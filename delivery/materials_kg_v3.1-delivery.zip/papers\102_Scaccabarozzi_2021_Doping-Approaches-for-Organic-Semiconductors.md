# Doping Approaches for Organic Semiconductors.

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Chemical Reviews |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 358 |
| 作者 | A. Scaccabarozzi, Aniruddha Basu, Filip Aniés, Jian Liu, Osnat Zapata-Arteaga, Ross Warren, Yuliar Firdaus, M. Nugraha et al. |
| DOI | 10.1021/acs.chemrev.1c00581 |
| 源文件 | 002_Scaccabarozzi_2021_Doping-Approaches-for-Organic-Semiconductors.pdf |

---
# **Doping Approaches for Organic Semiconductors** 

Alberto D. Scaccabarozzi,<sup>1†*</sup> Aniruddha Basu,<sup>1†</sup> Filip Aniés,<sup>3</sup> Jian Liu,<sup>2</sup> Osnat ZapataArteaga,<sup>4</sup> Ross Warren,<sup>5</sup> Yuliar Firdaus,<sup>1,7</sup> Mohamad Insan Nugraha,<sup>1</sup> Yuanbao Lin,<sup>1</sup> Mariano Campoy-Quiles<sup>4</sup> Norbert Koch,<sup>5</sup> Christian Müller,<sup>2</sup> Leonidas Tsetseris,<sup>6</sup> Martin Heeney,<sup>3</sup> Thomas D. Anthopoulos<sup>1*</sup> 

1. King Abdullah University of Science and Technology (KAUST), KAUST Solar Center (KSC), Thuwal 23955, Saudi Arabia 

2. Department of Chemistry and Chemical Engineering, Chalmers University of Technology, Göteborg 412 96, Sweden 

3. Department of Chemistry and Centre for Processable Electronics, Imperial College London, London, W12 0BZ , UK 

4. Materials Science Institute of Barcelona, ICMAB-CSIC, Campus UAB, 08193 Bellaterra, Spain 

5. Helmholtz-Zentrum Berlin für Materialien und Energie GmbH, Kekulé-Strasse 5, 12489 Berlin, Germany 

Institut für Physik & IRIS Adlershof, Humboldt-Universität zu Berlin, 12489 Berlin, Germany 

6. Department of Physics, National Technical University of Athens, Athens GR-15780, Greece 

7. Research Center for Electronics and Telecommunication, Indonesian Institute of Science, Jalan Sangkuriang Komplek LIPI Building 20 level 4, Bandung 40135, Indonesia 

† Authors contributed to this work equally 

Corresponding authors: thomas.anthopoulos@kaust.edu.sa; alberto.scaccabarozzi@kaust.edu.sa 

- 1 - 

### **Abstract** 

Electronic doping in organic materials has remained an elusive concept for several decades. It drew considerable attention in the early days in the quest for organic materials with high electrical conductivity, paving the way for the pioneering work on pristine organic semiconductors (OSCs) and their eventual use in a plethora of applications. Despite this early trend, however, recent strides in the field of organic electronics have been made hand in hand with the development and use of dopants to a point that are now ubiquitous. This article attempts to provide an overview of all important advances in the area of doping of organic semiconductors and their applications. We first review the relevant literature with particular focus on the physical processes involved, discussing established mechanisms but also newly proposed theories. We then continue with a comprehensive summary of the most widely studied dopants to date placing particular emphasis on the chemical strategies towards the synthesis of molecules with improved functionality. The processing routes towards doped organic films and the important doping-processing-nanostructure relationships, are also discussed. We conclude the review by highlighting how doping can enhance the operating characteristics of various organic devices. 

**TOC Graphic** 



<!-- Start of picture text -->
e<br>HOMO<br>n -dopant<br>OSC<br>e LUMO<br>p -dopant<br>- - - - - + + + +<br>- - - - + + + + + +<br>σ<br>50 25 0 25 50<br>Dopant concentration (%)<br>n -doping p -doping<br>WF (eV)<br>Conductivity<br><!-- End of picture text -->

- 2 - 

### **Table of Content** 

|1. Introduction .......................................................................................................|..................... 7|
|---|---|
|2. Molecular doping of Organic Semiconductors .................................................|..................... 9|
|2.1. Physical Processes|15|
|Density of states|15|
|Molecular orbital levels of a single molecule|15|
|Single molecules to thin films|16|
|Doping Processes:|21|
|Ion-pair formation:|21|
|Charge-transfer complex formation|23|
|Other doping processes|24|
|DOS of semiconductor and dopant|26|
|Charge carrier density against temperature|28|
|Charge carrier density against dopant concentration|31|
|Doping Efficiency|33|
|Charge carrier transport in doped semiconductors|35|
|Electrical contact to doped organic semiconductors|37|
|2.2. Atomistic Computational Studies|39|
|Integer Charge Transfer and Charge Transfer Complexes|40|
|Hydride Transfer, Anion Doping and Lewis Acids|43|
|2.3. Dopant Materials|46|
|Inorganic species|47|
|Molecular dopants|47|
|TCNQ derivatives|48|
|Fullerene dopants|49|
|Sulfur containing dopants and cationic dyes|50|
|DMBI derivatives|51|



- 3 - 

|Organometallics|54|
|---|---|
|Lewis acids and bases|57|
|Radialene based dopants|60|
|Amine based n-dopants|62|
|Other new dopants|65|
|Self-doping species|68|
|2.4. Design of organic semiconductors for dopant/host interactions|73|
|Side chain engineering|73|
|Backbone engineering|75|
|2.5. Experimental characterization|77|
|Diagnostic methods for doping|78|
|Mobility and charge-carrier density measurements|80|
|Field-effect mobility|81|
|SCLC mobility|81|
|CELIV Technique|82|
|Hall voltage and Hall mobility|82|
|3. Processing and nanostructure of molecularly doped polymers.........................|................... 83|
|3.1. Doping methods: co-processing and sequential doping|83|
|Co-processing|84|
|Sequential doping|86|
|3.2. Doping of bulk materials|89|
|3.3. Interplay between doping and microstructure|93|
|Highly conducting materials|93|
|Dopants as morphological modifiers additives|96|
|4. Doping of electronic devices ............................................................................|................. 105|
|4.1. Doping in OPV|105|
|Doping of charge transport layers|107|



- 4 - 

|Molecular doping of the BHJ layer|108|
|---|---|
|4.2. Doping in OTFTs|112|
|Controlling charge transport in OTFT with doping|113|
|Channel doping in OTFTs|120|
|Contact doping in OTFTs|125|
|4.3. Doping in Organic Thermoelectrics|129|
|4.4. Doping in other organic device technologies|136|
|5. Conclusions and perspectives|138|



- 5 - 

## **1. Introduction** 

The electronics revolution represents one of the major milestones of the 20<sup>th</sup> century with profound consequences on our society. To this end, organic electronics represent a new technological paradigm, similar to what the semiconductor industry achieved with the advent of silicon microelectronics.<sup>1–5</sup> Indeed, the deployment of organic semiconductors promises to widen the realm of electronics to countless new applications, thanks to their numerous advantageous properties.<sup>6–8</sup> A notable example is the organic light-emitting diode (OLED), that forged ahead since its discovery in 1987 and is now widely employed by the display and lighting industry, featuring devices that are light-weight and even flexible.<sup>9–12</sup> However, the exploitation of organic electronics in other applications, _e.g.,_ thin-film transistors (TFTs) or photovoltaics (PVs), has been progressing slower than expected due to difficulties in delivering high performance and reliability. 

A crucial element that unlocked the touted potential of organic electronics is electronic doping and here again, OLEDs serve as the prototypical example. It was only when doped charge transport layers were introduced in standard device architectures, that light-emitting diodes reached the performance and the technological maturity required for industrialization.<sup>13,14</sup> Furthermore, in recent years there has been a progressive transition from the straightforward use of dopants in highly conducting layers, to their incorporation into other fundamental parts of the devices. Active layers, for instance, have been almost entirely relying, until very recently, on pristine ( _i.e.,_ non-doped) organic semiconductors, in strong contrast to the typical approach exploited in classic inorganic semiconductors, _e.g.,_ silicon. Indeed, the interaction between dopants and organic semiconductors typically occurs through weak interactions and therefore the fabrication of a stable doped junction, as in inorganics, is highly challenging. For instance, the fabrication approach employed in organic thin-film transistors (OTFTs) is commonly based on the use of a single component, pristine semiconductor that is used to bridge the source and drain electrodes to form the channel. Extensive efforts in optimizing structure-property relationships in these layers led to a level of device optimization that pushed this approach to its limits. In this context, the employment of multicomponent systems and in particular that of dopants, paved the way for new possibilities, enabling the demonstration of organic electronic devices with unprecedented performance.<sup>15–21</sup> Similarly, the recent use of molecular dopants in bulk heterojunctions (BHJs) of various organic photovoltaics (OPV) is paving the way to improved power conversion efficiencies (PCEs) that are projected to exceed the benchmark value of 20% for single-junction devices.<sup>22–25</sup> Moreover, 

- 6 - 

the ability to incorporate large amounts of dopants into organic semiconductors and thus achieve high electrical conductivity has been attracting a growing interest, owing to their potential use in new forms of thermoelectric generators.<sup>26,27</sup> However, as promising and fascinating as the doping strategy is, there are still a lot of unexplored paths, and despite the plethora of possible molecules that have been designed, most of the focus in device applications has been limited on a handful of material systems. 

In this review article we discuss recent advances in the application of doping strategies for organic semiconductors. We will briefly review the fundamentals of doping in organics and the physical processes involved. We then address the relevant theoretical and computational work while highlighting the open questions related to the doping mechanisms. Further, we attempt to provide chemical insights, summarizing the most popular materials used as dopants and the novel molecular species that are emerging, with an emphasis on the chemical strategies towards the design of improved molecular dopants and their hosts. We then address the different processing methods for realizing doped films, discussing the routes towards high doping efficiency and the impact on the nanostructure of the host organic material(s). Finally, we highlight how doping has been exploited to control the operation of organic devices and in some cases to even enhance their performance. Full names of materials mentioned in this article and their chemical structures are given in the _Supporting Information_ section, if not indicated. 

- 7 - 



Figure 1: Chemical structure of selected OSCs. 

## **2. Molecular doping of Organic Semiconductors** 

### **2.1. Physical Processes** 

In this section we discuss the physical processes relevant to doping of organic semiconductors (OSCs), starting from the orbital levels of single molecules and building up to the density of states for a thin film. We discuss the different doping mechanisms occurring in this class of materials and we cover the effect of doping on charge carrier density and transport in organic films. Finally, we provide a summary on the electrical contact formed between a metal and a doped organic semiconductor. 

- 8 - 



### **Density of states** 



### **Molecular orbital levels of a single molecule** 

The highest occupied molecular orbital (HOMO) and lowest unoccupied molecular orbital (LUMO) levels for molecular semiconductors and the valence band maximum and conduction band minimum for polymer semiconductors, play a key role in determining the electronic and optical properties of the materials, and are particularly important for the doping process. In the following, the terms HOMO/LUMO are used synonymously for valence/conduction bands, but it is pointed out that the reader should keep in mind the differences when considering a specific material. The localized electron wavefunctions of a molecule are in contrast to delocalized ones in polymers, which can result in one-dimensional dispersive electronic bands. For a single molecule in isolation, the energy of the HOMO level is considered equivalent to the vertical ionization energy (IE) - that is the energy required to remove an electron and place it at rest, in a vacuum, and infinitely far away from the molecule. Similarly, the electron affinity (EA), equivalent to the LUMO level for an isolated molecule, is defined as the energy gained by adding an electron to the molecule from infinitely far away.<sup>28</sup> The energy gap between the IE and EA defines the fundamental gap and can be measured experimentally for single molecules _via_ a combination of gas-phase direct and inverse photoelectron spectroscopy (IPES).<sup>29</sup> The ionization energy and ionization potential are identical for an isolated molecule in vacuum, however, for solids, these two terms may take on different values. In a simple picture, the ionization potential is the energy difference between the HOMO level and the electrostatic potential at an infinite distance. The latter is often referred to as vacuum level and is commonly set to zero. The IE is the experimentally determined quantity, and can differ from the ionization potential if the electron removed from the HOMO level has to pass through a non-trivial electrostatic landscape. For example, this can be a surface dipole, requiring additional energy for electron removal compared to the ionization potential. As a final point regarding definitions, both the EA and IE have positive values below the vacuum level. Therefore, an increase of EA or IE signifies more tightly bound molecular energy levels. 



### **Single molecules to thin films** 

While the IE and EA are well-defined values for a single or gas-phase molecule, environmental interactions in a condensed phase make measurements and calculations of these parameters dependent on the technique that is employed (see also section 2.5) and on the molecular organization within films. The IE and EA can be accurately determined through a combination of UPS and IPES. Alternatively, cyclic voltammetry (CV) is often used, where molecules in 

- 9 - 

solution or thin polymer films deposited on an electrode are electrochemically oxidized/reduced. It should be noted that CV only provides approximate values because it does not fully capture solid-state effects (cf. discussion below) and is sensitive to the precise experimental conditions.<sup>30,31</sup> For example, the IE of pentacene (cf. chemical structure in Figure 1) was found to be about 1.5 eV smaller in the solid phase as compared to gas phase.<sup>32</sup> Furthermore, variations by up to 1 eV in solid-state IE have been reported for films of the same compound but with different molecular orientation, e.g., edge-on _vs_ . face-on with respect to the substrate.<sup>33–35</sup> These observations highlight the importance of carefully considering all solid-state effects that impact IE and EA, as briefly summarized in the following. 



Figure 2: Drawing of the energy level shifts from single molecules to solids. The induction (or polarization) _E_ ind interactions act to stabilize the energy levels in a molecular solid with respect to the single molecule values. In crystalline or poly-crystalline films, the molecular ordering results in a further electrostatic shift labelled _E_ el. This interaction arises as a consequence of permanent charge distributions, resulting in the HOMO and LUMO manifolds shifting in the same direction, and by equal magnitude. The direction of the energy level shift depends upon the molecular orientation. 

Figure 2 depicts the shift in HOMO and LUMO level energy upon going from a single molecule to a molecular solid. Firstly, induction interactions _Eind_ of a created charge with the surrounding molecules act to change the energy levels, with the IE decreasing and the EA increasing. Consequently, the fundamental gap becomes narrower. This electronic polarization by the dielectric environment<sup>36,37</sup> can be sizable (in the range of 1-2 eV), and it may even differ for an electron and a hole.<sup>38</sup> Secondly, collective electrostatic interactions _Eel_ arising from permanent charge distributions of the molecule and its environment can lead to parallel shifts on the order of 1 eV of the IE and EA, i.e., the fundamental gap remains unchanged. This phenomenon is restricted to ordered molecular assemblies, e.g., crystalline films, as only the collective action of molecular bond-dipoles and quadrupoles,<sup>35,39,40</sup> as leading terms, give rise to electrostatic potential shifts in the far-field. Examples are rod-like molecules, such as many 

- 10 - 

oligomers and planar molecules, for which – in crystalline thin films – the EA and IE depend strongly on the molecular orientation with respect to surface,<sup>35,38–41</sup> and the same holds for ordered polymer films.<sup>39</sup> Further modification of the IE and EA of organic crystals can originate from a considerable overlap of HOMO and LUMO orbitals between neighboring molecules. In that case, delocalized and dispersive electronic bands emerge from the otherwise localized electronic states, and sizable bandwidths on the order of several 100 meV have been determined.<sup>42</sup> 

<mark>In general, the energy levels of molecules in the solid are determined by the interactions with the environment, and thus strongly depend on the distance and mutual orientation of the molecules in the solid. To date, most studies on doped organic semiconductors are concerned with amorphous and polycrystalline materials. Studies on single crystals with low dopant concentration face the challenge of dispersing the dopants homogenously in the sample, but future efforts in this direction could be very rewarding.  In the following sections, we focus on disordered systems described using Gaussian distributions. Readers interested in ordered materials, e.g. single crystals, and descriptions using alternative DOS distributions of the states relevant for charge transport, e.g. exponential,   are referred to previous studies references</mark><sup>42–44</sup> <mark>.</mark> 

In a disordered solid, the environmental interaction/parameters are randomly distributed, producing local energy level shifts with a similar random distribution. The Central Limit Theorem states that the sum of a group of random independent variables tends towards a normal distribution, even if the variables do not follow a normal distribution themselves. Therefore, the resulting spread of energy states per unit volume, termed the density of states (DOS), is described with a Gaussian function centered around a mean value with standard deviation σDOS, which can be thought of as a disorder parameter. Energetic disorder encompasses intermolecular effects, as well as on-site variations. Changes in conjugation length, configuration, conformation, the relative orientation of molecules, and the presence of chemical defects, all contribute to even greater disorder in the DOS.<sup>45–47</sup> The population of molecular vibrational and librational modes, as a function of temperature, impact the timeaveraged DOS in an analogous manner. 

- 11 - 



Figure 3: Gaussian approximation for the density of states (DOS) of a molecular solid. Two Gaussian distributions representing the occupied HOMO and unoccupied LUMO manifold are shown. They are centered around _EHOMO_ and _ELUMO_ , respectively. With this Gaussian approximation for the DOS, the IE and EA are commonly defined by linear extrapolation from the curve’s inflection point towards zero, as shown, with the y-axis intercept at 2 _σDOS_ from the DOS centre. 

Figure 3 shows Gaussian distributions representing the HOMO and LUMO manifolds in a molecular solid. The two distributions are centered around _EHOMO_ and _ELUMO,_ and have an identical standard deviation σ. With this Gaussian approximation for the DOS, the IE and EA are commonly defined by linear extrapolation from the curve's inflection point towards zero, as shown, with the y-axis intercept at 2σDOS from the DOS center. It follows that in the disordered molecular solid, about 2.3 % of the molecules will have lower IE than determined _via_ extrapolation, and likewise the same fraction of molecules will have a higher EA. Clear knowledge of the meaning of IE and EA is critical as these values often form the basis for selecting host and dopant combinations. 



### **Doping Processes** 

Doping in OSCs is associated with complex mechanisms, many of which have been investigated using different approaches.<sup>26,48–52</sup> Yet, and despite the plethora of processes that have been reported, a complete understanding is still emerging. The large majority of molecular dopants are classified as neutral molecules that purely undergo an electron transfer with the OSC, without involving any chemical reaction. The electron transfer is believed to undergo two types of mechanisms: either ion-pair (IP) formation or charge-transfer complex (CTC) formation. Nevertheless, other dopants have been reported to undergo chemical reactions with 

- 12 - 

the OSC, and as a consequence, these systems are characterized by specific doping routes. In the following sections, we will discuss the different theories on doping of OSCs that have been reported, beginning with standard mechanisms and discussing the evolution of the dopants in that context. 



### **Ion-pair formation** 

The basic doping mechanism in organic semiconductors is believed to undergo an electron transfer process from the OSC to the dopant (p-type doping) or from the dopant to the OSC (ntype doping).<sup>13,26,57,58,48–51,53–56</sup> Therefore, the IE and EA values of the OSC and the dopant play a major part in this process. For  p-type doping, the EA of the dopant should ideally be equal or higher than the IE of the OSC,  allowing the dopant to accept an electron into its LUMO from the HOMO of the OSC, resulting in a paired dopant anion and OSC cation.<sup>48</sup> For n-type doping, the opposite process occurs. That is, the OSC accepts an electron into its LUMO from the HOMO of the dopant and hence, the IP is formed between the dopant cation and OSC anion (Figure 4). 

Spectroscopic evidence from several studies supports the formation of the IP in various systems.<sup>48,49,56,57</sup> The nature of the charge introduced into the OSC is not simply that of an excess electron or hole. Indeed, the charge formation is accompanied by a perturbation of the crystal lattice of the OSC, owing to the strong electron-phonon interactions in this class of materials, leading to an electronic charge dressed by phonon clouds. In condensed matter physics, this is defined as a quasi-particle, the polaron,<sup>59</sup> which in this case is localized on a single molecular site or conjugated polymer segment. During charge transport, the polaron, _i.e._ , the charge and its associated distortion, moves through other molecular locations, carrying the lattice distortion with itself. In the case of an amorphous OSC, the nature of the perturbation is associated with a structural distortions of the organic molecule. If a further charge is introduced into the semiconductor, two possibilities exist. The first is that a new polaron is formed in a different polymer segment or molecular site; the second is that the charge is added to an existing polaron. In the latter case, a new quasi-particle is formed, the bipolaron, which is defined as a pair of charges coupled with a strong distortion (a phonon cloud). The energetic condition for the formation of a bipolaron is that the Coulombic repulsion between the two charges needs to be smaller than the stability gained through nuclear reorganization.<sup>60</sup> 

Following charge transfer, the hole on the host semiconductor must dissociate from the negatively ionized dopant in order to become a mobile carrier. The binding energy _Eb_ of the IP 

- 13 - 

is approximated considering the Coulomb interaction between them (ignoring induction effects) 



<!-- Start of picture text -->
𝑒 2 1<br>𝐸𝑏(𝑟) =<br>4𝜋𝜀0𝜀𝑟 𝑟<br>(1)<br><!-- End of picture text -->

where _r_ is the charge-ionized dopant distance of separation. Taking a typical static dielectric constant of εr ≈ 3 for apolar organic semiconductors<sup>61,62</sup> and an intermolecular distance of r ≈ 1 nm, yields a binding energy of _Eb_ ≈ 0.5 eV. As this approximate binding energy far exceeds the thermal energy at room temperature ( _kT_ = 25 meV), only a small fraction of charges will dissociate. However, this simple model neglects other effects, which reduce the barrier to dissociation, such as Coulomb potential overlap between nearby dopant ions,<sup>52</sup> energetic disorder,<sup>63</sup> and entropic contributions.<sup>64</sup> 



<!-- Start of picture text -->
a Ion-pair formation b Ground state charge<br>transfer complex formation<br>Neutral<br>CTC<br>e -<br>Neutral  Neutral<br>OSC p-dopant Neutral  Neutral<br>OSC p-dopant<br>c d<br>Binding energy Binding energy<br><!-- End of picture text -->

Figure 4: a) IP formation and b) ground state CTC formation. Adapted with permission from ref<sup>48</sup> . Copyright 2016 American Chemical Society. c) Absorbance spectra of undoped and F4-TCNQ-doped P3HT films after thickness normalization (Reprinted with permission from ref<sup>65</sup> . Copyright 2013 American Physical Society). d) Infrared spectrum for F4-TCNQ-doped 4T (solid line) and P3HT film (dot-dashed line). Reprinted with permission from ref<sup>66</sup> . Copyright 2015 Méndez et al. under Creative Commons Attribution 4.0 International License http://creativecommons.org/licenses/by/4.0/. 

- 14 - 



### **Charge-transfer complex formation** 

Another well-known mechanism for OSC doping involves the formation of CTCs. According to the latter, the frontier orbitals of OSC and dopant undergo hybridization to form a new set of occupied (HOMOCTC) bonding and unoccupied (LUMOCTC) antibonding orbitals.<sup>26,48–51,67,68</sup> In contrast with the IP mechanism, CTC formation can also form in systems having EAdopant << IEOSC (for p-type doping) and IEdopant >>EAOSC (for n-type doping).<sup>48,66,69</sup> The degree of hybridization and energy level splitting are concomitant with the extent of orbital overlap as well as with the energy level mismatch between OSC and dopant. The amount of charge transfer (δ) can be determined by the relative amplitude of these newly formed energy levels and can involve non-integer charge transfer.<sup>48,66,69</sup> Interestingly, a dopant can undergo both IP or CTC formation depending on the particular host semiconductor. For instance, in the case of F4-TCNQ doping of a thiophene oligomer, quaterthiophene (4T, cf. chemical structure in Figure 1), Fourier transform infrared spectroscopy (FTIR) shows a redshift of the cyano (C≡N) peak of about 7 cm<sup>-1</sup> , compared to the 30-33 cm<sup>-1</sup> shift for the same dopant in P3HT, where IP formation is observed (Figure 4d).<sup>66–68</sup> These features indicate that a partial charge transfer (δ = 0.21-0.25) is involved for 4T owing to CTC, unlike IP. Although this partial charge transfer cannot produce charge carriers directly in the OSC, the partial charge transfer is achieved through an integer charge transfer (ICT) from the neutral OSC to CTC, where the CTC acts as a dopant for the undoped OSC.<sup>66</sup> However, the ICT is a non-spontaneous process that comprises substantial activation energy. Hence, not all CTCs are involved in the charge carrier generation, which eventually leads to lower carrier density and electrical conductivity compared to the IP mechanism. For example, under the same doping condition, the highest electrical conductivity ( _σ_ ) of P3HT (IP mechanism) was observed to be 1 S cm<sup>-1</sup> compared to 10<sup>-3</sup> S cm<sup>-1</sup> for 4T (CTC mechanism).<sup>26,66</sup> Nevertheless, due to the high complexity of the doping mechanism, it is still an open question to predict whether CTC or IP formation will take place in a given dopant/OSC system. Indeed, several factors dictate which mechanism would occur/prevail, such as dopant strength, charge carrier localization on OSCs, energy level offset, electron-hole interaction, spin relaxation, and disorder.<sup>26</sup> Therefore, further studies on the electronic structure of dopant/OSC systems and on hybridization effects are still required in order to advance our understanding of the relevant processes/relationships and as such improve our predictive power. 

- 15 - 



### **Other doping processes** 

Recently, non-conventional doping methods have been reported where the doping mechanism indeed undergoes an electron transfer process but no evidence for the formation of IP or CTC can be found. The chemical structures and a comprehensive discussion of the materials discussed hereafter are reported in Section 2.3. Goel _et al_ . reported a p-doping route of a polymeric semiconductor (OSC-1) where a  radical cation salt (OSC-2) is used as a dopant.<sup>70</sup> A similar process occurs when the polymer is doped with the strong oxidant tris(4bromophenyl)ammoniumyl hexachloroantimonate (Magic Blue).<sup>71,72</sup> The doping occurs due to the electron transfer from the fully occupied HOMOOSC-1 to the partially occupied HOMOOSC2. This process results in the reduction of OSC-2 and the resulting doped system becomes the mixture of both hole conductors. 

Apart from the electron transfer processes, a few other doping mechanisms have also been reported for different dopant/OSC systems. The proton (H<sup>+</sup> ) related doping process is one of them, where the dopant introduces a proton to the OSC backbone to ionize the host. This charge is eventually redistributed via conjugation effects and the corresponding anion moiety enters into the system for electric neutrality.<sup>26</sup> The latter doping process is predominantly observed in polymeric OSCs due to the presence of extended conjugation in their backbones. For example, 4-ethylbenzenesulfonic acid (EBSA) has been used as a proton dopant in poly[2,5-bis(3-alkylthiophen-2-yl)thieno(3,2-b)thiophene] (PBTTT, cf. chemical structure in Figure 1) for thermoelectric applications, where a substantial improvement in the OSC conductivity was observed upon doping.<sup>73</sup> However, this type of doping is reversible and spontaneous de-doping occurs in presence of a base.  In some cases, the acid does not lead to protonation of the conjugated backbone but mediates oxidation by O2.<sup>74–76</sup> On the other hand, hydride (Hˉ) doping is an irreversible process, although the doping mechanism is still under debate. The doping reaction is believed to occur in the solution phase, either by hydride transfer or by electron transfer from the dopant to the OSC, both leading to the formation of CTC along with some byproducts (see Section 2.2.2).<sup>77,78</sup> As discussed earlier, the dissociation of the CTC is the key for the effective charge carrier generation and hence, CTC with lower binding energy favors an effective doping process. Zeng _et al_ . used (4-(1,3-dimethyl-2,3-dihydro-1Hbenzoimidazol-2-yl)phenyl)dimethyl-amine (N-DMBI) (cf. chemical structure in Figure 12) as a hydride dopant in two polymers with different EA values.<sup>78</sup> Spontaneous doping was found to happen in the polymer with a higher EA value at room temperature. 

- 16 - 

Lewis acid and base doping are also emerging doping methods recently explored in the area of OSCs (see Section 2.2.2).  For example, boron trifluoride (BF3), a non-oxidative Lewis acid, was used to p-dope poly(p-phenylene vinylene) (PPV) with the process argued to rely on the formation of a coordination bond between BF3 and a vinyl group of PPV, which ultimately induces a positive charge in the backbone.<sup>79,80</sup> To gain a better understanding of the mechanism involved, Yurash _et al_ . conducted a systematic study of the Lewis acid doping in organic semiconductors with strong (poly[2,6-(4,4-bis-(2-ethylhexyl)-4H-cyclopenta [2,1-b;3,4b′]dithiophene)-alt-4,7(2,1,3-benzothiadiazole)] (PCPDTPT, cf. chemical structure in Figure 1)) and weak (poly[2,6-(4,4-bis-(2-ethylhexyl)-4H-cyclopenta [2,1-b;3,4-b′]dithiophene)-alt4,7(2,1,3-benzothiadiazole)] (PCPDTBT)) Lewis basic sites and compared them with classic electron-transfer dopants and Brønsted dopants.<sup>81</sup> According to the suggested mechanism, doping occurs in three steps: 

- 1) Formation of an acidic (Bronsted-type) tris(pentafluorophenyl)borane (BCF)-H2O complex 

- 2) Protonation of the polymer backbone with the formation of [BCF:OH]ˉ complex, 

- 3) Electron transfer from the neutral polymer chain segment to the protonated one resulting in the formation of a protonated radical species and a positively charged radical species, respectively. The positively charged radical species are attributed to being the free charge carriers in electrical measurements and the charge on it is effectively neutralized by [BCF:OH]ˉ counterions. 

Similarly, electron deficient OSCs can act as π-acids, facilitating n-type doping by interacting with Lewis bases.<sup>80</sup> An in-depth study by Guha _et al_ . on Lewis base doping in naphthalenediimide (NDI) derivatives showed the π-acidity of the OSCs plays a crucial role along with dopant strength for effective n-type doping, where the Lewis base/π-acid interaction is the key factor for determining the doping magnitude in n-type semiconductors.<sup>82</sup> Recently, Lewis base containing tetrabutylammonium dopants have attracted much attention due to their unconventional doping mechanism. The latter has been described in the framework of a pure electron transfer process, from the anion, halogens (Xˉ) or hydroxide (OHˉ), to the OSC ( _e.g._ , Fullerene (C60, cf. chemical structure in Figure 1)) which results in the formation of n-doped OSC radical anions ( _e.g._ , C60˙ˉ) and donor radicals ( _e.g._ , F˙ or OH˙).<sup>83</sup> Yet, the high electronegativity of fluoride makes direct electron transfer thermodynamically unlikely, so a different mechanism has been proposed by Weber _et al_ . who suggested that the presence of anions with strong nucleophilicity, such as Fˉ or OHˉ, can introduce a more complex doping process. They proposed that instead of a direct electron transfer process, a nucleophilic addition 

- 17 - 

reaction occurs between the anion and the OSC forming a C60-Fˉ adduct anion, which undergoes a subsequent electron transfer to a second C60 molecule.<sup>84</sup> For more detailed insight on the plausible mechanism involving Lewis bases, the readers are referred to Section 2.2.2 and a comprehensive review by Bridges _et al_ .<sup>80</sup> 



### **DOS of semiconductor and dopant** 

The following considerations are made for dopants that undergo electron transfer with the semiconductor, where the DOS of both compounds play a decisive role; for other doping mechanisms, _e.g._ , hydride transfer, this is not the case. Ideally, host and dopant materials that are to undergo electron transfer are paired based on securing a favorable energy offset to promote charge transfer between the frontier orbitals levels of adjacent host and dopant molecules. In practice, however, the position of the dopant’s energy levels when placed within the host matrix is difficult to determine. Computational work has shown differences of up to 1 eV between a pure dopant crystal and a dopant impurity surrounded by a host semiconductor (Section 2.2), due to environmental interactions named above.<sup>85</sup> Shifts of 0.86 eV have been confirmed experimentally for the molecular p-dopant hexafluorotetracyanonaphthoquinodimethane (F6-TCNNQ) with a phthalocyanine as the host<sup>86</sup> . 



<!-- Start of picture text -->
a b<br><!-- End of picture text -->

Figure 5: Illustration of the host and dopant DOS before (a) and after (b) charge transfer. (a) Energy levels of a neutral p- dopant within a matrix of the host semiconductor. The electron affinity of the neutral p-dopant is marked _EA_<sup>0</sup> , as referenced from the vacuum level _E_ vac. Analogously, the neutral host’s ionization energy is marked _IE_<sup>0</sup> . The corresponding DOS is drawn on the right hand side, with the shaded area representing the occupied levels. (b) After charge transfer, the on-site Coulomb interactions split the anion’s and cation’s frontier orbitals in two, separated by the reorganization energy λ from their original 

- 18 - 

positions. _EA_<sup>+</sup> and _IE_<sup>−</sup> mark the new levels of the host cation and dopant anion, respectively. Meanwhile, the intersite Coulomb interactions cause a shift in the neighboring molecule’s energy levels, dependent on distance. 

Figure 5a shows the DOS of a host and p-dopant _prior_ to charge transfer. At zero temperature, the host semiconductor's HOMO manifold is fully occupied. The dopant’s LUMO manifold, overlapping with the host's HOMO manifold, is unoccupied. The overlap between these two manifolds dictates the maximum charge transfer that can occur. In practice, many host and dopant states are spatially separated within the bulk material, reducing the likelihood of charge transfer. With increasing temperature, thermal fluctuations grant the opportunity for less-favorable configurations to result in charge transfer.<sup>30</sup> 

After charge transfer, Figure 5b, Coulomb interactions both on-site (within the molecule) and off-site (acting on neighboring molecules), as well as molecular geometry changes, impact the shape of the DOS. Firstly, on-site Coulomb interactions split the former HOMO or LUMO level into two sub-levels for the ionized molecule, separated in energy by an amount commonly termed Hubbard ( _Ud_ or _Uh_ ).<sup>87–89</sup> The two sub-levels are single-electron levels, and define the EA and IE of the ionized molecule, EA<sup>-/+</sup> and IE<sup>-/+</sup> with "-" indicating the anion and "+" the cation state. Adding a charge to a molecule leads to changes in bond lengths and bond angles, which is associated with the reorganization energy λ.<sup>90</sup> This energy relates the neutral and charged molecule's energy levels, _i.e._ , the host cation’s electron affinity EA<sup>+</sup> is lower than the neutral host IE<sup>0</sup> by  h, and the dopant anion’s IE<sup>-</sup> is higher than the neutral dopant's EA<sup>0</sup> by  d, as indicated in Figure 5b. Secondly, off-site Coulomb interactions shift the energy levels of nearby neutral molecules that sit within the Coulomb potential well generated by the ionized species, also shown in Figure 5b. 



### **Charge carrier density** **_vs._ temperature** 

Mathematically, the description of organic semiconductors follows that established for inorganic semiconductors. Figure 6a displays the quantities needed to calculate the density of charge carriers in a p-doped semiconductor. The first panel shows the DOS for the host’s HOMO and LUMO manifolds (𝑔𝐻𝑂𝑀𝑂ℎ𝑜𝑠𝑡 (𝐸) _,_ and 𝑔𝐿𝑈𝑀𝑂ℎ𝑜𝑠𝑡 (𝐸)), and the dopant’s LUMO manifold 𝑔𝐿𝑈𝑀𝑂𝑑𝑜𝑝𝑎𝑛𝑡(𝐸). The middle panel shows the Fermi-Dirac distribution function _f(E)_ at _T_ = 4000 K. The third and final panel shows the charge carrier densities per unit energy, at thermal equilibrium, of holes in the host HOMO manifold p(E), electrons in the host LUMO manifold n(E), and ionized p-dopants 𝑛𝑑𝑜𝑝𝑎𝑛𝑡− (𝐸). From Figure 6a, p-doping is apparent from the 

- 19 - 

increased _p(E)_ resulting from occupation of the dopant’s LUMO manifold by electrons 𝑛𝑑𝑜𝑝𝑎𝑛𝑡− (𝐸) _._ 



Figure 6: Plots of Fermi level, percentage of ionized p-dopants, and carrier density, against inverse temperature. (a) Graphical representation of the quantities needed to calculate charge carrier density in an organic semiconductor p-doped at a molar concentration of 40%. The first panel shows the Gaussian DOS for the host’s HOMO _ghostHOMO_ (E), LUMO _ghostLUMO_ (E) and the dopant’s LUMO _ghostLUMO_ (E). The second panel shows the occupation probability _f_ (E), following Fermi-Dirac statistics, with the Fermi Level marked _E_ F. Finally, the third panel shows the charge carrier densities per unit energy of holes in the host HOMO manifold _p_ ( _E_ ), electrons in the host LUMO manifold _n_ ( _E_ ), and ionized p-dopants n− _dopant_ (𝐸). (b) Fermi level against inverse temperature in a p-doped semiconductor. _E_ F quickly shifts toward the HOMO manifold with decreasing temperature, as intrinsic carriers are negligible and dopants fail to ionize. (c) The p-dopant ionization percentage as a function of inverse temperature. With lower temperature, only a fraction of the p-dopants can ionize. The disorder has a strong impact on how the ionization decreases with temperature. (d) Log plot of carrier density against inverse temperature. With low disorder ( _σ_ = 0.01 eV), the three regimes from inorganic semiconductor physics are visible - the intrinsic, dopant saturation, and dopant reserve regimes. With increasing disorder, it becomes difficult to distinguish between the dopant saturation and reserve regimes. For these simulations, the energy gap is _ELUMO_ - _EHOMO_ = 3 eV, the dopant’s DOS is centered around _E_ dopant = 0.2 eV, the disorder is equal for all components in the mixture _σDOS_ = _σDOS_<sup>_host_</sup> = _σDOS_<sup>_dopant_</sup> , and the molar doping concentration is 10%. 

Figure 6b-d show the Fermi level position within the host semiconductor's gap, percentage of ionized p-dopants, and charge carrier density at a fixed molar dopant concentration of 10 % against inverse temperature. To visualize the effect of disorder, we vary the DOS standard deviation 𝜎𝐷𝑂𝑆 = 𝜎𝐷𝑂𝑆ℎ𝑜𝑠𝑡 = 𝜎𝐷𝑂𝑆𝑑𝑜𝑝𝑎𝑛𝑡The respective values are determined by 

- 20 - 

Fermi-Dirac integrals, with the Fermi level set by numerically solving the neutrality condition 𝑛𝑓𝑟𝑒𝑒 = 𝑛𝑑𝑜𝑝𝑎𝑛𝑡− , where 𝑛𝑑𝑜𝑝𝑎𝑛𝑡− is the number density of ionized dopants. The position of _EF_ varies generally little with  DOS. At temperatures relevant to organic semiconductors (ca. up to 500 K), _EF_ is found close to the HOMO manifold onset (IE as defined by extrapolation, _vide supra_ ), and only for excessively high _T_ (where most organic semiconductors would decompose), the Fermi level moves towards mid-gap because thermally excited carriers of the host dominate and outweigh the effect of dopants. The impact of  DOS on the ionized dopant percentage (Figure 6c) is significant around room temperature. More dopants ionize with increasing disorder because of an increased overlap of 𝑔𝐻𝑂𝑀𝑂ℎ𝑜𝑠𝑡 (𝐸)and 𝑔𝐿𝑈𝑀𝑂𝑑𝑜𝑝𝑎𝑛𝑡(𝐸). Likewise, higher T makes more of the dopant LUMO's DOS accessible for the host's deeper lying HOMO levels and the ionized dopant percentage increases, but near room temperature the dependence is moderate. 

The temperature dependence of charge carrier density, Figure 6d, can be split into three regimes, analogously to inorganic semiconductor physics textbooks, most clearly identifiable for the low disorder (𝜎DOS = 0.01 𝑒𝑉). At low temperatures, p-dopants only partially ionize (𝑛< 𝑛𝑑𝑜𝑝𝑎𝑛𝑡), corresponding to the dopant reserve or freeze-out regime. In this regime, the Fermi level sits within the p-dopant’s LUMO manifold. With increasing temperature, a larger percentage of dopants ionized until the dopant saturation regime is reached ( 𝑛𝑑𝑜𝑝𝑎𝑛𝑡− ≈ 𝑛𝑑𝑜𝑝𝑎𝑛𝑡). At very high temperatures, the contribution of intrinsic carriers (thermally excited across the host energy gap) exceeds those generated by the dopants (Figure 6c), and the Fermi level shifts towards its intrinsic position, at the center of the host’s energy gap (Figure 6b). Resolving the dopant reserve from the dopant saturation regime is difficult if the disorder is large. As the width of the Gaussian distributions increase, there is a greater overlap between the host and dopant manifolds, resulting in a larger fraction of ionized dopants already at T = 0 K. Therefore, the percentage of ionized p-dopants is less dependent on temperature for highly disordered systems. With this in mind, doped organic semiconductors are expected to operate in the reserve regime,<sup>91,92</sup> with dopant ionization below 100% unless the EA of p-dopants is much higher than IE of the host or the n-dopant IE is much lower than the host's EA. 



### **Charge carrier density** **_vs._ dopant concentration** 

The Fermi level, percentage of ionized dopants, and charge carrier densities also depend on the dopant concentration present in the semiconductor. Here we express dopant concentration as the molar content of dopants divided by the total molar content of hosts and dopants in the 

- 21 - 

material mixture. We evaluate the Fermi-Dirac integrals at a fixed temperature (T = 300 K) over a range of dopant concentrations. At low dopant concentration (<< 1 %), the Fermi level, Figure 7a, resides within the host semiconductor gap with a high percentage of p-dopants ionized. As the dopant concentration increases, the Fermi level rapidly shifts to sit within the LUMO manifold of the dopant. Meanwhile, the percentage of ionized p-dopants, Figure 7b, plunges as the higher-lying dopant acceptor states are mostly inaccessible for electrons from the host's HOMO manifold. At this point, the doped semiconductor is operating in the reserve regime, and broadly encompasses the region of device-relevant doping concentrations. 



Figure 7: Plots of Fermi level, percentage of ionized p-dopants, carrier density, and conductivity against p-dopant molar fraction. (a) Fermi level shift as a function of dopant molar concentration, defined here as the molar content of dopants divided by the total molar content of hosts and dopants in the material mixture. The DOS before the addition of the dopant is overlayed, with the Fermi level sitting at its intrinsic position. At a dopant fraction of 25%, the DOS of the host and dopant are again overlayed, with the filled area representing occupied states. (b) Ionized dopant ratio as a function of dopant molar fraction. (c) Charge carrier density as a function of dopant molar fraction, given a molecular volume density of 3×10<sup>21</sup> cm<sup>−3</sup> and an integer charge transfer binding energy of _E_ B = 0.5 eV . (d) Log-log plot of conductivity against dopant molar fraction, assuming a constant mobility of 7.3 × 10<sup>−3</sup> cm<sup>2</sup> /Vs. The parameters used in all simulations are: _Ehost_ = 0 eV, _Edopant_ = 0.65 eV, T= 300 K and _σ_ = _σ host_ = _σ dopant_ = 0.2 eV. 

Figure 7c plots the density of charge carriers, assuming a molecular volume density of 3×10<sup>21</sup> cm<sup>-3</sup> , as a function of dopant concentration. To separate mobile carriers from bound carriers, we have introduced an IP binding energy of 0.5 eV, in a similar manner to recently 

- 22 - 

published models.<sup>63,86</sup> The sum of mobile and bound carriers on the host is equal to the density of ionized dopants, also plotted in Figure 7c. At low doping concentrations, the charge carrier density increases quickly. At higher concentrations, in the dopant reserve regime, the rate of increase slows as fewer dopants are ionized. In this model, mobile charges are generated quickly at low doping concentrations before increasing comparably slowly beyond a doping concentration of around 10%. 



### **Doping Efficiency** 

The doping efficiency describes the percentage of free charge carriers (or sometimes termed mobile charge carriers) that are generated per dopant in the semiconductor host material. Two processes must occur to generate a free charge carrier. First, the doping reaction must occur between the dopant and semiconductor host molecule, which ionizes the latter but leaves the resulting polaron Coulombically bound to the generated dopant counterion. The ionization efficiency can be defined as the ratio of the number of generated polarons 𝑁𝑝𝑜𝑙𝑎𝑟𝑜𝑛 and the total number of dopant molecules, 𝑁𝑑𝑜𝑝𝑎𝑛𝑡: 



<!-- Start of picture text -->
𝜂𝑖𝑜𝑛𝑖𝑧𝑎𝑡𝑖𝑜𝑛 =  𝑁𝑝𝑜𝑙𝑎𝑟𝑜𝑛<br>𝑁𝑑𝑜𝑝𝑎𝑛𝑡 (2)<br><!-- End of picture text -->

Secondly, the created polaron must dissociate from the dopant counterion, i.e., move sufficiently far away to be considered a free charge carrier. The dissociation efficiency can be defined _via_ the number of free carriers 𝑁𝑓𝑟𝑒𝑒 per total number of polarons: 



<!-- Start of picture text -->
𝑁𝑓𝑟𝑒𝑒<br>𝜂𝑑𝑖𝑠𝑠𝑜𝑐𝑖𝑎𝑡𝑖𝑜𝑛 =<br>𝑁𝑝𝑜𝑙𝑎𝑟𝑜𝑛 (3)<br><!-- End of picture text -->

The doping efficiency is then given by the product of the ionization and dissociation efficiency: 



<!-- Start of picture text -->
𝜂𝑑𝑜𝑝𝑖𝑛𝑔 = 𝜂𝑖𝑜𝑛𝑖𝑧𝑎𝑡𝑖𝑜𝑛 × 𝜂𝑑𝑖𝑠𝑠𝑜𝑐𝑖𝑎𝑡𝑖𝑜𝑛 = 𝑁𝑓𝑟𝑒𝑒 (4)<br>𝑁𝑑𝑜𝑝𝑎𝑛𝑡<br><!-- End of picture text -->

The distinction between bound and free charge carriers should not be considered as a static picture. Rather, averaged over a sufficiently long period of time, all polarons contribute to transport. At a given point in time, however, only a fraction of them contribute to charge transport. 

Most dopants generate a maximum of one polaron in the organic semiconductor per dopant, meaning that 𝜂𝑖𝑜𝑛𝑖𝑧𝑎𝑡𝑖𝑜𝑛 ≤ 100%, provided that the dopant/semiconductor pair undergo efficient ICT. If host and dopant form ground state CTCs, the frontier orbitals of the dopant and the host hybridize to form a new set of HOMO and LUMO levels of the complex, with a 

- 23 - 

narrower energy gap than its constituents. The resulting neutral CTC can act as a dopant, provided that the energy levels fulfill the requirements for a subsequent ICT process with surrounding host molecules.<sup>66</sup> The ionization efficiency is, therefore, reduced to significantly less than 100%, due to the additional step involved in this mechanism. Notably, CTC formation and ICT have been observed to occur simultaneously in some materials, for certain polymorphs<sup>93,94</sup> or depending on the doping method,<sup>95</sup> but a full understanding of its formation and effects on doping is yet to be developed.<sup>48,66,93,94</sup> In some cases, a dopant molecule is able to create two polarons in the semiconductor, i.e., 𝜂𝑖𝑜𝑛𝑖𝑧𝑎𝑡𝑖𝑜𝑛 can approach 200%. For p-type doping, this requires that the electron affinity of the dopant anion EA<sup>-</sup> is still higher than the IE of the semiconductor, as was demonstrated for the prototypical electron acceptor F4-TCNQ and a bithiophene–thienothiophene copolymer with tetraethylene glycol side chains [p(g42TTT)].<sup>96</sup> 

If the dopant molecules are not well miscible with the host but phase separate, then the dopant molecules at the center of the resulting aggregates are unlikely to undergo a dopant reaction with the host, which also reduces 𝜂𝑖𝑜𝑛𝑖𝑧𝑎𝑡𝑖𝑜𝑛. Many semiconductor/dopant systems, therefore, first display a rapid increase in 𝑁𝑝𝑜𝑙𝑎𝑟𝑜𝑛 as an increasing amount of dopant is added, implying a high 𝜂𝑖𝑜𝑛𝑖𝑧𝑎𝑡𝑖𝑜𝑛. At higher dopant concentrations, however, 𝑁𝑝𝑜𝑙𝑎𝑟𝑜𝑛 increases less strongly with dopant concentration due to aggregation, and as a result, the electrical properties level out.<sup>97</sup> Most polarons remain within the Coulomb capture radius of their counterion and hence cannot freely move within an electric field. Only once a polaron dissociates from the corresponding counterion and takes up a position that is located sufficiently far away it becomes a free charge carrier. In the case of a low dopant concentration, a polaron can escape the Coulomb capture radius of a counterion with minimal chance of being captured by another counterion, and hence 𝜂𝑑𝑖𝑠𝑠𝑜𝑐𝑖𝑎𝑡𝑖𝑜𝑛 can approach 100%. At intermediate dopant concentrations there are only a few positions within the host/counterion mixture where a polaron would not experience any Coulomb interaction with a counterion, and hence 𝜂𝑑𝑖𝑠𝑠𝑜𝑐𝑖𝑎𝑡𝑖𝑜𝑛 << 100%. At very high doping levels the Coulomb capture radius of counterions starts to overlap, meaning that counterions partially screen each other, and as result, it becomes easier for a polaron to move, which can result in an increase in 𝜂𝑑𝑖𝑠𝑠𝑜𝑐𝑖𝑎𝑡𝑖𝑜𝑛. As an example, at intermediate dopant concentrations for P3HT doped with F4-TCNQ, in host/dopant rations between 5000 and 200, only 5% of the formed polarons were estimated to be mobile.<sup>65</sup> 

Besides the dopant density, its size is also important to determine doping efficiency, since a larger dopant molecule size can help reducing the Coulomb interaction with polarons. 

- 24 - 

To continue with the same example, the distance between a polaron on the P3HT backbone and an F4-TCNQ anion is thought to be about 5-9 Å,<sup>98</sup> but larger dopant molecules, such as molybdenum dithiolene complexes with a diameter of 11-14 Å<sup>99,100</sup> or dodecaborane-based dopants with a diameter of 20 Å,<sup>101</sup> give rise to a larger polaron/counterion distance, and hence polarons are less strongly bound. In fact, for P3HT doped with a dodecaborane-based dopant 𝜂𝑑𝑖𝑠𝑠𝑜𝑐𝑖𝑎𝑡𝑖𝑜𝑛 = 100 % has been reported, i.e., all polarons are mobile charge carriers.<sup>101</sup> 

In contrast, in the high dopant concentration regime, the counterion size will influence the maximum polaron density per unit volume. A small counterion will only occupy little space but a large counterion will occupy a considerable fraction of the available volume. For P3HT, we can estimate a theoretical maximum polaron density of ca. 1  10<sup>21</sup> cm<sup>-3</sup> (assuming that a polaron spreads over four repeat units<sup>102</sup> ) . For larger dopants, such as molybdenum dithiolene complexes or dodecaborane-based dopants as mentioned above, the theoretical maximum polaron density in P3HT reduces to 0.2-0.7×10<sup>21</sup> cm<sup>-3</sup> . Since, however, a larger dopant will improve 𝜂𝑑𝑖𝑠𝑠𝑜𝑐𝑖𝑎𝑡𝑖𝑜𝑛, it can be anticipated that there is an optimal dopant size for which the maximum number of free charge carriers per unit volume can be obtained. 



### **Charge carrier transport in doped semiconductors** 

Highly crystalline organic semiconductors with low density of crystal and interface defects can exhibit coherent band-like transport with charge carrier mobilities that decrease with increasing temperature, similar to crystalline inorganic semiconductors.<sup>103,104</sup> However, most organic semiconductor thin films are not single crystals but feature a complex nano- and microstructure (see Section 3) associated with a high degree of electronic disorder. Hence, under devicerelevant conditions, transport is rate-limited by intermolecular charge transfer between weakly coupled electronic states, _via_ thermally activated hops. Charge carriers are strongly localized due to the molecular reorganization upon charging. Therefore, a charge making a hop is accompanied by local structural distortion as well as polarization of its environment, which is collectively termed a polaron (see Section 2.1.2). 

An important model used to describe hopping transport in molecular solids is Marcus theory, originally proposed to describe oxidation reactions between molecules in solution.<sup>90,105</sup> For a hop to occur, the molecules and their surrounding environment must reorganize, from their initial equilibrium position, through an unstable distorted state, to a final equilibrium position. In the high-temperature limit where vibrational modes can be treated classically, Marcus theory states an electron transfer rate in the weak coupling regime of 

- 25 - 



<!-- Start of picture text -->
Γ𝑖𝑓 =  2𝜋 |𝐽𝑖𝑓| 1<br>ℏ √4𝜋𝜆𝑘𝑇 𝑒𝑥𝑝 ( −(Δ𝐸+ 𝜆) 4𝜆𝑘𝑇 2 ) (5)<br><!-- End of picture text -->

where _J_ if is the intermolecular transfer integral, representing the electronic coupling strength between the states, ∆ _E_ is the energy difference between the final and initials states, and λ is the reorganization energy. 

Considering a linear chain of identical states under a constant applied electric field, Equation (6) yields an expression for the charge carrier mobility 



<!-- Start of picture text -->
𝜇=  |𝐽𝑖𝑓|<br>ℏ √𝜆𝑘𝑇 𝜋 𝑒𝑥𝑝 (  4𝑘𝑇 −𝜆 )  𝑒𝑎 𝑘𝑇 2 (6)<br><!-- End of picture text -->

where _a_ is the hopping distance between intermolecular sites. The mobility _µ_ quantifies how fast a charge moves in response to an electric field _F_ , and is a key parameter for electronic devices, for example, determining the ultimate switching speed in an organic field-effect transistor (OFET) attainable in the absence of any parasitic effects.<sup>106</sup> Using often encountered values of _Jif_ ≈ 0.01 eV, _λ_ ≈ 0.5 eV and _a_ ≈ 10<sup>-9</sup> m in Equation (2), the mobility is around _μ_ ≈ 7.3x10<sup>-3</sup> cm<sup>2</sup> V<sup>-1</sup> s<sup>-1</sup> , which, in general, is far lower than values displayed by many inorganic semiconductors. The mobility shows an Arrhenius-type temperature dependence at devicerelevant temperatures, as the exponential term in Equation (6) dominates. The conductivity of a semiconductor σ can then be calculated as the product of the charge-carrier density _p_ and the mobility _μ,_ 

𝜎= 𝑒𝜇𝑝 (7) 

In contrast to inorganic semiconductors, where charge scattering effects lead to a decrease in conductivity with increasing temperature, the conductivity of organic semiconductors increases exponentially with temperature. This exponential increase is driven by the thermally activated hopping transport, as discussed previously. To show how the conductivity changes as a function of dopant concentration, we multiply the mobile chargecarrier density, as sketched in Figure 7c, by a constant charge-carrier mobility _μ_ ≈ 7.3x10<sup>-3</sup> cm<sup>2</sup> V<sup>-1</sup> s<sup>-1</sup> . We assume a constant mobility here for simplicity, however, scattering effects as the charge-carrier density increases lead to a decrease in mobility as a function of dopant concentration. The mobility then increases again at higher dopant concentrations due to screening/overlap. The product of the charge-carrier density and mobility, Figure 7 demonstrates that through the introduction of dopants, the conductivity can be enhanced over many orders of magnitude. At low dopant concentrations, the increase in conductivity with dopant concentration _cdop_ follows a monomial relationship of the 𝜎∝𝑐𝑑𝑜𝑝𝑦 , with a constant 

- 26 - 

exponent _y_ . At higher dopant concentrations, _y_ reduces as the percentage of ionized dopants decreases and fewer mobile charge carriers are generated. 

Experimental studies on varying dopant concentration usually observe a monomial dependence of the form 𝜎∝𝑐𝑑𝑜𝑝𝑦 , however with 𝑦> 1. This super-linear conductivity increase is attributed to initial changes in mobility with doping concentration as a result of trap-filling,<sup>107</sup> and greater mobile charge-carrier generation when the Coulomb potentials of the ionized dopants overlap, reducing the barrier for IP dissociation.<sup>52,63</sup> Further deviations from the monomial dependence were reported at high dopant concentrations as a consequence of carriercarrier scattering, in addition to carrier-ionized dopant scattering.<sup>108</sup> Saturation or even lowering of  beyond a certain threshold of dopant concentration, typically in the range of 1020 %, is often observed experimentally. In addition to the carrier-carrier scattering, serious disruption of the intrinsic semiconductor's packing and an increased density of grain boundaries (for crystalline materials) result in lowered charge carrier mobility and thus conductivity. So far, only one study on a polymeric semiconductor reported that  decreased at high dopant concentration due to bipolaron formation instead of polarons.<sup>109</sup> Bipolarons are dicationic species and thus have doubly occupied/empty states, which are highly localized and do not effectively contribute to carrier transport. 



### **Electrical contact to doped organic semiconductors** 

The electrical contact between a semiconductor and a conductive electrode can be either nonrectifying (Ohmic) or rectifying (Schottky contact). For most devices, unhindered nonrectifying carrier injection is desirable to minimize Ohmic losses. Figure 8a shows the energy level diagram for a conventional metal-semiconductor material system before contact. In this example, the metal work function _Φm_ , i.e., the energy required to bring an electron from the metal Fermi level to the vacuum level _Evac_ , is lower than the p-doped semiconductor's work function  _s_ . The work function is always the energy difference between _E_ F and _E_ vac; for the metal, it is identical to its IE, and for the semiconductor, it is determined by the doping level. Upon contact (Figure 8b), holes transferred from the semiconductor to the metal side, create a depletion region and charge injection barrier on the semiconductor side of the interface. The barrier height _Φb_ as seen by the majority carriers, holes in this example, moving from the metal to the semiconductor is given by Φ𝑏 = IE −Φ𝑚. The barrier seen by carriers moving from the semiconductor-side to towards the metal, is called the junction potential or built-in voltage _Vbi_ , and is given by 𝑉𝑏𝑖 = Φ𝑠 −Φ𝑚. The junction potential drives an exodus of mobile charge 

- 27 - 

carriers from a region on the semiconductor side of the interface. Assuming this region contains only charges generated by immobile ionized dopants 𝑁𝑑𝑜𝑝𝑎𝑛𝑡− , and has an abrupt end, the depletion region width _w_ is derived from Poisson’s equation and is given by 



<!-- Start of picture text -->
2𝜖(𝑉𝑏𝑖 −𝑉)<br>𝑞𝑁𝑑𝑜𝑝𝑎𝑛𝑡− (8)<br>𝑤(𝑉) =  √<br><!-- End of picture text -->

The above equation is valid for applied voltages below the built-in voltage 𝑉< 𝑉𝑏𝑖 . This equation highlights two practical ways of avoiding rectifying contacts at metal-semiconductor interfaces; firstly, by matching the metal work function with the organic semiconductor’s IE to minimize _V_ bi, secondly, through an increase in dopant concentration. 



<!-- Start of picture text -->
a b<br><!-- End of picture text -->

Figure 8: Schematic energy level diagram before and after contact at a metal-semiconductor interface. (a) Schematic before contact showing a metal with work function Φ _m_ and semiconductor with _Ef_ at different potentials. (b) In equilibrium after contact, the metal work function and semiconductor Fermi level equilibrate, creating a barrier for majority carriers from the metal side of Φ _b_ and a barrier from the semiconductor side of _Vbi_ . 

The depletion region present between the metal and the semiconductor can be made narrower by doping of the semiconductor and/or the interface. This method is applicable in traditional semiconductors as well as organics, although major differences do exist. In the case of OSCs, for instance, the depletion region changes from hundreds of nanometers for undoped α-NPD to about 10 nm when p-doped with F6-TCNNQ.<sup>110</sup> For undoped or lightly doped samples, the depletion region can extend far into the semiconducting layer. For example, the depletion width in fullerenes, 𝐶60, deposited on gold, silver or copper, extends around 500 nm into the semiconductor.<sup>111</sup> If the film thickness is lower than the depletion region width, the Fermi level position will not be representative of its position in the bulk of the semiconductor far away from the contact. Rather, the Fermi level position varies with film thickness. In turn, a measurement of the depletion region width can give a good estimate of the density of mobile charge carriers, and with knowledge of _Ndopant_ , the doping efficiency in a given doped organic 

- 28 - 

films.<sup>112</sup> Complications arise if the semiconductor contains states within its energy gap, which in real materials is practically unavoidable. Charges moving from the metal accumulate in the gap states, shielding the bulk semiconductor from the metal interface. Thus, the Fermi level pins to the energy position of the gap states, and is independent of the metal work function. For organic semiconductors, Fermi level pinning arises as a consequence of chemical impurities but also from structural imperfections.<sup>113</sup> 

### **2.2. Atomistic Computational Studies** 

Doping of OSC is a complex task whose understanding and optimization should take into account many different mechanisms and factors. In this section we focus on how theoretical and computational studies, especially so-called atomistic studies, can elucidate key details and processes of doping and, by doing that, explain available experimental data or even guide materials synthesis and device engineering to novel doping routes. As discussed in the following, these studies can probe a wide range of aspects underlying the physics and chemistry of dopants and dopant-host systems. Examples include, but are not limited to, the energies of frontier orbitals, interactions between hosts and dopants or between dopants and solvents, dopant-induced changes in the microstructure of OSCs, and the effects of dopants on the optical, electronic, magnetic, or vibrational properties of a given sample. 

The main approaches in atomistic studies can be categorized into three groups: 

- 1) Quantum mechanical (QM) calculations which typically take into account in some approximate form the electronic many-body exchange-correlation (xc) effects 

- 2) Classical Molecular Dynamics (MD) simulations which integrate the classical equations of motions for atoms/ions 

- 3) Monte Carlo (MC) simulations 

Given that these approaches probe different time and length scales (up to a few hundreds of atoms for QM calculations, thousands or even more atoms for MD and MC simulations), they are really complementary to each other. In fact, the comprehensive description of doping in OSCs requires ideally the combination of such different methods because it includes inherently multi-scale phenomena, such as the embedding of dopants in a large-scale host environment, the long-range transport of carriers in OSCs, and their release or scattering off dopant impurities. 

The most common method in QM studies is Density Functional Theory (DFT) wherein many body effects are described through a so-called xc-functional. DFT and other electronic structure methods with post- or beyond-DFT corrections have become, through systematic 

- 29 - 

advances, a very useful and robust tool for the investigation of materials properties. However, it should be noted that certain calculated properties relevant to doping in OSCs often have a strong dependence on parameters of DFT studies, the most important of which are the xcfunctional and the type of orbital basis used to describe the electronic wavefunctions. Likewise, the quality of MD simulations is largely controlled by the type of force-field parameters that represent the inter-atomic potentials. With these cautionary remarks in mind, the importance of atomistic studies in the modelling of novel dopants will certainly continue to grow as more powerful computer infrastructures and improved algorithms will make it possible to tackle phenomena which up to now have been intractable in practice. In addition, the identification of novel dopants with optimal performance in OSCs will take advantage of the wider use of computational screening with high-throughput calculations and machine-learning techniques. In the next sections we present representative examples of achievements, challenges and opportunities in the modelling of OSC doping. The selection of these examples is not meant to be exhaustive and puts emphasis on relatively recent studies. For a more complete presentation of earlier pertinent works the reader can refer to previous review articles<sup>48–50,114</sup> about doping of OSCs. 



### **Integer Charge Transfer and Charge Transfer Complexes** 

As we discussed earlier, in the simplest point of view, an extrinsic species can dope a host OSC with holes (electrons) if the LUMO (HOMO) of the former lies lower (higher) than the HOMO (LUMO) of the latter. In this case, electrons can hop from the dopant to a proximal OSC unit or vice versa, through ICT.  Hence, the calculation of the energies of frontier orbitals is normally the first and rather straightforward step in assessing the suitability of a particular dopant vis-a-vis a certain OSC. It should be noted, however, that DFT results for HOMO and LUMO energies can show large variations<sup>115</sup> depending on the choice for the xc-functional and the orbital basis. For the “Becke, 3-parameter, Lee–Yang–Parr” (B3LYP)<sup>116,117</sup> xc-functional (one of the most popular xc-functionals), DFT HOMO energies tend to come up within a few tenths<sup>118</sup> of an electron-volt from experimental values, especially for a large enough orbital basis. LUMO DFT-B3LYP energies, on the other hand, typically turn up higher than experimental values.<sup>118</sup> However, when comparison is made to experimental LUMO values which are obtained by adding the optical gap to the HOMO energy, then the gap should be calculated with, e.g. Time-Dependent DFT (TDDFT). 

- 30 - 

Energies of frontier orbitals also have an intrinsic dependence on the interactions of dopants with their surrounding medium, namely the host OSC and possibly solvent molecules. At first approximation, these interactions can be taken into account through continuous polarizable or solvation models. With the availability of more computational power, however, explicit inclusion of the nearest neighbors becomes an option as well. Using this type of an approach, many-body GW studies<sup>85</sup> found that the electron affinity of p-type dopants (F4TCNQ, F6-TCNNQ and hexacyaotrimethylene‐cyclopropane (CN6-CP)) can shift lower by up to 1 eV when host-dopant interactions are part of the calculation. Such shifts are significant as they can alter completely the theoretical assessment with regard to the efficiency of a particular dopant. In addition, to decide whether a dopant molecule is capable of donating (or accepting) an electron to a proximal OSC unit and form a charge transfer complex (CTC) with the latter, the energy balance should include<sup>119</sup> the attractive interaction between the opposite charges of the CTC. In other words, even if the calculated HOMO or LUMO of a dopant molecule in the gas phase does not support the ICT scenario at first, the final verdict on the possibility of doping may change when environmental and excitonic effects are taken properly into account. 

In most cases, dopant-host interactions have a purely non-bonding van der Waals and electrostatic character. There are, however, instances with non-negligible hybridization between the frontier orbitals of a dopant-host pair. The end result of this inter-molecular hybridization is the partial (i.e. non-integer) transfer of charge between the moieties of the complex. DFT studies<sup>120</sup> can access this scenario through the calculation of intermolecular binding energies (e.g. 0.87-0.94 eV for a F4-TCNQ-Pentacene CTC), visualization of frontier orbitals and careful population analysis. Moreover, calculated reduced energy differences between the host-dopant hybrid HOMO-LUMO orbitals can account<sup>66</sup> for the sub-gap absorptions in UV/Visible/Near Infrared (UV-vis-NIR) spectroscopy. 

More generally, a comparison between DFT-based and experimental UV-vis-NIR absorption spectra can clarify the degree of hybridization and of charge transfer since in the calculations one can adjust the charged state of dopants to ad hoc levels. In this way, DFT studies can give clear evidence<sup>121</sup> whether the doping mechanism in a particular case pertains to ICT with the presence of fully ionized dopants, or to the formation of CTCs with partial ionization. Furthermore, calculated frequencies for vibrational modes of dopants and their intensities in corresponding Infrared (IR) spectra show, respectively, distinct shifts and changes based on the level of ionization. For example, the calculated frequencies<sup>121</sup> of the cyano group of the F6-TCNNQ dopant differ by 37-47 cm<sup>-1</sup> between its neutral and anion forms, with the latter also having stronger IR intensities. Red shifts of the same order of magnitude were 

- 31 - 

obtained also when the F6-TCNNQ dopant was simulated<sup>121</sup> in a complex with fragments of diketopyrrolopyrrole-based host polymers (DPP-TT-DPP and TT-DPP-TT). 

Interestingly, DFT studies have found<sup>121,122</sup> that the degree of charge transfer depends also on the relative position of a dopant with respect to a host polymer chain. In particular, when an F4-TCNQ dopant was stabilized<sup>122</sup> in a co-facial geometrical arrangement with the CPDT donor (D) moiety of the PCPDTBT co-polymer, DFT-based population analysis obtained an almost complete (0.93 e) charge transfer between the dopant and the polymer. Conversely, almost zero charge transfer was obtained when the dopant relaxed next to a BT acceptor (A) segment of the co-polymer. Similar results have been found by the DFT study<sup>121</sup> about the F6-TCNNQ and the DPP-TT-DPP co-polymer with D-A alternation. These findings bear directly on the key issue of doping efficiency, as they reveal that the ionization of dopants may be suppressed by undesired host-dopant complex structures. 

On the other hand, structural atomistic studies, based either on DFT or MD simulations, can probe conditions that enhance the efficiency of doping, e.g. by limiting dopant segregation. In this regard, coarse-grained molecular dynamics simulations<sup>97</sup> found that the replacement of apolar side alkyl chains in the D-A co-polymer P(NDI2OD-T2) (cf. chemical structure in Figure 1) with polar glycol-type groups enhanced the molecular dispersion of N-DMBI dopants (by trapping them between the side chains). Concomitantly, the tendency for clustering of dopants diminished and doping efficiency increased considerably. 

Other key processes which should be a part of a comprehensive study of OSC doping and which could be examined in detail with atomistic studies are the chemical stability of dopants against degradation reactions, e.g., with oxygen or water, and dopant diffusion. Based on the above, the migration of dopants to different sites may switch on and off the degree of its ionization depending on the local environment,<sup>122</sup> while it can also lead to segregation or trapping at interfaces. Dopant clustering has also been indirectly probed in a recent study<sup>123</sup> with combined electron paramagnetic resonance (EPR) measurements and DFT calculations. In particular, pairs of F6-TCNNQ dopants within a zinc phthalocyanine host were found to couple antiferromagnetically when placed at certain positions with respect to each other. In this way, the detection of spin adds another tool in the investigation of doping mechanisms. 

The identification of stable charge transfer complexes can be the starting point for the study of their dissociation and the release of mobile carriers to the host OSC. To this extent, experiments can provide<sup>63</sup> valuable information on the binding energy of electrons and holes in the CTC. This quantity can, in principle, also be calculated with DFT, or in a mixed DFT/Molecular Mechanics scheme.<sup>119</sup> Analogous studies have been performed in the past, e.g., 

- 32 - 

for the dissociation of charge transfer states between donors and acceptors in organic photovoltaic blends.<sup>124</sup> In the case of dopants, CTC dissociation efficiency has been shown with kinetic Monte Carlo<sup>96</sup> simulations to be sensitive also to the energetic disorder of states which are available for the release of carriers. 



**Hydride Transfer, Anion Doping and Lewis Acids** 

We now shift our attention to a broad class of dopants whose doping mechanisms cannot be accounted for (partly or fully) by the charge transfer process we discussed in the previous section. A prototypical member of this class is N-DMBI-H, an air-stable n-type dopant. The most widely held view<sup>77,125</sup> for this and other similar molecules is that they do not function as dopants via direct charge exchange with their hosts (although opposing evidence has been presented<sup>125</sup> as well up until recently). Indeed, DFT values<sup>126</sup> for the HOMO of  N-DMBI-H (- 4.44 eV) are lower than the LUMO energies of n-type OSCs, e.g. [6,6]-Phenyl C61 butyric acid methyl ester (PCBM, cf. chemical structure in Figure 1). On the other hand, if the hydrogen atom is removed from N-DMBI-H, then the calculated<sup>126</sup> energy of the singly Occupied Molecular Orbital (SOMO) of the remaining N-DMBI species is so high (-2.23 eV) so that it readily loses its highest lying electron. 

In effect, the ionization of N-DMBI-H happens concurrently with the transfer of a hydride (H<sup>-</sup> ) anion to an adjacent molecule or polymer fragment, producing thus a radical host anion. The kinetics of this reaction is controlled by the corresponding energy barrier, which for the aromatic A-DCV-DPPTT (quinoid Q-DCM-DPPTT) n-type OSC is calculated<sup>78</sup> to be 26.3 kcal mol<sup>-1</sup> (18.8 kcal mol<sup>-1</sup> ).  Hence, this hydride transfer is a thermally activated process which requires annealing to moderately elevated temperatures, especially for A-DCV-DPPTT. The product of the reaction is a charge-transfer complex. Further DFT studies could probe the dissociation of this CTC, as well as obtain the quantitative details (reaction energy and barrier, binding energy of CTC) for other host-dopant systems for which hydride transfer has been suggested as the actual doping mechanism. 

A mechanism akin to hydride transfer has been proposed for the so-called anion doping of organic semiconductors. A typical example of this case relates to doping of fullerenes,<sup>84</sup> polymers,<sup>127</sup> or non-fullerene acceptors<sup>125</sup> by tetrabutylammonium fluoride (TBAF). Although the mechanism of anion doping has been the subject of some debate (see section 2.1.2.3), in these examples, results from electron spin resonance, UV-vis-NIR absorption and ultraviolet spectroscopy suggest nucleophilic addition of the fluoride (F<sup>-</sup> ) anion of TBAF to C60 and 

- 33 - 

PCBM<sup>84</sup> or to the ClBDPPV<sup>127</sup> polymer. The resulting adduct is then proposed to undergo an electron transfer to neighboring fullerene molecules or polymer fragments resulting in the formation of neutral and charged radicals. Just like for the hydride transfer discussed above, the theoretical corroboration of the fluoride and, in general, anion transfer requires further careful computational analysis. For example, DFT calculations can, in principle, attempt to provide an unambiguous match between the proposed intermediate structures with specific features in the UV-vis spectra. Moreover, they can probe possible reaction pathways for the dissociation of certain radical products, a final step which is needed so that the whole process becomes exergonic. Preliminary results of a recent DFT study<sup>128</sup> for doping of a NDI copolymer (P-90) by TBAF are consistent with the two-step process of fluoride addition to the polymer and subsequent release of an electron carrier. 

In recent years there is a resurgent interest in the use of Lewis acids (organic or inorganic) as molecular dopants of organic semiconductors. The versatile chemistry of these compounds has already been demonstrated in applications such as organic photovoltaics and transistors.<sup>17,21,80,129</sup> The corresponding doping mechanism, however, remains under debate. For example, widely different scenarios have been reported for BCF, one of the most interesting members of this class at present. First, DFT and experimental LUMO energies for BCF seem<sup>21</sup> to preclude the case of p-doping through ICT, although we should mention that widely different values have been reported and more calculations and measurements are needed for this key quantity. A similar situation holds<sup>17</sup> (i.e. high LUMO energies are not compatible with ICT) for the Lewis acid acceptor bis(pentafluorophenyl)zinc (ZnCF) which has been shown to boost hole mobilities of organic transistors above 20 cm2 V-1 s-1. 

Another possibility is that Lewis acids affect the properties of an OSC by reacting with any Lewis basic sites of the latter. Indeed, DFT studies have shown that it is energetically favorable for BCF to form adducts in several cases, e.g. with diF-TESADT,  Tips-Pentacene (cf. chemical structure in Figure 1), and the C16IDT-BT<sup>21</sup> and the PFPT<sup>130</sup> polymers. Likewise, ZnCF has been shown<sup>17</sup> to form adducts with C16IDT-BT and stretched bonds with the C8BTBT small molecule (cf. chemical structure in Figure 1). These reactions change the energies of the frontier orbitals, albeit the calculated hybrid LUMOs are still not low enough to warrant a charge transfer effect. Nevertheless, experiments<sup>17,21,128</sup> have provided evidence that Lewis acids may affect the electronic properties of OSCs and improve thus the performance of pertinent devices not through direct electronic doping, but by changing the micro- or nanostructure of host polymers and small molecules. One way to do that is to induce<sup>130</sup> electric dipoles on the acceptor moieties of a blend. Although the functioning of Lewis acids as 

- 34 - 

structure modifiers is a plausible idea that could indeed explain several experimental observations, it has not attracted up to now focused and systematic computational investigations. In this respect, Molecular Dynamics (MD) simulations, either as a standalone study, or in combination with DFT calculations in a multi-scale scheme, can shed light to this key issue of how molecular dopants affect the local or long-range structure of embedding organic semiconductors. 

While molecules such as BCF or ZnCF form readily adducts with certain molecules or polymers, their relatively bulky structure precludes this scenario in other cases. Nonetheless, even without direct binding to a host, they can form so-called frustrated Lewis pairs which are known to be sites of increased catalytic activity. Moreover, these and other Lewis acids are known to form stable complexes with ambient molecules, namely O2 and H2O molecules. For example, DFT calculations found<sup>17</sup> that a ZnCF molecule can bind an O2 molecule and that the LUMO of the ZnCF-O2 complex is low enough (-4.78 eV) that could possibly lead to doping through charge transfer. On the other hand, the ability of BCF to capture an H2O molecule has been shown in a combined experimental and DFT study<sup>81</sup> to serve as the first step towards carrier doping of the PCPDTBT polymer. In particular, it was shown that the BCF-H2O group can donate a proton to the polymer backbone, while the complex is transformed to a BCF-OH anion. DFT-calculated<sup>1</sup> H NMR spectra are in very good agreement with experimental data (as shown in Figure 9) and confirm thus that a proton has been transferred to the PCPDTBT polymer. The protonated site may then release a hole to the same or neighboring polymer chains. Overall, these findings put forward an additional BCF-induced doping mechanism which is consistent with prior knowledge on the catalytic efficiency of Lewis acids. 



<!-- Start of picture text -->
CPDT+BCF<br>CPDT-H +<br>CPDT<br>BCF•H20<br>1H Chemical Shift (ppm)<br><!-- End of picture text -->

Figure 9: Comparison of DFT and experimental 1H NMR spectra for a fragment of a PCPDTBT polymer without (left) and with (right) a transferred proton (yellow-green site). Reprinted with permission from ref<sup>81</sup> . Copyright 2019 Springer Nature. 

- 35 - 

### **2.3. Dopant Materials** 

A wide variety of chemical species has been used as additives to dope organic semiconductors. This section provides a discussion on the chemical design and properties of the most significant examples, through the classification of different species by structural and mechanistic features. Those dopant classes which have already been extensively covered in previous review papers are briefly discussed in Sections 2.3.1 and 2.3.2 for context, followed by a more thorough description of doping and design strategies that have emerged over the past few years.<sup>26,49,50,114,131</sup> The effects and mechanisms of selected dopants in the context of devices are discussed in more depth in Section 4. 



### **Inorganic species** 

Some of the earliest examples of doping of organic semiconductors relied on diatomic halogen species for the doping of polyacetylene.<sup>132</sup> In particular, diatomic iodine has been used for p- doping of a variety of organic semiconductors, including pentacene and different phthalocyanines.<sup>133–136</sup> Similarly, molecular oxygen can also lead to unintentional p-doping of organic semiconductors with low IE, such as polythiophenes.<sup>137–141</sup> However, oxygen typically acts as a source of electron traps, instead of improving electronic properties.<sup>142,143</sup> Metal oxides, such as MoO3 and WO3, have also been used for p-doping of a range of organic semiconductors, especially owing to the possibility to p-dope materials with high IE.<sup>144,145</sup> The limitations in the employment of these materials are related to the typically high temperatures of deposition, their tendency to form aggregates, and their instability. Inorganic salts – particularly oxidizing Lewis acids, such as FeCl3, AsCl5, or SbCl5 – have also been shown to be efficient p-dopants.<sup>146–149</sup> However, they exhibit high reactivity, sensitivity to moisture, and the formation of side-products (such as HCl). Most Bronsted acids have also been used as p- dopants, particularly for polyanilines and polypyrroles.<sup>49</sup> Nitrosonium salts, e.g. NOBF4, are another notable class of dopants that have also been used recently to achieve record-high conductivity, with their effectiveness partly driven by the reduction of nitrosonium to form gaseous nitric oxide.<sup>150–153</sup> For n-doping, alkali metals such as Li, Na, K, and Cs, have been applied, with the drawbacks of high chemical reactivity, and interdiffusion through organic layers owing to their small size.<sup>154–156</sup> Salts of alkali metals, particularly oxysalts, have also proven useful for n-doping.<sup>157–160</sup> 



### **Molecular dopants** 

- 36 - 

Various molecular dopants have frequently been the preferred choice over earlier alternatives such as alkali metals and elemental halogens. This owes primarily to their processing versatility as well as being less prone to diffusion within the doped organic layer, which has often been found to be a contributing factor to device performance degradation. Furthermore, the structure of molecular dopants can be readily modified for tuning of specific properties using relatively simple chemistry. Although the design of molecular dopants varies dramatically, they typically have in common that they promote efficient charge transfer between the dopant and the host semiconductor via the various mechanisms discussed earlier. As already mentioned, a prerequisite for that is that the frontier orbital energy levels of the dopant are at an appropriate level in relation to the host semiconductor (see section 2.1). Furthermore, a good dopant should ideally have good stability, be readily processable, and be compatible with the host material for efficient charge transfer without detrimental effects on other important properties, such as the ensuing layer morphology. 



### **TCNQ derivatives** 

The most commonly applied p-type molecular dopant is F4-TCNQ and its derivatives (Figure 10).<sup>54,161,162</sup> F4-TCNQ is a volatile compound, which may lead to adverse effects such as uncontrolled dedoping– although the very same property has also been leveraged to control the doping level.<sup>163,164</sup> Extending the aromatic core (larger molecule) can reduce this volatility; for example, the naphthalene derivative F6-TCNNQ has increased molecular weight, resulting in improved vacuum deposition control and reduced molecular diffusion.<sup>165</sup> Attempts to further reduce volatility by substitution of one fluorine of F4-TCNQ with a bulky adamantanyl propyl chain led to a material which degraded before high vacuum sublimation.<sup>166</sup> However, the bulky group did facilitate solution processing. Moulé and co-workers further investigated solution processability by substituting one or two of the nitrile groups of F4-TCNQ with alkyl esters. Significantly enhanced solubility was achieved, albeit with a slight upshift in the LUMO level.<sup>167</sup> The volatility of F4-TCNQ was also lowered, along with the LUMO energy level, by substitution of two of the fluorine substituents with nitrile groups.<sup>168</sup> 

- 37 - 













Figure 10: Structures of TCNQ-based molecular dopants. 



### **Fullerene dopants** 

Fluorination has also been applied to fullerene-based p-dopants C60F36 and C60F48, significantly lowering the LUMO compared to C60.<sup>169,170</sup> C60F36 was shown to have a doping efficiency similar to that of F4-TCNQ – with the additional advantage of lower volatility and higher deposition control – whilst C60F48 have even stronger doping capabilities, doping materials with IE as high as 5.85 eV, as a result of the lower LUMO, and consequently a higher host/dopant energy offset.<sup>171,172</sup> Recently, a 1 mol% addition of C60F48 resulted in a 3-fold hole mobility improvement of a C8-BTBT:C16-IDT-BT blend, reaching charge carrier mobility values of 13 cm<sup>2</sup> V<sup>-1</sup> s<sup>-1</sup> .<sup>15</sup> The bulky structure of fullerene derived dopants further provides an advantage of lesser diffusivity, and devices doped with fluorinated fullerenes have exhibited improved thermal and morphological stability.<sup>15,171,173</sup> 



### **Sulfur containing dopants and cationic dyes** 

The design of suitable molecular n-type dopants has typically been more challenging, as the high-lying HOMO required for efficient doping results in high reactivity and instability in air. However, the major shortcomings of alkali metals as dopant species has prompted the search for molecular alternatives. In the early stages, molecules with relatively low-lying HOMOs, and therefore less efficient doping, were used, such as TTN, BEDT-TTF, and BTQBT.<sup>174–176</sup> A range of cationic dyes, either directly or via corresponding hydride precursors, were also trialed with some success (Figure 11).<sup>177–179</sup> Here the active dopant species is formed _in situ_ during thermal evaporation. Lately, a couple of examples have emerged of dyes also being 

- 38 - 

used for p-doping, particularly with respect to conductivity improvement of polypyrrole through morphology guidance.<sup>180–186</sup> 



Figure 11: Structures of early n-type molecular dopants. 



### **DMBI derivatives** 

One of the most commonly adapted designs for n-type molecular dopants derives from the DMBI molecule (Figure 12a). N-DMBI was first reported as a solution-processable, air-stable dopant for PCBM, with doping occurring via a thermally activated process involving hydride transfer.<sup>187</sup> The exact mechanism of this activation process has prompted much investigation as discussed in Section 2.2.2.<sup>78,187–189</sup> In brief, kinetic studies of the reaction between N-DMBI and PCBM suggest a hydride-transfer reaction to the fullerene, followed by electron transfer between the hydride-reduced PCBM and a neutral PCBM (Figure 12b).<sup>188</sup> Similar hydridetransfer pathways for the doping of other acceptor materials have also been proposed.<sup>78,189</sup> Although N-DMBI remains the most commonly employed molecular n-dopant, a multitude of related species has been synthesized in order to introduce or control various features of the dopant. Such species include halide salts and methoxy, alcohol, diphenylaniline substituted species, and dialkylaniline.<sup>190–196</sup> Glycol substituents have also been used to improve the dopant miscibility with glycol-containing fullerene-based semiconductors for thermoelectric applications.<sup>197</sup> 

- 39 - 

Fabiano and co-workers carried out a thorough study to investigate the correlation between the SOMO energy level of the active radical species and its doping efficiency.<sup>198</sup> By adding electron donating methyl and/or dimethylamine substituents to different positions of the DMBI core, they were able to finely tune the SOMO energy level. Subsequently, they were able to show a gradual increase in conductivity of a doped poly{[N,N’-bis(2-octyldodecyl)naphthalene-1,4,5,8-bis(dicarboximide)-2,6-diyl]-alt-5,5’-(2,2’-bithiophene)} (P(NDI2ODT2)) polymer as a result of the higher-lying SOMO energy of the dopant. They were able to increase the conductivity by an order of magnitude through a SOMO shift as small as 0.3 eV. One drawback of hydride precursors is the hydride transfer to the host semiconductor, potentially resulting in unwanted side-effects. To circumvent this issue, Marder, Bao and coworkers synthesized a set of air-stable DMBI dimers, in which two DMBI derivatives were directly linked to at the 2-position, inspired by the success of metallocene dimers as discussed below.<sup>199</sup> Like the hydride precursor, the reasonably air-stable dimers (stable over the course of several days or weeks) are thermally activated, and doping can proceed via two competing mechanisms: either via a rate limiting dimer cleavage, followed by electron transfer from each resulting radical species to the host semiconductor, or via a rate limiting electron transfer from the dimer to the host, followed by a bond cleavage, generating one ionic and one radical monomer species, prompting a second electron transfer of the radical species (Figure 12c).<sup>200</sup> An additional advantage of dimerized dopants is their suitability for both solution and vacuum processing. Additional modifications to the dimerized DMBI precursor have also been presented: Zhu and co-workers demonstrated how an introduction of methyl substituents to the DMBI core could improve the power factor of thermoelectric devices by raising the HOMO, compared to the reference DMBI dimer, and Pei and co-workers demonstrated a higher dopant efficiency of dimerized (N-DMBI)2 compared to N-DMBI.<sup>201,202</sup> It is notable also that doping with (N-DMBI)2 resulted in lesser impact on host morphology compared to doping with (RuCp*mes)2 (discussed below), due to its planar and less bulky structure.<sup>202</sup> 

- 40 - 

