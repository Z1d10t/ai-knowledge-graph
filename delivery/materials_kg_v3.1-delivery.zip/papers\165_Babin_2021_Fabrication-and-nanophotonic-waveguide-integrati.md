# Fabrication and nanophotonic waveguide integration of silicon carbide colour centres with preserved spin-optical coherence

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Materials |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 178 |
| 作者 | Charles Babin, Rainer J. Stöhr, Naoya Morioka, Tobias Linkewitz, Timo Steidl, R. Wornle, Di Liu, Erik Hesselmeier et al. |
| DOI | 10.1038/s41563-021-01148-3 |
| 源文件 | 065_Babin_2021_Fabrication-and-nanophotonic-waveguide-integrati.pdf |

---
Nanofabricated and integrated colour centres in silicon carbide with high-coherence spin-optical properties 

# Authors: 

Charles Babin<sup>1</sup> , Rainer Stöhr<sup>1</sup> , Naoya Morioka<sup>1,2</sup> , Tobias Linkewitz<sup>1</sup> , Timo Steidl<sup>1</sup> , Raphael Wörnle<sup>1</sup> , Di Liu<sup>1</sup> , Erik Hesselmeier<sup>1</sup> , Vadim Vorobyov<sup>1</sup> , Andrej Denisenko<sup>1</sup> , Mario Hentschel<sup>3</sup> , Christian Gobert<sup>4</sup> , Patrick Berwian<sup>4</sup> , Georgy V. Astakhov<sup>5</sup> , Wolfgang Knolle<sup>6</sup> , Sridhar Majety<sup>7</sup> , Pranta Saha<sup>7</sup> , Marina Radulaski<sup>7</sup> , Nguyen Tien Son<sup>8</sup> , Jawad Ul-Hassan<sup>8</sup> , Florian Kaiser<sup>1,*</sup> , Jörg Wrachtrup<sup>1</sup> 

# Affiliations: 

1 3rd Institute of Physics, IQST, and Research Centre SCoPE, University of Stuttgart, 70569 Stuttgart, Germany 

2 Institute for Chemical Research, Kyoto University, Uji, Kyoto, 611-0011, Japan 

3 4th Institute of Physics, IQST, and Research Centre SCoPE, University of Stuttgart, 70569 Stuttgart, Germany 

- 4 Fraunhofer Institute for Integrated Systems and Device Technology IISB, Schottkystr. 10, 91058 Erlangen, Germany 

5 Helmholtz-Zentrum Dresden-Rossendorf, Institute of Ion Beam Physics and Materials Research, 01328 Dresden, Germany 

6 Department of Sensoric Surfaces and Functional Interfaces, Leibniz-Institute of Surface Engineering (IOM), 04318 Leipzig, Germany 

7 Department of Electrical and Computer Engineering, University of California, Davis, CA 95616, USA 

8 Department of Physics, Chemistry and Biology, Linköping University, SE-58183 Linköping, Sweden 

Corresponding author: 

* f.kaiser@pi3.uni-stuttgart.de 

# Abstract: 

Optically addressable spin defects in silicon carbide (SiC) are an emerging platform for quantum information processing. Lending themselves to modern semiconductor nanofabrication, they promise scalable high-efficiency spin-photon interfaces. We demonstrate here nanoscale fabrication of silicon vacancy centres (VSi) in 4H-SiC without deterioration of their intrinsic spin-optical properties. In particular, we show nearly transform limited photon emission and record spin coherence times for single defects generated via ion implantation and in triangular cross section waveguides. For the latter, we show further controlled operations on nearby nuclear spin qubits, which is crucial for fault-tolerant quantum information distribution based on cavity quantum electrodynamics. 

1 

Introduction: 

Quantum information distribution enables provably secure communication<sup>1</sup> , blind quantum computing<sup>2</sup> and advanced quantum metrology<sup>3</sup> . Large-scale quantum networks can be realised based on a well-orchestrated interplay between stationary and flying multi-qubit systems<sup>4</sup> . In this regard, by addressing atom-like transitions in optically active solid-state spins<sup>5,6</sup> , impressive landmark demonstrations showed multi-node quantum networks<sup>7</sup> , quantum error correction<sup>8</sup> and entanglement distillation<sup>9</sup> . 

To claim system scalability, the field has yet to improve the interaction between colour centres and photons. E.g., the emission of an optical dipole usually covers a solid angle of 4𝜋, and the associated low light collection efficiency results in slow experimental rates<sup>10</sup> , reduced single-shot readout fidelity, and limited quantum protocol complexity. Near-deterministic light-matter interaction is achieved via colour centre integration into monolithic resonators<sup>11–</sup> 13. A challenge remains to preserve spin-optical coherence while granting high-fidelity access to qubit clusters, e.g., nuclear spins. The nitrogen vacancy centres in diamond<sup>14</sup> and divacancy spins in SiC<sup>15</sup> showed excellent control over nuclear spins. However integration into nanophotonics structures proved challenging as spin-optical coherences are degraded by coupling to nearby spins and charge traps, which can be present in the starting material and/or are formed during nanofabrication<sup>13,16–21</sup> . Group-IV defects in diamond show robust symmetry-protected optical coherences<sup>22,23</sup> , but high-fidelity spin manipulation requires millikelvin temperatures at which direct control over nuclear spin clusters becomes challenging<sup>24,25</sup> . 

By contrast, deep-bulk VSi centres in 4H-SiC have shown excellent optical coherences up to 𝑇= 20 K due to wavefunction symmetry protection<sup>26,27</sup> , with millisecond spincoherence times<sup>28</sup> and coherent coupling to nuclear spins<sup>29</sup> . This led to the demonstration of a coherent light-matter interface comprising one electron spin and two photons, suitable for cluster state generation<sup>30</sup> . The single dipole orientation of VSi centres facilitates integration into nanophotonic resonators, however, little is known about spin-optical coherences in such structures. 

Here, we demonstrate that VSi centres retain excellent spin-optical properties after generation via helium (He) ion implantation, which allows for three-dimensional positioning. Compared to previous approaches<sup>31–34</sup> , we use low-energy ions to create shallow VSi centres with a yield of 8%. We show nearly lifetime limited absorption lines and record Hahn echo spin-coherence times. Further, we simulate SiC waveguide designs<sup>35</sup> and create triangular cross-section nanophotonic waveguides via reactive ion etching (RIE). For VSi centres in such waveguides, we report nearly lifetime limited absorption lines without degradation of spin coherences compared to defects in bulk material. Capitalising on those advances, we coherently control nearby nuclear spins with near unity fidelity, which represents a significant step forward towards integrated multi-spin-multi-photon clusters. 

2 

Results: 

We investigate the cubic lattice site silicon vacancy centre (V2) in 4H-SiC, see Fig. 1a. V2 centres are characterised by a zero-phonon line (ZPL) at 917 nm, with a Debye-Waller ! factor (DWF) of 8-9%.<sup>26,36</sup> As shown in Fig. 1b, the system is spin ~~-~~ , in which the sublevels 𝑚# = " $ ! ± and 𝑚# = ± are degenerate Kramers doublets<sup>37</sup> . Optical transitions are spin-conserving, " " resulting in two absorption lines, labelled A1 and A2, respectively<sup>38</sup> . 

As shown in Fig. 1c, we generate arrays of VSi centres via implantation of He<sup>+</sup> ions. They are sent through a polymethyl methacrylate (PMMA) mask with 100 nm diameter holes, lithographed on the a-face of an epitaxially grown SiC sample with a low nitrogen concentration in the [N] = 4 ⋅10<sup>$!</sup> cm<sup>-3</sup> range (for more details, see Methods). Compared to previous work<sup>31–34,39,40</sup> , we choose a low He<sup>+</sup> ion energy of 6 keV to minimise crystal damage. To remove residual lattice damage, we subsequently anneal the sample in argon atmosphere at 600°C for 30 minutes. Fig. 1d shows the room-temperature photoluminescence map of an implanted array using off-resonant excitation at 785 nm. We infer the defect number per spot using autocorrelation measurements and obtain a Poissonian distribution with a mean value of 0.67 ± 0.06 V2 centres per spot. Considering the ion dose of 1 ⋅10<sup>$$</sup> cm<sup>-2</sup> , we determine an implantation yield of 8.5 ± 0.8%, similar to previous work<sup>34</sup> . From the fluorescence map, we infer that the implanted defect centres are laterally distributed with a variance of ±54 nm (one standard deviation), which is mainly determined by the implantation mask hole size. Synopsys Sentaurus Monte Carlo simulations show that V2 centres are created about 30-40 nm beneath the surface without channelling effects (see Supplementary Material). 

Although high-accuracy shallow defect generation is crucial for integration into nanophotonic resonator devices and for quantum sensing applications, it remained unclear whether spin-optical coherences can be maintained after ion implantation<sup>32,34</sup> . For many colour centres, ion implantation and surface proximity leads to strong degradation of spinoptical properties<sup>41–43</sup> . Here, we show that V2 centres do not suffer from those aspects. 

To benchmark the quality of the resonant absorption linewidths, we first measure the excited state lifetime of a single V2 centre at a temperature of 𝑇= 10 K with a 780 nm pspulsed pump laser. The data in Fig. 1e reveals a single-exponential decay with a 1/e-lifetime of 𝜏= 7.08 ± 0.06 ns, similar to previous work<sup>39</sup> . Thus, the lifetime limited absorption linewidth is Δ𝜈= (2 𝜋 𝜏)<sup>($</sup> = 22.5 ± 0.2 MHz. Additional data for proton and silicon ion implantation are given in the Supplementary Material. 

Subsequently, we perform resonant excitation with a tunable diode laser at 917 nm (Toptica DL pro). We provide an additional microwave (MW) drive at 70 MHz to continuously mix the ground states<sup>29</sup> , this way counteracting optical spin-pumping<sup>38</sup> . A typical resonant photoluminescence excitation scan is shown in Fig. 1f. The two absorption lines show the wellknown separation of 1 GHz.<sup>26</sup> The fitted linewidths are Δ𝜈A! = 41 ± 2 MHz and Δ𝜈A" = 24 ± 1 MHz for the A1 and A2 transitions, respectively, which is close to the lifetime limit. A longterm absorption line measurement is shown in Fig. 1g, revealing little drift with no signs of ionisation. Averaging over 125 scans, we find a linewidth of 40 MHz (29 MHz) for the A1 (A2) transition, with a distribution (one standard deviation) of 10 MHz (5 MHz), respectively. Those measurements corroborate the excellent stability of the V2 centre optical lines. We highlight that these results are reproducible for other V2 defects (see Supplementary Material). 

3 

We now proceed to V2 centres in nanofabricated waveguides<sup>44,45</sup> . We focus on triangular cross section waveguides, with which high cooperativity cavities have been realised<sup>46</sup> . Additionally, this geometry is very versatile and can be directly applied to bulk substrates of any polytype, without the need for doping level engineering<sup>13</sup> . In colour centre integration with triangular waveguides, single-mode light propagation is crucial for quantum applications. The relationship between device profile and its supported mode wavelength has been modelled recently<sup>35</sup> . Here, we expand on those findings and simulate light propagation in triangular cross section waveguides with a half-opening angle of 𝛼= 45° (see Supplementary Material). Fig. 2a-b show the fundamental transverse electric (TE) modes that are supported by waveguides with widths of 𝑑= 400 nm and 𝑑= 1000 nm, respectively. Fig. 2c shows the coupling efficiency of light emitted by a centrally located horizontally polarised dipole at 917 nm into the fundamental transverse electric (TE) mode as a function of 𝑑. For 𝑑= 500 nm, we find high light guiding efficiencies up to 82% (41% in each propagation direction). The 𝑑= 1000 nm device still shows a good coupling efficiency of 30% while some of the out-scattered fluorescence can be detected from the top of the waveguide with our collection optics. 

To ensure that the V2 centre dipole is parallel to the top surface of the waveguides and to highlight reproducibility across different SiC crystals, we now use a different epitaxially grown SiC layer. The sample was grown along the a-side with a slightly higher nitrogen concentration, [N] ∼ 3 ⋅10<sup>$*</sup> cm<sup>-3</sup> . Prior to nanofabrication, we create V2 centres throughout the entire sample at a density of 0.4 µm<sup>-3</sup> using electron irradiation at 2 MeV with a dose of 2 kGy (fluence of approximately 5 ⋅10<sup>$$</sup> cm<sup>-2</sup> ). 

To fabricate waveguide devices, we decide against photoelectrochemical etching, which may deteriorate spin-optical properties due to material degradation and porosification<sup>13</sup> . As shown in Fig. 2d, we fabricate triangular cross-section waveguides via a two-stage process based on RIE with SF6 gas. An initial straight etch creates ~2 µm deep trenches. Subsequent angled etching in a 45° Faraday cage results in suspended waveguide structures with a length of 20 µm and widths of 400 nm and 1000 nm, respectively. A scanning electron microscope image of the latter ones is shown in Fig. 2e. 

A typical photoluminescence map with optical excitation and collection from the top of the waveguides is shown in Fig. 2f, revealing multiple bright spots along the waveguides. Emission spectra reveal most of the spots as surface-related or unknown defects (see Supplementary Material). Bright single V2 centres are found in one out of five waveguides with 1000 nm width. Intuitively, this compares low to the average V2 density in the bulk. However, our simulations show that only emitters at the waveguides’ top apices show a sizable emission towards our collection optics. The fluorescence of most emitters is actually guided along the waveguides or out-scattered towards the bottom (see Supplementary Material). In analogy to the measurements on implanted V2 centres, we perform resonant photoluminescence excitation scans. Fig. 2g shows a one-hour long recording, revealing narrow absorption lines with no signs of ionisation. Considering that we primarily investigate defects at the waveguide apices, we assign the remaining slow drift to surface charge fluctuations. 

To demonstrate that the drift is slow enough to perform complex long-term measurements, we stabilise the resonant excitation laser on optical transitions via softwarecontrol<sup>47</sup> (see Supplementary Material). Fig. 2h shows absorption line scans repeated over one hour with the laser feedback activated once per minute and re-centring the scanning window after every scan with respect to the position of the A1 transition. Little to no effective drift is observed<sup>19,41</sup> , which enables long-term measurements. To highlight reproducibility, we show 

4 

the resonant absorption spectra of V2 centres in six different waveguides in Fig. 2i. We find that three out of six V2 centres show nearly lifetime limited absorption lines. The other three still present spin-selective optical transitions. The best defect shows a linewidth of 34 MHz (22 MHz) for the A1 (A2) transition, after averaging over 198 scans. The standard deviation in these measurements is 8 MHz (5 MHz). Unfortunately, we did not identify V2 centres in the 400 nm wide devices. We attribute this to the single-mode operation of the 400 nm waveguides, which suppresses out-scattering towards our collection optics, thus requiring dedicated output couplers<sup>22,48</sup> . 

The next step should combine nanofabrication and localised defect generation, for which multiple strategies exist. E.g., waveguide fabrication around pre-characterized implanted defect arrays, or depositing He<sup>+</sup> ion implantation masks on produced waveguides. For the 45° etched waveguides, both strategies require precise alignment in the range of a few 10 nm. Our simulations indicate a reduced demands on alignment in single-mode devices with a wider opening angle (75° and 900-1000 nm width, see Supplementary Material). Such devices could be created with adapted Faraday cages. Based on the success in the diamond platform<sup>11,46</sup> , we believe that mask-free implantation would be ideal, which can be achieved using a helium Focussed Ion Beam source or a helium ion microscope operated at fluxes of about 10 He<sup>+</sup> ions per spot. 

5 

Having demonstrated implantation and nanofabrication with minimal degradation of the optical properties of V2 centres, we proceed to spin coherence measurements. To maximise spin contrast, we use resonant excitation<sup>29</sup> and take advantage of our softwarecontrolled laser feedback system. Intuitively, we expect that spin properties are less affected than optical properties, however, ion implantation and waveguide nanofabrication can still lead to an increased abundance of parasitic spin defects<sup>13,49</sup> . To allow selective addressing of the three ground state spin transitions via MW drive, we lift the Kramers degeneracy by applying an external magnetic field of 𝐵+ = 36 G along the crystal’s c-axis (see Fig. 3a). We $ then deterministically initialise the spin state<sup>29</sup> , here into 𝑚S = + , followed by probing " $ ! dephasing and coherences between the levels 𝑚S = + and 𝑚S = + . " " Ramsey interferometry shows a dephasing time of 𝑇",implanted∗ = 34 ± 4 𝜇s for the ionimplanted defects (Fig. 3b), comparable to deep-bulk defects in similar SiC crystals<sup>15,29</sup> . Fig. 3c shows the data for V2 centres in waveguides. We find 𝑇",waveguide∗ = 9.4 ± 0.7 𝜇s, which is only twice shorter compared to deep bulk defects in the same sample, 𝑇",bulk∗ = 21 ± 1 𝜇s (see Supplementary Material). 

Hahn echo measurements with ion-implanted V2 centres are presented in Fig. 3d, showing a coherence time of 𝑇",implanted = 1.39 ± 0.10 ms. This is, to our knowledge, the longest-ever reported Hahn-echo coherence for this system. Fig. 3e shows the data for defects in waveguides, resulting in 𝑇",waveguide = 0.84 ± 0.01 ms, which is comparable to bulk defects in the same sample, 𝑇",bulk = 0.85 ± 0.03 ms (see Supplementary Material). Thus, RlE can be used for nanofabrication of high-quality SiC material without deteriorating spin properties. 

Interestingly, the data in Fig. 3e displays a strong modulation due to dipolar interaction with weakly coupled nuclear spins. This indicates that the hyperfine coupling strength with at least one nucleus is comparable to the Larmor frequency. We show now that the system is described by one V2 centre coupled to two nuclear spins, as depicted in the artistic design in Fig. 4a. To infer the coupling strengths with high resolution, we apply a slightly increased magnetic field, 𝐵+ = 81 G and perform 8-pulse Carr-Purcell-Meiboom-Gill (CPMG) sequences with varying waiting time 𝜏CPMG. From the modulation signal in Fig. 4b, we extract that both nuclei are<sup>29</sup> Si spins with hyperfine coefficients of 𝐴∥,$ = 2𝜋⋅(−23.5) kHz and 𝐴C,$ = 2𝜋⋅ 12.0 kHz for the first nuclear spin (N1), as well as 𝐴∥," = 2𝜋⋅0.2 kHz and 𝐴C," = 2𝜋⋅8.5 kHz for the second one (N2, see Supplementary Material). 

Having determined the coupling coefficients, we now show coherent manipulation of an electron-nuclear spin pair in a SiC waveguide. Compared to previous work<sup>15,50,51</sup> , we implement spin control sequences at a low magnetic field (𝐵+ = 81 G). This keeps the hyperfine coupling strength comparable to the nuclear spin Larmor frequency 𝜔D, which allows us to perform nuclear spin quantum gates in short times using a moderate number of CPMG pulses. 

As the V2 centre ground state is a quartet, it directly provides three exploitable spin ! $ $ $ $ ! subspaces (𝑚S = [+ ; + ], 𝑚S = [+ ; − ], and 𝑚S = [− ; − ]) that allow to implement " " " " " " vastly different nuclear spin control sequences. Here, we focus on the subspace 𝑚S = ! $ [+ ; + ] to demonstrate nuclear spin rotations around the 𝑥-axis for the first nuclear spin. " " The strong resonance signal in Fig. 4b at 𝜏CPMG = 5.38 µs already indicates that electron and nuclear spins are flipped. Ensuring precise rotations around the desired 𝑥-axis requires determining the optimal waiting times 𝜏<sup>(F)</sup> (dubbed as resonances), at which the electron spin signal due to the nuclear spin precession is exactly commensurate with the CPMG pulse spacing. To this end, we develop a generalised theoretical model to describe CPMG 

6 

resonances for weakly coupled nuclear spins<sup>50</sup> in small magnetic fields (see Supplementary Material). For each individual nuclear spin, the resonances occur at 



<!-- Start of picture text -->
(F) ⁄  𝜏 F ⁄ · 𝒏 !⁄" )($ −1<br>𝜏approx = 𝜏F S1 + sin  U 𝜔$ 2 " V  (𝒏$ (2𝑘−1) 𝜋 " Z .<br><!-- End of picture text -->

("F($) J Here, the integer number 𝑘 indicates the resonance number, 𝜏F = , 𝜔MS = K!⁄"<sup>LK</sup> $⁄" <u>[(𝑚S 𝐴C)</u><sup>"</sup> + (𝑚S 𝐴∥ − 𝜔D)<sup>"</sup> and 𝜔M& 𝒏MS = 𝑚S 𝐴C𝒆𝒙 + (𝑚S 𝐴∥ −𝜔D)𝒆𝒛. The unit vectors 𝒆𝒙 and 𝒆𝒛 denote the nuclear spin rotation axis. For the first resonance, we calculate ($) 𝜏approx = 5.38 𝜇s, in excellent agreement with the experimental data. We now control the nuclear spin rotation angle by varying the number 𝑁 of CPMG pulses at 𝜏CPMG = 5.38 𝜇s. The uncorrected raw data in Fig. 4c reveals that the electron spin signal is modulated due to electron spin-controlled nuclear spin rotations with near-unity fringe contrast, in excellent accord with the simulated signal with no free parameters (see Supplementary Material). By varying the number of refocusing pulses, we implement relevant quantum gates on the bipartite system. The Bloch spheres in Fig. 4d visualise the electron spin-dependent rotation of the first nucleus N1 for 𝑁= 4 CPMG pulses. The net result is an opposite rotation around the 𝑥-axis, which can be used to implement an entangling Hadamard gate. Fig. 4e shows the rotation of the second nucleus N2. The nuclear spin is decoupled as its rotation is (essentially) independent of the electron spin state. By increasing the number of refocusing pulses, we can rotate N1 to implement additional gates, such as the 𝜎S-gate for 𝑁= 8, and the identity operation for 𝑁= 16. For the three gates (Hadamard, 𝜎S, and identity), our simulations show fidelities of 97%, 94% and 98%, respectively (see Supplementary Material). These high fidelities are in part due to the fast implementation of gates using only a small number of refocusing pulses for which electron spin decoherence is negligible. In this sense, we emphasise that the small signal decrease in Fig. 4c for high pulse numbers (𝑁> 20) is not associated with electron spin decoherence. The signal decrease stems from a minimal remaining spin-dependent rotation of N2, which can be suppressed with stronger external magnetic fields<sup>7,15</sup> . Our results underline that waveguide-integrated V2 centres can be used for controlling nuclear spins with high fidelities at cryogenic temperatures, promising implementation of quantum memories, quantum error correction, and (distributed) quantum computational tasks. 

7 

Conclusion: 

We demonstrated that V2 centres in 4H-SiC can be successfully integrated into nanofabricated waveguide devices produced by RIE techniques. We showed further that lowenergy He<sup>+</sup> implantation creates shallow V2 centres with high yield and good spatial accuracy. Despite using SiC crystals from completely different growth processes, we observed nearly lifetime-limited absorption lines and reported record Hahn echo electron spin coherence times. The fact that ideally oriented V2 centres in novel a-plane 4H-SiC can be used for quantum applications offers a unique potential to further scale up semiconductor quantum technologies<sup>44</sup> . 

To induce these steps, we outlined how to combine ideal photonic waveguide designs and implantation strategies that could be used toward realizing cavity-based spin-photon interfaces with high cooperativities<sup>11</sup> . For maximum coupling efficiency, such devices could be directly connected to optical fibres<sup>52</sup> . 

To interfere multiple emitters, Stark shift tuning<sup>53</sup> could be used for both matching resonance frequencies and shaping optical linewidths<sup>54</sup> . On-chip wavelength conversion to the telecom band could be implemented by utilizing the 𝜒<sup>(")</sup> and 𝜒<sup>(!)</sup> nonlinearities of 4HSiC<sup>55</sup> , ultimately enabling large-scale memory-enhanced quantum repeater networks<sup>46</sup> . 

To scale-up such networks, nuclear spin quantum memories and processors represent a critical technology<sup>4</sup> . In this sense, we demonstrated coherent control over individual nuclear spins, and we implemented relevant quantum gates with high fidelity. The amount of controllable nuclear spins can be directly scaled up in isotopically engineered samples<sup>15</sup> . In this regard, V2 centres are very promising central spins as they can be operated at temperatures up to 𝑇= 20 K before experiencing spin-optical coherence degradation<sup>26</sup> . The high cooling powers of standard cryogenic equipment at those temperatures make it possible to operate experiments at full duty cycle while controlling nuclear spins with high-power radiofrequency drive. 

Overall, these results corroborate that V2 centres in SiC are attractive for developing large-scale quantum networks based on integrated quantum computational clusters with efficient spin-photon interfaces. 

8 

# Data availability 

Source data are provided with this paper and at https://doi.org/10.18419/darus-2107. Any further data are available from the corresponding author upon request. 

# Code availability 

Fits to the data were made using python software. The fit functions, parameters, and simulations of hyperfine interactions can be made available upon request. 

# Acknowledgements: 

C.B., F.K. and J.W. thank Arnold Weible, Rolf Reuter, Annette Zechmeister, Jonas Meinel, Roland Nagy, Jonathan Körber, Marcel Krumrein, Matthew Joliffe, Matthias Niethammer, Izel Gediz, Jonas Zatsch, Durga Dasari, Yu-Chen Chen, Kai-Mei Fu, Daniil Lukin, and Jelena Vučković for experimental assistance and fruitful discussions. We further acknowledge technical support from Swabian Instruments GmbH and Toptica Photonics AG. 

G.V.A. thanks Ulrich Kentsch for the proton implantation assistance and support from the Ion Beam Center at Helmholtz-Zentrum Dresden-Rossendorf (HZDR). 

N.T.S. acknowledges the Swedish Research Council (Grant No. VR 2016-04068). J.U.H. acknowledges the Swedish Energy Agency (Grant No. 43611-1) and Swedish Research Council (Grant No. 2020-05444). 

N.T.S. and J.U.H. thank the EU H2020 project QuanTELCO (Grant No. 862721) and the Knut and Alice Wallenberg Foundation (Grant No. KAW 2018.0071). 

S.M. acknowledges support by the UC Davis Summer GSR Award. 

M.R. acknowledges support by the National Science Foundation under the grant CAREER2047564. 

J.W. acknowledges the EU-FET Flagship on Quantum Technologies through the project ASTERIQS (Grant Agreement No. 820394), the European Research Council (ERC) grant SMel, the Max Planck Society, and the German Research Foundation (SPP 1601, FOR 2724). F.K. and J.W. acknowledge support by the EU-FET Flagship on Quantum Technologies through the project QIA (Grant Agreement No. 820445), as well as the German Federal Ministry of Education and Research (BMBF) for the project Q.Link.X (Grant Agreement No. 16KIS0867). 

# Author contributions: 

C.B., and F.K. conceived the experiments. F.K. and J.W. directed the research. R.S., T.L., R.W. and A.D. produced masks and performed helium ion implantation. C.G. and P.B. performed helium implantation simulations. R.S., T.L., R.W. and G.V.A. produced masks and designed proton implantation. M.H. performed silicon ion implantation. W.K. performed electron irradiation. C.B., R.S. and T.L. produced SiC waveguides. V.V., S.M., P.S. and M.R. simulated beam profiles in waveguides. N.T.S. and J.U.H. grew the SiC samples. C.B., N.M., T.L., T.S., R.W., D.L., E.H. and F.K. performed the experiments. C.B., N.M., T.L., T.S., D.L. and F.K. developed and improved software. C.B., R.W. and F.K. analysed the data. C.B. and F.K. developed the theoretical framework for nuclear spin control. C.B., M.R., F.K. and J.W. wrote the manuscript. All authors provided helpful comments during the writing process. 

9 

# Competing Interests statement: 

## The authors declare no competing interests. 

Methods: 

## **Sample preparation:** 

We use two different samples for the implantation and waveguide experiments. For the implantation experiments, we use a 110 μm thick 4H-<sup>28</sup> Si<sup>12</sup> C silicon carbide layer that was grown by chemical vapour deposition (CVD) on the c-plane of a n-type (0001) 4H-SiC wafer. The isotope purity is estimated to be [<sup>28</sup> Si] > 99.85% and [<sup>12</sup> C] > 99.98%, which was confirmed by secondary ion mass spectroscopy (SIMS) for one of the wafers in the series. After chemical mechanical polishing (CMP) of the top layer, the substrate was removed by mechanical polishing and the final isotopically enriched free-standing layer had a thickness of ~100 μm. Current-voltage measurements at room temperatures show that the layer is n-type with a free carrier concentration of ~6 × 10<sup>13</sup> cm<sup>−3</sup> . This value is close to the concentration of shallow nitrogen donors of ~4 × 10<sup>13</sup> cm<sup>−3</sup> , which was determined by photoluminescence at low temperatures. Deep level transient spectroscopy measurements show that the dominant electron trap in the layer is related to the carbon vacancy with a concentration in the mid 10<sup>12</sup> cm<sup>−3</sup> range. Minority carrier lifetime mapping of the carrier shows a homogeneous carrier lifetime of ~ 0.6 μs. Since the lifetime was measured by an optical method with high injection, the real lifetime is expected to be double, i.e., ~1.2 μs. Such a high minority carrier lifetime indicates that the density of all electron traps should not be more than mid 10<sup>13</sup> cm<sup>−3</sup> . To investigate colour centres from the a-side of the samples, they were cleaved in order to obtain a reasonably smooth surface morphology. Samples were investigated with fluorescence microscopy and no defect centres were found. 

For the waveguide experiments, we used a 28 μm thick 4H-<sup>28</sup> Si<sup>12</sup> C silicon carbide layer that was grown by CVD on an a-plane n-type 4H-SiC wafer. Isotope concentration is estimated to be similar to the above-described c-plane samples. However, we found an increased incorporation of nitrogen donors in the ~3 × 10<sup>15</sup> cm<sup>−3</sup> range, which attributes to slightly increased optical linewidths. The surface roughness of this sample was measured to be below 0.4 nm via an atomic force microscope. Defects in this sample were generated using electron irradiation at 2 MeV with a fluence of 2 kGy. After irradiation, the sample was annealed at a temperature of 600 °C for 30 min to remove some interstitial-related defects. 

## **Spin manipulation:** 

For all spin manipulation experiments, MW is provided through a 50 µm diameter copper wire that is placed within 50-100 µm distance to the investigated colour centres. MW signals are generated using signal generators (Rohde & Schwarz SMIQ03b and SMIQ02b) and subsequent switches (MiniCircuits ZASWA-2-50DRA+). MW signals are combined using MW splitters, followed by a 20 dB amplifier stage. Typical MW power levels at the wire are 15-20 dBm. 

## **He implantation process:** 

To generate defects via He<sup>+</sup> ion implantation, we spin-coated a 200 nm thick 200k-PMMA layer. Electron beam lithography (EBL) was done in Raith Eline apparatus with 20 kV acceleration voltage, 10 μm aperture, and an exposure dose of 270 μC/cm<sup>2</sup> . After exposure, 

10 

the sample was placed in a micro-beam implanter (ion gun) with a He<sup>+</sup> source and a Wien filter. He<sup>+</sup> ions were accelerated at 6 keV and implanted into the sample at a dose of 10<sup>11</sup> ions/cm<sup>2</sup> . After removing the PMMA mask, the sample was annealed at 600 °C for 30 min in argon atmosphere to remove some interstitial-related defects. 

## **RIE process:** 

To create suspended waveguide structures, a double layer PMMA mask (950K and 200K) was patterned using ELB. A 200 nm thick nickel mask was evaporated onto the surface of the sample. The pattern was transferred onto SiC via SF6 plasma etching process (20 sccm, 7.5 mTorr, -20°C, RIE power of 100 W). After completing straight and angled etching processes, mask residuals were removed by immersion into diluted nitric acid (HNO3). Thereafter, the sample was annealed at 600 °C for 30 min in argon atmosphere to remove some interstitialrelated defects. 

## **Photonic modelling:** 

<mark>To model the light propagation in SiC waveguides, we use Finite-Difference Time-Domain simulations in Lumerical software. Colour centres are simulated as horizontally oriented point dipoles at 917 nm, placed inside triangular waveguides with 𝑛 = 2.6 refractive index and mesh size of 20 nm. Mode coupling is monitored for six lowest energy modes supported in the waveguide and coupling efficiencies are evaluated after 10 µm of propagation.</mark> 

11 

References: 

1. Buhrman, H., Cleve, R., Massar, S. & De Wolf, R. Nonlocality and communication complexity. _Rev. Mod. Phys._ **82** , 665–698 (2010). 

2. Barz, S. et al. Demonstration of Blind Quantum Computing. _Science_ **335** , 303–309 (2012). 

3. Gottesman, D., Jennewein, T. & Croke, S. Longer-baseline telescopes using quantum repeaters. _Phys. Rev. Lett._ **109** , 070503 (2012). 

4. Borregaard, J. et al. One-Way Quantum Repeater Based on Near-Deterministic Photon-Emitter Interfaces. _Phys. Rev. X_ **10** , 021071 (2020). 

5. Atatüre, M., Englund, D., Vamivakas, N., Lee, S. Y. & Wrachtrup, J. Material platforms for spin-based photonic quantum technologies. _Nat. Rev. Mater._ **3** , 38–51 (2018). 

6. Awschalom, D. D., Hanson, R., Wrachtrup, J. & Zhou, B. B. Quantum technologies with optically interfaced solid-state spins. _Nat. Photon._ **12** , 516–527 (2018). 

7. Pompili, M. et al. Realization of a multi-node quantum network of remote solid-state qubits. _Science_ **372** , 259–264 (2021). 

8. Waldherr, G. et al. Quantum error correction in a solid-state hybrid spin register. _Nature_ **506** , 204–207 (2014). 

9. Kalb, N. et al. Entanglement distillation between solid-state quantum network nodes. _Science_ **356** , 928–932 (2017). 

10. Rozpȩdek, F. et al. Near-term quantum-repeater experiments with nitrogen-vacancy centers: Overcoming the limitations of direct transmission. _Phys. Rev. A_ **99** , 052330 (2019). 

11. Janitz, E., Bhaskar, M. K. & Childress, L. Cavity quantum electrodynamics with color centers in diamond. _Optica_ **7** , 1232–1252 (2020). 

12. Bracher, D. O., Zhang, X. & Hu, E. L. Selective Purcell enhancement of two closely linked zero-phonon transitions of a silicon carbide color center. _Proc. Natl. Acad. Sci._ **114** , 4060–4065 (2017). 

13. Crook, A. L. et al. Purcell enhancement of a single silicon carbide color center with coherent spin control. _Nano Lett._ **20** , 3427–3434 (2020). 

14. Abobeih, M. H. et al. Atomic-scale imaging of a 27-nuclear-spin cluster using a quantum sensor. _Nature_ **576** , 411–415 (2019). 

15. Bourassa, A. et al. Entanglement and control of single nuclear spins in isotopically engineered silicon carbide. _Nat. Mater._ **19** , 1319–1325 (2020). 

16. Myers, B. A. et al. Probing surface noise with depth-calibrated spins in diamond. _Phys. Rev. Lett._ **113** , 027602 (2014). 

17. Sangtawesin, S. et al. Origins of Diamond Surface Noise Probed by Correlating SingleSpin Measurements with Surface Spectroscopy. _Phys. Rev. X_ **9** , 031052 (2019). 

18. Riedel, D. et al. Deterministic enhancement of coherent photon generation from a nitrogen-vacancy center in ultrapure diamond. _Phys. Rev. X_ **7** , 031040 (2017). 

19. Ruf, M., Weaver, M. J., Van Dam, S. B. & Hanson, R. Resonant Excitation and Purcell Enhancement of Coherent Nitrogen-Vacancy Centers Coupled to a Fabry-Perot Microcavity. _Phys. Rev. Appl._ **15** , 024049 (2021). 

20. Schröder, T. et al. Quantum nanophotonics in diamond [Invited]. _J. Opt. Soc. Am. B_ **33** , B65 (2016). 

21. Chu, Y. et al. Coherent optical transitions in implanted nitrogen vacancy centers. _Nano Lett._ **14** , 1982–1986 (2014). 

22. Burek, M. J. et al. Fiber-coupled diamond quantum nanophotonic interface. _Phys. Rev._ 

12 

_Appl._ **8** , 024026 (2017). 

23. Bradac, C., Gao, W., Forneris, J., Trusheim, M. E. & Aharonovich, I. Quantum nanophotonics with group IV defects in diamond. _Nat. Commun._ **10** , 5625 (2019). 

24. Nguyen, C. T. et al. Quantum Network Nodes Based on Diamond Qubits with an Efficient Nanophotonic Interface. _Phys. Rev. Lett._ **123** , 183602 (2019). 

25. Nguyen, C. T. et al. An integrated nanophotonic quantum register based on siliconvacancy spins in diamond. _Phys. Rev. B_ **100** , 165428 (2019). 

26. Udvarhelyi, P. et al. Vibronic States and Their Effect on the Temperature and Strain Dependence of Silicon-Vacancy Qubits in 4H-Si C. _Phys. Rev. Appl._ **13** , 054017 (2020). 

27. Udvarhelyi, P. et al. Spectrally Stable Defect Qubits with no Inversion Symmetry for Robust Spin-To-Photon Interface. _Phys. Rev. Appl._ **11** , 044022 (2019). 

28. Simin, D. et al. Locking of electron spin coherence above 20 ms in natural silicon carbide. _Phys. Rev. B_ **95** , 161201 (2017). 

29. Nagy, R. et al. High-fidelity spin and optical control of single silicon-vacancy centres in silicon carbide. _Nat. Commun._ **10** , 1954 (2019). 

30. Morioka, N. et al. Spin-controlled generation of indistinguishable and distinguishable photons from silicon vacancy centres in silicon carbide. _Nat. Commun._ **11** , 2516 (2020). 

31. Ohshima, T. et al. Creation of silicon vacancy in silicon carbide by proton beam writing toward quantum sensing applications. _J. Phys. D. Appl. Phys._ **51** , 333002 (2018). 

32. Pavunny, S. P. et al. Arrays of Si vacancies in 4H-SiC produced by focused Li ion beam implantation. _Sci. Rep._ **11** , 3561 (2021). 

33. Chen, Y. C. et al. Laser Writing of Scalable Single Color Centers in Silicon Carbide. _Nano Lett._ **19** , 2377–2383 (2019). 

34. Wang, J. F. et al. On-Demand Generation of Single Silicon Vacancy Defects in Silicon Carbide. _ACS Photonics_ **6** , 1736–1743 (2019). 

35. Majety, S. et al. Quantum photonics in triangular-cross-section nanodevices in silicon carbide. _J. Phys. Photonics_ **3** , 034008 (2021). 

36. Shang, Z. et al. Local vibrational modes of Si vacancy spin qubits in SiC. _Phys. Rev. B_ **101** , 144109 (2020). 

37. Kraus, H. et al. Room-temperature quantum microwave emitters based on spin defects in silicon carbide. _Nat. Phys._ **10** , 157–162 (2014). 

38. Banks, H. B. et al. Resonant Optical Spin Initialization and Readout of Single Silicon Vacancies in 4H - SiC. _Phys. Rev. Appl._ **11** , 024013 (2019). 

39. Fuchs, F. et al. Engineering near-infrared single-photon emitters with optically active spins in ultrapure silicon carbide. _Nat. Commun._ **6** , 7578 (2015). 

40. Evans, R. E., Sipahigil, A., Sukachev, D. D., Zibrov, A. S. & Lukin, M. D. NarrowLinewidth Homogeneous Optical Emitters in Diamond Nanostructures via Silicon Ion Implantation. _Phys. Rev. Appl._ **5** , 044010 (2016). 

41. Ishikawa, T. et al. Optical and spin coherence properties of nitrogen-vacancy centers placed in a 100 nm thick isotopically purified diamond layer. _Nano Lett._ **12** , 2083– 2087 (2012). 

42. Yan, F. F. et al. Room-temperature coherent control of implanted defect spins in silicon carbide. _npj Quantum Inf._ **6** , 38 (2020). 

43. Van Dam, S. B. et al. Optical coherence of diamond nitrogen-vacancy centers formed by ion implantation and annealing. _Phys. Rev. B_ **99** , 161203 (2019). 

44. Lukin, D. M. et al. 4H-silicon-carbide-on-insulator for integrated quantum and nonlinear photonics. _Nat. Photon._ **14** , 330–334 (2020). 

13 

45. Radulaski, M. et al. Scalable Quantum Photonics with Single Color Centers in Silicon Carbide. _Nano Lett._ **17** , 1782–1786 (2017). 

46. Bhaskar, M. K. et al. Experimental demonstration of memory-enhanced quantum communication. _Nature_ **580** , 60–64 (2020). 

47. Hensen, B. et al. Loophole-free Bell inequality violation using electron spins separated by 1.3 kilometres. _Nature_ **526** , 682–686 (2015). 

48. Dory, C. et al. Inverse-designed diamond photonics. _Nat. Commun._ **10** , 3309 (2019). 

49. Rugar, A. E. et al. Narrow-Linewidth Tin-Vacancy Centers in a Diamond Waveguide. _ACS Photonics_ **7** , 2356–2361 (2020). 

50. Taminiau, T. H. et al. Detection and control of individual nuclear spins using a weakly coupled electron spin. _Phys. Rev. Lett._ **109** , 137602 (2012). 

51. Taminiau, T. H., Cramer, J., Van Der Sar, T., Dobrovitski, V. V. & Hanson, R. Universal control and error correction in multi-qubit spin registers in diamond. _Nat. Nanotechnol._ **9** , 171–176 (2014). 

52. Burek, M. J. et al. Fiber-coupled diamond quantum nanophotonic interface. _Phys. Rev. Appl._ **8** , 1–10 (2017). 

53. Rühl, M., Bergmann, L., Krieger, M. & Weber, H. B. Stark Tuning of the Silicon Vacancy in Silicon Carbide. _Nano Lett._ **20** , 658–663 (2020). 

54. Lukin, D. M. et al. Spectrally reconfigurable quantum emitters enabled by optimized fast modulation. _npj Quantum Inf._ **6** , 80 (2020). 

55. Guidry, M. A. et al. Optical parametric oscillation in silicon carbide nanophotonics. _Optica_ **7** , 1139–1142 (2020). 

56. Nagy, R. et al. Narrow inhomogeneous distribution of spin-active emitters in silicon carbide. _Appl. Phys. Lett._ **118** , 044001 (2021). 

14 



<!-- Start of picture text -->
a b c d<br>28Si 3<br>±<br>ES 2<br>12C He<br>1<br>±<br>2<br>PMMA<br>V2 A2<br>A1<br>3<br>GS ± SiC<br>2<br>1<br>±<br>2<br>e f g<br>c-axis<br><!-- End of picture text -->

Figure 1: Properties of He<sup>+</sup> ion implanted V2 centres. **a** Crystal structure of 4H-SiC. The V2 centre is formed by a missing silicon atom at a cubic lattice site. **b** Energy level diagram of V2 centres. Ground and excited states are spin quartets and optical transitions are spin conserving (A1 – red, A2 – blue). **c** Schematics of V2 centre creation via He<sup>+</sup> ion implantation. He<sup>+</sup> ions are accelerated to 6 keV and implanted at the a-side of the crystal through a lithographed PMMA mask. **d** Confocal fluorescence scan of the implanted defect centre array. **e** Off-resonant excitation lifetime measurement of a single V2 centre. The fit is based on a single-exponential decay (∝exp (−𝑡/𝜏)) with a 1/e-lifetime of 𝜏= 7.08 ± 0.06 ns. **f** Singlescan resonant photoluminiscence excitation scan on an implanted V2 centre. The nearly lifetime limited linewidth confirms the excellent spectral stability of V2 centres. **g** Repeated resonant excitation scans during one hour without repump laser. No ionisation is observed and the small remaining drift is assigned to surface charge fluctuations. 

15 



<!-- Start of picture text -->
a b c<br>d e f<br>PMMA Ni<br>(i) (ii)<br>SiC<br>(iii) SF6 (iv)<br>10 µm<br>g h i<br><!-- End of picture text -->

Figure 2: Properties of V2 centres in nanofabricated waveguides. **a** Cross-sectional fundamental TE mode profile in waveguides with a half opening angle 𝛼= 45° and width 𝑑= 400 nm. **b** TE mode profile for a waveguide with 𝛼= 45° and 𝑑= 1000 nm. **c** Coupling efficiency into the fundamental TE waveguide mode as a function of the width 𝑑 (emitter assumed to be located in the centre of the waveguide). High efficiencies are reached for 𝑑= 400 −600 nm. **d** Waveguide fabrication recipe. (i) Deposition of a double layer of PMMA mask; (ii) Deposition of a nickel mask; (iii) A straight reactive ion etch based on SF6 plasma creates 3 µm deep trenches. (iv) Angled SF6 plasma etch creates triangular cross-section waveguides. **e** Scanning electron microscope image of the created waveguide structures that appear smooth and well undercut. **f** Confocal fluorescence microscope image of the waveguides. Bright spots are in majority surface-related defects. In average, one V2 centre is found in every five waveguides with 𝑑= 1000 nm. **g** Resonant excitation scans during one hour. No ionisation is observed and the wavelength drift is minimal. **h** Resonant excitation scans with the laser feedback software activated once per minute. **i** Single-line resonant excitation scans for six different V2 centres in waveguides. For better visibility, the A1 transition for all spectra is centred at zero detuning. The actual spectral distribution of the defects is ±10 GHz, comparable to bulk defects<sup>56</sup> . 

16 



<!-- Start of picture text -->
a b c<br>+3/2<br>ES<br>−3/2<br>+1/2<br>−1/2<br>A2 A2 d e<br>A1 A1<br>+3/2<br>GS +1/2<br>−1/2<br>−3/2<br>B = 0 B > 0<br><!-- End of picture text -->

Figure 3: Electron spin properties of nanofabricated V2 centres. **a** Energy level diagram of V2 centres in an external magnetic field to lift the Kramers degeneracy in the ground and excited states. **b** Ramsey interferometry for He<sup>+</sup> implanted V2 centres. The dephasing time is 𝑇",implanted∗ = 34 ± 4 𝜇s. **c** Dephasing of V2 centres in waveguides, 𝑇",waveguide∗ = 9.4 ± 0.7 𝜇s. **d** Spin coherence time of He<sup>+</sup> implanted V2 centres using Hahn echo. The coherence time is 𝑇",implanted = 1.39 ± 0.06 ms. **e** Spin coherence in waveguides, 𝑇",waveguide = 0.84 ± 0.01 ms. The strong modulation corroborates coupling to at least one nearby<sup>29</sup> Si nuclear spin. In all ! $ plots, spin state +1 corresponds to 𝑚S = and -1 to 𝑚S = . The signal envelopes are fitted " " V T + 𝑦+. using stretched exponential functions ∝A ⋅exp U− U ~~V~~ 

17 



<!-- Start of picture text -->
a b c<br>N1<br>π<br>d N1 e N2<br>N2<br><!-- End of picture text -->

Figure 4: Control over nuclear spin qubits. **a** Artistic representation of the coupled electronnuclear spin triplet identified in a waveguide. **b** Spin signal for the 8-pulse CPMG sequence (inset) at 𝐵+ = 81 G. Blue dots are experimental data. The red and orange lines correspond to the (independent) spin signals obtained for the first and second nucleus, respectively. The white dashed line is the product of both fits. The strongest modulation is observed for N1 at (F) the resonance time 𝜏approx = 5.38 µs. **c** Electron-spin signal for different number 𝑁 of refocusing pulses at 𝜏CPMG = 5.38 𝜇s. Strong oscillations stem from electron spin-dependent rotations of N1. Blue dots are uncorrected raw data. The red curve is a simulation based on two nuclear spins without any free parameters. In all plots, spin state +1 corresponds to ! $ 𝑚S = and -1 to 𝑚S = . **d** Bloch-sphere representation showing the dynamics of the " " nuclear spin N1 during the 𝑁= 4 pulse CPMG sequence. The rotation axes (green arrows) $ ! for the electron spin states 𝑚S = and 𝑚S = are antiparallel (±𝒆𝒙) with a rotation angle of " " J ± rad. **e** Same as in Fig. 4d, but for the nuclear spin N2. The nuclear spin is decoupled from " the electron spin as the rotation axis is (nearly) the same (∼𝒆𝒛) with a very small rotation angle of 0.04 rad (the shown rotation is exaggerated for clarity). 

18 

## **Supplementary information for:** 

## **Nanofabricated and integrated colour centres in silicon carbide with high-coherence spin-optical properties** 

Charles Babin<sup>1</sup> ,<sup>_∗_</sup> Rainer Stöhr<sup>1</sup> , Naoya Morioka<sup>1</sup><sup>_,_2</sup> , Tobias Linkewitz<sup>1</sup> , Timo Steidl<sup>1</sup> , Raphael Wörnle<sup>1</sup> , Di Liu<sup>1</sup> , Erik Hesselmeier<sup>1</sup> , Vadim Vorobyov<sup>1</sup> , Andrej Denisenko<sup>1</sup> , Mario Hentschel<sup>3</sup> , Christian Gobert<sup>4</sup> , Patrick Berwian<sup>4</sup> , Georgy V. Astakhov<sup>5</sup> , Wolfgang Knolle<sup>6</sup> , Sridhar Majety<sup>7</sup> , Pranta Saha<sup>7</sup> , Marina Radulaski<sup>7</sup> , Nguyen Tien Son<sup>8</sup> , Jawad Ul-Hassan<sup>8</sup> , Florian Kaiser<sup>1</sup> ,<sup>_†_</sup> and Jörg Wrachtrup<sup>1</sup> 

> 1 _3rd Institute of Physics, IQST,_ 

_and Research Center SCoPE,_ 

_University of Stuttgart, 70569 Stuttgart, Germany_ 

> 2 _Institute for Chemical Research,_ 

_Kyoto University, Uji, Kyoto, 611-0011, Japan_ 

> 3 _4th Institute of Physics, IQST,_ 

_and Research Center SCoPE,_ 

_University of Stuttgart, 70569 Stuttgart, Germany_ 

> 4 _Fraunhofer Institute for Integrated Systems and Device Technology IISB, Schottkystr. 10, 91058 Erlangen, Germany_ 

> 5 _Helmholtz-Zentrum Dresden-Rossendorf,_ 

_Institute of Ion Beam Physics and Materials Research, 01328 Dresden, Germany_ 

> 6 _Department of Sensoric Surfaces and Functional Interfaces,_ 

_Leibniz-Institute of Surface Engineering (IOM), 04318 Leipzig, Germany_ 

> 7 _Department of Electrical and Computer Engineering,_ 

_University of California, Davis, CA 95616, USA_ 

> 8 _Department of Physics, Chemistry and Biology, Linköping University, SE-58183 Linköping, Sweden_ 

S2 

### **CONTENTS** 

|S1. VSi implantation experiments|S1|
|---|---|
|A. Defect generation via helium ion implantation|S1|
|1. Implantation yield|S1|
|2. Implantation accuracy|S2|
|3. Implantation depth|S2|
|4. Stability of the resonant absorption lines|S3|
|B. Proton implantation|S4|
|C. Silicon implantation|S6|
|S2. Waveguide integrated V2 centres|S7|
|A. Defect density in the waveguide SiC sample|S7|
|B. Depth scans from waveguides to SiC surfaces|S7|
|C. Emission spectra of VSi and non-V2 colour centres in the waveguides|S8|
|D. PLE statistics|S9|
|E. Laser stabilisation protocol|S10|
|F. Spin properties in bulk material|S11|
|G. Optimized waveguide design considering the demonstrated implantation techniques|S12|
|S3. Photonic coupling in the waveguide and observation of less V2 centres inside the waveguides|S14|
|S4. Electron-nuclear spin dynamics|S16|
|A. Decoupling sequences|S16|
|1. Hamiltonian|S16|
|2. Dynamics|S16|
|B. Hahn echo and modulation|S18|
|C. CPMG resonances|S19|
|1. 1<sup>st </sup>order correction|S19|
|2. Validity range for the approximated resonance approximation|S20|
|3. Application to a particular nuclear spin configuration|S21|
|D. Obtaining the hyperfine coupling terms|S22|
|E. Gate fidelity|S23|
|References|S23|



S1 

**S1. V** Si **IMPLANTATION EXPERIMENTS** 

In this section, we provide additional information on the different implantation techniques used to generate VSi colour centres. In particular, we compare defect generation via implantation of protons, He<sup>+</sup> ions and Si<sup>2+</sup> ions. 

### **A. Defect generation via helium ion implantation** 

The key results and implantation parameters have already been discussed in the main text. In this section, we provide additional information on experiments that were carried out to infer the implantation yield and accuracy. To underline reproducibility, we also show the resonant excitation spectra of five additional V2 centres. 



<!-- Start of picture text -->
a<br>c<br>b<br><!-- End of picture text -->

Figure S1. **a** Typical second order correlation measurement of a single V2 centre. Blue dots are data and the red line is a fit taking into account the below-described function for _g_<sup>(2)</sup> ( _τ_ ). **b** Probability distribution of the number of V2 centres per implantation site. Blue dots are data and error bars correspond to the square root of the number of measurements. The red line is a fit to the data considering a Poissonian distribution. **c** Lateral spatial distribution of the implanted single V2 centres compared to a simulated grid. The red circle represents the 53.6 nm variance of all positions. 

### _1. Implantation yield_ 

The implantation yield is defined as the number of V2 centres created per implanted ion. To infer the number of defects per implantation spot, we perform a Hanbury Brown and Twiss interferometry. We record the second-order correlation function ( _g_<sup>(2)</sup> ) under off-resonant excitation (785 nm with 2 mW pump power). Note that we are only interested in the yield for generating V2 centres. However, we find that V2 and V1 centres [S1] are created at roughly the same rate. To suppress spurious phonon sideband emission of V1 centres during the _g_<sup>(2)</sup> measurements, we use a 950 _±_ 25 nm bandpass filter which rejects most of the V1 centre’s emission, and, at the same time, shows a high transmission for in the first phonon sideband of the V2 centre emission (see Figure S6 **a** ). 

A typical measurement is shown in Figure S1 **a** . In general, the data can be fitted with the function _g_<sup>(2)</sup> ( _τ_ ) = <u>1</u> _N_<sup>[1</sup><sup>_−a·e−_</sup><sup>_<u>|</u>_</sup> _τ_<sup>_τ_</sup> 1<sup>_<u>|</u>_</sup> +(1 _− a_ ) _· e_<sup>_−_</sup><sup>_<u>|</u>_</sup> _τ_<sup>_τ_</sup> 2<sup>_<u>|</u>_</sup> ]+<sup>_<u>N</u>_</sup> _N_<sup>_−_</sup><sup><u>1</u>.Here,</sup><sup>_τ_is the delay time between two detector clicks in the Hanbury Brown and</sup> Twiss setup, _a_ is a prefactor, _τ_ 1 _,_ 2 are decay constants, and _N_ is the number of emitters in a spot. In the measurement 

S2 

shown in Figure S1 **a** , we find _g_<sup>(2)</sup> ( _τ_ = 0) _≪_ 0 _._ 5, which corroborates a single emitter (value extracted from the fit: _N_ = 1 _._ 01 _±_ 0 _._ 02). By inquiring 112 spots in the array, we extract the statistical distribution of defect number, shown in Figure S1 **b** . The fit to the data is based on a Poissonian function from which we determine the average number of V2 centres created per spot to be 0 _._ 66 _±_ 0 _._ 06. Considering the ion implantation dose (1 _·_ 10<sup>11</sup> cm<sup>_−_2</sup> ) and the mask’s hole size (100 nm diameter), we obtain therefore an implantation yield of 8 _._ 5 _±_ 0 _._ 8% for generating V2 centres. 

### _2. Implantation accuracy_ 

To estimate the spatial implantation accuracy in lateral coordinates, we use a closed-loop piezo scanner (Mad City Labs Inc. Nano-LPMW, 0.4 nm resolution) and determine the position of 36 single V2 centres within a 12 _×_ 12 array. Each single-defect position is determined using a two-dimensional Gaussian fit. To infer the principal implantation accuracy, we compare the implantation positions with a simulated grid. We minimize error squares between data and simulation by allowing the simulated grid to account sample rotation and scanner linearity error in both directions. The deviation between the measured data and simulated grid positions is shown in Figure S1 **c** . The variance of the defect positions is 53.6 nm (represented by a circle). This value is almost completely determined by the implantation hole size (50 nm diameter), such that the lateral straggle of He<sup>+</sup> ions during implantation is minimal. This is confirmed by SRIM simulations for implanting 6 keV He<sup>+</sup> ions into SiC that predict a lateral projected straggle of 22 nm. The implantation accuracy at this low energy is thus sufficient for creating defects in the centre of photonic crystal cavities. 

### _3. Implantation depth_ 

Simulations of helium ion implantation and corresponding vacancy generation have been carried out using the Synopsys Sentaurus Monte Carlo (MC) simulator in order to take the crystalline structure of 4H-SiC into consideration. Sentaurus MC uses the binary collision approximation (BCA). Implantation was simulated at a temperature of _T_ = 300 K into the (1 1 -2 0) plane with an implantation energy of 6 keV and a dose of 1 _·_ 10<sup>11</sup> cm<sup>_−_2</sup> . As we do not have a precise control on the implantation angle in our implanter device, we perform simulations for a variation of tilt angles between 0<sup>_◦_</sup> and 7<sup>_◦_</sup> . For the simulation of vacancy generation, threshold displacement energies of 41 eV for Si and 16 eV for C have been chosen for the Frenkel pair defect model while taking into account all secondary recoils from cascades [S2]. Figure S2 **a** shows the results for implantation at an angle of 0<sup>_◦_</sup> . Here, we observe a small He<sup>+</sup> ion channelling effect for implantation. However, no channelling is found in the depth profiles of carbon vacancies (VC) and especially not for VSi. Further simulations at an implantation angle of 7<sup>_◦_</sup> , shown in Figure S2 **b** , shows essentially the shape of the depth profile, however with a _≈_ 3 _×_ higher defect generation efficiency. Figure S2 **c** shows the simulated VSi depth profiles at different implantation angles ranging from 0<sup>_◦_</sup> to 7<sup>_◦_</sup> . The general shape of all profiles is the nearly identical, thus confirming that the VSi centres are created in majority at a depth of 30 _−_ 40 nm. 



<!-- Start of picture text -->
a b c<br><!-- End of picture text -->

Figure S2. Implantation depths for bombardment with He<sup>+</sup> ions at an energy of 6 keV along the (1 1 -2 0) side of 4H-SiC. In both plots, the black line represents the stopping distance for the He<sup>+</sup> ions, the green line represents the depths at which carbon vacancies are created (VC) and the blue line shows the VSi depth profiles. **a** Implantation at normal incidence (0<sup>_◦_</sup> ). **b** Implantation at an incidence angle of 7<sup>_◦_</sup> with respect to the surface normal. Although the peak of the VSi formation density is _≈_ 3 _×_ higher in **b** , no significant change in the depth profile is observed. **c** VSi depth profiles at different implantation angles ranging from 0<sup>_◦_</sup> to 7<sup>_◦_</sup> . 

S3 

_4. Stability of the resonant absorption lines_ 

To confirm that implanted V2 centres reproducibly show a good spectral stability, we show here resonant absorption line measurements on another five implanted defects. For each defect, we show repeated laser excitation scans for 20 minutes. The results are shown in Figure S3 **a** - **e** . 



<!-- Start of picture text -->
a b c<br>d e f<br><!-- End of picture text -->

Figure S3. **a** - **e** Repeated resonant excitation scans during 20 minutes without repump laser for five implanted defects. **f** Single-line resonant excitation scans for five different V2 centres created via He<sup>+</sup> implantation. For better visibility, the A1 optical transition for all spectra is centreed at zero detuning (the actual spectral distribution of the defects is _±_ 10 GHz). Each measurement is additionally off-setted by one unit in _y_ -direction. Linewidths are obtained via double-Lorentzian fits to the data. The obtained linewidths for the A2 (A1) transitions are (from bottom to top): 25 _±_ 1 MHz (26 _±_ 1 MHz), 45 _±_ 1 MHz (70 _±_ 2 MHz), 64 _±_ 2 MHz (52 _±_ 3 MHz), 79 _±_ 2 MHz (68 _±_ 4 MHz); 41 _±_ 1 MHz (101 _±_ 3 MHz). 

Remarkably, all defects show no signs of ionisation or blinking and single scans result in well-separated spinselective lines. The very small remaining drift rate can be captured by our laser feedback system (see section S2 E). In Figure S3 **f** , we display a single absorption line scans for the five additional defects from which we extract the linewidths of the A2 and A1 transitions via double-Lorentzian fit functions. 

The average linewidth of the A2 transition is 46 _±_ 20 MHz, where the uncertainty is taken from the standard deviation. Our results highlight the reproducibility of our implantation technique to generate high quality colour centres. 

S4 

### **B. Proton implantation** 

We investigate also V2 centre creation via proton implantation. As for the Helium implantation, we use a PMMA mask of 200 nm thickness on which 100 nm diameter holes are patterned using electron-beam lithography. Protons are implanted at an energy of 12 keV at a dose of 5 _·_ 10<sup>12</sup> cm<sup>_−_2</sup> . The sample is subsequently annealed at 600<sup>_◦_</sup> C in argon atmosphere for 30 minutes to remove some lattice damage and interstitial defects. A subsequent confocal microscopy image of the implanted defect array is shown in Figure S5 **a** . Using the same approach as described in the section S1 A 1 for the Helium implanted defects, we infer the number of defects per spot by measuring the second-order correlation function. A typical g<sup>(2)</sup> signal is shown in Figure S5 **b** . We collect statistical data for 110 implanted spots to infer the average number of V2 centres per spot (see Figure S5 **c** ). This translates to an implantation yield of 0 _._ 83 _±_ 0 _._ 02% for V2 centres. We also obtain the accuracy of the implantation, using the methods described in section S1 A 2. Similar to the above results, we find a lateral spatial variance of 56 nm, which is almost entirely dominated by the hole size (see Figure S5 **d** ). This is in accordance with SRIM simulations that predict a lateral projected straggle of 33 nm. 

We subsequently measure the resonant absorption spectrum of five generated V2 defects. As shown in Figure S5 **a** , single-line scans show spin-conserving transitions lines. From the double-Lorentzian fits, we extract the A2 (A1) linewidths, with four fits revealing nearly lifetime limited linewidths. Prolonged repeated measurements for 30 minutes, as seen in Figure S5 **b** - **f** , show no signs of ionisation, but the drift rate is somewhat faster compared to the He<sup>+</sup> ion implanted defects. This is observed despite the fact that proton implanted defects are generated substantially deeper beneath the surface ( _∼_ 110 nm for protons, compared to 40 nm for He<sup>+</sup> ). Thus, surface charge fluctuations are seemingly not the primary source of spectral drifts. Therefore, we attribute the increased drift rate for proton implanted defects to the increased relative formation of carbon versus silicon vacancies due to the use of lighter ions. 



<!-- Start of picture text -->
a b<br>c d<br><!-- End of picture text -->

Figure S4. **a** Confocal fluorescence scan of the proton implanted defect centre array **b** Second order correlation function of a single V2 centre. From the fit to the data, we obtain a defect number of _N_ = 1 _._ 07 _±_ 0 _._ 05. **c** Probability distribution of the number of created V2 centres per site. The fit to the data is based on a Poissonian distribution. **d** Lateral spatial implantation accuracy compared to the simulated grid. The red circle represents the variance of 56 nm. 

S5 



<!-- Start of picture text -->
a b c<br>d e f<br><!-- End of picture text -->

Figure S5. **a** Single-line resonant excitation scans for five different V2 centres created via proton implantation. For better visibility, the A1 transition for all spectra is centreed at zero detuning. The actual spectral distribution of the defects is _±_ 10 GHz. The single scan linewidths obtained from the fits are (from bottom to top): 43 _._ 9 _±_ 0 _._ 6 MHz (49 _±_ 2 MHz), 43 _±_ 1 MHz (39 _±_ 1 MHz), 20 _._ 9 _±_ 0 _._ 4 MHz (30 _±_ 1 MHz), 25 _._ 9 _±_ 0 _._ 5 MHz (37 _±_ 1 MHz); 226 _±_ 6 MHz (147 _±_ 8 MHz) for the A2 (A1) transition. **b** - **f** Repeated resonant excitation scans for 30 minutes without repump laser for five isolated V2 centres. No ionisation is observed. However, the drift rate is somewhat faster compared to the defects created via He<sup>+</sup> implantation. 

S6 

### **C. Silicon implantation** 

We implant Silicon ions (Si<sup>2+</sup> ) using a focussed ion beam device, operating at 35 keV acceleration voltage. The ion flux is varied from the minimal nominal dose of 1 _·_ 10<sup>_−_18</sup> C per spot to 29 _·_ 10<sup>_−_18</sup> C per spot, in other words, 3.1 to 91 ions are implanted per spot. After annealing the sample at 600<sup>_◦_</sup> C for 30 minutes, we investigate the defect arrays at cryogenic temperatures ( _T_ = 10 K). Unfortunately, even at the lowest implantation dose, we did not observe any single defect. 

We record photoluminescence emission spectra of the implanted spots using a Peltier cooled spectrometer (Ocean Insight QE pro, 0.3 nm resolution). A typical measurement is shown in Figure S6 **a** . In all implanted spots, we clearly identify the characteristic zero-phonon lines of V1 and V2 centres a 862 nm and 917 nm, respectively. For V2 centres, we usually find ZPL emission linewidths of about 1 nm (see inset of Figure S6 **a** ), which is in contrast to the 0.3 nm emission linewidths that are obtained for He<sup>+</sup> and proton implanted defects. Thus, without surprise, we were not able to identify resonant absorption lines for those defects. 

To further investigate the Si<sup>2+</sup> implanted defects, we perform additional measurements on the excited state lifetimes of the implanted defects. To this end, we use a 2-ps-pulsed excitation laser that operates at a central wavelength of 780 nm. From the time-dependent phonon sideband fluorescence, we extract the lifetime. The corresponding data is shown in Figure S6 **b** . We clearly observe a bi-exponential decay with 1/e-lifetimes of _τ_ = 5 _._ 63 _±_ 0 _._ 07 ns and _τ_ = 2 _._ 79 _±_ 0 _._ 09 ns, respectively. The longer decay constant closely resembles the typical results obtained for off-resonant excitation of V1 and V2 centres [S1, S3]. The shorter decay time may indicate that additional non-radiative decay channels have been created due to substantial crystal damage associated with heavy Si<sup>2+</sup> ion implantation [S4, S5]. Our hypothesis is strengthened by the single-decay results that are obtained with Helium and proton implantation (see main text). In future work, it may be interesting to reduce the Si ion flux to single silicon ions, and/or to see whether similar methods could be applied using helium ions. 



<!-- Start of picture text -->
a b<br><!-- End of picture text -->

Figure S6. **a** Typical photoluminescence spectrum of an implantation spot using the lowest possible Si<sup>2+</sup> ion dose of 1 _·_ 10<sup>_−_18</sup> C. The zero-phonon lines of both V1 and V2 are clearly visible, which clearly show that multiple defects are being generated. The inset shows a zoom-in for the V2 zero-phonon line, which is substantially wider compared to the proton and Helium implanted defects. **b** Pulsed off-resonant excitation lifetime measurement of a single implantation spot. The fit is based on a bi-exponential decay function, yielding 1/e-lifetimes of _τ_ = 2 _._ 79 _±_ 0 _._ 09 ns and _τ_ = 5 _._ 63 _±_ 0 _._ 07 ns, respectively. 

S7 

### **S2. WAVEGUIDE INTEGRATED V2 CENTRES** 

### **A. Defect density in the waveguide SiC sample** 

As mentioned in the Methods section, V2 centres have been created in the SiC sample via electron beam irradiation prior to waveguide fabrication. To estimate the expected defect density in the waveguides, we measure the defect density in the bulk material next to the waveguides via standard confocal microscopy. For the scans, we use a continuous-wave excitation laser with an operation wavelength of _λ_ = 785 nm. To estimate the defect density, we need to consider the axial resolution of the microscopy setup. Considering that our microscope objective has a numerical aperture of NA = 0 _._ 9, and that the refractive index of 4H-SiC is _n_ = 2 _._ 6, we obtain an axial resolution of: 



<!-- Start of picture text -->
z axial = NA 2  λ 2 ≈ 1 . 9  µ m . (S1)<br><!-- End of picture text -->

We subsequently count 57 defects in a scanning area of 5 _×_ 15 _µ_ m<sup>2</sup> in the bulk next to the waveguides, see Figure S7. Assuming that the defects are axially homogeneously distributed over 1 _._ 9 _µ_ m results in a defect density of _ρ_ VSi _≈_ 142 _._ <u>575</u> _µ_ m<sup>3= 0</sup><sup>_._4</sup><sup>_µ_m</sup><sup>_−_3.</sup> 



<!-- Start of picture text -->
5<br>4 6.0<br>3<br>4.0<br>2<br>1 2.0<br>0<br>0 5 10 15<br>x [µm]<br>y [µm]<br>Intensity (kcps)<br><!-- End of picture text -->

Figure S7. Confocal microscopy scan in the bulk next to the waveguides. 

### **B. Depth scans from waveguides to SiC surfaces** 

Considering the axial resolution of our microscopy setup, we underetch the waveguides by _≈_ 2 _µ_ m to ensure that optical excitation is performed on waveguide-integrated defects without spurious signal from defects in the SiC bulk substrate beneath. A typical confocal depth scan is shown in Figure S8 **a** . Three waveguides are visible, with fluorescence of defects primarily occurring at the apices. The bulk SiC surface is also visible, including two near-surface defects. Fluorescent spots in waveguides and bulk SiC are well separated, thus confirming that resonant excitation experiments are indeed performed with defects localised in waveguides. 



<!-- Start of picture text -->
a b<br>Vacuum<br>Waveguides<br>Surface<br>Bulk<br><!-- End of picture text -->

Figure S8. **a** Confocal microscopy depth scan in the waveguide area on the sample. The SiC bulk substrate surface is visible at a depth position _z ≈_ 0 _µ_ m. Three waveguides appear at _z ≈_ 2 _µ_ m. Defects in the bulk and waveguides appear well-separated, thus permitting selective excitation without spurious parasitic signals. **b** Second order correlation function of a single V2 centre in the waveguide, indicating single emitter behaviour ( _g_<sup>(2)</sup> ( _τ_ = 0) _<_ 0 _._ 5). 

S8 

### **C. Emission spectra of V** Si **and non-V2 colour centres in the waveguides** 

In Figure 2 **f** in the main text, we show typical confocal scans along the nanofabricated waveguides at _T_ = 10 K with 785 nm continuous wave excitation. Multiple bright spots appear, however, most spots are not identified as V2 centres. 

We have attempted to figure out the origin of the remaining fluorescent defects on the waveguides via measuring emission spectra. A typical emission spectrum of these defects and a typical spectrum of a V2 centre are shown in Figure S9. Unfortunately, no distinct features are present in the non-V2 centre spectra, despite the low temperature operation, making it hard for us to attribute the origin of the fluorescence to particular colour centres. At this point, we would like to mention that the identification of colour centre origin/structure is an ongoing field of research for the relatively new SiC platform. Additionally, many studies on unknown defects are performed at room temperature, which complicates a straightforward comparison to our low-temperature experiments. Nevertheless, comparing our spectra to known colour centres (e.g., as nicely summarized in reference [S6] and references therein), we can exclude carbon antisite vacancies (CAV), as well as annealing-related defects. Our measured emission spectra show some overlap with unknown defects that have been tentatively attributed to surface oxide [S7]. Such an oxide layer may form during the sample nanofabrication and/or acid cleaning. In the end, we would like to mention that the occasional presence of other colour centres on waveguides is not problematic for future experiments that target excitation of defects through the waveguides. Here, it is only important to be able to address individual VSi centres via spin-selective resonant optical excitation. The low powers used for resonant excitation experiments (nW range) are unlikely to induce any sizeable emission of other colour centres, even when performing excitation through the waveguide. 



<!-- Start of picture text -->
1.0 V2<br>Surf. defect<br>0.5<br>0.0<br>860 880 900 920 940<br> Wavelength (nm)<br>Intensity (arb. u.)<br><!-- End of picture text -->

Figure S9. Typical emission spectra of colour centres in waveguides. The red curve represents a typical non-V2 defect, while the blue curve shows the emission spectrum of a V2 centre, which we identify in one out of five waveguides. 

S9 

### **D. PLE statistics** 

To underline the reproducibility of the results presented in the main text, we studied five additional V2 centres in waveguides. To this end, we show repeated resonant excitation scans for five additional defects in different waveguides. Experimental data is shown in Figure S10. All defects exhibit a very slow spectral drift and no ionisation is observed. The single-line scans of those five defects correspond to the upper five data sets in Figure 2 **f** in the main text. The extracted single scan linewidths for the A2 (A1) transitions of those five defects are 21 _._ 4 _±_ 0 _._ 3 MHz (49 _±_ 2 MHz), 123 _±_ 7 MHz (115 _±_ 20 MHz), 17 _._ 6 _±_ 0 _._ 3 MHz (32 _±_ 1 MHz), 78 _±_ 2 MHz (216 _±_ 8 MHz), 15 _._ 6 _±_ 0 _._ 4 MHz (44 _±_ 3 MHz), 93 _±_ 1 MHz (100 _±_ 5 MHz). 



<!-- Start of picture text -->
a b c<br>d e<br><!-- End of picture text -->

Figure S10. **a** - **e** Repeated resonant excitation scans for the defects presented in Figure 2 **f** of the main text. No ionisation is observed and the remaining drift is assigned to surface charge fluctuations. 

S10 

### **E. Laser stabilisation protocol** 

The resonant absorption lines of our nanofabricated V2 centres still exhibit a very slow drift, e.g., as shown in Figure S10. To perform complex long-term measurements, we thus periodically refocus the resonant excitation laser on the A2 optical transition. The refocussing period is typically chosen on a time scale of a few to several minutes. The employed protocol is schematically depicted in Figure S11. During all steps in the protocol, we provide a microwave (MW) drive resonant with the ground state transitions _m_ S = +1 _/_ 2 _↔ m_ S = +3 _/_ 2 and _m_ S = _−_ 1 _/_ 2 _↔ m_ S = _−_ 3 _/_ 2 to counteract spin pumping by mixing the ground state populations. The laser feedback protocol goes as follows: 

- (1) We probe whether the absorption lines drifted by applying a resonant excitation on the A2 optical transition for 500 ms. Provided that more than 300 photons are detected, we consider that no drift occurred, and the main measurement is continued. If less than 300 photons are detected, we proceed with step (2). 

- (2) We perform up to two resonant excitation scans (PLE), by tuning the resonant excitation laser over a frequency range of 3 GHz. The resulting fluorescence signal is fitted with a double-Lorentzian function. The goodness of the fit is evaluated by several criteria, such as the peak separation that must be within 0 _._ 9 _−_ 1 _._ 1 GHz, the peak ratio that must be in the range of<sup><u>1</u></sup> 3<sup>to3,thepeakwidththatmustbeintherangeof10to100MHz,and</sup> the signal-to-background ratio that must exceed 5. If all criteria are met, we fix the laser on the high-frequency transition (A2 line) and resume the main measurement. The laser scanning window is also reset such that the A2 transition occurs at 2/3 of the (potential) next scan. If the above criteria are not met, we repeat step (2) one more time. If the criteria are not met after the second attempt, we proceed to step (3). 

- (3) An off-resonant laser pulse (1 mW, 1 s, 785 nm) is applied to modify/reset the charge environment of the V2 centre. Then, we perform up to two resonant excitation scans with a frequency range of 13 GHz. If the signal can be fitted by a double-Lorentzian function with the same fit criteria as mentioned in (2), we continue with step (2). Note that we do not resume the main measurement directly due to laser drift and hysteresis after extended scan ranges. If step (3) is not successful after two attempts, we proceed with step (4). 

- (4) Similar to step (3), we step (4) employs the same off-resonant excitation pulse, however followed by a resonant excitation scan covering 20 GHz. This scan range is sufficient to always identify the absorption lines, e.g., we have never observed spectral wandering and distribution beyond this range [S8]. Once step (4) is successful, we proceed with step (2). 



<!-- Start of picture text -->
2 tries 2 tries<br>PLE range: PLE range: PLE range:<br>Freq. check<br>3 GHz 13 GHz 20 GHz<br>Repump<br>Repump<br>Repump<br>Resume<br>Meas.<br><!-- End of picture text -->

Figure S11. Schematic of the protocol to periodically refocus the resonant laser on the A2 optical transition of the waveguideintegrated V2 centres. The green (red) arrows correspond to successful (unsuccessful) steps in finding the A2 transition. 

S11 

### **F. Spin properties in bulk material** 

To infer the spin coherence degradation that V2 centres experience after waveguide fabrication, we compare their spin properties to deep bulk defects that have not been affected by the nanofabrication processes. In the following, we perform Hahn-echo and Ramsey interferometry measurements on a V2 centre that resides in the bulk in a non-etched area on the sample. The results are shown in Figure S12 **a** - **b** . From the fit to the data, we obtain a dephasing time of _T_ 2<sup>_∗_</sup> _,_ bulk<sup>= 21</sup><sup>_±_1</sup><sup>_µ_sandaHahnechocoherencetimeof</sup><sup>_T_2</sup><sup>_,_bulk= 0</sup><sup>_._84</sup><sup>_±_0</sup><sup>_._03ms.Thosetimesareverysimilartothe</sup> ones measured for the waveguide integrated V2 centres, which corroborates that our nanofabrication recipes induce minimal damage. 



<!-- Start of picture text -->
a b<br><!-- End of picture text -->

Figure S12. **a** Spin dephasing time for V2 centres in the bulk. From the fit to the data, we obtain _T_ 2<sup>_∗_</sup> _,_ bulk<sup>=21</sup><sup>_±_1</sup><sup>_µ_s.</sup><sup>**b**</sup> Spin coherence time of bulk V2 centres using the Hahn echo sequence. The fit to the data results in a coherence time of _T_ 2 _,_ bulk = 0 _._ 85 _±_ 0 _._ 03 ms. 

S12 

### **G. Optimized waveguide design considering the demonstrated implantation techniques** 

Our implantation experiments demonstrated that the excellent spin-optical properties of V2 centres are not degraded by He<sup>+</sup> ion implantation and when integrating the defects in nanophotonic waveguides. This promises the development of highly efficient and robust spin-photon interfaces via system integration into waveguides, photonic crystal cavities, and quantum photonic circuits in general. In this section, we discuss ideal waveguide designs based on the demonstrated implantation and nanofabrication techniques. 



<!-- Start of picture text -->
a b<br>c<br>d<br><!-- End of picture text -->

Figure S13. Modelled colour centre emission coupling into a triangular cross section waveguide. **a** TE mode profiles of triangular waveguides with variable etch angle _α_ and width _d_ . Highest waveguide-coupling efficiency is achieved for the devices that are highlighted by a red box. **b** The coupling efficiency of light emitted by a centrally located V2 centre for variable waveguide geometry. **c** The coupling efficiency of light emitted by a V2 centre on the vertical symmetry axis for variable emitter depth and waveguide geometry; the colour legend in **b** applies to the plot. **d** The coupling efficiency of light emitted by a 30 nm deep V2 centre laterally shifted from the central position for variable waveguide geometry; the colour legend in **b** applies to the plot. 

In colour centre integration with triangular waveguides, highly efficient single-mode light propagation is a crucial prerequisite for quantum applications. The relationship between device profile and its supported mode wavelength has been modeled recently [S9]. Here, we expand on those findings to propose efficient design guidelines for V2 centre emission propagation, robust to the demonstrated implantation uncertainties. In particular, we analyze the coupling efficiency of light emitted by a centrally located horizontal dipole at 917 nm into the transverse electric (TE) modes of a triangular waveguide. We find the existence of the preferential waveguide width _d_ for each studied etch angle _α_ , as presented in Figure S13 **a,b** . Interestingly, the mode shape of the optimal device appears more rectangular than circular, and localized within silicon carbide. For the waveguides fabricated in this work ( _α_ = 45<sup>_◦_</sup> , _d_ = 1000 nm) the coupling efficiency into the fundamental TE mode is approximately 30% (15% in each propagation direction in the waveguide). The efficiency would rise to 82% if those waveguides were minimized to 500 nm width. We note that these coupling efficiencies assume a defect in the centre of the waveguide, i.e., at a depth of 125 nm along the vertical symmetry axis of the devices with _α_ = 45<sup>_◦_</sup> and _d_ = 500 nm. Figure S13 **a,b** show additional results for V2 centres positioned in at the centre of different waveguide geometries ( _α_ = 30<sup>_◦_</sup> _−_ 75<sup>_◦_</sup> , _d_ = 400 nm _−_ 1000 nm). Devices with optimal collection efficiency are highlighted by a red box in Figure S13 **a** . Figure S13 **b** shows further that waveguides with steeper etching angle _α_ provide high optimal efficiencies over a larger range in _d_ . 

S13 



<!-- Start of picture text -->
1 2 3 4 5 6<br>a<br>b<br>c d<br><!-- End of picture text -->

Figure S14. Single mode operation of optimized triangular waveguides. **a** Profiles of the six lowest energy modes supported in a triangular waveguide with etch angle _α_ = 45<sup>_◦_</sup> and width _d_ = 500 nm and **b** etch angle _α_ = 75<sup>_◦_</sup> and width _d_ = 900 nm; mode #1 is the fundamental TE polarized mode. **c** The coupling efficiency of light emitted by a centrally located horizontally polarized dipole into each of the modes shown under **a** ; the coupling efficiency is evaluated after 10 _µ_ m propagation. Single mode operation is observed for waveguide widths of 400 nm and 500 nm. **d** The coupling efficiency of light emitted by a 30 nm deep horizontally polarized emitter to each of the modes shown under b showing single mode operation. 

To account for the demonstrated He<sup>+</sup> ions implantation technique that results in a preferred V2 centre creation at 30 _−_ 40 nm depth, we now provide additional simulation results to identify the optimal geometry. As presented in Figure S13 **c** , the coupling efficiency does not change significantly in the investigated depth range ( _d_ = 30 _−_ 40 nm). Devices with higher etch angles result in consistently better coupling efficiencies (up to 80%). Remarkably, the _α_ = 75<sup>_◦_</sup> devices show very robust coupling efficiencies, especially with regards to the waveguide width _d_ = 900 _−_ 1000 nm, as shown in Figure S13 **c** . We also consider the demonstrated lateral defect creation accuracy which was determined to be _±_ 54 nm in this work and mainly limited by the implantation mask’s hole size (100 nm diameter). As shown in Figure S13 **d** , lateral displacement of the emitters does not play a significant role, i.e., fundamental TE mode coupling efficiencies remain within 10% of their peak value. The lost photons couple to the fundamental transverse magnetic (TM) mode and can, in practice, be filtered out by polarisation. 

For optimal coupling of light out of the waveguides into single-mode optical fibres, it is important to ensure single TE mode operation. To this end, we simulate the first six TE modes for devices with ( _α_ = 45<sup>_◦_</sup> , _d_ = 500 nm) and ( _α_ = 75<sup>_◦_</sup> , _d_ = 900 nm), respectively. The results are shown in Figure S14 **a** and **b** , respectively. The coupling efficiency of from a 30 nm deep emitter to the different modes and varying _d_ is shown in Figure S14 **c** and **d** , respectively. We find that both preferred geometries ( _α_ = 45<sup>_◦_</sup> , _d_ = 500 nm) and ( _α_ = 75<sup>_◦_</sup> , _d_ = 900 nm), provide _≈_ 80% coupling efficiency into the first TE mode without noticeable excitation of higher-order modes. 

Our modelling results show that the demonstrated Faraday cage etching techniques and He<sup>+</sup> ion implantation provide a rich toolset for integrated SiC colour centre photonics. The single TE mode operation of triangular waveguides is highly efficient and robust in multiple degrees of freedom: vertical and lateral emitter displacement, fabrication dimension and surface roughness imperfections. Moreover, these waveguides can be coupled to triangular photonic crystal cavities which are known to provide strong Purcell enhancement utilized to boost the generation of indistinguishable single photons in colour centres [S9–S11]. 

S14 

### **S3. PHOTONIC COUPLING IN THE WAVEGUIDE AND OBSERVATION OF LESS V2 CENTRES INSIDE THE WAVEGUIDES** 

Finite-Difference Time-Domain (FDTD) method is particularly suitable for simulating the expected performance of nanophotonic devices, processes, and materials. This method models the propagation of light by discretizing Maxwell’s equations in both time and space coordinates in a leap-frog manner. Owing to high accuracy and broad-frequency response, FDTD method has been widely used as a verification tool for photonic devices over the years. Moreover, FDTD method has been employed to simulate nanocavities in triangular diamond waveguides [S11, S12]. Recently, we have used FDTD modeling to analyze color center positioning and Purcell enhancement in triangular SiC waveguides and nanobeam cavities [S9]. In this work, as well as in the present manuscript, we have used Lumerical software to perform 3D FDTD electromagnetic simulations, an accurate and widely used tool in academia and industry. 

In an attempt to infer the photonic coupling efficiency along the waveguide using our present optical arrangement (collection objective from the top), we performed additional experimental and simulation studies. The basic idea was to infer saturation count rates from V2 centres in the bulk and compare these count rates to emitters in waveguides. Assuming that the total photon emission rate in both cases does not change, and comparing with results from simulations, would then allow to confirm photonic coupling into the waveguide. 

Our FDTD model assumes a horizontal dipole emitter in a SiC triangular waveguide (or bulk) studies the light propagation equivalent to the experimental setup. The collection of light into an objective of NA = 0.9 is calculated in a two-step analysis. In the first step, the fraction of light that leaves silicon carbide upwards is evaluated. In the second step, Fourier transform of the electromagnetic field above the structure produces the far-field pattern in k-space, and can be used to calculate the fraction of light that enters the NA = 0.9 objective. The modelling results support the experimental findings and are detailed in Figure S15. 



Figure S15. Model of an emitter in bulk. The model of a silicon vacancy in SiC bulk at arbitrary depth (top) shows a decreasing trend in collected photons with the increasing depth of the emitter. Experimental results (below) show a similar trend. 

In the next step, we performed simulations on the out-coupling efficiency for defects located in 45<sup>_◦_</sup> underetched 1000 nm wide waveguides. We found that the collectable photon rate depends very strongly on the exact location of the emitter in the waveguides, see Figure S16. 

Considering the large variability of achievable collection efficiency and the limited accuracy towards inferring each defect’s precise position inside the waveguide, made it impossible to faithfully measure the saturation count rate, which was therefore not attempted. 

These simulations provide also a plausible explanation for the observation of less V2 centres in the waveguides 

S15 





Figure S16. Model of an emitter in a triangular waveguide. The model of a silicon vacancy in a triangular SiC waveguide reveals that collection efficiency into an objective is higher at the edges of the structure than in its center (left). This data supports the experimental findings where emitters are identified at the sides of the structure (see Figure 2f in the Main Text, as well as Figure S8). A plausible explanation is that the emitters that couple to the fundamental mode do not scatter light toward the objective (right). The red dot size is proportional to the light collected by the objective for emitter at that location. 

compared to the defect density in the bulk. In this sense, we note that we only identify V2 centres that are bright compared to the waveguide’s background fluorescence. This means that we observe only these defects that are placed at ideal positions in the waveguide, notably those that are close to the waveguides’ apices, see Figure S16. It is thus very likely that the actual density of negatively charged V2 centres is not modified significantly in the waveguides. As the observed V2 centres show stable optical lines and no ionization, this could indicate that bandbending near the surfaces and edges is not significant. 

S16 

### **S4. ELECTRON-NUCLEAR SPIN DYNAMICS** 

In this section we develop a framework to describe the spin dynamics of a weakly coupled electron-nuclear spin pair during the Hahn echo and CPMG sequences. Further, we provide a methodology to estimate the nuclear spin gate fidelities. We apply the techniques to our hybrid system comprising an electron spin2<sup><u>3</u>systemcoupledtoanuclear</sup> spin-<sup><u>1</u></sup> 2<sup>.However,ourframeworkcanbestraightforwardlyappliedtoarbitraryelectron-nuclearspinsystems.</sup> 

### **A. Decoupling sequences** 

### _1. Hamiltonian_ 

We consider a weakly coupled electron nuclear spin system, such that the secular approximation is valid. Therefore, the Hamiltonian can be expressed as: 



<!-- Start of picture text -->
H ˆ = � |si⟩⟨si| ⊗ ωi n i · ˆ I  = � |si⟩⟨si| ⊗ H ˆ i. (S2)<br><!-- End of picture text -->

Here, _|si⟩_ denote the different electron spin levels, and<sup>ˆ</sup> **I** is the spin matrix representation of the nuclear spin. _ωi_ and **n** _i_ are the angular frequency and the rotation axis of the nuclear spin when the electron spin is in the state _|si⟩_ , respectively. The terms can be expressed as a function of the hyperfine coupling terms as: 



<!-- Start of picture text -->
ωi = � ( siA∥ − γnB ) 2 + ( siA⊥ ) 2 , (S3)<br><!-- End of picture text -->



<!-- Start of picture text -->
n i = 1 ( siA⊥,  0 , siA∥ − γnB ) . (S4)<br>ωi<br><!-- End of picture text -->

Here, _A∥_ and _A⊥_ are the parallel and perpendicular hyperfine coupling terms, respectively. _γn_ is the nuclear spin gyromagnetic moment, and _B_ the external magnetic field strength (assumed here to be parallel to the _z_ -axis, which is the electron spin quantisation axis). With this, we now develop the nuclear spin evolution operator with the electron spin state being in the state _|si⟩_ (ℏ = 1): 



<!-- Start of picture text -->
U ˆ i ( τ ) = exp � − i( ωiτ ) n i · ˆ I � . (S5)<br><!-- End of picture text -->

In the Bloch sphere representation, this corresponds to a rotation by an angle _ωiτ_ around the axis **n** _i_ . 

### _2. Dynamics_ 

The hyperfine coupling can be used to drive the nuclear spin. For a weakly coupled nuclear spin, so-called dynamical decoupling sequences provide a powerful means. By alternating the electron spin between the two states _|s_ 0 _⟩_ or _|s_ 1 _⟩_ (in our case _|s_ 0 _⟩_ = _|m_ S = +1 _/_ 2 _⟩_ and _|s_ 1 _⟩_ = _|m_ S = +3 _/_ 2 _⟩_ ), the nuclear spin experiences different rotations. We consider the sequence in which the electron spin is initialized into the state _|ψ⟩_ init = _|s_ 0 _⟩_ , followed by a _π/_ 2-pulse to obtain the superposition state ( _|s_ 0 _⟩_ + _|s_ 1 _⟩_ ) _/_ _~~√~~_ 2. Thereafter, we apply the spin manipulation sequence ( _τ − π − τ_ )<sup>_N_</sup> , in which, _τ_ represents a waiting time, _π_ a spin-flip pulse, and _N_ is an integer number. If we denote the initial nuclear spin state as _|n⟩_ , then the bipartite system’s state at the end of the sequence is: 



<!-- Start of picture text -->
1<br>| Ψ ⟩ = √ 2 � |s 0 ⟩⊗ (  U ˆ  |n⟩ ) +  |s 1 ⟩⊗ (  V ˆ |n⟩ )� . (S6)<br><!-- End of picture text -->

Here, _U_<sup>ˆ</sup> ( _V_<sup>ˆ</sup> ) describes the nuclear spin evolution with the electron spin state being _|s_ 0 _⟩_ ( _|s_ 1 _⟩_ ). To simplify the reading, we assume an additional _π_ -pulse at the end of the sequence for even _N_ . This way, we preserve the electron spin state in the case of no nuclear spin being present. After a final _π/_ 2-pulse, the initial electron-spin state _|ψ⟩_ init = _|s_ 0 _⟩_ is preserved with a probability of: 

S17 



<!-- Start of picture text -->
1 + cos V 2 † U ˆ<br>� θ  ˆ �<br>P ( s 0) = . (S7)<br>2<br><!-- End of picture text -->

Here, _θ_ ˆ _V †_ ˆ _U_ is the rotation angle of the nuclear spin during the operation _V_<sup>ˆ</sup><sup>_†_ˆ</sup> _U_ . 

S18 

### **B. Hahn echo and modulation** 

The Hahn echo is a particular case of the decoupling sequence with _N_ = 1, in which _U_<sup>ˆ</sup> and _V_<sup>ˆ</sup> are simply: 



<!-- Start of picture text -->
U ˆ = U ˆ1  · U ˆ0 . (S8)<br><!-- End of picture text -->



<!-- Start of picture text -->
V ˆ = U ˆ0  · U ˆ1 . (S9)<br><!-- End of picture text -->

The operators _U_<sup>ˆ</sup> _i_ are described in equation (S5). Taking advantage of trigonometric identities 

cos( _θ_ 1 _,_ 0 _/_ 2) = cos( _θ_ 1 _/_ 2) cos( _θ_ 0 _/_ 2) _−_ sin( _θ_ 1 _/_ 2) sin( _θ_ 0 _/_ 2) **n** 1 _·_ **n** 0 _._ (S10) 

sin( _θ_ 1 _,_ 0 _/_ 2) **n1** _,_ **0** = cos( _θ_ 1 _/_ 2) sin( _θ_ 0 _/_ 2) **n** 0 + cos( _θ_ 0 _/_ 2) sin( _θ_ 1 _/_ 2) **n** 1 + sin( _θ_ 1 _/_ 2) sin( _θ_ 0 _/_ 2) **n** 1 _×_ **n** 0 _,_ (S11) 

we obtain the well-known equation: 



<!-- Start of picture text -->
P ( s 0) = 1  − k (S12)<br>4 (2  − 2 cos( ω 0 τ )  − 2 cos( ω 1 τ ) + cos( ω + τ ) + cos( ω−τ ))  .<br><!-- End of picture text -->

Here, _ω±_ = _ω_ 0 _± ω_ 1, and _k_ being the so-called modulation depth parameter: 



<!-- Start of picture text -->
k = , (S13)<br>� ωωL 0 Aω 1 ⊥ �2<br><!-- End of picture text -->

with _ωL_ = _γnB_ being the nuclear spin Larmor frequency. 

S19 

### **C. CPMG resonances** 

For an even number _N_ of _π_ -pulses, the decoupling sequence can be written as: ( _τ_ - _π_ - _τ_ - _τ_ - _π_ - _τ_ )<sup>_N/_2</sup> , and the operators _U_ ˆ and _V_ ˆ as: 



<!-- Start of picture text -->
U ˆ = � U ˆ0  · U ˆ1  · U ˆ1  · U ˆ0� N/ 2 = � U ˆ D, 1  · U ˆ D, 0� N/ 2 , (S14)<br>V ˆ = � U ˆ1  · U ˆ0  · U ˆ0  · U ˆ1� N/ 2 = � U ˆ D, 0  · U ˆ D, 1� N/ 2 . (S15)<br><!-- End of picture text -->

Here, _U_<sup>ˆ</sup> _D,i_ is the composed rotation operator applied to the nuclear spin with the electron spin being in the state _|si⟩_ for a time _τ_ and additionally in the state _|s_ 1 _−i⟩_ for another time _τ_ . 

To optimize nuclear spin manipulation fidelity, we are now interested in the optimum (resonant) waiting time _τr_ at which _U_<sup>ˆ</sup> and _V_<sup>ˆ</sup> are anti-parallel. From equation (S11), we obtain anti-parallel rotation axes if, and only if: 



<!-- Start of picture text -->
cos( θD, 0) = cos( θD, 1) = 0 & n D, 0  ×  n D, 1 ̸ = 0 . (S16)<br><!-- End of picture text -->

With equation (S10), we obtain the condition for anti-parallel rotation axes: 



<!-- Start of picture text -->
tan( ω 0 τr/ 2) tan( ω 1 τr/ 2) = ( n 0  ·  n 1) − 1 (S17)<br><!-- End of picture text -->

Interestingly, for periodic waiting times _τk_ = (<sup><u>(</u></sup> _ω_<sup>2</sup><sup>_k_</sup> 0<sup>_−_</sup> +<sup>1</sup> _ω_<sup><u>)</u></sup> 1<sup>_π_</sup> )<sup>with</sup><sup>_k∈_N+,wehavetan(</sup><sup>_ω_0</sup><sup>_τk/_2) tan(</sup><sup>_ω_1</sup><sup>_τk/_2) = 1.Wefind</sup> further that in the case of negligible perpendicular hyperfine coupling ( _|A⊥| ≪_ �� _A∥_ �� _, |ωL|_ ), and with the definition of **n** _i_ in equation (S4), both rotation axes are along the _z_ -axis. The inverse vector product is then ( **n** 0 _·_ **n** 1)<sup>_−_1</sup> _≈_ 1. Therefore, we find: 



<!-- Start of picture text -->
τr =  τk = (2 k − 1) π . (S18)<br>ω 0 +  ω 1<br><!-- End of picture text -->

This equation represents the zero order approximation, which is exact in the asymptotic cases _B →∞_ or _A⊥_ = 0. For more realistic and general cases, the equation needs to be extended with correction terms. In the next section we develop the analytic expression for the first order correction term in ( _A⊥/B_ )<sup>2</sup> , and we define the criteria for the validity range of the approximation. 



<!-- Start of picture text -->
1. 1 st order correction<br><!-- End of picture text -->

We assume _τ_ = _τk_ (1 + _ϵτ_ ), with _ϵτ ≪_ 1. The left side in equation (S17) can be written as a first-order Taylor expansion: 



<!-- Start of picture text -->
tan( ω 0 τ/ 2) tan( ω 1 τ/ 2) = 1 +  ϵτ · sin( (2 k ω  − 0 τ 1 k ) / π 2) +  O ( ϵ τ 2 ) . (S19)<br><!-- End of picture text -->

Then, solving equation (S17) for _ϵτ_ results in: 



<!-- Start of picture text -->
ϵτ = sin( ω 0 τk/ 2) ( n 0  ·  n 1) − 1  − 1 . (S20)<br>(2 k − 1) π<br><!-- End of picture text -->

Considering the vector product in the numerator, one sees from this equation that _ϵτ →_ 0 for _B →∞_ . We now develop an expression to define the magnetic field range _B_ crit _≤ B ≤∞_ in which the approximation is valid. In other words, given a nuclear spin with coupling terms _A∥_ and _A⊥_ , which is the minimum required magnetic field _B_ crit in which the approximation _τr_ = _τk_ (1 + _ϵτ_ ) is valid? To have a negligible contribution from all higher order terms in _O_ ( _ϵ_<sup>2</sup> _τ_<sup>),wewant</sup><sup>_ϵ_2</sup> _τ_<sup>_≪ϵτ_,whichtranslatesto(</sup><sup>**n**0</sup><sup>_·_</sup><sup>**n**1)</sup><sup>_−_1</sup><sup>_−_1</sup><sup>_≪π_.</sup> 

S20 

_2. Validity range for the approximated resonance approximation_ 

From equation (S4), we have: 



<!-- Start of picture text -->
A⊥ · ωL<br>( n 0  ·  n 1) − 1 = � 1 + � s 1 s 0  ·  ( A 2 ⊥ +  A 2 ∥ )  − ( s 0 +  s 1)  · A∥ · ωL  +  ω L 2 �2 . (S21)<br><!-- End of picture text -->

Therefore, we can define an equivalence as: 



<!-- Start of picture text -->
A⊥ · ωL<br>( n 0  ·  n 1) − 1 − 1  ≤ ϵn ⇔ ��� s 0 s 1  ·  ( A 2 ⊥ +  A 2 ∥ )  − ( s 0 +  s 1)  · A∥ · ωL  +  ω L 2 ��� ≤ � (1 +  ϵn ) 2 − 1 . (S22)<br><!-- End of picture text -->

Here, _ϵn ≪_ 1 is a parameter that is related to the magnitude of the correction term in equation (S19). The last inequality is solved for two solutions: 



<!-- Start of picture text -->
A 2 ⊥ +  A 2 ∥<br>ωL  +  A− +  s 0 s 1 ≥ 0 , and (S23)<br>ωL<br>A 2 ⊥ +  A 2 ∥<br>ωL  +  A + +  s 0 s 1 ≤ 0 , (S24)<br>ωL<br><!-- End of picture text -->

with _A±_ = ( _s_ 0 + _s_ 1) _A∥ ±_ _~~√~~_ (1+ _<u>|Aϵ⊥n|</u>_ )<sup>2</sup> _−_ 1<sup>.Asrequiredabove,weareinterestedinthesolutionthatcoversthecase</sup> _B →∞_ , ( _B_ crit _≤ B ≤∞_ ). Because _ωL_ = _γnB_ , the correct set of solutions depends on the sign of the gyromagnetic ratio _γn_ . If _γn_ is positive (negative), the inequality to solve is equation (S23) (equation (S24)). To determine the critical magnetic field _B_ crit, we use the following equation: 



<!-- Start of picture text -->
ωL 2 +  A sign( γn ) · ωL +  s 0 s 1( A ⊥ 2 +  A 2 ∥ ) = 0 , (S25)<br><!-- End of picture text -->

in which sign( _γn_ ) = _γn/|γn|_ . Finally we have: 



<!-- Start of picture text -->
A sign( γn ) + sign( γn ) � A 2 sign( γn ) − 4 s 0 s 1( A ⊥ 2 +  A 2 ∥ )<br>( n 0  ·  n 1) − 1 − 1  ≤ ϵn ⇔ B ≥ B crit = . (S26)<br>2 γn<br>we have:<br>|A⊥|<br>A sign( γn ) = ( s 0 +  s 1) A∥ + sign( γn ) . (S27)<br>� (1 +  ϵn ) 2 − 1<br><!-- End of picture text -->

Here, we have: 

We now limit the first-order correction to 10% ( _ϵτ ≤_ 0 _._ 1) to keep higher order terms at a negligible level. This means that _ϵn_ = 0 _._ 1 _· π_ . With this, we can express the denominator in equation (S27) as 1 _/_ ~~�~~ (1 + _ϵn_ )<sup>2</sup> _−_ 1 _≈_ 1 _._ 17. We thus obtain the following theorem for the first-order approximation of the CPMG resonance times _τr_ : 

**Theorem.** _For given nuclear spin hyperfine coupling terms A∥ and A⊥, and in an external magnetic field along the z-axis with strength B, the CPMG resonances occur at:_ 



<!-- Start of picture text -->
τ approx ( k ) = (2 ω k 0  −  +  ω 1) 1 π �1 + sin� (2(2 kω − 0 +1)  ωπω 1)0 � ( n 0(2  ·  n k − 1) − 1)1  −π 1 � , (S28)<br><!-- End of picture text -->

_with k ∈_ N<sup>+</sup> _. This equation is valid as long as B ≥ B_ crit _, with:_ 



<!-- Start of picture text -->
Asign ( γn ) + sign( γn ) � A 2 sign( γn ) − 4 s 0 s 1( A ⊥ 2 +  A 2 ∥ )<br>B crit = , (S29)<br>2 γn<br>A sign( γn ) = ( s 0 +  s 1) A∥ + 1 . 17  ·  sign( γn ) |A⊥|. (S30)<br><!-- End of picture text -->

