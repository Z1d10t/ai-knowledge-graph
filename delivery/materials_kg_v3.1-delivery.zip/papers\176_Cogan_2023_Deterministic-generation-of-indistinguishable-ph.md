# Deterministic generation of indistinguishable photons in a cluster state

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Photonics |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 173 |
| 作者 | D. Cogan, Zu-En Su, O. Kenneth, D. Gershoni |
| DOI | 10.1038/s41566-022-01152-2 |
| 源文件 | 076_Cogan_2023_Deterministic-generation-of-indistinguishable-ph.pdf |

---
**Article** 

## **nature photonics** 

https://doi.org/10.1038/s41566-022-01152-2 

# **Deterministic generation of indistinguishable photons in a cluster state** 

|Received: 20 October 2022|**Dan Cogan**<br>**, Zu-En Su, Oded Kenneth & David Gershoni**<br>|
|---|---|
|Accepted: 19 December 2022||
|Published online: 9 February 2023<br>Check for updates|Entanglement between particles is a basic concept of quantum sciences. The<br>ability to produce entangled particles in a controllable manner is essential<br>for any quantum technology. Entanglement between light particles|
||(photons) is particularly crucial for quantum communication due to light’s<br>non-interactive nature and long-lasting coherence. Resources producing<br>entangled multiphoton cluster states will enable communication between<br>remote quantum nodes, as the inbuilt redundancy of cluster photons<br>allows for repeated local measurements—compensating for losses and<br>probabilistic Bell measurements. For feasible applications, the cluster<br>generation should be fast, deterministic and, most importantly, its photons<br>indistinguishable, which will allow measurements and fusion of clusters by<br>interfering photons. Here, using periodic excitation of a semiconductor<br>quantum-dot-confined spin, we demonstrate a multi-indistinguishable<br>photon cluster, featuring a continuously generated string of photons at<br>deterministic gigahertz generation rates, and an optimized entanglement<br>length of about ten photons. The indistinguishability of the photons<br>opens up new possibilities for scaling up the cluster’s dimensionality by<br>fusion, thus building graph states suited for measurement-based photonic<br>quantum computers and all-photonic quantum repeaters.|



Entanglement is a fundamental concept of quantum mechanics<sup>1</sup> . The ability to generate, impose, control and distribute entanglement is crucial for quantum technologies, quantum information processing and, in particular, quantum networking<sup>2</sup> . The non-interacting nature of photons, which protects them from dephasing, makes them a natural carrier for quantum communication; however, as photons do not mutually interact, their use for entanglement distribution is challenging. Zeilinger, Pan and co-workers introduced second-order interference between indistinguishable photons as a way to partially overcome this problem<sup>3,4</sup> . Photon indistinguishability (ID) is therefore a major prerequisite for entanglement distribution and photonic quantum repeaters. The unavoidable photon loss that exponentially limits the success probability of any communication protocol with distance, and the probabilistic nature of the interference remain as barriers that prevent the development of a full-fledged quantum network. Overcoming the exponential loss is possible using the concept of quantum repeaters<sup>5</sup> , in which entanglement swapping and 

purification performed at intermediate nodes enable entanglement distribution between distant nodes with photons<sup>6</sup> . 

Inspired by measurement-based quantum computation<sup>7,8</sup> , Zwerger and co-workers introduced the idea of measurement-based quantum repeaters<sup>9</sup> . This network architecture uses multiphoton entangled states—cluster or graph states<sup>10–13</sup> —that can be distributed and mutually connected through Bell measurements. Azuma and co-workers<sup>14</sup> recently extended this idea by making the repeater graph exclusively photonic, thereby removing the need for long-lived quantum memory. Graph states provide redundancy against photon loss and the probabilistic nature of photonic Bell measurements: if the first measurement fails, more trials will substantially increase the probability of success. An essential requirement from such graph states is that the photons be indistinguishable. Developing devices that are capable of deterministically producing indistinguishable photonic graph states is therefore an important scientific and technological challenge to overcome<sup>15–19</sup> . 

The Physics Department and the Solid State Institute, Technion — Israel Institute of Technology, Haifa, Israel. 

e-mail: dg@physics.technion.ac.il 

Nature Photonics | Volume 17 | April 2023 | 324–329 

**324** 

https://doi.org/10.1038/s41566-022-01152-2 

#### **Article** 

Single and entangled photons can be generated via the spontaneous emission of an optical transition of an atom or an atom-like quantum emitter<sup>1,20</sup> . Artificial atoms such as semiconductor quantum dots (QDs) have demonstrated tremendous performance as they can be incorporated into electro-optical devices, which dovetail with the contemporary semiconductor-based industry. Semiconductor QD-based devices have shown high efficiencies and photon emission rates (see ref.<sup>21</sup> for a review), placing them as the forerunner of all physical systems considered for generating quantum light<sup>9,12,14,15,22</sup> . 

Of particular relevance to this work is Lindner and Rudolph’s<sup>23</sup> proposal to generate one-dimensional photonic cluster states using semiconductor QDs. Their scheme uses a single QD-confined electron spin precessing in a magnetic field while driven by a temporal sequence of laser pulses. Following excitation of the QD, a single photon is deterministically emitted, and its polarization is entangled with the state of the QD-confined spin<sup>24</sup> . This process repeats many times to generate a large one-dimensional cluster of entangled photons. 

The entanglement robustness of such a photonic cluster is mainly determined by the ratio between the optical transition radiative and spin precession rates<sup>25</sup> , and by the coherence properties of the QD spin<sup>26,27</sup> . The ID between the emitted photons is mainly determined by the nature of the optical transition, which results in photon emission<sup>28</sup> . Schwartz and colleagues demonstrated a modification of this proposal by generating a one-dimensional cluster state based on a QD-confined dark exciton<sup>29</sup> as a photon entangler, and by characterizing the cluster entanglement length<sup>25</sup> . During generation, the emitted photons leave the dark exciton in an excited state, having a shorter lifetime than the radiative time. Consequently, the instability of the final state introduces spectral broadening to the energy profiles of the photons, resulting in non-identical photonic emission. 

Here we present an on-demand, continuously generated string of indistinguishable photons entangled in a cluster state. We use the heavy-hole (HH) spin<sup>26,30,31</sup> as an entangler, utilizing the fact that the HH is left in a stable ground state after photon emission; thus, as we show below, the emitted single photons are highly indistinguishable. Moreover, the HH has a half-integer spin; therefore, in the absence of external magnetic field, its two spin states are Kramers’ degenerate and its precession rate vanishes. Fine-tuning of the external field’s strength provides means for controlling the spin precession and photon emission rates, as well as optimization of the entanglement robustness in the cluster state. 

We follow ref.<sup>23</sup> , as schematically described in Fig. 1a, by applying a periodic sequence of controlled-not (CNOT) and Hadamard gates on the HH for producing the cluster state. Figure 1b,c schematically describes the QD-based device, and the experimental system for generating the cluster and its characterization, respectively. Each laser pulse (red upwards arrows) excites the confined HH (|| _h_ ⟩= |⇑⟩) to the excited-positive trion state (| _T_<sup>∗</sup> ⟩= |⇑⇓↑⟩*), in which the electron resides in its respective second energy level. The electron decays to the trion ground (| _T_ ⟩) level within about 5 ps by emitting a spin-preserving optical phonon<sup>32,33</sup> . The trion then recombines within about 400 ps, by emitting a photon (marked pink), leaving the HH at its ground level (|| _h_ ⟩). A dichroic mirror steers the emitted photons to the detectors. 

Both the HH and the positive trion act as spin qubits<sup>34</sup> . The selection rules for the optical transitions (see Fig. 1b) associated with the excitation and emission result in entanglement between the photon polarization and the HH spin polarization (see the Supplementary Information). Each excitation–emission step is therefore an actual realization of a CNOT gate between the spin and the photon qubits. We realize the Hadamard gate on the spin qubit by timing the excitations to the field-induced HH precession, such that after each excitation and photon emission, the spin acquires a π/2 phase before it is excited again. A sequence of resonantly tuned, linearly polarized laser π-pulses experimentally realizes the deterministic generation of the cluster state (Fig. 1c). Each pulse results in the addition of an entangled photon 

to the cluster state. As the cluster protocol is made by repeating an identical cycle, composed of excitation, emission and spin rotation, one can characterize the entire cluster state by mapping the process of this identical cycle. We perform full process tomography of the identical cycle for an externally applied magnetic field of 0.12 T (see the Supplementary Information). We measured four cluster witnesses for all of the other magnetic field strengths, as described below. For these purposes, it is enough to apply three cycles of the protocol and to detect the three photons, which the QD emits as a result<sup>25</sup> . For the photon detection and their polarization projection, we use six single-photon detectors in the set-up as described in Fig. 1c. In Fig. 1d we present the time-resolved single-photon detection rates as recorded by each of these six detectors for six different magnetic field strengths. For each field strength, we timed the excitation to match one-quarter of the HH spin precession period plus a small addition compensating for the finite trion’s radiative time. At the specific field strength of about 0.09 T, the HH precession is such that the appropriate excitation rate is exactly six-times faster than the laser repetition rate (~76 MHz). Under these finely tuned synchronization conditions, the device continuously generates a string of entangled photons, thereby realizing the original proposal of ref.<sup>23</sup> , albeit by using the HH rather than electron spin. 

We then consider all of the events in which two and three photons are detected sequentially. In Fig. 1e (Fig. 1f) we present the time-resolved degree-of-circular-polarization ( _D_ cp) measurements of the second (third) sequentially detected photon. We use these measurements to monitor the trion’s spin evolution during its radiative decay and hence determine the HH spin state before excitation<sup>35,36</sup> . We note that these time-resolved measurements are only used as characterization method enabling independent hole spin tomography. They are not part of the cluster generation protocol. We extract the following four cluster state witnesses from these measurements: _w_ 3 = _P_<sup>(</sup> _Z_<sup>_n_−1)</sup> _P_<sup>(</sup> _X_<sup>_n_)</sup><sup>_SZ_and ̂</sup><sup>_w_4=</sup><sup>_P_(</sup> _Z_<sup>_n_−1)</sup> _P_<sup>(</sup> _X_<sup>_n_)</sup><sup>_P_(</sup> _Z_<sup>_n_</sup> ̂ _w_<sup>+1</sup> 1<sup>)</sup> , where = _P_<sup>(</sup> _Z_<sup>_n_−1)</sup> _SPY_<sup>(</sup> _j_ ,<sup>_i_) represents the</sup> ̂ _w_ 2 = _P_<sup>(</sup> _Z_<sup>_n_−1)</sup> _P_<sup>(</sup> _Z_<sup>_n_),</sup> polarization of the _i_ th photon in the string, projected onto the _jt_ h polarization state; and _Sj_ is the polarization of the HH spin, projected onto the _j_ th state. We note that ̂ _w_ 1 and ̂ _w_ 3 are directly extracted from the polarization of correlated detection of two- and three-photons, shown in Fig. 1e,f, respectively, whereas ̂ _w_ 2 and ̂ _w_ 4 are extracted from the temporal integration of these measurements over the photon’s lifetime. For an ideal cluster state (containing ideal CNOT and Hadamard gates), ̂ _w_ 1,̂ _w_ 3 and ̂ _w_ 4 equal 1, whereas ̂ _w_ 2 equals 0. 

In Fig. 1g we present the four measured witnesses as a function of the magnetic field strength. The solid lines are the calculated witnesses using our state-evolution-model (see the Suppementary Information). The parameters used for the model calculations were independently measured and listed in ref.<sup>36</sup> . A good quantitative agreement between the measured data and the calculations is obtained. 

We now turn to measure the ID between two sequential photons in the cluster state by using the same set-up used by Hong, Ou and Mandel<sup>4,37</sup> , as illustrated in Fig. 2a. The ID is given by the ratio between the second-order interference of co- to cross-polarized photons, as displayed in Fig. 2b for various magnetic fields. At zero magnetic field, the cluster photons’ ID amounts to 95%. The ID between photons emitted from a quantum source of single photons depends on the temporal stability of the initial and final states<sup>28</sup> . Here the final state is the temporally stable ground state of the HH, hence the high ID of the cluster photons (see the Supplementary Information). 

The externally applied magnetic field reduces the ID of the cluster photons. As the field increases, the ID decreases due to the field-induced spectral broadening. At large fields, when the Zeeman splitting surpasses the radiative linewidth (see the Supplementary Information), the averaged (over both polarizations) ID drops to 50% and quantum beats are observed in the time-resolved correlation measurements<sup>38</sup> . 

We measured the ID between consecutive photons only. Past measurements performed on similar InAs/GaAs QD samples have shown 

Nature Photonics | Volume 17 | April 2023 | 324–329 

**325** 

**Article** 

https://doi.org/10.1038/s41566-022-01152-2 



<!-- Start of picture text -->
a c d e f<br>Th /4 + 0.7 ns × 104 PZ ( n –1)  P ( Zn ) PZ ( n –1)  PX ( n )  P ( Zn +1)<br>H H H || TT *�� OP (~5 ps) 10 B  = 0.03 T 0.8<br>|0� n +1 5 0<br>|0� n (12 ps) P (400 ps)( jn –1) P ( jn ) P ( jn +1) 100 0.06 –0.80.8<br>| h � 5 0<br>|0� n –1 LCVR PBS<br>0 –0.8<br>D1 D3 D5<br>10 0.09 0.8<br>D2 D4 D6<br>5 0<br>b Trion* g 0 –0.8<br>| T + Z � | T – Z � 1 10 0.8<br>Trion w ˆ 1 5 0.12 0<br>− Z + Z Z Y<br>Hole 0 –0.8<br>| h + Z � | h – Z � ˆ 10 0.8<br>w 3 0.25<br>966 nm 0.5 w ˆ 4 Z X Z 5 0<br>DM Z X Z 0 –0.8<br>0.8<br>10<br>0.5<br>Z ˆ 4 K w ˆ 2 5 0<br>Z Z<br>B 0 0 0.1 0.2 0.3 0.4 0.5 0 –5 0 5 0 1 2 0 1 2 –0.8<br>B  (T) Time (ns) Time (ns) Time (ns)<br>cp D<br>cp D<br>cp D<br>cp D<br>949 nm<br>cp D<br>Witness Photon rates (counts per sec per 30 ps bin)<br>cp D<br><!-- End of picture text -->

**Fig. 1 | The measured cluster witnesses. a** , Ideal description of the cluster state generation using sequential Hadamard and CNOT gates. **b** , A schematic of the QD-based device. DM represents a dichroic mirror and ⃗ _B_ = _B_ ̂ _x_ the externally applied magnetic field. The inset shows the polarization selection rules for the optical transition. The terms || _h_ ⟩ (|⇑⟩), | _T_ ⟩ and | _T_<sup>∗</sup> ⟩ represent the HH, trion and excited trion states, respectively; ± _Z_ represents the photon’s circular polarization along the optical axis and also the spin state’s direction. Red (pink) arrows represent laser pulses (emitted photons), whereas spiral arrows represent optical-phonon-assisted transitions. **c** , Schematic description of the QD’s spin-configurations optical transitions and their detection used in the measurements. The pink exponentials represent emitted single photons; _Th_ is the HH spin precession period. We detect two and three consecutive photons from the cluster and project their polarization using liquid crystal variable retarders (LCVR) and polarized beam splitters (PBS); _P_<sup>(</sup> _j_<sup>_i_) represents the polarization of the</sup><sup>_i_th</sup> photon in the cluster, projected onto the _j_ th polarization state. **d** , Time-resolved single photon rate measurements for various magnetic fields. At ~0.09 T, the HH 

precession is such that the appropriate excitation rate is exactly six times faster than the laser repetition rate (~76 MHz), resulting in deterministic generation of a continuous string of photons. **e** , **f** , Two- ( **e** ) and three-photon ( **f** ) correlations; red marks are the time-resolved measurement of the last correlated photon’s _D_ cp as a function of time from the second (third) pulse. These _D_ cp values are correlated with the previous detection of an emitted photon in **e** and two photons in **f** . Blue lines represent the best fitted central-spin-evolution model for the positive trion<sup>26,35</sup> . **g** , The measured (error bars) and calculated (coloured lines) cluster state witnesses as deduced from the fits in **e** and **f** versus the in-plane magnetic field strength. Strings of polarized photons (pink circles) and spin (yellow circles) describe the witnesses; ̂ _w_ 1 and ̂ _w_ 3 are deduced from the polarization of the correlated detection of two- and three-photons, as shown in **e** and **f** , respectively; ̂ _w_ 2 and ̂ _w_ 4 are deduced by temporally integrating these responses over one radiative lifetime. The error bars represent statistical 1 s.d. uncertainties deduced from a temporally integrated total number of about 500,000 two- and 50,000 three-sequential photons detection events. 

that the ID does not degrade much over time differences of about 1.5 μs (refs.<sup>39,40</sup> ). To fuse various sections from the one-dimensional cluster to form higher-dimensionality clusters, the ID should remain high for times comparable with the product of the entanglement length and the photon generation period (about 20–30 ns, only). This value is much shorter than the expected, characteristic decay time of the ID in our QD sample. 

Figure 3 summarizes the ID properties of the cluster photons, the robustness of the generated entanglement and the photon generation rate as a function of the applied magnetic field. 

The entanglement robustness is quantified using localizable entanglement (LE)<sup>41</sup> , defined as the magnitude of the entanglement between two qubits in the cluster after all of the other qubits are projected onto suitable bases. The localizable entanglement decays exponentially with the distance between the two qubits<sup>25,41</sup> . Thus _ζ_ LE, defined as the characteristic decay length of the localizable entanglement, is a figure of merit characterizing the robustness of the entanglement in the cluster. Our device continuously generates a string of entangled photons. One can select various lengths of consecutive photons from this string by projecting the first and last photons onto the _z_ -polarization basis, thereby disentangling the hole spin from the photonic string. All of the photons in the strings are entangled, of course, but the localizable entanglement in the string decays exponentially with 

a characteristic decay length of _ζ_ LE photons. Figure 3 presents _ζ_ LE versus the magnetic field strength, where _ζ_ LE is deduced from the ratio between two of the measured witnesses (red diamonds) according to: 



<!-- Start of picture text -->
ζ LE = −1/ ln (̂ w 3/̂ w 1) . (1)<br><!-- End of picture text -->

The difference between these two witnesses is simply the _D_ cp loss due to the application of a single cycle of the protocol. To strengthen our findings, we fully measure the process map of a single cycle of the protocol for a field strength of 0.12 T. The measured map has fidelity of 0.90 ± 0.01 to the ideal process map (see Supplementary Information). The fact that the entire protocol is made of a periodic repetition of exactly the same cycle<sup>23</sup> enables us to model multiple applications of the measured process map on the spin and thereby calculate the negativity between two qubits in the string as a function of their mutual distance (localizable entanglement). The negativity decays with a characteristic decay length _ζ_ LE of about 8 ± 1 (red circle in Fig. 3). To complete our analysis, the measured _ζ_ LE versus magnetic field is compared also with our state-evolution model (solid red line), as described in the Supplementary Information and ref.<sup>36</sup> . 

Figure 3 clearly shows an optimum for the entanglement robustness at _Bx_ = 0.09 T, in which _ζ_ LE ≃ 10. For stronger fields, the precession period becomes shorter. As a result, the ratio between the radiative 

Nature Photonics | Volume 17 | April 2023 | 324–329 

**326** 

**Article** 

https://doi.org/10.1038/s41566-022-01152-2 



<!-- Start of picture text -->
a b<br>Pol. B  (T) I nd<br>Co 0 0.95<br>t 2 TT Co 0.06 0.88<br>D2<br>Co 0.09 0.80<br>t 1 1 Co 1.00 0.51<br>Cross --<br>D1<br>0.8<br>λ /2<br>NPBS<br>0.6<br>TG 0.4<br>Pol.<br>LCVR<br>0.2<br>0<br>−1 0 1<br>t 2 −  t 1 (ns)<br>Correlation intensity (a.u.)<br><!-- End of picture text -->

**Fig. 2 | Photon ID. a** , The interferometer set-up. Two consecutive cluster photons interfere on a non-polarizing beam splitter (NPBS). Two detectors on the output ports register their detection times, _t_ 1 and _t_ 2, respectively. A half-wave plate ( _λ_ /2) is used to select the photons’ relative polarization state between co- and cross-linear polarization. A pair of LCVRs and a linear polarizer (Pol.) project the photons’ polarization, and a transmission grating (TG) filters their energy. **b** , ID measurements (averaged over both rectilinear polarizations H and V) between two consecutive cluster photons for various externally applied magnetic fields. The solid lines represent the measured second-order correlation function _g_<sup>(2)</sup> ( _t_ 2 − _t_ 1) using 50,000 two-sequential photon correlation events. In each period (13 ns apart) there are five correlation peaks<sup>37</sup> . Only the central peak, which results from the interference of the two photons, is shown. The other four peaks form the measured background. As they are polarization independent, they can be straightforwardly subtracted from the measured interference. The measured ID is then defined as _I_ nd = 1 − _A_ co/ _A_ cross, where _A_ co ( _A_ cross) is the area under the co (cross)polarized correlation function, represented by the coloured (black) solid lines. 

and precession times becomes larger, increasing the deviation of the two-qubit gate from the ideal CNOT gate. For weaker fields, the time difference between consecutive pulses increases to a level in which the HH spin dephasing becomes notable. 

To complete the device characterization, Fig. 3 also presents the measured ID (in blue) and the cluster generation rate (in black) versus the magnetic field strength. The ID monotonically decreases from 95% as the field increases. This decrease is due to the onset of quantum beats<sup>38</sup> caused by the Zeeman splitting of the optical transition. 

The time between consecutive laser pulses is set to approximately match one-quarter of a precession period. The photon generation rate therefore monotonically increases as a function of the magnetic field. At the optimum point, the generation rate is about 0.5 GHz. The cluster photon generation is deterministic. This means that every laser π-pulse results in the QD spin excitation and emission of an entangled photon. The photon detection, however, is not deterministic as not every emitted photon is detected. The overall detection efficiency of our system is currently better than 1%. The main losses are due to limited light harvesting efficiency from the planar microcavity containing the QD (~20%), free space into fibre coupling (~50%), detector efficiency (~80%) and the overall optical-elements transmission efficiency (~15–20%). After detecting a photon, the detectors have about 25 ns dead-time, in which they cannot detect another photon. We use multiple detectors to detect sequential photons that the device emits about every 2 ns. 



<!-- Start of picture text -->
16 1.6<br>14 1.4<br>12 1.2<br>10 1.0<br>8 0.8<br>6 0.6<br>4 0.4<br>2 0.2<br>0 0.1 0.2 0.3 0.4 0.5<br>Magnetic field (T)<br>Entanglement length (qubits) indistinguishabilityRate (GHz)\<br><!-- End of picture text -->

**Fig. 3 | Cluster characterization.** The localizable entanglement characteristic length, photon ID and generation rate of the cluster state as a function of the magnetic field. Error bars represent statistical uncertainty of 1 s.d. and standard error propagation calculations. The localizable entanglement and the ID are deduced from the measurements described in Figs. 1 and 2, respectively. The error bars in the photon generation rates result mainly from the experimental uncertainty in the hole’s _g_ -factor. The lines represent calculations in which the process map was obtained from our state-evolution model. The red circle represents the localizable entanglement length at _B_ = 0.12 T, at which the full process map was measured. See the Supplementary Information for more details. 

This further reduces the detection efficiency of multiphoton events. The total single photon detection rate is about 5 MHz with the current system efficiency. The detection rate of four-consecutive photon events is a few hertz only. This detection rate is more than enough to demonstrate and characterize our cluster-state-generating device which, due to the repetitive nature of its production, requires detection of only two and three consecutive photon events. We emphasize here that the non-deterministic detection does not affect the length of the photon string that we generate. It only makes the probability to detect a sequentially larger number of photons exponentially lower. There is an obvious need to improve both the device brightness and the collection efficiency of the optical system so that the generated cluster can be exploited in practical protocols. A clear way to increase the brightness is to embed the QD into a three-dimensional photonic microcavity. This can be achieved either by nanofabrication techniques<sup>21,42</sup> or by including a tunable, open cavity<sup>40</sup> in the optical set-up. Both ways are expected to maintain the determinism of the generated cluster while increasing the brightness of the device fourfold, making it close to a deterministic source. At the same time, a better mode matching to the single-mode fibre should also increase the optical system efficiency. Feasible increasing of the overall system efficiency to 50%<sup>40</sup> will result in a four-photon detection rate of a few tens of megahertz, enabling 25-photon correlation measurement rates of a few hertz. At the same time, a three-dimensional microcavity can considerably shorten the radiative lifetime due to the Purcell effect<sup>21,40,42</sup> . This, in turn, will considerably improve all three cluster states’ figures of merit; the entanglement quality, the ID and the generation rate. The entanglement quality improves by reducing the ratio between the radiative time and the precessions of the spin qubit. The ID improves by broadening the radiative spectral width, thereby reducing the distinguishability due to the Zeeman splitting induced quantum beats. The generation rate increases since the sweet point moves to larger fields. A feasible Purcell factor of ten, for example, is expected to increase the entanglement decay length to about 55 consecutive photons at the sweet point, the ID to better than 90% (limited by the excitation temporal jitter) and the photon generation rate to above 2 GHz (detection rate of single photons to more than 1 GHz). 

In summary, we demonstrate a gigahertz-rate deterministic and continuous generation of strings of indistinguishable photons 

Nature Photonics | Volume 17 | April 2023 | 324–329 

**327** 

**Article** 

https://doi.org/10.1038/s41566-022-01152-2 

entangled in a cluster state. Our device uses a QD-confined HH spin as the photon entangler, and is optimized by tuning the externally applied magnetic field to achieve a characteristic entanglement decay length of about ten photons, and a photon ID of about 80%. A feasible enhancement of the radiative rate by one order of magnitude is expected to boost the entanglement length to about 55, the photons’ ID to more than 90% and the photon generation rate at these conditions to 2 GHz. The current values may already be used for efficient fusion of cluster states to generate more complicated graph states for demonstrating all-photonic quantum repeaters. Demonstrating this functionality requires better light harvesting efficiencies, as recently demonstrated elsewhere. Our work therefore provides an essential building block for future large-scale quantum communication and information processing. 

### **Online content** 

Any methods, additional references, Nature Portfolio reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41566-022-01152-2. 

### **References** 

1. Aspect, A., Grangier, P. & Roger, G. Experimental realization of Einstein–Podolsky–Rosen–Bohm _Gedankenexperiment_ : a new violation of Bell’s inequalities. _Phys. Rev. Lett._ **49** , 91–94 (1982). 

2. Wehner, S., Elkouss, D. & Hanson, R. Quantum internet: a vision for the road ahead. _Science_ **362** , 303 (2018). 

3. Pan, J.-W., Bouwmeester, D., Weinfurter, H. & Zeilinger, A. Experimental entanglement swapping: entangling photons that never interacted. _Phys. Rev. Lett._ **80** , 3891–3894 (1998). 

4. Hong, C. K., Ou, Z. Y. & Mandel, L. Measurement of subpicosecond time intervals between two photons by interference. _Phys. Rev. Lett._ **59** , 2044–2046 (1987). 

5. Briegel, H.-J., Dür, W., Cirac, J. I. & Zoller, P. Quantum repeaters: the role of imperfect local operations in quantum communication. _Phys. Rev. Lett._ **81** , 5932–5935 (1998). 

6. Duan, L.-M., Lukin, M. D., Cirac, J. I. & Zoller, P. Long-distance quantum communication with atomic ensembles and linear optics. _Nature_ **414** , 413–418 (2001). 

7. Raussendorf, R. & Briegel, H. J. A one-way quantum computer. _Phys. Rev. Lett._ **86** , 5188–5191 (2001). 

8. Rudolph, T. Why I am optimistic about the silicon-photonic route to quantum computing. _APL Photon_ **2** , 030901 (2017). 

9. Zwerger, M., Dür, W. & Briegel, H. J. Measurement-based quantum repeaters. _Phys. Rev. A_ **85** , 062326 (2012). 

10. Briegel, H. J. & Raussendorf, R. Persistent entanglement in arrays of interacting particles. _Phys. Rev. Lett._ **86** , 910–913 (2001). 

11. Hein, M., Eisert, J. & Briegel, H. J. Multiparty entanglement in graph states. _Phys. Rev. A_ **69** , 062311 (2004). 

12. Buterakos, D., Barnes, E. & Economou, S. E. Deterministic generation of all-photonic quantum repeaters from solid-state emitters. _Phys. Rev. X_ **7** , 041023 (2017). 

13. Pichler, H., Choi, S., Zoller, P. & Lukin, M. D. Universal photonic quantum computation via time-delayed feedback. _Proc. Natl Acad. Sci. USA_ **114** , 11362–11367 (2017). 

14. Azuma, K., Tamaki, K. & Lo, H.-K. All-photonic quantum repeaters. _Nat. Commun._ **6** , 6787 (2015). 

15. Munro, W. J., Stephens, A. M., Devitt, S. J., Harrison, K. A. & Nemoto, K. Quantum communication without the necessity of quantum memories. _Nat. Photon._ **6** , 777–781 (2012). 

16. Larsen, M. V., Guo, X., Breum, C. R., Neergaard-Nielsen, J. S. & Andersen, U. L. Deterministic generation of a two-dimensional cluster state. _Science_ **366** , 369–372 (2019). 

17. Li, J.-P. et al. Multiphoton graph states from a solid-state single-photon source. _ACS Photon._ **7** , 1603–1610 (2020). 

18. Istrati, D. et al. Sequential generation of linear cluster states from a single photon emitter. _Nat. Commun._ **11** , 5501 (2020). 

19. Besse, J.-C. et al. Realizing a deterministic source of multipartite-entangled photonic qubits. _Nat. Commun._ **11** , 4877 (2020). 

20. Akopian, N. et al. Entangled photon pairs from semiconductor quantum dots. _Phys. Rev. Lett._ **96** , 130501 (2006). 

21. Senellart, P., Solomon, G. & White, A. High-performance semiconductor quantum-dot single-photon sources. _Nat. Nanotechnol._ **12** , 1026–1039 (2017). 

22. Appel, M. H. et al. Coherent spin-photon interface with waveguide induced cycling transitions. _Phys. Rev. Lett._ **126** , 013602 (2021). 

23. Lindner, N. H. & Rudolph, T. Proposal for pulsed on-demand sources of photonic cluster state strings. _Phys. Rev. Lett._ **103** , 113602 (2009). 

24. Berezovsky, J., Mikkelsen, M. H., Stoltz, N. G., Coldren, L. A. & Awschalom, D. D. Picosecond coherent optical manipulation of a single electron spin in a quantum dot. _Science_ **320** , 349–352 (2008). 

25. Schwartz, I. et al. Deterministic generation of a cluster state of entangled photons. _Science_ **354** , 434–437 (2016). 

26. Cogan, D. et al. Depolarization of electronic spin qubits confined in semiconductor quantum dots. _Phys. Rev. X_ **8** , 041050 (2018). 

27. Bechtold, A. et al. Three-stage decoherence dynamics of an electron spin qubit in an optically active quantum dot. _Nat. Phys._ **11** , 1005–1008 (2015). 

28. Kiraz, A., Atatüre, M. & Imamoğlu, A. Quantum-dot single-photon sources: prospects for applications in linear optics quantuminformation processing. _Phys. Rev. A_ **69** , 032305 (2004). 

29. Schwartz, I. et al. Deterministic writing and control of the dark exciton spin using single short optical pulses. _Phys. Rev. X_ **5** , 011009 (2015). 

30. Gerardot, B. D. et al. Optical pumping of a single hole spin in a quantum dot. _Nature_ **451** , 441–444 (2008). 

31. Brunner, D. et al. A coherent single-hole spin in a semiconductor. _Science_ **325** , 70–72 (2009). 

32. Benny, Y. et al. Excitation spectroscopy of single quantum dots at tunable positive, neutral, and negative charge states. _Phys. Rev. B_ **86** , 085306 (2012). 

33. Benny, Y. et al. Electron-hole spin flip-flop in semiconductor quantum dots. _Phys. Rev. B_ **89** , 035316 (2014). 

34. Loss, D. & DiVincenzo, D. P. Quantum computation with quantum dots. _Phys. Rev. A_ **57** , 120–126 (1998). 

35. Cogan, D., Peniakov, G., Su, Z.-E. & Gershoni, D. Complete state tomography of a quantum dot spin qubit. _Phys. Rev. B_ **101** , 035424 (2020). 

36. Cogan, D., Su, Z.-E., Kenneth, O. & Gershoni, D. Spin purity of the quantum dot confined electron and hole in an external magnetic field. _Phys. Rev. B_ **105** , L041407 (2022). 

37. Santori, C., Fattal, D., Vučković, J., Solomon, G. S. & Yamamoto, Y. Indistinguishable photons from a single-photon device. _Nature_ **419** , 594–597 (2002). 

38. Legero, T., Wilk, T., Hennrich, M., Rempe, G. & Kuhn, A. Quantum beat of two single photons. _Phys. Rev. Lett._ **93** , 070503 (2004). 

39. Wang, H. et al. Near-transform-limited single photons from an efficient solid-state quantum emitter. _Phys. Rev. Lett._ **116** , 213601 (2016). 

40. Tomm, N. et al. A bright and fast source of coherent single photons. _Nat. Nanotechnol._ **16** , 399–403 (2021). 

41. Verstraete, F., Popp, M. & Cirac, J. I. Entanglement versus correlations in spin systems. _Phys. Rev. Lett._ **92** , 027901 (2004). 

42. Liu, F. et al. High Purcell factor generation of indistinguishable on-chip single photons. _Nat. Nanotechnol._ **13** , 835–840 (2018). 

Nature Photonics | Volume 17 | April 2023 | 324–329 

**328** 

**Article** 

https://doi.org/10.1038/s41566-022-01152-2 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this 

article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons. org/licenses/by/4.0/. 

© The Author(s) 2023 

Nature Photonics | Volume 17 | April 2023 | 324–329 

**329** 

**Article** 

https://doi.org/10.1038/s41566-022-01152-2 

### **Methods** 

##### **The sample and optical system** 

At the heart of our device is an InGaAs self-assembled semiconductor QD, as illustrated in Fig. 1b. The QD contains a confined HH spin qubit<sup>26,30,31,34</sup> . We define the QD’s shortest dimension (~3 nm), the growth direction and the spin quantization axis as the _z_ -axis. The externally applied magnetic field direction is defined as the _x_ -axis. The QD is embedded in a planar microcavity, formed by two Bragg-reflecting mirrors, facilitating a light harvesting efficiency of about 20% by a 0.85 numerical aperture objective above the QD. 

The experimental system is schematically described in Extended Data Fig. 1. The pulsed laser light is resonantly tuned to the HH-excited trion optical transition<sup>36</sup> , and its power is set to a _π_ -area intensity. The polarization of the light is computer-controlled using pairs of LCVRs and PBSs. Very weak, above-bandgap continuous-wave light is also used to stabilize the charge state of the QD<sup>26</sup> . Similar sets of LCVRs and PBSs are used to project the polarization of the collected photons on six different polarization bases. We use highly efficient transmission gratings to spectrally filter the emitted photons. The filtered photons are detected using efficient (>80%) single-photon superconducting detectors, with temporal resolution of about 30 ps. The photons’ detection times are recorded using a time tagging correlation module. 

### **Acknowledgements** 

We gratefully acknowledge the support of the Israeli Science Foundation (ISF; grant no. 3756/20 to D.G.) and the European Research Council (ERC) under the European Union’s Horizon 2020 

research and innovation program (grant agreement no. 695188 to D.G.). 

### **Author contributions** 

D.G. conceived the project, D.C. and Z.E.S. conducted the experiments. D.C. and O.K. developed the theoretical and numerical tools. D.C. and Z.E.S. analysed the data, D.C. and D.G. wrote the paper and all of the authors contributed to its final version. 

### **Competing interests** 

The authors declare no competing interests. 

### **Additional information** 

**Extended data** is available for this paper at https://doi.org/10.1038/ s41566-022-01152-2. 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41566022-01152-2. 

**Correspondence and requests for materials** should be addressed to David Gershoni. 

**Peer review information** _Nature Photonics_ thanks the anonymous reviewers for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at www.nature.com/reprints. 

Nature Photonics 

**Article** 

https://doi.org/10.1038/s41566-022-01152-2 



**Extended Data Fig. 1 | Schematics of the experimental system.** CW, continuous wave; DL, Delay line; M, mirror; DM, dichroic mirror; PBS, (NPBS) polarizing (non-polarizing) beam splitter; TG, transmission grating; OBJ, microscope objective; LCVR, liquid crystal variable retarder; Dn, single-photon detector n; TT, Time tagging correlation module. 

Nature Photonics 

