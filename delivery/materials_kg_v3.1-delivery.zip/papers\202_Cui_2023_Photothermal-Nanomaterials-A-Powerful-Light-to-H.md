# Photothermal Nanomaterials: A Powerful Light-to-Heat Converter

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Chemical Reviews |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 1686 |
| 作者 | Ximin Cui, Qifeng Ruan, Xiaolu Zhuo, Xin Xia, Jingtian Hu, Run-Fang Fu, Yang Li, Jian-Fang Wang et al. |
| DOI | 10.1021/acs.chemrev.3c00159 |
| 源文件 | 002_Cui_2023_Photothermal-Nanomaterials-A-Powerful-Light-to-H.pdf |

---
pubs.acs.org/CR 

<mark>Review</mark> 









# **Photothermal Nanomaterials: A Powerful Light-to-Heat Converter** 

Ximin Cui,<sup>†</sup> Qifeng Ruan,<sup>†</sup> Xiaolu Zhuo,<sup>†</sup> Xinyue Xia, Jingtian Hu, Runfang Fu, Yang Li, Jianfang Wang,* and Hongxing Xu* 

**Cite This:** _Chem. Rev._ 2023, 123, 6891−6952 

**Read Online** 

## ACCESS 

Metrics & More 

#### Article Recommendations 

ABSTRACT: All forms of energy follow the law of conservation of energy, by which they can be neither created nor destroyed. Light-to-heat conversion as a traditional yet constantly evolving means of converting light into thermal energy has been of enduring appeal to researchers and the public. With the continuous development of advanced nanotechnologies, a variety of photothermal nanomaterials have been endowed with excellent light harvesting and photothermal conversion capabilities for exploring fascinating and prospective applications. Herein we review the latest progresses on photothermal nanomaterials, with a focus on their underlying mechanisms as powerful light-to-heat converters. We present an extensive catalogue of nanostructured photothermal materials, including metallic/semiconductor structures, carbon materials, organic polymers, and twodimensional materials. The proper material selection and rational structural design for improving the photothermal performance are then discussed. We also provide a representative overview of the latest techniques for probing photothermally generated heat at the nanoscale. We finally review the recent significant developments of photothermal applications and give a brief outlook on the current challenges and future directions of photothermal nanomaterials. 

|**CONTENTS**||5.1.3. Electricity Generation|6914|
|---|---|---|---|
|1Introduction|6892|5.2. Structural Color Printing<br>|6915|
|. <br>||5.3. Photothermal Manipulation|6917|
|2. Photothermal Conversion Mechanisms<br>|6893<br>|5.3.1. Opto-thermophoresis of Nanomotors|6917|
|2.1. Plasmonic Localized Heating<br>|6893|5.3.2.PhotothermalActuatorsandRobots|6918|
|2.2. Nonradiative Relaxation in Semiconductors<br>|6894<br>|<br>5.4. Photothermal Catalysis|6919|
|2.3. Thermal Vibrations of Molecules<br>f|6894|5.5. Selected Applications in Life Sciences|6920|
|2.4. Basic Mathematical Descriptions or Photo-<br>||5.5.1. Photothermal Therapy (PTT)|6920|
|thermal Conversion|6894|552DDli|6923|
|||... ru ever||
|2.4.1.LightHarvesting|6894|||
|<br>||5.5.3. Bacterial Inhibition|6924|
|2.4.2. Light-to-Heat Conversion<br>f|6895<br>|5.5.4. Polymerase Chain Reaction (PCR)|6924|
|2.4.3. Heat Transer|6895|||
|||555FitaainstVID-19|6925|
|3RecentDevelomentsofPhotothermalNano-||...   <br>||
|.  p   <br>il|6896|5.6. Other Applications|6925|
|materas||6ConclusionandOutlook|6927|
|31MetallicNanostructures|6896|.   <br>||
|..  <br>f||Author Information|6928|
|3.1.1. Effect of the Material and Geometry|6896|||
|f||orresonnutors|6928|
|3.1.2. Effect of Plasmon Coupling<br>|6897<br>|<br>Authors|6929|
|3.2. Semiconductors|6898|AuthorContributions|6929|
|33Carbon-BasedNanomaterials|6900|<br>||
|..  <br>||Notes|6929|
|3.4. Organic Polymer Nanomaterials|6901|Biographies|6929|
|3.5. Two-Dimensional Nanomaterials|6902|Acknowledments|6930|
|3.6. Hybrid Photothermal Nanomaterials|6903|g||
|4. Probing of Photothermal Heat Generation|6903|||
|4.1. Heater−Thermometer Nanoplatforms|6904|Special Issue: Thermal Materials and Technology||
|4.2. Non-nanoprobe Thermometry|6907|Received:<br>March192023||
|5. Applications|6908|, <br>Published:May32023||
|5.1. Solar Thermal Water Heating|6908|,||
|5.1.1. Seawater Desalination|6912|||
|5.1.2. Wastewater Purification|6914|||



© 2023 The Authors. Published by American Chemical Society 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**6891** 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

|Abbreviations|6930|
|---|---|
|References|6930|



### **1. INTRODUCTION** 

The Sun, as the brightest star in the Earth’s sky, supplies almost all energy for life and human activities on the Earth. Even conventional fossil fuels are the long-term storage of solar energy.<sup>1−3</sup> The Sun radiates its energy by emitting ultraviolet (UV), visible, and infrared (IR) light that carries photons with different vibrational frequencies. When encountering an object, a portion of photons in the light can be absorbed by the object, thereby heating it up. Sunlight that reaches the Earth can be largely absorbed and thus warm the atmosphere, land, and ocean, where the generated heat is essential for creating a suitable climate and environment for all living things.<sup>4</sup> Moreover, energy transfer from light to heat occurs widely in physical, chemical, and biological reactions. It is one of the most fundamental processes in nature. This light-to-heat conversion process, where materials can act as light absorbers and efficiently transfer light energy into heat, is called photothermal conversion.<sup>5</sup> The photothermal performance of a photoexcited material is mainly determined by two key intrinsic properties�the light-harvesting ability and the lightto-heat conversion efficiency. The investigation of photothermal materials with broadband absorption is beneficial for the utilization of renewable solar energy, while the engineering of materials with efficient heat generation abilities can be widely useful in various fields, including water evaporation,<sup>6,7</sup> photothermal catalysis,<sup>8,9</sup> and biomedicine.<sup>10,11</sup> 

With the rapid development in both advanced nanotechnologies and materials science, a library of photothermal materials has been developed into nanoscale ones and designed into functional nanostructures. Similar to the classical bulk case, the photothermal effect can be universally observed in numerous nanomaterials, including metallic nanostructures,<sup>12,13</sup> semiconductors,<sup>14,15</sup> carbon-based nanomaterials,<sup>16−19</sup> organic polymers,<sup>20,21</sup> two-dimensional (2D) transition metal carbides/nitrides (MXenes),<sup>22−24</sup> and their hybrids. In contrast to bulk structures, however, well-designed nanomaterials can exhibit unique thermal, optical, and electronic properties by tailoring their shapes, sizes, compositions, and surrounding environments, thus providing much more possibilities in tuning their photothermal properties. Based on the diversity in nanomaterials and their rich physiochemical properties, various strategies have been proposed and established for improving photothermal conversion capabilities. For example, metal nanostructures such as Au, Ag, Al, and Cu have attracted enormous attention because of their tunable localized surface plasmon resonances (LSPRs) ranging from the visible to IR region.<sup>25,26</sup> The extremely large absorption cross-sections of plasmonic metal nanostructures and their associated plasmonic heating are highly promising for converting light into heat through the LSPR effect.<sup>27,28</sup> Nanostructured semiconductors typified by metal oxides and chalcogenides represent a new type of photothermal nanomaterials, whose optical properties strongly rely on their bandgap energies.<sup>29−31</sup> Either bandgap engineering or free-carrier-induced LSPRs can govern the light absorption of semiconducting nanomaterials and further improve the light-to-heat conversion efficiency.<sup>32−34</sup> Carbonand polymer-based nanomaterials are two other competitive photothermal material candidates with strong light-to-heat 

conversion abilities through thermal vibrations within the atomic lattices.<sup>20,35−38</sup> The conjugation and hyperconjugation effects can easily facilitate the excitation of less tightly held electrons from the _π_ orbitals to the _π_ * orbitals, enabling broad light absorption over the solar spectrum. Apart from these widely used material options, more newly emerging classes of photothermal materials are continuously being developed, such as MXenes,<sup>39−41</sup> metal−organic frameworks (MOFs),<sup>42−46</sup> and covalent organic frameworks (COFs).<sup>47−50</sup> Nevertheless, the mechanisms of the photothermal conversion processes can be typically attributed to the three categories mentioned above, namely, plasmonic localized heating, nonradiative relaxation of electron−hole pairs, and thermal vibrations of molecules. For enhancing the photothermal performance, photothermal nanomaterials can be designed to consist of a single component or multiple components and can involve more than one mechanism of photothermal conversion. The proper selection of materials and the ingenious design of nanostructures are consequently the most deterministic criteria for photothermal technologies. 

The extensive search for new types of photothermal nanomaterials has emerged as a frontier research area for a wide range of high-potential applications in physics, chemistry, and life sciences.<sup>20,45,51</sup> One important implementation of photothermal nanomaterials is the solar evaporation technology that allows steam and clean water to be produced from either seawater or wastewater, while the sustainable solar energy is collected and stored in the form of thermal, electrical, or mechanical energy. To meet the pressing demands of energy and potable water, more and more photothermal nanomaterials with diverse structural designs have been employed for seawater desalination, wastewater purification, and electricity generation.<sup>6,7,52−54</sup> Heat-mediated optical manipulation is another emerging technique based on photothermal materials, where the generated optical heating reversely exerts an optothermal force on the heated nanostructures, which are thus endowed with versatile control of movements, including rotating, pulling, oscillating, walking, and swimming.<sup>55,56</sup> Based on various optothermo−matter interactions, light-driven photothermal nanomaterials have been demonstrated as optothermal motors, probes, assemblers, and robots for performing complicated motions and realizing functional tasks.<sup>57−60</sup> Besides mechanical movements, shape morphing expectedly occurs under excess thermal energy and thus brings new functions of photothermal materials. Localized heating at plasmonic/photonic nanostructures can easily modify their structural morphologies and thereby their LSPRs and dielectric electromagnetic (EM) resonances, leading to promising applications in color printing and display.<sup>61−65</sup> The combination of photothermal nanostructures and phase-changing materials has been further developed into soft photothermal actuators with reversible and controllable deformation.<sup>66−70</sup> Moreover, the photothermal effect has also been widely used to drive catalytic reactions because of a synergy of thermochemical and photochemical pathways.<sup>8,9,45</sup> Thermal energy localized at active sites can effectively reduce the activation energy of photothermal catalysis and promote the transfer of charge carriers, thus greatly enhancing the catalytic process. On the other hand, photothermal nanomaterials have exhibited vast perspectives in biomedical areas because of the remote control of heating with high selectivity and spatial accuracy. Numerous applications and techniques based on the photothermal effect have been developed into photothermal 

**6892** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

therapy (PTT),<sup>20,24,71</sup> drug delivery,<sup>13,72,73</sup> the polymerase chain reaction (PCR),<sup>74−77</sup> and even the fight against coronavirus disease 2019 (COVID-19).<sup>78−82</sup> 

Several comprehensive reviews of photothermal materials have been published in recent years.<sup>7,11,12,22</sup> However, most of these only review selected categories of photothermal materials or focus on one or two representatives of their promising technologies. In this review, we endeavor to provide a comprehensive overview of why photothermal nanomaterials can convert light into heat, what the material choices of photothermal converters are, and how the photothermal effect is applied (Figure 1). We will start with the fundamental 



Figure 1. Overview of the mechanisms, categories, and applications of photothermal nanomaterials. 

principles underlying the light-to-heat conversion processes, including the LSPR effect, electron−hole generation and nonradiative relaxation, and molecular vibrations (Section 2). We will summarize the major categories of nanostructured photothermal materials and evaluate their light-to-heat conversion capabilities based on the distinct mechanisms. From this starting point, the proper material choice and rational structural design of photothermal nanomaterials for specified utilizations will become clearer and more achievable (Section 3). We will further review the latest techniques for probing photothermal heat generation at the nanoscale and categorize nanothermometers according to the physical mechanism that is employed to measure the temperature (Section 4). We will also expatiate on the recent significant developments toward the applications of photothermal nanomaterials in solar water evaporation, photothermal manipulation, photothermal catalysis, and PTT (Section 5). In the concluding section, we will provide our perspectives on the current challenges and future directions in the field of photothermal nanomaterials. 

### **2. PHOTOTHERMAL CONVERSION MECHANISMS** 

As a representative phenomenon of light−matter interaction, the photothermal effect is generally characterized with the 

temperature increase in a material through the absorption of light. Various materials possess different light-to-heat conversion abilities that rely on the responses of their electronic or bandgap structures to EM radiation. In this section, we will briefly introduce three major fundamental mechanisms involved in light-to-heat conversion processes. 

### **2.1. Plasmonic Localized Heating** 

The LSPR effect is the most intriguing phenomenon appearing in metallic structures down to the subwavelength-sized dimensions. Plasmonic nanostructures can break the diffraction limit of conventional optics and further confine incident light into the nanoscale, leading to the enhancement of light−matter interaction.<sup>83,84</sup> The unexpected behavior of metallic nanostructures irradiated by an external EM field is associated with their unusual electronic configurations, where electrons are coherently oscillated and redistributed at the surface. LSPRs refer to the collective oscillations of conduction-band electrons restricted inside highly conductive nanostructures. Plasmons are thus termed from the quanta of collective electron oscillations, which is the analogy to photons defined from the quanta of light waves as well as phonons treated from the quanta of sound waves. The excitation of plasmons can not only induce strong electric field enhancement near the surface of the structure but also bring about extremely large absorption and scattering cross-sections at the resonance frequency. These two important effects make metallic nanostructures perfect candidates for harvesting light and concentrating energy, endowing them with an excellent light-to-heat conversion ability.<sup>13,85</sup> 

The photothermal conversion process in a metallic nanostructure can be understood from the excitation and damping of the surface plasmons (Figure 2a). Metallic nanostructures as conductive materials are generally featured by a considerable number of free and polarizable electrons. Upon light illumination, a plasmonic nanostructure can absorb energy from incident photons through electron transitions. 



Figure 2. Three mechanisms of the photothermal effect with the corresponding light absorption range. (a) Plasmonic localized heating. (b) Nonradiative relaxation in semiconductors. (c) Thermal vibrations of molecules. Reprinted with permission from ref 7. Copyright 2019 Royal Society of Chemistry. (d) Physical processes of plasmon excitation and damping at different time scales. _T_ C, _T_ L, and _T_ E represent the temperatures of free charge carriers, the lattice, and the surrounding environment, respectively. Reprinted with permission from ref 28. Copyright 2022 Wiley-VCH. 

**6893** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

When the photon energy matches the LSPR band, a strong resonant interaction takes place, giving rise to enhanced light absorption and local field. The free conductive electrons of the metallic nanostructure are displaced from their intrinsic equilibrium state and relocated at the structure surface, together with an in-phase oscillation with the external EM wave. The resultant photoexcitation of the LSPR is a global nonequilibrium, where the dephasing and decay of the plasmons occur at an ultrafast speed (Figure 2d).<sup>86</sup> To restore a thermally equilibrated state, the absorbed energy of electrons can therefore be relaxed through either the radiative reemissions of photons or the nonradiative generation of electron−hole pairs through Landau damping.<sup>87,88</sup> During such a pure quantum mechanical process of Landau damping, the energy transfer process from a plasmon quantum to a single electron−hole pair happens in a time interval from 1 to 100 fs.<sup>86,89</sup> This process occurs through electron−electron collisions without loss of the absorbed photon energy. The produced energetic electrons from the nonradiative plasmon decay are termed as hot charge carriers, whose distribution is highly nonthermal within the first 100 fs.<sup>90</sup> The hot electrons further quickly interact with low-energy electrons on the time scale ranging from 100 fs to 1 ps. This electron−electron collision is an inelastic Coulombic process that converts electron energy into heat. At the same time, low-energy electrons couple with the metallic lattice through electron− phonon scattering processes with a period of several to hundreds of picoseconds. This relaxation step leads to the lattice thermalization of the nanostructure as well as a Fermi− Dirac-like distribution of electrons.<sup>91</sup> In the final step, the thermal energy inside the metallic structure is released to the surrounding environment through phonon−phonon collisions in the time scale of 100 ps to 10 ns. With thermal dissipation and lattice cooling, the electrons of the metallic nanostructure in the conduction band eventually return to their ground states before the photoexcitation. 

In summary, the plasmonic effect for localized heating in metallic nanostructures involves the excitation of LSPRs with enhanced absorption, generation, and relaxation of hot electrons, and heat transfer to the surrounding medium. The energy transfer from the absorbed photons to the conductionband electrons of metallic nanostructures goes through: (1) a resonant excitation of surface plasmons; (2) an athermal process of electron−electron collisions; (3) a fast lattice thermalization through electron−phonon scattering; and (4) a slow thermal dissipation through phonon−phonon collisions. 

### **2.2. Nonradiative Relaxation in Semiconductors** 

Besides the excitation of the LSPRs in metallic nanostructures, the direct interband/intraband electron transitions of nonplasmonic semiconductors can also display the photothermal effect. When a semiconducting material is excited by photons with sufficient energies, electron−hole pairs are generated with their energies comparable to the bandgap. The energy of the excited electrons can be either released by emitting photons or transferred to the material lattice through nonradiative relaxation.<sup>7,92</sup> The release of phonons instead of photons in a semiconductor through the recombination of charge carriers can increase heat loss and therefore lead to a local temperature increase of the lattice. The established thermal distribution is strongly dependent on the characteristics of the light absorption and surface/bulk recombination of the semiconductor. Two types of the nonradiative relaxation processes, 

including Shockley−Read−Hall and Auger recombination,<sup>93,94</sup> are ultimately responsible for heat generation in semiconductors (Figure 2b). Auger recombination, which occurs with three carriers, is an intrinsic process relying on the properties of the involved material. The effect of Auger recombination becomes ascendant with decreasing bandgaps. When an electron−hole pair recombines without the emission of photons, their energy can be transferred to either another electron higher in the conduction band or another hole deeper in the valence band. The third energetic carrier normally thermalizes back to the band edge through lattice vibrations. Shockley−Read−Hall recombination is an alternative nonradiative relaxation that depends on the quality of the material. In the presence of defects/impurities in a semiconductor, midgap energy states are usually created within the bandgap due to the defect modification of the electronic structure.<sup>95</sup> These defect states are also known as trap levels that capture charge carriers. The Shockley−Read−Hall recombination process is thus called trap-assisted recombination. It involves a two-step process. Conduction-band electrons first relax to the trap level and then move to the valence band, where a hole is annihilated. These relaxation processes are accompanied with the exchange of thermal energy with the material. For the case of the defect traps located at or near the surface of the semiconductor, the trap-assisted recombination process is termed as surface recombination, which is dependent on the density of surface defects. 

### **2.3. Thermal Vibrations of Molecules** 

Carbon-based materials and some organic polymers also demonstrate excellent light absorption characteristics and are very competent in the heat generation through lattice vibrations. Although the usual carbon bonds like C-C, C-O, and C-H possess large energy differences between the _σ_ and _σ_ * orbitals that can be hardly excited, loosely held electrons in these materials can be easily excited from the _π_ orbitals to the _π_ * orbitals under low-energy irradiation.<sup>23,96,97</sup> When the energy of incident photons satisfies an electronic transition within the material, the _π_ electrons are excited from the ground state (highest-occupied molecular orbital, HOMO) to a higher energy state (lowest-unoccupied molecular orbital, LUMO) (Figure 2c). After the relaxation of the excited electrons to the ground state through vibration−electron coupling, the excess energy is released in the form of heat. Moreover, the conjugation or hyperconjugation of the _π_ orbitals can deeply modify the electron transitions between HOMO and LUMO, whose gap energy decreases with the increase in the number of _π_ bonds.<sup>98,99</sup> 

### **2.4. Basic Mathematical Descriptions for Photothermal Conversion** 

To elucidate the light-to-heat conversion process, it is essential to consider the light-harvesting ability and heat generation of a material as well as heat transfer and loss. Owing to the fundamental difference in the physical mechanisms, diversely categorized photothermal materials have various mathematical descriptions for their optical and thermal properties. In this section, basic universal equations are presented for understanding photothermal conversion in terms of three aspects including light harvesting, light-to-heat conversion, and heat transfer. 

**2.4.1. Light Harvesting.** One of the critical factors to evaluate the photothermal performance is the light-harvesting ability that reveals how well a photothermal material absorbs 

**6894** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

the energy of incident photons. The light absorption is an important process of light-to-heat conversion. Absorptance is defined as the fraction of the energy of incident photons that is absorbed by a material. The absorbed energy for a certain material depends on the range of absorption over the spectrum of the incident light and the intensity of absorbance for each wavelength. By integrating the absorption intensity of the photothermal material over the spectral range, the absorptance can be calculated by the energy ratio of the total absorbed light to the incident radiation. At an incidence angle of _θ_ , the overall absorptance _A_ ( _θ_ ) of a light absorber can be expressed as<sup>51,100</sup> 



<!-- Start of picture text -->
max [1 R ( , ) T ( , )] P ( , )d<br>min<br>A ( ) =<br>max P ( )d<br>min (2.1)<br><!-- End of picture text -->

where _P_ ( _λ_ ), _λ_ max and _λ_ min represent the wavelength-dependent radiation power and the maximum and minimum wavelengths of the incident light and _R_ ( _θ,λ_ ) and _T_ ( _θ,λ_ ) stand for the total reflectance and transmittance of the absorber at the wavelength _λ_ , respectively. According to this equation, the absorptance can be enhanced by reducing the transmittance and reflectance of the photothermal material. Moreover, broadband light absorption is crucial for light absorbers to harvest enough light for obtaining high light-to-heat conversion efficiencies. 

For the case of photothermal materials dispersed in homogeneous semitransparent media, light absorption is a cumulative process with an exponential decay that can be described by Beer−Lambert’s law as _I_ = _I_ 0 _e_<sup>−</sup><sup>_κcl_</sup> , where _I_ and _I_ 0 represent the light radiation intensity after and before the absorption, _κ_ stands for the extinction coefficient, _c_ is the particle concentration, and _l_ is the length of the optical path. To further determine how much of the light is absorbed by the material, absorbance _a_ is defined as the attenuation of the incident radiation power. It can be calculated from the transmittance _T_ as 



<!-- Start of picture text -->
I 0<br>a = ln T = ln = cl<br>I (2.2)<br><!-- End of picture text -->

The absorbance is therefore proportional to the extinction coefficient of the absorber and the amount of the absorber per unit area. The extinction coefficient is the intrinsic property of the absorber. It depends on the material, size, and shape. 

**2.4.2. Light-to-Heat Conversion.** Besides the light absorption of a photothermal material, the light-to-heat conversion efficiency is another essential factor that directly quantifies the absorbed energy transferred to thermal energy, instead of radiative re-emission of photons. One straightforward method for determining the conversion efficiency is to measure the increase in temperature and calculate the heat generation induced by an incident light. The photothermal conversion efficiency _η_ can be written as<sup>101,102</sup> 



<!-- Start of picture text -->
Q cm T<br>= =<br>E pst (2.3)<br><!-- End of picture text -->

where _Q_ is the generated thermal energy by the absorber, _E_ represents the total energy of the incoming light, _c_ and _m_ denote the specific heat and mass of the photothermal material, Δ _T_ is the temperature increase of the material under the light irradiation, _p_ is the power density of the light source, and _s_ and _t_ represent the radiation area and time. By use of this method, all of the incident light including the reflected, scattered, absorbed, and transmitted photons 

originating from the incident light is taken into account as the input energy. The advantage of this strategy is that only the absorbed photons contribute to the generation of thermal energy in the photothermal material. As the heat generation is dependent on the amount of the used photothermal material, it is difficult for this method to directly compare the efficiency values among different materials. Moreover, the heat transfer from the photothermal material to the surrounding medium is not considered in the calculation. 

The heat loss to the environment can be estimated by recording the temperature decay process after the incident light is removed. The equation of the photothermal conversion efficiency _η_ can then be expressed as<sup>103−105</sup> 



<!-- Start of picture text -->
hs ( T max T sur) Q dis<br>=<br>I (1 10 a ) (2.4)<br><!-- End of picture text -->

where _h_ is the heat transfer coefficient, _s_ represents the surface area of heat transfer, _T_ max is the equilibrium temperature, _T_ sur represents the temperature of the surrounding environment, _Q_ dis stands for the heat dissipated by the surrounding environment, _I_ is the radiation intensity of the incident light, and _aλ_ represents the absorbance of the photothermal material at the wavelength _λ_ . Although only the absorbed photons are treated as the input energy, this equation quantitatively eliminates the impact of the heat transfer and the concentration of the photothermal material on the light-toheat conversion efficiency. The photothermal conversion abilities of various materials can therefore be readily compared by this method. But there are a number of parameters that need to be experimentally measured. Some of them are not trivial and can significantly affect the ultimate value of the photothermal conversion efficiency. Some recent works have modified eq 2.4 and provided a more straightforward and reproducible approach for the evaluation of the photothermal conversion efficiency.<sup>106,107</sup> 

**2.4.3. Heat Transfer.** After the incident light is absorbed by a photothermal material, the photon energy is converted into thermal energy through a light-to-heat conversion process. The generated heat will be further transferred to other lowertemperature materials or released to the surrounding environment. Therefore, heat transfer is the third important process in a photothermal conversion system. The transfer of thermal energy from one material to another is driven by the thermal gradients between the materials, which can be realized in three main means, which are conduction, convection, and radiation.<sup>51,104</sup> 

Thermal conduction usually occurs within a material or contiguous objects, where heat spontaneously flows from the higher-temperature part (the light absorber) to the lowertemperature one (heat transfer object). The conduction energy can be expressed as 



<!-- Start of picture text -->
ks<br>Q cond = ( T obj)<br>L T (2.5)<br><!-- End of picture text -->

where _k_ represents the thermal conductivity of the photothermal material, _s_ represents the surface area of heat transfer, _L_ is the conduction length of the light absorber, and _T_ obj and _T_ are the steady temperatures of the heat transfer object and the light absorber. 

Thermal convection refers to the heat energy transfer induced by the movement of fluid. The convection energy from the heating source to the fluid can be written as 

**6895** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

Table 1. Proposed Photothermal Conversion Mechanisms and Advantages of Different Types of Nanomaterials for Photothermal Applications 

|references|photothermal materials|working mechanisms|advantages for photothermal applications|
|---|---|---|---|
|13, 85|plasmonic metals|LSPR effect|facile synthesis, tunable plasmon resonance, and large absorption<br>cross-sections|
|32, 33|slightly doped and intrinsic<br>semiconductors|nonradiative recombination of electron−hole<br>pairs|facile synthesis, low toxicity, and strong extinction coefficients in<br>the NIR region|
|34|heavily doped semiconductors|LSPR effect||
|326|carbon-based nanomaterials|nonradiative relaxation of delocalized _π_<br>electrons|high chemical stability, broadband light absorption, and<br>lightweight|
|98|organic polymers|nonradiative relaxation of delocalized _π_<br>electrons|versatile molecular designs, strong absorption of NIR light, and<br>good biocompatibility|
|22, 364|2D nanomaterials|nonradiative recombination of electron−hole<br>pairs and LSPR effect|layered structures, broad light absorption band, and high<br>photothermal conversion efficiencies|
|_Q_<br>conv|=<br>_hs T_<br>_T_<br>(<br>)<br>sur|(2.6)<br>nanoma|terials to enhance light absorption, convert heat, and|



nanomaterials to enhance light absorption, convert heat, and conduct thermal energy is highly dependent on the material choice and structural design. In this section, we will summarize the recent progresses in the development of both new photothermal materials and advanced methods for structural engineering with excellent light-to-heat conversion performances. 

where _h_ is the heat transfer coefficient. As the reciprocal of thermal insulance, the heat transfer coefficient depends on the physical properties of the fluid and the thermohydraulic conditions. 

Thermal radiation takes place in all objects through EM waves without the requirement of any medium. According to the Stefan−Boltzmann law, the emission energy is proportional to the fourth power of the temperature. When an object emits thermal radiation based on its temperature, it also absorbs radiation from the surrounding objects. The thermal radiation energy is the net energy exchange between the hot object and the cold environment, which can be expressed as 

### **3.1. Metallic Nanostructures** 

Noble metal nanostructures show attractive photothermal conversion properties because of the excitation of their strongly confined LSPRs. According to the Drude−Lorentz model, the high density of free electrons and their collective oscillations can give rise to the LSPR effect at the metal− dielectric interface.<sup>108,109</sup> Plasmon resonances are excited when the incident photon energy matches the LSPR band of metallic structures. The redistribution of the excited electrons contributes to the generation of plasmonic heating, which can be finely controlled by external irradiation. The LSPR frequency can be further tailored by changing the materials, sizes, and shapes of metallic nanoparticles, as well as their surrounding environments and assembly configurations.<sup>110,111</sup> **3.1.1. Effect of the Material and Geometry.** Because of the LSPR effect, numerous types of metallic nanostructures for light-to-heat conversion have been explored, such as Au,<sup>112−119</sup> Ag,<sup>120−124</sup> Pd,<sup>125−130</sup> Al,<sup>131−135</sup> Cu,<sup>136,137</sup> Ge,<sup>138,139</sup> and other metals. Au and Ag are two of the most commonly employed metals in photothermal conversion because of their high free charge carrier concentrations and relatively low Ohmic losses.<sup>140,141</sup> Their plasmon resonances can be finely tuned from the visible to near-infrared (NIR) region through control of the size and morphology (Figure 3, left panel). However, another loss mechanism originating from interband transitions plays an important role for Au and Ag at optical frequencies. For Au structures, the interband losses are dominant at the short wavelengths of the visible region, while the intraband losses are high in the NIR range and limited in the shorterwavelength region.<sup>142</sup> In addition, the plasmonic properties of Ag structures are easily degraded due to rapid oxidation and sulfuration under ambient conditions. The earth-abundant metals such as Al and Cu are newly emerging as intriguing alternatives to Au and Ag in plasmonics. Cu and Al are more cost-effective and possess similar LSPR performances to those of Au and Ag.<sup>131,143</sup> Moreover, Al nanostructures can support strong plasmon resonances in the UV range with extremely high photothermal conversion efficiencies.<sup>144</sup> Although Al suffers from chemical instability, the formation of a passivation layer of aluminum oxide can effectively protect the structure without degrading its LSPR response. The limitation for Al 



<!-- Start of picture text -->
4 4<br>Q rad = s ( T T env) (2.7)<br><!-- End of picture text -->

where _ε_ is the emissivity, _σ_ represents the Stefan−Boltzmann constant, and _T_ env stands for the temperature of the environment. 

Consequently, the heat transfer not only is dependent on the physical properties of the photothermal material but also is affected by the circumstance of its surrounding environment. The three mathematical expressions provided above offer efficient ways to regulate the heat transfer process. For interfacial solar water evaporation, thermal conduction is the dominant process that requires the minimization of heat loss to the surrounding environment. The generated heat can thus be localized on the surface of the photothermal material for efficient vapor generation. For volumetric water heating, the convection process needs to be first considered, where a promoted heat transfer is demanded for a fast increase in the temperature of the surrounding environment. In short, the proper choice of both photothermal materials and their surrounding media is essential for photothermal applications with desired purposes. 

### **3. RECENT DEVELOPMENTS OF PHOTOTHERMAL NANOMATERIALS** 

With the development of advanced nanofabrication methods in the last few decades, nanomaterials, for example, metallic/ semiconductor nanostructures, carbon-based nanomaterials, organic polymer nanomaterials, and 2D nanomaterials, have been thoroughly investigated with various beneficial and functional qualities. The light-to-heat conversion mechanisms and intriguing properties of differently categorized nanomaterials are summarized in Table 1. Photothermal conversion as an ancient technology has recently received extensive attention and regained a breakthrough. The capability of photothermal 

**6896** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 3. Typical plasmonic spectral bands of material- and shapedependent metallic nanostructures. Left: homogeneous metals (Au,<sup>101,164−182</sup> Ag,<sup>183−192</sup> Al,<sup>131,145,193−195</sup> Pd,<sup>196−199</sup> Pt,<sup>186,200</sup> and Cu.<sup>136,201−204</sup> Right: metal hybrids (Au hybrids: Au-Ag,<sup>156,201−218</sup> AuPd,<sup>219−224</sup> Au-Pt,<sup>225−234</sup> Au-Cu,<sup>235−238</sup> and Au-Ni;<sup>239,240</sup> Ag hybrids: Ag-Pd,<sup>241−248</sup> Ag-Pt,<sup>249−251</sup> Ag-Ni,<sup>252,253</sup> and Ag-Co<sup>254,255</sup> ) according to their different geometries. 

structures is the broad line widths of their plasmon resonances in the visible range because of interband transitions.<sup>145</sup> In addition, a wide variety of metal materials including Ni, Co, Cr, Pt, and Pd have been demonstrated to exhibit LSPRs in the UV region.<sup>144</sup> Among them, Pt and Pd are of practical interest in photothermal catalysis owing to their outstanding catalytic properties and high thermal stability.<sup>146,147</sup> In general, plasmonic nanoparticles made of these metals can be synthesized by bottom-up methods, where crystal structures are grown by stacking metal atoms. The bottom-up methods are usually based on the chemical reduction of metal salts and the nucleation of tiny particles. One of the famous synthetic approaches is seed-mediated growth with a two-step process.<sup>148</sup> The first step is the preparation of small seeds through homogeneous nucleation. The second step is overgrowth on the seeds using shape-directing agents, where nanoparticles are overgrown into the desired geometry and size. A large number of asymmetric metal nanostructures can be facilely synthesized by changing the seeds, metal salt, reductant, and capping agent, as well as the shape-directing agent.<sup>149</sup> Asymmetric structures usually have more sharp tips, corners, and edges where plasmonic heating is generated and concentrated because of largely enhanced EM fields. The geometry-dependent photothermal conversion efficiency has been well demonstrated in both numerical simulations and experiments. The effect of the morphology on the heat generation in plasmonic nanoparticles has been numerically investigated using Green’s dyadic method.<sup>150</sup> The heat generation can be well quantified by mapping the heating power density within the studied Au nanostructures. This geometry effect has also been experimentally shown in various differently shaped structures, including nanocubes, nanorods, nanoplates, nanocages, and branched nanostructures (Figure 3, left panel).<sup>151,152</sup> Nanospheres and nanocubes with high symmetry usually exhibit strong absorption resonance.<sup>153,154</sup> On the contrary, low-symmetry polyhedron nanoparticles show broader but weaker absorption resonances with multiple plasmon peaks. The most straightforward way to broaden the absorption spectrum is to mix plasmonic nanoparticles with different sizes and shapes.<sup>85</sup> But this method is practically unattractive, as it requires the parallel synthesis of various types of nanoparticles and the careful control of the amount ratio of these different nanoparticles. An alternative strategy is to grow new particles on pre-existing structures to broaden the 

plasmon resonances. A nearly ideal type of blackbody nanostructure composed of a Au nanorod with an attached Au nanosphere has been reported.<sup>155</sup> This material has a nearly perfect absorption of 98−99% over a broad spectral range from 400 to 1400 nm. 

As the LSPR bands of homogeneous metallic structures are intrinsically limited by the materials, metal hybrids, including alloys, can be obtained by reacting two or more metal elements (Figure 3, right panel). Metal alloys containing less conductive metals can effectively lower the free charge concentration and thus reduce the optical losses.<sup>108</sup> Their LSPR properties can also be tailored by adjusting the proportion of each plasmonic or functional reactant. For instance, Au-Ag alloyed nanostructures can support plasmon resonances over a much broad range of the UV−visible spectrum and exhibit distinct blueshifts by decreasing the atomic ratio of Au to Ag.<sup>156</sup> Because the change in the proportion of an alloy alters the effective dielectric constant of the alloy, the photothermal conversion efficiency can therefore be greatly improved with enhanced light absorption for Au-Ag alloy nanostructures.<sup>157−160</sup> Apart from the tunable LSPR frequencies, the formation of alloys offers a new route for improving the sensitivity of plasmonic structures through dispersion engineering.<sup>161</sup> The real permittivities of alloyed structures such as AuPd<sup>162,163</sup> and Ag-Ti<sup>161</sup> can be reduced compared to the pure metals, leading to the increase in sensitivity. 

**3.1.2. Effect of Plasmon Coupling.** The key challenge for improving the photothermal conversion efficiencies of plasmonic nanomaterials is to realize broadband absorption over the solar spectrum. But metal nanostructures often absorb photons at one or a few certain bands, limiting their photothermal performances.<sup>144</sup> The most widely used strategy is to assemble two or more metallic nanoparticles into plasmon-coupled structures where the interparticle nanogaps are formed and known as “hotspots”.<sup>256</sup> The generation of hotspots can not only achieve strong EM field enhancement but also produce multiple plasmon modes through plasmon coupling. The enhanced local field can give rise to pronounced photothermal conversion in the interparticle nanogaps. The overall photothermal performance of the assembled nanoparticles is based on their collective heating ability and plasmon coupling effect.<sup>257</sup> The plasmonic properties of the coupled nanostructures are sensitively dependent on the particle number, gap distance, structural configuration, and polarization state of the incident light.<sup>258</sup> When two metallic nanoparticles are placed close to each other, a plasmonic dimer as the simplest coupled structure is formed. According to plasmon hybridization, the interaction between the two nanoparticles produces a lower-energy symmetric (bonding) plasmon resonance mode and a higher-energy antisymmetric (antibonding) resonance mode.<sup>259</sup> The total heat generation and temperature distribution in a plasmonic dimer have been numerically calculated.<sup>260</sup> The calculated temperature is distributed nonuniformly around the nanoparticles even at the nanoscale. The plasmonic heating has been found to be dependent on the polarization state of the incident light. When the external electric field is polarized along the dimer axis, the heat generation increases as well as the electric field enhancement. Interestingly, an extraordinary photothermal isosbesticity has been discovered in plasmonic nanostructures, where the temperature is invariant with the change of the illumination polarization state at specific wavelengths (Figure 4a).<sup>261</sup> The isosbestic wavelength of a given plasmonic 

**6897** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

### **<u>Chemical Reviews</u>** 



Figure 4. Plasmon-coupling-induced absorption broadening and related heat effects. (a) Temperature distributions (left column) of a Au dimer under the longitudinal (top) and transverse (bottom) polarization excitation and corresponding electric near-field enhancements (right column). Reprinted with permission from ref 261. Copyright 2017 American Chemical Society. (b) Dependence of the calculated normalized extinction spectra of one-dimensional (1D) Al nanoparticle chains on the particle number _N_ . Reprinted with permission from ref 133. Copyright 2016 Springer Nature. (c) Calculated temperature maps of a single array and five arrays of nine Ag nanoparticles in a square lattice with lateral periods from 12.5 to 200 nm. Reprinted with permission from ref 266. Copyright 2020 American Chemical Society. (d) Measured absorption spectra of selfassembled Au colloidosomes (red) and the Au nanoparticles (black) suspended in 1-butanol. The inset shows the corresponding scanning electron microscopy (SEM) image of the Au colloidosomes. Reprinted with permission from ref 271. Copyright 2015 Wiley-VCH. 

nanostructure can be found at the intercrossing of the absorption spectra under two different polarization directions. Since the ability of a single dimer to broaden the LSPR band is limited, more nanoparticles need to be assembled and interact together to increase the light absorption bandwidth.<sup>52,262−264</sup> The linear assembly of Al nanoparticles has been shown to broaden the extinction peaks with distinct redshifts toward the visible and NIR regions as the particle number is increased (Figure 4b).<sup>133</sup> Randomly distributed Au nanoparticles have been employed as a perfect absorber to fully absorb light. The average absorbance can reach up to 99% in the spectral range from 400 nm to 10 _μ_ m because of the suppression of back reflection.<sup>265</sup> Analogous to the distance-dependent electric field from a charged particle, the temperature of a heated structure drops slowly as ∼1/ _d_ from the particle surface.<sup>260</sup> Figure 4c shows the simulated temperature profiles for the arrays of nine Ag nanoparticles with varied periodic spacings.<sup>266</sup> When a large number of nanoparticles are irradiated at the same time, the overall temperature of the entire particle system can reach large but homogeneous values by adding together all the temperature contributions.<sup>267</sup> Threedimensional (3D) or more disordered nanostructures, such as plasmonic colloidosomes that are generally prepared by assembly approaches, have also been used to produce strong plasmon coupling.<sup>123,268−270</sup> For example, Au nanospheres 

have been assembled into 3D black plasmonic colloidosomes by use of an emulsion-templating method (Figure 4d).<sup>271</sup> The fabricated colloidosomes have hexagonal close-packed multilayer shells and exhibit intense broadband light absorption. The assembly process is universal, and this method is suitable for nanoparticles with different sizes and shapes. In general, photothermal heat generation is highly sensitive to the assembly state of metal nanoparticles (particle number, spacing, and configuration) and the polarization state of the incident light. To take advantage of the plasmon coupling effect, the particle arrangement and structural design need to be carefully considered. 

### **3.2. Semiconductors** 

Semiconductor materials, such as metal oxides and chalcogenides, are another type of extraordinary candidate for photothermal conversion because of their low cost, facile synthesis, and low toxicity. Semiconductors are not easily vulnerable to photodegradation or photobleaching compared to organic photothermal materials.<sup>14</sup> They also possess tunable absorption wavelengths and exhibit strong extinction coefficients in the NIR region. The bandgaps of semiconductors govern the light absorption based on the free charge carrier generation inside the material. Figure 5 summarizes the bandgaps and band edge positions of some commonly studied semiconductors, including oxides, chalcogenides, nitrides, and silicon.<sup>272−274</sup> When the photon energy of incident light matches the bandgap energy, the incoming photons absorbed 



Figure 5. Band edge positions and bandgaps with respect to the vacuum level and the normal hydrogen electrode (NHE) for selected semiconductors including oxides, chalcogenides, nitrides, and silicon. The top squares indicate the conduction band edges. The bottom squares indicate the valence band edges. The top numbers represent the exact conduction band levels, and the numbers between the squares show the bandgaps. The data are taken from ref 272 with permission from the Royal Society of Chemistry and modified according to the new works.<sup>273,274</sup> 

**6898** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 6. Schematics for engineering the band structures of semiconductors. (a) An intrinsic semiconductor. (b) Doping-induced formation of shallow-level energy states in the bandgap. (c) Doping-induced formation of deep-level energy states in the bandgap. (d) Degenerate-dopinginduced LSPR. The electronic band structures are shown on the top, and the corresponding optical absorption curves are displayed on the bottom. Reprinted with permission from ref 7. Copyright 2019 Royal Society of Chemistry. 

by a semiconductor can cause the generation of electron−hole pairs (Figure 6a). The heat generation relies on the nonradiative recombination of the electron−hole pairs. Semiconductors usually possess much lower free charge carrier concentrations than metal materials. Semiconductor materials are therefore generally translucent in the IR region but opaque in the visible region.<sup>51</sup> To extend the absorption range, doping is one of the classical means to increase the free charge carrier concentrations of semiconductors. While the light absorption of a semiconductor is enhanced by doping, the photothermal conversion efficiency can also be improved owing to the increased probability of nonradiative recombination. 

Through the stratagem of defect or impurity introduction, not only can the band energy be shifted, but also new energy states can be created within the bandgap. There are several doping-induced changes during the bandgap engineering of semiconductors, including (1) the emergence of intraband energy states; (2) the narrowing of the bandgap; and (3) the formation of impurity bands in degenerately doped semiconductors.<sup>7</sup> In the first case, doping introduces defect and trap-level states without changing the bandgap (Figure 6b). The defect-level states can work as charge recombination centers for the relaxation of conduction-band electrons, resulting in the extension of the absorption spectrum to longer wavelengths. An add-on shoulder can often be observed in the absorption curve of a defect-level-doped semiconductor. N-doped TiO2 was first prepared in 2001. It possesses a visiblelight absorption capability.<sup>275</sup> From then on, doping has been extensively employed for TiO2 with either non-metal anions of C, N, S, and P at the O sites or transition metal cations of Fe, Co, Cu, Cr, and Ni at the Ti sites.<sup>272,276−279</sup> 

In the second case of doping, the position of the valence or conduction band is shifted instead of the introduction of any new energy levels (Figure 6c). The bandgap thus becomes narrower compared to that of the pristine semiconductor, resulting in both the broadening and redshift of the absorption edge. Upon light illumination, photons that possess higher energies than the band energy of the narrow bandgap semiconductor can generate above-bandgap electron−hole pairs.<sup>33</sup> The subsequent relaxation of the electron−hole pairs to the band edges can effectively convert the extra energy into heat through a thermalization process. On the contrary, most photons absorbed by the broad bandgap semiconductor are radiatively released through light emissions, leading to a lower 

photothermal conversion efficiency. Various narrow bandgap semiconductors, including black TiO2,<sup>32,280,281</sup> Ti2O3,<sup>33</sup> MoO3,<sup>282</sup> and Fe3O4,<sup>283,284</sup> have been developed as light-toheat converters. Black TiO2 with broadband light absorption has recently received intensive attention as a perfect light absorber.<sup>285−288</sup> It can reduce the recombination of electron− hole pairs and further enhance visible light absorption. Since the first discovery in 2011,<sup>32</sup> various fabrication strategies have been proposed for the development of black TiO2 with superior photothermal properties. The introduction of surface disorder and the creation of oxygen vacancies are the two main approaches for bandgap engineering. The introduction of surface disorder can destroy the lattice periodicity and modify the edges of the conduction and valence bands, resulting in the narrowing of the bandgap. The created oxygen vacancies can serve as traps for reducing the recombination of photogenerated charge carriers and thus improve the photothermal performance. Remarkably, the bandgap of black TiO2 was reported in 2017 to be further narrowed by adding Ti<sup>3+</sup> ions.<sup>33</sup> Ti2O3 nanoparticles were synthesized with an excellent absorption capability and a high photothermal conversion efficiency of 92%. Because of the localized hybridization between titanium and oxygen, Ti2O3 tends to generate oxygen vacancies instead of titanium vacancies.<sup>289</sup> The presence of vacancies can promote the band overlap near the Fermi level and therefore improve the electronic transport of Ti2O3.<sup>290</sup> 

Degenerately doped semiconductors have recently been discovered with strong LSPRs in the NIR region (Figure 6d). Both n-type and p-type semiconductors can be heavily doped to generate high-enough free charge carrier concentrations, which is necessary for achieving similar absorption characteristics to those of noble metals. The phenomena of free-carrierinduced LSPRs have been widely observed in many metal chalcogenides and oxides, including Cu2‑ _x_ S, Cu2‑ _x_ Se, Cu2‑ _x_ Te, Fe1‑ _x_ S2, MoO3‑ _x_ , WO3‑ _x_ , ZnO, and CdO.<sup>34,291−295</sup> In addition to the structural parameters (material, size, shape) that can affect the plasmonic responses, the plasmon resonances of heavily doped semiconductors can also be tuned by controlling their free charge carrier concentrations. The LSPR frequency can be largely spanned from the visible to far-infrared (FIR) region. Increases in the free charge carrier concentration can cause blueshifts of the LSPR peak and increases in the resonance amplitude. The free charge carrier concentrations of the doped semiconductors can be controlled from 10<sup>18</sup> cm<sup>−3</sup> to 

**6899** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

10<sup>21</sup> cm<sup>−3</sup> , which are still smaller than those of the conventional plasmonic metals<sup>34</sup> on the order of 10<sup>22</sup> cm<sup>−3</sup> . However, the doping level for many semiconductors is limited owing to the perturbation of high-concentration doping on the band structure. Many factors, including the fraction of the active dopant, the solid solubility limit, and doping compensation effects, need to be considered.<sup>296−298</sup> 

### **3.3. Carbon-Based Nanomaterials** 

Carbon is one of the most abundant elements in the universe and can be found in all life forms. The atoms of carbon can bond with each other in diverse hybridization states (sp, sp<sup>2</sup> , sp<sup>3</sup> ), resulting in a variety of carbon allotropes (Figure 7).<sup>35</sup> 



Figure 7. Carbon-based nanomaterials with different dimensionalities. Reprinted with permission from ref 35. Copyright 2015 American Chemical Society. 

Well-known carbon materials include carbon dots,<sup>299−303</sup> nanodiamond,<sup>304,305</sup> fullerene,<sup>306,307</sup> graphite,<sup>308−312</sup> carbon nanotubes (CNTs),<sup>313−318</sup> graphene and its derivatives.<sup>36,319−325</sup> All these carbon allotropes are excellent candidates as photothermal materials due to their high 

chemical stability, broadband light absorption, lightweight and low cost.<sup>326</sup> Their light-to-heat conversion relies on the excitation of loosely held _π_ electrons and relaxation to their ground states. The light absorption of carbon-based nanomaterials can be extended to a wide range of the solar spectrum. Many efforts have therefore been made to increase the absorption intensity and reduce the surface light reflection rather than broadening the absorption range. The optical properties of carbon-based nanomaterials vary with specific structural parameters, including the size, shape, doping, and number of layers.<sup>327</sup> These physicochemical factors are also related to the fabrication methods. The fabrication methods include both top-down and bottom-up approaches. In the topdown approaches, bulk materials are reduced in size, such as mechanical exfoliation. In the bottom-up approaches, the carbon-based nanomaterials are constructed from the atomic level, such as chemical vapor deposition and epitaxial growth.<sup>328,329</sup> When carbon-based materials are fabricated into porous nanostructures, the light reflection is significantly reduced through the minimization of the influence of the incidence angle and the reduction of the effective refractive index of the materials.<sup>7</sup> For instance, the synthesis of a doublelayer structure consisting of an exfoliated graphite layer and a carbon foam layer has been demonstrated.<sup>312</sup> The reflectivity of this porous nanostructure reaches down to 3% within the solar spectrum ranging from 250 to 2250 nm. Porous graphene sheets<sup>330,331</sup> and CNTs<sup>313,314</sup> have also been fabricated to improve light absorption. Optical microcavities can be formed between two sides of a spacer layer. These porous structures can therefore effectively confine light within the structures and significantly enhance the interaction between the materials and light.<sup>332</sup> A porous network comprising graphene sheets has been reported to achieve 97% absorption across 200−2500 nm because of the multiscattering effect.<sup>331</sup> 98% absorption of visible irradiation and almost 100% absorption of NIR light have been realized with vertically aligned graphene sheets.<sup>330</sup> In addition, hollow CNTs can be fabricated into a hierarchically nanoporous network structure,<sup>314</sup> which exhibits broad absorption of 99% and high photothermal conversion of 86.8%. 



Figure 8. Summary of polymer-based photothermal materials. (a) Basic conjugated polymers as photothermal materials. Their monomers can be treated as the basic components of the conjugated polymers with D-A structures. (b) Conjugated polymers with donor−acceptor structures as photothermal materials. Reprinted with permission from ref 102. Copyright 2020 American Chemical Society. 

**6900** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 9. Supramolecular assembly of polymer-based photothermal materials. (a) Schematic illustrating the multicomponent coordination assembly of metallo-nanodrugs. Reprinted with permission from ref 349. Copyright 2018 American Chemical Society. (b) Design and synthesis of a dual-NIR-window absorbing photothermal nanoagent. Reprinted with permission from ref 353. Copyright 2018 Wiley-VCH. 

### **3.4. Organic Polymer Nanomaterials** 

Organic polymers with conjugated structures have emerged as a new category of photothermal nanomaterials because of their versatile molecular designs, strong absorption of NIR light, high light-to-heat conversion efficiencies, and good biocompatibility.<sup>98</sup> Similar to the case of carbon-based nanomaterials, the absorption capabilities of conjugated polymers in the visible and NIR regions stem from the nonradiative relaxation of their rich delocalized _π_ electrons. Various polymer photothermal nanomaterials have been strategically designed on the basis of most basic conjugated structures, such as polythiophene (PT), polypyrrole (PPy), polyaniline (PAn), and polydopamine (PDA) (Figure 8a).<sup>20,102,333</sup> Through the close stacking of their monomeric units, the intermolecular collisions are strengthened in the formed polymers. The construction of conjugated polymers can partly quench molecular fluorescence and enhance nonradiative relaxation, resulting in efficient photothermal conversion.<sup>98</sup> Moreover, donor−acceptor (D-A) strategies have been proposed to develop a new series of conjugated polymers for further extending light absorption and improving light-to-heat conversion efficiencies.<sup>334−338</sup> Figure 8b presents a typical class of polymer-based photothermal materials with D-A structures consisting of diketopyrrolopyrrole (DPP) as an acceptor and a series of electron-donating polymers as donors.<sup>102</sup> While a conjugated polymer serves as a donor for absorbing light, another polymer accepts the excited electrons from the conjugated polymer and further releases them through nonradiative decay. The polymer as an acceptor needs to have a Fermi level that is lower than the excited state of the donor. The bandgap of these D-A structures can be facilely modulated by tuning the ratio and strengths of the donor and acceptor units.<sup>339</sup> When the D-A structures are activated under external light irradiation, intramolecular charge transfer is induced along the backbone. The radiative recombination of electrons and holes can be consequently 

suppressed, which enhances heat generation. This D-A strategy has been employed to prepare conjugated polymer nanoparticles for the harvesting of NIR light.<sup>334</sup> The photothermal conversion efficiency as high as 62.3% has been achieved by introducing a porphyrin-pyrene pendant as an extra lightharvesting unit. The same research group has further demonstrated a new type of biodegradable conjugated polymer made of two acceptors and one donor.<sup>340</sup> This A-D-A structure not only contributes to nearly complete fluorescence quenching but also brings about a narrow energy gap. The photothermal conversion efficiency has therefore been improved to 82%. 

To further improve the photothermal conversion efficiency and enhance the stability of conjugated polymers, supramolecular assemblies have been extensively developed to fabricate new polymer-based photothermal materials.<sup>341−346</sup> The assembly is distinguished from traditional molecular structural design and based on flexible noncovalent intermolecular interactions, such as van der Waals interaction, hydrogen bonding, and electrostatic interaction.<sup>37</sup> Similar to the aggregation-caused quenching effect, the intrinsic fluorescent emissions of molecules can be largely quenched in the supramolecular system, which results in the enhancement of heat generation.<sup>347</sup> In addition, the material stability can be significantly improved through the formation of supramolecular structures. The monomeric molecules are trapped into supramolecular assemblies where only a few peripheral molecules can be affected by the outer environment.<sup>21</sup> The isolation of the photothermal molecules can effectively avoid decomposition or oxidation, thereby maintaining their photophysicochemical properties. The photothermal conversion of unstable molecules can be greatly improved. Due to these unique advantages of supramolecular assembly, much effort has been dedicated to the exploration of new assembly methods and the promotion of the light-to-heat conversion perform- 

**6901** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

ance.<sup>348−352</sup> A multicomponent coordination self-assembly approach has recently been developed to synthesize supramolecular nanodrugs (Figure 9a).<sup>349</sup> The assembled multicomponent nanoparticles exhibit well-defined spherical structures, uniform sizes, and robust colloidal stability. Moreover, the development of dual-peak absorbing photothermal nanoagents through the supramolecular assembly strategy has been demonstrated (Figure 9b).<sup>353</sup> Two types of conjugated polymers with D-A structures are used for light absorption in both NIR-I and NIR-II windows. The photothermal conversion efficiencies of this dual-peak absorbing polymer are 44.9% and 43.4% at 808 and 1064 nm, respectively. 

### **3.5. Two-Dimensional Nanomaterials** 

Since the discovery of single-layer graphene in 2004, there has been tremendous growth in the development of 2D nanomaterials with extraordinary physical and chemical properties.<sup>354</sup> Various new types of 2D nanomaterials, including MXenes, MOFs, transition metal dichalcogenides (TMDCs), black phosphorus (BP), tellurene, and layered double hydroxides, have been delicately fabricated with appealing photothermal conversion properties.<sup>22−24,355−358</sup> Unlike graphene or BP made of a single element, TMDCs and MXenes, as two big fast-growing families of 2D nanomaterials, have been rapidly expanded with a large variety of compositions (Figure 10).<sup>359,360</sup> The versatile designability of 2D nanomaterials 



Figure 10. Periodic table showing the compositions of TMDCs and MXenes. 

allows their photothermal performances to be facilely tailored and become competitive with other photothermal materials. 

2D nanomaterials possess a typical layered structure. Their bandgaps can be simply tuned by adjusting the number of layers. The thickness-dependent bandgaps endow them with a wide absorption band. For instance, the bandgap of BP can be changed from 0.3 to 2 eV across a broad range from the visible to FIR region by controlling the layer number.<sup>361,362</sup> As the thinnest materials ever known, 2D nanomaterials have the highest specific surface areas compared to zero-dimensional (0D), 1D, and bulk materials.<sup>363</sup> The ultrathin structure can not only bring rapid response to light but also provide excellent in-plane electron mobilities to achieve high photothermal conversion efficiencies. MXenes, specifically Ti3C2, have been reported to possess a perfect light-to-heat conversion efficiency of 100%, showing the promising future of MXenes for photothermal applications.<sup>364</sup> 

MXenes have become a rapidly rising star among 2D nanomaterials since the first reported synthesis of Ti3C2 in 2011.<sup>360,365,366</sup> As carbides and nitrides of transition metals, MXenes have a general chemical formula of M _n_ +1X _n_ T _x_ , where M represents an early transition metal (Sc, Ti, V, Cr, Y, Zr, Nb, Mo, Hf, Ta, W), X represents carbon or nitrogen, and T denotes the surface termination (OH, O, F, Cl).<sup>367</sup> They can be synthesized by selective etching of their precursor ternary MAX phases, where A represents a group IIIA or IVA element.<sup>368</sup> While numerous MXene compositions have already been prepared, many more have been predicted by computational methods. Because of the presence of transition metals, the free charge carrier densities of MXenes are on the order of 10<sup>22</sup> cm<sup>−3</sup> and the reported highest metallic conductivity<sup>369,370</sup> reaches up to 20000 S cm<sup>−1</sup> . Based on their excellent metallic conductivity and layered structure, MXenes exhibit a strong electromagnetic interference (EMI) shielding effect (Figure 11a).<sup>371</sup> Except for the immediately reflected waves from the surface, the remaining EM waves suffer from multiple internal reflections within the MXene flakes, leading to more absorption and an overall attenuation of EM waves. In addition to the EMI shielding effect, the abundant free charge carriers of MXenes also bring about LSPRs (Figure 11b).<sup>372</sup> The plasmonic properties can be chemically tuned by altering the structure and type of the X and M sites, as well as the stoichiometry of the surface terminations.<sup>39</sup> MXenes with various compositions support tunable plasmon resonances in the entire visible and NIR regions.<sup>373</sup> The interband transitions of MXenes can also induce strong absorption in the UV region. These unique 



Figure 11. EMI shielding and LSPR effects in MXenes. (a) Proposed EMI shielding mechanism. Reprinted with permission from ref 371. Copyright 2016 American Association for the Advancement of Science. (b) Schematic illustration of the LSPR-induced photothermal and hotelectron effects. Reprinted with permission from ref 372. Copyright 2021 Wiley-VCH. 

**6902** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 12. Macroscopic and microscopic temperature measurements. (a) Schematic diagram of typical photothermal characterization with traditional thermometric techniques. The heating and cooling processes are controlled by switching on and off the laser and monitored with mercury thermometers or thermocouples. The macroscopic temperature distribution can be imaged with an IR camera. (b) Simulation of the photothermal effect of a Au nanosphere (radius, 50 nm) placed in water under an incident light at 530 nm, tuned to the dipole plasmon resonance wavelength. Left: electric field intensity profile normalized to the incident field. Right: equilibrium distribution of the temperature increase. Reprinted with permission from ref 260. Copyright 2010 American Chemical Society. (c) Simulated transient temperature increase of a Au nanosphere (radius, 50 nm) in water excited by on−off modulated light. _T_ h and _T_ l represent 90% and 10% of the temperature step, respectively, which define the rise and fall time of 110 ns. Reprinted with permission from ref 382. Copyright 2012 American Chemical Society. 

merits of MXenes are beneficial for efficient light harvesting and thermal energy generation.<sup>23</sup> 

### **3.6. Hybrid Photothermal Nanomaterials** 

Hybridization is a simple strategy to obtain complementary and synergistic properties from each component. The formation of hybrid nanostructures composed of different photothermal materials has been widely employed to achieve enhanced light absorption and better photothermal capabilities.<sup>49,374−380</sup> Metal nanostructures incorporated with plasmonic semiconductors or other metals can create a dualplasmonic system with multiple plasmon resonance modes for broadening the NIR absorption band.<sup>34</sup> The decoration of semiconductors with Pd nanoparticles as metallic active sites is usually used for improving the photothermal catalytic activities.<sup>146</sup> The introduction of Ag nanoparticles to other photothermal materials can give rise to a greatly synergistic antibacterial and photothermal performance.<sup>381</sup> To overcome the disadvantages of poor photostability and high photoluminescence emission, conjugated polymers are integrated with carbon-based materials or plasmonic metals.<sup>99</sup> On the other hand, the modification of these inorganic materials with polymers can also minimize their long-term toxicity. Consequently, the hybrid design provides a promising way to engineer photothermal materials with synergistic optical properties for targeted applications. 

### **4. PROBING OF PHOTOTHERMAL HEAT GENERATION** 

Traditional thermometric techniques, such as mercury thermometers, thermocouples, and IR cameras, can only give macroscopic temperatures as a collective effect of photothermal nanomaterials and are usually limited to the measurements of bulk or surface temperatures with low spatial and temporal resolution (Figure 12a). These conventional thermometers are commonly used for monitoring the heating and cooling processes of photothermal nanomaterials irradiated by a continuous laser on the time scale of a few hundreds of seconds, from which the photothermal conversion efficiency 

can thereby be derived.<sup>12,21,85,363</sup> However, photothermal conversion and the associated effects actually occur on much shorter time scales and in nanoscale dimensions that are beyond the reach of traditional thermometry. 

Take plasmonic nanoparticles as an example. LSPR and plasmonic heating are intrinsically localized and involve ultrafast excitation. Electromagnetic and thermodynamic simulations show that the photothermal-induced heat is highly concentrated at the surface (<20 nm) of irradiated plasmonic nanoparticles (Figure 12b) and strongly depends on the size and shape of the nanoparticles.<sup>260</sup> In addition, the local temperature increase can be extremely rapid (Figure 12c), reaching the nanosecond and even picosecond levels, as revealed in the pioneering works<sup>383,384</sup> and a more recent work.<sup>382</sup> This recent work shows the reshaping of individual Au nanoparticles triggered by transient photothermal heating with femtosecond and nanosecond laser pulses. 

Accurate temperature measurement of nanomaterials is critical for understanding their photothermal properties, heat generation mechanisms, and roles in physical, chemical, and biological applications. Controlled local heating is essential in biomedical diagnosis and therapeutics, especially for killing cancer cells in tumors with temperature elevation above the physiological level (41−42 °C) and simultaneously preventing excessive injury to the surrounding healthy tissues or posttreatment inflammatory responses.<sup>385,386</sup> In photothermal catalysis, the temporal scales of the plasmon-induced hot carrier generation, hot electron transfer, and thermalization processes are on the time scales of fs to sub-ns.<sup>9,387</sup> Excessive local heating also poses problems for the stability of the nanomaterials themselves and for the proper functioning of the associated optoelectronic devices. Therefore, monitoring the local temperature distributions and transient temperatures of photothermal nanomaterials, with sufficient sensitivity and accuracy, is of general interest to a wide range of scientific communities, from fundamental materials science to chemical and medical applications. Consequently, nanothermometers and spectroscopic methods have emerged as alternative tools 

**6903** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 13. Nanothermometers for local temperature measurements. (a) Schematics (upper row) illustrating three different configurations for combining nanoheaters and nanothermometers and transmission electron microscopy (TEM) images (lower row) of representative hybrid nanostructures: (1) (NaYF4:Yb,Er up-conversion nanoparticle (UCNP))@(mesoporous silica (mSiO2))-(Au nanoparticle) core−satellite nanoassemblies. Reprinted with permission from ref 394. Copyright 2019 Royal Society of Chemistry. (2) (Au nanorod)-(NaGdF4:Yb,Er UCNP) core−satellite nanoassemblies. Reprinted with permission from ref 397. Copyright 2016 Wiley-VCH. (3) Polystyrene beads attached with Au nanostars and CaF2:Nd<sup>3+</sup> ,Y<sup>3+</sup> UCNPs. Reprinted from ref 400. Copyright 2019 Ivyspring International Publisher under the CC BY 4.0 license http://creativecommons.org/licenses/by/4.0/. (b) Illustrations showing temperature-sensing strategies relying on (1) emission intensity, (2) peak position, (3) emission intensity ratio, (4) emission lifetime, (5) fluorescence polarization anisotropy, (6) electron spin resonance or ODMR. (c) Thermal sensitivities of different luminescent nanothermometers and their spectral operation ranges. Reprinted with permission from ref 391. Copyright 2017 Wiley-VCH. 

for temperature measurements with improved spatial, temporal and temperature resolutions.<sup>388−391</sup> 

### **4.1. Heater** − **Thermometer Nanoplatforms** 

Heater−thermometer nanoplatforms refer to hybrid nanostructures consisting of photothermal nanomaterials (nanoheaters) and nanothermometers. Such hybrid nanostructures enable simultaneous heating and nanothermometry. A straightforward approach is to simply mix nanoheaters and nanothermometers in a matrix, which has been employed to compare the heating and absorbing efficiency of Au nanoparticles with different geometries,<sup>392</sup> as well as to monitor plasmonic heating in a subtissue.<sup>393</sup> Nevertheless, direct decoration of nanothermometers on the surface of nanoheaters, or _vice versa_ , is highly desired for local temperature measurements with higher accuracy. Figure 13a illustrates three configurations that have been experimentally proven to work: (1) thermometer−heater core−satellite nanostructures,<sup>394−396</sup> (2) heater−thermometer core−satellite nanostructures,<sup>397−399</sup> and (3) codeposition of heaters and 

thermometers on a sub-microscale substrate.<sup>400</sup> These heater−thermometer nanoplatforms can be constructed using different photothermal nanomaterials and nanothermometers as building blocks. 

The selection of nanothermometers can cover a series of luminescent temperature-responsive probes, including fluorescent small molecules,<sup>401</sup> fluorescent proteins,<sup>402</sup> quantum dots (QDs),<sup>403</sup> lanthanide-ion-doped UCNPs,<sup>404</sup> vacancy-containing nanodiamonds,<sup>405−407</sup> carbon dots,<sup>408,409</sup> and polymeric nanoparticles.<sup>409</sup> The operation of these nanothermometers mostly relies on the temperature-dependent fluorescence properties (Figure 13b), for example, the emission intensity, emission peak shifting, spectral ratio between the different fluorescence bands, lifetime, polarization anisotropy, and electron spin resonance or optically detected magnetic resonance (ODMR). All of these signals allow for the realtime and noninvasive monitoring of local temperatures. Briefly, the fluorescence intensity of small organic molecules generally decreases as the temperature is increased because of the 

**6904** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 14. Heater−thermometer nanoplatforms. (a) Schematic (left) showing the temperature-dependent orientation change of phenyl isocyanide molecules on the surface of Au nanoparticles, and resultant temperature- (middle) and laser power-dependent (right) surface-enhanced Raman scattering (SERS) spectra of the N�C stretching vibrations. Reprinted with permission from ref 411. Copyright 2018 American Chemical Society. (b) Dye-loaded ZIF-8 for temperature sensing based on the luminescent intensity ratio and emission peak shift. Reprinted with permission from ref 414. Copyright 2021 American Chemical Society. (c) Core@shell NaLuF4:Yb,Er@NaLuF4 UCNPs coated by carbon for photothermal heating and temperature sensing. Upper left: schematic of the UCNP@C nanoparticles. Lower left: energy diagram of the thermally sensitive UCL process. Upper right: emission spectra of the UCNP@C nanoparticles at different temperatures by external heating. Lower right: temperature evolution of the UCNP@C nanoparticles in an aqueous dispersion under irradiation with a 730 nm laser at 0.8 and 0.3 W·cm<sup>−2</sup> . A.T.: apparent temperature recorded by a thermal camera. E.T.: eigen temperature calculated by the UCL spectra. Reprinted from ref 396. Copyright 2015 Springer Nature under the CC BY 4.0 license http://creativecommons.org/licenses/by/4.0/. (d) Multilayer NaYbF4:2%Er@NaYF4@mSiO2@Au@SiO2@Ag2S nanoparticles. From left to right: schematic illustrating the multilayer structure, heat conduction diagram under internal heating, TEM image of the multilayer nanoparticles, and temperature evolution ( _T_ 1: apparent temperature of the solution measured by a thermocouple; _T_ 2: core temperature measured by the UCNPs; _T_ 3: outmost layer temperature measured by the Ag2S QDs). Reprinted with permission from ref 415. Copyright 2020 American Chemical Society. 

thermal quenching effect.<sup>401</sup> Some specific molecules, such as green fluorescent proteins and organic dyes, possess temperature-dependent fluorescence polarization anisotropy; that is, the ratio of the emission intensities collected under different polarization states can vary with the environmental temperature.<sup>402</sup> Aggregation-induced emission (AIE) molecules have also been demonstrated to display temperature-responsive properties in terms of spectral position, fluorescence intensity, and fluorescence lifetime.<sup>410</sup> Most semiconductor QDs exhibit temperature-dependent spectral shifts and lifetime variations because of their bandgap changes with temperature.<sup>403</sup> UCNPs 

with specific thermally coupled energy-level pairs, such as Er<sup>3+</sup> (<sup>2</sup> H11/2 and<sup>4</sup> S3/2), Nd<sup>3+</sup> (<sup>4</sup> F5/2 and<sup>4</sup> F3/2), and Eu<sup>3+</sup> (<sup>5</sup> D1 and 5D0), are commonly used for temperature sensing by monitoring the intensity ratio between the two related fluorescence bands, also known as ratiometric optical nanothermometry.<sup>389,404</sup> Fluorescent nanodiamonds for temperature sensing rely on the spin resonances of the nitrogenvacancy center and their temperature-dependent shifts in the ODMR spectrum at microwave frequencies.<sup>405−407</sup> An important figure of merit for the comparison of nanothermometers is the relative thermal sensitivity, which is 

**6905** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 15. Non-nanoprobe thermometry. (a) Local temperature measurement of Au nanorods with X-rays. (1) Schematic illustrating the photothermal excitation of Au nanorods with visible-NIR light and the local temperature detection with X-rays. (2) Fourier transforms of the X-ray absorption fine structure spectra of Au nanorods under an NIR laser at different powers. (3) Debye−Waller factor parameters ( _σ_<sup>2</sup> ) of the Au nanorods as a function of temperature. The calibration curve was first obtained for a set of temperatures (open circles) and then used for the temperature determination under different laser excitation conditions (solid circles). Reprinted with permission from ref 417. Copyright 2021 American Chemical Society. (b) Local temperature measurement of individual Si nanoparticles by Raman spectroscopy. (1) Experimental Raman spectra for a spherical Si nanoparticle with a diameter of 350 nm on a glass substrate. (2) Schematic illustration, SEM image, and reconstructed 2D temperature map of a single Si nanoparticle under laser irradiation at an intensity of 2 mW _μ_ m<sup>−2</sup> . Reprinted with permission from ref 420. Copyright 2017 American Chemical Society. (c) Local temperature measurement of Au nanorods by anti-Stokes Raman spectroscopy. (1) Luminescence emission spectra of a single Au nanorod under 532 nm excitation (green) and 633 nm excitation at three different powers (purple, orange, and blue). The red curve is the surface plasmon profile extracted from the green curve using the Lorentz function. The inset shows the antiStokes-to-Stokes ratio as a function of the excitation power, overlapped with a linear fit in red. (2) Anti-Stokes Raman intensity of a single Au nanorod at different irradiation powers. The inset shows the extracted temperature at each power. Reprinted with permission from ref 427. Copyright 2018 American Chemical Society under the CC-BY-NC-ND 4.0 license http://creativecommons.org/licenses/by/4.0/. 

defined as the rate of change in the temperature-sensitive parameter with temperature, _S_ r = _Q_ 1 _<u>QT</u>_ , where _Q_ denotes the 

temperature-sensitive parameter (intensity, lifetime, ratio) and _T_ denotes temperature. _S_ r is comparable between different systems with the consistent unit of K<sup>−1</sup> or % K<sup>−1</sup> . Figure 13c provides a brief summary of the thermal sensitivities and spectral operation ranges of different luminescent nanothermometers, together with the first and second biological windows (BW-I and BW-II) where the absorption and scattering of biological tissues is minimal.<sup>391</sup> Comparison of other factors, such as the thermal accuracy, sensor size, and 

thermal and special resolution, and more detailed discussion about different nanothermometers have been summarized in a few recent review articles.<sup>386,388−391</sup> 

With advances in surface functionalization and assembly techniques, heater−thermometer nanoplatforms with different compositions and various configurations have been experimentally achieved. Plasmonic nanoparticles are the most commonly used nanoheaters because of their high photothermal conversion efficiencies and ease of surface functionalization. For example, local temperature measurements of Au nanoparticles have been demonstrated by monitoring the Raman spectra of phenyl isocyanide molecules functionalized 

**6906** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

on the top surface of the Au nanoparticles (Figure 14a).<sup>411</sup> Since the molecules take a more tilted angle to the Au surface as the temperature is increased, the Raman peak associated with the N�C stretching vibrations exhibits sensitive shifts with temperature. This phenomenon has further been used to determine CO photothermal desorption from the Au surface at ∼62 °C and to track the local temperature variations of a single living cell. Similarly, Au nanoparticles have been combined with molecular beacons,<sup>412</sup> nanodiamonds,<sup>413</sup> and UCNPs,<sup>400</sup> respectively, for extracellular or intracellular local heating and temperature monitoring. Multimode temperature readout has been realized by encapsulating two types of luminescent dyes (4-Mu and Flu) into the pores of a nanoscale MOF zeolitic imidazolate framework-8 (ZIF-8) and measuring the emission intensity ratio and maximum emission wavelength (Figure 14b).<sup>414</sup> The thermal sensitivity can reach _S_ r = 0.62% K<sup>−1</sup> at 240 °C; albeit, the photothermal conversion effect is not significant in this system. UCNP@C core@shell nanoparticles have been successfully prepared for simultaneous photothermal heating and nanothermometry (Figure 14c).<sup>396</sup> Accurate PTT has been demonstrated by use of the photothermally active carbon nanoshells as heaters and the UCNPs for the real-time monitoring of microscopic temperatures, so as to reduce injury on the normal tissues during photothermal treatment. The local temperature calculated from the up-conversion luminescence (UCL) spectra is 10−15 °C higher than the macroscopic temperature recorded by a thermal camera, indicating the important role of accurate nanothermometry in biomedical diagnosis and therapeutics. The same group has further developed a complex multilayer structure in the form of NaYbF4:2%Er@NaYF4@mSiO2@Au@SiO2@Ag2S (Figure 14d), where the Au nanoparticles play the role of nanoheaters, whereas both the NaYbF4:2%Er@NaYF4 UCNPs and the Ag2S QDs function as nanothermometers.<sup>415</sup> In the photothermal measurements, the Ag2S nanothermometers, which are designed to be closest to the nanoheaters, experience rapid heating and reach an equilibrium temperature rapidly. More interestingly, the measured temperatures follow the order Ag2S > UCNP > thermocouple, which matches well with the order of the distance between the Au nanoparticles (nanoheaters) and the different thermometers. Although there are not many hybrid systems that can perform effective local heating and local temperature detection at the same time, such efforts are beneficial for the development of heater−thermometer nanoplatforms with accuracy, sensitivity, and resolution, as well as for understanding the heating mechanisms of different photothermal nanomaterials. However, it is worth noting that the introduction of a nanothermometer near a nanoheater might affect the optical properties of both sides, including the heating efficiency of the nanoheater and the temperature calibration curve of the nanothermometer. Careful calibration is therefore especially crucial for these new systems.<sup>416</sup> 

### **4.2. Non-nanoprobe Thermometry** 

Non-nanoprobe thermometry refers to the direct measurement of the local temperatures or steady-state spatial temperature gradients of photothermal nanomaterials without introducing any nanothermometers. It mainly relies on various spectroscopies. The simplicity of local temperature control allows for an in-depth study of the dissipation and heat transfer mechanisms at the nanoscale. 

X-ray can be used as the probe for local temperature measurements. _In situ_ local temperature measurements of the 

photoinduced heating in single and hybrid Au nanoparticles have been demonstrated using extended X-ray absorption fine structure spectroscopy (EXAFS).<sup>417</sup> The temperature dependence of the structural and vibrational local parameters of Au nanoparticles can be quantified through the Fourier analysis of the EXAFS spectra, which contain information about photoexcited electrons that interact with the atomic local environment of the scattered atoms (Figure 15a). Although the measurements are time-consuming (∼2 h per sample per experimental condition),<sup>417</sup> the work reveals significant nanoscale thermal gradients, i.e., large variations of temperature within a small volume. In principle, this method allows for the measurements of the heating at the nanoscale for other types of nanoparticles under hyperthermia exposure. In addition, a scheme based on an optical pump and an X-ray diffraction probe has been developed to directly measure the photothermal effects on the lattice of TiN nanoparticles dispersed in water.<sup>418</sup> The lattice temperature of the TiN nanoparticles, from room temperature up to as hot as 175 °C, can be measured by calibrating transient X-ray diffraction data against static powder diffraction measurements at elevated temperatures. The heat capacity of the TiN nanoparticles has further been studied. The temporal dynamics of heat transfer from the TiN nanoparticles to the solvent is found to be on a time scale of 0.4−1 ns. This technique has also been employed for the internal temperature measurements of magnetic nanoparticles heated by a high-frequency magnetic field.<sup>419</sup> However, these X-ray-based thermometry techniques typically require powdered samples under inert gas atmosphere, which therefore limits their applications in complicated systems. 

Raman spectroscopies, both of the Stokes and anti-Stokes components, can be utilized for measuring the local temperatures of nanomaterials. In a work reported in 2017, a single Si nanoparticle simultaneously acts as a heater and a thermometer and integrates effective photoinduced heat generation and broad-range temperature sensing.<sup>420</sup> A photoinduced temperature up to 900 K is observed from the Si nanoparticle deposited on a glass substrate under the radiation of a typical 633 nm laser at moderate intensities (<2 mW _μ_ m<sup>−2</sup> ). The temperature sensing is accomplished simply by monitoring the intensity variation of the characteristic 520 cm<sup>−1</sup> (Stokes) Raman mode in silicon (Figure 15b), which is associated with the anharmonic effect in the lattice vibrations and inherently thermally sensitive. However, this method of Raman nanothermometry has very limited applicability to other materials. For most materials, anti-Stokes Raman emission signals are more sensitive to temperature variations than Stokes components.<sup>421</sup> The intensity ratio between the anti-Stokes and Stokes Raman peaks has a temperature-dependent term Ä É ÅÅÅÅÅÅ **Å** Çexp( 2 _k_ B _Tv_ m)ÑÑÑÑÑÑ **Ñ** Ö, where _ν_ m is the vibrational frequency of the 

excited state. The anti-Stokes to Stokes intensity ratio is therefore commonly used as a more general approach for direct local temperature measurements.<sup>422−426</sup> However, since the anti-Stokes signals are usually very weak, a careful calibration is crucial for accurate intensity measurements. An alternative method has therefore been developed to overcome this problem. In the method, the anti-Stokes luminescence emissions rather than the anti-Stokes to Stokes intensity ratio are used to obtain the absolute temperature of individual Au nanorods (Figure 15c).<sup>427</sup> Without the need for precalibration, the temperatures of the Au nanorods can be determined _in situ_ with an accuracy of 6% (4 K) by recording the anti-Stokes 

**6907** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

spectra of the individual nanorods with an acquisition time of 3 min (Figure 15c (1)). Furthermore, the accuracy can be improved to better than 2% by performing this single-particle Anti-Stokes emission measurement at different irradiation powers (Figure 15c (2)).<sup>427</sup> Taken together, all the works discussed above about the thermometry for photothermal conversion suggest that fast and accurate transient local temperature probing techniques have remained a challenge. 

### **5. APPLICATIONS** 

Together with the investigation on photothermal conversion mechanisms and the advancement of nanofabrication techniques, immense effort has been made to extend the applications of photothermal nanomaterials. Nanomaterials with efficient solar-to-heat conversion provide a promising solution to satisfy the ever-increasing water and energy demand. Pure water can be produced from seawater and wastewater through solar water heating and evaporation, which can be accelerated by suitable photothermal nanomaterials. The generated hot vapor during solar evaporation can be used for sterilizing, driving mechanical work, and even producing electricity. Photothermal conversion by nanomaterials has also been employed in other physical (laser printing, photothermal manipulation), chemical (photothermal catalysis), and biological (PTT, drug delivery, bacterial inhibition) applications. In this section, we will provide an overview on the recent developments in the applications of photothermal nanomaterials. Some of the most representative examples are highlighted to show the advantages of nanomaterials in these photothermal applications. 

### **5.1. Solar Thermal Water Heating** 

Owing to the development of various photothermal materials, new solar thermal systems have emerged for efficient water heating and vapor generation. Because of the vast number of works in this area, representative works on solar thermal water heating and evaporation are summarized in Table 2. They serve as references for researchers who are interested in this area. Photothermal water heating systems can be categorized into different types according to the relative position of the solar-absorbing material and the water medium (Figure 16a).<sup>7,51</sup> (1) When the solar absorbers are dispersed in water, the photothermal energy collected by the absorbers will transfer to water through classical (global heating) and nonclassical (nanobubble generation) mechanisms. Such volumetric systems, also known as nanofluids, usually employ well-dispersed plasmonic nanoparticles or carbon-based nanomaterials as the solar absorbers.<sup>428−435</sup> Nanomaterials possess high surface-to-volume ratios and provide large surface areas for heat transfer to the surrounding medium. For classical heating, the solar absorbers act as the heat sources and transfer thermal energy to increase the temperature of the bulk fluid. For nonclassical heating, nanoparticles under concentrated sunlight absorb solar energy efficiently and raise their surface temperature above the boiling point of the fluid.<sup>428,429</sup> A thin shell of water in direct contact with the nanoparticles transforms into vapor, forming nanobubbles. The complex made of the nanoparticle and the surrounding vapor moves to the liquid−air interface and releases the vapor. In this way, solar energy is primarily directed to the vaporization of water, with a much smaller fraction used for the heating of the bulk fluid. (2) When the solar absorbers are placed on the surface of the bulk water, the photothermal system is called the interfacial solar evaporation system.<sup>436</sup> In contrast to the volumetric 

photothermal system, the interfacial system confines the solar heat and vapor generation at the water−air interface. The temperature of the underneath bulk water remains low during the evaporation process, minimizing the heat loss through the surrounding environment. The light-absorbing materials either directly float on water or are placed onto a porous layer with interconnected water-supplying channels.<sup>7</sup> (3) Isolation systems with the solar absorbers separating from the bulk water have also been proposed to further suppress the conduction heat losses. To achieve a small contact area between the absorbers and the bulk water, confined 1D/2D water paths with a sufficient water-supply capability have been designed and fabricated.<sup>437−439</sup> For example, monolithic carbon sponges with self-contained water have been demonstrated for vapor generation,<sup>440</sup> where the photothermal system is completely isolated from the bulk water. In another example, a contactless vapor generation system has been proposed, with the absorber and the bulk water separated by a gas gap (Figure 16b).<sup>441</sup> The absorber converts solar light to heat and consequently re-emits thermal IR radiation toward the bulk water. Vapor with temperatures as high as 133 °C is produced under one sun illumination in a nonpressurized system. 

The water evaporation rate and efficiency are key parameters for evaluating the capability of a photothermal system to generate water vapor. The water evaporation rate is defined as the amount of generated vapor by a light absorber directly exposed to solar light of unit area within unit time. The evaporation efficiency _η_ eva is defined as the ratio of the energy consumed for evaporation ( _P_ eva) to the energy of light incident on the photothermal system ( _P_ solar).<sup>507</sup> 



<!-- Start of picture text -->
eva<br>= P<br>eva P solar (5.1)<br><!-- End of picture text -->

_P_ eva can be calculated by the product between the vaporization enthalpy of water and the weight of the evaporated water. The values of the water evaporation rates and efficiencies of various photothermal systems are also listed in Table 1. In addition to increasing the light-absorbing capability of the solar absorber, the water evaporation rate and efficiency can also be improved by optimizing the heat management and water supply, harvesting the environmental energy, as well as reducing and reusing the vaporization enthalpy. Groove structures on the hydrogel surface can introduce temperature gradients and tension gradients, activating the Marangoni convection effect to accelerate water flow (Figure 16c).<sup>465</sup> The accelerated water flow can reduce the viscosity of the internal water and activate the free water around the surface, increasing the evaporation rate. In contrast to traditional interfacial solar vapor generators with heat loss into the environment, most 3D absorbers can be kept cooler than their surrounding environment, which allows energy to be conveyed from the environment and thus to efficiently diminish the energy loss.<sup>448,467,497</sup> With the environmental energy used as an additional input, the calculated evaporation efficiencies of those systems can be close to or even beyond 100%.<sup>448,467,497</sup> A carbon foam with interconnected porous structures has been reported to harvest wind energy as additional energy.<sup>445</sup> An impressive evaporation rate of 10.9 kg m<sup>−2</sup> h<sup>−1</sup> under one sun illumination has been achieved with a convective flow of 6 m s<sup>−1</sup> . Porous networks of polymer films have been reported to confine water into clusters and lead to the reduction of the evaporation enthalpy.<sup>483,504,505</sup> 

**6908** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

|note|used for ethanol distillation<br>used for sterilization<br>exhibit better photothermal conversion efficiencies than the<br>graphene and graphene oxide ones||magnetic separation for recycling nanoparticles<br>salt-resistant ability based on the Donnan effect|bioinspired structure|wind used as an additional energy source|antifouling and salt-rejecting structure|seawater desalination and wastewater purification|isolated salt crystallization|energy gained from the environment|implement CO2 activation to increase the hot-electron effect|used for anti-icing<br>seawater desalination<br>saline water desalination|seawater desalination with salt-resistant properties|continuous desalination with salt excretion|self-salt-cleaning|iidbthtitiit|nspre y e ranspraon n rees|ttifiti|wasewaer purcaon|seawater desalination and wastewater purification|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|evaporation<br>efficiency|0.24<br>0.785<br>0.3097<br>0.65<br>0.925<br>0.9693|0.69|0.603<br>0.8|0.8|0.92<br>0.85|0.25|0.82|0.812|∼1|0.868<br>0.8751|0.5094<br>0.538|0.72|0.8475||0921|.|0894|.|0.928|
|water evaporation rate|6.27 kg m−2h−1under 10 sun irradiation|10.9 kg m−2 h−1 under 10 sun<br>illumination|1.3 kg m−2 h−1 under 1 sun irradiation|1.31 kg m−2h−1 under 1 sun irradiation|1.4 kg m−2h−1under 1 sun illumination<br>10.9 kg m−2h−1 under 1 sun irradiation<br>11 kg m−2 h−1 at 10 kW m−2 solar<br>irradiance|2.5 L day−1with daily insolation of 6 kW<br>h m−2|1.32 kg m−2 h−1 under 1 sun<br>illumination|1.42 kg m−2 h−1 under 1 sun<br>illumination|1.77 kg m−2 h−1 at 120 mW cm−2 solar<br>irradiance<br>|3.9186 kg m−2 h−1 under 3 sun<br>illumination<br>1.37 kg m−2 h−1 under 1 sun<br>illumination|1.1 kg m−2h−1under 1 sun illumination<br>0.5 kg m−2 h−1 at 700 W m−2 solar<br>irradiance|1.3 kg m−2h−1under 1 sun illumination|1.35 kg m−2 h−1 under 1 sun<br>illumination|9.05 kg m−2 h−1 under 1 sun<br>illuminationwithnaturalwind|<br>412k−2 h−1 d1|. g m  uner  sun<br>illumination|134k−2 h−1 d1|. g m  uner  sun<br>illumination|14.31 kg m−2 h−1 under 10 sun<br>illumination|
|photothermal material and device|nanofluid of Au nanoshells<br>nanofluid of Au nanoshells<br>nanofluid of Au-Ag nanoplates<br>Au, Ag, and Au-Ag blended nanofluids<br>plasmonic nanofluid containing Au nanoparticles<br>CuO and antimony-doped tin oxide composite nanofluid<br>reduced graphene oxide nanofluid|carbon black, graphene, and graphitized carbon black nanofluids|nanofluid of Fe3O4@CNTs<br>carbon fibers|hierarchical Cu structures with Al2O3 coating and carbon black<br>nanoparticles|carbon nanosheets<br>3D porous carbon foam<br>carbon foam/exfoliated graphite layers|contactless solar evaporator with porous reticulated vitreous<br>carbon foam|CNT membrane|CNTs/filter paper/cotton thread/polystyrene foam|composite of cotton, cellulose, carbon black nanoparticles, and<br>polystyrene foam|hollow carbon-nanotube aerogel<br>ultrablack carbon aerogel|SiC/CNT coating<br>carbon foam deposited with layered BiInSe3<br>polyvinyl alcohol embedded with carbon black nanoparticles on a<br>polyvinylidene fluoride membrane|poly methylmethacrylate coated with carbon black nanoparticles<br>on polyacrylonitrile layer|carbon-black-coated polyvinyl alcohol cloth|umbrella architecture of carbon-coated fabric|3Ditdhdldtdithbtil|-prne yroge ecorae w caron nanoparces|lfCNTdhdtiti|aeroge o s an yroxyapae nanowres|composite paper of CNTs and hydroxyapatite nanowires|
|reference|428<br>429<br>218<br>430<br>431<br>432<br>433|434|435<br>442|443|444<br>445<br>312|441|446|447|448|314<br>449|450<br>451<br>452|453|454|455|456||457||458|
|category|nanofluids||carbon-based<br>materials|||||||||||||||||



**6909** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

|note|waste energy-to-electricity conversion by thermoelectric<br>modules||electricity generation by water evaporation-induced piezo-<br>|pyroelectric response|anticlogging coating prevents salt accumulation|simultaneous generation of clean water and electricity||efficiency of 62% achieved for natural mushrooms<br>solar desalination with four orders of salinity decrement|inspired by the natural transpiration process in plants|improved efficiency compared to chemically reduced graphene<br>oxide|enthalpy of vaporization lowered and Marangoni effect induced|seawater desalination and wastewater purification<br>energy gained from the environment|reconfigurable and magnetically responsive evaporator||water evaporation rate of 3.46 kg m−2h−1and efficiency of 0.81<br>under 3 sun illumination|electricity extracted from the evaporation-induced salinity<br>gradient||adjustable device by magnetic field|wastewater purification<br>nearly 100% internal solar-thermal conversion efficiency|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|evaporation<br>efficiency|0.874|0.856|0.9||0.627|0.817||0.78<br>0.94|0.85|0.942<br>0.8<br>0.9<br>0.48|0.91|0.938<br>1.02||0.83|0.72<br>0.725|0.862<br>0.75<br>|0.778|0.797|0.8<br>0.92|
|photothermal material and device<br>water evaporation rate|sponge with polydimethylsiloxane, CNTs, and cellulose<br>nanocrystals<br>1.35 kg m−2 h−1 under 1 sun<br>illumination|3D-printed structure with CNTs, graphene oxide, and<br>nanofibrillated cellulose<br>1.25 kg m−2 h−1 under 1 sun<br>illumination<br>|monolithic carbon sponge<br>1.39 kg m−2 h−1 under 1 sun<br>|illumination|hydrogel-coated graphite film<br>1.01 kg m−2 h−1 under 1 sun<br>illumination|graphite/nonwoven film on nonwoven-wrapped polystyrene foam<br>34.8 kg m−2 h−1 at 30 kW m−2 solar|irradiance|carbonized mushrooms<br>1.475 kg m−2h−1under 1 sun irradiation<br>graphene oxide film<br>1.45 kg m−2h−1 under 1 sun irradiation|graphene oxide<br>16.1 kg m−2 under 8 h outdoor solar<br>irradiation|graphene sheets<br>6.25 kg m−2 h−1 under 4 sun<br>illumination<br>porous graphene<br>1.5 kg m−2h−1under 1 sun illumination<br>hierarchical graphene<br>1.4 kg m−2 h−1 at 5 kW m−2 solar<br>irradiance<br>hydrophilically functionalized graphene<br>0.47 kg m−2 h−1 under 1 sun<br>illumination|hydrogel embedded with Ti3C2T_x_ MXene and reduced graphene<br>oxide<br>3.62 kg m−2 h−1 under 1 sun<br>illumination|aerogel made of PPy-coated MnO2 nanowires and reduced<br>graphene oxide<br>1.587 kg m−2 h−1 under 1 sun<br>illumination<br>reduced graphene oxide and silk fabric<br>1.48 kg m−2 h−1 under 1 sun<br>illumination|conic arrays consisting of graphene-wrapped Fe3O4 nanoparticles<br>5.88 kg m−2 h−1 under 1 sun<br>illumination|graphene-oxide-coated wood<br>14.02 kg m−2 h−1 under 12 sun<br>illumination|flame-treated wood<br>1.05 kg m−2 h−1 under 1 sun<br>illumination<br>PPy-decorated wood<br>1.014 kg m−2 h−1 under 1 sun<br>illumination|CuFeSe2-nanoparticle-decorated wood<br>6.6 kg m−2h−1under 5 sun illumination<br>CNT-modified filter paper<br>1.15 kg m−2 h−1 under 1 sun<br>illumination<br>PPy-modified paper<br>2.99 kg m−2 h−1 under 1 sun<br>illumination<br><br>−1|air-laid paper and Au-nanoparticle-based film<br>1.71 mg s under 4.5 sun irradiation|Au nanoparticles supported on air-laid paper<br>Fe3O4 nanoparticles on air-laid paper<br>1.70 kg m−2 h−1 under 1 sun<br>illumination|Fe3O4 nanoparticles on air-laid paper<br>1.3 kg m−2h−1under 1 sun illumination<br>cellulose membrane deposited with Ti2O3 nanoparticles<br>5.03 kg m−2 h−1 at 5 kW m−2 solar<br>irradiance|
|reference|459|437|440||460|461||439<br>462|438|330<br>463<br>464<br>320|465|466<br>467|468|469|470<br>471|472<br>473<br>474<br>|262|475<br>476|477<br>33|
|category||||||||graphene-related<br>materials||||||wood materials||modified papers|||cellulose-based<br>materials|



**6910** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

|note||salt rejection||superior light absorption properties and rapid capillary-driven<br>water transport|dditithl|reuce vaporzaon enapy|reduced vaporization enthalpy|||||seawater desalination and wastewater purification|||seawater desalination|self-healing hydrophobicity|seawater desalination<br>seawater desalination|temperature polarization<br>seawater desalination and wastewater purification<br>higher thermal conductivity than pure polyethylene glycol|saline water desalination||seawater catalysis and desalination|diffuse reflectance reabsorbed and excess energy gained from<br>the surrounding|thermal concentration and heat localization<br>water evaporation and solar-thermal conversion separated on<br>the two sides of the film generator|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|evaporation<br>efficiency||0.22|||0935|.|0.94|0.763|0.81|0.85<br>0.82|0.57|0.869|0.8139|0.45|0.915|0.58|0.9<br>0.7752|0.4634<br>0.933|0.636||N/A|∼1|0.71<br>0.88|
|water evaporation rate|8.7 kg m−2 h−1 under 10 sun<br>illumination|2.5 L m−2 day−1 under 1 sun<br>illumination|11.33 kg m−2 h−1 under 1 sun<br>illumination|5.12 kg m−2 h−1 under 1 sun<br>illumination|209k−2 h−1 d1|. g m  uner  sun<br>illumination|3.2 kg m−2h−1under 1 sun illumination|0.32 mg cm−2 s−1 at a power density of<br>51Wcm−2|.  <br>6.15 kg m−2 h−1 at 5.35 kW m−2 solar<br>irradiance|11.8 kg m−2h−1under 10 sun irradiation<br>1.13 kg m−2 h−1 under 1 sun<br>illumination|18.5 kg m−2 h−1 under 20 sun<br>illumination|1.43 kg m−2 h−1 under 1 sun<br>illumination|3.81 kg m−2 h−1 at 0.294 W m−2 solar<br>irradiance|0.49 kg m−2 h−1 at 0.75 kW m−2 solar<br>idi|rraance<br>6.6 kg m−2 h−1 at 4 kW m−2 solar<br>irradiance|0.92 kg m−2 h−1 under 1 sun<br>illumination|5.7 kg m−2h−1under 4 sun illumination<br>0.50 kg m−2 h−1 under 1 sun<br>illumination|3.7 kg m−2h−1under 5 sun illumination|1.85 kg m−2 h−1 under 1 sun<br>illumination|−2 −1 −2|5.86 L m h under 7 kW m Xe<br>lamirradiance|p <br>2.04 kg m−2 h−1 under 1 sun<br>illumination|2.21 kg m−2 h−1 under 1 sun<br>illumination|
|photothermal material and device|membrane of mixed cellulose ester, ZnO nanorods, and Au<br>nanoparticles|cellulose-based fabric/polystyrene|bilayered hydrogel|3D-printed hydrogel decorated with Fe3O4 nanoparticles|hdldfddhiddTiCTMX|yroge mae o reuce grapene oxe an 32_x_ ene|hierarchically nanostructured gel made of polyvinyl alcohol and<br>PPy|plasmonic aerogel based on biofoam and Au nanorods|bilayer aerogel of MoS2 nanosheets and bacterial nanocellulose|microporous membrane deposited with Au nanoparticles<br>W18O49 mesocrystals on polytetrafluoroethylene membrane|black Au membrane|PDA/polyethylenimine/PPy@polyamide nanofibrous membrane|WO2.72/polylactic acid fiber membrane|PDA-coated polyvinylidene fluoride membrane|hybrid membrane of MoS2 nanosheets and single-walled<br>nanotubes|membrane of PPy-coated stainless steel mesh|self-assembly of Al nanoparticles in anodic Al2O3 membrane<br>polyvinylidene fluoride membrane with Al-Ti-O nanostructures|Ag-nanoparticle-loaded polyvinylidene fluoride membrane<br>Au@TiO2 nanoparticles on microporous membrane<br>composite of polyethylene glycol and poly(acrylamide-co-acrylic<br>acid) copolymer|composite sheet of HCuPO and polydimethylsiloxane||nanocomposite of SiO2/Ag@TiO2|3D-cup-shaped composite of CuFeMnO4 and silica|cermet-coated copper substrate<br>Janus interface based on copper foil and foam|
|category<br>reference|478|479|gels<br>480|481|482||483|484|485|membranes<br>486<br>295|263|487|488|489|490|491|133<br>492|493<br>494<br>other composites<br>495|496||124|497|498<br>499|



**6911** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

|note|minimized optical loss, enhanced heat transfer and<br>condensation||wastewater purification|wastewater purification|parallel production of fresh water and triboelectricity|||strong light absorption through heavy V-doping|seawater desalination|vaporization enthalpy recycled|
|---|---|---|---|---|---|---|---|---|---|---|
|evaporation<br>efficiency|0.7|0.9|0.427|0.8|0.85|0.92|0.62|0.9344|0.891|3.85|
|oration rate|nder 1 sun|er 4 sun illumination|der 1 sun|4 sun illumination|nder 1 sun|der 1 sun|der 5 sun|der simulated solar|der 1 sun|der 1 sun|
|evap|h−1 u|1und|−1 un|under|h−1 u|−1 un|−1 un|−1 un|−1 un|−1 un|
|water|1.063 kg m−2 <br>illumination|5.5 kg m−2h−|1.26 kg m−2 h<br>illumination|5 kg m−2 h−1|1.356 kg m−2 <br>illumination|1.38 kg m−2 h<br>illumination|4.95 kg m−2 h<br>illumination|2.01 kg m−2 h<br>light|1.49 kg m−2 h<br>illumination|5.78 kg m−2 h<br>illumination|
|material and device|purifier|in disordered nanoporous Al2O3|foil|in porous Al template|anoporous silica matrix|||embedded with V-doped MoO3|titanium oxynitride spheres||
|othermal|lar water|particles|ated Al|particles|rsed in n|sheets||etwork|ded with||
|hot|d so|nano|r-tre|nano|ispe|ano||ol) n|bed|still|
|p|r-base|f Au|nd-lase|f Ag|wer-d|PPy n|Ds|alcoh<br>eres|lm em|solar|
||Al-absorbe|assembly o<br>template|femtoseco|assembly o|Au-nanoflo|multilayer|MoO3‑_x_ Q|poly(vinyl <br>nanosph|polymer fi|multistage|
|reference|500|265|501|502|503|333|282|504|505|506|
|category|||||||||||



Reduced vaporization enthalpies have also been observed in hybrid hydrogel and explained by the abundant hydrophilic groups for weakening the interaction of the hydrogen bonds between the water molecules.<sup>465,482</sup> A thermally localized multistage solar still has been demonstrated to recycle the vaporization enthalpy, where the latent heat released from a stage is recycled at the next stage to produce vapor.<sup>506</sup> An evaporation rate of 5.78 kg m<sup>−2</sup> h<sup>−1</sup> and a remarkable evaporation efficiency of 385% under one sun illumination have been experimentally demonstrated. 

**5.1.1. Seawater Desalination.** Although water covers 71% of the surface of the Earth, most of the water resources are stored in the oceans and are too salty to be directly utilized. Desalination, a process that removes salts from saline water, is regarded as one of the most effective solutions to overcome water scarcity. A few developed countries, such as Saudi Arabia, Singapore, and Israel, have been investing in seawater desalination to address their water scarcity issues. Most current techniques of seawater desalination remain expensive since they require enormous amounts of energy. Solar seawater desalination, taking “free energy” from the Sun and producing negligible hazards to the environment, is a green technology to generate freshwater. The integration of a water condensation system with the solar evaporation system can be directly used for seawater desalination. The vapor generated from seawater under solar illumination by a photothermal system is condensed and collected to produce water with low salinity. In a pioneering work, the nanopores of anodic aluminum oxide membranes act as the paths for efficient water supply and continuous vapor flow (Figure 17a).<sup>133</sup> Plasmon-enhanced solar desalination has been successfully demonstrated with the broadband absorption of the assembled Al nanoparticles. The salinities of four representative seawater samples after desalination are all remarkably decreased below the salinity levels of drinkable water defined by the World Health Organization (WHO) and the US Environmental Protection Agency (EPA). Solar absorber films have recently been prepared from V-doped MoO3 nanospheres. They give a fast seawater evaporation rate of 2.01 kg m<sup>−2</sup> h<sup>−1</sup> and a high evaporation efficiency of 93.44% (Figure 17b).<sup>504</sup> The light absorption of the MoO3 nanospheres is significantly enhanced by V-doping, giving rise to over 90% absorption in the wavelength range from 250 to 2000 nm. IR imaging of the solar evaporation system shows that the surface temperature of the solar-absorbing film reaches up to 48.7 °C, while the temperature of the bulk water is barely changed. The synergistic effect between the thermal management and the great light-absorbing capability of the V-doped MoO3 nanospheres results in a superior photothermal conversion performance. The interband-transition-induced resonance and plasmon resonance endow nitridized titania nanospheres with a strong light absorption capability (Figure 17c).<sup>505</sup> The light absorption of the assembly of differently sized titanium oxynitride spheres is significantly enhanced across the solar spectrum. Hollow titanium oxynitride spheres are further incorporated into polyacrylamide-based films and integrated with a 2D water-wicking material for solar seawater desalination. A water evaporation rate of 1.49 kg m<sup>−2</sup> h<sup>−1</sup> and an evaporation efficiency of 89.1% have been demonstrated under simulated sunlight. The freshwater generated from the solar seawater desalination system possesses a significantly reduced salinity, satisfying the WHO standards for drinkable water. Moreover, the salts produced during solar 

**6912** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

<mark>Review</mark> 



<!-- Start of picture text -->
pubs.acs.org/CR<br><!-- End of picture text -->



Figure 16. Solar thermal water heating and evaporation. (a) Schematics of the different types of photothermal systems for water heating and evaporation. Reprinted with permission from ref 51. Copyright 2018 Royal Society of Chemistry. (b) Noncontact radiative transfer from the solar absorber to the water. Reprinted with permission from ref 441. Copyright 2018 Cooper et al., published under the CC BY 4.0 license http:// creativecommons.org/licenses/by/4.0/. (c) Marangoni-effect-accelerated water flow and -enhanced solar evaporation. Reprinted with permission from ref 465. Copyright 2021 American Chemical Society. (d) Environmental-energy-enhanced solar evaporation. Reprinted with permission from ref 448. Copyright 2018 under Elsevier user license. 



Figure 17. Solar heating for seawater desalination. (a) Setup and solar desalination performance of 3D assembled Al nanoparticles. The measured salinities represent the weight percentages of Na<sup>+</sup> of the four simulated seawater samples before and after desalination. The dashed colored lines refer to the WHO and the US EPA standards for drinkable water. Reprinted with permission from ref 133. Copyright 2016 Springer Nature. (b) Schematic and IR image of a porous interlaced poly(vinyl alcohol) network embedded with V-doped MoO3 nanospheres during solar seawater desalination. Reprinted with permission from ref 504. Copyright 2022 American Chemical Society. (c) Schematic and seawater desalination performance of hollow titanium oxynitride spheres as the photothermal transducers. Reprinted with permission from ref 505. Copyright 2022 American Chemical Society. (d) Illustrations and photographs of salt accumulation/excretion in conventional/salt-excreting evaporators. Reprinted with permission from ref 454. Copyright 2021 Wiley-VCH under the CC BY 4.0 license http://creativecommons.org/licenses/by/4.0/. 

**6913** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 18. Solar water heating for wastewater purification. (a) Self-floating aerogel composed of CNTs and hydroxyapatite nanowires for highly efficient solar-energy-assisted water purification. The middle panel shows the concentrations of three types of heavy metal ions in the simulated wastewater before and after photothermal wastewater purification. The right panel shows the UV−visible absorption spectra and photographs of a rhodamine B aqueous solution before and after photothermal purification. Reprinted with permission from ref 457. Copyright 2019 Elsevier. (b) A superwicking and super-light-absorbing aluminum surface for efficient solar-based water sanitation. The schematics show the black aluminum sheet with a rotatable platform to maximize the incident solar flux, and an open capillary architecture for easy cleaning. The histogram demonstrates the water sanitation of four types of heavy metals. The right panel shows the photographs of a Cr<sup>2+</sup> (top) and a rhodamine 6G dye (bottom) aqueous solution before (left) and after (right) photothermal purification. Reprinted with permission from ref 501. Copyright 2020 Singh et al., published under the CC BY 4.0 license http://creativecommons.org/licenses/by/4.0/. 

evaporation can be automatically cleaned for continuous desalination. Salt management in solar seawater desalination is vital for maintaining the desalination performance with longterm stability (Figure 17d).<sup>454</sup> During seawater desalination, the leaving of vapor from the bulk water produces concentrated salts, including NaCl and CaCO3. The fouling of the slats on an evaporation system can deteriorate the lightabsorbing performance and clog the water-supply path. Various designs have been proposed to address the fouling issue. In one design, the source water is taken up from the edge of the evaporator and the concentrated brine is excreted out before saturation through a directional flow.<sup>454</sup> White fabric wicks in a floating multilayer solar evaporation structure have been used for delivering water and rejecting excess salts at the same time.<sup>479</sup> A 3D umbrella architecture has been developed to guide the accumulated salts through the predesigned pathways without blocking the evaporative surface.<sup>455</sup> A stable evaporation rate from a hypersaline brine with a salinity of 20 wt % is achieved over 4 day operation with minimal salt accumulation. In a proposed contactless configuration (Figure 16b), the solar absorber does not touch the water surface and transfers energy to the seawater through thermal radiation, effectively circumventing the fouling problem.<sup>441</sup> 

**5.1.2. Wastewater Purification.** Solar thermal water evaporation can also be employed for wastewater purification. A bilayer aerogel composed of hydrophobic CNTs and hydrophilic hydroxyapatite nanowires has been reported for photothermal water purification (Figure 18a).<sup>457</sup> The CNT layer exhibits a high solar light absorptivity. The hydroxyapatite nanowires function as a thermal insulator for inhibiting the heat loss to the bulk water and confining the thermal energy at the evaporative surface.<sup>457,458</sup> The crosslinked pores and channels in the bilayer aerogel promote water transportation and vapor escape. Clean water can be produced from simulated wastewater containing heavy metal ions or 

organic dyes after vapor generation and condensation. The concentrations of Pb<sup>2+</sup> , Cr<sup>3+</sup> , and Cu<sup>2+</sup> ions in the purified water are measured to be below the WHO drinking water standards. A superwicking black Al surface has been designed for efficient wastewater purification (Figure 18b).<sup>501</sup> Femtosecond laser has been used to produce Al sheets with open capillary channels, which can be easily cleaned and reused. The light-absorbing Al sheet is mounted onto polystyrene foam and floated on the water surface to construct a solar evaporation system. The system has been proven to be effective for purifying wastewater with 14 common types of contaminants, including various heavy metals, light metals, as well as industrial, domestic, and agricultural pollutants. After purification, the concentrations of all the tested contaminants are reduced by 4−5 orders of magnitude and meet the WHO standards for drinkable water. Moreover, the device can be mounted onto a rotatable platform to track sunlight for optimizing incident solar irradiance. The versatility of plasmonic structures has been demonstrated in the application of water purification. The pronounced local field enhancement of plasmonic structures in the solar evaporation system enables on-site pollution detection by Raman scattering.<sup>502</sup> Bifunctional Au@TiO2 nanoparticles have been reported for simultaneous vapor generation and photocatalytic degradation of pollutants.<sup>494</sup> Photothermal-evaporation-induced seawater desalination and wastewater purification are believed to play vital roles in addressing the issues of water scarcity. 

**5.1.3. Electricity Generation.** Solar energy is converted into thermal energy and stored in the vapor and heated water after the solar evaporation process. A substantial amount of energy from the input sunlight is wasted if fresh water is the only target of the solar evaporation system.<sup>53</sup> Making the most use of solar energy along the photothermal evaporation process can contribute in addressing the energy and water scarcities. Researchers have developed strategies to further harvest the 

**6914** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 19. Solar water heating for electricity generation. (a) Schematic of the interfacial photothermal water evaporation and electricity generation processes based on polydimethylsiloxane/carbon nanotubes/cellulose nanocrystals (PCC) sponge and thermoelectric modules (left panel). The middle panel shows the maximum output power of the thermoelectric modules under different solar irradiation powers with a digital calculator powered by the PCC sponge under 5 sun illumination shown in the inset. The right panel displays the water evaporation rates and open circuit voltages of the hybrid photothermal device at different flowing water temperatures under an optical density of 1 kW m<sup>−2</sup> . Reprinted with permission from ref 459. Copyright 2019 Wiley-VCH. (b) Schematic illustrating the condensation process during solar steam generation for the simultaneous generation of clean water and electricity (left panel). The middle panel shows the maximum output power of the thermoelectric device under different solar irradiation powers, and the right panel displays the optical image of an operating electric fan and light-emitting diodes powered by the solar steam system. Reprinted with permission from ref 461. Copyright 2018 under Elsevier user license. 

input solar energy by generating electricity during the processes of solar absorption, vapor generation, and water condensation. The generation of thermoelectric power at the interface of the photothermal absorbers and the bulk water has been reported (Figure 19a).<sup>459</sup> A shape-conforming 3D organic sponge is fabricated for solar evaporation and integrated with thermoelectric modules for electricity generation. The sponge absorbs solar light and transfers energy to the upper side of the thermoelectric modules through heat diffusion. With the lower side of the thermoelectric modules cooled by the underneath bulk water, the temperature difference between the two sides of the thermoelectric modules produces electricity by the Seebeck effect. The generated electricity is proportionally boosted with solar irradiation. It can power a digital calculator under 5 sun illumination. On the other hand, the thermoelectric modules also serve as thermal insulators to isolate the sponge from the bulk water, resulting in an improved water evaporation rate. The water evaporation is also improved by the increased temperature of the flowing bulk water. In addition, lowering the temperature of the bulk water also increases the temperature difference between the two sides of the thermoelectric modules, which gives rise to a higher thermoelectric potential. Electricity can also be extracted from the evaporation-induced salinity gradient in a solar desalination system equipped with a piece of ion-selective membrane.<sup>473</sup> For instance, the storage and recycling of the enthalpy of the solar steam have been demonstrated for the simultaneous generation of electricity and fresh water (Figure 19b).<sup>461</sup> Heat is transferred from the high-temperature steam to a polyurethane-foam-wrapped Al chamber. Electricity is then generated by Bi2Te3-based thermoelectric modules due to 

the temperature difference between the heated chamber and the room-temperature environment. The output electric power reaches 574 mW under 30 kW m<sup>−2</sup> solar irradiation, enabling continuous operation of an electric fan and 28 light-emitting diodes. Moreover, the chamber with thermal capacity can maintain electricity generation after the light source is turned off. It is beneficial for reducing the influence of intermittent illumination during practical applications. The waste energy from solar vapor can also be harvested by a polyvinylidene fluoride film for electricity generation based on the coupled pyroelectric and piezoelectric effects.<sup>440</sup> Electricity can also be generated during the condensation and collection of fresh water. For example, the flow of condensed water droplets on a polytetrafluoroethylene surface produces electricity by triboelectric nanogenerators in a condensate collection device.<sup>503</sup> With further improvement in the energy conversion efficiency and reduction in the device cost, these multifunctional and sustainable systems will move toward commercial applications in the foreseeable future. 

### **5.2. Structural Color Printing** 

Structural colors arise from the interaction of light with photonic structures at the wavelength or subwavelength scale.<sup>61,508,509</sup> Fade-resistant and environmentally friendly structural colors with unprecedented printing resolution have gained much attention in numerous applications, including anticounterfeiting labels, optical encryption, high-density optical storage and display. With the development of laser and lithography techniques, direct laser printing becomes a powerful and convenient way for generating structural colors based on the localized photothermal heating of metal and 

**6915** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 20. Photothermal color printing. (a) Schematic illustrating laser printing governed by the photothermal reshaping of plasmonic nanostructures (left). A laser-printed plasmonic color image is given on the right as an example. Reprinted with permission from ref 64. Copyright 2016 Springer Nature. (b) Schematic illustrating focused femtosecond-laser-printed nanovolcanoes and scattered colors under oblique illumination (left). The image encryption and decryption under dark-field objective lenses with different incidence angles are shown on the right. Reprinted with permission from ref 515. Copyright 2018 American Chemical Society. (c) Schematics of a Au nanodisk-embedded poly(dimethylsiloxane) (PDMS) matrix before and after laser printing. The Au nanodisks are thermally reshaped into nanospheres under single-pulse laser exposure with a sufficient energy. Reprinted with permission from ref 528. Copyright 2020 Wiley-VCH. (d) Schematics of laser-printing Ge nanostructures for generating structural colors (left). The SEM images of the structures printed by different laser power dosages and the corresponding optical images of the color palettes are shown on the right. Reprinted with permission from ref 65. Copyright 2017 Zhu et al., published under the CC BY 4.0 license http://creativecommons.org/licenses/by/4.0/. (e) Schematic of a rewritable device consisting of a Sb2S3 phase-change material switched between its crystalline and amorphous states (upper panel). The crystalline sample (purple) is amorphized using femtosecond laser pulses, while the amorphous sample (yellow) is crystallized using a thermal annealing process. The optical micrograph of Vincent van Gogh’s self-portrait can be written on the device by varying the exposure power of the femtosecond laser pulses. On the bottom panel are the optical micrographs of the device with Sb2S3 in the amorphous (1) and crystalline (2) states. The crystalline sample can be reamorphized to varying degrees by femtosecond laser pulses with different excitation powers (3) and can be switched back to the crystalline state after a thermal annealing process (4). Reprinted with permission from ref 532. Copyright 2020 Liu et al., published under the CC BY 4.0 license http://creativecommons.org/licenses/by/4.0/. 

dielectric materials.<sup>85</sup> The interference between the incident laser and surface EM waves has been used to produce periodic surface structures.<sup>510−514</sup> Laser illumination can also change the morphology or phase of prefabricated micro-/nanostructures, giving rise to target colors. Laser pulses have been used to generate transient local heat for the melting and reshaping of nanoimprinted Al nanodisks (Figure 20a).<sup>64</sup> Laser pulses with different energy densities produce Al nanostructures with various morphologies, which support different plasmonic resonances to create colorful appearances. Color images are printed with a speed of one nanosecond per pixel and a resolution of up to 127,000 dots per inch, exceeding the diffraction limit. In another work, plasmonic nanovolcanoes at different splashing stages are produced on a Ti thin film by laser pulses with varied energy fluences (Figure 20b).<sup>515</sup> The scattering colors of the nanovolcanoes are found to be dependent not only on the morphologies but also on the incidence angle of the illumination light. The angularly anisotropic color appearances of the plasmonic nanovolcanoes are therefore utilized to encrypt hidden color images for information security and anticounterfeiting. Interestingly, the photothermal reshaping of plasmonic nanostructures by laser 

pulses can also be realized below the melting point of a bulk metal, as explained by a surface-diffusion model.<sup>382,516,517</sup> Besides the laser power, adjusting the laser wavelength and polarization also provides degrees of freedom to control the structural morphologies and resultant color pixels.<sup>518−520</sup> Two orthogonal arms of anisotropic plasmonic nanostructures can be separately reshaped by lasers with their polarization along different directions, achieving multiplexed pixels.<sup>519</sup> Instead of writing on the 2D surfaces of different materials,<sup>521−525</sup> the structural color prints can alternatively be prepared inside 3D matrices.<sup>526−528</sup> The laser printing of plasmonic colors inside transparent Au-nanodisk-embedded polymeric matrices has been demonstrated (Figure 20c).<sup>528</sup> The position of the focused laser spot can access a 3D space in different depths inside the polymer with uniformly distributed circular Au nanodisks, creating multiple layers of color patterns inside a single piece of matrix. The employment of more degrees of freedom endows structural color prints with high security levels and large storage densities. 

Dielectric materials, as an alternative to metals for certain optical applications, can also be photothermally modified by direct laser writing.<sup>65,529−532</sup> For example, Ge nanostructures 

**6916** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 21. Opto-thermophoresis of nanomotors. (a) Schematic (upper) of a NIR-light-powered Janus mSiO2 nanomotor and calculated steadystate temperature distribution (lower) of a representative nanomotor under 3 W cm<sup>−2</sup> irradiation. Reprinted with permission from ref 539. Copyright 2016 American Chemical Society. (b) Snapshots (left) and schematics (right) showing the mechanism of the motion of a PbSnanoparticle-filled vial propelled by a NIR laser (indicated by a red arrow). The proposed mechanism of the photomechanical effect contains four steps: (1) thermophoretic motion of the PbS nanoparticles toward the laser source; (2) brutal force release induced by Jeans’ instability; (3) explosive growth of a bubble, which disperses the accumulated PbS nanoparticles; and (4) collapse of the bubble and return to the initial state. The temperature gradient is represented by the red color. Reprinted with permission from ref 561. Copyright 2020 Kavokine et al., published under the CC BY 4.0 license http://creativecommons.org/licenses/by/4.0/. (c) Schematic showing the trapping of a single polystyrene nanosphere in an open gold structure on a glass substrate. The inset shows the trajectory points of a 200 nm polystyrene sphere trapped within a hexagonal lattice of triangular Au pads by a moving laser with a rotation frequency of 18.9 Hz. Reprinted with permission from ref 573. Copyright 2013 American Chemical Society. (d) Schematic and two representative examples of the opto-thermophoretic assembly of colloidal matter of diverse sizes (from the subwavelength to micrometer scale) and materials (polymeric, dielectric, metal) with versatile configurations. A bright-field optical image of a 2D hybrid superlattice of 2 mm polystyrene spheres, 0.96 mm polystyrene spheres, 2 mm silica beads, and 1 mm silica beads and a dark-field optical image of a heterogeneous dimer of a 500 nm polystyrene sphere bead and a 200 nm Au nanosphere are shown on the right panel. Reprinted with permission from ref 575. Copyright 2017 Lin et al., published under the CC BY 4.0 license http://creativecommons.org/licenses/by/4.0/. 

can harvest energy from pulsed laser irradiation through abovebandgap absorption and undergo morphology changes (Figure 20d).<sup>65</sup> In contrast to plasmonic heating with a rapid thermal change at the metal surface, the evenly distributed electric field inside the dielectric resonators potentially heats the resonators more homogeneously, making the associated photothermally driven morphology changes more controllable. With the increase of the laser power, Ge nanorods are gradually changed to shortened rods, spheres, and finally holes, causing the evident color variations. Furthermore, using phase-change materials, one can realize rewritable structural color prints, as have been reported in Sb2S3 films (Figure 20e).<sup>532</sup> Sb2S3 is a phase-change material that possesses a refractive index difference as large as ∼1 between its crystalline and amorphous states.<sup>532,533</sup> The crystallization of Sb2S3 films is achieved by thermal annealing, while the crystalline-to-amorphous transition is realized by employing high-intensity laser pulses with short duration to randomize the atomic arrangement. Partial reamorphization states with intermediate colors have also been demonstrated by changing the excitation power of the laser pulses. With further improvement in the write−erase cyclability of the color changes, such phase-change materials can become promising for optical encryption and nextgeneration high-resolution color display devices. 

### **5.3. Photothermal Manipulation** 

**5.3.1. Opto-thermophoresis of Nanomotors.** Motors, which can convert other forms of energy into mechanical work to produce motion, play a crucial role in the development of human society.<sup>57,534</sup> The miniaturization of motors toward the nanoscale has attracted intensive research interests.<sup>58</sup> The opto-thermophoretic effect provides a low-power solution for manipulating nanomotors by creating a temperature gradient field through optical heating.<sup>535,536</sup> The hydrostatic pressure induced by a temperature gradient field occurs in the vicinity of the nanomotor surface. It moves the nanomotor to decrease the interfacial free energy.<sup>55</sup> In general, nanomotors with positive (negative) Soret coefficients are thermophobic (thermophilic) and move from the hot (cold) region to the cold (hot) region. The magnitude and sign of the Soret coefficient are affected by many parameters, including the shape and size of the nanomotor, the nanomotor−solvent interfacial properties, the surrounding temperature, and the hydrodynamic boundary effects.<sup>55,536−538</sup> In a work with Janus mSiO2 nanomotors fabricated by sputtering a 10 nm Au layer on one side of mSiO2 nanoparticles (Figure 21a),<sup>539</sup> a NIR laser is employed to locally heat the Au half-shell, resulting in the formation of a thermal gradient across the nanomotor. The opto-thermophoretic effect actively drives the nanomotor to move opposite to the direction of the Au half-shell side at a 

**6917** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 22. Photothermal actuators and robots. (a) Sequential actuation of shape-memory polymer films through the wavelength-selective photothermal heating of Au nanospheres and nanorods. The TEM images and extinction spectra of the Au nanospheres and nanorods are shown on the left panel. A wavelength-controlled stage is demonstrated on the right panel with optically controlled heights and tilt angles using two legs made of folded shape-memory polymer films embedded with the Au nanospheres and nanorods, respectively. Two light-emitting diodes are used to selectively drive the shape recovery of the two legs. Reprinted with permission from ref 578. Copyright 2018 American Chemical Society. (b) Schematics and photographs of PDA-coated LCN actuators, which can advance two steps through arching up/flattening down in a single on and off irradiation cycle. Reprinted with permission from ref 585. Copyright 2021 Xiao et al., published under the CC BY 4.0 license http:// creativecommons.org/licenses/by/4.0/. (c) Earthworm-like directed peristaltic crawling enabled by an anisotropic hydrogel actuator. The upper and middle panels show the schematics and photographs of the light-responsive actuation of a hydrogel consisting of titanate nanosheets aligned orthogonally to the cylindrical gel axis and light-absorbing Au nanoparticles. The hydrogel undergoes peristaltic crawling and moves oppositely toward the laser scanning direction when the irradiation spot is moved along the cylindrical gel axis, as shown in the photographs (bottom panel). Reprinted with permission from ref 598. Copyright 2018 Wiley-VCH. 

speed up to 950 body lengths per second under a laser power of 703 kW m<sup>−2</sup> . Different types of opto-thermophoretic nanomotors have been reported, including plasmonic nanostructures,<sup>540−543</sup> carbonaceous nanoparticles,<sup>544−546</sup> biomolecules,<sup>547,548</sup> and hybrid nanoparticles.<sup>549−560</sup> Opto-thermophoretic manipulation can be achieved at not only the nanoscale but also the macroscopic scale. The displacement of a vial of nanofluids over centimeter-scale distances has been realized by a laser beam irradiation (Figure 21b).<sup>561</sup> The laser-irradiated PbS nanoparticles in the vial absorb the incident light and serve as local heating sources to trap other nanoparticles in the heated region through negative thermophoresis. Once the particle density in the illuminated region increases up to a point beyond the Jeans’ instability, the collective motion of the PbS nanoparticles occurs and pushes the entire vial away from the laser. Remarkably, a 1.5 W laser illumination is sufficient to propel a vial weighing 3.5 g at an average speed of 1 mm s<sup>−1</sup> . The opto-thermophoretic effect has also been used for trapping<sup>562−570</sup> and assembling<sup>571,572</sup> nanoparticles. An optothermophoretic trapping platform has been built for thermophobic nanoparticles (Figure 21c).<sup>573,574</sup> Since polystyrene nanospheres are repelled away from the laser-heated Au pads, the thermophobic nanoparticles can be confined inside a hexagonal lattice of the Au pads by rotating the laser at suitable speeds. A strategy of opto-thermophoretic assembly 

has been developed to manipulate and construct colloidal matter based on ionic depletants under a light-controlled temperature field (Figure 21d).<sup>575</sup> Diverse colloidal particles, as the building blocks, can be trapped and moved one by one to assemble into various superstructures of arbitrary 1D, 2D, and 3D configurations. Moreover, the superstructures can be disassembled and then reassembled into different configurations.<sup>576,577</sup> 

**5.3.2. Photothermal Actuators and Robots.** Plasmonic nanoparticles, carbon nanomaterials, and organic photothermal agents have been incorporated into the matrices of shapememory polymers,<sup>578−584</sup> liquid crystals,<sup>585−597</sup> hydrogels,<sup>136,598−604</sup> elastomers,<sup>605,606</sup> and biopolymers<sup>607,608</sup> to form photothermal actuators and robots. The photothermal conversion by light-absorbing materials leads to basic mechanical deformations, such as bending, twisting, rotating, and jumping, of thermally responsive components to function as grippers, mills, swimmers, and syringes.<sup>66,68,609−612</sup> Lightabsorbing materials also serve as thermally responsive components in some actuators.<sup>613−615</sup> Several metrics, including the generated stress and strain, Young’s modulus, durability, response time, and energy consumption, have been taken into account during the design of photothermal actuators and robots.<sup>616−618</sup> Two types of Au nanocrystals, nanospheres and nanorods have been selectively dispersed into thermo- 

**6918** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 23. Three categories of photothermal catalysis. (a) Thermally assisted photocatalysis. Schematic illustrating the photothermal effect and oxygen diffusion in a diphase (left) and a triphase (right) system. PC represents photocatalysis and PT represents the photothermal effect. Reprinted with permission from ref 276. Copyright 2021 Wiley-VCH. (b,c) Photoassisted thermocatalysis. The CH4 conversion with PdO/ Mn3O4/CeO2 nanocomposite supported on 1D halloysite nanotubes with and without light irradiation (on and off) is shown in (b). Reprinted with permission from ref 635. Copyright 2021 Wiley-VCH. The CO conversion with a Co-based catalyst with and without UV−visible irradiation (photothermal heating/direct thermal heating) is shown in (c). Reprinted with permission from ref 636. Copyright 2018 Wiley-VCH. (d,e) Photothermal cocatalysis. The schematic (left) illustrating the effect of light-induced thermal gradients on ammonia production and the NH3 production rates (right) under dark and different illumination conditions are shown in (d). Reprinted with permission from ref 637. Copyright 2019 American Chemical Society. The schematic (left) showing the modified reaction chamber for the temperature measurements of thermal and nonthermal reactions and the total, thermal, and nonthermal reaction rates (right) as functions of the light intensity are shown in (e). Reprinted with permission from ref 639. Copyright 2018 American Chemical Society. 

plastic polyurethane shape-memory polymer films with a transition temperature of 55 °C (Figure 22a).<sup>578</sup> The sizes of the Au nanospheres and nanorods are carefully adjusted so that their LSPR wavelengths are matched with those of two lightemitting diodes at 530 and 860 nm, respectively. When the Au nanocrystal-embedded polyurethane films are exposed to the 530 (860) nm light, only the polyurethane film embedded with the wavelength-matched Au nanocrystals (nanospheres or nanorods) undergoes a shape deformation. The wavelengthselective photothermal heating therefore enables the sequential actuation of a stage with the folded shape-memory polymer films. Desynchronized liquid crystalline network (LCN) actuators have been designed with a deformation reversal capability (Figure 22b).<sup>585</sup> The two sides of the LCN actuators are made to start deforming at different temperatures and exerting different reversible strains by asymmetrical crosslinking and/or asymmetrical stretching. PDA layers are coated on the cross-linked LCNs to serve as the photothermal agent. After being exposed to a light source with a power density of 30.5 mW mm<sup>−2</sup> , the PDA-coated LCN film arches up and then flattens down, taking a step forward. After the light is switched off, the film bends again and then flattens down to the initial state as it further cools, moving another step forward. The LCN film therefore implements two steps forward in a single light-on/off cycle. In another example, an anisotropic hydrogel has been created. It exhibits the capability of an earthworm-like directed peristaltic crawling inside a glass capillary (Figure 22c).<sup>598</sup> The hydrogel contains Au nanoparticles for photothermal conversion, a thermoresponsive polymer network for switching the electrical permittivity of the hydrogel interior, and magnetically oriented titanate nanosheets to synchronously change their anisotropic electrostatic repulsion. The employed poly( _N_ -isopropyl acrylamide) hydrogel can reversibly dehydrate and rehydrate upon heating and cooling, causing reversible expansion and contraction of the hydrogel 

along the direction orthogonal to the plane of titanate nanosheets. Once the hydrogel is illuminated with a visible laser, the irradiated region becomes thinner and longer, resulting in the reduction of friction with the capillary glass. When the irradiation spot is scanned along the cylindrical axis, the hydrogel undergoes peristaltic crawling and moves oppositely toward the laser scanning direction owing to quick and sequential elongation/contraction events. Besides the wavelength and intensity of the incident light,<sup>578,619−622</sup> the photothermal actuators and robots can be further controlled by the polarization of the light sources.<sup>623,624</sup> Noncontact manipulation of photothermal actuators and robots with improved response speeds, energy conversion efficiencies, and mechanical robustness will pave a promising way toward smart autonomous systems. 

### **5.4. Photothermal Catalysis** 

Heat and light are two crucial physical quantities that drive chemical reactions. With the rapid development of photothermal nanomaterials, photothermal catalysis has been widely explored to enhance the catalytic activity and achieve high selectivity for specific products, even under moderate reaction conditions.<sup>9,45,625</sup> As light and thermal energy can collectively or separately participate in the catalytic process, photothermal catalysis can be divided into three major categories.<sup>8,626</sup> The first category is thermally assisted photocatalysis, where photons mainly drive the catalytic reaction with thermal energy acting as an assisting role. Thermal energy alone can hardly drive this type of catalytic reactions. The photothermal effect is mainly reflected in the rising temperature that accelerates the migration of photogenerated charge carriers and the diffusion of reactant molecules.<sup>627−629</sup> The assisting thermal energy can apparently reduce the activation energy and thus facilitate the catalytic process. To better utilize the photothermal effect in photocatalytic reactions, the gas− 

**6919** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

liquid−solid triphase system has been proposed in several recent works for improving the catalytic performance.<sup>630−633</sup> In conventional liquid−solid diphase systems, the thermal energy is rapidly dissipated to the surrounding medium and less can contribute to the interfacial reaction (Figure 23a).<sup>276</sup> On the contrary, the generated thermal energy that concentrates at the local sites of a carbon layer can be readily transferred to the adjacent catalysts in the triphase system. With the efficient heat supply, the triphase photocatalytic reaction rate can therefore be improved by 13 times in comparison to that in the diphase system. However, it is worth mentioning that more thermal energy does not always bring better catalytic performances. The balance between thermodynamics and kinetics is normally manipulated to achieve the best catalytic performance.<sup>626</sup> Moreover, high temperatures also challenge the stability of catalysts, which significantly affects the catalytic performance. 

The second type of photothermal catalysis is photoassisted thermal catalytic activity, where the thermochemical reaction is dominant while photogenerated charge carriers serve as promoters. The introduction of light can lead to the increase in the local temperature because of the direct vibration absorption and indirect nonradiative relaxation.<sup>94,634</sup> These two impacts are thus beneficial for promoting the photoassisted thermal catalytic process. For example, the activity of a catalytic reaction can be boosted by the enhanced capability of activating and adsorbing oxygen with the help of photogenerated electrons (Figure 23b).<sup>635</sup> In the extreme case, light can only be used to generate heat. The catalytic performance under light irradiation shows a very similar tendency to the case of traditional thermal catalysis (Figure 23c).<sup>636</sup> This type of photocatalysts is desired to have narrow bandgaps and high photothermal conversion efficiencies. 

The third category is photothermal cocatalysis, where the thermochemical and photochemical processes make a synergistic contribution to the catalytic reaction. The cocatalytic performance is better than the overall contribution of individual photo- and thermocatalytic reactions. The thermal gradients modulated by photothermal heating have been demonstrated to efficiently produce ammonia with high conversion yields and reaction rates (Figure 23d).<sup>637</sup> The utilization of plasmonic Ru nanoparticles can facilitate the photothermal effect, but its limit hot carrier generation owing to the broad and weak plasmon resonance.<sup>638</sup> As shown in Figure 23d, simultaneously introducing light and external heating into the catalytic system can largely enhance the production of NH3. The NH3 production rate is even larger than the total rate of those under sole light illumination and sole external heating, indicating a synergistic contribution of the thermochemical and photochemical processes in the reaction. The nonthermal plasmonic effect such as hot charge carrier transfer is ruled out from the contribution to the enhancement of the NH3 production rate by comparing the catalytic performance under direct and indirect illumination. To further distinguish and quantify the thermal and nonthermal contributions in such a photothermal cocatalytic system, the research group has developed a methodology to _in situ_ measure the temperatures in the thermal and nonthermal reactions (Figure 23e).<sup>639</sup> The effective thermal and nonthermal reaction rates can be correctly extracted by a thermal gradient model based on the measured temperatures. 

In the catalytic systems involving plasmonic nanomaterials, photothermal heating and nonthermalized (hot) charge 

carriers can be effectively generated due to the well-known LSPR effect.<sup>266</sup> Both of them can contribute to the enhancement of the catalytic activities, even though these two phenomena happen at different time scales and stem from different physical processes.<sup>86</sup> Therefore, much effort has been made to distinguish the photothermal effect from the hot charge carrier effect in photothermal catalysis.<sup>640−644</sup> But it has still remained challenging to unambiguously identify the contributions of these two factors due to the involved wide time scales and diverse mechanisms. 

### **5.5. Selected Applications in Life Sciences** 

**5.5.1. Photothermal Therapy (PTT).** With the fascinating development of photothermal materials, PTT has emerged as a powerful potential therapeutic technology because of its minimal invasiveness, low toxicity, and spatiotemporal selectivity.<sup>645,646</sup> PTT makes use of photothermal nanomaterials to produce topical hyperthermia to trigger the death of abnormal cells.<sup>10</sup> When a photothermal agent is activated by external laser irradiation at a specific wavelength, the generated heat can accumulate in lesions and precisely target at tumors. Relatively low input power is required for tumor ablation because of the efficient light absorption of photothermal nanomaterials. Such selective and effective thermal ablation can minimize the damage to the surrounding healthy tissues. To achieve complete eradication of tumors, NIR light with long wavelengths, especially in the NIR-II window, is preferable for the deep tissue penetration during PTT.<sup>11,647,648</sup> Moreover, photothermal nanomaterials with desired absorption wavelengths can be readily designed to avoid the intrinsic light absorption of biological chromophores, leading to the reduction of phototoxicity in normal tissues. The modulation of the size, shape, and surface functionalization of photothermal nanomaterials, as well as the biological microenvironment, can be performed to improve the delivery efficiency and therapeutic efficacy of photothermal agents.<sup>71,649−652</sup> Robust photothermal nanomaterials have been extensively developed to possess specific physicochemical and pharmaceutical properties for the reduction of adverse effects and the enhancement of therapeutic efficacy.<sup>20,24,46,653,654</sup> In addition, PTT has also been carried out in clinical pilot trials as a safe and effective therapeutic modality. The clinical progresses of PTT with various photothermal nanomaterials have been widely made for the treatment of head and neck cancer, coronary atherosclerosis, diabetic macular abnormalities, age-related macular degeneration, prostate cancer, and genitourinary syndrome of menopause (national clinical trials: NCT 00848042, NCT 01270139, NCT 01975103, NCT 02569892, NCT 02680535, NCT 03288883).<sup>10,11</sup> A single-treatment clinical device study of AuroLase Therapy for the direct focal ablation of prostate tissue was demonstrated by the company of Nanospectra Biosciences.<sup>655</sup> Since silica-cored Au nanoshells served as the first photothermal nanomaterials for clinical use, more and more inorganic agents with strong absorption in the NIR region, high chemical stability, adjustable water solubility, and minimal cytotoxicity have entered clinical trials.<sup>648,653</sup> Clinical trials have also been underway for small organic molecules due to their good biodegradability, good repeatability, and simple preparation.<sup>690,713</sup> Nevertheless, the major challenges for the clinical implementation of photothermal nanomaterials are the complex metabolism and excretion behaviors.<sup>719</sup> The repre- 

**6920** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

Table 3. Representative Works on PTT in Recent Years 

|||||photothermal<br>conversion|
|---|---|---|---|---|
|category|reference|photothermal materials and devices|illumination conditions|efficiency|
|metals|656|Au nanostars|808 nm laser irradiation (0.5 W cm<sup>−2</sup>, 5 min)|85.5%|
||657|Au nanoparticles|808 nm laser irradiation (1 W cm<sup>−2</sup>, 5 min)|53.6%|
||658|Au-Pd nanoparticles|808 nm laser irradiation (0.5 W cm<sup>−2</sup>, 5 min)|41.9%|
||659|(Ag nanocube core)@(Au nanorod shell)<br>nanostructures|808 nm laser irradiation (1 W cm<sup>−2</sup>, 10 min)|87.28%|
||660|Au nanostars<br>|785 nm laser irradiation (0.02 W cm<sup>−2</sup>, 20 min)<br>|63.6%|
||661|Au nanoparticles|808 nm laser irradiation (1 W cm<sup>−2</sup>, 10 min)<br>|48.4%|
||662|Pd nanosheets|808 nm laser irradiation (1.5 W cm<sup>−2</sup>, 2 min)|39.2%|
||663|Cu nanoparticles|808 nm laser irradiation (0.3 W cm<sup>−2</sup>, 10 min)|26.5%|
||664|Au nanostars|1064 nm laser irradiation (0.5 W cm<sup>−2</sup>, 5 min)<br>|67.1%|
||665|Mn nanoparticles|1064 nm laser irradiation (1.2 W cm<sup>−2</sup>, 10 min)|22.1%|
||666|Fe nanoparticles|808 nm laser irradiation (0.95 W cm<sup>−2</sup>, 20 min)|67%|
||667|Ag nanoparticles|808 nm laser irradiation (0.25 W cm<sup>−2</sup>, 5 min)|71.68%|
||668|Mn nanoparticles|940 nm laser irradiation (1 W cm<sup>−2</sup>, 7 min)|70%|
||669|Cu single atoms|1064 nm laser irradiation (0.39 W cm<sup>−2</sup>, 5 min)|41.6%|
||670|Au nanorods|980 nm laser irradiation (0.1 W cm<sup>−2</sup>, 5 min)|40.62%|
|semiconductors|671|MnO_x_/PDA nanobombs|808 nm laser irradiation (2 W cm<sup>−2</sup>, 5 min)|34.8%|
||672<br>|flower-like MnO2 nanoparticles<br>|808 nm laser irradiation (1 W cm<sup>−2</sup>, 15 min)<br>|21.3%|
||673|_γ_-Fe2O3 nanoparticles|1064 nm laser irradiation (1.1 W cm<sup>−2</sup>, 10 min)|59.85%|
||674|Fe3O4@Cu1.77Se nanoparticles|1064 nm laser irradiation (0.75 W cm<sup>−2</sup>, 10 min)|67.6%|
||675|Fe3O4 nanoparticles|808 nm laser irradiation (1 W cm<sup>−2</sup>, 10 min) or 650 nm<br>laser irradiation (0.5 W cm<sup>−2</sup>, 10 min)|34.6%/17.9%|
||676|Sb2O3 nanoparticles|1210 nm laser irradiation (1 W cm<sup>−2</sup>, 8 min)|44%|
||677|FeS nanoparticles|1064 nm laser irradiation (1 W cm<sup>−2</sup>, 6 min)|56.51%|
||678|Fe3O4 nanoparticles on graphene oxide<br>nanosheets|808 nm laser irradiation (1.5 W cm<sup>−2</sup>, 10 min)|55.89%|
||679|CuS nanoparticles|1060 nm laser irradiation (1 W cm<sup>−2</sup>, 10 min)|57.9%|
||680|CuS nanoparticles|808 nm laser irradiation (0.5 W cm<sup>−2</sup>, 5 min)<br>|45.6%|
||681<br>|IrWO_x_ nanoparticles<br>|808 nm laser irradiation (1 W cm<sup>−2</sup>, 5 min)<br>|27%|
||682|CuSe nanoparticles|808 nm laser irradiation (3 W cm<sup>−2</sup>, 10 min)|31.9%|
|organic polymers|683|spirolactone nanoparticles|808 nm laser irradiation (1.5 W cm<sup>−2</sup>, 10 min)|36.9%|
||684|two isoindigo-based semiconducting conjugated<br>polymers|808 nm laser irradiation (0.8 W cm<sup>−2</sup>, 6 min)|70.6%|
||685|PTTe nanoparticles|1064 nm laser irradiation (1 W cm<sup>−2</sup>, 10 min)|47.5%|
||686|zwitterion−liposome hybrid nanoparticles|1064 nm laser irradiation (1 W cm<sup>−2</sup>, 6 min)|30.8%|
||687|O-T molecular oligomerization nanostructures|1064 nm laser irradiation (1.0 W cm<sup>−2</sup>, 5 min)|73%|
||688|DTTVBI nanoparticles|808 nm laser irradiation (0.8 W cm<sup>−2</sup>, 6 min)|45.8%|
||689|N<sup>+</sup>TT-mCB nanoparticles|808 nm laser irradiation (0.45 W cm<sup>−2</sup>, 5 min)|78%|
||690|BNDI-Me _π_-conjugated molecules|808 nm laser irradiation (0.3 W cm<sup>−2</sup>, 10 min)|50%|
||691|nanoparticles of A-D-A type planar<br>phototheranostic agent|808 nm laser irradiation (0.3 W cm<sup>−2</sup>, 10 min)|80%|
||692|J-aggregates of aza-coating heptamethine<br>cyanines|808 nm laser irradiation (1 W cm<sup>−2</sup>, 5 min)|57.59%|
||693|nanoparticles of D-A-D type conjugated small<br>molecules|1064 nm laser irradiation (1 W cm<sup>−2</sup>, 8 min)|35.8%|
||694|D-A conjugated Ru(II)-arene complex<br>nanoparticles|808 nm laser irradiation (0.5 W cm<sup>−2</sup>, 10 min)|24.2%|
||695|V-shaped DUT850 molecules|808 nm laser irradiation (0.33 W cm<sup>−2</sup>, 5 min)|60%|
||696|nanoparticles derived from borane-modified<br>dianthracenylpyrazines|808 nm laser irradiation (1 W cm<sup>−2</sup>, 5 min)|41.8%|
||697|nanoparticles of organic metal adjuvants|1064 nm laser irradiation (1 W cm<sup>−2</sup>, 5 min)|47.0%|
||698|supramolecular photothermal nanodrugs|680 nm laser irradiation (0.5 W cm<sup>−2</sup>, 10 min)|48.0%|
||699|glucose oxidase engineered PAn nanoplatforms|808 nm laser irradiation (1 W cm<sup>−2</sup>, 10 min)|55%|
||700|nanoparticulate heavy-atom-free boron|808 nm laser irradiation (2 W cm<sup>−2</sup>, 5 min)|60.02%|
|||dipyrromethenedyederivative|||
||701|<br>nanoaggregates of polymeric photothermal<br>agents coated with DC membranes|808 nm laser irradiation (1 W cm<sup>−2</sup>, 5 min)|30.5%|
||702|aza-boron dipyrromethene dimers|915 nm laser irradiation (0.54 W cm<sup>−2</sup>, 10 min)|60.3%|
||703|polymer multicellular nanoengagers|1064 nm laser irradiation (1 W cm<sup>−2</sup>, 6 min)|88.8%|
|2D<br>nanomaterials|704|sheet-like 2D manganese(IV) complex|730 nm laser irradiation (0.75 W cm<sup>−2</sup>, 5 min)|71%|
||705|Sn nanosheets|808 nm laser irradiation (1 W cm<sup>−2</sup>, 10 min)|37.9%|



**6921** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

### Table 3. continued 

|category|reference|photothermal materials and devices|illumination conditions|photothermal<br>conversion<br>efficiency|
|---|---|---|---|---|
||706|Fe-based 2D nanosheets|1064 nm laser irradiation (1 W cm<sup>−2</sup>, 10 min)|43.3%|
|carbon-based<br>materials|313|SWCNTs and MWCNTs|808 nm laser irradiation (1 W cm<sup>−2</sup>, 5 min)|59.3%/57.8%|



sentative works on PTT with diverse photothermal nanomaterials in recent years<sup>656−706</sup> are summarized in Table 3. 

Apart from the thermal ablation with PTT, an appropriate temperature increase can be beneficial for promoting tissue regeneration, stimulating drug release, improving the drug delivery efficiency, alleviating hypoxia, and other therapeutic activities.<sup>71,707−709</sup> These advantages further promote PTT to combine with other therapeutic modalities to achieve improved treatment outcomes by an additive or synergistic effect. The combination partners can mutually not only improve the penetration depth of PTT but also augment the antitumor efficacy at lower doses of photothermal agents or lower irradiation laser powers. A number of therapies, such as photodynamic therapy, chemotherapy, radiotherapy, immunotherapy, sonodynamic therapy, chemodynamic therapy, and gene therapy (GT), have been widely incorporated with PTT.<sup>11,710−714</sup> For example, as the essential therapeutic approach for malignant tumors, conventional chemotherapy often suffers from low drug release, limited dosage, and heavy systemic toxicity.<sup>715</sup> The combination of photothermal nanomaterials and chemotherapeutic drugs has been utilized to address the mentioned limitations.<sup>716,717</sup> Uniform Au@poly(acrylic acid) (PAA) nanostructures have been facilely synthesized for actively targeted chemo-PTT (Figure 24a).<sup>718</sup> Through the significant accumulation of these Janus nanoparticles at the tumor site, the tumor temperature can exceed 60 °C, producing a high tumor suppression of 98%. Apart from active targeting, the release of doxorubicin hydrochloride (DOX) can be greatly enhanced up to 90% due to the remote heat generation. Moreover, the thermal energy can make the chemotherapeutic agents distribute more evenly, leading to better or even complete tumor elimination. Gene-PTT is another important combinational therapeutic modality, where the photothermal heating controls the intracellular gene expression.<sup>668,719</sup> The photothermal activation of gene delivery can be realized by heating the cell membrane for enhanced endocytosis or cell fusion. CNT-based systems with excellent photothermal and temperature-sensitive properties have been demonstrated for synergistic antitumor activities (Figure 24b).<sup>313</sup> The temperature-sensitive molecules of peptide lipid and sucrose laurate have been used to functionalize singlewalled carbon nanotubes (SWCNTs) and multiwalled carbon nanotubes (MWCNTs) into photoswitchable gene carriers for loading anti-survivin small-interfering ribonucleic acid (siRNA). The increase in temperature can induce the disassembly of these gene carriers and thus facilitate the trapped siRNA to escape from the endosomes. The siRNA release can effectively suppress the tumor growth by the expression of surviving silencing. More than 76% tumor cells are killed during the gene-PTT, while PTT or GT alone only achieves half of the effect as the combinational therapy. In addition to chemo- and gene-PTTs, immuno-PTT is an emerging therapeutic strategy that introduces a systemic anticancer immune response by the photothermal ablation of a targeted tumor.<sup>720−723</sup> The immunogenetic cell death (ICD) 



Figure 24. Synergistic cancer treatment based on PTT. (a) ChemoPTT. Au@PAA Janus nanoparticles are used as the templates to grow a mSiO2 shell and Au branches, which are separately modified with methoxy-poly(ethylene glycol)-thiol (mPEG-SH) and lactobionic acid (LA). Left: schematic illustrating the octopus-type PEG-AuPAA/mSiO2-LA Janus nanoparticle. Right: release profiles of the DOX-loaded Janus nanoparticles under different treatments. Reprinted with permission from ref 718. Copyright 2016 Wiley-VCH. (b) Gene-PTT. Peptide lipid and sucrose laurate are used to coat CNTs to form bifunctional delivery systems (denoted as CNT-PS). Left: schematic showing the temperature-sensitive CNT-PS/siRNA nanoparticle for synergistic PTT and GT. Right: qualitative analysis by fluorescence microscopy of apoptotic cells under the combined treatment. Reprinted with permission from ref 313. Copyright 2021 American Chemical Society. (c) Immuno-PTT. Left: schematic illustrating SPNE-mediated multicellular engagement, immune activation, and NIR-II photothermal effects. Middle and right: confocal laser scanning microscopy (CLSM) images of 4T1 cells, T cells, and DCs cocultured with uncoated semiconducting polymer nanoparticles SPNU (middle) or SPNE (right). 4T1 cells and DCs are labeled with DiI (red) and DiO (green) molecular probes, respectively. DCs are stained with phycoerythrin anti-CD80 antibody and fluorescein isothiocyanate anti-CD86 antibody (yellow). Reprinted with permission from ref 703. Copyright 2021 Wiley-VCH. 

caused by PTT can be beneficial to the eradication of the disseminated disease.<sup>724,725</sup> A semiconducting polymer nanoengager (SPNE) has been employed for NIR-II immuno-PTT (Figure 24c).<sup>703</sup> As the coating of the fused membranes of 4T1 tumor cells, the design of SPNE enables multicellular engagements among different cells. Due to the vaccination effects of the cell membranes, SPNE can exert an intrinsic immune response and thus facilitate the activation of T cells and dendritic cells (DCs). Upon NIR-II irradiation, SPNE is driven to directly destroy tumors and induce the ICD of the 

**6922** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 25. Drug delivery. (a) Schematic showing the release of the encapsulated chemotherapeutic drug caused by NIR light irradiation on BP@ hydrogel, resulting in the breaking of the DNA chains and the apoptosis induction. Reprinted with permission from ref 740. Copyright 2018 National Academy of Sciences. (b) Schematic illustrating the intracellular delivery of miRNA by the photothermal heat generated on plasmonic pyramid arrays. Reprinted with permission from ref 756. Copyright 2022 Wiley-VCH. (c) Schematic showing intracellular delivery through membrane permeabilization with photothermal nanofibers. Reprinted with permission from ref 757. Copyright 2021 Springer Nature. (d) Schematic illustrating large-cargo delivery driven by photothermal-heat-triggered cavitation bubbles. Reprinted with permission from ref 758. Copyright 2015 Springer Nature. 

cancer cells, which can facilitate T cell priming and DC maturation. The populations of the primed T cells and mature DCs are increased by 1.45- and 1.21-fold in primary tumors. The tumor growth is efficiently curbed with the inhibition rate of 97% and eliminated with no recurrence for 30 days. As a result, PTT and its combinational therapies with demonstrated efficacy have been well developed as promising treatment options for various life-threatening diseases.<sup>667,679,726−728</sup> 

**5.5.2. Drug Delivery.** Drug delivery is an essential biological process in living tissues because the delivery efficiency and accumulation of therapeutic medicines directly determine the success and failure of a treatment.<sup>729</sup> Chemotherapy, suffering from insufficient delivery and poor pharmacokinetics of drugs, is one typical representative that often fails in tumor treatments.<sup>730</sup> The remote heat generation provided by photothermal nanostructures can be utilized to trigger drug release, promote the cellular uptake of drugs, and overcome drug resistance.<sup>731−734</sup> A variety of photothermal nanomaterials, especially hollow nanostructures and 2D nanosheets with high drug loading efficacy, have been designed as nanocarriers for controllable drug release.<sup>735−739</sup> A BPbased hydrogel drug delivery system with high therapeutic efficacy has been reported (Figure 25a).<sup>740</sup> The phase transition from the solid to gel state of BP@hydrogel can be triggered to control the drug release under NIR light irradiation. Owing to the good biocompatibility and biodegradability of BP, the BP@hydrogel nanocarriers are completely degradable and nontoxic. Inorganic nanocarriers generally possess high photothermal conversion efficiencies and high photothermal stability, which are beneficial for drug delivery.<sup>741</sup> However, many biological barriers are required to be overcome before the nanocarriers enter targeted cells.<sup>742</sup> The existence of biofilms, which hinder the penetration of 

nanocarriers and reduce drug susceptibility, is one of the significant barriers for clinical trials.<sup>667</sup> Various strategies have been explored to enhance the penetration of drug carriers by introducing targeting membranes, changing the protecting ligands/coatings, and optimizing the size and shape of the carriers.<sup>743−747</sup> Both biodegradability and biocompatibility can be achieved through integration with organic polymers.<sup>748−750</sup> For monomeric photothermal molecules, supramolecular design offers an excellent opportunity for efficient drug delivery by overcoming their disadvantages of limited accumulation, poor aqueous solubility, and low photothermal conversion efficiencies.<sup>751,752</sup> Moreover, the strategy for triggering drug release is also an essential part for the design of drug carriers. For the use of photothermal heat as an external stimulus, the drug release can be achieved through the deformation of thermosensitive materials or destabilization of the interaction between carriers and drugs.<sup>753−755</sup> Apart from the construction of drug carriers, drug delivery can also be realized by a temporal cell-membrane-disruption method (Figure 25b).<sup>756</sup> The instantaneous high temperature generated by plasmonic pyramid arrays is used to disrupt the cell membranes to promote the intracellular delivery. The membrane permeation is thus increased with the production of transient pores on the cell membranes, which permits the direct diffusion of miRNA molecules. To minimize toxicity to healthy cells, intercellular delivery without direct cellular contact with photothermal nanoparticles has also been demonstrated (Figure 25c).<sup>757</sup> Although embedded in biocompatible electrospun nanofibers, iron oxide nanoparticles can effectively absorb visible light and transfer efficiently generated heat to distinct places of the cell membrane with improved membrane permeability. When the temperature rapidly increases at the interface between the photothermal 

**6923** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** <mark>Review</mark> 

nanostructure and the cell membrane due to the photothermal effect, nanobubbles can be formed through the vaporization of the liquid environment (Figure 25d).<sup>758</sup> The expansion and collapse of the vapor nanobubbles can create high pressure and strong fluid flows, thereby disrupting the nearby membrane and driving the intercellular delivery. The generated vapor nanobubbles can also prevent thermal energy from transferring to the surrounding environment, which is beneficial for better cell viability. This membrane-disruption strategy offers a lowcytotoxicity and high-throughput way to deliver diverse biomolecules and nanoparticles into cells. 

**5.5.3. Bacterial Inhibition.** The wide antibiotic abuse to combat bacterial infections has brought about a series of severe healthcare problems in our daily life. The bacterial resistance caused by antibiotics and the formation of self-protected biofilms make bacterial inhibition a global health task.<sup>759,760</sup> The development of photothermal materials offers a promising way for addressing antibacterial challenges.<sup>327,761,762</sup> Owing to the photothermal effect, the generated hyperthermia can destroy the integrity of pathogenic bacteria. Unlike the response to antibiotics, bacteria under photothermal treatment have difficulty producing drug resistance and adverse effects.<sup>381</sup> The protective matrix of bacterial cells, including proteins and nucleic acids, can be inactivated or damaged by localized heating,<sup>763,764</sup> and thus antibacterial drugs find it much easier to penetrate the biofilm and kill the targeted bacteria. This bactericidal treatment with hyperthermia generally requires high power of light irradiation and high dosage of photothermal agents. Other bactericidal strategies have also been investigated to incorporate with the photothermal effect to achieve better curative efficacy.<sup>765</sup> The introduction of toxic metal ions such as Ag<sup>+</sup> , Cu<sup>2+</sup> , As<sup>3+</sup> , and Hg<sup>2+</sup> can facilitate the bactericidal activities by coordinating with the biological ligands of bacteria.<sup>766,767</sup> The formation of metal−biomolecule complexes can thus destroy the structures of DNAs, membranes, and enzymes, resulting in the death of bacterial cells.<sup>768,769</sup> Hollow AuAgCu2O-bromfenac sodium nanostructures have been designed as bifunctional carriers for both antibacterial and anti-inflammatory treatments (Figure 26a).<sup>770</sup> When the release of Ag<sup>+</sup> and Cu<sup>2+</sup> is mediated by a mild photothermal effect for bacterial elimination, the antiinflammatory drug can also be released to facilitate tissue rehabilitation. The participating Cu<sup>2+</sup> not only acts as a bactericidal agent but also promotes the healing of the infected wounds. Another important strategy for the bactericidal activity is to generate reactive oxygen species (ROSs) through a photodynamic or photocatalytic process.<sup>771−773</sup> ROSs, including singlet molecular oxygen, hydroxyl radicals, and superoxide anions, can cause autophagy, apoptosis, and necrosis of bacterial cells.<sup>774</sup> The synergistic combination of photothermal and photodynamic effects has been demonstrated to enhance bacterial membrane permeation (Figure 26b).<sup>774</sup> The outer and inner bacterial membranes are disrupted by heat and ROSs, respectively. The entry of ROSs in bacteria can further induce the outbreak of oxidative stress and the protein leakage, leading to a fast and effective bactericidal activity. A plasmonic hybrid system made of MoO3‑ _x_ and Ag has been reported for enhanced bacterial killing with synergistic photothermal and photocatalytic effects (Figure 26c).<sup>775</sup> MoO3‑ _x_ can efficiently convert the absorbed NIR light into heat, and further transfer the thermal energy to the Ag nanocubes to drive the release of Ag<sup>+</sup> . The hot electrons and holes can be produced and separated at the interface 



Figure 26. Antibacterial therapy. (a) Schematic illustrating the antibacterial treatment through the release of metal ions (Ag<sup>+</sup> and Cu<sup>+</sup> ) from AuAgCu2O-bromfenac sodium nanoparticles. Reprinted with permission from ref 770. Copyright 2020 Ye et al., published under the CC BY 4.0 license http://creativecommons.org/licenses/ by/4.0/. (b) Illustration showing the antibacterial mechanism of bacterial membrane disruption with ROSs. Reprinted with permission from ref 774. Copyright 2019 American Chemical Society. (c) Schematic illustrating the photothermal and photocatalytic antibacterial mechanisms of hybrid nanostructures made of MoO3‑ _x_ and Ag. Reprinted with permission from ref 775. Copyright 2018 Elsevier. 

between MoO3‑ _x_ and Ag, promoting the generation of ROSs. The bactericidal activity is greatly enhanced in the cooperation of thermal energy, Ag<sup>+</sup> , and ROSs. 

**5.5.4. Polymerase Chain Reaction (PCR).** PCR has been the standard molecular diagnostic routine for amplifying and detecting nucleic acids because of its high sensitivity and specificity. PCR mainly relies on a three-step thermal cycling, including (1) denaturation�separation of two strands of DNAs at a high temperature; (2) annealing�hybridization of the complementary and short single-stranded DNA fragments at a low temperature; and (3) extension�generation of a new DNA strand from the annealed DNA template by polymerase.<sup>776</sup> Such a chain reaction process allows researchers to replicate billions of specific nucleic acid segments exponentially. The initial nucleic acid concentration can also be estimated according to the cycle threshold value. PCR has therefore been regarded as the gold standard for quantitative diagnosis. However, many conventional PCR-based bioassays are limited by time-consuming procedures and expensive Peltier-based heating blocks.<sup>74</sup> Since multiple cycles and two or three discrete temperatures are required for the amplification of nucleic acids, to reduce the thermocycling rate has become the key to achieving fast/ultrafast PCR. Nanomaterials with 

**6924** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

excellent photothermal capabilities have been explored to accelerate heating and cooling processes through volumetric heating and efficient heat transfer.<sup>76,777−779</sup> A Au-nanorodbased PCR system has been reported for the rapid detection of bacterial cells (Figure 27a).<sup>780</sup> The procedures of the bacteria 



Figure 27. Polymerase chain reaction. (a) Schematic showing DNA extraction and the photo-PCR of bacterial cells. Reprinted with permission from ref 780. Copyright 2017 Ivyspring International Publisher under the CC BY 4.0 license http://creativecommons.org/ licenses/by/4.0/. (b) Schematic depicting the real-time PCR using dual-modal magnetic Fe3O4 nanoparticles for DNA isolation and amplification. Reprinted with permission from ref 782. Copyright 2016 Springer Nature under the CC BY 4.0 license http:// creativecommons.org/licenses/by/4.0/. (c) Photograph of the plasmofluidic-PCR chip. Reprinted with permission from ref 75. Copyright 2021 Kang et al., published under the CC BY 4.0 license http://creativecommons.org/licenses/by/4.0/. 

lysis and DNA amplification are integrated into one step to reduce the cycling time. The total time for the complete identification of the bacterial DNAs is shortened to less than 20 min. By optimizing the structural design of nanomaterials for higher photothermal conversion efficiencies, the thermocycling time can be further reduced to achieve the desirable ultrafast PCR.<sup>77,781</sup> Dual-modal Fe3O4 nanoparticles with both photothermal and magnetic properties have been used to develop a portable real-time PCR device (Figure 27b).<sup>782</sup> The magnetic Fe3O4 nanoparticles are employed to promote the movements of the primers and DNA templates and thus accelerate the DNA amplification. Compared to plasmonic metals, Fe3O4 possesses better thermal stability. It can resist high temperatures. Furthermore, an ultrafast vacuum-packaged plasmofluidic PCR chip has been developed for highly efficient and small-volume bioassay (Figure 27c).<sup>75</sup> The amplification process with 40 cycles can be completed in 306 s for SARSCoV-2 and in 264 s for _λ_ -DNA, together with an amplification efficiency of 91%. In a recent PCR example, the nucleic acid amplification can be reduced to 4 cycles with a runtime of 7.5 min for the detection of SARS-CoV-2.<sup>788</sup> PCR-based tests have been the gold standard with a high analytical accuracy of 99% for COVID-19 confirmation.<sup>783,787</sup> Although the PCR technology has been already commercialized for rapid diagnosis, particularly for COVID-19, the investigation of 

nanomaterials with better photothermal performances is still an essential pathway for the development of ultrafast, robust, and portable PCR at the point-of-care level.<sup>783,784</sup> 

**5.5.5. Fight against COVID-19.** The outbreak of COVID19, resulting from the infection of severe acute respiratory syndrome coronavirus 2 (SARS-CoV-2), has brought about a global pandemic to threaten public health. Scientists around the world have made great progresses in personal protective equipment, effective vaccines, reliable diagnostic tools, and therapeutic approaches.<sup>78,785,786</sup> Photothermal nanomaterials can also pose a significant impact on the processes of diagnosis, prevention, and treatment to fight against COVID-19. Apart from the PCR-based test, a dual-functional plasmonic biosensor based on the photothermal effect and LSPR sensing has been developed with a highly sensitive and reliable detection capability for COVID-19 diagnosis (Figure 28a).<sup>80</sup> The localized photothermal heat is employed to elevate the hybridization temperature of the nucleic acids and improve the separation accuracy of two similar gene segments. The detection limit for the selected SARS-CoV-2 sequences can be lowered to a concentration of 0.22 pM. Respiratory face masks can also be integrated with photothermal nanomaterials for antimicrobial action (Figure 28b).<sup>789</sup> The synergistic combination of photothermal and photocatalytic effects can endow the masks with reusability and a self-sterilizing ability. More types of reusable and antimicrobial face masks have also been demonstrated in cooperation with different photothermal nanomaterials.<sup>82,790</sup> Furthermore, the decoration of photothermal nanoparticles with high-affinity neutralizing antibodies, which are specific to the spike proteins of SARS-CoV-2, has been designed to effectively capture the virus (Figure 28c).<sup>791</sup> SARS-CoV-2 is forbidden to enter host cells due to the antibody treatment and subsequently inactivated owing to the photothermal effect. This strategy of functionalizing photothermal nanoparticles with antiviral agents offers tremendous potential for blocking SARS-CoV-2 and reducing the infection.<sup>78,106</sup> 

### **5.6. Other Applications** 

Besides the above-discussed applications, photothermal nanomaterials can also be potentially applied in sensing, wearable devices, energy storage and conversion, as well as photothermal electrodes. In this section, several representative examples of these applications will be presented. 

Photothermal nanomaterials are normally hybridized with some other temperature-sensitive components to achieve sensing functionality. In the hybrid system, photothermal nanomaterials function as light-to-heat converters that will transfer the converted thermal energy to the temperaturesensitive components. The temperature-sensitive components further transform heat into other types of signals, for instance, electrical changes, which are easily detected and thus realize the sensing function. For example, Au nanorods have been used as antennae for IR light, transforming light into heat in photoreceptors that are the light-sensing cells in the eye (Figure 29a).<sup>792,793</sup> Au nanorods can capture NIR light at their resonance wavelengths to generate heat, which is harnessed to open temperature-sensitive transient receptor potential (TRP) channels. Antibodies are used to bind Au nanorods to the heatsensitive TRP channels. Combined with GT, such a dual system can enable the activation of photoreceptors by IR light and thus be potentially used to restore light sensitivity in a blind human retina. 

**6925** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 28. Applications of photothermal nanomaterials in COVID-19 diagnosis, prevention, and treatment. (a) Left: schematic showing photothermally enhanced LSPR sensing. Right: temperature distribution map around the heat source on a Au nanoisland (top) and concentrations of various viral oligos measured with the dual-functional LSPR biosensor (bottom). Reprinted with permission from ref 80. Copyright 2020 American Chemical Society. (b) Schematic illustrating the inactivation of the virus in a nonwoven surgical mask through photothermal, photocatalytic, and hydrophobic self-cleaning processes. Reprinted with permission from ref 789. Copyright 2021 American Chemical Society. (c) Schematic illustrating a multifunctional photothermal nanoparticle for the capture (by antibody) and inactivation (by photothermal conversion) of SARS-CoV-2. Reprinted with permission from ref 791. Copyright 2022 Cai et al., published under the CC BY 4.0 license http://creativecommons. org/licenses/by/4.0/. 



Figure 29. Representative potential applications of photothermal nanomaterials in sensing, photothermal electrodes, and wearable devices. (a) Sensing. The schematic illustrates the restoration of the light sensitivity of an eye using Au nanorods bound to temperature-sensitive engineered TRP channels. Reprinted with permission from ref 792. Copyright 2020 American Association for the Advancement of Science. (b) Photothermal electrodes. Left: schematic illustrating a TiN-based supercapacitor under solar illumination at an open environment and −40 °C. Right: cyclic voltammetry curves of the photothermally assisted supercapacitor at −40 °C with and without solar illumination. Reprinted with permission from ref 797. Copyright 2021 Elsevier. (c) Wearable devices. Top: schematic illustrating the photothermal effect produced from (Ag nanoparticle)@ MXene hybrid structures when irradiated with light. Bottom: photograph (left) of a composite film made of (Ag nanoparticle)@MXene and polyurethane and attached on one human hand, and IR thermal images of the human hand with the attached film before (middle) and after (right) solar irradiation for 1 min. Reprinted with permission from ref 801. Copyright 2019 American Chemical Society. 

The heat generated by photothermal nanomaterials under light irradiation has been widely used to accelerate chemical reactions and enable reactions that require harsh conditions to proceed under mild conditions. Photothermal nanomaterials 

can consequently be employed as electrode materials for electrochemical reactions, which will enhance electrocatalytic reactions<sup>794−796</sup> or allow reactions to proceed in cold atmosphere.<sup>797</sup> Take photothermal supercapacitors as an 

**6926** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

example (Figure 29b, left panel).<sup>797</sup> A photothermal supercapacitor has been designed using an electrochemically active and photothermal electrode material. It shows the capability of operation even under −40 °C. The used commercially available TiN nanocrystals exhibit broad light absorption (>98%) in the entire solar spectrum and a photothermal conversion efficiency of 62.5%, endowing the as-fabricated device with a rising temperature of 25.8 °C under solar light illumination. Such a photothermal effect further contributes to the restored capacitance of the device from a declined one at −40 °C (Figure 29b, right panel). The capacitance and energy density of the device at −40 °C are restored to be 70.9% and 59.3%, respectively, of those at 25 °C when under solar light illumination. 

Wearable devices have emerged as a hot research topic in recent years due to their great potential in human healthcare and health monitoring.<sup>798−800</sup> Specifically, photothermal nanomaterials provide wearable devices with multiple functions including PTT, self-healing, EMI shielding, human physiological signal monitoring, and energy harvesting.<sup>801−807</sup> We focus here on the discussion of the functions of nanomaterials introduced by the photothermal effect, among which PTT has been described in detail in Section 5.5.1. We therefore discuss here the representative examples of how photothermal nanomaterials work in the self-healing of wearable devices, as shown in Figure 29c and in energy harvesting. 

Wearable devices can suffer from unexpected mechanical damages during practical applications because the real world is dynamic rather than static. Silver-nanoparticle-anchored MXene nanohybrids have been designed to achieve a rapid and _in situ_ repair of the damaged elastic polyurethane. The nanohybrids have been incorporated into a polyurethane elastomer through solution-based blending and coating processes. The synergistic effects from the photothermal conversion of the MXene nanosheets and the plasmonic effect of the Ag nanoparticles lead to a temperature increase of approximately 111 °C under light irradiation for 5 min (Figure 29c, top panel). Such an increased temperature results in the fusion of the elastic polyurethane and consequently the repair of the damaged composite. A healing efficiency of 97% has been achieved. 

It is also worth mentioning that when integrated with thermoelectric materials, photothermal nanomaterials can potentially harvest solar energy and transfer it to thermal energy, which is further harnessed to generate electricity to power wearable devices.<sup>806,807</sup> For instance, PPy, a photothermal layer, has been deposited on a thermoelectric layer (poly(3,4-ethylenedioxythiophene):tosylate (PEDOT:Tos)) to achieve photothermoelectric generation for wearable devices.<sup>803</sup> Taking advantage of the efficient photothermal conversion of PPy, the as-fabricated photothermoelectric fabric can generate a higher voltage of 536.47 _μ_ V than that without the PPy coating (294.13 _μ_ V) under IR light irradiation, giving a power density up to 13.76 nW m<sup>−2</sup> . 

Phase-change materials provide one promising way to store solar thermal energy because of their high phase-change latent heat.<sup>808</sup> The key factors in determining the photothermal energy conversion efficiency include the capability of solarthermal conversion, thermal stability, shape stability, thermal conductivity, and thermal energy storage density.<sup>809−813</sup> Even though conventional phase-change materials, such as paraffin waxes and fatty acids, exhibit high energy-storage capacities, 

they generally own limitations in photothermal energy conversion, thermal conductivity and stability. They therefore exhibit low photothermal energy conversion efficiencies, which limits their applications in solar energy conversion. Photothermal nanomaterials have become promising for effectively addressing the above-mentioned challenges through incorporation with phase-change materials. Different types of photothermal nanomaterials, including carbon-based nanomaterials (graphene oxide, CNTs),<sup>811,814,815</sup> MXene nanosheets,<sup>813,816−818</sup> metal nanoparticles,<sup>810,819</sup> and organic polymers,<sup>820−822</sup> have been successfully combined with phase-change materials to achieve high photothermal energy conversion efficiencies. For example, a layered phase-change composite made of polyethylene glycol and Ti3C2T _x_ has been demonstrated to show an improved photo-to-thermal storage efficiency of 94.5% under natural solar light irradiation, which is higher than that of pure polyethylene glycol.<sup>813</sup> Besides the photothermal storage efficiency, the as-fabricated composite also presents a high energy density and stable property before and after the phase change. 

### **6. CONCLUSION AND OUTLOOK** 

The recent advances on photothermal nanomaterials have been comprehensively summarized in this review article, including their photothermal conversion mechanisms, material choices, temperature measurements, and diverse applications. One major advantage of photothermal nanomaterials is their broad light absorption range and excellent photothermal conversion ability, thus allowing for the efficient utilization of solar energy as a sustainable solution for energy scarcity. In addition to acting as an energy source, light can also serve as an external control to remotely alter thermal gradients, as well as the position and morphology of photothermal nanoparticles. Through further integration with other molecules or particles, the functionalized photothermal nanomaterials with synergistic properties can perform multiple tasks for targeted applications, including light manipulation, catalysis, and therapy, with the assistance of thermal energy. 

Although the generation of photothermal heat can be divided into the three different mechanisms, which are plasmonic localized heating, nonradiative relaxation, and thermal vibrations, it has still been difficult to unambiguously identify the photothermal conversion mechanism of a given type of nanostructure among various newly emerging materials and to choose proper nanomaterials for specific applications. To further improve the performance of photothermal materials and extend their applications to more scenarios, many challenges will need to be overcome in the near future. The synthesis of nanomaterials with extremely high absorption over a broad wavelength range has always become a very active field, attracting more and more research interests toward perfect light absorbers.<sup>15,18</sup> Further development of economical approaches for the mass production of photothermal materials is essential for realizing their ultimate usage in daily life and industrial applications. Moreover, how to maintain the stability and photothermal conversion efficiencies of nanomaterials during long-term operation has still remained a challenge for practical applications and requires further exploration.<sup>22,27,28</sup> 

The implementation of many photothermal applications requires the accurate monitoring of local temperatures, such as PTT,<sup>20,24,71</sup> biomedical diagnostics,<sup>385,386</sup> photochemistry,<sup>9,387</sup> nanofabrication,<sup>64,85,519</sup> and realistic microelectronic devi- 

**6927** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

ces.<sup>798,800</sup> Regardless of the ultimate application, there is still much room for the development of new nanothermometry with high sensitivity, accuracy, spectral/temporal resolution, reproducibility, stability, biocompatibility, cost effectiveness, and ease of operation. The heater−thermometer nanoplatforms reported so far have shown the possibility of simultaneous photothermal heating and real-time temperature feedback, which is particularly attractive for controllable biomedical therapy and photothermal catalysis. On the one hand, biological applications of heater−thermometer nanoplatforms not only require biocompatibility but also place additional demands on the optical properties that allow the heating beam, the fluorescence excitation beam, and the emission beam to pass through the involved tissues.<sup>385</sup> On the other hand, an ideal tool is also highly demanded for monitoring photocatalytic processes. Even though thermal energy has been utilized in many works to drive or assist in catalytic chemical reactions, it has remained challenging to clearly distinguish the contributions of photothermal heating and nonthermalized hot charge carriers. Debates have lasted for many years on the dominant effect in plasmon-enhanced catalysis, where both hot charge carriers and thermal energy can be produced through the excitation of LSPRs.<sup>653−657</sup> As these two effects occur at different time scales and are originated from different physical processes, advanced technologies and ingeniously designed experiments are required to uncouple the underlying mechanisms of plasmon-enhanced catalysis and thus realize the use of plasmons to better control chemical reactions in terms of the reaction pathway, activity, and selectivity. 

For solar thermal water heating and evaporation, a standardized process for evaluating the performance of different photothermal nanomaterials is still lacking.<sup>53,507</sup> Researchers are suggested to list the detailed measurement conditions and calculation methods for the evaluation of the evaporation efficiency of the studied photothermal system. A widely discussed guideline by researchers in this field to fairly compare different photothermal nanomaterials will be highly desired. Further studies on water desalination and purification should also consider volatile organic compounds, some of which can be vaporized and collected with desalinated water.<sup>53</sup> The development of multifunctional nanomaterials with the capabilities of photothermal conversion and the removal of volatile organic compounds can be a solution. For structural color printing, we envision that further research should be devoted to the development of efficient techniques for tuning the colors of individual high-resolution pixels toward dynamic color display.<sup>62,508</sup> Beyond the control of the reflection, transmission, and scattering spectra of light in structural color prints, localized laser heating can also be used to fabricate metasurfaces and metamaterials for the adjustment of the phase, polarization, and angular momentum of light.<sup>525,590</sup> The merits of light-driving nanomotors, actuators, and robots include the remote energy supply and multiple tuning parameters of light for photothermal manipulation. However, most research works on photothermal manipulation have only demonstrated simple motions of micro-/nano-objects. More efforts are needed toward the design and construction of mature systems that can accomplish complicated tasks. The biomedical applications of photothermal manipulation for inbody treatment and surgery as well as precise manipulation of biological components are still challenging.<sup>616</sup> Biocompatible and biodegradable nanoscale motors, actuators, and robots, 

which can be operated under safe stimulating conditions, are required. Additional efforts are also desired for reducing the response time during in-body operation. We are confident that the more elegant integration of photothermal nanomaterials with thermal responsive components will produce smarter nanomotors, actuators, and robots for wider applications in engineering and medicine. 

Photothermal nanomaterials have been widely studied in the field of life sciences and especially show great potential for PTT. There are still many problems to be addressed. High water solubility, good biocompatibility and biodegradability are desired for inorganic photothermal nanomaterials to provide low toxicity.<sup>98,645</sup> Organic nanomaterials are expected to have high thermal stability and high photothermal conversion efficiencies. The development of nanomaterials with strong light absorption in the biological NIR-II window is required to achieve deeper tissue penetration for enhanced photothermal therapeutic efficacy. It is also necessary to quantify the damage caused by the hyperthermia on the surrounding tissues and minimize the injury of normal cells.<sup>381</sup> Moreover, much effort should be made to integrate photothermal nanomaterials with biologically mimic coatings to overcome different biological barriers and thus facilitate drug delivery, bacteria inhibition, and other biological activities.<sup>742</sup> 

Nowadays, most of the aforementioned photothermal nanomaterials and nanothermometers are commercially available as raw materials for researchers and start-up companies. While most applications have only been demonstrated in research laboratories, a few examples have shown promise for real-life applications, such as the PCR test, AuroLase Therapy, and wearable devices. Furthermore, there is great potential of photothermal nanomaterials in energy science in terms of solar cells, photothermal catalysis, and energy storage. In general, there exist several critical factors for successful commercialization. First, the ability to scale up the production of diverse photothermal nanomaterials with optimized cost efficiencies is essential for most industrial applications. Second, the biosecurity and environmental safety of these materials have not been fully assessed, which is a critical consideration for commercialization. 

We believe that there will be ceaselessly enthusiastic research effort to continuously broaden the family of photothermal nanomaterials and explore new directions for real-life practical applications. The ongoing progresses will undoubtedly address most unresolved challenges and bring about new scientific inquiries. All of the effort will make photothermal nanomaterials an even more powerful light-to-heat converter. 

### **AUTHOR INFORMATION** 

### **Corresponding Authors** 

- Jianfang Wang − _Department of Physics, The Chinese University of Hong Kong, Hong Kong, SAR 999077, China;_ orcid.org/0000-0002-2467-8751; Email: jfwang@ 

- phy.cuhk.edu.hk 

- Hongxing Xu − _School of Physics and Technology and School of Microelectronics, Wuhan University, Wuhan 430072 Hubei, China; Henan Academy of Sciences, Zhengzhou 450046 Henan, China; Wuhan Institute of Quantum Technology, Wuhan 430205 Hubei, China;_ orcid.org/ 0000-0002-1718-8834; Email: hxxu@whu.edu.cn 

**6928** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

### **Authors** 

- Ximin Cui − _State Key Laboratory of Radio Frequency Heterogeneous Integration, College of Electronics and Information Engineering, Shenzhen University, Shenzhen 518060, China;_ orcid.org/0000-0001-7115-5032 

- Qifeng Ruan − _Ministry of Industry and Information Technology Key Lab of Micro-Nano Optoelectronic Information System & Guangdong Provincial Key Laboratory of Semiconductor Optoelectronic Materials and Intelligent Photonic Systems, Harbin Institute of Technology, Shenzhen 518055, China;_ orcid.org/0000-0002-15929010 

- Xiaolu Zhuo − _Guangdong Provincial Key Lab of Optoelectronic Materials and Chips, School of Science and Engineering, The Chinese University of Hong Kong (Shenzhen), Shenzhen 518172, China;_ orcid.org/00000002-5895-3336 

- Xinyue Xia − _Department of Physics, The Chinese University of Hong Kong, Hong Kong, SAR 999077, China_ 

- Jingtian Hu − _Department of Physics, The Chinese University of Hong Kong, Hong Kong, SAR 999077, China_ 

- Runfang Fu − _Department of Physics, The Chinese University of Hong Kong, Hong Kong, SAR 999077, China;_ orcid.org/0000-0003-1203-9458 

- Yang Li − _State Key Laboratory of Radio Frequency Heterogeneous Integration, College of Electronics and Information Engineering, Shenzhen University, Shenzhen 518060, China_ 

Complete contact information is available at: https://pubs.acs.org/10.1021/acs.chemrev.3c00159 

### **Author Contributions** 

> †X.M.C., Q.F.R., and X.L.Z. contributed equally to this work. CRediT: Ximin Cui conceptualization, funding acquisition, investigation, project administration, writing-original draft, writing-review & editing; Qifeng Ruan conceptualization, funding acquisition, investigation, writing-original draft, writing-review & editing; Xiaolu Zhuo conceptualization, funding acquisition, investigation, writing-original draft, writing-review & editing; Xinyue Xia investigation, writingoriginal draft; Jingtian Hu investigation, writing-original draft; Runfang Fu investigation, writing-original draft; Yang Li investigation, writing-original draft; Jianfang Wang conceptualization, funding acquisition, investigation, project administration, supervision, writing-review & editing; Hongxing Xu conceptualization, project administration, writing-review & editing. 

### **Notes** 

The authors declare no competing financial interest. 

### **Biographies** 

Ximin Cui received his B.S. degree in physics from Nanjing University in 2014. He obtained his Ph.D. degree in physics from The Chinese University of Hong Kong in 2018, working under the supervision of Prof. Jianfang Wang. He joined the group of Prof. Mikael Käll at Chalmers University of Technology as a postdoctoral fellow from 2019 to 2021. He is currently an assistant professor at the College of Electronics and Information Engineering, Shenzhen University. His research interests include the synthesis, assembly, and optical manipulation of metallic nanostructures. 

Qifeng Ruan received his B.S. degree from University of Science and Technology of China in 2011. After obtaining his Ph.D. degree from The Chinese University of Hong Kong in 2015 under the supervision of Prof. Jianfang Wang, he carried out research on resonance coupling in the same group. In 2017, he moved to Shenzhen and Singapore to conduct research on nanofabrication and structural colors. He joined School of Science, Harbin Institute of Technology (Shenzhen), as an associate professor in 2022. His research interests mainly focus on the optical properties and applications of wet-chemistry synthesized metal/semiconductor nanocrystals and 3D-printed micro-/nanostructures. 

Xiaolu Zhuo received her B.S. degree in physics from Sun Yat-sen University in 2010 and her Ph.D. degree in physics from the Department of Physics at The Chinese University of Hong Kong in 2017 under the supervision of Prof. Jianfang Wang. During 2019− 2022, she conducted her postdoctoral research at CIC biomaGUNE (Spain) as a Juan de la Cierva fellow under the supervision of Prof. Luis M. Liz-Marzán. She joined the School of Science and Engineering, The Chinese University of Hong Kong (Shenzhen), as an assistant professor in 2022. Her research interests include the synthesis of metallic/dielectric nanoparticles and their optical properties and applications. 

Xinyue Xia received her B.S. degree in materials science in 2016 from Soochow University. She is currently a Ph.D. student at The Chinese University of Hong Kong in Prof. Jianfang Wang’s group. Her current research interests focus on the synthesis of plasmonic nanoparticles, their optical properties and modulation of two-dimensional excitons in plasmonic nanocavities. 

Jingtian Hu obtained his B.E. degree in composite materials and engineering in 2017 and his M.E. degree in materials science in 2020, both from Northwestern Polytechnical University. He is currently a Ph.D. candidate in the Department of Physics of The Chinese University of Hong Kong under the supervision of Prof. Jianfang Wang. His current research focuses on the preparation of plasmonic nanomaterials, and their photocatalytic as well as photothermal applications. 

Runfang Fu received her B.E. degree and M.E. degree in textile engineering from Sichuan University in 2014 and 2017 and her Ph.D. degree in chemical engineering from Monash University in 2021. She is currently a postdoctoral researcher in Prof. Jianfang Wang’s group. Her research interests include self-assembly of plasmonic nanostructures and their applications. 

Yang Li received his Ph.D. degree in materials physics and chemistry from Wuhan University in 2018. After that, he continued to work at Wuhan University as a research assistant during 2018−2020. He is currently an assistant professor in nanophotonics in the College of Electronics and Information Engineering, Shenzhen University. His research interests include light−matter interaction in plasmonic nanocavities, waveguiding optics, and surface-enhanced spectroscopy. 

Jianfang Wang obtained his B.S. degree in chemistry and software design in 1993 from University of Science and Technology of China, his M.S. degree in chemistry in 1996 from Peking University, and his Ph.D. degree in physical chemistry in 2002 from Harvard University. He then conducted his postdoctoral research at University of California, Santa Barbara from 2002 to 2005. After that, he joined the Department of Physics of The Chinese University of Hong Kong as an assistant professor. He was promoted to associate professor in 2011 and professor in 2015. His current research interests include colloidal metal nanocrystals, nanoplasmonics, dielectric nanomaterials for nanophotonics, and photocatalysis. 

**6929** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

Hongxing Xu is a professor of physics in the School of Physics and Technology at Wuhan University. He is a member of the Chinese Academy of Sciences. He received his B.S. from Peking University in 1992 and his Ph.D. from Chalmers University of Technology in 2002, both in physics. He then joined the Division of Solid State Physics at Lund University, as an assistant professor until December 2004. From 2005 to 2014, he was a professor at the Institute of Physics, Chinese Academy of Sciences. He is known for the discovery of the nanogap effect for huge electromagnetic enhancement, the invention of plasmonic logic gates, and the development of plasmonic nanowire waveguides and circuits. His research interests include plasmonics, nanophotonics, surface-/tip-enhanced spectroscopy, and singlemolecule spectroscopy. 

### **ACKNOWLEDGMENTS** 

J.F.W. acknowledges support from the Research Grants Council of Hong Kong (General Research Fund, ref. No. 14302322) and Guangdong Basic and Applied Basic Research Foundation (General Research Fund, ref. No. 2022A1515010247). X.M.C. acknowledges support from National Natural Science Foundation of China (No. 62205223) and the Natural Science Foundation of Guangdong Province (No. 2023A1515011455). Q.F.R acknowledges the Natural Science Foundation of Guangdong Province (No. 2023A1515012912). X.L.Z acknowledges financial support from CUHK-Shenzhen (UDF 01002665). 

### **ABBREVIATIONS** 

|0D|zero-dimensional|
|---|---|
|1D|one-dimensional|
|2D|two-dimensional|
|3D|three-dimensional|
|AIE|aggregation-induced emission|
|BP|black phosphorus|
|CLSM|confocal laser scanning microscopy|
|CNTs|carbon nanotubes|
|CNT-PS|carbon nanotube coated with peptide lipid and<br>sucrose laurate|
|COFs|covalent organic frameworks|
|COVID-19|coronavirus disease 2019|
|D-A|donor−acceptor|
|DC|dendritic cell|
|DOX|doxorubicin hydrochloride|
|DPP|diketopyrrolopyrrole|
|EM|electromagnetic|
|EMI|electromagnetic interference|
|EPA|Environmental Protection Agency|
|EXAFS|extended X-ray absorption fine structure spec-<br>troscopy|
|FIR|far-infrared|
|GT|gene therapy|
|HOMO|highest-occupied molecular orbital|
|ICD|immunogenetic cell death|
|IR|infrared|
|LA|lactobionic acid|
|LCN|liquid crystalline network|
|LSPR|localized surface plasmon resonance|
|LUMO|lowest-unoccupied molecular orbital|
|MWCNTs|multiwalled carbon nanotubes|
|MOFs|metal−organic frameworks|
|mPEG-SH|methoxy-poly(ethylene glycol)-thiol|
|mSiO2|mesoporous silica|



|MXene|two-dimensional transition metal carbide/ni-<br>tride|
|---|---|
|NHE|normal hydrogen electrode|
|NIR|near-infrared|
|ODMR|optically detected magnetic resonance|
|PAA|poly(acrylic acid)|
|PAn|polyaniline|
|PCC|polydimethylsiloxane/carbon nanotubes/cellu-<br>lose nanocrystals|
|PCR|polymerase chain reaction|
|PDA|polydopamine|
|PDMS|poly(dimethylsiloxane)|
|PPy|polypyrrole|
|PT|polythiophene|
|PTT|photothermal therapy|
|PTTe|poly[2,2″-((E)-4,4″-bis(2-octyldodecyl)-[6,6″-<br>bithieno[3,2-b]pyrrolylidene]-5,5″-(4H,4′H)-<br>dione)-alt-2,5-(tellurophene)]|
|QDs|quantum dots|
|ROSs|reactive oxygen species|
|SARS-CoV-2|severe acute respiratory syndrome coronavirus 2|
|SWCNTs|single-walled carbon nanotubes|
|SEM|scanning electron microscopy|
|siRNAs|small-interfering ribonucleic acids|
|SPNE|semiconducting polymer nanoengager|
|SPNU|uncoated semiconducting polymer nanopar-<br>ticles|
|TEM|transmission electron microscopy|
|TMDCs|transition metal dichalcogenides|
|TRP|transient receptor potential|
|UCL|up-conversion luminescence|
|UCNPs|up-conversion nanoparticles|
|WHO|World Health Organization|
|ZIF-8|zeolitic imidazolate framework-8|



### **REFERENCES** 

(1) Chu, S.; Majumdar, A. Opportunities and Challenges for a Sustainable Energy Future. _Nature_ 2012, _488_ , 294−303. 

(2) Shih, C. F.; Zhang, T.; Li, J.; Bai, C. Powering the Future with Liquid Sunshine. _Joule_ 2018, _2_ , 1925−1949. 

(3) Gong, J.; Li, C.; Wasielewski, M. R. Advances in Solar Energy Conversion. _Chem. Soc. Rev._ 2019, _48_ , 1862−1864. 

(4) Smil, V. _The Earth’s Biosphere: Evolution, Dynamics, and Change_ ; MIT Press: Cambridge, 2003; p 346. 

(5) Almond, D. P.; Patel, P.; Patel, P. _Photothermal Science and Techniques_ ; Springer Science & Business Media: Stanmore, 1996; Chapter 1, p 9. 

(6) Zhao, F.; Guo, Y.; Zhou, X.; Shi, W.; Yu, G. Materials for SolarPowered Water Evaporation. _Nat. Rev. Mater._ 2020, _5_ , 388−401. 

(7) Gao, M.; Zhu, L.; Peh, C. K.; Ho, G. W. Solar Absorber Material and System Designs for Photothermal Water Vaporization towards Clean Water and Energy Production. _Energy Environ. Sci._ 2019, _12_ , 841−864. 

(8) Song, C.; Wang, Z.; Yin, Z.; Xiao, D.; Ma, D. Principles and Applications of Photothermal Catalysis. _Chem Catal._ 2022, _2_ , 52−83. 

(9) Mateo, D.; Cerrillo, J. L.; Durini, S.; Gascon, J. Fundamentals and Applications of Photo-Thermal Catalysis. _Chem. Soc. Rev._ 2021, _50_ , 2173−2210. 

(10) Li, X.; Lovell, J. F.; Yoon, J.; Chen, X. Clinical Development and Potential of Photothermal and Photodynamic Therapies for Cancer. _Nat. Rev. Clin. Oncol._ 2020, _17_ , 657−674. 

(11) Xu, C.; Pu, K. Second Near-Infrared Photothermal Materials for Combinational Nanotheranostics. _Chem. Soc. Rev._ 2021, _50_ , 1111−1137. 

**6930** 

https://doi.org/10.1021/acs.chemrev.3c00159 _Chem. Rev._ 2023, 123, 6891−6952 

