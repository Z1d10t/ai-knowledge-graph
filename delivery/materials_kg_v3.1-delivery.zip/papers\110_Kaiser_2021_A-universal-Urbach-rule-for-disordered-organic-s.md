# A universal Urbach rule for disordered organic semiconductors

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 220 |
| 作者 | Christina Kaiser, O. Sandberg, Nasim Zarrabi, Wei Li, P. Meredith, Ardalan Armin |
| DOI | 10.1038/s41467-021-24202-9 |
| 源文件 | 010_Kaiser_2021_A-universal-Urbach-rule-for-disordered-organic-s.pdf |

---
# **A Universal Urbach Rule for Disordered Organic Semiconductors** 

Christina Kaiser, Oskar J. Sandberg<sup>*</sup> , Nasim Zarrabi, Wei Li, Paul Meredith, Ardalan Armin<sup>*</sup> 

Sustainable Advanced Materials (Sêr-SAM), Department of Physics, Swansea University, Singleton Park, Swansea SA2 8PP, United Kingdom 

*Email: ardalan.armin@swansea.ac.uk; o.j.sandberg@swansea.ac.uk 

# **Abstract** 

In crystalline semiconductors, absorption onset sharpness is characterized by temperature dependent Urbach energies. These energies quantify the static, structural disorder causing localized exponentialtail states, and dynamic disorder from electron-phonon scattering. Applicability of this exponential-tail model to disordered solids has been long debated. Nonetheless, exponential fittings are routinely applied to sub-gap absorption analysis of organic semiconductors. Herein, we elucidate the sub-gap spectral line-shapes of organic semiconductors and their blends by temperature-dependent quantum efficiency measurements. We find that sub-gap absorption due to singlet excitons is universally dominated by thermal broadening at low photon energies and the associated Urbach energy equals the thermal energy, regardless of static disorder. This is consistent with absorptions obtained from a convolution of Gaussian density of excitonic states weighted by Boltzmann-like thermally activated optical transitions. A simple model is presented that explains absorption line-shapes of disordered systems, and we also provide a strategy to determine the excitonic disorder energy. Our findings elaborate the meaning of the Urbach energy in molecular solids and relate the photo-physics to static disorder, crucial for optimizing organic solar cells for which we present a new radiative open-circuit voltage limit. 

# **Introduction** 

Recently, research on organic solar cells has seen significant progress through the development of nonfullerene electron acceptors (NFAs), in particular delivering increases in single-junction efficiencies from 13.1 to 18.7 % between 2017 to 2021.<sup>1,2</sup> This has revived ambitions to ultimately achieve industrial scale low-cost photovoltaics with low embodied manufacturing energy. While chemists have been productively synthesising new materials, understanding of the opto-electronic properties lags behind – particularly in relation as to why these new NFA blends are so effective at photogeneration with low voltage losses. A particular area of intense interest is light absorption and how it is related to molecular 

dipole moments and their energetic disorder. Of course, this is also a very relevant question for the fundamental solid-state physics of molecular and disordered semiconductors. Furthermore, energetic disorder critically determines dominant radiative loss mechanisms limiting the open-circuit voltage in optoelectronic applications. 

In general, semiconductors tend to absorb light at photon energies below the bandgap (sub-gap absorption) depending on the energetic disorder. In the case of inorganic semiconductors, the absorption coefficient (𝛼) often displays an exponential tail below the bands. These so-called Urbach tails increase their broadening with temperature 𝑇.<sup>3</sup> The sub-gap 𝛼 generally follows the expression 



<!-- Start of picture text -->
𝛼(𝐸, 𝑇) ∝exp  ( 𝐸−𝐸𝐸Uo(𝑇)n(𝑇)),                                                    (1)<br><!-- End of picture text -->

where 𝐸 is the photon energy, 𝐸on is the energy onset of the tail, and 𝐸U(𝑇) is the Urbach energy quantifying the total energetic disorder of the system. Depending on the semiconductor, 𝐸U generally varies between 10 to 100 meV at room temperature.<sup>4–7</sup> In banded semiconductors, it has been suggested that 𝐸U(𝑇) = 𝐸U,D(𝑇) + 𝐸U,S , where 𝐸U,D(𝑇) is a temperature-dependent dynamical disorder term related to the thermal occupation of phonon states,<sup>4,8</sup> while 𝐸U,S is the width of the assumed exponential distribution of sub-gap states induced by static disorder.<sup>9</sup> However, a unifying theory describing the density of states and their absorption leading to Urbach tails for materials of different chemical bonding and morphology is still lacking.<sup>10–12</sup> 

In non-excitonic amorphous semiconductors, the definition of a clear bandgap edge is often difficult due to large static disorder inducing sub-gap broadening. Organic semiconductors, which are excitonic and partially amorphous, display even more complex sub-gap features including intermolecular hybrid charge transfer (CT) states in technologically-relevant blends of electron donors (D) and acceptors (A), excitonic features<sup>13</sup> and trap states<sup>14</sup> . CT states give rise to light absorption with Gaussian sub-gap spectral line-shapes. This has been attributed to intermolecular D:A transitions described by nonadiabatic Marcus theory<sup>15</sup> or its extensions<sup>16–19</sup> , suggesting that the static disorder is governed by a Gaussian distribution of CT states. Whether a similar description applies for sub-gap absorption by intramolecular excitons is unclear. With the rise of NFA semiconductors with small energetic offset relative to donors<sup>20</sup> , the lack of CT state sub-gap spectral features in donor-acceptor blends has led to the increased usage of Urbach energies to understand disorder and sub-gap photo-physics. As a rule of thumb, it has been assumed that low Urbach energies are indicative of lower static disorder and hence expected to result in higher performance such as reduced charge recombination and higher charge carrier mobilities in a photovoltaic device.<sup>21–23</sup> Due to the complex and often convoluted spectral features in sub-gap light absorption of organic semiconductors, however, the Urbach energy carries significant ambiguity. Moreover, a long-standing debate<sup>24–26</sup> on the distribution of density of states (DOS) defining the static disorder in organic semiconductors has been revived: does the DOS follow a 

Gaussian or an exponential distribution? With no doubt, the origin of the static disorder is of great importance for the classification and future development of organic semiconductors and their electrooptical properties. However, it has remained unclear how this important figure-of-merit relates to the Urbach energy. 

In this work, we show that the exciton sub-gap absorption in organic semiconductors, at photon energies well below the gap, is generally characterized by Urbach tails with characteristic energies equivalent to the thermal energy 𝑘𝑇 as demonstrated by temperature-dependent EQE measurements. However, these Urbach tails are often convoluted with Gaussian line-shapes induced by trap states and/or CT states, resulting in erroneous, energy-dependent, Urbach energies larger than 𝑘𝑇. A simple model, combining the Gaussian distributed DOS with Boltzmann-like thermally activated optical transitions, is shown to reproduce the absorption profiles and to give an estimate for the Gaussian static disorder. Based on this model, the exciton sub-absorption is found to be composed of two regimes: near the onset, the sub-gap absorption is dominated by Gaussian static disorder resulting in strongly energy dependent Urbach energies, while thermal broadening dominates at energies well below the gap, where the Urbach energy approaches 𝑘𝑇. As such, using an (energy-independent) Urbach energy as a probe for the static disorder in organic solar cells is meaningless. Finally, the effect of exciton static disorder and thermal broadening on the expected radiative voltage losses and power conversion efficiency (PCE) in organic solar cells based on low offset D:A blends is clarified. 

# **Results and Discussion** 

The spectral line-shape of 𝛼 and the absorbance 𝐴 in the sub-gap tail are generally related via a modified Beer-Lambert law, 𝐴= 𝑓̃𝛼𝑑, where 𝑑 is the thickness of the active layer and 𝑓̃ is an energydependent correction factor accounting for optical interference.<sup>27,28</sup> For optically thin films with layer thicknesses of 100 to 150 nm, 𝑓̃ is often assumed to be close to 1 (negligible optical interference effects). Moreover, it has been shown for efficient D:A systems that the internal quantum efficiency (IQE) is generally excitation energy independent, hence EQE ∝𝐴 and the spectral line shape of the EQE follows 𝛼 .<sup>29–32</sup> Based on this underlying premise, EQE measurements have been frequently employed in the past to determine 𝐸U. However, a previous lack of sensitivity in the EQE measurements has led to speculative assumptions about the spectral range of trap state absorptions, exponential tails and associated 𝐸U in organic semiconductors. By choosing a small fitting range, exponential fits can be forced on to EQE spectra resulting in rather arbitrary 𝐸U dependent on the spectral range of the fitting. More insight can instead be gained from the apparent Urbach energy (𝐸Uapp) here defined as: 



<!-- Start of picture text -->
−1<br>𝐸U                                                               (2)<br>𝑑𝐸<br>app(𝐸) =  [ 𝑑ln(EQE) ]<br><!-- End of picture text -->

For a true exponential tail of the form eq. 1, 𝐸Uapp is constant in the sub-gap spectral region and given by 𝐸U. 

**Determination of the apparent Urbach energy in organic solar cells** . **Figure 1** shows the EQE and 𝐸Uapp for a wide range of organic semiconductor D:A blends. The material systems studied here can be generally grouped according to the D:A energy offset or, in other words, the difference between the CT state energy 𝐸CT and the optical bandgap 𝐸opt. Here, 𝐸opt is typically equal to the local exciton (LE) energy of the lower-bandgap component (between D and A). Large offset systems, such as PCDTBT:PC70BM, BQR:PC70BM and PBDB-T:PC70BM (Figure 1a), show three distinct spectral ranges for energies below the gap: (i) mid-gap trap state absorption at energies below 1.2 eV, (ii) CT state absorption in the mid-range (~1.2 – 1.5 eV) and (iii) LE absorption above 1.5 eV. For mid-gap and CT state absorption, Gaussian-shaped EQE features are observed.<sup>14</sup> These features are consistent with Marcus charge-transfer between states that are distributed in accordance with a Gaussian density of sub-gap states. Details of the Gaussian fits are provided in the **Methods section** . Because of the Gaussian line-shape (see eq. S7), the corresponding 𝐸Uapp in the spectral range of CT absorption is expected to be strongly energy-dependent and given by 𝐸Uapp ≈2𝑘𝑇𝜆CT⁄(𝐸CT + 𝜆CT −𝐸); this is highlighted by the black solid line in Figure 1a. Here, 𝐸CT and 𝜆CT, as obtained from the Gaussian fits, are to be considered the effective energy and reorganization energy of CT states which includes the effect of static disorder (see **Supplementary Information** ).<sup>16,18</sup> At higher energies corresponding to the sub-gap LE absorption regime, in turn, 𝐸Uapp has a narrow parabolic shape with a sharp minimum at roughly 40 - 50 meV for the large offset blends. 









**Figure 1 | EQE and** 𝑬𝐔𝐚𝐩𝐩 **for organic D:A blends with different energetic offsets between** 𝑬𝐂𝐓 **and** 𝑬𝐨𝐩𝐭 **.** Schematic illustration of the energetic offset (𝐸opt −𝐸CT) decreasing from left to right. Gaussian fits in the spectral range of CT state and trap state absorption are performed where possible. For low offset blends PM6:Y6, PM6:ITIC and PBDB-T:EH-IDTBR, the EQE tail has the form 𝑒<sup>𝐸/𝑘𝑇</sup> , and 𝐸Uapp roughly equals 𝑘𝑇 in the spectral range that is dominated by the absorption of the acceptor. For large offset material systems, such as BQR:PC70BM, PBDB-T:PC70BM and PCDTBT:PC70BM, 𝐸Uapp shows a 2𝑘𝑇𝜆CT/(𝐸CT + 𝜆CT −𝐸) dependence in the spectral range of CT absorption. 

The EQE and 𝐸Uapp of blends with a smaller offset between 𝐸CT and 𝐸opt (PTB7-Th:ITIC, PBDBT:ITIC and PBDB-T:IT-4F) are shown in the Figure 1b. In this case, the Gaussian CT state line-shape is barely recognizable, and the 𝛼 tail in the spectral range of LEs is visible over a wider spectral range. While 𝐸Uapp retains its parabolic shape in the LE sub-gap absorption regime, because of the wider range, the minimum value of 𝐸Uapp is significantly reduced to values close to 𝑘𝑇. Finally, the EQE and 𝐸Uapp of blends in low-offset D:NFA systems (PM6:Y6, PM6:ITIC and PBDB-T:EH-IDTBR) are shown in Figure 1c. In these blends, the CT state absorption can no longer be discerned from the EQE spectra. Instead, the 𝛼 tail in the spectral range of LEs remains dominant down to the energy range of mid-gap 

state excitation. In this limit, the 𝐸Uapp in the LE-dominated sub-gap absorption range finally saturates and reaches a broad plateau where 𝐸Uapp ≈𝑘𝑇. 

The above experimental observation for low offset D:NFA systems suggests the presence of an intramolecular sub-gap absorption regime where 𝛼∝exp(𝐸𝑘𝑇⁄ ), but that its spectroscopic observation is obstructed by CT absorption in systems with larger offsets. To further clarify this, neat D or A systems (lacking the D-A CT absorption feature in the sub-gap EQE spectrum) were investigated as shown in **Figure 2** . In the case of neat PC70BM (Figure 2a), a narrow spectral range where 𝐸Uapp ≈ 𝑘𝑇 can be identified. This range is limited by deep trap-state absorption at low energies, while the poor exciton dissociation in the neat phase (translating into a low IQE) strongly reduces the EQE range at higher energies. However, the spectral range where 𝐸Uapp ≈𝑘𝑇 can be increased by adding 0.1 mol% of the wide-gap donor m-MTDATA, resulting in enhanced exciton dissociation. Since m- MTDATA:PC70BM is characterized by a low 𝐸CT, the LE tail of PC70BM can be clearly distinguished from CT states as shown in Figure 2a.<sup>33</sup> By further increasing the donor content, the CT state absorption increases and the parabolic shape of 𝐸Uapp emerges. This explains the parabolic shapes seen for large offset systems in Figure 1a, which appear when the 𝛼 tail in the spectral range of LE absorption becomes convoluted with CT state absorption. This is further supported by results shown in Figure 2b for neat NFA devices comprising ITIC and IT-4F active layers, respectively. Here again, exponentially decaying 𝛼 tail regions with 𝐸Uapp ≈𝑘𝑇 are observed. 

To check if 𝐸Uapp ≈𝑘𝑇 is also true for donor materials has proven more challenging, since the neat donor absorption is often convoluted with deep trap-state absorption. This convolution effectively increases 𝐸Uapp above 𝑘𝑇 as shown for PBDB-T in Figure 2c, where 𝐸Uapp ≈ 30 meV. The problem can be circumvented by using narrow-gap polymer donors such as PBTQ(OD) or PTTBAI, which show strongly redshifted EQE spectra when blended with PC70BM as previously reported.<sup>34</sup> As shown in Figure 2c, 𝐸Uapp is around 22 meV in this case. While deviations of the type 𝐸Uapp > 𝑘𝑇+ 10 meV are due to the presence of other absorbing species like CT states or deep trap states, small deviations of 𝐸Uapp around 𝑘𝑇 are likely caused by interference effects, i.e. non-constant 𝑓̃, as shown previously.27,35 Interference effects arise from the spectral dependence of the optical constants of the different layers in the thin-film stack and generally vary with the thickness of the active layer. To demonstrate the presence of interference effects, we therefore fabricated PM6:ITIC devices and PM6:Y6 devices of different active layer thicknesses. Indeed, as illustrated in the **Figures S3** , 𝐸Uapp shows a weak thickness dependence leading to deviations around 𝑘𝑇 from +2.3 meV to −5.8 meV. The thickness dependence of 𝐸Uapp is further corroborated by optical transfer-matrix simulations (see **Figure S4** in the **Supplementary Information** ). 



**Figure 2 | EQE tail dominated by neat material absorption. a,** EQE and 𝐸Uapp for a series of m-MTDATA sensitized PC70BM solar cells. The widest energy range over which 𝐸Uapp equals 𝑘𝑇 is observed for 0.1 mol% m-MTDATA in PC70BM due to improved exciton dissociation in comparison to neat PC70BM. Examples for EQE tails partially dominated by **b,** the neat donor absorption or by **c,** the neat acceptor absorption hence showing 𝐸Uapp ≈𝑘𝑇 in some parts of the spectrum. EQE spectra of PTTBAI:PC70BM and PBTQ(OD):PC70BM are taken from reference 34. 

**Temperature-dependent EQE measurements.** To verify that the exponential 𝛼 tails in the spectral range of LEs are characterized by 𝐸Uapp ≈𝑘𝑇, we performed 𝑇-dependent EQE measurements on PBDB-T:EH-IDTBR, PM6:Y6 and PM6:ITIC, and the neat materials IT-4F and Y6. **Figure 3a** shows the normalized EQE and the respective 𝐸Uapp spectra of three representative systems: PBDB-T:EHIDTBR, PM6:Y6 and IT-4F. The remaining material systems are provided in the **Supplementary Information** . Depending on 𝑇, two different regimes can be distinguished in the sub-gap absorption tail: At high 𝑇, 𝐸Uappspectra show a 𝑇-dependent plateau only influenced by interference effects and the shift in the absorption onset. At low 𝑇, however, the 𝐸Uappspectra generally attain a parabolic shape suggesting that the LE tail becomes convoluted with CT and/or mid-gap states. The thermal activation of the exponential 𝛼 tail is then finally illustrated in **Figure 3b** where 𝐸Uapp (at a constant energy) in the plateau region is shown as a function of 𝑘𝑇 for the systems studied. We see that 𝐸Uapp at higher 

temperature is linear and equals 𝑘𝑇± 2.5 meV, where the offset arises from interference effects. At lower 𝑇, 𝐸Uapp eventually deviates from linearity, as the spectral shape is increasingly affected by other absorbing species. For example, the low-energy tail of the CT absorption may emerge at low 𝑇 owing to its distinctly different 𝑇-dependence compared to LE absorption.<sup>36</sup> Moreover, the absorption of trap states is expected to play a role as well, while little is yet known about their spectral broadening as a function of 𝑇. 

For comparison, we also measured 𝑇-dependent EQE spectra of a commercial a-Si:H thin-film solar cell (EQE and 𝐸Uapp spectra shown in **Figure S6** ). In banded semiconductors such as a-Si:H, the total energetic disorder is 𝐸U(𝑇) = 𝐸U,D(𝑇) + 𝐸U,S, consistent with the presence of an exponential DOS of tail states (defined by the associated width 𝐸U,S). In **Figure 3b** , two regimes can be distinguished for a- Si:H comprising the low-temperature saturation of 𝐸U to 𝐸U(0) ≈ 40 meV and thermal activation at higher temperatures with an offset of roughly 21 meV from 𝑘𝑇 in agreement with previous reports.<sup>37–</sup> 39 In contrast, for the organic semiconductor systems in **Figure 3b** , an extrapolation to 𝑇= 0 implies that 𝐸U,S ≈0, suggesting the lack of an exponential tail state distribution in these systems. These observations raise the question why excitons in organic semiconductors follow 𝛼∝exp(𝐸𝑘𝑇⁄ ) resulting in 𝐸Uapp ≈𝑘𝑇 and what is the role of static disorder in shaping the 𝐸Uapp spectra. 



**Figure 3 | Temperature dependent apparent Urbach energies. a,** Normalized sub-gap EQE and 𝐸Uapp spectra of inverted PM6:Y6, PBDB-T:EH-IDTBR and neat IT-4F solar cells at different temperatures. Independent of temperature, 𝐸Uapp spectra show a local minimum (solid markers) at a constant energy within the spectral range dominated by exciton absorption. **b,** Minimum 𝐸Uapp as a function of 𝑘𝑇 for all tested materials systems including a commercial a-Si:H thin-film solar cell. 

**Model for understanding the sub-gap** 𝛂 **.** In the context of the Marcus formalism for non-adiabatic charge transfer (high-temperature limit), the presence of 𝐸Uapp ≈𝑘𝑇 in the spectral range of LE absorption (described by the absorption coefficient 𝛼LE) may be rationalized in terms of non-equal potential energy surfaces for the excited state and the ground state. By assuming a significantly more diffuse or delocalized excited state, compared to the (strongly localized) ground state, a much smaller reorganization energy is obtained for the excited state in comparison to the ground state.<sup>40–42</sup> In this limit, we expect 𝛼LE(𝐸) ≈𝛼sat exp([𝐸−𝐸opt]⁄𝑘𝑇) for 𝐸< 𝐸opt, in the case of negligible static disorder (see **Supplementary Information** ). Here, 𝛼sat includes a 1/𝐸 dependence, however, the subgap spectral line-shape is dominated by the Boltzmann factor. For above-gap absorption 𝐸> 𝐸opt, we assume 𝛼LE(𝐸) ≈𝛼sat . We note that this simplification of 𝛼LE(𝐸) essentially follows a MillerAbrahams-type charge-transfer formalism, sometimes used to describe exciton migration<sup>43</sup> , but more commonly used for charge transport<sup>44</sup> in organic semiconductors. Accounting for static disorder described by a DOS given by 𝑔DOS(𝐸opt′ ), the total absorption coefficient is of the form 𝛼LE(𝐸) = 

∫𝛼LE(𝐸, 𝐸opt′ )𝑔DOS(𝐸opt′ )𝑑𝐸opt′ . In the **Supplementary Information** , expressions for the associated absorption coefficients are derived for the cases of a Gaussian DOS and an exponential tail DOS. For the case of an exponential tail DOS with the width 𝑊, we obtain 𝐸Uapp = 𝑊 (see **Figure S7** ). This is 

indeed not what we observe in experiments. For a Gaussian DOS, in turn, we obtain 𝛼 in the form 



<!-- Start of picture text -->
𝛼LE(𝐸) 𝐸−𝐸opt + 2𝑘𝑇 𝜎𝑠2 𝐸−𝐸opt + 𝑘𝑇 𝜎𝑠2 𝐸−𝐸opt<br>=  1<br>𝛼sat 2 𝑘𝑇 𝜎𝑠√2 𝜎𝑠√2<br>{exp ( )  [1 −erf ( ) ] + erf ( )  + 1}            (3)<br><!-- End of picture text -->

where 𝜎𝑠 is the standard deviation of the Gaussian DOS and 𝐸opt is the associated mean exciton energy. Here, 𝐸opt corresponds to the optical gap and is determined by the first excited singlet state of either donor (𝐸opt = 𝐸D,LE) or acceptor (𝐸opt = 𝐸A,LE) in a blend. For 𝐸≪𝐸opt, eq. (3) reduces to the exponential part and 𝐸Uapp therefore equals 𝑘𝑇. For 𝐸≥𝐸opt, the error functions govern the spectral shape at the absorption edge as demonstrated in **Figure S8** in the **Supplementary Information** . 

To validate the model, we applied eq. (3) to 𝑇-dependent EQE spectra, as demonstrated in **Figure 4a** for neat Y6 and IT-4F. Using neat materials avoids the influences of CT states in the low-energy tail although trap states are always present at lower energies. Doing so, we obtain 𝜎𝑠 values of 47.0 ± 0.7 meV for Y6 and 35.0 ± 2.6 meV for IT-4F (see **Figure S10** in the **Supplementary Information** ). More fittings on room temperature EQE spectra of other material systems are shown in the **Figure S11** in the **Supplementary Information** ). For blend systems, the full experimental sub-gap EQE can be reconstructed assuming 𝛼(𝐸) = 𝛼LE(𝐸) + 𝛼CT(𝐸) + 𝛼t(𝐸) constituting the exponentially decaying 𝛼LE according to eq. (3) and the sum of two Gaussian functions (CT states and deep trap states; see eq. 5). In **Figure 4b,** we demonstrate the model for PBDB-T:PC70BM using the parameters 𝐸opt = 1.89 eV and 𝜎s = 60 meV, and other Gaussian fit parameters summarized in **Table S1** in the **Supplementary Information** . PBDB-T:PC70BM belongs to the group of blends for which 𝐸CT ≪𝐸opt with 𝐸CT −𝐸opt ≈ 0.45 eV. Nevertheless, the simplified model reproduces the strong spectral dependence of the experimental 𝐸Uapp, including the parabolic behaviour in the LE absorption dominated spectral range. On the other hand, by keeping all other parameters constant while increasing 𝐸CT with respect to 𝐸opt , the emergence of the 𝐸Uapp = 𝑘𝑇 plateau at around 1.6±0.1 eV can be reproduced. 





**Figure 4 | The sub-bandgap EQE as a function of** 𝑻 **and** 𝑬𝐂𝐓 **. a,** Experimental (black lines) and simulated (green lines) subgap EQE spectra of IT-4F and Y6. **b,** The line-shape of the experimental sub-gap EQE of PBDB-T:PC70BM can be described as the sum of LE absorption, CT state absorption, and trap state absorption: 𝛼= 𝛼LE + 𝛼CT + 𝛼t , with 𝛼LE given by eq. 3 (𝐸opt = 1.89 eV, 𝜎s = 60 meV), while 𝛼CT and 𝛼t are determined from their respective Gaussian fits. In the experiment, 𝐸Uapp is well above 𝑘𝑇, since 𝐸opt −𝐸CT > 0.3 eV . Increasing 𝐸CT (see eq. 5) in the simulation results in 𝐸Uapp →𝑘𝑇 between 1.5 to 1.7 eV. **c,** Schematic representation of the disorder regimes dominating 𝛼 in the absence of CT absorption comprising (i) static disorder 𝜎s close to the band edge, (ii) thermal broadening, where 𝐸Uapp = 𝑘𝑇, and (iii) deep trap state absorption well below the gap. 

In the absence of CT states, the above model predicts three sub-gap regimes of the 𝛼(𝐸) based on the dominant disorder mechanism as illustrated in **Figure 4c** . For photon energies close to the gap (𝐸> 𝐸opt −𝜎𝑠<sup>2</sup> ⁄𝑘𝑇 ), 𝐸Uapp is dominated by (Gaussian) static disorder. In this regime, the absorption resembles a Gaussian-like shape, where the steepness close to the gap is determined by 𝜎s, causing a redshift of the effective energy gap with increasing 𝜎s. While 𝐸Uapp does not directly represent 𝜎𝑠 at any energy, a positive correlation between 𝐸Uapp and 𝜎s is observed in this regime (see **Figure S9** ). A closer inspection suggests that 𝐸Uapp is strongly energy dependent in this regime, scaling with 𝜎s as 𝐸Uapp(𝐸) ≈2𝜎𝑠2⁄(𝐸𝑋 −𝐸), for 𝜎s < 4𝑘𝑇, where 𝐸𝑋 is a constant independent of 𝐸. This explains the previously reported correlation between morphological disorder and 𝐸Uapp close to the absorption onset.<sup>22,45–47</sup> For 𝐸< 𝐸opt −𝜎𝑠<sup>2</sup> ⁄𝑘𝑇, however, the exponential term in eq. (3) eventually starts to dominate the spectral line shape of 𝛼LE. In this regime, the sub-gap absorption of LEs is dominated by thermal broadening with 𝐸Uapp →𝑘𝑇, thus becoming independent of 𝜎s. The transition between the static disorder dominated and the thermal broadening dominated regime depends on 𝜎s (which is a 

measure of the Gaussian static disorder) and the temperature. This is simulated for the two cases 𝜎𝑠 = 70 meV and 𝜎𝑠 = 100 meV as shown in **Figure S9** : For 𝜎s = 70 meV, 𝐸Uapp reaches 𝑘𝑇 at 𝛼(𝐸) values 3 to 4 orders of magnitudes below 𝛼sat, while this is 6 orders below 𝛼sat for 𝜎𝑠 = 100 meV at room temperature. Finally, at energies well below the optical gap, 𝛼(𝐸) eventually becomes dominated by deep trap state absorption, resulting in an artificial increase in 𝐸Uapp and a concomitant deviation from 𝐸Uapp = 𝑘𝑇. Deep trap state absorption is typically observed 6 orders of magnitude below 𝛼sat limiting the spectral range dominated by thermal broadening. 

Based on these considerations, we estimate that it is possible to observe 𝐸Uapp ≈𝑘𝑇 only when 𝜎𝑠 < 100 meV (see Figure S9). Other conditions that must be met are: (i) the neat phase absorption of one component is spectrally separated from the other neat phase absorption, as well as from the CT states and trap states; (ii) the dynamic range of the EQE (or 𝛼) measurement is sufficiently wide to measure photocurrent at wavelengths well below the absorption onset of the neat material (𝐸< 𝐸opt −𝜎𝑠<sup>2</sup> ⁄𝑘𝑇); and (iii) optical cavity effects are not significant. Exponential sub-gap EQE spectra previously reported in literature for BHJs often do not fulfill these requirements, explaining reported Urbach energies much larger than 𝑘𝑇. Importantly, the 𝐸Uapp spectra introduced here do not suffer from the short fitting ranges of previous of 𝐸U measurements. In contrast, we have shown that an exponential distribution of tail states cannot explain the sub-gap spectral line-shape associated with singlet absorption, nor CT or trap state absorption in organic semiconductors. 

**Recombination losses and the radiative** 𝐕𝐎𝐂 **limit set by excitons.** The presence of sub-gap absorption is known to induce radiative recombination losses additional to those predicted by Shockley and Queisser (SQ) approach. While the short-circuit current density (𝐽SC) remains largely unaffected, the presence of sub-gap absorption mainly translates into enhanced losses in the open-circuit voltage (𝑉OC). In general, the 𝑉OC can be expressed as 𝑉OC = 𝑉OCSQ −Δ𝑉OCRAD −Δ𝑉OCNR , where 𝑉OCSQ represents the upper thermodynamic limit of the 𝑉OC based on the SQ model, assuming perfect above-gap absorption and no sub-gap absorption. Furthermore, Δ𝑉OCRAD = 𝑉OCSQ −𝑉OCRAD is the radiative loss induced by sub-gap absorption, while Δ𝑉OCNR = 𝑉OCRAD −𝑉OC is the non-radiative loss. Here, 𝑉OCRAD is the radiative limit of the 𝑉OC corresponding to the expected 𝑉OC in the absence of non-radiative losses. In accordance with detailed balance, we expect 𝑉OCRAD = 𝑘𝑇 <u>𝐽RADSC</u> where 𝐽SC = 𝑞 ln ~~(~~ 𝐽0 + 1) , 𝑞∫0∞ EQE(𝐸)Φsun(𝐸) 𝑑𝐸 and 𝐽0RAD = 𝑞∫0∞ EQE(𝐸)ΦBB(𝐸) 𝑑𝐸) is the dark saturation current density in the radiative limit; 𝑞 is the elementary charge and Φsun (ΦBB ) the solar spectrum (black body spectrum).<sup>48</sup> The SQ limit (𝑉OCRAD = 𝑉OCSQ) corresponds to the case when EQE = 1 for 𝐸> 𝐸opt, while EQE = 0 for 𝐸< 𝐸opt. We note that, because of the different ideality factors, the contribution from deep trap states will be is negligible under 1-sun conditions, as shown previously.<sup>14</sup> 

As we have shown above, in low offset systems such as state-of-the-art NFA-based blends (or neat material systems), the CT absorption is mostly overshadowed by the stronger NFA absorption (or is absent). In such systems the sub-gap absorption tail is dominated by excitons (𝛼= 𝛼LE). The expected radiative limit 𝑉OCRAD set by excitons can be calculated by assuming EQE = EQEmax × (𝛼LE⁄𝛼sat), with 𝛼LE given by eq. (3). The concomitant radiative loss Δ𝑉OCRAD, arising from the imperfect spectral line shape of 𝛼LE (leading to deviations from the ideal box-like EQE shape), is shown in **Figure 5a** at different 𝐸opt and 𝜎𝑠. As shown, the voltage loss Δ𝑉OCRAD increases with increasing 𝜎s. For example, when 𝜎s = 100 meV, Δ𝑉OCRAD is larger than 0.2 V. Furthermore, at large 𝜎s, the voltage loss becomes more prominent at larger 𝐸opt. We note that these losses are caused by a drastic increase in 𝐽0RAD, while 𝐽SC is essentially unchanged. As 𝜎s is reduced, in turn, Δ𝑉OCRAD is correspondingly decreased. For small static disorder (i.e., small 𝜎s), an analytical approximation relating Δ𝑉OCRAD and 𝜎s can be obtained as 



<!-- Start of picture text -->
𝑞Δ𝑉OCRAD ≈ 𝜎𝑠2 𝐸opt 𝜎𝑠 2 3<br>2𝑘𝑇 3𝑘𝑇<br>+ 𝑘𝑇ln  ( [1 − 2𝐸opt𝑘𝑇] ).                                  (4)<br><!-- End of picture text -->

A good agreement between eq. (4), as indicated by the dashed lines in Figure 5a, and the full simulation is indeed obtained for small 𝜎s. Importantly, even in the limit of vanishing static disorder, 𝜎s →0, a voltage loss Δ𝑉OCRADof roughly 70-80 meV is expected due to non-vanishing sub-gap absorption induced by thermal broadening (manifested by 𝛼∝exp(𝐸𝑘𝑇⁄ ) in the gap). Based on the 𝐸opt and 𝜎s extracted (see **Figure S11** ) for the low-offset D:A systems PM6:Y6 (𝐸opt = 1.44 eV, 𝜎s = 42 meV), PM6:ITIC ( 𝐸opt = 1.69 eV, 𝜎s = 37 meV) and PBDB-T:EH-IDTBR ( 𝐸opt = 1.77 eV, 𝜎s = 46 meV), the radiative voltage loss induced by sub-gap absorption can be estimated. Subsequently, we find Δ𝑉OCRAD of 108 mV for PM6:Y6, 107 mV for PM6:ITIC, and 120 mV for PBDB-T:EH-IDTBR. We note that the corresponding would-be Δ𝑉OCRAD (if CT states were absent, see Fig. 4b) for PBDB-T:PC70BM is 150 mV. 

Finally, **Figure 5b** shows the corresponding effect of 𝜎s on the radiative limit of the PCE, assuming EQEmax = 1 (and ideal charge collection). Compared to the SQ limit of the PCE (indicated by black solid line), the presence of the sub-gap absorption results in a PCE peak loss of around 1.5 % for 𝜎s = 0. For 𝜎s ≠0, the radiative PCE limit is further lowered, with the PCE peak deceasing with increasing 𝜎s. Hence, to minimize Δ𝑉OCRAD, and thus maximize PCE, it is important to minimize 𝜎s. However, an unavoidable radiative loss, relative to the SQ limit, will still be present due to thermal broadening. Based on our findings, this loss is inherent to all organic solar cells, and needs to be taken into account in low offset systems where excitons dominate the sub-gap absorption. 



**Figure 5 | The radiative** 𝑽𝐎𝐂 **loss induced by sub-gap absorption and associated radiative PCE limit of low-offset D:A solar cells. a,** The radiative voltage loss Δ𝑉OCRAD as a function of the optical bandgap for varying degree of Gaussian static disorder 𝜎s, assuming the sub-gap absorption dominated by LEs as per eq. 3 (solid lines with symbols). The corresponding analytical approximation (eq. 4) is represented by the dashed lines. **b,** The corresponding radiative PCE limit based on eq. 3, assuming EQEmax = 1 and ideal charge collection, is shown (solid lines with symbols). For comparison, the SQ limit, representing the ideal case with no sub-gap absorption, is included as indicated by the black solid line. The PCE decreases with respect to the SQ limit as 𝜎s increases. The SQ limit is not expected to be reached even for vanishing 𝜎s due to the thermal broadening. 

# **Conclusion** 

In summary, we have shown that the exciton sub-gap absorption in organic semiconductors is dominated by Gaussian static disorder near the onset, while thermal broadening dominates at lower photon energies.  Furthermore, we find that for a large number of organic semiconductors, the Urbach energy in the sub-gap absorption regime dominated by thermal broadening equals the thermal energy 𝑘𝑇 within the variations caused by the optical interference. While exponential absorption tails have been previously observed mainly in non-fullerene systems, we show that this property is universal for organic semiconductors and consistent with a Gaussian density of excitonic states undergoing Boltzmann-like thermally activated optical transitions. The static disorder is shown to arise from the width of the Gaussian DOS and to broaden the absorption onset at energies close to the optical gap. Using our model for the sub-gap excitonic absorption tail, it is possible to discriminate spectral regimes dominated by static disorder (where the Urbach energy is strongly dependent on the energy) and thermal broadening (𝐸U = 𝑘𝑇), as well as to reproduce the temperature dependence of absorption coefficient due to excitons. This modified view of the sub-gap absorption coefficient in disordered organic semiconductors clarifies a longstanding debate concerning the shape of the DOS and the relevance of an Urbach description in these important and intriguing materials. Finally, we demonstrate the implications of exciton static disorder and thermal broadening on the radiative open-circuit voltage losses in organic solar cells based on low offset D:A blends. 

# **Methods** 

**Materials. PEDOT:PSS** was purchased from Heraeus. Zinc acetate dihydrate and **PCDTBT** (Poly[N9'-heptadecanyl-2,7-carbazole-alt-5,5-(4',7'-di-2-thienyl-2',1',3'-benzothiadiazole)]) were purchased from Sigma Aldrich. PC70BM ([6,6]-Phenyl-C71-butyric acid methyl ester) and **EH-IDTBR** were purchased from Solarmer (Beijing). **BQR** (benzodithiophene-quaterthiophene-rhodanine) was provided by Prof. David. J Jones (University of Melbourne). **m-MTDATA** (4,4',4''-Tris[(3-methylphenyl) phenylamino]triphenylamine) was purchased from Ossila. **IT-4F** (3,9-bis(2-methylene-((3-(1,1dicyanomethylene)-6,7-difluoro)-indanone))-5,5,11,11-tetrakis(4-hexylphenyl)-dithieno[2,3-d:2',3'd']-s-indaceno[1,2-b:5,6-b']dithiophene), **PM6** (Poly[(2,6-(4,8-bis(5-(2-ethylhexyl-3-fluoro)thiophen2-yl)-benzo[1,2-b:4,5-b']dithiophene))-alt-(5,5-(1',3'-di-2-thienyl-5',7'-bis(2-ethylhexyl)benzo[1',2'c:4',5'-c']dithiophene-4,8-dione)]), **Y6** (2,2'-((2Z,2'Z)-((12,13-bis(2-ethylhexyl)-3,9-diundecyl-12,13dihydro-[1,2,5]thiadiazolo[3,4-e]thieno[2",3'':4',5']thieno[2',3':4,5]pyrrolo[3,2g]thieno[2',3':4,5]thieno[3,2-b]indole-2,10-diyl)bis(methanylylidene))bis(5,6-difluoro-3-oxo-2,3dihydro-1H-indene-2,1-diylidene))dimalononitrile), **ITIC** (3,9-bis(2-methylene-(3-(1,1dicyanomethylene)-indanone))-5,5,11,11-tetrakis(4-hexylphenyl)-dithieno[2,3-d:2',3'-d']-sindaceno[1,2-b:5,6-b']dithiophene), **PBDB-T** (Poly[(2,6-(4,8-bis(5-(2-ethylhexyl)thiophen-2-yl)benzo[1,2-b:4,5-b']dithiophene))-alt-(5,5-(1',3'-di-2-thienyl-5',7'-bis(2-ethylhexyl)benzo[1',2'-c:4',5'c']dithiophene-4,8-dione)]) and **PTB7-Th** (Poly[4,8-bis(5-(2-ethylhexyl)thiophen-2-yl)benzo[1,2b;4,5-b']dithiophene-2,6-diyl-alt-(4-(2-ethylhexyl)-3-fluorothieno[3,4-b]thiophene-)-2-carboxylate-26-diyl)]) were purchased from Zhi-yan (Nanjing) Inc. 

**Device Fabrication** . Solar cells were fabricated with either a conventional architecture ITO/PEDOT:PSS/active layer/Ca/Al or inverted architecture ITO/ZnO/active layer/MoO3/Ag. Commercial ITO coated glass substrates from Ossila were cleaned in an aqueous solution of Alconox at 60 °C, followed by an ultrasonic bath in deionize water, acetone and isopropanol. The cleaned substrates were dried with nitrogen, followed by a UV/O3 treatment (Ossila, L2002A2-UK). For the conventional device architecture, 30 nm of PEDOT:PSS was spin-coated at 6000 rpm for 30 s onto precleaned ITO substrates and annealed at 155 °C for 15 min. As top electrode, 20 nm of calcium (Ca) and 100 nm of Aluminium (Al) were vacuum deposited at 10<sup>-6</sup> Tor defining an active area of 4 mm<sup>2</sup> . For the inverted device architecture with 30 nm of ZnO, a solution of 200 mg of zinc acetate dihydrate in 2-methoxyethanol (2 ml) and ethanolamine (56 µl) was prepared and stirred overnight under ambient conditions. The ZnO layer formed upon spin-coating the solution at 4000 rpm followed by thermal annealing at 200 °C for 60 min. As top electrode, 7 nm of MoO3 and 100 nm of Ag were vacuum deposited at 10<sup>-6</sup> Tor defining an active area of 4 mm<sup>2</sup> . 

**Devices with conventional structure.** BQR:PC70BM devices were prepared using with the conventional architecture ITO/PEDOT:PSS/BQR:PC70BM/Ca/Al. BQR and PC70BM were dissolved in toluene (24 mg/ml with the donor:acceptor ratio of 1:1) and stirred at 60 °C for 3 hours. Next, the BQR:PC70BM solution was spin-coated at 1000 rpm on the PEDOT:PSS layer to form a 100 nm thick film. 

**Devices with inverted structure. m-MTDATA:PC70BM** devices: Equimolar solutions of PC70BM and m-MTDATA in dichloromethane (DCM) with a concentration of 19.4 mmol/l were prepared. To obtain a series of solutions with different molar ratios of m-MTDATA:PC70BM (5 mol%, 1 mol%, 0.1 mol% and 0 mol% of m-MTDATA), 50 ul, 10 ul, 1 ul and 0 ul of m-MTDATA in DCM were added to 1 ml of PC70BM in DCM. The solutions were spin-coated at a spin rate of 800 rpm to get an active layer thickness of around 90 nm. **PM6:Y6** devices: PM6:Y6 was dissolved in CF solution (14 mg ml<sup>-1</sup> with 0.5 vol.% CN) with a donor:acceptor ratio of 1:1.2, and spin-coated (3000 rpm) on ZnO to form a 100 nm thick film. The casted active layers were thermally annealed at 110<sup>o</sup> C for 10 min. **PM6:ITIC** devices: PM6:ITIC was dissolved in CB solution (18 mg ml<sup>-1</sup> with 0.5 vol.% DIO) with a donor:acceptor ratio of 1:1, and spin-coated (1000 rpm) on ZnO to form a 100 nm thick film. The active layers were further treated with thermal annealing at 100<sup>o</sup> C for 10 min. **PBDB-T:EH-IDTBR** devices: PBDBT:EH-IDTBR was dissolved in CB solution (14 mg ml<sup>-1</sup> ) with a donor:acceptor ratio of 1:1, and spincoated (800 rpm) on ZnO to form a 100 nm thick film. **PBDB-T:ITIC** devices: PBDB-T:ITIC was dissolved in CB solution (14 mg ml<sup>-1</sup> with 0.5 vol.% DIO) with a donor:acceptor ratio of 1:1, and spincoated (800 rpm) on ZnO to form a 100 nm thick film. The active layers were further treated with thermal annealing at 100<sup>o</sup> C for 10 min. **PTB7-Th:ITIC** devices: PTB7-Th:ITIC was dissolved in CB solution (14 mg ml<sup>-1</sup> with 1 vol.% DIO) with a donor:acceptor ratio of 1:1.4, and spin-coated (1000 rpm) on ZnO to form a 100 nm thick film. **PBDB-T:PC70BM** devices: PBDB-T:PC70BM was dissolved in CB solution (14 mg ml<sup>-1</sup> with 3 vol.% DIO) with a donor:acceptor ratio of 1:1.4, and spin-coated (1000 rpm) on ZnO to form a 100 nm thick film. Then the as-cast films were rinsed with 80 μL of methanol at 4000 rpm for 20 s to remove the residual DIO. **PBDB-T:IT-4F** devices: PBDB-T:IT-4F was dissolved in CB solution (14 mg ml<sup>-1</sup> with 0.5 vol.% DIO) with a donor:acceptor ratio of 1:1, and spincoated (800 rpm) on ZnO to form a 100 nm thick film. The active layers were further treated with thermal annealing at 100<sup>o</sup> C for 10 min. **Neat ITIC** devices: ITIC was dissolved in chloroform solution (10 mg ml<sup>-1</sup> ) and spin-coated on ZnO (2000 rpm) to form a 70 nm thick film. **Neat IT-4F** devices: IT4F was dissolved in chloroform solution (10 mg ml<sup>-1</sup> ) and spin-coated on ZnO (2000 rpm) to form a 70 nm thick film. **Neat PBDB-T** devices: PBDB-T was dissolved in chloroform solution (10 mg ml<sup>-1</sup> ) and spin-coated on ZnO (3000 rpm) to form a 70 nm thick film. 

**EQE measurements.** A homebuilt setup including a Perkin Elmer UV/VIS/NIR spectrometer (LAMBDA 950) as a source for monochromatic light was used. The light was chopped at 273 Hz and 

directed onto the device under test (DUT). The resulting photocurrent was amplified by a low noise current amplifier (FEMTO DLPCA-200) and measured with the Stanford SR860 lock-in amplifier. To decrease the noise floor of the setup, the DUT was mounted in an electrically shielded and temperature controlled Linkam sample stage. An integration time up to 1000 seconds was used for detecting wavelengths above 1500 nm. NIST‐calibrated silicon and GaAs photodiodes from Newport were used as a calibration reference. The temperature inside the Linkam sample stage was set to -120 to 60 ⁰C by the Linkam T96 temperature controller in combination with an LNP96 liquid nitrogen pump. The commercial amorphous silicon thin film solar cell, used for temperature dependent EQE measurements, was manufactured by TRONY with the part number sc80125s-8. 

**Gaussian fits.** The EQE associated with CT states and mid-gap states were routinely fitted in accordance with the standard Marcus charge-transfer formalism. The associated EQEs are given by EQECT(𝐸) = 𝑔(𝐸, 𝐸CT, 𝜆CT, 𝑓CT) and EQEt(𝐸) = 𝑔(𝐸, 𝐸t, 𝜆t, 𝑓t) for CT and mid-gap state absorption, respectively, where 



<!-- Start of picture text -->
2<br>− 1<br>𝑔(𝐸, 𝐸𝑗, 𝜆𝑗, 𝑓𝑗) = 𝑓𝑗𝐸 −1 (4𝜋𝜆𝑗𝑘𝑇) 2<br>exp (− (𝐸𝑗 + 𝜆 4𝜆𝑗 𝑗 𝑘𝑇 −𝐸) ).                              (5)<br><!-- End of picture text -->

Here, 𝑓𝑗, 𝐸𝑗 and 𝜆𝑗 are fitting parameters. All fit parameters obtained in this work are summarized in **Table S1** . The EQEs are assumed to be related to their respective absorption coefficients as 𝛼CT(𝐸) ∝ EQECT(𝐸) and 𝛼t(𝐸) ∝EQEt(𝐸) (neglecting interference effects). 

# **Data Availability** 

The data that support the findings of this study are available from the corresponding author upon reasonable request. 

# **References** 

- (1) Zhao, W.; Li, S.; Yao, H.; Zhang, S.; Zhang, Y.; Yang, B.; Hou, J. Molecular Optimization Enables over 13% Efficiency in Organic Solar Cells. _J. Am. Chem. Soc._ **2017** , _139_ (21), 7148– 7151. https://doi.org/10.1021/jacs.7b02677. 

- (2) Jin, K.; Xiao, Z.; Ding, L. 18.69% PCE from Organic Solar Cells. _J. Semicond._ **2021** , _42_ (6), 060502. https://doi.org/10.1088/1674-4926/42/6/060502. 

- (3) Urbach, F. The Long-Wavelength Edge of Photographic Sensitivity and of the Electronic Absorption of Solids. _Phys. Rev._ **1953** , _92_ (5), 1324. https://doi.org/10.1103/PhysRev.92.1324. 

- (4) Cody, G. D.; Tiedje, T.; Abeles, B.; Brooks, B.; Goldstein, Y. Disorder and the Optical- 

Absorption Edge of Hydrogenated Amorphous Silicon. _Phys. Rev. Lett._ **1981** , _47_ (20), 1480– 1483. https://doi.org/10.1103/PhysRevLett.47.1480. 

- (5) Bonalde, I.; Medina, E.; Rodríguez, M.; Wasim, S. M.; Marín, G.; Rincón, C.; Rincón, A.; Torres, C. Urbach Tail, Disorder, and Localized Modes in Ternary Semiconductors. _Phys. Rev. B - Condens. Matter Mater. Phys._ **2004** , _69_ (19), 1–5. https://doi.org/10.1103/PhysRevB.69.195201. 

- (6) Bansal, B.; Dixit, V. K.; Venkataraman, V.; Bhat, H. L. Alloying Induced Degradation of the Absorption Edge of in As XSb1-X. _Appl. Phys. Lett._ **2007** , _90_ (10). https://doi.org/10.1063/1.2711388. 

- (7) Pankove, J. I. Absorption Edge of Impure Gallium Arsenide. _Phys. Rev._ **1965** , _140_ (6A). https://doi.org/10.1103/PhysRev.140.A2059. 

- (8) Kurik, M. V. Urbach Rule. _Phys. Status Solidi_ **1971** , _8_ (1), 9–45. https://doi.org/10.1002/pssa.2210080102. 

- (9) Grein, C. H.; John, S. Temperature Dependence of the Urbach Optical Absorption Edge: A Theory of Multiple Phonon Absorption and Emission Sidebands. _Phys. Rev. B_ **1989** , _39_ (2), 1140–1151. https://doi.org/10.1103/PhysRevB.39.1140. 

- (10)  Corkish, R.; Green, M. A. Band Edge Optical Absorption in Intrinsic Silicon: Assessment of the Indirect Transition and Disorder Models (Journal of Applied Physics (1993) 73 (3988)). _J. Appl. Phys._ **1993** , _74_ (10), 6462. https://doi.org/10.1063/1.355344. 

- (11)  Dow, J. D.; Redfield, D. Toward a Unified Theory of Urbach’s Rule and Exponential Absorption Edges. _Phys. Rev. B_ **1972** , _5_ (2), 594–610. https://doi.org/10.1017/CBO9781107415324.004. 

- (12)  Shklovskii, B. I.; Efros, A. L. _Electronic Properties of Doped Semiconductors_ ; Springer Series in Solid-State Sciences; Springer Berlin Heidelberg: Berlin, Heidelberg, 1984; Vol. 45. https://doi.org/10.1007/978-3-662-02403-4. 

- (13)  Rahimi, K.; Botiz, I.; Agumba, J. O.; Motamen, S.; Stingelin, N.; Reiter, G. Light Absorption of Poly(3-Hexylthiophene) Single Crystals. _RSC Adv._ **2014** , _4_ (22), 11121–11123. https://doi.org/10.1039/c3ra47064d. 

- (14)  Zarrabi, N.; Sandberg, O. J.; Zeiske, S.; Li, W.; Riley, D. B.; Meredith, P.; Armin, A. ChargeGenerating Mid-Gap Trap States Define the Thermodynamic Limit of Organic Photovoltaic Devices. _Nat. Commun._ **2020** , _11_ (1), 5567. https://doi.org/10.1038/s41467-020-19434-0. 

- (15)  Vandewal, K.; Tvingstedt, K.; Gadisa, A.; Inganäs, O.; Manca, J. V. Relating the Open-Circuit 

Voltage to Interface Molecular Properties of Donor:Acceptor Bulk Heterojunction Solar Cells. _Phys. Rev. B - Condens. Matter Mater. Phys._ **2010** , _81_ (12), 1–8. 

https://doi.org/10.1103/PhysRevB.81.125204. 

- (16)  Burke, T. M.; Sweetnam, S.; Vandewal, K.; Mcgehee, M. D. Beyond Langevin Recombination : How Equilibrium Between Free Carriers and Charge Transfer States Determines the Open-Circuit Voltage of Organic Solar Cells. _Adv. Energy Mater._ **2015** , _1500123_ , 1–12. https://doi.org/10.1002/aenm.201500123. 

- (17)  Kahle, F. J.; Rudnick, A.; Bässler, H.; Köhler, A. How to Interpret Absorption and Fluorescence Spectra of Charge Transfer States in an Organic Solar Cell. _Mater. Horizons_ **2018** , _5_ (5), 837–848. https://doi.org/10.1039/c8mh00564h. 

- (18)  Tvingstedt, K.; Benduhn, J.; Vandewal, K. Temperature Dependence of the Spectral LineWidth of Charge-Transfer State Emission in Organic Solar Cells; Static vs. Dynamic Disorder. _Mater. Horizons_ **2020** , _7_ (7), 1888–1900. https://doi.org/10.1039/D0MH00385A. 

- (19)  Felekidis, N.; Melianas, A.; Kemerink, M. The Role of Delocalization and Excess Energy in the Quantum Efficiency of Organic Solar Cells and the Validity of Optical Reciprocity Relations. _J. Phys. Chem. Lett._ **2020** , _11_ (9), 3563–3570. https://doi.org/10.1021/acs.jpclett.0c00945. 

- (20)  Qian, D.; Zheng, Z.; Yao, H.; Tress, W.; Hopper, T. R.; Chen, S.; Li, S.; Liu, J.; Chen, S.; Zhang, J.; Liu, X. K.; Gao, B.; Ouyang, L.; Jin, Y.; Pozina, G.; Buyanova, I. A.; Chen, W. M.; Inganäs, O.; Coropceanu, V.; Bredas, J. L.; Yan, H.; Hou, J.; Zhang, F.; Bakulin, A. A.; Gao, F. Design Rules for Minimizing Voltage Losses in High-Efficiency Organic Solar Cells. _Nat. Mater._ **2018** , _17_ (8), 703–709. https://doi.org/10.1038/s41563-018-0128-z. 

- (21)  Ran, N. A.; Love, J. A.; Takacs, C. J.; Sadhanala, A.; Beavers, J. K.; Collins, S. D.; Huang, Y.; Wang, M.; Friend, R. H.; Bazan, G. C.; Nguyen, T. Q. Harvesting the Full Potential of Photons with Organic Solar Cells. _Adv. Mater._ **2016** , _28_ (7), 1482–1488. https://doi.org/10.1002/adma.201504417. 

- (22)  Liu, S.; Yuan, J.; Deng, W.; Luo, M.; Xie, Y.; Liang, Q.; Zou, Y. High-Efficiency Organic Solar Cells with Low Non-Radiative Recombination Loss and Low Energetic Disorder. _Nat. Photonics_ **2020** , _in press_ . https://doi.org/10.1038/s41566-019-0573-5. 

- (23)  Jain, N.; Chandrasekaran, N.; Sadhanala, A.; Friend, R. H.; McNeill, C. R.; Kabra, D. Interfacial Disorder in Efficient Polymer Solar Cells: The Impact of Donor Molecular Structure and Solvent Additives. _J. Mater. Chem. A_ **2017** , _5_ (47), 24749–24757. https://doi.org/10.1039/c7ta07924a. 

- (24)  Bässler, H. Charge Transport in Disordered Organic Photoconductors a Monte Carlo Simulation Study. _Phys. Status Solidi_ **1993** , _175_ (1), 15–56. https://doi.org/10.1002/pssb.2221750102. 

- (25)  Beenken, W. J. D.; Herrmann, F.; Presselt, M.; Hoppe, H.; Shokhovets, S.; Gobsch, G.; Runge, E. Sub-Bandgap Absorption in Organic Solar Cells: Experiment and Theory. _Phys. Chem. Chem. Phys._ **2013** , _15_ (39), 16494–16502. https://doi.org/10.1039/c3cp42236d. 

- (26)  Blakesley, J. C.; Neher, D. Relationship between Energetic Disorder and Open-Circuit Voltage in Bulk Heterojunction Organic Solar Cells. _Phys. Rev. B - Condens. Matter Mater. Phys._ **2011** , _84_ (7). https://doi.org/10.1103/PhysRevB.84.075210. 

- (27)  Kaiser, C.; Zeiske, S.; Meredith, P.; Armin, A. Determining Ultralow Absorption Coefficients of Organic Semiconductors from the Sub‐Bandgap Photovoltaic External Quantum Efficiency. _Adv. Opt. Mater._ **2019** , _8_ (1), 1901542. 

   - https://doi.org/https://doi.org/10.1002/adom.201901542. 

- (28)  Armin, A.; Zarrabi, N.; Sandberg, O. J.; Kaiser, C.; Zeiske, S.; Li, W.; Meredith, P. Limitations of Charge Transfer State Parametrisation and Relevance for Non-Fullerene Acceptors. _Adv. Energy Mater._ **2020** , _in press_ . https://doi.org/10.1002/aenm202001828. 

- (29)  Armin, A.; Kassal, I.; Shaw, P. E.; Hambsch, M.; Stolterfoht, M.; Lyons, D. M.; Li, J.; Shi, Z.; Burn, P. L.; Meredith, P. Spectral Dependence of the Internal Quantum Efficiency of Organic Solar Cells: Effect of Charge Generation Pathways. _J. Am. Chem. Soc._ **2014** , _136_ (32), 11465– 11472. https://doi.org/10.1021/ja505330x. 

- (30)  Vandewal, K.; Albrecht, S.; Hoke, E. T.; Graham, K. R.; Widmer, J.; Douglas, J. D.; Schubert, M.; Mateker, W. R.; Bloking, J. T.; Burkhard, G. F.; Sellinger, A.; Frechet, J. M.; Amassian, A.; Riede, M. K.; Mcgehee, M. D.; Neher, D.; Salleo, A. Efficient Charge Generation by Relaxed Charge-Transfer States at Organic Interfaces. _Nat. Mater._ **2014** , _13_ (1), 63–68. https://doi.org/10.1038/nmat3807. 

- (31)  Kurpiers, J.; Ferron, T.; Roland, S.; Jakoby, M.; Thiede, T.; Jaiser, F.; Albrecht, S.; Janietz, S.; Collins, B. A.; Howard, I. A.; Neher, D. Probing the Pathways of Free Charge Generation in Organic Bulk Heterojunction Solar Cells. _Nat. Commun._ **2018** , _9_ (1), 1–11. https://doi.org/10.1038/s41467-018-04386-3. 

- (32)  Lee, J.; Vandewal, K.; Yost, S. R.; Bahlke, M. E.; Goris, L.; Baldo, M. A.; Manca, J. V.; Voorhis, T. Van. Charge Transfer State versus Hot Exciton Dissociation in Polymer-Fullerene Blended Solar Cells. _J. Am. Chem. Soc._ **2010** , _132_ (34), 11878–11880. https://doi.org/10.1021/ja1045742. 

- (33)  Sandberg, O. J.; Zeiske, S.; Zarrabi, N.; Meredith, P.; Armin, A. Charge Carrier Transport and Generation via Trap-Mediated Optical Release in Organic Semiconductor Devices. _Phys. Rev. Lett._ **2020** , _124_ (12), 128001. https://doi.org/10.1103/PhysRevLett.124.128001. 

- (34)  Gielen, S.; Kaiser, C.; Verstraeten, F.; Kublitski, J.; Benduhn, J.; Spoltore, D.; Verstappen, P.; Maes, W.; Meredith, P.; Armin, A.; Vandewal, K. Intrinsic Detectivity Limits of Organic Near‐Infrared Photodetectors. _Adv. Mater._ **2020** , _32_ (47), 2003818. https://doi.org/10.1002/adma.202003818. 

- (35)  Nikolis, V. C.; Mischok, A.; Siegmund, B.; Kublitski, J.; Jia, X.; Benduhn, J.; Hörmann, U.; Neher, D.; Gather, M. C.; Spoltore, D.; Vandewal, K. Strong Light-Matter Coupling for Reduced Photon Energy Losses in Organic Photovoltaics. _Nat. Commun._ **2019** , _10_ (1), 1–8. https://doi.org/10.1038/s41467-019-11717-5. 

- (36)  Göhler, C.; Saladina, M.; Wang, Y.; Spoltore, D.; Benduhn, J.; Leo, K.; Deibel, C. Temperature Dependent Charge Transfer State Absorption and Emission Reveal Dominant Role of Dynamic Disorder in Organic Solar Cells. **2021** , arXiv:2102.06071v1. 

- (37)  Searle, T. M.; Jackson, W. A. Static versus Electron-Phonon Disorder in Amorphous Si: H and Its Alloys. _Philos. Mag. B Phys. Condens. Matter; Stat. Mech. Electron. Opt. Magn. Prop._ **1989** , _60_ (2), 237–255. https://doi.org/10.1080/13642818908211192. 

- (38)  Cody, G. D. Urbach Edge of Crystalline and Amorphous Silicon: A Personal Review. _J. Non. Cryst. Solids_ **1992** , _141_ (C), 3–15. https://doi.org/10.1016/S0022-3093(05)80513-7. 

- (39)  Leblanc, F. Related Content Accurate Determination of the Urbach Energy of A- Si : H Thin Films by Correction for the Interference Effect. _Japanese J. Appl. Phys. Jpn. J. Appl. Phys_ **1994** , _33_ , 1755–1758. https://doi.org/10.1143/jjap.33.l1755. 

- (40)  Tang, J. Electron-Transfer Reactions Involving Non-Linear Spin-Boson Interactions. _Chem. Phys._ **1994** , _188_ (2–3), 143–160. https://doi.org/10.1016/0301-0104(94)00254-1. 

- (41)  Casado-pascual, J.; Morillo, M.; Goychuk, I.; Hänggi, P.; Morillo, M. The Role of Different Reorganization Energies within the Zusman Theory of Electron Transfer The Role of Different Reorganization Energies within the Zusman Theory of Electron Transfer. _J. Chem. Phys._ **2003** , _118_ (1), 291. https://doi.org/10.1063/1.1525799. 

- (42)  Keil, T. H. Theory of the Urbach Rule. _Phys. Rev._ **1966** , _144_ (2), 582–587. https://doi.org/10.1103/PhysRev.144.582. 

- (43)  Hood, S.; Zarrabi, N.; Meredith, P.; Kassal, I.; Armin, A. Measuring Energetic Disorder in Organic Semiconductors Using the Photogenerated Charge-Separation Efficiency. _J. Phys._ 

_Chem. Lett._ **2019** , _10_ (14), 3863–3870. https://doi.org/10.1021/acs.jpclett.9b01304. 

- (44)  Miller, A.; Abrahams, E. Impurity Conduction at Low Concentrations. _Phys. Rev._ **1960** , _120_ (3), 745–755. https://doi.org/10.1103/PhysRev.120.745. 

- (45)  Cui, Y.; Yao, H.; Zhang, J.; Xian, K.; Zhang, T.; Hong, L.; Wang, Y.; Xu, Y.; Ma, K.; An, C.; He, C.; Wei, Z.; Gao, F.; Hou, J. Single-Junction Organic Photovoltaic Cells with Approaching 18% Efficiency. _Adv. Mater._ **2020** , _32_ (19), 1–7. https://doi.org/10.1002/adma.201908205. 

- (46)  Song, B.; Rolin, C.; Zimmerman, J. D.; Forrest, S. R. Effect of Mixed Layer Crystallinity on the Performance of Mixed Heterojunction Organic Photovoltaic Cells. _Adv. Mater._ **2014** , _26_ (18), 2914–2918. https://doi.org/10.1002/adma.201305099. 

- (47)  Venkateshvaran, D.; Nikolka, M.; Sadhanala, A.; Lemaur, V.; Zelazny, M.; Kepa, M.; Hurhangee, M.; Kronemeijer, A. J.; Pecunia, V.; Nasrallah, I.; Romanov, I.; Broch, K.; McCulloch, I.; Emin, D.; Olivier, Y.; Cornil, J.; Beljonne, D.; Sirringhaus, H. Approaching Disorder-Free Transport in High-Mobility Conjugated Polymers. _Nature_ **2014** , _515_ (7527), 384–388. https://doi.org/10.1038/nature13854. 

- (48)  Shockley, W.; Queisser, H. J. Detailed Balance Limit of Efficiency of P-n Junction Solar Cells. _J. Appl. Phys._ **1961** , _32_ (3), 510–519. https://doi.org/10.1063/1.1736034. 

# **Acknowledgements** 

This work was funded through the Welsh Government’s Sêr Cymru II Program ‘Sustainable Advanced Materials’ (Welsh European Funding Office − European Regional Development Fund). C.K. is recipient of a UKRI EPSRC Doctoral Training Program studentship. N.Z. is funded by a studentship through the Sêr Cymru II Program. P.M. is a Sêr Cymru II Research Chair and A.A. is a Rising Star Fellow also funded through the Welsh Government’s Sêr Cymru II ‘Sustainable Advanced Materials’ Program (European Regional Development Fund, Welsh European Funding Office and Swansea University Strategic Initiative). 

# **Author Contributions** 

AA and PM provided the overall leadership of the project. OJS and AA conceptualised the idea. CK and AA designed the experiments. CK performed most measurements, analysed the data, performed optical modelling and drafted the manuscript. OJS developed the theoretical model. CK, OJS and AA interpreted the data. NZ assisted with EQEPV measurements. WL fabricated the devices. All co-authors contributed in the development of the manuscript which was initially drafted by CK. 

# **Additional information** 

**Supplementary Information** 

**Competing interests:** The authors declare no competing interests. 

