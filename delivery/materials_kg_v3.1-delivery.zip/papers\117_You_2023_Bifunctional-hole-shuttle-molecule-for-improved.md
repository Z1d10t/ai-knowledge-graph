# Bifunctional hole-shuttle molecule for improved interfacial energy level alignment and defect passivation in perovskite solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Energy |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 212 |
| 作者 | Shuai You, F. Eickemeyer, Jing Gao, J. Yum, Xin Zheng, Dan Ren, Meng Xia, Rui Guo et al. |
| DOI | 10.1038/s41560-023-01249-0 |
| 源文件 | 017_You_2023_Bifunctional-hole-shuttle-molecule-for-improved.pdf |

---
## **nature energy** 

#### **Article** 

https://doi.org/10.1038/s41560-023-01249-0 

# **Bifunctional hole-shuttle molecule for improved interfacial energy level alignment and defect passivation in perovskite solar cells** 

Received: 16 August 2022 **Shuai You**<sup>**1,2,4**</sup> **, Felix T. Eickemeyer**<sup>**2,4**</sup> **, Jing Gao**<sup>**2**</sup> **, Jun-Ho Yum**<sup>**3**</sup> **, Xin Zheng**<sup>**1**</sup> **, Dan Ren**<sup>**2**</sup> **, Meng Xia**<sup>**2**</sup> **, Rui Guo**<sup>**1**</sup> **, Yaoguang Rong**<sup>**1**</sup> **, Shaik M. Zakeeruddin**<sup>**2**</sup> **,** Accepted: 13 March 2023 **Kevin Sivula**<sup>**3**</sup> **, Jiang Tang**<sup>**1**</sup> **, Zhongjin Shen**<sup>**2**</sup> **, Xiong Li**<sup>**1**</sup> Published online: 17 April 2023 **& Michael Grätzel**<sup>**2**</sup> Check for updates 

Perovskite solar cells have reached a power conversion efficiency over 25%, and the engineering of the interface between the perovskite and hole transport layer (HTL) has been crucial to achieve high performance. Here we design a bifunctional molecule CBz-PAI with carbazole-triphenylamine a nd p he nylammonium iodide units to passivate defects at the perovskite/ HTL interface. Owing to a favourable energy level alignment with the perovskite, the CBz-PAI acts as a hole shuttle between the perovskite layer and the HTL. This minimizes the difference between the quasi-Fermi level splitting of the perovskite, or ‘internal’ _V_ oc, and the external device _V_ oc, thus reducing voltage losses. As a result, solar cells incorporating CBz-PAI reach a stabilized power conversion efficiency of 24.7% and maintain 92.3% of the initial efficiency after 1,000 h under damp heat test (85 °C and 85% relative humidity) and 94.6% after 1,100 h under maximum power point-tracking conditions. 

Perovskite solar cells (PSCs) based on mixed organic–inorganic halide perovskite, delivering higher energy conversion efficiency with lower processing costs, have been served as a promising electricity generation technology<sup>1–12</sup> . The past decade has witnessed a rapid increase of power conversion efficiency (PCE) over 25% (refs. 13–15). Efficient charge extraction and low non-radiative recombination at the interface between the perovskite material and hole transport layer (HTL) are key for achieving excellent photovoltaic (PV) performance<sup>16–23</sup> . 

Passivation of defects especially at the perovskite/HTL interface has become a crucial method for reducing non-radiative charge carrier 

recombination inside PSC devices<sup>24</sup> . In addition, interfacial passivation layers have been recently reported to be able to improve the stability of PSCs due to their resistance against moisture and thermal stress<sup>25–27</sup> . For example, phenethylammonium iodide (PEAI) and octylammonium iodide (OAI) are widely used interfacial modulators for PSCs, reducing defect-assisted non-radiative recombination and improving device stability<sup>14,28,29</sup> . However, such interfacial layers are generally disordered and exhibit poor charge transport properties due to unfavourable energy level matching, impairing hole extraction<sup>30–32</sup> . There have been efforts to introduce interface modulators exhibiting good energy 

> 1Michael Grätzel Center for Mesoscopic Solar Cells, Wuhan National Laboratory for Optoelectronics, Huazhong University of Science and Technology, Wuhan, China.<sup>2</sup> Laboratory of Photonics and Interfaces, Institute of Chemical Sciences and Engineering, École Polytechnique Fédérale de Lausanne (EPFL), Lausanne, Switzerland.<sup>3</sup> Laboratory for Molecular Engineering of Optoelectronic Nanomaterials, Institute of Chemical Sciences and Engineering, École Polytechnique Fédérale de Lausanne (EPFL), Lausanne, Switzerland.<sup>4</sup> These authors contributed equally: Shuai You, Felix T. Eickemeyer. e-mail: zhongjin.shen@epfl.ch; xiongli@hust.edu.cn; michael.graetzel@epfl.ch 

Nature Energy | Volume 8 | May 2023 | 515–525 

**515** 

**Article** 

https://doi.org/10.1038/s41560-023-01249-0 

level alignment with the perovskite layer to improve charge transfer<sup>20,33–35</sup> ; however, device performances of these works are far from state-of-the-art. Recently, two-dimensional (2D) layered perovskites based on bulky cations applied to the surface of three-dimensional (3D) perovskite thin films to generate 2D/3D heterojunction with better band alignment have attracted considerable attention, and a significant improvement in device performance has been shown<sup>22,36</sup> . Energy level misalignment between the perovskite absorber layer and HTL layers causes a voltage loss due to enhanced radiationless charge carrier recombination at the interface between the two layers. In the presence of such a valence band offset, the hole concentration in the HTM has to be raised to a higher level to match the quasi-Fermi level in the two layers than in the absence of band misalignment. This in turn accelerates radiationless carrier recombination causing an additional voltage loss. This _V_ oc loss can be avoided for example by introducing a layer of molecular dipoles between the perovskite and the HTM that compensates the valence band offset<sup>37</sup> . 

Furthermore, perovskites based on organic–inorganic hybrids are hydrophilic materials while the widely used HTLs (such as spiro-OMeTAD) are hydrophobic. This causes poor wetting of the perovskite by the HTL layer, which results in further parasitic resistive losses in PSC devices<sup>38,39</sup> . These limitations prompted us to develop a molecularly tailored interface layer with two functions, a good interface passivation to minimize non-radiative recombination and one allowing for a barrier-free hole transfer into the HTL, and to investigate its beneficial effects in depth. 

In this Article, we judiciously designed and synthesized a bifunctional organic molecule, 4-(3,6-bis(4-(bis(4-methoxyphenyl)amino) phenyl)-9 _H_ -carbazol-9-yl)benzenaminium iodide (CBz-PAI) containing carbazole-triphenylamine (CBz) and phenylammonium iodide (PAI) moieties (Fig. 1a). The PAI unit acts as an effective defect passivator, whereas the conjugated structure of methoxy-substituted triphenylamine that is highly compatible with the spiro-OMeTAD layer enables excellent hole transfer or hole shuttling from the perovskite into the HTL layer. Since the HOMO energy level is well adjusted by the conjugated structure of CBz unit, CBz-PAI shows a very small valence band edge/HOMO energy level misalignment of 40 meV with the perovskite layer, voltage losses are minimized and the efficient hole shuttling mechanism leads to a lower series resistance. The mechanism behind these minimized voltage losses due to this energy level alignment is revealed in this work by a detailed optoelectronic device characterization corroborated by drift-diffusion simulations. Due to the bifunctionality, the PSC device achieved a PCE of 24.7% under simulated air mass (AM) 1.5G illumination. Notably, non-encapsulated CBz-PAI-based PSC device exhibited an excellent long-term stability, with 94.6% of the initial PCE being retained after 1,100 h measurement under maximum power point (MPP) tracking condition. 

### **Selection of CBz-PAI** 

As depicted in Fig. 1a and Supplementary Fig. 1, the synthesis of CBz-PAI started from Suzuki reaction of 3,6-dibromo-9 _H_ -carbazole and (4-(bis(4-methoxyphenyl)amino)phenyl)boronic acid affords compound 1. Then the Buchwald–Hartwig reaction of compound 1 and 1-fluoro-4-nitrobenzene was employed to yield compound 2, followed by being reduced by stannous chloride dihydrate to get compound 3. Subsequently, acidification of compound 3 with hydriodic acid was performed to achieve the final compound CBz-PAI. All the key intermediates and the final compound CBz-PAI were characterized by 1H nuclear magnetic resonance (NMR), 13C NMR and high-resolution mass spectrometry (Supplementary Figs. 2–13). The size of the CBz-PAI molecule was also calculated to be 28.865 Å (Supplementary Fig. 14). 

The ultraviolet–visible (UV–Vis) absorption of CBz-PAI, PbI2 and CBz-PAI/PbI2 (molar ratio 2:1) was characterized to investigate the interaction between PbI2 and CBz-PAI (Fig. 1b). The absorption of PbI2 dramatically changes after mixing with CBz-PAI, which indicates a 

strong interaction between CBz-PAI and PbI2. Moreover, the colour of PbI2 film transforms from yellow to transparent pale yellow (inset of Fig. 1b). In addition, the<sup>1</sup> H NMR spectrum of CBz-PAI has changed after mixing with PbI2 (Supplementary Fig. 15), confirming the interaction between CBz-PAI and PbI2. Cyclic voltammetry (CV) measurement of CBz-PAI with ferrocene as the reference shows the highest occupied molecular orbital (HOMO) level of −5.36 eV against vacuum (Fig. 1c). Then the lowest unoccupied molecular orbital (LUMO) level of CBz-PAI is calculated to be −2.26 eV based on its bandgap of 3.10 eV. As seen in the energy level diagram (Fig. 1d), the valence band offset between CBz-PAI and perovskite (−5.40 eV) generates a driving force of 40 meV for hole transfer from perovskite to CBz-PAI. Generally, the deep HOMO energy level of −5.36 eV allows for a favourable band alignment with the perovskite, which might minimize voltage loss of the resulted device. In addition, the good compatibility of CBz-PAI and HTL suggests an efficient hole transport from CBz-PAI to HTL layer, which we will discuss in greater detail later. 

### **Film properties** 

To further disclose the optical and electronic properties of perovskite film with and without CBz-PAI, scanning electron microscopy (SEM) was applied to investigate the effect of CBz-PAI on the morphology of perovskite film (Fig. 2a,b). Surprisingly, the average domain size of the perovskite increases from 750 nm to 1,260 nm after being treated by CBz-PAI (Supplementary Fig. 16). The formation of larger domain could be attributed to the interaction between CBz-PAI with excess PbI2 at the perovskite surface (dotted circle in Fig. 2a), where CBz-PAI may act as a ‘coalescer’ at the perovskite surface<sup>29</sup> . Elemental mapping of the CBz-PAI-treated perovskite film demonstrates the existence of carbon and oxygen on the perovskite surface (Supplementary Figs. 17 and 18), confirming the incorporation of CBz-PAI overlayer. The optical properties of perovskite films were also characterized by UV–Vis absorption spectroscopy (Supplementary Fig. 19). As expected, the CBz-PAI-treated perovskite film shows a similar absorption spectrum as the pristine perovskite film<sup>40</sup> . In addition, we measured the optical bandgap by UV–Vis spectroscopy and the first derivative of external quantum efficiency (EQE), being 1.512 eV and 1.526 eV (Supplementary Fig. 20), respectively. The bandgap determined from EQE is usually 10–20 meV lower than that determined from UV–Vis spectra<sup>41</sup> , which is in good agreement with our results. 

To further investigate the structural characteristics of the perovskite films with and without CBz-PAI treatment, synchrotron-based grazing-incidence X-ray diffraction (GIXRD) was performed (Fig. 2c,d). The GIXRD does not provide evidence for a 2D structure and only supports the notion that there is a reaction between CBz-PAI and PbI2 which removes PbI2 at the interface. This result is consistent with the phenomenon we observed in the SEM measurement (Fig. 2a,b). 

Kelvin probe force microscopy (KPFM) was employed to evaluate the difference in the surface potential of the perovskite films (Fig. 2e–g), which is associated with the work function with respect to the vacuum energy level. The KPFM image of the pristine perovskite film shows notable dark areas inside individual grains indicating a heterogeneous surface potential distribution (Fig. 2e), while the perovskite film treated by CBz-PAI presented a more evenly distributed surface potential (Fig. 2f). This difference may be ascribed to the partial elimination of subgap defect states. The work functions of the perovskite films are further determined by the contact potential difference (CPD) between the Pt-coated conductive cantilever probe and the samples. The perovskite film with CBz-PAI treatment showed an average CPD of −63.1 mV (Fig. 2f), which is 51.2 mV lower than that of perovskite film without CBz-PAI coating (Fig. 2e). This downward shift indicates a more positive surface charging that is caused by a hole transfer from the perovskite valence band into the CBz-PAI HOMO level. Such a hole transfer is energetically favoured as discussed above since the CBz-PAI HOMO level is 40 meV higher than the perovskite valence band edge. 

Nature Energy | Volume 8 | May 2023 | 515–525 

**516** 

**Article** 

https://doi.org/10.1038/s41560-023-01249-0 



<!-- Start of picture text -->
a O O O O O<br>N B(OH)2 N N O N N O<br>Br Br O F NO2 O<br>O<br>HN Pd(PPh3)4 K2CO3 THF N K2CO3 DMF N<br>H<br>1<br>NO2<br>O O O O 2<br>N N O N N O HTL unit<br>O O<br>SnCl2 . 2H2O HI<br>EtOH THF N THF N<br>Chemical etching unit<br>NH2 NH+ 3 I–<br>3 CBz-PAI<br>–2.03<br>b c d<br>–2.26<br>CBz-PAI/PbI2 6 CBz-PAI<br>CBz-PAI<br>4<br>PbI2<br>2<br>–3.92<br>0<br>–2<br>PbI2 CBz-PAI/PbI2<br>–4 –4.97<br>300 400 500 600 700 800 0 0.1 0.2 0.3 0.4 0.5<br>–5.40 –5.36<br>Wavelength (nm) Potential,  V  versus Fc + /Fc<br>A)Current (µ CBz-PAI Spiro-OMeTAD<br>Energy level (eV)<br>Normalized absorption<br>Perovskite<br><!-- End of picture text -->

**Fig. 1 | Synthesis and characterization of CBz-PAI molecule. a** , Synthetic route of CBz-PAI. **b** , The UV–Vis absorption spectra of PbI2, CBz-PAI and CBz-PAI/PbI2 with molar ratio 2:1. The inset shows a digital image of PbI2 film, CBz-PAI/PbI2 film. **c** , CV of CBz-PAI in acetonitrile with 0.1 M LiTFSI ( _E_<sup>Fc</sup> HOMO<sup>= −5.13 V versus vacuum).</sup> 

**d** , Energy level diagram. The levels for perovskite (FAPbI3) and spiro-OMeTAD were taken from literature<sup>49</sup> ; the ones for CBz-PAI were determined from CV shown in **c** . 

Note that in a full device with HTM there is no positive charging of the CBz-PAI interface layer; due to a 390 meV higher HOMO level of the HTM (Fig. 1d), a charge transfer from the CBz-PAI layer into the HTM is energetically favoured. Thus, the increase in device _V_ oc, which will be discussed later, is not directly related to the change in surface potential. 

Absolute intensity photoluminescence (AIPL) measurements were performed to determine the photoluminescence quantum yield (PLQY) to study the effect of CBz-PAI on the optoelectronic quality of the perovskite films (Figs. 2h,i). Five samples were prepared for both control and perovskite/CBz-PAI conditions. The average PLQY of the control sample is 6%, whereas the average PLQY of perovskite/CBz-PAI is 16%, illustrating significant reduction of non-radiative recombination of the CBz-PAI treated compared with the pristine perovskite film. This shows that CBz-PAI acts as a defect passivation agent. 

### **Device performance** 

The target device configuration used in this study is based on the architecture shown in Fig. 3a. In the following we denote the device with CBz-PAI as the target device. For the control device we use PEAI as passivation layer. We also made devices without interface passivation layer and with OAI as modulator; however, a statistical analysis revealed that for our device recipe PEAI yielded the highest device performance 

(Supplementary Figs. 21 and 22). Different concentrations of CBz-PAI were used to optimize the PV performance of PSC devices; for PEAI we used the established recipe<sup>28</sup> . Current density–voltage ( _J–V_ ) curves for different CBz-PAI concentrations are shown in Supplementary Fig. 23, and the PV parameters are summarized in Supplementary Table 1. The CBz-PAI-treated cell with a concentration of 5.04 mM achieves the highest PCE of 24.7% using the anti-reflection coating (Fig. 3b), with a short-circuit current density ( _J_ sc) of 26.1 mA cm<sup>−2</sup> , an open-circuit voltage ( _V_ oc) of 1,161 mV and a fill factor (FF) of 81.6% (Table 1). The comparison of the PV performance with and without anti-reflection coating and the transmittance of the AR coating are shown in Supplementary Fig. 24. In contrast, the PCE of the control PSC device is 22.3% (Fig. 3b), with a _J_ sc of 25.9 mA cm<sup>−2</sup> , a _V_ oc of 1,112 mV and an FF of 77.6%. 

In addition, the device based on the perovskite/CBz-PAI/HTL delivered a negligible hysteresis of 0.4% (Supplementary Fig. 25 and Supplementary Table 2), which is lower than that of the control device (2.8%). Figure 3c shows steady-state MPP measurements of the champion devices for 500 s. The stabilized PCEs of the control device and the device with CBz-PAI are 22.1% and 24.5%, respectively, which are consistent with the ones obtained from the _J–V_ measurement (Fig. 3b). Incident photon to electron conversion efficiency (IPCE) spectra of devices are shown in Fig. 3d. The integrated current densities of the 

Nature Energy | Volume 8 | May 2023 | 515–525 

**517** 

**Article** 

https://doi.org/10.1038/s41560-023-01249-0 



<!-- Start of picture text -->
a c e mV<br>2.2 (012) 800 3.10<br>2 (002) 700<br>1.8<br>(111) 600<br>1.6<br>1.4 (011) 500<br>1.2 (001) 400 –11.9<br>1<br>300<br>0.8 PbI2<br>0.6 200<br>0.4<br>Control 500 nm 0.2 Control 100 Control 2 µm –26.9<br>–1.5 –1 –0.5 0 0.5 1 1.5<br>qx,y  nm –1<br>b d 2.2 (012) 800 f –mV48.1<br>2 (002) 700<br>1.8<br>(111) 600<br>1.6<br>1.4 (011) 500<br>1.2 (001) 400 –63.1<br>1<br>300<br>0.8<br>0.6 200<br>0.4<br>Target 500 nm 0.2 Target 100 Target<br>2 µm –78.1<br>–1.5 –1 –0.5 0 0.5 1 1.5<br>qx,y  nm –1<br>g h 4.0 i<br>20 Control Control Control<br>Target Target 20 Target<br>0 3.0<br>–20<br>2.0<br>10<br>–40<br>1.0<br>–60<br>–80 0 0<br>0 2 4 6 8 10 700 750 800 850 900 950 Control Target<br>Distance (µm) Wavelength (nm)<br>–1 q  nm z<br>Intensity (a.u.)<br>–1 q  nm z<br>Intensity (a.u.)<br>PLQY (%)<br>Potential (mV)<br>218Photon flux (1/(s mnm)) × 10<br><!-- End of picture text -->

**Fig. 2 | Characterization of the FAPbI3 perovskite films with (target) and without (control) CBz-PAI treatment. a** , **b** , Top view SEM images of perovskite thin films without CBz-PAI ( **a** ) and with CBz-PAI ( **b** ); scale bars, 500 nm ( **a** and **b** ). The dotted circles represent PbI2 at the perovskite surface. **c** , **d** , GIXRD patterns of perovskite layers without CBz-PAI ( **c** ) and with CBz-PAI ( **d** ). **e** , **f** , CPD analysis of ITO substrate supported perovskite films without CBz-PAI ( **e** ) and with CBz-PAI 

( **f** ). **g** , CPD variations of the perovskite and perovskite/CBz-PAI films along the white dotted line across the KPFM images shown in **e** and **f** . **h** , **i** , AIPL spectra ( **h** ) and PLQY ( **i** ) of treated and untreated perovskite films on glass (five individual samples were used for the measurement). The centre line represents the median value, the bounds of box indicate upper and lower quartiles and the whiskers represent the minimum and maximum values. 

control and target cells are 25.5 and 25.8 mA cm<sup>−2</sup> (Supplementary Fig. 26), respectively, which are also in good agreement with the _J-V_ measurements (Fig. 3b). Furthermore, a statistical analysis of the PV parameters of 20 devices was carried out (Fig. 3e and Supplementary Fig. 21). CBz-PAI-based PSCs deliver an average PCE of 24.2%, while the control cells show an average PCE of 21.9%. The devices with CBz-PAI overlayer delivered an enhanced _V_ oc, FF and PCE. In addition, the ideality factor ( _n_ id) of the control and target devices was calculated from the dependence of _V_ oc on the illumination intensity (Fig. 3f). The _n_ id decreased slightly from 1.4 to 1.3 after introducing the CBz-PAI layer between perovskite and HTL, indicating a very small decrease of trap-assisted non-radiative recombination. 

### **Optoelectronic characterization** 

In the following we quantitatively elaborate the mechanisms behind the _V_ oc and the FF increase. We measured PLQY of complete CBz-PAI passivated (control) and PEAI passivated (target) devices, which are 

shown in Fig. 4a. The PLQY is 1.8% for the control device and 1.9% for the target device. Note that CBz-PAI treatment of the bare perovskite film leads to a significant PLQY increase (Fig. 2i) compared with the untreated perovskite films on glass without HTL, which shows the passivation effect of this treatment. Here we compare complete cells (that is, with electron transport layer (ETL) and HTL) of CBz-PAI-treated perovskite films (target) with PEAI-treated perovskite films (control). The PLQY difference is very small and indicates that the defect passivation effect is only slightly better with CBz-PAI as compared with PEAI, which is in good agreement with the small difference of the solar cell ideality factors shown above (Fig. 3f). In addition, we observe a lower statistical fluctuation of the PLQY values for the CBz-PAI sample, which indicates a better device reproducibility with the interface passivation. From PLQY we can determine the voltage loss due to non-radiative recombination and the quasi-Fermi level splitting ∆ _E_ F as described in detail in Supplementary Information (Supplementary Note 1). In Fig. 4b we show ∆ _E_ F/ _q_ , where _q_ is the elementary charge, and the measured 

Nature Energy | Volume 8 | May 2023 | 515–525 

**518** 

**Article** 

https://doi.org/10.1038/s41560-023-01249-0 



<!-- Start of picture text -->
a b c<br>Au<br>PCE 24.5%<br>25 25<br>HTL<br>20 20 PCE 22.1%<br>CBz-PAI<br>15 15<br>Perovskite 10 10<br>5 Control 5 Control<br>Target Target<br>FTO/SnO2<br>0 0<br>0 0.2 0.4 0.6 0.8 1.0 1.2 0 100 200 300 400 500<br>Voltage (V) Time (s)<br>d e f 1.20<br>100 25 15 Control<br>Target<br>80 20 12 1.15 1.3  KT/q<br>60 15<br>9<br>1.10<br>40 10<br>6 1.4  KT/q<br>20 Control 5 3 1.05 Control<br>Target Target<br>0 0<br>0 1.00<br>400 500 600 700 800 900 20 21 22 23 24 25 10 100<br>Wavelength (nm) PCE (%) Light intensity (mW cm –2 )<br>–2)Current density (mA cm Stabilized efficiency (%)<br>EQE (%) Count  (V) V OC<br>Integrated current (mA cm)–2<br><!-- End of picture text -->

**Fig. 3 | PV performance of the control and target PSCs.** The control devices use PEAI and the target devices CBz-PAI as interface passivator. **a** , An illustration of the device architecture of the target PSCs. **b** , _J_ – _V_ curves of the control and target PSCs devices measured under reverse scan direction. The comparison of forward and reverse scans are shown in Supplementary Fig. 21. **c** , The stabilized maximum power output of the control and target PSCs devices. **d** , IPCE spectrum 

and integrated current of the control and target PSCs devices. **e** , Histogram of average PCE values of the control and target devices. **f** , Light intensity dependence of _V_ OC. The ideality factor _n_ id is calculated from the slope of the linear fit of the semilogarithmic plot. _q_ , electron charge; _K_ , Boltzmann constant; _T_ , Kelvin temperature. 

**Table 1 | PV parameters of the best-performed control and target devices under 1 sun illumination (AM 1.5 G, 100 mW cm**<sup>**−2**</sup> **)** 

|**Sample**|**_V_oc (V)**|**_J_sc (mA cm**<sup>**−2**</sup>**)**|**FF (%)**|**PCE (%)**|
|---|---|---|---|---|
|Control|1.112|25.9|77.6|22.3|
|Target|1.161|26.1|81.6|24.7|



steady-state _V_ oc of the same devices. _V_ oc of the target device increases by 40 mV; however ∆ _E_ F/ _q_ of the same device increases only 10 mV. Thus, the _V_ oc increase cannot be explained by a reduction in non-radiative recombination alone. To understand the reason behind the _V_ oc increase, we have to consider all factors determining _V_ oc. The quasi-Fermi level splitting is the ‘internal’ _V_ oc of the absorber layer, that is, the maximum _V_ oc a solar cell with this absorber can attain if there are no additional _V_ oc losses. An additional _V_ oc loss comes from energy level misalignments between the valence bands of the HTL and perovskite in combination with interfacial non-radiative recombination<sup>42</sup> . In Fig. 1d we see that the spiro-OMeTAD HTL shows a large valence band edge/HOMO energy level misalignment of 430 meV whereas CBz-PAI has a HOMO level only 40 meV above the perovskite valence band edge. During device operation under illumination, holes are injected from the perovskite layer into the CBz-PAI layer before they reach the spiro-OMeTAD HTL. On the other hand, electron injection into CBz-PAI is blocked due to the significantly higher conduction band edge energy (Fig. 1d). Therefore, the main interfacial electron-hole recombination happens at the perovskite/ CBz-PAI interface where the valence band edge/HOMO level mismatch is very small. This suggests that _V_ oc losses at this interface are much lower than at the perovskite/spiro-OMeTAD interface. In the control device, hole injection into the PEAI interface passivation layer is impeded since 

the PEAI HOMO level is 50 meV below the perovskite valence band (Supplementary Fig. 27). Therefore, hole injection is only possible directly (for example via pinholes) or via tunnelling into the spiro-OMeTAD layer with a very large energy level offset. Thus, in this case a larger _V_ oc loss compared with the CBz-PAI-based solar cell is expected. To corroborate this, we performed simulations using the drift-diffusion solver Solar Cell Capacitance Simulator (SCAPS) (for more details, see Supplementary Information), which are shown in Fig. 4c). For the control and target devices we used the same simulation parameters (Supplementary Table 3) except for a 1 Ω cm<sup>2</sup> higher series resistance for the control device, which will be discussed in detail later. In particular we used the same interface recombination velocity at the interface perovskite/CBz-PAI (target) and perovskite/spiro-OMeTAD (control). More details on the simulations can be found in Supplementary Information (Supplementary Note 1b). The inset of Fig. 4c shows the quasi-Fermi levels for electrons ( _F_ n) and holes ( _F_ p) at _V_ oc. Calibrating the absolute energy so that _F_ n in the ETL is the same for control and target, we see that the main difference is observed in the shape and position of _F_ p. The control device shows an upward bending of Fp at the HTM/perovskite interface. This is caused by a strong hole accumulation within the HTM and electron accumulation in the perovskite layer at the HTM/perovskite interface due to the large valence band energy misalignment (for more details, see Supplementary Fig. 28). Such a carrier accumulation leads to a strong enhancement in non-radiative recombination at the HTM/perovskite interface compared to the target device where such a carrier accumulation does not appear even if the recombination velocities are the same. The resulting simulated _J–V_ characteristics match well the measured _J–V_ curves. This shows that the main contribution of the _V_ oc increase upon CBz-PAI treatment in comparison with PEAI treatment comes from the improved energy level alignment of the passivator molecule and not from an improved defect passivation effect. This is in contrast with most of the findings 

Nature Energy | Volume 8 | May 2023 | 515–525 

**519** 

**Article** 

https://doi.org/10.1038/s41560-023-01249-0 



<!-- Start of picture text -->
a b 1.15<br>4<br>Loss<br>1.14<br>3<br>1.13<br>Loss<br>2<br>1.12<br>1 1.11<br>0 1.10<br>Control Target V oc ∆ E F/ q V oc ∆ E F/ q<br>control target<br>c 30 d 1.1<br>Control 1<br>Target 1<br>25 0.9<br>0.8 0.1<br>20 1.12 HTM Perovskite ETL 0.7<br>15 F n(control/target) 0.6 0.01<br>0 F p(control) 0 100 200<br>Gain 0.5<br>10 –0.04<br>F p(target)<br>0.4<br>5 0.2 0.4 0.6 0.8 Control<br>Distance (µm)<br>0 Target<br>0.3<br>0 0.2 0.4 0.6 0.8 1.0 1.2 0 1 2 3 4 5<br>Voltage (V) Delay time (ns)<br>PLQY (%) Voltage (V)<br>Energy (eV)<br>–2)Current density (mA cm PL inensity (normalized)<br><!-- End of picture text -->

**Fig. 4 | Optoelectronic characterization.** The control samples use PEAI and the target samples CBz-PAI as interface passivator. **a** , PLQY of complete devices (five individual samples were used; the measurement was done outside the Au contact layer). The centre line represents the median value, the bounds of box indicate upper and lower quartiles and the whiskers represent the minimum and maximum values. **b** , Stabilized _V_ OC and quasi-Fermi level splitting Δ _E_ F/ _q_ for the 

control and target devices. **c** , SCAPS simulation of a control and target device. The circles indicate the measured _J_ – _V_ curves shown also in Fig. 3b), the solid lines are the simulated curves. The inset shows the Fermi levels of the electrons ( _F_ n) and of the holes ( _F_ p) at _V_ oc. **d** , TRPL measurements of glass/perovskite/interface passivation/HTL samples. The inset shows the TRPL traces on a timescale of several hundreds of nanoseconds. The error bands indicate standard deviation. 

in literature where a _V_ oc increase caused by a passivator is assigned to a reduction of non-radiative recombination. To the best of our knowledge, the mechanism of energy level alignment of a passivator and its effect of increasing _V_ oc is demonstrated and rigorously proven, and thus, our interface layer technique represents an important concept to improve device performance of PSCs. 

The FF losses in high-performing PSCs with high carrier mobilities are determined by two main factors, non-radiative recombination and series resistance<sup>43</sup> . To quantify these losses, we performed _J_ sc– _V_ oc measurements, which is a standard technique to determine the series resistance of solar cell devices<sup>44–46</sup> . We performed _J_ sc– _V_ oc measurements with two control and two target devices. In Supplementary Fig. 29, we show the transport limit _J–V_ curves determined from the _J_ sc– _V_ oc measurements (details are presented in Supplementary Note 2) and the radiative limit _J–V_ curves of the control and target devices. In addition, we plot the steady-state maximum power point (ss-MPP) measurements. The radiative limit _J–V_ curves were determined using the ideal single-diode approximation with the radiative limit of _V_ oc = 1.249 V (details are presented in Supplementary Note 1), the measured average _J_ sc (25.1 mA cm<sup>−2</sup> ) and an ideality factor of 1. The performance parameters of these curves determined from measurements of the two control devices with PEAI and the two target devices with CBz-PAI are recorded in Supplementary Table 4. The FF of the _J_ sc– _V_ oc curve for control and target devices are similar, about 5%abs lower than the radiative limit FF. This FF loss can be attributed to non-radiative recombination. The fact that the FF of the target devices are very similar to the control ones is in good agreement with the similar non-radiative recombination that has been shown by the device ideality factor and the PLQY measurements as discussed above (Figs. 3f and 4a). The FFs determined from the steady-state MPP measurements are 73.5% for control and 76.7% for the 

target devices, that is, 11%abs and 8%abs lower than the ones determined from the _J_ sc _–V_ oc curve. This additional FF loss can be attributed to the series resistance _R_ s, which is 5 Ω cm<sup>2</sup> for the control and 4 Ω cm<sup>2</sup> for the target devices (the details of the calculation are presented in Supplementary Note 2). The 1 Ω cm<sup>2</sup> lower series resistance of the target device is the reason for the 3%abs higher FF. This difference in _R_ s can only come from the interface passivation layer since all other layers of the devices contributing to the series resistance are the same. To understand the mechanism behind this decrease in series resistance upon the CBz-PAI treatment compared with the PEAI treatment we have to look at the HOMO energy levels. The CBz-PAI layer has a HOMO level 40 meV above the perovskite valence band edge (Supplementary Fig. 25); hence, a good hole transport through this layer into the spiro-OMeTAD HTL is expected. For PEAI, the HOMO level is 50 meV below the perovskite valence band, which should result in a barrier and, thus, in a larger series resistance. This barrier also has an effect on the kinetics of the hole transfer, which we can show by time-resolved photoluminescence (TRPL) measurements on bilayer perovskite/spiro-OMeTAD films with PEAI and CBz-PAI as interface passivation (Fig. 4d). Although the TRPL traces on a timescale of several hundreds of nanoseconds appear to be very similar (Fig. 4d, inset), a closer look on the first few nanoseconds, where hole transfer dominates the signal decay, reveal with statistical significance a faster decay for the CBz-PAI-treated sample. Thus, the hole transfer from perovskite to HTM is faster with the CBz-PAI-treated sample, which is in good agreement with the elimination of a transport barrier. This barrier is the reason for a higher series resistance of the PEAI device, which we quantified to be 1 Ω cm<sup>2</sup> . Thus, the elimination of this barrier and the concomitant favourable hole transfer from the perovskite layer into the HTL leads not only to reduced Voc losses as discussed above but also to a higher FF. 

Nature Energy | Volume 8 | May 2023 | 515–525 

**520** 

**Article** 

https://doi.org/10.1038/s41560-023-01249-0 



<!-- Start of picture text -->
a<br>1.0 94.60%<br>0.8<br>0.6 66.59%<br>Initial PCE<br>0.4<br>Control 21.5%<br>Target 23.2%<br>0.2<br>Operational stability: 1,100 h of MPP-tracking conditions<br>0<br>0 100 200 300 400 500 600 700 800 900 1,000 1,100<br>Time (h)<br>b<br>Control-fresh Control-aged<br>Au<br>Spiro-MeOTAD<br>Perovskite<br>SnO2<br>FTO<br>1 µm 1 µm<br>c<br>Target-fresh Target-aged<br>Au<br>Spiro-MeOTAD<br>CBz-PAI<br>Perovskite<br>SnO2<br>FTO 1 µm 1 µm<br>d 80 ×102 e 80 ×102<br>Control Target<br>1.3 1.3<br>60 60<br>1.0 1.0<br>40 0.8 40 0.8<br>0.5 0.5<br>20 20<br>0.3 0.3<br>10 µm 10 µm<br>0 0 0 0<br>0 25 50 75 0 25 50 75<br>µm µm<br>PCE (%)<br>Intensity (a.u.) Intensity (a.u.)<br><!-- End of picture text -->

**Fig. 5 | Operational stability test of the control (PEAI as passivator) and target (CBz-PAI) PSC devices.** All samples were aged for 1,100 h MPP tracking at 1 sun and 45 °C. **a** , PCE during 1,100 h stability test under MPP tracking condition (AM 1.5 G, 100 mW cm<sup>−2</sup> in N2, 45 °C). Cross-sectional SEM images of the full PSC 

devices. **b** , **c** , Control device ( **b** ) and target device ( **c** ) before and after ageing. The dotted circles represent voids. Voids appear in the perovskite film, which appears to be delaminated at the interfaces with perovskite and HTM layer. **d** , **e** , Mapping of TOF-SIMS signals of I<sup>−</sup> in the HTL for control device ( **d** ) and target device ( **e** ). 

### **Device stability** 

The operational stability of the control and target devices was evaluated using full sunlight soaking under the continuous MPP tracking, and the stability results are shown in Fig. 5a. After 1,100 h, the device with CBz-PAI overlayer is capable of maintaining 94.6% PCE of its initial value, while the one for the control device is only 66.6%. Then the measurement of contact angle of the corresponding films was performed to figure out the reason for the improved stability of PSC after CBz-PAI treatment (Supplementary Fig. 30). As compared with the perovskite, the contact angle of the hydrophobic chlorobenzene (CB)-based HTL 

solution droplets on the perovskite/CBz-PAI film decreases from 18.3° to 9.7°, indicating the improved compatibility between the perovskite and the HTL. Additionally, the contact angles of water droplets on the surface of the control sample and the sample with CBz-PAI overlayer are 50.6° and 77.8°, respectively. This obvious difference in water contact angle demonstrates that the surface of the perovskite/CBz-PAI films is more hydrophobic, which is favourable for repelling moisture and slowing down the water penetration into the perovskite film in a moist environment. Moreover, the cross-section of the control and CBz-PAI-based devices was measured by SEM before and after 1,100 h 

Nature Energy | Volume 8 | May 2023 | 515–525 

**521** 

**Article** 

https://doi.org/10.1038/s41560-023-01249-0 

MPP tracking (Fig. 5b,c and Supplementary Fig. 31), which demonstrates that CBz-PAI treatment does not change the crystal quality of perovskite. The void-like features between the perovskite layer and HTL are observed in the aged control device, which could behave as the non-radiative recombination sites to inhibit charge transport. In contrast, thanks to the high compatibility of the conjugated structure in CBz-PAI with HTL layer, no such features appeared in the device with CBz-PAI interlayer after ageing, evidencing that CBz-PAI can enhance the stability of the interface between perovskite layer and HTL layer. 

Time-of-flight secondary ion mass spectroscopy (TOF-SIMS) was applied to analyse the spatial distribution of the key perovskite components within Spiro-MeOTAD layer for the aged control and target PSC devices (Fig. 5d,e). The mapping signal of I<sup>−</sup> in Spiro-MeOTAD is counted and represented by pixel ratio. It is clearly observed that the aged control device showed extremely strong signal of I<sup>−</sup> , while the signal is significantly reduced in the aged device with CBz-PAI compared with the control PEAI device. This result shows that the incorporated CBz-PAI layer strongly suppresses the undesired migration of I<sup>−</sup> ions from perovskite to HTL, thus preventing the device from fast degradation. We also analysed the depth profile of I<sup>−</sup> and Li<sup>+</sup> within the cells by TOF-SIMS (Supplementary Fig. 32). The I<sup>−</sup> signal in the PEAI control device is much higher in the HTL than that of the device with CBz-PAI interlayer. Meanwhile, the diffusion of Li<sup>+</sup> from HTL layer to the perovskite layer is also effectively reduced in the device with CBz-PAI interlayer, which is considered to be one of the reasons for the small hysteresis of the target device. These results show that the CBz-PAI interlayer can not only improve the stability of the interface between perovskite and HTL layers, it can also suppress the migration of I<sup>−</sup> from perovskite to HTL, as well as the diffusion of Li<sup>+</sup> from HTL to perovskite, thus resulting in outstanding stability of the target PSC device. Remarkably, the damp heat (85 °C and 85% relative humidity) test showed that the device with CBz-PAI retained 92.3% of its maximum PCE after 1,000 h (Supplementary Fig. 33). Furthermore, we carried out more detailed experiments on higher thermal/light stability by using the more stable PTAA and P3HT as HTL. The target device retained 78.5% and 91.1% of the initial PCEs after 500 h under continuous full light illumination at 80 ± 5 °C with PTAA and P3HT as HTL (Supplementary Fig. 34), respectively. Our results demonstrate that CBz-PAI as interface engineering material can effectively enhance the device performance and operational reliability of n-i-p PSCs. 

### **Conclusion** 

In summary, a bifunctional molecule CBz-PAI with two functional groups, a CBz unit and PAI, was developed and used as an interface layer between perovskite and HTM, whose role is to afford interfacial defect passivation, tolerance of energy level misalignment between the valence band of the perovskite and that of the hole conductor and chemical compatibility with the HTL, resulting in a greatly improved device performance. 

### **Methods** 

from Alfa Aesar. Methylammonium chloride, PEAI and formamidinium iodide were purchased from Dyesol. Poly(bis-(4-phenyl)(2,4,6-trimethylphenyl)-amine) (PTAA), poly(3-hexylthiophene) (P3HT) and 2,2′,7,7′-tetrakis( _N_ , _N_ -di(4-methoxyphenyl)amino)9,9′-spirobifluorene (Spiro-OMeTAD) were purchased from Xi’an Polymer Light Technology Corp.). Dimethyl sulphoxide (DMSO), dimethylformamide (DMF), isopropyl alcohol (IPA), toluene, ultradry tetrahydrofuran, ethanol and CB were purchased from Acros. All the chemicals were used as received without further purification. The (4-(bis(4-methoxyphenyl)amino)phenyl)boronic acid was synthesized according to the literature<sup>47</sup> . Fluorine-doped tin oxide (10 Ω per square) conductive glass was purchased from Nippon Sheet Glass. The transmittance is shown in Supplementary Fig. 35. 

##### **Preparation of electron transport layer** 

The FTO substrate was cleaned by 2% Hellmanex III (HellmaAnalytics), deionized water, acetone and IPA for 10 min each. Then an air gun was used to remove the remaining ethanol, and the films were treated by ultraviolet-ozone for 15 min before use. The Chemical Bath Deposition solution was prepared by mixing 625 mg of urea, 625 μl of HCl, 12.5 μl of thioglycolic acid and 137.5 mg of SnCl2·2H2O per 50 ml of deionized water<sup>48</sup> . FTO glass substrate was dipped in the solution for 3 h. Then deionized water was used for ultrasonic cleaning for 5 min to remove the remaining large particles, and the SnO2 film was annealed on a hot stage at 180 °C for 1 h. The Chemical Bath Deposition process was repeated for several times to achieve the desired thickness, and followed by annealing at 180 °C for 1 h. 

##### **Preparation of the perovskite precursor** 

Then, 1.56 M perovskite precursor solutions (FAPbI3 crystal:0.35 methylammonium chloride) in a mixture solvent of DMF/DMSO (4:1, by volume) with 0.12 mM of PbI2 as a dopant were prepared using a previously reported method<sup>13</sup> . 

Synthesis of FAPbI3 crystal: 1.0 M FAPbI3 perovskite precursor solutions were prepared by dissolving equimolar formamidinium iodide and PbI2 in g-butyrolactone after shaking for 1–2 h. The solutions were filtered using polytetrafluoroethylene filter with 0.22 mm. Seed crystals of 0.5–2 mm in size were first obtained by placing 1 ml precursor solutions at 131 °C for 30 min in a hotplate. To obtain a larger FAPbI3 crystal, we can transfer small-sized crystals to a 1 M pre-heated fresh solution, and continue growth under 90 °C. The as-obtained large-size single crystals were taken out from the hot precursor solutions. The residual solution of the large-size single crystals was removed by ether and subsequently dried at 150 °C for 1 h. The photos of preparing FAPbI3 crystals and FAPbI3-based perovskite precursor solutions are shown in Supplementary Fig. 36. 

##### **Preparation of the Spiro-OMeTAD solution** 

The Spiro-OMeTAD solution was prepared by firstly dissolving 72.3 mg Spiro-OMeTAD in 1 ml CB. After that, 17.5 μl Li-TFSI (from 520 mg ml<sup>−1</sup> stock acetonitrile solution) and 28.8 μl tBP was added into the solution. 

##### **Materials** 

Stannous chloride dihydrate (SnCl 2·2H 2O) (>99.995%), hydrochloric acid (HCl, 37 wt. % in water), thioglycolic acid (98%), urea, acetonitrile, 4- _tert_ -butylpyridine (tBP), lithium bis(trifluoromethanesulphonyl)imide salt (Li-TFSI), hexadeuterodimethyl sulphoxide (DMSO-d6), deuterated tetrahydrofuran (THF-d8), heptadeutero- _N_ , _N_ -dimethylformamide (DMF-d7), bis(4-methoxyphenyl)amine, 1-bromo-4-iodobenzene, potassium _tert_ -butoxide, tris(dibenzylideneacetone) dipalladium (Pd2(dba)3), _n_ -butyllithium ( _n_ -BuLi), trimethyl borate, 2-dicyclohexylphosphino2′,4′,6′-triisopropylbiphenyl (XPhos) and tetrakis(triphenyl phosphine)-palladium(0) (Pd(PPh3)4) were purchased from Sigma-Aldrich. Lead iodide (PbI2), 3,6-dibromo-9 _H_ -carbazole, potassium carbonate and 1-fluoro-4-nitrobenzene were purchased 

##### **Preparation of the P3HT layer** 

The P3HT layer was deposited onto perovskite film by spin-coating P3HT solution (P3HT (10 mg) in 1 mL CB) at 3,000 r.p.m. for 30 s. 

##### **Preparation of the PTAA layer** 

The PTAA was dissolved in toluene (10 mg ml<sup>−1</sup> ) with additives of 7.5 μl bis(trifluoromethane)sulphonimide lithium salt/acetonitrile (170 mg ml<sup>−1</sup> ) and 4 μl tBP. PTAA layer was deposited onto perovskite film by spin-coating PTAA solution at 3,000 r.p.m. for 30 s. 

##### **Device fabrication** 

The perovskite precursor was spin-coated on FTO/SnO2 substrates. The first step was carried out at 1,000 r.p.m. with an acceleration rate 

Nature Energy | Volume 8 | May 2023 | 515–525 

**522** 

**Article** 

https://doi.org/10.1038/s41560-023-01249-0 

of 200 r.p.m. s<sup>−1</sup> for 10 s. The second step followed at 5,000 r.p.m. with an acceleration rate of 1,000 r.p.m. s<sup>−1</sup> for 30 s. At the last 15th second, a 110 μl anti-solvent of CB was drop-coated, and then the as-deposited films were annealed at 150 °C for 15 min. After cooling the perovskite-coated substrate, for CBz-PAI treatment, the CBz-PAI solution was dissolved in IPA with different concentrations ranging from 0 mM to 10 mM and spin-coated onto the perovskite surface at a spin rate of 5,000 r.p.m. and annealed at 100 °C for 5 min. For PEAI treatment, the PEAI solution was dissolved in IPA with the concentrations of 20 mM and spin-coated onto the perovskite surface at a spin rate of 5,000 r.p.m. and annealed at 100 °C for 5 min. Then, the Spiro-OMeTAD solution was spin-coated on the perovskite films at 3,000 r.p.m. for 30 s. Finally, gold was deposited using thermal evaporation at a pressure of ~3 × 10<sup>−4</sup> Pa. 

##### **PV performance measurements** 

Current–voltage ( _J–V_ ) characteristics were recorded under ambient temperature (23 °C) and ambient air conditions. The PSCs were measured using a 450 W xenon light source solar simulator (ORIEL Sol3A CLASS AAA 94043A) from Newport and were kept at room temperature by a constant flow of compressed air at a temperature of 23 °C. A silicon photodiode with KG3 filter, calibrated by an A2LA-accredited PV and calibration test laboratory (Newport, PV Calibration Lab), was used as reference cell for light intensity calibration. In the measurement evaluation a spectral mismatch factor of 0.962 was taken into account. It was determined from the solar simulator spectrum, the AM1.5 spectrum and the EQE spectra of the test and reference cells. A Keithley 2400 source meter was used for current–voltage measurements with a scan rate of 50 mV s<sup>−1</sup> . The cells with an active area of 0.25 cm<sup>2</sup> (0.5 cm × 0.5 cm) were masked with a black metal mask with an area of 0.158 cm<sup>2</sup> . EQE spectra were recorded with a commercial system (Arkeo-Ariadne, Cicci Research s.r.l.) based on a 300 W xenon light source and a holographic grating monochromator (Cornerstone, Newport). The operational stability of the cells was measured under a white-light-emitting diode lamp with biologic MPG2 potentiostat and was performed under a continuous nitrogen flow. The device area is masked to around 0.16 cm<sup>2</sup> . The light intensity is set to reflect 1 sun condition, and the actual current is adjusted according to in-time calibration results from the silicon diode. 

##### **Steady-state MPP and** **_V_ oc measurements** 

If not otherwise stated, steady-state MPP and _V_ oc measurements were carried out under simulated 1 sun illumination with cooling by a constant flow of compressed air at a temperature of 23 °C for 60 s. For the steady-state _V_ oc measurements we used a black metal mask with an area of 36 mm<sup>2</sup> (6 mm × 6 mm), which is slightly bigger than the cell active area, to homogeneously illuminate the entire cell. This method guarantees that the real stabilized active area _V_ oc is measured and not one that reflects the parallel connection of an illuminated cell and a shaded cell. 

##### **NMR measurements** 

1H and 13C NMR spectra were recorded on Bruker Avance III-400 MHz NMR spectrometer. Chemical shifts are reported in parts per million (p.p.m., _δ_ ).<sup>1</sup> H NMR and<sup>13</sup> C NMR spectra were referenced to tetramethylsilane (0 p.p.m.) or solvent residual peak (3.58 p.p.m. or 2.50 p.p.m. for 1H NMR and 67.21 p.p.m. for 13C NMR) as internal standard. Mass spectra were collected on a HITACHI-80 mass spectrometer. 

##### **Photoluminescence lifetime and UV–Vis measurements** 

The photoluminescence lifetime was measured via time-correlated single photon counting using a LifeSpec II (Edinburgh Instruments) fluorescence spectrometer with a picosecond-pulsed diode laser (EPL510, Edinburgh Instruments) at 510 nm wavelength and 85 ps pulse width. UV–Vis absorption and transmission spectra were measured using a Varian Cary 5 spectrometer (Varian). 

##### **Powder X-ray diffraction measurement** 

Powder X-ray diffraction patterns of the mechanosynthesized samples were recorded with a Bruker D8 Discover Vario diffractometer with a Cu Kα1 monochromator (1.540598 Å). 

##### **SEM and atomic force microscopy/KPFM measurements** 

The SEM images were acquired using field-emission SEM (Zeiss Merlin). Atomic force microscopy height images and KPFM were attained by a Cypher, Asylum Research in tapping mode, using Pt:Si-coated tips (AC240TM, Olympus). 

##### **PLQY measurement** 

PLQY was measured using an integrating sphere (Fluorolog, Horiba JobinYvon), an Andor Kymera 193i spectrograph and a 660 nm continuous-wave laser (OBIS, Coherent) set at 1-sun equivalent photon flux (1.1 μm beam full-width half-maximum, 632 μW); photoluminescence was collected at normal incidence using a 0.1 numerical aperture, 110-μm-diameter optical fibre. For the calibration of the PLQY measurements we used a halogen lamp (HL-3 plus CAL from Ocean Optics). To check the correctness of the calibration we measured PLQY of a dye solution of indocyanine green in DMSO in the same setup and measured PLQY values within 15% deviation from the literature values. 

##### **GIWAXS measurements** 

GIWAXS measurements were performed at the Shanghai Synchrotron Radiation Facility Laboratory on Beamline BL14B1 using X-ray with a wavelength of _λ_ ≈ 1.24 Å. Two-dimensional GIWAXS patterns were acquired by a Mar CCD mounted vertically at a distance ~194 mm from the sample with a grazing incidence angle of 0.5° and an exposure time of 50 s. The 2D GIWAXS patterns were analysed using the FIT2D software and displayed in scattering vector _q_ coordinates with _q_ = 4 _π_ sin _θ_ / _λ_ , where _θ_ is half of the diffraction angle and _λ_ is the wavelength of incident X-ray. 

##### **SCAPS simulations** 

SCAPS is a drift-diffusion solver that has been developed by the group of M. Burgelman at the University of Gent. It can be obtained from https://users.elis.ugent.be/ELISgroups/solar/projects/scaps. Simulation parameters are presented in Supplementary Table 3. 

##### **Reporting summary** 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

### **Data availability** 

Source data are provided with this paper. All the data supporting the findings of this study are available within this article and its Supplementary Information. Any additional information can be obtained from corresponding authors upon request. 

### **References** 

1. Kojima, A., Teshima, K., Shirai, Y. & Miyasaka, T. Organometal halide perovskites as visible-light sensitizers for photovoltaic cells. _J. Am. Chem. Soc._ **131** , 6050–6051 (2009). 

2. Kim, H.-S. et al. Lead iodide perovskite sensitized all-solid-state submicron thin film mesoscopic solar cell with efficiency exceeding 9%. _Sci. Rep._ **2** , 591 (2012). 

3. Zhou, H. et al. Interface engineering of highly efficient perovskite solar cells. _Science_ **345** , 542–546 (2014). 

4. Yang, W. S. et al. High-performance photovoltaic perovskite layers fabricated through intramolecular exchange. _Science_ **348** , 1234–1237 (2015). 

5. Tan, H. et al. Efficient and stable solution-processed planar perovskite solar cells via contact passivation. _Science_ **355** , 722–726 (2017). 

Nature Energy | Volume 8 | May 2023 | 515–525 

**523** 

**Article** 

https://doi.org/10.1038/s41560-023-01249-0 

6. Wu, Y. et al. Perovskite solar cells with 18.21% efficiency and area over 1 cm<sup>2</sup> fabricated by heterojunction engineering. _Nat. Energy_ **1** , 16148 (2016). 

7. Ren, H. et al. Efficient and stable Ruddlesden–Popper perovskite solar cell with tailored interlayer molecular interaction. _Nat. Photon._ **14** , 154–163 (2020). 

8. Zhou, Q. et al. Revealing steric-hindrance-dependent buried interface defect passivation mechanism in efficient and stable perovskite solar cells with mitigated tensile stress. _Adv. Funct. Mater._ **32** , 2205507 (2022). 

9. Tang, X. et al. Improvements in efficiency and stability of perovskite solar cells using a cesium chloride additive. _ACS Appl. Mater. Interfaces_ **14** , 26866–26872 (2022). 

10. You, S. et al. A biopolymer heparin sodium interlayer anchoring TiO2 and MAPbI3 enhances trap passivation and device stability in perovskite solar cells. _Adv. Mater._ **30** , 1706924 (2018). 

11. Tong, J. et al. Carrier control in Sn–Pb perovskites via 2D cation engineering for all-perovskite tandem solar cells with improved efficiency and stability. _Nat. Energy_ **7** , 642–651 (2022). 

12. You, S. et al. Radical polymeric p-doping and grain modulation for stable, efficient perovskite solar modules. _Science_ **379** , 288–294 (2023). 

13. Min, H. et al. Perovskite solar cells with atomically coherent interlayers on SnO2 electrodes. _Nature_ **598** , 444–450 (2021). 

14. Jeong, J. et al. Pseudo-halide anion engineering for α-FAPbI3 perovskite solar cells. _Nature_ **592** , 381–385 (2021). 

15. Yang, G. et al. Stable and low-photovoltage-loss perovskite solar cells by multifunctional passivation. _Nat. Photon._ **15** , 681–689 (2021). 

16. Chen, J. & Park, N.-G. Materials and methods for interface engineering toward stable and efficient perovskite solar cells. _ACS Energy Lett._ **5** , 2742–2786 (2020). 

17. You, S. et al. Multifunctional polymer-regulated SnO2 nanocrystals enhance interface contact for efficient and stable planar perovskite solar cells. _Adv. Mater._ **32** , 2003990 (2020). 

18. Zhao, L. et al. Chemical polishing of perovskite surface enhances photovoltaic performances. _J. Am. Chem. Soc._ **144** , 1700–1708 (2022). 

19. Wang, Y. et al. Stabilizing heterostructures of soft perovskite semiconductors. _Science_ **365** , 687–691 (2019). 

20. Tan, F. et al. In situ back-contact passivation improves photovoltage and fill factor in perovskite solar cells. _Adv. Mater._ **31** , 1807435 (2019). 

21. Bu, T. et al. Lead halide-templated crystallization of methylamine-free perovskite for efficient photovoltaic modules. _Science_ **372** , 1327–1332 (2021). 

22. Jang, Y.-W. et al. Intact 2D/3D halide junction perovskite solar cells via solid-phase in-plane growth. _Nat. Energy_ **6** , 63–71 (2021). 

23. Luo, J. et al. An efficient and hydrophobic molecular doping in perovskite solar cells. _Nano Energy_ **82** , 105751 (2021). 

24. Zheng, X. et al. Defect passivation in hybrid perovskite solar cells using quaternary ammonium halide anions and cations. _Nat. Energy_ **2** , 17102 (2017). 

25. Wu, G. et al. Surface passivation using 2D perovskites toward efficient and stable perovskite solar cells. _Adv. Mater._ **34** , 2105635 (2022). 

26. Bi, D. et al. Multifunctional molecular modulators for perovskite solar cells with over 20% efficiency and high operational stability. _Nat. Commun._ **9** , 4482 (2018). 

27. Liang, C. et al. Two-dimensional Ruddlesden–Popper layered perovskite solar cells based on phase-pure thin films. _Nat. Energy_ **6** , 38–45 (2021). 

28. Jiang, Q. et al. Surface passivation of perovskite film for efficient solar cells. _Nat. Photon._ **13** , 460–466 (2019). 

29. Jung, E. H. et al. Efficient, stable and scalable perovskite solar cells using poly(3-hexylthiophene). _Nature_ **567** , 511–515 (2019). 

30. Shi, E. et al. Two-dimensional halide perovskite lateral epitaxial heterostructures. _Nature_ **580** , 614–620 (2020). 

31. Gao, Y. et al. Molecular engineering of organic–inorganic hybrid perovskites quantum wells. _Nat. Chem._ **11** , 1151–1157 (2019). 

32. Zhang, F. et al. Metastable Dion–Jacobson 2D structure enables efficient and stable perovskite solar cells. _Science_ **375** , 71–76 (2022). 

33. Tan, Y., Cheng, H., Zhao, Y., Wan, L. & Wang, Z.-S. Indolocarbazole-core linked triphenylamine as an interfacial passivation layer for perovskite solar cells. _J. Mater. Chem. A_ **10** , 7173–7185 (2022). 

34. Zhao, B. et al. Introduction of multifunctional triphenylamino derivatives at the perovskite/HTL interface to promote efficiency and stability of perovskite solar cells. _ACS Appl. Mater. Interfaces_ **12** , 9300–9306 (2020). 

35. Wu, Y. et al. Realizing high-efficiency perovskite solar cells by passivating triple-cation perovskite films. _Sol. RRL_ **6** , 2200115 (2022). 

36. Sidhik, S. et al. Deterministic fabrication of 3D/2D perovskite bilayer stacks for durable and efficient solar cells. _Science_ **377** , 1425–1430 (2022). 

37. Lu, J. et al. Interfacial benzenethiol modification facilitates charge transfer and improves stability of cm-sized metal halide perovskite solar cells with up to 20% efficiency. _Energy Environ. Sci._ **11** , 1880–1889 (2018). 

38. Peng, J. et al. Centimetre-scale perovskite solar cells with fill factors of more than 86 per cent. _Nature_ **601** , 573–578 (2022). 

39. Liu, Y. et al. Ultrahydrophobic 3D/2D fluoroarene bilayer-based water-resistant perovskite solar cells with efficiencies exceeding 22%. _Sci. Adv._ **5** , eaaw2543 (2019). 

40. Zhang, H. et al. Multimodal host–guest complexation for efficient and stable perovskite photovoltaics. _Nat. Commun._ **12** , 3383 (2021). 

41. Krückemeier, L., Rau, U., Stolterfoht, M. & Kirchartz, T. How to report record open-circuit voltages in lead-halide perovskite solar cells. _Adv. Energy Mater._ **10** , 1902573 (2020). 

42. Caprioglio, P. et al. On the relation between the open-circuit voltage and quasi-Fermi level splitting in efficient perovskite solar cells. _Adv. Energy Mater._ **9** , 1901631 (2019). 

43. Tress, W. et al. Interpretation and evolution of open-circuit voltage, recombination, ideality factor and subgap defect states during reversible light-soaking and irreversible degradation of perovskite solar cells. _Energy Environ. Sci._ **11** , 151–165 (2018). 

44. Wolf, M. & Rauschenbach, H. Series resistance effects on solar cell measurements. _Adv. Energy Convers._ **3** , 455–479 (1963). 

45. Mundhaas, N. et al. Series resistance measurements of perovskite solar cells using _J_ sc– _V_ oc measurements. _Sol. RRL_ **3** , 1800378 (2019). 

46. Peng, J. et al. Nanoscale localized contacts for high fill factors in polymer-passivated perovskite solar cells. _Science_ **371** , 390–395 (2021). 

47. Teng, C. et al. Molecular design of anthracene-bridged metal-free organic dyes for efficient dye-sensitized solar cells. _J. Phys. Chem. C_ **114** , 9101–9110 (2010). 

48. Yoo, J. J. et al. Efficient perovskite solar cells via improved carrier management. _Nature_ **590** , 587–593 (2021). 

49. Jeong, M. et al. Stable perovskite solar cells with efficiency exceeding 24.8% and 0.3-V voltage loss. _Science_ **369** , 1615–1620 (2020). 

### **Acknowledgements** 

S.Y. acknowledges the financial support from the China Scholarship Council (CSC). This work was financially supported by National Key 

Nature Energy | Volume 8 | May 2023 | 515–525 

**524** 

**Article** 

https://doi.org/10.1038/s41560-023-01249-0 

Research and Development Program of China (2022YFB4200305, X.L. and Y.R.); National Natural Science Foundation of China (21875081, X.L.; 22279039, X.L. and 52172200, Y.R.); the Chinese National 1000-Talent-Plan programme (X.L.); the Frontier Project of the Application Foundation of Wuhan Science and Technology Plan Project 2020010601012202 (X.L.); the Science and Technology Department of Hubei Province (2021CFB315, Y.R.); the Innovation Project of Optics Valley Laboratory OVL2021BG008 (X.L.); the foundation of State Key Laboratory of New Textile Materials and Advanced Processing Technologies FZ2021011 (X.L.), the Graduates’ Innovation Fund of Huazhong University of Science and Technology 2021yjsCXCY037 (S.Y.); Gebert Rüf Stiftung under Microbials scheme ‘Solar-Bio Fuels’ (GRS-080/19, D.R. and J.G.). We thank the Analytical and Testing Center from HUST and the Center for Nanoscale Characterization and Devices (CNCD) from WNLO (HUST) for the facility support of sample measurements, and thank Donjin Semichem Co., LTD, South Korea for a gift of anti-reflective film. 

### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41560-023-01249-0. 

**Correspondence and requests for materials** should be addressed to Zhongjin Shen, Xiong Li or Michael Grätzel. 

**Peer review information** _Nature Energy_ thanks Nam-Gyu Park and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at www.nature.com/reprints. 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

### **Author contributions** 

M.G., X.L. and Z.S. conceived and supervised the project. S.Y., F.T.E. and Z.S. designed the experiments and conducted the corresponding device and characterization. J.G. and D.R. helped with the SEM measurements. J.-H.Y. and K.S. helped with the KPFM measurements. M.X. helped with the X-ray diffraction measurements. S.Y. wrote the original draft. F.T.E., Z.S., M.G. and X.L. contributed to the editing of the manuscript. X.Z., R.G, Y.R., S.M.Z. and J.T. provided valuable suggestions for the manuscript. All authors discussed the results and reviewed the manuscript. 

### **Funding** 

Open access funding provided by EPFL Lausanne. 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons. org/licenses/by/4.0/. 

### **Competing interests** 

The authors declare no competing financial interests. 

© The Author(s) 2023 

Nature Energy | Volume 8 | May 2023 | 515–525 

**525** 











