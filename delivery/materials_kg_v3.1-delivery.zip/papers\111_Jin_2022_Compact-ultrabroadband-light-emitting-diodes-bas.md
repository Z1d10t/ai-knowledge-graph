# Compact ultrabroadband light-emitting diodes based on lanthanide-doped lead-free double perovskites

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Light: Science & Applications |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 217 |
| 作者 | Shi-Lin Jin, Ren-Fu Li, Hai Huang, Naizhong Jiang, Ji-dong Lin, Shao-Xiong Wang, Yuanhui Zheng, Xue-Yuan Chen et al. |
| DOI | 10.1038/s41377-022-00739-2 |
| 源文件 | 011_Jin_2022_Compact-ultrabroadband-light-emitting-diodes-bas.pdf |

---
Official journal of the CIOMP 2047-7538 www.nature.com/lsa 

Jin et al. Light: Science & Applications (2022) 11:52 https://doi.org/10.1038/s41377-022-00739-2 

## A R T I C L E 

O p e n A c c e s s 

# Compact ultrabroadband light-emitting diodes based on lanthanide-doped lead-free double perovskites 

Shilin Jin<sup>1,2</sup> , Renfu Li 3✉, Hai Huang1, Naizhong Jiang1, Jidong Lin1, Shaoxiong Wang1,4,5, Yuanhui Zheng 2,6, Xueyuan Chen 3✉ and Daqin Chen 1,2✉ 

### Abstract 

Impurity doping is an effective approach to tuning the optoelectronic performance of host materials by imparting extrinsic electronic channels. Herein, a family of lanthanide (Ln<sup>3+</sup> ) ions was successfully incorporated into a Bi:Cs2AgInCl6 lead-free double-perovskite (DP) semiconductor, expanding the spectral range from visible (Vis) to near-infrared (NIR) and improving the photoluminescence quantum yield (PLQY). After multidoping with Nd, Yb, Er and Tm, Bi/Ln: Cs2AgInCl6 yielded an ultrabroadband continuous emission spectrum with a full width at half-maximum of ~365 nm originating from intrinsic self-trapped exciton recombination and abundant 4f–4f transitions of the Ln<sup>3+</sup> dopants. Steady-state and transient-state spectra were used to ascertain the energy transfer and emissive processes. To avoid adverse energy interactions between the various Ln<sup>3+</sup> ions in a single DP host, a heterogeneous architecture was designed to spatially confine different Ln<sup>3+</sup> dopants via a “DP-in-glass composite” (DiG) structure. This bottom-up strategy endowed the prepared Ln<sup>3+</sup> -doped DIG with a high PLQY of 40% (nearly three times as high as that of the multidoped DP) and superior long-term stability. Finally, a compact Vis–NIR ultrabroadband (400~2000 nm) light source was easily fabricated by coupling the DiG with a commercial UV LED chip, and this light source has promising applications in nondestructive spectroscopic analyses and multifunctional lighting. 

### Introduction 

Ultrabroadband light sources that emit over an extremely wide spectral range are of great interest in many fields, such as photonics, medical treatment, high-capacity optical data communications, ultraprecision metrology, and spectroscopy<sup>1–7</sup> . Conventionally, halogen tungsten lamps (HTLs) are used in most studies and applications, but they generate large amounts of heat and have limited operational lifetimes<sup>8</sup> . Recently, superluminescent diodes (SLDs)<sup>9</sup> , ultrabroadband semiconductor lasers (UBSLs)<sup>10</sup> , 

Correspondence: Renfu Li (lirenfu@fjirsm.ac.cn) or 

> Xueyuan Chen (xchen@fjirsm.ac.cn) or Daqin Chen (dqchen@fjnu.edu.cn) 

> 1College of Physics and Energy, Fujian Normal University, Fujian Provincial Key Laboratory of Quantum Manipulation and New Energy Materials, Fuzhou 350117, China 

> 2Fujian Science & Technology Innovation Laboratory for Optoelectronic Information, Fuzhou 350116, China 

laser-driven light sources (LDLSs)<sup>11</sup> , supercontinuum light sources (SCLSs)<sup>12</sup> , and other sources of light have been developed to satisfy the needs of various applications. SLDs are fabricated by elaborately coupling many light-emitting diodes (LEDs) with different emission wavelengths. UBSLs adopt a quantum cascade configuration, where several dissimilar inter-subband (IS) optical transitions cooperate to provide broadband optical gain. LDLSs use high-power lasers to energize highintensity xenon (Xe) plasma, which produces broadband radiation. SCLSs are generated in a photonic crystal fiber pumped by a femtosecond laser. Notably, each of these approaches has intrinsic drawbacks, such as complex structure design for coupling multiple LEDs, difficulty in tailoring IS transitions, low efficiency, and expensive laser triggers. 

Full list of author information is available at the end of the article 

> © The Author(s) 2022 

> OpenAccess ThisarticleislicensedunderaCreativeCommonsAttribution4.0InternationalLicense,whichpermitsuse,sharing,adaptation,distributionandreproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/licenses/by/4.0/. 

Jin et al. Light: Science & Applications (2022) 11:52 

Page 2 of 13 

Lanthanide (Ln<sup>3+</sup> ) or rare-earth ion incorporation or doping is considered a promising approach to imparting and tailoring the optical and optoelectronic performances of inorganic materials spanning the ultraviolet (UV), visible (Vis), near-infrared (NIR), and middle-infrared (MIR) regions, improving their abundant intermediate excited states<sup>13</sup> . For example, Er-doped fiber amplification (EDFA), praseodymium-doped fiber amplifier (PDFA), and thuliumdoped fiber amplifier (TDFA) with broadband NIR emissions have been successfully applied in optical telecommunication<sup>14–16</sup> . However, the parity-forbidden 4f–4f transition of Ln<sup>3+</sup> leads to weak light absorption, which limits the practical application of these materials. Sensitizing Ln<sup>3+</sup> emission via semiconductor quantum dots (QDs) can effectively address this difficult challenge because QDs undergo efficient allowed band-to-band absorption and have tuneable bandgaps<sup>17</sup> . Recently, various lanthanide ions have been successfully doped into the hottest lead-halide perovskite QD (PeQD) lattices to endow them with optical functionality<sup>18–21</sup> . Unfortunately, their use of toxic lead and their poor stability to heat, water, electric fields, and light hamper their commercialization and industrialization on a large scale<sup>22,23</sup> . As an alternative, lead-free halide double perovskites (DPS) have drawn extensive attention for their fascinating optical performance and excellent stability<sup>24–26</sup> . Among the DP family, Cs2AgInCl6 has been in the spotlight for its direct bandgap characteristics and various alloy compositions with monoand trivalent cations other than Ag<sup>+</sup> and In<sup>3+ 27–29</sup> . For example, Cs2AgInCl6 alloyed with 40% Na<sup>+</sup> and 0.04% Bi<sup>3+</sup> doping emits warm white light with ~86% photoluminescence quantum yield (PLQY) and works beyond 1000 h without obvious PL loss<sup>30</sup> . The underlying mechanism of the broadband luminescence in the visible (400~800 nm) spectral range proceeded via the recombination of self-trapped excitons (STEs), which mainly arose from the strong Jahn–Teller distortion of the AgCl6 octahedron triggered by Na<sup>+</sup> dopants<sup>30</sup> . Since then, several successful examples of DPs doped with Ln<sup>3+</sup> ions (Table S1), including La-, Tb-, Er-, and Yb-doped Cs2AgInCl6, have been reported, primarily for their potential applications in white-light-emitting diodes (wLEDs), NIR-LEDs with specific wavelengths, scintillators, anticounterfeiting techniques, and X-ray detection and imaging<sup>31–45</sup> . 

Inspired by the studies described above, we intend to explore the possibility of combining the STE recombination of Cs2AgInCl6 with Ln<sup>3+</sup> dopant-induced extra lightemitting channels to produce lead-free Vis–NIR (400~2000 nm) ultrabroadband emissive DPs for the first time. To our knowledge, there has been no report on Ln<sup>3+</sup> -doped DPs aimed at the application of ultrabroadband light sources. Herein, a family of Ln<sup>3+</sup> dopants (Ln=La–Lu) with Bi<sup>3+</sup> ions is successfully incorporated into Cs2AgInCl6 DPs. The Bi/Ln (Ln=Nd, Yb, Er, and 

Tm):Cs2AgInCl6 samples can yield both visible STE radiation and multiple NIR Ln<sup>3+</sup> 4f–4f emissions under UV light excitation, and the related energy transfer mechanisms are systematically discussed. We further provide a strategy of dispersing Nd:Cs2AgInCl6, Yb/Er: Cs2AgInCl6, and Yb/Tm:Cs2AgInCl6 DPs into an inorganic glass matrix to prevent the depletion of nonradiative migration from the co-doping of multiple Ln<sup>3+</sup> ions in a sole DP host, leading to detrimental luminescent quenching. To the best of our knowledge, this is the first report on a DP-in-glass (DiP) composite. The DiP composite with superior stability and a high PLQY of ~40% can be coupled with a commercial UV LED chip to construct an ultrabroadband LED (u-LED) device. Finally, we demonstrate its promising applications in spectroscopic analysis and multifunctional lighting. Notably, compared with previously reported ultrabroadband light sources, this u-LED device shows the advantages of costeffective fabrication, compactness, excellent optical performance and extremely long-term stability. 

### Results and discussion 

Bi/Ln-doped Cs2AgInCl6 DPs were synthesized via a modified coprecipitation method (Fig. S1, Experimental Section) previously reported by Volonakis et al.<sup>27</sup> . In a typical synthesis, stoichiometric amounts of InCl3, AgCl, BiCl3, and LnCl3 are dissolved in hydrochloric acid at 100 °C. Upon the addition of CsCl solution, a precipitate forms after 20 min of reaction. Notably, a shaded glass bottle is needed in the synthesis of DPs to prevent the silver chloride from being oxidized (Supporting Information, Movie 1). We first prepared Cs2AgInCl6 DPs doped with only Bi<sup>3+</sup> and investigated the influence of Bi<sup>3+</sup> doping content on the structure and optical properties. The X-ray diffraction (XRD) patterns showed that the pure cubic phase was retained after Bi<sup>3+</sup> doping (Fig. S2a). With increasing Bi<sup>3+</sup> content, the diffraction peaks shifted slightly to a lower angle (Fig. S2b), indicating the substitution of In<sup>3+</sup> , which has a small ionic radius (r = 0.80 Å, CN = 6), with Bi<sup>3+</sup> , which has a large ionic radius (r = 1.02 Å, CN = 6). PL originating from STE recombination for the Cs2AgInCl6 DPs is quite weak, and the corresponding PLQY is lower than 1%; Bi<sup>3+</sup> doping will significantly improve the PL intensity, decay lifetime, and PLQY up to ~25% for STE emission (Fig. S2c, Fig. S2d, Fig. S3). The optimal Bi<sup>3+</sup> nominal doping content is 0.048 mmol (Fig. S3), which corresponds to the actual content of ~15 mol% determined by inductively coupled plasma–mass spectrometry (ICP–MS) (Table S2). The excitation power (intensity)- and temperature-dependent PLQYs of Bi: Cs2AgInCl6 were determined. The PLQY remained unchanged with increasing excitation power and was insensitive to excitation intensity (Fig. S3d). However, 

Jin et al. Light: Science & Applications (2022) 11:52 

Page 3 of 13 

with increasing temperature, the PLQY showed a tendency to decrease owing to thermal quenching of STE recombination (Fig. S3e). The normalized PL/PLE spectra show redshifting of both the emission and excitation bands with increasing Bi<sup>3+</sup> content (Fig. S2e, S2f), indicating the Bi<sup>3+</sup> -doping-induced modification of the band-edge structure of Cs2AgInCl6 DPs<sup>46–49</sup> . We prepared additional Bi<sup>3+</sup> /Er<sup>3+</sup> codoped samples with various Bi<sup>3+</sup> contents and fixed Er<sup>3+</sup> contents. All the samples were assigned to the cubic Cs2AgInCl6 phase and exhibited sharp emission peaks corresponding to the Er<sup>3+</sup> : 2H11/2 → 4I15/2, 4S3/2 → 4I15/2, 4F9/2 → 4I15/2, and 4I9/2 → 4I15/2 transitions in the visible spectral region upon excitation with 250~450 nm light (Fig. S4), confirming the incorporation of the Er<sup>3+</sup> dopants into the DP host. With the addition of Er<sup>3+</sup> ions, the total emitting intensity was greater than that of the sample doped with only Bi<sup>3+</sup> owing to the superposition of the additional Er<sup>3+</sup> emissions, and the optimal Bi<sup>3+</sup> content remained at 0.048 mmol (Fig. S5). As evidenced in Fig. S6, changing the Er<sup>3+</sup> content does not greatly enhance the Er<sup>3+</sup> emission intensity. Compared to that of the sample doped with only Bi, the PLQY for the Er/Bi codoped sample is greater; however, the PLQY does not noticeably differ for different Er<sup>3+</sup> -doped samples (Fig. S6). These results indicate the doping saturation of Er<sup>3+</sup> ions, which makes high-content Er<sup>3+</sup> doping difficult. Indeed, the ICP–MS (Table S2) data verify the saturated doping of Er<sup>3+</sup> in DPs with the highest content of ~2.5 mol%, even when the nominal Er/In doping ratio reaches as high as 3. Similarly, for the Yb/Er co-doped sample, the total doping content of both Yb and Er is also close to 2.5 mol% (Table S2). Indeed, intense upconversion luminescence can be detected from the Bi/Yb/Ln (Ln=Er, Ho, or Tm):Cs2AgInCl6 samples under 980 nm laser excitation (Fig. S7), further confirming the incorporation of Ln<sup>3+</sup> ions in the DP host. Notably, it is easy to incorporate many Bi<sup>3+</sup> ions into Cs2AgInCl6 because the structure of Cs2Ag(In/Bi)Cl6 is a stable solid solution<sup>50</sup> , while doping Ln<sup>3+</sup> ions into Cs2AgInCl6 is difficult because the electronic configurations of the Ln<sup>3+</sup> ions and In<sup>3+</sup> ions are quite different. 

The XRD patterns for the whole family of Bi–Ln (Ln=La–Lu)-doped DP samples are provided in Fig. 1a. Introducing Ln<sup>3+</sup> dopants does not induce the formation of impurity phases for all the products, and the diffraction peaks were assigned to the cubic Cs2AgInCl6 phase. The diffraction peak slightly shifted to a smaller angle after the substitution of In<sup>3+</sup> by Ln<sup>3</sup> ; this shift was due to the gradual increase in ionic radius from Lu<sup>3+</sup> to La<sup>3+</sup> (Fig. S8), suggesting successful incorporation of Ln<sup>3+</sup> dopants into the Cs2AgInCl6 crystalline lattice. Taking Yb/Er: Cs2AgInCl6 as a typical example, the scanning electron 

microscopy (SEM) images show that the products are micron-sized crystals with polygonal shapes (Fig. 1b). Energy-dispersive X-ray (EDX) mappings confirm the uniform distribution of all the elements of Cs, Ag, In, Cl, Bi, Yb, and Er (Fig. 1c). The actual elemental content was consistent with the experimental scheme (Fig. S6d, Table S3). X-ray photoelectron spectroscopy (XPS) measurements on the M-1(Bi:Cs2AgInCl6), M-2 (Bi/Yb:Cs2AgInCl6), and M-3 (Bi/Yb/Er Cs2AgInCl6) samples were performed (Fig. S9). Typical Cs 3d, Ag 3d, In 3d, and Cl 2p signal peaks (Fig. S9, Fig. 1d) were detected in the highresolution XPS spectra, and extra Bi 4f (Fig. 1e), Yb 4d (Fig. 1f), and Er 4d (Fig. 1g) peaks were observed for the Bi/Yb/Er:Cs2AgInCl6 sample. Additionally, as shown in Fig. 1d, the shifting of the In 3d peak toward higher energy is observed after Bi/Yb/Er doping. Generally, the substitution of In<sup>3+</sup> ions by Bi<sup>3+</sup> and Ln<sup>3+</sup> dopants in Cs2AgInCl6 leads to lattice expansion and thus a slight shift to a higher binding energy of the In<sup>3+</sup> 3d XPS peak. Similar results have been observed in Bi/Tb-doped Cs2AgInCl6 samples and have been previously reported.<sup>38</sup> Furthermore, magic-angle-spinning (MAS) solid-state nuclear magnetic resonance (NMR) measurements for 133Cs and 115In were performed on the Bi:Cs2AgInCl6 and Bi/Yb/Er:Cs2AgInCl6 samples. The doping of paramagnetic Yb<sup>3+</sup> and Er<sup>3+</sup> induced a shift of the<sup>133</sup> Cs doublet peaks from 105.9/112.3 ppm to 105.4/111.8 ppm (Fig. 1h). This shift is ascribed to the delocalization of the extra electron density of Yb<sup>3+</sup> and Er<sup>3+</sup> (spin I = 1/2 and 3/2) on the Cs<sup>+</sup> ion (i.e., the Fermi-contact interaction)<sup>41,51–53</sup> . The two samples show the peaks of<sup>115</sup> In at 41.8 ppm and 52.3 ppm (Fig. 1i), and the relative peak intensity decreases at 41.8 ppm after Ln doping<sup>53</sup> . The results of the above two changes further verify the successful incorporation of rare-earth ions into the Cs2AgInCl6 DP lattice. 

We recorded the PL spectra of all the Bi/Ln codoped Cs2AgInCl6 samples. Under 350 nm UV light excitation, typical narrow emission peaks assigned to Ln<sup>3+</sup> 4 f → 4 f transitions appeared in addition to the broadband emission of STE for the Pr<sup>3+</sup> , Nd<sup>3+</sup> , Sm<sup>3+</sup> , Tb<sup>3+</sup> , Dy<sup>3+</sup> , Ho<sup>3+</sup> , Er<sup>3+</sup> , Tm<sup>3+</sup> , and Yb<sup>3+</sup> -doped samples (Fig. S10). All the samples exhibited bright luminescence, and the slight difference in emission color is due to the combination of STE emissive color and Ln<sup>3+</sup> color (Fig. S11). The corresponding Ln<sup>3+</sup> 4f → 4f electronic transitions and emitting wavelengths are tabulated in Table S4. For the other Ln<sup>3+</sup> (Ln=La, Ce, Eu, Gd, and Lu)-doped samples, only STE emission was observed. La<sup>3+</sup> , Ce<sup>3+</sup> , Gd<sup>3+</sup> , and Lu<sup>3+</sup> dopants with outer-shell electronic configurations of 4f<sup>0</sup> , 4f<sup>1</sup> , 4f<sup>7</sup> , and 4f<sup>14</sup> do not have suitable energy levels falling inside the bandgap of DP<sup>13</sup> , and no energy transfer from DP to them occurs. Eu<sup>3+</sup> dopants easily produce electron trapping states in empty f-orbitals in the bandgap<sup>36,39</sup> , 

Jin et al. Light: Science & Applications (2022) 11:52 

Page 4 of 13 



<!-- Start of picture text -->
a Bi-La: Cs2AgInCI6 b<br>Bi-Ce: Cs2AgInCI6<br>Bi-Pr: Cs2AgInCI6<br>Bi-Nd: Cs2AgInCI6<br>Bi-Sm: Cs2AgInCI6<br>Bi-Eu: Cs2AgInCI6<br>Bi-Gd: Cs2AgInCI6<br>Bi-Tb: Cs2AgInCI6 10 ûm 5 ûm<br>Bi-Dy: Cs2AgInCI6<br>Bi-Ho: Cs2AgInCI6 c<br>Bi-Er: Cs2AgInCI6<br>Bi-Tm: Cs2AgInCI6<br>Bi-Yb: Cs2AgInCI6<br>Bi-Lu: Cs2AgInCI6 5 ûm Cs 5 ûm Ag 5 ûm In<br>Bi: Cs2AgInCI6<br>Cs2AgInCI6<br>10 20 30 40 50 60 70 80<br>5 ûm 5 ûm 5 ûm 5 ûm<br>2θ ( ° ) Cl Bi Yb Er<br>d M-1 In 3d5/2 e M-1 Bi 4f7/2 h 111.8<br>M-2 M-2 105.4<br>M-3 In 3d3/2 M-3<br>Bi 4f5/2 M-3<br>112.3<br>105.9<br>M-1<br>460 455 450 445 440 168 164 160 156 152 90 100 110 120 130<br>Binding energy (eV) Binding energy (eV) 133Cs (ppm)<br>f Yb 4d M-2M-3 g M-3 Er 4d i 41.8<br>M-3<br>52.3<br>M-1<br>208 200 192 184 176 190 180 170 160 150 -50 0 50 100 150<br>Binding energy (eV) Binding energy (eV) 115In (ppm)<br>Normalized intensity (a.u.)<br>Intensity (a.u.)<br>Intensity (a.u.)<br>Intensity (a.u.) Intensity (a.u.)<br><!-- End of picture text -->

Fig. 1 Structural characterization of Bi/Ln:Cs2AgInCl6 DPs. a XRD patterns of Bi/Ln:Cs2AgInCl6 DPs. b SEM images of a typical Bi/Yb/Er:Cs2AgInCl6 sample and (c) the corresponding EDX mappings. d–g XPS spectra of the In 3d, Bi 4f, Yb 4d, and Er 4d orbitals of M-1 (Bi:Cs2AgInCl6, black line), M-2 (Bi/Yb:Cs2AgInCl6, green line), and M-3 (Bi/Yb/Er:Cs2AgInCl6, red line) samples. h<sup>133</sup> Cs and i<sup>115</sup> In NMR spectra of the M-1 and M-3 samples 

which act as quenching centers. Importantly, as demonstrated in Fig. 2a, the combination of STE broadband visible emission (400–800 nm) with a series of narrowband NIR emissions from Ln<sup>3+</sup> ions (Yb<sup>3+</sup> :<sup>2</sup> F5/2 →<sup>2</sup> F7/2; Tm<sup>3+</sup> : 3H4 → 3H6, 3H5 → 3H6, 3H4 → 3F4; Er<sup>3+</sup> : 4I11/2 → 4I15/2, 4I13/2 → 4I15/2; Nd<sup>3+</sup> : 4F3/2 → 4I9/2, 4F3/2 → 4I11/2, 4F3/2 → 4I13/2) is feasible to realize an ultrabroadband continuous emission spectrum. Taking Bi/Er:Cs2AgInCl6 DP as a typical example, the PL excitation (PLE) spectra were recorded by monitoring the various emissions of Er<sup>3+</sup> (Fig. 2b). The PLE spectra corresponding to the broad visible-light emission of STE at 610 nm are similar for both the Bi:Cs2AgInCl6 and Bi/ Er:Cs2AgInCl6 samples, but are quite different from those of the Er<sup>3+</sup> emissions at 525 nm, 551 nm, 667 nm, 806 nm, and 1539 nm, respectively. In particular, the PLE spectrum for 1539 nm NIR emission without the interference of STE luminescence shows two typical absorption bands 

rather than semiconductor-like band-to-band absorption (Fig. 2b). These two absorption bands can be assigned to Bi<sup>3+</sup> : 6s<sup>2</sup> → 6s6p (<sup>1</sup> S0 →<sup>3</sup> P1,<sup>1</sup> S0 →<sup>1</sup> P1) absorption transitions<sup>54</sup> . In fact, similar phenomena can be found in the PLE spectra of the other Ln<sup>3+</sup> (Nd, Ho, Tm, and Yb) NIR emissions (Fig. S12). These results indicate that the excitation of Ln<sup>3+</sup> ions in Cs2AgInCl6 DP is mainly achieved via energy transfer from Bi<sup>3+</sup> ions rather than the STE state (DP host). To verify this, we detected the PL decay curves for the STE emission of the Bi-doped and Bi/ Er codoped samples. The decay curves of the Er<sup>3+</sup> emissions (Fig. 2c) exhibited typical parity-forbidden 4f–4f transitions with a long lifetime on a millisecond scale (1.49 ms for Er<sup>3+</sup> : 4S3/2 → 4I15/2, 4.04 ms for Er<sup>3+</sup> : 4F9/2 → 4I15/2, and 30.43 ms for Er3+: 4I13/2 → 4I15/2), while the decay lifetime for STE emission was only ~750 ns owing to the strong Jahn–Teller distortion-induced electron–hole recombination (Fig. 2d). Notably, the 

Jin et al. Light: Science & Applications (2022) 11:52 

Page 5 of 13 



<!-- Start of picture text -->
a b<br>2F5/2<br>Yb<br>λem=1539 nm<br>3H4<br>3H5<br>3H4 3F4 Tm λem=806 nm<br>λem=667 nm<br>4S3/2 4F9/2 4I9/2 4I13/2<br>4I11/2 Er λem=551 nm<br>4F3/2 λem=525 nm<br>4I9/2 Bi λem=610 nm<br>4I11/2<br>4I13/2 Nd Bi-Er λem=610 nm<br>400 600 800 1000 1200 1400 1600 250 300 350 400 450 500<br>Wavelength (nm) Wavelength (nm)<br>c d λem= 610 nm Bi/Er: Cs2AgInCl6<br>Bi/Er: Cs2AgInCI6 Er: 0 mmol, t=748 ns<br>4S3/2 4I15/2 λem=551 nm τ=1.49 ms Er: 0.25 mmol, t=759 ns<br>0 40 80 120 160<br>Er: 0.50 mmol, t=753 ns<br>4F9/2 4I15/2 λem =667 nm τ=4.04 ms Er: 0.75 mmol, t=755 ns<br>0 40 80 120 160<br>Er: 1.00 mmol, t=776 ns<br>4I13/2 4I15/2 λem =1539 nm τ=30.43 ms<br>Er: 1.25 mmol, t=754 ns<br>IRF<br>0 40 80 120 160 0 2 4 6 8 10<br>Time (ms) Time ( μ s)<br>e 60<br>Bi/Ln: Cs2AgInCI6 51.7<br>50 45.9 45.6 56.3<br>43.0<br>40<br> Cs2AgInCI6<br>30 Bi: Cs2AgInCI6 ee E.T.E.T. E.T. 1P1<br>Bi: Cs2AgInCI6 STE 33PP12<br>23.6 3P0<br>20<br>10<br> Cs2AgInCI6 g 1S0<br>0 0.8 DP host Ln 3+ Bi 3+<br>undoped Bi Nd Ho Er Tm Yb<br>UV light<br>PL intensity (a.u.) 2H11/2 PLE intensity (a.u.)<br>Log[intensity (a.u.)] Log[intensity (a.u.)]<br>PLQY (%)<br>400-900 nm<br>Energy<br>UV light<br><!-- End of picture text -->

Fig. 2 Spectroscopic characterization and energy-transfer processes in Bi/Ln:Cs2AgInCl6 DPs. a PL spectra of the Bi/Ln (Ln=Nb, Er, Tm, and Yb): Cs2AgInCl6 samples. b PLE spectra of the Bi:Cs2AgInCl6 and Bi/Er:Cs2AgInCl6 samples obtained by monitoring different emitting wavelengths. PL decay curves obtained by monitoring (c) Er<sup>3+</sup> emissions and (d) STE recombination in the Bi/Er:Cs2AgInCl6 samples. IRF represents the instrumental response function. e PLQYs for a series of the Bi/Ln:DPs. The inset shows the proposed energy-transfer mechanisms and emission processes involving both STE recombination and Ln<sup>3+</sup> 4f–4f transitions 

Jin et al. Light: Science & Applications (2022) 11:52 

Page 6 of 13 

decay lifetime for STE recombination shows no obvious change with increasing Er<sup>3+</sup> doping content, indicating that there was no direct energy transfer from STE to the Ln dopants. 

Herein, we propose a possible mechanism that describes the Ln<sup>3+</sup> emissions in Bi/Ln:Cs2AgInCl6 DP, as demonstrated in Fig. 2e. Cs2AgInCl6 DP is a direct bandgap semiconductor that undergoes a parity-allowed higherorder transition between the third valence band (VB) level and conductive-band minima (CBM) at ~4.8 eV<sup>27,28</sup> . Interestingly, Bi<sup>3+</sup> doping decreases the excitation energy to the UV region (extra-absorption energy state at ~377 nm, Fig. S3c) but no other PL peak, except STE emission (Fig. S2c), which might arise from contributions of Bi<sup>3+</sup> orbitals in the band edges<sup>37,46,47</sup> . Based on theoretical calculations, Bi<sup>3+</sup> incorporation is believed to modify the projected density of states at the band edges<sup>37</sup> , break the parity-forbidden transition of STE states<sup>50,55</sup> , and promote exciton localization<sup>30</sup> , giving rise to a new optical absorption channel at a lower energy (Fig. S3c) and promoting the PLQY of STE emission (Fig. S3a). The modified VB → CB excitation energy is then transferred to STE states responsible for visible broadband emission. Additionally, the Bi<sup>3+</sup> ion has a 6s<sup>2</sup> outer-electron configuration with a<sup>1</sup> S0 ground state, and optical transitions to the 6s<sup>1</sup> 6p<sup>1</sup> configuration lead to two intense absorptions assigned to the 1S0 → 1P1 and 1S0 → 3P1-allowed transitions (inset of Fig. 2e)<sup>54</sup> . These two absorption transitions can effectively transfer energy to the Ln<sup>3+</sup> dopants in the DP host, which are de-excited by multiple light emissions with characteristic 4f–4f transitions in the NIR spectral range. In summary, both emissions from STE recombination and Ln<sup>3+</sup> 4f–4f transitions are excitable by UV light, such as light from commercial UV chips, which are beneficial for their synergistic luminescence. Indeed, as demonstrated in Fig. 2e, the PLQY for Cs2AgInCl6 DP is below 1%, Bi<sup>3+</sup> doping promotes the value up to ~24% for efficient UV excitation, and Ln<sup>3+</sup> codoping further increases the PLQY to 43 ~ 56% owing to the superposition of the additional Ln<sup>3+</sup> emissions. Notably, the Cs2AgInCl6 DP reported by Luo et al. has been codoped with Na<sup>+</sup> ions, which can significantly improve the PLQY up to ~90% by breaking the parityforbidden transition of STE-radiative recombination<sup>30</sup> . Unfortunately, the doping of Na<sup>+</sup> in this sample is detrimental to the incorporation of Ln<sup>3+</sup> into the Cs2AgInCl6 lattice. Therefore, only the Cs2AgInCl6 DP without Na<sup>+</sup> dopant was used as the host for Ln<sup>3+</sup> doping. 

To achieve ultrabroadband luminescence in the visible–NIR spectral range, it is necessary to dope multiple Ln<sup>3+</sup> activators into a sole DP host. First, the multi-doped Nd<sup>3+</sup> , Yb<sup>3+</sup> , Er<sup>3+</sup> , and Tm<sup>3+</sup> DP samples were prepared. Compared with those of the single-doped samples, the NIR emission intensities of all the Ln<sup>3+</sup> 4f–4f transitions in the 

multidoped sample decreased significantly (Fig. 3a). Indeed, the PLQY of the multidoped sample decreased to 13% (Fig. 3b). This PL coquenching phenomenon is attributed to detrimental energy transfers and migrations among Nd<sup>3+</sup> , Yb<sup>3+</sup> , Er<sup>3+</sup> , and Tm<sup>3+</sup> dopants due to their well-matched and abundant multiplets<sup>56</sup> . As shown in Fig. 3c, the energy levels of Nd, Er, and Tm ions in the red, yellow, and blue regions are well matched, enabling energy migration among them to defect sites in the multidoped samples and finally leading to PL quenching. In addition, taking Ln<sup>3+</sup> couples (such as Nd and Yb, Nd and Tm, Nd and Er, and Er and Tm) as typical examples, several energy transfer and crossrelaxation processes among Ln<sup>3+</sup> ions are responsible for the energy loss via nonradiative relaxation (Fig. S13). All these detrimental energy-transfer processes finally quench the Ln<sup>3+</sup> emissions in the multidoped samples. To address this challenge, we herein provide a strategy to spatially confine different Ln<sup>3+</sup> dopants in a heterogeneous architecture (Fig. 3d), which involves the codispersion of Nd: Cs2AgInCl6, Yb/Er: Cs2AgInCl6, and Yb/Tm: Cs2AgInCl6 DPs into an inorganic glass matrix through a lowtemperature cosintering technique<sup>57,58</sup> to form a DP-inglass (DiG) composite. Herein, the heterogeneous DiG architecture is not a multilayered structure but a monolithic composite with a size of 1 × 1 cm<sup>2</sup> and a thickness of 75 µm. This method enables the effective avoidance of unwanted energy interactions among Ln<sup>3+</sup> ions and produces intense Ln<sup>3+</sup> NIR emissions for the separate doping of Nd, Er, and Tm ions in DPs. As shown in Fig. S13f–h, the decay lifetimes of the typical Nd<sup>3+</sup> :<sup>4</sup> F3/2 →<sup>4</sup> I9/2, Er<sup>3+</sup> :<sup>4</sup> F9/2 →<sup>4</sup> I15/2, and Tm<sup>3+</sup> :<sup>3</sup> H4 →<sup>3</sup> H6 transitions in the Nd/Yb/Er/Tm multidoped sample are far shorter than those in the Nd-, Yb/Er-, and Yb/Tm-doped samples. Importantly, the decay lifetimes recover after the DiG sample is formed, confirming the efficient inhibition of detrimental energy transfer among the various Ln<sup>3+</sup> -emitting centers. 

The thermal stability of the Ln:Cs2AgInCl6 sample was characterized by differential thermal analysis (DTA) and thermogravimetric (TG) analysis (Fig. 3e). Both the DTA and TG curves show that the Ln:Cs2AgInCl6 sample was stable below 500 °C, and further increasing the temperature led to the gradual decomposition of the DP (inset of Fig. 3e, Fig. S14). In this case, it is important to choose an appropriate low-melting inorganic glass to successfully fabricate DiG composites. Herein, a sodium silicate glass with the composition of SiO2–Na2O–K2O–ZnO was selected because of its excellent moisture resistance and low melting temperature (500 °C). As illustrated in Fig. S15, the viscous Ln:Cs2AgInCl6 ink paste was first prepared by admixing Ln:Cs2AgInCl6 (Ln=Nd, Yb/Er, and Yb/Tm) phosphors, glass powders and organic vehicles via thorough grinding. Second, the ink paste was spined on a single-crystal sapphire (SA) substrate with high thermal conductivity (∼30 W m<sup>-1</sup> K<sup>-1</sup> ) and then placed on 

Jin et al. Light: Science & Applications (2022) 11:52 

Page 7 of 13 



<!-- Start of picture text -->
a YbNd b 60 c 30 24HD9/27/2 22PP1/23/2 300<br>Er 50 4D5/2 4G9/2 1D2 EM<br>TmNdYbErTm 40 DiG 20 22442PPGGD3/21/25/211/29/2 44422GFFHH7/23/211/29/211/2 1G4 EM 400500<br>30 10 444442GFSFFH9/25/23/23/211/25/2 4444S/FII11/29/29/23/2 333FFH324 EM 2F5/2 6008001000<br>20 4I15/2 4I13/2 33HF45 15002000<br>4I13/2 3000<br>phosphor 0 44II11/29/2 4I15/2 3H6 2F7/2<br>10 Nd Er Tm Yb<br>800 1000 1200 1400 1600 Yb Nd Er Tm NdYbErTm<br>Wavelength (nm)<br>d Mixed phosphors@glass Nd 3+ 4F3/2 e 0 TGDTA 0<br>STE  –15 –5<br>Glass matrixNd 3+ STE:Nd 3+ : 400–900901, 1077, 1367 44II13/211/2 –35 –10<br>4I9/2 –45 –15<br>UV light Er 3+ 2H11/2 –60 –20<br>Yb 3+ STE: Er 3+ : 529, 551, 666,400–900 STE  444ISF9/29/23/2 Yb 3+ 25 200 Temperature (400 °C) 600 800<br>Er 3+         814, 998, 1543,Yb 3+ : 991 44II11/213/2 2F5/2 f<br>2F7/2<br>4I15/2<br>Yb 3+<br>Tm 3+<br>3F3<br>Tm 3+ Tm         1477, 1820STE:  3+ :400–900726, 807, 1227, STE  33HH45 Yb2 3+ F5/2<br>Mixed Ln-doped DPs Yb 3+ : 991 33HF46 2F7/2 240°C 260°C 280°C 300°C 320°C 340°C 360°C<br>g 10 20 30 40 50 60 70 80 h i mixed DPs@glass<br>PLQY=40%<br>phosphor<br>Yb/Tm:DP@glass<br>PLQY=43%<br>Yb/Er:DP@glass<br>DiG PLQY=37%<br>glass Nd:DP@glass<br>PLQY=31%<br>10 20 30 40 50 60 70 80 20  û m<br>600 900 1200 1500 1800 2100<br>2θ(°)<br>Wavelength (nm)<br>PLQY (%)<br>PL intensity (a.u.) 3–1Energy (10)×cm Wavelength (nm)<br>Weight (%)  Heat flow (µV)<br>Intensity (a.u.)<br> PL intensity (a.u.)<br><!-- End of picture text -->

Fig. 3 Design of “DP-in-glass” composite and optimization of the related optical performance. a NIR PL spectra of the Yb, Nd, Er, or Tm singledoped samples and Yb/Nd/Er/Tm multidoped samples. b PLQYs of the corresponding five samples and DiG composite. c Energy-level diagrams of the Nd, Er, Tm, and Yb activators, showing the consistent energy-migration (EM) levels (green, yellow, and blue regions), leading to coquenching PL. d Simplified schematic illustration of the heterogeneous architecture (DP-in-glass). e TG and DTA curves of a typical Bi/Er-doped sample. The insets are the samples sintered at 425 °C and 600 °C, respectively. f Photographs of Bi/Ln:Cs2AgInCl6–DiG–SA composites prepared with different sintering temperatures excited by daylight (top) and UV light (bottom). g XRD patterns of the DP phosphor, the blank glass, and the DiG composite. h Fluorescence image of DiG under UV-light excitation. i PL spectra of different kinds of DiGs 

a heating table for drying. Finally, it was sintered in a muffle furnace at 240–360 °C for a certain duration to obtain the Bi/Ln:Cs2AgInCl6–DiG–SA composite (Fig. 3f). The use of an SA substrate is beneficial for improving the thermal conductivity of the composite film, and the optimized synthesis temperature/time is 300 °C/15 min (Fig. S16). XRD patterns confirm that the added Ln: Cs2AgInCl6 DPs were retained in the glass without obvious decomposition (Fig. 3g). Fluorescence images of 

the composite film (Fig. 3h, Fig. S17) under UV-light excitation show the distribution of luminescent Bi/Ln: Cs2AgInCl6 DP particles inside the nonluminescent glass matrix. Notably, the Bi/Yb/Er:Cs2AgInCl6 microcrystals can be well distinguished from the Bi/Nd:DP and Bi/Yb/ Tm:DP microcrystals for their light-green luminescence (indicated by the arrows) owing to the superimposed Er<sup>3+</sup> emissions on the STE broadband emission (Fig. S17). As shown in Fig. 3i, the PLQY of the mixed multiple Bi/Ln: 

Jin et al. Light: Science & Applications (2022) 11:52 

Page 8 of 13 



<!-- Start of picture text -->
1.2<br>a b d<br>pristine<br>0.9 4 h<br>8 h<br>1.2 W 12 h<br>0.6 24 h<br>48h<br>0.3<br>300 600 900 1200 1500<br>Wavelength (nm)<br>0.0<br>0 200 400 600 800 1000 1200<br>Time (hours)<br>c e 1.6<br>Er Er Operating voltage: 6 V 6.0<br>Er Yb<br>Er Tm 1.2 4.5<br>Nd<br>3.0<br>Nd 0.8<br>STE<br>chip 1.5<br>Tm Tm 0.4 chip emitting range (320~380 nm)<br>Nd Tm Vis-NIR range (380~1700 nm)<br>0.2 0.0<br>0 50 100 150 200 250 300<br>300 600 900 1200 1500 1800<br>Operating current (mA)<br>Wavelength (nm)<br>EL Intensity (a.u.)<br>Integrated intensity (a.u.)<br>PL intensity (a.u.)<br>Integrated chip intensity (a.u.)<br>Integrated Vis-NIR intensity (a.u.)<br><!-- End of picture text -->

Fig. 4 Construction of ultrabroadband LED based on Bi/Ln:DP@glass composite. Photographs of the constructed Bi/Ln:DP@glass-based LED device with an operating current of 200 mA taken by (a) a visible-light camera and (b) NIR camera. c PL spectrum of the LED device. d Dependence of the PL intensity of the LED on the exposure time in air. The inset shows the PL spectra of LEDs continuously operating for 48 h. e Dependence of the UV-emitting intensity of the chip and Vis–NIR-emitting intensity of DiP on the operating current from 20 to 350 mA 

DPs in glass is comparable to those of the only one type of DP-embedded glasses, confirming the successful inhibition of adverse energy transfer by isolating different Ln<sup>3+</sup> dopants in diverse DPs. As a consequence, the PLQY (~40%) of the three types of DP-(Nd:DP, Yb/Er:DP, and Yb/Er:DP) embedded glass is much higher than that of the Nd/Yb/Er/Tm multidoped DP phosphor (~13%, Fig. 3b). 

In a further work, a light-emitting diode (LED) was fabricated by coupling the prepared DiG with a commercial 350 nm UV chip, which can produce brightyellow light visible to the naked eye (Fig. 4a) and intense NIR light observable by a night-vision camera (Fig. 4b). The PL spectra of the operating device show one narrow UV emission assigned to the chip, a broadband visible emission assigned to STE recombination, and many narrowband emissions ascribed to the Er<sup>3+</sup> , Nd<sup>3+</sup> , Yb<sup>3+</sup> , and Tm<sup>3+</sup> 4f–4f transitions (Fig. 4c), covering the ultrabroad spectral region from 400 to 2000 nm with a full width at half-maximum (FWHM) of ~365 nm. The NIR emission located at ~1820 nm with a decay lifetime of 6.69 ms is assigned to the Tm<sup>3+</sup> :<sup>3</sup> F4 →<sup>3</sup> H6 transition (Fig. S18). To the best of our knowledge, this is the first report on an ultrabroadband light source based on the combination of Ln<sup>3+</sup> dopants and DP. Importantly, the 

PL intensity remained almost unchanged after the device was exposed to air for 1200 h (Fig. 4d), confirming its super long-term stability. In fact, the DiG composite is stable after exposure to air for 180 days (Fig. S19). Moreover, after continuous operation for 48 h, only slight thermal quenching for STE emission occurred, and no obvious changes in the Ln<sup>3+</sup> emissions were observed in the PL spectra (inset of Fig. 4d). The STE emission is sensitive to temperature (Fig. S20a), and the increased temperature of the UC chip during operation leads to a certain degree of PL quenching. Additionally, the 4f orbitals of the Ln<sup>3+</sup> ions are shielded from the surroundings by the filled 5s<sup>2</sup> and 5p<sup>6</sup> orbitals. Therefore, the influence of temperature on the optical transitions within the 4f<sup>n</sup> configuration is small since there is no crossover point between the excited state and the ground state in the Ln<sup>3+</sup> configuration<sup>13</sup> . In this case, no obvious change in the Ln<sup>3+</sup> PL intensity was detected with increasing temperature, while PL quenching of STE was observed since exciton recombination is highly sensitive to temperature (Fig. S20b). Fortunately, the temperature of the constructed u-LED with long-term operation is stable (remained below 30 °C) owing to the use of a cooling fan (Fig. S21). Therefore, thermal quenching only 

Jin et al. Light: Science & Applications (2022) 11:52 

Page 9 of 13 

subtly impacted the u-LED performance after several weeks. The excellent stability of the device is ascribed to the effective protection of the inorganic glass matrix for the Bi/Ln:Cs2AgInCl6 color converters, which inhibits the decomposition of and damage to the DPs upon exposure to external stimuli. As shown in Fig. 4e, both the UV and NIR emissions increased monotonically with increasing operating current from 20 mA to 200 mA and tended to be stable for higher input currents owing to the saturation of the commercial 350 nm UV chip. 

Finally, we demonstrate the promising applications of this compact ultrabroadband LED (u-LED) in nondestructive spectroscopic analysis and multifunctional lighting. The absorption spectra of some substances, such as water, ethyl alcohol (EtOH), plum, tomato, grape, and white/yellow egg, were measured using the u-LED as the light source. The sample was placed inside an integrating sphere equipped with the u-LED and a fiber-coupled spectrometer (Fig. 5a). The absorption spectrum of the sample was obtained by subtracting the emission spectrum of the u-LED recorded without the sample from that recorded with the sample. As shown in Fig. 5b, the absorption of water and EtOH in the visible spectral region is negligible, and several NIR-absorption peaks located at 810 nm, 994 nm, 1220 nm, and 1545 nm are observed. In comparison, the fruits and eggs showed strong absorption in the visible spectral range in addition to NIR-absorption peaks; these absorption signals were similar to those observed in water and EtOH (Fig. 5c). The visible absorption intensity of dark-red plum, red tomato, and green grape decreases in sequence, which is probably due to the relationship between the color of fruits and the absorption of visible light by phytochromes. A similar phenomenon can be observed for eggs with different apparent colors (white and red), where the visible absorption of white eggs is remarkably lower than that of red eggs. The exact origin of absorption is not discussed, and quantitative analysis is not performed in the present work due to its complexity and because it is beyond the scope of this research. Figure 5d and Fig. S22 present photographs of fruits and palms taken via different cameras (visible camera and NIR camera). No image can be captured by either camera when the u-LED is off (middle of Fig. 5d). In contrast, when the u-LED lamp is lightened, the colorful image (left of Fig. 5d, Fig. S22a) and blackand-white image (right of Fig. 5d, Fig. S22b) are easily detected by the visible camera and NIR camera, respectively. This kind of dual-modal lighting based on u-LED is ascribed to its broadband emissions covering both visible and NIR spectral regions. In addition, when the light from the u-LED is passed through the palm and fingers, the venous blood vessels in the palm and fingers are discerned by the NIR camera (Fig. 5e, Fig. S22) owing to the loss of NIR light absorbed by the chromophores in the blood. 

### Conclusions 

In summary, a family of Ln<sup>3+</sup> ions and Bi<sup>3+</sup> ions was successfully doped into Cs2AgInCl6 DP microcrystals prepared by a modified coprecipitation method. Bi<sup>3+</sup> ions were easily incorporated into DPs by substituting In<sup>3+</sup> , while Ln<sup>3+</sup> doping resulted in a saturation concentration of ~2.5 mol%. Bi<sup>3+</sup> doping can decrease the excitation energy to the UV region (330–400 nm) for STE recombination and significantly promote the PLQY from ~1% to ~25% owing to the Bi<sup>3+</sup> -doping-induced modification of the band-edge structure of Cs2AgInCl6 DP. Importantly, Ln<sup>3+</sup> codoping can further increase the PLQY to 43~56% owing to the superimposition of the additional Ln<sup>3+</sup> emissions on the broadband STE luminescence. A series of spectroscopic characterizations evidence the different energy-transfer channels for STE emission and Ln<sup>3+</sup> 4f–4f emissions, where the former is attributed to energy transfer from band-edge to STE state and the latter is due to energy transfer from Bi<sup>3+</sup> in the 6s<sup>1</sup> 6p<sup>1</sup> state to the Ln<sup>3+</sup> multiplets. In this case, Nd/Yb/Er/Tm multidoping in Bi:DP can produce ultrabroadband luminescence covering the Vis and NIR spectral regions. Furthermore, a DiG composite was fabricated by dispersing diverse Nd: DP, Yb/Er:DP, and Yb/TmDP in an inorganic glass matrix to spatially confine the various Ln<sup>3+</sup> dopants, which is beneficial for inhibiting the coquenching PL for multiple Ln<sup>3+</sup> ions in a single DP host. Finally, the DiP-based light source was designed; it exhibited a commercial UV chip with excitable ultrabroadband (400 ~ 2000 nm) electroluminescence. This compact u-LED has a low cost, is easy to manufacture, is nontoxic, exhibits excellent optoelectronic performance, and is stable; therefore, it provides practicality, commercialization, and industrialization in multifunctional lighting and nondestructive spectral analysis. 

### Methods 

#### Chemicals 

Indium(III) trichloride (InCl3, Shanghai Macklin Chem. Co., LTD., 99.9%), bismuth trichloride (BiCl3, Macklin, 99.9%), silver chloride (AgCl, Macklin, 99.5%), hydrochloric acid (HCl, Hushi, 99.99%), cesium chloride (CsCl, Macklin, 99.9%), and lanthanide(III) chloride hexahydrate (LnCl3·6H2O, Ln=La–Lu, Beijing HWRK Chem. Co., LTD., 99.99%). All of the chemicals were used without further purification. 

#### Synthesis of Bi<sup>3+</sup> -doped Cs2AgInCl6 

Before the reaction, a shaded and heat-resistant glass bottle was prepared in advance to prevent the oxidation of silver chloride (movie 1). First, different amounts of BiCl3 (0, 0.003, 0.006, 0.012, 0.024, 0.036, 0.048, 0.060, and 0.100 mmol), 0.25 mmol of InCl3, 0.25 mmol of AgCl, and 4 mmol of 12 M HCl were added to an 8 mL glass bottle. 

Jin et al. Light: Science & Applications (2022) 11:52 

Page 10 of 13 



<!-- Start of picture text -->
a b<br>u-LED u-LED<br>Detector<br>water EtOH<br>LED<br>Integrating sphere 500 700 900 1100 1300 1500 500 700 900 1100 1300 1500<br>Wavelength (nm) Wavelength (nm)<br>c u-LED u-LED u-LED u-LED<br>plum tomato grape white eggyellow egg<br>white egg<br>yellow egg<br>500 700 900 1100 1300 1500 500 700 900 1100 1300 1500 500 700 900 1100 1300 1500 500 700 900 1100 1300 1500<br>Wavelength (nm) Wavelength (nm) Wavelength (nm) Wavelength (nm)<br>d u-LED on u-LED off u-LED on<br>Visible camera Visible & NIR  NIR camera<br>e<br>u-LED<br> NIR camera<br>Vis-NIR<br>Optical-fiber USB<br>PL intensity (a.u.)<br>PLΔ<br>PL intensity (a.u.)<br>PLΔ<br><!-- End of picture text -->

Fig. 5 Application demonstration of Bi/Ln:DP-based ultrabroadband LED. a Schematic diagram of the experimental setup for measuring absorption. PL spectra with and without the measured substance inside the integrated sphere using u-LED as the light source: (b) water and EtOH, (c) plum, tomato, grape, and eggs. ΔPL is defined as PL(u-LED) - PL(u-LED + substance). d Photos of fruits with and without u-LED irradiation recorded by visible and NIR cameras. e Photos of palm and finger after transillumination of NIR light from u-LED 

Jin et al. Light: Science & Applications (2022) 11:52 

Page 11 of 13 

Second, the glass bottle was placed in an oil bath pan at 100 °C and stirred vigorously, until all the powders in the reaction mixture were completely dissolved. Third, 0.5 mmol CsCl was dissolved in 1 mL of 12 M HCl and swiftly injected into the glass bottle to produce the products. The reaction continued for another 20 min to ensure that it was complete. Then, the glass bottle was magnetically stirred at room temperature for 10 min. The crude microcrystalline solution was centrifuged at 10000 rpm for 5 min, and the supernatant was discarded. The residual sediment was washed twice with ethanol, and the solution was then centrifuged at 10000 rpm for 10 min. Finally, the precipitates were dried at 80 °C in a drying oven overnight and then stored. 

monolithic composite, where Nd:Cs2AgInCl6, Yb/Er: Cs2AgInCl6, and Yb/Tm:Cs2AgInCl6 DPs are codispersed inside an inorganic glass matrix. 

#### Fabrication of DiG-based LEDs 

The compact ultrabroadband-emitting light-emitting diode (u-LED) was constructed by coupling the prepared monolithic DiG layer with a commercial 350 nm UV chip by placing the DiG on the surface of the UV chip. A cooling fan was adhered to the back of the UV chip to reduce the thermal accumulation upon operation. The opaque silica gels were filled around the edges between DiG and the UV chip to prevent the leakage of UV light. 

#### Characterizations 

#### Synthesis of Bi/Er codoped Cs2AgInCl6 

The synthesis process was similar to that of Bi<sup>3+</sup> -doped Cs2AgInCl6. The only difference was that the BiCl3 content was fixed at 0.048 mmol, and different amounts of ErCl3 (0, 0.25, 0.50, 0.75, 1.00, and 1.25 mmol) were added. 

#### Synthesis of Bi/Ln (Ln=La–Lu) codoped Cs2AgInCl6 

The synthesis process was similar to that of Bi<sup>3+</sup> -doped Cs2AgInCl6. The only difference was that the BiCl3 and LnCl3 contents were fixed at 0.048 mmol and 0.75 mmol, respectively. 

#### Synthesis of Bi/Yb/Ln (Ln=Er, Tm, or Ho) triple-doped Cs2AgInCl6 

The synthesis process was similar to that of Bi<sup>3+</sup> -doped Cs2AgInCl6. The only difference was that the BiCl3, YbCl3, and LnCl3 (Ln=Er<sup>3+</sup> , Tm<sup>3+</sup> or Ho<sup>3+</sup> ) contents were fixed at 0.048 mmol, 0.75 mmol and 0.75 mmol, respectively. 

#### Synthesis of Bi/Nd/Yb/Er/Tm multidoped Cs2AgInCl6 

The synthesis process was similar to that of Bi<sup>3+</sup> -doped Cs2AgInCl6. The only difference was that the BiCl3 content was fixed at 0.048 mmol and all LnCl3 contents were fixed at 0.75 mmol. 

#### Fabrication of Bi/Ln:Cs2AgInCl6@glass 

First, diethylene glycol monobutyl ether acetate (DBAC), ethyl cellulose (EC), and terpineol precursors were added to a glass bottle. Then, the slurry was heated to 80 °C for at least 50 min to fully react. In addition, the inorganic glass frits with compositions of SiO2–Na2O–K2O–ZnO and the Bi-/Ln-doped DP phosphors were ground with a small amount of the above-mentioned slurry for 20 min and then spined on the single-crystal sapphire. Finally, the composite film was sintered in a muffle furnace at 240–360 °C for 15/30 min to obtain DP-in-glass (DiG). Notably, for ultrabroadband LED applications, DiG is a 

X-ray diffraction (XRD) analysis was carried out to identify Bi/Ln:Cs2AgInCl6 crystalline-phase structures using a Bruker D8 Advance X-ray powder diffractometer with Cu Kα radiation (λ = 0.154 nm) operating at 40 kV. The actual chemical compositions were measured by inductively coupled plasma–mass spectrometry (ICP–MS) using a PerkinsElmer Optima 3300DV spectrometer. The microstructures of the samples were characterized by scanning electron microscopy (SEM) equipped with an energy-dispersive X- ray (EDX) spectroscopy system and were visualized via fluorescence images using optical microscopy (Nikon, Eclipse, Ti2) coupled with a spectrofluorometer. The elemental analysis of Bi/Ln:Cs2AgInCl6 was performed by X-ray photoelectron spectroscopy (XPS) using a VG Scientific ESCA Lab Mark II spectrometer equipped with two ultrahigh vacuum-6 (UHV) chambers. All the binding energies were referenced to the C1s peak of the adventitious carbon on the surface at 284.8 eV.<sup>133</sup> Cs and<sup>115</sup> In magicangle-spinning nuclear magnetic resonance (MAS-NMR) spectra were recorded using Bruker ADVANCE III HD 400 spectrometers. The diffuse-reflectance spectra were recorded on a spectrophotometer (Lambda900, PerkinElmer) with a resolution of 1 nm. Thermogravimetric analyses (TGA) were conducted on a Netzsch STA449C thermal analysis system under a N2 flow with a heating rate of 10 °C min<sup>−1</sup> . Photoluminescence (PL) spectra, PL-excitation (PLE) spectra and decay curves were recorded on an Edinburgh Instruments FLS1000 spectrofluorometer equipped with a continuous xenon lamp (450 W), a pulsed flash lamp, and a 375 nm picosecond pulsed laser. Middle-infrared (MIR) PL emission spectra and decay curves were measured with a customized UV to mid-infrared steady-state and phosphorescence-lifetime spectrometer (FSP920-C, Edinburgh) equipped with a tuneable midband optical parametric oscillator pulsed laser as the excitation source (210–2400 nm, 10 Hz, pulse width ≤5 ns, Opolette<sup>TM</sup> HE355UV, OPOTEK). The absolute photoluminescence quantum yields (PLQYs) of the samples were obtained by employing a standard barium sulfate-coated integrating 

Jin et al. Light: Science & Applications (2022) 11:52 

Page 12 of 13 

sphere (150 mm in diameter, Edinburgh) as the sample chamber that was mounted on the FLS1000 spectrometer with the entry and output port of the sphere located at a 90° angle from each other in the plane of the spectrometer. A standard tungsten lamp was used to correct the optical response of the instrument. All the spectral data were collected at RT and corrected for the spectral response of both the spectrometer and the integrating sphere. PLQY(450–1600 nm) of Ln:DP covering the Vis–NIR broad spectral range equals the sum of PLQY(450–930 nm) and PLQY(930–1600 nm). PLQY(930–1600 nm) was determined by the expression PLQY(650–930 nm) × I(930–1600 nm)/I(650–930 nm). Note that the integral intensities for both I(930–1600 nm) and I(650–930 nm) here come from the same near-infrared spectra (620–1650 nm). PL spectra of the UV LED chip and the fabricated u-LED were measured using a Keithley 2400 source and an integrating sphere equipped with an FLS1000 spectrofluorometer. 

##### Acknowledgements 

This research was supported by the National Natural Science Foundation of China (51972060, U1805252, and 22135008), the Fujian Science & Technology Innovation Laboratory for Optoelectronic Information (2021ZZ126), and the Natural Science Foundation of Fujian Province (2020J02017, 2021L3024). 

##### Author details 

1College of Physics and Energy, Fujian Normal University, Fujian Provincial Key Laboratory of Quantum Manipulation and New Energy Materials, Fuzhou 350117, China.<sup>2</sup> Fujian Science & Technology Innovation Laboratory for Optoelectronic Information, Fuzhou 350116, China.<sup>3</sup> CAS Key Laboratory of Design and Assembly of Functional Nanostructures, Fujian Key Laboratory of Nanomaterials and State Key Laboratory of Structural Chemistry, Fujian Institute of Research on the Structure of Matter, Chinese Academy of Sciences, Fuzhou, Fujian 350002, China.<sup>4</sup> Fujian Provincial Collaborative Innovation Center for Advanced High-Field Superconducting Materials and Engineering, Fuzhou 350117, China.<sup>5</sup> Fujian Provincial Engineering Technology Research Center of Solar Energy Conversion and Energy Storage, Fuzhou 350117, China. 6College of Chemistry, Fuzhou University, Fuzhou 350116, China 

##### Author contributions 

D. C. and X. C. conceived, designed and supervised the overall project. S. J. and R. L. conducted the experiments, and S. J. and R. L. wrote the paper. H. H. and N. J. performed optical spectroscopic characterizations. All the authors discussed the results and commented on the paper. 

##### Conflict of interest 

The authors declare that they have no competing interest. 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41377-022-00739-2. 

Received: 30 November 2021 Revised: 10 February 2022 Accepted: 13 February 2022 



3. Joos, J. J. et al. Broadband infrared LEDs based on europium-to-terbium charge transfer luminescence. Nat. Commun. 11, 3647 (2020). 

4. Tikhomirov, V. K. et al. Broadband telecommunication wavelength emission in Yb<sup>3+</sup> -Er<sup>3+</sup> -Tm<sup>3+</sup> co-doped nano-glass-ceramics. Opt. Express 15, 9535–9540 (2007). 

5. Zhou, S. F. et al. Multifunctional bismuth-doped nanoporous silica glass: from blue-green, orange, red, and white light sources to ultra-broadband infrared amplifiers. Adv. Funct. Mater. 18, 1407–1413 (2008). 

6. Jones, D. J. et al. Carrier-envelope phase control of femtosecond mode-locked lasers and direct optical frequency synthesis. Science 288, 635–639 (2000). 

7. Rajendran, V. et al. Ultra-broadband phosphors converted near-infrared light emitting diode with efficient radiant Power for spectroscopy applications. ACS Photonics 6, 3215–3224 (2019). 

8. Rajendran, V. et al. Super broadband near-infrared phosphors with high radiant flux as future light sources for spectroscopy applications. ACS Energy Lett. 3, 2679–2684 (2018). 

9. Lukovic, M. et al. LED-based vis-NIR spectrally tunable light source - the optimization algorithm. J. Eur. Optical Soc. Rapid Publ. 12, 19 (2016). 

10. Gmachl, C. et al. Ultra-broadband semiconductor laser. Nature 415, 883–887 (2002). 

11. Ye, X. et al. In Proceedings of SPIE 10758, Nonimaging Optics: Efficient Design for Illumination and Solar Concentration XV (SPIE, 2018). 

12. Wadsworth, W. J. et al. Supercontinuum generation in photonic crystal fibers and optical fiber tapers: a novel light source. J. Optical Soc. Am. B 19, 2148–2155 (2002). 

13. Blasse, G. & Grabmaier, B. C. Luminescent Materials (Springer-Verlag, 1994). 

14. Htein, L. et al. Amplification by white light-emitting diode pumping of largecore Er-doped fiber with 12 dB gain. Opt. Lett. 37, 4853–4855 (2012). 

15. Hu, J. et al. Highly efficient cascaded amplification using Pr<sup>3+</sup> -doped midinfrared chalcogenide fiber amplifiers. Opt. Lett. 40, 3687–3690 (2015). 

16. Aitken, B. G., Dejneka, M. J. & Powley, M. L. Tm-doped alkaline earth aluminate glass for optical amplification at 1460 nm. J. Non Cryst. Solids 349, 115–119 (2004). 

17. Marin, R. & Jaque, D. Doping lanthanide ions in colloidal semiconductor nanocrystals for brighter photoluminescence. Chem. Rev. 121, 1425–1462 (2021). 

18. Pan, G. C. et al. Doping lanthanide into perovskite nanocrystals: highly improved and expanded optical properties. Nano Lett. 17, 8005–8011 (2017). 

19. Milstein, T. J., Kroupa, D. M. & Gamelin, D. R. Picosecond quantum cutting generates photoluminescence quantum yields over 100% in ytterbium-doped CsPbCl3 nanocrystals. Nano Lett. 18, 3792–3799 (2018). 

20. Zhou, D. L. et al. Cerium and ytterbium codoped halide perovskite quantum dots: a novel and efficient downconverter for improving the performance of silicon solar cells. Adv. Mater. 29, 1704149 (2017). 

21. Kroupa, D. M. et al. Quantum-cutting ytterbium-doped CsPb(Cl1-xBrx)3 perovskite thin films with photoluminescence quantum yields over 190%. ACS Energy Lett. 3, 2390–2395 (2018). 

22. Wei, Y., Cheng, Z. Y. & Lin, J. An overview on enhancing the stability of lead halide perovskite quantum dots and their applications in phosphor-converted LEDs. Chem. Soc. Rev. 48, 310–350 (2019). 

23. Wang, X. C. et al. Perovskite quantum dots for application in high color gamut backlighting display of light-emitting diodes. ACS Energy Lett. 5, 3374–3396 (2020). 

24. Creutz, S. E. et al. Colloidal nanocrystals of lead-free double-perovskite (elpasolite) semiconductors: synthesis and anion exchange to access new materials. Nano Lett. 18, 1118–1123 (2018). 

25. Nila Nandha, K. & Nag, A. Synthesis and luminescence of Mn-doped Cs2AgInCl6 double perovskites. Chem. Commun. 54, 5205–5208 (2018). 

26. Zhou, B. et al. Efficient white photoluminescence from self-trapped excitons in Sb<sup>3+</sup> /Bi<sup>3+</sup> -codoped Cs2NaInCl6 double perovskites with tunable dualemission. ACS Energy Lett. 6, 3343–3351 (2021). 

27. Volonakis, G. et al. Cs2InAgCl6: a new lead-free halide double perovskite with direct band gap. J. Phys. Chem. Lett. 8, 772–778 (2017). 

##### References 

1. Rizzo, A. et al. Ultra-broadband interleaver for extreme wavelength scaling in silicon photonic links. IEEE Photonics Technol. Lett. 33, 55–58 (2021). 

2. Hayashi, D. et al. A broadband LED source in visible to short-wave-infrared wavelengths for spectral tumor diagnostics. Appl. Phys. Lett. 110, 233701 (2017). 

28. Meng, W. W. et al. Parity-forbidden transitions and their impact on the optical absorption properties of lead-free metal halide perovskites and double perovskites. J. Phys. Chem. Lett. 8, 2999–3007 (2017). 

29. Liu, Y. et al. Lead-free double perovskite Cs2AgInCl6. Angew. Chem. Int. Ed. 60, 11592–11603 (2021). 

30. Luo, J. J. et al. Efficient and stable emission of warm-white light from lead-free halide double perovskites. Nature 563, 541–545 (2018). 

Jin et al. Light: Science & Applications (2022) 11:52 

Page 13 of 13 

31. Lee, W., Hong, S. & Kim, S. Colloidal synthesis of lead-free silver-indium doubleperovskite Cs2AgInCl6 nanocrystals and their doping with lanthanide ions. J. Phys. Chem. C 123, 2665–2672 (2019). 

32. Mahor, Y., Mir, W. J. & Nag, A. Synthesis and near-infrared emission of Ybdoped Cs2AgInCl6 double perovskite microcrystals and nanocrystals. J. Phys. Chem. C 123, 15787–15793 (2019). 

33. Chen, N. et al. Yb- and Mn-doped lead-free double perovskite Cs2AgBiX6 (X = Cl<sup>−</sup> , Br<sup>−</sup> ) nanocrystals. ACS Appl. Mater. Interfaces 11, 16855–16863 (2019). 

34. Li, S. R. et al. Self-trapped exciton to dopant energy transfer in rare earth doped lead-free double perovskite. Adv. Opt. Mater. 7, 1901098 (2019). 

35. Wang, C. Y. et al. Highly efficient lead-free (Bi, Ce)-codoped Cs2Ag0.4Na0.6InCl6 double perovskites for white light-emitting diodes. Chem. Mater. 32, 7814–7821 (2020). 

36. Schmitz, F. et al. Lanthanide-induced photoluminescence in lead-free Cs2AgBiBr6 bulk perovskite: insights from optical and theoretical investigations. J. Phys. Chem. Lett. 11, 8893–8900 (2020). 

37. Arfin, H. et al. Bi<sup>3+</sup> -Ln<sup>3+</sup> (Ln = Er and Yb) codoped Cs2AgInCl6 double perovskite near -infrared emitter. Angew. Chem. Int. Ed. 59, 11307–11311 (2020). 

38. Liu, Y. et al. Incorporating rare-earth terbium(III) ions into Cs2AgInCl6:Bi nanocrystals toward tunable photoluminescence. Angew. Chem. Int. Ed. 59, 11634–11640 (2020). 

39. Yao, M. M. et al. Improving lead-free double perovskite Cs2NaBiCl6 nanocrystal optical properties via ion doping. Adv. Opt. Mater. 8, 1901919 (2020). 

40. Zhang, G. D. et al. Facile solution synthesis of Bi<sup>3+</sup> /Yb<sup>3+</sup> ions co-doped Cs2Na0.6Ag0.4InCl6 double perovskites with near-infrared emission. Dalton Trans. 49, 15231–15237 (2020). 

41. Zeng, Z. C. et al. Multimodal luminescent Yb<sup>3+</sup> /Er<sup>3+</sup> /Bi<sup>3+</sup> -doped perovskite single crystals for X-ray detection and anti-counterfeiting. Adv. Mater. 32, 2004506 (2020). 

42. Yang, S. et al. Bi and Yb codoped Cs2Ag0.6Na0.4InCl6 microcrystals: visible to near-infrared fluorescence for thermometry. J. Phys. Chem. C 125, 10431–10440 (2021). 

43. Zhang, R. L. et al. All-inorganic rare-earth halide double perovskite single crystals with highly efficient photoluminescence. Adv. Opt. Mater. 9, 2100689 (2021). 

44. Yin, H. et al. Lead-free rare-earth double perovskite Cs2AgIn1-γ-xBixLaγCl6 nanocrystals with highly efficient warm-white emission. Sci. China Mater. 64, 2667–2674 (2021). 

45. Wang, Z. L. et al. Cerium doping double perovskite scintillator for sensitive X-ray detection and imaging. Chem. A Eur. J. 27, 9071–9076 (2021). 

46. Zhou, J. et al. Manipulation of Bi<sup>3+</sup> /In<sup>3+</sup> transmutation and Mn<sup>2+</sup> -doping effect on the structure and optical properties of double perovskite Cs2NaBi1x<sup>In</sup> x<sup>Cl</sup> 6<sup>.Adv.Opt.Mater. 7,1801435(2019).</sup> 

47. Han, P. G. et al. Size effect of lead-free halide double perovskite on luminescence property. Sci. China Chem. 62, 1405–1413 (2019). 

48. Hu, Q. S. et al. Tunable color temperatures and efficient white emission from Cs2Ag1−xNaxIn1−yBiyCl6 double perovskite nanocrystals. Small 15, 1903496 (2019). 

49. Zhu, W. J. et al. Low-dose real-time X-ray imaging with nontoxic double perovskite scintillators. Light Sci. Appl. 9, 112 (2020). 

50. Yang, B. et al. Lead-free direct band gap double-perovskite nanocrystals with bright dual-color emission. J. Am. Chem. Soc. 140, 17001–17006 (2018). 

51. Kubicki, D. J. et al. Phase segregation in Cs‑, Rb- and K‑doped mixed-cation (MA)x(FA)1−xPbI3 Hybrid perovskites from solid-state NMR. J. Am. Chem. Soc. 139, 14173–14180 (2017). 

52. Xiang, W. C. et al. Europium-doped CsPbI2Br for stable and highly efficient inorganic perovskite solar cells. Joule 3, 205–214 (2019). 

53. Karmakar, A. et al. Tailorable indirect to direct band-gap double perovskites with bright white-light emission: decoding chemical structure using solidstate NMR. J. Am. Chem. Soc. 142, 10780–10793 (2020). 

54. Awater, R. H. P. & Dorenbos, P. The Bi<sup>3+</sup> 6s and 6p electron binding energies in relation to the chemical environment of inorganic compounds. J. Lumin. 184, 221–231 (2017). 

55. Liu, Y. et al. Design optimization of lead-free perovskite Cs2AgInCl6:Bi nanocrystals with 11.4% photoluminescence quantum yield. Chem. Mater. 31, 3333–3339 (2019). 

56. Pan, Q. W. et al. Engineering tunable broadband near-infrared emission in transparent rare-earth doped nanocrystals-in-glass composites via a bottomup strategy. Adv. Optical Mater. 7, 1801482 (2019). 

57. Lin, J. et al. Research progresses in preparation and applications of CsPbX3 (X=Cl, Br, I) perovskite quantum dots-embedded glass. Chin. J. Lumin. 42, 1331–1344 (2021). 

58. Lin, J. D. et al. Perovskite quantum dots glasses based backlit displays. ACS Energy Lett. 6, 519–528 (2021). 

