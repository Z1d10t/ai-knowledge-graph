# Thermal evaporation and hybrid deposition of perovskite solar cells and mini-modules

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Joule |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 166 |
| 作者 | F. Kosasih, E. Erdenebileg, N. Mathews, S. Mhaisalkar, A. Bruno |
| DOI | 10.1016/j.joule.2022.11.004 |
| 源文件 | 068_Kosasih_2022_Thermal-evaporation-and-hybrid-deposition-of-per.pdf |

---
**ll** 

### Review 

# Thermal evaporation and hybrid deposition of perovskite solar cells and mini-modules 

Felix Utama Kosasih,<sup>1</sup> Enkhtur Erdenebileg,<sup>1</sup> Nripan Mathews,<sup>1,2</sup> Subodh G. Mhaisalkar,<sup>1,2</sup> and Annalisa Bruno<sup>1,</sup> * 

#### SUMMARY 

The development of perovskite photovoltaics has so far been led by solution-based coating techniques, such as spin-coating. However, there has been an increasing interest in thermal evaporation (TE) as an industrially compatible method to fabricate perovskite solar cells (PSCs). TE has several advantages compared with solution processing, including a high degree of process control, excellent film uniformity, low material consumption, conformal substrate coverage, a lack of toxic solvents, and superb device reproducibility and scalability. These benefits make TE an ideal choice to upscale lab-scale PSCs into modules. Here, we discuss three types of TEbased perovskite deposition techniques, namely 1-step TE, multistep all-TE, and multistep hybrid of TE-gas reaction and TE-solution processing. We summarize their fundamental principles and applications, first on small-area PSCs and then on modules. Finally, we provide our outlook on important research topics for TE PSCs, namely device interlayers, defect passivation, and device stability. 

#### INTRODUCTION 

Fabrication versatility is often cited as one of the primary advantages of hybrid halide perovskites as a photovoltaic (PV) material. Indeed, amenability to a wide variety of relatively simple and cheap deposition techniques is one of the reasons so many research groups can contribute to the development of perovskite solar cells (PSCs). These techniques are broadly classified into two main groups: solutionand vapor-based techniques. Solution processing was responsible for the genesis of perovskite PV and it remains by far the more popular fabrication pathway at the point of this review’s writing.<sup>1</sup> Similarly, the list of power conversion efficiency (PCE) record-breaking PSCs is still dominated by spin-coated cells for small-area devices (Figure 1A; Table S1). However, spin-coating is highly wasteful and inherently unsuitable for upscaling, meaning that other methods must be developed for the industrial-scale manufacture of perovskite PV devices. Scalable solution-processing techniques like blade-coating, slot die-coating, and spray-coating have produced highly efficient cells (Figure 1A; Table S1), but these methods are often reliant on toxic or otherwise hazardous solvents such as N,N-dimethylformamide (DMF) and N,N-dimethylacetamide (DMAC), among others.<sup>7</sup> 

#### CONTEXT & SCALE 

Halide perovskites have revolutionized photovoltaics with their advantageous optoelectronic properties and low fabrication cost. The state-of-theart efficiency and stability have been achieved largely with spincoated perovskite solar cells (PSCs). However, spin-coating is wasteful and unsuitable for largearea and high-yield fabrication. Industrially compatible methods to upscale lab-sized (<1 cm<sup>2</sup> ) PSCs to modules could enable perovskites to make an impact on the global energy landscape. Methods based on vacuum deposition and already implemented in optoelectronics industries, such as thermal evaporation (TE), are promising for high-throughput manufacturing. This review introduces the readers to perovskite deposition methods based on TE, including hybrid approaches such as TE-gas reaction and TE-solution processing. The prevailing research directions, seminal advances, and pathways toward high-performance perovskite devices are discussed with a view to bringing this technology to the market. 

Recently, the research effort invested in the vapor deposition of halide perovskites has been growing rapidly, particularly where the vaporization is achieved through heating (as opposed to a laser or an electron beam).<sup>8</sup> This family of deposition methods is commonly known as thermal evaporation (TE). For the formation of organic-inorganic and fully inorganic halide perovskites, these methodologies can 



2692 Joule 6, 2692–2734, December 21, 2022 ª 2022 Elsevier Inc. 

**ll** 

### Review 



Figure 1. State-of-the-art of perovskite solar cell and perovskite deposition methods (A) Evolution of record PCE achieved by PSCs fabricated using various perovskite deposition methods. See also Table S1. 

(B) Illustrations of common perovskite deposition methods. The solution-processing techniques are shown on the left side in red boxes, while the TE techniques are shown on the right side in blue boxes. The figures in (B) are reproduced with permission from Deng et al.,<sup>2</sup> copyright 2018 Springer Nature; Rana et al.,<sup>3</sup> copyright 2022 Wiley-VCH; Pasquarelli et al.,<sup>4</sup> copyright 2011 Royal Society of Chemistry; Luo et al.,<sup>5</sup> copyright 2018 Royal Society of Chemistry; and Wang et al.,<sup>6</sup> copyright 2018 Wiley-VCH. 

be divided by the number of deposition steps into single step (1-step) and multistep TE. In the former, either all the precursors are evaporated at the same time and allowed to react on the substrate (co-evaporation), or the desired product is prepared beforehand and then evaporated onto a substrate (single-source TE). In multistep TE, different precursors are evaporated in turn, hence it is also known as sequential evaporation. Finally, TE may be combined with gas reaction or solution-based deposition method(s) to form perovskites through a multistep hybrid path. A schematic division and illustrations of various TE methods are shown in Figure 1B. 

Through the aforementioned increase in interest, TE has been shown to possess several important advantages, such as precise control of the growth environment and growth rate of various perovskite precursors, highly reproducible film thickness, film uniformity over a large area, complete and conformal substrate coverage, 

> 1Energy Research Institute @ NTU, Nanyang Technological University, Research Techno Plaza, 50 Nanyang Drive, Singapore 637553, Singapore 2School of Materials Science and Engineering, Nanyang Technological University, Singapore 639798, Singapore 

*Correspondence: annalisa@ntu.edu.sg https://doi.org/10.1016/j.joule.2022.11.004 

Joule 6, 2692–2734, December 21, 2022 2693 

**ll** 

Review 



Figure 2. The schematic outline of this review This work discusses three groups of TE-based device fabrication methods. These methods can be used to scale up perovskite PV devices from lab-scale cells to mini-modules. 

minimum material waste, and amenability to a wide range of substrates, such as transparent conductive oxide (TCO)-coated glass, flexible metal or plastic foils, and textured silicon. All these lead to high-quality perovskite films and high-performance solar cells. Moreover, TE features a lack of hazardous solvents, simple upscaling, and ease of integration into existing industrial manufacturing lines. 

At first glance, it may seem that these advantages rarely translate into highly efficient TE cells, at least when compared with solution-processed devices (Figure 1A; Table S1). However, TE PSCs have exhibited smaller PCE losses upon device area upscaling compared not only with solution-deposited PSCs but also with established PV technologies like Cu(In, Ga)S/Se, CdTe, and crystalline silicon.<sup>9</sup> As a result, TE large-area devices with PCEs of 20.9% (14 cm<sup>2</sup> active area), 18.1% (21 cm<sup>2</sup> active area), and 17.6% (48 cm<sup>2</sup> active area) have been demonstrated.<sup>9–11</sup> These figures have surpassed or are rapidly approaching those achieved by solution-processed perovskite solar modules (PSMs), such as spin-coating (22.7%, 24 cm<sup>2</sup> active area),<sup>12</sup> spray-coating (15.5%, 40 cm<sup>2</sup> active area),<sup>13</sup> slot die-coating (16.6%, 21 cm<sup>2</sup> active area),<sup>14</sup> and blade-coating (19.2%, 50 cm<sup>2</sup> active area).<sup>15</sup> All these features put TE in an excellent position to drive the next phase of perovskite PV development forward, as the community shifts its focus from pursuing higher PCEs on laboratory-scale cells to fabricating large PSMs with industrial-compatible techniques. 

In this review, we discuss the fundamentals of various TE-based methodologies developed to achieve high-quality perovskite films, namely 1-step TE (co-evaporation and single-source TE), multistep all-TE, and multistep hybrid of TE-gas reaction and TE-solution processing. We summarize the evolution of perovskite PV devices fabricated through these methods, from the first TE PSCs in 2013<sup>16</sup> to the present state-of-the-art devices. We first review these fabrication techniques for small-area PSCs. Subsequently, special emphasis is placed on the TE of large-area perovskite films to enable the upscaling of PSCs into modules. The flow of this review is schematically reported in Figure 2. We end this review by providing our perspective on several topics we believe are particularly relevant for the further development of TE perovskite PV, namely device interlayers, defect passivation strategies, and device stability. Interested readers may refer to other review articles discussing 

2694 Joule 6, 2692–2734, December 21, 2022 

**ll** 

### Review 



Figure 3. Small-area (<1 cm<sup>2</sup> ) PSCs with 1-step co-evaporation perovskite deposition (A) Evolution of PCEs achieved over time by organic-inorganic, fully inorganic, and Pb-free PSCs. See also Table S2. 

(B) Illustration of co-evaporation with four Knudsen cells. 

(C) Cross-sectional SEM image of the first co-evaporated PSC, showing a dense MAPbI3 film with columnar grains. Reproduced with permission from Liu et al.,<sup>16</sup> copyright 2013 Springer Nature. (D) J-V curve of the most efficient co-evaporated PSC. Reproduced with permission from Pe´ rez-delRey et al.,<sup>21</sup> copyright 2018 American Chemical Society. (E) PCEs of colorful semi-transparent MAPbI3 PSCs plotted as a function of ITO thickness. Reproduced with permission from Li et al.,<sup>10</sup> copyright 2020 Elsevier. 

(F) Top-view SEM image of a MAPbBrxI3�x film. Reproduced with permission from Longo et al.,<sup>22</sup> copyright 2017 American Chemical Society. 

different aspects of TE perovskite, such as evaporated perovskite light-emitting diodes and other optoelectronic devices,<sup>17,18</sup> a comparison of evaporated and solution-processed perovskites,<sup>8</sup> a more focused review of evaporated fully inorganic perovskites,<sup>19</sup> and a practical overview of evaporation parameter control.<sup>20</sup> 

#### THERMALLY EVAPORATED SMALL-AREA PEROVSKITE SOLAR CELLS 

One-step thermal evaporation Co-evaporation 

Co-evaporation has been proven to be an effective technique to produce high-performance PSCs, as shown in Figure 3A and Table S2. The PCE of co-evaporated PSCs has been steadily climbing throughout the years for organic-inorganic and fully inorganic perovskites. Co-evaporation is also by far the most popular one-step TE method. In this methodology, each precursor is put into a separate Knudsen cell 

Joule 6, 2692–2734, December 21, 2022 2695 

**ll** 

Review 

inside the evaporation chamber (Figure 3B). The cells are simultaneously heated at independently set temperatures necessary to sublimate the materials and their deposition rates are recorded using quartz crystal microbalances (QCMs) to precisely control the stoichiometry of the deposited film. 

One of the earliest examples of halide perovskite co-evaporation was demonstrated by Era et al. in 1997, who prepared the two-dimensional (2D) layered perovskite (C6H5C2H4NH3)2PbI4 from PbI2 and C6H5C2H4NH3I (2-phenylethylammonium iodide).<sup>23</sup> In 2013, Liu et al. used co-evaporation to fabricate the first TE PSCs.<sup>16</sup> They used CH3NH3I (MAI) and PbCl2 precursors to deposit uniform flat films of MAPbI3�xClx and integrated them into planar n-i-p PSCs (Figure 3C). Their champion cell reached an efficiency of 15.4%, the record PCE for PSCs at that time. Importantly, the evaporated perovskite exhibited identical crystallography, better film coverage, and higher uniformity compared with its spin-coated analog. This work introduced co-evaporation and TE more generally as a viable method to fabricate highly efficient PSCs and triggered the interest for future investigations. Perhaps unsurprisingly, coevaporation was then responsible for several important ‘‘firsts’’ among TE PSCs. Liu et al.’s article was quickly followed by the work of Malinkiewicz et al., who co-evaporated MAPbI3 to form the first inverted TE PSC.<sup>24</sup> They reached an efficiency of 12% on an active area of 0.09 cm<sup>2</sup> and 8.27% on a larger area of 0.98 cm<sup>2</sup> , becoming the first to demonstrate relatively large TE PSCs. The same group then improved their devices by careful tuning of the co-evaporation parameters, resulting in PCEs of 14.8% and 10.9% on active areas of 0.065 and 0.95 cm<sup>2</sup> , respectively.<sup>25</sup> In early 2014, Rolda´n-Carmona et al. co-evaporated MAPbI3 on a substrate stack of polyethylene terephthalate (PET)/aluminium-doped zinc oxide (AZO)/Ag/AZO, producing the first flexible TE PSC with a PCE of 7%.<sup>26</sup> A few months later, the same group unveiled the first semi-transparent TE PSC by tuning the perovskite layer thickness.<sup>27</sup> At almost the same time, Polander et al. introduced the first fully evaporated TE PSC with a PCE of 10.9%, where the MAPbI3�xClx perovskite layer was co-evaporated.<sup>28</sup> The next breakthrough came in late 2014 when Lin et al. conducted a detailed electro-optical characterization of co-evaporated MAPbI3.<sup>29</sup> The obtained dielectric and optical constants were then fed into a device design model, resulting in a 16.5%-efficient cell that broke the record PCE for TE PSCs. This record was afterward broken again by co-evaporated PSCs through the works of Momblona et al. in 2016 (20.3%) and Pe´ rez-del-Rey et al. in 2018 (20.83%, Figure 3D) using organic interlayers.<sup>21,30</sup> Another high-efficiency device by Li et al. proved that >20% PCEs can also be achieved using an SnO2 electron transport layer (ETL) in addition to the more popular fullerene (derivatives) and TiO2.<sup>10</sup> In the meantime, co-evaporation was responsible for two more milestones: the first Pb-free TE PSC with MASnBr3 in late 2015 and the first fully inorganic TE PSC with CsPbBr2I in early 2016.<sup>31,32</sup> These cells demonstrated relatively low efficiencies at 0.35% and 4.7%, respectively, but further developments since then have significantly increased the performance of those two categories of TE PSCs. Finally, colorful and semi-transparent co-evaporated PSCs with high PCEs have also been produced (Figure 3E), exhibiting their potential for building-integrated and decorative PV applications.<sup>10,33</sup> 

One drawback of co-evaporation is the need for extensive optimization of the deposition parameters for perovskites with complex stoichiometries, where more than two or three precursors are evaporated at the same time. The recent adoption of machine learning to guide the solution processing of perovskite films should be replicated in TE to enable more effective and efficient parameter optimization in the near future.<sup>34–36</sup> Another disadvantage of co-evaporation, which is perhaps more relevant for the industry, is the long deposition time. Regrettably, very few 

2696 Joule 6, 2692–2734, December 21, 2022 

**ll** 

### Review 

publications report the duration of their co-evaporation process. Among those that do, all MAPbI3 PSCs that were co-evaporated in 30 min or less have produced < 8% PCEs,<sup>37–39</sup> with one notable exception where 17 min of MAPbI3 co-evaporation resulted in a 15.74% PCE.<sup>40</sup> Nine other studies reported >15%-efficient co-evaporated cells and recorded the deposition times in their publications, which range from 90 to 180 min.<sup>10,16,41–48</sup> Notably, Patel et al. showed that the thickness of co-evaporated MAPbI3 has a linear dependence on evaporation time, at least up until a thickness of 1.4 mm.<sup>48</sup> This simple relationship means the desired perovskite thickness can be precisely achieved with co-evaporation. 

Main research efforts in co-evaporated perovskite. The continuous growth in PCE and stability of co-evaporated PSCs is primarily due to major efforts in understanding and controlling the following aspects. 

Nucleation and Growth Mechanisms. A deep understanding of the dependence of the TE perovskite’s nucleation and growth on evaporation conditions is critical to obtaining high-quality, stoichiometric perovskite films. In TE, perovskite thin film nucleation and growth may proceed through three well-known pathways: Volmer-Weber, Frank-van der Merwe, or Stranski-Krastanov (Figure 4A). The dominant mechanism is determined by the relative strengths of adsorbate-adsorbate and adsorbate-substrate interactions. Strong bonding between adsorbates favors island growth (Volmer-Weber), while strong adsorbate-surface bonding leads to layer growth (Frank-van der Merwe). If neither bonding type is significantly stronger than the other, then the combined growth mode (Stranski-Krastanov) occurs. In practice, overall film formation was found to depend on the substrate surface properties (Figure 4B), substrate temperature, and precursor deposition rate.<sup>42,51,52</sup> The effect of the latter on the perovskite film quality is challenging to understand, as the organic precursor’s evaporation behavior is often irregular and its deposition rate has proven difficult to measure.<sup>52,53</sup> Normally, TE chambers are set up with QCMs located near the openings of the Knudsen cells. This arrangement assumes unidirectional travel of the precursor molecular fluxes from the Knudsen cells toward the substrate, where they react to form the intended compound. In that case, the evaporation rate measured by the QCMs should be close to the deposition rate on the substrate. However, organic precursors like MAI and CH(NH2)2I (FAI) are evaporated omnidirectionally, thus reducing the accuracy of QCMs placed close to Knudsen cells.<sup>42,49,52,54,55</sup> Therefore, several authors have suggested monitoring the organic precursor’s partial pressure instead.<sup>40,54–57</sup> This method may also be challenging, as studies have shown that MAI and FAI decompose during typical TE perovskite deposition processes, leading to an increase in pressure.<sup>58,59</sup> In the case of co-evaporation, the deposition rate control of organic precursors is even more complex as the substrate surface may be occupied by the inorganic precursor, the organic precursor, or the perovskite at any given time. Because the organic precursor’s absorptivity on these three possible surfaces differs, the measured deposition rate trend could also vary over time.<sup>53</sup> 

Despite these complications, we now have a better understanding of how TE perovskites are formed and how the deposition conditions may affect the final film quality. For example, Olthof and Meerholz showed that the first 3–30 nm of evaporated perovskites are non-stoichiometric due to chemical reactions between the perovskite precursors and the substrate.<sup>60</sup> This deviation in composition induces the formation of an interface dipole and band bending, but their spatial extent can be minimized with certain substrate materials. Abzieher et al. expanded upon this finding through a detailed study of perovskite nucleation and growth on various substrates.<sup>49</sup> They 

Joule 6, 2692–2734, December 21, 2022 2697 

**ll** 

Review 



Figure 4. Nucleation and growth of evaporated and solution-processed perovskite grains 

(A) Illustrations of the three thin film formation mechanisms. Reproduced with permission from Du et al.,<sup>17</sup> copyright 2021 Wiley-VCH. 

(B) Schematic drawings of variations in evaporated perovskite nucleation and growth governed by the properties of the subjacent layer. Reproduced from Abzieher et al.<sup>49</sup> under the Creative Commons CC-BY-NC-ND 4.0 License. 

(C) LaMer model plot and schematic drawings of solution-processed perovskite nucleation and growth. Reproduced with permission from Lee et al.,<sup>50</sup> copyright 2018 Wiley-VCH. 

found that the underlying layer affects not only the perovskite’s nucleation and early growth but also the bulk film’s morphology and crystallography, in agreement with Roß et al.<sup>42</sup> Regarding the deposition of organic precursors, Kim et al. showed that 

2698 Joule 6, 2692–2734, December 21, 2022 

**ll** 

### Review 

their complex evaporation characteristics can be modeled and understood by considering their changing absorptivity on different surfaces.<sup>53</sup> The advantage of obtaining a uniform perovskite film goes beyond improving device efficiency, as shown by Gallet et al. who found that precise control of the organic precursor’s deposition rate helps to obtain good perovskite stability by ensuring phase purity and reducing photostriction.<sup>57</sup> 

It is worth noting that perovskite nucleation and growth in TE do not proceed in the same manner as in solution processing. In the latter case, thin film formation broadly follows the LaMer model (Figure 4C), where nucleation is driven by the supersaturation of the precursor solution.<sup>61</sup> In practice, supersaturation may be induced by the use of an antisolvent, an air knife, a vacuum environment, or heating, among other techniques. Although TE does not involve solutions, understanding the basic principles governing thin film fabrication out of solutions is still beneficial for the case of multistep hybrid TE-solution deposition. For a more thorough discussion of perovskite nucleation and growth, readers are referred to Du et al.<sup>17</sup> and Hu et al.<sup>62</sup> for the TE and solution-processing cases, respectively. 

Perovskite Composition. Like solution processing, many early studies of TE PSCs were focused exclusively on MAPbI3. However, while solution-processed CsaFAbMA1�a�bPbBrxI3�x compositions have been very popular since 2016, in the TE community the adoption of mixed-cation, mixed-halide stoichiometries are still limited due to the challenges of depositing many different precursors simultaneously.<sup>63</sup> The pioneering study was conducted by Longo et al., who co-evaporated MAI, PbBr2, and PbI2 to fabricate 15.9%- and 10.5%-efficient PSCs with perovskite compositions of MAPb(Br0.2I0.8)3 and MAPb(Br0.5I0.5)3, respectively (Figure 3F).<sup>22</sup> Notably, Longo’s perovskite films have band gaps of 1.72 and 1.87 eV, which are useful for integration into tandem cells. Then, in 2018, Gil-Escrig et al. increased the complexity by co-evaporating Cs0.5FA0.4MA0.1Pb(Br0.17I0.83)3 using four Knudsen cells containing MAI, CsBr, FAI, and PbI2.<sup>64</sup> Their PSCs reached a PCE of 16% and were the first demonstration of TE triple-cation, double-halide perovskite. The following year, Igual-Mun˜ oz et al. and Ball et al. deposited narrow band-gap TE perovskites with compositions of FAPb0.5Sn0.5I3 and CsxFA1�xPbySn1�yI3, respectively. Igual-Mun˜ oz’s team co-evaporated FAI, PbI2, SnI2, and SnF2 to make 14%-efficient PSCs with a band gap of 1.28 eV.<sup>65</sup> Meanwhile, Ball and colleagues attempted to reduce the process complexity by melting together the PbI2, SnI2, and SnF2 precursors into an ingot and co-evaporated it with FAI in the other cell.<sup>66</sup> Their PSCs attained a stabilized PCE of 9.3% with a band gap of �1.35 eV. Both studies incorporated SnF2 to slow down the unwanted oxidation of Sn<sup>2+</sup> cations to Sn<sup>4+</sup> . However, in co-evaporation, it is rather difficult to control the evaporation of reactants needed only in small quantities, such as SnF2. Igual-Mun˜ oz et al. sought to remove this problem by co-evaporating Cs0.1MA0.9Pb0.75Sn0.25I3.<sup>67</sup> The inclusion of MA and Cs and the adjustment of the Pb-Sn balance increased the perovskite’s inherent stability and removed the need for the SnF2 additive. In early 2020, two groups independently reported the fabrication of MA-free PSCs using CsBr, PbI2, and FAI precursors in three Knudsen cells, achieving PCEs of 16.6% and 18.2%.<sup>68,69</sup> Although the obtained efficiency values are impressive, the use of CsBr necessarily coupled the concentrations of Cs and Br in the formed perovskite. This inflexibility is an obstacle to efficient and stable wide band-gap compositions, which ideally have a high Br content but a low Cs content. This problem was solved by Gil-Escrig et al. by using four precursors, namely FAI, CsI, PbI2, and PbBr2.<sup>70</sup> They successfully produced a PSC with a band gap of 1.75 eV and a PCE of 16.8%. Very recently, the same group made an even more complex formulation of (CsMAFAGA)PbBrxI3-x, where GA is 

Joule 6, 2692–2734, December 21, 2022 2699 

**ll** 

Review 

the guanidinium cation.<sup>71</sup> Four cells are again used, containing CsI, MAI, a combination of FAI and GAI, and an alloy of PbI2 and PbBr2. These studies validated co-evaporation as a deposition method capable of producing quality multi-ion perovskite films and highly efficient devices. Note that the nuances regarding substrate choice and processing conditions described above still apply, meaning a significant optimization effort is likely necessary to successfully co-evaporate multi-ion perovskites, given the high number of reactants. Indeed, Chiang et al. pointed out the extreme sensitivity of their deposition process to various parameters, such as evaporation rate, rate stability over deposition time, precursor purity, and annealing temperature.<sup>68</sup> 

Composition and Device Customization. Further expanding the concept of perovskite composition control, a homojunction or a graded junction in the perovskite layer can be fabricated through TE with a degree of control unachievable with solution processing. The basis for this approach was a study by Wang et al., who discovered the p-type (n-type) characteristics of MAI-rich (PbI2-rich) MAPbI3.<sup>72</sup> Da¨nekamp et al. exploited this finding and fabricated a MAPbI3 PSC with a p-n homojunction in the perovskite layer by adjusting the deposition rates of the MAI and PbI2 precursors.<sup>73</sup> This concept was then modified by Li et al. in a subsequent study.<sup>47</sup> Rather than forming an abrupt junction, they gradually altered the MAPbI3 perovskite composition through a continuous reduction of the co-evaporation chamber pressure. This methodology formed a gradient of MAI content and Fermi level throughout the perovskite layer’s thickness. This approach makes it possible to customize the perovskite film for a particular architecture type. Indeed, the authors showed that a particular gradient is favorable for p-i-n PSCs but not for n-i-p devices. TE allows the customization of perovskite composition while it is being deposited without the need for any passivation or additional treatment, which is not feasible with solution processing. 

Co-evaporation of perovskite in tandem architectures. Successful co-evaporation of narrow and wide band-gap perovskite films, combined with the ability to dispense with solvent orthogonality considerations, have led to co-evaporation’s application to fabricate tandem cells. In 2016, Forga´cs et al. constructed Cs0.15FA0.85PbBr2.1I0.9/ MAPbI3 all-perovskite tandem cells containing charge transport and recombination layers composed of TaTm, C60, and various dopants.<sup>74</sup> Except for the TiO2 electron transport layer and the mixed-ion perovskite, all layers in these tandem cells were thermally evaporated. Their champion device recorded a PCE of 18% and paved the way for other TE tandem cells, even if one of the two perovskite layers was still solution-processed. In 2018, Chen et al. produced tandem cells consisting of a coevaporated CsPbI3 top cell and a spin-coated organic bottom cell.<sup>75</sup> The perovskite layer not only boosted the tandem cell’s PCEs to 14% but also protected the organic layer from UV light, increasing the device’s photostability. Then, Song et al. demonstrated a co-evaporated MAPbClxI3�x/p-type silicon tandem cell with PCEs of 18.95% and 19.40% when configured in two-terminal and four-terminal arrangements, respectively.<sup>76</sup> A<sup>´</sup> vila et al. proposed an interesting concept of a homologous all-perovskite tandem cell, where both the light-absorbing layers are co-evaporated MAPbI3.<sup>77</sup> Although this design does not benefit from reduced thermalization losses like typical tandem cells, the higher output voltage is useful for photoelectrochemical applications. Like Forga´cs’ cells, A<sup>´</sup> vila’s devices were also fully evaporated except for the TiO2 layer. The champion tandem cell reached a PCE of 18% and an open-circuit voltage of 2.30 V in a two-terminal configuration. Very recently, a breakthrough was made by Roß et al., who produced the first two-terminal tandem cell consisting of a co-evaporated MA0.5FA0.63PbI3.13 perovskite top cell and a fully textured silicon bottom cell.<sup>43</sup> Due to TE’s ability to perform conformal deposition, 

2700 Joule 6, 2692–2734, December 21, 2022 

**ll** 

### Review 

the silicon layer’s texture was perfectly replicated by the perovskite film, resulting in fewer reflection losses. Their tandem cell posted an impressive stabilized PCE of 24.6% on an active area of 1 cm<sup>2</sup> . 

Co-evaporation of fully inorganic perovskite. Compared with their hybrid organicinorganic cousins, fully inorganic perovskites are more robust against heat and moisture due to the absence of volatile and hygroscopic organic cations. This, perhaps coupled with the processing complications related to organic precursors described above, has led to several attempts to co-evaporate inorganic PSCs. However, the PCEs of co-evaporated inorganic PSCs still lag behind the organic-inorganic ones. The first TE inorganic PSC was reported by Ma et al. in 2016, who co-evaporated a CsPbBr2I absorber with a band gap of 2.05 eV.<sup>32</sup> They incorporated this film into a hole transport layer (HTL)-free planar PSC with a PCE of 4.7%. Unfortunately, their PSCs suffer from significant current-voltage hysteresis, likely from the lack of an HTL. Later, the same group shifted their investigation to CsPbBrI2 and added a poly(3-hexylthiophene-2,5-diyl) (P3HT) HTL to their cell stack, achieving a PCE of 6.7%.<sup>78</sup> Beyond the first few pioneering studies, the literature on TE inorganic PSCs is dominated by the search for an optimum evaporation rate ratio between the precursors. In a series of articles, Frolova, Luchkin, and co-workers described their investigations on TE PSCs using CsPbI3, CsPbBr3, and CsPbBrxI1�x perovskites.<sup>79–81</sup> Their pure iodide and bromide devices recorded PCEs of 10.5% and 3.9%, respectively. A CsBr-rich condition (based on calibrated deposition rates and verified through flame atomic absorption spectrometry) was found to be beneficial in terms of both efficiency and phase stability for the mixed-halide case, with a PCE of 10.7% recorded for the Cs1.2PbBr1.2I2 PSC.<sup>81</sup> The role of precursor stoichiometry was also investigated by Chen et al. in the case of CsPbI3.<sup>82</sup> They found that an equal proportion of CsI and PbI2 (based on calibrated deposition rates) resulted in the best-performing cell (9.4% PCE). Swapping the CsI precursor with CsBr and maintaining the precursor ratio formed a CsPbBrI2 PSC with an even higher PCE of 11.8%. The same group then modified their co-evaporation procedure by adding a baffle separating the molecular fluxes of CsBr and PbI2 until they reach the substrate.<sup>83</sup> The substrate is rotated above this baffle, alternating thin layers of each precursor are deposited on the substrate, and the resulting stack of thin films was then annealed to form CsPbBrI2. The number and thickness of these thin layers can be tailored by adjusting the precursor evaporation rates and the substrate rotation speed. The optimized process conditions formed 660 pairs of thin precursor layers and yielded a 13%-efficient cell. 

Another report on stoichiometry control, this time for CsPbBr3, was published by Lei et al.<sup>84</sup> Their most efficient cells were produced using a CsBr:PbBr2 evaporation rate ratio of 7:10. They speculated that this deviation from the perovskite stoichiometry was needed to compensate for partial re-evaporation of PbBr2 from the substrate, as it was heated at 300<sup>�</sup> C during the deposition. This idea agrees with the results of Duan et al., whose cells reached peak PCE when CsBr and PbBr2 were co-evaporated at the same rate toward an unheated substrate.<sup>85</sup> By critically comparing the findings of these studies, we can conclude that, generally, a stoichiometric evaporation rate ratio between inorganic precursors will produce the best-performing devices. However, if substrate heating during perovskite deposition or high-temperature (>�250<sup>�</sup> C) annealing is necessary to form the perovskite, then the possibility of lead halide re-evaporation must be considered, and the precursor evaporation rate ratio should be adjusted accordingly. 

In a more detailed study on CsPbI3, Becker et al. discovered a link between the precursor compositional ratio and the crystallographic phase of the formed perovskite.<sup>86</sup> 

Joule 6, 2692–2734, December 21, 2022 2701 

**ll** 

Review 

A CsI-rich growth condition was observed to assist the production of the photoactive g-CsPbI3 phase at low temperatures, while a PbI2-rich condition led to the undesired d phase. Optimization of the precursor ratio yielded PSCs with an 11.3% stabilized PCE. An alternative approach for the low-temperature deposition of g-CsPbI3 was proposed by Zhang et al.<sup>87</sup> A small amount of co-evaporated phenylmethyl ammonium iodide (PEAI) additive was shown to beneficially alter the crystallography, grain morphology, and defect density of g-CsPbI3 PSCs, boosting the efficiency to 15%. Finally, a fascinating comparative study on TE CsPbBrI2 was conducted by IgualMun˜ oz et al.<sup>88</sup> They fabricated TE CsPbBrI2 PSCs via five pathways: single-source TE; 2-source single halide (PbI2, CsBr); 2-source mixed-halide (Pb(BrxI1�x)2, CsBrxI1�x); 3-source PbI2, CsI, CsBr; and 4-source (PbI2, PbBr2, CsI, CsBr). The single-source TE approach led to a mixture of several phases and unreacted precursors, while the 2-source single halide method formed low-quality perovskite films. Among the remaining approaches, PSCs containing as-deposited perovskite films exhibit largely similar PCEs in the range of 7%–8%. Upon annealing at 150<sup>�</sup> C, the 3-source method reached the highest PCE at 10%. 

Single-source thermal evaporation 

Co-evaporation of a complex material requires regular calibration of deposition rates and precursor ratios to obtain high-quality films with accurate stoichiometry. As mentioned above, this can be rather challenging for organic-inorganic hybrid halide perovskites due to the irregular evaporation characteristics of the organic precursor. To sidestep this problem, single-source TE was investigated as an alternative method, albeit with limited success in terms of PCE so far (<13%, Figure 5A; Table S3). With this technique, the target material is prepared beforehand in the form of a powder or a crystal. Then, it is evaporated onto the substrate (Figure 5B), ideally without any chemical reaction. Examples of successful applications of singlesource TE include an 8.7%-efficient CsPbBr3 cell<sup>89</sup> (Figure 5C) and a 7.1%-efficient CsGe0.5Sn0.5I3 cell,<sup>90</sup> a notable achievement for a Pb-free PSC. The latter study also exhibited the feasibility of large-area perovskite deposition using single-source TE, as proven by their 10 3 10 cm evaporated perovskite film (Figure 5D). 

One limitation of the standard version of single-source TE is the relatively slow material heating and evaporation, usually in the order of tens of minutes. During this period, the perovskite may decompose back to its precursors rather than merely being vaporized. Furthermore, the low formation enthalpy of halide perovskites and the large difference in vapor pressure between the perovskite’s organic and inorganic components mean the target film may end up having an undesired stoichiometry. 

Perovskite decomposition can be circumvented by modifying single-source TE such that the evaporation process is significantly accelerated and completed in the order of a few seconds.<sup>91–93</sup> To achieve this, the perovskite powder/film is placed on a foil or into a boat made of a conductive material (Figure 5E). Then, a high electric current (30–200 A) is quickly ramped up and passed through the foil/boat to rapidly increase its temperature and evaporate the material.<sup>91,92</sup> This variation of single-source TE was originally applied to hybrid perovskite deposition in 1999 by Mitzi et al., who named the technique single-source thermal ablation.<sup>94</sup> However, its use for PSCs was pioneered by Longo et al. in 2015.<sup>91</sup> They labeled this technique flash evaporation due to the instantaneous deposition and this name has been preferred by the community since then. Longo’s MAPbI3 cells reached a peak efficiency of 12.2%, an impressive result at that time. Unfortunately, since then there has been very little progress in the PCE of PSCs made via standard single-source TE or flash evaporation (Figure 5A). The current PCE record for these two techniques is 12.55%, achieved by 

2702 Joule 6, 2692–2734, December 21, 2022 

**ll** 

### Review 



Figure 5. Small-area (<1 cm<sup>2</sup> ) PSCs with 1-step, single-source TE perovskite deposition (A) Evolution of PCEs achieved over time by organic-inorganic, fully inorganic, and Pb-free PSCs. See also Table S3. 

(B) Illustration of single-source perovskite TE. 

(C) Cross-sectional SEM image of a CsPbBr3 PSC. Reproduced with permission from Li et al.,<sup>89</sup> copyright 2020 Elsevier. 

(D) Photograph of a large-area CsGe0.5Sn0.5I3 film. Reproduced from Chen et al.<sup>90</sup> under the Creative Commons CC-BY 4.0 License. 

(E) Illustration of a flash evaporation chamber. Reproduced from Longo et al.<sup>91</sup> under the Creative Commons CC-BY 3.0 License. 

(F) J-V curve of the most efficient PSC among single-source TE and flash evaporated devices. Reproduced with permission from Xu et al.,<sup>92</sup> copyright 2019 Springer Nature. 

Xu et al. who flash-evaporated phase-pure a-FAPbI3 films at a substrate temperature of 105<sup>�</sup> C and without post-deposition annealing (Figure 5F).<sup>92</sup> 

Recently, single-source TE has mostly been applied to deposit relatively unusual perovskite compositions, including perovskite-inspired Pb-free materials (Figure 5A). Most of the progress on this front has been made by Fan and colleagues, whose selected deposition method seems to be a hybrid between standard single-source TE and flash evaporation. In a series of articles, they reported the use of a high electric current to evaporate MAPbI3, the quasi-2D BA2MA3Pb4I13 (BA, 

Joule 6, 2692–2734, December 21, 2022 2703 

**ll** 

Review 

butylammonium cation), Cs2AgBiBr6, and CsBi3I10.<sup>95–101</sup> The duration of their perovskite deposition step was reported to range from 3 to 15 min, faster than standard single-source TE but not nearly as fast as flash evaporation.<sup>95–97,99,101</sup> Although these works have not improved the PCE record of single-source TE PSCs, they proved their suitability for large-area perovskite thin films,<sup>97</sup> 2D perovskites,<sup>96,98</sup> and lead-free perovskites.<sup>99,100</sup> 

##### Multistep all-thermal evaporation 

Summarizing the results presented in the previous sections, co-evaporation produces superior PSCs compared with standard single-source TE and flash evaporation. However, co-evaporation has an inherent disadvantage, as it precludes the independent optimization of deposition conditions (temperature and partial pressure) for each of the (especially organic) precursors. Multistep TE was developed with the idea of nullifying or reducing this drawback, as tailoring the deposition conditions to each precursor could potentially improve the perovskite film quality. In its simplest form, multistep TE is merely a division of co-evaporation into two or more deposition rounds, with one precursor deposited after the other (sequential evaporation, Figure 6B). The first report of PSCs fabricated via multistep TE was authored by Hu et al. less than a year after the first co-evaporated PSC work was published.<sup>104</sup> Their HTL-less MAPbI3 cell demonstrated a PCE of 5.4%. Although this efficiency was not very high, it demonstrated the feasibility of multistep TE as a perovskite deposition method. Shortly afterward, Chen et al. exhibited a full-stack PSC containing a MAPbClxI3�x perovskite layer with a PCE of 15.4%, matching the performance of co-evaporated PSCs.<sup>105</sup> Currently, the highest PCE record for PSCs fabricated via multistep TE is held by Li et al., whose Cs0.05FA0.95PbI3 cell achieved an efficiency of 24.42% (Figures 6A and 6C; Table S4).<sup>11</sup> The cells were made through co-evaporation of PbI2, PbCl2, and CsI in a relatively high vacuum environment (7 3 10<sup>�3</sup> Pa), followed by FAI evaporation in a lower vacuum condition (10<sup>�2</sup> Pa) and short annealing in air. The PbCl2 precursor assisted the formation of a low-defect a-phase perovskite and facilitated the high PCE. 

##### Multistep all-thermal evaporation of organic-inorganic perovskite 

Interestingly, the first two publications of multistep TE PSCs (those by Hu, Chen, and their colleagues) demonstrated vastly different morphologies of the lead halide layer.<sup>104,105</sup> Hu used a PbI2 precursor and obtained a rough, porous film composed of randomly oriented PbI2 plates.<sup>104</sup> The pores formed between neighboring plates created a large surface area and enabled easy penetration of MAI into the PbI2 film, fostering a complete perovskite formation reaction. On the other hand, Chen used a PbCl2 precursor and observed PV behavior from their cells only when the lead halide film thickness was between 15 and 25 nm, indicating a limited MAI penetration.<sup>105</sup> However, heating the substrate during MAI deposition successfully increased the penetration depth to about 150 nm. Substrate heating is a generally undesirable step as it increases the deposition process’s energy demand, promotes the re-evaporation of deposited material, and is unsuitable for flexible plastic substrates. Therefore, an alternative approach is needed to obtain thick, completely formed perovskite films. The solution to this problem, multilayer evaporation, was developed by Ng et al.<sup>106</sup> They first confirmed MAI’s limited penetration depth in evaporated lead halide films by demonstrating the existence of PbI2, even after a bilayer of 150 nm PbI2/150 nm MAI was annealed for 2 h. Then, they sequentially evaporated seven pairs of thin PbI2/MAI bilayers (50 nm each). Perovskite formation was observed to start during the evaporation steps, but it was only completed after 1 h of annealing at 90<sup>�</sup> C. The resulting cells recorded a champion PCE of 12.5%. After encountering the same problem with limited MAI penetration depth into PbCl2 

2704 Joule 6, 2692–2734, December 21, 2022 

**ll** 

### Review 



Figure 6. Small-area (<1 cm<sup>2</sup> ) PSCs with multistep all-TE perovskite deposition 

(A) Evolution of PCEs achieved over time by organic-inorganic, fully inorganic, and Pb-free PSCs. See also Table S4. 

(B) Illustration of sequential perovskite evaporation. Reproduced with permission from Wang et al.,<sup>6</sup> copyright 2018 Wiley-VCH. 

(C) J-V curve of the most efficient multistep all-TE PSC. Reproduced from Li et al.<sup>11</sup> under the Creative Commons CC-BY-NC 4.0 License. 

(D) Schematic of a pre-annealed perovskite film deposited with multilayer evaporation, containing alternating layers of FAI and PbI2 with a layer of additive MACl. Reproduced with permission from Tavakoli et al.,<sup>102</sup> copyright 2019 Institute of Physics. 

(E) Illustration of a 3D/2D perovskite heterojunction formed through sequential co-evaporation, and top-view SEM images of the co-evaporated 3D and 2D layers. Reproduced with permission from La-Placa et al.,<sup>103</sup> copyright 2019 American Chemical Society. 

films (up to 100 nm), Yang et al. deposited two pairs of PbCl2/MAI bilayers and annealed them for 2 h at 120<sup>�</sup> C.<sup>107</sup> They achieved a peak PCE of 16%, excellent reproducibility, and demonstrated the high degree of process monitoring and control achievable with multistep TE. Another clever application of multilayer evaporation is the inclusion of a small amount of dopant into the perovskite layer by adding it as one of the many thin layers. This method was used by Tavakoli et al. by evaporating a 60-nm-thick layer of MACl in the middle of nine alternating layers of PbI2 and FAI (Figure 6D).<sup>102</sup> The addition of MACl stabilized the a-FAPbI3 phase, increased the cell PCE from 16.2% to 17.7%, and markedly reduced the currentvoltage hysteresis. 

Joule 6, 2692–2734, December 21, 2022 2705 

**ll** 

Review 

In complex multicomponent depositions, it may be desirable to incorporate coevaporation in multistep TE. Two good examples of this approach are found in the works of Gil-Escrig et al. and La-Placa et al. The former, in the first demonstration of evaporated mixed-halide PSC, fabricated a 12.9%-efficient MAPbBrxI3�x PSC by MAI-PbI2 co-evaporation followed by PbBr2 deposition.<sup>108</sup> The latter exploited sequential evaporation’s inherently additive nature and precise thickness control to fabricate a 2D/3D perovskite heterostructure, a promising architecture to obtain both high efficiency and stability.<sup>103,109</sup> This multidimensional device architecture was constructed by first co-evaporating MAI and PbI2 to form the base 3D MAPbI3, followed by co-evaporating PEAI and PbI2 to form a thin layer of 2D PEA2PbI4 (Figure 6E). As there was no need to consider solvent compatibility with the underlying layers, the 2D layer can be easily incorporated between the perovskite and either charge transport layers (CTLs). Importantly, the 2D film was composed purely of PEA2PbI4, unlike solution-processed ‘‘2D’’ perovskites that often contain quasi-2D phases. However, the inorganic slabs of the evaporated 2D layer were oriented parallel to the substrate, hindering charge extraction and ultimately lowering device performance. Although a method to force perpendicular growth of 2D perovskite has been found for solution processing,<sup>110</sup> its analog for TE is still elusive and it represents an interesting research direction to explore. 

Beyond 2D/3D hybrid perovskites, much progress is being made in other forms of perovskite heterojunctions formed via multistep TE. Here, the aim is to exploit TE’s additive nature to engineer a favorable energy band landscape in the absorber layer. Zhang et al. fabricated a stack composed of CsPbBr1.5I1.5 and FAPbBr1.5I1.5.<sup>111</sup> The Cs-containing layer has deeper conduction and valence bands compared with the FA-containing perovskite; as such, it was evaporated onto the C60 electron transport layer to assist electron extraction and block holes. The perovskite deposition sequence consisted of two co-evaporation steps, featuring the cesium halide or formamidinium halide in one crucible and a mixture of PbI2 and PbBr2 in the other. This heterojunction design improved the device stability and increased its PCE to 17.1% compared with a FAPbBr1.5I1.5-only cell (14.1%). An even more complex absorber stack was reported by Tong et al., who developed a trilayer heterojunction using fully inorganic, all-bromide perovskites.<sup>112</sup> The first layer in their n-i-p stack is CsPbBr3, deposited via sequential evaporation of CsBr and PbBr2 in a stoichiometric 1:1 ratio. Then, the second is a mixture of CsPbBr3 and CsPb2Br5 (10% excess PbBr2). Finally, the last layer is a mixture of CsPbBr3 and Cs4PbBr6 (10% excess CsBr). The produced stack has conduction and valence bands that gradually become shallower with each new layer, producing an energy level cascade that helps with charge extraction and minimizes interfacial recombination. When incorporated into a full device, this heterojunction demonstrated a PCE of 10.2%, a large increase from the standard CsPbBr3 cell (7.1%). 

Highly efficient flexible PSCs and modules have been fabricated using multistep TE on a variety of substrates, such as flexible glass, epoxy, PET/tin-doped indium oxide (ITO), and polyethylene naphthalate (PEN)/ITO.<sup>113–118</sup> Flexible substrates are often intolerant of high-temperature processing steps, so they benefit from sequential or multilayer perovskite evaporation where high-temperature annealing is rarely needed. A couple of early studies were conducted by Tavakoli et al., who explored the use of patterned substrates to reduce reflection losses. An array of nanocones was either fabricated on polydimethylsiloxane and attached to a flexible glass substrate<sup>113</sup> or patterned directly on an epoxy substrate,<sup>114</sup> leading to MAPbI3 PSCs with PCEs of 13.1% and 11.3%, respectively. Both works used an n-i-p configuration with ZnO as the substrate-side ETL. When the p-i-n configuration is used instead, the 

2706 Joule 6, 2692–2734, December 21, 2022 

**ll** 

### Review 

produced evaporated flexible PSCs have shown much better performance. For instance, fully vacuum-processed flexible MAPbI3 cells using PTAA (poly[bis(4phenyl)(2,4,6-trimethylphenyl)amine]) and CuPc (copper phthalocyanine) as the substrate-side HTL recorded PCEs of 17.3% and 18.7%, respectively.<sup>116,117</sup> Most recently, a flexible fully inorganic CsPbBr3 PSC was fabricated with sequential evaporation, reaching a PCE of 5.67% by incorporating a Cu2O interlayer between the perovskite and spiro-OMeTAD.<sup>118</sup> 

##### Multistep all-thermal evaporation of fully inorganic perovskite 

The first few applications of multistep TE for the deposition of fully inorganic PSCs were conducted entirely with CsPbI3. The first report was written in early 2017 by Yonezawa et al., whose sequentially deposited cells had an efficiency of 5.71%.<sup>119</sup> Several months later, the same group changed their deposition procedure to multilayer evaporation and obtained a PCE of 6.79%.<sup>120</sup> At about the same time, multilayer evaporation was also adopted by Hutter et al., but using a much higher number of alternating CsI and PbI2 thin layers.<sup>121</sup> This approach produced devices with an efficiency of 8.8%. Only the n-i-p architecture was used in these initial works until p-i-n CsPbI3 cells with a PCE of 10.2% were produced by Kottokaran et al. in 2018. 

Since then, the focus has shifted to CsPbBr3, where there is a debate on whether non-stoichiometric phases (CsPb2Br5 and Cs4PbBr6) play a positive or negative role in PSCs. Li et al. deliberately used a PbBr2-rich recipe to introduce CsPb2Br5 into their cells, and they attributed a vast range of advantageous phenomena to this phase. These include larger perovskite grains, bulk and interface defect passivation, and beneficial energy band bending at both perovskite/CTL interfaces, although no direct evidence was provided for the band bending.<sup>122</sup> In contrast, Zhang et al. treated CsPb2Br5 merely as a side product of an incomplete perovskite formation reaction.<sup>123</sup> Indeed, the presence of this impurity motivated them to switch from sequential to multilayer evaporation. A subsequent report by the group of authors who wrote Li et al.<sup>122</sup> found that PbBr-rich CsPb2Br5 and CsBr-rich Cs4PbBr6 are overall beneficial, but only because they serve as nucleation sites where CsPbBr3 is formed through inter-diffusion of the derivative phases.<sup>124</sup> Then, a case against CsPb2Br5 and Cs4PbBr6 was made by Liu et al.<sup>125</sup> Devices made from stoichiometric amounts of CsBr and PbBr2 demonstrated superior efficiency compared with those containing the derivative phases due to stronger light absorption, better film crystallinity and morphology, longer carrier lifetime, and faster charge extraction. In summary, the effects of these derivative phases and the mechanism behind them remain unresolved topics deserving further investigation. Beyond that, other studies of CsPbBr3 PSCs fabricated via multistep TE have focused on improving the post-deposition annealing procedure to reduce the perovskite crystal’s defect density while avoiding its decomposition.<sup>126,127</sup> 

##### Multistep all-thermal evaporation of Pb-free perovskite 

Multistep TE has been used more than any other TE technique to fabricate Pb-free PSCs. Early works were focused on substituting Sn for Pb to lessen toxicity concerns, resulting in PSCs containing MASnBr3, CsSnBr3, Cs2SnI6, or GASnI3.<sup>31,128–130</sup> These devices demonstrated poor operational stability and efficiency, with <1% PCE in all cases. More recent reports have explored derivative structures, such as variations of ordered perovskites (A<sup>0</sup> A<sup>00</sup> 2BX6 and A3B2X9).<sup>6,131–133</sup> These have been relatively more successful, producing MA3Bi2I9 and Cs2AgBiBr6 PSCs with efficiencies of 1.64% and 1.41%, respectively.<sup>131,132</sup> These values are still significantly lower compared with solution-processed Bi-based PSCs,<sup>134</sup> but they also reflect the 

Joule 6, 2692–2734, December 21, 2022 2707 

**ll** 

Review 

wide disparity in the amount of research effort being devoted to TE and solutionprocessed Pb-free PSCs. Given the success of TE in producing highly efficient Pb PSCs, we can expect TE Pb-free PSCs to at least match the performance of their solution-processed analogs as well, provided more resources are devoted to their study. 

Overall, multistep TE’s greatest advantage is its highly precise control of material deposition, which allows for excellent reproducibility in device fabrication. This makes multistep TE a fertile ground for studies exploring the effects of a specific phenomenon, as unintended changes in variables that are not of interest can be suppressed. Consequently, multistep TE has been the method of choice for investigations on a wide variety of topics, including the role of unreacted PbI2 precursor,<sup>135</sup> the impact of grain boundary traps,<sup>136</sup> the fundamental mechanisms governing the transformation of PbI2 to MAPbI3,<sup>137,138</sup> the effect of substrate temperature on perovskite morphology,<sup>137</sup> the performance of CTLs,<sup>116,117,139–143</sup> and the capabilities of a unique reactor design.<sup>144</sup> 

##### Multistep hybrid deposition 

TE can be combined with many other deposition techniques to fabricate quality perovskite films and high-performance PSCs. These complementary methods may be grouped into gas-phase techniques (gas reaction) and liquid-phase techniques (solution processing). In the TE-gas reaction pathway, the inorganic salt precursor is thermally evaporated. Then, this intermediate product is exposed to a vapor of the organic precursor to induce a gas-solid reaction. Originally, TE and gas reactions were differentiated by whether the vapor deposition is performed in a line-of-sight manner. In TE, the flux of evaporated molecules travels in a directional beam from the material source onto the deposition target. On the other hand, if the target is simply put into an environment containing the material vapor, then it is called a gas reaction. However, several authors have consistently shown that even in a typical TE setup, only the inorganic precursors (e.g., the lead and cesium halide salts) undergo line-of-sight deposition. Meanwhile, the organic precursors (e.g., MAI, FAI) are evaporated omnidirectionally.<sup>42,49,52,54,55</sup> In this review, we nonetheless categorize the deposition of organic precursors in a TE chamber as TE to simplify the classification of deposition routines. In the class of gas reaction, we include gas-phase deposition approaches done outside a typical TE chamber (e.g., in a quartz furnace tube or an enclosed Petri dish) and those performed inside a TE chamber but with line-of-sight deposition deliberately blocked with a shutter or similar. 

The wide variety of solution-processing techniques suitable for perovskite deposition means there is an equally large number of hybrid TE-solution processing deposition pathways. In literature, TE has been combined with spin-coating, bladecoating, slot die-coating, spray-coating, inkjet printing, electrodeposition, and chemical bath deposition (CBD). Although most publications on hybrid TE-solution approaches only use two deposition steps, recently there has been an increasing number of reports using longer and more complicated deposition sequences to produce multi-ion perovskites or to incorporate performance-boosting additives. Interestingly, hybrid deposition recipes where TE is the first step (TE >> solution) outnumber those where solution processing is conducted first (solution >> TE) by a ratio of almost three to one. In general, these two approaches respond to the different needs and challenges to be overcome. A thermally evaporated first layer can guarantee a conformal deposition over rough substrates, while the solution-first method could induce a slower perovskite phase formation and consequentially a better control of the film morphology. 

2708 Joule 6, 2692–2734, December 21, 2022 

**ll** 

### Review 



Figure 7. Small-area (<1 cm<sup>2</sup> ) PSCs with multistep hybrid TE-gas reaction perovskite deposition (A) Evolution of PCEs achieved over time by organic-inorganic and Pb-free PSCs. See also Table S5. (B) Cross-sectional SEM image of a Cs0.23MA077PbI3 PSC showing columnar grains. Reproduced with permission from Zhu et al.,<sup>145</sup> copyright 2017 Royal Chemical Society. (C) Top-view SEM image of a Sr-doped Cs0.24FA0.76PbBrxI3�x film. Reproduced with permission from Deng et al.,<sup>146</sup> copyright 2020 Royal Society of Chemistry. (D) J-V curve of the most efficient TE-gas reaction PSC. Reproduced with permission from Tavakoli et al.,<sup>147</sup> copyright 2022 Wiley-VCH. (E) Schematic of the fabrication of a 3D/2D perovskite heterojunction. The 3D MAPbI3 layer was first deposited by TE, then exposed to BAI vapor to form the 2D BA2MAn�1PbnI3n+1 layer. Reproduced with permission from Lin et al.,<sup>148</sup> copyright 2019 Elsevier. 

Hybrid TE-solution deposition has great potential to produce high-quality perovskite films as it allows us to get the best of both worlds while covering each technique’s disadvantages. However, it necessarily increases the complexity of the device fabrication process compared with simpler methods such as co-evaporation, and it remains to be seen whether this complexity can be outweighed by the potential benefits. 

##### Thermal evaporation—gas reaction 

The popularity of multistep hybrid TE-gas reaction as a perovskite deposition method has been waning compared with its peak, which lasted from 2016 to early 2019 (Figure 7A; Table S5). Perhaps due to this reason, it took five years for the 

Joule 6, 2692–2734, December 21, 2022 2709 

**ll** 

Review 

record PCE to be improved from 19.94% in 2017 to 21.20% in 2022. However, if we look at the overall PCE trend, there is a clear, gradual rise from 2014 up until the present (Figure 7A). The development of PSCs fabricated via TE-gas reaction can largely be divided into phases focused on distinct topics, as summarized below. 

The combined use of TE and gas reaction was pioneered by the group of Yabing Qi. In the first of two articles published in late 2014, they demonstrated MAI deposition in a TE chamber but with a closed crucible shutter.<sup>149</sup> This deviation from standard procedure and the resulting avoidance of line-of-sight deposition were claimed to be key to achieving uniform MAI deposition across a cm-scale area. In the second article, the authors deposited PbCl2 via TE and then put the substrates and some MAI powder into a tube furnace, where MAI was deposited onto the substrates via chemical vapor deposition (CVD).<sup>150</sup> They showed that a high degree of control over the deposition temperature, pressure, and gas flow rate was achievable, resulting in an 11.8%-efficient PSC. The successful application of CVD, a well-established and scalable deposition technique, for perovskite device fabrication was a valuable finding as it provided early evidence of perovskite device manufacturing using industrial-scale methods. 

In the subsequent two years, research on hybrid TE-gas reactions was heavily focused on optimizing the processing conditions of either CVD or closed-shutter TE deposition. These efforts include investigations on alternative lead halide sources,<sup>151</sup> the effect of CVD temperature,<sup>152</sup> ideal partial pressure of the organic precursor,<sup>153</sup> and the lead halide deposition rate.<sup>154</sup> In 2016, a major advance was achieved by Yang et al., who incorporated 1-butyl-3-methylimidazolium tetrafluoroborate ionic liquid between the TiO2 ETL and MAPbI3 in their PSCs.<sup>155</sup> The ionic liquid played several important roles, such as increasing electron mobility, reducing interfacial carrier recombination, lowering contact resistance, assisting with TiO2perovskite work function matching, and providing a suitable surface for the growth of low-trap state density perovskite. As a result, the ionic liquid-containing device exhibited an impressive PCE of 19.6% and no current-voltage hysteresis due to suppressed ion migration and interfacial charge accumulation. This PCE was the highest ever achieved by planar MAPbI3 PSCs at that time, thus demonstrating the importance of interface optimization. 

From 2017 onward, the research focus shifted to perovskite composition and dimensionality engineering. Zhu et al. fabricated Cs0.23MA0.77PbI3 PSCs with a stabilized efficiency of 19.94% by co-evaporating PbCl2 and CsCl, putting the substrates on a layer of MAI powder, and heating them up to induce a gas-solid perovskite formation reaction (Figure 7B).<sup>145</sup> Luo et al. produced a series of CsxFA1�xPbBryI3�y PSCs by sequentially evaporating CsBr and PbI2, followed by CVD with a pre-deposited film of FAI/FACl mix. A champion PCE of 17.3% was recorded by the Cs0.24FA0.76PbBryI3�y PSC. FACl was credited with accelerating the gas-solid reaction rate, while the good thermal and moisture stability was attributed to the absence of MA cation.<sup>5</sup> The same research group then slightly improved the performance of their PSCs to 17.7% by evaporating a 4-nm-thick layer of SrI2 between CsBr and PbI2 depositions.<sup>146</sup> The authors claimed that SrI2 increased the reactivity of PbI2, easing perovskite formation in the CVD step and producing larger perovskite grains with a lower density of trap states (Figure 7C). Meanwhile, Cs-free multi-cation perovskites were studied by Choi et al. They heated an evaporated PbCl2 film and a mix of FAI and MAI powders in a vacuum oven to form FAxMA1�xPbI3 perovskites. A maximum stabilized PCE of 15.8% was achieved when the organic powders have a weight ratio of FAI:MAI = 59:41.<sup>156</sup> Very recently, Tavakoli et al. reported highly 

2710 Joule 6, 2692–2734, December 21, 2022 

**ll** 

### Review 

efficient In-doped MAPbI3 PSCs.<sup>147</sup> Rather than starting with metal halide precursors, they evaporated a Pb-In alloy (1 wt % In), which was subsequently converted into perovskite through MAI gas reaction. This approach achieved a PCE of 21.20%, which is the highest value reported for TE-gas reaction PSCs (Figure 7D). 

Beyond mixed-ion perovskites, 2D, Pb-free, and even Pb-free 2D perovskites have been developed via hybrid TE-gas reaction. Lin et al. formed a 2D/3D perovskite heterojunction through a combination of TE and two gas reaction steps.<sup>148</sup> A film of PbI2 was first evaporated, then suspended face-down above a spread of MAI powder, and heated in a vacuum oven. After the 3D MAPbI3 is formed, it was in turn suspended above BAI powder and similarly reacted, albeit at a lower temperature and shorter heating period, to form primarily the quasi-2D phase BA2MAPb2I7 layer (Figure 7E). The heterojunction device demonstrated a slightly lower stabilized PCE compared with its all-3D analog (16.12% versus 16.75%), but it was also far more robust against thermal and moisture degradation. TE-gas reaction was also used by Chen et al. to produce Cs2TiBr6 PSCs with a stabilized PCE of 3.2%.<sup>157</sup> They constructed a reaction chamber where an evaporated film of CsBr was reacted with TiBr4 vapor produced by heating TiBr4 powder. This reaction pathway produced phase-pure Cs2TiBr6, but its formation takes 24 h to complete. The relatively low efficiency and prolonged reaction time may be why Ti-based PSCs have not been extensively explored thus far, although it has demonstrated promising operational stability. Finally, a Pb-free 2D/ 3D perovskite heterojunction was developed by Choi et al. as an attempt to improve the stability of Sn perovskite against oxidation.<sup>158</sup> Choi’s selected deposition pathway was rather unique as after evaporating a SnI2 film, they evaporated PEAI and converted the topmost parts of the SnI2 film into PEA2SnI4 first. Then, the SnI2/ PEA2SnI4 stack was exposed to MAI vapor, which diffused through the 2D layer to convert the remaining SnI2 into MASnI3. Time-of-flight secondary ion mass spectrometry ascertained that the 2D layer was formed only at the top surface and that MAI penetrated through the entire thickness of the SnI2 film. The 2D layer suppressed Sn oxidation and enhanced the crystallinity of MASnI3, leading to a PCE of 9.2%. 

The rising number of deposition steps and/or precursors may lead to a more demanding optimization procedure. For example, Liu et al. recently co-evaporated PbI2 and PbCl2 and reacted them with a mixture of FAI, MACl, and MABr powders using CVD.<sup>159</sup> Although their PSCs reached a respectable PCE of 18.1%, this achievement required a simultaneous optimization of organic salt composition, CVD vapor pressure, CVD reaction time, and post-deposition annealing. This study shows that while hybrid deposition techniques can be very useful to obtain good multi-ion perovskite films, they often require extensive tuning of multiple parameters with overlapping effects. This can become a drawback compared with relatively simpler deposition methods like co-evaporation. 

In terms of processing duration, several applications of TE-gas reaction have produced >15%-efficient PSCs while keeping the total deposition time (TE duration and gas reaction duration) to 45–60 min.<sup>148,155,160,161</sup> Although this is significantly faster than most reported co-evaporation processing times, it is also far slower than flash evaporation. Further reduction of processing time may be necessary before the TE-gas reaction hybrid path can be integrated into industrial processing lines. 

##### Thermal evaporation >> solution 

The TE-solution processing hybrid method has been applied to a wide variety of perovskites and device structures (although the TE >> solution path specifically has not been used to produce fully inorganic or Pb-free perovskites, Figure 8A; Table S6). 

Joule 6, 2692–2734, December 21, 2022 2711 

**ll** 

Review 



Figure 8. Small-area (<1 cm<sup>2</sup> ) PSCs with multistep hybrid TE-solution processing perovskite deposition, where the first step is TE 

(A) Evolution of PCEs achieved over time by organic-inorganic PSCs. See also Table S6. 

(B) Illustration of TE followed by spin-coating to fabricate small-area PSCs. Reproduced with permission from Jang et al.,<sup>162</sup> copyright 2019 American Chemical Society. (C) Illustration of TE followed by blade-coating to fabricate large-area PSCs. Reproduced from Siegrist et al.<sup>163</sup> under the Creative Commons CC-BY-NC 3.0 License. 

(D) J-V curve of the most efficient TE >> solution PSC. Reproduced with permission from Soltanpoor et al.,<sup>164</sup> copyright 2020 American Chemical Society. 

(E) Top-view SEM image of a MAPbI3 film fabricated via PbI2 evaporation and MAI spin-coating. Reproduced from Pisoni et al.<sup>165</sup> under the Creative Commons CC-BY 4.0 License. 

(F) Cross-sectional SEM image of a triple-cation PSC deposited via TE and blade-coating. Reproduced from Siegrist et al.<sup>163</sup> under the Creative Commons CC-BY-NC 3.0 License. 

(G) Cross-sectional SEM image of a triple-junction perovskite/perovskite/silicon tandem cell. The conformal perovskite layers were deposited via co-evaporation of PbI2 and CsBr, followed by FAI or FABr spin-coating. Reproduced with permission from Werner et al.,<sup>166</sup> copyright 2018 American Chemical Society. 

2712 Joule 6, 2692–2734, December 21, 2022 

**ll** 

### Review 

This versatility is largely due to the large number of available solution-processing options. Although a majority of TE-solution hybrid deposition uses either spincoating (Figure 8B) or CBD, there have been several studies using spraycoating,<sup>167,168</sup> electrochemical reaction,<sup>169</sup> inkjet printing,<sup>170</sup> and blade-coating (Figure 8C).<sup>163</sup> Some effort has also been invested to significantly modify the TE step, such as by evaporating a metallic lead or tin film as opposed to their halide salts and evaporating PbI2 from a solution instead of a powder.<sup>169,171</sup> So far, these approaches have produced relatively low PCEs and most studies use standard TE or slight variations thereof. 

The combination of TE and solution processing was aimed at bypassing each technique’s limitations and exploiting the best features of both, ultimately producing the best perovskite film and device possible. For example, the first few applications of this hybrid technique took advantage of TE’s superior process control to carefully tune the perovskite thickness, grain morphology, and crystallite domain orientation.<sup>172–174</sup> Meanwhile, the solution-based step allows further refinement of perovskite nucleation and growth through the use of additives such as hypophosphorous acid, MACl-MABr mixture, or dimethyl sulfoxide (DMSO), which are either challenging or impossible to incorporate through TE.<sup>164,170,175</sup> Such additives usually lead to excellent device performance and are one of the factors contributing to the increase in device efficiency over time (Figure 8A). For example, the current record PCE for this deposition technique (19.7%, Figure 8D) was achieved by putting MABr and MACl additives into the MAI solution used in the spin-coating step.<sup>164</sup> 

Some of the most important research works performed with the TE >> solution method revolves around two main topics. The first one looks at the conversion of the evaporated lead halide film into perovskite, how it can be driven to completion, and the effects of any remnant lead halide. Because the conversion reaction starts at the top surface of the lead halide film, the buried parts of this film may not react with the organic halide salt if there is insufficient energy or time for the organic salt to diffuse through. If the residual lead halide layer is too thick, it will block charge transfer from perovskite to the subjacent CTL. To solve this problem, Fu et al. and Pisoni et al. devised ways to evaporate PbI2 in the form of nanoplates.<sup>165,176</sup> These plates are oriented at a range of angles to the substrate instead of lying flat on it, so the PbI2 films are porous and can be easily permeated by the organic salt molecules to form perovskite films with good grain morphology (Figure 8E). Then, the amount of remnant PbI2 can be controlled by changing the amount of organic salt precursor. Other studies have shown that a small amount of remnant PbI2 can increase PSC performance through grain boundary and interface passivation,<sup>177,178</sup> though these benefits are outweighed by poor charge transport when there is too much unreacted PbI2. 

The second topic is halide composition tuning. By using precursors containing different halides and controlling the manner of their deposition, the perovskite halide content and distribution can be finely tuned. In the simplest case, the TE >> solution approach can be used to produce a mixed-halide perovskite from monohalide precursors. For example, Gil-Escrig et al. fabricated MAPbBrxI3�x by co-evaporating MAI and PbI2, evaporating PbBr2, and spin-coating MABr.<sup>108</sup> A short annealing induced halide inter-diffusion and formed the mixed-halide perovskite, whose bromide content can be regulated by varying the PbBr2 layer thickness and MABr solution concentration. A different method to control the halide balance was demonstrated by Jang et al., who used single-source TE of MAPbCl3 and MAI spin-coating to make MAPbClxI3�x PSCs.<sup>162</sup> Halide exchange occurred during the MAI coating 

Joule 6, 2692–2734, December 21, 2022 2713 

**ll** 

Review 

step, which means the chloride ions can be gradually replaced by iodide by repeating the spin-coating step up to eight times, by which point no chloride was detectable in the perovskite. Interestingly, they also found that the halide exchange occurred at the surface first, and then progressed toward the bottom part of the film. This raises the possibility of forming a halide and band-gap gradient that could assist charge collection. Fu et al. realized this by spin-coating MABr on a MAPbI3 film, which itself was deposited using TE and spin-coating.<sup>179</sup> The Br-I exchange was induced by annealing in a chlorobenzene vapor atmosphere. By tuning the amount and concentration of the MABr solution, the extent of halide exchange and hence the composition gradient can be controlled. Because halide ions dominate the valence band formation in perovskites, the Br-rich side of the film has a deeper valence band maximum compared with the Br-poor side. Therefore, the Br-rich side can act as a hole blocker and prevent interfacial recombination if it is located at the perovskite/ETL interface. Fu et al. exploited this feature to obtain a PCE of 16.8% with their graded absorber device (Figure 8F), a significant gain from their 14%-efficient reference cells. A similar PCE increase was obtained by Wu et al. who formed a composition gradient through an alternative method.<sup>180</sup> They evaporated a stack of 30 ultrathin PbI2-PbBr2 layer pairs with gradually changing thicknesses of PbI2 and PbBr2. This stack was converted to perovskite by spincoating an organic salt solution with a 4:1 ratio of MAI:MABr and annealing. A PCE of 18.2% was recorded by the graded device, higher than the 17.3% and 16.6% values achieved by the homogeneous mixed-halide cell and pure iodide cell, respectively. 

Very recently, Dewi et al. showed an easy method to increase the band gap of coevaporated MAPbI3 (�1.60 eV) through MABr spin-coating.<sup>45</sup> The best MABrtreated films exhibited a band gap of 1.66 eV (MAPb(Br0.18I0.82)3) and showed good spectral stability. This hybrid method works efficiently, even for thick (�750 nm) co-evaporated MAPbI3 films, which is unusual for hybrid processes. Contrary to previously presented methods, no solvent vapor treatment was needed, and the extent of halide exchange could be controlled simply by varying the delay between the MABr solution drop and the onset of spin-coating. The n-i-p PSCs constructed with the MAPb(Br0.18I0.82)3 films exhibit a blue-shifted external quantum efficiency curve and an open-circuit voltage increase of �30 mV compared with the MAPbI3 PSCs. This TE >> solution hybrid method to create wide band-gap perovskites can be applied to MAPbI3 films deposited on both flat and textured surfaces, making it suitable for tandem cell applications. 

Some of the benefits of hybrid processing can only be accessed if the TE step is performed first. For example, Tao et al. incorporated a phenyl-C61-butyric acid methyl ester (PCBM) interlayer between MAPbI3 and TiOx in their PSC.<sup>181</sup> The PCBM-containing cells exhibited a high PCE of 17.6% and a far weaker current-voltage hysteresis compared with TiO2-only cells. However, this device architecture is not amenable to standard solution-processing perovskite recipes, as the PCBM layer is easily damaged by commonly used solvents, such as DMF, DMSO, and gammabutyrolactone (GBL). Therefore, the TE >> solution approach was used, where the PbI2 layer was thermally evaporated onto PCBM before an MAI solution was spincoated to form the perovskite film. Applying TE as the first perovskite deposition step avoids the need for a solvent that is both suitable for the perovskite precursors and orthogonal to the underlying layers. Moreover, it also simplifies investigations of CTL materials by eliminating solvent compatibility concerns. For example, the TE >> solution path was used to study composite HTLs such as P3HT nanowires embedded in a poly(methyl methacrylate) (PMMA) matrix<sup>182</sup> or a VOx/CuPc bilayer.<sup>183</sup> 

2714 Joule 6, 2692–2734, December 21, 2022 

**ll** 

### Review 

Another order-specific advantage that requires a TE-first approach is the conformal coating of the substrate. This characteristic is highly sought after for perovskite/silicon tandem cells, where the use of a double-side pyramidal-textured silicon layer is desirable to improve light management. The early iterations of perovskite/silicon tandem cells relied on solution-processed perovskite layers, which led to poor coverage of the micron-scale pyramids and current leakage paths.<sup>168,184</sup> Consequently, either a flat silicon layer or one that is textured only on the back side is used, resulting in sub-optimal light trapping.<sup>185–189</sup> The best alternative achievable with solution processing is a micrometer-thick perovskite layer deposited from a concentrated precursor solution.<sup>184</sup> The perovskite fully infiltrates the pyramid valleys and covers the peaks but does not conform to the texture, resulting in a wide variation in perovskite thickness. Although this device design was shown to produce a high PCE (25.7%), it required a multistep defect passivation approach to enable charge carriers to traverse the thick perovskite film. In contrast, a conformal perovskite film on textured silicon can be easily achieved using metal halide evaporation followed by conversion to perovskite through solution processing. Multiple groups have successfully used this method to fabricate double- and triplejunction perovskite/textured silicon tandem cells with efficiencies of up to 27.5% (Figure 8G).<sup>45,166,168,190,191</sup> Moreover, the TE >> solution path has also produced perovskite/Cu(In,Ga)Se2 tandem cells in fourand two-terminal configurations.<sup>179,192,193</sup> When coupled with a low-temperature deposition recipe and flexible, transparent electrodes,<sup>194</sup> this all-thin-film design can be produced on flexible substrates, greatly widening the application space of tandem cells. The limitation of the TE >> solution approach lies in the achievable thickness of the perovskite film.<sup>105–107</sup> Indeed, for PbI2 films above 300 nm, the conversion into perovskite is rarely complete. However, this impediment is not a disadvantage for tandem cells in practice, as the low-energy photons not absorbed by the relatively thin perovskite layer can be harvested by the subjacent absorber. 

##### Solution >> thermal evaporation 

The solution >> TE approach has produced several relatively efficient PSCs—and two very efficient cells—despite being used only in a small number of studies (Figure 9A; Table S7). Since its earliest applications and up until recent years, this method has been used primarily in an attempt to obtain good perovskite film morphology. Reports describe the reproducible formation of smooth, compact, and uniform films consisting of large and strongly crystalline grains that fully cover the substrates (Figures 9B and 9C).<sup>195,197–206</sup> This was achieved through various methods, such as forming a bilayer lead halide film through spin-coating and TE,<sup>198,199,205</sup> controlling the crystallization of the intermediate product with a polymer,<sup>200</sup> and using a multilayer precursor deposition approach to enable the complete formation of high-quality perovskite films.<sup>201,202</sup> Notably, many studies have shown that even without introducing any unique adaptations, a typical procedure of spin-coating followed by TE (Figure 9D) can produce higher-quality films compared with solution-only deposition approaches.<sup>195,197,203,206</sup> 

Beyond film morphology improvements, a few studies have applied the solution >> TE method to produce high-performance PSCs through other avenues. Hawash et al. evaporated a 4-nm-thick MAI interlayer between their spin-coated MAPbI3 and spiro-OMeTAD to tune the perovskite’s interfacial energy level.<sup>207</sup> Remarkably, they found that such a thin MAI layer tends to decompose when deposited on MAPbI3, but the decomposition products tuned the energy levels favorably and resulted in a PCE increase from 15.0% to 17.2%. Another example of interfacial modification was described by Ran et al.<sup>208</sup> They evaporated PEAI on top of spin-coated 

Joule 6, 2692–2734, December 21, 2022 2715 

**ll** 

Review 



Figure 9. Small-area (<1 cm<sup>2</sup> ) PSCs with multistep hybrid TE-solution processing perovskite deposition, where the first step is solution-processing 

(A) Evolution of PCEs achieved over time by organic-inorganic, fully inorganic, and Pb-free PSCs. See also Table S7. 

(B) Top-view SEM image of a CsPbBr3 film deposited through PbBr2 spin-coating and CsBr evaporation. Reproduced with permission from Li et al.,<sup>195</sup> copyright 2019 American Chemical Society. 

(C) Cross-sectional SEM image of a FAMAPbBrI device fabricated with a sequence of drop-casting, evaporation, and spin-coating. Reproduced with permission from Shen et al.,<sup>196</sup> copyright 2022 Royal Society of Chemistry. 

(D) Schematic of a typical solution >> TE perovskite deposition pathway. The method shown here produced the perovskite film shown in (B). Reproduced with permission from Li et al.,<sup>195</sup> copyright 2019 American Chemical Society. 

(E) Stabilized PCE plot of the most efficient PSC fabricated through solution > TE. Reproduced with permission from Shen et al.,<sup>196</sup> copyright 2022 Royal Society of Chemistry. 

FAI to form a bilayer organic salt film, then evaporated SnI2 to transform it into a Pbfree perovskite absorber layer. The quasi-2D and 3D layers formed a bulk heterojunction and exhibited a �30% reduction in trap state density in addition to better device stability compared with the 3D-only device. Optimization of the PEAI concentration resulted in a champion PCE of 5.28%, which was further enhanced to almost 7% by LiF evaporation between ITO and the poly(3,4-ethylenedioxythiophene) polystyrene sulfonate (PEDOT:PSS) HTL. Trap passivation through evaporation of an additive is also feasible for all-inorganic perovskites, as was shown by Zhang et al. Their 

2716 Joule 6, 2692–2734, December 21, 2022 

**ll** 

### Review 

spin-coated CsPbI2Br PSCs reached an impressive stabilized efficiency of 15.8% thanks to interfacial and grain boundary passivation by Br-rich perovskite formed through CsBr evaporation.<sup>209</sup> Chen et al. fabricated a relatively more complex device through co-evaporation of MAPbI3 on top of spin-coated nanocrystalline CsPbBr3.<sup>210</sup> The inorganic perovskite improved the interfacial charge transfer between the MAPbI3 and the TiO2 ETL, and also act as a downshifter material to enhance light absorption and minimize UV-induced degradation. Due to its large Stokes shift and high luminescence quantum yield, CsPbBr3 can absorb UV light and efficiently reemit it in the visible (green) range. The downshifted photon is then absorbed by MAPbI3 and converted to charge carriers. The nanocrystal layer increased the PSC efficiency by 11.6% (relative) to a maximum of 16.4%. 

Very recently, two reports of very efficient and stable cells made via solution >> TE were published, in which the excellent device performance was attributed to morphology control. The first is by Shen et al., whose unique solution >> TE deposition recipe resulted in an extremely high PCE of 25.2% (Figure 9E).<sup>196</sup> This efficiency is significantly greater than the highest values achieved by other multistep hybrid paths (21.2% for TE-gas reaction and 19.7% for TE >> solution) and is very close to the record PCE of solution-processed PSCs (25.8%).<sup>211</sup> They first dropcasted a solution of FA0.995MA0.005Pb(Br0.005I0.995)3 in GBL and pressed a polydimethylsiloxane template onto the wet film, forcing it to form domains on the substrate. Mild heating evaporated the solvent and left an array of perovskite crystals. Then, PbI2 was deposited onto the array via TE, as solution processing was deemed likely to destroy the crystal array. Finally, spin-coating of an FAI-MABr solution and annealing in a DMF-DMSO atmosphere was performed to complete the perovskite. The regularly distributed perovskite crystal array becomes nucleation sites and enables a controllable crystallization, forming very large grains (>3 mm on average) with high crystallinity and low-defect density. The second report describes Wang et al.’s success in fabricating a 24.1%-efficient MA-free CsxFA1�xPbX3 PSCs.<sup>212</sup> They first spin-coated a solution of PbI2, PbCl2, and CsBr to form the inorganic film. Then, FAI was evaporated, and the resulting stack was annealed to form the perovskite. Large-grained and high-quality perovskite films were obtained due to the inclusion of a chloride salt precursor and the uniformity of FAI evaporation. 

#### THERMALLY EVAPORATED LARGE-AREA PEROVSKITE SOLAR CELLS AND MINI-MODULES 

TE’s ability to uniformly deposit large-scale thin films makes it a popular deposition method in the semiconductor industry, such as in organic light-emitting diode (OLED) production lines. Thanks to this advantage, TE is well-poised to be a fabrication method of choice for perovskite PV modules of commercially relevant sizes as well. The standard approach to producing a PSM is to first make a large-area cell, then divide it into multiple electrically connected cells through monolithic interconnections.<sup>213</sup> One interconnection is typically composed of three lines, so-called P1, P2, and P3. Briefly, P1 lines separate neighboring cells at the TCO layer, P2 lines provide a connection between one cell’s cathode to the next cell’s anode, and P3 lines isolate adjacent cells at the back contact.<sup>214</sup> The areas occupied by these lines and the spaces between them do not contribute to power generation, hence they are called the dead area, as opposed to the cell’s active area where photogenerated charge carriers are harvested. These interconnection lines can be scribed with a pulsed laser beam (laser scribing) or a knife (mechanical scribing). The choice of scribing method greatly affects the geometric fill factor (GFF) parameter, defined as the ratio between the active area and the sum of active and dead areas (aperture area). In this section, all areas and PCEs are measured using the active area convention, unless otherwise stated. 

Joule 6, 2692–2734, December 21, 2022 2717 

**ll** 

Review 

The TE of large-area PSCs (R1 cm<sup>2</sup> active area) and PSMs has been a relatively understudied topic so far. Although there have been several reports in this field, it remains far less researched compared with TE of lab-scale PSCs. In Figure 10 and Table S8 we have summarized the results obtained with 1-step TE (Figure 10A), multistep all-TE (Figure 10B), and multistep hybrid processes (Figure 10C). We can see that most published reports for large-area devices used multistep hybrid deposition. To ease perovskite PV’s transition to industry and minimize both capital expenditure and fabrication cost, a relatively simple manufacturing procedure is desirable. We believe that 1-step TE offers both simplicity and excellent process engineering capabilities for the fabrication of large-area PSCs and PSMs. 

##### One-step thermal evaporation 

Thus far, all large-area PSC/Ms deposited via 1-step TE have been fabricated via coevaporation. Despite the relatively few studies, co-evaporated PSMs have demonstrated a very low upscaling loss (Figure 10A). The first two large-area cells were reported in 2017–2018.<sup>78,84</sup> Both used fully inorganic perovskites and performed equally well, with active areas of 1.2 and 1.0 cm<sup>2</sup> and PCEs of 5.5% and 5.4%, respectively. Then, the first module was fabricated by Abzieher et al. in 2019.<sup>217</sup> This module was composed of five MAPbI3 cells with an active area of 0.46 cm<sup>2</sup> each, making a total active area of 2.3 cm<sup>2</sup> . The achieved PCE of 12.4% was a considerable drop from the small-area cell reported in the same study (15.4%, 0.105 cm<sup>2</sup> ), but it was also a significant leap from previous studies and marked a turning point toward highly efficient large-area PSCs and PSMs. In 2020–2021, large-area PSCs and PSMs incorporating co-evaporated MAPbI3 films were reported in several publications by our group and others in both n-i-p and p-i-n configurations. The upscaling process is usually performed gradually, starting from 0.1 cm<sup>2</sup> cells (�19%–20% PCE) and progressing first to 1 cm<sup>2</sup> cell (18%–19% PCE) and then to 2–4 cm<sup>2</sup> cells (�16%–17% PCE).<sup>10,47,218</sup> Subsequently, the PSCs were further enlarged up to tens of cm<sup>2</sup> in an active area and then divided using a monolithic interconnection scheme to form PSMs composed of serially connected cells. This process resulted in modules ranging from �4 to 48 cm<sup>2</sup> in the active area and from 13.7% to 18.8% in PCE.<sup>9,10,44,219</sup> 

Focusing on the two PSMs with the largest reported active areas reveals distinct approaches toward high-performance co-evaporated modules. Li et al. produced a 21 cm<sup>2</sup> n-i-p PSM with a PCE of 18.1% through a thorough optimization of device layers and interfaces (Figure 10A, inset).<sup>10</sup> This effort includes the selection of SnO2 over TiO2 as a more suitable ETL, the inclusion of PCBM at the perovskiteSnO2 interface to improve carrier selectivity, treatment of the evaporated MAPbI3 with potassium acetate to increase grain boundary conductivity and reduce nonradiative recombination, and the use of LiF as an anti-reflection coating to reduce reflection losses. However, a combination of laser scribing, knife scribing, and masking tape was used to define the interconnection area, resulting in a low GFF of 72%. Meanwhile, Ritzer et al. developed a fully evaporated p-i-n module with an all-laserscribed optimized interconnection design.<sup>9</sup> They obtained a PSM with an active area of 48 cm<sup>2</sup> , a GFF of 94%, and a PCE of 17.6%, the highest ever recorded for a fully evaporated module. Promisingly, their PSMs exhibited a very low upscaling PCE loss of 3.1% (relative) per order of magnitude increase in the device area. 

##### Multistep all-thermal evaporation 

Just like with small-area devices, multistep TE is a relatively less popular deposition method for large-area PSCs and PSMs compared with one-step TE. Multistep TE produced the first-ever evaporated large-area PSC in early 2015, a 1 cm<sup>2</sup> cell with a PCE of 13.8%, which was rather impressive at that point.<sup>107</sup> However, the next 

2718 Joule 6, 2692–2734, December 21, 2022 

**ll** 

### Review 



Figure 10. TE large-area PSCs and PSMs (A–C)Show the achieved PCEs versus active areas of PSC/Ms fabricated via (A) 1-step TE, (B) multistep all-TE, and (C) multistep hybrid, respectively. See also Table S8. Insets in (A)–(C) show photographs of selected PSMs. The inset in (A) is a MAPbI3 6-cell PSM, reproduced with permission from Li et al.,<sup>10</sup> copyright 2020 Elsevier. Insets in (B) show (top) rigid and (bottom) flexible sequentially evaporated 8-cell MAPbI3 PSMs, reproduced with permission from Lei et al.,<sup>115</sup> copyright 2020 Wiley-VCH. The left inset in (C) is a flexible 8-cell MAPbI3 PSM deposited via PbI2 evaporation and MAI spin-coating, reproduced with permission from Pisoni et al.,<sup>215</sup> copyright 2018 Elsevier. The right inset in (C) shows the largest TE PSM, a 14-cell Cs0.1FA0.9PbBr0.1I2.9 module, reproduced from Qiu et al.<sup>216</sup> under the Creative Commons CC-BY-NC 3.0 License. 

Joule 6, 2692–2734, December 21, 2022 2719 

**ll** 

Review 

1 cm<sup>2</sup> cell only came in 2019, when Liu et al. reported a 7.6%-efficient CsPbBr3 PSC.<sup>125</sup> More recently, a 1 cm<sup>2</sup> MAPbI3 cell reached a very high PCE of 23.44% and several modules also showed good performance (Figure 10B), suggesting that further developments in large-area applications of multistep TE are coming.<sup>11</sup> 

Lei et al. described the production of fully evaporated rigid (Figure 10B, top inset) and flexible (Figure 10B, bottom inset) 16 cm<sup>2</sup> PSMs via sequential flash evaporation of PbI2 and MAI.<sup>115</sup> The authors employed a doped HTL where the HTL (2T-NATA, 4,4<sup>0</sup> ,4<sup>00</sup> -tris(N-(naphthalene-2-yl)-N-phenylamino)triphenylamine) and the dopant (F4-TCNQ, 2,3,5,6-tetrafluoro-7,7,8,8-tetracyanoquinodimethane) were co-evaporated. The rigid and flexible modules reached an efficiency of 15.1% and 13.2%, respectively. Beyond MAPbI3, Niu et al. and Feng et al. fabricated mixed-cation PSMs with active areas around 10 cm<sup>2</sup> . Niu co-evaporated CsI and PbI2 and followed it up with flash evaporation of MAI to form a Cs0.05MA0.95PbI3 film.<sup>220</sup> Their PSM had an active area PCE of 10.2%, but the dead area was very wide as the active areas were defined by successive masking instead of scribing. Consequently, the module had a GFF of only �21% and an aperture area PCE of 2.1%. Feng et al. used a different approach and sequentially evaporated PbI2, FAI, and CsI to form Cs0.15FA0.85PbI3.<sup>221</sup> The films were incorporated into fully evaporated modules with a PCE of 14.6%. The low fill factor (56%) was identified as the performancelimiting parameter, suggesting that the module design can be improved through resistance loss minimization and optimization of the cell and P2 line widths. A breakthrough was recently achieved by Li et al., whose Cs0.05FA0.95PbI3 module recorded a PCE of 20.92% on an active area of 13.68 cm<sup>2</sup> .<sup>11</sup> This success was attributed to the inclusion of PbCl2 in the metal halide layer, which facilitated the complete formation of an a-phase perovskite with high crystallinity. Besides complete modules, perovskite films with areas of 400 and 300 cm<sup>2</sup> on glass and PET substrates, respectively, have been fabricated.<sup>221</sup> These films demonstrated excellent thickness and performance uniformity across the large area, proving the viability of multistep TE (and TE in general) as a scalable perovskite deposition method. 

##### Multistep hybrid deposition 

Multistep hybrid deposition techniques were used to deposit the perovskite layer in about half of the reported large-area PSCs and PSMs. Specifically, the TE-gas reaction combination and the TE >> solution method (using either spin-coating or CBD) dominate, while the solution >> TE path contributes only three large-area cells. However, two of these three cells feature the highest PCEs (22.8% and 22.3%) of all large-area devices fabricated via multistep hybrid deposition,<sup>196,212</sup> while the other one is the only fully inorganic entry in this section, a 1 cm<sup>2</sup> CsPbBr2I cell with a PCE of 6.8% (Figure 10C).<sup>206</sup> So far, multistep hybrid devices still lead those of one-step and multistep TE in terms of the active area, with the largest module coming close to passing the 100 cm<sup>2</sup> benchmark (Figure 10C).<sup>216</sup> However, in terms of module efficiency, it still lags behind co-evaporation and multistep TE (Figure 10). 

Most of the large-area cells have active areas between 1 and 2.5 cm<sup>2</sup> , and PCEs range from 7.7% to 14.5%.<sup>148,192,222–228</sup> All these cells use either a MAPbI3 or FAPbI3 perovskite layer with one notable exception. Lin et al. fabricated a 3D/2D bilayer perovskite via a three-step deposition process, namely PbI2 evaporation followed by two rounds of gas reactions with MAI and BAI, respectively.<sup>148</sup> Their 1 cm<sup>2</sup> cell attained a PCE of 14.1%, the second-highest among all multistep hybrid largearea PSCs. Larger cells were produced by Chen et al., who made 4 and 16 cm<sup>2</sup> MAPbI3 PSCs with PCEs of 5.6% and 4.8%, respectively.<sup>225</sup> The PCE declined 

2720 Joule 6, 2692–2734, December 21, 2022 

**ll** 

### Review 

significantly from the 12.1% value exhibited by the 0.1 cm<sup>2</sup> cell, highlighting the need to transform such large cells into modules. 

Fabrication of PSMs with the TE-gas reaction hybrid technique was pioneered by Leyden et al. in 2016.<sup>227</sup> They gradually scaled up FAPbI3-based devices from an active area of 2 cm<sup>2</sup> (cell, 10.4% PCE) to 8.8 cm<sup>2</sup> (5-cell module, 7.6% PCE), 12 cm<sup>2</sup> (6-cell module, 8.8% PCE), and 15.4 cm<sup>2</sup> (6-cell module, 5.8% PCE). The markedly lower efficiency for the largest module was attributed to shorted adjacent cells in the module due to incomplete removal of TiO2 via photolithography and plasma-based dry etching. The next two attempts at PSM production via TE and gas reaction were made by Luo, Deng, and colleagues from Yi-bing Cheng’s group. Luo et al. sequentially evaporated CsBr and PbI2, then exposed the deposited film to a mix of FAI and FACl vapor. They varied the Cs:FA balance and found that a ratio of 0.24:0.76 produced the highest quality film and the most efficient cells. This formulation was upscaled into a module with an active area of 41.25 cm<sup>2</sup> and a PCE of 12.2%. Deng et al. then improved upon Luo’s deposition procedure by adding 4 nm of SrI2 between the CsBr and PbI2 films to improve film morphology and reduce trap state concentration.<sup>146</sup> The produced PSM reached a PCE of 13.9%, although the active area was shrunk to 16 cm<sup>2</sup> . 

Several reports on TE >> solution deposition of MAPbI3 PSMs were published in 2018, with spin-coating used as the solution-based step in all cases. The first was by Li et al., a flexible module constructed on a PEN substrate with a 16 cm<sup>2</sup> active area and an 8.6% PCE. This was followed shortly after by the work of Pisoni et al. They evaporated a LiF interlayer between the C60 ETL and aluminum-doped zinc oxide contact, resulting in an 11.2%-efficient flexible module with an active area of 9.6 cm<sup>2</sup> (Figure 10C, left inset). LiF induced a favorable band bending at the ETL/ contact interface, assisting with electron extraction and minimizing interfacial recombination. A subsequent study by Li et al. produced relatively large modules with active areas of 31.71 and 49 cm<sup>2</sup> , whose PCEs were 13.8% and 12.2%, respectively.<sup>229</sup> 

Finally, the largest evaporated PSM so far was introduced by Qiu et al.<sup>216</sup> They deposited a Cs0.1FA0.9PbBr0.1I2.9 film through a sequence of CsBr-PbI2 co-evaporation, FAI gas reaction, and washing with a solution of KI in isopropanol. Their PSM is composed of 14 cells with a total active area of 82.6 cm<sup>2</sup> , a GFF of �90%, and a PCE of 10.4% (Figure 10C, right inset). There is room for improvement in the GFF as the P3 lines in these modules were still mechanically scribed. Furthermore, the relatively low fill factor of 60% indicates a sub-optimal module design. Future development of TE PSMs should focus not only on high-quality film deposition but also on cell geometry and monolithic interconnection optimization. 

#### CONCLUSIONS AND PERSPECTIVES 

More than a decade into perovskite PV research, spin-coating—and solution processing in general—remains the most widespread method to fabricate PSCs. To illustrate this point, at the time this review was written, the perovskite database constructed by Jacobsson, Unger, and colleagues<sup>230</sup> contained 33,743 devices (from 5,980 articles) deposited solely by spin-coating. In stark contrast, it includes just 1,141 devices (from 229 articles), whose perovskite layer was deposited using one of the TE techniques discussed in this review. This vast discrepancy makes it even more impressive that TE PSCs have advanced so far in improving the PCE of labscale PSCs and translating them into large-area devices. 

Joule 6, 2692–2734, December 21, 2022 2721 

**ll** 

Review 

TE is an appealing deposition method for the industrial manufacture of perovskite PV devices, not only because of the high PCEs achievable on both small- and large-area devices but also due to its beneficial features. These include a high degree of process control, precisely controllable film thickness, easy sequential addition of multiple layers, and low-substrate temperature processability. Moreover, the sublimation procedure itself purifies the precursors during the film formation, resulting in very high material and film quality. In turn, this leads to excellent spatial uniformity within a device batch, good reproducibility across multiple fabrication rounds, and high production yield, which are key aspects of industrial application. The absence of solvents in the deposition not only removes solvent orthogonality concerns but also eliminates a major source of toxicity and environmental hazards. Furthermore, the entire process can be automated and controlled, making it intrinsically attractive for large-scale and high-throughput manufacturing. All these characteristics make TE suitable for industrial processes. Indeed, TE is already a familiar technique in the microelectronic and optoelectronic industries, where it has been used for many years to fabricate OLEDs, metal contacts, and coatings of various materials. In short, TE-based processes are mature techniques with clear advantages for the preparation of multilayered thin films over large areas, and it represents a significant opportunity to push metal halide perovskites from laboratories to production lines. 

Besides all these advantages, there are also some limitations to overcome to bring TE-based perovskite deposition to the next level. Despite the high level of process control, simultaneous evaporation of more than two or three perovskite precursors remains challenging to fine-tune, especially when one or more of those precursors are organic molecules. Consequently, although the co-evaporation of complicated perovskite stoichiometries has been successfully demonstrated,<sup>64,68,71</sup> further process development has progressed slowly for 1-step TE and multistep all-TE. More mixed-cation, mixed-halide perovskites have been deposited using multistep hybrid TE approaches.<sup>159,163,191</sup> The gas reaction and solution-processing steps offer an easier way to incorporate additives in devices and more flexibility in deposition parameter optimization, thus easing the fabrication of complex perovskites and decreasing the process timing. Naturally, the impact of some of TE’s advantages is reduced in hybrid deposition recipes. The benefits of multistep hybrid TE also come at the cost of increasing process complexity and capital expenditure compared with 1-step TE and multistep all-TE pathways. 

With its many advantages, TE-based methods lend themselves well to the fabrication of PSMs. In principle, all the methods discussed in this review are suitable for module manufacture. However, in practice, it would be desirable to produce not only evaporated perovskite films but also fully evaporated modules using the same fabrication lines. This preference stems from the high likelihood that a production line composed of both vacuum-based and solution-based deposition systems would be more complex and costlier to run and maintain. To maximize production yield and hence reduce the production cost of TE-based PSMs, we believe that in the near future, substantial research should be focused on the development of TE methods that require shorter deposition times. Indeed, for industrial applications, manufacture time is a key factor in bringing new technology to the production lines. In this regard, flash evaporation is a very promising candidate, given its proven ability to deposit 200- to 500-nm-thick films in less than 5 min, and even down to a few seconds.<sup>91–93,95,97,98</sup> More research on this topic could drive the most suitable industrial-compatible methods. At the same time, there are at least three major topics where more research effort should be invested, namely the device interlayers, perovskite defect passivation, and device stability. 

2722 Joule 6, 2692–2734, December 21, 2022 

**ll** 

### Review 

##### Device interlayers 

CTLs with suitable energy levels, fast charge extraction, high charge carrier selectivity, wide spectral transparency, and good stability are necessary to obtain high-performance devices. Beyond those material properties, a few more qualities are highly desirable in the context of TE. First, ideally, the CTLs can be deposited via evaporation to enable TE-only fabrication lines. Several CTL materials that fulfill these criteria have been identified, such as fullerenes, CuPc, thiophene polymers, MoO3/TaTm couple, and various triarylamine derivatives.<sup>28,231–236</sup> The second important characteristic, for the substrate-side CTL specifically, is its surface’s suitability for perovskite nucleation and growth. With solution processing, it is well-known that the transport layer’s nature influences the morphology, crystallography, composition, and stability of the perovskite film deposited onto it.<sup>237–239</sup> Indeed, many studies have been devoted to the careful selection and tailoring of substrate-side CTLs with the express purpose of improving the perovskite layer quality.<sup>240–242</sup> A range of experiments conducted on various organic and inorganic CTLs have confirmed that this strong dependence of perovskite quality on the CTL properties also holds true for evaporated films.<sup>49,60</sup> For example, non-polar CTLs were found to induce desirable columnar grain growth in co-evaporated MAPbI3.<sup>49</sup> We expect there to be more such determining characteristics, whose exact forms of influence on perovskite properties are yet to be delineated. Third, the first tens of nanometers of evaporated perovskite films can be amorphous or non-stoichiometric.<sup>60,243,244</sup> Such a layer is undesirable, as it leads to current-voltage hysteresis and series resistance. To prevent that, the substrate-side CTL must not chemically react with the perovskite precursors. Furthermore, all-perovskite precursors should have similar absorptivities on the surface of the substrate-side CTL to foster the nucleation and early-phase growth of stoichiometric perovskite films. The interface formed by the substrate-side CTL and the perovskite layer is a very important one in evaporated devices, if not the most important. It is a topic deserving deeper investigation to identify, first, the various properties that make a material suitable CTLs for evaporated devices and, second, ways to synthesize and deposit such materials. 

Another method to engineer a high-quality interface in devices is to insert ultrathin interlayers between the CTLs and the perovskite film or between the CTLs and the contacts. Interlayers can ease the search for appropriate CTL materials by assuming surface-specific roles, such as fostering perovskite nucleation and providing a suitable energy band alignment. This focuses the CTL material selection on the bulk properties, such as high conductivity and stability. This advantage comes with a necessity to ensure good compatibility between the interlayer and the CTL. Fortunately, TE can make interlayer insertion simpler due to the accurate control over film thickness and lack of solvent compatibility concerns with the underlying layers. Thickness control is a particularly important feature as interlayers that are too thick often contribute to series resistance.<sup>245</sup> So far, relatively few interlayers amenable to TE have been investigated. These range from simple compounds like LiF,<sup>215</sup> Cu2O,<sup>118</sup> BaI2,<sup>246</sup> and C6021 to complex organic molecules such as TPBi<sup>234</sup> and F4-TCNQ,<sup>232</sup> among others.<sup>247,248</sup> The hunt for suitable interlayers should be done in parallel with the exploration of CTL materials to obtain robust and efficient PSCs and PSMs. 

##### Defect passivation strategies 

Although PSCs are relatively tolerant to vacancies and interstitials, surface and interfacial defects play a large role in current-voltage hysteresis and prevent open-circuit voltage from reaching its radiative limit.<sup>249–251</sup> Furthermore, minimizing overall defect density improves device stability as defect sites, including shallow point defects, enable ion migration and various degradation mechanisms.<sup>252–255</sup> In the past 

Joule 6, 2692–2734, December 21, 2022 2723 

**ll** 

Review 

few years, significant experience has been developed in defect passivation of various solution-processed perovskite compositions.<sup>3,256</sup> A large variety of additives have been found to passivate both point and interfacial defects in solution-processed PSCs. These range from metal ions, excess precursors, and ionic liquids to Lewis acids, Lewis bases, and zwitterions.<sup>256</sup> Due to the ionic nature of the perovskite’s inorganic sublattice, defects commonly exist as dangling bonds from undercoordinated B cations or X anions.<sup>256</sup> The former act as Lewis acids and can therefore be healed by Lewis bases containing electron-donating atoms or by excess halides. Conversely, the latter are Lewis bases that can be neutralized by electron-accepting additives or metal cations.<sup>257</sup> Because undercoordinated cations and anions tend to be present together, zwitterions with oppositely charged ends have been used to effectively passivate both defects with one additive.<sup>258</sup> 

Overall, defect passivation has improved the PCE and stability of PSCs. However, most of the explored additives were incorporated into small-area PSCs either through direct inclusion into the precursor solution (bulk passivation) or by spincoating them on the formed perovskite layer (interfacial passivation). Although the interfaces of evaporated perovskite films can be passivated via solution-processing<sup>10,218</sup> or an additional round of TE,<sup>21,234</sup> the ability to evaporate a bulk passivator together with the perovskite precursors would greatly simplify the device fabrication process. In practice, the challenge of co-evaporating precursors and bulk passivator(s) lies in simultaneously controlling the evaporation and deposition of a high number of compounds. This is especially true because the ideal deposited amount of a bulk passivator is usually orders of magnitude lower than those of the perovskite precursors. One reason that this problem has not been satisfactorily solved may be in part because the literature on TE perovskites has so far been dominated by MAPbI3. As described above, MAI is a notoriously difficult precursor to controllably evaporate. Attempting to co-evaporate a small amount of bulk passivator together with MAI will only amplify the process complexity. Therefore, the quest for bulk passivation materials and strategies that are suitable for controllable and spatially homogeneous evaporation is crucial to further improve the performance of TE PSCs. 

##### Device stability 

One of the most important challenges to tackle on perovskite PV’s path toward commercialization is its poor operational stability relative to established PV technologies. Indeed, techno-economic analyses projecting the levelized cost of electricity and energy payback time for PSCs have found that both quantities are very sensitive to device lifetime.<sup>259–261</sup> One proposed benchmark is that PSCs need to be sufficiently stable to reach at least a 15-year lifetime, defined as the period over which the PCE declined to 80% of its original value.<sup>262</sup> Perovskite degradation can be induced by several stimuli, such as heat, light, moisture, and oxygen.<sup>263,264</sup> Furthermore, additional degradation pathways arise in PSMs due to the presence of interconnection areas.<sup>265,266</sup> Although the lifetimes of most research devices in the literature are short of the 15-year benchmark, there are signs that PSCs have the potential to be as stable as silicon panels (25–30 years), provided they are carefully designed. For example, a 2020 report, which extrapolated published stability data, identified three device designs that could achieve a 20-year lifetime.<sup>262,267–269</sup> Shortly afterward, two studies reported PSCs that successfully met the requirements of IEC 61215, a series of industrialstandard accelerated degradation tests designed to assess the fitness of PV modules for long-term operation in an open-air climate.<sup>270,271</sup> 

All the studies highlighted above used solution-processed perovskite, but it does not mean that evaporated perovskites have not demonstrated promising stability 

2724 Joule 6, 2692–2734, December 21, 2022 

**ll** 

### Review 

despite the comparatively smaller research effort invested into it. To cite just a few examples, unencapsulated co-evaporated MAPbI3 PSCs have maintained 80% of their original PCE after 3,600 h of continuous thermal aging at 85<sup>�</sup> C with 10% relative humidity and 95% after 12,000 h of ambient storage at 28<sup>�</sup> C with 30% relative humidity.<sup>46</sup> Another work showed that co-evaporated PSCs could preserve 100% of their original PCE after 1,000 h of continuous operation.<sup>43</sup> Furthermore, PSCs incorporating a wide band-gap perovskite prepared with multistep TE-solution processing maintained 95% of their original PCE after almost 10,500 h of dark storage in N2 atmosphere.<sup>191</sup> Lastly, PSCs with the perovskite layer produced by the solution >> TE approach conserved 100% of their original PCE after 1,000 h in the ambient summer air with 50% relative humidity and 95% after 20,000 h of storage in dry air.<sup>212</sup> 

These important works not only demonstrate the state-of-the-art robustness of TE perovskite but also highlight paths toward excellent intrinsic and extrinsic perovskite stabilities. First, there is evidence that perovskites with the same chemical composition are more stable when prepared by TE than by solution processing. Gordillo et al. found that MAPbI3 films made via PbI2 TE and either MAI dipping or gas reaction are more resistant to humidity-induced decomposition compared with spin-coated MAPbI3. This advantage was attributed to a lower density of structural defects and grain boundaries.<sup>272</sup> More recently, Dewi et al. also reported the absence of tensile stress and strain in co-evaporated MAPbI3, enabling intrinsically stable films and devices at high temperatures, in contrast to strained and unstable spin-coated MAPbI3 films.<sup>46</sup> Strain-free TE is a highly appealing choice of deposition method, as strained halide perovskite exhibits poorer optoelectronic properties.<sup>273</sup> Second, for perovskite compositions like FAPbI3, which suffer from phase instability in ambient conditions, the photoactive phase’s stability may be enhanced through a judicious choice of the substrate-side CTL.<sup>43</sup> This further stresses the great importance of the subjacent layer in the TE of halide perovskites.<sup>49,60</sup> Third, getting the correct perovskite stoichiometry over the entire deposition area is also essential to obtain good stability. For mixedcation, mixed-anion compositions, accurate control of the precursor evaporation rate is necessary to obtain the targeted stoichiometry and suppress spatial heterogeneity, phase instability, and photo-induced halide segregation. Finally, we note that the stability of evaporated perovskite cells is likely to be further enhanced by defect passivation or other additives, which so far have been rarely applied to them. 

#### SUPPLEMENTAL INFORMATION 

Supplemental information can be found online at https://doi.org/10.1016/j.joule. 2022.11.004. 

#### ACKNOWLEDGMENTS 

The authors wish to thank the National Research Foundation (NRF), Prime Minister’s Office, Singapore, under the Solar Competitive Research Program (S18-1176-SCRP) and the Competitive Research Program (NRF-CRP25-2020-04) for financial support. The authors would like to aknowledge also the MOE-T2EP50221-0035 project sponsored by the Singapore Ministry of Education. The authors also acknowledge T.J. Jacobsson and E. Unger’s The Perovskite Database (https://perovskitedatabase.com/), from which a part of the data on devices discussed in this review was taken. 

#### DECLARATION OF INTERESTS 

N.M. and S.M. are directors of Prominence Photovoltaics Pte Ltd, a perovskite solar cell commercialization company. 

Joule 6, 2692–2734, December 21, 2022 2725 

**ll** 

### Review 

#### REFERENCES 

1. Kojima, A., Teshima, K., Shirai, Y., and Miyasaka, T. (2009). Organometal halide perovskites as visible-light sensitizers for photovoltaic cells. J. Am. Chem. Soc. 131, 6050–6051. https://doi.org/10.1021/ ja809598r. 

2. Deng, Y., Zheng, X., Bai, Y., Wang, Q., Zhao, J., and Huang, J. (2018). Surfactant-controlled ink drying enables high-speed deposition of perovskite films for efficient photovoltaic modules. Nat. Energy 3, 560–566. https://doi. org/10.1038/s41560-018-0153-9. 

3. Rana, P.J.S., Febriansyah, B., Koh, T.M., Muhammad, B.T., Salim, T., Hooper, T.J.N., Kanwat, A., Ghosh, B., Kajal, P., Lew, J.H., et al. (2022). Alkali additives enable efficient large area (>55 cm<sup>2</sup> ) slot-die coated perovskite solar modules. Adv. Funct. Mater. 32, 2113026. https://doi.org/10.1002/adfm. 202113026. 

4. Pasquarelli, R.M., Ginley, D.S., and O’Hayre, R. (2011). Solution processing of transparent conductors: from flask to film. Chem. Soc. Rev. 40, 5406–5441. https://doi.org/10.1039/ c1cs15065k. 

5. Luo, L., Zhang, Y., Chai, N., Deng, X., Zhong, J., Huang, F., Peng, Y., Ku, Z., and Cheng, Y.-B. (2018). Large-area perovskite solar cells with CsxFA1�xPbI3�yBry thin films deposited by a vapor–solid reaction method. J. Mater. Chem. A 6, 21143–21148. https://doi.org/10. 1039/C8TA06557H. 

6. Wang, M., Zeng, P., Bai, S., Gu, J., Li, F., Yang, Z., and Liu, M. (2018). High-quality sequential-vapor-deposited Cs2AgBiBr6 thin films for lead-free perovskite solar cells. Sol. RRL 2, 1800217. https://doi.org/10.1002/solr. 201800217. 

7. Vidal, R., Alberola-Borra`s, J.-A., Habisreutinger, S.N., Gimeno-Molina, J.-L., Moore, D.T., Schloemer, T.H., Mora-Sero´ , I., Berry, J.J., and Luther, J.M. (2021). Assessing health and environmental impacts of solvents for producing perovskite solar cells. Nat. Sustain. 4, 277–285. https://doi.org/10.1038/ s41893-020-00645-8. 

8. Vaynzof, Y. (2020). The future of perovskite photovoltaics—thermal evaporation or solution processing? Adv. Energy Mater. 10, 2003073. https://doi.org/10.1002/aenm. 202003073. 

9. Ritzer, D.B., Abzieher, T., Basibu¨ yu¨ k, A., Feeney, T., Laufer, F., Ternes, S., Richards, B.S., Bergfeld, S., and Paetzold, U.W. (2021). Upscaling of perovskite solar modules: the synergy of fully evaporated layer fabrication and all-laser-scribed interconnections. Prog. Photovolt. 30, 1–14. https://doi.org/10.1002/ pip.3489. 

10. Li, J., Wang, H., Chin, X.Y., Dewi, H.A., Vergeer, K., Goh, T.W., Lim, J.W.M., Lew, J.H., Loh, K.P., Soci, C., et al. (2020). Highly efficient thermally co-evaporated perovskite solar cells and mini-modules. Joule 4, 1035–1053. https://doi.org/10.1016/j.joule.2020.03.005. 

11. Li, H., Zhou, J., Tan, L., Li, M., Jiang, C., Wang, S., Zhao, X., Liu, Y., Zhang, Y., Ye, Y., et al. (2022). Sequential vacuum-evaporated perovskite solar cells with more than 24% 

efficiency. Sci. Adv. 8, eabo7422. https://doi. org/10.1126/sciadv.abo7422. 

Energy Lett. 3, 214–219. https://doi.org/10. 1021/acsenergylett.7b01217. 

12. Ding, Y., Ding, B., Kanda, H., Usiobo, O.J., Gallet, T., Yang, Z., Liu, Y., Huang, H., Sheng, J., Liu, C., et al. (2022). Single-crystalline TiO2 nanoparticles for stable and efficient perovskite modules. Nat. Nanotechnol. 17, 598–605. https://doi.org/10.1038/s41565022-01108-1.. 

   23. Era, M., Hattori, T., Taira, T., and Tsutsui, T. (1997). Self-organized growth of PbI-based layered perovskite quantum well by dualsource vapor deposition. Chem. Mater. 9, 8–10. https://doi.org/10.1021/cm960434m. 

- 022-01108-1.. 24. Malinkiewicz, O., Yella, A., Lee, Y.H., Espallargas, G.M., Graetzel, M., Nazeeruddin, 

- 13. Heo, J.H., Lee, M.H., Jang, M.H., and Im, S.H. M.K., and Bolink, H.J. (2014). Perovskite solar (2016). Highly efficient CH3NH3PbI3�xClx cells employing organic charge-transport mixed halide perovskite solar cells prepared layers. Nat. Photon. 8, 128–132. https://doi. by re-dissolution and crystal grain growth via org/10.1038/nphoton.2013.341. spray coating. J. Mater. Chem. A 4, 17636– 17642. https://doi.org/10.1039/C6TA06718B. 25. Malinkiewicz, O., Rolda´n-Carmona, C., 

   25. Malinkiewicz, O., Rolda´n-Carmona, C., Soriano, A., Bandiello, E., Camacho, L., Nazeeruddin, M.K., and Bolink, H.J. (2014). Metal-oxide-free methylammonium lead iodide perovskite-based solar cells: the influence of organic charge transport layers. Adv. Energy Mater. 4, 1400345. https://doi. org/10.1002/aenm.201400345. 

14. Yang, Z., Zhang, W., Wu, S., Zhu, H., Liu, Z., Liu, Z., Jiang, Z., Chen, R., Zhou, J., Lu, Q., et al. (2021). Slot-die coating large-area formamidinium-cesium perovskite film for efficient and stable parallel solar module. Sci. Adv. 7, eabg3749. https://doi.org/10.1126/ sciadv.abg3749. 

   26. Rolda´n-Carmona, C., Malinkiewicz, O., Soriano, A., Mı´nguez Espallargas, G., Garcia, A., Reinecke, P., Kroyer, T., Dar, M.I., Nazeeruddin, M.K., and Bolink, H.J. (2014). Flexible high efficiency perovskite solar cells. Energy Environ. Sci. 7, 994. https://doi.org/10. 1039/c3ee43619e. 

15. Chen, S., Dai, X., Xu, S., Jiao, H., Zhao, L., and Huang, J. (2021). Stabilizing perovskitesubstrate interfaces for high-performance perovskite modules. Science 373, 902–907. https://doi.org/10.1126/science.abi6323. 

16. Liu, M., Johnston, M.B., and Snaith, H.J. (2013). Efficient planar heterojunction perovskite solar cells by vapour deposition. Nature 501, 395–398. https://doi.org/10. 501, 395–398. https://doi.org/10., 395–398. https://doi.org/10. https://doi.org/10. 1038/nature12509.. 

- (2013). Efficient planar heterojunction 27. Rolda´n-Carmona, C., Malinkiewicz, O., perovskite solar cells by vapour deposition. Betancur, R., Longo, G., Momblona, C., Nature 501, 395–398. https://doi.org/10. 501, 395–398. https://doi.org/10., 395–398. https://doi.org/10. https://doi.org/10. Jaramillo, F., Camacho, L., and Bolink, H.J. 1038/nature12509.. (2014). High efficiency single-junction semitransparent perovskite solar cells. Energy 

- 17. Du, P., Wang, L., Li, J., Luo, J., Ma, Y., Tang, J., Environ. Sci. 7, 2968–2973. https://doi.org/10. and Zhai, T. (2022). Thermal evaporation for 1039/C4EE01389A. halide perovskite optoelectronics: fundamentals, progress, and outlook. Adv. 28. Polander, L.E., Pahner, P., Schwarze, M., Opt. Mater. 10, 2101770. https://doi.org/10. Saalfrank, M., Koerner, C., and Leo, K. (2014). 1002/adom.202101770. Hole-transport material variation in fully 

   28. Polander, L.E., Pahner, P., Schwarze, M., Saalfrank, M., Koerner, C., and Leo, K. (2014). Hole-transport material variation in fully vacuum deposited perovskite solar cells. APL Mater. 2, 081503. https://doi.org/10.1063/1. 4889843. 

18. Bae, S.-R., Heo, D.Y., and Kim, S.Y. (2022). Recent progress of perovskite devices fabricated using thermal evaporation method: perspective and outlook. Mater. Today Adv. 14, 100232. https://doi.org/10. 1016/j.mtadv.2022.100232. 

   29. Lin, Q., Armin, A., Nagiri, R.C.R., Burn, P.L., and Meredith, P. (2015). Electro-optics of perovskite solar cells. Nat. Photon. 9, 106–112. https://doi.org/10.1038/nphoton. 2014.284. 

19. Ullah, S., Wang, J., Yang, P., Liu, L., Li, Y., Rehman, A.-U., Yang, S.-E., Xia, T., Guo, H., and Chen, Y. (2021). Evaporation deposition strategies for all-inorganic CsPb(I1– xBrx)3 perovskite solar cells: recent advances and perspectives. Sol. RRL 5, 2100172. https://doi. org/10.1002/solr.202100172. 

   30. Momblona, C., Gil-Escrig, L., Bandiello, E., Hutter, E.M., Sessolo, M., Lederer, K., Blochwitz-Nimoth, J., and Bolink, H.J. (2016). Efficient vacuum deposited p-i-n and n-i-p perovskite solar cells employing doped charge transport layers. Energy Environ. Sci. 9, 3456–3463. https://doi.org/10.1039/ C6EE02100J. 

20. Guesnay, Q., Sahli, F., Ballif, C., and Jeangros, Q. (2021). Vapor deposition of metal halide perovskite thin films: process control strategies to shape layer properties. APL Mater. 9, 100703. https://doi.org/10.1063/5. 0060642. 

   31. Jung, M.-C., Raga, S.R., and Qi, Y. (2016). Properties and solar cell applications of Pbfree perovskite films formed by vapor deposition. RSC Adv. 6, 2819–2825. https:// doi.org/10.1039/C5RA21291J. 

21. Pe´ rez-del-Rey, D., Boix, P.P., Sessolo, M., Hadipour, A., and Bolink, H.J. (2018). Interfacial modification for high-efficiency vapor-phase-deposited perovskite solar cells based on a metal oxide buffer layer. J. Phys. Chem. Lett. 9, 1041–1046. https://doi.org/10. 1021/acs.jpclett.7b03361. 

   32. Ma, Q., Huang, S., Wen, X., Green, M.A., and Ho-Baillie, A.W.Y. (2016). Hole transport layer free inorganic CsPbIBr2 perovskite solar cell by dual source thermal evaporation. Adv. Energy Mater. 6, 1502202. https://doi.org/10. 1002/aenm.201502202. 

22. Longo, G., Momblona, C., La-Placa, M.-G., Gil-Escrig, L., Sessolo, M., and Bolink, H.J. (2018). Fully vacuum-processed wide band gap mixed-halide perovskite solar cells. ACS 

33. Wang, H., Dewi, H.A., Koh, T.M., Bruno, A., Mhaisalkar, S., and Mathews, N. (2020). Bifacial, color-tunable semitransparent 

2726 Joule 6, 2692–2734, December 21, 2022 

## **ll** 

### Review 

perovskite solar cells for building-integrated photovoltaics. ACS Appl. Mater. Interfaces 12, 484–493. https://doi.org/10.1021/acsami. 9b15488. 

34. Kirman, J., Johnston, A., Kuntz, D.A., Askerka, M., Gao, Y., Todorovi�c, P., Ma, D., Prive´ , G.G., and Sargent, E.H. (2020). Machine-learningaccelerated perovskite crystallization. Matter 2, 938–947. https://doi.org/10.1016/j.matt. 2020.02.012. 

35. Higgins, K., Valleti, S.M., Ziatdinov, M., Kalinin, S.V., and Ahmadi, M. (2020). Chemical robotics enabled exploration of stability in multicomponent lead halide perovskites via machine learning. ACS Energy Lett. 5, 3426– 3436. https://doi.org/10.1021/acsenergylett. 0c01749. 

36. Tao, Q., Xu, P., Li, M., and Lu, W. (2021). Machine learning for perovskite materials design and discovery. NPJ Comput. Mater. 7, 23. https://doi.org/10.1038/s41524-02100495-8. 

37. Subbiah, A.S., Halder, A., Ghosh, S., Mahuli, N., Hodes, G., and Sarkar, S.K. (2014). Inorganic hole conducting layers for perovskite-based solar cells. J. Phys. Chem. Lett. 5, 1748–1753. https://doi.org/10.1021/ jz500645n. 

38. Ng, T.-W., Chan, C.-Y., Lo, M.-F., Guan, Z.Q., and Lee, C.-S. (2015). Formation chemistry of perovskites with mixed iodide/chloride content and the implications on charge transport properties. J. Mater. Chem. A 3, 9081–9085. https://doi.org/10.1039/ C4TA05819D. 

39. Agarwal, S., Seetharaman, M., Kumawat, N.K., Subbiah, A.S., Sarkar, S.K., Kabra, D., Namboothiry, M.A.G., and Nair, P.R. (2014). On the uniqueness of ideality factor and voltage exponent of perovskite-based solar cells. J. Phys. Chem. Lett. 5, 4115–4121. https://doi.org/10.1021/jz5021636. 

40. Arivazhagan, V., Xie, J., Yang, Z., Hang, P., Parvathi, M.M., Xiao, K., Cui, C., Yang, D., and Yu, X. (2019). Vacuum co-deposited CH3NH3PbI3 films by controlling vapor pressure for efficient planar perovskite solar cells. Sol. Energy 181, 339–344. https://doi. org/10.1016/j.solener.2019.02.012. 

41. Cojocaru, L., Wienands, K., Kim, T.W., Uchida, S., Bett, A.J., Rafizadeh, S., Goldschmidt, J.C., and Glunz, S.W. (2018). Detailed investigation of evaporated perovskite absorbers with high crystal quality on different substrates. ACS Appl. Mater. Interfaces 10, 26293–26302. https://doi.org/10.1021/acsami.8b07999. 

42. Roß, M., Gil-Escrig, L., Al-Ashouri, A., Tockhorn, P., Jo�st, M., Rech, B., and Albrecht, S. (2020). Co-evaporated p-i-n perovskite solar cells beyond 20% efficiency: impact of substrate temperature and hole-transport layer. ACS Appl. Mater. Interfaces 12, 39261– 39272. https://doi.org/10.1021/acsami. 0c10898. 

43. Roß, M., Severin, S., Stutz, M.B., Wagner, P., Ko¨ bler, H., Favin-Le´ veˆ que, M., Al-Ashouri, A., Korb, P., Tockhorn, P., Abate, A., et al. (2021). Co-evaporated formamidinium lead iodide based perovskites with 1000 h constant stability for fully textured monolithic perovskite/silicon tandem solar cells. Adv. 

Energy Mater 11, 2101460. https://doi.org/10. 1002/aenm.202101460. 

44. Erdenebileg, E., Wang, H., Li, J., Singh, N., Dewi, H.A., Tiwari, N., Mathews, N., Mhaisalkar, S., and Bruno, A. (2022). Low-temperature atomic layer deposited electron transport layers for co-evaporated perovskite solar cells. Sol. RRL 6, 2100842. https://doi.org/10.1002/solr.202100842. 

45. Dewi, H.A., Li, J., Erdenebileg, E., Wang, H., De Bastiani, M., De Wolf, S., Mathews, N., Mhaisalkar, S., and Bruno, A. (2022). Efficient bandgap widening in co-evaporated MAPbI3 perovskite. Sustainable Energy Fuels 6, 2428– 2438. https://doi.org/10.1039/D1SE01692J. 

46. Dewi, H.A., Li, J., Wang, H., Chaudhary, B., Mathews, N., Mhaisalkar, S., and Bruno, A. (2021). Excellent intrinsic long-term thermal stability of co-evaporated MAPbI3 solar cells at 85<sup>�</sup> C. Adv. Funct. Mater. 31, 2100557. https://doi.org/10.1002/adfm.202100557. 

47. Li, J., Dewi, H.A., Wang, H., Zhao, J., Tiwari, N., Yantara, N., Malinauskas, T., Getautis, V., Savenije, T.J., Mathews, N., et al. (2021). Co-evaporated MAPbI3 with graded fermi levels enables highly performing, scalable, and flexible p-i-n perovskite solar cells. Adv. Funct. Mater. 31, 2103252. https://doi.org/10. 1002/adfm.202103252. 

48. Patel, J.B., Wright, A.D., Lohmann, K.B., Peng, K., Xia, C.Q., Ball, J.M., Noel, N.K., Crothers, T.W., Wong-Leung, J., Snaith, H.J., et al. (2020). Light absorption and recycling in hybrid metal halide perovskite photovoltaic devices. Adv. Energy Mater. 10, 1903653. https://doi.org/10.1002/aenm.201903653. 

49. Abzieher, T., Feeney, T., Schackmar, F., Donie, Y.J., Hossain, I.M., Schwenzer, J.A., Hellmann, T., Mayer, T., Powalla, M., and Paetzold, U.W. (2021). From groundwork to efficient solar cells: on the importance of the substrate material in co-evaporated perovskite solar cells. Adv. Funct. Mater. 31, 2104482. https://doi.org/10.1002/adfm. 202104482. 

50. Lee, J., Lee, D., Jeong, D., and Park, N. (2019). Control of crystal growth toward scalable fabrication of perovskite solar cells. Adv. Funct. Mater. 29, 1807047. https://doi.org/10. 1002/adfm.201807047. 

51. Kottokkaran, R., Gaonkar, H.A., Abbas, H.A., Noack, M., and Dalal, V. (2019). Performance and stability of co-evaporated vapor deposited perovskite solar cells. J. Mater. Sci. Mater. Electron. 30, 5487–5494. https://doi. org/10.1007/s10854-019-00842-y. 

52. Wang, S., Ono, L.K., Leyden, M.R., Kato, Y., Raga, S.R., Lee, M.V., and Qi, Y. (2015). Smooth perovskite thin films and efficient perovskite solar cells prepared by the hybrid deposition method. J. Mater. Chem. A 3, 14631–14641. https://doi.org/10.1039/ C5TA03593G. 

53. Kim, B.S., Gil-Escrig, L., Sessolo, M., and Bolink, H.J. (2020). Deposition kinetics and compositional control of vacuum-processed CH3NH3PbI3 perovskite. J. Phys. Chem. Lett. 11, 6852–6859. https://doi.org/10.1021/acs. jpclett.0c01995. 

54. Kim, B.-S., Choi, M.-H., Choi, M.-S., and Kim, J.-J. (2016). Composition-controlled organometal halide perovskite via CH3NH3I pressure in a vacuum co-deposition process. J. Mater. Chem. A 4, 5663–5668. https://doi. org/10.1039/C6TA00168H. 

55. Teuscher, J., Ulianov, A., Mu¨ ntener, O., Gra¨tzel, M., and Te´ treault, N. (2015). Control and study of the stoichiometry in evaporated perovskite solar cells. ChemSusChem 8, 3847–3852. https://doi.org/10.1002/cssc. 201500972. 

56. Heinze, K.L., Dolynchuk, O., Burwig, T., Vaghani, J., Scheer, R., and Pistor, P. (2021). Importance of methylammonium iodide partial pressure and evaporation onset for the growth of co-evaporated methylammonium lead iodide absorbers. Sci. Rep. 11, 15299. https://doi.org/10.1038/s41598-021-94689-1. 

57. Gallet, T., Poeira, R.G., Lanzoni, E.M., Abzieher, T., Paetzold, U.W., and Redinger, A. (2021). Co-evaporation of CH3NH3PbI3: how growth conditions impact phase purity, photostriction, and intrinsic stability. ACS Appl. Mater. Interfaces 13, 2642–2653. https://doi.org/10.1021/acsami.0c19038. 

58. Kroll, M., O<sup>¨</sup> z, S.D., Zhang, Z., Ji, R., Schramm, T., Antrack, T., Vaynzof, Y., Olthof, S., and Leo, K. (2022). Insights into the evaporation behaviour of FAI: material degradation and consequences for perovskite solar cells. Sustainable Energy Fuels 6, 3230–3239. https://doi.org/10.1039/D2SE00373B. 

59. Roß, M., Stutz, M.B., and Albrecht, S. (2022). Revealing the role of methylammonium iodide purity on the vapor-phase deposition process of perovskites. Sol. RRL 6, 2200500. https://doi.org/10.1002/solr.202200500. 

60. Olthof, S., and Meerholz, K. (2017). Substratedependent electronic structure and film formation of MAPbI3 perovskites. Sci. Rep. 7, 40267. https://doi.org/10.1038/srep40267. 

61. LaMer, V.K., and Dinegar, R.H. (1950). Theory, production and mechanism of formation of monodispersed hydrosols. J. Am. Chem. Soc. 72, 4847–4854. https://doi.org/10.1021/ ja01167a001. 

62. Hu, H., Singh, M., Wan, X., Tang, J., Chu, C.-W., and Li, G. (2020). Nucleation and crystal growth control for scalable solutionprocessed organic–inorganic hybrid perovskite solar cells. J. Mater. Chem. A 8, 1578–1603. https://doi.org/10.1039/ C9TA11245F. 

63. Saliba, M., Matsui, T., Seo, J.-Y., Domanski, K., Correa-Baena, J.-P., Nazeeruddin, M.K., Zakeeruddin, S.M., Tress, W., Abate, A., Hagfeldt, A., and Gra¨tzel, M. (2016). Cesiumcontaining triple cation perovskite solar cells: improved stability, reproducibility and high efficiency. Energy Environ. Sci. 9, 1989–1997. https://doi.org/10.1039/C5EE03874J. 

64. Gil-Escrig, L., Momblona, C., La-Placa, M.-G., Boix, P.P., Sessolo, M., and Bolink, H.J. (2018). Vacuum deposited triple-cation mixed-halide perovskite solar cells. Adv. Energy Mater. 8, 1703506. https://doi.org/10.1002/aenm. 201703506. 

65. Igual-Mun˜ oz, A.M., A<sup>´</sup> vila, J., Boix, P.P., and Bolink, H.J. (2020). FAPb0.5Sn0.5I3: a narrow 

Joule 6, 2692–2734, December 21, 2022 2727 

## **ll** 

### Review 

   - bandgap perovskite synthesized through 76. Song, H.-J., Lee, H., Ahn, S., Song, H., and evaporation methods for solar cell Lee, C. (2018). Perovskite photovoltaic cells applications. Sol. RRL 4, 1–5. https://doi.org/ with ultra-thin buffer layers for tandem 10.1002/solr.201900283. applications. Jpn. J. Appl. Phys. 57, 102303. https://doi.org/10.7567/JJAP.57.102303. 

66. Ball, J.M., Buizza, L., Sansom, H.C., Farrar, M.D., Klug, M.T., Borchert, J., Patel, J., Herz, L.M., Johnston, M.B., and Snaith, H.J. (2019). Dual-source coevaporation of low-bandgap FA1– xCsxSn1– yPbyI3 perovskites for photovoltaics. ACS Energy Lett. 4, 2748–2756. https://doi.org/10.1021/acsenergylett. 9b01855. 

   77. A<sup>´</sup> vila, J., Momblona, C., Boix, P., Sessolo, M., Anaya, M., Lozano, G., Vandewal, K., Mı´guez, H., and Bolink, H.J. (2018). High voltage vacuum-deposited CH3NH3PbI3�CH3NH3PbI3 tandem solar cells. Energy Environ. Sci. 11, 3292–3297. https://doi.org/10.1039/ C8EE01936C. 

67. Igual-Mun˜ oz, A.M., Castillo, A., Dreessen, C., Boix, P.P., and Bolink, H.J. (2020). Vacuumdeposited multication tin–lead perovskite solar cells. ACS Appl. Energy Mater. 3, 2755– 2761. https://doi.org/10.1021/acsaem. 9b02413. 

   78. Ma, Q., Huang, S., Chen, S., Zhang, M., Lau, C.F.J., Lockrey, M.N., Mulmudi, H.K., Shan, Y., Yao, J., Zheng, J., et al. (2017). The effect of stoichiometry on the stability of inorganic cesium lead mixed-halide perovskites solar cells. J. Phys. Chem. C 121, 19642–19649. https://doi.org/10.1021/acs.jpcc.7b06268. 

68. Chiang, Y.H., Anaya, M., and Stranks, S.D. (2020). Multisource vacuum deposition of methylammonium-free perovskite solar cells. ACS Energy Lett. 5, 2498–2504. https://doi. org/10.1021/acsenergylett.0c00839. 

   79. Frolova, L.A., Anokhin, D.V., Piryazev, A.A., Luchkin, S.Y., Dremova, N.N., Stevenson, K.J., and Troshin, P.A. (2017). Highly efficient allinorganic planar heterojunction perovskite solar cells produced by thermal coevaporation of CsI and PbI2. J. Phys. Chem. Lett. 8, 67–72. https://doi.org/10.1021/acs. jpclett.6b02594. 

69. Ji, R., Zhang, Z., Cho, C., An, Q., Paulus, F., Kroll, M., Lo¨ ffler, M., Nehm, F., Rellinghaus, B., Leo, K., and Vaynzof, Y. (2020). Thermally evaporated methylammonium-free perovskite solar cells. J. Mater. Chem. C 8, 7725–7733. https://doi.org/10.1039/ D0TC01550D. 

   80. Luchkin, S.Y., Akbulatov, A.F., Frolova, L.A., Tsarev, S.A., Troshin, P.A., and Stevenson, K.J. (2017). Spatially-resolved nanoscale measurements of grain boundary enhanced photocurrent in inorganic CsPbBr3 perovskite films. Sol. Energy Mater. Sol. Cells 171, 205–212. https://doi.org/10.1016/j.solmat. 2017.06.059. 

70. Gil-Escrig, L., Dreessen, C., Palazon, F., Hawash, Z., Moons, E., Albrecht, S., Sessolo, M., and Bolink, H.J. (2021). Efficient widebandgap mixed-cation and mixed-halide perovskite solar cells by vacuum deposition. ACS Energy Lett. 6, 827–836. https://doi.org/ 10.1021/acsenergylett.0c02445. 

   81. Frolova, L.A., Chang, Q., Luchkin, S.Y., Zhao, D., Akbulatov, A.F., Dremova, N.N., Ivanov, A.V., Chia, E.E.M., Stevenson, K.J., and Troshin, P.A. (2019). Efficient and stable allinorganic perovskite solar cells based on nonstoichiometric CsxPbI2Brx(x)1. J. Mater. Chem. C 7, 5314–5323. https://doi.org/10. 1039/C8TC04488K. 

71. Susic, I., Gil-Escrig, L., Palazon, F., Sessolo, M., and Bolink, H.J. (2022). Quadruple-cation wide-bandgap perovskite solar cells with enhanced thermal stability enabled by vacuum deposition. ACS Energy Lett. 7, 1355– 1363. https://doi.org/10.1021/acsenergylett. 2c00304. 

   82. Chen, C.-Y., Lin, H.-Y., Chiang, K.-M., Tsai, W.-L., Huang, Y.-C., Tsao, C.-S., and Lin, H.-W. (2017). All-vacuum-deposited stoichiometrically balanced inorganic cesium lead halide perovskite solar cells with stabilized efficiency exceeding 11%. Adv. Mater. 29, 1605290. https://doi.org/10.1002/ adma.201605290. 

72. Wang, Q., Shao, Y., Xie, H., Lyu, L., Liu, X., Gao, Y., and Huang, J. (2014). Qualifying composition dependent p and n self-doping in CH3NH3PbI3. Appl. Phys. Lett. 105, 163508. https://doi.org/10.1063/1.4899051. 

73. Da¨nekamp, B., Mu¨ ller, C., Sendner, M., Boix, P.P., Sessolo, M., Lovrincic, R., and Bolink, H.J. (2018). Perovskite–perovskite homojunctions via compositional doping. J. Phys. Chem. Lett. 9, 2770–2775. https://doi.org/10.1021/ acs.jpclett.8b00964. 

   83. Lin, H., Chen, C., Hsu, B., Cheng, Y., Tsai, W., Huang, Y., Tsao, C., and Lin, H. (2019). Efficient cesium lead halide perovskite solar cells through alternative thousand-layer rapid deposition. Adv. Funct. Mater. 29, 1905163. https://doi.org/10.1002/adfm.201905163. 

74. Forga´cs, D., Gil-Escrig, L., Pe´ rez-Del-Rey, D., Momblona, C., Werner, J., Niesen, B., Ballif, C., Sessolo, M., and Bolink, H.J. (2017). Efficient monolithic perovskite/perovskite tandem solar cells. Adv. Energy Mater. 7, 1602121. https://doi.org/10.1002/aenm. 201602121. 

   84. Lei, J., Gao, F., Wang, H., Li, J., Jiang, J., Wu, X., Gao, R., Yang, Z., and Liu, S. (2018). Efficient planar CsPbBr3 perovskite solar cells by dual-source vacuum evaporation. Sol. Energy Mater. Sol. Cells 187, 1–8. https://doi. org/10.1016/j.solmat.2018.07.009. 

75. Chen, W., Zhang, J., Xu, G., Xue, R., Li, Y., Zhou, Y., Hou, J., and Li, Y. (2018). A semitransparent inorganic perovskite film for overcoming ultraviolet light instability of organic solar cells and achieving 14.03% efficiency. Adv. Mater. 30, 1800855. https:// doi.org/10.1002/adma.201800855. 

85. Duan, Y., Zhao, G., Liu, X., Ma, J., Chen, S., Song, Y., Pi, X., Yu, X., Yang, D., Zhang, Y., and Guo, F. (2021). Highly efficient and stable inorganic CsPbBr3 perovskite solar cells via vacuum co-evaporation. Appl. Surf. Sci. 562, 150153. https://doi.org/10.1016/j.apsusc. 2021.150153. 

86. Becker, P., Ma´rquez, J.A., Just, J., Al-Ashouri, A., Hages, C., Hempel, H., Jo�st, M., Albrecht, S., Frahm, R., and Unold, T. (2019). Low temperature synthesis of stable g-CsPbI3 perovskite layers for solar cells obtained by high throughput experimentation. Adv. Energy Mater. 9, 1900555. https://doi.org/10. 1002/aenm.201900555. 

87. Zhang, Z., Ji, R., Kroll, M., Hofstetter, Y.J., Jia, X., Becker-Koch, D., Paulus, F., Lo¨ ffler, M., Nehm, F., Leo, K., and Vaynzof, Y. (2021). Efficient thermally evaporated g-CsPbI3 perovskite solar cells. Adv. Energy Mater. 11, 2100299. https://doi.org/10.1002/aenm. 202100299. 

88. Igual-Mun˜ oz, A.M., Navarro-Alapont, J., Dreessen, C., Palazon, F., Sessolo, M., and Bolink, H.J. (2020). Room-temperature vacuum deposition of CsPbI 2 Br perovskite films from multiple sources and mixed halide precursors. Chem. Mater. 32, 8641–8652. https://doi.org/10.1021/acs.chemmater. 0c03038. 

89. Li, J., Gao, R., Gao, F., Lei, J., Wang, H., Wu, X., Li, J., Liu, H., Hua, X., and Liu, S. (2020). Fabrication of efficient CsPbBr3 perovskite solar cells by single-source thermal evaporation. J. Alloys Compd. 818, 152903. https://doi.org/10.1016/j.jallcom.2019. 152903. 

90. Chen, M., Ju, M.-G., Garces, H.F., Carl, A.D., Ono, L.K., Hawash, Z., Zhang, Y., Shen, T., Qi, Y., Grimm, R.L., et al. (2019). Highly stable and efficient all-inorganic lead-free perovskite solar cells with native-oxide passivation. Nat. Commun. 10, 16. https://doi.org/10.1038/ s41467-018-07951-y. 

91. Longo, G., Gil-Escrig, L., Degen, M.J., Sessolo, M., and Bolink, H.J. (2015). Perovskite solar cells prepared by flash evaporation. Chem. Commun. (Camb) 51, 7376–7378. https://doi.org/10.1039/C5CC01103E. 

92. Xu, F., Tian, Y., Wang, W., Zhu, Y., Zeng, L., Yao, B., Fang, Z., Xu, H., Xu, R., Xu, F., et al. (2019). In situ deposition of black a-FAPbI3 films by vacuum flash evaporation for solar cells. J. Mater. Sci. Mater. Electron. 30, 8381– 8389. https://doi.org/10.1007/s10854-01901155-w. 

93. Xu, H., Wu, Y., Xu, F., Zhu, J., Ni, C., Wang, W., Hong, F., Xu, R., Xu, F., Huang, J., and Wang, L. (2016). Grain growth study of perovskite thin films prepared by flash evaporation and its effect on solar cell performance. RSC Adv. 6, 48851–48857. https://doi.org/10.1039/ C6RA07549E. 

94. Mitzi, D.B., Prikas, M.T., and Chondroudis, K. (1999). Thin film deposition of organic�inorganic hybrid materials using a single source thermal ablation technique. Chem. Mater. 11, 542–544. https://doi.org/10. 1021/cm9811139. 

95. Fan, P., Gu, D., Liang, G.-X., Luo, J.-T., Chen, J.-L., Zheng, Z.-H., and Zhang, D.-P. (2016). High-performance perovskite CH3NH3PbI3 thin films for solar cells prepared by singlesource physical vapour deposition. Sci. Rep. 6, 29910. https://doi.org/10.1038/srep29910. 

96. Fan, P., Lan, H., Zheng, Z., Lan, C., Peng, H., Luo, J., Ma, X., and Liang, G. (2018). Hysteresis-free two-dimensional perovskite 

2728 Joule 6, 2692–2734, December 21, 2022 

**ll** 

### Review 

solar cells prepared by single-source physical vapour deposition. Sol. Energy 169, 179–186. https://doi.org/10.1016/j.solener.2018. 04.051. 

97. Liang, G., Lan, H., Fan, P., Lan, C., Zheng, Z., Peng, H., and Luo, J. (2018). Highly uniform large-area (100 cm<sup>2</sup> ) perovskite CH3NH3PbI3 thin-films prepared by single-source thermal evaporation. Coatings 8, 256. https://doi.org/ 10.3390/coatings8080256. 

98. Zheng, Z.-H., Lan, H.-B., Su, Z.-H., Peng, H.-X., Luo, J.-T., Liang, G.-X., and Fan, P. (2019). Single source thermal evaporation of twodimensional perovskite thin films for photovoltaic applications. Sci. Rep. 9, 17422. https://doi.org/10.1038/s41598-019-53609-0. 

99. Fan, P., Peng, H.-X., Zheng, Z.-H., Chen, Z.-H., Tan, S.-J., Chen, X.-Y., Luo, Y.-D., Su, Z.-H., Luo, J.T., and Liang, G.-X. (2019). Singlesource vapor-deposited Cs2AgBiBr6 thin films for lead-free perovskite solar cells. Nanomaterials (Basel) 9, 1760. https://doi. org/10.3390/nano9121760. 

100. Lan, H., Chen, X., Fan, P., and Liang, G. (2021). Inorganic and lead-free CsBi3I10 thin-film solar cell prepared by single-source thermal evaporation. J. Mater. Sci. Mater. Electron. 32, 11183–11192. https://doi.org/10.1007/ s10854-021-05783-z. 

101. Peng, H., Su, Z., Zheng, Z., Lan, H., Luo, J., Fan, P., and Liang, G. (2019). High-quality perovskite CH3NH3PbI3 thin films for solar cells prepared by single-source thermal evaporation combined with solvent treatment. Materials (Basel) 12, 1237. https:// doi.org/10.3390/ma12081237. 

102. Tavakoli, M.M., Yadav, P., Prochowicz, D., Tavakoli, R., and Saliba, M. (2019). Multilayer evaporation of MAFAPbI3�xClx for the fabrication of efficient and large-scale device perovskite solar cells. J. Phys. D: Appl. Phys. 52, 034005. https://doi.org/10.1088/13616463/aaebf1. 

103. La-Placa, M.-G.G., Gil-Escrig, L., Guo, D., Palazon, F., Savenije, T.J., Sessolo, M., and Bolink, H.J. (2019). Vacuum-deposited 2D/3D perovskite heterojunctions. ACS Energy Lett. 4, 2893–2901. https://doi.org/10.1021/ acsenergylett.9b02224. 

104. Hu, H., Wang, D., Zhou, Y., Zhang, J., Lv, S., Pang, S., Chen, X., Liu, Z., Padture, N.P., and Cui, G. (2014). Vapour-based processing of hole-conductor-free CH3NH3PbI3 perovskite/ C60 fullerene planar solar cells. RSC Adv. 4, 28964–28967. https://doi.org/10.1039/ C4RA03820G. 

105. Chen, C.-W., Kang, H.-W., Hsiao, S.-Y., Yang, P.-F., Chiang, K.-M., and Lin, H.-W. (2014). Efficient and uniform planar-type perovskite solar cells by simple sequential vacuum deposition. Adv. Mater. 26, 6647–6652. https://doi.org/10.1002/adma.201402461. 

106. Ng, A., Ren, Z., Shen, Q., Cheung, S.H., Gokkaya, H.C., Bai, G., Wang, J., Yang, L., So, S.K., Djuri�si�c, A.B., et al. (2015). Efficiency enhancement by defect engineering in perovskite photovoltaic cells prepared using evaporated PbI2/CH3NH3I multilayers. J. Mater. Chem. A 3, 9223–9231. https://doi. org/10.1039/C4TA05070C. 

107. Yang, D., Yang, Z., Qin, W., Zhang, Y., Liu, S., and Li, C. (2015). Alternating precursor layer deposition for highly stable perovskite films towards efficient solar cells using vacuum deposition. J. Mater. Chem. A 3, 9401–9405. https://doi.org/10.1039/C5TA01824B. 

108. Gil-Escrig, L., Miquel-Sempere, A., Sessolo, M., and Bolink, H.J. (2015). Mixed iodide– bromide methylammonium lead perovskitebased diodes for light emission and photovoltaics. J. Phys. Chem. Lett. 6, 3743– 3748. https://doi.org/10.1021/acs.jpclett. 5b01716. 

109. Kosasih, F.U., and Ducati, C. (2018). Attaining high photovoltaic efficiency and stability with multidimensional perovskites. ChemSusChem 11, 4193–4202. https://doi. org/10.1002/cssc.201801905. 

110. Tsai, H., Nie, W., Blancon, J.C., Stoumpos, C.C., Asadpour, R., Harutyunyan, B., Neukirch, A.J., Verduzco, R., Crochet, J.J., Tretiak, S., et al. (2016). High-efficiency twodimensional Ruddlesden-Popper perovskite solar cells. Nature 536, 312–316. https://doi. org/10.1038/nature18306. 

111. Zhang, Y.-N., Li, B., Fu, L., Zou, Y., Li, Q., and Yin, L.-W. (2019). Enhanced optical absorption and efficient cascade electron extraction based on energy band alignment double absorbers perovskite solar cells. Sol. Energy Mater. Sol. Cells 194, 168–176. https://doi. org/10.1016/j.solmat.2019.02.014. 

112. Tong, G., Chen, T., Li, H., Song, W., Chang, Y., Liu, J., Yu, L., Xu, J., Qi, Y., and Jiang, Y. (2019). High efficient hole extraction and stable all-bromide inorganic perovskite solar cells via derivative-phase gradient bandgap architecture. Sol. RRL 3, 1900030. https://doi. org/10.1002/solr.201900030. 

113. Tavakoli, M.M., Tsui, K.-H., Zhang, Q., He, J., Yao, Y., Li, D., and Fan, Z. (2015). Highly efficient flexible perovskite solar cells with antireflection and self-cleaning nanostructures. ACS Nano 9, 10287–10295. https://doi.org/10.1021/acsnano.5b04284. 

114. Tavakoli, M.M., Lin, Q., Leung, S.F., Lui, G.C., Lu, H., Li, L., Xiang, B., and Fan, Z. (2016). Efficient, flexible and mechanically robust perovskite solar cells on inverted nanocone plastic substrates. Nanoscale 8, 4276–4283. https://doi.org/10.1039/C5NR08836D. 

115. Lei, T., Li, F., Zhu, X., Dong, H., Niu, Z., Ye, S., Zhao, W., Xi, J., Jiao, B., Ding, L., and Wu, Z. (2020). Flexible perovskite solar modules with functional layers fully vacuum deposited. Sol. RRL 4, 2000292. https://doi.org/10.1002/solr. 202000292. 

116. Tavakoli, M.M., Yadav, P., Prochowicz, D., and Tavakoli, R. (2021). Efficient, hysteresis-free, and flexible inverted perovskite solar cells using all-vacuum processing. Sol. RRL 5, 2000552. https://doi.org/10.1002/solr. 202000552. 

117. Tavakoli, M.M., and Tavakoli, R. (2021). All-vacuum-processing for fabrication of efficient, large-scale, and flexible inverted perovskite solar cells. Phys. Status Solidi RRL 15, 2000449. https://doi.org/10.1002/pssr. 202000449. 

118. Tan, Y., Xiao, B., Xu, P., Luo, Y., Jiang, Q., and Yang, J. (2021). Improving the photovoltaic performance of flexible solar cells with semitransparent inorganic perovskite active layers by interface engineering. ACS Appl. Mater. Interfaces 13, 20034–20042. https:// doi.org/10.1021/acsami.1c01674. 

119. Yonezawa, K., Yamamoto, K., Shahiduzzaman, M., Furumoto, Y., Hamada, K., Ripolles, T.S., Karakawa, M., Kuwabara, T., Takahashi, K., Hayase, S., and Taima, T. (2017). Annealing effects on CsPbI 3 -based planar heterojunction perovskite solar cells formed by vacuum deposition method. Jpn. J. Appl. Phys. 56, 04CS11. https://doi.org/10.7567/ JJAP.56.04CS11. 

120. Shahiduzzaman, M., Yonezawa, K., Yamamoto, K., Ripolles, T.S., Karakawa, M., Kuwabara, T., Takahashi, K., Hayase, S., and Taima, T. (2017). Improved reproducibility and intercalation control of efficient planar inorganic perovskite solar cells by simple alternate vacuum deposition of PbI2 and CsI. ACS Omega 2, 4464–4469. https://doi.org/10. 1021/acsomega.7b00814. 

121. Hutter, E.M., Sutton, R.J., Chandrashekar, S., Abdi-Jalebi, M., Stranks, S.D., Snaith, H.J., and Savenije, T.J. (2017). Vapour-deposited cesium lead iodide perovskites: microsecond charge carrier lifetimes and enhanced photovoltaic performance. ACS Energy Lett. 2, 1901–1908. https://doi.org/10.1021/ acsenergylett.7b00591. 

122. Li, H., Tong, G., Chen, T., Zhu, H., Li, G., Chang, Y., Wang, L., and Jiang, Y. (2018). Interface engineering using a perovskite derivative phase for efficient and stable CsPbBr3 solar cells. J. Mater. Chem. A 6, 14255–14261. https://doi.org/10.1039/ C8TA03811B. 

123. Zhang, Y., Luo, L., Hua, J., Wang, C., Huang, F., Zhong, J., Peng, Y., Ku, Z., and Cheng, Y. (2019). Moisture assisted CsPbBr3 film growth for high-efficiency, all-inorganic solar cells prepared by a multiple sequential vacuum deposition method. Mater. Sci. Semicond. Process. 98, 39–43. https://doi.org/10.1016/j. mssp.2019.03.021. 

124. Tong, G., Chen, T., Li, H., Qiu, L., Liu, Z., Dang, Y., Song, W., Ono, L.K., Jiang, Y., and Qi, Y. (2019). Phase transition induced recrystallization and low surface potential barrier leading to 10.91%-efficient CsPbBr3 perovskite solar cells. Nano Energy 65, 104015. https://doi.org/10.1016/j.nanoen. 2019.104015. 

125. Liu, X., Tan, X., Liu, Z., Sun, B., Li, J., Xi, S., Shi, T., and Liao, G. (2019). Sequentially vacuum evaporated high-quality CsPbBr3 films for efficient carbon-based planar heterojunction perovskite solar cells. J. Power Sources 443, 227269. https://doi.org/10.1016/j.jpowsour. 2019.227269. 

126. Xiang, T., Zhang, Y., Wu, H., Li, J., Yang, L., Wang, K., Xia, J., Deng, Z., Xiao, J., Li, W., et al. (2020). Universal defects elimination for high performance thermally evaporated CsPbBr3 perovskite solar cells. Sol. Energy Mater. Sol. Cells 206, 110317. https://doi.org/ 10.1016/j.solmat.2019.110317. 

127. Hua, J., Deng, X., Niu, C., Huang, F., Peng, Y., Li, W., Ku, Z., and Cheng, Y.B. (2020). A 

Joule 6, 2692–2734, December 21, 2022 2729 

**ll** 

### Review 

pressure-assisted annealing method for high quality CsPbBr3 film deposited by sequential thermal evaporation. RSC Adv. 10, 8905–8909. https://doi.org/10.1039/D0RA00446D. 

128. Moghe, D., Wang, L., Traverse, C.J., Redoute, A., Sponseller, M., Brown, P.R., Bulovi�c, V., and Lunt, R.R. (2016). All vapor-deposited lead-free doped CsSnBr3 planar solar cells. Nano Energy 28, 469–474. https://doi.org/10. 1016/j.nanoen.2016.09.009. 

129. Qiu, X., Cao, B., Yuan, S., Chen, X., Qiu, Z., Jiang, Y., Ye, Q., Wang, H., Zeng, H., Liu, J., and Kanatzidis, M.G. (2017). From unstable CsSnI3 to air-stable Cs2SnI6: a lead-free perovskite solar cell light absorber with bandgap of 1.48 eV and high absorption coefficient. Sol. Energy Mater. Sol. Cells 159, 227–234. https://doi.org/10.1016/j.solmat. 2016.09.022. 

130. Ishibashi, H., Katayama, M., Tanaka, S., and Kaji, T. (2017). Hybrid perovskite solar cells fabricated from guanidine hydroiodide and tin iodide. Sci. Rep. 7, 4969. https://doi.org/ 10.1038/s41598-017-05317-w. 

131. Zhang, Z., Li, X., Xia, X., Wang, Z., Huang, Z., Lei, B., and Gao, Y. (2017). High-quality (CH3NH3)3Bi2I9 film-based solar cells: pushing efficiency up to 1.64%. J. Phys. Chem. Lett. 8, 4300–4307. https://doi.org/10.1021/acs. jpclett.7b01952. 

132. Igbari, F., Wang, R., Wang, Z.-K., Ma, X.J., Wang, Q., Wang, K.-L., Zhang, Y., Liao, L.-S., and Yang, Y. (2019). Composition stoichiometry of Cs2AgBiBr6 films for highly efficient lead-free perovskite solar cells. Nano Lett. 19, 2066–2073. https://doi.org/10.1021/ acs.nanolett.9b00238. 

133. Huang, J., Gu, Z., Zhang, X., Wu, G., and Chen, H. (2018). Lead-free (CH3NH3)3Bi2I9 perovskite solar cells with fluorinated PDI films as organic electron transport layer. J. Alloys Compd. 767, 870–876. https://doi.org/10. 1016/j.jallcom.2018.07.185. 

134. U<sup>¨</sup> nlu¨ , F., Deo, M., Mathur, S., Kirchartz, T., and Kulkarni, A. (2022). Bismuth-based halide perovskite and perovskite-inspired light absorbing materials for photovoltaics. J. Phys. D: Appl. Phys. 55, 113002. https://doi.org/10. 1088/1361-6463/ac3033. 

135. Du, Y., Cai, H., Wen, H., Wu, Y., Li, Z., Xu, J., Huang, L., Ni, J., Li, J., and Zhang, J. (2016). Undesirable role of remnant PbI2 layer on low temperature processed planar perovskite solar cells. RSC Adv. 6, 101250–101258. https://doi.org/10.1039/C6RA19265C. 

136. Du, Y., Cai, H., Wen, H., Wu, Y., Li, Z., Xu, J., Huang, L., Ni, J., Li, J., and Zhang, J. (2016). Revealing the unfavorable role of superfluous CH3NH3PbI3 grain boundary traps in perovskite solar cells on carrier collection. RSC Adv. 6, 83264–83272. https://doi.org/10. 1039/C6RA15512J. 

137. Dachauer, R., Clemens, O., Lakus-Wollny, K., Mayer, T., and Jaegermann, W. (2019). Characterization of methylammonium lead iodide thin films fabricated by exposure of lead iodide layers to methylammonium iodide vapor in a closed crucible transformation process. Phys. Status Solidi A. 216, 1800894. https://doi.org/10.1002/pssa. 201800894. 

138. Patel, J.B., Milot, R.L., Wright, A.D., Herz, L.M., deposition. Nano Energy 59, 619–625. https:// 59, 619–625. https://, 619–625. https:// https:// and Johnston, M.B. (2016). Formation doi.org/10.1016/j.nanoen.2019.03.014.. dynamics of CH3NH3PbI3 perovskite following two-step layer deposition. J. Phys. Chem. 149. Ono, L.K., Wang, S., Kato, Y., Raga, S.R., and Lett. 7, 96–102. https://doi.org/10.1021/acs. Qi, Y. (2014). Fabrication of semi-transparent jpclett.5b02495. perovskite films with centimeter-scale superior uniformity by the hybrid deposition 

139. Yamamoto, K., Kuwabara, T., Takahashi, K., method. Energy Environ. Sci. 7, 3989–3993. and Taima, T. (2015). Study of planar https://doi.org/10.1039/C4EE02539C. 

deposition. Nano Energy 59, 619–625. https:// 59, 619–625. https://, 619–625. https:// https:// doi.org/10.1016/j.nanoen.2019.03.014.. 

139. Yamamoto, K., Kuwabara, T., Takahashi, K., and Taima, T. (2015). Study of planar heterojunction perovskite photovoltaic cells using compact titanium oxide by chemical bath deposition. Jpn. J. Appl. Phys. 54, 08KF02. https://doi.org/10.7567/JJAP.54. 08KF02. 

   150. Leyden, M.R., Ono, L.K., Raga, S.R., Kato, Y., Wang, S., and Qi, Y. (2014). High performance perovskite solar cells by hybrid chemical vapor deposition. J. Mater. Chem. A 2, 18742– 18745. https://doi.org/10.1039/C4TA04385E. 

140. Huang, J., Gu, Z., Zuo, L., Ye, T., and Chen, H. (2016). Morphology control of planar heterojunction perovskite solar cells with fluorinated PDI films as organic electron transport layer. Sol. Energy 133, 331–338. https://doi.org/10.1016/j.solener.2016. 04.017. 

   151. Balaji, G., Joshi, P.H., Abbas, H.A., Zhang, L., Kottokkaran, R., Samiee, M., Noack, M., and Dalal, V.L. (2015). CH3NH3PbI3 from noniodide lead salts for perovskite solar cells via the formation of PbI2. Phys. Chem. Chem. Phys. 17, 10369–10372. https://doi.org/10. 1039/C5CP00073D. 

141. Kam, M., Zhang, Q., Zhang, D., and Fan, Z. (2019). Room-temperature sputtered SnO2 as robust electron transport layer for air-stable and efficient perovskite solar cells on rigid and flexible substrates. Sci. Rep. 9, 6963. https:// doi.org/10.1038/s41598-019-42962-9. 

   152. Yuan, S., Qiu, Z., Zhang, H., Qiu, X., Gao, C., Gong, H., Yang, S., Yu, J., and Cao, B. (2016). Growth temperature-dependent performance of planar CH3NH3PbI3 solar cells fabricated by a two-step subliming vapor method below 120<sup>�</sup> C. RSC Adv. 6, 47459– 47467. https://doi.org/10.1039/C6RA07686F. 

142. Subbiah, A.S., Dhara, A.K., Mahuli, N., Banerjee, S., and Sarkar, S.K. (2020). Ultra-thin atomic layer deposited–Nb2O5 as electron transport layer for co-evaporated MAPbI 3 planar perovskite solar cells. Energy Technol. 8, 1900878. https://doi.org/10.1002/ente. 201900878. 

   153. Hsiao, S.-Y., Lin, H.-L., Lee, W.-H., Tsai, W.-L., Chiang, K.-M., Liao, W.-Y., Ren-Wu, C.-Z., Chen, C.-Y., and Lin, H.-W. (2016). Efficient allvacuum deposited perovskite solar cells by controlling reagent partial pressure in high vacuum. Adv. Mater. 28, 7013–7019. https:// doi.org/10.1002/adma.201601505. 

143. Tsai, W.-L., Lee, W.-H., Chen, C.-Y., Hsiao, S.-Y., Shiau, Y.-J., Hsu, B.-W., Lee, Y.-C., and Lin, H.-W. (2017). Very high hole drift mobility in neat and doped molecular thin films for normal and inverted perovskite solar cells. Nano Energy 41, 681–686. https://doi.org/10. 1016/j.nanoen.2017.10.026. 

   154. Ioakeimidis, A., Christodoulou, C., LuxSteiner, M., and Fostiropoulos, K. (2016). Effect of PbI2 deposition rate on two-step PVD/CVD all-vacuum prepared perovskite. J. Solid State Chem. 244, 20–24. https://doi. org/10.1016/j.jssc.2016.08.034. 

144. Hoerantner, M.T., Wassweiler, E.L., Zhang, H., Panda, A., Nasilowski, M., Osherov, A., Swartwout, R., Driscoll, A.E., Moody, N.S., Bawendi, M.G., et al. (2019). High-speed vapor transport deposition of perovskite thin films. ACS Appl. Mater. Interfaces 11, 32928– 32936. https://doi.org/10.1021/acsami. 9b07651. 

   155. Yang, D., Zhou, X., Yang, R., Yang, Z., Yu, W., Wang, X., Li, C., Liu, S., and Chang, R.P.H. (2016). Surface optimization to eliminate hysteresis for record efficiency planar perovskite solar cells. Energy Environ. Sci. 9, 3071–3078. https://doi.org/10.1039/ C6EE02139E. 

   156. Choi, W.-G., Na, S., Park, C.-G., and Moon, T. (2019). Organic-cation-mixed (FA,MA)PbI3 through sequential vapor growth for planar perovskite solar cells. Sol. Energy 178, 56–60. https://doi.org/10.1016/j.solener.2018. 11.061. 

145. Zhu, X., Yang, D., Yang, R., Yang, B., Yang, Z., Ren, X., Zhang, J., Niu, J., Feng, J., and Liu, S.F. (2017). Superior stability for perovskite solar cells with 20% efficiency using vacuum co-evaporation. Nanoscale 9, 12316–12323. https://doi.org/10.1039/C7NR04501H. 

   157. Chen, M., Ju, M.-G., Carl, A.D., Zong, Y., Grimm, R.L., Gu, J., Zeng, X.C., Zhou, Y., and Padture, N.P. (2018). Cesium titanium(IV) bromide thin films based stable lead-free perovskite solar cells. Joule 2, 558–570. https://doi.org/10.1016/j.joule.2018.01.009. 

146. Deng, X., Hua, J., Huang, F., Peng, Y., Li, W., Ku, Z., and Cheng, Y. (2020). Improving the crystal growth of a Cs0.24FA0.76PbI3�xBrx perovskite in a vapor–solid reaction process using strontium iodide. Sustainable Energy Fuels 4, 2491–2496. https://doi.org/10.1039/ D0SE00088D. 

   158. Choi, W.-G., Park, C.-G., Kim, Y., and Moon, T. (2020). Sn perovskite solar cells via 2D/3D bilayer formation through a sequential vapor process. ACS Energy Lett. 5, 3461–3467. https://doi.org/10.1021/acsenergylett. 0c01887. 

147. Tavakoli, M.M., Fazel, Z., Tavakoli, R., Akin, S., Satapathi, S., Prochowicz, D., and Yadav, P. (2022). Efficient and less-toxic indium-doped MAPbI 3 perovskite solar cells prepared by metal alloying technique. Sol. RRL 6, 2200106. https://doi.org/10.1002/solr.202200106. 

   159. Liu, J., Shi, B., Xu, Q., Li, Y., Chen, B., Wang, Q., Wang, P., Zhao, Y., and Zhang, X. (2021). Crystalline quality control in sequential vapor deposited perovskite film toward high efficiency and large scale solar cells. Sol. 

148. Lin, D., Zhang, T., Wang, J., Long, M., Xie, F., Chen, J., Wu, B., Shi, T., Yan, K., Xie, W., et al. (2019). Stable and scalable 3D-2D planar heterojunction perovskite solar cells via vapor 

2730 Joule 6, 2692–2734, December 21, 2022 

**ll** 

### Review 

Energy Mater. Sol. Cells 233, 111382. https:// doi.org/10.1016/j.solmat.2021.111382. 

160. Ma, W., Han, J., Yu, W., Yang, D., Wang, H., Zong, X., and Li, C. (2016). Integrating perovskite photovoltaics and noble-metalfree catalysts toward efficient solar energy conversion and H 2 S splitting. ACS Catal. 6, 6198–6206. https://doi.org/10.1021/acscatal. 6b01772. 

161. Fang, C., Zhao, Q., Zhao, F., Huang, F., Peng, Y., Ku, Z., Cheng, Y.-B., and Fu, Z. (2022). Allvacuum deposited perovskite solar cells with glycine modified NiOx hole-transport layers. RSC Adv. 12, 10863–10869. https://doi.org/ 10.1039/D2RA01360F. 

162. Jang, J., Choe, G., and Yim, S. (2019). Effective control of chlorine contents in MAPbI3–xClx perovskite solar cells using a single-source vapor deposition and anion-exchange technique. ACS Appl. Mater. Interfaces 11, 20073–20081. https://doi.org/10.1021/ acsami.9b05101. 

163. Siegrist, S., Yang, S.-C., Gilshtein, E., Sun, X., Tiwari, A.N., and Fu, F. (2021). Triple-cation perovskite solar cells fabricated by a hybrid PVD/blade coating process using green solvents. J. Mater. Chem. A Mater. 9, 26680– 26687. https://doi.org/10.1039/D1TA07579A. 

164. Soltanpoor, W., Dreessen, C., Sahiner, M.C., Susic, I., Afshord, A.Z., Chirvony, V.S., Boix, P.P., Gunbas, G., Yerci, S., and Bolink, H.J. (2020). Hybrid vapor-solution sequentially deposited mixed-halide perovskite solar cells. ACS Appl. Energy Mater. 3, 8257–8265. https://doi.org/10.1021/acsaem.0c00686. 

165. Pisoni, S., Carron, R., Moser, T., Feurer, T., Fu, F., Nishiwaki, S., Tiwari, A.N., and Buecheler, S. (2018). Tailored lead iodide growth for efficient flexible perovskite solar cells and thin-film tandem devices. NPG Asia Mater. 10, 1076–1085. https://doi.org/10.1038/s41427018-0099-1. 

166. Werner, J., Sahli, F., Fu, F., Diaz Leon, J.J., Walter, A., Kamino, B.A., Niesen, B., Nicolay, S., Jeangros, Q., and Ballif, C. (2018). Perovskite/perovskite/silicon monolithic triple-junction solar cells with a fully textured design. ACS Energy Lett. 3, 2052–2058. https://doi.org/10.1021/acsenergylett. 8b01165. 

167. Xia, Z., Chai, G., Wang, Y., and Zhou, H. (2015). Uniform perovskite photovoltaic thin films via ultrasonic spray assisted deposition method. In 2015 IEEE 42nd Photovoltaic Specialist Conference (PVSC), pp. 1–4. IEEE. https://doi. org/10.1109/PVSC.2015.7355719. 

168. Cojocaru, L., Wienands, K., Erdil, U., Schulze, P.S.C., Mundt, L.E., Bett, A.J., Breitwieser, M., Lombeck, F., Prescher, M., Kirste, L., et al. (2020). Hybrid evaporation/spray-coating process for a simplified and controllable production of perovskite solar cells. IEEE J. Photovolt. 10, 276–286. https://doi.org/10. 1109/JPHOTOV.2019.2949763. 

169. Rakita, Y., Gupta, S., Cahen, D., and Hodes, G. (2017). Metal to halide perovskite (HaP): an alternative route to HaP coating, directly from Pb(0) or Sn(0) films. Chem. Mater. 29, 8620– 8629. https://doi.org/10.1021/acs. chemmater.7b02314. 

efficiency in perovskite solar cells. Nanoscale Res. Lett. 15, 127. https://doi.org/10.1186/ s11671-020-03359-0. 

170. Abzieher, T., Mathies, F., Hetterich, M., Welle, 

   - A., Gerthsen, D., Lemmer, U., Paetzold, U.W., and Powalla, M. (2017). Additive-assisted crystallization dynamics in two-step fabrication of perovskite solar cells. Phys. Status Solidi A. 214, 1700509. https://doi.org/ 10.1002/pssa.201700509. 

   181. Tao, C., Neutzner, S., Colella, L., Marras, S., Srimath Kandada, A.R., Gandini, M., De Bastiani, M., Pace, G., Manna, L., Caironi, M., et al. (2015). 17.6% stabilized efficiency in lowtemperature processed planar perovskite solar cells. Energy Environ. Sci. 8, 2365–2370. https://doi.org/10.1039/C5EE01720C. 

171. Liu, A., Liu, K., Zhou, H., Li, H., Qiu, X., Yang, Y., and Liu, M. (2018). Solution evaporation processed high quality perovskite films. Sci. Bull. 63, 1591–1596. https://doi.org/10.1016/j. scib.2018.11.004.. 

- scib.2018.11.004.. 182. Kundu, S., and Kelly, T.L. (2018). Improving the moisture stability of perovskite solar cells by 

- 172. Liu, D., Gangishetty, M.K., and Kelly, T.L. using PMMA/P3HT based hole-transport (2014). Effect of CH3NH3PbI3 thickness on layers. Mater. Chem. Front. 2, 81–89. https:// device efficiency in planar heterojunction doi.org/10.1039/C7QM00396J. perovskite solar cells. J. Mater. Chem. A 2, 19873–19881. https://doi.org/10.1039/ https://doi.org/10.1039/ 183. Lei, T., Dong, H., Xi, J., Niu, Y., Xu, J., Yuan, F., C4TA02637C.. Jiao, B., Zhang, W., Hou, X., and Wu, Z. (2018). 

- 19873–19881. https://doi.org/10.1039/ https://doi.org/10.1039/ 183. Lei, T., Dong, H., Xi, J., Niu, Y., Xu, J., Yuan, F., C4TA02637C.. Jiao, B., Zhang, W., Hou, X., and Wu, Z. (2018). Highly-efficient and low-temperature 

- 173. Chen, Y., Chen, T., and Dai, L. (2015). Layerperovskite solar cells by employing a bi-hole by-layer growth of CH3NH3PbI3-xClx for highly transport layer consisting of vanadium oxide efficient planar heterojunction perovskite and copper phthalocyanine. Chem. Commun. solar cells. Adv. Mater. 27, 1053–1059. https:// (Camb) 54, 6177–6180. https://doi.org/10. doi.org/10.1002/adma.201404147. 1039/C8CC03672A. 

174. Xi, J., Wu, Z., Dong, H., Xia, B., Yuan, F., Jiao, 184. Hou, Y., Aydin, E., De Bastiani, M., Xiao, C., B., Xiao, L., Gong, Q., and Hou, X. (2015). Isikgor, F.H., Xue, D.J., Chen, B., Chen, H., Controlled thickness and morphology for Bahrami, B., Chowdhury, A.H., et al. (2020). highly efficient inverted planar heterojunction Efficient tandem solar cells with solutionperovskite solar cells. Nanoscale 7, 10699– processed perovskite on textured crystalline 10707. https://doi.org/10.1039/C5NR01988E. silicon. Science 367, 1135–1140. https://doi. org/10.1126/science.aaz3691. 

175. Lee, S.H., Hong, S., An, S., Jeon, T.-Y., and Kim, H.J. (2020). Strategy for the complete conversion of thermally grown PbI2 layers in inverted perovskite solar cells. Electron. Mater. Lett. 16, 588–594. https://doi.org/10. 1007/s13391-020-00250-z. 

   185. Zheng, J., Lau, C.F.J., Mehrvarz, H., Ma, F.-J., Jiang, Y., Deng, X., Soeriyadi, A., Kim, J., Zhang, M., Hu, L., et al. (2018). Large area efficient interface layer free monolithic perovskite/homo-junction-silicon tandem solar cell with over 20% efficiency. Energy Environ. Sci. 11, 2432–2443. https://doi.org/ 10.1039/C8EE00689J. 

176. Fu, F., Kranz, L., Yoon, S., Lo¨ ckinger, J., Ja¨ger, T., Perrenoud, J., Feurer, T., Gretener, C., Buecheler, S., and Tiwari, A.N. (2015). Controlled growth of PbI2 nanoplates for rapid preparation of CH3NH3PbI3 in planar perovskite solar cells. Phys. Status Solidi A. 212, 2708–2717. https://doi.org/10.1002/ pssa.201532442. 

   186. Shen, H., Omelchenko, S.T., Jacobs, D.A., Yalamanchili, S., Wan, Y., Yan, D., Phang, P., Duong, T., Wu, Y., Yin, Y., et al. (2018). In situ recombination junction between p-Si and TiO2 enables high-efficiency monolithic perovskite/Si tandem cells. Sci. Adv. 4, eaau9711. https://doi.org/10.1126/sciadv. aau9711. 

177. Shi, B., Yao, X., Hou, F., Guo, S., Li, Y., Wei, C., Ding, Y., Li, Y., Zhao, Y., and Zhang, X. (2018). Unraveling the passivation process of PbI2 to enhance the efficiency of planar perovskite solar cells. J. Phys. Chem. C 122, 21269– 21276. https://doi.org/10.1021/acs.jpcc. 8b08075. 

   187. Bush, K.A., Palmstrom, A.F., Yu, Z.J., Boccard, M., Cheacharoen, R., Mailoa, J.P., McMeekin, D.P., Hoye, R.L.Z., Bailie, C.D., Leijtens, T., et al. (2017). 23.6%-efficient monolithic perovskite/silicon tandem solar cells with improved stability. Nat. Energy 2, 17009. https://doi.org/10.1038/nenergy.2017.9. 

178. Rafizadeh, S., Wienands, K., Schulze, P.S.C., Bett, A.J., Andreani, L.C., Hermle, M., Glunz, S., and Goldschmidt, J.C. (2019). Efficiency enhancement and hysteresis mitigation by manipulation of grain growth conditions in hybrid evaporated–spin-coated perovskite solar cells. ACS Appl. Mater. Interfaces 11, 722–729. https://doi.org/10.1021/acsami. 8b16963. 

   188. Chen, B., Yu, Z., Liu, K., Zheng, X., Liu, Y., Shi, J., Spronk, D., Rudd, P.N., Holman, Z., and Huang, J. (2019). Grain engineering for perovskite/silicon monolithic tandem solar cells with efficiency of 25.4%. Joule 3, 177–190. https://doi.org/10.1016/j.joule. 2018.10.003. 

179. Fu, F., Pisoni, S., Weiss, T.P., Feurer, T., Wa¨ckerlin, A., Fuchs, P., Nishiwaki, S., Zortea, L., Tiwari, A.N., and Buecheler, S. (2018). Compositionally graded absorber for efficient and stable near-infrared-transparent perovskite solar cells. Adv. Sci. (Weinh) 5, 1700675. https://doi.org/10.1002/advs. 201700675. 

   189. Jo�st, M., Ko¨ hnen, E., Morales-Vilches, A.B., Lipov�sek, B., Ja¨ger, K., Macco, B., Al-Ashouri, A., Kr�c, J., Korte, L., Rech, B., et al. (2018). Textured interfaces in monolithic perovskite/ silicon tandem solar cells: advanced light management for improved efficiency and energy yield. Energy Environ. Sci. 11, 3511– 3523. https://doi.org/10.1039/C8EE02469C. 

180. Wu, G., Zhu, Q., Zhang, T., Zou, Z., Wang, W., Cao, Y., Kong, L., Zheng, X., Wu, Y., Li, X., et al. (2020). Gradient engineered light absorption layer for enhanced carrier separation 

190. Sahli, F., Werner, J., Kamino, B.A., Bra¨uninger, M., Monnard, R., Paviet-Salomon, B., Barraud, L., Ding, L., Diaz Leon, J.J., Sacchetto, D., 

Joule 6, 2692–2734, December 21, 2022 2731 

