# High-performance quasi-2D perovskite light-emitting diodes: from materials to devices

| 字段 | 内容 |
|---|---|
| 期刊 | Light: Science & Applications |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 449 |
| 作者 | Li Zhang, Chang-Jiu Sun, Tingwei He, Yuan-Zhi Jiang, Jun-Li Wei, Yan-Min Huang, M. Yuan |
| DOI | 10.1038/s41377-021-00501-0 |
| 源文件 | 021_Zhang_2021_High-performance-quasi-2D-perovskite-light-emitt.pdf |

---
Official journal of the CIOMP 2047-7538 www.nature.com/lsa 

Zhang et al. Light: Science & Applications (2021) 10:61 https://doi.org/10.1038/s41377-021-00501-0 

O <u>p e n</u> A c c e s s 

R E V I E W A R T I C L E 

# High-performance quasi-2D perovskite light-emitting diodes: from materials to devices 

Li Zhang<sup>1</sup> , Changjiu Sun 1, Tingwei He 1, Yuanzhi Jiang 1, Junli Wei1, Yanmin Huang1 and Mingjian Yuan 1 

## Abstract 

Quasi-two-dimensional (quasi-2D) perovskites have attracted extraordinary attention due to their superior semiconducting properties and have emerged as one of the most promising materials for next-generation lightemitting diodes (LEDs). The outstanding optical properties originate from their structural characteristics. In particular, the inherent quantum-well structure endows them with a large exciton binding energy due to the strong dielectricand quantum-confinement effects; the corresponding energy transfer among different n-value species thus results in high photoluminescence quantum yields (PLQYs), particularly at low excitation intensities. The review herein presents an overview of the inherent properties of quasi-2D perovskite materials, the corresponding energy transfer and spectral tunability methodologies for thin films, as well as their application in high-performance LEDs. We then summarize the challenges and potential research directions towards developing high-performance and stable quasi2D PeLEDs. The review thus provides a systematic and timely summary for the community to deepen the understanding of quasi-2D perovskite materials and resulting LED devices. 

## Introduction 

Light-emitting diodes (LEDs) are changing the lighting and display industry and have obtained significant advances compared to traditional lighting sources. Traditional material LEDs, e.g., III–V semiconductor LEDs<sup>1,2</sup> , organic LEDs (OLEDs)<sup>3,4</sup> , and quantum-dot LEDs (QLEDs)<sup>5</sup> , have achieved great success and gradually realized commercialization but still face some challenges. OLEDs have low carrier transport capability and exciton recombination, which hinders the improvement of the brightness. In addition, QLEDs show challenges in terms of the tedious manufacturing process, and the reliance on hydrophobic insulating long ligands also hinders their stability and electrical conductivity. Compared with these traditional materials, metal halide perovskites (MHPs) 

> Correspondence: Mingjian Yuan (yuanmj@nankai.edu.cn) 

> 1Key Laboratory of Advanced Energy Materials Chemistry (Ministry of Education), Renewable Energy Conversion and Storage Center (RECAST), College of Chemistry, Nankai University, 300071 Tianjin, People’s Republic of China 

exhibit superior optoelectronic features that are beneficial for LED applications, such as high photoluminescence quantum yields (PLQYs), narrow full width at half maximum (FWHM), and feasible spectral tunability<sup>6–10</sup> . Perovskite LEDs (PeLEDs) have achieved impressive progress in the past few years since the first room-temperature PeLED was reported in 2014<sup>11</sup> . Three types of perovskite materials with different dimensions (i.e., 3D perovskites, quasi-2D perovskites, and perovskite nanocrystals) are commonly included in the emitter layer of PeLEDs<sup>12–16</sup> . 3D PeLEDs have achieved EQEs of more than 20% in both the near-infrared and green regimes<sup>17,18</sup> . Simultaneously, PeLEDs based on perovskite nanocrystals have also shown prosperous development since they were first reported by Song et al. in 2015<sup>19–21</sup> , achieving a record EQE of 23.4%<sup>22</sup> . Accordingly, the rapid progress achieved in highperformance PeLEDs indicates their promising applications, particularly in ultrahigh-definition displays, solidstate lighting, and photo-communication areas<sup>23,24</sup> . 

Quasi-2D perovskites represent an important category of perovskites that possess self-assembled multi-quantum-well 

> These author contributed equally: Li Zhang, Changjiu Sun 

> © The Author(s) 2021 

> OpenAccess ThisarticleislicensedunderaCreativeCommonsAttribution4.0InternationalLicense,whichpermitsuse,sharing,adaptation,distributionandreproduction 

> in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/licenses/by/4.0/. 

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 2 of 26 

structures and have gained great success in light emission applications owing to their outstanding optoelectrical properties<sup>25,26</sup> . Calabrese et al.<sup>27</sup> demonstrated that MAPbI3 (n = ∞) perovskite and (RNH3)2PbI4 (n = 1) perovskite represent two typical materials in the series of (RNH3)2MAn−1 PbnI3n+1 (n = 1 to ∞). Thereafter, they reported the first quasi-2D perovskite, PEA2MAPb2I7, and the obtained crystallography data unambiguously confirmed the “bilayer” structure. Another pioneering work carried out by Mitzi et al.<sup>28</sup> highlighted the structural “layered” characteristic of Sn-based perovskites (C4H9NH3)2(CH3NH3)n−1SnnI3n+1 (n = 1–5) through crystallographic characterization. Recently, substantial efforts have been made to obtain high-performance quasi-2D PeLEDs, which have facilitated unprecedented rapid development. In the past five years, we have witnessed the rapid development of quasi-2D perovskite optoelectronics, especially their tremendous success in LED applications. The recorded EQE of LEDs has soared to 21% and approached the efficiency limit<sup>22,29</sup> since the first example was reported in 2016<sup>30</sup> . 

In particular, quasi-2D perovskites exhibit unique optical properties arising from their structural characteristics, which are different from those of conventional 3D<sup>11,31–33</sup> and two-dimensional (2D) perovskites<sup>34,35</sup> . First, quasi-2D perovskites possess natural quantum-well structures, which can induce both dielectric- and quantum-confinement effects<sup>36–40</sup> . Such strong confinements thus afford a large exciton binding energy (Eb). In addition, quasi-2D films feature a mixed-phase rather than a single phase because the formation energies for different quasi-2D phases are quite similar<sup>41</sup> . During photoexcitation, the photocarriers transfer from higher bandgap species to lower bandgap species rapidly and efficiently, leading to accumulated carriers in the recombination centers. The increased carrier density then effectively passivates the defect states, thereby significantly improving the radiative recombination efficiency and the resulting PLQYs<sup>30,42</sup> . In addition, quasi-2D perovskites exhibit tunability of their spectra, which can be modulated through composition and dimensionality engineering respectively. These characteristics enable continuous photoluminescence (PL) wavelength tuning from violet to near-infrared (NIR) spectral regions<sup>29,43–45</sup> . 

However, the performance and stability of quasi-2D PeLEDs still cannot meet the requirements for commercialization at the moment. More efforts need to be devoted to exploring the optical and electrical properties of these materials. In addition, investigation of the correlation between the device performance and the underlying photophysics of the materials appears to be particularly important. Following this trend, we discuss the inherent optical properties and corresponding photophysics of quasi-2D perovskites at the beginning of the review. We then summarize the progress in spectral tunability of quasi-2D perovskites, mainly to realize high-performance 

pure-red and pure-blue emission. Next, we discuss the newly emerged device engineering approaches to produce high-performance quasi-2D PeLEDs. Finally, we summarize the key challenges in the field and propose several promising research opportunities to facilitate the development of highly stable and high-performance quasi-2D materials and devices. The review article thus paves the way for future quasi-2D PeLED manufacture. 

## Characteristics of quasi-2D perovskites 

### Structural characteristics 

Employing bulky organic cations to substantially replace the traditional small cations breaks the original continuous 3D structure and generates a stable quasi-2D geometry. The geometry can be understood as slicing the 3D structure in planes along the <100> crystallographic directions<sup>46–48</sup> . As shown in Fig. 1a, large organic amines are introduced during crystal growth, which cannot enter the gap between [BX6]<sup>4−</sup> octahedrons, thus inhibiting the growth of [BX6]<sup>4−</sup> along out-of-plane directions<sup>49,50</sup> . The sheets of quasi-2D perovskite unit cells are periodic along the basal plane and are constrained in the perpendicular direction. Generally, quasi-2D perovskites possess the chemical formula A′2An−1BnX3n+1 (1 ≤ n ≤∞), where A′ refers to a large organic cation, including monoammonium cations (R-NH3+) and diammonium cations (+H3N-RNH3+) (R represents an alkyl chain or aromatic ligand); A stands for a small monovalent cation, e.g., methylammonium (MA<sup>+</sup> = CH3NH3+), formamidine (FA<sup>+</sup> = CH (NH2)2+), or cesium (Cs+); B is a divalent metal cation such as lead (Pb<sup>2+</sup> ) or tin (Sn<sup>2+</sup> ); X represents a halide, e.g., chloride (Cl<sup>−</sup> ), bromide (Br<sup>−</sup> ) or iodide (I<sup>−</sup> ); and n refers to the number of [BX6]<sup>4−</sup> octahedral units. In brief, A′ acts as an insulating layer to isolate the inorganic layers (the metal halide [BX6]<sup>4−</sup> octahedral units) linked together by cornersharing halide anions, and A cations occupy voids within the framework<sup>30,42</sup> . 

Quasi-2D perovskites consist of a series of alternately aligned inorganic and organic layers. Inorganic [BX6]<sup>4−</sup> octahedral sheets are sandwiched by two layers of large organic spacers with relatively low dielectric constants. Specifically, the inorganic [BX6]<sup>4−</sup> slabs act as quantum “wells”, while the organic capping layers function as “barriers”. Thus, the “quantum-well” (QW) structures of a quasi2D perovskite are formed naturally with an atomically sharp interface between “barriers” and “wells” (Fig. 1a). Due to the quantum- and dielectric-confinement effects arising from the QW structure, the Eb of a quasi-2D perovskite becomes larger than that of its 3D analog<sup>25,42</sup> . The carrier wave function is compressed in one direction due to the QW width limitation. Accordingly, the carrier movement is limited, which increases the resulting Eb and effective bandgap of quasi-2D perovskites. In particular, both electrons and holes are confined within the inorganic well; 

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 3 of 26 



<!-- Start of picture text -->
a<br>(i) (ii) n  = 1 n  = 2 n  = 3<br>Large cation<br>Pb 2+ , Sn 2+ Cs + , MA + , FA + Cl - , Br - , I -<br>b (iii) well<br>n  =  �<br>200<br>700<br>Larger exciton Strong coupling Weak coupling<br>Lower bandgap<br>binding energy<br>100 E g<br>600<br>n  =  � A’2A n -1B n X3 n +1<br>1 10<br>LED PV Quantum and dielectric confinement<br>Number of layers  n<br>barrier barrier<br>Exciton binding energy (meV) PLemission wavelength  (nm)<br><!-- End of picture text -->

Fig. 1 Structure and photophysical properties of a quasi-2D perovskite. a (i) Schematic representation of a quasi-2D perovskite, which can be obtained by slicing the 3D perovskite along the <100> crystallographic direction. (ii) Schematic crystal structures of quasi-2D perovskites with different n- values. (iii) Electronic properties of quasi-2D perovskites, which are determined by the degree of quantum- and dielectric-confinement effects. b Eb and PL emission wavelength of quasi-2D perovskites as a function of n-value. Panel b is reprinted from ref.<sup>51</sup> with permission from Wiley 

stronger binding energy facilitates the formation of stable excitons at room temperature, thereby increasing the radiative recombination efficiency. Furthermore, the confinement intensity is dependent on the thickness of the QWs, which provides additional flexibility to tune the corresponding bandgap and carrier recombination dynamics<sup>51</sup> (Fig. 1b). The selection of barriers with different dielectric constants affects the Eb value, referred to as the “dielectric confinement” effect. Ishihara et al.<sup>52</sup> noted that the large Eb (370 meV) was too large to be explained only by the quantum confinement effect. Therefore, the dielectric confinement effect was raised<sup>53</sup> . Kanatzidis et al. simulated a highfrequency dielectric constant (ε∞) profile for different n- values of the BA2MAn−1PbnI3n+1 (BA<sup>+</sup> = CH3(CH2)3NH3+, MA<sup>+</sup> = CH3NH3+) family<sup>54</sup> . They demonstrated an increasing ε∞ for inorganic slabs with increasing n-value. The dielectric confinement dominates at n = 1, weakens at n = 5, and completely disappears in the 3D perovskite (n = ∞). Therefore, the dielectric confinement in quasi-2D perovskites also accounts for the corresponding high Eb, and the dielectric confinement decreases as the n-value increases (Fig. 1b). 

The robustness of the excitonic states at room temperature is the most prominent optical feature of quasi-2D perovskites, which originates from their large Eb. Fortunately, Eb can be regulated through composition and structure engineering. Basically, incorporating organic cations with different dielectric constants into the quasi-2D 

structure can significantly tune the dielectric confinement effect<sup>55,56</sup> . In addition, Eb can also be modulated due to confinement effects by varying the thickness of the QWs<sup>40</sup> . The large Eb and thus prominent excitonic luminescence are unique features of quasi-2D perovskites with application in LEDs. 

### Photophysical properties 

Ishihara et al. successively grew quasi-2D single crystals with n = 1, 2, 3, and 4<sup>27,28,52</sup> . Afterward, Kanatzidis et al. synthesized and structurally characterized the n = 5 (CH3(CH2)3NH3)2(CH3NH3)4Pb5I16 perovskite<sup>54</sup> . To date, the maximum n-value quasi-2D perovskite reported is the n = 7 (CH3(CH2)2NH3)2(CH3NH3)6Pb7I22 perovskite<sup>57</sup> . Significantly, the high-quality quasi-2D single-crystal confirms that the structure is thermodynamically stable, which lays the foundation for further optoelectronic applications. The carrier recombination dynamics of quasi-2D perovskite single crystals with various n-values were systematically studied to deeply understand the photophysical properties of quasi-2D perovskites. The carrier recombination dynamics of quasi-2D perovskites can typically be described by the following Eq. (1)<sup>58,59</sup> : 



<!-- Start of picture text -->
dNðtÞ<br>¼ �k1N � k2N 2 � k3N 3 ð1Þ<br>dt<br><!-- End of picture text -->

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 4 of 26 

Here, N represents the carrier density at delay time t; k1 refers to the monomolecular recombination constant; k2 is the bimolecular recombination constant, and k3 is the three-body Auger (nonradiative) recombination constant. Chen et al.<sup>60</sup> studied the charge-carrier recombination in quasi-2D perovskite single crystals using transient reflection (TR) spectroscopy. TR kinetics at different excitation fluences were then globally fitted to obtain k1, k2, and k3 for different n-value PEA2MAn−1PbnI3n+1 crystals. They found that the existence of excitons and free carriers varied in quasi-2D perovskite single crystals with different n-values. The largest k1 was found in the n = 1 sample, which can be attributed to its large Eb, indicating that excitons were dominant in this species, while for the n = 4 sample, free carriers dominated; for the n = 2 and 3 samples, free carriers and excitons coexisted. Additionally, Delport et al.<sup>61</sup> investigated the recombination dynamics in (C6H5C2H4NH3)2(CH3NH3)n−1PbnI3n+1 (n = 1, 2, 3, and 4) single crystals. They first studied the scaling law of PL0 (the PL intensity at t = 0 ns, at the instant of pulse excitation) with excitation fluence, which is a classical method used to analyze the recombination behavior. For 

the n = 1 2D single crystal, PL0 was linear with the excitation density, showing the predominant exciton recombination characteristic. However, for n > 1 single crystals, the nonlinear relationship between PL0 and the pump density proved the coexistence of free carrier and exciton recombination. The associated optical and electrical properties seemed to further diverge from those of the pure excitonic compound as the n-value increased. To conclude, in low n-value quasi-2D perovskites, Eb is large, which guarantees efficient exciton recombination. In high n-value species, the excitons tend to dissociate into free carriers as Eb decreases (Fig. 2b). The above carrier recombination dynamics in quasi-2D perovskite single crystals have established the potential use of quasi-2D perovskites as optoelectronic materials, such as in solar cells and LEDs. 

## Recombination characteristics of quasi-2D perovskite films 

### Crystallization kinetics 

In light of the efficient excitonic radiative recombination, efforts have been devoted to fabricating highquality quasi-2D perovskite films, aiming for LED 



<!-- Start of picture text -->
a 0.003 0 ns0.5 ns1 ns5 ns b 0.0127 567 nm610 nm642 nm695 nm c 600 0 ns0.5 ns1 ns5 ns<br>0.002 PL (static) 6 PL (static ×0.005 )<br>5<br>4<br>3 400<br>0.001 2<br>0.001<br>200<br>0.000 7<br>5 6<br>4<br>3<br>500 600 700 800 0.1 1 10 100 1000 500 600 700 800<br>Wavelength (nm) Delay time (ps) Wavelength (nm)<br>d e f<br>1 10 0 3D<br>6543 518 nm569 nm615 nm 10 –1 Quasi-2D y  �  x 0.6<br>649 nm<br>2 700 nm 10 –2 0.4 3DQuasi-2D<br>0.1<br>65 10 –3 y  �  x 2<br>4 0.2<br>3<br>2 10 –4<br>0.01 0.0<br>0.001 0.01 0.1 1 10 100 10 15 10 16 10 17 10 14 10 15 10 16 10 17 10 18<br>Delay time (ns) Charge-carrier density (cm –3 ) Charge-carrier density (cm –3 )<br>= 3() n < > OD)(–TA V OD)(–TA V<br>PL intensity (a.u.)<br>PLQY (%)<br>PL intensity (a.u.)  ( = 0) (a.u.) It PL<br><!-- End of picture text -->

Fig. 2 Charge-carrier recombination kinetics in quasi-2D perovskite films. a TA spectra at different timescales, b TA spectra at different wavelengths as a function of delay time, c PL spectra at distinct timescales, and d PL decay curve probed at selected wavelengths for <n> = 3 perovskites. Comparison of e initial time PL intensities and f PLQYs as a function of the photoinjected carrier density between 3D and quasi-2D perovskite films. Panels a–d are reprinted from ref.<sup>30</sup> with permission from Springer Nature. Panels e and f are reprinted from ref.<sup>62</sup> with permission from Springer Nature 

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 5 of 26 

applications<sup>60,62</sup> . The films possess mixed phases with different n-values rather than a single phase, which endows them with distinct optical characteristics compared to their single-crystal state<sup>63</sup> . Fortunately, this feature enables efficient energy transfer among different species, which is beneficial for radiative recombination. To better understand and manipulate the formation of the mixed-phase state, the underlying crystallization kinetics in quasi-2D perovskite films should be determined. Quintero-Bermudez et al.<sup>64</sup> systematically studied the formation process in quasi-2D perovskite films. They found that in the crystallization process, quasi-2D perovskites underwent an intermediate phase state, where tightly combined inorganic slabs, solvents, and organic cations were found. With the evaporation of the solvent, the inorganic layers are newly released from the intermediate phase and then combine with the surrounding organic cations to form a quasi-2D scaffold. The intermediate phase mediated the formation of the quasi-2D structure by providing the scaffold for subsequent nucleation and growth. Consequently, the phase distribution was strongly influenced by whether the organic cations were uniformly distributed on the film. 

In particular, selecting different solvents can regulate the distribution of QWs since different cations exhibit various solubilities in different solvents. The kinetics and mechanism of quasi-2D perovskite crystallization can be adjusted by the selection and proportion of the solvent mixture. Compared with dimethylformamide (DMF), dimethyl sulfoxide (DMSO) can form strong Lewis base adducts with lead halide<sup>65</sup> and strong hydrogen bonds with ammonium salts due to its high polarity (7.2)<sup>66</sup> . Thus, the presence of DMSO further increased the nucleation barrier of the perovskites. n < 4 species were remarkably favored when intermediate phases transformed into quasi-2D perovskites owing to the intrinsic lower nucleation barrier compared with n > 4 species<sup>66</sup> . Therefore, the mixed solvent or neat DMSO increased the disparity of nucleation barriers among various phases and thus led to a broader phase distribution compared to the neat DMF case<sup>67</sup> . 

### Carrier recombination characteristics 

Energy transfer in quasi-2D perovskite films originates from the graded band structure because of mixed n-value species. This structure acts as a carrier concentrator, increasing the carrier density of the recombination center. The resulting high carrier density thus partially photopassivates the shallower trap states, thereby significantly avoiding trap-mediated nonradiative recombination<sup>25,30,42</sup> . The energy transfer facilitates radiative recombination, resulting in high PLQYs for quasi-2D perovskite films even at low pumping densities. Thus, profoundly understanding the energy transfer kinetics 

and effectively modulating them are demanded to construct efficient quasi-2D optoelectronics. 

Yuan et al.<sup>30</sup> carried out ultrafast spectroscopy to investigate the carrier recombination kinetics for (PEA)2MAn−1PbnI3n+1 quasi-2D perovskite films. Intriguingly, the TA spectra exhibited four distinctive bleaching peaks in <n> = 3 (<n> represents the average “QW” thickness) films ascribed to n = 2, 3, 4, and 5 species. Figure 2a shows the relative intensity evolution of these bleaching peaks. The data demonstrated that carriers transfer from small n-value species to large n-value species. The build-up time for GSB of lower bandgap species was in good agreement with the fast decay time of higher bandgap species, which was less than 1 ps and indicated that the energy transfer was ultrafast (Fig. 2b). Time-resolved photoluminescence (TRPL) measurements revealed the same trend (Fig. 2c). Specifically, the lower bandgap species exhibited a biexponential decay, and the corresponding fast component was attributed to carrier funneling from large bandgap species (Fig. 2d). 

Xing et al.<sup>62</sup> investigated the power-dependent initial PL intensity (IPL [t = 0]) for (NMA)2FAn−1PbnI3n+1 quasi-2D perovskite films (Fig. 2e). Notably, IPL [t = 0] was linear with excitation density below 1.5 × 10<sup>16</sup> cm<sup>−3</sup> , while a clear transition from linear to superlinear was observed when the excitation density increased continuously. They demonstrated that monomolecular radiative exciton recombination was dominant under a low carrier density and gradually changed to free electron-hole bimolecular recombination as the carrier density increased further. Consequently, the PLQY of a quasi-2D perovskite can be given by the following equation<sup>62</sup> : 



<!-- Start of picture text -->
PLQYðNÞ ¼ Pkr ¼ k1;exciton þ k2N<br>P kr þ P knr k1;exciton þ k1;trap þ k2N þ k3N 2<br>ð2Þ<br><!-- End of picture text -->

Here, the monomolecular recombination constant k1 contains both k1,exciton and k1,trap, where k1,exciton is the radiative exciton recombination constant and k1,trap is the nonradiative trap-assisted recombination constant. The PLQY only depends on two physical processes, namely, radiative recombination (kr) and nonradiative recombination (knr), and is the result of competition between these two channels. Specifically, for quasi-2D perovskites, radiative recombination includes exciton recombination (k1,exciton) and free carrier recombination (k2); nonradiative recombination includes trap-assisted recombination (k1,trap) and Auger recombination (k3). In addition, these recombination rate constants (k1, k2, and k3) strongly depend on the carrier concentration (N). Therefore, the PLQY of quasi-2D perovskite films is dependent on N. At low N, PLQY only depends on the competition between k1,exciton and k1,trap. Fortunately, the 

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 6 of 26 



<!-- Start of picture text -->
a n = 5 b n = 2 c<br>n = 3 n = 4<br>2 n = 4 –1 n = 4 n = 5 –1 n  = 2 n = 3 n = 5<br> 0 –0.8 Engineered energy –0.8 Graded energy<br>Flat energy landscape landscape landscape<br>–2 –0.6 –0.6<br>–4 1 ps –0.4 –0.4<br>10 ps Transfer<br>100 ps –0.2 –0.2<br>–6<br>0 0<br>450 500 550 600 650 700  1 ps  10 ps  100 ps  1 ns  1 ps 10 ps 100 ps  1 ns<br>Wavelength (nm) Pump delay  Pump delay<br>d 100 graded e 0.04 DMSO nn == 23 f 0.04 NMP nn == 32<br>10 0.03 3D n  ≥ 3 0.03 3D<br>slope 1<br>   1<br>slope 2<br>Engineered energy landscape 0.02 0.02<br>0.1 Flat energy landscape<br>bulk 3D<br>0.01 slope 3 0.01 0.01<br>MAPbBr3<br>0.00 0.00<br>0 1 2 3 4 0.0 0.5 1.0 1.5 0.0 0.5 1.0 1.5<br>Power density (mW cm –2 ) Delay (ps) Delay (ps)<br>430 nm460 nm480 nm 490 nm<br> 500 nm<br> 460 nm<br>mOD<br>OD norm Δ OD norm Δ<br>/  T  Δ  /  T Δ<br>PLQY (%)<br><!-- End of picture text -->

Fig. 3 Phase distribution and crystal orientation for effective energy funneling. a TA spectra at different timescales for a quasi-2D perovskite film with a flat energy landscape. Time-dependent TA spectral traces for b an <n> = 3 perovskite film with an engineered energy landscape and c an <n> = 5 film with a graded energy landscape. d Pump power density-dependent PLQYs for different perovskite systems. Time-dependent TA spectral traces of different quasi-2D perovskite films obtained from e DMSO and f NMP solvents. Panels a–d are reprinted from ref.<sup>75</sup> with permission from the American Chemical Society. Panels e and f are reprinted from ref.<sup>77</sup> with permission from Wiley 

high PLQY and near invariant dependence for quasi-2D perovskite films at carrier densities below 10<sup>16</sup> cm<sup>3</sup> validated that radiative exciton recombination overwhelmed trap-mediated nonradiative recombination<sup>62</sup> (Fig. 2f). Additionally, many defect passivation strategies are used to reduce k1,trap. At high N, k3 increases sharply and gradually dominates, resulting in a decrease in PLQY<sup>68</sup> . Therefore, optimizing the optical properties of quasi-2D perovskite films mainly involves increasing k1,exciton and k2, and simultaneously suppressing k1,trap and k3. 

### Optical property modulation 

From the perspective of the crystallization kinetics and the carrier recombination characteristics of quasi-2D perovskite films, we conclude that efficient energy transfer, effective exciton recombination, and low defect density are the most striking features for quasi-2D perovskite films, which contribute to the excellent optical properties<sup>69</sup> . Here, we summarize the widespread strategies towards highly emissive quasi-2D perovskite films from the three aspects above. 

Efficient energy transfer requires photogenerated carriers to transfer quickly to lower bandgap species to escape from the trapping process. Therefore, energy transfer pathway optimization is highly needed to realize high-efficiency energy transfer<sup>70</sup> . For quasi-2D perovskite films, the n-value 

distribution affects their energy transfer and corresponding radiative exciton recombination efficiency. Fortunately, the n-value distribution can be modulated through fabrication process engineering<sup>71–74</sup> . Quan et al. tailored the energy landscapes in PEA2(MA)n−1PbnBr3n+1 perovskite using antisolvent engineering. As shown, the flat energy landscape in the <n> = 3 film led to subtle energy transfer, whereas the graded energy landscape in the <n> = 5 films, which consisted of different n-value species, facilitated the resulting energy transfer (Fig. 3a, b). They then optimized the concentration of n = 5 species in the <n> = 5 film to make a graded energy landscape, which can make energy transfer more efficient<sup>75</sup> (Fig. 3c). As a result, a high PLQY (60%) was achieved in the <n> = 5 films with the graded energy landscape (Fig. 3d). In addition, recent studies have noted that the grain orientation can also affect energy transfer efficiency. Lei et al.<sup>76</sup> demonstrated that a highly oriented quasi-2D perovskite film exhibited a faster Förster resonance energy transfer (FRET) than a randomly oriented film due to the decreased donor-acceptor distance and aligned dipole orientation<sup>77</sup> . Using N-methyl-2-pyrrolidone (NMP) as the solvent, PEA2(FA)n−1PbnBr3n+1 films with grains highly parallel to the substrate were obtained, while randomly oriented films were achieved by using DMSO as the solvent. Consequently, more efficient energy transfer was realized in the highly oriented quasi-2D perovskite films 

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 7 of 26 



<!-- Start of picture text -->
a b<br>PEABr PEABr-Crown<br>CBM<br>E b E b 60<br>PEABr<br>40 PEABr-Crown<br>E opt E g E g<br>E opt<br>20<br>0<br>VBM<br>20 40 60 80 100<br>PEA ratio (%)<br>c<br>Highly reaction<br>superoxide DMSO High volatility P = O with low volatility<br>O 2* – P = O<br>O2<br>2 2 2 2<br>1 1 3 1<br>Cs Pb Br O P C S H<br>d e<br>1.0<br>OS AsO Edge-stabilized perovskite<br>0.8<br>N O 22<br>O<br>C<br>0.6<br>Se<br>P 480 520 560 600<br>SP 0.4 28 Wavelength (nm) Control<br>OP 0.2<br>No protection 480 520 560 600<br>Wavelength (nm)<br>0.0<br>0 20 40 60 80 100 0.01 0.1 1 10 100<br>PLQY in film (%)  Delay (ps)<br>n  = 3<br>PLQY (%)<br>PL Intensity<br>PL Intensity<br>Normalized PL (516 nm)<br>Molecule for edge stabilization<br><!-- End of picture text -->

Fig. 4 Additive engineering for high-efficiency and stable quasi-2D perovskite films. a Energy schematic diagram of 40% PEABr with and without a “crown” additive. b PLQY versus PEABr ratio for the quasi-2D perovskite films with and without the “crown” additive. c Schematic illustrating imperfect edges of PEA2Cs2Pb3Br10 perovskite films and the reaction pathway to produce superoxide under photoexcitation. d Corresponding PLQYs of quasi-2D perovskite films treated with different molecules. e PL stability for the control (blue) and edge-stabilized (red) quasi-2D perovskites before and after (in gray) measurement. Panels a and b are reprinted from ref.<sup>78</sup> with permission from Springer Nature. Panels c–e are reprinted from ref.<sup>79</sup> with permission from Springer Nature 

according to various optical characterizations (Fig. 3e, f). In addition to the n-value distribution and the grain orientations, the coupled quasi-2D perovskite phases can also affect the energy transfer. Ren et al. introduced a bifunctional ligand (4-(2-aminoethyl) benzoic acid, ABA) into the mixedligand perovskite PEA/PA(CsPbBr3)n−1PbBr4 to promote coupled quasi-2D perovskite phases<sup>40</sup> . The strengthened interaction between the coupled perovskite phases would benefit efficient energy transfer in films, resulting in prolonged operational stability in PeLEDs. 

Enhancing radiative exciton recombination by increasing Eb can also improve the optical properties of quasi-2D perovskite films. Ban et al. demonstrated that severe phase 

separation between the perovskite and the organic phase would weaken dielectric confinement, introducing nonradiative recombination channels. Therefore, they used a crown molecule as an additive to suppress the π–π stacking between PEA cations, thereby inhibiting phase separation<sup>78</sup> . The suppression of phase separation led to a more pronounced dielectric confinement effect and an increased Eb (69.5 meV) (Fig. 4a). The k1 fitted by TA dynamics for crown-treated quasi-2D perovskite films showed a value of 9 × 10<sup>−6</sup> s<sup>−1</sup> , which was 1.5 times that of the controls without the crown. As a result, the crown-treated quasi-2D perovskite films exhibited an enhanced PLQY of 70 ± 8% compared with the pristine films (23 ± 5%) (Fig. 4b). 

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 8 of 26 

However, with increasing Eb, the enhancement of exciton recombination is accompanied by increases in k2 and k3. Therefore, the acquisition of a high radiative recombination efficiency should consider the trade-off between the high radiative recombination constant (k1,exciton and k2) and the low nonradiative recombination constant (k1,trap and k3). 

According to Eq. (2), minimizing k1,trap is equally important for obtaining high PLQYs of quasi-2D perovskite films. Owing to the ultrafast energy transfer process, quasi-2D perovskite films have less first-order nonradiative recombination loss than their bulk 3D analogs<sup>67</sup> . However, due to many uncontrollable factors during nucleation and growth, trap states still exist in the films. Generally, the generation of trap states is related to the volatilization of the solvent during the crystallization process. Specifically, Lewis base polar aprotic solvents, such as DMSO, DMF, or NMP, which readily form intermediate phases with metal halides, are widely used in the dissolution of perovskite precursors and the control of the crystallization rate<sup>79</sup> . However, the Lewis base metal complexes decompose under the annealing process with the evaporation of the solvent. Then, metal dangling bonds and halogen vacancies are inevitably brought to the grain surface. The undesirable edge states are sensitive to moisture and oxygen, where additional low-level orbitals can be provided once an oxygen atom is adsorbed. These edge states thus further serve as exciton capture sites. Small molecule additives with lone-pair electrons can provide strong bonding with Pb dangling bonds and reduce the density of halogen vacancies<sup>80</sup> . Yang et al.<sup>81</sup> used Lewis base trioctylphosphine oxidation (TOPO) to passivate the surface of a (PEA)2FA2Pb3Br10 film. After the surface treatment, the PLQY of the film increased from 57.3% to 73.8%. They addressed that the passivation effect originated from the bond between the P=O group in TOPO and the incomplete [PbBr6]<sup>4−</sup> octahedra. Quan et al.<sup>79</sup> found that the rapid photodegradation of quasi-2D perovskite films arose from edge-initiated oxidation. Photodegradation occurred as photogenerated carriers diffused to the edge states and produced superoxide (Fig. 4c). Therefore, they adopted an edge-stabilization strategy in which triphenylphosphine oxides passivated the halogen vacancy traps. With this strategy, the passivated quasi2D films obtained an edge-stable state and showed a nearunity PLQY up to 97% (Fig. 4d). Notably, small molecules including P=O or As=O groups showed strong binding energies with unsaturated Pb in quasi-2D perovskite films. More importantly, the perovskite films maintained excellent stability. After continuous illumination for more than 300 h in ambient air, no significant drop in PL intensity or emission peak shift was observed (Fig. 4e). In addition to small molecules, Lewis base polymers such as polyethylene oxide (PEO) and polyethylene glycol (PEG) also have an effective passivation effect on halogen 

vacancy traps<sup>82–85</sup> . Such polymers contain a large number of oxygen atoms with lone-pair electrons. They can coordinate with Pb<sup>2+</sup> to form passivation layers on the perovskite grain surface, which significantly reduces trapassisted nonradiative recombination. Additionally, these polymers could reduce the grain size, improve the film quality, inhibit ion migration, and enhance the stability of quasi-2D perovskite films. 

Precursor composition engineering is another effective method to reduce the trap state density of thin films. Since the crystallization of quasi-2D perovskite films is a selfassembly process, the precursor composition strongly influences the surface state, grain boundaries, and phase distribution of the ultimate films. Cheng et al.<sup>86</sup> fabricated quasi-2D perovskite films via two different precursor compositions: stoichiometric (ST) and extensive organic cation-doped (LOD). Compared with the ST precursor, the nonstoichiometric LOD precursor possessed a high organic cation/Pb<sup>2+</sup> ratio, thus providing more PEA<sup>+</sup> to passivate the grain boundaries and avoiding the formation of the unfavorable low-n phase. As a result, the LOD perovskite films showed remarkable optical properties, with the highest PLQY up to 95.3%. 

## Color-pure emission of quasi-2D perovskites 

Quasi-2D perovskites can achieve emission from violet to NIR spectral regions by chemical composition adjustment and dimensionality engineering (Fig. 5a, b). To date, EQEs exceeding 20% have been successfully achieved in green and NIR quasi-2D PeLEDs, while the realization of high-performance pure red and blue quasi-2D PeLEDs still encounters many obstacles. The most advanced Recommendation BT 2020 (Rec. 2020) standard demands that the monochromatic RGB primaries should approach (0.708, 0.292), (0.170, 0.797) and (0.131, 0.046) for red, green and blue in Commission Internationale de L’Eclairage (CIE) coordinates<sup>87</sup> (Fig. 5c). Simultaneously, a narrow full width at half maximum (FWHM) (<25 nm) is required. However, the pure red and blue quasi-2D PeLEDs still show lower efficiency, color purity, and stability than the desired values<sup>84,88–91</sup> . Here, we summarize three promising strategies to achieve high-performance pure red and blue quasi-2D PeLEDs. 

### Anion engineering 

Anion engineering is a straightforward strategy to achieve pure red and blue emission<sup>92–96</sup> . For instance, Li et al. reported blue emission perovskite films by partial substitution of Br<sup>−</sup> with Cl<sup>−</sup> in PEA2(CsPbBr3)n−1PbBr4 perovskite (Fig. 6a). However, the resulting quasi-2D PeLEDs presented spectral instability when the applied voltage exceeded 6 V. This spectral instability resulted from phase separation due to the migration of Cl<sup>−</sup> and Br<sup>−</sup> under the electric field<sup>97</sup> . A similar phenomenon was 

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 9 of 26 



<!-- Start of picture text -->
a c<br>Anion-based spectral tunability I 0.8 REC.2020 standard<br>Br<br>Cl<br>0.7<br>0.6<br>Purple Cl/Br Br/I NIR 0.5<br> Cl  Br   I<br>b 0.4 NTSC standard<br>Dimensionality engineering<br>0.3<br>0.2<br>Purple NIR 0.1<br>n  = 1 1 <  n  <  ∞ n  =  ∞<br>0.0<br>0.0 0.2 0.4 0.6 0.8<br>x<br>y<br><!-- End of picture text -->

Fig. 5 Spectral tunability of quasi-2D perovskites. Schematic representation of spectral tunability in quasi-2D perovskites realized by a anion and b dimensionality engineering. c CIE chromaticity coordinate diagram for display color gamut showing the Rec. 2020 and NTSC standards. Panels a, b are reprinted from ref.<sup>51</sup> with permission from Wiley 

also observed in red quasi-2D PeLEDs with mixed bromide-iodide perovskite films<sup>98</sup> . 

Strategies have been developed to suppress the undesired ion migration in mixed-halide quasi-2D perovskite systems<sup>99,100</sup> . Previous experience with perovskite photovoltaics suggested that the free energy linked to the composition or electronic structure can drive ion migration<sup>101</sup> . Li et al. reported a spectrally stable blue quasi-2D film by adding 2% yttrium(III) chloride (YCl3) to the precursor. The improved spectral stability can be attributed to inhibited ion migration. The incorporation of yttrium increased the ion migration activation energy of the quasi-2D perovskite from 0.26 to 0.75 eV, making it more thermodynamically stable<sup>102</sup> (Fig. 6b). In addition, theoretical calculations and experimental results suggested that phase separation could be mediated by ionic defects, especially by halide vacancies<sup>103</sup> . Thus, defect passivation can be used to mitigate or eliminate ion migration. Recently, Sargent et al. reported that the treatment of a PEA2Cs1.6MA0.4Pb3Br10 film with diphenyl phosphine chloride (DPPOCl) achieved stable blue emission<sup>104</sup> . They noted that DPPOCl would first react with trace water and release Cl<sup>−</sup> to saturate the halide vacancies. Meanwhile, DPPOCl would form hydrogen bonds to in situ immobilize the inserted Cl<sup>−</sup> (Fig. 6c). The chloride insertion-immobilization strategy enabled bright, narrowband, and stable blue quasi-2D PeLEDs. In addition, a recent study also proposed that local strains induced by lattice mismatch could facilitate ion migration<sup>105</sup> . An avenue was thus presented to enhance the intrinsic stability of perovskite films by reducing the residual strain in films. The above findings indicate that it is feasible to realize pure red and blue quasi-2D PeLEDs by using anion engineering, but the relevant studies are insufficient, and 

further research is required. Further research should focus on exploring more effective ion stabilization strategies to achieve more spectrally stable quasi-2D PeLEDs. 

### Cation engineering 

Spectra can also be tuned through “A-site” or “B-site” substitutions in quasi-2D perovskites. Commonly used “Asite” cations, e.g., Cs<sup>+</sup> , MA<sup>+</sup> , and FA<sup>+</sup> , possess incremental ionic radii (R) (RCs+ = 1.67 Å, RMA+ = 2.70 Å, RFA+ = 2.79 Å). The ion radius change causes the perovskite lattice to deviate from the desired tolerance factor, resulting in structural distortion and bandgap alteration<sup>106–108</sup> . Previous reports demonstrated that introducing Rb<sup>+</sup> (RRb+ = 1.52 Å) into a perovskite resulted in a significant increase in the bandgap due to the tilt of the inorganic octahedron and the reduction in orbital overlap<sup>109</sup> . The bandgap of RbxCs1−xPbBr3 perovskite films increased from 2.31 to 2.60 eV (0 ≤ x ≤ 0.8) with increasing Rb<sup>+</sup> . Jiang et al.<sup>110</sup> partially substituted Cs<sup>+</sup> with Rb<sup>+</sup> and fabricated alloy PEA2(RbxCs1−x)2Pb3Br10 films. The small-radius Rb<sup>+</sup> increased the optical bandgap of these films and realized blue emission within the range of ~450–490 nm (Fig. 6d). Moreover, alloy PEA2(RbxCs1−x)2Pb3Br10 films exhibited impressive spectral stability compared with the mixedhalide films since the undesired halide migration or Ostwald ripening had been overcome. Recently, Chu et al. used EA<sup>+</sup> (CH3CH2NH3+) to partially replace Cs+ and achieved pure-blue emission in PEA2(EAxCs1−xPbBr3)2PbBr4 perovskite. They claimed that the incorporation of EA<sup>+</sup> could decrease the Pb-Br orbital coupling and increase the bandgap (Fig. 6e). This strategy modulated the PL peak from the green region (508 nm) to the blue region (466 nm) with increasing EA<sup>+</sup> (Fig. 6f), and over 70% PLQY in blue emission was obtained<sup>45</sup> . Lanzetta et al.<sup>111</sup> reported the 2D 

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 10 of 26 



<!-- Start of picture text -->
a 1.0 Cl concentration CsCl : CsBr  d PEA2(Rb x Cs1- x )2Pb3Br10<br>0:1  x =1.0<br>0.8 1:9<br>2:8  x =0.8<br>0.6 3:7 4:6  x =0.6<br>5:5  x =0.4<br>0.4 6:4  x =0.2<br>7:3<br>0.2 8:2 9:1  x =0<br>0.0<br>460 480 500 520 540 560 375 400 425 450 475 500 525 550 575<br>Wavelength (nm) Wavelength (nm)<br>b 0.1 e<br>0.75 eV CsPbBr2.4Cl0.6 CsPbBr3 2.30 eV Pb sPb p<br>CsPbBr2.4Cl0.62%YCl3 Br p<br>0.01 CsPbBr3PEACl<br>0.26 eV 0.03 eV Cs0.75EA0.25PbBr3<br>2.58 eV<br>1E-3 0.04 eV<br>Cs0.5EA0.5PbBr3 2.60 eV<br>0.04 eV<br>1E-4<br>0.8 0.9 1.0 1.1 1.2 1.3 -10 -8 -6 -4 -2 0 2 4 6<br>300  T -1 Energy (eV)<br>c f<br>Trace H2O<br>Without<br>EABr 20%<br>EABr 40%<br>EABr 60%<br>Pb 2+ Cs + or MA + Br 479 nm EABr 80%<br>Cl Halide Vacancy EABr 100%<br>Blue Perovskite LEDs<br>479 nm<br>High Efficiency and Color Purity<br>Operating and Spectral Stability<br>400 450 500 550 600 400 450 500 550 600 650<br>Wavelength (nm)  Wavelength (nm)<br>Absorbance (a.u.)<br>Normalized PL (a.u.) Normalized PL (a.u.)<br>pDOS<br>–1(S*Km) T σ<br>Normalized EL<br>Normalized intensity (a.u.)<br><!-- End of picture text -->

Fig. 6 Tuning the spectra via anion and cation engineering. a PL spectra of 3D perovskite films with various contents of Cl ions. b Temperaturedependent conductivity measurement for different perovskite films to obtain the activation energy of ion migration. c EL spectra of control and DPPOCl-treated quasi-2D PeLEDs. Inset: Schematic representation of Cl ion insertion and immobilization in DPPOCl-treated perovskites. d UV-vis absorption and PL spectra of PEA2(RbxCs1−x)2Pb3Br10 perovskites with various contents of Rb ions (0 ≤ x ≤ 1). e Calculated electronic density of states (DOS) of control and EABr-treated perovskites. f PL spectra for different EABr contents. Panel a is reprinted from ref.<sup>97</sup> with permission from Springer Nature. Panel b is reprinted from ref.<sup>102</sup> with permission from Springer Nature. Panel c is reprinted from ref.<sup>104</sup> with permission from the American Chemical Society. Panel d is reprinted from ref.<sup>110</sup> with permission from Springer Nature. Panels e, f are reprinted from ref.<sup>45</sup> with permission from Springer Nature 

perovskite materials (PEA)2SnIxBr4−x with tunable optical properties in the visible spectral region. Limited to the manufacturing technology at that time, they only fabricated PeLEDs with extremely poor performance at 630 nm. Subsequently, Yuan et al.<sup>112</sup> developed a strategy to improve the film quality and protect Sn<sup>2+</sup> from oxidation by adding valeric acid (VA). They fabricated color-pure red PEA2SnI4 LEDs with an EQE of 5% and a lifetime of >15 h. 

In conclusion, cation engineering of the “A-site” or “Bsite” is another feasible strategy to achieve pure red and blue emission. This strategy dramatically slows down the spectral redshift caused by halogen segregation, thus showing excellent application potential in long-term 

stable quasi-2D PeLEDs. The “A-site” and “B-site” options are still limited, and researchers should exploit more suitable inorganic or organic cations to provide further breakthroughs. 

### Dimensionality engineering 

Quasi-2D perovskites with high structural tunability can enable flexible regulation of the quantum-confinement effect. Reducing the average <n> value of the film enhances the quantum-confinement effect, broadens the perovskite bandgap, and results in spectral blueshift. Thus, dimensionality engineering offers an efficient approach for spectral manipulation<sup>86,97</sup> . The average <n> values of 

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 11 of 26 



<!-- Start of picture text -->
a –4.5 b c<br>–5.0 0%<br>10% Crystal growth<br>–5.5 20%<br>40%<br>–6.0 60%<br>PEA Cs<br>IPA Pb<br>–6.5 PEA/IPA Br<br>C<br>–7.0 N Coordination<br>O induced<br>–7.5 H destabilization<br>1 2 3 4 5 6 7 360 390 420 450 480 510 540<br>Number of  n Wavelength (nm)<br>d e f<br>0.02 0.02<br>0.8 (PEA)2Cs2Pb3Br10 film 0.2 ps GABA-treated (PEA)2Cs2Pb3Br10 film 0.2 ps<br>1 ps 1 ps<br>0.01<br>0.6 5 ps 0 5 ps<br>10 ps 10 ps<br>0.4 0 40 ps100 ps –0.02 n  = 3 40 ps100 ps<br>0.2 –0.01<br>–0.04<br>0.0 –0.02<br>Coordinating molecule Mixture  n n  = 2<br>AA ×  2 AA Control –0.03 –0.06<br>450 500 550 600 400 450 500 550 600<br>Wavelength (nm)  Wavelength (nm)<br>Absorbance (a.u.)<br>Formation energy (eV)<br>(eV)<br>OD Δ OD Δ<br>Destabilization energy<br><!-- End of picture text -->

Fig. 7 Phase modulation of quasi-2D perovskites for effective blue emission. a Calculated formation energy of PEABr- and IPABr-based perovskites and their mixed quasi-2D perovskites with different n-values. Inset: Atomic model of the PEA/IPA mixed quasi-2D perovskite with n = 3. b UV-vis absorption spectra of the perovskite PEA2A1.5Pb2.5Br8.5 with different amounts of IPABr additive. c Schematic diagram of the chelating effect on PbBr2 binding to the surface. d DFT-calculated destabilization energy of PbBr2 on the quasi-2D perovskite surface when coordinated with GABA and PEA. TA spectra at different timescales for e (PEA)2Cs2Pb3Br10 and f GABA-treated (PEA)2Cs2Pb3Br10 perovskite films. Panels a and b are reprinted from ref.<sup>121</sup> with permission from Springer Nature. Panels c–f are reprinted from ref.<sup>122</sup> with permission from Springer Nature 

quasi-2D perovskite films are determined by the equilibrium between the large organic cations and the precursor<sup>88</sup> . In theory, increasing the content of large organic cations can monotonically reduce the <n> value of quasi2D perovskite films. However, this does not mean that quasi-2D perovskite films with low <n> values are sufficient to effectively realize pure red or blue emission. For instance, increasing the content of large organic cations results in excessive generation of a low n-value phase, which leads to inefficient energy transfer and reduced optical properties<sup>113</sup> . Meanwhile, poor charge transport properties arise from large amounts of insulating organic cations. Moreover, the strong electron–phonon coupling and exciton–exciton annihilation at small <n> values act as nonradiative recombination pathways and further deteriorate the optical properties<sup>114</sup> . 

Judicious phase modulations towards a narrow phase distribution are highly desired to realize pure red and blue emission, which would address the severe optical property degradation in small <n> value films<sup>44,115–120</sup> . Controlling crystallization by antisolvent techniques or rational large cation spacers and additives can narrow the phase distribution<sup>72,115</sup> . Xing et al. selected the short organic cation isopropylammonium (IPA<sup>+</sup> ) to partially replace the longer cation (PEA<sup>+</sup> ) in PEA2A1.5Pb2.5Br8.5 (A = MA<sup>+</sup> 

and Cs<sup>+</sup> ) films, which can modulate the crystallization and phase distribution in the quasi-2D perovskite. Theoretical calculations showed that the formation energy of the n = 1 phase changed from −7.2 (more stable) to −6.5 eV (less stable) when these two cations were used synergistically (Fig. 7a). Thus, increasing the IPA<sup>+</sup> /Pb<sup>2+</sup> ratio suppressed the formation of the n = 1 phase and inhibited high-n phase generation afterward, while the intermediate n phases (n = 2, 3, 4) grew faster instead (Fig. 7b). Simultaneously, the PL peaks blueshifted from 497 to 467 nm as the IPA<sup>+</sup> /Pb<sup>2+</sup> ratio increased from 10 to 60%<sup>121</sup> . As a result, the resultant films displayed high PLQYs and stable blue emission by modulating the phase judiciously, thereby fabricating efficient and spectrally stable sky-blue quasi-2D PeLEDs. Since then, the effect of mixed organic cations on the properties of quasi-2D perovskites has been extensively studied. 

In addition to mixed-cation strategies, a judicious phase distribution can be achieved by rationally screening additives. Wang et al.<sup>122</sup> incorporated a chelating agent, γ- aminobutyric acid (GABA), into a PEA2Csn−1PbnBr3n+1 film. Theoretical calculations indicated that the coordination tendency of small chelating molecules towards PbBr2 in the vicinity of the perovskite could inhibit the binding of PbBr2 to the perovskite surface, suppressing the growth of 

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 12 of 26 

the large n phase. Replacing the unidentate group (PEA<sup>+</sup> ) with a small bidentate molecule (GABA) resulted in a 10fold increase in the destabilization energy (0.51 eV), which increased further when two GABA molecules were utilized for coordination (Fig. 7c, d). The photoexcited carrier dynamics of the GABA-treated quasi-2D perovskite films adequately proved that the resulting phase distribution was concentrated at n = 2 and 3 (Fig. 7e, f). The efficient energy transfer from the judicious phase distribution of the films can increase the PLQY and realize true-blue emission (EL at 478 nm)<sup>122</sup> . In conclusion, after a series of artificial designs and interventions regarding the phase distribution, the optical properties of pure red and blue quasi-2D perovskite films have significantly improved, paving the way for high-performance pure red and blue quasi-2D PeLED manufacture. In our opinion, successful fabrication of highperformance quasi-2D PeLEDs with pure red and blue emission that satisfy display purposes might require a combination of strategies leveraging anion engineering, cation engineering of the “A-site” or “B-site,” and dimensionality engineering. 

## High-performance quasi-2D PeLEDs 

Highly emissive perovskite layers are not sufficient to obtain high-performance quasi-2D PeLEDs due to the difference between photoluminescence and electroluminescence. The working principle and important parameters of PeLEDs need to be specifically considered. PeLEDs can be simplified into a double-heterojunction structure, in which the perovskite emitter layer is sandwiched between the p-type hole transport layer (HTL) and the n-type electron transport layer (ETL)<sup>123</sup> . Under a forward voltage, holes and electrons are injected from the anode and cathode, respectively, and are confined in the perovskite layer. Then, the holes and electrons release photons through radiative recombination. The key parameters, including the EL peak, FWHM, luminance, turnon voltage (Von), EQE, and operational stability, are used to evaluate the performance of PeLEDs<sup>124</sup> (Table 1). For display devices with a wide color gamut, LEDs usually need to have a specific EL peak and a narrow FWHM to achieve emission purity, while in the case of white-light devices for solid-state lighting, the devices have a wide emission range and FWHM. The luminances of LEDs are usually between 200 and 1000 cd m<sup>−2</sup> for display applications and exceed 10,000 cd m<sup>−2</sup> for solid-state lighting<sup>125</sup> . Von refers to the voltage when the luminance of the device reaches 1 cd m<sup>−2</sup> . A low Von represents an effective injection of carriers. The operational stability of PeLEDs is usually evaluated by T50, which represents the time for the luminance to drop to half of its initial value when working at a fixed current or voltage. 

EQE is defined as the ratio of the number of photons emitted by the device to the number of electrons injected 

and is the most important indicator for judging the energy conversion efficiency of LEDs. EQE can be expressed as the product of the internal quantum efficiency (IQE) and light extraction efficiency (ηoc)<sup>126</sup> . 



<!-- Start of picture text -->
EQE ¼ IQE ´ ηoc ¼ γ ´ χ ´ ηPL ´ ηoc ð3Þ<br><!-- End of picture text -->

Here, IQE is defined as the ratio of the number of photons generated to the number of electrons injected into the LED; ηoc represents the ratio of the number of photons emitted to the outside to the number of photons generated in the active layer; γ represents the charge injection balance factor; χ refers to the fraction of excitons for radiative decay, and ηPL is the PLQY<sup>127</sup> . ηPL has been detailed before, and ηoc will be elaborated below. Here, we focus on γ and χ, which relate to the device structure and electrical factors. Device engineering, such as optimization of the charge transport layers of quasi-2D PeLEDs, could promote the charge injection balance factor towards its maximum (γ = 1)<sup>128</sup> . In addition, the use of electron- and hole-blocking layers can confine the charge carriers in the emitting layer and thus lead to enhanced charge balance. The use of interfacial engineering to reduce the exciton quenching at each interface of the device could promote the fraction of excitons for radiative decay (χ)<sup>129</sup> . Based on Eq. (3), we summarize three aspects to improve the electrical properties in quasi-2D PeLEDs, including function layer modulation, interfacial engineering, and light outcoupling technologies. Finally, the operational stability is another critical parameter of quasi-2D PeLEDs, and we then overview several possible reasons for degradation<sup>130</sup> . 

### Functional layer optimization 

To convert high PLQYs of quasi-2D perovskite films into high EQEs of quasi-2D PeLEDs, the band alignment of the device structure is the most basic consideration. Typically, PeLEDs have a sandwich device structure in which the perovskite emissive layer is located between the electron and hole transport layers. Ideally, the charge balance factor can be maximized to 1 (γ = 1) by optimizing the charge transport layer. The energy levels for different transport layer materials (TLMs), including HTLs and ETLs, are shown in Fig. 8a. Appropriate TLMs should have ideal energy levels for efficient carrier transport while blocking opposite carrier transport. In addition, the carrier mobility of different TLMs also affects the carrier injection balance. For ETLs, PO-T2T (2,4,6-tris[3-(diphenylphosphinyl) phenyl]-1,3,5-triazine) can enable overall performance improvements compared to B3PYMPM (4,6-bis (3,5-di(pyridin-3-yl) phenyl)-2-methylpyrimidine) and TPBi (2,2′,2″-(1,3,5-benzinetriyl)-tris(1-phenyl-1-H-benzimidalzole))<sup>131</sup> . The deeper HOMO level (−7.5 eV) and the superior electron mobility (∼10<sup>−3</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ) account for the excellent electron transport and hole-blocking 

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 13 of 26 

|Refs.||30||42||71|73|168||16|185|163|72|171|167|132|29|38|72|119|84||||44|48|112|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|T50 stability|||–|2|2 h @10 mA cm−|>10 h@3 mA cm−2|90 s@5 v|−2|50 min@10 mA cm|46 h@0.1 mA cm−2|–|30 min@100 mA cm−2|–|1.3 h@10 mA cm−2<br> −2|20 h@2 mA cm<br>>100 h@25 mA cm−2|>1 h@10 mA cm−2|–|5 h@10 mA cm−2|–|–|>4 h@3.5 v||||–||>15 h@20 cd m−2|
|Lmax [cd m−2]/ Rmax [Wsr−1<br>m−2]||R|80|R|82|72R|30|R|199|<10R|–|254R|–|60R|88.5R|7.4R|114.9R|~440|~130|732|390|1231|1392|186|968|70|~100|
|Peak EQE [%]|||8.8||11.7|7.9|10.4||17.6|20.1|13|12.7|15|11.4|5.2|8.1|20.2|3.7|7.3|7.3|0.41|2.81|6.23|4.73|13.3|0.3|5|
|]<br>FWHM [nm]|||–||–|–|–||–|~49|–|–|–|–|50|–|35.4|–|~34||61|50|39|36|(0.72, 0.27)|24/(0.706,0.294)|21/(0.708,0.292)|
|EL [nm|||750||786|749|748||752|~780|740|~790|750|804|776|980|800|688|683|694|638|664|680|690|F/<br>664|633|632|
|Device architecture||ITOTOFMOA|/i2/perov/8/o3/u||ITO/ZnO/PEIE/perov/TFB/MoOx/Au|ITO/Poly-TPD/perov/TPBi/LiF/Al|ITO/Poly-TPD/perov/TPBi/LiF/Al|ll|ITO/Poy-TPD/perov/TPBi/LiF/A|MA<br>ITO/MZO/PEIE/PPBH/TFB-PFO/MoOx/Au|AgNW/Poly-TPD/perov/TPBi/LiF/Al|ITO/PEIE-ZnO/perov/TFB/MoOx/Al|ITO/Poly-TPD/perov/TPBi/LiF/Al|ITO/ZnMgO/perov/TFB/MoOx/Al|ITO/PEIE-ZnO/perov/TFB/MoOx/Al|ITO/PEDOT:PSS/QDLP/TPBi/LiF/Al|Glass/Au/ZnO/PEIE/perov/TFB/MoO3/Au|ITO/ZnO/PEIE/perov/TFB/MoOx/Au|ITO/NiO/Poly-TPD/PVK/perov/TPBi/Ca/Al|ITO/ZnO/PEIE/perov/TFB/MoOx/Au|ITO/PEDOT:PSS/Poly-TPD/perov/BCP/LiF/Al||||ITO/PEDOT:PSS/Poly-TPD/PVK/perov/TPBi/Li<br>|Al<br>ITO/PEDOT:PSS/perov/TPBi/LiF/Al.|ITO/PEDOT:PSS/perov/TPBi/LiF/Al|
|Perovskite materials|frared (NIR) quasi-2D PeLEDs|PEAMAPbI|()24516||(NMA)2FAPb2I6Br|MAPbI3·20%FPMAI|MAPbI3·20%BAI|b|Cs0.2FA0.8PI2.8Br0.2·20%BAI|(NMA)2(FA)n−1PbnI3n+1·poly-HE|MAPbI3·FPMAI|(NMA)2FAn−1PbnI3n+1|MAPbI3·20%PMAI|(EDBE)FAn−1PbnI3n+1|(BAB)FAn−1PbnI3n+1|PbS QDs in (PEA)2Cs2Pb3Br10|(NMA)2FAn−1PbnI3n+1|asi-2D PeLEDs<br>(NMA)2Csn−1Pbn(I/Cl)3n+1|(PBA)2Csn−1PbnI3n+1|(NMA)2Csn−1PbnI3n+1|(BA)2Csn−1PbnI3n+1·PEO||||(PBA)2Csn−1PbnI3n+1|(PEA)2SnI4|(PEA)2SnI4|
|Year|Near-in||2016||2016|2017|2017||2018|2018|2018|2018|2019|2019|2019|2020|2020|Red qu<br>2017|2017|2018|2018||||2019|2020|2020|



Zhang et al. Light: Science & Applications (2021) 10:61 

Page 14 of 26 

|Refs.|63|75|72||76||131|82||81|83|166|157||137||78||135||85|133||156|43|98||91||79||86||136|134|143|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|T50 stability|–|–||–||–|–|−2|102 min@100 cd m|70 min@280 cd m−2|45 min@100 cd m−2|72 min@10 mA cm−2||>25 min@3.5 v|63 i1330 d−2|mn@ c m|2|90 min@2 mA cm−||–|–||–|9.2 h@10 mA cm−2|~2.5 h@150 cd m−2|–||40 i100 d−2|mn@ c m|2|3.5 h@4000 cd m−|−2|<1 h@0.25 mA cm|42 s@5 V|1.5 h@1 mA cm−2|–|
|−2]/ Rmax [Wsr−1|||||||||||||||||||||||||||||||||||||
|Lmax [cd m<br>m−2]|2935|8400||14,000||~3000|56,143||24,100|9120|33,533|3259||23,380|30000|,||~20,000||13,970|8052||15,765|41,500|11,560|3810|11,200|8353|||45,230||37,477|10,000|~6500|~50,000|
|Peak EQE [%]|4.9(CE)|7.4||10.4||5|13||14.6|14.36|8.42|4.51||14.4|77|.||15.5||16.3|15.1||15.4|10.6|15.9|10.1|7.2|174|.||14||14.7|4.5|12.4|19.1|
|]<br>FWHM [nm]|–|–||17||–|2<br>25–26||–|23|19–21|24||22||–||–||22|25||–|–|21.7|–|||–||–||23|24|21|~18|
|EL [nm|525|526||514||540|528–53||530–54|532|514|500||512|537|||514||526|534||532|525|518|506|513|512|||517||529|528|527|~520|
|Device architecture|ITO/Buf-HIL/perov/TPBi/LiF/Al|ITO/PEDOT:PSS/perov/TPBi/LiF/Al||ITO/NiO/TFB/PVK/perov/TPBi/Ca/Al|ITOLFPOTTCAl|/i/perov/-2/a/|s<br>ITO/PEDOT:PSS/perov/PO-T2T/Ca/Al||ITO/NiOx/perov/TPBi/LiF/Al|ITO/m-PEDOT:PSS/perov/TOPO/TPBi/LiF/Al|ITO/PEDOT:PSS/perov/TPBi/Ca/Al|ITO/PEDOT:PSS:PFI/perov/TPBi/LiF/Al||ITO/Poly-TPD/PFN/perov/TPBi/LiF/Al|ITO/PVK//TPPB/LiF/Al|perovmy||ITO/Poly-TPD/perov/TPBi/LiF/Al||ITO/PEDOT:PSS/TFB/perov/TPBi/LiF/Al|ITO/PVK:TPD-DDAB/perov/TPBi/CsF/Al||ITO/PEDOT:PSS-Na/perov/TOPO/TPBi/LiF/Al|ITO/PEDOT:PSS/perov/TPBi/LiF/Al|ITO/TFB/PVK/perov/TPBi/LiF/Al|ITO/PEDOT:PSS/PVK/perov/TPBi/Al||ITO/NiO/PVK//TPBi/LiF/Al|xperov||ITO/PEDOT:PSS:PFI/perov/TPBi/LiF/Al||ITO/PVK/perov/TPBi/LiF/Al|ITO/PEDOT:PSS/perov/TPBi/LiF/Al|ITO/PVK/perov/TPBi/LiF/Al|ITO/TFB/LiF/perov/TPBi/LiF/Al|
|materials|EDs<br>−1PbnBr3n+1|−1PbnBr3n+1||1PbnBr3n+1|FAPbB|2n−1nr3n+1|PbnBr3n+1 FAPbBr3 NC||3Br10|b3Br10|PbnBr3n+1·PEO|1PbnBr3n+1/Cs4PbBr6||bnBr3n+1|B|nr3n+1||1PbnBr3n+1||PABr|An−1PbnBr3n+1||1PbnBr3n+1|b3Br10|Br|Br3n+1||PbBNB|1nr3n+1·ar||A0.6Pb4Br13||1PbnBr3n+1|Cs)n−1PbnBr3n+1|1PbnBr3n+1|1PbnBr3n+1|
|Perovskite|quasi-2D PeL<br>(PEA)2MAn|(PEA)2MAn||(PBA)2Csn−|CHNH|(8173|(OA)2FAn−1||(BA)2FA2P|(PEA)2FA2P|(BA)2Csn−1|(PEA)2Csn−||(PEA)2CsnP|BIZFAP|()22||(PEA)2Csn−||FAPbBr3·D|(PBA/PA)2F||(PEA)2FAn−|(PEA)2FA2P|CsPbBr3·Na|BA2CsnPbn||(PEA)C|2sn−||PEA2Cs2.4M||(PEA)2FAn−|(PEA)2(FA/|(PEA)2FAn−|(PEA)2Csn−|
|Year|Green <br>2016|2017||2017||2018|2018||2018|2018|2018|2018||2018|2018|||2018||2018|2019||2019|2019|2019|2019||2019|||2020||2020|2020|2020|2020|



Zhang et al. Light: Science & Applications (2021) 10:61 

Page 15 of 26 

|Refs.|164|194|88|195|90|89|121|92|98||144|196|102|97|2<br>117||110||116|137|104||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|T50 stability|6.5 min@10000 cd m−2|–||–|–|–|10 min@10 cd m−2<br>4 min@20 cd m−2<br>|0.5 min@210 cd m−2<br>30 min@4.8 v|1 min@500 cd m−2|10 min@800 cd m−2|–|220 min@150 cd m−2<br>120 min@415 cd m−2|<br>100 min@100 cd m−2|10 min@1500 cd m−2|135 i035 A−|. mn@. m cm|−2|14.5 min@15 cd m|4.3 min@100 cd m−2|4 min@100 cd m−2|<br>51 min@1500 cd m−2|90 min@100 cd m−2|
|−2]/ Rmax [Wsr−1|||||||||||||||||||||||
|Lmax [cd m<br>m−2]|82,480|–|8.5|1<br>1<br>19.5|1.26<br>186|200|2480|7320|962|3340|1446|4359|9040|3780|211|||100.6|1200|700|5141|468|
|EQE [%]|||||||||||||||||||||||
|Peak|20.36|0.04|0.23|0.024<br>0.004<br>1.1|0.06<br>0.015|2.6|1.5|3.6|2.4|6.2|0.52|1.45|11.0|5.7|26|.||1.35|2.62|9.5|1.3|5.2|
|]<br>FWHM [nm]|21.2|–|24|18<br>40<br>–|–|–|28|26|23|25|21|26|–|21|25|||20|23|–|18|18|
|EL [nm|525|410|492|456<br>432<br>494|462<br>491|473|490|505|465|487|490|492|485|480|465|||475|485|483|489|479|
|Device architecture|ITO/PEDOT:PSS/PFNBr/perov/PMMA/TmPyPB/<br>LiF/Al|ITO/PEDOT: PSS/perov/TPBi/Al/Ca|ITO/PEDOT: PSS/CBP/perov/TPBi/LiF/Al|ITO/PEDOT: PSS/perov/TPBi/Ba/Al|ITO/PEIE-ZnO/perov/TFB/MoOx/Al|ITO/PEDOT:PSS/perov/TmPyPB/CsF/Al|ITO/PEDOT:PSS/NiOx/PVK/perov/TPBi/LiF/Al|ITO/PEDOT:PSS/perov/TmPyPB/Cs2CO3/Al|ITO/PEDOT:PSS/PVK/perov/TPBi/Al||ITO/NiOx/LiF/perov/TPBi/LiF/Al|ITO/NiOx-PSSNa/perov/TPBi/LiF/Al|ITO/PEDOT:PSS/perov/TPBi/LiF/Al|ITO/PEDOT:PSS/perov/TPBi/LiF/Al|ITO/PVK/PFI//3TPYMB/Li/Al|perovq||ITO/PEDOT:PSS/perov/TmPyPB/LiF/Al|ITO/PVK/perov/PO-T2T/Liq/Al|ITO/NiOx/TFB/PVK/perov/TPBi/LiF/Al|ITO/PEDOT:PSS:PFI or Poly-TPD/perov/TPBi/<br>|LiF/Al|
|Perovskite materials|(p-FPEA)2MAn−1PbnBr3n+1|uasi-2D PeLEDs<br>(PEA)2PbBr4|(OLA)2MAn−1PbnBr3n+1|(PEOA)2MAn−1PbnBr3n+1|(4-PBA)2PbBr4|(EA)2MAn−1PbnBr3n+1|(PEA/IPA)2(MA/Cs)n−1PbnBr3n+1|PA2Csn−1PbnBr3n+1|(BA)2Csn−1Pbn(Br/Cl)3n+1||(PBA)2Csn−1Pbn(Br/Cl)3n+1|(PA)2Csn−1PbnBr3n+1|(PEA)2Csn−1Pbn(Br/Cl)3n+1|(PEA)2Csn−1Pbn(Br/Cl)3n+1|PEA/PPDABCPbB|(-r2)2sn−1nr3n+1||(PEA)2(Rb/Cs)n−1PbnBr3n+1|(PEA/NPA)2Csn−1PbnBr3n+1|PBABr2(Cs07FA03PbBr3)|..<br>PEA2Cs1.6MA0.4Pb3Br10·DPPOCl||
|Year|2021|Blue q<br>2016|2016|2017|2017|2017|2018|2018|2019||2019|2019|2019|2019|2019|||2019|2019|2019|2020||



Zhang et al. Light: Science & Applications (2021) 10:61 

Page 16 of 26 

|Refs.|115||122<br>45|||197|120|198|
|---|---|---|---|---|---|---|---|---|
|T50 stability|232 s@12 cd m−2||150 s@200 cd m−2<br>200s@100 cd m−2|||970 s@100 cd m−2|81.3 min@0.3 mA cm−2|14.0 min@1 mA cm−2|
|]/ Rmax [Wsr−1|||||||||
|Lmax [cd m−2<br>m−2]|150|1000|200<br>2790|2191|83|1511|~600|451|
|EQE [%]|||||||||
|Peak|2.34|5.08|6.3<br>13.3|12.1|4.19|11.7|10.11|4.14|
|M [nm]|||0.14)|||||5, 0.076)|
|FWH|–||(0.12,<br>23|25|25|18.8|25|(0.12|
|EL [nm]|LiF/Al<br>465|493|r3 QW/TPBi/LiF/<br>478<br>/LiF/Al<br>495|488|480|Bi/LiF/Al<br>488|486|F/Al<br>469|
|re|ov/POT2T/||PVK/CsPbB<br>perov/TPBi|||/perov/TP|i/LiF/Al|ov/TPBi/Li|
|ctu|/per||:PFI/<br>SS/|||/PVK|TPB|/per|
|hite|:PSS||:PSS<br>OT:P|||TAA|rov/|:PSS|
|arc|DOT||DOT<br>PED|||Ox/P|K/pe|DOT|
|Device|ITO/PE||ITO/PE<br>Al<br>ITO/m-|||ITO/Ni|ITO/PV|ITO/PE|
|terials|Br3n+1||bBr3)2PbBr4|||(Br/Cl)3n+1·NaBr|PbnBr3n+1|)Pb(Cl/Br)3|
|ma|1Pbn||BA<br>EAxP|||1Pbn|sn−1|PEA|
|te|n−||GA<br>−x|||n−|2C|-F-|
|Perovski|(PBA)2Cs||CsPbBr3·<br>PEA2(Cs1|||(PEA)2Cs|(PEA/PA)|(Cs/FA/p|
|Year|2020||2020<br>2020|||2020|2020|2020|



properties of PO-T2T. For HTLs, poly(3,4-ethylenedioxythiophene):polystyrene sulfonate (PEDOT:PSS) is commonly used, and its work function is ∼5.2 eV<sup>132</sup> . Notably, in terms of hole injection, a large barrier exists between PEDOT:PSS and the perovskite layer with a deeper valence band, especially in green and blue emitters. Fortunately, this predicament can be overcome by employing poly (sodium 4-styrenesulfonate) (PSS-Na) to increase the work function of PEDOT:PSS<sup>45,81,133</sup> . PEDOT:PSS doped with perfluorinated ionomer (PFI) can also achieve similar effects<sup>79,104</sup> . In addition, HTLs with low HOMO levels, such as poly[bis(4-phenyl)(2,4,6-trimethylphenyl)amine] (PTAA), poly(9,9-dioctylfluorene-co-N-(4-butylphenyl)diphenylamine) (TFB), poly(9-vinlycarbazole) (PVK), and poly[bis(4-phenyl)(4-butylphenyl)amine] (poly-TPD), were deposited on PEDOT:PSS to form gradient energy levels for hole injection, which can also achieve charge balance effectively<sup>72,134–136</sup> . 

Balanced carrier transport and sufficient radiative recombination center density in perovskite emissive layers are also key to ensuring excellent electrical properties. Here, we summarize the effects of organic cation spacers and grain orientations on the carrier transport and recombination capabilities of quasi-2D perovskite films when the device is operated under a bias voltage. Due to the insulating nature of organic cation spacers, the charge transport of the quasi-2D perovskite films becomes anisotropic and highly restricted, damaging the device performance. Wu et al. replaced large organic molecules with small basic sodium ions (Na<sup>+</sup> ) to improve the conductivity of the emissive layers. The Na<sup>+</sup> could generate amorphous sodium lead bromide (NaPbBr3) in the perovskite as spacers to form a nanocrystal-like halide perovskite film (Fig. 8b). High EQE (15.9%) and PLQY (>50%) were achieved by varying the inorganic salt molar ratio and adding trace organic additives to the perovskite<sup>43</sup> . In addition, molecular engineering to control the barrier width of quasi-2D perovskites is another way to optimize the conductivity of the emissive layers. The introduction of a rigid benzimidazole (BIZ) molecule into quasi-2D perovskites resulted in the formation of the novel quasi-2D perovskite (BIZ)2(FA)n−1PbnBr3n+1 with reduced barrier width and increased carrier mobility<sup>137</sup> . 

Controlling the grain orientations in quasi-2D perovskite films is crucial for efficient carrier transport. Extensive research on the grain orientations of quasi-2D perovskite solar cells will help us systematically study and understand the grain orientations of the emissive layers in quasi-2D PeLEDs. Ideally, vertically oriented films provide a direct path for hole and electron transport. Therefore, by controlling the vertical orientations of the grains in perovskite films, the suppressed out-of-plane charge transport caused by organic cations can be solved<sup>138</sup> . Tsai et al. first reported that vertically oriented films could facilitate efficient charge injection 

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 17 of 26 



<!-- Start of picture text -->
a –1–2–3 FTO  or –1.8 –2.3–2.0 –2.3–2.4–2.3–2.9–2.3 –3.1–3.4–3.6–3.2–3.5Electron–2.7 –2.7–2.8–3.2–3.7 b 10 0 2.3Å5.83Å 13.96 Å8.13 Å nn  = 1 = 2 bCsPbBrNa<br>–4 –ITO4.4 –4.3–4.0 ––4.34.7 AlAg 10 –3 a c<br>–5 –4.7 –4.9–5.2–5.3 –5.1 Au<br>–5.2 –5.4–5.2–5.4–5.4–5.4–5.4 –5.4 –5.3–5.3 10 –6<br>–6 –5.8–5.8 –5.7 –6.1 –6.2 –6.0<br>–7 Hole –6.7 –6.7 50% NaBr<br>–7.3 –7.2 10 –9 50% PEABr<br>–7.6<br>–8 50% NMABr<br>Hole transport layers Quasi-2D perovskites Electron transport layers<br>–9 50% BABr<br>0.01 0.1 1 10<br>Voltage (V)<br>c d e<br>10 3 Casting temperature Outcoupled photons<br>MoOx/Au<br>RT<br>70 °C<br>TFB<br>110 °C Organic layer<br>10 1 OLED Perovskite<br>hv Outcoupled photons ZnO-PEIE<br>ITO/PEDOT ITO<br>10 –1 h h A B<br>Glass substrate<br>e e PeLED<br>Radiative recombination event<br>PCBM/AI C<br>10 -3<br>Photon recycling event<br>1.0 2.0 3.0<br>Voltage (V)<br>f 100% Evanescent coupling g 20% PEDOT:PSS Thickness  h<br>80% Guided mode 2 nm  60 nm<br>15%<br>60% Absorption Loss PEDOT:PSS 2 nm  Au<br>10%<br>MoO3<br>40%<br>Substrate guided TFB<br>MQW-Perovskite<br>20% 5% PEDOT:PSS 60 nm  PEIE<br>ZnO<br>Out-coupled Au<br>0% 0% Glass<br>10 20 30 40 50 60 0.0 0.2 0.4 0.6 0.8 1.0<br>PEDOT:PSS Thickness (nm) Equivalent recombination center location ratio<br>PEDOT:PSS NiOx TFB WO3 MoO3 NPB F8<br>PTAA Poly-TPD PVK PEAMAPbBr 21023 PEAMAPbBr2 4165 PEAMAPbI2 4 165 IPEAMAPb32 3 10 CsClPEAMAPbBr21.6 0.4337 TBPi TmPyPB BCP BPyMPM3 ZnO TiO2<br>Energy (eV) BPyMPM4<br>–2Current density (mA cm)<br>–2Current density (mA cm)<br>Outcoupled efficiency<br>Relative average contribution<br><!-- End of picture text -->

Fig. 8 Device engineering and characterization of quasi-2D PeLEDs. a Energy levels for different transport layers and emitting layers. b J–V curves for hole-only devices based on quasi-2D perovskite films with different spacer cation salts. Inset: Unit cell of Na2Csn−1PbnBr3n+1 perovskites with n = 1 and n = 2. c J–V curves for (BA)2(MA)2Pb4I13 PeLEDs cast at different temperatures. Inset: Scheme illustrating the charge injection and recombination processes in oriented film. d Schematic diagram for photon recycling in PeLEDs and OLEDs. e Formation of submicrometric structures in PeLEDs to enhance the light out-coupling efficiency. f Power dissipation channels of PeLEDs determined by the PEDOT:PSS layer thickness. g Light extraction efficiency changes with equivalent recombination center location for various PEDOT:PSS layer thicknesses. h Device structure of topemission PeLEDs. Panel b is reprinted from ref.<sup>43</sup> with permission from the American Chemical Society. Panel c is reprinted from ref.<sup>139</sup> with permission from Wiley. Panel d is reprinted from ref.<sup>155</sup> with permission from Wiley. Panel e is reprinted from ref.<sup>17</sup> with permission from Springer Nature. Panels f and g are reprinted from ref.<sup>159</sup> with permission from Wiley. Panel h is reprinted from ref.<sup>29</sup> with permission from Springer Nature 

and transport (Fig. 8c). As a result, they achieved efficient quasi-2D PeLEDs with a radiance of 35 W Sr<sup>−1</sup> cm<sup>−2</sup> at 744 nm and an ultralow turn-on voltage of 1 V<sup>139</sup> . Different from the above, Tae-Woo Lee et al. reported a strategy to improve the EQEs of (PEA)2(CH3NH3)n−1PbnBr3n+1 PeLEDs by introducing structure-modulated and randomly oriented 

perovskite emissive layers. The random grain orientations in the quasi-2D perovskite films forced contact between the inorganic layers to improve charge transport and radiative recombination<sup>140</sup> . Consequently, until a clear consensus is reached on the effect of grain orientation on carrier transport, efforts should be intensified. 

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 18 of 26 

### Interfacial engineering 

In quasi-2D PeLEDs, the physical properties of the bottom interlayers affect the properties of the subsequently deposited perovskite layers, e.g., the crystallinities, morphologies, and defect densities<sup>141</sup> . The perovskite-interlayer interfaces have a complex effect on the performance of quasi-2D PeLEDs and deserve further investigation. Interface defects should be responsible for the low PLQYs of quasi-2D perovskite films deposited on top of the interlayers. Therefore, interlayer modification by interfacial engineering is essential. 

The surface wettability of bottom interlayers can affect the crystallization process of the subsequently deposited perovskite films<sup>142</sup> . Zhao et al.<sup>143</sup> showed that an ultrathin (∼1 nm) layer of lithium fluoride (LiF), an ionic compound with strong polarity, can improve the crystal quality and carrier lifetime of perovskite films on top of the polymeric hole transport layer TFB. The perovskite film formed on the TFB/LiF interface showed larger and more defined crystal grains and reduced pinhole density compared with the perovskite film formed on the oxygenplasma-treated TFB surface. The LiF layer acted as a useful template for the growth of high-quality perovskite films and enhanced the device performance for green quasi-2D/3D PeLEDs. Similarly, novel NiOx/LiF HTLs can also avoid luminescence quenching at the surface. The inert LiF intermediate layer (∼1 nm) can effectively passivate the NiOx HTL and suppress the exciton quenching induced by the -OH groups on the surface of NiOx144. Functional passivating moieties (such as Lewis base/acid groups), if grafted on interfacial materials, are likely to induce additional healing of surface defects. Zhou et al. used MoO3-ammonia deposited on PEDOT:PSS in quasi-2D PeLEDs, which not only facilitated hole injection into the perovskite by reducing the contact barrier but also suppressed exciton quenching at the interface<sup>145,146</sup> . 

### Light out-coupling 

In Eq. (3), ηoc represents the fraction of photons extracted from quasi-2D PeLEDs and is generally below 30%. Most photons are trapped inside and lost by generating excess thermal energy<sup>147–149</sup> . Even more detrimental in quasi-2D PeLEDs is the much higher refractive index (~2.6)<sup>16,150</sup> of perovskite materials than their 3D counterparts (~2.0), which limits ηoc as predicted by rayoptics theory<sup>151</sup> . Shi et al.<sup>152</sup> studied the photon loss using systematic optical simulations and showed that quasi-2D PeLEDs could achieve theoretical maximum EQEs of ~20%, which indicated serious photon loss. Generally, the light generated in PeLEDs induces a series of optical modes, including the waveguide mode, surface plasmon polariton (SPP) mode, substrate mode, and out-coupled mode. However, only the out-coupled mode (<20%) is beneficial to the light extraction efficiency (LEE), while the SPP mode (20–30%), waveguide mode (20–30%), substrate 

mode (10–30%), and parasitic absorption (<10%) are consumed within the device<sup>153</sup> . Therefore, efficiently extracting the waveguide, SPP, and substrate modes is critical to further improve the LEE and EQEs of PeLEDs. 

Modulating the morphologies and properties of perovskite films is an important strategy to improve light outcoupling. The perovskite-polymer heterostructure (PPBH) can expand the photon emission escape cone of the emission layer to 32° and reduce the refractive index of the standard halide perovskite. Considering the effects of interference, optical constants, and layer thicknesses, an out-coupling factor of up to ~25% was modeled in quasi2D PeLEDs<sup>16</sup> . More remarkably, lateral photoluminescence experiments showed that light initially confined as modes waveguided in the PPBH layer can propagate up to 80 µm, along with photoluminescence decay beyond 10 μm. The superlong transverse propagation range indicated a possible contribution from photon recycling (PR) (Fig. 8d). Insight into the relatively small Stokes shifts in perovskites suggested significant levels of reabsorption of emitted photons<sup>12,154</sup> . The PR process can assist light out-coupling by randomizing the direction of photon propagation and redirecting photons from trapped to out-coupled modes<sup>155–157</sup> . Cho et al.<sup>158</sup> further proved that PR had a significant contribution to the light out-coupling of PeLEDs. In the current device structure, to maximize the benefits of PR, solutions to reduce the electrode area and different filter structures were proposed. Additionally, Cao et al. modulated the morphology of perovskite films. The emission layer spontaneously formed as distinct submicrometer-scale crystal platelets, increasing the light out-coupling factor to 30%<sup>14</sup> (Fig. 8e). The submicrometric structure inspired us to conclude that patterning perovskite films may further increase ηoc. 

Modifying the device structure is another strategy to achieve high ηoc. An ultrathin PEDOT:PSS (UT-PEDOT: PSS) HTL was reported to enhance the light extraction efficiency of quasi-2D PeLEDs. An increase in the PEDOT: PSS thickness led to a reduction in the portion of the outcoupled mode because the extinction coefficient of PEDOT:PSS is nonzero in the green light region<sup>159</sup> (Fig. 8f, g). In another study that made more sense by Wang’s group, the microcavity effect was employed to enhance light extraction. They used a total-reflection Au bottom electrode accompanied by a semitransparent Au top electrode in a simple top-emission (TE) LED device structure. ηoc thus vastly improved due to the microcavity effect (Fig. 8h), and a high peak EQE of 20.2% in the quasi2D PeLEDs was achieved<sup>29</sup> . More recently, Chen et al.<sup>153</sup> designed a rational device structure that utilizes the nearfield coupling between different emitters via evanescent fields to extract trapped photons. They can efficiently extract the waveguide mode by photon tunneling and evanescent wave absorption. Simultaneously, the SPP 

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 19 of 26 

mode can be utilized via reabsorption or reemission processes. This simple and efficient approach led to highperformance white PeLEDs (EQE of >12%) with muchenhanced LEE (over 50%). For more clarity, we summarize the recent reports in the field of PeLEDs on improving the LEE and corresponding strategies (Table 2). Moreover, the corresponding device structures are also included. Research on improving the ηoc in quasi-2D PeLEDs is just in its infancy. Various valuable strategies have not been effectively used, such as using diffraction gratings, buckling the device and texturing meshed surfaces<sup>160</sup> , prompting researchers to pay more attention to addressing this issue in the future. 

### Stability of quasi-2D PeLEDs 

In addition to improving the efficiency of quasi-2D PeLEDs, it is crucial to address the environmental stability and long-term reliability of materials and devices. Quasi2D perovskites have better stability than their 3D analogs when facing ambient erosion<sup>161</sup> . The main reason is the addition of large organic cations, which provide a protective barrier, isolating the materials from the outside environment and protecting them from moisture, oxygen, etc.<sup>162</sup> . Although the environmental stability of materials can be improved by judicious selection of large organic cations, the situation is quite different when applied to LEDs. Even in the best case, quasi-2D PeLEDs can only work for a few hundred minutes. However, there is still little consensus in the community about the factors limiting the stability of these devices. In this review, we summarize several possible causes. 

Nonradiative Auger recombination is an essential factor for the reduced operational stability of quasi-2D PeLEDs. Quasi-2D PeLEDs suffer from finite maximum brightness and terrible efficiency roll-off, mainly caused by luminescence quenching resulting from nonradiative Auger recombination<sup>163</sup> . We also note that the current density threshold of the Auger recombination in quasi-2D PeLEDs is well below that of their 3D analogs. This can be attributed to the efficient energy transfer in films that exacerbates excessive local carrier concentration and makes them susceptible to Auger recombination. In addition, the large Eb in quasi-2D perovskites also increases the charge-carrier probability of spatial encounters<sup>164</sup> . Therefore, it is urgent to find effective strategies to suppress Auger recombination. Zou et al.<sup>163</sup> increased the width of the QWs to suppress Auger recombination. The real cause of the efficiency roll-off and more effective measures to suppress Auger recombination needs to be further pursued by researchers. 

Field-induced decomposition of spacer cations under a voltage bias is also a crucial factor affecting the stability and lifetime of quasi-2D PeLEDs. Warby et al. attributed the operational instability to the increased mobility of 

||Refs.|layer; LEE: ~25%;<br>16|168|0% to more than 30%<br>17|as); EQE 17.5% (green); LEE from 10–20% to<br>199|8.2% (green)<br>200|4.6% (red/near IR); 1.64 times light<br>201|coupling efficiency of 100% is theoretically<br>159|to 40−50%<br>202|11% for 3D, quasi-3D and quasi-2D,<br>160|effect; EQE 20.2%<br>29|154|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|||missive||rom 2|ntenn|EQE 2|EQE 1|n out-|0–20%|87% 1|cavity||
||cy|thin e||ency f|ptical a|l lens;|t; peak|ntrol; a|from 1|s 42%|micro|s|
||icien|BH;||effici|er o|f-bal|ntras|e co|LEE|ent|nced|ode|
|s|ffi|PP|R)|n|pl|hal|o|ur|);|em|a|m|
|eLED|and e|.9) of|7.6% (I|tractio|ht cou|yer +|ndex c|struct|(green|nhanc|he enh|d SPP|
|s on P|strategy|index (1|rs; EQE 1|; light ex|strate (lig|ction la|th high-i<br>ement|photonic|QE 16%|S; EQE e|ission; t|guide an|
|rt|n|ve|ye|n)|ub|nje|wi<br>nc|;|; E|:PS|em|ve|
|t repo|xtractio|d refracti|itting la|7% (gree|otonic s<br>an70%;|ye ZnO i|le array <br>on enha|recycling<br>|ite PNWs|n PEDOT<br>vel;|y<br>vity top-|both wa|
|n|e|ce|em|0.|ph<br> th|-e|ho<br>ti|n<br>ble|sk|hi<br>cti|ca|t|
|in rece|Light|Redu|Thin|EQE 2|Nano<br>more|Moth|Nano<br>extrac|Photo<br>possi|Perov|Ultrat<br>respe|Micro|Extrac|
|corresponding strategies||-PFO/MoOx/Au|/TPBi/Al|yer/Perovskite/TFB/MoOx/Au|EDOT:PSS/Perovskite/F8/Ca/Ag|OT:PSS/Perovskite/TPBi/LiF/Al|ovskite/TPBi/LiF/Al|l|te PNWs/TPBi/Cathode|vskite/B3PYMPM/LiF/Al|vskite/TFB/MoO3/Au|Perovskite/TPBi/LiF/Al/Ag/LiF/|
|d||FB|ite|la|/P|D|er|/A|ski|ro|ero|e|
|an||BH/T|ovsk|anic|/ITO|O/PE|D/P|i/LiF|erov|S/Pe|W-P|-blu|
|nt||PP|er|rg|2)|Zn|TP|PB|/P|PS|Q|ky|
|me|e|EIE/|D/P|EIE/O|(TiO|eye|Poly-|te/T|:PSS|OT:|IE/M|VK/S|
|nce|ctur|ZO/P|ly-TP|O-P|AAM|oth-|ITO/|ovski|DOT|-PED|O/PE|Ox/P|
|nha|e stru|ITO/M|ITO/Po|ITO/Zn|Epoxy/|ITO/m|NHAs/|VK/Per|ITO/PE|ITO/UT|Au/Zn|ITO/Ni<br>eNCs|
|iency e|Devic|Glass/|Glass/|Glass/|Glass/|Glass/|Glass/|ITO/P|Glass/|Glass/|Glass/|Glass/<br>Red P|
|extraction effic|aterials|1PbnI3n+1 - Polymer|I2.8Br0.2|I3|PbBr3 (Br-Pero)|PbBr3||PbnBr3n+1|fied CsPbBr3 PNW|D, and quasi-2D|1PbnI3n+1|sn−1PbnBr3n+1;|
|ght|g m|FAn−|0.8Pb|FAPb|NH3|d Cs||sn−1|odii|si-3|FAn−|A)2C|
|Li|tin|)2|A|A/|H3|fie|bI3|2C|m|ua|)2|IP|
|2|Emit|(NMA|Cs0.2F|5-AV|BA: C|Modii|MAP|(PEA)|MABr|3D, q|(NMA|(PEA/|
|Table|Year|2018|2018|2018|2019|2019|2019|2020|2020|2020|2020|2021|



Zhang et al. Light: Science & Applications (2021) 10:61 

Page 20 of 26 

ammonium ions, which led to the decomposition of spacer cations<sup>165,166</sup> . The field-induced decomposition of the spacer cations and the subsequent spontaneous conversion from quasi-2D into the corresponding 3D phase were considered another reason for the degradation of the operational stability. The dissociation of surface passivating molecules introduced oxygen and water into the lattice structure, leading to further decomposition of the inorganic octahedral scaffold. Therefore, increasing the interaction between large organic cations and inorganic layers is a feasible strategy to improve the operational stability of quasi-2D PeLEDs. Compared with the monoamine cations in RP configurations, the diamine cations in DJ configurations can form a strong interaction with the inorganic layer. Shang et al.<sup>167</sup> used 1,4-bis(aminomethyl) benzene (BAB), a dicarboxylic acid organic cation with higher dissociation energy, to construct a quasi-2D perovskite with a DJ configuration (Fig. 9a–c). The device showed an operating lifetime of 100 h, almost two orders of magnitude longer than that of the RP configuration. 

This conclusion was well consistent with the previous study by Yuan et al.<sup>117</sup> . 

In addition, some other factors lead to poor device stability. For example, insulating organic long-chain spacer cations result in high internal resistance under a voltage bias, which brings Joule heating and irreversibly destroys the functional layer of the device<sup>168</sup> . Grain orientation can improve the carrier transport in the emissive layers, reducing the internal resistance and Joule heating. Furthermore, field-induced ion migration also affects operational stability. Ion migration can shield the applied electric fields and cause undesirable changes in quasi-2D PeLEDs. In addition, the ions favor locating at interfaces or grain boundaries, leading to changes in interfacial properties and the formation of defect sites. Thus, we note that the degradation mechanisms of quasi2D PeLEDs seem more complicated than those of other LEDs. However, the currently limited exploration cannot completely address this considerable challenge. Therefore, systematic research, an in-depth understanding of the 



<!-- Start of picture text -->
a b d<br>-150-120 PbIPbIPEA-PEA66-BAB-PEA free carrier state<br>free exciton<br>-90<br>state<br>-60<br>-30<br>self-trapped<br>0 exciton state<br>van der Waals gap BAB-FAPbI3 PEA-FAPbI3<br>c 10<br>DEBAB<br>8 DEPEA<br>ground state<br>6<br>4<br>2<br>0 Nuclear coordinate<br>BAB-FAPbI3 PEA-FAPbI3 BAB-FAPbI3 PEA-FAPbI3<br>e 1.2 f<br>1.1<br>Excited n  = 2 n  = 4 n  > 5<br>1.0 state<br>Population<br>0.9 400 nm inversion<br>0.8 Pump<br>0.7<br>0.6 r  = 2 mm ASE<br>0.5 r  = 1 mm Ground<br>state<br>0.4 Antenna Accepter<br>0 2000 4000 6000 8000 10,000<br>Bending cycles<br>Dissociation<br>-2Binding energy (meV A)<br>Dissociation<br>Energy<br>Dissociation energy (meV)<br>Normalized EQE (a.u.)<br><!-- End of picture text -->

Fig. 9 Prospects for quasi-2D perovskite materials and devices. a Schematic crystal structures of BAB-FAPbI3 and PEA-FAPbI3 quasi-2D perovskites. b Calculated binding energies of PbI6-BAB, PbI6-PEA, and PEA-PEA in quasi-2D perovskites. c Calculated molecular dissociation energy of the BAB- and PEA-based quasi-2D perovskites. d Schematic illustration of the self-trapped exciton emission process. e Normalized EQE depending on the 1- and 2-mm bending cycle of flexible quasi-2D PeLEDs doped with FPMAI. Inset: Digital photo of the working flexible quasi-2D PeLEDs doped with FPMAI. f Schematic of the amplified spontaneous emission process realized by population inversion in quasi-2D perovskites. Panels a–c are reprinted from ref.<sup>167</sup> with permission from the AAAS. Panel d is reprinted from ref.<sup>203</sup> with permission from Springer Nature. Panel e is reprinted from ref.<sup>185</sup> with permission from Wiley. Panel f is reprinted from ref.<sup>188</sup> with permission from Wiley 

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 21 of 26 

degradation mechanisms, and continuous exploration of appropriate solutions are necessary. 

## Conclusions and perspectives 

Owing to their excellent optical and electrical properties, quasi-2D perovskites have flourished in LEDs in merely five years, promising to emulate established technologies such as OLEDs and QLEDs. The state-of-the-art quasi-2D PeLEDs reported have achieved EQEs exceeding 20%. The advances in quasi-2D PeLEDs indicate their bright future in the application scenarios of ultrahighdefinition displays, solid-state lighting, optical communications, etc. However, despite these impressive achievements, quasi-2D perovskite materials still have many unsettled issues that hinder their further development and application. Here, we discuss the prospects for the future development of novel quasi-2D perovskite materials/structures and white-light-emitting quasi-2D devices and the potential applications of quasi-2D perovskite emitters in large-area, printable, and flexible electronics as well as quasi-2D perovskite lasers, aiming to shed light on these promising future prospects. 

### Novel quasi-2D perovskite materials and structures 

Searching for large organic cations with excellent chemical and physical properties is the key to exploring new quasi-2D perovskite materials. Large organic cations can introduce additional energy levels, thereby affecting the energy transfer process. In addition, the distortion of the inorganic layer caused by organic cations also influences the luminescence properties of the film. Moreover, the synergistic effect of mixed cations can also achieve an ideal phase distribution and promote significant emission of specific spectra, especially pure red and blue emission. 

The environmental toxicity of perovskite precursor materials remains an urgent issue. As a regulated substance, the presence of lead in PeLEDs raises concerns due to its toxicity; it has a high solubility in water and readily leaches into the environment<sup>169</sup> . Exploring leadfree perovskite systems is thus of great significance. In the past several years, some lead-free perovskites and perovskite derivatives have been developed in other perovskite systems, such as the tin-based perovskite Cs2SnI6111 and halide double perovskite Cs2AgInCl624. However, the performance of lead-free perovskite optoelectronic devices still lags far behind that of their leadbased counterparts. Strategies for improving the device performance include inhibiting tin oxidation, optimizing the structure, and synthesizing novel potential lead-free perovskites<sup>170</sup> . 

In addition to new materials, the exploration of new quasi-2D perovskite structures is also a significant aspect. Compared with the comprehensive studies on RP phase perovskites, few studies on Dion–Jacobson (DJ) phase 

perovskites have been conducted. The diamine cations in DJ configurations can form a strong interaction with the inorganic layer and effectively reduce the distortion of the octahedron, which shows potential for efficient and stable optoelectronic devices<sup>117,167,171</sup> . Other newly developed perovskite structures, e.g., the Aurivillius (AV) phase<sup>172</sup> and the alternating cations in the interlayer space (ACI) phase<sup>74</sup> , display unique photoelectric properties and deserve to be applied in quasi-2D PeLEDs. 

### White-light-emitting quasi-2D PeLEDs 

White color EL is highly desirable for practical applications in lighting and photo-communication. EL devices of white-light emission are generally achieved in three architectures, single emissive layer LEDs, multiple emissive layer LEDs, and hybrid LEDs combined with color down-conversion emitters and blue/ultraviolet (UV) chips<sup>173</sup> . The common single emissive layer white LEDs can be produced by using a single white luminescent material or a set of distinct colored luminaries. A single material with efficient and stable white-light emission is an ideal choice for lighting applications, but it is difficult for a single material to achieve photon emission covering the entire visible spectrum. A promising strategy is to use self-trapped excitons (STEs) for white-light emission<sup>24</sup> . In STE emission, the free excitons quickly relax to the selftrapped states of different energies in the bandgap, yielding white-light emission, which was widely observed in 2D perovskites (Fig. 9d). 

In addition, quasi-2D perovskites offer great opportunities for direct white-light emission<sup>174</sup> . However, the energy transfer in quasi-2D perovskites becomes a limiting factor for white-light emission because the emission tends to be dominated by the smallest bandgap domains, yet a broadband spectrum is required for white-light emission. Incorporating a dual emitting layer or a tandem configuration into quasi-2D PeLEDs may be an effective approach to increase the spatial and physical separation and reduce energy transfer<sup>175</sup> . Many blind areas still exist in white quasi-2D PeLEDs, and more efforts are required to improve the performance of the devices. 

### Technologies for commercial applications 

The improved device efficiency and stability inspired researchers to push quasi-2D PeLEDs into commercialization. Large-area, printable, and flexible manufacturing technologies are thus regarded as the next challenges for large-scale commercialization of quasi-2D PeLEDs<sup>176</sup> . 

Large-area quasi-2D PeLEDs are necessary when considering their applications in next-generation displays, solid-state lighting, and medical imaging. However, severe performance damage arises when increasing the active area. Controlling the formation of a large-area film is a prerequisite for high-performance large-area PeLEDs<sup>177,178</sup> . 

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 22 of 26 

Recently, Wang et al. attributed the performance degradation of a large-area device to the defects found in perovskite films. These defects emerged from thermal convection during solvent evaporation and electronic traps formed during perovskite crystallization<sup>179</sup> . They thus raised a molecular modification strategy that eliminates pinholes in perovskite layers by controlling the dynamics of film formation. Simultaneously, Br species can passivate defects in perovskite films, thereby preventing nonradiative recombination. The quasi-2D perovskite films with high PLQY and nucleation density show unique potential for fabricating large-area LED devices. However, few reports on large-area quasi-2D PeLEDs can be found. Kim et al. developed efficient and large-area benzylammonium (BA)2Csn−1PbnBr3n+1 quasi-2D PeLEDs by using the hotcasting method. They proposed that the thermal energy of the substrate reduced the surface tension between the perovskite precursor solution and the substrate. This hotcasting strategy indeed delivered a perovskite film with high crystallinity and fewer pinholes and cracks. However, the performance of large-area (12.8 cm<sup>2</sup> ) quasi-2D PeLEDs is still far below that of small-area devices reported<sup>180</sup> . We are convinced that large-area quasi-2D PeLEDs will flourish more in the future by precisely controlling the crystallization kinetics. 

With the rise of wearable electronics, curved and foldable displays, etc., the fabrication of flexible devices has also been important research topic<sup>181–183</sup> . Thus, flexible PeLEDs are gradually gaining more attention, mainly covering flexible substrate materials, flexible emitting layer technology, and flexible film encapsulation technology. High-performance flexible PeLEDs have also been fabricated on various lightweight substrates, such as carbon nanotubes and silver nanowires<sup>184,185</sup> . These devices exhibit excellent mechanical robustness with negligible performance loss after up to 10 000 cycles of bending tests<sup>185</sup> . In quasi-2D perovskites, bulky organo-ammonium halide additives may help both passivate surface traps and improve flexibility. Zhao et al. reported flexible quasi-2D PeLEDs by introducing a proper additive to improve both the optoelectronic and mechanical properties of the active film. This strategy yielded highly efficient, robust, and flexible quasi-2D PeLEDs with EQE up to 13% and no degradation after bending for 10 000 cycles at a radius of 2 mm<sup>185</sup> (Fig. 9e). 

Printing technology is an integral part of enabling the scale-up production of quasi-2D PeLEDs. In addition, quasi-2D perovskite films are compatible with lowtemperature solution-based manufacturing techniques, such as inkjet, roll-to-roll, and 3D printing, also providing great potential in large-area and flexible electronics. To date, among the patterning methods of perovskite materials, inkjet printing is particularly attractive due to its noncontact process, direct writing and plate making, mask-free 

nature, and flexible substrate<sup>186,187</sup> . Recently, Jia et al. used inkjet printing technology to prepare a quasi-2D perovskite embedded in polymers and successfully constructed luminous patterns/pictures on the polymer substrate. The composite combined the inherent stability of the quasi-2D perovskite and the outstanding barrier property of polyvinyl chloride (PVC), obtaining excellent resistance to abrasion, air, water, light irradiation, etc., and had broad prospects for application in large-area fluorescent billboards<sup>187</sup> . The available strategies for the scale-up production of large-area/flexible/printable quasi-2D PeLEDs are still limited, which poses significant challenges for commercial applications. Therefore, extensive research should be conducted on manufacturing technologies prior to large-scale commercial applications. 

### Quasi-2D perovskite lasers 

Amplified spontaneous emission (ASE) and optically pumped pulsed lasing with low ASE and lasing thresholds have been realized with a wide range of perovskite gain media. Quasi-2D perovskites with unique properties, e.g., good stability, high Eb, and natural QW architectures, are better gain media than 3D perovskites for laser applications<sup>77,188–191</sup> . The effective ASE of a quasi-2D perovskite is relative to its carriers accumulated by energy transfer, which achieves higher population inversion (Fig. 9f). An optically pumped (NMA)2(FA)Pb2Br7 quasi-2D perovskite laser with a low ASE threshold carrier density (ρASE = 6.3 × 10<sup>17</sup> cm<sup>−3</sup> ) under threshold fluence (8.5 ± 0.5 μJ cm<sup>−2</sup> ) was demonstrated, and this density was two times smaller than that of the 3D CH3NH3PbI3 perovskite<sup>192</sup> . Since then, optically pumped quasi-2D perovskite lasers have been gradually reported. However, electrically pumped lasers have not yet been reported. The behavior of quasi-2D perovskites under the intense electrical excitation required for electrically pumped lasing remains unexplored. Recently, Qin et al. indicated that singlet–triplet exciton annihilation (STA) is a possible intrinsic mechanism causing lasing death. By using a distributed-feedback cavity with a high-quality factor and applying triplet management strategies, they achieved stable green quasi-2D perovskite lasers under continuouswave lasing (CW lasing) in the air at room temperature. CW lasing is popular for practical applications in highdensity integrated optoelectronic devices and is a crucial step towards electrically pumped lasers, which would pave the way to realizing future current-injection perovskite lasers<sup>193</sup> . 

To conclude, we have summarized the fundamental requirements for approaching high-performance quasi2D PeLEDs from two aspects, the materials and devices. Simultaneously, we have highlighted some key challenges ahead in quasi-2D PeLEDs, e.g., high-performance pure red and blue PeLEDs, long-term operational stability, and 

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 23 of 26 

environmental safety. In our opinion, an interdisciplinary approach may be proposed to overcome these challenges and create large-scale commercial routes. Finally, we have discussed promising research directions and innovations in developing high-performance and stable quasi-2D materials and devices in the near future. We believe that quasi-2D PeLEDs will have unique advantages in future commercial applications. We hope that our review article will provide broad and comprehensive perspectives for researchers to deepen the development of quasi-2D perovskite materials and devices. 

#### Acknowledgements 

We acknowledge financial support from the National Natural Science Foundation of China (Nos. 21771114, 91956130) and the Natural Science Foundation of Tianjin (18YFZCGX00580). M. Yuan acknowledges financial support from Distinguished Young Scholars of Tianjin (No. 19JCJQJC62000). 

#### Conflict of interest 

The authors declare no competing interests. 

Received: 6 December 2020 Revised: 28 January 2021 Accepted: 24 February 2021 



#### References 

1. Okumura, H., Misawa, S. & Yoshida, S. Epitaxial growth of cubic and hexagonal GaN on GaAs by gas-source molecular-beam epitaxy. Appl. Phys. Lett. 59, 1058–1060 (1991). 

2. Duffy, M. T. et al. Epitaxial growth and piezoelectric properties of A1N, GaN, and GaAs on sapphire or spinel. J. Electron. Mater. 2, 359–372 (1973). 

3. Wu, T. L. et al. Diboron compound-based organic light-emitting diodes with high efficiency and reduced efficiency roll-off. Nat. Photonics 12, 235–240 (2018). 

4. Baldo, M. A. et al. Highly efficient phosphorescent emission from organic electroluminescent devices. Nature 395, 151–154 (1998). 

5. Dai, X. L. et al. Solution-processed, high-performance light-emitting diodes based on quantum dots. Nature 515, 96–99 (2014). 

6. Quan, L. N. et al. Perovskites for next-generation optical sources. Chem. Rev. 119, 7444–7477 (2019). 

7. He, T. W. et al. Structured perovskite light absorbers for efficient and stable photovoltaics. Adv. Mater. 32, 1903937 (2020). 

8. He, T. W. et al. Reduced-dimensional perovskite photovoltaics with homogeneous energy landscape. Nat. Commun. 11, 1672 (2020). 

9. Wang, L. et al. A chiral reduced-dimension perovskite for an efficient flexible circularly polarized light photodetector. Angew. Chem. Int. Ed. 59, 6442–6450 (2020). 

10. Huang, Y. M. et al. A-site cation engineering for highly efficient MAPbI3 single-crystal X-ray detector. Angew. Chem. Int. Ed. 58, 17834–17842 (2019). 

11. Tan, Z. K. et al. Bright light-emitting diodes based on organometal halide perovskite. Nat. Nanotechnol. 9, 687–692 (2014). 

12. Xu, W. D. et al. Rational molecular passivation for high-performance perovskite light-emitting diodes. Nat. Photonics 13, 418–424 (2019). 

13. Zhao, X. F. et al. Opportunities and challenges in perovskite light-emitting devices. ACS Photonics 5, 3866–3875 (2018). 

14. Li, G. R. et al. Efficient light-emitting diodes based on nanocrystalline perovskite in a dielectric polymer matrix. Nano Lett. 15, 2640–2644 (2015). 

15. Chiba, T. et al. Anion-exchange red perovskite quantum dots with ammonium iodine salts for highly efficient light-emitting devices. Nat. Photonics 12, 681–687 (2018). 

16. Zhao, B. D. et al. High-efficiency perovskite-polymer bulk heterostructure light-emitting diodes. Nat. Photonics 12, 783–789 (2018). 

17. Cao, Y. et al. Perovskite light-emitting diodes based on spontaneously formed submicrometre-scale structures. Nature 562, 249–253 (2018). 

18. Lin, K. B. et al. Perovskite light-emitting diodes with external quantum efficiency exceeding 20 per cent. Nature 562, 245–248 (2018). 

19. Yong, Z. J. et al. Doping-Enhanced short-range order of perovskite nanocrystals for near-unity violet luminescence quantum yield. J. Am. Chem. Soc. 140, 9942–9951 (2018). 

20. Koscher, B. A. et al. Essentially trap-free CsPbBr3 colloidal nanocrystals by postsynthetic thiocyanate surface treatment. J. Am. Chem. Soc. 139, 6566–6569 (2017). 

21. Shan, Q. S. et al. High performance metal halide perovskite light-emitting diode: from material design to device optimization. Small 13, 1701770 (2017). 

22. Kim, Y. H. et al. Comprehensive defect suppression in perovskite nanocrystals for high-efficiency light-emitting diodes. Nat. Photonics https://doi.org/ 10.1038/s41566-020-00732-4 (2021). 

23. Bao, C. X. et al. Bidirectional optical signal transmission between two identical devices using perovskite diodes. Nat. Electron. 3, 156–164 (2020). 

24. Luo, J. J. et al. Efficient and stable emission of warm-white light from leadfree halide double perovskites. Nature 563, 541–545 (2018). 

25. Cheng, L. et al. Multiple-quantum-well perovskites for high-performance light-emitting diodes. Adv. Mater. 32, 1904163 (2020). 

26. Jiang, Y. Z. et al. Reduced-dimensional α-CsPbX3 perovskites for efficient and stable photovoltaics. Joule 2, 1356–1368 (2018). 

27. Calabrese, J. et al. Preparation and characterization of layered lead halide compounds. J. Am. Chem. Soc. 113, 2328–2330 (1991). 

28. Mitzi, D. B. et al. Conducting tin halides with a layered organic-based perovskite structure. Nature 369, 467–469 (1994). 

29. Miao, Y. F. et al. Microcavity top-emission perovskite light-emitting diodes. Light. Sci. Appl. 9, 89 (2020). 

30. Yuan, M. J. et al. Perovskite energy funnels for efficient light-emitting diodes. Nat. Nanotechnol. 11, 872–877 (2016). 

31. Kim, Y. H. et al. Multicolored organic/inorganic hybrid perovskite lightemitting diodes. Adv. Mater. 27, 1248–1254 (2015). 

32. Wang, J. P. et al. Interfacial control toward efficient and low-voltage perovskite light-emitting diodes. Adv. Mater. 27, 2311–2316 (2015). 

33. Zhang, F. J. et al. Efficient blue perovskite light-emitting diodes boosted by 2D/3D energy cascade channels. Adv. Funct. Mater. 30, 2001732 (2020). 

34. Hong, X., Ishihara, T. & Nurmikko, A. V. Photoconductivity and electroluminescence in lead iodide based natural quantum well structures. Solid State Commun. 84, 657–661 (1992). 

35. Era, M. et al. Organic-inorganic heterostructure electroluminescent device using a layered perovskite semiconductor (C6H5C2H4NH3)2PbI4. Appl. Phys. Lett. 65, 676–678 (1994). 

36. Kumagai, M. & Takagahara, T. Excitonic and nonlinear-optical properties of dielectric quantum-well structures. Phys. Rev. B 40, 12359 (1989). 

37. Tanaka, K. et al. Image charge effect on two-dimensional excitons in an inorganic-organic quantum-well crystal. Phys. Rev. B 71, 045312 (2005). 

38. Zhang, S. T. et al. Efficient red perovskite light-emitting diodes based on solution-processed multiple quantum wells. Adv. Mater. 29, 1606600 (2017). 

39. Traore, B. et al. Composite nature of layered hybrid perovskites: assessment on quantum and dielectric confinements and band alignment. ACS Nano 12, 3321–3332 (2018). 

40. Katan, C., Mercier, N. & Even, J. Quantum and dielectric confinement effects in lower-dimensional hybrid perovskite semiconductors. Chem. Rev. 119, 3140–3192 (2019). 

41. Quan, L. N. et al. Ligand-stabilized reduced-dimensionality perovskites. J. Am. Chem. Soc. 138, 2649–2655 (2016). 

42. Wang, N. N. et al. Perovskite light-emitting diodes based on solutionprocessed self-organized multiple quantum wells. Nat. Photonics 10, 699–704 (2016). 

43. Wu, C. et al. Alternative type two-dimensional-three-dimensional lead halide perovskite with inorganic sodium ions as a spacer for high-performance light-emitting diodes. ACS Nano 13, 1645–1654 (2019). 

44. He, Z. F. et al. High-efficiency red light-emitting diodes based on multiple quantum wells of phenylbutylammonium-cesium lead iodide perovskites. ACS Photonics 6, 587–594 (2019). 

45. Chu, Z. M. et al. Large cation ethylammonium incorporated perovskite for efficient and spectra stable blue light-emitting diodes. Nat. Commun. 11, 4165 (2020). 

46. Mitzi, D. B. et al. Conducting layered organic-inorganic halides containing <110>-oriented perovskite sheets. Science 267, 1473–1476 (1995). 

47. Mitzi, D. B. In Progress in Inorganic Chemistry (ed. Karlin, K. D.) 1–121 (1999). 

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 24 of 26 

48. Liang, H. Y. et al. High color purity lead-free perovskite light-emitting diodes via Sn stabilization. Adv. Sci. 7, 1903213 (2020). 

49. Sichert, J. A. et al. Quantum size effect in organometal halide perovskite nanoplatelets. Nano Lett. 15, 6521–6527 (2015). 

50. Ortiz-Cervantes, C., Carmona-Monroy, P. & Solis-Ibarra, D. Two-dimensional halide perovskites in solar cells: 2D or not 2D? ChemSusChem 12, 1560–1575 (2019). 

51. Quan, L. N. et al. Perovskites for light emission. Adv. Mater. 30, 1801996 (2018). 

52. Ishihara, T., Takahashi, J. & Goto, T. Exciton state in two-dimensional perovskite semiconductor (C10H21NH3)2PbI4. Solid State Commun. 69, 933–936 (1989). 

53. Ishihara, T., Takahashi, J. & Goto, T. Optical properties due to electronic transitions in two-dimensional semiconductors (CnH2n+1NH3)2PbI4. Phys. Rev. B 42, 11099 (1990). 

54. Stoumpos, C. C. et al. High members of the 2D Ruddlesden-Popper halide perovskites: synthesis, optical properties, and solar cells of (CH3(CH2)3NH3)2(CH3NH3)4Pb5I16. Chem 2, 427–440 (2017). 

55. Gan, L. et al. Effects of organic cation length on exciton recombination in two-dimensional layered lead iodide hybrid perovskite crystals. J. Phys. Chem. Lett. 8, 5177–5183 (2017). 

56. Ni, L. M. et al. Real-time observation of exciton-phonon coupling dynamics in self-assembled hybrid perovskite quantum wells. ACS Nano 11, 10834–10843 (2017). 

57. Soe, C. M. M. et al. Structural and thermodynamic limits of layer thickness in 2D halide perovskites. Proc. Natl Acad. Sci. USA 116, 58–66 (2019). 

58. Yaffe, O. et al. Excitons in ultrathin organic-inorganic perovskite crystals. Phys. Rev. B 92, 045414 (2015). 

59. Feldmann, S. et al. Photodoping through local charge carrier accumulation in alloyed hybrid perovskites for highly efficient luminescence. Nat. Photonics 14, 123–128 (2020). 

60. Chen, X. H. et al. Impact of layer thickness on the charge carrier and spin coherence lifetime in two-dimensional layered perovskite single crystals. ACS Energy Lett. 3, 2273–2279 (2018). 

61. Delport, G. et al. Exciton-exciton annihilation in two-dimensional halide perovskites at room temperature. J. Phys. Chem. Lett. 10, 5153–5159 (2019). 

62. Xing, G. C. et al. Transcending the slow bimolecular recombination in lead-halide perovskites for electroluminescence. Nat. Commun. 8, 14558 (2017). 

63. Byun, J. et al. Efficient visible quasi-2D perovskite light-emitting diodes. Adv. Mater. 28, 7515–7520 (2016). 

64. Quintero-Bermudez, R. et al. Compositional and orientational control in metal halide perovskites of reduced dimensionality. Nat. Mater. 17, 900–907 (2018). 

65. Jeon, N. J. et al. Solvent engineering for high-performance inorganic-organic hybrid perovskite solar cells. Nat. Mater. 13, 897–903 (2014). 

66. Soe, C. M. M. et al. Understanding film formation morphology and orientation in high member 2D Ruddlesden-Popper perovskites for high‐efficiency solar cells. Adv. Energy Mater. 8, 1700979 (2018). 

67. Zhang, X. et al. Phase transition control for high performance RuddlesdenPopper perovskite solar cells. Adv. Mater. 30, 1707166 (2018). 

68. Venkatesan, N. R., Labram, J. G. & Chabinyc, M. L. Charge-carrier dynamics and crystalline texture of layered Ruddlesden-Popper hybrid lead iodide perovskite thin films. ACS Energy Lett. 3, 380–386 (2018). 

69. Yu, J. C. et al. Improving the stability and performance of perovskite lightemitting diodes by thermal annealing treatment. Adv. Mater. 28, 6906–6913 (2016). 

70. Hamill, J. C. Jr., Schwartz, J. & Loo, Y. L. Influence of solvent coordination on hybrid organic-inorganic perovskite formation. ACS Energy Lett. 3, 92–97 (2018). 

71. Zhao, L. F. et al. In situ preparation of metal halide perovskite nanocrystal thin films for improved light-emitting devices. ACS Nano 11, 3957–3964 (2017). 

72. Xiao, Z. G. et al. Engineering perovskite nanocrystal surface termination for light-emitting diodes with external quantum efficiency exceeding 15%. Adv. Funct. Mater. 29, 1807284 (2019). 

73. Xiao, Z. G. et al. Efficient perovskite light-emitting diodes featuring nanometre-sized crystallites. Nat. Photonics 11, 108–115 (2017). 

74. Soe, C. M. M. et al. New type of 2D perovskites with alternating cations in the interlayer space, (C(NH2)3)(CH3NH3)nPbnI3n+1: structure, properties, and photovoltaic performance. J. Am. Chem. Soc. 139, 16297–16309 (2017). 

75. Quan, L. N. et al. Tailoring the energy landscape in quasi-2D halide perovskites enables efficient green-light emission. Nano Lett. 17, 3701–3709 (2017). 

76. Yantara, N. et al. Designing efficient energy funneling kinetics in Ruddlesdenpopper perovskites for high-performance light-emitting diodes. Adv. Mater. 30, 1800818 (2018). 

77. Lei, L. et al. Efficient energy funneling in quasi-2D perovskites: from light emission to lasing. Adv. Mater. 32, 1906571 (2020). 

78. Ban, M. Y. et al. Solution-processed perovskite light emitting diodes with efficiency exceeding 15% through additive-controlled nanostructure tailoring. Nat. Commun. 9, 3892 (2018). 

79. Quan, L. N. et al. Edge stabilization in reduced-dimensional perovskites. Nat. Commun. 11, 170 (2020). 

80. Gao, C. C. et al. Multifunctional naphthol sulfonic salt incorporated in leadfree 2D tin halide perovskite for red light-emitting diodes. ACS Photonics 7, 1915–1922 (2020). 

81. Yang, X. L. et al. Efficient green light-emitting diodes based on quasi-twodimensional composition and phase engineered perovskite with surface passivation. Nat. Commun. 9, 570 (2018). 

82. Lee, S. et al. Control of interface defects for efficient and stable quasi-2D Perovskite light-emitting diodes using nickel oxide hole injection layer. Adv. Sci. 5, 1801350 (2018). 

83. Wang, Z. B. et al. Manipulating the trade-off between quantum yield and electrical conductivity for high-brightness quasi-2D perovskite light-emitting diodes. Adv. Funct. Mater. 28, 1804187 (2018). 

84. Tian, Y. et al. Highly efficient spectrally stable red perovskite light‐emitting diodes. Adv. Mater. 30, 1707093 (2018). 

85. Meng, F. Y. et al. Co-interlayer engineering toward efficient green quasi-twodimensional perovskite light-emitting diodes. Adv. Funct. Mater. 30, 1910167 (2020). 

86. Cheng, T. et al. Stoichiometry control for the tuning of grain passivation and domain distribution in green quasi-2D metal halide perovskite films and light-emitting diodes. Adv. Funct. Mater. 30, 2001816 (2020). 

87. Series, B. T. Parameter Values for Ultra-high Definition Television Systems for Production and International Programme Exchange (2012). 

88. Kumar, S. et al. Efficient blue electroluminescence using quantum-confined two-dimensional perovskites. ACS Nano 10, 9720–9729 (2016). 

89. Wang, Q. et al. Efficient sky-blue perovskite light-emitting devices based on ethylammonium bromide induced layered perovskites. ACS Appl. Mater. Interfaces 9, 29901–29906 (2017). 

90. Cheng, L. et al. Sky-blue perovskite light-emitting diodes based on quasitwo-dimensional layered perovskites. Chin. Chem. Lett. 28, 29–31 (2017). 

91. Chen, H. T. et al. Sodium ion modifying in situ fabricated CsPbBr3 nanoparticles for efficient perovskite light emitting diodes. Adv. Optic. Mater. 7, 1900747 (2019). 

92. Chen, P. et al. Charge-transfer versus energy-transfer in quasi-2D perovskite light emitting diodes. Nano energy 50, 615–622 (2018). 

93. Protesescu, L. et al. Nanocrystals of cesium lead halide perovskites (CsPbX3, X= Cl, Br, and I): novel optoelectronic materials showing bright emission with wide color gamut. Nano Lett. 15, 3692–3696 (2015). 

94. Song, J. Z. et al. Quantum dot light-emitting diodes based on inorganic perovskite cesium lead halides (CsPbX3). Adv. Mater. 27, 7162–7167 (2015). 

95. Li, G. R. et al. Highly efficient perovskite nanocrystal light-emitting diodes enabled by a universal crosslinking method. Adv. Mater. 28, 3528–3534 (2016). 

96. Dutta, A. et al. Near-Unity photoluminescence quantum efficiency for all CsPbX3 (X= Cl, Br, and I) perovskite nanocrystals: a generic synthesis approach. Angew. Chem. Int. Ed. 58, 5552–5556 (2019). 

97. Li, Z. C. et al. Modulation of recombination zone position for quasi-twodimensional blue perovskite light-emitting diodes with efficiency exceeding 5%. Nat. Commun. 10, 1027 (2019). 

98. Vashishtha, P. et al. High efficiency blue and green light-emitting diodes using Ruddlesden-Popper inorganic mixed halide perovskites with butylammonium interlayers. Chem. Mater. 31, 83–89 (2019). 

99. Yao, E. P. et al. High-brightness blue and white leds based on inorganic perovskite nanocrystals and their composites. Adv. Mater. 29, 1606859 (2017). 

100. Vashishtha, P. & Halpert, J. E. Field-driven ion migration and color instability in red-emitting mixed halide perovskite nanocrystal light-emitting diodes. Chem. Mater. 29, 5965–5973 (2017). 

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 25 of 26 

101. Brivio, F., Caetano, C. & Walsh, A. Thermodynamic origin of photoinstability in the CH3NH3Pb(I1-xBrx)3 hybrid halide perovskite alloy. J. Phys. Chem. Lett. 7, 1083–1087 (2016). 

102. Wang, Q. et al. Efficient sky-blue perovskite light-emitting diodes via photoluminescence enhancement. Nat. Commun. 10, 5633 (2019). 

103. Yuan, Y. B. & Huang, J. S. Ion migration in organometal trihalide perovskite and its impact on photovoltaic efficiency and stability. Acc. Chem. Res. 49, 286–293 (2016). 

104. Ma, D. X. et al. Chloride insertion-immobilization enables bright, narrowband, and stable blue-emitting perovskite diodes. J. Am. Chem. Soc. 142, 5126–5134 (2020). 

105. Zhao, J. J. et al. Strained hybrid perovskite thin films and their impact on the intrinsic stability of perovskite solar cells. Sci. Adv. 3, eaao5616 (2017). 

106. Kubicki, D. J. et al. Cation dynamics in mixed-cation (MA)x(FA)1-xPbI3 hybrid perovskites from solid-state NMR. J. Am. Chem. Soc. 139, 10055–10061 (2017). 

107. Philippe, B. et al. Chemical distribution of multiple cation (Rb<sup>+</sup> , Cs<sup>+</sup> , MA<sup>+</sup> , and FA<sup>+</sup> ) perovskite materials by photoelectron spectroscopy. Chem. Mater. 29, 3589–3596 (2017). 

108. Gao, L. L. et al. Improved environmental stability and solar cell efficiency of (MA, FA) PbI3 perovskite using a wide-band-gap 1D thiazolium lead iodide capping layer strategy. ACS Energy Lett. 4, 1763–1769 (2019). 

109. Linaburg, M. R. et al. Cs1-xRbxPbCl3 and Cs1-xRbxPbBr3 solid solutions: understanding octahedral tilting in lead halide perovskites. Chem. Mater. 29, 3507–3514 (2017). 

110. Jiang, Y. Z. et al. Spectra stable blue perovskite light-emitting diodes. Nat. Commun. 10, 1868 (2019). 

111. Lanzetta, L. et al. Two-dimensional organic tin halide perovskites with tunable visible emission and their use in light-emitting devices. ACS Energy Lett. 2, 1662–1668 (2017). 

112. Yuan, F. L. et al. Color-pure red light-emitting diodes based on twodimensional lead-free perovskites. Sci. Adv. 6, eabb0253 (2020). 

113. Gauthron, K. et al. Optical spectroscopy of two-dimensional layered (C6H5C2H4-NH3)2-PbI4 perovskite. Opt. Express 18, 5912–5919 (2010). 

114. Gong, X. W. et al. Electron-phonon interaction in efficient perovskite blue emitters. Nat. Mater. 17, 550–556 (2018). 

115. Yantara, N. et al. Designing the perovskite structural landscape for efficient blue emission. ACS Energy Lett. 5, 1593–1600 (2020). 

116. Jin, Y. et al. Synergistic effect of dual ligands on stable blue quasi-2D perovskite light-emitting diodes. Adv. Funct. Mater. 30, 1908339 (2020). 

117. Yuan, S. et al. Optimization of low-dimensional components of quasi-2D perovskite films for deep-blue light-emitting diodes. Adv. Mater. 31, 1904319 (2019). 

118. Leung, T. L. et al. Mixed spacer cation stabilization of blue-emitting n = 2 Ruddlesden-Popper organic-inorganic halide perovskite films. Adv. Optic. Mater. 8, 1901679 (2020). 

119. Chang, J. et al. Enhanced performance of red perovskite light-emitting diodes through the dimensional tailoring of perovskite multiple quantum wells. J. Phys. Chem. Lett. 9, 881–886 (2018). 

120. Ren, Z. W. et al. High-performance blue perovskite light-emitting diodes enabled by efficient energy transfer between coupled quasi-2D perovskite layers. Adv. Mater. 33, 2005570 (2021). 

121. Xing, J. et al. Color-stable highly luminescent sky-blue perovskite lightemitting diodes. Nat. Commun. 9, 3541 (2018). 

122. Wang, Y. K. et al. Chelating-agent-assisted control of CsPbBr3 quantum well growth enables stable blue perovskite emitters. Nat. Commun. 11, 3674 (2020). 

123. Yang, Z. Y. et al. Low-dimensionality perovskites yield high electroluminescence. Sci. Bull. 65, 1057–1060 (2020). 

124. Lee, S. J. et al. Versatile defect passivation methods for metal halide perovskite materials and their application to light-emitting devices. Adv. Mater. 31, 1805244 (2019). 

125. Shen, H. B. et al. Visible quantum dot light-emitting diodes with simultaneous high brightness and efficiency. Nat. Photonics 13, 192–197 (2019). 

126. Chen, Y. N. et al. 2D Ruddlesden-Popper perovskites for optoelectronics. Adv. Mater. 30, 1703487 (2018). 

127. Yu, J. C. et al. Effect of perovskite film morphology on device performance of perovskite light-emitting diodes. Nanoscale 11, 1505–1514 (2019). 

128. Kim, Y. H., Kim, J. S. & Lee, T. W. Strategies to improve luminescence efficiency of metal-halide perovskites and light-emitting diodes. Adv. Mater. 31, 1804595 (2019). 

129. Sum, T. C., Righetto, M. & Lim, S. S. Quo vadis, perovskite emitters? J. Chem. Phys. 152, 130901 (2020). 

130. Liu, X. K. & Gao, F. Organic-inorganic hybrid Ruddlesden-Popper perovskites: an emerging paradigm for high-performance light-emitting diodes. J. Phys. Chem. Lett. 9, 2251–2258 (2018). 

131. Chin, X. Y. et al. Self-assembled hierarchical nanostructured perovskites enable highly efficient LEDs via an energy cascade. Energy Environ. Sci. 11, 1770–1778 (2018). 

132. Gao, L. et al. Efficient near-infrared light-emitting diodes based on quantum dots in layered perovskite. Nat. Photonics 14, 227–233 (2020). 

133. Yang, X. L. et al. Effects of organic cations on the structure and performance of quasi-two-dimensional perovskite-based light-emitting diodes. J. Phys. Chem. Lett. 10, 2892–2897 (2019). 

134. Qin, C. J. et al. Triplet management for efficient perovskite light-emitting diodes. Nat. Photonics 14, 70–75 (2020). 

135. Han, D. B. et al. Efficient light-emitting diodes based on in situ fabricated FAPbBr3 nanocrystals: the enhancing role of the ligand-assisted reprecipitation process. ACS Nano 12, 8808–8816 (2018). 

136. Yu, X. C. et al. Tailoring the surface morphology and phase distribution for efficient perovskite electroluminescence. J. Phys. Chem. Lett. 11, 5877–5882 (2020). 

137. Liu, Y. et al. Efficient blue light-emitting diodes based on quantum-confined bromide perovskite nanostructures. Nat. Photonics 13, 760–764 (2019). 

138. Yantara, N. et al. Regulating vertical domain distribution in RuddlesdenPopper perovskites for electroluminescence devices. J. Phys. Chem. Lett. 10, 7949–7955 (2019). 

139. Tsai, H. et al. Stable light-emitting diodes using phase-pure RuddlesdenPopper layered perovskites. Adv. Mater. 30, 1704217 (2018). 

140. Lee, H. D. et al. Efficient Ruddlesden-Popper perovskite light-emitting diodes with randomly oriented nanocrystals. Adv. Funct. Mater. 29, 1901225 (2019). 

141. Zhang, L. Q. et al. Ultra-bright and highly efficient inorganic based perovskite light-emitting diodes. Nat. Commun. 8, 15640 (2017). 

142. Bi, C. et al. Non-wetting surface-driven high-aspect-ratio crystalline grain growth for efficient hybrid perovskite solar cells. Nat. Commun. 6, 7747 (2015). 

143. Zhao, B. D. et al. Efficient light-emitting diodes from mixed-dimensional perovskites on a fluoride interface. Nat. Electron. 3, 704–710 (2020). 

144. Wang, K. H. et al. Efficient and color-tunable quasi-2D CsPbBrxCl3-x perovskite blue light-emitting diodes. ACS Photonics 6, 667–676 (2019). 

145. Meng, Y. et al. High performance and stable all-inorganic perovskite light emitting diodes by reducing luminescence quenching at PEDOT: PSS/perovskites interface. Org. Electron. 64, 47–53 (2019). 

146. Zhou, Y. M. et al. Improved efficiency of perovskite light-emitting diodes using a three-step spin-coated CH3NH3PbBr3 emitter and a PEDOT: PSS/ MoO3-ammonia composite hole transport layer. Micromachines 10, 459 (2019). 

147. Hong, K. & Lee, J. L. Review paper: recent developments in light extraction technologies of organic light emitting diodes. Electron. Mater. Lett. 7, 77–91 (2011). 

148. Salehi, A. et al. Recent advances in OLED optical design. Adv. Funct. Mater. 29, 1808803 (2019). 

149. Kim, Y. H. et al. Molecular-scale strategies to achieve high efficiency and low efficiency roll-off in simplified solution-processed organic light-emitting diodes. Adv. Funct. Mater. 30, 2005292 (2020). 

150. Chen, C. W. et al. Optical properties of organometal halide perovskite thin films and general device structure design rules for perovskite single and tandem solar cells. J. Mater. Chem. A 3, 9152–9159 (2015). 

151. Lin, T. A. et al. Sky-blue organic light emitting diode with 37% external quantum efficiency using thermally activated delayed fluorescence from spiroacridine-triazine hybrid. Adv. Mater. 28, 6976–6983 (2016). 

152. Shi, X. B. et al. Optical energy losses in organic-inorganic hybrid perovskite light-emitting diodes. Adv. Optic. Mater. 6, 1800667 (2018). 

153. Chen, Z. M. et al. Utilization of trapped optical modes for white perovskite light-emitting diodes with efficiency over 12%. Joule https://doi.org/10.1016/j. joule.2020.12.008 (2021). 

154. Motti, S. G. et al. Heterogeneous photon recycling and charge diffusion enhance charge transport in quasi-2D lead-halide perovskite films. Nano Lett. 19, 3953–3960 (2019). 

155. Stranks, S. D. et al. The physics of light emission in halide perovskite devices. Adv. Mater. 31, 1803336 (2019). 

Zhang et al. Light: Science & Applications (2021) 10:61 

Page 26 of 26 

156. Bi, W. T. et al. Efficient quasi-two-dimensional perovskite light-emitting diodes with improved multiple quantum well structure. ACS Appl. Mater. Interfaces 12, 1721–1727 (2020). 

157. Zou, Y. T. et al. Boosting perovskite light-emitting diode performance via tailoring interfacial contact. ACS Appl. Mater. Interfaces 10, 24320–24326 (2018). 

158. Cho, C. et al. The role of photon recycling in perovskite light-emitting diodes. Nat. Commun. 11, 611 (2020). 

159. Lu, J. X. et al. Ultrathin PEDOT: PSS enables colorful and efficient perovskite light-emitting diodes. Adv. Sci. 7, 2000689 (2020). 

160. Ziebarth, J. M. et al. Extracting light from polymer light-emitting diodes using stamped bragg gratings. Adv. Funct. Mater. 14, 451–456 (2004). 

161. Cheng, Y. H. et al. Enhanced light outcoupling in a thin film by texturing meshed surfaces. Appl. Phys. Lett. 90, 091102 (2007). 

162. Koo, W. H. et al. Light extraction from organic light-emitting diodes enhanced by spontaneously formed buckles. Nat. Photonics 4, 222–226 (2010). 

163. Zou, W. et al. Minimising efficiency roll-off in high-brightness perovskite lightemitting diodes. Nat. Commun. 9, 608 (2018). 

164. Jiang, Y. Z. et al. Reducing the impact of Auger recombination in quasi-2D perovskite light-emitting diodes. Nat. Commun. 12, 336 (2021). 

165. Warby, J. H. et al. Revealing factors influencing the operational stability of perovskite light-emitting diodes. ACS Nano 14, 8855–8865 (2020). 

166. Shang, Y. Q. et al. Quasi-2D inorganic CsPbBr3 perovskite for efficient and stable light-emitting diodes. Adv. Funct. Mater. 28, 1801193 (2018). 

167. Shang, Y. Q. et al. Highly stable hybrid perovskite light-emitting diodes based on Dion-Jacobson structure. Sci. Adv. 5, eaaw8072 (2019). 

168. Zhao, L. F. et al. Improved outcoupling efficiency and stability of perovskite light-emitting diodes using thin emitting layers. Adv. Mater. 31, 1805836 (2019). 

169. Babayigit, A. et al. Toxicity of organometal halide perovskite solar cells. Nat. Mater. 15, 247–251 (2016). 

170. Lu, S. H. et al. Accelerated discovery of stable lead-free hybrid organicinorganic perovskites via machine learning. Nat. Commun. 9, 3405 (2018). 

171. Qiu, J. J. et al. Stable, efficient near-infrared light-emitting diodes enabled by α/δ phase modulation. J. Phys. Chem. Lett. 10, 2101–2107 (2019). 

172. Kendall, K. R. et al. Recent developments in oxide ion conductors: aurivillius phases. Chem. Mater. 8, 642–649 (1996). 

173. Chen, J. W. et al. Efficient and bright white light-emitting diodes based on single-layer heterophase halide perovskites. Nat. Photonics https://doi.org/ 10.1038/s41566-020-00743-1 (2020). 

174. Shen, P. F., Vogt, T. & Lee, Y. Pressure-induced enhancement of broad-band white light emission in butylammonium lead bromide. J. Phys. Chem. Lett. 11, 4131–4137 (2020). 

175. Jamaludin, N. F. et al. White electroluminescence from perovskite-organic heterojunction. ACS Energy Lett. 5, 2690–2697 (2020). 

176. Ye, F. et al. Low-temperature soft-cover deposition of uniform large-scale perovskite films for high-performance solar cells. Adv. Mater. 29, 1701440 (2017). 

177. Chu, S. L. et al. Large-area and efficient perovskite light-emitting diodes via low-temperature blade-coating. Nat. Commun. 12, 147 (2021). 

178. Zhao, X. F. & Tan, Z. K. Large-area near-infrared perovskite light-emitting diodes. Nat. Photonics 14, 215–218 (2020). 

179. Wang, H. R. et al. A multi-functional molecular modifier enabling efficient large-area perovskite light-emitting diodes. Joule 4, 1977–1987 (2020). 

180. Kim, D. B. et al. Uniform and large-area cesium-based quasi-2D perovskite light-emitting diodes using hot-casting method. Adv. Mater. Interfaces 7, 1902158 (2020). 

181. Spechler, J. A. et al. A transparent, smooth, thermally robust, conductive polyimide for flexible electronics. Adv. Funct. Mater. 25, 7428–7434 (2015). 

182. Li, F. et al. Flexible QLED and OPV based on transparent polyimide substrate with rigid alicyclic asymmetric isomer. Org. Electron. 51, 54–61 (2017). 

183. Yao, H. Y. et al. From a flexible hyperbranched polyimide to a microporous polyimide network: Microporous architecture and carbon dioxide adsorption. Polymer 115, 176–183 (2017). 

184. Bade, S. G. R. et al. Fully printed halide perovskite light-emitting diodes with silver nanowire electrodes. ACS Nano 10, 1795–1801 (2016). 

185. Zhao, L. F. et al. Influence of Bulky organo-ammonium halide additive choice on the flexibility and efficiency of perovskite light-emitting devices. Adv. Funct. Mater. 28, 1802060 (2018). 

186. Liu, Y. et al. Fluorescent microarrays of in situ crystallized perovskite nanocomposites fabricated for patterned applications by using inkjet printing. ACS Nano 13, 2042–2049 (2019). 

187. Jia, S. Q. et al. Highly luminescent and stable green quasi-2D perovskiteembedded polymer sheets by inkjet printing. Adv. Funct. Mater. 30, 1910817 (2020). 

188. Zhang, H. H. et al. A two-dimensional Ruddlesden-Popper perovskite nanowire laser array based on ultrafast light-harvesting quantum wells. Angew. Chem. Int. Ed. 57, 7748–7752 (2018). 

189. Li, M. J. et al. Enhanced exciton and photon confinement in RuddlesdenPopper perovskite microplatelets for highly stable low-threshold polarized lasing. Adv. Mater. 30, 1707235 (2018). 

190. Liang, Y. et al. Lasing from mechanically exfoliated 2D homologous Ruddlesden-Popper perovskite engineered by inorganic layer thickness. Adv. Mater. 31, 1903030 (2019). 

191. Cui, M. H. et al. Direct observation of competition between amplified spontaneous emission and auger recombination in quasi-two-dimensional perovskites. J. Phys. Chem. Lett. 11, 5734–5740 (2020). 

192. Li, M. L. et al. Amplified spontaneous emission based on 2D RuddlesdenPopper perovskites. Adv. Funct. Mater. 28, 1707006 (2018). 

193. Qin, C. J. et al. Stable room-temperature continuous-wave lasing in quasi-2D perovskite films. Nature 585, 53–57 (2020). 

194. Liang, D. et al. Color-pure violet-light-emitting diodes based on layered lead halide perovskite nanoplates. ACS Nano 10, 6897–6904 (2016). 

195. Chen, Z. M. et al. High-performance color-tunable perovskite light emitting devices through structural modulation from bulk to layered film. Adv. Mater. 29, 1603157 (2017). 

196. Ren, Z. W. et al. Hole transport bilayer structure for quasi-2D perovskite based blue light-emitting diodes with high brightness and good spectral stability. Adv. Funct. Mater. 29, 1905339 (2019). 

197. Pang, P. Y. et al. Rearranging low-dimensional phase distribution of quasi-2D perovskites for efficient sky-blue perovskite light-emitting diodes. ACS Nano 14, 11420–11430 (2020). 

198. Shen, Y. et al. Interfacial potassium-guided grain growth for efficient deepblue perovskite light-emitting diodes. Adv. Funct. Mater. https://doi.org/ 10.1002/adfm.202006736 (2020). 

199. Zhang, Q. P. et al. Efficient metal halide perovskite light-emitting diodes with significantly improved light extraction on nanophotonic substrates. Nat. Commun. 10, 727 (2019). 

200. Shen, Y. et al. High-efficiency perovskite light-emitting diodes with synergetic outcoupling enhancement. Adv. Mater. 31, 1901517 (2019). 

201. Jeon, S. et al. Perovskite light-emitting diodes with improved outcoupling using a high-index contrast nanoarray. Small 15, 1900135 (2019). 

202. Zhang, Q. P. et al. Three-dimensional perovskite nanophotonic wire arraybased light-emitting diodes with significantly improved efficiency and stability. ACS Nano 14, 1577–1585 (2020). 

203. Liu, X. K. et al. Metal halide perovskites for light-emitting diodes. Nat. Mater. https://doi.org/10.1038/s41563-020-0784-7 (2021). 

