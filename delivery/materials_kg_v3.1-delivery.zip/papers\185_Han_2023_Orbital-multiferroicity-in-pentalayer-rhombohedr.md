# Orbital multiferroicity in pentalayer rhombohedral graphene

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 169 |
| 作者 | Tong-Hang Han, Zheng-Guang Lu, Giovanni Scuri, Ji-Ho Sung, Jue Wang, T. Han, K. Watanabe, T. Taniguchi et al. |
| DOI | 10.1038/s41586-023-06572-w |
| 源文件 | 085_Han_2023_Orbital-multiferroicity-in-pentalayer-rhombohedr.pdf |

---
## **Orbital Multiferroicity in Pentalayer Rhombohedral Graphene** 

Tonghang Han<sup>1</sup> †, Zhengguang Lu<sup>1</sup> †, Giovanni Scuri<sup>2,3</sup> , Jiho Sung<sup>2,3</sup> , Jue Wang<sup>2,3</sup> , Tianyi Han<sup>1</sup> , Kenji Watanabe<sup>4</sup> , Takashi Taniguchi<sup>5</sup> , Liang Fu<sup>1</sup> , Hongkun Park<sup>2,3</sup> , Long Ju<sup>1</sup> * 

1Department of Physics, Massachusetts Institute of Technology, Cambridge, MA, USA. 

2Department of Chemistry and Chemical Biology, Harvard University, Cambridge, MA, USA. 

3Department of Physics, Harvard University, Cambridge, MA, USA. 

4Research Center for Electronic and Optical Materials, National Institute for Materials Science, 1-1 Namiki, Tsukuba 305-0044, Japan 

5Research Center for Materials Nanoarchitectonics, National Institute for Materials Science, 1-1 Namiki, Tsukuba 305-0044, Japan 

*Corresponding author. Email: longju@mit.edu †These authors contributed equally to this work. 

**Ferroic orders describe spontaneous polarization of spin, charge, and lattice degrees of freedom in materials. Materials featuring multiple ferroic orders, known as multiferroics, play important roles in multi-functional electrical and magnetic device applications**<sup>1–4</sup> **. 2D materials with honeycomb lattices offer exciting opportunities to engineer unconventional multiferroicity, where the ferroic orders are driven purely by the orbital degrees of freedom but not electron spin. These include ferro-valleytricity corresponding to the electron valley**<sup>5</sup> **and ferro-orbital-magnetism**<sup>6</sup> **supported by quantum geometric effects. Such orbital multiferroics could offer strong valley-magnetic couplings and large responses to external fields—enabling device applications such as multiple-state memory elements, and electric control of valley and magnetic states. Here we report orbital multiferroicity in pentalayer rhombohedral graphene using low temperature magneto-transport measurements. We observed anomalous Hall signals** **_Rxy_ with an exceptionally large Hall angle (tan** **_ΘH_ > 0.6) and orbital magnetic hysteresis at hole doping. There are four such states with different valley polarizations and orbital magnetizations, forming a valley-magnetic quartet. By sweeping the gate electric field** **_E_ we observed a butterfly-shaped hysteresis of** **_Rxy_ connecting the quartet. This hysteresis indicates a ferro-valleytronic order that couples to the composite field** **_E_ •** **_B,_ but not the individual fields. Tuning** **_E_ would switch each ferroic order independently, and achieve non-volatile switching of them together. Our observations demonstrate a new type of multiferroics and point to electrically tunable ultra-low power valleytronic and magnetic devices.** 

Two-dimensional (2D) materials with honeycomb lattices feature electron valley as an internal degree-offreedom that resembles spin. But due to its orbital nature, valley is easier to control through electric field, magnetic field and circular polarization of light<sup>7–9</sup> . The prospect of utilizing valley for information storage, transportation and processing has triggered intensive research in the field known as valleytronics<sup>5</sup> . In parallel, these materials host quantum geometric effects<sup>6–10</sup> that can be controlled by tuning the band structure, including the valley-dependent Hall effect and the orbital magnetism<sup>6–10</sup> . The latter could exhibit a much larger coupling to magnetic field than electron spin does<sup>10,11</sup> . These orbitaldegrees-driven phenomena provide a fertile ground for novel ferroic orders, which warrants large responses to external fields and multi-functional device applications. For example, information could be stored in multiple states with different combinations of valley and magnetic characters instead of being limited to the binary states of spin. Furthermore, such multiple states can be manipulated conveniently by an electric field. Despite its great promise for applications and many theory proposals of realizing multiferroics in heterostructures of graphene and transition metal dichalcogenides<sup>12–14</sup> , orbital multiferroics with independent switching of valley and magnetism have remained elusive. 

Recently, spontaneous valley polarization and orbital magnetism induced by electron correlation effects have been observed in rhombohedral bilayer and trilayer graphene<sup>15–19</sup> , as well as twisted graphene layers<sup>20–24</sup> . Despite the observed magnetic hysteresis, the valley and orbital magnetization are always locked. This is due to the requirement of a large gate electric field _E_ to generate flat bands for the Stoner instability<sup>15–17</sup> , or the fixed band structure in a moiré superlattice<sup>19–24</sup> . The one-to-one correspondence between valley and magnetization prevents their independent control and realizing multiferroicity. In the twisted mono-bilayer graphene, flipping of orbital magnetization by charge doping in a fixed valley was observed<sup>22</sup> . The explanation relies on large edge-state-current contribution<sup>25</sup> , while the magnetic moments in the bulk states are locked to valley. In a general material setting without moiré, it is crucial to understand the contributions of bulk states to ferro-valleytronic and ferro-orbital-magnetic orders without the complications of edge states. However, orbital multiferroicity in natural crystals has not been observed. 

Here we explore orbital multiferroicity in pentalayer graphene with rhombohedral stacking. We purposely twist the angle between graphene and hBN layers away from zero degree to avoid moiré effects<sup>15,26</sup> . As shown in Figure 1a, orbitals located at the two highlighted sublattices dominate the electronic states near zero energy.  Figure 1b shows the band structure and Berry curvature distribution in pentalayer graphene based on a tight-binding calculation<sup>27</sup> _._ At _E_ = 0 V/nm, the two bands feature great flatness and a significantly larger density-of-states than those in thinner graphene (see Extended Data Fig. 3). At the same time, inversion symmetry of the system ensures a zero Berry curvature. When the 

bandgap is opened by _E_ , states near the band edges acquire a non-zero Berry curvature<sup>10,27–29</sup> . The signs of the Berry curvature, the anomalous Hall resistance _Rxy_ and the orbital magnetization depend on the valley index and the sign of _E_ . These results clearly show that valley and orbital magnetism are two separate order parameters in rhombohedral graphene. It is therefore possible to have a quartet of valley-polarized states, (K, + _M_ ), (K, - _M_ ), (K’, + _M_ ) and (K’, - _M_ ), each with the Fermi surface cuts through one of the four bands. The flat bands with tunable Berry curvature in pentalayer graphene provide a fertile ground for electron correlation and quantum geometry effects. The spin character of bands is not shown as it is irrelevant to the observations and discussions. 

## **Spontaneous ferro-orbital-magnetism** 

Figure 2a shows _Rxx_ as a function of the electron density _ne_ and _E_ in zero magnetic field. With hole doping in the flat band, a bubble-shaped region (‘bubble’ for simplicity) that is symmetric about _E_ = 0 emerges. With an out-of-plane magnetic field _B_ = 1.8 T, quantum oscillation features appear within the bubble as shown in Fig. 2b. The period of oscillation corresponds to two isospin flavors at the Fermi level (see Extended Data Fig. 2), indicating an isospin-symmetry-broken half-metal state. This bubble is absent from previous reports of rhombohedral graphene<sup>15–19,30,31</sup> . 

Figure 2c shows the _Rxy_ at _B_ = 0.5 T. Outside the bubble, a small _Rxy_ signal prevails and corresponds to the normal Hall signal. Within the bubble, large anomalous Hall signals appear in a wingsshaped region (‘wings’). The wings largely overlap with the region that shows quantum oscillations in Fig. 2b.  Figure 2d shows _Rxy_ at several different _E_ s at _ne_ = -0.55*10<sup>12</sup> cm<sup>-2</sup> , as _B_ is scanned back and forth. No hysteresis is seen at _E_ = 10 mV/nm, while clear hysteresis can be seen within the wings. The coercive field  _Bc_ decreases while the jump in Hall resistance  _Rxy_ increases, as _E_ is increased in amplitude. The values of  _Bc_ and  _Rxy_ as a function of _E_ are summarized in Fig. 2e. We note that the anomalous Hall angle is exceptionally large, with the largest tan _ΘH_ > 0.6<sup>32,33</sup> . 

Combining the isospin-symmetry-breaking with the anomalous Hall signal, we conclude that the wings is valley-polarized. The magnetic hysteresis loop demonstrates a ferro-orbital-magnetism, where spin is not involved. Fig. 2d illustrates the states at large _B_ values. The Fermi surface is highlighted as a dashed circle, which cuts through the valence band in only one valley. Qualitatively, sweeping _B_ switches both the valley and magnetization at the same time. By switching the sign of _E_ at fixed _B_ , the valley order is flipped while the magnetization remains since the magnetic field always chooses the valley that minimizes the magnetic energy. Microscopically, the close-to-linear relation between  _Rxy_ and | _E|_ is due to the field-controlled Berry curvature distribution and can be reproduced by our tight-binding calculation 

(see Extended Data Fig. 4). This demonstrates a new mechanism to achieve electrical tuning of orbital magnetism, while its counterpart for spin magnetism has been demonstrated<sup>34</sup> . We note the value of  _Bc_ and  _Rxy_ change in opposite ways when _E_ is changed, as the product _M_ • _B_ (where _M_ is the averaged orbital magnetic moment) needs to overcome an energy barrier to have the magnetization flipped. The value of _M_ is hard to be measured directly through transport measurements due to the small size of our device, but can be extracted indirectly as shown later. 

The valley-polarized half-metal state in pentalayer graphene is induced by the electroncorrelation effect in the flat band, in the form of a valley-exchange interaction<sup>35–37</sup> . Although other isospin-symmetry-broken states have been observed in Bernal bilayer graphene and ABC trilayer graphene (only at large _E_ )<sup>15–17</sup> , there was no sign of valley-polarized half-metal states. In addition, this state resides at around zero _E,_ which leads to an important consequence as shown next. 

## **Ferro-valleytricity** 

We further explore the valley and orbital magnetic orders by scanning the electric field _E_ at _B_ = 20 mT, as shown in Fig. 3a&b. Surprisingly, the sign of _Rxy_ switches as the scanning direction switches if we focus on the wings. Fig. 3c shows a line-cut at _ne_ = -0.55*10<sup>12</sup> cm<sup>-2</sup> _,_ which reveals a butterfly-shaped hysteresis loop (‘butterfly’) within the wings. Repeating the measurements in Fig. 3c at –20 mT, a butterfly with the opposite winding direction appears as shown in Fig. 3e. We note that the small magnetic field is used to suppress the fluctuations of the whole magnetization (see Extended Data Fig. 8). 

Based on earlier discussions, we illustrate the band structure and Fermi level corresponding to different states in Fig. 3c. When _E_ is scanned into the wings, the system selects the valley that minimizes the magnetic energy - _M_ • _B_ . Scanning through zero _E_ , the valley polarization persists at the cost of a higher magnetic energy (because _Rxy_ and orbital magnetization are flipped) _._ Fig. 3d shows the valley polarization _V_ (defined as a +1 and –1 for K and K’ valleys, respectively) extracted from Fig. 3c. It features a hysteresis loop and a new ferroic order we call ferro-valleytricity — the spontaneous polarization and switching of the valley order. Even at zero _E_ , the valley polarization exists although the orbital magnetization is zero, in contrast to a non-zero magnetization at valley-polarized states in other graphene systems<sup>15,19–23</sup> . These observations show that the valley polarization and orbital magnetization are two different order parameters of the ground state, distinct from in the quarter-metal of trilayer graphene. Additionally, the butterfly hysteresis can exist in pentalayer graphene since the valley-polarized-half- 

metal resides at around zero _E_ . While in rhombohedral trilayer graphene<sup>15</sup> , the valley polarization is lost when _E_ is scanned to outside the quarter-metal state, and a butterfly was not observed. 

We note the conjugate field of the valley polarization is _E•B._ This can be seen from the winding directions of the valley-polarization in Fig. 3d&e: the two hysteresis loops under positive and negative _B_ wind in opposite ways, but can be unified if we plot _Rxy_ versus _E•B_ instead of _E_ (see Extended Data Fig. 6). This is consistent with the relation between orbital magnetization and valley shown in Fig. 1b. 

We provide a simple picture to understand both the ferro-orbital-magnetism and ferrovalleytricity observed in our device. The coupling between orbital magnetization and valley order can be described by a free energy _F_ = -  _V•E•B_ per hole, where  is a constant independent of _E_ , _V_ and _B_ . In the case of scanning _B_ , _F_ can be viewed as -(  _V•E_ )• _B_ , where  _V_ • _E_ is effectively the averaged orbital magnetic moment and _B_ is the corresponding conjugate field. The averaged orbital magnetic moment  _V_ • _E_ = _g_  _B_ (  _B_ is the Bohr magneton and _g_ is the g-factor) will be extracted from a toy-model in the next section. In the case of scanning _E_ , _F_ can be viewed as -(  _V)_ •( _E_ • _B)_ , where  _V_ is effectively the valley moment and ( _E_ • _B)_ is the corresponding conjugate field _._ 

## **_B_ - and** **_T_ -dependent ferro-valleytricity** 

With the ferro-valleytricity established, we further explore its response to the _B_ and elevated temperature _T_ . Figure 4a&b show the evolution of butterfly at increased _B_ , taken at _T_ = 300 mK and _ne_ = -0.55*10<sup>12</sup> cm<sup>-2</sup> (see Extended Data Fig. 7 for other densities). At small _B_ , the butterfly remains similar to that in Fig. 3c. As | _B_ | is increased, the range of _E_ showing hysteresis gradually shrinks and eventually disappears at ~ 0.6 T. Figure 4c shows line-cuts corresponding to the solid and dashed lines in Fig. 4a&b, where the butterfly gradually shrinks and evolves into an ‘M’ or ‘W’ shape. We define the critical electric field at which the butterfly terminates as _EB_ . At _B_ = -20 mT, Fig. 4d shows _Rxy_ as _E_ is scanned at elevated _T_ . Similar to its response to _B_ , the butterfly gradually evolves into a ‘W’ shape as the temperature is increased to ~2 K. We define the critical electric field at which the butterfly terminates as _ET_ . Figure. 4e summarizes _EB_ and _ET_ as a function of _B_ and _T_ , respectively. 

A model to qualitatively describe the response to _B_ and _T_ is shown in Fig. 4f. The free energy of Ising-coupled orbital magnets has two local minima at – _M_ and + _M_ respectively, where _±M_ is the averaged orbital magnetic moment per hole. An energy barrier  prevents the flipping of the magnetization between – _M_ and + _M_ . At _EB_ and _ET_ , this barrier is overcome by a combination of the thermal energy _kBT_ and the magnetic energy _M•B._ As a result, the device switches from the local minimal 

energy state (K, - _M_ ) to the global minimal energy state (K’, + _M_ ) and the butterfly is terminated. Further analysis of data in Fig. 4e allows us to extract the _g_ -factor as shown in Fig. 4g (see Methods), which agrees with previous literatures<sup>10,28</sup> . Crucially, this averaged orbital magnetic moment per hole is ~10 times bigger than that of electron spin, which allows much stronger coupling with magnetic field. 

## **Orbital multiferroicity and switching** 

The ferro-valleytronic order we observed enriches the family of ferroic orders in solids. Figure 5a compares ferro-valleytricity with conventional ferroic orders and conjugate fields. The valley order breaks both the inversion symmetry and the time-reversal symmetry, similar to the scenario of the ferrotoroidicity<sup>38</sup> . This can be seen from the (different form of) product of _E_ and _B_ as conjugate fields in both of cases. The coexistence of ferro-valleytricity and the orbital ferro-magnetism represents a new type of multiferroics where both orders ultimately originate from the orbital degree of electrons but not spin. These two orders couple strongly with each other, similar to that in type-II multiferroics<sup>2</sup> . Firstly, at fixed _B_ , the conjugate field of the valley order ( _E•B_ ) can continuously tune the orbital magnetic moment as shown in Fig. 3c and 4g, similar to the magneto-electric coupling in conventional type-II multiferroics. Secondly, the emergence of ferro-valleytricity and ferro-orbital-magnetism happen at a similar temperature of _T_ = 2K, as can be seen in Fig. 4d and Extended Data Fig. 5. These co-incident critical temperatures are typical for type-II multiferroics, where one order spontaneously polarizes the other order through their coupling. 

The gate electric field plays an important role in both ferroic orders as it contributes to the conjugate field of the valley order and controls the orbital magnetization. We can therefore use _E_ to control the valley and orbital magnetization independently as shown in Fig. 5b. The valley-magnetic quartet states are connected by the butterfly in Fig. 3a, including (K, + _M_ ), (K, - _M_ ), (K’, + _M_ ) and (K’, - _M_ ). At small _B_ , we can choose different routes along the butterfly to switch the valley repeatedly and keep the magnetization as shown in the blue-shaded part (Fig. 5b), or to keep the valley and switch the magnetization repeatedly as shown in the yellow-shaded part. In addition, the two ferro-magnetic states at the same _E_ , for example (K, + _M_ ) and (K’, - _M_ ) can be switched non-volatilely as shown in Fig. 5c. 

The switching between the valley-magnetic quartet states requires only a change of the gate electric field, but not current flowing through graphene. This is very preferable to the current-induced switching of the magnetization from the power consumption point-of-view, which was the case in twisted bilayer graphene as well as conventional magnetic switches<sup>20,21,39,40</sup> . 

## **Conclusion and outlook** 

In summary, we demonstrated orbital multiferroicity in the flat bands of crystalline pentalayer graphene, which features co-existed but independent ferro-valleytricity and orbital-ferro-magnetism. It enriches the family of electronic phases of matter driven by the co-existing electron correlation and quantum geometry effects. Our experiment opens up new possibilities in harnessing the electron valley and orbital magnetism for multi-functional device applications in valleytronics and magnetics. 

## **References:** 

1. Eerenstein, W., Mathur, N. D. & Scott, J. F. Multiferroic and magnetoelectric materials. _Nature 2006 442:7104_ **442** , 759–765 (2006). 

2. Fiebig, M., Lottermoser, T., Meier, D. & Trassin, M. The evolution of multiferroics. _Nature Reviews Materials 2016 1:8_ **1** , 1–14 (2016). 

3. Spaldin, N. A., Cheong, S. W. & Ramesh, R. Multiferroics: Past, present, and future. _Phys Today_ **63** , 38 (2010). 

4. Jin, W. _et al._ Observation of a ferro-rotational order coupled with second-order nonlinear optical fields. _Nature Physics 2019 16:1_ **16** , 42–46 (2019). 

5. Xu, X., Yao, W., Xiao, D. & Heinz, T. F. Spin and pseudospins in layered transition metal dichalcogenides. _Nature Physics 2014 10:5_ **10** , 343–350 (2014). 

6. Xiao, D., Chang, M. C. & Niu, Q. Berry phase effects on electronic properties. _Rev Mod Phys_ **82** , 1959–2007 (2010). 

7. Mak, K. F., McGill, K. L., Park, J. & McEuen, P. L. The valley hall effect in MoS2 transistors. _Science_ **344** , 1489–1492 (2014). 

8. Ju, L. _et al._ Topological valley transport at bilayer graphene domain walls. _Nature_ **520** , 650–655 (2015). 

9. Yin, J. _et al._ Tunable and giant valley-selective Hall effect in gapped bilayer graphene. _Science_ **375** , 1398–1402 (2022). 

10. Xiao, D., Yao, W. & Niu, Q. Valley-contrasting physics in graphene: Magnetic moment and topological transport. _Phys Rev Lett_ **99** , 236809 (2007). 

11. Ju, L. _et al._ Tunable excitons in bilayer graphene. **358** , 907–910 (2017). 

12. Tong, W.-Y., Gong, S.-J., Wan, X. & Duan, C.-G. Concepts of ferrovalley material and anomalous valley Hall effect. _Nature Communications 2016 7:1_ **7** , 1–7 (2016). 

13. Abouelkomsan, A., Bergholtz, E. J. & Chatterjee, S. Multiferroicity and Topology in Twisted Transition Metal Dichalcogenides. (2022). 

14. Wang, T., Vila, M., Zaletel, M. P. & Chatterjee, S. Electrical control of magnetism in spin-orbit coupled graphene multilayers. (2023). 

15. Zhou, H. _et al._ Half- and quarter-metals in rhombohedral trilayer graphene. _Nature 2021 598:7881_ **598** , 429–433 (2021). 

16. Zhou, H. _et al._ Isospin magnetism and spin-polarized superconductivity in Bernal bilayer graphene. _Science_ **375** , 774–778 (2022). 

17. de la Barrera, S. C. _et al._ Cascade of isospin phase transitions in Bernal-stacked bilayer graphene at zero magnetic field. _Nat Phys_ **18** , 771–775 (2022). 

18. Shi, Y. _et al._ Electronic phase separation in multilayer rhombohedral graphite. _Nature 2020 584:7820_ **584** , 210–214 (2020). 

19. Chen, G. _et al._ Tunable correlated Chern insulator and ferromagnetism in a moiré superlattice. _Nature_ **579** , 56–61 (2020). 

20. Sharpe, A. L. _et al._ Emergent ferromagnetism near three-quarters filling in twisted bilayer graphene. _Science_ **365** , 605–608 (2019). 

21. Serlin, M. _et al._ Intrinsic quantized anomalous Hall effect in a moiré heterostructure. _Science_ **367** , 900–903 (2020). 

22. Polshyn, H. _et al._ Electrical switching of magnetic order in an orbital Chern insulator. _Nature 2020 588:7836_ **588** , 66–70 (2020). 

23. Chen, S. _et al._ Electrically tunable correlated and topological states in twisted monolayer–bilayer graphene. _Nature Physics 2020 17:3_ **17** , 374–380 (2020). 

24. Li, T. _et al._ Quantum anomalous Hall effect from intertwined moiré bands. _Nature_ **600** , 641–646 (2021). 

25. Zhu, J., Su, J. J. & MacDonald, A. H. Voltage-Controlled Magnetic Reversal in Orbital Chern Insulators. _Phys Rev Lett_ **125** , 227702 (2020). 

26. Yang, J. _et al._ Spectroscopy signatures of electron correlations in a trilayer graphene/hBN moiré superlattice. _Science_ **375** , 1295–1299 (2022). 

27. Min, H. & MacDonald, A. H. Electronic structure of multilayer graphene. _Progress of Theoretical Physics Supplement_ **176** , 227–252 (2008). 

28. Zhang, F., Jung, J., Fiete, G. A., Niu, Q. & MacDonald, A. H. Spontaneous quantum Hall states in chirally stacked few-layer graphene systems. _Phys. Rev. Lett._ **106** , 156801 (2011). 

29. Koshino, M. & McCann, E. Trigonal warping and Berry’s phase Nπ in ABC-stacked multilayer graphene. _Phys. Rev. B_ **80** , 165409 (2009). 

30. Weitz, R. T., Allen, M. T., Feldman, B. E., Martin, J. & Yacoby, A. Broken-symmetry states in doubly gated suspended bilayer graphene. _Science_ **330** , 812–816 (2010). 

31. Velasco, J. _et al._ Transport spectroscopy of symmetry-broken insulating states in bilayer graphene. _Nature Nanotechnology 2012 7:3_ **7** , 156–160 (2012). 

32. Nagaosa, N., Sinova, J., Onoda, S., MacDonald, A. H. & Ong, N. P. Anomalous Hall effect. _Rev Mod Phys_ **82** , 1539–1592 (2010). 

33. Liu, E. _et al._ Giant anomalous Hall effect in a ferromagnetic kagome-lattice semimetal. _Nature Physics 2018 14:11_ **14** , 1125–1131 (2018). 

34. Matsukura, F., Tokura, Y. & Ohno, H. Control of magnetism by electric fields. _Nat. Nanotechnol._ **10** , 209–220 (2015). 

35. Dong, Z., Davydova, M., Ogunnaike, O. & Levitov, L. Isospin and momentum polarized orders in bilayer graphene. _Phys Rev B_ **107** , 075108 (2021). 

36. Szabó, A. L. & Roy, B. Competing orders and cascade of degeneracy lifting in doped Bernal bilayer graphene. _Phys Rev B_ **105** , L201107 (2022). 

37. Huang, C. _et al._ Spin and orbital metallic magnetism in rhombohedral trilayer graphene. _Phys Rev B_ **107** , L121405 (2023). 

38. Gnewuch, S. & Rodriguez, E. E. The fourth ferroic order: Current status on ferrotoroidic materials. _J Solid State Chem_ **271** , 175–190 (2019). 

39. Fan, Y. _et al._ Magnetization switching through giant spin-orbit torque in a magnetically doped topological insulator heterostructure. _Nat Mater_ **13** , 699–704 (2014). 

40. He, W. Y., Goldhaber-Gordon, D. & Law, K. T. Giant orbital magnetoelectric effect and currentinduced magnetization switching in twisted bilayer graphene. _Nature Communications 2020 11:1_ **11** , 1–8 (2020). 

# **Main Figures** 



**Figure 1.  Gate-induced Berry curvature and valley-magnetic quartet in pentalayer graphene with the rhombohedral stacking. a.** Schematic of the dual-gated Hall bar device, featuring the top view of the atomic structure of pentalayer rhombohedral graphene. The highlighted orbitals located at the bottom and top layers of pentalayer graphene dominate the wavefunctions of the low energy bands. **b.** Color-coded band structure in the K and K’ valleys, showing the Berry curvature distribution at varied gate electric field _E_ s. The valence band is flatter than the conduction band and more susceptible to electron correlation effects. The Berry curvature and orbital magnetic moment ( _M_ ) of the hole states change signs as _E_ changes sign. Berry curvatures in the two valleys sum up to zero, to ensure the time-reversal symmetry. The four states at non-zero _E_ form a valley-magnetic quartet. 



**Figure 2. Ferro-orbital-magnetism in a valley-polarized half-metal. a & b.** 2D color maps of the longitudinal resistance _Rxx_ at 0 T and 1.8 T out-of-plane magnetic fields. A bubble-shaped region appears when the flat valence band is doped by holes. At 1.8 T, quantum oscillations appear in part of the bubble and the period in density corresponds to two isospin flavors (degeneracy _d_ = 2) at the Fermi level. **c.** 2D color map of the Hall resistance _Rxy_ at _B_ = 0.5 T in the same range as in **a** & **b** . Anomalous Hall signal appears in a wings-shaped region which largely overlaps with where quantum oscillations are seen in Fig. 1d, indicating orbital magnetism due to valley polarization in this half-metal region. **d.** _Rxy_ as the magnetic field _B_ is scanned, showing clear hysteresis loops within the wings.  Curves correspond to dots with the same color in **c** at _ne_ = -0.55*10<sup>12</sup> cm<sup>-2</sup> and different _E_ s, and are shifted vertically for clarity. Solid and dashed curves correspond to forward and backward scanning of the _B_ field, respectively. Schematics of the valence band alignment and Fermi surface are shown for representative states. The bands are colorcoded by the value of Berry curvature, the same as in Fig. 1b. **e.** The anomalous Hall signal  _Rxy_ and the coercive field  _Bc_ extracted from **d** along the dashed line in **c** .  _Rxy_ is the amplitude of the abrupt jump of the transverse resistance which is extracted by averaging the changes of _Rxy_ at the two vertical edges of the magnetic hysteresis loop.  _Rxy_ increases while the  _Bc_ decreases with the increased amplitude of _E_ . 



**Figure 3. Ferro-valleytricity. a** & **b.** 2D color maps of _Rxy_ corresponding to forward and backward scanning of _E_ , at a small magnetic field _B_ = 20 mT. **c.** _Rxy_ at _ne_ = -0.55*10<sup>12</sup> cm<sup>-2</sup> , corresponding to lines shown in **a** & **b.** Clear hysteresis behavior is seen as a butterfly shape. This indicates the valley polarization persists as _E_ changes sign until close to the boundary and out of the wings. Schematics of the valence band alignment and Fermi surface are shown for representative states. The bands are color-coded by the value of Berry curvature, same as in Fig. 1b.  The sharp spikes right before exiting the butterfly are due to the flipping of valley and _Rxy_ induced by the magnetic coupling - _M_ • _B_ , where _M_ is the averaged orbital magnetic moment. **d.** Plot of valley polarization _V_ corresponds to the _Rxy_ plot in **a** , featuring a hysteresis loop and a ferro-valleytronic order. **e.** Same plots as in **c** & **d** for a small negative magnetic field _B_ = -20 mT. The direction of winding in _V_ is opposite of those in **d** , but they can be unified when plotting versus the conjugate field _E_ • _B_ . (See Extended Data Fig. 6). 



**Figure 4. Ferro-valleytricity controlled by magnetic field and temperature. a & b.** _Rxy_ as _E_ is scanned at different magnetic fields at _ne_ = -0.55*10<sup>12</sup> cm<sup>-2</sup> . When _B_ is small, ferro-valleytricity dominates the device behavior. At above ~ 0.6 T, the _Rxy_ and _V_ are completely determined by the magnetic field while the butterfly disappears. **c.** Line-cuts corresponding to the solid and dashed lines in **a** & **b** , showing the butterfly gradually shrinks in _E_ and eventually evolves into an 'M' or 'W' shape. _EB_ indicated by the arrows is the critical field at which the butterfly is terminated. **d.** _Rxy_ as _E_ is scanned at different temperatures at _ne_ = -0.55*10<sup>12</sup> cm<sup>-2</sup> and _B_ = -20 mT. The butterfly and ferro-valleytricity gradually disappear as the temperature is increased, similar to the behaviors as when _B_ is increased. _ET_ is the critical field at which the butterfly is terminated. **e.** Critical fields _EB_ and _ET_ from **c & d** , respectively. **f.** A schematic to explain the flipping of _Rxy_ at the critical fields _EB_ and _ET_ . The flipping happens when the magnetic energy _M_ • _B_ and thermal energy _kBT_ add up to overcome the energy barrier D. **g.** Effective _g_ - factor of the averaged orbital magnetic moment as a function of _E_ extracted from **e** . 



**Figure 5. Electrical control of the orbital multiferroic. a.** Ferroic orders and the corresponding conjugate fields. The ferro-valleytronic order breaks both inversion (due to _E_ field) and time-reversal symmetry (due to _B_ field), similar to the ferro-toroidal order does. The ferro-valleytronic order and ferroorbital-magnetic order form an orbital multiferroic. **b.** Switching of the valley polarization _V_ (blue shaded region) and orbital magnetic moment _M_ (yellow shaded region) independently by sweeping the gate electric field _E_ . The top panel shows the path of switching along the ‘butterfly’ between the two static states labeled by the two dots. The color on the paths matches that of the switching pulse and the arrows label the scanning direction. A small magnetic field _B_ = 20 mT is applied here. **c.** Non-volatile switching of the _M_ and _V_ together using a gate electric field. 

# **Methods** 

## **Device fabrication** 

The pentalayer graphene and hBN flakes were prepared by mechanical exfoliation onto SiO2/Si substrates. The rhombohedral domains of pentalayer graphene were identified using near-field infrared microscopy<sup>8</sup> , confirmed with Raman spectroscopy and isolated by cutting with a Bruker atomic force microscope (AFM)<sup>41</sup> . The van der Waals heterostructure was made following a dry transfer procedure. We picked up the top hBN and pentalayer graphene using polypropylene carbonate (PPC) film and landed it on a prepared bottom stack consisting of an hBN and graphite bottom gate. We intentionally misaligned the straight edges of the flakes to avoid the formation of the moiré superlattice. The device was then etched into a Hall bar structure using standard e-beam lithography (EBL) and reactive-ion etching (RIE). We deposited Cr/Au contact electrodes and a NiCr alloy top layer to form a dual-gate device. 

## **Transport measurement** 

The device was measured in a Bluefors LD250 dilution refrigerator with an electronic temperature of around 100 mK. Part of the data was taken in the National High Magnetic Field Laboratory, Tallahassee, FL. Stanford Research Systems SR830 lock-in amplifiers were used to measure the longitudinal and Hall resistance _Rxx_ and _Rxy_ with an AC voltage bias 200 uV at a frequency at 17.77 Hz. Keithley 2400 sourcemeters were used to apply top and bottom gate. Top-gate voltage ( _Vt_ ) and bottom-gate voltage ( _Vb_ ) are swept to adjust doping density _ne_ =  ( _CtVt_ + _CbVb_ )/ _e_ and electric field _E_ = ( _Vt/dt_ - _Vb/db_ )/2, where _Ct_ and _Cb_ are top- and bottom-gate capacitance per area calculated from the Landau fan diagram 

## **Phase diagram of pentalayer rhombohedral graphene** 

Extended Data Fig. 1a and 1b show the color plots of four-probe resistance _Rxx_ as a function of carrier density _n_ and displacement field _E_ for the hole doping side and electron doping side measured at _B_ = 0 and a temperature of 100 mK. Colored dots label different phases including band insulator (BI), correlated insulator (CI), spin-polarized half metal (SPHM), isospin-polarized quarter metal (IPQM), unpolarized metal (UP) and valley-polarized half metal (VPHM). The large _D_ side of the phase diagram looks similar to that of the previous studies in bilayer and trilayer graphene<sup>15,16</sup> . At the intermediate and small _D_ side, the semimetal and correlated insulator states emerge and dominate the neighboring regions. The VPHM state with a waterdrop shape (labeled by a red star) is the focus of this paper. 

The degeneracy of the isospin-polarized metal is inferred from the spacing of the Landau levels<sup>15</sup> . Extended Data Fig. 2a and 2b show the _Rxx_ as a function of _n_ and _E_ measured at _B_ = 2T in the VPHM 

state and the large density UP state. The Landau level spacings indicate the Fermi surface has 2-fold and 4-fold degeneracy in the VPHM and UP state respectively. The details of IPQM and SPHM states can be found in ref<sup>42</sup> . 

## **Tight-binding calculation of band structure and Hall conductivity** 

The single-particle band structure of the rhombohedral stacked pentalayer graphene is calculated from the 10-band continuum model. The Hamiltonian and the parameters are taken from previous literature<sup>43</sup> . The band structures and density of states (DOS) calculated for different layer number _N_ (2 _N_ -band model) are shown in Extended Data Fig. 3. The remote hopping processes lead to the trigonal warping of the band structure, resulting in deviation from _E_ ~ _k_<sup>_N_</sup> at low energy. We note that among all layer numbers, rhombohedral pentalayer graphene has the flattest band and largest DOS around zero energy. This could account for the observation of new correlated phases absent in Bernal bilayer and rhombohedral trilayer graphene. 

Extended Data Fig. 4a shows the tight-binding calculation of band structure for rhombohedral pentalayer graphene near the K point with an interlayer potential 2 _E0_ = 0 meV (black) and 16 meV (grey). Inset shows an iso-energy contour at –5 meV and the three-fold rotational symmetry is from the trigonal warping effect. Due to the trigonal warping, the Dirac points arrange themselves along the three directions and at the center<sup>29</sup> . The black and white dots represent Dirac points with Berry phase π and –π, which are also labeled by the black and white arrows in the band structure. They appear at different energy and correspondingly different densities. 

We also calculated the intrinsic contribution to the anomalous Hall conductivity by integrating the Berry curvature of the occupied states 𝜎<sup>𝐴𝐻𝐸</sup> = ∫ Ω. Extended Data Fig. 4b shows the 𝑜𝑐𝑐𝑢𝑝𝑖𝑒𝑑 𝑠𝑡𝑎𝑡𝑒𝑠 calculated Hall conductivity with respect to the doping density _ne_ and interlayer potential _E0_ for a single valley and spin flavor _._ The hot spots at around -1.2 and 0.4*10<sup>12</sup> cm<sup>-2</sup> correspond to the four Dirac points at smaller _k_ and the three Dirac points at larger _k_ respectively. In our valley-polarized half-metal picture, one valley has holes while the other valley has zero net carriers ( _ne_ =0). As a result, to fully characterize the system we need to add the contributions from the two valleys together. Extended Data Fig. 4c shows the same plot as **b** with the contribution from the other valley at zero density (opposite value to the dashed line in **b** ). Extended Data Fig. 4d provides a microscopic picture for the linear anomalous Hall conductivity with _E_ . At _E_ = 0, Berry curvature is zero everywhere except for at the Dirac points, so 𝜎<sup>𝑥𝑦</sup> is zero. As _E_ increases, Berry curvature hot spots emerge near the Dirac points and spread out. Consequently, there is more Berry curvature on states below _EF_ and 𝜎<sup>𝑥𝑦</sup> increases with _E_ . Extended Data Fig. 4e shows linecuts in **c** from _ne_ = 0 to -0.5*10<sup>12</sup> cm<sup>-2</sup> for a single spin copy. At a small interlayer 

potential _E0_ , the Hall conductivity is roughly linear with _E0_ . Extended Data Fig. 4f shows measured 𝜎<sup>𝑥𝑦</sup> . The linear _E_ dependence of 𝜎<sup>𝑥𝑦</sup> agrees with the calculation qualitatively. We note that the measurements on the positive _E_ side suffer from contact issue at low temperatures (can be seen from the _n-E_ color plot as well). The measured 𝜎<sup>𝑥𝑦</sup> is much larger than the calculated Berry curvature contribution, which could arise from extrinsic contribution<sup>44</sup> . This phenomenon is also seen in other graphene based orbital magnet, for example the quarter-metal of rhombohedral trilayer graphene<sup>15</sup> . 

## **Doping dependence of the orbital magnetism** 

We show the electric field dependence of the anomalous Hall effect (orbital magnetism) in the main text and here we present the doping dependence. Extended Data Fig. 5a is the same as Fig. 2c and now we cut along the x-axis. Extended Data Fig. 5b and 5c are magnetic hysteresis measured at _E_ = 5 mV/nm and _ne_ = -2.5 to -9.5*10<sup>11</sup> cm<sup>-2</sup> (corresponds to the dots with the same color in 5a) with temperatures of 0.3K and 2K. Clear magnetic hysteresis and anomalous Hall effect are seen within the waterdrop region and we get the largest signal at around _ne_ = -5.5*10<sup>11</sup> cm<sup>-2</sup> . We also note that the magnetic coercive field at 2K almost vanishes, aligned with the disappearance of butterfly at 2K. 

## **Control the valley order with** **_E∙B_ field** 

Here we demonstrate _E∙B_ as the conjugate field of the valley order. Extended Data Fig. 6a and 6b plot show the valley polarization corresponding to the _Rxy_ plot in Fig. 3d & 3e with _B_ >0 and _B_ <0. The two hysteresis loops wind in opposite ways. However, if we plot the x-axis as the _E∙B_ field, the two loops will collapse into one, which demonstrates that the conjugate field of the valley is _E∙B_ . Blue (yellow) lines labels scanning to positive (negative) _E_ direction. The arrows indicate the scanning direction. 

## **Random fluctuation of magnetization at** **_B_ =0** 

Extended Fig. 8 shows the fluctuation of _Rxy_ as a function of time at _B_ = 0 T. _Rxy_ flips sign frequently with time, indicating the fluctuation of the magnetization due to the finite size of the magnet. The stochastic switching enables the system to act as a probabilistic bit, which is essential in probabilistic and neuromorphic computing<sup>45,46</sup> . Crucially, a small external _B_ field (20 mT) is enough to stabilize the system to a controlled state without changing the ground state. As a result, our device is capable of shifting between two operation modes (stochastic and controlled) easily. 

## **_Rxy_ measurement under different conditions** 

There are several measurement conditions including scanning doping density or electric field, and applying a small positive or negative _B_ field. In the main text Fig. 3a and 3b we show the plots of 

scanning _E_ with a positive magnetic field. Here in Extended Data Fig. 9 we discuss the results of other measurements (the applied magnetic field is ±20 mT) and all four measurements are consistent with our picture. 

- i. **Scan** **_E_ , negative** **_B_** (9a, 9b). Similar to the main text Fig. 3a and 3b, the negative magnetic field now selects the opposite valley compared to the former case. The behavior is the same as Fig.3a and 3b with an opposite sign of _Rxy_ . 

- ii. **Scan** **_ne_ , positive** **_B_** (9c, 9d). In contrast to the scanning _E_ case, there is no butterfly-type hysteresis when scanning _n_ , since the orbital magnetism of a valley does not change with _n_ . The system will choose to polarize to the valley with magnetization parallel to _B_ , resulting in positive _Rxy_ in both positive and negative _E_ sides. The magnetization of the system is small around _E_ = 0 and the small external _B_ field cannot effectively select a favored valley, resulting in fluctuations around _E_ = 0. We note the fluctuations around _E_ = 0 do not happen when scanning _D_ since the system already chooses the valley as the system enters the VPHM state and stays in the chosen valley. 

- iii. **Scan** **_ne_ , negative** **_B_** (9e, 9f). Similar to the 9c and 9d but with the opposite external _B_ field. The small negative magnetic field will select the opposite valley compared to the 9c & 9d case. 

## **Hysteresis of the longitudinal resistance** **_Rxx_** 

In the main figures we mainly show the _Rxy_ behaviors and relate the jump of _Rxy_ to the switching of the valley. Here we also present the _Rxx_ behaviors corresponding to the _Rxy_ and show the _Rxx_ jump simultaneously with _Rxy_ . 

Extended Data Fig. 10a-f show the n-E map with a small positive magnetic field. 10a and 10b are the same as Fig. 3a and 3b. 10c and 10d are the _Rxx_ map corresponding to 10a and 10b. The white arrows indicate the jumps at the boundary, which matches where _Rxy_ jumps. 10e and 10f are linecuts at _ne_ =- 0.67*10<sup>12</sup> cm<sup>-2</sup> , indicated by the dashed line in 10c and 10d. The arrows label the scanning directions. The jumps in _Rxx_ happen right before the system get out of the VPHM state where _Rxy_ also jumps. Extended Data Fig. 10g-l plots the data corresponding to the measurement in Fig. 4a and 4b, in a similar way to 10a-f. It is clear that the _Rxx_ jumps at the same time as _Rxy_ jumps. The hysteretic behaviors in _Rxx_ indicate the valley-switching is a first-order process. 

## **Extracting the averaged magnetic moment through a toy model** 

In Fig. 4g we phenomenologically extracted the averaged magnetic moment per hole from the magnetic field dependence and temperature dependence measurement of the _Rxy_ - _E_ butterfly. Our picture is depicted 

in Fig. 4f where we assume the barrier ∆ does not change with magnetic field and temperature. Our sweeping of the magnetic field in Fig. 4 a&b was done very slowly (each scan takes ~minutes). Therefore, in our toy model the system will switch to the valley with lower energy (global minimum) when the magnetic energy added with thermal energy is larger than the barrier, i.e. _M∙B_ + _kBT_ > _∆_ . Then we can estimate the averaged magnetic moment _M_ at different _E_ with the extracted critical electric field _E_ C at different magnetic fields and temperatures in Fig. 4e. We have 

_M(EB)∙B(EB)_ + _kBT(_ 0.3K _)_ = _∆_ 

_M(ET)∙B(_ 0.02T _)_ + _kBT(ET)_ = _∆_ 

Where _EB_ and _ET_ are the critical electric fields when changing magnetic field and temperature. So the averaged magnetic moment can be written as 

_M(E_ C) = ( _kBT_ ( _ET_ ) _- kBT_ (0.3K)) / ( _B_ ( _EB_ ) _- B_ (0.02T)) 

We extrapolate the data in Fig. 4e and calculate the averaged magnetic moment _M_ as a function of electric field and get Fig. 4g. We note that the absence of data at 1.5-2 K in Fig. 4e is due to the difficulty of stabilizing the sample temperature in this range in our experimental setups. When extracting the _g_ -factor, we used the value of _ET_ by linear interpolation in this range. 

## **Relation between ferro-valleytricity, ferroelectricity and magneto-electric effect** 

The coupling term _F_ = -  _E_ * _V_ * _B = -(_  _E_ * _V)_ * _B_ = - _E_ *(  _V_ * _B)_ can be viewed as an orbital magnetic moment coupling to a magnetic field, as well as an electric polarization coupling to an electric field. In the main text we discussed the orbital magnetism and here we elaborate on the electric polarization. 

We note that the total electric polarization/dipole has two parts. Without considering the valley symmetry breaking, an electric dipole is induced by the gate electric field _E_ . At gate electric field _E_ = 0 mV/nm, in both K and K’ valleys, both the conduction and valence band wave functions have 50% at the top layer and 50% at the bottom layer, preserving the inversion symmetry of the lattice structure; when a non-zero _E_ is applied, the inversion symmetry is broken so in both valleys the valence-band-wavefunction is polarized in the layer with a lower potential energy while the conduction-band-wave-function is polarized in the opposite layer. From the band structure point of view, applying a gate electric field opens up the band gap proportional to _E_ and lowers the energy of the valence band, as shown in Extended Data Fig. 11a. The total energy lowering of the valence band and occupied states is equivalent to an electrostatic energy of _E_ * _P0,_ where the electric dipole _P0_ is induced by the applied _E_ and characterizes the number of electrons whose energy is affected by the gap opening. Although the electric potential energy includes a term that is – _E_ * _P0_ , we note that this energy should not be counted in the flipping process from 

K’ to K: as we explained above, _P0_ is unrelated to valley polarization, so **all the states on the freeenergy curve in Fig. 4f have exactly the same potential energy -** **_E_ *** **_P0_ as they correspond to the same** **_E_ and** **_P0_ is unrelated to valley polarization.** As _P0_ is unrelated to valley polarization, vice versa, the ferro-valley order does not imply a ferro-electric order, since the system can have a big(small) Fermi surface in the K(K’) valley even if the inversion symmetry is preserved, as shown by the states at the center of the butterfly in Fig. 3c of the main text. 

When the valley symmetry is spontaneously broken in the presence of a magnetic field _B_ , the bands in K and K’ valley shift in energy due to the coupling between the orbital magnetization and _B_ . This coupling results in the free energy _F_ = -  _E_ * _V_ * _B = -(_  _E_ * _V)_ * _B_ , where  _E_ * _V_ is the averaged orbital magnetic moment as we stated in the manuscript. This same energy can be as _F_ = - _E_ *(  _V_ * _B)_ , where (  _V_ * _B)_ is an effective electric dipole _P’_ . This additional electric dipole _P’_ is determined by both _V_ and _B,_ and it is involved in the ferro-valleytricity behavior. From the band structure point of view, this electric dipole and the corresponding electrostatic energy can be seen from the shift of the occupied states in valence band in a magnetic field _B,_ as shown in Extended Data Fig. 11b. 

In the presence of _B_ , _P’_ (at _E_ = 0 mV/nm) and valley polarization _V_ should indeed co-exist. Here we provide a physical picture to understand this (Extended Data Fig. 11c). At a non-zero _B_ , electron states form discrete Landau levels. Taking the zeroth Landau level as an example (other Landau levels have qualitatively similar sublattice and layer polarization, but quantitatively not as big as that in the zeroth Landau level), its electron wavefunctions in the K and K’ valleys are located at the A and B sublattices respectively. In all rhombohedral graphene, A and B sublattices to describe the lowest-energy bands are located at the top and bottom layers. Therefore, valley polarization leads to the imbalance of population of the zeroth Landau level, which results in a layer polarization of electric charge distribution and electric dipole. 

In summary, ferro-valley order is not related to ferroelectricity when _B_ = 0. Only with the presence of a magnetic field, the ferro-valley order leads to ferroelectricity in a way that _P’_ = (  _V_ * _B)_ . To probe this ferroelectric order, a graphene sensing layer or layer-sensitive capacitance measurement is required<sup>47–49</sup> . We also note that when considering the free energy, we cannot consider the orbital magnetism and electric polarization at the same time, since they come from essentially the same term _F_ = -  _E_ * _V_ * _B_ and we shouldn’t double count this energy. 

The induced electrical polarization _P’_ and orbital magnetic moment _M_ can be viewed as a magneto-electric effect, where the free energy _F_ = -  _V*B*E = -E*P’ =-B*M._ The valley polarization _V_ 

can be viewed as the coefficient of the magnetoelectric effect, which usually can be controlled through strain in conventional multiferroic or magneto-electrics, for example. 

## **Density and in-plane magnetic field scan in the correlated insulting state at** **_D_ =** **_n_ = 0** 

We performed similar measurements as in ref<sup>18</sup> . Although the back-and-forth scans do not overlap perfectly (Extended Data Fig. 12), we did not see obvious hysteresis as reported in ref<sup>18</sup> . 

# **Methods references** 

41. Li, H. _et al._ Electrode-Free Anodic Oxidation Nanolithography of Low-Dimensional Materials. _Nano Lett_ **18** , 8011–8015 (2018). 

42. Han, T. _et al._ Correlated Insulator and Chern Insulators in Pentalayer Rhombohedral Stacked Graphene. _arXiv preprint arXiv:2305.03151_ (2023). 

43. Zhang, F., Sahu, B., Min, H. & MacDonald, A. H. Band structure of ABC-stacked graphene trilayers. _Phys. Rev. B_ **82** , 035409 (2010). 

44. Tian, Y., Ye, L. & Jin, X. Proper scaling of the anomalous hall effect. _Phys Rev Lett_ **103** , 087206 (2009). 

45. Borders, W. A. _et al._ Integer factorization using stochastic magnetic tunnel junctions. _Nature 2019 573:7774_ **573** , 390–393 (2019). 

46. Mizrahi, A. _et al._ Neural-like computing with populations of superparamagnetic basis functions. _Nature Communications 2018 9:1_ **9** , 1–11 (2018). 

47. Fei, Z. _et al._ Ferroelectric switching of a two-dimensional metal. _Nature 2018 560:7718_ **560** , 336– 339 (2018). 

48. de la Barrera, S. C. _et al._ Direct measurement of ferroelectric polarization in a tunable semimetal. _Nature Communications 2021 12:1_ **12** , 1–9 (2021). 

49. Hunt, B. M. _et al._ Direct measurement of discrete valley and orbital quantum numbers in bilayer graphene. _Nature Communications 2017 8:1_ **8** , 1–7 (2017). 

## **Acknowledgments** 

We acknowledge helpful discussions with F. Zhang, J. Checkelsky, L. Levitov, Z. Dong, W. He, P. Yu, Y. Ba, F. Wang, and L. Zhao. We acknowledge Y. Yao for his help in sample fabrication. L.J. acknowledges support from a Sloan Fellowship. Work by T.H. was supported by NSF grant no. DMR2225925. The device fabrication of this work was supported by the STC Center for Integrated Quantum Materials, NSF grant no. DMR-1231319 and was carried out at the Harvard Center for Nanoscale Systems and MIT.Nano. Part of the device fabrication was supported by USD(R&E) under contract no. FA8702-15-D-0001. K.W. and T.T. acknowledge support from the JSPS KAKENHI (Grant Numbers 20H00354, 21H05233 and 23H02052) and World Premier International Research Center Initiative (WPI), MEXT, Japan. L.F. was supported by the STC Center for Integrated Quantum Materials (CIQM) under NSF award no. DMR-1231319. H.K. acknowledges support from NSF grant no. PHY-1506284 and AFOSR grant no. FA9550-21-1-0216 . A portion of this work was performed at the National High Magnetic Field Laboratory, which is supported by National Science Foundation Cooperative Agreement No. DMR-2128556* and the State of Florida. 

## **Author Contributions** 

TH.H., Z.L., G.S., J.S. and J.W. performed the DC magneto-transport measurement. TH.H. and TY.H. fabricated the devices. K.W. and T.T. grew hBN single crystals. TH.H. performed the tight-binding calculations. H.P. and L.F. contributed to the data analysis. L.J. supervised the project. All authors discussed the results and wrote the paper. 

**Competing Interests** The authors declare no competing interests. 

**Correspondence and requests for materials** should be addressed to Long Ju. 

# **Extended Data Figures** 



**Extended Data Fig. 1** | **Raman characterization and phase diagram of rhombohedral penta layer graphene** 

**a, b** , 2D Raman peak of Bernal (black) and rhombohedral (red) stacked pentalayer graphene before ( **a** ) and after ( **b** ) hBN encapsulation. The rhombohedral stacking is preserved after hBN encapsulation. **c, d,** Color plots of four-probe resistance _Rxx_ as a function of carrier density _n_ and displacement field _E_ for the hole doping side ( **c** ) and electron doping side ( **d** ) measured at _B_ = 0 and a temperature of 100 mK. Colored dots label different phases including band insulator (BI), correlated insulator (CI), spin-polarized half metal (SPHM), isospin-polarized quarter metal (IPQM) and unpolarized metal (UP). The red star labels the valley polarized half metal (VPHM), which is the focus of the maintext. The details of IPQM and SPHM states can be found in ref<sup>42</sup> . 



**Extended Data Fig. 2** | **Isospin degeneracy inferred from Landau level spacing** 

Color plots of four-probe resistance _Rxx_ as a function of carrier density _n_ and displacement field _E_ for the small hole doping VPHM region ( **a** ) and large hole doping UP region ( **b** ) measured at _B_ = 2T and a temperature of 300 mK. The straight features correspond to Landau levels and the spacing indicates the degeneracy _d_ of the band. With _d_ = 4, all four isospin flavors are present at the Fermi surfaces. With _d_ = 2, two out of four isospin flavors have Fermi surfaces (the so-called half-metal). 



**Extended Data Fig. 3** | **Single particle band structure and density of states of rhombohedral stacked multilayer graphene** 

Tight-binding calculation of single particle band structure and density of states (DOS) for rhombohedral stacked multilayer graphene (layer number N=2, 3, 4, 5). Due to the remote hopping, the band structure deviates from _E_ ~ _k_<sup>_N_</sup> at low energy. The rhombohedral pentalayer graphene has the flattest band among all layer numbers. 



**Extended Data Fig. 4** | **Hall conductivity calculation** 

**a** , Tight-binding calculation of band structure for rhombohedral pentalayer graphene near the K point with an interlayer potential 2 _E0_ = 0 meV (black) and 16 meV (grey). Inset shows an iso-energy contour at –5 meV and the black and white circles represent Dirac points with Berry phase π and –π, which are also labeled by the black and white arrows in the band structure. **b** , Calculation of Hall conductivity 𝜎<sup>𝑥𝑦</sup> with respect to the doping density _ne_ and interlayer potential _E0_ for a single valley _._ The hot spots at around -1.2 and 0.4*10<sup>12</sup> cm<sup>-2</sup> correspond to the four Dirac points at smaller _k_ and the three Dirac points at larger _k_ respectively. **c** , The same plot as **b** with the contribution from the other valley at zero density (same position and opposite value to the dashed line in **b** ). **d** , Colored-coded band structure in the K valley, showing the Berry curvature distribution at varied gate electric field _E_ s. The iso-energy contour at Fermi level _EF_ is labeled by the dashed circle. 𝜎<sup>𝑥𝑦</sup> can be calculated by integrating the Berry curvature below _EF_ . At _E_ = 0 mV/nm, Berry curvature is zero everywhere except for at the Dirac points, and 𝜎<sup>𝑥𝑦</sup> is zero. As _E_ increases, Berry curvature hot spots emerge near the Dirac points and spread out. Consequently, there is more Berry curvature on states below _EF_ and 𝜎<sup>𝑥𝑦</sup> increases with _E_ . **e** , Linecuts in c from _ne_ =0 to - 0.5*10<sup>12</sup> cm<sup>-2</sup> for a single spin copy. At a small interlayer potential _E0_ , the Hall conductivity is roughly linear with _E0_ . **f** , Measured 𝜎<sup>𝑥𝑦</sup> at 20mT and 0.3K. The linear _E_ dependence of 𝜎<sup>𝑥𝑦</sup> agrees with the calculation qualitatively. Measurements on the positive _E_ side suffer from contact issue at low temperatures. 



**Extended Data Fig. 5** | **Magnetic hysteresis at 0.3K and 2K at different doping** 

**a,** Color plots of four-probe resistance _Rxy_ as a function of carrier density _n_ and displacement field _E_ for the small hole doping VPHM region at _B_ = 0.5 T and _T_ = 0.3 K. **b** & **c** , _Rxy_ as the magnetic field _B_ is scanned, showing clear hysteresis loops within the droplet region.  Curves correspond to dots with the same color in **a** at _E =_ 5 mV/nm and different _ne_ at _T_ = 0.3 K **a** and 2K **b** , and are shifted vertically for clarity. Solid and dashed curves correspond to forward and backward scanning of the _B_ field. At 2K, the coercive field of magnetic hysteresis almost vanishes, consistent with the disappearance of the ferrovalleytronic order at 2K. 



**Extended Data Fig. 6** | **Control valley with** **_E∙B_ field** 

**a** & **b,** Plots of valley polarization correspond to the _Rxy_ plot in Fig. **3d** and **3e** with _B_ > 0 ( **a** ) and _B_ < 0 ( **b** ), featuring two hysteresis loops winding in opposite ways. However, if we plot the x-axis as the _E∙B_ field, the two loops will collapse into one, which demonstrates that the conjugate field of the valley is _E∙B_ . Blue (yellow) lines labels scanning to positive (negative) _E_ direction. The arrows indicate the scanning direction. 



**Extended Data Fig. 7** | **Evolution of the ‘butterfly’ as a function of magnetic field and temperature at** **_ne_ = -0.65*10**<sup>**12**</sup> **cm**<sup>**-2**</sup> **_and ne_ = -0.45*10**<sup>**12**</sup> **cm**<sup>**-2**</sup> **. a & b.** _Rxy_ as _E_ is scanned at different magnetic fields at _ne_ = -0.65*10<sup>12</sup> cm<sup>-2</sup> . **d & e.** _Rxy_ as _E_ is scanned at different temperatures at _ne_ = -0.65*10<sup>12</sup> cm<sup>-2</sup> and _B_ = 30 mT. **e & f.** Critical fields _EB_ and _ET_ from **a-d** . **g.** Effective _g_ -factor of the averaged orbital magnetic moment as a function of _E_ extracted from **e & f** . **h** - **n** . Same measurements and analysis as **a** - **g** at _ne_ = - 0.45*10<sup>12</sup> cm<sup>-2</sup> . 



**Extended Data Fig. 8** | **Fluctuation of magnetization at zero magnetic field** 

_Rxy_ as a function of time, measured at _ne_ =-0.7*10<sup>12</sup> cm<sup>-2</sup> , _E_ = 4 mV/nm, _B_ = 0 and _T_ = 300 mK. _Rxy_ flips sign frequently with time, indicating the fluctuation of the magnetization due to the finite size of the magnet. A small external _B_ field (20mT) can stabilize the system without changing the ground state. 



**Extended Data Fig. 9** | **Hall resistance behaviors under different measuring conditions** 

**a** & **b,** 2D color maps of _Rxy_ in the droplet region corresponding to forward and backward scanning of _E_ with a small negative magnetic field _B_ = -20 mT. **c** & **d,** The same plot as in **a** and **b** but with scanning density _ne_ at _B_ = 20 mT. **e** & **f,** The same plot as in **a** and **b** but with scanning density _ne_ with _B_ = -20 mT. _Rxy_ changes the sign as we scan _E_ but stays the same sign as we scan _ne_ . This is due to the fact that the magnetic moment for a given valley will reverse as we scan _E_ but not _ne_ . As we scan n, the system will choose to polarize to the valley with the magnetic moment parallel with external _B_ . The random jumps near _E_ = 0 when scanning _ne_ is because the magnetic moment near _E_ = 0 is very small and the coupling to the external B field is weak, so the system cannot decide which valley to choose. 



**Extended Data Fig. 10** | **Longitudinal resistance** **_Rxx_ hysteresis** 

**a** & **b** , The same plot as Fig **3d** & **e** . The arrow indicates the jump in _Rxy_ where the valley switches. **c** & **d** , The same plot as in **a** & **b** for _Rxx_ . The arrow indicates where _Rxx_ jumps and it also coincides with where the _Rxy_ jumps. **e** & **f** , Linecuts of _Rxx_ and _Rxy_ at _ne_ =-0.67*10<sup>12</sup> cm<sup>-2</sup> as indicated by the dashed line in **a-d** . **g** & **h,** The same plot as Fig **4a** & **b** . **i** & **j,** The same plot as in **g** & **h** for _Rxx_ . The jumps in _Rxx_ correspond to that in _Rxy_ . **k** & **l,** Linecuts of _Rxx_ and _Rxy_ at _B_ = -0.16T as indicated by the dashed line in **a-d** . The jumps in _Rxx_ indicate the valley-switching is a first-order process. 



**Extended Data Fig. 11** | **Ferro-valleytricity and ferroelectricity** 

The opening of the band gap _E0_ by a gate electric field _E_ is effectively inducing an electric dipole _P0_ which couples to _E_ and lowers the energy of the occupied states. The Berry curvature and orbital magnetization in the K and K’ valleys are opposite. **b.** Given a non-zero _E_ , the valence bands in the K and K’ valley experience further shift in a magnetic field _B_ . The shift is proportional to the orbital magnetization of the occupied states. This shift in energy _M_ * _B = aE*B_ can be viewed as _M_ * _B = E*_ ( _aB_ ) = _E* P’,_ where is effectively an additional electric dipole _P’._ This latter part of electric dipole _P’_ matters for the valleytricity while the _P0_ does not. **c** . Ferro-electricity in the valley-polarized state at _E_ = 0, | _B_ | > 0. Upper panel: illustration of the valley polarization and imbalanced population of the zeroth Landau levels in K and K’ valley at a non-zero _B_ . Lower panel: valley and sublattice and layer have a one-to-one-to-one correspondence in the zeroth Landau level of rhombohedral graphene. Thus a valley polarization at nonzero B implies layer polarization and an electric dipole at _E_ = 0 mV/nm. In this picture, ferro-electricity should exist at _E_ = 0 mV/nm and | _B_ | > 0 mT **.** 



**Extended Data Fig. 12** | **Density and in-plane magnetic field scan at** **_E_ = 0** 

**a.** _Rxx_ versus forward and backward scanning of _n_ . **b.** _Rxx_ versus forward and backward scanning of _B_ //. 

