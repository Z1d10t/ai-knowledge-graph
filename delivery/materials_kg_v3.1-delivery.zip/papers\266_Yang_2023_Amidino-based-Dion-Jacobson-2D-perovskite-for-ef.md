# Amidino-based Dion-Jacobson 2D perovskite for efficient and stable 2D/3D heterostructure perovskite solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Joule |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 191 |
| 作者 | Ting-Huan Yang, Chuang Ma, Weilun Cai, Shi-Qiang Wang, Yin Wu, Jiang-Shan Feng, Nan Wu, Hao-Jin Li et al. |
| DOI | 10.1016/j.joule.2023.02.003 |
| 源文件 | 052_Yang_2023_Amidino-based-Dion-Jacobson-2D-perovskite-for-ef.pdf |

---
**ll** 

### Article 

# Amidino-based Dion-Jacobson 2D perovskite for efficient and stable 2D/3D heterostructure perovskite solar cells 



Tinghuan Yang, Chuang Ma, Weilun Cai, ..., Lili Gao, Shengzhong (Frank) Liu, Kui Zhao 

fengjs@snnu.edu.cn (J.F.) zhaok@snnu.edu.cn (K.Z.) 

Highlights A 2D/3D composite was constructed based on amidinobased DJ 2D and 3D perovskite 

The 2D-perovskite-assisted nucleation/growth of 3D perovskites was found by in situ PL 

2D perovskites decrease the voids and bulk defects for efficient charge transport 

2D/3D devices achieve PCEs of 24.9% and 22.3% based on rigid and flexible substrates 

We report a 2D/3D heterostructure perovskite composite, consisting of amidinobased Dion-Jacobson 2D perovskites and 3D FAPbI3 perovskites, to achieve both efficient charge transport and stability for solar cells. We then demonstrate, in detail, the crystallization mechanism for the 2D/3D composite. The 2D perovskite provides a skeleton for 3D growth during the dissolution-recrystallization process, which effectively avoids volume collapse and reduces bulk defects. The rigid and flexible devices achieved a PCE of 24.9% (certified 24.1%) and 22.3%, respectively, along with enhanced stability. 

Yang et al., Joule 7, 574–586 March 15, 2023 ª 2023 Elsevier Inc. https://doi.org/10.1016/j.joule.2023.02.003 



**ll** 

##### Article 

## Amidino-based Dion-Jacobson 2D perovskite for efficient and stable 2D/3D heterostructure perovskite solar cells 

Tinghuan Yang,<sup>1</sup> Chuang Ma,<sup>1</sup> Weilun Cai,<sup>1</sup> Shiqiang Wang,<sup>1</sup> Yin Wu,<sup>1</sup> Jiangshan Feng,<sup>1,</sup> * Nan Wu,<sup>1</sup> Haojin Li,<sup>1</sup> Wenliang Huang,<sup>1</sup> Zicheng Ding,<sup>1</sup> Lili Gao,<sup>1</sup> Shengzhong (Frank) Liu,<sup>1,2</sup> and Kui Zhao<sup>1,3,</sup> * 

###### SUMMARY 

In metal halide perovskite solar cells the formation of a 2D/3D bulk heterostructure has a positive effect on device stability but can be detrimental to charge transport and power conversion efficiency (PCE). Herein, we report that amidino-based Dion-Jacobson 2D perovskite enables the creation of an efficient and stable FAPbI3based 2D/3D heterostructure in perovskite solar cells. The 2Dperovskite-assisted nucleation/growth of 3D perovskites during film formation was found by using time-resolved optical diagnostics, which decrease concentrations of voids and bulk defects of perovskite films for efficient charge transport. The planar perovskite solar cells based on 2D/3D heterostructures achieved efficiencies of 24.9% and 22.3% on rigid and flexible substrates, respectively, which are the highest efficiencies among all 2D/3D composite solar cells. Improved stability was further demonstrated, with 97% of original efficiency retained for rigid solar cells without encapsulation after 1,000 h of storage under ambient conditions (RH 30%–40%) and 92% for flexible solar cells after 3,000 bending cycles. 

###### INTRODUCTION 

Organic-inorganic metal halide perovskite solar cells (PSCs) are the foremost contenders for future photovoltaic technology owing to their rapidly increasing power conversion efficiency (PCE), which has exceeded 25.7% in just over a decade, and their low-cost, solution-processable preparation.<sup>1,2</sup> However, the long-term stability of PSCs is still a major obstacle limiting their commercialization. Dimensional engineering is an effective strategy to improve both efficiency and stability.<sup>3,4</sup> Compared with threedimensional (3D) perovskites, two-dimensional (2D) perovskites possess significant advantages in terms of improved stability, such as enhanced resistance to moisture and heat, suppressed ion migration, and efficient carrier transport paths.<sup>5,6</sup> However, the current PCE of 2D/3D PSCs is still lower than that of 3D PSCs. Therefore, it is of great research significance to further develop more efficient 2D/3D PSCs to improve both efficiency and stability for commercial applications. 

In 2D/3D perovskites, bulky organic amine salts are generally used as spacers to tailor the [PbI6]<sup>4�</sup> framework, such as phenylethylammonium (PEA), butylammonium (BA), and amylamine (AA) for Ruddlesden-Popper (RP) 2D perovskites<sup>7–13</sup> and propane-1,3-diammonium (PDA), 1,4-phenylenedimethanammonium (PDMA), and 3-(aminomethyl)piperidinium (3AMP) for Dion-Jacobson (DJ) 2D perovskites.<sup>14–17</sup> 2D/3D perovskites have achieved tremendous improvements using different organic amino-ligands and preparation methods; particularly, formamidinium lead iodide 

###### CONTEXT & SCALE 

Planar perovskite solar cells have shown great promise as a photovoltaic technology. The formation of a 2D/3D bulk heterostructure has positive effects on solar cell stability; however, it can increase the charge transport barrier and lead to lattice mismatch between the conventional amino-based ligands and the FAPbI3 3D framework. Herein, we demonstrate a 2D/3D composite based on an amidino-based DionJacobson 2D perovskite and reveal how the addition of 2D perovskites influences the crystallization pathways of 3D perovskites by using in situ optical diagnostics. We found that 2D perovskites can provide a skeleton for the growth of 3D films, thus avoiding volume collapse and reducing bulk defects. Finally, the rigid and flexible devices realized a PCE of 24.9% (certified 24.1%) and a PCE of 22.3%, respectively. The results not only provide a promising route toward efficient and stable perovskite solar cells but also highlight a fundamental understanding of the formation mechanism of FAPbI3-based 2D/ 3D composites. 



574 Joule 7, 574–586, March 15, 2023 ª 2023 Elsevier Inc. 

**ll** 

##### Article 

(FAPbI3)-based 2D/3D perovskites have shown promising device performance. For instance, we previously reported high-performance and ambient-stable solar cells by combining RP/3D heterostructures with molecular passivation. The passivated RP/3D heterostructured devices deliver a well-stabilized PCE—as high as 20.6%—and significantly improve the ambient stability, exceeding 2,800 h.<sup>10</sup> Thomas et al.<sup>18</sup> used dual-isomer alkylammonium cations (DIAC, mixed with n-butylammonium [n-BA] and iso-butylammonium [i-BA]) to passivate the upper and lower interfaces of 3D perovskites, and the obtained 2D/3D heterostructured films achieved an open-circuit voltage (VOC) of 1.21 V and a PCE of 23.3%.<sup>18</sup> Noh et al.<sup>4</sup> adopted a solid-phase in-plane growth to grow RP-type 2D ((BA)2PbI4) film on 3D perovskites to form a 2D/3D heterojunction with an efficiency approaching 24.6%. Zhu et al.<sup>3</sup> constructed2D/3D heterojunctions by designing metastable DJ-type 2D (DMePDAPbI4) structure and obtained a PCE of 24.7%.<sup>3</sup> Although there is a high diversity of organic ligands for 2D perovskites in the literature, the A<sup>+</sup> cation in most published studies is limited to amino-based ligands. Lattice matching between the amino group from organic ligands and FAPbI3 lattices is one of the key factors determining the energy-band alignment and device performance of 2D/3D heterojunctions. For FA-based perovskites, the relatively large FA cations distort the [PbI6]<sup>4�</sup> octahedra,<sup>19</sup> resulting in the lattice mismatch of their reassembly into 2D structures with amino-ligands.<sup>20</sup> Compared with the traditional amino-based ligands, amidino-based ligands are expected to better match FA-based perovskites because of their suitable size and more abundant N–H structures, which can form multiple hydrogen bonding interactions with the [PbI6]<sup>4�</sup> octahedra for fewer defects and better intrinsic stability.<sup>21,22</sup> However, there is little precedent for amidino-based 2D perovskites, not to mention 2D/3D bulk heterostructures based on amidino-2D perovskites and FAPbI3. 

Meanwhile, film formation kinetics has proven to be one of the key factors that determines the solid-film physical properties.<sup>10,23–31</sup> Despite the widespread use of 2D/3D heterostructures to augment device stability or performance, their formation mechanismremainsunresolved.Forexample,conflictsstillremainformethylammonium lead iodide (MAPbI3)-based 2D/3D perovskites in terms of nucleation/growth, as to whether they begin at the air/liquid interface or liquid/substrate interface, and with the low-n phases or high-n phases nucleate first.<sup>11,32,33</sup> For 2D/3D bulk heterostructures basedonamidino-2DperovskitesandFAPbI3,thelocationwherenucleation/growthbegins and the influence of the addition of 2D perovskites on the crystallization pathway of 3D perovskites remains unknown. 

In thisstudy,we first designeda 2D/3Dheterostructure based on FAPbI3 3D perovskites and amidino-based DJ-type 2D perovskites ((4AP)PbI4, 4AP = 4-amidinopyridine ). Further, we gained insight into the formation mechanism of 2D/3D perovskites using in situ optical diagnostics, which showed the influence of 2D perovskites on the crystallization pathways of 3D perovskites during spin coating and subsequent thermal annealing. Next, we demonstrated how crystallization pathways modulate the crystal volume collapse and defect concentration in the solid state. Devices based on 2D/3D heterostructures deliver PCEs of up to 24.9% on rigid substrates and 22.3% on flexible substrates, with excellent long-term and mechanical stability. Our study highlights the critical role of crystallization modulation on the design of superior solar cells. 

###### RESULTS 

Molecular structure, morphology, and optoelectronic properties The amidino-based molecular ligand 4AP (Figure 1A), which has both –NH=C– on the pyridine ring and an (NH2)NH=C– terminal group interacting with the 

> 1Key Laboratory of Applied Surface and Colloid Chemistry, Ministry of Education, Shaanxi Key Laboratory for Advanced Energy Devices, Shaanxi Engineering Laboratory for Advanced Energy Technology, School of Materials Science and Engineering, Shaanxi Normal University, Xi’an 710119, Shaanxi, China 

2Dalian National Laboratory for Clean Energy, iChEM, Dalian Institute of Chemical Physics, Chinese Academy of Sciences, Dalian 116023, Liaoning, China 3Lead contact *Correspondence: fengjs@snnu.edu.cn (J.F.), zhaok@snnu.edu.cn (K.Z.) https://doi.org/10.1016/j.joule.2023.02.003 

Joule 7, 574–586, March 15, 2023 575 

**ll** 

Article 



<!-- Start of picture text -->
A B C<br><!-- End of picture text -->



<!-- Start of picture text -->
D<br><!-- End of picture text -->





<!-- Start of picture text -->
E<br><!-- End of picture text -->



<!-- Start of picture text -->
F<br><!-- End of picture text -->





<!-- Start of picture text -->
G<br><!-- End of picture text -->



<!-- Start of picture text -->
H<br><!-- End of picture text -->

Figure 1. Preparation of 3D and 2D/3D perovskite films and their morphological and optical properties 

(A) Molecular structure of 4AP. 

(B) Single crystal structure of (4AP)PbI4. 

(C and D) SEM surface and cross-sectional images. 

- (E) AFM images, RMS represents the root-mean-square of roughness. 

- (F) XRD diffraction patterns. 

- (G) UV-vis absorption spectra and steady-state PL spectra. 

- (H) TAS spectra of 2D/3D perovskite film. 

576 Joule 7, 574–586, March 15, 2023 

**ll** 

##### Article 

[PbI6]<sup>4�</sup> framework, was selected to construct a DJ perovskite. Single-crystal analysis of (4AP)PbI4 indicates that the inorganic octahedra are connected through corner sharing (Figure 1B; Table S1), with a unit cell displacement of (0.1, 0.2). The (NH2) NH=C– and –NH=C– between the layers were connected to the adjacent upper and lower inorganic layers via hydrogen bonding, respectively. The 4AP-based DJ perovskite has more flexible adjacent [PbI6]<sup>4�</sup> linkages and a greater tolerance to lattice distortion, as well as stronger inner hydrogen bonding interactions, than conventional amino-based analogs.<sup>17</sup> This leads to a unique charge transport behavior that might influence the semiconducting properties of 2D/3D perovskite films. 

The amidino-based 2D/3D films were prepared from a precursor solution comprising a 3D solution and a 2D solution in a molar ratio of 90:1 (Figure S1). The film morphology was evaluated by scanning electron microscopy (SEM) and atomic force microscopy (AFM). The neat 3D film exhibited voids at the grain boundaries (Figure 1C, top, the red circles), caused by the volume collapse when the trapped solvent escapes from the films as reported.<sup>34</sup> The grains became more compact by adding 2D perovskites (Figure 1C, bottom), indicating that the morphology is not negatively affected by the insertion of 2D cations. Cross-sectional SEM images indicated that the perovskite grains were well-stacked perpendicularly, without obvious voids at the grain boundaries in the 2D/3D film (Figures 1D and S2). In addition, the time-of-flight secondary ion mass spectrometry (TOF-SIMS) showed that 4AP is uniformly distributed throughout the perovskite film (Figure S3). The AFM images further confirmed the improved uniformity of the film with 2D perovskites, with fewer voids and decreased root-mean-square roughness (45 nm vs. 32 nm) (Figure 1E). 

Although the addition of 2D perovskite did not change the crystalline packing of the 3D perovskite, as evidenced by the X-ray diffraction (XRD) patterns (Figure 1F), we confirmed the formation of 2D perovskite with different quantum well thicknesses using optical spectroscopy. The ultraviolet-visible (UV-vis) spectra indicated excitonic peaks of (4AP)FAn�1PbnI3n+1 at 525 nm (n = 1), 580 nm (n = 2), 620 nm (n = 3), and 654 nm (n = 4) for the 2D/3D film (Figure 1G).<sup>17,35</sup> Except for the appearance of n = 1–4 DJ quantum wells, the band-edge excitonic feature of the 3D perovskite film remained the same after the addition of 2D perovskite. Interestingly, the perovskite film exhibited stronger photoluminescence (PL) intensity and a 2 nm peak shift with the addition of 2D perovskite, indicating decreased non-radiative recombination.<sup>36</sup> 

Ultrafast transient absorption spectroscopy (TAS) was performed to investigate the charge transfer possibility between the 2D and 3D perovskites.<sup>9,16</sup> The TAS color map is shown in Figure S4 and the TA spectra at different delay times of both films are shown in Figure S5. (4AP)FAn�1PbnI3n+1 with n = 1–4 can be further confirmed in the 2D/3D film. The TAS of (4AP)PbI4 is also given in Figure S6. The evolution of bleaching recovery for different n phases is shown in Figure 1H. Initially, the low n values showed a rapid increase in sequence with increasing n values. The 3D phase also shows a fast-rising process as the low n value gradually decays, indicating that charge transfer occurs between the 2D and 3D perovskites. 

Figure 2A shows a schematic illustration of DJ-type 2D and 3D bulk-phase heterojunctions. X-ray photoelectron spectroscopy (XPS) was performed to compare the electronic environments of the neat 3D and 2D/3D films (Figure S7). The Pb 4f 5/2 and 4f 7/2 peaks were significantly shifted toward lower binding energy from 143.34 and 138.47 eV to 143.23 and 138.37 eV with the addition of 2D perovskite, 

Joule 7, 574–586, March 15, 2023 577 

**ll** 



<!-- Start of picture text -->
Article<br><!-- End of picture text -->



<!-- Start of picture text -->
A B<br>C D<br>E F<br><!-- End of picture text -->





Figure 2. 4AP-based bulk-phase heterojunction and the photoelectric properties (A) Schematic illustration of the crystal structure of a 2D/3D bulk-phase heterojunction. (B) Energy band gap diagram for (4AP)PbI4, 2D/3D, and 3D perovskite films. (C) TRPL carrier decay curves. 

(D) Mott-Schottky plots. 

(E) Dark I-V curves. 

(F) Nyquist plots of 3D and 2D/3D devices. 

respectively. This is attributed to the formation of N–H$$$I hydrogen bonding between 4AP and [PbI6]<sup>4�</sup> octahedra.<sup>21</sup> The band nature of n = 1 2D perovskite and both films was investigated using ultraviolet photoelectron spectroscopy (UPS) (Figure S8) and the band gap extracted from UV-vis absorption spectroscopy (Figure S9). Figure 2B shows the determined energy levels with valence band maximum (VBM) at �5.73, �5.50, and �5.45 eV and conduction band minimum (CBM) at �3.39, �3.95, and �3.90 eV for the n = 1 perovskite, 2D/3D, and 3D films, respectively. The addition of 2D perovskite lowers both the CBM and VBM values by 0.05 eV, which is beneficial for electron extraction. 

Time-resolved photoluminescence spectroscopy (TRPL) was performed to investigate the influence of the 2D perovskite on charge recombination in the 3D perovskite (Figure 2C). The TRPL spectra were fitted using the double exponential decay function: y = A1 expð � t=t1Þ + A2 expð � t=t2Þ + y0,<sup>37</sup> where A1 and A2 represent the relative amplitudes, t1 and t2 represent fast non-radiative recombination caused 

578 Joule 7, 574–586, March 15, 2023 

**ll** 

##### Article 

by defects and impurities, and the radiative recombination process of charge carriers,<sup>38</sup> respectively. The t1 value slightly increased from 0.4 to 0.9 ms along with a significant enhancement of t2 from 1.2 to 3.7 ms for the film with the addition of 2D perovskite (Table S2). This increased lifetime indicates that the traps are significantly reduced, which partially originates from the improved grain boundaries and is beneficial for increasing the VOC of the final solar cell. The capacitance-voltage (C-V) curve was measured to investigate the built-in potential (Vbi) of the film with the addition of 2D perovskite according to the Mott-Schottky relationship (Figure 2D, the details are shown in supplemental information).<sup>4,39</sup> The Vbi value increased from 1.10 to 1.22 V for the 3D and 2D/3D devices. Therefore, more efficient charge separation and higher VOC are expected. 

The defect density within the perovskite films was quantitatively investigated using the space-charge-limited current (SCLC) method for the FTO/TiO2/Perovskite/ PCBM/Ag device (Figure S10). The dark I-V curves are shown in Figure 2E. The trap density (ntrap) and electron mobility (me) were determined from ntrap = ð2εr ε0VTFLÞ=qL<sup>2</sup> and the Mott-Gurney law where me = ð8JDL<sup>3</sup> Þ=ð9εr ε0V<sup>2</sup> Þ,<sup>40</sup> respectively. The values of ntrap and me were 1.94 3 10<sup>16</sup> cm<sup>�3</sup> and 0.04 cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> for the 3D devices and 1.59 3 10<sup>16</sup> cm<sup>�3</sup> and 0.08 cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> for the 2D/3D devices, respectively. The decreased trap density and improved electron mobility were consistent with improved film quality and were beneficial for enhancing device performance. Figure 2F presents Nyquist diagrams of the devices comprising the 3D and 2D/3D films. The inset shows the equivalent circuit model, and the fitted impedance parameters are listed in Table S3. The 2D/3D device exhibited lower series resistance (Rs) and transfer resistance (Rtr). Meanwhile, the recombination impedance (Rrec) increased from 4.43 to 15.27 kU with the addition of 2D perovskite, indicating that the charge carrier’s recombination and defects formation occur with greater difficulty in the perovskite.<sup>41</sup> In addition, transient photocurrent (TPC) and transient photovoltage (TPV) were performed to further examine the non-radiative and radiative recombination processes in completed photovoltaic cells. The 2D/3D devices exhibited a faster photocurrent decay and slower photovoltage decay in contrast to their 3D counterpart, indicating more aggressive carrier extraction and fewer recombination sites or weaker carrier capture ability from defects in the 2D/3D devices (Figure S11). 

###### In situ investigation into crystallization dynamics 

In situ PL spectroscopy was performed for real-time monitoring of the crystallization process during spin coating and subsequent thermal annealing of both neat 3D and 2D/3D films (Figures 3A and 3B). We used the same recipe (thermal annealing at 150<sup>�</sup> C) as the device fabrication procedure to best simulate the real crystallization process in our devices. A 405 nm laser diode coupled with a visible-range spectrometer was mounted to track the in situ photoemission (Figure S12). The corresponding PL peak positions and intensities were extracted and plotted in Figures 3C and 3D. During crystallization, three conversion processes were observed, as explained below. 

During stage I, the a-phase perovskite crystallizes at the point when anti-solvent dripping is applied at ca. 10 s during spin coating. The PL peak shifted slightly from ca. 770 to ca. 790 nm (Figure 1C; see Figure S13 for the PL spectra at selected times). The peak shift originates from two possibilities: that FA cations are preferred to MA and Cs cations for crystallization on the surface and that crystals grow larger with less exciton quantum confinement. The PL intensity exhibited a sharp increase at 10–35 s owing to the rapid nucleation of the perovskite phase on the film surface 

Joule 7, 574–586, March 15, 2023 579 

**ll** 





<!-- Start of picture text -->
A<br>B<br>C<br>D<br><!-- End of picture text -->



Article 

Figure 3. In situ PL measurements for the formation kinetics of perovskite films (A and B) 3D and 2D/3D films during spin coating (left) and annealing (right). (C and D) Peak position and PL intensity extracted from in situ PL measurements during spin coating and annealing, respectively. 

after anti-solvent dripping,<sup>42,43</sup> followed by a decrease at 35–50 s for the neat 3D case. The addition of 2D perovskites led to a lower PL intensity but a continuous increase during spin coating. This implies that the addition of 2D perovskites slows down the nucleation and growth of 3D perovskites during spin coating. 

During stage II, the PL intensity exhibited a sharp drop during the first 10 s of thermal annealing, followed by a continuous decrease until ca. 90 s for the neat 3D film. This was caused by the dissolution of the a-phase perovskite on the surface when the solvent escaped from the bulk film.<sup>44</sup> The corresponding PL peak also demonstrated a sharp drop, from ca. 790 to ca. 750 nm during the first 10 s of thermal annealing, which is related to the smaller crystal size during dissolution and the negative temperature coefficient of Eg (a, �dEg/dT) for metal halide perovskites.<sup>45–47</sup> The negative temperature coefficient of the perovskite was verified by monitoring the in situ PL evolution for a-phase perovskite films, with increasing and decreasing temperatures (Figure S14). Furthermore, the 3D sample exhibited a slight increase in the PL peak to ca. 760 nm during �10–90 s of thermal annealing, indicating the dissolutionrecrystallization equilibrium of the a-phase perovskite on the surface. The addition of the 2D perovskite did not change the dissolution of the a-phase perovskite on the surface, as confirmed by the decrease in the PL intensity during the first 10 s of thermal annealing. Interestingly, the PL intensity showed a sharp increase during 

580 Joule 7, 574–586, March 15, 2023 

**ll** 

##### Article 

�35–60 s of thermal annealing, while the PL peak was retained at �750 nm without any obvious shift. This is in contrast with the observations for the neat 3D film. Such 2D-perovskite-induced differences in PL evolution indicate that 2D perovskites play a template role in the nucleation and growth of a-phase perovskites. In contrast to the homogeneous nucleation of FA-rich a-phase perovskites during spin coating, the 2D perovskites formed during thermal annealing provide a skeleton for the hetero-nucleation of 3D a-phase perovskites to push the dissolution-recrystallization forward. 

During stage III, both the PL intensity and PL peak exhibited negligible variation until the end of the thermal annealing of the 3D film. This indicates that the crystallization process was complete throughout the whole film thickness. For the 2D/3D film, the PL peak remained unchanged, whereas the PL intensity showed a slight decrease and was further stabilized during the subsequent thermal annealing. 

To gain a deep understanding of the crystallization dynamics of 2D-assisted 3D growth, we also characterized XRD of the films during thermal annealing from 25<sup>�</sup> C to 150<sup>�</sup> C. Figure S15 compares XRD patterns recorded for the neat 3D and 2D/3D films. We found stronger diffraction intensity during crystallization when 2D perovskite was introduced. We also observed the formation of 2D (4AP)PbI4 at 2q = 8.8<sup>�</sup> for the 2D/3D film during crystallization (Figures S15 and S16). Note that the 2D/3D films exhibited less lattice change during thermal annealing, indicating that the 2D component decreases lattice stress strain for 3D perovksite.<sup>48–50</sup> These results demonstrate that the 2D component was playing a role in regulating the 3D perovskite growth during the crystallization process. 

Figure 4 shows schematic images comparing the crystallization processes of the neat 3D and 2D/3D perovskites. The 3D perovskite exhibited preferential crystallization of FA-rich a-phase perovskites during spin coating, followed by dissolution and recrystallization when the entrapped DMSO leaves the bulk film during thermal annealing. The homogeneous nucleation during dissolution-recrystallization equilibrium and DMSO evaporation finally causes volume collapse of the crystals, leading to void formation at grain boundaries. This has also been observed previously by Huang et al.,<sup>34</sup> who printed perovskite films from DMSO-containing ink. The DJ 2D perovskite—as previously observed by Kanatzidis’s group and Choi’s group, based on RP 2D perovskites<sup>32,33</sup> —provides a skeleton for the growth of 3D a-phase perovskites. This not only changes the nucleation/growth pathways, as shown in Figure 3D, but also avoids the volume collapse, which is promising for crystallization regulation toward the achievement of high-quality perovskite film. 

###### Photovoltaic performance, and stability 

Solar cells with an n-i-p-type structure of FTO/TiO2/Perovskite/Spiro-OMeTAD/Au were constructed. Figure 5A presents the J-V curves of the 3D and 2D/3D solar cells on a rigid glass substrate. The photovoltaic parameters are shown in Table S4 and Figure S17. The neat 3D cell exhibited a PCE of 22.7%, VOC of 1.13 V, JSC of 25.27 mA cm<sup>�2</sup> , and FF of 79.60%. The addition of 2D improved the PCE to 24.9%, with a VOC of 1.18 V, short-circuit current density (JSC) of 25.70 mA cm<sup>�2</sup> , and fill factor (FF) of 81.81%, which is the highest PCE among all 2D/3D composite PSCs thus far (Figure 5B; Table S5). The 2D/3D solar cells were sent to the accredited laboratory in the National Institute of Metrology (NIM), China, for certification and obtained 24.1% certificated PCE (Figure S18). 2D/3D solar cells on a flexible polyethylene terephthalate/indium tin oxide (PET/ITO) substrate were also fabricated (Figure 5C), with a PCE of 22.3%, VOC of 1.15 V, JSC of 25.26 mA cm<sup>�2</sup> , and FF of 76.58%. This value can 

Joule 7, 574–586, March 15, 2023 581 

**ll** 



Article 





Figure 4. Schematic illustration of crystallization mechanism of perovskite films 

be further promoted when the interfacial charge extraction is improved via trap passivation or band alignment. Figure 5D shows a comparison of the external quantum efficiency (EQE) curves and integrated JSC of both cells on a rigid substrate. The integrated JSC were 25.12 and 25.65 mA cm<sup>�2</sup> for the neat 3D and 2D/3D cells, respectively, which are quite close to those obtained from the J-V. Figure S19 shows the EQE curves of flexible solar cells, the integrated JSC was 24.5 mA cm<sup>�2</sup> , which is close to the value obtained from the J-V result. Furthermore, the higher transmittance (maximum transmittance of 91.7%) of the homemade flexible substrate is also an important factor to improve JSC (Figure S20). Figure S21 shows the maximum power output (SPO) of 3D and 2D/3D cells with PCEs stabilized at 22.6% and 24.7%, respectively. In addition, the hysteresis of the 2D/3D cell was significantly suppressed, as the hysteresis factor decreased from 5.7% to 1.2%, in contrast with that of the 3D cell (Figure S22; Table S6). Figure S23 shows the change of VOC determined by the light intensity, according to equation VOC = �nkBT=q�lnðIÞ + B,<sup>51</sup> where the slope of the 2D/3D device was reduced to 1.20 kBT/q, which was less than 1.76 kBT/q for the 3D device. The reduction in the ideal factor indicates a significant weakening of the defect-assisted Shockley-Read-Hall recombination in 2D/3D devices, which can be attributed to enhanced charge transport. 

To evaluate the stability of solar cells, we monitored the PCE evolution for 2D/ 3D cells without encapsulation stored under ambient conditions relative humidity 

582 Joule 7, 574–586, March 15, 2023 

**ll** 

##### Article 



<!-- Start of picture text -->
A B C<br>D E F<br>G H<br><!-- End of picture text -->

Figure 5. Photovoltaic performance and stability of perovskite solar cells (A) J-V curves of rigid solar cells. 

(B) Comparison of the PCE of 2D/3D composite PSCs. 

(C) J-V curve of flexible solar cell. 

(D) EQE spectra and integral current for rigid devices. 

(E) Environmental stability of rigid solar cells, the error bars represent the standard deviation for normalized PCE of devices. (F) The PCE evolution of rigid PSCs under steady-state light soaking (N2 atmosphere, 100 mW cm<sup>�2</sup> , about 55<sup>�</sup> C). 

(G) Bending cycle stability of flexible solar cells. 

(H) Normalized PCE with curvature from flat to R = 2 mm. 

(RH) of 30%–40%, temperature of 20ºC–25<sup>�</sup> C) (Figure 5E). The cell retained 97.8% of its initial efficiency (24.2%) after storage for 1,032 h, indicating a very low level of perovskite degradation. In addition, without encapsulation, 2D/3D solar cells retained 96% of their initial efficiency (23.7%) after 150 h under continuous light soaking (Figure 5F); however, the 3D devices maintained only 82% of their initial value (22.2%). At the same time, the devices maintained 88% of their initial efficiency after 230 h under thermal stress (Figure S24). We also investigated the mechanical stability of 2D/3D flexible cells. Figure 5G showed the bending test (inset photographs, bend radius is 5 mm) of the cell and the PCE evolution of the cell. The 2D/3D flexible cells retained 92% of their initial PCE after 3,000 bending cycles, which is superior to the 88% of 3D flexible cells. Figure 5H presents the PCE evolution of the 2D/3D cell at different curvature radii. The inset photographs show the cells with different 

Joule 7, 574–586, March 15, 2023 583 

**ll** 

Article 

curvature radii. The 2D/3D flexible cells retained 89% of their initial efficiency when the radius of curvature was increased to 2 mm, which is superior to the 73% retained by the 3D flexible cells. These observations indicate good environmental and mechanical stability for 2D/3D cells, which is partially due to the 2D-perovskite-induced high film quality. 

###### DISCUSSION 

In summary, we successfully prepared amidino-based 2D/3D bulk-phase heterojunction perovskite films by incorporating amidino-based DJ-type 2D perovskites. We first revealed the crystallization mechanism of an amidino-based 2D/3D heterojunction via in situ optical diagnostics. The fabricated rigid and flexible solar cells had PCEs as high as 24.9% (certified 24.1%) and 22.3%, respectively, which are the highest values among all 2D/3D composite PSCs so far, with excellent device stability. The role of 2D perovskite in the formation mechanism and crystallization pathways of 3D perovskite provides an essential guide for the design and preparation of high-quality perovskite films. More importantly, we highlight the great potential of amidino-based organic ligands in the design and development of highly efficient and stable solar cells, which will provide a highly promising strategy for the commercialization of PSCs. It is anticipated that the heterostructure, based on 3D and low-dimensional perovskites, will be one of the important strategies to achieve high-performance devices. With increasing understanding of crystallization dynamics and charge transport behavior for heterostructures, single-junction solar cells with efficiencies close to 27% are expected. 

###### EXPERIMENTAL PROCEDURES 

###### Resource availability 

Lead contact 

Further information and requests for resources and materials should be directed to and will be fulfilled by the lead contact, Kui Zhao (zhaok@snnu.edu.cn). 

###### Materials availability 

The materials synthesized as part of this study are available from the corresponding authors upon request. 

Data and code availability 

This study did not generate any datasets or codes. 

All data needed to evaluate the conclusions in the study are presented in the paper or supplemental information. 

All the data are available from the corresponding authors upon reasonable request. 

###### SUPPLEMENTAL INFORMATION 

Supplemental information can be found online at https://doi.org/10.1016/j.joule. 2023.02.003. 

###### ACKNOWLEDGMENTS 

This work was supported by the Key Program Project of the National Natural Science Foundation of China (51933010), National Natural Science Foundation of China (61974085), National University Research Fund (GK202201005), and the 111 Project (B21005). 

584 Joule 7, 574–586, March 15, 2023 

**ll** 

##### Article 

###### AUTHOR CONTRIBUTIONS 

K.Z. designed the study. K.Z. and S.L. supervised the work. T.Y. conducted most of the experimental work, data analysis, and wrote the first manuscript. C.M. and L.G. synthesized the (4AP)PbI4 single crystal. W.C. helped prepare the flexible PSCs. S.W., Y.W., and W.H. assisted with in situ PL measurements. N.W. helped test the XRD at variable temperature. H.L. and Z.D. analyzed and optimized the energy-level diagram. J.F. provided flexible PET/ITO substrates and supervised the fabrication of flexible PSCs. 

###### DECLARATION OF INTERESTS 

The authors declare no competing interests. 

Received: August 18, 2022 Revised: December 15, 2022 Accepted: February 6, 2023 Published: March 6, 2023 

###### REFERENCES 

1. National Renewable Energy Laboratory (2022). perovskite solar cells based on phase-pure thin Best research-cell efficiencies chart. https:// https:// films. Nat. Energy 6, 38–45. https://doi.org/10. 6, 38–45. https://doi.org/10., 38–45. https://doi.org/10. https://doi.org/10. www.nrel.gov/pv/cellefficiency.html.. 1038/s41560-020-00721-5.. 

1. National Renewable Energy Laboratory (2022). perovskite solar cells based on phase-pure thin 15. Cheng, L., Liu, Z., Li, S., Zhai, Y., Wang, X., Qiao, Best research-cell efficiencies chart. https:// https:// films. Nat. Energy 6, 38–45. https://doi.org/10. 6, 38–45. https://doi.org/10., 38–45. https://doi.org/10. https://doi.org/10. Z., Xu, Q., Meng, K., Zhu, Z., and Chen, G. www.nrel.gov/pv/cellefficiency.html.. 1038/s41560-020-00721-5.. (2021). Highly thermostable and efficient formamidinium-based low-dimensional 

2. Li, N., Niu, X., Chen, Q., and Zhou, H. (2020). 9. Wu, G., Yang, T., Li, X., Ahmad, N., Zhang, X., perovskite solar cells. Angew. Chem. Int. Ed. Towards commercialization: the operational Yue, S., Zhou, J., Li, Y., Wang, H., Shi, X., et al. Engl. 60, 856–864. https://doi.org/10.1002/ stability of perovskite solar cells. Chem. Soc. (2021). Molecular engineering for twoanie.202006970. Rev. 49, 8235–8286. https://doi.org/10.1039/ dimensional perovskites with photovoltaic D0CS00573H. efficiency exceeding 18%. Matter 4, 582–599. 16. Zhang, X., Yang, T., Ren, X., Zhang, L., Zhao, K., https://doi.org/10.1016/j.matt.2020.11.011. and Liu, S. (2021). Film formation control for 

   16. Zhang, X., Yang, T., Ren, X., Zhang, L., Zhao, K., and Liu, S. (2021). Film formation control for high performance Dion–Jacobson 2D perovskite solar cells. Adv. Energy Mater. 11, 2002733. https://doi.org/10.1002/aenm. 202002733. 

3. Zhang, F., Park, S.Y., Yao, C., Lu, H., Dunfield, S.P., Xiao, C., Uli�cna´, S., Zhao, X., Du Hill, L., Chen, X., et al. (2022). Metastable DionJacobson 2D structure enables efficient and stable perovskite solar cells. Science 375, 71–76. https://doi.org/10.1126/science. abj2637. 

10. Niu, T., Lu, J., Tang, M.-C., Barrit, D., Smilgies, D.-M., Yang, Z., Li, J., Fan, Y., Luo, T., McCulloch, I., et al. (2018). High performance ambient-air-stable FAPbI3 perovskite solar cells with molecule-passivated Ruddlesden– Popper/3D heterostructured film. Energy Environ. Sci. 11, 3358–3366. https://doi.org/10. 1039/C8EE02542H. 

   17. Mao, L., Ke, W., Pedesseau, L., Wu, Y., Katan, C., Even, J., Wasielewski, M.R., Stoumpos, C.C., and Kanatzidis, M.G. (2018). Hybrid Dion– Jacobson 2D lead iodide perovskites. J. Am. Chem. Soc. 140, 3775–3783. https://doi.org/10. 1021/jacs.8b00542. 

4. Jang, Y.-W., Lee, S., Yeom, K.M., Jeong, K., Choi, K., Choi, M., and Noh, J.H. (2021). Intact 2D/3D halide junction perovskite solar cells via solid-phase in-plane growth. Nat. Energy 6, 63–71. https://doi.org/10.1038/s41560-02000749-7. 

11. Zhang, X., Munir, R., Xu, Z., Liu, Y., Tsai, H., Nie, W., Li, J., Niu, T., Smilgies, D.-M., Kanatzidis, M.G., et al. (2018). Phase transition control for high performance Ruddlesden–Popper perovskite solar cells. Adv. Mater. 30, e1707166. https://doi.org/10.1002/adma. 201707166. 

   18. Mahmud, M.A., Duong, T., Yin, Y., Peng, J., Wu, Y., Lu, T., Pham, H.T., Shen, H., Walter, D., Nguyen, H.T., et al. (2020). In situ formation of mixed-dimensional surface passivation layers in perovskite solar cells with dual-isomer alkylammonium cations. Small 16, e2005022. https://doi.org/10.1002/smll.202005022. 

5. Jiang, Y., He, X., Liu, T., Zhao, N., Qin, M., Liu, J., Jiang, F., Qin, F., Sun, L., Lu, X., et al. (2019). Intralayer A-site compositional engineering of Ruddlesden–Popper perovskites for thermostable and efficient solar cells. ACS Energy Lett. 4, 1216–1224. https://doi.org/10. 1021/acsenergylett.9b00403. 

12. Niu, T., Lu, J., Jia, X., Xu, Z., Tang, M.-C., Barrit, D., Yuan, N., Ding, J., Zhang, X., Fan, Y., et al. (2019). Interfacial engineering at the 2D/3D heterojunction for high-performance perovskite solar cells. Nano Lett. 19, 7181– 7190. https://doi.org/10.1021/acs.nanolett. 9b02781. 

   19. Li, X., Fu, Y., Pedesseau, L., Guo, P., Cuthriell, S., Hadar, I., Even, J., Katan, C., Stoumpos, C.C., Schaller, R.D., et al. (2020). Negative pressure engineering with large cage cations in 2D halide perovskites causes lattice softening. J. Am. Chem. Soc. 142, 11486–11496. https:// doi.org/10.1021/jacs.0c03860. 

6. Huang, Z., Proppe, A.H., Tan, H., Saidaminov, M.I., Tan, F., Mei, A., Tan, C.-S., Wei, M., Hou, Y., Han, H., et al. (2019). Suppressed ion migration in reduced-dimensional perovskites improves operating stability. ACS Energy Lett. 4, 1521–1527. https://doi.org/10.1021/ acsenergylett.9b00892. 

13. Cheng, P., Xu, Z., Li, J., Liu, Y., Fan, Y., Yu, L., Smilgies, D.-M., Mu¨ ller, C., Zhao, K., and Liu, S.F. (2018). Highly efficient Ruddlesden– Popper halide perovskite PA2MA4Pb5I16 solar cells. ACS Energy Lett. 3, 1975–1982. https:// doi.org/10.1021/acsenergylett.8b01153. 

   20. Lu, J., Yang, T., Niu, T., Bu, N., Zhang, Y., Wang, S., Fang, J., Chang, X., Luo, T., Wen, J., et al. (2022). Formamidinium-based Ruddlesden– Popper perovskite films fabricated via two-step sequential deposition: quantum well formation, physical properties and film-based solar cells. Energy Environ. Sci. 15, 1144–1155. https://doi.org/10.1039/D1EE02851K. 

7. Zhang, J., Qin, J., Wang, M., Bai, Y., Zou, H., Keum, J.K., Tao, R., Xu, H., Yu, H., Haacke, S., and Hu, B. (2019). Uniform permutation of Quasi-2D perovskites by vacuum poling for efficient, high-fill-factor solar cells. Joule 3, 3061–3071. https://doi.org/10.1016/j.joule. 2019.09.020. 

14. Cheng, L., Meng, K., Qiao, Z., Zhai, Y., Yu, R., Pan, L., Chen, B., Xiao, M., and Chen, G. (2022). Tailoring interlayer spacers for efficient and stable formamidinium-based low-dimensional perovskite solar cells. Adv. Mater. 34, e2106380. https://doi.org/10.1002/adma. 202106380. 

   21. Liu, T., Guo, J., Lu, D., Xu, Z., Fu, Q., Zheng, N., Xie, Z., Wan, X., Zhang, X., Liu, Y., and Chen, Y. (2021). Spacer engineering using aromatic formamidinium in 2D/3D hybrid perovskites for 

8. Liang, C., Gu, H., Xia, Y., Wang, Z., Liu, X., Xia, J., Zuo, S., Hu, Y., Gao, X., Hui, W., et al. (2021). Two-dimensional Ruddlesden–Popper layered 

Joule 7, 574–586, March 15, 2023 585 

#### **ll** 

##### Article 

cells with efficiency > 17%: an in situ investigation. ACS Energy Lett. 3, 1078–1085. https://doi.org/10.1021/acsenergylett. 8b00428. 

highly efficient solar cells. ACS Nano 15, 7811– 7820. https://doi.org/10.1021/acsnano. 1c02191. 

22. Ma, Y., Liu, N., Zai, H., Fan, R., Kang, J., Yang, X., Pei, F., Zhou, W., Wang, H., Chen, Y., et al. (2022). Amidinium additives for highperformance perovskite solar cells. J. Mater. Chem. A 10, 3506–3512. https://doi.org/10. 1039/D1TA08092J. 

   32. Hoffman, J.M., Strzalka, J., Flanders, N.C., Hadar, I., Cuthriell, S.A., Zhang, Q., Schaller, R.D., Dichtel, W.R., Chen, L.X., and Kanatzidis, M.G. (2020). In situ grazing-incidence wideangle scattering reveals mechanisms for phase distribution and disorientation in 2D halide perovskite films. Adv. Mater. 32, e2002812. https://doi.org/10.1002/adma.202002812. 

23. Barrit, D., Cheng, P., Tang, M.-C., Wang, K., Dang, H., Smilgies, D.-M., Liu, S., Anthopoulos, T.D., Zhao, K., and Amassian, A. (2019). Impact of the solvation state of lead iodide on its twostep conversion to MAPbI3: an in situ investigation. Adv. Funct. Mater. 29, 1807544. https://doi.org/10.1002/adfm.201807544. 

   33. Chen, A.Z., Shiu, M., Ma, J.H., Alpert, M.R., Zhang, D., Foley, B.J., Smilgies, D.-M., Lee, S.H., and Choi, J.J. (2018). Origin of vertical orientation in two-dimensional metal halide perovskites and its effect on photovoltaic performance. Nat. Commun. 9, 1336. https:// doi.org/10.1038/s41467-018-03757-0. 

24. Barrit, D., Cheng, P., Darabi, K., Tang, M.-C., Smilgies, D.-M., Liu, S., Anthopoulos, T.D., Zhao, K., and Amassian, A. (2020). Roomtemperature partial conversion of a-FAPbI3 perovskite phase via PbI2 solvation enables high-performance solar cells. Adv. Funct. Mater. 30, 1907442. https://doi.org/10.1002/ adfm.201907442. 

   34. Chen, S., Dai, X., Xu, S., Jiao, H., Zhao, L., and Huang, J. (2021). Stabilizing perovskitesubstrate interfaces for high-performance perovskite modules. Science 373, 902–907. https://doi.org/10.1126/science.abi6323. 

   35. Li, Y., Zheng, G., Lin, C., and Lin, J. (2008). New organic–inorganic perovskite materials with different optical properties modulated by different inorganic sheets. Cryst. Growth Des. 8, 1990–1996. https://doi.org/10.1021/ cg800047p. 

25. Fan, Y., Fang, J., Chang, X., Tang, M.-C., Barrit, D., Xu, Z., Jiang, Z., Wen, J., Zhao, H., Niu, T., et al. (2019). Scalable ambient fabrication of high-performance CsPbI2Br solar cells. Joule 3, 2485–2502. https://doi.org/10.1016/j.joule. 2019.07.015. 

26. Li, J., Munir, R., Fan, Y., Niu, T., Liu, Y., Zhong, 36. Shao, Y., Xiao, Z., Bi, C., Yuan, Y., and Huang, J. Y., Yang, Z., Tian, Y., Liu, B., Sun, J., et al. (2018). (2014). Origin and elimination of photocurrent Phase transition control for high-performance hysteresis by fullerene passivation in blade-coated perovskite solar cells. Joule 2, CH3NH3PbI3 planar heterojunction solar cells. 1313–1330. https://doi.org/10.1016/j.joule. Nat. Commun. 5, 5784. https://doi.org/10. 2018.04.011. 1038/ncomms6784. 

27. Tang, M.-C., Fan, Y., Barrit, D., Chang, X., Dang, H.X., Li, R., Wang, K., Smilgies, D.-M., Liu, S., De Wolf, S., et al. (2020). Ambient blade coating of mixed cation, mixed halide perovskites without dripping: in situ investigation and highly efficient solar cells. J. Mater. Chem. A 8, 1095–1104. https://doi. org/10.1039/C9TA12890E. 

   37. Zhao, X., Tian, L., Liu, T., Liu, H., Wang, S., Li, X., Fenwick, O., Lei, S., and Hu, W. (2019). Roomtemperature-processed fullerene singlecrystalline nanoparticles for high-performance flexible perovskite photovoltaics. J. Mater. Chem. A 7, 1509–1518. https://doi.org/10. 1039/C8TA10510C. 

38. Cho, H., Jeong, S.H., Park, M.H., Kim, Y.H., 

28. Tang, M.-C., Fan, Y., Barrit, D., Li, R., Dang, Wolf, C., Lee, C.L., Heo, J.H., Sadhanala, A., H.X., Zhang, S., Magnanelli, T.J., Nguyen, N.V., Myoung, N., Yoo, S., et al. (2015). Overcoming Heilweil, E.J., Hacker, C.A., et al. (2020). the electroluminescence efficiency limitations Efficient hybrid mixed-ion perovskite of perovskite light-emitting diodes. Science photovoltaics: in situ diagnostics of the roles of 350, 1222–1225. https://doi.org/10.1126/ cesium and potassium alkali cation addition. science.aad1818. Sol. RRL 4, 2000272. https://doi.org/10.1002/ solr.202000272.. 39. Almora, O., Aranda, C., Mas-Marza´, E., and 

- solr.202000272.. 39. Almora, O., Aranda, C., Mas-Marza´, E., and Garcia-Belmonte, G. (2016). On Mott-Schottky 

- 29. Zhang, X., Ren, X., Liu, B., Munir, R., Zhu, X., analysis interpretation of capacitance Yang, D., Li, J., Liu, Y., Smilgies, D.-M., Li, R., measurements in organometal perovskite solar et al. (2017). Stable high efficiency twocells. Appl. Phys. Lett. 109, 173903. https://doi. dimensional perovskite solar cells via cesium org/10.1063/1.4966127. doping. Energy Environ. Sci. 10, 2095–2102. https://doi.org/10.1039/C7EE01145H. 40. Han, Q., Bae, S.-H., Sun, P., Hsieh, Y.-T., Yang, 

   40. Han, Q., Bae, S.-H., Sun, P., Hsieh, Y.-T., Yang, Y.M., Rim, Y.S., Zhao, H., Chen, Q., Shi, W., Li, G., and Yang, Y. (2016). Single crystal formamidinium lead iodide (FAPbI3): insight into the structural, optical, and electrical properties. Adv. Mater. 28, 2253–2258. https:// doi.org/10.1002/adma.201505002. 

30. Zhang, Y., Wang, P., Tang, M.-C., Barrit, D., Ke, W., Liu, J., Luo, T., Liu, Y., Niu, T., Smilgies, D.-M., et al. (2019). Dynamical transformation of two-dimensional perovskites with alternating cations in the interlayer space for high-performance photovoltaics. J. Am. Chem. Soc. 141, 2684–2694. https://doi.org/10.1021/ jacs.8b13104. 

   41. Zhao, W., Lin, H., Li, Y., Wang, D., Wang, J., Liu, Z., Yuan, N., Ding, J., Wang, Q., and Liu, S. (2022). Symmetrical acceptor–donor–acceptor molecule as a versatile defect passivation agent toward efficient FA0.85MA0.15PbI3 perovskite solar cells. Adv. Funct. Mater. 32, 

31. Zhong, Y., Munir, R., Li, J., Tang, M.-C., Niazi, M.R., Smilgies, D.-M., Zhao, K., and Amassian, A. (2018). Blade-coated hybrid perovskite solar 

2112032. https://doi.org/10.1002/adfm. 202112032. 

42. Pratap, S., Babbe, F., Barchi, N.S., Yuan, Z., Luong, T., Haber, Z., Song, T.-B., Slack, J.L., Stan, C.V., Tamura, N., et al. (2021). Out-ofequilibrium processes in crystallization of organic-inorganic perovskites during spin coating. Nat. Commun. 12, 5624. https://doi. org/10.1038/s41467-021-25898-5. 

43. Yu, S., Meng, J., Pan, Q., Zhao, Q., Pullerits, T., Yang, Y., Zheng, K., and Liang, Z. (2022). Imidazole additives in 2D halide perovskites: impacts of –CN versus –CH3 substituents reveal the mediation of crystal growth by phase buffering. Energy Environ. Sci. 15, 3321–3330. https://doi.org/10.1039/D2EE00571A. 

44. Yan, Y., Yang, Y., Liang, M., Abdellah, M., Pullerits, T., Zheng, K., and Liang, Z. (2021). Implementing an intermittent spin-coating strategy to enable bottom-up crystallization in layered halide perovskites. Nat. Commun. 12, 6603. https://doi.org/10.1038/s41467-02126753-3. 

45. Tang, B., Ruan, L.J., Qin, C., Shu, A., He, H., and Ma, Y. (2020). High stability and temperaturedependent photoluminescence of orthorhombic CsPbI3 perovskite nanoparticles. Adv. Optical Mater. 8, 2000498. https://doi. org/10.1002/adom.202000498. 

46. Wu, K., Bera, A., Ma, C., Du, Y., Yang, Y., Li, L., and Wu, T. (2014). Temperature-dependent excitonic photoluminescence of hybrid organometal halide perovskite films. Phys. Chem. Chem. Phys. 16, 22476–22481. https:// doi.org/10.1039/C4CP03573A. 

47. Xing, G., Mathews, N., Lim, S.S., Yantara, N., Liu, X., Sabba, D., Gra¨tzel, M., Mhaisalkar, S., and Sum, T.C. (2014). Low-temperature solution-processed wavelength-tunable perovskites for lasing. Nat. Mater. 13, 476–480. https://doi.org/10.1038/nmat3911. 

48. Zhu, C., Niu, X., Fu, Y., Li, N., Hu, C., Chen, Y., He, X., Na, G., Liu, P., Zai, H., et al. (2019). Strain engineering in perovskite solar cells and its impacts on carrier dynamics. Nat. Commun. 10, 815. https://doi.org/10.1038/s41467-01908507-4. 

49. Fang, J., Ding, Z., Chang, X., Lu, J., Yang, T., Wen, J., Fan, Y., Zhang, Y., Luo, T., Chen, Y., et al. (2021). Microstructure and lattice strain control towards high-performance ambient green-printed perovskite solar cells. J. Mater. Chem. A 9, 13297–13305. https://doi.org/10. 1039/D1TA01763B. 

50. Yang, N., Zhu, C., Chen, Y., Zai, H., Wang, C., Wang, X., Wang, H., Ma, S., Gao, Z., Wang, X., et al. (2020). An in situ cross-linked 1D/3D perovskite heterostructure improves the stability of hybrid perovskite solar cells for over 3000 h operation. Energy Environ. Sci. 13, 4344–4352. https://doi.org/10.1039/ D0EE01736A. 

51. Yang, D., Zhou, X., Yang, R., Yang, Z., Yu, W., Wang, X., Li, C., Liu, S., and Chang, R.P.H. (2016). Surface optimization to eliminate hysteresis for record efficiency planar perovskite solar cells. Energy Environ. Sci. 9, 3071–3078. https://doi.org/10.1039/ C6EE02139E. 

586 Joule 7, 574–586, March 15, 2023 

