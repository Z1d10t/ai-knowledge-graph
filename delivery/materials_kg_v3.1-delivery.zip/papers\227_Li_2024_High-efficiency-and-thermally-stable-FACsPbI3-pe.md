# High-efficiency and thermally stable FACsPbI3 perovskite photovoltaics

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Nature |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 301 |
| 作者 | Sai-Sai Li, Yuan-Zhi Jiang, Jian Xu, Di Wang, Zi-Jin Ding, Tong Zhu, Bin Chen, Ying-Guo Yang et al. |
| DOI | 10.1038/s41586-024-08103-7 |
| 源文件 | 027_Li_2024_High-efficiency-and-thermally-stable-FACsPbI3-pe.pdf |

---
Article 

# **High-efficiency and thermally stable FACsPbI3 perovskite photovoltaics** 

|https://doi.org/10.1038/s41586-024-08103-7<br>Received: 5 December 2023<br>Accepted: 23 September 2024|**Saisai Li**<sup>**1,13**</sup>**, Yuanzhi Jiang**<sup>**1,13**</sup>**, Jian Xu**<sup>**2,3,13**</sup>**, Di Wang**<sup>**1,13**</sup>**, Zijin Ding**<sup>**1,13**</sup>**, Tong Zhu**<sup>**2**</sup>**, Bin Chen**<sup>**2**</sup>**,**<br>**Yingguo Yang**<sup>**4**</sup>**, Mingyang Wei**<sup>**5**</sup>**, Renjun Guo**<sup>**6**</sup>**, Yi Hou**<sup>**2**</sup>**, Yu Chen**<sup>**7**</sup>**, Changjiu Sun**<sup>**1**</sup>**, Keyu Wei**<sup>**1**</sup>**,**<br>**Saif M. H. Qaid**<sup>**8**</sup>**, Haizhou Lu**<sup>**9**</sup>**, Hairen Tan**<sup>**10**</sup>**, Dawei Di**<sup>**11**</sup>**, Jun Chen**<sup>**1,12**</sup>**, Michael Grätzel**<sup>**5**</sup>**,**<br>**Edward H. Sargent**<sup>**2** ✉</sup>**& Mingjian Yuan**<sup>**1,12** ✉</sup>|
|---|---|
|Published online: 30 September 2024||
|Check for updates|α-FA1−_x_Cs_x_PbI3is a promising absorbent material for efficient and stable perovskite<br>solar cells (PSCs)<sup>1,2</sup>. However, the most efficient α-FA1−_x_Cs_x_PbI3PSCs require the<br>inclusion of the additive methylammonium chloride<sup>3,4</sup>, which generates volatile<br>organic residues (methylammonium) that limit device stability at elevated<br>temperatures<sup>5</sup>. Previously, the highest certified power-conversion efficiency of<br>α-FA1−_x_Cs_x_PbI3PSCs without methylammonium chloride was only approximately<br>24% (refs. 6,7), and these PSCs have yet to exhibit any stability advantages. Here we<br>identify interfacial contact loss caused by the accumulation of Cs<sup>+</sup>in conventional<br>α-FA1−_x_Cs_x_PbI3PSCs, which deteriorates device performance and stability. Through<br>in situ grazing-incidence wide-angle X-ray scattering analysis and density functional<br>theory calculations, we demonstrate an intermediate-phase-assisted crystallization<br>pathway enabled by acetate surface coordination to fabricate high-quality<br>α-FA1−_x_Cs_x_PbI3films, without using the methylammonium additive. We herein<br>report a certified stabilized power output efficiency of 25.94% and a reverse-scanning<br>power-conversion efficiency of 26.64% for α-FA1−_x_Cs_x_PbI3PSCs. Moreover, the devices<br>exhibited negligible contact losses and enhanced operational stability. They retained<br>over 95% of their initial power-conversion efficiency after operating for over 2,000 h<br>at the maximum power point under 1 sun, 85 °C and 60% relative humidity (ISOS-L-3).|



The highest certified power-conversion efficiency (PCE) of perovskite solar cells (PSCs) has recently reached 26.7% (ref. 8). Despite the rapid progress in increasing the PCE, realizing the long-term operational stability of PSCs under continuous illumination and elevated temperature remains a challenge, hindering commercial applications. α-FAPbI3 perovskite (where FA is formamidinium) has gained much attention for high-efficiency PSCs due to its wide range of optical absorption<sup>9,10</sup> . Notably, all state-of-the-art α-FAPbI3-based PSCs reported to date use methylammonium chloride (MACl) as an additive to stabilize and promote metastable α-FAPbI3. However, previous studies have identified undesired residual methylammonium in the resultant PSCs<sup>4</sup> . These thermally unstable organic species are, thus, causing strong concerns regarding the long-term operational stability of the devices, even when the fraction of methylammonium inclusion is relatively small<sup>11</sup> . 

An alternative approach for producing methylammonium-free perovskites without compromising optical absorption is to introduce 

a small number of Cs<sup>+</sup> cations into α-FAPbI3. Unfortunately, the highly efficient α-FA1− _x_ Cs _x_ PbI3-based PSCs reported to date similarly require MACl additives to improve crystallinity<sup>3</sup> , which inevitably produces methylammonium residues. Recently, the best certified PCE of α-FA1− _x_ Cs _x_ PbI3 PSCs without the MACl additive was only approximately 24% (refs. 6,7), and substantial evidence of device longevity has yet to be demonstrated. Hence, further efforts are required to examine the potential of α-FA1− _x_ Cs _x_ PbI3 perovskites for photovoltaic applications. 

In this work, we discovered a significant contact loss in conventional structured (n-i-p) α-FA1− _x_ Cs _x_ PbI3 photovoltaics without the MACl additive. This loss arises at the top interface between the active layer and the hole transport layer (HTL) of a device. We observed an expansion of the bandgap and a contraction of the lattice in the perovskite films’ top zone, indicating substantial Cs<sup>+</sup> accumulation. Through density functional theory (DFT) calculations and device simulations, we further identified that Cs<sup>+</sup> accumulation induces a notable valence band offset (Δ _E_ V) at the perovskite/HTL interface. This Δ _E_ V significantly limits the 

> 1State Key Laboratory of Advanced Chemical Power Sources, Frontiers Science Center for New Organic Matter, Key Laboratory of Advanced Energy Materials Chemistry (Ministry of Education), College of Chemistry, Nankai University, Tianjin, P. R. China.<sup>2</sup> Department of Electrical and Computer Engineering, University of Toronto, Toronto, Ontario, Canada.<sup>3</sup> Advanced Research Institute of Multidisciplinary Sciences, Beijing Institute of Technology, Beijing, P. R. China.<sup>4</sup> School of Microelectronics, Fudan University, Shanghai, P. R. China.<sup>5</sup> Laboratory of Photonics and Interfaces, Ecole Polytechnique Fédérale de Lausanne, Lausanne, Switzerland.<sup>6</sup> Solar Energy Research Institute of Singapore (SERIS), National University of Singapore, Singapore, Singapore. 7Beijing Synchrotron Radiation Facility, Institute of High Energy Physics, Beijing, P. R. China. 8Department of Physics & Astronomy, College of Sciences, King Saud University, Riyadh, Saudi Arabia.<sup>9</sup> Key Laboratory of MEMS of Ministry of Education, School of Integrated Circuits, Southeast University, Nanjing, P. R. China.<sup>10</sup> College of Engineering and Applied Sciences, Nanjing University, Nanjing, P. R. China.<sup>11</sup> State Key Laboratory of Extreme Photonics and Instrumentation, College of Optical Science and Engineering, Zhejiang University, Hangzhou, P. R. China. 

> 12Haihe Laboratory of Sustainable Chemical Transformations, Tianjin, P. R. China. 13These authors contributed equally: Saisai Li, Yuanzhi Jiang, Jian Xu, Di Wang, Zijin Ding. ✉ e-mail: ted.sargent@ utoronto.ca; yuanmj@nankai.edu.cn 

**82** | Nature | Vol 635 | 7 November 2024 

device’s quasi-Fermi level splitting (QFLS), leading to contact losses, which deteriorate device performance. 

Using incident-angle-dependent in situ grazing-incidence wide-angle X-ray scattering (GIWAXS), we identified that a rapid single-step crystallization occurs sequentially from top to bottom, with a direct phase transition from precursor solution to α-FA1− _x_ Cs _x_ PbI3. This process can directly cause Cs<sup>+</sup> accumulation in the top zone. Moreover, we observed a Cs<sup>+</sup> deficiency in the bottom zone, which leads to the formation of photo-inactive yellow-phase impurities and greatly limits device longevity. Our DFT calculations revealed that the incorporation of Cs<sup>+</sup> into the lattice of α-FA1− _x_ Cs _x_ PbI3 is thermodynamically favourable, whereas Cs<sup>+</sup> segregation is less energetically favourable in the intermediate phase (δ-FA1− _x_ Cs _x_ PbI3). Moreover, DFT calculations also indicated that the migration of Cs<sup>+</sup> was accelerated in δ-FA1− _x_ Cs _x_ PbI3. These findings suggest that Cs<sup>+</sup> tends to reach a homogeneous (rather than accumulated) distribution in δ-FA1− _x_ Cs _x_ PbI3. 

These results motivated us to switch the crystallization pathway from single step to intermediate phase assisted (IPA). To achieve this, we needed to reduce the formation energy of the intermediate δ-FA1− _x_ Cs _x_ PbI3 phase, which would drive the IPA crystallization towards a thermodynamically favourable regime. We demonstrated that the corresponding formation energy of the intermediate phase can be manipulated by rational management of the surface ligand coordination. Through DFT calculations, we found that acetate anions (Ac<sup>−</sup> ), which have a strong surface binding affinity, can reduce the relative formation energy of the intermediate δ phase. Thus, we were able to fabricate high-quality α-FA1− _x_ Cs _x_ PbI3 films without any Cs<sup>+</sup> accumulation, resulting in minimal contact losses and enhanced device operational stability. We herein describe α-FA0.94Cs0.06PbI3 PSCs with a certified stabilized power output (SPO) efficiency of 25.94% and a reverse-scanning PCE of 26.64% (Supplementary Fig. 31). Importantly, these PSCs retained approximately 95% of their initial performance after 2,000 h of maximum power point (MPP) tracking under continuous AM 1.5 G illumination at 85 °C and relative humidity of 60 ± 10% (ISOS-L-3). Our PSCs are among the most efficient and stable conventionally structured PSCs reported to date (Supplementary Table 2). Further, this approach exhibited good versatility regarding various alloyed PSCs with different sizes and device configurations. 

#### **Contact loss in α-FA1−** **_x_ Cs** **_x_ PbI3 PSCs** 

First, we fabricated α-FA1− _x_ Cs _x_ PbI3 PSCs ( _x_ = 0.06) without introducing any MACl additive (denoted as pristine α-FA1− _x_ Cs _x_ PbI3), based on a conventional structure of glass/indium tin oxide (ITO)/SnO2/perovskite/ Spiro-OMeTAD/Au. The active perovskite layer was fabricated by single-step deposition (Fig. 1a). The corresponding average attainable PCE was approximately 23.02% (Extended Data Fig. 1), comparable to the best MACl additive-free PSCs reported to date<sup>6,7,12</sup> . However, the average open-circuit voltage ( _V_ oc) obtained was only 1.10 V, revealing a large _V_ oc loss of up to 420 mV. This value lags far behind that of the state-of-the-art methylammonium-containing PSCs, which typically exhibit a small _V_ oc loss of around 300 mV (ref. 13). Additionally, we observed that pristine α-FA1− _x_ Cs _x_ PbI3 films had large grains of up to micrometres with full surface coverage, indicating good crystallinity (Supplementary Note 8). We, thus, speculated that the _V_ oc loss may have originated from the interfaces, consistent with previous studies that reported that interfacial non-radiative recombination can greatly reduce the attainable _V_ oc (ref. 14). 

We then measured the photoluminescence quantum efficiency (PLQE) for pristine α-FA1− _x_ Cs _x_ PbI3 on various film stacks to verify the hypothesis<sup>15</sup> . As shown in Fig. 1b and Supplementary Fig. 1, we observed a substantial PLQE decrement once the α-FA1− _x_ Cs _x_ PbI3 was in contact with the Spiro-OMeTAD HTL. These results indicate that significant non-radiative recombination arises at the perovskite/HTL interface, which corresponds to a severe reduction in QFLS (around 66 meV) 

compared to the neat film. We then used the light-intensity-dependent QFLS result to construct a pseudo current density versus voltage ( _J–V_ ) curve and quantify the contact loss for each stack (Supplementary Note 1). The results again verified that the performance decline primarily originated from the perovskite/HTL interface. 

By using confocal depth-dependent photoluminescence spectroscopy<sup>16</sup> , we observed a peak blueshift of the photoluminescence at the top zone of a film (Fig. 1c), indicating an expansion of the bandgap. We then investigated the lattice structure at the top zone through incident-angle-dependent grazing-incidence X-ray diffraction (GIXRD) (Extended Data Fig. 2). As depicted in Fig. 1d, we found that the diffraction peak at 13.93°, corresponding to the (100) plane of α-FA1− _x_ Cs _x_ PbI3 ( _x_ ≈ 0.06), had shifted to 14.04° in the top zone. According to Bragg’s law, such a peak shift indicates lattice contraction. We ascribed this to the top-zone Cs<sup>+</sup> accumulation, which was verified by depth profiling with X-ray photoelectron spectroscopy (Supplementary Note 2). We demonstrated that Cs<sup>+</sup> accumulation is independent of the substrates and antisolvents, which has also been observed in other alloyed perovskite films (Supplementary Note 7). 

We evaluated the impact of the Cs<sup>+</sup> accumulation on the device scale<sup>9,17</sup> . We performed DFT calculations to simulate the density of states (DOS) of a perovskite slab with a graded Cs<sup>+</sup> distribution<sup>18</sup> . As illustrated in Fig. 1e, we observed a downward shift of both the valence and conduction bands in the Cs<sup>+</sup> -accumulated zone, which was supported by depth profiling with ultraviolet photoelectron spectroscopy (UPS) (Supplementary Note 3). The impact of the band misalignment on device performance was investigated in simulations with the Solar Cell Capacitance Simulator (Supplementary Note 4). As shown in Fig. 1f, the band shift caused a large valence band offset (Δ _E_ V) between the perovskite layer and the HTL, resulting in undesirable contact loss. This contact loss limited the attainable QFLS and further induced interfacial hole accumulation, which greatly deteriorates device performance and longevity<sup>18</sup> . 

#### **Origin of the composition inhomogeneity** 

To investigate the origin of the top-zone Cs<sup>+</sup> accumulation, we conducted in situ, depth-dependent GIWAXS measurements by varying the incident angle ( _α_ i) of X-rays. As shown in Fig. 2a, a diffraction peak indexed to the (100) plane of α-FA1− _x_ Cs _x_ PbI3 emerged immediately after antisolvent dripping, indicating a direct, single-step phase transition from the precursor solution to α-FA1− _x_ Cs _x_ PbI3. The evolution of this diffraction peak varied with probing depth during crystallization (Fig. 2b), indicating the top-down direction of the sequential crystallization. In the early stage of crystallization, we observed a _q_ value of approximately 9.97 nm<sup>−1</sup> for the (100) plane of α-FA1− _x_ Cs _x_ PbI3 at the top zone ( _α_ i = 0.3°; the probing depth ranged from 0 to around 50 nm). According to Vegard’s law, we derived a nominal formula of FA0.7Cs0.3PbI3 (Extended Data Fig. 2b). Notably, this Cs<sup>+</sup> content ( _x_ ≈ 0.3) significantly exceeded the starting ratio in the precursor solution ( _x_ ≈ 0.06). 

During crystallization, the _q_ value for the top zone remained almost constant (approximately 9.97 nm<sup>−1</sup> ). Conversely, when the probing depth was extended to the bottom zone ( _α_ i = 3°; the probing depth ranged from 0 to around 600 nm), the _q_ value shifted from approximately 9.97 to approximately 9.89 nm<sup>−1</sup> within 20 s, indicating rapid crystallization. Combining this with further grazing-incidence XRD analysis, we attributed the _q_ value variations to a gradual reduction of Cs<sup>+</sup> content from the top to the bottom zone. We here posit that the rapid top-down crystallization occurred with a single-step phase transition to α-FA1− _x_ Cs _x_ PbI3 (ref. 19). As a result, the Cs<sup>+</sup> -accumulated and Cs<sup>+</sup> -deficient α-FA1− _x_ Cs _x_ PbI3 compositions precipitated sequentially, resulting in a vertical variation of the Cs<sup>+</sup> content across the film (Fig. 2e). 

To gain an in-depth understanding of the crystallization process, we performed DFT calculations. The calculations revealed a significant decrease in the formation energy with increasing Cs<sup>+</sup> concentration in α-FA1− _x_ Cs _x_ PbI3 (Fig. 2c)<sup>20</sup> . This indicates that Cs<sup>+</sup> tended to 

Nature | Vol 635 | 7 November 2024 | **83** 



<!-- Start of picture text -->
Article<br><!-- End of picture text -->



<!-- Start of picture text -->
a b<br>Radiative limit 1.25<br>20<br>FA0.94Cs0.06PbI3  Cs + -accumulated Ü-phase PLQE QFLS Non-radiative<br>1.20<br>Seeds 15 loss<br>qV oc<br>10 1.15<br>5 1.10<br>(i) Solution  (ii) Spin-coating 0 1.05<br>Perovskite ETL/Perovskite HTL/Perovskite Devices<br>c d<br>Top zone Top zone µ14.04°<br>Top zone<br> Cs + -accumulated FA1- x Cs x PbI3<br>Bulk Bulk µ13.93°<br>Bottom zone<br> Metastable Cs + -deficient FA1- x Cs x PbI3 (iii) Annealing Increased bandgap<br>750 800 850 900 13.6 13.8 14.0 14.2 14.4<br>Wavelength (nm) 2 θ  (°)<br>e 2  Cs + -accumulated 2 f HTL Pristine Ü-FA1- x Cs x PbI3<br>zone Top zone Bulk<br>CBM<br>CBM<br>1 I – 1<br>Pb 2+ Band  Cross-interface recombination<br>downward shift<br>0 0 (non-radiative loss)<br>VBM Cs +<br>Valence band offset (V E V)<br>–1 FA + –1<br>VBM<br> Cs + -deficient<br>–2 zone –2<br>DOS DOS<br>One-step<br>pro<br>c<br>e<br>s<br>s<br>PLQE (%)<br>OC qV  (eV)QFLS,<br>Energy (eV) Energy (eV)<br>Normalized intensity (a.u.) Normalized intensity (a.u.)<br><!-- End of picture text -->

**Fig. 1 | Top-surface Cs**<sup>**+**</sup> **accumulation and resulting band misalignment. a** , Schematic of the typical crystallization process of α-FA1− _x_ Cs _x_ PbI3 perovskite films ( _x_ = 0.06). **b** , PLQE for pristine α-FA1− _x_ Cs _x_ PbI3 with different film stacks (18 pieces) under 1 sun equivalent illumination. The calculated QFLS and the _qV_ oc of 36 devices are shown against the right axis, where _q_ is the elementary charge. **c** , **d** , Confocal photoluminescence spectra ( **c** ) and zoom-in view of (100) diffraction peaks in grazing-incidence XRD patterns ( **d** ) for the top zone 

and for bulk pristine α-FA1− _x_ Cs _x_ PbI3. **e** , Calculated DOS of the Cs<sup>+</sup> -accumulated zone (red solid line) and Cs<sup>+</sup> -deficient zone (blue dashed line) of pristine α-FA1− _x_ Cs _x_ PbI3 perovskites. The corresponding slab structure model is shown in the middle. **f** , Schematic diagram of the band misalignment caused by surface Cs<sup>+</sup> accumulation. The band bending is supported by UPS depth profiling (Supplementary Fig. 7b). a.u., arbitrary units; CBM, conduction band minimum; VBM, valence band maximum. 

spontaneously incorporate into the lattice to form Cs<sup>+</sup> -accumulated α-FA1− _x_ Cs _x_ PbI3 in the initial stage of crystallization<sup>20,21</sup> . Further, we calculated the corresponding free energy of mixing (Δ _F_ ), which verified that precipitation of Cs<sup>+</sup> -accumulated α-FA1− _x_ Cs _x_ PbI3 perovskite is thermodynamically favourable (Supplementary Note 5)<sup>22–24</sup> . Additionally, due to its tightly linked three-dimensional crystal structure, α-FA1− _x_ Cs _x_ PbI3 has a high energy barrier for Cs<sup>+</sup> migration, which hinders the subsequent compositional homogenization through Cs<sup>+</sup> diffusion (Fig. 2d)<sup>12</sup> . Overall, it became evident that the rapid, single-step crystallization was the primary cause of this top-zone Cs<sup>+</sup> accumulation. These findings prompted us to explore an alternative crystallization pathway that could suppress Cs<sup>+</sup> segregation. 

#### **Crystallization pathway manipulation** 

In our pursuit of an alternative crystallization pathway, we noticed that a non-dominant intermediate phase (δ-FA1− _x_ Cs _x_ PbI3) assisted 

crystallization accompanied by the single-step phase transition during the formation of a pristine α-FA1− _x_ Cs _x_ PbI3 film. This IPA process was characterized by slow crystal growth rate. We then assessed whether this IPA phase transition could be used to suppress the accumulation of Cs<sup>+</sup> . 

We performed DFT calculations to assess the formation energy of intermediate δ-FA1− _x_ Cs _x_ PbI3 with various Cs<sup>+</sup> contents. Figure 2c demonstrates that the formation energy of δ-FA1− _x_ Cs _x_ PbI3 had a relatively low sensitivity to variations in Cs<sup>+</sup> content, which indicated that there was a relatively uniform distribution of the material composition. Furthermore, the DFT calculations revealed that the Cs<sup>+</sup> diffusion barrier in δ-FA1− _x_ Cs _x_ PbI3 was lower than that of α-FA1− _x_ Cs _x_ PbI3 due to its loose and soft one-dimensional structure (Fig. 2d). This would enable the potential compositional homogenization of the films through Cs<sup>+</sup> diffusion. These findings suggest that IPA crystallization could theoretically avoid Cs<sup>+</sup> accumulation. However, to make this phase transition thermodynamically favourable and dominant in the crystallization process, the formation energy of the δ-FA1− _x_ Cs _x_ PbI3 needs to be reduced. 

**84** | Nature | Vol 635 | 7 November 2024 



<!-- Start of picture text -->
a GIWAXS spectra for different depth ranges b Evolution of peak position c<br>Anti- 0.35<br>14 solvent Annealing Pristine Ü-FA1- x Cs x PbI3 (100) 0.06<br>1210 Pristine Ü-FA1- x Cs x PbI3 (100) α i = 0.3°  9.989.96 0.300.25 Significant reductionof formation energy 0.04<br>8 q  @  t 130 = 9.97 nm –1 9.94 Top zone x  � 0.30 0.20 0.02<br>Spin-coating Annealing 0.15<br>1412 Anti-solvent Pristine Ü-FA1- x Cs x PbI3 (100) α i = 3°  9.929.90 Bulk x  � 0.03 0.100.05 0−0.02<br>108 q  @  t 130 = 9.89 nm –1 9.88 ~20 s 0 Üè-FA-FA1-1- xx CsCs xx PbIPbI33 −0.04<br>9.86<br>0 10 20 30 40 50 60 70 80 90 100 110 120 130 30 50 70 90 110 130 0 0.05 0.10 0.15 0.20 0.25<br>Time (s) Time (s) x  in FA1- x Cs x PbI3<br>d<br>Ü-FA1- x Cs x PbI3 è-FA1- x Cs x PbI3 e<br>High diffusion barrier Single-step pathway<br>1.2<br>1.0 Low diffusion barrier<br>Impeded diffusion<br>0.8 FA + Cs + Ac – [PbI6] 4-  Cs+-accumulated Ü-phase Surface Cs + -accumulated film<br>0.6 FA + Intermediate phase Spin-coating Annealing IPA pathway<br>Ü-phase<br>0.4<br>Cs +<br>Homogeneous<br>0.2<br>Promoted diffusion<br>0 Cs +  accumulated Solution  Intermediate phase with ligands Homogeneous film<br>0 3 6 0 3 6<br>Images along the migration path<br>f g Spin-coating Annealing GIWAXS spectra for whole film h Evolution of peak position<br>11 9.96<br>0 4 Anti- IPA  pathway Annealing<br>solvent<br>Homogeneous Ü-FA1- x Cs x PbI3<br>10 Without  q  shift<br>3 9.92<br>–0.5<br>2 9 Intermediate phase<br>–1.0 Extended crystallization process q  @  t 130 � 9.91 nm –1 9.88<br>1<br>8 Top zone Bulk<br>–1.5 I– CH3SO3– BF4– HCOO– Ac– 0 0 10 20 30 40 50 60 70 80 90 100 110 120 130 30 50 70 90 110 130<br>Pseudo-halide anions Time (s) Time (s)<br>–1 (nm) q<br>–1 (nm) q<br>Cs content+<br>–1 (nm) q Formation energy (eV f.u.)–1<br>Energy (eV)<br>–1 (nm) q q  (nm)–1<br>Binding energy (eV)<br>Relative formation energy (eV)<br><!-- End of picture text -->

**Fig. 2 | Crystallization manipulation to eliminate Cs**<sup>**+**</sup> **accumulation. a** , Time-resolved GIWAXS spectra under different probing depths for pristine α-FA1− _x_ Cs _x_ PbI3 films. _q_ @ _t_ 130 is defined as the (100) α-FA1− _x_ Cs _x_ PbI3 peak position at the 130th second. **b** , Corresponding time-resolved evolution of the _q_ value of the (100) α-FA1− _x_ Cs _x_ PbI3 peak for different probing depths. **c** , Calculated formation energies (eV f.u.<sup>−1</sup> ) of α- and δ-FA1− _x_ Cs _x_ PbI3 for various Cs<sup>+</sup> contents, where f.u. represents formula unit. **d** , Energy profiles along the migration paths of Cs<sup>+</sup> in the α- and δ-FA1− _x_ Cs _x_ PbI3 phases, which represents the barrier 

of Cs<sup>+</sup> free diffusion. **e** , Schematic illustrations of rapid single-step and IPA crystallization processes. **f** , DFT results for the relative formation energies of the intermediate phase induced by different pseudo-halide anions. The calculated binding energies of the ligands on the intermediate phase surface are provided on the right axis. **g** , Time-resolved GIWAXS spectra for IPA α-FA1− _x_ Cs _x_ PbI3 films. **h** , Time-resolved evolution of the _q_ value of (100) α-FA1− _x_ Cs _x_ PbI3 peak with different probing depths for IPA films. 

In previous studies, a rational selection of surface ligands has been effective in tuning the formation energy of the nanomaterials<sup>25</sup> . In particular, various pseudo-halide anions can regulate the perovskite crystallization pathway through surface coordination<sup>3,26</sup> . We, thus, introduced pseudo-halide anions into the precursors, with the aim of reducing the formation energy of the intermediate δ-FA1− _x_ Cs _x_ PbI3 by surface coordination. We used DFT calculations to investigate the relative formation energy of δ-FA1− _x_ Cs _x_ PbI3 with different surface pseudo-halide anions (Fig. 2f), such as tetrafluoroborate (BF4−), formate (HCOO<sup>−</sup> ), acetate (Ac<sup>−</sup> ) and methanesulfonate (CH3SO3−). The calculations revealed that the relative formation energy of δ-FA1− _x_ Cs _x_ PbI3 decreased due to surface coordination by pseudo-halide anions. In particular, the largest decrease was observed after the introduction of Ac<sup>−</sup> anions. The decrease was threefold lower compared to the other 

pseudo-halide anions. We attributed this notable decrease in the relative formation energy to the strong coordination capability of Ac<sup>−</sup> on the intermediate phase surface, as Ac<sup>−</sup> has the highest adsorption energy of 3.4 eV among the four types of pseudo-halide anions (Fig. 2f). Further, we employed ab initio molecular dynamics (AIMD) simulations to uncover the role of Ac<sup>−</sup> in modulating the crystallization (Supplementary Note 6). We observed that Ac<sup>−</sup> forms coordinate bonds with Pb<sup>2+</sup> and hydrogen bonds with FA<sup>+</sup> . The corresponding interactions between Ac<sup>−</sup> and Pb<sup>2+</sup> /FA<sup>+</sup> slows down the crystallization kinetics so that Cs<sup>+</sup> can freely diffusing within the intermediate phase across the film, resulting in homogeneous α-FA1− _x_ Cs _x_ PbI3 films. Overall, the DFT calculations demonstrated that introducing Ac<sup>−</sup> surface coordination has the potential to switch the crystallization of α-FA1− _x_ Cs _x_ PbI3 from the single-step pathway to the IPA pathway. Furthermore, previous studies 

Nature | Vol 635 | 7 November 2024 | **85** 



<!-- Start of picture text -->
Article<br>a b<br>1<br>−2.08<br>Fit of IPA film/HTL<br>Fit of pristine film/HTL<br>−3<br>−3.68<br>−4 0.1<br>−4.02<br>−5<br>−5.18 V E V −5.20<br>−5.57<br>−6 0.01<br>Spiro-OMeTAD Pristine film IPA film 0 20 40 60 80 100<br>Time (ns)<br>c d<br>Pristine film/HTL IPA film/HTL Large drop<br>from 1.2 to 1.1 eV<br>1,500 Pristine film<br>Pristine film/HTL<br>1,000<br>500<br>1.30 1,500 IPA film<br>IPA film/HTL<br>1,000<br>500<br>0.95<br>0<br>0.9 1.0 1.1 1.2 1.3<br>QFLS (eV)<br>e f<br>Probing depth ~0 to 50 nm  ~0 to 600 nm ~0 to 600 nm<br>2.0 2.0 2.0 2.0<br>1.6 1.6 1.6 1.6<br>1.2 1.2 1.2 1.2<br>Ü phase Ü phase Ü phase<br>0.8 0.8 0.8 0.8<br>0.4 0.4 0.4 0.4<br>Yellow phase<br>0 0 0 0<br>0 –0.5 –1.0 0 –0.5 –1.0 0 –0.5 –1.0 0 –0.5 –1.0<br>qr  (Å –1 ) qr  (Å –1 ) qr  (Å –1 ) qr  (Å –1 )<br>~0 to 50 nm<br>Ü phase<br>Pristine film IPA film<br>Energy (eV)<br>Normalized PL intensity (a.u.)<br>Counts<br>QFLS (eV) Counts<br>–1 Å ) ( qz –1 Å ) ( qz –1 Å  () qz –1 Å ) ( qz<br><!-- End of picture text -->

**Fig. 3 | Optoelectronic properties and stability of the films. a** , Band alignment of the pristine and IPA α-FA0.94Cs0.06PbI3 films and HTL. **b** , Time-resolved photoluminescence spectra of the pristine and IPA α-FA0.94Cs0.06PbI3 films in contact with HTL. **c** , QFLS maps of pristine and IPA films. **d** , Histograms of 

QFLS pixel values extracted from QFLS maps. **e** , **f** , Two-dimensional GIWAXS scattering patterns in _q_ space for pristine ( **e** ) and IPA ( **f** ) α-FA0.94Cs0.06PbI3 films with different probing depths. Scale bar, 5 μm. PL, photoluminescence. 

**86** | Nature | Vol 635 | 7 November 2024 

suggest that Ac<sup>−</sup> not only contributes to improving the crystallinity but also aids in defect passivation<sup>27–29</sup> . 

With these new findings in mind, we introduced 5% formamidinium acetate (FAAc) into the precursor to fabricate α-FA1− _x_ Cs _x_ PbI3 films, and we monitored the crystallization with in situ GIWAXS. As shown in Fig. 2g, a strong peak with a _q_ value of approximately 8.34 nm<sup>−1</sup> (δ-FA1− _x_ Cs _x_ PbI3 intermediate phase) emerged instantly after the antisolvent dripping. Moreover, diffraction signals from α-FA1− _x_ Cs _x_ PbI3 did not appear during spin-coating. During the annealing, the amount of δ-FA1− _x_ Cs _x_ PbI3 gradually diminished as it transformed into α-FA1− _x_ Cs _x_ PbI3 (Fig. 2e). This observation confirmed that the IPA crystallization now dominated the crystallization process. More importantly, in situ depth-dependent GIWAXS measurements revealed that the probed (100) Bragg peak position of α-FA1− _x_ Cs _x_ PbI3 remained constant at a _q_ value of approximately 9.91 nm<sup>−1</sup> throughout the crystallization, for all probing depths (Fig. 2h). This suggested that top-zone Cs<sup>+</sup> accumulation had been fully eliminated. Furthermore, the IPA approach is sufficiently versatile to be used with the other alloyed perovskites and with various sizes and device configurations, so as to yield spatial compositional homogeneity (Supplementary Note 7). 

#### **Film properties and device performance** 

We used UPS to investigate the interfacial band alignment of the two distinct types of α-FA0.94Cs0.06PbI3 films (Fig. 3a and Supplementary Fig. 8). The data revealed that the IPA α-FA0.94Cs0.06PbI3 film had a reduced valence band offset (Δ _E_ V = 0.02 eV), indicating a mitigated downward band bending compared to the pristine film (Δ _E_ V = 0.39 eV). This observation aligns well with the DFT calculations (Supplementary Note 3). 

To thoroughly evaluate the charge carrier transport and recombination behaviour of the films, we captured time-resolved photoluminescence spectra for two distinct α-FA0.94Cs0.06PbI3 films in contact with Spiro-OMeTAD<sup>30,31</sup> . As shown in Fig. 3b, we used the lifetime of the fast decay process as an indicator of charge extraction. The IPA α-FA0.94Cs0.06PbI3 film had a shorter lifetime _τ_ 1 of approximately 4.2 ns, compared to the approximately 8.5 ns for the pristine film, which is consistent with enhanced hole extraction. 

Next, we mapped the photoluminescence spectra of the α-FA0.94 Cs0.06PbI3 films to extract the corresponding QFLS values so that we could understand the origin of the contact loss (Fig. 3c,d). The QFLS values were determined to be approximately 1.20 eV for pristine α-FA0.94Cs0.06PbI3 films. However, we observed a substantial difference between the two films when they were in contact with Spiro-OMeTAD. The QFLS value of the pristine film dropped to approximately 1.10 eV, with a standard deviation of 49 meV. In contrast, there was no notable decrement of the QFLS for the IPA film (which remained at approximately 1.19 eV), indicating that the non-radiative recombination losses at the top interface of this film were suppressed due to the elimination of Cs<sup>+</sup> accumulation. 

To investigate the ageing of the films, we then employed ex situ depth-dependent GIWAXS (Fig. 3e,f). Notably, a diffraction peak corresponding to the yellow phase emerged at the bottom zone of the pristine α-FA0.94Cs0.06PbI3 film after ageing. We ascribed it to the bottom-zone Cs<sup>+</sup> deficiency, as aforementioned, such that the Cs<sup>+</sup> content was too low to stabilize α-FA1− _x_ Cs _x_ PbI3. This suggests that the film underwent decomposition starting from the buried interface. The corresponding evolution of the buried interface further confirmed this finding (Extended Data Fig. 3 and Supplementary Note 8). In contrast, no diffraction signals corresponding to yellow-phase impurities were observed in the GIWAXS measurements of the IPA films. This led us to the conclusion that Cs<sup>+</sup> segregation was responsible for the accelerated degradation of the pristine α-FA0.94Cs0.06PbI3 films. 

Following these findings, we fabricated α-FA0.94Cs0.06PbI3 PSCs based on a device architecture of glass/ITO/SnO2/perovskite/ Spiro-OMeTAD/Au. The current density versus voltage ( _J–V_ ) plots of the 



<!-- Start of picture text -->
a b<br>1.24<br>25<br>IPA device<br>20 Reverse 1.20 Pristine device<br>Forward<br>15 1.16<br>IPA V (V)oc (mA cm J sc –2 ) (%)FF PCE(%)<br>10 1.12<br>Reverse 1.21 25.69 85.0 26.41 1.04  k B T / q 1.50  k B T / q<br>5 Forward 1.20 25.71 85.4 26.39 1.08<br>0<br>0 0.2 0.4 0.6 0.8 1.0 1.2 10 100<br>Voltage (V) Light intensity (mW cm –2 )<br>c d<br>30 25<br>28 IPA device 20 IPA device<br>26 Pristine device<br>24 15<br>22 Certified SPO efficiency: 25.94%<br>20 10<br>18<br>5<br>16<br>14 0<br>0 50 100 150 200 250 300 20 22 24 26 28<br>Time (s) PCE (%)<br>e<br>25<br>ISOS-L-3: MPP tracking at 85 °C and relative humidity 60 ± 10%<br>20<br>ITO/SnO2/FA0.94Cs0.06PbI3/HTL/Au<br>15 Pristine device T 95 � 150 h IPA device T 95 > 2,000 h<br>10<br>5<br>0 200 400 600 800 1,000 1,200 1,400 1,600 1,800 2,000<br>Time (h)<br>Voltage (V)<br>–2Current density (mA cm)<br>PCE (%) Counts<br>PCE (%)<br><!-- End of picture text -->

**Fig. 4 | Device performance and operational stability of the α-FA1−** **_x_ Cs** **_x_ PbI3 PSCs (** **_x_ = 0.06). a** , _J–V_ curves of the IPA α-FA0.94Cs0.06PbI3 device. **b** , Lightintensity dependence of _V_ oc for pristine and IPA α-FA0.94Cs0.06PbI3 devices. **c** , SPO of the IPA α-FA0.94Cs0.06PbI3 device. **d** , PCE histograms for the pristine and IPA α-FA0.94Cs0.06PbI3 devices. **e** , Long-term stability of the encapsulated α-FA0.94Cs0.06PbI3 devices. For the MPP tracking, an encapsulated device was kept at a constant temperature of approximately 85 °C and an ambient humidity of 60 ± 10% for the entire measurement process, which was based on the ISOS-L-3 protocol. 

champion device are presented in Fig. 4a and Extended Data Fig. 1. The reverse-scanning PCE increased from 24.06 to 26.41%, the _V_ oc increased from approximately 1.15 to approximately 1.21 V and fill factor (FF) increased from approximately 81.0 to approximately 85.0%. The measured short-circuit current ( _J_ sc) matched well with the _J_ sc obtained from measuring the external quantum efficiency. Notably, the _V_ oc of 1.21 V for our cell reached 96.6% of the radiative limit. The low voltage loss was validated by measuring the electroluminescence quantum efficiency (Supplementary Note 9). Furthermore, light-intensity-dependent _V_ oc measurements revealed an ideality factor close to 1, which correlates with the high FF of 85% (Fig. 4b). The PLQE data were used to calculate the QFLS for both pristine and IPA α-FA0.94Cs0.06PbI3 film-based stacks so that we could further understand the voltage loss<sup>32</sup> (Extended Data Fig. 4). Although both samples had similar bulk and electronic transport layer (ETL) interfacial contact losses, the IPA stack had a smaller _V_ oc loss when it was in contact with Spiro-OMeTAD compared to the pristine device. Additionally, there was a reduced mismatch between the calculated full-stack QFLS and attainable _qV_ oc for the IPA α-FA0.94Cs0.06PbI3 device, which had decreased from 13 to 3 meV compared to the pristine device. This indicates that there was a reduced band offset between IPA α-FA1− _x_ Cs _x_ PbI3 and Spiro-OMeTAD HTL, consistent with the analysis presented in Fig. 3. 

The Chinese National PV Industry Measurement and Testing Center validated one of our best-performing devices. A SPO efficiency of 

Nature | Vol 635 | 7 November 2024 | **87** 

## Article 

25.94% was achieved after MPP tracking for 300 s under continuous AM 1.5 G illumination (Fig. 4c). This certified efficiency is among one of the highest reported for perovskite single-junction cells. A statistical analysis of 36 pieces of PSCs demonstrated the excellent reproducibility of the approach (Fig. 4d). Additionally, we also fabricated a large-area device (1 cm<sup>2</sup> ) and a 10 × 10 cm<sup>2</sup> solar module (with a mask area of 66 cm<sup>2</sup> ), which had SPO efficiencies of 25.00% and 21.78%, respectively (Supplementary Note 7), demonstrating the robustness of the approach. 

Strong concerns have been raised regarding the thermal stability of PSCs containing methylammonium residue<sup>33</sup> . As expected, the IPA α-FA0.94Cs0.06PbI3 films did exhibit excellent thermal stability (Supplementary Note 10). Moreover, the IPA α-FA0.94Cs0.06PbI3 devices exhibited improved long-term stability (Extended Data Fig. 5). We, therefore, strictly examined their long-term stability under MPP conditions with continuous damp heat and illumination following the ISOS-L-3 testing protocol (85 °C and 60 ± 10% relative humidity). As shown in Fig. 4e, the IPA α-FA1− _x_ Cs _x_ PbI3 device maintained its initial PCE for the first 500 h and _T_ 95 > 2,000 h. Notably, the device had a minimal PCE decrement at high operating temperatures, maintaining a PCE of 23.0% at 85 °C, so that it ranks among the highest values for PSCs reported to date (Supplementary Table 2). In contrast, the pristine devices exhibited an approximately 10% relative PCE loss after 500 h of operation. 

#### **Online content** 

Any methods, additional references, Nature Portfolio reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41586-024-08103-7. 

1. Deng, Y. et al. Defect compensation in formamidinium-cesium perovskites for highly efficient solar mini-modules with improved photostability. _Nat. Energy_ **6** , 633–641 (2021). 

   - Park, N.-G., Grätzel, M., Miyasaka, T., Zhu, K. & Emery, K. Towards stable and commercially available perovskite solar cells. _Nat. Energy_ **1** , 16152 (2016). 

2. 

3. Liang, Z. et al. Homogenizing out-of-plane cation composition in perovskite solar cells. _Nature_ **624** , 557–563 (2023). 

4. Liu, S. et al. Buried interface molecular hybrid for inverted perovskite solar cells. _Nature_ **632** , 536–542 (2024). 

5. Jeong, J. et al. Pseudo-halide anion engineering for α-FAPbI3 perovskite solar cells. _Nature_ **592** , 381–385 (2021). 

6. Chen, R. et al. Reduction of bulk and surface defects in inverted methylammonium- and bromide-free formamidinium perovskite solar cells. _Nat. Energy_ **8** , 839–849 (2023). 

7. Li, H. et al. 2D/3D heterojunction engineering at the buried interface towards highperformance inverted methylammonium-free perovskite solar cells. _Nat. Energy_ **8** , 946–955 (2023). 

8. Green, M. A. et al. Solar cell efficiency tables (version 64). _Prog. Photovolt.: Res. Appl._ **32** , 425–441 (2024). 

9. Liu, X. et al. Stabilization of photoactive phases for perovskite photovoltaics. _Nat. Rev. Chem._ **7** , 462–479 (2023). 

10. Doherty, T. et al. Stabilized tilted-octahedra halide perovskites inhibit local formation of performance-limiting phases. _Science_ **374** , 1598–1605 (2021). 

11. Conings, B. et al. Intrinsic thermal instability of methylammonium lead trihalide perovskite. _Adv. Energy Mater._ **5** , 1500477 (2015). 

12. Bai, Y. et al. Initializing film homogeneity to retard phase segregation for stable perovskite solar cells. _Science_ **378** , 747–754 (2022). 

13. Park, J. et al. Controlled growth of perovskite layers with volatile alkylammonium chlorides. _Nature_ **616** , 724–730 (2023). 

14. Zhang, T. et al. Ion-modulated radical doping of spiro-OMeTAD for more efficient and stable perovskite solar cells. _Science_ **377** , 495–501 (2022). 

15. You, S. et al. Radical polymeric p-doping and grain modulation for stable, efficient perovskite solar modules. _Science_ **379** , 288–294 (2023). 

16. Chen, Y. et al. Strain engineering and epitaxial stabilization of halide perovskites. _Nature_ **577** , 209–215 (2020). 

17. Zhang, H. et al. Multimodal host-guest complexation for efficient and stable perovskite photovoltaics. _Nat. Commun._ **12** , 3383 (2021). 

18. Chen, H. et al. Regulating surface potential maximizes voltage in all-perovskite tandems. _Nature_ **613** , 676–681 (2023). 

19. Chen, S. et al. Crystallization in one-step solution deposition of perovskite films: upward or downward? _Sci. Adv._ **7** , eabb2412 (2021). 

20. Bu, T. et al. Modulating crystal growth of formamidinium-caesium perovskites for over 200 cm<sup>2</sup> photovoltaic sub-modules. _Nat. Energy_ **7** , 528–536 (2022). 

21. Saliba, M. et al. Cesium-containing triple cation perovskite solar cells: improved stability, reproducibility and high efficiency. _Energy Environ. Sci._ **9** , 1989–1997 (2016). 

22. Li, N. et al. Microscopic degradation in formamidinium-cesium lead iodide perovskite solar cells under operational stressors. _Joule_ **4** , 1743–1758 (2020). 

23. Qin, M. et al. Manipulating the mixed-perovskite crystallization pathway unveiled by in situ GIWAXS. _Adv. Mater._ **31** , 1901284 (2019). 

24. Yi, C. et al. Entropic stabilization of mixed A-cation ABX3 metal halide perovskites for high performance perovskite solar cells. _Energy Environ. Sci._ **9** , 656–662 (2016). 

25. Fu, Y. et al. Stabilization of the metastable lead iodide perovskite phase via surface functionalization. _Nano Lett._ **17** , 4405–4414 (2017). 

26. Lu, H. et al. Vapor-assisted deposition of highly efficient, stable black-phase FAPbI3 perovskite solar cells. _Science_ **370** , eabb8985 (2020). 

27. Yan, L. et al. Fabrication of perovskite solar cells in ambient air by blocking perovskite hydration with guanabenz acetate salt. _Nat. Energy_ **8** , 1158–1167 (2023). 

28. Ren, N. et al. Multifunctional additive CdAc2 for efficient perovskite-based solar cells. _Adv. Mater._ **35** , 2211806 (2023). 

29. Kim, B. J. & Boschloo, G. Beneficial effects of cesium acetate in the sequential deposition method for perovskite solar cells. _Nanoscale_ **13** , 11478–11487 (2021). 

30. Wang, C. et al. Enhancing performance of tin-based perovskite solar cells via fused-ring electron acceptor. _eScience_ **3** , 100113 (2023). 

31. Kirchartz, T., Márquez, J., Stolterfoht, M. & Unold, T. Photoluminescence-based characterization of halide perovskites for photovoltaics. _Adv. Energy Mater._ **10** , 1904134 (2020). 

32. Stolterfoht, M. et al. Visualization and suppression of interfacial recombination for high-efficiency large-area pin perovskite solar cells. _Nat. Energy_ **3** , 847–854 (2018). 

33. Zhang, H. & Park, N.-G. Towards sustainability with self-healing and recyclable perovskite solar cells. _eScience_ **2** , 567–572 (2022). 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law. 

© The Author(s), under exclusive licence to Springer Nature Limited 2024 

**88** | Nature | Vol 635 | 7 November 2024 

### **Methods** 

##### **Materials** 

SnO2 colloid solution was purchased from Alfa Aesar. Formamidinium iodide (FAI), lead iodide (PbI2), formamidinium formate (FAHCOO), FAAc, formamidinium tetrafluoroborate (FABF4), formamidinium thiocyanate (FASCN), caesium methanesulfonate (CsCH3SO3), caesium iodide (CsI), bis(trifluoromethane) sulfonimide lithium salt (Li-TFSI), 4-tertbutyl-pyridine ( _t_ BP), C60, bathocuproine, [2-(3,6-dim ethoxy-9H-carbazol-9-yl)ethyl]phosphonic acid (MeO-2PACz) and Spiro-OMeTAD were purchased from TCI, Sigma-Aldrich, Alfa Aesar, Lumtec (Luminescence Technology Corp.) and GreatCell Solar. All materials were used as received without further purification. 

##### **Device fabrication** 

**Fabrication of PSCs with n-i-p structure.** The SnO2 colloid solution was spin-coated onto the cleaned ITO substrates at 6,000 rpm for 30 s, followed by annealing at 150 °C for 30 min. FA0.94Cs0.06PbI3 perovskite precursor solution (1.4 M) was obtained by mixing FAI, CsI and PbI2 with 800 μl dimethylformamide and 200 μl dimethyl sulfoxide (DMSO) according to the stoichiometric ratio. Then, 2 mol% CsCl was introduced to increase the crystallinity. Next, 25 μl perovskite precursor solution was spin-coated onto the top of the SnO2 layer at a speed of 5,000 rpm for 35 s. After 20 s, 140 μl ethyl acetate was dropped onto the film, and the corresponding film was then annealed at 150 °C for 20 min. The hole transport material solution, which was a mixture of 72.3 mg Spiro-OMeTAD, 17.5 μl Li-TFSI (520 mg ml<sup>−1</sup> in acetonitrile) and 29 μl _t_ BP in 1 ml chlorobenzene, was deposited by spin-coating at a speed of 4,000 rpm for 30 s. We doped it as in the previous work to improve the thermal stability<sup>14</sup> . Finally, Au electrodes (80 nm) were thermally evaporated under a vacuum of 2 × 10<sup>−6</sup> torr at a rate of 0.05 nm s<sup>−1</sup> . The IPA FA0.94Cs0.06PbI3 perovskite films were prepared using the same method except that FAAc (0.07 M) was added. The devices were encapsulated as previously described<sup>34</sup> . 

**Fabrication of PSCs with p-i-n structure.** MeO-2PACz was dissolved in ethanol (1 mM) solution and spin-coated onto cleaned ITO substrates at 3,000 rpm for 30 s, which was followed by annealing at 100 °C for 10 min. The perovskite precursor was deposited onto the MeO-2PACz-modified substrate, as detailed above. The C60 (30 nm, 0.03 nm s<sup>−1</sup> ) and bathocuproine (7 nm, 0.01 nm s<sup>−1</sup> ) were deposited sequentially by thermal evaporation under a vacuum of 2 × 10<sup>−6</sup> torr. Finally, Ag electrodes (150 nm) were thermally evaporated at a rate of 0.05 nm s<sup>−1</sup> . 

**Fabrication of modules.** The SnO2 solution was blade-coated onto cleaned ITO substrates at a speed of 30 mm s<sup>−1</sup> and a substrate temperature of 70 °C. The gap between the blade coater and ITO substrate was 200 μm. The substrates were transferred onto a hotplate and annealed at 100 °C for 10 min in air. The perovskite precursor solution was blade-coated onto the SnO2 layer with a gap of 200 μm at a movement speed of 5 mm s<sup>−1</sup> in the N2 glovebox, and the corresponding film was then annealed at 150 °C for 20 min. The N2 knife worked at 60 psi during blade-coating. The Spiro-OMeTAD solution was deposited by spin-coating at a speed of 4,000 rpm for 30 s. Finally, Au electrodes (80 nm) were deposited by thermal evaporation. More details of the scribing of P1, P2 and P3 can be found in previous work<sup>35</sup> . 

##### **Characterization of solar cells** 

The solar cell devices were characterized in an N2 glovebox with a Keithley 2400 source meter under AM 1.5 G (Enli Tech). Instantaneous _J–V_ curves were measured at a scanning rate of 50 mV s<sup>−1</sup> (delay time of 200 ms) from 1.2 V to −0.1 V and then back. The modules were measured from 18.0 to −1.5 V and then back (scan rate approximately 2.0 V s<sup>−1</sup> ). The active areas were determined by masking the devices with a 4.9 mm<sup>2</sup> metal aperture to avoid edge effects for the small devices or with 1.0 cm<sup>2</sup> and 

66.0 cm<sup>2</sup> masks for the large devices and 10 × 10 cm<sup>2</sup> solar modules. The operational stability was measured by holding the devices at the MPP at a constant temperature of approximately 85 °C and an ambient humidity of 60 ± 10%. The light source was a 1 sun equivalent white LED. The devices tested in the MPP measurement had an architecture of ITO/SnO2/ perovskite/Spiro-OMeTAD/Au. The MPP was recorded every 30 min. 

##### **In situ and ex situ GIWAXS measurements** 

In situ GIWAXS experiments were conducted at the 1W1A beamline of the Beijing Synchrotron Radiation Facility and beamline BL17B of the Shanghai Synchrotron Radiation Facility. The X-ray wavelength was set to 1.54 Å in the annealing process, and two-dimensional scattering images were collected by the Pilatus 100K or Mar 345. A monochromatic beam of _λ_ = 1.24 Å was used for the spin-coating process. Various incident angles (0.3° and 3°) were used to investigate the spatial structure of the perovskite films. We used the DPDAK package based on Python 2.7 to extract line cuts from the two-dimensional scattering images<sup>36</sup> . All the line cuts were calibrated using ITO peaks through the GIXSGUI package<sup>37</sup> . 

##### **Film characterization** 

XRD patterns were recorded on an X-ray diffractometer (D8 ADVANCE, Bruker). The surface morphology and cross-sectional images of PSCs were characterized by field-emission scanning electron microscopy (JSM-7900F, JEOL). Time-resolved photoluminescence spectra were measured with a fluorescence spectrophotometer (FLS 980, Edinburgh Instruments). Absolute photoluminescence spectra of the samples were acquired using a high-resolution hyperspectral imaging system integrated with a microscope (Photon, etc. IMA) with a spectral resolution of 2 nm. The samples were excited by a 532 nm laser under approximately 1 sun illumination intensity. The acquired data were processed using a custom MATLAB code to extract the peak photoluminescence position and quantify the QFLS using a modified, generalized, Planck law. Laser-confocal photo-fluorescence (photoluminescence) measurements were collected using a confocal Raman spectrometer (Renishaw inVia). The UPS and X-ray photoelectron spectroscopy measurements were performed using a ThermoFisher Nexsa spectrometer. Cluster-etching was performed using large Ar clusters generated by a gas cluster ion source (Kratos Analytical Inc.) with an energy of 5 keV. For the electroluminescence analysis measurements, we first calibrated the integrating sphere-spectrometer system with an HL-3P-INT-CAL calibration source (Ocean Optics). The electroluminescence spectra were recorded concurrently with a fibre-coupled spectrometer (QE65 Pro, FOIS-1-FL integration sphere).<sup>1</sup> H nuclear magnetic resonance spectroscopy was measured with a liquid nuclear magnetic resonance spectrometer (600M, Bruker Avance). The solvent was DMSO- _d_ 6. 

##### **DFT calculations** 

First-principles calculations based on DFT were performed using the Vienna Ab initio Simulation Package<sup>38</sup> . The generalized gradient approximation of the Perdew–Burke–Ernzerhof functional served as the exchange-correlation functional<sup>39</sup> . To account for van der Waals interactions, the DFT-D3 method was employed<sup>40</sup> . A plane-wave cutoff energy of 400 eV was used, with energy and force convergence criteria set at 10<sup>−5</sup> eV and 0.02 eV Å<sup>−1</sup> , respectively. To calculate the DOS, we constructed slab structures for both Cs<sup>+</sup> -accumulated and homogeneous α-FA1− _x_ Cs _x_ PbI3 perovskite models (2 × 2 × 5 Pb-I layers). To calculate the respective DOS, distinct three-layer regions were selected for each Cs content. The corresponding formation energy ( _H_ f) of FA1− _x_ Cs _x_ PbI3 with different Cs contents ( _x_ ) was calculated as: 



<!-- Start of picture text -->
H f = E (FA1− x Cs x PbI3) −(PbI E 2) − xE (CsI) −(1 −) x E (FAI)<br><!-- End of picture text -->

where _E_ (FA1− _x_ Cs _x_ PbI3), _E_ (PbI2), _E_ (CsI) and _E_ (FAI) are the total energies of FA1− _x_ Cs _x_ PbI3, PbI2, CsI and FAI, respectively. The free energy of mixing (Δ _F_ ) was calculated as follows: 

## Article 

∆( _F x_ , _T_ ) = ∆( _U x_ ) − _T_ ∆( _S x_ ), 



<!-- Start of picture text -->
∆( U x ) = U FACs −(1 −) x U FA − xU Cs,<br><!-- End of picture text -->



<!-- Start of picture text -->
∆( S x ) = − k B[ x ln x + (1 −) ln(1 −)], x x<br><!-- End of picture text -->

where Δ _U_ ( _x_ ) is the mixing enthalpy and Δ _S_ ( _x_ ) is the mixing entropy. _U_ FACs, _U_ FA and _U_ Cs are the energies of FA1− _x_ Cs _x_ PbI3, pure FAPbI3 and pure CsPbI3, respectively. _k_ B is the Boltzmann constant. The migration barrier along the migration path was determined by the climbing-image nudged elastic band method<sup>41</sup> . Five images were selected for each migration path. To calculate the binding energy, we constructed a slab structure at an intermediate phase (hexagonal perovskite) with 20 Å spacing in the _c_ direction. We then replaced the surface iodine with different pseudo-halides (CH3SO3−, BF4−, HCOO− or CH3COO−). To estimate the relative binding strength, the adsorbed anions were displaced along the _c_ direction away from the surface. The formation energies ( _E_ f) of iodine substituted by pseudo-halide anion ( _X_ I) at the α- and δ-phase surfaces were calculated as follows: 



<!-- Start of picture text -->
E f( α phase) = E ( X I, α phase) −(pure, E α phase) −( μ X ) + μ (I),<br><!-- End of picture text -->



<!-- Start of picture text -->
E f( δ phase) = E ( X I, δ phase) −(pure, E δ phase) −( μ X ) + μ (I),<br><!-- End of picture text -->

where _X_ = BF4−, HCOO−, CH3COO− or CH3SO3−, and _E_ ( _X_ I, α phase) and _E_ (pure, α phase) are the total energies of the α-phase surface with a substituted pseudo-halide anion and the pure α-phase surface without pseudo-halide anions, respectively. Similarly, _E_ ( _X_ I, _δ_ phase) and _E_ (pure, _δ_ phase) denote the total energies of the δ-phase surface with a substituted pseudo-halide anion and the pure _δ_ -phase surface without pseudo-halide anions, respectively. _μ_ ( _X_ ) and _μ_ (I) are the chemical potentials of pseudo-halide anions and iodine, respectively. The relative formation energies of the intermediate phase induced by different pseudo-halide anions were defined as the energy difference between _E_ f(δ phase) and _E_ f(α phase). 

##### **AIMD simulations** 

The AIMD simulations were performed with the CP2K package<sup>42</sup> . We constructed a model of the perovskite precursor solution with a mixture of ions and molecules: six Pb<sup>2+</sup> , nine I<sup>−</sup> , nine Ac<sup>−</sup> , five FA<sup>+</sup> , one Cs<sup>+</sup> , four DMSO and 16 dimethylformamide. All ions and molecules were evenly distributed in the initial configuration, which was constructed with the Packmol software<sup>43</sup> . The AIMD simulations were run for 14 ps in the constant-pressure and -temperature (NPT) ensemble and then for 12 ps in the constant-volume and -temperature (NVT) ensemble. The temperature was maintained at 300 K with a Nosé–Hoover thermostat<sup>44</sup> . The pressure was set to atmospheric pressure ( _P_ = 1 bar), and the time step was set to 1.0 fs. The PBE-D3 functional was used with double-zeta basis sets (DZVP-MOLOPT)<sup>45</sup> and Goedecker–Teter–Hutter pseudopotentials<sup>46</sup> . The cutoff was set to 560 Ry. Specially, more details, including atomistic models and methodologies, are available in the Supplementary Information. 

#### **Data availability** 

All data are available in the Article or the Supplementary Information. Other data that support the findings of this study are available from the corresponding author upon reasonable request. 

34. Shi, L. et al. Gas chromatography-mass spectrometry analyses of encapsulated stable perovskite solar cells. _Science_ **368** , eaba2412 (2020). 

35. Gao, H. et al. Homogeneous crystallization and buried interface passivation for perovskite tandem solar modules. _Science_ **383** , 855–859 (2024). 

36. Benecke, G. et al. A customizable software for fast reduction and analysis of large X-ray scattering data sets: applications of the new DPDAK package to small-angle X-ray scattering and grazing-incidence small-angle X-ray scattering. _J. Appl. Crystallogr._ **47** , 1797–1803 (2014). 

37. Jiang, Z. GIXSGUI: a MATLAB toolbox for grazing-incidence X-ray scattering data visualization and reduction, and indexing of buried three-dimensional periodic nanostructured films. _J. Appl. Crystallogr._ **48** , 917–926 (2015). 

38. Kresse, G. & Furthmüller, J. Efficient iterative schemes for ab initio total-energy calculations using a plane-wave basis set. _Phys. Rev. B_ **54** , 11169–11186 (1996). 

39. Perdew, J., Burke, K. & Ernzerhof, M. Generalized gradient approximation made simple. _Phys. Rev. Lett._ **77** , 3865–3868 (1996). 

40. Lee, K. et al. Higher-accuracy van der Waals density functional. _Phys. Rev. B_ **82** , 081101 (2010). 

41. Henkelman, G., Uberuaga, B. & Jónsson, H. A climbing image nudged elastic band method for finding saddle points and minimum energy paths. _J. Chem. Phys._ **113** , 9901–9904 (2000). 

42. Kühne, T. D. et al. CP2K: An electronic structure and molecular dynamics software package-Quickstep: efficient and accurate electronic structure calculations. _J. Chem. Phys._ **152** , 194103 (2020). 

43. Martínez, L., Andrade, R., Birgin, E. G. & Martínez, J. M. PACKMOL: a package for building initial configurations for molecular dynamics simulations. _J. Comput. Chem._ **30** , 2157–2164 (2009). 

44. Nosé, S. A unified formulation of the constant temperature molecular dynamics methods. _J. Chem. Phys._ **81** , 511–519 (1984). 

45. VandeVondele, J. & Hutter, J. Gaussian basis sets for accurate calculations on molecular systems in gas and condensed phases. _J. Chem. Phys._ **127** , 114105 (2007). 

46. Goedecker, S., Teter, M. & Hutter, J. Separable dual-space Gaussian pseudopotentials. _Phys. Rev. B_ **54** , 1703–1710 (1996). 

**Acknowledgements** This work is financially supported by the National Science Fund for Distinguished Young Scholars (Grant No. T2225024) and the Foundation for Innovative Research Groups of the National Natural Science Foundation of China (Grant No. 22121005). We extend our appreciation to the Deputyship for Research and Innovation, Ministry of Education in Saudi Arabia for funding this research work (Project No. IFKSU-DSR-NS1). We thank the staff of beamlines BL02U2, BL17B1, BL14B1, BL19U2 and BL01B1 at the Shanghai Synchrotron Radiation Facility for providing the beam time and the staff of the User Experiment Assist System of the Shanghai Synchrotron Radiation Facility for their help. This work was partly supported by Analysis Platform of New Matter Structure at Nankai University. 

**Author contributions** M.Y., Y.J. and S.L. conceived the idea. M.Y., J.C. and E.H.S. supervised the project. S.L., D.W. and Z.D. fabricated the devices. J.X. and T.Z. did the DFT calculations. S.L., D.W., Y.C., Y.Y., R.G. and Z.D. were responsible for the GIWAXS characterization. S.L., D.W., Z.D., C.S. and K.W. carried out the electrical and optical characterizations. S.M.H.Q. performed the device simulations. M.Y., Y.J., S.L. and E.H.S. co-wrote the manuscript. All authors contributed to the discussion and commented on the manuscript. 

**Competing interests** The authors have filed a provisional patent for this work with the China National Intellectual Property Administration. The authors declare no other competing interests. 

###### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41586-024-08103-7. 

**Correspondence and requests for materials** should be addressed to Edward H. Sargent or Mingjian Yuan. 

**Peer review information** _Nature_ thanks Wei Chen, Jun Zhu and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. **Reprints and permissions information** is available at http://www.nature.com/reprints. 



**Extended Data Fig. 1 | Device characterization. a** - **d** , Comparison of ( **a** ) PCE, ( **b** ) _FF_ , ( **c** ) _J_ sc, and ( **d** ) _V_ oc for pristine and IPA _α_ -FA0.94Cs0.06PbI3-based devices. The _V_ oc, _J_ sc, _FF_ , and PCE were extracted from 36 devices’ reverse scan _J-V_ curves. **e** , _J-V_ curves of our champion pristine _α_ -FA0.94Cs0.06PbI3 device. The detailed 

performance parameters are inserted in the figure. **f** , EQE spectra and integrated current ( _J_ sc) of the IPA _α_ -FA0.94Cs0.06PbI3 device. By integrating the EQE over the AM 1.5 G standard spectrum, the integrated _J_ sc of IPA _α_ -FA0.94Cs0.06PbI3 device is 26.27 mA cm<sup>−2</sup> . 

Article 



**Extended Data Fig. 2 | Incident-angle-dependent XRD measurements. a** , Calculated probing depth as a function of X-ray incident angle ( _α_ i). **b** , Calculated (100) Bragg peak position of _α_ -FA1- _x_ Cs _x_ PbI3 as a function of Cs<sup>+</sup> content. **c** , **d** , GIXRD patterns for ( **c** ) pristine and ( **d** ) IPA _α_ -FA1- _x_ Cs _x_ PbI3 films with different probing depths. By increasing the _α_ i of X-ray radiation, we observed a shift towards lower angles in the (100) diffraction peak signal. The phenomenon 

we attributed to a lattice constant reduction in the top-zone of pristine film; and a nominal formula of FA0.7Cs0.3PbI3 is derived here according to Vegard’s law. In contrast, the IPA _α_ -FA1- _x_ Cs _x_ PbI3 films exhibited a constant peak position, indicating a uniform composition distribution vertically. Notably, these results were further corroborated by the XPS depth profiles in Supplementary Note 2. 



**Extended Data Fig. 3 | PL mapping of the buried interfaces. a** , **b** , PL images ( **a** ) and histograms of pristine and IPA _α_ -FA0.94Cs0.06PbI3 films ( **b** ) before and after ageing in ambient for one month. The PL images were taken from the buried interface sides. As shown, the pristine _α_ -FA0.94Cs0.06PbI3 film exhibits significantly reduced PL intensity, and nonuniform PL emission across 

different areas. The phenomenon indicates that increased defect density at the buried interface arises after ageing. In contrast, no notable PL quenching and inhomogeneity were observed in the aged IPA _α_ -FA0.94Cs0.06PbI3 films. The results are consistent with SEM and GIXRD measurements in Supplementary Note 8. 

## Article 



**Extended Data Fig. 4 | QFLS analysis. a** , PLQE and calculated QFLS statistics of the neat IPA _α_ -FA0.94Cs0.06PbI3 films, and the IPA _α_ -FA0.94Cs0.06PbI3 film with transport layer stacks. **b** , PLQE and QFLS statistics for pristine and IPA _α_ -FA0.94 Cs0.06PbI3-based full stacks. **c** , The QFLS, Shockley-Queisser radiative limit, and the experimental _V_ oc for pristine and IPA _α_ -FA1- _x_ Cs _x_ PbI3 based devices. We found 

a substantial contact loss at the interface between the pristine _α_ -FA0.94Cs0.06PbI3 film and the HTL. While, for the IPA _α_ -FA0.94Cs0.06PbI3, the elimination of surface Cs<sup>+</sup> accumulation within perovskite film could effectively reduce the _V_ oc-loss of devices. 



**Extended Data Fig. 5 | Device long-term stability. a** - **d** , Statistics of ( **a** ) _V_ oc, ( **b** ) _J_ sc, ( **c** ) _FF_ , and ( **d** ) PCEs for pristine and IPA _α_ -FA0.94Cs0.06PbI3-based devices with different ageing durations; the corresponding parameters are extracted from 36 devices’ reverse scan _J-V_ curves, and the devices were stored in a dark environment with a relative humidity of 30% at room temperature. For the 

device storage, we found that the PCEs of the pristine _α_ -FA0.94Cs0.06PbI3 undergo a rapid decline, while the IPA _α_ -FA0.94Cs0.06PbI3 exhibited no significant reduction over the entire ageing duration. Thus, we conclude that the IPA strategy can effectively stabilize absolutely MA-free _α_ -FA1- _x_ Cs _x_ PbI3 and also promote the devices’ stability. 

