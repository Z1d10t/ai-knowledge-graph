# Ion-modulated radical doping of spiro-OMeTAD for more efficient and stable perovskite solar cells

| 字段 | 内容 |
|---|---|
| 期刊 | Science |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 309 |
| 作者 | Tian-Kai Zhang, Feng Wang, Hak-Beom Kim, In-Woo Choi, Chuanfei Wang, Eunkyung Cho, R. Konefał, Y. Puttisong et al. |
| DOI | 10.1126/science.abo2757 |
| 源文件 | 056_Zhang_2022_Ion-modulated-radical-doping-of-spiro-OMeTAD-for.pdf |

---
Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

20 

25 

30 

# **Ion-modulated radical doping of Spiro-OMeTAD for more efficient and stable perovskite solar cells** 

Tiankai Zhang<sup>1</sup> †, Feng Wang<sup>1</sup> †*, Ha-Beom Kim<sup>2</sup> , In-woo Choi<sup>2</sup> , Chuanfei Wang<sup>3</sup> , Eunkyung Cho<sup>4</sup> , Rafal Konefal<sup>5</sup> , Yuttapoom Puttisong<sup>1</sup> , Kosuke Terado<sup>6,7</sup> , Libor Kobera<sup>5</sup> , Mengyun Chen<sup>1</sup> , Mei Yang<sup>1</sup> , Sai Bai<sup>1</sup> , Bowen Yang<sup>8,9</sup> , Jiajia Suo<sup>8,9</sup> , Shih-Chi Yang<sup>10</sup> , Xianjie Liu<sup>3</sup> , Fan Fu<sup>10</sup> , Hiroyuki Yoshida<sup>6,7</sup> , Weimin M. Chen<sup>1</sup> , Jiri Brus<sup>5</sup> , Veaceslav Coropceanu<sup>4</sup> , Anders Hagfeldt<sup>8,9</sup> , Jean‐Luc Brédas<sup>4</sup> , Mats Fahlman<sup>3</sup> , Dong Suk Kim<sup>2</sup> , Zhangjun Hu<sup>1</sup> , Feng Gao<sup>1</sup> * 

1Department of Physics, Chemistry and Biology (IFM), Linköping University; 58183 Linköping, Sweden 

2Korea Institute of Energy Research (KIER); Ulsan, Republic of Korea 

3Laboratory of Organic Electronics, Department of Science and Technology, Linköping University; 60174, Norrköping, Sweden 

15 

4Department of Chemistry and Biochemistry, The University of Arizona; Tucson, Arizona, 85721-0088, USA 

5Institute of Macromolecular Chemistry of the Czech Academy of Sciences; Prague, Czech Republic 

6Graduate School of Engineering, Chiba University; 1-33 Yayoi-cho, Inage-ku, Chiba, 2638522, Japan 

7Molecular Chirality Research Center, Chiba University; 1-33 Yayoi-cho, Inage-ku, Chiba, 263-8522, Japan 

8Laboratory of Photomolecular Science (LSPM), École Polytechnique Fédérale de Lausanne; Station 6, CH-1015 Lausanne, Switzerland 

9Department of Chemistry, Ångström Laboratory, Uppsala University; Box 523, SE-751 20 Uppsala, Sweden. 

10Laboratory for Thin Films and Photovoltaics, Empa–Swiss Federal Laboratories for Materials Science and Technology; Ueberlandstrasse 129, Duebendorf, CH-8600 Switzerland 

*Corresponding author. Email: feng.wang@liu.se (F.W.); feng.gao@liu.se (F.G.) †These authors contributed equally to this work. 

35 

40 

**Abstract:** Record power conversion efficiencies (PCEs) of perovskite solar cells (PSCs) have been obtained with the organic hole transporter 2,2′,7,7′-tetrakis(N,N-di-p-methoxyphenylamine)9,9′-spirobifluorene (spiro-OMeTAD). Conventional doping of spiro-OMeTAD with hygroscopic lithium salts and volatile 4-tert-butylpyridine is a time-consuming process and also leads to poor device stability. We developed a new doping strategy for spiro-OMeTAD that avoids post oxidation by using stable organic radicals as the dopant and ionic salts as the doping modulator (referred as _ion-modulated (IM) radical doping_ ). We achieved PCEs > 25% and much improved device stability under harsh conditions. The radicals provide hole polarons that instantly increase the conductivity and work function, and ionic salts further modulate the work function (WF) by affecting the energetics of the hole polarons. This organic semiconductor doping strategy, which decouples conductivity and work function tunability, could inspire further optimizations in other optoelectronic devices. 

1 

This document is the accepted manuscript version of the following article: Zhang, T., Wang, F., Kim, H. B., Choi, I. W., Wang, C., Cho, E., … Gao, F. (2022). Ion-modulated radical doping of spiro-OMeTAD for more efficient and stable perovskite solar cells. Science, 377(6605), 495-501. https://doi.org/10.1126/science.abo2757 

Submitted Manuscript: Confidential Template revised February 2021 

**One-Sentence Summary:** Instantly effective doping of spiro-OMeTAD realizes efficient and robust perovskite solar cells, offering new insights for organic semiconductors doping. 

2 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

15 

20 

25 

35 

Metal halide perovskites have achieved impressive power conversion efficiencies (PCEs) in both single junction ( _1-6_ ) and tandem solar cells ( _7, 8_ ). However, a key challenge limiting their practical applications lies in the trade-off between high efficiency and high stability, an issue determined by not only the perovskite materials ( _9_ ) but also the charge transport layers ( _10_ ). Currently, most high-performance perovskite solar cells (PSCs) with > 24% PCE are based on the bench-mark hole transport layer (HTL) spiro-OMeTAD doped by lithium bis(trifluoromethane)sulfonimide (LiTFSI) and 4- _tert_ -butylpyridine (tBP) ( _11-13_ ), a process that, limits the stability of these high-efficiency PSCs. 

Conventional spiro-OMeTAD doping (left part of **Fig. 1A** ) involves LiTFSI to facilitate the generation of spiro-OMeTAD<sup>·+</sup> TFSI<sup>−</sup> radicals and tBP to improve dopants solubility and film morphology ( _14_ ). This recipe usually requires an in-situ oxidization process for a period of 10 to 24 hours in air to reach the optimal conductivity and work function (WF) ( _15_ ). However, because of the low doping efficiency of this process, a large amount of dopants and additives (~56 mol% LiTFSI and ~330 mol% tBP) are required to generate ~10 mol% radicals ( _16_ ). The residual LiTFSI, tBP and byproducts (e.g., LixOy) are not only diffusible ( _17_ ) but also sensitive to humidity and heat ( _18_ , _19_ ), which affects device stability. 

In addition, the complex in-situ oxidation process makes it challenging to understand the mechanism of conventional spiro-OMeTAD doping, which limits further development of stable HTLs with high PCEs. Several efforts addressing the stability issue related to the conventional doping of spiro-OMeTAD have focused on the hygroscopic lithium salt. For example, a CO2 gas-forming treatment was recently used to remove the hygroscopic lithium species ( _20_ ). Less hygroscopic dopants, including metallic salts ( _21-23_ ), protic ionic liquids ( _24_ ) and ex-situ synthesized spiro-OMeTAD<sup>2·+</sup> (TFSI<sup>−</sup> )2 radicals ( _25_ , _26_ ), have also been used to replace the oxidant LiTFSI. However, such doping usually requires adding volatile tBP. The role that tBP plays in the doping process has been controversial ( _27_ , _28_ ). Particularly, tBP would react with radicals and coordinate with LiTFSI to form byproducts (left part of **Fig. 1A** ), which not only negatively impacts device performance but also prevents a full understanding of the spiroOMeTAD doping mechanism. 

30 

40 

We develop a stable doping strategy for instant and effective doping of spiro-OMeTAD [right part of **Fig. 1A,** denoted as ion-modulated (IM) radical doping] that relies on two components. <mark>One is the pre-synthesized stable spiro-OMeTAD</mark><sup>2·+</sup> <mark>(TFSI</mark><sup>−</sup> <mark>)</mark> 2 <mark>radical (synthesis and characterizations in</mark> **<mark>figures S1</mark>** <mark>and</mark> **<mark>S2</mark>** <mark>,), which acts as the main dopant to improve conductivity and WF.</mark> The second is the ionic salt 4- _tert_ -butyl-1-methylpyridinium 

bis(trifluoromethylsulfonyl)imide (TBMP<sup>+</sup> TFSI<sup>−</sup> ) to further modulate the WF. In this doping, the localized ionic environment created was used to manipulate the energetics of the hole polarons and decouple the conductivity and WF tunability. The doped spiro-OMeTAD based on our IM radical doping strategy delivered PSCs simultaneously with high efficiency (PCE > 25%) and high stability (T80 for ~ 1200 h under 70±5% relative humidity (RH) and T80 for ~ 800 h under 70±3 °C without encapsulation), minimizing the trade-off between efficiency and stability of PSCs. In addition, the IM radical doping strategy provides a facile yet effective approach to separately optimize the conductivity and WF of organic semiconductors for a variety of optoelectronic applications. 

## **Results** 

The distinctive effects of conventional and IM radical doping of spiro-OMeTAD are compared using (FAPbI3)0.99(MAPbBr3)0.01 (where FA is formamidinium and MA is methylammonium) 

45 

3 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

15 

20 

25 

PSCs with an SnO2 electron transport layer ( **Fig. S3** ) ( _12_ ). The conventional spiro-OMeTAD doping process requires an oxidation time of around 24 h to reach the optimized PCE of 22.2% ( **Fig. 1B, fig. S4A** and **Table S1** ). The gradual improvement in device performance with increasing oxidation time is consistent with the conductivity increase ( **fig. S5A** ) that resulted from the continuous generation of spiro-OMeTAD<sup>·+</sup> TFSI<sup>−</sup> radicals, as evidenced by the ultraviolet-visible-near infrared (UV-Vis-NIR) absorption spectra ( **fig. S5B** ) ( _29, 30_ ). 

In our IM spiro-OMeTAD doping strategy, the first additive consists of pre-synthesized spiroOMeTAD<sup>2·+</sup> (TFSI<sup>−</sup> )2 biradicals ( _31_ , _32_ ) which can be immediately converted into spiroOMeTAD<sup>·+</sup> TFSI<sup>−</sup> monoradicals through comproportionation with the neutral spiro-OMeTAD ( _27_ ): 

spiro-OMeTAD + spiro-OMeTAD<sup>2·+</sup> (TFSI<sup>-</sup> )2 → 2 spiro-OMeTAD<sup>·+</sup> TFSI<sup>−</sup> (1) 

We note that more radical cations (and hence a higher conductivity) are obtained at lower dopant levels using the current approach than using LiTFSI, as indicated by absorption spectra and conductivity measurements ( **fig. S5** ). Upon the incorporation of radicals, the device performance improved compared with the undoped spiro-OMeTAD ( **fig. S4B** ), and an optimal performance was reached with the doping radical ratio of ~14 mol% (calculated to the ratio of monoradicals). However, compared to a high open-circuit voltage ( _V_ OC) of 1.15 V achieved with the conventional doping recipe, the optimized _V_ OC of spiro-OMeTAD doped with radicals was 1.04 V ( **Fig. 1B** ). 

Upon addition of the second additive (ionic salt, TBMP<sup>+</sup> TFSI<sup>−</sup> ), the _V_ OC of the solar cells increased and a _V_ OC of 1.17 V was achieved with 20 mol% TBMP<sup>+</sup> TFSI<sup>−</sup> . The resulting PCE of 23.4% was even higher than that resulting from the conventional doping ( **Fig. 1B** ). Further increasing the TBMP<sup>+</sup> TFSI<sup>−</sup> content led to a decrease in the fill factor (FF) ( **fig. S4C** and **Table S2** ) because of ionic aggregation ( **fig. S6** ). 

30 

35 

40 

The high _V_ OC of the optimized devices was also consistent with the values of electroluminescence external quantum efficiency (ELEQE), which increased from 0.05% to 5.4% upon the addition of 20 mol% <mark>TBMP</mark><sup>+</sup> <mark>TFSI</mark><sup>−</sup> into the HTL ( **fig. S7** ), indicating reduced nonradiative recombination. Remarkably, based on the meso-TiO2 scaffold with FAPbI3 as the active layer, the IM radical doping of spiro-OMeTAD delivered a PCE of 25.1% ( **Table S3** , certified 25.0% **fig. S8** ), which was again higher than that of the control device with conventionally doped spiro-OMeTAD ( **Fig. 1C** ). The PCE statistics demonstrated that the IM radical doping strategy, which did not involve a post oxidation process, was more controllable compared to conventional doping process ( **fig. S9** ). 

Because the IM radical doping strategy completely removed the need to use hygroscopic LiTFSI and volatile tBP, an improved device stability can be expected. We systematically compared the device stability with IM radical doping versus conventional doping as a function of RH, heat, and illumination. Compared with the conventional doping of spiro-OMeTAD, the IM radical doping strategy extended the T80 of PSCs (unencapsulated) from ~96  to ~1240 hours under high RH of ~70±5% ( **Fig. 1D** and **fig. S10** ), and T80 from ~264  to ~796 hours under ~70±3 °C ( **Fig. 1E** and **fig. S11** ). The improved device stability with the IM radical doped HTL was ascribed to not only the improved stability of HTL but also the prevention of phase and thermal degradation of the perovskite active layer under high RH and under heat stress, as evidenced from optical images ( **fig. S12** ) and XRD results ( **figures S13** and **S14** ) of the degraded devices. 

4 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

15 

20 

25 

The SEM images provided more details into the protection effect from the spiro-OMeTAD HTL based on IM radical doping. A large number of pinholes were observed in degraded devices based on the conventionally doped HTLs, implying that LiTFSI residuals absorbed moisture and that tBP volatilized gradually. Both effects accelerated the degradation of the perovskite active layer ( **figures S15** and **S16** ). In contrast, the devices based on the IM radical doping strategy maintained a compact and uniform morphology after long-term exposure to high RH and thermal stress ( **figures S15** and **S17** ), indicating the inhibition of both yellow-phase degradation of FAPbI3 and release of FAI. In addition, under maximum power point (MPP) tracking, the PCEs of PSCs based on conventional doping decay to ~85% after 500 h continuous illumination. Devices based on the IM radical doping strategy maintained ~95% of the initial PCE after the same operational time ( **fig. S18** ), which is similar to that of devices that use inorganic HTLs ( _33_ , _34_ ) or undoped polymer HTLs ( _35_ ). 

Our IM radical doping strategy provided an instantly effective and stable doping of spiroOMeTAD. In addition, this simple process allowed us to decouple and investigate the fundamental functions of additives (radicals and ionic salts). We focus on two physical parameters which are key to the effectiveness of the HTL, conductivity and energetic levels, both WF and ionization energy (IE). 

To investigate the HTL conductivity, we used hole-only devices with the structure ITO/PEDOT:PSS/doped spiro-OMeTAD/Au, where ITO is indium tin oxide, PEDOT is poly(3,4-ethylenedioxythiophene), and PSS is polystyrene sulfonate. The effects of organic radicals on the film conductivity ( **Fig. 2, A** and **B** ) showed two distinct stages as a function of an increasing amount of organic radicals. There was initially an extremely high doping efficiency with a small doping ratio of radicals (< 2 mol%, marked by the light blue area in **Fig. 2B** ) which suggested efficient hole polaron generation. Particularly, 0.1 mol% of radicals could increase the conductivity of the film by almost four orders of magnitude, from 1.10 × 10<sup>‒8</sup> S cm<sup>‒1</sup> to 8.03 × 10<sup>‒5</sup> S cm<sup>‒1</sup> . This increase could be attributed to the filling of deep trap states by dopantgenerated charge carriers which brings increased carrier concentration as well as higher carrier mobility ( _36_ ). 

30 

35 

40 

45 

For higher doping concentrations, the hole-only current density exhibits a linear dependence over the entire voltage range from 0 V to 5 V, indicative of a high hole concentration in the system. In the second stage (doping ratio from 2 mol% to 60 mol%, marked by the light red area), the doping efficiency nearly saturated and the conductivity peaked at around 1.00 × 10<sup>‒3</sup> S cm<sup>‒1</sup> at ~14 mol% radicals ( **Fig. 2B** ). This doping saturation phenomenon was consistent with what have been previously reported in other organic semiconductor systems, and is ascribed to the increase in energetic disorder induced by long-range Coulomb interactions when increasing the number of charge carriers ( _37_ ). The addition of the TBMP<sup>+</sup> TFSI<sup>−</sup> ionic salt had negligible effects on the film conductivity over a wide range of concentrations (up to 20 mol%) ( **Fig. 2C** ), beyond which a slight decrease in film conductivity is observed, possibly because of the aforementioned phase aggregation and increased disorder in the film (see below). 

In addition to conductivity, the energetic level alignment at the HTL interface is another parameter that is critically important to device performance. An optimal energetic level of the HTL helped facilitate hole extraction and eliminated interfacial non-radiative recombination, which contributed to high device performance (especially high _VOC_ ). We investigated the impact of the radicals on the relevant energetic levels by ultraviolet photoelectron spectroscopy (UPS). For the pristine spiro-OMeTAD, the ionization energy (IE) was 5.08 eV, which according to Koopmans theorem ( _38_ ) corresponds to the energy of highest occupied molecular orbital 

5 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

15 

20 

25 

30 

35 

40 

(HOMO), and the WF was 4.36 eV ( **fig. S19A** ). The density functional theory (DFT) results showed that the IE of an isolated spiro-OMeTAD molecule is about 5.46 eV and this value decreased to 5.03 eV when the calculations were performed by taking into account an effective medium with a dielectric constant of 2.4 ( **Fig. S20** ). 

<mark>With increasing amounts of radicals, both IE and WF increased (</mark> **<mark>Fig. 2D</mark>** <mark>). The increased IE is ascribed to the intermolecular interactions destabilizing the hole in spiro-OMeTAD formed by photoionization (</mark> _<mark>39</mark>_ <mark>). A more detailed comparison revealed the difference between WF and IE decreases along with increasing dopant concentration (</mark> **<mark>Fig. 2D</mark>** <mark>), emphasizing the extent to which the Fermi level moves towards the HOMO level, which is a key signature of p-doping.</mark> Combining with the conductivity results in **Fig. 2B** , we noticed that a radical concentration > 2 mol% could affect the energetic levels of the film despite almost no improvement in conductivity. The shift of energetic levels saturated at ~ 14 mol% radical doping, which is due to the charge transfer and hole generation efficiency limit ( _37_ ). 

Based on the 14 mol% radical doped system, we further assessed the effect of the TBMP<sup>+</sup> TFSI<sup>−</sup> ionic salt on the film energetic levels. In contrast to the simultaneous change of the HOMO level and WF upon the addition of radicals, the ionic salt increased the WF to 5.08 eV with 20 mol% TBMP<sup>+</sup> TFSI<sup>−</sup> but had a negligible effect on the HOMO levels ( **fig. S19B** and **Fig. 2E** ). The slightly decreased WF with 30% TBMP<sup>+</sup> TFSI<sup>−</sup> was ascribed to the effects of ion aggregation ( **fig. S6** ). <mark>As such, the addition of TBMP</mark><sup>+</sup> <mark>TFSI</mark><sup>−</sup> <mark>breaks the doping limit of radical doping, resulting a Fermi level which is very close to the HOMO level (with a small difference of 0.12 eV, a value much smaller than those in traditional organic semiconductor doping). The promoted doping efficiency after TBMP</mark><sup>+</sup> <mark>TFSI</mark><sup>−</sup> <mark>incorporation is also confirmed by the increased carrier concentration, as indicated from Mott–Schottky (MS) analysis (</mark> **<mark>Fig. S21</mark>** <mark>).</mark> 

In PSCs, as long as the HOMO energy of the HTL remains above the valence band of perovskites, it has little impact on the device _V_ OC value. For example, different HTLs with HOMO energies between −5.2 and −5.4 eV have almost the same _J_ - _V_ curves ( _40_ ). Within a suitable HOMO energy range, an optimal WF of the HTL aligned with the quasi-Fermi-level (QFL) of the perovskite active layer is critical to minimizing the voltage loss ( _41_ , _42_ ). As illustrated in **Fig. 2F** , the increase of the WF by the TBMP<sup>+</sup> TFSI<sup>−</sup> reduced the hole extraction barrier between the perovskite and the IM radical doped HTL film. This change enables a high QFL splitting in the perovskites under illumination by eliminating the interfacial non-radiative recombination loss. Thus, this WF modulation by the ionic salt is important, as this _VOC_ improvement made it possible for the device based on our IM radical doping strategy to reach a performance comparable to that of a device based on the conventional doping (refer to **Fig. 1B** and **Fig. 1C** ). 

## **Discussion** 

From these conductivity and energetic level investigations, the different functions assumed by the organic radicals and ionic salts become clear. The radicals enhance the conductivity and affect the energetic levels (both HOMO and WF); the ionic salts further optimize the WF and contribute to optimal _VOC_ values in the devices. 

The effectiveness of the radicals to tune the conductivity and energy levels can be understood with a charge transfer model between neutral spiro-OMeTAD and the spiro-OMeTAD<sup>·+</sup> TFSI<sup>−</sup> radical. For neutral spiro-OMeTAD, the Fermi level ( _E_ F) corresponds to an energy about midway between the lowest unoccupied molecular orbital (LUMO) and HOMO levels ( **Fig. S20** ). The low film conductivity in the absence of dopant can be understood by poor film crystallinity 

45 

6 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

15 

20 

25 

35 

and low charge carrier concentrations, which are determined by thermal excitation of charge carriers from HOMO to LUMO levels. 

Upon radical doping, spiro-OMeTAD<sup>·+</sup> TFSI<sup>−</sup> provides additional electronic states ( _43_ ) ( **figures S22** , **S23** and **S24** ), specifically bound hole states corresponding to singly unoccupied molecular orbitals (SUMO) levels stabilized by Coulombic attraction from the TFSI<sup>−</sup> counter ion. Electron transfer from neutral spiro-OMeTAD (host) to spiro-OMeTAD<sup>·+</sup> TFSI<sup>−</sup> radical complex (dopant) led to the generation of free hole polarons and increased the conductivity ( **Fig. 3A** ). Concurrently, the hole filling of the transport states downshifted the Fermi level and increased the WF ( **Fig. 2D** ) ( _44_ , _45_ ). 

We now turn to a discussion of how ionic salts can further tune the WF. We did not observe oxidation or reduction between ionic salt and neutral spiro-OMeTAD/spiro-OMeTAD<sup>·+</sup> TFSI<sup>−</sup> ( **figures S25** and **S26** ). A straightforward possibility of WF change is the introduction of a macroscopic dipole, which could be induced either by a particular spiro-OMeTAD orientation ( _46_ ) or by an interfacial TBMP<sup>+</sup> TFSI<sup>−</sup> accumulation ( _47_ ). We excluded the former based on the grazing-incidence wide-angle x-ray scattering (GIWAXS) results ( **fig. S27** ), which indicated neither stacking mode change nor crystallization amelioration upon addition of TBMP<sup>+</sup> TFSI<sup>−</sup> . The latter could be ruled out because time-of-flight secondary ion mass spectroscopy (TofSIMS) measurements show a uniform distribution of S<sup>−</sup> , C4H9<sup>−</sup> , C5H4N<sup>−</sup> and CF3<sup>−</sup> across the entire HTL ( **fig. S28** ), indicating the absence of surface dipoles formed by TBMP<sup>+</sup> TFSI<sup>−</sup> . In addition, the incorporation of ionic salts increases the WF more than its effects on the IE ( **Fig. 2D** ), further ruling out the possibility of the surface-dipole effect. 

30 

40 

45 

The exclusion of macroscopic dipole formation motivated us to understand the WF tuning mechanism at the molecular level. Both radicals and salts are ionic so Coulomb interactions among them are to be expected and would affect their frontier orbital energetics. Details on the Coulomb interactions between the ionic salts and radicals were obtained from both highresolution liquid- and solid-state nuclear magnetic resonance (hr- and ss-NMR, respectively) spectroscopies ( **Fig. 3B** ). Although NMR spectroscopy cannot provide direct information on radicals given the strong interactions of unpaired electrons with NMR active nuclei, comparison between different samples provided useful information on the interactions in our mixture. We observed electron transfer between spiro-OMeTAD<sup>·+</sup> TFSI<sup>−</sup> and spiro-OMeTAD, in that all<sup>1</sup> H signals (labelled with a to f) of spiro-OMeTAD hr-NMR spectra were broadened after the addition of spiro-OMeTAD<sup>·+</sup> TFSI<sup>−</sup> ( **Fig. 3B** and **fig. S29** ). The broad signal half-widths suggest that unpaired electrons from spiro-OMeTAD<sup>·+</sup> TFSI<sup>−</sup> were near neutral spiro-OMeTAD with mutually exchanging electrons, which can be attributed to π-π stacking between fluorene moieties of spiro-OMeTAD and spiro-OMeTAD<sup>·+</sup> TFSI<sup>−</sup> ( _48, 49_ ). <mark>However, the</mark><sup>1</sup> <mark>H NMR signals of spiro-OMeTAD d+e+f are severely broadened whereas the b and c peaks are only slightly affected indicating that the electron transfer between spiro-OMeTAD and spiroOMeTAD</mark><sup>·+</sup> <mark>TFSI</mark><sup>−</sup> <mark>influences the molecules only partially (</mark> _<mark>50</mark>_ <mark>).</mark> 

Upon addition of TBMP<sup>+</sup> TFSI<sup>−</sup> into the spiro-OMeTAD and spiro-OMeTAD<sup>·+</sup> TFSI<sup>−</sup> mixture, the<sup>1</sup> H NMR signals from all aromatic protons (b, c, and d+e+f) of spiro-OMeTAD nearly disappear ( **fig. 3B** ). This indicates more effective electron exchange between spiro-OMeTAD and spiro-OMeTAD<sup>·+</sup> TFSI<sup>−</sup> in presence of TBMP<sup>+</sup> TFSI<sup>−</sup> salt. Because direct interactions between TBMP<sup>+</sup> TFSI<sup>−</sup> and spiro-OMeTAD were negligible ( **fig. S29A** ), we attribute the effect of TBMP<sup>+</sup> TFSI<sup>−</sup> on the<sup>1</sup> H hr-NMR signals ( **fig. 3B** ) to Coulomb interactions between spiroOMeTAD<sup>·+</sup> TFSI<sup>−</sup> and TBMP<sup>+</sup> TFSI<sup>−</sup> which enhanced charge transfer between spiro-OMeTAD and spiro-OMeTAD<sup>·+</sup> TFSI<sup>−</sup> in the presence of TBMP<sup>+</sup> TFSI<sup>−</sup> salt. <mark>The emergence of these</mark> 

7 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

15 

20 

25 

## <mark>interactions is consistent with the shift and narrowing of the</mark><sup>19</sup> <mark>F ss-NMR peak of TFSI</mark><sup>−</sup> <mark>(</mark> **<mark>fig. S30</mark>** <mark>).</mark> 

A complementary EPR study from 77 K to room temperature (RT) demonstrates a Lorentzian broadening of EPR spectra in our radical-doped spiro-OMeTAD (for samples both with and without TBMP<sup>+</sup> TFSI<sup>−</sup> ) ( **Fig. 3C** , **figures S31** and **S32** ). We attribute this effect to the dynamic broadening due to the electron self-exchange between the neutral spiro-OMeTAD and spiroOMeTAD<sup>·+</sup> TFSI<sup>−</sup> radical. Within the intermediate exchange rate limit, the EPR broadening upon TBMP<sup>+</sup> TFSI<sup>−</sup> incorporation is attributed to the increased electron transfer rate between the neutral spiro-OMeTAD and spiro-OMeTAD<sup>·+</sup> TFSI<sup>−</sup> radical that decreases the spin lifetime ( _51_ ). 

We further investigated the impact of these Coulomb interactions on the frontier orbital energies by combining the photoelectron spectroscopy data and DFT results. The incorporation of TBMP<sup>+</sup> TFSI<sup>−</sup> not only decreased the energy offset between the HOMO level and the Fermi level, but also changed the density of states (DOS) of frontier orbitals ( **Fig. 3D** ). In addition, low-energy inverse photoelectron spectra (LEIPS) indicate that the SUMO level of spiroOMeTAD<sup>·+</sup> downshifted from −4.06 to −4.30 eV upon addition of TBMP<sup>+</sup> TFSI<sup>−</sup> ( **fig. S33** ). The DFT calculations highlighted the effect of the ionic salt on the molecular orbital levels ( **figures S34** and **S35** ), which we rationalized by considering that the TBMP<sup>+</sup> TFSI<sup>−</sup> ionic salt screened the Coulomb attraction between the counter ion and hole polaron in the spiro-OMeTAD<sup>·+</sup> TFSI<sup>−</sup> complex ( _52_ ). In this context, the impact of the TBMP<sup>+</sup> TFSI<sup>−</sup> can be viewed as a modulation of the activation energy of doping (𝐸𝑎𝑑) related to the energy difference between the doping states and transport states ( **Fig. 3E** ), because neutral spiro-OMeTAD molecules close to TFSI<sup>−</sup> anions from the ionic salts can homogenize the electrostatic potential of the transport states, resulting in decreased 𝐸𝑎𝑑 and increased WF. 

30 

35 

40 

45 

Given this understanding of the impact of ionic salt on the energetic levels, we investigated why there was no conductivity enhancement withing increasing WF, a feature that makes it possible to decouple conductivity and WF tuning. Decreasing the 𝐸𝑎𝑑 of dopants upon ionic salt addition ( **Fig. 3E** ) enables an increasing fraction of hole polarons to be thermally populated. This effect, taken alone, would lead to a conductivity increase. However, the temperature-dependent conductivity indicated that the ionic salts also increase disorder. The temperature-dependent conductivity measurements revealed a faster decreasing rate of conductivity upon addition of TBMP<sup>+</sup> TFSI<sup>−</sup> and suggested an increased long-distance inter-molecular charge hopping potential barrier (𝐸𝑎ℎ) from 0.14 eV to 0.20 eV ( _53_ , _54_ ) ( **Fig. 3F** and **fig. S36** ). <mark>This more difficult longdistance inter-molecular charge transfer implies a decreased mobility which may be induced by increased disorder or more scattering from ionic clusters (</mark> _<mark>55, 56</mark>_ <mark>).</mark> Overall, the ionic salt played a dual role. They increased the hole polaron population but also increased disorder. These two effects largely compensated each other and led to negligible conductivity changes over a broad range of ionic salt concentrations. 

Stimulated by the possibilities of precise energetic manipulation and facile conductivity tunability, we applied the IM radical doping approach to perovskites with different compositions and devices with different architectures (planar or mesoporous structures). In addition to the PSCs based on SnO2/(FAPbI3)0.99(MAPbBr3)0.01 and TiO2/FAPbI3 shown in **Fig. 1B, C** , IM radical doped spiro-OMeTAD HTLs also resulted in high PCEs in perovskites with different band gaps, different fabrication methods (one-step or two-step), and with or without ionic liquid (IL) additives. All PCEs were similar to (or slightly higher than) those based on conventionally doped spiro-OMeTAD HTL ( **Fig. 4A, fig. S37, table S4** and **S5** ), indicating that our IM radical doping strategy is applicable to different PSCs. In addition, we observed improved stability (both 

8 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

15 

20 

25 

30 

35 

40 

under high RH and high temperature) for all the PSCs using IM radical doped spiro-OMeTAD compared with those using conventional doped spiro-OMeTAD ( **fig. S38** ). 

The generality of the IM radical doping strategy was also demonstrated in terms of the ionic salts. We investigated six additional ionic salts, based on typical anions 

(bis(trifluoromethylsulfonyl)imide, hexafluorophosphate, tetrafluoroborate, p-toluenesulfonate) and cations (ethyldimethylpropylammonium, propylpyridinium, imidazolium, methylpyridinium) ( **Fig. 4B** ). All of the ionic salts could effectively tune the WF ( **Fig. 4B** and **fig. S39** ) without negatively affecting the conductivity ( **fig. S40** ). Their incorporation results in high _V_ OC values (~1.12 to 1.16 V) and high PCEs (~22% to 23%) in SnO2/(FAPbI3)0.99(MAPbBr3)0.01-based PSCs ( **Fig. 4C** and **Table S6** ). Although the use of different cations resulted in negligible WF modifications, we noted that switching from TFSI<sup>−</sup> to other anions could slightly decrease the WF, which points to the anions playing a more prominent role in the energetic modulation in the framework of the IM radical doping strategy. A possible reason is that the anions coming from the ionic salts can exchange with TFSI<sup>−</sup> in the radical complex, resulting in new radical complex species with different energetics. 

Given that the energetics of the hole polarons are sensitive to their local ionic environment, the IM radical doping strategy provides room to manipulate the WF as a function of the nature of the ionic salts. WF tuning could be achieved over a large range by controlling the interaction strength between the ionic salts and the radicals and is more easily adjustable compared to the WF modulation through interfacial molecular dipoles ( _47_ ). As such, the IM radical doping strategy fills the gap between several previous strategies to enhance WF and conductivity and greatly expands the toolbox for organic semiconductor doping ( _57_ , _58_ ). 

## References and Notes 

- [1] H. Min, D. Y. Lee, J. Kim, G. Kim, K. S. Lee, J. Kim, M. J. Paik, Y. K. Kim, K. S. Kim, M. G. Kim, T. J. Shin, S. I. Seok, Perovskite solar cells with atomically coherent interlayers on SnO2 electrodes. _Nature_ , **598** (7881): 444-450 (2021). 

- [2] T. Zhang, M. Long, M. Qin, X. Lu, S. Chen, F. Xie, L. Gong, J. Chen, M. Chu, Q. Miao, Z. Chen, W. Xu, P. Liu, W. Xie, J. Xu, Stable and efficient 3D-2D perovskite-perovskite planar heterojunction solar cell without organic hole transport layer. _Joule_ **2** .12, 27062721(2018). 

- [3] S. Bai, P. Da, C. Li, Z. Wang, Z. Yuan, F. Fu, M. Kawecki, X. Liu, N. Sakai, J. T. Wang, S. Huettner, S. Buecheler, M. Fahlman, F. Gao, H. J. Snaith. Planar perovskite solar cells with long-term stability using ionic liquid additives. _Nature_ **571** (7764), 245-250 (2019). 

- [4] S. Chen, Y. Deng, X. Xiao, S. Xu, P. N. Rudd, J. Huang, Preventing lead leakage with builtin resin layers for sustainable perovskite solar cells. _Nat. Sustainability_ , 1-8 (2021). 

- [5] J. Xue, R. Wang, X. Chen, C. Yao, X. Jin, K. Wang, W. Huang, T. Huang, Y. Zhao, Y. Zhai, D. Meng, S. Tan, R. Liu, Z. Wang, C. Zhu, K. Zhu, M. C. Beard, Y. Yan, Y. Yang, Reconfiguring the band-edge states of photovoltaic perovskites by conjugated organic cations. _Science_ , **371** (6529), 636-640 (2021). 

- [6] Y. H. Lin, N. Sakai, P. Da, J. Wu, H. C. Sansom, A. J. Ramadan, S. Mahesh, J. Liu, R. J. Oliver, J. Lim, L. Aspitarte, K. Sharma, P. K. Madhu, A. B. > Vilches, P. K. Nayak, S. 

9 

Submitted Manuscript: Confidential Template revised February 2021 

Bai, F. Gao, C. M. Grovenor, M. B. Johnston, J. G. Labram, J. R. Durrent, J. M. Ball, B. Wenger, B. Stannowski, H. J. Snaith, A piperidinium salt stabilizes efficient metal-halide perovskite solar cells. _Science_ **369** (6499), 96-102 (2020). 

5 

10 

15 

20 

25 

30 

- [7] A. Al-Ashouri, E. Köhnen, B. Li, A. Magomedov, H. Hempel, P. Caprioglio, J. A. Marquze, A. B. M. Vilches, E. Kasparavicius, J. A. Smith, N. Pung, D. Menzel, M. Grischek, L. Kegelmann, D. Skroblin, C. Gollwitzer, T. Malinauskas, M.Jost, G. Matic, B. Rech, R. Schlatmann, M. Topic, L. Korte, A. Abate, B. Stannowski, D. Neher, M. Stolterfoht, T. Unold, V. Getautis, S. Albrecht, Monolithic perovskite/silicon tandem solar cell with> 29% efficiency by enhanced hole extraction. _Science_ **370** (6522), 1300-1309 (2020). 

- [8] K. Xiao, R. Lin, Q. Han, Y. Hou, Z. Qin, H. T. Nguyen, J. Wen, M. Wei, V. Yeddu, M. I. Saidaminov, Y. Gao, X. Luo, Y. Wang, H. Gao, C. Zhang, J. Xu, J. Zhu, E. H. Sargent, H. Tan, All-perovskite tandem solar cells with 24.2% certified efficiency and area over 1 cm<sup>2</sup> using surface-anchoring zwitterionic antioxidant. _Nat. Energy_ **5** (11), 870-880 (2020). 

- [9] J. Jeong, M. Kim, J. Seo, H. Lu, P. Ahlawat, A. Mishra, Y. Yang, M. A. Hope, F. T. Eickemeyer, M. Kim, Y. J. Yoon, I. W. Choi, B. P. Darwich, S. J. Choi, Y. Jo, J. H. Lee, B. Walker, S. M. Zakeeruddin, L. Emsley, U. Rothlisberger, A. Hagfeldt, D. S. Kim, M. Grätzel, J. Y. Kim, Pseudo-halide anion engineering for α-FAPbI3 perovskite solar cells. _Nature_ **592** (7854), 381-385 (2021). 

- [10] M. Jeong, I. W. Choi, E. M. Go, Y. Cho, M. Kim, B. Lee, S. Jeong, Y. Jo, H. W. Choi, J. Lee, J. Bae, S. K. Kwak, D. S. Kim, C. Yang, Stable perovskite solar cells with efficiency exceeding 24.8% and 0.3-V voltage loss. _Science_ **369** (6511), 1615-1620 (2020). 

- [11] J. J. Yoo, G. Seo, M. R. Chua, T. G. Park, Y. Lu, F. Rotermund, Y.-K. Kim, C. S. Moon, N. J. Jeon, J.-P. Correa-Baena, V. Bulović, S. S. Shin, M. G. Bawendi, J. Seo, Efficient perovskite solar cells via improved carrier management. _Nature_ **590** (7847), 587-593 (2021). 

- [12] M. Kim, G.-H. Kim, T. K. Lee, I. W. Choi, H. W. Choi, Y. Jo, Y. J. Yoon, J.  W. Kim, J. Lee, D. Huh, H. Lee, S. K. Kwak, J. Y. Kim, D. S. Kim, Methylammonium chloride induces intermediate phase stabilization for efficient perovskite solar cells. _Joule_ , **3** (9), 2179-2192 (2019). 

- [13] G. Kim, H. Min, K. S. Lee, D. Y. Lee, S. M. Yoon, S. I. Seok, Impact of strain relaxation on performance of α-formamidinium lead iodide perovskite solar cells. _Science_ , **370** (6512), 108-112 (2020). 

35 

- [14] S. Wang, M. Sina, P. Parikh, T. Uekert, B. Shahbazian, A. Devaraj, Y. S. Meng, Role of 4- _tert_ -butylpyridine as a hole transport layer morphological controller in perovskite solar cells. _Nano Lett._ **16** (9), 5594-5600 (2016). 

- [15] U. B. Cappel, T. Daeneke, and U. Bach, Oxygen-induced doping of spiro-MeOTAD in solid-state dye-sensitized solar cells and its impact on device performance. _Nano Lett_ . **12** (9), 4925-4931 (2012). 

40 

- [16] R. L. Forward, K. Y. Chen, D. M. Weekes, D. J. Dvorak, Y. Cao, C. P. Berlinguette, Protocol for quantifying the doping of organic hole-transport materials. _ACS Energy Lett._ , **4** (10), 2547-2551 (2019). 

10 

Submitted Manuscript: Confidential Template revised February 2021 

- [17] S. Kim, T. H. Le, T. de Monfreid, F. Goubard, T.-T. Bu, N.-G. Park, Capturing mobile lithium ions in a molecular hole transporter enhances the thermal stability of perovskite solar cells. _Adv. Mater._ **33** .12, 2007431 (2021). 

5 

10 

- [18] A. K. Jena, M. Ikegami, T. Miyasaka, Severe morphological deformation of spiroOMeTAD in (CH3NH3) PbI3 solar cells at high temperature. _ACS Energy Lett._ **2** (8), 1760-1761 (2017). 

- [19] A. K. Jena, W. Zhang, L. Wang, Y. Guo, B. Zhang, V. Leandri, B. Xu, Z. Li, J. M. Gardner, L. Sun, L. Kloo, Role of spiro-OMeTAD in performance deterioration of perovskite solar cells at high temperature and reuse of the perovskite films to avoid Pb-waste. _J. Mater. Chem. A_ **6** (5), 2219-2230 (2018). 

- [20] J. Kong, Y. Shin, J. A. Röhr, H. Wang, J. Meng, Y. Wu, A. Katzenberg, G. Kim, D. Y. Kim, T.-D. Li, E. Chau, F. Antonio, T. Siboonruang, S. Kwon, K. Lee, J. R. Kim, M. A. Modestino, H. Wang, A. D. Taylor, CO2 doping of organic interlayers for perovskite solar cells. _Nature_ **594** (7861), 51-56 (2021). 

15 

20 

- [21] B. Xu, J. Huang, H. Ågren, L. Kloo, A. Hagfeldt, L. Sun, AgTFSI as p-type dopant for efficient and stable solid-state dye-sensitized and perovskite solar cells. _ChemSusChem_ **7** .12, 3252-3256 (2014). 

- [22] J.-Y. Seo, H.-S. Kim, S. Akin, M. Stojanovic, E. Simon, M. Fleischer, A. Hagfeldt, S. M. Zakeeruddin, M. Grätzel, Novel p-dopant toward highly efficient and stable perovskite solar cells. _Energy Environ. Sci._ **11** .10, 2985-2992 (2018). 

- [23] J.-Y. Seo, S. Akin, M. Zalibera, M. A. R. Preciado, H.-S. Kim, S. M. Zakeeruddin, J. V. Milić, M. Grätzel, Dopant Engineering for Spiro‐OMeTAD Hole‐Transporting Materials towards Efficient Perovskite Solar Cells. _Adv. Func. Mater._ 2102124 (2021). 

25 

30 

- [24] A. Abate, D. J. Hollman, J. Teuscher, S. Pathak, R. Avolio, G. D’Errico, G. Vitiello, S. Fantacci, H. J. Snaith, Protic ionic liquids as p-dopant for organic hole transporting materials and their application in high efficiency hybrid solar cells. _J. Am. Chem. Soc._ **135** (36), 13538-13548 (2013). 

- [25] W. H. Nguyen, C. D. Bailie, E. L. Unger, M. D. McGehee, Enhancing the hole-conductivity of spiro-OMeTAD without oxygen or lithium salts by using spiro(TFSI)2 in perovskite and dye-sensitized solar cells. _J. Am. Chem. Soc._ **136** (31), 10996-11001 (2014). 

- [26] B. Tan, S. R. Raga, A. S. R. Chesman, S. O. Fürer, F. Zheng, D. P. McMeekin, L. Jiang, W. Mao, X. Lin, X. Wen, J. Lu, Y.-B. Cheng, U. Bach, LiTFSI‐free spiro‐OMeTAD‐based perovskite solar cells with power conversion efficiencies exceeding 19%. _Adv. Energy Mater._ **9** .32: 1901519 (2019). 

35 

40 

- [27] S. Wang, Z. Huang, X. Wang, Y. Li, M. Günther, S. Valenzuela, P. Parikh, A. Cabreros, W. Xiong, Y. S. Meng, Unveiling the role of tBP-LiTFSI complexes in perovskite solar cells. _J. Am. Chem. Soc._ **140** (48), 16720-16730 (2018). 

- [28] F. Lamberti, T. Gatti, E. Cescon, R. Sorrentino, A. Rizzo, E. Menna, G. Meneghesso, M. Meneghetti, A. Petrozza, L. Franco, Evidence of spiro-OMeTAD de-doping by tertbutylpyridine additive in hole-transporting layers for perovskite solar cells. _Chem_ **5** (7), 1806-1817 (2019). 

11 

Submitted Manuscript: Confidential Template revised February 2021 

10 

- [29] S. Fantacci, F. De Angelis, M. K. Nazeeruddin, M. Grätzel, Electronic and optical properties of the spiro-MeOTAD hole conductor in its neutral and oxidized forms: a DFT/TDDFT investigation. _J. Phys. Chem. C_ **115** (46), 23126-23133 (2011). 

5 

- [30] V. Coropceanu, M. Malagoli, J. M. André, J. L. Brédas, Charge-transfer transitions in triarylamine mixed-valence systems: a joint density functional theory and vibronic coupling study. _J. Am. Chem. Soc._ **124** (35), 10519-10530 (2002). 

- [31] W. Zhang, L. Wang, Y. Guo, B. Zhang, V. Leandri, B. Xu, Z. Li, J. M. Gardner, L. Sun, L. Kloo, Single crystal structure and opto-electronic properties of oxidized SpiroOMeTAD. _Chem. Commun._ **56** (10), 1589-1592 (2020). 

- [32] W. Zhang, F. Zhang, B. Xu, Y. Li, L. Wang, B. Zhang, Y. Guo, J. M. Gardner, L. Sun, L. Kloo, Organic salts as p-type dopants for efficient LiTFSI-free perovskite solar cells. _ACS Appl. Mater. Interfaces_ **12** (30), 33751-33758 (2020). 

15 

- [33] J. You, L. Meng, T.-B. Song, T.-F. Guo, Y. (M.) Yang, W.-H. Chang, Z. Hong, H. Chen, H. Zhou, Q. Chen, Y. Liu, N. De Marco, Y. Yang, Improved air stability of perovskite solar cells via solution-processed metal oxide transport layers. _Nat. Nanotechnol._ **11** (1), 75-81 (2016). 

- [34] W. Chen, Y. Z. Wu, Y. Yue, J. Liu, W. Zhang, X. Yang, H. Chen, E. Bi, I. Ashraful, M. Grätzel, L. Han, Efficient and stable large-area perovskite solar cells with inorganic charge extraction layers. _Science_ **350** (6263), 944-948 (2015). 

20 

25 

30 

- [35] Y. Hou, X. Du, S. Scheiner, D. P. Mcmeekin, Z. Wang, N. Li, M. S. Killian, H. Chen, M. Richter, I. Levchuk, N. Schrenker, E. Spiecker, T. Stubhan, N. A. Luechinger, A. Hirsch, P. Schmuki, H.-P. Steinruck, R. H. Fink, M. Halik, H. J. Snaith, C. J. Brabec, A generic interface to reduce the efficiency-stability-cost gap of perovskite solar cells. _Science_ **358** (6367), 1192-1197 (2017). 

- [36] S. Olthof, S. Mehraeen, S. K. Mohapatra, S. Barlow, V. Coropceanu, J.-L. Brédas, S. R. Marder, A. Kahn, Ultralow doping in organic semiconductors: evidence of trap filling. _Phys. Rev. Lett._ **109** .17, 176601 (2012). 

- [37] M. L. Tietze, P. Pahner, K. Schmidt, K. Leo, B. Lüssem, Doped organic semiconductors: trap-filling, impurity saturation, and reserve regimes. _Adv. Funct. Mater._ **25** (18), 27012707 (2015). 

- [38] T. Koopmans, On the assignment of wave functions and eigenvalues to the individual electrons of an atom. _Physica_ **1** , 104-113 (1934). 

35 

- [39] H. Méndez, G. Heimel, A. Opitz, K. Sauer, P. Barkowski, M. Oehzelt, J. Soeda, T. Okamoto, J. Takeya, J.-B. Arlin, J.-Y. Balandier, Y. Geerts, N. Koch, I. Salzmann, Doping of organic semiconductors: impact of dopant strength and electronic coupling. _Angew. Chem._ , 125(30), 7905-7909 (2013). 

- [40] R. A. Belisle, P. Jain, R. Prasanna, T. Leijtens, M. D. McGehee, Minimal effect of the holetransport material ionization potential on the open-circuit voltage of perovskite solar cells. _ACS Energy Lett._ **1** (3), 556-560 (2016). 

40 

- [41] P. Caprioglio, M. Stolterfoht, C. M. Wolff, T. Unold, B. Rech, S. Albrecht, D. Neher, On the relation between the open‐circuit voltage and quasi‐Fermi level splitting in efficient perovskite solar cells. _Adv. Energy Mater._ **9** (33), 1901631 (2019). 

12 

Submitted Manuscript: Confidential Template revised February 2021 

5 

- [42] M. Stolterfoht, P. Caprioglio, C. M. Wolff, J. A. Márquez, J. Nordmann, S. Zhang, D. Rothhardt, U. Hörmann, Y. Amir, A. Redinger, L. Kegelmann, F. Zu, S. Albrecht, N. Koch, T. Kirchartz, M. Saliba, T. Unold, D. Neher, The impact of energy alignment and interfacial recombination on the internal and external open-circuit voltage of perovskite solar cells. _Energy Environ. Sci._ **12** (9), 2778-2788 (2019). 

- [43] A. Fediai, F. Symalla, P. Friederich, W. Wenzel, Disorder compensation controls doping efficiency in organic semiconductors. _Nat. Communi._ **10** : 4547 (2019). 

10 

- [44] C. G. Tang, M. C. Y. Ang, K.-K. Choo, V. Keerthi, J.-K. Tan, M. N. Syafiqah, T. Kugler, J. H. Burroughes, R.-Q. Png, L.-L.y Chua, P. K. H. Ho, Doped polymer semiconductors with ultrahigh and ultralow work functions for ohmic contacts. _Nature_ **539** .7630, 536540(2016). 

- [45] Y. Yamashita, J. Tsurumi, M. Ohno, R. Fujimoto, S. Kumagai, T. Kurosawa, T. Okamoto, J. Takeya, S. Watanabe, Efficient molecular doping of polymeric semiconductors driven by anion exchange. _Nature_ **572** .7771, 634-638 (2019). 

15 

20 

- [46] N. Shibayama, H. Maekawa, Y. Nakamura, Y. Haruyama, M. Niibe, S. Ito, Control of Molecular Orientation of Spiro-OMeTAD on Substrates. _ACS Appl. Mater. Interfaces_ **12** .44: 50187-50191 (2020). 

- [47] Y. Zhou, C. Fuentes-hernandez, J. Shim, J. Meyer, A. J. Giordano, H. Li, P. Winget, T. Papadopoulos, H. Cheun, J. Kim, M. Fenoll, A. Dindar, W. Haske, E. Najafabadi, T. M. Khan, H. Sojoudi, S. Barlow, S. Graham, J.-L. Brédas, S. R. Marder, A. Kahn, B. Kippelen, A universal method to produce low–work function electrodes for organic electronics. _Science_ **336** (6079), 327-332 (2012). 

- [48] Y. Li, H. Li, C. Zhong, G. Sini, J.-L. Brédas, Characterization of intrinsic hole transport in single-crystal spiro-OMeTAD. _npj Flexible Electronics_ **1** (1), 1-8 (2017). 

25 

- [49] D. Shi, X. Qin, Y. He, C. Zhong, J. Pan, H. Dong, W. Xu, T. Li, W. Hu, J.-L. Brédas, O. M. Bakr, Spiro-OMeTAD single crystals: Remarkably enhanced charge-carrier transport via mesoscale ordering. _Sci. Adv._ **2** .4: e1501491 (2016). 

- [50] <mark>E. D</mark> e Boer, C. MacLean, NMR Study of electron transfer rates and spin densities in p‐ xylene and p‐diethylbenzene anions. _J. Chem. Phys._ , **44** (4), 1334-1342 (1966). 

30 

- [51] R. L. Ward, S. I. Weissman, Electron transfer between naphthalene negative ion and naphthalene. _J. Am. Chem. Soc._ **76** .13, 3612-3612 (1954). 

- [52] R.-Q. Png, M. C.Y. Ang, M.-H. Teo, K.-K. Choo, C. G. Tang, D. Belaineh, L.-L. Chua, P. K.H. Ho, Madelung and Hubbard interactions in polaron band model of doped organic semiconductors. _Nat. Commun._ **7** , 11948 (2016). 

35 

- [53] N. Karl, Charge carrier transport in organic semiconductors. _Synth. Met._ **133** , 649-657 (2003). 

- [54] H. Abdalla, G. Zuo, M. Kemerink, Range and energetics of charge hopping in organic semiconductors. _Phys. Rev. B_ **96** (24), 241202 (2017). 

40 

- [55] P.-J. Chia, S. Sivaramakrishnan, M. Zhou, R.-Q. Png, L.-L. Chua, R. H. Friend, P. K. H. Ho, Direct evidence for the role of the madelung potential in determining the work function of doped organic semiconductors. _Phys. Rev. Lett._ **102** (9), 096602 (2009). 

13 

Submitted Manuscript: Confidential Template revised February 2021 

- [56] K. Harada _,_ F. Li _,_ B. Maennig _,_ M. Pfeiffer, K. Leo, Ionized impurity scattering in n-doped C 60 thin films. _Appl. Phys. Lett._ , **91** (9): 092118 (2007). 

- [57] I. E. Jacobs, A. J. Moulé, Controlling molecular doping in organic semiconductors. _Adv. Mater._ **29** .42, 1703063 (2017). 

5 

10 

- [58] C. Gaul, S. Hutsch, M. Schwarze, K. S. Schellhammer, F. Bussolotti, S. Kera, G. Cuniberti, K. Leo, F. Ortmann, Insight into doping efficiency of organic semiconductors from the analysis of the density of states in n-doped C60 and ZnPc. _Nat. Mater._ **17** .5, 439-444 (2018). 

- [59] H. Yoshida, Near-ultraviolet inverse photoemission spectroscopy using ultra-low energy electrons. _Chem. Phys. Lett._ **539** , 180-185 (2012). 

- [60] H. Yoshida, Principle and application of low energy inverse photoemission spectroscopy: a new method for measuring unoccupied states of organic semiconductors. _J. Electron Spectrosc. Relat. Phenom._ **204** , 116-124 (2015). 

15 

- [61] H. Yoshida, Note: Low energy inverse photoemission spectroscopy apparatus. _Rev. Sci. Instrum._ **85** .1, 016101 (2014). 

- [62] E. L. Hahn, Spin echoes, _Phys. Rev._ **80** , 580-594 (1950) 

- [63] I., Yoshitaka, N. P. Wickramasinghe, S. Chimon, A new approach in 1D and 2D 13C highresolution solid-state NMR spectroscopy of paramagnetic organometallic complexes by very fast magic-angle spinning. _J. Am. Chem. Soc._ 125.12, 3438-3439 (2003). 

20 

25 

30 

35 

- [64] M. J. Frisch, G. W. Trucks, H. B. Schlegel, G. E. Scuseria, M. A. Robb, J. R. Cheeseman, G. Scalmani, V. Barone, G. A. Petersson, H. Nakatsuji, X. Li, M. Caricato, A. V. Marenich, J. Bloino, B. G. Janesko, R. Gomperts, B. Mennucci, H. P. Hratchian, J. V. Ortiz, A. F. Izmaylov, J. L. Sonnenberg, D. Williams-Young, F. Ding, F. Lipparini, F. Egidi, J. Goings, B. Peng, A. Petrone, T. Henderson, D. Ranasinghe, V. G. Zakrzewski, J. Gao, N. Rega, G. Zheng, W. Liang, M. Hada, M. Ehara, K. Toyota, R. Fukuda, J. Hasegawa, M. Ishida, T. Nakajima, Y. Honda, O. Kitao, H. Nakai, T. Vreven, K. Throssell, J. A. Montgomery, J. E. Peralta, F. Ogliaro, M. J. Bearpark, J. J. Heyd, E. N. Brothers, K. N. Kudin, V. N. Staroverov, T. A. Keith, R. Kobayashi, J. Normand, K. Raghavachari, A. P. Rendell, J. C. Burant, S. S. Iyengar, J. Tomasi, M. Cossi, J. M. Millam, M. Klene, C. Adamo, R. Cammi, J. W. Ochterski, R. L. Martin, K. Morokuma, O. Farkas, J. B. Foresman, D. J. Fox, _Gaussian 16, Revision B.01_ , Gaussian, Inc., Wallingford CT, (2016). 

- [65] Z. Zheng, J.-L. Brédas, V. Coropceanu. Description of the charge transfer states at the pentacene/C60 interface: Combining range-separated hybrid functionals with the polarizable continuum model. _J. Phys. Chem. Lett._ **7** (13), 2616-2621 (2016). 

- [66] E. Cho, V. Coropceanu, J.-L. Brédas. Electronic Structure of Multicomponent Organic Molecular Materials: Evaluation of Range-Separated Hybrid Functionals. _J. Chem. Theor. Comput._ **16** (6), 3712-3719 (2020). 

40 

- [67] L. Abella, J. Crassous, L. Favereau, J. Autschbach, Why is the Energy of the Singly Occupied Orbital in Some Radicals below the Highest Occupied Orbital Energy? _Chem. Mater._ **33** , 10, 3678–3691 (2021). 

14 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

15 

20 

25 

**Acknowledgments:** The authors gratefully thank Dr. Chunxiong Bao for the help with temperature-dependent conductivity measurements; Dr. Guanhaojie Zheng for the help with GIWAXS analysis; Dr. Yong Wang for the help with the stability test; Prof. Jimmy Chai Mei YU for the help with single-crystal characterization; Prof. Olle Inganäs, Dr. Weidong Xu, Dr. Xiaoke Liu, Dr. Xinyi Cai for valuable discussions. **Funding:** This work was supported by Swedish Research Council Vetenskapsrådet (Grant 2018-04809), ERC Starting Grant (No. 717026), the Knut and Alice Wallenberg Foundation (Dnr KAW 2019.0082), and the Swedish Government Strategic Research Area in Materials Science on Functional Materials at Linköping University (Faculty Grant SFO-Mat-LiU no. 2009-00971). F.G. is a Wallenberg Academy Fellow. The work at the University of Arizona has been funded by the UA College of Science and the Office of Naval Research, Award No. N00014-20-1-2110. The work at the École Polytechnique Fédérale de Lausanne has been funded by Swiss National Science Foundation for financial support with Project No. 200020_185041 and from the European Union’s Horizon 2020 research and innovation program under grant agreement No 764047. **Author contributions:** F.W. and F.G. conceived and supervised the project. T.Z., Z.H., F.W. and F.G. designed this project. Z.H. contributed to advising and providing chemistry solutions. T.Z., Z.H., and F.W. performed the investigations and analyzed the data. H.B.K., C.W.D and D.S.K. made the PSCs based on the meso-TiO2. C.F.W., X.J.L. and M.F. conducted XPS/UPS measurements and analysis. E.C., V.C. and J-L.B. conducted the DFT calculations and helped to discuss the doping mechanism. R.K., L.K., and J.B. performed NMR measurements. M.Y.C. performed SEM measurements and helped with NMR interpretations. M.Y. and S.B. contributed to the discussions. Y.P. and W.M.C performed EPR analysis. B.W.Y, J.J.S, and A.H. performed the MPP measurements. K.T. and H. Y. conducted the LEIPS measurements. S.Y. and F.F. contributed to Tof-SIMS measurements.  T.Z., F.W., and F.G. wrote the manuscript.  All authors discussed the results and reviewed the manuscript. **Competing interests:** F.G., F.W., T.Z., and Z.H. filed a patent based on the concept developed in this manuscript. **Data and materials availability:** All data are available in the main text other supplementary materials. 

## **Supplementary Materials** 

Materials and Methods 

30 

Supplementary Text Figs. S1 to S40 Tables S1 to S6 References ( _29_ , _30_ , _59-67_ ) 

15 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 





**Fig. 1. Comparison of PSCs based on the conventional and IM radical doping strategies.** ( **A** ) Illustration of the complex in-situ reaction processes in the conventional doping process (left) and the clean, instant IM radical doping strategy (right) of spiro-OMeTAD. ( **B** ) Current density-voltage ( _J_ - _V_ ) curves of PSCs (SnO2 ETL) based on conventional doping,  radical doping, and IM radical doping of spiro-OMeTAD. ( **C** ) _J_ - _V_ curves of PSCs (mesoporous TiO2 ETL) based on conventional and IM radical doping of spiro-OMeTAD. ( **D** and **E)** PCE tracking of unencapsulated PSCs based on conventional and IM radical doping of spiro-OMeTAD under (D) 70±5% humidity and (E) 70±3°C thermal aging. 

16 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

15 

20 



**<mark>Fig. 2. Effects of radicals and ionic salts on conductivity and energetics.</mark>** <mark>(</mark> **<mark>A</mark>** <mark>and</mark> **<mark>B</mark>** <mark>) (A)</mark> _<mark>J</mark>_ <mark>-</mark> _<mark>V</mark>_ <mark>curves of the hole-only devices and (B) conductivity of the spiro-OMeTAD films doped with different amounts of radical, with the device structure of hole-only devices shown in the inset. (</mark> **<mark>C</mark>** <mark>)</mark> _<mark>J</mark>_ <mark>-</mark> _<mark>V</mark>_ <mark>curves of the hole-only devices with 14 mol% radicals and different amounts of TBMP</mark><sup>+</sup> <mark>TFSI</mark><sup>−</sup> <mark>; the conductivity is shown in the inset. (</mark> **<mark>D</mark>** <mark>and</mark> **<mark>E</mark>** <mark>) Fermi-level and HOMO onsets of the spiro-OMeTAD films doped with (D) different radical amounts and (E) different TBMP</mark><sup>+</sup> <mark>TFSI</mark><sup>−</sup> <mark>amounts (14 mol% radicals). (</mark> **<mark>F</mark>** <mark>) Illustration of the band alignment between the perovskite layer and the HTL with different WF values.</mark> 

25 

17 

Submitted Manuscript: Confidential Template revised February 2021 

5 







**Fig. 3. Molecular-level doping mechanisms of the IM radical doping.** ( **A** ) Illustration of the charge transfer and doping mechanisms with spiro-OMeTAD<sup>·+</sup> TFSI<sup>−</sup> radicals. ( **B** )<sup>1</sup> H hr-NMR spectra of the spiro-OMeTAD (black line), spiro-OMeTAD and spiro-OMeTAD<sup>·+</sup> TFSI<sup>−</sup> mixture without (red line, the inset figure shows magnified view of d+e+f peak in range of 9~7.5 ppm) and with (blue line) TBMP<sup>+</sup> TFSI<sup>−</sup> in the range of 9~6.25 ppm. (Peaks b, c, and d+e+f refers to the aromatic protons signal.) ( **C** ) EPR signals of doped spiro-OMeTAD (14 mol% radicals) with 

18 

Submitted Manuscript: Confidential Template revised February 2021 

10 

and without TBMP<sup>+</sup> TFSI<sup>−</sup> at low temperature and RT. ( **D** ) Zoom-in UPS spectra near the valence band of neutral spiro-OMeTAD, 14 mol% radical doped spiro-OMeTAD film, and 14 mol% radical and 20 mol% TBMP<sup>+</sup> TFSI<sup>−</sup> doped spiro-OMeTAD films. ( **E** ) Illustration of the ionic salts effect on the WF modulation in the framework of the IM radical doping strategy. ( **F** ) 5 Temperature-dependent conductivity evolution of doped spiro-OMeTAD (14 mol% radicals) with and without TBMP<sup>+</sup> TFSI<sup>−</sup> . 

15 

20 

25 

30 

35 

40 

45 

19 

Submitted Manuscript: Confidential Template revised February 2021 

10 



**Fig. 4. Generality of the IM radical doping strategy.** ( **A** ) _J_ - _V_ curves of different PSCs based on spiro-OMeTAD HTL following the IM radical doping strategy. ( **B** ) Molecular structures of six additional ionic salts used in this work and their effects on the energetic levels of the doped 5 spiro-OMeTAD films. ( **C** ) _J_ - _V_ curves of PSCs based on the spiro-OMeTAD HTL doped with six additional ionic salts (14 mol% radicals). 

20 

