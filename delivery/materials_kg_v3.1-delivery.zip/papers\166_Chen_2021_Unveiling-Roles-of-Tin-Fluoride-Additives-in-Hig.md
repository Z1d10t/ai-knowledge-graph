# Unveiling Roles of Tin Fluoride Additives in High‐Efficiency Low‐Bandgap Mixed Tin‐Lead Perovskite Solar Cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Advanced Energy Materials |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 178 |
| 作者 | Qi-Yu Chen, Jin-Cheng Luo, Rui He, Hua-Gui Lai, S. Ren, Yi-Ting Jiang, Zhenxi Wan, W. Wang et al. |
| DOI | 10.1002/aenm.202101045 |
| 源文件 | 066_Chen_2021_Unveiling-Roles-of-Tin-Fluoride-Additives-in-Hig.pdf |

---
**ReseaRch aRticle** 



**www.advenergymat.de** 

# **Unveiling Roles of Tin Fluoride Additives in High-Efficiency Low-Bandgap Mixed Tin-Lead Perovskite Solar Cells** 

_Qiyu Chen, Jincheng Luo, Rui He, Huagui Lai, Shengqiang Ren,* Yiting Jiang, Zhenxi Wan, Wenwu Wang, Xia Hao, Ye Wang, Jingquan Zhang, Iordania Constantinou, Changlei Wang, Lili Wu, Fan Fu,* and Dewei Zhao*_ 

## **1. Introduction** 

**Low-bandgap mixed tin–lead perovskite solar cells (PSCs) have been attracting increasing interest due to their appropriate bandgaps and promising application to build efficient all-perovskite tandem cells, an effective way to break the Shockley–Queisser limit of single-junction cells. Tin fluoride (SnF2) has been widely used as a basis along with various strategies to improve the optoelectronic properties of low-bandgap Sn**  **Pb perovskites and efficient cells. However, fully understanding the roles of SnF2 in both films and devices is still lacking and fundamentally desired. Here, the functions of SnF2 in both low-bandgap (FASnI3)0.6(MAPbI3)0.4 perovskite films and efficient devices are unveiled. SnF2 regulates the growth mode of low-bandgap Sn**  **Pb perovskite films, leading to highly oriented topological growth and improved crystallinity. Meanwhile, SnF2 prevents the oxidation of Sn**<sup>**2+**</sup> **to Sn**<sup>**4+**</sup> **and reduces Sn vacancies, leading to reduced background hole density and defects, and improved carrier lifetime, thus largely decreasing nonradiative recombination. Additionally, the F**<sup>**−**</sup> **ion preferentially accumulates at hole transport layer/perovskite interface with high SnF2 content, leading to more defects. This work provides in-depth insights into the roles of SnF2 additives in low-bandgap Sn**  **Pb films and devices, assisting in further investigations into multiple additives and approaches to obtain efficient low-bandgap PSCs.** 

Organic–inorganic metal halide perovskites emerge as promising light absorbing materials for photovoltaic devices due to their high absorption coefficients, low trap density, tunable bandgaps, and long carrier diffusion lengths.<sup>[1–5]</sup> The record power conversion efficiency (PCE) of perovskite solar cells (PSCs) continues to rise in recent years, exceeding 25% for single-junction cells.<sup>[6]</sup> Perovskitebased tandems offer promise to break the Shockley–Queisser radiative limit of single-junction solar cells,<sup>[7–13]</sup> among which all-perovskite tandem solar cells with theoretically high efficiencies have exhibited their advantages in terms of lowtemperature processing and flexibility that are compatible to high throughput roll-toroll manufacturing, potentially low fabrication cost.<sup>[14–19]</sup> 

All-perovskite tandem solar cells consist of a low-bandgap (low- _E_ g: ≈1.1–1.3 eV) perovskite absorbing 

Q. Chen, J. Luo, R. He, Dr. S. Ren, Y. Jiang, Z. Wan, Dr. W. Wang, Prof. J. Zhang, Prof. L. Wu, Prof. D. Zhao College of Materials Science and Engineering Engineering Research Center of Alternative Energy Materials & Devices Ministry of Education Sichuan University Chengdu, Sichuan 610065, China E-mail: rensq@scu.edu.cn; dewei.zhao@scu.edu.cn 

H. Lai, Dr. F. Fu Laboratory for Thin Films and Photovoltaics Empa–Swiss Federal Laboratories for Materials Science and Technology Ueberlandstrasse 129, Duebendorf CH-8600, Switzerland E-mail: Fan.Fu@empa.ch 

The ORCID identification number(s) for the author(s) of this article can be found under https://doi.org/10.1002/aenm.202101045. 

© 2021 The Authors. Advanced Energy Materials published by WileyVCH GmbH. This is an open access article under the terms of the Creative Commons Attribution License, which permits use, distribution and reproduction in any medium, provided the original work is properly cited. 

**DOI: 10.1002/aenm.202101045** 

Prof. X. Hao Institute of New Energy and Low-Carbon Technology Sichuan University Chengdu, Sichuan 610065, China Prof. Y. Wang Key Laboratory of Material Physics Ministry of Education School of Physics and Microelectronics Zhengzhou University Zhengzhou, Henan 450052, China 

Prof. I. Constantinou 

Institute of Microtechnology (IMT) and Center of Pharmaceutical Engineering (PVZ) Technische Universität Braunschweig 38124 Braunschweig, Germany 

Prof. C. Wang 

School of Optoelectronic Science and Engineering & Collaborative Innovation Center of Suzhou Nano Science and Technology Key Lab of Advanced Optical Manufacturing Technologies of Jiangsu Province & Key Lab of Modern Optical Technologies of Education Ministry of China Soochow University Suzhou 215006, China 

**2101045 (1 of 10)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101045 

**www.advancedsciencenews.com** 

the long-wavelength light and a wide- _E_ g (≈1.7–1.9 eV) perovskite harvesting the short-wavelength light.<sup>[20–22]</sup> Partial substitution of tin (Sn) into lead (Pb) perovskite tunes the bandgap of mixed SnPb perovskites in a wide range of ≈1.17–2.18 eV.<sup>[23–26]</sup> A high-quality low- _E_ g perovskite absorber is a prerequisite for fabricating high-performance all-perovskite tandem solar cells, when paired with a wide- _E_ g perovskite absorber.<sup>[7,9,27]</sup> 

Incorporation of Sn accelerates the crystallization process of mixed SnPb perovskites, leading to uncontrollable morphology and disordered grain orientation.<sup>[20,28,29]</sup> Heterogeneous nucleation and rapid crystallization lead to high trap density of mixed SnPb perovskite films and inhomogeneity of the film quality when grown on substrate, greatly reducing the carrier mobility.<sup>[11]</sup> On the other hand, the introduction of Sn makes the mixed SnPb perovskites intrinsically p-doped due to the Sn vacancies mainly resulting from the readily oxidation of Sn<sup>2+</sup> to Sn<sup>4+</sup> ,<sup>[10,15,20,30,31]</sup> leading to high hole carrier concentration, low carrier mobility, and increased non-radiative recombination loss, thus making the performance of low- _E_ g PSCs unstable and underestimated. 

To address the aforementioned issues, many efforts have been devoted to regulating the crystallization processes via onestep method<sup>[7]</sup> or two-step method,<sup>[11,32]</sup> or by adding additives into SnPb perovskite precursors such as metallic Sn powders,<sup>[10,33]</sup> ascorbic acid,<sup>[34]</sup> halide anions (e.g., Br<sup>−</sup> , Cl<sup>−</sup> ),<sup>[9,35]</sup> surface anchoring agent,<sup>[15]</sup> and thiocyanate-based additives (e.g., MASCN, GuaSCN)<sup>[11,16,32]</sup> to prevent the formation of Sn vacancies, which prolongs the carrier lifetime and increases the carrier diffusion length. Although the tremendous advance has been achieved in low- _E_ g PSCs with efficiencies up to 21.7%,<sup>[15]</sup> further suppressing Sn vacancies, improving carrier lifetime and diffusion length in low- _E_ g mixed SnPb perovskites via controlling the crystallization process or incorporating additives are of great challenge to unlock their maximum potential in terms of their bandgaps.<sup>[36,37]</sup> 

Tin fluoride (SnF2), as the most commonly used additive, has been first used in Pb-free Sn-based PSCs,<sup>[30,38–44]</sup> in which SnF2 can effectively inhibit the generation of Sn vacancies, and thus significantly reduce the hole density<sup>[30,39,45,46]</sup> by means of SnF2 itself,<sup>[30,38,39,42,43]</sup> SnF2·3FACl (FA = formamidinium),<sup>[47]</sup> (SnF2(DMSO))2 (DMSO = dimethyl sulfoxide),<sup>[48]</sup> etc. Inheriting the great success of SnF2 in Sn-based PSCs, most of existing low- _E_ g mixed SnPb PSCs have employed SnF2 as one indispensable additive and exploited the functions of the additional additives, but no detailed studies have been reported to comprehensively investigate the roles of such extremely important SnF2 in both mixed SnPb perovskite absorbers and devices, especially in efficient low- _E_ g mixed SnPb PSCs. The case has changed until a recent investigation, where Herz and coworkers have systematically studied the effect of SnF2 on the properties of FA-Cs-based mixed SnPb perovskite thin films.<sup>[46]</sup> It is claimed that the addition of SnF2 significantly decreases the background hole density related to Sn vacancies, resulting in longer carrier lifetime, less energy disorder, less Burstein–Moss transfer, higher charge carrier mobility, and reduces the tetragonal distortion in mixed SnPb perovskites originating from the strain due to the existence of Sn vacancies, especially in the case of high Sn content. While this study has only focused on Cs-FA SnPb perovskite films, no devices have been shown for 

**www.advenergymat.de** 

further discussion. Thus, it is highly desired to gain in-depth insights and a full understanding of SnF2 additives in both low- _E_ g mixed SnPb perovskite films and efficient low- _E_ g devices. 

Here, we systematically investigate the effect of SnF2 additive on both optoelectronic properties of low- _E_ g mixed SnPb perovskite films and solar cells performance. We find that a decent amount of SnF2 not only suppresses the oxidation of Sn<sup>2+</sup> and reduces the hole concentration related to Sn vacancies, but also promotes the topological growth of perovskite grains, which reduces the disorder of crystal arrangement in low- _E_ g mixed SnPb perovskite and significantly improves the crystallinity as well as reduces the defects.<sup>[49]</sup> It is more interesting that the F<sup>−</sup> ion prefers accumulating at the hole transport layer/perovskite interface, which increases the defects. As a result, our optimized PSC with 5% SnF2 achieves a greatly enhanced PCE of 20.27% with an open-circuit voltage ( _V_ OC) of 0.834 V, a short-circuit current density ( _J_ SC) of 30.60 mA cm<sup>−2</sup> , and a fill factor (FF) of 79.41% under forward voltage scan, much higher than that (12.21%) of control devices without SnF2. Our work suggests that such a fundamental understanding of SnF2 additives would definitely help unveil the in-depth mechanisms of additional additives and approaches proposed in efficient low- _E_ g mixed SnPb PSCs toward making highly efficient all-perovskite tandem solar cells. 

## **2. Results and Discussion** 

We investigate the effect of SnF2 in our previously well-developed and well-reproduced low- _E_ g (≈1.25 eV) (FASnI3)0.6(MAPbI3)0.4 precursors on both perovskite films and devices.<sup>[7–9,16,33,35,50]</sup> We prepared (FASnI3)0.6(MAPbI3)0.4 perovskite thin films with different SnF2 concentrations via the antisolvent dripping method as previously reported.<sup>[7,9]</sup> 

We first examined the morphology and crystal structure of low- _E_ g mixed SnPb perovskites with varying SnF2 concentrations via scanning electron microscope (SEM) and X-ray diffraction (XRD). **Figure 1** A,B show the top-view SEM images of (FASnI3)0.6(MAPbI3)0.4 films on indium tin oxide (ITO)/poly(3,4-ethylenedioxythiophene):polystyrenesulfonate (PEDOT:PSS) with 0% SnF2 as control and 5% SnF2. The grain sizes on the surface of (FASnI3)0.6(MAPbI3)0.4 films with and without SnF2 are similar (Figure 1A,B and Figure S1A–E, Supporting Information). However, the surface morphology of the low- _E_ g mixed SnPb perovskites with SnF2 added appears regular linear stripes with a directional arrangement on every single grain (Figure 1B and Figure S1B–E, Supporting Information), which is obviously distinguished from the “clean morphology” of the low- _E_ g mixed SnPb perovskite without SnF2 (Figure 1A). We call such oriented striped surface morphology due to the existence of SnF2 as “domain morphology”. 

The cross-sectional SEM images of the 0% SnF2 and 5% SnF2 devices with a structure of ITO/PEDOT:PSS/ (FASnI 3) 0.6(MAPbI 3) 0.4/C 60/2,9-dimethyl-4,7-diphenyl1,10-phenanthroline (BCP)/Ag are shown in Figure 1C,D. The 0% SnF2 film has two or several small grains lying within the film thickness, while the 5% SnF2 film has only one complete grain across the film. The growth of the 0% SnF2 low- _E_ g perovskite crystals is horizontally preferred along the plane of the substrate (Figure 1C), that is, the crystal growth orientation inside 

**2101045 (2 of 10)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101045 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 





**Figure 1.** A,B) Top-view and C,D) cross-sectional SEM images of (FASnI3)0.6(MAPbI3)0.4 films with 0% and 5% SnF2. E) Schematic illustration of the influence of SnF2 on (FASnI3)0.6(MAPbI3)0.4 perovskite growth. F) XRD patterns and G) FWHM of (110) peak of the (FASnI3)0.6(MAPbI3)0.4 films with various concentration of SnF2, and H) the expanded figure at ≈14.6° of 2 _θ_ . 

the film shows a disordered mode. By contrast, the 5% SnF2 low- _E_ g perovskite crystals grow in both horizontal and vertical directions of the substrate, that is, the crystal growth orientation inside the film shows highly uniform and highly ordered mode. It is worth noting that the films with SnF2 doping concentration of 10–20% also show the same growth mode and “domain morphology” as those of 5% SnF2 film (Figure 1D and Figures S1 and S2, Supporting Information). We attribute the formation of the “domain morphology” to the topological growth of the crystal due to the doping of SnF2 in the precursor solution, as illustrated in Figure 1E. As reported, a simple topology oriented attachment process facilitates the growth of highly oriented perovskite thin films due to the incorporation of halogen ions into the perovskite precursor solution,<sup>[49]</sup> leading to strong uniaxial crystalline texture, micron-sized grain morphology, high crystallinity, low trap density, and unprecedented high charge carrier mobility in FA0.6MA0.4PbI(3− _y_ )Cl _y_ perovskite films. The similar topological growth mode observed in our SnF2 doped (FASnI3)0.6(MAPbI3)0.4 films indicates high orientation of the normative crystallization, largely reduced grain boundaries (GBs), and thus decreased trap density in the bulk. In terms of the identical thicknesses of all films with various SnF2 concentrations confirmed by the cross-sectional SEM images (Figure S2, Supporting Information) and their unchanged absorption spectra (Figure S3, Supporting Information), such “domain morphology” would be beneficial for fundamentally improving the carrier transport. 

Figure 1F shows the XRD patterns of low- _E_ g (FASnI3)0.6(MAPbI3)0.4 films with different SnF2 doping concentrations of 0%, 5%, 10%, 15%, and 20%. All XRD patterns show strong (110) and (220) diffraction peaks, indicating a highly preferred orientation. Note that the 0% SnF2 film exhibits an inferior peak intensity, compared with other SnF2-incorporated perovskite films. With the increase of SnF2 concentration, the peak intensity does not change much. The full-width at half-maximum (FWHM) values of the (110) peak of (FASnI3)0.6(MAPbI3)0.4 films with SnF2 doping concentrations of 0%, 5%, 10%, 15%, and 20% are 0.154° ± 0.003°, 0.125° ± 0.001°, 0.139° ±0.001°, 0.141° ± 0.001°, and 0.147° ± 0.001°, respectively (Figure 1G and Table S1, Supporting Information), indicating that the 5% SnF2 film has the highest crystallinity. While, with the increase of SnF2 concentration, the crystallinity of (FASnI3)0.6(MAPbI3)0.4 perovskite film is slightly reduced. Interestingly, the (110) peak at 2 _θ_ ≈14.6° gradually shifts from 14.62° to 14.54° as the SnF2 concentration increases (Figure 1H). We speculate that the addition of SnF2 reduces the formation of Sn vacancies in (FASnI3)0.6(MAPbI3)0.4 films, which makes the lattice constant of perovskite return to normal (i.e., the increase of lattice constant), resulting in the slight shift of the position of (110) peak to the left.<sup>[11,35,46]</sup> 

Another important role of SnF2 is to alleviate Sn<sup>2+</sup> from being oxidized to Sn<sup>4+</sup> , which is recognized as one of the key issues for low- _E_ g PSCs.<sup>[10,30,51]</sup> Tan group claimed that Sn<sup>2+</sup> is easily oxidized to Sn<sup>4+</sup> in the precursor solution and the commonly used reductant SnF2 additive could not completely 

**2101045 (3 of 10)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101045 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 2.** A–E) Sn 3d5/2 XPS spectra, F) Mott−Schottky plots, G) hole concentration, H) PL spectra, and I) TRPL spectra of (FASnI3)0.6(MAPbI3)0.4 films with various SnF2 concentrations. 

prevent the oxidation of Sn<sup>2+</sup> ,<sup>[15]</sup> however, it is still worth evaluating the antioxidant capability of SnF2 additive in SnPb perovskites. We then carried out X-ray photoelectron spectroscopy (XPS) measurements of (FASnI3)0.6(MAPbI3)0.4 films with various SnF2 doping concentrations ( **Figure 2** A–E). Clearly, the 5% SnF2 film shows lower peak intensity of Sn<sup>4+</sup> compared with the 0% SnF2 perovskite film. With the increase of SnF2 concentration, the peak intensity of Sn<sup>4+</sup> decreases and almost turns saturated until 20% SnF2 is added. This implies that a small amount of SnF2 doping plays a crucial role in suppressing Sn oxidation, leading to decreased Sn vacancies. Thus, this would benefit the reduction of hole concentration in mixed SnPb films and the improvement of device performance. 

We then performed capacitance–voltage ( _C_ – _V_ ) measurements to determine the hole concentrations in the (FASnI3)0.6(MAPbI3)0.4 films with varying SnF2 concentration (Figure 2F). According to the reciprocal of the square of capacitance ( _C_<sup>−2</sup> ) versus the potential ( _V_ ), and the hole concentrations ( _N_ A) of devices are estimated by the following equation, 1 2 2 = 2 ( _V_ bi − _V_ ), where _e_ , _εε_ 0 ( _ε_ = 20 and _ε_ 0 = 8.85 × _C A e_ εε0 _N_ A 10<sup>−12</sup> F m<sup>−1</sup> ),<sup>[30,52]</sup> _V_ bi, and A are the elementary charge, semiconductor permittivity, built-in potential, and active area of the device, respectively.<sup>[30,52]</sup> The slope _K_ is obtained by linear fitting of the curve, and the hole concentration _N_ A can be calculated by 2 the formula _N A_ = _A_ 2 _e_ εε0 _K_ . The dependence of hole concentration on SnF2 doping concentration is plotted in Figure 2G. The 0% SnF2 perovskite film has a relatively high hole concentration 

of 1.18 ± 0.85 × 10<sup>17</sup> cm<sup>−3</sup> , however, upon the incorporation of SnF2, the hole concentrations are decreased by roughly one order of magnitude to 1.08 ± 0.11 × 10<sup>16</sup> , 1.01 ± 0.17 × 10<sup>16</sup> , 0.95 ± 0.05 × 10<sup>16</sup> , and 0.91 ± 0.04 × 10<sup>16</sup> cm<sup>−3</sup> for 5, 10, 15, and 20% SnF2 films, respectively, which is more suitable for solar cell applications. This result is consistent with the XPS results on the Sn<sup>4+</sup> content variation. Our results suggest that merely a small amount of SnF2 helps decrease the Sn vacancies and hole concentration, but the hole concentration cannot be further reduced with only SnF2 doping. 

We further conducted steady-state photoluminescence (PL) and time-resolved PL (TRPL) measurements to examine charge recombination and lifetimes. We deposited (FASnI3)0.6(MAPbI3)0.4 films on glass/ITO/PEDOT:PSS to ensure consistency with our device structure. Films with different SnF2 concentrations display almost the same emission peak at ≈1000 nm (Figure 2H,I), which is in agreement with the trend of their absorption onsets. The 5% SnF2 film has the highest PL intensity, indicating reduced non-radiative recombination and thus decreased density of trap states in the film. We attribute this to the fact that the addition of optimal 5% SnF2 effectively inhibits the formation of Sn vacancies, while too much SnF2 would lead to unnecessary defect recombination. We further extracted the charge carrier lifetime from the TRPL decay plot fitted by the bi-exponential equation, as shown in Figure 2I and Table S2, Supporting Information. The mean carrier lifetime of 0% SnF2 perovskite film is only 20 ns, which is significantly lower than those of other perovskite films with SnF2 (98, 90, 73, and 52 ns for 5%, 10%, 15%, and 20% SnF2 

**2101045 (4 of 10)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101045 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 3.** A,B) Tapping-mode AFM and E,F) KPFM images of low- _E_ g mixed SnPb perovskite films with SnF2 concentration of A,E) 0%, B,F) 5%, and the corresponding C,D) AFM and G,H) KPFM line scans. The AFM and KPFM images have dimensions of 3 × 3 µm<sup>2</sup> . 

films, respectively). The trend of carrier lifetimes dependent on various SnF2 concentrations is similar to that of the FWHM values of the (110) peak and PL intensity. The increase in mean carrier lifetime is consistent with the increase of film crystallinity as revealed by the FWHM values and the decrease of Sn vacancies as revealed by the hole concentration results. This indicates that the improvement of crystallinity and the suppression of Sn vacancies simultaneously promote the improvement of carrier lifetimes of the (FASnI3)0.6(MAPbI3)0.4 perovskite film. 

To further understand the role of SnF2 on surface morphology and potential of low- _E_ g (FASnI3)0.6(MAPbI3)0.4 perovskite films, atomic force microscopy (AFM), and Kelvin probe force microscopy (KPFM) measurements were performed, as shown in **Figure 3** and Figures S4 and S7, Supporting Information. The 0% SnF2 and 5% SnF2 perovskite films have a root mean square roughness ( _R_ q) of 31.9 and 25.5 nm, respectively, and show similar surface morphology to that observed in SEM images (Figure 1A,B). According to the AFM line scan, the height at GBs in 0% SnF2 film is significantly lower than that at grain interiors (GIs), exhibiting a large peak-valley fluctuation curve (Figure 3C). The GB/GI height contrast in 5% SnF2 perovskite film is relatively small, and the overall curve is relatively flat (Figure 3D). This suggests that 5% SnF2 incorporation effectively smoothens the perovskite surface. With the increase of SnF2 concentration from 10 to 20%, the height difference between GB and GI in films gradually appears to be obvious (Figures S4 and S5, Supporting Information). 

More GBs and disordered crystal growth in the 0% SnF2 film have been observed than that in the 5% SnF2 film, indicating the formation of more defects. It is inferred that the addition of SnF2 could passivate the defects, which is confirmed by KPFM measurements.<sup>[20,42]</sup> Figure 3E–H and Figures S6 and S7, Supporting Information, show the KPFM maps and KPFM line scans of (FASnI3)0.6(MAPbI3)0.4 perovskites with various SnF2 concentrations. The KPFM map shows that the GBs have a deeper work function (Fermi Energy) than GIs for the 0% SnF2 perovskite film (Figure 3E,G). The deeper work function could originate from a higher hole density or higher density 

of defects. When 5% SnF2 is added to the perovskite film, the potential contrast between GB and GI is largely reduced (Figure 3F,H), indicating decreased hole density and density of defects at GBs. We believe that the passivation of these defects is related to the reduction of Sn vacancies, verified by the XPS, PL, and TRPL results. The increase in SnF2 concentration from 10 to 20% slightly increases the potential contrast between GBs and GIs, however, the potential contrast is still lower than that in the 0% SnF2 film. This means that excessive SnF2 will induce defects in perovskite films along with no much change of hole concentration in the films, which will be detrimental to the device performance. Therefore, SnF2 effectively passivates the defects at GBs. 

The roles of SnF2 are summarized as shown in Figure 1E. SnF2 regulates the growth mode of low- _E_ g mixed SnPb perovskite films, leading to columnar grain growth and improved crystallinity. SnF2 suppresses the formation of Sn vacancies, leading to decreased hole concentration, increased lattice constant, and passivated defects. These effects synergistically reduce non-radiative recombination losses and facilitate the performance of low- _E_ g SnPb PSCs. 

The aforementioned characterizations have shown significant impacts of SnF2 additives on the optoelectronic properties of (FASnI3)0.6(MAPbI3)0.4 films. To further evaluate the effect of SnF2 concentration on device performance, we fabricated inverted devices as shown in Figure 1C,D. On the one hand, SnF2 doping makes the perovskite film highly oriented and highly crystalline, beneficial for the charge transport improvement. On the other hand, the incorporation of SnF2 inhibits Sn oxidation, reduces Sn vacancies, passivates the defects, leading to suppression of non-radiative recombination loss. However, excessive SnF2 doping neither improves the crystallinity nor further prevents Sn oxidation, instead induces excessive SnF2 impurities. Therefore, the SnF2 concentration needs optimization in devices. The statistics of _V_ OC, _J_ SC, FF, and PCE of these PSCs are shown in **Figure 4** A–D and Table S3, Supporting Information. The _J_ – _V_ curves of the typical devices with different SnF2 concentrations under 100 mW cm<sup>−2</sup> AM 1.5G illumination are shown in Figure S8, Supporting Information. 

**2101045 (5 of 10)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101045 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 4.** Statistics of photovoltaic parameters of (FASnI3)0.6(MAPbI3)0.4 PSCs with various SnF2 concentrations under 100 mW cm<sup>−2</sup> AM 1.5G solar irradiation under forward voltage scan: A) _V_ OC, B) _J_ SC, C) FF, and D) PCE. 40 devices for each SnF2 concentration were fabricated. E) Dark _J–V_ curves and F) EQE spectra of devices with different SnF2 concentrations. G) ToF-SIMS depth profile of ITO/PEDOT:PSS/(FASnI3)0.6(MAPbI3)0.4 films with different SnF2 concentrations. H) _J–V_ curves of the champion device measured under forward and reverse voltage scans. I) Corresponding EQE spectrum and integrated _J_ SC of the champion device. 

To be specific, the average _V_ OC of the 5% SnF2 devices is 0.832 V, larger than those of the 0% SnF2 devices (0.679 V) and the 2.5% SnF2 device (0.745 V) (Figure S8, Supporting Information). With further increasing the SnF2 concentration, the average _V_ OC is 0.834, 0.835, and 0.837 V when the SnF2 concentration is 10%, 15%, and 20%, respectively, exhibiting no significant variation. This trend is consistent with the change of hole concentration with SnF2 doping. We regard this as limited contribution of excessive SnF2 to suppression of Sn oxidation. The average _J_ SC and FF first increase and then decrease with the increase in SnF2 concentration. Both get the peak values at 5% SnF2. The increase in _J_ SC and FF is due to the topological growth of the film and the suppressed Sn vacancies, leading to enhanced crystallinity and reduced defects. The decrease in _J_ SC and FF at higher SnF2 concentrations results from more defects and reduced crystallinity induced by the excessive SnF2, also evidenced by the trend in our dark _J_ – _V_ curves of the devices with varying SnF2 concentrations (Figure 4E). In order to obtain the dark saturation current density ( _J_ 0) of devices under different SnF2 concentrations, according to _J_ = _J_ 0 [ _exp_  _<u>qV</u>_  1], <sup></sup> _nkBT_ <sup>−</sup> 

the logarithmic value of current density _Ln_ ( _J_ ) with respect to voltage _V_ is obtained: _Ln_ ( _J_ ) = _Ln_ ( _J_ 0 ) + _nkqBT_<sup>_V_</sup> , where _k_ B is the Boltzmann constant, _T_ is the temperature in Kelvin, q is the elementary charge, _J_ is the current density, _n_ is the ideality factor. 

Then, the _Ln_ ( _J_ )– _V_ curves are plotted in Figure S9, Supporting Information, and the part of the linear change of the curve can be linearly fitted to obtain the intercept value of the y axis, then the _J_ 0 of the device can be calculated.<sup>[53]</sup> The _J_ 0 is 1.28 × 10<sup>−6</sup> mA·cm<sup>−2</sup> for 0% SnF2 device, indicating a large defect state density and leakage current. With the addition of a small amount of SnF2 (e.g., 5% and 10% SnF2), the _J_ 0 decreases sharply to 4.42 × 10<sup>−8</sup> mA·cm<sup>−2</sup> and 5.04 × 10<sup>−8</sup> mA·cm<sup>−2</sup> , respectively, which is attributed to SnF2 limiting the generation of Sn vacancies and reducing the defect state density. This helps improve the FF. However, with the addition of 15% and 20% SnF2, the _J_ 0 turn to increase to 1.96 × 10<sup>−7</sup> and 5.01 × 10<sup>−7</sup> mA·cm<sup>−2</sup> , which suggests that excessive SnF2 will introduce unnecessary impurities to increase the defect state density of the device and reduce the FF to a certain extent. 

To gain further insight into the role of SnF2 in devices, especially the influence on the front and back interfaces, we measured the external quantum efficiency (EQE) spectra of (FASnI3)0.6(MAPbI3)0.4 PSCs with different SnF2 concentrations as shown in Figure 4F. Their EQE-integrated _J_ sc values are 23.78, 29.24, 28.96, 28.47, and 26.61 mA cm<sup>−2</sup> for the devices with 0%, 5%, 10%, 15%, and 20% SnF2, respectively. The spectral response of the devices with SnF2 added is much higher than that of the device without SnF2 in the entire wavelength range, which is attributed to the largely enhanced carrier lifetime in 5% SnF2 film originating from improved crystallinity, 

**2101045 (6 of 10)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101045 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 

reduced Sn vacancies and hole concentration, passivated defects, that is, the charge carriers transporting in the vertical direction across the absorber layer encounter less GBs. With the increase of SnF2 concentration, the overall EQE values first increase, get to peak values at SnF2 concentration of 5%, and then decrease with further increase of the SnF2 concentration. Note that two distinctively enhanced regions can be observed: one is from 700 to 950 nm and the other is from 350 to 500 nm. We attribute the increase in the range of 700–950 nm to the reduced defects, as evidenced by the prolonged carrier lifetimes of films obtained by TRPL (Figure 2I).<sup>[7]</sup> 

More interestingly, we see significant differences in EQE values from 350 to 500 nm. As known, when light is incident from the ITO side, different wavelengths of light will have different incident depths in the perovskite absorption layer. For example, the incident depth of the short-wavelength light is shorter, that is, absorbed at the front interface region, while the incident depth of the long-wavelength light is longer, that is, far away from the front interface. As the SnF2 concentration further increases, the EQE values in the range of 350–500 nm decrease, indicating that excessive SnF2 has negative effects on the perovskite/PEDOT:PSS interface region. We speculate that excessive SnF2, for example, higher than 10%, may accumulate and form the SnF2-rich region nearby the PEDOT:PSS/perovskite interface. To probe the distribution of SnF2 throughout the perovskite film, we performed the time-of-flight secondary ion mass spectrometry (ToF-SIMS) on samples with perovskite/ PEDOT:PSS/ITO/glass layer stack. In Figure 4G, we present the depth profiles of negative secondary ions, such as F<sup>−</sup> , [CsSO3]<sup>−</sup> , and In<sup>−</sup> to represent SnF2, PEDOT:PSS, and ITO layer, respectively. The F<sup>−</sup> distributes throughout the perovskite film, but preferentially accumulates at the PEDOT:PSS/perovskite interface and the perovskite surface. Particularly, there is a clear trend of F<sup>−</sup> ion accumulation at the PEDOT:PSS/perovskite interface in samples with high SnF2 content. Thus, the excessive SnF2 could intrinsically increase the defects and hinder the hole transport to the PEDOT:PSS/perovskite interface. 

As a result, our optimal device with 5% SnF2 achieves an average PCE of 19.73% with an average _V_ OC of 0.831 V, an average _J_ SC of 30.08 mA cm<sup>−2</sup> , and an average FF of 78.7%. The trend of the device performance is consistent with the aforementioned characterization results of the films. We attribute these improvements to enhanced crystallinity, reduced Sn vacancies and hole concentration, as well as passivated defects upon the incorporation of SnF2. 

The _J–V_ curves of our champion PSC under 100 mW cm<sup>−2</sup> AM1.5G solar irradiation are shown in Figure 4H. The 5% SnF2 device achieves the highest PCE of 20.27% (20.20%) measured under reverse (forward) voltage scan, along with a _J_ SC of 30.6 (30.5) mA cm<sup>−2</sup> , a _V_ OC of 0.834 (0.832) V, and a FF of 79.41% (79.59%), showing neglectable _J_ – _V_ hysteresis. As summarized on recently reported low- _E_ g mixed SnPb mixed FA-MA PSCs (Table S4, Supporting Information), the PCE of our optimized device with 5% SnF2 is among the best values in literature. The EQE-integrated _J_ SC over a 100 mW cm<sup>−2</sup> AM1.5G solar spectrum is 29.80 mA cm<sup>−2</sup> , as shown in Figure 4I, in good agreement with the _J_ SC value from the _J–V_ measurement. The steady-state efficiency is 19.75% by tracking the maximum output power for 900 s under a 100 mW cm<sup>−2</sup> AM1.5G illumination, much higher than that (12.21%) of the cell without SnF2 (Figure S10, Supporting Information). We have fabricated 40 pieces of 5% SnF2 devices in several batches. The PCE histogram demonstrates good reproducibility of our devices (Figure S11, Supporting Information). The 5% SnF2 device shows better stability than the 0% SnF2 device (Figure S12, Supporting Information). 

We conducted transient photocurrent (TPC) measurements to assess the effect of the SnF2 incorporation on carrier transport in the devices ( **Figure 5** A). We used a 532 nm laser light with 10 µs pulses to excite TPC in the active area of the device. When the laser is incident to the perovskite absorption layer, the light-generated holes can quickly inject into the hole transport layer (ITO/PEDOT:PSS), and the lightgenerated electrons diffuse through the perovskite layer and are collected at the electron transport layer (C60/BCP/Ag). The TPC measurement reflects the minority carrier (electron) diffusion through the absorber layer. A longer decay time of photocurrent means a longer carrier lifetime.<sup>[9]</sup> We find that the variation of photocurrent decay times of the devices with different SnF2 concentrations is consistent with that of the EQE values in the wavelength range of 300–550 nm (Figure 4F). The device with 5% SnF2 has the longest photocurrent decay time. With the increase of SnF2 concentration, the photocurrent decay time gradually decreases. When 20% SnF2 is added, the photocurrent decay time is even shorter than that of the device without SnF2. We attribute this to more efficient hole extraction at the PEDOT:PSS/perovskite interface and longer minority carrier diffusion length. However, the excessive doping of SnF2 (20% SnF2) causes more defects, especially at the PEDOT:PSS/perovskite interface where the F<sup>−</sup> 



**Figure 5.** A) TPC decay curves of (FASnI3)0.6(MAPbI3)0.4 PSCs with different SnF2 concentrations. Light-intensity dependence of C) _V_ OC and D) _J_ SC for PSCs with 0% and 5% SnF2. 

**2101045 (7 of 10)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101045 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

accumulates more, as verified by the ToF-SIMS depth profile (Figure 4G), detrimental to the crystallinity and the carrier diffusion length. 



<!-- Start of picture text -->
To further examine the charge extraction and charge recom-<br>bination processes in 0% SnF2 and 5% SnF2 devices, we meas-<br>ured the  J–V  characteristics of the devices under different<br>light intensities ranging from 0.1 to 1 sun. Figure 5B shows<br>the relationship between  V OC and logarithmic light intensity.<br>V OC increases monotonically with logarithmic light intensity.<br>According to  V OC = nkBT ln  I + 1<br>q   I 0   , where  k B is the Boltzmann<br><!-- End of picture text -->

constant, _T_ is the temperature in Kelvin, _q_ is the elementary charge, _I_ is the light intensity, and _I_ 0 is the initial light intensity, _n_ is the ideality factor, which is often used to determine the dominant recombination mechanism in solar cells and the value over 1 reflects the presence of trap-assisted Shockley–Read–Hall recombination. The device with 5% SnF2 has an _n_ value of 1.20, whereas the device with 0% SnF2 has one of 1.59 (Figure 5B). The smaller _n_ indicates a reduction of the trap-assisted recombination, in good agreement with the enhanced carrier lifetime. This confirms the reduction of Sn vacancy defects and the increase of crystallinity and charge transport by the topological growth in SnF2-incorporated low- _E_ g perovskite film. Figure 5C shows the power-law dependence of the _J_ SC on light intensity ( _J_ SC∝ _I_<sup>_α_</sup> ), where _I_ and _α_ are the light intensity and exponential factor, respectively. The _α_ values of 0.988 and 0.991 for 0% SnF2 and 5% SnF2 devices, respectively, are both close to 1, showing that there is no space charge limiting current in the process of charge extraction, and no large energy barrier is produced. 

For future development of efficient low- _E_ g SnPb PSCs, some significant points might help: 1) preventing oxidation of Sn<sup>2+</sup> to Sn<sup>4+</sup> via incorporating antioxidants or reducing agents in perovskite precursors; 2) detarding crystallization process to form uniform and defect-less SnPb perovskite films via developing unique techniques or additives; 3) aligning energy levels between SnPb perovskites and charge transport layers via accurately determining the energy levels of SnPb perovskites with different compositions; 4) mixing dimensionality in bulk and/or forming 3D/2D structures to enhance film and device stability via incorporating lower dimensional perovskites and finely modulating charge transport capability. 

## **3. Conclusion** 

In conclusion, we have demonstrated the crucial roles of SnF2 additives in optoelectronic properties of both low- _E_ g mixed SnPb perovskite films and solar cells, to facilitate the topological growth of perovskite grains, suppress the oxidation of Sn<sup>2+</sup> and reduce the hole concentration related to Sn vacancies, leading to enhanced crystallinity, reduced defects at GBs, and improved carrier lifetime. As a result, the optimal device with 5% SnF2 incorporated achieves a greatly enhanced PCE of 20.27% compared with that (12.21%) of control one. This work offers a basis for better understanding the roles of single SnF2 additive in both films and devices, benefiting the further development of high-performance low- _E_ g mixed SnPb perovskites together with multiple additives and approaches. 

## **4. Experimental Section** 

_Film Preparation_ : Pristine low- _E_ g (FASnI3)0.6(MAPbI3)0.4 perovskite precursor was prepared as reported in our previous works.<sup>[7,9]</sup> The details can be found below. The FASnI3 precursor solution was prepared by dissolving 372 mg of SnI2 (Aldrich Sigma) and 172 mg of FAI (GreatCell Solar Company) in mixed N,N-dimethylmethanamide (DMF) (Aldrich Sigma, anhydrous) and DMSO (Aldrich Sigma, anhydrous). The MAPbI3 precursor solution was prepared by dissolving 461 mg PbI2 (Alfa Aesar, 99.9985%) and 159 mg MAI (GreatCell Solar Company) with 3.5 mol% (11.3 mg) lead thiocyanate (Pb(SCN)2) (Aldrich Sigma, 99.5%) dissolved in 630 µL DMF and 70 µL DMSO. The SnF2 with different concentration (0, 3.9, 7.8, 15.6, 23.4, and 31.2 mg) was added to the FASnI3 precursor solution. Then stoichiometric amounts of FASnI3 and MAPbI3 perovskite precursors were mixed to obtain the (FASnI3)0.6(MAPbI3)0.4 precursor solution with _x_ % SnF2 ( _x_ = 0, 2.5, 5, 10, 15, 20). All the aforementioned materials were weighed in a glove box filled with high-purity N2. PEDOT:PSS (CLEVIOS P VP AI 4083) was purchased from Heraeus, LLC. C60 was purchased from Nano-C. BCP was purchased from Jilin OLED Company (China). All chemicals used in this work were commercially available and were used as received. The samples for top-view SEM, XRD, AFM, KPFM, PL, TRPL measurements were obtained by spin-coating their corresponding precursor solutions onto ITO/PEDOT:PSS. The samples for XPS and optical absorption spectrum measurements were coated on glass. 

_Device Fabrication_ : The pre-patterned ITO substrates were first wiped with detergent and then cleaned by sonication for 15 min in deionized water and ethanol sequentially. After drying under an N2 stream, the substrates were cleaned by UV/Ozone treatment (UVOCS Inc.) for 20 min. PEDOT:PSS films were coated on the cleaned ITO substrate at 4000 rpm for 50 s and then dried at 145 °C for 45 min. The precursors with varying SnF2 concentrations were spin-coated onto ITO/PEDOT:PSS at 5,000 rpm for 60 s. Diethyl ether was applied drop-wise at 5 s onto the spinning substrate during the spin-coating. All perovskite films were annealed at 70 °C for 3 min and then 105 °C for 7 min in a glove box. Then, the perovskite thin films were transferred into a vacuum chamber for thermal evaporation. When the vacuum reached ≈3 × 10<sup>−4</sup> Pa, C60 (20 nm)/BCP (5 nm)/Ag (75 nm) was sequentially deposited on the perovskite films to complete the solar cell fabrication, and the vacuum pressure during deposition of C60 layer, BCP layer, and Ag electrode was kept in the range of 0.8–3 × 10<sup>−4</sup> Pa. The active areas of the devices through an aperture mask were 0.0784 cm<sup>2</sup> . Devices were encapsulated with cover glass and UV-curable epoxy. 

_Film Characterization_ : High-resolution field emission SEM images of low- _E_ g perovskite films with varying SnF2 concentration were taken with FE-SEM, Regulus-8230, Hitachi. The cross-sectional SEM images of inverted PSC were taken with Hitachi S-4800. The XRD data of (FASnI3)0.6(MAPbI3)0.4 perovskite films with varying SnF2 concentration were obtained using a Shimazu XRD-6100 diffractometer with Cu-K _α_ radiation under operation conditions of 40 kV and 30 mA excitation. AFM and KPFM of low- _E_ g perovskite films with varying SnF2 concentrations were taken with Bruker Nano Inc DI Multi Mode 8. AFM and KPFM with commercially available MESP conductive probe coated with Co/Cr. XPS results of (FASnI3)0.6(MAPbI3)0.4 perovskite films with varying SnF2 concentrations were obtained using ESCALAB 250Xi, Thermo-Fisher Scientific. The absorption spectra of the perovskite films were measured by Lambda 950 UV–Vis spectrophotometer (PerkinElmer lnc.). PL and TRPL measurements were performed on the perovskite films coated with poly(methyl methacrylate) (PMMA) (ITO/PEDOT:PSS/perovskite/ PMMA) using FLS980 (Edinburgh Inc.). PL measurements were conducted using a 532-nm Xeon lamp with a monochromator while TRPL measurements were conducted using a 655-nm picosecond pulsed laser (EPL-655, 67.1 ps pulse width, 200 mm diameter). Fluorescence was detected via NIR detector. Bi-exponential fitting was adopted to calculate the carrier lifetimes. ToF-SIMS measurements were performed on a ToFSIMS.5 instrument from IONTOF, Germany, operated in spectral mode using a 25 keV Bi3<sup>+</sup> primary ion beam with an ion current of 0.39 pA. For depth profiling, a 1000 eV Cs<sup>+</sup> sputter beam with a current of 52.98 nA was used to remove the material layer-by-layer in interlaced mode from a raster area of 300 µm × 300 µm. Negative ions were collected for depth 

**2101045 (8 of 10)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101045 

**www.advancedsciencenews.com** 

profile analysis. The mass-spectrometry was performed on an area of 50 µm × 50 µm in the center of the sputter crater. 

_Device Characterization_ : _J–V_ curves were measured using a Keysight Technologies B2901A source meter under simulated AM 1.5 G solar illumination at 100 mW cm<sup>−2</sup> (1 sun). The light intensity was calibrated by silicon reference cells (SRC-00205, Enli Tech) with a solar simulator (SS-F5-3A, Enli Tech). The scanning rate was 100 mV s<sup>−1</sup> , having a delay time of 100 ms and a voltage step of 10 mV. The solar cells were measured using a black shadow mask with an aperture area of 0.0784 cm<sup>2</sup> . The steady-state PCEs were recorded by tracking the maximum power point. The light intensity dependence of _V_ OC and _J_ SC was performed by setting a series of light intensity and then the _J–V_ curves were measured. The EQE spectra were performed from 300 to 1100 nm with a QE system (QE-R, Enli Tech) using a chopper frequency of 210 Hz under neardark test conditions. The dark _J–V_ curves were recorded by the allin-one characterization platform (Paios, Fluxim AG, Switzerland). TPC measurement was performed following a previously reported method.<sup>[9]</sup> A 532 nm laser with a pulse duration of 10 µs and a delay of 3.5 ms was used to excited time-resolved photocurrent signals in these devices. The photocurrent signals were recorded by a fast-speed digital oscilloscope (Keysight, model DSOX6002A) operating at a 1 GHz acquisition rate. All temporal photocurrent spectra were averaged over 32 pulses. 

## **Supporting Information** 

Supporting Information is available from the Wiley Online Library or from the author. 

## **Acknowledgements** 

Q.C. and J.L. contributed equally to this work. This work was financially supported by the National Key Research and Development Program of China (No. 2019YFE0120000), the Fundamental Research Funds for the Central Universities (nos. YJ201955 and YJ201722), the Science and Technology Program of Sichuan Province (nos. 2020JDJQ0030, 2020YFH0079, and 2019ZDZX0015), the National Natural Science Foundation of China (nos. 62005188 and U1804132), Engineering Featured Team Fund of Sichuan University (2020SCUNG102), Natural Science Foundation of Jiangsu Province (BK20190825) the Ministry of Science and Culture (MWK) of Lower Saxony, Germany within the framework of the SMART BIOTECS alliance between the Technische Universität Braunschweig and the Leibniz Universität Hannover. F.F. acknowledges the funding from the Swiss Federal Office of Energy (SFOE)-BFE (project No. SI/501805-01). The authors would like to thank Dr. Yingming Zhu, from the Institute of New Energy and Low-Carbon Technology, Sichuan University, for SEM images capturing and analysis. 

## **Conflict of Interest** 

The authors declare no conflict of interest. 

## **Data Availability Statement** 

Research data are not shared. 

## **Keywords** 

low-bandgap perovskites, mixed SnPb, perovskite solar cells, Sn<sup>2+</sup> oxidation, topological growth 

Received: April 1, 2021 Revised: May 22, 2021 Published online: June 16, 2021 

**www.advenergymat.de** 

- [1] H. R. Tan, A. Jain, O. Voznyy, X. Z. Lan, F. P. G. de Arquer, J. Z. Fan, R. Quintero-Bermudez, M. J. Yuan, B. Zhang, Y. C. Zhao, F. J. Fan, P. C. Li, L. N. Quan, Y. B. Zhao, Z. H. Lu, Z. Y. Yang, S. Hoogland, E. H. Sargent, _Science_ **2017** , _355_ , 722. 

- [2] J. Huang, Y. Yuan, Y. Shao, Y. Yan, _Nat. Rev. Mater._ **2017** , _2_ , 17042. 

- [3] Y. Z. Wu, X. D. Yang, W. Chen, Y. F. Yue, M. L. Cai, F. X. Xie, E. B. Bi, A. Islam, L. Y. Han, _Nat. Energy_ **2016** , _1_ , 16148. 

- [4] A. Ren, H. Lai, X. Hao, Z. Tang, H. Xu, B. M. F. Yu Jeco, K. Watanabe, L. Wu, J. Zhang, M. Sugiyama, J. Wu, D. Zhao, _Joule_ **2020** , _4_ , 1263. 

- [5] P. Fu, S. Hu, J. Tang, Z. Xiao, _Front. Optoelectron._ **2021** , https://doi. org/10.1007/s12200-021-1227-z. 

- [6] M. Green, E. Dunlop, J. Hohl-Ebinger, M. Yoshita, N. Kopidakis, X. Hao, _Prog. Photovoltaics_ **2020** , _29_ , 3. 

- [7] D. Zhao, Y. Yu, C. Wang, W. Liao, N. Shrestha, C. R. Grice, A. J. Cimaroli, L. Guan, R. J. Ellingson, K. Zhu, X. Zhao, R.-G. Xiong, Y. Yan, _Nat. Energy_ **2017** , _2_ , 17018. 

- [8] D. Zhao, C. Wang, Z. Song, Y. Yu, C. Chen, X. Zhao, K. Zhu, Y. Yan, _ACS Energy Lett._ **2018** , _3_ , 305. 

- [9] D. Zhao, C. Chen, C. Wang, M. M. Junda, Z. Song, C. R. Grice, Y. Yu, C. Li, B. Subedi, N. J. Podraza, X. Zhao, G. Fang, R.-G. Xiong, K. Zhu, Y. Yan, _Nat. Energy_ **2018** , _3_ , 1093. 

- [10] R. Lin, K. Xiao, Z. Qin, Q. Han, C. Zhang, M. Wei, M. I. Saidaminov, Y. Gao, J. Xu, M. Xiao, A. Li, J. Zhu, E. H. Sargent, H. Tan, _Nat. Energy_ **2019** , _4_ , 864. 

- [11] C. Li, Z. Song, C. Chen, C. Xiao, B. Subedi, S. P. Harvey, N. Shrestha, K. K. Subedi, L. Chen, D. Liu, Y. Li, Y.-W. Kim, C.-s. Jiang, M. J. Heben, D. Zhao, R. J. Ellingson, N. J. Podraza, M. Al-Jassim, Y. Yan, _Nat. Energy_ **2020** , _5_ , 768. 

- [12] D. Chi, S. Huang, M. Zhang, S. Mu, Y. Zhao, Y. Chen, J. You, _Adv. Funct. Mater._ **2018** , _28_ , 1804603. 

- [13] D. Zhao, L. Ding, _Sci. Bull._ **2020** , _65_ , 1144. 

- [14] Y. Yan, _Joule_ **2018** , _2_ , 2206. 

- [15] K. Xiao, R. Lin, Q. Han, Y. Hou, Z. Qin, H. T. Nguyen, J. Wen, M. Wei, V. Yeddu, M. I. Saidaminov, Y. Gao, X. Luo, Y. Wang, H. Gao, C. Zhang, J. Xu, J. Zhu, E. H. Sargent, H. Tan, _Nat. Energy_ **2020** , _5_ , 870. 

- [16] J. H. Tong, Z. N. Song, D. H. Kim, X. H. Chen, C. Chen, A. F. Palmstrom, P. F. Ndione, M. O. Reese, S. P. Dunfield, O. G. Reid, J. Liu, F. Zhang, S. P. Harvey, Z. Li, S. T. Christensen, G. Teeter, D. W. Zhao, M. M. Al-Jassim, M. van Hest, M. C. Beard, S. E. Shaheen, J. J. Berry, Y. F. Yan, K. Zhu, _Science_ **2019** , _364_ , 475. 

- [17] Z. Song, C. Chen, C. Li, R. A. Awni, D. Zhao, Y. Yan, _Semicond. Sci. Technol._ **2019** , _34_ , 093001. 

- [18] A. F. Palmstrom, G. E. Eperon, T. Leijtens, R. Prasanna, S. N. Habisreutinger, W. Nemeth, E. A. Gaulding, S. P. Dunfield, M. Reese, S. Nanayakkara, T. Moot, J. Werner, J. Liu, B. To, S. T. Christensen, M. D. McGehee, M. F. A. M. van Hest, J. M. Luther, J. J. Berry, D. T. Moore, _Joule_ **2019** , _3_ , 2193. 

- [19] T. Leijtens, R. Prasanna, K. A. Bush, G. E. Eperon, J. A. Raiford, A. Gold-Parker, E. J. Wolf, S. A. Swifter, C. C. Boyd, H.-P. Wang, M. F. Toney, S. F. Bent, M. D. McGehee, _Sustainable Energy Fuels_ **2018** , _2_ , 2450. 

- [20] Z. Yang, A. Rajagopal, C. C. Chueh, S. B. Jo, B. Liu, T. Zhao, A. K. Jen, _Adv. Mater._ **2016** , _28_ , 8990. 

- [21] B. Abdollahi Nejand, I. M. Hossain, M. Jakoby, S. Moghadamzadeh, T. Abzieher, S. Gharibzadeh, J. A. Schwenzer, P. Nazari, F. Schackmar, D. Hauschild, L. Weinhardt, U. Lemmer, B. S. Richards, I. A. Howard, U. W. Paetzold, _Adv. Energy Mater._ **2019** , _10_ , 1902583. 

- [22] R. He, T. Chen, Z. Xuan, T. Guo, J. Luo, Y. Jiang, W. Wang, J. Zhang, X. Hao, L. Wu, Y. Wang, I. Constantinou, S. Ren, D. Zhao, _Nanophotonics_ **2021** , https://doi.org/10.1515/nanoph-2020-0634. 

- [23] F. Hao, C. C. Stoumpos, R. P. Chang, M. G. Kanatzidis, _J. Am. Chem. Soc._ **2014** , _136_ , 8094. 

**2101045 (9 of 10)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101045 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

- [24] J. Im, C. C. Stoumpos, H. Jin, A. J. Freeman, M. G. Kanatzidis, _J. Phys. Chem. Lett._ **2015** , _6_ , 3503. 

- [25] D. Ju, Y. Dang, Z. Zhu, H. Liu, C.-C. Chueh, X. Li, L. Wang, X. Hu, A. K. Y. Jen, X. Tao, _Chem. Mater._ **2018** , _30_ , 1556. 

- [26] R. Prasanna, A. Gold-Parker, T. Leijtens, B. Conings, A. Babayigit, H. G. Boyen, M. F. Toney, M. D. McGehee, _J. Am. Chem. Soc._ **2017** , _139_ , 11117. 

- [27] R. He, C. Zuo, S. Ren, D. Zhao, L. Ding, _J. Semicond._ **2021** , _46_ , 060202. 

- [28] F. Zuo, S. T. Williams, P. W. Liang, C. C. Chueh, C. Y. Liao, A. K. Jen, _Adv. Mater._ **2014** , _26_ , 6454. 

- [29] N. K. Noel, S. D. Stranks, A. Abate, C. Wehrenfennig, S. Guarnera, A.-A. Haghighirad, A. Sadhanala, G. E. Eperon, S. K. Pathak, M. B. Johnston, A. Petrozza, L. M. Herz, H. J. Snaith, _Energy Environ. Sci._ **2014** , _7_ , 3061. 

- [30] W. Liao, D. Zhao, Y. Yu, C. R. Grice, C. Wang, A. J. Cimaroli, P. Schulz, W. Meng, K. Zhu, R. G. Xiong, Y. Yan, _Adv. Mater._ **2016** , _28_ , 9333. 

- [31] L. Zhang, Q. Kang, Y. Song, D. Chi, S. Huang, G. He, _Sol. RRL_ **2021** , _5_ , 2000681. 

- [32] X. Lian, J. Chen, Y. Zhang, M. Qin, J. Li, S. Tian, W. Yang, X. Lu, G. Wu, H. Chen, _Adv. Funct. Mater._ **2019** , _29_ , 1807024. 

- [33] T. Jiang, Z. Chen, X. Chen, T. Liu, X. Chen, W. E. I. Sha, H. Zhu, Y. Yang, _Sol. RRL_ **2019** , _4_ , 1900467. 

- [34] X. Xu, C.-C. Chueh, Z. Yang, A. Rajagopal, J. Xu, S. B. Jo, A. K. Y. Jen, _Nano Energy_ **2017** , _34_ , 392. 

- [35] C. Li, Z. Song, D. Zhao, C. Xiao, B. Subedi, N. Shrestha, M. M. Junda, C. Wang, C.-S. Jiang, M. Al-Jassim, R. J. Ellingson, N. J. Podraza, K. Zhu, Y. Yan, _Adv. Energy Mater._ **2019** , _9_ , 1803135. 

- [36] Z. Yang, Z. Yu, H. Wei, X. Xiao, Z. Ni, B. Chen, Y. Deng, S. N. Habisreutinger, X. Chen, K. Wang, J. Zhao, P. N. Rudd, J. J. Berry, M. C. Beard, J. Huang, _Nat. Commun._ **2019** , _10_ , 4498. 

- [37] Z. Yang, A. Rajagopal, A. K. Jen, _Adv. Mater._ **2017** , _29_ , 1704418. 

- [38] S. Gupta, T. Bendikov, G. Hodes, D. Cahen, _ACS Energy Lett._ **2016** , _1_ , 1028. 

- [39] M. H. Kumar, S. Dharani, W. L. Leong, P. P. Boix, R. R. Prabhakar, T. Baikie, C. Shi, H. Ding, R. Ramesh, M. Asta, M. Graetzel, S. G. Mhaisalkar, N. Mathews, _Adv. Mater._ **2014** , _26_ , 7122. 

- [40] S. J. Lee, S. S. Shin, Y. C. Kim, D. Kim, T. K. Ahn, J. H. Noh, J. Seo, S. I. Seok, _J. Am. Chem. Soc._ **2016** , _138_ , 3974. 

- [41] B.-B. Yu, L. Xu, M. Liao, Y. Wu, F. Liu, Z. He, J. Ding, W. Chen, B. Tu, Y. Lin, Y. Zhu, X. Zhang, W. Yao, A. B. Djurišić, J.-S. Hu, Z. He, _Sol. RRL_ **2019** , _3_ , 1800290. 

- [42] C. Hartmann, S. Gupta, T. Bendikov, X. Kozina, T. Kunze, R. Felix, G. Hodes, R. G. Wilks, D. Cahen, M. Bar, _ACS Appl. Mater. Interfaces_ **2020** , _12_ , 12353. 

- [43] M. Xiao, S. Gu, P. Zhu, M. Tang, W. Zhu, R. Lin, C. Chen, W. Xu, T. Yu, J. Zhu, _Adv. Opt. Mater._ **2018** , _6_ , 1700615. 

- [44] Z. Wan, H. Lai, S. Ren, R. He, Y. Jiang, J. Luo, Q. Chen, X. Hao, Y. Wang, J. Zhang, L. Wu, D. Zhao, _J. Energy Chem._ **2021** , _57_ , 147. 

- [45] S. Gupta, D. Cahen, G. Hodes, _J. Phys. Chem. C_ **2018** , _122_ , 13926. 

- [46] K. J. Savill, A. M. Ulatowski, M. D. Farrar, M. B. Johnston, H. J. Snaith, L. M. Herz, _Adv. Funct. Mater._ **2020** , _30_ , 2005594. 

- [47] Y. Zong, Z. Zhou, M. Chen, N. P. Padture, Y. Zhou, _Adv. Energy Mater._ **2018** , _8_ , 1800997. 

- [48] T. S. Ripolles, D. Yamasuso, Y. Zhang, M. A. Kamarudin, C. Ding, D. Hirotani, Q. Shen, S. Hayase, _J. Phys. Chem. C_ **2018** , _122_ , 27284. 

- [49] D. H. Kim, J. Park, Z. Li, M. Yang, J. S. Park, I. J. Park, J. Y. Kim, J. J. Berry, G. Rumbles, K. Zhu, _Adv. Mater._ **2017** , _29_ , 1606831. 

- [50] G. Xu, P. Bi, S. Wang, R. Xue, J. Zhang, H. Chen, W. Chen, X. Hao, Y. Li, Y. Li, _Adv. Funct. Mater._ **2018** , _28_ , 1804427. 

- [51] B. A. Nejand, I. M. Hossain, M. Jakoby, S. Moghadamzadeh, T. Abzieher, S. Gharibzadeh, J. A. Schwenzer, P. Nazari, F. Schackmar, D. Hauschild, L. Weinhardt, U. Lemmer, B. S. Richards, I. A. Howard, U. W. Paetzold, _Adv. Energy Mater._ **2020** , _10_ , 1902583. 

- [52] S. Lee, J. Lee, H. Park, J. Choi, H. W. Baac, S. Park, H. J. Park, _ACS Appl. Mater. Interfaces_ **2020** , _12_ , 40310. 

- [53] R. A. Awni, D.-B. Li, C. R. Grice, Z. Song, M. A. Razooqi, A. B. Phillips, S. S. Bista, P. J. Roland, F. K. Alfadhili, R. J. Ellingson, M. J. Heben, J. V. Li, Y. Yan, _Sol. RRL_ **2019** , _3_ , 1800304. 

**2101045 (10 of 10)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101045 

