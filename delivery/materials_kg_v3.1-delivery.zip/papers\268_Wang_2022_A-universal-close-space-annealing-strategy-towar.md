# A universal close-space annealing strategy towards high-quality perovskite absorbers enabling efficient all-perovskite tandem solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Nature Energy |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 190 |
| 作者 | Chang-Lei Wang, Yue Zhao, Tianshu Ma, Yidan An, Rui He, Jing-Wei Zhu, Cong Chen, S. Ren et al. |
| DOI | 10.1038/s41560-022-01076-9 |
| 源文件 | 068_Wang_2022_A-universal-close-space-annealing-strategy-towar.pdf |

---
Articles 

**https://doi.org/10.1038/s41560-022-01076-9** 





# **A universal close-space annealing strategy towards high-quality perovskite absorbers enabling efficient all-perovskite tandem solar cells** 

**Changlei Wang**<sup>**1**</sup> **, Yue Zhao**<sup>**1**</sup> **, Tianshu Ma**<sup>**1**</sup> **, Yidan An**<sup>**1**</sup> **, Rui He**<sup>**2**</sup> **, Jingwei Zhu**<sup>**2**</sup> **, Cong Chen**<sup>**2**</sup> **, Shengqiang Ren**<sup>**2**</sup> **, Fan Fu**<sup>**3**✉</sup> **, Dewei Zhao**<sup>**2**✉</sup> **and Xiaofeng Li**<sup>**1**✉</sup> 

**The broad bandgap tunability of organic–inorganic metal halide perovskites enables the fabrication of multi-junction all-perovskite tandem solar cells with ultra-high power conversion efficiencies (PCEs). Controllable crystallization plays a crucial role in the formation of high-quality perovskites. Here we report a universal close-space annealing strategy that increases grain size, enhances crystallinity and prolongs carrier lifetimes in low-bandgap (low-** **_E_ g) and wide-bandgap (wide-** **_E_ g) perovskite films. By placing the intermediate-phase perovskite films with their faces towards solvent-permeable covers during the annealing process, high-quality perovskite absorber layers are obtained with a slowed solvent releasing process, enabling fabrication of efficient single-junction perovskite solar cells (PVSCs) and all-perovskite tandem solar cells. As a result, the best PCEs of 21.51% and 18.58% for single-junction low-** **_E_ g and wide-** **_E_ g PVSCs are achieved and thus ensure the fabrication of 25.15% efficiency 4-terminal and 25.05% efficiency 2-terminal all-perovskite tandem solar cells.** 

enefiting from broad bandgap tunability and simple solution processability with potentially low manufacturing cost, Bperovskites shine a bright light on achieving high-efficiency and low-cost tandem solar cells (TSCs)<sup>1,2</sup> . All-perovskite TSCs, including mechanically stacked four-terminal (4-T) tandem and monolithic two-terminal (2-T) tandem configurations, could surpass the Shockley–Queisser (SQ) limit of single-junction devices by reducing thermalization losses<sup>3,4</sup> . With tremendous advances in past years, the PCEs of 4-T and 2-T all-perovskite TSCs have been boosted to ~25% and 26.4%, respectively<sup>1,5</sup> . However, the efficiency of all-perovskite TSCs still lags behind their practical efficiency limit, primarily due to non-radiative recombination losses either inside the perovskite absorbers or at the perovskite/charge transport layer interfaces in both low-bandgap (low- _E_ g) and wide-bandgap (wide- _E_ g) subcells, leading to deficient subcells<sup>6,7</sup> . Most studies have focused on mitigating defects in perovskite absorbers or at the interfaces in subcells by compositional engineering, additive engineering, surface/interface passivation and band alignment modulation<sup>8–11</sup> . 

While fewer studies focus on the crystallization process for both low- _E_ g and wide- _E_ g perovskite absorbers, which largely dictate the optoelectronic quality of absorber films and hence photovoltaic performance of the devices. It is widely accepted that incorporation of tin (Sn) in mixed Sn–lead (Pb) low- _E_ g perovskites and Br in mixed I/Br wide- _E_ g perovskites accelerates crystallization of the perovskites due to greater Lewis acidity of Sn<sup>2+</sup> (refs.<sup>12,13</sup> ) and exaggerated growth from the precursor solution<sup>14</sup> , respectively. Rapid and uncontrolled crystallization generally induces relatively small grains and thus a large number of grain boundaries, leading to more defects at grain boundaries or in grains and shorter carrier lifetime/ diffusion length<sup>13,15,16</sup> . 

Growing high-quality uniform perovskite absorbers with enlarged grains and prolonged carrier lifetime/diffusion length by slowing down the crystallization process is essential to fabricate efficient subcells, especially for all-perovskite TSCs<sup>16,17</sup> . Previously, several solvent annealing processes have been reported to significantly enlarge the grains via recrystallization of grains and increase film crystallinity<sup>18–20</sup> . However, Yu and coworkers found that excessive external dimethylsulfoxide (DMSO) solvent could react with Sn– Pb perovskites, leading to heterogeneous metal distribution due to phase segregation<sup>21</sup> . Huang and coworkers reported that excessive DMSO could cause big pinholes at the buried interface of perovskite film, deteriorating device performance<sup>22</sup> . DMSO and metal halides usually form adducts in the intermediate-phase film<sup>23</sup> and then evaporate out to form final crystal growth downward<sup>24</sup> . Therefore, it is of great significance to precisely control the amount of residual coordinating solvents during perovskite crystallization and better utilize them, especially for Sn-containing perovskites. Currently, studies on controlled crystallization process in both low- _E_ g and wide- _E_ g perovskite absorbers are lacking. It is desired to develop a reliable and universal preparation process for both subcell absorbers to fabricate high-performance single-junction perovskite solar cells (PVSCs) and all-perovskite TSCs. 

Herein, we report a facile film side down close-space annealing (CSA) process that is applicable to different perovskite materials with a broad range of bandgaps, including mixed Sn–Pb low- _E_ g, normal-bandgap and wide- _E_ g perovskites. By selecting proper underneath covers to precisely control the releasing process of the residual internal solvent, high-quality perovskite absorbers with micrometre-scale grains and prolonged carrier lifetimes are achieved, enabling high-performance 1.25 eV low- _E_ g (FASnI3)0.6(MAPbI3)0.4 

> 1School of Optoelectronic Science and Engineering & Collaborative Innovation Center of Suzhou Nano Science and Technology; Key Lab of Advanced Optical Manufacturing Technologies of Jiangsu Province & Key Lab of Modern Optical Technologies of Education Ministry of China, Soochow University, Suzhou, China.<sup>2</sup> College of Materials Science and Engineering & Institute of New Energy and Low-Carbon Technology, Sichuan University, Engineering Research Center of Alternative Energy Materials & Devices, Ministry of Education, Chengdu, China.<sup>3</sup> Laboratory for Thin Films and Photovoltaics, Empa—Swiss Federal Laboratories for Materials Science and Technology, Duebendorf, Switzerland.<sup>✉</sup> e-mail: Fan.Fu@empa.ch; dewei_zhao@hotmail.com; xfli@suda.edu.cn 

**NATuRe eNeRgY** | VOL 7 | AUgUST 2022 | 744–753 | www.nature.com/natureenergy 

**744** 

**NATurE ENErgy** 

<mark>Articles</mark> 



<!-- Start of picture text -->
a Normal annealing<br>Precursor Antisolvent Preheating Final films<br>Solvent<br>evaporation Solvent annealing<br>CSA<br>Solvents<br>permeable<br>substrates<br>b c d<br>1 µm 1 µm 1 µm<br>e<br>Step I Step II Step III<br><!-- End of picture text -->

**Fig. 1 | Scheme of different annealing processes and corresponding film morphology. a** , Scheme of normal annealing, solvent annealing and CSA processes. **b** – **d** , Top view SEM images of mixed Sn–Pb perovskite films fabricated with normal annealing ( **b** ), solvent annealing ( **c** ) and CSA ( **d** ) processes. The scale bar is 1 µm. **e** , Mechanisms of grain growth during the CSA process. Small grains merge into big ones during the film side down annealing process. The as-casted intermediate perovskite film has small grains after antisolvent dropping and preheating (Step I). The film is reversed back with the film side downward to the solvent permeable covers, and the residual solvents could slowly volatilize out, merging adjacent grains together and flattening the surface (Step II). The slowed solvent releasing process leads to larger grains and smoother surface of the perovskite film. The green arrows indicate the preparation flow. 

(FA = formamidinium and MA = methylammonium) and 1.75 eV wide- _E_ g FA0.8Cs0.2Pb(I0.7Br0.3)3 (Cs = cesium) PVSCs with power conversion efficiencies (PCEs) of 21.51% and 18.58%, respectively. As a result, our best-performing 4-T and monolithic 2-T all-perovskite TSCs deliver the PCEs of 25.15% and 25.05%, respectively. Our work offers a promising and effective approach to achieve efficient single-junction cells and multi-junction TSCs. 

##### **Optoelectronic properties of low-** **_E_ g Sn–Pb perovskite films** 

We investigated the effect of different annealing processes on the crystallization of mixed Sn–Pb low- _E_ g perovskite (FASnI3)0.6(MAPbI3)0.4, which has been widely studied via a one-step method in our previous works<sup>2,25–29</sup> . Figure 1a shows the preparation process of normal annealing, solvent annealing and CSA processes, which are solvent-controllable routes. The normal annealing process has been described in previous works<sup>7–9</sup> . While, a solvent annealing process introduces an extra solvent, that is, N,N-dimethylmethanamide (DMF) in our case, to enlarge the grains during annealing<sup>18,30</sup> . In a CSA process, the amount of the residual solvent in the as-cast 

intermediate-phase film can be accurately controlled by preheating the film on a hot plate for a certain time, and then the sample is reversed back with the film side towards a type of cover, forming a closed space to prevent the internal solvents from quickly escaping. We expect that the remaining solvents could dissolve the grain boundaries and then merge adjacent crystals together to form big ones<sup>16</sup> . 

To evaluate the film quality by modified methods, we performed morphological, structural and optoelectronic characterizations of low- _E_ g Sn–Pb perovskite films. Figure 1b–d shows the top view scanning electron microscope (SEM) images of low- _E_ g perovskite films processed by normal annealing, solvent annealing and CSA processes. Their corresponding grain size distributions are shown in Supplementary Fig. 1. The normal annealing-processed perovskite film has an average grain size about 400 nm and inhomogeneous surface (Fig. 1b). The solvent annealing-processed film has relatively increased grain size to about 500 nm (Fig. 1c) but shows inferior quality film with pinholes<sup>22</sup> , which should be ascribed to the redissolving of the as-formed crystals by the excessive solvent. 

**NATuRe eNeRgY** | VOL 7 | AUgUST 2022 | 744–753 | www.nature.com/natureenergy 

**745** 

**NATurE ENErgy** 

<mark>Articles</mark> 

Such a poor film coverage could lead to severe current leakage and shunting due to direct contact between electron and hole transport layers<sup>31</sup> . Figure 1d shows the SEM image of the CSA-processed perovskite film. Obviously, the precisely selected cover with proper solvent permeability promotes the growth of perovskites with the largest average grain size of over 1 μm and smooth surface. This indicates that the CSA process significantly enlarges the grains due to retarded solvent evaporation, facilitating Ostwald ripening and oriented attachment<sup>13,32</sup> . 

We compared the crystallinity of these films by performing X-ray diffraction measurements, as shown in Supplementary Fig. 2a. The intensity of (110) diffraction peak at around 14° has the order of CSA → solvent annealing → normal annealing-processed film from high to low level, indicating the CSA-processed film has better crystallinity, consistent with the enlarged grain sizes. The full-width half maximums of (110) peak of three films are shown in Supplementary Fig. 2b, further verifying that larger grain size presents higher crystallinity. All three films have the same absorption onsets, implying no change in optical bandgap, evidenced by the Tauc plots (Supplementary Fig. 3). The CSA-processed film has the highest absorbance, indicating better light absorption due to enlarged grain size and reduced defects<sup>16</sup> . 

Film quality and device performance significantly depend on growth conditions; therefore, it is necessary to uncover the fundamental mechanism of CSA process. We investigated the effects of solvent releasing rate and amount of solvent residual on optoelectronic properties of perovskite films and device performance. We selected soda-lime glass (SLG), filter paper and printing paper as the underlying covers with different solvent permeabilities in our CSA process. DMSO solvent releasing has both horizontal and vertical directions with different evaporation rates along these two directions, affecting the crystallization dynamics of perovskite films (Supplementary Discussion 1 and Supplementary Figs. 4–6). 

The structural, morphological and optical properties of these corresponding perovskite films are shown in Supplementary Figs. 7–10. The low- _E_ g perovskite film processed on SLG has the largest grain size of about 3 μm (Supplementary Fig. 7b). However, this film has no crystalline texture feature, as found in our previous work that perovskite grains with highly ordered linear stripes exhibit better quality due to the oriented topological growth mode<sup>27</sup> . The film processed on filter paper has an oriented morphology with grain size of around 1 μm (Supplementary Fig. 7c) and thus good crystallinity. However, the printing paper-processed film surface has a secondary white phase (Supplementary Fig. 7d), which should be related to the bleaching additives like fluorescent brightener<sup>33</sup> . We did not find any fibres on the perovskite surface with CSA processes (Supplementary Fig. 8). 

We hypothesized that the grain growth dynamics could be manipulated by changing the solvent releasing rate and directions via selecting SLG, filter paper and printing paper cover, as illustrated in Supplementary Fig. 6. The normal annealing process has only the vertical solvent releasing direction, therefore giving no effect on surface morphology with relatively small grains and texture features. While, the CSA process with various solvent-permeable covers is determined by the competition of solvent releasing rate by permeation through the membrane and by escape of solvent around the edges. When the vertical releasing rate is low, such as the case for SLG-based CSA process (no permeation rate through glass) where the perovskite intermediate-phase film is sandwiched between two pieces of glass, solvents would slowly escape out in a timely way and then pass along the film surface during annealing. This leads to recrystallization of grains and smooth surface (Supplementary Fig. 9), similar to the growth of single crystals<sup>34</sup> . In the cases of filter paper- and printing paper-based CSA processes, the solvents could release around the edges (horizontal direction) and by permeation through the membrane, thus the grains are gently enlarged 

and the texture feature is kept to some extent (Supplementary Fig. 9). The permeated solvents could be further released at the rough surface of the hot plate but does not contribute to the morphological changes of perovskite film. Note that the overall horizontal solvent releasing rate in printing paper-based CSA process is relatively slower than that of the filter paper-based one (Supplementary Fig. 4), therefore leading to smaller grain size and more distinguishable surface texture of corresponding perovskite film compared with the latter one. From the morphological evolution of perovskite films (Supplementary Fig. 9), we do see the merging process and oriented attachment trend of the grains, which thus confirm our hypothesis of recrystallization growth of the grains assisted by DMSO. Their time-resolved photoluminescence (TRPL) results show the corresponding averaged lifetimes of 452 ns, 670 ns and 317 ns for SLG-, filter paper- and printing paper-based films, respectively (Supplementary Fig. 10). Therefore, the vertical and horizontal solvent releasing should be balanced to facilitate the growth of high-quality films with both large grains and textured surface. 

Because the growth process can be modulated by the solvent vapour of the annealing condition<sup>35</sup> , we then investigated the amount of internal solvents by controlling the preheating time at low annealing temperature of 65 °C (ref.<sup>19</sup> ). The optimal preheating time was found to be 30 s (Supplementary Discussion 2 and Supplementary Figs. 11–16). 

On the basis of the above discussions, we further proposed the overall possible mechanisms of grain growth during CSA process, as illustrated in Fig. 1e. The as-casted perovskite film has already crystallized at the top after antisolvent dripping, followed by being preheating at 65 °C for a certain time to control the residual coordinative solvents (Step I). When the film is reversed back with film side down towards the underneath cover, the solvent releasing process is retarded, that is, the DMSO molecules slowly volatize from deep bulk to film surface, dissolving the grain boundaries and, consequently, merging adjacent small crystals together. At the same time, part of DMSO passes horizontally along the film surface, flattening the rough grains (Step II). At last, the slowed solvent releasing process leads to larger grains and a smoother surface (Step III). 

The photovoltaic performance of corresponding PVSCs based on absorber films with various covers and preheating time is shown in Supplementary Figs. 17 and 18 and is summarized in Supplementary Tables 1 and 2. All CSA-processed PVSCs show improved efficiencies compared with the normal annealing-processed ones, indicating this process could efficiently enhance the film quality and device performance irrespective to cover type. The small error deviation of statistical results from 60 devices for each process confirmed the good reproducibility of our CSA process. The devices with shorter preheating time have inferior performance and low reproducibility due to poor film morphology. Longer preheating time over 40 s gradually decreases PCEs. The external quantum efficiency (EQE) spectra of the devices with short preheating time (<20 s) show low spectral response at the long-wavelength region, consistent with the shorter carrier lifetimes due to the higher density of traps. The optimal preheating time is 30 s, delivering the averaged PCE of 20.52 ± 0.27% for PVSCs. The results indicate the proper amount of residual solvents and suitable solvent releasing pathways are key of high-quality perovskite films and efficient devices. 

We further conducted the photoluminescence (PL) and TRPL measurements to investigate charge dynamics in normal annealing-, solvent annealing-, and CSA-processed perovskite films. Normal annealing- and solvent annealing-based films have the average peak positions located at around 1,005.5 ± 3.3 and 1,004.3 ± 3.0 nm, respectively, while CSA-processed film has a peak position at around 1,002.3 ± 2.2 nm (Fig. 2a and Supplementary Table 3). Moreover, CSA-based film exhibits a much higher PL intensity than the others, indicating reduced defects. The minority carrier lifetime in the 

**NATuRe eNeRgY** | VOL 7 | AUgUST 2022 | 744–753 | www.nature.com/natureenergy 

**746** 

**NATurE ENErgy** 

<mark>Articles</mark> 



<!-- Start of picture text -->
a b 10 0 c 3<br>120,000 CSASA  CSA     NA       SA        Fitting Fitting Fitting 2 CSANASA<br>NA<br>10 –1 1<br>80,000<br>0 30<br>25<br>–1<br>40,000 10 –2 20<br>–2 15<br>–3 10 NA SA CSA<br>0 10 –3<br>800 900 1,000 1,100 1,200 500 1,000 1,500 2,000 1.1 1.2 1.3 1.4 1.5<br>Wavelength (nm) Time (ns) Energy (eV)<br>d 32 e 100 f<br>28 1.00 CSASA FittingFitting EE 00 = 1.23 V = 1.19 V<br>80 NA Fitting E 0 = 1.11 V<br>24<br>0.95<br>20 CSA reverse 60<br>CSA forward<br>16 SA reverseSA forward CSA   30.8 mA cm –2 0.90<br>12 NA reverse 40 SA     28.4 mA cm –2<br>NA forward NA     29.7 mA cm –2<br>8 20 0.85<br>4<br>0 0 0.80<br>0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 300 400 500 600 700 800 900 1,000 1,100 180 200 220 240 260 280 300<br>Voltage (V) Wavelength (nm) Temperature (K)<br>Normalized PL<br>Intensity (counts)<br>/ln() (dimensionless)ααg<br>Urbach energy (meV)<br>EQE (%)<br>Voltage (V)<br>–2Current density (mA cm)<br><!-- End of picture text -->

**Fig. 2 | Characterizations of low-** **_E_ g perovskite films and PVSCs based on normal annealing, solvent annealing and CSA processes. a** , **b** , Steady-state PL and TRPL decays of perovskite films processed with different methods on glass substrates. TRPL results are fitted with a bi-exponential decay formula. **c** , Linear fit of ln( _α_ / _α_ g) below _E_ g for the CSA-, solvent annealing- (SA) and normal annealing (NA)-processed samples using results from PDS measurements. The inset shows Urbach energy extracted from PDS measurement of different perovskite films. The histograms indicate the mean values, error bars indicate the standard deviations ( _n_ = 3) and the individual data are provided in the Source Data. **d** , _J–V_ curves under reverse and forward voltage scans under AM 1.5 g 100 mW cm<sup>−2</sup> illumination. **e** , EQE spectra and the integrated _J_ SC values are 30.8 mA cm<sup>−2</sup> , 28.4 mA cm<sup>−2</sup> and 29.7 mA cm<sup>−2</sup> for CSA-, solvent annealing- and normal annealing-processed PVSCs, respectively. **f** , _V_ OC as a function of temperature; the results are fitted with a linear function. 

CSA-based film from TRPL is 670 ns, much longer than those in the solvent annealing-based film (511 ns) and normal annealing-based film (204 ns) (Fig. 2b), indicating that the trap density is largely reduced. The prolonged carrier lifetime would facilitate the charge transport in the perovskite bulk with suppressed non-radiative recombination benefiting from fewer grain boundaries<sup>7,26</sup> . 

We then measured the photothermal deflection spectroscopy (PDS) of normal annealing-, solvent annealing- and CSA-processed perovskite films to characterize the responses for the detection of below-bandgap absorption induced by the defect energy level<sup>25</sup> . The linear fits of ln( _α_ / _α_ g) below _E_ g for the perovskites from the PDS measurements are shown in Fig. 2c, where _α_ is the absorption coefficient and _α_ g is the value at bandgap point. We derived the Urbach energy ( _E_ u) accordingly as shown in the inset. The averaged _E_ u decreases from 25.4 ± 1.9 meV for normal annealing-processed film to 24.1 ± 0.4 meV and 21.8 ± 0.3 meV for solvent annealing-processed film and CSA-processed film, respectively, implying reduced electronic disorder in film due to a decrease in the density of trap states<sup>25</sup> , in good agreement with improved crystallinity and prolonged carrier lifetimes. 

We fabricated low- _E_ g PVSCs with normal annealing-, solvent annealing- and CSA-processed absorbers to evaluate their effects on device performance. The dark current density–voltage ( _J_ – _V_ ) curves of these devices fabricated by different processes are shown in Supplementary Fig. 19a. The CSA-based PVSC has the lowest dark saturation current density, indicating the suppressed current loss and reduced carrier recombination outside the depletion region<sup>28</sup> . Because grain boundaries usually cause higher current leakage than grain interiors, the dense and uniform CSA-processed film with fewer grain boundaries leads to largely reduced dark current. 

By contrast, the solvent annealing-based device has much higher saturation current density, which we attribute to the pinholes existing in the absorber film that induce severe shunting effect. As aforementioned, these pinholes result from the excessive DMF-based solvent annealing process, which could dissolve the as-formed crystals and lead to incomplete coverage films. 

The _J–V_ curves of the best-performing normal annealing-, solvent annealing- and CSA-processed PVSCs are shown in Fig. 2d. The short-circuit current density ( _J_ SC), open-circuit voltage ( _V_ OC) and fill factor (FF) of the CSA-based device are greatly improved compared with the normal annealing-based one, while the solvent annealing-based device shows the worst performance. The CSA-based PVSC has a _V_ OC of 0.856 (0.857) V, a _J_ SC of 31.29 (31.25) mA cm<sup>−2</sup> and a FF of 80.1 (79.1)%, yielding a PCE of 21.51 (21.22)% when measured under reverse (forward) voltage scan. The normal annealing-processed device has a _V_ OC of 0.829 (0.830) V, a _J_ SC of 30.20 (30.21) mA cm<sup>−2</sup> and a FF of 78.4 (77.8)%, delivering a PCE of 19.63 (19.50)% under reverse (forward) voltage scan. However, the solvent annealing-based PVSC shows a _V_ OC of 0.810 (0.811) V, a _J_ SC of 29.10 (28.93) mA cm<sup>−2</sup> and a FF of 67.3 (68.1)%, delivering a PCE of 15.86 (15.97)% under reverse (forward) voltage scan. All devices show negligible hysteresis. These results confirm the benefits of improved film quality with large grains and homogeneous surface, while the inferior efficiency of the solvent annealing-based device is ascribed to severe current leakage as evidenced by the dark current. 

Figure 2e shows the corresponding EQE spectra. The _J_ SC values from the integrated EQE spectra over the entire solar spectrum are 30.8 mA cm<sup>−2</sup> , 29.7 mA cm<sup>−2</sup> and 28.4 mA cm<sup>−2</sup> for CSA-, normal annealing- and solvent annealing-based PVSCs, respectively, consistent with the _J_ SCs obtained from the _J–V_ measurements. 

**NATuRe eNeRgY** | VOL 7 | AUgUST 2022 | 744–753 | www.nature.com/natureenergy 

**747** 

**NATurE ENErgy** 

<mark>Articles</mark> 



<!-- Start of picture text -->
a b c<br>1 µm  1 µm  1 µm<br>d 10 0 e 20 f 100<br>16 CSA 80<br>SA<br>10 –1 NA<br>12 60<br>CSA  18.3 mA cm –2<br>SA     17.9 mA cm –2<br>8 40 NA     17.4 mA cm –2<br>10 –2<br>CSA  Fitting 4 20<br>SA  Fitting<br>NA  Fitting<br>10 –3 0 0<br>0 1,000 2,000 3,000 0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 300 400 500 600 700 800<br>Time (ns) Voltage (V) Wavelength (nm)<br>EQE (%)<br>Normalized PL<br>–2Current density (mA cm)<br><!-- End of picture text -->

**Fig. 3 | Film quality of wide-** **_E_ g perovskites and device performance with normal annealing, solvent annealing and CSA processes. a** – **c** , Top view SEM images of wide- _E_ g perovskite films fabricated with normal annealing ( **a** ), solvent annealing ( **b** ) and CSA ( **c** ) processes. **d** , TRPL curves of perovskite films; the results are fitted with a bi-exponential decay formula. **e** , **f** , _J_ – _V_ curves under reverse voltage scan ( **e** ) under AM 1.5 g 100 mW cm<sup>−2</sup> illumination and EQE spectra ( **f** ); the integrated _J_ SC values are 18.3 mA cm<sup>−2</sup> , 17.9 mA cm<sup>−2</sup> and 17.4 mA cm<sup>−2</sup> for CSA-, solvent annealing (SA)- and normal annealing (NA)-processed PVSCs, respectively. 

The high response of CSA-based PVSC at the long-wavelength region could be attributed to the passivated defects in the absorber film with fewer grain boundaries and high crystallinity, while the inferior EQE of solvent annealing-based PVSC can be ascribed to the high defects level caused by pinholes and unsatisfied back interface at the metal electrode. The power output of the CSA-based device is stabilized at 21% for 800 s by maximum power point (MPP) tracking. Meanwhile, the power output of the normal annealing- and solvent-based devices are 19.5% and 15.1%, respectively, as shown in Supplementary Fig. 19b. We analysed the charge transfer dynamics in devices by measuring the light intensity dependence of _V_ OC and _J_ SC for normal annealing-, solvent annealingand CSA-processed low- _E_ g PVSCs. The CSA-based device shows the optimum (Supplementary Discussion 3 and Supplementary Figs. 19, 20). 

We further confirmed the reduced trap density in the light absorber by conducting the temperature-dependent _J–V_ measurement of PVSCs with different annealing processes under 1 sun illumination with temperatures ranging from 180 K to 300 K (Supplementary Fig. 21). The _V_ OC increases with the decrease of temperature. Because the other functional layers and interfaces are identical, the dominant recombination losses should originate from the defects inside the perovskite films<sup>36</sup> . The _V_ OC as a function of temperature was fitted with a linear relationship and extrapolated to 0 K for the prediction of the highest achievable _V_ OC (ref.<sup>36</sup> ). However, due to the inevitable electronic disorder in PVSCs, the maximum _V_ OC is always lower than the intercept one, that is, _E_ g q<sup>−1</sup> , where q is the elementary charge. As shown in Fig. 2f, the intercept values are 1.23 V, 1.19 V and 1.11 V for CSA-, normal annealing- and solvent annealing-based PVSCs, respectively. The higher intercept of CSA-based PVSC means the lower density of trap states in contrast to the those of the others<sup>37,38</sup> . The difference in _V_ OC intercept related to the defect density of the perovskite layer further confirms that CSA could reduce electronic disorder through slow crystal 

growth, as evidenced by the _E_ u values. In addition, both the normal annealing- and CSA-based devices show the q _V_ OC values close to the bandgap, that is, 1.25 eV, suggesting good band alignment in our low- _E_ g PVSCs. 

##### **Film quality of wide-** **_E_ g perovskite and device performance** 

To demonstrate the efficacy and universality of the CSA strategy, we extended it to 1.75 eV wide- _E_ g FA0.8Cs0.2Pb(I0.7Br0.3)3 perovskite and solar cells. As shown in Fig. 3a _–_ c, the normal annealing-processed wide- _E_ g perovskite film shows a small grain size of around 200 nm, while the CSA-processed film exhibits a much larger average grain size of over 1 μm. The increased grains indicate fewer grain boundaries and reduced defects at grain boundaries, leading to improved film quality and high crystallinity. Different from the low- _E_ g mixed Sn–Pb perovskites, solvent annealing process could effectively improve the film quality in the wide- _E_ g perovskite film without pinholes<sup>30</sup> . The carrier lifetime (1,108 ns) of CSA-processed wide- _E_ g perovskite is much longer than that of solvent annealing-based (790 ns) and normal annealing-processed (351 ns) films (Fig. 3d), suggesting the prolonged carrier diffusion length in the absorber and benefiting the suppression of non-radiative recombination. The cross-sectional SEM images of the wide- _E_ g PVSCs with different annealing processes are shown in Supplementary Fig. 22. The large grains with high aspect ratio and no vertical boundaries compared with normal annealing- and solvent annealing-based ones confirm the preferred charge transport in our CSA-based devices. 

We also investigated the effect of preheating time on film morphology and device performance statistics for our wide- _E_ g (1.75 eV) PVSCs as shown in Supplementary Figs. 23 and 24, respectively. The photovoltaic parameters of the corresponding devices are summarized in Supplementary Table 4. The _J_ – _V_ curves of three wide- _E_ g PVSCs with normal annealing, solvent annealing and CSA processes under reverse voltage scan are depicted in Fig. 3e. The normal annealing-processed wide- _E_ g device has a _V_ OC of 1.220 V, a _J_ SC 

**NATuRe eNeRgY** | VOL 7 | AUgUST 2022 | 744–753 | www.nature.com/natureenergy 

**748** 

**NATurE ENErgy** 

## <mark>Articles</mark> 



<!-- Start of picture text -->
a 32 b 100 c<br>25<br>28 Forward Low- E g cell 4-T tandem ~25%<br>24 Reverse 80 20<br>20 Wide- E g top cell 60 17.0 mA cm –2 15 Top cell ~16.9%<br>16 Forward<br>Reverse<br>12 40 11.9 mA cm –2 10<br>Forward<br>8 Reverse 20 5 Filtered bottom cell ~8.1%<br>4 Filtered low- E g bottom cell<br>0 0 0<br>0 0.2 0.4 0.6 0.8 1.0 1.2 300 400 500 600 700 800 900 1,000 1,100 10 20 30 40 50<br>Voltage (V) Wavelength (nm) Time (s)<br>d e 16 f 100<br>C60/BCP/Ag 14<br>80<br>12<br>Low- E g perovskite 10 CSA forwardCSA reverse 60<br>8 NA forward 15.6 mA cm –2 15.0 mA cm –2<br>PEDOT:PSS 6 NA reverse 40 14.8 mA cm –2 14.5 mA cm –2<br>C60/SnO2/ITO<br>Wide- E g perovskite 4 20<br>PTAA<br>2<br>ITO 500 nm<br>Glass 0 0<br>0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 300 400 500 600 700 800 900 1,000 1,100<br>Voltage (V) Wavelength (nm)<br>g h 1.2<br>25<br>Stabilized PCE = 24.5% 1.0 90%<br>20<br>0.8<br>15<br>0.6<br>10 0.4 Unencapsulated 2-T tandem solar cell<br>MPP tracking under AM 1.5G in glovebox<br>5 0.2<br>0 0<br>20 40 60 80 100 120 0 50 100 150 200 250 300 350 400 450 500<br>Time (s) Time (h)<br>EQE (%) PCE (%)<br>–2Current density (mA cm)<br>EQE (%)<br>–2Current density (mA cm)<br>PCE (%)<br>Normalized PCE<br><!-- End of picture text -->

**Fig. 4 | Photovoltaic performance of 4-T and 2-T tandem solar cells. a** , _J_ – _V_ curves of 4-T TSCs. **b** , EQE spectra and the integrated _J_ SC values are 17.0 mA cm<sup>−2</sup> and 11.9 mA cm<sup>−2</sup> for top cell and filtered bottom cell, respectively. **c** , Power outputs of wide- _E_ g top cell, filtered low- _E_ g bottom cell and the overall output. **d** , Cross-sectional SEM image of an entire 2-T TSC. **e** , _J_ – _V_ curves of 2-T TSCs fabricated with normal annealing (NA) and CSA methods. **f** , EQE spectra of 2-T TSCs processed by normal annealing and CSA, and the integrated _J_ SC values are 15.6 mA cm<sup>−2</sup> and 15.0 mA cm<sup>−2</sup> for top and bottom subcells of CSA-based 2-T TSC and are 14.8 mA cm<sup>−2</sup> and 14.5 mA cm<sup>−2</sup> for top and bottom subcells of normal annealing-based 2-T TSC, respectively. **g** , MPP tracking of the best-performing 2-T TSC under AM 1.5 g 100 mW cm<sup>−2</sup> illumination. **h** , MPP tracking of one unencapsulated 2-T all-perovskite TSC under continuous AM 1.5 g 1 sun illumination in a glovebox; the initial efficiency is 24.5%. 

of 18.10 mA cm<sup>−2</sup> and a FF of 78.00%, yielding a PCE of 17.22%, and the solvent annealing-based PVSC shows a _V_ OC of 1.240 V, a _J_ SC of 18.45 mA cm<sup>−2</sup> and a FF of 79.29%, delivering a PCE of 18.14%. While, the CSA-processed wide- _E_ g device achieves a _V_ OC of 1.260 V, a _J_ SC of 18.60 mA cm<sup>−2</sup> and a FF of 79.30%, yielding a PCE of 18.58%. Their EQE spectra reflect that the CSA-processed device has improved response at the long-wavelength region (Fig. 3f). The CSA-, solvent annealing- and normal annealing-based PVSCs deliver stabilized power outputs of 18.5%, 18.0% and 17.3% under 1 sun illumination (Supplementary Fig. 24f). The light intensity dependence of _V_ OC of PVSCs with normal annealing, solvent annealing and CSA processes is shown in Supplementary Fig. 24g. The CSA-based PVSC has an ideal factor _n_ of 1.35, which is smaller than the normal annealing- and solvent annealing-based ones of 1.59 and 1.44, respectively, indicating a lower level of Shockley–Read– Hall (SRH) recombination in CSA-based PVSC. The light intensity dependence of _J_ SC of wide- _E_ g PVSCs is shown in Supplementary Fig. 24h, the values of _α_ are fitted to be 0.96, 0.95 and 0.94 for PVSCs 

with CSA-, solvent annealing- and normal annealing-based devices, respectively, indicating negligible space charge limited current of all devices. While, the higher values of _α_ for the CSA-based device is related to improved charge transport capability due to the removed lateral grain boundaries. 

To further assess its universality, we then applied the CSA method to prepare perovskites with various compositions, such as normal- _E_ g 1.57 eV-MA0.7FA0.3PbI3 and 1.63 eV-(FAPbI3)0.85(MAPbBr3)0.15. Their top view SEM images are shown in Supplementary Fig. 25, and their absorption spectra and statistics of photovoltaic performance and _J_ – _V_ curves of corresponding PVSCs are shown in Supplementary Figs. 26–28, respectively. All the CSA-processed perovskite films exhibit larger grains than the normal annealing-processed ones, and their corresponding devices show better performance (Supplementary Table 5). These results confirm that the CSA strategy could universally enhance the film quality and photovoltaic performance of PVSCs irrespective to the compositions and bandgaps. 

**NATuRe eNeRgY** | VOL 7 | AUgUST 2022 | 744–753 | www.nature.com/natureenergy 

**749** 

**NATurE ENErgy** 

<mark>Articles</mark> 

**Table 1 | Photovoltaic performance of single-junction PVSCs and 4-T and 2-T all-perovskite tandem solar cells** 

|**Cells**|**Scan**|**_V_oc (V)**|**_J_sc**<br>**(mA cm**<sup>−</sup><sup>**2**</sup>**)**|**FF**|**PCe**<br>**(%)**|**SSe**<br>**(%)**|
|---|---|---|---|---|---|---|
|Wide-_E_g<br>|Reverse|1.212|17.53|0.801|17.02|16.9|
|cell<br>(1.75 eV)|Forward|1.173|17.56|0.786|16.19||
|Low-_E_gcell<br>|Reverse|0.856|31.29|0.803|21.51|21.2|
|(1.25 eV)|Forward|0.857|31.25|0.792|21.22||
|Filtered|Reverse|0.834|12.13|0.804|8.13|8.1|
|low-_E_g<br>bottom<br>cell|Forward|0.831|12.17|0.796|8.05||
|4-T|Reverse||||25.15|25.0|
|tandem<br>cell|Forward||||24.24||
|2-T<br>|Reverse|1.956|15.41|0.831|25.05|24.5|
|tandem<br>cell (CSA)|Forward|1.949|15.35|0.827|24.74||
|2-T tandem|<br>Reverse|1.926|14.54|0.803|22.49|21.2|
|cell<br>(normal<br>annealing)|Forward|1.916|14.49|0.792|21.97||



Summary of device performance metrics of single-junction wide- _E_ g (1.75 eV) perovskite top cell, low- _E_ g (1.25 eV) perovskite bottom cell, corresponding 4-T and champion 2-T all-perovskite tandem cells measured under a 100 mW cm<sup>−2</sup> AM 1.5 g illumination under reverse and forward voltage scans. SSE indicates steady-state efficiency. 

##### **Performance of 4-T and 2-T all-perovskite tandem solar cells** 

We fabricated 4-T all-perovskite TSCs consisting of filter paper CSA-processed wide- _E_ g and low- _E_ g perovskite absorbers (Supplementary Fig. 29), where semi-transparent n–i–p regular device of glass/FTO/SnO2/1.75 eV wide- _E_ g perovskite/spiro-OMeTAD/ ultra-thin Au/MoO _x_ /ITO as the top subcell and p–i–n inverted device of glass/ITO/PEDOT:PSS/1.25 eV low- _E_ g perovskite/ C60/BCP/Ag as the bottom subcell, where FTO is fluorinedoped tin oxide, spiro-OMeTAD is 2,2′,7,7′-tetrakis(N,N′-dip-methoxyphenylamine)-9,9′-spirobifluorene, ITO is indium tin oxide, PEDOT:PSS is poly(3,4-ethylenedioxythiophene):polyst yrene sulfonate and BCP is bathocuproine. To reduce the reflection loss at the front surface of the semi-transparent top subcell and the parasitic absorption loss between two subcells, paraffin oil was employed as an anti-reflection coating and light coupling layer to enhance the transmittance (Supplementary Fig. 30), where over 70% transmission was obtained at the long-wavelength region, beneficial for the light harvesting by the low- _E_ g perovskite bottom subcell. The _J_ – _V_ curves of single-junction wide- _E_ g top cell and low- _E_ g bottom cell with and without light filtered by a semi-transparent top subcell are shown in Fig. 4a. Their corresponding photovoltaic parameters are summarized in Table 1. The semi-transparent top subcell has a PCE of 17.02%. The low- _E_ g single-junction cell has a PCE of 21.51% and its PCE decreases to 8.13% with a semi-transparent top subcell as the optical filter. As a result, the 4-T tandem cell delivers a PCE of 25.15%, which is among the best values of all-perovskite TSCs<sup>5</sup> . As shown in Fig. 4b, the EQE-integrated _J_ SCs over the AM 1.5 G solar spectrum for the semi-transparent wide- _E_ g top subcell and filtered low- _E_ g bottom subcell are 17.0 mA cm<sup>−2</sup> and 11.9 mA cm<sup>−2</sup> , respectively, in good agreement with the _J_ SC values from the _J_ – _V_ measurements. We tracked the MPP over 60 s to obtain their efficiencies of 16.9% for the top cell and 8.1% for the filtered bottom cell, leading to the overall efficiency of 25.0% for our 4-T tandem cell (Fig. 4c). 

We fabricated monolithic 2-T all-perovskite TSCs employing a 1.75 eV wide- _E_ g top subcell and a 1.25 eV low- _E_ g bottom subcell. Figure 4d shows the cross-sectional SEM image of the entire TSC, the device structure of which is glass/ITO/PTAA/wide- _E_ g perovskite/ C60/SnO2/ITO/PEDOT:PSS/low- _E_ g perovskite/C60/BCP/Ag, where PTAA is Poly [bis (4-phenyl)(2,4,6-trimethylphenyl)amine]. Here, we used 15 nm SnO2 grown by atom layer deposition and 100 nm ITO deposited by sputtering as the interconnection layer. Both of the wide- _E_ g and low- _E_ g perovskites were processed with the same fabrication process, that is, normal annealing or CSA strategy. Our best-performing CSA-based 2-T all-perovskite TSC obtains the PCE of 25.05 (24.74)% under reverse (forward) voltage scan, with a _V_ OC of 1.956 (1.949) V, a _J_ SC of 15.41 (15.35) mA cm<sup>−2</sup> and a FF of 83.1 (82.7)%, which are much higher than the normal annealing-based tandem device with a PCE of 22.49 (21.97)%, a _V_ OC of 1.926 (1.916) V, a _J_ SC of 14.54 (14.49) mA cm<sup>−2</sup> and a FF of 80.3 (79.2)% under reverse (forward) voltage scan (Fig. 4e). The stabilized power output of our 2-T tandem cell measured by using MPP tracking under 1 sun in glovebox is ~24.5% (Fig. 4f). The EQE-integrated _J_ SCs of the corresponding top and bottom subcells in CSA-processed tandem devices are 15.6 mA cm<sup>−2</sup> and 15.0 mA cm<sup>−2</sup> , respectively, while the normal annealing-based top and bottom subcells are 14.8 mA cm<sup>−2</sup> and 14.5 mA cm<sup>−2</sup> . We obtained an independently certified efficiency of 24.59% (24.79%) under reverse (forward) voltage scan for our 2-T all-perovskite tandem cell (Supplementary Fig. 31). We further investigated the long-term stability of our 2-T TSC under continuous AM 1.5 G 1 sun illumination in a glovebox. The unencapsulated TSC presented excellent stability that retained 90% of its original PCE for about 450 h, as shown in Fig. 4g. Our 2-T tandem cell stability is on the same level as those in previous reports<sup>17,39–41</sup> . 

We proposed the proof of concept of the CSA process here and demonstrated the universality and feasibility of our strategy suitable for various compositions. In terms of future commercialization, the quantification of solvent permeability of underneath covers, the surface roughness of covers, the residual internal solvents in the intermediate-phase film, substrate size, selection of solvent-permeable membranes to avoid potential fibre contamination at larger scales and other parameters should be further optimized before actual industrial trials. 

##### **Conclusions** 

We have demonstrated a promising CSA strategy applicable for various bandgaps of perovskites to fabricate high-quality perovskite absorbers with enlarged grains, improved crystallinity and prolonged carrier lifetimes, enabling efficient single-junction devices and all-perovskite TSCs. We elucidate the perovskite growth mechanism during CSA process and found that properly controlling the amount of residual solvents inside the intermediate-phase perovskites could promote the grain growth by merging neighbouring crystals during the slowed solvent releasing process. As a result, high-performance low- _E_ g mixed Sn–Pb and semi-transparent wide- _E_ g PVSCs have been obtained, enabling high PCEs of 25.15% and 25.05% for 4-T and 2-T all-perovskite TSCs, respectively. 

##### **Methods** 

**Materials.** Fluorine-doped tin oxide (FTO) glass substrates (15 Ω per square) were purchased from NPG, and indium tin oxide (ITO) glass substrates (10 Ω per square and 15 Ω per square) were purchased from Youxuan and Yaoke. Lead iodide (PbI2, 99.9985%), caesium iodide (CsI, 99.9%) and diethyl ether were purchased from Alfa Aesar. Tin iodide (SnI2), leadthiocyanate (Pb(SCN)2, 99.5%), tin fluoride (SnF2, 99%), 4-tert-butylpyridine (TBP, 96%), Li-bis-(trifluoromethanesulfonyl) imide (Li-TFSI, 99.95%), N,N-dimethylmethanamide (DMF, anhydrous), dimethyl sulfoxide (DMSO, anhydrous) and chlorobenzene were purchased from Sigma Aldrich. Poly(3,4-ethylenedioxythiophene): polystyrene sulfonate (PEDOT:PSS, CLEVIOS™ PVP AI 4083) was purchased from Heraeus. Methylammonium iodide (MAI), formamidinium iodide (FAI) and methylammonium bromide (MABr) were purchased from Great Solar Company. Bathocuproine (BCP) was purchased 

**NATuRe eNeRgY** | VOL 7 | AUgUST 2022 | 744–753 | www.nature.com/natureenergy 

**750** 

**NATurE ENErgy** 

<mark>Articles</mark> 

from Jilin OLED Company. 2,2ʹ,7,7ʹ-tetrakis(N,Nʹ-di- _p_ -methoxyphenylamine)9,9ʹ-spirobifluorene (Spiro-OMeTAD), Co(II)-TFSI salt (FK209), lead bromide (PbBr2), 2,3,5,6-tetrafluoro-7,7,8,8-tetracyanoquinodimethane (F4-TCNQ), Poly [bis (4-phenyl)(2,4,6-trimethylphenyl)amine] (PTAA) were purchased from Xi’an polymer light company. Indium tin oxide (ITO, In2O3/SnO2 90/10 wt%) target, gold (Au) and silver (Ag) were purchased from Kairui Xincai. All chemicals used in this work were commercially available and were used as received. 

**Preparation of perovskite precursors and spiro-OMeTAD solution.** Low- _E_ g (FASnI3)0.6(MAPbI3)0.4 perovskite precursor _._ The FASnI3 precursor solution was prepared by dissolving 372 mg of SnI2 and 172 mg of FAI with 5 mol% (7.8 mg) of SnF2 in mixed DMF and DMSO. The MAPbI3 precursor solution was prepared by dissolving 461 mg PbI2 and 159 mg MAI with 3.5 mol% (11.3 mg) Pb(SCN)2 dissolved in 565 μl DMF and 71 μl DMSO. The (FASnI3)0.6(MAPbI3)0.4 precursor solution was obtained by mixing stoichiometric amounts of FASnI3 and MAPbI3 perovskite precursor<sup>25</sup> . The mixed solutions were kept for 30 min before spin coating. 

_Wide-Eg FA0.8Cs0.2Pb(I0.7Br0.3)3 perovskite precursor._ The precursor solution<sup>30</sup> was prepared by dissolving 0.736 mmol FAI, 0.184 mmol CsI, 0.506 mmol PbI2 and 0.414 mmol PbBr2 in 1 ml mixed solvents of DMF and DMSO with a volume ratio of 3:1. The precursor solution was thoroughly mixed and aged for 12 h before usage. 

_Normal-Eg MA0.7FA0.3PbI3 perovskite precursor._ The precursor<sup>42</sup> (1.57 eV) was prepared by mixing 461 mg PbI2, 111 mg MAI, 53 mg FAI, 9.22 mg Pb(SCN)2 with 71 μl DMSO in 600 μl DMF solvent and dissolved completely on a 65 °C hot plate. 

_Normal-Eg (FAPbI3)0.85(MAPbBr3)0.15 perovskite precursor._ The FAPbI3 precursor was prepared by dissolving 553 mg PbI2 and 206 mg FAI in 1 ml mixed solvent of DMF and DMSO with a volume ratio of 4:1. The MAPbBr3 solution was prepared by dissolving 367 mg PbBr2 and 112 MABr in 1 ml mixed solvent of DMF and DMSO with a volume ratio of 4:1. The final (FAPbI3)0.85(MAPbBr3)0.15 perovskite precursor was obtained by mixing FAPbI3 with MAPbBr3 precursors with a molar ratio of 0.85:0.15. Moreover, 5 mmol Pb(SCN)2 solution (1 M stock solution in DMF) was dropped into the above mixture. The combined solution was mixed evenly and used immediately. 

_Spiro-OMeTAD solution._ Spiro-OMeTAD was used as the hole transport layer and deposited on the perovskite film at 3,000 r.p.m. for 45 s. The Spiro-OMeTAD was co-doped using Co-TFSI and Li-TFSI. The Spiro-OMeTAD solution was prepared by dissolving 72.3 mg Spiro-OMeTAD in 1 ml chlorobenzene with 28 μl TBP, 18 μl Li-TFSI (520 mg ml<sup>−1</sup> in acetonitrile) and 18 μl Co(II)-TFSI salt (FK209, 300 mg ml<sup>−1</sup> in acetonitrile). 

**Fabrication of perovskite films.** Low- _E_ g perovskite film by normal annealing process _._ The low- _E_ g (FASnI3)0.6(MAPbI3)0.4 precursor<sup>29</sup> was spin coated on substrates at 4,000 r.p.m. for 60 s with 800 μl diethyl ether dripped simultaneously during the spinning. The as-deposited film was annealed at 65 °C for 3 min and then 100 °C for 7 min. 

_Film side down CSA-processed low-Eg perovskite film._ The low- _E_ g (FASnI3)0.6(MAPbI3)0.4 precursor was spin coated on substrates at 4,000 r.p.m. for 60 s with 800 μl diethyl ether dripped simultaneously during the spinning. The as-casted precursor film was preheated on a 65 °C hot plate for exactly 30 s until the edge of the film became a little bit grey, then immediately overturned with the film side down to different covers on a 65 °C hot plate for annealing for 3 min and then heated to 100 °C for annealing for another 10 min. After the second step annealing, the perovskite film was then reversed back with film side up on the 100 °C hot plate for another 2 min to ensure the complete evaporation of solvents. 

_Low-Eg perovskite film by solvent annealing process._ The spin coating method is the same as above. The as-casted film was put on a 65 °C hot plate with a petri dish on top, while a small drop of DMF solvent was put into the petri dish. The hot plate was kept at 65 °C for 3 min and then heated up to 100 °C for another 10 min. 

_Normal-Eg MA0.7FA0.3PbI3 perovskite film by normal annealing process._ The precursor was deposited on substrate with a two-step spin coating method, 500 r.p.m. for 3 s and then 4,000 r.p.m. for 60 s, and 800 μl diethyl ether was poured on the film during spinning. The as-casted film was then annealed at 65 °C for 2 min and at 100 °C for 5 min. 

_Normal-Eg MA0.7FA0.3PbI3 perovskite film by CSA process._ The precursor film was deposited in the same way mentioned above. For the CSA process, the as-casted film was preheated at 65 °C for about 30 s and then put on the filter paper on a 65 °C hot plate with the film side down. Then the film was kept annealing at 65 °C for 3 min and at 100 °C for 10 min. At last, the film was reversed up for another 2 min on 100 °C. 

_Normal-Eg (FAPbI3)0.85(MAPbBr3)0.15 perovskite film by normal annealing process._ The precursor film was deposited on the substrate with a two-step spin coating method at 1,000 r.p.m. for 10 s and then 4,000 r.p.m. for 60 s, and 500 μl diethyl 

ether was applied during the 30 s before the end of the second step. The obtained film was annealed at 65 °C for 30 s and then at 120 °C for 20 min. 

_Normal-Eg (FAPbI3)0.85(MAPbBr3)0.15 perovskite film by CSA process._ The precursor film was deposited in the same way as mentioned above. For the CSA process, the as-casted film was preheated at 65 °C for 30 s and then been put on the filter paper on a 65 °C hot plate with the film side down for annealing for 3 mins, and the hot plate was heated up to 120 °C for annealing for another 10 min. At last, the film was reversed up for another 2 min at 120 °C. 

**Fabrication of PVSCs.** Low- _E_ g PVSCs _._ ITO substrates were treated under UV ozone for 20 min, and then 20 nm PEDOT:PSS layer was spin coated on ITO, followed by annealing at 150 °C for 20 min in ambient air. The substrates were then transferred into a N2-filled glovebox for the deposition of perovskite films. (FASnI3)0.6(MAPbI3)0.4 perovskite absorber layers were spin coated on the PEDOT:PSS layer by the aforementioned method. After the deposition of the perovskite layer, the samples were then put into a high vacuum chamber for the following deposition of functional layers: 20 nm C60 and 5 nm BCP were sequentially evaporated onto the perovskite, and 75 nm Ag was finally deposited with an active area of 0.09 cm<sup>2</sup> . At last, the devices were encapsulated with cover glass and UV-curable epoxy. 

_Normal-Eg PVSCs with gold electrode._ Clean FTO glass substrates were put in an atom layer deposition system for the deposition of 15 nm SnO2 and then were treated at 100 °C for 1 h with fixed humidity<sup>43</sup> . The SnO2-coated FTO substrates were then transferred into a N2-filled glovebox for the following layers. Normal- _E_ g perovskite layers with different deposition methods were demonstrated above. Wide- _E_ g perovskites were fabricated using the solvent annealing process that has been reported previously<sup>30</sup> . After the deposition of perovskite layers, a 150 nm spiro-OMeTAD layer was spin coated onto the sample with a spin speed of 3,000 r.p.m. for 45 s. Finally, the Au electrode was thermally evaporated on the top of spiro-OMeTAD with a shadow mask of 0.09 cm<sup>2</sup> . 

_Semi-transparent wide-Eg PVSCs with ITO electrodes._ The deposition processes of different layers were as identical as those to the regular structure PVSCs. After the deposition of spiro-OMeTAD, the sample was put into a vacuum chamber for the evaporation of ultra-thin metal and MoO _x_ layer on the whole surface. The thickness of the MoO _x_ layer is 10 nm. Finally, the ITO layer was sputtered on the top of MoO _x_ with a power of 60 W from a 2″ target. The active area of the devices was 0.09 cm<sup>2</sup> as defined by a shadow mask during sputtering. For the light filter, the ITO layer was sputtered on the whole surface without any mask. 

**Fabrication of 2-T all-perovskite TSCs.** ITO substrates were cleaned with detergent, water and organic solvents assisted with an ultrasonic bath. The cleaned substrates were treated under UV ozone for 15 min and then transferred into a glovebox for the spin coating of PTAA. The PTAA solution was prepared with 1 wt% F4-TCNQ doping. The PTAA was annealed at 100 °C for 10 min, followed with the deposition of wide- _E_ g perovskite film. For 2-T tandem cells, C60 (30 nm) was deposited by thermal evaporation in the vacuum chamber. Then, the samples were transferred to the atom layer deposition system for the deposition of 15 nm SnO2 at 70 °C with water as the oxidizer and tetrakis(dimethylamino)-tin(IV) (TDMA-Sn) as the Sn source. Then, about 100 nm ITO layer was sputtered from a 2″ target (Kairui Xincai, In2O3/SnO2 90/10 wt%) at 60 W power during the second stage under Ar pressure of 0.45 Pa. Right after the deposition of the ITO layer, PEDOT:PSS films were spin coated onto the prepared underneath subcells and post-annealed at 100 °C for 10 min. The finished substrates were transferred into a glovebox for the deposition of low- _E_ g perovskite films. The following steps of low- _E_ g perovskite film deposition and functional layer vacuum evaporation are same as single-junction low- _E_ g PVSCs as described above. Devices were encapsulated with cover glass and UV-curable epoxy. 

**Film and device characterizations.** The top view and cross section structures of perovskite films and PVSCs were characterized with a field emission SEM instrument (Hitachi S-4800). Optical microscope images of perovskite films were measured using a microscope (Olympus). Crystallinity and the crystal structure of the perovskite layer were analysed with an Ultima III X-ray Diffractometer using a Ni-filtered Cu Kα X-ray source (Rigaku). Absorbance spectra were obtained with a UV–vis spectrophotometer (PerkinElmer Lambda 1050 S). For steady-state PL and TRPL measurements, perovskite films were fabricated by spin coating perovskite precursors on glass substrates followed by coating another encapsulating layer of polymethylmethacrylate (PMMA) after thermal annealing. PL measurements were performed in ambient air at room temperature. Samples were illuminated through the film side. A 532 nm continuous-wave laser (beam diameter ≈ 90 μm) at 40 mW cm<sup>−2</sup> was used as an excitation wavelength for steady-state PL measurement. PL signal was detected via a Symphony-II charge-coupled device (CCD) (Horiba) detector after a 300 g mm<sup>−1</sup> grating monochromator (integration time = 0.5 s). 

For TRPL measurements, samples were excited by a 532 nm pulsed laser (pulse width = 5 ps, beam diameter ≈ 150 μm) at 10<sup>10</sup> photons per pulse cm<sup>−2</sup> . TRPL measurements were performed with time-correlated single photon counting 

**NATuRe eNeRgY** | VOL 7 | AUgUST 2022 | 744–753 | www.nature.com/natureenergy 

**751** 

**NATurE ENErgy** 

## <mark>Articles</mark> 

module (Becker & Hickel Simple Tau SPCM 130-E/M module), and the radiative recombination events were detected (integration time = 600 s) via hybrid avalanche photo diode(APD)/photomultiplier tube (PMT) module (R10467U-50). The intensity average lifetime of bi-exponential PL decay is calculated as reported in our previous works<sup>42</sup> . The PDS measurements are collected using a custom system (PTS-3-PTD, Sciencetech) operating in transverse configuration over a spectral range of 1,400–800 nm (0.89–1.55 eV) in 10 nm steps. The monochromatic pump beam is modulated with a mechanical chopper at 0.2 Hz. The probe beam is a 633 nm laser of nominally 300 μm cross-sectional diameter. The full acquisition time for measurement of each film was approximately 5 h. 

Fourier transform infrared spectra were recorded on a vacuum Fourier transform infrared spectrometer (Bruker, VERTEX70V). 

During PDS measurement, each film was immersed in a quartz cuvette containing a C6F14 fluid (Fluorinert FC-72, Synquest Laboratories); in addition to being a thermally sensitive medium suitable for PDS measurement, it also effectively eliminates atmospheric exposure of the perovskite films during measurement. For comparison, low- _E_ g perovskite films processed with normal annealing, substrate annealing and CSA method were prepared and subsequently immersed in C6F14 with the transfer taking place in a pure N2 environment. Thus, PDS measurements are collected for perovskite films without exposure to atmosphere. 

Dark _J_ – _V_ curves was measured in ambient conditions in a dark box using a semiconductor device parameter analyser (Keysight B1500A); the devices were encapsulated with cover glass and UV-curable epoxy before being taken out for testing. 

The _J_ – _V_ curves were measured using a Keithley 2400 sourcemeter under standard AM 1.5 G illumination using a solar simulator (SS-F5-3A, Enlitech) with an output intensity of 100 mW cm<sup>−2</sup> as calibrated by National Renewable Energy Laboratory (NREL) reference silicon solar cells. The active area of all devices was determined by applying an aperture mask when measuring (0.0625 cm<sup>2</sup> ). Unless otherwise stated, all _J_ – _V_ results were measured in a nitrogen-filled glovebox with a scanning speed of 100 mV s<sup>−1</sup> . The applied bias ranges from −0.1 V to 0.9 V for low- _E_ g PVSCs, from −0.1 V to 1.3 V for wide- _E_ g PVSCs and from −0.1 V to 2.0 V for 2-T TSCs under reverse and forward voltage scan. No preconditioning was used before _J_ – _V_ measurements. For light intensity dependence tests, the light intensity was later adjusted between 1 mW cm<sup>−2</sup> and 100 mW cm<sup>−2</sup> . EQE measurement was carried out in ambient air with an EQE system (QE-R, Enlitech) using 210 Hz chopped monochromatic light ranging from 300 nm to 1,100 nm under near-dark test conditions. For TSCs, the bias illumination from a 150 W halogen lamp with optical filters of 850 nm and 550 nm was employed to measure the spectral response of the top and bottom subcells, respectively. 

The power outputs of single-junction PVSCs and all-perovskite TSCs were recorded relying on the MPP tracking protocol based on a homemade current-voltage (I-V) measurement software. The devices were measured in a glovebox under 100 mW cm<sup>−2</sup> illumination without temperature control units. 

For temperature-dependent _J_ – _V_ measurements, the encapsulated device was put into a liquid nitrogen cooling cryostat with a transparent window for the illumination from a solar simulator. The light intensity was controlled by changing the distance from the simulator to the sample until the device output the same _J_ SC of normal _J_ – _V_ measurements. The temperature was controlled by an in-house designed LabVIEW programme. 

For DMSO solvent volatilization rate measurements, four vials were filled with 3.5 ml DMSO liquid and then heated at 240 °C covered with different covers on the top. The final evaporated volume of DMSO was determined by the beginning and final volumes. The diameter values of the vial and the hole of cap were measured to be 0.96 cm and 0.92 cm, respectively, using a calliper. 

**Reporting summary.** Further information on research design is available in the Nature Research Reporting Summary linked to this article. 

##### **Data availability** 

The datasets analysed and generated during the current study are included in the paper and its Supplementary Information. Source data are provided with this paper. 

Received: 23 November 2021; Accepted: 13 June 2022; Published online: 21 July 2022 

##### **References** 

1. Lin, R. et al. All-perovskite tandem solar cells with improved grain surface passivation. _Nature_ **603** , 73–78 (2022). 

2. Zhao, D. & Ding, L. All-perovskite tandem structures shed light on thin-film photovoltaics. _Sci. Bull._ **65** , 1144–1146 (2020). 

3. Eperon, G. E. et al. Perovskite–perovskite tandem photovoltaics with optimized band gaps. _Science_ **354** , 861–865 (2016). 

4. Zhao, D. et al. Four-terminal all-perovskite tandem solar cells achieving power conversion efficiencies exceeding 23%. _ACS Energy Lett._ **3** , 305–306 (2018). 

5. Tong, J. et al. Carrier lifetimes of >1 μs in Sn–Pb perovskites enable efficient all-perovskite tandem solar cells. _Science_ **364** , 475–479 (2019). 

6. He, R. et al. Wide-bandgap organic–inorganic hybrid and all-inorganic perovskite solar cells and their application in all-perovskite tandem solar cells. _Energy Environ. Sci._ **14** , 5723–5759 (2021). 

7. Wang, C., Song, Z., Li, C., Zhao, D. & Yan, Y. Low-bandgap mixed tin–lead perovskites and their applications in all-perovskite tandem solar cells. _Adv. Funct. Mater._ **29** , 1808801 (2019). 

8. Wang, L. et al. A Eu<sup>3+</sup> -Eu<sup>2+</sup> ion redox shuttle imparts operational durability to Pb–I perovskite solar cells. _Science_ **363** , 265–270 (2019). 

9. Tan, H. et al. Efficient and stable solution-processed planar perovskite solar cells via contact passivation. _Science_ **355** , 722–726 (2017). 

10. Zheng, X. et al. Defect passivation in hybrid perovskite solar cells using quaternary ammonium halide anions and cations. _Nat. Energy_ **2** , 17102 (2017). 

11. Liu, Y., Dong, B., Hagfeldt, A., Luo, J. & Graetzel, M. Chemically tailored molecular surface modifiers for efficient and stable perovskite photovoltaics. _SmartMat_ **2** , 33–37 (2021). 

12. Shi, T. et al. Effects of organic cations on the defect physics of tin halide perovskites. _J. Mater. Chem. A_ **5** , 15124–15129 (2017). 

13. Wang, J. et al. Controlling the crystallization kinetics of lead-free tin halide perovskites for high performance green photovoltaics. _Adv. Energy Mater._ **11** , 2102131 (2021). 

14. Zhou, Y. et al. Manipulating crystallization of organolead mixed-halide thin films in antisolvent baths for wide-bandgap perovskite solar cells. _ACS Appl. Mater. Interfaces_ **8** , 2232–2237 (2016). 

15. Bu, T. et al. Lead halide-templated crystallization of methylamine-free 

   - perovskite for efficient photovoltaic modules. _Science_ **372** , 1327–1332 (2021). 

16. Li, N. et al. Liquid medium annealing for fabricating durable perovskite solar cells with improved reproducibility. _Science_ **373** , 561–567 (2021). 

17. Xiao, K. et al. All-perovskite tandem solar cells with 24.2% certified efficiency and area over 1 cm<sup>2</sup> using surface-anchoring zwitterionic antioxidant. _Nat. Energy_ **5** , 870–880 (2020). 

18. Xiao, Z. et al. Solvent annealing of perovskite-induced crystal growth for photovoltaic-device efficiency enhancement. _Adv. Mater._ **26** , 6503–6509 (2014). 

19. Zhu, W. et al. Facile face-down annealing triggered remarkable texture development in CH3NH3PbI3 films for high-performance perovskite solar cells. _ACS Appl. Mater. Interfaces_ **9** , 6104–6113 (2017). 

20. Liu, J. et al. Lead-free solar cells based on tin halide perovskite films with high coverage and improved aggregation. _Angew. Chem. Int. Ed._ **57** , 13221–13225 (2018). 

21. Zhu, L. et al. Solvent-molecule-mediated manipulation of crystalline grains for efficient planar binary lead and tin triiodide perovskite solar cells. _Nanoscale_ **8** , 7621–7630 (2016). 

22. Chen, S. et al. Stabilizing perovskite-substrate interfaces for high-performance perovskite modules. _Science_ **373** , 902–907 (2021). 

23. Jiang, X. et al. One-step synthesis of SnI2·(DMSO) _x_ adducts for high-performance tin perovskite solar cells. _J. Am. Chem. Soc._ **143** , 10970–10976 (2021). 

24. Chen, S. et al. Crystallization in one-step solution deposition of perovskite 

   - films: upward or downward? _Sci. Adv._ **7** , eabb2412 (2021). 

25. Zhao, D. et al. Efficient two-terminal all-perovskite tandem solar cells enabled by high-quality low-bandgap absorber layers. _Nat. Energy_ **3** , 1093–1100 (2018). 

26. Zhao, D. et al. Low-bandgap mixed tin–lead iodide perovskite absorbers with long carrier lifetimes for all-perovskite tandem solar cells. _Nat. Energy_ **2** , 17018 (2017). 

27. Chen, Q. et al. Unveiling roles of tin fluoride additives in high-efficiency low-bandgap mixed tin–lead perovskite solar cells. _Adv. Energy Mater._ **11** , 2101045 (2021). 

28. Li, C. et al. Reducing saturation-current density to realize high-efficiency low-bandgap mixed tin–lead halide perovskite solar cells. _Adv. Energy Mater._ **9** , 1803135 (2018). 

29. Liao, W. et al. Fabrication of efficient low-bandgap perovskite solar cells by combining formamidinium tin iodide with methylammonium lead iodide. _J. Am. Chem. Soc._ **138** , 12360–12363 (2016). 

30. Yu, Y. et al. Synergistic effects of lead thiocyanate additive and solvent annealing on the performance of wide-bandgap perovskite solar cells. _ACS Energy Lett._ **2** , 1177–1182 (2017). 

31. Boccard, M. & Ballif, C. Influence of the subcell properties on the fill factor of two-terminal perovskite–silicon tandem solar cells. _ACS Energy Lett._ **5** , 1077–1082 (2020). 

32. Yang, M. et al. Facile fabrication of large-grain CH3NH3PbI3− _x_ Br _x_ films for high-efficiency solar cells via CH3NH3Br-selective Ostwald ripening. _Nat. Commun._ **7** , 12305 (2016). 

33. Zhang, G. et al. Synthesis of polymeric fluorescent brightener based on coumarin and its performances on paper as light stabilizer, fluorescent brightener and surface sizing agent. _Appl. Surf. Sci._ **367** , 167–173 (2016). 

34. Alsalloum, A. Y. et al. 22.8%-efficient single-crystal mixed-cation inverted perovskite solar cells with a near-optimal bandgap. _Energy Environ. Sci._ **14** , 2263–2268 (2021). 

35. Lu, H. et al. Vapor-assisted deposition of highly efficient, stable black-phase FAPbI3 perovskite solar cells. _Science_ **370** , eabb8985 (2020). 

**NATuRe eNeRgY** | VOL 7 | AUgUST 2022 | 744–753 | www.nature.com/natureenergy 

**752** 

<mark>Articles</mark> 

#### **NATurE ENErgy** 

36. Li, D.-B. et al. Stable and efficient CdS/Sb2Se3 solar cells prepared by scalable close space sublimation. _Nano Energy_ **49** , 346–353 (2018). 

37. Chen, Y. et al. Self-elimination of intrinsic defects improves the lowtemperature performance of perovskite photovoltaics. _Joule_ **4** , 1961–1976 (2020). 

38. Chen, C. et al. Optical properties of amorphous and polycrystalline Sb2Se3 thin films prepared by thermal evaporation. _Appl. Phys. Lett._ **107** , 043905 (2015). 

39. Lin, R. et al. Monolithic all-perovskite tandem solar cells with 24.8% efficiency exploiting comproportionation to suppress Sn(II) oxidation in precursor ink. _Nat. Energy_ **4** , 864–873 (2019). 

40. Yu, Z. et al. Simplified interconnection structure based on C60/SnO2- _x_ for all-perovskite tandem solar cells. _Nat. Energy_ **5** , 657–665 (2020). 

41. Li, C. et al. Low-bandgap mixed tin–lead iodide perovskites with reduced methylammonium for simultaneous enhancement of solar cell efficiency and stability. _Nat. Energy_ **5** , 768–776 (2020). 

42. Wang, C. et al. Compositional and morphological engineering of mixed cation perovskite films for highly efficient planar and flexible solar cells with reduced hysteresis. _Nano Energy_ **35** , 223–232 (2017). 

43. Wang, C. et al. Low-temperature plasma-enhanced atomic layer deposition of tin oxide electron selective layers for highly efficient planar perovskite solar cells. _J. Mater. Chem. A_ **4** , 12080–12087 (2016). 

##### **Acknowledgements** 

The work was financially supported by the National Key Research and Development Program of China (number 2019YFE0120000), National Natural Science Foundation of China (numbers 61875143, 62005188, 62174112, and 62120106001), Natural Science Foundation of Jiangsu Province (BK20190825), Fundamental Research Funds for the Central Universities (numbers YJ2021157, 2021SCU12057, and YJ201955), the Science and Technology Program of Sichuan Province (numbers 2020JDJQ0030), Engineering Featured Team Fund of Sichuan University (2020SCUNG102) and Engineering Research Center of Digital Imaging and Display, Ministry of Education, Soochow University. F.F. 

acknowledges funding from the Swiss Federal Office of Energy (SFOE)-BFE (project number SI/501805-01). 

##### **Author contributions** 

C.W. and D.Z. conceived the project. C.W. carried out single cell and tandem cell fabrication and characterization. Y.Z., Y.A. and R.H. helped with the fabrication of single-junction wide- _E_ g PVSCs in both regular and inverted structures. T.M. and J.Z. helped the device fabrication of single-junction low- _E_ g PVSCs. C.C. did the SEM, X-ray diffraction characterizations of single-junction PVSCs and helped the solvent annealing processes of both low- _E_ g and wide- _E_ g perovskite films. S.R. did the PL and TRPL measurements. C.W., F.F., D.Z. and X.L. analysed the data and wrote the manuscript. Y.Z., T.M., Y.A., R.H., J.Z., C.C., S.R. and F.F. helped with the manuscript preparation. All the authors discussed the results and commented on the manuscript. X.L. and D.Z. supervised the project. 

##### **Competing interests** 

The authors declare no competing interests. 

##### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41560-022-01076-9. 

**Correspondence and requests for materials** should be addressed to Fan Fu, Dewei Zhao or Xiaofeng Li. 

**Peer review information** _Nature Energy_ thanks Rohit Prasanna, Atsushi Wakamiya and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. **Reprints and permissions information** is available at www.nature.com/reprints. **Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

© The Author(s), under exclusive licence to Springer Nature Limited 2022 

**NATuRe eNeRgY** | VOL 7 | AUgUST 2022 | 744–753 | www.nature.com/natureenergy 

**753** 

Corresponding author(s): 

Dewei Zhao, Fan Fu, Xiaofeng Li 



## <u>Solar Cells Reporting Summary</u> 

Nature Research wishes to improve the reproducibility of the work that we publish. This form is intended for publication with all accepted papers reporting the characterization of photovoltaic devices and provides structure for consistency and transparency in reporting. Some list items might not apply to an individual manuscript, but all fields must be completed for clarity. 

For further information on Nature Research policies, including our data availability policy, see Authors & Referees. 

### � Experimental design 

##### **Please check: are the following details reported in the manuscript?** 

1.   Dimensions 

|Area of the tested solar cells|Yes<br>No|The device area is 0.09 cm2.|
|---|---|---|
|Method used to determine the device area|Yes|Metal mask of 0.09 cm2 was used during metal electrode fabrication.|
||No||
|2.   Current-voltage characterization<br>Current density-voltage (J-V) plots in both forward|Yes|Provided in this manuscript.|
|and backward direction|No||
|Voltage scan conditions|Yes|Provided in Method section.|
|_For instance: scan direction, speed, dwell times_|No||
|Test environment|Yes|Provided in Method section.|
|_For instance: characterization temperature, in air or in glove box_|No||
|Protocol for preconditioning of the device before its|Yes|No preconditioning was used in this work.|
|characterization|No||
|Stability of the J-V characteristic|Yes|Stabilized PCEs of both single-junction and tandem solar cells were provided.|
|_Verified with time evolution of the maximum power point or with_<br>_the photocurrent at maximum power point; seeref. 7 for details._|No||
|3.   Hysteresis or any other unusual behaviour<br>Description of the unusual behaviour observed during|Yes|Very minor hysteresis was observed for devices.|
|the characterization|No||
||Yes|J-V curves under reverse and forward scans were provided.|
|Related experimental data<br>4.   Efficiency|No||
|External quantum efficiency (EQE) or incident|Yes|EQE curves were provided.|
|photons to current efficiency (IPCE)|No||
|A comparison between the integrated response under|Yes|The integrated Jsc values from EQE were compared to Jsc values from J-V|
|the standard reference spectrum and the response|No|measurements, showing less than 4% difference.|
|measure under the simulator|||
|For tandem solar cells, the bias illumination and bias|Yes|Stated in Method section.|
|voltage used for each subcell|No||
|5.   Calibration|||
|Light source and reference cell or sensor used for the|Yes|Stated in Method section.|
|characterization|No||
|Confirmation that the reference cell was calibrated|Yes|The reference cells were calibrated by NREL and explained in Method section.|
|and certified|No||



1 

|Calculation of spectral mismatch between the<br>reference cell and the devices under test|Yes<br>No|The light spectrum used for measurements matches well with the reference silicon<br>cell, we did not calculated the spectral mismatch between the reference cell and the<br>tested cells.|
|---|---|---|
|6.   Mask/aperture|||
|Size of the mask/aperture used during testing|Yes<br>No|Metal aperture mask with area of 0.0625 cm2 was used for testing.|
|Variation of the measured short-circuit current|Yes|All J-V curves were measured with mask.|
|density with the mask/aperture area|No||
|7.   Performance certification|||
|Identity of the independent certification laboratory|Yes|Tandem solar cell efficiency was certified by SIMIT (Shanghai, China).|
|that confirmed the photovoltaic performance|No||
|A copy of any certificate(s)|Yes|Provided in Supplementary Information.|
|_Provide in Supplementary Information_|No||
|8.   Statistics|||
|b f l ll d|Yes|Stated in the manuscript.|
|Numer o soar ces teste|No||
||Yes|Stated in the manuscript.|
|Statistical analysis of the device performance|No||
|9.   Long-term stability analysis|||
|Type of analysis, bias conditions and environmental|Yes|Stated in the Method section.|
|conditions<br>_For instance: illumination type, temperature, atmosphere_|No||
|_humidity, encapsulation method, preconditioning temperature_|||



2 

