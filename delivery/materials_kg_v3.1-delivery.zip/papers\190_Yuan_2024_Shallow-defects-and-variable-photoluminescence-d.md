# Shallow defects and variable photoluminescence decay times up to 280 µs in triple-cation perovskites

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Materials |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 166 |
| 作者 | Ye Yuan, Genghua Yan, C. Dreessen, Toby Rudolph, M. Hülsbeck, B. Klingebiel, Jiajiu Ye, U. Rau et al. |
| DOI | 10.1038/s41563-023-01771-2 |
| 源文件 | 090_Yuan_2024_Shallow-defects-and-variable-photoluminescence-d.pdf |

---
https://doi.org/10.1038/s41563-023-01771-2 

## **nature materials** 

##### **Article** 

# **Shallow defects and variable photoluminescence decay times up to 280 µs in triple-cation perovskites** 

|Received: 25 January 2023<br>Accepted: 23 November 2023|**Ye Yuan**<br> <sup>**1,2**</sup>**, Genghua Yan**<br> <sup>**1,2**</sup><br>**, Chris Dreessen**<br> <sup>**1,3**</sup>**, Toby Rudolph**<sup>**1**</sup>**,**<br>**Markus Hülsbeck**<sup>**1**</sup>**, Benjamin Klingebiel**<br> <sup>**1**</sup>**, Jiajiu Ye**<sup>**1**</sup>**, Uwe Rau**<br> <sup>**1**</sup>**&**<br>**Thomas Kirchartz**<br> <sup>**1,4**</sup>|
|---|---|
|Published online: 9 January 2024||
|Check for updates|Quantifying recombination in halide perovskites is a crucial prerequisite<br>to control and improve the performance of perovskite-based solar cells.<br>While both steady-state and transient photoluminescence are frequently<br>used to assess recombination in perovskite absorbers, quantitative<br>analyses within a consistent model are seldom reported. We use transient<br>photoluminescence measurements with a large dynamic range of more<br>than ten orders of magnitude on triple-cation perovskite films showing<br>long-lived photoluminescence transients featuring continuously<br>changing decay times that range from tens of nanoseconds to hundreds of<br>microseconds. We quantitatively explain both the transient and steady-state<br>photoluminescence with the presence of a high density of shallow defects<br>and consequent high rates of charge carrier trapping, thereby showing<br>that deep defects do not affect the recombination dynamics. The complex<br>carrier kinetics caused by emission and recombination processes via<br>shallow defects imply that the reporting of only single lifetime values, as is<br>routinely done in the literature, is meaningless for such materials. We show<br>that the features indicative for shallow defects seen in the bare films remain<br>dominant in finished devices and are therefore also crucial to understanding<br>the performance of perovskite solar cells.|



Non-radiative recombination via defects is one of the most important loss processes in most photovoltaic technologies<sup>1,2</sup> . Thus, a considerable amount of photovoltaic research has been dedicated to suppressing non-radiative recombination as well as characterizing and quantifying its extent<sup>3,4</sup> . This is especially true for emerging photovoltaic technologies such as halide perovskites that mostly rely on solution-processed polycrystalline thin films. In lead halide perovskites, non-radiative recombination is much less of a problem compared to other polycrystalline materials used for photovoltaic applications<sup>5,6</sup> . 

The common explanation is that most intrinsic defects are either shallow or unlikely to form<sup>7</sup> . Interestingly, the experimental community has so far worked under the paradigm that deep defects dominate recombination, whereas shallow defects are mostly considered irrelevant<sup>8,9</sup> . The only shallow defects considered crucial for device functionality are mobile ions causing field screening and hysteresis in the current–voltage curve<sup>10,11</sup> . 

Identifying the properties of the defects dominating non-radiative recombination is important for various reasons. Depending on the 

> 1IEK-5 Photovoltaik, Forschungszentrum Jülich, Jülich, Germany. 2Institute for Solar Energy Systems, Guangdong Provincial Key Laboratory of Photovoltaic Technology, School of Physics, Sun Yat-sen University, Guangzhou, P. R. China.<sup>3</sup> Instituto de Ciencia Molecular (ICMol), Universidad de Valencia, Paterna, Spain.<sup>4</sup> Faculty of Engineering and CENIDE, University of Duisburg-Essen, Duisburg, Germany. e-mail: ge.yan@fz-juelich.de; t.kirchartz@fz-juelich.de 

Nature Materials | Volume 23 | March 2024 | 391–397 

**391** 

**Article** 

https://doi.org/10.1038/s41563-023-01771-2 



<!-- Start of picture text -->
a 0.2 b<br>0.3 SQ limit 10–4 This work<br>0.4 ref. 15 10–5 ref. 15<br>0.5 This work 10–6<br>0.6 10–7<br>Monoexponential<br>0.7<br>10–8 BiexponentialDifferential<br>0.810–9 10–8 k rad (1010–9–7, 10–10, 1010–6–11, 10–12 cm10–53 s–1) 10–4 10–9 0 2 4 6 Others/not clear8 10<br>Decay time  τ  (s) Dynamic range (orders of magnitude)<br> (s)Decay time  τ<br>Voltage difference / (V) EVq  – goc<br><!-- End of picture text -->

**Fig. 1 | Meta-analysis of reported energy loss and decay time in publications. a** , The voltage difference _E_ g/ _q_ – _V_ oc as a function of decay time of perovskite films. The lines indicate the relationship between carrier lifetime and energy loss<sup>13,14</sup> , which is calculated based on a step function absorptance by taking _p_ 0 = 0, _p_ a = 0, _p_ e = 0.05, _G_ ext = 5.3 × 10<sup>21</sup> cm<sup>−3</sup> s<sup>−1</sup> and _V_<sup>SQ</sup> oc<sup>= 1.297 V (corresponding to a bandgap</sup> of 1.57 eV), where _p_ 0 is the equilibrium carrier concentration, _p_ a is parasitic 

absorption probability, _p_ e is emission probability, _G_ ext is the generation rate of electron-hole pairs due to external illumination and _V_<sup>SQ</sup> oc<sup>is the open-circuit</sup> voltage in the Shockley-Queisser (SQ) model. Additionally, _k_ rad is the radiative recombination coefficient. **b** , Meta-analysis on the dynamic range of tr-PL decay curves in publications. The colours represent the fitting methods of the tr-PL decay curves. More information is in Supplementary Note 5. 

dominant defect species, different material optimization strategies and characterization approaches are needed. For deep traps, both transient photoluminescence (PL) and PL quantum yields are viable methods to quantify recombination, and the information content of both quantities is basically identical<sup>12</sup> . In the presence of deep traps, transient PL measurements lead to monoexponential decays at sufficiently low injection conditions, from which charge carrier lifetimes can be extracted. Those lifetimes must then be consistent with the PL quantum yields obtained from steady-state PL measurements and consequently correlate with the voltage difference _E_ g/ _q_ – _V_ oc, where _E_ g, _q_ and _V_ oc are the bandgap energy, elementary charge and open-circuit voltage, respectively. Figure 1a shows this correlation for a range of perovskite studies<sup>13,14</sup> , where the voltage difference was calculated from the solar cell data while the lifetime was obtained from film measurements. While many data points seem to show correlation between lifetime and voltage difference, others (especially the data points (stars) labelled ‘this work’ and ‘ref. 15’) feature decay times that seem too long for the associated value of _E_ g/ _q_ – _V_ oc. This raises the question of whether transient PL decay times are always a valid method to quantify recombination and voltage losses in halide perovskites. Moreover, the finding raises doubts regarding the implicit assumption that deep defects dominate recombination losses and transient PL decay. 

Here we show that typical triple-cation perovskite layers, layer stacks and solar cells are strongly affected by shallow defects that manifest themselves in steady-state and transient PL data. The most convincing evidence for shallow defects is the presence of an extremely long-lived PL signal in time-resolved PL (tr-PL) measurements with a high dynamic range of greater than ten orders of magnitude. Combined with the observation of PL quantum yields in the range of 2% (this means much smaller than unity) in films, we can rule out radiative band-to-band recombination as the reason for the long-lived decay. Consistent with the dominant influence of shallow defects, the decay approximately follows a power law (PL flux _ϕ_ ∝ _t_<sup>-</sup><sup>_α_</sup> , where _t_ is time and _α_ is a constant) over the investigated time range and never saturates to an exponential decay (Supplementary Fig. 5). The high dynamic range is important to disentangle different mechanisms in large-signal transients<sup>16</sup> and is not typically found in the literature on halide perovskites (Fig. 1b). The differential decay times exceed 100 µs at the end of the decay, which implies that these decays may be the longest measured so far in halide perovskites or any other direct semiconductor considered for photovoltaic applications<sup>6</sup> . The high dynamic range combined with the power-law nature of the decay allows us to observe differential 

decay times that vary over four orders of magnitude spanning tens of nanoseconds at the beginning of a decay up to hundreds of microseconds. This implies that the heavily used concept of a single ‘lifetime’ of charge carriers in halide perovskites can be highly misleading and may have to be replaced by effective recombination coefficients. We note that decay times exceeding tens of microseconds are observed also in films with one or two charge-extracting layers and in full devices. This finding implies that the shallow traps and long lifetimes are consistent with efficient charge extraction in solar cells with fill factors exceeding 80%. The absence of any type of saturation of the decay time to a constant value shows that (1) the halide perovskite films are extremely intrinsic<sup>17</sup> and (2) the Shockley–Read–Hall (SRH) lifetime for recombination via deep defects must be extremely long (in the range of hundreds of microseconds; Supplementary Fig. 7). The latter finding implies a change of the dominant paradigm that reduction of deep defects is crucial for further efficiency improvements. Instead, we show that a high density of shallow defects dominates recombination and limits device performance. 

#### **Defect-mediated recombination** 

Recombination via defects is the most relevant recombination mechanism for thin-film photovoltaics as it reduces the open-circuit voltage of solar cells and often also the fill factor and the short-circuit current. The SRH model is used to identify non-radiative recombination and estimate its effect on device performance. The SRH recombination rate for one species of singly charged defects is given by<sup>18,19</sup> 



<!-- Start of picture text -->
( np  − n i 2)<br>R SRH = , (1)<br>( n  +  n 1)  τ p + ( p  +  p 1) τ n<br><!-- End of picture text -->

where _n_ , _p_ and _n_ i represent electron, hole and intrinsic carrier concentrations; _τ_ p and _τ_ n are the SRH lifetimes for holes and electrons; _n_ 1 = _N_ Cexp[( _E_ T – _E_ C)/ _k_ B _T_ ]; and _p_ 1 = _N_ Vexp[( _E_ V – _E_ T)/ _k_ B _T_ ]. Here _n_ 1 and _p_ 1 are in the unit ‘per cubic centimetre’ and use further variables such as the effective density of states for the conduction and valence bands ( _N_ C and _N_ V, respectively) and the energy of the trap ( _E_ T), conduction band edge ( _E_ C) and valence band edge ( _E_ V), as well as a Boltzmann constant ( _k_ B) and temperature ( _T_ ). Given that lead halide perovskites behave like intrinsic semiconductors<sup>17</sup> , the equation is typically simplified using the two assumptions _n_ = _p_ and _n_ ≫ _n_ i. Furthermore, _n_ 1 and _p_ 1 are typically considered negligible relative to _n_ and _p_ , implying that detrapping is neglected, which is typically a good approximation for 

Nature Materials | Volume 23 | March 2024 | 391–397 

**392** 

**Article** 

https://doi.org/10.1038/s41563-023-01771-2 



<!-- Start of picture text -->
a 106 b<br>105 10–4 Gated CCD<br>104 ~ n 2<br>103<br>102 OAI-modified film 10–5<br>2.6 OD Simulation<br>1015 1016<br>Carrier concentration  n  (cm –3 ) 10–6 0 OD<br>c 2 OD ~exp(–∆ E F/3 k B T )<br>Experiment<br>Simulation<br>1.2 10–7 1 OD<br>n id ≈ 1.2<br>~exp(–∆ E F/2 k B T )<br>1.1 OAI-modified film OAI-modified film<br>10–2 10–1 100 10–8 1.0 1.1 1.2 1.3 1.4 1.5<br>Intensity (suns) Fermi-level splitting ∆ E F (eV)<br> = 0) (a.u.) ф ( t<br>Differential decay time  (s) τ diff<br> (V)∆ E F<br><!-- End of picture text -->

**Fig. 2 | The tr-PL and steady-state PL results of OAI-modified films. a** , Change of initial amplitude _ϕ_ ( _t_ = 0) of tr-PL decay curve (time-correlated single-photon counting set-up) for an OAI-modified perovskite film as a function of carrier concentration. The amplitude is proportional to _n_<sup>2</sup> , indicating the film is intrinsic. **b** , Measured differential decay time as a function of Fermi-level splitting 

by both time-correlated single-photon counting (using different optical density (OD) filters) and gated CCD set-ups. Note that the curve for 0 OD is nearly overlapping with the gated CCD curve. The solid line is the simulated result. **c** , Calculated and simulated results of Δ _E_ F versus illumination intensity for OAI-modified film. The calculated data are based on the steady-state PL results. 

a deep trap. These simplifications lead to _R_ SRH = _n_ /( _τ_ p + _τ_ n), that is, to the situation in which SRH recombination is often considered synonymous with first-order recombination, which has a rate that is linear in _n_ (and _p_ ), that is, _R_ SRH ∝ _n_<sup>_δ_</sup> , where _δ_ = 1 is the reaction order. However, this is only a special case, where the trap is between the quasi-Fermi levels under operation<sup>20</sup> . If a trap dominating recombination is close to either the conduction or the valence band edge, one of the two voltage-independent terms _n_ 1 or _p_ 1 will become comparable to _n_ and _p_ , and hence affect the recombination rate. Without loss of generality, we assume that we have a defect close to the conduction band, implying that _n_ 1 ≫ _p_ 1. In this case, the rate _R_ SRH = _n_<sup>2</sup> /[( _n_ + _n_ 1) _τ_ p + _nτ_ n] can scale linearly with _n_ (for the case of _n_ 1 ≪ _n_ ); it may scale quadratically with _n_ (for _n_ 1 ≫ _n_ ); or it may have a non-integer recombination order if _n_ and _n_ 1 are similar in magnitude. Thus, depending on the trap level and the quasi-Fermi levels, SRH recombination may lead to 1 < _δ_ < 2, but in consequence, the ideality factor _n_ id will assume non-integer values over a wide range of Fermi levels, that is, 1 < _n_ id < 2. 

Equation (1) describes SRH recombination in a steady-state situation relevant for explaining the current–voltage curve, the open-circuit voltage and the steady-state PL. For a transient experiment, the SRH formalism becomes a set of coupled rate equations that can be solved numerically (Supplementary Note 6). Analytical solutions are possible<sup>15,16</sup> but are commonly used only in the absence of detrapping. A perovskite film on glass whose recombination is dominated by a deep trap will exhibit a monoexponential PL decay at sufficiently low excitation conditions, where radiative recombination can be disregarded. In the presence of shallow traps, however, the decay will have additional features related to detrapping and changes in trap occupation due to the movement of the quasi-Fermi levels relative to the trap position during the transient process. Note that increased apparent lifetimes caused by detrapping have previously been reported for multicrystalline Si wafers<sup>21,22</sup> and for kesterite solar cells<sup>23</sup> . 

#### **PL experiments** 

To investigate the nature of defects, we prepared Cs0.05FA0.73MA0.22 PbI2.56Br0.44 triple-cation perovskite films post-treated with _n_ -octylammonium iodide (OAI), with a bandgap of ∼1.63 eV, and subsequently fabricated ITO/Me-4PACz/perovskite/C60/BCP/Ag inverted solar cells with non-radiative recombination losses as low as ∼100 mV (ITO, indium tin oxide; Me-4PACz, [4-(3,6-dimethyl-9 _H_ -carbazol-9-yl) butyl]phosphonic acid; BCP, bathocuproine). To quantitatively analyse non-radiative recombination, we measured tr-PL decays as a function 

of light intensity. Figure 2a shows that the initial PL flux _ϕ_ ( _t_ = 0) of transient PL measurements scales with the square of the laser power and hence with _n_<sup>2</sup> , suggesting that the electron and hole concentrations are identical just after the pulse (that is, before recombination could have happened) over a range of pulse intensities. Thus, the perovskite film cannot have either a high hole or a high electron density in the dark, as otherwise the initial amplitude should have scaled linearly with laser power, as seen for instance for Sn-based perovskites<sup>17</sup> . Thus, we can treat the OAI-modified film as well as an unmodified control (Supplementary Fig. 12) as intrinsic semiconductors—a finding that is consistent with reports on similar triple-cation perovskites<sup>24</sup> . 

Furthermore, we measured tr-PL decays with two different methods (single-photon counting and a gated CCD (charge-coupled device) camera) over approximately ten orders of magnitude in dynamic range (Fig. 2b). In Fig. 2b, the normalized decay data have been changed to differential decay time versus Fermi-level splitting. The details of the transformation and the figure before transformation can be found in Supplementary Fig. 4. Figure 2b shows that the tr-PL data obtained using the gated CCD camera features a constantly changing decay time that varies from tens of nanoseconds at high Fermi-level splitting (beginning of the decay) to >100 µs at a Fermi-level splitting of ∼1 V. The covered range of ∼500 meV in Fermi-level splitting corresponds to exp(500 meV/ _k_ B _T_ ) ≘ 9.5 orders of magnitude dynamic range ( _k_ B, Boltzmann’s constant). Increasing the laser intensity can enhance the signal-to-noise ratio, which can further increase the dynamic range to over ten orders of magnitude. Then a detectable decay time of >280 µs was observed (Supplementary Fig. 7). The decay time ( _τ_ ) is nearly continuously changing with a constant slope, where _τ_ ∝ exp(–Δ _E_ F/( _θk_ B _T_ )), 2 ≤ _θ_ ≤ 3 and _E_ F is the Fermi energy. This implies that the decay is approximately consistent with a power law of the type _ϕ_ ∝ _t_<sup>–2</sup> as expected (Supplementary Fig. 5) for radiative recombination— or shallow defects—in an intrinsic semiconductor. An alternative to the determination of a (constantly changing) decay time is therefore the determination of a differential recombination coefficient _k_ diff (details in Supplementary Note 1), which would be constant for a recombination quadratic in free carrier density. This would enable the description of the recombination dynamics by a single constant parameter in the case of the absence of deep defects. Such a recombination coefficient has been frequently used in the organic solar cell community<sup>25,26</sup> but is so far uncommon in the description of halide perovskites. 

We also note that the single-photon counting data partly overlap with the data from the gated CCD but have additional features. Due to 

Nature Materials | Volume 23 | March 2024 | 391–397 

**393** 

**Article** 

https://doi.org/10.1038/s41563-023-01771-2 



<!-- Start of picture text -->
a 1.28<br>1.24<br>1.20<br>1.16<br>OAI modified<br>1.12<br>Control<br>b 100<br>10–2<br>10–4<br>10–6 OAI modified<br>Film<br>ITO/Me-4PACz/film<br>10–8 Film/C60<br>ITO/Me-4PACz/film/C60<br>10–10100 101 102 103 104 105<br>Time  t  (ns)<br>c<br>~exp(–∆ E F/2 k B T )<br>10–4<br>10–5<br>~exp(–∆ E F/3 k B T )<br>10–6<br>10–7 Plateau<br>10–8<br>1.0 1.1 1.2 1.3 1.4 1.5<br>Fermi-level splitting ∆ E F (eV)<br>Film Me-4PACz/film Film/C60Me-4PACz/film/C60 Device<br> (eV)Quasi-Fermi-level splitting ∆ E F<br>Photoluminescence flux  (normalized) ф<br>Differential decay time  (s) τ diff<br><!-- End of picture text -->

**Fig. 3 | PL characteristics of layer-stack samples. a** , Calculated quasi-Fermi-level splitting for control and OAI-modified samples with different layer stacks, which were measured under 1 sun equivalent illumination. **b** , The tr-PL decay curves of OAI-modified samples with different layer stacks measured by the gated CCD set-up. **c** , Differential decay time as a function of Fermi-level splitting for OAI-modified samples with different layer stacks measured by the gated CCD set-up. 

the repetition rate limitation of the single-photon counting method, the decay times shown using the gated CCD are impossible to measure in the absence of a measurement system that can handle repetition rates below a few kilohertz (Supplementary Fig. 4). In addition, we demonstrate that exponential fitting is unable to reliably extract PL decay times (Supplementary Table 1). Finally, we measured the steady-state PL to determine the ideality factor of the films and obtained a non-integer ideality factor of _n_ id ≈ 1.2 (Fig. 2c). 

To verify that the data are consistent with shallow traps but inconsistent with recombination being limited by deep traps, we use a rate-equation model to simulate both the tr-PL and the steady-state PL data (equations are shown in Supplementary Note 6). The solid lines shown in Fig. 2b,c represent fits to the data, with the parameters shown in Supplementary Table 2. We use three shallow defects to fit the data, and they have a distance to the nearest band of about 55, 95 and 125 meV. Furthermore, we know from Fig. 2a that the defects cannot dope the layer, that is, they have to be acceptor-like defects close to the conduction band or donor-like defects close to the valence band (as visualized in Supplementary Fig. 17). We note that defect positions closer to mid-gap would lead to substantially different shapes of the tr-PL (Supplementary Fig. 20). Furthermore, the only way to consistently explain decay times of hundreds of microseconds in combination with steady-state PL values that are much lower than the radiative limit is to invoke the presence of shallow traps that release charge carriers at longer times, thereby leading to a delayed luminescence, a power-law decay and, in consequence, extremely long decay times towards the end of the decay. Detrapping effects can cause the peculiar situation of PL decay times that increase with increasing shallow defect density, which is the opposite trend as that observed for deep defects (Supplementary Fig. 23). 

#### **Influence of charge-extracting layers** 

Figure 3a shows the Δ _E_ F of layer-stack samples acquired from steady-state PL measurements (Supplementary Fig. 30). The ITO/ Me-4PACz/perovskite sample shows the highest Δ _E_ F value. However, interfacing the perovskite layer with C60 substantially lowers Δ _E_ F, possibly by introducing additional interfacial defects, as suggested by studies<sup>27,28</sup> and consistent with previous reports on steady-state<sup>29</sup> and transient PL<sup>15,30,31</sup> . OAI modification can effectively passivate the perovskite/C60 interface defects, as samples with the perovskite/C60 interface show a stronger enhancement in Δ _E_ F after OAI modification than stacks without C60. Figure 3b,c shows the time-dependent tr-PL decay curves and the differential decay time _τ_ diff as a function of the Δ _E_ F of different layer stacks. The decay times of different stacks are remarkably similar. While interfaces between perovskite and C60 reduce Δ _E_ F values, interfaces with only Me-4PACz show an increase in Δ _E_ F. This indicates that film growth on Me-4PACz improves the bulk properties and suggests that the Me-4PACz/perovskite interface is electronically rather benign. This also contributes to the Me-4PACz/perovskite samples showing the longest _τ_ diff at high Δ _E_ F values. While the general shape of the _τ_ diff versus Δ _E_ F curves is similar, the samples with charge-extracting interfaces (either electron transport layer ETL or hole transport layer HTL) show a somewhat lower slope at intermediate values of Δ _E_ F (highlighted by the plateau in the figure). Possible reasons for this feature are Coulomb effects that have previously been shown to lead to an S-shaped decay time versus Δ _E_ F curves<sup>15,32</sup> . 

#### **Device characteristics** 

Finally, inverted solar cells were fabricated based on the films. Figure 4a shows that the _V_ oc of the device increases from 1.114 to 1.214 V after OAI modification, resulting in an efficiency increase from 19.9% to 21.4%. Figure 4b presents the statistical distribution of opencircuit voltages as a function of the OAI concentration. The best devices reach a _V_ oc over 1.23 V corresponding to a non-radiative 

Nature Materials | Volume 23 | March 2024 | 391–397 

**394** 

**Article** 

https://doi.org/10.1038/s41563-023-01771-2 



<!-- Start of picture text -->
a 0 b<br>OAI-modified device 1 ( V radoc )<br>Control device 1.30<br>–5 Control: OAI modified: 10–1<br>1.114 V21.70 mA cm–2 22.00 mA cm1.214 V –2 1.25 Q lume  ≈ 2%<br>–10 82.58% 80.06% 10–2<br>19.9% 21.4% 1.20<br>–15<br>10–3<br>1.15<br>–20 Device area = 0.06 cm2<br>1.10 10–4<br>0 0.2 0.4 0.6 0.8 1.0 1.2 Control OAI 1.0 OAI 1.5 OAI 2.0 OAI 2.5<br>Voltage  V  (V)<br>c d<br>10–4 Gated CCD<br>1.20<br>~exp(–∆ E F/ k B T )<br>1.15 n id ≈ 1.5 10–5<br>~exp(–∆ E F/3 k B T )<br>n id ≈ 1.4<br>1.10 10–6 ~exp(–∆ E F/6 k B T )<br>2.6 OD<br>2 OD 1 OD<br>1.05<br>10–7 0 OD<br>1.00 OAI-modified device<br>Control device OAI-modified device<br>10–8<br>0.01 0.1 1 0.9 1.0 1.1 1.2 1.3 1.4 1.5<br>Intensity (suns) Fermi-level splitting ∆ E F (eV)<br>–2)Current density  (mA cm J  (V)Open-circuit voltage  V oc<br> (V)Open-circuit voltage  V oc Differential decay time   (s) τ diff<br><!-- End of picture text -->

**Fig. 4 | Device performance. a** , _J_ – _V_ curves of the control and OAI-modified (2 mg ml<sup>–1</sup> ) small-area device. The value shown in the figure, from top to bottom, is _J_ sc, _V_ oc, _FF_ and efficiency. **b** , Statistical open-circuit voltage data of control devices and OAI-modified devices with different OAI concentrations in milligrams per millilitre. The solid lines indicate the PL quantum yields. The box contains the values from the upper to lower quartiles. The lines outside the box 

indicate the ×1.5 interquartile range, and the line inside the box is the median. The open square inside the box is the mean value. The sample size for each group, from left to right, is 12, 12, 14, 26 and 12. **c** , Open-circuit voltage of control and OAI device as a function of illumination intensity. **d** , Differential decay time _τ_ diff as a function of Δ _E_ F for the OAI-modified device. 

recombination loss: Δ _V_ ocnonrad = _V_ oc<sup>rad−</sup><sup>_V_</sup> oc<sup>≈100 mV (current density</sup> versus voltage ( _J_ – _V_ ) curves in Supplementary Fig. 36), whereby the open-circuit voltage in the radiative limit is given by _V_ oc<sup>rad= 1.332 V.</sup> The horizontal lines represent the values of _V_ oc expected for different PL quantum efficiency ( _Q_<sup>lum</sup> e ) values. Results show that _Q_<sup>lum</sup> e increases from ∼0.04% to ∼2% as a function of OAI concentration. Although the value is lower than the record value of >5% (refs. 33,34), it is still higher than most triple-cation-perovskite-based inverted devices (Supplementary Fig. 37). More details about device performances as well as the band alignment between absorber and contact layers can be found in Supplementary Note 4. Figure 4c shows the intensity-dependent open-circuit voltages of full devices, from which we derive ideality factors of around 1.4 (control) to 1.5 (OAI-modified device). These ideality factors are considerably lower than 2, as would be expected from an intrinsic absorber layer dominated by a deep defect, and are therefore consistent with the assumption that the existence of shallow traps still dominates the behaviour in the final cell. This observation is further corroborated by the behaviour of the decay times from tr-PL, shown in Fig. 4d. The decay times show a rather similar behaviour to the films and layer stacks shown in Fig. 3c. At high Δ _E_ F (for example, 1.3–1.5 eV), the high carrier concentration results in strong radiative recombination, leading to the fast variation of _τ_ diff. In the intermediate region (for example, 1.05–1.3 eV), the decay follows a roughly constant slope of approximately exp(–Δ _E_ F/6 _k_ B _T_ ), which is less steep than for the films and layer stacks. At low Δ _E_ F (for example, <1.05 eV), _τ_ diff sharply increases again. One possible reason could be the capacitance effect caused by the electrodes<sup>15</sup> . The single-photon counting data cannot reflect the real variation of _τ_ diff in the low Δ _E_ F region because of the limitation of the repetition rate. 

#### **Outlook** 

We show that typical triple-cation perovskite layers, layer stacks and solar cells are strongly affected by shallow defects that manifest themselves in steady-state and transient PL data. Detrapping from such shallow traps then leads to extremely long decay times of hundreds of microseconds that can only be measured using a technique with an extremely low repetition rate. These shallow traps are less problematic for device performance than deeper traps with given SRH lifetimes of _τ_ n and _τ_ p but are still dominating the steady-state properties. Furthermore, the signatures of shallow traps in transient and steady-state experiments are difficult to distinguish from radiative recombination, which may have contributed to the wide spread of reported values for the radiative recombination coefficient in lead halide perovskites<sup>35–40</sup> as well as the frequent reports on non-radiative contributions to the quadratic recombination coefficient<sup>9,12,38,39,41</sup> . Furthermore, the work highlights that the often used approximations of the SRH recombination rate must be applied with caution and should not be considered as the default recombination model. The work also shows that the absolute value of the PL decay time extracted from single- or multiexponential fits to low dynamic range fractions of the complete datasets can lead to highly misleading values as decay times may vary over orders of magnitude (tens of nanoseconds to hundreds of microseconds) depending on the excitation density and the repetition rate of the PL set-up. Thus, considering the decay time observed from transient experiments on halide perovskites to be a single number is one of the key fallacies the community needs to overcome to gain insights on recombination dynamics in these materials. A possible alternative to effective decay times for decays that rather resemble a power law instead of an exponential decay is the determination of an effective recombination coefficient. 

Nature Materials | Volume 23 | March 2024 | 391–397 

**395** 

**Article** 

https://doi.org/10.1038/s41563-023-01771-2 

#### **Online content** 

Any methods, additional references, Nature Portfolio reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41563-023-01771-2. 

#### **References** 

1. Park, J. S., Kim, S., Xie, Z. & Walsh, A. Point defect engineering in thin-film solar cells. _Nat. Rev. Mater._ **3** , 194–210 (2018). 

2. Queisser, H. J. & Haller, E. E. Defects in semiconductors: some fatal, some vital. _Science_ **281** , 945–950 (1998). 

3. Luo, D., Su, R., Zhang, W., Gong, Q. & Zhu, R. Minimizing non-radiative recombination losses in perovskite solar cells. _Nat. Rev. Mater._ **5** , 44–60 (2020). 

4. Bao, C. & Gao, F. Physics of defects in metal halide perovskites. _Rep. Prog. Phys._ **85** , 096501 (2022). 

5. Green, M. A. & Ho-Baillie, A. W. Y. Pushing to the limit: radiative efficiencies of recent mainstream and emerging solar cells. _ACS Energy Lett._ **4** , 1639–1644 (2019). 

6. deQuilettes, D. W. et al. Reduced recombination via tunable surface fields in perovskite solar cells. Preprint at _arXiv_ https://doi. org/10.48550/arXiv.2204.07642 (2022). 

7. Huang, J., Yuan, Y., Shao, Y. & Yan, Y. Understanding the physical properties of hybrid perovskites for photovoltaic applications. _Nat. Rev. Mater._ **2** , 17042 (2017). 

8. Feldmann, S. et al. Photodoping through local charge carrier accumulation in alloyed hybrid perovskites for highly efficient luminescence. _Nat. Photon._ **14** , 123–128 (2020). 

9. Kiligaridis, A. et al. Are Shockley-Read-Hall and ABC models valid for lead halide perovskites? _Nat. Commun._ **12** , 3329 (2021). 

10. Belisle, R. A. et al. Interpretation of inverted photocurrent transients in organic lead halide perovskite solar cells: proof of the field screening by mobile ions and determination of the space charge layer widths. _Energy Environ. Sci._ **10** , 192–204 (2017). 

11. Calado, P. et al. Evidence for ion migration in hybrid perovskite solar cells with minimal hysteresis. _Nat. Commun._ **7** , 13831 (2016). 

12. Bowman, A. R. et al. Extracting decay-rate ratios from photoluminescence quantum efficiency measurements in optoelectronic semiconductors. _Phys. Rev. Appl._ **17** , 044026 (2022). 

13. Kirchartz, T., Márquez, J. A., Stolterfoht, M. & Unold, T. Photoluminescence-based characterization of halide perovskites for photovoltaics. _Adv. Energy Mater._ **10** , 1904134 (2020). 

14. Yuan, Y., Yan, G. H., Hong, R. J., Liang, Z. C. & Kirchartz, T. Quantifying efficiency limitations in all-inorganic halide perovskite solar cells. _Adv. Mater._ **34** , 2108132 (2022). 

15. Krückemeier, L., Krogmeier, B., Liu, Z., Rau, U. & Kirchartz, T. Understanding transient photoluminescence in halide perovskite layer stacks and solar cells. _Adv. Energy Mater._ **11** , 2003489 (2021). 

16. Krückemeier, L., Liu, Z., Krogmeier, B., Rau, U. & Kirchartz, T. Consistent interpretation of electrical and optical transients in halide perovskite layers and solar cells. _Adv. Energy Mater._ **11** , 2102290 (2021). 

17. Peña-Camargo, F. et al. Revealing the doping density in perovskite solar cells and its impact on device performance. _Appl. Phys. Rev._ **9** , 021409 (2022). 

18. Shockley, W. & Read, W. T. Statistics of the recombinations of holes and electrons. _Phys. Rev._ **87** , 835–842 (1952). 

19. Hall, R. N. Electron-hole recombination in germanium. _Phys. Rev._ **87** , 387–387 (1952). 

20. Simmons, J. G. & Taylor, G. W. Nonequilibrium steadystate statistics and associated effects for insulators and semiconductors containing an arbitrary distribution of traps. _Phys. Rev. B_ **4** , 502–511 (1971). 

21. Macdonald, D. & Cuevas, A. Understanding carrier trapping in multicrystalline silicon. _Sol. Energy Mater. Sol. Cells_ **65** , 509–516 (2001). 

22. Macdonald, D. & Cuevas, A. Trapping of minority carriers in multicrystalline silicon. _Appl. Phys. Lett._ **74** , 1710–1712 (1999). 

23. Hages, C. J. et al. Identifying the real minority carrier lifetime in nonideal semiconductors: a case study of kesterite materials. _Adv. Energy Mater._ **7** , 1700167 (2017). 

24. Stolterfoht, M. et al. How to quantify the efficiency potential of neat perovskite films: perovskite semiconductors with an implied efficiency exceeding 28%. _Adv. Mater._ **32** , 2000080 (2020). 

25. Rauh, D., Deibel, C. & Dyakonov, V. Charge density dependent nongeminate recombination in organic bulk heterojunction solar cells. _Adv. Funct. Mater._ **22** , 3371–3377 (2012). 

26. Maurano, A. et al. Recombination dynamics as a key determinant of open circuit voltage in organic bulk heterojunction solar cells: a comparison of four different donor polymers. _Adv. Mater._ **22** , 4987–4992 (2010). 

27. Liu, J. et al. Efficient and stable perovskite-silicon tandem solar cells through contact displacement by MgF _x_ . _Science_ **377** , 302–306 (2022). 

28. Menzel, D. et al. Field effect passivation in perovskite solar cells by a LiF interlayer. _Adv. Energy Mater_ . **12,** 2201109 (2022). 

29. Warby, J. et al. Understanding performance limiting interfacial recombination in _pin_ perovskite solar cells. _Adv. Energy Mater._ **12** , 2103567 (2022). 

30. Stolterfoht, M. et al. Visualization and suppression of interfacial recombination for high-efficiency large-area pin perovskite solar cells. _Nat. Energy_ **3** , 847–854 (2018). 

31. Siekmann, J. et al. Characterizing the influence of charge extraction layers on the performance of triple-cation perovskite solar cells. _Adv. Energy Mater_ . **13** , 2300448 (2023). 

32. Krogmeier, B., Staub, F., Grabowski, D., Rau, U. & Kirchartz, T. Quantitative analysis of the transient photoluminescence of CH3NH3PbI3/PC61BM heterojunctions by numerical simulations. _Sustain. Energy Fuels_ **2** , 1027–1034 (2018). 

33. Liu, Z., Siekmann, J., Klingebiel, B., Rau, U. & Kirchartz, T. Interface optimization via fullerene blends enables open-circuit voltages of 1.35 V in CH3NH3Pb(I0.8Br0.2)3 solar cells. _Adv. Energy Mater._ **11** , 2003386 (2021). 

34. Yang, G. et al. Stable and low-photovoltage-loss perovskite solar cells by multifunctional passivation. _Nat. Photon._ **15** , 681–689 (2021). 

35. Staub, F. et al. Beyond bulk lifetimes: insights into lead halide perovskite films from time-resolved photoluminescence. _Phys. Rev. Appl._ **6** , 044017 (2016). 

36. Crothers, T. W. et al. Photon reabsorption masks intrinsic bimolecular charge-carrier recombination in CH3NH3PbI3 perovskite. _Nano Lett._ **17** , 5782–5789 (2017). 

37. Braly, I. L. et al. Hybrid perovskite films approaching the radiative limit with over 90% photoluminescence quantum efficiency. _Nat. Photon._ **12** , 355–361 (2018). 

38. Richter, J. M. et al. Enhancing photoluminescence yields in lead halide perovskites by photon recycling and light out-coupling. _Nat. Commun._ **7** , 13941 (2016). 

39. Staub, F., Kirchartz, T., Bittkau, K. & Rau, U. Manipulating the net radiative recombination rate in lead halide perovskite films by modification of light outcoupling. _J. Phys. Chem. Lett._ **8** , 5084–5090 (2017). 

40. Zhang, X., Shen, J.-X., Wang, W. & Van de Walle, C. G. Firstprinciples analysis of radiative recombination in lead-halide perovskites. _ACS Energy Lett._ **3** , 2329–2334 (2018). 

41. Simbula, A. et al. Direct measurement of radiative decay rates in metal halide perovskites. _Energy Environ. Sci._ **15** , 1211–1221 (2022). 

Nature Materials | Volume 23 | March 2024 | 391–397 

**396** 

**Article** 

https://doi.org/10.1038/s41563-023-01771-2 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this 

article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons. org/licenses/by/4.0/. 

© The Author(s) 2024 

Nature Materials | Volume 23 | March 2024 | 391–397 

**397** 

**Article** 

https://doi.org/10.1038/s41563-023-01771-2 

#### **Methods** 

###### **Materials** 

Methylammonium iodide, methylammonium chloride, formamidinium iodide and OAI were purchased from Greatcell Solar. Caesium iodide (CsI, 99.9%) was purchased from Alfa Aesar. Lead(II) iodide (PbI2, 99.99%), Me-4PACz (>99.0%) and BCP (>99.0%) were purchased from TCI. Lead bromide (PbBr2, 99.999%), caesium bromide (CsBr, 99.999%), anisole (99.7%), _N_ , _N_ -dimethylformamide (DMF, 99.8%), dimethyl sulfoxide (DMSO, ≥99.9%), isopropyl alcohol (IPA, 99.5%), chlorobenzene (99.8%) and poly(methyl methacrylate) (PMMA, weight-averaged molecular mass _M_ w ≈ 120,000 by gel permeation chromatography (GPC)) were purchased from Sigma-Aldrich. Ethyl alcohol (EtOH, maximum 0.003% water) and acetone were purchased from VWR Chemicals. C60 was purchased from Lumtec. All chemicals were used as received. GaAs (intrinsic, 350 µm thick) wafers were purchased from Suzhou Jingguikeji Company. 

###### **Device fabrication** 

Patterned ITO glasses (Kinetic, 2.0 × 2.0 cm<sup>2</sup> ) were used as substrates and ultrasonically cleaned with soap solution (Seife Hellmanex III, 2%, 50 °C, 20 min), acetone (20 °C, 20 min) and IPA (20 °C, 20 min), one by one. The substrates were further cleaned by oxygen plasma (Diener Zepto, 50 W, 13.56 MHz, 10 min) and then transferred into a N2-filled glove box to await use. The Me-4PACz powder was dissolved by EtOH solvent with a concentration of 1 mmol l<sup>–1</sup> . After it was completely dissolved, the solution was spin-coated on the substrates at 3,000 r.p.m. for 25 s (acceleration time, 4 s) and then annealed at 100 °C for 10 min. For the perovskite solution, 1.2 M Cs0.05FA0.73MA0.22PbI2.56Br0.44 triple-cation perovskite precursor solution was prepared by mixing CsI (0.06 M), methylammonium (MA) iodide (0.264 M), formamidinium (FA) iodide (0.876 M), PbBr2 (0.264 M) and PbI2 (0.936 M) solutes in DMF/DMSO (3:1 volume ratio) solvent. Then PMMA (∼0.06 mg ml<sup>–1</sup> ) was added to the solution. The precursor solution was stirred at 75 °C until fully dissolved, and then filtered with a polytetrafluoroethylene filter (0.45 µm). Some 180 µl solution was dropped onto the Me-4PACz layer and spin-coated at 4,000 r.p.m. for 15 s (acceleration time, 5 s) and 6,000 r.p.m. for 40 s (acceleration time, 5 s). Some 300 µl anisole was dripped onto the film as an antisolvent 20 s before the end of the spin process. The films were immediately annealed at 100 °C for 20 min. For the OAI-modified sample, 100 µl OAI/IPA solutions (with concentrations of 1, 1.5, 2 and 2.5 mg ml<sup>–1</sup> ) were each dynamically spin-coated on a perovskite layer at 5,000 r.p.m. for around 30 s, and then annealed at 100 °C for 5 min. The as-prepared films were covered by C60 (25 nm) and BCP (8 nm) layers by thermal evaporation at a rate of 0.1 Å s<sup>–1</sup> . Finally, 80 nm of silver was thermally evaporated on the film with a mask. All of the solution preparation and film preparation was performed in a N2-filled glove box and attached thermal evaporation system. The active cell area (0.06 and 0.16 cm<sup>2</sup> ) is the intersection of the silver and patterned ITO. 

sample, measured under identical conditions. Work functions were determined from the spectra by measuring the position of the cut-off at high binding energies using linear fits at the background and the steep edge. The same method was applied to the leading edge of the UPS spectra to determine the valence band position for the HTL and ETL. For the control and OAI-treated perovskite films, the valence band onset was plotted on a logarithmic scale and was determined by using exponential fitting. 

###### **Device characterizations** 

The current–voltage curves were measured by a calibrated air mass 1.5 (AM1.5) spectrum of a class AAA solar simulator (WACOM-WXS-140S-Super-L2 with a combined xenon/halogen lamp-based system) using a crystalline silicon cell as a reference and providing a power density of 100 mW cm<sup>–2</sup> . The reference cell was certified by the photovoltaic calibration laboratory at the Fraunhofer ISE, Germany, and the spectral mismatch factor is ∼0.98. For both forward and reverse scans, the scan speed was about 76 mV s<sup>–1</sup> with a measurement time of around 17 s. All the samples were kept uniformly under the light for 5 s before scanning without any other preconditioning. Additionally, a white light light-emitting diode (LED; Cree XLamp CXA3050) was also used as light source. The light intensity of the LED was adjusted to the one sun condition using the short-circuit current resulting from the solar simulator measurement of a perovskite solar cell. A 2450 Keithley was used as a source measure unit. All measurements were carried out under inert atmosphere in a glove box. We did not use a mask for the measurements, as it would lead to erroneous _V_ oc and fill factor FF values with masking, though the determination of short-circuit current density _J_ sc can be more accurate<sup>42</sup> . To solve the _J_ sc issue, we consider that validating the _J_ sc with the external quantum efficiency results is a good choice. For our samples, they matched well with each other. 

For the external quantum efficiency measurement, a set-up with a xenon light source (Osram XPO 150 W) and a Bentham monochromator (TMC 300) was used. A photodiode (Gigahertz Optik SSO-PD 100-04) was used to calibrate the light source. The cells were mounted inside a sealed, nitrogen-filled sample box with a quartz cover glass. The raw data of external quantum efficiency and integrated _J_ sc have been corrected by subtracting the reflectance of the cover glass. 

Fourier-transform photocurrent spectroscopy measurements were carried out using a Fourier-transform infrared spectrometer (Bruker Vertex 80v) equipped with a halogen lamp. A low-noise current amplifier (Femto DLPCA-200) was used to amplify the photocurrent generated upon illumination of the solar cell devices with light modulated by the Fourier-transform infrared spectrometer. We used a mirror speed of 2.5 kHz and a resolution of 12 cm<sup>−1</sup> . Measurements with different filters were combined to get a spectrum with a higher dynamic range of the bandgap. 

###### **Sample preparation for PL measurement** 

###### **Material characterizations** 

The surface morphologies of the perovskite films were characterized by scanning electron microscope (Zeiss LEO 1550VP). Absorptance spectra of the film samples were measured by an ultraviolet–visible–near-infrared spectrometer (PerkinElmer Lambda 950). The thickness of perovskite films was measured by a step profiler (Veeco Dektak 6M). Ultraviolet photoelectron spectroscopy (UPS) measurements were carried out for each layer to investigate the energy level alignment. The UPS system is a Multiprobe MXPS system from Scienta Omicron with an ARGUS hemispherical electron spectrometer and is part of the JOSEPH cluster system at the research center in Jülich. The base pressure in the system is 3 × 10<sup>−11</sup> mbar. The light source for UPS measurement is a HIS13 He I gas discharge VUV source from FOCUS (main line He Iα, 21.22 eV). The binding energy scale is referenced to the Fermi edge measured on a freshly evaporated gold 

We prepared five types of sample for PL measurement, that is, perovskite film, film/C60, Me-4PACz/film, Me-4PACz/film/C60 and the full device. Unless otherwise noted, the OAI-modified perovskite samples were prepared using 2 mg ml<sup>–1</sup> OAI/IPA solution. Perovskite film and film/C60 samples were prepared on quartz glass substrates. In order to reduce the defect density of the glass/perovskite interface, we prepared PMMA film on the glass before perovskite preparation. To be specific, 20 mg ml<sup>–1</sup> PMMA was dissolved in chlorobenzene solvent and then spin-coated on the quartz glass at 3,000 r.p.m. for 25 s, followed by annealing at 100 °C for 10 min. Other types of stacks were prepared on ITO and have the same preparation parameters as devices described previously. 

Apart from the triple-cation perovskite, we also performed transient PL measurement for Cs0.05FA0.95PbI3 and CsPbBr3 films, as well as GaAs wafer. The GaAs wafer was purchased from a company 

Nature Materials 

**Article** 

https://doi.org/10.1038/s41563-023-01771-2 

without any treatment. The CsPbBr3 precursor was prepared by adding 0.35 M CsBr and 0.35 M PbBr2 into DMSO solution. After fully dissolving it at 70 °C, 100 µl solution was dropped on the bare glass and spin-coated at 4,000 r.p.m. for 1 min, followed by annealing at 100 °C for 10 min. As for Cs0.05FA0.95PbI3, the precursor was mixed together with formamidinium iodide (1.71 M), PbI2(1.8 M) and CsI (0.09 M) powders and then dissolved in DMF/DMSO (8:1 v/v). To facilitate crystallinity, we added an extra 5% PbI2 and 30% methylammonium chloride (molar ratio) into the solution. The perovskite layer was prepared by spin-coating with ∼100 µl precursor at 1,000 r.p.m. (10 s) and 5,000 r.p.m. (30 s). Some 200 µl chlorobenzene was used as antisolvent and dropped onto the film at 10 seconds prior to the end. The film was annealed at 100 °C for 30 minutes. All processes were performed in the glove box. 

###### **The tr-PL measurement** 

The tr-PL decay was measured using time-correlated single-photon counting and gated CCD recording, separately. For the time-correlated single-photon counting set-up, a 630 nm laser with a pulse width of 96 ps was used. The laser spot size was 50 µm in diameter, and the laser pulse repetition rate applied was 25 kHz and 50 kHz. The time resolution of the system was approximately 2 ns. To vary the laser intensity hitting the sample, filters with different OD values were used. The applied excitation fluences using 2.6 OD, 2 OD, 1 OD and 0 OD filters were 2.00, 7.97, 79.65 and 796.54 nJ cm<sup>–2</sup> , respectively. The whole system was placed in a black box to protect the signal from ambient light. 

Regarding to gated CCD recording, a pulsed UV–solid-state laser was used as an excitation source, which served as a pump laser for the dye laser. The set-up parameters followed the following description unless otherwise noted. The pumped dye (Coumarin) used in the tr-PL set-up emitted a down-converted, pulsed laser radiation of 512 nm. The repetition rate was 100 Hz. This radiation passed through an optical fibre and impinged at an angle of 30° on the sample surface, illuminating an elliptically shaped spot with a diameter 3.07 mm on the samples. The applied excitation fluence was around 2.83 µJ cm<sup>–2</sup> , making the corresponding initial carrier concentration and Δ _E_ F values 1.46 × 10<sup>17</sup> cm<sup>−3</sup> and 1.48 eV, respectively. The PL signal emitted by the samples was focused and coupled into the spectrometer (SPEX 270M from Horiba Jobin Yvon). An intensified CCD camera (iStar DH720 from Andor Solis) was used to detect the spectrally dispersed signals. To get a time resolution, we exploited the inherent shutter functionality of our intensified CCD camera and a signal of the laser as a trigger. By changing the decay time between the trigger signal and an acquisition of a spectrum, the PL can be measured at different times after the excitation pulse. 

For both methods, the samples were mounted inside a sealed, nitrogen-filled sample box. To analyse the data, we first subtracted the background and then normalized the data, as well as shifting the peak to position zero. Detailed instructions can be found in ref. 15. 

###### **Steady-state PL measurement and Quasi-Fermi-level splitting calculation** 

The samples were optically excited by a continuous wave 532 nm laser (Coherent Sapphire). The laser beam was widened to a square of about 5.3 mm × 5.3 mm to illuminate the entire cell area (4 mm × 4 mm). The luminescence spectra were detected via a spectrometer (Andor Shamrock 303) with an Andor Si (deep depletion) CCD camera (iDus Series). The laser power was 17.3 mW. PL measurements were performed for different laser intensities impinging on the sample by using different OD filters. During the measurements, dark spectra were taken following each illuminated measurement to subtract the background. 

The quasi-Fermi-level splitting of layer-stack samples was acquired from steady-state PL data. With the open-circuit voltage _V_ oc and 

corresponding PL intensity _ϕ_ PL,cell at the 1 sun condition ( _V_ oc( _ϕ_ sun) and _ϕ_ PL,cell( _ϕ_ sun), respectively) of the control device as a reference, the Δ _E_ F of layer-stack samples was calculated by 



<!-- Start of picture text -->
Δ E F =  qV oc ( ϕ sun) +  k B T  ln ( ϕ PL,cell ϕ ( ϕ PLsun/ ∫)/ ∫ AϕQ BB EQE d Eϕ BBd E )<br><!-- End of picture text -->

where _ϕ_ PL, _A_ , _E_ and _Q_<sup>EQE</sup> are the PL intensity of the sample, absorptance of the films, energy and external quantum efficiency of the cells, respectively. _ϕ_ BB is the spectral black-body radiation as shown in 



<!-- Start of picture text -->
ϕ BB( E  ) = 2π E 2 1<br>h 3 c 2 exp [ E /( k B T  )] − 1<br><!-- End of picture text -->

where _k_ B, _T_ , _h_ and _c_ are Boltzmann’s constant, the temperature, Planck’s constant and light speed in a vacuum, respectively. 

###### **PL quantum yield calculation** 

The PL quantum yield ( _Q_<sup>lum</sup> e<sup>) values of devices were calculated from</sup> 



<!-- Start of picture text -->
q  ( V oc rad − V oc ) = − k B T  ln ( Q e lum )<br><!-- End of picture text -->

where _V_ oc<sup>rad is the radiative open-circuit voltage limit. It can be calculated</sup> using the approach described in ref. 43. 

###### **Numerical simulation** 

Band diagrams of devices were simulated using SCAPS software based on the UPS measurement results. The tr-PL and steady-state PL simulations were performed with self-developed MATLAB scripts based on the coupled rate equations (Supplementary Note 6). 

###### **Reporting summary** 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

#### **Data availability** 

The data used in the paper are available at https://zenodo.org/ records/10101259. Source data are provided with this paper. 

#### **Code availability** 

The codes used for the simulation of this study can be accessed at https://zenodo.org/records/10101259. 

#### **References** 

42. Kiermasch, D., Gil-Escrig, L., Bolink, H. J. & Tvingstedt, K. Effects of masking on open-circuit voltage and fill factor in solar cells. _Joule_ **3** , 16–26 (2019). 

43. Krückemeier, L., Rau, U., Stolterfoht, M. & Kirchartz, T. How to report record open-circuit voltages in lead-halide perovskite solar cells. _Adv. Energy Mater._ **10** , 1902573 (2020). 

#### **Acknowledgements** 

We acknowledge funding by the Helmholtz Association via POF IV funding (U.R. and T.K.), via the innovation platform ‘SolarTAP – A Solar Technology Acceleration Platform’ (U.R.), via the project ‘Beschleunigter Transfer der nächsten Generation von Solarzellen in die Massenfertigung - Zukunftstechnologie Tandem‐ Solarzellen’ (T.K.) and via the Helmholtz.AI project AISPA, AI-driven instantaneous solar cell property analysis (T.K.), as well as by the Deutsche Forschungsgemeinschaft (German Research Foundation) via the project ‘Correlating Defect Densities with Recombination Losses in Halide-Perovskite Solar Cells’ (T.K.). Y.Y., G.Y. and J.Y. acknowledge the financial support by the China and Germany Postdoctoral Exchange Program. 

Nature Materials 

**Article** 

https://doi.org/10.1038/s41563-023-01771-2 

#### **Author contributions** 

Y.Y., G.Y. and T.K. conceived the idea. Y.Y., G.Y. and J.Y. fabricated the perovskite-based samples and performed the photovoltaic performance characterizations. M.H. built the steady-state and transient PL measurement set-ups. G.Y. and C.D. performed the PL characterizations. B.K. carried out the UPS characterization and analysed the results. T.K. wrote the codes for the simulations. T.R. conducted the grid search for the simulated parameters. T.K., Y.Y. and G.Y. wrote the manuscript. C.D. and U.R. improved the manuscript. U.R. derived the new equations in Supplementary Note 1. T.K. supervised the project. All authors discussed the results and commented on the paper. 

#### **Competing interests** 

The authors declare no competing interests. 

#### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41563-023-01771-2. 

**Correspondence and requests for materials** should be addressed to Genghua Yan or Thomas Kirchartz. 

**Peer review information** _Nature Materials_ thanks Igal Levine and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. 

#### **Funding** 

Open access funding provided by Forschungszentrum Jülich GmbH. 

**Reprints and permissions information** is available at www.nature.com/reprints. 

Nature Materials 

Corresponding author(s): Genghua Yan, Thomas Kirchartz 



## <u>Solar Cells Reporting Summary</u> 

Nature Research wishes to improve the reproducibility of the work that we publish. This form is intended for publication with all accepted papers reporting the characterization of photovoltaic devices and provides structure for consistency and transparency in reporting. Some list items might not apply to an individual manuscript, but all fields must be completed for clarity. 

For further information on Nature Research policies, including our data availability policy, see Authors & Referees. 

### � Experimental design 

##### **Please check: are the following details reported in the manuscript?** 

1.   Dimensions 

|Area of the tested solar cells|Yes<br>No|in Fig.4, in the Methods section and in Section 4 of the Supplementary Information|
|---|---|---|
||Yes|in the Methods section|
|Method used to determine the device area|No||
|2.   Current-voltage characterization<br>Current density-voltage (J-V) plots in both forward|Yes|in the Supplementary Fig.38|
|and backward direction|No||
|Voltage scan conditions|Yes|in the Methods section|
|_For instance: scan direction, speed, dwell times_|No||
|Test environment|Yes|in the Methods section|
|_For instance: characterization temperature, in air or in glove box_|No||
|Protocol for preconditioning of the device before its|Yes|in the Methods section|
|characterization|No||
|Stability of the J-V characteristic|Yes|in the Supplementary Fig.39|
|_Verified with time evolution of the maximum power point or with_<br>_the photocurrent at maximum power point; seeref. 7 for details._|No||
|3.   Hysteresis or any other unusual behaviour<br>Description of the unusual behaviour observed during|Yes|in Section 4 of the Supplementary Information|
|the characterization|No||
||Yes|in Supplementary Fig.38|
|Related experimental data<br>4.   Efficiency|No||
|External quantum efficiency (EQE) or incident|Yes|in Section 4 of the Supplementary Information|
|photons to current efficiency (IPCE)|No||
|A comparison between the integrated response under|Yes|EQE integrated Jsc in Supplementary Fig.34 and simulator measured Jsc in Fig.4 and|
|the standard reference spectrum and the response|No|in Supplementary Fig.35, 36 and 38.|
|measure under the simulator|||
|For tandem solar cells, the bias illumination and bias|Yes|We don't have tandem cells.|
|voltage used for each subcell|No||
|5.   Calibration|||
|Light source and reference cell or sensor used for the|Yes|in the Methods section|
|characterization|No||
|Confirmation that the reference cell was calibrated|Yes|in the Methods section. The reference cell was certified by the Fraunhofer ISE,|
|and certified|No|Germany.|



1 

|Calculation of spectral mismatch between the|Yes|in the Methods section. The mismatch factor is ~0.98.|
|---|---|---|
|reference cell and the devices under test|No||
|6.   Mask/aperture|||
|Size of the mask/aperture used during testing|Yes<br>No|We didn't use mask during testing. It will lead to erroneous Voc and FF with masking<br>though the determination of Jsc can be more accurate(Kiermasch et al. Joule 2019,<br>3(1): 16-26). So we consider that validating the Jsc with the EQE results and acquiring<br>the correct Voc and FF without a mask is the best option.|
|Variation of the measured short-circuit current<br>density with the mask/aperture area|Yes<br>No|We didn't use mask during testing. But we varied the active area of the device and<br>acquired the Jsc (shown in Fig.4 and Supplementary Fig.38)|
|7.   Performance certification|||
|Identity of the independent certification laboratory<br>that confirmed the photovoltaic performance|Yes<br>No|As we focus on studying the PL related physical mechanism in this work, we have not<br>certified the efficiency value. We use a AAA class solar simulator for the efficiency<br>measurement.|
|A copy of any certificate(s)|Yes|No certificates.|
|_Provide in Supplementary Information_|No||
|8.   Statistics|||
||Yes|in the Supplementary Fig.35|
|Number of solar cells tested|No||
||Yes|in  the Supplementary Fig.35|
|Statistical analysis of the device performance|No||
|9.   Long-term stability analysis|||
|Type of analysis, bias conditions and environmental<br>conditions|Yes<br>No|As we focus on studying the PL related physical mechanism in this work, we have not<br>measured the long-term stability.|
|_For instance: illumination type, temperature, atmosphere_|||
|_humidity, encapsulation method, preconditioning temperature_|||



2 

