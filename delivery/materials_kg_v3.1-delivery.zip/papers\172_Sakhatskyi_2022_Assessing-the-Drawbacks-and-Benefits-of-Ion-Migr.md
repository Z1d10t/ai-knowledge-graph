# Assessing the Drawbacks and Benefits of Ion Migration in Lead Halide Perovskites

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | ACS Energy Letters |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 174 |
| 作者 | Kostiantyn Sakhatskyi, R. John, Antonio Guerrero, Sergey A. Tsarev, Sebastian Sabisch, Tisita Das, G. Matt, S. Yakunin et al. |
| DOI | 10.1021/acsenergylett.2c01663 |
| 源文件 | 072_Sakhatskyi_2022_Assessing-the-Drawbacks-and-Benefits-of-Ion-Migr.pdf |

---














http://pubs.acs.org/journal/aelccp 

## **Assessing the Drawbacks and Benefits of Ion Migration in Lead Halide Perovskites** 

Kostiantyn Sakhatskyi,<sup>#</sup> Rohit Abraham John,*<sup>,#</sup> Antonio Guerrero,<sup>#</sup> Sergey Tsarev,<sup>#</sup> Sebastian Sabisch, Tisita Das, Gebhard J. Matt, Sergii Yakunin, Ihor Cherniukh, Martin Kotyrba, Yuliia Berezovska, Maryna I. Bodnarchuk, Sudip Chakraborty, Juan Bisquert, and Maksym V. Kovalenko* 

**Cite This:** _ACS Energy Lett._ 2022, 7, 3401−3414 

###### **Read Online** 

### ACCESS 



<!-- Start of picture text -->
Metrics & More Article Recommendations * sı Supporting Information<br><!-- End of picture text -->

ABSTRACT: Since the inception of the unprecedented rise of halide perovskites for photovoltaic research, ion migration has shadowed this material class with undesirable hysteresis and degradation effects, limiting its practical implementations. Unfortunately, the localized doping and electrochemical reactions triggered by ion migration cause many more undesirable effects that are often unreported or misinterpreted because they deviate from classical semiconductor behavior. In this Perspective, we provide a concise overview of such effects in halide perovskites, such as operational instability in photovoltaics, polarization-induced abnormal external quantum efficiency in light-emitting diodes, and energy channel shift and anomalous sensitivities in hard radiation detection. Finally, we highlight a unique use case of exploiting ion migration as a boon to design emerging memory technologies such as memristors for information storage and computing. 

alide perovskites have been a hot topic of research in the photovoltaic area for the past decade because of H the rapid increase in power-conversion efficiency exceeding 20%<sup>1,2</sup> and their simple solution-based processability. Since their discovery as efficient light absorbers, hysteresis in the current−voltage curves has been observed and described. In comparison to ferroelectricity and electronic charge carrier trapping, the phenomenon of ion migration has received widespread validity as a causal factor for hysteretic behavior in optoelectronic responses, unstable transient behavior, and device degradation.<sup>3,4</sup> Careful spectroscopy studies, electrical parameter analyses, device modeling, and microscopic simulations have unravelled a large body of evidence to support the hypothesis of ion migration.<sup>5−12</sup> 

In this Perspective, we discuss the obstacles as well as the opportunities provided by ion migration in halide perovskites. In contrast to conventional semiconductors with rigid covalent bonding like Si, Ge, and CdTe, metal halide perovskite compounds possess a much softer crystal structure that allows migration of structural defects under low activation energy, such as temperature, photoexcitation, and an external electrical field.<sup>13</sup> This structural instability adversely affects the functioning of optoelectronic devices, specifically those operating under an external bias voltage. Examples of undesirable effects include strong electrical polarization, quenching of charge collection efficiency with time for photon detectors, high dark currents, poor radiation sensitivity, etc. 

However, while ion migration causes instability issues and inaccurate parameter extraction in photodetectors, lightemitting diodes, and hard radiation detectors, it acts as a boon to design novel devices such as memristors and switchable diodes (Figure 1). For example, in memristors, the dynamics and kinetics of ion migration can be utilized to tune the memory window to dawn several functionalities pertinent for information storage and in-memory computing. Hence, in the sections below, we highlight both the pros and cons of this mixed ionic-electronic conductivity in halide perovskites. We also discuss the design principles for each of these technologies with insights on how to mitigate/exploit ion migration. 

# ■<sup>**WHATMOVESINHALIDEPEROVSKITES?**</sup> 

Ionic transport is a process of hopping between equilibrium sites of the ions that occupy interstitials, defects, or hopping of the defects. Ionic transport is used in different electrochemical and electrooptic devices, such as lithium intercalation and 



Received: July 21, 2022 Accepted: September 1, 2022 Published: September 24, 2022 

© 2022 The Authors. Published by American Chemical Society 

https://doi.org/10.1021/acsenergylett.2c01663 _ACS Energy Lett._ 2022, 7, 3401−3414 

**3401** 

**<u>ACS Energy Letters</u>** 

**<mark>http://pubs.acs.org/journal/aelccp</mark>** 

<mark>Perspective</mark> 



Figure 1. Ion migration mechanism in metal halide perovskites and its influence on different application fields. Inside the ellipse is shown the schematic of typical perovskite-based optoelectronic devices with the halide perovskite layer sandwiched between two electrodes. Among the mobile ionic species, two major migration mechanisms have been identified: (1) metal ion (white sphere, M<sup>+</sup> ) migration from the electrode via the perovskite structure through a metal ion vacancy (white open circle, VM−) and (2) halide ion (black sphere, I<sup>∓</sup> ) migration through halide ion vacancies (black open circle, VI+). Blue spheres represent stable ions in the perovskite structure which do not contribute significantly to migration. Arrows point to different application fields with the major influenced parameter inside arrows (e.g., charge collection efficiency (CCE) for photodetectors, power conversion efficiency (PCE) for solar cells, memory window for memristors, and external quantum efficiency (EQE) for lightemitting diodes (LEDs)). 

   - illumination, or high temperatures, these ions can reach the external electrodes. Hence, a large polarization represented by a surface capacitance can be observed. 

- (2) While normal semiconductors are usually described by a fixed n- or p-type doping level, the displacement of ions and defects changes the local doping in different parts of the devices. Under an applied voltage, illumination, or both, a new equilibrium of charge neutrality and surface polarization becomes established. Monitoring the energy diagram of the device hence becomes challenging. 

- (3) The previous effects assume that the conducting contacts are inert. But different effects can happen at the interface of the perovskite with a metal or organic conductor. 

   - (3a) The ions at the interface can launch electrochemical reactions that degrade the cell irreversibly.<sup>16</sup> 

   - (3b) The ions interfere with the electronic properties of the interface and change the device behavior, for example, adding recombination components. This effect usually leads to an inductive behavior, negative capacitance,<sup>17−20</sup> and inverted hysteresis characteristics. 

- (4) Illumination modifies the dynamics of ionic species and their interactions with their electronic counterparts.<sup>11</sup> A number of photoinduced effects occur such as high ionic conductivity of phase separations.<sup>21−25</sup> 

The migration of halide vacancies prevails compared to larger cations. However, at long operation times and under external driving forces such as voltage, light, and temperature, all of these different types of ions will move in the halide perovskite structure 

diffusion in Li-battery materials, and proton intercalation and transport in electrochromic WO3. 

In the case of ABX3 halide perovskites, the ions can easily diffuse across the net of corner sharing octahedra. The ionic transport becomes combined with the electronic transport (of electrons and holes) that happens naturally in the semiconductor. Hence, the material is a mixed ionic-electronic conductor, of the type that is common in solid-state electrochemistry.<sup>14</sup> Halide vacancies, organic cations, and metal electrode ions have been reported to diffuse through the perovskite material. In general, the migration kinetics of halide vacancies is favored with respect to larger cations in the perovskite formulation and metal contacts. However, during long operation times and under external driving forces such as voltage, light, and temperature, all of these different types of ions will move in the halide perovskite structure.<sup>12,15</sup> This property causes several effects and phenomena that become very relevant for the applications of halide perovskite materials. Those effects are listed below. 

- (1) As in all solid and liquid electrolytes, the ions can move in the bulk material but become blocked when they arrive at the electrodes of the device (Figure 2a). Under low-to-moderate stress conditions, the migrating ions stop at the HTL/ETL. However, under high-stress conditions such as a large applied bias voltage, 

# ■<sup>**INSTABILITYANDHYSTERESISIN**</sup> **PHOTOVOLTAICS/DETECTORS** 

Perovskite photovoltaic devices currently show marketable power conversion efficiencies (PCEs) with a record value of 25.7%<sup>27</sup> but still suffer in encompassing high stability with high PCE. Photovoltaic devices (and photodetectors) are typically fabricated in the configuration shown in Figure 2a in which the perovskite material is sandwiched between charge selective layers, with one contact selective to electrons (ETL) and the other selective to holes (HTL). Detailed analyses of their optoelectronic responses have revealed hysteresis, above bandgap photovoltage, switchable majority carrier concentration, etc., pointing toward ion migration.<sup>10</sup> Once the migrating ions reach the contacts, they lead to reversible and irreversible interactions that limit photocurrent extraction and trigger degradation pathways.<sup>16,28</sup> Despite remarkable progress in efficiency numbers, hysteresis is still present in recent stateof-the-art devices (Figure 2b) with PCEs above 22%.<sup>26</sup> 

Figure 2c displays the stability performance ( _T_ 80 values) reported for different perovskite formulations as a function of the ion diffusion coefficient ( _D_ ion), where _T_ 80 is the required time for 20% degradation of the initial PCE under 1 sun of 

**3402** 

https://doi.org/10.1021/acsenergylett.2c01663 _ACS Energy Lett._ 2022, 7, 3401−3414 

**<u>ACS Energy Letters</u>** 

**<mark>http://pubs.acs.org/journal/aelccp</mark>** 

<mark>Perspective</mark> 



Figure 2. Effects of ion migration in halide perovskite photovoltaics and detectors. (a) Photovoltaic and photodetector device configuration. (b) A recent high-efficiency perovskite quasi-2D photovoltaic device that shows hysteresis in the forward and reverse scans, reproduced with permission from ref 26. (c) Stability performance ( _T_ 80) under 1 sun illumination condition and maximum power point tracking (MPPT) of selected literature examples as a function of the expected ion diffusion coefficient ( _D_ ion). _T_ 80 and _D_ ion values have been extracted from the references shown in Supplementary Note 1 and Tables SI1 and 2. 

illumination at the maximum power point for cells with an initial PCE > 18% (see Supplementary Note 1 for further details). A vertical line shows _T_ 80 values for a single perovskite formulation with the estimated _D_ ion. For a given perovskite formulation, _T_ 80 has been improved from low stability (blue circles) to higher stability (black circles) by modification of the extraction layers, contacts, and encapsulants. In this approach, it is assumed that ions will reach the external perovskite interfaces, but under optimized contacts, they find nonreactive interfaces leading to hysteresis-free and highly stable devices. For example, _T_ 80 has been improved from a few hours to above 10 000 h for the MA0.1Cs0.05FA0.85Pb(I0.95Br0.05)3 formulation.<sup>29</sup> 

#### Once the migrating ions reach the contacts, the reversible and irreversible interactions that limit photocurrent extraction occur. 

A different approach to increasing the stability relies on the reduction of ion supply toward the interfaces by decreasing _D_ ion (mostly halogen vacancies) via tuning of the perovskite formulation. Indeed, the introduction of large cations decreases the dimensionality of the perovskite, reduces ion migration, 

and increases the device stability. Increased stability is observed when ion migration is suppressed with _D_ ion < 10<sup>−12</sup> cm<sup>2</sup> s<sup>−1</sup> , such as in low dimensional perovskites. The original perovskite formulation developed in 2009 was based on the small cation methylammonium (MA<sup>+</sup> ), MAPbI3, that enabled high PCEs but suffered from very high _D_ ion ∼10<sup>−8</sup> cm<sup>2</sup> s<sup>−1</sup> that activated several degradation pathways with _T_ 80 in the range of 5−12 h.<sup>30,31</sup> Higher efficiencies are obtained by the introduction of the larger formamidinium (FA<sup>+</sup> ) cation that reduces the bandgap of the perovskite and increases the photocurrent output. However, the phase stability of FAPbI3 is low, and the formulation needs to be balanced with smaller cations like Cs<sup>+</sup> and Br<sup>−</sup> anions leading to mixed formulations.<sup>31</sup> As a side effect, the use of the large FA<sup>+</sup> cation reduces the ion conductivity to values of _D_ ion of 10<sup>−8</sup> to 10<sup>−11</sup> cm<sup>2</sup> s<sup>−1</sup> , but this reduction is not sufficient to avoid interactions between migrating ions and contacts.<sup>32</sup> Hence, devices using mixed formulations also degrade within the first few hours of operation. On the other hand, incorporating very large cations such as guanidinium (GA<sup>+</sup> ), phenylethylammonium (PE<sup>+</sup> ), and butyl ammonium (BA<sup>+</sup> ) disrupts the 3D phase continuity dimensionally. Utilizing this strategy, the structure of perovskites can be tuned from pure 3D ( _n_ = ∞) to Ruddlesden−Popper (i.e., _n_ = 2 to _n_ = 5) to pure 2D ( _n_ = 1) phases.<sup>33</sup> Low dimensional perovskites show considerably 

**3403** 

https://doi.org/10.1021/acsenergylett.2c01663 _ACS Energy Lett._ 2022, 7, 3401−3414 

**<u>ACS Energy Letters</u>** 

**<mark>http://pubs.acs.org/journal/aelccp</mark>** 

<mark>Perspective</mark> 



Figure 3. Polarization in perovskite light-emitting diodes. (a) Band diagram and (b) current−voltage−luminance curves of perovskite LEDs with CsPbBr3 nanocrystals as an emitting layer. (c) Schematic of the pulse measurement protocol. (d) Normalized luminance and current efficiency of the CsPbBr3 LED versus time depending on the applied polarization. 

lower _D_ ion than 3D perovskites on the order of 10<sup>−12</sup> to 10<sup>−15</sup> cm<sup>2</sup> s<sup>−1</sup> and stabilities in the range of hundreds of hours, e.g., GA/MA formulations with _T_ 80 = 750 h.<sup>34</sup> But on the negative side, disruption of the 3D phases reduces the charge carrier mobility, and devices typically show inferior PCEs to those of their 3D counterparts. It is only recently that optimization of the formulations and deposition conditions has led to better control of grain boundaries, orientation, and contact optimization, resulting in PCEs > 22%.<sup>26,35</sup> The prospect to obtain highly stable devices with a further reduction in the PCE gap between 3D and 2D is very promising. In addition, the working mechanism and knowledge acquired in recent years with regard to solar cells can be extrapolated to other devices. For example, CsPbBr3 perovskites due to their low _D_ ion (10<sup>−12</sup> to 10<sup>−13</sup> cm<sup>2</sup> s<sup>−1</sup> ) are good candidates to be used as light-emitting diodes or hard radiation detectors, as described next. 

# ■<sup>**AMBIGUOUSPERFORMANCEASSESSMENTOF**</sup> **PEROVSKITE LIGHT-EMITTING DIODES** 

In perovskite light-emitting diodes (LEDs), the effects of ion migration are pronounced due to the comparatively large electric field magnitude across a very thin (∼30 nm in our case) emitter layer. A typical LED structure comprises perovskite nanocrystals sandwiched between two composite hole and electron injection layers<sup>36</sup> as shown in Figure 3a. The devices under test show current−voltage characteristics with a turn-on voltage of around 3 V and a maximum luminance of nearly 10 000 Cd m<sup>−2</sup> peaking at 514 nm (Figure 3b). However, during operation, halogen ions or vacancies migrate to the interfaces and may react with them reversibly or irreversibly.<sup>37</sup> The reactions of ions with charge transport 

layers may lead to a change in the levels of charge injection, altering the diode performance. Moreover, during continuous operation, the devices heat up,<sup>38</sup> which also leads to degradation or modification of the contacts with perovskite. Thus, the theoretical band alignment can be modified during the first few seconds of operation of the LED, which can potentially occur faster than the first measurement point during a typical IV sweep. 

The reactions of ions with charge transport layers may drastically alter the charge injection, and hence the diode performance. The band alignment might be modified faster than the first data point acquired during a typical IV sweep. 

To illustrate the detrimental effects of ion migration on the device stability and accurate extraction of benchmarking parameters, we compare the device characteristics and their real-time transients as a function of two measurement protocols. In the first protocol, we apply 0 V bias to the LEDs before the application of a pulsed voltage above the turnon level of the device, representing a nonpolarized condition. In the second protocol, the LED is subject to constant polarization below the turn-on level of the device. Subsequently, we apply periodical short voltage pulses above the LED turn-on level to monitor its performance (Figure 3c). We assume that these short voltage pulses of 200 ms every 20 s do not polarize the device. The results shown in Figure 3d 

**3404** 

https://doi.org/10.1021/acsenergylett.2c01663 _ACS Energy Lett._ 2022, 7, 3401−3414 

**<u>ACS Energy Letters</u>** 

**<mark>http://pubs.acs.org/journal/aelccp</mark>** 

<mark>Perspective</mark> 



Figure 4. Effects of ion migration on gamma and X-ray detectors. (a) Structure of a hard radiation detector based on a CsPbBr3 single crystal (SC) used in the experiments. (b) Evolution of gamma energy spectra recorded under irradiation of a Cs-137 gamma source at a temperature of 294 K (gray spectra) and 173 K (blue spectra) under a 30 V bias. (c) Time dependencies of peak position in the gamma spectra at b, for various temperatures. (d) Current density time traces were measured under modulated 50 kV X-ray irradiation at different temperatures during exposure (from 0 to 60 s on the time scale) at a 30 V bias. On top of the slow response is shown a fast 22 Hz modulation component (schematically zoomed-in on the top panel). (e) Normalized X-ray response depending on modulation frequency at different temperatures. (f) Comparison of temperature dependencies: the rise time and the decay time of X-ray ionic response and X-ray sensitivity. 

unfold a significant effect on the LED performance. Under the nonpolarizing testing protocol, the luminance and current efficiency continuously decrease with time in the absence of significant ion migration because of the intrinsically low _D_ ion of CsPbBr3 (Figure 2c). However, with the polarizing testing protocol, the luminance and current efficiency increase to reach a value almost 4 times higher compared to the nonpolarized condition. Interestingly, this change in the device performance does not correspond to any significant change in the emission peak position or shape, ruling out changes to the structure or trap concentration in the perovskite bulk (Supplementary Note 2, Figure S1). Hence, we attribute the increase in device efficiency to changes in the charge injection balance due to ion accumulation and modification of the interfacial band alignment. A similar conditioning phenomenon is observed in light-emitting electrochemical cells.<sup>39</sup> Moreover, we can completely remove the negative effects of operating under the nonpolarized conditions by switching to the polarized regime, supporting our theory of ion migrationinduced polarization further (Supplementary Note 2, Figure S2). 

It is also worthwhile to note that the pulse-based measurements presented in Figure 3d cannot be directly compared to the absolute values of current efficiency calculated from conventional DC sweep measurements because of the difference in polarization levels under both conditions. The polarization at each point of the scan influences the next point. Thus, during a DC IV sweep, the measured current will depend on both the voltage and the state of ions in the device. 

Depending on the duration of bias applied to the device at each point of the scan and the relaxation time between points, the measured parameters can differ substantially. On the other hand, pulse-based IV sweeps may be utilized to measure the initial nonpolarized state of the LEDs, which may be beneficial for reliable and reproducible device characterization. 

# ■<sup>**ENERGYCHANNELSHIFTANDANOMALOUS**</sup> **SENSITIVITIES IN HARD RADIATION DETECTION** 

Furthemore, ion migration is also observed in hard radiation detectors based on halide perovskites, as we demonstrate for the case of _γ_ and X-ray detection. Inorganic perovskite CsPbBr3 single crystals (SCs) can be utilized for _γ_ -ray detection with excellent energy resolution.<sup>40</sup> However, the operational stability for hard radiation response has not yet been a subject of an explicit study. Here, we show an energy channel shift of the gamma pulse height distribution spectra with time. It was recorded with CsPbBr3 SC, contacted with Au and Ga (Figure 4a), at a 30 V reverse bias under 662 keV _γ_ - ray irradiation from a<sup>137</sup> Cs radioactive source (Figure 4b). At room temperature, 294 K (RT), the spectrum almost merges with the noise level after 1200 s of measurement, indicating a substantial decrease of the charge collection efficiency in the CsPbBr3 detector, which is likely caused by electrical field screening, i.e., polarization of the perovskite due to migration of Br<sup>−</sup> ions toward the positively biased electrode. This hypothesis is supported by correlating temperature-dependent stability of the dark current and gamma spectra at a low 

**3405** 

https://doi.org/10.1021/acsenergylett.2c01663 _ACS Energy Lett._ 2022, 7, 3401−3414 

**<u>ACS Energy Letters</u>** 

**<mark>http://pubs.acs.org/journal/aelccp</mark>** 

<mark>Perspective</mark> 

temperature (Figures 4b,c, Supplementary Note 3, Figure S3). Observed at RT, the gamma spectra instability disappears already at 273 K and is not observed at lower temperatures down to 223 K (Figures 4b,c). This can be explained by a “freezing” of ionic movement as it is also observed on the dark current absolute value and its temporal behavior (Supplementary Note 3, Figure S3). The dark current is stable at 273 K, and its value is at least 8 times lower than at RT. Such a decrease in conductivity additionally supports the suppression of ionic movement. 

A substantial decrease of the charge collection efficiency might be caused by electrical field screening, i.e., polarization of the perovskite due to migration of Br<sup>−</sup> ions toward the positively biased electrode. 

Perovskite X-ray detectors are often reported to have extremely high X-ray sensitivities,<sup>41,42</sup> sometimes even exceeding the theoretical maximum of photocurrent based on the evaluation from incoming energy flux. One explanation of this fact arises from the presence of a high photoconductive gain under a strong external biasing field,<sup>43</sup> while another assumption considers the substantial contribution of ionic movement to X-ray photocurrent.<sup>44</sup> Notably, it is possible to decouple the contribution of ions and electronic charge carriers in the X-ray response using temperature-dependent photocurrent traces. For this, the same device based on CsPbBr3 SC (Figure 4a) was illuminated by a modulated X-ray irradiation (Figure 4d). The modulation depth of photocurrent traces (for 223 K temperature shown on the top part of Figure 4d) corresponds to the fast ( _i.e._ , electronic) component of the response (shown as an e−h response in Figure 4d), while the lower envelope of the trace corresponds to the result of a slow ( _i.e._ , ionic movement) component (shown as ion response in Figure 4d). The latter is especially prominent at low temperatures. Additional evidence of the large ion migration contribution to an X-ray generated photocurrent is its dependence on X-ray beam modulation frequency (Figure 4e). The X-ray photocurrent drops (more abrupt at low temperatures and smoother at RT) at frequencies higher than 10−20 Hz, reaching the saturation plateau, where response is mostly independent of frequency. Such behavior confirms the presence of two components in the photocurrent signal: a slow component (attributed to movement of ions) and a fast component (resulted from the movement of electron and holes). Cooling of the CsPbBr3 SC detector surprisingly leads to an increase of the ionic component contribution to the X- ray photocurrent from 50% at RT to ca. 90% at 173 K. Additionally, with a decreasing of temperature, the absolute value of X-ray sensitivity shoots up about 20 times, from 1730 _μ_ C/cm<sup>2</sup> Gyair at RT to 32 400 _μ_ C/cm<sup>2</sup> Gyair at 173 K (Figure 4f). However, such a giant sensitivity value does not have any real practical implication since it is achieved after the long X- ray exposure and leads to the noise enhancement due to the ionic movement. 

Decay and rise time parameters of the ionic component (in Figure 4d at times 0 and 60 s for the rise and the decay, respectively) become slower with cooling, as presented in Figure 4f. These time values are strongly influenced by 

temperature but are weakly dependent on parameters such as bias voltage, X-ray intensity, and irradiation time, indicating that the kinetic of the ionic component build-up has clear activation behavior. The slow-down and increase of the ionic component of photocurrent with cooling can be explained by suppression of thermal-activated recombination processes<sup>45</sup> � in this particular case, the recombination of a free halide to its vacancies. Such a recombination mechanism appears to be unique for metal halide perovskites due to the relatively “soft” structure of their lattice. Similar effects are also considered to be responsible for a so-called self-healing process<sup>46</sup> and the extra-long hard radiation damage stability demonstrated by metal halide perovskites. 

It is interesting to note the contrasting influence of temperature on ion migration in the cases of _γ_ -ray and X-ray irradiation. For _γ_ -ray detectors, ion migration gets quenched at low temperatures, while for X-ray detectors, the ionic contribution is enhanced. This can be attributed to the substantial difference in the irradiation flux in both cases (here, the X-ray flux is higher by about 6 orders of magnitude than the gamma-ray flux). Therefore, accumulation effects observed for the X-ray irradiation are suppressed and negligible for the _γ_ - ray case, and “freezing” of the ions exclusively helps to improve the stability of the perovskite _γ_ -ray response. 

Recent measurements of current transients and impedance spectroscopy in CsPbBr3 single crystals indicate the formation of several regimes of ionic space-charge-limited current (SCLC) associated with mechanisms similar to the Poole− Frenkel ionized-trap-assisted transport. The ionic-SCLC seems to be a dominant operational mode in these lead halide perovskites.<sup>47</sup> 

# ■<sup>**IONMIGRATIONASATOOLTODESIGN**</sup> **MEMRISTORS** 

In contrast to photodetectors and hard radiation detectors, memristors are a device technology that could reap benefits from the migration of ions. A memristor is a resistive device with an inherent memory effect, i.e., memristor = memory + resistor. Typically fashioned in a two-terminal structure, dynamic reconfiguration of the active switching matrix upon electrical stimulation leads to a change in the device’s resistance, which can be used to store data and also directly process information. This is of immediate pertinence to the hardware implementation of neural networks where memristors as synapses provide a promising non-von Neumann computing paradigm capable of intrinsically implementing parallel multiply accumulated operations via Ohm’s and Kirchhoff’s circuit laws. This enables analog in-memory computing with considerably enhanced speed and energy efficiency. 

Halide perovskites, as a material technology platform, provide a wide range of design options for memristive and neuromorphic devices, with a compositional space of >10<sup>6</sup> formulations that can be explored using solution-based simple processing.<sup>48−50</sup> These materials support a rich variety of switching physics including electrochemical metallization reactions with reactive electrodes,<sup>51,52</sup> valence change mechanisms via halide ion migration,<sup>49,50,53</sup> spin-dependent charge transport,<sup>54</sup> and multiferroicity,<sup>55</sup> making them relevant for a wide array of neuromorphic architectures.<sup>56,57</sup> 

However, this memristor material technology is presently challenged by incompetent endurance performance, which hinders its practical implementations. State-of-the-art halide 

**3406** 

https://doi.org/10.1021/acsenergylett.2c01663 _ACS Energy Lett._ 2022, 7, 3401−3414 

**<u>ACS Energy Letters</u>** 

**<mark>http://pubs.acs.org/journal/aelccp</mark>** 

<mark>Perspective</mark> 



Figure 5. Functional flavors of halide perovskite memristors. The local ion and defect concentration in halide perovskites, choice of interlayers, and the transient dynamics of ions and vacancies under applied bias can lead to different types of memristive switching, useful for information storage and computing. 

perovskite memristors depict an on−off ratio in the range of 10<sup>3</sup> to 10<sup>9</sup> , a retention ≥ 10<sup>4</sup> s, and a switching speed < 500 ns, but with a poor endurance of ∼10<sup>3</sup> cycles.<sup>51,53,57,58</sup> While very recent studies utilizing oxide capping layers have improved the endurance values up to 10<sup>6</sup> cycles,<sup>59−64</sup> the corresponding on− off ratios are <10<sup>3</sup> , and more importantly, the switching performance in such devices is an ensemble outcome of the oxide and halide perovskite layers. At the same time, the limits of the switching performance of pure HPs are still unknown. The highest reported endurance for pristine HP memristors with an on−off ratio ≥10<sup>3</sup> is 5655 cycles to the best of our knowledge.<sup>57</sup> Therefore, the inferior endurance performance of pristine halide perovskite memristors is an unsolved challenge today. 

Intuitively, if the motion of ions in halide perovskites can be controlled, this could result in multiple modulable resistance states and enhanced endurance performance (Supplementary Note 4). Dynamics of the defect formation and migration would in turn decide the functional flavor of the memristors: (I) threshold switch devices with volatile memory, (II) binary/ digital devices that can switch in a nonvolatile manner between 

only two resistance states, and (III) analog devices that can switch between multiple nonvolatile resistance states (Figure 5). The kinetics of ion migration would affect the benchmarking parameters, which include (1) the on−off ratio, the ratio between the low resistance state (LRS) and high resistance state (HRS) in the case of digital memristors; (2) dynamic range, the conductance range over which the nonvolatile states are spread across in the case of analog memristors; (3) retention, the duration for which the programmed bits remain stable; (4) endurance, the number of times a memory can be written/erased; and (5) switching speed. 

However, the extent to which ion migration contributes to memristive switching and how it affects the benchmarking parameters is still debatable and a matter of ongoing research. In implementations that rely on the migration of electrochemically active electrode species through the perovskite matrix to form conductive filaments (CFs), halide ions mostly act only as reducing agents. In such cases, a low defect formation energy could result in more available sites for redox reactions, resulting in easier CF formation and rupture and, 

**3407** 

https://doi.org/10.1021/acsenergylett.2c01663 _ACS Energy Lett._ 2022, 7, 3401−3414 

**<u>ACS Energy Letters</u>** 

**<mark>http://pubs.acs.org/journal/aelccp</mark>** 

<mark>Perspective</mark> 

hence, higher endurance and faster switching speed.<sup>57</sup> However, the large number of available redox sites could also lead to runaway reactions and the formation of very thick filaments that cannot be erased, precipitating poor on−off ratio and endurance performance. The activation energy for ion migration of both halide ions and electrochemically active electrode species could also play vital roles in determining the endurance performance of memristors. The low activation energy for ion migration could point to more congenial pathways for CF formation and rupture and hence result in higher endurance and faster switching speed. However, this could also result in multiple nonerasable thick filaments that adversely affect the on−off ratio and endurance performance. Recently, Lee et al.<sup>53</sup> performed a high-throughput screening of 696 compositions with four different crystal structures based on first-principles calculations to identify the optimal halide perovskite for memory applications. With stability, vacancy formation, and migration as the descriptors, dimer-Cs3Sb2I9 has been identified as the best option with an experimentally verified ultrafast switching speed of ∼20 ns. However, the retention and endurance were limited to 10<sup>3</sup> s and 500 cycles, respectively, limiting its viability for practical demonstrations. Parallelly, lower dimensional perovskites<sup>52,65</sup> and nanocrystals<sup>51,57</sup> with high barriers for ion migration have also emerged as promising candidates with higher endurance performance. Hence, it is clear that a trade-off is required among these descriptors to design the next generation of high-performance, robust halide perovskite memristors. 

However, the extent to which ion migration contributes to memristive switching and how it affects the benchmarking parameters is still debatable and a matter of ongoing research. 

Redesigning the structure of perovskites by doping with large-size cations to disrupt the lattice to accommodate for easier ion migration seems a viable strategy but has not been investigated to date. Density-functional theory (DFT) calculations point to doping with the oversized ethylenediammonium (en) dication as a promising strategy to efficiently create and rupture nanochannels of CFs within the perovskite matrix, with 1 order of magnitude lower activation energy for Ag<sup>+</sup> migration (Figure 6a,b). When en is incorporated into the 3D perovskite structure, massive B and X vacancies appear in the 3D [ABX3] framework, resulting in a less-connected 3D hollow structure with enhanced structural disorder and widened band gaps. This hollow shape, we believe, will provide conductive paths for the passage of electrochemically active electrode species, resulting in longlasting devices with a high on−off ratio. Our preliminary experimental results on 7% en-doped MAPI show unmatched performance with an on−off ratio > 10<sup>3</sup> , a retention of 10<sup>5</sup> s, and a record endurance of 1.2 × 10<sup>4</sup> cycles (double the existing record for pristine perovskite memristors of 5 × 10<sup>3</sup> cycles; Figures 6c−f). This validates the en-doping strategy as a means to realize the next generation of robust perovskite memristors. 

On the other side of the spectrum, exploiting the driftdiffusive migration-relaxation of halide ions as a means to create analog memristors seems a promising research 

#### The en-doping strategy might be the means to realize the next generation of robust perovskite memristors. 

direction<sup>66</sup> but has not been systematically investigated to date. Modulation of Schottky barriers at the transport layer interfaces in a charge extracting/solar cell or injecting/lightemitting diode configuration is the perceived hypothesis in such cases.<sup>67</sup> The selection of transport layers and contacts becomes crucial in such scenarios. Finally, the back diffusion or relaxation of ions under a diffusion gradient or built-in potential could also serve as a tool to create threshold switches and probabilistic neurons, entailing systematic attention in this direction. Recently, there has been good progress in the characterization and understanding of migration and reaction effects on hysteresis in perovskite memristors.<sup>68,69</sup> Further systematic investigations in this direction are expected to pave the way for robust memristor designs with halide perovskite as the active switching matrix. 

In short, the field of halide perovskite memristors is relatively new and provides a large space for exploratory and downstream research.<sup>56</sup> The ability to control the migration of ions becomes critical in order to realize robust memristors. The notion that bad photodetectors/LEDs can be good memristors is flawed because this does not guarantee high performance. The underlying physics is very different, and from our results, it becomes clear that materials and interfaces need to be tailored to get excellent device performance with high robustness. 

# ■<sup>**METHODS**</sup> 

**Light Emitting Diode (LED).** A slightly modified version of a published recipe<sup>36</sup> was used. Substrates with prepatterned indium tin oxide (<17 Ohm/sq) were cleaned by sequentially sonicating in Hellmanex (2% in water), deionized water, acetone, and isopropanol for 10 min at each stage and then treated with UV ozone for 10 min. A dispersion of PEDOT:PSS 4083 was filtered through a 0.45 _μ_ m hydrophilic syringe filter and spin-coated at 4000 rpm for 25 s, followed by annealing for 30 min at 130 °C in the air. Then, the substrates were transferred into the nitrogen-filled glovebox, where a solution of polyTPD (2 mg/mL in chlorobenzene) was spincoated at 2000 rpm for 40 s and annealed at 130 °C for 25 min. The cyclohexane solution of CsPbBr3 NCs (ca. 10 nm), stabilized with N- _α_ -lauroylarginine decyl ester hydrobromide as surface capping ligands (details of the synthesis will be published elsewhere), was spin-coated at 6000 rpm for 40 s. While remaining under a nitrogen atmosphere, the substrates were transferred into the thermal evaporator with a base pressure of 10<sup>−4</sup> Pa, where 15 nm of B3PYMPM, 45 nm of TPBi, and 1.2 nm of LiF were thermally evaporated onto the substrates at the following rates: 0.5, 0.5, and 0.1 As<sup>−1</sup> . Finally, 100 nm of aluminum was evaporated through shadow masks (installed without breaking the vacuum) at 2−5 As<sup>−1</sup> , defining a 0.16 cm<sup>2</sup> pixel area by overlap with ITO. The device performance was measured under ambient conditions without any encapsulation. 

**Hard Radiation Detection.** _Crystal Growth of CsPbBr3 Crystals._ Cesium lead bromide (CsPbBr3) was prepared from cesium bromide CsBr (5N, ChemCraft Ltd.) and lead bromide PbBr2 (homemade). The components were weighted out 

**3408** 

https://doi.org/10.1021/acsenergylett.2c01663 _ACS Energy Lett._ 2022, 7, 3401−3414 

**<u>ACS Energy Letters</u>** 

**<mark>http://pubs.acs.org/journal/aelccp</mark>** 

<mark>Perspective</mark> 



Figure 6. Robust hollow halide perovskite memristors. (a) Migration pathway and (b) activation barrier and for Ag ions in standard 3D tetragonal and 44% en-doped CH3NH3PbI3, obtained from DFT calculations. (c) The device structure comprises Ag (150 nm), PMMA (∼150 nm), en-doped MAPI (∼ 240 nm), and ITO (110 nm) as shown in the SEM device cross-section. (d) IV sweep, (e) retention, and (f) endurance characteristics of 7% en-doped MAPI. The IV sweep represents the evolution of the device conductance upon applying DC sweep voltages (0 V → +5 V → 0 V →−7 V → 0 V). For the positive sweep direction, a compliance current _I_ cc = 1 mA is applied. This is done to control the thickness/number of filaments formed to achieve reliable and controllable switching. As observed, the devices switch from a HRS (∼10<sup>−10</sup> A) to a LRS (∼ 10<sup>−3</sup> A) at ∼1 V for cycle 1. This is called the “SET” process. In the negative sweep direction, _I_ cc is removed to allow higher current flow in the reverse direction. This triggers Joule heating within the device and aids erasure of the programmed state. As observed, the devices switch from the LRS to HRS at −0.5 V. This is called the “RESET” process. The on−off ratio is calculated by comparing the currents at LRS and HRS for the same reading voltage (in this case 0.1 V). For retention testing, the devices are programmed with a write voltage of +5 V, after which the resistance state is read with a reading voltage of +0.1 V. In the next stage, the devices are erased with an erase voltage of −7 V, and the resistance state is read with a reading voltage of +0.1 V. The pulse width used in all cases is 5 ms. For endurance testing of the nonvolatile mode, a write voltage of +5 V, an erase voltage of −7 V, and a read voltage of +0.1 V are used in a cyclical fashion, i.e., write-read-erase-read. This procedure is repeated until the device completely fails or the desired on−off ratio (>10<sup>3</sup> in our case) is not met. For the retention and endurance testing, the reading voltage is chosen to be much smaller than the write and erase voltages to preserve the integrity of the programmed states during the reading operation. 

stoichiometrically and ground together in an agate mortar. The obtained mixture was sealed into a silica tube (10 mm inner diameter, 1 mm wall thickness, conical tip for crystal selection) under a residual pressure of ca. 0.6 Pa. The silica tube was transferred into a muffle furnace in a tilted position and heated to 850 °C for 8 h at a rate of 275 °C/h; the furnace afterward was switched off for cooling to RT, yielding a polycrystalline CsPbBr3 ingot (domain size typically 6−8 mm). For the growth of single crystals, the silica tube was brought as obtained into a three-zone Bridgman−Stockbarger crystal growth furnace. The upper zone was heated to 850 °C at a rate of 275 °C/h and held at this temperature the whole time that the sample needed to travel through the furnace. Afterward, the temperature was lowered to 50 °C (at a rate 80 °C/h), and the furnace switched off when reaching this set point. The lower zone was not actively heated for enhancing the temperature gradient. The temperature gradient was thus 3.5 °C/mm. The translational speed of the sample was set in the range between 0.6−2.4 mm/h. The ingot was retrieved inside a nitrogen-filled glovebox (oxygen, water < 1 ppm). 

_CsPbBr3 SC Device Fabrication._ Ingot slicing was done with a CU-02 Desktop Crystal Cutter cutting machine from Crystal 

Systems Corporation using a compression holder to keep the ingot as well as the obtained slices in position. The slices had typical thicknesses of 2 mm. The obtained slices were polished on a TP-02 Desktop Crystal Polisher from Crystal Systems Corporation. The wafers obtained after completing the grinding/polishing sequence were washed with dry toluene and stored under inert conditions until further use. Ga and Au electrodes were deposited onto the top and bottom sides of the wafers by mechanically spreading a drop of liquid gallium and sputtering Au (100−200 nm) in a JEOL sputter coater. 

_γ and X-ray Characterization._ The energy-resolved _γ_ - spectrum for the<sup>137</sup> Cs source (activity of _c.a._ 0.4 MBq) was measured from the devices connected to a charge-sensitive preamplifier (A250CF CoolFET from Amptek) coupled with an amplifier-shaper (Model 572 from ORTEC) and a digital multichannel analyzer (MCA-8000D from Amptek). X-ray irradiation experiments were done utilizing the X-ray tube from Amptek (model Mini-X, with Ag target). The radiation dose rate measurements were performed with a Soft X-ray Chamber dosimeter from PTW. For the X-ray photocurrent response study, the device was connected to a digital oscilloscope Tectronix DPO 2024B, which recorded the signal waveform, 

**3409** 

https://doi.org/10.1021/acsenergylett.2c01663 _ACS Energy Lett._ 2022, 7, 3401−3414 

**<u>ACS Energy Letters</u>** 

**<mark>http://pubs.acs.org/journal/aelccp</mark>** 

<mark>Perspective</mark> 

via a low-noise current amplifier Femto DLPCA-200. The temperature-dependent measurements were done with a THMS600 heating and freezing microscope stage from Linkam. 

**Memristor.** _Syntheses of MA1_ − _xenxPb1_ − _0.7xI3_ − _0.4x (x = 0%, 7%) Perovskite Microcrystalline Compounds. β-MAPbI3._ Undoped MAPbI3 was synthesized using an inverse temperature crystallization method.<sup>70</sup> A total of 5.070 g of PbI2 and 1.749 g of MAI were dissolved in 10 mL of GBL at 65 °C. The solution was filtered using a 0.2 _μ_ m PTFE filter in a vial which was heated to 110 °C in an oil bath and kept at this temperature for 2 h and 30 min. The grown crystals were collected by suction filtration, washed with toluene, and dried under a vacuum overnight at 90 °C. Doped compounds were obtained from acidic aqueous solutions upon cooling following the reported procedure.<sup>71</sup> 

_(MA)0.93(en)0.07(Pb)0.951(I)2.972._ 1.137 g of Pb(CH3CO2)2· 3H2O was dissolved in 3.5 mL of aqueous HI (57% w/w, stabilized) by heating to boiling under stirring. Meanwhile, 40 _μ_ L of ethylenediamine was added into another vial with 0.7 mL of 50% aqueous H3PO2 in an ice bath. Then, this solution was added to the hot PbI2 solution, followed by the addition of 0.477 g of methylammonium iodide. The black crystals obtained upon cooling down were collected by suction filtration, washed with toluene, and dried under a vacuum overnight at 110 °C. 

_Memristor Device Fabrication._ Substrates with prepatterned indium tin oxide (<17 Ohm/sq) were cleaned by sequential sonicating in Hellmanex (2% in water), deionized water, acetone, and isopropanol for 10 min at each stage and then treated with UV ozone for 10 min. en-MAPI crystals were dissolved in DMF/DMSO (95:5 by volume) mixture to form 30% (by mass) perovskite precursor solutions, which were filtered with a 45 _μ_ m PTFE filter. First, 100 _μ_ L of PMMA solution in toluene (27 mg/mL) was spin-coated on the substrate at 4000 rpm for 1 min, followed by annealing at 100 °C for 6 min. Next, 60 _μ_ L of 30% (by mass) perovskite precursor solution, prepared by dissolving en-MAPI crystals in DMF/DMSO (95:5 by volume) mixture, subsequently filtered with a 45 _μ_ m PTFE filter, was spin-coated on the cold substrate at 4000 rpm for 30 s and 400 _μ_ L of toluene was dropped for 10 s after starting the spin-coating. The perovskite film was annealed on a hot plate at 100 °C for 10 min and allowed to cool down. Then, 100 _μ_ L of 27 mg/mL PMMA solution in toluene was spin-coated at 4000 rpm for 1 min. Finally, ∼150 nm of Ag was thermally evaporated through shadow masks (100 _μ_ m × 100 _μ_ m) to complete the device fabrication. Electrical measurements were carried out using a Karl Suss PM8Manual Probe Station and Keithley 4200 SCS under ambient conditions without additional encapsulation. 

**Computational Methodology.** All of the DFT-based<sup>72,73</sup> electronic structure calculations for structural optimization and the transition pathway prediction are carried out using the plane-wave basis set-based approach as implemented in the Vienna Ab initio Simulation Package (VASP) within the framework of the projector augmented wave (PAW) formalism.<sup>74,75</sup> To approximate the exchange-correlation potential, a Perdew, Burke, and Ernzerhof (PBE) type<sup>76</sup> generalized gradient approximation (GGA) functional was used with a plane wave cutoff of 450 eV. We have used the converged k- points mesh of 3 × 3 × 3 Monkhorst−Pack<sup>77</sup> throughout the calculations. For all of the calculations performed in this work, self-consistency has been achieved with convergence criteria of 

1 × 10<sup>−3</sup> eV, whereas the force convergence criteria have been set to 1 × 10<sup>−2</sup> eV/Å. Since the structures contain heavy element lead (Pb), we have considered relativistic spin−orbit coupling (SOC) interaction throughout our calculations. Usually in the CH3NH3PbI3-type perovskite, vacancy-mediated ion migration dominates. Hence in this theoretical study, we have mainly investigated a vacancy transport mechanism to determine the migration barrier for I and Ag ions. The simulation cells used for structural optimization are extracted from the experimental data and contain a total of 50 and 26 atoms with four and two PbI3 units respectively in case of standard and hollow (44% _en_ doped) configurations. These cell sizes are sufficient enough to accommodate the vacancy defects under consideration. To investigate vacancy-mediated migration, we have used the climbing image nudge elastic band method. The activation energy corresponding to the diffusion process is determined from the difference in the ground state energies of diffusion species I and Ag at successive saddle points along the migration pathway. 

# ■<sup>**ASSOCIATEDCONTENT**</sup> 

##### * **sı Supporting Information** 

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acsenergylett.2c01663. 

- Supplementary notes and additional optoelectronic characterization (PDF) 

# ■<sup>**AUTHORINFORMATION**</sup> 

###### **Corresponding Authors** 

- Rohit Abraham John − _Laboratory of Inorganic Chemistry, Department of Chemistry and Applied Biosciences, ETH Zurich,_ ̈ _CH-8093 Zu_ ̈ _rich, Switzerland; Laboratory for Thin Films and Photovoltaics, Empa_ − _Swiss Federal Laboratories for Materials Science and Technology, CH-8600 Dubendorf,_ ̈ _Switzerland;_ orcid.org/0000-0002-1709-0386; Email: rohjohn@ethz.ch 

- Maksym V. Kovalenko − _Laboratory of Inorganic Chemistry, Department of Chemistry and Applied Biosciences, ETH Zurich,_ ̈ _CH-8093 Zu_ ̈ _rich, Switzerland; Laboratory for Thin Films and Photovoltaics, Empa_ − _Swiss Federal Laboratories for Materials Science and Technology, CH-8600 Dubendorf,_ ̈ _Switzerland;_ orcid.org/0000-0002-6396-8938; Email: mvkovalenko@ethz.ch 

###### **Authors** 

- Kostiantyn Sakhatskyi − _Laboratory of Inorganic Chemistry, Department of Chemistry and Applied Biosciences, ETH Zurich,_ ̈ _CH-8093 Zu_ ̈ _rich, Switzerland; Laboratory for Thin Films and Photovoltaics, Empa_ − _Swiss Federal Laboratories for Materials Science and Technology, CH-8600 Dubendorf,_ ̈ _Switzerland_ 

- Antonio Guerrero − _Institute of Advanced Materials (INAM), Universitat Jaume I, 12006 Castelló, Spain;_ orcid.org/0000-0001-8602-1248 

- Sergey Tsarev − _Laboratory of Inorganic Chemistry, Department of Chemistry and Applied Biosciences, ETH Zurich,_ ̈ _CH-8093 Zu_ ̈ _rich, Switzerland; Laboratory for Thin Films and Photovoltaics, Empa_ − _Swiss Federal Laboratories for Materials Science and Technology, CH-8600 Dubendorf,_ ̈ _Switzerland_ 

**3410** 

https://doi.org/10.1021/acsenergylett.2c01663 _ACS Energy Lett._ 2022, 7, 3401−3414 

**<u>ACS Energy Letters</u>** 

**<mark>http://pubs.acs.org/journal/aelccp</mark>** 

<mark>Perspective</mark> 

- Sebastian Sabisch − _Laboratory of Inorganic Chemistry, Department of Chemistry and Applied Biosciences, ETH Zurich,_ ̈ _CH-8093 Zurich,_ ̈ _Switzerland_ 

- Tisita Das − _Materials Theory for Energy Scavenging (MATES) Lab, Harish-Chandra Research Institute (HRI) Allahabad, HBNI, Allahabad, Uttar Pradesh 211019,_ 

- _India;_ orcid.org/0000-0001-5212-5102 

- Gebhard J. Matt − _Laboratory of Inorganic Chemistry, Department of Chemistry and Applied Biosciences, ETH Zurich,_ ̈ _CH-8093 Zurich,_ ̈ _Switzerland; Laboratory for Thin Films and Photovoltaics, Empa_ − _Swiss Federal Laboratories for Materials Science and Technology, CH-8600 Du_ ̈ _bendorf, Switzerland_ 

- Sergii Yakunin − _Laboratory of Inorganic Chemistry, Department of Chemistry and Applied Biosciences, ETH Zurich,_ ̈ _CH-8093 Zurich,_ ̈ _Switzerland; Laboratory for Thin Films and Photovoltaics, Empa_ − _Swiss Federal Laboratories for Materials Science and Technology, CH-8600 Du_ ̈ _bendorf, Switzerland;_ orcid.org/0000-0002-6409-0565 

- Ihor Cherniukh − _Laboratory of Inorganic Chemistry, Department of Chemistry and Applied Biosciences, ETH Zurich,_ ̈ _CH-8093 Zurich,_ ̈ _Switzerland; Laboratory for Thin Films and Photovoltaics, Empa_ − _Swiss Federal Laboratories for Materials Science and Technology, CH-8600 Du_ ̈ _bendorf, Switzerland;_ orcid.org/0000-0001-7155-5095 

- Martin Kotyrba − _Laboratory of Inorganic Chemistry, Department of Chemistry and Applied Biosciences, ETH Zurich,_ ̈ _CH-8093 Zurich,_ ̈ _Switzerland; Laboratory for Thin Films and Photovoltaics, Empa_ − _Swiss Federal Laboratories for Materials Science and Technology, CH-8600 Du_ ̈ _bendorf, Switzerland_ 

- Yuliia Berezovska − _Laboratory of Inorganic Chemistry, Department of Chemistry and Applied Biosciences, ETH Zurich,_ ̈ _CH-8093 Zurich,_ ̈ _Switzerland; Laboratory for Thin Films and Photovoltaics, Empa_ − _Swiss Federal Laboratories for Materials Science and Technology, CH-8600 Du_ ̈ _bendorf, Switzerland_ 

- Maryna I. Bodnarchuk − _Laboratory of Inorganic Chemistry, Department of Chemistry and Applied Biosciences, ETH Zurich,_ ̈ _CH-8093 Zurich,_ ̈ _Switzerland; Laboratory for Thin Films and Photovoltaics, Empa_ − _Swiss Federal Laboratories for Materials Science and Technology, CH-8600 Du_ ̈ _bendorf, Switzerland;_ orcid.org/0000-0001-6597-3266 

- Sudip Chakraborty − _Materials Theory for Energy Scavenging (MATES) Lab, Harish-Chandra Research Institute (HRI) Allahabad, HBNI, Allahabad, Uttar Pradesh 211019, India;_ orcid.org/0000-0002-6765-2084 

- Juan Bisquert − _Institute of Advanced Materials (INAM), Universitat Jaume I, 12006 Castelló, Spain; Yonsei Frontier Lab, Yonsei University, Seoul 03722, South Korea;_ orcid.org/0000-0003-4987-4887 

Complete contact information is available at: https://pubs.acs.org/10.1021/acsenergylett.2c01663 

###### **Author Contributions** 

> #These authors contributed equally to this work 

###### **Notes** 

The authors declare no competing financial interest. 

###### **Biographies** 

Kostiantyn Sakhatskyi is a Ph.D. student at ETH Zurich in the Department of Chemistry and Applied Biosciences since 2020. His expertise fields are the physics of ionizing radiation interaction with 

matter, the semiconductor radiation detector physics, and the fabrication of devices, such as X-ray imaging detectors and gammaray spectrometers. 

Rohit Abraham John is an ETH Fellow at the Department of Chemistry and Applied Biosciences, ETH Zurich. He is a recipient of the prestigious ETH Fellowship (2020−2022). His expertise lies in the physics of semiconducting materials and devices for emerging memory and computing applications, such as transistors and memristors. 

Antonio Guerrero is Associate Professor in Applied Physics at the Universitat Jaume I (Spain). His expertise involves materials development for solar cells (perovskite and organic photovoltaics), memristors, light emitting diodes, or electrochemical devices. He has great experience in their characterization using advanced electrical techniques to understand their working mechanisms. 

Sergey Tsarev is a postdoctoral fellow at the Department of Chemistry and Applied Biosciences at ETH Zurich. His core competencies are perovskite thin-film devices, including perovskite solar cells, light-emitting diodes, and photodetectors. His research focuses on improving the stability of perovskite devices and their innovative applications. 

Sebastian Sabisch is a student at ETH Zurich, currently obtaining his̈ M.Sc. in chemistry. His research interests are in understanding the unique properties and structural features of functional metal halides used in optical applications and heterogeneous catalysis. 

Tisita Das completed her Ph.D. from IACS Kolkata in 2019 as an INSPIRE Fellow and currently works as an Institute Postdoc in HRI Allahabad, India. She extensively works on hybrid perovskites and 2D nanostructures through her materials modelling expertise for energy applications in catalysis, solar cells, batteries, and neuromorphic computing. 

Gebhard Matt is a postdoctoral fellow at ETH Zurich in the Department of Chemistry and Applied Biosciences. His research focus is the electro-optical characterization and charge transport measurements on metal halide perovskite-based devices. 

Sergii Yakinin is a senior researcher at ETH Zurich in the Department of Chemistry and Applied Biosciences. His research field is semiconductor physics and optoelectronic properties of metal halide perovskites and their various applications, including photodetectors, lasers, X-ray detectors, and thermal imagers. 

Ihor Cherniukh is a Ph.D. student at ETH Zurich in the Department of Chemistry Applied Biosciences and at Empa since 2018. His research focuses on the synthesis and self-assembly of functional inorganic nanocrystals into multicomponent superlattices. 

Martin Kotyrba leads the crystal growth facility part of the SynMatLab at ETH Zurich. As a solid-state chemist, his main competencies are the preparation of lead-halide based single crystals. Also, further development of the facility and improvement of the crystal growth equipment are parts of his scope. 

Yuliia Berezovska is a Ph.D. student at ETH Zurich in the Department of Chemistry and Applied Biosciences since 2021. Her fields of expertise are the surface chemistry of lead halide perovskite nanomaterials and the organic synthesis of small molecules. 

Maryna I. Bodnarchuk is group leader at Swiss Federal Laboratories for Materials Science and Technology (Switzerland). Her research focuses on the synthesis of precisely engineered nanocrystals, their surface chemistry, and self-assembly into long-range ordered structures. 

**3411** 

https://doi.org/10.1021/acsenergylett.2c01663 _ACS Energy Lett._ 2022, 7, 3401−3414 

**<u>ACS Energy Letters</u>** 

**<mark>http://pubs.acs.org/journal/aelccp</mark>** 

<mark>Perspective</mark> 

Sudip Chakraborty leads the Materials Theory for Energy Scavenging (MATES) Lab in HRI Allahabad, India as a Reader since 2021. His research thrust revolves around development and applications of cutting-edge computations for energy application in the area of solar cells, catalysis, batteries, and neuromorphic computing using hybrid perovskites and 2D materials. 

Juan Bisquert is a professor of Applied Physics at Universitat Jaume I de Castello.́ He is the funding director of the Institute of Advanced Materials. He has been distinguished in the list of Highly Cited Researchers from 2014 to 2021. His research focuses on understanding the fundamental mechanisms of perovskites. 

Maksym Kovalenko is a professor of Functional Inorganic Materials at the Swiss Federal Institute of Technology Zurich and at Swiss Federal Laboratories for Material Science and Technology. He is a Clarivate’s Highly Cited Researcher since 2018. His research interests span light emissive nanomaterials, light harvesting materials, hard radiation detectors, and electrochemical energy storage. 

# ■<sup>**ACKNOWLEDGMENTS**</sup> 

R.A.J. acknowledges financial support from the ETH Zurich Postdoctoral Fellowship scheme for this work (Grant 20-1 FEL-16). K.S., R.A.J., S.T., S.S., G.J.M., S.Y., I.C., M.K., Y.B., M.I.B., and M.V.K. would like to thank the financial support by the European Union through Horizon 2020 research and innovation programme [ERC Consolidator Grant, agreement no. (819740), project SCALE-HALO]. A.G. and J.B. would like to thank the financial support by the Ministerio de Ciencia e Innovación of Spain (MICINN) project PID2019107348GB-100. T.D. and S.C. would like to acknowledge HRI Allahabad for the necessary infrastructure and required computation. S.C. would like to acknowledge DST funding SRG/2020/001707. 

# ■<sup>**REFERENCES**</sup> 

(1) Zhang, Y.; Park, N.-G. Quasi-Two-Dimensional Perovskite Solar Cells with Efficiency Exceeding 22%. _ACS Energy Lett._ 2022, _7_ (2), 757−765. 

(2) NREL_Photovoltaic Research_Best Research-Cell Efficiency Chart. Available at Https://Www.Nrel.Gov/Pv/Cell-Efficiency.Html (accessed on Jan 28, 2022). 

(3) Xiao, Z.; Yuan, Y.; Shao, Y.; Wang, Q.; Dong, Q.; Bi, C.; Sharma, P.; Gruverman, A.; Huang, J. Giant Switchable Photovoltaic Effect in Organometal Trihalide Perovskite Devices. _Nat. Mater._ 2015, _14_ (2), 193. 

(4) Kim, H.-S.; Jang, I.-H.; Ahn, N.; Choi, M.; Guerrero, A.; Bisquert, J.; Park, N.-G. Control of I−V Hysteresis in CH3NH3PbI3 Perovskite Solar Cell. _J. Phys. Chem. Lett._ 2015, _6_ (22), 4633−4639. 

(5) Shao, Y.; Fang, Y.; Li, T.; Wang, Q.; Dong, Q.; Deng, Y.; Yuan, Y.; Wei, H.; Wang, M.; Gruverman, A.; Shield, J.; Huang, J. Grain Boundary Dominated Ion Migration in Polycrystalline Organic− Inorganic Halide Perovskite Films. _Energy Environ. Sci._ 2016, _9_ (5), 1752−1759. 

(6) Zhang, H.; Fu, X.; Tang, Y.; Wang, H.; Zhang, C.; Yu, W. W.; Wang, X.; Zhang, Y.; Xiao, M. Phase Segregation Due to Ion Migration in All-Inorganic Mixed-Halide Perovskite Nanocrystals. _Nat. Commun._ 2019, _10_ (1), 1088. 

(7) Meggiolaro, D.; Mosconi, E.; De Angelis, F. Formation of Surface Defects Dominates Ion Migration in Lead-Halide Perovskites. _ACS Energy Lett._ 2019, _4_ (3), 779−785. 

(8) Li, C.; Guerrero, A.; Zhong, Y.; Gräser, A.; Luna, C. A. M.; Köhler, J.; Bisquert, J.; Hildner, R.; Huettner, S. Real-time Observation of Iodide Ion Migration in Methylammonium Lead Halide Perovskites. _Small_ 2017, _13_ (42), 1701711. 

(9) Birkhold, S. T.; Precht, J. T.; Giridharagopal, R.; Eperon, G. E.; Schmidt-Mende, L.; Ginger, D. S. Direct Observation and Quantitative Analysis of Mobile Frenkel Defects in Metal Halide Perovskites Using Scanning Kelvin Probe Microscopy. _J. Phys. Chem. C_ 2018, _122_ (24), 12633−12639. 

(10) Yuan, Y.; Huang, J. Ion Migration in Organometal Trihalide Perovskite and Its Impact on Photovoltaic Efficiency and Stability. _Acc. Chem. Res._ 2016, _49_ (2), 286−293. 

(11) Yuan, H.; Debroye, E.; Janssen, K.; Naiki, H.; Steuwe, C.; Lu, G.; Moris, M.; Orgiu, E.; Uji-i, H.; De Schryver, F.; Samori, P.; Hofkens, J.; Roeffaers, M. Degradation of Methylammonium Lead Iodide Perovskite Structures through Light and Electron Beam Driven Ion Migration. _J. Phys. Chem. Lett._ 2016, _7_ (3), 561−566. 

(12) Eames, C.; Frost, J. M.; Barnes, P. R.; O’regan, B. C.; Walsh, A.; Islam, M. S. Ionic Transport in Hybrid Lead Iodide Perovskite Solar Cells. _Nat. Commun._ 2015, _6_ (1), 7497. 

(13) Tress, W. Metal Halide Perovskites as Mixed Electronic−Ionic Conductors: Challenges and Opportunities� From Hysteresis to Memristivity. _J. Phys. Chem. Lett._ 2017, _8_ (13), 3106−3114. 

(14) Rickert, H. _Electrochemistry of Solids: An Introduction_ ; Springer Science & Business Media, 2012; Vol. _7_ . 

(15) Wang, H.; Guerrero, A.; Bou, A.; Al-Mayouf, A. M.; Bisquert, J. Kinetic and Material Properties of Interfaces Governing Slow Response and Long Timescale Phenomena in Perovskite Solar Cells. _Energy Environ. Sci._ 2019, _12_ (7), 2054−2079. 

(16) Guerrero, A.; You, J.; Aranda, C.; Kang, Y. S.; Garcia-Belmonte, G.; Zhou, H.; Bisquert, J.; Yang, Y. Interfacial Degradation of Planar Lead Halide Perovskite Solar Cells. _ACS Nano_ 2016, _10_ (1), 218− 224. 

(17) Jacobs, D. A.; Shen, H.; Pfeffer, F.; Peng, J.; White, T. P.; Beck, F. J.; Catchpole, K. R. The Two Faces of Capacitance: New Interpretations for Electrical Impedance Measurements of Perovskite Solar Cells and Their Relation to Hysteresis. _J. Appl. Phys._ 2018, _124_ (22), 225702. 

(18) Zohar, A.; Kedem, N.; Levine, I.; Zohar, D.; Vilan, A.; Ehre, D.; Hodes, G.; Cahen, D. Impedance Spectroscopic Indication for Solid State Electrochemical Reaction in (CH3NH3) PbI3 Films. _J. Phys. Chem. Lett._ 2016, _7_ (1), 191−197. 

(19) Guerrero, A.; Bisquert, J.; Garcia-Belmonte, G. Impedance Spectroscopy of Metal Halide Perovskite Solar Cells from the Perspective of Equivalent Circuits. _Chem. Rev._ 2021, _121_ (23), 14430−14484. 

(20) Bisquert, J.; Guerrero, A. Chemical Inductor. _J. Am. Chem. Soc._ 2022, _144_ (13), 5996−6009. 

(21) Hoke, E. T.; Slotcavage, D. J.; Dohner, E. R.; Bowring, A. R.; Karunadasa, H. I.; McGehee, M. D. Reversible Photo-Induced Trap Formation in Mixed-Halide Hybrid Perovskites for Photovoltaics. _Chem. Sci._ 2015, _6_ (1), 613−617. 

(22) Kim, G. Y.; Senocrate, A.; Wang, Y.; Moia, D.; Maier, J. PhotoEffect on Ion Transport in Mixed Cation and Halide Perovskites and Implications for Photo-Demixing. _Angew. Chem., Int. Ed._ 2021, _60_ (2), 820−826. 

(23) Kim, G. Y.; Senocrate, A.; Yang, T.-Y.; Gregori, G.; Grätzel, M.; Maier, J. Large Tunable Photoeffect on Ion Conduction in Halide Perovskites and Implications for Photodecomposition. _Nat. Mater._ 2018, _17_ (5), 445−449. 

(24) Samu, G. F.; Balog, Á.; De Angelis, F.; Meggiolaro, D.; Kamat, P. V.; Janáky, C. Electrochemical Hole Injection Selectively Expels Iodide from Mixed Halide Perovskite Films. _J. Am. Chem. Soc._ 2019, _141_ (27), 10812−10820. 

(25) Elmelund, T.; Seger, B.; Kuno, M.; Kamat, P. V. How Interplay between Photo and Thermal Activation Dictates Halide Ion Segregation in Mixed Halide Perovskites. _ACS Energy Lett._ 2020, _5_ (1), 56−63. 

(26) Zhang, Y.; Park, N.-G. Quasi-Two-Dimensional Perovskite Solar Cells with Efficiency Exceeding 22%. _ACS Energy Lett._ 2022, _7_ , 757−765. 

(27) _NREL_Photovoltaic Research_Best Research-Cell Efficiency Chart_ . https://www.nrel.gov/pv/cell-efficiency.html. 

**3412** 

https://doi.org/10.1021/acsenergylett.2c01663 _ACS Energy Lett._ 2022, 7, 3401−3414 

**<u>ACS Energy Letters</u>** 

**<mark>http://pubs.acs.org/journal/aelccp</mark>** 

<mark>Perspective</mark> 

(28) Domanski, K.; Roose, B.; Matsui, T.; Saliba, M.; Turren-Cruz, S.-H.; Correa-Baena, J.-P.; Carmona, C. R.; Richardson, G.; Foster, J. M.; De Angelis, F.; Ball, J. M.; Petrozza, A.; Mine, N.; Nazeeruddin, M. K.; Tress, W.; Gratzel, M.; Steiner, U.; Hagfeldt, A.; Abate, A. Migration of Cations Induces Reversible Performance Losses over Day/Night Cycling in Perovskite Solar Cells. _Energy Env. Sci._ 2017, _10_ , 604−613. 

(29) Zhao, Y.; Heumueller, T.; Zhang, J.; Luo, J.; Kasian, O.; Langner, S.; Kupfer, C.; Liu, B.; Zhong, Y.; Elia, J.; Osvet, A.; Wu, J.; Liu, C.; Wan, Z.; Jia, C.; Li, N.; Hauch, J.; Brabec, C. J. A Bilayer Conducting Polymer Structure for Planar Perovskite Solar Cells with over 1,400 h Operational Stability at Elevated Temperatures. _Nat. Energy_ 2022, _7_ (2), 144−152. 

(30) Kojima, A.; Teshima, K.; Shirai, Y.; Miyasaka, T. Organometal Halide Perovskites as Visible-Light Sensitizers for Photovoltaic Cells. _J. Am. Chem. Soc._ 2009, _131_ (17), 6050−6051. 

(31) Boyd, C. C.; Cheacharoen, R.; Leijtens, T.; McGehee, M. D. Understanding Degradation Mechanisms and Improving Stability of Perovskite Photovoltaics. _Chem. Rev._ 2019, _119_ (5), 3418−3451. 

(32) Li, C.; Guerrero, A.; Huettner, S.; Bisquert, J. Unravelling the Role of Vacancies in Lead Halide Perovskite through Electrical Switching of Photoluminescence. _Nat. Commun._ 2018, _9_ (1), 5113. 

(33) Tsai, H.; Nie, W.; Blancon, J.-C.; Stoumpos, C. C.; Asadpour, R.; Harutyunyan, B.; Neukirch, A. J.; Verduzco, R.; Crochet, J. J.; Tretiak, S.; Pedesseau, L.; Even, J.; Alam, M. A.; Gupta, G.; Lou, J.; Ajayan, P. M.; Bedzyk, M. J.; Kanatzidis, M. G.; Mohite, A. D. HighEfficiency Two-Dimensional Ruddlesden−Popper Perovskite Solar Cells. _Nature_ 2016, _536_ (7616), 312−316. 

(34) Akriti; Zhang, S.; Lin, Z.-Y.; Shi, E.; Finkenauer, B. P.; Gao, Y.; Pistone, A. J.; Ma, K.; Savoie, B. M.; Dou, L. Quantifying Anionic Diffusion in 2D Halide Perovskite Lateral Heterostructures. _Adv. Mater._ 2021, _33_ (51), 2105183. 

(35) Ren, H.; Yu, S.; Chao, L.; Xia, Y.; Sun, Y.; Zuo, S.; Li, F.; Niu, T.; Yang, Y.; Ju, H.; Li, B.; Du, H.; Gao, X.; Zhang, J.; Wang, J.; Zhang, L.; Chen, Y.; Huang, W. Efficient and Stable Ruddlesden− Popper Perovskite Solar Cell with Tailored Interlayer Molecular Interaction. _Nat. Photonics_ 2020, _14_ (3), 154−163. 

(36) Shynkarenko, Y.; Bodnarchuk, M. I.; Bernasconi, C.; Berezovska, Y.; Verteletskyi, V.; Ochsenbein, S. T.; Kovalenko, M. V. Direct Synthesis of Quaternary Alkylammonium-Capped Perovskite Nanocrystals for Efficient Blue and Green Light-Emitting Diodes. _ACS Energy Lett._ 2019, _4_ (11), 2703−2711. 

(37) Teng, P.; Reichert, S.; Xu, W.; Yang, S.-C.; Fu, F.; Zou, Y.; Yin, C.; Bao, C.; Karlsson, M.; Liu, X.; Qin, J.; Yu, T.; Tress, W.; Yang, Y.; Sun, B.; Deibel, C.; Gao, F. Degradation and Self-Repairing in Perovskite Light-Emitting Diodes. _Matter_ 2021, _4_ (11), 3710−3724. 

(38) Zhao, L.; Roh, K.; Kacmoli, S.; Al Kurdi, K.; Jhulki, S.; Barlow, S.; Marder, S. R.; Gmachl, C.; Rand, B. P. Thermal Management Enables Bright and Stable Perovskite Light-emitting Diodes. _Adv. Mater._ 2020, _32_ (25), 2000752. 

(39) Lenes, M.; Garcia-Belmonte, G.; Tordera, D.; Pertegás, A.; Bisquert, J.; Bolink, H. J. Operating Modes of Sandwiched LightEmitting Electrochemical Cells. _Adv. Funct. Mater._ 2011, _21_ (9), 1581−1586. 

(40) He, Y.; Petryk, M.; Liu, Z.; Chica, D. G.; Hadar, I.; Leak, C.; Ke, W.; Spanopoulos, I.; Lin, W.; Chung, D. Y.; Wessels, B. W.; He, Z.; Kanatzidis, M. G. CsPbBr3 Perovskite Detectors with 1.4% Energy Resolution for High-Energy _γ_ -Rays. _Nat. Photonics_ 2021, _15_ (1), 36− 42. 

(41) Liu, Y.; Zhang, Y.; Zhu, X.; Feng, J.; Spanopoulos, I.; Ke, W.; He, Y.; Ren, X.; Yang, Z.; Xiao, F.; Zhao, K.; Kanatzidis, M.; Liu, S. Triple-Cation and Mixed-Halide Perovskite Single Crystal for HighPerformance X-ray Imaging. _Adv. Mater._ 2021, _33_ (8), 2006010. 

(42) Liu, Y.; Zheng, X.; Fang, Y.; Zhou, Y.; Ni, Z.; Xiao, X.; Chen, S.; Huang, J. Ligand Assisted Growth of Perovskite Single Crystals with Low Defect Density. _Nat. Commun._ 2021, _12_ (1), 5113. 

(43) Pan, W.; Yang, B.; Niu, G.; Xue, K.; Du, X.; Yin, L.; Zhang, M.; Wu, H.; Miao, X.; Tang, J. Hot-Pressed CsPbBr3 Quasi-Monocrystal- 

line Film for Sensitive Direct X-ray Detection. _Adv. Mater._ 2019, _31_ (44), 1904405. 

(44) Jia, S.; Xiao, Y.; Hu, M.; He, X.; Bu, N.; Li, N.; Liu, Y.; Zhang, Y.; Cui, J.; Ren, X.; Zhao, K.; Liu, M.; Wang, S.; Yuan, N.; Ding, J.; Yang, Z.; Liu, S. Ion-Accumulation-Induced Charge Tunneling for High Gain Factor in P−I−N-Structured Perovskite CH3NH3PbI3 X- Ray Detector. _Adv. Mater. Technol._ 2022, _7_ (6), 2100908. 

(45) Chen, C.; Fu, Q.; Guo, P.; Chen, H.; Wang, M.; Luo, W.; Zheng, Z. Ionic Transport Characteristics of Large-Size CsPbBr3 Single Crystals. _Mater. Res. Express_ 2019, _6_ (11), 115808. 

(46) Daum, M.; Deumel, S.; Sytnyk, M.; Afify, H. A.; Hock, R.; Eigen, A.; Zhao, B.; Halik, M.; These, A.; Matt, G. J.; Brabec, C. J.; Tedde, S. F.; Heiss, W. Self-Healing Cs3Bi2Br3I6 Perovskite Wafers for X-Ray Detection. _Adv. Funct. Mater._ 2021, _31_ (47), 2102713. 

(47) Almora, O.; Matt, G. J.; These, A.; Kanak, A.; Levchuk, I.; Shrestha, S.; Osvet, A.; Brabec, C. J.; Garcia-Belmonte, G. Surface versus Bulk Currents and Ionic Space-Charge Effects in CsPbBr3 Single Crystals. _J. Phys. Chem. Lett._ 2022, _13_ , 3824−3830. 

(48) Harikesh, P. C.; Febriansyah, B.; John, R. A.; Mathews, N. Hybrid Organic−Inorganic Halide Perovskites for Scaled-in Neuromorphic Devices. _MRS Bull._ 2020, _45_ (8), 641−648. 

(49) Xiao, Z.; Huang, J. Energy-efficient Hybrid Perovskite Memristors and Synaptic Devices. _Adv. Electron. Mater._ 2016, _2_ (7), 1600100. 

(50) Xu, W.; Cho, H.; Kim, Y.; Kim, Y.; Wolf, C.; Park, C.; Lee, T. Organometal Halide Perovskite Artificial Synapses. _Adv. Mater._ 2016, _28_ (28), 5916−5922. 

(51) Wang, Y.; Lv, Z.; Liao, Q.; Shan, H.; Chen, J.; Zhou, Y.; Zhou, L.; Chen, X.; Roy, V. A. L.; Wang, Z.; Xu, Z.; Zeng, Y.-J.; Han, S.-T. Synergies of Electrochemical Metallization and Valance Change in All-inorganic Perovskite Quantum Dots for Resistive Switching. _Adv. Mater._ 2018, _30_ (28), 1800327. 

(52) Lee, S.; Kim, H.; Kim, D. H.; Kim, W. B.; Lee, J. M.; Choi, J.; Shin, H.; Han, G. S.; Jang, H. W.; Jung, H. S. Tailored 2D/3D Halide Perovskite Heterointerface for Substantially Enhanced Endurance in Conducting Bridge Resistive Switching Memory. _ACS Appl. Mater. Interfaces_ 2020, _12_ (14), 17039−17045. 

(53) Park, Y.; Kim, S. H.; Lee, D.; Lee, J.-S. Designing ZeroDimensional Dimer-Type All-Inorganic Perovskites for Ultra-Fast Switching Memory. _Nat. Commun._ 2021, _12_ (1), 3527. 

(54) Kepenekian, M.; Even, J. Rashba and Dresselhaus Couplings in Halide Perovskites: Accomplishments and Opportunities for Spintronics and Spin−Orbitronics. _J. Phys. Chem. Lett._ 2017, _8_ (14), 3362−3370. 

(55) Liu, Y.; Kim, D.; Ievlev, A. V.; Kalinin, S. V.; Ahmadi, M.; Ovchinnikova, O. S. Ferroic Halide Perovskite Optoelectronics. _Adv. Funct. Mater._ 2021, _31_ , 2102793. 

(56) John, R. A.; Shah, N.; Vishwanath, S. K.; Ng, S. E.; Febriansyah, B.; Jagadeeswararao, M.; Chang, C.-H.; Basu, A.; Mathews, N. Halide Perovskite Memristors as Flexible and Reconfigurable Physical Unclonable Functions. _Nat. Commun._ 2021, _12_ (1), 3681. 

(57) John, R. A.; Demirag, Y.; Shynkarenko, Y.; Berezovska, Y.; Ohannessian, N.; Payvand, M.; Zeng, P.; Bodnarchuk, M. I.; Krumeich, F.; Kara, G.; Shorubalko, I.; Nair, M. V.; Cooke, G. A.; Lippert, T.; Indiveri, G.; Kovalenko, M. V. Reconfigurable Halide Perovskite Nanocrystal Memristors for Neuromorphic Computing. _Nat. Commun._ 2022, _13_ (1), 2074. 

(58) Kim, H.; Choi, M.-J.; Suh, J. M.; Han, J. S.; Kim, S. G.; Le, Q. V.; Kim, S. Y.; Jang, H. W. Quasi-2D Halide Perovskites for Resistive Switching Devices with ON/OFF Ratios above 10 9. _NPG Asia Mater._ 2020, _12_ (1), 21. 

(59) Shaban, A.; Joodaki, M.; Mehregan, S.; Rangelow, I. W. ProbeInduced Resistive Switching Memory Based on Organic-Inorganic Lead Halide Perovskite Materials. _Org. Electron._ 2019, _69_ , 106−113. (60) Siddik, A.; Haldar, P. K.; Paul, T.; Das, U.; Barman, A.; Roy, A.; Sarkar, P. K. Nonvolatile Resistive Switching and Synaptic Characteristics of Lead-Free All-Inorganic Perovskite-Based Flexible Memristive Devices for Neuromorphic Systems. _Nanoscale_ 2021, _13_ (19), 8864− 8874. 

**3413** 

https://doi.org/10.1021/acsenergylett.2c01663 _ACS Energy Lett._ 2022, 7, 3401−3414 

**<u>ACS Energy Letters</u>** 

**<mark>http://pubs.acs.org/journal/aelccp</mark>** 

<mark>Perspective</mark> 

(61) Park, Y.; Lee, J.-S. Bifunctional Silver-Doped ZnO for Reliable and Stable Organic−Inorganic Hybrid Perovskite Memory. _ACS Appl. Mater. Interfaces_ 2021, _13_ (1), 1021−1026. 

(62) Lee, S.; Kim, W. B.; Lee, J. M.; Kim, H. J.; Choi, J. H.; Jung, H. S. Oxide Passivation of Halide Perovskite Resistive Memory Device: A Strategy for Overcoming Endurance Problem. _ACS Appl. Mater. Interfaces_ 2021, _13_ (37), 44577−44584. 

(63) Poddar, S.; Zhang, Y.; Gu, L.; Zhang, D.; Zhang, Q.; Yan, S.; Kam, M.; Zhang, S.; Song, Z.; Hu, W.; Liao, L.; Fan, Z. DownScalable and Ultra-Fast Memristors with Ultra-High Density ThreeDimensional Arrays of Perovskite Quantum Wires. _Nano Lett._ 2021, _21_ (12), 5036−5044. 

(64) Zhang, Y.; Poddar, S.; Huang, H.; Gu, L.; Zhang, Q.; Zhou, Y.; Yan, S.; Zhang, S.; Song, Z.; Huang, B.; Shen, G.; Fan, Z. ThreeDimensional Perovskite Nanowire Array−Based Ultrafast Resistive RAM with Ultralong Data Retention. _Sci. Adv._ 2021, _7_ (36), eabg3788. 

(65) Kim, S.-I.; Lee, Y.; Park, M.-H.; Go, G.-T.; Kim, Y.-H.; Xu, W.; Lee, H.-D.; Kim, H.; Seo, D.-G.; Lee, W.; Lee, T.-W. Dimensionality Dependent Plasticity in Halide Perovskite Artificial Synapses for Neuromorphic Computing. _Adv. Electron. Mater._ 2019, _5_ (9), 1900008. 

(66) John, R. A.; Yantara, N.; Ng, S. E.; Patdillah, M. I. B.; Kulkarni, M. R.; Jamaludin, N. F.; Basu, J.; Ankit; Mhaisalkar, S. G.; Basu, A.; Mathews, N. Diffusive and Drift Halide Perovskite Memristive Barristors as Nociceptive and Synaptic Emulators for Neuromorphic Computing. _Adv. Mater._ 2021, _33_ , 2007851. 

(67) John, R. A.; Yantara, N.; Ng, Y. F.; Narasimman, G.; Mosconi, E.; Meggiolaro, D.; Kulkarni, M. R.; Gopalakrishnan, P. K.; Nguyen, C. A.; De Angelis, F.; Mhaisalkar, S. G.; Basu, A.; Mathews, N. Ionotronic Halide Perovskite Drift-diffusive Synapses for Low-power Neuromorphic Computation. _Adv. Mater._ 2018, _30_ (51), 1805454. 

(68) Berruet, M.; Pérez-Martínez, J. C.; Romero, B.; Gonzales, C.; Al-Mayouf, A. M.; Guerrero, A.; Bisquert, J. Physical Model for the Current−Voltage Hysteresis and Impedance of Halide Perovskite Memristors. _ACS Energy Lett._ 2022, _7_ (3), 1214−1222. 

(69) Li, D.; Wang, Y.; Niu, T.; Chao, L.; Chen, Y. Device Physics of a Metal Halide Perovskite Diode: Decoupling of the Bulk from the Interface. _J. Phys. Chem. C_ 2022, _126_ (15), 6892−6903. 

(70) Saidaminov, M. I.; Abdelhady, A. L.; Murali, B.; Alarousu, E.; Burlakov, V. M.; Peng, W.; Dursun, I.; Wang, L.; He, Y.; Maculan, G.; Goriely, A.; Wu, T.; Mohammed, O. F.; Bakr, O. M. High-Quality Bulk Hybrid Perovskite Single Crystals within Minutes by Inverse Temperature Crystallization. _Nat. Commun._ 2015, _6_ (1), 7586. 

(71) Spanopoulos, I.; Ke, W.; Stoumpos, C. C.; Schueller, E. C.; Kontsevoi, O. Y.; Seshadri, R.; Kanatzidis, M. G. Unraveling the Chemical Nature of the 3D “Hollow” Hybrid Halide Perovskites. _J. Am. Chem. Soc._ 2018, _140_ (17), 5728−5742. 

(72) Hohenberg, P.; Kohn, W. Inhomogeneous Electron Gas. _Phys. Rev._ 1964, _136_ (3B), B864. 

(73) Kohn, W.; Sham, L. J. Self-Consistent Equations Including Exchange and Correlation Effects. _Phys. Rev._ 1965, _140_ (4A), A1133. (74) Blöchl, P. E. Projector Augmented-Wave Method. _Phys. Rev. B_ 1994, _50_ (24), 17953. 

(75) Kresse, G.; Furthmuller,̈ J. Efficient Iterative Schemes for Ab Initio Total-Energy Calculations Using a Plane-Wave Basis Set. _Phys. Rev. B_ 1996, _54_ (16), 11169. 

(76) Perdew, J. P.; Burke, K.; Ernzerhof, M. Generalized Gradient Approximation Made Simple. _Phys. Rev. Lett._ 1996, _77_ (18), 3865. 

(77) Monkhorst, H. J.; Pack, J. D. Special Points for Brillouin-Zone Integrations. _Phys. Rev. B_ 1976, _13_ (12), 5188. 



#### **Recommended by ACS** 

**Intrinsic Ion Migration Dynamics in a One-Dimensional Organic Metal Halide Hybrid** 

Zhenqi Hua, Peng Xiong, et al. OCTOBER 14, 2022 ACS ENERGY LETTERS READ 



###### **Degradation of Perovskite Photovoltaics Manifested in the Cross-Sectional Potential Profile Studied by Quantitative Kelvin Probe Force Microscopy** 

Maki Hiraoka, Yasuhiro Shirai, et al. APRIL 08, 2022 ACS APPLIED ENERGY MATERIALS READ 



**How Hole Injection Accelerates Both Ion Migration and Nonradiative Recombination in Metal Halide Perovskites** Chuan-Jia Tong, Oleg V. Prezhdo, et al. APRIL 01, 2022 JOURNAL OF THE AMERICAN CHEMICAL SOCIETY READ 



###### **Charge Carrier Dynamics in Co-evaporated MAPbI3 with a Gradient in Composition** 

Jiashang Zhao, Tom J. Savenije, et al. MAY 18, 2022 ACS APPLIED ENERGY MATERIALS READ 



**Get More Suggestions >** 

**3414** 

https://doi.org/10.1021/acsenergylett.2c01663 _ACS Energy Lett._ 2022, 7, 3401−3414 

