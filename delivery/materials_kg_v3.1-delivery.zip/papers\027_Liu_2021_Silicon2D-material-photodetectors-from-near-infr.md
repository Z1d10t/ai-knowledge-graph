# Silicon/2D-material photodetectors: from near-infrared to mid-infrared

| 字段 | 内容 |
|---|---|
| 期刊 | Light: Science & Applications |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 410 |
| 作者 | Chao-Yue Liu, Jingshu Guo, Laiwen Yu, Jiang Li, Ming Zhang, Huan Li, Yao-Cheng Shi, Daoxin Dai |
| DOI | 10.1038/s41377-021-00551-4 |
| 源文件 | 027_Liu_2021_Silicon2D-material-photodetectors-from-near-infr.pdf |

---
Official journal of the CIOMP 2047-7538 www.nature.com/lsa 

Liu et al. Light: Science & Applications (2021) 10:123 https://doi.org/10.1038/s41377-021-00551-4 

O <u>p e n</u> A c c e s s 

## R E V I E W A R T I C L E 

# Silicon/2D-material photodetectors: from nearinfrared to mid-infrared 

Chaoyue Liu<sup>1</sup> , Jingshu Guo 1, Laiwen Yu1, Jiang Li1, Ming Zhang1,2, Huan Li 1, Yaocheng Shi1,2 and Daoxin Dai1,2 

### Abstract 

Two-dimensional materials (2DMs) have been used widely in constructing photodetectors (PDs) because of their advantages in flexible integration and ultrabroad operation wavelength range. Specifically, 2DM PDs on silicon have attracted much attention because silicon microelectronics and silicon photonics have been developed successfully for many applications. 2DM PDs meet the imperious demand of silicon photonics on low-cost, high-performance, and broadband photodetection. In this work, a review is given for the recent progresses of Si/2DM PDs working in the wavelength band from near-infrared to mid-infrared, which are attractive for many applications. The operation mechanisms and the device configurations are summarized in the first part. The waveguide-integrated PDs and the surface-illuminated PDs are then reviewed in details, respectively. The discussion and outlook for 2DM PDs on silicon are finally given. 

### Introduction 

Two-dimensional materials (2DMs) are the layered materials in which the atoms of different layers interact though van der waals (vdW) forces instead of chemical bonds<sup>1</sup> . Nowadays, the 2DM family has been growing rapidly and becomes a rich new-material system, including semi-metal 2DMs<sup>2</sup> , semiconductor 2DMs<sup>3</sup> , and insulator 2DMs<sup>4</sup> . 2DMs are found to have some unique advantages for constructing photodetectors (PDs)<sup>5–7</sup> , which are the key components in various optoelectronic systems for optical communications, optical imaging, and optical sensing. Currently, various 2DMs have been demonstrated to enable the photodetection for ultrabroad wavelength bands from visible light to THz wave<sup>8</sup> . More importantly, 2DMs can be integrated flexibly with various material platforms, such as silicon and silicon compounds<sup>9,10</sup> , III–V materials<sup>11</sup> , as well as flexible materials<sup>7,12</sup> . In addition, 2DM PDs are free of dangling bonds which usually cause the surface 

Correspondence: Daoxin Dai (dxdai@zju.edu.cn) 

> 1State Key Laboratory for Modern Optical Instrumentation, Zhejiang Provincial Key Laboratory for Sensing Technologies, College of Optical Science and Engineering, International Research Center for Advanced Photonics, Zhejiang University, Zijingang Campus, Hangzhou 310058, China 

> 2Ningbo Research Institute, Zhejiang University, Ningbo 315100, China These authors contributed equally: Chaoyue Liu, Jingshu Guo 

recombination and the increment of dark current<sup>13</sup> . Among various 2DM PDs reported in the past years, the Si/2DM PDs have drawn much attention particularly because of the following two reasons<sup>9,10</sup> . First, silicon provides an excellent platform for realizing PD read-out circuits based on microelectronics, enabling optoelectronic integration to be realized potentially. Second, silicon photonics has also been developed successfully to provide high-performance, highintensity, and low-cost photonic integrated circuits due to its complementary-metal-oxide-semiconductor (CMOS)-compatibility<sup>14,15</sup> . As is well known, silicon photonics has been a key technology for many important applications in the nearinfrared (NIR, e.g., 1.31/1.55 μm) and mid-infrared (MIR) wavelength bands, such as optical communications/interconnects<sup>14,16</sup> , laser radar<sup>17</sup> , lab-on-chip for sensing<sup>18</sup> , optical computing<sup>19</sup> , and on-chip quantum photonics<sup>20</sup> . It is desired to achieve PDs on silicon working in broad operation wavelength bands, which are determined by the bandgap of the photodetection material<sup>21</sup> . As for the commonly used bulk semiconductor materials, silicon<sup>22</sup> and SiGe<sup>23</sup> can work in the wavelength band below 1.07 and 1.6 μm, respectively. While it is possible to realize PDs at the wavelength up to the MIR-band by using III–V materials<sup>24</sup> and HgCdTe<sup>25</sup> , their heterogeneous integration on silicon is usually difficult 

> © The Author(s) 2021 

> OpenAccess ThisarticleislicensedunderaCreativeCommonsAttribution4.0InternationalLicense,whichpermitsuse,sharing,adaptation,distributionandreproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/licenses/by/4.0/. 

Liu et al. Light: Science & Applications (2021) 10:123 

Page 2 of 21 

due to lattice mismatch. Fortunately, the emergence of 2DMs provides a new option to realize high-performance and low-cost PDs on silicon for broad wavelength bands. 

In this paper, we review the recent progresses of silicon/ 2DM PDs particularly working in the windows from the NIR-band of 1.31/1.55 μm to the MIR-band of 2–6 μm, which are very attractive for silicon photonics<sup>26</sup> . It is widely known that the big family of 2DMs includes several categories, such as single-element 2DMs, transition metal dichalcogenides (TMDCs), posttransition metal chalcogenides, tetradymites, and metal halides<sup>27,28</sup> . For example, single-element 2DMs mainly include group IV materials (e.g., graphene (G), silicene, germanene), group V materials (e.g., phosphorene, arsenene, antimonene), and group VI material (e.g., tellurene (Te)). Similar to bulk semiconductors, 2DMs usually have their bandgaps determining the wavelength band for photodetection, as summarized in refs.<sup>3,6</sup> . Interestingly, the bandgaps of 2DMs can be modified by band engineering<sup>3</sup> , such as strain engineering<sup>12</sup> , vertical electric field gating<sup>29</sup> , and chemical doping<sup>3</sup> . For the NIR/MIR photodetection, the commonly used 2DMs include graphene with a zero bandgap<sup>30</sup> , TMDCs with a bandgap of 1–2 eV<sup>31</sup> , and black phosphorus (BP) with a 0.3–2 eV bandgap<sup>32</sup> . In addition, some newly developed 2DMs are also available in potential, such as tellurene with a bandgap of 0.35–1.265 eV<sup>33</sup> , GeP with a bandgap of 0.51–1.68 eV<sup>34</sup> , and PtSe2 with a bandgap of 0–1.2 eV<sup>35</sup> . Here this review article is organized as follows. In “Fundamentals: mechanisms and structures” section, the fundamentals about 2DM PDs are discussed. In “Waveguide-integrated silicon-2DM PDs” and “Surface-illuminated Si/2DM PDs” sections, waveguide-integrated PDs and surface-illuminated PDs are summarized and reviewed, respectively. In “Perspective and outlook” section, we discuss the future development and the potential applications for 2DM PDs. Finally, a short conclusion is made in “Conclusions” section. 

### Fundamentals: mechanisms and structures 

In this section, the fundamentals of 2DM PDs are discussed and reviewed, including the working mechanisms and the device structures. Currently, there have been a number of review articles on 2DM PDs<sup>1,5,36</sup> . Here we aim to give a comprehensive discussion for Si/2DM PDs by clarifying several puzzles and distinguishing those similar mechanisms. In addition, a systematic classification of those 2DM PDs reported is also given in terms of the device structures, in which way the connection between the mechanisms and the device configurations is established. 

#### Working mechanisms 

As the field of 2DM PDs has been growing rapidly, the related technical routes have not been unified yet. The 

reported photodetection mechanisms for 2DM PDs include the photovoltaic (PV) effect<sup>5,21,28,36,37</sup> , the internal photon emission (IPE)<sup>38,39</sup> , the direct tunneling (DT)<sup>37</sup> , the Fowler-Nordheim (F-N) tunneling<sup>37</sup> , the photoconductive (PC) effect<sup>5,6,21,36,37</sup> , the photo-gating (PG) effect<sup>5,6,36</sup> , the bolometric (BOL) effect<sup>5,6</sup> , and the photothermoelectric (PTE) effect<sup>5,6</sup> . Most of these mechanisms have been applied or investigated very well in PDs based on traditional bulk materials, such as photoconductors, bolometers, or thermocouples. Figure 1 is a schematic diagram showing how the incident photons lead to electrical responses when working with different mechanisms. Basically speaking, when the incident photons are absorbed in the active region, the photo-excited electron-hole (e-h) pairs generate. The PDs can be classified into two types<sup>2</sup> , i.e., the photon-type and thermal-type, depending on whether the thermal relaxation process takes part in the photoelectric conversion process. 

#### Photon-type PDs 

For the photon-type PDs, the photoresponse is extracted by collecting the photo-excited carriers or detecting the photo-induced change of the channel conductivity. The former is available when working with the PV effect, IPE, DT, or F-N tunneling<sup>37</sup> , while the latter corresponds to the PC-type mechanisms (such as the PC effect and the PG effect) as well as the thermal-type BOL effect discussed below<sup>5,6,36</sup> . 

For the PV effect, which is a kind of fundamental mechanism for bulk semiconductor photodiodes, the photo-excited e-h pairs are usually driven by the built-in electric fields formed in p-n junctions<sup>5</sup> or Schottky junctions<sup>38</sup> , and then contribute to the photocurrents. A related concept is the impact ionization, which occurs when the photo-excited carriers are accelerated by a strong electric field and then lead to the carrier multiplications. It is the fundamental mechanism of avalanche photodetectors (APDs), and currently there have been several 2DM APDs reported<sup>40</sup> . 

The IPE is the major working mechanism of the traditional Schottky PDs with the metal-semiconductor configuration, and is also known as the thermionic emission<sup>39</sup> . In IPE-based 2DM PDs, the photo-excited hot carriers with sufficient energy may be emitted over the Schottky barrier, and then contribute to the photocurrent<sup>38</sup> , as shown in Fig. 1b. As is well known, conventional Schottky PDs usually have a low internal quantum efficiency of <1%<sup>37</sup> , since only a small part of hot electrons generated from the light absorption in metal can be emitted when their normal components of momentum correspond to the kinetic energy overcoming the Schottky barrier<sup>39</sup> . 

The DT and F-N tunneling are known as the operation mechanisms in traditional metal-insulator-semiconductor/ 

Liu et al. Light: Science & Applications (2021) 10:123 

Page 3 of 21 



<!-- Start of picture text -->
a Photovoltic (PV) effect b Internal photon  i Photothermoelectric (PTE) effect<br>emission (IPE)<br>Photocurrent Photocurrent Photocurrent S 1 S 2<br>Thermionic emission Photo-thermal-voltage<br>Seebeck<br>Schottky effect<br>junction<br>p – n  junction Schottky junction T e gradient field Photocurrent<br>direction<br>g Electron  h<br>e e Temperature  T e Carrier  Channel<br>mobility  conductivity<br>Incident photons carrier–carrier  increase  decrease decrease<br>h h scattering  Phonon<br>c Direct tunneling  emission  Bias voltage<br>(DT) Photo-excited<br>2DM e–h pairs Lattice temperature increase  Photocurrent<br>Johnson noise  Electrical<br>power increase response<br>e f Trap<br>states<br>Insulator Carrier density increase Photo-induced gating Thermomechanical stress<br>d F–N tunneling Channel conductivity  Channel conductivity  Mechanical<br>increase change resonator<br>Bias  Bias<br>voltage voltage Resonance  Electrical<br>frequency shift response<br>2DM Photocurrent Photocurrent<br>Photoconductive  Photogating Bolometric(BOL) effect<br>Insulator ( PC )  effect ( PG )  effect<br>Fig. 1 Summary of the working mechanisms of 2DM PDs. a–f Photon-type mechanisms: a The photovoltaic (PV) effect. The photo-excited e-h<br>pairs driven by the built-in electric fields contribute to the photocurrents. b The internal photon emission (IPE) effect. For example, in a G-Si Schottky<br>junction, the photo-excited hot carriers in graphene emitted over the Schottky barrier contribute to the photocurrent. c The direct tunneling (DT).<br>d The Fowler-Nordheim (F-N) tunneling. e The photoconductive (PC) effect. The carrier density increment leads to the change of channel<br>conductivity in a phototransistor. f The photo-gating (PG) effect. The photo-induced gating leads to the change of the channel conductivity in a<br>phototransistor. g The thermal relaxation process in 2DMs. The carrier–carrier scattering results in the increment of the electron temperature Te, and<br>then the optical/acoustic phonon emissions lead to the increment of lattice temperature TL. h, i Thermal-type mechanisms: h The bolometric (BOL)<br>effect. The increment of Te or TL can be extracted by different read-outs. i The photo-thermoelectric (PTE) effect. Here Seebeck effect plays a major<br>role. In the present example, S1 and S2 are respectively the positive and negative Seebeck coefficients.<br>Photocurrent<br>Photocurrent<br><!-- End of picture text -->

metal tunneling diodes<sup>37</sup> . Now these two mechanisms have also been applied in 2DM PDs by introducing a 2DMinsulator configuration<sup>41,42</sup> , as shown in Fig. 1c, d. The DT occurs when the insulator layer is very thin (e.g., a sub-5nm-thick SiO2 thin film<sup>37</sup> ). For the F-N tunneling, the photo-excited carriers can transit through the triangleshaped barrier of the insulator layer, which usually needs a high-bias voltage. For these tunneling PDs, the insulator layer can help reduce the dark current significantly to nanoampere scale<sup>41</sup> . 

For the PC-type mechanisms, the incident photons cause the change of the channel electrical conductivities σ, and the photocurrents can then be extracted by applying a bias voltage. The electrical conductivity σ for 2DMs is given as σ = neμ, where n, e, and μ are respectively the carrier density, the unit charge, and the carrier mobility. 

For both PC and PG effects, the conductivity σ changes due to the change of the photo-induced carrier density n. However, there are some obvious differences between them. For the PC effect, both the carrier density n and the conductivity σ increase when light illuminates. Correspondingly, the total current Itot under illumination is higher than the dark current Idark when the bias voltage is applied. In this case, the photocurrent given by Iph = Itot − Idark has the same direction as the applied bias voltage, as shown in Fig. 1e. In contrast, the key point in the PG effect is the trap states which may originate from the defects in 2DMs<sup>43</sup> (e.g., vacancies, dislocations<sup>44</sup> ), the 2DM/bulk-material junctions<sup>45</sup> , as well as the 2DM–2DM junctions<sup>46</sup> . For the PG effect, the electrons or holes of the photo-excited e-h pairs are trapped by the trap states with a long carrier life time τL, during which the other polarity 

Liu et al. Light: Science & Applications (2021) 10:123 

Page 4 of 21 

carriers can transit through the channel between the drain- and source-electrodes many times. Since the carrier life time τL is much longer than the carrier transit time τtr, there is usually a PC gain up to 5–10<sup>11</sup> (given by Gain = τL/τtr)<sup>6</sup> and thus the PG photoresponse is as high as 10–10<sup>10</sup> A W<sup>−1,5–7</sup> . In phototransistors with the source-, drain- and gate-electrodes, the trapped carriers causing the shift of the neutral-point gate-voltage can be treated as an extra gate voltage applied by the incident photons<sup>36</sup> . As a result, the direction of the photocurrent is decided by not only the applied bias voltage but also the original doping level of the channel 2DM. The process of the PG effect is also shown in Fig. 1f. 

#### Thermal-type PDs 

As illustrated in Fig. 1g, the thermal relaxation process in 2DMs is briefly described by a well-known two-temperature system<sup>47–49</sup> . After the photo-excited e-h pairs generate under illumination, the electron heating occurs by the carrier–carrier scattering, leading to the increment of the electron temperature Te. After then, the energy transfers from the electronic system to the phonon system by the electron-lattice cooling through optical/acoustic phonon emissions, making the lattice temperature TL increase. Such processes are usually very fast in some 2DMs. For example, in graphene, the electron-heating and electron-cooling processes happen in the time scales of ~50 fs and ~1 ps, respectively<sup>47</sup> . Benefiting from such ultrafast thermal relaxation dynamics, graphene bolometers can work with the bandwidths over tens of GHz, which are very different from their bulk-material counterparts with slow responses in the time scale of millisecond<sup>2,21</sup> . 

For the BOL effect, the photo-induced increase of the electron temperature Te can be transferred to the electric response via different readouts. For example, three typical bolometer readouts have been employed for graphene bolometers<sup>50</sup> , as shown in Fig. 1h. The first one is the thermal-resistance readout<sup>51</sup> . As the electron temperature Te increases under illumination, the carrier mobility μ decreases according to the relationship μ~Te−γ, where the coefficient γ is expected to be 1 for graphene in the acoustic phonon limited condition<sup>49</sup> . Accordingly, the 2DM electrical conductivity σ decreases. In this case, the photocurrent has an opposite direction to the applied bias voltage. The BOL responsivity is decided by the temperaturedependent conductivity Δσ/ΔTe, which is large at high doping level and low temperature<sup>52</sup> . The second one is Johnson noise thermometry readout<sup>53</sup> . As the electron temperature Te increases, the Johnson noise power increases and can be extracted by using microwave circuits. The third one is the thermomechanics readout<sup>54</sup> . As the electron temperature TL increases, the thermomechanical stress arises and leads to the resonance frequency shift of a 

mechanical resonator, which can be measured by applying a frequency-sweeping alternating voltage. In addition, graphene-superconductor junctions<sup>55</sup> and superconducting tunnel junctions<sup>56</sup> have also been available as possible alternatives. Generally speaking, for graphene bolometers, low-temperature operation is helpful to achieve competitive performances<sup>50</sup> . 

For the PTE effect, which is the dominated mechanism for lateral p-n configured graphene PDs<sup>57</sup> , the electron temperature Te increases with light illumination and the local photo-thermal-voltage generates through the Seebeck effect (see Fig. 1i). A non-zero channel- integral photo-thermal-voltage arises when either the Seebeck coefficient distribution or the electron temperature distribution is asymmetric. The photo-thermal voltage can drive the photocurrent without a bias voltage. The detailed processes for the PTE effect have been introduced in many works<sup>1,5,6,28,36</sup> . Even though the PDs based on the PTE effect can work fast, the responsivity is usually not high unless there are special structures for optical enhancement<sup>58</sup> . Besides, one should note that the bias voltage-insensitive PTE photoresponse usually becomes negligible compared to other photoconductive photoresponses in the PDs when bias voltages are applied<sup>58</sup> . 

#### Device configurations of 2DM PDs 

Since the first 2DM PD was demonstrated with a simple metal-graphene-metal (M-G-M) configuration in 2009<sup>59</sup> , lots of 2DM PDs have been proposed and demonstrated<sup>1,2,5,6,28,36</sup> , which is attributed partially to the flexibility of 2DMs. In this part, the device configurations for 2DM PDs are summarized and discussed. More importantly, the connection between the photodetection mechanisms and the device configurations is revealed with the configurations classified to three categories, i.e., the metal-2DM-metal type, the metal-2DM+X-metal type, and the 2DM-heterostructure type, as shown in Fig. 2. 

As the most fundamental configuration, the metal2DM-metal type usually has one or two gate electrodes for manipulating the 2DM doping properties, as shown in the left-bottom part of Fig. 2. Even for such a simple PD, there are usually multiple photodetection mechanisms involved. For example, for graphene phototransistors operating at a near-zero/zero-bias voltage, the PTE effect is the dominant contribution to the photoresponse in the laterally asymmetric channel<sup>60</sup> , the lateral p-n junction<sup>57,61</sup> , as well as the metal-graphene interface<sup>58,62</sup> . When the applied bias voltage increases, the PC-type effects with much higher responsivities than the PTE effect become dominant<sup>58,63</sup> . In addition, the PC effect and the BOL effect with contrary photocurrents compete, while the doping level in graphene is the key<sup>58,63</sup> . When the graphene doping level is lower, the longer carrier life time makes the PC effect stronger, meanwhile the BOL 

Liu et al. Light: Science & Applications (2021) 10:123 

Page 5 of 21 



<!-- Start of picture text -->
Metal-2DM+X-metal<br>2 D Black font:  Photon-type<br>1 D<br>CNT … Orange font:  Thermal-type<br>… Bulk<br>0 D<br>QDs Si Si/SiO2 Metal Detecting the photo-induced<br>… … conductivity change<br>X material<br>V bias<br>Direct detecting<br>2DM: G, TMDC, BP,… Photo-induced carriers<br>Metal-2DM-metal PC PG IPE 2DM-heterostructures<br>Bulk<br>Gate electrode<br>numbers: 0 ,1 ,2, …<br>V bias 2DM PV 2DM Stacks2DM and Si Metal/TiO… 2 Mixed-dimensional structures…<br>BOL DT G/SiO2<br>… ?<br>V bias<br>2DM: G, TMDC, BP, … PTE FNT 2DM: G, TMDC, BP,…<br>Fig. 2 The relation between the working mechanisms and the configurations of the 2DM PDs. Both metal-2DM-metal and metal-2DM+X-<br>metal configurations have a phototransistor structure featuring a 2DM channel. The former has a pure 2DM channel, while the latter has a 2DM<br>channel contacted with another specific material “X”, such as zero-dimensional (0D) quantum dots, 1D carbon nanotubes (CNTs), 2DMs, and even<br>bulk materials. In the 2DM-heterostructure configuration, the electrodes are connected to different materials. PV photovoltaic, IPE internal photon<br>emission, DT direct tunneling, F-N tunneling Fowler-Nordheim (F-N) tunneling, PC photoconductive, PG Photo-gating, BOL bolometric, PTE photo-<br>thermoelectric, QDs quantum dots, CNT carbon nanotubes.<br><!-- End of picture text -->

effect is weaker since the carrier mobility is less sensitive to temperature in this case<sup>52</sup> , and thus the PC effect dominates, and vice versa<sup>58,63</sup> . 

In contrast, TMDCand BP-PDs have different mechanisms from their graphene counterparts. In TMDC or BP p-n junctions formed by two separated gate electrodes, the photocurrents originating from the PV effect were observed<sup>64,65</sup> . For a regular single-gate phototransistor, it has been reported that all the PC-, PG-, BOL-, and PTE-effects partially contribute to photodetection. In many TMDC or BP phototransistors, there existed some structural defects and thus some trap states at the band tails were introduced. Such devices usually have photoresponses dominated by the PG effect<sup>43,66–69</sup> . On the other hand, in some phototransistors with lightly doped TMDC or BP, the PC effect<sup>43,70</sup> or the PV effect in the PC mode<sup>67,71,72</sup> happens, similar to their graphene counterparts. In contrast, the BOL effect was found to be dominant for those phototransistors based on heavily doped BP<sup>71</sup> . Furthermore, the PTE effect and the BOL effect were found to contribute dominantly to the low-bias (<0.5 V) and high-bias photoresponses of BP phototransistors, respectively<sup>49</sup> . According to ref.<sup>73</sup> , the photoresponse at the BP-metal interface is usually dominated by the PV effect or the PTE effect, depending on the band bending. When the band bending is significant, the PV effect is the dominant. Otherwise, the dominant is the PTE effect. 

Figure 2 also shows the PDs based on the metal-2DM +X-metal configuration, which consists of a 2DM channel contacted with another specific material “X”, such as zero-dimensional (0D) quantum dots<sup>74,75</sup> , 1D carbon nanotubes (CNTs)<sup>76</sup> , 2DMs<sup>46,77</sup> , and even bulk materials<sup>45,78–81</sup> . Light absorption may occur in the 2DM channel region<sup>78,80,81</sup> or the X-material region<sup>45,46,74,76,79</sup> . Typically, the specific material X contacting the 2DM channel plays the role of introducing trap states. In this case, it is usually the PG effect dominating the photoresponse with very high responsivity (e.g., 10–10<sup>10</sup> A W<sup>−1</sup> )<sup>45,46,74,76–79,81</sup> . 

When using the 2DM-heterostructure configuration (see Fig. 2), the signal and ground electrodes are respectively connected to the 2DM region and another material(s) region in contact, in which way a 2DM-heterostructure is formed. As shown in Fig. 2, the material(s) in contact with the 2DM can be two-, three-, or mixed-dimensional material(s). In order to realize high-performance PDs, various 2DMheterostructures have been developed with band engineering and carrier-dynamics manipulations, despite that the fabrication difficulty increases. As demonstrated, the PV effect has been often observed in 2DM-heterostructures of e.g., vertically<sup>82–84</sup> or laterally overlapped<sup>85</sup> G-TMDC-G, TMDC-G-TMDC<sup>86</sup> , TMDC-TMDC<sup>87,88</sup> , G-TMDC<sup>89,90</sup> , PTMDC-TMDC<sup>91</sup> , and BP-TMDC<sup>92–95</sup> . In these PDs, light is often absorbed by the non-zero bandgap 2DMs (e.g., 

Liu et al. Light: Science & Applications (2021) 10:123 

Page 6 of 21 

TMDC, BP), and then the photo-excited carriers are separated along the bended band which can be manipulated by applying a gate voltage. In order to understand the carrier dynamics in the 2DM-heterostructures, one should usually take the quantum effect into consideration<sup>87,96</sup> . More recently, Gao et al. reported an APD based on an InSe-BP heterojunction, in which carrier-dynamics multiplication was realized with the ballistic avalanche phenomena<sup>97</sup> . The PV effect also happens in 2DM/bulk-material heterostructures, and particularly the G-Si type has attracted the most attention. In G-Si heterostructures, the photo-excited carriers are separated along the bending bands formed in the Schottky junction when light is mainly absorbed in silicon. In contrast, the IPE effect becomes the dominant when light is mainly absorbed by graphene, in which case the hot carriers with sufficient energy are emitted over the G-Si Schottky barrier and then contribute to the photocurrent<sup>98,99</sup> . Similar processes also occur in G-TMDC-G<sup>100</sup> and G-hBN-G junctions (hBN is hexagonal boron nitride)<sup>101</sup> . For the G-hBN-G junctions operating with highbias voltages, the photoresponse may also come from the tunneling effects, namely the DT and F-N tunneling<sup>41</sup> . The photoresponse based on the tunneling effects was also achieved in some other 2DM-insultor-2DM/bulk-material configurations, e.g., G-hBN-MoS242,102. 

In addition, recently Lee et al. reported a broken-gap SnSe2-MoTe2 heterojunction, which forms an Ezaki diode. In this case, the photoresponse is contributed from both the PV effect and the F-N tunneling<sup>91</sup> . Besides, the PG effect-based photoresponses were also observed in 2DM-heterostructure PDs, such as BP-MoS2 heterostructure PDs<sup>92</sup> and laterally overlapped TMDC-BPTMDC bipolar phototransistors<sup>93</sup> . In these PDs, there may be trap states originating from the defect in materials or heterostructure interfaces, resulting in the PG effectbased photoresponse. More recently, a grapheneinsulator-metal PD was demonstrated with graphene covered by colloidal quantum dots (CQDs), showing an interesting mixed-photoresponse mechanism<sup>103</sup> . In this PD, the charge trapping upon light absorption in the CQDs layer induces a shift of the chemical potential of graphene (which is analogous to the PG effect). Then the photocurrent generates from the change of the current flowing across the graphene-insulator-metal structure, through the F-N tunneling effect and/or the IPE effect. 

### Waveguide-integrated silicon-2DM PDs 

As is well known, a 2DM layer usually has quite limited absorption for normal-incident light. For example, the absorption ratio is about 2.3% for single-layer graphene. Fortunately, it is possible to strongly enhance the interaction between a 2DM layer and the optical modal field propagating along an optical waveguide by extending the interaction length<sup>104</sup> . 

With the great enhancement of light-matter interaction, the waveguide-integrated silicon-2DM PDs have attracted much attention for the potential applications in various functional photonic integrated circuits for e.g., optical communications and interconnects<sup>105</sup> . In this section, recent progresses of the popular waveguide-integrated silicon-2DM PDs are reviewed and summarized, including the metal-2DM-metal PDs in “Metal-2DM-metal PDs” section, as well as the 2DM-heterostructure PDs in “2DM-heterostructure PDs” section. 

#### Metal-2DM-metal PDs 

Figure 3 shows the representative metal-2DM-metal PDs with various materials as well as different mechanisms. Among them, it can be seen that the M-G-M PDs<sup>58,60,106–119</sup> are very popular because the fabrication process is relatively easy. For M-G-M PDs, the PV effect is hardly observed because the life time of the photogenerated carriers in graphene is very short (~2 ps<sup>120</sup> ). When the channel length is reduced to as short as ~100 nm, the PV effect becomes dominant for the photoresponse, which happens when using a metal-air-metal plasmonic waveguide, as shown in Fig. 3a. In this case, an ultra-short channel (~120 nm) and 19-μm-long PD was demonstrated with a responsivity of 360 mA W<sup>−1</sup> at 2.2 V bias voltage as well as a bandwidth of >110 GHz. In contrast, the BOL effect is widely observed in the M-G-M PDs when a bias voltage is applied. For example, Ma et al. presented a 6-μm-long M-G-M PD integrated with bowtie-shaped metallic nanostructures, as shown in Fig. 3b, exhibiting a high external responsivity of 0.5 A W<sup>−1</sup> under −0.4 V bias voltage and a frequency response exceeding 110 GHz. 

On the other hand, for M-G-M PDs, typically the resistance is 10<sup>2</sup> –10<sup>3</sup> Ω, and correspondingly the dark current might reach the level of ~mA even when the bias voltage is below 1 V. In order to reduce the dark current, it is preferred to develop PDs working under near-zero bias with the PTE effect. As demonstrated previously, the PTE photoresponse can be generated by introducing an asymmetric distribution of electron temperature Te58,60 or an asymmetric distribution of chemical doping in 2DMs<sup>112</sup> . Figure 3c shows a representative example of the former case. In such a one-gate configuration, the laterally asymmetric light absorption leads to an asymmetric distribution of electron temperature Te. The PD was measured with a bandwidth of 42 GHz and a responsivity of 78 mA W<sup>−1</sup> at zero bias, which is impressive compared to its counterparts at zero bias. 

For the case with an asymmetric distribution of chemical doping in 2DMs, the lateral p-n junction structure constructed with two gate electrodes is a popular design. In such PDs, both the light absorption and the electron temperature Te distribute symmetrically. However, the 

Liu et al. Light: Science & Applications (2021) 10:123 

Page 7 of 21 



<!-- Start of picture text -->
a b c d<br>Gate hBN/Graphene/hBN graphene VG2 VG2<br>Drain Cr/Au AI2O3 VG1 VG1<br>Source hBN Si BOX W Drain Source<br>R Drain Source<br>X y SiO2 Waveguide K<br>z PIN PTRANS<br>Si<br>Si<br>e f Vds g h<br>SignalSi Ground Ground xz y Vlg Graphite Vrg MoTe2 b c<br>Signal Gate S Top h-BN D<br>Ground h  = 220 nm z<br>Al2O3on Si w  = 500 nm<br>y<br>SiO2 Graphene Si x<br>Silicon Phc waveguide<br>i Graphene BP j BP Vbias k<br>G<br>D Z<br>S Si X Y<br>Al2O3<br>SiO2<br>Si<br>Ground<br>θ AC<br>Waveguide<br>Source<br>Gate<br>Drain<br>PMMA<br>Ti/Au<br>Grating<br>Silicon Slab<br><!-- End of picture text -->

Fig. 3 The waveguide-integrated Si/2DM PDs with metal-2DM-metal configurations. a A graphene plasmonic PD working with the PV effect. b A plasmonically enhanced graphene PD working on the BOL effect. c A horizontally asymmetric graphene PD with one gate electrode based on the PTE effect. d A microring resonator-integrated two-gate graphene PD based on the PTE effect. e The Si-G hybrid plasmonic waveguide PDs operating at 1.55 and 2 μm. f A two-gate MoTe2 PD operating at 1.16 μm based on the PV effect. g A strain-engineered MoTe2 PD integrated on a microring resonator operating at 1.55 μm. h A PtSe2 PD operating at 1.55 μm. i A black-phosphorus PD operating at 1.55 μm with 3 GHz bandwidth. j A black-phosphorus PD operating at 2 μm. k A PG effect-based black phosphorus PD operating at the wavelength band of 3.68–4.03 μm. Figures reproduced with permissions from: a ref.<sup>108</sup> ,<sup>©</sup> 2020 De Gruyter, Berlin/Boston, under Creative Commons Attribution 4.0 International license (CC BY 4.0, https://creativecommons.org/licenses/by/4.0/); b ref.<sup>119</sup> ,<sup>©</sup> 2018 American Chemical Society; c ref.<sup>60</sup> ,<sup>©</sup> 2015 American Chemical Society; d ref.<sup>115</sup> , under Creative Commons Attribution 4.0 International license (CC BY 4.0, https://creativecommons.org/licenses/by/4.0/); e ref.<sup>58</sup> ,<sup>©</sup> 2020 Springer Nature Limited, under Creative Commons Attribution 4.0 International license (CC BY 4.0, https://creativecommons.org/licenses/by/4.0/); f ref.<sup>64</sup> ©2017 Springer Nature Limited. g ref. 70, ©2020 Springer Nature Limited; h ref. 121, ©2020 American Chemical Society; i ref. 71, ©2015 Springer Nature Limited; j ref.<sup>72</sup> ,<sup>©</sup> 2019 John Wiley & Sons, Inc. k ref.<sup>68</sup> ,<sup>©</sup> 2018 American Chemical Society. Further permissions related to the figures should be directed to the copyright holders. 

Seebeck coefficients of the left and right half-parts have opposite signs. As a result, the PTE-voltages for the left and right half-parts can be accumulated instead of canceled. In order to enhance the light-graphene interaction, one can integrate the lateral p-n junction structure with a nano-slot waveguide<sup>112</sup> , a slow-light photonic-crystal waveguide<sup>113</sup> , a plasmonic waveguide<sup>114</sup> , as well as a microring resonator shown in Fig. 3d<sup>115</sup> . In ref.<sup>115</sup> , the light absorption ratio for the ~6 µm-long single-layer graphene sheet is >90%, and the demonstrated PD has a high zero-bias response of 90 V W<sup>−1</sup> and a bandwidth of 12 GHz. Recently, silicon-graphene hybrid plasmonic waveguide PDs working on 1.55 µm and beyond were demonstrated, as shown in Fig. 3e. Under a non-zero-bias voltage, the BOL effect and the PC effect were found to dominate the photoresponses in highly and lightly doped graphene, respectively. The demonstrated PD operating at 2 μm has a responsivity of 70 mA W<sup>−1</sup> at −0.3 V bias voltage and a bandwidth of >20 GHz. When operating at 

1.55 μm, the PD has a responsivity of 400 mA W<sup>−1</sup> at −0.3 V bias voltage and a bandwidth of over 40 GHz. In short, even though M-G-M PDs have shown advantages in high speed, it is still much desired to achieve low dark current, low thermal noise, and high responsivity simultaneously. 

As alternatives, the 2DMs with non-zero bandgaps (e.g., TMDC and BP) have also been utilized for realizing metal-2DM-metal PDs with lower dark currents than their graphene counterparts. As shown in Fig. 3f, Bie et al. presented a metal-MoTe2-metal PD with a lateral p-n junction structure, in which the PV effect dominantly contributes to the photoresponse. The responsivity is 4.8 mA W<sup>−1</sup> at zero bias and the bandwidth is 200 MHz when operating at the wavelength of 1.16 μm (which is slightly shorter than the intrinsic absorption edge wavelength ~1.24 μm for MoTe2). Recently, the MoTe2 bandgap was modulated successfully through the strain engineering, and a microring resonator-integrated MoTe2 

Liu et al. Light: Science & Applications (2021) 10:123 

Page 8 of 21 

PD was demonstrated for the wavelength band of 1.55 μm. The PD exhibited a responsivity of about 0.5 A W<sup>−1</sup> at −2 V bias, a low dark current of ~13 nA, a noise equivalent power (NEP) of 90 pW Hz<sup>−1/2</sup> and a bandwidth of 35 MHz. More recently, PtSe2 has attracted intensive attention as a type of wide-sense TMDC 2DM with high chemical stability in air as well as thick-dependent nonzero-bandgap of 0.1–1.2 eV, which enables a wide operation wavelength range. As shown in Fig. 3h, Wang et al. demonstrated a Si3N4-waveguide-integrated PtSe2 PD based on the bound-states-in-continuum scheme. This PD has a responsivity of ~12 mA W<sup>−1</sup> at 8 V bias voltage with a dark current of 317 nA and a large bandwidth of 35 GHz<sup>121</sup> . 

BP has also been extensively studied for realizing PDs, and waveguide-integrated BP PDs have been demonstrated with the PV effect, as shown in Fig. 3i<sup>39</sup> . The demonstrated PD with a 11.5-nm-thick BP sheet has an extrinsic responsivity of 19 mA W<sup>−1</sup> , a low dark current of 220 nA, and a large bandwidth of 3 GHz at 1550 nm. A 3 Gbit s<sup>−1</sup> data transmission was also performed with a low optical power of 1.2 mW. Later, silicon-BP hybrid waveguide PDs were realized for the wavelength band of 2 μm, as illustrated in Fig. 3j<sup>71</sup> . These PDs performed responsivities of 21–307 mA W<sup>−1</sup> at 0.4 V bias voltage and bandwidths of 0.5–1.33 GHz, meanwhile the data transmission with a bit rate of 4.0 Gbit s<sup>−1</sup> was demonstrated successfully. In Fig. 3k, Huang et al. reported waveguide-integrated BP PDs operating at 3.68–4.03 μm, in which the PG effect plays a 

major role and results in high-gain photoresponses<sup>68</sup> . When operating at a bias of 1 V, the BP PDs have responsivities of 23 A W<sup>−1</sup> and 2 A W<sup>−1</sup> for the wavelengths of 3.68 μm and 4 μm, respectively. Meanwhile, the NEPs were measured to be ~ 0.01–1 nW Hz<sup>−1/2</sup> at room temperature. Compared to the M-G-M PDs, the metal-TMDC-metal (M-TMDC-M) and metal-BP-metal (M-BP-M) PDs have smaller bandwidths, much lower dark currents, and comparable responsivities unless the PG effect dominates. 

#### 2DM-heterostructure PDs 

In recent years, waveguide-integrated 2D-Heterostructure PDs have attracted intensive attention and several representative examples are shown in Fig. 4. The G-Si heterostructure is one of the most widely used configurations, and most G-Si PDs have limited bandwidths (<MHz) due to the long transit time in silicon. Fortunately, it is possible to achieve very fast PDs with the help of silicon doping engineering. For example, Li et al. demonstrated a high-speed waveguide- integrated G-Si p- i-n photodiode by utilizing the IPE effect, as depicted in Fig. 4a, in which fast carrier transit in silicon is enabled by silicon doping engineering. When operating at 1550 nm, the fabricated PD exhibited a relatively low responsivity of 11 mA W<sup>−1</sup> under zero bias and >50 GHz RF-limited bandwidth. In particular, the G-Si Schottky junction helps suppress the thermal noise, while the dark current becomes zero for zero-bias operation. Therefore, more than 50 dB converted signal-to-noise ratio (SNR) was 



<!-- Start of picture text -->
a b Schottky<br>photodetector<br>PhC WG 415 nm Ohmic Single layer<br>contact graphene<br>+ -<br>250 nm<br>Metal G Metal<br>z p- Si 5  i- μ Sim n- Si 250 nm<br>y LOCOS<br>waveguide<br>x Si substrate<br>c d<br>Signal<br>Au top contact Graphene hBN<br>Width,  w MoS2<br>Length,  L<br>SiO2 d GND<br>MoTe2 Si3N4<br>MoTe2 Si Au Au<br>Graphene Si SIO2<br>SOI<br>Graphene<br>BOX<br>Au<br>AI<br><!-- End of picture text -->

Fig. 4 The waveguide-integrated Si/2DM PDs with heterostructure configurations. a A high-speed G-Si PD with p-i-n doping distributions for both Si and graphene. b A Si-G plasmonic Schottky photodetector. c A MoTe2-G heterostructure PD. d A G-hBN-G heterostructure PD. Figures reproduced with permissions from: a ref.<sup>122</sup> ,<sup>©</sup> 2018 Springer Nature Limited, under Creative Commons Attribution 4.0 International license (CC BY 4.0, https://creativecommons.org/licenses/by/4.0/); b ref.<sup>99</sup> ,<sup>©</sup> 2016 American Chemical Society; c ref.<sup>90</sup> ,<sup>©</sup> 2020 Springer Nature Limited; d ref.<sup>123</sup> ;<sup>©</sup> 2019 The Optical Society, under Creative Commons Attribution 4.0 International license (CC BY 4.0, https://creativecommons.org/licenses/by/4.0/). Further permissions related to the figures should be directed to the copyright holders. 

Liu et al. Light: Science & Applications (2021) 10:123 

Page 9 of 21 

achieved even at 40 GHz<sup>122</sup> . In order to achieve an improved responsivity, a metal-G-Si PD was reported with an interesting configuration, in which a graphene sheet was introduced to work with a conventional metal-Si Schottky PD, as shown in Fig. 4b. When this PD operating at 1 V reverse bias, the responsivity is about 85 mA W<sup>−1</sup> , which is one order of magnitude higher than metal-Si Schottky PDs<sup>99</sup> . 

The 2DM-heterostructures have also been integrated with silicon photonic waveguides for on-chip photodetection. As shown in Fig. 4c, a 33-μm-long waveguide-integrated MoTe2-G heterostructure PD was demonstrated with an external responsivity of 0.2 A W<sup>−1</sup> under −3V bias voltage at 1300 nm<sup>90</sup> . Here the vertically stacked structure design minimizes the path length of the carrier transit in TMDCs, which contributes to achieve a bandwidth as high as ~24 GHz. For this PD, the normalized photocurrent to the dark current ratio (NPDR) is 100–1000 mW<sup>−1</sup> under a bias voltage of −0.5–0 V<sup>90</sup> . More recently, a Si3N4 waveguideintegrated G-hBN-G heterostructure tunneling photodiode was demonstrated with a responsivity of ~0.24 A W<sup>−1</sup> at ~1550 nm, as shown in Fig. 4d. This PD has a bandwidth of 28 GHz and a good NPDR of 10<sup>4</sup> –10<sup>5</sup> mW<sup>−1</sup> under 0.5–10 V bias voltage, benefiting from the dark current suppression by the tunneling barrier<sup>123</sup> . It can be seen that the PDs with 2DM-heterostructures have great potentials for realizing high sensitivity and broad bandwidth simultaneously. 

Summary for waveguide-integrated 2DM PDs on silicon 

Table 1 gives a summary for the performances of waveguide-integrated 2DM PDs on silicon. It can be seen that currently most works focus on the wavelength band of 1550 nm. Among them, the M-G-M PDs provide an interesting option enabling bandwidths even as high as 110 GHz<sup>108,119</sup> . On the other hand, the p-n graphene homojunction based on the PTE effect is an attractive option because zero-bias operation can be achieved without any dark current shot noise. The state-of-the-art zero-bias responsivity has reached 90 V W<sup>−1</sup> , enabling high sensitivity comparable to the counterpart based on the mature semiconductor technology<sup>115</sup> . In contrast, the PDs based on the BOL effect can realize high responsivity at moderately low-bias voltages as well as low input optical power, for which unfortunately the photodetection linearity still needs much improvement<sup>58,119</sup> . For the M- TMDC-M and M-BP-M PDs based on the PC or PV effects, the responsivities are similar while the bandwidths are small when compared to M-G-M PDs. For those PDs based on the PG effect, the responsivities can be up to ~10 A W<sup>−1</sup> in cost of small bandwidths<sup>69</sup> . Currently, the 2DM-heterostructure configuration was recognized as one of the most promising options because the device responsivity are comparable to that of the metal-2DM- 

metal PDs (~10–10<sup>2</sup> mA W<sup>−1</sup> ), meanwhile the noise can be suppressed greatly with the help of the junction structures<sup>89,90,98,99,122,123</sup> . 

In order to further give a comprehensive comparison on the PD performances, a summary map is given in Fig. 5, where the x-axis and y-axis, respectively, denote the NEP and the bandwidth. Here the NEP is calculated by considering the dark current shot noise and the thermal noise, as discussed in Supplementary Note 1.3. As depicted in Fig. 5, the M-G-M PDs have unique advantages in the scenarios when ultra-large bandwidths (~100 GHz) are required. However, the PD sensitivity is still quite limited. In contrast, better NEP can usually be achieved for M-TMDC-M or M-BP-M PDs. A promising option is using 2DM-heterostructures, which might enable a large bandwidth of ~50 GHz and a high sensitivity of ~10<sup>−13</sup> –10<sup>−11</sup> W Hz<sup>−1/2</sup> . 

### Surface-illuminated Si/2DM PDs 

In this section, we give a review for the recent progresses of surface-illuminated Si/2DM PDs, which have potentially important applications in free-space optical communication and optical imaging. Here we focus on the devices working at NIR and MIR wavelengths, including the metal-2DM-metal PDs and metal-2DM+Xmetal PDs in “Metal-2DM-metal and metal-2DM+Xmetal PDs” section as well as the 2DM-heterostructure PDs in “2DM-heterostructure PDs” section. Furthermore, “PDs and arrays for image sensing” section gives a summary for the reported image-sensor array chips<sup>124,125</sup> and proof-of-concept image systems<sup>126,127</sup> based on surfaceilluminated 2DM PDs. Finally, a comprehensive summary for these PDs is given in “Summary of surface-illuminated 2DM PDs on silicon” section. 

#### Metal-2DM-metal and metal-2DM+X-metal PDs 

Figure 6 shows several representative surfaceilluminated metal-2DM-metal and metal-2DM+X-metal PDs. As seen in Fig. 6a, a graphene PD using engineered nanostructures based on gold-patched graphene nanostrips was demonstrated with high PC gain, benefiting from the reduction of photocarrier transport time through the electrodes. This device enables broadband photodetection from the visible to the infrared regime. The responsivities were measured to be 0.6 A W<sup>−1</sup> at 0.8 μm and 11.5 A W<sup>−1</sup> at 20 μm, while a large bandwidth of over 50 GHz was measured at 0.8 μm. Unfortunately, the photocurrent saturates when the input power increases to only ~10 μW (at 0.8 μm), which may be attributed to the limited active region areas and the density of states in graphene<sup>128</sup> . 

Figure 6b shows a hot-electron graphene bolometer based on Johnson noise read-out at 1531 nm<sup>53</sup> . As is well known, the enhancement of the light-2DM interaction is 

Liu et al. Light: Science & Applications (2021) 10:123 

Page 10 of 21 

Table 1 Summary of waveguide-integrated Si/2DM PDs 

|Structure|λ|Mechanism|Responsivity||Bias voltage||Bandwidth<sup>a</sup>|Refs.|
|---|---|---|---|---|---|---|
|M-G-M|~1.35μm|PV|0.2 A W<sup>−1</sup>|0.5 V|–|106|
|||BOL|0.67 A W<sup>−1</sup>||||
|M-G-M|~1.55μm|PV|7–50<sup>b </sup>mA W<sup>−1</sup>|0 V|3–110 GHz|107–111|
||||57–108 mA W<sup>−1</sup>|1 V|||
||||360 mA W<sup>−1</sup>|2.2 V|||
|M-G-M|~1.55μm|PTE|35–78 mA W<sup>−1</sup><br>3.5–90 V W<sup>−1</sup>|0 V|12–67 GHz|60,112–117|
|M-G-M|~1.55μm|BOL|90–500 mA W<sup>−1</sup>|0.3–0.4 V|40–110 GHz|58,119|
|M-G-M|~2μm|BOL|45–70 mA W<sup>−1</sup>|0.3 V|20 GHz|58|
|M-G-M|~3.8μm|No stated|2.2 mA W<sup>−1</sup>|1 V|–|160|
|M-MoTe2-M|~1.16μm|PV|4.8 mA W<sup>−1</sup>|0 V|200 MHz|64|
|M-MoTe2-M|~1.55μm|PC|468 mA W<sup>−1</sup>|2 V|35 MHz|70|
|M-PtSe2-M|~1.55μm|PC|12 mA W<sup>−1</sup>|8 V|35 GHz|121|
|M-BP-M|~1.55μm|PV|135–657 mA W<sup>−1</sup>|0.4–2 V|3 GHz|71|
|M-BP-M|~1.55μm|PC|6.25 A W<sup>−1</sup>|0.7 V|150 MHz|161|
|M-BP-M|3.68μm|PG|0.7–23 A W<sup>−1</sup>|1 V|–|68|
||4μm||0.5–2 A W<sup>−1</sup>||||
|M-BP-M|~3.825μm|PG|0.1–11.31 A W<sup>−1</sup>|0.5 V|550 Hz|69|
|M-BP-M|2μm|PV|0.026–0.307 A W<sup>−1</sup>|0.4 V|0.5–1.33 GHz|72|
|MoTe2-G|~1.31μm|PV; PC|23–400 mA W<sup>−1</sup>|3 V|0.5 GHz|89|
|MoTe2-G|1.26–1.34μm|PV; PC|~ 7–150 mA W<sup>−1</sup>|0.6 V|12–46 GHz|90|
|G-hBN-G|~1.55μm|DT; F-N tunneling|240 mA W<sup>−1</sup>|10 V|28 GHz|123|
|G-Si|2.75μm|IPE|0.13 A W<sup>−1</sup>|1.5 V|–|98|
|Au-G-Si|~1.55μm|IPE|85 mA W<sup>−1</sup>|1 V|–|99|
|G-Si|~1.55μm|IPE|11 mA W<sup>−1</sup>|0 V|>50 GHz|122|



PV photovoltaic, IPE internal photon emission, DT direct tunneling, F-N tunneling, Fowler-Nordheim (F-N) tunneling, PC photoconductive, PG Photo-gating, BOL bolometric, PTE photo-thermoelectric. aThe measured bandwidths may be setup limited. bIn ref. 107, the graphene has two or three layers. 

really important for surface-illuminated PDs due to the ultra-thin light absorption layer. As shown in Fig. 6b, a suspended silicon photonic-crystal cavity enables 45% light absorption in graphene at the resonance wavelength. This device has a NEP of ~10 pW Hz<sup>−1/2</sup> and fast thermal relaxation less than 35 ps at 5 K (see Fig. 6b), which means that the bolometer has a large intrinsic bandwidth. In practice, the bandwidth is usually limited by the readout electronics. 

Recently CNTs were introduced for realizing a metalgraphene+CNT-metal PD working at 400–1550 nm, as shown in Fig. 6c. This PD based on the PG effect has a peak responsivity of over 100 AW<sup>−1</sup> , benefiting from high gain which however leads to a slow response time (~100 μs)<sup>76</sup> . Figure 6d shows another PD with the same 

type of configuration and the same mechanism (i.e., the PG effect). In this configuration, the graphene channel is sandwiched by Au-nanoparticles and the silicon substrate, while the plasmonic effect helps realize photon trapping and enhance light absorption in graphene. With such a design, this PD performed a high responsivity of 83 A W<sup>−1</sup> at 1550 nm and a response time of less 600 ns, which is outstanding among the PDs based on the PG effect<sup>78</sup> . As an alternative, the surface-illuminated M-TMDC-M PDs are also very popular<sup>6</sup> and most of them were demonstrated for visible light regarding the material bandgaps. On the other hand, it is still possible to extend the working wavelength range by utilizing some special approaches. For example, a ferroelectric-polymer-filmgated triple-layer MoS2 PD was demonstrated to work at 

Liu et al. Light: Science & Applications (2021) 10:123 

Page 11 of 21 



<!-- Start of picture text -->
10 12<br>[110]<br>[111]<br>Metal-Graphene-Metal [108]<br>10 11 (MoS2 on) G-hBN-G G-Si [112][60]<br>[113]<br>[114]<br>10 10 [116]<br>MoTe2-G [117]<br>[118]<br>[119]<br>10 9 [58]<br>[58]<br>[115]<br>MoTe2-G<br>[64]<br>10 8 [70]<br>[121]<br>Metal-BP-Metal Metal-TMDC-Metal [71]<br>[161]<br>10 7 [69]<br>[72]<br>10 3 [89]<br>[90]<br>[122]<br>[123]<br>10 2<br>10 -13 10 -12 10 -11 10 -10 10 -9 10 -8 10 -7<br>NEP(W Hz -1/2 )<br>Bandwidth (Hz)<br><!-- End of picture text -->

Fig. 5 Performance summary for the waveguide-integrated Si/2DM PDs. ■: photovoltaic (PV) effect, ●: photo-thermoelectric (PTE) effect, ▲: bolometric (BOL) effect, ♦: photoconductive (PC) effect, ⬟: Photo-gating (PG) effect, ◄: tunneling effects, ►: internal photon emission.(IPE) effect; blue: metal-graphene-metal (M-G-M); green: metal-TMDC-metal; black: metal-BP-metal; red: 2DM-heterostructure 

1550 nm, utilizing the ferroelectric polarization tuning for the bandgap of few-layer MoS2 (see Fig. 6e)<sup>81</sup> . 

BP is another promising candidate for NIR and MIR photodetection. As depicted in Fig. 6f, a M-BP-M PD at 3.39 μm was demonstrated. In this work, the dominated mechanisms are respectively the PV effect and the PG effect for the cases of intrinsic BP and moderately doped BP<sup>67</sup> . A BP PD can even work at wavelength as long as 7.7 μm by introducing a vertical electric field due to Stark effect with help of top and bottom gates (see Fig. 6g)<sup>29</sup> . For this PD, the NEPs under a bias voltage of 1.2 V are 0.03, 35, and 672 pW Hz<sup>−1/2</sup> for the wavelengths of 3.4, 5, and 7.7 μm, respectively, when operating with the corresponding optimal gate voltages. The corresponding dark currents are 8.6 × 10<sup>−4</sup> , 3.42, and 6.75 μA, as shown in Fig. 6g. The operation wavelengths of BP PDs can also be extended by chemical doping. For example, Amani et al. demonstrated two gate-photoconductors based on BP and black-PAs-alloy (b-PAs). The cut-off wavelength can be extended from 3.9 to 4.6 μm when replacing BP by b-PAs, as shown in Fig. 6h. These two PDs have peak specific detectivities of 6 × 10<sup>10</sup> cm Hz<sup>1/2</sup> W<sup>−1</sup> and 2.4 × 10<sup>10</sup> cm Hz<sup>1/2</sup> W<sup>−1</sup> at room temperature, respectively<sup>129</sup> . For another b-PAs phototransistor demonstrated in ref.<sup>130</sup> , the detection wavelength was extended to 8.05 μm. The 2DM tellurene has also been applied as a new photodetection material<sup>33,131</sup> . In ref.<sup>33</sup> , a Fabry-Perot (F-P) cavity-integrated metal-Te-metal PD was demonstrated at 

1–3.4 μm, showing an optimized room-temperature specific detectivity of 2 × 10<sup>9</sup> Jones at 1.7 μm. Later, another metal-Te-metal PD (shown in Fig. 6i) was reported with a peak extrinsic responsivity of 383 A W<sup>−1</sup> , 19.2, and 18.9 mA W<sup>−1</sup> at the wavelengths of 520 nm, 1.55, and 3.39 μm, respectively. In particular, this PD has a bandwidth of 37 MHz when operating at 1.55 μm<sup>131</sup> . 

#### 2DM-heterostructure PDs 

Various 2DM-heterostructure PDs have been developed in recent years. As depicted in Fig. 7a, Long et al. presented a PD based on the PV effect by using the MoS2-GWSe2 heterostructure<sup>86</sup> . This vdW heterostructure PD enables the photodetection in a broadband wavelength range from 400 to 2400 nm. Its specific detectivity is 10<sup>9</sup> –10<sup>10</sup> Jones at the NIR and MIR wavelength bands, while the bandwidth is ~6.5 kHz estimated from the timedependent photoresponse at 637 nm. Figure 7b shows a G-WSe2-G heterostructure PD<sup>100</sup> . When this PD operates beyond the absorption band for WSe2, light absorption in graphene is the key and the responsivity based on the IPE effect is 0.12 mA W<sup>−1</sup> , corresponding to an IQE of 2%. Meanwhile, the IPE effect is very fast with a charge injection time of ~47 ps<sup>100</sup> . The photoresponse can also be very fast in the time scale of picosecond when light absorption in WSe2 is the dominant at the wavelength band of <950 nm<sup>84</sup> . Recently, a CQD-G heterostructure PD was reported, as shown in Fig. 7c. For this PD, light is 

Liu et al. Light: Science & Applications (2021) 10:123 

Page 12 of 21 



<!-- Start of picture text -->
a b<br>1.0 4 100 10 3<br>30<br>1.01.0 32 Au Incident beam 8060 hBN-G-hBNAu LC 300 KCryoLNA 10 2 20<br>1.01.0 10 V bias V g SiOAuSi 2 4020 Si/HfO2 x Air/SiO2 SG BPMixer 10<br>Si<br>Diode Δ V bg = 0 V<br>1.0 –1 1 10 0 V bg Lock-in 10 1 10 100<br>Wavelength (μm) T s(K)<br>c d e f 3.39 μm IR laser<br>Light beam<br>Drain<br>Top gate Al SiO2<br>SourceP(VDF-TrFE) Si Au/Cr<br>SiO2 BP Si<br>A MoS2<br>g h i<br>hBNPt (top gate)D S V ds Vtg 1010 32 10 3 1010 1110 297K bP (100% P)bPAs (9% P/91% As)<br>BP 10 1 10 1 Tellurene<br>hBN Vbg 10 0<br>Si (back gate)SiO2 10 –1 10 –1 10 9 z y<br>10 –2 x arm-chair Ti/Au<br>X -direction 10 –3 10 8<br>3 4 5 6 7 8 1 2 3 4 5 6 7<br>Wavelength(μm) Wavelength (μm)<br>zig-zag<br>(ps)τ<br>–1/2NEP (pW Hz)<br>Responsivity (mA/W) Photoconductive gain<br>–1/2NEP (pW Hz) μDark current (A) 1/2–1D* (cm Hz)W<br><!-- End of picture text -->

Fig. 6 The surface-illuminated Si/2DM PDs with metal-2DM-metal configuration. a A wide-band plasmonic enhanced graphene PD and the measured responsivity/photoconductive-gain. b A cavity-coupled graphene bolometer with Johnson noise read-out. Left: the 3D schematic. Right: the NEP and thermal relaxation time of hot electrons as a function of lattice temperature. c A metal-graphene+X-metal configuration PD, for which X is carbon nanotube. d A short-wave infrared graphene PD with a plasmonic enhanced structure on channel. e A ferroelectric polarization gating MoS2 photodetector with an operation wavelength extended to 1.55 μm. f A mid-infrared black-phosphorus PD with a high gain. g A mid-infrared black-phosphorus PD with an operation wavelength extended to 7.7 μm by applying a vertical electric field. Left: the 3D schematic. Right: the NEP and dark current at different wavelengths. h The specific detectivities of the mid-infrared black phosphorus PD and black-PAs-alloy PD as a function of wavelength. i A short-wave infrared tellurene PD. Figures reproduced with permissions from: a ref.<sup>128</sup> ,<sup>©</sup> 2018 Springer Nature Limited, under Creative Commons Attribution 4.0 International license (CC BY 4.0, https://creativecommons.org/licenses/by/4.0/); b ref.<sup>53</sup> ,<sup>©</sup> 2018 Springer Nature Limited; c ref.<sup>76</sup> ,<sup>©</sup> 2015 Springer Nature Limited, under Creative Commons Attribution 4.0 International license (CC BY 4.0, https://creativecommons. org/licenses/by/4.0/); d ref.<sup>78</sup> ,<sup>©</sup> 2017 American Chemical Society; e ref.<sup>81</sup> .<sup>©</sup> 2015 John Wiley & Sons, Inc. f ref.<sup>67</sup> ,<sup>©</sup> 2016 American Chemical Society; g ref.<sup>29</sup> ,<sup>©</sup> 2017 Springer Nature Limited, under Creative Commons Attribution 4.0 International license (CC BY 4.0, https://creativecommons.org/ licenses/by/4.0/); h ref.<sup>129</sup> ,<sup>©</sup> 2017 American Chemical Society. i ref.<sup>131</sup> ,<sup>©</sup> 2019 American Chemical Society. Further permissions related to the figures should be directed to the copyright holders. 

absorbed by the CQDs on graphene. Then the charge trapping in the CQDs induces a shift of the chemical potential in graphene, resulting in the change of the current flowing across the G-insulator-metal structure. In such a PD, the dark current is usually several μA or even sub-μA, which is much lower than that of conventional metal-2DM-metal PDs based on the PG effect. Meanwhile, the PD has a high gain leading to a high responsivity of 70 A W<sup>−1</sup> at 1625 nm as well as excellent response linearity for the input power density less than 1.1 W m<sup>−2103</sup> . 

As another popular configuration, the G-Si heterostructure has also been exploited widely for realizing surface-illuminated PDs for visible<sup>132–135</sup> , NIR<sup>135–137</sup> , and 

MIR<sup>138</sup> light. As shown in Fig. 7d, a position-sensitive PD was demonstrated with a G-Si heterostructure, where graphene plays the role of the photon-absorbing and charge-separation layer<sup>135</sup> . This PD has excellent position sensitivity to weak light at nanowatt level, nanosecondscale high response speed, as well as low response nonlinearity in the NIR region. As is well known, the PD response usually can be enhanced by introducing an optical cavity<sup>136</sup> , for instance, the F-P cavity in Fig. 7e. In this case, light is absorbed in graphene and the photocurrent can be generated with an improved external responsivity of ~20 mA W<sup>−1</sup> through the IPE effect. As shown in Fig. 7f, a more complicated heterojunction PD with a G/vertical-MoSe2/Si structure was demonstrated at 

Liu et al. Light: Science & Applications (2021) 10:123 

Page 13 of 21 



<!-- Start of picture text -->
a b c<br>TiO2<br>Vbias<br>GND<br>hBN Ni Ti/AI<br>+ + + + + GT<br>e-<br>A<br>– h+ – GB WSe2<br>– – hBN<br>– SiO2 V G SLG CQDs<br>n++-Si<br>V B<br>d e f<br>(λ =Light In1.55 μm) Light<br>Light Graphene/Si<br>VX1 schottky contact Graphene<br>VY1 Ohmic<br>VX2 contact<br>Ag<br>VY2<br>n-MoSe2<br>SiO2<br>Si p-Si Au<br>Holes Au<br>Electrons<br>Back mirror<br>g h i<br>V ds 1-n layers A V ds BP<br>HfS2 MoS2<br>InSe<br>WS2<br>Electrode bP Ni<br>SiO2 Au/Ti Au<br>p-doped Si Vg Si/SiO2<br>V bg<br>Au<br>Au<br>Quartz<br>Fabry-perot cavity<br><!-- End of picture text -->

Fig. 7 Surface-illuminated Si/2DM PDs with heterostructure configurations. a A MoS2-G-WSe2 PD. b A G-WSe2-G PD with the IPE effect .c A colloidal quantum dot-graphene (CQD-G) hybrid PD with tunneling layer. d A G-Si heterostructure position-sensitive PD operating at near-infrared wavelengths. e A G-Si PD operating at 1.55 μm. f A G/vertical-MoSe2/Si heterojunction PD. g A mid-infrared WS2-HfS2 heterostructure PD based on interlayer excitons. h A mid-infrared BP-MoS2 heterostructure PD. i A mid-infrared BP-InSe avalanche photodetector. Figures reproduced with permissions from: a ref.<sup>86</sup> ,<sup>©</sup> 2016 American Chemical Society; b ref.<sup>100</sup> ,<sup>©</sup> 2016 Springer Nature Limited, under Creative Commons Attribution 4.0 International license (CC BY 4.0, https://creativecommons.org/licenses/by/4.0/); c ref.<sup>103</sup> ,<sup>©</sup> 2020 American Chemical Society; d ref.<sup>135</sup> ,<sup>©</sup> 2018 The Optical Society, under Creative Commons Attribution 4.0 International license (CC BY 4.0, https://creativecommons.org/licenses/by/4.0/); e ref.<sup>136</sup> , ©2017 American Chemical Society; f ref. 139, ©2016 John Wiley & Sons, Inc, under Creative Commons Attribution 4.0 International license (CC BY 4.0, https://creativecommons.org/licenses/by/4.0/); g ref.<sup>13©</sup> 2020 Springer Nature Limited. h ref.<sup>94</sup> ,<sup>©</sup> 2018 Springer Nature Limited; i ref.<sup>97</sup> ,<sup>©</sup> 2019 Springer Nature Limited. Further permissions related to the figures should be directed to the copyright holders. 

the wavelength band of 350–1310 nm<sup>139</sup> . The presence of graphene enables the photodetection at the wavelength beyond the absorption edges of MoSe2 and Si. Such a PD has a strong built-in electric field and a short transmit time, guaranteeing a fast response. 

More recently, the TMDC-based heterostructures have become very popular for realizing PDs. Note that the TMDCs usually have absorption edges around ~1.24 μm or below. However, the operation wavelengths of the heterostructures can be modified. For example, Lukman et al. demonstrated a WS2-HfS2 heterostructure MIR PD, as shown in Fig. 7g. Here, the interlayer excitons absorption is strongly enhanced due to the unique band 

alignment and the orbital hybridization, which thus contributes to the peak responsivity of 9.5 × 10<sup>2</sup> A W<sup>−1</sup> at the wavelength of 4.3 μm<sup>13</sup> . In addition, a multi-operationmode PD with a MoTe2-VO2 heterostructure on sapphire was demonstrated<sup>140</sup> . It works based on the PV effect in the wavelength range from 450 nm to 2 μm, while the dark current is as low as ~0.2 pA and the response time is about 17 μs. Furthermore, this PD can also work for the wavelength range from 2 to >10 μm when operating with the BOL effect. 

As a 2DM with a relatively narrow bandgap, BP has also been combined with TMDCs to form 2DM-heterostructure PDs<sup>92–95</sup> . For example, a BP-MoS2 heterostructure PD 

Liu et al. Light: Science & Applications (2021) 10:123 

Page 14 of 21 



<!-- Start of picture text -->
a b<br>CVD  Colloidal<br>graphene quantum dots<br>e e e e<br>Colloidal quantum dots<br>h h h h CVD graphene:mobility >1000 cm2 V–1 s–1<br>RR compblind Column select V ss V REF CTIA Row selectCDS Output driver VV DDOUT Vertical interconnectsCMOS read-out circuit<br>CMOS read-out<br>circuitry<br>CMOS wafer with<br>image sensor dies<br>c<br>V 1 n VMn d<br>– V 1 n – VMn I SC x – y  scan<br>R 1 n RMn<br>P 2<br>P 1 n th pixel I 1 n IMn Object<br>R 12... RM 2<br>R 11... RM 1 M  subpixels R 1 NP ...N RMN WSe2 Image<br>IM V G – V G Black phosphorus<br>A I 1 A Laser light detector<br>288 pixels<br>388 pixels<br><!-- End of picture text -->

Fig. 8 The image sensors based on Si/2DM PDs. a An image sensor array based on graphene-CMOS integration, covering ultraviolet, visible and infrared light. Left: the schematic of the graphene transfer process on wafer. Right: the schematic of the graphene/colloidal quantum dot PDs integrated with CMOS read-outs. b Concept of a focal stack light-field imaging system using graphene transparent PDs (inset). c An artificial neural network image-sensor based on a reconfigurable WSe2 PD array. Left: the schematic of the PD array. Right: the schematic of the single-element WSe2 PD. d A multispectral imaging system based on a black phosphorus PD. Figures reproduced with permissions from: a ref.<sup>124</sup> ,<sup>©</sup> 2017 Springer Nature Limited; b ref.<sup>126</sup> ,<sup>©</sup> 2020 Springer Nature Limited; c ref.<sup>125</sup> ,<sup>©</sup> 2020 Springer Nature Limited; d ref.<sup>127</sup> ,<sup>©</sup> 2014 American Chemical Society. Further permissions related to the figures should be directed to the copyright holders. 

(shown in Fig. 7h) was reported with a response time of 3.7 μs as well as a high room-temperature specific detectivity of 1.1 × 10<sup>10</sup> Jones under zero bias at 3.8 μm<sup>94</sup> . Another BP-MoS2 heterostructure PD using an F-P cavity for light absorption enhancement was demonstrated with a specific detectivity of 1.7 × 10<sup>9</sup> Jones at 3.0 μm and a fast response time of less than 3 ns<sup>95</sup> . More recently, a submean-free-path-scaled vertical BP-InSe heterostructure was reported to realize a ballistic APD enabling low threshold (<1 V) and sensitive MIR photodetection at 4 μm<sup>97</sup> . 

#### PDs and arrays for image sensing 

Surface-illuminated 2DM PDs have been developed further to realize image-sensor-array chips and the proofof-concept image systems. As shown in Fig. 8a, the demonstrated image sensor consists of a 388 × 288 G- CQD PD array, which can be used for high-sensitivity digital cameras with a broad wavelength range of 300–2000 nm<sup>124</sup> . Each G-CQD PD element given in Fig. 8a shows a high responsivity of >10<sup>7</sup> A W<sup>−1</sup> and a highspecific detectivity of >10<sup>12</sup> Jones. Compared to commercial imaging systems, such an image-sensor array enables the operation with high frame-rates as well as high detection sensitivity even at very wide operation wavelength bands. 

Transparent graphene PDs are also useful for a ranging and light-field imaging system, as shown in Fig. 8b<sup>126</sup> . A proof-of-concept single-pixel focal stack light-field camera was developed for depth ranging. A neural network photoelectric image-sensor array with a two-gate metalWSe2-metal PD element was also proposed and developed, as shown in Fig. 8c. The image sensor can realize the acquisition and processing of optical signals simultaneously without converting optical images into digital information formats, enabling real-time image acquisition in the scale of nanoseconds. The image sensor was developed further to realize two types of artificial neural networks, i.e., the image classifier (supervised learning) and image encoder (unsupervised learning)<sup>125</sup> . In ref.<sup>127</sup> , a multispectral imaging system was demonstrated by deploying a BP PD as a point-like PD in a confocal microscope setup, as shown in Fig. 8d. The BP PD can acquire high-visibility images with submicron resolutions for both visible (e.g., λ = 532 nm) and infrared (e.g., λ = 1550 nm) regimes, and the corresponding responsivities are 20 and 5 mA W<sup>−1</sup> , respectively. 

#### Summary of surface-illuminated 2DM PDs on silicon 

Table 2 gives a summary for the reported surfaceilluminated 2DM PDs on silicon, including the FOMs of 

Liu et al. Light: Science & Applications (2021) 10:123 

Page 15 of 21 

the responsivity, the bandwidth/response-time, and the specific detectivity. One can see that the PD performances are usually wavelength-sensitive (e.g., in refs.<sup>29,134</sup> ). Specifically, the linear dynamic ranges are usually not given for those 2DM PDs reported previously. Instead, the responsivities are often given with the measured input power or the power range when possible to partially reflect the linearity properties. Among them, the earliest surface-illuminated M-G-M PDs demonstrated in refs.<sup>59,141</sup> . have insufficient sensitivity (e.g., 10<sup>5</sup> Jones in ref.<sup>141</sup> ) due to the limited light absorptions and the intrinsic noise. The M-G-M bolometers reported recently can achieve high theoretical bandwidths and improved specific detectivities at low temperature (e.g., ~1 × 10<sup>7</sup> Jones<sup>53</sup> ). A M-G-M PD with an ultra-short graphene channel achieved a high PC gain and a specific detectivity of 1.5–15 × 10<sup>8</sup> Jones only on the condition of low input optical power<sup>128</sup> . This feature is similar to those PDs based on the PG effect except the much higher bandwidth of 50 GHz at the wavelength of 0.8 μm. As shown in “Metal-2DM-metal PDs” and “Metal-2DM-metal and metal-2DM+X-metal PDs” sections, the PG effect is observed rarely in M-G-M PDs, except the PD with graphene quantum dot-like arrays<sup>142</sup> , in which the electron trapping centers were introduced and the bandgap in graphene was created through band-structure engineering. In contrast, there are a few M-BP-M PDs reported with the PG effect<sup>67,143,144</sup> . As shown in Table 2, the surface-illuminated M-BP-M PDs have specific detectivities in scale of 10<sup>5</sup> –10<sup>10</sup> Jones, while the bandwidth is usually below MHz. More recently, the M-Te-M and M- PtSe2-M PDs were also demonstrated with high sensitivity and high speed in potential<sup>33,35,131</sup> . For example, the PD reported in ref.<sup>35</sup> has a specific detectivity of about 1.2 × 10<sup>7</sup> Jones and a bandwidth of ~17 GHz. 

As discussed in Section 2.2, the M-2DM+X-M PDs are mainly based on the PG effect due to the presence of trap states. These PDs usually have a high-specific detectivity at very low input optical power (e.g., 10<sup>13</sup> Jones at ~0.2 μW cm<sup>−2</sup> in ref.<sup>75</sup> ), while the bandwidth is usually in kHz scale, as shown in Table 2. In addition, their responsivities degrade seriously as the optical power increases due to the saturation of trap states<sup>46,75</sup> . In other words, it is necessary to further improve the linearity performance in order to satisfy the demands in many scenarios. 

In contrast, 2DM-heterostructure PDs were developed until recently because of the fabrication process complexity. It is possible to achieve high sensitivity due to the dark current suppression. For example, there are several PDs reported with high-specific detectivity of over 10<sup>10</sup> Jones<sup>13,86,92,94,101</sup> . However, they mostly have limited bandwidths e.g., less than MHz currently. Among these reported PDs, the BP-MoS2 heterostructure PD in ref.<sup>95</sup> 

has excellent performances overall, i.e., a bandwidth of ~0.1–1 GHz and a specific detectivity of 1.7 × 10<sup>9</sup> Jones at 3.0 μm. 

### Perspective and outlook 

Figure 9 gives the perspective of Si/2DM PDs according to four levels of material, device, circuit, and commercialization. The researches at the material level aim at the synthesis and the transfer process of 2DMs, providing the material foundation for the development of the devices. Great efforts have been devoted to explore and synthesize new 2DMs suitable for photodetection, i.e., with high mobilities as well as engineered bandgaps covering the NIR and MIR wavelength bands. As discussed above, various 2DMs have been demonstrated in the past years. Definitely, it is also important to develop high-quality transfer process for 2DMs. As is well known, the wet transfer process for CVD-grown 2DM films is one of the most popular options because it enables large-area transfer and thus is even useful for wafer-scale fabrication. For the wet transfer process, a polymer thin film is usually used as the assistant layer. Unfortunately, the polymer-removing process often induces the 2DM quality degradation<sup>9</sup> . To solve this problem, several direct transfer processes have been developed<sup>145–147</sup> . Another major transfer process is the mechanical exfoliation from vdW crystals, which can provide near-perfect high-quality 2DMs. In this way, however, only small-sized 2DM thin film with random shapes can be achieved and transferred if there is no special technique. Fortunately, it is shown that large-area mechanical exfoliation of graphene with controlled thickness can be achieved, as demonstrated recently in ref.<sup>148</sup> , showing high potential for the device development in the future. In order to develop highperformance Si/2DM PDs, more efforts at the material level are desired for the interface engineering, including contact engineering<sup>149</sup> , doping engineering, and strain engineering<sup>12</sup> , as shown in Fig. 9. 

As summarized in “Waveguide-integrated silicon-2DM PDs” and “Surface-illuminated Si/2DM PDs” sections, it is still very challenging to achieve Si/2DM PDs with high performances as well as high stability, which is the major goal for researches working for devices. More specifically, there is usually a trade-off between the response speed and the detection sensitivity. For some applications, such as optical imaging<sup>150,151</sup> and spectrometry<sup>152</sup> , high sensitivity is extremely important, while moderate (or even low) response speed is acceptable (e.g., kHz-MHz). In this case, the PDs with the PG effect might be useful since their detection sensitivity could be very high for low optical power. Definitely one should note that the higher the PC gain is, the slower the response speed will be. Besides, it is still important to increase the saturated optical power for the PDs to achieve sufficient linear 

Liu et al. Light: Science & Applications (2021) 10:123 

Page 16 of 21 

|Refs.|59<br>141<br>128|142|51d|53||162||163||130|29||129|67<br>143<br>144<br>164<br>33|131<br>165<br>35|166<br>76<br>75<br>46<br>78|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|D* (Jones) @Tb|–<br>~1.08 × 105c<br>~1.5–15 × 108 (3–20μm)*|–|~3.03 × 1010 (10.6μm)<br>@5 K*|7K|~ 3.5 × 10@5|4 *|~722 × 10–265 × 105|..|–|>1.06 × 108 (2–8μm)|~2.67 × 1010*|~2.29 × 107*|~1.19 × 106*<br>1 × 1010–6 × 1010 @1V|~1.2 × 108*<br>∼2.1 × 1010 (0.632μm)<br>–<br>~2.86 × 107*<br>~2.16 × 106*<br>~1.86 × 105*<br>2.9 × 109 @ RT 2.6 × 1011<br>@ 78 K|–<br>~1.3 × 1010<br>~1.2 × 107 (1.55μm)*|–<br>–<br>~1013 @RT<br>~105 @77 K<br>–<br>~108|
|Bandwidth/Response timea|>40 GHz<br>16 GHz<br>50 GHz (0.8μm)|–|>1 GHz (1.03μm)|Kdld|30 ps @5 (rea out-imite)||47 MHz|<br>|>0.88 MHz|~0.65 kHz (4.03μm) ~11.4 kHz<br>(1.55μm)|>>10 kHz (1.3 GHz estimated)||117 kHz (0.98μm)|1.1–2.2 kHz<br>~35 kHz (0.632μm)<br>~73 Hz<br>–<br>–|~1 kHz @ 0.95 nW<br>37 MHz @39–250μW<br>35 Hz @30μW<br>~117 Hz<br>4.5–17 GHz|–<br>~3.5 kHz (0.65μm)<br>sub-Hz scale<br>~88 Hz<br>~ 580 kHz|
||Bias||–<br>–<br>0.02 V|002 V|.<br>–||–||05 V|.<br><br>|0.2 V|0 V|1.2 V||0.5 V|0.5 V<br>2 V<br>1 V<br>1 V<br>5 V|1 V<br>0.1 V<br>5 V|1 V<br>0.5 V<br>1 V<br> <br>1 V<br>10 V|
|nism<br>Responsivity @ input power (λ)|0.5 mA W−1<br>6.1 mA W−1@0.4 V<br>0.6–0.075 A W−1 @2.5–50μW (0.8μm)<br>11.5 A W−1 @2.5μW (20μm)|02–125 A W−1 (053 m)|.. .μ<br>2 × 105V W−1 (10.6μm)||–|1|14–51 mA W−|..<br> −1  −1|160 mA W @25μW 22 mA W @785μW|<br>180–20.3 mA W−1 @ 0.07–44.3μW<br>(3.66μm)|518 mA W−1 @40μW, 77 K|30 mA W−1 @50μW, 77 K|<br>2.2 mA W−1 @100μW, 77 K<br>~11 A W−1 @ RT (3.6μm)|82 A W−1 @1.6 nW 0.9 A W−1 @30μW<br>5 × 103–6 × 104A W−1 @1.6 W cm−2, 70 K<br>230 A W−1 @11 nW<br>190 mA W−1<br>16 mA W−1<br>1.2 mA W−1<br>27 A W−1 @78 K (1.7μm) 16 A W−1 @297 K<br>(1.7μm)|<br>383 A W−1 @1.6 nW<br>~19.2 mA W−1 @0~30μW<br>~18.9 mA W−1 @0–30μW<br>380–350 A W−1<br>0.19 mA W−1 (1.55μm)|20 A W−1<br>0.45 A W−1<br>20 A W−1 @0.3μW (1.55μm)<br>1.2–22 × 108A W−1 @0.2μW cm−2<br>0.22–44.9 A W−1 @375 mW cm−2<br>1300 A W−1 @ 11 nW 210 A W−1 @ 211 nW<br>83 A W−1 @0.3μW|
|Mecha|PV<br>PV<br>PV<br>PC|PG|BOL|BOL|||BOL||PV; PC|PV|PC||PC|PG<br>PG<br>PG<br>PG<br>PTE<br>PV<br>PG|PG<br>PV<br>PG<br>BOL<br>PC<br>PV|PG<br>PG<br>PG<br>PG<br>PG|
|λ (μm)|~1.55<br>~1.55<br>0.8–20|0532–103|..<br>0.658–10.6||1.531||34–12|.<br>|2.5–3.7|2–8|3.4|5|7.7<br>1–4.6|3.39<br>0.514–1.8<br>1.55<br>3.4<br>5<br>7.7<br>1.4–2.4|0.52<br>1.55<br>3.39<br>0.8−1.2<br>0.765–1.55|1.2<br>2.4<br>0.405–1.55<br>0.375–1.87<br>2.5–3.9<br>1.55<br>~1.55|
|Structure|M-G-M<br>M-G-M<br>M-G-M|M-GQDs-M|M-G(bilayer)-M|MGM|--||M-G-M||M-BP-M|M-bPAs-M|M-BP-M||M-BP-M M-bPAs-M|M-BP-M<br>M-BP-M<br>M-BP-M<br>M-bAsP-M<br>M-Te-M|M-Te-M<br>M-ReS2-M<br>M-PtSe2-M|M-G+Ta2O5+G-M<br>M-G+CNT-M<br>M-G+SiQDs-M<br>M-BP+G-M<br>M-Au+G+Si-M|
|Configuration<br>Year|Metal-2DM-metal<br>2009<br>2010<br>2018|2013|2012||2018||2020||2017|2017|2017||2017|2016<br>2018<br>2018<br>2018<br>2018|2019<br>2019<br>2020|Metal-2DM+X-metal<br>2014<br>2015<br>2017<br>2017<br>2017|



Liu et al. Light: Science & Applications (2021) 10:123 

Page 17 of 21 

|Refs.|100<br>86|167|||101|136|138<br>168|103|13<br>92<br>93<br>130|94<br>95|unneling, PC|
|---|---|---|---|---|---|---|---|---|---|---|---|
|D* (Jones) @Tb|–<br>2 × 109–2 × 1010|~5.76 × 107c|~1.73 × 107c|~2.9 × 105c|5 × 1014<br>–|5.1 × 107|2.56 × 107<br>1.6 × 109|–<br>~8.1 × 107* e|7 × 1012 (7μm)<br>3.1 × 1011<br>2.13 × 109<br>1.01 × 109<br>1.74 × 108<br>>4.9 × 109 (3–5μm)|1.1 × 1010 (3.8μm)<br>1.7 × 109 (3.0μm)|nneling Fowler-Nordheim t|
|esponse timea|0.94μm)||||||||||tunneling, F-N tu|
|Bandwidth/R|–<br>~ 7 kHz (0.53–|3.9 Hz|2.2 Hz|1.5 Hz|ts<br>–|–|–<br>~0.95 kHz|–<br>1.1 kHz|100–200 Hz<br>–<br>~23.3 kHz<br>–<br>–|~100 kHz<br>~0.1–1 GHz|mission, DT direct|
||Bias||0.6 V<br>1 V|1 V|||Few vol|10 V|0 V<br>1 V|0 V<br>0.5 V|1.5 V<br>3 V<br>3 V<br>0 V|0 V<br>0 V|ernal photon e<br>ere.<br>~210μm2.|
|y @ input power (λ)|(1.3–2.4μm)||||||@0.19μW||A W−1 @0.5 nW<br>@1 nW<br> @1 nW<br>@13.5 nW<br>@13.5 nW<br>mA W−1 (2.36–4.29μm)|1<br>3μm)|, PV photovoltaic, IPE int<br>, RT room temperature.<br>region area.<br> absorption was ignored h<br>h a device active area of|
|Responsivit|0.12 mA W−1<br>0.1–1 A W−1|10 mA W−1|3 mA W−1|0.05 mA W−1|13μA W−1<br>70 nA W−1|~20 mA W−1|0.16 mA W−1<br>21 mA W−1|0.44μA W−1<br>70 A W−1|~92.4–3510<br>22.3 A W−1  <br>153.4 mA W1<br>6.32 A W−1  <br>1.12 A W−1  <br>115.4–216.1|0.1–0.9 A W−<br>0.11 A W−1 (|quantum dots<br>terlayer exciton<br> device active <br>use the optical<br>cy of 30 Hz wit|
|Mechanism|IPE<br>PV|IPE|||IPE<br>F-N tunneling|IPE|IPE<br>IPE|PG|ILE<br>PV<br>PG<br>PV<br>PG<br>PV|PV<br>PV|tum dots, SiQDs Si <br>hermoelectric, ILE in<br>ovided NEP and the<br>d the thermal noise.<br> overestimated beca<br> modulation frequen|
|λ (μm)|~1.55<br>0.4–2.4|0.73|1.33|1.55|~0.532<br>~1.55|~1.55|2<br>Si<br>1.55|3.5<br>1.625|4.3–10<br>~0.532<br>1.55<br>~0.532<br>1.55<br>2–8|1.6–4<br>2–4|olloidal quan<br>, PTE photo-t<br>y using the pr<br>hot noise an<br>ty D* may be<br> −11W at the|
|Structure|G-WSe2-G<br>WSe2-G-MoS2|G-GaSe-G|||G-hBN-G|G-Si|G-Si<br>G nanowalls- Au-|CQDs+G-TiO2-Ti|WS2-HfS2<br>BP-MoS2<br>WS2-BP-MoS2<br>BP-MoS2|BP-MoS2<br>BP-MoS2|ke arrays, CQDs c<br>g, BOL bolometric<br>ed.<br>*) are extracted b<br> considering the s<br>d specific detectivi<br>lue NEP=1.8 × 10|
|Configuration<br>Year|2DM- heterostructure<br>2016<br>2016|2018|||2019|2017|2018<br>2019|2020|2020<br>2016<br>2017<br>2017|2018<br>2020|GQDs graphene quantum dot-li<br>photoconductive, PG photo-gatin<br>aThe measured values are count<br>bThe data marked with asterisk (<br>cExtracted by the measured data<br>dThe responsivity and the relate<br>eExtracted from the measured va|



Liu et al. Light: Science & Applications (2021) 10:123 

Page 18 of 21 



<!-- Start of picture text -->
Commercialization<br>Material level  Device level  Circuit level level<br>Fundamental<br>Tasks: material research Design, fabrication, Test Wafer-scale integration Large scale production<br>High responsivity<br>Uniformity<br>High quality<br>High speed<br>material synthesis Reliability<br>Goals: High sensitivity<br>Yield<br>Advanced  High linearlity<br>transfer process<br>High stability Cost<br>Interface engineering  Novel mechanism Multilayer vdW system integration<br>Issues and Doping engineering Novel design<br>challenges: Inline metrology<br>Strain engineering<br>CMOS-compatibility of processes<br>Heterostructure integration<br><!-- End of picture text -->

Fig. 9 Development of Si/2DM PDs. The tasks, goals, and issues and challenges are summarized from the perspective of the material level, the device level, the circuit level, as well as the commercialization level. 

dynamic range, which might be enabled by introducing some novel device configurations and read-out structures. Similar problem is also faced by the BOL effect-based PDs<sup>58,119</sup> . As shown in Fig. 9, high linearity is an important requirement which should be paid more attention for the future development of 2DM PDs. 

In the applications, such as next-generation optical interconnects<sup>105</sup> and THz photonics<sup>153</sup> , it is usually desired to have PDs with ultra-large bandwidths of ~10<sup>2</sup> GHz and beyond. In these scenarios, M-G-M PDs have shown unique advantages due to the ultrafast carrier dynamics in graphene. However, the SNR should be improved significantly. A potential solution is to use special device structures with extremely strong enhancement of light absorption, e.g., plasmonic structures<sup>154</sup> . In particular, waveguide-integrated 2DM-heterostructure PDs on silicon have been recognized as a promising candidate with potentially decent performances in responsivity, bandwidth, and sensitivity<sup>122,123</sup> . However, there remain several big challenges. First, the structural complexity of the 2DM-heterostructure PDs makes the fabrication more difficult compared to the M-2DM-M PDs. More efforts should be made to achieve reliable high-quality fabrication<sup>155</sup> . Furthermore, more fundamental work is desired for the carrier dynamics in various 2DM heterojunctions. 

At the circuit level, it is expected to develop wafer-scale photonic integrated circuits based on 2DM PDs. In this case, it is required to realize high-performance PDs with high uniformity and high reliability. Currently, there have been several works demonstrated at the level of circuits, such as the optoelectronic integrated circuits with Si/ 2DM PDs discussed in “PDs and arrays for image sensing” 

section<sup>124,125</sup> . 2DM PDs have also been fabricated in wafer-scale, including the graphene PDs in ref.<sup>118</sup> , the few-layer GaTe PDs in ref.<sup>156</sup> , which are ready for largescale integration on silicon. More recently, Giambra et al. presented the full process flow of wafer-scale integration of graphene-based photonic devices with improved uniformity<sup>157</sup> . 

To the best of our knowledge, Si/2DM PDs have not been commercialized for applications yet. It is expected to happen in the following years with the great efforts from the groups working on materials, devices and circuits. Definitely, the yield and the cost are the keys. It is desired to develop the system-level multilayer vdW integration method<sup>158</sup> , the inline metrology technology<sup>9</sup> , as well as the quasi-CMOS-compatible process<sup>9,105,159</sup> . As predicted in ref.<sup>9</sup> , Si/2DM PDs based on the back end of line CMOS-compatible technology might be brought to market in 2022, which will be very attractive and helpful for the development of silicon photonics as well as 2DM photonics. 

### Conclusions 

In this paper, we have given a review on recent progresses of Si/2DM PDs for the applications in the NIR/MIR wavelength bands. The operation mechanisms and the configurations for 2DM PDs have been summarized and discussed, including the waveguide-integrated and surfaceilluminated devices. It can be seen that great progresses have been achieved, including ~100 GHz high-bandwidth M-G-M PDs, ultra-high-sensitivity PG effect-based PDs, and 2DM-heterostructure PDs with balanced bandwidths and sensitivities. Several representative wafer-scale image 

Liu et al. Light: Science & Applications (2021) 10:123 

Page 19 of 21 

sensors based on Si/2DM PDs and the arrays have also been demonstrated. However, it is still very challenging to realize overall high-performance PDs in wafer-scale. Nevertheless, the combination of 2DMs and silicon microelectronics/photonics provides a promising technical route to realize high-performance and low-cost PDs, which might play an important role as the fundamental element in next-generation optoelectronic integrated chips. 

##### Acknowledgements 

This project was supported by National Major Research and Development Program (No. 2018YFB2200200/2018YFB2200201); National Science Fund for Distinguished Young Scholars (61725503); National Natural Science Foundation of China (NSFC) (61905210, 61961146003, 91950205); China Postdoctoral Science Foundation (2020T130575, 2019M662041); Zhejiang Provincial Natural Science Foundation (LZ18F050001, LD19F050001); and The Fundamental Research Funds for the Central Universities. 

##### Conflict of interest 

The authors declare no competing interests. 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41377-021-00551-4. 

Received: 19 December 2020 Revised: 21 April 2021 Accepted: 6 May 2021 



##### References 

1. Ferrari, A. C. et al. Science and technology roadmap for graphene, related two-dimensional crystals, and hybrid systems. Nanoscale 7, 4598–4810 (2015). 

2. Liu, J. et al. Semimetals for high-performance photodetection. Nat. Mater. 19, 830–837 (2020). 

3. Chaves, A. et al. Bandgap engineering of two-dimensional semiconductor materials. npj 2D Mater. Appl. 4, 29 (2020). 

4. Illarionov, Y. Y. et al. Insulators for 2D nanoelectronics: the gap to bridge. Nat. Commun. 11, 3385 (2020). 

5. Koppens, F. H. L. et al. Photodetectors based on graphene, other twodimensional materials and hybrid systems. Nat. Nanotechnol. 9, 780–793 (2014). 

6. Long, M. S. et al. Progress, challenges, and opportunities for 2D material based photodetectors. Adv. Funct. Mater. 29, 1803807 (2019). 

7. Chen, X. Q. et al. Graphene hybrid structures for integrated and flexible optoelectronics. Adv. Mater. 32, 1902039 (2019). 

8. Vicarelli, L. et al. Graphene field-effect transistors as room-temperature terahertz detectors. Nat. Mater. 11, 865–871 (2012). 

9. Akinwande, D. et al. Graphene and two-dimensional materials for silicon technology. Nature 573, 507–518 (2019). 

10. Li, J. et al. Hybrid silicon photonic devices with two-dimensional materials. Nanophotonics 9, 2295–2314 (2020). 

11. Cao, G. Q. et al. Multicolor broadband and fast photodetector based on InGaAs–Insulator–graphene hybrid heterostructure. Adv. Electron. Mater. 6, 1901007 (2020). 

12. Deng, S. K. et al. Strain engineering in two-dimensional nanomaterials beyond graphene. Nano Today 22, 14–35 (2018). 

13. Lukman, S. et al. High oscillator strength interlayer excitons in twodimensional heterostructures for mid-infrared photodetection. Nat. Nanotechnol. 15, 675–682 (2020). 

14. Rahim, A. et al. Open-access silicon photonics: current status and emerging initiatives. Proc. IEEE 106, 2313–2330 (2018). 

15. Bogaerts, W. & Chrostowski, L. Silicon photonics circuit design: methods, tools and challenges. Laser Photonics Rev. 12, 1700237 (2018). 

16. Soref, R. Group IV photonics: enabling 2 µm communications. Nat. Photonics 9, 358–359 (2015). 

17. Sun, J. et al. Large-scale nanophotonic phased array. Nature 493, 195–199 (2013). 

18. Lavchiev, V. M. & Jakoby, B. Photonics in the mid-infrared: challenges in single-chip integration and absorption sensing. IEEE J. Sel. Top. Quantum Electron. 23, 8200612 (2017). 

19. Shen, Y. C. et al. Deep learning with coherent nanophotonic circuits. Nat. Photonics 11, 441–446 (2017). 

20. Wang, J. W. et al. Integrated photonic quantum technologies. Nat. Photonics 14, 273–284 (2020). 

21. Rieke, G. H. Detection of Light: From the Ultraviolet to the Submillimeter. 2nd edn. (Cambridge University Press, Cambridge, 2003). 

22. Huang, Z. H. et al. Microstructured silicon photodetector. Appl. Phys. Lett. 89, 033506 (2006). 

23. Chen, H. T. et al. 100-Gbps RZ data reception in 67-GHz Si-contacted germanium waveguide p-i-n photodetectors. J. Lightwave Technol. 35, 722–726 (2017). 

24. Roelkens, G. et al. III-V-on-silicon photonic devices for optical communication and sensing. Photonics 2, 969–1004 (2015). 

25. Capper, P. & Garland, J. W. Mercury Cadmium Telluride: Growth, Properties and Applications. (Wiley, Hoboken, 2011). 

26. Thomson, D. et al. Roadmap on silicon photonics. J. Opt. 18, 073003 (2016). 27. Liu, Y. et al. Two-dimensional transistors beyond graphene and TMDCs. Chem. Soc. Rev. 47, 6388–6409 (2018). 

28. Xiong, Z. & Tang, J. Y. Two-dimensional materials and hybrid systems for photodetection. in Synthesis, Modeling, and Characterization of 2D Materials, and Their Heterostructures. (eds. Yang, E. H. et al.) 325–349 (Elsevier, 2020). 

29. Chen, X. L. et al. Widely tunable black phosphorus mid-infrared photodetector. Nat. Commun. 8, 1672 (2017). 

30. Bonaccorso, F. et al. Graphene photonics and optoelectronics. Nat. Photonics 4, 611–622 (2010). 

31. Mak, K. F. & Shan, J. Photonics and optoelectronics of 2D semiconductor transition metal dichalcogenides. Nat. Photonics 10, 216–226 (2016). 

32. Dong, B. W. et al. Black phosphorus based photodetectors. in Fundamentals and Applications of Phosphorus Nanomaterials. (ed. Ji, H. F.) Ch. 3 (American Chemical Society, 2019). 

33. Amani, M. et al. Solution-synthesized high-mobility tellurium nanoflakes for short-wave infrared photodetectors. ACS Nano 12, 7253–7263 (2018). 

34. Yu, T. T. et al. Two‐dimensional GeP‐based broad‐band optical switches and photodetectors. Adv. Optical Mater. 8, 1901490 (2020). 

35. Wang, Y. et al. High-speed infrared two-dimensional platinum diselenide photodetectors. Appl. Phys. Lett. 116, 211101 (2020). 

36. Buscema, M. et al. Photocurrent generation with two-dimensional van der Waals semiconductors. Chem. Soc. Rev. 44, 3691–3718 (2015). 

37. Sze, S. M. Physics of Semiconductor Devices. (John Wiley and Sons, New York, 1981). 

38. Di Bartolomeo, A. Graphene Schottky diodes: an experimental review of the rectifying graphene/semiconductor heterojunction. Phys. Rep. 606, 1–58 (2016). 

39. Scales, C. & Berini, P. Thin-film Schottky barrier photodetector models. IEEE J. Quantum Electron. 46, 633–643 (2010). 

40. Miao, J. S. & Wang, C. Avalanche photodetectors based on two-dimensional layered materials. Nano Res. https://doi.org/10.1007/s12274-020-3001-8 (2020). 

41. Ma, Q. et al. Tuning ultrafast electron thermalization pathways in a van der Waals heterostructure. Nat. Phys. 12, 455–459 (2016). 

42. Vu, Q. A. et al. Tuning carrier tunneling in van der waals heterostructures for ultrahigh detectivity. Nano Lett. 17, 453–459 (2017). 

43. Furchi, M. M. et al. Mechanisms of photoconductivity in atomically thin MoS2. Nano Lett. 14, 6165–6170 (2014). 

44. Zhu, W. J. et al. Electronic transport and device prospects of monolayer molybdenum disulphide grown by chemical vapour deposition. Nat. Commun. 5, 3087 (2014). 

45. Guo, X. T. et al. High-performance graphene photodetector using interfacial gating. Optica 3, 1066–1070 (2016). 

46. Liu, Y. et al. Highly efficient and air-stable infrared photodetector based on 2D layered graphene-black phosphorus heterostructure. ACS Appl. Mater. Interfaces 9, 36137–36145 (2017). 

47. Malic, E. et al. Carrier dynamics in graphene: ultrafast many‐particle phenomena. Ann. der Phys. 529, 1700038 (2017). 

48. Ma, Q. et al. Competing channels for hot-electron cooling in graphene. Phys. Rev. Lett. 112, 247401 (2014). 

49. Low, T. et al. Origin of photoresponse in black phosphorus phototransistors. Phys. Rev. B 90, 081408 (2014). 

Liu et al. Light: Science & Applications (2021) 10:123 

Page 20 of 21 

50. Du, X. et al. Graphene-based bolometers. Graphene 2D Mater. 1, 1–22 (2014). 51. Yan, J. et al. Dual-gated bilayer graphene hot-electron bolometer. Nat. Nanotechnol. 7, 472–478 (2012). 

52. Jago, R., Malic, E. & Wendler, F. Microscopic origin of the bolometric effect in graphene. Phys. Rev. B 99, 035419 (2019). 

53. Efetov, D. K. et al. Fast thermal relaxation in cavity-coupled graphene bolometers with a Johnson noise read-out. Nat. Nanotechnol. 13, 797–801 (2018). 

54. Blaikie, A., Miller, D. & Alemán, B. J. A fast and sensitive room-temperature graphene nanomechanical bolometer. Nat. Commun. 10, 4726 (2019). 

55. Walsh, E. D. et al. Graphene-based Josephson-junction single-photon detector. Phys. Rev. Appl. 8, 024022 (2017). 

56. Vora, H. et al. Bolometric response in graphene based superconducting tunnel junctions. Appl. Phys. Lett. 100, 153507 (2012). 

57. Gabor, N. M. et al. Hot carrier–assisted intrinsic photoresponse in graphene. Science 334, 648–652 (2011). 

58. Guo, J. S. et al. High-performance silicon-graphene hybrid plasmonic waveguide photodetectors beyond 1.55 μm. Light.: Sci. Appl. 9, 29 (2020). 

59. Xia, F. N. et al. Ultrafast graphene photodetector. Nat. Nanotechnol. 4, 839–843 (2009). 

60. Shiue, R. J. et al. High-responsivity graphene–boron nitride photodetector and autocorrelator in a silicon photonic integrated circuit. Nano Lett. 15, 7288–7293 (2015). 

61. Tielrooij, K. J. et al. Generation of photovoltage in graphene on a femtosecond timescale through efficient carrier heating. Nat. Nanotechnol. 10, 437–443 (2015). 

62. Tielrooij, K. J. et al. Hot-carrier photocurrent effects at graphene-metal interfaces. J. Phys. 27, 164207 (2015). 

63. Freitag, M. et al. Photoconductivity of biased graphene. Nat. Photonics 7, 53–59 (2013). 

64. Bie, Y. Q. et al. A MoTe2-based light-emitting diode and photodetector for silicon photonic integrated circuits. Nat. Nanotechnol. 12, 1124–1129 (2017). 

65. Buscema, M. et al. Photovoltaic effect in few-layer black phosphorus PN junctions defined by local electrostatic gating. Nat. Commun. 5, 4651 (2014). 

66. Lopez-Sanchez, O. et al. Ultrasensitive photodetectors based on monolayer MoS2. Nat. Nanotechnol. 8, 497–501 (2013). 

67. Guo, Q. S. et al. Black phosphorus mid-infrared photodetectors with high gain. Nano Lett. 16, 4648–4655 (2016). 

68. Huang, L. et al. Waveguide-integrated black phosphorus photodetector for mid-infrared applications. ACS Nano 13, 913–921 (2019). 

69. Ma, Y. M. et al. High-responsivity mid-infrared black phosphorus slow light waveguide photodetector. Adv. Optical Mater. 8, 2000337 (2020). 

70. Maiti, R. et al. Strain-engineered high-responsivity MoTe2 photodetector for silicon photonic integrated circuits. Nat. Photonics 14, 578–584 (2020). 

71. Youngblood, N. et al. Waveguide-integrated black phosphorus photodetector with high responsivity and low dark current. Nat. Photonics 9, 247–252 (2015). 

72. Yin, Y. L. et al. High-speed and high-responsivity hybrid silicon/black-phosphorus waveguide photodetectors at 2 μm. Laser Photonics Rev. 13, 1900032 (2019). 

73. Hong, T. et al. Polarized photocurrent response in black phosphorus fieldeffect transistors. Nanoscale 6, 8978–8983 (2014). 

74. Konstantatos, G. et al. Hybrid graphene–quantum dot phototransistors with ultrahigh gain. Nat. Nanotechnol. 7, 363–368 (2012). 

75. Ni, Z. Y. et al. Plasmonic silicon quantum dots enabled high-sensitivity ultrabroadband photodetection of graphene-based hybrid phototransistors. ACS Nano 11, 9854–9862 (2017). 

76. Liu, Y. D. et al. Planar carbon nanotube–graphene hybrid films for highperformance broadband photodetectors. Nat. Commun. 6, 8589 (2015). 

77. Shin, G. H. et al. Ultrasensitive phototransistor based on WSe2–MoS2 van der Waals heterojunction. Nano Lett. 20, 5741–5748 (2020). 

78. Chen, Z. F. et al. Synergistic effects of plasmonics and electron trapping in graphene short-wave infrared photodetectors with ultrahigh responsivity. ACS Nano 11, 430–437 (2017). 

79. Liu, J. J. et al. Silicon-graphene conductive photodetector with ultra-high responsivity. Sci. Rep. 7, 40904 (2017). 

80. Venuthurumilli, P. K., Ye, P. D. & Xu, X. F. Plasmonic resonance enhanced polarization-sensitive photodetection by black phosphorus in near infrared. ACS Nano 12, 4861–4867 (2018). 

81. Wang, X. D. et al. Ultrasensitive and broadband MoS2 photodetector driven by ferroelectrics. Adv. Mater. 27, 6575–6581 (2015). 

82. Yu, W. J. et al. Highly efficient gate-tunable photocurrent generation in vertical heterostructures of layered materials. Nat. Nanotechnol. 8, 952–958 (2013). 

83. Britnell, L. et al. Strong light-matter interactions in heterostructures of atomically thin films. Science 340, 1311–1314 (2013). 

84. Massicotte, M. et al. Picosecond photoresponse in van der Waals heterostructures. Nat. Nanotechnol. 11, 42–46 (2016). 

85. Heo, J. et al. Reconfigurable van der Waals heterostructured devices with metal–insulator transition. Nano Lett. 16, 6746–6754 (2016). 

86. Long, M. S. et al. Broadband photovoltaic detectors based on an atomically thin heterostructure. Nano Lett. 16, 2254–2259 (2016). 

87. Lee, C. H. et al. Atomically thin p–n junctions with van der Waals heterointerfaces. Nat. Nanotechnol. 9, 676–681 (2014). 

88. Yang, S. et al. Monolithic interface contact engineering to boost optoelectronic performances of 2D semiconductor photovoltaic heterojunctions. Nano Lett. 20, 2443–2451 (2020). 

89. Ma, P. et al. Fast MoTe2 waveguide photodetector with high sensitivity at telecommunication wavelengths. ACS Photonics 5, 1846–1852 (2018). 

90. Flöry, N. et al. Waveguide-integrated van der Waals heterostructure photodetector at telecom wavelengths with high speed and high responsivity. Nat. Nanotechnol. 15, 118–124 (2020). 

91. Lee, J. et al. Modulation of junction modes in SnSe2/MoTe2 broken-gap van der Waals heterostructure for multifunctional devices. Nano Lett. 20, 2370–2377 (2020). 

92. Ye, L. et al. Near-infrared photodetector based on MoS2/black phosphorus heterojunction. ACS Photonics 3, 692–699 (2016). 

93. Li, H., Ye, L. & Xu, J. B. High-performance broadband floating-base bipolar phototransistor based on WSe2/BP/MoS2 heterostructure. ACS Photonics 4, 823–829 (2017). 

94. Bullock, J. et al. Polarization-resolved black phosphorus/molybdenum disulfide mid-wave infrared photodiodes with high detectivity at room temperature. Nat. Photonics 12, 601–607 (2018). 

95. Yan, W. et al. Spectrally selective mid-wave infrared detection using fabrypérot cavity enhanced black phosphorus 2D photodiodes. ACS Nano 14, 13645–13651 (2020). 

96. Yu, W. J. et al. Unusually efficient photocurrent extraction in monolayer van der Waals heterostructure by tunnelling through discretized barriers. Nat. Commun. 7, 13278 (2016). 

97. Gao, A. Y. et al. Observation of ballistic avalanche phenomena in nanoscale vertical InSe/BP heterostructures. Nat. Nanotechnol. 14, 217–222 (2019). 

98. Wang, X. M. et al. High-responsivity graphene/silicon-heterostructure waveguide photodetectors. Nat. Photonics 7, 888–891 (2013). 

99. Goykhman, I. et al. On-chip integrated, silicon–graphene plasmonic schottky photodetector with high responsivity and avalanche photogain. Nano Lett. 16, 3005–3013 (2016). 

100. Massicotte, M. et al. Photo-thermionic effect in vertical graphene heterostructures. Nat. Commun. 7, 12174 (2016). 

101. Li, L. F. et al. Plasmon excited ultrahot carriers and negative differential photoresponse in a vertical graphene van der Waals heterostructure. Nano Lett. 19, 3295–3304 (2019). 

102. Jeong, H. et al. Metal–insulator–semiconductor diode consisting of twodimensional nanomaterials. Nano Lett. 16, 1858–1862 (2016). 

103. De Fazio, D. et al. Graphene-quantum dots hybrid photodetectors with low dark-current readout. ACS Nano 14, 11897–11905 (2020). 

104. Koester, S. J. & Li, M. Waveguide-coupled graphene optoelectronics. IEEE J. Sel. Top. Quantum Electron. 20, 6000211 (2014). 

105. Romagnoli, M. et al. Graphene-based integrated photonics for nextgeneration datacom and telecom. Nat. Rev. Mater. 3, 392–414 (2018). 

106. Ma, Z. Z. et al. Compact graphene plasmonic slot photodetector on siliconon-insulator with high responsivity. ACS Photonics 7, 932–940 (2020). 

107. Pospischil, A. et al. CMOS-compatible graphene photodetector covering all optical communication bands. Nat. Photonics 7, 892–896 (2013). 

108. Ding, Y. H. et al. Ultra-compact integrated graphene plasmonic photodetector with bandwidth above 110 GHz. Nanophotonics 9, 317–325 (2020). 

109. Gan, X. T. et al. Chip-integrated ultrafast graphene photodetector with high responsivity. Nat. Photonics 7, 883–887 (2013). 

110. Schall, D. et al. 50 GBit/s photodetectors based on wafer-scale graphene for integrated silicon photonic communication systems. ACS Photonics 1, 781–784 (2014). 

111. Gao, Y. et al. High-performance chemical vapor deposited graphene-onsilicon nitride waveguide photodetectors. Opt. Lett. 43, 1399–1402 (2018). 

Liu et al. Light: Science & Applications (2021) 10:123 

Page 21 of 21 

112. Schuler, S. et al. Controlled generation of a p–n junction in a waveguide integrated graphene photodetector. Nano Lett. 16, 7107–7112 (2016). 

113. Schuler, S. et al. Graphene photodetector integrated on a photonic crystal defect waveguide. ACS Photonics 5, 4758–4763 (2018). 

114. Muench, J. E. et al. Waveguide-integrated, plasmonic enhanced graphene photodetectors. Nano Lett. 19, 7632–7644 (2019). 

115. Schuler, S. et al. High-responsivity graphene photodetectors integrated on silicon microring resonators. Preprint at https://arxiv.org/abs/2007.03044 (2020). 

116. Marconi, S. et al. Photo thermal effect graphene detector featuring 105 Gbit s<sup>−1</sup> NRZ and 120 Gbit s<sup>−1</sup> PAM4 direct detection. Nat. Commun. 12, 806 (2021). 

117. Mišeikis, V. et al. Ultrafast, zero-bias, graphene photodetectors with polymeric gate dielectric on passive photonic waveguides. ACS Nano 14, 11190–11204 (2020). 

118. Schall, D. et al. Graphene photodetectors with a bandwidth> 76 GHz fabricated in a 6'' wafer process line. J. Phys. D: Appl. Phys. 50, 124004 (2017). 

119. Ma, P. et al. Plasmonically enhanced graphene photodetector featuring 100 Gbit/s data reception, high responsivity, and compact size. ACS Photonics 6, 154–161 (2019). 

120. Urich, A., Unterrainer, K. & Mueller, T. Intrinsic response time of graphene photodetectors. Nano Lett. 11, 2804–2808 (2011). 

121. Wang, Y. et al. Bound-states-in-continuum hybrid integration of 2D platinum diselenide on silicon nitride for high-speed photodetectors. ACS Photonics 7, 2643–2649 (2020). 

122. Li, T. T. et al. Spatially controlled electrostatic doping in graphene p-i-n junction for hybrid silicon photodiode. npj 2D Mater. Appl. 2, 36 (2018). 

123. Gao, Y. et al. High-speed van der Waals heterostructure tunneling photodiodes integrated on silicon nitride waveguides. Optica 6, 514–517 (2019). 

124. Goossens, S. et al. Broadband image sensor array based on graphene–CMOS integration. Nat. Photonics 11, 366–371 (2017). 

125. Mennel, L. et al. Ultrafast machine vision with 2D material neural network image sensors. Nature 579, 62–66 (2020). 

126. Lien, M. B. et al. Ranging and light field imaging with transparent photodetectors. Nat. Photonics 14, 143–148 (2020). 

127. Engel, M., Steiner, M. & Avouris, P. Black phosphorus photodetector for multispectral, high-resolution imaging. Nano Lett. 14, 6414–6417 (2014). 

128. Cakmakyapan, S. et al. Gold-patched graphene nano-stripes for highresponsivity and ultrafast photodetection from the visible to infrared regime. Light.: Sci. Appl. 7, 20 (2018). 

129. Amani, M. et al. Mid-wave infrared photoconductors based on black phosphorus-arsenic alloys. ACS Nano 11, 11724–11731 (2017). 

130. Long, M. S. et al. Room temperature high-detectivity mid-infrared photodetectors based on black arsenic phosphorus. Sci. Adv. 3, e1700589 (2017). 

131. Shen, C. F. et al. Tellurene photodetector with high gain and wide bandwidth. ACS Nano 14, 303–310 (2020). 

132. Chen, C. C. et al. Graphene-silicon schottky diodes. Nano Lett. 11, 5097 (2011). 133. Selvi, H. et al. Graphene–silicon-on-insulator (GSOI) Schottky diode photodetectors. Nanoscale 10, 18926–18935 (2018). 

134. Chang, K. E. et al. Gate-controlled graphene-silicon schottky junction photodetector. Small 14, 1801182 (2018). 

135. Wang, W. H. et al. High-performance position-sensitive detector based on graphene–silicon heterojunction. Optica 5, 27–31 (2018). 

136. Casalino, M. et al. Vertically illuminated, resonant cavity enhanced, graphene–silicon schottky photodetectors. ACS Nano 11, 10955–10963 (2017). 

137. Selvi, H. et al. Towards substrate engineering of graphene–silicon Schottky diode photodetectors. Nanoscale 10, 3399–3409 (2018). 

138. Casalino, M. et al. Free-space schottky graphene/silicon photodetectors operating at 2 μm. ACS Photonics 5, 4577–4585 (2018). 

139. Mao, J. et al. Ultrafast, broadband photodetector based on MoSe2/silicon heterojunction with vertically standing layered structure using graphene as transparent electrode. Adv. Sci. 3, 1600018 (2016). 

140. Jiang, W. et al. A versatile photodetector assisted by photovoltaic and bolometric effects. Light.: Sci. Appl. 9, 160 (2020). 

141. Mueller, T., Xia, F. N. & Avouris, R. Graphene photodetectors for high-speed optical communications. Nat. Photonics 4, 297–301 (2010). 

142. Zhang, Y. Z. et al. Broadband high photoresponse from pure monolayer graphene photodetector. Nat. Commun. 4, 1811 (2013). 

143. Xiong, X. et al. High performance black phosphorus electronic and photonic devices with HfLaO dielectric. IEEE Electron Device Lett. 39, 127–130 (2018). 

144. Liu, Y. et al. Highly responsive broadband black phosphorus photodetectors. Chin. Opt. Lett. 16, 020002 (2018). 

145. Verguts, K. et al. Controlling water intercalation is key to a direct graphene transfer. ACS Appl. Mater. Interfaces 9, 37484–37492 (2017). 

146. Wang, B. et al. Support-free transfer of ultrasmooth graphene films facilitated by self-assembled monolayers for electronic devices and patterns. ACS Nano 10, 1404–1410 (2016). 

147. Chen, M. G. et al. Advances in transferring chemical vapour deposition graphene: a review. Mater. Horiz. 4, 1054–1063 (2017). 

148. Moon, J. Y. et al. Layer-engineered large-area exfoliation of graphene. Sci. Adv. 6, eabc6601 (2020). 

149. Schulman, D. S., Arnold, A. J. & Das, S. Contact engineering for 2D materials and devices. Chem. Soc. Rev. 47, 3037–3058 (2018). 

150. Konstantatos, G. Current status and technological prospect of photodetectors based on two-dimensional materials. Nat. Commun. 9, 5266 (2018). 

151. Rogalski, A. Graphene-based materials in the infrared and terahertz detector families: a tutorial. Adv. Opt. Photonics 11, 314–379 (2019). 

152. Lin, H. T. et al. Mid-infrared integrated photonics on silicon: a perspective. Nanophotonics 7, 393–420 (2017). 

153. Seeds, A. J. et al. Terahertz photonics for wireless communications. J. Lightwave Technol. 33, 579–587 (2015). 

154. Yan, S. Q. et al. 2D materials integrated with metallic nanostructures: fundamentals and optoelectronic applications. Nanophotonics 9, 1877–1900 (2020). 

155. Liu, Y. et al. Van der Waals heterostructures and devices. Nat. Rev. Mater. 1, 16042 (2016). 

156. Yuan, X. et al. Wafer-scale arrayed p-n junctions based on few-layer epitaxial GaTe. Nano Res. 8, 3332–3341 (2015). 

157. Giambra, M. A. et al. Wafer-scale integration of graphene-based photonic devices. ACS Nano 15, 3171–3187 (2021). 

158. Liu, Y., Huang, Y. & Duan, X. F. Van der Waals integration before and beyond two-dimensional materials. Nature 567, 323–333 (2019). 

159. Neumaier, D., Pindl, S. & Lemme, M. C. Integrating graphene into semiconductor fabrication lines. Nat. Mater. 18, 525–529 (2019). 

160. Qu, Z. et al. Waveguide integrated graphene mid-infrared photodetector. In Proceedings of SPIE 10537, Silicon Photonics XIII. (SPIE, 2018). 105371N. 

161. Chen, C. et al. Three-dimensional integration of black phosphorus photodetector with silicon photonics and nanoplasmonics. Nano Lett. 17, 985–991 (2017). 

162. Yuan, S. F. et al. Room temperature graphene mid-infrared bolometer with a broad operational wavelength range. ACS Photonics 5, 1206–1215 (2020). 

163. Xu, M. et al. Black phosphorus mid-infrared photodetectors. Appl. Phys. B 123, 130 (2017). 

164. Yuan, S. F. et al. Air-stable room-temperature mid-infrared photodetectors based on hBN/black arsenic phosphorus/hBN heterostructures. Nano Lett. 18, 3172–3179 (2018). 

165. Xiang, D. et al. Anomalous broadband spectrum photodetection in 2D rhenium disulfide transistor. Adv. Optical Mater. 7, 1901115 (2019). 

166. Liu, C. H. et al. Graphene photodetectors with ultra-broadband and high responsivity at room temperature. Nat. Nanotechnol. 9, 273–278 (2014). 

167. Kim, W. et al. Photoresponse of graphene-gated graphene-GaSe heterojunction devices. ACS Appl. Nano Mater. 1, 3895–3902 (2018). 

168. Liu, X. Z. et al. Infrared photodetector based on the photothermionic effect of graphene-nanowall/silicon heterojunction. ACS Appl. Mater. Interfaces 11, 17663–17669 (2019). 

