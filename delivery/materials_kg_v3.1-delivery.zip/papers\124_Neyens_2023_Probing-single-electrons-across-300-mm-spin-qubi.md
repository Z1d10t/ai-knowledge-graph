# Probing single electrons across 300-mm spin qubit wafers

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 208 |
| 作者 | S. Neyens, O. Zietz, T. Watson, F. Luthi, Aditi Nethwewala, H. George, E. Henry, M. Islam et al. |
| DOI | 10.1038/s41586-024-07275-6 |
| 源文件 | 024_Neyens_2023_Probing-single-electrons-across-300-mm-spin-qubi.pdf |

---
# Probing single electrons across 300 mm spin qubit wafers 

Samuel Neyens<sup>*1</sup> , Otto K. Zietz<sup>*1</sup> , Thomas F. Watson<sup>1</sup> , Florian Luthi<sup>1</sup> , Aditi Nethwewala<sup>1</sup> , Hubert C. George<sup>1</sup> , Eric Henry<sup>1</sup> , Mohammad Islam<sup>1</sup> , Andrew J. Wagner<sup>1</sup> , Felix Borjans<sup>1</sup> , Elliot J. Connors<sup>1</sup> , J. Corrigan<sup>1</sup> , Matthew J. Curry<sup>1</sup> , Daniel Keith<sup>1</sup> , Roza Kotlyar<sup>1</sup> , Lester F. Lampert<sup>1</sup> , Mateusz T. Mądzik<sup>1</sup> , Kent Millard<sup>1</sup> , Fahd A. Mohiyaddin<sup>1</sup> , Stefano Pellerano<sup>1</sup> , Ravi Pillarisetty<sup>1</sup> , Mick Ramsey<sup>1</sup> , Rostyslav Savytskyy<sup>1</sup> , Simon Schaal<sup>1</sup> , Guoji Zheng<sup>1</sup> , Joshua Ziegler<sup>1</sup> , Nathaniel C. Bishop<sup>1</sup> , Stephanie Bojarski<sup>1</sup> , Jeanette Roberts<sup>1</sup> , and James S. Clarke<sup>1</sup> 

> 1Intel Corp., 2501 NE Century Blvd, Hillsboro, OR 97124, USA , *These authors contributed equally to this work 

May 6, 2024 

## **Abstract** 

**Building a fault-tolerant quantum computer will require vast numbers of physical qubits. For qubit technologies based on solid state electronic devices [1, 2, 3], integrating millions of qubits in a single processor will require device fabrication to reach a scale comparable to that of the modern CMOS industry. Equally importantly, the scale of cryogenic device testing must keep pace to enable efficient device screening and to improve statistical metrics like qubit yield and voltage variation. Spin qubits [1, 4, 5] based on electrons in Si have shown impressive control fidelities [6, 7, 8, 9] but have historically been challenged by yield and process variation [10, 11, 12]. Here we present a testing process using a cryogenic 300 mm wafer prober [13] to collect high-volume data on the performance of hundreds of industry-manufactured spin qubit devices at 1.6 K. This testing method provides fast feedback to enable optimization of the CMOS-compatible fabrication process, leading to high yield and low process variation. Using this system, we automate measurements of the operating point of spin qubits and probe the transitions of single electrons across full wafers. We analyze the random variation in single-electron operating voltages and find that the optimized fabrication process leads to low levels of disorder at the 300 mm scale. Together these results demonstrate the advances that can be achieved through the application of CMOS industry techniques to the fabrication and measurement of spin qubit devices.** 

## **Main text** 

Silicon quantum dot spin qubits [1, 4, 5] have recently demonstrated single- and two-qubit fidelities well above 99% [6, 7, 8, 9], satisfying thresholds for error correction [14]. Today, integrated spin qubit arrays have reached sizes of six quantum dots [15, 9] with larger quantum dot platforms in 1D [16, 17] and 2D [18, 19] configurations also being demonstrated. To realize practical applications with spin qubit technology, physical qubit count will need to be increased dramatically [20, 21]. This will require fabricating spin qubit devices with a density, volume, and uniformity comparable to those of classical computing chips, which today contain billions of transistors. The spin qubit technology has inherent advantages for scaling due to the qubit size ( _∼_ 100 nm), as well as, in the case of Si-based devices, a native compatibility with complementary metal-oxide-semiconductor (CMOS) manufacturing infrastructure. It has therefore been 

1 

posited that manufacturing spin qubit devices with the same infrastructure as classical computing chips can unlock spin qubits’ potential for scaling and provide a path to building fault-tolerant quantum computers with the technology. 

The scaling of classical chips according to Moore’s Law has depended on significant advancements in device variation ( _σVT_ ) [22] as well as performance ( _I_ on _/I_ off, gate delay). For spin qubits today, process variation and yield are significant challenges [10, 11, 12]. While state-of-the-art results are impressive [6, 7, 8, 9], associated platforms do not yet include studies of device yield. In practice, most spin qubit results are achieved as a culmination of a device screening process where many devices are tested until one with satisfactory electrostatic behavior is obtained. As the spin qubit field progresses towards larger array sizes, such processes will become more challenging as increasing numbers of gates and quantum dot sites must pass these screening criteria. Advancing to the next order of magnitude in spin qubit processor size will demand both higher yield of spin qubit device components (e.g., gates, quantum dots) as well as more efficient testing processes to tackle the increasingly complex fabrication process optimization. 

It has not yet been clearly shown that CMOS manufacturing infrastructure can bring the same improvements to variation and yield of quantum devices as have been made for classical devices. Spin qubits have been made with hybrid fabrication flows, where industry-standard techniques are interleaved with research techniques such as e-beam lithography and/or liftoff [23, 24]. More fully industry-compatible devices in Si-MOS have also been demonstrated [25, 26] but are currently limited by high levels of disorder due to the qubits being formed directly at the Si/SiO2 interface. Spin qubits hosted in epitaxial group-IV heterostructures offer reduced disorder [27, 28, 29] but are less straightforward to integrate in an industry process due to the 300 mm SiGe epitaxy, which comes with reduced thermal budget and increased valley splitting challenges [30] compared to Si-MOS. 

In addition to fabrication challenges, the bottleneck of cryogenic electrical testing presents a barrier to scaling any solid state quantum technology, from spin qubits to superconducting [2] and topological [3] qubits. To improve process variation and yield in quantum devices, process changes must be combined with statistical measurements of performance indicators such as voltage variation and component yield. Furthermore, as spin qubit processor size increases, it will be increasingly important to identify the “leading edge” devices from a given wafer before packaging in a quantum computer stack, requiring thorough testing of a large volume of devices per wafer. Traditional test systems that cool down one device at a time introduce significant overhead (through dicing, die attaching, bonding, and thermal cycling devices), which limits the number of devices per wafer that can be tested. One solution is device multiplexing, using either on-chip [31, 32] or off-chip [33] circuitry, but both approaches come with limitations in the wafer area that can be sampled. By contrast, the standard technique in the semiconductor test industry is full wafer probing. This approach provides maximal flexibility, as all devices on the wafer are simultaneously accessible for electrical measurement. For quantum devices, wafer-scale probing requires additional cooling hardware to reach the required temperatures. For spin qubits based on Si/SiGe quantum dots, accessing the single electron operating regime typically requires temperatures ≲ 4 K. Only recently has wafer probing at such low temperatures become possible. 

In this work we present two advancements. First, we develop a 300 mm cryogenic probing process to collect high volume data on spin qubit devices across full wafers. Second, we optimize an industry-compatible process to fabricate spin qubit devices on Si/SiGe heterostructures, combining low process variation with a low disorder host material. These two advancements are mutually reinforcing: the development of full-wafer cryogenic test capabilities enables the optimization of the complex 300 mm fabrication process, and the optimization of the fabrication process improves device reliability to enable significantly deeper automated measurements across wafers. As we will show, together these culminate in the automated probing of single electrons in spin qubit arrays across 300 mm wafers. 

The spin qubit devices studied here are fabricated in Intel’s D1 factory where the company’s CMOS logic processes are developed. The host material is a Si/Si0 _._ 7Ge0 _._ 3 heterostructure [34] grown on 300 mm Si wafers. This structure is chosen to leverage the long-lived coherence of electron spins in Si and their applicability for multiple qubit encodings [5]. Fig. 1a shows an optical image of a completed spin qubit wafer. All patterning is done with optical lithography. The quantum dot gate patterning is done in a single pass with extreme ultraviolet (EUV) lithography, allowing us to explore gate pitches from 50-100 nm. The fabrication of all device sub-components is based on fundamental industry techniques of deposition, etch, and chemical-mechanical polish [35]. As we will demonstrate, this approach leads to high yield and low process variation across the 300 mm wafer. 

2 



<!-- Start of picture text -->
a Wafer at T = 1.6 K b Device alignment and contact c Measurement sequence d Wafer-scale data analysis<br><!-- End of picture text -->

Figure 1: **Cryo-prober measurement flow. a** , The cryo-prober cools 300 mm wafers (upper image) to an electron temperature of 1.6 K in _∼_ 2 hrs. Lower image shows a cross-sectional transmission electron micrograph of a Si/SiGe quantum dot qubit device. Gates are false-colored. Scale bar is 100 nm. **b** , When the wafer is cold, device pads are aligned to the probe pins using wafer stage controls and machine vision feedback. The stage lifts the device pads into contact with the probe pins to connect devices to measurement electronics at room temperature. Device pads are 100 _×_ 100 _µ_ m<sup>2</sup> with 150 _µ_ m pitch. **c** , With device in contact, a wide variety of measurements can be performed to extract device data. **d** , After repeating this process on many devices across the wafer, device data can be used for statistical analysis of wafer-scale trends. 

The cryogenic wafer prober (cryo-prober) we use [13, 36] was manufactured by Bluefors and AEM Afore and was developed in collaboration with Intel. The cryo-prober can load and cool 300 mm wafers to a base temperature of 1.0 K at the chuck and an electron temperature of 1 _._ 6 _±_ 0 _._ 2 K (see Extended Data Fig. 2) in _∼_ 2 hrs. Fig. 1 shows an overview of the wafer measurement process. After cooldown, thousands of spin qubit arrays and test structures on the wafer are available for measurement. An individual device is aligned to the probe pins using the wafer stage control and a machine vision algorithm. The wafer is brought into contact with the probe pins to electrically connect device pads to voltage sources and current and voltage detectors at room temperature. Measurements are taken with these instruments to extract a variety of metrics including gate line resistance, ohmic contact resistance, carrier mobility, gate threshold voltage, and transition voltages in the few-electron regime. (See Methods and Extended Data Fig. 3 for measurements of gate line resistance and carrier mobility.) These measurements are repeated on many devices across a wafer to generate wafer-scale statistics. The entire process, from alignment to device measurement, is fully automated and programmable, speeding up device data collection by several orders of magnitude compared to the measurement of singular devices in a cryostat. 

To achieve high yield, a combination of processes from industrial transistor manufacturing are used. A 3D schematic of the gate stack is shown in Fig. 2a. The quantum dots are defined by a planar architecture. Active gates, used for controlled accumulation, are defined in a single layer. In later devices (discussed below), a second passive layer for screening/depletion is also integrated [37]. The gate electrodes are isolated from the heterostructure by a high dielectric constant composite stack, or “high- _κ_ stack,” while neighboring gates are isolated by a “spacer” stack. Complete process optimization involves many factors; here we highlight two key vectors for improving device variation and performance: reducing fixed charge in the high- _κ_ stack and optimizing the gate layer architecture. Fixed charge in the high- _κ_ stack can arise due to the materials and conditions of the deposition itself as well as through exposure to subsequent processing. In particular, we find that fixed charge can be reduced in our devices by limiting the temperature of the spacer process to within the typical thermal budget for back-end-of-line (BEOL) processing, _T_ BEOL _∼_ 400<sup>_◦_</sup> C [38]. We attribute the reductions in fixed charge to reduced crystallization of the high- _κ_ stack at lower temperatures. Fig. 2b shows improvements in flatband voltage variation over 15 wafers, as measured by gate threshold voltage ( _VT_ ), or the voltage required to turn on and off current with a particular gate. (See Methods for measurement details.) This plot highlights three distinct versions of the fabrication flow and includes _∼_ 4,000 data points for each version. Across these versions, we observe a significant reduction in median 

3 



<!-- Start of picture text -->
a b High-κ stack A High-κ stack B High-κ stack B<br>Spacer temp. >  T BEOL Spacer temp. >  T BEOL Spacer temp. < Screening gate layer T BEOL<br>4<br>3<br>2<br>1<br>0<br>1 2 3 4 5 6 7 8 9 10 11 12 13 14 15<br>Spacer Gate Spacer Gate Spacer c Wafer number (arb.)<br>3.15 3.5 0.95 7 1.00 25<br>High-κ stack<br>SiGe<br>Si<br>2.60 0.0 0.40 0 0.55 0<br>SiGe 2.50 3.05 0.25 0.80 0.60 1.05<br>Right barrier (V) Right barrier (V) Right barrier (V)<br>Threshold voltage (V)<br>Left barrier (V) Current (nA) Left barrier (V) Current (nA) Left barrier (V) Current (nA)<br><!-- End of picture text -->

Figure 2: **Process optimization aided by cryo-prober feedback. a** , Schematic of the gate structure in an optimized spin qubit array. Gates designed to accumulate charge are colored yellow, blue, and green, while gates designed to deplete charge (screening gates) are colored red. Scale in the vertical direction is approximate. **b** - **c** , Spin qubit device variation and electrostatics performance are improved through optimization of the gate stack. Three versions of the device fabrication are highlighted. Only the third version includes the lower screening layer shown in **a** . **b** , Gate _VT_ variation both within and between wafers are improved after process optimization. Box plots display the median and inter-quartile range (IQR) of each distribution. Whiskers mark the maximum and minimum values excluding outliers, which are defined as points removed from the median by more than 1.5 times the IQR. **c** , Representative quantum dot transport measurements are shown for each of the three versions with improvements made to disorder and stability. 

_VT_ and a reduction in _VT_ variation between and within wafers. We attribute these improvements to the reduction in fixed charge, driven by improvements to the high- _κ_ stack itself (between stack “A” and “B”) and the reduction in thermal budget of subsequent processing, as well as to the more consistent confinement provided by the additional screening gate layer. The “barrier-barrier scans” shown in Fig. 2c also highlight improvements in quantum dot confinement, disorder, and stability through each stage of device optimization (see Methods and Extended Data Fig. 7 for more). 

After process optimization, we characterize the optimized process flow with measurements on 12-quantumdot (12QD) devices with 60 nm gate pitch. Measurements are again fully automated to maximize the speed and consistency of data collection (see Methods). The 12QD design is comprised of a linear array of twelve quantum dots with four opposing sensor dots isolated by a center screening gate. An in-line SEM image of this device with a schematic of the measurement configuration is shown in Fig. 3b. Quantum dots on both the qubit side and the sensor side are defined by three gates each: one plunger gate to control the electron number on the dot, and one barrier gate on each side to tune the tunnel coupling to the neighboring dot or charge reservoir. The array of twelve quantum dots can be operated as physical qubits in a variety of spin encodings, including single spin qubits [39] (in a 12-qubit array) or exchange-only qubits [40] (in a 4-qubit array). Depending on the spin qubit encoding, an optional micromagnet layer can be added to the device and the center screening gate can supply microwave electric fields to control the qubits with electric dipole spin resonance. 

As in a CMOS logic process, improving qubit yield is a necessary part of scaling up quantum processors, as larger systems will depend on an increasing number of qubit components to function. To analyze the yield of this fabrication flow, we test 232 12QD devices across a wafer. We calculate component yield for ohmic contacts, gates, quantum dots, and full 12QD devices. These yield metrics are summarized in Table 1. Both ohmic contact and gate yield are 100%. The large number of gates tested and working on this wafer 

4 



<!-- Start of picture text -->
a b<br>B0 B1 B2 B3 B4 B5 B6 B7 B8 B9 B10 B11 B12<br>A1 P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 P11 P12 A2<br>40<br>0 100 nm<br>0 1<br>Gate voltage (V)<br>c 1.2<br>1.0<br>d<br>0.8<br>σ(∆ VT )/√2 = 59 mV<br>600<br>0.6<br>400<br>0.4<br>200<br>0.2<br>0<br>-0.4 -0.2 0.0 0.2 0.4 0.0 A1 B0 P1 B1 P2 B2 P3 B3 P4 B4 P5 B5 P6 B6 P7 B7 P8 B8 P9 B9 P10 B10 P11 B11 P12 B12 A2<br>Matched pair ∆ VT  (V) Gate<br>Current (nA)<br>Count Threshold voltage (V)<br><!-- End of picture text -->

Figure 3: **Threshold voltage statistics from 12-quantum-dot arrays. a** , Tiled array of IV curves taken on 12-quantum-dot (12QD) devices across a wafer. IV curves from a single device are shown in the inset, including 27 gates from the linear quantum dot array. **b** , Schematic of the measurement configuration overlaid on an in-line SEM image of a representative 12QD device. Quantum dot locations are indicated by dashed circles. Gates are false-colored by function: yellow for plunger gates, blue for barrier gates, green for reservoir gates, and red for center screening gate. **c** , Histograms of gate _VT_ values across the 12QD array. Data is taken from 232 12QD devices across a wafer. **d** , Histogram of ∆ _VT_ calculated between matched gate pairs using the _VT_ dataset shown in **c** . 

( _>_ 10,000) highlights the consistency of the gate fabrication process. Quantum dot yield is 99.8%, which further emphasizes the reliability of electrostatic gate control. Lastly, the full device yield, including the linear array of 12 quantum dots and the 4 charge sensors, is 96%. (See Methods for more details.) 

Fig. 3c shows a summary of gate _VT_ values collected on 12QD devices across a wafer. The distributions are highly consistent across the 25-gate array. We also observe a systematic shift in median _VT_ for the two outer-most gates in the array. The symmetry of this effect suggests it is electrostatic in nature, due to the proximity of the reservoir gates. While trends like this might be difficult to confirm through one-off device testing, they are readily observable with full-wafer statistics. The gate _VT_ distributions also contain information on process variation. To estimate the random variation in _VT_ within individual devices, we adapt a standard CMOS industry method of analyzing matched pair _VT_ differences [22]. (See Methods for details.) The resulting matched pair ∆ _VT_ distribution is plotted in Fig. 3d. The standard deviation of this distribution, reduced by a factor of _~~√~~_ 2, is 59 mV, representing the random component of _VT_ variation within devices. 

|**Component**|**Yield**|**Good count**|**Total count**|
|---|---|---|---|
|Ohmics|100%|1624|1624|
|Gates|100%|10208|10208|
|Quantum dots|99_._8%|3703|3712|
|12QD arrays|96%|223|232|



Table 1: **Summary of device component yield across a representative 300 mm wafer.** “Total count” indicates the total number of each component tested. “Good count” indicates the number of each component found working. Yield is the percentage of the good count out of the total count for each component. 

5 



<!-- Start of picture text -->
a 0.9 8 b 1.6<br>1.2<br>0.8<br>0.4 Plunger<br>0.5<br>Left barrier<br>1 Right barrier<br>0.0<br>1.0 1.4 B0 P1 B1 P2 B2 P3 B3 P4 B4 P5 B5 P6 B6 P7 B7 P8 B8 P9 B9 P10 B10 P11 B11 P12 B12<br>Plunger voltage (V) Gate<br>c 60 e g<br>σ(∆ V 1 e )/√2 = 61 mV Mean: 59 ± 7 mV σ( VP - VB ) = 0.12 V<br>120<br>80<br>40<br>30 nm SiGe  80<br>barrier 40<br>20 40<br>0 0 0<br>d 60 f h<br>σ(∆ V 1 e )/√2 = 63 mV Mean: 79 ± 8 mV σ( VP - VB ) = 0.13 V<br>120<br>80<br>40<br>50 nm SiGe  80<br>barrier 20 40<br>40<br>0 0 0<br>-0.4 -0.2 0.0 0.2 0.4 0 0.04 0.08 0.12 0 0.4 0.8 1.2<br>Matched pair ∆ V 1 e  (V) 1 e -2 e  addition voltage (V/ e ) ( VP - VB )|1 e  (V)<br>Г < 1 kHz<br>Г >  kBT/h<br>n = 0 e n = 1 e n = 2 e<br>Dual barrier voltage (V) Lock-in signal (arb. units)  voltage tuning (V)1 e<br>Count<br>Count Count<br>Count Count Count<br><!-- End of picture text -->

Figure 4: **Single-electron voltage statistics from 12-quantum-dot arrays. a** , Example charge sensing measurement. Bright lines represent electron number transitions in the quantum dot. The red star marks where the single-electron (1 _e_ ) voltages are extracted for the plunger and barrier gates. The red triangle indicates where the voltage difference between plunger and barrier gate is extracted. Dashed lines bound regions of extreme tunnel rate (Γ) (see Methods). **b** , Histograms of 1 _e_ plunger and barrier voltages across the 12QD array. Data is taken from a wafer with a 50 nm SiGe barrier. **c** - **d** , Histograms of 1 _e_ plunger voltage differences calculated between matched gate pairs on a wafer with 30 nm ( **c** ) and 50 nm ( **d** ) SiGe barrier. **e** - **f** , Histograms of 1 _e_ -2 _e_ addition voltage taken on a wafer with 30 nm ( **e** ) and 50 nm ( **f** ) SiGe barrier. The uncertainties shown are standard deviations. **g** - **h** , Histograms of voltage difference between plunger and barrier gates at the 1 _e_ transition taken on a wafer with 30 nm ( **g** ) and 50 nm ( **h** ) barrier wafer. 

The measurements presented so far are all taken in the transport regime, where devices are operated as 1D transistors or many-electron quantum dots. Spin qubit operations typically require tuning the electron occupancy to one electron per quantum dot. Accessing this single-electron regime can be challenging even for devices that perform well in transport, as reducing the charge number increases sensitivity to atomistic disorder. To characterize the single-electron regime of these devices, we perform automated charge sensing measurements with each of the twelve quantum dots in the linear array. A typical measurement is shown in Fig. 4a. In this 2D sweep, the horizontal axis is plunger voltage, and the vertical axis is the voltage of both barrier gates [41]. (See Methods for more details.) Charge sensing scans are taken for all 12 quantum dot sites in the linear array, across 58 die on the wafer, for a total of 696 quantum dot sites. Over the 696 scans taken on a wafer with 50 nm SiGe barrier, we find a 91% success rate in observing clear transitions (as gauged by eye relative to the noise background). This success rate represents highly consistent device performance and is primarily limited by the measurement algorithm (see Methods). 

For further analysis on the 91% of successful scans on this wafer, we apply a numerical algorithm to detect transition curves in the 2D data and extract the coordinates for the first electron (1 _e_ ) transition (see Methods) [36]. We define the “1 _e_ voltage” as the plunger voltage position of the 1 _e_ transition at the midpoint of the barrier voltage axis, indicated by the red star in Fig. 4a. We use the distance between the transition voltage and the left edge of the scan window to gain high confidence that these transitions represent the first 

6 

electron in the quantum dot (see Methods). 

A summary of plunger and barrier voltages at the 1 _e_ transition is shown in Fig. 4b. These data represent the voltages needed to set the 1 _e_ charge state in individual sites of 12QD arrays, sampled across a 300 mm wafer. They therefore can reveal how process variation translates to variation in the spin qubit operating point. Improving variation in spin qubit operating voltage has multiple benefits. Lower 1 _e_ voltage variation makes for easier automation, as operating voltages are more predictable. Lower variation can also enable pathways for alleviating the interconnect bottleneck, as in proposals based on floating memory [42] or on voltage sharing among spin qubit lines [43, 44]. For the former, lower variation can reduce the amount of classical circuitry needed to operate an array, while for the latter, lower variation will allow larger numbers of qubits to be accurately controlled with shared voltages. 

To analyze the variation in 1 _e_ transition voltage data, we repeat the same matched pair voltage difference analysis as above, taking differences between 1 _e_ voltages for mirrored pairs of plunger gates. Since this method highlights the variation within individual devices, it is well suited to benchmarking devices’ potential for voltage-sharing, where gate-to-gate variation, as opposed to die-to-die variation, is most relevant. The resulting distributions of voltage differences are shown in Fig. 4c-d for two wafers. The random variation in 1 _e_ voltage extracted from wafers with a 30 nm and 50 nm SiGe barrier are 61 mV and 63 mV, respectively. Both of these values are close to the random variation in gate _VT_ (59 mV), suggesting the random variation of a transistor-like metric (gate _VT_ ) is matched by the random variation of a quantum metric (1 _e_ voltage). We also observe strong correlation (correlation coefficient _ρ >_ 0 _._ 9) between _V_ 1 _e_ and _VT_ datasets (see Extended Data Fig. 6a). Altogether, this implies that these devices are not subject to significantly increased disorder at the single electron regime compared with the many electron regime. Also, while the 1 _e_ voltage variation is nearly the same between the two wafers, this variation can be better compared through the ratio of 1 _e_ voltage variation and 1 _e_ -2 _e_ addition voltage (Fig. 4e-f). This ratio effectively converts voltage variation to units of electron number and can be a useful benchmark for voltage-sharing applications [32]. These ratios are (1 _._ 0 _±_ 0 _._ 1) _e_ and (0 _._ 80 _±_ 0 _._ 08) _e_ for the 30 nm and 50 nm barrier wafer, respectively. The observation that the wafer with a deeper quantum well has a reduced ratio of this kind suggests that the 1 _e_ voltage variation is dominated by sources in the gate stack above the heterostructure. These sources could include charge defects (e.g., interface traps or fixed charge in the oxide), gate line edge roughness, gate work function variation, oxide thickness variation, or some combination. These possible sources of variation all have analogies in the transistor field and could be improved by borrowing similar strategies; for example, the impact of oxide charge defects could be reduced by decreasing the oxide thickness between the heterostructure and the gate [29]. Measurements of carrier mobility on wafers with 30 nm and 50 nm SiGe barrier also show that samples with shallower quantum wells are subject to increased remote charge scattering (see Methods and Extended Data Fig. 3), suggesting gains can be made by further reducing fixed charge in our high- _κ_ stack. 

The charge sensing data can also be used to benchmark the compatibility of these devices with voltagesharing protocols [43, 44]. One basic requirement for such schemes could be that all quantum dots in an array be tuned to the same electron number using the same voltage. From the 1 _e_ and 2 _e_ voltages obtained here, we estimate that a median of 63% of quantum dots per 12QD device could be set to _n_ = 1 _e_ with a common voltage. (See Methods for more detail and Extended Data Fig. 5.) While this result is still far from the level of uniformity needed to tune an ensemble of spin qubits to their operating point with shared voltages, the 1 _e_ voltage variation results in Fig. 4 highlight the device metrics that must be further improved in order for voltage sharing protocols to be feasible in large spin qubit processors. 

To further assess variation at the single electron regime, we calculate the standard deviation of the difference between plunger and barrier voltages at the cutoff point of the 1 _e_ transition line [24]. Using the datasets (see Fig. 4g-h) from the wafer with 30 (50) nm SiGe barrier, we calculate a standard deviation of 0.12 (0.13) V, in agreement with the values reported in Ref. [24] for six-dot devices with high exchange qubit fidelity [9]. This further confirms that the devices studied here can achieve low levels of disorder at the single electron regime while being fabricated with a high-yield 300 mm process. We also find that devices from these wafers perform well when operated as spin qubits (see Extended Data Fig. 1). Across many devices and wafers, we measure, on average, coherence times of _T_ 2<sup>_∗_=0.6</sup><sup>_µ_s</sup> (5 _µ_ s) and _T_ 2<sup>Echo</sup> = 98 _µ_ s (205 _µ_ s) for<sup>Nat</sup> Si (<sup>28</sup> Si) quantum wells, limited by (residual) nuclear spins. In a 28Si device, we also demonstrate high single qubit Clifford fidelities of _∼_ 99.9%, on par with leading results across the field. We find furthermore that the high electrostatic reliability demonstrated here allows us to efficiently gather data on many qubits towards studies of variability. The high device yield combined 

7 

with cryo-prober testing enables a straightforward path from device fabrication to the study of spin qubits, eliminating failures due to yield or electrostatics at the dilution refrigerator stage. Thanks to a low disorder host material (Si/SiGe), an all CMOS industry-compatible fabrication process with low process variation, and a high volume cryogenic testing method, we achieve a large and extensible unit cell of up to 12 qubits. While future work at mK temperatures will involve expanding operation of this unit cell, high-volume testing with the cryoprober will continue to enable process optimization to reduce variation and disorder as well as more advanced performance screening (for, e.g., charge noise, inter-dot coupling, and 1 _e_ transition disorder) to identify the leading-edge test chips for quantum computing applications. Altogether, these results set a new standard for the scale and reliability of spin qubit devices today and pave the way for significantly larger and more complex spin qubit arrays of the future. 

## **References** 

- [1] Floris A. Zwanenburg, Andrew S. Dzurak, Andrea Morello, Michelle Y. Simmons, Lloyd C. L. Hollenberg, Gerhard Klimeck, Sven Rogge, Susan N. Coppersmith, and Mark A. Eriksson. Silicon quantum electronics. _Rev. Mod. Phys._ , 85(3):961, 2013. 

- [2] Michel H. Devoret and John M. Martinis. Implementing qubits with superconducting integrated circuits. _Quantum Information Processing_ , 3:163–203, 2004. 

- [3] Sankar Das Sarma, Michael Freedman, and Chetan Nayak. Majorana zero modes and topological quantum computation. _npj Quantum Inf._ , 1:15001, 2015. 

- [4] Xin Zhang, Hai-Ou Li, Gang Cao, Ming Xiao, Guang-Can Guo, and Guo-Ping Guo. Semiconductor quantum computation. _National Science Review_ , 6(1):32–54, 2018. 

- [5] Guido Burkard, Thaddeus D. Ladd, Andrew Pan, John M. Nichol, and Jason R. Petta. Semiconductor spin qubits. _Rev. Mod. Phys._ , 95:025003, 2023. 

- [6] Xiao Xue, Maximilian Russ, Nodar Samkharadze, Brennan Undseth, Amir Sammak, Giordano Scappucci, and Lieven M. K. Vandersypen. Quantum logic with spin qubits crossing the surface code threshold. _Nature_ , 601:343–347, 2022. 

- [7] Akito Noiri, Kenta Takeda, Takashi Nakajima, Takashi Kobayashi, Amir Sammak, Giordano Scappucci, and Seigo Tarucha. Fast universal quantum gate above the fault-tolerance threshold in silicon. _Nature_ , 601:338–342, 2022. 

- [8] Adam R. Mills, Charles R. Guinn, Michael J. Gullans, Anthony J. Sigillito, Mayer M. Feldman, Erik Nielsen, and Jason R. Petta. Two-qubit silicon quantum processor with operation fidelity exceeding 99%. _Sci. Adv._ , 8(14), 2022. 

- [9] Aaron J. Weinstein, Matthew D. Reed, Aaron M. Jones, Reed W. Andrews, David Barnes, Jacob Z. Blumoff, Larken E. Euliss, Kevin Eng, Bryan H. Fong, Sieu D. Ha, Daniel R. Hulbert, Clayton A. C. Jackson, Michael Jura, Tyler E. Keating, Joseph Kerckhoff, Andrey A. Kiselev, Justine Matten, Golam Sabbir, Aaron Smith, Jeffrey Wright, Matthew T. Rakher, Thaddeus D. Ladd, and Matthew G. Borselli. Universal logic with encoded spin qubits in silicon. _Nature_ , 615:817–822, 2023. 

- [10] Matthias Brauns, Sergey V. Amitonov, Paul-Christiaan Spruijtenburg, and Floris A. Zwanenburg. Palladium gates for reproducible quantum dots in silicon. _Scientific Reports_ , 8(5690), 2018. 

- [11] J. P. Dodson, Nathan Holman, Brandur Thorgrimsson, Samuel F. Neyens, E. R. MacQuarrie, Thomas McJunkin, Ryan H. Foote, L. F. Edge, S. N. Coppersmith, and M. A. Eriksson. Fabrication process and failure analysis for robust quantum dots in silicon. _Nanotechnology_ , 31(50):505001, 2020. 

- [12] Charles Tahan. Opinion: Democratizing spin qubits. _Quantum_ , 5:584, 2021. 

8 

- [13] R. Pillarisetty, H. C. George, T. F. Watson, L. Lampert, N. Thomas, S. Bojarski, P. Amin, R. Caudillo, E. Henry, N. Kashani, P. Keys, R. Kotlyar, F. Luthi, D. Michalak, K. Millard, J. Roberts, J. Torres, O. Zietz, T. Krähenmann, A. M. Zwerver, M. Veldhorst, G. Scappucci, L. M. K. Vandersypen, and J. S. Clarke. High volume electrical characterization of semiconductor qubits. In IEEE, editor, _2019 IEEE International Electron Devices Meeting (IEDM)_ , pages 31.5.1–31.5.4, 2019. 

- [14] Barbara M. Terhal. Quantum error correction for quantum memories. _Rev. Mod. Phys._ , 87(2):307, 2015. 

- [15] Stephan G. J. Philips, Mateusz T. Mądzik, Sergey V. Amitonov, Sander L. de Snoo, Maximilian Russ, Nima Kalhor, Christian Volk, William I. L. Lawrie, Delphine Brousse, Larysa Tryputen, Brian Paquelet Wuetz, Amir Sammak, Menno Veldhorst, Giordano Scappucci, and Lieven M. K. Vandersypen. Universal control of a six-qubit quantum processor in silicon. _Nature_ , 609:919–924, 2022. 

- [16] A. R. Mills, D. M. Zajac, M. J. Gullans, F. J. Schupp, T. M. Hazard, and J. R. Petta. Shuttling a single charge across a one-dimensional array of silicon quantum dots. _Nat. Commun._ , 10:1063, 2019. 

- [17] C. Volk, A. M. J. Zwerver, U. Mukhopadhyay, P. T. Eendebak, C. J. van Diepen, J. P. Dehollain, T. Hensgens, T. Fujita, C. Reichl, W. Wegscheider, and L. M. K. Vandersypen. Loading a quantum-dot based “qubyte” register. _npj Quantum Inf._ , 5:29, 2019. 

- [18] Pierre-André Mortemousque, Emmanuel Chanrion, Baptiste Jadot, Hanno Flentje, Arne Ludwig, Andreas D. Wieck, Matias Urdampilleta, Christopher Bäuerle, and Tristan Meunier. Coherent control of individual electron spins in a two-dimensional quantum dot array. _Nat. Nanotechnol._ , 16:296–301, 2021. 

- [19] Francesco Borsoi, Nico W. Hendrickx, Valentin John, Marcel Meyer, Sayr Motz, Floor van Riggelen, Amir Sammak, Sander L. de Snoo, Giordano Scappucci, and Menno Veldhorst. Shared control of a 16 semiconductor quantum dot crossbar array. _Nat. Nanotechnol._ , 2023. 

- [20] Dave Wecker, Bela Bauer, Bryan K. Clark, Matthew B. Hastings, and Matthias Troyer. Gate-count estimates for performing quantum chemistry on small quantum computers. _Phys. Rev. A_ , 90(2):022305, 2014. 

- [21] Craig Gidney and Martin Ekerå. How to factor 2048 bit RSA integers in 8 hours using 20 million noisy qubits. _Quantum_ , 5:433, 2021. 

- [22] Kelin J. Kuhn, Martin D. Giles, David Becher, Pramod Kolar, Avner Kornfeld, Roza Kotlyar, Sean T. Ma, Atul Maheshwari, and Sivakumar Mudanai. Process technology variation. _IEEE Transactions on Electron Devices_ , 58(8):2197–2208, 2011. 

- [23] R. Li, N. I. Dumoulin Stuyck, S. Kubicek, J. Jussot, B. T. Chan, F. A. Mohiyaddin, A. Elsayed, M. Shehata, G. Simion, C. Godfrin, Y. Canvel, Ts. Ivanov, L. Goux, B. Govoreanu, and I. P. Radu. A flexible 300 mm integrated Si MOS platform for electron- and hole-spin qubits exploration. In IEEE, editor, _2020 IEEE International Electron Devices Meeting (IEDM)_ , pages 38.3.1–38.3.4, 2020. 

- [24] Wonill Ha, Sieu D. Ha, Maxwell D. Choi, Yan Tang, Adele E. Schmitz, Mark P. Levendorf, Kangmu Lee, James M. Chappell, Tower S. Adams, Daniel R. Hulbert, Edwin Acuna, Ramsey S. Noah, Justine W. Matten, Michael P. Jura, Jeffrey A. Wright, Matthew T. Rakher, and Matthew G. Borselli. A flexible design platform for Si/SiGe exchange-only qubits with low disorder. _Nano Lett._ , 22(3):1443–1448, 2022. 

- [25] Fabio Ansaloni, Anasua Chatterjee, Heorhii Bohuslavskyi, Benoit Bertrand, Louis Hutin, Maud Vinet, and Ferdinand Kuemmeth. Single-electron operations in a foundry-fabricated array of quantum dots. _Nat. Commun._ , 11:6399, 2020. 

- [26] A. M. J. Zwerver, T. Krähenmann, T. F. Watson, L. Lampert, H. C. George, R. Pillarisetty, S. A. Bojarski, P. Amin, S. V. Amitonov, J. M. Boter, R. Caudillo, D. Correas-Serrano, J. P. Dehollain, G. Droulers, E. M. Henry, R. Kotlyar, M. Lodari, F. Luthi, D. J. Michalak, B. K. Mueller, S. Neyens, J. Roberts, N. Samkharadze, G. Zheng, O. K. Zietz, G. Scappucci, M. Veldhorst, L. M. K. Vandersypen, and J. S. Clarke. Qubits made by advanced semiconductor manufacturing. _Nat. Electron._ , 5:184–190, 2022. 

9 

- [27] P. W. Deelman, L. F. Edge, and C. A. Jackson. Metamorphic materials for quantum computing. _MRS Bulletin_ , 41(3):224–230, 2016. 

- [28] G. Scappucci, P. J. Taylor, J. R. Williams, T. Ginley, and S. Law. Crystalline materials for quantum computing: Semiconductor heterostructures and topological insulators exemplars. _MRS Bulletin_ , 46:596–606, 2021. 

- [29] R. Kotlyar, S. Premaratne, G. Zheng, J. Corrigan, R. Pillarisetty, S. Neyens, O. Zietz, T. Watson, F. Luthi, F. Borjans, L. Lampert, E. Henry, H. George, S. Bojarski, J. Roberts, A. Y. Matsuura, and J. S. Clarke. Mitigating impact of defects on performance with classical device engineering of scaled Si/SiGe qubit arrays. In IEEE, editor, _2022 International Electron Devices Meeting (IEDM)_ , pages 8.4.1–8.4.4, 2022. 

- [30] Merritt P. Losert, M. A. Eriksson, Robert Joynt, Rajib Rahman, Giordano Scappucci, Susan N. Coppersmith, and Mark Friesen. Practical strategies for enhancing the valley splitting in Si/SiGe quantum wells. _Phys. Rev. B_ , 108:125405, 2023. 

- [31] D. R. Ward, D. E. Savage, M. G. Lagally, S. N. Coppersmith, and M. A. Eriksson. Integration of on-chip field-effect transistor switches with dopantless Si/SiGe quantum dots for high-throughput testing. _Appl. Phys. Lett._ , 102:213107, 2013. 

- [32] P. L. Bavdaz, H. G. J. Eenink, J. van Staveren, M. Lodari, C. G. Almudever, J. S. Clarke, F. Sebastiano, M. Veldhorst, and G. Scappucci. A quantum dot crossbar with sublinear scaling of interconnects at cryogenic temperature. _npj Quantum Inf._ , 8:86, 2022. 

- [33] B. Paquelet Wuetz, P. L. Bavdaz, L. A. Yeoh, R. Schouten, H. van der Does, M. Tiggelman, D. Sabbagh, A. Sammak, C. G. Almudever, F. Sebastiano, J. S. Clarke, M. Veldhorst, and G. Scappucci. Multiplexed quantum transport using commercial off-the-shelf CMOS at sub-kelvin temperatures. _npj Quantum Inf._ , 6:43, 2020. 

- [34] F. Schäffler. High-mobility Si and Ge structures. _Semicond. Sci. Tech._ , 12(12):1515–1549, 1997. 

- [35] Chenming Hu. _Modern Semiconductor Devices for Integrated Circuits_ . Pearson, 2009. 

- [36] L.C. Contamin, B. Cardoso Paz, B. Martinez Diaz, B. Bertrand, H. Niebojewski, V. Labracherie, A. Sadik, E. Catapano, M. Cassé, E. Nowak, Y.-M. Niquet, F. Gaillard, T. Meunier, P.-A. Mortemousque, and M. Vinet. Methodology for an efficient characterization flow of industrial grade Si-based qubit devices. In IEEE, editor, _2022 International Electron Devices Meeting (IEDM)_ , pages 22.1.1– 22.1.4, 2022. 

- [37] D. M. Zajac, T. M. Hazard, X. Mi, K. Wang, and J. R. Petta. A reconfigurable gate architecture for Si/SiGe quantum dots. _Appl. Phys. Lett._ , 106:223507, 2015. 

- [38] Jurriaan Schmitz. Low temperature thin films for next-generation microelectronics (invited). _Surface and Coatings Technology_ , 343:83–88, 2018. 

- [39] Daniel Loss and David P. DiVincenzo. Quantum computation with quantum dots. _Phys. Rev. A_ , 57(1):120, 1998. 

- [40] D. P. DiVincenzo, D. Bacon, J. Kempe, G. Burkard, and K. B. Whaley. Universal quantum computation with the exchange interaction. _Nature_ , 408:339–342, 2000. 

- [41] M. G. Borselli, K. Eng, R. S. Ross, T. M. Hazard, K. S. Holabird, B. Huang, A. A. Kiselev, P. W. Deelman, L. D. Warren, I. Milosavljevic, A. E. Schmitz, M. Sokolich, M. F. Gyure, and A. T. Hunter. Undoped accumulation-mode Si/SiGe quantum dots. _Nanotechnology_ , 26:375202, 2015. 

- [42] M. Veldhorst, H. G. J. Eenink, C. H. Yang, and A. S. Dzurak. Silicon CMOS architecture for a spin-based quantum computer. _Nat. Commun._ , 8:1766, 2017. 

10 

- [43] Ruoyu Li, Luca Petit, David P. Franke, Juan Pablo Dehollain, Jonas Helsen, Mark Steudtner, Nicole K. Thomas, Zachary R. Yoscovits, Kanwal Singh, Stephanie Wehner, Lieven M. K. Vandersypen, James S. Clarke, and Menno Veldhorst. A crossbar network for silicon quantum dot qubits. _Sci. Adv._ , 4(7), 2018. 

- [44] Jelmer M. Boter, Juan P. Dehollain, Jeroen P. G. van Dijk, Yuanxing Xu, Toivo Hensgens, Richard Versluis, Henricus W. L. Naus, James S. Clarke, Menno Veldhorst, Fabio Sebastiano, and Lieven M. K. Vandersypen. Spiderweb array: A sparse spin-qubit array. _Phys. Rev. Applied_ , 18:024053, 2022. 

11 

## **Methods** 

### **Electron temperature measurement** 

Electron temperature in the cryo-prober is measured from a charge stability diagram, using a transition line that is tuned to avoid tunnel rate broadening. This stability diagram is shown in Extended Data Fig. 2a. A 1D measurement of the transition line is then taken to extract the width of the transition line. The lock-in data is integrated with respect to swept voltage and subtracted by a linear background. The resulting data is then fit to the model for a temperature-broadened charge sensor transition [45] to extract an electron temperature of 1 _._ 6 _±_ 0 _._ 2 K. The processed data and theoretical fit are shown in Extended Data Fig. 2b. The uncertainty is estimated from the uncertainty of the lever arm (0 _._ 08 _±_ 0 _._ 01), which is measured from bias triangles. We attribute the relatively large offset between the electron temperature and the base temperature of the stage to two possible limiting factors: a lack of filtering on the DC wiring and thermal resistance between the wafer and the chuck. Improvements to the electron temperature could be made through addition of low pass filters to the wiring, providing better thermalization of the probes, and/or decreasing the thermal resistance between the wafer and the chuck. 

### **Test structure probing** 

The mask set used in this work produces many different device types on each wafer, including fully integrated spin qubit arrays and test structures. These test structures are designed to emulate sub-components of the complete devices and aid in both troubleshooting and targeting specific processes within the fabrication flow. All structures have the same pad design (100 _×_ 100 _µ_ m<sup>2</sup> in size with 150 _µ_ m pitch) to match the probe pin array (see Extended Data Fig. 3a-b), allowing many different structures to be measured in situ. Switching among device types simply requires changes in software or minor changes at the electronics rack. The performance of all these structures is improved through process optimization, guided by feedback from the cryo-prober. The following sections focus on two such test structures: gate line resistance structures and Hall bars. 

#### **Gate line resistance measurements** 

The DC gate line resistance, including both gate and interconnect layer, is an important factor in RF ( _∼_ 0.1-20 GHz) signal delivery during qubit control. Improvements in gate line resistance across multiple wafers are shown in Extended Data Fig. 3c. Here gate line resistance is reduced through optimization of the gate fabrication process with normal-conducting materials and through the introduction of superconducting materials to the stack. Validating the superconducting process in particular is made possible by the 1.6 K base temperature of the cryo-prober. For the fully normal-conducting wafers, improvements come from increasing the cross-sectional area at the smallest bottleneck of the gate line. Of the partially superconducting wafers, the first wafer (with median resistance of _∼_ 78 Ω) includes superconducting materials in the gate layer but still has a normal-conducting interconnect layer. The second wafer (with a median resistance of _∼_ 6 Ω) includes superconducting materials in both gate and interconnect layers. We note that these measurements are taken using two-point resistance test structures and include a wiring resistance of _∼_ 30 Ωwhich is subtracted from the plotted data. The small remaining resistance in the metal stack with both layers superconducting could be due to the uncertainty in the wiring and probing resistance or to the via between gate and interconnect layers remaining normal-conducting. (See Supplementary Information for more characterization of the superconducting layers.) 

#### **Carrier mobility measurements** 

Carrier mobility is an important metric for spin qubits. In the case of Si/SiGe devices, electron mobility is a direct measure of the quality of the Si quantum well where qubits are defined and provides a target for optimizing the heterostructure growth recipe. While a magnetic field is needed to measure mobility most accurately, we can use cryo-prober measurements to generate a reasonable estimate to compare the quantum well quality of different wafers. 

12 

Carrier mobility is estimated from measurements of channel resistance in 4-probe Hall bar devices at zero magnetic field. A schematic of the measurement configuration is shown in Extended Data Fig. 3b. Each device has 6 ohmic contacts, enabling 2 separate channel resistance (and mobility) measurements per device. The mobility calculation depends on knowing the carrier density, so we approximate a fixed carrier density (4 _×_ 10<sup>11</sup> cm<sup>_−_2</sup> ) by measuring the device threshold voltage ( _VT_ ) and setting the gate voltage to _VT_ + ∆ _V_ where ∆ _V_ = _e_ ∆ _n/cg_ , _e_ is the electron charge, ∆ _n_ is the approximated carrier density, and _cg_ is the estimated gate capacitance per area based on TEM imaging of the gate stack. With this method, additional uncertainty comes from the unknown threshold density ( _nt_ ) at which the device first shows a threshold current, so approximating _n_ = ∆ _n_ will lead to a systematic over-estimate of mobility by a factor of (1 + _nt/_ ∆ _n_ ). From measurements in a conventional cryostat with magnetic field control, we estimate a typical threshold density to be _nt ∼_ 1 _._ 5 _×_ 10<sup>11</sup> cm<sup>_−_2</sup> , suggesting actual mobilities are _∼_ 30% less than the estimates generated in this way. 

Using this estimation method, we observe improvements in mobility distributions across multiple wafers as shown in Extended Data Fig. 3d. All wafers shown have the same quantum well thickness of _∼_ 5 nm. We attribute the mobility improvements to two changes: increasing the SiGe barrier thickness (from 30 nm to 50 nm), thereby reducing remote scattering from charge centers in the gate stack; and improving the quantum well growth recipe itself (“QW A” to “QW B”) to reduce background oxygen concentration. For the highest-mobility process, we also observe a similar mobility distribution before and after isotopic purification of the quantum well to<sup>28</sup> Si, confirming epitaxial quality is maintained with the purified growth precursor. 

To further understand these observations, we select two samples with the QW B process (one with 30 nm and one with 50 nm SiGe barrier) and perform measurements in a conventional cryostat with magnetic field control (Quantum Design PPMS Dynacool) at a temperature of 1.7 K. These measurements are shown in Extended Data Fig. 3e. Here we confirm the observation from the cryo-prober measurements that samples with the deeper quantum well have higher mobility. We also find that the absolute values of mobility are _∼_ 30% less than the estimates from the cryo-prober, confirming the expected systematic offset. The two samples also show a difference in the dependence of mobility on carrier density in the high-density regime ( _∼_ 5 _×_ 10<sup>11</sup> cm<sup>_−_2</sup> ). These different trends suggest different mobility limiting mechanisms: remote scattering in the case of the 30 nm SiGe barrier, and scattering in or near the quantum well in the case of the 50 nm SiGe barrier [46]. Overall, these measurements confirm that estimated mobility distributions obtained with the cryo-prober are useful for detecting significant changes in carrier mobility resulting from heterostructure changes. 

We note that in these datasets, all wafers contain a fraction of devices (10-30%) with significantly reduced mobility, as can be seen in Extended Data Fig. 3d. This statistical phenomenon is confirmed with conventional Hall measurements and is not an artifact of the measurement method. By measuring mobility on both halves of devices, we also observe that this mobility degradation can be limited to a single half of the device, suggesting it arises from a discrete defect mode, such as pile-ups of misfit dislocations [47]. By overlaying the Hall bar outline on a map of such defect pile-ups, we estimate that _∼_ 25% of Hall bars could be bisected by such defects, roughly matching the observed frequency of mobility degradation. We expect the bimodal distribution of mobility is also related to the size of the Hall bars (6 _µ_ m in width), which could allow a single defect pile-up to have an outsized effect on the mobility extracted from a single device half. The comparatively high yield of 12-quantum-dot arrays on these wafers could be explained by those arrays’ much smaller size (at least two orders of magnitude), making them much less likely to overlap these defects. By the same reasoning, we expect larger hall bars fabricated on the same wafers would overlap more of these defects, averaging out the impact of individual defects and possibly resulting in a more unimodal distribution of mobility. 

### **Automated device measurements** 

After a device is contacted with the probes, each current channel in the device (including the qubit channel and the four charge sensor channels) is turned on with all gates over that channel at the same voltage. Once each channel’s _VT_ is recorded, the gates of each channel are set to a fixed voltage relative to the channel _VT_ . The qubit channel is then isolated from the sensor channels by reducing the center screening gate voltage until the cross-conductance between channels drops to zero (within the noise floor). The voltage of individual 

13 

gates is then fine-tuned to set a roughly uniform carrier density across the channel. This is done through an iterative process where the transconductance of each gate is sampled and the voltage on that gate is increased (decreased) if the transconductance is above (below) a threshold value. These transconductance thresholds are calculated relative to the absolute value of device current ( _I_ 0), and are set at 0 _._ 5 _I_ 0 A/V and 2 _._ 0 _I_ 0 A/V for the low threshold and high threshold, respectively. This effectively sets the voltages of all gates so they are at roughly the same point on their pinch-off curves relative to their _VT_ . The _VT_ data for all gates is extracted from pinch-off curves taken with a source-drain bias of 1 mV. _VT_ is identified using the constant-current method [48] with a constant current of 1 nA. This current is chosen to be well above the offset of the current preamplifiers ( _<_ 100 pA). The sweep range for the pinch-off curves is set from well below zero (-0.5 V) to the gate’s accumulated voltage after fine tuning, ensuring that the scan range includes the pinch-off point despite variation in _VT_ from gate to gate. 

The voltages needed to tune up a quantum dot at each site are identified by setting each plunger gate to a fixed voltage relative to its _VT_ and varying the barrier gate voltages about their individual _VT_ values in a 2D sweep (a barrier-barrier scan). A phenomenological 2D function is fitted to this data to extract the corner point, which combined with the plunger voltage is used to define the “tune-up” parameters for the quantum dot site. Defining the barrier sweep range based on the gates’ _VT_ values ensures that the scan window is positioned to include this tune-up point despite variation in its location from gate to gate. 

The charge sensing measurements shown in Fig. 4 are taken with one quantum dot tuned up at a time on the qubit side. The closest charge sensor to that quantum dot is also tuned up, and neighboring charge sensor dots are pinched off with their respective plunger gates. Changes in electron number are detected using a lock-in technique. A modulation voltage of 3 mV (RMS) at a frequency of _∼_ 1 kHz is applied to the screening gate on the qubit side and the current through the charge sensor is read out with a lock-in amplifier at a sample time of 10 ms. To generate the charge sensing measurement, the plunger voltage is swept at a fixed range relative to its _VT_ , and the two barrier gate voltages are stepped simultaneously. The barrier gates are stepped over the same voltage interval but with different voltage values. The step values of each barrier gate are defined relative to that gate’s individual “tune-up” voltage extracted from the barrier-barrier scan. In the example shown in Fig. 4a, the barrier voltage range displayed on the vertical axis is the voltage of the left barrier gate. The sweep range is chosen to take each quantum dot from zero-electron to several-electron occupation along the plunger axis and from low tunnel rate (Γ _≪_ 1 kHz) to high tunnel rate (Γ _≫_ 1 GHz) along the barrier axis. Transition lines disappear at the bottom of the scan window where tunnel rate falls below two times the lock-in frequency ( _∼_ 1 kHz) and at the top of the scan window where the lines become broadened by tunnel coupling energy. For wafer-level maps of the charge sensing measurements used to collect the 1 _e_ voltage data summarized in Fig. 4, see Extended Data Figs. 8 and 9. 

Automated charge sensing measurements can also be taken on double quantum dots. The three barrier gates that define each double quantum dot are first set to a fixed voltage relative to their individual _VT_ values. The plunger gate voltages for each dot are then swept to generate a 2D charge stability diagram. While these scans are not analyzed quantitatively in this work, a demonstration of this type of measurement can be seen in Extended Data Fig. 10. 

We note that the overall device measurement rate is predominately set by the speed of measurement hardware. Significant gains can therefore be made by implementing faster hardware (e.g., arbitrary waveform generators) and higher-bandwidth amplification (e.g., cryogenic amplifiers [49]) without any further changes to the tune-up procedure. 

### **Threshold voltage measurements** 

The _VT_ data shown in Fig. 2b is collected using the procedure described in the Methods section on automated device measurements. The data summarized in Fig. 2b contains a combination of _VT_ data from plunger and barrier gates on both the qubit and the charge sensor sides of devices. For the earlier versions of devices (first ten wafers shown), data is taken from a combination of 3-quantum-dot (3QD) and 12QD arrays. For the optimized version (last five wafers shown), all data is taken from 12QD arrays. 

14 

### **Barrier-barrier scans** 

To qualitatively characterize quantum dot confinement in our devices, a measurement referred to as a “barrier-barrier scan” is used. This involves a 2D sweep of the barrier gate voltages that define each quantum dot while measuring the transport current through the quantum dot. Current oscillations in these scans indicate the formation of a quantum dot between the two barrier gates, as transport between source and drain becomes dominated by Coulomb blockade [50]. Fig. 2c shows examples of these measurements from each of the three fabrication versions featured in Fig. 2b. The first two versions show significant disorder and/or instability in these measurements. By comparison, the optimized process, incorporating reductions in fixed charge and the additional screening gate layer, leads to clean confinement with the barrier gates and stable current throughout the length of the scan. Extended Data Fig. 7 shows more examples of these scans taken across wafers with each of the three versions of fabrication. 

### **Yield analysis** 

The measurements of yield summarized in Table 1 are taken from a total of 232 12QD devices, spanning 58 die across the wafer and including four nominally identical devices per die. We exclude the outer-most ring of die at the edge of the wafer as these are not targeted in all steps of fabrication. The component yield metrics are calculated using the following definitions. Ohmic contact yield is defined as the fraction of contacts through which current in the Si quantum well can be linearly controlled. Gate yield is defined as the fraction of gates that can be used to turn on and pinch off their respective current channel. Quantum dot yield is defined as the fraction of quantum dot sites where a viable quantum dot tune-up point can be identified from barrier-barrier scans. Failure to identify this tune-up point is determined by the fitting procedure failing to converge and therefore not outputting any barrier voltage values. This occurs when the data fails to conform to the phenomenological model of a “corner point” where current is pinched off simultaneously by both gates. For the data used here to calculate yield, we also examine all instances of failed fits by eye to confirm they are not the result of an error in the fitting procedure. Lastly, full device yield is defined as the fraction of devices where all sub-components (all ohmic contacts, gates, and quantum dots) yield. 

Out of 3,712 quantum dot sites tested and summarized in Table 1, the nine that fail to tune up are also observed to have anomalously low pinch-off voltage ( _<_ 0.2 V) on at least one of the three gates defining that quantum dot. These nine sites are also confined to the charge sensor side, where gate geometry is most complex. This indicates that this small number of non-yielding quantum dots is due to the processing of the 0.3% most marginal gates as opposed to, e.g., quantum well defects. We attribute these edge cases on the charge sensor side to a known failure mode in the gate lithography process. We note that the paths to improving the robustness of this process to fix these extreme outlier cases are well understood. 

### **Matched pair voltage difference analysis** 

When working with distributions of gate parameters such as threshold voltage ( _VT_ ) or 1-electron voltage ( _V_ 1 _e_ ), there are a variety of possible methods for analyzing variation. The simplest is the standard deviation of each gate voltage distribution. For the 25 plunger and barrier gate distributions shown in Fig. 3c, this standard deviation ranges from 63 to 89 mV. This standard deviation incorporates all causes of cross-wafer variation, including both random effects and systematic cross-wafer phenomena arising from processes like deposition and etch. As a measure of individual device performance, we focus our attention on the random component of this variation, which leads to variation (of _VT_ or _V_ 1 _e_ ) within the length scale of individual devices. To estimate this random component of variation, we adapt a standard CMOS industry method of analyzing matched pair voltage differences [22]. The standard approach for transistor devices is to take the difference between _VT_ values (∆ _VT_ ) of neighboring devices to compare gates that are as close together as possible. For quantum dot devices, which have a more complex, multi-gate structure, there are multiple ways the matched pair method can be adapted. Simply taking the difference between nearest-neighbor gate pairs within the array minimizes the distance between matched pairs but comes with the drawback of introducing systematic effects of gate geometry. Since different gates along the array are subject to different cross-capacitances from their surrounding environment, systematic differences in _VT_ can be present within the array that can show up in the resulting matched pair ∆ _VT_ distributions. Such systematic effects are seen 

15 

clearly in Fig. 3c, where gates nearest to the edge of the array tend to have lower _VT_ due to their different capacitive environment. To factor out these effects of geometry, we choose to perform the matched pair variation analysis using mirror-symmetric pairs rather than nearest-neighbor pairs. This ensures that both gates in every pair are subject to nominally the same capacitive environment, due to the mirror symmetry of the array. Using this approach, we combine the raw ∆ _VT_ data into one distribution and extract the standard deviation. This resulting metric, reduced by a factor of _~~√~~_ 2, represents random variation within the length scale of an individual device, excluding aforementioned systematic sources of die-to-die variation as well as the systematic voltage offsets due to cross-capacitance changes at the edges of the array. The matched pair distributions which result from this analysis are shown in Fig. 3d and Fig. 4c-d for _VT_ and _V_ 1 _e_ , respectively. 

As a check of our approach using mirror-symmetric matched pairs, we take the _V_ 1 _e_ dataset from the wafer with 50 nm SiGe barrier (shown in Fig. 4b) and generate matched pair ∆ _V_ 1 _e_ distributions using both mirrorsymmetric pairs and nearest-neighbor pairs. For each method, the median values of all gate pair distributions are plotted in Extended Data 6b-c. In general, median values near zero indicate that the method is capturing random variation, while median values farther from zero indicate that systematic sources of variation are also playing a role. The distributions generated from nearest-neighbor pairs include median values which are clearly larger than those generated from mirror-symmetric pairs: the largest absolute value median generated from nearest-neighbor (mirror-symmetric) pairs is 89 (48) mV. In the case of nearest-neighbor pairs, this is driven by systematic effects of gate position, as evidenced by the anti-symmetric trend of median value as a function of pair position visible in Extended Data Fig. 6c. When gate pair distributions are combined for both methods, we also find that the nearest-neighbor pair method gives rise to a larger matched pair standard deviation compared to the method of mirror-symmetric pairs (68 mV compared to 63 mV), as shown in Extended Data Fig. 6d-e. This confirms that the matched pair variation in the case of nearest-neighbor pairs is being inflated by systematic geometric effects and that the result from using mirror-symmetric pairs is closer to the intrinsic random variation we intend to capture. Altogether, these findings suggest that use of mirror-symmetric pairs is superior to the use of nearest-neighbor pairs when extending the matched pair variation analysis method to the case of multi-gate quantum dot arrays. 

We note that this approach of using mirror-symmetric pairs may need to be updated as quantum dot arrays become significantly larger, since increased separation between gate pairs could lead to the systematic components of variation being incorporated into the analysis. In this case, plots of median ∆ _V_ 1 _e_ as a function of gate pair like those shown in Extended Fig. 6b will serve as a useful check for whether or not systematic effects are starting to contribute. The 12QD arrays studied here are still of a size where the mirror-symmetric method is valid, as confirmed by the median values found in Extended Data Fig. 6b as well as the finding that all gate pairs within the array can be well approximated as having the same correlation coefficient (see Supplementary Information). Future larger arrays could be handled by limiting the mirror-symmetric pair method to apply only within repeating unit cells of the array, where each unit cell is of a similar size to the 12QD arrays studied here ( _∼_ 1 _µ_ m). 

### **Charge sensing success rate** 

The charge sensing success rate (91%) reported in the main text depends on multiple factors: the relevant sensor quantum dot must yield, the sensing signal must be high enough relative to background noise to resolve transitions, and the charge sensor must remain stable throughout the length of the scan. We attribute the success rate to be mainly limited by factors related to the measurement algorithm: the automated tuning of the charge sensor and instances of charge sensor instability occurring during the scan. Even in cases where both quantum dots (sensor dot and sensed dot) yield, the automated charge sensor tune-up procedure can lead to insufficient signal relative to background noise, and drift of the charge sensor tuning over the timescale (several minutes) of the measurement can degrade the signal. We expect the success rate can therefore be improved with a more sophisticated measurement algorithm, such as by adding additional sweeps of charge sensor gate voltages to optimize sensitivity, or by incorporating active feedback into the measurement loop to analyze data quality [51] and re-take measurements after charge sensor shifts occur. We expect the success rate can also be improved by reducing electron temperature, which will increase charge sensor sensitivity and will possibly improve charge offset stability [52] through de-activation of two-level fluctuators [53]. 

16 

### **Charge sensing transition curve analysis** 

Transition line coordinates are extracted from charge sensing measurements using the following procedure. The raw lock-in amplifier data is first filtered with a first-order Gaussian filter to remove slowly-varying features. A maximum filter is then used to identify features of high signal in the pre-filtered data. An algorithm is then used to convert the set of “maximum points” into a set of “curve segments.” Curve segments are found by searching for groupings of maximum points that satisfy the following criteria: each point in the curve segment must be the closest maximum point to its nearest neighbor; the slope between each pair of neighboring points must be within a target window; and the set of points must span a minimum specified “length” in the vertical direction. Overlapping curve segments are then merged into transition curves. Transition curves are then further filtered to remove outlier curves and ordered by their coordinate means. The first and second transition curve generated from this algorithm are identified with the 1-electron and 2-electron transition, respectively. An example of the entire sequence is shown in Extended Data Fig. 4. The “1 _e_ (2 _e_ ) voltage” is defined as the plunger voltage at which the 1 _e_ (2 _e_ ) transition line crosses the midpoint of the barrier voltage axis. This point corresponds to both barrier gates being tuned to their respective “tune-up” points extracted from the barrier-barrier scans. The 1 _e_ -2 _e_ addition voltage is calculated as the difference between these voltages. We note that in some cases (15%), the 1 _e_ (2 _e_ ) transition in the scan window does not cross the midpoint of the barrier voltage axis, in which case no 1 _e_ (2 _e_ ) transition voltage is extracted from that scan. 

### **Impact of tuning the barrier voltages on 1e voltage variation** 

The analysis of variation in matched pair 1 _e_ voltage differences (∆ _V_ 1 _e_ ) presented in the main text reports the variation in voltage of a single gate voltage (the plunger gate) per quantum dot, analogous to how the analysis is performed for transistors. Given that the gate layout of quantum dot arrays is more complex than a typical transistor, it is important to consider the effect of cross-capacitance from other gates on the extracted ∆ _V_ 1 _e_ variation. In particular, the barrier gates that surround each quantum dot can have high cross-capacitance relative to the plunger gate (as can be seen in Fig. 4a of the main text). 

We perform additional analysis and measurements to quantify the impact of tuning the barrier voltages (as opposed to using fixed barrier voltages) on extracted metrics of 1 _e_ voltage variation. (See Supplementary Information for complete analysis.) These results include two main conclusions. Firstly, we find that tuning the barrier voltages can reduce the absolute standard deviation of 1 _e_ voltage distributions ( _σ_ ( _V_ 1 _e_ )) in the presence of device-level correlations between barrier and plunger voltage offsets. Secondly, we find that tuning the barrier voltages does not reduce the standard deviation of matched pair ∆ _V_ 1 _e_ distribution ( _σ_ (∆ _V_ 1 _e_ )), the main variation metric in this work, due to this metric factoring out the effects of device-level correlations. In fact, this metric of variation tends to increase when tuning the barrier voltages, due to the coupling of uncorrelated voltage offsets on barrier gates to plunger voltage values through cross-capacitance. This increase is greater for devices with greater levels of cross-capacitance. In cases of significant cross capacitance, such as devices studied here with 50 nm SiGe barrier ( _∼_ 55% between nearest neighbors), this increase can be _∼_ 20%. We note that, between the wafers studied in Fig. 4c-d of the main text, cross-capacitance is greater for the wafer with 50 nm SiGe barrier than it is for the wafer with 30 nm SiGe barrier, meaning that this effect of increasing _σ_ (∆ _V_ 1 _e_ ) through barrier tuning is also stronger for the former wafer. This effect therefore does not change the conclusion presented in the main text that the impact of voltage variation is reduced in the wafer with the deeper quantum well. 

In general, while fixing barrier voltages could make for more precise comparison between ∆ _V_ 1 _e_ distributions from wafers with different amounts of cross-capacitance, there are also benefits to tuning the barriers before measurement. Using fine-tuned barrier voltages results in a higher success rate in identifying the 1 _e_ transition in the charge sensing scan window. In our tests, _∼_ 20% fewer matched pairs are obtained for analysis in a “barriers fixed” dataset compared to a “barriers fine-tuned” dataset (see Supplementary Information). Tuning the barrier voltages is therefore a benefit for collecting large and representative datasets through automated measurements. Also, if barrier voltage variation is high, there is some risk of sample bias when using fixed barriers, since quantum dots with the highest barrier voltage offsets may result in 1 _e_ transitions being missed in the automated measurements and therefore not counted. For these reasons, we have maintained using tuned barrier voltages as our standard method for collecting _V_ 1 _e_ statistics. 

17 

### **1e transition validation** 

To validate that the 1 _e_ voltages we report are actually the first electron in the quantum dot, we extract the margin between the 1 _e_ transition voltage and the left edge of the scan window and compare it to the distribution of addition voltages between the 1 _e_ and 2 _e_ transitions. To have high confidence that the first transition represents the first electron, we require this “scan margin” be _>_ 2 times the typical addition voltage. For the 50 nm SiGe barrier wafer characterized in Fig. 4b, 98% of 1 _e_ voltage data points have a scan margin value above this threshold, giving us high confidence that the 1 _e_ transition data summarized in Fig. 4b is actually single-electron data. See Extended Data Fig. 4f-g for histograms of the 1 _e_ -2 _e_ addition voltage and 1 _e_ scan margin data from this wafer. 

### **Voltage sharing analysis** 

To estimate the proportion of quantum dots in each 12QD device that could be set to single-electron occupation with shared voltages, we analyze the 1 _e_ voltage and 2 _e_ voltage data from the 50 nm SiGe barrier wafer and search for a common voltage that best divides the 1 _e_ and 2 _e_ voltage distributions for each 12QD device. In this scheme, any 1 _e_ voltage value above the common voltage ( _V_ common) corresponds to _n_ = 0 _e_ , and any 2 _e_ voltage value below _V_ common corresponds to _n ≥_ 2 _e_ . The remaining instances correspond to quantum dots tuned to _n_ = 1 _e_ . For each device, the optimal _V_ common is found by minimizing the number of instances where _n_ = 0 _e_ or _n ≥_ 2 _e_ . Extended Data Fig. 5 shows a histogram of 1 _e_ and 2 _e_ voltage data points shifted relative to their assigned device-specific _V_ common value. A scatter plot also shows the proportion of quantum dots in each category of electron number for all 12QD devices. The median success rate for tuning dots to _n_ = 1 _e_ is 63%. 

We note that the data used in this analysis comes from measurements of quantum dots tuned one at a time and that this method does not take into account the individualized setpoints of other gates in the array during measurements. We do not expect that tuning the barrier voltages results in an over-estimate of the percentage of quantum dots tunable to 1 _e_ , since we observe that the variation of matched pair 1 _e_ voltage differences increases rather than decreases when the barrier voltages are tuned, due to the factoring out of device-level correlation effects (see Supplementary Information). Similarly, this method of estimating the success rate of voltage sharing is also a measure of the variation within a device, in this case done by comparing individual 1 _e_ and 2 _e_ voltages to a common device-level voltage. Therefore, this method can be expected to factor out the impact of device-level correlations, and for the same reason as the matched pair case, tuning the barrier gates will, if anything, slightly increase the 1 _e_ variation observed for the plunger gates. Overall, we find it is beneficial to perform the analysis after fine-tuning the barriers, since that process can increase the proportion of 1 _e_ data successfully obtained from a set of devices and therefore give a more representative sample of 1 _e_ voltages for analysis. 

We note furthermore that this success rate, or the fraction of quantum dots in an array that can be tuned to _n_ = 1 _e_ using a common voltage, can depend on both the size of the array and the method for choosing _V_ common. The dependence on array size can be considered to have two limits. In the limit of an array with a number of quantum dots _N_ = 1, a success rate of 100% is guaranteed. In the “large array limit,” where _V_ 1 _e_ and _V_ 2 _e_ data from each device can be well approximated by a normal distribution, the fraction of quantum dots in an array that can be tuned to _n_ = 1 _e_ using a common voltage can be estimated by assuming that each “failure” results from each instance of a _V_ 1 _e_ (2 _e_ ) value being above (below) the mean by more than half the addition voltage. The success rate can then be described by: 



<!-- Start of picture text -->
−V add<br>1  − 2Φ , (1)<br>� √ 2 σ (∆ V 1 e ) �<br><!-- End of picture text -->

where Φ is the cumulative distribution function of the standard normal distribution, _V_ add is the addition voltage, and _σ_ (∆ _V_ 1 _e_ ) is the standard deviation of matched pair _V_ 1 _e_ differences. In the range of “intermediate” array size the success rate will decrease from 100% to this limiting value, but the rate of its decrease will depend on the particular method of choosing the value of _V_ common. To better understand this intermediate range, we simulate the success rate as a function of array size for two different methods of choosing _V_ common. The first method is that described above and shown in Extended Data Fig. 5a-b, where _V_ common is optimized to give the maximum number of _n_ = 1 _e_ successes. The second method naively sets _V_ common to the mean of 

18 

the combined _V_ 1 _e_ and _V_ 2 _e_ data for each device. We first simulate devices that reflect the experimental results from the wafer with 50 nm SiGe barrier; we generate _V_ 1 _e_ and _V_ 2 _e_ data from a random normal distribution with a standard deviation equal to the measured _σ_ (∆ _V_ 1 _e_ ) _/_ _~~√~~_ 2 and use the average measured _V_ add from that wafer. Extended Data Fig. 5c shows the results of simulated success rate as a function of array size, taking an average over 10,000 simulated devices at each array size. We find that the success rate of both methods decreases as a function of array size, saturating at the expected fraction based on a normal distribution. We also find that using the method where _V_ common is optimized can boost the success rate over a much larger range in array sizes compared to the simpler method based on the mean, only saturating at the large array limit around _N ∼_ 1000. We interpret this difference as an effect of sampling noise, where for intermediate array sizes ( _N <_ 1000), the distribution of _V_ 1 _e_ data departs from the ideal normal distribution, so optimizing _V_ common for the sampled distribution of each device can outperform the method of simply setting _V_ common from the mean. We also note good agreement between these simulated results and the results of both methods being applied to the measured data (marked as stars in Extended Data Fig. 5c). 

While these findings show that our reported success rate (63%) will tend to decrease as a function of array size, they also reveal how intermediate gains can be made by choosing an optimal _V_ common value for each array. As arrays become significantly larger ( _N >_ 1000), one way to preserve this benefit would be to assign different _V_ common values to different unit cells of the array, where each unit cell could contain _N <_ 1000 quantum dots. This approach would also mitigate the challenge of voltage variation across an array increasing as the array size increases. We also note that significant gains can be made even in the large array limit through improvements in _V_ 1 _e_ variation. For example, decreasing _σ_ (∆ _V_ 1 _e_ ) by a factor of four while keeping _V_ add fixed would lead to an expected success rate of _∼_ 99%, even in the large array limit (see Extended Data Fig. 5d). 

### **Qubit measurement setup** 

The qubit measurements were performed in Bluefors XLD dry dilution refrigerators with a base temperature of 10 mK. Each sample was mounted and wirebonded onto a custom PCB and placed on a coldfinger that sits in the middle of the bore of a superconducting magnet. DC voltages from battery-powered voltage DACs (Qutech SPI rack) are applied to each gate electrode of the device. The signals are routed to the sample PCB using twisted pair cables and pass through RC filters that are also thermalised on the coldfinger. AC and MW signals are delivered to the sample PCB via coax cables with attenuators from room temperature to mK totaling between 21 - 28 dB. AC signals are applied to the plunger and barrier gates of the devices by adding them to the DC signals using RC bias tees (R=1 MΩ, C=100 nF) on the sample PCB. The microwave signal is added to the DC signal for the center screening gate using an LC bias tee (L=1.7 nH, C=1 pF) also on the sample PCB. AC signals are generated using arbitrary waveform generators (Zurich instruments HDAWG8 and custom DDS based AWGs). MW signals are generated using I/Q modulation of either a Keysight E8267D or R&S SGS100A vector microwave source. 

The charge sensor is measured using an AC coupled dual-stage SiGe heterojunction-bipolar-transistor (HBT) amplifier [54] on the sample PCB board. The design of the dual stage amplifier is similar to other high-electron-mobility transistor (HEMT) based amplifiers [55]. A stimulus voltage is applied to one of the ohmics of the charge sensor via a bias tee, generating an AC current through the charge sensor that gets amplified by the dual stage amplifier. The small distance between the device and the base of the HBT in the first stage of the amplifier leads to a low parasitic capacitance enabling bandwidths _>_ 1 MHz. The amplified current signal is demodulated at RT using the Zurich instruments MFLI lock-in amplifier. Within this setup we achieve electron temperatures between 100 - 200 mK, dependent on the stimulus amplitude and bias applied to the emitter of the HBTs. 

### **Qubit readout and initialization** 

In the qubit measurements shown in Extended Data Fig. 1, two methods are used for readout and initialization. The first method is Elzerman readout [56], which involves spin selective tunneling of the qubit electron to a nearby reservoir. To perform this readout, the Fermi level of the reservoir is aligned between the spin up and spin down state, split by the Zeeman energy. If the electron is spin up, the electron can tunnel out, followed by a spin down electron tunneling back in. This movement of charge can be detected in real time 

19 

with the nearby charge sensor. If the electron is spin down, it cannot tunnel out and therefore there is no change in the charge sensor signal. Since in either case, the quantum dot ends with a spin down electron, this readout can also be used to initialize the qubit. 

The second method is Pauli spin blockade (PSB) parity readout of a pair of electron spins [57, 15], which involves spin selective tunneling within a double quantum dot and does not need nearby reservoirs. This method utilizes the valley-orbit splitting, _E_ vo, between the singlet ground state and the triplet excited state that is found for certain electron numbers (i.e 2 _e_ or 4 _e_ ). Often, we observe that _E_ vo in the 2 _e_ state is low with respect to the sample electron temperature which degrades the readout fidelity. We expect this splitting to be limited by a combination of interface disorder, such as alloy disorder [30], and electron-electron interactions of the 2 _e_ state [58]. Consequently, we typically opt to define one qubit of the pair to contain 3 electrons, allowing us to utilize the much larger _E_ vo typically found with the 4 _e_ state. The 3 _e_ state typically shows similar coherence times to the 1 _e_ state. We note that alternating the electron number between 1 _e_ and 3 _e_ across arrays in this manner could add overhead to scaling solutions based on voltage sharing. 

To give an example of how parity readout is performed, consider a double dot in the (1,3) charge configuration where the (0,4) state is used for readout. The plunger gates of the devices are pulsed to the PSB readout point in the (0,4) where only the S(0,4) state is accessible and tunneling to the T(0,4) is not energetically possible. At this point, due to the large Zeeman energy difference between the two dots [57], the _|↓↑⟩_ and _|↑↓⟩_ state quickly relax to the singlet allowing tunneling into the S(0,4) charge state. In contrast, _|↓↓⟩_ and _|↑↑⟩_ map onto the T+(1,3) and T _−_ (1,3) states and tunneling to the T(0,4) state is not allowed. Hence, the final charge state of the double dot determines the parity of the two electron spins and can be measured using the nearby charge sensor using integration times typically between 20 - 100 _µ_ s. For the single qubit measurements in Extended Data Fig. 1, the state of other qubit is fixed allowing the full state of the measured qubit to be extracted. 

To initialize the system, the S(0,4) state is prepared using postselection [15]. In particular, at the start of each sequence, PSB readout is used to determine if the state is T(1,3) or S(0,4). If the state is T(1,3) then the measurement run is discarded. After preparing S(0,4) via postselection, the state is mapped to _|↓↑⟩_ by applying an adiabatic ramp to the (1,3) regime where _J ≪_ ∆ _Bz_ . Here we can perform single qubit operations, followed by a second PSB readout to determine the final state. 

### **Micromagnet design and EDSR** 

Coherent manipulation of single electron spins is performed using electric dipole spin resonance (EDSR) mediated by magnetic field gradients from Cobalt micromagnets [59]. EDSR enables high-fidelity and local electrical control of spin qubits [60], and micromagnets can also be used to engineer the qubit frequencies along an array enabling addressibility and high fidelity two-qubit gates [6, 7, 8]. The micromagnets (Extended Data Fig. 1a) are patterned on top of the quantum dot samples using electron-beam lithography and standard lift-off techniques. The micromagnets are based on the design in [15] and are magnetized in the direction indicated by the white arrow by ramping the external magnetic field to 3 T. The micromagnets are used to generate a magnetic field gradient, d _Bz/_ d _y_ at each of the quantum dot sites, with simulations giving values ranging between 0.4 - 0.5 mT/nm. Microwaves are applied to the center screening gate (highlighted in red) which displaces the electrons in the quantum dot in the _y_ direction, resulting in the electron effectively seeing an oscillating magnetic field in the _z_ direction that is perpendicular to the external magnetic field ( _B_ 0) in the _y_ direction. In addition, the micromagnets also generate a magnetic field gradient d _By/_ d _x_ along the array ranging from 0.007 - 0.03 mT/nm at full magnetization, with the gradient decreasing from Q1 to Q12. This field gradient is in the direction of the external field (i.e., aligned to the quantization axis) and leads to different qubit frequencies along the array. In addition, this field gradient can lead to decoherence as charge noise can cause fluctuations in qubit position and hence the qubit frequency. The field gradient in the d _By/_ d _y_ direction can also cause decoherence but is minimized close to zero by centering the qubit array between the two micromagnets. The coherent rotation of a single electron using EDSR as a function of MW burst time is shown in Extended Data Fig. 1b. In this measurement, we estimate that we apply a microwave power at the sample of _∼_ -35 dBm, taking into account the microwave source power of -2 dBm, attenuation of -21 dBm from attenuators in the cryostat, and frequency-dependent cable losses of -14 dBm at the resonance frequency of 7.5 GHz. 

20 

### **Randomized benchmarking** 

Randomized benchmarking is used to characterize the single qubit gate fidelity in a<sup>28</sup> Si sample. The experiment is performed by first applying a randomized sequence of a varying number ( _m_ ) of Clifford gates to the qubit followed by a final Clifford gate that is the inverse of the randomized sequence, then measuring the resulting spin up probability [61, 62]. For each data point we perform 100 repetitions for 80 different randomized sets of gates for each sequence length. In addition, we interleave Ramsey frequency calibrations for the qubit between every 2 randomizations (approximately every 1 min). Examples are shown in Extended Data Fig. 1c for two qubits, labeled Q1 and Q2, from a<sup>28</sup> Si device labeled dev12. We perform the measurement with the qubit initialized in either the _|_ 0 _⟩_ or _|_ 1 _⟩_ state and extract the difference in the measured spin up probability for those two starting states, _P|_<sup>_′_</sup> 1 _⟩_<sup>-</sup><sup>_P|_1</sup><sup>_⟩_,asafunctionofsequencelength</sup><sup>_m_</sup> [62]. From an exponential fit of the data, _P|_<sup>_′_</sup> 1 _⟩_<sup>-</sup><sup>_P|_1</sup><sup>_⟩_=</sup><sup>_apm_,weestimateaverageClifford-gatefidelities</sup> _FC_ = 1 _−_ (1 _− p_ ) _/_ 2 of 99 _._ 90 _±_ 0 _._ 01% and 99 _._ 88 _±_ 0 _._ 02% for Q1 and Q2, respectively. 

### **Coherence measurements** 

The dephasing time ( _T_ 2<sup>_∗_)ofaqubitismeasuredusingaRamseysequence,showninExtendedDataFig.1d</sup> for the qubit labeled Q3 from dev12. In this sequence, the wait time between two _Xπ/_ 2 pulses is varied. An artificial oscillation is introduced to the data to improve the reliability of the fit by making the phase of the last _π_ pulse dependent on the evolution time. We fit the spin up probability as a function of the free evolution time _τ_ to extract _T_ 2<sup>_∗_=15.6</sup><sup>_µ_s.Inthisfit,thedecayexponentiskeptasafreeparameter.</sup> In addition to measuring the dephasing time, for most of the qubits we also measure the Hahn echo decay time _T_ 2<sup>Echo</sup> , where a _Xπ_ pulse is used to refocus low frequency (quasi-static) noise, extending the qubit coherence time. Similar to the Ramsey sequence, we also introduce an artificial oscillation for fitting purposes. An example of this measurement for Q3 from dev12 is shown in Extended Data Fig. 1f. We fit the spin up probability as a function of the free evolution time _τ_ to extract _T_ 2<sup>Echo</sup> = 225 _µ_ s. In the fit, the decay exponent is again a free parameter. 

Extended Data Fig. 1g shows coherence time measurements from 39 qubits formed in 14 devices (dev1 - dev14) from 5 different wafers (w1 - w5). Data is collected from a mix of two device types, either a linear array of three qubits (3Q) or a linear array of 12 qubits (12Q). _T_ 2<sup>_∗_ismeasuredforeachqubitusingtheRamsey</sup> sequence (as shown in Extended Data Fig. 1d), and _T_ 2<sup>Echo</sup> is measured using the Hahn echo sequence (as shown in Extended Data Fig. 1f). In dev3, the coherence times are measured for each qubit after tuning up the entire 12Q array. In dev11 and dev13, for some qubits we plot multiple points measured for _T_ 2<sup>Echo</sup> that varied significantly due to device tuning. We observe that moving from<sup>Nat</sup> Si (w1 - w3) to<sup>28</sup> Si (w4 - w5) leads to about an order of magnitude improvement in _T_ 2<sup>_∗_.</sup> 

_T_ 2<sup>_∗_isdeterminedbytheintegratednoisespectrumduringtheRamseyexperimentandthereforeis</sup> dependent on the total measurement time [63]. In Extended Data Fig. 1g, the total measurement time for each of the _T_ 2<sup>_∗_datapointsvariesbetween1-10mins.ExtendedDataFig.1eshowsthedependenceof</sup><sup>_T ∗_</sup> 2 on the total measurement time for a subset of qubits measured in Extended Data Fig. 1g. The cumulative plots in Extended Data Fig. 1e are generated by performing many repetitions of the Ramsey experiment. From this data set, we calculate the average _T_ 2<sup>_∗_fordifferentmeasurementtimes.Thisisdonebyapplying</sup> a moving average to the data set with a window size that equals a particular measurement time. We then fit each averaged time trace to extract _T_ 2<sup>_∗_asafunctionofthewindowpositionandcalculatetheaverage</sup><sup>_T ∗_</sup> 2 from this. Here the _T_ 2<sup>_∗_decreases as a function of measurement time and saturates.Between 1-10 mins the</sup><sup>_T ∗_</sup> 2 can vary by a factor of _∼_ 2 and explains some of the variation in Extended Data Fig. 1g. The approximate _T_ 2<sup>_∗_saturationpoint,labeled</sup><sup>_T ∗_</sup> 2<sup>(</sup><sup>_∞_),foreachofthecurvesinExtendedDataFig.1earealsoplottedin</sup> Extended Data Fig. 1g and allows a better comparison between the different samples and with theoretical estimates of _T_ 2<sup>_∗_.</sup> 

In<sup>Nat</sup> Si and<sup>28</sup> Si samples, the average ratio between _T_ 2<sup>Echo</sup> and _T_ 2<sup>_∗_(</sup><sup>_∞_)is</sup><sup>_∼_150and</sup><sup>_∼_50,respectively.</sup> These numbers indicate that the exponent of the noise model, given by a power law 1 _/f_<sup>_α_</sup> , is _α >_ 1, consistent with nuclear spins dominating _T_ 2<sup>_∗_.Inaddition,thecoherencetimesarenotdependentondot</sup> number/position in the devices (e.g., Q1 vs. Q12) despite the decoherence gradient decreasing by a factor of _∼_ 4 from Q1 to Q12. This suggests that for most of the qubits, _T_ 2<sup>_∗_(</sup><sup>_∞_)and</sup><sup>_T_Echo</sup> 2 are predominantly limited by nuclear spins rather than charge noise. However, we note that for some qubits we sometimes 

21 

find lower than expected values for _T_ 2<sup>Echo</sup> that can be improved with device tuning. While we have not fully investigated the cause of this, two potential reasons could be either that the dot position is offset with respect to the center of the micromagnets (i.e., in the _y_ -direction), increasing significantly the decoherence gradient, or that in some tuning configurations charge traps are activated, leading to higher levels of charge noise. 

### **Coherence modeling** 

To obtain an estimate of the dephasing time _T_ 2<sup>_∗_fromnuclearspins,weconsiderthequbitelectronto</sup> be confined in a crystalline lattice comprised of a 5 nm thick strained Si quantum well (Si-QW) and a Si0 _._ 7Ge0 _._ 3 barrier on both sides of the well. The electron confinement is assumed to be given by (i) the harmonic oscillator potential with an orbital splitting ∆orb for the in-plane direction ( _x_ , _y_ ), and (ii) the potential barrier between the Si-QW and Si0 _._ 7Ge0 _._ 3 for the out-of-plane ( _z_ ) direction. In this confinement potential we estimate the electron wave-function _ψ_ ( **r** _i_ ) at each nuclear-spin site _i_ , where the nuclear spins are distributed in the lattice with a probability given by their concentration. _ψ_ ( **r** _i_ ) acts as a handle to the hyperfine interaction _Aik_ between the electron and nuclear spins and the resultant _T_ 2<sup>_∗_(</sup><sup>_∞_),givenbythe</sup> equations [5]: 



<!-- Start of picture text -->
Aik = 2 µ 3 0 γeγnkηk|ψ ( r i ) | 2 , (2)<br><!-- End of picture text -->



<!-- Start of picture text -->
� T 2 ∗ 1( ∞ ) �2 = 1 2 k = 29 � Si, 73 Ge Ik ( Ik 3 + 1) � i A 2 ik , (3)<br><!-- End of picture text -->

where index _k_ denotes the spin carrying nuclei of<sup>29</sup> Si and<sup>73</sup> Ge, with their total nuclear spins being _Ik_ = 1 _/_ 2 and _Ik_ = 9 _/_ 2, respectively, _ηk_ are their bunching factors, and _γe_ and _γnk_ are the gyromagnetic ratio of the electron and nuclear spins, respectively. 

For our calculations, we assume ∆orb to be uncertain in the range of 1 meV and 2 meV, calculate _T_ 2<sup>_∗_(</sup><sup>_∞_)</sup> for 50 different distributions of nuclear spins for a given concentration, and then estimate the bounds of the resultant _T_ 2<sup>_∗_(</sup><sup>_∞_)showninExtendedFig.1g[64].Hencethiscalculationaccountsforboththeuncertainty</sup> of the orbital splittings and the variation in location of nuclear spins in the lattice. We note from our simulations that<sup>29</sup> Si and<sup>73</sup> Ge nuclei in the Si quantum well and the Si0 _._ 7Ge0 _._ 3 barrier limit the _T_ 2<sup>_∗_(</sup><sup>_∞_)to</sup> be in the range of 0.73 _µ_ s - 0.98 _µ_ s and 4.9 _µ_ s - 8.3 _µ_ s for both natural Si and isotopically enriched Si (800 ppm), respectively. The strength of the contribution from nuclear spins in the Si0 _._ 7Ge0 _._ 3 barrier can depend sensitively on the width of the Si/Si0 _._ 7Ge0 _._ 3 interface. Simulations based on a sigmoidal interface [33] and using a measured interface width of 4 _τ_ = 1 nm predict that residual<sup>29</sup> Si nuclei in the quantum well are the main limiter to our coherence. The range of theoretical estimates of _T_ 2<sup>_∗_(</sup><sup>_∞_)forNatSiand28Siwith800ppm</sup> residual<sup>29</sup> Si are shown in Fig. 1g as shaded regions outlined by dashed and dashed-dot lines, respectively. The simulated ranges show reasonable agreement with the data, indicating _T_ 2<sup>_∗_timesareindeedlimitedby</sup> nuclear spins rather than charge noise. 

## **Methods References** 

- [45] L. DiCarlo, H. J. Lynch, A. C. Johnson, L. I. Childress, K. Crockett, C. M. Marcus, M. P. Hanson, and A. C. Gossard. Differential charge sensing and charge delocalization in a tunable double quantum dot. _Phys. Rev. Lett._ , 92:226801, 2004. 

- [46] Don Monroe, Y. H. Xie, E. A. Fitzgerald, P. J. Silverman, and G. P Watson. Comparison of mobilitylimiting mechanisms in high-mobility Si1 _−x_ Ge _x_ heterostructures. _J. Vac. Sci. Technol. B_ , 11:1731–1737, 1993. 

- [47] M. A. Lutz, R. M. Feenstra, F. K. LeGoues, P. M. Mooney, and J. O. Chu. Influence of misfit dislocations on the surface morphology of Si1 _−x_ Ge _x_ films. _Appl. Phys. Lett._ , 66:724–726, 1995. 

- [48] A. Ortiz-Conde, F. J. García Sánchez, J. J. Liou, A. Cerdeira, M. Estrada, and Y. Yue. A review of recent MOSFET threshold voltage extraction methods. _Microelectronics Reliability_ , 42:583–596, 2002. 

22 

- [49] I. T. Vink, T. Nooitgedagt, R. N. Schouten, L. M. K. Vandersypen, and W. Wegscheider. Cryogenic amplifier for fast real-time detection of single-electron tunneling. _Appl. Phys. Lett._ , 91:123512, 2007. 

- [50] L. P. Kouwenhoven, C. M. Marcus, P. L. McEuen, S. Tarucha, R. M. Westervelt, and N. S. Wingreen. Electron transport in quantum dots. In L. L. Sohn, L.P. Kouwenhoven, and G. Schön, editors, _Mesoscopic Electron Transport_ , volume 345 of _NATO Science Series E_ , pages 105–214. Springer Dordrecht, 1997. 

- [51] Joshua Ziegler, Thomas McJunkin, E. S. Joseph, Sandesh S. Kalantre, Benjamin Harpt, D. E. Savage, M. G. Lagally, M. A. Eriksson, Jacob M. Taylor, and Justyna P. Zwolak. Toward robust autotuning of noisy quantum dot devices. _Phys. Rev. Applied_ , 17(2):024069, 2022. 

- [52] Neil M. Zimmerman, Chih-Hwan Yang, Nai Shyan Lai, Wee Han Lim, and Andrew S. Dzurak. Charge offset stability in Si single electron devices with Al gates. _Nanotechnology_ , 25(40):405201, 2014. 

- [53] Elliot J. Connors, J. J. Nelson, Haifeng Qiao, Lisa F. Edge, and John M. Nichol. Low-frequency charge noise in Si/SiGe quantum dots. _Phys. Rev. B_ , 100:165305, 2020. 

- [54] M. J. Curry, T. D. England, N. C. Bishop, G. Ten-Eyck, J. R. Wendt, T. Pluym, M. P. Lilly, S. M. Carr, and M. S. Carroll. Cryogenic preamplification of a single-electron-transistor using a silicon-germanium heterojunction-bipolar-transistor. _Appl. Phys. Lett._ , 106:203505, 2015. 

- [55] L. A. Tracy, D. R. Luhman, S. M. Carr, N. C. Bishop, G. A. Ten Eyck, T. Pluym, J. R. Wendt, M. P. Lilly, and M. S. Carroll. Single shot spin readout using a cryogenic high-electron-mobility transistor amplifier at sub-Kelvin temperatures. _Applied Physics Letters_ , 108(6):063101, February 2016. 

- [56] J. M. Elzerman, R. Hanson, L. H. Willems Van Beveren, B. Witkamp, L. M. K. Vandersypen, and L. P. Kouwenhoven. Single-shot read-out of an individual electron spin in a quantum dot. _Nature_ , 430(6998):431–435, July 2004. 

- [57] Amanda E. Seedhouse, Tuomo Tanttu, Ross C.C. Leon, Ruichen Zhao, Kuan Yen Tan, Bas Hensen, Fay E. Hudson, Kohei M. Itoh, Jun Yoneda, Chih Hwan Yang, Andrea Morello, Arne Laucht, Susan N. Coppersmith, Andre Saraiva, and Andrew S. Dzurak. Pauli Blockade in Silicon Quantum Dots with Spin-Orbit Control. _PRX Quantum_ , 2(1):010303, January 2021. 

- [58] H. Ekmel Ercan, S. N. Coppersmith, and Mark Friesen. Strong electron-electron interactions in Si/SiGe quantum dots. _Phys. Rev. B_ , 104:235302, 2021. 

- [59] M. Pioro-Ladrière, T. Obata, Y. Tokura, Y.-S. Shin, T. Kubo, K. Yoshida, T. Taniyama, and S. Tarucha. Electrically driven single-electron spin resonance in a slanting Zeeman field. _Nature Physics_ , 4(10):776– 779, October 2008. 

- [60] Jun Yoneda, Kenta Takeda, Tomohiro Otsuka, Takashi Nakajima, Matthieu R. Delbecq, Giles Allison, Takumu Honda, Tetsuo Kodera, Shunri Oda, Yusuke Hoshi, Noritaka Usami, Kohei M. Itoh, and Seigo Tarucha. A quantum-dot spin qubit with coherence limited by charge noise and fidelity higher than 99.9%. _Nature Nanotechnology_ , 13(2):102–106, February 2018. 

- [61] E. Knill, D. Leibfried, R. Reichle, J. Britton, R. B. Blakestad, J. D. Jost, C. Langer, R. Ozeri, S. Seidelin, and D. J. Wineland. Randomized benchmarking of quantum gates. _Physical Review A_ , 77(1):012307, January 2008. 

- [62] Erika Kawakami, Thibaut Jullien, Pasquale Scarlino, Daniel R. Ward, Donald E. Savage, Max G. Lagally, Viatcheslav V. Dobrovitski, Mark Friesen, Susan N. Coppersmith, Mark A. Eriksson, and Lieven M. K. Vandersypen. Gate fidelity and coherence of an electron spin in an Si/SiGe quantum dot with micromagnet. _Proceedings of the National Academy of Sciences_ , 113(42):11738–11743, October 2016. 

23 

- [63] Tom Struck, Arne Hollmann, Floyd Schauer, Olexiy Fedorets, Andreas Schmidbauer, Kentarou Sawano, Helge Riemann, Nikolay V. Abrosimov, Lukasz Cywinski, Dominique Bougeard, and Lars R. Schreiber. Low-frequency spin qubit energy splitting noise in highly purified 28Si/SiGe. _npj Quantum Information_ , 6(1):40, May 2020. 

- [64] J. Kerckhoff, B. Sun, B.H. Fong, C. Jones, A.A. Kiselev, D.W. Barnes, R.S. Noah, E. Acuna, M. Akmal, S.D. Ha, J.A. Wright, B.J. Thomas, C.A.C. Jackson, L.F. Edge, K. Eng, R.S. Ross, and T.D. Ladd. Magnetic Gradient Fluctuations from Quadrupolar 73 Ge in Si / Si Ge Exchange-Only Qubits. _PRX Quantum_ , 2(1):010347, March 2021. 

## **Data availability** 

The data that support the findings in this study are available in the Zenodo repository (https://doi.org/10.5281/zenodo.10601293). 

### **Contributions** 

S.N., O.K.Z., and T.F.W. designed the automated cryo-prober measurements. S.N., O.K.Z., and A.N. performed the cryo-prober measurements. F.L. contributed to the measurement software. H.C.G., E.H., A.J.W., and M.I. fabricated the devices. S.N. and O.K.Z. analyzed the cryo-prober data. R.P., R.K., and S.P. contributed to the cryo-prober data analysis. O.K.Z., R.P., and K.M. enabled the cryo-prober installation. T.F.W., F.B., E.J.C., J.C., M.T.M., R.S., and G.Z. performed the qubit measurements. M.J.C., D.K., L.F.L., F.L., M.R., S.S., and J.Z. contributed to the preparation of the qubit experiments. F.A.M. performed the simulations of qubit coherence and micromagnets. N.C.B., S.B., J.R., and J.S.C. supervised the project. S.N. and O.K.Z. wrote the manuscript with input from all authors. 

### **Corresponding authors** 

Correspondence to Samuel Neyens (samuel.neyens@intel.com) or James S. Clarke (james.s.clarke@intel.com). 

## **Competing interests** 

The authors declare no competing interests. 

24 

## **Extended Data** 

25 



<!-- Start of picture text -->
a b c<br>M<br>MW<br>B0<br>y<br>x<br>d e f<br>g<br>28Si<br>NatSi<br>NatSi 28Si<br><!-- End of picture text -->

Extended Data Figure 1: **From single electrons to spin qubits. a** , Scanning electron microscopy image of the cobalt micromagnets fabricated on an Intel 12Q device to enable electric dipole spin resonance for single qubit control. The white arrow indicates the direction of magnetization M. The dashed line shows where the linear array of quantum dots is formed with respect to the micromagnets. **b** , Rabi oscillations between the spin up _|_ 1 _⟩_ and the spin down state _|_ 0 _⟩_ driven by EDSR. **c** , Randomized benchmarking of single qubit Clifford gates for two qubits, Q1 and Q2, from a<sup>28</sup> Si device (dev12). The difference in the measured spin up probability is plotted for two different starting states, _|_ 0 _⟩_ or _|_ 1 _⟩_ , as a function of sequence length _m_ . From exponential fits (solid lines) of the data, we estimate average Clifford-gate fidelities of 99 _._ 90 _±_ 0 _._ 01% and 99 _._ 88 _±_ 0 _._ 02% for Q1 and Q2, respectively. **d** , A Ramsey sequence performed on Q3 from dev12. By fitting the decay (solid line), we extract _T_ 2<sup>_∗_=15.6</sup><sup>_µ_s.</sup><sup>**e**,Cumulative</sup><sup>_T ∗_</sup> 2<sup>asafunctionofmeasurement</sup> time for a subset of devices described in **g** . The dephasing time saturates at long measurements to the limit _T_ 2<sup>_∗_(</sup><sup>_∞_).</sup><sup>**f**,AHahnechosequenceperformedonQ3fromdev12.Byfittingthedecay(solidline),weextract</sup> _T_ 2<sup>Echo</sup> = 225 _µ_ s. **g** , _T_ 2<sup>_∗_(stars),</sup><sup>_T ∗_</sup> 2<sup>(</sup><sup>_∞_)(diamonds),and</sup><sup>_T_Echo</sup> 2 (circle) data points measured from 39 qubits formed in 14 devices (dev1 - dev14) from 5 different wafers (w1 - w5). Two device types are featured: a linear array of 3 qubits (3Q) or 12 qubits (12Q). The color of each point corresponds to the position of the qubit in the array, which is labeled Q1 - Q3 for the 3Q samples and Q1 - Q12 for the 12Q samples. Error bars represent uncertainty of the fit. 

26 



<!-- Start of picture text -->
a b<br>1.4<br>2<br>2<br>0<br>Data<br>-2 Fit<br>-5<br>1.1 1.225 1.255<br>1.1 P5 (V) 1.4 P5 (V)<br>P6 (V)<br>Lock-in signal (arb. units)<br>Integrated lock-in signal (arb. units)<br><!-- End of picture text -->

Extended Data Figure 2: **Electron temperature measurement in the cryo-prober. a** , Charge stability diagram showing the configuration where electron temperature is extracted. **b** , 1D measurement across the transition indicated by the red dashed line in **a** with theoretical fit overlaid. 



<!-- Start of picture text -->
a b<br>Ω<br>VXY<br>V XX (1) V XX (2)<br>c d e<br>QW A QW B<br>Normal- Partial super- SiGe barrier: 30 nm 50 nm 30 nm 50 nm<br>conducting conducting<br>28Si  3×10 5<br>400 50 nm SiGe<br>30 nm SiGe<br>4×10 5<br>2<br>3<br>200<br>2<br>1<br>1<br>0<br>2 3 4 5×10 11<br>0 1 2 3 4 0 1 2 3 4 5 6 7 8 Carrier density (cm -2 )<br>Wafer number (arb.) Wafer number (arb.)<br>Mobility (cm/Vs)2<br>Gate line resistance (Ω)<br>Mobility (estimated) (cm/Vs)2<br><!-- End of picture text -->

Extended Data Figure 3: **Process optimization aided by cryo-prober feedback. a-b** , Optical images of two test structures with the same pad layout: Gate line resistance test structure ( **a** ) and Hall bar ( **b** ). In each case, the active probe pads are highlighted and a schematic of the measurement is shown. **c** - **d** , Improvements in device metrics from process optimization. Box plots display the median and inter-quartile range (IQR) of each distribution. Whiskers mark the maximum and minimum values excluding outliers, which are defined as points removed from the median by more than 1.5 times the IQR. **c** , Gate line resistance is reduced through optimization of the gate process and introduction of superconducting materials. **d** , Estimated carrier mobility is increased through improvements in epitaxy and increase in quantum well depth. **e** , Hall measurements taken in a conventional cryostat show mobility as a function of carrier density for two samples with the “QW B” process and different SiGe barrier thickness. 

27 



<!-- Start of picture text -->
a b e<br>0.80 1 e 1.1<br>2 e<br>3 e<br>4 e<br>5 e<br>6 e<br>c d<br>0.45<br>0.7<br>0.80 1.15<br>Plunger voltage (V)<br>f<br>200<br>100<br>0<br>0 0.08 0.16 0.24 0.32 0.4<br>1 e -2 e  addition voltage (V)<br>g 80<br>40<br>0<br>0 0.08 0.16 0.24 0.32 0.4<br>1 e  scan margin (V)<br>Dual barrier voltage (V) Lock-in signal (arb. units)<br>Count<br>Count<br><!-- End of picture text -->

Extended Data Figure 4: **Charge sensing scan analysis. a-e** , Sequence to extract transition curve data. **a** , Raw lock-in data is taken in by the analysis algorithm. **b** , A first-order Gaussian filter is applied to remove background charge sensor features from the data. **c** , A maximum filter is applied to locate points of high signal. **d** , Local maxima are filtered and binned into “curve segments”. **e** , Curve segments are merged into a set of continuous transition curves. The coordinates of these transition curves are collected and used to analyze 1 _e_ and 2 _e_ transition voltage statistics. **f-g** , Validation of 1 _e_ transition data. **f** , Histogram of 1 _e_ -2 _e_ addition voltage statistics from a wafer with 50 nm SiGe barrier. The vertical dashed line indicates two times the median addition voltage (0.158 V). **g** , Histogram of the 1 _e_ scan margin, or distance between the purported 1 _e_ transition and the left edge of the scan window, extracted from charge sensing scans on the same wafer as **f** . 98% of scans have a margin more than twice the median addition voltage. 

28 



<!-- Start of picture text -->
a 1 e  voltage b 1.0<br>60<br>0.8<br>0.6<br>0<br>50 2 e  voltage 0.4<br>0.2<br>0.0<br>0<br>-0.3 0.0 0.3 n  = 0 e n  = 1 e n  ≥ 2 e<br>c Voltage relative to  V common (V) d<br>1.0 V common optimized 1.00 V common optimized<br>0.8 V common from mean V common from mean<br>0.99<br>0.6<br>0.4<br>0.98<br>0.2 V add = 79 mV V add = 79 mV<br>σ(∆ V 1e)/√2 = 63 mV σ(∆ V 1e)/√2 = 16 mV<br>0.0 0.97<br>10 0 10 1 10 2 10 3 10 4 10 0 10 1 10 2 10 3 10 4<br>Array size Array size<br>Count<br>Count<br>Fraction of dots at occupation  n<br>Mean fraction of dots at n = 1 e Mean fraction of dots at n = 1 e<br><!-- End of picture text -->

Extended Data Figure 5: **Voltage sharing analysis. a** , Histogram of 1 _e_ and 2 _e_ electron voltages taken across a full wafer. Each voltage is plotted relative to the common voltage ( _V_ common) assigned to the 12QD device from which the data point is taken. 1 _e_ voltages above _V_ common (green) represent dots tuned to _n_ = 0 _e_ . 2 _e_ voltages below _V_ common (orange) represent dots tuned to _n ≥_ 2 _e_ . All other data points (blue, gray) represent dots tuned to _n_ = 1 _e_ . **b** , Scatter plot indicating the fraction of quantum dots tuned to various electron configurations at _V_ common for 12QD devices across a wafer. The fraction of dots in _n_ = 1 _e_ represents the success rate, giving a median success rate of 63%. Box plots display the median and inter-quartile range (IQR) of each distribution. Whiskers mark the maximum and minimum values excluding outliers, which are defined as points removed from the median by more than 1.5 times the IQR. **c** - **d** , Simulated success rate for tuning all quantum dots in an array to _n_ = 1 _e_ with a common voltage, plotted as a function of array size in number of quantum dots. _V_ common is chosen with two methods: one method where _V_ common is optimized to maximize the _n_ = 1 _e_ fraction, and one method where _V_ common is set based on the mean of _V_ 1 _e_ and _V_ 2 _e_ data. The dashed horizontal line indicates the expected success rate for normally distributed _V_ 1 _e_ and _V_ 2 _e_ data in the limit of large array size. Stars indicate the success rate extracted from the measured 12QD data using each method. Simulations are performed with experimentally observed _V_ 1 _e_ variation ( **c** ) and with four times lower _V_ 1 _e_ variation ( **d** ). 

29 



<!-- Start of picture text -->
a 1.2 b 0.1 c 0.1<br>30 nm SiGe<br>50 nm SiGe<br>1.0 0.0 0.0<br>ρ = 0.92<br>-0.1 -0.1<br>0.8 P1-P12 P2-P11 P3-P10 P4-P9 P5-P8 P6-P7 P1-P2 P3-P4 P5-P6 P7-P8 P9-P10 P11-P12<br>Gate pair Gate pair<br>ρ = 0.93 d e<br>60 σ(∆ V 1 e )/√2 = 63 mV 60 σ(∆ V 1 e )/√2 = 68 mV<br>40 40<br>0.6<br>20 20<br>0 0<br>0.8 1.0 1.2 1.4 1.6 -0.4 -0.2 0 0.2 0.4 -0.4 -0.2 0 0.2 0.4<br>V 1 e  (V) Matched pair ∆ V 1 e  (V) Matched pair ∆ V 1 e  (V)<br>Median() (V) V ∆1 e Median() (V) V ∆1 e<br> (V) VT<br>Count Count<br><!-- End of picture text -->

Extended Data Figure 6: **Additional analysis of 1** _e_ **voltage data. a** , Threshold voltage plotted as a function of 1 _e_ voltage for the set of plunger gates used in the matched pair analysis of Fig. 4c-d. Blue (red) data points are taken from a wafer with 30 (50) nm SiGe barrier. Linear fits to each dataset are shown as solid lines. The correlation coefficient ( _ρ_ ) is also shown, indicating a high level of correlation for both datasets: 0.92 (0.93) for the wafer with 30 (50) nm SiGe barrier. **b-c** , Median of matched pair 1 _e_ voltage difference distributions from the wafer with 50 nm SiGe barrier, plotted as a function of gate pair for sets of mirror-symmetric pairs ( **b** ) and nearest-neighbor pairs ( **c** ). **d-e** , Histograms of matched pair 1 _e_ voltage differences from combined distributions of gate pairs for sets of mirror-symmetric pairs ( **d** ) and nearest-neighbor pairs ( **e** ). 



<!-- Start of picture text -->
a b c<br><!-- End of picture text -->

























































































































Extended Data Figure 7: **Barrier-barrier scans representing three versions of wafer fabrication.** Wafer-scale maps of barrier-barrier scans are shown to represent the three versions of wafer fabrication highlighted in Fig. 2b-c: high- _κ_ stack A with high temperature spacer ( **a** ), high- _κ_ stack B with high temperature spacer ( **b** ), and high- _κ_ stack B with low temperature spacer and an integrated screening gate layer ( **c** ). Each set of scans shows a measurement from one quantum dot per device and represents the complete set from which the individual examples in Fig. 2c are taken. Scans are arranged by device location on the wafer. For the first two sets of measurements, only half of die are measured by sampling in a checkerboard pattern across the wafer. Additional missing scans are due to non-yielding quantum dots on the earlier versions of fabrication. 

30 



Extended Data Figure 8: **Charge sensing data from wafer with 30 nm SiGe barrier.** Charge sensing scans are grouped by 12QD device and arranged by wafer location. Scans with unresolved transitions and/or fitting errors are removed. 1 _e_ and 2 _e_ transition curves identified by the analysis algorithm are plotted in blue and orange, respectively. 

31 









































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































Extended Data Figure 9: **Charge sensing data from wafer with 50 nm SiGe barrier.** Charge sensing scans are grouped by 12QD device and arranged by wafer location. Scans with unresolved transitions and/or fitting errors are removed. 1 _e_ and 2 _e_ transition curves identified by the analysis algorithm are plotted in blue and orange, respectively. 

32 

































































































































































































































































































































































































































































































































































































































































































































































































































































































































































Extended Data Figure 10: **Charge sensing of double quantum dots across a wafer.** Charge sensing scans are taken on eight double quantum dots per 12QD device (two pairs of quantum dots for each charge sensor) and arranged by wafer location. 

33 

