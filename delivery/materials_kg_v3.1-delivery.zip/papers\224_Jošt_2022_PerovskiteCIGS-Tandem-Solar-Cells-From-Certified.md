# Perovskite/CIGS Tandem Solar Cells: From Certified 24.2% toward 30% and Beyond

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | ACS Energy Letters |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 309 |
| 作者 | M. Jošt, Eike Köhnen, A. Al-Ashouri, T. Bertram, Špela Tomšič, A. Magomedov, Ernestas Kasparavičius, T. Kodalle et al. |
| DOI | 10.1021/acsenergylett.2c00274 |
| 源文件 | 018_Jošt_2022_PerovskiteCIGS-Tandem-Solar-Cells-From-Certified.pdf |

---








http://pubs.acs.org/journal/aelccp 

## Perovskite/CIGS Tandem Solar Cells: From Certified 24.2% toward 30% and Beyond 

Marko Jost,̌ * Eike Köhnen, Amran Al-Ashouri, Tobias Bertram, Spelǎ Tomsič ,̌ Artiom Magomedov, Ernestas Kasparavicius, Tim Kodalle, Benjamin Lipovsek,̌ Vytautas Getautis, Rutger Schlatmann, Christian A. Kaufmann, Steve Albrecht,* and Marko Topic 

|Cite This: ACS Energy Lett. 2022, 7, 1298−1307|Read Online||
|---|---|---|
|ACCESS<br>Metrics & More|Article Recommendations|*<br>sı<br>Supporting Information|



ABSTRACT: We demonstrate a monolithic perovskite/CIGS tandem solar cell with a certified power conversion efficiency (PCE) of 24.2%. The tandem solar cell still exhibits photocurrent mismatch between the subcells; thus optical simulations are used to determine the optimal device stack. Results reveal a high optical potential with the optimized device reaching a short-circuit current density of 19.9 mA cm<sup>−2</sup> and 32% PCE based on semiempirical material properties. To evaluate its energy yield, we first determine the CIGS temperature coefficient, which is at −0.38% K<sup>−1</sup> notably higher than the one from the perovskite subcell (−0.22% K<sup>−1</sup> ), favoring perovskite in the field operation at elevated cell temperatures. Both single-junction cells, however, are significantly outperformed by the combined tandem device. The enhancement in energy output is more than 50% in the case of CIGS single-junction device. The results demonstrate the high potential of perovskite/CIGS tandem solar cells, for which we describe optical guidelines toward 30% PCE. 



erovskite-based tandem solar cells are a promising photovoltaic technology to enter the market at low cost P due to their higher power conversion efficiency (PCE) potential.<sup>1,2</sup> The realistic candidates for the bottom cell are silicon (Si), CIGS (copper indium gallium selenide), and low bandgap perovskite subcells,<sup>2</sup> with the perovskite/Si combination being currently the most investigated and developed, achieving a PCE above 29%.<sup>3,4</sup> Nevertheless, perovskite/CIGS tandems have some advantages compared to their silicon-based counterparts despite currently lower PCEs being reported. They can be produced on flexible substrates<sup>5</sup> and, as all thin film technologies, show significantly lower carbon footprint per kWh produced, thus being an efficient, flexible, sustainable, and lightweight solution. Combined with the radiation hardness of both subcells,<sup>6,7</sup> perovskite/CIGS tandems could be a high energy yield solution for space applications. On the basis of these advantages, perovskite/CIGS devices have a future in a large variety of terrestrial and space applications. 

Compared to the numerous publications on perovskite/Si tandem solar cells, there have only been a few papers on perovskite/CIGS solar cells,<sup>5,7−11</sup> most likely due to lower PCE, smaller market share of CIGS, and challenging integration of the perovskite subcell on top of a (nano)rough CIGS cell surface. The number of papers has recently increased following the possibility of depositing a thin hole transport layer directly on the rough surface, either by atomic layer deposition (ALD)<sup>10</sup> or by utilizing self-assembled 

monolayers.<sup>11</sup> The latter approach has resulted in the record device to date with the PCE of 23.2%. This record PCE is, however, still well below 29.8% PCE of the record perovskite/ Si tandem solar cell,<sup>4</sup> with all the PV parameters of the perovskite/CIGS tandem being below those of the perovskite/ Si device,<sup>12</sup> although the bandgaps of Si and CIGS are very close to each other and the theoretical limit of PCE almost the same. To improve the short-circuit current density (JSC) of the perovskite/CIGS tandem devices, optical optimization using simulations can be performed, similar to those established for perovskite/Si devices.<sup>13−15</sup> Derived from optical simulations, one can also estimate the energy yield,<sup>15−20</sup> which includes the operation under realistic outdoor conditions and not only under standard testing conditions (STC). 

In this paper, we present a monolithic perovskite/CIGS tandem device with a certified record PCE of 24.2%. Using optoelectrical measurements, we determine that the device is not optically optimized and thus turn to optical simulations. On the basis of realistic, fabrication-relevant parameters, we 



Received: February 4, 2022 Accepted: March 2, 2022 Published: March 9, 2022 

© 2022 The Authors. Published by American Chemical Society 

https://doi.org/10.1021/acsenergylett.2c00274 ACS Energy Lett. 2022, 7, 1298−1307 

1298 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Letter</mark> 

numerically optimize the device stack and show that the perovskite/CIGS tandem solar cells have the potential to reach a PCE of 32%. Finally, we incorporate the measured temperature- and light intensity-dependent current density− voltage (J−V) parameters of perovskite and CIGS singlejunction solar cells into our temperature-dependent energy yield model for tandem solar cells to fully evaluate the potential of perovskite/CIGS tandem solar cells and the improvement from single-junction to tandem devices. 

The fabricated monolithic perovskite/CIGS tandem solar cell consists of a p−i−n top cell that is deposited directly on a CIGS bottom cell. The active CIGS layer with a bandgap of 1.1 eV was coevaporated on a molybdenum coated glass substrate. A rubidium fluoride postdeposition treatment was used to improve the absorber quality.<sup>21</sup> The device was finished with a CdS layer to form the p−n junction and intrinsic and aluminum-doped ZnO as window layers. The ZnO:Al also functions as a recombination layer in the tandem device. The so-prepared bottom cell has a root-mean-square surface roughness (σRMS) of 64.0 nm (Figure S1), and it was used without any planarization before further top cell preparation. To fabricate a highly efficient perovskite top cell, we have adopted the procedure that was used to fabricate the 29.15% perovskite/Si tandem solar cell.<sup>3</sup> The hole transport layer was Me-4PACz that forms a monolayer upon deposition on oxide layers.<sup>3</sup> Due to the rough surface of our CIGS bottom cell, the dip-coating technique was used for monolayer deposition to ensure full coverage. A wide 1.68 eV bandgap perovskite with a precursor composition of Cs0.05(MA0.23FA0.77)Pb1.1(I0.77Br0.23)33,22 and PEAI (phenethylammonium iodide) additive<sup>23,24</sup> was spin-casted next, followed by evaporation of 1 nm LiF<sup>25−27</sup> and 20 nm C60. This combination has proved to have the highest potential in our perovskite single-junction devices and was therefore also utilized in the tandem device (Figure S2). 20 nm of SnO2 was then deposited as an electron selective contact and buffer layer using ALD. The device was finalized by sputtering 95 nm of IZO (indium zinc oxide) as transparent conductive oxide (TCO) and evaporating 110 nm of LiF as an antireflective coating. The final active area of 1.05 cm<sup>2</sup> was defined by a silver frame, which also served as a front contact. The crosssection scanning electron microscope (SEM) micrograph of the device is shown in Figure 1, where all the layers are labeled. The (nano)rough surface of the CIGS absorber is clearly 



Figure 1. Schematic of a monolithic perovskite/CIGS tandem solar cell with all the layers, superimposed on a cross-sectional SEM image. 

visible; however, this roughness is only partially transferred to the top surface of the perovskite, leading to a smoother surface.<sup>28,29</sup> 

The fabricated device was sent to CalLab at Fraunhofer ISE for independent certification. The device exhibited excellent performance with a stabilized maximum power point (MPP) PCEMPP of 24.2%, 1% higher than the previous record value.<sup>11</sup> The certified current−voltage (I−V) curve is shown in Figure 2a. The main improvement lies in an increased open-circuit voltage (VOC) of 1.77 V due to the higher perovskite bandgap of 1.68 eV, Me-4PACz HTL, PEAI additive, and LiF interlayer. The main downside is a relatively poor fill factor (FF) of 71.2% (as seen in Figure 2a) and also short-circuit current density (JSC) of only 18.8 mA cm<sup>−2</sup> , resulting in the final PCEJV of 23.7%. This is slightly lower than PCEMPP; we postulate that during MPP tracking the FF improves due to smaller charge accumulation compared to the open-circuit condition imposed during I−V scanning. At the moment it is unclear whether the relatively poor shunt resistance stems from the top or bottom device or even both. Finding the cause for and improving the shunt resistance of the tandem could yield a further 10% relative increase of the PCE and is planned for further investigations. This improvement would result in a PCE of 26.6%, reducing the difference between record perovskite/Si and perovskite/CIGS to ∼3% absolute, which is approximately the difference between the PCE of the silicon and CIGS bottom cells used in record devices (this work and ref 30). 

The JSC and optical performance of the fabricated device are analyzed in more detail using external quantum efficiency (EQE) and reflection (R) measurements (Figure 2b). The low reflection loss of only 2.2 mA cm<sup>−2</sup> is on par with best frontside polished perovskite/Si tandem solar cells<sup>3</sup> and only slightly worse than for the double-side textured tandem device.<sup>25</sup> The reason lies in the rough surface of the CIGS absorber, which results in excellent antireflection properties and enables high optical potential of perovskite/CIGS devices with little parasitic absorption in the device as revealed by the EQE measurements. The EQE, however, shows a slight photocurrent mismatch between the top and bottom cell, with the tandem device being top cell limited, leaving some room for further improvement. To do this, one could reduce the bandgap of the perovskite or, better yet, increase the thickness of the top absorber layer. As the whole device stack including other layers besides the perovskite has not been fully optically optimized yet, we turn to optical simulations. 

For optical simulations we used a transfer matrix/ray tracing algorithm, implemented in the software CROWM,<sup>31,32</sup> and simulated annealing algorithm for global optimization. The device stack in simulations is the same as in the experiment described above, and we used the algorithm to determine the optimal thicknesses of several layers. We have successfully used the same procedure for optimization of perovskite/Si tandem devices before,<sup>15</sup> where we have learned that the layer thickness of the top contact (IZO, SnO2, and C60) always trend toward the lower boundary conditions due to high absorption in these layers. Since our initial optical simulation results on perovskite/CIGS tandem solar cells resulted in the same trends, we fixed these layers to the minimum thickness still needed for a well-functioning tandem (80, 10,<sup>27</sup> and 10 nm<sup>27,33</sup> ) and omitted them from the optimization process to save computational time. The layers left for thickness optimization were therefore LiF (as antireflection coating), perovskite, ZnO:Al, i-ZnO, and CdS, where for the perovskite 

1299 

https://doi.org/10.1021/acsenergylett.2c00274 ACS Energy Lett. 2022, 7, 1298−1307 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Letter</mark> 



Figure 2. (a) Certified I−V characteristics of the fabricated perovskite/CIGS solar cell. Certification was performed at CalLab Fraunhofer ISE. The certified values are PCEMPP = 24.2%, JSC = 18.8 mA cm<sup>−2</sup> , VOC = 1.77 V, and FF = 71.2%. The active area was 1.04 cm<sup>2</sup> . (b) EQE and 1-R spectra for the fabricated tandem. Photogenerated current densities, obtained from integration of the EQE spectra with AM1.5G spectrum, are also stated. The perovskite bandgap is 1.68 eV, while CIGS has a bandgap of 1.1 eV, determined at the inflection point from the EQE spectra. 

Table 1. Simulated Optimal Layer Thicknesses and the Corresponding Performance Metrics of a Perovskite/CIGS Tandem Solar Cell for Different Perovskite Bandgaps<sup>a</sup> 

|||||none|ncapsulated||encaps|
|---|---|---|---|---|---|---|---|
|layer|min thickness|max thickness|Eg = 1.65 e|V<br>Eg = 1.68 eV|Eg = 1.70 eV|Eg = 1.72 eV|Eg = 1.69 eV<br>selected|
|LiF|80|140|108|108|103|101|105|
|perovskite|400|1000|605|738|998|999|999<br>1000|
|ZnO:Al|30|80|30|33|35|68|32<br>32|
|i-ZnO|10|100|89|94|94|62|90<br>90|
|CdS|50|140|91|90|88|119|89<br>90|
|||||nonencaps|ulated||encaps|
|||Eg = 1.65 eV||Eg = 1.68 eV|Eg = 1.70 eV|Eg = 1.72 eV|Eg = 1.69 eV|
|Pero JSC_SIM|(mA cm<sup>−2</sup>)|19.92||19.93|19.92|19.33|18.8|
|CIGS JSC_SIM|(mA cm<sup>−2</sup>)|19.92||19.92|19.93|19.92|18.8|
|JSC_SIM (mA|cm<sup>−2</sup>)|19.9||19.9|19.9|19.3|18.8|
|FF (%)||80||80|80|80|80|
|VOC (V)||1.96||1.99|2.01|2.03|2.00|
|PCE (%)||31.2||31.6|32.0|31.3|30.0|



aIn the first column the layers that were optimized are stated. Experimentally relevant minimum and maximum layer thicknesses that were used as boundary conditions in the optimization algorithm are in the second and the third columns. Thickness values of other layers, namely IZO, SnO2, C60, and CIGS remain fixed at 80, 10, 10, and 2500 nm, respectively. Other columns show optimal thicknesses of the layer optimized for the corresponding different perovskite bandgap, with the penultimate column showing thicknesses of the encapsulated stack. The last column shows the selected thicknesses that were later used for further optimization. All thickness values are in nm. All n and k spectra used in the optical simulations are shown in Figure S5. 

layer we investigated different thicknesses and bandgaps. Despite the tunable bandgap of CIGS, we decided to fix the bandgap at 1.1 eV and the thickness at 2500 nm. Besides the fact that our best experimental devices are fabricated with that bandgap, 1.1 eV is also already close to the optimal bandgap for the bottom cell in the tandem. The results of the optical optimization are stated in Table 1 for different bandgaps of perovskite (which were obtained by blue shifting the complex refractive index (n and k) spectra<sup>34</sup> as has experimentally been justified in refs 35 and 36), together with lower and upper thickness boundaries. The boundaries were chosen within the practical limits;<sup>37,38</sup> for example the thickest considered perovskite was 1000 nm, also to keep in line with our previous results on perovskite/Si tandem solar cells.<sup>15</sup> Such thickness 

has been shown to still work efficiently, while optically no real gain is expected from a thicker layer.<sup>39,40</sup> 

To obtain reliable results and check reproducibility, we have run the optimization procedure several times. Interestingly, not all the thicknesses have converged to the same value. There are several local maxima for different thicknesses of the optimized layers, yielding almost the same JSC in both subcells. While for LiF and ZnO:Al the optimal thicknesses are 105 ± 5 nm and 35 ± 5 nm, respectively, the values for CdS and i-ZnO vary a lot, more than ±20 nm between different optimization runs. However, on a closer look, the sum of both thicknesses always trends toward 180 ± 5 nm due to very similar refractive indices of the two materials (1.98 for CdS and 2.05 for i-ZnO at a wavelength of 600 nm). We are therefore able to gain a very high JSC for several combinations of CdS and i-ZnO 

1300 

https://doi.org/10.1021/acsenergylett.2c00274 ACS Energy Lett. 2022, 7, 1298−1307 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Letter</mark> 

thicknesses with a sum of around 180 nm and can choose the thickness combination based on material consumption, deposition times, complexity, and electrical properties. Since inside the device only vertical and not lateral charge transport is important, no electrical losses are expected from thicker CdS and i-ZnO layers. 

Some parallels with perovskite/Si tandems can be drawn. The thicknesses of all the layers that absorb light (IZO, C60, ZnO:Al) have to be minimized as much as possible. The optimal thickness of LiF seems to be just above 100 nm, while both technologies also benefit from a thicker layer below the recombination layer. In perovskite/Si tandems this is nc:SiOX:H(n) with a refractive index of 2.75 at a wavelength of 600 nm, for which the optimal thickness of 90 nm was determined.<sup>41,42</sup> In perovskite/CIGS tandems, this is the combination of CdS and i-ZnO, with a combined thickness of around 180 nm and refractive index of 2. 

Finally, simulations show that with an optically optimized structure very high JSC values of 19.9 mA cm<sup>−2</sup> are possible for various perovskite bandgaps by only tuning the thickness of the perovskite layer, while all the other layers retain the same thickness. This facilitates a significantly more streamlined fabrication of high efficiency perovskite/CIGS, since no constant optimization of other layers is needed. Figure 3 



Figure 3. Absorptance and 1-R of an optimized perovskite/CIGS tandem solar cell obtained from optical simulations. The solid lines stand for the nonencapsulated, laboratory devices, and dashed lines represent encapsulated devices as would be used in the PV modules. Perovskite spectrum is blue, CIGS is red, and 1-R is black. 

shows the spectrally resolved absorptance of perovskite and CIGS subcells (solid lines) obtained from optical simulations. Good utilization of the solar spectrum is observed in the optically optimized perovskite/CIGS tandem, confirmed by the very high photocurrent in both subcells of 19.9 mA cm<sup>−2</sup> . The sum of both photocurrents is 39.8 mA cm<sup>−2</sup> , only slightly below the value for a front-side flat perovskite/Si tandem solar cell of 40 mA cm<sup>−2</sup> and only 0.8 mA cm<sup>−2</sup> less than in doubleside textured perovskite/Si tandems.<sup>15</sup> Consequently, adding a perovskite top cell should reduce the difference in performance between silicon and CIGS (bottom) cells. As already mentioned, this excellent optical performance, despite no pyramidal texture as in the case of perovskite/Si tandems, is enabled by the natural roughness of the CIGS absorber. Interestingly, the above nonoptimized fabricated tandem solar 

cell reached a combined photocurrent of 39.0 mA cm<sup>−2</sup> , which is only 0.8 mA cm<sup>−2</sup> below the optimal value. Thus, for the tandem current, we would gain only 0.4 mA cm<sup>−2</sup> by changing the layers other than the perovskite. 

Once the bandgap exceeds 1.70 eV, the current matching cannot be reached anymore with the perovskite thickness of 1000 nm as not enough photons are absorbed in the highbandgap perovskite. The current mismatch causes losses in PCE, which can be estimated based on the perovskite bandgap. To calculate the PCE, the JSC is obtained from the above simulations, while for FF we chose a fixed value of 80% for all bandgaps. We believe this is a realistic practical value, even though the FF of the record CIGS single-junction device (Eg = 1.08 eV) is only 80.4%,<sup>43</sup> since the perovskite subcell can achieve a higher FF and also the FF of the tandem is in the ideal case higher than that of their single-junction subcells. The VOC of the tandem device was determined by the following eq 1, 



<!-- Start of picture text -->
i 38 y<br>V OC = V OC,CIGSe + V OC,Pero = 730 mV − nk B T lnjjj zzz<br>k 19.9 {<br>+ E g(Pero) − 400 mV<br>q (1)<br><!-- End of picture text -->

Here we assume that the standalone VOC of the bottom CIGS cell is 730 mV under 1 sun, 100 mW cm<sup>−2</sup> irradiance, which was then reduced using the solar cell diode equation due to the absorption of shorter wavelengths in the perovskite top cell. VOC of the perovskite solar cell was determined from its bandgap and an estimated bandgap to VOC deficit of 400 mV, which should realistically be achievable.<sup>44,45</sup> The results are shown in the bottom part of Table 1. On the basis of these assumptions, the PCE of the perovskite/CIGS tandem solar cell peaks at 32.0% for a perovskite bandgap of 1.70 eV. In this case, the PCE of the perovskite top cell is 20.7%, while the PCE of the CIGS bottom cell under partial spectral illumination is 11.3%. For higher perovskite bandgaps, we can no longer achieve the current matching condition between the top and bottom cell as not enough light is absorbed in the top cell, while for lower perovskite bandgaps we lose VOC in the top cell. Here, the bandgap was determined from the inflection point of the EQE to fit with the photoluminescence (PL) peak.<sup>46</sup> In our previous analysis of perovskite/Si tandems,<sup>15</sup> we determined the bandgap from the crossing of the absorption slope in the EQE with the wavelength axis. The difference in the bandgap value between the two procedures is around 35 meV, which is then also translated to the VOC and PCE calculations. This reveals an important observation. The optimal bandgaps for perovskite/CIGS and double-side textured perovskite/Si tandem solar cells are the same, while the maximum PCEs determined by the same procedure are 32.0 and 33.1%, respectively. 

The path from the achieved 24.2% toward the ultimately anticipated 32% requires improvement of both subcells. The CIGS bottom cell used here has a VOC of 0.642 V (see the section below), while the record CIGS single-junction device has VOC of 0.734 V. This immediately introduces almost 100 mV VOC loss to our tandem device compared to the proposed 32% tandem device. The bandgap of perovskite absorber has to increase to 1.7 eV, at which the perovskite subcell should generate VOC of 1.3 V. Currently our perovskite top cell has a VOC of only 1.15 V, thus a 150 mV lower VOC. Improving the perovskite processing steps and potentially CIGS bottom cell 

1301 

https://doi.org/10.1021/acsenergylett.2c00274 ACS Energy Lett. 2022, 7, 1298−1307 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Letter</mark> 



Figure 4. (a) J−V characteristics at 100 mW cm<sup>−2</sup> intensity and different temperatures in the range from 25 to 85 °C for the CIGS device under test. Inset shows calculated kth_P from these measurements. (b) VOC dependence on light intensity and temperature for the tested CIGS device. (c) JSC dependence on temperature at 100 mW cm<sup>−2</sup> irradiance. (d) FF dependence on light intensity and temperature for the tested CIGS device. All J−V curves are shown in Figure S6. 

robustness should help increase the shunt resistance. While Me-4PACz significantly improves the performance, the yield is lower due to poorer wetting. Additionally, we often see submillimeter dots on our bottom cells, indicating CIGS delamination. Eliminating these two causes would increase the fill factor from 71% to the expected 78−80%. Finally, improving the JSC is the topic of this contribution. We show that optimized optics should yield an extra 1 mA cm<sup>−2</sup> in the JSC at STC. 

The above results demonstrate the high PCE potential of perovskite/CIGS tandem solar cells and should serve as a guideline on how to achieve it under STC. However, for field operation some modifications in the form of the encapsulation have to be made to the design. At the same time, due to different climate conditions, it is more informative to focus on the energy yield with the environmental effects than on STC performance. Therefore, in the following we calculate the energy yield including temperature for perovskite/CIGS tandem and perovskite and CIGS single-junction devices with encapsulation to add further relevance to the results. 

The yearly energy yield of PV devices and their performance are strongly influenced by irradiance and operating temperature. In our previous publication, we have experimentally investigated the performance of perovskite single-junction solar cells under different temperature and light intensity conditions.<sup>19</sup> This allowed us to extract perovskite PV parameters needed for energy yield modeling. In this paper, we repeat this systematic approach also on CIGS single-junction devices to 

obtain the parameters of the bottom cell. The analysis below is therefore based on realistic data: the previously obtained data for the perovskite and the newly measured data for the CIGS subcell. By use of experimentally measured I−V data of the subcells with temperature- and light intensity-dependent effects fully included, our energy yield model will allow direct performance comparison between the tandem and the two corresponding single-junction technologies. 

The CIGS single-junction device used here is the same as the bottom cell in the tandem device, with the only difference being the metal Ni/Al/Ni grid on top of a slightly thicker transparent conductive oxide (TCO), enabling current collection. The PCE of the single-junction CIGS device under STC was 19.7%. For temperature and light intensity testing, we perform I−V measurements at different temperatures (25−85 °C) and under different light intensities (10− 120 mW cm<sup>−2</sup> , 10−120% light intensity). In Figure 4a, we show the effect of temperature on the J−V curve at constant irradiation (100 mW cm<sup>−2</sup> ). The results point to a drop in voltage as the main reason for PCE decrease with temperature, in accordance with the detailed balance limit, while the JSC seems mostly unaffected. From these curves, we have extracted the power temperature coefficient of the investigated CIGS device. The PCE values at different temperatures and the corresponding slopes are presented in the inset of Figure 4a. The obtained value for the power temperature coefficient is kth_P = γ = −0.38% K<sup>−1</sup> for CIGS and fits with other reports from literature and module producers.<sup>47−49</sup> It is notably higher 

1302 

https://doi.org/10.1021/acsenergylett.2c00274 ACS Energy Lett. 2022, 7, 1298−1307 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Letter</mark> 

than the −0.17% K<sup>−1</sup> that was previously obtained for perovskite single-junction devices,<sup>19</sup> with perovskite’s higher bandgap acting beneficially in this case. 

In Figure 4b−d we analyze the J−V data into more detail. The graph in part b shows VOC versus light intensity for different temperatures. From the data at 100 mW cm<sup>−2</sup> (100%) light intensity a voltage temperature coefficient of kth_Voc = β = −0.275% K<sup>−1</sup> is extracted, while for all the tested temperatures the VOC drops logarithmically with light intensity. From the slope ideality factor n = 1.3 was extracted. Figure 4c shows the evolution of JSC with temperature, with JSC of CIGS largely unaffected by temperature. However, the CIGS suffers from a strong FF decrease with temperature, further increasing the kth_P of CIGS. We postulate that the higher FF drop of CIGS could be due to changed material properties, such as conductivity and energy misalignment. 

To protect them from environmental effects, solar cells in modules are normally encapsulated with a 3.2 mm thick glass and 500 μm thick encapsulation foil. Due to these additional layers, antireflective coating in the form of LiF is not needed anymore and the optics of the device change. We first check how the encapsulation affects the performance of the encapsulated device, where all the layers are the same as analyzed above except for the absence of the LiF layer. The optimal results for the encapsulated perovskite/CIGS tandem device are also stated in Table 1, while in Figure 3 reflectance and absorptance of both subcells are shown. The generated photocurrent of the encapsulated device is about 1 mA cm<sup>−2</sup> lower due to increased reflection at the front glass and increased absorption in glass and encapsulation foil in the UV region. This absorption also influences the current distribution as the optimal bandgap is reduced by 10 meV to 1.69 eV. Importantly, neither the bandgap nor the optimal thicknesses of the layers change significantly; thus the STC optimized structure of the device can be translated to a real world encapsulated device with little change. 

The encapsulation for CIGS single-junction devices for the comparative yield calculation is the same as for the tandems. For the perovskite single-junction devices, however, the encapsulation would come from the back side due to its fabrication in a superstrate configuration. Therefore, we have only replaced the laboratory 1.1 mm thick glass on the front side with a 3.2 mm thick glass in simulations. For all the considered device configurations, back-side encapsulation was omitted. The estimated PCEs under STC of so-encapsulated devices that were used in simulations were 18.4, 17.9, and 26.2% for perovskite and CIGS single-junction and perovskite/ CIGS tandem solar cell, respectively. The drop of the singlejunction CIGS PCE (measured 19.7% vs 17.9% here) is due to added encapsulation. The difference between the above simulated 30% and 26.2% for the encapsulated perovskite/ CIGS tandem used here is that for energy yield calculations we used data based on our experimentally measured singlejunction device with a much higher bandgap to VOC loss compared to what we assumed in the optimal case above (see eq 1). Note that for the energy yield modeling of the singlejunction perovskite device the original data based on a 1.63 eV perovskite<sup>19</sup> were used, since this bandgap is more suited for single-junction devices. For the perovskite in the tandem, the optimal 1.69 eV bandgap was considered (see Figure S7 for J−V curves used in tandem energy yield modeling and Figure S4 for additional kth_P measurements). These PCEs are not record PCEs for the respective technologies (except for the 

tandem); however, they are based on our fabricated devices and represent realistic state-of-the-art solar cell (or module) PCEs, thus enabling fair comparison and adding relevance to the results. 

The difference between perovskite and CIGS single-junction PCE is a result of the encapsulation. Looking at the J−V parameters of the nonencapsulated devices that were used for modeling, CIGS has a higher PCE than perovskite at STC (19.7% vs 18.5%). However, CIGS is far more affected by the encapsulation due to its substrate configuration. While encapsulation changes very little for the superstrate-built perovskite device, additional encapsulation glass and foil change the optics of CIGS by increasing reflection and parasitic absorption in the UV region, reducing the JSC. 

The above temperature- and light intensity-dependent data and optical simulations were then used in the energy yield model. The model is based on the previously published models for perovskite/Si tandems without temperature dependence<sup>15</sup> and perovskite single-junction solar cells with temperature dependence.<sup>19</sup> Here, we combine the two models to calculate the energy yield including the changes due to the temperature of the perovskite/CIGS tandem, and perovskite and CIGS single-junction solar cells. The model therefore includes geographical location, spectrally resolved irradiance, air temperature, measured I−V data, and optimized absorption spectra of both subcells. Assuming that all the solar cells of the same technology would perform the same and no additional fabrication changes would have to be performed to connect cells in series, the results can be extended to the respective modules. Additionally, no degradation rates have been included, which would play a role in the long-term energy yield; CIGS is a technology with a proven outdoor track record, while for perovskite there is very little data, if any, available. The results below, however, indicate a very high potential for perovskite and perovskite/CIGS tandem technology. 

Figure 5 and Table 2 show energy yield results of the three analyzed technologies for Phoenix, Arizona, where hot climate should show the biggest difference. Indeed, the difference between the energy produced by perovskite and CIGS is almost 14% in favor of perovskite. Partially, this is due to the slightly higher PCE of the perovskite, while the most 



Figure 5. Energy yield of perovkite/CIGS, CIGS, and perovskite technologies. Encapsulated devices were considered. Bars on the left show the case where hourly temperatures (daily profiles) were considered, while the bars on the right show results where the temperature was fixed to 25 °C. 

1303 

https://doi.org/10.1021/acsenergylett.2c00274 ACS Energy Lett. 2022, 7, 1298−1307 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Letter</mark> 

#### Table 2. Energy Yield of of Perovkite/CIGS, CIGS and Perovskite Technologies<sup>a</sup> 

||PCE (STC) [%]|EY [kWh m<sup>−2</sup>]|PCEEY [%]|tandem vs SJ|EY_25 (T = 25°C) [kWh m<sup>−2</sup>]|PCEEY (T = 25°C) [%]|EY:EY_25|
|---|---|---|---|---|---|---|---|
|perovskite/CIGS|26.2|544.95|22.5||583.99|24.1|−6.7%|
|CIGS|17.9|356.86|14.7|+52.7%|395.33|16.3|−9.7%|
|perovskite|18.4|405.93|16.7|+34.2%|430.15|17.7|−5.6%|



aValues stated are PCE under STC conditions (AM1.5 and T = 25 °C) and energy yields, first with real daily temperature profiles and second with fixed temperature T = 25 °C. For the latter cases PCE was also calculated. Since the spectral data were only given up to 1800 nm, the incident power was increased by 8.7%, which in the full AM1.5 spectra corresponds to the part above 1800 nm. While this ratio might not be true for spectra other than AM1.5, we believe that it is accurate enough to enable a better comparison of PCE values. The last column shows the drop in energy yield when daily temperature profiles are included instead of fixed temperature. 

significant difference is due to the blue rich spectra favoring perovskite and higher kth_P of CIGS. By fixing the temperature to 25 °C, we remove the temperature effect. In this case, the perovskite still outperforms the CIGS by ∼9%. For Phoenix, including the temperature reduces the energy yield by 5.6% and 9.7% for perovskite and CIGS, respectively (Figure 5, Table 2). For a colder climate, this difference would be slightly lower; however, perovskite would still outperform CIGS. Importantly however, the perovskite/CIGS tandem significantly outperforms both subcell standalone technologies by more than 30% and 50% in the cases of perovskite and CIGS, respectively. Adding a perovskite top cell to the CIGS is therefore an effective and viable way to improve the performance of single-junction thin film technologies. The drop due to the temperature is 6.7% and lies somewhere between the drops for perovskite and CIGS. This drop might in the field be reduced due to a lower operational temperature of the perovskite/CIGS tandem compared to single-junctions; however, reliable data on this temperature benefit are not yet available. 

In this Letter, we report on the highest-efficiency monolithic perovskite/CIGS tandem solar cell to date. The fabricated device was certified by an independent institution at 24.2% power conversion efficiency (PCE). The record PCE was enabled by simultaneous integration of the Me-4PACz monolayer as HTM, increased bandgap of 1.68 eV with PEAI dopant and LiF passivation interlayer. The EQE measurements have shown a 1 mA cm<sup>−2</sup> current density mismatch, leaving some further room for improvement. We therefore used optical simulations in combination with simulated annealing to optically optimize the device stack. On the basis of realistic boundary conditions for thicknesses and open-circuit voltage and FF assumptions, we determine that a PCE of 32% could realistically be achieved, with a very high short-circuit current density (JSC) of 19.9 mA cm<sup>−2</sup> , almost matching the JSC of an optimized perovskite/Si tandem solar cell. The optimized layer stack should serve as a guideline for further improvements in the PCE of this technology. Importantly, we also show that the optimized stack does not change with the encapsulation except for a 10 meV perovskite bandgap drop. Therefore, the same stack can be used to achieve the best laboratory devices and encapsulated modules. 

Finally, we show the temperature-dependent and light intensity-dependent I−V measurements of the fabricated CIGS single-junction device. Together with the same data for perovskite single-junction device and optically optimized stack, they were used to evaluate the energy potential of this tandem technology compared to their single-junction counterparts. The energy yield results are therefore based on measurements of devices that are used as subcells in perovskite/CIGS tandem solar cells. The simulations revealed 

that in the tandem around 7% energy is lost due to the increased temperature during solar cell field operation, compared with 9.7% and 5.6% for CIGS and perovskite single-junction devices. Nevertheless, the tandem device significantly outperforms the CIGS and perovskite singlejunction devices by 52.7 and 34.2%, respectively, for the case of Phoenix. The results presented in this Letter show the high potential of perovskite/CIGS tandem solar cells and show the way to its realization. 

# ■<sup>ASSOCIATEDCONTENT</sup> 

### *sı Supporting Information 

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acsenergylett.2c00274. 

- Methods section; analysis of wide bandgap singlejunction perovskite solar cells; spectrally resolved complex refractive indices of all the layers used in optical simulations; J−V curves of CIGS and perovskite single-junction devices used for energy yield modeling (PDF) 

# ■<sup>AUTHORINFORMATION</sup> 

#### Corresponding Authors 

- Marko Josť − Faculty of Electrical Engineering, University of Ljubljana, 1000 Ljubljana, Slovenia; Young Investigator Group Perovskite Tandem Solar Cells, Helmholtz-Zentrum Berlin für Materialien und Energie GmbH, 12489 Berlin, Germany; orcid.org/0000-0003-2754-1467; Email: marko.jost@fe.uni-lj.si 

- Steve Albrecht − Young Investigator Group Perovskite Tandem Solar Cells, Helmholtz-Zentrum Berlin für Materialien und Energie GmbH, 12489 Berlin, Germany; Faculty of Electrical Engineering and Computer Science, Technical University Berlin, 10587 Berlin, Germany; orcid.org/0000-0001-9962-9535; 

- Email: steve.albrecht@helmholtz-berlin.de 

#### Authors 

- Eike Köhnen − Young Investigator Group Perovskite Tandem Solar Cells, Helmholtz-Zentrum Berlin für Materialien und Energie GmbH, 12489 Berlin, Germany; orcid.org/00000002-3637-4907 

- Amran Al-Ashouri − Young Investigator Group Perovskite Tandem Solar Cells, Helmholtz-Zentrum Berlin für Materialien und Energie GmbH, 12489 Berlin, Germany; orcid.org/0000-0001-5512-8034 

- Tobias Bertram − PVcomB, Helmholtz Zentrum Berlin fur̈ Materialien und Energie, 12489 Berlin, Germany; orcid.org/0000-0002-4060-7523 

- Špela Tomsič ̌ − Faculty of Electrical Engineering, University of Ljubljana, 1000 Ljubljana, Slovenia 

1304 

https://doi.org/10.1021/acsenergylett.2c00274 ACS Energy Lett. 2022, 7, 1298−1307 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Letter</mark> 

- Artiom Magomedov − Department of Organic Chemistry, Kaunas University of Technology, 50254 Kaunas, Lithuania 

- Ernestas Kasparavicius − Department of Organic Chemistry, Kaunas University of Technology, 50254 Kaunas, Lithuania 

- Tim Kodalle − PVcomB, Helmholtz Zentrum Berlin fur̈ Materialien und Energie, 12489 Berlin, Germany; orcid.org/0000-0002-8792-9669 

- Benjamin Lipovšek − Faculty of Electrical Engineering, University of Ljubljana, 1000 Ljubljana, Slovenia 

- Vytautas Getautis − Department of Organic Chemistry, Kaunas University of Technology, 50254 Kaunas, Lithuania; orcid.org/0000-0001-7695-4677 

- Rutger Schlatmann − PVcomB, Helmholtz Zentrum Berlin für Materialien und Energie, 12489 Berlin, Germany; Faculty 1: School of Engineering − Energy and Information, Hochschule für Technik und Wirtschaft Berlin, 10313 Berlin, Germany; orcid.org/0000-0002-5951-9435 

- Christian A. Kaufmann − PVcomB, Helmholtz Zentrum Berlin für Materialien und Energie, 12489 Berlin, Germany 

- Marko Topič − Faculty of Electrical Engineering, University of Ljubljana, 1000 Ljubljana, Slovenia; orcid.org/00000001-8089-2974 

Complete contact information is available at: https://pubs.acs.org/10.1021/acsenergylett.2c00274 

#### Notes 

The authors declare no competing financial interest. 

# ■<sup>ACKNOWLEDGMENTS</sup> 

The authors acknowledge the funding by the Slovene Research Agency (ARRS) for Research Programs P2-0415 and J2-1727, and German Federal Ministry of Education and Research (BMBF, Grant 03SF0540). We thank the Helmholtz Association for funding the project TAPAS (Tandem Perovskite and Silicon Solar CellsAdvanced Optoelectrical Characterization, Modelling and Stability) within the EU partnering program and DAAD for the funding of Bilateral Project BI-DE/2017-2019/004. A.M., Er.K., and V.G. acknowledge funding from the Research Council of Lithuania under Grant Agreement 01.2.2-LMT-K-718-03-0040 (SMARTMOLECULES). Authors from PVcomB thank G.A. Farias Basulto, D. Greiner, M. D. Heinemann, I. Kafejiska, R. Klenk, I. Lauermann, J. A. Márquez Prieto, N. Maticiuc, P. Reyes Figueroa, A. Ruiz Perona, T. Unold, R. Wenisch, and H. A. Yetkin for valuable discussions and assistance during bottom device development. Furthermore, B. Bunn, I. Dorband, R. Haberecht, T. Hänel, M. Hartig, M. Kirsch, J. Lauche, K. Mack, K. Mayer-Stillrich, T. Münchenberg, and E. Waack are acknowledged for technical support. 

# ■<sup>REFERENCES</sup> 

(1) Yu, Z. J.; Carpenter, J. V.; Holman, Z. C. Techno-Economic Viability of Silicon-Based Tandem Photovoltaic Modules in the United States. Nat. Energy 2018, 3 (9), 747−753. 

(2) Jost,̌ M.; Kegelmann, L.; Korte, L.; Albrecht, S. Monolithic Perovskite Tandem Solar Cells: A Review of the Present Status and Advanced Characterization Methods Toward 30% Efficiency. Adv. Energy Mater. 2020, 10 (26), 1904102. 

(3) Al-Ashouri, A.; Köhnen, E.; Li, B.; Magomedov, A.; Hempel, H.; Caprioglio, P.; Márquez, J. A.; Morales Vilches, A. B.; Kasparavicius, E.; Smith, J. A.; Phung, N.; Menzel, D.; Grischek, M.; Kegelmann, L.; Skroblin, D.; Gollwitzer, C.; Malinauskas, T.; Jošt, M.; Matic,̌ G.; Rech, B.; Schlatmann, R.; Topič, M.; Korte, L.; Abate, A.; Stannowski, 

B.; Neher, D.; Stolterfoht, M.; Unold, T.; Getautis, V.; Albrecht, S. Monolithic Perovskite/Silicon Tandem Solar Cell with >29% Efficiency by Enhanced Hole Extraction. Science 2020, 370 (6522), 1300−1309. 

(4) Best Research-Cell Efficiency Chart https://www.nrel.gov/pv/ cell-efficiency.html (accessed Feb 2, 2022). 

(5) Fu, F.; Nishiwaki, S.; Werner, J.; Feurer, T.; Pisoni, S.; Jeangros, Q.; Buecheler, S.; Ballif, C.; Tiwari, A. N. Flexible Perovskite/ Cu(In,Ga)Se2Monolithic Tandem Solar Cells. ArXiv 2019, No. 1907.10330, (accesssed Feb 28, 2022). 

(6) Lang, F.; Jošt, M.; Bundesmann, J.; Denker, A.; Albrecht, S.; Landi, G.; Neitzert, H.-C.; Rappich, J.; Nickel, N. H. Efficient Minority Carrier Detrapping Mediating the Radiation Hardness of Triple-Cation Perovskite Solar Cells under Proton Irradiation. Energy Environ. Sci. 2019, 12 (5), 1634−1647. 

(7) Lang, F.; Jost,̌ M.; Frohna, K.; Köhnen, E.; Al-Ashouri, A.; Bowman, A. R.; Bertram, T.; Morales-Vilches, A. B.; Koushik, D.; Tennyson, E. M.; Galkowski, K.; Landi, G.; Creatore, M.; Stannowski, B.; Kaufmann, C. A.; Bundesmann, J.; Rappich, J.; Rech, B.; Denker, A.; Albrecht, S.; Neitzert, H.-C.; Nickel, N. H.; Stranks, S. D. Proton Radiation Hardness of Perovskite Tandem Photovoltaics. Joule 2020, 4 (5), 1054−1069. 

(8) Todorov, T.; Gershon, T.; Gunawan, O.; Lee, Y. S.; Sturdevant, C.; Chang, L.-Y.; Guha, S. Monolithic Perovskite-CIGS Tandem Solar Cells via In Situ Band Gap Engineering. Adv. Energy Mater. 2015, 5 (23), 1500799. 

(9) Han, Q.; Hsieh, Y.-T.; Meng, L.; Wu, J.-L.; Sun, P.; Yao, E.-P.; Chang, S.-Y.; Bae, S.-H.; Kato, T.; Bermudez, V.; Yang, Y. HighPerformance Perovskite/Cu(In,Ga)Se2 Monolithic Tandem Solar Cells. Science 2018, 361 (6405), 904−908. 

(10) Jost,̌ M.; Bertram, T.; Koushik, D.; Marquez, J. A.; Verheijen, M. A.; Heinemann, M. D.; Köhnen, E.; Al-Ashouri, A.; Braunger, S.; Lang, F.; Rech, B.; Unold, T.; Creatore, M.; Lauermann, I.; Kaufmann, C. A.; Schlatmann, R.; Albrecht, S. 21.6%-Efficient Monolithic Perovskite/Cu(In,Ga)Se2 Tandem Solar Cells with Thin Conformal Hole Transport Layers for Integration on Rough Bottom Cell Surfaces. ACS Energy Lett. 2019, 4 (2), 583−590. 

(11) Al-Ashouri, A.; Magomedov, A.; Roß, M.; Jost, M.; Talaikis, M.;̌ Chistiakova, G.; Bertram, T.; Márquez, J. A.; Köhnen, E.; Kasparavičius, E.; Levcenco, S.; Gil-Escrig, L.; Hages, C. J.; Schlatmann, R.; Rech, B.; Malinauskas, T.; Unold, T.; Kaufmann, C. A.; Korte, L.; Niaura, G.; Getautis, V.; Albrecht, S. Conformal Monolayer Contacts with Lossless Interfaces for Perovskite Single Junction and Monolithic Tandem Solar Cells. Energy Environ. Sci. 2019, 12 (11), 3356−3369. 

(12) Green, M.; Dunlop, E.; Hohl-Ebinger, J.; Yoshita, M.; Kopidakis, N.; Hao, X. Solar Cell Efficiency Tables (Version 57). Prog. Photovolt. Res. Appl. 2021, 29 (1), 3−15. 

(13) Santbergen, R.; Mishima, R.; Meguro, T.; Hino, M.; Uzu, H.; Blanker, J.; Yamamoto, K.; Zeman, M. Minimizing Optical Losses in Monolithic Perovskite/c-Si Tandem Solar Cells with a Flat Top Cell. Opt. Express 2016, 24 (18), A1288−A1299. 

(14) Jäger, K.; Korte, L.; Rech, B.; Albrecht, S. Numerical Optical Optimization of Monolithic Planar Perovskite-Silicon Tandem Solar Cells with Regular and Inverted Device Architectures. Opt. Express 2017, 25 (12), A473−A482. 

(15) Jošt, M.; Köhnen, E.; Morales-Vilches, A. B.; Lipovšek, B.; Jäger, K.; Macco, B.; Al-Ashouri, A.; Krč, J.; Korte, L.; Rech, B.; Schlatmann, R.; Topic,̌ M.; Stannowski, B.; Albrecht, S. Textured Interfaces in Monolithic Perovskite/Silicon Tandem Solar Cells: Advanced Light Management for Improved Efficiency and Energy Yield. Energy Environ. Sci. 2018, 11 (12), 3511−3523. 

(16) Langenhorst, M.; Sautter, B.; Schmager, R.; Lehr, J.; Ahlswede, E.; Powalla, M.; Lemmer, U.; Richards, B. S.; Paetzold, U. W. Energy Yield of All Thin-Film Perovskite/CIGS Tandem Solar Modules. Prog. Photovolt. Res. Appl. 2019, 27 (4), 290−298. 

(17) Schmager, R.; Langenhorst, M.; Lehr, J.; Lemmer, U.; Richards, B. S.; Paetzold, U. W. Methodology of Energy Yield Modelling of 

1305 

https://doi.org/10.1021/acsenergylett.2c00274 ACS Energy Lett. 2022, 7, 1298−1307 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Letter</mark> 

Perovskite-Based Multi-Junction Photovoltaics. Opt. Express 2019, 27 (8), A507−A523. 

(18) Hörantner, M. T.; Snaith, H. J. Predicting and Optimising the Energy Yield of Perovskite-on-Silicon Tandem Solar Cells under Real World Conditions. Energy Environ. Sci. 2017, 10 (9), 1983−1993. 

(19) Jošt, M.; Lipovšek, B.; Glazar,̌ B.; Al-Ashouri, A.; Brecl, K.; Matic,̌ G.; Magomedov, A.; Getautis, V.; Topič, M.; Albrecht, S. Perovskite Solar Cells Go Outdoors: Field Testing and Temperature Effects on Energy Yield. Adv. Energy Mater. 2020, 10 (25), 2000454. 

(20) Lipovšek, B.; Jošt, M.; Tomsič ,̌ Š.; Topič, M. Energy Yield of Perovskite Solar Cells: Influence of Location, Orientation, and External Light Management. Sol. Energy Mater. Sol. Cells 2022, 234, 111421. 

(21) Kodalle, T.; Bertram, T.; Schlatmann, R.; Kaufmann, C. A. Effectiveness of an RbF Post Deposition Treatment of CIGS Solar Cells in Dependence on the Cu Content of the Absorber Layer. IEEE J. Photovolt. 2019, 9 (6), 1839−1845. 

(22) Saliba, M.; Correa-Baena, J.-P.; Wolff, C. M.; Stolterfoht, M.; Phung, N.; Albrecht, S.; Neher, D.; Abate, A. How to Make over 20% Efficient Perovskite Solar Cells in Regular (n−i−p) and Inverted (p− i−n) Architectures. Chem. Mater. 2018, 30 (13), 4193−4201. 

(23) Kim, D. H.; Muzzillo, C. P.; Tong, J.; Palmstrom, A. F.; Larson, B. W.; Choi, C.; Harvey, S. P.; Glynn, S.; Whitaker, J. B.; Zhang, F.; Li, Z.; Lu, H.; van Hest, M. F. A. M.; Berry, J. J.; Mansfield, L. M.; Huang, Y.; Yan, Y.; Zhu, K. Bimolecular Additives Improve WideBand-Gap Perovskites for Efficient Tandem Solar Cells with CIGS. Joule 2019, 3, 1734. 

(24) Gharibzadeh, S.; Fassl, P.; Hossain, I. M.; Rohrbeck, P.; Frericks, M.; Schmidt, M.; Duong, T.; Khan, M. R.; Abzieher, T.; Nejand, B. A.; Schackmar, F.; Almora, O.; Feeney, T.; Singh, R.; Fuchs, D.; Lemmer, U.; Hofmann, J. P.; Weber, S. A. L.; Paetzold, U. W. Two Birds with One Stone: Dual Grain-Boundary and Interface Passivation Enables > 22% Efficient Inverted Methylammonium-Free Perovskite Solar Cells. Energy Environ. Sci. 2021, 14, 5875. 

(25) Sahli, F.; Werner, J.; Kamino, B. A.; Bräuninger, M.; Monnard, R.; Paviet-Salomon, B.; Barraud, L.; Ding, L.; Diaz Leon, J. J.; Sacchetto, D.; Cattaneo, G.; Despeisse, M.; Boccard, M.; Nicolay, S.; Jeangros, Q.; Niesen, B.; Ballif, C. Fully Textured Monolithic Perovskite/Silicon Tandem Solar Cells with 25.2% Power Conversion Efficiency. Nat. Mater. 2018, 17 (9), 820−826. 

(26) Stolterfoht, M.; Wolff, C. M.; Márquez, J. A.; Zhang, S.; Hages, C. J.; Rothhardt, D.; Albrecht, S.; Burn, P. L.; Meredith, P.; Unold, T.; Neher, D. Visualization and Suppression of Interfacial Recombination for High-Efficiency Large-Area Pin Perovskite Solar Cells. Nat. Energy 2018, 3 (10), 847−854. 

(27) Xu, J.; Boyd, C. C.; Yu, Z. J.; Palmstrom, A. F.; Witter, D. J.; Larson, B. W.; France, R. M.; Werner, J.; Harvey, S. P.; Wolf, E. J.; Weigand, W.; Manzoor, S.; van Hest, M. F. A. M.; Berry, J. J.; Luther, J. M.; Holman, Z. C.; McGehee, M. D. Triple-Halide Wide-Band Gap Perovskites with Suppressed Phase Segregation for Efficient Tandems. Science 2020, 367 (6482), 1097−1104. 

(28) Minemawari, H.; Yamada, T.; Matsui, H.; Tsutsumi, J.; Haas, S.; Chiba, R.; Kumai, R.; Hasegawa, T. Inkjet Printing of SingleCrystal Films. Nature 2011, 475 (7356), 364−367. 

(29) Sever, M.; Lipovšek, B.; Krč, J.; Čampa, A.; Sánchez Plaza, G.; Haug, F.-J.; Duchamp, M.; Soppe, W.; Topič, M. Combined Model of Non-Conformal Layer Growth for Accurate Optical Simulation of Thin-Film Silicon Solar Cells. Sol. Energy Mater. Sol. Cells 2013, 119, 59−66. 

(30) Köhnen, E.; Jost, M.; Morales-Vilches, A. B.; Tockhorn, P.; Al-̌ Ashouri, A.; Macco, B.; Kegelmann, L.; Korte, L.; Rech, B.; Schlatmann, R.; Stannowski, B.; Albrecht, S. Highly Efficient Monolithic Perovskite Silicon Tandem Solar Cells: Analyzing the Influence of Current Mismatch on Device Performance. Sustain. Energy Fuels 2019, 3 (8), 1995−2005. 

(31) Lipovšek, B.; Krč, J.; Topič, M. Optical Model for Thin-Film Photovoltaic Devices with Large Surface Textures at the Front Side. Inf. MIDEM 2011, 41 (4), 264−271. 

(32) Lipovšek, B.; Krč, J.; Topič, M. Microtextured LightManagement Foils and Their Optimization for Planar Organic and Perovskite Solar Cells. IEEE J. Photovolt. 2018, 8 (3), 783−792. 

(33) Liu, D.; Wang, Q.; Traverse, C. J.; Yang, C.; Young, M.; Kuttipillai, P. S.; Lunt, S. Y.; Hamann, T. W.; Lunt, R. R. Impact of Ultrathin C60 on Perovskite Photovoltaic Devices. ACS Nano 2018, 12 (1), 876−883. 

(34) Löper, P.; Stuckelberger, M.; Niesen, B.; Werner, J.; Filipič, M.; Moon, S.-J.; Yum, J.-H.; Topič, M.; De Wolf, S.; Ballif, C. Complex Refractive Index Spectra of CH3NH3PbI3 Perovskite Thin Films Determined by Spectroscopic Ellipsometry and Spectrophotometry. J. Phys. Chem. Lett. 2015, 6 (1), 66−71. 

(35) McMeekin, D. P.; Sadoughi, G.; Rehman, W.; Eperon, G. E.; Saliba, M.; Hörantner, M. T.; Haghighirad, A.; Sakai, N.; Korte, L.; Rech, B.; et al. A Mixed-Cation Lead Mixed-Halide Perovskite Absorber for Tandem Solar Cells. Science 2016, 351 (6269), 151− 155. 

(36) Tejada, A.; Braunger, S.; Korte, L.; Albrecht, S.; Rech, B.; Guerra, J. A. Optical Characterization and Bandgap Engineering of Flat and Wrinkle-Textured FA0.83Cs0.17Pb(I1−XBrx)3 Perovskite Thin Films. J. Appl. Phys. 2018, 123 (17), 175302. 

(37) Ramanujam, J.; Singh, U. P. Copper Indium Gallium Selenide Based Solar Cells − a Review. Energy Environ. Sci. 2017, 10 (6), 1306−1319. 

(38) Chirilǎ, A.; Reinhard, P.; Pianezzi, F.; Bloesch, P.; Uhl, A. R.; Fella, C.; Kranz, L.; Keller, D.; Gretener, C.; Hagendorfer, H.; Jaeger, D.; Erni, R.; Nishiwaki, S.; Buecheler, S.; Tiwari, A. N. PotassiumInduced Surface Modification of Cu(In,Ga)Se 2 Thin Films for HighEfficiency Solar Cells. Nat. Mater. 2013, 12 (12), 1107−1111. 

(39) Hou, Y.; Aydin, E.; De Bastiani, M.; Xiao, C.; Isikgor, F. H.; Xue, D.-J.; Chen, B.; Chen, H.; Bahrami, B.; Chowdhury, A. H.; Johnston, A.; Baek, S.-W.; Huang, Z.; Wei, M.; Dong, Y.; Troughton, J.; Jalmood, R.; Mirabelli, A. J.; Allen, T. G.; Van Kerschaver, E.; Saidaminov, M. I.; Baran, D.; Qiao, Q.; Zhu, K.; De Wolf, S.; Sargent, E. H. Efficient Tandem Solar Cells with Solution-Processed Perovskite on Textured Crystalline Silicon. Science 2020, 367 (6482), 1135−1140. 

(40) Jost,̌ M.; Albrecht, S.; Kegelmann, L.; Wolff, C. M.; Lang, F.; Lipovšek, B.; Krč, J.; Korte, L.; Neher, D.; Rech, B.; Topic,̌ M. Efficient Light Management by Textured Nanoimprinted Layers for Perovskite Solar Cells. ACS Photonics 2017, 4 (5), 1232−1239. 

(41) Mazzarella, L.; Lin, Y.-H.; Kirner, S.; Morales-Vilches, A. B.; Korte, L.; Albrecht, S.; Crossland, E.; Stannowski, B.; Case, C.; Snaith, H. J.; Schlatmann, R. Infrared Light Management Using a Nanocrystalline Silicon Oxide Interlayer in Monolithic Perovskite/Silicon Heterojunction Tandem Solar Cells with Efficiency above 25%. Adv. Energy Mater. 2019, 9, 1803241. 

(42) Mazzarella, L.; Werth, M.; Jäger, K.; Jošt, M.; Korte, L.; Albrecht, S.; Schlatmann, R.; Stannowski, B. Infrared Photocurrent Management in Monolithic Perovskite/Silicon Heterojunction Tandem Solar Cells by Using a Nanocrystalline Silicon Oxide Interlayer. Opt. Express 2018, 26 (10), A487−A497. 

(43) Nakamura, M.; Yamaguchi, K.; Kimoto, Y.; Yasaki, Y.; Kato, T.; Sugimoto, H. Cd-Free Cu(In,Ga)(Se,S)2 Thin-Film Solar Cell With Record Efficiency of 23.35%. IEEE J. Photovolt. 2019, 9 (6), 1863− 1867. 

(44) Liu, Z.; Krückemeier, L.; Krogmeier, B.; Klingebiel, B.; Márquez, J. A.; Levcenko, S.; Oz,̈ S.; Mathur, S.; Rau, U.; Unold, T.; Kirchartz, T. Open-Circuit Voltages Exceeding 1.26 V in Planar Methylammonium Lead Iodide Perovskite Solar Cells. ACS Energy Lett. 2019, 4, 110−117. 

(45) Gharibzadeh, S.; Abdollahi Nejand, B.; Jakoby, M.; Abzieher, T.; Hauschild, D.; Moghadamzadeh, S.; Schwenzer, J. A.; Brenner, P.; Schmager, R.; Haghighirad, A. A.; Weinhardt, L.; Lemmer, U.; Richards, B. S.; Howard, I. A.; Paetzold, U. W. Record Open-Circuit Voltage Wide-Bandgap Perovskite Solar Cells Utilizing 2D/3D Perovskite Heterostructure. Adv. Energy Mater. 2019, 9 (21), 1803699. 

1306 

https://doi.org/10.1021/acsenergylett.2c00274 ACS Energy Lett. 2022, 7, 1298−1307 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Letter</mark> 

(46) Kruckemeier, L.; Rau, U.; Stolterfoht, M.; Kirchartz, T. How tö Report Record Open-Circuit Voltages in Lead-Halide Perovskite Solar Cells. Adv. Energy Mater. 2020, 10, 1902573. 

(47) Friesen, G.; Pavanello, D.; Virtuani, A. Overview of Temperature Coefficients of Different Thin Film Photovoltaic Technologies. Proceedings, 25th European Photovoltaic Solar Energy Conference and Exhibition, 5th World Conference on Photovoltaic Energy Conversion, Valencia, Spain, Sep 6−10, 2010; PES, 2010; pp 4248−4252, 

(48) Theelen, M.; Liakopoulou, A.; Hans, V.; Daume, F.; Steijvers, H.; Barreau, N.; Vroon, Z.; Zeman, M. Determination of the Temperature Dependency of the Electrical Parameters of CIGS Solar Cells. J. Renew. Sustain. Energy 2017, 9 (2), No. 021205. 

(49) Farias-Basulto, G. A.; Reyes-Figueroa, P.; Ulbrich, C.; Szyszka, B.; Schlatmann, R.; Klenk, R. Validation of a Multiple Linear Regression Model for CIGSSe Photovoltaic Module Performance and Pmpp Prediction. Sol. Energy 2020, 208, 859−865. 

1307 

https://doi.org/10.1021/acsenergylett.2c00274 ACS Energy Lett. 2022, 7, 1298−1307 

