# Transition metal-catalysed molecular n-doping of organic semiconductors

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Nature |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 232 |
| 作者 | Han Guo, Chi-Yuan Yang, Xianhe Zhang, A. Motta, Kui Feng, Yu Xia, Yong-Qiang Shi, Ziang Wu et al. |
| DOI | 10.1038/s41586-021-03942-0 |
| 源文件 | 048_Guo_2021_Transition-metal-catalysed-molecular-n-doping-of.pdf |

---
Article 

# **Transition metal-catalysed molecular n-doping of organic semiconductors** 

|https://doi.org/10.1038/s41586-021-03942-0<br>Received: 29 January 2020<br>Accepted: 24 August 2021|**Han Guo**<sup>**1**</sup>**, Chi-Yuan Yang**<sup>**2**</sup>**, Xianhe Zhang**<sup>**1**</sup>**, Alessandro Motta**<sup>**3**</sup>**, Kui Feng**<sup>**1**</sup>**, Yu Xia**<sup>**4**</sup>**,**<br>**Yongqiang Shi**<sup>**1**</sup>**, Ziang Wu**<sup>**5**</sup>**, Kun Yang**<sup>**1**</sup>**, Jianhua Chen**<sup>**1**</sup>**, Qiaogan Liao**<sup>**1**</sup>**, Yumin Tang**<sup>**1**</sup>**,**<br>**Huiliang Sun**<sup>**1**</sup>**, Han Young Woo**<sup>**5**</sup>**, Simone Fabiano**<sup>**2**</sup>**, Antonio Facchetti**<sup>**2,4,6** ✉</sup>**& Xugang Guo**<sup>**1** ✉</sup>|
|---|---|
|Published online: 3 November 2021<br>Check for updates|Chemical doping is a key process for investigating charge transport in organic<br>semiconductors and improving certain (opto)electronic devices<sup>1–9</sup>.<br>N(electron)-doping is fundamentally more challenging than p(hole)-doping and<br>typically achieves a very low doping efficiency (_η_) of less than 10%<sup>1,10</sup>. An efficient<br>molecular n-dopant should simultaneously exhibit a high reducing power and air<br>stability for broad applicability<sup>1,5,6,9,11</sup>, which is very challenging. Here we show a<br>general concept of catalysed n-doping of organic semiconductors using air-stable<br>precursor-type molecular dopants. Incorporation of a transition metal (for example,<br>Pt, Au, Pd) as vapour-deposited nanoparticles or solution-processable<br>organometallic complexes (for example, Pd2(dba)3) catalyses the reaction, as<br>assessed by experimental and theoretical evidence, enabling greatly increased_η_in a<br>much shorter doping time and high electrical conductivities (above 100 S cm<sup>−1</sup>;<br>ref.<sup>12</sup>). This methodology has technological implications for realizing improved<br>semiconductor devices and offers a broad exploration space of ternary systems<br>comprising catalysts, molecular dopants and semiconductors, thus opening new<br>opportunities in n-doping research and applications<sup>12, 13</sup>.|



N-doping of organic semiconductors is important for developing light-emitting diodes<sup>1,6–9</sup> , solar cells<sup>7,8</sup> , thin-film transistors<sup>10</sup> and thermoelectric devices<sup>12,13</sup> . Although solution-based n-doping is widely investigated, only a few air-stable n-dopants have been developed (Supplementary Fig. 1), with the most prominent being organic hydrides<sup>5,9,14–18</sup> such as benzoimidazole derivatives, dimers of organic radicals<sup>11,19,20</sup> such as 19-electron organometallic sandwich compounds, and mono-/multi-valent anions<sup>8,21,22</sup> such as OH<sup>−</sup> , F<sup>−</sup> and Ox<sup>2−</sup> . These air-stable dopants have a deep ionization potential in their initial forms and therefore cannot directly transfer electrons to n-dope organic semiconductors with a low electron affinity. For anions, it has been shown that dispersion into small anhydrous clusters enables sufficiently high donor levels for n-doping organic semiconductors with electron affinities up to 2.4 eV (ref.<sup>8</sup> ). Hydride and dimer dopant precursors (referred as precursor-type dopants) most undergo a C–H and C–C bond cleavage reaction, respectively, to generate active-doping-species in situ before electron transfer can occur<sup>23–26</sup> . Thus, their reducing strength and reaction kinetics are strongly affected by the thermodynamics and the activation energies of the doping reaction<sup>23–26</sup> . If the activation energy to the product is reduced, it is expected that the reaction rate, and extent of doping, will greatly increase (Fig. 1a). 

Transition metal (TM)-catalysed C–H and C–C bond cleavage reactions are widely used in organic synthesis, with the most common TMs belonging to group 8–11 elements and the catalysts being in the form of nanoparticles and organometallic complexes<sup>27,28</sup> . Nanoparticle 

size, supporting material and the chemical structure of the complex can greatly affect catalytic activities. Thus, intriguing questions are whether TM catalysts can be used for precursor-type dopants, whether they are compatible with different semiconductors, whether the overall doping efficiency/rate can be improved, and whether it can have technological implications. Here we explore the doping process in ternary systems comprising a benzoimidazole-based hydride molecular dopant (N-DMBI-H)<sup>5</sup> and group 10/11 TM catalysts, in the form of metal nanoparticles and an organometallic complex [Pd2(dba)3], with various electron-transporting organic semiconductors to validate the general concept (Fig. 1b, c). N-DMBI-H is used because of its commercial availability, air stability, good reducing capability, and broad applicability to several semiconductors<sup>12,14,29,30</sup> . Group 10/11 TM catalysts were used because of accessibility in various forms including vapour/solution processed nanoparticles and soluble complexes<sup>27,28,31</sup> . 

### **Au nanoparticle-catalysed doping of PDTzTI** 

The TM catalysed n-doping methodology is straightforward and efficient, as demonstrated in Fig. 2 using Au nanoparticles (AuNPs) as an example. The NPs of size ( _d_ ) from 1.4 ± 0.3 nm to 8.2 ± 2.7 nm were fabricated by thermal evaporation of Au films with nominal thickness of 0.1–1.5 nm, and nanoparticle formation was confirmed by transmission electron microscopy (TEM) and plasmonic signature (Extended Data Fig. 1, Supplementary Fig. 3). However, ~1.4-nm nanoparticles were 

> 1Department of Materials Science and Engineering, Southern University of Science and Technology (SUSTech), Shenzhen, Guangdong, China. 2Laboratory of Organic Electronics, Department of Science and Technology, Linköping University, Norrköping, Sweden.<sup>3</sup> Dipartimento di Scienze Chimiche, Università di Roma “La Sapienza” and INSTM, UdR Roma, Roma, Italy.<sup>4</sup> Flexterra Corporation, Skokie, IL, USA.<sup>5</sup> Department of Chemistry, Korea University, Seoul, South Korea.<sup>6</sup> Department of Chemistry and the Materials Research Center, Northwestern University, Evanston, IL, USA.<sup>✉</sup> e-mail: afacchetti@flexterracorp.com; guoxg@sustech.edu.cn 

Nature | Vol 599 | 4 November 2021 | **67** 



<!-- Start of picture text -->
Article<br><!-- End of picture text -->



<!-- Start of picture text -->
a b<br>Direct n-dopant Precursor-type n-dopant Dopant Catalyst<br>Without catalyst<br>Activation Nanoparticle: Ni Cu<br>N<br>reduction energy Pd Ag<br>Pt Au<br>With catalyst,<br>IP, dopant e – transition state<br>e –<br>IP, active- H Organometallic complex:<br>doping-species N N O<br>EA, acceptor<br>e – Pd2<br>IP, precursor N-DMBI-H Pd2(dba)3 3<br>c R R R<br>O N O O N O O N O<br>X S<br>X N N X S n<br>S S S S n S S S S S n N2200<br>N X N R = 2-octyldodecyl<br>PDTzTI:  X = C-H PDTzTIT-2F:  X = F O N O<br>R PBTzI: = 2-hex X = Nlydecly O N O PDTzTIT: R = 2-hexly X = Hdecly O N O R O RN O<br>R<br>R<br>R F R<br>O RN O O N O F O N O<br>S S S n<br>S S<br>S S<br>n O N O O N O<br>PBTI f-BTI2-FT R R O N O<br>R = 2-octyldodecyl R = 2-octyldodecyl O O O R<br>f-BTI2TEG-FT R = O O NDI-EH PDI-C6C7<br>O R = 2-ethylhexyl R = 1-hexylheptyl<br>Energy level<br><!-- End of picture text -->

**Fig. 1 | The TM catalysed n-doping concept. a** , Molecular n-doping process for direct n-dopant and precursor-type n-dopant. Direct n-dopants reduce an n-type organic semiconductor (acceptor) by direct electron transfer, so their ionization potential (IP) needs to be higher than the electron affinity (EA) of organic semiconductor acceptor, making them sensitive to oxygen/moisture and difficult to handle. Precursor-type n-dopants generally have deep IPs and are more air-stable, but bond cleavage limits their doping reaction rate and 

efficiency. Incorporation of TM catalysts can lower bond cleavage activation energy, leading to increases in doping reaction rate, efficiency and effective doping power. **b** , **c** , The hydride molecular dopant N-DMBI-H, TM catalysts ( **b** ) and n-type organic semiconductors ( **c** ) used in this study. When performing N-DMBI-H doping with a catalyst, for example, AuNPs, a general rapid and strong film colour change occurs, indicating successful heavy n-doping of the acceptor (Supplementary Fig. 2, Supplementary Video 1). 

mostly used throughout this study because they are efficient catalysts (vide infra) and their negligible absoptivity prevents interference with semiconductor optical characterization. After AuNP deposition, the doped films were obtained following one of two procedures (Fig. 2a): specifically, (1) spin-coating a semiconductor + dopant blend solution (blend doping) or (2) first spin-coating a semiconductor solution followed by deposition of the dopant solution (sequential doping). In both cases, the doping process was completed by mild thermal annealing for a given time (typically _T_ ann = 120 °C and _t_ ann = 10 s; see Methods). 

We first discuss the results for the semiconductor PDTzTI<sup>32</sup> with AuNP to exemplify the effectiveness of this approach. Despite its all-acceptor backbone structure and relatively deep electron affinity of 3.77 eV, this polymer can only be weakly n-doped even when blended with 100mol% (1 molar equivalent of its repeating unit) of N-DMBI-H after annealing at 120 °C for 10 min. In contrast, PDTzTI is efficiently n-doped by N-DMBI-H with AuNPs after annealing at 120 °C for 10 s, as evidenced by the bleaching of the 2.2–2.4 eV optical transition, appearance of a broad polaronic near-infrared band (Fig. 2b), and stronger electron spin resonance (ESR) signal (Fig. 2c). 

N-DMBI-H doping of PDTzTI without/with AuNPs was then assessed quantitatively. Without AuNPs, a low charge density of ~10<sup>17</sup> –10<sup>18</sup> cm<sup>−3</sup> was found in doped PDTzTI samples when using 5–100mol% of N-DMBI-H, translating to a very poor doping efficiency ( _η_ ) of <0.5% (Fig. 2d), as determined from Mott–Schottky analysis and ESR 

measurements (Supplementary Fig. 4 and Fig. 2c). Accordingly, a low electrical conductivity ( _σ_ ) of (3.5 ± 0.4)×10<sup>−4</sup> S cm<sup>−1</sup> was measured even at the greatest N-DMBI-H loading of 100mol% (Fig. 2e). However, with AuNPs _σ_ increases by >10<sup>4</sup> × at a N-DMBI-H loading ≥20mol%, reaching 14.1 ± 0.7 S cm<sup>−1</sup> for a 60mol% dopant content (Fig. 2e). Furthermore, with AuNPs the charge density increases to ~2 × 10<sup>19</sup> –6 × 10<sup>19</sup> cm<sup>−3</sup> (~0.03–0.09 charge/repeat unit) as determined by ESR measurements (Supplementary Fig. 5), an underestimated value if bipolarons form<sup>33</sup> , leading to a ~100× greater _η_ of ~10–50% for PDTzTI (see discussion in Extended Data Fig. 3). Thus, PDTzTI conductivity enhancement is likely to be due to greater doping efficiency, as assessed by optical and ESR measurements, and larger carrier mobility in mid-/heavily doped samples versus the pristine/poorly doped films (Supplementary Figs. 4d and 5b), as seen for other polymers<sup>34</sup> . Note _σ_ of the uncatalysed/doped samples is measured with Al electrodes to avoid unintentional catalysis when using shadow mask deposited Au contacts (vide infra), while Au electrodes are used for catalysed/doped samples for efficient charge injection, in view of the non-linear current–voltage ( _I_ – _V_ ) characteristics of catalysed/doped samples with Al electrodes (Extended Data Fig. 2a–c) likely to be originating from non-optimal injection due to AlO _x_ on Al and the Al/organic interface dipole<sup>35</sup> . However, we stress that the 60mol% N-DMBI-H+AuNPs blend doped PDTzTI devices using Al electrodes still exhibit a _σ_ (3.6 ± 0.3 S cm<sup>−1</sup> ), close to that measured with Au (14.1 ± 0.7 S cm<sup>−1</sup> ) (Extended Data Fig. 2b). 

**68** | Nature | Vol 599 | 4 November 2021 



<!-- Start of picture text -->
a b c<br>SubstrateMetal NP Blend doping Blend  0.4 PDTzTIDoped w/o AuNP 0.6  Doped w/o AuNP Doped w/ AuNP<br>(catalyst)<br>deposition solution Blendfilm 0.3 Doped w/ AuNP 0.3<br>Heat<br>Doped 0.0<br>films 0.2<br>Metal<br>Mask Sequential doping<br>depositioncontact  Semiconductor  Dopant  0.1 –0.3<br>solution Pristine  solution  Heat<br>film –0.6<br>0<br>1 2 3 4 3,450 3,500 3,550<br>Photon energy (eV) Magnetic field (Gauss)<br>d e f g<br>100 10 2 60<br>10 1 Sequential,<br>10 1 off-centre<br>10 0 Blend doped<br>10          w/ AuNP 40<br>Blend doped  10 –1 Blend doped  10 0<br>         w/ AuNP Sequential,<br> Blend doped  10 –2          w/o AuNP 120 °C100 °C on-centre<br>1          w/o AuNP 10 –3 10 –1 80 °C 20 Blend<br>60 °C<br>10 –4<br>0.1 10 –5 10 –2 0<br>0 20 40 60 80 100 0 20 40 60 80 100 0 60 120 180 240 300 360 Processing method<br>Dopant molar ratio (mol%) Dopant molar ratio (mol%) Annealing time (s)<br>Absorbance<br>ESR signal (a.u.)<br>Doping efficiency (%)<br>–1Electrical conductivity (S cm) –1Electrical conductivity (S cm) –1)Electrical conductivity (S cm<br><!-- End of picture text -->

**Fig. 2 | AuNP catalysed n-doping of PDTzTI with N-DMBI-H. a** , Device structure and fabrication procedure via blend and sequential doping processes using nanoparticles (NPs) as the catalyst. For blend doping, the reaction starts immediately when the solution contacts the AuNPs. Note that Au (shadow mask deposited) is used as the contact material for devices with AuNPs, whereas Al (shadow mask deposited) was used for the devices without AuNP. For details and control experiments reasoning this selection, see discussion in Extended Data Fig. 2 and Supplementary Fig. 8. **b** , UV–vis–NIR spectra of pristine PDTzTI film (red), 100mol% N-DMBI-H blend doped films without (w/o) catalyst (cyan) and with (w/) AuNP (blue), with their photographs (inset) displayed in the same order. **c** – **e** , ESR signals ( **c** ), N-DMBI-H doping efficiency ( **d** ) and electrical conductivity of blend doped PDTzTI films without 

and with AuNP ( **e** ). Note that in **d** , the data with AuNPs are based on ESR measurement of spin density, which may underestimate the carrier density at high dopant molar ratio; the data without AuNPs are based on MIS diode capacitance measurement of charge density. **f** , Temporal evolution of 60mol% N-DMBI-H blend doped PDTzTI films with AuNP annealed at different temperatures. **g** , Electrical conductivity for sequential versus blend doping. Note, for sequential doping the PDTzTI film was deposited before doping, using off-centre spin-coating technique can partially align the polymer chains. Unless indicated otherwise, in all experiments _d_ = 1.4 nm, _T_ ann = 120 °C, _t_ ann = 10 s (with AuNPs) or 10 min (without AuNPs), and the substrate is glass. For the ESR experiment, the substrate is PET. Error bars represent the standard deviations from their mean values. 

Conventional/uncatalysed N-DMBI-H doping typically requires long annealing times to achieve high _σ_ with optimal conditions consisting of _T_ ann = 120–150 °C for as long as 2–8 h (see Supplementary Table 1). Such thermal/time budget is problematic for implementation in conventional fabrication processes and when using inexpensive plastic substrates. However, doping of PDTzTI with N-DMBI-H+AuNPs occurs at 120 °C in only ~10 s. Figure 2f demonstrates that _T_ ann can be reduced to 60 °C for a reasonably short _t_ ann of ~6 min. This allows doping using the most temperature-sensitive, but most inexpensive, plastic substrates (for example, PET) retaining excellent performance ( _σ_ = 12.1 ± 0.6 S cm<sup>−1</sup> , Extended Data Fig. 2d). 

Further _σ_ enhancement for PDTzTI is achieved using sequential doping (Fig. 2g, Supplementary Fig. 6 and Table 1), which includes separating semiconductor deposition and dopant deposition/infiltration steps<sup>36</sup> . Here deposition and optimization of the semiconductor film morphology are carried out independently of/before the dopant/ catalyst process. Thus, using this method, consisting of first on-centre or off-centre spin-coating of PDTzTI film followed by N-DMBI-H deposition/annealing, remarkable conductivities of 19.0 ± 0.9 S cm<sup>−1</sup> and 42.2 ± 1.8 S cm<sup>−1</sup> (maximum 46.6 S cm<sup>−1</sup> ) were obtained, respectively. 

The fact that Au electrodes are typically used for conductivity measurements of doped samples suggests the possibility of unintentional metal catalysis, which is now an intriguing and important question to address. When fabricating metal electrodes via thermal evaporation/shadow mask or photolithography/chemical etching, a small number of metal clusters/particles can remain in the channel owing to diffusion or incomplete etching. We investigated this phenomenon for N-DMBI-H doped 

PDTzTI using shadow mask evaporated Au electrodes (Supplementary Fig. 8), resulting in a _σ_ of 10.1 ± 0.4 S cm<sup>−1</sup> even without deliberately introducing AuNPs. This value is far higher than the _σ_ (~4.6 × 10<sup>−4</sup> S cm<sup>−1</sup> ) of devices using Au electrodes prepared by lift-off photolithography. Thus, care must be taken to ensure correct measurement of the doping efficiency, and to compare published data, when studying doping reactions of organic semiconductors with certain dopants. 

### **Generality of AuNP catalysed doping** 

The generality of AuNP catalytic activity is demonstrated for other semiconductors including several thiazole imide-based polymers<sup>37</sup> , naphthalene diimide (NDI) or perylene diimide (PDI)-based materials such as N2200, NDI-EH and PDI-C6C7, as clearly demonstrated by film colour change, doping efficiency and electrical conductivity enhancement, as well as the time to achieve it, upon doping (Fig. 3a–d, Supplementary Figs. 9–11, Extended Data Fig. 3, Table 1 and Supplementary Table 3). Larger _σ_ is generally observed for these planar thiazole imide-based polymers upon catalysed doping (Fig. 3a)<sup>32,37</sup> . For AuNP catalysed samples, _σ_ s of ~0.10 S cm<sup>−1</sup> and ~4 S cm<sup>−1</sup> are measured for doped PBTzI and PDTzTIT films, respectively, despite these polymers exhibiting lower field-effect mobilities than N2200<sup>37,38</sup> . Remarkable _σ_ s of 12.8 ± 0.5 S cm<sup>−1</sup> and 17.4 ± 0.9 S cm<sup>−1</sup> were obtained for blend and sequentially doped PDTzTIT-2F samples, respectively, representing a _σ_ enhancement of >10<sup>4</sup> times compared to the uncatalysed samples ( _σ_ ≈ 6 × 10<sup>−4</sup> S cm<sup>−1</sup> ). 

N2200 is poorly doped by N-DMBI-H with a low _η_ of ~ 1% even after _t_ ann > 2 h (ref.<sup>39</sup> ). When using AuNPs, the N2200 film colour quickly 

Nature | Vol 599 | 4 November 2021 | **69** 

Article 

**Table 1 | Summary of the electrical conductivities for the indicated n-type polymer semiconductors** 

|**Polymers**|**Without AuNP**<br>|**With AuNP catal**|**yst**|
|---|---|---|---|
||**catalyst, blend**<br>**doping (S cm**<sup>**−1**</sup>**)**|**Blend doping**<br>**(S cm**<sup>**−1**</sup>**)**|**Sequential doping**<br>**(S cm**<sup>**−1**</sup>**)**|
|PDTzTI|(3.5 ± 0.4) × 10<sup>−4</sup>|14.1 ± 0.7|19.0 ± 0.9/42.2 ± 1.8<br>(off-centre)|
|PDTzTIT-2F|(6.2 ± 0.3) × 10<sup>−4</sup>|12.8 ± 0.5|17.4 ± 0.9|
|PDTzTIT|(6.7 ± 0.4) × 10<sup>−5</sup>|3.5 ± 0.1|4.1 ± 0.1|
|PBTzI|(5.5 ± 0.5) × 10<sup>−4</sup>|0.10 ± 0.01|0.098 ± 0.002|
|N2200|(2.1 ± 0.2) × 10<sup>−3</sup>|(2.5 ± 0.3) ×  10<sup>−3</sup>|(1.5 ± 0.2) × 10<sup>−3</sup>|
|f-BTI2TEG-FT|1.4 ± 0.1|25.1 ± 0.6|38.4 ± 2.2/74.3 ± 4.6<br>(off-centre)/104.0 ± 7.9<br>(off-centre, +PBTI<br>blend)<sup>a</sup>|



_T_ ann = 120 °C; _t_ ann = 10 min (without nanoparticles, or 2 h for N2200), 10 s (with nanoparticles). Electric conductivies are given as average with standard deviations. For additional experimental conditions and semiconductor/N-DMBI-H molar ratios used for blend doping and N-DMBI-H solution concentrations used for sequential doping, which vary with the polymer structure, see Supplementary Table 2. If not indicated, on-centre spin-coating was used. aBlend film of PBTI and f-BTI2TEG-FT with an optimized weight ratio of 15%:85% in the sample. Note, in control experiments we demonstrated that AuNPs in the channel do not contribute to enhanced electrical conductivity of the catalysed/doped devices through formation of a metallic percolation network (see Supplementary Fig. 7 and Discussion). 

changed from cyan to pink after n-doping for a short _t_ ann = 10 s at 120 °C. ESR analysis of catalysed doped N2200 revealed a remarkable _η_ of ~40–75% and a high charge density of ~0.3–3 × 10<sup>20</sup> cm<sup>−3</sup> (~0.04–0.4 charge per repeat unit) at 5–100 mol% N-DMBI-H loading (Fig. 3d, Supplementary Fig. 11a–c). Similar high doping efficiencies (~60–70%) were measured in NDI-EH and PDI-C6C7, with high charge densities of ~1 × 10<sup>20</sup> –6 × 10<sup>20</sup> cm<sup>−3</sup> (20–100 mol% N-DMBI-H, Supplementary Fig. 11d–i). Despite successful heavy n-doping of N2200, its _σ_ decreases significantly to <10<sup>−7</sup> S cm<sup>−1</sup> at 100 mol% loading of N-DMBI-H. The same phenomenon was observed for N2200 doped with tetrakis(dimethylamino)ethylene (TDAE) vapours<sup>40</sup> , indicating an intrinsic limitation of this polymer to achieve high _σ_ . This result is attributed to the N2200 twisted backbone suppressing polaron delocalization<sup>40,41</sup> and non-optimal doped film morphology disrupting ordering, as assessed here for the catalysed process by atomic force microscopy (AFM) and grazing-incidence wide-angle X-ray scattering (GIWAXS) measurements (Extended Data Fig. 4, Supplementary Figs. 12 and 13, Supplementary Table 4). As charge transport in planar/ rigidified polymer semiconductors is more resilient to structural disorder<sup>42</sup> , the backbone design and film structural difference rationalize the N2200 versus thiazole imide-based polymer responses upon doping. 

### **Generality of TM catalyst selection** 

To understand whether Au is unique, we studied group 10/11 TM elements as catalysts using optical absorption spectra of N-DMBI-H doped semiconductor films (Fig. 3e–g). Doped films generally show bleached charge transfer/π–π* absorption peaks with the appearance of sub-bandgap polaronic transitions for polymers and radical-anion absorption for small molecules. Under similar doping conditions it is expected that increasing TM catalytic activity will enhance polaron or radical-anion absorption as a result of higher doping level<sup>4</sup> while weakening the charge transfer/π–π* absorption. For thiazole imide-based polymers, the catalytic activity of the TM elements is Pt, Au, Pd > Ag >> Cu, Ni (Fig. 3e, Supplementary Fig. 14). Similar catalytic activity trends are observed for N2200, NDI-EH and PDI-C6C7 (Fig. 3f, g, Supplementary Figs. 15 and 16), offering broad options for selecting the catalyst. 

We also expanded applicability and demonstrated all-solution processed blend/sequential n-doping (Supplementary Fig. 17) using a common soluble organometallic complex, tris(dibenzylideneacetone) dipalladium(0) (Pd2(dba)3). Optical absorption (Fig. 3h) and electrical conductivity (Supplementary Fig. 43) measurements demonstrate blend and sequentially doped f-BTI2TEG-FT with large _σ_ values of 19.2 ± 0.5 S cm<sup>−1</sup> and 37.1 ± 2.1 S cm<sup>−1</sup> , respectively. The reaction mechanism, which is likely to be more complex than that for AuNPs (vide infra), should involve both Pd2(dba)3-derived species and Pd nanoparticles, as it is known that Pd(0) complexes can efficiently catalyse C–H breakage<sup>43</sup> and Pd metal clusters/nanoparticles are already present in, or form from, Pd2(dba)3 (ref.<sup>44</sup> ). 

### **PDI + N-DMBI-H reaction mechanism** 

A catalyst should increase the reaction rate without altering the product distribution and remain chemically unchanged after the reaction is completed. To demonstrate catalysis, we investigated the small molecule PDI-C6C7 primarily for convenience in identifying products, managing computation time, and direct comparison with the literature. First, we recall that the ultraviolet–visible–near-infrared (UV–vis–NIR) spectra of the doped PDI-C6C7 and other semiconductor samples, with or without AuNPs, are identical, demonstrating that both reactions afford the same product (for example, see Supplementary Fig. 18). As reported above, all AuNP-catalysed solid-state reactions using N-DMBI-H, including that of PDI-C6C7, are very fast (nominally ~10 s) at 120 °C (for example, Fig. 2f). Remarkably, close inspection of the doping process indicates that it starts as soon as the semiconductor + dopant solution contacts the AuNP film maintained at 25 °C (Supplementary Video 1) and, when using 10 molar eq. of N-DMBI-H, it is almost completed during film casting even before thermal annealing (Fig. 4a and Supplementary Fig. 19). Furthermore, we note that thicker films afford the same degree of bulk doping, as assessed by the linear increase in the solid-state PDI-C6C7 radical anion absorbance with thickness (Supplementary Fig. 20). This is probably the result of the fast catalysed process evidenced in Supplementary Video 1, with completion of the reaction upon film annealing having residual solvent, which facilitates neutral/cationic dopant movement and cascade electron transfer from the bottom to the top film as seen in redox chemistry of organic semiconductor films on metal electrodes<sup>45</sup> . Thus, we cannot use the solid-state reaction to quantify kinetic parameters and instead followed the same reaction with or without AuNPs in solution ( _T_ = 25 °C). As shown in Fig. 4b, c and Supplementary Fig. 21, while N-DMBI-H and PDI-C6C7 do not react appreciably without catalyst, AuNP can efficiently catalyse the reaction, resulting in a rate constant ( _k_ w/AuNP) of 478 M<sup>−1</sup> min<sup>−1</sup> . Our data agree with the slow uncatalysed reaction between N-DMBI-H and a PDI molecule ( _k_ w/oAuNP < 0.01 M<sup>−1</sup> min<sup>−1</sup> ) reported in the literature<sup>26</sup> . Optical absorption and electrospray ionization mass spectrometry (ESI-MS) measurements of the solution reaction confirm the generation of N-DMBI<sup>+</sup> and PDI-C6C7•− as the main products (Supplementary Figs. 21 and 22), similarly to the thin-film data (Fig. 3c and Supplementary Fig. 19), while gas chromatography (GC) and<sup>1</sup> H-NMR evidence H2 evolution (Fig. 4d, Supplementary Figs. 23 and 24). Importantly, quenching the with/ without AuNP doped PDI-C6C7 (and doped PDTzTl as a polymer representative) solution and film samples by ambient exposure regenerates the neutral semiconductor without any appreciable by-products (Supplementary Figs. 25–28), further demonstrating that in both reactions the charged PDI species are radical anions and not hydride addition/ decomposition products. AuNP catalytic effect is also demonstrated for another reaction where heterolytic C–H bond cleavage/hydride transfer occurs, specifically using triaminomethane (TAM)<sup>18</sup> and the hydride acceptor trimethyloxy tritylium [(MeO)3Tr<sup>+</sup> ] ( _k_ w/AuNP = 7,180 M<sup>−1</sup> min<sup>−1</sup> , _k_ w/oAuNP = 424 M<sup>−1</sup> min<sup>−1</sup> ; Supplementary Fig. 29). Note that the AuNP catalytic effect in solid-state and in solution is retained to a large extent after being recycled (Supplementary Figs. 29 and 30). Interestingly, 

**70** | Nature | Vol 599 | 4 November 2021 



<!-- Start of picture text -->
a b c d<br>w/ AuNP  w/o AuNP 100<br>10 6 0.4 N2200 0.5 PDI-C6C7 N2200<br>10 1 50<br>10 0 ratio 10 5 0.3 0.4 100<br>NDI-EH<br>10 –1 0.3<br>10 4 0.2 50<br>10 –2<br>0.2<br>100<br>10 –3 10 3 0.1 0.1 PDI-C6C7<br>10 –4 50<br>10 –5 10 2 0 1 2 3 4 0 1 2 3 4 0<br>0 20 40 60 80 100<br>Photon energy (eV) Photon energy (eV)<br>Dopant molar ratio (mol%)<br>Pristine film Blend doped w/o AuNP Blend doped w/ AuNP<br>e f g h<br>1.5 1.5<br>PBTzI   PDTzTIT-2F N2200 0.5 PDI-C6C7 at 718 nm 0.4 f-BTI2TEG-FT, sequential<br>PDTzTI PDTzTIT NDI-EH at 478 nm Pristine<br>0.4 w/o<br>1.0 1.0 0.3<br>AuNP<br>0.3 Pd2(dba)3<br>0.2<br>0.5 0.5 0.2<br>0.1<br>0.1<br>0 0 0 0<br>Ni Cu Ag Au Pd Pt Ni Cu Ag Au Pd Pt Ni Cu Ag Au Pd Pt 1 2 3 4<br>Catalyst Catalyst Catalyst Photon energy (eV)<br>PBTzIPDTzTITPDTzTIT-2F PDTzTI<br>Absorbance<br>Absorbance<br>Conductivity improvement Doping effieciency (%)<br>–1Electrical conductivity (S cm)<br>Absorbance<br>Polaron/* peak ratioππ– Polaron/CT peak ratio Absorbance increase<br><!-- End of picture text -->

**Fig. 3 | The generality of metal-catalysed N-DMBI-H doping method. a** , Electrical conductivity for N-DMBI-H blend doped thiazole imide-based polymers using AuNP (see Supplementary Fig. 10 for detail). **b** , **c** , The UV–vis– NIR spectra of N2200 ( **b** ), PDI-C6C7 ( **c** ) films as representative of naphthalene diimide (NDI) or perylene diimide (PDI)-based organic semiconductors. They consist of pristine films (red), 100mol% N-DMBI-H blend doped films without catalyst (cyan) and with AuNPs (blue), with their photographs (inset) displayed in the same order. **d** , Doping efficiency of N2200, NDI-EH and PDI-C6C7 with AuNPs determined by ESR, with 20% uncertainty as shown by the error bars. **e** – **g** , Relative catalytic activity of different TM nanoparticles for thiazole imide-based polymers ( **e** ), N2200 ( **f** ), NDI-EH and PDI-C6C7 small molecules ( **g** ). 

They are determined from the polaron/π–π* or polaron/charge transfer (CT) absorption peak ratio for the polymers, and from the anion absorption peak increase for the small molecules. The corresponding peak positions are given in Supplementary Table 5. **h** , UV–vis–NIR spectra of sequentially doped f-BTI2TEG-FT films, including pristine (red), doped without the catalyst (cyan), with AuNP catalyst (blue) and with solution-processable organometallic Pd2(dba)3 catalyst (purple). The N-DMBI-H concentration is 5 mg ml<sup>−1</sup> and the Pd2(dba)3 concentration is 1 mol% of N-DMBI-H (~0.18 mM). In all experiments, _d_ ≈ 1.4–2.3 nm at 0.1 nm nominal evaporation thickness, _T_ ann = 120 °C, _t_ ann = 10 s, and the substrate is glass. For the ESR experiment, the substrate is PET. 

significant reaction rate enhancement is also observed for the reaction of PDI-C6C7 with TAM ( _k_ w/AuNP = 398 M<sup>−1</sup> min<sup>−1</sup> , _k_ w/oAuNP < 0.01 M<sup>−1</sup> min<sup>−1</sup> ; Supplementary Fig. 31), further demonstrating generality to another dopant. 

Based on our own and previous experimental and theoretical studies involving N-DMBI-H doping<sup>23,26</sup> , density functional theory (DFT) calculations were performed to model the reaction between N-DMBI-H and PDI-C6C7 (equation (1)) with and without AuNPs. 



<!-- Start of picture text -->
N −DMBI −H + PDI −C6C7 →N −DMBI+ + PDI −C6C7⋅− + 1/2H2 (1)<br><!-- End of picture text -->

Note, PDI-C6C7 is modelled by a simpler PDI in which methyl replaces the 1-hexylheptyl group. Several routes have been proposed for this reaction and we explored them by DFT; however, as seen for uncatalysed doping reactions in the literature<sup>23,26</sup> , our data indicate that in the presence of AuNPs, heterolytic cleavage of the N-DMBI-H (C–H → C<sup>+</sup> + H<sup>−</sup> ) bond is energetically more favourable than of the homolytic one (C–H → C<sup>•</sup> + H<sup>•</sup> ) (–12.3 versus +28.7 kcal mol<sup>−1</sup> , respectively; Supplementary Fig. 32). Thus, among the possible paths (routes a–d in Extended Data Figs. 5 and 6), Fig. 4e reports a plausible reaction mechanism for the AuNP-catalysed process for PDI-C6C7 (route a in Extended Data Figs. 5 and 6) and Fig. 4f reports its associated Gibbs free energy profile compared with the uncatalysed reaction. The most stable route without AuNPs (cyan line, Fig. 4f and Supplementary Fig. 33) consists in a first step where hydride transfer occurs from the dopant to PDI. This process leads to the formation of N-DMBI<sup>+</sup> and PDI-H<sup>−</sup> and requires 

19.7 kcal mol<sup>−1</sup> . Next, PDI–H<sup>–</sup> transfers an electron to another PDI forming PDI–H<sup>•</sup> , then two PDI–H<sup>•</sup> combine affording H2 while PDI is regenerated for the next reaction cycle. Hydride transfer from N-DMBI-H to PDI (first step) is the rate-determining step. With AuNPs (orange line, Fig. 4f), hydride transfer occurs between N-DMBI-H and the AuNP surface to form an ion pair adduct (N-DMBI<sup>+</sup> /AuH<sup>−</sup> ). This step is barrierless and highly exergonic (−12.3 kcal mol<sup>−1</sup> ). Next, when PDI contacts AuH<sup>−</sup> it is reduced to PDI<sup>•−</sup> while N-DMBI<sup>+</sup> is released, leaving radical Au–H<sup>•</sup> species on the surface. Finally, two H<sup>•</sup> on gold combine to form H2, which, upon escape, restores the Au surface. This H2 release step is rapid and exergonic, with a computed overall activation energy (10.1 kcal mol<sup>−1</sup> ) far lower than that of the uncatalysed route (18.2 kcal mol<sup>−1</sup> ; Fig. 4f). The main difference between the two paths is the hydride transfer step, with that from N-DMBI-H to PDI requiring a 19.7 kcal mol<sup>−1</sup> energy barrier whereas it is barrierless when catalysed by AuNP. 

### **Catalysed n-doping of devices** 

The technological impact of this method was demonstrated for improving the performance of several (opto)electronic devices (Extended Data Figs. 7–9). Thus, using the catalysed n-doped f-BTI2TEG-FT + PBTI blend (see Table 1, Extended Data Fig. 7, Supplementary Figs. 34–45, Supplementary Scheme 1 and Supplementary Table 6 for discussion), we fabricated an organic thermoelectric device exhibiting one of the largest power factors (65.7 ± 5.5 μW m<sup>−1</sup> K<sup>−2</sup> ) to date<sup>12,46</sup> . Furthermore, using the doped NDI-based polymer P and cyanated perylene diimide 

Nature | Vol 599 | 4 November 2021 | **71** 

## Article 



<!-- Start of picture text -->
a As-cast film,  T  = 25 °C d 2 PDI-C6C7 + 1 eq. N-DMBI-H + AuNP<br>4 PDI-C6C7 + N-DMBI-H (10 eq.) H2<br>PDI-C6C7 + N-DMBI-H (10 eq.) + AuNP 1<br>3 718 nm H2 In situ reaction<br>Gas phase<br>0<br>2 5.0 4.8 4.6 4.4 4.2 4.0<br>Chemical shift (ppm)<br>1<br>N H<br>e N N-DMBI-H<br>0 H H N<br>400 600 800 1,000 N<br>Wavelength (nm) eliminationHydrogen Au transferHydride N+ N<br>N-DMBI +<br>b<br>5<br>4 In CH2PDI-CCl2,  T 6 = 25 °C, stirred for 17 minC7 + N-DMBI-H (10 eq.) O O H HAu H Au O O<br>PDI-C6C7 + N-DMBI-H (10 eq.) + AuNP R N N R Gold nanoparticle R N N R<br>3 O PDI Single electrontransferO catalysed n-doping electrontransferSingle O R = 1-hexylheptyl PDI-C6C7 (PDI) O<br>2 O O O O<br>1 R N N R H Au H Au R N N R<br>H<br>O O O O<br>0 PDI-C6C7 (PDI) Hydride PDI<br>transfer<br>400 600 800 1,000 N N H<br>Wavelength (nm) N+ N N N<br>N-DMBI + N-DMBI-H<br>f 40<br>c<br>In CH2Cl2,  T  = 25 °C<br>0.6 PDI-C6C7 + N-DMBI-H (10 eq.) [N-DMBI···H··PDI] ‡ w/ AuNP<br>PDI-C6C7 + N-DMBI-H (10 eq.) + AuNP 20 19.7 w/o AuNP<br>N-DMBI +<br>0.4 + N-DMBI-HPDI  19.7 H • PDI½ [PDI··H··H··PDI] •– 6.3 ‡<br>0.2 0 Au (111) 0.00.0 N-DMBIPDIPDI •–+ Au (111) –6.0 PDI 10.1 –2.2 ½ H½ H22<br>PDI<br>N-DMBI-H –12.3 –11.9 H H ‡ –19.6<br>0.0 -20 N-DMBI + H – [PDI-H] – ½  Au (111) –19.6<br>0 2 4 6 8 10 12 14 16 Au (111) Au (111)<br>Time (min)<br>-40<br>Intensity (a.u.)<br>Absorbance<br>Absorbance<br>Absorbance at 715 nm<br>–1Gibbs free energy change (kcal mol)<br><!-- End of picture text -->

**Fig. 4 | AuNP-catalysed N-DMBI-H doping mechanism. a** , UV–vis–NIR spectra of as-cast N-DMBI-H (10 eq.) blend doped PDI-C6C7 films without and with AuNPs without thermal annealing. Blend solution shows immediate colour change upon contacting the AuNPs, as illustrated in the Supplementary Video 1. **b** , UV–vis–NIR spectra at 25 °C of 10 eq. N-DMBI-H doped PDI-C6C7 solutions (initial PDI-C6C7 concentration, 41.4 μM) without and with AuNPs after 17 min. **c** , The N-DMBI-H + PDI-C6C7 doping reaction kinetics at 25 °C in solution 

without and with AuNPs, by monitoring the temporal evolution of PDI-C6C7•− absorbance at 715 nm. **d** ,<sup>1</sup> H-NMR spectra of the AuNP-catalysed N-DMBI-H doping of PDI-C6C7 analysing both in situ (top) and ex situ (bottom) gas phase product formation evidencing H2 signals. **e** , **f** , Proposed catalytic cycle for the Au-catalysed N-DMBI-H doping reaction of PDI-C6C7 ( **e** ) and DFT calculated Gibbs free energy change ( **f** ) for the same reaction with and without Au. 

molecule PDIR-CN2 (OSC) as a semiconductor, we demonstrated greatly improved electron injection in n-type thin-film transistors using different metal contacts (Au and Ag) and catalysts (Au and Pd2(dba)3) (Extended Data Fig. 8, Supplementary Fig. 46). Finally, we demonstrated that n-doped PDTzTIT can also improve the performance of perovskite solar cells (power conversion efficiency, PCE, of ~19%) using Ag as electron extraction contact versus the undoped polymer-based cells (PCE ~9%) (Extended Data Fig. 9, Supplementary Table 7). 

identical reaction products to the uncatalysed reactions as assessed experimentally. We demonstrated applicability to organic thermoelectrics, thin-film transistors, and perovskite solar cell devices that require high charge carrier density and/or efficient electron injection/ transport<sup>10,12,47–49</sup> . Thus, this concept is not only potentially applicable to existing n-dopant libraries, but also can be used to expand the design space of ‘ideal’ n-dopants with enhanced air stability and reducing ability. 

### **Concluding remarks** 

A novel metal-catalysed n-doping concept of organic semiconductors has been demonstrated to achieve rapid, highly efficient and heavily n-doped π-conjugated polymers and small molecules. The use of TM catalysts promotes the reactivity of the dopant precursor by facilitating C–H bond cleavage, as assessed by DFT computations, and affords 

### **Online content** 

Any methods, additional references, Nature Research reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41586-021-03942-0. 

**72** | Nature | Vol 599 | 4 November 2021 

1. Lüssem, B., Riede, M. & Leo, K. Doping of organic semiconductors. _Phys. Status Solidi A_ **210** , 9–43 (2013). 

2. Kang, K. et al. 2D coherent charge transport in highly ordered conducting polymers doped by solid state diffusion. _Nat. Mater._ **15** , 896–902 (2016). 

3. Kiefer, D. et al. Double doping of conjugated polymers with monomer molecular dopants. _Nat. Mater._ **18** , 149–155 (2019). 

4. Yamashita, Y. et al. Efficient molecular doping of polymeric semiconductors driven by anion exchange. _Nature_ **572** , 634–638 (2019). 

5. Wei, P., Oh, J. H., Dong, G. & Bao, Z. Use of a 1H-benzoimidazole derivative as an n-type dopant and to enable air-stable solution-processed n-channel organic thin-film transistors. _J. Am. Chem. Soc._ **132** , 8852–8853 (2010). 

6. Lin, X. et al. Beating the thermodynamic limit with photo-activation of n-doping in organic semiconductors. _Nat. Mater._ **16** , 1209–1215 (2017). 

7. Tang, C. G. et al. Doped polymer semiconductors with ultrahigh and ultralow work functions for ohmic contacts. _Nature_ **539** , 536–540 (2016). 

8. Tang, C. G. et al. Multivalent anions as universal latent electron donors. _Nature_ **573** , 519–525 (2019). 

9. Gruessing, A. et al. Use of heterocyclic radicals for doping of organic semiconductors. _EP patent_ EP06005834A (2006). 

10. Lüssem, B. et al. Doped organic transistors. _Chem. Rev._ **116** , 13714–13751 (2016). 11. Guo, S. et al. N-doping of organic electronic materials using air-stable organometallics. _Adv. Mater._ **24** , 699–703 (2012). 

12. Sun, Y., Di, C.-A., Xu, W. & Zhu, D. Advances in n-type organic thermoelectric materials and devices. _Adv. Electron. Mater._ **5** , 1800825 (2019). 

13. Russ, B. et al. Organic thermoelectric materials for energy harvesting and temperature control. _Nat. Rev. Mater._ **1** , 16050 (2016). 

14. Wei, P. et al. Tuning the Dirac point in CVD-grown graphene through solution processed n-type doping with 2-(2-methoxyphenyl)-1,3-dimethyl-2,3-dihydro-1H-benzoimidazole. _Nano Lett._ **13** , 1890–1897 (2013). 

15. Li, F. H. et al. Leuco crystal violet as a dopant for n-doping of organic thin films of fullerene C60. _J. Phys. Chem. B_ **108** , 17076–17082 (2004). 

16. Chan, C. K., Kim, E. G., Brédas, J. L. & Kahn, A. Molecular n-type doping of 1,4,5,8-naphthalene tetracarboxylic dianhydride by pyronin B studied using direct and inverse photoelectron spectroscopies. _Adv. Funct. Mater._ **16** , 831–837 (2006). 

17. Shi, K. et al. A novel solution-processable n-dopant based on 1,4-dihydropyridine motif for high electrical conductivity of organic semiconductors. _Adv. Electron. Mater._ **3** , 1700164 (2017). 

18. Yang, C.-Y. et al. A thermally activated and highly miscible dopant for n-type organic thermoelectrics. _Nat. Commun._ **11** , 3292 (2020). 

19. Naab, B. D. et al. Effective solution- and vacuum-processed n-doping by dimers of benzimidazoline radicals. _Adv. Mater._ **26** , 4268–4272 (2014). 

20. Un, H.-I. et al. Understanding the effects of molecular dopant on n-type organic thermoelectric properties. _Adv. Energy Mater._ **9** , 1900817 (2019). 

21. Guha, S., Goodson, F. S., Corson, L. J. & Saha, S. Boundaries of anion/naphthalenediimide interactions: from anion-π interactions to anion-induced charge-transfer and electron-transfer phenomena. _J. Am. Chem. Soc._ **134** , 13679–13691 (2012). 

22. Li, C.-Z. et al. Doping of fullerenes via anion-induced electron transfer and its implication for surfactant facilitated high performance polymer solar cells. _Adv. Mater._ **25** , 4425– 4430 (2013). 

23. Naab, B. D. et al. Mechanistic study on the solution-phase n-doping of 1,3-dimethyl-2aryl-2,3-dihydro-1H-benzoimidazole derivatives. _J. Am. Chem. Soc._ **135** , 15018–15025 (2013). 

24. Guo, S. et al. N-doping of organic electronic materials using air-stable organometallics: A mechanistic study of reduction by dimeric sandwich compounds. _Chem. Eur. J._ **18** , 14760–14772 (2012). 

25. Mohapatra, S. K. et al. Dimers of nineteen-electron sandwich compounds: crystal and electronic structures, and comparison of reducing strengths. _Chem. Eur. J._ **20** , 15385–15394 (2014). 

26. Jhulki, S. et al. Reactivity of an air-stable dihydrobenzoimidazole n-dopant with organic semiconductor molecules. _Chem_ **7** , 1050–1065 (2021). 

27. Daniel, M. C. & Astruc, D. Gold nanoparticles: assembly, supramolecular chemistry, quantum-size-related properties, and applications toward biology, catalysis, and nanotechnology. _Chem. Rev._ **104** , 293–346 (2004). 

28. Wang, D. & Astruc, D. The golden age of transfer hydrogenation. _Chem. Rev._ **115** , 6621–6686 (2015). 

29. Wang, H. et al. Tuning the threshold voltage of carbon nanotube transistors by n-type molecular doping for robust and flexible complementary circuits. _Proc. Natl Acad. Sci. USA_ **111** , 4776–4781 (2014). 

30. Tarasov, A. et al. Controlled doping of large-area trilayer MoS2 with molecular reductants and oxidants. _Adv. Mater._ **27** , 1175–1181 (2015). 

31. Jia, C.-J. & Schüth, F. Colloidal metal nanoparticles as a component of designed catalyst. _Phys. Chem. Chem. Phys._ **13** , 2457–2487 (2011). 

32. Shi, Y. et al. Thiazole imide-based all-acceptor homopolymer: achieving high-performance unipolar electron transport in organic thin-film transistors. _Adv. Mater._ **30** , 1705745 (2018). 

33. Tanaka, H., Nishio, S., Ito, H. & Kuroda, S.-I. Microscopic signature of insulator-to-metal transition in highly doped semicrystalline conducting polymers in ionic-liquid-gated transistors. _Appl. Phys. Lett._ **107** , 243302 (2015). 

34. Zuo, G. et al. Molecular doping and trap filling in organic semiconductor host–guest systems. _J. Phys. Chem. C_ **121** , 7767–7775 (2017). 

35. Maxwell, A. J. et al. Electronic and geometric structure of C60 on Al(111) and Al(110). _Phys. Rev. B_ **57** , 7312–7326 (1998). 

36. Scholes, D. T. et al. Overcoming film quality issues for conjugated polymers doped with F4TCNQ by solution sequential processing: Hall effect, structural, and optical measurements. _J. Phys. Chem. Lett._ **6** , 4786–4793 (2015). 

37. Shi, Y. et al. Imide-functionalized thiazole-based polymer semiconductors: Synthesis, structure-property correlations, charge carrier polarity, and thin-film transistor performance. _Chem. Mater._ **30** , 7988–8001 (2018). 

38. Yan, H. et al. A high-mobility electron-transporting polymer for printed transistors. _Nature_ **457** , 679–686 (2009). 

39. Schlitz, R. A. et al. Solubility-limited extrinsic n-type doping of a high electron mobility polymer for thermoelectric applications. _Adv. Mater._ **26** , 2825–2830 (2014). 

40. Wang, S. et al. Thermoelectric properties of solution-processed n-doped ladder-type conducting polymers. _Adv. Mater._ **28** , 10764–10771 (2016). 

41. Naab, B. D. et al. Role of polymer structure on the conductivity of n-doped polymers. _Adv. Electron. Mater._ **2** , 1600004 (2016). 

42. Fratini, S. et al. Charge transport in high-mobility conjugated polymers and molecular semiconductors. _Nat. Mater._ **19** , 491–502 (2020). 

43. Rousseaux, S., Gorelsky, S. I., Chung, B. K. W. & Fagnou, K. Investigation of the mechanism of C(sp<sup>3</sup> )–H bond cleavage in Pd(0)-catalyzed intramolecular alkane arylation adjacent to amides and sulfonamides. _J. Am. Chem. Soc._ **132** , 10692–10705 (2010). 

44. Zalesskiy, S. S. & Ananikov, V. P. Pd2(dba)3 as a precursor of soluble metal complexes and nanoparticles: Determination of palladium active species for catalysis and synthesis. _Organometallics_ **31** , 2302–2309 (2012). 

45. Lyons, M. E. G. _Electroactive Polymer Electrochemistry Part 1: Fundamentals_ Ch. 1, (Springer, 1994). 

46. Lu, Y. et al. Persistent conjugated backbone and disordered lamellar packing impart polymers with efficient n-doping and high conductivities. _Adv. Mater._ **33** , 2005946 (2021). 

47. Baeg, K.-J., Caironi, M. & Noh, Y.-Y. Toward printed integrated circuits based on unipolar or ambipolar polymer semiconductors. _Adv. Mater._ **25** , 4210–4244 (2013). 

48. Chueh, C.-C., Li, C.-Z. & Jen, A. K. Y. Recent progress and perspective in solution-processed interfacial materials for efficient and stable polymer and organometal perovskite solar cells. _Energy Environ. Sci._ **8** , 1160–1189 (2015). 

49. Walzer, K., Maennig, B., Pfeiffer, M. & Leo, K. Highly efficient organic devices based on electrically doped transport layers. _Chem. Rev._ **107** , 1233–1271 (2007). 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

© The Author(s), under exclusive licence to Springer Nature Limited 2021 

Nature | Vol 599 | 4 November 2021 | **73** 

## Article **Methods** 

#### **Materials** 

The thiazole imide-based polymers (PDTzTI, PDTzTIT-2F, PDTzTIT, PBTzI), f-BTI2-FT, PBTI and TAM dopant were synthesized as descri bed<sup>18,32,37,50,51</sup> . The N-DMBI-H dopant is from Sigma-Aldrich. Synthetic detail to new f-BTI2TEG-FT is included in the Supplementary Information (section G). N2200, N2200-EG7 (P) and PDIR-CN2 are from Flexterra Corp. High purity metals (99.95% or 99.999%) are from Beijing Dream Materials Technology Co., Ltd. The Pd2(dba)3 catalyst and anhydrous solvents are from Sigma-Aldrich and Acros Organics. All materials were used as received except for chloroform, which was distilled. 

#### **Metal nanoparticle fabrication and characterization** 

The metal nanoparticles were fabricated by thermal evaporation under high vacuum (<10<sup>−5</sup> mbar for Ni, Pd and Pt; <10<sup>−6</sup> mbar for Cu, Ag and Au) with an evaporation rate of ~0.1 Å s<sup>−1</sup> using an Angstrom Engineering Nexdep evaporator in a N2-filled glove box (O2, H2O <0.1 ppm). For TEM imaging, the nanoparticles were thermally evaporated onto TEM grid coated with a carbon film under the same conditions described above. The TEM images were collected on a FEI Tecnai F30 300 kV transmission electron microscope under bright field mode. 

#### **Film doping** 

**Blend doping.** The organic semiconductor, N-DMBI-H and Pd2(dba)3 catalyst were all dissolved in anhydrous CHCl3. A concentration of 5 mg ml<sup>−1</sup> was used for all polymers and Pd2(dba)3, 10 mg ml<sup>−1</sup> was used for NDI-EH, PDI-C6C7 and N-DMBI-H. For binary blend of semiconductor + N-DMBI-H, small amounts of the N-DMBI-H solution was added into the semiconductor solution to achieve the desired N-DMBI-H molar concentrations (from 5% to 100%) versus the semiconductor; similarly, for ternary blend of semiconductor + N-DMBI-H+Pd2(dba)3, small amounts of the N-DMBI-H and Pd2(dba)3 solutions were separately added into the semiconductor solution to achieve the desired molar ratios for N-DMBI-H and Pd2(dba)3 (typically ~1mol%). The blend solutions were spin-coated at room temperature on the selected substrate shortly after their preparation at 1,500 rpm for 15 s. Next, the film was annealed at the desired temperature for a given time. In typical experiments and unless indicated otherwise, the annealing temperature ( _T_ ann) is 120 °C for a time ( _t_ ann) of 10 s when using the catalyst, while _t_ ann = 10 min (or longer for N2200) when not using the catalyst. 

**Solution sequential doping.** The organic semiconductor and N-DMBI-H (or N-DMBI-H + catalyst when using Pd2(dba)3) solutions were spin-coated separately. A concentration of 5 mg ml<sup>−1</sup> was used for all polymers using the following solvents: CHCl3 (CF) for PDTzTI (on-centre sample), PDTzTIT-2F, PDTzTIT and f-BTI2TEG-FT (on-centre sample); chlorobenzene (CB) for PBTzI, f-BTI2-FT; CF or CF: _para_ -xylene (1:1) mixture for N2200; CB: _ortho_ -dichlorobenzene ( _o_ -DCB) (3:1) mixture was used for PDTzTI (off-centre sample); CF:CB (3:1) mixture for f-BTI2TEG-FT and f-BTI2TEG-FT+PBTI blend (off-centre samples for both). For on-centre samples, the polymer films were spin-coated from room temperature solutions at 1,500 rpm for 15 s (CF solvent) or 40 s (CB or CF: _para_ -xylene mixed solvent). For off-centre samples, they are spin-coated from room temperature solutions for f-BTI2TEG-FT, f-BTI2TEG-FT+PBTI blend, and warm solutions for PDTzTI (both substrate and solution pre-heated at 120 °C); the samples were placed at a distance of ~3 cm from the centre of the spin-coater and spin-coated at 1,500 rpm for 40 s. The off-centre spin-coated samples were thermally annealed at 160 °C for 10 min to increase its mobility. After semiconductor film deposition, the dopant solutions in _n_ -butyl acetate (nBA) (either N-DMBI-H at various concentrations (0.1–5 mg ml<sup>−1</sup> ) or N-DMBI-H (concentration, 5 mg ml<sup>−1</sup> )  + Pd2(dba)3 (1 mg ml<sup>−1</sup> )) were placed on the semiconductor films, allowed to sit on them for 10 s, and finally spin-coated at 5,000 rpm for 10 s. After N-DMBI-H (or 

N-DMBI-H+Pd2(dba)3) deposition, the films were annealed as described above for the blend doping method. For details of polymer thickness, see Supplementary Table 2. 

**TDAE vapour doping.** PDTzTI films were spin-coated from CHCl3 (5 mg ml<sup>−1</sup> ) at 1,500 rpm for 15 s, then they were placed inside a sealed glass bottle containing ~1 ml of TDAE and doped by its saturated vapour at room temperature for the desired time (2–96 h). All solution preparation, film spin-coating and thermal annealing steps were carried out in a N2-filled glovebox. 

#### **Electrical measurements** 

Borosilicate glass (1.1 mm thick) or polyethylene terephthalate (PET) (125 μm thick) substrates were cleaned by acetone/isopropanol sonication wash, then dried with N2 before use. Unless otherwise indicated, 30-nm Au or 30-nm Al was thermally evaporated as bottom-contact electrodes (two-probe geometry) for devices with and without using catalysts, respectively. Channel length ( _L_ ) and width ( _W_ ) are 100 μm and 2 mm, respectively. For devices with AuNP catalyst, 0.1-nm Au (nominal thickness) was thermally evaporated prior to electrode deposition. Keithley 4200-SCS Semiconductor Characterization System was used to measure the _I_ – _V_ curves of the devices inside a N2-filled glovebox, while their electrical conductivity was calculated from the standard equation _σ_ = (1/ _R_ ) × [ _L_ /( _W_ × _h_ )], where _R_ is the device resistance and _h_ is the film thickness measured by a Tencor KLA D-120 profilometer or by AFM. The reported electrical conductivity results are from the average of five or more devices. 

#### **UV−vis−NIR** 

The thin films were prepared on borosilicate glass substrates and then loaded into tightly sealed glass cuvettes to avoid exposure to ambient atmosphere. The optical absorption spectra were collected on a Shimadzu UV-3600 UV–VIS–NIR spectrometer. 

#### **ESR** 

The thin films were prepared on PET substrates and cut into 3 mm by 12 mm in size, and then loaded into tightly sealed quartz ESR tubes. The measurement was performed on an X-band (9.84 GHz) Burker EMXplus-10 spectrometer, using a microwave power of 2 mW, a magnetic field modulation magnitude of 2 gauss and modulation frequency of 100 kHz, respectively. The spin-counting was done with Burker software following standard procedures. The error in the spin density is taken to be 20% to account for the uncertainty in spin counting and any other error sources. 

#### **Metal–insulator–semiconductor diode** 

The metal–insulator–semiconductor (MIS) diode structure was p-doped silicon ( _ρ_ < 0.05 Ω cm)/200-nm SiO2/doped polymer film/50-nm Al with a device area of 20 mm<sup>2</sup> . A Keysight E4990A impedance analyser was used to measure their capacitance–voltage ( _C_ – _V_ ) responses in a N2-filled glovebox. During measurement, the devices were biased from depletion to accumulation by applying a d.c. voltage from +40 to −40 V and a small a.c. voltage of 0.1 V at 1 kHz. The charge concentration ( _n_ ) was calculated from the Mott–Schottky analysis equation d(1/ _C_<sup>2</sup> )/d _V_ = [2/( _e_ × _ε_ 0 × _ε_ r)]  ×  (1/ _n_ ), where _C_ is the diode capacitance per unit area, _e_ is the elementary charge, _ε_ 0 is the vacuum permittivity, and _ε_ r ≈ 3 is used as the approximate dielectric constant value for PDTzTI during calculations. The errors in MIS analysis are from three devices. 

#### **AFM** 

The thin film samples were prepared on borosilicate glass and were characterized in ambient air using a Dimension Icon Scanning Probe Microscope (Asylum Research, MFP-3D-Stand Alone) under tapping mode. 

#### **GIWAXS** 

The thin films were prepared on silicon substrates and measurements were performed at the Beamline PLS-II 9A SAXS of Pohang Accelerator Laboratory, Republic of Korea. 

#### **GC** 

One eq. N-DMBI-H (17.7 mg, 66.2 μmol) + PDI-C6C7 (50.0 mg, 66.2 μmol) blend solution in 1 ml anhydrous CH2Cl2 was reacted for 1 h with AuNPs (nominal evaporation thickness 1.2 nm on glass) in a sealed bottle (4 ml) under nitrogen. The gas product was collected with a 5-ml syringe and then characterized on Agilent 990 Micro GC system using thermal conductivity detector. To eliminate the influence of possible residual H2 gas in the instrument pipeline, an air blank sample test was taken before each injection. 

#### **DFT calculation** 

DFT-based simulations were performed with the CP2K/Quickstep package, using a hybrid Gaussian and plane wave method<sup>52</sup> . A double quality DZVP Gaussian basis set was used for the Au atoms and a triple quality TZVP Gaussian basis set was used for all the other atoms<sup>53</sup> . The Goedecker–Teter–Hutter pseudopotentials<sup>54</sup> together with a 400 Ry plane wave cut-off were used to expand the densities obtained with the Perdew– Burke–Ernzerhof (PBE)<sup>55</sup> exchange-correlation density functional, and van der Waals forces were taken in account with the Grimme D3 Method<sup>56</sup> . 

**Surface model.** Gold nanoparticles were modelled by a gold (111) surface. It was constructed using a slab model having three Au layers with a 17.31 Å × 14.99 Å surface unit cell (108 Au atoms). A 35 Å vacuum region between the slabs was adopted to minimize unrealistic slab interactions. Only the gamma point was considered in a supercell approach. Periodic boundary conditions were applied in all directions of space. 

**Gibbs free energy profile.** Potential energy as obtained by the self-consistent field (SCF) procedure at zero kelvin is adopted as an approximation of the enthalpy contributions. Entropic contributions associated to the loss of mobility of the molecular species once adsorbed on the gold surface were evaluated. In particular, only the loss of translational and rotational entropy was considered and computed at 298.15 K. Solvation contribution to the energy profile was evaluated within the solvation model based on density (SMD) approach only for molecular species using dichloromethane ( _ε_ = 8.93) as prototypical solvent as implemented in the G16 code<sup>57</sup> . G16 calculations were performed at the level of the B3LYP hybrid functional. The standard all-electron 6-311G** basis set was used for all atoms. The entropic and solvent contributions were then ‘appended’ to the SCF energy profile to obtain the Gibbs free energy profile. 

#### **ESI-MS** 

NDI-EH and PDI-C6C7 were blended with 100mol% of N-DMBI-H in anhydrous chloroform, then drop-casted onto glass substrates with pre-deposited gold nanoparticles ( _d_ = 1.4 nm). After doping activation by thermal annealing, the samples were rinsed in anhydrous CF solvent inside a small glass bottle to wash off the doped films. The doped NDI-EH and PDI-C6C7 solutions were further diluted to a concentration below 0.1 mg ml<sup>−1</sup> before data collection using a Thermo Scientific LCQ Fleet system under ESI mode. 

#### **Seebeck coefficient** 

The doped films were prepared on borosilicate glass substrates in the same way as those for electrical conductivity measurement. The samples for Seebeck coefficient measurement had a channel length of 1 mm, channel width of 20 mm and electrode width of 500 μm. A pair of Peltier devices with a separation distance of 1 mm were used to generate a temperature difference (Δ _T_ ) across the samples, which were monitored by a pair of thermal couples. By systematically changing Δ _T_ 

from 0 to 3.5 K with 0.7 K step, the corresponding thermal voltages were recorded by the Keithley 4200-SCS Semiconductor Characterization System and then used for Seebeck coefficient calculation through linear fitting of the data. The reported Seebeck coefficient results were all from the average of three different measurements. 

#### **Organic thin-film transistors** 

Top-gate bottom-contact organic thin-film transistors (OTFTs) with different metal source and drain electrode materials (Au and Ag) were fabricated on glass substrates. The substrates were coated with a planarization layer prepared by spin-coating a solution of Flexterra crosslinkable polymer B2000 in dioxane (110 mg ml<sup>−1</sup> ; 1,500–2,000 rpm) onto the substrates to afford a ~300–500-nm-thick layer. This film was crosslinked thermally (180 °C, 60 min) to afford a robust, completely insoluble planarization layer. Next, the metal source/drain electrical contacts (100 nm thick) were prepared by sputtering (Ag) or thermal vapour deposition (Au) followed by photolithography. Channel length and width are 15 μm and 1 mm, respectively. Doped polymer contact modification formulations (for Au contacts, N2200-EG7 0.35 mg + N-DMBI-H 0.7 mg in 1 ml CHCl3; for Ag contacts, N2200-EG7 0.35 mg + N-DMBI-H 0.7 mg + Pd2(dba)3 0.12 mg (5mol%) in 1 ml CHCl3) were deposited by spin-coating at 1,000 rpm for 60 s and then annealed on a hotplate at 160 °C for 5 min. The n-type semiconductor PDIR-CN2 layer was then deposited by spin coating (N3004 2.5 mg ml<sup>−1</sup> in a hydrocarbon mixture, 2,000 rpm, 30 s, film dried on a hotplate at ~110 °C for 5 min). Typical semiconductor film thicknesses were ~20 nm. Next, the dielectric layer (~600 nm thick) was spin-coated (D1600, ~100 mg ml<sup>−1</sup> , 700–2,000 rpm) and the transistors were completed by deposition of the metal gate contact (100 nm Ag or Au) by thermal evaporation through a shadow mask. 

### **Data availability** 

All relevant data are contained within the Article and its Supplementary Information, or are available from the corresponding authors upon request. 

50. Shi, Y. et al. Distannylated bithiophene imide: enabling high-performance n-type polymer semiconductors with an acceptor-acceptor backbone. _Angew. Chem. Int. Ed._ **59** , 14449–14457 (2020). 

51. Wang, Y. et al. Effects of bithiophene imide fusion on the device performance of organic thin-film transistors and all-polymer solar cells. _Angew. Chem. Int. Ed._ **56** , 15304–15308 (2017). 

52. Küehne, T. D. et al. CP2K: an electronic structure and molecular dynamics software package - quickstep: efficient and accurate electronic structure calculations. _J. Chem. Phys._ **152** , 194103 (2020). 

53. VandeVondele, J. & Hutter, J. Gaussian basis sets for accurate calculations on molecular systems in gas and condensed phases. _J. Chem. Phys._ **127** , 114105 (2007). 

54. Goedecker, S., Teter, M. & Hutter, J. Separable dual-space gaussian pseudopotentials. _Phys. Rev. B_ **54** , 1703–1710 (1996). 

55. Perdew, J. P., Burke, K. & Ernzerhof, M. Generalized gradient approximation made simple. _Phys. Rev. Lett._ **77** , 3865–3868 (1996). 

56. Grimme, S., Antony, J., Ehrlich, S. & Krieg, H. A consistent and accurate ab initio parametrization of density functional dispersion correction (DFT-D) for the 94 elements H-Pu. _J. Chem. Phys._ **132** , 154104 (2010). 

57. Frisch, M. J. et al. Gaussian 16 rev. B.01 (Gaussian Inc., Wallingford, CT, 2016). 58. Liu, J. et al. Overcoming coulomb interaction improves free-charge generation and thermoelectric properties for n-doped conjugated polymers. _ACS Energy Lett._ **4** , 1556–1564 (2019). 

59. Kiefer, D. et al. Enhanced n-doping efficiency of a naphthalenediimide-based copolymer through polar side chains for organic thermoelectrics. _ACS Energy Lett._ **3** , 278–285 (2018). 

**Acknowledgements** H.G. and X.G. gratefully acknowledge financial support from the National Natural Science Foundation of China (51903117 and 21774055) and the Shenzhen Science and Technology Innovation Commission (JCYJ20180504165709042). A.F. acknowledges AFOSR grant FA9550-18-1-0320. S.F. and C.-Y.Y. acknowledge financial support from the Swedish Research Council (2020-03243), Olle Engkvists Stiftelse (204-0256), VINNOVA (2020-05223),Swedish Government Strategic Research Area in Materials Science on Functional Materials at Linköping University (Faculty Grant SFO-Mat-LiU 2009-00971), and the European Commission through the Marie Sklodowska-Curie project HORATES (GA-955837). A.M. acknowledges CINECA award no. HP10CC5WSY 2020 under the ISCRA initiative for computational resources. H.Y.W. acknowledges financial support from the National Research Foundation (NRF) of Korea (NRF-2019R1A2C2085290). We also acknowledge technical support from SUSTech Core Research Facilities. We thank H. Li, L. Lin, Z.-Y. Ren and Y.-H. Yang for 

## Article 

performing ESI-MS and ESR measurements. We thank L. Safaric, Q. Li and Y. Liu (Linköping University) for assistance with GC, absorption and NMR measurements. 

**Author contributions** H.G., A.F. and X.G. conceived and designed the project. H.G. prepared the samples and performed the electrical, optical absorption, MIS diode, AFM and Seebeck coefficient measurements. C.-Y.Y. and S.F. conducted the doping kinetics study and H2 product analysis. X.Z. initiated the study with organometallic complex catalyst. A.M. performed the DFT calculations. K.F., Y.S., K.Y., J.C. and H.S. synthesized the organic semiconductors. Y.X. and A.F. fabricated and characterized OTFT devices. Q.L. fabricated and characterized perovskite solar cells. Z.W. and H.Y.W. conducted the GIWAXS measurement. Y.T. performed the TEM measurement. C.-Y.Y., A.M., S.F. and A.F. contributed to data analysis and scientific discussion. H.G., A.F. and X.G. wrote the manuscript. All authors discussed the experimental results and approved the manuscript. 

**Competing interests** X.G. and H.G. have filed a provisional patent application based on this work. S.F. is the chief scientific officer of n-Ink AB, a company developing organic conductive inks. A.F. is the chief technology officer of Flexterra corporation, a company developing organic semiconductors. 

##### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41586-021-03942-0. **Correspondence and requests for materials** should be addressed to Antonio Facchetti or Xugang Guo. 

**Peer review information** _Nature_ thanks Peter Ho, Karl Leo and Shun Watanabe for their contribution to the peer review of this work. **Reprints and permissions information** is available at http://www.nature.com/reprints. 



**Extended Data Fig. 1 | TEM images of thermally evaporated AuNP films on TEM grids coated with a thin carbon film with the nanoparticle size (diameter** **_d_ ) distribution as a function of the nominal film thickness. a** – **e** , The nominal AuNP film thickness is 0.1 nm ( **a** ), 0.2 nm ( **b** ), 0.4 nm ( **c** ), 0.8 nm ( **d** ) and 1.5 nm ( **e** ). The TEM images are shown in both high magnification 

(left column; scale bar, 10 nm) and lower magnification (middle column; scale bar, 50 nm). The AuNP size distribution probability plots in the right column are all from statistical analysis of more than 150 nanoparticles, with their average sizes and standard deviations shown inside. 

## Article 



**Extended Data Fig. 2 | Electrical conductivity measurements for blend doped PDTzTI films on glass and PET substrates with different electrical contact materials. a** – **c** , Representative _I_ – _V_ characteristics of 60mol% N-DMBI-H blend doped PDTzTI films on glass substrates as plotted in log scale ( **a** ) and linear scale ( **b** , **c** ), respectively. When using AuNPs, there is a significant charge injection barrier between the Al electrode and the highly conductive PDTzTI film as shown by the non-linear _I_ – _V_ characteristics in panel **b** . Nonetheless, the _σ_ of the Al device, estimated from the currents at | _V_ | = 5 V, is 3.6 ± 0.3 S cm<sup>−1</sup> , which is in the same order of magnitude of that of the Au device (14.1 ± 0.7 S cm<sup>−1</sup> ). **c** , Without using AuNP catalyst, the device current is orders of magnitude lower than that of the device with AuNP, with a 

_σ_ = (2.6 ± 0.2) × 10<sup>−4</sup> S cm<sup>−1</sup> for the Al device and (4.6 ± 1.2) × 10<sup>−4</sup> S cm<sup>−1</sup> for the Au device. In all these experiments, the electrodes were fabricated by thermal evaporation using a shadow mask except for the control Au device (without AuNPs), which was prepared by lift-off photolithography to avoid that residual Au clusters catalyse the reaction as we show clearly in Supplementary Fig. 8. **d** , Representative _I_ – _V_ characteristics of 60mol% N-DMBI-H plus AuNPs blend doped PDTzTI films on glass (blue line) and plastic (PET, red line) substrates. In all these experiments _d_ = 1.4 nm, _T_ ann = 120 °C, _t_ ann = 10 s when using AuNP catalyst or _t_ ann = 10 min when not using catalyst, demonstrating that the catalysed n-doping method is fully compatible with PET substrates. All contact geometries are 100 μm (channel length) and 2 mm (channel width). 



**Extended Data Fig. 3 | AuNP catalysed N-DMBI-H doping efficiency estimation from electrical conductivity. a** – **f** , N-DMBI-H doping efficiency ( _η_ ) versus dopant molar ratio in blend-doped PDTzTI ( **a** ), PDTzTIT-2F ( **b** ), PDTzTIT ( **c** ), PBTzI ( **d** ), N2200 ( **e** ), and f-BTI2TEG-FT ( **f** ) films calculated using the measured electrical conductivity and various electron mobility values. The red curves originate using the measured OTFT mobility ( _μ_ e,OTFT values from our published results<sup>32,37,58</sup> or Supplementary Table 6 for f-BTI2TEG-FT). The plots show that the _μ_ e,OTFT is a reasonable assumption for the actual carrier mobility of doped films ( _μ_ e,doped) at high charge density for PDTzTI, PDTzTIT-2F, PDTzTIT and PBTzI (Extended Data Fig. 3a–d and Supplementary Table 3). The estimated high _η_ is in good agreement with our experimental observations of strong film colour change in their UV–vis–NIR spectra and high electrical conductivity (for 

example, Fig. 2b, Supplementary Figs. 9 and 10, Table 1). Obviously, the _μ_ e,doped at different dopant loading must afford a _η_ < 100%, to be realistic. _μ_ e,doped is likely to be charge density dependent and also changes with the N-DMBI-H loading and variation of film morphology, and also may differ significantly from the _μ_ e,OTFT as exemplified by N2200 ( **e** ) and f-BTI2TEG-FT ( **f** ) analysis. For N2200, the calculated _η_ max using the _μ_ e,OTFT is <0.1%, which does not agree with the experimental ESR results (>40%) and the strong variation of the optical absorption. Thus, the actual _μ_ e,doped must be << _μ_ e,OTFT and possibly <0.001 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> when examining the _η-_ dopant molar ratio graph in panel **e** . For the polymer f-BTI2TEG-FT, a _η_ max >3,000% is calculated using the _μ_ e,OTFT, which is unrealistic. Thus, the actual _μ_ e,doped is >> _μ_ e,OTFT and possibly around 1 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> at high charge densities, as estimated from the graph in panel **f** . 

Article 



**Extended Data Fig. 4 | 2D-GIWAXS images of N-DMBI-H + AuNP doped organic semiconductor films.** The semiconductor films were spin-cast from their pristine or blend solutions with N-DMBI-H in CHCl3 (5 mg ml<sup>−1</sup> for PDTzTI and N2200, 20 mg ml<sup>−1</sup> for PDI-C6C7), then annealed at _T_ ann = 120 °C, _t_ ann = 10 s. In all these experiments, AuNP _d_ = 1.4 nm and the substrate is silicon. The images 

clearly show that, as the N-DMBI-H loading increases, the doped film crystallinity gradually decreases, eventually to a very low degree of crystallinity and near amorphous structure for all these organic semiconductor films at 100mol% N-DMBI-H loading. 



**Extended Data Fig. 5 | Explored AuNP catalysed N-DMBI-H doping mechanisms.** All the investigated routes share the same first step, namely the hydride transfer from N-DMBI-H to AuNP surface. Depending on the possible active-doping-species, we propose four different reaction routes after the initial hydride transfer step. In route a, Au _x_ –H<sup>–</sup> directly acts as the active-doping-species and forms Au _x_ –H<sup>•</sup> after electron transfer to PDI, then, the H<sup>•</sup> on AuNP surface combines and releases H2 gas to regenerate clean AuNP surface for the next catalytic cycle. In route b, H<sup>•</sup> is released from Au _x_ –H<sup>–</sup> to form Au _x_ •− as the active-doping-species, then H• combines to give H2 gas, while Au _x_ •− transfers the electron to the PDI and goes to the next catalytic cycle. In route c, H<sup>−</sup> is transferred from Au _x_ –H<sup>–</sup> to PDI and forms hydrogenated PDI anion 

(denoted as PDI–H<sup>–</sup> ) as the active-doping-species, which transfers electron to another PDI molecule and forms PDI–H<sup>•</sup> , then two PDI–H<sup>•</sup> combine each other to give H2 gas while PDI is regenerated for the next doping reaction cycle. Finally, in route d, H<sup>−</sup> is released from Au _x_ –H<sup>–</sup> and serves as the active-doping-species, the clean AuNP surface goes to next catalytic cycle, while H<sup>−</sup> transfers the electron to the PDI and forms H<sup>•</sup> which combines to give H2 gas. For all the reaction routes, the final reaction products are N-DMBI<sup>+</sup> , PDI<sup>•−</sup> and H2 gas, AuNP only serves as the reaction catalyst. PDI-C6C7 molecule is modelled by a simpler PDI in which the 1-hexylheptyl side chain is replaced by a methyl group. 

Article 



**Extended Data Fig. 6 | Gibbs free energy profile (kcal mol**<sup>**−1**</sup> **) of the investigated nanoparticle catalysed N-DMBI-H doping mechanisms.** PDI-C6C7 molecule is modelled by a simpler PDI in which the 1-hexylheptyl side chain is replaced by a methyl group. AuNP is modelled by the Au (111) surface. 

Solvation effects are taken into account for all the molecular species. Route a is most energetically favourable with its Gibbs free energy diagram also given in Fig. 4f of the main text. 



**Extended Data Fig. 7 | Application of catalysed n-doping of organic** 

**polymers to n-type organic thermoelectronic devices. a** , Illustration of an n-type thermoelectric device where this method can be used to generate an n-doped organic semiconductor film. **b** , N-type thermoelectric performance of an off-centre spin-casted, sequentially doped f-BTI2TEG-FT+PBTI blend films, using AuNP catalyst. Recently, side-chain engineering of conjugated polymers with hydrophilic groups<sup>59</sup> has shown improved n-dopability and conductivity with N-DMBI-H due to enhanced dopant/semiconductor miscibility. For example, by simply replacing the hydrophobic alkyl chain (2-octyldodecyl) in f-BTI2-FT<sup>51</sup> with triethylene glycol (TEG)-based chain in f-BTI2TEG-FT (Supplementary scheme 1, Supplementary Figs. 34–41), _σ_ of uncatalysed N-DMBI-H doping was found to increase from (8.9 ± 0.5)  × 10<sup>−3</sup> S cm<sup>−1</sup> to 1.4 ± 0.1 S cm<sup>−1</sup> , respectively. However, N-DMBI-H+AuNP doping of f-BTI2TEG-FT can achieve a _σ_ of 25.1 ± 0.6 S cm<sup>−1</sup> (blend doping), 

38.4 ± 2.2 S cm<sup>−1</sup> (sequential doping, on-centre), and 74.3 ± 4.6 S cm<sup>−1</sup> (sequential doping, off-centre) (Table 1, Supplementary Figs. 42, 43), despite a low transistor mobility of 0.018 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> (Supplementary Fig. 44, Supplementary Table 6). Impressively, an even higher _σ_ of 104.0 ± 7.9 S cm<sup>−1</sup> (maximum 116.3 S cm<sup>−1</sup> ) can be obtained by adding a small amount (15wt%) of the high mobility PBTI polymer<sup>50</sup> ( _M_ n = 35.5 kDa) to f-BTI2TEG-FT, which serves as high-mobility pathways between doped f-BTI2TEG-FT domains for improved charge transport<sup>42</sup> . Thus, based on the latter blend, we fabricated an organic thermoelectric device which showed a remarkable power factor (PF) of 65.7 ± 5.5 μW m<sup>−1</sup> K<sup>−2</sup> with a Seebeck coefficient of −79.5 ± 2.8 μV K<sup>−1</sup> (Extended Data Fig. 7b, Supplementary Fig. 45). The conductivity and power factor values are among the highest to date for solution-processed molecular n-doped conjugated polymers<sup>12,46</sup> . Error bars represent the standard deviations from their mean values. 

Article 



**Extended Data Fig. 8 | Application of catalysed n-doping of organic polymers to organic thin-film transistor (OTFT) devices. a** , Chemical structure of the polymer N2200-EG7 (P) and the PDIR-CN2 semiconductor (OSC) used for OTFT devices. **b** , Top-gate bottom-contact OTFT structure with Au source/drain/gate electrodes and using Au contacts to catalyse the n-doping of the NDI polymer P with N-DMBI-H (blend method). 

**c** – **e** , Corresponding transfer plots ( **c** ), mobility evolutions ( **d** ) and low-drain voltage output plots ( **e** ) of the indicated devices. **f** , Top-gate bottom-contact OTFT structure with Ag source/drain/gate electrodes using Pd2(dba)3 to catalyse the n-doping of the NDI polymer P with N-DMBI-H (blend method). **g** – **i** , Corresponding transfer plots ( **g** ), mobility evolutions ( **h** ) and low-drain voltage output plots ( **i** ) of the indicated devices. 



**Extended Data Fig. 9 | Perovskite solar cells fabricated with undoped/ doped polymer films as the electron transporting layer (ETL). a** , Perovskite cell structure, chemical structures of the hole transporting layer (HTL) and ETL 

polymers used in this study. **b** , _J–V_ plots of the best device using PDTzTIT polymer as ETL. **c** , _J–V_ plots of the best device using PDTzTIT-2F polymer as ETL. 

