# The Main Progress of Perovskite Solar Cells in 2020–2021

| 字段 | 内容 |
|---|---|
| 期刊 | Nano-Micro Letters |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 366 |
| 作者 | Tian-Hao Wu, Zhen-Zhen Qin, Yan-Bo Wang, Yongzhen Wu, Wei Chen, Shu-Fang Zhang, Mo-Lang Cai, Song-Yuan Dai et al. |
| DOI | 10.1007/s40820-021-00672-w |
| 源文件 | 039_Wu_2021_The-Main-Progress-of-Perovskite-Solar-Cells-in-2.pdf |

---
ISSN 2311-6706 e-ISSN 2150-5551 CN 31-2103/TB 

https://doi.org/10.1007/s40820-021-00672-w 

## **<mark>REVIEW</mark>** 



# **The Main Progress of Perovskite Solar Cells in 2020–2021** 

###### **Cite as** 

Nano-Micro Lett. (2021) 13:152 

Received: 29 April 2021 Accepted: 7 June 2021 Published online: 7 July 2021 © The Author(s) 2021 

Tianhao Wu<sup>1</sup> , Zhenzhen Qin<sup>1</sup> , Yanbo Wang<sup>1</sup> , Yongzhen Wu<sup>2</sup> , Wei Chen<sup>3</sup> , Shufang Zhang<sup>4</sup> , Molang Cai<sup>5</sup> , Songyuan Dai<sup>5</sup> , Jing Zhang<sup>6</sup> , Jian Liu<sup>7</sup> , Zhongmin Zhou<sup>8</sup> , Xiao Liu<sup>9</sup> , Hiroshi Segawa<sup>9</sup> , Hairen Tan<sup>10</sup> , Qunwei Tang<sup>11</sup> , Junfeng Fang<sup>12</sup> , Yaowen Li<sup>13</sup> , Liming Ding<sup>14</sup> , Zhijun Ning<sup>15</sup> , Yabing Qi<sup>16</sup> , Yiqiang Zhang<sup>17</sup> , Liyuan Han<sup>1,9*</sup> 

#### **HIGHLIGHTS** 

- Recent progress of efficiency and long-term stability for perovskite solar cells, and the development of perovskite-based tandem solar cells are described. 

- The progress of lead-free perovskite solar cells and their potential for industrial production are discussed in detail. 

- The current status, ongoing challenges, and the future outlooks of perovskite solar cells are highlighted. 

**ABSTRACT** Perovskite solar cells (PSCs) emerging as a promising photovoltaic technology with high efficiency and low manufacturing cost have attracted the attention from all over the world. Both the efficiency and stability of PSCs have increased steadily in recent years, and the research on reducing lead leakage and developing eco-friendly lead-free perovskites pushes forward the commercialization of PSCs step by step. This review summarizes the main progress of PSCs in 2020 and 2021 from the aspects of efficiency, stability, perovskite-based tandem devices, and lead-free PSCs. Moreover, a brief discussion on the development of PSC modules and its challenges toward practical application is provided. 



<!-- Start of picture text -->
Perovskite Absorber<br>Interface Engineering Charge<br>Transport Layer Design<br>Efficiency<br>Back Electrode<br>Charge Transport Layer Additive<br>PerovskiteTin-based Lead-Free Perovskite Stability HeterostructureEngineering<br>Solar Cells Device Stabilization<br>Charge Transport Layer Cell<br>Encapsulation<br>Transparent Electrode<br>Tandem<br>Device<br>Si/Perovskite Tandem<br>All-Perovskite Tandem<br><!-- End of picture text -->

**KEYWORDS** Perovskite solar cells; Stability; Solar module; Perovskite-based tandem devices; Lead-free perovskite 

> * Liyuan Han, han.liyuan@sjtu.edu.cn 

> 1 State Key Laboratory of Metal Matrix Composites, School of Material Science and Engineering, Shanghai Jiao Tong University, Shanghai 200240, People’s Republic of China 

> 2 Key Laboratory for Advanced Materials and Feringa Nobel Prize Scientist Joint Research Centre, Shanghai Key Laboratory of Functional Materials Chemistry, Joint International Research Laboratory of Precision Chemistry and Molecular Engineering, School of Chemistry and Molecular Engineering, East China University of Science and Technology, Meilong Road 130, Shanghai 200237, People’s Republic of China 

> 3 Wuhan National Laboratory for Optoelectronics, Huazhong University of Science and Technology, Luoyu Road 1037, Wuhan 430074, People’s Republic of China 

> 4 College of Materials Science and Engineering, Nanjing University of Science and Technology, Nanjing 210094, People’s Republic of China 

> 5 Beijing Key Laboratory of Novel Thin-Film Solar Cells and State Key Laboratory of Alternate Electrical Power System With Renewable Energy Sources, North China Electric Power University, Beijing 102206, People’s Republic of China 

> 6 Department of Microelectronic Science and Engineering, Ningbo University, Zhejiang 315211, People’s Republic of China 

1 3 

**152** Page 2 of 18 

Nano-Micro Lett. (2021) 13:152 

### **1 Introduction** 

Perovskite solar cells (PSCs) have become a promising thinfilm photovoltaic (PV) technology due to the high lightabsorption coefficient, long carrier diffusion length, and solution processibility of metal halide perovskite materials [1–5]. Currently, the highest power conversion efficiency (PCE) of PSCs has reached 25.5% [6], exceeding the record efficiency of copper indium gallium selenium (CIGS) solar cells and approaching that of crystalline-Si solar cells. Moreover, the scale-up deposition techniques for perovskites and charge transport layers promote the development of largearea perovskite solar modules, including doctor-blade coating, slot-die coating, screen printing, and spray deposition strategies. Recently, a certified efficiency of about 18% has been reported for an over 800  cm<sup>2</sup> PSC sub-module [6], indicating large potential for practical use. On the other hand, perovskite-based tandem solar cells with a theoretical PCE beyond the limit of single-junction PSCs also make a huge progress owing to the reduction of defect density and increase of carrier diffusion length in both wide-bandgap and narrow-bandgap perovskite absorbers [7–9]. By now, the highest certified efficiency of the perovskite-based tandems has increased to over 29% [10]. 

Besides the efficiency progress, the long-term stability of PSCs against damp, light, and heat also improved significantly in recent years, which could be attributed to the construction of diffusion barrier against ion migration, additive engineering, design of chemically inert carbon-based electrodes, and development of cell encapsulation technique to 

reduce the lead leakage from a broken PSC module [11–18]. It was demonstrated that the printable PSCs had passed the most popular international standards of IEC61215:2016 for mature PV technology [19]. 

With the continuous progress of PSCs toward commercialization, exploiting eco-friendly lead-free perovskite materials has also become a hot research topic in this field in view of the toxicity of Pb element in Pb-containing PSCs giving rise to the concern of environmental pollution [20–23]. So far, the highest certified efficiency of lead-free PSCs has reached 11.22%, enabled by minimizing the defect density in tin halide perovskite films via a template-growth deposition method [24]. 

In this review, we summarize the representative works on PSCs published by worldwide research groups in 2020 **–** 2021 from the aspects of efficiency, stability, perovskite-based tandem solar cells, and the development of lead-free PSCs. In addition, we point out the future challenges on realizing the commercialization of PSCs, and then give a brief outlook on the possible research topics at the next stage. 

### **2  Efficiency** 

PSCs are usually composed of perovskite absorbers, charge transport layers and counter electrodes. The energy loss in the bulk and interface of perovskites layers, and the charge extraction and transportation process in device play a critical role in determining the efficiency of PSCs. Therefore, improving the crystal quality of perovskite films, suppressing the non-radiative recombination at interface, and rational 

> 7 College of Chemical Engineering, Jiangsu Key Lab of Biomass-Based Green Fuels and Chemicals, Nanjing Forestry University, Nanjing 210037, People’s Republic of China 

- 8 College of Chemistry and Molecular Engineering, Qingdao University of Science and Technology, Qingdao 266042, People’s Republic of China 

- 9 Special Division of Environmental and Energy Science, Komaba Organization for Educational Excellence (KOMEX), College of Arts and Sciences, University of Tokyo, Tokyo 153-8902, Japan 

> 10 National Laboratory of Solid State Microstructures, Jiangsu Key Laboratory of Artificial Functional Materials, College of Engineering and Applied Sciences, Nanjing University, Nanjing 210093, People’s Republic of China 

- 11 College of Information Science and Technology, Jinan University, Guangzhou 510632, People’s Republic of China 

- 12 School of Physics and Electronic Science, Engineering Research Center of Nanophotonics and Advanced Instrument, Ministry of Education, East China Normal University, Shanghai 200062, People’s Republic of China 

> 13 Laboratory of Advanced Optoelectronic Materials, College of Chemistry, Chemical Engineering and Materials Science, Soochow University, Suzhou 215123, People’s Republic of China 

> 14 Center for Excellence in Nanoscience, Key Laboratory of Nanosystem and Hierarchical Fabrication, National Center for Nanoscience and Technology, Beijing 100190, People’s Republic of China 

> 15 School of Physical Science and Technology, ShanghaiTech University, 100 Haike Road, Shanghai 201210, People’s Republic of China 

> 16 Energy Materials and Surface Sciences Unit (EMSSU), Okinawa Institute of Science and Technology Graduate University (OIST), Okinawa 904-0495, Japan 

> 17 School of Materials Science and Engineering, Henan Institute of Advanced Technology, Zhengzhou University, Zhengzhou 450001, People’s Republic of China 

© The authors 

https://doi.org/10.1007/s40820-021-00672-w 

Page 3 of 18 **152** 

Nano-Micro Lett. (2021) 13:152 

design of the charge transport layers are expected to further improve the device efficiency. 

##### **2.1  Perovskite Absorbers** 

In 2020–2021, the research activities on perovskite layer mainly focus on stabilizing the formamidinium lead iodide (FAPbI3) perovskite phase with wide absorption range and long carrier lifetime to boost the short-circuit current density ( _J_ SC) and open-circuit voltage ( _V_ OC) of PSCs [25, 26]. Besides, exploiting the single-crystal device with very low defect density has also been reported for realizing highperformance PSCs. 

To maximize the photon-absorption at the UV–vis region, Kim et al. used the inherent bandgap (1.47 eV) of α-phase FAPbI3 to increase the photocurrent of PSCs [27]. They replaced the FA cations by a trace amount (0.03 molar 

fraction) of cesium (Cs) and methylenediammonium (MDA) cations to stabilize the α-phase  FAPbI3 without changing its inherent bandgap, but improved the UV–vis absorption of perovskite layer. These effects contribute to a high _J_ SC of 26.23 mA  cm<sup>−2</sup> for PSCs, very close to the theoretical current limit of about 27 mA  cm<sup>−2</sup> for 1.47 eV-bandgap semiconductors [7]. Moreover, Fig. 1a shows that co-doping of 0.03 mol Cs and MDA cations also relaxes the lattice strain of  FAPbI3 by over 70% compared to the sample only treated with MDA cation reported in their previous study [28], which prolongs the carrier recombination lifetime and enables a _V_ OC increase of 30 mV (Fig. 1b), leading to a high certified PCE reaching 24.4%. 

Besides the cation-doping strategies, substitution of X-site halide anions could also significantly affect the optoelectronic properties of  FAPbI3 perovskites. Jeong et al. introduced an anion engineering strategy that employs the pseudo-halide anion formate  (HCOO<sup>−</sup> ) to fill the halide 



<!-- Start of picture text -->
(a) 0.0016 (b)<br>25<br>FA-MDA3.8 20<br>0.0012<br>Control (reverse scan)<br>15 Control (forward scan)<br>Target (reverse scan)<br>10 Target (forward scan)<br>0.0008<br>5<br>0.0004 0<br>0.01 0.02 0.03 0.04 Control 0.0 0.2 0.4 0.6 0.8 1.0 1.2<br>x (mole fraction) Voltage (V)<br>(c) (d) HCOO −<br>Cl −<br>Pb 2+<br>Br −<br>I −<br>FA +<br>I −<br>HCOO −<br>BF4 −<br>0.0 0.5 1.0 1.5 2.0 2.5 3.0<br>Binding affinity towards iodide vacancy site (eV)<br>Microstrain (ε)<br>−2Current density (mA cm)<br><!-- End of picture text -->

**Fig. 1  a** Residual strain calculated in  FAPbI3 perovskite films doped with different molar ratio (x) of Cs and MDA cations, and the control sample treated with 3.8 mol% MDA. **b** The best _J -V_ curves of the control device and the PSCs treated with Cs and MDA. Reproduced with permission from Ref. [27] Copyright 2020 AAAS. **c** Calculated crystal structure demonstrating the passivation of  I<sup>−</sup> vacancy at  FAPbI3 surface by a  HCOO<sup>−</sup> anion. All chemical compounds are shown in ball-and-stick style. **d** The relative binding energy of different anions at the site of  I<sup>−</sup> vacancy at  FAPbI3 surface. Reproduced with permission from Ref. [29] Copyright 2021 Nature Publishing Group 

1 3 

**152** Page 4 of 18 

Nano-Micro Lett. (2021) 13:152 

vacancy defects located at grain boundaries and surface of perovskite films [29] and to enhance the crystallinity of FAPbI3. It is found that the doping of 2% formate anions could enlarge the grain size to about 2 μm, increasing the crystal orientation along (100) and (200) directions that are better for carrier transport, and suppressing the formation of non-photoactive δ-FAPbI3 phase. Moreover, the theoretical calculation revealed that formate anions had a larger binding affinity toward iodide vacancy sites compared to other anions like  Cl<sup>−</sup> ,  Br<sup>−</sup> , and  BF4− owing to the fact that every carboxylate group can form two Pb–O coordination bonds with the lead cations (Fig. 1c, d). As a result, the  FAPbI3-based PSCs with pseudo-halide treatment attained a record PCE of 25.6% (certified 25.2%) and a _V_ OC of 1.19 V. 

Another representative work for the improvement in perovskite layers is the fabrication of uniaxial-oriented perovskite layer with millimeter-sized grains via a methylamine gas-assisted crystallization method [30]. In this study, the methylammonium lead iodide  (MAPbI3) perovskite film was formed by controlling the evaporation rate of MA gas molecules from liquid intermediate phase of  MAPbI3·xMA in a closed system. The results demonstrated that a slow release rate of MA molecules from the liquid intermediate phase significantly reduced the supersaturation, leading to a low nucleation density that provided more time for growing large  MAPbI3 grains during thermal annealing process. Consequently, the perovskite grains with about 1 mmsize can be obtained, resulting in a very low trap density of 9.7 ×  10<sup>13</sup> cm<sup>−3</sup> , approaching that of the  MAPbI3 single crystal [31], and the PSCs with millimeter-sized  MAPbI3 perovskite grains exhibited a promising PCE of 21.36%. 

##### **2.2  Interface Engineering** 

The interfacial properties between perovskite and charge transport layers play an important role in the charge recombination mechanism of PSCs, which greatly influence the _V_ OC and fill factor (FF) of the solar cells [32–34]. Therefore, many methods have been developed to reduce the non-radiative recombination loss at the interface and optimize the series resistance of the passivation layers for efficiency improvement. 

To suppress carrier recombination at perovskite surface and grain boundaries, Zheng et al. used a trace amount of surface-anchoring alkylamine ligands (AALs) with different chain lengths for the modification of perovskite surface 

[35]. They found that the oleylamine ligand with a long alkyl chain showed a more obvious passivation effect for improving carrier recombination lifetime and the _V_ OC of PSCs (Fig. 2a), as compared to other organic AALs with shorter alkyl chains, which could be attributed to the electron-tunneling effect in the insulating AALs layers. Such a tunneling effect allows the movement of electrons from perovskite conduction band to the lowest unoccupied molecular orbital (LUMO) of the fullerene-C60 layer, but effectively blocks the hole injection from valence band to the highest occupied molecular orbital (LUMO) of  C60 (Fig. 2b). This passivation technique based on the insulating tunneling layer is also widely applied in silicon solar cells [36]. Based on this oleylamine ligand-anchoring strategy, the invertedstructure PSCs achieved a strong _V_ OC improvement up to 110 mV, resulting in a record certified efficiency of 22.3%. 

Although the additional passivation layer is beneficial for the _V_ OC improvement of PSCs, it may undesirably increase the series resistance of devices and thus leads to the loss of FF. This detrimental effect will become more obvious in the case of large-area devices. In order to balance the improvement of _V_ OC and FF, Peng et al. designed a nanoscale localized contact at the polymer-passivated perovskite/TiO2 interface to realize a higher FF for 1  cm<sup>2</sup> PSCs [37]. They deposited a nanopatterned electron-selective  TiO2 layer via atomic-layer deposition (ALD) to form nanorod-like charge transport channels through the passivated interface (the device structure is shown in Fig. 2c), which provided both effective contact passivation and excellent charge extraction ability for reducing the device series resistance. As a result, they achieved a high FF of 83.9% and a high _V_ OC of 1.20 V by employing an ALD TiO2 nanopattern with 300 nm spacing at the polymer passivation interface (Fig. 2d), resulting in a record certified PCE of 21.6% for an over 1  cm<sup>2</sup> cell. 

##### **2.3  Charge Transport Layer Design** 

Rational design of the charge transport layer also boosts the PV parameters of PSCs significantly. Jeong et al. designed two fluorinated isomeric analogs of the well-known hole transport molecule spiro-OMeTAD to modify the energylevel alignment, hydrophobicity, and hole extraction ability in PSCs [38]. They found that the fluorinated group at the meta-position on the benzene ring (spiro-mF) could 

© The authors 

https://doi.org/10.1007/s40820-021-00672-w 

Page 5 of 18 **152** 

Nano-Micro Lett. (2021) 13:152 



<!-- Start of picture text -->
(a) (b)<br>Electron<br>CBM − − − − −<br>LUMO<br>Pb<br>Br/I<br>Cs/FA/MA<br>C Hole<br>N VBM + + + + + HOMO<br>Perovskite<br>C60<br>Perovskite Long-chain AAL layer AAL layer<br>0<br>(c) (d)<br>300 nm pitch<br>−4 S-Planar<br>−8<br>Pt protection layer<br>Gold (~130 nm)<br>Perovskite −12<br>ITO (~130 nm) −16<br>Glass<br>−20<br>Device Structure: −24 Experiment<br>Glass/ITO/c-TiO2/TiO2 nanorods/PMMA:PCBM/Perovskite/PMMA/P3HT:CuPc/Gold<br>(~50 nm) (<3 nm) (<3 nm) (~60 nm) 0.0 0.2 0.4 0.6 0.8 1.0 1.2<br>Voltage (V)<br>TiO2   ETL<br>PMMA:PCBM<br>−2Current density (mA cm)<br><!-- End of picture text -->

**Fig. 2  a** Illustration of the long-chain AALs assembled on perovskite film surface. **b** The electron-tunneling and hole-blocking effects induced by AAL layer at the perovskite/C60 interface, VBM and CBM represent the valence band maximum and conduction band minimum of perovskite semiconductor, respectively. Reproduced with permission from Ref. [35] Copyright 2020 Nature Publishing Group. **c** Cross-sectional SEM image of the PSCs designed with  TiO2 nanorod pattern at the bottom surface of perovskite layer. **d** Experimental _J-V_ curves of the PSCs based on planar (reference cell) and the  TiO2 nanopattern structure, 300 nm pitch represents the  TiO2 nanorods with a spacing of 300 nm in devices, the inset shows that about 30% of the nanorod is coated with insulating passivation layer. Reproduced with permission from Ref. [37] Copyright 2020 AAAS 

lower the HOMO position from −4.97 to −5.19 eV and thus provided a more suitable energy-level alignment with the valence band maximum (VBM) of  FAPbI3 perovskite absorber (-5.40 eV) to reduce the interfacial energy loss, resulting in a _V_ OC improvement of the device. Moreover, the F atoms could induce a denser solid-state molecule packing through non-covalent intramolecular interaction, which further improves the electronic contact between spiro-mF and perovskite surface, producing better transport and extraction ability of holes, resulting in a slightly increase of _J_ SC and FF. These effects boost the efficiency from 23.44% to 24.84% for PSCs. 

On the other side, chemical bath deposition was applied to produce a high-quality electron-selective  SnO2 layer for limiting excess charge carrier recombination in PSCs [39]. 

Unlike the conventional deposition using  SnOx nanoparticle dispersion, chemical bath deposition enables the uniform and complete coverage of  SnO2 film on the substrate via a rational control of the reaction time and pH value of the  SnCl2 precursor solution. As can be seen in Fig. 3, at the stage A-i, with a low pH value and short reaction time, the as-deposited  SnO2 film showed many pinholes. After increasing the pH value to stage A-ii, a low O-vacancy SnO2 film (targeted sample) with ideal film coverage, thickness, and chemical composition could be achieved. When further increasing the pH and reaction time to stages A-iii and B, the density of O-vacancy increased significantly and the additional  Sn6O4(OH)4 and SnO phases were present, lowering the electron transport ability and inducing charge recombination in  SnO2 films. By further optimizing the Br 

1 3 

**152** Page 6 of 18 

Nano-Micro Lett. (2021) 13:152 



**Fig. 3** Schematic illustration of four major stages at different reaction time and pH value of the chemical bath deposition for  SnO2, the magic region highlights the A-ii stage that exhibits an ideal film coverage, morphology and chemical composition of  SnO2 film. Reproduced with permission from Ref. [39] Copyright 2021 Nature Publishing Group 

concentration in perovskite films, a certified PCE of 25.2% was achieved, corresponding to 80.5% of the theoretical efficiency limit. 

### **3  Stability** 

Stability issues are the major bottleneck for the commercialization of PSCs. The chemical components of metal halide perovskite are bonded through weak interactions such as ionic interaction, hydrogen bonding, and van der Waals forces, which results in the soft-material nature of perovskite semiconductors. Irreversible decomposition of organic species and the ion migration occur easily in PSCs under moisture penetration, continuous light soaking, thermal stress, and external electric field [11, 40–42], which cause damage to both the perovskite and charge transport layers. On the other hand, the leakage of Pb during long-term operation of PSCs under bad weather conditions could further cause environmental and public health risk, which should also be considered as an important stability issue to be addressed for future commercialization. In this part, we discuss the recent research progress on PSC stability from the viewpoint of additive engineering, heterostructure stabilization, and the cell encapsulation technology for reducing lead leakage. 

##### **3.1  Additive Engineering** 

Introducing the additive molecules that could form extra chemical interactions with the volatile components is an effective way to suppress ion migration and irreversible decomposition of perovskite films. Mei et al. [19] introduced 

bifunctional 5-ammoniumvaleric acid iodide (5-AVAI) to inhibit the methylammonium iodide (MAI) loss on the surface and the crystal reconstruction of  MAPbI3 grains. 5-AVAI could form hydrogen bonds with the iodine ions through amino groups (−NH3+), while their carboxyl groups (-COOH) form a strong hydrogen bond with another 5-AVAI in the adjacent grains, which results in a cross-linking of the perovskite surface and interface and a large enhancement of the thermal stability. Besides, non-volatile 5-AVAI at the interfaces limits the volatilization of organic components, which inhibits the forward process of decomposition reaction of  MAPbI3. It can also stabilize the metal oxide matrix  (ZrO2 and  TiO2) via the anchoring effect between -COOH and metal cations, thus restricting ion migration of  MA<sup>+</sup> and  I<sup>−</sup> at the grain boundaries and the interfaces. After encapsulation with a hot-melt polymer film, the printable PSCs treated with 5-AVAI successfully passed the main items of IEC61215:2016 qualification tests, especially working for more than 9000 h at a maximum power point of 55 ± 5 °C without obvious decay. 

Furthermore, an organic ionic salt called 1-butyl-1-methylpiperidinium tetrafluoroborate  ([BMP]<sup>+</sup> [BF4]<sup>−</sup> ) was developed to suppress the light-induced phase segregation and degradation in thermally stable CsFA-based lead-halide perovskites [43]. The results indicated that small amounts of  [BMP]<sup>+</sup> [BF4]<sup>−</sup> additives could penetrate the entire volume of perovskite film and passivate both the bulk and surface defect states via ionic interaction, leading to a large photovoltage enhancement for the PSCs. During the aging process,  [BMP]<sup>+</sup> [BF4]<sup>−</sup> prevented the segregation of Br-rich FAPbBr3 phase in mixed-halide perovskite film and suppress the corrosion of silver electrode (one of the key reasons for device degradation) induced by  I2 generation under 

© The authors 

https://doi.org/10.1007/s40820-021-00672-w 

Page 7 of 18 **152** 

Nano-Micro Lett. (2021) 13:152 

light and heat.  I2 is mainly formed by the combination of interstitial  I<sup>−</sup> and holes, or two neutral iodine atoms [44]. In the presence of  [BMP]<sup>+</sup> [BF4]<sup>−</sup> , the ion diffusion channels at the grain surface were effectively reduced, resulting in the inhibition of  I2 formation. Consequently, under full-spectrum simulated sunlight in ambient atmosphere, the unencapsulated and encapsulated PSCs retained 80% and 95% of their post-burn-in efficiencies for 1010 h (60 °C) and 1200 h (85 °C), respectively. 

Other additives such as lead chloride, organic dye molecules, phosphorus-based Lewis acid, and cyano derivatives have been reported to suppress ion migration and passivate surface ionic defects in perovskite film, resulting in the improvement of long-term stability [45–47]. 

##### **3.2  Heterostructure Stabilization** 

The heterostructures formed between perovskite and charge transport layers play a significant role in the long-term 

stability of the whole device, so much attention has been paid to stabilizing the interface of each functional layer in PSCs. Liu et al. employed a holistic strategy to stabilize the front and back interface of perovskite layer under operational condition [48].They used ethylenediaminetetraacetic acid dipotassium salt (EDTAK) to treat the electron-selective  SnO2 surface for stabilization of the front heterostructure (Fig. 4a). The Lewis acid–base reaction between the alkylamine group of EDTAK and  Pb<sup>2+</sup> cations efficiently passivated the vacancy defects in the perovskite film. Besides, incorporation of EDTAK also shifted the conduction band minimum (CBM) of  SnO2 from −3.69 to −3.95 eV, resulting in a better energy-level alignment for charge extraction. The perovskite/ spiro-OMeTAD heterostructure was stabilized by the surface ethylammonium iodide (EAI) modification to form an EAMA-based perovskite capping layer with better ambient stability. Regarding the spiro-OMeTAD/electrode interface, a small amount of P3HT was incorporated to inhibit the degradation caused by inward migration of gold into the 



<!-- Start of picture text -->
(a)<br>Parylene<br>Au<br>Spiro-OMeTAD/P3HT<br>EAMA perovskite<br>FAMA perovskite<br>EDTAK<br>SnO2<br>ITO<br>P3 P2<br>P1<br>(b)<br>1.0<br>0.8<br>100% of initial PCE 90% of initial PCE 80% of initial PCE<br>0.6<br>0.4<br>0.2<br>0.0<br>0 200 400 600 800 1000 1200 1400 1600 1800 2000<br>Time (h)<br>Normalized PCE<br><!-- End of picture text -->

**Fig. 4  a** The holistic method containing four treatments for the functional layers and their interfaces in device, including the use of EDTAK to modify  SnO2 layer, the use of ethylammonium iodide (EAI) to form EAMA-based perovskite atop the FAMA-based perovskite absorber, doping P3HT into the spiro-OMeTAD layer, and using parylene to encapsulate the PSC module. **b** The operational stability of parylene-encapsulated solar module with a structure of  SnO2-EDTAK/perovskite/spiro-OMeTAD-P3HT/Au measured under continuous 1-sun illumination. Reproduced with permission from Ref. [47] Copyright 2020 Nature Publishing Group 

1 3 

**152** Page 8 of 18 

Nano-Micro Lett. (2021) 13:152 

perovskite layer and also enhance the moisture stability of spiro-OMeTAD. By employing such a holistic stabilization approach, the PSC modules without encapsulation achieved an efficiency of 16.6% with a designated area of 22.4  cm<sup>2</sup> , and the encapsulated solar modules with parylene-coated cover glass retained approximately 86% of the initial performance after continuous operation for 2000 h under AM1.5G light illumination (Fig. 4b). 

Our previous work employed CsFA-based perovskite with high thermal stability as the absorber to construct a scalable integrated heterostructure for PSC modules [49]. Under the operational condition, the iodide ions can easily migrate from perovskite to the hole transport layer (HTL) and change its semiconducting properties from p ‐ type to n ‐ type, causing deterioration of hole extraction in PSCs. To stabilize this heterostructure, a scalable bridge ‐ jointed graphene oxide (BJ-GO) layer was deposited on the perovskite surface to block iodide migration. During this process, 3 ‐ aminopropyl triethoxysilane (APTES) was used to connect the small-size GO nanosheets by forming C-N covalent bonds with GO, resulting in a full ‐ coverage hydrophobic blocking layer on perovskite surface for inhibiting ion migration, passivating surface under-coordinated  Pb<sup>2+</sup> , and protecting perovskite layer from the damage of water in ambient environment. By employing the BJ-GO layer in the PSCs with undoped HTL, we achieved a high PCE of 16.21% for a 36  cm<sup>2</sup> solar module. The encapsulated module retained over 91% of its initial efficiency after the damp heat test at 85 °C and 85% relative humidity for 1000 h, while maintaining 90% of the initial value for 1000 h under standard operational condition at 60 °C. 

##### **3.3  Cell Encapsulation** 

In 2020–2021, researches on PSC encapsulation mainly focused on reducing the Pb leakage from a broken device. During the long-term operation process,  Pb<sup>2+</sup> showing weak chemical interaction with other perovskite components could also escape from perovskite layer after water penetration, resulting in additional environmental problems. For a typical lead perovskite absorber with a thickness of 550 nm, the unit-area lead concentration is estimated to be about 0.75 g  m<sup>−2</sup> , which is more than 100 times higher than that of the commonly used Pb-containing paints (0.007 g  m<sup>−2</sup> ) [50]. 

The physical encapsulation with  Pb<sup>2+</sup> -absorption materials can effectively suppress the irreversible outflow of Pb from damaged devices into the underground water or soils at severe weather conditions [51]. Li et al. deposited the leadabsorbing materials on both front and back sides of PSCs to reduce the leakage of lead [23]. On the front glass side, they used a transparent Pb-absorbing molecule with phosphonic acid groups that showed a large binding energy with  Pb<sup>2+</sup> cations to absorb lead in water when water seeps into the device. On the back side, they coated a polymer film mixed with lead-coordination agents between the metal electrode and the encapsulation layer. As a consequence, the leadabsorption effects on both sides of PSCs could sequestrate more than 96% of lead leakage in water induced by severe device damage while retain the structural integrity of solar cells. 

Furthermore, a low-cost and chemically robust cationexchange resin (CER)-based method was developed to prevent lead leakage from broken PSC modules [52]. The results showed that CER exhibited both high adsorption capacity and high adsorption rate of  Pb<sup>2+</sup> in water due to the high binding energy between sulfonate-terminated groups and the common divalent metal ions like  Pb<sup>2+</sup> ,  Ca<sup>2+</sup> , and Mg<sup>2+</sup> in the mesoporous polymer matrix (Fig. 5a). Additionally, mixing the CER with carbon electrode and integrating them on the front glass of PSC modules have a negligible detrimental impact on the device PCE while reduces lead leakage from mini-modules in water by 62-fold to 14.3 ppb as compared to that of the device without CER (Fig. 5b). The theoretical calculation indicates that the CER treatment could further reduce the lead leakage of large-area perovskite solar panels to lower than 7.0 ppb even under the worst condition that all the PSC sub-modules are broken. 

### **4  Perovskite‑Based Tandem Solar Cells** 

The tunable bandgap of  ABX3 perovskite absorber from 1.2 eV to 3.0 eV benefits the design of silicon-perovskite or perovskite-perovskite tandem devices [34] that enables the theoretical efficiency beyond the Shockley–Queisser limit of single-junction solar cells. For silicon-perovskite tandems, exploiting the ideal wide-bandgap perovskite materials (1.6–1.7 eV) with suitable spectrum response matching the 1.1 eV-bandgap silicon absorber is key to obtaining high 

© The authors 

https://doi.org/10.1007/s40820-021-00672-w 

Page 9 of 18 **152** 

Nano-Micro Lett. (2021) 13:152 



<!-- Start of picture text -->
(a) (b) 8 w/o 2 °C<br>7 w/o 20 °C<br>Pb 2+ w/o 60 °C<br>w/o 85 °C<br>I − CER CER 6 w/o 2 °C<br>CH3NH3+ 5 w/o 20 °Cw/o 60 °C<br>Water O SO − O2+PbO − OS 2+OPbO − OO − S OSO OO OOS OSO − OPb − 2+ 432 w/o 85 °C<br>1<br>O S O O S O<br>O − Pb 2+ O − 0<br>0 0.5 1.0 1.5 2.0 2.5 3.0<br>Time (h)<br>Pb concentration (ppm)<br><!-- End of picture text -->

**Fig. 5  a** Illustration of how CERs prevent the lead leakage via strong ionic interaction between  Pb<sup>2+</sup> cations in broken perovskite films and the sulfonate groups. **b** Pb-soaking test results in water for the damaged perovskite solar modules without (yellow line) and with (blue line) the CER coating layer on glass side. Reproduced with permission from Ref. [50] Copyright 2020 Nature Publishing Group 

efficiency [53]. By contrast, suppressing the generation of Sn<sup>4+</sup> defects and increasing the carrier diffusion length in narrow-bandgap mixed Sn–Pb perovskites (1.1–1.2 eV) are currently the major tasks for efficient all-perovskite tandem devices. 

##### **4.1  Silicon‑Perovskite Tandem Structure** 

In the past two years, the efficiency of silicon-perovskite tandems boosted rapidly from about 25% to over 29% due to the reduced _V_ OC deficit of wide-bandgap perovskite top cell enabled by compositional engineering for a stable phase and the selection of charge transport layers [54–56]. Xu et al. [57] reported a triple-halide alloys containing chlorine, bromine, and iodine to tailor the carrier lifetime and suppress the light-induced phase segregation in wide-bandgap perovskite films. They found that direct incorporation of large amounts of Cl (more than 15%) into the double-halide perovskite could produce a uniform halide distribution throughout the film with an ideal bandgap (1.67 eV) matching the spectrum of the bottom 1.12-eV Si absorber. This effect increased the photocarrier mobility by two times and efficiently suppressed the phase separation that was previously found in most of the mixed-halide perovskite compositions [58, 59]. By extending the double-halide to triple-halide components, a distinct efficiency enhancement for opaque single-junction PSCs from 18.15% to 20.42% was demonstrated, with a _V_ OC increasing over 100 mV. Moreover, they 

obtained a PCE of 27.04% in 1-cm<sup>2</sup> two-terminal monolithic tandems via integrating the optimized perovskite top cells with the silicon bottom cells. 

Besides the modification of perovskite layer, a novel selfassembled, methyl-substituted carbazole monolayer (Me4PACz, the chemical structure is shown in Fig. 6a) was developed as the HTL to minimize the non-radiative recombination loss at the hole-selective contact in wide-bandgap PSCs [10], resulting in a record efficiency of 29.15% for Si-perovskite tandem devices. The carbazole unit provided fast hole extraction from the wide-bandgap perovskite layer and the methyl substitution was considered to passivate the defects on perovskite surface, minimizing the FF loss induced by series resistance (transport loss) and the interfacial non-radiative recombination in PSCs (Fig. 6b), as investigated by intensity-dependent absolute photoluminescence measurements. By using the Me-4PACz hole-selective layer, the FF of single-junction PSCs greatly increased from 79.8% (control cell based on PTAA) to 84.0%, and the device _V_ OC also showed a large improvement from 1.19 V to 1.25 V. 

Textured crystalline-Si subcells have also been reported for Si-perovskite tandem devices to reduce the device reflectance and increase the photon usage rate. Hou et al. [60] directly deposited the solution-processed micrometer-thick perovskite top cell on a fully textured Si-heterojunction bottom cell to fabricate tandem devices. They addressed the carrier-extraction issue in micrometer-thick perovskite layer by increasing the depletion width at the bases of silicon 

1 3 

**152** Page 10 of 18 

Nano-Micro Lett. (2021) 13:152 



<!-- Start of picture text -->
(a) (b)<br>Excitation 90 non-rad. loss non-rad. loss<br>R R PL in neat material in neat material<br>non-rad.<br>interface loss Transport loss<br>85<br>N Transport loss<br>Perovskite Solar cell FF<br>n = 2.4 80<br>HO P OH Solar cell FF<br>Glass/ITO<br>O<br>75<br>PTAA Me-4PACz<br>(c)<br>FSA<br>FA + /MA + Pb 2+ SnSn 4+2+ Sn 4+ O2 I − vacancyHalide vacancyA-site SO OO O H2N + NHOS2 O H2N + O SNHO O2<br>O2 O 2− O2 O2<br>O 2− − O O NH2<br>O HS2N + NH2 O OH2SN + NH2 H2N + OS O<br>O S NH + 2 H2N +<br>NH2<br>H2N O S<br>O<br>FSA<br>Defects and oxidation of Sn 2+ Reduction of Sn 4+  Defect passivation<br>on surface and grain boundary and antioxidation by FSA<br>(d) (e) 18 (f) C60Cu/BCP<br>Aperture area, 1.05 cm 2<br>Back cell 1.22-eV perovskite<br>15<br>Cu PEDOT:PSS<br>ALD-SnO2 12 ALD-SnO2/Au<br>C60 C60<br>9 Middle cell 1.60-eV perovskite<br>1.22-eV perovskite<br>6 NiO/PTAA<br>PEDOT-PSS ALD-SnO2/Au<br>ALD-SnOC602/Au 1 nm 3 FSA, PCE = 24.7%Control, PCE = 22.7% Front cell 1.99-eV perovskiteC60<br>1.77-eV perovskite 0 PTAA<br>0 0.4 0.8 1.2 1.6 2.0 ITO<br>NiO/VNPB<br>Glass/ITO Voltage (V) glass<br>− −<br>−<br>−<br>−<br>−<br>S<br>H2N<br>H2 + N<br>NH2<br>O<br>HN2 + − −<br>Fill factor (%)<br>−2Current density (mA cm)<br><!-- End of picture text -->

**Fig. 6  a** Schematic of the photoluminescence measurement and the chemical structure of carbazole-based HTL molecules, with R representing a methyl group for Me-4PACz. The number of 4 denotes the number of carbon atoms between the phosphonic anchoring group and the carbazole unit for Me-4PACz. **b** The FF loss mechanisms for PTAA and Me-4PACz PSCs based on the detailed balance analysis. Reproduced with permission from Ref. [10] Copyright 2021 AAAS. **c** Schematic illustration of suppressing  Sn<sup>2+</sup> oxidation and the passivation of halide and cation vacancy at the grain surface of mixed Sn–Pb perovskite films enabled by FSA molecule. A-site represents the organic monovalent cations in the lattice. **d** Structure of all-perovskite tandem device with 1.22 eV narrow-bandgap absorber and 1.77 eV wide-bandgap absorber. **e** _J-V_ curves of the best control and FSA tandem devices with an aperture area of 1.05  cm<sup>2</sup> . Reproduced with permission from Ref. [9] Copyright 2020 Nature Publishing Group. **f** Device configuration of the all-perovskite triple-junction tandem device. Reproduced with permission from Ref. [65] Copyright 2020 American Chemical Society Publications 

bottom cell and employing a self-assembled 1-butanethiol passivation layer on the perovskite surface. This strategy not only increased the carrier diffusion length but also stabilized the wide-bandgap perovskite phase, enabling a certified efficiency of 25.7%. Similarly, Chen et al. used a 

nitrogen-assisted blading process to deposit hole transport layer and high-quality planarizing perovskite absorber that fully covered the rough silicon pyramids [61]. Moreover, a textured light-scattering layer was added to the perovskite top cell to reduce reflectance at the front surface, leading 

© The authors 

https://doi.org/10.1007/s40820-021-00672-w 

Page 11 of 18 **152** 

Nano-Micro Lett. (2021) 13:152 

to an efficiency of 26.0% for textured Si-perovskite tandem devices. 

##### **4.2  All‑Perovskite Tandem Structure** 

Compared to the Si-perovskite tandems, all-perovskite tandems exhibit additional advantages of low materials and fabrication costs because the bottom and top cells can be fabricated by the same preparation process without using specific equipment for other types of solar cells. The initial two-terminal all-perovskite tandems used  MAPbBr3 and MAPbI3 as the wide-bandgap (2.30 eV) and narrow-bandgap (1.55 eV) absorbers, respectively, giving an efficiency of 10.8% [62]. 

After a few years of development, the efficiency of all-perovskite tandems has increased to over 24% via tailoring the bandgap alignment in devices. The mixed Sn–Pb perovskites with a minimized bandgap of about 1.2 eV are a promising candidate as the narrow-bandgap absorbers [63]. However, the spontaneous oxidation of  Sn<sup>2+</sup> to  Sn<sup>4+</sup> and Sn vacancy cause a high defect density in Sn–Pb perovskites and thus a shorter carrier diffusion length compared to that of the fullPb counterpart, which lowers the charge transport efficiency in the thick narrow-bandgap absorber (over 1 μm). To overcome this challenge, Lin et al. used metallic Sn to reduce the  Sn<sup>4+</sup> impurities in perovskite precursors via a comproportionation reaction (Sn +  Sn<sup>4+</sup> →  Sn<sup>2+</sup> ) [64], reducing the defect density from 1.4 ×  10<sup>16</sup> to 5.4 ×  10<sup>15</sup> cm<sup>−3</sup> and thereby prolonging the diffusion length from 0.75 to 2.99 μm in  MA0.3FA0.7Pb0.5Sn0.5I3 perovskites. After integrating this narrow-bandgap Sn–Pb PSCs (1.22 eV) with the wide-bandgap PSCs (1.77 eV), they obtained a high PCE of 24.8% for the tandem solar cells. 

To further reduce the defect density in mixed Sn–Pb perovskite, Lin et al. employed a strongly reductive surfaceanchoring molecules, formamidine sulfinic acid (FSA), to reduce the  Sn<sup>4+</sup> defects and passivate the surface ionic vacancy [9]. As shown in Fig. 6c, the sulfinic acid group could react with oxygen molecules and thus suppress the Sn<sup>2+</sup> oxidation. Meanwhile, the O atoms of sulfinic group serving as an electron donor could form coordination bond with the under-coordinated  Sn<sup>2+</sup> or  Pb<sup>2+</sup> cations to passivate the surface halide vacancy. On the other hand, the formamidine group of FSA showing similar structure with FA cation could also passivate the surface A-site vacancy defects. Such 

synergistic effect of the surface-anchoring FSA improved the carrier recombination lifetime in Sn–Pb perovskites by three times. Via employing this narrow-bandgap absorber into the monolithic tandem structure (Fig. 6d), they obtained a _V_ OC enhancement of about 60 mV and a large PCE improvement from 22.7% to 24.7% for a 1.05-cm<sup>2</sup> all-perovskite tandem (Fig. 6e). 

Furthermore, the solution-processed all-perovskite triplejunction tandem device with a PCE of over 20% was also reported [65]. This triple-junction solar cell contained a 1.99−eV perovskite at the front cell, a 1.60−eV perovskite at the middle cell, and a 1.22−eV perovskite at the back cell (Fig. 6f). By developing compatible interconnecting layers with those solution-processed perovskite absorbers, a high _V_ OC of 2.8 V can be achieved, much higher than the value of all-perovskite double-junction solar cells. 

##### **4.3  Lead‑Free PSCs** 

With the continuous movement of PSCs to commercialization, the toxicity of Pb element in perovskite absorber arouses the concern of environmental problems [66]. In recent years, a growing number of studies have aimed at developing the eco-friendly lead-free PSCs to directly avoid the use of lead in metal halide perovskite layers. So far, a number of lead-free perovskites based on tin (Sn), antimony (Sb), bismuth (Bi), titanium (Ti), germanium (Ge), and copper (Cu) have been exploited for the application of solar cells [67–71]. 

Among all the lead-free perovskite materials, the most promising candidate is tin perovskite. Sn has a similar outer electronic structure  (ns<sup>2</sup> np<sup>2</sup> ) and ionic radius to Pb, enabling the complete replacement of lead in perovskite lattice without causing notable phase segregation. Furthermore, tin perovskites demonstrate some additional advantages: (1) ideal bandgap close to Shockley–Queisser limit (1.3 ~ 1.4 eV), (2) low exciton binding energy (29 meV for  MASnI3 and 62 meV for  MAPbI3), and (3) high charge carrier mobility ( _μ_ e (electron mobility) = 2000  cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> for  MASnI3 and 60  cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> for  MAPbI3) [72, 73]. 

After a few years of development, the efficiency of tin PSCs underwent a rapid growth from 6 to 11%–13% owing to the careful design of antioxidant additives, mediating the crystallization rate, design of suitable A-site cations such as phenethylammonium (PEA) and 

1 3 

**152** Page 12 of 18 

Nano-Micro Lett. (2021) 13:152 

pentafluorophen-oxyethylammonium (FOE), and constructing the oriented low-dimensional perovskite structure [22, 74, 75]. Currently, researchers mainly focus on the defect passivation and selection of suitable electron transport layers to minimize the _V_ OC loss in tin PSCs. 

Nishimura et al. combined the bulk ethylammonium (EA) doping and surface edamine passivation to reduce the defect density of  FASnI3 perovskite films by as much as 1 order of magnitude [21], which resulted in a high device _V_ OC of 0.84 V. Furthermore, our group developed a template-growth technique assisted by an n-propylammonium iodide (PAI) salt to reduce the bulk defect density in the solution-processed  FASnI3 films [24]. The PAI post-treatment increased the electron diffusion length from 70 to 180 nm and thereby reduced the recombination loss in  FASnI3 absorbers due to the increased crystal orientation along (h00) directions (Fig. 7a), which enabled a significant _V_ OC enhancement of 200 mV and a record certified PCE of 11.22% for tin PSCs (Fig. 7b). On the other side, Jiang et al. utilized indene-C60 bis-adduct (ICBA) with a high LUMO position as the electron transport layer to reduce the energy-level offset in tin PSCs [76]. They found that a shallower LUMO of −3.74 eV in ICBA than that (−3.91 eV) of traditional [6, 6]-phenyl-C61-butyric acid methyl ester (PCBM) can upshift the quasi-Fermi level of electrons, approaching the CBM (−3.69 eV) of  FA0.85PEA0.15SnI3 perovskite (PEA represents cation) and thus improving the quasi-Fermi level splitting and the maximum attainable _V_ OC. Consequently, the ICBA-based tin PSCs obtained an ultra-high open-circuit voltage of 0.94 V, about 300 mV increasing compared to that of the PCBM-based cell, which enables a high PCE of 12.4%. The detailed PV parameters of tin PSCs reported in 2020–2021 are summarized in Table 1. 

Besides the tin PSCs, other types of lead-free PSCs based on wide-bandgap Bi and Sb perovskites also showed a large efficiency progress. Hu et al. fabricated the bulk-heterojunction perovskite active layers consisting of phase-separated Cs3Bi2I9 and  Ag3Bi2I9 to improve the grain orientation and interface band alignment [77], achieving a record efficiency of about 3.6% with a high _V_ OC reaching 0.89 V for Bi-based PSCs. Singh et al. used the indacenodithiophenebased organic acceptor with Lewis base groups to improve the morphology of wide-bandgap  Cs3Sb2I9 perovskites and enhance the electron-extraction ability in Sb-based PSCs [78], yielding a PCE of 3.25% for the inverted-structure device. 

### **5  Conclusions and Perspectives** 

In 2020 and 2021, researchers from all over the word have reported exciting progress on the improvement of efficiency and stability of PSCs, and both the solar cells and modules have been demonstrated to pass the 85 °C/85% RH test. Furthermore, the entrepreneurs in China and other countries are pushing forward the large-scale production of PSCs. Microquanta Semiconductor has established a 5GW-capacity pilot manufacturing facility for perovskite solar products, which is the first production facility for perovskite PV in the world. At the same time, GCL New Energy is building its 100 MW-capacity production line in Kunshan for fabricating the 18%-efficiency PSC modules with a decrease of 70% in production cost compared to that of the crystalline-Si. Oxford PV has recently increased the efficiency of perovskite-silicon tandem cells to 29.52% and announced that a 125 MW-capacity production line in Berlin is under 



<!-- Start of picture text -->
(b)<br>(a) I − Sn 2+ FA + NH3 + (PA + ) DMSO 20<br>Intermediate FASnI3 phase Intermediate PAI-FASnI3 phase FASnI3 (Forward)<br>15<br>FASnI3 (Reverse)<br>PAI template TG-FASnI3 (Forward)<br>10<br>TG-FASnI3 (Reverse)<br>5<br>0<br>0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7<br>Voltage (V)<br>−2Current density (mA cm)<br><!-- End of picture text -->

**Fig. 7  a** Possible mechanism of the template-growth process for  FASnI3 perovskite film. **b** _J-V_ plots of the champion tin PSCs based on control and template-growth  FASnI3 perovskite absorbers. Reproduced with permission from Ref. [24] Copyright 2020 The Royal Society of Chemistry 

© The authors 

https://doi.org/10.1007/s40820-021-00672-w 

Page 13 of 18 **152** 

Nano-Micro Lett. (2021) 13:152 

**Table 1** Photovoltaic parameters of the tin PSCs reported in 2020–2021, all the device efficiencies were measured in the third-party institutes or accredited test centers 

|Perovskite|_J_SC(mA  cm<sup>−2</sup>)|_V_OC(V)|FF (%)|PCE (%)|Test Center|Refs|
|---|---|---|---|---|---|---|
|FASnI3|21.14|0.61|73.4|9.39|AIST<sup>_a_</sup>(Japan)|[72]|
|Cs0.1FA0.9SnI3|22.21|0.64|70.8|10.08|Newport (USA)|[75]|
|PEA0.15FA0.85SnI3|17.40|0.94|75.0|12.40|SIMIT<sup>_b_</sup>(China)|[76]|
|FOE0.02FA0.98SnI3|21.95|0.64|72.5|10.16|Newport (USA)|[74]|
|FA0.75MA0.25SnI3|23.65|0.69|68.0|11.16|KISTEC<sup>_c_</sup>(Japan)|[73]|
|PA0.2FA0.8SnI3|22.01|0.70|73.3|11.22|Newport (USA)|[24]|



> _a_ AIST represents National Institute of Advanced Industrial Science and Technology 

> _b_ SIMIT represents Shanghai Institute of Microsystem and Information Technology, Chinese Academy of Science 

> _c_ KISTEC represents the Kanagawa Institute of Industrial Science and Technology 

construction for producing the perovskite-based residential rooftop panels. Moreover, Wonder Solar Ltd. continues to develop the fully printable PSC modules and has demonstrated a 110  m<sup>2</sup> power generation system outdoor. We hope that such collaboration between academia and PV industry can be further intensified to boost the commercialization of PSCs. 

Although many efforts have been done, the significantly reduced efficiency upon solar module area scaling-up is still the main challenge to face for the commercialization of PSCs. As shown in Fig. 8, the PCE decreases to 19.6% when the aperture area increases from 0.1  cm<sup>2</sup> to about 10  cm<sup>2</sup> , and further drops to 17.9% with the area approaching 1000 



<!-- Start of picture text -->
26<br>25.5% (UNIST)<br>0.095 cm 2<br>24<br>22<br>21.6% (ANU)<br>1.024 cm 2<br>20 18.6% (UNCarolina)<br>19.6% (DICP) 29.54 cm 2<br>7.92 cm 2<br>18<br>17.9% (Panasonic)<br>804 cm 2<br>16<br>0.1 1 10 100 1000<br>Aperture area (cm 2 )<br>Efficiency (%)<br><!-- End of picture text -->

**Fig. 8** The record efficiency of PSCs as a function of the aperture area in 2020. UNIST represents Ulsan National Institute of Science and Technology (Republic of Korea), ANU represents the Australian National University (Australia), DCIP represents Dalian Institute of Chemical Physics (China), UNCarolina represents the University of North Carolina at Chapel Hill (USA) 

cm<sup>2</sup> for PSCs, which still lags far behind that of the crystalline silicon cells (26.7% at 79.0  cm<sup>2</sup> and 24.4% at 13,177 cm<sup>2</sup> ) [6]. Therefore, intensive works should be conducted to precisely control the uniformity of the crystallization process in large-area perovskite films. Also, the fundamental mechanisms relative to the PCE loss in PSC modules should be further studied. On the other side, realizing open-air and high-speed coating of perovskite films is also important for reducing the module manufacturing cost in production line, and some related studies have been done. Deng et al. first demonstrated a tailoring solvent coordination method to blade large-area perovskite films with a high speed of 5.9 m  min<sup>−1</sup> under ambient condition. They used the lowvolatile, coordinating solvents for  Pb<sup>2+</sup> components to obtain high-quality perovskite films, yielding a module efficiency of 16.4% [5]. Recently, Rolston et al. reported an open-air rapid spray plasma processing method that enabled a record coating speed of 12 m  min<sup>−1</sup> without any post-annealing for CsFA-based perovskite films, which resulted in a module efficiency of 15.5% [79]. 

Furthermore, recent study showed that organic solvents used in the mass production of PSC modules such as N,N-dimethylformamide (DMF), N,N-dimethylacetamide (DMAC), N-methyl-2-pyrrolidone (NMP), and gammabutyrolactone (GBL) are toxic to the human reproductive systems [80]. Therefore, development of green solvent systems or the solvent-free deposition technology for fabricating large-area perovskite film will be an important research topic in the future [81, 82]. 

Besides the efficiency, more and more attention has been paid to the long-term stability of PSC modules. In 2020, Microquanta company announced that its mass-produced 

1 3 

**152** Page 14 of 18 

Nano-Micro Lett. (2021) 13:152 

PSC module has passed the strict stability test according to the International Electro technical Commission (IEC) standards, the 20  cm<sup>2</sup> perovskite module underwent 3000 h damp heat test without degradation, and showed an efficiency loss less than 2% after UV preconditioning test, associated with a product lifetime of over 25 years. Also, Utmo Light Ltd. reported that their PSC mini-module passed the IEC test with a stabilized efficiency of over 20%, which is a milestone for PSCs toward the practical use. Recently, Okinawa Institute of Science and Technology Graduate University (OIST, Japan) reported over 1100-h operational lifetime for a 10 × 10  cm<sup>2</sup> solar module [83]. Although many research groups and companies claimed that their devices have passed IEC standard test, there are still some stability issues needed to be addressed at the next stage, one important thing is the cell encapsulation technology. A well-designed encapsulation of PSCs should not only block the outside moisture and oxygen effectively, but also suppress the escape of volatile products and lead from the decomposed organic hybrid perovskite layer [84]. In this regard, we believe that a growing number of studies will move to exploit such multifunctional encapsulation materials in the future. 

So far, a series of stability tests custom-made for PSCs have been proposed [85], and we therefore suggest a standardized stability test for PSCs and encourage the researchers to measure the module stability at an authorized third-party test center to increase the credibility of their results. 

Development of highly efficient lead-free PSCs is also an alternative choice to extend their application range in the PV markets, especially for the indoor power generation like wearable power sources that have a strict limit on lead content [86–88]. It was demonstrated that tin PSCs could be the next generation of PSCs for realizing over 20% efficiency and the strategies for their mass production have been investigated [20]. Moreover, developing reducing solvent system for  Sn<sup>2+</sup> precursor, constructing antioxidant capping layer during the crystallization of tin perovskite film, and the investigation of compatible device encapsulation approaches also led to a large stability improvement of tin PSCs [89, 90]. In our opinion, the application of tin PSCs for indoor PV products could be prior to lead PSCs when their efficiencies reach over 15%. 

**Acknowledgements** This work was supported by the National Natural Science Foundation of China (Grant Nos. 11834011 and 12074245). Y. B. Q. acknowledges the support from the Energy 

Materials and Surface Sciences Unit of the Okinawa Institute of Science and Technology Graduate University. 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http:// creat iveco mmons. org/ licen ses/ by/4. 0/. 

### **References** 

1. Y. Wang, T. Wu, J. Barbaud, W. Kong, D. Cui et al., Stabilizing heterostructures of soft perovskite semiconductors. Science **365** (6454), 687–691 (2019). https:// doi. org/ 10. 1126/ scien ce. aax80 18 

2. Q. Jiang, Y. Zhao, X. Zhang, X. Yang, Y. Chen et al., Surface passivation of perovskite film for efficient solar cells. Nat. Photonics **13** (7), 460–466 (2019). https:// doi. org/ 10. 1038/ s41566- 019- 0398-2 

3. E.H. Jung, N.J. Jeon, E.Y. Park, C.S. Moon, T.J. Shin et al., Efficient, stable and scalable perovskite solar cells using poly(3-hexylthiophene). Nature **567** (7749), 511–515 (2019). https:// doi. org/ 10. 1038/ s41586- 019- 1036-3 

4. T. Wu, Y. Wang, Z. Dai, D. Cui, T. Wang et al., Efficient and stable  CsPbI3 solar cells via regulating lattice distortion with surface organic terminal groups. Adv. Mater. **31** (24), 1900605 (2019). https:// doi. org/ 10. 1002/ adma. 20190 0605 

5. Y. Deng, C.H. Van Brackle, X. Dai, J. Zhao, B. Chen et al., Tailoring solvent coordination for high-speed, room-temperature blading of perovskite photovoltaic films. Sci. Adv. **5** (12), eaax7537 (2019). https:// doi. org/ 10. 1126/ sciadv. aax75 37 

6. M. Green, E. Dunlop, J. Hohl Ebinger, M. Yoshita, N. Kopidakis et al., Solar cell efficiency tables (version 57). Prog. Photovoltaics **29** (1), 3–15 (2021). https:// doi. org/ 10. 1002/ pip. 3371 

7. X. Luo, T. Wu, Y. Wang, X. Lin, H. Su et al., Progress of all-perovskite tandem solar cells: the role of narrow-bandgap absorbers. Sci. China Chem. **64** (2), 218–227 (2021). https:// doi. org/ 10. 1007/ s11426- 020- 9870-4 

8. S. Gu, R. Lin, Q. Han, Y. Gao, H. Tan et al., Tin and mixed lead-tin halide perovskite solar cells: progress and their application in tandem solar cells. Adv. Mater. **32** (27), 1907392 (2020). https:// doi. org/ 10. 1002/ adma. 20190 7392 

9. K. Xiao, R. Lin, Q. Han, Y. Hou, Z. Qin et al., All-perovskite tandem solar cells with 24.2% certified efficiency and area over 1  cm<sup>2</sup> using surface-anchoring zwitterionic antioxidant. 

© The authors 

https://doi.org/10.1007/s40820-021-00672-w 

Page 15 of 18 **152** 

Nano-Micro Lett. (2021) 13:152 

Nat. Energy **5** (11), 870–880 (2020). https:// doi. org/ 10. 1038/ s41560- 020- 00705-5 

10. A. Al Ashouri, E. Köhnen, B. Li, A. Magomedov, H. Hempel et al., Monolithic perovskite/silicon tandem solar cell with >29% efficiency by enhanced hole extraction. Science **370** (6522), 1300–1309 (2020). https:// doi. org/ 10. 1126/ scien ce. abd40 16 

11. H. Su, T. Wu, D. Cui, X. Lin, X. Luo et al., The application of graphene derivatives in perovskite solar cells. Small Methods **4** (10), 2000507 (2020). https:// doi. org/ 10. 1002/ smtd. 20200 0507 

12. S. Wu, R. Chen, S. Zhang, B.H. Babu, Y. Yue et al., A chemically inert bismuth interlayer enhances long-term stability of inverted perovskite solar cells. Nat. Commun. **10** (1), 1161 (2019). https:// doi. org/ 10. 1038/ s41467- 019- 09167-0 

13. N. Arora, M.I. Dar, A. Hinderhofer, N. Pellet, F. Schreiber et al., Perovskite solar cells with CuSCN hole extraction layers yield stabilized efficiencies greater than 20%. Science **358** (6364), 768–771 (2017). https:// doi. org/ 10. 1126/ scien ce. aam56 55 

14. H. Chen, Q. Wei, M.I. Saidaminov, F. Wang, A. Johnston et al., Efficient and stable inverted perovskite solar cells incorporating secondary amines. Adv. Mater. **31** (46), 1903559 (2019). https:// doi. org/ 10. 1002/ adma. 20190 3559 

15. S. Bai, P. Da, C. Li, Z. Wang, Z. Yuan et al., Planar perovskite solar cells with long-term stability using ionic liquid additives. Nature **571** (7764), 245–250 (2019). https:// doi. org/ 10. 1038/ s41586- 019- 1357-2 

16. D. Wei, F. Ma, R. Wang, S. Dou, P. Cui et al., Ion-migration inhibition by the cation-pi interaction in perovskite materials for efficient and stable perovskite solar cells. Adv. Mater. **30** (31), 1707583 (2018). https:// doi. org/ 10. 1002/ adma. 20170 7583 

17. L. Liu, S. Huang, Y. Lu, P. Liu, Y. Zhao et al., Grain-boundary “patches” by in situ conversion to enhance perovskite solar cells stability. Adv. Mater. **30** (29), 1800544 (2018). https:// doi. org/ 10. 1002/ adma. 20180 0544 

18. N. Li, S. Tao, Y. Chen, X. Niu, C.K. Onwudinanti et al., Cation and anion immobilization through chemical bonding enhancement with fluorides for stable halide perovskite solar cells. Nat. Energy **4** (5), 408–415 (2019). https:// doi. org/ 10. 1038/ s41560- 019- 0382-6 

19. A. Mei, Y. Sheng, Y. Ming, Y. Hu, Y. Rong et al., Stabilizing perovskite solar cells to IEC61215:2016 standards with over 9,000-h operational tracking. Joule **4** (12), 2646–2660 (2020). https:// doi. org/ 10. 1016/j. joule. 2020. 09. 010 

20. T. Wu, X. Liu, X. Luo, X. Lin, D. Cui et al., Lead-free tin perovskite solar cells. Joule **5** (4), 863–886 (2021). https:// doi. org/ 10. 1016/j. joule. 2021. 03. 001 

21. K. Nishimura, M.A. Kamarudin, D. Hirotani, K. Hamada, Q. Shen et al., Lead-free tin-halide perovskite solar cells with 13% efficiency. Nano Energy **74** , 104858 (2020). https:// doi. org/ 10. 1016/j. nanoen. 2020. 104858 

22. C. Wang, Y. Zhang, F. Gu, Z. Zhao, H. Li et al., Illumination durability and high-efficiency Sn-based perovskite solar cell under coordinated control of phenylhydrazine and halogen 

ions. Matter **4** (2), 709–721 (2021). https:// doi. org/ 10. 1016/j. matt. 2020. 11. 012 

23. X. Li, F. Zhang, H. He, J.J. Berry, K. Zhu et al., On-device lead sequestration for perovskite solar cells. Nature **578** (7796), 555–558 (2020). https:// doi. org/ 10. 1038/ s41586- 020- 2001-x 

24. X. Liu, T. Wu, J.Y. Chen, X. Meng, X. He et al., Templated growth of FASnI(3) crystals for efficient tin perovskite solar cells. Energy Environ. Sci. **13** (9), 2896–2902 (2020). https:// doi. org/ 10. 1039/ d0ee0 1845g 

25. C. Zhang, Y. Wang, X. Lin, T. Wu, Q. Han et al., Effects of A site doping on the crystallization of perovskite films. J. Mater. Chem. A **9** (3), 1372–1394 (2021). https:// doi. org/ 10. 1039/ D0TA0 8656H 

26. C. Shen, Y. Wu, S. Zhang, T. Wu, H. Tian et al., Stabilizing formamidinium lead iodide perovskite by sulfonyl-functionalized phenethylammonium salt via crystallization control and surface passivation. Sol. RRL **4** (5), 2000069 (2020). https:// doi. org/ 10. 1002/ solr. 20200 0069 

27. G. Kim, H. Min, K.S. Lee, D.Y. Lee, S.M. Yoon et al., Impact of strain relaxation on performance of α-formamidinium lead iodide perovskite solar cells. Science **370** (6512), 108–112 (2020). https:// doi. org/ 10. 1126/ scien ce. abc44 17 

28. H. Min, M. Kim, S.U. Lee, H. Kim, G. Kim et al., Efficient, stable solar cells by using inherent bandgap of α-phase formamidinium lead iodide. Science **366** (6466), 749–753 (2019). https:// doi. org/ 10. 1126/ scien ce. aay70 44 

29. J. Jeong, M. Kim, J. Seo, H. Lu, P. Ahlawat et al., Pseudohalide anion engineering for α-FAPbI3 perovskite solar cells. Nature **592** (7854), 381–385 (2021). https:// doi. org/ 10. 1038/ s41586- 021- 03406-5 

30. H. Fan, F. Li, P. Wang, Z. Gu, J.H. Huang et al., Methylamineassisted growth of uniaxial-oriented perovskite thin films with millimeter-sized grains. Nat. Commun. **11** (1), 5402 (2020). https:// doi. org/ 10. 1038/ s41467- 020- 19199-6 

31. Q. Dong, Y. Fang, Y. Shao, P. Mulligan, J. Qiu et al., Electron-hole diffusion lengths >175 μm in solution-grown CH3NH3PbI3 single crystals. Science **347** (6225), 967–970 (2015). https:// doi. org/ 10. 1126/ scien ce. aaa57 60 

32. T. Wu, Y. Wang, X. Li, Y. Wu, X. Meng et al., Efficient defect passivation for perovskite solar cells by controlling the electron density distribution of donor-π-acceptor molecules. Adv. Energy Mater. **9** (17), 1803766 (2019). https:// doi. org/ 10. 1002/ aenm. 20180 3766 

33. L.K. Ono, S. Liu, Y.B. Qi, Reducing detrimental defects for high-performance metal halide perovskite solar cells. Angew. Chem. Int. Ed. **59** (17), 6676–6698 (2020). https:// doi. org/ 10. 1002/ anie. 20190 5521 

34. B. Chen, P.N. Rudd, S. Yang, Y. Yuan, J. Huang, Imperfections and their passivation in halide perovskite solar cells. Chem. Soc. Rev. **48** (14), 3842–3867 (2019). https:// doi. org/ 10. 1039/ C8CS0 0853A 

35. X. Zheng, Y. Hou, C. Bao, J. Yin, F. Yuan et al., Managing grains and interfaces via ligand anchoring enables 22.3%-efficiency inverted perovskite solar cells. Nat. Energy **5** (2), 131– 140 (2020). https:// doi. org/ 10. 1038/ s41560- 019- 0538-4 

1 3 

**152** Page 16 of 18 

Nano-Micro Lett. (2021) 13:152 

36. Q. Wang, Q. Dong, T. Li, A. Gruverman, J. Huang, Thin insulating tunneling contacts for efficient and water-resistant perovskite solar cells. Adv. Mater. **28** (31), 6734–6739 (2016). https:// doi. org/ 10. 1002/ adma. 20160 0969 

37. J. Peng, D. Walter, Y. Ren, M. Tebyetekerwa, Y. Wu et al., Nanoscale localized contacts for high fill factors in polymerpassivated perovskite solar cells. Science **371** (6527), 390–395 (2021). https:// doi. org/ 10. 1126/ scien ce. abb86 87 

38. M. Jeong, I.W. Choi, E.M. Go, Y. Cho, M. Kim et al., Stable perovskite solar cells with efficiency exceeding 24.8% and 0.3-V voltage loss. Science **369** (6511), 1615–1620 (2020). https:// doi. org/ 10. 1126/ scien ce. abb71 67 

39. J.J. Yoo, G. Seo, M.R. Chua, T.G. Park, Y. Lu et al., Efficient perovskite solar cells via improved carrier management. Nature **590** (7847), 587–593 (2021). https:// doi. org/ 10. 1038/ s41586- 021- 03285-w 

40. Y. Yuan, J. Huang, Ion migration in organometal trihalide perovskite and its impact on photovoltaic efficiency and stability. Acc. Chem. Res. **49** (2), 286–293 (2016). https:// doi. org/ 10. 1021/ acs. accou nts. 5b004 20 

41. P. Delugas, C. Caddeo, A. Filippetti, A. Mattoni, Thermally activated point defect diffusion in methylammonium lead trihalide: anisotropic and ultrahigh mobility of iodine. J. Phys. Chem. Lett. **7** (13), 2356–2361 (2016). https:// doi. org/ 10. 1021/ acs. jpcle tt. 6b009 63 

42. M.I. Saidaminov, J. Kim, A. Jain, R. Quintero-Bermudez, H. Tan et al., Suppression of atomic vacancies via incorporation of isovalent small ions to increase the stability of halide perovskite solar cells in ambient air. Nat. Energy **3** (8), 648–654 (2018). https:// doi. org/ 10. 1038/ s41560- 018- 0192-2 

43. Y.H. Lin, N. Sakai, P. Da, J. Wu, H.C. Sansom et al., A piperidinium salt stabilizes efficient metal-halide perovskite solar cells. Science **369** (6499), 96–102 (2020). https:// doi. org/ 10. 1126/ scien ce. aba16 28 

44. S.G. Motti, D. Meggiolaro, A.J. Barker, E. Mosconi, C.A.R. Perini et al., Controlling competing photochemical reactions stabilizes perovskite solar cells. Nat. Photonics **13** (8), 532–539 (2019). https:// doi. org/ 10. 1038/ s41566- 019- 0435-1 

45. K. Wang, J. Liu, J. Yin, E. Aydin, G.T. Harrison et al., Defect passivation in perovskite solar cells by cyano-based π-conjugated molecules for improved performance and stability. Adv. Funct. Mater. **30** (35), 2002861 (2020). https:// doi. org/ 10. 1002/ adfm. 20200 2861 

46. S. Xiong, J. Song, J. Yang, J. Xu, M. Zhang et al., Defectpassivation using organic dyes for enhanced efficiency and stability of perovskite solar cells. Sol. RRL **4** (5), 1900529 (2020). https:// doi. org/ 10. 1002/ solr. 20190 0529 

47. Z. Yang, J.J. Dou, S. Kou, J.L. Dang, Y.Q. Ji et al., Multifunctional phosphorus-containing lewis acid and base passivation enabling efficient and moisture-stable perovskite solar cells. Adv. Funct. Mater. **30** (15), 1910710 (2020). https:// doi. org/ 10. 1002/ adfm. 20191 0710 

48. Z. Liu, L. Qiu, L.K. Ono, S. He, Z. Hu et al., A holistic approach to interface stabilization for efficient perovskite solar modules with over 2,000-hour operational stability. 

Nat. Energy **5** (8), 596–604 (2020). https:// doi. org/ 10. 1038/ s41560- 020- 0653-2 

49. Y. Sha, E. Bi, Y. Zhang, P. Ru, W. Kong et al., A scalable integrated dopant-free heterostructure to stabilize perovskite solar cell modules. Adv. Energy Mater. **11** (5), 2003301 (2021). https:// doi. org/ 10. 1002/ aenm. 20200 3301 

50. B. Hailegnaw, S. Kirmayer, E. Edri, G. Hodes, D. Cahen, Rain on methylammonium lead iodide based perovskites: possible environmental effects of perovskite solar cells. J. Phys. Chem. Lett. **6** (9), 1543–1547 (2015). https:// doi. org/ 10. 1021/ acs. jpcle tt. 5b005 04 

51. Y. Jiang, L. Qiu, E.J. Juarez-Perez, L.K. Ono, Z. Hu et al., Reduction of lead leakage from damaged lead halide perovskite solar modules using self-healing polymer-based encapsulation. Nat. Energy **4** (7), 585–593 (2019). https:// doi. org/ 10. 1038/ s41560- 019- 0406-2 

52. S. Chen, Y. Deng, H. Gu, S. Xu, S. Wang et al., Trapping lead in perovskite solar modules with abundant and low-cost cation-exchange resins. Nat. Energy **5** (12), 1003–1011 (2020). https:// doi. org/ 10. 1038/ s41560- 020- 00716-2 

53. D. Kim, H.J. Jung, I.J. Park, B.W. Larson, S.P. Dunfield et al., Efficient, stable silicon tandem cells enabled by anionengineered wide-bandgap perovskites. Science **368** (6487), 155–160 (2020). https:// doi. org/ 10. 1126/ scien ce. aba34 33 

54. B. Chen, Z. Yu, K. Liu, X. Zheng, Y. Liu et al., Grain engineering for perovskite/silicon monolithic tandem solar cells with efficiency of 25.4%. Joule **3** (1), 177–190 (2019). https:// doi. org/ 10. 1016/j. joule. 2018. 10. 003 

55. Y. Wang, X. Liu, T. Zhang, X. Wang, M. Kan et al., The role of dimethylammonium iodide in  CsPbI3 perovskite fabrication: additive or dopant? Angew. Chem. Int. Ed. **58** (46), 16691– 16696 (2019). https:// doi. org/ 10. 1002/ anie. 20191 0800 

56. S. Gharibzadeh, B. Abdollahi Nejand, M. Jakoby, T. Abzieher, D. Hauschild et al., Record open-circuit voltage wide-bandgap perovskite solar cells utilizing 2D/3D perovskite heterostructure. Adv. Energy Mater. **9** (21), 1803699 (2019). https:// doi. org/ 10. 1002/ aenm. 20180 3699 

57. J. Xu, C.C. Boyd, Z.J. Yu, A.F. Palmstrom, D.J. Witter et al., Triple-halide wide–band gap perovskites with suppressed phase segregation for efficient tandems. Science **367** (6482), 1097–1104 (2020). https:// doi. org/ 10. 1126/ scien ce. aaz50 74 

58. I.L. Braly, R.J. Stoddard, A. Rajagopal, A.R. Uhl, J.K. Katahara et al., Current-induced phase segregation in mixed halide hybrid perovskites and its impact on two-terminal tandem solar cell design. ACS Energy Lett. **2** (8), 1841–1847 (2017). https:// doi. org/ 10. 1021/ acsen ergyl ett. 7b005 25 

59. M.C. Brennan, S. Draguta, P.V. Kamat, M. Kuno, Lightinduced anion phase segregation in mixed halide perovskites. ACS Energy Lett. **3** (1), 204–213 (2018). https:// doi. org/ 10. 1021/ acsen ergyl ett. 7b011 51 

60. Y. Hou, E. Aydin, M. De. Bastiani, C. Xiao, F.H. Isikgor et al., Efficient tandem solar cells with solution-processed perovskite on textured crystalline silicon. Science **367** (6482), 1135–1140 (2020). https:// doi. org/ 10. 1126/ scien ce. aaz36 91 

61. B. Chen, Z.J. Yu, S. Manzoor, S. Wang, W. Weigand et al., Blade-coated perovskites on textured silicon for 26%-efficient 

© The authors 

https://doi.org/10.1007/s40820-021-00672-w 

Page 17 of 18 **152** 

Nano-Micro Lett. (2021) 13:152 

   - monolithic perovskite/silicon tandem solar cells. Joule **4** (4), 850–864 (2020). https:// doi. org/ 10. 1016/j. joule. 2020. 01. 008 

62. J.H. Heo, S.H. Im,  CH3NH3PbBr3-CH3NH3PbI3 perovskiteperovskite tandem solar cells with exceeding 2.2 V open circuit voltage. Adv. Mater. **28** (25), 5121–5125 (2016). https:// doi. org/ 10. 1002/ adma. 20150 1629 

63. J. Im, C.C. Stoumpos, H. Jin, A.J. Freeman, M.G. Kanatzidis, Antagonism between spin-orbit coupling and steric effects causes anomalous band gap evolution in the perovskite photovoltaic materials  CH3NH3Sn1-xPbxI3. J. Phys. Chem. Lett. **6** (17), 3503–3509 (2015). https:// doi. org/ 10. 1021/ acs. jpcle tt. 5b017 38 

64. R. Lin, K. Xiao, Z. Qin, Q. Han, C. Zhang et al., Monolithic all-perovskite tandem solar cells with 24.8% efficiency exploiting comproportionation to suppress Sn(II) oxidation in precursor ink. Nat. Energy **4** (10), 864–873 (2019). https:// doi. org/ 10. 1038/ s41560- 019- 0466-3 

65. K. Xiao, J. Wen, Q. Han, R. Lin, Y. Gao et al., Solution-processed monolithic all-perovskite triple-junction solar cells with efficiency exceeding 20%. ACS Energy Lett. **5** (9), 2819– 2826 (2020). https:// doi. org/ 10. 1021/ acsen ergyl ett. 0c011 84 

66. M.G. Ju, M. Chen, Y. Zhou, J. Dai, L. Ma et al., Toward ecofriendly and stable perovskite materials for photovoltaics. Joule **2** (7), 1231–1241 (2018). https:// doi. org/ 10. 1016/j. joule. 2018. 04. 026 

67. B. Saparov, F. Hong, J.P. Sun, H.S. Duan, W. Meng et al., Thin-film preparation and characterization of  Cs3Sb2I9: a leadfree layered perovskite semiconductor. Chem. Mater. **27** (16), 5622–5632 (2015). https:// doi. org/ 10. 1021/ acs. chemm ater. 5b019 89 

68. D. Cortecchia, H.A. Dewi, J. Yin, A. Bruno, S. Chen et al., Lead-free  MA2CuClxBr4–x hybrid perovskites. Inorg. Chem. **55** (3), 1044–1052 (2016). https:// doi. org/ 10. 1021/ acs. inorg chem. 5b018 96 

69. T. Krishnamoorthy, H. Ding, C. Yan, W.L. Leong, T. Baikie et al., Lead-free germanium iodide perovskite materials for photovoltaic applications. J. Mater. Chem. A **3** (47), 23829– 23832 (2015). https:// doi. org/ 10. 1039/ C5TA0 5741H 

70. Z. Shao, T. Le. Mercier, M.B. Madec, T. Pauporté, Exploring AgBixI3x+1 semiconductor thin films for lead-free perovskite solar cells. Mater. Design **141** , 81–87 (2018). https:// doi. org/ 10. 1016/j. matdes. 2017. 12. 036 

71. S. Öz, J.C. Hebig, E. Jung, T. Singh, A. Lepcha et al., Zerodimensional  (CH3NH3)3Bi2I9 perovskite for optoelectronic applications. Sol. Energy Mater. Sol. C **158** , 195–201 (2016). https:// doi. org/ 10. 1016/j. solmat. 2016. 01. 035 

72. T. Wu, X. Liu, X. He, Y. Wang, X. Meng et al., Efficient and stable tin-based perovskite solar cells by introducing π-conjugated Lewis base. Sci. China Chem. **63** (1), 107–115 (2020). https:// doi. org/ 10. 1007/ s11426- 019- 9653-8 

73. T. Nakamura, S. Yakumaru, M.A. Truong, K. Kim, J. Liu et al., Sn(iv)-free tin perovskite films realized by in situ Sn(0) nanoparticle treatment of the precursor solution. Nat. Commun. **11** (1), 3008 (2020). https:// doi. org/ 10. 1038/ s41467- 020- 16726-3 

74. X. Meng, Y. Wang, J. Lin, X. Liu, X. He et al., Surface-controlled oriented growth of  FASnI3 crystals for efficient leadfree perovskite solar cells. Joule **4** (4), 902–912 (2020). https:// doi. org/ 10. 1016/j. joule. 2020. 03. 007 

75. X. Liu, Y. Wang, T. Wu, X. He, X. Meng et al., Efficient and stable tin perovskite solar cells enabled by amorphouspolycrystalline structure. Nat. Commun. **11** (1), 2678 (2020). https:// doi. org/ 10. 1038/ s41467- 020- 16561-6 

76. X. Jiang, F. Wang, Q. Wei, H. Li, Y. Shang et al., Ultra-high open-circuit voltage of tin perovskite solar cells via an electron transporting layer design. Nat. Commun. **11** (1), 1245 (2020). https:// doi. org/ 10. 1038/ s41467- 020- 15078-2 

77. W. Hu, X. He, Z. Fang, W. Lian, Y. Shang et al., Bulk heterojunction gifts bismuth-based lead-free perovskite solar cells with record efficiency. Nano Energy **68** , 104362 (2020). https:// doi. org/ 10. 1016/j. nanoen. 2019. 104362 

78. A. Singh, P.T. Lai, A. Mohapatra, C.Y. Chen, H.W. Lin et al., Panchromatic heterojunction solar cells for Pb-free all-inorganic antimony based perovskite. Chem. Eng. J. **419** , 129424 (2021). https:// doi. org/ 10. 1016/j. cej. 2021. 129424 

79. N. Rolston, W.J. Scheideler, A.C. Flick, J.P. Chen, H. Elmaraghi et al., Rapid open-air fabrication of perovskite solar modules. Joule **4** (12), 2675–2692 (2020). https:// doi. org/ 10. 1016/j. joule. 2020. 11. 001 

80. R. Vidal, J.A. Alberola-Borràs, S.N. Habisreutinger, J.L. Gimeno-Molina, D.T. Moore et al., Assessing health and environmental impacts of solvents for producing perovskite solar cells. Nat. Sustain. **4** (3), 277–285 (2021). https:// doi. org/ 10. 1038/ s41893- 020- 00645-8 

81. G. Tong, D.Y. Son, L.K. Ono, Y. Liu, Y. Hu et al., Scalable fabrication of >90  cm<sup>2</sup> perovskite solar modules with >1000 h operational stability based on the intermediate phase strategy. Adv. Energy Mater. **11** (10), 2003712 (2021). https:// doi. org/ 10. 1002/ aenm. 20200 3712 

82. H. Chen, F. Ye, W. Tang, J. He, M. Yin et al., A solvent- and vacuum-free route to large-area perovskite films for efficient solar modules. Nature **550** (7674), 92–95 (2017). https:// doi. org/ 10. 1038/ natur e23877 

83. X. Cao, G. Zhang, Y. Cai, L. Jiang, X. He et al., All green solvents for fabrication of  CsPbBr3 films for efficient solar cells guided by the hansen solubility theory. Sol. RRL **4** (4), 2000008 (2020). https:// doi. org/ 10. 1002/ solr. 20200 0008 

84. L. Shi, M.P. Bucknall, T.L. Young, M. Zhang, L. Hu et al., Gas chromatography–mass spectrometry analyses of encapsulated stable perovskite solar cells. Science **368** (6497), eaba2412 (2020). https:// doi. org/ 10. 1126/ scien ce. aba24 12 

85. M.V. Khenkin, E.A. Katz, A. Abate, G. Bardizza, J.J. Berry et al., Consensus statement for stability assessment and reporting for perovskite photovoltaics based on isos procedures. Nat. Energy **5** (1), 35–49 (2020). https:// doi. org/ 10. 1038/ s41560- 019- 0529-5 

86. M. Konstantakou, T. Stergiopoulos, A critical review on tin halide perovskite solar cells. J. Mater. Chem. A **5** (23), 11518– 11549 (2017). https:// doi. org/ 10. 1039/ C7TA0 0929A 

87. E.W.G. Diau, E. Jokar, M. Rameez, Strategies to improve performance and stability for tin-based perovskite solar cells. 

1 3 

**152** Page 18 of 18 

Nano-Micro Lett. (2021) 13:152 

ACS Energy Lett. **4** (8), 1930–1937 (2019). https:// doi. org/ 10. 1021/ acsen ergyl ett. 9b011 79 

88. J. Cao, F. Yan, Recent progress in tin-based perovskite solar cells. Energy Environ. Sci. **14** (3), 1286–1325 (2021). https:// doi. org/ 10. 1039/ D0EE0 4007J 

89. X. Meng, T. Wu, X. Liu, X. He, T. Noda et al., Highly reproducible and efficient fasni3 perovskite solar cells fabricated 

with volatilizable reducing solvent. J. Phys. Chem. Lett. **11** (8), 2965–2971 (2020). https:// doi. org/ 10. 1021/ acs. jpcle tt. 0c009 23 

90. X. He, T. Wu, X. Liu, Y. Wang, X. Meng et al., Highly efficient tin perovskite solar cells achieved in a wide oxygen concentration range. J. Mater. Chem. A **8** (5), 2760–2768 (2020). https:// doi. org/ 10. 1039/ C9TA1 3159K 

© The authors 

https://doi.org/10.1007/s40820-021-00672-w 

