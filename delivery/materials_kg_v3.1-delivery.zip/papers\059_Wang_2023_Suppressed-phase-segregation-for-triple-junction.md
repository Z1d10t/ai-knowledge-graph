# Suppressed phase segregation for triple-junction perovskite solar cells

| 字段 | 内容 |
|---|---|
| 期刊 | Nature |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 308 |
| 作者 | Zai-Wei Wang, Le-Wei Zeng, Tong Zhu, Hao Chen, Bin Chen, D. Kubicki, Adam Balvanz, Chong-Wen Li et al. |
| DOI | 10.1038/s41586-023-06006-7 |
| 源文件 | 059_Wang_2023_Suppressed-phase-segregation-for-triple-junction.pdf |

---
# **Suppressed phase segregation for triple-junction perovskite solar cells** 

https://doi.org/10.1038/s41586-023-06006-7 **Zaiwei Wang**<sup>**1,12**</sup> **, Lewei Zeng**<sup>**1,12**</sup> **, Tong Zhu**<sup>**1,12**</sup> **, Hao Chen**<sup>**1,12**</sup> **, Bin Chen**<sup>**1,2**</sup> **, Dominik J. Kubicki**<sup>**3**</sup> **, Adam Balvanz**<sup>**2**</sup> **, Chongwen Li**<sup>**1,4**</sup> **, Aidan Maxwell**<sup>**1**</sup> **, Esma Ugur**<sup>**5**</sup> **, Roberto dos Reis**<sup>**6**</sup> **,** Received: 30 October 2022 **Matthew Cheng**<sup>**6**</sup> **, Guang Yang**<sup>**7**</sup> **, Biwas Subedi**<sup>**4**</sup> **, Deying Luo**<sup>**8**</sup> **, Juntao Hu**<sup>**9**</sup> **, Junke Wang**<sup>**1**</sup> **,** Accepted: 23 March 2023 **Sam Teale**<sup>**1**</sup> **, Suhas Mahesh**<sup>**1**</sup> **, Sasa Wang**<sup>**1**</sup> **, Shuangyan Hu**<sup>**1**</sup> **, Eui Dae Jung**<sup>**1**</sup> **, Mingyang Wei**<sup>**1,10**</sup> **, So Min Park**<sup>**1**</sup> **, Luke Grater**<sup>**1**</sup> **, Erkan Aydin**<sup>**5**</sup> **, Zhaoning Song**<sup>**4**</sup> **, Nikolas J. Podraza**<sup>**4**</sup> **,** Published online: 28 March 2023 **Zheng-Hong Lu**<sup>**8,9**</sup> **, Jinsong Huang**<sup>**7**</sup> **, Vinayak P. Dravid**<sup>**6**</sup> **, Stefaan De Wolf**<sup>**5**</sup> **, Yanfa Yan**<sup>**4**</sup> **, Michael Grätzel**<sup>**10**</sup> **, Merx G. Kanatzidis**<sup>**2**</sup> **& Edward H. Sargent**<sup>**1,2,11**✉</sup> 

The tunable bandgaps and facile fabrication of perovskites make them attractive for multi-junction photovoltaics<sup>1,2</sup> . However, light-induced phase segregation limits their efficiency and stability<sup>3–5</sup> : this occurs in wide-bandgap (>1.65 electron volts) iodide/ bromide mixed perovskite absorbers, and becomes even more acute in the top cells of triple-junction solar photovoltaics that require a fully 2.0-electron-volt bandgap absorber<sup>2,6</sup> . Here we report that lattice distortion in iodide/bromide mixed perovskites is correlated with the suppression of phase segregation, generating an increased ion-migration energy barrier arising from the decreased average interatomic distance between the A-site cation and iodide. Using an approximately 2.0-electron-volt rubidium/caesium mixed-cation inorganic perovskite with large lattice distortion in the top subcell, we fabricated all-perovskite triple-junction solar cells and achieved an efficiency of 24.3 per cent (23.3 per cent certified quasi-steady-state efficiency) with an open-circuit voltage of 3.21 volts. This is, to our knowledge, the first reported certified efficiency for perovskite-based triple-junction solar cells. The triple-junction devices retain 80 per cent of their initial efficiency following 420 hours of operation at the maximum power point. 

Multi-junction solar cells offer routes to increase power conversion efficiency (PCE) by stacking multiple light-absorbing layers with complementary bandgaps and minimizing charge-carrier thermalization losses<sup>7,8</sup> . Halide perovskites with tunable bandgaps, long charge-carrier diffusion lengths, high light-harvesting efficiency and facile fabrication are compelling materials for multi-junction photovoltaics<sup>1,2,9–14</sup> . However, the challenge of light-induced phase segregation (LIPS) for wide-bandgap (>1.65 electron volts (eV)) iodide/bromide (I/Br) mixed perovskite absorbers in the top subcells limits the PCE and stability of perovskite-based multi-junction photovoltaics, especially triple-junction solar cells (TJSCs)<sup>2–4,6,15</sup> . Perovskite-based TJSCs, such as all-perovskite, perovskite/perovskite/silicon and perovskite/ perovskite/CuInGa(Se,S), have a higher theoretical PCE than their double- and single-junction counterparts<sup>2,16</sup> . Nevertheless, so far, perovskite-based TJSCs have achieved an efficiency of only 20.1%, a PCE that decreases to about 5% after 1 h of continuous operation<sup>6,17–19</sup> (Supplementary Table 1). 

We noted that most previously reported I/Br mixed perovskite compositions exhibiting suppressed LIPS have enlarged lattice distortions: these have been achieved through doping with smaller A-site cations, and also by increasing the larger X-site iodide anion content<sup>3,4,20–26</sup> . On the basis of this observation, we hypothesized that increasing lattice distortion raises the ion-migration energy barrier, thereby suppressing LIPS (Fig. 1a). For a similar range of bandgaps, caesium (Cs)-based inorganic perovskites, with a smaller A-site cation and a higher iodide anion content, have a higher degree of lattice distortion and better stability under illumination than organic–inorganic hybrid perovskites<sup>1,27,28</sup> . However, 2.0-eV-bandgap Cs-based inorganic perovskites, such as CsPbI1.4Br1.6 (Supplementary Fig. 1), as the absorber in the top subcell for perovskite-based TJSCs still face the challenge of LIPS under illumination<sup>22</sup> . 

We find that rubidium (Rb), which has a smaller cation radius than Cs, can be doped into the inorganic perovskite lattice and that the upper limit of Rb doping content is positively correlated with the Br 

> 1Department of Electrical and Computer Engineering, University of Toronto, Toronto, Ontario, Canada. 2Department of Chemistry, Northwestern University, Evanston, IL, USA. 3Department of Physics, University of Warwick, Coventry, UK.<sup>4</sup> Department of Physics and Astronomy and Wright Center for Photovoltaics Innovation and Commercialization, The University of Toledo, Toledo, OH, USA.<sup>5</sup> KAUST Solar Center (KSC), Physical Sciences and Engineering Division (PSE), King Abdullah University of Science and Technology (KAUST), Thuwal, Kingdom of Saudi Arabia. 

> 6Department of Materials Science and Engineering, Northwestern University, Evanston, IL, USA. 7Department of Applied Physical Sciences, University of North Carolina at Chapel Hill, Chapel Hill, NC, USA.<sup>8</sup> Department of Materials Science and Engineering, University of Toronto, Toronto, Ontario, Canada.<sup>9</sup> Department of Physics, Center for Optoelectronics Engineering Research, Yunnan University, Kunming, China.<sup>10</sup> Laboratory of Photonics and Interfaces, Institute of Chemical Sciences and Engineering, Ecole Polytechnique Federale de Lausanne (EPFL), Lausanne, Switzerland. ́ 11Department of Electrical and Computer Engineering, Northwestern University, Evanston, IL, USA. 12These authors contributed equally: Zaiwei Wang, Lewei Zeng, Tong Zhu, Hao Chen. ✉ e-mail: ted.sargent@utoronto.ca 



<!-- Start of picture text -->
a B(Pb) X(I) Mixed phases × Segregated phases<br>A(Cs/Rb) X(Br)<br>Barriers<br>Increased Decreased<br>lattice  distance of<br>distortion A and I<br>∠B–X–B<br>(distortion)<br>b c d<br>x  = 0.2 CsPbBr3<br>Rb0.1Cs0.9PbBr3 Rb0.1Cs0.9PbBr3<br>x  = 0.15<br>x  = 0<br>x  = 0.1<br>x  = 0.05<br>x  = 0.1 *<br>x  = 0.05<br>x  = 0.15<br>x  = 0.2 x  = 0 γ-CsPbI3<br>γ-Rb0.1Cs0.9PbI3 γ-Rb0.1Cs0.9PbI3<br>500 520 540 560 580 600 620 640 660 680 13 14 15 28 29 30 31 32<br>Wavelength (nm) 2 �  (º) Cs x Rb1– x PbI3<br>Rb x Cs1– x I Rb x Cs1– x I<br>e f<br>1.30 0 * δ<br>Rb x Cs1– x PbI1.4Br1.6<br>1.28 Rb x Cs1– x PbI1.75Br1.25<br>–0.02 Rb x Cs1– x PbI1.75Br1.25<br>1.26<br>x  = 0.7 (δ) 0.7 (γ + δ) 0.2 0.1 0 0.7 (δ) 0.2 0.1<br>1.24<br>Rb x Cs1– x PbI2Br –0.04<br>1.22 Rb x Cs1– x PbI1.75Br1.25<br>Rb x Cs1– x PbI1.5Br1.5<br>1.20 –0.06<br>0 0.05 0.10 0.15 0.20 0.25 0.30 0 0.2 0.4 0.6 0.8 1.0 300 200 100 150 100 50 0<br>Rb content Rb content 133Cs shift (ppm) 87Rb shift (ppm)<br>I rich<br>Br rich<br>Intensity (a.u.)<br>Normalized absorbance<br>(V)Voc<br>() (eV per formula) FT Δ x ,<br><!-- End of picture text -->

**Fig. 1 | Properties of Rb/Cs mixed-cation inorganic perovskites. a** , Schematic illustration of the suppression mechanism of LIPS. The hollow circles denote vacancies. **b** , **c** , UV–vis absorption spectra ( **b** ) and XRD patterns ( **c** ) of Rb _x_ Cs1− _x_ PbI1.75Br1.25 ( _x_ = 0, 0.05, 0.1, 0.15, 0.2). θ is the angle of diffraction. **d** ,<sup>133</sup> Cs and<sup>87</sup> Rb solid-state MAS NMR spectra of Rb-doped caesium lead halides recorded at 20 T, 20 kHz MAS and room temperature. The green, purple and blue lines represent pure-I, pure-Br and mixed-I/Br phases. The δ and γ symbols indicate the hexagonal non-perovskite and 3 three-dimensional perovskite 

polymorphs, respectively. The light grey labels indicate secondary phases coexisting in small quantities with the main phase. The asterisks indicate spinning sidebands. **e** , The _V_ OC as a function of Rb doping content for the single-junction solar cells of Rb _x_ Cs1− _x_ PbI2Br, Rb _x_ Cs1− _x_ PbI1.75Br1.25 and Rb _x_ Cs1− _x_ PbI1.5Br1.5. **f** , The DFT-calculated Helmholtz free energy Δ _F_ (can be treated as a thermodynamic driving force) with different Rb doping content in Rb _x_ Cs1− _x_ PbI1.4Br1.6 and Rb _x_ Cs1− _x_ PbI1.75Br1.25 (see Methods for details). _x,_ Rb content; T, temperature. T = 300 K. 

content. Rb<sup>+</sup> lattice doping widens the bandgap of inorganic perovskites, meaning that Rb/Cs solid solutions require a higher I content to achieve a bandgap of about 2.0 eV (such as Rb0.15Cs0.85PbI1.75Br1.25, compared with about 2.0 eV CsPbI1.4Br1.6). The approximately 2.0-eV Rb/Cs mixed-cation inorganic perovskites with a larger degree of lattice distortion than their Cs-based counterparts show suppressed LIPS because of the decreased average interatomic distance between the A-site cation (where A is Cs or Rb) and I, and the increased energy barrier of halide ion migration. Finally, we applied the approximately 2.0-eV Rb/Cs perovskites in all-perovskite TJSCs and achieved an efficiency of 24.3% (23.29% certified quasi-steady-state efficiency). Our all-perovskite TJSC retains 80% of its initial efficiency after 420 h of operation at maximum power point under room temperature and air mass 1.5 global (AM 1.5G) 1-sun illumination. 

### **Rb/Cs mixed-cation inorganic perovskites** 

We partially replaced Cs<sup>+</sup> with Rb<sup>+</sup> in a Cs-based I/Br mixed inorganic perovskite CsPbI1.75Br1.25. Ultraviolet–visible (UV–Vis) absorption spectra (Fig. 1b and Supplementary Fig. 2) show a gradual blueshift of the absorption edge from 631 nm for the pure Cs-based perovskite CsPbI1.75Br1.25 to 614 nm for the Rb/Cs mixed-cation perovskite Rb0.2Cs0.8PbI1.75Br1.25. From X-ray diffraction (XRD), we find that Rb 

can be doped into the CsPbI1.75Br1.25 lattice to form a pure perovskite phase in Rb _x_ Cs1− _x_ PbI1.75Br1.25 ( _x_ ≤ 0.2) films (Fig. 1c and Supplementary Fig. 2). For pure-halide Rb/Cs mixed-cation films, Rb _x_ Cs1− _x_ PbBr3 ( _x_ ≤ 0.7) and Rb _x_ Cs1− _x_ PbI3 ( _x_ ≤ 0.1) are pure perovskite phases (see Supplementary Note 1 for a detailed discussion). Thus, the upper limit of Rb lattice-doping content for retaining a pure perovskite phase is positively correlated with the Br content in these Rb/Cs mixed-cation materials. 

Solid-state nuclear magnetic resonance (NMR) spectroscopy is used to study dopants in halide perovskites<sup>29,30</sup> . We carried out solid-state magic-angle spinning (MAS) NMR measurements on materials prepared by mechanosynthesis to study the local structure of<sup>133</sup> Cs and<sup>87</sup> Rb. Upon Rb<sup>+</sup> doping of single-halide and mixed-halide inorganic perovskites, the<sup>133</sup> Cs perovskite peaks broaden and shift to higher frequencies. The 87Rb spectra show peaks corresponding to Rb+ inside the perovskite phase. These observations corroborate that Rb<sup>+</sup> can be incorporated into Cs-based inorganic perovskites (Fig. 1d, Supplementary Figs. 3–5 and Supplementary Notes 2 and 3 for a detailed discussion)<sup>29</sup> . 

Rb/Cs mixed-cation perovskites with a bandgap near 2.0 eV (Supplementary Fig. 6 and Supplementary Tables 2–4) including Rb _x_ Cs1− _x_ PbI2Br ( _x_ = 0, 0.05, 0.1, 0.15, 0.2), Rb _x_ Cs1− _x_ PbI1.75Br1.25 ( _x_ = 0, 0.05, 0.1, 0.15, 0.2, 0.25) and Rb _x_ Cs1− _x_ PbI1.5Br1.5 ( _x_ = 0, 0.1, 0.15, 0.2, 0.25, 0.3) were employed as the absorbers in perovskite solar cells (PSCs). Devices with perovskite 



<!-- Start of picture text -->
a 600 b 1,000 c 1,000<br>Time (min) Time (min) Time (min)<br>0 800 0 800 0<br>400<br>600 600<br>200 60 400 60 400 60<br>200 200<br>0<br>0 0<br>550 600 650 700 750 550 600 650 700 750 550 600 650 700 750<br>Wavelength (nm) Wavelength (nm) Wavelength (nm)<br>d f<br>X3 X2 X3 CsPbI1.4Br1.6 h 154.8<br>X5 X5 1 × 10 –8 CsPbI1.75Br1.25 151.2 Pb–Br–Pb<br>X1 X8 X1 Rb0.15Cs0.85PbI1.75Br1.25 147.6 (Rb)<br>1 × 10 –9 144.0<br>X7 X4 140.4 Pb–I–Pb<br>X4 X6 X6 1 × 10 –10 i 4.16<br>Cs–I<br>4.00<br>X5 X5<br>X1 X3 X8 X2 X3 X1 g 1 × 10 –11 0 20 40 Time (s)60 80 100 120 3.843.68 Cs–Br<br>e 20 3.52<br>j 1.25 Br→VI<br>Pb4 Pb2 15<br>Pb4 1.00<br>Br→VBr<br>Rb/Cs1 Rb/Cs2 10 0.75<br>Pb3 Pb1 Pb3 0.50 I→VBr<br>5<br>Rb/Cs3<br>Rb/Cs4 0.25<br>Pb4 Pb2 Pb4 0 I→V I<br>CsPb CsPb Rb0.15Cs0.85Pb CsPb CsPb Rb0.15Cs0.85Pb<br>I1.4Br1.6 I1.75Br1.25 I1.75Br1.25 I1.4Br1.6 I1.75Br1.25 I1.75Br1.25<br>PL intensity (counts) PL intensity (counts) PL intensity (counts)<br>angles (°)<br>Current (A) Average Pb–X–Pb∠<br>Average A–Xdistance (Å)<br>Mobile ion<br>Ion migration<br>energy barriers (eV)<br>16 –3concentration (×10)cm<br><!-- End of picture text -->

**Fig. 2 | The phenomena and mechanism of suppressed LIPS. a** – **c** , PL spectra of CsPbI1.4Br1.6 ( **a** ), CsPbI1.75Br1.25 ( **b** ) and Rb0.15Cs0.85PbI1.75Br1.25 ( **c** ) perovskite films under 1-sun AM 1.5G illumination for 60 min. **d** , **e** , The structures of the crystals from the loading compositions CsPbI1.4Br1.6 and CsPbI1.75Br1.25 ( **d** ) and Rb0.15Cs0.85PbI1.75Br1.25 ( **e** ) as viewed down the crystallographic _b_ axis. The halide positions are labelled by X (where X is I or Br), and the labelling scheme for the atoms is consistent between the two structures. The Rb, Cs, Pb, I and Br atoms are labelled in blue, yellow, grey, pink and green, respectively. The fractional occupancy of the halide sites is shown as partially filled sectors. Halide sites X1–X4 propagate in the _a_ – _c_ plane, and halide sites X5–X8 propagate down the _b_ 

axis. **f** , **g** , Transient ion-migration currents ( **f** ) and calculated mobile ion concentrations ( **g** ) of CsPbI1.4Br1.6, CsPbI1.75Br1.25 and Rb0.15Cs0.85PbI1.75Br1.25 PSCs. **h** – **j** , DFT-calculated average ∠Pb–Χ–Pb (where X is I or Br) ( **h** ), average A···X interatomic distance ( **i** ) and ion-migration energy barrier of I (or Br) to VI (or VBr) ( **j** ) for CsPbI1.4Br1.6, CsPbI1.75Br1.25 and Rb0.15Cs0.85PbI1.75Br1.25. The arrows represent their trends. For Rb0.15Cs0.85PbI1.75Br1.25, the information around the Rb atoms is labelled with stars. Owing to the supercell limitations, the real compositions used in calculations are CsPbI1.375Br1.625 (for CsPbI1.4Br1.6), CsPbI1.75Br1.25 (for CsPbI1.75Br1.25) and Rb0.125Cs0.875PbI1.75Br1.25 (for Rb0.15Cs0.85 PbI1.75Br1.25). 

absorbers of _x_ = 0.1 in Rb _x_ Cs1− _x_ PbI2Br, _x_ = 0.15 in Rb _x_ Cs1− _x_ PbI1.75Br1.25 and _x_ = 0.2 in Rb _x_ Cs1− _x_ PbI1.5Br1.5 show the highest open-current voltage ( _V_ OC) (Fig. 1e and Supplementary Tables 2–4). Among the various absorber compositions, Rb0.15Cs0.85PbI1.75Br1.25 has a bandgap of about 2.0 eV (Supplementary Table 3) and delivers the highest _V_ OC in PSCs compared with other Rb-doped inorganic perovskites with a bandgap of ≤2.0 eV (Supplementary Tables 2–4). We therefore used Rb0.15Cs0.85PbI1.75Br1.25 as our target approximately 2.0-eV Rb/Cs mixed-cation perovskite sample in the following context. We also chose a Cs-based perovskite CsPbI1.4Br1.6 with the same approximately 2.0-eV bandgap and a Cs-based perovskite CsPbI1.75Br1.25 with the same I/Br ratio as control samples compared with the target sample. 

The top-view scanning electron microscopy images in Supplementary Fig. 7 show that the CsPbI1.4Br1.6, CsPbI1.75Br1.25 and Rb0.15Cs0.85 PbI1.75Br1.25 perovskite films are uniform and pinhole-free. These films also have a low root-mean-square roughness (<26 nm), as shown in atomic force microscopy images (Supplementary Fig. 7). The energy-dispersive X-ray spectroscopy mapping and depth-profile X-ray photoelectron spectroscopy of Rb0.15Cs0.85PbI1.75Br1.25 films (Supplementary Figs. 8–10) show a uniform distribution of Rb at the surface and throughout the depth of the perovskite films. 

Density functional theory (DFT) calculations reveal a deeper Helmholtz free energy (larger thermodynamic driving force) for Rb/Cs mixed-cation perovskites with an increase in Br content (Fig. 1f). In addition, the Rb content is also correlated with the phase stability (Supplementary Figs. 4 and 5 and Supplementary Note 2 for a detailed discussion)<sup>31</sup> . Thus, we attribute the positive correlation between the upper limit of Rb doping content and the Br content in inorganic perovskites to the increase in thermodynamic driving force and the relatively stable perovskite phase in Br-rich perovskites. 

### **Suppressed LIPS** 

We carried out time-dependent photoluminescence (PL) measurements of encapsulated CsPbI1.4Br1.6, CsPbI1.75Br1.25 and Rb0.15Cs0.85 PbI1.75Br1.25 perovskite films under 1-sun illumination (AM 1.5G). The initial PL spectrum of CsPbI1.4Br1.6 shows a PL peak at 610 nm (Fig. 2a). A new lower-energy PL peak at about 680 nm appears after 10 min owing to LIPS. With the extension of illumination time, the intensity of the peak at about 680 nm increases, and simultaneously the initial peak at about 610 nm decreases in intensity. The initial PL peak of the CsPbI1.75Br1.25 film is at 630 nm, and a lower-energy PL peak at about 680 nm appears 



<!-- Start of picture text -->
a 16 b 20 c 16<br>14 18<br>16 14<br>12<br>14 12<br>10 12<br>8 10 10<br>6 8 1.4<br>6<br>4 CsPbI1.4Br1.6 4 CsPbI1.4Br1.6 1.3<br>2<br>Rb0.15Cs0.85PbI1.75Br1.25 2 Rb0.15Cs0.85PbI1.75Br1.25<br>0 0<br>0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 0 50 100 150 200 250 300 1.2<br>Voltage (V) Time (s)<br>16<br>d 10 CsPbI1.4Br1.6 e CsPbI1.4Br1.6 14<br>10 5 Rb0.15Cs0.85PbI1.75Br1.25<br>Rb0.15Cs0.85PbI1.75Br1.25 12<br>8<br>10<br>6 50 45.0 ± 0.4 100<br>45<br>10 4<br>40<br>4<br>35 31.3 ± 0.3 75<br>30<br>2 25<br>0 10 3 50<br>1.1 1.2 1.3 1.4 1.5 1.8 1.9 2.0 2.1 2.2 2.3 2.4 CsPb Rb0.15Cs0.85<br>QFLS (eV) Photon energy (eV) I1.4Br1.6 PbI1.75Br1.25<br>PCE (%)<br>PCE (%)<br>–2Current density (mA cm)<br> (V) V OC<br>–2(mA cm) J SC<br>–1(cm) ��<br>3)Counts (×10  (meV)<br>Urbach energy FF (%)<br><!-- End of picture text -->

**Fig. 3 | PV performance of 2.0-eV single-junction PSCs. a** , **b** , _J_ – _V_ curves ( **a** ) and SPO ( **b** ) of approximately 2.0-eV CsPbI1.4Br1.6 and Rb0.15Cs0.85PbI1.75Br1.25 PSCs. **c** , Statistics of PCE, _V_ OC, _J_ SC and FF of the CsPbI1.4Br1.6 devices (41 samples) and the Rb0.15Cs0.85PbI1.75Br1.25 devices (54 samples). **d** , Histogram of QFLS pixel 

values of CsPbI1.4Br1.6 and Rb0.15Cs0.85PbI1.75Br1.25 perovskites taken from larger 100 µm × 100 µm images. **e** , Near-bandgap absorption coefficient ( _α_ ) spectra from PDS for CsPbI1.4Br1.6 and Rb0.15Cs0.85PbI1.75Br1.25 thin films. Inset: Urbach energy extracted from the PDS measurements. 

after 30 min of illumination (Fig. 2b). After 60 min of illumination, the CsPbI1.75Br1.25 film shows a lower PL intensity of the peak at about 680 nm than the CsPbI1.4Br1.6 film. Our target sample, Rb0.15Cs0.85PbI1.75Br1.25, which exhibits an initial PL peak at about 616 nm, shows a negligible peak shift (less than 2 nm) and an absence of a lower-energy peak after 60 min of illumination (Fig. 2c). These results indicate that the CsPbI1.75Br1.25 films with a higher iodide content undergo weaker LIPS than do CsPbI1.4Br1.6 films, and that approximately 2.0-eV Rb/Cs mixed-cation perovskites show the best light stability among these. The spatial homogeneity of the PL peak position agrees with this finding (Supplementary Fig. 11). 

To study the mechanism of LIPS suppression in Rb/Cs mixed-cation perovskites, we grew single crystals in solid-state reactions with the loading compositions CsPbI1.4Br1.6, CsPbI1.75Br1.25 and Rb0.15Cs0.85PbI1.75 Br1.25, and analysed their single-crystal diffraction data. All compounds crystallize in a monoclinic crystal system best described by the _P_ 21/ _m_ space group (Fig. 2d,e, Supplementary Figs. 12–14, Supplementary Table 5 and Supplementary Notes 4 and 5 for a detailed discussion). These structures exist as a supercell (Supplementary Fig. 12 and Supplementary Note 4 for a detailed discussion), presumably because of the partial ordering of the halides. To our knowledge, this has not yet been reported in the literature. The single-crystal XRD data unambiguously show that Rb substitutes Cs on the A site. 

Substituting Rb at the Cs site leads to increased lattice distortions as evidenced by the decrease in the Pb–X–Pb (where X is I/Br mixed sites) bond angles (∠Pb–X–Pb) and the widening of the bandgap when comparing Rb0.15Cs0.85PbI1.75Br1.25 versus CsPbI1.75Br1.25 (Supplementary Fig. 15 and Supplementary Tables 6 and 7)<sup>32,33</sup> . The Pb–X–Pb angles in CsPbI1.75Br1.25 show a slight increasing distortion compared with those of CsPbI1.4Br1.6 (Supplementary Table 7 and Supplementary Notes 6 and 7 for a detailed discussion). 

We further estimated the concentration of mobile ions using a mobile ion charging–discharging method that has demonstrated consistency with ion-migration energy barriers<sup>34,35</sup> . The typical transient currents in devices are shown in Fig. 2f and the calculated average mobile ion 

concentrations are summarized in Fig. 2g. The mobile ion concentrations decrease from 1.45 × 10<sup>17</sup> cm<sup>−3</sup> for the CsPbI1.4Br1.6 device to 1.01 × 10<sup>17</sup> cm<sup>−3</sup> for the CsPbI1.75Br1.25 device and 7.89 × 10<sup>16</sup> cm<sup>−3</sup> for the Rb0.15Cs0.85PbI1.75Br1.25 device. 

To explore further the distortion of the I or Br sites, we analysed the DFT-relaxed structures of CsPbI1.4Br1.6, CsPbI1.75Br1.25 and Rb0.15Cs0.85PbI1.75 Br1.25. The average ∠Pb–I–Pb decreases from 143.54° for CsPbI1.4Br1.6 to 143.06° for CsPbI1.75Br1.25 and then decreases further to 143.05° for I far away from Rb and 142.39° for I close to Rb in Rb0.15Cs0.85PbI1.75Br1.25, which is indicative of increased distortion of the I site with the introduction of I or Rb (Fig. 2h and Supplementary Figs. 16 and 17). Lattice distortion results in a large variation for interatomic distances of A-site cation and X-site anion (A···X) compared with Pb···X interatomic distances (Supplementary Tables 8 and 9). Thus, we mainly focus on discussing the A···X interatomic distances in the text. The average Cs···I interatomic distance decreases from 4.04 Å for CsPbI1.4Br1.6 to 4.02 Å for CsPbI1.75Br1.25. For Rb0.15Cs0.85PbI1.75Br1.25, the average interatomic distance further decreases to 3.98 Å for Cs and I, and 3.95 Å for Rb and I (Fig. 2i and Supplementary Fig. 17). The energy barrier of I migrating to an I vacancy (VI) increases from 0.33 eV for CsPbI1.4Br1.6 to 0.40 eV for CsPbI1.75Br1.25 (Fig. 2j and Supplementary Figs. 18 and 19). In addition, the migration energy barriers for Rb0.15Cs0.85PbI1.75Br1.25 are further increased to 0.42 eV for VI far from Rb and 0.51 eV for VI close to Rb. 

The average A···I interatomic distance is longer than that of A···Br, and the migration energy barrier of I to VI is the lowest among all four studied ion-migration transitions (Fig. 2i,j). In addition, the defect formation energy of VI is lower than that of VBr based on our calculations (Supplementary Fig. 20). Thus, the migration energy barriers of these materials are dominated by that of I to VI and increase with the introduction of I and Rb. This also indicates that the most mobile ions arise from I to VI migration, consistent with previous reports<sup>34</sup> . 

Thus, we conclude that increasing the lattice distortion in I/Br mixed inorganic perovskites increases the I-site distortion. This is associated with a decrease in the average A···I interatomic distance, which 



<!-- Start of picture text -->
a b<br>12<br>Ag<br>C60/SnO2 10<br>1.22-eV perovskite<br>8<br>PEDOT:PSS Reverse Forward<br>Au 6 PCE 24.33% 24.32%<br>PCBM/PEIE/ SnO x<br>PEAI–EDAI2 V OC 3.215 V 3.210 V<br>4<br>1.6-eV perovskite J SC 9.71 mA cm –2  9.63 mA cm –2<br>NiO x ITO/PACZ 2 FF 77.93% 78.67%<br>PCBM/PEIE/SnO x<br>PEAI–EDAI2 0<br>2.0-eV perovskite 0 0.5 1.0 1.5 2.0 2.5 3.0 3.5<br>NiO x /PACZ<br>Glass/ITO Voltage (V)<br>c d Top<br>100 10.18 mA cm –2<br>10 Midddle<br>9.95 mA cm –2 Bottom<br>8 3-J perovskite cell 80 9.31 mA cm –2<br>PCE = 23.29%<br>6 V OC = 3.181 V 60<br>4 J SC = 9.61 mA cm –2 40<br>FF = 76.2%<br>2<br>20<br>0<br>0<br>0 0.5 1.0 1.5 2.0 2.5 3.0 3.5 300 400 500 600 700 800 900 1,000 1,100<br>Voltage (V) Wavelength (nm)<br>e<br>1.0<br>0.8<br>0.6 T 80 = 420 h<br>0.4<br>0.2<br>0<br>0 50 100 150 200 250 300 350 400 450<br>Time (h)<br>–2Current density ()mA cm<br>EQE (%)<br>–2Current density (mA cm)<br>Normalized PCE<br><!-- End of picture text -->

**Fig. 4 | PV performance and stability of all-perovskite TJSCs. a** , Schematic diagram of device structure and corresponding cross-sectional scanning electron microscopy image of the all-perovskite TJSC. Scale bar, 400 nm. **b** , _J_ – _V_ curves of reverse and forward scans for a champion all-perovskite TJSC. The _J_ – _V_ performances of the single-junction cells in all-perovskite triple-junction solar cells based on Ag electrodes are shown in Supplementary Table 10. 

**c** , NREL-certified quasi-steady-state _J_ – _V_ curve of the all-perovskite triple-junction device. **d** , EQE curves of the approximately 2.0-eV, approximately 1.6-eV and approximately 1.22-eV subcells within the TJSC. **e** , The maximum-power-point stability tracking of an encapsulated TJSC at room temperature under simulated AM 1.5G 1-sun illumination. T80 is the time taken for device efficiency to reduce to 80% of its initial value. 

enhances the ion-migration energy barrier and suppresses ion migration and LIPS. This conclusion also offers a more comprehensive explanation for the reported phenomena of suppressed LIPS (Supplementary Note 8 for a detailed discussion). 

### **2.0-eV single-junction PSCs** 

As approximately 2.0-eV perovskites are ideal absorbers as the top subcells in all-perovskites TJSCs, we compared the performance of approximately 2.0-eV CsPbI1.4Br1.6 and Rb0.15Cs0.85PbI1.75Br1.25 devices based on the p–i–n configuration of indium tin oxide (ITO)/nickel oxide (NiO _x_ )/ [4-(3,6-dimethyl-9H-carbazol-9-yl)butyl]phosphonic acid (Me-4PACz)/ perovskite/phenethylammonium iodide and ethane-1,2-diammonium iodide (PEAI–EDAI2)/phenyl C61 butyric acid methyl ester (PCBM)/ polyethyleneimine ethoxylated (PEIE)/tin oxide (SnO _x_ )/silver (Ag) (Supplementary Fig. 21). For the control 2.0-eV CsPbI1.4Br1.6 device, the PCE is 12.59% with a _V_ OC of 1.288 V (Fig. 3a). The PCE of the Rb0.15Cs0.85PbI1.75Br1.25 device increases to 13.41% with a _V_ OC of 1.312 V. Their stabilized power output (SPO) efficiencies are 12.1% and 13.3%, respectively (Fig. 3b). A statistical analysis of the photovoltaic parameters of 54 devices shows the reproducibility of high-performance Rb0.15Cs0.85PbI1.75Br1.25 devices 

(Fig. 3c). The Rb0.15Cs0.85PbI1.75Br1.25 device with suppressed LIPS shows improved operational stability compared with the CsPbI1.4Br1.6 device (Supplementary Fig. 21 and Supplementary Note 9 for a detailed discussion). The quasi-Fermi level splitting (QFLS) of the partially complete device stacks (ITO glass/NiO _x_ /Me-4PACz/perovskites) of these perovskites shows that the Rb0.15Cs0.85PbI1.75Br1.25 sample has a high QFLS (1.417 ± 0.004 eV) with a narrow spatial distribution compared with the CsPbI1.4Br1.6 perovskite (1.318 ± 0.054 eV) (Fig. 3d), which is indicative of reduced non-radiative recombination<sup>36</sup> . The Urbach energy values obtained from photothermal deflection spectroscopy (PDS) measurements decrease from 45 meV for CsPbI1.4Br1.6 to 31 meV for Rb0.15Cs0.85 PbI1.75Br1.25 perovskite films (Fig. 3e). This suggests decreased electronic disorder of Rb0.15Cs0.85PbI1.75Br1.25 perovskite films, consistent with suppressed LIPS and improved perovskite film quality (Supplementary Note 10 for a detailed discussion)<sup>37,38</sup> . These are correlative with the high _V_ OC observed for the Rb0.15Cs0.85PbI1.75Br1.25 device<sup>36,37</sup> . 

### **All-perovskite triple-junction solar cells** 

We further employed the approximately 2.0-eV Rb/Cs mixed-cation inorganic perovskite as the absorber for the top subcell in a monolithic 

all-perovskite TJSC. The configuration of the TJSC is ITO glass/NiO _x_ / Me-4PACz/2.0-eV inorganic perovskite (170 nm)/PEAI–EDAI2/PCBM/ PEIE/SnO _x_ /ITO/NiO _x_ /Me-4PACz/1.6-eV perovskite (780 nm)/PEAI– EDAI2/PCBM/PEIE/SnO _x/_ gold (Au)/poly(3,4-ethylenedioxythiophene) polystyrene sulfonate (PEDOT:PSS)/1.22-eV SnPb perovskite (870 nm)/ C60/SnO _x_ /Ag (Fig. 4a). Figure 4b shows the _J_ – _V_ curves of a champion all-perovskite TJSC. The PCE from the reverse scan is 24.33% with a _V_ OC of 3.215 V, a short-circuit current ( _J_ SC) of 9.71 mA cm<sup>−2</sup> and a fill factor (FF) of 77.93%. There is negligible hysteresis between the forward and reverse _J_ – _V_ scans of the device (Fig. 4b). We achieved a certified quasi-steady-state PCE of 23.29% in an accredited independent PV calibration laboratory (National Renewable Energy Laboratory (NREL); Fig. 4c and Supplementary Fig. 22), which is, to our knowledge, the first reported certified PCE for perovskite-based TJSCs. The SPO efficiency over 20 min is 24.1% (Supplementary Fig. 23). The integrated _J_ SC values for the approximately 2.0-eV, approximately 1.6-eV and approximately 1.22-eV cells from external quantum efficiency (EQE) measurements of a TJSC are 10.18 mA cm<sup>−2</sup> , 9.95 mA cm<sup>−2</sup> and 9.31 mA cm<sup>−2</sup> , respectively (Fig. 4d). The _J_ – _V_ performance from 32 devices is detailed in Supplementary Fig. 24. The efficiency of all-perovskite TJSCs will further improve through the development of new passivation strategies, improved interfacial contact and the optimization of light management (Supplementary Table 11 and Supplementary Note 11 for a detailed discussion). 

We tracked the PCE of an encapsulated device stored in a nitrogen glovebox. After 120 days, the PCE shows a negligible decline (Supplementary Fig. 23). We also monitored the performance of an encapsulated TJSC under maximum-power-point tracking conditions and continuous AM 1.5G 1-sun illumination at room temperature in an ambient atmosphere (Fig. 4e). The optimized device based on a Rb/Cs mixed-cation perovskite retains 80% of its initial PCE after 420 h of continuous operation. Further analysis shows that 2.0-eV Rb/Cs perovskites undergo phase segregation after 450 h of maximum-power-point tracking (Supplementary Fig. 25, Supplementary Table 12 and Supplementary Note 12 for a detailed discussion). These results indicate that, although Rb incorporation offers a promising route to decreased light-induced phase segregation, the topic will benefit from further study along the path to a long-term operating lifetime solution. 

8. Shockley, W. & Queisser, H. J. Detailed balance limit of efficiency of p‐n junction solar cells. _J. Appl. Phys._ **32** , 510–519 (1961). 

9. Pazos-Outon, L. M. et al. Photon recycling in lead iodide perovskite solar cells. _Science_ **351** , 1430–1433 (2016). 

10. Best research-cell efficiencies. _NREL_ https://www.nrel.gov/pv/cell-efficiency.html (2022). 11. Green, M. A. et al. Solar cell efficiency tables (version 60). _Prog. Photovolt. Res. Appl._ **30** , 687–701 (2022). 

12. Kojima, A., Teshima, K., Shirai, Y. & Miyasaka, T. Organometal halide perovskites as 

- visible-light sensitizers for photovoltaic cells. _J. Am. Chem. Soc._ **131** , 6050–6051 (2009). 

- 13. Lee, M. M., Teuscher, J., Miyasaka, T., Murakami, T. N. & Snaith, H. J. Efficient hybrid solar cells based on meso-superstructured organometal halide perovskites. _Science_ **338** , 643–647 (2012). 

14. Kim, H. S. et al. Lead iodide perovskite sensitized all-solid-state submicron thin film 

   - mesoscopic solar cell with efficiency exceeding 9%. _Sci. Rep._ **2** , 591 (2012). 

15. Xu, J. et al. Triple-halide wide-band gap perovskites with suppressed phase segregation for efficient tandems. _Science_ **367** , 1097–1104 (2020). 

16. Hörantner, M. T. et al. The potential of multijunction perovskite solar cells. _ACS Energy Lett._ **2** , 2506–2513 (2017). 

17. McMeekin, D. P. et al. Solution-processed all-perovskite multi-junction solar cells. _Joule_ **3** , 387–401 (2019). 

18. Wang, J. et al. 16.8% monolithic all-perovskite triple-junction solar cells via a universal two-step solution process. _Nat. Commun._ **11** , 5254 (2020). 

19. Zheng, J. et al. Monolithic perovskite–perovskite–silicon triple-junction tandem solar cell with an efficiency of over 20%. _ACS Energy Lett_ . **7** , 3003–3005 (2022). 

20. Muscarella, L. A. et al. Lattice compression increases the activation barrier for phase segregation in mixed-halide perovskites. _ACS Energy Lett._ **5** , 3152–3158 (2020). 

21. Rehman, W. et al. Photovoltaic mixed-cation lead mixed-halide perovskites: links between crystallinity, photo-stability and electronic properties. _Energy Environ. Sci._ **10** , 361–369 (2017). 

22. Beal, R. E. et al. Cesium lead halide perovskites with improved stability for tandem solar cells. _J. Phys. Chem. Lett._ **7** , 746–751 (2016). 

23. Brennan, M. C., Draguta, S., Kamat, P. V. & Kuno, M. Light-induced anion phase segregation in mixed halide perovskites. _ACS Energy Lett._ **3** , 204–213 (2017). 

24. Noh, J. H., Im, S. H., Heo, J. H., Mandal, T. N. & Seok, S. I. Chemical management for colorful, efficient, and stable inorganic-organic hybrid nanostructured solar cells. _Nano Lett._ **13** , 1764–1769 (2013). 

25. Yuan, Y. B. & Huang, J. S. Ion migration in organometal trihalide perovskite and its impact on photovoltaic efficiency and stability. _Acc. Chem. Res._ **49** , 286–293 (2016). 

26. Beal, R. E. et al. Structural origins of light-induced phase segregation in organic– inorganic halide perovskite photovoltaic materials. _Matter_ **2** , 207–219 (2020). 

27. Marronnier, A. et al. Anharmonicity and disorder in the black phases of cesium lead iodide used for stable inorganic perovskite solar cells. _ACS Nano_ **12** , 3477–3486 (2018). 

28. Zhou, W. et al. Light-independent ionic transport in inorganic perovskite and ultrastable Cs-based perovskite solar cells. _J. Phys. Chem. Lett._ **8** , 4122–4128 (2017). 

29. Kubicki, D. J., Stranks, S. D., Grey, C. P. & Emsley, L. NMR spectroscopy probes microstructure, dynamics and doping of metal halide perovskites. _Nat. Rev. Chem._ **5** , 624–645 (2021). 

30. Kubicki, D. J. et al. Phase segregation in Cs-, Rb- and K-doped mixed-cation (MA) _x_ (FA)1− _x_ PbI3 hybrid perovskites from solid-state NMR. _J. Am. Chem. Soc._ **139** , 14173– 14180 (2017). 

31. Xiao, J. W. et al. Stabilizing RbPbBr3 perovskite nanocrystals through Cs<sup>+</sup> substitution. _Chem. Eur. J._ **25** , 2597–2603 (2019). 

### **Online content** 

Any methods, additional references, Nature Portfolio reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41586-023-06006-7. 

1. Stoumpos, C. C., Malliakas, C. D. & Kanatzidis, M. G. Semiconducting tin and lead iodide perovskites with organic cations: phase transitions, high mobilities, and near-infrared photoluminescent properties. _Inorg. Chem._ **52** , 9019–9038 (2013). 

2. Eperon, G. E., Hörantner, M. T. & Snaith, H. J. Metal halide perovskite tandem and multiple-junction photovoltaics. _Nat. Rev. Chem._ **1** , 0095 (2017). 

3. Hoke, E. T. et al. Reversible photo-induced trap formation in mixed-halide hybrid perovskites for photovoltaics. _Chem. Sci._ **6** , 613–617 (2015). 

4. McMeekin, D. P. et al. A mixed-cation lead mixed-halide perovskite absorber for tandem solar cells. _Science_ **351** , 151–155 (2016). 

5. Abdi-Jalebi, M. et al. Maximizing and stabilizing luminescence from halide perovskites with potassium passivation. _Nature_ **555** , 497–501 (2018). 

6. Xiao, K. et al. Solution-processed monolithic all-perovskite triple-junction solar cells with efficiency exceeding 20%. _ACS Energy Lett._ **5** , 2819–2826 (2020). 

32. Stoumpos, C. C. & Kanatzidis, M. G. The renaissance of halide perovskites and their evolution as emerging semiconductors. _Acc. Chem. Res._ **48** , 2791–2802 (2015). 

33. Linaburg, M. R., McClure, E. T., Majher, J. D. & Woodward, P. M. Cs1− _x_ Rb _x_ PbCl3 and Cs1− _x_ Rb _x_ PbBr3 solid solutions: understanding octahedral tilting in lead halide perovskites. _Chem. Mater._ **29** , 3507–3514 (2017). 

34. Deng, Y. et al. Defect compensation in formamidinium–caesium perovskites for highly efficient solar mini-modules with improved photostability. _Nat. Energy_ **6** , 633–641 (2021). 

35. Eames, C. et al. Ionic transport in hybrid lead iodide perovskite solar cells. _Nat. Commun._ **6** , 7497 (2015). 

36. El-Hajje, G. et al. Quantification of spatial inhomogeneity in perovskite solar cells by hyperspectral luminescence imaging. _Energy Environ. Sci._ **9** , 2286–2294 (2016). 

37. Subedi, B. et al. Urbach energy and open-circuit voltage deficit for mixed anion–cation perovskite solar cells. _ACS Appl. Mater. Interfaces_ **14** , 7796–7804 (2022). 

38. Mahesh, S. et al. Revealing the origin of voltage loss in mixed-halide perovskite solar cells. _Energy Environ. Sci._ **13** , 258–267 (2020). 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law. 

7. Henry, C. H. Limiting efficiencies of ideal single and multiple energy gap terrestrial solar cells. _J. Appl. Phys._ **51** , 4494–4500 (1980). 

## **Methods** 

#### **Materials** 

All materials were used as received without further purification. Lead iodide (PbI2, 99.99%), lead bromide (PbBr2, 99.999%) and Me-4PACz were purchased from TCI chemicals. Caesium iodide (CsI, 99.999%), caesium bromide (CsBr, >99.9%), rubidium bromide (RbBr, 99.6%), tin(II) iodide (SnI2, 99.99%, Beads), tin(II) fluoride (SnF2, 99%), glycine hydrochloride (99%), guanidine thiocyanate (GuaSCN, 99%), EDAI2 (98%), polyethyleneimine, 80% ethoxylated solution (PEIE, 37 wt% in water), nickel(II) nitrate hexahydrate (Ni(NO3)2·6H2O, 99.999%) and sodium hydroxide (NaOH, ≥99.99%) were purchased from Sigma-Aldrich. Methylammonium iodide (MAI), formamidinium iodide (FAI), formamidinium chloride (FACl) and PEAI were purchased from GreatCell Solar Materials. PCBM (99.5%) and C60 were purchased from Nano-C. Tetrakis(dimethylamino) tin(IV) (99.99%-Sn, 50–1815 Tin) was purchased from Strem Chemicals. 

Dimethyl sulfoxide (DMSO, 99.9%), _N_ , _N_ -dimethylformamide (DMF, 99.8%), 2-propanol (IPA, 99.5%), chlorobenzene (CB, 99.8%), anisole (99.7%) and 1-propanol (99.7%) were purchased from Sigma-Aldrich. Toluene (99.8%) was purchased from Alfa Aesar. PEDOT:PSS aqueous solution (Al-4083) was purchased from Ossila. Commercial ITO substrates (20 Ω sq<sup>−1</sup> ) with 25 mm × 25 mm dimension were purchased from TFD. Quartz substrates were purchased from Shenzhen Weina Technology Electronic. 

#### **Preparation of inorganic perovskite precursor solutions** 

The precursor chemicals were mixed stoichiometrically with anhydrous dimethyl sulfoxide solvent and stirred until completely dissolved. Before use, the perovskite precursor solution was filtered through a 0.22-µm polytetrafluoroethylene (PTFE) membrane. 

FACl (FACl:Pb<sup>2+</sup> = 0.1 mmol:1 mmol) was added into the I/Br mixed precursor solutions as an additive to improve the interfacial contact of inorganic perovskite and substrate<sup>39</sup> . FACl was evaporated during the annealing process at 180 °C (Supplementary Fig. 9)<sup>40</sup> . For simplicity, we do not show the 0.1 mmol FACl additive and 1 ml DMSO in the following recipes. 

- 1 M Rb0.15Cs0.85PbI1.75Br1.25 = 0.15 mmol RbI + 0.85 mmol CsI + 0.375 

- mmol PbI2 + 0.625 mmol PbBr2 

- 1 M CsPbI1.4Br1.6 = 1 mmol CsI + 0.2 mmol PbI2 + 0.8 mmol PbBr2 

- 1 M CsPbI1.75Br1.25 = 1 mmol CsI + 0.375 mmol PbI2 + 0.625 mmol PbBr2 

- 1 M RbPbI1.75Br1.25 = 1 mmol RbI + 0.375 mmol PbI2 + 0.625 mmol PbBr2 

- 1 M CsPbI2Br = 1 mmol CsI + 0. 5 mmol PbI2 + 0.5 mmol PbBr2 

- 1 M RbPbI2Br = 1 mmol RbI + 0. 5 mmol PbI2 + 0.5 mmol PbBr2 1 M CsPbI1.5Br1.5 = 1 mmol CsI + 0. 25 mmol PbI2 + 0.75 mmol PbBr2 1 M RbPbI1.5Br1.5 = 1 mmol RbI + 0. 25 mmol PbI2 + 0.75 mmol PbBr2 For pure-Br precursor solutions, the concentration was 0.5 M without 

- additives because 1 M cannot be dissolved in DMSO. 

- 0.5 M CsPbBr3 = 0.5 mmol CsBr + 0.5 mmol PbBr2 

- 0.5 M RbPbBr3 = 0.5 mmol RbBr + 0.5 mmol PbBr2 

DMAI (DMAI:Pb<sup>2+</sup> = 1 mmol:1 mmol) was added into the following pure-I precursor solutions as an additive to promote the formation of pure-I inorganic perovskites<sup>41</sup> . DMAI was evaporated during the annealing process at 250 °C (ref. 42). For simplicity, we do not show the 1 mmol DMAI additive and 1 ml DMSO in the following recipes. 

- 1 M CsPbI3 = 1 mmol CsI + 1 mmol PbI2 

- 1 M RbPbI3 = 1 mmol RbI + 1 mmol PbI2 

Rb _x_ Cs1− _x_ PbX3 (where X is I or Br) precursor solutions can be obtained by mixing the CsPbX3 and RbPbX3 precursor solutions based on volume ratios. 

#### **NiO** **_x_ nanoparticle synthesis** 

The NiO _x_ nanoparticles were prepared by hydrolysis of nickel nitrate following previous work<sup>43</sup> . Briefly, Ni(NO3)2·6H2O (20 mmol) was dissolved in deionized water (20 ml) to obtain a dark-green solution. Then, 

NaOH aqueous solution (4 ml, 10 M) was slowly added to the dark-green solution with stirring. After stirring for 20 min, the colloidal precipitate was washed thoroughly using deionized water three times and dried at 80 °C for 6 h. The obtained green powder was then calcined at 270 °C for 2 h to obtain a black powder. The NiO _x_ nanoparticle ink was prepared by dispersing the obtained NiO _x_ nanoparticles in a mixed solution of deionized water and IPA (3:1, v/v) for a concentration of 5 mg ml<sup>−1</sup> . 

#### **Inorganic perovskite device fabrication** 

The configuration of inorganic perovskite devices was ITO glass/NiO _x_ / Me-4PACz/inorganic perovskite/PEAI–EDAI2/PCBM/PEIE/SnO _x_ /Ag. The pre-patterned ITO glasses were sequentially sonicated in acetone and IPA each for 20 min. After drying with nitrogen, the substrates were exposed to UV-ozone treatment for 20 min to remove organic contaminants. 

NiO _x_ layers were prepared by spin-coating 100 µl NiO _x_ nanoparticle solution on ITO substrates at 3,000 rpm for 25 s in the air without any post-treatment, then immediately transferred to a nitrogen-filled glovebox. 

For the Me-4PACz layer, 100 µl Me-4PACz (0.5 mg ml<sup>−1</sup> ) solution in ethanol was spin-coated on the NiO _x_ film at 3,000 rpm for 30 s in a nitrogen-filled glovebox. Then the prepared film was annealed at 100 °C for 10 min. 

For Br-based or I/Br mixed perovskite films, 100 µl inorganic perovskite precursor solution was spin-coated on the substrate at 3,000 rpm for 70 s. The film was firstly annealed at 40 °C until the colour of the film started to turn brown (5–20 s in our lab), then quickly moved to a 180 °C hotplate for 5-min annealing. For pure-I-based inorganic perovskite, 100 µl inorganic perovskite precursor solution was spin-coated on the substrate at 3,000 rpm for 70 s. Then the film was annealed at 250 °C for 5 min. 

For the PEAI–EDAI2 modified layer, the treatment solution was prepared by dissolving 1 mg PEAI and 1 mg EDAI2 into 1 ml IPA. Then 130 µl filtered solution was spin-coated on the inorganic perovskite film at 4,000 rpm for 25 s. Then the film was annealed at 100 °C for 5 min. 

For the PCBM layers, 70 µl PCBM (15 mg ml<sup>−1</sup> ) solution in CB was spin-coated on the inorganic perovskite/PEAI–EDAI2 film at 1,000 rpm for 30 s. 

For the PEIE layers, 100 µl PEIE (0.025 wt%) solution in IPA was spin-coated on the PCBM film at 4,000 rpm for 30 s. 

For the SnO _x_ layer, the film was then transferred to the atomic layer deposition system (Picosun) to deposit 20-nm SnO _x_ at 100 °C using precursors of tetrakis(dimethylamino) tin(IV) (99.9999%) and deionized water. 

The 140-nm-thick Ag electrode was deposited by thermal evaporation. 

#### **Fabrication of all-perovskite triple-junction solar cells** 

The configuration of the triple-junction solar cells was ITO/NiO _x_ / Me-4PACz/2.0-eV inorganic perovskite (170 nm)/PEAI–EDAI2/PCBM/ PEIE/SnO _x_ /ITO/NiO _x_ /Me-4PACz/1.6-eV perovskite (780 nm)/PEAI– EDAI2/PCBM/PEIE/SnO _x_ /Au/PEDOT:PSS/1.22-eV SnPb perovskite (870 nm)/C60/SnO _x_ /Ag. 

For the approximately 2.0-eV inorganic perovskite top cell, the fabrications of ITO glass, NiO _x_ , Me-4PACz, PEAI–EDAI2, PCBM, PEIE and SnO _x_ layers were the same as inorganic perovskite single-junction devices. The PEIE layer can increase the compatibility of SnO _x_ , which can protect the perovskite layer from degradation when spin-coating the following NiO _x_ and perovskite layers<sup>44</sup> . For the 2.0-eV inorganic perovskite layers, 100 µl 0.8 M Rb0.15Cs0.85PbI1.75Br1.25 inorganic perovskite precursor solution was spin-coated on the substrate at 3,000 rpm for 70 s. The film was first annealed at 40 °C for 15 s, then quickly moved to a 180 °C hotplate for 5 min. 

For the ITO layer, the top cell was then transferred to the radiofrequency magnetron sputtering system. The ITO target used in 

this study was a commercial grade of purity of >99.99% with a size of 3.00″ diameter × 0.125″ thick. The target composition was In2O3/ SnO2 90/10 wt%. The process pressure was 3 mtorr at an argon flow of 18 standard cubic centimetres per minute. The average deposition rate was about 0.24 A s<sup>−1</sup> at 33 W power. A total ITO layer thickness of 20 nm was deposited. 

For the approximately 1.6-eV perovskite middle cell, the fabrication procedures of the NiO _x_ , Me-4PACz, PEAI–EDAI2, PCBM, PEIE and SnOx layers were similar to those described above for the single-junction inorganic perovskite devices. The only difference was that the subcell was treated by plasma etching for 30 s to increase its surface wettability before spin-coating the NiO _x_ nanoparticle solution. For the 1.6-eV perovskite film, the Cs0.05FA0.9MA0.05Pb(I0.9Br0.1)3 perovskite precursor solution (1.5 M) was prepared by dissolving 0.075 mmol CsI, 0.075 mmol MABr, 1.35 mmol FAI, 0.1875 mmol PbBr2 and 1.3125 mmol PbI2 in a mixed solvent of DMF and DMSO with a volume ratio of 4:1. The perovskite precursor solution was filtered through a 0.22-µm PTFE membrane before use. Then 100 µl of perovskite solution was dropped on the substrate and spin-coated at 1,000 rpm for 10 s followed by 5,000 rpm for 30 s. Then 150 µl anisole was dropped onto the substrate at the last 5 s of the spin-coating, resulting in the formation of dark brown films that were then annealed on a hotplate at 100 °C for 10 min. 

A 1-nm-thick Au electrode was deposited by thermal evaporation. 

For the approximately 1.22-eV SnPb perovskite bottom cell, the PEDOT:PSS layer was prepared by spin-coating 100 µl diluted PEDOT:PSS solution with _n_ -propanol at a volume ratio of 1:1 on the substrate at 4,000 rpm for 30 s and then annealing at 100 °C for 15 min in ambient air. After cooling, the substrates were immediately transferred to a nitrogen-filled glovebox to deposit perovskite films. A 1.8 M SnPb perovskite precursor solution with a composition of Cs0.05FA0.7MA0.25Pb0.5Sn0.5I3-0.05SnF2 was prepared by dissolving 0.09 mmol CsI, 1.26 mmol FAI, 0.45 mmol MAI, 0.9 mmol SnI2, 0.9 mmol PbI2 and 0.09 mmol SnF2 in a 1 ml mixed solvent of DMF and DMSO with a volume ratio of 3:1. Tin powders (5 mg), GuaSCN (4 mg), 4F-PEABr (2 mg) and glycine hydrochloride (4 mg) were added to the precursor solution. The precursor solution was then stirred at room temperature for 1 h. The precursor solution was filtered using a 0.22-µm PTFE membrane before deposition. Then 70 µl of perovskite solution was deposited on the substrate and spin-coated with a two-step spin-coating procedure: 1,000 rpm for 10 s and 3,800 rpm for 45 s. Then 300 µl CB was dropped onto the substrate during the second spin-coating step at the last 20 s of the spin-coating. The substrates were then annealed at 100 °C for 10 min. Finally, 20-nm C60, 20-nm SnO _x_ and 140-nm Ag were sequentially deposited on the top of SnPb perovskite layer by organic thermal evaporation, atomic layer deposition and metal thermal evaporation, respectively. 

#### **Reporting summary** 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

### **Data availability** 

All data are available in the paper or its Supplementary Information. The crystallographic files (CIF) for the compounds reported in this work can be found as depositions in the Cambridge Crystallographic Data Centre (CCDC) based on the following deposition numbers: 2211086 (CsPbI1.46Br1.54), 2211087 (CsPbI1.73Br1.27) and 2211088 (Rb0.22Cs0.78PbI1.65 Br1.35). 

### **Code availability** 

The codes and post-analysis tools for calculations are available from the FHI-aims website: https://fhi-aims.org. 

39. Zhang, J. et al. Intermediate phase enhances inorganic perovskite and metal oxide interface for efficient photovoltaics. _Joule_ **4** , 222–234 (2020). 

40. Wang, Z. et al. Additive-modulated evolution of HC(NH2)2PbI3 black polymorph for mesoscopic perovskite solar cells. _Chem. Mater._ **27** , 7149–7155 (2015). 

41. Wang, Y. et al. Thermodynamically stabilized β-CsPbI3-based perovskite solar cells with efficiencies >18%. _Science_ **365** , 591–595 (2019). 

42. Meng, H. et al. Chemical composition and phase evolution in DMAI-derived inorganic perovskite solar cells. _ACS Energy Lett._ **5** , 263–270 (2019). 

43. Chen, H. et al. Quantum-size-tuned heterostructures enable efficient and stable inverted perovskite solar cells. _Nat. Photon._ **16** , 352–358 (2022). 

44. Palmstrom, A. F. et al. Enabling flexible all-perovskite tandem solar cells. _Joule_ **3** , 2193–2204 (2019). 

**Acknowledgements** This research was made possible by a US Department of the Navy, Office of Naval Research grant (N00014-20-1-2572), and the US Department of Energy’s Office of Energy Efficiency and Renewable Energy (EERE) under the Solar Energy Technologies Office Award Number DE-EE0008753. This work was supported in part by the Ontario Research Fund-Research Excellence programme (ORF7-Ministry of Research and Innovation, Ontario Research Fund-Research Excellence Round 7). M.G.K. was supported by the Office of Naval Research (ONR) under grant N00014-20-1-2725. At King Abdullah University of Science and Technology (KAUST), this work was supported by the under award no. OSR-2020-CRG9-4350.2. This work was also supported by the Natural Sciences and Engineering Council of Canada and the Vanier Canada Graduate Scholarship. Z.W. acknowledges the Banting Postdoctoral Fellowships Program of Canada. D.J.K. acknowledges the support of the University of Warwick. The UK High-Field Solid-State NMR Facility used in this research was funded by EPSRC and BBSRC (EP/T015063/1), as well as the University of Warwick, including via part funding through Birmingham Science City Advanced Materials Projects 1 and 2 supported by Advantage West Midlands (AWM) and the European Regional Development Fund (ERDF). The crystallographic experiments made use of the IMSERC Crystallography and Physical Characterization facilities at Northwestern University, which received support from the Soft and Hybrid Nanotechnology Experimental (SHyNE) Resource (NSF ECCS-2025633), and Northwestern University. The purchase of the Ag-microsource used to collect both single and powder diffraction data was supported by the Major Research Instrumentation Program for the National Science Foundation under the award CHE-1920248. This work also made use of the EPIC facility at Northwestern University’s NUANCE Center, which has received support from the SHyNE Resource (NSF ECCS-2025633), the IIN and Northwestern’s MRSEC programme (NSF DMR-1720139). Computations were performed on the Niagara supercomputer at the SciNet HPC Consortium. SciNet is funded by the Canada Foundation for Innovation; the Government of Ontario; Ontario Research Fund Research Excellence; and the University of Toronto. A.B. was supported, in part, by a fellowship through the National Defense Science and Engineering Graduate (NDSEG) Fellowship Program, sponsored by the Air Force Research Laboratory (AFRL), the Office of Naval Research (ONR) and Army Research Office (ARO). We thank Tao Song for efficiency certification in NREL. Z.W. thanks Yicheng Zhao, Zhenyi Ni and Emre Yengel for discussion about LIPS. A.B. acknowledges Christos D. Malliakas for assistance with the single-crystal measurements and discussions and thanks Abishek K. Iyler, Craig Laing and Michael Quintero for discussions. 

**Author contributions** Z.W. conceived the idea of this project. L.Z. and Z.W. fabricated the 2.0-eV bandgap devices and triple-junction solar cells for performance and fabricated the perovskite films for characterizations. H.C., L.Z. and Z.W. fabricated the 1.6-eV bandgap cells. L.Z., Z.W., A.M. and C.L. fabricated the 1.22-eV bandgap cells. T.Z. carried out the DFT calculations and analysed the data. H.C. prepared NiO _x_ nanoparticles and developed the surface passivation of the inorganic perovskite layers and 1.6-eV perovskite layers. B.C. helped with experimental design and data analysis. D.J.K. carried out the solid-state NMR characterization, prepared the corresponding powders and analysed the data. A.B. prepared the crystals and carried out the crystal XRD and data analysis. C.L. carried out EQE measurements. E.U. carried out the PL mapping and QFLS analysis. R.d.R. and M.C. carried out the TEM-EDS and data analysis. G.Y. measured transient ion-migration currents and carried out data analysis. B.S. performed PDS characterizations and data analysis. D.L. and J. Hu carried out the depth-profile X-ray photoelectron spectroscopy characterization and data analysis. S.D.W. carried out the atomic force microscopy characterization. L.Z. and Z.W. carried out the UV–vis measurements, XRD measurements, PL measurements, _J_ – _V_ measurements and stability measurements. Z.W. wrote the original draft. E.H.S., L.W., T.Z., D.J.K. and A.M., helped to review and edit the manuscript. E.H.S. secured funding. All the authors contributed to the discussion of the results and the final manuscript preparation. 

**Competing interests** The authors declare no competing interests. 

##### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41586-023-06006-7. 

**Correspondence and requests for materials** should be addressed to Edward H. Sargent. **Peer review information** _Nature_ thanks Michael McGehee and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. Peer reviewer reports are available. **Reprints and permissions information** is available at http://www.nature.com/reprints. 

