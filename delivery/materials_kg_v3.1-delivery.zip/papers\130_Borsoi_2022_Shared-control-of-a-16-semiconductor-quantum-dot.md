# Shared control of a 16 semiconductor quantum dot crossbar array

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Nanotechnology |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 202 |
| 作者 | F. Borsoi, N. Hendrickx, Valentin John, M. Meyer, S. Motz, F. van Riggelen, A. Sammak, S. D. de Snoo et al. |
| DOI | 10.1038/s41565-023-01491-3 |
| 源文件 | 030_Borsoi_2022_Shared-control-of-a-16-semiconductor-quantum-dot.pdf |

---
# **Shared control of a 16 semiconductor quantum dot crossbar array** 

Francesco Borsoi,<sup>1</sup> Nico W. Hendrickx,<sup>1</sup> Valentin John,<sup>1</sup> Sayr Motz,<sup>1</sup> Floor van Riggelen,<sup>1</sup> Amir Sammak,<sup>2</sup> Sander L. de Snoo,<sup>1</sup> Giordano Scappucci,<sup>1</sup> and Menno Veldhorst<sup>1</sup> 

> 1 _QuTech and Kavli Institute of Nanoscience, Delft University of Technology, P.O. Box 5046, 2600 GA Delft, The Netherlands_ 

> 2 _QuTech and Netherlands Organisation for Applied Scientific Research (TNO), 2628 CK Delft, The Netherlands_ 

The efficient control of a large number of qubits is one of most challenging aspects for practical quantum computing. Current approaches in solid-state quantum technology are based on bruteforce methods, where each and every qubit requires at least one unique control line, an approach that will become unsustainable when scaling to the required millions of qubits. Here, inspired by random access architectures in classical electronics, we introduce the shared control of semiconductor quantum dots to efficiently operate a two-dimensional crossbar array in planar germanium. We tune the entire array, comprising 16 quantum dots, to the few-hole regime and, to isolate an unpaired spin per dot, we confine an odd number of holes in each site. Moving forward, we establish a method for the selective control of the quantum dots interdot coupling and achieve a tunnel coupling tunability over more than 10 GHz. The operation of a quantum electronic device with fewer control terminals than tunable experimental parameters represents a compelling step forward in the construction of scalable quantum technology. 

Keywords: Semiconductor quantum dots, crossbar array, germanium, spin qubits 

Fault-tolerant quantum computers will require millions of interacting qubits [1–3]. Scaling to such extreme numbers imposes stringent conditions on all the hardware and software components, including their integration [4]. In semiconductor technology, decades of advancements have led to the integration of billions of transistor components on a single chip. A key enabler has been the ability to control such a large number of components with only a few hundred to a few thousand control lines [5, 6]. In quantum technology, such a game-changing strategy has yet to be embraced owing to the fact that qubits are not sufficiently similar to each other. Nowadays, leading efforts in solid state, such as superconducting and semiconducting qubits, all require that each and every qubit component is connected to at least one unique control line [7]. Clearly, this brute-force approach is not sustainable for attaining practical quantum computation. The development of spin qubits in semiconductor quantum dots has strongly been inspired by classical semiconductor technology [8–10]. Advanced semiconductor qubit systems are based on CMOS compatible materials and even foundry manufactured qubits have been realised [11, 12]. In addition, it is anticipated that the small qubit footprint and compatibility with (cryo)CMOS electronics will open up avenues to build integrated quantum circuits [13, 14]. To enable the efficient control of larger qubit architectures with a sustainable number of control lines, proposals of architectures inspired by classical random access systems have been put forward [15, 16]. However, their practical realisation has been so far prevented by device quality and material uniformity. 

Here, we take the first step toward the sustainable control of large quantum processors by operating semiconductor quantum dots in a crossbar architecture. This strategy enables the manipulation of the most extensive 

semiconductor quantum device with only a few sharedcontrol terminals. This is accomplished by exploiting the high quality and uniformity of strained germanium quantum wells [17], by introducing an elegant gate layout based on diagonal plunger lines and double barrier gates, and by establishing a method that directly maps the transitions lines of charge stability diagrams to the associated quantum dots in the grid. We operate a twodimensional 16 quantum dot system and demonstrate the tune-up of the full device to the few-hole regime. In this configuration, we also prove the ability to prepare all the quantum dots in the odd charge occupation, as a key step for the confinement of an unpaired spin in each site [18, 19]. We then introduce a random access method for addressing the interdot tunnel coupling and find a remarkable agreement in the response of two verticallyand horizontally-coupled quantum dot pairs. We also discuss some critical challenges to efficiently operating future large quantum circuits. 

### **I. A TWO-DIMENSIONAL QUANTUM DOT CROSSBAR ARRAY** 

Our shared-terminals control approach for a twodimensional quantum dot array with dots Q1, Q2t,...Q7 is based on a multi-layer gate architecture (Figs. 1a-d). We use two barrier layers (with gates UB _i_ and LB _i_ with _i ∈_ [1 _,_ 8]) to control the interdot tunnel couplings, and exploit a layer of plunger lines (P _i_ with _i ∈_ [1 _,_ 7]) to vary the on-site energies (Fig. 1d). In contrast to brute-force implementations, a single plunger gate is here employed to control up to four quantum dots, and an individual barrier up to six nearest-neighbours interactions. In analogy with classical integrated circuits, this strategy enables to manage a number of experimental parameters (i.e., dot 

2 



<!-- Start of picture text -->
a<br><!-- End of picture text -->





<!-- Start of picture text -->
b d P1 P2 P3 P4<br>P5<br>Q1 Q2t Q3t Q4t<br>P6<br>P7<br>Q2b Q3m Q4mt Q5t<br>LB1 LB2 LB3 LB4<br>LB5<br>Q3b Q4mb Q5m Q6t LB6<br>LB7<br>LB8<br>Q4b Q5b Q6b Q7<br>UB5 UB6 UB7 UB8<br>c<br>UB4<br>UB3<br>Si0.2Ge0.8 UB2<br>Ge<br>Si0.2Ge0.8 UB1<br><!-- End of picture text -->

FIG. 1. **A 16 quantum dot crossbar array. a,** False-colour scanning electron microscopy image of the crossbar array device. The architecture consists of two staircase barrier gate layers (two lines of each layer are shown in red and blue), and one plunger gate layer (two lines are illustrated in green). 16 quantum dots are defined under the plungers, while four charge sensors in the form of single-hole transistors are located at the corners (ohmic contacts in orange, barriers in dark green, and plungers in yellow). The scale bar corresponds to 100 nm, which is also the size of the designed plunger gates diameter. This shared-control approach enables to control a number of quantum dots ( _g_ ) with a sublinear number of control terminals ( _T_ ). Here, the scaling is given by _T_ = 6 _g_<sup>1</sup><sup>_/_2</sup> _−_ 1 (Suppl. Fig. 1). **b,** Schematic illustration of the device and labelling of each quantum dot. We choose to label the quantum dots after their positions on their controlling plunger line, e.g., the quantum dot Q6b(t) is located on the bottom (top) site controlled by the plunger line P6. **c,** Schematic cross-section of the device. Holes are isolated in quantum dots in a 55 nm-deep germanium quantum well in a silicon-germanium heterostructure grown on a silicon wafer. **d,** Shared-control elements: from the bottom of the gate stack, eight UB barrier gates, eight LB barrier gates and seven P plunger gates. The overlay of these layers is visible in **(b)** . 

energies and interdot couplings) with a sub-linear number of control terminals, an approach that may overcome, among other aspects, the wiring interconnect bottleneck of large-scale spin qubit arrays (Suppl. Fig. 1) [6, 7]. To monitor the quantum dot array, we make use of charge sensing techniques [18]. Four single-hole transistors at the corners of the array (named after their cardinal positions: NW as north-west, NE as north-east, SW as southwest and SE as south-east) act as charge sensors as well as holes reservoirs for the array. The simultaneous readout of their electrical response in combination with fast rastering pulse schemes enables us to continuously measure two-dimensional charge stability diagrams in real time (Methods) [20, 21]. 

To bring the device in the 16 quantum dots configuration, we identify an alternative strategy to the tune-up methods established for individually-controlled quantum dot devices [22]. We begin by lowering all gate voltages to starting values based on previous experiments (Methods). We set up the four independent charge sensors (Suppl. Fig. 2) and start defining a set of virtual gates as linear combinations of real gates [22–24]. Throughout our work, we refer to vP1,..., vP7, vUB1,..., vUB8, vLB1,..., vLB8 as the virtual gates associated to the actual gates P1,..., P7, UB1,..., UB8, LB1,..., LB8 (Methods and Suppl. Fig. 3). By further adjusting the respec- 

tive virtual plunger and barrier voltages, we then accumulate the first holes in the quantum dots at the four corners of the array. Once clear charge addition lines are detected in the charge stability diagrams, we proceed with the tune-up of the adjacent dots and finish with the quantum dots furthest to the sensor. Owing to the homogeneity of our heterostructure [25] and the symmetry of our gate layout, the accumulation of the first few holes in quantum dots controlled by the same plungers occurs at similar gate voltages. 

Rather, challenges in the tuning up the array that we encounter are mainly due to elements outside the array. In fact, we observe that small variations of the gate voltages impact the electrostatics of the dense gate fanout area, which in turn affects the charge sensors and the readout quality. Furthermore, specific gate settings cause unintentional quantum dots under the gate fanout, which restrict the operational window. Altogether, these issues are a challenge for the implementation of automated tuning methods [26]. We envision that the integration of a lower layer of “screening” gates or the implementation of the gate fanout in the third dimension [27] can mitigate this issue (Suppl. Note 4). 

3 



<!-- Start of picture text -->
a<br>Q3m<br>Q3b<br>Q2t<br>Q2b<br>b c λvUB, λvLB d<br>vUB vLB<br><!-- End of picture text -->

FIG. 2. **From multi-dot charge stability diagrams to quantum dots identification. a,** Few-hole charge stability diagram obtained by combining the signal gradients of the SW and NW charge sensors. The labels indicate for each addition line the corresponding quantum dot. At (0,0) the fillings of Q2t, Q2b, Q3t, Q3m, Q3t are 0, 0, 0, 3, 0, respectively. **b,** Histograms of the (normalized) capacitive couplings _λ_ of the barrier gates to the transition lines (in red for the vUB, and in blue for the vLB virtual gates) obtained by analysing three different sets of transition lines coupled to the virtual plunger vP3. Middle and bottom panels are extracted from the shift of the transition lines at _∼_ (-20, -63) and (-15, -7) in **a** , respectively. The top panel (relative to dot Q3t) is obtained from a measurement shown in Suppl. Figs. 6g,h, where the transition line is more visible. We find that due to the order in the gate stack, the capacitive coupling of the vUB gates is a factor of 2-3 higher than of the vLB gates. Red and blue backgrounds are added to emphasize the two barriers with the highest couplings. **c,** Device layout with the capacitive couplings colour-coded on the filling of the gate lines. Here, both the vUB and vLB capacitive couplings, _λ_ vUB and _λ_ vLB, are normalized to their maximum values. At an intuitive level, the quantum dot associated with the analysed transition lines is located at the intersection of the two intensely coloured red and blue lines. **d,** Visualisation of the probability ( _W_ ) calculated from of the shift of the three sets of addition lines (see Methods for details). The comparison of the top, middle and bottom panels of **b, c, d** clearly distinguishes the three Q3 quantum dots (full analysis in Suppl. Figs. 4 and 5). 

### **II. FROM MULTI-DOT CHARGE STABILITY DIAGRAMS TO QUANTUM DOTS IDENTIFICATION** 

Moving forward, a direct result of our control approach is the fact that, upon sweeping the voltage of a plunger gate controlling _n_ quantum dots, up to _n_ sets of charge transitions can be observed, each associated with (un)loading an additional hole in one of the _n_ quantum dots. For the case of the two shared virtual plungers vP2 and vP3, this results in the charge stability diagram shown in Fig. 2a where a number of vertical and horizontal charge addition lines marking well separate charge states are visible. However, because of our control approach, a priori it is unknown to which of the Q3 (Q2) quantum dots these vertical (horizontal) lines are associated. 

Here, we solve this problem by establishing a statistical method that maps such transition lines to the respective quantum dot. In our protocol, we first evaluate the shift of the charge transition lines induced by a voltage variation of each barrier gate to estimate the (normalized) capacitive coupling _λ_ between each barrier gate and the associated quantum dot (Figs. 2b, c and Methods). Because the two barrier layers form a grid of lines and columns crossing the device, we then use their capacitive couplings to infer the spatial location of the quantum dot in the array. For this purpose, we consider the normalised capacitive couplings of the two orthogonal barrier sets, _λ_ vUB and _λ_ vLB, as two independent probability distributions. We then use _λ_ vUB and _λ_ vLB to calculate the combined probability _W_ on each of the 16 sites (Fig. 2d, Methods). Finally, our protocol ends assigning the site with the maximum probability to the quantum dot loaded via the specific charge addition lines. In practice, _W_ quantifies how much an electric field generated on each site is perceived by a hole in a specific quantum dot site. Hence, a low (high) _W_ value identifies a location that is weakly (strongly) coupled to the analysed quantum dot. 

In Figs. 2b-d, we show how this routine is effective for distinguishing and characterising the three Q3 quantum dots, whereas similar results are obtained also for the remaining dots in the grid (Suppl. Figs. 4 and 5). The demonstrated ability of labelling multi-quantum dot charge stability diagrams makes this method an important tool in the tune-up of large quantum dot devices. We note that we can obtain further confirmation of our identification by also considering other aspects, such as the different sensitivity of the charge sensors to the same set of charge addition lines (e.g. compare Suppl. Figs. 6e, j, c). 

### **III. QUANTUM DOT OCCUPANCIES** 

Whilst useful in reducing drastically the number of control terminals, a crossbar approach is effective for 

4 

spin-based quantum computing if it enables to isolate a single or an unpaired spin in the individual quantum dots [8, 16]. Here, by harnessing the low disorder of the heterostructure and the symmetry of our design, we demonstrate the tune-up of the array to an odd charge occupancy configuration with 11 quantum dots filled with one hole, and five quantum dots filled with three holes (Fig. 3b). Figs. 3a,c-l present a set of charge stability diagrams where the transition lines of each quantum dots are shown and labelled at least once. Importantly, at the centre of the panels (i.e., ∆vP _i_ = 0, with _i ∈_ [1 _,_ 7]), each quantum dot is filled with an odd number of holes, hence with an unpaired hole spin (Methods). We note that holes in quantum dots that are located in the core of the array are loaded/unloaded by means of cotunneling processes via the outer dots [28]. When such reservoirdot tunnelling timescale becomes long and approaches the timescale of our measurement scan ( _∼_ 0 _._ 01 s), the quantum dots transition lines become weakly visible in the charge stability diagrams and appear distorted due to latching effects, explaining some of the features observed in Figs. 3h, i, k. [29, 30]. Additional reservoirs within the array may therefore simply the tune-up, though for quantum operation is it not critical to have each and every dot strongly coupled to a reservoir [6, 10]. 

### **IV. INTERDOT COUPLINGS CONTROL** 

The ability to selectively tune the interdot coupling in a quantum dot architecture is crucial for generating exchange-based entanglement between semiconductor qubits [8]. Here, inspired by the word and bitlines approach as in dynamic random-access memories [13, 16], we exploit the double barrier design to spatially define and activate unique points in the grid structure. Conceptually, each two-barrier intersection point can be set by the respective voltages in the four configurations: (ON, ON), (ON, OFF), (OFF, ON), (OFF, OFF). For selective two-qubit operations in qubit arrays, the voltage set points should be calibrated such that only when both barriers are in the ON-state a two-qubit interaction is activated, leaving all the other pairs non-interacting (Suppl. Fig. 7). 

Here, we implement a proof-of-principle of this method by demonstrating the two-barrier control of the interdot tunnel coupling. To this end, we investigate the tunnel coupling variations of the horizontal Q6b-Q7 and vertical Q6t-Q7 quantum dot pairs as a function of the two intersecting barriers. Starting from the respective UB4 and LB7 gates, we define the virtual barriers t6b7 and j6b7 (Methods), which separate the quantum dots Q6b and Q7, while keeping their detuning (e67) and on-site (U67) voltages constant at the (3,1)-(2,2) Q6b-Q7 interdot transition (Fig. 4a). After obtaining the detuning lever arm _αϵ_ 67 to convert the detuning voltage into an energy scale (∆ _ϵ_ 67 = _αϵ_ 67 _·_ ∆e67), we evaluate the 



<!-- Start of picture text -->
a b c<br>1 1 1 1<br>1 3 1 3<br>3 1 3 1<br>1 1 3 1<br>d e f<br>g h i<br>j k l<br><!-- End of picture text -->

FIG. 3. **Few and odd charge occupancy in a crossbar array. a, c-l,** Charge stability diagrams displaying the sensor signals (after subtraction of a slowly-varying background) showcasing the 16 quantum dot system. At the centre of all the maps (∆vP _i_ = 0 with _i ∈_ [1 _,_ 7]), all the quantum dots are set in a odd occupancy regime. In each map, the first visible transition lines from the right and the top are labelled and assigned to the relative quantum dot by dashed lines (as guides for the eyes) with colours defined as in the schematic above each panel. The colour of the panel frame identifies the sensor used: NW in red, NE in blue, SW in green, and SE in ochre. Preparing the system in such a configuration results in the occupation of unintentional quantum dots under the fanout, which mostly do not interact with the dots inside the array (e.g. see horizontal transition in ( **a** ) at ∆vP1 = -50 mV and the periodical pattern in **(e)** ). **b,** Schematic with the shared plungers layout together with quantum dot hole fillings, as monitored by the four charge sensors depicted as four eyes. 

5 



<!-- Start of picture text -->
a t6b7 f t6t7<br>j6b7<br>j6t7<br>b c g h<br>d e i j<br><!-- End of picture text -->

FIG. 4. **Addressable control of the interdot tunnel coupling using double barrier gates. a, f** Schematics of the crossbar indicating the two intersecting barriers (in red and blue) controlling the Q6b-Q7 and Q6t-Q7 interdot tunnel couplings, respectively. **b, g** Exemplary charge stability diagrams taken via reflectometry methods showing the Q6b-Q67 and Q6t-Q7 (3,1)-(2,2) charge states at four different virtual barrier voltages configurations, respectively. At the centre of the panels, the vertical interdot transition line is clearly visible. The circle, square, diamond, and triangle markers correlate each map to the voltages, (t6b7 _,_ j6b7) = (t6t7 _,_ j6t7) = _−_ (330 _,_ 380) _,_ (270 _,_ 380) _,_ (330 _,_ 510) _,_ (270 _,_ 510) mV, respectively. **c, h** Charge polarisation traces (black) relative to panels **(b, g)** , together with best fit (dashed grey). **d, i** Colour maps of the two-axis controlled tunnel couplings of the systems Q6b-Q7 and Q6t-Q7, with markers located at the respective voltages. **e, j** Vertical (left panel) and horizontal (right panel) linecuts of **(d)** and **(i)** at t6b7 = t6t7 = _−_ 330 mV and j6b7 = j6t7 = _−_ 510 mV, respectively. Grey traces are fits with an exponential function of the data, from which we obtain the four effective barrier lever arms (Methods). 

strength of the interdot couplings by analysing the charge polarisation lines along the detuning axis at ∆U67 = 0 (Figs. 4b, c) [31]. By performing this measurement systematically, we demonstrate that the tunnel coupling can be controlled effectively by both barriers (Figs. 4d,e). At values of (t6b7 _,_ j6b7) = ( _−_ 270 _, −_ 380) mV, the coupling is virtually OFF, but our method is inherently not accurate for _tc ≤_ 3 GHz, because the thermal energy dominates the broadening of the polarisation line [29, 31]. In contrast, upon activating both barriers at (t6b7 _,_ j6b7) = ( _−_ 330 _, −_ 510) mV, the tunnel coupling is turned on following approximately an exponential trend (Methods). Within the displayed voltage range, we can tune it well above 10 GHz, much higher than in the configuration in which only one barrier is activated. We perform the 

same experiment on the dots pair Q6t-Q7 by defining the virtual barriers t6t7 and j6t7 based on the gates UB5 and LB7, respectively (Fig. 4f and Methods). Using the same barrier voltages window as for Q6b-Q7, we find that the coupling tunability of the pair Q6t-Q7 is comparable to the previous pair, with a virtually OFF state ( _≤_ 3 GHz) at (t6t7 _,_ j6t7) = ( _−_ 270 _, −_ 380) mV, and with a ON state reaching 20 GHz at (t6t7 _,_ j6t7) = ( _−_ 330 _, −_ 510) mV (Figs. 4g-j). These results are corroborated by the two-barrier tunability of the interdot capacitive coupling for both double-dot systems (Suppl. Fig. 8) and by the tunability of another dot pair (Suppl. Fig. 9). We envision that for rapid qubits exchange operations at the charge symmetry point, the required barrier voltage window might be different from our measurable window via 

6 

polarisation lines. Specifically, for state-of-the-art values of ON (OFF) exchange interaction of 50 MHz (10 KHz) and a typical charging energy of 1 mV, the required tunnel coupling is _∼_ 2 (0.02) GHz, which can be better calibrated via qubit spectroscopy techniques [20, 32, 33]. 

### **V. CONCLUSIONS** 

While semiconductor technology has gained credibility as a platform for large-scale quantum computation, experimental work primarily focused on small and linear arrays, and it is currently unclear how to scale quantum dot qubits to large numbers. Here, by implementing a strategy that allows to address a large number of quantum dots with a small number of control lines, we have operated the most extensive two-dimensional quantum dot array so far. With this approach, the number of gate layers is independent of the grid size, which greatly simplifies the nanofabrication of quantum dot arrays. With the introduction of a double barrier paradigm and a statistical method for labelling multi-dot charge stability diagrams, we have demonstrated two critical requirements for quan- 

- [1] A. G. Fowler, M. Mariantoni, J. M. Martinis, and A. N. Cleland, Surface codes: Towards practical large-scale quantum computation, Phys. Rev. A **86** , 032324 (2012). 

- [2] D. Wecker, B. Bauer, B. K. Clark, M. B. Hastings, and M. Troyer, Gate-count estimates for performing quantum chemistry on small quantum computers, Physical Review A - Atomic, Molecular, and Optical Physics **90** , 022305 (2014). 

- [3] B. M. Terhal, Quantum error correction for quantum memories, Rev. Mod. Phys. **87** , 307 (2015). 

- [4] R. Van Meter and D. Horsman, A blueprint for building a quantum computer, Commun. ACM **56** , 84–93 (2013). 

- [5] B. Landman and R. Russo, On a pin versus block relationship for partitions of logic graphs, IEEE Trans. Comput. **C-20** , 1469 (1971). 

- [6] L. M. K. Vandersypen, H. Bluhm, J. S. Clarke, A. S. Dzurak, R. Ishihara, A. Morello, D. J. Reilly, L. R. Schreiber, and M. Veldhorst, Interfacing spin qubits in quantum dots and donors—hot, dense, and coherent, npj Quantum Inf. **3** (2017). 

- [7] D. P. Franke, J. S. Clarke, L. M. Vandersypen, and M. Veldhorst, Rent’s rule and extensibility in quantum computing, Microprocess. Microsyst. **67** , 1 (2019). 

- [8] D. Loss and D. P. DiVincenzo, Quantum computation with quantum dots, Phys. Rev. A **57** , 120 (1998). 

- [9] F. A. Zwanenburg, A. S. Dzurak, A. Morello, M. Y. Simmons, L. C. Hollenberg, G. Klimeck, S. Rogge, S. N. Coppersmith, and M. A. Eriksson, Silicon quantum electronics, Rev. Mod. Phys. **85** , 961 (2013). 

- [10] A. Chatterjee, P. Stevenson, S. De Franceschi, A. Morello, N. P. de Leon, and F. Kuemmeth, Semiconductor qubits in practice, Nat. Rev. Phys. **3** , 157 (2021). 

tum logic in shared-control architectures: the tunability of 16 interacting quantum dots into an odd charge state with an unpaired spin and a method for the selective control of the interdot tunnel coupling, which is crucial for the control of the exchange interaction. We stress that, while the functionality of our approach crucially depends on the quality and homogeneity of the material stack, it can be applied to simplify the interconnection of quantum dot systems hosted in other material platforms, such as silicon [30, 34], gallium arsenide [35, 36] and graphene [37]. 

Our experiment has also served to pinpoint a limit of our first implementation: additional stray dots at the periphery of the crossbar have complicated the tune-up of the device, which they may be resolved by additional screening gates in the fanout. Moreover, the array is also reaching a size where manual tuning operations become a bottleneck. A promising direction to obtain the efficient control of quantum dot arrays is autonomous operation based on machine learning [26]. We envision that future crossbar arrays may find applications in large and dense two-dimensional quantum processors or as registers that are coupled via long-range quantum links for networked computing. 

- [11] R. Maurand, X. Jehl, D. Kotekar-Patil, A. Corna, H. Bohuslavskyi, R. Lavi´eville, L. Hutin, S. Barraud, M. Vinet, M. Sanquer, and S. De Franceschi, A CMOS silicon spin qubit, Nat. Commun. **7** , 13575 (2016). 

- [12] A. M. J. Zwerver, T. Kr¨ahenmann, T. F. Watson, L. Lampert, H. C. George, R. Pillarisetty, S. A. Bojarski, P. Amin, S. V. Amitonov, J. M. Boter, R. Caudillo, D. Corras-Serrano, J. P. Dehollain, G. Droulers, E. M. Henry, R. Kotlyar, M. Lodari, F. L¨uthi, D. J. Michalak, B. K. Mueller, S. Neyens, J. Roberts, N. Samkharadze, G. Zheng, O. K. Zietz, G. Scappucci, M. Veldhorst, L. M. K. Vandersypen, and J. S. Clarke, Qubits made by advanced semiconductor manufacturing, Nat. Electron. **5** , 184 (2022). 

- [13] M. Veldhorst, H. G. Eenink, C. H. Yang, and A. S. Dzurak, Silicon CMOS architecture for a spin-based quantum computer, Nat. Commun. **8** (2017). 

- [14] X. Xue, B. Patra, J. P. G. van Dijk, N. Samkharadze, S. Subramanian, A. Corna, B. Paquelet Wuetz, C. Jeon, F. Sheikh, E. Juarez-Hernandez, B. P. Esparza, H. Rampurawala, B. Carlton, S. Ravikumar, C. Nieva, S. Kim, H.-J. Lee, A. Sammak, G. Scappucci, M. Veldhorst, F. Sebastiano, M. Babaie, S. Pellerano, E. Charbon, and L. M. K. Vandersypen, Cmos-based cryogenic control of silicon quantum circuits, Nature **593** , 205 (2021). 

- [15] C. D. Hill, E. Peretz, S. J. Hile, M. G. House, M. Fuechsle, S. Rogge, M. Y. Simmons, and L. C. Hollenberg, Quantum Computing: A surface code quantum computer in silicon, Sci. Adv. **1** (2015). 

- [16] R. Li, L. Petit, D. P. Franke, J. P. Dehollain, J. Helsen, M. Steudtner, N. K. Thomas, Z. R. Yoscovits, K. J. Singh, S. Wehner, L. M. K. Vandersypen, J. S. Clarke, and M. Veldhorst, A crossbar network for silicon quan- 

7 

tum dot qubits, Sci. Adv. **4** , eaar3960 (2018). 

- [17] G. Scappucci, C. Kloeffel, F. A. Zwanenburg, D. Loss, M. Myronov, J.-J. Zhang, S. De Franceschi, G. Katsaros, and M. Veldhorst, The germanium quantum information route, Nat. Rev. Mater. **6** , 926 (2021). 

- [18] R. Hanson, L. P. Kouwenhoven, J. R. Petta, S. Tarucha, and L. M. K. Vandersypen, Spins in few-electron quantum dots, Rev. Mod. Phys. **79** , 1217 (2007). 

- [19] W. I. L. Lawrie, N. W. Hendrickx, F. van Riggelen, M. Russ, L. Petit, A. Sammak, G. Scappucci, and M. Veldhorst, Spin relaxation benchmarks and individual qubit addressability for holes in quantum dots, Nano Lett. **20** , 7237 (2020), pMID: 32833455, https://doi.org/10.1021/acs.nanolett.0c02589. 

- [20] N. Hendrickx, D. Franke, A. Sammak, G. Scappucci, and M. Veldhorst, Fast two-qubit logic with holes in germanium, Nature **577** , 487 (2020). 

- [21] F. Vigneau, F. Fedele, A. Chatterjee, D. Reilly, F. Kuemmeth, F. Gonzalez-Zalba, E. Laird, and N. Ares, Probing quantum devices with radio-frequency reflectometry, arXiv (2022). 

- [22] C. Volk, A. M. J. Zwerver, U. Mukhopadhyay, P. T. Eendebak, C. J. van Diepen, J. P. Dehollain, T. Hensgens, T. Fujita, C. Reichl, W. Wegscheider, and L. M. K. Vandersypen, Loading a quantum-dot based “Qubyte” register, npj Quantum Inf. **5** , 29 (2019). 

- [23] T. Hensgens, T. Fujita, L. Janssen, X. Li, C. J. Van Diepen, C. Reichl, W. Wegscheider, S. Das Sarma, and L. M. K. Vandersypen, Quantum simulation of a fermi–hubbard model using a semiconductor quantum dot array, Nature **548** , 70 (2017). 

- [24] A. R. Mills, D. M. Zajac, M. J. Gullans, F. J. Schupp, T. M. Hazard, and J. R. Petta, Shuttling a single charge across a one-dimensional array of silicon quantum dots, Nat. Commun. **10** (2019). 

- [25] M. Lodari, N. W. Hendrickx, W. I. L. Lawrie, T.-K. Hsiao, L. M. K. Vandersypen, A. Sammak, M. Veldhorst, and G. Scappucci, Low percolation density and charge noise with holes in germanium, Materials for Quantum Technology **1** , 011002 (2021). 

- [26] A. Dawid, J. Arnold, B. Requena, A. Gresch, M. P�lodzie´n, K. Donatella, K. Nicoli, P. Stornati, R. Koch, M. B¨uttner, R. Okula, G. Mu˜noz-Gil, R. A. Vargas-Hern´andez, A. Cervera-Lierta, J. Carrasquilla, V. Dunjko, M. Gabri´e, P. Huembeli, E. van Nieuwenburg, F. Vicentini, L. Wang, S. J. Wetzel, G. Carleo, E. Greplov´a, R. Krems, F. Marquardt, M. Tomza, M. Lewenstein, and A. Dauphin, Modern applications of machine learning in quantum sciences, arXiv 10.48550/arxiv.2204.04198 (2022). 

- [27] W. Ha, S. D. Ha, M. D. Choi, Y. Tang, A. E. Schmitz, M. P. Levendorf, K. Lee, J. M. Chappell, T. S. Adams, D. R. Hulbert, E. Acuna, R. S. Noah, J. W. Matten, M. P. Jura, J. A. Wright, M. T. Rakher, and M. G. Borselli, A flexible design platform for Si/SiGe exchange-only qubits with low disorder, Nano Lett. **22** , 1443 (2022). 

- [28] S. De Franceschi, S. Sasaki, J. M. Elzerman, W. G. van der Wiel, S. Tarucha, and L. P. Kouwenhoven, Electron cotunneling in a semiconductor quantum dot, Phys. Rev. Lett. **86** , 878 (2001). 

- [29] H. G. J. Eenink, L. Petit, W. I. L. Lawrie, J. S. Clarke, L. M. K. Vandersypen, and M. Veldhorst, Tunable Coupling and Isolation of Single Electrons in Silicon MetalOxide-Semiconductor Quantum Dots, Nano Lett. **19** , 

8653 (2019). 

- [30] W. I. L. Lawrie, H. G. J. Eenink, N. W. Hendrickx, J. M. Boter, L. Petit, S. V. Amitonov, M. Lodari, B. Paquelet Wuetz, C. Volk, S. G. J. Philips, G. Droulers, N. Kalhor, F. van Riggelen, D. Brousse, A. Sammak, L. M. K. Vandersypen, G. Scappucci, and M. Veldhorst, Quantum dot arrays in silicon and germanium, Appl. Phys. Lett. **116** , 080501 (2020). 

- [31] L. DiCarlo, H. J. Lynch, A. C. Johnson, L. I. Childress, K. Crockett, C. M. Marcus, M. P. Hanson, and A. C. Gossard, Differential Charge Sensing and Charge Delocalization in a Tunable Double Quantum Dot, Phys. Rev. Lett. **92** , 226801 (2004). 

- [32] N. W. Hendrickx, W. I. Lawrie, M. Russ, F. van Riggelen, S. L. de Snoo, R. N. Schouten, A. Sammak, G. Scappucci, and M. Veldhorst, A four-qubit germanium quantum processor, Nature **591** , 580 (2021). 

- [33] X. Xue, M. Russ, N. Samkharadze, B. Undseth, A. Sammak, G. Scappucci, and L. M. K. Vandersypen, Quantum logic with spin qubits crossing the surface code threshold, Nature **601** , 343 (2022). 

- [34] S. G. J. Philips, M. T. M¸adzik, S. V. Amitonov, S. L. De Snoo, M. Russ, N. Kalhor, C. Volk, W. I. L. Lawrie, D. Brousse, L. Tryputen, B. Paquelet Wuetz, A. Sammak, M. Veldhorst, G. Scappucci, and L. M. K. Vandersypen, Universal control of a six-qubit quantum processor in silicon, arXiv 10.48550/arxiv.2202.09252 (2022). 

- [35] P.-A. Mortemousque, E. Chanrion, B. Jadot, H. Flentje, A. Ludwig, A. D. Wieck, M. Urdampilleta, C. B¨auerle, and T. Meunier, Coherent control of individual electron spins in a two-dimensional quantum dot array, Nat. Nanotechnol. **16** , 296 (2021). 

- [36] F. Fedele, A. Chatterjee, S. Fallahi, G. C. Gardner, M. J. Manfra, and F. Kuemmeth, Simultaneous operations in a two-dimensional array of singlet-triplet qubits, PRX Quantum **2** , 040306 (2021). 

- [37] L. M. G¨achter, R. Garreis, J. D. Gerber, M. J. Ruckriegel, C. Tong, B. Kratochwil, F. K. de Vries, A. Kurzmann, K. Watanabe, T. Taniguchi, T. Ihn, K. Ensslin, and W. W. Huang, Single-shot spin readout in graphene quantum dots, PRX Quantum **3** , 020343 (2022). 

- [38] A. Sammak, D. Sabbagh, N. W. Hendrickx, M. Lodari, B. Paquelet Wuetz, A. Tosato, L. Yeoh, M. Bollani, M. Virgilio, M. Andreas Schubert, P. Zaumseil, G. Capellini, M. Veldhorst, G. Scappucci, A. Sammak, D. Sabbagh, N. W. Hendrickx, M. Lodari, B. Paquelet Wuetz, A. Tosato, L. Yeoh, M. Veldhorst, G. Scappucci, M. Virgilio, M. A. Schubert, P. Zaumseil, and G. Capellini, Shallow and Undoped Germanium Quantum Wells: A Playground for Spin and Hybrid Quantum Technology, Adv. Funct. Mater. **29** , 1807613 (2019). 

- [39] N. W. Hendrickx, D. P. Franke, A. Sammak, M. Kouwenhoven, D. Sabbagh, L. Yeoh, R. Li, M. L. Tagliaferri, M. Virgilio, G. Capellini, G. Scappucci, and M. Veldhorst, Gate-controlled quantum dots and superconductivity in planar germanium, Nat. Commun. **9** , 1 (2018). 

- [40] A. Tosato, V. Levajac, J.-Y. Wang, C. J. Boor, F. Borsoi, M. Botifoll, C. N. Borja, S. Mart´ı-S´anchez, J. Arbiol, A. Sammak, M. Veldhorst, and G. Scappucci, Hard superconducting gap in a high-mobility semiconductor, arXiv 10.48550/arxiv.2206.00569 (2022). 

- [41] D. M. Zajac, T. M. Hazard, X. Mi, E. Nielsen, and J. R. Petta, Scalable gate architecture for a one-dimensional array of semiconductor spin qubits, Phys. Rev. Appl. **6** , 

8 

054013 (2016). 

- [42] C. J. van Diepen, P. T. Eendebak, B. T. Buijtendorp, U. Mukhopadhyay, T. Fujita, C. Reichl, W. Wegscheider, and L. M. K. Vandersypen, Automated tuning of interdot tunnel coupling in double quantum dots, Appl. Phys. Lett. **113** , 033101 (2018). 

- [43] F. Borsoi, N. W. Hendrickx, V. John, S. Motz, F. van Riggelen, A. Sammak, S. L. de Snoo, G. Scappucci, and M. Veldhorst, Dataset underlying the manuscript: Shared control of a 16 semiconductor quantum dot crossbar array (2022). 

### **VI. METHODS** 

## **Fabrication** 

The device is fabricated on a Ge/SiGe heterostructure where a 16-nm-thick germanium quantum well with a maximum hole mobility of 2 _._ 5 _·_ 10<sup>5</sup> cm<sup>2</sup> V<sup>_−_1</sup> s<sup>_−_1</sup> is buried 55 nm below the semiconductor/oxide interface [25, 38]. We design the quantum dot plunger gates with a diameter of 100 nm, and the barrier gates separating the quantum dots with a width of 30 nm. The fabrication of the device follows these main steps. 30 nm-thick Pt ohmic contacts are patterned via electron-beam lithography, evaporated and diffused in the heterostructure following an etching step to remove the oxidised Si cap layer [39, 40]. A three-layer gate stack is then fabricated by alternating the atomic layer deposition of a Al2O3 dielectric film (with thicknesses of 7, 5, 5 nm) and the evaporation of Ti/Pd metallic gates (with thicknesses 3/17, 3/27, 3/27 for each deposition, respectively). After dicing, a chip hosting a single crossbar array is then mounted and wire-bonded on a printed circuit board. Prior to the cool down in a dilution refrigerated, we tested in a 4 K helium bath two nominally identical crossbar devices following the screening procedure shown in ref. [32]. Both devices exhibited full gates and ohmic contacts functionality, and one of them was mounted in a dilution refrigerator. 

## **Experimental setup** 

The experiment is performed in a Bluefors dilution refrigerator with a base temperature of 10 mK. From Coulomb peaks analysis, we extract an electron temperature of 138 _±_ 9 mK, which we use to estimate the detuning lever arm (Suppl. Figs. 10 and 11). We utilise an inhouse built battery-powered SPI rack `https://qtwork. tudelft.nl/~mtiggelman/spi-rack/chassis.html` to set direct-current (dc) voltages, while we use a Keysight M3202A arbitrary waveform generator (AWG) to apply alternating-current (ac) rastering pulses via coaxial lines. The dc and ac voltage signals are combined on the PCB with bias-tees and applied to the gates. Each charge sensor is galvanically connected to a NbTiN inductor with an inductance of a few _µ_ H forming a resonant tank circuit with resonance frequencies of _∼_ 100 MHz. In our experiment we have observed only three out of four resonances, likely due to a defect inductor. Moreover, 

because two resonances overlap significantly, we mostly avoid using reflectometry (unless explicitly stated in the text) and use fast dc measurements with bandwidth up to 50 kHz. The four dc sensor currents are converted into voltages, amplified and simultaneously read out by a four-channel Keysight M3102A digitizer module with 500 MSa/s. The digitizer module and several AWG modules are integrated into a Keysight M9019A peripheral component interconnect express extensions for instrumentation (PXIe) chassis. Charge stability diagrams here typically consists of a 150x150 pixels scan with a measurement time per pixel of 50 _µ_ s. To enhance the signal-to-noise ratio, we average the same map 5-50 times, obtaining a high-quality map within a minute. We adopt the notation ∆g _i_ to identify an AWG-supplied ramp of the gate g _i_ with respect to a fixed dc reference voltage. 

## **Tune-up details** 

The device was tuned into the 16-quantum-dots regime two times. In the first run, the gate voltages were optimised to minimise the number of unintentional quantum dots to better characterise the crossbar quantum dots (Fig. 2 and Suppl. Fig. 6). In the second, the stray dots were neglected and we focused on tuning the quantum dot array to the odd-occupation regime (Fig. 3). Between the two tune-up cycles, the gate voltages were reset to zero without thermal cycling the device. The starting gate voltage values for the tune-up are -300 mV for the barriers and -600 mV for the plungers. In Suppl. Fig. 12 we display the dc gate voltages relative to the measurements displayed in Fig. 3, with the crossbar array tuned in the odd-charge occupation. In this regime, we characterise the variability of the transition lines spacing to be _∼_ 10 _−_ 20% as a metric for the level of homogeneity of the array (Suppl. Fig. 13) [41]. We could also have chosen the voltage onset of the first hole in each quantum dot, however these exact voltages depend on several surrounding gates, hence our choice on the transition lines spacing. The odd occupancy is demonstrated by emptying each quantum dot as shown in Suppl. Figs. 14-25. All the panels of Fig. 3 are taken at the same gate voltage configuration on the same day, except for panels b, and d, which were retaken a few days later with improved sensitivity of the NW sensor and with minimal voltage differences (the largest variations are 12 mV on P7 which is far away from the Q1, Q2 and Q3 system and 11 mV on UB8). The original (vP2, vP1) and (vP2, vP3) measurements are shown in Suppl. Figs. 14 and 16. During the experiment, the gate UB8 did not function properly, possibly due to a broken lead. To compensate for this effect and to enable charge loading in the dots P3t and P5t, we set UB7 at a lower voltage compared to the other UB gates. Additionally, LB1 is set at a comparatively higher voltage to mitigate the formation of accidental quantum dots under the fanout of LB1 and P1 at lower voltages. The first addition line of such an accidental quantum dot 

9 

is visible as a weakly interacting horizontal line in Fig. 3a. 

## **Virtual matrix** 

We define a set of virtual gates (v _⃗ G_ ) as linear combinations of actual gates ( _⃗G_ ) to eliminate the cross-talk to the charge sensors and to independently control the on-site energies with virtual plunger gates [23, 24]. The matrix _M_ defined by _⃗G_ = _M ·⃗_ v _G_ is shown as a colour map in Suppl. Fig. 3. For the tunnel coupling experiments presented in Fig. 4, we employ additional virtual gate systems for achieving independent control of the detuning voltage e67 and U67, and of the interdot interactions via virtual barriers t6b7, j6b7, t6t7 and j6t7. With SE ~~P~~ the SE plunger gate, we write: 



<!-- Start of picture text -->
P5 0 . 04 − 1 . 2<br> P6   − 0 . 5 0 . 9  e67<br>   <br>P7 0 . 492 0 . 9 U67<br>� �<br>SE P  =  − 0 . 08 − 0 . 26<br><!-- End of picture text -->

integral of the _λ_ vUB ( _λ_ vLB) between vUB _i_ (vLB _k_ ) and vUB _j_ (vLB _l_ ) returns a “probability” _pU,_ ( _i,j_ ) ( _pL,_ ( _k,l_ )) to find the dot in-between these control lines. As a result, the combined probability in the site confined by these four barriers is given by the product of these elements: _w_ ( _i,j_ ) _,_ ( _k,l_ ) = _pU,_ ( _i,j_ ) _· pL,_ ( _k,l_ ). We note that the sum of the 16 probabilities returns 1. As already observed in ref. [30], the gates cross-coupling to a specific quantum dot defined in a germanium quantum well manifest a slow falloff in space (i.e., gates with a distance to the dot of _>_ 100 nm still have a considerable cross-coupling to the dot). This can be attributed to the rather large vertical distance between the gates and the quantum dots ( _>_ 60 nm), and is in contrast with experiments in SiMOS devices where the falloff is rather immediate due to the tight charge confinement. This aspect explains why our probability W at the identified quantum dot reaches at a max of 0 _._ 25 _−_ 0 _._ 5. 

## **Tunnel coupling evaluation** 



<!-- Start of picture text -->
P6 − 1 . 28 − 0 . 33<br> P7   − 1 . 18 − 0 . 72<br>    t6t7<br> UB5   1 0 <br> LB7   0 1  �j6t7�<br>SE P  =  0 . 15 − 0 . 01<br>P6 − 2 . 05 − 0 . 97<br> P7   − 1 . 18 − 0 . 41<br>    t6b7<br> UB4   1 0 <br> LB7   0 1  �j6b7�<br>SE P  =  − 0 . 19 − 0 . 01<br><!-- End of picture text -->

## **Quantum dots identification** 

To obtain the capacitive coupling of all the barrier gates to a set of transition lines (as shown in Fig. 2b), we acquire and analyse sets of 112 charge stability diagrams. The same charge stability diagram is taken after stepping each barrier gate around its current voltage in steps of 1 mV in the range of -3 to 3 mV (i.e., 7 scans x 16 barriers). In the analysis, we first subtract a slowly varying background to the data (with the function ndimage.gaussian.filter of the open-source scipy package) and then calculate the gradient of the map (with ndimage.gaussian ~~g~~ radient ~~m~~ agnitude). For a given line cut of such two-dimensional maps, we extract the peaks position using a Gaussian fit function. Due to cross capacitance, the transition line positions manifest a linear dependence on each of the 16 barriers, which we quantify by extracting the linear slope (Suppl. Fig. 4). After normalisation to the maximum value, these parameters are named capacitive couplings ( _λ_ ), and, because of the grid structure of the two barrier layers, provide a first information of where the hole is added/removed to/from. To extract the quantum dot positions, we consider the capacitive couplings to the vUB ( _λ_ vUB) and vBL ( _λ_ vLB) gates as two independent probability distributions. With this approach, the 

For the estimation of the tunnel coupling results presented in Fig. 4, we established an automated measurement procedure that follows this sequence: 1) we step the virtual barriers across the two-dimensional map ( _t, j_ ); 2) at each barrier configuration, we take a two-dimensional (e67, U67) charge stability map (Figs. 4b-g); 3) we identify the accurate position of charge interdot via a fitting procedure of the map (Suppl. Fig. 8) [42]; 4) we perform small adjustments at the e67, U67 virtual gates to centre the interdot at the (0,0) dc-offset; 5) measure the polarisation line by using _∼_ 0.1 kHz AWG ramps (Figs. 4c, h). For an accurate analysis, each polarisation line is the result of an average of 150 traces, using a measurement integration time of 50 _µs_ per pixel. With this method, the full 30x30 maps are taken in a few hours. We fit the traces considering an electron temperature of 138 mK and a detuning lever arm of _αϵ_ 67 = 0 _._ 012(4) eV/V, extracted from a thermally broadened polarisation line (Suppl. Fig. 11). We observe that the extracted tunnel coupling follows approximately an exponential trend as a function of the barrier gates. We fit the data presented in Figs. 4e, j with the function _A · e_<sup>_−BVg_</sup> , with _A_ a prefactor, _B_ the effective barrier lever arm and _Vg_ the gate axis. We find that the effective barrier lever arms of _j_ 6b7 and _t_ 6b7 are 0 _._ 007 _±_ 0 _._ 002 and 0 _._ 021 _±_ 0 _._ 003 mV<sup>_−_1</sup> , respectively. Similarly, we find for _j_ 6t7 and _t_ 6t7 values of 0 _._ 008 _±_ 0 _._ 001 and 0 _._ 026 _±_ 0 _._ 003 mV<sup>_−_1</sup> , respectively. Altogether these results indicate that the lower barrier layer of UB gates is _∼_ 3 times more effective than the upper barrier layer of LB gates. This is consistent with what is found in Fig. 2b and Suppl. Fig. 5. We note that for qubit operations in such crossbar array, it is actually necessary to fully characterise and calibrate the two-barrier tunability of all the 24 nearest-neighbours. Performing this task requires improving further our hardware implementation and is beyond the scope of this work. 

10 

**VII. ACKNOWLEDGEMENTS** 

### **VIII. AUTHOR CONTRIBUTIONS** 

F.B., N.W.H. performed the experiments with the support of V.J. and F.v.R.. F.B. analysed the data and N.W.H fabricated the device. V.J. and S.M. contributed to the data analysis. S.L.d.S., N.W.H and F.B. developed the software used in the experiment. A.S. and G.S. supplied the heterostructure. F.B. and M.V. wrote the manuscript with the input from all the authors. M.V. supervised the project. 

We are grateful to Corentin Depr´ez, Chien-An Wang, Eliˇska Greplov´a and all the members of the Veldhorst lab for fruitful discussions. We acknowledge support through an ERC Starting Grant and through an NWO projectruimte. Research was sponsored by the Army Research Office (ARO) and was accomplished under Grant No. W911NF-17-1-0274. The views and conclusions contained in this document are those of the authors and should not be interpreted as representing the official policies, either expressed or implied, of the Army Research Office (ARO), or the U.S. Government. The U.S. Government is authorized to reproduce and distribute reprints for Government purposes notwithstanding any copyright notation herein. 

### **IX. COMPETING INTERESTS** 

The authors declare no competing interests. Correspondence should be addressed to Francesco Borsoi (F.Borsoi@tudelft.nl). 

### **X. DATA AVAILABILITY** 

All data and analysis underlying this study are available on a Zenodo repository at `https://doi.org/10. 5281/zenodo.7077895` [43]. 

# **Supplementary information: Shared control of a 16 semiconductor quantum dot crossbar array** 

Francesco Borsoi,<sup>1</sup> Nico W. Hendrickx,<sup>1</sup> Valentin John,<sup>1</sup> Sayr Motz,<sup>1</sup> Floor van Riggelen,<sup>1</sup> Amir Sammak,<sup>2</sup> Sander L. de Snoo,<sup>1</sup> Giordano Scappucci,<sup>1</sup> and Menno Veldhorst<sup>1</sup> 

> 1 _QuTech and Kavli Institute of Nanoscience, Delft University of Technology, P.O. Box 5046, 2600 GA Delft, The Netherlands_ 

> 2 _QuTech and Netherlands Organisation for Applied Scientific Research (TNO), 2628 CK Delft, The Netherlands_ 

### **Supplementary Note 1. RENT’S RULE AND GATE COUNT** 

Scalable architectures impose stringent requirements at all layers of the quantum computing stack [S1]. If we focus on the lowest layers of the computing stack, state-of-the-art solid-state quantum processors do not meet these prerequisites yet [S2]. In fact, current processors still make use of a few control terminals per qubit, an approach that will lead to arduous interconnectivity and control challenges in the route toward millions qubits [S3, S4]. To quantify the level of optimisation and interconnectivity of a quantum processor, we borrow the concept of Rent’s rule from classical electronics [S5]. In quantum dot devices, the Rent’s rule can be used to correlate the number of control terminals _T_ (i.e., gates, ohmic leads,...) and the number of active components _g_ (i.e., quantum dots or qubits): 



<!-- Start of picture text -->
T =  tg p (1)<br><!-- End of picture text -->

where _t_ is the average number of control terminals per qubit and _p_ is the Rent exponent that lies in the range (0 _,_ 1]. Without any quantum hardware optimisation, the number of terminals will keep increasing linearly with the number of qubits, creating major interconnect problems in the quantum computing stack [S2]. 

An analogous challenge emerged in the 1950s in classical electronics when every electrical component needed to 



<!-- Start of picture text -->
NQDs= 9<br>NQDs= 4 NQDs= 16<br><!-- End of picture text -->

**Supplementary Figure 1** . **Rent’s rule in two-dimensional quantum dot architectectures and gates count.** Number of control terminals (gates) versus the number of quantum dots for a two-dimensional array. The blue trace indicates the scaling of our shared-control gate architecture. The red trace shows the scaling for an architecture with individual control (inset) of interdot couplings and quantum dot energies. Scatter points represent the gates counts of a 2x2 [S6], 3x3 [S7] and 4x4 quantum dot array (this work). We draw a horizontal line at 2000 control terminals, which currently identify the current maximum number of input/output terminals of classical integrated circuits. Assuming this as a practical limit for the control terminals of a quantum processor without on-chip control logic [S8], the individual control strategy is limited to control up to a few hundred quantum dots. In contrast, the shared control approach may be able to control few hundreds of thousands. 

be soldered to several others [S9]. The turning point was the invention of the integrated circuit, which led to the realisation of the first microprocessor - the Intel 4004 - with 2300 transistors and only 16 external pins. Nowadays, 

S2 

integrated circuits are at the heart of our technology and, with a Rent exponent of about 0 _._ 5 and a maximum number of input/output lines of _T ∼_ 2 _·_ 10<sup>3</sup> , present a ratio of transistor to input/output pins _g/T_ of _∼_ 10<sup>6</sup> [S8, S10]. On the contrary, in infant quantum chips, the _g/T_ ratio is below 1 [S2], and therefore, significant efforts have to be made to downscale the quantum Rent exponent. 

In our work, we have moved from electrostatic gating strategies with individual control of every unit to crossbar architectures with shared control of quantum dots energies and interdot couplings [S11]. This advance is crucial for scalability because it may enable to use _O_ ( _N_<sup>1</sup><sup>_/_2</sup> ) terminals for _O_ ( _N_ ) qubits (i.e., _p_ = 0 _._ 5). The impact of this strategy can be visualised in Suppl. Fig. **1** , where we compare the different scalings of control terminals for a two-dimensional quantum dot array controlled with a shared- and with an individual-control approach. For the shared-control architecture presented in this work, the gates count as a function of quantum dots _g_ is given by: 



<!-- Start of picture text -->
T = 6 g 1 / 2 − 1  ∝ 6 g 1 / 2 (2)<br><!-- End of picture text -->

while for an architecture with individual control of all the on-site dot energies and interdot couplings (see inset of Suppl. Fig. **1** ), we obtain: 



<!-- Start of picture text -->
T = 3 g  + 2 g 1 / 2 − 4  ∝ 3 g (3)<br><!-- End of picture text -->

These equations hold for square arrays with a minimum 2x2 size, i.e., _g ≥_ 4. 

We emphasise that in these considerations we do not account for the terminals controlling the read-out charge sensors. In the future, a strategy for the integrating charge sensors within quantum dot crossbar arrays needs to be fully work out to establish and operate scalable modules of semiconductor qubit arrays with a Rent exponent of 0.5. We note that germanium can make ohmic contacts to metals, thus facilitating a very small footprint for charge sensors, and providing a route toward the integration of charge sensors in the quantum dots array. 

### **Supplementary Note 2. TYPICAL CHARGE SENSORS RESPONSE** 

To read out the charge states of the 16 quantum dots, we prepare four charge sensors in the Coulomb regime, as demonstrated by the transport features in Suppl. Fig. **2** , and operate them at the steepest points. 



<!-- Start of picture text -->
a b c d<br><!-- End of picture text -->

**Supplementary Figure 2** . **Typical charge sensor responses. a, b** Direct-current _I_ via the NW and SW sensor. **c, d** Reflectometry signal _S_ 21 of the NE and SE sensor respectively. 

S3 

**Supplementary Note 3. VIRTUAL GATE MATRIX** 

In Suppl. Fig. **3** we display the virtual matrix used in software to define the set of virtual gates. We define the virtual barriers such that their variation does not influence the position of the charge sensors Coulomb peak. Virtual plungers are designed to be able to tune independently the on-site energies of the quantum dots by using only nearestneighbours compensations. Because multiple sites are controlled by a single plunger line and each of the site can have a slightly different crosstalk to the surrounding gate, our procedure results in an approximation. 



**Supplementary Figure 3** . **Virtual gate matrix.** Visualization of the virtual gate matrix. Virtual barriers vLB _i_ and vUB _i_ are defined as combination of the relative barriers LB _i_ and UB _i_ with _i ∈_ [1 _,_ 8] and sensor plungers. NW ~~P~~ , NE ~~P~~ , SW ~~P~~ and SE ~~P~~ identify the plungers of the respective charge sensors. 

S4 

### **Supplementary Note 4. PRACTICAL DEVICE IMPROVEMENTS** 

Here, we present a series of practical ideas to mitigate challenges observed (and not) throughout the experiment. 

1. The tune-up of the current implementation is complicated by the emergence of a few ( _∼_ 5) unwanted stray dots outside the array, located under the dense gates fanout. These decrease the read-out sensitivity to the designed quantum dots and, in general, complicate the system tune-up. Near-term solutions can be: the addition of a lower “screening” gate layer (kept at a more positive voltage), or an upper “depleting” gate layer that prevents any charge puddles from forming in between different gate lines. A more sophisticated solution consists of the implementation of vertical interconnect access through the oxide layer that enables to fan out the gate lines at a much higher level in the stack [S12]. We also envision that, in the future, boundary effects of large qubit arrays need to be accounted for (e.g., dots at the perimeter of the array experience a smaller electric field than the ones in the middle). Hence, another possibility is to neglect the dots at the perimeter completely. 

2. A faster device tunability can be achieved by using radio frequency reflectometry, which, in our experiment, worked out only partially. 

3. A higher level of homogeneity and functionality than is presented here will be needed for practical quantum computation with quantum dots. Leaving aside the development on the material stack itself (Ge/SiGe) and on the device nanofabrication, there appears to still be space for improvements on the gate layout. Similarly to the behaviour of the turn-on voltages in transistors [S13], a higher quantum dots homogeneity may be achieved by increasing their size. This will also have the beneficial effect of increasing the plunger gates lever arm, which will be less screened by the lower layers. Clearly, an excessively large quantum dot can lead to (Pauli spin-blockade) read-out problems if the energy of the first excited state is too low. Therefore a search for an optimal size needs to be performed. 

4. In the current device, we observed that the ratio of the two barrier layers lever arms is approximately 2-3. Due to imperfections in the nanofabrication and an oxide layer in between them, the top layer partially overlaps the bottom one. As a consequence, its electric field is screened. To enhance the coupling of the top layer, one can design the top layer to have a slightly larger width, or add a gap of a few nm in between the two lines. 

S5 

### **Supplementary Note 5. THE QUANTUM DOTS IDENTIFICATION** 

To obtain the capacitive coupling of each barrier to each dot, we analyse several charge stability diagrams as shown in Suppl. Fig. **4** a. We monitor the position of the transition lines (away from charge interdots) by fitting the derivative of the data with a Gaussian function, after subtraction of a slow-varying background. In the small voltage range that we consider, the extracted peak positions respond linearly to each barrier gate (Suppl. Figs. **4** b, c) The normalised slope of the fitted linear function is used to quantify the capacitive coupling of each gate. The latter are plotted as histograms and visualised on the device layout in Suppl. Fig. **5** . As described in the Methods, this information can be used to clearly assign each set of transition lines to the dot in the grid. 



<!-- Start of picture text -->
a b c<br><!-- End of picture text -->

**Supplementary Figure 4** . **Detecting the shift of the quantum dots transition lines: an exemplary case. a,** Charge stability diagram (gradient of the SW sensor signal) showcasing a set of vertical and horizontal charge transition lines. The green trace shows the derivative of the data at the vP4 value identified by the horizontal green tick. The white dashed line is a fit of the linecut with a Gaussian function, and the green marker identifies the fitted centre of the peak. The red marker labels the fitted coordinate of a vertical transition line (not shown). **b, c,** Scatter points are the fitted positions of the green and red markers, respectively, as a function of the voltage applied at all barriers. Error bars on the points display the standard deviation of the fitted centre of the Gaussian. Dashed lines are the best linear fit to the data. The normalised absolute values of the slope parameter are taken as capacitive couplings of each gate to the specific transition line. The error bar on the capacitive coupling is taken as one standard deviation of the fitted slope parameter. The horizontal (vertical) transition line in **(a)** is attributed to the quantum dot Q4b (Q5b). 

S6 



<!-- Start of picture text -->
a b c m n o<br>λvUB, λvLB λvUB, λvLB<br>d e f<br>λvUB, λvLB<br>λvUB, λvLB<br>p q r<br>g h i<br>λvUB, λvLB<br>j k λvUB, λvLB l<br>vUB vLB vUB vLB<br><!-- End of picture text -->

**Supplementary Figure 5** . **Quantum dot identification. a,** Histograms of the (normalised) capacitive couplings (in red for the vUB, and in blue for the vLB gates) obtained by the analysis of transition lines attributed to different quantum dots as shown in Suppl. Fig. **4** . Red and blue backgrounds are added to emphasise the two barriers that surround the labelled quantum dot. **b,** Device layout with the capacitive couplings colour-coded on the filling of the gate lines. The vUB (vLB) capacitive couplings are normalised to their maximum values. Intuitively, the quantum dot associated with the analysed transition lines is located at the intersection of the two intensely coloured red and blue lines. **c,** Extracted probabilities ( _W_ ) of each set of addition lines (calculated as discussed in the Methods). The comparison of the top and bottom panels of **a, b, c** ( **d, e, f** ) clearly distinguishes the two Q2 (Q6) quantum dots. Similarly, our method is applied on the two dots controlled by independent plunger lines Q1 and Q7 in panels **g, h, i** and **j, k, l** , respectively. The three different rows of panels **m, n, o** ( **p, q, r** ) enables to label the Q5 (Q4) quantum dots. The dot Q4t could not be systematically analysed because, in this gating regime, we observe a slow loading mechanism via the defective barrier UB8 with respect to the timescale of our scan ( _∼_ ms). However, because such transition lines are controlled by vP4 (labelled in Suppl. Fig. **6** ), do strongly respond to vUB7 and vLB5, we can still map them to the site Q4t, in a qualitative way. 

S7 

**Supplementary Note 6. TUNE-UP OF THE CROSSBAR ARRAY IN THE FEW-HOLE REGIME** 

In Suppl. Fig. **6** , we display the charge stability diagrams obtained for the first tune-up of the device with the quantum dots in the few-holes regime. These maps are part of the data sets that are used for the analysis presented in Suppl. Fig. **5** . 

S8 



<!-- Start of picture text -->
a b c d<br>e f g h<br>i j k l<br>m n o p<br>q r s<br>P1 P2 P3 P4 LB1 LB2 LB3 LB4 UB5 UB6 UB7 UB8<br>P5 P6 P7 LB5 LB6 LB7 LB8 UB1 UB2 UB3 UB4<br><!-- End of picture text -->

**Supplementary Figure 6** . **Tune-up of the crossbar array in the few-holes regime. a-p,** Charge stability diagrams (raw sensor signal after subtraction of a background) showcasing the 16 quantum dots system in the few-hole regime. These measurements are taken in the first tune-up of the crossbar array. In each map, the first visible transition lines from the right or the top are labelled and assigned to the relative quantum dot by dashed lines with colours defined in the quantum dots schematic at the top. The quantum dots identification is performed via the results of Suppl. Fig. **5** . The colour of the panel frame identifies the sensor used: NW in red, NE in blue, SW in green, and SE in ochre. **q-s,** Schematics of the voltage applied at all crossbar gates at this phase of the experiment. The voltages are here optimised to circumvent stray dots. 

S9 

### **Supplementary Note 7. ADDRESSABLE EXCHANGE OPERATIONS WITH A DOUBLE BARRIER DESIGN** 

The ability to control the tunnel coupling with two barriers opens the opportunity to design addressable exchangebased two-qubit gates in architectures with shared control. We envision an operation strategy in which a two-qubit gate can be activated only when both barriers are in the ON state. For a fast CPHASE gate with a duration of 5 ns, we require to activate an exchange interaction of _J_ ON _/h_ = 100 MHz. In all other cases (i.e., when the barriers are in the configurations (ON, OFF), (OFF, ON), (OFF, OFF)), we demand a sufficiently low exchange to minimise errors. State-of-the-art values of OFF exchange interaction are in the order of _J_ OFF _/h ∼_ 10 KHz [S14]. 

Suppl. Fig. **7** illustrates the required barrier voltage points to obtain such exchange interactions considering symmetric lever arms, a quantum dot charging energy of U = 1 meV and operations at the charge symmetry point (i.e., at zero detuning). In Suppl. Fig. **7** , we have approximated the dependence of the tunnel coupling energy _t_ C with respect to the two barrier voltages _Bx_ and _By_ with [S15–S17]: 



<!-- Start of picture text -->
√ JU<br>t C = =  c 1  · e −c 2 α ( Bx−Bx,ON ) · e −c 2 α ( By−By,ON ) (4)<br>2<br><!-- End of picture text -->

with _Bx,ON_ and _By,ON_ the ON set-points of the two barriers. 

In this example, we have set the prefactor _c_ 1 to 5, and the effective barrier lever arms _c_ 2 _· α_ to 0.04 _V_<sup>_−_1</sup> . 



<!-- Start of picture text -->
Tunnel coupling Exchange<br>(ON, OFF) (OFF, OFF) (ON, OFF) (OFF, OFF)<br>10 MHz 0.03 MHz 0.6 kHz 4∙10 -6  kHz<br>(ON, ON) (OFF, ON) (ON, ON) (OFF, ON)<br>5 GHz 10 MHz 100 MHz 0.6 kHz<br><!-- End of picture text -->

**Supplementary Figure 7** . **Addressable exchange operation with a double barrier design. a, b** Target tunnel coupling and exchange required for fast two-qubit gates with interaction ON (bottom left corner), and OFF (top left, top right, bottom left corners in the map). The exchange interaction of qubit pairs at (ON, OFF) crossing points remains four orders of magnitude smaller than in the (ON, ON) cases. The parameters displayed are calculated at the coordinates (0, 0), (0, 150), (150, 0), (150, 150) mV. 

S10 

### **Supplementary Note 8. TWO-AXIS CONTROL OF THE QUANTUM DOTS INTERDOT TRANSITION LINE** 

By fitting the two-dimensional (e67, U67) charge stability diagrams (examples in Suppl. Figs. **8** a, b), we obtain an estimate of the (3,1)-(2,2) charge interdot size _L_ for the double dot systems Q6b-Q7 and Q6t-Q7. The size of the interdot line is indicative of the capacitive coupling between the adjacent quantum dots. Consistent with the two-axis tunability of the tunnel coupling, the interdot size is varied as the effective distance between the dots is modified by the action of the two tunnel barriers (Suppl. Figs. **8** c-f). 



<!-- Start of picture text -->
a b<br>L L<br>c d e f<br><!-- End of picture text -->



**Supplementary Figure 8** . **Two-axis control of the quantum dot interdot transition line. a, b,** Exemplary charge stability diagrams taken at the Q6t-Q7 (3,1)-(2,2) charge interdot line. The two maps are taken at the diagonally opposite points of the two-dimensional barrier scan, at _t_ 6t7 _, j_ 6t7 = (-330, -510) and (-270, -380) mV, respectively. Orange lines represent a fit to the map following the procedure shown in ref. [S18]. A black circle identifies the fitted centre of the interdot, and the arrow illustrates the size in voltage of the interdot line. **c, d,** Size of the Q6b-Q7 (3,1)-(2,2) charge interdot line as a function of the two virtual barriers. **e, f,** Same for the Q6t-Q7 (3,1)-(2,2) charge interdot line. Outliers in the plot are due to non-accurate fits of the image. 

S11 

### **Supplementary Note 9. TWO-AXIS CONTROL OF THE Q6B-Q5M INTERACTION** 

We repeat the tunnel coupling experiments considering the double-dot pair Q6b and Q5m by defining the virtual barriers _t_ 6b5 and _j_ 6b5 starting from the relative UB4 and LB6 barriers (Suppl. Fig. **9** ): 



<!-- Start of picture text -->
P5 − 1 . 63 − 0 . 58<br> P6   − 1 . 61 − 0 . 48<br>    t6b5<br> UB4   1 0 <br> LB6   0 1  �j6b5�<br>SE P  =  − 0 . 43 − 0 . 02<br><!-- End of picture text -->

We observe that the limited sensitivity at the interdot hinders a quantitative tunnel coupling analysis. However, at a qualitative level, we still observe the expected pattern with the size of the interdot tunable by both barriers. 

### **a** 



<!-- Start of picture text -->
b c<br>(ON, OFF) (OFF, OFF)<br>t<br>6b5<br>d e<br>(ON, ON) (OFF, ON)<br>j 6b5<br><!-- End of picture text -->

**Supplementary Figure 9** . **Two-axis control of the Q6b-Q5m interdot coupling. a** Schematic of the crossbar indicating the two intersecting virtual barriers (in red and blue) controlling the Q6b-Q5m interaction. **b-e** Charge stability diagrams at different barrier voltages: **(b)** ( _t_ 6b5 _, j_ 6b5) = (-330, -380) mV, **(c)** (-270, -380) mV, **(d)** (-270, -510) mV, **(e)** (-330, -510) mV. In **(d)** , in the high interdot coupling regime, we add dashed lines as guide for the eyes on weakly visible transition lines. Here, we display the signal from the SE charge sensor after subtraction of a background. 

S12 

**Supplementary Note 10. ELECTRON TEMPERATURE EXTRACTION** 



<!-- Start of picture text -->
a b c<br><!-- End of picture text -->

**Supplementary Figure 10** . **Electron temperature extraction. a** Coulomb peak width as a function of fridge temperature. **b, c.** Exemplary data (scatter points) and best fits (black lines) collected at _Tf_ = 10 mK and _Tf_ = 540 mK, respectively. For every temperature, we perform five plunger sweeps across the Coulomb peak (each averaged 500 times) and, by fitting the curves, we obtain five different estimates for the Coulomb peak width. In **(a)** , we show the average width. The depicted standard deviation is determined by considering the standard deviation from the single fit itself or the standard deviation between the five different fitting estimates, depending on which is dominant. 

We estimate the electron temperature of our setup by fitting a temperature-broadened Coulomb peak of the SE charge sensor. We choose a source-drain voltage _V_ SD and coupling energy to the leads _h_ Γ such that _h_ Γ _, eV_ SD _<< kBTe_ , with _h_ and _kB_ the Plank and Boltzmann constants, respectively and Γ the lead-dot tunnel rate. The current _I_ at the Coulomb peak is fitted with the Lorentzian distribution 



<!-- Start of picture text -->
Imodel =  a ·  cosh − 2 +  c, (5)<br>� αsensor 2 kBT ·e  ϵ �<br><!-- End of picture text -->

where _a_ is an amplitude prefactor, _αsensor_ is the lever arm of the sensor plunger gate, _ϵ_ is the plunger gate voltage and _c_ an offset. The full width half maximum (FWHM) of the peak is therefore given by 



<!-- Start of picture text -->
FWHM = kBTe = kB � T 0 2 +  T  2 f , (6)<br>αsensor αsensor<br><!-- End of picture text -->

where _Tf_ is the nominal fridge temperature and _T_ 0 the base electron temperature [S19]. We use the FWHM dependence on the nominal fridge temperature to extract both _T_ 0 and _αsensor_ . The result can be seen in Suppl. Fig. **10** with two exemplary fits for 10 and 540 mK. The fit with Equation 6 results in _T_ 0 = 138 _±_ 9 mK and _αsensor_ = 0 _._ 123 _±_ 0 _._ 002 eV/V, which is consistent with an independent lever arm extraction from Coulomb diamonds. 

### **Supplementary Note 11. DETUNING LEVER ARM EXTRACTION** 

For an accurate estimation of the interdot tunnel coupling, we evaluate the quantum dot detuning lever arm by fitting the sensor signal _S_ 21 with a thermally limited polarisation line (Suppl. Fig. **11** ) as described in [S20]: 



<!-- Start of picture text -->
Smodel =  S 0  ± δS Ω ϵ ·  tanh � 2 k Ω BTe � + ∂S ∂ϵ ϵ (7)<br><!-- End of picture text -->

with _S_ 0 the background signal of the charge sensor, _δS_ the signal amplitude, _ϵ_ the detuning energy, Ωthe energy difference between the two levels and the term _<u>∂S∂ϵ</u>_<sup>_ϵ_alinearslopeduetocross-talktothechargesensor.Inthe</sup> low-tunnelling regime, we can approximate Ω= _~~√~~ ϵ_<sup>2</sup> + 4 _t_<sup>2</sup> _≈ ϵ_ , which reduces Equation 7 to 



<!-- Start of picture text -->
S model =  S 0  ± δS ·  tanh + ∂S (8)<br>� α 2 QkBDT ·e ϵ � ∂ϵ ϵ.<br><!-- End of picture text -->

S13 



<!-- Start of picture text -->
a b e67 (mV)<br>40 30 20 10 0 10 20 30 40<br>67 = 0.0124 eV/V<br>10<br>120<br>0<br>110<br>10<br>50 0 50 400 200 0 200 400<br>e67 (mV) 67 ( eV)<br>U67 (mV)  (a. u. )S21<br><!-- End of picture text -->

**Supplementary Figure 11** . **Temperature limited polarisation line. a,** Charge stability diagram of the uncoupled Q6bQ7 at the (3,1)-(2,2) charge interdot. In this configuration, the tunnel time in Q6b is small with respect to the ramp time of the detuning axis, therefore the interdot is extended and the Q6b addition line is not clearly visible in the map. **b,** Thermally limited polarisation line (blue trace) taken at the centre of the interdot shown in **(a)** . From the best fit (orange line), we obtain the detuning lever arm _αϵ_ 67 = 0 _._ 012(4) eV/V. 

S14 

**Supplementary Note 12. GATE VOLTAGES OF THE CROSSBAR IN THE ODD CHARGE REGIME** 



<!-- Start of picture text -->
a b c<br>P1 P2 P3 P4 LB1 LB2 LB3 LB4 UB5 UB6 UB7 UB8<br>P5 P6 P7 LB5 LB6 LB7 LB8 UB1 UB2 UB3 UB4<br><!-- End of picture text -->

**Supplementary Figure 12** . **Crossbar gate voltages. a-c,** Voltages applied at the real P, LB and UB gates, respectively, when the system is tuned in the odd charge occupation regime. 

### **Supplementary Note 13. VARIABILITY OF ADDITION VOLTAGES** 



<!-- Start of picture text -->
1st<br>70<br>2nd<br>3rd<br>60<br>4th<br>50<br>40<br>30<br>20<br>10<br>0<br>Q1 Q2b Q2t Q3b Q3m Q3t Q4b Q4mb Q4mt Q4t Q5b Q5m Q5t Q6b Q6t Q7<br>Quantum dot<br>Spacing (mV)<br><!-- End of picture text -->

**Supplementary Figure 13** . **Charge dddition voltages of all the quantum dots.** Histogram of the addition voltages of each quantum dot considering the first spacings, when detectable in the already existing datasets. The three horizontal lines identify the spread of the first hole addition voltage of 51 _±_ 6 mV. 

We extract the charge addition voltages of all the quantum dots from the corresponding stability diagrams to evaluate the level of homogeneity of the system (Suppl. Fig. **13** ). We consider the charge addition voltage as the spacing between two consecutive charge addition lines. We estimate the averaged spacing of the first and second hole to be 51 _±_ 6 mV and 50 _±_ 9, respectively, indicating a _∼_ 10 _−_ 20% variability of the quantum dot properties in the array. 

S15 

### **Supplementary Note 14. DEMONSTRATION OF THE ODD OCCUPATION REGIME** 

Here, we present sequences of measurements to demonstrate the claim of an odd number of holes confined in each quantum dot. To monitor the occupancy of a dot Q _i_ , we consider charge stability diagrams of the type vP _i_ versus vP _j_ with _i_ , _j ∈_ [1 _,_ 7] and _i̸_ = _j_ . Because the maximum amplitude of the AWG ramps at the device is only _∼_ 200 mV due to the attenuation in the lines, a single two-dimensional scan is not enough to evaluate directly the number of holes in a quantum dot. Rather we use a different approach. We start from the gate voltage regime presented in the main text Fig. 3 and proceed by moving the dc voltage vP _i_ in steps of 10 mV toward more positive voltages until Q _i_ is fully depleted. At every step, we take a fast two-dimensional scan that allows to label and count the number of transition lines visible in the available gate window. In Suppl. Figs. **14** - **25** , we present these measurements starting from an empty dot (left side) and finishing in the original configuration (right side), with a square labelling the (0,0) point in the map signalling the odd occupancy regime. In analogy to the main text, the red, blue, green and yellow frames of the plots indicate that the data have been measured with the NW, NE, SW and SE charge sensor, respectively. 



<!-- Start of picture text -->
a<br><!-- End of picture text -->



<!-- Start of picture text -->
1<br>1<br><!-- End of picture text -->

**Supplementary Figure 14** . **Counting the number of holes in Q1. a,** Schematic of the quantum dot grids labelling the dot Q1 **b-g,** Sequence of measurements (for improved visibility, we show here the raw data after subtracting a slow-varying background) that demonstrates the presence of a single hole in Q1. We use a dashed guide-for-the-eye trace and a label to indicate the first Q1 addition line. 

S16 



<!-- Start of picture text -->
a<br><!-- End of picture text -->



<!-- Start of picture text -->
1 1<br><!-- End of picture text -->



<!-- Start of picture text -->
1 1<br><!-- End of picture text -->

**Supplementary Figure 15** . **Counting the number of holes in Q2b and Q2t. a,** Schematic of the quantum dot grids labelling the dots Q2b and Q2t in different colours. **b-e,** Sequence of measurements (for improved visibility, we show here the raw data after subtracting a slow-varying background) that demonstrates the single-hole occupancy of Q2b and Q2t. In **(e)** , the square identifies the (Q1, Q2b, Q2t) (1,1,1) charge state. The coloured dashed lines and the label identify the two first addition lines. 



<!-- Start of picture text -->
a<br><!-- End of picture text -->



<!-- Start of picture text -->
1<br>1<br>2<br>2<br>3<br>3<br><!-- End of picture text -->

**Supplementary Figure 16** . **Counting the number of holes in Q3m. a,** Schematic of the quantum dot grids labelling the dot Q3m. **b-g,** Sequence of measurements (for improved visibility, we show here the raw data after subtracting a slow-varying background) that demonstrates the third-hole occupancy of Q3m. In **(g)** , the square identifies the (Q3m, Q2b, Q2t) (3,1,1) charge state. The gray dashed lines and the labels identify the first three addition lines in Q3m, which partially overlap with the addition lines of Q3b. 

S17 



<!-- Start of picture text -->
a<br><!-- End of picture text -->



<!-- Start of picture text -->
1<br>1 2<br>2<br>3<br>3<br><!-- End of picture text -->

**Supplementary Figure 17** . **Counting the number of holes in Q3b. a,** Schematic of the quantum dot grids labelling the dot Q3b. **b-g,** Sequence of measurements (for improved visibility, we show here the raw data after subtracting a slow-varying background) that demonstrates the third-hole occupancy of Q3b. In **(g)** , the square identifies the (Q3b, Q2b, Q2t) (3,1,1) charge state. The gray dashed lines and the labels identify the first three addition lines in Q3b, which partially overlap with the addition lines of Q3m. Quasi-vertical addition lines tunable by vP2 are associated with a stray dot under P2 outside the array. 



<!-- Start of picture text -->
a<br>1 1<br><!-- End of picture text -->

**Supplementary Figure 18** . **Counting the number of holes in Q4b and Q4mb. a,** Schematic of the quantum dot grids labelling the dots Q4b and Q4mb. **b-e,** Sequence of measurements (for improved visibility, we show here the raw data after subtracting a slow-varying background) that demonstrates the single-hole occupancy of Q4b and Q4mb. In **(e)** , the square identifies the (Q3b, Q4b, Q4mb) (3,1,1) charge state. The dashed lines and the labels identify the first addition lines of Q4b and Q4mb, which mostly overlap. Quasi-horizontal addition lines tunable by vP3 are associated with the quantum dot Q3b. 

S18 



<!-- Start of picture text -->
a<br>1<br>1 2<br>2<br><!-- End of picture text -->

**Supplementary Figure 19** . **Counting the number of holes in Q3t. a,** Schematic of the quantum dot grids labelling the dots Q3t. **b-f,** Sequence of measurements (for improved visibility, we show here the sum of the signals measured at the SW and SE charge sensor, after removal of a background) that demonstrates the single-hole occupancy of Q3t. The addition lines of Q3t are hard to sense due to a nearby stray dot, therefore we rely on following the charge interdot with the more-visible Q4t. Differently from other sequences, here we empty the dot Q3t by stepping the voltage on the nearby barrier vUB7. 



<!-- Start of picture text -->
a<br>1<br>1<br><!-- End of picture text -->

**Supplementary Figure 20** . **Counting the number of holes in Q5b. a,** Schematic of the quantum dot grids labelling the dots Q5b. **b-g,** Sequence of measurements (for improved visibility, we show here the raw data after subtracting a slow-varying background) that demonstrates the single-hole occupancy of Q5b. In **(g)** , the square identifies the (Q5b, Q4b, Q4mb) (1,1,1) charge state. The dashed lines and the labels identify the first addition lines of Q5b. Addition lines of Q5b are weakly visible, but can still be tracked by the interdots with Q4b and Q4mb. 

S19 

### **a** 



<!-- Start of picture text -->
1 1 1 1 1<br>1 1<br>1<br><!-- End of picture text -->



<!-- Start of picture text -->
1 1<br><!-- End of picture text -->

**Supplementary Figure 21** . **Counting the number of holes in Q4t, Q4mt, Q4mb. a,** Schematic of the quantum dot grids labelling the dots Q4t, Q4mt, Q4mb. **b-m,** and **n-y,** Sequence of measurements (for improved visibility, we show here the raw data after subtracting a slow-varying background) that demonstrates the single-hole occupancy of the three Q4mb, Q4mt, Q4t dots, collected at the SE and NE charge sensors, respectively. The identification of the transition lines is complicated by the slow loading mechanism in the dot Q4mt which mostly appears as a quasi-diagonal line (orange dashed lines). In **(m)** and **(y)** , Q5t appears close to the 1-2 charge transition at (0,0), rather than in the 1st hole regime, as shown in the main text Fig. 3c. Such difference is due to an intentional and specific shift in gate voltage of the NE sensor to improve the signal, which results in a modification of the electrostatics of Q4t. 

S20 



<!-- Start of picture text -->
a<br><!-- End of picture text -->



<!-- Start of picture text -->
1<br>1<br>1<br>1<br>2<br>2<br>2<br>3<br>2 3 3<br>3<br><!-- End of picture text -->

**Supplementary Figure 22** . **Counting the number of holes in Q5m and Q5t. a,** Schematic of the quantum dot grids labelling the dots Q5m and Q5t. **b-q,** Sequence of measurements (for improved visibility, we show here the partial derivative of the raw data along vP5) that demonstrates the third-hole occupancy of Q5m and Q5t. The dashed lines and the labels identify the first three addition lines in Q5m and Q5t. 

S21 



<!-- Start of picture text -->
a<br>1 1 2 2<br>3 3<br><!-- End of picture text -->

**Supplementary Figure 23** . **Counting the number of holes in Q6b. a,** Schematic of the quantum dot grids labelling the dot Q6b. **b-m,** Sequence of measurements (for improved visibility, we show here the partial derivative of the raw data along vP6) that demonstrates the third-hole occupancy of Q6b. The dashed lines and the labels identify the first three addition lines in Q6b. Due to the presence of a stray dot outside the array tunable by vP6, we step the barrier vUB3 rather than vP6 to isolate the shift of the Q6b addition line. In **(m)** , the square identifies the (Q6b, Q6t, Q7) (3,1,1) charge state. 



<!-- Start of picture text -->
a<br>1<br><!-- End of picture text -->



<!-- Start of picture text -->
1<br><!-- End of picture text -->

**Supplementary Figure 24** . **Counting the number of holes in Q6t. a,** Schematic of the quantum dot grids labelling the dot Q6t. **b-i,** Sequence of measurements (for improved visibility, we show here the partial derivative of the raw data along vP6) that demonstrates the single-hole occupancy of Q6t. Due to the presence of a stray dot outside the array tunable by vP6, we step the barrier vUB6 rather than vP6 to isolate the shift of the Q6t addition line. The dashed lines and the labels identify approximately the first addition line in Q6t. For vUB6 values bigger than _∼_ -305 mV, the loading in Q6t is slow therefore the addition line latches and is hardly visible Nevertheless, in the slow-loading regime, we can still track the interdots with dot Q7. In **(i)** , the square identifies the (Q6b, Q6t, Q7) (3,1,1) charge state. 

S22 



<!-- Start of picture text -->
a<br>1<br>1<br><!-- End of picture text -->

**Supplementary Figure 25** . **Counting the number of holes in Q7. a,** Schematic of the quantum dot grids labelling the dot Q7. **b-e,** Sequence of measurements (for improved visibility, we show here the raw data after subtracting a background) that demonstrates the single-hole occupancy of Q7. In **(e)** , the square identifies the (Q6b, Q6t, Q7) (3,1,1) charge state. The dashed lines and the labels identify the first addition lines of Q7. 

S23 

- [S1] R. Van Meter and D. Horsman, A blueprint for building a quantum computer, Commun. ACM **56** , 84–93 (2013). 

- [S2] D. P. Franke, J. S. Clarke, L. M. Vandersypen, and M. Veldhorst, Rent’s rule and extensibility in quantum computing, Microprocess. Microsyst. **67** , 1 (2019). 

- [S3] F. Arute, K. Arya, R. Babbush, D. Bacon, J. C. Bardin, R. Barends, R. Biswas, S. Boixo, F. G. S. L. Brandao, D. A. Buell, B. Burkett, Y. Chen, Z. Chen, B. Chiaro, R. Collins, W. Courtney, A. Dunsworth, E. Farhi, B. Foxen, A. Fowler, C. Gidney, M. Giustina, R. Graff, K. Guerin, S. Habegger, M. P. Harrigan, M. J. Hartmann, A. Ho, M. Hoffmann, T. Huang, T. S. Humble, S. V. Isakov, E. Jeffrey, Z. Jiang, D. Kafri, K. Kechedzhi, J. Kelly, P. V. Klimov, S. Knysh, A. Korotkov, F. Kostritsa, D. Landhuis, M. Lindmark, E. Lucero, D. Lyakh, S. Mandr`a, J. R. McClean, M. McEwen, A. Megrant, X. Mi, K. Michielsen, M. Mohseni, J. Mutus, O. Naaman, M. Neeley, C. Neill, M. Y. Niu, E. Ostby, A. Petukhov, J. C. Platt, C. Quintana, E. G. Rieffel, P. Roushan, N. C. Rubin, D. Sank, K. J. Satzinger, V. Smelyanskiy, K. J. Sung, M. D. Trevithick, A. Vainsencher, B. Villalonga, T. White, Z. J. Yao, P. Yeh, A. Zalcman, H. Neven, and J. M. Martinis, Quantum supremacy using a programmable superconducting processor, Nature **574** , 505 (2019). 

- [S4] S. G. J. Philips, M. T. M¸adzik, S. V. Amitonov, S. L. De Snoo, M. Russ, N. Kalhor, C. Volk, W. I. L. Lawrie, D. Brousse, L. Tryputen, B. Paquelet Wuetz, A. Sammak, M. Veldhorst, G. Scappucci, and L. M. K. Vandersypen, Universal control of a six-qubit quantum processor in silicon, arXiv 10.48550/arxiv.2202.09252 (2022). 

- [S5] M. Y. Lanzerotti, G. Fiorenza, and R. A. Rand, Microminiature packaging and integrated circuitry: The work of e. f. rent, with an application to on-chip interconnection requirements, IBM J. Res. Dev. **49** , 777 (2005). 

- [S6] N. W. Hendrickx, W. I. Lawrie, M. Russ, F. van Riggelen, S. L. de Snoo, R. N. Schouten, A. Sammak, G. Scappucci, and M. Veldhorst, A four-qubit germanium quantum processor, Nature **591** , 580 (2021). 

- [S7] P.-A. Mortemousque, E. Chanrion, B. Jadot, H. Flentje, A. Ludwig, A. D. Wieck, M. Urdampilleta, C. B¨auerle, and T. Meunier, Coherent control of individual electron spins in a two-dimensional quantum dot array, Nat. Nanotechnol. **16** , 296 (2021). 

- [S8] L. M. K. Vandersypen, H. Bluhm, J. S. Clarke, A. S. Dzurak, R. Ishihara, A. Morello, D. J. Reilly, L. R. Schreiber, and M. Veldhorst, Interfacing spin qubits in quantum dots and donors—hot, dense, and coherent, npj Quantum Inf. **3** (2017). 

- [S9] J. A. Morton and W. J. Pietenpol, The technological impact of transistors, PIRE **46** , 955 (1958). 

- [S10] P. Christie and D. Stroobandt, The interpretation and application of rent’s rule, IEEE Trans. Very Large Scale Integr. (VLSI) Syst. **8** , 639 (2000). 

- [S11] R. Li, L. Petit, D. P. Franke, J. P. Dehollain, J. Helsen, M. Steudtner, N. K. Thomas, Z. R. Yoscovits, K. J. Singh, S. Wehner, L. M. K. Vandersypen, J. S. Clarke, and M. Veldhorst, A crossbar network for silicon quantum dot qubits, Sci. Adv. **4** , eaar3960 (2018). 

- [S12] W. Ha, S. D. Ha, M. D. Choi, Y. Tang, A. E. Schmitz, M. P. Levendorf, K. Lee, J. M. Chappell, T. S. Adams, D. R. Hulbert, E. Acuna, R. S. Noah, J. W. Matten, M. P. Jura, J. A. Wright, M. T. Rakher, and M. G. Borselli, A flexible design platform for Si/SiGe exchange-only qubits with low disorder, Nano Lett. **22** , 1443 (2022). 

- [S13] P. L. Bavdaz, H. G. J. Eenink, J. van Staveren, M. Lodari, C. G. Almudever, J. S. Clarke, F. Sebastiano, M. Veldhorst, and G. Scappucci, A quantum dot crossbar with sublinear scaling of interconnects at cryogenic temperature, arXiv (2022). 

- [S14] X. Xue, M. Russ, N. Samkharadze, B. Undseth, A. Sammak, G. Scappucci, and L. M. K. Vandersypen, Quantum logic with spin qubits crossing the surface code threshold, Nature **601** , 343 (2022). 

- [S15] N. Hendrickx, D. Franke, A. Sammak, G. Scappucci, and M. Veldhorst, Fast two-qubit logic with holes in germanium, Nature **577** , 487 (2020). 

- [S16] M. Russ, D. M. Zajac, A. J. Sigillito, F. Borjans, J. M. Taylor, J. R. Petta, and G. Burkard, High-fidelity quantum gates in Si/SiGe double quantum dots, Phys. Rev. B **97** , 085421 (2018). 

- [S17] D. Loss and D. P. DiVincenzo, Quantum computation with quantum dots, Phys. Rev. A **57** , 120 (1998). 

- [S18] C. J. van Diepen, P. T. Eendebak, B. T. Buijtendorp, U. Mukhopadhyay, T. Fujita, C. Reichl, W. Wegscheider, and L. M. K. Vandersypen, Automated tuning of inter-dot tunnel coupling in double quantum dots, Appl. Phys. Lett. **113** , 033101 (2018). 

- [S19] L. Petit, J. Boter, H. Eenink, G. Droulers, M. Tagliaferri, R. Li, D. Franke, K. Singh, J. Clarke, R. Schouten, V. Dobrovitski, L. Vandersypen, and M. Veldhorst, Spin Lifetime and Charge Noise in Hot Silicon Quantum Dot Qubits, Phys. Rev. Lett. **121** , 076801 (2018). 

- [S20] L. DiCarlo, H. J. Lynch, A. C. Johnson, L. I. Childress, K. Crockett, C. M. Marcus, M. P. Hanson, and A. C. Gossard, Differential Charge Sensing and Charge Delocalization in a Tunable Double Quantum Dot, Phys. Rev. Lett. **92** , 226801 (2004). 

