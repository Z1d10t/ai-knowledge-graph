# Scalable integration of hybrid high-κ dielectric materials on two-dimensional semiconductors

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Materials |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 242 |
| 作者 | Yongshan Xu, Teng Liu, Kai-Lang Liu, Ying-He Zhao, Lei Liu, Peng-Hui Li, An-Min Nie, Li-Xin Liu et al. |
| DOI | 10.1038/s41563-023-01626-w |
| 源文件 | 089_Xu_2023_Scalable-integration-of-hybrid-high-κ-dielectric.pdf |

---




<!-- Start of picture text -->
Scalable integration of hybrid high -κ  dielectric<br>materials on two -d imensional semiconductors with<br>a van der Waals interface<br><!-- End of picture text -->

Huazhong University of Science and Technology 

Huazhong University of Science and Technology 

Huazhong University of Science and Technology 

Huazhong University of Science and Technology https://orcid.org/0000-0002-2331-8973 

Yanshan University 

Nanjing University 

Yanshan University 

Huazhong University of Science and Technology 

Huazhong University of Science and Technology 

Huazhong University of Science and Technology 

Huazhong University of Science and Technology https://orcid.org/0000-0003-3673-2257 

Huazhong University of Science and Technology https://orcid.org/0000-0001-8114-2542 

Nanjing University https://orcid.org/0000-0002-3975-1667 

Tianyou Zhai  (  zhaity@hust.edu.cn ) 

Huazhong University of Science and Technology https://orcid.org/0000-0003-0985-4806 

Page 1/21 

Posted Date: September 13th, 2022 

DOI: https://doi.org/10.21203/rs.3.rs-1967308/v1 

License:   This work is licensed under a Creative Commons Attribution 4.0 International License. Read Full License 

Version of Record: A version of this preprint was published at Nature Materials on August 3rd, 2023. See the published version at https://doi.org/10.1038/s41563-023-01626-w. 

Page 2/21 

Silicon semiconductor technology is approaching its downscaling limit in state-of-the-art electronics. Atomically thin two-dimensional (2D) semiconductors allow exceptional gate electrostatics in �eld-effect transistors (FETs), thus holding potential as the candidate channel materials beyond silicon. However, it remains challenging to integrate ultrathin and uniform high-κ dielectrics on 2D materials to fabricate FETs with large gate capacitances, though this is highly required to reduce the device operating voltage toward the energy-e�cient electronics. Here we report a versatile two-step approach to integrating highquality dielectric �lm with sub-1-nm equivalent oxide thickness (EOT) on 2D materials. Inorganic molecular crystal Sb2O3 is homogeneously deposited on 2D materials as a van der Waals buffer layer, which forms a high-quality oxide-to-semiconductor interface and offers a highly hydrophilic surface, enabling the integration of diverse high-κ dielectrics via atomic layer deposition. Using such an approach, we can fabricate monolayer molybdenum disul�de-based FETs with the ever-reported thinnest EOT (0.67 nm). The transistors exhibit an on/off ratio of over 10<sup>6</sup> using an ultralow operating voltage of 0.4 V, i.e., an unprecedentedly high gating e�ciency not matched by any previous FETs. Our results may pave the way for the applications of 2D materials in the future low-power ultra-scaling electronic devices. 

The continuous downscaling of silicon-based metal-oxide-semiconductor (MOS) �eld-effect transistors (FETs), which facilitated the development of modern semiconductor industry, is approaching its fundamental limit<sup>1</sup> . Further transistor scaling requires reducing the body thickness of channel semiconductor to mitigate the short-channel effects (SCEs)<sup>1–3</sup> . In this context, van der Waals (vdW) twodimensional (2D) semiconductors such as transition metal dichalcogenides (MoS2, WSe2, etc.) and black phosphorus exhibit exceptional advantages over silicon<sup>4–6</sup> . They can be ultimately thinned down to atomic thickness thanks to their layered structure, theoretically allowing unprecedentedly excellent gate control in a MOSFET architecture, and moreover, their charge carriers mobilities can be highly preserved at atomic thinness for their dangling-bond-free surface. For instance, the prototypical FETs based on 2D semiconductor MoS2 with sub-1-nm gate lengths have demonstrated their excellent current switching<sup>4,5</sup> . 

However, the vdW surface of 2D semiconductors also gives rise to another critical challenge: the integration of high-quality dielectrics. In theory, the characteristic length λ of FETs without SCEs is determined by<sup>2,7</sup> : 



<!-- Start of picture text -->
λ =  √tsεsEOT/εSiO2 with EOT= toxεSiO2/εox ,<br><!-- End of picture text -->

where ts, tox are respectively the thickness of channel semiconductor and gate dielectric layer; εs, εox and εSiO2 stands for the dielectric constants of channel semiconductor, gate dielectric layer, and silicon dioxide; EOT is the equivalent oxide thickness as de�ned. Clearly, besides the quest for the channel thinness (ts), it is of great signi�cance to integrate ultrathin high-κ dielectrics (small EOT) on 2D materials 

Page 3/21 

for the ultimate transistor scaling<sup>8</sup> . Moreover, a smaller EOT implies a larger gate capacitance, which can effectively reduce the supply voltage (Vdd) and the energy consumption of the devices. According to the International Roadmap for Devices and Systems (IRDS)<sup>9</sup> , the state-of-the-art MOSFETs (5-nm-node FinFET) require a sub-1-nm EOT and a Vdd lower than 0.8 V. Nevertheless, owing to the inert danglingbond-free surface of 2D materials, it has proved di�cult to integrate ultrathin dielectrics, particularly in a scalable way<sup>7</sup> . In addition, the integration process of dielectrics requires to be non-destructive, and ideally, they form a vdW interface with 2D semiconductors in order to preserve the intrinsic properties of 2D semiconductors and minimize the density of interfacial states<sup>10,11</sup> . Though various attempts, such as direct deposition<sup>12 − 15</sup> , oxidation of deposited metal<sup>16 − 23</sup> , surface pre-treatment<sup>24 − 31</sup> , organic materials as seeding layer<sup>7,32−34</sup> , have been made to address this critical challenge, a universal approach for the integration of high-quality dielectric layer with sub-1-nm EOT on 2D materials is yet to be explored. Due to the absence of high-quality dielectrics, despite an expectedly better gate electrostatics than conventional semiconductors, 2D FETs still require a higher operating voltage than the state-of-the-art Si MOSFETs. 

Here, we report a versatile approach to integrate ultrathin high-κ dielectric layer with sub-1-nm EOT on 2D materials. We deposit inorganic molecular crystal (IMC) antimony trioxide (Sb2O3) as a special buffer layer on 2D semiconductors. The buffer layer contacts with 2D semiconductors via vdW interaction, which creates a high-quality oxide-to-semiconductor interface with low interfacial state density. Moreover, the buffer layer covers up the hydrophobic 2D materials (such as graphene, TMDs) and offers a highly hydrophilic surface, allowing the integration of ultrathin high-κ dielectrics (HfO2, Al2O3 and ZrO2) via standard atomic layer deposition (ALD). In such a way, we can fabricate a hybrid inorganic dielectric layer with EOT of 0.67 nm on 2D semiconductors, which is, to the best of our knowledge, the ever-reported thinnest EOT integrated on 2D semiconductors. FETs made of monolayer MoS2 channel and Sb2O3/HfO2 hybrid dielectrics can switch over an on/off ratio of 10<sup>6</sup> using an ultralow operating voltage of 0.4 V with subthreshold swing (SS) approaching thermionic limit of 60 mV dec<sup>− 1</sup> . This exceptional gating e�ciency that cannot be matched by any reported FETs, are attributed to our high-quality dielectric layer and the excellent electrostatic controllability of 2D semiconductors. 

The integration processes of the hybrid dielectric layer start with the fabrication of Sb2O3 on 2D semiconductors via thermal evaporation deposition method (Fig. 1a). We choose a thinnest layer Sb2O3 of 1 nm that can fully cover the surface of 2D materials as the buffer layer. Afterwards, typical high-κ dielectrics, for instance HfO2, can be integrated on Sb2O3 via a standard process of ALD to form a hybrid dielectric layer on 2D semiconductors (see details in Methods). As revealed by the atomic force microscopic (AFM) images (Fig. 1b), both the deposited Sb2O3 layer and HfO2 layer remain dense and homogeneous, without observable voids. The integration of Sb2O3 and HfO2 layers slightly roughens the atomically �at MoS2 surface, as shown in the height histograms (Fig. 1c). In contrast, direct deposition of HfO2 on 2D materials results in a rough and porous layer, with some HfO2 particles nucleated probably at 

Page 4/21 

the defect sites (Supplementary Fig. 1a and b). We also demonstrate that this excellent buffering effect of Sb2O3 promoting the ALD of HfO2 can clearly be observed on few-layer graphene (Supplementary Fig. 1c). As probed by Raman spectroscopy (Supplementary Fig. 3a and b), the underlying 2D materials are remained intact during the dielectric integration. Moreover, this approach is applicable for the integration of various dielectrics (Al2O3 and ZrO2) since they share the same ALD mechanisms (Supplementary Fig. 2a and b). 

To analyze the quality of the dielectric layer in atomic scale, we observe the cross-sectional interface of the stacking layers via scanning transmission electron microscopy (STEM). The two layers of Sb2O3 and HfO2 stacking on MoS2 can be clearly identi�ed (Fig. 1d), exhibiting atomical homogeneity over the whole surface of MoS2, which agrees well with our observation by AFM (Fig. 1b). Moreover, the top layer of MoS2 clearly remained intact, without observable damage induced by the dielectric integration process (Fig. 1d). The stacking structure of HfO2/Sb2O3/MoS2 is also con�rmed by the elemental maps (Hf, Sb and Mo) at the interface (Fig. 1e). The electron energy loss spectrum (EELS) of Sb2O3 indicates its preservation of molecular structure in the whole integration process (Fig. 1f)<sup>35</sup> , which means that the deposited Sb2O3 layer forms a vdW contact with MoS2. Such a vdW interface between 2D semiconductor and oxide has proved critical for the device performance<sup>36</sup> . As the buffer layer merely ignites the ALD process of high-κ dielectrics, the interface remains the same for the integration of a thicker layer HfO2 (Supplementary Fig. 4). 

We now try to get insight into the formation mechanisms of the Sb2O3 and HfO2 layers atop 2D materials. With respect to this two-step process, we �rstly carried out molecular dynamics (MD) simulation to investigate the deposition behaviors of Sb2O3 molecules on 2D MoS2, and then use �rstprinciples calculations to �gure out the precursor adsorption mechanisms in ALD (see Methods for details). Sb2O3 molecules may experience various behaviors (deposition, surface diffusion, re�ection and nucleation etc.) in the MD simulations (Fig. 2a). From the simulations (Supplementary Video 1), Sb2O3 molecules can spontaneously form a homogeneous and dense layer on 2D materials when enough molecules are deposited (Fig. 2b). Interestingly, we �nd that the interlayer distance (3.32 Å) between the stabilized Sb2O3 layer and MoS2 approximates the vdW gaps within MoS2 (3.33 Å), which con�rms the formation of vdW interface between Sb2O3 and MoS2 (Fig. 2b). Such a homogeneous Sb2O3 layer contacting 2D MoS2 via vdW interaction can be maintained at a stable state for a long period of simulation time (Fig. 2c). We then turn to the adsorption of the precursors, which plays a decisive role in ALD process (Supplementary Fig. 5). We �rst optimized the adsorption of precursor H2O molecules on MoS2 surface and �gure out �ve possible adsorption con�gurations, with H2O/MoS2 distance around 3 Å (Fig. 2d). Contrarily, the optimized adsorption con�gurations of H2O on Sb2O3 exhibit much smaller interatomic distances of below 2 Å, approaching the typical length of hydrogen bonds in water (Fig. 2e and Supplementary Fig. 6a)<sup>37</sup> . We then calculated the adsorption energies of all such con�gurations, as presented together with the interatomic distances in Fig. 2f. The larger adsorption energies and smaller distances of H2O on Sb2O3 surface imply that the Sb2O3 molecules dramatically improve the adsorption 

Page 5/21 

probability of precursors in the ALD process. Such a contrast of Sb2O3 promoting H2O adsorption can also be found on graphene (Supplementary Fig. 6b). The adsorption tendency of H2O molecules in molecular scale can be veri�ed by the wetting behaviors of water droplet in macroscale. We experimentally demonstrate that a thin Sb2O3 layer can greatly increase the hydrophilicity of graphene, with a reduction of contact angle from 90<sup>o</sup> to 54<sup>o</sup> (Supplementary Fig. 7a and b). Moreover, we are able to probe the formation of HfO2 on the surface of Sb2O3 using X-ray photoelectron spectroscopy (XPS) on the sample with only one H2O-TDMAHf ALD cycle (Supplementary Fig. 7c), which furthermore con�rms an e�cient precursor adsorption on Sb2O3 layer. 

We now demonstrate the application of our hybrid dielectric layer in high-performance 2D electronic devices. We integrate the hybrid Sb2O3/HfO2 dielectric layer on 2D semiconductors to fabricate 2D FETs and investigate their device performance. In the FETs (Fig. 3a), 2D MoS2 is representatively chosen as the channel semiconductors, Bi/Au is used as the electrode to minimize contact resistance<sup>38</sup> and the Sb2O3/HfO2 layer is integrated on the top of MoS2 as the gate dielectrics (see Methods for details). We �rst examine the FETs based on monolayer MoS2 prepared by mechanical exfoliation, usually with high crystal quality. For a systematic study, we designed two different thickness of our hybrid dielectric layer (td = 3 nm and 5 nm), respectively with HfO2 of 2 nm and 4 nm on the buffer layer of 1 nm Sb2O3. For such FETs with td of 3 nm and 5 nm (corresponding to ultrasmall EOT of 0.67 nm and 1.01 nm), the drain-to-source currents Ids abruptly switch over 10<sup>6</sup> within an ultralow top-gate voltage of 0.4 V (Fig. 3b). The FET with EOT of 0.67 nm exhibits a full on/off ratio over 10<sup>7</sup> using a low operating voltage of 0.6 V (Fig. 3b). Such a high gating e�ciency is obviously attributed to an ultralow subthreshold swing (SS) in the transfer characteristics. We can identify a range of Ids switching over 4 orders of magnitude (Supplementary Fig. 8c and 9c), with SS remaining at the Boltzmann thermionic limit of approximately 60 mV dec<sup>− 1</sup> (Fig. 3b). The output curves furthermore veri�ed that the top gate effectively controls the conductance of channel MoS2 (Supplementary Fig. 8d and 9d). A dozen of such FETs have been fabricated to verify the reliability of our dielectric integration approach. All the FETs demonstrate SS between 60 and 75 mV dec<sup>− 1</sup> . Despite such slight deviations of SS from 60 mV dec<sup>− 1</sup> , probably resulting from the interface states introduced in the device fabrication process, this performance still adheres to the requirements of future FETs proposed in IRDS<sup>9</sup> . Based on the minimum SS of 60 mV dec<sup>− 1</sup> that we have achieved in our FETs, we are capable of estimating the typical density of interface states (Dit) between our hybrid dielectric layer and MoS2 channel to be 1.4×10<sup>11</sup> and 2.2×10<sup>11</sup> cm<sup>− 2</sup> eV<sup>− 1</sup> respectively for td of 5 and 3 nm (see Methods). Such a small Dit may be attributed to the formation of vdW interface during the integration of our hybrid dielectric. 

We try to extract the exact EOTs of our hybrid dielectric layers in devices via measuring the electrical transport of dual-gating FETs (Supplementary Fig. 8a, b and 9a, b). The EOTs for hybrid dielectric layer 

Page 6/21 

with td of 3 nm and 5 nm are respectively measured to be 0.67 and 1.01 nm, both of which are in good agreement with the theoretical values of 0.65 nm and 0.96 nm (See calculations in Methods). Moreover, using a capacitor device, we directly measured the capacitance of the dielectric layer with td=5 nm under various bias voltages and at various frequencies (Supplementary Fig. 10). Thanks to the all-inorganic dielectric materials of our hybrid dielectrics, the capacitance stably remains between 3.2 and 3.5 µF cm<sup>− 2</sup> within a broad range of frequency, agreeing with the calculated static capacitance of 3.45 µF cm<sup>− 2</sup> . 

Obviously, our dielectrics integration approach on 2D semiconductors is compatible with the CMOS manufacturing processes. To demonstrate the reproducibility of our devices and their application potential in future integrated circuits, we use large-scale monolayer MoS2 obtained by chemical vapor deposition (CVD) as the channel semiconductor to fabricate FETs arrays and common logic gates (Supplementary Fig. 11). We fabricate 16 FETs in an array with td of 5 nm (Fig. 3d) and �nd 14 of them can normally work, with a yield of 87.5%. All these FETs need operating voltages of about 0.8 V (Fig. 3e), while exhibiting on/off ratio and SS that are comparable with the state-of-the-art Si FETs (Fig. 3f). Our approach also allows the integration of logic gates with low supply voltage Vdd (Fig. 3g). For example, using 1-nm-EOT dielectrics, the NAND, NOR and NOT can operate with Vdd of 0.5 V (Fig. 3g and h). Our approach is scalable and exhibits a high reproducibility, leading to a considerably high device yield. We con�rm the application potential of our dielectric layer in 2D integrated circuits. 

The FETs using our hybrid dielectrics exhibit superior performance regarding some important �gures of merit, including SS, on/off ratio, and operating voltages. Nevertheless, the on-state current is still limited due to the wide channels and a local top gate that can only partly control the channel semiconductors. We demonstrate that the on-state current can be signi�cantly improved in FETs with the global back gate and a shorter channel (Fig. 4a-c). For the FET with a global back gate and smaller channel length Lch (< 100 nm), the SS remains below 70 mV dec<sup>− 1</sup> (Fig. 4b) and the on-state current density goes beyond 100 µA µm<sup>− 1</sup> (Fig. 4b). An on/off ratio of over 10<sup>8</sup> can be realized using a low gate voltage of 0.65 V (Fig. 4b). The global back gate e�ciently controls the whole channel, giving rise to a much larger on-state current over 250 µA µm<sup>− 1</sup> (Fig. 4c). We expect that, if narrower-channel FETs can be fabricated, the on-state current density of our FETs would be furthermore improved to the magnitude of mA µm<sup>− 1</sup> . 

We benchmark the device performance of our FETs with the state-of-the-art 2D FETs and silicon MOSFETs (Fig. 4d and e). We achieved the integration of dielectric layer with the thinnest EOT (0.67 nm) on 2D semiconductors via a high-quality semiconductor-to-oxide interface, resulting in an excellent gate control over the channel conductance with SS of 60 mV dec<sup>− 1</sup> (Fig. 4d). In addition, as the atomically thin 2D semiconductors intrinsically have a reduced electrostatic screening effect, 2D FETs with the thinnest gate dielectric EOT demonstrates unprecedentedly e�cient gating controllability in ever-reported FETs, i.e., achieving a large on/off ratio with a small operating voltage (Fig. 4e). It is worth noting that our hybrid dielectric layer is consisting of all inorganic oxides, with a breakdown electric �eld of 17.6 MV cm<sup>−</sup> 

Page 7/21 

1 (Supplementary Fig. 12a). The leakage current remains below 10− 7 A cm− 2 (DRAM limit) under an electric �eld of 2.4 MV cm<sup>− 1</sup> (Supplementary Fig. 12a). Such dielectric properties also outperform the reported dielectric layers integrated on 2D materials, which may render its further applications in other devices beyond FETs (Supplementary Fig. 12b-c)<sup>7,13,15–19,23−28,30,32–34,39,43,44</sup> . Moreover, we also show an excellent environmental stability of our FET in 7 months to exhibit the robustness of our dielectric layer (Supplementary Fig. 13). In general, given the great properties of our hybrid dielectric layer and the demonstrated device performance of the integrated 2D FETs (Supplementary Table 1)<sup>7,12–</sup> 14,19−21,26,28,29,31,32,41,45, we expect to �nd its applications in the ultra-scaling low-power 2D devices in the future. 



<!-- Start of picture text -->
Declarations<br>Acknowledgements<br><!-- End of picture text -->

This work was supported by the National Nature Science Foundation of China (21825103, U21A2069). We also acknowledge the Analytical and Testing Center of Huazhong University of Science and Technology for the XPS characterizations and analysis. We thank Yihua Gao and Li Sun (Huazhong University of Science and Technology) for providing us with graphene and measuring the contact angle. 

K.L and T.Z conceived the ideas. Y.X and K.L designed and carried out most experiments under T.Z.’s supervision. T.L and Y.Z carried out the works of molecular dynamic simulation and �rst-principles calculations. P.L and A.N prepared the cross-sectional samples and performed the STEM characterizations. Lei. L and X.W prepared the large-scale monolayer MoS2. F.Z, X.F and J.Y helped to analyze the data. Y.X, K.L and T.L worked on the images with assistance from all the others. K.L wrote the paper with inputs of all the co-authors. 

The authors declare no competing �nancial interests. 

1.     Akinwande, D. et al. Graphene and two-dimensional materials for silicon technology. Nature 573, 507-518 (2019). 

2.     Liu, Y. et al. Promises and prospects of two-dimensional transistors. Nature 591, 43-53 (2021). 

3.     Das, S. et al. Transistors based on two-dimensional materials for future integrated circuits. Nat. Electron. 4, 786-799 (2021). 

4.     Desai, S. B. et al. MoS2 transistors with 1-nanometer gate lengths. Science 354, 99-102 (2016). 

Page 8/21 

5.     Wu, F. et al. Vertical MoS2 transistors with sub-1-nm gate lengths. Nature 603, 259-264 (2022). 

6.     Fiori, G. et al. Electronics based on two-dimensional materials. Nat. Nanotechnol. 9, 768-779 (2014). 

7.     Li, W. et al. Uniform and ultrathin high-κ gate dielectrics for two-dimensional electronic devices. Nat. Electron. 2, 563-571 (2019). 

8.     Cheema, S. S. et al. Ultrathin ferroic HfO2-ZrO2 superlattice gate stack for advanced transistors. Nature 604, 65-71 (2022). 

9.     Badaroglu, M. e. a. More Moore, International Roadmap for Devices and Systems 2021 https://irds.ieee.org/editions/2021/more-moore (2021). 

10.   Knobloch, T. et al. The performance limits of hexagonal boron nitride as an insulator for scaled CMOS devices based on two-dimensional materials. Nat. Electron. 4, 98-108 (2021). 

11.   Illarionov, Y. Y. et al. Insulators for 2D nanoelectronics: the gap to bridge. Nat. Commun. 11, 3385 (2020). 

12.   Radisavljevic, B. et al. Single-layer MoS2 transistors. Nat. Nanotechnol. 6, 147-150 (2011). 

13.   Liu, H. & Ye, P. D. MoS2 dual-gate MOSFET with atomic-layer-deposited Al2O3 as top-gate dielectric. IEEE Electron Device Lett. 33, 546-548 (2012). 

14.   Fang, H. et al. High-performance single layered WSe2 p-FETs with chemically doped contacts. Nano Lett. 12, 3788-3792 (2012). 

15.   Liu, K. et al. A wafer-scale van der Waals dielectric made from an inorganic molecular crystal �lm. Nat. Electron. 4, 906-913 (2021). 

16.   Jeong, S.-J. et al. Thickness scaling of atomic-layer-deposited HfO2 �lms and their application to wafer-scale graphene tunnelling transistors. Sci. Rep. 6, 20907 (2016). 

17.   Zhu, Y. et al. Monolayer molybdenum disul�de transistors with single-atom-thick gates. Nano Lett. 18, 3807-3813 (2018). 

18.   Takahashi, N. & Nagashio, K. Buffer layer engineering on graphene via various oxidation methods for atomic layer deposition. Appl. Phys. Express 9, 125101 (2016). 

19.   Zou, X. et al. Interface engineering for high-performance top-gated MoS2 �eld-effect transistors. Adv. Mater. 26, 6255-6261 (2014). 

20.   Lin, D. et al. Dual gate synthetic WS2 MOSFETs with 120 μS/μm Gm 2.7 μF/cm<sup>2</sup> capacitance and ambipolar channel. In 2020 IEEE International Electron Devices Meeting (IEDM). 3.6.1-3.6.4 (IEEE, 2020) 

Page 9/21 

21.   Xu, K. et al. Sub-10 nm nanopattern architecture for 2D material �eld-effect transistors. Nano Lett. 17, 1065-1070 (2017). 

22.   Fisichella, G. et al. Interface electrical properties of Al2O3 thin �lms on graphene obtained by atomic layer deposition with an in situ seedlike layer. ACS Appl. Mater. Interfaces 9, 7761-7771 (2017). 

23.   Park, Y. H. et al. Enhanced nucleation of high-κ dielectrics on graphene by atomic layer deposition. Chem. Mater. 28, 7268-7275 (2016). 

24.   Zheng, L. et al. Improvement of Al2O3 �lms on graphene grown by atomic layer deposition with preH2O treatment. ACS Appl. Mater. Interfaces 6, 7014-7019 (2014). 

25.   Xiao, M., Qiu, C., Zhang, Z. & Peng, L.-M. Atomic-layer-deposition growth of an ultrathin HfO2 �lm on graphene. ACS Appl. Mater. Interfaces 9, 34050-34056 (2017). 

26.   Wang, X. et al. Improved integration of ultra-thin high-κ dielectrics in few-layer MoS2 FET by remote forming gas plasma pretreatment. Appl. Phys. Lett. 110, 053110 (2017). 

27.   Nayfeh, O. M., Marr, T. & Dubey, M. Impact of plasma-assisted atomic-layer-deposited gate dielectric on graphene transistors. IEEE Electron Device Lett. 32, 473-475 (2011). 

28.   Yang, W. et al. The integration of sub-10 nm gate oxide on MoS2 with ultra low leakage and enhanced mobility. Sci. Rep. 5, 11921 (2015). 

29.   Bolshakov, P. et al. Improvement in top-gate MoS2 transistor performance due to high quality backside Al2O3 layer. Appl. Phys. Lett. 111, 032110 (2017). 

30.   Jandhyala, S. et al. Atomic layer deposition of dielectrics on graphene using reversibly physisorbed ozone. ACS Nano 6, 2722-2730 (2012). 

31.   Wang, J. et al. Integration of high-κ oxide on MoS2 by using ozone pretreatment for highperformance MoS2 top-gated transistor with thickness-dependent carrier scattering investigation. Small 11, 5932-5938 (2015). 

32.   Park, J. H. et al. Atomic layer deposition of Al2O3 on WSe2 functionalized by titanyl phthalocyanine. ACS Nano 10, 6888-6896 (2016). 

33.   Alaboson, J. M. P. et al. Seeding atomic layer deposition of high-κ dielectrics on epitaxial graphene with organic self-assembled monolayers. ACS Nano 5, 5223-5232 (2011). 

34.   Sangwan, V. K. et al. Quantitatively enhanced reliability and uniformity of high-κ dielectrics on graphene enabled by self-assembled seeding layers. Nano Lett. 13, 1162-1167 (2013). 

Page 10/21 

35.   Bouchet, D., Roy, E., Yu-Zhang, K. & Leprince-Wang, Y. TEM and EELS studies of electrodeposited antimony nanowires. Eur. Phys. J. Appl. Phys. 30, 193-199 (2005). 

36.   Cui, X. et al. Multi-terminal transport measurements of MoS2 using a van der Waals heterostructure device platform. Nat. Nanotechnol. 10, 534-540 (2015). 

37.   Yang, J. et al. Direct observation of ultrafast hydrogen bond strengthening in liquid water. Nature 596, 531-535 (2021). 

38.   Shen, P. C. et al. Ultralow contact resistance between semimetal and monolayer semiconductors. Nature 593, 211-217 (2021). 

39.   Cheng, L. et al. Sub-10 nm tunable hybrid dielectric engineering on MoS2 for two-dimensional material-based devices. ACS Nano 11, 10243-10252 (2017). 

40.   Li, W. et al. High-Performance CVD MoS2 Transistors with Self-Aligned Top-Gate and Bi Contact. In 2021 IEEE International Electron Devices Meeting (IEDM). 37.3.1-37.3.4 (IEEE, 2021). 

41.   Qian, Q. et al. Improved gate dielectric deposition and enhanced electrical stability for single-layer MoS2 MOSFET with an AlN interfacial layer. Sci. Rep. 6, 27676 (2016). 

42.   Chamlagain, B. et al. Thermally oxidized 2D TaS2 as a high-κ gate dielectric for MoS2 �eld-effect transistors. 2D Mater. 4, 031002 (2017). 

43.   Natarajan, S. et al. A 14 nm logic technology featuring 2<sup>nd</sup> -generation FinFET, air-gapped interconnects, self-aligned double patterning and a 0.0588 µm<sup>2</sup> SRAM cell size. In 2014 IEEE International Electron Devices Meeting (IEDM). 3.7.1-3.7.3 (IEEE, 2014). 

44.   Gusev, E. P. et al. Ultrathin high-κ gate stacks for advanced CMOS devices. In International Electron Devices Meeting. Technical Digest (Cat. No.01CH37224). 20.1.1-20.1.4 (IEEE, 2001). 

45.   Liu, H. et al. Statistical study of deep submicron dual-gated �eld-effect transistors on monolayer chemical vapor deposition molybdenum disul�de �lms. Nano Lett. 13, 2640-2646 (2013). 



<!-- Start of picture text -->
methods<br>Thermal evaporation deposition of Sb2O3<br><!-- End of picture text -->

The deposition of Sb2O3 is carried out in a standard thermal evaporation deposition system (Nexdep, Angstrom Engineering) in a high vacuum (10<sup>-6</sup> torr)<sup>15</sup> . Sb2O3 powder is sublimated by heating and deposited on the surface of the substrate. The deposition rate is precisely controlled by an in-situ quartz crystal oscillator. To maintain the �atness of the obtained Sb2O3 �lm, the deposition rate in this work is 0.03 Å s<sup>-1</sup> for the entire fabrication process. 

Page 11/21 

The ALD process is carried out in a hot-wall, closed-chamber desk-top ALD reactor (GEMSTAR XT, ARRADIANCE). All the deposition processes are executed at a base pressure of ~50 mTorr and used 40 sccm Ar as the carrier gas. ALD of HfO2 proceeds at 140<sup>o</sup> C using tetrakis(dimethylamido)hafnium (TDMAHf) and H2O as precursors. The TDMAHf precursor container is heated to 75<sup>o</sup> C. The pulse/purge times for TDMAHf and H2O precursors are 1000 ms/20 s and 60 ms/20 s, respectively. The ALD of ZrO2 is carried out at 150<sup>o</sup> C, tetrakis(dimethylamino)zirconium (TDMAZr) and H2O are the precursors. The TDMAZr precursor container is heated to 60<sup>o</sup> C. The pulse/purge times for TDMAZr and H2O are 60 ms/30 s and 60 ms/30 s, respectively. For Al2O3 deposition, the deposition temperature is 140<sup>o</sup> C and the precursors are trimethylaluminum (TMA) and H2O. The pulse/purge times for TMA and H2O are 100 ms/30 s and 60 ms/30 s, respectively. 

2D MoS2 �akes and few-layer graphene are mechanically exfoliated onto the 300 nm SiO2/Si substrate by the standard scotch tape technique. Large-scale monolayer MoS2 �lm is grown on a sapphire substrate via CVD method and then transferred on to SiO2/substrate<sup>46</sup> . 

The morphological characterization and surface �atness measurements of the samples are carried out on AFM (Bruker Dimension FastScan) with a peak-force tapping mode. Raman spectroscopy is performed on a confocal Raman system (WITec Alpha300) with an incident laser of 532 nm at 5 mW. The cross-sectional samples of HfO2/Sb2O3/MoS2 stacking layered are fabricated with a standard lift-out process using an FEI Helios G5 UX dual-beam focused ion beam (FIB) system. STEM characterization and EDS analyses are carried out on a JEOL ARM300F2 GRAND ARM<sup>TM</sup> 2 atomic resolution analytical microscope with an accelerating voltage of 300 kV. Bright-�eld imaging mode is chosen for the sample observation and elemental mapping is used to distinguish the different stack layers, including Hf, Sb and Mo. A Gatan dual-EELS system is used for STEM-EELS data acquisition to further con�rm the presence of Sb2O3 layer. 

Molecular dynamics simulations are performed by LAMMPS Molecular Dynamics Simulator and the visualization is realized by OVITO and VMD 1.9.3<sup>47-49</sup> . The Sb2O3 molecule is described by UFF force �eld and its atomic charges are obtained by bader charge analysis<sup>50,51</sup> . The substrate MoS2 is described by empirical force �eld VA8 model, which is considered as a promising model in the prediction of structural properties of MoS252,53. The non-bonded interactions are described by the van der Waals interactions and the electrostatic interactions with a cutoff of 1.25 nm. The former is modeled by 12-6 Lennard-Jones 

Page 12/21 

potential with parameters of UFF force �eld. The latter is modeled by Coulomb’s law with a PPPM method computing long-range Coulombic interactions<sup>54</sup> . The timestep in simulation is set to 1 fs. Before the deposition simulation of Sb2O3 �lm, the substrate MoS2 consisting of 5376 Mo atoms and 10752 S atoms with a size of 15.187 nm × 15.344 nm is fully relaxed in the NPT ensemble at 300 K. The corresponding simulation box size during deposition is 15.187 nm×15.344 nm × 15.3 nm, with periodic boundary in X, Y direction and �xed boundary in the Z direction. The Sb2O3 �lm deposition process is simulated by injecting Sb4O6 molecules at 14 nm in the Z direction per 8000 fs. The initial kinetic energy of the injected Sb4O6 molecules is 0.2 eV in a direction perpendicular to the substrate. The bottom layer of substrate MoS2 is �xed to modify bulk condition and the upper layer is free to interact with injected Sb4O6 molecules. The system is simulated in the NVT ensemble and the temperature is controlled at 300 K in the Langevin thermostat<sup>55</sup> . After deposition process, another 4 ns is simulated to make the system reach equilibrium. The interlayer distance is calculated as , where  is the centroid of mass of upper layer, where  is the centroid of mass of lower layer,  is the thickness of upper layer and  is the thickness of lower layer. 

The DFT calculations were performed by VASP package and the post-processing data was conducted by VASPKIT<sup>56,57</sup> . The Perdew-Burke-Ernzerhof (PBE) functional in the generalized gradient approximation (GGA) was implemented to describe the exchange-correlation interaction and the projector-augmented wave pseudopotential plane-wave method was used to describe the core-electron interaction<sup>58,59</sup> . The planewave cutoff energy was set to 520 eV in both lattice relaxation and static calculation. The Brillouin zone was sampled by a gamma-centered Monkhorst-Pack k-mesh with reciprocal lattice spacing ≤ 0.2 Å<sup>60</sup> . The convergence criterion was 10<sup>-8</sup> eV for energy and 10<sup>-2</sup> eV Å<sup>-1</sup> for force. DFT-D3 method was utilized to better describe interactions<sup>61</sup> . The adsorption energy of single molecule H2O is calculated as, where  is the total energy of system,  is the energy of substrate model and  is the energy of H2O molecule in gas phase, is the number of adsorbed molecule H2O. 

The water contact angle measurements are performed at POWEREACH JC2000D1. The XPS measurement is carried out on an AXIS SUPRA+ XPS instrument. All the XPS spectra presented in this work are calibrated by the C1s peak at 284.8 eV. 

The monolayer MoS2 �lms grown by CVD are transferred from sapphire growth substrate onto the SiO2/Si substrate for the device fabrication using a wet transfer process. First, poly(methyl methacrylate) (PMMA) is spin-coated (2000 rpm) onto the MoS2 �lm and baked on the hotplate at 100<sup>o</sup> C for 5 min. Then, the PMMA/MoS2 stacks are released from the sapphire by etching in 0.5 mol/L sodium hydroxide 

Page 13/21 

aqueous solution at 60<sup>o</sup> C. The freestanding PMMA/MoS2 �lm is �shed up by SiO2/Si substrate then rinsed in deionized water for several times. To dry the samples and enhance the adhesion, the SiO2/Si substrate with PMMA/MoS2 �lm is baked on the hotplate at 60<sup>o</sup> C for 30 min. Finally, the sample is immersed in acetone at 60<sup>o</sup> C for 12 h to remove the PMMA. 

All the top-gate transistors adopted similar fabrication procedures. First, source and drain electrodes are patterned by standard electron-beam lithography (EBL), followed by the deposition of electrodes metal. After the lift-off of metal in acetone, the device is further rinsed in clean acetone for 12 hours at 60<sup>o</sup> C to minimize the residues of PMMA on the surface of 2D materials. The cleanness of 2D materials plays an important role in the subsequent deposition of Sb2O3 and ALD process. Then, Sb2O3 and HfO2 are deposited onto the channel area using the afore-mentioned methods. Finally, the gate electrode is aligned patterned between the source and drain and similarly fabricated. For all the FETs based on exfoliated and CVD MoS2, 10 nm Bi/90 nm Au is used as the source, drain and gate electrodes. 

The fabrication of logic gates is largely the same as the fabrication of the top-gate transistor. To obtain the logic devices array, MoS2 �lm is �rst etched into several separate parts using EBL-patterned PMMA as the mask with reactive ion etching (RIE). Then, the Bi/Au bottom-electrode, HfO2/Sb2O3 dielectric layer and Bi/Au top-electrode are prepared as described before. 

Electrical measurements are carried out with a Keithley 4200 semiconductor parameter analyzer. We pump the chamber and keep it in a high vacuum (10<sup>-6</sup> torr) for 1 h to eliminate the gas adsorption on device surface before the device test. C-V and C-f measurements are performed with a Keysight B1500A semiconductor characterization system. 

The dielectric property parameters mainly include capacitance, dielectric constant and equivalent oxide thickness. Theoretically, the capacitance of the stack (Ctg) comprises contribution from both Sb2O3 and HfO2: 

Page 14/21 



where Cbg and Vbg are the capacitance and applied voltage of back-gate respectively, and Vth (tg) is the threshold voltage of top-gate. The capacitance of SiO2 substrate (300 nm) is estimated to be 1.15x10<sup>-2</sup> µF cm<sup>-2</sup> . The equivalent oxide thickness (EOT) is calculated as 



where 3.45 µF cm<sup>-2</sup> is the gate capacitance of 1 nm SiO2. 

Density of interface states (Dit) is employed to evaluate the interface quality using the equation<sup>19,63</sup> : 



where Ci is the capacitance per unit area of top-gate, q represents the electron charge, SS designates the subthreshold slope, k is the Boltzmann constant and T signi�es the test temperature. 

46.   Li, T. et al. Epitaxial growth of wafer-scale molybdenum disul�de semiconductor single crystals on sapphire. Nat. Nanotechnol. 16, 1201-1207 (2021). 

47.   Plimpton, S. Fast parallel algorithms for short-range molecular dynamics. J. Comput. Phys. 117, 1-19 (1995). 

Page 15/21 

48.   Stukowski, A. Visualization and analysis of atomistic simulation data with OVITO-the Open Visualization Tool. Modelling Simul. Mater. Sci. Eng. 18, 015012 (2009). 

49.   Humphrey, W., Dalke, A. & Schulten, K. VMD: Visual molecular dynamics. J. Mol. Graph. 14, 33-38 (1996). 

50.   Rappe, A. K. et al. UFF, a full periodic table force �eld for molecular mechanics and molecular dynamics simulations. J. Am. Chem. Soc. 114, 10024-10035 (1992). 

51.   Tang, W., Sanville, E. & Henkelman, G. A grid-based Bader analysis algorithm without lattice bias. J. Phys.: Condens. Matter 21, 084204 (2009). 

52.   Varshney, V. et al. MD simulations of molybdenum disulphide (MoS2): Force-�eld parameterization and thermal transport behavior. Comput. Mater. Sci. 48, 101-108 (2010). 

53.   Nicolini, P. & Polcar, T. A comparison of empirical potentials for sliding simulations of MoS2. Comput. Mater. Sci. 115, 158-169 (2016). 

54.   Hockney, R. W. & Eastwood, J. W. Computer simulation using particles. 1st Edition edn, 540 (CRC Press, 1988). 

55.   Allen, M. P. & Tildesley, D. J. Computer simulation of liquids. (Oxford university press, 2017). 

56.   Kresse, G. & Hafner, J. Ab initio molecular dynamics for liquid metals. Phys. Rev. B 47, 558-561 (1993). 

57.   Wang, V. et al. VASPKIT: A user-friendly interface facilitating high-throughput computing and analysis using VASP code. Comput. Phys. Commun. 267, 108033 (2021). 

58.   Perdew, J. P., Burke, K. & Ernzerhof, M. Generalized gradient approximation made simple. Phys. Rev. Lett. 77, 3865-3868 (1996). 

59.   Blöchl, P. E. Projector augmented-wave method. Phys. Rev. B 50, 17953-17979 (1994). 

60.   Monkhorst, H. J. & Pack, J. D. Special points for Brillouin-zone integrations. Phys. Rev. B 13, 51885192 (1976). 

61.   Grimme, S., Antony, J., Ehrlich, S. & Krieg, H. A consistent and accurate ab initio parametrization of density functional dispersion correction (DFT-D) for the 94 elements H-Pu. J. Chem. Phys. 132, 154104 (2010). 

62.   Xu, H. et al. Quantum capacitance limited vertical scaling of graphene �eld-effect transistor. ACS Nano 5, 2340-2347 (2011). 

Page 16/21 

63.   H. Yoshioka et al. Effects of interface state density on 4H-SiC n-channel �eld-effect mobility. Appl. Phys. Lett. 104, 083516 (2014). 



a, Schematic illustration of the hybrid HfO2/Sb2O3dielectrics integrated on 2D MoS2. b, AFM images of the as-exfoliated MoS2, after 1 nm Sb2O3deposition and after 2 nm HfO2 deposition. Scale bar, 1 μm. c,Height histograms for the surface of samples in b, acquired from the indicated areas. d, Bright-�eld (BF) cross-sectional STEM image of HfO2/Sb2O3 on MoS2. Scale bars, 10 nm. The thickness of the HfO2 and Sb2O3 layers are marked. e, STEM-EDS elemental maps of Hf, Sb and Mo respectively, acquired from the indicated area in d. Scale bar, 5 nm. f, EELS spectrum of Sb2O3 acquired from the interface of the stacking layers. 

Page 17/21 



The formation mechanisms of Sb2O3 and HfO2 layers on 2D materials. a, The schematic illustration of the deposition of Sb2O3molecules on MoS2, which is a snapshot in our MD simulations. b,The steady state that a thin layer of Sb2O3 is deposited on 2D MoS2. The Sb2O3 molecules homogeneously spread on MoS2 with a vdW gap. c, The average vdW distances of Sb2O3-MoS2 and MoS2-MoS2extracted from b for a lasting period of simulation time. The Sb2O3-MoS2gap is comparable to that of MoS2-MoS2 at the steady state, indicating their vdW interaction at the interface. d, e, represent the H2O adsorption con�gurations respectively on the surface of MoS2 and Sb2O3. which are optimized to their steady states in �rst-principles calculations. f, the typical adsorption energy, and interatomic distances for the optimized adsorption con�gurations of H2O molecules on Sb2O3 and MoS2. The typical hydrogen bond length in water is marked as the dashed line. 

Page 18/21 



Low ~~-p~~ ower FETs and logic gates with our hybrid dielectric layer as gate dielectrics. a, Schematic illustration of the FET structure with the hybrid Sb2O3/HfO2 layer as the gate dielectrics. b, Transfer characteristics curves of monolayer MoS2FETs with dielectric thickness td of 3 nm (red) and 5 nm (cyan). c, Statistical distribution of SS measured from 12 FETs based on exfoliated 2D MoS2. d, Optical micrograph of FET arrays based on monolayer MoS2grown via CVD. Scale bars are 100 μm and 10 μm respectively. e, f, Transfer characteristics curves of 14 CVD MoS2 FETs and their statistics of SS and on/off ratio. g, Photograph of different logic gates and corresponding equivalent circuit diagrams. Scale bar, 100 μm. h, Normalized output characteristics of NAND and NOR gates for different input states [(0,0), 

Page 19/21 

(0,1), (1,0), and (1,1)] as a function of time at a low supply voltage of Vdd=0.5 V. i, Normalized output voltage and voltage gain of an inverter as a function of input voltage with Vdd=0.5 V. 



dielectrics. a, The schematic �gure of the FETs with shorter channel lengths and global back gates. b, The transfer characteristics curves of back-gated FETs with different gate dielectric thickness td of 3 nm and 5 nm. Inset, SEM images of the short channel FETs, with channel length of 70 nm and 80 nm. c, output curves of the back-gated FETs with td of 5 nm. d,The EOT and SS of our MoS2-based FETs with hybrid Sb2O3/HfO2gate dielectrics in comparison with the state-of-the-art 2D FETs integrated with high-κ dielectrics via various approaches7,12,14,15,17,19,20,26,28,29,31,32,39,40. e, The operating voltages and on/off ratios of our FETs benchmarking the state-of-the-art 2D FETs and the Si MOSFETs released in IRDS7,9,12,13,15,17,19-21,26,28,29,31,32,39-42. 

Page 20/21 

This is a list of supplementary �les associated with this preprint. Click to download. 

NMManuscriptHybridDielecSI.docx 

MovieSb2O3depositiononMoS2.avi 

Page 21/21 

