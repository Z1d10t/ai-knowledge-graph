# Ion-induced field screening as a dominant factor in perovskite solar cell operational stability

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Energy |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 262 |
| 作者 | J. Thiesbrummel, Sahil Shah, Emilio Gutiérrez-Partida, Feng-Shuo Zu, F. Peña-Camargo, Stefan Zeiske, Jonas Diekmann, Fangyuan Ye et al. |
| DOI | 10.1038/s41560-024-01487-w |
| 源文件 | 077_Thiesbrummel_2024_Ion-induced-field-screening-as-a-dominant-factor.pdf |

---
## **nature energy** 

**Article** 

https://doi.org/10.1038/s41560-024-01487-w 

# **Ion-induced field screening as a dominant factor in perovskite solar cell operational stability** 

|Received: 19 January 2023|**Jarla Thiesbrummel**<br> <sup>**1,2,12**</sup>**, Sahil Shah**<sup>**1,12**</sup>**, Emilio Gutierrez-Partida**<sup>**1**</sup>**,**|
|---|---|
|Accepted: 28 February 2024|**Fengshuo Zu**<sup>**3**</sup>**, Francisco Peña-Camargo**<sup>**1**</sup>**, Stefan Zeiske**<sup>**4**</sup>**, Jonas Diekmann**<br> <sup>**1**</sup>**,**<br>**Fangyuan Ye**<sup>**1,5,6**</sup>**, Karol P. Peters**<sup>**1**</sup>**, Kai O. Brinkmann**<br> <sup>**7**</sup>**, Pietro Caprioglio**<br> <sup>**2**</sup>**,**|
|Published online: 28 March 2024<br>Check for updates|**Akash Dasgupta**<br> <sup>**2**</sup>**, Seongrok Seo**<sup>**2**</sup>**, Fatai A. Adeleye**<br> <sup>**1**</sup>**, Jonathan Warby**<sup>**1**</sup>**,**<br>**Quentin Jeangros**<br> <sup>**8**</sup>**, Felix Lang**<br> <sup>**1**</sup>**, Shuo Zhang**<sup>**5**</sup>**, Steve Albrecht**<sup>**6**</sup>**,**<br>**Thomas Riedl**<br> <sup>**7**</sup>**, Ardalan Armin**<br> <sup>**4**</sup>**, Dieter Neher**<br> <sup>**1**</sup>**, Norbert Koch**<br> <sup>**3,9**</sup>**,**|
||**Yongzhen Wu**<br> <sup>**5**</sup>**, Vincent M. Le Corre**<br> <sup>**10**</sup>**, Henry Snaith**<br> <sup>**2**</sup>**&**<br>**Martin Stolterfoht**<br> <sup>**1,11**</sup>|



The presence of mobile ions in metal halide perovskites has been shown to adversely affect the intrinsic stability of perovskite solar cells (PSCs). However, the actual contribution of mobile ions to the total degradation loss compared with other factors such as trap-assisted recombination remains poorly understood. Here we reveal that mobile ion-induced internal field screening is the dominant factor in the degradation of PSCs under operational conditions. The increased field screening leads to a decrease in the steady-state efficiency, often owing to a large reduction in the current density. Instead, the efficiency at high scan speeds (>1,000 V s<sup>−1</sup> ), where the ions are immobilized, is much less affected. We also show that the bulk and interface quality do not degrade upon ageing, yet the open-circuit voltage decreases owing to an increase in the mobile ion density. This work reveals the importance of ionic losses for intrinsic PSC degradation before chemical or extrinsic mechanical effects manifest. 

Despite the impressive progress in terms of photovoltaic performance of perovskite solar cells over the last decade, there still remain many issues regarding the stability, which has considerable implications for their real-world energy yield<sup>1–3</sup> . These challenges include material decomposition under light<sup>4,5</sup> , heat<sup>6,7</sup> , oxygen<sup>8,9</sup> and humidity<sup>10,11</sup> 

or mechanical concerns such as delamination<sup>12</sup> and strain<sup>13,14</sup> . Generally, increased trap-assisted recombination is also considered to be a major reason for degradation<sup>15–18</sup> . Efforts to improve device stability include compositional engineering<sup>19–22</sup> , device engineering<sup>23–25</sup> , the incorporation of two-dimensional perovskites<sup>26,27</sup> , diffusion barriers<sup>28–31</sup> 

> 1Physik und Optoelektronik weicher Materie, Institut für Physik und Astronomie, Universität Potsdam, Potsdam, Germany. 2Clarendon Laboratory, University of Oxford, Oxford, UK.<sup>3</sup> Institut für Physik and IRIS Adlershof, Humboldt-Universität zu Berlin, Berlin, Germany.<sup>4</sup> Department of Physics, Swansea University, Swansea, UK.<sup>5</sup> Institute of Fine Chemicals, East China University of Science and Technology, Shanghai, China.<sup>6</sup> Young Investigator Group Perovskite Tandem Solar Cells, Helmholtz-Zentrum Berlin für Materialien und Energie GmbH, Berlin, Germany.<sup>7</sup> Institute of Electronic Devices and Wuppertal Center for Smart Materials and Systems, University of Wuppertal, Wuppertal, Germany.<sup>8</sup> Centre Suisse d′Électronique et de Microtechnique, Neuchâtel, Switzerland.<sup>9</sup> Helmholtz-Zentrum Berlin für Materialien und Energie GmbH, Berlin, Germany.<sup>10</sup> Institute of Materials for Electronics and Energy Technology, Friedrich-Alexander-Universität Erlangen-Nürnberg, Erlangen, Germany.<sup>11</sup> Electronic Engineering Department, The Chinese University of Hong Kong, Hong Kong SAR, China.<sup>12</sup> These authors contributed equally: Jarla Thiesbrummel, Sahil Shah. e-mail: mstolterfoht@ee.cuhk.edu.hk 

Nature Energy | Volume 9 | June 2024 | 664–676 

**664** 

**Article** 

https://doi.org/10.1038/s41560-024-01487-w 

and more effective encapsulation methods<sup>32</sup> . However, the reported stability remains far below the targeted values required for commercial viability<sup>33</sup> (International Electrotechnical Commission standards and ~25 year operational lifetime), highlighting the need for a more comprehensive understanding of the underlying chemical and physical processes occurring during device ageing and their effects on device performance. 

Many of the intrinsic stability limitations are related to the presence of mobile ions in the perovskite layer, which behaves like a solid electrolyte with low activation energies for ionic transport<sup>34</sup> . For methylammonium lead iodide (MAPI), density functional theory simulations have predicted a mobile ion density ( _n_ ION) of ~1 × 10<sup>19</sup> cm<sup>−3</sup> due to the low activation energy of the mobile ions (~100 meV)<sup>35</sup> , although most recent experimental/numerical studies narrow the mobile ions density to 1 × 10<sup>15</sup> to 1 × 10<sup>17</sup> cm<sup>−3</sup> in devices with low levels of hysteresis<sup>36–40</sup> . Halide vacancies and interstitial iodine are usually considered to be the dominant species of mobile ions, and they are particularly harmful since they can form I2—a solid that easily sublimes above room temperature, leading to a loss of absorber layer material, potentially causing electrode cracks and critical device failure<sup>41</sup> . The migration and accumulation of halide defects due to lateral variation in the electric field also trigger degradation at the edges of cells and at the position of external impurities<sup>42</sup> . Moreover, A- and X-site mobile ions and vacancies are able to diffuse into the transport layers (TLs), with halide ions being localized in the device electrodes<sup>29,41,43–46</sup> . This effect may cause a range of problems, for example, loss of charge selectivity owing to a change in the electrode work function, oxidation reactions, corrosion or the formation of insulating layers. As such there is substantial research into ion migration in perovskites<sup>47–50</sup> . 

Although tackling stability has always been a main priority for perovskite researchers, the community still lacks to some extent the experimental methodologies required to quantitatively characterize degradation losses induced by mobile ions to overcome these limitations. Moreover, it is not yet possible to decouple these losses from losses due to trap-assisted recombination and deterioration of other device and material parameters. In this regard, we recently presented a method to determine the contribution of mobile ion-induced efficiency losses to the device performance and showed that the presence of mobile ions leads to moderate efficiency losses in fresh devices with low levels of apparent hysteresis (typically 1–3% absolute)<sup>51</sup> . The underlying mechanism of these ion-induced losses is the movement of mobile ions to the perovskite–transport layer interfaces, leading to field screening and a reduction in charge extraction efficiency<sup>38,52–57</sup> . 

In this Article, we determine the contribution of mobile ioninduced degradation losses to the total degradation loss in the presence of external stressors for a range of different perovskite solar cells. Using current density vs. voltage ( _J–V_ ) measurements at different scan speeds, we first demonstrate that these losses can be directly linked to the movement of mobile ions and an increase in _n_ ION, which dominates the initial performance losses of perovskite solar cells. We show that an increased _n_ ION upon prolonged illumination leads to a substantial decrease in the steady-state power conversion efficiency (PCE), mainly owing to a large reduction in short-circuit current density ( _J_ SC) from fast to slow scan speeds that can exceed 10 mA cm<sup>−2</sup> . We attribute this result to increased field screening—a phenomenon that, to the best of our knowledge, has not been previously discussed in relation to the degradation of perovskite solar cells. We also show that interfacial recombination does not increase upon ageing, yet there is an increasing mismatch between open-circuit voltage ( _V_ OC) and the quasi-Fermi level splitting (QFLS), which can also be attributed to an increased accumulation of ions in the contact regions. As such, the increasing _n_ ION dominates the early ageing stages of perovskite solar cells. This work establishes key insights into the process of device degradation and the critical role mobile ions play therein and lays the foundation for 



<!-- Start of picture text -->
a 0 min b<br>90 min<br>0 265 min 1.0<br>480 min<br>0.8<br>–10<br>0.6 V OC<br>J SC<br>–20 FF<br>PCE<br>0.4<br>0 0.5 1.0 0 200 400 600<br>Voltage (V) Time (min)<br>−2) (mA cm J<br>Relative losses (%)<br><!-- End of picture text -->

**Fig. 1 | Degradation of perovskite solar cells under illumination. a** , Representative stabilized _J–V_ characteristics at slow scan speeds (10 mV s<sup>−1</sup> ) measured on a fresh Cs0.05(FA0.83MA0.17)0.95Pb(I0.83Br0.17)3 perovskite solar cell as well as after continuous illumination at _V_ OC for the specified time. **b** , Relative steady-state losses of the different PCE parameters as a function of ageing time. 

accelerated ageing tests to predict the long-term stability of perovskite devices on the basis of a quantitative analysis of ion-induced losses. 

### **Ionic losses during degradation** 

To study the effects of illumination-induced degradation in perovskite solar cells, we started off investigating the commonly used triple-cation Cs0.05(FA0.83MA0.17)0.95Pb(I0.83Br0.17)3 1.63 eV perovskite composition in a _pin_ -type architecture (referred to as ‘83:17 TC’ throughout). The following cell architecture was used: indium tin oxide (ITO)/PTAA/PFN-Br/ perovskite/C60/BCP/Cu, that is, indium tin oxide/poly[bis(4-phenyl) (2,4,6-trimethylphenyl)amine]/poly((9,9-bis(3′-( _N_ , _N_ -dimethyl)- _N_ -ethylammonium-propyl)-2,7-fluorene)- _alt_ -2,7-(9,9-dioctylfluorene)) dibromide/perovskite/C60/bathocuproine/Cu<sup>58</sup> . The cells were subjected to three different external stressors: light, heat and electrical bias, with a focus on light-induced degradation. During the light-induced ageing, devices were exposed to 1 sun illumination at _V_ OC and cooled such that the device temperature remained at 25 °C. Measurements under maximum power point conditions (MPP) are discussed further below. In Fig. 1a, the stabilized _J–V_ curves (without hysteresis) at slow scan speeds (10 mV s<sup>−1</sup> ) after different illumination times under _V_ OC are exemplified. Figure 1b shows how the different device parameters change over time with ageing. In these cells, the increasing _J_ SC losses over time dominate the degradation losses although fill factor (FF) losses are also significant, and the _V_ OC decreases slightly as well. 

To quantify the impact of mobile ions on the light-induced performance degradation, we performed fast hysteresis (FH) _J–V_ measurements at different points in time during the ageing process. While details are presented in Methods and in ref. 51, we note that the cell is initially held slightly above the initial _V_ OC (pre-bias), followed by a reverse and forward sweep with variable frequency or scan speed. The duration of the pre-bias was 5× longer than the total scan time of the voltage sweep. The methodology allows us to determine the steady-state and the ‘ion-freeze’ efficiency, which refers to the condition at which the ions are effectively immobilized when the scan rate is much quicker than the diffusion rate<sup>51</sup> . The difference between slow (steady-state) and fast scan speeds can be directly attributed to the movement of mobile ions and is referred to as mobile ion-induced PCE loss ( _L_ ion = _η_ ion-freeze − _η_ steady-state) in the following<sup>51</sup> . 

However, it should be noted that the presence of mobile ions can still affect the PCE even when they are immobilized, depending on their distribution and accumulation throughout the device and at the interfaces<sup>51,56</sup> . This effect will be small if the ions are homogeneously distributed in the bulk at the start of the scan, which is discussed further below. The results (Fig. 2a) reveal once again that the steady-state efficiency drops significantly with ageing. Conversely, the ion-freeze efficiency, determined at fast scan speeds of around 2,500 V s<sup>−1</sup> , experiences a much smaller, almost negligible reduction. Next, we investigated the effects on each of the three _J–V_ metrics: the _V_ OC, _J_ SC and FF, displayed 

Nature Energy | Volume 9 | June 2024 | 664–676 

**665** 

**Article** 

https://doi.org/10.1038/s41560-024-01487-w 



<!-- Start of picture text -->
a 24 b e<br>24<br>20 Fast loss<br>20<br>21<br>Ionic<br>16 J SC 16 Ionic loss<br>hysteresisPeak Ionicloss 18 loss<br>12<br>15 Ageing time 12 PCE at fast speed<br>8  Reverse 0 min 90 min PCE at slow speed<br> Forward 280 min  480 min<br>12<br>0.1 1 10 100 1,000 0.1 1 10 100 1,000 0 100 200 300 400 500<br>Scan rate (V s –1 ) Scan rate (V s –1 ) Time (min)<br>c 1.20 d 80 f 10 Scan rate (V s−1)<br> 0.125<br> 0.25<br> 1.25<br>1.15 70  2.5<br>0  12.5<br> 25<br> 125<br>60  250<br>1.10  1,250<br>–10  2,500<br>50<br>1.05<br>40 –20<br>1.00<br>0.1 1 10 100 1,000 0.1 1 10 100 1,000 0 1<br>Scan rate (V s –1 ) Scan rate (V s –1 ) Voltage (V)<br>Steady state Ion freeze<br>PCE (%) PCE (%)<br>−2) (mA cm J SC<br> (V) V OC FF (%)<br>–2) (mA cm J<br><!-- End of picture text -->

**Fig. 2 | Identifying ageing-induced ionic losses in triple-cation-based perovskite solar cells. a** – **d** , The PCE ( **a** ), _J_ SC ( **b** ), _V_ OC ( **c** ) and FF ( **d** ) obtained from _J–V_ characteristics measured at different scan speeds in reverse (squares) and forward (circles) scan direction for Cs0.05(FA0.83MA0.17)0.95Pb(I0.83Br0.17)3 perovskite solar cells after different ageing times. **e** , The absolute PCE at fast and slow timescales versus aging time. The coloured areas underneath the curves demonstrate large losses induced by the movement of mobile ions at slow scan speeds (blue curve) and small losses at fast scan speeds (red curve). **f** , Exemplified scan rate-dependent _J–V_ curves after 480 min of ageing. The steady-state and 

ion-freeze PCE are defined at slow and fast scan speeds at which the hysteresis disappears, respectively. This is exemplified by the dashed horizontal lines at 480 min of ageing for the PCE and _J_ SC in **a** and **b** , respectively. The transition from slow and fast scan speeds is highlighted by the shaded background in **a** . The peak hysteresis shows the maximum difference between the forward and reverse scan PCE as exemplified by the vertical arrow at 480 min of ageing. The ionic loss in PCE and _J_ SC is obtained from the difference in the steady-state and ion-freeze state as shown by the vertical arrows in **a** , **b** and the shading in **b** . 

in Fig. 2b–d. It can be seen that the performance losses are largely related to a drastic loss of the steady-state current output with respect to the ion-freeze _J_ SC (even >10 mA cm<sup>−2</sup> current loss can be observed in other systems as discussed below). However, the _V_ OC and the FF are also affected to some extent. Furthermore, the ‘peak hysteresis’, that is, the maximum difference between the PCE determined from the forward versus the reverse scan, also increases significantly with ageing (Fig. 2a). Overall, the remarkable difference in the PCE between the fast and slow scan speeds (Fig. 2e,f) shows that the dominant loss mechanism upon ageing acts more significantly at the slower timescales. 

To get some understanding of the chemical changes of the perovskite film during light exposure, we performed absorption spectroscopy (Supplementary Fig. 1), X-ray diffraction measurements on fresh and aged perovskite layers (Supplementary Fig. 2), scanning electronic microscopy and atomic force microscopy measurements (Supplementary Fig. 3). While these measurements do not rule out changes in the morphology, these changes are considered to be relatively small on the timescale of the measurements (up to 24 h of illumination). 

To generalize these findings, we then investigated the mobile ion-induced ageing loss in a range of different perovskite compositions beyond the ‘83:17’ model system. These perovskite systems include a standard 1.6 eV MAPbI3 (‘MAPI’), a 1.69 eV double cation perovskite FA0.85Cs15Pb(I77Br23)3 (‘CsFA’) relevant for silicon/perovskite tandems, a wide-bandgap Cs0.05(FA0.60MA0.40)0.95Pb(I0.60Br0.40)3 (‘1.8 eV’) relevant for all-perovskite tandems and a high-performance (>22% PCE) 1.57 eV formamidinium lead iodide-rich (‘95:5 TH‘) triple halide perovskite 

(Cs0.05(FA0.95MA0.05)0.95Pb(I0.95Br0.05)3 + 20 wt% methylammonium chloride (MACl)). The FH results on all systems are shown in Supplementary Figs. 4–7. MPP tracking of all devices can be found in Supplementary Fig. 8. We also investigated _nip_ -type cells (Supplementary Fig. 9), where we observed the same losses. These results demonstrate that the increase of the ionic loss contributes significantly to the degradation loss for all systems (Fig. 3a). Moreover, we find that the reduced _J_ SC is the most important factor contributing to the ion-induced loss in these systems (Supplementary Figs. 10 and 11). However, the ionic loss may also predominately affect other PCE parameters depending on the exact material/device parameters. Moreover, some of the systems are probably affected by non-ionic losses, which likely affect the FF at fast scan speeds as discussed in Supplementary Note 1. Figure 3b exemplifies the large reduction of the steady-state _J_ SC after several hours of illumination (5 h, except for 12 h in MAPI) with respect to the initial current. 

Importantly, Fig. 4a shows that the ionic losses also emerge in the much more stable 95:5 TH perovskite system, which degraded to roughly 68% of its initial PCE (21%) after tracking the stabilized power output (SPO) over 1,630 h. Notably, the PCE increased to 23.5% after roughly 50 h. The FH measurements taken initially and after the MPP tracking (Fig. 4b) reveal a nearly unchanged ion-freeze PCE, meaning that the observed degradation loss (here defined as 

_L_ total = _η_<sup>0</sup> ion-freeze<sup>−</sup><sup>_ηf_</sup> steady-state<sup>, where</sup><sup>_η_</sup> ion<sup>0</sup> -freeze<sup>and</sup><sup>_ηf_</sup> steady-state<sup>are the</sup> initial ion-freeze and the final steady-state PCE, respectively) can be 

Nature Energy | Volume 9 | June 2024 | 664–676 

**666** 

**Article** 

https://doi.org/10.1038/s41560-024-01487-w 



<!-- Start of picture text -->
a Composition b Composition<br> 95:5 TH 25  95:5 TH<br> MAPI  MAPI<br>60  CsFA  CsFA<br> 1.8 eV  1.8 eV<br>20<br> 83:17 TC<br>40  Fresh<br>15  Degraded<br>20<br>10<br>0 5<br>0 100 200 300 400 500 600 0.1 1 10 100 1,000<br>Time (min) Scan rate (V s –1 )<br>–2) (mA cm J<br>Relative ionic loss (%)<br><!-- End of picture text -->

**Fig. 3 | Overview of ageing-induced ionic losses in various perovskite solar cells. a** , The relative ageing-induced ionic loss (1 − PCEslow/PCEfast) as a function of ageing time under 1 sun open-circuit conditions demonstrates increasing ionic losses in all systems, though with varying magnitude depending on the individual composition. The highest ageing-induced ionic losses are found in the Cs0.05 (FA0.60MA0.40)0.95Pb(I0.60Br0.40)3 (‘1.8 eV’) cell, followed by FA0.85Cs0.15Pb(I0.77Br0.23)3 

(‘CsFA’), and 83:17 TC with the smallest losses found in MAPbI3 (‘MAPI’) and the Cs0.05(FA0.95MA0.05)0.95Pb(I0.95Br0.05)3 + 20 wt% MACl (‘95:5 TH’) cell, where the ioninduced ageing losses do not increase on these timescales. **b** , The _J_ SC measured at different scan speeds for fresh and aged cells after 5 h of ageing under 1 sun open-circuit conditions (12 h for MAPI) with additional PCE parameters shown in Supplementary Fig. 4–7. 

attributed to ionic losses (that is, _L_ ion/ _L_ total = 100%). Using a specific interlayer between the perovskite and C60 (described in a separate work), we then improved the initial _V_ OC to 1.2 V and the performance of this device to a certified PCE of 24% and measured the ionic losses at the beginning and the end of the tracking (Supplementary Fig. 12). The device experienced a critical device failure due to electrode oxidation (thinning of the electrode owing to insufficient encapsulation visible by the eye) before we conducted the FH measurement at roughly 1,000 h. Nevertheless, the ionic losses still increase substantially during aging: _L_ ion/ _L_ total = 37.4%. 

In an attempt to generalize the findings further, we performed additional measurements on a high-performance _pin_ -type Cs0.05 (FA0.98MA0.02)0.95Pb(I0.98Br0.02)3 cell (‘98:2 TH’) fabricated in our laboratory, as well as Cs0.05(FA0.95MA0.05)0.95Pb(I0.95Br0.05)3 cells made at the East China University of Science and Technology (‘95:5 ECUST’)<sup>59</sup> . The results, highlighted in Fig. 4c,d and in Supplementary Fig. 13 for the 98:2 TH and the 95:5 ECUST device, respectively, demonstrate dominant ionic losses in both cells, that is, _L_ ion/ _L_ total = 73.1% and 81.3% after tracking the SPO of the 98:2 TH cell for 270 h and the MPP of the 95:5 ECUST cell for 1,000 h, respectively. The remaining FH data corresponding to Fig. 4 can be found in Supplementary Fig. 14. Overall, these results confirm that the same losses also occur in more stable cells during MPP or SPO tracking, and in cells fabricated in other laboratories. The results indicate that the ionic losses are even more critical in stable cells, which do not undergo premature degradation due to extrinsic issues such as shunt formation, moisture ingress or electrode corrosion, which can cause earlier device failure. 

### **Understanding reasons for ionic losses** 

Having established that the ionic losses play a key role for the intrinsic device degradation, we now set out to understand the origin of these losses. At this point, it is important to note that the increase of the ionic loss with ageing time could be due to different factors<sup>51</sup> . This is because the magnitude of the ionic loss depends on various device and material parameters for a given ion density. To identify the underlying mechanisms, we now discuss, simulate and analyse distinct scenarios. For the simulations, we used the software IonMonger<sup>60</sup> and cross-checked using the software SETFOS from FLUXiM<sup>61</sup> . In our first hypothesis, the concentration of mobile ions increases with ageing, which leads to enhanced ionic losses as shown by the simulations in Fig. 5a (see Supplementary Fig. 15, Supplementary Fig. 16 and Supplementary Table 1 for the _J–V_ characteristics, the corresponding PCE parameters and the simulation parameters, respectively). Here, the increased _n_ ION causes enhanced screening of the internal electric field in the absorber layer, leading to a continuous 

reduction in the charge extraction efficiency due to band flattening (Supplementary Fig. 17). 

Another possible explanation for the enhanced ionic losses is degrading perovskite/transport layer interfaces with higher recombination velocities ( _S_ ). As shown in Fig. 5b, the increased recombination velocity leads to a reduced steady-state PCE and increased peak hysteresis. However, in contrast to the case of an increased _n_ ION (Fig. 4a), the ion-freeze PCE at fast scan speeds decreases as well. In addition, we also investigated the impact of an increased energy level offset, as well as the impact of more bulk defects lowering the bulk lifetime (Supplementary Fig. 18). We found that both effects (increased energy offset and reduced bulk lifetime) lead to a parallel downshift of the scan rate-dependent PCE rather than an increase in the ionic losses, which is not consistent with the experimental results. 

To further investigate the impact of potentially worsening interfaces or absorber layer quality on the enhanced ionic losses, photoluminescence (PL) measurements of different partial cell stacks were recorded as a function of illumination time. From the PL yield, the quasi-Fermi level splitting (QFLS) was calculated following our previous methodology<sup>58,62</sup> . Surprisingly, the results (Fig. 5c) suggest that the interfaces do not significantly worsen as the QFLS of all the partial device stacks increases slightly over time, while the QFLS of the neat perovskite layer was nearly unchanged. This suggests that increased bulk and interfacial defects are probably not a dominant factor of the light-induced degradation in this cell. Yet, the device _V_ OC decreases, resulting in an increasing QFLS–eVOC mismatch upon ageing<sup>62</sup> , which is intriguing. Although this requires further investigation, the QFLS–VOC mismatch provides clues about the effect of ions at fast scan speeds. The FH simulations displayed in Supplementary Fig. 19 shows that, if the built-in voltage ( _V_ BI) is not offset with the pre-bias of the FH measurement (that is, _V_ pre < _V_ BI), the _V_ OC decreases with increasing _n_ ION. Considering that such a _V_ OC decrease (and QFLS–eVOC mismatch) is observed in various systems (Supplementary Figs. 4–7) points to ion accumulation in an unfavourable position under open-circuit conditions (for example, cations at the hole-selective interface)<sup>56,62</sup> . 

Having ruled out an increased recombination velocity at the interfaces, an increased mobile ion density seems likely to be the root cause of the observed ageing-induced losses. To directly assess whether _n_ ION increases with degradation, we performed bias-assisted charge extraction (BACE)<sup>63,64</sup> and charge extraction by linearly increasing voltage (CELIV) measurements at the same points in time as the FH measurements. Both techniques can be used to estimate the _n_ ION by integrating the external current. In BACE, the cell is held under ‘quasi’-open-circuit conditions, where the injection current equals the _J_ SC at which the mobile ions are distributed throughout the absorber layer before the 

Nature Energy | Volume 9 | June 2024 | 664–676 

**667** 

**Article** 

https://doi.org/10.1038/s41560-024-01487-w 



<!-- Start of picture text -->
a 95:5 TH<br>24<br>Ion freeze<br>20<br>Ionic loss<br>16 25 27<br>20 24<br>21<br>12 15  Fresh<br>18  Degraded<br>10 Ionic<br>loss 15  Reverse Forward<br>5<br>8 10–2 10–1 100 101 102 103 1210–2 10–1 100 101 102 103<br>Scan rate (V s–1) Scan rate (V s–1)<br>0 200 400 600 800 1,000 1,200 1,400 1,600<br>Time (h)<br>b 98:02 TH<br>25<br>Ion freeze<br>20<br>24 Ionic loss<br>15 24<br>20<br>16 21<br>Ionic  Fresh<br>10 12 loss 18  Degraded<br> Reverse<br>8  Forward<br>4 15<br>5 10–1 100 101 102 103 10–1 100 101 102 103<br>Scan rate (V s–1) Scan rate (V s–1)<br>0 50 100 150 200 250<br>Time (h)<br>–2)<br>PCE (%)<br>PCE (%)  (mA cm Jsc<br>−2)<br>PCE (%)<br>PCE (%)  (mA cm Jsc<br><!-- End of picture text -->

**Fig. 4 | Ionic losses under operational conditions. a** , SPO tracking on the 95:5 TH device with enhanced stability compared with the 83:17 TC reference cell. Inset: The corresponding PCE and _J_ SC from FH measurements at different scan speeds before and after the aging. **b** , SPO tracking on the 98:2 TH device and corresponding PCE and _J_ SC at different scan speeds before and after the aging in the inset. The measurements demonstrate that the observed degradation stems largely from ionic losses while the ion-freeze PCE remains nearly unchanged. The dashed line is a guide to the eye, connecting the experimentally measured 

initial and final ion-freeze PCE (stars), while the gradient shading highlights the expected emergence of the ionic losses. The steady-state and ion-freeze PCE are marked by the diamonds and stars, respectively. The red arrows highlight the ionic losses after the degradation. The latter are determined from the difference between the steady-state and ion-freeze PCE, as exemplified by the yellow horizontal lines in the insets. The experimental conditions for the SPO and FH measurements can be found in Methods and all the remaining FH data in Supplementary Fig. 14. 

voltage is switched to 0 V, at which point the mobile ions drift to the contact layers. However, we note that, if the ionic charge is larger than the electrode charge ( _Q_ ION > _CV_ BI), the formation of zero-field regions should limit the displacement of ions in excess of _CV_ BI (ref. 65). Thus, _CV_ BI is expected to be a natural limit for the externally detectable ionic charge. Moreover, the ratio of the drift length of charges versus the film thickness ( _d_ drift/ _d_ ) limits the externally integrated charge<sup>65</sup> . Therefore, the ions should be roughly homogeneously distributed under the pre-bias condition to maximize the drift length and to avoid an underestimation of _n_ ION (ref. 66). 

The results of the BACE measurements are displayed in Fig. 6a. It can be seen that the externally measured current is greatly enhanced the longer the illumination. Notably, the ionic ‘time of flight’ in the fresh device at around 50 ms (Supplementary Fig. 20) matches nearly perfectly the scan time at the peak hysteresis observed in averaged FH on fresh devices (~50 ms). Owing to the associated diffusion constant ( _D_ = 7 × 10<sup>−10</sup> cm s<sup>−1</sup> ) and ionic mobility ( _μ_ = 2 × 10<sup>−8</sup> cm<sup>2</sup> V s<sup>−1</sup> ), these results indicate that the responsible ion species are consistent with halide vacancies<sup>40,48</sup> . Therefore, these measurements link the transient charge extraction with the scan rate-dependent _J–V_ results. It is also interesting to note that, with prolonged ageing time, slower species are extracted. This is also consistent with a slowdown of the peak 

hysteresis that is observed in the FH measurements in Fig. 2a for the 83:17 TC and in Supplementary Fig. 6 for the 60:40 TC system. Considering that this is not observed in CsFA (Supplementary Fig. 5) might point to A-site vacancies<sup>40,48</sup> . Another possible explanation is that grain boundary diffusion is replaced by volume diffusion in less stable devices, which has recently been identified to have a two orders of magnitude lower ion diffusivity<sup>67</sup> . More details regarding the timescales observed in FH and BACE are discussed in Supplementary Note 2. 

As shown in Fig. 6b, by integrating the external current, a rough estimate for _n_ ION can be obtained. We note that we do not exclude some collection of ions from the side of the pixel as recently demonstrated, which could increase _n_ ION within the active device area<sup>42</sup> . It can be seen that _n_ ION increases significantly, even within the first hour of illumination, and reaches values over 10<sup>18</sup> cm<sup>−3</sup> after 20 h of ageing under light. Although the reason why such large densities can be obtained in BACE is not yet clear, considering the above-discussed limit of the detectable ion density, the obtained values make sense qualitatively. As shown in Fig. 4a, the simulations can well reproduce the observed losses at the given ion densities. To highlight the effect, an ion density of 5 × 10<sup>18</sup> cm<sup>−3</sup> approximately halves the initial steady-state PCE owing to enhanced ionic losses. By plotting the ionic losses obtained through FH as a function of _n_ ION in Fig. 6c, we observe a linear dependence after an initial 

Nature Energy | Volume 9 | June 2024 | 664–676 

**668** 

**Article** 

https://doi.org/10.1038/s41560-024-01487-w 



<!-- Start of picture text -->
a Changing ion density b Changing interface recombination velocity<br>S (cm s−1)<br>101<br>20 20 102<br>103<br>104<br>15 16 Higher  S 105<br>Reverse<br>12 Forward<br>10<br>Ionic<br>8 loss<br>Ion density (cm–3)<br>5 1015 1016 1017 1018<br>4<br>10−2 10−1 100 101 102 0.001 0.01 0.1 1 10 100 1,000<br>Scan rate (V s –1 ) Scan rate (V s –1 )<br>c QFLS from PL<br>Cu pero  HTL/pero<br>1.3 Glass Pero ITO HTLPero ETLPero Glass PeroITOETLPero HTL pero/ETL  cell eVOC Cell<br>1.2<br>QFLS–<br>e V OC<br>1.1 mismatch<br>0 165 285 495 1,215<br>Time (min)<br>PCE (%) PCE (%)<br> and QFLS (eV) eV OC<br><!-- End of picture text -->

**Fig. 5 | Simulation of ionic loss mechanisms and experimental bulk and interface recombination during ageing. a** , The simulated PCE at different scan speeds in reverse (solid lines) and forward scan (dashed lines) direction for a range of different mobile ion densities. We consider mobile halide vacancies in our simulations with counter-ions being immobilized; however, the observed trend does not depend on the sign of the dominant mobile ion species or if there are one or two mobile species. **b** , Simulated PCE from _J–V_ curves at different 

scan speeds in reverse (solid line) and forward scan (dashed line) direction for a range of different recombination velocities ( _S_ ) at both perovskite–transport layer interfaces. The arrow highlights the ionic loss. **c** , Device _V_ OC and the QFLS measured with PL on bare triple-cation films (‘pero’), and partial (‘HTL/pero’ and ‘Pero/C60’) and complete cell stacks (structures shown in the inset) as a function of illumination time. The arrow marks the QFLS– _eV_ OC difference in the cell. 

dwell time. Moreover, an increase of _n_ ION with increasing ageing time was also confirmed for the other studied systems (Supplementary Fig. 21). Also from CELIV, the increasing ion density during ageing is reflected in the large increase in the signal on slower timescales, starting at roughly 1 × 10<sup>−4</sup> s in the 83:17 TC cell (Supplementary Fig. 22)<sup>51</sup> . 

To investigate whether the devices would age similarly under real-world conditions and to better understand the dominant factor triggering the degradation, we expanded our measurements to other ageing conditions: elevated temperatures (75 °C) in the dark (Supplementary Fig. 23), MPP conditions at 1 sun illumination (Supplementary Fig. 24) and electrical bias ( _V_ OC) in the dark (Supplementary Fig. 25). From these results, it becomes clear that the ion-induced performance loss is a general degradation mechanism that occurs under different stressors. Nevertheless, the ageing at elevated temperatures does not show the characteristic step-function like scan rate-dependent _J_ SC (Supplementary Fig. 18) nor display a very large increase of _n_ ION on these timescales (Supplementary Fig. 26). This might point towards a different path of degradation or a slower evolution of the ionic losses. 

While determining the exact rates of degradation requires a much more focused investigation, our measurements indicate that mobile ions are easily created in the presence of electrical charges in the active layer regardless of the presence of light. This is consistent with the interpretation that halide vacancies are generated by injected or photo-generated free holes<sup>45,47</sup> . It has been previously shown that iodine atoms can be oxidized and iodine kicked out of the lattice by photo-generated holes, creating halide vacancies via I<sup>_x_</sup> I<sup>+ h+= I</sup><sup>_x_</sup> _i_<sup>+ V</sup> I<sup>+,</sup> 

where I, I and _x_ refer to the regular and the interstitial lattice site and to the neutral charge, respectively<sup>34,45,47</sup> . Another possible ion source is unreacted lead halide PbI2 (Supplementary Fig. 2), which can decompose into metallic lead and mobile iodine under illumination<sup>18</sup> . Both of these mechanisms are consistent with additional X-ray photoelectron spectroscopy measurements, which reveal the presence of iodine on top of the C60 layer after illuminating the triple-cation perovskite for approximately 10 h, demonstrating the possibility of iodine diffusion through fullerenes, in line with previous reports (Supplementary Fig. 27)<sup>29,68–70</sup> . Moreover, we could detect iodine in the perovskite film on a Si substrate that was placed ~1 mm above the sample (in N2) during illumination, hence highlighting the egress of volatile iodine species (Supplementary Fig. 28). 

To recap, the mobile ion-induced efficiency losses dominate the early degradation losses in the here tested perovskite compositions, and on the basis of various measurements, such as PL and BACE, we attribute these enhanced ionic losses to an increasing ion density upon ageing. Figure 7a shows a breakdown of the identified degradation losses under illumination for the 83:17 TC system: (1) the ionic loss in _J_ SC and FF, which is attributed to the field screening effect due to the movement of mobile ions, (2) the loss due to the QFLS– _V_ OC mismatch, which is probably also a mobile ion-induced loss and (3) other, as yet unspecified, loss processes. 

Figure 7b–d schematically illustrates a possible explanation for the observed _J_ SC and FF losses. The increased _n_ ION during the ageing successively screens the internal (built-in) field, thus increasing the 

Nature Energy | Volume 9 | June 2024 | 664–676 

**669** 

**Article** 

https://doi.org/10.1038/s41560-024-01487-w 



<!-- Start of picture text -->
a Ageing time 0 h b 10 19 c<br>10–7 1 h4 h8 h 1018 10 18 10<br>20 h<br>10–8 1017 1 Time (h)10<br>10–9<br>10–10 V V OC 1016 1<br>0 V<br>10–11 Time 1015<br>0.1 1 10 100 1,000 0.1 1 10 100 1,000 1016 1017 1018<br>Time (s) Time (s) Ion density (cm –3 )<br>–3)<br>Density (cm<br>−2) (mA cm J dark<br>Ionic PCE loss (%)<br>–3)Carrier density (cm<br><!-- End of picture text -->

**Fig. 6 | Correlating ageing-induced ionic losses with ion density. a** , **b** , Current transients from BACE measurements for both fresh and aged devices ( **a** ) and integrated charge carrier density from the transients in **a** ( **b** ). The applied voltage pulse to the device is illustrated in the inset in **a** . Considering that the capacitive (dis)charging effect after the voltage switch and the extraction of electronic charges takes place on the microsecond timescales, the contribution to the total 

extracted charge in these transients is expected to be nearly entirely given by mobile ions<sup>51</sup> . The inset in **b** shows the ion density as a function of time. **c** , The ionic loss obtained for a Cs0.05(FA0.83MA0.17)0.95Pb(I0.83Br0.17)3 triple-cation device as a function of the ion density reveals a linear dependence after an initial dwell ageing time. 

fraction of the active layer that is effectively under _V_ OC (or flat band) conditions. The formation of zero-field regions under short-circuit conditions leads to an increased accumulation of electronic charges (e<sup>−</sup> and h<sup>_+_</sup> ) at the hole-selective interface. This charge accumulation leads in turn to enhanced recombination at the hole transport layer (HTL) and in the bulk. We note that the reason why the _p_ -interface is more affected than the electron-selective interface is that we consider positively charged mobile ions (halide vacancies), which screen the field at the HTL. The dominance of mobile vacancies was confirmed by experiments performed by Senocrate et al.<sup>71</sup> , who measured the ionic conductivity in MAPI for various iodine partial pressures and found that incorporating more iodine decreases the ion conductivity by passivating mobile iodine vacancies. Similarly, Kamat et al. found that excess iodine suppresses mobile ion-related features in transient absorption spectroscopy<sup>72</sup> . Therefore, we suspect that halide vacancies are the problem. However, currently, we do not exclude negative ions as dominant ionic species, in which case, the electron-selective interface would be more significantly affected. Finally, while there might be some small bulk recombination losses at short-circuit conditions depending on the diffusion length in the absorber layer, the recombination at the interfaces increases more rapidly with the increasing cation vacancy concentration at 0 V (Fig. 6d). Moreover, the interfacial recombination current scales faster with the applied forward bias than the bulk losses, thus affecting the FF more significantly (Fig. 6d). 

To explain the observed QFLS– _V_ OC mismatch with increased ion densities, we analysed the band diagrams at _V_ OC conditions displayed in Supplementary Fig. 29 for devices with different ion densities. The graph shows that a higher cation vacancy concentration causes a larger electron QFL bending at the C60 interface (∇ _E_ f,e). This can be explained by a population inversion at the electron-selective interface, that is, enhanced hole accumulation and depletion of electrons (Supplementary Fig. 30), and ∇ _E_ f,e = _σσ_ he<sup>⋅∇</sup><sup>_E_f,h</sup> 73–75, where _σ_ h/e and ∇ _E_ f,h are the hole/ electron conductivity and the hole QFL bending, respectively). This suggests that mobile ions are probably also responsible for the observed QFLS– _V_ OC mismatch and the reduction of the _V_ OC. Therefore, parts of the losses at fast scan speeds are attributed to this ion accumulation. 

### **Implications for improving device stability** 

Having thoroughly studied the impact of mobile ions on device degradation, it is also important to consider how this knowledge can translate into more stable devices. We first tested the above hypothesis that the ionic losses are strongly affected by the quality of the HTL/perovskite interface. To this end, we improved the _p_ -interface by replacing the HTL PTAA with the self-assembled monolayer 

2PACz (Supplementary Fig. 31). This readily improved the PLQY of the half stack and significantly slowed the ion-induced degradation losses. This is consistent with the assumption that the _p_ -interface plays a major role in mediating the ion-induced losses. 

Secondly, owing to the large impact of ion migration on the stability, we believe that the ionic properties are strongly correlated to the stability of the devices and that initial assessment of the ionic properties will allow us to rapidly identify more stable compositions. To exemplify this, our data in this work highlight a clear correlation between the magnitude of the peak hysteresis—where the ion migration is most harmful to the cell performance—and the T80 lifetime at which the PCE drops to 80% (Supplementary Fig. 32). Although a correlation between stability and hysteresis has been often observed in literature<sup>67,76</sup> , we emphasize that the full peak of the hysteresis cannot be resolved with commonly used source measure units for cell characterization (with maximum scan speeds usually below ~1 V s<sup>−1</sup> ). Also depending on the effective ion diffusion coefficient in the used absorber, the peak hysteresis can shift by orders of magnitude in scan speed range. Thus, assessing the hysteresis at only one scan rate or a small scan speed range does not provide the true magnitude of the hysteresis and does not allow comparison of different perovskite devices with very different ion diffusion coefficients<sup>77</sup> . This is exemplified in Supplementary Fig. 32b, where it appears that the much more stable 95:5 TH device has a larger hysteresis compared with the 60:40 device at slow scan speeds typically used (100 mV s<sup>−1</sup> ). This underlines the importance of closing the hysteresis at slow and fast scan speeds to understand the impact of the hysteresis on the device’s performance and stability. Lastly, we believe that reporting these ionic properties will allow the community to train a more accurate machine learning algorithm that can accelerate the development of a more stable composition<sup>78–81</sup> . Overall, while the correlation of ionic properties and long-term stability requires a much larger data set, which is beyond the scope of this present work, we believe that future research will allow us to identify highly stable perovskites on the basis of the ionic features and properties of newly developed devices. 

### **Conclusion** 

In this work, we investigated the impact of mobile ions on the ageing-induced performance degradation of perovskite solar cells under different external stressors, with a focus on light-induced degradation, and thoroughly studied the mechanisms underlying the observed losses. We reveal a key degradation mechanism as a dominant factor for the intrinsic, early degradation that has previously not been clearly identified, namely mobile ion-induced field screening. This degradation loss appears to be more significant than increased trap-assisted recombination in the bulk and at the interfaces. 

Nature Energy | Volume 9 | June 2024 | 664–676 

**670** 

**Article** 

https://doi.org/10.1038/s41560-024-01487-w 



<!-- Start of picture text -->
a b<br>50<br>Total loss<br>Ionic  J SC + FF loss Ec Ion free<br>40 Ionic  J SC loss<br>–<br>30 R interface<br>– – - – – – R bulk +<br>20 Ec<br>+ + Ev<br>10 + + + + + +<br>+<br>++ + + + + + + + +<br>0<br>0 100 200 300 400 500 Ev<br>Time (min)<br>c HTL Active layer HTL d<br>Ion density (cm–3)<br>1018 10101816  10 101715<br>n ION = 1018 cm–3 10  Bulk<br> p -Interface<br>1015<br>1<br>1012 Electrons<br>n ION = 1015 cm–3 Holes 0.1<br>0 100 200 300 400 500 0 0.5 1.0<br>d  (nm) Voltage (V)<br>Ionic  J sc loss<br>Ionic FF loss<br>Additional losses (unspecified)QFLS– V OC loss<br>Degradation loss (%)<br>−2) (mA cm J<br>–3)Carrier density (cm<br><!-- End of picture text -->

**Fig. 7 | Degradation loss processes and reasons for ionic current losses. a** , A breakdown of the loss processes: mobile ion-induced _J_ SC and FF losses, mismatch of the QFLS and _V_ OC that we also attribute to accumulation of ions at the interfaces, and other losses. **b** , A schematic band diagram of the HTL (red)/ perovskite (purple)/ETL (blue) stacks at short-circuit conditions, highlighting the accumulation of cation vacancies at the HTL ( _p_ -)interface (red squares) that leads to enhanced hole (‘+’ circles) accumulation and electron (‘−’ circles) accumulation close to the HTL. The interfacial ( _R_ interface) and bulk recombination rate ( _R_ bulk) are indicated by the purple arrows. The inset in **b** reveals the ion-free 

case where the dashed black line shows the QFLS. Here, _E_ C and _E_ V refer to the conduction and valence band, respectively. **c** , The simulated hole (dashed red lines) and electron (solid blue lines) density across the cell stack for different ion densities from 1 × 10<sup>15</sup> cm<sup>−3</sup> to 1 × 10<sup>18</sup> cm<sup>−3</sup> in logarithmic steps from light to darker colours in the direction of the arrow. **d** , The recombination current at the _p_ -interface and in the bulk as a function of applied voltage for different ion densities. The graph highlights that interfacial (dot dashed lines) and bulk recombination (solid lines) increase with increasing ion density. However, the former is more significant, which is also indicated by the purple arrows in **b** . 

The ionic losses typically manifest as a strongly reduced _J_ SC, which often suffers most significantly under the illumination in the studied compositions, although the FF and _V_ OC are also affected by the mobile ions. With regard to the voltage losses, we found that they are caused by an increased QFLS– _V_ OC mismatch due to ion accumulation, and not due to increased interfacial or bulk defects. This QFLS– _V_ OC mismatch occurs in various systems and can be explained by an increased ion accumulation at the interfaces. Using different transient charge extraction techniques, we then linked the increasing current and FF losses upon ageing to an increase in the concentration of mobile ions in the perovskite. We showed that the increase of _n_ ION upon ageing is a general degradation mechanism, which occurs through exposure to other stressors, such as electrical bias. However, the ion-induced losses are more significant in the presence of free electrical charges and less under elevated temperatures, consistent with previous findings of halide vacancy generation through holes. 

In the future, perovskite solar cells need to be engineered to minimize both the mobile ion densities that can be generated during ageing as well as their impact on the device performance. Our results also highlight the key role of the hole-selective interface for the non-induced degradation in case of large halide vacancy concentrations. By providing a crucial understanding of the role of mobile ions 

during degradation, this work paves the path to rapidly identify stable perovskite compositions based on the initial ionic fingerprints and highlights potential mitigation routes to prevent degradation, which will be key for the commercialization of perovskite-based solar cells. 

### **Methods** 

#### **Device fabrication of** **_pin_ -type cells** 

Pre-patterned 2.5 × 2.5 cm<sup>2</sup> 15 Ω sq<sup>−1</sup> ITO substrates (Automatic Research) were cleaned with acetone, 3% Hellmanex solution, deionized water and isopropanol by sonication for 10 min in each solution. After a microwave plasma treatment (3 min, 200 W), the samples were transferred to a N2-filled glovebox. For tall _pin_ -type cells, except for the 95:5 TH and the 98:2 TH perovskite, a PTAA (Sigma-Aldrich) layer with a thickness of 8 nm was spin-coated from a 1.5 mg ml<sup>−1</sup> PTAA/toluene solution at 6,000 rpm for 30 s. After 10 min annealing on a hotplate at 100 °C, the films were cooled down to room temperature, and a 60 µl solution of PFN-Br (1-Material, 0.5 mg ml<sup>−1</sup> in methanol) was deposited onto PTAA while the substrate was being spun at 5,000 rpm for 20 s, resulting in a film with thickness below the detection limit of our atomic force microscopy (<5 nm). No further annealing occurred. For the 95:5 TH and the 98:2 TH perovskite, the same ITO-coated samples were used, but instead of the microwave plasma treatment, the substrates 

Nature Energy | Volume 9 | June 2024 | 664–676 

**671** 

**Article** 

https://doi.org/10.1038/s41560-024-01487-w 

were treated with ultraviolet ozone for 30 min. The samples were then transferred to a nitrogen-filled glovebox and 100 µl MeO-2PACz purchased from TCI (0.003 g per 3 ml in ethanol) was spin-coated onto the ITO substrates at 3,000 rpm for 30 s, followed by annealing at 100 °C for 10 min. All fabrication details of the 95:5 ECUST cells based on (2-(4-(bis(4-methoxyphenyl)amino)phenyl)-1-cyanovinyl)phosphonic acid (MPA-CPA) are described in ref. 59. 

The triple-cation perovskite solutions were prepared by mixing two 1.2 M FAPbI3 and MAPbBr3 perovskite solutions in dimethylformamide (DMF):dimethyl sulfoxide (DMSO) (4:1 volume ratio, v/v) in a ratio of 83:17 (for the 83:17 triple-cation reference cell) and 60:40 (for the 1.8 eV WG cell). The 1.2 M FAPbI3 solution was thereby prepared by dissolving FAI (722 mg) and PbI2 (2130 mg) in 2.8 ml DMF and 0.7 ml DMSO, which contains a 10 molar% excess of PbI2. The 1.2 M MAPbBr3 solution was made by dissolving MABr (470 mg) and PbBr2 (1,696 mg) in 2.8 ml DMF and 0.7 ml DMSO, which contains a 10 mol% excess of PbBr2. Lastly, 40 µL of a 1.5 CsI solution in DMSO (389 mg CsI in 1 ml DMSO) was mixed with 960 µL of the MAFA solution, resulting in a nominal perovskite stoichiometry of Cs0.05(FA0.83MA0.17)0.95Pb(I0.83Br0.17)3 in case of the 83:17 triple-cation reference cell and Cs0.05(FA0.6MA0.4)0.95Pb(I0.6Br0.4)3 in case of the 1.8 eV WG cell. The MAPI solution was prepared by dissolution of MAI powder (Dysol, 0.2) with PbI2 (TCI America, 1.1 M) in a γ-butyrolactone/dimethyl sulfoxide mixed solvent (7:3 by volume) at 60 °C for 10 min. The Cs0.15FA0.85Pb(I0.75Br0.25)3 double cation perovskite was prepared by mixing PbI2 (TCI), FAI (Greatcell Solar), FABr (Sigma-Aldrich) and CsI (Sigma-Aldrich), with molarity ratios of 1.1, 0.12, 0.73 and 0.15, respectively, in one vial and adding a mixture of DMF:DMSO 4:1 in volume. The ‘95:5 triple halide (TH)’ perovskite precursor solution was prepared by mixing two 1.5 M FAPbI3 and MAPbBr3 perovskite solutions in DMF:DMSO (4:1 volume ratio, v/v) as well as the solution of CsI (1.5 M), resulting in a nominal perovskite stoichiometry of Cs0.05(FA0.95MA0.05)0.95Pb(I0.95Br0.05)3. Then, 20 molar% MACl (Merck) dissolved in DMSO was added into the precursor solution to improve the crystallization of the film. All final solutions were stirred overnight at room temperature. For the ‘98:2 triple halide (TH)’ perovskite precursor solution, 1.73 M Cs0.05(FA0.98MA0.02)0.95 Pb(I0.98Br0.02)3 perovskite precursor was prepared by dissolving 0.90919 g lead iodide (PbI2, TCI), 0.27698 g formamidinium iodide (FAI, GreatCell Solar), 0.02247 g caesium iodide (CsI, Sigma-Aldrich), 0.00368 g methylammonium bromide (MABr, GreatCell Solar) and 0.018105 g MACl (Merck) in a 4:1 (by volume) mixture solvent of DMF (anhydrous, 99.8%; Sigma-Aldrich) and DMSO (anhydrous, ≥99.9%; Sigma-Aldrich). The precursor solution was stirred 780 rpm on the hotplate for 4 h at 55 °C and then filtered. All solution preparation processes were conducted in a N2 glovebox (O2 <1 ppm and H2O <1 ppm) 

Both triple-cation films (83:17 TC and 1.8 eV WG) were deposited by spin-coating at 5,000 rpm for 35 s, and 10 s after the start of the spinning process, the spinning substrate was washed with 300 µl ethyl acetate for approximately 1 s (the anti-solvent was placed in the centre of the film). We note that, by the end of the spinning process, the perovskite film turned dark brown. The perovskite film was then annealed at 100 °C for 1 h on a pre-heated hotplate, where the film turned slightly darker. The MAPI solution (80 µl) was spin-coated at 1,000 rpm for 5 s followed by 3,000 rpm for 80 s. A total of 100 µl toluene was added dropwise after 40 s to form a transparent perovskite film. After the spin coating, the films were dried for 2 min in the glovebox at room temperature until the films changed their colour from yellow to light brown. The MAPI perovskite layers were then subsequently annealed at 100 °C on a hotplate, where the films turned black immediately. For the Cs0.15 FA0.85Pb(I0.75Br0.25)3 perovskite, a volume of 120 µl of the precursor solution was spin-coated at 4,000 rpm (with a ramping rate of 1,334 rpm s<sup>−1</sup> ) for 40 s. After 10 s, the film was quenched by adding 300 µl of ethyl acetate. Directly afterwards, the film was annealed at 100 °C for 60 min inside the N2 filled glovebox. For the 95:5 TH perovskite, 120 µl of the perovskite precursor was spin-coated onto the cooled 

(HTL-coated) substrates at 4,000 rpm for 40 s (5 s acceleration to 4,000 rpm). A total of 200 µl anti-solvent chlorobenzene was slowly dripped onto the centre of the film 7 s before the end of the spinning programme. Further, the perovskite film was annealed at 100 °C for 60 min. The 98:2 TH Cs0.05(FA0.98MA0.02)0.95 Pb (I0.98Br0.02)3 films were fabricated by spin-coating a volume of 100 µl of the precursor solution onto the cooled (HTL-coated) substrates via two steps: 100 rpm 334 rpm s<sup>−1</sup> for 10 s and 5,000 rpm 2,000 rpm s<sup>−1</sup> for 40 s at the second leg of the spinning process. The perovskite film turned dark brown, and it was subsequently annealed at 100 °C for 20 min on a pre-heated hotplate, where the film turned black immediately. 

Only the 98:2 TH perovskite included a passivation consisting of 0.002 g ethane-1,2-diammonium iodide (EDAI2) purchased from Sigma-Aldrich dissolved in 1 ml of isopropanol (99.5%) and 1 ml toluene (anhydrous, 99.8%,) and then stirred in the ultrasonic bath for 25 min. The 120 µl solution of EDAI2 (0.002 g ml<sup>−1</sup> in isopropanol/toluene) was then deposited onto perovskite while the substrate was being spun at 5,000 rpm, 4,000 rpm s<sup>−1</sup> for 30 s. After 5 min annealing on a hotplate at 100 °C, the films were cooled down to room temperature. 

After annealing, all samples were transferred to an evaporation chamber where fullerene-C60 (30 nm), 2,9-dimethyl-4,7-diphenyl-1, 10-phenanthroline BCP (8 nm) and copper (100 nm) were deposited under vacuum (pressure of 1 × 10<sup>−7</sup> mbar). The overlap of the copper and the ITO electrodes defined the active area of the pixel (6 mm<sup>2</sup> ). 

#### **Device fabrication of** **_nip_ -type cells** 

TEC15 FTO glass was used. Glass substrates were cleaned and ultraviolet ozone treated for 15 min before electron transport layer (ETL) deposition. A total of 100 µl of titanium isopropoxide solution (diluted 1:15 in 1-butanol) was statistically spin-coated at 5,000 rpm for 45 s (acceleration of 2,000 rpm s<sup>−1</sup> ) then dried at 130 °C for 5 min and 450 °C for 30 min 100 µl of SnO2 nanoparticle dispersion (2 wt% diluted in deionized water) were spin-coated at 4,000 rpm for 30 s (acceleration of 3,000 rpm s<sup>−1</sup> ) and then annealed at 180 °C for 30 min. Then, 1.5 M (FAPbI3)0.99(CsPbBr3)0.01:35 mol% MACl (1.53 eV perovskite) were stoichiometrically weighed and dissolved in DMF:DMSO (4:1 by volume). It was stirred for 1 h and filtered (0.45 µm, PTFE) before use. A total of 100 µl of the solution was dropped dynamically. The spin was conducted in two steps: 1,000 rpm for 10 s (acceleration of 500 rpm s<sup>−1</sup> ) and 5,000 rpm for 35 s (acceleration of 1,000 rpm s<sup>−1</sup> ). Then, 300 µl of anisole was used for solvent quenching at 5 s before the end of the spin. It was annealed at 80 °C for 10 min. This was performed in the glovebox, followed by further annealing at 150 °C for 15 min in the dry box (RH <5%). A 2,2′, 7,7′-tetrakis[ _N_ , _N_ -di(4-methoxyphenyl)amino]-9,9′-spirobifluorene (Spiro-OMeTAD) solution was prepared with the following composition: 60 mg of Spiro-OMeTAD, 25.5 µl of 4- _tert_ -butylpyridine, 15.5 µl of Li-TFSI (520 mg ml<sup>−1</sup> in acetonitrile) and 12.5 µl of Co-TFSI (375 mg ml<sup>−1</sup> in acetonitrile) in 700 µl of chlorobenzene. A total of 60 µl of the solution was dynamically spin-coated at 4,000 rpm for 30 s, then dried overnight in dry air condition before Au deposition. The devices were completed with 70-nm-thick thermally evaporated Au. 

#### **Current density–voltage characteristics** 

Curves were obtained in a two-wire source-sense configuration with a Keithley 2400 (standard _J–V_ characterization). An Oriel class AAA xenon-lamp-based sun simulator was used for illumination, providing approximately 100 mW cm<sup>−2</sup> of simulated AM1.5G irradiation as calibrated using a (KG3) filtered Si reference certified from Fraunhofer Institute for Solar Energy Systems (ISE). The intensity was further monitored simultaneously with a Si photodiode to use the exact illumination intensity for efficiency calculations. The device area of 6 mm<sup>2</sup> was masked with a 4.32 mm<sup>2</sup> mask, and the obtained short-circuit current densities were checked by integrating the product of the external quantum efficiency and the solar spectrum, which matches the obtained value within less than 5%. The temperature of the cell was fixed to 

Nature Energy | Volume 9 | June 2024 | 664–676 

**672** 

**Article** 

https://doi.org/10.1038/s41560-024-01487-w 

25 °C, and a voltage ramp (scan rate) of 67 mV s<sup>−1</sup> was used. _J–V_ curves obtained using different scan speeds and stabilization times are the subject of this work. For the 83:17 reference cell, a spectral mismatch calculation was performed on the basis of the spectral irradiance of the solar simulator, the external quantum efficiency of the reference silicon solar cell and three typical external quantum efficiencies of our cells. This resulted in three mismatch factors of _M_ = 0.9949, 0.9996 and 0.9976. Given the very small deviation from unity, the measured _J_ SC was not corrected by the factor 1/ _M_ . 

#### **FH measurements** 

Fast _J–V_ curves were obtained by applying a triangular voltage pulse to the cells starting from approximately open-circuit ( _V_ OC) followed by a reverse sweep from open-circuit to −0.1 V and forward sweep from −0.1 V to _V_ OC with variable frequency or scan speed (V s<sup>−1</sup> ) using a system developed by FastChar UG. The duration of the hold voltage at _V_ OC was five times longer than the total scan time of the voltage sweep. The voltage response of the cell was measured with an oscilloscope, using an external load resistance of ≤10 Ω, and the voltage pulse was supplied by a function generator in combination with a home-built power amplifier (4×). Despite the different hardware and measurement routines, the testing conditions were the same as used for the standard _J–V_ measurements as described above. We note that, to cross-check the FH results at slow scan speeds (10–100 mV s<sup>−1</sup> ), standard _J–V_ measurements were performed on the same cells, which resulted in a nearly identical performance metric as obtained with the FH setup. 

#### **BACE** 

In dark BACE, the device was initially held at a voltage close to the open-circuit voltage, where the injected charge equals the short-circuit current. After a pre-set delay time, a bias of 0 V was applied to extract the injected and capacitive charge in the device. The delay times for the fresh devices were chosen to be typically five times longer than the extraction time of charges observed under the collection bias (typically ~5–10 s) to allow ionic charges to distribute throughout the active layer. The BACE measurements during the light aging (Fig. 6) were performed in the following way. First, while the cells were illuminated, a voltage close to the VOC was applied to the cells to prevent a premature extraction of mobile ions to the transport layers by the built-in voltage when the light source is switched off (as this would lower the extracted charge). Subsequently, the illumination was switched off; however, the built-in voltage remains roughly compensated by the applied voltage keeping the mobile ions roughly distributed throughout the bulk. Finally, after ~10 s, the voltage was switched to 0 V to extract the charge carriers. The current transients were measured with a Keithley 2400 using a home-built LabView program. The use of a current meter was found to be necessary over an oscilloscope to resolve the small ion drift currents, and we note that no significant differences were observed when the measurements were performed with a Keithley 485 picoamperemeter instead of the Keithley 2400. Finally, the extracted charge was obtained by integrating the current transient and the charge carrier density by dividing the total charge by the elementary charge and the cell volume. 

#### **Dark CELIV** 

In dark CELIV, the device was initially held at short-circuit conditions. Then, the voltage was increased linearly to minus 0.4 V (in reverse bias) using a pulse generator. The slope ( _A_ = ∆ _V_ /∆ _t_ ) was thereby varied to assess a wide timescale range (Δ _t_ ). The current transients were recorded with an oscilloscope (Agilent DSO9104H) and measured with a variable load resistance ( _R_ Load = 50 Ω at short 10 µs pulses and up to 10 kΩ at 100 ms pulses) to keep the voltage response approximately constant. The increased load resistance reduces the time resolution at short times but allows for recording the response for long pulses. The continuous increase of the electrode charge leads to a step-like voltage response. 

The voltage response step of the cell is given by ∆ _V_ = _AR_ Load _C_ , from which we calculated the capacitance of the cell ( _C_ ). Equilibrium charges in the active layer (doping-induced electronic charge or mobile ions) lead to an additional bump in the voltage response. 

#### **Numerical drift–diffusion simulations** 

The simulations were performed using SETFOS<sup>61</sup> and IonMonger, an open-source code developed by Nicola Courtier et al.<sup>60</sup> . Both programs numerically solve a system of three coupled equations, namely the Poisson equation, the continuity equation and the drift–diffusion equation<sup>82</sup> . 

#### **Absolute PL measurements** 

Excitation for the PL measurements was performed with a 520 nm continuous-wave laser (Insaneware) through an optical fibre into an integrating sphere. The intensity of the laser was adjusted to a 1 sun equivalent intensity by illuminating a 1-cm<sup>2</sup> -size perovskite solar cell under short-circuit and matching the current density to the _J_ SC under the sun simulator for the 83:17 triple-cation device (22.0 mA cm<sup>−2</sup> at 100 mW cm<sup>−2</sup> , or 1.375 × 10<sup>21</sup> photons m<sup>−2</sup> s<sup>−1</sup> ). A second optical fibre was used from the output of the integrating sphere to an Andor SR393iB spectrometer equipped with a silicon charge-coupled device camera (DU420A-BR-DD, iDus). The system was calibrated by using a calibrated halogen lamp with specified spectral irradiance, which was shone into the integrating sphere. A spectral correction factor was established to match the spectral output of the detector to the calibrated spectral irradiance of the lamp. The spectral photon density was obtained from the corrected detector signal (spectral irradiance) by division through the photon energy ( _hf_ ), and the photon numbers of the excitation and emission were obtained from numerical integration using MATLAB. In the last step, three fluorescent test samples with high specified PLQY (~70%) supplied from Hamamatsu Photonics were measured, where the specified value could be accurately reproduced within a small relative error of less than 5%. 

#### **Photoemission spectroscopy measurements** 

Photoemission experiments were performed at an ultrahigh vacuum system consisting of sample preparation and analysis chambers (both at a base pressure of 1 × 10<sup>−10</sup> mbar) as well as a load lock (with a base pressure of 1 × 10<sup>−6</sup> mbar). All of the samples were transferred to the ultrahigh vacuum chamber using a transfer rod under a rough vacuum (1 × 10<sup>−3</sup> mbar). Ultraviolet photoemission spectroscopy was performed using a helium discharge lamp (21.22 eV) with a filter to reduce the photon flux and block visible light from the source hitting the sample. All spectra were recorded at room temperature and normal emission using a hemispherical Specs Phoibos 100 analyser, and the overall energy resolution was 140 meV. 

#### **Light ageing** 

Light ageing under open-circuit conditions was performed in a dedicated aging box in the glovebox under N2 atmosphere using white light-emitting diode (LED) array illumination providing a 1 sun equivalent intensity by matching the initial current of the cell to the _J_ SC. The intensity of the LED was checked using a photodiode and remained stable over the course of the course of the measurement timescale (~24 h) in a sample holder. The cells were cooled to 25 °C over the course of the measurement using a Peltier element, but no significant changes in the degradation were observed without additional cooling or for encapsulated cells measured in the lab outside the glovebox. 

#### **Voltage and temperature ageing** 

Voltage ageing was performed by applying a voltage slightly above the open-circuit voltage to the cell, at which the injected charge equals the initial short-circuit current. Over the course of the ageing test (~24 h), the applied voltage was slightly adjusted to maintain an injection 

Nature Energy | Volume 9 | June 2024 | 664–676 

**673** 

**Article** 

https://doi.org/10.1038/s41560-024-01487-w 

current of roughly _J_ SC. The temperature aging was conducted by placing the cell on a hotplate at ~80 °C for the given amount of time. 

#### **SPO tracking** 

Long-term SPO tracking measurements were performed on 95:5 TH and 98:2 TH cells with a Botest multichannel analyser system (Botest Systems GmbH, EMU-8/ v2.3) with a constant applied voltage (initial _V_ MP) using white light LED (3000K Cree CXB3590) illumination providing a 1 sun equivalent intensity by matching the initial current of the cell to the _J_ SC under AM1.5G illumination. The temperature during the tracking was _T_ = 40 °C, and the measurements were performed in an ambient atmosphere on encapsulated cells. 

#### **MPP tracking** 

In addition to the SPO tracking, MPP tracking was performed on 95:5 ECUST, interlayer-modified 95:5 TH, and reference cells. The devices were placed under a 1 sun equivalent white LED irradiation inside a nitrogen-filled glovebox for several days. Thereby, the cell is continuously held at 25 °C and its maximum power voltage was obtained from an initial _J–V_ scan. Maximum power output was ensured by applying a small voltage perturbation (±5 mV) to the cell every 5 s. Depending on which voltage gave a higher power output, the applied voltage was either increased or decreased by 5 mV and then held at this voltage for the next 5 s. A home-built LabView program was used for these measurements. No significant changes were observed between aging under SPO or MPP conditions. 

#### **Reporting summary** 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

### **Data availability** 

All data generated or analysed during this study are included in the published article and its Supplementary Information. Data sources for the main text figures are available via Figshare at https://figshare. com/s/cbfad738b0666ecf7f98 (ref. 83). 

### **Code availability** 

The codes that support the findings of this study are available from the following links. Parameter files for IonMonger simulations are available at https://doi.org/10.25446/oxford.24359959.v2 and parameter files for SETFOS simulations at https://doi.org/10.25446/oxford.24361138.v1. 

### **References** 

1. Rong, Y. et al. Challenges for commercializing perovskite solar cells. _Science_ **361** , eaat8235 (2018). 

2. Meng, L., You, J. & Yang, Y. Addressing the stability issue of perovskite solar cells for commercial applications. _Nat. Commun._ **9** , 1–4 (2018). 

3. Ling, J. K. et al. A perspective on the commercial viability of perovskite solar cells. _Sol. RRL_ **5** , 1–48 (2021). 

4. Ruan, S. et al. Light induced degradation in mixed-halide perovskites. _J. Mater. Chem. C._ **7** , 9326–9334 (2019). 

5. Lang, F. et al. Influence of radiation on the properties and the stability of hybrid perovskites. _Adv. Mater._ **30** , 1–22 (2018). 

6. Misra, R. K. et al. Temperature- and component-dependent degradation of perovskite photovoltaic materials under concentrated sunlight. _J. Phys. Chem. Lett._ **6** , 326–330 (2015). 

7. Conings, B. et al. Intrinsic thermal instability of methylammonium lead trihalide perovskite. _Adv. Energy Mater._ **5** , 1–8 (2015). 

8. Ouyang, Y. et al. Photo-oxidative degradation of methylammonium lead iodide perovskite: mechanism and protection. _J. Mater. Chem. A_ **7** , 2275–2282 (2019). 

9. Bryant, D. et al. Light and oxygen induced degradation limits the operational stability of methylammonium lead triiodide perovskite solar cells. _Energy Environ. Sci._ **9** , 1655–1660 (2016). 

10. Wang, Q. et al. Scaling behavior of moisture-induced grain degradation in polycrystalline hybrid perovskite thin films. _Energy Environ. Sci._ **10** , 516–522 (2017). 

11. Salado, M. et al. Impact of moisture on efficiency-determining electronic processes in perovskite solar cells. _J. Mater. Chem. A_ **5** , 10917–10927 (2017). 

12. De Bastiani, M. et al. Mechanical reliability of fullerene/tin oxide interfaces in monolithic perovskite/silicon tandem cells. _ACS Energy Lett._ **7** , 827–833 (2022). 

13. Meng, W. et al. Revealing the strain-associated physical mechanisms impacting the performance and stability of perovskite solar cells. _Joule_ **6** , 458–475 (2022). 

14. Steele, J. A. et al. Thermal unequilibrium of strained black CsPbI3 thin films. _Science_ **365** , 679–684 (2019). 

15. Li, Z., Li, B., Wu, X., Sheppard, S. A. & Zhang, S. Organometallicfunctionalized interfaces for highly efficient inverted perovskite solar cells. _Science_ **420** , 416–420 (2022). 

16. Azmi, R. et al. Damp heat—stable perovskite solar cells with tailored-dimensionality 2D/3D heterojunctions—supplementary. _Mater. Sci._ **5784** , 1–9 (2022). 

17. Deng, Y. et al. Defect compensation in formamidinium–caesium perovskites for highly efficient solar mini-modules with improved photostability. _Nat. Energy_ **6** , 633–641 (2021). 

18. Holovský, J. et al. Lead halide residue as a source of light-induced reversible defects in hybrid perovskite layers and solar cells. _ACS Energy Lett._ **4** , 3011–3017 (2019). 

19. Turren-Cruz, S.-H., Hagfeldt, A. & Saliba, M. Methylammoniumfree, high-performance, and stable perovskite solar cells on a planar architecture. _Science_ **362** , 449–453 (2018). 

20. Eperon, G. E. et al. Formamidinium lead trihalide: a broadly tunable perovskite for efficient planar heterojunction solar cells. _Energy Environ. Sci._ **7** , 982 (2014). 

21. Yang, I. S. & Park, N. G. Dual additive for simultaneous improvement of photovoltaic performance and stability of perovskite solar cell. _Adv. Funct. Mater._ **31** , 1–7 (2021). 

22. Zhang, F. & Zhu, K. Additive engineering for efficient and stable perovskite solar cells. _Adv. Energy Mater._ **10** , 1902579 (2020). 

23. Byeon, J. et al. Charge transport layer-dependent electronic band bending in perovskite solar cells and its correlation to light-induced device degradation. _ACS Energy Lett._ **5** , 2580–2589 (2020). 

24. Huang, L. & Ge, Z. Simple, robust, and going more efficient: recent advance on electron transport layer-free perovskite solar cells. _Adv. Energy Mater._ **9** , 1–31 (2019). 

25. Li, Y., Xie, H., Lim, E. L., Hagfeldt, A. & Bi, D. Recent progress of critical interface engineering for highly efficient and stable perovskite solar cells. _Adv. Energy Mater._ **12** , 1–31 (2022). 

26. Chen, P. et al. In situ growth of 2d perovskite capping layer for stable and efficient perovskite solar cells. _Adv. Funct. Mater._ **28** , 1–10 (2018). 

27. Grancini, G. et al. One-year stable perovskite solar cells by 2D/3D interface engineering. _Nat. Commun._ **8** , 1–8 (2017). 

28. Gahlmann, T. et al. Impermeable charge transport layers enable aqueous processing on top of perovskite solar cells. _Adv. Energy Mater._ **10** , 1903897 (2020). 

29. Brinkmann, K. O. et al. Suppressed decomposition of organometal halide perovskites by impermeable electron-extraction layers in inverted solar cells. _Nat. Commun._ **8** , 13938 (2017). 

30. Arora, N. et al. Perovskite solar cells with CuSCN hole extraction layers yield stabilized efficiencies greater than 20%. _Science_ **358** , 768–771 (2017). 

31. Wu, S. et al. A chemically inert bismuth interlayer enhances long-term stability of inverted perovskite solar cells. _Nat. Commun._ **10** , 1161 (2019). 

Nature Energy | Volume 9 | June 2024 | 664–676 

**674** 

**Article** 

https://doi.org/10.1038/s41560-024-01487-w 

32. Cheacharoen, R. et al. Encapsulating perovskite solar cells to withstand damp heat and thermal cycling. _Sustain. Energy Fuels_ **2** , 2398–2406 (2018). 

33. Duan, L. et al. Stability challenges for the commercialization of perovskite–silicon tandem solar cells. _Nat. Rev. Mater._ **8** , 261–281 (2023). 

34. Kim, G. Y. et al. Large tunable photoeffect on ion conduction in halide perovskites and implications for photodecomposition. _Nat. Mater._ **17** , 445–449 (2018). 

35. Walsh, A., Scanlon, D. O., Chen, S., Gong, X. G. & Wei, S. H. Self-regulation mechanism for charged point defects in hybrid halide perovskites. _Angew. Chem. Int. Ed._ **54** , 1791–1794 (2015). 

36. Weber, S. A. L. et al. How the formation of interfacial charge causes hysteresis in perovskite solar cells. _Energy Environ. Sci._ **11** , 2404–2413 (2018). 

37. Richardson, G. et al. Can slow-moving ions explain hysteresis in the current-voltage curves of perovskite solar cells? _Energy Environ. Sci._ **9** , 1476–1485 (2016). 

38. Calado, P. et al. Evidence for ion migration in hybrid perovskite solar cells with minimal hysteresis. _Nat. Commun._ **7** , 1–10 (2016). 

39. Tessler, N. & Vaynzof, Y. Insights from device modeling of perovskite solar cells. _ACS Energy Lett._ **5** , 1260–1270 (2020). 

40. Futscher, M. H. et al. Quantification of ion migration in CH3NH3PbI3 perovskite solar cells by transient capacitance measurements. _Mater. Horiz._ **6** , 1497–1503 (2019). 

41. Fu, F. et al. I2 vapor-induced degradation of formamidinium lead iodide based perovskite solar cells under heat-light soaking conditions. _Energy Environ. Sci._ **12** , 3074–3088 (2019). 

42. Jacobs, D. A. et al. Lateral ion migration accelerates degradation in halide perovskite devices. _Energy Environ. Sci._ **15** , 5324–5339 (2022). 

43. Mei, A. et al. Stabilizing perovskite solar cells to IEC61215:2016 standards with over 9,000-h operational tracking. _Joule_ **4** , 2646–2660 (2020). 

44. Yang, T. Y., Gregori, G., Pellet, N., Grätzel, M. & Maier, J. The significance of ion conduction in a hybrid organic-inorganic lead-iodide-based perovskite photosensitizer. _Angew. Chem. Int. Ed._ **54** , 7905–7910 (2015). 

45. Dunfield, S. P. et al. From defects to degradation: a mechanistic understanding of degradation in perovskite solar cell devices and modules. _Adv. Energy Mater._ **10** , 1–35 (2020). 

46. Kato, Y. et al. Silver iodide formation in methyl ammonium lead iodide perovskite solar cells with silver top electrodes. _Adv. Mater. Interfaces_ **2** , 2–7 (2015). 

47. Motti, S. G. et al. Controlling competing photochemical reactions stabilizes perovskite solar cells. _Nat. Photonics_ **13** , 532–539 (2019). 

48. Reichert, S. et al. Probing the ionic defect landscape in halide perovskite solar cells. _Nat. Commun._ **11** , 6098 (2020). 

49. Tammireddy, S. et al. Temperature-dependent ionic conductivity and properties of iodine-related defects in metal halide perovskites. _ACS Energy Lett._ **7** , 310–319 (2022). 

50. Meggiolaro, D. et al. Iodine chemistry determines the defect tolerance of lead-halide perovskites. _Energy Environ. Sci._ **11** , 702–713 (2018). 

51. Le Corre, V. M. et al. Quantification of efficiency losses due to mobile ions in perovskite solar cells via fast hysteresis measurements. _Sol. RRL_ **6** , 2100772 (2022). 

52. Thiesbrummel, J. et al. Universal current losses in perovskite solar cells due to mobile ions. _Adv. Energy Mater._ **11** , 2101447 (2021). 

53. Cave, J. M. et al. Deducing transport properties of mobile vacancies from perovskite solar cell characteristics. _J. Appl. Phys._ **128** , 184501 (2020). 

54. Moia, D. et al. Dynamics of internal electric field screening in hybrid perovskite solar cells probed using electroabsorption. _Phys. Rev. Appl._ **18** , 044056 (2022). 

55. Futscher, M. H., et al. Quantification of ion migration in CH3NH3PbI3 perovskite solar cells by transient capacitance measurements. _Mater. Horiz._ **6** , 1497–1503 (2018). 

56. Jacobs, D. A. et al. Hysteresis phenomena in perovskite solar cells: the many and varied effects of ionic accumulation. _Phys. Chem. Chem. Phys._ **19** , 3094–3103 (2017). 

57. Herterich, J., Unmüssig, M., Loukeris, G., Kohlstaedt, M. & Würfel, U. Ion movement explains huge _V_ oc increase despite almost unchanged internal quasi-Fermi level splitting in planar perovskite solar cells. _Energy Technol._ **9** , 2001104 (2021). 

58. Stolterfoht, M. et al. Visualization and suppression of interfacial recombination for high-efficiency large-area pin perovskite solar cells. _Nat. Energy_ **3** , 847–854 (2018). 

59. Zhang, S. et al. Minimizing buried interfacial defects for efficient inverted perovskite solar cells. _Science_ **380** , 404–409 (2023). 

60. Courtier, N. E., Cave, J. M., Walker, A. B., Richardson, G. & Foster, J. M. IonMonger: a free and fast planar perovskite solar cell simulator with coupled ion vacancy and charge carrier dynamics. _J. Comput. Electron._ **18** , 1435–1449 (2019). 

61. Aeberhard, U. et al. Numerical optimization of organic and hybrid multijunction solar cells. in _2019 IEEE 46th Photovoltaic Specialists Conference_ 0105–0111 (IEEE, 2019). 

62. Stolterfoht, M. et al. The impact of energy alignment and interfacial recombination on the internal and external open-circuit voltage of perovskite solar cells. _Energy Environ. Sci._ **12** , 2778–2788 (2019). 

63. Li, B. et al. Revealing the correlation of light soaking effect with ion migration in perovskite solar cells. _Sol. RRL_ **6** , 2200050 (2022). 

64. Bertoluzzi, L. et al. Mobile ion concentration measurement and open-access band diagram simulation platform for halide perovskite solar cells. _Joule_ **4** , 109–127 (2019). 

65. Diekmann, J. et al. Determination of mobile ion densities in halide perovskites via low-frequency capacitance and charge extraction techniques. _J. Phys. Chem. Lett._ **14** , 4200–4210 (2023). 

66. Kniepert, J. et al. Reliability of charge carrier recombination data determined with charge extraction methods. _J. Appl. Phys._ **126** , 205501 (2019). 

67. Ghasemi, M. et al. A multiscale ion diffusion framework sheds light on the diffusion–stability–hysteresis nexus in metal halide perovskites. _Nat. Mater._ **22** , 329–337 (2023). 

68. Zu, F. et al. Position-locking of volatile reaction products by atmosphere and capping layers slows down photodecomposition of methylammonium lead triiodide perovskite. _RSC Adv._ **10** , 17534–17542 (2020). 

69. De Bastiani, M. et al. Toward stable monolithic perovskite/ silicon tandem photovoltaics: a six-month outdoor performance study in a hot and humid climate. _ACS Energy Lett._ **6** , 2944–2951 (2021). 

70. Sahli, F. et al. Fully textured monolithic perovskite/silicon tandem solar cells with 25.2% power conversion efficiency. _Nat. Mater._ **17** , 820–826 (2018). 

71. Senocrate, A. et al. The nature of ion conduction in methylammonium lead iodide: a multimethod approach. _Angew. Chem. Int. Ed. Engl._ **56** , 7755–7759 (2017). 

72. Yoon, S. J., Kuno, M. & Kamat, P. V. Shift happens. how halide ion defects influence photoinduced segregation in mixed halide perovskites. _ACS Energy Lett._ **2** , 1507–1514 (2017). 

73. Onno, A., Chen, C. & Holman, Z. C. Electron and hole partial specific resistances: a framework to understand contacts to solar cells. in _Proc. 46th IEEE Photovoltaic Specialists Conference_ (ed) 2329–2333 (IEEE, 2019). 

74. Würfel, P. & Würfel, U. _Physics of Solar Cells: From Basic Principles to Advanced Concepts_ (Wiley, 2009). 

Nature Energy | Volume 9 | June 2024 | 664–676 

**675** 

**Article** 

https://doi.org/10.1038/s41560-024-01487-w 

75. Kavadiya, S. et al. Investigation of the selectivity of carrier transport layers in wide-bandgap perovskite solar cells. _Sol. RRL_ **5** , 1–9 (2021). 

76. Kang, D. H. & Park, N. G. On the current–voltage hysteresis in perovskite solar cells: dependence on perovskite composition and methods to remove hysteresis. _Adv. Mater._ **31** , 1–23 (2019). 

77. Jacobs, D. A. et al. The two faces of capacitance: new interpretations for electrical impedance measurements of perovskite solar cells and their relation to hysteresis. _J. Appl. Phys._ **124** , 225702 (2018). 

78. Pilania, G., Balachandran, P. V., Kim, C. & Lookman, T. Finding new perovskite halides via machine learning. _Front. Mater._ **3** , 1–7 (2016). 

79. Takahashi, K., Takahashi, L., Miyazato, I. & Tanaka, Y. Searching for hidden perovskite materials for photovoltaic systems by combining data science and first principle calculations. _ACS Photonics_ **5** , 771–775 (2018). 

80. Li, J., Pradhan, B., Gaur, S. & Thomas, J. Predictions and strategies learned from machine learning to develop high-performing perovskite solar cells. _Adv. Energy Mater._ **9** , 1901891 (2019). 

81. Le Corre, V. M., Sherkar, T. S., Koopmans, M. & Koster, L. J. A. Identification of the dominant recombination process for perovskite solar cells based on machine learning. _Cell Rep. Phys. Sci._ **2** , 100346 (2021). 

82. Diekmann, J. et al. Pathways toward 30% efficient single‐junction perovskite solar cells and the role of mobile ions. _Sol. RRL_ **5** , 2100219 (2021). 

83. Ion-induced field screening as a dominant factor in perovskite solar cell operational stability. _Figshare_ https://figshare.com/s/ cbfad738b0666ecf7f98 (2024). 

### **Acknowledgements** 

We acknowledge HyPerCells (a joint graduate school of the University of Potsdam and the Helmholtz-Zentrum Berlin) and the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation)— project numbers 423749265 and 424709669—SPP 2196 (SURPRISE-2 and HIPSTER-PRO), as well as project numbers 182087777-SFB951 and MUJUPO (RI 1551/12-2), for funding. K.B. and T.R. thank the DFG (HIPSTER-PRO:RI 1551/15-2), the BMBF (MOISTURE: 01DP20008 and the EU Horizon 2020 (FOXES: 951774) for funding. Y.W. acknowledges the National Natural Science Foundation of China (22179037). We also acknowledge financial support by the Federal Ministry for Economic Affairs and Energy within the framework of the 7th Energy Research Programme (P3T-HOPE, 03EE1017C). A.D. would like to thank the Penrose scholarship for generously funding his studentship. M.S. further acknowledges the Heisenberg programme from the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation) with project number 498155101 and the Vice-Chancellor Early Career Professorship Scheme from CUHK for funding. F.L. acknowledges funding by the Volkswagen Foundation via the Freigeist Program. A.A. acknowledges support from the Welsh Government’s Sêr Cymru II Rising Star through the European Regional Development Fund, Welsh European Funding Office and Swansea University Strategic Initiative in Sustainable Advanced Materials. 

### **Author contributions** 

J.T. and Sa.Sh. performed experiments, data analysis and contributed to drafting of the manuscript. E.G.-P., F.Z., F.P.-C, St.Ze., F.Y, M.S., P.C., A.D., F.A.A., Se.Se. and Sh.Zh. performed additional experiments. J.T., Sa.Sh., M.S, J.D. and K.P.P. performed simulations and provided programming support. K.O.B., J.W., Q.J., F.L., S.A., T.R., A.A., D.N., N.K., Y.W., V.M.L.C. and H.S. helped with the interpretation and analysis of the results. F.L., S.A., T.R., A.A., D.N., N.K., Y.W., H.S. and M.S. supervised students. M.S. initiated the research and drafted the manuscript. 

### **Funding** 

Open access funding provided by Universität Potsdam. 

### **Competing interests** 

H.J.S. is co-founder and CSO of Oxford PV Ltd., a company commercializing perovskite PV technology. M.S., F.L. and D.N. are co-founders of FastChar UG, a company specializing in automated tools for perovskite solar cell characterization. The remaining authors declare no competing interests. 

### **Additional information** 

**Supplementary information** The online version 

contains supplementary material available at https://doi.org/10.1038/s41560-024-01487-w. 

**Correspondence and requests for materials** should be addressed to Martin Stolterfoht. 

**Peer review information** _Nature Energy_ thanks Carsten Deibel and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at www.nature.com/reprints. 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http://creativecommons. org/licenses/by/4.0/. 

© The Author(s) 2024, corrected publication 2024 

Nature Energy | Volume 9 | June 2024 | 664–676 

**676** 

