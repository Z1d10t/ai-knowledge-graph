# Phase-controlled van der Waals growth of wafer-scale 2D MoTe2 layers for integrated high-sensitivity broadband infrared photodetection

| 字段 | 内容 |
|---|---|
| 期刊 | Light: Science & Applications |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 382 |
| 作者 | Di Wu, Chen-Guang Guo, Longhui Zeng, Xiaoyan Ren, Zhi-Feng Shi, Long Wen, Qin Chen, Mengyao Zhang et al. |
| DOI | 10.1038/s41377-022-01047-5 |
| 源文件 | 033_Wu_2023_Phase-controlled-van-der-Waals-growth-of-wafer-s.pdf |

---
Official journal of the CIOMP 2047-7538 www.nature.com/lsa 

Wu et al. Light: Science & Applications (2023) 12:5 https://doi.org/10.1038/s41377-022-01047-5 

O p e n A c c e s s 

## A R T I C L E 

# Phase-controlled van der Waals growth of wafer-scale 2D MoTe2 layers for integrated high-sensitivity broadband infrared photodetection 

Di Wu 1, Chenguang Guo1, Longhui Zeng2✉, Xiaoyan Ren1, Zhifeng Shi 1, Long Wen3, Qin Chen3, Meng Zhang4, Xin Jian Li<sup>1✉</sup> , Chong-Xin Shan 1 and Jiansheng Jie4✉ 

### Abstract 

Being capable of sensing broadband infrared (IR) light is vitally important for wide-ranging applications from fundamental science to industrial purposes. Two-dimensional (2D) topological semimetals are being extensively explored for broadband IR detection due to their gapless electronic structure and the linear energy dispersion relation. However, the low charge separation efficiency, high noise level, and on-chip integration difficulty of these semimetals significantly hinder their further technological applications. Here, we demonstrate a facile thermal-assisted tellurization route for the van der Waals (vdW) growth of wafer-scale phase-controlled 2D MoTe2 layers. Importantly, the type-II Weyl semimetal 1T′-MoTe2 features a unique orthorhombic lattice structure with a broken inversion symmetry, which ensures efficient carrier transportation and thus reduces the carrier recombination. This characteristic is a key merit for the well-designed 1T′-MoTe2/Si vertical Schottky junction photodetector to achieve excellent performance with an ultrabroadband detection range of up to 10.6 µm and a large room temperature specific detectivity of over 10<sup>8</sup> Jones in the mid-infrared (MIR) range. Moreover, the large-area synthesis of 2D MoTe2 layers enables the demonstration of high-resolution uncooled MIR imaging capability by using an integrated device array. This work provides a new approach to assembling uncooled IR photodetectors based on 2D materials. 

### Introduction 

Detection in multiple infrared (IR) regions spanning from short- and mid- to long-wave IR plays an important role in diverse fields, from scientific research to wide-ranging technological applications, including target identification, imaging, remote monitoring, and gas sensing<sup>1–3</sup> . Currently, the state-of-the-art IR photodetectors are mainly dominated by conventional narrow bandgap semiconductors, including In1-xGaxAs, InSb, and Hg1-xCdxTe, operating in short-wave IR (SWIR, 1–3 µm), mid-wave IR (MWIR, 3–6 µm), and 

Correspondence: Longhui Zeng (lhzeng.hfut@gmail.com) or Xin Jian Li (lixj@zzu.edu.cn) or Jiansheng Jie (jsjie@suda.edu.cn) 

> 1School of Physics and Microelectronics, Key Laboratory of Material Physics Ministry of Education, Zhengzhou University, Zhengzhou, Henan 450052, China 

> 2Department of Electrical and Computer Engineering, University of California San Diego, La Jolla, CA 92093, USA 

long-wave IR (LWIR, 6–15 µm) spectral bands, respectively<sup>4–6</sup> . Notably, these photodetectors not only rely on expensive processes of raw materials growth and complex processing procedures, but also suffer from cryogenic cooling conditions with time-consuming and high power consumption<sup>7,8</sup> . Moreover, there are several remaining technological challenges, such as poor complementary metal-oxide-semiconductor (CMOS) compatibility, bulky module size, and low efficiency, which severely restrict the wider application of these detectors. Additionally, similar limitations and drawbacks associated with other mature semiconductor technologies, such as quantum wells, type-II superlattices, and III-V semiconductor heterostructures, have stimulated the research community to search for new IR absorber candidates, which not only possess good optoelectronic properties comparable to III-V material systems but also feature low-cost, homogenous integration, 

> Full list of author information is available at the end of the article 

> © The Author(s) 2023 

> OpenAccess ThisarticleislicensedunderaCreativeCommonsAttribution4.0InternationalLicense,whichpermitsuse,sharing,adaptation,distributionandreproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/licenses/by/4.0/. 

Wu et al. Light: Science & Applications (2023) 12:5 

Page 2 of 12 

ease of fabrication, high-yield production<sup>4</sup> . To date, several alternative candidates, e.g., colloidal quantum dots (CQDs), graphene, black phosphorus (BP), and black arsenic phosphorus (b-AsP), have been intensively studied<sup>9–14</sup> . These promising alternatives have enabled advanced achievements in IR photodetection to overcome classical counterparts’ limitations. For instance, room temperature SWIR detection (λ = 1.3 µm) has been demonstrated based on solutionprocessed PbS quantum dots (QDs)<sup>15</sup> . MWIR-LWIR detection has been realized with two-dimensional (2D) material systems of BP and b-AsP (3–8 µm), at room temperature<sup>16–18</sup> . However, several unsolved challenging issues of these materials in terms of low optical absorption, chemical instability, non-scalable fabrication, and complicated manufacturing techniques impede their further technological actualization and commercialization<sup>19,20</sup> . Therefore, the exploration of an attractive and promising candidate with wide bandgap tunability, strong IR absorption, good air stability, and excellent optoelectronic properties may offer an alternative solution for high-sensitivity IR detection. 

Recently, the rising star of 2D molybdenum ditelluride (MoTe2) with a favorable transition from semiconducting (2H) to semimetallic (1T′) phase, high carrier mobility, wide optical absorption, and good chemical stability has been chosen as a promising candidate for the IR sensors assembly<sup>21–24</sup> . Compared with its semiconducting counterpart with a bandgap of ~1.0 eV, semimetallic 1T ′-MoTe2 featuring a gapless nature and unique optoelectronic properties, has shown great potential for the use in broadband IR photodetection applications. More importantly, 1T′-MoTe2 has been confirmed to be a type-II Weyl semimetal<sup>22,23</sup> , where the Weyl point appears at the boundary of electron and hole pockets, enabling the realization of a high sensitivity response over a wide spectral band due to the linear dispersion and suppressed backscattering<sup>24</sup> . To date, top-down exfoliation of MoTe2 from the bulk crystal was stuck by the low yield and limited size. Although bottom-up growth of MoTe2 could be achieved by the standard chemical vapor deposition (CVD) methods, the unsatisfactory lateral scale of resultant few or multilayer nanosheets is limited to tens of micrometers, and even smaller sizes<sup>25</sup> . So far, the demonstration of a number of broadband photodetectors utilizing micron-sized 2D semimetals in several studies suggests their initial potential in next-generation IR photodetection technologies<sup>24</sup> . Unfortunately, the main technological bottlenecks directly related to the large noise level under a bias voltage and the low charge separation efficiency impede their further applications in high-performance broadband IR photodetection due to the lack of high-quality junctions<sup>26,27</sup> . On the other hand, the weak optical absorption originating from atomically thin 2D materials results in another limitation of the total photocarrier generation in photodetectors<sup>28</sup> . Moreover, by applying a bias voltage on the metal-semimetal-metal 

device, the large dark current through the photodetector will significantly reduce the specific detectivity of the detector<sup>26</sup> . We, therefore, propose the construction of 2D/threedimensional (3D) mixed-dimensional van der Waals (vdW) heterostructures to boost the performance of detectors, which can combine novel 2D materials and 3D semiconductors with mature integration processes<sup>29,30</sup> . 

Herein, we propose a facile and scalable thermal-assisted tellurization approach for the rational growth of wafer-scale 2D MoTe2 layers with controllable thickness, along with a tunable phase transition from semiconductor (2H) to semimetal (1T′). The large-scale uniform 2D MoTe2 layers enable the in situ construction of a high-quality vertical 1T′-MoTe2/ Si 2D/3D Schottky junction device. The as-fabricated photodetector is capable of sensing broadband IR light up to the LWIR range (λ = 10.6 µm) at room temperature with large specific detectivities of 4.75–2.8 × 10<sup>8</sup> Jones in the midinfrared (MIR) range of 3.0–10.6 µm, which is among the widest range for photodetectors based on 2D transition metal chalcogenides (TMDs) materials. Importantly, the nature of the thermal-assisted tellurization technique allows for the assembly of an 8 × 8 focal plane array device, demonstrating an impressive MIR imaging capability without the need for cryogenic cooling. This work provides a viable way for the development of highly sensitive 2D photodetectors for room temperature MIR photodetection and image-sensing applications. 

### Results 

Figure 1a, b show the atomic structures of the semimetallic 1T′ (monoclinic) and semiconducting 2H (hexagonal) phases of MoTe2, respectively. For the 2H phase, a single MoTe2 layer consists of a Mo atoms layer arranged in hexagons between two Te atoms layers in repetitive cells. In contrast, Mo atoms arrange octahedral coordination around the Te atoms, with lattice distortion along the x-axis to form the 1T′ phase<sup>31</sup> . In this work, a predeposited Mo film as a precursor was transformed into 2D MoTe2 layer via a vdW growth mechanism through a direct thermal-assisted tellurization process, as shown in Fig. S1. As a matter of fact, the phase transition of MoTe2 is highly dependent on the growth time. Optical images in Fig. 1c reveal that the 1T′-MoTe2 layer was readily obtained by transforming the pre-deposited Mo metal layer within a short growth time of 10 min due to the decreased free energy of 1T′-MoTe2 in the presence of the Te deficiency in the initial transition stage<sup>31</sup> . Note that the transition time from Mo to 1T′-MoTe2 is highly dependent on the initial thickness of the Mo layer, which increases with the increasing precursor Mo layer thickness (Fig. S2). As the growth time increases to 30 min, the island-shaped 2H-MoTe2 layers only appear randomly, and then gradually become larger as the growth time increases to 120 min. Specially, when the growth time 

Wu et al. Light: Science & Applications (2023) 12:5 

Page 3 of 12 



<!-- Start of picture text -->
a c d<br>10 min 30 min<br>100 100<br>1T ′ 1T ′ 80 80<br>2H<br>y z 1T ′ 60 60<br>Te 1T′<br>b Mo x x 120 min 240 min 40 2H 40<br>2H 2H 2H 20 20<br>y z 1T ′ 0 0<br>x x 0 40 80 120 160 200 240<br>Time (min)<br>e Bg f g 001 120<br>Mo 3d5/2 Te 3d5/2<br>Te 3d3/2<br>Mo 3d3/2 010<br>Ag Ag Ag 1T′-MoTe2 1T′ MoOMoO3 3 TeO2 TeO2<br>0.4 eV 0.4 eV<br>E2g<br>A1g<br>B2g 2H-MoTe2 2H 20 μ m<br>IPF-Z map<br>100 150 200 250 300 350 400 220 230 240 570 580 590<br>Raman shift (cm -1 ) Binding Energy (eV)<br>h Y0 i (100) j (100) (010)<br>0.63 nm (004) 0.35 nm<br>(100) (100)<br>X0<br>(004)<br>(001) 0.35 nm 1T ′ 2H<br>30<br>60<br>90<br>120150 1 nm 1 nm<br>(010)<br>0.35 nm<br>Proportion of 2H (%) ′ (%)Proportion of 1T<br>Intensity (a.u.) Intensity (a.u.)<br><!-- End of picture text -->

Fig. 1 Synthesis and characterization of the 2D MoTe2 layers. a, b Atomic structures of 1 Tʹ- and 2H-MoTe2. c Photographs of the 2D MoTe2 layers with different growth times. Scale bar: 100 μm. d Proportion of 1 Tʹ- and 2H-MoTe2 as a function of growth time. e, f Raman and XPS spectra of the 1 Tʹ- and 2H-MoTe2 layers. g, h Inverse pole figures along the z-axis (IPF-Z) and pole figure of the 1Tʹ-MoTe2 layers acquired from EBSD mapping on large-area. i, j Z-contrast STEM images of 1Tʹ- and 2H-MoTe2 

further reaches 240 min, the island-like layers of 2HMoTe2 merge together, leading to the formation of a uniform and continuous 2H-MoTe2 layer. The phase transformation from 1T′ to 2H phase can be elucidated by the time-temperature-transformation (TTT) theory<sup>32</sup> . Figure 1d plots the proportion of 1Tʹ and 2H phases of MoTe2 with the growth time, revealing the linear increase of the proportion of 2H-MoTe2 layers with increasing the growth time at a rate of ~0.5% per min. Based on the Raman spectroscopic studies of the assynthesized 1Tʹ- and 2H-MoTe2 layers in Fig. 1e, the phase-specific characteristic Raman peaks of Bg (162.5 cm<sup>−1</sup> ) and Ag (258.6 cm<sup>−1</sup> ) vibration modes for 1T ′-MoTe2 and A1g (170.3 cm<sup>−1</sup> ) and E2g (230.5 cm<sup>−1</sup> ) for 2H-MoTe2, respectively, can be clearly distinguished. In the X-ray photoelectron spectroscopy (XPS) analysis (Fig. 1f), the peaks of Mo 3d5/2 (228.5 eV), Mo 3d3/2 (231.7 eV), Te 3d5/2 (573.2 eV), and Te 3d3/2 (583.6 eV) can be assigned to 2H-MoTe2, while the corresponding peaks of 

1 T′-MoTe2 redshift by ~0.4 eV compared to the semiconducting phase due to the reduction in binding energy caused by Te deficiency<sup>33</sup> . Besides, the atomic ratios of Te/Mo are evaluated to be ∼1.92 and ~1.98 for the 1Tʹand 2H-MoTe2 layers, respectively, confirming the existence of more Te deficiency in the 1Tʹ-MoTe2 layer. As shown in Fig. S3, the X-ray diffraction (XRD) patterns of both the 1Tʹ- and 2H-MoTe2 layers present four sharp peaks assigned to crystal planes of (002), (004), (006), and (008), respectively, without Mo peaks, indicating the full transformation of the Mo film to highly crystalline MoTe2 layers along the (001) direction in a preferential orientation. Transmission electron microscopy (TEM) results in Fig. S4 indicate that 2D MoTe2 layers consist of many adjacent single-crystal MoTe2 domains. Furthermore, electron back-scattered diffraction (EBSD) mapping conducted on the large-area MoTe2 sample with the uniform red color (related to the [001] crystal orientation) in Fig. 1g confirms the preferential crystal growth of the 

Wu et al. Light: Science & Applications (2023) 12:5 

Page 4 of 12 

1Tʹ-MoTe2 layers along the normal direction, consistent with the XRD results. In addition, a number of crystal domains arranged in a mosaic of a single crystal for layers of 1Tʹ-MoTe2 is further evidenced by the inverse pole figure maps along the x- and y-axes in Fig. S5. The (001) dominant orientation in the MoTe2 layers, as confirmed by the pole figure in Fig. 1h, demonstrates high crystallinity despite polycrystalline features. The Z-contrast high-resolution scanning TEM (HRSTEM) images in Fig. 1i, j show a monoclinic lattice structure with spacing distances of 0.35 and 0.63 nm, which correspond to (100) and (004) planes of 1Tʹ-MoTe2, while 2H-MoTe2 possesses a hexagonal atomic structure with a lattice spacing of 0.35 nm for the (100) and (010) planes. 

By virtue of the facile and scalable thermal-assisted tellurization strategy, we can precisely tailor the thickness of the 2D MoTe2 layers by tuning the initial Mo film thickness. Figure 2a demonstrates the 2D 1Tʹ-MoTe2 layers with various thicknesses of ~2.2, ~5.1, ~10.7, ~15.3, and ~35.1 nm, according to atomic force microscopy (AFM) results. The thickness-dependent XRD patterns and Raman spectra of the 1Tʹ-MoTe2 layers in Fig. S6 confirm the high quality of as-synthesized samples with well-controlled thickness. From the measured absorption spectra in Fig. 2b, the layer-independent optical bandgap with zero bandgaps strongly manifests its gapless nature for 1Tʹ-MoTe2 layers. In Fig. 2c and Fig. S7, ultraviolet photoemission spectroscopy (UPS) characterization of 1Tʹ-MoTe2 with different layer thicknesses reveals the layer-dependent energy band structure. The work function (WF) values are calculated to be ~3.76, ~3.99, ~4.17, ~4.29, ~4.34, and ~4.43 eV for the 1Tʹ-MoTe2 layers with thicknesses of ~2.2, ~5.1, ~10.7, ~15.3, ~20.3, and ~35.1 nm, respectively. Note that the Fermi level (EF) shifts from 3.76 to 4.43 eV due to the higher hole concentration in the relatively thicker MoTe2 layers (Fig. S8), as plotted in Fig. 2d. In addition, the Hall measurements confirm that carrier mobility highly depends on layer thickness, revealing the increased mobility and decreased resistivity of 2H/1Tʹ-MoTe2 layers with increasing the layer thickness. Specifically, the 1Tʹ-MoTe2 layers possess a higher carrier mobility than their its 2H phase counterparts, which is beneficial for improving the carrier collection efficiency. To further verify the above experimental observation, we carried out density functional theory (DFT) calculations for simulating the layerdependent electronic band structures of the 2D MoTe2 layers, as shown in Fig. 2e, from which the gapless nature of 1Tʹ-MoTe2 can be clearly observed from monolayer to bulk. In contrast, 2H-MoTe2 has an indirect bandgap of 1.16–0.73 eV for its monolayer to bulk structure (Fig. S9). In addition, the scalable and facile thermal-assisted tellurization route enables the direct growth of wafer-scale 2D MoTe2 layers on 2-inch SiO2/Si wafers, as shown in 

Fig. S10a, b. Besides, the Raman scans across the wafer diameter with similar density and profile in Fig. S10c, d suggest the admirable homogeneity and uniformity of the large-scale 2D MoTe2 layers, making them attractive and promising candidates for application in integrated optoelectronic devices and systems. 

The vdW growth of the large-area 2D MoTe2 layers offers more flexibility for the development of high-sensitivity optoelectrical devices. In light of this, we developed a 1TʹMoTe2/Si vertical Schottky junction device by the in situ vdW growth of 1Tʹ-MoTe2 layers on a pre-patterned Si (n-type, 1–10 Ω cm) substrate. To ensure efficient carrier collection, monolayer graphene (Gr, 300 Ω sq<sup>−1</sup> ) and In-Ga alloy were selected as top transparent contact with 1TʹMoTe2 layer and an ohmic contact with Si (Fig. S11), respectively. Figure 3a shows the schematic illustration of the Gr/1Tʹ-MoTe2/Si Schottky junction device, and the photograph of a real device is shown in Fig. S12. The crosssectional HRTEM image of the 1Tʹ-MoTe2/Si Schottky junction in Fig. 3b obviously reveals the layer-by-layer structure along [001] direction for the MoTe2 layers with a thickness of ~34.3 nm on the Si substrate, yielding a sharp atomic heterostructure interface. Since the thickness of the monolayer MoTe2 is ~0.7 nm, the layer number is approximately determined to be ~49 layers. Due to the unique vdW growth manner, there are no obvious defects, including crystal deformation, stack faults, or dislocations at the interface, suggesting the formation of a high-quality junction interface. Significantly, the existence of an ultrathin natural oxidation layer (~4 nm) on the Si surface has an inappreciable effect on carrier transportation due to the direct tunneling behavior, which will even serve as a passivation layer to suppress carrier recombination and enhance device performance<sup>1</sup> . The corresponding elemental mapping results of the heterostructure also confirm the chemical element distributions in the 1Tʹ-MoTe2/Si Schottky junction. 

Figure 3c plots the current-voltage (I-V) characteristics of the Gr/1Tʹ-MoTe2/Si Schottky junction photodetector under dark conditions and light illumination with various wavelengths. In the dark, the device shows a typical current rectification characteristic with a remarkable current ratio, suggesting the high quality of the Schottky junction. Notably, upon light illumination in a broad wavelength range (265 nm–10.6 μm), the generation of photon-excited carriers results in the right shift of I-V characteristic curves, giving rise to pronounced photovoltaic behaviors, which enable the device to operate in a self-powered mode without the need of extra power. We further characterized the photovoltaic photoresponse properties of the device over a wide spectral range, as shown in Fig. 3d. Notably, the photodetector demonstrates the robust response to ultrabroadband light from deep UV of 265 nm to LWIR of 10.6 μm with fast speed, giving rise to decent Ion/Ioff ratios of ~10<sup>5</sup> for 265 nm (1.7 mW cm<sup>−2</sup> ), ~10<sup>6</sup> for 405 nm 

Wu et al. Light: Science & Applications (2023) 12:5 

Page 5 of 12 



<!-- Start of picture text -->
a<br>Quartz 2.2 nm 5.1 nm 10.7 nm 15.3 nm 35.1 nm<br>~2.2 nm ~5.1 nm ~10.7 nm ~15.3 nm ~35.1 nm<br>b 3 c d<br>2.2 nm (~3 L)5.1 nm (~7 L) 16.79 eV 35.1 nm (50 L) -3.8 Fermi level<br>10.7 nm (~15 L)<br>20.3 nm (29 L)<br>2 15.3 nm (~22 L) 16.88 eV<br>-4.0<br>35.1 nm (~50 L)<br>15.3 nm (22 L)<br>16.93 eV<br>10.7 nm (15 L) -4.2<br>1 1 7.05 eV<br>5.1 nm (7 L)<br>17.23 eV<br>-4.4<br>17.46 eV 2.2 nm (3 L)<br>0<br>0 1 2 3 18 16 14 12 10 0 5 10 15 20 25 30 35<br>Photon Energy (eV) Binding Energy (eV) Thickness (nm)<br>e 3<br>2<br>1<br>0<br>1L 2L 5L 10L bulk<br>-1<br>-2<br>-3<br>Γ Y B Γ Γ Y B Γ Γ Y B Γ Γ Y B Γ B Γ D B A Y E A<br>Fig. 2 Thickness control and characterization of the 2D MoTe2 layers. a Photograph and corresponding AFM images of the 1Tʹ-MoTe2 layers<br>with different layer numbers grown on the quartz. Scale bar: 2 μm. b Thickness-dependent Tauc plots of the 1Tʹ-MoTe2 layers. c, d Secondary-electron<br>cut-off regions and Fermi levels of the 1Tʹ-MoTe2 layers. e Electronic band structures of the 1Tʹ-MoTe2 layers obtained from DFT simulation<br>Intensity (a.u.) Energy (eV)<br>1/21/23 (eV/cm)()(×10)hνα<br>Energy (eV)<br><!-- End of picture text -->

(32 mW cm<sup>−2</sup> ), ~4 × 10<sup>6</sup> for 650 nm (43 mW cm<sup>−2</sup> ), ~5.6 × 10<sup>6</sup> for 980 nm (44 mW cm<sup>−2</sup> ), ~1.4 × 10<sup>4</sup> for 1550 nm (23 mW cm<sup>−2</sup> ), ~1.3 × 10<sup>3</sup> for 2.2 μm (50 mW cm<sup>−2</sup> ), ~6.6 × 10<sup>2</sup> for 3.0 μm (50 mW cm<sup>−2</sup> ), ~4.8 × 10<sup>2</sup> for 4.6 μm (50 mW cm<sup>−2</sup> ), and ~3.7 × 10<sup>2</sup> for 

10.6 μm (50 mW cm<sup>−2</sup> ). The photovoltaic response spanning from deep UV to LWIR can be ascribed to the ultrawide broad absorption of 2D semimetallic 1Tʹ-MoTe2 layer. The working mechanism could be explained by the energy band diagram of the Schottky junction (Fig. 3e). Due to the 

Wu et al. Light: Science & Applications (2023) 12:5 

Page 6 of 12 



<!-- Start of picture text -->
a Light b O Si Mo Te<br>Graphene<br>[001]<br>34.3 nm<br>MoTe2<br>MoTe2<br>MoTe2 Si 5 nm Si 5 nm<br>c d<br>V bias= 0 V<br>10 -2 10 -3 980 nm<br>650 nm<br>10 -3 405 nm<br>10 -4<br>10 -4<br>10 -5 265 nm<br>10 -5<br>10 -6 Dark265 nm 1010 -6-7 1.5 μm2.2 μm<br>10 -7 405 nm 3.0 μm 4.6 μm 10.6 μm<br>980 nm 10 -8<br>10 -8 1.5 μm<br>10 -9 3.0 μm 10 -9<br>4.6 μm<br>10 -10 10.6 μm 10 -10<br>-1.0 -0.5 0.0 0.5 1.0 0 40 80 120 160 200 240 280 320 360<br>Voltage (V) Time (s)<br>e 1T ′ -MoTe2 n -Si f 1T′-MoTe2 V/m5.0<br>h � E0<br>4.5<br>W =4.43 eV � Si=4.05 eV<br>- - 4.0<br>- - - - n -Si<br>EF EC<br>+ + Eg(Si) =1.12 eV<br>+ + + + EV 3.5<br>3.0<br>Width<br>Au<br>SiO2 Si<br>In-Ga<br>Current (A) Current (A)<br>Depth<br><!-- End of picture text -->

Fig. 3 Optoelectronic performance of the photodetector. a Schematic illustration of a graphene/1Tʹ-MoTe2/Si Schottky junction device. b Crosssectional HRTEM image of the device and the corresponding elemental mapping image. c I-V characteristics of the graphene/1Tʹ-MoTe2/Si Schottky junction device acquired in the dark and under irradiation of broadband light. d Time-dependent photoresponse properties to pulsed light illumination in a broad spectral band. e, f Energy band diagram and electrical potential distribution of the photodetector 

difference in the work function of the multilayer MoTe2 layer and n-Si, a built-in electric field at the junction interface will be produced with a Schottky barrier of ~0.38 eV when the 1Tʹ-MoTe2 layer contacts with n-Si. Based on the electric field distribution simulation of the 1Tʹ-MoTe2/Si Schottky junction by COMSOL Multiphysics (Fig. 3f), a depletion layer is mainly distributed at the Si side with a built-in electric field direction from Si to 1Tʹ-MoTe2. Under UV-near infrared (NIR) light illumination with photon energy higher than the bandgap of Si, the photogenerated electron-hole pairs from both the 1Tʹ-MoTe2 and Si sides will be separated by the built-in electric field and then drift in the opposite direction toward each electrode, giving rise to the photocurrent. However, upon IR 

illumination with sufficient energy to overcome the Schottky barrier, the electrons would flow from the 1TʹMoTe2 to the Si side with the thermionic emission mechanism, resulting in an obvious photocurrent in the NIR-MIR range. For the IR photon with energy lower than the Schottky barrier, the photo-excited carriers can transit through the barrier of the ultrathin insulator layer (~4 nm) based on a direct tunneling working mechanism, producing the pronounced photoresponse of up to 10.6 µm<sup>1</sup> . 

The MIR photodetection performance of the 1TʹMoTe2/Si Schottky junction device was evaluated by investigating photoresponses of the device under MIR illumination of 3.0, 4.6, and 10.6 µm. Obviously, the photodetector shows prominent MIR responses when the 

Wu et al. Light: Science & Applications (2023) 12:5 

Page 7 of 12 



<!-- Start of picture text -->
a 10 -7 3.0  μ m 50 20 Unit: mW/cm 2 b 3.0  μ m<br>1010 -8-9 12 2 0.5 10.6 4.6  μμ mm<br>10 -10<br>1010 -7-8 4.6  μ m 50 25 8 Unit: mW/cm 2 10 -8 I 3.0~ P 0.81 I 10.6~ P 0.79<br>1.7<br>10 -9 0.5<br>10 -10<br>1010 -7-8 10.6  μ m 50 21 7.2 2.6 Unit: mW/cm 2 10 -9 I 4.6~ P 0.80<br>10 -9 0.6<br>10 -10<br>0 50 100 150 200 10 0 10 1 10 2<br>Time (s) Light intensity (mW/cm 2 )<br>c d 10 14<br>0.14 3.0 μm 10 3 R<br>4.6 μm D * 10 13<br>0.12 10.6 μm 10 2<br>10 12<br>0.10 10 1<br>0.08 10 0 10 11<br>0.06 10 -1 10 10<br>0.04 10 -2 10 9<br>0.02 10 -3 10 8<br>10 0 10 1 10 2 0.65 0.98 1.55 2.2 3.0 4.6 10.6<br>Light intensity (mW/cm 2 ) Wavelength (μm)<br>e<br>1T′-MoTe2/Si<br>10 13<br>Fe3O4<br>PdSe2<br>10 12<br>b-AsP<br>TaAs<br>10 11 PbSe<br>HgCdTe<br>10 10 Thermistor<br>10 9<br>10 8<br>10 7<br>0.65 0.98 1.55 2.2 3.0 4.55 10.6<br>Wavelength (μm)<br>Current (A)<br>Photocurrent (A)<br>Responsivity (mA/W) Responsivity (mA/W)<br>Specific detectivity (Jones)<br>Specific detectivity (Jones)<br><!-- End of picture text -->

Fig. 4 MIR photodetection performance of the photodetector. a Temporal photoresponses of the Gr/1Tʹ-MoTe2/Si Schottky junction device under light illumination of 3, 4.6, and 10.6 μm with various light intensities. b The fitting photocurrent versus light intensity at 3.0, 4.6, and 10.6 μm by the power law. c Responsivity at 3.0, 4.6, and 10.6 μm as a function of light intensity. d Responsivity and specific detectivity of the photodetector over a broad spectral range. e Comparison of the room temperature specific detectivity of the Gr/1Tʹ-MoTe2/Si Schottky junction device with other IR detectors 

lasers were periodically switched on and off, as shown in Fig. 4a. We believed that the photovoltaic effect could account for the pronounced photoresponse with sharp fall and rise edges rather than the thermal electric or bolometer effect<sup>30</sup> . In Fig. 4b, we fitted the light intensitydependent photocurrents with a power law (Iph∼AP<sup>θ</sup> , where Iph is the photocurrent, and θ determines the photoresponse to the power density), giving the power exponents of 0.81, 0.80, and 0.79 for 3.0, 4.6, and 10.6 μm, respectively, indicating the complex carrier recombination processes in the device<sup>34,35</sup> . Furthermore, the 

responsivity (R) and specific detectivity (D*) are evaluated by the formulas of 



<!-- Start of picture text -->
Iph Ilight � Idark<br>R ¼ ð1Þ<br>PS ¼ PS<br>f f i f f i f f i f f iffi<br>pAΔf<br>D � ¼ ð2Þ<br>NEP<br><!-- End of picture text -->

where Ilight and Idark, are the current under light illumination and in the dark, P, S, A, Δf, and NEP are light intensity, effective irradiated area, device area, 

Wu et al. Light: Science & Applications (2023) 12:5 

Page 8 of 12 

bandwidth, and noise equivalent power, respectively<sup>36</sup> . Figure 4c presents the calculated R under MIR illumination with various light intensities. R is found to decrease with increasing light intensity and reaches 0.115, 0.095, and 0.068 mA W<sup>−1</sup> at zero bias under 3.0, 4.6, and 10.6 µm illumination (0.5 mW cm<sup>−2</sup> ), respectively. The measured noise current density gives a value of 9.74 × 10<sup>−14</sup> A Hz<sup>−1/2</sup> at Δf = 1 Hz (Fig. S13). Hence, the room temperature D* is determined to be 4.75/3.92/ 2.80 × 10<sup>8</sup> Jones under 3.0/4.6/10.6 µm illumination. In addition, R and D* of the Schottky junction device are determined to be 526 mA W<sup>−1</sup> and 2.17 × 10<sup>12</sup> Jones under 980 nm illumination (Fig. S14), which are superior to that of photodetectors based on few-layer 2H-MoTe2 (24 mA W<sup>−1</sup> , 1.3 × 10<sup>9</sup> Jones)<sup>37</sup> , MoTe2 p-n junction (4.8 mA W<sup>−1</sup> )<sup>38</sup> , MoTe2/Graphene (1.55 × 10<sup>11</sup> Jones)<sup>39</sup> , the strain-engineered MoTe2 photodetector (0.5 A W<sup>−1</sup> )<sup>40</sup> , and 1T′-MoTe2 (96 mA W<sup>−1</sup> )<sup>41</sup> operating in NIR region. The R and D* of the photodetector in a wide wavelength range reveal an ultrabroadband photoresponse spectrum range up to LWIR of 10.6 μm (Fig. 4d), which is among the widest range for MoTe2-based heterostructure photodetectors, such as 2H-MoTe2/Si (300–1800 nm)<sup>42</sup> , PdSe2/MoTe2 (365–980 nm)<sup>43</sup> , MoTe2/ graphene (532–1064 nm)<sup>39</sup> , and MoTe2/MoS2 (550–1550 nm)<sup>34</sup> . It is expected that the use of other narrow bandgap semiconductors (such as HgCdTe, InGaAs, and Ge) as the substrates could effectively adjust the barrier heights of Schottky junctions, and make it possible to further improve the photodetection performance of the device with a detection range beyond 10.6 μm<sup>44</sup> . In addition, the photodetector has a large D* over 10<sup>8</sup> Jones in the MIR region, as summarized in Fig. 4e. The obtained room temperature D* is not only superior to InSb (8.1 × 10<sup>6</sup> Jones at 2.7 µm)<sup>45</sup> , Td-MoTe2 (9.1 × 10<sup>6</sup> Jones at 10.6 µm)<sup>24</sup> , b-AsP (2.02/1.61/1.06 × 10<sup>8</sup> Jones at 3.0/4.0/8.05 µm)<sup>16</sup> , HgCdTe (3 × 10<sup>8</sup> /6 × 10<sup>7</sup> Jones at 3.0/10 µm)<sup>46</sup> , TaAs (9 × 10<sup>7</sup> Jones at 10.29 µm)<sup>47</sup> , and the commercial thermistor bolometers (~10<sup>8</sup> Jones), but also comparable to Fe3O4 (4.9/5.2/ 7.4 × 10<sup>8</sup> Jones at 3.0/4.6/10.6 µm)<sup>48</sup> , PbSe (1.6 × 10<sup>9</sup> / 3.8 × 10<sup>8</sup> Jones at 3.0/4.5 µm)<sup>49</sup> , and PdSe2 (9.1 × 10<sup>8</sup> / 1.2 × 10<sup>9</sup> /1.1 × 10<sup>9</sup> Jones at 3.0/4.6/10.6 µm)<sup>50</sup> . 

Furthermore, the response speeds of the Schottky junction device under IR illumination are characterized. As shown in Fig. 5a, the photodetector exhibits stable and fast photoresponses to modulated laser diode illumination (λ = 980 nm) with switching frequencies of 1, 5, and 10 kHz at a duty ratio of 50%. A large 3-dB frequency (f3dB) of 10 kHz is achieved for the device, revealing its great capability of detecting fast-varying optical signals, even up to 50 kHz (Fig. S15). A short rising/falling time of 1.9/41.5 µs is obtained at f3dB of 10 kHz (Fig. 5b). As a matter of fact, the Gr/1Tʹ-MoTe2/Si Schottky junction 

photodetector can follow ultrafast short-pulsed signals (duty ratio of 0.1%) at switching frequencies of 1, 5, and 10 kHz with good stability and distinguishability (Fig. 5c). Under a single pulse at 10 kHz with a pulse width of 100 ns, the photodetector features a fast rising/falling time of 90 ns/11 µs, which is among the fastest for TMD/Si photodetectors<sup>35,51–58</sup> . The fast response speed of the photodetector could be attributed to the following aspects: (i) The type-II Weyl semimetal 1T′-MoTe2 layers with high carrier mobility possess a unique orthorhombic lattice structure with broken inversion symmetry, ensuring the rapid carrier transportation and thus reducing carrier recombination<sup>24</sup> . (ii) The large built-in electric field in the device plays an important role in facilitating the fast separation and transportation of the photogenerated carriers<sup>59</sup> . (iii) The vertically stacked heterostructure with top transparent graphene contact would shorten the transit time of the carriers and reduce the carrier recombination induced by the grain boundaries in the 2D MoTe2 layer, leading to a fast response speed<sup>42</sup> . The above reasons corporately result in the short response time of the photodetector. Besides, the longer fall time could be attributed to the existence of some defects and traps in MoTe2 layers and junction interface. The photo-excited carriers trapped by the defects and traps will be slowly released by turning off the light, resulting in a relatively longer falling time<sup>60</sup> . Furthermore, the response speeds of 41.6/96.2 µs and 80.6/103.1 µs are achieved under 1.55 and 2.2 μm light illumination, respectively (Fig. 5e, f), which are probably due to the lower carrier concentration generated under IR light illumination with longer wavelength<sup>61</sup> . Benefiting from the fast response speed of the detector, we explored its application of a new-concept visual demonstration in IR optical communication. As shown in Fig. S16a, the target information of “MoTe2” entered into a computer was converted to American Standard Code for Information Interchange (ASCII) codes and then was sent to a signal generator to drive an infrared laser of 1550 nm (C-band). Subsequently, the conversion of the modulated pulsed IR signals to electrical signals by the Gr/1Tʹ-MoTe2/Si Schottky junction device, transmitted to a terminal computer via an oscilloscope, produced the resulting ASCII codes of “MoTe2” (Fig. S16b). The perfect square waves matched well with the original input information, suggesting the great potential of the device for IR optical communication. 

Given the superior IR detection capability of the photodetector, the room temperature IR imaging was further explored with the Gr/1Tʹ-MoTe2/Si Schottky junction device. Figure 6a demonstrates a schematic of the imaging measurement system with an individual Gr/1Tʹ-MoTe2/Si device as a sensing pixel, from which the IR light signal passed through a hollow LWIR-patterned mask fixed on a 

Wu et al. Light: Science & Applications (2023) 12:5 

Page 9 of 12 



<!-- Start of picture text -->
a 1.0 f =1 kHz b f =10 kHz<br>1.0<br>0.5<br>0.0 0.8 τ r=1.9  μ s<br>0 1 2 3 4 5<br>1.0 f =5 kHz 0.6<br>0.5<br>0.4<br>0.0<br>0.0 0.5 1.0 1.5 2.0<br>1.0 f =10 kHz 0.2 τ f=41.5  μ s<br>0.5<br>0.0<br>0.0<br>0.0 0.2 0.4 0.6 0.8 1.0 0.14 0.16 0.18 0.20 0.22 0.24<br>Time (ms) Time (ms)<br>c 1.0 f =1 kHz d f =10 kHz<br>1.0<br>0.5<br>0.0 0.8 τ r=90 ns<br>0 1 2 3 4 5<br>f =5 kHz<br>0.6<br>0.5<br>0.4<br>0.0<br>0.0 0.2 0.4 0.6 0.8 1.0<br>0.5 f =10 kHz 0.2 τ f=11  μ s<br>0.0<br>0.0<br>0.0 0.1 0.2 0.3 0.4 0.5 0.24 0.26 0.28 0.30<br>Time (ms) Time (ms)<br>e f<br>1.0 1.55 μm 1.0 2.2 μm<br>0.8 τr=41.6 μs 0.8 τr=80.6 μs<br>0.6 0.6<br>0.4 0.4<br>0.2 τf=96.2 μs 0.2 τf=103.1 μs<br>0.0 0.0<br>1.0 1.2 1.4 1.6 1.8 1.0 1.2 1.4 1.6 1.8<br>Time (ms) Time (ms)<br>Photocurrent (a.u.)<br>Photoresponse (a.u.)<br>Photocurrent (a.u.) Photocurrent (a.u.)<br>Photocurrent (a.u.) Photocurrent (a.u.)<br><!-- End of picture text -->

Fig. 5 Response speed of the photodetector. a Photoresponse properties of the photodetector to 980 nm pulse signals with a duty ratio of 50%. b Rising and falling time at 10 kHz with a duty ratio of 50%. c Photoresponse properties of the device to 980 nm pulse signals with a duty ratio of 0.1%. d Rising and falling time at 10 kHz with a duty ratio of 0.1%. Response speeds of the device at e 1.55 and f 2.2 μm, respectively 

2D translation stage. Subsequently, the positiondependent photocurrent of the device was recorded by the software-programmed computer and then transformed to a corresponding photocurrent mapping image of “LWIR” patterns under 10.6 μm in the absence of cryogenic cooling. As shown in Fig. 6b, the imaging result of clear “LWIR” patterns (134 × 59 steps) with a large current contrast ratio over 10 and sharp edges is acquired at room temperature. Furthermore, the large-scale uniform 2D MoTe2 layer enables the fabrication of an 8 × 8 1Tʹ-MoTe2/Si Schottky junction device array for IR imaging application (Fig. 6c, d). Notably, the uniform 

distributions of the dark current and the photocurrent under 10.6 μm with tiny fluctuation, according to the current mappings results in Fig. S17, reveal the satisfactory performance uniformity of the device array. Upon MIR illumination, the large difference between the currents from exposed pixels and unexposed counterparts results in a high-resolution heart-shaped image with large current ratios of 100, 68, and 51 for 3.0, 4.6, and 10.6 μm laser illumination at room temperature, respectively. Such excellent room temperature imaging capability with good homogeneity of the device array certainly confirms its great promise for MIR imaging applications. 

Wu et al. Light: Science & Applications (2023) 12:5 

Page 10 of 12 



<!-- Start of picture text -->
a b<br>Detector Mask Chopper<br>Lens<br>Lens I (nA)<br>Laser 2.0<br>1.8<br>1.6<br>1.4<br>1.2<br>1.0<br>0.8<br>0.6<br>0.4<br>0.2<br>0.0<br>2D translation stage<br>c d<br>Infrared light<br>Mask<br>2 cm 0.5 cm 0.5 mm<br>I (nA) I (nA) I (nA)<br>8 e 7.0 8 f 5.0 8 g 4.0 4.0<br>7 6.0 7 7<br>4.0<br>6 5.0 6 6 3.0 3.0<br>5 4.0 5 3.0 5<br>4 3.0 4 2.0 4 2.0 2.0<br>32 2.01.0 32 1.0 32 1.0 1.0<br>1 3.0 μ m 0.0 1 4 . 6 μ m 0.0 1 10 . 6 μ m 0.0 0.0<br>1 2 3 4 5 6 7 8 1 2 3 4 5 6 7 8 1 2 3 4 5 6 7 8<br>10<br>20<br>30<br>40<br>50 Scanningsteps<br>Device array<br>2.0<br>1.8<br>1.6<br>1.4<br>1.2<br>1.0<br>0.8<br>0.6<br>0.4<br>0.2<br>120 0.0<br>80 100<br>60<br>40<br>20<br>Scanningsteps<br>Current(nA)<br><!-- End of picture text -->

Fig. 6 MIR imaging application of the photodetector. a A schematic of a single-pixel-based IR imaging system. b IR imaging of “LWIR” patterns under 10.6 μm at room temperature. c A schematic of IR imaging measurement based on devices array. d Photographs of an 8 × 8 1Tʹ-MoTe2/Si Schottky junction device array. The device area of each pixel cell is 200 × 200 μm<sup>2</sup> . e–g The imaging results of the “heart” pattern under 3.0, 4.6, and 10.6 μm, respectively 

The wafer-scale growth of the 2D MoTe2 layer compatible with Si technology shows great potential for nextgeneration on-chip Si CMOS systems with low-power consumption and low-cost production. 

### Discussion 

In summary, we demonstrated the vdW growth of wafer-scale 2D MoTe2 layers with controllable phases of 2H (semiconductor) and 1Tʹ (semimetal) via a thermalassisted tellurization method. Through in situ vdW growth of 1Tʹ-MoTe2 layers on a pre-patterned Si substrate, highquality 1Tʹ-MoTe2/Si 2D/3D vdW Schottky junction was fabricated to achieve broadband IR detection. Thanks to the 2D MoTe2 layers with few interface defects via the vdW epitaxial growth mode, the wide absorption of the type-II Weyl semimetal 1Tʹ-MoTe2 layer, and the highquality vertical junction with transparent graphene electrode, the Gr/1Tʹ-MoTe2/Si Schottky junction device has the capability of detecting an ultrawide light signal up to 10.6 μm at room temperature. This makes it one of the widest for 2D material-based photodetectors. Moreover, 

the device shows a large specific detectivity of 4.75–2.8 × 10<sup>8</sup> Jones in the range of 3.0–10.6 µm with a fast response time. The wafer-scale growth of 2D MoTe2 layers also enable the assembly of a photodetector array to achieve an excellent room temperature MIR imaging capability. Our work demonstrates a novel design concept for the fabrication of high-performance, uncooled broad IR photodetectors based on 2D layered materials. 

### Materials and methods 

#### Materials synthesis and characterization 

Wafer-scale 2D MoTe2 layers were fabricated via a thermal-assisted tellurization route. In detail, Mo precursor layers were first defined on pre-cleaned substrates by a magnetron sputtering system. Then, the Mo-coated substrates were placed on a quartz boat filled with Te powder (99.99%) at the center of a horizontal tube furnace. The tube was evacuated and filled with a gas mixture of Ar (95%) and H2 (5%) at 50 sccm. Afterward, the Mo samples and Te powder were heated to 700 °C. During the heating process, the MoTe2 layers can be produced by the transportation of 

Wu et al. Light: Science & Applications (2023) 12:5 

Page 11 of 12 

vaporized Te to the Mo samples. The prepared 2D MoTe2 layers were analyzed by XRD (RigakuSmart Lab), Raman spectrometry (Horiba HR800), AFM (Veeco Nanoscope V), a field-emission-gun scanning electron microscope (LEO 1530) attached with an EBSD detector (Oxford Instruments NordlysNano EBSD detector and AZtecHKL), a UV/Vis/ NIR spectrometer (PERKIN ELMER), STEM (JEOL JEMARM300F), and XPS (Thermo ESCALAB 250). 

#### Theoretical simulation 

Our first-principles calculations based on density functional theory were performed by the Vienna Ab initio Simulation Package (VASP). For the exchange-correlation functions, we employed the generalized gradient approximation (PBE-GGA) with projector augmented wave (PAW) potentials<sup>62–65</sup> . We adopted the zero damping DFT-D3 method of Grimme to describe van der Waals interactions<sup>66</sup> . The kinetic energy cutoff for the plane wave basis was set to 300 eV, and 8 × 8 × 2 (4 × 8 × 2) and 8 × 8 (4 × 8) meshes of k-space integration were used in the Brillouin zones of bulk and finite layer for 2H (1Tʹ) MoTe2, respectively. The finite-layer structures were simulated by a periodic slab model with a vacuum thickness of 15 Å to avoid periodic slab interactions. All atoms were allowed to relax until all residual force components were less than 0.01 eV. 

The spatial distributions of the electric field intensity within the 1Tʹ-MoTe2/Si Schottky junction were investigated by the radio frequency (RF) module of COMSOL Multiphysics through an exact full-field electromagnetic calculation in the frequency domain based on Maxwell’s equations. 

the device was detected by a lock-in amplifier when the mask moved. 

##### Acknowledgements 

This work was financially supported by the National Natural Science Foundation of China (Nos. U2004165, U22A20138, 52225303, 91833303, and 12174349), Natural Science Foundation of Henan Province, China (No. 202300410376), and Henan provincial key science and technology research projects (No. 212102210130). We also thank the support from Collaborative Innovation Center of Suzhou Nano Science & Technology. 

##### Author details 

> 1School of Physics and Microelectronics, Key Laboratory of Material Physics Ministry of Education, Zhengzhou University, Zhengzhou, Henan 450052, China.<sup>2</sup> Department of Electrical and Computer Engineering, University of California San Diego, La Jolla, CA 92093, USA.<sup>3</sup> Institute of Nanophotonics, Jinan University, Guangzhou, Guangdong 511443, China.<sup>4</sup> Institute of Functional Nano and Soft Materials (FUNSOM), Jiangsu Key Laboratory for Carbon-Based Functional Materials and Devices, Soochow University, Suzhou, Jiangsu 215123, China 

##### Author contributions 

D.W. and L.Z. conceived the project and wrote the manuscript. C.G. synthesized the material and fabricated the devices. X.R. conducted the theoretical calculations. Z.S. carried out the optical characterizations. L.W. and Q.C. fabricated the device array. M.Z. helped with the data analysis. X.L., C.-X.S., and J.J. supervised the projects and development of the manuscript. 

##### Data availability 

The data that support the findings of this study are available from the corresponding author upon reasonable request. 

##### Conflict of interest 

The authors declare no competing interests. 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41377-022-01047-5. 

Received: 9 September 2022 Revised: 21 November 2022 Accepted: 25 November 2022 



#### Device fabrication and characterization 

A SiO2 window (2 mm × 2 mm) was first defined on a SiO2 (300 nm)/Si (n-type, resistivity of 1–10 Ω cm) wafer through a wet etching process. Then, the 1Tʹ-MoTe2 layer was directly deposited on a pre-patterned SiO2/Si wafer to construct a 1Tʹ-MoTe2/Si Schottky junction device. Afterward, the Au (50 nm) and In-Ga alloy electrodes were defined on the MoTe2 layer and the back side of the Si wafer, respectively. Then a monolayer graphene film on the top surface of MoTe2 was chosen as the transparent electrode. The electrical and optoelectrical properties of the devices were investigated by a Keithley 4200-SCS (Tektronix), an oscilloscope (DPO2012B, Tektronix), and light sources with various wavelengths. The noise current of the device was measured by a semiconductor parameter analyzer system (Fs-pro, Primarius). Imaging measurements were performed with a lab-built imaging system. The hollow mask with “LWIR” patterns was mounted on a 2D motorized positioning system, programmed to move in a plane with each step of 0.5 mm. The device was located behind the mask. The position-dependent current of 

##### References 

1. Liu, C. Y. et al. Silicon/2D-material photodetectors: from near-infrared to midinfrared. Light Sci. Appl. 10, 123 (2021). 

2. Wang, H. Y. et al. Van der Waals integration based on two‐dimensional materials for high‐performance infrared photodetectors. Adv. Funct. Mater. 31, 2103106 (2021). 

3. Rao, G. F. et al. Two-dimensional heterostructure promoted infrared photodetection devices. InfoMat 1, 272–288 (2019). 

4. Wang, P. et al. Sensing infrared photons at room temperature: from bulk materials to atomic layers. Small 15, 1904396 (2019). 

5. Rogalski, A. Toward third generation HgCdTe infrared detectors. J. Alloy. Compd. 371, 53–57 (2004). 

6. Wang, J. L. et al. Recent progress on localized field enhanced two-dimensional material photodetectors from ultraviolet—visible to infrared. Small 13, 1700894 (2017). 

7. Sizov, F. Terahertz radiation detectors: the state-of-the-art. Semiconductor Sci. Technol. 33, 123001 (2018). 

8. Rogalski, A. New material systems for third generation infrared photodetectors. Opto-Electron. Rev. 16, 458–482 (2008). 

9. Tang, X. et al. Dual-band infrared imaging using stacked colloidal quantum dot photodiodes. Nat. Photonics 13, 277–282 (2019). 

10. Chen, Z. F. et al. Synergistic effects of plasmonics and electron trapping in graphene short-wave infrared photodetectors with ultrahigh responsivity. ACS Nano 11, 430–437 (2017). 

Wu et al. Light: Science & Applications (2023) 12:5 

Page 12 of 12 

11. Yuan, S. F. et al. Air-stable room-temperature mid-infrared photodetectors based on hBN/Black arsenic phosphorus/hBN heterostructures. Nano Lett. 18, 3172–3179 (2018). 

12. Bullock, J. et al. Polarization-resolved black phosphorus/molybdenum disulfide mid-wave infrared photodiodes with high detectivity at room temperature. Nat. Photonics 12, 601–607 (2018). 

13. Li, N. et al. Solution-processable infrared photodetectors: materials, device physics, and applications. Mater. Sci. Eng. R. 146, 100643 (2021). 

14. Guo, J. S. et al. High-performance silicon-graphene hybrid plasmonic waveguide photodetectors beyond 1.55 μm. Light Sci. Appl. 9, 29 (2020). 

15. Konstantatos, G. et al. Ultrasensitive solution-cast quantum dot photodetectors. Nature 442, 180–183 (2006). 

16. Long, M. S. et al. Room temperature high-detectivity mid-infrared photodetectors based on black arsenic phosphorus. Sci. Adv. 3, e1700589 (2017). 

17. Guo, Q. S. et al. Black phosphorus mid-infrared photodetectors with high gain. Nano Lett. 16, 4648–4655 (2016). 

18. Yan, J. et al. Dual-gated bilayer graphene hot-electron bolometer. Nat. Nanotechnol. 7, 472–478 (2012). 

19. Choi, S. H. et al. Large-scale synthesis of graphene and other 2D materials towards industrialization. Nat. Commun. 13, 1484 (2022). 

20. Akinwande, D. et al. Graphene and two-dimensional materials for silicon technology. Nature 573, 507–518 (2019). 

21. Zhou, L. et al. Large-area synthesis of high-quality uniform few-layer MoTe2. J. Am. Chem. Soc. 137, 11892–11895 (2015). 

22. Wang, Z. J. et al. MoTe2: a type-II weyl topological metal. Phys. Rev. Lett. 117, 056805 (2016). 

23. Huang, L. et al. Spectroscopic evidence for a type II Weyl semimetallic state in MoTe2. Nat. Mater. 15, 1155–1160 (2016). 

24. Lai, J. W. et al. Anisotropic broadband photoresponse of layered type-II weyl semimetal MoTe2. Adv. Mater. 30, 1707152 (2018). 

25. Empante, T. A. et al. Chemical vapor deposition growth of few-layer MoTe2 in the 2H, 1T’, and 1T phases: tunable properties of MoTe2 films. ACS Nano 11, 900–905 (2017). 

26. Liu, J. et al. Semimetals for high-performance photodetection. Nat. Mater. 19, 830–837 (2020). 

27. Wang, L. et al. Hybrid Dirac semimetal-based photodetector with efficient lowenergy photon harvesting. Light Sci. Appl. 11, 53 (2022). 

28. Jiao, H. X. et al. HgCdTe/black phosphorus van der Waals heterojunction for high-performance polarization-sensitive midwave infrared photodetector. Sci. Adv. 8, eabn1811 (2022). 

29. Jariwala, D., Marks, T. J. & Hersam, M. C. Mixed-dimensional van der Waals heterostructures. Nat. Mater. 16, 170–181 (2017). 

30. Zeng, L. H. et al. Van der Waals epitaxial growth of mosaic-like 2D platinum ditelluride layers for room-temperature mid-infrared photodetection up to 10.6 µm. Adv. Mater. 32, 2004412 (2020). 

31. Wang, Y. et al. Structural phase transition in monolayer MoTe2 driven by electrostatic doping. Nature 550, 487–491 (2017). 

32. Xu, X. L. et al. Millimeter-scale single-crystalline semiconducting MoTe2 via solid-to-solid phase transformation. J. Am. Chem. Soc. 141, 2128–2134 (2019). 

33. Yoo, Y. et al. In-plane 2H-1T’ MoTe2 homojunctions synthesized by fluxcontrolled phase engineering. Adv. Mater. 29, 1605461 (2017). 

34. Chen, Y. et al. High-performance photovoltaic detector based on MoTe2/MoS2 van der Waals heterostructure. Small 14, 1703293 (2018). 

35. Xiao, P. et al. Solution-processed 3D RGO-MoS2/pyramid Si heterojunction for ultrahigh detectivity and ultra-broadband photodetection. Adv. Mater. 30, 1801729 (2018). 

36. Fang, Y. J. et al. Accurate characterization of next-generation thin-film photodetectors. Nat. Photonics 13, 1–4 (2019). 

37. Huang, H. et al. Highly sensitive visible to infrared MoTe2 photodetectors enhanced by the photogating effect. Nanotechnology 27, 445201 (2016). 

38. Bie, Y. Q. et al. A MoTe2-based light-emitting diode and photodetector for silicon photonic integrated circuits. Nat. Nanotechnol. 12, 1124–1129 (2017). 

39. Yu, W. Z. et al. Near-infrared photodetectors based on MoTe2/graphene heterostructure with high responsivity and flexibility. Small 13, 1700268 (2017). 

40. Maiti, R. et al. Strain-engineered high-responsivity MoTe2 photodetector for silicon photonic integrated circuits. Nat. Photonics 14, 578–584 (2020). 

41. Kim, D. et al. Two-dimensional phase-engineered 1T′- and 2H-MoTe2-based near-infrared photodetectors with ultra-fast response. J. Alloy. Compd. 789, 960–965 (2019). 

42. Lu, Z. J. et al. Ultrahigh speed and broadband few-layer MoTe2/Si 2D-3D heterojunction-based photodiodes fabricated by pulsed laser deposition. Adv. Funct. Mater. 30, 1907951 (2020). 

43. Pi, L. J. et al. Broadband convolutional processing using band-alignmenttunable heterostructures. Nat. Electron. 5, 248–254 (2022). 

44. Wang, Y. et al. Fast uncooled mid-wavelength infrared photodetectors with heterostructures of van der Waals on epitaxial HgCdTe. Adv. Mater. 34, 2107772 (2022). 

45. Li, X. X. et al. Broadband InSb/Si heterojunction photodetector with graphene transparent electrode. Nanotechnology 31, 315204 (2020). 

46. Piotrowski, J. & Rogalski, A. Uncooled long wavelength infrared photon detectors. Infrared Phys. Technol. 46, 115–131 (2004). 

47. Chi, S. M. et al. A wide-range photosensitive weyl semimetal single crystal— TaAs. Adv. Mater. 30, 1801372 (2018). 

48. Yin, C. J. et al. Ultrabroadband photodetectors up to 10.6 µm based on 2D Fe3O4 nanosheets. Adv. Mater. 32, 2002237 (2020). 

49. Sun, X. G. et al. Research status of lead selenide thin films used for infrared detectors. Infrared Technol. 38, 1005–1019 (2016). 

50. Long, M. S. et al. Palladium diselenide long-wavelength infrared photodetector with high sensitivity and stability. ACS Nano 13, 2511–2519 (2019). 

51. Wu, D. et al. A defect-induced broadband photodetector based on WS2/ pyramid Si 2D/3D mixed-dimensional heterojunction with a light confinement effect. Nanoscale 13, 13550–13557 (2021). 

52. Wu, D. et al. Mixed-dimensional PdSe2/SiNWA heterostructure based photovoltaic detectors for self-driven, broadband photodetection, infrared imaging and humidity sensing. J. Mater. Chem. A 8, 3632–3642 (2020). 

53. Wu, E. P. et al. In situ fabrication of 2D WS2/Si type-ii heterojunction for selfpowered broadband photodetector with response up to mid-infrared. ACS Photonics 6, 565–572 (2019). 

54. Zeng, L. H. et al. Ultrafast and sensitive photodetector based on a PtSe2/silicon nanowire array heterojunction with a multiband spectral response from 200 to 1550 nm. NPG Asia Mater. 10, 352–362 (2018). 

55. Wu, D. et al. Photovoltaic high-performance broadband photodetector based on MoS2/Si nanowire array heterojunction. Sol. Energy Mater. Sol. Cells 182, 272–280 (2018). 

56. Wang, L. et al. MoS2/Si heterojunction with vertically standing layered structure for ultrafast, high-detectivity, self-driven visible-near infrared photodetectors. Adv. Funct. Mater. 25, 2910–2919 (2015). 

57. Zeng, L. H. et al. Multilayered PdSe2/perovskite schottky junction for fast, selfpowered, polarization-sensitive, broadband photodetectors, and image sensor application. Adv. Sci. 6, 1901134 (2019). 

58. Tong, X. W. et al. Direct tellurization of Pt to synthesize 2D PtTe2 for highperformance broadband photodetectors and NIR image sensors. ACS Appl. Mater. Interfaces 12, 53921–53931 (2020). 

59. Wu, D. et al. Highly sensitive solar-blind deep ultraviolet photodetector based on graphene/PtSe2/β-Ga2O3 2D/3D schottky junction with ultrafast speed. Nano Res. 14, 1973–1979 (2021). 

60. Jie, J. S. et al. Photoconductive characteristics of single-crystal CdS nanoribbons. Nano Lett. 6, 1887–1892 (2006). 

61. Wu, D. et al. Ultrabroadband and high-detectivity photodetector based on WS2/Ge heterojunction through defect engineering and interface passivation. ACS Nano 15, 10119–10129 (2021). 

62. Kresse, G. & Furthmüller, J. Efficient iterative schemes for ab initio total-energy calculations using a plane-wave basis set. Phys. Rev. B 54, 11169–11186 (1996). 

63. Blöchl, P. E. Projector augmented-wave method. Phys. Rev. B 50, 17953–17979 (1994). 

64. Kresse, G. & Joubert, D. From ultrasoft pseudopotentials to the projector augmented-wave method. Phys. Rev. B 59, 1758–1775 (1999). 

65. Perdew, J. P., Burke, K. & Ernzerhof, M. Generalized gradient approximation made simple. Phys. Rev. Lett. 77, 3865–3868 (1996). 

66. Grimme, S. et al. A consistent and accurate ab initio parametrization of density functional dispersion correction (DFT-D) for the 94 elements H-Pu. J. Chem. Phys. 132, 154104 (2010). 

