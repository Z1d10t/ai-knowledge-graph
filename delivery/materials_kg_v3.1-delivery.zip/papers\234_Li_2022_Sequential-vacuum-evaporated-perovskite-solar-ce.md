# Sequential vacuum-evaporated perovskite solar cells with more than 24% efficiency

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Science Advances |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 278 |
| 作者 | Hang Li, Jun-Jie Zhou, Liguo Tan, Minghao Li, Chao Jiang, Siyang Wang, Xing Zhao, Yue Liu et al. |
| DOI | 10.1126/sciadv.abo7422 |
| 源文件 | 025_Li_2022_Sequential-vacuum-evaporated-perovskite-solar-ce.pdf |

---
SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

#### **P HYSICS** 

# **Sequential vacuum-evaporated perovskite solar cells with more than 24% efficiency** 

**Hang Li**<sup>**1**</sup> **, Junjie Zhou**<sup>**1**</sup> **, Liguo Tan**<sup>**1**</sup> **, Minghao Li**<sup>**1**</sup> **, Chaofan Jiang**<sup>**1**</sup> **, Siyang Wang**<sup>**1**</sup> **, Xing Zhao**<sup>**1**</sup> **, Yue Liu**<sup>**1**</sup> **, Yu Zhang**<sup>**1**</sup> **, Yiran Ye**<sup>**1**</sup> **, Wolfgang Tress**<sup>**2**</sup> **, Chenyi Yi**<sup>**1**</sup> ***** 

**Vacuum evaporation is promising for the high-throughput fabrication of perovskite solar cells (PSCs) because of its solvent-free characteristic, precise control of film thickness, and compatibility with large-scale production. Nevertheless, the power conversion efficiency (PCE) of PSCs fabricated by vacuum evaporation lags behind that of solution-processed PSCs. Here, we report a Cl-containing alloy–mediated sequential vacuum evaporation approach to fabricate perovskite films. The presence of Cl in the alloy facilitates organic ammonium halide diffusion and the subsequent perovskite conversion reaction, leading to homogeneous pinhole-free perovskite films with few defects. The resulting PSCs yield a PCE of 24.42%, 23.44% (certified 22.6%), and 19.87% for 0.1, 1.0, and 14.4 square centimeters (mini-module, aperture area), respectively. The unencapsulated PSCs show good stability with negligible decline in performance after storage in dry air for more than 4000 hours. Our method provides a reproducible approach for scalable fabrication of large-area, high-efficiency PSCs and other perovskitebased optoelectronics.** 

Copyright © 2022 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works. Distributed under a Creative Commons Attribution NonCommercial License 4.0 (CC BY-NC). 

#### **INTRODUCTION** 

Metal halide hybrid perovskite solar cells (PSCs) have the advantages of high power conversion efficiency (PCE) and low cost and have received great attention from the academia and industry ( _1_ ). Largearea PSC fabrication methods compatible with industrial applications must be developed to enable commercialization. However, most of the reported high-efficiency PSCs were prepared by spin coating, which is only suitable for laboratory-scale devices ( _2_ ). Moreover, solvents used in the solution process may be detrimental to the underlying functional layers and are harmful to the environment ( _3_ ). In contrast, these drawbacks can be avoided by using vacuum evaporation ( _4_ , _5_ ). The precursors can be evenly and uniformly deposited on substrates, and the film thickness can be precisely controlled during the vacuum evaporation process, which is compatible with scalable fabrication ( _6_ ). 

However, to date, the efficiency of evaporated PSCs lags behind that of solution-processed PSCs ( _7_ – _13_ ). Although a PCE of 15.4% was achieved with MAPbI3− _x_ Cl _x_ by coevaporation as early as 2013 ( _14_ ), a PCE of 20.28% has been reached until recently with coevaporated MAPbI3 ( _15_ ). Compared with the coevaporation process, the layer-by-layer sequential deposition method avoids the risk of cross-contamination by evaporating lead halide and organic ammonium salt separately in different vacuum chambers. Recently, the highest PCE of 21.32% (0.09 cm<sup>2</sup> ) was achieved by sequential deposition ( _16_ ). However, it is still much lower than the highest PCE (25.7%) of solution-processed PSCs ( _17_ ). Therefore, it is of vital importance to develop a vacuum thermal evaporation method for fabricating PSCs with high efficiency. 

Here, we report a Cl-alloy–mediated sequential vacuum deposition method for fabricating high-efficiency PSCs. We evaporated cesium iodide (CsI), lead iodide (PbI2), and lead chloride (PbCl2) to create a composite precursor film on which formamidinium iodide 

> 1State Key Laboratory of Power System, Department of Electrical Engineering, Tsinghua University, Beijing 100084, China.<sup>2</sup> Institute of Computational Physics (ICP), ZHAW School of Engineering, Wildbachstr. 21, Winterthur 8400, Switzerland. 

> *Corresponding author. Email: yicy@mail.tsinghua.edu.cn, yicy@tsinghua.edu.cn 

(FAI) molecules were deposited under precise control. The Cl-alloy– mediated vacuum deposition method can produce perovskite films with high crystallinity and homogeneity. Small-area devices (0.1 cm<sup>2</sup> ) achieved a champion PCE of 24.42% (Fig. 1A), and the corresponding 1-cm<sup>2</sup> PSCs exhibited a champion PCE of 23.44% (certified PCE of 22.6%). The evaporated PSCs show good stability with negligible decline in device performance after storage in dry air for more than 4000 hours. Moreover, the unencapsulated devices maintained 97% of their initial PCE after 1300 hours of storage in ambient air at a humidity of 35% and maintained 92% of the initial PCE after 450 hours of maximum power point (MPP) tracking under continuous light irradiation. Although the mechanisms of chloride additives in solutionprocessed perovskite films have been widely studied ( _18_ – _20_ ), the crystallization process of vacuum-evaporated perovskite is a solidstate reaction. Substantial differences between the solid-state reaction and liquid reaction are in the diffusion rates, crystallization dynamics, and phase transition of perovskite ( _21_ – _23_ ). Therefore, we systematically studied the role of chlorine in the vacuum deposition method. We found that by adding a certain amount of chlorine to the precursor film, the formed PbI2-alloy (Cs0.05PbI2.05− _x_ Cl _x_ ) film shows a stronger degree of preferential orientation and higher crystallinity. Meanwhile, the chlorine incorporated into the lead iodide lattice accelerates the diffusion of ammonium salt, facilitating the crystallization of the perovskite. Our findings lay a solid foundation for scalable fabrication of large-area and high-efficiency PSCs. 

#### **RESULTS** 

Figure 1B illustrates the procedure of the Cl-containing alloy– mediated sequential vacuum deposition process. First, a highly uniform lead halide precursor film was obtained by coevaporating PbI2, PbCl2, and CsI. Next, a certain amount of FAI was deposited on the precursor film and annealed at 170°C in ambient air. The high annealing temperature and humidity accelerate the diffusion of ammonium salt into lead halide and promote the volatilization of chlorine ( _24_ , _25_ ). A highly uniform pinhole-free black-phase film was obtained. To identify the composition of the perovskite, we 

**1 of 8** 

Li _et al_ ., _Sci. Adv._ **8** , eabo7422 (2022)     15 July 2022 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 1. Lead halide precursor film characterizations.** ( **A** ) Champion efficiencies of thermally evaporated PSCs from 2013 to 2022. The star marks the PCE reported in this work. ( **B** ) Simplified scheme presenting the Cl-containing alloy–mediated sequential vacuum deposition approach. ( **C** ) X-ray diffraction (XRD) patterns of Cl-alloy–mediated precursor film (red) and the Ref precursor film (black). a.u., arbitrary units. ( **D** and **E** ) Top-view SEM images of (D) Cl-alloy–mediated precursor film and (E) the Ref precursor film. ( **F** ) Azimuth integration at _q_ ≈ 0.91 Å<sup>−1</sup> for lead halide films. ( **G** and **H** ) GIWAXS spectra of (G) Cl-alloy–mediated precursor film and (H) Ref film. 

performed inductively coupled plasma mass spectrometry (ICP-MS), and the composition was determined to be Cs0.05FA0.95PbI3. 

### **Unveiling the role of chlorine in lead halide precursor films** 

Fine control of the crystallization of the lead halide precursor film is of vital importance to enhancing the quality of the final perovskite film ( _26_ ). The Cl-alloyed lead halide precursor film has a smoother surface along with higher crystallinity and vertical face-on orientation. Compared with the Ref film with a weak diffraction signal at 12.62° corresponding to the (001) planes of PbI2, the PbCl2-alloyed film exhibits a 10-fold increased intensity (Fig. 1C and fig. S2), suggesting a stronger preferred orientation along the _c_ axis. Moreover, a peak shift toward higher angles is observed, which can be attributed to a slightly shrinking lattice after PbCl2 incorporation. We also compared the PbCl2-alloyed film with pure phase PbCl2 (fig. S3) and found no PbCl2 phase in the PbCl2-alloyed film. Namely, an alloy composed of PbI2, PbCl2 and CsI forms, and chlorine serves as a substitute for iodine to form a Cs0.05PbI2.05- _x_ Cl _x_ precursor. Topview scanning electron microscopy (SEM) images (Fig. 1, D and E) revealed that the incorporation of chlorine also resulted in a change in the morphology. Atomic force microscopy (AFM) revealed that the PbCl2-alloyed film had a smoother surface with a root mean 

square (RMS) roughness of 4.87 compared with that of Ref at 9.11 (fig. S4), which indicates that the PbCl2-alloyed film has a more condensed and smoother surface and can be a better template for subsequent perovskite formation. 

To further investigate the effect of chlorine on the crystal orientation of the lead halide precursor, we performed grazing incidence wide-angle x-ray scattering (GIWAXS). Figure 1 (G and H) depicts that both the Ref and PbCl2-alloyed films exhibit a diffused (001) ring, indicating the presence of PbI2. However, as shown by the azimuthal integration of the PbI2 diffraction ring (Fig. 1F), the Ref film exhibits peaks at ~110° and ~69°, which indicates a mixed face/edge-on orientation, representing a typically disordered crystal growth ( _27_ ). In contrast, the only pole figure of the azimuth angle is at 92° without any noticeable peaks along the same rings in PbCl2-alloyed films, which indicates a highly vertical face-on orientation in PbCl2-alloyed films, yielding a better orientation and crystallinity ( _26_ ). Schematic illustrations of the chlorine-doped film and Ref are depicted in fig. S5. 

### **Revealing the crystallization mechanism of vacuum-deposited perovskite** 

High-quality perovskite films produced by PbCl2 modification are related to the diffusion kinetics of the ammonium salt and crystal 

**2 of 8** 

Li _et al_ ., _Sci. Adv._ **8** , eabo7422 (2022)     15 July 2022 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

growth dynamics ( _28_ ). The incorporated Cl can accelerate the solidstate diffusion of organic ammonium halide salt, facilitate the perovskite phase transition from the  phase to the  phase, and increase the crystallinity of the perovskite film. To unveil the orientation of crystals during growth with different annealing times, we deposited an appropriate amount of FAI on the Ref film and PbCl2-alloyed film, and operando GIWAXS tests were performed. Before annealing, we probed the near-surface and full-depth diffractions using x-ray incident angles of 0.1° and 2°. No obvious signal was observed at 0.1° (fig. S6), indicating the absence of a crystalline phase at the top surface of the film before annealing, and we inferred it to be the formation of an amorphous phase by the excessive FAI on top ( _29_ ). For the incident angle of 2°, several different diffraction signals appeared. As displayed in Fig. 2 (A and F), a PbI2 signal near _q_ ≈ 0.91 Å<sup>−1</sup> and an  phase perovskite signal near 

_q_ ≈ 1.00 Å<sup>−1</sup> appeared, indicating that partial ammonium salt had penetrated into the lead halide layer and that the perovskite phase had formed. Moreover, a yellow  phase at _q_ ≈ 0.85 Å<sup>−1</sup> was observed, probably because of the moisture-induced phase transition from  to  in ambient air, which is inevitable during transport of the sample to the test laboratory ( _25_ ). Another two phases were observed at _q_ ≈ 0.47 Å<sup>−1</sup> and 0.71 Å<sup>−1</sup> , which we speculated to be two different adduct phases in the form of (FAX) _x_ -FAPbI3 (X = Cl and I) ( _30_ – _32_ ). The appearance of adduct phases illustrates that excessive FAI molecules have penetrated into the lead halide lattice and formed intermediate phases with larger lattice parameters. 

To observe the diffusion and conversion reaction process more clearly, we carried out operando GIWAXS of the PbCl2-alloyed and Ref perovskite films at a lower annealing temperature of 130°C for 10 min before raising the annealing temperature to 170°C. The 



**Fig. 2. Crystallization dynamics of Cl-alloy–mediated perovskite films.** The Cl-alloy–mediated film and the Ref film were annealed at 130°C for 10 min before increasing to 170°C for 15 min for the operando GIWAXS test. ( **A** to **E** ) Operando GIWAXS patterns of Cl-alloy–mediated film with different annealing times at an incident angle of 2°: (A) without annealing, (B) 130°C for 1 min, (C) 130°C for 3 min, (D) 170°C for 2 min, and (E) 170°C for 15 min. ( **F** to **J** ) Operando GIWAXS patterns of the Ref film with different annealing times at an incident angle of 2°: (F) without annealing, (G) 130°C for 1 min, (H) 130°C for 3 min, (I) 170°C for 2 min, and (J) 170°C for 15 min. 

**3 of 8** 

Li _et al_ ., _Sci. Adv._ **8** , eabo7422 (2022)     15 July 2022 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

results are shown in the videos (movies S1 and S2) and Fig. 2. For the PbCl2-alloyed film, as the annealing time was prolonged, the diffraction signals of the  phase at _q_ ≈ 0.85 Å<sup>−1</sup> vanished after annealing at 130°C for 1 min (Fig. 2B), indicating a phase transition from the  phase to the  phase. When further increasing the annealing time, the PbI2 phase at _q_ ≈ 0.92 Å<sup>−1</sup> weakened gradually and disappeared after annealing at 130°C for 3 min (Fig. 2C), implying that there existed no lead halide in the film and that all lead atoms had formed [PbI6]<sup>4−</sup> octahedral structures. By comparison of the Ref film, as shown in Fig. 2 (G and H), the PbI2 phase vanished at 5 min, and the  phase vanished after annealing for 6 min, substantially longer than that of the PbCl2-alloyed film. The operando GIWAXS test demonstrates that chlorine in the precursor film accelerates the diffusion of organic ammonium iodide into the lead iodide lattice, thus reducing the disappearance time of lead iodide. Moreover, chlorine also facilitates the conversion from the  phase to the  phase. In addition, a peak shift from _q_ ≈ 1.012 Å<sup>−1</sup> to _q_ ≈ 1.005 Å<sup>−1</sup> was observed by the Grazing incidence x-ray diffraction test when the PbCl2- alloyed perovskite film was annealed at 130°C (fig. S7), indicating the volatilization of chlorine in the early stage of annealing. Although annealed at 130°C for a sufficiently long time, two adduct phases at _q_ ≈ 0.47 Å<sup>−1</sup> and 0.71 Å<sup>−1</sup> still existed in both films, suggesting a much higher energy barrier for the conversion from adduct phases to the  phase. 

When the annealing temperature was raised to 170°C, the adduct phases in the PbCl2-alloy–mediated film disappeared gradually, and after annealing at 170°C for 2 min, no signal was observed at _q_ ≈ 0.47 Å<sup>−1</sup> and 0.71 Å<sup>−1</sup> , indicating the complete conversion from the adduct phases to the  phase (Fig. 2D). In contrast, the Ref film took as long as 15 min to complete the whole conversion (Fig. 2J). The conversion from (FAX) _x_ -FAPbI3 (X = Cl and I) to FAPbI3 requires the volatilization of ammonium salt, and the difference in conversion speed is likely attributed to the higher vapor pressure of FACl compared with FAI, which is confirmed by the thermogravimetric analysis (TGA) results (fig. S8). When the annealing temperature is as high as 170°C, chlorine is easier to volatilize in the form of FACl. For the Ref film, the relatively low vapor pressure of FAI makes it much more difficult to convert from (FAI) _x_ -FAPbI3 to FAPbI3. 

As the annealing time at 170°C was prolonged, a PbI2 signal appeared again in the PbCl2-alloy–mediated film compared with no emergence of the PbI2 signal in the Ref film. Furthermore, difference in the orientation of perovskite grains was observed after annealing for 15 min. As displayed in Fig. 2 (E and J), it is obvious that the (100) phase of the PbCl2 alloy–mediated film exhibits a sharp peak in the narrow azimuthal angle range between 80° and 100°, indicating a vertically oriented face-on crystalline perovskite. For the Ref film, a more random orientation was observed at azimuthal angles ranging from 50° to 100°, suggesting a mixed face/edge-on orientation, which is not favorable for charge transfer inside the bulk perovskite ( _33_ ). 

To further understand the transformation during the annealing process, we performed TGA and differential scanning calorimetry (fig. S9) by using the corresponding powders. We found that for the Ref composition, the weight loss appeared at 240°, 296°, and 340°C. For the PbCl2-alloyed composition, the weight loss appeared at 202°, 210°, 287°, and 340°C. We attribute the slight weight loss at 202°C to the volatilization of FACl and 340°C to the decomposition of Cs _x_ FA1− _x_ PbI3. In addition, it is obvious that two decomposition 

temperatures at 240° and 296°C of pure iodide composition are decreased to 210° and 287°C for the Cl-alloyed composition, suggesting that the incorporation of chlorine facilitates the volatilization of excess FAX (X = Cl and I), accelerating the crystallization process of the perovskite. 

To reveal the perovskite growth rate and crystallization process of the PbCl2 alloy–mediated film, we monitored vacuum-deposited perovskite film growth by SEM. Top-view SEM images revealed that irregular porous clusters exist on the surface of the Ref film before annealing (fig. S10, D and E), which is likely to be the amorphous phase on the surface of the perovskite. Compared with the Ref film, the PbCl2 alloy–mediated film showed a relatively smooth morphology before annealing and after annealing at 130°C for 1 min (fig. S10, A and B). The grains begin to grow and form doughnutshaped grains with holes in the middle, which is remarkably different from the Ref film. 

As we raised the temperature to 170°C and annealed for 1 min, the PbCl2-alloy–mediated film had a larger grain size compared with that of Ref (fig. S10, C and F). When the annealing time is prolonged to 15 min, the grain size of Ref increases slightly (Fig. 3B). In contrast, we found that the grain size of the PbCl2 alloy–mediated film continued to grow (Fig. 3A), which could be attributed to the accelerated crystal growth rate. The resulting PbCl2 alloy–mediated film had a larger grain size of 2.11 ± 0.3 m compared with that of Ref at 1.25 ± 0.34 m (fig. S11). Grain boundaries in perovskite films exhibit optoelectronic properties different from those of the bulk ( _34_ ). The incorporation of chlorine significantly reduces the grain boundaries, which can endow PSCs with higher efficiency because of the reduced number of defects and thus suppressed Shockley-Read-Hall (SRH) recombination. The reduction of grain boundaries also improves the perovskite homogeneity with respect to its optoelectronic properties ( _35_ ). Furthermore, the PbCl2 alloy–mediated film exhibited a lower surface roughness with an RMS roughness of 20.2 compared with that of Ref at 32.1 (Fig. 3, E and F), which indicates that the incorporation of chlorine contributes to a smoother perovskite/ hole-transport layer interface. 

Moreover, with the increasing annealing time, we observed the fragmentation of partial perovskite grains. The bright spots in the fragmentation area are probably lead halide crystals as shown by the SEM images (fig. S12), indicating the decomposition of perovskite on top of the interface, which is in good agreement with the x-ray diffraction (XRD) (fig. S14) and operando GIWAXS patterns (Fig. 2). The lead halide produced by decomposition is likely to passivate the grain boundaries ( _36_ ) and thus suppress nonradiative recombination. 

### **Probing trap densities related to SRH recombination** 

Polycrystalline films usually contain a high density of defects, which play a critical role in the process of SRH recombination ( _37_ , _38_ ), heavily influencing the resulting device PCE and long-term stability ( _39_ ). Compared with the Ref device, an increased electroluminescence (EL) intensity with an emission peak located at ~810 nm was observed in the device based on the PbCl2-alloyed perovskite film (fig. S15), indicating reduced nonradiative recombination. The external quantum efficiency of EL (EL-EQE) is shown as a function of the injection current in fig. S16. The PbCl2-alloy–mediated PSC exhibits a 10-fold increase compared with the Ref PSC at a current density of 25 mA cm<sup>−2</sup> , demonstrating that the defects related to nonradiative recombination losses were significantly suppressed in chlorine-mediated perovskite. On the basis of these EL data, we 

**4 of 8** 

Li _et al_ ., _Sci. Adv._ **8** , eabo7422 (2022)     15 July 2022 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 3. Perovskite film characterizations.** ( **A** to **D** ) SEM images (top-view images on top, and the corresponding cross-sectional images on bottom) of the PbCl2-alloy– mediated film (A and C) and the Ref film (B and D). ( **E** and **F** ) AFM images of the (E) PbCl2 alloy–mediated film and (F) Ref film. 

calculated the open-circuit voltage loss ( _V_ oc-loss) induced by nonradiative recombination. The _V_ oc-loss of PSCs with PbCl2 alloy– mediated film is 126 mV, and that of Ref is 185 mV. The suppression of nonradiative recombination in chlorine-mediated PSCs is also confirmed by time-resolved photoluminescence (fig. S17), transient photovoltage (TPV; fig. S18), and drive-level capacitance profiling (DLCP; fig. S19) characterizations ( _28_ ). 

In addition, the optoelectronic properties of the devices were studied by ideality factor ( _n_ id), transient photocurrent (TPC) measurement, and dark _J_ - _V_ measurement. Figure S20 displays the steady-state light intensity–dependent _V_ oc of PSCs from which the ideality factor ( _n_ id) can be derived. The _n_ id of the PbCl2 alloy–mediated film is 1.31 compared with _n_ id ≈ 1.56 of the Ref film ( _40_ ). Figure S21 displays the TPC measurement, which indicates improved carrier transport and extraction capabilities of the PbCl2 alloy–mediated PSCs. Moreover, we recorded dark _J_ - _V_ curves (fig. S22) and found that the dark current of PbCl2-alloy–mediated PSCs was lower than that of the Ref PSCs in both the forward and reverse bias regions, indicating that a larger shunt resistance was achieved with PbCl2 modification. 

### **Photovoltaic performance of vacuum-deposited PSCs** 

We fabricated PSCs with the structure of fluorine-doped tin oxide (FTO)/SnO2/perovskite/Spiro-OMeTAD/Au and investigated the 

influence of PbCl2 on the photovoltaic performance. Note that the evaporated perovskite films were posttreated by 2-CF3-PEAI to passivate the surface defects ( _41_ ). As displayed in Fig. 4A, the open-circuit voltage ( _V_ oc), fill factor (FF), and short current density ( _J_ sc) were all improved significantly with PbCl2 modification. For the best devices, _V_ oc was substantially enhanced from 1.073 to 1.152 V, which could be attributed to the reduction of nonradiative recombination losses, as discussed above. The _J_ sc is increased from 24.75 to 25.92 mA cm<sup>−2</sup> . Furthermore, the FF was enhanced from 79.57 to 81.78%, which is likely related to the higher crystallinity and vertical face-on orientation of perovskite. The best PSC by the Cl-containing alloy– mediated sequential vapor deposition approach exhibits a PCE of 24.42% (reverse scan) and 24.04% (forward scan) with an aperture area of 0.1 cm<sup>2</sup> (Fig. 4B), which is the highest PCE based on vacuum thermal evaporation and for Methylammonium-free PSCs. 

Vacuum evaporation contributes to perovskite films with high homogeneity and uniformity, which is beneficial to fabricate largearea devices. We fabricated PSCs with an aperture area of 1 cm<sup>2</sup> based on the same perovskite composition (Cs0.05FA0.95PbI3), which gave a champion PCE of 23.44 and 23.23% for reverse and forward scans, respectively (Fig. 4C). One of the devices was sent to the National Institute of Metrology, China for certification, showing a certified PCE of 22.6% (fig. S23). To our knowledge, this is among 

**5 of 8** 

Li _et al_ ., _Sci. Adv._ **8** , eabo7422 (2022)     15 July 2022 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 4. Device performance of PSCs.** ( **A** ) _V_ oc, _J_ sc, FF, and PCE distribution of 20 PSC devices. ( **B** ) _J_ - _V_ curve and corresponding parameters of the best-performing Cl-alloy–mediated device and the Ref device (0.1-cm<sup>2</sup> aperture area). ( **C** ) _J_ - _V_ curve and corresponding parameters for the best-performing Cl-alloy–mediated device with an aperture area of 1 cm<sup>2</sup> . ( **D** ) The long-term stability of the PSCs stored in a dry air box (<5% RH) in the dark. ( **E** ) The operational stability test under MPP tracking in N2. ( **F** ) The long-term stability under 60°C heating in Ar atmosphere. 

the highest PCEs of 1-cm<sup>2</sup> PSCs to date. We also fabricate PSC minimodules (14.4-cm<sup>2</sup> aperture area) by vacuum evaporation, and a 19.87% efficiency is achieved (fig. S24). 

### **Stability test** 

To investigate the stability of PSCs fabricated by vacuum evaporation, we monitored the performance evolution under several conditions. We performed a long-term environmental stability test of devices, and the unencapsulated PSCs maintained 97% of their initial PCE after 1300 hours of storage in ambient air at a humidity of 35% (fig. S25). Moreover, no apparent decrease in device performance was observed when the PSCs were stored in a dry air box [<5% relative humidity (RH)] in the dark for more than 4000 hours (Fig. 4D). In addition, the operational stability of unsealed PSCs was studied at continuous light irradiation with MPP tracking in the nitrogen atmosphere. The devices maintained 92% of the initial PCE after 450 hours of aging (Fig. 4E). Besides, the unencapsulated PSCs maintained 70.8% of the initial PCE after heated at 60°C for 1200 hours in the Ar atmosphere (Fig. 4F). We attributed the good stability of all-vacuum perovskite to the high-quality pinhole-free perovskite film ( _42_ ). 

and 1-cm<sup>2</sup> -area devices, respectively. Systematic operando GIWAXS and XRD characterizations showed that chlorine incorporates into Cs0.05PbI2.05− _x_ Cl _x_ as an alloy, inducing a face-on orientation of the lead halide precursor. Furthermore, the integrated Cl can accelerate the solid-state diffusion of organic ammonium halide salt, facilitate perovskite phase transition from the  phase to the  phase, and increase the crystallinity of the resulting perovskite nanocrystals, leading to a high-quality film with fewer defects. We believe that this breakthrough will promote the scalable fabrication of large- area, high-efficiency PSCs and other perovskite-based optoelectronics. 

#### **MATERIALS AND METHODS** 

### **Materials** 

The SnO2 colloid precursor [tin(IV) oxide, 15% in H2O colloidal dispersion] was purchased from Alfa Aesar. Lead chloride (PbCl2) and cesium iodide (CsI) were purchased from Meryer. FAI was purchased from Great Cell Solar Materials. Chlorobenzene (CB) and acetonitrile were purchased from Acros. Isopropanol, lithium bis(trifluoromethanesulfonyl)imide (Li-TFSI), and 4- _tert_ -butyl pyridine were purchased from Energy-Chemical. 2-CF3-PEAI and Spiro-OMeTAD were synthesized in our laboratory. 

#### **DISCUSSION** 

We developed an effective multisource sequential vacuum deposition approach to fabricate large-area, pinhole-free perovskite films, which, together with precursor optimization, enables us to achieve high-efficiency PSCs with PCEs of 24.42 and 23.44% for 0.1-cm<sup>2</sup> -area 

### **Device fabrication** 

The fluorine-doped tin oxide (FTO) glass substrates were sequentially cleaned using detergent, deionized water, ethanol, and isopropanol. After 20 min of ultraviolet- O3 treatment, the SnO2 colloidal solution (diluted to 3.75 weight %) was deposited by spin coating at 4000 rpm for 

**6 of 8** 

Li _et al_ ., _Sci. Adv._ **8** , eabo7422 (2022)     15 July 2022 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

25 s (1000 rpm ramp), followed by annealing at 150°C for 30 min in ambient air. The FTO/SnO2 substrates were treated with oxygen plasma for 20 min before transferred to the vacuum chamber. 

Figure S1 is a schematic illustration of vacuum chambers for the evaporation. It is a 40 cm by 40 cm by 50 cm cuboid-shaped chamber. The distance from evaporation sources to the substrate is around 35 cm, and two quartz crystal microbalances are placed close to the substrate to monitor the evaporation rate. We used the resistance heater as evaporation sources and controlled the heating temperature of the evaporation sources by tuning the applied voltage. A K-type thermocouple detector was adhered to the resistance heater to monitor the temperature. Note that we keep the temperature constant during the evaporation of lead halide and FAI film. For the deposition of the lead halide layer, 500 mg of PbI2, 100 mg of CsI, and 500 mg of PbCl2 were placed into the crucibles. The deposition rate was predetermined by controlling the corresponding source temperature. The deposition process started at 7 × 10<sup>−3</sup> Pa, and a film with designated thickness was evaporated. After that, the substrates were transferred to another vacuum chamber for the deposition of FAI with a pressure under 10<sup>−2</sup> Pa. FAI (700 mg) was placed into the crucible, and after heating to 250°C, FAI molecules began to deposit onto the substrate. The optimization of the evaporation thickness of FAI is listed in fig. S30. After FAI deposition, the perovskite films were annealed at 170°C for 15 min in ambient air. 

For perovskite surface treatment, 2-CF3-PEAI (10 mg/ml) in isopropanol was spin-coated at 4000 rpm for 20 s (2000 rpm ramp). The hole-transport layer was deposited on top of the perovskite film by spin coating at 4000 rpm for 25 s using a Spiro-OMeTAD/CB solution, which consisted of 80 mg of Spiro-OMeTAD, 30 l of 4- _tert_ -butyl pyridine, and 18 l of Li-TFSI solution (520 mg of Li-TFSI in 1 ml of acetonitrile) in 1 ml of CB. Last, 100-nm metal contact (Au and Ag) was deposited by thermal evaporation. 

### **Material and device characterization** 

SEM images were measured using a Zeiss field-emission scanning electron microscope (Zeiss Merlin). We obtained the SEM images at the 15-kV voltage. XRD patterns were recorded by Rigaku SmartLab with copper K ( = 1.54 Å, 150 mA, 40 kV) as the x-ray source. EL, EL-EQE, TPV, TPC, and incident photon-to-electron conversion efficiency were measured by the Cicci platform, Italy. TPC and TPV measurements were performed under a constant bias illumination, while the short light pulse was used to create the charge carriers. The light pulse was set to be a 20-s delay, and the total measurement was performed within 200 s. The wavelength range of the IPCE measurement was from 300 to 900 nm. Note that no bias voltage was applied in the IPCE test. The ICP-MS test was performed in Tsinghua University Analysis Center. The ICP-MS was measured using iCAP Q equipment (Thermo Fisher Scientific, Waltham, USA). For the sample preparation procedure, we transferred the sample to a polytetrafluoroethylene beaker, added 5 ml of aqua regia, and digested at 180°C until there was no obvious reaction, and about 0.5 ml of solution remained. The beaker was then cooled down to room temperature, and we fixed the volume to 10 ml with ultrapure water. Then, the solution was tested on the iCAP Q equipment. GIWAXS was carried out at beamline 1W1A of the Beijing Synchrotron Radiation Facility. 

The capacitance-voltage ( _C_ - _V_ ), DLCP, and dark _J_ - _V_ measurements were conducted using a Keithley 4200A-SCS parameter analyzer. For the standard _C_ - _V_ measurement, the DC bias scanned from 0 to 1.2 V at a frequency of 10 kHz. The amplitude of the AC 

bias was 20 mV. The DLCP measurement was conducted in the same DC bias range as that for the _C_ - _V_ measurement, and the trap densities were measured at 10 kHz. The amplitude of the AC bias range is 12.73 to 14.14 mV. The measured capacitance at each DC bias was fitted with a polynomial function to obtain _C_ 0 and _C_ 1 with a homemade computer program. 

The _J_ - _V_ measurement was performed via a solar simulator (Newport, Oriel Class AAA, 94043 A) with a source meter (Keithley 2400) of 100 mA cm<sup>−2</sup> under Air Mass 1.5 Global illumination. Light intensity was calibrated with an infrared-cutoff filter (KG-3, Newport) silicon reference cell, and a mismatch factor of 1 was used in our measurements. The _J_ - _V_ measurements were carried out in ambient air. The devices were measured both in forward scan (−0.2 V → 1.2 V, step 0.02 V) and reverse scan (1.2 V → −0.2 V, step 0.02 V) with a scanning speed of 0.2 V/s. The active area of the device was defined by a dark mask of 0.1 or 1 cm<sup>2</sup> . We sent a device to the PV Metrology Laboratory of the National Institute of Metrology, China, for certification. 

The operational stability test under MPP tracking conditions was performed under a light-emitting diode lamp. The unencapsulated PSCs were masked and placed inside a homemade sample holder with continuous N2 flow. For the thermal stability test, Spiro-OMeTAD/ PTAA hybrid HTL was used, where a Spiro-OMeTAD/PTAA (40 mg/ 5 mg in 1 ml of CB) mixture was used with the addition of 18 l of Li-TFSI (520 mg of Li-TFSI in 1 ml of acetonitrile) and 30 l of 4- _tert_ -butylpyridine, and deposited by spin coating at 4000 rpm for 20 s. 

### **SUPPLEMENTARY MATERIALS** 

Supplementary material for this article is available at https://science.org/doi/10.1126/ sciadv.abo7422 

### **REFERENCES AND NOTES** 

1. M. I. H. Ansari, A. Qurashi, M. K. Nazeeruddin, Frontiers, opportunities, and challenges in perovskite solar cells: A critical review. _J. Photochem. Photobiol. C_ **35** , 1–24 (2018). 

2. J. Ávila, C. Momblona, P. P. Boix, M. Sessolo, H. J. Bolink, Vapor-deposited perovskites: The route to high-performance solar cell production? _Joule_ **1** , 431–442 (2017). 

3. S. H. Wang, X. T. Li, J. B. Wu, W. J. Wen, Y. B. Qi, Fabrication of efficient metal halide perovskite solar cells by vacuum thermal evaporation: A progress review. _Curr. Opin. Electrochem._ **11** , 130–140 (2018). 

4. J. Li, H. A. Dewi, H. Wang, J. H. Lew, N. Mathews, S. Mhaisalkar, A. Bruno, Design of perovskite thermally co-evaporated highly efficient mini-modules with high geometrical fill factors. _Sol. RRL_ **4** , 2000473 (2020). 

5. M. M. Tavakoli, P. Yadav, D. Prochowicz, R. Tavakoli, M. Saliba, Multilayer evaporation of MAFAPbI3− _x_ Cl _x_ for the fabrication of efficient and large-scale device perovskite solar cells. _J. Phys. D Appl. Phys._ **52** , 034005 (2019). 

6. R. Ji, Z. Zhang, C. Cho, Q. An, F. Paulus, M. Kroll, M. Löffler, F. Nehm, B. Rellinghaus, K. Leo, Y. Vaynzof, Thermally evaporated methylammonium-free perovskite solar cells. _J. Mater. Chem. C_ **8** , 7725–7733 (2020). 

7. T. Gallet, R. G. Poeira, E. M. Lanzoni, T. Abzieher, U. W. Paetzold, A. Redinger, Coevaporation of CH3NH3PbI3: How growth conditions impact phase purity, photostriction, and intrinsic stability. _ACS Appl. Mater. Interfaces_ **13** , 2642–2653 (2021). 

8. Z. Zhang, R. Ji, M. Kroll, Y. J. Hofstetter, X. Jia, D. Becker-Koch, F. Paulus, M. Löffler, F. Nehm, K. Leo, Y. Vaynzof, Efficient thermally evaporated -CsPbI3 perovskite solar cells. _Adv. Energy Mater._ **11** , 2100299 (2021). 

9. P. Du, L. Wang, J. Li, J. Luo, Y. Ma, J. Tang, T. Zhai, Thermal evaporation for halide perovskite optoelectronics: Fundamentals, progress, and outlook. _Adv. Optic. Mater._ **10** , 2101770 (2022). 

10. Y. Choi, D. Koo, M. Jeong, G. Jeong, J. Lee, B. Lee, K. J. Choi, C. Yang, H. Park, Toward all-vacuum-processable perovskite solar cells with high efficiency, stability, and scalability enabled by fluorinated Spiro-OMeTAD through thermal evaporation. _Sol. RRL_ **5** , 2100415 (2021). 

11. S. Ullah, J. Wang, P. Yang, L. Liu, Y. Li, A. U. Rehman, S. E. Yang, T. Xia, H. Guo, Y. Chen, Evaporation deposition strategies for all-inorganic CsPb(I1– xBrx)3 perovskite solar cells: Recent advances and perspectives. _Solar RRL_ **5** , 2100172 (2021). 

12. J. Borchert, I. Levchuk, L. C. Snoek, M. U. Rothmann, R. Haver, H. J. Snaith, C. J. Brabec, L. M. Herz, M. B. Johnston, Impurity tracking enables enhanced control 

**7 of 8** 

Li _et al_ ., _Sci. Adv._ **8** , eabo7422 (2022)     15 July 2022 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

and reproducibility of hybrid perovskite vapor deposition. _ACS Appl. Mater. Interfaces_ **11** , 28851–28857 (2019). 

13. M. Kam, Y. Zhu, D. Zhang, L. Gu, J. Chen, Z. Fan, Efficient mixed-cation mixed-halide perovskite solar cells by all-vacuum sequential deposition using metal oxide electron transport layer. _Sol. RRL_ **3** , 1900050 (2019). 

14. M. Liu, M. B. Johnston, H. J. Snaith, Efficient planar heterojunction perovskite solar cells by vapour deposition. _Nature_ **501** , 395–398 (2013). 

15. J. Li, H. Wang, X. Y. Chin, H. A. Dewi, K. Vergeer, T. W. Goh, J. W. M. Lim, J. H. Lew, K. P. Loh, C. Soci, T. C. Sum, H. J. Bolink, N. Mathews, S. Mhaisalkar, A. Bruno, Highly efficient thermally co-evaporated perovskite solar cells and mini-modules. _Joule_ **4** , 1035–1053 (2020). 

16. J. Feng, Y. Jiao, H. Wang, X. Zhu, Y. Sun, M. du, Y. Cao, D. Yang, S. (. F.). Liu, Highthroughput large-area vacuum deposition for high-performance formamidine-based perovskite solar cells. _Energ. Environ. Sci._ **14** , 3035–3043 (2021). 

17. H. Min, D. Y. Lee, J. Kim, G. Kim, K. S. Lee, J. Kim, M. J. Paik, Y. K. Kim, K. S. Kim, M. G. Kim, T. J. Shin, S. Il Seok, Perovskite solar cells with atomically coherent interlayers on SnO2 electrodes. _Nature_ **598** , 444–450 (2021). 

18. H. Yu, F. Wang, F. Xie, W. Li, J. Chen, N. Zhao, The role of chlorine in the formation process of “CH3NH3PbI3-xClx” perovskite. _Adv. Funct. Mater._ **24** , 7102–7108 (2014). 

19. F. Ye, J. Ma, C. Chen, H. Wang, Y. Xu, S. Zhang, T. Wang, C. Tao, G. Fang, Roles of MACl in sequentially deposited bromine-free perovskite absorbers for efficient solar cells. _Adv. Mater._ **33** , 2007126 (2021). 

20. K. Odysseas Kosmatos, L. Theofylaktos, E. Giannakaki, D. Deligiannis, M. Konstantakou, T. Stergiopoulos, Methylammonium chloride: A key additive for highly efficient, stable, and up-scalable perovskite solar cells. _Energy Environ. Sci._ **2** , 79–92 (2019). 

21. Y. H. Chiang, M. Anaya, S. D. Stranks, Multisource vacuum deposition 

   - of methylammonium-free perovskite solar cells. _ACS Energy Lett._ **5** , 2498–2504 (2020). 

22. C. Momblona, L. Gil-Escrig, E. Bandiello, E. M. Hutter, M. Sessolo, K. Lederer, J. Blochwitz-Nimoth, H. J. Bolink, Efficient vacuum deposited p-i-n and n-i-p perovskite solar cells employing doped charge transport layers. _Energ. Environ. Sci._ **9** , 3456–3463 (2016). 

23. L. Gil-Escrig, C. Dreessen, I. C. Kaya, B. S. Kim, F. Palazon, M. Sessolo, H. J. Bolink, Efficient vacuum-deposited perovskite solar cells with stable cubic FA1–xMAxPbI3. _ACS Energy Lett._ **5** , 3053–3061 (2020). 

24. Z. Xu, Z. Liu, N. Li, G. Tang, G. Zheng, C. Zhu, Y. Chen, L. Wang, Y. Huang, L. Li, N. Zhou, J. Hong, Q. Chen, H. Zhou, A thermodynamically favored crystal orientation in mixed formamidinium/methylammonium perovskite for efficient solar cells. _Adv. Mater._ **31** , 1900390 (2019). 

25. H. Lu, Y. Liu, P. Ahlawat, A. Mishra, W. R. Tress, F. T. Eickemeyer, Y. Yang, F. Fu, Z. Wang, C. E. Avalos, B. I. Carlsen, A. Agarwalla, X. Zhang, X. Li, Y. Zhan, S. M. Zakeeruddin, L. Emsley, U. Rothlisberger, L. Zheng, A. Hagfeldt, M. Grätzel, Vapor-assisted deposition of highly efficient, stable black-phase FAPbI3 perovskite solar cells. _Science_ **370** , eabb8985 (2020). 

26. W. Hui, L. Chao, H. Lu, F. Xia, Q. Wei, Z. Su, T. Niu, L. Tao, B. Du, D. Li, Y. Wang, H. Dong, S. Zuo, B. Li, W. Shi, X. Ran, P. Li, H. Zhang, Z. Wu, C. Ran, L. Song, G. Xing, X. Gao, J. Zhang, Y. Xia, Y. Chen, W. Huang, Stabilizing black-phase formamidinium perovskite formation at room temperature and high humidity. _Science_ **371** , 1359–1364 (2021). 

27. Z. Xiong, X. Chen, B. Zhang, G. O. Odunmbaku, Z. Ou, B. Guo, K. Yang, Z. Kan, S. Lu, S. Chen, N. A. N. Ouedraogo, Y. Cho, C. Yang, J. Chen, K. Sun, Simultaneous interfacial modification and crystallization control by biguanide hydrochloride for stable perovskite solar cells with PCE of 24.4%. _Adv. Mater._ **34** , 2106118 (2022). 

28. Z. Ni, C. Bao, Y. Liu, Q. Jiang, W. Q. Wu, S. Chen, X. Dai, B. Chen, B. Hartweg, Z. Yu, Z. Holman, J. Huang, Resolving spatial and energetic distributions of trap states in metal halide perovskite solar cells. _Science_ **367** , 1352–1358 (2020). 

29. S. A. Rigter, X. L. Quinn, R. E. Kumar, D. P. Fenning, P. Massonnet, S. R. Ellis, R. M. A. Heeren, K. L. Svane, A. Walsh, E. C. Garnett, Passivation properties and formation mechanism of amorphous halide perovskite thin films. _Adv. Funct. Mater._ **31** , 2010330 (2021). 

30. J. Gebhardt, Y. Kim, A. M. Rappe, Influence of the dimensionality and organic cation on crystal and electronic structure of organometallic halide perovskites. _J. Phys. Chem. C_ **121** , 6569–6574 (2017). 

31. X. Zhu, Z. Xu, S. Zuo, J. Feng, Z. Wang, X. Zhang, K. Zhao, J. Zhang, H. Liu, S. Priya, S. F. Liu, D. Yang, Vapor-fumigation for record efficiency two-dimensional perovskite solar cells with superior stability. _Energ. Environ. Sci._ **11** , 3349–3357 (2018). 

32. L. Kuai, J. Li, Y. Li, Y. Wang, P. Li, Y. Qin, T. Song, Y. Yang, Z. Chen, X. Gao, B. Sun, Revealing crystallization dynamics and the compositional control mechanism of 2D perovskite film growth by in situ synchrotron-based GIXRD. _ACS Energy Lett._ **5** , 8–16 (2020). 

33. J. Liu, Y. Chen, C. Ran, J. Hu, Y. Lin, Y. Xia, Y. Chen, Unraveling the role of chloride in vertical growth of low-dimensional Ruddlesden–Popper perovskites for efficient perovskite solar cells. _ACS Appl. Mater. Interfaces_ (2021); https://doi.org/10.1021/acsami.1c16124. 

34. B. Chen, P. N. Rudd, S. Yang, Y. Yuan, J. Huang, Imperfections and their passivation in halide perovskite solar cells. _Chem. Soc. Rev._ **48** , 3842–3867 (2019). 

35. F. Gao, Y. Zhao, X. Zhang, J. You, Recent progresses on defect passivation toward efficient perovskite solar cells. _Adv. Energy Mater._ **10** , 1902650 (2020). 

36. D. Luo, R. Su, W. Zhang, Q. Gong, R. Zhu, Minimizing non-radiative recombination losses in perovskite solar cells. _Nat. Rev. Mater._ **5** , 44–60 (2020). 

37. M. Abdi-Jalebi, Z. Andaji-Garmaroudi, S. Cacovich, C. Stavrakas, B. Philippe, J. M. Richter, M. Alsari, E. P. Booker, E. M. Hutter, A. J. Pearson, S. Lilliu, T. J. Savenije, H. Rensmo, G. Divitini, C. Ducati, R. H. Friend, S. D. Stranks, Maximizing and stabilizing luminescence from halide perovskites with potassium passivation. _Nature_ **555** , 497–501 (2018). 

38. T. A. S. Doherty, A. J. Winchester, S. Macpherson, D. N. Johnstone, V. Pareek, E. M. Tennyson, S. Kosar, F. U. Kosasih, M. Anaya, M. Abdi-Jalebi, Z. Andaji-Garmaroudi, E. L. Wong, J. Madéo, Y. H. Chiang, J. S. Park, Y. K. Jung, C. E. Petoukhoff, G. Divitini, M. K. L. Man, C. Ducati, A. Walsh, P. A. Midgley, K. M. Dani, S. D. Stranks, Performance-limiting nanoscale trap clusters at grain junctions in halide perovskites. _Nature_ **580** , 360–366 (2020). 

39. D. W. Dequilettes, K. Frohna, D. Emin, T. Kirchartz, V. Bulovic, D. S. Ginger, S. D. Stranks, Charge-carrier recombination in halide perovskites. _Chem. Rev._ **119** , 11007–11019 (2019). 

40. W. Xu, T. Zhu, Y. Yang, L. Zheng, L. Liu, X. Gong, Enhanced device performance of perovskite photovoltaics by magnetic field-aligned perovskites-magnetic nanoparticles composite thin film. _Adv. Funct. Mater._ **30** , 2002808 (2020). 

41. J. Zhou, M. Li, S. Wang, L. Tan, Y. Liu, C. Jiang, X. Zhao, L. Ding, C. Yi, 2-CF3-PEAI to eliminate Pb0 traps and form a 2D perovskite layer to enhance the performance and stability of perovskite solar cells. _Nano Energy_ **95** , 107036 (2022). 

42. R. Guo, D. Han, W. Chen, L. Dai, K. Ji, Q. Xiong, S. Li, L. K. Reb, M. A. Scheel, S. Pratap, N. Li, S. Yin, T. Xiao, S. Liang, A. L. Oechsle, C. L. Weindl, M. Schwartzkopf, H. Ebert, P. Gao, K. Wang, M. Yuan, N. C. Greenham, S. D. Stranks, S. V. Roth, R. H. Friend, P. MüllerBuschbaum, Degradation mechanisms of perovskite solar cells under vacuum and one atmosphere of nitrogen. _Nat. Energy_ **6** , 977–986 (2021). 

**Acknowledgments:** We thank X. Zhang for the optimization of the evaporation procedure and Y. Chen and Z. Shen from Beijing Synchrotron Radiation Facility beamline 1W1A for the GIWAXS tests. **Funding:** This work was supported by the National Natural Science Foundation of China (no. 21872080); State Key Laboratory of Power System and Generation Equipment (nos. SKLD21Z03 and SKLD20M03); The Chinese Thousand Talents Program for Young Professionals; State Grid Corporation of China, National Bio Energy Co. Ltd., grant no. 52789922000D; and China Huaneng Group Co. Ltd., grant no. HNKJ20-H88. **Author contributions:** C.Y. conceived the idea and directed the project. H.L. fabricated the PSCs and conducted the basic characterization. M.L. and J.Z. helped with the characterizations. L.T. and C.J. helped with the stability test. X.Z., S.W., Y.Z., Y.Y., and W.T. provided valuable suggestions for the manuscript. All the authors participated in the discussion of the results and revision of the manuscript. **Competing interests:** C.Y., H.L., C.J., M.L., L.T., J.Z., Y.L., Y.Y., and S.W. are inventors on a provisional patent application related to this work filed at the China National Intellectual Property Administration (no. CN 114242901, filed 16 November 2021). The authors declare that they have no other competing interests. **Data and materials availability:** All data needed to evaluate the conclusions in the paper are present in the paper and/or the Supplementary Materials. 

Submitted 22 February 2022 Accepted 1 June 2022 Published 15 July 2022 10.1126/sciadv.abo7422 

**8 of 8** 

Li _et al_ ., _Sci. Adv._ **8** , eabo7422 (2022)     15 July 2022 



## **Sequential vacuum-evaporated perovskite solar cells with more than 24% efficiency** 

Hang Li, Junjie Zhou, Liguo Tan, Minghao Li, Chaofan Jiang, Siyang Wang, Xing Zhao, Yue Liu, Yu Zhang, Yiran Ye, Wolfgang Tress, and Chenyi Yi 

_Sci. Adv._ **8** (28), eabo7422.  DOI: 10.1126/sciadv.abo7422 

**View the article online** https://www.science.org/doi/10.1126/sciadv.abo7422 **Permissions** 

https://www.science.org/help/reprints-and-permissions 

Use of this article is subject to the Terms of service 

> _Science Advances_ (ISSN 2375-2548) is published by the American Association for the Advancement of Science. 1200 New York Avenue NW, Washington, DC 20005. The title _Science Advances_ is a registered trademark of AAAS. 

Copyright © 2022 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works. Distributed under a Creative Commons Attribution NonCommercial License 4.0 (CC BY-NC). 

