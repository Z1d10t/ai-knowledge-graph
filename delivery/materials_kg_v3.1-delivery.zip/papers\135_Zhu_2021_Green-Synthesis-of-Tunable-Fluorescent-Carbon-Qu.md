# Green Synthesis of Tunable Fluorescent Carbon Quantum Dots from Lignin and Their Application in Anti-Counterfeit Printing.

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | ACS Applied Materials and Interfaces |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 199 |
| 作者 | Ling-Li Zhu, De-Kui Shen, Qi Wang, Kai Luo |
| DOI | 10.1021/acsami.1c16679 |
| 源文件 | 035_Zhu_2021_Green-Synthesis-of-Tunable-Fluorescent-Carbon-Qu.pdf |

---
������������������������������������ 

���������� 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```



## **Green Synthesis of Tunable Fluorescent Carbon** 

**Quantum Dots from Lignin and its application in** 

## **Anti-counterfeit Printing** 

Lingli Zhu<sup>a</sup> , Dekui Shen<sup>a,</sup> *, Qi Wang<sup>b,</sup> *, Kai Hong Luo<sup>c</sup> 

a Key Laboratory of Energy Thermal Conversion and Control of Ministry of Education, School 

of Energy and Environment, Southeast University, Nanjing 210096, PR China. 

b College of Metrology and Measurement Engineering, China Jiliang University, Hangzhou, 

310087, Zhejiang, PR China 

c Department of Mechanical Engineering, University College London, London WC1E7JE, UK 

E-mail address: 101011398@seu.edu.cn (D. Shen), wangqi@cjlu.edu.cn (Q. Wang) 

**ABSTRACT** : Lignin converted to carbon quantum dots (CQDs) attracts tremendous attentions 

for the large-scaled CQDs production and value-added disposal of the biomass wastes (such as 

the black liquor from pulping industry and the residue from hydrolysis of biomass). The green 

synthesis of lignin-derived CQDs is proposed through a facile two-step route with the 

adjustment of acid additives containing the N or S. The synthesized CQDs exhibited bright fluorescence in gradient colors from blue to yellowish green, in which the N and S co-doped 

CQDs with the addition of 2, 4-diaminobenzene sulfonic acid show the optimal fluorescence 

quantum yield (QY) of 30.5%. The red-shift photoluminescence emission behaviors of the 

CQDs can be attributed to the increased graphitization degree and reduced optical energy band 

gaps (2.47→2.17 eV) with regard to the incorporation of various heteroatoms. The improved 

fluorescence QYs are consistent with the variation trend of the increased N/C content in the 

CQDs. The high-efficient yellowish green-emissive CQDs performed well in 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

anti-counterfeiting printing, regarding its bright fluorescence, strong water solubility and excellent chemical stability. The green synthesis of tunable fluorescent CQDs exhibits the value-added utilization of lignin for the fluorescence ink production. 

**_Keywords_** : Alkali lignin, Carbon quantum dots, Heteroatoms, Fluorescence mechanism, Anti-counterfeit printing. 

## **1. Introduction** 

Lignocellulosic biomass, the only sustainable and non-fossil resource in nature has great promise as alternative sources of petroleum-based energy and materials. It is composed of cellulose (45%), hemicellulose (25%) and lignin (30%) [1, 2]. Although breakthrough progress 

has been achieved in the efficient conversion of cellulose and hemicellulose into fuel ethanol 

and chemicals [3, 4]. The high-valued utilization of lignin remains a major challenge due to its complexity and recalcitrance, and more than 98% of it is discharged into rivers as black liquor or burned for heat as solid waste. Lignin is a three-dimensional amorphous polymer consisting of three principal phenylpropane units (p-hydroxyphenol (H), guaiacyl (G) and syringyl (S)) linked by C–C bond and C–O bond [5-7]. Profiting from its unique aromatic rings in the native structure, one of the most advanced strategies for lignin utilization is for the green production of 

carbon nanomaterials with aromatic subunit such as carbon quantum dots (CQDs) [8, 9]. � 

CQDs, as a rising star of zero-dimensional (0D) carbon nanomaterials, have gained tremendous attention due to their outstanding biocompatibility, excellent water solubility, good chemical 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

stability, superior nontoxicity, high conductivity, and controllable PL performance [10, 11]. 

Owing to these advantages, CQDs are widely applied in optical and electrochemical fields, 

including bioimaging, sensing, light-emitting diode, nanomedicine, photocatalysis, electrocatalysis, supercapacitors, batteries and photovoltaics [12]. However, the high-cost raw material and the low production yield hinder the industrial application of CQDs. The green production of CQDs from renewable and low-cost lignin has shown great potential for addressing these issues [13]. Recently, massive efforts have been devoted to improving the photoluminescence (PL) performance of lignin-derived CQDs, especially the fluorescence quantum yield (QY). It is found that the presence of additives (acid or alkali) play a dual role of hydrotrope and dopant in the synthesis process, as to enhance the fluorescence QY of lignin-derived CQDs [14]. The blue N-doped CQDs were obtained from lignin via one-step hydrothermal method with the addition of alkali additives (ammonia water or ethylenediamine), the QYs of which were 14.2% and 17.6%, respectively. The lignin-derived CQDs as fluorescent nanoprobe both showed high sensitivity and selectivity in sensing metal ions [15, 16]. In term of acid additives, the light green S-doped lignin-derived CQDs were synthesized by one-step hydrothermal treatment of lignin and sulfuric acid. The resultant CQDs with a QY of 13.5% exhibited excellent selectivity and sensitivity on the detection of Sudan [17]. The blue N-doped 

CQDs from alkali lignin were prepared by a two-step process including sonication in nitric acid 

followed by hydrothermal treatment. The as-prepared single-crystalline CQDs had a QY of 21.0% and had potential in bioimaging [18]. The cyan S, N co-doped CQDs from lignin and p-amino-benzenesulfonic acid monosodium salt were synthesized through the same two-step process described above. The as-synthesized CQDs with a QY of 20.2% presented sensitive 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

fluorometric detection of Fe<sup>3+</sup> ions [19]. Nevertheless, the production of lignin-derived CQDs is still largely under-developed with the bottleneck in the monotonous fluorescence color (blue or green) and the limited fluorescence QY (below 21%). It can be found that acids are the mainstream additives especially containing N or S elements due to its significantly positive effect on the improvement of the PL performance of CQDs. The uncertainty of fluorescence mechanism also leads to the disorientation of performance regulation thus constraining its wide application. There is already an ever-increasing demand for low-cost lignin-derived CQDs of high performance. 

In this work, alkali lignin was employed as the carbon source and mild organic acids (4-aminobenzoic acid, benzenesulfonic acid, 4-aminobenzene sulfonic acid, and 2, 4-diaminobenzene sulfonic acid, instead of corrosive acids) served as the dopants to tune the N or S doping. The green synthesis of the lignin-derived CQDs via a facile two-step route was proposed, involving acid hydrolysis followed by hydrothermal treatment (Figure 1). The fluorescence mechanism was explored for the tunable PL performance of the multicolor fluorescent CQDs, revealing the reason of the red-shift emission wavelengths and improved fluorescence QYs. The pH-dependent PL performance of the optimal CQDs was also evaluated to validate the chemical stability, which were used as valuable fluorescent inks and successfully applied in optical anti-counterfeit printing. The utilization of abundant and inexpensive biomass waste paves the way for green and large-scale production of CQDs and facilitates the development of sustainable applications. 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```



<!-- Start of picture text -->
Alkali lignin Acid olysis B-CQDs<br>a Hydrothermal<br>90 �  1h<br>200 �  12h<br>Acid olysis C-CQDs<br>b Hydrothermal<br>90 �  1h<br>200 �  12h<br>+<br>Acid olysis G-CQDs<br>c Hydrothermal<br>90 �  1h<br>200 �  12h<br>Acid olysis Y-CQDs<br>d Hydrothermal<br>90 �  1h<br>200 �  12h<br><!-- End of picture text -->

**Figure 1.** Synthetic routes of lignin-derived CQDs using four different N or S containing 

acid additives. 

## **2. Experimental Section** 

### _2.1 Materials and chemicals_ 

Alkali lignin (AL) with low sulfonate content was offered by Sigma in Shanghai. All other 

chemicals (ACS, ≥ 96%) were obtained from Aladdin in Shanghai and were used as received without any further purification. Phosphate buffer solutions (PBS) of different pH values were 

provided by Kehuashi in Nanjing. Deionized (DI) water was used throughout this experiment. 

The dialysis bag (retained molecular weight: 1000 Da) was purchased from Viskase (MD44, 

US). The PTFE microporous filter membranes (0.8 and 0.22 μm) were supplied by Relab in Shanghai. 

### _2.2 Synthesis of the lignin-derived CQDs_ 

The CQDs were synthesized by a simple two-step method of hydrothermal treatment. Firstly, 

acid additives (0.3 g) were fully dissolved into DI water (30 mL), and then AL (0.3 g) was 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

slowly added under constant stirring. Afterwards the water bath heater was used to treat the mixed solution keeping at 90 °C for 1 h with a constant stirring (350 rpm). The solution after the reaction was vacuum filtered by a PTFE microporous membrane (0.8 μm). Subsequently, the obtained filtrate was transferred into a 50 mL Teflon-lined stainless autoclave and maintained at 200 °C for 12 h. After naturally cooling to room temperature, the solid carbon insoluble in the CQDs aqueous solution was removed out by a PTFE microporous filter membrane (0.22 μm). The remaining brown supernatant was further dialyzed in a dialysis bag (1000 Da) for 2 days. Finally, the purified CQDs aqueous solution was freeze-dried in a lyophilizer below -60 °C for characterization and property evaluations. In this experiment, the four fluorescent CQDs were designed by changing the different types of acid additives, including 4-aminobenzoic acid, benzenesulfonic acid, 4-aminobenzene sulfonic acid, and 2, 4-diaminobenzene sulfonic acid, denoted as B-CQDs, C-CQDs, G-CQDs and Y-CQDs, respectively. 

### _2.3 Characterization_ 

The high-resolution transmission electron microscopy (HR-TEM) observation was performed on a FEI Tecnai G2 F20 TEM. Raman spectra were recorded on a ThermoFisher Dxi2Xi with a 532 nm laser beam. Fourier transform infrared (FT-IR) spectra were carried out on a Nicolet iN10 FT-IR spectrometer. The matrix-assisted laser desorption/ ionization time of flight mass spectrometry (MALDI-TOF MS) was measured on a Bruker ultrafleXtreme MALDI TOF/TOF Analyzer using a-cyano-4-hydroxycinnamic acid (CHCA) as matrix media in the analysis. 

X-ray photoelectron spectroscopy (XPS) experiment was conducted on a ThermoFisher ESCALAB 250Xi photoelectron spectrometer. The two-dimensional heteronuclear singular 

quantum correlation nuclear magnetic resonance (2D-HSQC NMR) experiment was performed 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

on a Bruker Avance III 600 MHz spectrometer with the dispersant of dimethyl sulfoxide-d6 

(DMSO). The ultraviolet−visible (UV-vis) absorption spectra were measured by a YuanXi 

UV-5200 spectrophotometer. The PL spectra were characterized by a Agilent Cary Eclipse. The 

PL lifetimes were measured by Edinburgh FLS1000 spectrofluorometer. 

## **3. Results and discussion** 

### _3.1 Morphological and optical characterization of CQDs_ 

The morphology and lateral sizes of the four CQDs are shown in the TEM images (Figure 2). 

The as-synthesized CQDs are all zero-dimensional and discrete quasi-spherical nanoparticles 

with the average size of 2.88, 4.01, 4.56, 5.05 nm, respectively. The HRTEM images of the four 

CQDs demonstrate well-resolved lattice fringes with similar lattice distance of 0.32 nm, resembling the (002) crystal plane of graphitic carbon [20, 21]. Furthermore, the CQDs aqueous solutions display bright fluorescence of blue (B-CQDs), cyan (C-CQDs), blueish green (G-CQDs) and yellowish green (Y-CQDs) color under UV light of 365 nm irradiation. According to the PL spectra, the optimum fluorescence emission peaks of B-CQDs, C-CQDs, G-CQDs, and Y-CQDs are centered at 344, 360, 470, and 530 nm at the excitation wavelengths of 280, 280, 340, 440 nm, respectively. The emission wavelengths of B-CQDs and C-CQDs mainly concentrate in the UV region, while those of G-CQDs and Y-CQDs extend from the UV 

to the visible region, displaying an evident red-shift PL behavior from B-CQDs to Y-CQDs. On 

the basis of the PL emission spectra under different excitation wavelengths, it can be observed 

that B-CQDs and C-CQDs present the most obvious excitation-dependent behavior. In 

comparison, the G-CQDs exhibit a weak excitation dependence. The Y-CQDs show almost no 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

excitation dependence due to the emission wavelengths maintain the position under the varying 

excitation wavelengths. The PL excitation-independent behavior is considered to be often related to fewer surface defects such as the oxygen, nitrogen or sulfur functional groups. It can be speculated that with the red-shift of the emission wavelengths, the surface defects of the CQDs decrease. The UV-vis absorption spectra of the four CQDs present a similar absorption peak at 200–300 nm ascribed to the π–π* transition of C=C in the sp<sup>2</sup> core, corresponding to the formation of conjugated skeletons. Notably, the absorption of G-CQDs and Y-CQDs are stronger than that of B-CQDs and C-CQDs, implying more C=C groups in their carbon core. The weak adsorption shoulder at 300–450 nm is attributed to the n–π* transition of C=O or C=N on the surface of the four CQDs [22]. The cut-off energy absorption spectra of G-CQDs and Y-CQDs is shifted forward to 370 and 350 nm in comparison with 410 and 400 nm of B-CQDs and C-CQDs, which suggests that the energy gap of valence electron transition decreases due to increased conjugation [23]. In addition, the relative fluorescence QYs of the four lignin-derived CQDs can be calculated as 10.8% of B-CQDs, 7.3% of C-CQDs, 23.6% of G-CQDs and 30.5% of Y-CQDs according to the measurement method [24] (in the Supporting Information). 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```



<!-- Start of picture text -->
a b c d<br>2 Diameter (nm)3 4 5 6 2 3 Diameter (nm)4 5 6 2 3 Diameter (nm)4 5 6 2 3 Diameter (nm)4 5 6<br>10 nm 10 nm 10 nm 10 nm<br>0.32 nm<br>0.32 nm<br>0.21 nm<br>0.32 nm<br>5 nm 5 nm 5 nm 5 nm<br>Ex (nm) 280 Ex (nm) 280 Ex (nm) 280 Ex (nm) 280<br>300 300 300 300<br>320 320 320 320<br>340 340 340 340<br>360 360 360 360<br>380 380 380 380<br>400 400 400 400<br>420 420 420 420<br>440 440 440 440<br>460 460 460 460<br>200 300 400 500 600 700 200 300 400 500 600 700 200 300 400 500 600 700 200 300 400 500 600 700<br>Wavelength (nm) Wavelength (nm) Wavelength (nm) Wavelength (nm)<br>()Absorbance a.u. PL Intensity (a.u.) ()Absorbance a.u. PL Intensity (a.u.) ()Absorbance a.u. PL Intensity (a.u.) ()Absorbance a.u. PL Intensity (a.u.)<br><!-- End of picture text -->

**Figure 2.** TEM, HRTEM images, UV-vis absorption spectra and PL emission spectra at 

different excitation wavelengths from 280 to 460 nm with a 20 nm increment of (a) B-CQDs, (b) 

C-CQDs, (c) G-CQDs, and (d) Y-CQDs (insert: fluorescence image of CQDs aqueous solution 

under 365 nm UV light and diameter distribution of CQDs). 

### _3.2 Structural characterization of CQDs_ 

The Raman, MS, FTIR and NMR are employed to analyze the chemical structure of CQDs. The Raman spectra of the four CQDs obviously show a G peak (1568-1586 cm<sup>−1</sup> ) and a D peak (1350-1380 cm<sup>−1</sup> ) (Figure 3a), which are associated with the vibrations of graphitized sp<sup>2</sup> carbon and disordered sp<sup>3</sup> carbon, respectively [8, 25]. The intensity ratios (IG/ID) can characterize the degree of graphitization and defects of the CQDs. The IG/ID values of the blue to yellowish green CQDs are 0.39, 0.44, 0.47 and 0.58, respectively. The increased graphitization degree is consistent with the red-shift PL emission behavior observed for the four CQDs. The 2D peak of the CQDs can be also found around 2800 cm<sup>-1</sup> , indicative of graphene 

with few layers [18, 26]. The degree of polymerization and molecular weight of the four CQDs 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

are recorded by MALDI-TOF MS (Figure 3b). The number-average molecular weights of the 

CQDs increase in the order of B-CQDs (525.5) < C-CQDs (534.8) < G-CQDs (573.4) < Y-CQDs (609.5), which may result from the larger size of conjugate structure. As for the FTIR spectra (Figure 3c), they all exhibit –OH, hydrocarbyl, carboxylic C=O, sp<sup>2</sup> C=C, and C–O stretching vibration peaks at 3000-3600, 2900, 1700, 1400-1500, and 1100 cm<sup>−1</sup> , respectively. Specially, the C-S/C=S vibration peaks in C-CQDs, G-CQDs and Y-CQDs spectra can be clearly detected at 600-800 cm<sup>−1</sup> [24, 27], originating from sulfonic groups in additives. The strengths of the C=C vibration peaks in Y-CQDs and G-CQDs spectra are greater than those observed in B-CQDs and C-CQDs spectra, implying that long-wave emission CQDs may contain higher sp<sup>2</sup> conjugation degree. The 2D-HSQC NMR spectra (<sup>1</sup> H -<sup>13</sup> C) are used to identify the sp<sup>3</sup> -hybridized carbon domains and the sp<sup>2</sup> -hybridized carbon domains of the four CQDs (Figure S2) (in the Supporting Information). In the NNR spectra, signals in range of 50– 75/3–4 ppm (δC/δH) are attributed to the aliphatic region (sp<sup>3</sup> C), and signals of 100-140/6-8 

ppm are corresponding to the aromatic region (sp<sup>2</sup> C). The content of sp<sup>3</sup> C is decreased from B-CQDs to Y-CQDs, while that of sp<sup>2</sup> C is increased, indicative of that higher degrees of 

sp<sup>2</sup> -conjugation domains make the PL emission wavelengths of CQDs red shift [23, 28]. 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```



<!-- Start of picture text -->
a b<br>Y-CQDs IG/ID =0.58 Y-CQDs<br>G-CQDs IG/ID =0.47 G-CQDs<br>C-CQDs IG/ID =0.44 C-CQDs<br>B-CQDs IG/ID =0.39 B-CQDs<br>500 1000 1500 2000 2500 3000 100 200 300 400 500 600<br>Raman shift (cm -1 ) (m/z)<br>c d<br>B-CQDs<br>Y-CQDs<br>C-CQDs<br>G-CQDs<br>G-CQDs Y-CQDs<br>C-CQDs<br>B-CQDs<br>3500 3000 2500 2000 1500 1000 500 0 50 100 150 200 250<br>Wavenumber (cm -1 ) Time (ns)<br>Intensity (a.u.) Intensity (a.u.)<br>Absorbancy (a.u.) Intensity (a.u.)<br><!-- End of picture text -->

**Figure 3.** Structure characterization of the four CQDs. (a) Raman spectra, (b) FTIR 

spectra, (c) MALDI-TOF MS spectra and (d) time-resolved PL spectra of the four types of 

CQDs. 

The chemical composition of the four CQDs are further characterized by XPS (Figure 4a-d). They are mainly composed of C (284.8 eV) and O (531.1 eV) elements, and a small amount of N (401.1 eV) or S (168.1 eV) elements. In detail, the samples from B-CQDs to Y-CQDs are N-doped, S-doped, N, S co-doped and N, S co-doped lignin-derived CQDs, respectively. These heteroatoms of N or S are introduced via the regulation of different organic acid additives containing sulfonate and amine. The high-resolution XPS spectra reveal that the four CQDs present similar C 1s and O 1s spectra, where sp<sup>2</sup> carbon (C-C/C=C, 284.5 eV), sp<sup>3</sup> carbon (C−O, 286.2 eV), carbonyl groups (C=O, 288.0 eV) in the C 1s spectra and C=O (532.1 eV), C−O (533.4 eV) in the O 1s spectra. In comparison, the C-C/C=C content in the C 1s spectra 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

significantly increases from B-CQDs to Y-CQDs, indicating the decreased defects on the surfaces. Meanwhile, the C=O content increases in the O 1s spectra, which is identified as the cause of red-shift emission due to its electron-accepting property [23, 29, 30]. These results agree well with the above-mentioned conclusion of FTIR and Raman analysis. The high-resolution N 1s spectra of B-CQDs, G-CQDs and Y-CQDs have two deconvolution peaks corresponding to amine-N (401.4 eV) and C-N (399.5 eV).The intensity ratio of C-N to amine-N peaks is decreased in the order of B-CQDs > G-CQDs > Y-CQDs. It is reported that 

the C-N in the form of pyridine-N, pyrrole-N as electron donors in the electron delocalization system is inclined to cause the blue-shift PL emission behavior [30-32]. The high-resolution S 2p spectra of C-CQDs, G-CQDs and Y-CQDs display three deconvolution peaks around 168.5 

169.6 and 170.5 eV, which represent the -C-SOx- (x=2, 3, 4) units derived from sulfonate in additives. To further explore the surface state of the CQDs, the peak areas are analyzed, and the results are listed in Table 1. The O/C ratios are 0.74 (B-CQDs), 0.59 (C-CQDs), 0.55 (G-CQDs), 

and 0.44 (Y-CQDs), which indicates that the surface oxidation degree from B-CQDs to Y-CQDs gradually decrease with the red-shift of the emission wavelengths. Moreover, the N/C ratios of B-CQDs, C-CQDs, G-CQDs, and Y-CQDs are 0.06%, 0.00%, 0.07% and 0.08%, 

respectively, which is consistent with the variation trend of fluorescence QYs. 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```



<!-- Start of picture text -->
a b c d<br>C1s<br>C1s C1s C1s O1s<br>O1s O1s O1s<br>N1s S2p N1s S2p N1s<br>S2p<br>S2p<br>900 800 700 600 500 400 300 200 100 900 800 700 600 500 400 300 200 100 900 800 700 600 500 400 300 200 100 900 800 700 600 500 400 300 200 100<br>Binding energy (eV) Binding energy (eV) Binding energy (eV) Binding energy (eV)<br>C1s C1s C1s C1s<br>C-C/C=C C-C/C=C C-C/C=C C-C/C=C<br>C=O C-O/C-N C=O C-O/C-N C-O/C-NC=O C=OC-O/C-N<br>292 290 288 286 284 282 292 290 288 286 284 282 292 290 288 286 284 282 292 290 288 286 284 282<br>Binding energy (eV) Binding energy (eV) Binding energy (eV) Binding energy (eV)<br>O1s O1s O1s O1s<br>C=O C=O C=O C=O<br>C-O<br>C-O<br>C-O<br>C-O<br>536 535 534 533 532 531 530 536 535 534 533 532 531 530 536 535 534 533 532 531 530 536 535 534 533 532 531 530<br>Binding energy (eV) Binding energy (eV) Binding energy (eV) Binding energy (eV)<br>N1s N1s N1s N1s<br>N-H C-N C-N<br>N-H<br>N-H<br>C-N<br>406 404 402 400 398 396 406 404 402 400 398 396 406 404 402 400 398 396 406 404 402 400 398 396<br>Binding energy (eV) Binding energy (eV) Binding energy (eV) Binding energy (eV)<br>S2p S2p S2p S2p<br>-C-SOx- -C-SOx- -C-SOx-<br>x=2,3,4 x=2,3,4 x=2,3,4<br>174 172 170 168 166 164 162 174 172 170 168 166 164 162 174 172 170 168 166 164 162 174 172 170 168 166 164 162<br>Binding energy (eV) Binding energy (eV) Binding energy (eV) Binding energy (eV)<br>()Intensita.u.y Intensity (a.u.) Intensity (a.u.) ()Intensita.u.y<br>Intensity (a.u.) Intensity (a.u.) ()Intensita.u.y Intensity (a.u.)<br>Intensity (a.u.) Intensity (a.u.) Intensity (a.u.) Intensity (a.u.)<br>Intensity (a.u.) Intensity (a.u.) Intensity (a.u.) Intensity (a.u.)<br>Intensity (a.u.) Intensity (a.u.) Intensity (a.u.) Intensity (a.u.)<br><!-- End of picture text -->

**Figure 4.** XPS spectra and High resolution XPS C 1s, O 1s, N 1s, S 2p spectra of (a) 

B-CQDs, (b) C-CQDs, (c) G-CQDs and (d) Y-CQDs. 

**Table 1** . XPS data analysis results. 

|**Sample**|**C**|**O**|**N**|**S**|**O/C**|**N/C**|**N-H**|**C-N**|**S/C**|**QY**|
|---|---|---|---|---|---|---|---|---|---|---|
||**/**%|**/**%|**/**%|**/**%|**/**%|**/**%|**/**%|**/**%|**/**%|**/**%|
|B-CQDs|55.50|40.87|3.56|0.07|0.74|0.06|77.21|22.79|0.00|10.8|
|C-CQDs|57.20|33.70|0.00|9.10|0.59|0.00|0.00|0.00|0.16|7.3|
|G-CQDs|59.40|32.55|4.31|3.74|0.55|0.07|40.77|59.23|0.06|23.6|
|Y-CQDs|63.70|28.22|4.82|3.26|0.44|0.08|34.09|65.91|0.05|30.5|



```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

Based on the above experimental evidences, it is reasonable to deduce that the synthesized four 

CQDs have extensive conjugated sp<sup>2</sup> domains, oxygen-containing surface groups along with small amount of heteroatoms (N or S) doping. The sp<sup>2</sup> conjugated degrees in the carbon core from B-CQDs to Y-CQDs increase while oxidation degree on the surface reduce with the red-shift of the emission wavelengths. 

### _3.3 Fluorescence mechanism of CQDs_ 

The time-resolved PL decay (TRPL) curves of the four CQDs are assessed at their maximum 

excitation wavelength (Figure 3d). The average lifetimes (τavg) of B-CQDs, C-CQDs, G-CQDs, and Y-CQDs are 1.42, 1.30, 1.56 and 2.94 ns, respectively, consistent with the variation trend of fluorescence QYs in term of the same carbon source (lignin). All the lifetimes demonstrate biexponentially fitted (τ1 and τ2) corresponding to two fluorescence-emission centers in the four 

CQDs. According to the fitting parameters of the four decay curves (Table S1) (in the Supporting Information), they all contain a fast component (τ1: 3.04, 3.79, 4.26, 4.59 ns) and a slow component (τ2: 28.67, 27.53 26.95, 7.09 ns). The former fluorescence-emission center is 

associated with the radiative recombination of eigenstates (carbon core with sp<sup>2</sup> hybrid domains), in which the electrons are excited in the form of π–π* transitions. However, the latter is correlated with recombination processes of surface state (O, N or S-containing functional 

groups), which is a forbidden transition and the electrons are excited in the form of an n–π* transition [33, 34]. In comparison, the lifetimes of τ1 gradually increase from B-CQDs to Y-CQDs in turn owing to the increased graphitization degree. In addition, the Y-CQDs and 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

G-CQDs possess a significantly larger percentage of τ1 (88.31and 54.34%) than the B-CQDs 

and C-CQDs (14.46% and 17.80%). That is, the fluorescence emission behaviors of Y-CQDs and G-CQDs with fewer surface defects are dominated by eigenstates of the conjugated sp<sup>2</sup> domains in the carbon core, while those of B-CQDs and C-CQDs mainly originate from the defects of surface states. 

The distinct optical energy band gaps (Eg) of the four CQDs further reflect the synergistic effect of the carbon core and surface states on the tunable PL behavior[34, 35]. The Eg (caculated by the absorption edge in the UV–vis spectra) decreases in the order of 2.47 eV of B-CQDs, 2.38 eV of C-CQDs, 2.35 eV of G-CQDs and 2.17 eV of Y-CQDs. The reduced Eg from B-CQDs to Y-CQDs is corresponding to the increasing red-shift emission wavelengths. According to the Equation S1 and S2 (in the Supporting Information), the energy levels of the lowest unoccupied molecular orbital (LUMO) and highest occupied molecular orbital (HOMO) can be obtained as displayed in Table S2 (in the Supporting Information). As described in Fig 5, the reduced Eg from B-CQDs to Y-CQDs is on account of the lower energy levels of LUMO or higher energy levels of HOMO. Based on the obtained morphology, optical and structural characterization results, the fluorescence mechanism of the four CQDs can be proposed accordingly. The synthesized four CQDs have internal sp<sup>2</sup> conjugate domains in their carbon cores and amorphous regions on their surfaces. It facilitates a red-shift PL emission wavelength at larger size and higher degrees of graphitization of the carbon nucleus [36]. Meanwhile, the existence of C=O with the strong electron negativity displays the electron-accepting property, decreasing 

the energy level of LUMO [35, 37]. The lattice doping of heteroatom (N or S) introduces the 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

additional energy level between π and π* of carbon, inducing multiple pathways of electron transitions (n→π*) both in absorption and PL emission. The radiative recombination takes place after the vibration relaxation and interband crossing [27, 32, 33, 38]. Compared to the absorbed photons, the energy of the emitted photons is reduced due to the Stokes shift. The excited electrons tend to emit longer wavelengths via interband crossing, exhibiting the red-shift PL spectra. Hence, the increased graphitization degree and structure defects of the CQDs play the key roles in the reduction of Eg. 

Particularly, the fluorescence QYs of the four lignin-derived CQDs are significantly improved in the order of C-CQDs (7.3%) < B-CQDs (10.8%) < G-CQDs (23.6%) < Y-CQDs (30.5%), the optimal QY of which is superior to the most of biomass-derived CQDs in the previously reported works [9, 10, 39, 40]. Based on the above XPS results listed in Table 1, the variation trend of N/C ratios agrees well with that of fluorescence QYs , implying the critical effect of N content on the enhancement of QYs. It is regarded that N exists in the form of amine-N and C-N, in which the amine-N contents decrease while the C-N contents increase with the increased fluorescence QYs. The C-N can be divided into pyridine-N, pyrrole-N, and graphite-N. The pyridine-N and pyrrole-N enable to create lattice defects to the carbon network and graphite-N contributes the replacement to C in the sp<sup>2</sup> carbon domain [20, 25, 41]. The C-N incorporated 

into the carbon skeleton with its two isolated electrons may increase the electron cloud density 

of the entire conjugated π-domain while reducing the non-radiative recombination center of the CQDs, thereby enhancing the fluorescence intensity of the three N-doped CQDs in this study 

(i.e. B-CQDs, G-CQDs and Y-CQDs). The superior PL performance of G-CQDs and Y-CQDs 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

compared with B-CQDs and C-CQDs might be attributed to the complicated synergistic effect 

of N and S [14, 19, 42]. It can be summarized the PL emission behavior of CQDs can be 

efficiently tuned through modulating the graphitization degree and surface defects. 



<!-- Start of picture text -->
LUMO (π*) Sp 2 carbon core<br>-2.99 eV<br>-3.27 eV -3.20 eV -3.26 eV<br>2.47 eV<br>Energy 2.38 eV 2.35 eV<br>2.17 eV<br>-5.37 eV<br>-5.43 eV<br>-5.74 eV -5.55 eV<br>HOMO (π)<br>hvex hvex hvex hvex<br>hvem hvem hvem hvem<br>Size 2.88 nm 4.01 nm 4.56 nm 5.05 nm<br>B-CQDs C-CQDs G-CQDs Y-CQDs<br>Graphitization degree increase<br>Red shift<br>Energy gap decrease<br><!-- End of picture text -->

**Figure 5.** Illustration of the _E_ g, HOMO, LUMO and possible structures of the four CQDs. 

### _3.4 Anti-counterfeit printing application_ 

The chemical stability of Y-CQDs concerning the pH-dependent PL performance is further 

evaluated for the anti-counterfeit printing application. There is disagreement whether pH can induce emission peak shift except for the definite influence of fluorescence intensity in the previous reports [15, 26, 43]. The pH-dependent fluorescence intensity is considered to be influenced by the protonation and deprotonation of oxygen-containing groups on the surface of CQDs, whereas the shift of emission peak at different pH may be related to the variation of 

surface defect states. To explore the influence mechanism of pH-dependent PL performance 

can help provide supporting evidence to reveal the origin of the PL emission for 

lignin-derived CQDs. The PL emission behavior of Y-CQDs is investigated over a wide pH 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

range of 3-11. As depicted in Figure 6, the optimal PL excitation and emission of Y-CQDs are 

centered at 450-455 nm and 515-520 nm, respectively, with no significant difference at the pH 

of 3-11. However, the PL emission behavior of Y-CQDs can be divided into two pH regions. 

In comparison with the pH of 3-6, the ranges of PL emission wavelengths at the pH of 7-11 

tend to expand toward shorter wavelengths of 400 nm, indicative of a slight blue-shift 

behavior. These findings demonstrate the excellent stability of Y-CQDs in different pH values. 

Based on the fluorescence mechanism analysis, the PL behavior Y-CQDs is dominated by the 

eigenstate owing to the high degree of graphitization. In particular, the heteroatom-related 

defect states have an increased impact on the PL emission as the pH in the region of 8-11. 



<!-- Start of picture text -->
a 700 b 700 c 700<br>pH=3 pH=4 pH=5<br>650 650 650<br>600 600 600<br>550 550 550<br>500 500 500<br>455 nm 455 nm 455 nm<br>450 450 450<br>400 400 400<br>350 350 350<br>300 300 300<br>300 350 400 450 500 550 600 650 700 300 350 400 450 500 550 600 650 700 300 350 400 450 500 550 600 650 700<br>d 700 Em (nm) e 700 Em (nm) f 700 Em (nm)<br>pH=6 pH=7 pH=8<br>650 650 650<br>600 600 600<br>550 550 550<br>500 500 500<br>450 455 nm 450 450 nm 450 450 nm<br>400 400 400<br>350 350 350<br>300 300 300<br>300 350 400 450 500 550 600 650 700 300 350 400 450 500 550 600 650 700 300 350 400 450 500 550 600 650 700<br>Em (nm) Em (nm) Em (nm)<br>g 700 h 70 0 i 700<br>pH=9 pH=10 pH=11<br>650 65 0 650<br>600 60 0 600<br>550 55 0 550<br>500 50 0 500<br>450 450 nm 45 0 450 nm 450 450 nm<br>400 40 0 400<br>350 35 0 350<br>300 30 0 300<br>300 350 400 450 500 550 600 650 700 300 350 400 450 500 550 600 650 700 300 350 400 450 500 550 600 650 700<br>Em (nm) Em (nm) Em (nm)<br>520 nm 520 nm 520 nm<br>Ex (nm) Ex (nm) Ex (nm)<br>520 nm 520 nm 515 nm<br>Ex (nm) Ex (nm) Ex (nm)<br>515 nm 515 nm 515 nm<br>Ex (nm) Ex (nm) Ex (nm)<br><!-- End of picture text -->

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

**Figure 6.** (a-i) The Excitation–emission matrix of Y-CQDs at different pH values ranging 

from 3 to 11. 

For the further exploration, the pH-dependent PL emission performances of Y-CQDs are investigated under the short and long excitation of 360 and 450 nm, respectively. As displayed in Figure 7a, the PL intensities excited by 360 nm remain relatively stable initially at pH of 3-6, while there is an increase in PL intensities at the further increasing of pH from 6 to 11. However, the PL intensities show no significant change under 450 nm excitation. This means that the pH-dependent PL behavior of Y-CQDs tends to occur at short excitation wavelengths. Specially, the PL emission spectra of Y-CQDs at different PH values are characterized under the excitation wavelengths of 360 and 440 nm, respectively (Figure 7b, c). The PL emission spectra of Y-CQDs display a gradual blue shift and a slight increased PL intensities at pH of 3-11 under 360 nm excitation, which can be clearly observed in Figure 8. This may be owing to 

the deprotonation as the increasing of pH from 7 to 11, which can reduce the aggregation caused by the hydrogen bonds [44]. On the contrary, the emission spectra of Y-CQDs under 450 nm excitation are almost insusceptible to the different pH values. The optimal emission peak position and PL intensities both exhibit good stability due to the large stokes shift under the long excitation wavelength, which can avoid self-quenching and re-emission [15]. 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```



<!-- Start of picture text -->
a b c<br>� Ex=360 nm Ex=360 nm pH=3 Ex=450 nm   pH=3<br>Ex=450 nm 1 1 3 pH=4   pH=4<br>pH=5   pH=5<br>pH=6   pH=6<br>pH=7   pH=7<br>pH=8   pH=8<br>pH=9   pH=9<br>pH=10   pH=10<br>pH=11   pH=11<br>2 3 4 5 6 7 8 9 10 11 12 400 450 500 550 600 650 400 450 500 550 600 650<br>pH Wavelength (nm) Wavelength (nm)<br>PL Intensity (a.u.) PL Intensity (a.u.) PL Intensity (a.u.)<br><!-- End of picture text -->

**Figure 7.** (a) The PL intensity of Y-CQDs at different pH values ranging from 3 to 11 

excited by 360 and 450 nm, respectively. The PL emission spectra of Y-CQDs at different pH 

values (3- 11) excited by (b) 360 nm and (c) 450 nm. 



<!-- Start of picture text -->
3 4 5 6 7 8 9 10 11<br><!-- End of picture text -->

**Figure 8.** Photograph of Y-CQDs in different pH buffers of 3 to 11 under 365 nm UV light 

The high-performance Y-CQDs show promising potential in anti-counterfeiting printing application [45, 46]. The experiment is carried out through a desktop inkjet printer (Canon inkjet MG2580S printer) with the aqueous solution of Y-CQDs as fluorescence inks (Figure 9a). The Y-CQDs inks are quickly recrystallized on paper fibers when printed on a 

non-fluorescent paper. As presented in Figure 9b, the printed patterns with Y-CQDs ink are nearly invisible and the texts are almost indistinguishable on the paper under daylight. However, theses printed patterns (Southeast University, QR code and paper currency) with 

bright yellowish green fluorescence appear under 365 nm UV light along with a background 

of blue fluorescence on the paper. After switching off the excitation, the fluorescent patterns 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

completely disappeared. Moreover, these photographs of printed patterns remain fluorescent 

stability after a week of sunlight exposure. It indicates that the as-prepared Y-CQDs-based 

fluorescent inks can exhibit the intriguing durability and reliability [47-49]. The Y-CQDs-based fluorescent inks with yellowish green color would develop the application for 

optical anti-counterfeiting printing, regarding its green preparation, invisibility under-daylight, 

facile designability and high chemical stability [50-53]. 



<!-- Start of picture text -->
a<br>Sunlight UV light<br>Day light UV light<br>b<br>365 nm<br>on<br>off<br><!-- End of picture text -->

**Figure 9.** Anti-counterfeit printing application of the Y-CQDs. (a) Schematic illustrations 

of a customized desktop inkjet printer with the aqueous solutions of Y-CQDs in its cartridge. (b) 

Photographs of the Y-CQDs ink dispersion in daylight and under 365 nm UV light. 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

## **4. Conclusions** 

The green synthesis of tunable fluorescent CQDs from alkali lignin and acid additives (4-aminobenzoic acid, benzenesulfonic acid, 4-aminobenzene sulfonic acid, etc.) is achieved 

via a facile two-step method. The obtained N or S doped CQDs display a profuse color evolution from blue to yellowish green by varying different acid additives, in which the N, S co-doped CQDs with the adding of 2, 4-diaminobenzene sulfonic acid have the optimal fluorescence QY of 30.5%. The red-shift PL emission behavior is consistent with variation 

trend of the increased graphitization degree and reduced energy gaps of the CQDs. The fluorescence QYs are explained to be dominated by the N content and the synergistic effect of 

N and S co-doping. The high-efficient yellowish green-emissive CQDs are successfully 

utilized as fluorescence inks for the anti-counterfeiting printing. This work highlights the advanced strategy for the green production of high-performance CQDs from renewable lignin 

and promotes sustainable application development and environmental protection. 

## **Declaration of Competing Interest** 

The authors declare that they have no known competing financial interests or personal 

relationships that could have appeared to influence the work reported in this paper. 

## **Acknowledgements** 

The authors gratefully acknowledge the financial support from National Natural Science 

Foundation of China (grant numbers. 51676047 and 51861145102) and the Key Research & 

Development Program of Jiangsu Province (grant number: BE2020114). The authors also 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

acknowledge the funding support from the Scientific Research Foundation of Graduate School 

of Southeast University, China (YBPY2109) and Postgraduate Research & Practice Innovation 

Program of Jiangsu Province from the Education Department of Jiangsu (KYCX21_0094). 

## **Appendix A. Supplementary data** 

The Supporting Information is available free of charge at 

## **References** 

- [1] Luo, H. and Abu-Omar, M. M., Lignin extraction and catalytic upgrading from genetically modified poplar, _Green Chemistry_ . **2018** , 20, 745-753. 

- [2] Zhao, W.;Xiao, L.-P.;Song, G.;Sun, R.-C.;He, L.;Singh, S.;Simmons, B. A. and Cheng, G., From lignin subunits to aggregates: insights into lignin solubilization, _Green Chemistry_ . 

**2017** , 19, 3272-3281. 

- [3] Hallac, B. B. and Ragauskas, A. J., Analyzing cellulose degree of polymerization and its relevancy to cellulosic ethanol, _Biofuels, Bioproducts and Biorefining_ . **2011** , 5, 215-225. 

- [4] Nagarajan, S.;Skillen, N. C.;Irvine, J. T. S.;Lawton, L. A. and Robertson, P. K. J., Cellulose II as bioethanol feedstock and its advantages over native cellulose, _Renewable and Sustainable Energy Reviews_ . **2017** , 77, 182-192. 

- [5] Phongpreecha, T.;Hool, N. C.;Stoklosa, R. J.;Klett, A. S.;Foster, C. E.;Bhalla, A.;Holmes, 

   - D.;Thies, M. C. and Hodge, D. B., Predicting lignin depolymerization yields from 

   - quantifiable properties using fractionated biorefinery lignins, _Green Chem._ **2017** , 19, 5131-5143. 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

- [6] Gómez-Monedero, B.;Ruiz, M. P.;Bimbela, F. and Faria, J., Selective hydrogenolysis of α 

   - O 4, β O 4, 4 O 5 C O bonds of lignin-model compounds and lignin-containing stillage derived from cellulosic bioethanol processing, _Applied Catalysis A: General_ . **2017** , 541, 60-76. 

- [7] Zhu, L. and Zhong, Z., Effects of cellulose, hemicellulose and lignin on biomass pyrolysis 

   - kinetics, _Korean Journal of Chemical Engineering_ . **2020** , 37, 1660-1668. 

- [8] Nair, A. N.;Chava, V. S. N.;Bose, S.;Zheng, T.;Pilla, S. and Sreenivasan, S. T., In Situ 

Doping-Enabled Metal and Nonmetal Codoping in Graphene Quantum Dots: Synthesis and Application for Contaminant Sensing, _Acs Sustainable Chemistry & Engineering_ . **2020** , 8, 16565-16576. 

- [9] Zhu, L.;Shen, D.;Wu, C. and Gu, S., State-of-the-Art on the Preparation, Modification, 

   - and Application of Biomass-Derived Carbon Quantum Dots, _Industrial & Engineering Chemistry Research_ . **2020** , 59, 22017-22039. 

- [10] Abbas, A.;Mariana, L. T. and Phan, A. N., Biomass-waste derived graphene quantum dots and their applications, _Carbon_ . **2018** , 140, 77-99. 

- [11] Lu, H.;Li, W.;Dong, H. and Wei, M., Graphene Quantum Dots for Optical Bioimaging, _Small_ . **2019** , 15, e1902136. 

- [12] Lim, S. Y.;Shen, W. and Gao, Z., Carbon quantum dots and their applications, _Chemical_ 

   - _Society Reviews_ . **2015** , 44, 362-381. 

- [13] Si, M.;Zhang, J.;He, Y.;Yang, Z.;Yan, X.;Liu, M.;Zhuo, S.;Wang, S.;Min, X.;Gao, C.;Chai, 

   - L. and Shi, Y., Synchronous and rapid preparation of lignin nanoparticles and carbon 

   - quantum dots from natural lignocellulose, _Green Chemistry_ . **2018** , 20, 3414-3419. 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

- [14] Wang, R.;Xia, G.;Zhong, W.;Chen, L.;Chen, L.;Wang, Y.;Min, Y. and Li, K., Direct transformation of lignin into fluorescence-switchable graphene quantum dots and their application in ultrasensitive profiling of a physiological oxidant, _Green Chemistry_ . **2019** , 21, 3343-3352. 

- [15] Zhang, B.;Liu, Y.;Ren, M.;Li, W.;Zhang, X.;Vajtai, R.;Ajayan, P. M.;Tour, J. M. and Wang, L., Sustainable Synthesis of Bright Green Fluorescent Nitrogen-Doped Carbon Quantum Dots from Alkali Lignin, _Chemsuschem_ . **2019** , 12, 4202-4210. 

- [16] Li, Y.;Ren, J.;Sun, R. and Wang, X., Fluorescent Lignin Carbon Dots for Reversible Responses to High-Valence Metal Ions and Its Bioapplications, _Journal of Biomedical Nanotechnology_ . **2018** , 14, 1543-1555. 

- [17] Yang, X.;Guo, Y.;Liang, S.;Hou, S.;Chu, T.;Ma, J.;Chen, X.;Zhou, J. and Sun, R., Preparation of sulfur-doped carbon quantum dots from lignin as a sensor to detect Sudan I in an acidic environment, _J Mater Chem B_ . **2020** , 8, 10788-10796. 

- [18] Ding, Z.;Li, F.;Wen, J.;Wang, X. and Sun, R., Gram-scale synthesis of single-crystalline graphene quantum dots derived from lignin biomass, _Green Chemistry_ . **2018** , 20, 1383-1390. 

- [19] Wang, R.;Jiao, L.;Zhou, X.;Guo, Z.;Bian, H. and Dai, H., Highly fluorescent graphene quantum dots from biorefinery waste for tri-channel sensitive detection of Fe3+ ions, _Journal of hazardous materials_ . **2021** , 412, 125096-125096. 

- [20] Zhang, H.;Kang, S.;Wang, G.;Zhang, Y. and Zhaou, H., Fluorescence Determination of 

   - Nitrite in Water Using Prawn-Shell Derived Nitrogen-Doped Carbon Nanodots as Fluorophores, _Acs Sensors_ . **2016** , 1, 875-881. 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

- [21] Zhao, J.;Peng, Y.;Yang, K.;Chen, Y.;Zhao, S. and Liu, Y.-M., A new ratiometric fluorescence assay based on resonance energy transfer between biomass quantum dots and organic dye for the detection of sulfur dioxide derivatives, _RSC Advances_ . **2019** , 9, 41955-41961. 

- [22] Zhu, L.;Shen, D.;Liu, Q.;Wu, C. and Gu, S., Sustainable synthesis of bright green fluorescent carbon quantum dots from lignin for highly sensitive detection of Fe3+ ions, _Applied Surface Science_ . **2021** , 565. 

- [23] Wang, B.;Song, H.;Tang, Z.;Yang, B. and Lu, S., Ethanol-derived white emissive carbon dots: the formation process investigation and multi-color/white LEDs preparation, _Nano Research_ . **2021** , DOI: 10.1007/s12274-021-3579-5. 

- [24] Jing, S.;Zhao, Y.;Sun, R.-C.;Zhong, L. and Peng, X., Facile and High-Yield Synthesis of Carbon Quantum Dots from Biomass-Derived Carbons at Mild Condition, _Acs Sustainable Chemistry & Engineering_ . **2019** , 7, 7833-7843. 

- [25] Liu, Y.;Yang, H.;Ma, C.;Luo, S.;Xu, M.;Wu, Z.;Li, W. and Liu, S., Luminescent Transparent Wood Based on Lignin-Derived Carbon Dots as a Building Material for Dual-Channel, Real-Time, and Visual Detection of Formaldehyde Gas, _ACS Appl Mater Interfaces_ . **2020** , 12, 36628-36638. 

- [26] Shi, Y.;Liu, X.;Wang, M.;Huang, J.;Jiang, X.;Pang, J.;Xu, F. and Zhang, X., Synthesis of 

   - N-doped carbon quantum dots from bio-waste lignin for selective irons detection and cellular imaging, _International Journal of Biological Macromolecules_ . **2019** , 128, 537-545. 

- [27] Wang, G.;Guo, G.;Chen, D.;Liu, Z.;Zheng, X.;Xu, A.;Yang, S. and Ding, G., Facile and 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

Highly Effective Synthesis of Controllable Lattice Sulfur-Doped Graphene Quantum Dots 

via Hydrothermal Treatment of Durian, _Acs Applied Materials & Interfaces_ . **2018** , 10, 5750-5759. 

- [28] Yang, H.;Liu, Y.;Guo, Z.;Lei, B.;Zhuang, J.;Zhang, X.;Liu, Z. and Hu, C., Hydrophobic carbon dots with blue dispersed emission and red aggregation-induced emission, _Nature Communications_ . **2019** , 10. 

- [29] Park, M.;Kim, H. S.;Yoon, H.;Kim, J.;Lee, S.;Yoo, S. and Jeon, S., Controllable Singlet-Triplet Energy Splitting of Graphene Quantum Dots through Oxidation: From Phosphorescence to TADF, _Adv Mater_ . **2020** , 32, e2000936. 

- [30] Li, H.;Han, S.;Lyu, B.;Hong, T.;Zhi, S.;Xu, L.;Xue, F.;Sai, L.;Yang, J.;Wang, X. and He, 

   - B., Tunable light emission from carbon dots by controlling surface defects, _Chinese Chemical Letters_ . **2021** , DOI: 10.1016/j.cclet.2021.03.051. 

- [31] Chen, Y.;Lian, H.;Wei, Y.;He, X.;Chen, Y.;Wang, B.;Zeng, Q. and Lin, J., Concentration-induced multi-colored emissions in carbon dots: origination from triple fluorescent centers, _Nanoscale_ . **2018** , 10, 6734-6743. 

- [32] Hola, K.;Sudolska, M.;Kalytchuk, S.;Nachtigallova, D.;Rogach, A. L.;Otyepka, M. and 

   - Zboril, R., Graphitic Nitrogen Triggers Red Fluorescence in Carbon Dots, _Acs Nano_ . **2017** , 11, 12402-12410. 

- [33] Li, X.;Lau, S. P.;Tang, L.;Ji, R. and Yang, P., Sulphur doping: a facile approach to tune the 

   - electronic structure and optical properties of graphene quantum dots, _Nanoscale_ . **2014** , 6, 5323-5328. 

- [34] Zhang, T.;Zhu, J.;Zhai, Y.;Wang, H.;Bai, X.;Dong, B.;Wang, H. and Song, H., A novel 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

mechanism for red emission carbon dots: hydrogen bond dominated molecular states emission, _Nanoscale_ . **2017** , 9, 13042-13051. 

- [35] Liao, X.;Chen, C.;Zhou, R.;Huang, Q.;Liang, Q.;Huang, Z.;Zhang, Y.;Hu, H. and Liang, Y., Comparison of N-doped carbon dots synthesized from the main components of plants including cellulose, lignin, and xylose: Characterized, fluorescence mechanism, and potential applications, _Dyes and Pigments_ . **2020** , 183. 

- [36] Zheng, Y.;Arkin, K.;Hao, J.;Zhang, S.;Guan, W.;Wang, L.;Guo, Y. and Shang, Q., Multicolor Carbon Dots Prepared by Single� Factor Control of Graphitization and Surface Oxidation for High� Quality White Light� Emitting Diodes, _Advanced Optical Materials_ . **2021** , DOI: 10.1002/adom.202100688. 

- [37] Feng, J.;Dong, H.;Yu, L. and Dong, L., The optical and electronic properties of graphene quantum dots with oxygen-containing groups: a density functional theory study, _Journal of Materials Chemistry C_ . **2017** , 5, 5984-5993. 

- [38] Yuan, Y. H.;Liu, Z. X.;Li, R. S.;Zou, H. Y.;Lin, M.;Liu, H. and Huang, C. Z., Synthesis of nitrogen-doping carbon dots with different photoluminescence properties by controlling the surface states, _Nanoscale_ . **2016** , 8, 6770-6776. 

- [39] Bhandari, S.;Mondal, D.;Nataraj, S. K. and Balakrishna, R. G., Biomolecule-derived quantum dots for sustainable optoelectronics, _Nanoscale Advances_ . **2019** , 1, 913-936. 

- [40] Kang, C.;Huang, Y.;Yang, H.;Yan, X. F. and Chen, Z. P., A Review of Carbon Dots Produced from Biomass Wastes, _Nanomaterials_ . **2020** , 10. 

- [41] Wang, L.;Li, B.;Xu, F.;Shi, X.;Feng, D.;Wei, D.;Li, Y.;Feng, Y.;Wang, Y.;Jia, D. and Zhou, 

   - Y., High-yield synthesis of strong photoluminescent N-doped carbon nanodots derived 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

from hydrosoluble chitosan for mercury ion sensing via smartphone APP, _Biosensors &_ 

_Bioelectronics_ . **2016** , 79, 1-8. 

- [42] Hu, Y.;Zhang, L.;Li, X.;Liu, R.;Lin, L. and Zhao, S., Green Preparation of S and N Co-Doped Carbon Dots from Water Chestnut and Onion as Well as Their Use as an Off On Fluorescent Probe for the Quantification and Imaging of Coenzyme A, _Acs Sustainable Chemistry & Engineering_ . **2017** , 5, 4992-5000. 

- [43] Yang, P.;Zhu, Z.;Zhang, T.;Chen, M.;Cao, Y.;Zhang, W.;Wang, X.;Zhou, X. and Chen, W., 

   - Facile synthesis and photoluminescence mechanism of green emitting xylose-derived carbon dots for anti-counterfeit printing, _Carbon_ . **2019** , 146, 636-649. 

- [44] Song, Z.;Quan, F.;Xu, Y.;Liu, M.;Cui, L. and Liu, J., Multifunctional N,S co-doped carbon 

   - quantum dots with pH- and thermo-dependent switchable fluorescent properties and highly selective detection of glutathione, _Carbon_ . **2016** , 104, 169-178. 

- [45] Yang, X.-C.;Li, Q.;Tang, M.;Yang, Y.-L.;Yang, W.;Hu, J.-F.;Pu, X.-L.;Liu, J.;Zhao, J. and 

   - Zhang, Z.-J., One Stone, Two Birds: pH- and Temperature-Sensitive Nitrogen-Doped Carbon Dots for Multiple Anticounterfeiting and Multiple Cell Imaging, _Acs Applied Materials & Interfaces_ . **2020** , 12, 20849-20858. 

- [46] Zhao, J.;Zheng, Y.;Pang, Y.;Chen, J.;Zhang, Z.;Xi, F. and Chen, P., Graphene quantum dots as full-color and stimulus responsive fluorescence ink for information encryption, _J Colloid Interface Sci_ . **2020** , 579, 307-314. 

- [47] Jiang, K.;Wang, Y.;Gao, X.;Cai, C. and Lin, H., Facile, Quick, and Gram-Scale Synthesis 

   - of Ultralong-Lifetime Room-Temperature-Phosphorescent Carbon Dots by Microwave Irradiation, _Angewandte Chemie-International Edition_ . **2018** , 57, 6216-6220. 

```
 1
 2
 3
 4
 5
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
```

- [48] Lin, C.;Zhuang, Y.;Li, W.;Zhou, T.-L. and Xie, R.-J., Blue, green, and red full-color ultralong afterglow in nitrogen-doped carbon dots, _Nanoscale_ . **2019** , 11, 6584-6590. 

- [49] Long, P.;Feng, Y.;Cao, C.;Li, Y.;Han, J.;Li, S.;Peng, C.;Li, Z. and Feng, W., Self-Protective Room-Temperature Phosphorescence of Fluorine and Nitrogen Codoped Carbon Dots, _Advanced Functional Materials_ . **2018** , 28. 

- [50] Jiang, K.;Wang, Y.;Cai, C. and Lin, H., Conversion of Carbon Dots from Fluorescence to Ultralong Room-Temperature Phosphorescence by Heating for Security Applications, _Advanced Materials_ . **2018** , 30. 

- [51] Atchudan, R.;Edison, T. N. J. I.;Aseer, K. R.;Perumal, S.;Karthik, N. and Lee, Y. R., Highly fluorescent nitrogen-doped carbon dots derived from Phyllanthus acidus utilized as a fluorescent probe for label-free selective detection of Fe3+ ions, live cell imaging and fluorescent ink, _Biosensors & Bioelectronics_ . **2018** , 99, 303-311. 

- [52] Jiang, K.;Zhang, L.;Lu, J.;Xu, C.;Cai, C. and Lin, H., Triple-Mode Emission of Carbon 

   - Dots: Applications for Advanced Anti-Counterfeiting, _Angewandte Chemie-International Edition_ . **2016** , 55, 7231-7235. 

- [53] Guo, J.;Li, H.;Ling, L.;Li, G.;Cheng, R.;Lu, X.;Xie, A.-Q.;Li, Q.;Wang, C.-F. and Chen, 

   - S., Green Synthesis of Carbon Dots toward Anti-Counterfeiting, _Acs Sustainable Chemistry & Engineering_ . **2020** , 8, 1566-1572. 

���������������������� 

����������������������������� ���������������������� ��������������������������� 

��������������������������������� 

# **Declaration of Interest Statement** 

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper. 

