# A near-infrared colloidal quantum dot imager with monolithically integrated readout circuitry

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Electronics |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 293 |
| 作者 | Jing Liu, Peilin Liu, Dengyang Chen, Tailong Shi, Xixi Qu, Long Chen, Tong Wu, Jiangping Ke et al. |
| DOI | 10.1038/s41928-022-00779-x |
| 源文件 | 066_Liu_2022_A-near-infrared-colloidal-quantum-dot-imager-wit.pdf |

---




<!-- Start of picture text -->
A High -r esolution Colloidal Quantum Dot Imager by<br>Monolithic Integration<br>Jing Liu<br><!-- End of picture text -->

Huazhong University of Science and Technology 

Huazhong University of Science and Technology 

Hisilicon Optoelectronics Co., Ltd. 

Huazhong University of Science and Technology 

Hisilicon Optoelectronics Co., Ltd. 

Huazhong University of Science and Technology 

Huazhong University of Science and Technology 

Huazhong University of Science and Technology 

Huazhong University of Science and Technology 

Huazhong University of Science and Technology 

Huazhong University of Science and Technology 

Hisilicon Optoelectronics Co., Ltd. 

Hisilicon Optoelectronics Co., Ltd. 

Huazhong University of Science and Technology https://orcid.org/0000-0003-0642-3939 

Huazhong University of Science and Technology 

Jiang Tang  (  jtang@mail.hust.edu.cn ) 

Huazhong University of Science and Technology https://orcid.org/0000-0003-2574-2943 

Page 1/18 

Keywords: Near-infrared imagers, infrared imagers, high-resolution colloidal quantum dot imagers 

Posted Date: July 13th, 2021 

https://doi.org/10.21203/rs.3.rs-677155/v1 

License:   This work is licensed under a Creative Commons Attribution 4.0 International License. Read Full License 

Page 2/18 

Near-infrared (NIR, 0.7–1.4 µm) imagers have wide applications in night surveillance, material sorting, machine vision and potentially automatic driving. However, limited by the high-temperature processing and requirement of single-crystalline substrate, so far �ip-chip is the dominant way to connect infrared photodiodes and silicon-based readout integrated circuit (ROIC) to produce infrared imagers, suffering from complicated process and ultra-high cost and hence limiting their widespread applications in the market. Here we report the monolithic integration of colloidal quantum dots (CQD) photodiodes with complementary metal-oxide-semiconductor (CMOS) ROIC, operating as a low-cost and high-performance imager. The CQD photodetector is well designed with a CMOS-compatible structure, demonstrating a response spectral range of 400–1300 nm, a detectivity of 2.1×10<sup>12</sup> Jones at room temperature, a -3dB bandwidth of 140 kHz and a linear dynamic range over 100 dB. The CQD imager can identify materials, inspect apple scar and veins with a large size of 640×512 pixels and a spatial resolution of 40 lp/mm at a modulation transfer function of 50%. Monolithic integration signi�cantly reduces the cost without sacri�cing performance, thus providing huge potential for the ubiquitous deployment of infrared imagers. 

Imagers, by integration of photodetector array with silicon readout integrated circuit (ROIC) to convert incident light into electrical signals, are the foundation of light-sensing technology widely used in machine vision<sup>1-3</sup> , security monitoring<sup>4-6</sup> , bioimaging<sup>7</sup> and other emerging �elds. For visible imagers, homogeneous silicon photodiodes are monolithically integrated with silicon ROIC, dominating visible imaging with ultralow cost and excellent performance. However, for infrared imagers, the fabrication of InGaAs, InSb and HgCdTe photodetectors need high quality single-crystalline substrates and high temperature vacuum processing, ruling out their direct integration with ROIC. Therefore, these photodetectors are exclusively heterogeneously integrated with silicon ROIC via wire-bonding or indium solder bumps for infrared imaging at exponentially increased cost and impaired performance<sup>8-10</sup> . The prohibitive price is the main reason that such infrared imagers have their limited application in military and industry and fail to penetrate into everyday life such for cell phones despite they could provide much valuable information unseen by the visible imager. 

Colloidal quantum dot (CQD) is one kind of solution-processed nanocrystal possessing a size tunable bandgap covering from visible to long-wavelength infrared. Monolithic integration of PbS CQD with silicon ROIC promises high resolution and cost reduction, thus providing the most affordable way for large scale deployment of infrared imagers. Optimization of CQD photodiodes are well studied yet their integration with ROIC for imaging is much less reported. PbS CQD was �rst reported to sensitize organic materials on TFT with 256×256 pixels (pixel size of 154 μm) for longer-wavelength imaging<sup>11</sup> . The organic/CQD TFT imager worked at high reverse bias (-5 V) with large dark current (>1 μA/cm<sup>2</sup> ), low external quantum e�ciency (<20%) and limited -3dB bandwidth (~2 kHz). The large pixel size and poor pixel homogeneity limited the imaging resolution. Another report of CQD/graphene imager using CQD to 

Page 3/18 

sensitize graphene showed very high responsivity (~10<sup>7</sup> A W<sup>-1</sup> ) and detectivity (>10<sup>12</sup> Jones) but suffered from low -3dB bandwidth (~0.16 kHz), large dark current and slow imaging frame rate<sup>12</sup> . Furthermore, its resolution was severely restricted by very poor pixel homogeneity due to the strong bias dependent resistance and photoresponse associated with the horizontal CQD/graphene phototransistors con�guration. 

Here we present a high-performance near-infrared imager by monolithic integration of top-illuminated CQD photodiodes and large-scale (640×512) COMS ROIC. The device structure and fabrication procedure of PbS CQD photodiodes were well optimized to ensure CMOS-compatibility, good homogeneity, low dark current and high external quantum e�ciency. After integration, our CQD imager showed a high resolution of 640×512, a pixel size of 15 μm and a modulation transfer function of 40 lp/mm at a modulation transfer function of 50%, and it produced infrared images with quality comparable with the commercial InGaAs imager. We further demonstrated the applications of our CQD imager for matter authentication and vein imaging. 

Fig. 1| Design of COMS ~~-c~~ ompatible PbS CQD photodiode. a, Integration of readout circuit and top illuminated photodiode. ETL means electron transport layer and HTL means hole transport layer. b, Carrier transmission in CQD photodiodes illuminated through top (n-type) and bottom (p-type) sides. c, Steady-state responses of PbS CQD photodiodes with or without fullerene (C60) layer. Defect density pro�les of PbS CQD photodiodes without (d) and with (e) C60 by capacitance-voltage measurement and drive-level capacitance pro�ling. f, External quantum e�ciency (EQE) of double-side PbS CQD photodiodes illuminated through top and bottom sides. 

For ROIC integration, photodiodes need to be top illuminated to enable incident light absorption and signal acquisition. Con�guration of our CQD imager is schematically shown in Fig. 1a, where the photosensitive CQD devices are directly integrated onto ROIC with a transparent conductive oxide on top to enable top illumination. The depletion region of the photodiode close to illumination side prompts the e�cient drift of photo-generated carriers by the built-in electric �eld rather than diffusion as shown in Fig. 1b. However, most of high-performing CQD photodiodes reported in literature are bottom-illuminated<sup>13-15</sup> ; top illuminated CQD photodiode is rarely reported with high-quality junction and favorable stability possibly due to the di�culty of depositing a high-quality transparent conductive oxide on top without damaging the bottom vulnerable CQD layer. 

The structure of our PbS CQD photodiode is NiOx/PbS CQD/ZnO as shown in supplementary Fig. S1a. We chose sputtered NiOx and ZnO as the hole and electron collection layer respectively for its proper band position, high stability, high reproducibility and easy manufacturability. Solution processed NiOx and ZnO layers have been extensively explored at the beginning of this project but eventually discarded due to its unsatisfactory reproducibility despite they often produced devices with high performance. PbS CQD was synthesized from the cation-exchange strategy<sup>16,17</sup> and are monodispersed with an absorption peak at 

Page 4/18 

920 nm as shown in supplementary Fig. S1b-c. The sputtered NiOx and ZnO �lms are super smooth with roughness of 1.3 nm and 2.1 nm and the ZnO �lm is well oriented along [002] direction (supplementary Fig. S1d-f). The NiOx/PbS CQD/ZnO photodiode shows over 3 orders of recti�cation but poor photoresponse (external quantum e�ciency, EQE < 0.4%) in Fig. 1c. 

We suspect that poor junction quality accounts for the extremely low EQE. We thus sought for drive-level capacitance pro�ling (DLCP) and capacity-voltage (C-V) measurements to characterize our photodiode. Since DLCP is only sensitive to the bulk defects and C-V reveals both interface and bulk traps<sup>18</sup> (supplementary Fig. S2a-b), the interfacial defect density can be estimated from NA,CV-NA,DLCP as 5.8×10<sup>16</sup> cm<sup>-3</sup> in Fig. 1d. This value is much higher than that of the solution-processed ZnO nanoparticle/PbS CQD photodiode as 2×10<sup>16</sup> cm<sup>-3</sup> due to the interface destruction during ZnO sputtering<sup>19</sup> . A thin layer of fullerene (C60) with strong C-C bond and consequently mechanical and electrical robustness was chosen to protect the interface. Thermal evaporation was selected for its gentle deposition and less damage caused to the CQD layer. After careful optimization of the C60 layer, the NiOx/PbS CQD/C60/ZnO photodiode shows excellent photoresponse (dark current density Jd ~17.8 nA cm<sup>-2</sup> , EQE ~60% @ -0.5 V) in Fig. 1c, attributed to the better junction quality as the evidenced lower interface density of 2.3×10<sup>16</sup> cm<sup>-3</sup> as shown in Fig. 1e. 

The optimal thickness of CQD layer is demonstrated in supplementary Fig. S3 by using a double-side illuminated device structure of ITO/NiOx/PbS CQD/C60/ZnO/ITO. As the light comes from ZnO side (top illuminated mode), the EQE is about 1.5 times that in the back illuminated mode (from NiOx side) as shown in Fig. 1f. The EQE increases along with the thickness of PbS CQD layer, but the Jd reaches a minimum 30.1 nA cm<sup>-2</sup> at the thickness of 600 nm. Such an optimal thickness is further veri�ed by SCAPS simulation in supplementary Fig. S4-5 and Table 1. The EQE at short wavelength in the top illuminated mode is almost one order of magnitude higher than in the back illuminated mode, further proving that top-illuminated mode helps to charge collection because most of photo-generated carriers are swept by the built-in �eld instead of circuitous diffusion. 

Fig. 2| Performance of CMOS ~~-c~~ ompatible PbS CQD photodiodes. a, Steady-state response of PbS CQD photodiode under 970 nm LED illumination with power densities varied from 100 nW cm<sup>-2</sup> to 100 mW cm<sup>-</sup> 2. b, Linear dynamic range (LDR) of PbS CQD photodiode at -0.5 V bias. c, External quantum e�ciency and responsivity spectra, d, Response bandwidth and e, Transient response of PbS CQD photodiode at -0.5 V bias. f, Measured current noise of PbS CQD photodiode as a function of frequency at -0.5 V bias. The calculated shot noise, 1/f noise, and generation-recombination (G-R) noise limit are also included for reference. g, Speci�c detectivity (D*) and bandwidth statistics of PbS CQD photodetectors reported in literature. Filled black triangles: measured D* for PbS CQD photodiodes (a<sup>20</sup> , b<sup>21</sup> , c<sup>14</sup> , d<sup>13</sup> , e<sup>15</sup> ). Hollow triangles: calculated D* for PbS CQD photodetectors (f<sup>22</sup> , g<sup>23</sup> , h<sup>24</sup> , i<sup>25</sup> ). Filled red squares: measured D* for PbS CQD photodetectors for readout circuit (ROIC) integration. (j<sup>12</sup> , k<sup>11</sup> ). Blue pentagram: measured D* in 

Page 5/18 

this work (deep blue: under zero bias (self-powered state), light blue: at -0.5 V bias). h, Stability of PbS CQD photodiodes in air at room temperature. i, Homogeneity of PbS CQD photodiodes. N represents the number of devices. 

In order to comprehensively evaluate the performance of the top-illuminated PbS CQD photodiodes, the �gure of merits were carefully measured and compared with other PbS CQD photodetectors. The currentvoltage (I-V) curves of the device are shown in Fig. 2a under a 970 nm LED illumination with power density varied from 100 nW cm<sup>-2</sup> to 100 mW cm<sup>-2</sup> . The device demonstrates a high recti�cation ratio over 2000 at ±1 V in the dark state. The Jd is as low as 17.8 nA cm<sup>-2</sup> at -0.5 V bias and almost �ve orders of magnitude lower than photocurrent under 10 mW cm<sup>-2</sup> illumination. The photocurrent remains constant at bias from -1 to -0.5 V, revealing photogenerated carriers are completely collected by the built-in electric �eld with the assistance of an external bias. Such a �at photoresponse is important for real application because any abnormal voltage �uctuation near the working bias from the ROIC would cause negligible interference on the signal intensity and thus enable authentic imaging. When the light power received by the device ranges from ~7 nW to 0.7 mW, the photocurrent is linearly proportional to the light intensity as shown in Fig. 2b. The measured linear dynamic range (LDR) is thus calculated greater than 100 dB at -0.5 V bias and 80 dB at self-powered state (zero bias) as shown in Supplementary Fig. S6a, restricted by unattainable weaker or stronger light source. The lowest detectable light intensity of the device at selfpowered state is about 1.9 pW at a signal-to-noise ratio of 1, identi�ed by electronic noise measurement in supplementary Fig. S7. The estimated LDR of the device is over 150 dB, which is close to the measured LDR of 160 dB of silicon diode<sup>26</sup> . 

The broadband spectral response at -0.5 V bias in Fig. 2c ensures that the device works over a wide spectral range from 390 to 1300 nm. The responsivity and EQE are as high as 0.46 A W<sup>-1</sup> and 63% at 970 nm, respectively. And the device also has favorable performance at self-powered state with an EQE about 28% at 970 nm (supplementary Fig. S6c). The bumpy EQE spectrum is somewhat unexpected, and we ascribe the peak at ~970 nm to the excitonic absorption and peaks between 400-800 nm to optical interference. The frequency response is shown in Fig. 2d, suggesting the fast response of the PbS CQD photodiode with a -3dB bandwidth up to 140 kHz. Furthermore, the transient response of the device in Fig. 2e reveals the rising and falling time are respectively 490 ns and 1.15 μs, echoing the observed -3dB bandwidth. At self-powered state, the -3 dB bandwidth is 60 kHz (supplementary Fig. S6b), and the rising and falling time are respectively 670 ns and 1.86 μs (supplementary Fig. S6d). This photoresponse is fast enough to permit imaging application which is often working at a speed of 30 frames per second. 

Fig. 2f illuminates the frequency dependent current noise spectrum of PbS CQD photodiode measured by lock-in ampli�er at -0.5 V bias within 10<sup>-14</sup> -10<sup>-13</sup> A Hz<sup>-1/2</sup> . The total noise is contributed by shot noise, 1/f noise, and generation-recombination (G-R) noise as calculated in supplementary Method. The calculated total noise is plotted as red line in Fig. 2f, ideally �tting with the measured noise spectrum. At frequency < 1 kHz, the noise is mainly originated from the 1/f noise due to the scattering between CQDs and at the interface between different functional layers<sup>27,28</sup> . At frequency > 1 kHz, the shot noise and G-R noise 

Page 6/18 

primarily determine the noise of our photodiode. Furthermore, the current noise at self-powered state is shown in supplementary Fig. S6e within 10<sup>-15</sup> -10<sup>-14</sup> A Hz<sup>-1/2</sup> . The measured room temperature speci�c detectivity (D<sup>*</sup> ) is displayed in supplementary Method and Fig. S6f-g. The optimal D<sup>*</sup> of PbS CQD photodiode is respectively 1.5×10<sup>11</sup> Jones at -0.5 V bias and 2.1×10<sup>12</sup> Jones at self-powered state, which is comparable to the commercial InGaAs photodiode (~4×10<sup>12</sup> Jones) at 1000 nm<sup>4</sup> . The frequency dependent noise equivalent power (NEP) is 9.5×10<sup>-14</sup> W at 10 Hz as shown in supplementary Fig. S6h. The estimated lowest detectable power is 1.9 pW by extrapolating photocurrent equal to noise current<sup>26</sup> (signal-to-noise ratio of 1) in supplementary Fig. S7. 

The �gure of merits of PbS CQD photodetectors are summarized in supplementary Table S2 and Fig. 2g. The product of bandwidth and D* is decided by the quality of photodiodes, and the balance between bandwidth and D* has great effect on fast and sensitive photodetection. Our CQD photodiode presents the most balanced performance in bandwidth and measured D<sup>*</sup> , the highest LDR and ROIC-compatible top-illuminated device structure compared to the reported PbS CQD photodetectors. There are only two articles about PbS CQD imagers based on CQD sensitized organic photodiode with Al top electrode and CQD/graphene phototransistors (red squares) with unbalanced bandwidth and D*<sup>11,12</sup> . Obviously, our PbS CQD photodiode exhibits the highest D* (2.1×10<sup>12</sup> Jones) and the fastest response (140 kHz). 

Bene�ting from the vacuum-deposited charge transfer layers (NiOx and ZnO) and interfacial protective layer (C60), our CMOS-compatible PbS CQD photodiodes show signi�cantly improved stability and uniformity, which is crucial for an imager. The devices are super-stable in dry air for 720 hours with almost no change in Jd and EQE (15 samples monitored as shown in Fig. 2h). In addition, the devices keep the same EQE and show only about 3 times increase of Jd after keeping in 85<sup>o</sup> C for 1080 hours or thermal cycling (from -40<sup>o</sup> C to 85<sup>o</sup> C) for more than 1200 hours (supplementary Fig. S8). By randomly sampling 41 pixels on a 4-inch silicon wafer, the standard deviation of Jd and EQE are 4.3 nA/cm<sup>2</sup> and 1.7% respectively as shown in Fig. 2i. The excellent uniformity of PbS CQD photodiodes is better than the requirement of standard deviation for imaging<sup>10</sup> . 

Fig. 3| Imager integrating CMOS ROIC and PbS CQD photodiodes. Integral (a) and crosssection (b) schematic diagram of PbS CQD imager. c, Cross-section scanning electron microscope image of PbS CQD imager. d, Landscape layout of PbS CQD imager. e, Circuit diagram of one single pixel. f, Readout timing sequence. The signal readout timing diagram includes the pixel reset time (blue region), integral time (yellow region), signal readout time (green region) and reset time (orange region). The above process is controlled by opening the gate of different transistors (M1 to M7). 

Our PbS CQD imager consists of CMOS ROIC and PbS CQD photodiode array by monolithic integration (Fig. 3a). The PbS CQD photodiode was deposited onto CMOS ROIC panel with 640×512 pixels array below 100<sup>o</sup> C as described in supplementary Method. The wet etching method was used to prepare the 

Page 7/18 

imagers, including lithography and lift-off etching to expose the ports and separate imagers as shown in supplementary Fig. S9. The PbS CQD photodiode pixel array is de�ned by CMOS ROIC bottom electrode array from fab in supplementary Fig. S10. The pixel size is 15 μm with a pixel pitch of 2 μm. The whole �ow process has no negative effect on the PbS CQD photodiodes. After lithography and lift-off etching, the PbS CQD photodiode pixels basically keep the same performance as show in supplementary Fig. S11. 

The schematic diagram of the layer sequence is in detail shown in Fig. 3b. The separated bottom metal electrodes de�ne the pixel size and pitch. The top contact is a common transparent conductive oxide layer with good conductivity and transmittance. The other layers are continuous with almost no electrical and optical crosstalk, due to a 150-250 nm lateral carrier diffusion length of all layers and <1 μm whole device thickness<sup>29,30</sup> . The SEM image in Fig. 3c shows a cross-section view of our PbS CQD imager. The thickness of PbS CQD is optimal 600 nm with high EQE and low Jd. The landscape layout of the image sensor in Fig. 3d indicates the function of each area. The pixel area is located in the center with analogto-digital converter (ADC), column multiplexer and signal output around. 

Circuit diagram of one single pixel in Fig. 3e is a BDI (buffered direct injection) structure in our PbS CQD imager. Readout timing diagram of our PbS CQD imager in Fig. 3f controls the on-off of the transistors to reset the collection capacitor (CC), integrate photo-generated carriers and read out signals of pixels in sequence. The CC is reset via opening the gate of M2 (RST in sequence) before light exposure. Next, the photo-generated carriers by exposure involved in the pixel are stored into CC via opening the gate of M1. During the readout period, the signal voltages on the CC are �rstly read out by opening the gates of M4 (SEL in sequence) and M6 (S/S in sequence). Then the sensing nodes are reset by M2 (RST in sequence) and reset signal is read out by opening the gates of M4 (SEL in sequence) and M7 (S/R in sequence) for noise cancellation. Such a correlated double sampling are widely used in imaging to reduce the noise and improve image quality. By adjusting the integral time, the collection capacity is affordable to accumulate carriers excited by different-intensity light for high-quality imaging. 

Fig. 4| Performance of PbS CQD imager. a, Photograph of a standard image reference ‘Lena’ taken by PbS CQD/graphene imager sensitive to 300-1000 nm�reproduced from reference 13. b, Identical photograph reference ‘Lena’ captured by our PbS CQD imager. c, Original histogram associated to the 18% gray card under sunlight (insets show the photographs) captured by the PbS CQD imager and commercial InGaAs imager (C10633 HAMAMATSU) respectively. d, Average density of the grayscale patches. A portion of the patches are shown just below the plot. The photograph of the ST-52 chart is shown in the inset. e, Gray levels as a function of the density range. The detail process is shown in Supplementary notes. f, The f-stop Signal-to-Noise Ratio (SNR=1/f-stop noise, Supplementary notes) as a function of the density range. g, ISO-12233 test chart shoot by the PbS CQD imager to measure the spatial frequency response (Supplementary notes). The horizontal and vertical slant edges are marked by red rectangles for measuring Modulation Transfer Function (MTF). h, Edge spread function (ESF) of the 

Page 8/18 

region marked by the red rectangles in panel g. The edge pro�le is proportional to the light intensity. i, Horizontal and vertical modulation transfer function (MTF) of the PbS CQD imager. 

Figure of merits of our PbS CQD imager are shown in Fig. 4 by imaging the standard charts, such as classical ‘Lena’, 18% gray card, ST-52 chart and ISO-12233 test chart. All image-capturing setups are in detail described in Supplementary Method. The photograph of ‘Lena’ captured by our PbS CQD imager (Fig. 4b) is of much higher resolution than that captured by the PbS CQD/graphene imager (Fig. 4a)<sup>12</sup> at the same condition. This is partially due to larger scale of our PbS CQD imager (640×512) than the PbS CQD/graphene imager (388×288), and partially due to the better pixel homogeneity in our vertical PbS CQD photodiodes than the horizontal PbS CQD/graphene phototransistors which suffers from bias dependent resistance and photoresponse. The homogeneity of our PbS CQD imager is slightly worse than the commercial InGaAs imager by imaging the 18% gray card under halogen lamps as shown in Fig. 4c. The grayscale root mean standard deviation (RMSD) of our PbS CQD imager as 3.38 is about 2 times higher than that of a commercial HAMAMATSU InGaAs imager as 1.66. Considering the limited optimization done so far and no fundamental restrictions, we believe the homogeneity of our CQD imager could be further improved to be in par with InGaAs imager. 

The dynamic range (DR) of our PbS CQD imager is demonstrated in Fig. 4d ~~-f~~ by imaging the ST-52 step chart with 12 gray levels (density range from 0.1 to 3.7). All 12 gray levels are clearly distinguished by our PbS CQD imager (the inset of Fig. 4d). The average density of grayscale in Fig. 4d is normalized to 255 by the equation: gray level=255×(10<sup>-density</sup> /1.01)<sup>(1/2.2)31</sup> . The characteristic curve of our PbS CQD imager is shown in Fig. 4e where x-axis represents exposure in dB, which equals to -20log(target density/0.1) referred to the ISO-14524. The signal-to-noise ratio (SNR) curve in Fig. 4f demonstrates that SNR drops from 10 to 1 with a decreasing light exposure. The DR of our PbS CQD imager for SNR = 1 is 31 dB, which is limited by the maximum range (31.3 dB) of the ST-52 step chart. 

The slant edge test for spatial frequency response is shown in Fig. 4g ~~-i~~ to measure spatial resolution and modulation transfer function (MTF). The high-resolution photograph of the ISO-12233 test chart captured by our 640×512 PbS CQD imager (pixel size 15 μm) in Fig. 4g demonstrates all kinds of shapes more clearly than that in supplementary Fig. S12a captured by the commercial 320×256 InGaAs imager (pixel size 30 μm). The horizontal and vertical spatial resolution of our PbS CQD imager is extracted from the edge spread function (ESF) as shown in Fig. 4h. The 10-90% edge rise distance of the horizontal slant edge is slightly better than the vertical (0.93 vs. 0.98 pixels), which are both better than 1.64(H) and 1.84(V) pixels of the InGaAs imager (supplementary Fig. S12b). The modulation transfer function (MTF) in Fig. 4i shows that the MTF50 (50% contrast spatial frequency) of the horizontal and vertical slant edge is 40 lp/mm and 37 lp/mm respectively. The resolution of our PbS CQD imager is about 4 times higher than the InGaAs imager (10 lp/mm) with nearly the same-area focal plane (supplementary Fig. S12c). 

Page 9/18 

Fig. 5| Applications of PbS CQD imager. Photographs of apple and water captured by the smartphone silicon imager (a) and our PbS CQD imager (d) illuminated with natural light. Photographs of hand captured by our PbS CQD imager (b) and the InGaAs imager (e) illuminated with 940 nm LED. c and f, Gray level along the red dotted line 1 and 2 in panel b and e. g, Photographs of water and ethanol captured by our PbS CQD imager and the InGaAs imager illuminated with 940 nm LED. Solution S1, S3: water, Solution S2, S4: ethanol. h, Normalized grayscale histogram of solution S1-4 in panel g. i, Normalized grayscale histogram of alcohol with various concentration associated to supplementary Fig. S13. 

Fig. 5 shows several types of images captured by our PbS CQD imager. Under natural light, the photograph in Fig. 5a captured by the smartphone silicon imager demonstrates a well-looking apple and a shadowy level of water in the visible range. In comparison, the same scene captured by the PbS CQD imager in 400-1300 nm range gives more information, such as a hidden scar in the apple and a clear level of water as shown in Fig. 5d. The capability of our PbS CQD imager to capture infrared images provide additional valuable information that are hardly discernable by the silicon imager. 

Another application is demonstrated on vein imaging under 940 nm plane light source in transmission mode. In this band, penetration depth of tissue is over 10 mm<sup>32</sup> and our PbS CQD imager (EQE>60% @ 940 nm, Jd<17.8 nA cm<sup>-2</sup> ) is much more sensitive than the commercial InGaAs imager (EQE<15% @ 940 nm, Jd~143 nA cm<sup>-2</sup> )<sup>33</sup> considering its higher EQE and lower Jd. The photograph in Fig. 5b by our PbS CQD imager shows much clearer blood veins in the hand than that in Fig. 5e taken by the commercial InGaAs imager. The grayscale values along the red dotted line 1 and 2 are respectively shown in Fig. 5c and 5f. Our PbS CQD imager obtains more obvious and sharper change of grayscale (9.6 and 13.5) in the edge of vein compared with the commercial InGaAs camera (7.7 and 5.2), demonstrating greater application potential in vein imaging. 

Our PbS CQD imager further provides the possibility for material identi�cation as the commercial InGaAs imager. The images of water and ethanol, illuminated by 940 nm plane light source, are captured by our PbS CQD and the InGaAs imager as shown in Fig. 5g. The water bottles (S1, S3) are darker than the ethanol bottles (S2, S4) due to stronger 940 nm absorption of water than ethanol (supplementary Fig. S13d). The normalized grayscale histogram in Fig. 5h demonstrates that our PbS CQD imager obtains broader and higher grayscale values than the InGaAs imager. The grayscale deviation between water (median 110) and ethanol (median 80) captured by our PbS CQD imager is greater than that captured by the InGaAs imager (median 60 to 40). The contrasts illustrate that our PbS CQD imager is better at water and ethanol identi�cation than the InGaAs imager. Supplementary Fig. S13 shows the images of alcohol with various concentration by using our PbS CQD imager. The corresponding grayscale histogram in Fig. 5i demonstrates how our PbS CQD imager distinguishes different concentration of alcohol in this azeotropic mixture through comparing gray values. Our PbS CQD imager also performs very well in organic dye discrimination (Figure S14), thanks to its wide responsive spectrum and tunable band gap 

Page 10/18 

via quantum con�nement. All these examples highlight the broad application potential of our CQD imagers. 

In summary, we demonstrate a low-cost and high-performance imager by monolithically integrating welldesigned CQD photodiodes and CMOS ROIC. Via optimization of charge transport layer and protective layer, our top illuminated PbS CQD photodiodes demonstrate a balanced D<sup>*</sup> of 2.1×10<sup>12</sup> Jones and -3dB bandwidth of 140 kHz. Monolithic integration of PbS CQD photodiodes and ROIC produced a nearinfrared CQD imager with the-state-of-the-art performance including a large pixel number of 640×512, a >60% EQE @ 940 nm, a spatial resolution of 40 lp/mm at MTF50, and comparable image quality with commercial InGaAs camera. We further showcase our CQD imager for apple scar detection, vein imaging, water/ethanol discrimination and dye identi�cation, as examples to supplement silicon based visible camera. The success of CQD imager highlights the great potential of monolithic integration of functional devices onto ROIC, such as arrays of sensors, integrated photonics and even integration of sensing, memory and computing onto a single chip. 



<!-- Start of picture text -->
Declarations<br>Acknowledgement<br><!-- End of picture text -->

This work was �nancially supported by the National Natural Science Foundation of China (61725401, 61904065), fund for Innovative Research Groups of the Natural Science Foundation of Hubei Province (2020CFA034). The authors thank the Analytical and Testing Center of HUST and the facility support of the Center for Nanoscale Characterization and Devices (CHCB), WNLO-HUST. 

L. G. and J. T. supervised the whole project. J. L., P. L. and D. C. fabricated the imager. J. K., K. X. and J. Z. provided materials. J. L., T. S., X. Q., L. C. and T. W. performed measurements and analyzed the experimental data. L. G., J. T., H. S., W. W. and J. C. supported theoretical analysis. J. L., L. G. and J. T. wrote the manuscript. All authors reviewed and commented on the manuscript. 

The authors declare no competing interests. 

Correspondence and requests for materials should be addressed to L. G. or J. T. 

Page 11/18 

1.             Chen, Y., Chao, K. & Kim, M. S. Machine vision technology for agricultural applications. Comput. Electron. Agr. 36, 173-191 (2002). 

2.             Saran, R. & Curry, R. J. Lead sulphide nanocrystal photodetector technologies. Nat. Photonics 10, 81-92 (2016). 

3.             Konstantatos, G. & Sargent, E. H. Nanostructured materials for photon detection. Nat. Nanotechnol. 5, 391-400 (2010). 

4.             Rogalski, A., Antoszewski, J. & Faraone, L. Third-generation infrared photodetector arrays. J. Appl. Phys. 105, 091101 (2009). 

5.             Lu, H., Carroll, G. M., Neale, N. R. & Beard, M. C. Infrared Quantum Dots: Progress, Challenges, and Opportunities. ACS Nano 13, 939-953 (2019). 

6.             Livache, C., Martinez, B., Goubet, N., Ramade, J. & Lhuillier, E. Road Map for Nanocrystal Based Infrared Photodetectors. Front. Chem. 6, 575, (2018). 

7.             Otani, Y. Snapshot full Stokes imager by polarization cameras and its application to bioimaging. In Ultra-High-De�nition Imaging Systems IV.1170904 (SPIE OPTO, 2021); https://doi.org/10. 1117/12.2587339 

8.             Lei, W., Antoszewski, J. & Faraone, L. Progress, challenges, and opportunities for HgCdTe infrared materials and detectors. Appl. Phys. Rev. 2, 041303 (2015). 

9.             Kinch, M. A. The rationale for ultra-small pitch IR systems. In Infrared Technology and Applications XL.907032 (SPIE Defense & Security, 2014). https://doi.org/10.1117/12.2051335 

10.          Rogalski, A. Infrared detectors(CRC press, 2010). 

11.           Fuentes-Hernandez, C. et al. Large-area low-noise �exible organic photodiodes for detecting faint visible light. Science 370, 698-701 (2020). 

12.          Goossens, S. et al. Broadband image sensor array based on graphene–CMOS integration. Nat. Photonics 11, 366-371 (2017). 

13.          Pal, B. N. et al. High-Sensitivity p-n Junction Photodiodes Based on PbS Nanocrystal Quantum Dots. Adv. Funct. Mater. 22, 1741-1748 (2012). 

14.          Sliz, R. et al. Stable Colloidal Quantum Dot Inks Enable Inkjet-Printed High-Sensitivity Infrared Photodetectors. ACS Nano 13, 11988-11995 (2019). 

15.          Manders, J. R. et al. Low-Noise Multispectral Photodetectors Made from All Solution-Processed Inorganic Semiconductors. Adv. Funct. Mater. 24, 7205-7210 (2014). 

Page 12/18 

16.          Zhang, J. et al. Preparation of Cd/Pb chalcogenide heterostructured janus particles via controllable cation exchange. ACS Nano 9, 7151-7163 (2015). 

17.          Zhang, C. et al. Combination of Cation Exchange and Quantized Ostwald Ripening for Controlling Size Distribution of Lead Chalcogenide Quantum Dots. Chem. Mater. 29, 3615-3622 (2017). 

18.          Heath, J. T., Cohen, J. D. & Shafarman, W. N. Bulk and metastable defects in CuIn1−xGaxSe2 thin �lms using drive-level capacitance pro�ling. J. Appl. Phys. 95, 1000-1010 (2004). 

19.          Wang, R. et al. Highly E�cient Inverted Structural Quantum Dot Solar Cells. Adv. Mater. 30, 1704882 (2018). 

20.          Lee, J. W., Kim, D. Y. & So, F. Unraveling the Gain Mechanism in High Performance SolutionProcessed PbS Infrared PIN Photodiodes. Adv. Funct. Mater. 25, 1233-1238 (2015). 

21.          Dong, R. et al. An Ultraviolet-to-NIR Broad Spectral Nanocomposite Photodetector with Gain. Adv. Opt. Mater. 2, 549-554 (2014). 

22.          Yoo, J., Jeong, S., Kim, S. & Je, J. H. A Stretchable Nanowire UV-Vis-NIR Photodetector with High Performance. Adv. Mater. 27, 1712-1717 (2015). 

23.          Wei, Y. et al. Hybrid Organic/PbS Quantum Dot Bilayer Photodetector with Low Dark Current and High Detectivity. Adv. Funct. Mater. 28, 1706690 (2018). 

24.          Qiao, K. K. et al. E�cient interface and bulk passivation of PbS quantum dot infrared photodetectors by PbI2 incorporation. RSC Adv. 7, 52947-52954 (2017). 

25.          Clifford, J. P. et al. Fast, sensitive and spectrally tuneable colloidal-quantum-dot photodetectors. Nat. Nanotechnol. 4, 40-44 (2009). 

26.          Fuentes-Hernandez, C. et al. Large-area low-noise �exible organic photodiodes for detecting faint visible light. Science 370, 698-701 (2020). 

27.          Geremew, A. et al. Low-frequency electronic noise in superlattice and random-packed thin �lms of colloidal quantum dots. Nanoscale 11, 20171-20178 (2019). 

28.          Liu, H., Lhuillier, E. & Guyot-Sionnest, P. 1/f noise in semiconductor and metal nanocrystal solids. J. Appl. Phys. 115, 154309 (2014). 

29.          Carey, G. H., Levina, L., Comin, R., Voznyy, O. & Sargent, E. H. Record Charge Carrier Diffusion Length in Colloidal Quantum Dot Solids via Mutual Dot-To-Dot Surface Passivation. Adv. Mater. 27, 33253330 (2015). 

Page 13/18 

30.          Zhitomirsky, D. et al. Engineering colloidal quantum dot solids within and beyond the mobilityinvariant regime. Nat. Commun. 5, 3803 (2014). 

31.          Appendix I: F-stop noise, scene-referenced SNR, and Dynamic Range. (Imatest, 2021); https://www.imatest.com/docs/noise/ 

32.          Teraphongphom, N., Kong, C. S., Warram, J. M. & Rosenthal, E. L. Specimen mapping in head and neck cancer using �uorescence imaging. Laryngoscope 2, 447-452 (2017). 

33.          Hamamatsu, InGaAs camera C10633-13 -23. (Hamamatsu, 2013); https://www. hamamatsu. com/jp/en/product/type/C14041-10U/index.html 



Design of COMS-compatible PbS CQD photodiode. a, Integration of readout circuit and top illuminated photodiode. ETL means electron transport layer and HTL means hole transport layer. b, Carrier transmission in CQD photodiodes illuminated through top (n-type) and bottom (p-type) sides. c, Steadystate responses of PbS CQD photodiodes with or without fullerene (C60) layer. Defect density pro�les of PbS CQD photodiodes without (d) and with (e) C60 by capacitance-voltage measurement and drive-level capacitance pro�ling. f, External quantum e�ciency (EQE) of double-side PbS CQD photodiodes illuminated through top and bottom sides. 

Page 14/18 



Performance of CMOS-compatible PbS CQD photodiodes. a, Steady-state response of PbS CQD photodiode under 970 nm LED illumination with power densities varied from 100 nW cm-2 to 100 mW cm-2. b, Linear dynamic range (LDR) of PbS CQD photodiode at -0.5 V bias. c, External quantum e�ciency and responsivity spectra, d, Response bandwidth and e, Transient response of PbS CQD photodiode at -0.5 V bias. f, Measured current noise of PbS CQD photodiode as a function of frequency at -0.5 V bias. The calculated shot noise, 1/f noise, and generation-recombination (G-R) noise limit are also included for reference. g, Speci�c detectivity (D*) and bandwidth statistics of PbS CQD photodetectors reported in literature. Filled black triangles: measured D* for PbS CQD photodiodes (a20, b21, c14, d 13, e15). Hollow triangles: calculated D* for PbS CQD photodetectors (f22, g23, h24, i25). Filled red squares: measured D* for PbS CQD photodetectors for readout circuit (ROIC) integration. (j12, k11). Blue pentagram: measured D* in this work (deep blue: under zero bias (self-powered state), light blue: at -0.5 V bias). h, Stability of PbS CQD photodiodes in air at room temperature. i, Homogeneity of PbS CQD photodiodes. N represents the number of devices. 

Page 15/18 



Imager integrating CMOS ROIC and PbS CQD photodiodes. Integral (a) and cross-section (b) schematic diagram of PbS CQD imager. c, Cross-section scanning electron microscope image of PbS CQD imager. d, Landscape layout of PbS CQD imager. e, Circuit diagram of one single pixel. f, Readout timing sequence. The signal readout timing diagram includes the pixel reset time (blue region), integral time (yellow region), signal readout time (green region) and reset time (orange region). The above process is controlled by opening the gate of different transistors (M1 to M7). 



Page 16/18 

Performance of PbS CQD imager. a, Photograph of a standard image reference ‘Lena’ taken by PbS CQD/graphene imager sensitive to 300-1000 nm�reproduced from reference 13. b, Identical photograph reference ‘Lena’ captured by our PbS CQD imager. c, Original histogram associated to the 18% gray card under sunlight (insets show the photographs) captured by the PbS CQD imager and commercial InGaAs imager (C10633 HAMAMATSU) respectively. d, Average density of the grayscale patches. A portion of the patches are shown just below the plot. The photograph of the ST-52 chart is shown in the inset. e, Gray levels as a function of the density range. The detail process is shown in Supplementary notes. f, The f- stop Signal-to-Noise Ratio (SNR=1/f-stop noise, Supplementary notes) as a function of the density range. g, ISO-12233 test chart shoot by the PbS CQD imager to measure the spatial frequency response (Supplementary notes). The horizontal and vertical slant edges are marked by red rectangles for measuring Modulation Transfer Function (MTF). h, Edge spread function (ESF) of the region marked by the red rectangles in panel g. The edge pro�le is proportional to the light intensity. i, Horizontal and vertical modulation transfer function (MTF) of the PbS CQD imager. 



Applications of PbS CQD imager. Photographs of apple and water captured by the smartphone silicon imager (a) and our PbS CQD imager (d) illuminated with natural light. Photographs of hand captured by our PbS CQD imager (b) and the InGaAs imager (e) illuminated with 940 nm LED. c and f, Gray level along the red dotted line 1 and 2 in panel b and e. g, Photographs of water and ethanol captured by our PbS 

Page 17/18 

CQD imager and the InGaAs imager illuminated with 940 nm LED. Solution S1, S3: water, Solution S2, S4: ethanol. h, Normalized grayscale histogram of solution S1-4 in panel g. i, Normalized grayscale histogram of alcohol with various concentration associated to supplementary Fig. S13. 

This is a list of supplementary �les associated with this preprint. Click to download. 

supportinginformationCQDimager0630.docx 

Page 18/18 

