# Ti3C2TX MXene for Sensing Applications: Recent Progress, Design Principles, and Future Perspectives.

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | ACS Nano |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 649 |
| 作者 | Yangyang Pei, Xiaoli Zhang, Zeng Hui, Jin-Yuan Zhou, Xiao Huang, Geng-Zhi Sun, Wei Huang |
| DOI | 10.1021/acsnano.1c00248 |
| 源文件 | 004_Pei_2021_Ti3C2TX-MXene-for-Sensing-Applications-Recent-Pr.pdf |

---


www.acsnano.org 

## Ti3C2TX MXene for Sensing Applications: Recent Progress, Design Principles, and Future Perspectives 

Yangyang Pei, Xiaoli Zhang, Zengyu Hui, Jinyuan Zhou, Xiao Huang, Gengzhi Sun,* and Wei Huang* 

|Cite This: ACS Nano 2021, 15, 3996−4017<br>Read Online|
|---|



### ACCESS 

|Metrics & More|Article Recommendations|
|---|---|



ABSTRACT: Sensors are becoming increasingly significant in our daily life because of the rapid development in electronic and information technologies, including Internet of Things, wearable electronics, home automation, intelligent industry, etc. There is no doubt that their performances are primarily determined by the sensing materials. Among all potential candidates, layered nanomaterials with two-dimensional (2D) planar structure have numerous superior properties to their bulk counterparts which are suitable for building various high-performance sensors. As an emerging 2D material, MXenes possess several advantageous features of adjustable surface properties, tunable bandgap, and excellent mechanical strength, making them attractive in various applications. Herein, we particularly focus on the recent research progress in MXene-based sensors, discuss the merits of MXenes and their derivatives as sensing materials for collecting various signals, and try to elucidate the design principles and working mechanisms of the corresponding MXene-based sensors, including strain/stress sensors, gas sensors, electrochemical sensors, optical sensors, and humidity sensors. In the end, we analyze the main challenges and future outlook of MXene-based materials in sensor applications. KEYWORDS: Ti3C2TX MXene, strain/stress sensors, gas sensors, electrochemical sensors, optical sensors, humidity sensors, design principles, sensing mechanisms 

he widespread applications of wearable electronics and Internet of Things drive the noteworthy expansion in 

# T 

the global sensor market, which is poised to reach $323.3 billion by 2024 with a compound annual growth rate of 13.3% according to BCC Research reports.<sup>1</sup> Generally speaking, sensors are the devices that enable the acquisition of the changes in environment and output readable signals to other electronics for postprocessing. As the essential integral part, sensing material takes the responsibility to interact with the stimulus of either physical perturbation or chemical reactions. To date, numerous nanomaterials have been synthesized and used as sensing component for various applications, including strain/stress sensors, humidity sensors, gas sensors, photodetectors, biosensors, etc. Among all candidates, two-dimensional (2D) layered materials have their advantages of large surface-to-volume ratio, tunable electronic structure, excellent flexibility, as well as outstanding mechanical robustness. 

Comparably, ever since their discovery in 2011, 2D transition-metal carbides/nitrides (collectively denoted as MXenes) are attracting enormous research interests.<sup>2</sup> As 

illustrated in Figure 1, MXenes have a general formula of Mn+1XnTX, where n = 1, 2, or 3, representing three common structures. M stands for an early transition metal, such as Ti, Mo, and V, X refers to carbon/nitrogen, while TX represents various surface terminations, for example, fluorine (−F), hydroxyl (−OH), and/or oxygen (O).<sup>3</sup> In case of double transition-metal MXenes, the M atoms can exist either in random (solid solution) or ordered arrangement, where the ordered phase is energetically more stable. Typically, MXenes possess excellent mechanical strength, good thermal conductivity, tunable bandgap from semiconducting to metallic, and hydrophilic surfaces with abundant functional groups that can be postmodified and solution processed.<sup>4−7</sup> These 



Received: January 10, 2021 Accepted: March 5, 2021 Published: March 11, 2021 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

© 2021 American Chemical Society 

3996 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 



Figure 1. Compositions of MXenes predicted theoretically and obtained experimentally. Reproduced with permission from ref 6. Copyright 2019 American Chemical Society. 

characteristics render MXenes an ideal platform as sensing materials for a number of applications. 

Herein, we comprehensively review the synthetic methods, physicochemical properties, and sensing applications of MXenes. Particularly, we aim to cover the latest research achievements of using MXenes and their derivatives in strain/ stress sensors, gas sensors, electrochemical sensors, optical sensors, and humidity sensors, highlight the principles of device design, underscore the underlying sensing mechanisms, and provide insightful prospects for future endeavors. 

#### SYNTHESIS 

At present, the commonly used strategy for preparing MXene nanosheets is the top-down etching from MAX phases (Mn+1AXn), where A represents an A-group element (e.g., Al and Si). Generally, the M−A bond is considered to be metallic, whereas the M−X bond features multiple characters of ionic, metallic, and covalent.<sup>8,9</sup> Therefore, in contrast to the exfoliation of graphene, the metallic M−A bond is difficult to break by mechanical shearing. Nevertheless, it is feasible to be selectively etched rather than M−X bonds.<sup>10,11</sup> The preparation of MXenes typically includes two steps, namely the selective etching of A and the delamination of MXenes.<sup>12−17</sup> 

Etching. In 2011, it was reported that the MAX phase of Ti3AlC2 can be chemically etched by HF aqueous solution following eqs 1−3, and Al was selectively removed forming Ti3C2TX-based MXene.<sup>3</sup> 

2Ti AlC3 2 + 6HF = 2AlF3 + 3H2 + 2Ti C3 2 (1) 



<!-- Start of picture text -->
Ti C3 2 + 2H2O = Ti C3 2(OH)2 + H2 (2)<br><!-- End of picture text -->



<!-- Start of picture text -->
Ti C3 2 + 2HF = Ti C3 2F2 + H2 (3)<br><!-- End of picture text -->

The ab initio molecular dynamics (MD) simulations showed that the H and F radicals decomposed from HF adsorbed on Ti atoms, weakening Al−Ti bonds, generating surface terminals, and ultimately forming Ti3C2TX.<sup>18−20</sup> Subsequently, by using HF as etchant, numerous MAX phases, including Ti2AlC, Ti3AlCN, Nb2AlC, Ti3SiC2, Mo2Ga2C, Zr3Al3C5, and (Ti0.5Nb0.5)2AlC, were transformed into the corresponding MXene nanosheets successfully.<sup>8,21</sup> Since chemical etching is a kinetically controlled process, several important reaction parameters, such as duration, temperature, and HF concentration, need to be considered. It was reported that a large n number in Mn+1AXn requires a prolonged etching time, relatively high etching temperature, and low pH value.<sup>8</sup> As the main byproduct during etching is AlF3 (eq 1) which is not dissolvable in water, it is critically important to select an appropriate temperature and time to avoid the precipitation of AlF3. On the other hand, Alhabeb and co-workers confirmed that effective etching is preferentially achieved by HF with a high concentration (e.g., 30%), forming an accordion-like morphology, which was not observed when using 5% HF as the etchant (Figure 2a).<sup>22</sup> The successful etching of Al in Ti3AlC2 was further evidenced by XRD analysis with an obvious downshift of (002) peak (Figure 2b). Moreover, the experimental results showed that vacancy defects derived from the removal of surface Ti atoms can be adjusted by HF concentration. As shown in Figure 2c,d, vacancy clusters were 

3997 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 



Figure 2. (a) SEM images of (i) Ti3AlC2 (MAX) powder and multilayered Ti3C2TX etched by HF with the concentration of (ii) 5 wt %, (iii) 10 wt %, and (iv) 30 wt %. (b) XRD profiles of the pristine Ti3AlC2 powder and the obtained Ti3C2TX. Reproduced with permission from ref 22. Copyright 2017 American Chemical Society. (c) Scanning transmission electron microscopy images of Ti3C2TX flakes obtained by HF etching with different concentrations of: (i) 2.7 wt %, (ii) 5.3 wt %, and (iii) 7 wt %. (d) Defect concentration calculated from the samples shown in panel (c). Reproduced with permission from ref 21. Copyright 2016 American Chemical Society. 



Figure 3. (a) The exfoliation of Ti3AlC2 via HF etching and TBAOH-assisted delamination. (b) Transmission electron microscopy (TEM), selected area electron diffraction, and high-resolution TEM (HRTEM) images of (i) bulk Ti3AlC2, (ii) exfoliated Ti3C2-HF, and (iii) delaminated Ti3C2-HF/TBA. Reproduced with permission from ref 30. Copyright 2020 American Chemical Society. 

rarely observed at 2.7 wt % HF, but increased significantly at 7 wt % HF.<sup>21</sup> 

To avoid direct utilization of toxic HF, in 2014, Halim and co-workers utilized NH4HF2 as the etchant, which is much safer and milder.<sup>23</sup> Alternatively, Ghidiu and co-workers prepared Ti3C2TX by adding Ti3AlC2 powder in the mixture of LiF and HCl (6 M). The reaction was carried out at 40 °C 

for 45 h, and the experimental results indicated that the copresence of fluorine ions and protons is the key for successful etching.<sup>24</sup> Lipatov and co-workers further developed this approach by adjusting the feeding ratios between MAX and LiF (MAX: LiF = 1:5 or 1:7.5).<sup>25</sup> It was found that excess LiF promoted the etching of Al and the intercalation of Li<sup>+</sup> , leading to Ti3C2TX MXene nanosheets with larger size, 

3998 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 



Figure 4. (a) Stress−strain curves of Tin+1Cn samples. Reproduced with permission from ref 42. Copyright 2015 IOP Publishing. (b) TEM images of a Ti3C2TX scroll with an inner diameter of <20 nm. Reproduced with permission from ref 9. Copyright 2014 John Wiley and Sons. (c) An air plane model folded by Ti3C2TX film. (d) Tensile tests of Ti3C2TX/PVA films containing different amount of Ti3C2TX. (e) Photo images of Ti3C2TX and Ti3C2TX/PVA scrolls loaded by weight. Reproduced with permission under a Creative Commons Attribution 4.0 International License (CC BY 4.0) from ref 44. Copyright 2014 National Academy of Sciences. 

uniform thickness, and fewer defects. Typically, the etching process transforms solid dense MAX into loosely accumulated accordion-like structure, which are also known as multilayer MXenes (ML-MXenes). Therefore, an exfoliation step is necessary to separate ML-MXenes into monolayer. 

It is noteworthy that wet-chemical methods are not appropriate for etching nitride-based MAXs due to their higher formation energy.<sup>5</sup> Urbankowski and co-workers developed a molten salt method (e.g., potassium fluoride, lithium fluoride, and sodium fluoride) for preparing Ti4N3based MXene by selectively etching aluminum from Ti4AlN3 at 550 °C in Ar.<sup>26</sup> The residue fluoride in resultant powder was then removed using sulfuric acid (H2SO4) solution. 

Exfoliation. In 2013, MXene nanosheets were exfoliated into single layer by inserting large organic molecules into the interlayers of the accordion-like structure followed by mechanical vibration or ultrasonication.<sup>4,12</sup> The commonly used intercalants include tetrabutylammonium hydroxide (TBAOH), dimethyl sulfoxide, hydrazine, urea, and NH4+.12,27−29 For example, Chia and co-workers used TBAOH as the intercalant to exfoliate Ti3C2TX MXene from the products obtained via HF etching (Figure 3a).<sup>30</sup> As shown in Figure 3b, MAX powder with micron-sized flakes was expanded after the removal of Al, and the obtained Ti3C2-HF was delaminated into single-/fewer-layer MXenes by weakening the interlayer interaction using TBAOH. When NH4HF2 was adopted as the etchant, the accordion-like multilayer Ti3C2TX MXene was already intercalated with cations (e.g., NH4+) in the aqueous solution.8,31 



<!-- Start of picture text -->
3<br>Ti AlC3 2 + 3NH4HF2 = (NH4)3AlF6 + Ti C3 2 + 2<br>2 H<br>(4)<br><!-- End of picture text -->



<!-- Start of picture text -->
Ti C3 2 + a NH4HF2 + 2H2O = (NH ) (NH3 c 4) d Ti C3 2(OH) x F y<br>(5)<br><!-- End of picture text -->

For example, during the reaction between NH4HF2 and Ti3AlC2, (NH4)3AlF6 was generated instead of AlF3 (eq 4), and in the meantime, NH3 and NH4+ were intercalated there between Ti3C2TX layers (eq 5). Lately, Li<sup>+</sup> , Na<sup>+</sup> , and Sn<sup>4+</sup> were also adopted as the intercalants.<sup>32,33</sup> The obtained Ti3C2TX nanosheets had similar size to that of the original Ti3AlC2 crystals.<sup>22</sup> 

In addition to the above-mentioned top-down strategies, chemical vapor deposition (CVD) as a multifunctional bottom-up method was developed particularly suitable for fabricating high-quality and large-area MXenes. For instance, α-Mo2C crystals with a large lateral size of ∼10 μm and a thickness of 3−20 nm were deposited on copper using molybdenum foil and methane (CH4) as the precursors at 1085 °C in hydrogen.<sup>34</sup> The molybdenum atoms diffused to the surface of liquid copper and reacted with carbon atoms generated from the decomposition of CH4 forming 2D Mo2C. Lately, TaN and ReC crystals were successfully prepared using the similar methods.<sup>35,36</sup> 

#### PROPERTIES 

Typically, the properties of MXenes severely depend on their composition, stacking order, and lateral size. When the Al atoms are removed from MAX phase (e.g., Ti3AlC2), Ti atoms are exposed on both sides of Ti3C2 layer. These unstable Ti atoms are prone to link with TX (e.g., −F, −OH, and O) generated during the etching in aqueous solution to lower the total surface energy.<sup>37,38</sup> Therefore, it is necessary to fundamentally understand the influence of terminations on 

3999 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 



Figure 5. (a) Imaginary part of the in-plane (ε2,xx) and out-plane (ε2,zz) dielectric function, (b) in-plane (αxx) and out-plane (αzz) adsorption coefficient, and (c) in-plane (Rxx) and out-plane (Rzz) reflectivity as a function of photon energy for functionalized Ti3C2T2 monolayer. Reproduced with permission from ref 46. Copyright 2016 Royal Society of Chemistry. 



Figure 6. (a) The electronic structures of Ti3C2 and Ti3C2TX monolayers with −F and −OH terminations. Reproduced with permission from ref 2. Copyright 2011 John Wiley and Sons. (b) The electronic structures of I-Ti3C2F2, II-Ti3C2F2, III-Ti3C2F2, I-Ti3C2(OH)2, IITi3C2(OH)2, and III-Ti3C2(OH)2. Reproduced with permission from ref 52. Copyright 2012 American Chemical Society. (c) The temperature-dependent resistance measurements for Ti3C2TX, Ti3CNTX, and Mo2TiC2TX. (d) The electron transport mechanism of Mo2TiC2TX before and after annealing. Reproduced with permission under a Creative Commons Attribution 4.0 International License (CC BY 4.0) from ref 55. Copyright 2019 Springer Nature. 

the physicochemical properties of MXenes so as to provide versatility in designing sensors.<sup>39</sup> 

Thermal/Chemical Stability. The stability of MXene nanosheets is critically important for practical applications because the materials may undergo a series of thermal/ chemical treatments during device fabrication and face specialized working environment. Typically, heat treatment in inert atmosphere (e.g., Ar) at elevated temperature (e.g., 1200 °C) results in the elimination of surface terminations and improves the crystallinity of MXene nanosheets without any damage of the layered morphology.<sup>40</sup> Notably, Ti3C2TX MXene is unstable in oxidative environment (e.g., hot air) and gradually transforms to oxide (TiO2).<sup>17</sup> For instance, 

Naguib and co-workers directly converted Ti3C2TX in to TiO2/carbon sheets simply by annealing at 1150 °C in air for 30 s.<sup>41</sup> Such transformation may induce some distinct properties typically by sacrificing the merits of MXenes, such as high conductivity, superior pseudocapacitance, and good solution processability. Therefore, Ti3C2TX-based materials should be designed rationally depending on their applications.<sup>20</sup> 

Mechanical Property. The Young’s moduli of Ti3C2 were theoretically calculated to be as high as 502 GPa (Figure 4a).<sup>42</sup> The elasticity (E<sup>2D</sup> ) of single Ti3C2TX was measured ranging from 278 to 393 N m<sup>−1</sup> based on the force−deflection relationship in force−indentation experiments using the 

4000 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

Poisson’s ratio of v = 0.227, while two-layer Ti3C2TX had a E<sup>2D</sup> value falling in the range of 632−683 N m<sup>−1</sup> . The average E<sup>2D</sup> of two-layer Ti3C2TX (655 ± 19 N m<sup>−1</sup> ) was twice that of monolayer sheet (326 ± 29 N m<sup>−1</sup> ), suggesting the strong interlayer interaction between surface groups. The experimental results of nanoindentation showed that Ti3C2TX had a higher E<sup>2D</sup> than graphene oxide (GO), reduced GO (rGO), and molybdenum sulfide (MoS2), yet lower than h-BN and graphene.<sup>43</sup> In addition, Ti3C2TX exhibited good flexibility and can be rolled into a conical shape with a radius of <20 nm (Figure 4b).<sup>2</sup> As a result, the free-standing paper assembled by Ti3C2TX sheets can be folded into an airplane without any obvious damage (Figure 4c). The Ti3C2TX thin film (∼3.3 μm thick) exhibited a mechanical strength of ∼22 MPa (Figure 4d). The cylinder rolled up by Ti3C2TX paper (∼5 μm thick) can support ∼4000 times its own weight. The incorporation of 10 wt % PVA further enhanced the mechanical strength of Ti3C2TX/PVA paper by 34%, bearing ∼15,000 times of its own weight (Figure 4e).<sup>44</sup> 

Optical Property. The optical properties of MXenes intrinsically correlate to their electronic structures. The density functional theory (DFT) calculation indicated that most Tin+1Xn exhibit metallic nature with overlap between the conduction and valence bands at the Fermi level.<sup>45</sup> Recent studies showed the electronic structure of MXenes is largely affected by their surface terminations.<sup>9</sup> The imaginary part (ε2) of the dielectric function, adsorption coefficients (α), and refractivity (R) were calculated for functionalized Ti3C2T2 monolayer (Figure 5). Within photon energy between 1.4 and 4.5 eV, F- and OH-terminated Ti3C2TX had lower in-plane αxx than pristine and O-terminated ones. Moreover, both αxx and Rxx showed neglectable dependence on photon frequency in visible region.<sup>46</sup> The above results were consistent with that reported by Berdiyorov and co-workers, which shows that the real and imaginary parts of the frequency-dependent dielectric functions calculated for pristine Ti3C2, Ti3C2F2, Ti3C2O2, and Ti3C2(OH)2 greatly depending on the functional groups. The peaks agreed well with the inter- and intraband transitions obtained from DFT predictions. Moreover, in visible range, F- and OH-terminated Ti3C2TX showed lower absorption and reflectivity than pristine Ti3C2, making them more suitable for transparent electrode applications.<sup>47−49</sup> In addition, depending on thickness, a strong absorption was observed between 700 and 800 nm, implicating potential applications in photothermal therapy.<sup>50</sup> 

Electrical Property. According to DFT calculations, the electronic structure of Ti3C2TX severely depends on the surface terminations (Figure 6a). The presence of −F and −OH transforms metallic Ti3C2 to semiconductors with obvious bandgaps of 0.05 and 0.1 eV, respectively, reducing the carrier density and thus the conductivity.<sup>2,51</sup> Moreover, it was reported the electrical properties of the obtained Ti3C2(OH)2 and Ti3C2F2 monolayers showed dependence on the spatial arrangement of −OH and −F on Ti3C2TX MXene surface, resulting in either narrow bandgap semiconductors or metallic characteristic.<sup>52</sup> Three main possible configurations were theoretically constructed: All −OH or −F directly linked to Ti atoms or located at the hollow sites above three adjacent C atoms (type I), all −OH or −F sat on the topmost C atoms (type II), and the asymmetric arrangement of type I and type II on the two sides of Ti3C2 (type III). It was found that I-Ti3C2F2 behaved as a semiconductor (∼0.04 eV bandgap), while II-Ti3C2F2 showed metallic features (Figure 

6b). Therefore, the electronic structures of monolayer MXenes are possibly tuned by adjusting surface groups and their geometric conformation.<sup>53</sup> 

Regarding multilayer MXenes, the intercalating agents can enlarge the interlayer spacing, thereby increasing the resistance by an order of magnitude.<sup>39,54</sup> A direct experimental observation was reported by Hart and co-workers.<sup>55</sup> They found that the intercalation of H2O and TBA<sup>+</sup> in MXenes assemblies led to higher resistance and induced negative dR/ dT (a negative temperature dependence of resistance) as shown in Figure 6c. Thermal annealing at 200 °C in vacuum decreased Ti3C2TX and Ti3CNTX resistance by 18% and 36% owing to the removal of H2O molecules. Since Mo2TiC2TX contained both H2O and TBA<sup>+</sup> , 24% and 69% reduction in resistance were obtained after annealing at 200 and 500 °C, respectively, due to the removal of H2O and the decomposition of TBA<sup>+</sup> accompanying with a transition of dR/dT from negative to positive (Figure 6d). Further increase in annealing temperature accelerated the removal of surface terminations, leading to an improved conductivity. A typical example is the detachment of F-terminals from Ti3C2TX when the temperature rose from 300 to 775 °C.<sup>56</sup> In comparison, the defunctionalization of Mo2TiC2TX occurred at a lower temperature of 500 °C, indicating the weaker interaction between F and Mo. 

#### APPLICATIONS 

Strain/Stress Sensors. Strain/stress sensors have been extensively studied and widely utilized in a broad range of applications, including scales, robotics, human-machine-interfaces, healthcare, motion monitoring, electronic skins, artificial eardrum, etc.<sup>57−59</sup> The advantage features of MXenes, including high electrical conductivity, excellent flexibility, and good hydrophilicity suitable for wet-processing, endow its potential applications in strain/stress sensors (Table 1).<sup>51,60,61</sup> For example, a tensile strain sensor based on the hybrid network of Ti3C2TX nanoparticles (NPs) and nanosheets was developed by Yang and co-workers (Figure 7a). The sensing mechanism was attributed to the resistance change originating from the migration of NPs and the bridging effect of Ti3C2TX nanosheets. The thus fabricated sensor exhibited a gauge factor (GF) of >178.4, a sensing range within 0−53%, a detection limit of 0.025%, and stable response under a 20% strain without obvious degradation over 5000 cycles (Figure 7b).<sup>62</sup> Cai and co-workers designed a sandwich-like thin film through alternatively spray-coating Ti3C2TX nanosheets and hydrophilic single-walled carbon nanotubes (CNTs) (Figure 7c).<sup>63</sup> Upon tensile loading and unloading, the interwoven thin film showed reversible resistance change due to the generation and repair of cracks through the interconnection of one-dimensional (1D) CNTs and 2D MXenes (Figure 7d). The resultant sensor exhibited high sensitivity (GF = 772.6), a detection limit of 0.1% strain, tunable sensing range between 30% and 130%, and good reliability and stability over 5000 cycles. In addition to thin films, MXene-based hydrogels with self-healing ability were synthesized using poly(vinyl alcohol) (PVA) as polymeric matrix and applied as sensing materials for strain detection (Figure 7e).<sup>64,65</sup> Ti3C2TX provided highly conductive pathways as well as enhanced self-healing ability of the hydrogel due to its hydrophilic properties (Figure 7f). The asfabricated capacitive sensor showed a GF of 0.4 with a linear response and low hysteresis within 200% strain (Figure 7g). In addition, the device exhibited only 5.8% relative capacitance 

4001 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

|test range<br>LOD<br>response/<br>recovery time<br>ref|0−83%<br>−<br>−<br>137<br>0−152%<br>−<br>−<br>138<br>0−200%<br>−<br>−<br>139<br>0−75%<br>0.1%<br>50 ms<br>140<br>0−100%<br>−<br>344 ms<br>141<br>0−150%<br>0.1%<br>−<br>142<br>0−350%<br>−<br>−<br>143<br>0−74.1%<br>∼0.025%<br>130 ms<br>144<br>0−75%<br>−<br>−<br>145<br>130−900%<br>−<br>−<br>146<br>0−0.7%<br>−<br>88 ms<br>147<br>23 Pa−30 kPa<br>10.2 Pa<br>11 ms<br>148|13 Pa−0.77 kPa<br>−<br>50/20 ms<br>149<br><br>0−16 kPa<br>−<br>120 ms<br>150|0−40 kPa<br>8 Pa<br>60/40 ms<br>151|0−6 GPa<br>−<br>−<br>152<br><br>0.05−3.5 kPa<br>9 Pa<br>4 ms<br>153<br>10−200 Pa<br>8 Pa<br>14 ms<br>154<br>0.1−5 kPa<br>1.0 Pa<br>109.6 ms<br>155<br>0−40 kPa<br>−<br>26 ms<br>156<br>0−10 kPa<br>1.0 Pa<br>189 ms<br>157<br>10−600 mg<br>10 mg<br>20 ms<br>158<br>0.69 Pa−100.4 Pa<br>0.69 Pa<br>48 ms<br>159<br>0−10 kPa<br>1.0 Pa<br>167 ms<br>160<br>∼623 kPa<br>100 Pa<br>320 ms<br>161<br>0−61.5 kPa<br>0.87 Pa<br>33.5 ms<br>162<br>0−200 ppm<br>−<br>12.7/14.6 s<br>163<br>5−120 ppm<br>−<br>39/139 s<br>164<br>11.6−20 ppm<br>170 ppb<br>5.6/6 s<br>165<br>0−40 ppm<br>−<br>9.7/6.6 s<br>166<br>5−1000 ppm<br>5 ppm<br>18/24 s<br>167<br>0.5−40%<br>0.5%<br>(32 ± 7) s<br>168<br>5−100 ppm<br>5 ppm<br>34 s<br>169<br>the range of 0.1−40 μM and 0.5−60 μM for<br>Ag+ and Mn2+ ions.<br>9.7 nM for Ag+ 102 nM<br>for Mn2+<br>−<br>170<br>1 × 10−14−1 × 10−8 M<br>0.3 × 10−14 M<br>−<br>171<br>0.5−70 μM<br>0.167 μM<br>−<br>172|
|---|---|---|---|---|
|sensitivity (linear<br>range)|256.1 (0−15%)<br>12,900<br>309.1 (0−60%)<br>107.4 (0−10%)<br>128,800 (0−15%)<br>22.9 (0−10%)<br>5.0 (0−200%)<br>190.8 (0−52.6%)<br>3.6 (0−75%)<br>14,000 (120−240%)<br>7400 (0.6−0.7%)<br>0.55 kPa−1 (23 Pa−<br>982 Pa)|11.47 kPa−1<br>148.26 kPa−1 (7 kPa−<br>16 kPa)|507 kPa−1 (0−5.75<br>kPa)|0.07 × 10−6 kPa−1<br>99.5 kPa−1(0.05 kPa−<br>1 kPa)<br>24.63 kPa−1<br>80.4 kPa−1<br>3.844 (0−29 kPa)<br>45.5 kPa−1<br>−<br>165.35 kPa−1<br>12.5 kPa−1<br>128 kPa−1<br>10.75 kPa−1<br>4.7% (200 ppm)<br>−<br>−<br>0.24<br>43.1 (100 ppm)<br>(23.0 ± 4.0)% (4%)<br>−<br>−<br>−<br>−|
|composition|Ti3C2TX-AgNW-PDA/Ni2+<br>MXene/PU<br>MXene/silver<br>Ti3C2/rubber<br>AgNW/WPU-MXene<br>MXene/polyurethane<br>MXene/PAAm/PVA<br>Ti3C2TX/graphene/PDMS<br>Ti3C2TX/PDMS<br>MXene/polystyrene<br>MXene/PDMS<br>MXene/tissue paper|s-MXene/SWNTs<br>MXene/polyacrylate|Ti2C/PDMS|Mo2TiC2O2-based quantum<br>transport device<br>MXene/Au/PET<br>Ti3C2/natural microcapsules<br>CSx/MXene-C<br>MXene/cotton textile<br>MXene/CNC<br>MXene/PDMS<br>MXene/SWCNT<br>MXene/bacterial cellulose<br>MXene/ANFs<br>MXene/PVA/PVP<br>Ti3C2TX/polyacrylamide<br>Ti3C2TX/fluoroalkylsilane<br>Ti3C2TX/W18O49<br>Ti3C2TX/WSe2<br>MXene/Fe2(MoO4)3<br>MXene/Pd colloidal<br>nanoclusters<br>Ti3C2TX/ZnO spheres<br>Ti3C2TX nanosheets<br>AChE/CS-Ti3C2TX/GCE<br>MXene/MWCNTs|
|target<br>MXene|tension<br>Ti3C2TX<br>Ti3C2TX<br>Ti3C2TX<br>Ti3C2TX<br>Ti3C2TX<br>Ti3C2TX<br>Ti3C2TX<br>Ti3C2TX<br>Ti3C2TX<br>Ti3C2TX<br>Ti3C2TX<br>Pressure<br>Ti3C2TX|Ti3C2TX<br>Ti3C2TX|Ti2C|Mo2TiC2O2<br>Ti3C2TX<br>Ti3C2TX<br>Ti3C2TX<br>Ti3C2TX<br>Ti3C2TX<br>Ti3C2TX<br>Ti3C2TX<br>Ti3C2TX<br>Ti3C2TX<br>Ti3C2TX<br>NH3<br>Ti3C2TX<br>VOCs<br>Ti3C2TX<br>Ti3C2TX<br>Ti3C2TX<br>Ti3C2TX<br>H2<br>Ti3C2TX<br>NO2<br>Ti3C2TX<br>Ag+/ Mn2+<br>Ti3C2TX<br>organophosphorous<br>pesticides<br>Ti3C2TX<br>synephrine<br>Ti3C2TX|
|type|force sensors|||gas sensors<br>electrochemical<br>sensors<br>https://dx.doi.org/10.1021/acsnano.1c002<br>4002|



https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

|response/<br>recovery time<br>ref|−<br>173|−<br>174|∼10 s<br>175|6.3 s<br>176|200 ms<br>177|∼1.8 s<br>178|
|---|---|---|---|---|---|---|
|LOD|1.0 nmol L−1|0.98 Fg mL−1|0.7 nM|0.1 °C|−|−|
|test range|0.003 μmol L−1−20.0 μmol L−1|0.05−10,000 pg mL−1||140 °C|0−100 kPa|0−62% 25−40 °C|
|sensitivity (linear<br>range)|−|−|596 mA cm−2 mM−1|up to 986 °C1−|1.67 (0−100 kPa)|220.8 (0−5%)|
|composition|MXene/NH2−CNTs|Ppy@Ti3C2TX/PMo12|pristine and oxidized Ti3C2TX|Ti3C2TX/PDMS|MXene/PAM|MXene-AgNW-PEDOT: PSS-<br>TeNW|
|MXene|Ti3C2TX|Ti3C2TX|Ti3C2TX|Ti3C2TX|ain<br>Ti3C2TX|Ti3C2TX|
|target|fisetin|osteopontin|H2O2|temperature|temperature and str|sensor|
|type|||||multifunctional|sensor|



decay after cyclic test for 10,000 times. Wang and co-workers designed an elastic core−sheath yarn using Ti3C2TX MXene as conductive layer for strain sensing.<sup>66</sup> The MXene-based core− sheath yarn (MCSY) sensor had a GF of ∼0.67, a linear detection range to 120% strain, a LOD of 0.3% strain, and a response time of 0.12 s. The sensing mechanism was attributed to the changes in contact points between conductive filaments. Under compression, the distance between adjacent nanosheets in MXene-based assemblies decreases, leading to resistance change, and this provides the basis for designing piezoresistive sensors.<sup>67</sup> For example, hybrid films composed of elastic P(VDF-TrFE) and Ti3C2TX nanosheets (mass ratio of 1.6:1) were prepared by spin-coating and applied as pressure sensor (Figure 8a).<sup>68</sup> The device showed a GF of 817.4 kPa<sup>−1</sup> at the low loading level of 0.072−0.74 kPa and a GF of 2213.68 kPa<sup>−1</sup> under the high force level ranging from 0.74 to 3.083 kPa (Figure 8b), together with a response time of 16 ms (Figure 8c). Alternatively, Cheng and co-workers fabricated a piezoresistive sensor by spray coating a single layer of Ti3C2TX nanosheets on PDMS surface patterned with spinous microstructures (Figure 8d).<sup>69</sup> The sensing mechanism was essentially originated from the contact resistance change between the microstructured PDMS and the interdigital electrodes (Figure 8e). The ΔI/Ioff raised rapidly with a sensitivity of 151.4 kPa<sup>−1</sup> below 4.7 kPa, then gradually increased between 4.7 and 15 kPa with the corresponding sensitivity of 33.8 kPa<sup>−1</sup> . Under 0.73 kPa, the response and recovery times of the sensor were 125 and 104 ms, respectively. MXene-based aerogels and three-dimensional (3D) foam also show sensitive responses to compression deformation.<sup>70,71</sup> For example, Ti3C2TX/rGO hybrid aerogels were prepared through a simple ice-templated freezing-drying technology and applied as piezoresistive sensors (Figure 8f). The robust 3D framework formed by Ti3C2TX and rGO enabled the sensor a sensitivity of 22.56 kPa<sup>−1</sup> (Figure 8g) with a response time <200 ms.<sup>72</sup> 

Gas Sensors. The identification and quantification of gaseous species, such as CO, NO, CO2, NO2, NH3, H2S, and SOX, are of essential importance for human health, industry safety, emission, and air quality monitoring.<sup>73−76</sup> Because of its 2D layered structure and adjustable surface terminations, MXenes are considered an ideal platform for gas sensing.<sup>77,78</sup> The suitability of Ti2CO2 MXene as sensing material for NH3 was predicted using DFT calculations by Yu and co-workers.<sup>79</sup> Ti2CO2 was the semiconductor and showed strong adsorption to NH3 at Ti sites with a binding energy of −0.37 eV (Figure 9a). Comparably, due to the weak interaction, Ti2CO2 has no response to H2, CO2, O2, CO, N2, NO2, and CH4 (Figure 9b). The suitability of semiconducting M2CO2 (M = Sc, Ti, Zr, Hf) for NH3 sensing was also theoretically evaluated, and the results showed that the effective release/trapping of NH3 on M2CO2 can be controlled by the charge state of M.<sup>80</sup> This conclusion was supported by Khakbaz and co-workers who analyzed the gas sensing performance of Ti3C2TX in the presence of different surface terminations and water molecules.<sup>81</sup> The binding energy between NH3 and the Ti sites near to O atoms is 60%−180% larger than that adjacent to F atoms, indicating that the Ti3C2TX with a low content of F terminations was preferred for NH3 sensing. 

Lee and co-workers experimentally deposited Ti3C2TX thin film on a polyimide substrate by a solution casting method.<sup>82</sup> The Ti3C2TX film with a p-type semiconducting behavior showed a resistance increase when exposed to ethanol, 

4003 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 



Figure 7. (a) Tensile behavior and (b) resistance change of the Ti3C2TX-based strain sensor. Reproduced with permission from ref 62. Copyright 2019 John Wiley and Sons. (c) Fabrication of Ti3C2TX/CNT thin film with a laminar structure. (d) SEM images of the Ti3C2TX/ CNT sensing layer during the first stretching-releasing cycle from (i) 0%, (ii) 5%, (iii) 20%, (iv) 40%, to (v) 80%, then back to (vi) 0%. Reproduced with permission from ref 63. Copyright 2018 American Chemical Society. (e) Photo images of the Ti3C2TX/PVA hydrogel. (f) Self-healable and stretchable demonstrations of the Ti3C2TX/PVA hydrogel. (g) Capacitance response of the Ti3C2TX/PVA hydrogel between 0 to 200% strain. Reproduced with permission from ref 65. Copyright 2019 John Wiley and Sons. 

methanol, acetone, and ammonia, respectively. The sensing mechanism was attributable to the charge transfer between MXenes and the target gas molecules which were supposed to be adsorbed on the defect sites and/or surface terminations (e.g., O and −OH) of MXene nanosheets. For example, according to eqs 6 and 7, when NH3 molecules are adsorbed on Ti3C2TX via O<sup>−</sup> and OH<sup>−</sup> , the generated electrons combine with the holes in Ti3C2TX MXene, leading to resistance increases. 



<!-- Start of picture text -->
2NH3 + 3O− → N2 + 3H2O + 3e− (6)<br><!-- End of picture text -->



<!-- Start of picture text -->
NH3 + OH− → NH2 + H2O + e− (7)<br><!-- End of picture text -->

Further experiments by Kim and co-workers confirmed the high sensitivity of Ti3C2TX to acetone, ethanol, and NH3, with minimal interference of CO2, NO2, or SO2.<sup>83</sup> At room temperature, the sensor showed a detectable range of 50 to 1000 ppb for NH3 with a limit of detection (LOD) of 0.13 ppb. By coating Ti3C2 on ceramic tubes, Wu and co-workers constructed NH3 sensors which had linear response between 10 and 700 ppm.<sup>84</sup> The sensing performance of Ti3C2TX can be further improved by hybridizing with rGO via wet spinning method (Figure 10a). The obtained Ti3C2TX/rGO fibers exhibited obvious electrical response (6.77%) to 50 ppm of NH3 (Figure 10b), which was, respectively, 4.7- and 7.9-fold higher than that of bare rGO and Ti3C2TX electrode.<sup>85</sup> Such an enhancement was assigned to the expanded bandgap of Ti3C2TX from 1.05 to 1.57 eV due to the heterogeneous hybridization with rGO (Figure 10c). In another work, Yuan and co-workers fabricated a Ti3C2TX MXene-based inter- 

connected porous network via electrostatic attraction with electrospun polymer scaffold (Figure 10d).<sup>86</sup> The as-prepared sensor presented response signals to a few different volatile organic compounds (VOCs) with a sensitivity falling in the range of 0.1−0.17 ppm<sup>−1</sup> , a LOD of 50 ppb, and the response/ recovery times <2 min (Figure 10e). Distinct from other 2D materials such as rGO, MoS2, and phosphorene, MXenes showed decreased resistance when exposed to gas species regardless of their type (n- or p-type).<sup>83</sup> Koh and co-workers used an in situ X-ray diffraction (XRD) method to investigate the swelling behavior of Ti3C2TX membrane upon the exposure to gas/vapor (Figure 10f).<sup>87</sup> The experimental observation indicated that the Ti3C2TX membrane selectively responded to ethanol vapor rather than CO2 with an obvious expansion. In addition, the dissolution of target molecules was determined by the intercalated metal ions. It was found that the inserted Na<sup>+</sup> derived from NaOH treatment enabled the significant swelling of Ti3C2TX membrane in the presence of ethanol, thus gaining a high response (Figure 10g). 

In addition to Ti3C2TX, other MXene nanosheets, particularly V2CTX and V4C3TX, have been utilized for gas sensing applications.<sup>79,88</sup> The detection limits of V2CTX to H2 and CH4 were determined to be 1 and 9 ppm, respectively, by Lee and co-workers.<sup>89</sup> Recently, Zhao and co-workers demonstrated the selective acetone detection by V4C3TXbased sensor with a LOD of ∼1 ppm due to the difference in adsorption energy.<sup>90</sup> 

Electrochemical Sensors. Electrochemical sensors are considered powerful tools for a variety of practical applications 

4004 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

<u>ACS Nano</u> 

<mark>www.acsnano.org Review</mark> 



Figure 8. (a) The preparation, (b) current response, and (c) response time of Ti3C2TX@P(VDF-TrFE) film. Reproduced with permission from ref 68. Copyright 2020 American Chemical Society. (d) The preparation of piezoresistive sensors by coating Ti3C2TX nanosheets on spinous microstructures. (e) The sensing mechanism of the device in panel (d) under the original, heavy loading, light loading, and recovery state, respectively. Reproduced with permission from ref 69. Copyright 2020 American Chemical Society. (f) The assembly of Ti3C2TX/rGO aerogel and the corresponding sensing mechanism under pressure. (g) Comparison of the current responses between Ti3C2TX/rGO aerogel and rGO aerogel. Reproduced with permission from ref 72. Copyright 2018 American Chemical Society. 



Figure 9. (a) The density of states of the single-layer Ti2CO2 upon the adsorption of NH3 and CO2. (b) The side and top views of the adsorption of H2, CO2, O2, NH3, CO, N2, NO2, and CH4 on Ti2CO2. Reproduced with permission from ref 79. Copyright 2015 American Chemical Society. 

due to their relatively good selectivity, linear output, excellent repeatability, and low cost. Generally, the interactions between sensing materials and analytes are critically important in determining the sensing performance.<sup>91</sup> MXenes as a typical 2D material have biocompatibility, large specific surface area, rich surface chemistry, tunable lateral size, good electrical conductivity, and mechanical robustness, allowing efficient and selective interaction with target species.<sup>63,92</sup> MXene-based materials have been utilized directly or indirectly as redox transducer and electrocatalysts for detecting small molecules, pharmaceutical drugs, environmental pollutants, and biomarkers. Herein, the design and applications of MXenebased materials for electrochemical detection of environmental pollutants and biomarkers are the focus of this section. 

Environmental Pollutants. Carbendazim (CBZ), a sort of benzimidazole fungicide, has been wildly applied in agriculture, horticulture, forest, and gardening as well as in the preservative industry, yet is harmful to the environment and human health. Therefore, the sensitive and accurate detection of CBZ is highly necessary.<sup>93</sup> Wu and co-workers drop-casted Ti3C2TX on glass carbon electrode (GCE) as sensing material for the determination of CBZ (Figure 11a).<sup>94</sup> The results showed that CBZ can be electrochemically reduced on Ti3C2TX/GCE with a cathodic peak at 0.02 V. The electrocatalytic activity of Ti3C2TX toward CBZ was attributed to the surface terminations on Ti3C2TX MXene. The adsorption energies (Ea) of CBZ on Ti3C2F2 and Ti3C2O2 were −1.31 eV and −0.30 eV, respectively, indicating that the fluorine termination is favorable for electrochemical sensing. As a result, a detection 

4005 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 



Figure 10. (a) Wet spinning of Ti3C2TX/GO hybrid fiber. (b) Sensing responses of Ti3C2TX/rGO hybrid fiber (mass ratio = 4:6), rGO fiber, and Ti3C2TX film to NH3. (c) Energy-level of Ti3C2TX/rGO and Ti3C2TX. Reproduced with permission from ref 85. Copyright 2020 American Chemical Society. (d) Electrospinning 3D Ti3C2TX MXene network. (e) Resistance changes of 3D Ti3C2TX upon exposure to different gases. Reproduced with permission from ref 86. Copyright 2018 Royal Society of Chemistry. (f) In situ XRD measurement and (g) the corresponding (002) peak shift of Ti3C2TX film upon the exposure to CO2 and ethanol. Reproduced with permission from ref 87. Copyright 2019 American Chemical Society. 

limit of 10.3 nM was achieved (Figure 11b). The sensing performance was further improved by Xie and co-workers through hybridizing Ti3C2TX with electrochemically reduced graphene oxide (ERGO) (Figure 11c).<sup>95</sup> The obtained Ti3C2TX/ERGO sensor exhibited a detection limit of 0.67 nM (Figure 11d). By utilizing Ti3C2TX/Au-Pd as a sensing material, Zhao and co-workers designed an electrochemical sensor toward the detection of organophosphorus pesticides (Figure 11e), which was adopted in agriculture to increase crop yields yet caused severe environmental pollution.<sup>96,97</sup> Taking paraoxon as a model pesticide, the as-fabricated sensor showed a linear detection range between 0.1 μg L<sup>−1</sup> and 1000 μg L<sup>−1</sup> with a LOD of 1.75 ng L<sup>−1</sup> (Figure 11f). Methamidophos was also electrochemically detected by the combination of Ti3C2TX/Au and MnO2/Mn3O4 derived from Mn-MOF (Figure 11g).<sup>98</sup> The Ti3C2TX/Au/MnO2/Mn3O4/ GCE exhibited a broad linear detection range of 10<sup>−12</sup> −10<sup>−6</sup> M (Figure 11h). In addition, MXene-based sensors can also detect a variety of substances including synephrine and methamidophos, which are shown in Table 1. 

Heavy metal ions are another type of pollution that can cause cancer and serious environmental contaminations.<sup>99</sup> A kind of alkaline intercalated Ti3C2 (alk-Ti3C2) was synthesized for the detection of Cd (II), Pb (II), Cu (II), and Hg (II) (Figure 12a,b).<sup>100</sup> The results showed that Cd (II), Pb (II), Cu (II), and Hg (II) with a concentration range from 0.1 μM to 1.5 μM were simultaneously determined in 0.1 M acetic acid 

with the respective LOD values of 0.098, 0.041, 0.032, and 0.130 μM. Normally, modifying the MXene surface with active nanomaterials can further improve its sensing performance. Following this direction, Zhu and co-workers reported the synthesis and application of MXene-bismuth (Bi@d-Ti3C2) hybrid for determining Zn (II), Cd (II), and Pb (II).<sup>101</sup> The measured sensitivities were 0.60, 0.84, and 0.98 μA L μg<sup>−1</sup> with the LOD of 0.5, 0.4, and 0.2 μg L<sup>−1</sup> for Zn (II), Cd (II), and Pb (II), respectively, which are much lower than the guidance value of the World Health Organization for drinking water. PANI-Ti3C2 composite was also prepared and loaded on GCE. The modified electrode showed a linear response to Hg<sup>2+</sup> within the concentration of 0.1−20 μg L<sup>−1</sup> and a LOD of 0.017 μg L<sup>−1</sup> .<sup>102</sup> In addition to heavy metal ions, Rasheed and coworkers demonstrated the electrochemical determination of bromine ions (BrO3−) in water using Ti3C2TX as a sensing platform.<sup>103</sup> The obtained sensor exhibited a LOD of 41 nM and a linear response between 50 nM and 5 μM. The sensing mechanism was attributable to the electrocatalytic capability of Ti3C2TX nanosheets toward the selective reduction of BrO3− as displayed in the following equation: 



<!-- Start of picture text -->
− 2+ + − 4+<br>BrO3 + 3Ti + 6H → Br + 3Ti + 3H2O (8)<br><!-- End of picture text -->

Biomarkers. A biomarker as a fingerprint molecule that exists in drugs, blood, fluids, and tissues can reflect the toxicity and pathogenic diseases. Therefore, their accurate detection is of essential importance for early clinical diagnosis, risk 

4006 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 



Figure 11. (a) The detection of CBZ on Ti3C2TX modified electrode and (b) the corresponding calibration curve. Reproduced with permission from ref 94. Copyright 2019 Elsevier. (c) The detection of CBZ based on Ti3C2TX/ERGO/GCE and (d) the corresponding differential pulse voltammetry (DPV) plots in PBS (0.1 M, pH 7.0). Reproduced with permission from ref 95. Copyright 2019 IOP Publishing. (e) The application of Ti3C2TX/Au-Pd nanocomposites in enzyme-based pesticide biosensor and (f) the corresponding amperometric response in PBS (0.01 M, pH 7.4). Reproduced with permission from ref 96. Copyright 2020 Elsevier. (g) Methamidophos assay based on Ti3C2TX/Au/MnO2/Mn3O4/GCE biosensor and (h) the corresponding DPV responses after inhibition with different concentrations of methamidophos from 0, 10<sup>−6</sup> , 10<sup>−8</sup> , 10<sup>−9</sup> , 10<sup>−10</sup> , 10<sup>−11</sup> to 10<sup>−12</sup> M. Reproduced with permission from ref 98. Copyright 2019 Elsevier. 

assessment, and even successful treatment.<sup>106,107</sup> Electrochemical technique has been widely utilized for noninvasive sensing of biomarkers. Isoniazid (INZ) and acetaminophen (ACOP) as two types of commonly used drugs that have the possibility to induce liver damage were determined by Zhang and co-workers using a modified screen-printed electrode (SPE) based on Ti3C2TX nanosheets.<sup>108</sup> The as-fabricated Ti3C2TX MXene/SPE enabled simultaneous determinations of ACOP and INZ with respective linear detection ranges of 0.25−2000 μM (LOD = 0.048 μM) and 0.1−4.6 μM (LOD = 0.064 μM), superior to bare SPE. Shahzad and co-workers reported a dopamine (DA) sensor by drop-casting Ti3C2TX nanosheets on a GCE followed by Nafion coating. A LOD of ∼3 nM and a detectable window of 0.015−10 mM were achieved because of the electrostatic interaction between the negatively charged Ti3C2TX/Nafion and the positively charged DA aromatic molecules.<sup>109</sup> The abundant surface terminations (e.g., −OH, −F and O) on MXenes make them an ideal platform as carriers for immobilizing active substances. For example, tetrahedral DNA nanostructures (TDNs) were coordinately fixed on the surface of Ti3C2TX nanosheets (Figure 12c).<sup>104</sup> By employing gliotoxin aptamer, mycotoxin was efficiently detected with an inspection range from 5 pM to 

10 nM and a LOD of 5 pM. Surface modification was proven as an effective approach to stabilize MXenes at the anodic potential window. Metal nanoclusters (such as Ag, Pd, Au, etc.) were loaded on MXene surfaces and used for electrochemical sensors.<sup>105,110,111</sup> For instance, Pd NPs were uniformly grown on Ti3C2TX surface via self-reduction forming Pd@Ti3C2TX nanocomposites toward the electrochemical determination of L-Cys (Figure 12d).<sup>105</sup> The sensor gave a linear response to L- Cys between 0.5 μM and 10 μM, providing a LOD of 0.14 μM. Neampet and co-workers modified the screen-printed carbon electrode with Pt/PANI/Ti3C2TX MXene for hydrogen peroxide and lactate sensing with respective detection limits of 1.0 μM and 5.0 μM.<sup>112</sup> Similarly, Ti3C2TX MXene/graphite composite showed an improved sensitivity to adrenaline (AD) with a LOD of 9.5 nM.<sup>113</sup> In addition, hybridizing Ti3C2TX MXene with layered double hydroxides (LDHs), the nonenzymatic determination of glucose with a linear response ranging from 0.002 mM to 4.096 mM was achieved by Li and co-workers.<sup>114</sup> The possible mechanism for glucose oxidation on NiCo-LDH in alkaline solution was accomplished by the reduction of Ni (III) to Ni (II) and CO (III) to CO (II), as illustrated in eqs 9 and 10. 

4007 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 



Figure 12. (a) The synthesis of alk-Ti3C2 and (b) the corresponding electrochemical determination of Hg (II), Cu (II), Pb (II), and Cd (II) with the concentrations ranging from 0.1 μM to 1.5 μM. Reproduced with permission from ref 100. Copyright 2017 Elsevier. (c) The modification of GCE with TDN/Ti3C2TX for gliotoxin detection. Reproduced with permission from ref 104. Copyright 2019 Elsevier. (d) The modification of GCE with Pd@Ti3C2TX composite for the detection of L-Cys. Reproduced with permission from ref 105. Copyright 2019 Royal Society of Chemistry. 



Figure 13. (a) Schematic diagram of the Ti3C2TX MXene-based PHOS. (b) Phase shifts at 980 and 1540 nm wavelengths versus pumping power. (c) Response of the designed PHOS. Reproduced with permission under a Creative Commons Attribution 4.0 International License (CC BY 4.0) from ref 118. Copyright 2019 De Gruyter. (d) Ti3C2TX MXene-based fiber SPR sensor and RI sensor. (e) The enhanced performance of fiber RI sensor induced by Ti3C2TX MXene coating. Reproduced with permission from ref 119. Copyright 2020 American Chemical Society. 

NiOOH + C6H12O6 (glucose) → Ni(OH)2 + C6H10O6 (glucolactone) (9) 



<!-- Start of picture text -->
CoOOH + 2C6H12O6 (glucose) → 2Co(OH)2 + C6H10O6 (glucolactone)<br>(10)<br><!-- End of picture text -->

Ti3C2TX MXene/NiCo LDH provided a 2.5-fold higher current than NiCo-LDH owing to prompt electron transfer accelerated by Ti3C2TX. Nonenzymatic sugar detection was lately realized by the combination of NiFe-LDH and Ti3C2TX (Ti3C2TX/NiFe-LDH) (Table 1).<sup>115</sup> 

Optical Sensors. Since MXenes have tunable electronic structure depending on the number of layers and surface 

functional groups, correspondingly they exhibit interesting nonlinear optical characteristics and can withstand a much higher laser radiation power than graphene.<sup>116,117</sup> It has been reported that Ti3C2TX has a wide optical absorption region covering from visible to short-wave infrared with a high photothermal conversion efficiency. Based on this characteristic, Zuo and co-workers built a photothermal optical sensor (PHOS) by adding Ti3C2TX to the Mach−Zehnder interferometer (Figure 13a).<sup>118</sup> As shown in Figure 13b,c, the control efficiency was determined to be 0.19 π mW<sup>−1</sup> mm<sup>−1</sup> under 980 nm pumping, while the estimated rise and decay times were 23.4 and 5 μs, respectively. By depositing Ti3C2TX on optical 

4008 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 



Figure 14. (a) Schematic design of Ti3C2TX-TiO2-based photodetector. (b) UV response of Ti3C2TX film with a thickness of 16 nm in Ar at a bias of 1 V. (c) The influence of air exposure on the photoresponse of Ti3C2TX film with a thickness of 38 nm. Reproduced with permission from ref 120. Copyright 2018 American Chemical Society. (d) The charge-transfer mechanism of the photodetector based on Ti3C2TX and CsPbBr3 in dark and under illumination. (e) I−V curves and (f) response/recovery times of the photodetector based on Ti3C2TX and CsPbBr3. Reproduced with permission from ref 121. Copyright 2019 John Wiley and Sons. 



Figure 15. (a) The device configuration and (b) the response of the Ti3C2-based humidity sensor. Reproduced with permission under a Creative Commons Attribution 3.0 Unported License (CC BY 3.0) from ref 126. Copyright 2017 Royal Society of Chemistry. (c) The adsorption of water molecules on Ti3C2/TiO2 composite. (d) Electrical response of the Ti3C2/TiO2 in the presence of different RHs. (e) The interpretation of sensing mechanism based on the energy-band diagram of Ti3C2/TiO2 composite. Reproduced with permission from ref 130. Copyright 2019 American Chemical Society. 

fiber surfaces, the sensitivities of the surface plasmon resonance (SPR) sensor and refractive index (RI) sensor were, respectively, improved by 30% and 8 times (Figure 13d).<sup>119</sup> The enhanced sensitivity was attributed to the wide optical absorption and the large surface area, resulting in enhanced interaction between incident light, Ti3C2TX nanosheets, and target trace biochemical molecules (Figure 13e). 

MXene nanosheets are chemically unstable in colloidal state and gradually oxidized to TiO2 starting from the defect sites. According to this principle, Chertopalov and co-workers prepared Ti3C2TX-TiO2 composites for UV detection (Figure 

14a).<sup>120</sup> The light response of Ti3C2TX-TiO2 was attributed to the electron transitions in TiO2 induced by UV irradiation. The response behavior was reversible in Ar (Figure 14b), yet changed dramatically in ambient air with a rapid current drop owing to the adsorption/desorption of oxygen on TiO2 (Figure 14c); interestingly, when the gas was switched from air back to Ar, the light response behavior was fully restored (Figure 14c). Deng and co-workers used Ti3C2TX MXene and 2D CsPbBr3 as electrodes and active materials, respectively, to prepare paper-based flexible photodetectors (PDS) arrays. A Schottky barrier at the contact between CsPbBr3 and Ti3C2TX 

4009 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 



Figure 16. (a) The adsorption of H2O on Ti3C2/Ag. Reproduced with permission from ref 134. Copyright 2019 Royal Society of Chemistry. (b) The adsorption of water molecules on Ti3C2TX/polyelectrolyte multilayers. (c) The sensing mechanism and (d) the humidity response of Ti3C2TX/polyelectrolyte-based sensor. Reproduced with permission from ref 136. Copyright 2019 American Chemical Society. 

was formed due to different work functions (Figure 14d).<sup>121</sup> When the incident light had a higher energy than the bandgap of CsPbBr3, electron−hole pairs were photogenerated and separated rapidly by the local electric field, leading to an improved conductivity. The experimental results showed that upon illumination (7.07 mW mm<sup>−2</sup> ), the photocurrent sharply rose to 5.7 μA at the bias of 10 V (Figure 14e). Once the light was turned off, the current immediately dropped back to 1 nA with the response/recovery time of 48/18 ms (Figure 14f). This sensing behavior was mainly attributed to the high quality of the CsPbBr3 crystal, the excellent conductivity of Ti3C2TX, and the Schottky junction between Ti3C2TX and CsPbBr3, leading to rapid separation of photogenerated carriers. 

Humidity Sensors. Humidity sensors are generally applied in a number of traditional fields including meteorology, process control, automation, agriculture, and food storage as well as the emerging fields such as smart home and health care.<sup>122</sup> To date, numerous nanomaterials have been adopted as humidity sensing materials, among which MXenes have the advantage of high conductivity, good hydrophilicity, and abundant surface terminations (e.g., −F and −OH).<sup>123,124</sup> As previously reported, Ti3C2TX showed hydration over a wide range of relative humidity (RH).<sup>125</sup> Water molecules (H2O) were preferentially adsorbed on vacancies and hydrophilic groups via double and/or single hydrogen bonds. The subsequent water layers were mobilized in a way similar to those in bulk liquid with hydronium ions (H3O<sup>+</sup> ) partially generated due to the electric-field-induced ionization. Both H3O<sup>+</sup> and the hydrolyzed oxygen-containing functional groups on Ti3C2 contributed to ionic conductivity. The resistivity of Ti3C2 film was examined versus humidity (Figure 15a).<sup>126</sup> The initial resistance of Ti3C2-based sensor was 243 Ω in dry nitrogen (N2); it dramatically changed to 6341 Ω when exposed to a RH of 80 ± 5%. Moreover, the device showed reversible responses in the range of 0.1%−95% RH with a LOD of 0.1% RH (Figure 15b).<sup>124</sup> As the insertion of cations between MXene interlayers can enhance H2O diffusion, Muckley and co-workers intercalated Mg<sup>2+</sup> and K<sup>+</sup> between MXene nanosheets, then measured their resistance and mass changes 

by neutron scattering upon the exposure to water vapor.<sup>12,127,128</sup> The average d-spacings of Ti3C2-Mg and Ti3C2-K were 15 and 11 Å, respectively, and the Mg(H2O)62+ cluster was considered the best pillar due to its rigid structure. The experimental results showed that the sensors had an optimum LOD of ∼0.8% RH and a detectable range of 0−85% RH with ∼3% resolution. Alternatively, Yang and co-workers synthesized alkalized Ti3C2TX for humidity sensing.<sup>129</sup> The alkalized Ti3C2TX presented good repeatability at 98% RH with the response time of 1 s and the recovery time of 201 s. Li and co-workers prepared the sensing material of Ti3C2/TiO2 via an in situ oxidation reaction in KOH solution forming numerous TiO2 nanowires (thickness of 10−100 nm thick and length of 500 nm−1 μm) on Ti3C2 surfaces (Figure 15c).<sup>130</sup> The humidity sensor had a detection range of 7%−97% and a high sensitivity of 1614 pF/% RH (Figure 15d) because of the increased charge density in Ti3C2/TiO2 heterostructures (Figure 15e).<sup>131</sup> The sensor was further demonstrated with the capability of monitoring the fingertip approaching, proving its potential applications for human-machine interactions and robotics. Wang and co-workers synthesized semiconductor/ metal heterostructure via hydrothermally growing TiOF2 nanospheres on Ti3C2TX substrates.<sup>132</sup> Owing to the protection of hydrophobic TiOF2 nanospheres, the heterostructure (TiOF2@Ti3C2TX) showed excellent stability for moisture detection. The TiOF2@Ti3C2TX composite exhibited the response time and recovery time of 16 and 20 s, respectively. 

Since AgNPs have been demonstrated to possess the ability to reduce the activation energy required for water adsorption, Ti3C2/Ag composites were prepared as humidity sensors (Figure 16a).<sup>133,134</sup> Liu and co-workers assembled 1D AgNWs and 2D Ti3C2 MXene via a vacuum-assisted process, producing a leaf-like structure.<sup>135</sup> A sensing range of 0−80% and a response time of 5 s comparable to that of commercial sensors were achieved. However, the recovery time reached 80 s. The humidity response can be further modulated by incorporating water-sensitive polymers. An and co-workers layer-by-layer hybridized poly(diallyldimethylammonium chloride) (PDAC) 

4010 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

with Ti3C2TX MXene nanosheets and found the conductivity of Ti3C2TX/PDAC showed strong dependence on the number of Ti3C2TX MXene layers and the content of PDAC.<sup>136</sup> In this work, the conductivity of three-layer and five-layer films was, respectively, 21 S cm<sup>−1</sup> and 27 ± 2 S cm<sup>−1</sup> . As the adsorption time was prolonged from 5 to 15 min, the content of PDAC increased from 6.1 wt % to 9.3 wt %, leading to a 46% improvement in humidity sensitivity. In addition, it was found that with the increase of humidity, the distance between Ti3C2TX layers was enlarged, thereby increasing the interlayer tunnel resistance (Figure 16b−d). 

#### CONCLUSIONS AND OUTLOOK 

To date, single-layer MXenes have been successfully top-down synthesized via chemical etching and delamination. Benefiting from their features of tunable conductivity, rich surface groups, hydrophilicity, mechanical robustness, and optical properties, numerous MXene-based sensors were developed, including mechanical sensors, gas sensors, electrochemical sensors, optical sensors, humidity sensors, and multifunctional sensors. In this review, we started with the preparation of MXene nanosheets, and then we introduced the latest development of MXene-based sensors and highlighted the underlying sensing mechanisms in order to provide the guideline for future endeavor in designing high performance sensing devices. Although MXenes are considered a versatile 2D material and impressive achievements have been accomplished, there are still challenges in utilizing MXenes for sensor applications. 

The synthesis of MXene-based sensing materials in a controllable manner is still unachievable. For example, it remains difficult to prepare MXene nanosheets with particular size, defects, surface terminations (e.g., hydroxyl, fluorine, oxygen, or hydrogen), and their arbitrary spatial distribution. The etching of MAX phases unavoidably involves toxic chemicals and complicated procedures. In addition, due to the low yield, the scalable preparation of MXene nanosheets is difficult. 

The interpretation of the interface properties between MXene nanosheets and other substances, such as surface functional groups, gas molecule, water molecule, and the hybrid phase, needs further investigations. The combination of experimental investigation (both in situ and ex situ observation) and theoretical analysis (or prediction) would be a promising direction and deserves great endeavors in the future. 

The interferences from different signals (e.g., humidity, gas, temperature, and strain) lead to inaccurate measurements, which may be partially resolved by a post-data process. Moreover, it is anticipated that the selectivity and sensitivity of MXene-based sensors could be further improved by surface engineering so as to provide specific adsorption and catalytic activity toward a particular molecule. 

Last but not least, particular attention should be paid to the chemical and thermal stability of MXene nanosheets especially in humid environments with the presence of oxygen and high temperature. The irreversible oxidation leads to the permanent degradation of MXenes, which would be a major obstacle hindering MXene-based sensors from practical applications. More efforts should be paid toward this, except for antioxidant modification and stabilizer hybridization of MXene nanosheets. 

#### AUTHOR INFORMATION 

##### Corresponding Authors 

- Gengzhi Sun − Frontiers Science Center for Flexible Electronics, Xi’an Institute of Flexible Electronics (IFE), and Xi’an Institute of Biomedical Materials and Engineering, Northwestern Polytechnical University (NPU), Xi’an 710072, P.R. China; Institute of Advanced Materials (IAM), Nanjing Tech University (NanjingTech), Nanjing 211816, P.R. China; School of Materials Science and Engineering, Henan Polytechnic University, Jiaozuo 454003, P.R. China; orcid.org/0000-0002-8000-8912; Email: iamgzsun@ 

- nwpu.edu.cn 

- Wei Huang − Frontiers Science Center for Flexible Electronics, Xi’an Institute of Flexible Electronics (IFE), and Xi’an Institute of Biomedical Materials and Engineering, Northwestern Polytechnical University (NPU), Xi’an 710072, P.R. China; Institute of Advanced Materials (IAM), Nanjing Tech University (NanjingTech), Nanjing 211816, P.R. China; Email: iamwhuang@nwpu.edu.cn 

##### Authors 

- Yangyang Pei − Frontiers Science Center for Flexible Electronics, Xi’an Institute of Flexible Electronics (IFE), and Xi’an Institute of Biomedical Materials and Engineering, Northwestern Polytechnical University (NPU), Xi’an 710072, P.R. China 

- Xiaoli Zhang − Frontiers Science Center for Flexible Electronics, Xi’an Institute of Flexible Electronics (IFE), and Xi’an Institute of Biomedical Materials and Engineering, Northwestern Polytechnical University (NPU), Xi’an 710072, P.R. China 

- Zengyu Hui − Frontiers Science Center for Flexible Electronics, Xi’an Institute of Flexible Electronics (IFE), and Xi’an Institute of Biomedical Materials and Engineering, Northwestern Polytechnical University (NPU), Xi’an 710072, P.R. China 

- Jinyuan Zhou − School of Physical Science and Technology, Lanzhou University, Lanzhou 730000, P.R. China; orcid.org/0000-0003-0284-105X 

- Xiao Huang − Frontiers Science Center for Flexible Electronics, Xi’an Institute of Flexible Electronics (IFE), and Xi’an Institute of Biomedical Materials and Engineering, Northwestern Polytechnical University (NPU), Xi’an 710072, P.R. China; orcid.org/0000-0002-0106-7763 

Complete contact information is available at: https://pubs.acs.org/10.1021/acsnano.1c00248 

##### Notes 

The authors declare no competing financial interest. 

#### ACKNOWLEDGMENTS 

This work was supported by the National Natural Science Foundation of China (nos. 21975123 and 61704076), the Natural Science Basic Research Program of Shaanxi (no. 2020JM-092), Six Talent Peaks Project in Jiangsu Province (no. XCL-024), Postgraduate Research and Practice Innovation Program of Jiangsu Province (nos. SJCX20_0401 and KYCX20_0997), and the Fundamental Research Funds for the Central Universities. 

4011 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

#### VOCABULARY 

Young’s modulus, the stiffness evaluation of a solid upon elastic deformation; Fermi level, the equilibrium electronic energy of a solid material, referring to the highest energy level that an electron can occupy at the absolute zero temperature; valence band, the highest range of occupied electron energies; conduction band, the lowest range of vacant electronic states; limit of detection (LOD), also known as detection limit, the lowest concentration that can be reliably distinguished by a specific analytical method; gauge factor (GF), the ratio between relative resistance change and mechanical strain, which can be mathematically written as GF = (ΔR/R)/(ΔL/ L). 

#### REFERENCES 

(1) https://www.bccresearch.com/market-research/ instrumentation-and-sensors/sensors-technologies-markets-report. html; BCC Research: Wellesley, MA (accessed 2020-12). 

(2) Naguib, M.; Kurtoglu, M.; Presser, V.; Lu, J.; Niu, J.; Heon, M.; Hultman, L.; Gogotsi, Y.; Barsoum, M. W. Two-Dimensional Nanocrystals Produced by Exfoliation of Ti3AlC2. Adv. Mater. 2011, 23, 4248−4253. 

(3) Nan, J.; Guo, X.; Xiao, J.; Li, X.; Chen, W.; Wu, W.; Liu, H.; Wang, Y.; Wu, M.; Wang, G. Nanoengineering of 2D MXene-Based Materials for Energy Storage Applications. Small 2019, 17, 1902085. (4) Anasori, B.; Lukatskaya, M. R.; Gogotsi, Y. 2D Metal Carbides and Nitrides (MXenes) for Energy Storage. Nat. Rev. Mater. 2017, 2, 16098. 

(5) Anasori, B.; Gogotsi, Y. Introduction to 2D Transition Metal Carbides and Nitrides (MXenes). In 2D Metal Carbides and Nitrides (MXenes) Structure, Properties and Applications; Anasori, B., Gogotsi, Y., Eds.; Springer: Switzerland, 2019; pp 3−12. 

(6) Gogotsi, Y.; Anasori, B. The Rise of MXenes. ACS Nano 2019, 13, 8491−8494. 

(7) Zhao, X.; Xu, H.; Hui, Z.; Sun, Y.; Yu, C.; Xue, J.; Zhou, R.; Wang, L.; Dai, H.; Zhao, Y.; Yang, J.; Zhou, J.; Chen, Q.; Sun, G.; Huang, W. Electrostatically Assembling 2D Nanosheets of MXene and MOF-Derivatives into 3D Hollow Frameworks for Enhanced Lithium Storage. Small 2019, 15, 1904255. 

(8) Yu, H.; Wang, Y.; Jing, Y.; Ma, J.; Du, C.-F.; Yan, Q. Surface Modified MXene-Based Nanocomposites for Electrochemical Energy Conversion and Storage. Small 2019, 15, 1901503. 

(9) Naguib, M.; Mochalin, V. N.; Barsoum, M. W.; Gogotsi, Y. 25th Anniversary Article: MXenes: A New Family of Two-Dimensional Materials. Adv. Mater. 2014, 26, 992−1005. 

(10) Hu, T.; Hu, M.; Li, Z.; Zhang, H.; Zhang, C.; Wang, J.; Wang, X. Interlayer Coupling in Two-Dimensional Titanium Carbide MXenes. Phys. Chem. Chem. Phys. 2016, 18, 20256−20260. 

(11) Xu, J.; Shim, J.; Park, J. H.; Lee, S. MXene Electrode for the Integration of WSe2 and MoS2 Field Effect Transistors. Adv. Funct. Mater. 2016, 26, 5328−5334. 

(12) Mashtalir, O.; Naguib, M.; Mochalin, V. N.; Dall’Agnese, Y.; Heon, M.; Barsoum, M. W.; Gogotsi, Y. Intercalation and Delamination of Layered Carbides and Carbonitrides. Nat. Commun. 2013, 4, 1716. 

(13) Mashtalir, O.; Lukatskaya, M. R.; Zhao, M.-Q.; Barsoum, M. W.; Gogotsi, Y. Amine-Assisted Delamination of Nb2C MXene for LiIon Energy Storage Devices. Adv. Mater. 2015, 27, 3501−3506. 

(14) Li, T.; Yao, L.; Liu, Q.; Gu, J.; Luo, R.; Li, J.; Yan, X.; Wang, W.; Liu, P.; Chen, B.; Zhang, W.; Abbas, W.; Naz, R.; Zhang, D. Fluorine-Free Synthesis of High-Purity Ti3C2TX (T = OH, O) via Alkali Treatment. Angew. Chem., Int. Ed. 2018, 57, 6115−6119. 

(15) Feng, W.; Luo, H.; Wang, Y.; Zeng, S.; Tan, Y.; Zhang, H.; Peng, S. Ultrasonic Assisted Etching and Delaminating of Ti3C2 MXene. Ceram. Int. 2018, 44, 7084−7087. 

(16) Lian, P.; Dong, Y.; Wu, Z.; Zheng, S.; Wang, X.; Wang, S.; Sun, C.; Qin, J.; Shi, X.; Bao, X. Alkalized Ti3C2 MXene Nanoribbons with 

Expanded Interlayer Spacing for High-Capacity Sodium and Potassium Ion Batteries. Nano Energy 2017, 40, 1−8. 

(17) Li, G.; Jiang, K.; Zaman, S.; Xuan, J.; Wang, Z.; Geng, F. Ti3C2 Sheets with an Adjustable Surface and Feature Sizes to Regulate the Chemical Stability. Inorg. Chem. 2019, 58, 9397−9403. 

(18) Srivastava, P.; Mishra, A.; Mizuseki, H.; Lee, K. R.; Singh, A. K. Mechanistic Insight into the Chemical Exfoliation and Functionalization of Ti3C2 MXene. ACS Appl. Mater. Interfaces 2016, 8, 24256− 24264. 

(19) Khazaei, M.; Mishra, A.; Venkataramanan, N. S.; Singh, A. K.; Yunoki, S. Recent Advances in MXenes: From Fundamentals to Applications. Curr. Opin. Solid State Mater. Sci. 2019, 23, 164−178. 

(20) Xiong, D.; Li, X.; Bai, Z.; Lu, S. Recent Advances in Layered Ti3C2TX MXene for Electrochemical Energy Storage. Small 2018, 14, 1703419. 

(21) Sang, X.; Xie, Y.; Lin, M.-W.; Alhabeb, M.; Van Aken, K. L.; Gogotsi, Y.; Kent, P. R. C.; Xiao, K.; Unocic, R. R. Atomic Defects in Monolayer Titanium Carbide (Ti3C2TX) MXene. ACS Nano 2016, 10, 9193−9200. 

(22) Alhabeb, M.; Maleski, K.; Anasori, B.; Lelyukh, P.; Clark, L.; Sin, S.; Gogotsi, Y. Guidelines for Synthesis and Processing of TwoDimensional Titanium Carbide (Ti3C2TX MXene). Chem. Mater. 2017, 29, 7633−7644. 

(23) Halim, J.; Lukatskaya, M. R.; Cook, K. M.; Lu, J.; Smith, C. R.; Naslund, L. A.; May, S. J.; Hultman, L.; Gogotsi, Y.; Eklund, P.; Barsoum, M. W. Transparent Conductive Two-Dimensional Titanium Carbide Epitaxial Thin Films. Chem. Mater. 2014, 26, 2374−2381. 

(24) Ghidiu, M.; Lukatskaya, M. R.; Zhao, M. Q.; Gogotsi, Y.; Barsoum, M. W. Conductive Two-Dimensional Titanium Carbide ‘Clay’ with High Volumetric Capacitance. Nature 2014, 516, 78−81. (25) Lipatov, A.; Alhabeb, M.; Lukatskaya, M. R.; Boson, A.; Gogotsi, Y.; Sinitskii, A. Effect of Synthesis on Quality, Electronic Properties and Environmental Stability of Individual Monolayer Ti3C2 MXene Flakes. Adv. Electron. Mater. 2016, 2, 1600255. 

(26) Urbankowski, P.; Anasori, B.; Makaryan, T.; Er, D.; Kota, S.; Walsh, P. L.; Zhao, M.; Shenoy, V. B.; Barsoum, M. W.; Gogotsi, Y. Synthesis of Two-Dimensional Titanium Nitride Ti4N3 (MXene). Nanoscale 2016, 8, 11385−11391. 

(27) Maleski, K.; Mochalin, V. N.; Gogotsi, Y. Dispersions of TwoDimensional Titanium Carbide MXene in Organic Solvents. Chem. Mater. 2017, 29, 1632−1640. 

(28) Mashtalir, O.; Lukatskaya, M. R.; Kolesnikov, A. I.; RaymundoPinero, E.; Naguib, M.; Barsoum, M. W.; Gogotsi, Y. The Effect of Hydrazine Intercalation on the Structure and Capacitance of 2D Titanium Carbide (MXene). Nanoscale 2016, 8, 9128−9133. 

(29) Yazdanparast, S.; Soltanmohammad, S.; Fash-White, A.; Tucker, G. J.; Brennecka, G. L. Synthesis and Surface Chemistry of 2D TiVC Solid-Solution MXenes. ACS Appl. Mater. Interfaces 2020, 12, 20129−20137. 

(30) Chia, H. L.; Mayorga-Martinez, C. C.; Antonatos, N.; Sofer, Z.; Gonzalez-Julian, J. J.; Webster, R. D.; Pumera, M. MXene Titanium Carbide-Based Biosensor: Strong Dependence of Exfoliation Method on Performance. Anal. Chem. 2020, 92, 2452−2459. 

(31) Feng, A.; Yu, Y.; Wang, Y.; Jiang, F.; Yu, Y.; Mi, L.; Song, L. Two-Dimensional MXene Ti3C2 Produced by Exfoliation of Ti3AlC2. Mater. Des. 2017, 114, 161−166. 

(32) Ghidiu, M.; Halim, J.; Kota, S.; Bish, D.; Gogotsi, Y.; Barsoum, M. W. Ion-Exchange and Cation Solvation Reactions in Ti3C2 MXene. Chem. Mater. 2016, 28, 3507−3514. 

(33) Zhao, R.; Di, H.; Wang, C.; Hui, X.; Zhao, D.; Wang, R.; Zhang, L.; Yin, L. Encapsulating Ultrafine Sb Nanoparticles in Na<sup>+</sup> Pre-Intercalated 3D Porous Ti3C2TX MXene Nanostructures for Enhanced Potassium Storage Performance. ACS Nano 2020, 14, 13938−13951. 

(34) Xu, C.; Wang, L.; Liu, Z.; Chen, L.; Guo, J.; Kang, N.; Ma, X.L.; Cheng, H.-M.; Ren, W. Large-Area High-Quality 2D Ultrathin Mo2C Superconducting Crystals. Nat. Mater. 2015, 14, 1135−1141. 

(35) Wang, Z.-X.; Kochat, V.; Pandey, P.; Kashyap, S.; Chattopadhyay, S.; Samanta, A.; Sarkar, S.; Manimunda, P.; Zhang, 

4012 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

X.; Asif, S.; Singh, A. K.; Chattopadhyay, K.; Tiwary, C. S.; Ajayan, P. M. Metal Immiscibility Route to Synthesis of Ultrathin Carbides, Borides, and Nitrides. Adv. Mater. 2017, 29, 1700364. 

(36) Qi, Y.; Meng, C.; Xu, X.; Deng, B.; Han, N.; Liu, M.; Hong, M.; Ning, Y.; Liu, K.; Zhao, J.; Fu, Q.; Li, Y.; Zhang, Y.; Liu, Z. Unique Transformation from Graphene to Carbide on Re(0001) Induced by Strong Carbon-Metal Interaction. J. Am. Chem. Soc. 2017, 139, 17574−17581. 

(37) Hu, T.; Hu, M.; Gao, B.; Li, W.; Wang, X. Screening Surface Structure of MXenes by High-Throughput Computation and Vibrational Spectroscopic Confirmation. J. Phys. Chem. C 2018, 122, 18501−18509. 

(38) Persson, I.; Halim, J.; Hansen, T. W.; Wagner, J. B.; Darakchieva, V.; Palisaitis, J.; Rosen, J.; Persson, P. O. A. How Much Oxygen Can a MXene Surface Take Before It Breaks? Adv. Funct. Mater. 2020, 30, 1909005. 

(39) Uzun, S.; Seyedin, S.; Stoltzfus, A. L.; Levitt, A. S.; Alhabeb, M.; Anayee, M.; Strobel, C. J.; Razal, J. M.; Dion, G.; Gogotsi, Y. Knittable and Washable Multifunctional MXene-Coated Cellulose Yarns. Adv. Funct. Mater. 2019, 29, 1905015. 

(40) Wang, K.; Zhou, Y.; Xu, W.; Huang, D.; Wang, Z.; Hong, M. Fabrication and Thermal Stability of Two-Dimensional Carbide Ti3C2 Nanosheets. Ceram. Int. 2016, 42, 8419−8424. 

(41) Naguib, M.; Mashtalir, O.; Lukatskaya, M. R.; Dyatkin, B.; Zhang, C.; Presser, V.; Gogotsi, Y.; Barsoum, M. W. One-Step Synthesis of Nanocrystalline Transition Metal Oxides on Thin Sheets of Disordered Graphitic Carbon by Oxidation of MXenes. Chem. Commun. 2014, 50, 7420−7423. 

(42) Borysiuk, V. N.; Mochalin, V. N.; Gogotsi, Y. Molecular Dynamic Study of the Mechanical Properties of Two-Dimensional Titanium Carbides Tin+1Cn (MXenes). Nanotechnology 2015, 26, 265705. 

(43) Lipatov, A.; Lu, H.; Alhabeb, M.; Anasori, B.; Gruverman, A.; Gogotsi, Y.; Sinitskii, A. Elastic Properties of 2D Ti3C2TX MXene Monolayers and Bilayers. Sci. Adv. 2018, 4, eaat0491. 

(44) Ling, Z.; Ren, C. E.; Zhao, M.-Q.; Yang, J.; Giammarco, J. M.; Qiu, J.; Barsoum, M. W.; Gogotsi, Y. Flexible and Conductive MXene Films and Nanocomposites with High Capacitance. Proc. Natl. Acad. Sci. U. S. A. 2014, 111, 16676−16681. 

(45) Lashgari, H.; Abolhassani, M. R.; Boochani, A.; Elahi, S. M.; Khodadadi, J. Electronic and Optical Properties of 2D Graphene-Like Compounds Titanium Carbides and Nitrides: DFT Calculations. Solid State Commun. 2014, 195, 61−69. 

(46) Bai, Y.; Zhou, K.; Srikanth, N.; Pang, J. H. L.; He, X.; Wang, R. Dependence of Elastic and Optical Properties on Surface Terminated Groups in Two-Dimensional MXene Monolayers: A First-Principles Study. RSC Adv. 2016, 6, 35731−35739. 

(47) Berdiyorov, G. R. Optical Properties of Functionalized Ti3C2T2 (T = F, O, OH) MXene: First-Principles Calculations. AIP Adv. 2016, 6, 055105. 

(48) Elumalai, S.; Lombardi, J. R.; Yoshimura, M. The SurfaceEnhanced Resonance Raman Scattering of Dye Molecules Adsorbed on Two-Dimensional Titanium Carbide Ti3C2TX (MXene) Film. Mater. Adv. 2020, 1, 146−152. 

(49) Chaudhuri, K.; Wang, Z.; Alhabeb, M.; Maleski, K.; Gogotsi, Y.; Shalaev, V.; Boltasseva, A. Optical Properties of MXenes. In 2D Metal Carbides and Nitrides (MXenes) Structure, Properties and Applications; Anasori, B., Gogotsi, Y., Eds.; Springer: Switzerland, 2019; pp 327− 346. 

(50) Ronchi, R. M.; Arantes, J. T.; Santos, S. F. Synthesis, Structure, Properties and Applications of MXenes: Current Status and Perspectives. Ceram. Int. 2019, 45, 18167−18188. 

(51) Khazaei, M.; Arai, M.; Sasaki, T.; Chung, C. Y.; Venkataramanan, N. S.; Estili, M.; Sakka, Y.; Kawazoe, Y. Novel Electronic and Magnetic Properties of Two-Dimensional Transition Metal Carbides and Nitrides. Adv. Funct. Mater. 2013, 23, 2185− 2192. 

(52) Tang, Q.; Zhou, Z.; Shen, P. Are MXenes Promising Anode Materials for Li Ion Batteries? Computational Studies on Electronic 

Properties and Li Storage Capability of Ti3C2 and Ti3C2X2 (X = F, OH) Monolayer. J. Am. Chem. Soc. 2012, 134, 16909−16916. 

(53) Xie, Y.; Kent, P. R. C. Hybrid Density Functional Study of Structural and Electronic Properties of Functionalized Tin+1Xn (X = C, N) Monolayers. Phys. Rev. B: Condens. Matter Mater. Phys. 2013, 87, 235441. 

(54) Halim, J.; Kota, S.; Lukatskaya, M. R.; Naguib, M.; Zhao, M.Q.; Moon, E. J.; Pitock, J.; Nanda, J.; May, S. J.; Gogotsi, Y.; Barsoum, M. W. Synthesis and Characterization of 2D Molybdenum Carbide (MXene). Adv. Funct. Mater. 2016, 26, 3118−3127. 

(55) Hart, J. L.; Hantanasirisakul, K.; Lang, A. C.; Anasori, B.; Pinto, D.; Pivak, Y.; Tijn van Omme, J.; May, S. J.; Gogotsi, Y.; Taheri, M. L. Control of MXenes’ Electronic Properties through Termination and Intercalation. Nat. Commun. 2019, 10, 522. 

(56) Wang, C.; Chen, S.; Song, L. Tuning 2D MXenes by Surface Controlling and Interlayer Engineering: Methods, Properties, and Synchrotron Radiation Characterizations. Adv. Funct. Mater. 2020, 30, 2000869. 

(57) Hui, Z.; Chen, R.; Chang, J.; Gong, Y.; Zhang, X.; Xu, H.; Sun, Y.; Zhao, Y.; Wang, L.; Zhou, R.; Ju, F.; Chen, Q.; Zhou, J.; An, J.; Sun, G.; Huang, W. Solution-Processed Sensing Textiles with Adjustable Sensitivity and Linear Detection Range Enabled by Twisting Structure. ACS Appl. Mater. Interfaces 2020, 12, 12155− 12164. 

(58) Dinh Le, T.-S.; An, J.; Huang, Y.; Vo, Q.; Boonruangkan, J.; Tran, T.; Kim, S.-W.; Sun, G.; Kim, Y.-J. Ultrasensitive AntiInterference Voice Recognition by Bio-Inspired Skin-Attachable SelfCleaning Acoustic Sensors. ACS Nano 2019, 13, 13293−13303. 

(59) Li, L.; Shi, P.; Hua, L.; An, J.; Gong, Y.; Chen, R.; Yu, C.; Hua, W.; Xiu, F.; Zhou, J.; Gao, G.; Jin, Z.; Sun, G.; Huang, W. Design of a Wearable and Shape-Memory Fibriform Sensor for the Detection of Multimodal Deformation. Nanoscale 2018, 10, 118−123. 

(60) Anasori, B.; Xie, Y.; Beidaghi, M.; Lu, J.; Hosler, B. C.; Hultman, L.; Kent, P. R. C.; Gogotsi, Y.; Barsoum, M. W. TwoDimensional, Ordered, Double Transition Metals Carbides (MXenes). ACS Nano 2015, 9, 9507−9516. 

(61) Enyashin, A. N.; Ivanovskii, A. L. Atomic Structure, Comparative Stability and Electronic Properties of Hydroxylated Ti2C and Ti3C2 Nanotubes. Comput. Theor. Chem. 2012, 989, 27−32. (62) Yang, Y.; Shi, L.; Cao, Z.; Wang, R.; Sun, J. Strain Sensors with a High Sensitivity and a Wide Sensing Range Based on a Ti3C2TX (MXene) Nanoparticle-Nanosheet Hybrid Network. Adv. Funct. Mater. 2019, 29, 1807882. 

(63) Cai, Y.; Shen, J.; Ge, G.; Zhang, Y.; Jin, W.; Huang, W.; Shao, J.; Yang, J.; Dong, X. Stretchable Ti3C2TX MXene/Carbon Nanotube Composite Based Strain Sensor with Ultrahigh Sensitivity and Tunable Sensing Range. ACS Nano 2018, 12, 56−62. 

(64) Zhang, Y.; Chen, K.; Li, Y.; Lan, J.; Yan, B.; Shi, L.-Y.; Ran, R. High-Strength, Self-Healable, Temperature-Sensitive, MXene-Containing Composite Hydrogel as a Smart Compression Sensor. ACS Appl. Mater. Interfaces 2019, 11, 47350−47357. 

(65) Zhang, J.; Wan, L.; Gao, Y.; Fang, X.; Lu, T.; Pan, L.; Xuan, F. Highly Stretchable and Self-Healable MXene/Polyvinyl Alcohol Hydrogel Electrode for Wearable Capacitive Electronic Skin. Adv. Electron. Mater. 2019, 5, 1900285. 

(66) Wang, L.; Tian, M.; Zhang, Y.; Sun, F.; Qi, X.; Liu, Y.; Qu, L. Helical Core-Sheath Elastic Yarn-Based Dual Strain/Humidity Sensors with MXene Sensing Layer. J. Mater. Sci. 2020, 55, 6187− 6194. 

(67) Ma, Y.; Liu, N.; Li, L.; Hu, X.; Zou, Z.; Wang, J.; Luo, S.; Gao, Y. A Highly Flexible and Sensitive Piezoresistive Sensor Based on MXene with Greatly Changed Interlayer Distances. Nat. Commun. 2017, 8, 1207. 

(68) Li, L.; Fu, X.; Chen, S.; Uzun, S.; Levitt, A. S.; Shuck, C. E.; Han, W.; Gogotsi, Y. Hydrophobic and Stable MXene-Polymer Pressure Sensors for Wearable Electronics. ACS Appl. Mater. Interfaces 2020, 12, 15362−15369. 

(69) Cheng, Y.; Ma, Y.; Li, L.; Zhu, M.; Yue, Y.; Liu, W.; Wang, L.; Jia, S.; Li, C.; Qi, T.; Wang, J.; Gao, Y. Bioinspired Microspines for a 

4013 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

High-Performance Spray Ti3C2TX MXene-Based Piezoresistive Sensor. ACS Nano 2020, 14, 2145−2155. 

(70) Yue, Y.; Liu, N.; Liu, W.; Li, M.; Ma, Y.; Luo, C.; Wang, S.; Rao, J.; Hu, X.; Su, J.; Zhang, Z.; Huang, Q.; Gao, Y. 3D Hybrid Porous MXene-Sponge Network and Its Application in Piezoresistive Sensor. Nano Energy 2018, 50, 79−87. 

(71) Yue, Y.; Liu, N.; Ma, Y.; Wang, S.; Liu, W.; Luo, C.; Zhang, H.; Cheng, F.; Rao, J.; Hu, X.; Su, J.; Gao, Y. Highly Self-Healable 3D Microsupercapacitor with MXene-Graphene Composite Aerogel. ACS Nano 2018, 12, 4224−4232. 

(72) Ma, Y.; Yue, Y.; Zhang, H.; Cheng, F.; Zhao, W.; Rao, J.; Luo, S.; Wang, J.; Jiang, X.; Liu, Z.; Liu, N.; Gao, Y. 3D Synergistical MXene/Reduced Graphene Oxide Aerogel for a Piezoresistive Sensor. ACS Nano 2018, 12, 3209−3216. 

(73) Lee, E.; Kim, D. J. Recent Exploration of Two-Dimensional MXenes for Gas Sensing: From a Theoretical to an Experimental View. J. Electrochem. Soc. 2020, 167, 037515. 

(74) Jacoby, M. MXenes Sense Gas Maximally. Chem. Eng. News 2018, 96, 11. 

(75) Rui, K.; Wang, X.; Du, M.; Zhang, Y.; Wang, Q.; Ma, Z.; Zhang, Q.; Li, D.; Huang, X.; Sun, G.; Zhu, J.; Huang, W. Dual-Function Metal-Organic Framework-Based Wearable Fibers for Gas Probing and Energy Storage. ACS Appl. Mater. Interfaces 2018, 10, 2837− 2842. 

(76) Zhou, S.; Mei, H.; Lu, M.; Cheng, L. 3D Printed and Structurally Strengthened Ammonia Sensor. Composites, Part A 2020, 139, 106100. 

(77) Khazaei, M.; Ranjbar, A.; Ghorbani-Asl, M.; Arai, M.; Sasaki, T.; Liang, Y.; Yunoki, S. Nearly Free Electron States in MXenes. Phys. Rev. B: Condens. Matter Mater. Phys. 2016, 93, 205125. 

(78) Soomro, R. A.; Jawaid, S.; Zhu, Q.; Abbas, Z.; Xu, B. A MiniReview on MXenes as Versatile Substrate for Advanced Sensors. Chin. Chem. Lett. 2020, 31, 922−930. 

(79) Yu, X.; Li, Y.; Cheng, J.; Liu, Z.; Li, Q.; Li, W.; Yang, X.; Xiao, B. Monolayer Ti2CO2: A Promising Candidate for NH3 Sensor or Capturer with High Sensitivity and Selectivity. ACS Appl. Mater. Interfaces 2015, 7, 13707−13713. 

(80) Xiao, B.; Li, Y.-C.; Yu, X.-F.; Cheng, J.-B. MXenes: Reusable Materials for NH3 Sensor or Capturer by Controlling the Charge Injection. Sens. Actuators, B 2016, 235, 103−109. 

(81) Khakbaz, P.; Moshayedi, M.; Hajian, S.; Soleimani, M.; Narakathu, B. B.; Bazuin, B. J.; Pourfath, M.; Atashbar, M. Z. Titanium Carbide MXene as NH3 Sensor: Realistic First-Principles Study. J. Phys. Chem. C 2019, 123, 29794−29803. 

(82) Lee, E.; VahidMohammadi, A.; Prorok, B. C.; Yoon, Y. S.; Beidaghi, M.; Kim, D.-J. Room Temperature Gas Sensing of TwoDimensional Titanium Carbide (MXene). ACS Appl. Mater. Interfaces 2017, 9, 37184−37190. 

(83) Kim, S. J.; Koh, H. J.; Ren, C. E.; Kwon, O.; Maleski, K.; Cho, S. Y.; Anasori, B.; Kim, C. K.; Choi, Y. K.; Kim, J.; Gogotsi, Y.; Jung, H. T. Metallic Ti3C2TX MXene Gas Sensors with Ultrahigh Signal-toNoise Ratio. ACS Nano 2018, 12, 986−993. 

(84) Wu, M.; He, M.; Hu, Q.; Wu, Q.; Sun, G.; Xie, L.; Zhang, Z.; Zhu, Z.; Zhou, A. Ti3C2 MXene-Based Sensors with High Selectivity for NH3 Detection at Room Temperature. ACS Sens. 2019, 4, 2763− 2770. 

(85) Lee, S. H.; Eom, W.; Shin, H.; Ambade, R. B.; Bang, J. H.; Kim, H. W.; Han, T. H. Room-Temperature, Highly Durable Ti3C2TX MXene/Graphene Hybrid Fibers for NH3 Gas Sensing. ACS Appl. Mater. Interfaces 2020, 12, 10434−10442. 

(86) Yuan, W.; Yang, K.; Peng, H.; Li, F.; Yin, F. A Flexible VOCs Sensor Based on a 3D MXene Framework with a High Sensing Performance. J. Mater. Chem. A 2018, 6, 18116−18124. 

(87) Koh, H. J.; Kim, S. J.; Maleski, K.; Cho, S. Y.; Kim, Y. J.; Ahn, C. W.; Gogotsi, Y.; Jung, H. T. Enhanced Selectivity of MXene Gas Sensors through Metal Ion Intercalation: In Situ X-Ray Diffraction Study. ACS Sens. 2019, 4, 1365−1372. 

(88) Yang, D.; Fan, X.; Zhao, D.; An, Y.; Hu, Y.; Luo, Z. Sc2CO2 and Mn-Doped Sc2CO2 as Gas Sensor Materials to NO and CO: A FirstPrinciples Study. Phys. E 2019, 111, 84−90. 

(89) Lee, E.; VahidMohammadi, A.; Yoon, Y. S.; Beidaghi, M.; Kim, D. J. Two-Dimensional Vanadium Carbide MXene for Gas Sensors with Ultrahigh Sensitivity Toward Nonpolar Gases. ACS Sens. 2019, 4, 1603−1611. 

(90) Zhao, W.-N.; Yun, N.; Dai, Z.-H.; Li, Y.-F. A High-Performance Trace Level Acetone Sensor Using an Indispensable V4C3TX MXene. RSC Adv. 2020, 10, 1261−1270. 

(91) Fang, X.; Zong, B.; Mao, S. Metal-Organic Framework-Based Sensors for Environmental Contaminant Sensing. Nano-Micro Lett. 2018, 10, 64. 

(92) Scheibe, B.; Wychowaniec, J. K.; Scheibe, M.; Peplińska, B.; Jarek, M.; Nowaczyk, G.; Przysiecka, Ł. Cytotoxicity Assessment of Ti-Al-C Based MAX Phases and Ti3C2TX MXenes on Human Fibroblasts and Cervical Cancer Cells. ACS Biomater. Sci. Eng. 2019, 5, 6557−6569. 

(93) Ma, Y.; Jiang, H.; Shen, C.; Hou, C.; Huo, D.; Wu, H.; Yang, M. Detection of Carbendazim Residues with a Colorimetric Sensor Based on Gold Nanoparticles. J. Appl. Spectrosc. 2017, 84, 460−465. (94) Wu, D.; Wu, M.; Yang, J.; Zhang, H.; Xie, K.; Lin, C.; Yu, A.; Yu, J.; Fu, L. Delaminated Ti3C2TX (MXene) for Electrochemical Carbendazim Sensing. Mater. Lett. 2019, 236, 412−415. 

(95) Xie, Y.; Gao, F.; Tu, X.; Ma, X.; Xu, Q.; Dai, R.; Huang, X.; Yu, Y.; Lu, L. Facile Synthesis of MXene/Electrochemically Reduced Graphene Oxide Composites and Their Application for Electrochemical Sensing of Carbendazim. J. Electrochem. Soc. 2019, 166, B1673−B1680. 

(96) Zhao, F.; Yao, Y.; Jiang, C.; Shao, Y.; Barceló, D.; Ying, Y.; Ping, J. Self-Reduction Bimetallic Nanoparticles on Ultrathin MXene Nanosheets as Functional Platform for Pesticide Sensing. J. Hazard. Mater. 2020, 384, 121358. 

(97) Xu, Y.-L.; Li, F.-Y.; Ndikuryayo, F.; Yang, W.-C.; Wang, H.-M. Cholinesterases and Engineered Mutants for the Detection of Organophosphorus Pesticide Residues. Sensors 2018, 18, 4281. 

(98) Song, D.; Jiang, X.; Li, Y.; Lu, X.; Luan, S.; Wang, Y.; Li, Y.; Gao, F. Metal-Organic Frameworks-Derived MnO2/Mn3O4 Microcuboids with Hierarchically Ordered Nanosheets and Ti3C2 MXene/ Au NPs Composites for Electrochemical Pesticide Detection. J. Hazard. Mater. 2019, 373, 367−376. 

(99) Thatai, S.; Khurana, P.; Kumar, D. Role of Core-Shell Nanocomposites in Heavy Metal Removal. In Smart Materials for Waste Water Applications; Mishra, A. K., Ed.; John Wiley & Sons: New York, 2016; pp 289−309. 

(100) Zhu, X.; Liu, B.; Hou, H.; Huang, Z.; Zeinu, K. M.; Huang, L.; Yuan, X.; Guo, D.; Hu, J.; Yang, J. Alkaline Intercalation of Ti3C2 MXene for Simultaneous Electrochemical Detection of Cd(II), Pb(II), Cu(II) and Hg(II). Electrochim. Acta 2017, 248, 46−57. 

(101) Zhu, X.; Liu, B.; Li, L.; Wu, L.; Chen, S.; Huang, L.; Yang, J.; Liang, S.; Xiao, K.; Hu, J.; Hou, H. A Micromilled Microgrid Sensor with Delaminated MXene-Bismuth Nanocomposite Assembly for Simultaneous Electrochemical Detection of Lead(II), Cadmium(II) and Zinc(II). Microchim. Acta 2019, 186, 776. 

(102) Cheng, H.; Yang, J. Preparation of Ti3C2-PANI Composite as Sensor for Electrochemical Determination of Mercury Ions in Water. Int. J. Electrochem. Sci. 2020, 15, 2295−2306. 

(103) Rasheed, P. A.; Pandey, R. P.; Rasool, K.; Mahmoud, K. A. Ultra-Sensitive Electrocatalytic Detection of Bromate in Drinking Water Based on Nafion/Ti3C2TX (MXene) Modified Glassy Carbon Electrode. Sens. Actuators, B 2018, 265, 652−659. 

(104) Wang, H.; Li, H.; Huang, Y.; Xiong, M.; Wang, F.; Li, C. A Label-Free Electrochemical Biosensor for Highly Sensitive Detection of Gliotoxin Based on DNA Nanostructure/MXene Nanocomplexes. Biosens. Bioelectron. 2019, 142, 111531. 

(105) Rasheed, P. A.; Pandey, R. P.; Jabbar, K. A.; Ponraj, J.; Mahmoud, K. A. Sensitive Electrochemical Detection of L-Cysteine Based on a Highly Stable Pd@Ti3C2TX (MXene) Nanocomposite 

4014 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

Modified Glassy Carbon Electrode. Anal. Methods 2019, 11, 3851− 3856. 

(106) Qian, Q.; Hu, Q.; Li, L.; Shi, P.; Zhou, J.; Kong, J.; Zhang, X.; Sun, G.; Huang, W. Sensitive Fiber Microelectrode Made of Nickel Hydroxide Nanosheets Embedded in Highly-Aligned Carbon Nanotube Scaffold for Nonenzymatic Glucose Determination. Sens. Actuators, B 2018, 257, 23−28. 

(107) Sun, Y.; Xu, H.; Wang, L.; Yu, C.; Zhou, J.; Chen, Q.; Sun, G.; Huang, W. Ultrathin NiMn Layered Double Hydroxide Nanosheets with a Superior Peroxidase Mimicking Performance to Natural HRP for Disposable Paper-Based Bioassays. J. Mater. Chem. B 2021, 9, 983−991. 

(108) Zhang, Y.; Jiang, X.; Zhang, J.; Zhang, H.; Li, Y. Simultaneous Voltammetric Determination of Acetaminophen and Isoniazid Using MXene Modified Screen-Printed Electrode. Biosens. Bioelectron. 2019, 130, 315−321. 

(109) Shahzad, F.; Iqbal, A.; Zaidi, S. A.; Hwang, S. W.; Koo, C. M. Nafion-Stabilized Two-Dimensional Transition Metal Carbide (Ti3C2TX MXene) as a High-Performance Electrochemical Sensor for Neurotransmitter. J. Ind. Eng. Chem. 2019, 79, 338−344. 

(110) Wu, Q.; Li, N.; Wang, Y.; Liu, Y.; Xu, Y.; Wei, S.; Wu, J.; Jia, G.; Fang, X.; Chen, F.; Cui, X. A 2D Transition Metal Carbide MXene-Based SPR Biosensor for Ultrasensitive Carcinoembryonic Antigen Detection. Biosens. Bioelectron. 2019, 144, 111697. 

(111) Rakhi, R. B.; Nayak, P.; Xia, C.; Alshareef, H. N. Novel Amperometric Glucose Biosensor Based on MXene Nanocomposite. Sci. Rep. 2016, 6, 36422. 

(112) Neampet, S.; Ruecha, N.; Qin, J.-Q.; Wonsawat, W.; Chailapakul, O.; Rodthongkum, N. A Nanocomposite Prepared from Platinum Particles, Polyaniline and a Ti3C2 MXene for Amperometric Sensing of Hydrogen Peroxide and Lactate. Microchim. Acta 2019, 186, 752. 

(113) Shankar, S. S.; Shereema, R. M.; Rakhi, R. B. Electrochemical Determination of Adrenaline Using MXene/Graphite Composite Paste Electrodes. ACS Appl. Mater. Interfaces 2018, 10, 43343−43351. (114) Li, M.; Fang, L.; Zhou, H.; Wu, F.; Lu, Y.; Luo, H.; Zhang, Y.; Hu, B. Three-Dimensional Porous MXene/NiCo-LDH Composite for High Performance Non-Enzymatic Glucose Sensor. Appl. Surf. Sci. 2019, 495, 143554. 

(115) Li, H.; Wen, Y.; Zhu, X.; Wang, J.; Zhang, L.; Sun, B. A Novel Heterostructure of a MXene@NiFe-LDH Nanohybrid with Superior Peroxidase-Like Activity for Sensitive Colorimetric Detection of Glutathione. ACS Sustainable Chem. Eng. 2020, 8, 520−526. 

(116) Jiang, X.; Liu, S.; Liang, W.; Luo, S.; He, Z.; Ge, Y.; Wang, H.; Cao, R.; Zhang, F.; Wen, Q.; Li, J.; Bao, Q.; Fan, D.; Zhang, H. Broadband Nonlinear Photonics in Few-Layer MXene Ti3C2TX (T = F, O, or OH). Laser Photonics Rev. 2018, 12, 1700229. 

(117) Jhon, Y. I.; Koo, J.; Anasori, B.; Seo, M.; Lee, J. H.; Gogotsi, Y.; Jhon, Y. M. Metallic MXene Saturable Absorber for Femtosecond Mode-Locked Lasers. Adv. Mater. 2017, 29, 1702496. 

(118) Zuo, Y.; Gao, Y.; Qin, S.; Wang, Z.; Zhou, D.; Li, Z.; Yu, Y.; Shao, M.; Zhang, X. Broadband Multi-Wavelength Optical Sensing Based on Photothermal Effect of 2D MXene Films. Nanophotonics 2020, 9, 123−131. 

(119) Chen, Y.; Ge, Y.; Huang, W.; Li, Z.; Wu, L.; Zhang, H.; Li, X. Refractive Index Sensors Based on Ti3C2TX MXene Fibers. ACS Appl. Nano Mater. 2020, 3, 303−311. 

(120) Chertopalov, S.; Mochalin, V. N. Environment-Sensitive Photoresponse of Spontaneously Partially Oxidized Ti3C2 MXene Thin Films. ACS Nano 2018, 12, 6109−6116. 

(121) Deng, W.; Huang, H.; Jin, H.; Li, W.; Chu, X.; Xiong, D.; Yan, W.; Chun, F.; Xie, M.; Luo, C.; Jin, L.; Liu, C.; Zhang, H.; Deng, W.; Yang, W. All-Sprayed-Processable, Large-Area, and Flexible Perovskite/MXene-Based Photodetector Arrays for Photocommunication. Adv. Opt. Mater. 2019, 7, 1801521. 

(122) Farahani, H.; Wagiran, R.; Hamidon, M. N. Humidity Sensors Principle, Mechanism, and Fabrication Technologies: A Comprehensive Review. Sensors 2014, 14, 7881−7939. 

(123) Zhao, J.; Li, N.; Yu, H.; Wei, Z.; Liao, M.; Chen, P.; Wang, S.; Shi, D.; Sun, Q.; Zhang, G. Highly Sensitive MoS2 Humidity Sensors Array for Noncontact Sensation. Adv. Mater. 2017, 29, 1702076. 

(124) Muckley, E. S.; Naguib, M.; Ivanov, I. N. Multi-Modal, Ultrasensitive, Wide-Range Humidity Sensing with Ti3C2 Film. Nanoscale 2018, 10, 21689−21695. 

(125) Celerier, S.; Hurand, S.; Garnero, C.; Morisset, S.; Benchakar, M.; Habrioux, A.; Chartier, P.; Mauchamp, V.; Findling, N.; Lanson, B.; Ferrage, E. Hydration of Ti3C2TX MXene: An Interstratification Process with Major Implications on Physical Properties. Chem. Mater. 2019, 31, 454−461. 

(126) Roemer, F. M.; Wiedwald, U.; Strusch, T.; Halim, J.; Mayerberger, E.; Barsoum, M. W.; Farle, M. Controlling the Conductivity of Ti3C2 MXenes by Inductively Coupled Oxygen and Hydrogen Plasma Treatment and Humidity. RSC Adv. 2017, 7, 13097−13103. 

(127) Osti, N. C.; Naguib, M.; Ostadhossein, A.; Xie, Y.; Kent, P. R. C.; Dyatkin, B.; Rother, G.; Heller, W. T.; van Duin, A. C. T.; Gogotsi, Y.; Mamontov, E. Effect of Metal Ion Intercalation on the Structure of MXene and Water Dynamics on Its Internal Surfaces. ACS Appl. Mater. Interfaces 2016, 8, 8859−8863. 

(128) Muckley, E. S.; Naguib, M.; Wang, H. W.; Vlcek, L.; Osti, N. C.; Sacci, R. L.; Sang, X.; Unocic, R. R.; Xie, Y.; Tyagi, M.; Mamontov, E.; Page, K. L.; Kent, P. R. C.; Nanda, J.; Ivanov, I. N. Multimodality of Structural, Electrical, and Gravimetric Responses of Intercalated MXenes to Water. ACS Nano 2017, 11, 11118−11126. (129) Yang, Z.; Liu, A.; Wang, C.; Liu, F.; He, J.; Li, S.; Wang, J.; You, R.; Yan, X.; Sun, P.; Duan, Y.; Lu, G. The Improvement of Gas and Humidity Sensing Properties of Organ-Like MXene by Alkaline Treatment. ACS Sens. 2019, 4, 1261−1269. 

(130) Li, N.; Jiang, Y.; Zhou, C.; Xiao, Y.; Meng, B.; Wang, Z.; Huang, D.; Xing, C.; Peng, Z. High-Performance Humidity Sensor Based on Urchin-Like Composite of Ti3C2 MXene-Derived TiO2 Nanowires. ACS Appl. Mater. Interfaces 2019, 11, 38116−38125. 

(131) Burman, D.; Ghosh, R.; Santra, S.; Guha, P. K. Highly Proton Conducting MoS2/Graphene Oxide Nanocomposite Based Chemoresistive Humidity Sensor. RSC Adv. 2016, 6, 57424−57433. 

(132) Wang, Z.; Yu, K.; Feng, Y.; Qi, R.; Ren, J.; Zhu, Z. Stabilizing Ti3C2TX-MXenes with TiOF2 Nanospheres Intercalation to Improve Hydrogen Evolution Reaction and Humidity-Sensing Performance. Appl. Surf. Sci. 2019, 496, 143729. 

(133) Majumder, B. D.; Roy, J. K.; Padhee, S. Recent Advances in Multifunctional Sensing Technology on a Perspective of Multi-Sensor System: A Review. IEEE Sens. J. 2019, 19, 1204−1214. 

(134) Li, N.; Jiang, Y.; Xiao, Y.; Meng, B.; Xing, C.; Zhang, H.; Peng, Z. A Fully Inkjet-Printed Transparent Humidity Sensor Based on a Ti3C2/Ag Hybrid for Touchless Sensing of Finger Motion. Nanoscale 2019, 11, 21522−21531. 

(135) Liu, L.-X.; Chen, W.; Zhang, H.-B.; Wang, Q.-W.; Guan, F.; Yu, Z.-Z. Flexible and Multifunctional Silk Textiles with Biomimetic Leaf-Like MXene/Silver Nanowire Nanostructures for Electromagnetic Interference Shielding, Humidity Monitoring, and SelfDerived Hydrophobicity. Adv. Funct. Mater. 2019, 29, 1905197. 

(136) An, H.; Habib, T.; Shah, S.; Gao, H.; Patel, A.; Echols, I.; Zhao, X.-F.; Radovic, M.; Green, M. J.; Lutkenhaus, J. L. Water Sorption in MXene/Polyelectrolyte Multilayers for Ultrafast Humidity Sensing. ACS Appl. Nano Mater. 2019, 2, 948−955. 

(137) Shi, X.; Wang, H.; Xie, X.; Xue, Q.; Zhang, J.; Kang, S.; Wang, C.; Liang, J.; Chen, Y. Bioinspired Ultrasensitive and Stretchable MXene-Based Strain Sensor via Nacre-Mimetic Microscale “Brickand-Mortar” Architecture. ACS Nano 2019, 13, 649−659. 

(138) Seyedin, S.; Uzun, S.; Levitt, A.; Anasori, B.; Dion, G.; Gogotsi, Y.; Razal, J. M. MXene Composite and Coaxial Fibers with High Stretchability and Conductivity for Wearable Strain Sensing Textiles. Adv. Funct. Mater. 2020, 30, 1910504. 

(139) Li, H.; Du, Z. Preparation of a Highly Sensitive and Stretchable Strain Sensor of MXene/Silver Nanocomposite-Based Yarn and Wearable Applications. ACS Appl. Mater. Interfaces 2019, 11, 45930−45938. 

4015 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

(140) Guo, Q.; Zhang, X.; Zhao, F.; Song, Q.; Su, G.; Tan, Y.; Tao, Q.; Zhou, T.; Yu, Y.; Zhou, Z.; Lu, C. Protein-Inspired Self-Healable Ti3C2 MXenes/Rubber-Based Supramolecular Elastomer for Intelligent Sensing. ACS Nano 2020, 14, 2788−2797. 

(141) Pu, J.-H.; Zhao, X.; Zha, X.-J.; Bai, L.; Ke, K.; Bao, R.-Y.; Liu, Z.-Y.; Yang, M.-B.; Yang, W. Multilayer Structured AgNW/WPUMXene Fiber Strain Sensors with Ultrahigh Sensitivity and a Wide Operating Range for Wearable Monitoring and Healthcare. J. Mater. Chem. A 2019, 7, 15913−15923. 

(142) Yang, K.; Yin, F.; Xia, D.; Peng, H.; Yang, J.; Yuan, W. A Highly Flexible and Multifunctional Strain Sensor Based on a Network-Structured MXene/Polyurethane Mat with Ultra-High Sensitivity and a Broad Sensing Range. Nanoscale 2019, 11, 9949− 9957. 

(143) Liao, H.; Guo, X.; Wan, P.; Yu, G. Conductive MXene Nanocomposite Organohydrogel for Flexible, Healable, Low-Temperature Tolerant Strain Sensors. Adv. Funct. Mater. 2019, 29, 1904507. (144) Yang, Y.; Cao, Z.; He, P.; Shi, L.; Ding, G.; Wang, R.; Sun, J. Ti3C2TX MXene-Graphene Composite Films for Wearable Strain Sensors Featured with High Sensitivity and Large Range of Linear Response. Nano Energy 2019, 66, 104134. 

(145) Zhang, K.; Sun, J.; Song, J.; Gao, C.; Wang, Z.; Song, C.; Wu, Y.; Liu, Y. Self-Healing Ti3C2 MXene/PDMS Supramolecular Elastomers Based on Small Biomolecules Modification for Wearable Sensors. ACS Appl. Mater. Interfaces 2020, 12, 45306−45314. 

(146) Yang, H.; Xiao, X.; Li, Z.; Li, K.; Cheng, N.; Li, S.; Low, J. H.; Jing, L.; Fu, X.; Achavananthadith, S.; Low, F.; Wang, Q.; Yeh, P.-L.; Ren, H.; Ho, J. S.; Yeow, C.-H.; Chen, P.-Y. Wireless Ti3C2TX MXene Strain Sensor with Ultrahigh Sensitivity and Designated Working Windows for Soft Exoskeletons. ACS Nano 2020, 14, 11860−11875. 

(147) Kedambaimoole, V.; Kumar, N.; Shirhatti, V.; Nuthalapati, S.; Sen, P.; Nayak, M. M.; Rajanna, K.; Kumar, S. Laser-Induced Direct Patterning of Free-Standing Ti3C2-MXene Films for Skin Conformal Tattoo Sensors. ACS Sens. 2020, 5, 2086−2095. 

(148) Guo, Y.; Zhong, M.; Fang, Z.; Wan, P.; Yu, G. A Wearable Transient Pressure Sensor Made with MXene Nanosheets for Sensitive Broad-Range Human-Machine Interfacing. Nano Lett. 2019, 19, 1143−1150. 

(149) Zhang, Y.; Chang, T.-H.; Jing, L.; Li, K.; Yang, H.; Chen, P.-Y. Heterogeneous, 3D Architecturing of 2D Titanium Carbide (MXene) for Microdroplet Manipulation and Voice Recognition. ACS Appl. Mater. Interfaces 2020, 12, 8392−8402. 

(150) Yan, J.; Ma, Y.; Li, X.; Zhang, C.; Cao, M.; Chen, W.; Luo, S.; Zhu, M.; Gao, Y. Flexible and High-Sensitivity Piezoresistive Sensor Based on MXene Composite with Wrinkle Structure. Ceram. Int. 2020, 46, 23592−23598. 

(151) Zhao, X.-F.; Hang, C.-Z.; Lu, H.-L.; Xu, K.; Zhang, H.; Yang, F.; Ma, R.-G.; Wang, J.-C.; Zhang, D. W. A Skin-Like Sensor for Intelligent Braille Recognition. Nano Energy 2020, 68, 104346. 

(152) Akkuş, U.̈ Ö.; Balcı, E.; Berber, S. Mo2TiC2O2 MXene-Based Nanoscale Pressure Sensor. Phys. E 2020, 116, 113762. 

(153) Gao, Y.; Yan, C.; Huang, H.; Yang, T.; Tian, G.; Xiong, D.; Chen, N.; Chu, X.; Zhong, S.; Deng, W.; Fang, Y.; Yang, W. Microchannel-Confined MXene Based Flexible Piezoresistive Multifunctional Micro-Force Sensor. Adv. Funct. Mater. 2020, 30, 1909603. 

(154) Wang, K.; Lou, Z.; Wang, L.; Zhao, L.; Zhao, S.; Wang, D.; Han, W.; Jiang, K.; Shen, G. Bioinspired Interlocked StructureInduced High Deformability for Two-Dimensional Titanium Carbide (MXene)/Natural Microcapsule-Based Flexible Pressure Sensors. ACS Nano 2019, 13, 9139−9147. 

(155) Hu, Y.; Zhuo, H.; Luo, Q.; Wu, Y.; Wen, R.; Chen, Z.; Liu, L.; Zhong, L.; Peng, X.; Sun, R. Biomass Polymer-Assisted Fabrication of Aerogels from MXenes with Ultrahigh Compression Elasticity and Pressure Sensitivity. J. Mater. Chem. A 2019, 7, 10273−10281. 

(156) Li, T.; Chen, L.; Yang, X.; Chen, X.; Zhang, Z.; Zhao, T.; Li, X.; Zhang, J. A Flexible Pressure Sensor Based on an MXene-Textile Network Structure. J. Mater. Chem. C 2019, 7, 1022−1027. 

(157) Zhuo, H.; Hu, Y.; Chen, Z.; Peng, X.; Liu, L.; Luo, Q.; Yi, J.; Liu, C.; Zhong, L. A Carbon Aerogel with Super Mechanical and 

Sensing Performances for Wearable Piezoresistive Sensors. J. Mater. Chem. A 2019, 7, 8092−8100. 

(158) Song, D.-K.; Li, X.-F.; Li, X.-P.; Jia, X.-Q.; Min, P.; Yu, Z.-Z. Hollow-Structured MXene-PDMS Composites as Flexible, Wearable and Highly Bendable Sensors with Wide Working Range. J. Colloid Interface Sci. 2019, 555, 751−758. 

(159) Chen, M.; Hu, X.; Li, K.; Sun, J.; Liu, Z.; An, B.; Zhou, X.; Liu, Z. Self-Assembly of Dendritic-Lamellar MXene/Carbon Nanotube Conductive Films for Wearable Tactile Sensors and Artificial Skin. Carbon 2020, 164, 111−120. 

(160) Chen, Z.; Hu, Y.; Zhuo, H.; Liu, L.; Jing, S.; Zhong, L.; Peng, X.; Sun, R. Compressible, Elastic, and Pressure-Sensitive Carbon Aerogels Derived from 2D Titanium Carbide Nanosheets and Bacterial Cellulose for Wearable Sensors. Chem. Mater. 2019, 31, 3301−3312. 

(161) Wang, L.; Zhang, M.; Yang, B.; Tan, J.; Ding, X. Highly Compressible, Thermally Stable, Light-Weight, and Robust Aramid Nanofibers/Ti3AlC2 MXene Composite Aerogel for Sensitive Pressure Sensor. ACS Nano 2020, 14, 10633−10647. 

(162) Lu, Y.; Qu, X.; Zhao, W.; Ren, Y.; Si, W.; Wang, W.; Wang, Q.; Huang, W.; Dong, X. Highly Stretchable, Elastic, and Sensitive MXene-Based Hydrogel for Flexible Strain and Pressure Sensors. Research 2020, 2020, 2038560. 

(163) Zhao, L.; Zheng, Y.; Wang, K.; Lv, C.; Wei, W.; Wang, L.; Han, W. Highly Stable Cross-Linked Cationic Polyacrylamide/ Ti3C2TX MXene Nanocomposites for Flexible Ammonia-Recognition Devices. Adv. Mater. Technol. 2020, 5, 2000248. 

(164) Chen, W. Y.; Lai, S. N.; Yen, C.; Jiang, X.; Peroulis, D.; Stanciu, L. A. Surface Functionalization of Ti3C2TX MXene with Highly Reliable Superhydrophobic Protection for Volatile Organic Compounds Sensing. ACS Nano 2020, 14, 11490−11501. 

(165) Sun, S.; Wang, M.; Chang, X.; Jiang, Y.; Zhang, D.; Wang, D.; Zhang, Y.; Lei, Y. W18O49/Ti3C2TX MXene Nanocomposites for Highly Sensitive Acetone Gas Sensor with Low Detection Limit. Sens. Actuators, B 2020, 304, 127274. 

(166) Chen, W. Y.; Jiang, X.; Lai, S. N.; Peroulis, D.; Stanciu, L. Nanohybrids of a MXene and Transition Metal Dichalcogenide for Selective Detection of Volatile Organic Compounds. Nat. Commun. 2020, 11, 1302. 

(167) Zou, S.; Gao, J.; Liu, L.; Lin, Z.; Fu, P.; Wang, S.; Chen, Z. Enhanced Gas Sensing Properties at Low Working Temperature of Iron Molybdate/MXene Composite. J. Alloys Compd. 2020, 817, 152785. 

(168) Zhu, Z.; Liu, C.; Jiang, F.; Liu, J.; Ma, X.; Liu, P.; Xu, J.; Wang, L.; Huang, R. Flexible and Lightweight Ti3C2TX MXene@Pd Colloidal Nanoclusters Paper Film as Novel H2 Sensor. J. Hazard. Mater. 2020, 399, 123054. 

(169) Yang, Z.; Jiang, L.; Wang, J.; Liu, F.; He, J.; Liu, A.; Lv, S.; You, R.; Yan, X.; Sun, P.; Wang, C.; Duan, Y.; Lu, G. Flexible Resistive NO2 Gas Sensor of Three-Dimensional Crumpled MXene Ti3C2TX/ZnO Spheres for Room Temperature Application. Sens. Actuators, B 2021, 326, 128828. 

(170) Desai, M. L.; Basu, H.; Singhal, R. K.; Saha, S.; Kailasa, S. K. Ultra-Small Two Dimensional MXene Nanosheets for Selective and Sensitive Fluorescence Detection of Ag<sup>+</sup> and Mn<sup>2+</sup> Ions. Colloids Surf., A 2019, 565, 70−77. 

(171) Zhou, L.; Zhang, X.; Ma, L.; Gao, J.; Jiang, Y. Acetylcholinesterase/Chitosan-Transition Metal Carbides Nanocomposites-Based Biosensor for the Organophosphate Pesticides Detection. Biochem. Eng. J. 2017, 128, 243−249. 

(172) Gao, M.; Xie, Y.; Yang, W.; Lu, L. Fabrication of Novel Electrochemical Sensor Based on MXene/MWCNTs Composite for Sensitive Detection of Synephrine. Int. J. Electrochem. Sci. 2020, 15, 4619−4630. 

(173) Ma, X.; Tu, X.; Gao, F.; Xie, Y.; Huang, X.; Fernandez, C.; Qu, F.; Liu, G.; Lu, L.-M.; Yu, Y. Hierarchical Porous MXene/Amino Carbon Nanotubes-Based Molecular Imprinting Sensor for Highly Sensitive and Selective Sensing of Fisetin. Sens. Actuators, B 2020, 309, 127815. 

4016 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

(174) Zhou, S.; Gu, C.; Li, Z.; Yang, L.; He, L.; Wang, M.; Huang, X.; Zhou, N.; Zhang, Z. Ti3C2TX MXene and Polyoxometalate Nanohybrid Embedded with Polypyrrole: Ultra-Sensitive Platform for the Detection of Osteopontin. Appl. Surf. Sci. 2019, 498, 143889. (175) Lorencova, L.; Bertok, T.; Dosekova, E.; Holazova, A.; Paprckova, D.; Vikartovska, A.; Sasinkova, V.; Filip, J.; Kasak, P.; Jerigova, M.; Velic, D.; Mahmoud, K. A.; Tkac, J. Electrochemical Performance of Ti3C2TX MXene in Aqueous Media: Towards Ultrasensitive H2O2 Sensing. Electrochim. Acta 2017, 235, 471−479. (176) Cao, Z.; Yang, Y.; Zheng, Y.; Wu, W.; Xu, F.; Wang, R.; Sun, J. Highly Flexible and Sensitive Temperature Sensors Based on Ti3C2TX (MXene) for Electronic Skin. J. Mater. Chem. A 2019, 7, 25314− 25323. 

(177) Wang, Q.; Pan, X.; Wang, X.; Gao, H.; Chen, Y.; Chen, L.; Ni, Y.; Cao, S.; Ma, X. Spider Web-Inspired Ultra-Stable 3D Ti3C2TX (MXene) Hydrogels Constructed by Temporary Ultrasonic Alignment and Permanent in Situ Self-Assembly Fixation. Composites, Part B 2020, 197, 108187. 

(178) Li, F.; Liu, Y.; Shi, X.; Li, H.; Wang, C.; Zhang, Q.; Ma, R.; Liang, J. Printable and Stretchable Temperature-Strain Dual-Sensing Nanocomposite with High Sensitivity and Perfect Stimulus Discriminability. Nano Lett. 2020, 20, 6176−6184. 

4017 

https://dx.doi.org/10.1021/acsnano.1c00248 ACS Nano 2021, 15, 3996−4017 

