# Impedance Spectroscopy for Perovskite Solar Cells: Characterization, Analysis, and Diagnosis

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Journal of Materials Chemistry C |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 170 |
| 作者 | E. von Hauff, Dino Klotz |
| DOI | 10.1039/d1tc04727b |
| 源文件 | 066_Hauff_2021_Impedance-Spectroscopy-for-Perovskite-Solar-Cell.pdf |

---
Journal of Materials Chemistry C 



# <mark>P</mark> APER 

Published on 08 December 2021 <u>Licensed under CC-BY-NC 4.0</u> 



Cite this: _J. Mater. Chem. C_ , 2022, 10, 742 

# Impedance spectroscopy for perovskite solar cells: characterisation, analysis, and diagnosis 

Elizabeth von Hauff †*<sup>ab</sup> and Dino Klotz †*<sup>cd</sup> 

Impedance spectroscopy (IS) has great potential to become a standard technique for the characterisation, analysis, and diagnosis of perovskite solar cells (PSC). However, the interpretation of IS data from PSC is still challenging due to the large number of dynamic processes which are not yet fully understood. Here we provide a general framework for IS analysis on PSC. We begin by reviewing the timescales reported for electrical and electrochemical dynamics, many of which are too fast or too slow to monitor with IS, and yet they have a significant impact on the impedance spectrum of PSC. To account for this, we review guidelines for obtaining high quality impedance spectra, including suitable measurement settings as well as the relevant device physics at different solar cell operating points. Based on this, we propose a universal equivalent circuit model (ECM) that exploits the fact that impedance spectra from perovskite solar cells ubiquitously demonstrate high and low frequency Received 4th October 2021, signatures that are separated by several orders of magnitude. We show that the high frequency Accepted 6th December 2021 signatures are consistent with fast electronic processes, while the low frequency signatures are DOI: 10.1039/d1tc04727b consistent with electrochemical processes such as ion drift and diffusion and electrochemical reactions. This allows us to propose a simple, robust, and adaptable ECM that can be used to parameterise rsc.li/materials-c relevant material parameters as well as monitor loss mechanisms for all PSC materials and architectures. 

## Introduction 

Perovskite solar cells (PSC) have demonstrated remarkable increases in efficiency,<sup>1</sup> and more recently also notable improvements in stability<sup>2</sup> over the last decade. In the current stage of development, operando characterisation and diagnosis are becoming increasingly important to engineer the transition towards commercialisation. Measurement protocols for current (density)–voltage curves (JV curves) that yield benchmark data for efficiency, open circuit voltage (VOC), fill factor (FF), short circuit current density (JSC) and the hysteresis index (HI) have been established in the literature, and are a straightforward way to characterise fully contacted devices under relevant operating conditions. However, JV measurements alone do not offer insight into the nature of the different dynamic processes that determine and limit solar cell performance. 

> a Fraunhofer Institute for Organic Electronics, Electron Beam and Plasma Technology (FEP), Dresden, Germany. 

E-mail: Elizabeth.von.Hauff@fep.fraunhofer.de b Faculty of Electrical and Computer Engineering, Technical University of Dresden, Dresden, Germany c International Institute for Carbon-Neutral Energy Research (I2CNER), Kyushu University, Fukuoka, Japan. E-mail: dino.klotz@i2cner.kyushu-u.ac.jp d Department of Materials Science and Engineering (DMSE), Massachusetts Institute of Technology (MIT), Cambridge, USA † Both authors contributed equally. 

Impedance spectroscopy (IS) is a versatile characterisation technique to monitor electrical and electrochemical processes operando, as well as profile the electronic structure in electrochemical and solid-state devices. In an IS measurement, the response of the sample to a small-signal, sinusoidal electrical stimulus is monitored as a function of the frequency. The electrical energy of the excitation signal is dissipated and/or stored by the device, depending on the characteristic dynamics being probed. The dynamics, or relaxation processes, can be differentiated if they show a unique relaxation time (or time constant), i.e. the measure for how long it takes for the device to equilibrate after excitation. The information is extracted and quantified from the spectrum using equivalent circuit models (ECM), and the values of the corresponding parameters offer insights into the underlying physical nature of these different processes. IS can be easily performed in complement to standard electrical characterisation, and has proven to be very useful for elucidating different performance-relevant processes and parameters in energy conversion and storage devices.<sup>3</sup> 

In electrochemical cells, IS has been widely used to model charge transfer and chemical reactions at the electrode– electrolyte interface, as these dynamic processes are generally accessible within the IS measurement window.<sup>4,5</sup> Analogous techniques such as Capacitance-frequency (Cf) and deep-level transient spectroscopy (DLTS), which can be summarised as defect spectroscopy techniques, probe electronic structure 

742 | _J. Mater. Chem. C_ , 2022, 10, 742–761 

This journal is © The Royal Society of Chemistry 2022 

Journal of Materials Chemistry C 

Paper 

instead of dynamics, in particular doping and trap profiles of device junctions and interfaces.<sup>6–8</sup> The difference between IS and defect spectroscopy is the mode of operation in which the device is characterised.<sup>9</sup> For IS, the device is measured at a relevant operational DC offset bias in order to quantify electrical or electrochemical dynamics that determine and impact performance. In contrast, for defect spectroscopy, the change in the capacitance of the depleted semiconductor as a function of temperature, voltage, and/or frequency is monitored to determine the energetic distribution of traps. Therefore, the device must be operated in depletion mode for the measurement, i.e. changes in capacitance are only due to the changes in the density of bound charge in the depleted semiconductor. This has proven challenging in emerging PV, as the band diagram and therefore processes determine carrier transport are often not well enough understood to ensure that the depletion approximation is satisfied for the measurement. In this case, additional capacitive signatures due to mobile charge<sup>10,11</sup> result in artefacts in the frequency spectra and errors in the analysis. 

Historically in photovoltaic (PV) research, defect spectroscopy has been more commonly applied than electrochemical IS combined with ECM. This is because the electronic dynamics in silicon and thin film PV are generally too fast to monitor with IS, and defect spectroscopy reveals more useful information related to trap and doping profiles. In the field of emerging PV, however, IS has been gaining increasing attention. Dye sensitised solar cells (DSSC), as electrochemical devices, are well-suited for IS measurements.<sup>12–14</sup> Organic photovoltaics (OPV) are solid-state devices with comparatively slow transport processes, where both IS<sup>15,16</sup> and defect spectroscopy<sup>10,17,18</sup> have been applied to study transport, electronic structure, and interfacial phenomena. 

Perovskite solar cells (PSC) were first reported in 2009<sup>19</sup> and in the wake of rapidly increasing efficiencies, many researchers from other PV communities, including DSSC and OPV, joined the perovskite community. As a result, IS studies on PSC were motivated by earlier insights gained from DSSC and OPV devices. This was only partly successful because in PSC, both ionic and electronic carriers may contribute to the IS signatures, and a wide range of electrical and electrochemical processes take place at the device interfaces. Further, device stability and reproducibility have been rather poor in the past, making it difficult to obtain reliable IS data. Finally, variations in PSC compositions and architectures, combined with different IS measurement protocols, have made it challenging to compare different IS spectra in the literature and extract general features. As a result, there are currently no universally accepted protocols for performing IS on PSC, nor are there universal models for interpreting IS results. 

We, by no means, intend to disregard the extensive, careful, and insightful work that has been done on PSC. We refer the interested reader to examples of this previous work, for example a comprehensive introduction is provided in ref. 20, model approaches are discussed based on the thickness of the absorber layer, illumination intensity, and applied voltage in ref. 21; in ref. 22 this approach is extended to take into account influences of layer thicknesses and contacts, in ref. 23, the dynamic behaviour of PSC is studied in 



Fig. 1 Example schematics of impedance spectra for PSC with HF contribution smaller/larger than LF contribution, with/without negative hook. While sizes and ratios of the diameters of these features can differ, most spectra reported in the literature show shapes that can be seen as variations of the two examples shown here. 

combination with other complementary techniques such as open circuit photovoltage decay (OCVD) and intensity-modulated photovoltage spectroscopy (IMVS). Additional practical guidelines for consistent IS measurements are provided in ref. 24 

A quick survey through the literature reveals an apparent variation between the impedance spectra measured on PSC, including differences in the magnitude of the impedance values, as well as the appearance of features in the Nyquist plots that are difficult to physically interpret, such as negative hooks or loops.<sup>22,23,25–27</sup> However, closer inspection reveals that there is a commonality of nearly all impedance spectra from PSC, namely the general appearance of high frequency (HF) and low frequency (LF) features which are separated in the frequency spectrum by several orders of magnitude, as shown in Fig. 1. 

The nature of these HF and LF signatures have not yet been unequivocally assigned in the literature, although recent studies have demonstrated that the HF signature is consistent with electrical transport while the LF signature is consistent with electrochemical dynamics.<sup>28,29</sup> In a later section, we explain how the HF signature can be attributed to electronic dynamics in the PSC, while LF signatures are classic signatures of electrochemical dynamics. 

Our aim is to provide guidelines for applying IS to study the performance and stability of PSC, as well as to apply IS as a diagnostic tool to identify mechanisms leading to performance loss. We begin by reviewing dynamic processes in PSC and their timescales. This serves as the basis for interpreting and assigning the HF and LF signatures in the IS from PSC. We then review the basics of IS along with rules of good practice for obtaining reliable IS data. Next, we correlate the IS response at different operating points with the JV characteristics from state-of-the-art PSC. Finally, we combine these concepts to suggest a basic, empirical and universal approach to circuit modelling for PSC. This approach facilitates the comparison of IS performed on different PSC architectures, and thereby provides the basis for IS as an operando diagnosis tool for performance characterisation and monitoring, and improved physical insight into failure modes in PSC. 

## Timescales of dynamics in perovskite solar cells 

An understanding of the timescales of dynamics occurring in the operational PSC during measurement is an important 

_J. Mater. Chem. C_ , 2022, 10, 742–761 | 743 

This journal is © The Royal Society of Chemistry 2022 

Journal of Materials Chemistry C 

Paper 

starting point for developing reliable IS measurement protocols and analyses. The challenge, specifically for IS on PSC, is that many of these processes occur on timescales outside the frequency range of the IS measurement (which is generally from microseconds to seconds), and yet, have a direct impact on the electrical response. These dynamics may still manifest in the IS spectrum as either a resistive or capacitive signature, but not as an independent relaxation process. Fast dynamics include electronic processes at short (picoseconds to microseconds) timescales, slow dynamics include (electro-)chemical processes on long (seconds to hours) timescales.<sup>30,31</sup> These electrochemical processes will inevitably be determined by fabrication parameters, such as perovskite composition and the nature of the contact materials, and therefore the nature of these dynamics, e.g. timescale and reversibility, will vary. 

Fig. 2 illustrates the different electronic, ionic, and (electro-) chemical dynamics in PSC and how these compare to the IS measurement window (shaded in dark blue). The relaxation time, t, of each process is indicated on the upper scale bar, 1 while the corresponding characteristic frequency f f ¼ is � 2pt� 

indicated on the lower scale bar. The frequency ranges for the high frequency (HF) semicircles and low frequency (LF) signatures that are commonly observed in IS on PSC are also indicated. 

### Electronic processes in PSC (HF) 

Electronic processes in PSC, such as carrier generation and cooling, radiative recombination (bimolecular recombination), transport, and trapping, are reported to occur on ns–ps timescales<sup>30,32</sup> in studies that apply optical spectroscopy on 

perovskite layers and uncontacted (partial) devices under conditions corresponding to standard 1.5 AM illumination. As the samples were not electrically contacted for these studies, these measurement conditions correspond to open circuit voltage (VOC) conditions, where no current flows and all photogenerated carriers ideally recombine radiatively. 

Applying an external voltage to the solar cell results in the flow of current. Electrical transport of carriers to the electrodes can, in principle, be monitored with IS if the mobility is low and/or the carrier lifetime is long enough. However, in PSC the effective carrier lifetime is reported in the order of ns.<sup>33,34</sup> As a result, carrier transport is too fast to monitor as a dynamic process with IS. 

Trap-assisted, or Shockley–Read–Hall (monomolecular), recombination is a non-ideal recombination process that occurs when photocarriers recombine via defect states either at device interfaces (surface recombination) or in the perovskite, e.g. at grain boundaries.<sup>35</sup> Trap-assisted recombination in PSC is reported to occur on timescales ranging between microseconds and 10s of microseconds.<sup>32,33,36,37</sup> In other words, non-radiative recombination dynamics in PSC border on the threshold of the maximum frequency in the IS measurement window (MHz). It should be noted that non-radiative recombination dynamics (particularly at device interfaces) depend on processing, device architecture, and operating voltage, and therefore timescales may vary.<sup>32,38</sup> 

We note two important points here. Firstly, that there is good agreement between the timescales for electronic processes reported in the literature. Secondly, all of the electronic dynamics in PSC are too fast to monitor as dynamic processes with IS, with the exception perhaps of slower non-radiative 



Fig. 2 Timescales of dynamics in PSC. The top scale bar indicates the relaxation time t of each process. The bottom scale bar indicates the corresponding frequency. The maximum measurement frequency possible in IS measurements without high-frequency compensation bridges is between 1–10 MHz. For the reliable characterisation of dynamics, the measurement frequency should be about an order of magnitude higher than the characteristic frequency. This limits characterisation at the high frequency end of the spectrum. At the lower end, the characterisation of slow processes is limited by more practical aspects such as measurement time, signal-to-noise, and device stability. 

744 | _J. Mater. Chem. C_ , 2022, 10, 742–761 

This journal is © The Royal Society of Chemistry 2022 

Journal of Materials Chemistry C 

Paper 

recombination losses. However, recent studies that combined experimental electrical measurements with modelling concluded that electrical characterisation techniques (including IS) cannot directly access the dynamics of electrical transport - including recombination - but instead interrogate secondary effects.<sup>39,40</sup> Slower ionic transport or ionic migration occurring under illumination and/or applied bias results in a change in the electrostatic environment in the PSC,<sup>41</sup> and this in turn results in slow changes in the electrical transport and recombination dynamics. In this scenario, the HF and LF signatures are interdependent. For example, carrier recombination in PSC was reported to display temperature-activation resembling the Meyer–Neldel (MN) rule,<sup>42</sup> which is not characteristic for electrical recombination dynamics, but instead, is consistent with the MN behaviour reported for ion migration in PSC.<sup>31,41,43</sup> For the analysis of IS, we will later see (cf. Fig. 7) that the geometric capacitance makes it essentially impossible to discern different dynamics within the HF signature. Therefore, more sophisticated analyses from the area of mixed conductors and solid-state electrochemistry could be very useful to elucidate electrical transport properties by exploiting the reciprocal nature of ionic and electrical transport in PSC.<sup>44</sup> 

### Electrochemical processes in PSC (LF) 

Lower frequency (LF) signatures in IS on PSC are consistent with slow electrochemical dynamics, such as chemical reactions and ion migration. These processes are non-ideal photovoltaic processes. In other words, in contrast to ideal electrical processes such as electrical charge transport and recombination,<sup>45</sup> electrochemical processes are not well described in terms of basic solar cell physics, and there are no generalised equations availabe for these processes in the context of PV. Therefore, identification of these LF signatures and the corresponding physical assignment requires a dedicated and systematic approach that, in the best case, includes corroboration with other experiment techniques as well as with simulation. This step is important since the electrochemical processes represent losses in the photovoltaic conversion process, as the incoming solar energy is converted into chemical processes rather than into electrical power. 

### The frequency gap between the HF and LF signatures in IS 

The HF and LF signatures in the IS of PSC have been discussed extensively in the literature, and many reports can be found describing the expected and observed HF and LF behaviour, respectively.<sup>23,39,40,46</sup> However, we want to draw the attention to the ubiquitous frequency gap between HF and LF contributions. Neither theoretical studies nor reported experimental IS measurements on PSC predict or observe any process or characteristic impedance signature between 100 Hz (upper frequency bound of the LF signature) and 10 kHz (lower frequency bound of the HF signature). This is an important consideration for the interpretation and analysis of IS on PSC, and we will utilise this particularity in the ECM section to significantly simplify as well as to generalise our proposed ECM for PSC. 

## Impedance Spectroscopy basics for PSC 

### Impedance Spectroscopy basics 

To perform an IS measurement, a small-signal, sinusoidal electrical input signal (VAC) is superimposed on the applied DC voltage (VDC) 



<!-- Start of picture text -->
V(ot) = VDC + VAC(ot) = VDC + V0 sin(ot) (1)<br><!-- End of picture text -->

where o (= 2pf) is the angular frequency, which is the parameter in the frequency domain on which the impedance Z(o) solely depends. The resulting alternating current IAC is monitored (this corresponds to a potentiostatic impedance measurement, see also the section about measurement settings) and follows 



<!-- Start of picture text -->
I(ot) = IDC + IAC(ot) = IDC + I0 sin(ot + j) (2)<br><!-- End of picture text -->

The amplitude V0 is chosen to maximise the signal-to-noise ratio while ensuring a linear current response, j represents the difference in phase angle between the input voltage VAC and output current IAC in the frequency domain. Fig. 3a depicts the input voltage V0 sin(ot) and output current I0 sin(ot + j) in the time domain, where Dt indicates the time delay between the voltage and current signals. 

The impedance Z is a transfer function, i.e. a linear function that relates the input VAC to the output IAC via: 



<!-- Start of picture text -->
V0<br>Z ¼ expð�ijÞ ¼ ZoðcosðjÞ � i sinðjÞÞ ¼ Z 0 � iZ 00 (3)<br>I0<br><!-- End of picture text -->

Z is a complex function that can be expressed as a magnitude (Zo ¼ pfZ **f** i f **f** i f<sup>02</sup> **f** i f **f** i fþ **f** i f **f** i f Z **f** i f **f** i f<sup>00</sup> **f** i f<sup>2</sup> **f** ) and phase angle (j) for each value of frequency o. Fig. 3b shows the projection of Z(o) in the complex plane, where the real part of Z (Z<sup>0</sup> or RE{Z}) is the resistance to current flow, or simply the resistance. The imaginary part of Z (Z<sup>00</sup> or IM{Z}) is the reactance, i.e. the resistance to changes in current flow. Generally, the relative contributions of Z<sup>0</sup> and Z<sup>00</sup> to the total impedance vary with frequency. Equivalent circuit modelling (ECM) (see section ECM) relies on the assumption that the full impedance spectrum can be modelled with a combination of ideal circuit elements, such as 



Fig. 3 (a) Time domain representation of the current and voltage signals (IAC and VAC) during an impedance measurement for one frequency with both signals harmonically oscillating at different amplitudes (^), and with a time delay (Dt) between VAC and IAC. (b) Schematic of a Nyquist plot with one complex impedance value Z(o). (c) Circuit representation of a fundamental relaxation process with a finite resistance and a finite capacitance. (d) Nyquist plot of the impedance response over the full frequency range of an RC circuit. 

_J. Mater. Chem. C_ , 2022, 10, 742–761 | 745 

This journal is © The Royal Society of Chemistry 2022 

Journal of Materials Chemistry C 

Paper 

resistors (R, j = 01), capacitors (C, j = �901), and/or inductors (L, j = +901), such that the frequency-dependence of Z can be parameterised. 

### Relaxation processes in the impedance spectrum 

With IS, we are probing dynamics in the device. Provided the timescales of the dynamics are within the IS measurement window (Fig. 2), these dynamics manifest as relaxation processes in the impedance spectrum. Relaxation processes in IS can be expressed in terms of the characteristic resistance (R) and capacitance (C), correlated to the dissipation (j = 01) and storage (j = 901) of electrical energy of the excitation signal, respectively. Therefore, ideal relaxation processes are modelled with a resistor–capacitor (RC) circuit (Fig. 3c). The characteristic time constant t of the RC circuit t = RC (4) is equivalent to the time constant of the exponential decay function describing the system’s approach to equilibrium after excitation, and is also referred to as the relaxation time of the physical process. The impedance spectrum of an ideal relaxation results in the well-known semicircle form in the Nyquist plot (Fig. 3d). 

However, measurements on real samples rarely yield spectra with ideal relaxation processes.<sup>47</sup> Specifically, measurements on semiconductor devices and electrochemical systems contain a combination of resistive and reactive signatures, resulting from material polarisation, electrical and ionic transport, interfacial charge transfer, chemical reactions, double layer formation, and/or charge recombination.<sup>3,9,48,49</sup> These relaxation processes are often dispersive, meaning that there may be a distribution of time constants associated with a single dynamic process, for example, charge transfer at an inhomogeneous electrode surface.<sup>3</sup> Further, relaxation processes may overlap in the Nyquist plot, making them either indistinguishable or causing them to appear as distorted.<sup>50</sup> Here, ECM can help to identify and parameterise the individual contributions to the spectrum, which is why modelling is an essential step in impedance analysis. 

### Resistors and capacitors in impedance spectroscopy 

Relaxation processes inherently consist of the dissipation (resistance) and storage (capacitance or inductance) of electrical energy. To facilitate a physical interpretation of an ECM, it should be possible to express and quantify the individual R and C elements in terms of material parameters. 

Resistors. Resistance in IS corresponds to the dissipation of electrical energy as heat. The physical origin for this dissipation may either be due to the reorientation of bound dipole moments in the sample, e.g. methylammonium (MA) cations, or due to the flow of current. IS analysis focuses purely on resistances due to current flow, specifically electrical or ionic transport, including conduction, charge transfer, and recombination. Dipolar reorientation is generally too fast to monitor electrically.<sup>51,52</sup> ECM analysis of relaxation processes 

therefore focuses on dynamics related to mobile charge that are modulated by electrostatic, or geometric, capacitances. 

The definition of the resistance R is not always precise in electrochemistry and photo-electrochemistry. While it is custom to use the area-specific quantity for current (A), i.e. the current density (A cm<sup>�2</sup> ), often no distinction is made between the resistance (O) and the area-specific resistance (O cm<sup>2</sup> ). In PSC literature, the term ‘‘area-specific resistance’’ is not commonly used so it may not be clear which quantity is being used. Therefore, we explicitly state that all resistances discussed here are area-specific (O cm<sup>2</sup> ) unless otherwise stated. Analogously, we only consider the area specific capacitance (F cm<sup>�2</sup> ). In the literature it is common to report current density to facilitate comparison between solar cell parameters in the literature. Analogously, using area-specific resistance and capacitance values facilitates comparison of the IS data. 

To compare the theoretical values introduced here with (absolute) measurement data, the area-specific resistances introduced here have to be divided by the cell area, whereas the area-specific capacitances have to multiplied by the cell area. 

Series resistance. The series resistance RS arises due to parasitic resistance losses from device contacts. Ideally, RS is kept as small as possible, however in the case of thin film solar cells, the transparent conductive oxide windows result in significant values of RS, typically around 10 O in absolute magnitude (here, we do not use the area-specific value because the geometry of the device contacts is usually different from the active device area). The series resistance is the most straightforward resistive signature to identify in IS. It is in series with the other components, and it manifests as a shift in the Nyquist spectrum along the real axis away from the origin. The value of the series resistance measured with IS may be easily corroborated with sheet resistance measurements of contact materials. 

Transport resistance. The transport resistance RTR is a measure for the energy required (or lost) for transporting mobile charges through a material. It is inversely proportional to the conductivity s and can therefore be expressed in terms of relevant material parameters 



<!-- Start of picture text -->
RTR ¼ d � s �1 ¼ d � ðz � q � n � mÞ �1 (5)<br><!-- End of picture text -->

where d is the length of the conduction path or the thickness of the sample, z is the number of charges per carrier (i.e. electron, hole or ion, and therefore for PSC z = 1), q is elementary charge, n the concentration of charge carriers, and m is the carrier mobility. The corresponding drift current density is given by 



<!-- Start of picture text -->
V<br>I ¼ sE ¼ qnmE ¼ qnm (6)<br>d<br><!-- End of picture text -->

RTR is then given as 



<!-- Start of picture text -->
d<br>RTR ¼ (7)<br>qnm<br><!-- End of picture text -->

In addition to resistance due to bulk transport, resistive signatures may also manifest in the IS spectrum due to charge transfer and recombination. 

746 | _J. Mater. Chem. C_ , 2022, 10, 742–761 

This journal is © The Royal Society of Chemistry 2022 

Journal of Materials Chemistry C 

Paper 

Charge transfer resistance. The charge transfer resistance RCT has been widely used to model charge transfer at interfaces in electrochemistry where charge is transferred, for example from ionic current to electrical current, for example over an electrochemical double layer. In solid-state physics, RCT generally reflects a potential barrier for current flow at an interface, for example band bending at a contact junction or grain boundary. Together with the corresponding interfacial capacitance, RCT determines the timescale of charge transfer at these interfaces. Due to the potential barrier, RCT depends on voltage (which impacts the width of the double layer or depletion zone), and sometimes temperature (if the process is thermally activated).<sup>3,53</sup> Examples for charge transfer in PSC are the interfaces of the perovskite with electron transport layer (ETL) and hole transport layer (HTL), the electrochemical reaction during bonding of charged complexes that compensate surface charging, and irreversible material decomposition. Electrical charge transfer is generally very fast, therefore charge transfer signatures monitored with IS are electrochemical, i.e. they involve an electrochemical reaction. Recombination resistance. The recombination resistance Rrec describes an electron capture process. In other words, the transition of an electron (or hole) from the conduction (or valence) band to a defect in the bandgap, or to surface states. Rrec is therefore dependent on the density of carriers, which in turn depends on the applied voltage and illumination intensity.<sup>54,55</sup> A derivation of Rrec in terms of material parameters requires insight into the recombination rate and depth of the trap distribution, although generally it depends on carrier density n and temperature T. We note that as carrier density decreases due to recombination events, the transport resistance increases. Therefore, the resistances Rrec and RTR are interdependent. Generally, interdependent processes are challenging or even impossible to parameterise with IS. However, interdependent processes with sufficiently different timescales may be approximated as independent contributions, and therefore can be modelled individually in an ECM to facilitate analysis. This is, for example, the basis of ECM modelling for DSSC<sup>12</sup> and OPV.<sup>15</sup> Capacitors. Capacitance in IS corresponds to the storage of electrical energy. Physically, capacitance arises either due material polarisation (geometric capacitance), or due to local inhomogeneity in the distribution of free charge (electrochemical capacitance), usually related to charge dynamics. If the impedance response is purely capacitive, the capacitance can be calculated from the impedance according to 



<!-- Start of picture text -->
1<br>C ¼ (8)<br>ioZ<br><!-- End of picture text -->

However, generally the resistive and capacitive signatures must be extracted from the impedance spectrum using an ECM. 

Here we consider ideal capacitors to describe the underlying physics related to transport in solar cells. However, for equivalent circuit modelling of IS data from real samples, ideal capacitors often have to be substituted by constant phase 

elements to account for dispersion, i.e. variations in the timescale of a relaxation process due to sample inhomogeneity. 

Geometric capacitance. The geometric capacitance Cgeo is a function of the dielectric constant and the geometry of the sample, and is given by the equation for the parallel plate capacitor (normalised by the area) 



<!-- Start of picture text -->
eDCe0<br>C ¼ (9)<br>d<br><!-- End of picture text -->

where eDC is the dielectric constant, e0 is the permittivity of free space and d is the thickness of the dielectric layer. It is important to note that, while the permittivity e is frequency dependent, the static dielectric constant eDC reflects the DC dielectric properties of the sample and is, by definition, not frequency dependent. Ideally, eDC can be extracted at low frequencies provided that the e(o) spectrum is constant in this regime. In PSC, mobile charge can lead to frequency-dependent signatures in e(o) at low frequencies, which can result in an artificially high estimate for eDC.<sup>56</sup> 

Geometric capacitances arise due to the polarisation of bulk materials, as well as interfaces. Therefore, the total geometric capacitance may comprise several individual capacitive contributions. Capacitances in series contribute to total capacitance CTOTAL reciprocally, i.e. 



<!-- Start of picture text -->
1 1<br>CTOTAL ¼ þ . . . :<br>�C1 C2 ��1<br><!-- End of picture text -->

This means that the smallest capacitance dominates the total capacitance that is measured. This is the case when considering the PSC, in which the total geometric capacitance of the device is determined by the capacitance of the perovskite bulk in series with the capacitances at the contact interfaces. In this case, the bulk PSC is the lowest (as the film thickness of the bulk is generally orders of magnitude larger than that of the transport layers), and dominates. 

For standard PSC with a thickness of the perovskite absorber of 500 nm and a dielectric constant of 10 to 20,<sup>22,57</sup> the area-specific geometrical capacity of a PSC is 18 nF cm<sup>�2</sup> to 35 nF cm<sup>�2</sup> . 

Electrochemical capacitances. Electrochemical capacitances in IS are associated with a change in the electrochemical potential of the system due to a local rearrangement of charge,<sup>12,49,58</sup> resulting in a capacitive signature with the general form 



<!-- Start of picture text -->
dQ 1<br>C ¼ (10)<br>dV � A<br><!-- End of picture text -->

where Q is the total charge. The parameterisation of specific electrochemical capacitances in terms of material properties requires insight into the electronic structure, as well as the electronic and ionic dynamics in the sample. Chemical capacitances may arise due to a number of different processes, including diffusion of charge, chemical reactions, and carrier injection. An important consideration for modelling IS data is to understand whether the electrochemical capacitances are in 

_J. Mater. Chem. C_ , 2022, 10, 742–761 | 747 

This journal is © The Royal Society of Chemistry 2022 

Journal of Materials Chemistry C 

Paper 

parallel or in series to other dynamics in the device. Examples of commonly reported electrochemical capacitances in solar cells are the diffusion capacitance due to minority carrier transport in the vicinity of the depletion region, and chemical capacitance, due to carrier injection into a depleted or intrinsic semiconductor. 

The diffusion capacitance Cdiff arises in forward-biased diodes due to the accumulation of minority carriers at the boundary of the depletion region. It depends on the voltage, which in turn determines the depletion region width as well as the density of minority carriers, and has the general form (normalised by the area) 



<!-- Start of picture text -->
qnd qV<br>Cdiff � kT e xp �kT� (11)<br><!-- End of picture text -->

The diffusion capacitance is in parallel to drift transport in the solar cell. 

The chemical capacitance Cm arises in systems with a low density of charge, so that the excitation voltage used to perform the IS measurement causes a shift in the chemical potential (Fermi level) of the semiconductor due, e.g. the injection of charge at the contacts 



<!-- Start of picture text -->
Dn 1<br>�<br>Cm ¼ q 2 (12)<br>DEF A<br><!-- End of picture text -->

where EF is the Fermi level of the semiconductor. This phenomenon was first reported in low dimensional semiconductors as the quantum capacitance.<sup>58</sup> In emerging PV, this chemical capacitance has been identified as a relevant source of artefacts and errors in defect spectroscopy on emerging PV, such as OPV<sup>10</sup> and PSC,<sup>11</sup> when the chemical capacitance from mobile charge is wrongly ascribed to defect states. This capacitance is in series to other capacitive signatures in the device, therefore if neglected, it can result in artificially low values for the Cgeo.<sup>58</sup> We note, however, in PSC it is unlikely that this chemical capacitance is relevant for IS measured in forward bias and/or under illumination, but should instead be considered as a potential source of error for capacitancefrequency measurements in depletion mode. 

We summarise this section by noting that with exception of the transport resistance and the geometric capacitance, defining the resistive and capacitive elements in terms of more fundamental material and device parameters requires an understanding of the electronic band diagram, carrier dynamics, and, specifically in the case of PSC, also possible electrochemical dynamics. Identifying the physical nature of resistive and capacitive signatures is not always possible. Therefore, we note here that in the case that either the resistance or capacitance associated with a relaxation process is not easily physically interpreted, it is possible to fully describe the impedance response of a relaxation process with the timescale t combined with either the R or C element. This approach, for example, resolves a major issue with negative loops, because one does not have to physically rationalise the emergence of negative capacity.<sup>59</sup> However, as we will discuss in the later section ECM, in the case of PSC, the geometric 

capacitance makes it nearly impossible to identify and distinguish electronic dynamics. Therefore, we will present a strategy for the modelling of PSC that primarily focusses on distinguishing electronic and electrochemical dynamics, as well as understanding the reciprocity between electronic and electrochemical transport. Specifically, we argue that IS presents an opportunity to identify electrochemical dynamics, and monitor how these impact the electrostatic band diagram and carrier dynamics in PSC. 

Lastly, we note that inductive signatures are frequently reported in IS studies on solar cells, including PSC.<sup>22,59,60</sup> Inductive signatures can arise due to real physical effects, such as long (unshielded) cables.<sup>61</sup> However, they may also arise due to capacitive signatures that lead the VAC excitation, instead of lagging behind it, resulting in a negative capacitance or inductance. In the literature, this has been attributed to trapping and surface recombination.<sup>60</sup> We later discuss potential origins for negative capacitances in PSC related to ion migration. 

### Impedance measurements and analysis on perovskite solar cells 

In this section we discuss good practice for IS measurement protocols for PSC. While PSC architectures vary in the literature, generally benchmark efficiencies for optimised devices are around 20%, with VOC and JSC values in the range of 1.0–1.2 V and 20–25 mA cm<sup>�2</sup> , respectively. That means that the areaspecific electrical properties of these cells are comparable, resulting in resistive and capacitive signatures in IS of the same order of magnitude. This is a feature that has not been appreciated in the community to its full extent, and we believe that the quantitative comparison of IS features between optimised PSC has the potential to serve as basis for more refined diagnosis and comparison than JV curves. 

The solar cell JV curve is relatively simple to interpret in terms of the most relevant figures of merit (VOC, JSC, FF, MPP, efficiency, as well as stability and hysteresis). However, just as for other (photo-)electrochemical devices, the solar cell JV curve provides the sum of losses for all the cumulative processes that occur simultaneously. Those can only be deconvoluted if the underlying physics are known. More quantitative analysis of the JV curve using drift-diffusion simulations can provide additional information about the electrical properties, such as carrier conductivity and mobility, and recombination losses. However, these rely on detailed knowledge of these processes in order to perform accurate modelling. Further analysis of the temperature and light intensity dependence of the VOC can reveal insight into non-ideal losses that fundamentally limit solar cell efficiency. But even then, the JV curve of real solar cells is impacted by multiple, simultaneously occurring dynamic processes that cannot easily be extracted or distinguished using DC electrical measurements. In this regard, IS enables a separation of these dynamics in the frequency range, where the timescales of distinct relaxation processes emerge at characteristic frequencies in the spectrum. Therefore, impedance spectra taken at specific operating points along the JV contain information about dynamics that impact performance. Examining characteristic IS resistive and 

748 | _J. Mater. Chem. C_ , 2022, 10, 742–761 

This journal is © The Royal Society of Chemistry 2022 

Journal of Materials Chemistry C 

### Paper 

capacitive parameters and monitoring their values as a function of different fabrication protocols, for example for the geometric capacitance, offers direct access to values that can be quantitatively compared to parameters from the literature, and be used to identify signatures of faulty samples. Where applicable, standard values for characteristic IS resistor and capacitor parameters are summarised in section ECM (cf. Table 1) below. As a rule of thumb, if the obtained values are off by more than 50% it is a clear indication that something went wrong with the measurement, with the device, or with both. 

Fig. 4 shows the JV curve, power density versus voltage curve and the DC resistance calculated from the slope of the (smoothed) JV curve, taken from ref. 62, where also experimental details can be found. The corresponding PSC has a JSC of about 24 mA cm<sup>�2</sup> , a VOC of 1.11 V and an FF of 71%, which are typical values for a well-performing PSC under 100 mW cm<sup>�2</sup> solar irradiation. The efficiency of about 20% is directly visible from the peak in the power density curve at MPP (20 mW cm<sup>�2</sup> at 100 mW cm<sup>�2</sup> irradiation). The DC resistance, i.e. the impedance for o - 0, can be estimated from the slope of the JV curve and is shown in Fig. 4c. It provides an estimate of the magnitude of the impedance at very low frequencies. This example demonstrates that the expected values for the impedance vary by about three 



Fig. 4 Example of (a) JV curve forward scan (0 V - VOC, dotted line) and backward scan (VOC - 0 V, full line) measured with a scan rate of 200 mV s<sup>�1</sup> ; (b) power density calculated from the respective JV curves demonstrating the efficiency of B20% (20 mW cm<sup>�2</sup> under standard 100 mW cm<sup>�2</sup> illumination); (c) slope of the JV curve (calculated from raw JV data with a smoothing filter. The slope is equivalent to the expected ZDC = Z(o - 0). It should be considered that the measurement of the JV curve is also a dynamic measurement and might not reflect the exact ZDC as a matter of principle. 

orders of magnitude over the full JV curve, depending on the operating voltage. 

Next, we will discuss the expected, ideal impedance response from PSC at VOC, JSC, and MPP. Establishing a unified measurement protocol and guidelines for PSC at these operating points, complete with the expected resistive and capacitive response, enables the comparison of results from the literature, the possibility to join efforts to understand PSC behaviour in detail and, last but not least, to provide guidelines for newcomers to IS and/or PSC. 

### Operating points 

Ensuring that IS measurements are performed at well-defined solar cell operating points is a necessary prerequisite for a useful comparison between IS data extracted from different PSC. The actual numeric values for VOC, JSC, and MPP may differ between devices, which means that the exact values chosen for the DC offset for the IS measurement should always be corroborated with JV measurements on the same devices. In practice, the solar cell parameters can be numerically comparable for good cells or PSC fabricated from the same batch, but even small shifts in the DC offset around the operating point can be decisive for the extracted IS parameters. There are two possible issues related to measurements at open circuit voltage (VOC), for example: (1) the magnitude of the absolute electric field used for the measurement and the associated potential (non-ideal) processes that this can induce, in the worst case, sample degradation. This means that IS results from two devices with different VOC might be difficult to compare. (2) VOC may shift over time or be different for nominally identical cells. Therefore, it is important to ensure the right operating point, as deviations even as small as 50 mV deviation can impact the measured impedance. The choice of operating point, and confirmation of the operating point with JV measurements, is therefore crucial for IS analysis and interpretation. It is not necessary to perform IS at all of the solar cell operating points to extract useful information about the device, and we will highlight the advantages and disadvantages of performing IS at each operating point in the following. 

Open circuit voltage VOC. The VOC is the most commonly used operating point for IS. The impedance of PSC at VOC usually shows a recognizable pattern of two to three semicircles in the Nyquist plot (see Fig. 1), along with occasional hooks or loops with convenient characteristic frequencies and absolute values,<sup>20,22</sup> but the exact shape depends on the cell configuration and the materials applied as absorber, passivation and transport layers, and contacts. As the JV curve is ‘‘straight’’ around VOC, one important precondition for a linear impedance response is fulfilled. The ‘‘eyes’’ (ellipses) in Fig. 5 indicate the range of current and voltage values expected during the measurement at the respective operating point, as represented by the dot in the centre of the eyes. For the case of VOC, the JV curve forms a straight line within the ‘‘eye’’. 

Phenomenologically, VOC is clearly defined as the operating point where no net current flows, and the device is in quasiequilibrium. While in principle, all solar cell operating points 

_J. Mater. Chem. C_ , 2022, 10, 742–761 | 749 

This journal is © The Royal Society of Chemistry 2022 

Journal of Materials Chemistry C 

Paper 



Fig. 5 Schematic of a JV curve with possible operating points for IS measurements, VOC, JSC and MPP plus around the MPP. The points within the ellipses signify the essential steady-state operating point and the ellipses themselves indicate the range of voltage and current density that the devices undergo during the IS measurement, respectively. 

correspond to a steady-state condition (after a characteristic waiting time), quasi-equilibrium is a particular feature of the VOC. At VOC, all photogenerated charge ultimately recombines radiatively, and all electronic processes, drift, diffusion, charge transfer, are reversible and therefore VOC is a clearly defined operating point for extracting dynamics of electronic processes.<sup>63</sup> 

The current changes sign around VOC during the IS measurement, which has raised concerns whether an impedance spectrum measured at VOC satisfies the condition of reversibility, and if the results are then indicative of the operating point. However, for the small perturbations used in IS, the concept of microscopic reversibility can be applied. The concept is based on Boltzmann kinetics and implies that in equilibrium, forward and backwards processes occur at identical non-zero rates, which means the perturbation does not change the nature of the occurring processes (forward into backwards or vice versa) but just their respective rates. The interested reader is also referred to Butler–Volmer kinetics and the concept of the exchange current density, the ‘‘microscopic flux crossing the interface equally in both directions at equilibrium’’.<sup>64</sup> In other words, VOC is thermodynamically welldefined, and this generally facilitates the interpretation of any experimental parameters extracted at this operating point. 

The growing number of reports on accelerated degradation at VOC in PSC highlights the necessity to closely monitor the cell parameters during the experiment, in particular shifting of the DC value of VOC, which will corrupt the IS measurement. On the other hand, non-reversible processes observed at VOC are an excellent indication of stability issues. One has to consider that VOC represents the operating point with the largest electric field inside the device, which can enhance field-dependent processes. This effect can be reduced by using lower light intensities for IS measurements at VOC, in order to reduce the photocurrent density, reduce the VOC, and enhance stability during measurements.<sup>65</sup> However, concrete standards are still missing here, such as well-defined intensities and measurement times. 

In summary, we recommend IS measurements at VOC, as this is the most well-defined operating point physically. 

Short circuit current (density) JSC. IS measurements at JSC have not led to significant analysis results to the best of our knowledge. Although, analogously to VOC, JSC may seem like a well-defined operating point, performing IS at JSC comes with several drawbacks. First, the overall resistance is very high at this point (see Fig. 4c). In practice, it can reach up to several Megaohms. Recall that t = RC, and it is clear that the large resistance leads to large time constants, since capacitance is unlikely to change significantly for a given process. Therefore, the frequency range required to extract useful information would extend to very low frequencies (Fig. 2). If we consider an increase in the resistance by almost three orders of magnitude (from the DC resistance in Fig. 4c), we can estimate an increase in measurement time by a similar factor. The large resistance and the large time constant lead to a huge semicircle in the Nyquist plot, overlapping with possible other features, which makes it practically impossible to gather any relevant information from such a spectrum, apart from the series resistance. The large time constants not only mean that the measurement time will be long, but also the equilibration time at JSC before the measurement will be much longer. Lower light intensity would be counterproductive here because it will lead to even larger resistance values. 

These measurement issues reflect the underlying physics occurring at JSC. Under these conditions, there is no photovoltage and the solar cell produces no power; the energy levels of the transport layers are short-circuited in the outer circuit and all of the electrical energy is being dissipated as current. Those circumstances hardly vary in the voltage amplitude window used for IS; the line in the ‘‘eye’’ at JSC in Fig. 5 is straight which suggests a linear response, however, it is also flat which indicates that there is little information to be gained from the impedance, which probes the relationship between voltage and current (density). In summary, JSC is not recommended as an operating point for impedance analysis. 

Maximum Power Point MPP. MPP is the most interesting operating point from the perspective of PV application and represents the operating point where every PV device should be optimised in terms of efficiency and stability. However, it is the most challenging to obtain reliable IS spectra. This is because, on one hand, the slope of the solar cell JV curve changes rapidly with voltage around MPP, which means that there are significant changes in the impedance response over a narrow voltage range (see also Fig. 4c and 5). Further, especially at low frequencies, even a small excitation amplitude of 10 mV may be sufficient to excite the device out of its nominal operating point, thereby making it difficult to obtain a linear response from the device.<sup>24</sup> It is apparent that the part of the JV curve inside the ‘‘eyes’’ in Fig. 5 is not straight (linear) for the MPP as opposed to the case of the VOC and JSC. The changes in slope or sharp bends in the JV curve around MPP indicate a change in mechanism or at least a change in the rate determining mechanism around this operating point. Starting from JSC, for increasing the voltage, the current density breaks down around the MPP; or, starting from VOC, when increasing the current density, the voltage breaks down around the MPP. That means we expect different limitations left and right of the MPP 

750 | _J. Mater. Chem. C_ , 2022, 10, 742–761 

This journal is © The Royal Society of Chemistry 2022 

Journal of Materials Chemistry C 

Paper 

in the schematic in Fig. 5. As consequence, small changes in the DC offset when measuring IS around the MPP will yield very different spectra. This makes it difficult to compare the results (from different devices and/or different research groups) quantitatively and even qualitatively. Furthermore, it is difficult to determine the MPP by a single (automated) measurement. A JV curve plus subsequent calculations or an integrated MPPtracker are required, and the MPP cannot assumed to be static over time, so the procedure of determining the MPP has to be repeated before each IS measurement, and MPP should obviously not shift during the impedance measurement itself. Phenomenologically, however, hysteresis and poor stability are correlated with time-dependent variations in MPP in PSC. 

It is also worth considering that if FF is approaching unity, i.e. the better the solar cell performance, the more pronounced and the sharper the bend around the MPP gets, which makes an impedance measurement at the MPP even more challenging for the reasons mentioned above. 

In summary, performing IS at operating points around the MPP can – in theory – be very helpful to investigate PSC stability and performance. However, this is practically very challenging to do reliably. 

Summary of IS at VOC, JSC, MPP. We recommend starting with IS analyses at VOC in order to establish reliable protocols that yield insight into the reproducibility and stability of the devices. While we do not recommend IS at JSC, developing reliable protocols for IS performed around MPP could offer interesting insights into device performance and stability. In this case, we recommend performing systematic crosschecks between the DC voltage used for the IS measurement and the JV curve as reliable IS studies at MPP would require dedicated, extensive measurement series. We are not aware of any such investigation at the time of writing. 

Depletion mode. Depletion mode is an important ‘‘operating point’’ for performing measurements that probe the capacitance of the device to extract information about trap and doping profiles, for example capacitance-frequency (Cf) and Mott–Schottky measurements. The analysis of these measurements relies on the depletion approximation being satisfied, i.e., when a well-defined region of the active layer is completely depleted of free charge carriers. Depending on the solar cell architecture, the depletion approximation is satisfied either in the pn junction (pn junction solar cells), or in the vicinity of the semiconductor-contact interface (many thin film solar cells), or throughout the entire active layer (OPV). The depletion approximation essentially means that these specific (functional) junctions of the solar cell are completely depleted of mobile charge, and thereby can be approximated as a parallel plate capacitor. In depletion mode, capacitance (as a function of frequency, voltage, or temperature) corresponds to the density of bound charge in the depletion region, which in turn, can be ascribed to trap occupation or to doping density. 

The depletion approximation is satisfied if no current flows in the device, which, for solar cells, generally corresponds to dark measurements under reverse bias. However, care must be taken to ensure that unexpected carrier dynamics, due e.g. 

failure to fully deplete the semiconductor,<sup>10</sup> carrier injection under reverse bias,<sup>11</sup> or ion migration,<sup>66</sup> do not introduce unexpected electrochemical capacitances related to transport dynamics of electrical or ionic carriers. In short, Cf and Mott– Schottky measurements are used to probe the frequencydependent capacitance of the device, which can be related to electronic structure. Dynamic processes, in particular mobile electronic or ionic species, will result in artefacts in these measurements. In the case of PSC, performing measurements at low temperatures may be a useful approach to limiting artefacts due to ion migration.<sup>9,31</sup> 

### Settings for IS on PSC 

Proper settings to perform IS measurements are a prerequisite for obtaining reliable spectra, however, the process of choosing suitable settings is rarely addressed in the literature. Here, we provide some practical advice on choosing the excitation signal and amplitude, as well as setting up the measurement procedure. 

Excitation signal. Potentiostatic excitation applies a sinusoidal voltage signal (VAC), and the current response (IAC) is measured, and vice versa for galvanostatic excitation. Potentiostatic excitation is generally recommended for large impedance magnitudes, while galvanostatic is recommended for small magnitudes. The range impedance magnitudes measured in PSC (10<sup>1</sup> –10<sup>3</sup> O) are intermediate. However, galvanostatic measurements on PSC are not recommended, as the DC bias voltage is used to clearly define the operating point of the solar cell (e.g. VOC, JSC = J(V = 0)). In galvanostatic measurements, the DC voltage may shift during the measurement, changing the operating point and thereby corrupting the IS measurement. In contrast, the DC operating point is fixed during a potentiostatic measurement. 

Excitation amplitude. IS is a perturbative technique, and the choice for the amplitude of the excitation signal is a trade-off between signal-to-noise ratio (better for larger amplitudes) and linearity (violated at larger amplitudes, see also KK below). For suitable excitation amplitudes, the impedance spectrum is (pseudo)-linear, which means that it is independent of the amplitude for a finite range of excitation amplitude values. The influence of the excitation amplitude on data quality for IS measurements on PSC has been reported.<sup>24</sup> Based on commonly-measured JV curves from PSC, recommended amplitudes are between 5 and 20 mV depending on the impedance analyzer used, measurement noise of the setup, as well as the operating point chosen for performing the measurement. The recommended procedure for identifying a suitable amplitude is to start with a small amplitude and increase it only if the data quality is poor. The increase in voltage amplitude is legitimate if the data quality is improved but the overall shape of the obtained spectrum does not change. Further increase of the averaging (see below) can be performed if the noise is large, and the amplitude cannot be increased, a common issue at low frequencies. 

Equilibration time. When a photoelectrochemical system is transferred between operating points – practically, for solar 

_J. Mater. Chem. C_ , 2022, 10, 742–761 | 751 

This journal is © The Royal Society of Chemistry 2022 

Journal of Materials Chemistry C 

Paper 

cells that means adjusting light and DC bias voltage – the time to equilibrate and reach steady-state in the new operating point depends on the dynamics of the system. 

The slowest process in a PSC determines the required waiting time before starting the impedance measurement. To be clear, the waiting time is not determined by the lowest frequency used in the IS measurement but by the slowest dynamic process in the PSC. As a rule of thumb, at least 3t (t being the time constant of the slowest process, corresponding to the peak frequency of the respective semicircle in the Nyquist plot) should be considered as standard waiting/equilibration time. If the slowest dynamics are not known, the only way to confirm that the device is in equilibrium is to repeat the measurement under the same conditions and check if the spectra are identical. If not, the waiting time should be increased. For unstable cells, this may not be possible due to irreversible degradation over time, but in that case, an impedance analysis is generally questionable. In the ideal case that the dynamics are known and the measurement frequencies are chosen accordingly to include the slowest dynamics, waiting times of 1/3 of the measurement time are a good default value, for example 10 min waiting time for an impedance measurement that takes 30 min. 

Ideally, waiting times for PV devices are determined by electronic processes, which are much faster than the practical times required for setting up and starting the measurement. Therefore, waiting times are practically irrelevant for ideal solar cells. However, in the case of PSC, slow (electro-) chemical processes on much longer timescales can require significant waiting times. In fact, the necessity for waiting times indicates the presence of slow electrochemical processes. 

Averaging. Frequency domain techniques such as IS are less sensitive to noise by design of experiment. Of course, that does not mean that noise is uncritical for IS. Problems with noise can be mitigated by increasing the excitation amplitude (see above) or by longer measurement time, i.e. by applying the excitation signal over multiple periods and averaging or integrating over these periods. At high frequencies, the additional time for more averaging is often not even noticeable, but at low frequencies, averaging can increase the measurement time significantly. Depending on the impedance analyser and the measurement noise, the excitation signal should be applied for 3 to 10 periods at low frequencies. Many analysers allow to set a measurement time as the maximum of number of periods (relevant for low frequencies, recommendation: 3 to 10, depending on noise) and averaging time (relevant for high frequencies, recommendation: 0.5 s to 2 s). Of course, longer measurement times might turn out to be inconvenient and even compromising for the stability of the PSC. 

Measurement frequencies/points per decade (ppd). The measurement frequencies for IS are often given as points per decade (ppd). While more ppd increase the measurement time (particularly at low frequencies), more data points enable more accurate and stable fitting of the IS data. In particular, more data points are required to resolve features over a small frequency range, such as negative loops in the Nyquist plot. 

As a recommendation, 80 to 100 logarithmically distributed frequencies are suggested for 7 decades (10<sup>�1</sup> Hz to 10<sup>6</sup> Hz). 

### Validity of impedance spectra 

Ultimately, a consistent impedance analysis requires reliable spectra. The specific criteria for reliability in IS arise from linear circuit theory: 

(1) Linearity: linearity of the impedance spectrum is provided if IAC scales linearly with VAC, which means that Z = VAC/ IAC is independent of the excitation amplitude. If the amplitude of VAC is too large and exceeds the linear regime, the current response contains higher order harmonics on top of the linear base term. Nonlinear impedance spectra (more specifically, the transfer functions of the higher harmonics) can be analysed, but they require more advanced and non-standard analytical methods than those used to analyse linear impedance spectra. If the spectrum is assumed to be linear, but contains higher harmonics, this can lead to serious errors in the analysis. 

(2) Stability: the sample properties do not change during measurement. In other words, impedance spectra are reproducible and successively measured spectra will be identical; the measured system is time invariant. 

(3) Causality: the sample response IAC is only due to the VAC excitation and not external factors such as the applied DC voltage, illumination, temperature, or other sources. 

(4) Finiteness: impedance values must be finite for finite frequencies. 

Violations of any of these criteria mean that standard analysis approaches, such as ECM, will likely not yield useful information reflecting the physical properties of the sample. 

For impedance measurements on PSC, the most common issues are low sample stability (or not enough waiting time after a change in operating conditions such as voltage, illumination, temperature), and nonlinearity due to poorly chosen VAC amplitude at the operating point of interest. 

The quality of linear impedance spectra can be assessed using the Kramers–Kronig (KK) equations. The KK equations are mathematical relationships that relate the real and the imaginary parts of a complex spectrum. If the transfer function satisfies the criteria of linearity, stability, causality, and finiteness, then the KK relations can be used to calculate the real part of the IS spectrum from the imaginary part, and vice versa. In practice, KK tests are performed on experimental impedance spectra by approximating the KK integrals with a finite chain of resistor–capacitor (RC) elements. This eliminates the challenge of performing the KK integrals (with limits from 0 to infinity) over the finite frequency range of the discrete measurement points (Hz to MHz). The assumption is that an ideal RC circuit is KK compliant, and therefore a chain of RC elements is also KK compliant. Further, any KK compliant impedance spectrum can be fit with a chain of RC elements.<sup>67–69</sup> In ref. 67, the test procedure is introduced, while ref. 68 introduces an independent criterion for the number of RC elements to be used for the KK test, and ref. 69 shows that the general assumption of approximability holds true. 

752 | _J. Mater. Chem. C_ , 2022, 10, 742–761 

This journal is © The Royal Society of Chemistry 2022 

Journal of Materials Chemistry C 

Paper 

The KK test quantifies deviations between the measured and predicted values of the real and imaginary components of the impedance spectrum as the corresponding residuals. It is not possible to generally quantify threshold maximum values for the residuals. In principle, stochastically distributed residuals point towards noise and larger values, i.e. up to 2% might be tolerable, whereas a systematic deviation over a larger frequency range indicates issues with sample stability and measurement reproducibility, even if its maximum deviation is below 0.5%. 

In the case of PSC, we have observed that it is not easy to obtain KK-compliant IS spectra. Hysteresis effects in the JV curve combined with limited sample stability make it challenging to find a stable operating point. That underlines the importance to perform KK-tests to confirm that IS spectra are consistent and reliable. It has been shown by the group of Adachi that even PSC showing less than 1% degradation in performance over 1000 hours under operation in light did not show stable impedance spectra at VOC due to reversible polarisation behaviour that occurs over the range of tens of minutes to several hours.<sup>70</sup> In fact, the spectra showed an increase of up to four-fold in magnitude during the course of 24 h. However, keeping the sample in the dark for two days resulted in a recovery such that the initial spectrum was restored. In other words, even reversible processes can result in unreliable data if they occur on comparable and longer time scales than the impedance measurement itself. 

In PSC, loops and hooks in the IS spectra are frequently reported. These may arise from reproducible physical phenomena or from measurement artefacts likewise. Therefore, it is very important to check the validity of impedance spectra containing such features, either by KK-test or repeat measurements. 

### Equivalent circuit modelling (ECM) 

Equivalent circuit modelling (ECM) is the most common approach to analyse impedance spectra. Equivalent circuit models (ECM, note that the same acronym is commonly used for both equivalent circuit models and equivalent circuit modelling) are necessary to parameterise the IS data by identifying and quantifying relaxation processes from the impedance spectrum. ECM has been applied to emerging photovoltaic devices,<sup>9</sup> such as DSSC,<sup>13,14,20</sup> OPV.<sup>15,16</sup> More recently, there has been a great interest and progress in establishing ECM for PSC,<sup>20–23,65</sup> but there are still many open questions to be addressed with regards to a universal, physically motivated ECM for PSC. In the following section, we propose a framework to derive a generalised ECM for PSC and discuss it with respect to other models found in the literature. In this section, we provide a short introduction on the basics of ECM. 

ECM relies on the assumption that relaxation processes are first order, reversible, and independent phenomena, such as charge transport, charge transfer, charge recombination, and simple chemical reactions. This means that these phenomena can be modelled independently from each other, that impedance spectra are necessarily reproducible, and the 

spectra themselves are time-independent. In this case, the impedance spectra can be modelled using an ECM composed of a combination of ideal, linear circuit elements with fixed values. The RC element (Fig. 3c) introduced previously is the basic ECM building block for modelling relaxation processes. In practice, most relaxation processes appear in the spectrum as dispersive relaxation processes with more than one time constant, in other words, a distribution of time constants. That can be due to inhomogeneity in sample quality (e.g. surface roughness) or operating conditions (e.g. temperature), or it can be caused by a concrete dispersive process (e.g. charge transfer at porous electrodes or electrical transport in amorphous semiconductors). Often, dispersive relaxation processes can be modelled by an RQ circuit, in other words, the C in the parallel RC element is replaced by a constant phase element (CPE). For other specific cases, specific circuit elements are used, such as the Warburg element for mass transport. A detailed introduction into the different circuits can be found elsewhere.<sup>3,48,71</sup> 

At this point we would like to emphatically note that an ECM does not necessarily represent a unique solution to an impedance spectrum. It has often been shown in IS literature that very different ECMs produce identical frequency responses, and therefore, there may be several ECMs that can reproduce a single experimental impedance spectrum. Therefore, an ECM should ideally fulfil two basic requirements. First, it must accurately reproduce (without systematic error) the dynamic and steady-state electrical behaviour of the device at the DC operating point of measurement over the full IS frequency range. However, generally there is a range of models that will satisfy this criterion, and the different circuit structures and arrangements lead to different quantities for the parameter values, and therefore ambiguity in the physical interpretation. Therefore, the second more rigorous requirement for the ECM is that it must contain relevant, quantified, and unambiguously extractable parameters for the analysis. 

ECMs in the PSC literature have focused mainly on the first requirement to date. The second requirement is more challenging, and it might even be impossible to fulfil it to its finest detail for PSC because of: 

� The large number of dynamic processes (transport, recombination, electrode processes, ionic/electronic processes, reactions at the interfaces, trapping/de-trapping) that (sometimes) overlap in the impedance spectrum leading to multiple different ECMs that can reproduce the same IS response. 

� The interdependencies of processes, such as carrier transport, recombination, and electrochemical dynamics make it difficult to obtain reliable spectra and/or unequivocally assign individual IS signatures. 

� Instable electrical properties lead to unreliable IS spectra that are either KK incompliant or not reproducible, or both. 

With this introduction to ECM, we aim to underline the difficulties in finding an appropriate ECM, which is one of the main reasons that the ECM is still under discussion in the community. However, we will show how one can apply available knowledge about dynamic processes in PSC in order 

_J. Mater. Chem. C_ , 2022, 10, 742–761 | 753 

This journal is © The Royal Society of Chemistry 2022 

Journal of Materials Chemistry C 

Paper 

to identify relevant behavioural traces and parameter values by IS. In the next section we will develop and derive an empirical foundation for a versatile PSC model, which can be adapted for most types of PSC. 

ECMs are very handy for quantifying the resistive and capacitive signatures, and for extracting the timescales, of well-known and/or ideal processes. In this case, ECM provides a global model consisting of simple, well-defined circuit elements that can be used to parameterise the system. One way to design an ECM is to start with the relevant set of differential equations that describe the basic device physics in the ideal system. This approach, however, may neglect nonideal and unexpected effects observed in real samples. In fact, these non-ideal processes are often related to performance and stability losses, and therefore very relevant for many IS studies. For example, in ref. 72 an ECM for Lithium ion batteries was established, and when interpreting features of the spectra, the researchers concluded that, contrary to the initial assumptions, one of the main semicircles in the spectra was due to a contact resistance between cathode and current collector. Analogously, in the case of solar cells, the effects of contacts (blocking, recombination, series resistances) are neglected in more idealised models. 

Performing ECM on unknown samples can lead to ambiguous results when attempting to attribute circuit elements to uncharacterised physical processes. For example, interfacial charge transfer, charge recombination, and chemical reactions may result in similar impedance signatures, although the physical origins and implications on device performance are very different. Also, assuming that processes occurring in parallel or sequentially – and modelling them correspondingly – will lead to different ECMs and different parameter dependencies. Our suggestion for best practice for assigning unknown IS signatures is therefore to perform corroborative measurements to determine the underlying physical origin. 

Specifically, in the case of PSC, the exact processes that determine device performance, and their dependence on the solar cell operating conditions, are still elusive. Due to the co-existence of both electrical and electrochemical dynamics, PSC present a few new challenges to impedance analysis that have not been apparent for other types of solar cells.<sup>28,29,39,40</sup> Therefore, we argue that an empirical approach may actually help in this case to shed light on unknown or non-ideal processes in these devices. 

## Generalised equivalent circuit model for perovskite solar cells 

Here, we aim to develop a general platform for an adaptable ECM for PSC that can account for the different IS features observed in the literature (see Fig. 1), while providing a set of parameters for the features that are common to all spectra measured on PSC. We see this as a helpful contribution towards fulfilling the requirement that ECMs contain relevant, quantified, and extractable parameters, as discussed in the previous section. 

Specifically, we propose an ECM that consists of an HF component to describe the known fast electrical dynamics in PSC (Fig. 2) combined with a variable LF component to describe the range of possible electrochemical dynamics observed in PSC. This flexible platform is based on a physically motivated ECM to describe both electrical and electrochemical processes, combined with the flexibility to adjust the LF response according to the specifics of the PSC and its measurement conditions. 

We begin by considering the impedance response in terms of the HF and LF signatures to provide a physically motivated ECM that accounts for what is currently considered substantiated knowledge in the literature for dynamics in PSC (see Fig. 2). 

For the reasons outlined in the previous section, we base our ECM on IS spectra measured at VOC under standard solar light irradiation, but this approach is applicable to other operating points as well. 

### Separating HF and LF features in a general ECM 

As shown in Fig. 1 and 2, the impedance response of PSC can be divided into HF and LF contributions that are separated from each other by several orders of magnitude in the frequency spectrum. 

To put our approach into context with previous work, the ECM structure shown in Fig. 6 represents one of the commonly reported physically motivated structures, the derivation of which is detailed in many studies.<sup>27,73,74</sup> The part of the ECM describing the processes within the absorber layer (brown layer in Fig. 6), the transport layers (red and green in Fig. 6) and the interfaces are branched out, which leads to a nested circuit (or in special cases to a circuit referred to as Matryoshka circuit<sup>26</sup> ). In the nested circuit, the elements representing the HF and LF impedance are located where they phenomenologically occur in the device, and the underlying (differential) equations are derived based on the physical understanding of the device. In principle, this is a logical approach that is intended to reflect the device physics and reproduce the IS data. However, the resulting structure of nested circuits is much more complex than a series connection of circuit elements, even though it has been shown that for PSC the parameter values for both nested and linear ECMs are very similar.<sup>26,75</sup> Nested circuits are difficult to parametrise, the fitting procedure becomes unstable 



Fig. 6 Schematic with series resistance R0, high-frequency resistance RHF, and a potential LF feature. Grey and yellow rectangles represent the current collectors, and the brown, red and green layers represent the absorber and transport layers, respectively. 

754 | _J. Mater. Chem. C_ , 2022, 10, 742–761 

This journal is © The Royal Society of Chemistry 2022 

Journal of Materials Chemistry C 

### Paper 

for multiple branches, and the fitting values can be difficult to rationalise as the simple relationship t = RC for the time constant no longer applies. More universal, simple structures generally lead to more reproducible fit results. 

In the following, we will present a rational detailing why such branching or nested circuits are not necessary for PSC. Namely, the characteristic frequencies of the HF and LF impedance signatures are separated by at least two orders of magnitude in the frequency domain. This makes it possible to decouple signatures in the HF and LF regime, enabling a series model, which is easier to handle, to parametrise, and to rationalise. Recent studies combining impedance spectroscopy with drift-diffusion modelling have applied an analogous approach to derive recombination dynamics and the solar cell ideality factor from PSC from the HF signature.<sup>76,77</sup> This demonstrates that empirically-derived ECMs can be used to extract relevant PSC parameters. 

The approach is based on one central assumption: that the geometrical capacity Cgeo of the PSC does not affect the LF impedance. By relying on this assumption, we gain the desired flexibility in the ECM, such that we can separate the ECM in a HF-ECM and a LF-ECM without changing the parameters for the respective circuit elements. Another outcome of these considerations is the confirmation that the series resistance can be assigned unequivocally to the Ohmic resistance originating from the current collectors. 

In order to verify our central assumption, and to demonstrate the impact of Cgeo on the HF impedance, we introduce a hypothetical model, which consists of a series resistance and three RC elements or (perfect) semicircles. We simulated this hypothetical ECM from 10<sup>�3</sup> Hz to 10<sup>14</sup> Hz with 250 data points. The parameter values of the individual elements are chosen as such that there are two fast processes (red and yellow) and one slow process (green). This results in a Nyquist plot analogous to those reported for PSC in the literature (Fig. 1). The two fast processes represent electrical relaxation processes such as transport and recombination, while the third process represents one slow electrochemical process, consistent with the different dynamics observed in PSC depicted in Fig. 2. The large data points in the spectra mark (local) negative maxima in the imaginary part of the impedance indicating the characteristic frequency, fchar, respectively. We now demonstrate how a finite value of Cgeo (which is in parallel to all electrical and electrochemical dynamics) impacts the IS signature of the faster processes, but not the slow one. 

For a successive increase of Cgeo from zero, the following can be observed in Fig. 7: 

(a) Cgeo = 0: all three processes are visible by the respective semicircles, and the large data points mark the expected values for fchar with good accuracy. 

(b) Cgeo = 2.5 � 10<sup>�14</sup> F: the semicircles of the two fast processes begin to merge, and notably fchar of the red process decreases by a factor of B2. 

(c) Cgeo = 2.5 � 10<sup>�13</sup> F: the semicircles associated with the two fast processes further merge, and fchar of the yellow and green processes still remain unchanged. 



Fig. 7 Demonstration of the impact of Cgeo on the IS response with the help of a hypothetical equivalent circuit model (ECM). On top, the model structure is shown together with the parameter values including time constant t and characteristic frequency fchar. The impedance spectra show simulations for different values of Cgeo varying from 0 to 2.5 � 10<sup>�8</sup> F in 6 steps. The color code highlights the fastest process in light red, the second fastest in light yellow and the slow process in light green. All values are hypothetical but chosen to be close to the area-specific resistances and capacities of a planar PSC under illumination at VOC. 

_J. Mater. Chem. C_ , 2022, 10, 742–761 | 755 

This journal is © The Royal Society of Chemistry 2022 

Journal of Materials Chemistry C 

Paper 

(d) For Cgeo = 2.5 � 10<sup>�12</sup> F: the semicircles associated with the two fast processes merge completely and fchar of the single remaining fast process decreases by a factor of B2.5. 

(e) For Cgeo = 2.5 � 10<sup>�10</sup> F: the shape of the impedance spectrum does not change significantly anymore, but fchar of the single fast process decreases by almost two orders of magnitude, the same magnitude with which Cgeo increases. 

(f) For Cgeo = 2.5 � 10<sup>�8</sup> F: fchar further decreases by almost two orders of magnitude, similarly to the increase in Cgeo. 

With this simple demonstration, we see how Cgeo slows down the response of the fast processes in the simulated spectra, causing the HF semicircles to merge into a single semicircle with a significantly decreased fchar. This happens when Cgeo is significantly larger than C1 and C2. In this case, C1 and C2 do not influence the dynamics of the ECM at all. Practically speaking, Cgeo will therefore mask any faster impedance signature in the PSC. This is because no current flows through C1 and/or C2 at high frequencies (for Cgeo 4 2.5 � 10<sup>�10</sup> F and a test frequency f (= o/2p) 4 10 kHz: ZCgeo { ZC2 o ZC1 o ZC1+C2). 

But why do we still see a series resistance in all simulated spectra in simulated spectra in Fig. 7? The above considerations are only true for processes that are geometrically located inside the PSC, i.e. that are in parallel to Cgeo, representing the plate capacitor defined by the current collectors in Fig. 6. That is the reason that the very fast impedance of the current collectors (R0 in Fig. 6), can be distinguished from the processes ‘‘inside’’ the device (vertical processes in Fig. 6) with IS. In turn, the results of this simulation confirm that R0 can be attributed to current collectors and electrical contacts, and that it is sensible to model it as a series resistance. It cannot represent any process inside the cell structure, such as a residual Ohmic resistance of the perovskite or contact layers, because in this case it would be dependent on the value of Cgeo. 

In all simulations, the slow process (green) is not influenced by changes in Cgeo. This is because the timescale associated with the slow dynamics is several orders of magnitude larger than those of the (merged) fast processes. The reason for this can be found in the capacitance of the respective RC circuit, which is three orders of magnitude larger than the largest simulated Cgeo. In this case, it is essentially irrelevant if the geometrical capacity is in parallel or in series with the LF circuit elements. Therefore, we propose to simplify the ECM structure as shown in Fig. 8, and include the LF signature as a separate element in series to the HF features. 

In summary, according to Fig. 8, Cgeo is the only capacitance that is practically relevant for IS on PSC in the high frequency regime, while it is not relevant for the low frequency regime. As detailed in many studies, there are several other capacitances that can contribute to the HF signature. However, as capacitances related to charge transport are parallel to Cgeo, their contribution to the total HF signature is negligible and they cannot be identified or quantified from the IS data. Therefore, it is not helpful to include those in this general structure for the ECM. One exception is the chemical capacitance (eqn (12)) which arises due to charge injection in the depleted semiconductor, and is in series 



Fig. 8 General structure of the proposed ECM. R0 accounts for the Ohmic resistance of the contacts and current collectors, Cgeo is the geometrical capacity, RHF is the sum of all HF features in the spectrum and the LF-ECM will be detailed below. 

with Cgeo. However, as we have already noted above, this capacitance is only relevant for PSC in depletion mode,<sup>78</sup> i.e. for defect spectroscopy studies which are not analysed using ECM. 

The sum of all resistances in the high frequency regime (RHF) results from multiple contributions, such as recombination and transport resistances (see Fig. 2). For the model in Fig. 7, RHF = R1 + R2. All contributions to RHF are additive. This holds whether the resistive contributions are independent (truly in series) or interdependent (e.g. both depend on carrier density, such as transport and recombination). A major consequence of this is that RHF cannot be deconvoluted into the individual resistive components from a single impedance spectrum. Only by varying the operating conditions, materials or the cell configuration systematically, is it possible to potentially access to individual contributions. 

### General ECM – LF 

The LF signature probed by IS on PSC is very characteristic, and often, several distinct features are observed in the spectra. On the other hand, the LF signature varies significantly for different cells and, from the literature, it is nearly impossible to define a standard LF signature, such that it is almost impossible to formulate a single general ECM for the LF regime. 

The slow dynamics cannot be explained by purely electronic processes, and it is generally agreed that these are related to (photo)electrochemical processes. The dynamics are slow because they either represent slow reactions or transport, or because they represent faster processes that are modulated or limited by sluggish ion and vacancy migration or slow reactions. One major point of contingency is the variation between diverse positive and negative semicircles, which also appear as loops and hooks, in Nyquist plots reported in the literature. We propose a general description that accounts for all potentially occurring phenomena. 

According to the current understanding of PSC, the following processes are likely to happen due to slow changes in the applied electric field, such as during the IS excitation at low frequencies. Ions and vacancies drift due to the slowly changing electric field. The contacts however, block the ions and vacancies, so that there is an electrical current but no net ionic current. This leads to electrode polarisation which means that ions and/or vacancies accumulate or deplete at a given 

756 | _J. Mater. Chem. C_ , 2022, 10, 742–761 

This journal is © The Royal Society of Chemistry 2022 

Journal of Materials Chemistry C 

### Paper 

electrode interface, thereby changing the internal field in the PSC. Possible consequences are: 

(a) changes in the electrical drift and diffusion currents under a constant DC bias due to the change in electrostatic potential in the PSC and the accumulation or depletion of ions, vacancies or polar molecules, 

(b) triggering of chemical reactions due to the change in ion density and/or local field, 

- (c) formation of traps, and/or. 

- (d) neutralisation of existing traps. 

The question is how these processes impact the IS data and result in the diverse LF signatures. We now consider the possibilities for ion or vacancy migration and other reactions during the AC time interval of the excitation in the low frequency region. However, we do not consider the ionic migration itself – assumed to have a small impact because of the limited number of charges involved – but instead the resulting impact of the migration on the electrical properties.<sup>39,40</sup> For the sake of simplicity, we describe those possibilities in the text and in Fig. 9 only for the part of the oscillation when the voltage increases. The IS response is assumed to be (pseudo-) linear due to the small perturbation about equilibrium, and therefore all processes are assumed to be completely reversible: 

1. positively charged species (ions, vacancies or polar molecules) accumulate at the ‘‘–’’ side, resulting in recombination centres or electrode polarisation leading to ion accumulation leading to hindrance of charge transport and transfer, 

2. negatively charged species (ions, vacancies or polar molecules) accumulate on the ‘‘+’’ side, resulting in recombination centres or electrode polarisation leading to hindrance of charge transport and transfer, 

3. negatively charged species are repelled from the ‘‘�’’ side, which neutralise existing recombination centres or improves the transport or transfer of charges, 

4. positively charged species are repelled from the ‘‘+’’ side, which neutralise existing recombination centres or improves the transport or transfer of charges. 

We note that Scenarios 1 and 2, and Scenarios 3 and 4 cannot be distinguished as the impact is qualitatively equal, but may indeed result in distinct signatures in IS. Scenarios 1 and 2 both result in a positive resistance and a time constant. It is possible to calculate a capacitance from these values (C = t/R), which will be positive and will either be a double-layer capacitance (in case of an electrochemical reaction as the limiting factor) or a chemical capacitance (in case of the ion migration as the limiting factor). 

Scenarios 3 and 4, on the other hand, result in a negative resistance and a positive time constant. This is because the impact from the corresponding limiting factor (recombination and/or poor charge transfer) decreases with increasing voltage at low frequencies. The increase in current due to both the increasing voltage and due to the elimination of limiting factors, representing what has been described as ‘‘negative differential resistance (NDR)’’. The time constant will still be positive because causality in the system prevails. The 



Fig. 9 Schematic of a cell structure with positively and negatively charged ions/vacancies that are supposed to drift due to the outer electric field. At the contacts, those can bond or react at the interface, either foring recombinations centers or, oppositely, passivating the interface. Bonding or electrochemical reaction products bound to the interfaces are symolised by the posts on the respective electrodes. Numbers indicate the number of the list of possible scenarios for field-driven effects described in the text. 

corresponding capacitance can be calculated as in the case of Scenarios 1 and 2, but it will adopt a negative value. The reason is that the capacitive element is actually discharged during the 

_J. Mater. Chem. C_ , 2022, 10, 742–761 | 757 

This journal is © The Royal Society of Chemistry 2022 

Journal of Materials Chemistry C 

Paper 

Table 1 Equivalent circuit elements in the proposed ECM and their description 

|Element|Value|Description|
|---|---|---|
|R0|B10 O (absolute)<br>|Series resistance from the current collectors|
|Rt+r|B10–100 O cm<sup>2</sup><br>|Charge carrier transport (drift/diffusion) and recombination resistance|
|Cgeo|B18–35 nF cm<sup>�2</sup>|Geometrical capacity|
|R1|40|Related to scenario 1 (optional)|
|C1|40|Related to scenario 1 (optional)|
|R2|40|Related to scenario 2 (optional)|
|C2|40|Related to scenario 2 (optional)|
|R3|o0|Related to scenario 3 (optional)|
|C3|o0|Related to scenario 3 (optional)|
|R4|o0|Related to scenario 4 (optional)|
|C4|o0|Related to scenario 4 (optional)|



phase when the voltage increases, as schematically depicted in Fig. 9. Negative capacitance may be represented by an inductivity, however, this results in a different ECM structure.<sup>59</sup> 

These two cases, scenario 1/2 and scenario 3/4 describe related physical processes, but lead to different IS features depending on whether the electrochemical processes enhances or limits current transport during the AC oscillation. This difference can explain the emergence of the different low frequency features, such as loops and hooks, in different spectra reported in the literature. From the opposite perspective – identifying the physical effect from the impedance spectrum – is not possible, as there is still not enough knowledge available about the underlying electrochemical processes to provide a general recipe to elucidate the physical nature of LF signatures based on the impedance response alone. More specifically, from the shape alone, it is impossible to distinguish between the different scenarios (1/2 or 3/4), and also to identify which type of charge carrier is affected as well as potential reactions. That can be done successively by thoroughly measuring and calculating the respective mobilities and activation energies, dedicated materials testing experiments with predominant mobile species, and specifically tailored IS or conductivity measurements. 

The LF part of our suggested ECM (Fig. 10) is constructed according to the possible number and nature of processes occurring. Here we remind the reader that the HF part of the ECM is well-defined as it is determined by the electrical processes, and ultimately dominated by Cgeo. In contrast, the LF part of the ECM depends on specific electrochemical processes, which in turn depend on specific PSC architectures and the measurement conditions. Therefore, the LF-ECM is necessarily empirical because of the current lack of knowledge of the electrochemical processes occurring in different PSC at different solar cell operating points. Therefore, it is fundamentally 



Fig. 10 Possible structure of the LF ECM employing all four options mentioned in the text. 

not possible to design a universal LF-ECM that naturally accounts for all LF features in the IS of PSC. On the other hand, an empirical description of the impedance spectrum is an important step towards gaining a full understanding of the processes in PSC, and a very helpful tool to monitor parameter evolution over time, particularly during stability tests. Our proposed ECM, which combines the physically motivated HF-ECM and the empirical LF-ECM, offers researchers a simple tool box to study PSC stability, and specifically elucidate how the electrochemical processes described in Fig. 9 impact the HF-response and result in different LF features in the Nyquist plot, such as loops and hooks. 

This approach is intended as a first step to create a framework for a general description. We follow the approach in the work by Lasia<sup>79</sup> (Section 5.3), where the adsorption of several species is modelled on top of an electrochemical reaction at a solid–gas interface. In this case, the author depicts a nested circuit but indicates that other ECM structures are possible. As there is currently no substantial information about the LF processes and their interdependencies available, we propose the simplest approach – a linear circuit – that can account for the respective number of features in the spectrum. Also, only a series connection of the (optional) features in Fig. 10 makes it possible to evaluate the characteristic parameters, such as resistance, capacitance and time constant, of these processes independently. This is helpful for a more in-depth physical interpretation of the observed phenomena. 

For the sake of simplicity, the all ECMs introduced here include capacitors. For real IS data, capacitors may be substituted by constant phase elements to enable accurate fitting. It is worth mentioning that the quality of the fit is best assessed via the residuals plot – Nyquist or Bode plots alone are generally too coarse for a reliable judgement. 

The approach presented here differs from most ECM approaches for PSC in the literature. Those can be put into two categories, the first being physically motivated ECMs that account, as closely as possible, for the device physics but place less focus on what is likely, possible, and practical to probe with IS. This approach fails to provide a general framework to understand the varying LF impedance – which is, admittedly, almost impossible to elucidate with IS with the current understanding of the devices, materials, and chemical reactions. In the second category, there are empirical ECMs that try to 

758 | _J. Mater. Chem. C_ , 2022, 10, 742–761 

This journal is © The Royal Society of Chemistry 2022 

Journal of Materials Chemistry C 

Paper 

account for the visible features in the spectra and then attempt a physical interpretation of these features. Our contribution here represents a useful compromise by starting with the device physics, namely the known timescales for dynamics in PSC; and then simplifying the ECM by decoupling the HF and the LF regimes. That enables us to have a closer and unbiased look (independent from the HF impedance) at the LF impedance in order to gain better insights into the unknown, non-ideal electrochemical processes, and their corresponding IS signatures, that cannot be expressed in terms of basic equations that govern solar cell physics. 

## Conclusions 

Impedance spectroscopy (IS) is a powerful tool for operando characterisation and diagnosis of perovskite solar cells (PSC). However, to date, universal models for IS from PSC have been elusive. Based on the current understanding of electrical and electrochemical dynamics in PSC combined with relevant IS basics, we propose a universal approach for equivalent circuit modelling (ECM) for PSC. Our model serves as an up-to-date platform for the unambiguous analysis of IS on different PSC, and provides a straightforward approach for the diagnosis of critical loss processes. Our simplified ECM structure deconvolutes fast electrical processes from slow electrochemical processes along with a comprehensive explanation and parameter assignment for the HF component. We highlight that although the LF and HF signatures can be modelled independently, there is an obvious interdependence between the electronic and electrochemical dynamics in a PSC. Therefore, monitoring how the LF regime relates to the HF signature can yield valuable insight into how electrochemical dynamics determine and limit electrical transport, and therefore photovoltaic performance in PSC. We recommend that researchers who aim to improve PSC stability focus on eliminating LF signatures because those are mostly linked to detrimental non-ideal processes. 

## Conflicts of interest 

There are no conflicts to declare. 

## Acknowledgements 

We want to thank Dr G. Tumen-Ulzii, Prof. T. Matsushima and Prof. C. Adachi (Center for Organic Photonics and Electronics Research (OPERA), Kyushu University) as well as Mischa Hillenius, Mees Dieperink, and Tulus for very helpful discussions. D. K., acknowledges funding from Kakenhi Grant-In-Aid for young scientists, grant number 18K13993/20K15028. 

## References 

- 1 A. K. Jena, A. Kulkarni and T. Miyasaka, Chem. Rev., 2019, 119, 3036–3103. 

- 2 M. V. Khenkin, E. A. Katz, A. Abate, G. Bardizza, J. J. Berry, C. Brabec, F. Brunetti, V. Bulovic´, Q. Burlingame, A. Di Carlo, R. Cheacharoen, Y. B. Cheng, A. Colsmann, S. Cros, K. Domanski, M. Dusza, C. J. Fell, S. R. Forrest, Y. Galagan, D. Di Girolamo, M. Gra¨tzel, A. Hagfeldt, E. von Hauff, H. Hoppe, J. Kettle, H. Ko¨bler, M. S. Leite, S. (Frank) Liu, Y. L. Loo, J. M. Luther, C. Q. Ma, M. Madsen, M. Manceau, M. Matheron, M. McGehee, R. Meitzner, M. K. Nazeeruddin, A. F. Nogueira, Ç. Odabas-ı, A. Osherov, N. G. Park, M. O. Reese, F. De Rossi, M. Saliba, U. S. Schubert, H. J. Snaith, S. D. Stranks, W. Tress, P. A. Troshin, V. Turkovic, S. Veenstra, I. Visoly-Fisher, A. Walsh, T. Watson, H. Xie, R. Yıldırım, S. M. Zakeeruddin, K. Zhu and M. Lira-Cantu, Nat. Energy, 2020, 5, 35–49. 

- 3 V. F. Lvovich, Impedance Spectroscopy: Applications to Electrochemical and Dielectric Phenomena, John Wiley & Sons, 2012. 

- 4 J. T. S. Irvine, D. C. Sinclair and A. R. West, Adv. Mater., 1990, 2, 132–138. 

- 5 E. Ivers-Tiffe´e and A. Weber, J. Ceram. Soc. Jpn., 2017, 125, 193–201. 

- 6 D. Abou-Ras, T. Kirchartz and U. Rau, Advanced Characterization Techniques for Thin Film Solar Cells, 2nd edn, 2016, vol. 1–2. 

- 7 S. Reichert, J. Flemming, Q. An, Y. Vaynzof, J. F. Pietschmann and C. Deibel, Phys. Rev. Appl., 2020, 13, 034018. 

- 8 T. Walter, R. Herberholz, C. Mu¨ller and H. W. Schock, J. Appl. Phys., 1996, 80, 4411–4420. 

- 9 E. von Hauff, J. Phys. Chem. C, 2019, 123, 11329–11346. 

- 10 L. Xu, J. Wang and J. W. P. Hsu, Phys. Rev. Appl., 2016, 6, 064020. 

- 11 S. Ravishankar, T. Unold and T. Kirchartz, Science, 2021, 371, eabd8014. 

- 12 J. Bisquert, Phys. Chem. Chem. Phys., 2003, 5, 5360–5364. 

- 13 M. Adachi, M. Sakamoto, J. Jiu, Y. Ogata and S. Isoda, J. Phys. Chem. B, 2006, 110, 13872–13880. 

- 14 Q. Wang, J. E. Moser and M. Gra¨tzel, J. Phys. Chem. B, 2005, 109, 14945–14953. 

- 15 J. I. Basham, T. N. Jackson and D. J. Gundlach, Adv. Energy Mater., 2014, 4, 1400499. 

- 16 B. Ecker, H. J. Egelhaaf, R. Steim, J. Parisi and E. Von Hauff, J. Phys. Chem. C, 2012, 116, 16333–16337. 

- 17 P. P. Boix, G. Garcia-Belmonte, U. Mun˜ecas, M. Neophytou, C. Waldauf and R. Pacios, Appl. Phys. Lett., 2009, 95, 233302. 

- 18 B. Ecker, J. C. Nolasco, J. Pallare´s, L. F. Marsal, J. Posdorfer, J. Parisi and E. Von Hauff, Adv. Funct. Mater., 2011, 21, 2705–2711. 

- 19 A. Kojima, K. Teshima, Y. Shirai and T. Miyasaka, J. Am. Chem. Soc., 2009, 131, 6050–6051. 

- 20 F. Fabregat-Santiago, G. Garcia-Belmonte, I. Mora-Sero´ and J. Bisquert, Phys. Chem. Chem. Phys., 2011, 13, 9083–9118. 

- 21 I. Zarazua, G. Han, P. P. Boix, S. Mhaisalkar, F. FabregatSantiago, I. Mora-Sero´, J. Bisquert and G. Garcia-Belmonte, J. Phys. Chem. Lett., 2016, 7, 5105–5113. 

- 22 A. Guerrero, G. Garcia-Belmonte, I. Mora-Sero, J. Bisquert, Y. S. Kang, T. J. Jacobsson, J. P. Correa-Baena and A. Hagfeldt, J. Phys. Chem. C, 2016, 120, 8023–8032. 

_J. Mater. Chem. C_ , 2022, 10, 742–761 | 759 

This journal is © The Royal Society of Chemistry 2022 

Journal of Materials Chemistry C 

Paper 

- 23 A. Pockett, G. E. Eperon, N. Sakai, H. J. Snaith, L. M. Peter and P. J. Cameron, Phys. Chem. Chem. Phys., 2017, 19, 5959–5970. 

- 24 D. Pitarch-Tena, T. T. Ngo, M. Valle´s-Pelarda, T. Pauporte´ and I. Mora-Sero´, ACS Energy Lett., 2018, 3, 1044–1048. 

- 25 K. Miyano, M. Yanagida and Y. Shirai, Adv. Energy Mater., 2020, 10. 

- 26 A. Todinova, L. Contreras-Bernal, M. Salado, S. Ahmad, N. Morillo, J. Idı´goras and J. J. A. Anta, ChemElectroChem, 2017, 4, 2891–2901. 

- 27 S. M. Yoo, S. J. Yoon, J. A. Anta, H. J. Lee, P. P. Boix and I. Mora-Sero´, Joule, 2019, 3, 2535–2549. 

- 28 M. T. Neukom, A. Schiller, S. Zu¨fle, E. Knapp, J. A<sup>´</sup> vila, D. Pe´rez-Del-Rey, C. Dreessen, K. P. S. Zanoni, M. Sessolo, H. J. Bolink and B. Ruhstaller, ACS Appl. Mater. Interfaces, 2019, 11, 23320–23328. 

- 29 D. Moia, I. Gelmetti, P. Calado, W. Fisher, M. Stringer, O. Game, Y. Hu, P. Docampo, D. Lidzey, E. Palomares, J. Nelson and P. R. F. Barnes, Energy Environ. Sci., 2019, 12, 1296–1308. 

- 30 C. M. Wolff, P. Caprioglio, M. Stolterfoht and D. Neher, Adv. Mater., 2019, 31, 1902762. 

- 31 M. H. Futscher, J. M. Lee, L. McGovern, L. A. Muscarella, T. Wang, M. I. Haider, A. Fakharuddin, L. Schmidt-Mende and B. Ehrler, Mater. Horiz., 2019, 6, 1497–1503. 

- 32 M. B. Johnston and L. M. Herz, Acc. Chem. Res., 2016, 49, 146–154. 

- 33 F. Staub, H. Hempel, J. C. Hebig, J. Mock, U. W. Paetzold, U. Rau, T. Unold and T. Kirchartz, Phys. Rev. Appl., 2016, 6, 044017. 

- 34 J. Wu, Y. Li, Y. Li, W. Xie, J. Shi, D. Li, S. Cheng and Q. Meng, J. Mater. Chem. A, 2021, 9, 6382–6392. 

- 35 Y. Yang, M. Yang, D. Moore, Y. Yan, E. Miller, K. Zhu and M. Beard, Nat. Energy, 2017, 1–7. 

- 36 C. Wehrenfennig, G. E. Eperon, M. B. Johnston, H. J. Snaith and L. M. Herz, Adv. Mater., 2014, 26, 1584–1589. 

- 37 E. M. Hutter, J. J. Hofman, M. L. Petrus, M. Moes, R. D. Abello´n, P. Docampo and T. J. Savenije, Adv. Energy Mater., 2017, 7, 1602349. 

- 38 D. Luo, R. Su, W. Zhang, Q. Gong and R. Zhu, Nat. Rev. Mater., 2019, 5, 44–60. 

- 39 Z. S. Wang, F. Ebadi, B. Carlsen, W. C. H. Choy and W. Tress, Small Methods, 2020, 4, 2000290. 

- 40 G. Y. Kim, A. Senocrate, T. Y. Yang, G. Gregori, M. Gra¨tzel and J. Maier, Nat. Mater., 2018, 17, 445–449. 

- 41 S. Reichert, Q. An, Y. W. Woo, A. Walsh, Y. Vaynzof and C. Deibel, Nat. Commun., 2020, 11, 6098. 

- 42 E. Velilla, F. Jaramillo and I. Mora-Sero´, Nat. Energy, 2021, 6, 54–62. 

- 43 M. H. Futscher and J. V. Mili, Front. Energy Res., 2021, 9, 1–9. 

- 44 T.-Y. Yang, G. Gregori, N. Pellet, M. Gra¨tzel and J. Maier, Angew. Chem., Int. Ed., 2015, 54, 7905–7910. 

- 45 W. Shockley and H. J. Queisser, J. Appl. Phys., 1961, 32, 510–519. 

- 46 L. Bertoluzzi, R. S. Sanchez, L. Liu, J. W. Lee, E. Mas-Marza, H. Han, N. G. Park, I. Mora-Sero and J. Bisquert, Energy Environ. Sci., 2015, 8, 910–915. 

- 47 A. K. Jonscher, Nature, 1977, 263, 673–679. 

- 48 J. R. Macdonald, Theory, Experiment, Wiley, 2nd edn, 1995. 

- 49 J. Jamnik and J. Maier, Phys. Chem. Chem. Phys., 2001, 3, 1668–1678. 

- 50 H. Schichlein, A. C. Mu¨ller, M. Voigts, A. Kru¨gel and E. IversTiffe´e, J. Appl. Electrochem., 2002, 32, 875–882. 

- 51 A. A. Bakulin, O. Selig, H. J. Bakker, Y. L. A. Rezus, C. Mu¨ller, T. Glaser, R. Lovrincic, Z. Sun, Z. Chen, A. Walsh, J. M. Frost and T. L. C. Jansen, J. Phys. Chem. Lett., 2015, 6, 3663–3669. 

- 52 A. Poglitsch and D. Weber, J. Chem. Phys., 1987, 87, 6373. 

- 53 J. Fleig and J. Maier, J. Am. Ceram. Soc., 2004, 82, 3485–3493. 

- 54 Z. Hens and W. P. Gomes, J. Electroanal. Chem., 1997, 437, 77–83. 

- 55 J. E. A. M. van den Meerakker, J. J. Kelly and P. H. L. Notten, J. Electrochem. Soc., 1985, 132, 638–642. 

- 56 D. P. Almond and C. R. Bowen, J. Phys. Chem. Lett., 2015, 6, 1736–1740. 

- 57 E. J. Juarez-Perez, R. S. Sanchez, L. Badia, G. GarciaBelmonte, Y. S. Kang, I. Mora-Sero and J. Bisquert, J. Phys. Chem. Lett., 2014, 5, 2390–2394. 

- 58 S. Luryi, Appl. Phys. Lett., 1988, 52, 501. 

- 59 D. Klotz, Electrochem. Commun., 2019, 98, 58–62. 

- 60 E. Ghahremanirad, A. Bou, S. Olyaee and J. Bisquert, J. Phys. Chem. Lett., 2017, 8, 1402–1406. 

- 61 D. Klotz, A. Weber and E. Ivers-Tiffe´e, Electrochim. Acta, 2017, 227, 110–126. 

- 62 G. Tumen-Ulzii, T. Matsushima, D. Klotz, M. R. Leyden, P. Wang, C. Qin, J.-W. Lee, S.-J. Lee, Y. Yang and C. Adachi, Commun. Mater., 2020, 1, 31. 

- 63 E. M. Hutter, T. Kirchartz, B. Ehrler, D. Cahen and E. Von Hauff, Appl. Phys. Lett., 2020, 116, 100501. 

- 64 Impedance Spectroscopy, ed. E. Barsoukov and J. R. Macdonald, John Wiley & Sons, Inc., Hoboken, NJ, USA, 2018. 

- 65 D. Pitarch-Tena, T. T. Ngo, M. Valle´s-Pelarda, T. Pauporte´ and I. Mora-Sero´, ACS Energy Lett., 2018, 3, 1044–1048. 

- 66 O. Almora, M. Garcı´a-Batlle and G. Garcia-Belmonte, J. Phys. Chem. Lett., 2019, 10, 3661–3669. 

- 67 B. A. Boukamp, J. Electrochem. Soc., 1995, 142, 1885–1894. 

- 68 M. Scho¨nleber, D. Klotz and E. Ivers-Tiffe´e, Electrochim. Acta, 2014, 131, 20–27. 

- 69 M. Scho¨nleber and E. Ivers-Tiffe´e, Electrochem. Commun., 2015, 58, 15–19. 

- 70 D. Klotz, G. Tumen-Ulzii, C. Qin, T. Matsushima and C. Adachi, RSC Adv., 2019, 9, 33436–33445. 

- 71 D. Klotz, Characterization and modeling of electrochemical energy conversion systems by impedance techniques, KITPublishing Scientific, 2012, DOI: 10.5445/KSP/1000029318. 

- 72 J. Illig, M. Ender, T. Chrobak, J. P. Schmidt, D. Klotz and E. Ivers-Tiffe´e, J. Electrochem. Soc., 2012, 159, A952–A960. 

- 73 S. Ravishankar, C. Aranda, S. Sanchez, J. Bisquert, M. Saliba and G. Garcia-Belmonte, J. Phys. Chem. C, 2019, 123, 6444–6449. 

760 | _J. Mater. Chem. C_ , 2022, 10, 742–761 

This journal is © The Royal Society of Chemistry 2022 

Journal of Materials Chemistry C 

Paper 

- 74 I. Zarazu´a, S. Sidhik, T. Lope´z-Luke, D. Esparza, E. De la Rosa, J. Reyes-Gomez, I. Mora-Sero´ and G. Garcia-Belmonte, J. Phys. Chem. Lett., 2017, 8, 6073–6079. 

- 75 D. Klotz, D. S. Ellis, H. Dotan and A. Rothschild, Phys. Chem. Chem. Phys., 2016, 18(34), 23438–23457. 

- 76 A. Riquelme, L. J. Bennett, N. E. Courtier, M. J. Wolf, L. Contreras-Bernal, A. B. Walker, G. Richardson and J. A. Anta, Nanoscale, 2020, 12, 17385–17398. 

- 77 A. Castro-Chong, A. J. Riquelme, T. Aernouts, L. J. Bennett, G. Richardson, G. Oskam and J. A. Anta, ChemPlusChem, 2021, 86, 1347–1356. 

- 78 S. Ravishankar, T. Unold and T. Kirchartz, Science, 2021, 371, eabd8014. 

- 79 A. Lasia, Electrochemical Impedance Spectroscopy and its Applications, Springer New York, New York, NY, 2014. 

_J. Mater. Chem. C_ , 2022, 10, 742–761 | 761 

This journal is © The Royal Society of Chemistry 2022 

