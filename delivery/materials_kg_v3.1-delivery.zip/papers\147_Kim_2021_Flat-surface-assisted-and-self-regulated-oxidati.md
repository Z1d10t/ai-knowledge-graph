# Flat-surface-assisted and self-regulated oxidation resistance of Cu(111)

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 188 |
| 作者 | Su Jae Kim, Yong In Kim, Bipin Lamichhane, Young-Hoon Kim, Yousil Lee, C. Cho, M. Cheon, Jong Chan Kim et al. |
| DOI | 10.1038/s41586-021-04375-5 |
| 源文件 | 047_Kim_2021_Flat-surface-assisted-and-self-regulated-oxidati.pdf |

---
# Article **Flat-surface-assisted and self-regulated oxidation resistance of Cu(111)** 

|https://doi.org/10.1038/s41586-021-04375-5<br>Received: 8 March 2021<br>Accepted: 20 December 2021|**Su Jae Kim**<sup>**1,12**</sup>**, Yong In Kim**<sup>**2,12**</sup>**, Bipin Lamichhane**<sup>**3,12**</sup>**, Young-Hoon Kim**<sup>**2**</sup>**, Yousil Lee**<sup>**1**</sup>**,**<br>**Chae Ryong Cho**<sup>**4**</sup>**, Miyeon Cheon**<sup>**1**</sup>**, Jong Chan Kim**<sup>**5**</sup>**, Hu Young Jeong**<sup>**6**</sup>**, Taewoo Ha**<sup>**7**</sup>**,**<br>**Jungdae Kim**<sup>**8**</sup>**, Young Hee Lee**<sup>**2,7,9**</sup>**, Seong-Gon Kim**<sup>**3** ✉</sup>**, Young-Min Kim**<sup>**2,7** ✉</sup>**&**<br>**Se-Young Jeong**<sup>**10,11** ✉</sup>|
|---|---|
|Published online: 16 March 2022||
|Open access|Oxidation can deteriorate the properties of copper that are critical for its use,|
|Check for updates|particularly in the semiconductor industry and electro-optics applications<sup>1–7</sup>. This has<br>prompted numerous studies exploring copper oxidation and possible passivation<br>strategies<sup>8</sup>. In situ observations have, for example, shown that oxidation involves<br>stepped surfaces: Cu2O growth occurs on flat surfaces as a result of Cu adatoms<br>detaching from steps and diffusing across terraces<sup>9–11</sup>. But even though this<br>mechanism explains why single-crystalline copper is more resistant to oxidation than<br>polycrystalline copper, the fact that flat copper surfaces can be free of oxidation has<br>not been explored further. Here we report the fabrication of copper thin films that are<br>semi-permanently oxidation resistant because they consist of flat surfaces with only<br>occasional mono-atomic steps. First-principles calculations confirm that<br>mono-atomic step edges are as impervious to oxygen as flat surfaces and that surface<br>adsorption of O atoms is suppressed once an oxygen face-centred cubic (fcc) surface<br>site coverage of 50% has been reached. These combined effects explain the<br>exceptional oxidation resistance of ultraflat Cu surfaces.|



Given that the step edge is vulnerable to oxidation because surface steps act as the dominant source of Cu adatoms for oxide growth on surface terraces<sup>2,11</sup> , oxidation resistance requires that surface step edges are avoided<sup>6,12,13</sup> . In this regard, the close-packed Cu(111) surface is superior to other Cu surfaces<sup>14,15</sup> and our experimental demonstration thus used a single-crystal Cu(111) film (SCCF) grown by atomic sputtering epitaxy (ASE)<sup>16</sup> to show that a tightly coordinated flat surface can remain semi-permanently stable against oxidation. Theoretical calculations show the atomic-scale oxidation-resistant mechanism of the flat copper surface from the perspective of the likely pathways for oxygen atoms into the viable structures of the copper surface with a discovery of the self-regulated protection layer at elevated oxygen coverages. The implication is that the atomically flat surface of the SCCF shows oxidation-resistant properties owing to the high energy barrier for oxygen infiltration and self-regulation owing to high oxygen coverages. 

#### **Flatness of Cu(111) surface** 

The surface and structural characteristics of a 110-nm-thick SCCF with an ultraflat surface (see Extended Data Fig. 1 for a large-scale characterization) are examined using high-resolution (scanning) transmission electron microscopy (HR(S)TEM) combined with geometrical 

phase analysis (GPA)<sup>17,18</sup> (Fig. 1). The cross-sectional (S)TEM images (Fig. 1a, e) show that the copper film grew along the [111] direction, thus creating an exposed surface (111) plane with mono-atomic step-edge structures. Typical multi-atomic step edges and intrinsic defects such as grain boundaries and stacking faults are rarely detected. It is remarkable that the outermost copper surface layer has the same atomic configuration as the interior copper without evidence of surface relaxation or structural changes by surface oxidation, even at the step-edge positions. To examine the local strain behaviour near the surface region, lattice distortions along the in-plane ( _x_ ) and out-of-plane ( _y_ ) directions relative to the inside of the SCCF were measured by the GPA technique (Fig. 1b, c). The resulting strain field maps ( _Exx_ and _Eyy_ ) clearly show that no noticeable changein lattice strain is observed throughout the entire surface region. This means that the SCCF has a nearly perfect atomic structure up to its outermost surface layer without any structural defects, such as vacancies or dislocations. The simulated HRTEM image using an amorphous carbon/ flat copper surface model matches well with the experimental HRTEM image (Fig. 1a). By comparing the layer spacings of the (111) stacking planes ( _d_ (111) = 0.21 nm) between the simulated and experimental images (Fig. 1d), it is evident that the Cu surface is undistorted and ultraflat, and has the same structure as bulk Cu. Annular dark-field (ADF) and annular bright-field (ABF) STEM images of the SCCF surface 

> 1Crystal Bank Research Institute, Pusan National University, Busan, Republic of Korea. 2Department of Energy Science, Sungkyunkwan University, Suwon, Republic of Korea. 3Department of Physics and Astronomy, Mississippi State University, Mississippi State, MS, USA.<sup>4</sup> Department of Nanoenergy Engineering, Pusan National University, Busan, Republic of Korea.<sup>5</sup> School of Materials Science and Engineering, Ulsan National Institute of Science and Technology, Ulsan, South Korea.<sup>6</sup> UNIST Central Research Facilities (UCRF), Ulsan National Institute of Science and Technology, Ulsan, South Korea.<sup>7</sup> Center for Integrated Nanostructure Physics, Institute for Basic Science (IBS), Sungkyunkwan University, Suwon, Republic of Korea.<sup>8</sup> Department of Physics, University of Ulsan, Ulsan, Republic of Korea.<sup>9</sup> Department of Physics, Sungkyunkwan University, Suwon, Republic of Korea.<sup>10</sup> Department of Optics and Mechatronics Engineering, Pusan National University, Busan, Republic of Korea.<sup>11</sup> Department of Cogno-Mechatronics Engineering, Pusan National University, Busan, Republic of Korea.<sup>12</sup> These authors contributed equally: Su Jae Kim, Yong In Kim, Bipin Lamichhane.<sup>✉</sup> e-mail: sk162@msstate.edu; youngmk@skku.edu; syjeong@pusan.ac.kr 

**434** | Nature | Vol 603 | 17 March 2022 



<!-- Start of picture text -->
a Experimental Simulated Model d<br>Carbon Cu d (111) = 0.21 nm Carbon<br>Cu [110]<br>Simulated<br>b Exx   Experimental<br>0.6 0 1 2 3 4<br>Dis tance (nm)<br>y 0 e ADF ABF<br>x ref. In-plane strain<br>–0.4<br>c Eyy<br>0.6<br>Cu Cu<br>y<br>0<br>x ref. Out-of-plane strain –0.4<br>Normalized intensity (a.u.)<br><!-- End of picture text -->

**Fig. 1 | Surface of a single-crystal copper thin film grown by ASE. a** , Cross-sectional HRTEM image of the surface region of the copper thin film observed in the [110] orientation. The simulated HRTEM image and the corresponding model of the carbon–copper supercell are presented alongside the experimental HRTEM image. Scale bar is 2 nm. **b** , **c** , In-plane ( _Exx_ ) and out-of-plane ( _Eyy_ ) strain field maps obtained by GPA for the experimental HRTEM image. The reference area of Cu chosen for GPA is marked by the white 

square boxes in each map. Note that complex patterns for parts of the carbon film are shaded by a grey colour for clarity, as those are not relevant for the strain behaviour of the SCCF. Scale bars are 2 nm. **d** , Comparison of the experimental and simulated intensity profiles obtained along the out-of-plane direction for (111) layer spacings ( _d_ (111) = 0.21 nm). **e** , Simultaneously acquired ADF-STEM and ABF-STEM images for the surface region of the copper thin film. Scale bars are 2 nm. 



<!-- Start of picture text -->
a One-year-old sample b c<br>Cu d (111) = 0.21 nm Carbon 111<br>001 101<br> As deposited<br> One year old<br>0 1 2 3<br>Distance (nm)<br>d 111<br>Cu<br>001 101<br>e Three-year-old sample f g Time (s)<br>Carbon 1 0 400 800 1,200 1,600<br>111 - 0.25<br>111<br>1 002<br>2 – 0.20<br>Cu [110] [110] Cu2O I II III<br>Exx 2 0.15<br>0.6 002  111- 111 0.10<br>y<br>ref. x 0 –<br>In-plane strain –0.4 [110] Cu2O 0.05<br>Eyy 0.6 1 + 2 0  SCCF-0.3 r.m.s. SCCF-0.7 r.m.s.<br> PCCF<br>ref. y x 0 –0.05 100 200 300 400 500 600 700<br>Out-of-plane strain –0.4 Temperature (°C)<br>Normalized intensity (a.u.)<br>230 °C 265 °C 300 °C 550 °C<br>Thermal mass (a.u.)<br><!-- End of picture text -->

**Fig. 2 | Long-term oxidation resistance and structural stability of the SCCF surface. a** , Low-magnification BF-TEM image of the SCCF sample exposed to ambient air at room temperature for about 1 year (top). The result shows that the atomically flat surface morphology over the entire SCCF film has remained almost unchanged. HRTEM image of the surface region (marked by a red rectangle in the top panel) of the 1-year-old SCCF sample (bottom). The sample was oriented in the [110] direction. Scale bars are 100 nm (top) and 2 nm (bottom). **b** , Comparison of the intensity profiles for the (111) plane between the as-deposited (red) and 1-year-old (blue) samples. **c** , EBSD map showing 

perfect alignment along the (111) plane. Scale bar is 3 μm. **d** , IPF with a sole spot associated with the (111) plane. The inset image is the enlarged image of the sole-spot area. **e** , HRTEM image of the surface region of the 3-year-old SCCF sample observed in the [110] orientation (top) and in-plane ( _Exx_ , middle) and out-of-plane ( _Eyy_ , bottom) strain field maps obtained by GPA for the HRTEM image of the 3-year-old SCCF sample. Scale bars are 2 nm. **f** , FFT patterns of region 1 (top), region 2 (middle) and both regions (bottom). **g** , Thermogravimetric analysis for the PCCF and SCCF samples with different surface roughness. r.m.s., root mean square. 

Nature | Vol 603 | 17 March 2022 | **435** 



<!-- Start of picture text -->
Article<br>a d<br>Cu<br>Interface<br>Al2O3<br>b c e<br>Cu<br>111 14 ×  d Cu–Cu[110]–  = 3.578 nm<br>006 Al2O3<br>–220<br>–330<br>Cu<br>13 ×  d O–O[120]–    = 3.575 nm<br>[112]– Cu // [110]Al2O3 Al2O3 0 0.2 0.4 0.6 0.8 1.0 1.2<br>Distance (nm)<br>f g h<br>110–<br>210–<br>– c<br>120– 330 a b<br>[111]Cu // [001]Al2O3<br>d m<br>c d m<br>a b<br>b<br>b<br>Cu O Al c c<br>a a<br>Inverted intensity (a.u.)<br><!-- End of picture text -->

**Fig. 3 | Interface structure and crystallographic relation. a** , Cross-sectional HRTEM image of the Cu–Al2O3 heterointerface having the orientation relation of (111)Cu[112]Cu//(001)Al2O3[110]Al2O3<sup>. Scale bar is 2 nm.</sup><sup>**b**, A composite pattern</sup> of FFTs for the regions of Cu and Al2O3 in the HRTEM image. **c** , Enlarged HRTEM image for the region marked by the dashed box in **a** . Scale bar is 1 nm. **d** , ABF-STEM image and superimposed atomic model of the Cu–Al2O3 

heterointerface. Scale bar is 5 Å. **e** , Inverted intensity profile obtained across the interface between Cu and Al2O3 in **d** . **f** , Plan-view HRTEM image of the Cu– Al2O3 heterointerface. The inset is the FFT pattern of the HRTEM image. Scale bar is 2 nm. **g** , **h** , Side view ( **g** ) and plan view ( **h** ) of the deduced epitaxy model of Cu grown on an Al2O3 substrate. The yellow diamonds with unit length of _d_ m in **f** and **h** indicate the 2D unit cell of the moiré pattern. 

are complementary to the HRTEM observation results (Fig. 1e). We can discriminate this remarkable ultraflat surface structure of the SCCF from that of the conventional polycrystalline Cu thin film (PCCF) and the Cu(111) surface of a bulk Cu single crystal with a notable oxidized copper layer on top of them (Extended Data Fig. 2 and Fig. 3). Notably, we found that the SCCF sample maintained its ultraflat and pristine surface even after more than a year of air exposure (Fig. 2a–d), suggesting that our SCCF has exceptional oxidation-resistant properties (also see Extended Data Fig. 4 for a large-scale scanning tunnelling microscope (STM) topography). 

The low-magnification bright-field TEM (BF-TEM) image (Fig. 2a, top) and the cross-sectional HRTEM image (Fig. 2a, bottom) show that the mono-atomic step-edge structure is maintained even after a year. The two intensity profiles for the (111) plane between the as-deposited (red) and the 1-year-old (blue) samples (Fig. 2b) show a change in the planar spacing of the (111) planes up to the uppermost surface layer, and they agree well with each other, suggesting that no notable oxidation has occurred even in the SCCF under long-term exposure to air. The electron backscatter diffraction (EBSD) map 

(Fig. 2c) and inverse pole figure (IPF) (Fig. 2d) show that no misalignment of crystal lattices deviating from the (111) plane has occurred after a year. Oxidized portions were rare on the 3-year-old SCCF sample oriented along [110] in the HRTEM image, although they were found on the sample edge where the sample was cut (Fig. 2e, top). The resulting strain field maps ( _Exx_ and _Eyy_ ) prepared using the GPA technique (Fig. 2e, middle and bottom) show that the overlayer (region 1) has a new lattice structure that is mismatched with the SCCF. The fast Fourier transform (FFT) patterns of region 1 (Fig. 2f, top), region 2 (Fig. 2f, middle) and both regions (Fig. 2f, bottom) indicate that the two regions belong to the Cu2O and Cu phases, respectively, and suggest that part of the surface is oxidized. However, the oxidized surface only reaches a few Cu2O layers, which is thin compared with the thickness of natural oxide layers in polycrystalline Cu (Extended Data Fig. 2). Comparative thermogravimetric analysis of PCCF and SCCF samples having different surface roughness clearly demonstrates that the SCCF with mono-atomic step edges shows exceptional resistance to initial oxidation at elevated temperatures compared with the other samples (Fig. 2g). 

**436** | Nature | Vol 603 | 17 March 2022 



<!-- Start of picture text -->
c<br>b g 2.0<br>a 3 1.5<br>2.71 Cu(111) surface path 1<br>Cu(111) surface path 2<br>2 1.82 Mono-atomic step edge 1.0<br>1.43 1.56 1.52 Bi-atomic step edge<br>Tri-atomic step edge<br>1 0.71 0.97 d 0.5<br>0.80<br>0 0<br>–0.67<br>–0.70<br>–1 –0.5<br>–0.86 –0.90<br>–1.01 e<br>–2 –1.0<br>0 1 2 3 4 5<br>Distance along the path (Å)<br>–1.5<br>f<br>(1) (2) (3) 2 1 (4) –2.0<br>0 0.2 0.4 0.6 0.8 1.0<br>Coverage ( � )<br> (eV) E Δ<br> (eV)Adsorption energy,  E ads<br><!-- End of picture text -->

**Fig. 4 | Theoretical analysis and a model of oxidation of the copper surface. a** – **f** , Energy profile of an O atom along various penetration paths ( **a** ): from the Cu(111) surface into the first Cu substrate interstitial layer (black solid circles) ( **b** ); from the first to the second Cu substrate interstitial layer (black open circles) ( **c** ); from the outside to the inside of the mono-atomic step edge (red solid circles) ( **d** ); from the outside to the inside of the bi-atomic step edge (blue open squares) ( **e** ); and from the outside to the inside of the tri-atomic step edge (pink open squares) ( **f** ). Blue spheres represent Cu atoms in the bulk or substrate, green spheres represent Cu atoms in the steps and dark blue spheres represent Cu atoms on the step edge. Orange spheres represent adsorbed O atoms and red spheres represent O atoms infiltrating into the interstitial region. Panel **f** also shows the initiation of oxidation on the edge of a 

multi-atomic step: (1) given a pristine step edge and ambient oxygen conditions, (2) two O atoms (orange spheres) adsorb on each side of the Cu on the edge (Cu-1, dark blue sphere); (3) the third adsorbed O atom (O-2, red sphere) causes the local structure of Cu-1 to be similar to that of Cu in a monolayer of Cu2O<sup>, and the expansion of volume causes Cu-1 to move upward</sup> and open a pathway for O-2; and (4) O-2 passes through the opening and binds with Cu atoms in the next row to push those Cu atoms upward to sustain the oxidation process. **g** , Incremental adsorption energy of O atom as a function of oxygen coverage of the fcc sites on the Cu(111) surface. The red and blue shading in **a** and **g** represents the endothermic and exothermic reactions, respectively. 

#### **Growth condition for the flat surface** 

The flatness of a surface is decisively influenced by the interface structure between the film and the substrate<sup>19,20</sup> , which can be relaxed by structural defects such as dislocations. The interface structure between the Cu film and the Al2O3 substrate is characterized by HR(S)TEM (Fig. 3). The overall interface structure viewed at the [112] orientation of the Cu film and the FFT pattern of the image show that the crystallographic orientation relationship (OR) is (111)Cu[112]Cu//(001)Al2O3[110]Al2O<sup>(Fig. 3a, b). The copper lattices seem</sup> 3 to flawlessly adjoin with the Al2O3 substrate without interfacial misfit defects, suggesting that the Cu film grows metamorphically on the substrate<sup>21</sup> (Extended Data Fig. 5). The enlarged image of the interface (Fig. 3c) shows a detailed lattice mismatch between the two materials. The in-plane atomic distance mismatch _f_ (( _d_ [120]O−OAl2O3 − _d_ [110]Cu−Cu)/ _d_ [120]O−OAl2O3<sup>)</sup> between Cu atoms in the film and O atoms in Al2O3 is estimated to be 6.9%. However, considering the extended atomic distance mismatch (EADM)<sup>22,23</sup> , the large mechanical misfit strain can be relieved if the mismatch for a relatively long period of atomic distance is extremely small. The EADM is defined as ( _ID_ − _I_ ′ _D_ ′)/ _I_ ′ _D_ ′, in which _D_ and _D_ ′ are the Cu–Cu distance in the Cu (111) epilayer and the O–O distance in the substrate, respectively, and _I_ and _I_ ′ are smallest non-reducible integers determined by the relation _D_ : _D_ ′ ~ _I:I_ ′. Given the _D_ Cu-Cu (14 × _d_ [110]Cu−Cu) interatomic spacing (3.578 nm) of Cu atoms in the film and the _D_ ′O−O (13 × _d_ [120]O−O) interatomic spacing (3.575 nm) of O atoms in Al2O3, the EADM of the Cu–Al2O3 interface is about 0.1% (Fig. 3c). The light-element-sensitive ABF-STEM imaging<sup>24</sup> (Fig. 3d) shows that the interface model of Cu grown on the oxygen-terminated Al2O3 surface matches well with the experimental heterostructure. The inverted intensity profile obtained across the interface (Fig. 3e) clearly cor- 

roborates the presence of an oxygen layer between the Cu and Al layers, thus indicating the existence of Cu–O interactions at the interface, which can be stabilized on a typical Al2O3 surface terminated with oxygen<sup>25</sup> . Owing to the in-plane lattice mismatch, a large-scale interference pattern, that is, a moiré pattern<sup>26</sup> , can be observed in the plane view of the Cu–Al2O3 heterostructure (Fig. 3f). Indeed, the hexagonal moiré pattern with a dimension ( _d_ m) of 1.83 nm is observed owing to the different in-plane lattice periodicities in the vertical OR of [111]Cu//[001]Al2O3, which is confirmed by the FFT pattern analysis (inset in Fig. 3f). The simulated moiré pattern generated by the epitaxy model of Cu–Al2O3 with the same OR is consistent with the experimental moiré pattern, showing the repeating large-scale contrast feature (Fig. 3g, h). This vertical OR observation corroborates our EADM analysis and indicates that the growth mechanism of the SCCF on the Al2O3 substrate can be understood on the basis of the large-scale mismatch epitaxial relationship, rather than the atomic-scale lattice interrelation. The detailed chemical nature of the SCCF at the surface and the interface regions are investigated by the combined spectroscopic approaches of energy-dispersive X-ray spectroscopy (EDX), electron energy loss spectroscopy (EELS) in ADF-STEM imaging mode and X-ray photoelectron spectroscopy<sup>27,28</sup> (Extended Data Fig. 6). 

#### **Calculation of oxidation resistance** 

We can understand the exceptional oxidation resistance of our films using a microscopic model of copper oxidation on the basis of first-principles density functional theory (DFT) calculations<sup>29–31</sup> . The main reason for the suppression of oxidation is that our atomically flat film is free of one critical feature, namely, multi-atomic step edges, as shown in Fig. 4. The energy profile in Fig. 4a shows that the penetration of an O atom through 

Nature | Vol 603 | 17 March 2022 | **437** 

## Article 

a pristine Cu(111) surface needs an activation energy of more than 1.4 eV (Fig. 4b), and the O atom becomes stable only in the second subsurface interlayer space with a further energy barrier of 1.3 eV (Fig. 4c). One of the main reasons for the strong resistance of a flat surface to oxidation is that, when Cu atoms are oxidized, the out-of-plane distance between Cu layers increases from 2.10 to 2.48 Å, and the volume expands by 18% (Extended Data Fig. 7). The volume increase is even more pronounced in the early stage of oxidation: the Cu layer distance in the monolayer of Cu2O on the Cu surface is 3.26 Å, and the volume is greater by 55% (Extended Data Fig. 7). Given that one exposed Cu surface is insufficient to initiate the oxidation process, we examine a structure wherein two crystallographically different planes meet, namely, the edge of a multi-atomic step. Notably O2 molecules physisorbed on a Cu(111) surface readily dissociate into O ions with a small activation energy of 0.027 eV (Extended Data Fig. 8). Figure 4d–f shows the initiation of oxidation on the edge of such multi-atomic steps according to our DFT calculation; Fig. 4a shows that there is a critical difference between a mono-atomic step and a multi-atomic step in terms of the oxidation resistance. Whereas the penetration of O atoms at a bi-atomic and tri-atomic step is an exothermic reaction (Δ _E_ = −0.90 and −0.86 eV, respectively) with smaller activation energies ( _E_ a = 0.97 and 0.71 eV, respectively), the penetration of O at the edge of a mono-atomic step is highly endothermic (Δ _E_ = +0.80 eV), requiring a much larger activation energy ( _E_ a = 1.56 eV), and shows strong oxidation resistance. Our DFT calculation indicates that, as the coverage of oxygen increases, the incremental adsorption energy for the next O atom becomes smaller and eventually becomes negative beyond 50% of oxygen coverage, rendering the adsorption process energetically unfavourable (Fig. 4g). This self-regulation of oxygen suppresses further adsorption of O atoms on an ultraflat Cu surface at elevated oxygen coverages and increasingly enhances the oxidation resistance of the surface. Our microscopic model of oxidation is well supported by HRTEM images, which show that atomically flat Cu thin films with occasional presence of mono-atomic steps are highly resistant to oxidation over an extended period (≥3 years) (Fig. 2), whereas Cu films with multi-atomic steps show substantial oxidation (Extended Data Figs. 2 and 3). The oxidation resistance of a Cu(111) surface is greatly affected by the type of surface defects<sup>32–35</sup> , which suggests that an atomically flat Cu(111) surface without multi-atom steps is essential to achieve strong oxidation resistance. 

#### **Online content** 

Any methods, additional references, Nature Research reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41586-021-04375-5. 

1. Gattinoni, C. & Michaelides, A. Atomistic details of oxide surfaces and surface oxidation: the example of copper and its oxides. _Surf. Sci. Rep._ **70** , 424–447 (2015). 

2. Zhu, Q., Zou, L., Zhou, G., Saidi, W. A. & Yang, J. C. Early and transient stages of Cu oxidation: atomistic insights from theoretical simulations and in situ experiments. _Surf. Sci._ **652** , 98–113 (2016). 

3. Lahtonen, K., Hirsimaki, M., Lampimaki, M. & Valden, M. Oxygen adsorption-induced nanostructures and island formation on Cu{100}: bridging the gap between the formation of surface confined oxygen chemisorption layer and oxide formation. _J. Chem. Phys._ **129** , 124703 (2008). 

4. Ahonen, M. et al. Adsorption dynamics of O2 on Cu(100): the role of vacancies, steps and adatims in dissociative chemisorption of O2. _Chem. Phys. Lett._ **456** , 211–214 (2008). 

5. Moritani, K., Okada, M., Teraoka, Y., Yoshigoe, A. & Kasai, T. Reconstruction of Cu(111) induced by a hyperthermal oxygen molecular beam. _J. Phys. Chem. C_ **112** , 8662–8667 (2008). 

6. Yang, J. C., Kolasa, B., Gibson, J. M. & Yeadon, M. Self-limiting oxidation of copper. _Appl. Phys. Lett._ **73** , 2841–2843 (1998). 

7. Huang, C. L., Weng, W. L., Liao, C. N. & Tu, K. N. Suppression of interdiffusion-induced voiding in oxidation of copper nanowires with twin-modified surface. _Nat. Commun._ **9** , 340 (2018). 

8. Bellchambers, P. et al. Elucidating the exceptional passivation effect of 0.8 nm evaporated aluminium on transparent copper films. _Front. Mater._ **5** , 71 (2018). 

9. Li, L. et al. Surface-step-induced oscillatory oxide growth. _Phys. Rev. Lett._ **113** , 136104 (2014). 

10. Zhou, G. et al. In situ atomic-scale visualization of oxide islanding during oxidation of Cu surfaces. _Chem. Commun._ **49** , 10862–10864 (2013). 

11. Zhou, G. et al. Step-edge-induced oxide growth during the oxidation of Cu surfaces. _Phys. Rev. Lett._ **109** , 235502 (2012). 

12. Baber, A. E. et al. In situ imaging of Cu2O under reducing conditions: formation of metallic fronts by mass transfer. _J. Am. Chem. Soc._ **135** , 16781–16784 (2013). 

13. Fujita, K., Ando, D., Uchikoshi, M., Mimura, K. & Isshiki, M. New model for low-temperature oxidation of copper single crystal. _Appl. Surf. Sci._ **276** , 347–358 (2013). 

14. Zhang, X. et al. Nanocrystalline copper films are never flat. _Science_ **357** , 397–400 (2017). 

15. Schiøtz, J. & Jacobsen, K. W. Nanocrystalline metals: roughness in flatland. _Nat. Mater._ **16** , 1059–1060 (2017). 

16. Kim, S. J. et al. Color of copper/copper oxide. _Adv. Mater._ **33** , 2007345 (2021). 

17. Hytch, M. J., Snoeck, E. & Kilaas, R. Quantitative measurement of displacement and strain fields from HREM micrographs. _Ultramicroscopy_ **74** , 131–146 (1998). 

18. Hÿtch, M. J., Putaux, J.-L. & Pénisson, J.-M. Measurement of the displacement field of 

   - dislocations to 0.03 Å by electron microscopy. _Nature_ **423** , 270–273 (2003). 

19. Sasaki, T. et al. Atomic and electronic structures of Cu/a-Al2O3 interfaces prepared by pulsed-laser deposition. _Sci. Technol. Adv. Mater._ **4** , 575–584 (2003). 

20. Ernst, F., Pirouz, P. & Heuer, A. H. HRTEM study of a Cu/Al2O3 interface. _Philos. Mag._ **A63** , 259–277 (1991). 

21. Richardson, C. J. K. & Lee, M. L. Metamorphic epitaxial materials. _MRS Bull._ **41** , 193–198 2016). 

22. Kato, T. et al. Simultaneous growth of two differently oriented GaN epilayers on (11.0) sapphire II. A growth model of (00.1) and (10.0) GaN. _J. Cryst. Growth_ **183** , 131–139 (1998). 

23. Liu, X. Y. et al. Perfect strain relaxation in metamorphic epitaxial aluminum on silicon through primary and secondary interface misfit dislocation arrays. _ACS Nano_ **12** , 6843–6850 (2018). 

24. Kim, Y. M., Pennycook, S. J. & Borisevich, A. Y. Quantitative comparison of bright field and annular bright field imaging modes for characterization of oxygen octahedral tilts. _Ultramicroscopy_ **181** , 1–7 (2017). 

25. Kung, P., Sun, C. J., Saxler, A., Ohsato, H. & Razeghi, M. Crystallography of epitaxial growth of wurtzite-type thin films on sapphire substrates. _J. Appl. Phys._ **75** , 4515–4519 (1994). 

26. Williams, D. B. & Carter, C. B. _Transmission Electron Microscopy_ (Plenum Press, 1996). 27. Ngantcha, J. P., Gerland, M., Kihn, Y. & Riviere, A. Correlation between microstructure and mechanical spectroscopy of a Cu-Cu2O alloy between 290 K and 873 K. _Eur. Phys. J. App. Phys._ **29** , 83–89 (2005). 

28. Ewels, P., Sikora, T., Serin, V., Ewels, C. P. & Lajaunie, L. A complete overhaul of the electron energy-loss spectroscopy and X-ray absorption spectroscopy database: eelsdb. eu. _Microsc. Microanal._ **22** , 717–724 (2016). 

29. Perdew, J. P., Burke, K. & Ernzerof, M. Generalized gradient approximation made simple. _Phys. Rev. Lett._ **77** , 3865–3868 (1996). 

30. Blochl, P. E. Projector augmented-wave method. _Phys. Rev. B_ **50** , 17953–17979 (1994). 31. Kresse, G. & Joubert, D. From ultrasoft pseudopotentials to the projector augmented-wave method. _Phys. Rev. B_ **59** , 1758–1775 (1999). 

32. Coulman, D. J., Wintterlin, J., Behm, R. J. & Ertl, G. Novel mechanism for the formation of chemisorption phases: the (2×1)O-Cu(110) “added row” reconstruction. _Phys. Rev. Lett._ **64** , 1761–1764 (1990). 

33. Sun, L. D., Hohage, M., Denk, R. & Zeppenfeld, P. Oxygen adsorption on Cu(110) at low temperature. _Phys. Rev. B_ **76** , 245412 (2007). 

34. Lian, X., Xiao, P., Liu, R. & Henkelman, G. Communication: calculations of the (2 × 1)-O reconstruction kinetics on Cu(110). _J. Chem. Phys._ **146** , 111101 (2017). 

35. Li, L., Liu, Q., Li, J., Saidi, W. A. & Zhou, G. Kinetic barriers of the phase transition in the oxygen chemisorbed Cu(110)-(2 × 1)-O as a function of oxygen coverage. _J. Phys. Chem. C_ **118** , 20858–20866 (2014). 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/licenses/by/4.0/. 

© The Author(s) 2022 

**438** | Nature | Vol 603 | 17 March 2022 

### **Methods** 

level of stability is not sufficient for the growth of the Cu film with an atomic-level flatness. 

##### **ASE for the preparation of single-crystal Cu thin films** 

Cu thin films were grown as nearly defect-free and grain-boundary-free single crystals using the ASE technique achieved by addressing the problems of conventional sputter systems<sup>16</sup> . Because the ASE system controlling atomic-level growth is very sensitive to environmental factors, it requires three key instrumental modifications compared with a commercially available sputtering system. First, we used a single-crystal target instead of a polycrystalline one; second, all conducting wires of the wiring network were replaced with single-crystal copper wires; finally, a mechanical noise-reduction system was installed to suppress the mechanical vibrations from the surroundings. The idea of this technology is on the basis of completely eliminating the noise caused by electron-grain boundary scattering in the conduction network in the device, which, to our knowledge, has been completely ignored until now. Once the system was appropriately constructed, we confirmed that the quality of the Cu films was greatly improved, with a high level of reproducibility. The schematic diagram of the ASE system with the three key features is shown in Extended Data Fig. 9a and the detailed descriptions are as follows. 

**Single-crystal Cu sputtering target.** For a polycrystalline target with a high density of surface steps and grain boundaries, atoms on the edges or grain boundaries have a lower binding energy than that of atoms arranged on a flat plane of the grain. Hence the atoms at the structural defects are prone to being sputtered as atomic clusters for the RF power set to remove atoms from a flat plane, which will eventually be deposited on the substrate as randomly oriented clusters. To realize the practicability of ASE growth, the use of a single-crystal Cu target with a (111) surface is essential because Cu atoms are sputtered from the target as individual atoms. Thus the uniform stacking of Cu atoms on the substrate is empirically achieved for the growth of an ultraflat film. The single-crystal Cu(111) target can be obtained from the single-crystal Cu ingot grown by the Czochralski method by cutting using wire electrical discharge machining as a 6-mm-thick disc with a 2-inch diameter (see the two images on the upper-left side of Extended Data Fig. 9a). Even though Cu single-crystal ingots are commercially available, we grew them using our own apparatus in this study, and there were no differences between the two in the resulting improvement of film quality. 

**Electrical noise reduction using single-crystal Cu wires.** To reduce electrical noise interference, we replaced the electrical networks made of conducting wires in conventional sputtering systems with single-crystal Cu wires as much as possible (see the three images on the lower-left side of Extended Data Fig. 9a). The effectiveness of this modification was previously demonstrated in a Hall measurement kit with circuitry and connecting components made of single-crystal Cu, notably improving the measurement precision of the electrical coefficients, such as carrier density and mobility<sup>36</sup> . Single-crystal Cu wires can be prepared by the wire electrical discharge machining cutting of a single-crystal Cu disc in a spiral manner, as reported in our previous study<sup>37</sup> . To ensure further reduction of electrical noise, we replaced a typical RF power cable with a single crystal. To monitor how effectively the single-crystal power cable improves the RF power stability in the sputtering system, we measured the change in the RF power over time with and without the single-crystal Cu power cable (Extended Data Fig. 10a, b). Single-crystal wiring has already been adapted in the sputtering system used in the test. Therefore it is evident that the output RF power is more stabilized in a narrower power range (12.61 ± 0.005 W) after changing the original power cable to a single crystal. Although the RF power stability of the sputtering system before modification is also of good quality compared with the conventional ones, we empirically confirmed that such a 

**Mechanical noise reduction using mechanical diodes.** Although mechanical noise is not the main source of interference in the ASE system, the electrical noise reduction on the basis of the single-crystal Cu wiring cannot be effective unless the mechanical noise is effectively screened. After the tests to reduce the mechanical noise with several choices, including absorbers, barriers, vibration isolators and vibration dampers, we found that the application of a mechanical diode consisting of a set of metal spikes and pads is very effective and economical in shielding the mechanical interferences transmitted through the wall and the floor. As depicted in Extended Data Fig. 9a, we designed mechanical diodes and installed them on every device, including the chamber and the vacuum pumps. The growth of the atomically flat metal films was not successful without this shield against mechanical noise. 

To verify the reproducibility of our ASE approach for the growth of the ultraflat Cu(111) film, we measured the root mean square (r.m.s.) roughness of many samples as a function of the film thickness and compared these values with those of the samples grown by a conventional sputtering system equipped with only the single-crystal Cu target (Extended Data Fig. 10c). The averaged r.m.s. value for the 29 samples grown by the ASE system was estimated to be around 0.20 ± 0.1 nm (red dashed line), which is similar to the planar spacing of Cu(111). Notably, it can be further decreased to about 0.17 ± 0.1 nm (purple dashed line) when considering thinner Cu films below 35 nm, suggesting their reliable applications to ultrathin electronic devices. However, the averaged r.m.s. value for the samples grown by the conventional sputtering system equipped with the single-crystal Cu target was around 0.66 ± 0.2 nm, which is good but not enough for the growth of the ultraflat Cu films with only the mono-atomic steps. 

**Optimized sputtering conditions using the ASE system.** A double-side polished (001) Al2O3 wafer with a thickness of 430 μm was used as the substrate material. The optimized deposition temperature and RF (13.56 MHz in frequency) power were about 170 °C and 30 W, respectively, and varied slightly, depending on the ASE systems. The target-to-substrate distance was set at 95 mm. The base pressure was maintained at under 2 × 10<sup>−7</sup> torr and the working pressure at 5.4 × 10<sup>−3</sup> torr with an Ar gas flow of 50 sccm. Ar gas with a purity of 99.9999% (6N) was used. The relationship between the deposition time and the thickness of the thin film (or the average growth rate) was determined from the average deposition time of a 200-nm-thick film grown under the optimum conditions. The determined average growth rate of roughly 4.3 nm min<sup>−1</sup> is fairly reliable above a film thickness of 10 nm. The kinetic energy of sputtered Cu atoms depends on the incident ion energy of Ar<sup>+</sup> and the binding energy of Cu atoms at the surface of the target. The crystallographically different surfaces of Cu have different surface binding energies ( _E_ b,Cu), which were reported to be 4.62, 4.26 and 4.65 eV for the Cu(100), Cu(110) and Cu(111) planes, respectively<sup>38</sup> . Considering the potential energy ( _E_ Ar<sup>+</sup> = 15eV) of the accelerated Ar<sup>+</sup> ion at the maximum current of 1 A in our ASE equipment, the kinetic energy of the sputtered Cu atoms can be narrowly distributed at around 10.35 eV, which is roughly calculated from _E_ Ar+ − _E_ b,Cu(111) in the case of the Cu(111) single-crystal target used in this study. By contrast, in the case of polycrystalline Cu target dominantly having a mixture of Cu(100), Cu(110) and Cu(111) exposed planes at the surface, the kinetic energy of the sputtered Cu atoms is expected to be spread between 10.35 and 10.74 eV. When considering the surface defects and grain boundaries at the target, the kinetic energy would be distributed more widely up to 11.52 eV (ref.<sup>39</sup> ). The radial distribution of the incident flux of the sputtered Cu atoms at the substrate is known to determine the uniformity of the deposition thickness of Cu film<sup>40</sup> . To check the thickness uniformity of the grown SCCF, we measured the thickness at five different points from centre to edge in a 2-inch wafer using an atomic 

## Article 

force microscope (AFM). As a result, the thickness uniformity was estimated to be about 99.8% (Extended Data Fig. 9b, c). This result suggests that the diffusive flux of Cu atoms is purely uniform at the position of the substrate. Note that the substrate of our system is rotated at 30 rpm. 

##### **Structural and chemical characterizations** 

X-ray diffraction _θ_ –2 _θ_ measurements were performed using a PANalytical Empyrean Series 2 instrument equipped with a Cu _Kα_ source (40 kV, 30 mA). Data were collected in the range 20° < 2 _θ_ < 90°, with a step size of 0.0167° and a dwell time of 0.5 s per point in all cases. AFM measurements were carried out using an XE-100 system (Park Systems, Inc.). Scanning electron microscopy, EBSD, pole figure (PF) and IPF measurements were performed with a Zeiss Supra 40VP with a scanning electron microprobe. An STM surface analysis was conducted using a custom-built STM system installed at the University of Ulsan, Korea. Electron-transparent cross-sectional TEM samples were prepared by the Ga ion beam milling and lift-out method in focused ion beam systems (FIB, Helios NanoLab 450, FEI and AURIGA CrossBeam Workstation, Carl Zeiss) and the possible damaged surface layers on the samples were removed by subsequent low-energy Ar ion beam surface milling at 700 eV for 15 min (Model 1040 NanoMill, Fischione). The plan-view TEM specimen was prepared by mechanical polishing and dimple grinding, followed by ion milling with Ar ions. Double _C_ s-corrected (S)TEM systems (JEM-ARM200CF, JEOL) equipped with EELS (Quantum ER965, Gatan) and EDX (JED-2300T, JEOL) were used for atomic-scale structure imaging and chemical analysis of the samples at an accelerating voltage of 200 kV. The inner and outer angle ranges for ADF-STEM and ABF-STEM imaging were 45–180 and 12–24 mrad, respectively. The HRTEM, ADF-STEM and ABF-STEM images were denoised by a local 2D difference image filter that is implemented in commercial software (HREM-Filters Pro, HREM Research Inc.). The HRTEM simulation was carried out for the amorphous carbon/copper [110] supercell structure (4.8 × 4.8 nm<sup>2</sup> ) using the multislice method, which is implemented in the commercial software MacTempas (Total Resolution LLC), with the following microscope and imaging parameters: accelerating voltage ( _V_ = 200 kV), spherical aberration coefficient ( _C_ s = 0.4 μm), chromatic aberration coefficient ( _C_ c = 1.1 mm), convergence semi-angle ( _α_ = 0.5 mrad), sample thickness ( _t_ = 20.5 nm) and defocus (Δ _f_ = +14 nm). The simulated HRTEM image was estimated to have a correlation of 0.98 with the experimental HRTEM image as a cross-correlation factor. For the quantitative analysis of local strain components in the copper thin film, the GPA technique was used, which allows mapping two-dimensional local displacement fields by analysing the phase shift between non-collinear Fourier components of the lattice vectors _g_ 1 and _g_ 2. For EELS measurements of the Cu–Al2O3 interface and the Cu surface, the core-loss EELS spectra of the Cu _L_ edge were obtained from the interface to the Cu surface using the line scan function of the scanning step (0.72 nm) for a 37.83-nm length with an energy dispersion of 0.5 eV pix<sup>−1</sup> and a dwell time of 2.0 s pix<sup>−1</sup> . For core-loss EELS spectrum imaging for the comparison of surface structures between the SCCF and the PCCF samples, surface regions of both samples were selected by 20 × 16 pixels that can be translated as 9.87 × 7.9 nm<sup>2</sup> and scanned with the step size of 0.493 nm to obtain EELS spectrum imaging dataset. The selected range of energy loss was set to be 477–988 eV including O _K_ and Cu _L_ 2,3 edges. Nanoscale STEM-EDX maps of the constituent elements of the Cu–Al2O heterostructure were obtained for a 256 × 256 pixel resolution with a high-efficiency dual silicon drift detector X-ray detector system having a wide collection window of 100 mm<sup>2</sup> for each detector, and the sample drift during the acquisition was corrected by tracking the reference area assigned at the acquisition setup. 

##### **Thermogravimetric analysis for the PCCF and SCCF samples with different surface roughness** 

The thermal mass change was measured using a thermogravimetric measurement system (TG-DTA 2000S, MAC Science). We prepared two 

SCCF samples with different values of surface roughness and a PCCF sample. The gravimetric changes of the three samples were measured in the temperature range from room temperature to 700 °C at a heating rate of 20 °C min<sup>−1</sup> under air atmosphere. The two SCCF samples with different values of r.m.s. roughness, that is, 0.3 nm (SCCF-0.3, corresponding to a mono-atomic step) and 0.7 nm (SCCF-0.7, corresponding to a bi-atomic or tri-atomic step), were tested to ascertain the effect of the surface steps on oxidation in comparison with the PCCF sample (blue) (r.m.s. roughness around 10 nm). Although the SCCF sample with a roughness of 0.3 nm (red) was synthesized by ASE and had an ultraflat surface with occasional mono-atomic steps, the SCCF sample with a roughness of 0.7 nm (green), which was synthesized using a single-crystal target in a conventional sputtering system, had occasional multi-atomic steps of 2 or 3 atomic layers in height. 

##### **Theoretical calculations** 

All ab initio total energy calculations and geometry optimizations were performed with DFT in the generalized gradient approximation Perdew–Burke–Ernzerhof functional<sup>29</sup> and with the projected augmented-plane-wave method<sup>30</sup> , as implemented by Kresse and Joubert<sup>31</sup> . The Cu substrate was represented by slabs of six layers with the theoretical equilibrium lattice constant. A vacuum length of 15 Å was used, and the bottom two layers of the slab were fixed in their bulk positions. The electron wave functions were expanded in a plane-wave basis set with a cut-off energy of 400 eV. The Brillouin zone for the slabs was sampled using _k_ -point sets equivalent to at least a (5 × 5 × 1) Monkhorst–Pack grid<sup>41</sup> for the primitive fcc unit cell. The climbing image-nudged elastic band method<sup>42</sup> was used to calculate activation energies. The local atomic charge was computed using Bader’s charge decomposition method<sup>43</sup> , which divides the total volume into individual atomic volumes for each atom as the one containing a single charge density maximum and separated from the other volumes by a zero-flux surface of the gradients of the charge density magnitude. The incremental adsorption energy of an oxygen atom as a function of oxygen coverage Θ = _n_ / _n_ 0<sup>for</sup><sup>_n_</sup> O atoms on _n_ 0 fcc sites on a Cu(111) substrate is calculated as the energy change when a further O atom is adsorbed on the substrate, 1 _E_ ad( _n_ ) = _E_ [Cu + ( _n_ + 1)O] −[Cu + _E n_ O] − 2 _E_ [O2], in which _E_ [Cu + _n_ O] is the total energy of _n_ oxygen atoms on the Cu substrate and _E_ [O2] is the total energy of an isolated oxygen molecule. 

#### **Data availability** 

The data that support the findings of this study are available from the corresponding authors on reasonable request. Source data are provided with this paper. 

36. Cha, S. Y. et al. Improving the precision of Hall effect measurements using a single-crystal copper probe. _Rev. Sci. Instrum._ **83** , 013901 (2012). 

37. Cho, Y. C. et al. Copper better than silver: electrical resistivity of the grain-free single-crystal copper wire. _Cryst. Growth Des._ **10** , 2780–2784 (2010). 

38. Jackson, D. P. Binding energies in cubic metal surfaces. _Radiat. Eff._ **18** , 185–189 (1973). 

39. Kudriavtsev, Y., Villegas, A., Godines, A. & Asomoza, R. Calculation of the surface binding energy for ion sputtered particles. _Appl. Surf. Sci._ **239** , 273–278 (2005). 

40. Yagisawa, T. & Makabe, T. Modeling of dc magnetron plasma for sputtering: transport of sputtered copper atoms. _J. Vac. Sci. Technol. A_ **24** , 908–913 (2006). 

41. Monkhorst, H. J. & Pack, J. D. Special points for Brillouin-zone integrations. _Phys. Rev. B_ **13** , 5188–5192 (1976). 

42. Henkelman, G., Uberuage, B. P. & Jonsson, H. A climbing image nudged elastic band method for finding saddle points and minimum energy paths. _J. Chem. Phys._ **113** , 9901–9904 (2000). 

43. Bader, R. F. W. A quantum theory of molecular structure and its applications. _Chem. Rev._ **91** , 893–928 (1991). 

**Acknowledgements** This research was supported by the Basic Science Research Program through the National Research Foundation of Korea (NRF) funded by the Ministry of Science, ICT and Future Planning (nos. NRF-2017R1A2B3011822 and NRF-2020R1A4A4078780), the Creative Materials Discovery Program (nos. NRF-2015M3D1A1070672 and NRF2016M3D1A1919181) through the NRF, and the Institute for Basic Science (IBS-R011-D1). Computer time allocation was provided by the High Performance Computing Center (HPCC) at Mississippi State University. 

**Author contributions** S.-Y.J., Y.-M.K. and S.-G.K. conceived this work and wrote the manuscript. **Additional information** S.-Y.J. and Y.-M.K. supervised the experiments. S.J.K. and Y.L. prepared the SCCF samples. **Supplementary information** The online version contains supplementary material available at Y.-M.K., Y.I.K., Y.-H.K., J.C.K. and H.Y.J. performed TEM analyses and sample preparations. https://doi.org/10.1038/s41586-021-04375-5. J.K. conducted the STM analysis. S.J.K., Y.L., T.H., C.R.C. and M.C. performed EBSD and AFM **Correspondence and requests for materials** should be addressed to Seong-Gon Kim, experiments and assisted with the data analyses. S.-Y.J. and S.-G.K. established the theoretical Young-Min Kim or Se-Young Jeong. model, and S.-G.K. and B.L. carried out first-principles calculations. S.-Y.J. and Y.H.L. supervised **Peer review information** _Nature_ thanks Ross Hatton and the other, anonymous, reviewer(s) for and coordinated this work. All authors contributed to the discussion and analysis of the results. their contribution to the peer review of this work. Peer reviewer reports are available. **Reprints and permissions information** is available at http://www.nature.com/reprints. **Competing interests** The authors declare no competing interests. 

Article 



**Extended Data Fig. 1 | Pristine SCCFs grown by ASE. a** , Photo of a 2-inch SCCF grown on Al2O3. **b** , _θ_ –2 _θ_ X-ray diffraction data taken at different positions marked in **a** . **c** , Surface morphologies at 20-nm (upper) and 1.5-nm (lower) vertical scales of AFM images with a root mean square (RMS) surface roughness of 0.28 nm. **d** , EBSD map showing perfect alignment along the (111) plane. **e** , IPF 

with a sole spot associated with the (111) plane. **f** , [100] PF showing the sixfold symmetry of the {100} PF. The inset images in **e** and **f** are the enlarged images of the sole-spot areas. **g** , Scanning electron microscopy images of the sample at different magnifications. **h** , Low-magnification cross-sectional BF-TEM image of the SCCF sample. 



**Extended Data Fig. 2 | Structural and chemical characterizations of a conventional PCCF grown on a glass substrate. a** , Low-magnification cross-sectional BF-TEM image of the PCCF sample showing a typical polycrystalline structure. **b** , Magnified image of the region marked by the yellow box in **a** , which shows the presence of a thick oxidized Cu layer on the surface of the PCCF. **c** , **d** , HRTEM images of oxidized Cu nanoparticles formed in the regions denoted by white boxes in **b** . The measured planar spacings of the (111) planes are 2.32 and 2.46 Å, which represent typical values of CuO and 

Cu2O phases, respectively. **e** , ADF-STEM image of the surface region of the PCCF. **f** , **g** , STEM-EDX elemental maps of Cu ( **f** ) and O ( **g** ) in the surface region. **h** , Vertically averaged intensity profiles of Cu (blue) and O (red) across the surface. Note that the intensity of each element was normalized with respect to its intensity maximum. From this result, it is evident that the highly oxidized Cu surface layer (indicated by the pink shaded region in the graph) can be formed on the PCCF with a thickness of tens of nanometres. 

## Article 



**Extended Data Fig. 3 | Surface oxidation of bulk Cu single crystal. a** , **g** , Low-magnification micrographs of the non-polished and polished Cu single-crystal samples prepared by FIB milling. The insets show the two Cu single crystals sliced and cut to dimensions of 5 × 5 mm<sup>2</sup> . **b** , **h** , HRTEM images of the two Cu surfaces. Note that the yellow arrows indicate the thin Cu2O layers 

that formed on the two surfaces. **c** , **d** , **i** , **j** , FFT patterns of the two regions of Cu2O (red box, labelled ‘1’) and Cu (green box, labelled ‘2’) depicted in each HRTEM image. **e** , **k** , Composite of the two FFT patterns for comparison. **f** , **l** , Measurements of the layer spacings across the interface between Cu and Cu2O (red dotted arrows). 



**Extended Data Fig. 4 | STM topography images of the clean Cu(111)** <110> orientations on the (111) plane. **c** , Profile of step height obtained from the **single-crystal film at room temperature. a** , Configuration of step edges for line scan marked with a black arrow in **a** , which shows a series of mono-atomic an imaging area of 200 × 200 nm<sup>2</sup> . **b** , Atomic-resolution surface structure steps corresponding to the planar spacing of the Cu(111). (image size around 3 × 3 nm<sup>2</sup> ). The arrows indicate the three corresponding 

## Article 



**Extended Data Fig. 5 | Interface structure and strain distribution. a** , Cross-sectional HRTEM image of the interface region of the Cu–Al2O3 heterostructure with an orientation relation of (111)Cu[112]Cu//(001)Al2O3[110]Al2O3<sup>.</sup> **b** , Enlarged image showing an abrupt interface structure. **c** , **d** , In-plane ( _Exx_ ) and out-of-plane ( _Eyy_ ) strain field maps obtained by GPA of the HRTEM image. Note 

that the region enclosed by the white dotted line indicates the strained interface region of about 1–2 nm in thickness. The colour scale indicates the magnitude of the strain relative to the reference area marked by the white box. Scale bars are 2 nm. 



**Extended Data Fig. 6 | Chemical analysis and electronic structure of the grown SCCF. a** , **b** , Nanoscale STEM-EDX elemental maps of Al, O and Cu in the regions on the surface and at the interface of the Cu–Al2O3 heterostructure, respectively. **c** , Comparison of the Cu _L_ 2,3 electron energy-loss near-edge structure profiles obtained at four different positions (marked by the numbers 1–4 in the ADF-STEM images) and the reference profiles obtained from copper metal and copper oxides, CuO and Cu2O (lower graphs). **d** , ADF-STEM image, 

core-loss EELS spectrum imaging data and the constructed elemental map of Cu and O for the surface region of the SCCF sample. The red and blue profiles on the right side are core-loss EEL spectra of O _K_ and Cu _L_ 2,3 edges extracted from the white dotted rectangle denoted in the EELS map. **e** , Equivalent data arrangement for the PCCF sample for comparison of surface oxidation. **f** , X-ray photoelectron spectroscopy depth profile depending on the etching time for the SCCF sample. 

Article 



**Extended Data Fig. 7 | Structural and electronic properties of Cu, Cu2O and Cu2O monolayers on the Cu(111) surface. a** – **c** , Structural model of Cu, Cu2O and Cu2O monolayers on the Cu(111) surface. Cu and O atoms are represented by blue and red spheres, respectively. Only the bonds between O and Cu atoms are drawn explicitly for clarity. **d** , Structural parameters of Cu, Cu2O and Cu2O 

monolayers on the Cu(111) surface. **e** , Degree of oxidation of atoms in various configurations. _n_ e is the electron charge of each atom (the number of valence electrons attributed to each atom computed using the Bader decomposition method<sup>43</sup> ) and _n_ 0 is the number of valence electrons of the corresponding isolated neutral atom. 



**Extended Data Fig. 8 | Relative energy per oxygen atom for the dissociation of the O2 molecule approaching the Cu(111) surface as a function of O–O bond length.** Blue spheres represent Cu atoms and red spheres represent O atoms. The insets show the side and top views of the configurations, with 

corresponding letters on the curve. **a** , O2 molecule far away from the surface. **b** , O2 molecule in the physisorbed state. **c** , O2 molecule in the transition state. **d** , Two O atoms adsorbed on the surface. **e** , O atoms diffused on the surface away from each other. 

Article 



**Extended Data Fig. 9 | Structure of the ASE system and uniformity of the grown Cu film. a** , Schematic diagram of the construction of the ASE system used in this study. The three key technological modifications made to differ from a commercially available sputtering system are as follows: single-crystal Cu sputtering target, electrical wiring with single-crystal Cu cables and mechanical noise-reduction parts, such as vibration absorbers and mechanical diodes. **b** , Two-inch SCCF grown wafer with a target thickness of 95 nm. To check the uniformity of the film thickness, the wafer was cut into pieces along 

the red lines and the five pieces marked by numbers were mounted to our AFM instrument to measure their thickness. **c** , Thickness profiles of the five samples. One side of each SCCF film was mechanically removed to expose the bare surface of the Al2O3 substrate to measure the film thickness from AFM edge profiling. Note that the mid-value in the thickness profile was set to be zero in AFM. The average thickness of the five samples was estimated to be 95 ± 0.18 nm, which corresponds to about 99.8% in uniformity. 



**Extended data Fig. 10 | Monitoring RF power stability and the effect of ASE on surface roughness. a** , **b** , Plots showing the output RF power fluctuations measured over time in the sputtering system without ( **a** , black) and with a single-crystal Cu power cable ( **b** , red). **c** , Plot of the measured root mean square (RMS) roughness of many samples as a function of the film thickness. The RMS values of the blue squares and the red circles were measured from the samples grown by the conventional sputtering system equipped with a single-crystal Cu 

target only and those grown using the ASE system, respectively. The thickness-dependent average RMS surface roughness of the blue squares (blue dashed line) and the red circles (red dashed line, ASE) are 0.66 ± 0.2 nm and 0.20 ± 0.1 nm, respectively. The average RMS surface roughness of the single-crystal films grown by the ASE method for <35 nm (purple dashed line) is 0.17 ± 0.1 nm. 

