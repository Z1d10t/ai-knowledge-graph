# Ultra-wide bandgap semiconductor Ga2O3 power diodes

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Communications |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 586 |
| 作者 | Jin-Cheng Zhang, Peng-Fei Dong, Kui Dang, Yan-Ni Zhang, Qinglong Yan, Hu Xiang, Jie Su, Z. Liu et al. |
| DOI | 10.1038/s41467-022-31664-y |
| 源文件 | 011_Zhang_2022_Ultra-wide-bandgap-semiconductor-Ga2O3-power-dio.pdf |

---


## ARTICLE 



> https://doi.org/10.1038/s41467-022-31664-y **OPEN** 

# Ultra-wide bandgap semiconductor Ga2O3 power diodes 

Jincheng Zhang<sup>1</sup> , Pengfei Dong<sup>1</sup> , Kui Dang 1, Yanni Zhang1, Qinglong Yan1, Hu Xiang1, Jie Su1, Zhihong Liu1, Mengwei Si 2, Jiacheng Gao3, Moufu Kong3, Hong Zhou 1✉ & Yue Hao1 

Ultra-wide bandgap semiconductor Ga2O3 based electronic devices are expected to perform beyond wide bandgap counterparts GaN and SiC. However, the reported power figure-ofmerit hardly can exceed, which is far below the projected Ga2O3 material limit. Major obstacles are high breakdown voltage requires low doping material and PN junction termination, contradicting with low specific on-resistance and simultaneous achieving of n- and p-type doping, respectively. In this work, we demonstrate that Ga2O3 heterojunction PN diodes can overcome above challenges. By implementing the holes injection in the Ga2O3, bipolar transport can induce conductivity modulation and low resistance in a low doping Ga2O3 material. Therefore, breakdown voltage of 8.32 kV, specific on-resistance of 5.24 mΩ⋅cm<sup>2</sup> , power figure-of-merit of 13.2 GW/cm<sup>2</sup> , and turn-on voltage of 1.8 V are achieved. The power figure-of-merit value surpasses the 1-D unipolar limit of GaN and SiC. Those Ga2O3 power diodes demonstrate their great potential for next-generation power electronics applications. 

> 1 State Key Discipline Laboratory of Wide Bandgap Semiconductor Technology, School of Microelectronics, Xidian University, Xi’an 710071, China. 

> 2 Department of Electronic Engineering, Shanghai Jiao Tong University, Shanghai 200240, China. 3 State Key Laboratory of Electronic Thin Films and Integrated Devices of China, University of Electronic Science and Technology of China, Chengdu 61005, China.<sup>✉</sup> email: hongzhou@xidian.edu.cn 

1 

NATURE COMMUNICATIONS | (2022) 13:3900 | https://doi.org/10.1038/s41467-022-31664-y | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-31664-y 

dvanced semiconductor material holds great promise of providing higher conversion efficiency as well as mainAtaining higher voltage for modern industrialand consumer-scale power electronics. Ultra-wide bandgap (UWB) semiconductor with general bandgap (Eg) greater than 4 eV can sustain a higher critical field (Ec) and hence a higher blocking voltage is achievable at a smaller resistance and power electronic component dimension, which turns out to be more efficient than its narrow bandgap material Si and wide bandgap material GaN and SiC counterparts, as summarized in Table 1 of Supplementary Information. The general concept lies behind is that the high electric-field (E) and high temperature driven of the electron excitation from valance band to conduction band is inherently suppressed by the UWB. Therefore, power electronics based on UWB materials are spontaneously endowed with high breakdown voltage (BV) at a lower material thickness and resistance. Combined with good mobility (μ), a crucial power device parameter Baliga’s figure-of-merit (B-FOM~μ × Ec<sup>3</sup> ) of UWB semiconductors could be several or tens of folds of those wide bandgap materials GaN and SiC as well as more than thousands of times of narrow bandgap material Si<sup>1,2</sup> . However, it should be noted that the major tyranny of the UWB forbids achieving effective both n- and p-type doping simultaneously. Among those intriguing UWB semiconductor materials, the emerging Ga2O3 is now regarded as one of the most promising materials for nextgeneration high-power and high-efficiency electronics, due to its cost-effective melt-grown large-scale and low defect density substrate as well as the controllable n-type doping<sup>3</sup> . Ga2O3 with Eg = 4.6–4.8 eV, high EC = 8 MV/cm and decent intrinsic μ = 250 cm<sup>2</sup> /Vs has yielded a B-FOM to be around 3000, which is four times GaN and ten times SiC. Being the mainstream of the UWB semiconductor, Ga2O3-based power electronics are expected to bring higher blocking voltage at a lower specific onresistance (Ron,sp) for power switching applications. Tremendous efforts have been dedicated to explore the material property and push the device limit, and hence significant progresses are acquired during the past 5 years. Despite those intriguing achievements, it should be noted that those performances especially the representative device parameter power figure-of-merit (P-FOM = BV<sup>2</sup> /Ron,sp) are much inferior to the projected material limit, or even cannot be comparable with the 1-D unipolar limit of the GaN and SiC<sup>4,5</sup> . Like other UWB semiconductors with the difficulties of achieving both highly conductive p- and n-type materials at the meantime, one of the major obstacles is the lack of p-type Ga2O3 which can be utilized as the PN homojunction termination for the BV improvement. It was calculated that shallow acceptor does not exist and it was also predicted that the holes are self-trapped inherently<sup>6</sup> . As a result, unipolar Ga2O3 power electronics dominate most of the research and few reports are available about the bipolar transport study. Due to the challenge of realizing p-type Ga2O3 on lightly-doped n-type Ga2O3 layer, the BV of the vertical Ga2O3 power diodes was limited, although various types of edge termination (ET) methods were employed<sup>7</sup> . On the other hand, some wide-bandgap p-type materials like NiOx with Eg of 3.8–4 eV and Cu2O with Eg ~ 3 eV, controllable doping and decent hole mobility of 0.5–5 cm<sup>2</sup> /V s turn out to be a good counterpart of p-type Ga2O3 to boost the diodes performance<sup>8,9</sup> . The combination of p-NiOx and n-Ga2O3 is a feasible route for the Ga2O3 development, and the recent progress of the Ga2O3 PN hetero-junction (HJ) diodes shows a P-FOM of 1.37 GW/cm<sup>2</sup> , which is comparable to the P-FOM value of state-of-the-art Schottky barrier diodes (SBDs)<sup>10,11</sup> . Even incorporating p-NiOx into Ga2O3 material system, the potential of Ga2O3 HJ PN diodes is only explored for less than 10% of the material limitation. Meanwhile, the conductivity modulation effect is observed in Ga2O3 HJ PN diodes, indicating the holes can 

be injected in the Ga2O3 layer<sup>12</sup> . However, under what bias condition and to what extent the conductivity modulation can impact the Ron,sp are still not explored. In addition, the in-depth understanding of bipolar transport in the Ga2O3 layer, especially hole transport and lifetime extraction are still forfeiting. Against the generally believed holes are self-trapped, the hole lifetime is a crucial and fundamental parameter to determine whether the bipolar transport is about to happen and to what extent it will impact the PN diode performances. Another critical issue regards the practical application of UWB PN diode is the requirement of low turn-on voltage (Von) for high-efficiency application, since the general forward bias (VF) is limited to be around 3 V. This is very challenging for homo-junction PN diode for wide bandgap semiconductor GaN and SiC with Von ~ 3 V, regardless of the even wider bandgap Ga2O3. 

In this article, a general design strategy of UWB semiconductor power diodes is provided to achieve high BV and low Ron,sp simultaneously through the introduction of hole injection and transport in Ga2O3 to minimize the Ron,sp, suppressing the background carrier density to improve the BV, employing low conduction band offset p-NiOx to reduce Von, and a composite E management technique with implanted ET and field plate architecture to further strengthen the BV. We setup a milestone of the UWB power diodes by acquiring a BV of 8.32 kV and P- FOM = BV<sup>2</sup> /Ron,sp of 13.21 GW/cm<sup>2</sup> , which is a record P-FOM value among all types of UWB power diodes to date, and it also exceeds the 1-D unipolar limit of GaN and SiC. Meanwhile, a conductivity modulation phenomenon induced bipolar transport of electron and hole pairs is identified with hole lifetime determined to be 5.4–23.1 ns. Considering some real application circumstances of diodes at a VF of 3 V, benchmarking of the BV and Ron,sp extracted at VF = 3 V also shows a record P-FOM value to date, validating the great promise of UWB power diodes for nextgeneration high-voltage and high-power electronics. 

### Results and discussions 

High BV and low Ron,sp design strategy and implementation. The most intriguing aspect of β-Ga2O3 is that its native substrate can be substantially grown by the melt-grown methodology, which lays a basic foundation for low-cost and large-diameter with low defect density substrate<sup>13</sup> . The β-Ga2O3 epi-layer can be epitaxied by various routes, such as molecular beam epitaxy, metalorganic chemical vapor deposition (MOCVD), mist-CVD, halide vapor phase epitaxy (HVPE), and some other low-cost techniques<sup>14,15</sup> . HVPE is the most widely adopted methodology for balancing the epitaxial speed, substrate size, defect density, and complicity. The β-Ga2O3 background doping regulation is a challenge, resulting in a non-controllable electron density of 2–4 × 10<sup>16</sup> cm<sup>−3</sup> . Unintentional doping from precursors like Si or H, and defects like O vacancies all contribute to the n-type conduction in the β-Ga2O3 layer. 

Ideal power devices should embrace high BV and low Ron,sp to provide high blocking capability and low loss simultaneously<sup>16</sup> . In order to improve the BV of the UWB Ga2O3 power diodes, the minimal doping concentration is the first essential, since the slope of the E is governed by the doping concentration<sup>16</sup> . Summarized in Supplementary Fig. 1, it was found that the BV of the reported Ga2O3 power diodes is limited to be less than 3 kV, where the donor concentration is the major tyranny. Some other subsidiary factors like ETs or advanced E management techniques are all prerequisites for a minimized peak E at the anode edge to achieve a high desirable BV. PN junction is one of the most straightforward approaches to suppress the peak E at the interface. However, the forfeit of the p-Ga2O3 on the n-Ga2O3 makes the PN home-junction an impossible mission to further 

2 

NATURE COMMUNICATIONS | (2022) 13:3900 | https://doi.org/10.1038/s41467-022-31664-y | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-31664-y 

explore the maximum BV potentials of diodes. It should be noted that only extending the spacing of two electrodes to increase the BV is of marginal value by sacrificing the Ron,sp and averaged E. In terms of manipulating the Ron,sp, to increase the doping concentration seems to be the simplest, however, the BV will be essentially compromised. A unique physical phenomenon of power diode, which is called conductivity modulation of the PN or PIN junction at forward bias will substantially guarantee a low Ron,sp even at a low doping concentration. Regardless of the challenge on the formation of PN homo-junction, the high Von > 4 V is another suffering for the Ga2O3 homo-junction PN diodes. 

Recently, the implementation of the p-NiOx into the Ga2O3 system opens up another route for expanding the Ga2O3 application from the SBDs to the HJ PN diode<sup>17–20</sup> . Although the performance of the Ga2O3 HJ diode is still inferior to the SBDs at current stage, however, we argue that some fundamental limitations which have haunted the Ga2O3 power diodes research for a decade could be essentially clarified. First, p-NiOx flavors a low conduction band offset of ~2.1 eV such that the high Von issue of the homo-junction could be partially resolved. Second, with a PN HJ structure, the conductivity modulation is theoretically expected so that the Ron,sp can be minimized at a low doping concentration and high VF. In addition, by combining the ETs and advanced E management, the BV can be further enhanced. Comparison of the E management strategies is summarized in Supplementary Fig. 2. 

Figure 1a shows the 3-D cross-sectional image of two representative Ga2O3 HJ PN diodes, the top view image is exhibited as Fig. 1b, and the false-colored scanning electron microscopy (SEM) image at the crucial area of the anode edge is listed in Fig. 1c. In the Ga2O3 power diodes, the doping concentration of the Ga2O3 epi-layer is suppressed from the 2 × 10<sup>16</sup> cm<sup>−3</sup> to around 5–7 × 10<sup>15</sup> cm<sup>−3</sup> for two wafers with different thicknesses by adopting a long duration of the oxygen 

thermal anneal process, as shown in Fig. 1d<sup>21</sup> . C–V curves are shown in Supplementary Fig. 3. Heavily doped p-NiOx layer on top is utilized to form an Ohmic contact, as described in Fig. 1e. The simulated energy band diagram of the p-NiOx/n-Ga2O3 HJ is shown in Fig. 1f with the conduction band and valance band offset to be 2.15 eV and 2.8 eV, respectively. The ET process by Mg doping to form a high-resistivity region underneath the electrode is utilized to withstand a high E and the coupled field plate is implemented to further mitigate crowded peak E at the anode edge<sup>15</sup> . 

Diodes characterizations. Figure 2a compares the log-scale forward current-forward bias-ideality factor (IF-VF-η) characteristics of two Ga2O3 HJ PN diodes with Ga2O3 thickness (TGa2O3) of 7.5 and 13 μm at a radius of 75 μm. The kink effect observed at VF around 1.5 V is related to the variation of the barrier height and ideality factor, which is most likely to be induced by the two different barriers connected in parallel. IF on/off ratio of 10<sup>9</sup> −10<sup>10</sup> and η smaller than 2 can last for 4–5 decades of the IF. Figure 2b shows the linear-scale forward IF-VF-Ron,sp curves of the same diodes as Fig. 2a. Even with a PN HJ structure, a relatively decent Von = 1.8 V is acquired, which is much smaller than the Von of SiC and GaN PN diodes. The small Von is benefited from two aspects, the small conduction band offset between p-NiOx and n-Ga2O3 and the interface recombination current<sup>17</sup> . Minimal Diff. Ron,sp is extracted to be 2.9 and 5.24 mΩ cm<sup>2</sup> for TGa2O3 = 7.5 and 13 μm, respectively. Unlike SBDs with increased Ron,sp at an increased VF, the Ron,sp of the Ga2O3 HJ PN diodes drops at an increased VF, most likely due to bipolar transportinduced conductivity modulation effect. It should be noted that such conductivity modulation effect is the key to enable the simultaneous achievement of low Ron,sp and high BV. Figure 2c describes the radius-dependent IF-VF-Ron,sp curves for diodes with TGa2O3 = 13 μm. Log-scale IF-VF characteristic is 



<!-- Start of picture text -->
a b c<br>Ni/Au<br>R =75  m SiO2<br>Ni/Au<br>p-NiOx<br>30  m 0.4  m n-Ga2O3<br>d e f<br>10 17 20<br>T Ga2O3 = 13  m 15 Ni 100  m Ni 4 EC<br>T Ga2O3 = 7.5  m 10 p-NiOx p-NiOx EC = 2.1 eV<br>2<br>10 16 Sapphire<br>5 Eg=3.92 eV<br>0 0<br>EV EF<br>10 15 -5 -2 EV = 2.8 eV n-Ga2O3<br>-10 Eg=4.67 eV<br>-15 -4<br>10 14 -20<br>0.5 1.0 1.5 2.0 2.5 -12 -8 -4 0 4 8 12 -0.3 0.0 0.3 0.6 0.9 1.2 1.5<br>Depth ( m) Bias (V) Distance ( m)<br>) A Energy (eV)<br>Current  (<br>-3Charge Density  () cm<br><!-- End of picture text -->

Fig. 1 UWB power diodes design and implementation. a 3-D cross-sectional schematic of the Ga2O3 power diodes with HJ architecture and composite electric field management. b Top view of a fabricated Ga2O3 power diode. c False-colored SEM image of the cross-sectional anode field plate region with p-NiOx thickness of 400 nm. d Extracted carrier concentration of two representative samples with concentration of 5 × 10<sup>15</sup> −7 × 10<sup>15</sup> cm<sup>−3</sup> . e Currentvoltage behavior of the Ni pads on p-NiOx with NA = 10<sup>19</sup> cm<sup>−3</sup> , showing an Ohmic contact. f Simulated band diagram of the p-NiOx/n-Ga2O3 HJ structure. The band bending occurs in n-Ga2O3 and the conduction band offset is only 2.1 eV, showing the great promise of low Von even for a UWB material. 

3 

NATURE COMMUNICATIONS | (2022) 13:3900 | https://doi.org/10.1038/s41467-022-31664-y | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-31664-y 



<!-- Start of picture text -->
a b c<br>10 3 10 800 10 3 500 15<br>TGa2O3 = 13  m T Ga2O3 = 13  m<br>10 1 TGa2O3 = 7.5  m 400<br>600<br>R  = 75  m 10 2<br>10 -1 300 10<br>10 -3 1 400 200 & R =75  m<br>R  = 75  m 10 1 & R =50  m<br>10 -5  & T Ga2O3 = 13  m 200 100 & R =30  m 5<br> & T Ga2O3 = 7.5  m<br>10 -7 0 1 2 3 4 50.1 00 1 2 3 4 510 0 00 1 2 3 4 5<br>Forward Bias (V) Forward Bias (V) Forward Bias (V)<br>d e f<br>600 10 3 4.0 9<br>10 2    R  = 75  m<br>T Ga2O3 = 13  m 3.5    R  = 75  m 8<br>10 0 T  = 25  C 450 T Ga2O3 = 13  m<br>T  = 50  C 25  C to 150  C 10 2 3.0<br>7<br>10 -2 T  = 75  C    Step: 25  C<br>300 2.5<br>10 -4 TT  = 100  = 125  CC 10 1 2.0 6<br>150<br>10 -6 T  = 150  C 1.5 Ideality Factor 5<br>R  = 75  m T Ga2O3 = 13  m R on,sp<br>10 -8 0 10 0 1.0 4<br>0 1 2 3 4 5 0 1 2 3 4 5 440 400 360 320 280<br>Forward Bias (V) Forward Bias (V) Temperature (K)<br>cm2<br>Ron,sp = 29.5 m<br>cm2<br>Ron,sp = 15.3 m<br>2)<br>Ideality Factor 2 ) cm 2)cm<br> ( R mon,sp  (mRon,sp<br>Forward Current (A/cm 2Forward Current (A/cm) 2Forward Current (A/cm)<br>2)cm 2)cm<br> (mRon,sp Ideality Factor  (m R on,sp<br>2Forward Current  ( A/cm ) 2Forward Current ()A/cm<br><!-- End of picture text -->

Fig. 2 UWB Ga2O3 power diodes forward characteristics. a Forward current-voltage-ideality factor characteristics of two Ga2O3 power diodes with TGa2O3 = 7.5 and 13 μm. b Forward current–voltage-specific on-resistance Ron,sp characteristics of the same diodes as a. A decent Von = 1.8 V with minimal Diff. Ron,sp = 2.9 and 5.24 mΩ cm<sup>2</sup> as well as extracted overall Ron,sp (@VF = 3 V) of 15.3 and 29.5 mΩ cm<sup>2</sup> for TGa2O3 = 7.5 and 13 μm are achieved. c Radius-dependent forward current-voltage-resistance curves for diodes with TGa2O3 = 13 μm. T-dependent d log-scale and e linear-scale forward characteristics of diode with TGa2O3 = 13 μm. On/Off ratio of 10<sup>10</sup> and 10<sup>8</sup> are achieved for T = 25 °C and 150 °C, respectively. At all temperatures, Ron,sp drops when VF increases, verifying the conductivity modulation effect. f Extracted T-dependent ideality factor and Ron,sp values as e. 

summarized in Supplementary Fig. 4. By increasing the radius, the insulating Mg implanted region constitutes to a smaller portion of the area so that Ron,sp decreases when radius increases. The resistance (Res.) contribution from each layer based on the equation Res. = thickness/(ND × μ × q) is summarized in Supplementary Fig. 5<sup>22</sup> . For diodes with TGa2O3 = 7.5/13 μm, ND = 6 × 10<sup>15</sup> cm<sup>−3</sup> , μ = 200 cm<sup>2</sup> /Vs, and q = 1.6 × 10<sup>−19</sup> C, the resistance of the drift layer is calculated to be 3.89/6.77 mΩ cm<sup>2</sup> . It should be noted that this calculation is based on the low-level injection prerequisite. At VF = 5 V, conductivity modulation effect of the HJ PN diode begins to dominate so that the Ron,sp drops, which is favorable for resistance minimization. Figure 2d and e summarizes the T-dependent linear-scale I-V-Ron,sp and log-scale IFVF of the diode with radius = 75 μm and TGa2O3 = 13 μm. On/off ratios of 10<sup>10</sup> and 10<sup>8</sup> are achieved at T = 25 °C and 150 °C, respectively. At all temperature ranges, the differential (Diff.) Ron,sp drops at an increased VF, verifying the conductivity modulation effect of the Ga2O3 HJ PN diodes. Figure 2f shows the extracted T-dependent ideality factor η and Ron,sp from temperatures of 25–150 °C. The η is extracted from the forward current equation J = Js(exp(qVF/ηkT) − 1), whereas Js is the reverse saturation current, VF is the applied forward bias, q is the electron charge, k is the Boltzmann’s constant, and T is the absolute temperature. The η is extracted to be around 1.5 at T = 25 °C. 

Based on the simulation, it is very interesting to find that hole concentration in the Ga2O3 layer at the HJ-interface is comparable with the Ga2O3 doping concentration of 6 × 10<sup>15</sup> cm<sup>−3</sup> at VF = 3.5 V, as shown in Supplementary Figs. 6 and 7. That is to say, the hole injection-related conductivity modulation can help to reduce the Ron,sp only with VF ≥ 3.5 V, since the hole is with more than 1 order of magnitude lower mobility. The simulation result is in good agreement with the forward IF–VF characteristic, since the Ron,sp = 7 mΩ cm<sup>2</sup> (at 

VF = 3.5 V) roughly equals to the resistance summary of p-side Ohmic contact, p-NiOx layer, n-Ga2O3 drift layer, n<sup>+</sup> -Ga2O3 substrate and n-side Ohmic contact. In other words, the hole injection and conductivity modulation are negligible at the VF range of Von = 1.8 V to 3.5 V, due to significant valance band offset between p-NiOx and n-Ga2O3, so that few holes can be injected across this barrier. At VF ~ 3.5 V, holes are injected from p-NiOx to n-Ga2O3 most likely via trap assisted tunneling and hopping mechanisms. By increasing the VF beyond 3.5 V to lower the PN HJ barrier, more holes are injected into n-Ga2O3 layer and hence high level injection phenomenon will raise the electron concentration in the Ga2O3 layer to maintain the charge neutrality condition. Therefore, the Ron,sp is further reduced when the VF is increased. At VF = 5 V, the hole concentration is simulated to be 3.8 × 10<sup>16</sup> cm<sup>−3</sup> and 6 × 10<sup>15</sup> cm<sup>−3</sup> at HJinterface and 6 μm away from the HJ-interface, respectively. The averaged hole (also electron) concentration is extracted to be 1.9 × 10<sup>16</sup> cm<sup>−3</sup> within this 6-μm range, by integrating concentration and then divided by the total length of 6 μm. Therefore, the resistance of the significant hole injection region is roughly calculated to be 1.32 mΩ cm<sup>2</sup> , by considering the electron mobility of 150 cm<sup>2</sup> /Vs at this electron concentration. By adding up another 7-μm low level injected Ga2O3 layer resistance of 6.77/ 13 × 7 = 3.65 mΩ cm<sup>2</sup> , the 13-μm Ga2O3 drift layer owns a Ron,sp of 4.97 mΩ cm<sup>2</sup> . This estimation of the Ron,sp coincides with our extracted Ron,sp from the IF–VF, verifying the correctness of the explanation, hole concentration simulation, and calculation of the hole injection into the Ga2O3 layer. 

The T-dependent reverse I–V characteristics of diode with TGa2O3 = 7.5 μm are plotted in Fig. 3a from T = 25–150 °C. By increasing the T, IR increases, indicating a non-avalanche breakdown behavior. Even at T = 150 °C, the IR is just 1 mA/cm<sup>2</sup> at a reverse bias of 3 kV. By further pushing the reverse bias to 5.1 kV we observe a hard breakdown with 

4 

NATURE COMMUNICATIONS | (2022) 13:3900 | https://doi.org/10.1038/s41467-022-31664-y | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-31664-y 



<!-- Start of picture text -->
a b<br>10 0 10 -5<br>T Ga2O3 = 7.5  m T Ga2O3 = 7.5  m<br>10 -2      R  = 75  m<br>10 -6<br>25  C to 150  C<br>10 -4     Step:25  C<br>10 -7<br>10 -6<br>10 -8 R =30  m<br>10 -8 R =50  m<br>R =75  m<br>10 -10 10 -9<br>0.0 -0.6 -1.2 -1.8 -2.4 -3.0 0 -1 -2 -3 -4 -5 -6<br>Reverse Bias (kV) Reverse Bias (kV)<br>c d Cut-line<br>10 -5 8.32 kV<br>8 E (MV/cm)<br>10 -6 T Ga2O3 = 13  m 12 6 8 8<br>9 6 6<br>10 -7 4 4 interface 4<br>1010 -8-9 RR =75 =50  mm 36 200 2 200.0 0.4 0.8 1.2 1.6Position (4 6 m) 8 10 12 20<br>10 -10 R =30  m 0 Position ( m)<br>0 -2 -4 -6 -8 -10 0 20 40 60 80 100<br>Reverse Bias (kV) Position ( m)<br>Reverse Current (A)<br>2Reverse Current (A/cm)<br>m)<br>E (MV/cm)<br>E (MV/cm)<br>Position (<br>Reverse Current (A)<br><!-- End of picture text -->

Fig. 3 UWB Ga2O3 power diodes with high breakdown voltages. a T-dependent reverse current–voltage characteristics of diode with TGa2O3 = 7.5 μm. With increased T, IR increases, indicating a non-avalanche breakdown. Room temperature reverse current–voltage characteristics of diodes with TGa2O3 = 7.5 μm (b) and 13 μm (c) at various radiuses. A BV of 5.1 kV and 8.32 kV are achieved for diodes with TGa2O3 = 7.5 and 13 μm, yielding an averaged E of 6.45 MV/cm and 6.2 MV/cm, respectively. d Simulated E distribution of the diode with BV = 8.32 kV and TGa2O3 = 13 μm. Due to the small ND = 6 × 10<sup>15</sup> cm<sup>−3</sup> , a fully depletion and a small E slope of the drift layer is observed. 

TGa2O3 = 7.5 μm, as indicated in Fig. 3b. The averaged E field is calculated to be around 6.45 MV/cm by considering E = 5.1 kV/ (0.4 μm + 7.5 μm). Combined with the Ron,sp = 2.9 mΩ cm<sup>2</sup> , the P-FOM = BV<sup>2</sup> /Ron,sp is yielded to be 8.97 GW/cm<sup>2</sup> . As for the diode with TGa2O3 = 13 μm, a maximum BV of 8.32 kV is acquired at an IR = 0.2 mA/cm<sup>2</sup> , as exhibited in Fig. 3c. The asmeasured figure is shown in Supplementary Fig. 8. This BV = 8.32 kV is the highest BV value among all Ga2O3 power FETs and diodes to date. As a result, the P-FOM is calculated to be (8.32 kV)<sup>2</sup> /5.24 mΩ cm<sup>2</sup> = 13.21 GW/cm<sup>2</sup> . Besides the record P-FOM, this HJ PN diode also has a high averaged E = 8.32 kV/ (0.4 μm + 13 μm) = 6.2 MV/cm. Figure 3d describes the E simulation result of the HJ PND with TGa2O3 = 13 μm and BV = 8.32 kV. The simulated peak E in the p-NiOx layer is around 4.9 MV/cm, which is slightly lower than its theoretical limit, considering the 3.9 eV bandgap. The peak E at the p-NiOx side is lower when compared with the peak E at the Ga2O3 side, due to much higher dielectric constant of p-NiOx. Due to the small ND and the depletion effect from the p-NiOx as well as the functionalities of the ET and coupled field plate, a fully depletion and small E slope are observed in the drift layer, resulting a peak E = 7 MV/cm in the Ga2O3 at the HJ-interface. 

Holes in Ga2O3 layer. Similar to other UWB semiconductors like diamond, BN, and AlN, high ionization efficiency of n- and p-type doing simultaneously turns out to be a big challenge, considering the UWB nature of those UWB semiconductor materials. The direct observation of conductivity modulation is a straightforward evidence of bipolar transport and hole existence in the Ga2O3 layer, which deviates from the general prediction that holes are less likely to occur in Ga2O3. Three reasons are attributed to the challenge of acquiring holes in Ga2O3, no calculated shallow acceptors, large effective mass from the flat 

valance band, and free holes tend to be self-trapped by polarons. However, we argue that with the unique PN HJ structure under high VF condition, holes from the heavily-doped p-NiOx are capable of being injected to the Ga2O3 layer, although the hole mobility is relatively low. Under a very positive VF condition (e.g., 5 V), energy band of the p-NiOx is pulled down so that holes at the Fermi tail witness no significant barrier height to travel across the PN HJ-interface and then diffuse in the Ga2O3 layer, leading to the conductivity modulation effect. In other words, the holes can be manufactured in the UWB Ga2O3 layer by hole injection at a very positive VF. In order to verify the hole transportation and survival in the Ga2O3 not so short by self-trapping effect of the polarons, hole lifetime extraction or measurement is urgently needed. 

The reverse recovery measurement technique is implemented to determine the hole lifetime in the Ga2O3 layer, and the schematic of the measurements are summarized in Supplementary Fig. 9a<sup>23</sup> . Once the Ga2O3 diode is switched from positive VF to a reverse bias, a period of time is needed to remove holes from the Ga2O3 either via electron-hole pair recombination or to be trapped by polarons. The hole lifetime (τp) can be determined by the equation τp = tsd/(erf<sup>−1</sup> (IF/(IF + IR)))<sup>2</sup> , whereas tsd, IF, and IR represent charge storage time, forward current, and reverse current, respectively<sup>24</sup> . During the reverse recovery measurement, the VF is extracted to be 2.97 V and 4.73 V for injection current of 5 mA and 25 mA, respectively, at a diode radius of 40 μm. Meanwhile, the subsequently applied reverse bias is −8 V. The reverse recovery and input–output measurement of the pulsed current–voltage characteristics of the UWB Ga2O3 HJ PN diode at a diode current of 5 mA is shown in Fig. 4a. For the HJ PN diode, the IF is 5 mA which is 3 orders of magnitudes more than IR, so that IF/(IF + IR) can be simplified to be 1. Then the τp can be simplified to π/4 × tsd, which is ~80% of the tsd when the diode 

5 

NATURE COMMUNICATIONS | (2022) 13:3900 | https://doi.org/10.1038/s41467-022-31664-y | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-31664-y 



<!-- Start of picture text -->
a<br>5 mA<br>23.1 ns<br>0 mA<br>20 ns<br>-5 mA<br>b 30<br>Diode 1<br>25 Diode 2<br>20<br>15<br>10<br>5<br>0<br>0 5 10 15 20 25 30<br>Currents (mA)<br>Lifetime (ns)<br><!-- End of picture text -->

Fig. 4 Hole lifetime determination in Ga2O3 layer. a Time-dependent of the reverse recovery characteristics of Ga2O3 HJ PN diode at a forward injection current of 5 mA. b Lifetime dependence on the forward injection current with current ranges from 5 mA to 25 mA. At current of 5 mA, the lifetime is determined to be 23.1 ns. At high VF condition, holes diffuse from p-NiOx to n-Ga2O3 without seeing obvious barrier, so that the hole lifetime in the Ga2O3 layer can be determined. 

is switched until the anode current is recovered to be around 0. Therefore, hole lifetime τp is determined to be 23.1 ns at a forward injection current IF of 5 mA. The τp dependence on IF is summarized in Fig. 4b, with a minimal τp of 5.4 ns. In order to exclude the subsidiary impact on the measurements, the reverse recovery measurement is performed on Ga2O3 SBD (Supplementary Fig. 9b) and the recovery time in the SBD is determined to be 1.8 ns, which is 1 order of magnitude lower when compared with the HJ PN diode. By injecting holes into the Ga2O3 layer at high VF, the hole lifetime is then determined to be 5.4–23.1 ns. By combining the calculated hole effective mass (mp*) of 4.46mo (Supplementary Fig. 10), the hole mobility (μp) can be roughly estimated by the equation μp = q × τp/mp*, yielding the μp to be 1.93–8.3 cm<sup>2</sup> /Vs. 

Performance benchmarking. The combination of the conductivity modulation induced low Ron,sp and low doping concentration as well as the composite E regulation led record BV renders a substantial performance enhancement by setting a record P-FOM of all UWB power diodes (Fig. 5a), including Ga2O3, diamond, and high AlAlxGa1−xN (x > 60%) power diodes<sup>25–44</sup> . Compared with all other Ga2O3 power diodes, the BV of this work is around three times the 



<!-- Start of picture text -->
a<br>10 3 This Work<br>Ga2O3 SBD/JBS<br>10 2 Ga2O3 PND<br>SiC<br>AlxGa(1-x)N x≥0.6 SBD<br>Diamond SBD/PND GaN<br>10 1<br>Ga2O3<br>10 0<br>10 -1<br>10 -2<br>10 2 10 3 10 4<br>Breakdown Voltage (V)<br>b<br>This Work Ron,sp = 3 V/ ( IF@3 V )<br>Ga2O3 Diodes<br>10 2 Diamond Diodes SiC<br>GaN Diodes<br>SiC Diodes<br>GaN<br>10 1<br>Ga2O3<br>10 0<br>10 3 10 4<br>Breakdown Voltage (V)<br>)(2mΩ·cmMinimal  R on,sp<br>)2(mΩ·cm R on,sp<br><!-- End of picture text -->

Fig. 5 Benchmarking UWB Ga2O3 power diodes against state-of-the-art other diodes. a Minimal Ron,sp versus BV of some representative UWB power diodes, including Ga2O3, diamond, and high-Al AlGaN, which are reported in the literatures. Our Ga2O3 power diodes set a milestone for the UWB power diodes by breaking the 1-D unipolar figure-of-merit limit of GaN and SiC. b Extracted Ron,sp(@3V) versus BV of some highest performance GaN, SiC, and diamond diodes. By considering some real application circumstances, the Ron,sp = 3V/(IF@3 V) is preferred over the minimal Ron,sp to eliminate the impact of the Von. GaN and SiC PN diodes are excluded due to the Von ~ 3 V. Our UWB power diodes demonstrate a substantial enhancement of the performance over other diodes by surpassing the 1-D unipolar limit of the SiC. The Ron,sp extraction for lateral diodes is yielded by Ron,sp = on-resistance × (anode–cathode spacing +1.5 μm transfer length for both electrodes). 

previously reported best BV of 2.9 kV with a lower Ron,sp. The most enticing aspect of this work is that the performance of the Ga2O3 device exceeds the 1-D unipolar limit of the SiC and GaN. In terms of real application of the HJ PN diode in the circuit, the overall Ron,sp at a general VF = 3 V instead of the minimal differential Ron,sp is more realistic. In order to eliminate the impact of Von, an overall Ron,sp of 15.3 mΩ cm<sup>2</sup> and 29.5 mΩ cm<sup>2</sup> are extracted for TGa2O3 of 7.5 μm and 13 μm at a VF = 3 V, respectively, as shown in Fig. 2b. Benchmarking against all other state-of-the-art representative diodes, including SiC SBDs/JBS diodes/PN diodes and GaN SBDs/ PN diodes with extracted Ron,sp at a fixed VF = 3 V, our Ga2O3 HJ PN diodes achieve a record of nowadays power diodes, as compared in Fig. 5b<sup>33,45–53</sup> . Even under the real application circumstance, the P-FOM = BV<sup>2</sup> /Ron,sp of the Ga2O3 power diodes still surpasses the 1-D unipolar limit of the SiC. These intriguing results verify the great promise of UWB semiconductor Ga2O3 power diodes for nextgeneration high-voltage and high-power electronics. 

In summary, we show that UWB semiconductor Ga2O3 power diodes are capable of delivering a record high BV<sup>2</sup> /Ron,sp, which breaks the 1-D unipolar limit of the SiC and GaN figure-of-merit. The incorporation of suppressed background doping, HJ PN structure, and the composite electric field management technique 

6 

NATURE COMMUNICATIONS | (2022) 13:3900 | https://doi.org/10.1038/s41467-022-31664-y | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-31664-y 

yields a high BV which makes the averaged electric field approach the material limit. Taking advantage of the hole injection as well as the conductivity modulation, the Ron,sp can be essentially minimized even the Ga2O3 is with a low doping concentration. The hole lifetime is determined to be 5.4–23.1 ns, which verifies the existence of the hole in the Ga2O3 layer. By carefully engineering the energy band offset, a decent Von can also be derived for a high efficiency rectifying. This unique technology by implementing the low doping material, electric field suppression, hole injection as well as the conductivity modulation, and energy band engineering offers an effective route for the innovation of other UWB power diodes, such as diamond, BN, high Al mole fraction AlxGa1-xN. 

### Methods 

Fabrication of UWB Ga2O3 power diodes. Ga2O3 epi-wafers with epi-layer thicknesses of 7.5 μm and 13 μm were epitaxial by HVPE on a (001) substrate with substrate doping concentration of 2 × 10<sup>19</sup> cm<sup>−3</sup> . Substrates were first thinned down from 650 μm to 300 μm by polishing to minimize on-resistance. Then, Ga2O3 epi-wafers were annealed in the low-pressure-CVD furnace at 500 °C under the O2 ambient to partially compensate the donors in the epi-layer. N-side Ohmic contacts were formed by evaporating Ti/Au metals followed with rapid thermal anneal at 450 °C. Angle-dependent Mg ion implantation was utilized to form a highresistivity layer to serve as the ET. Bi-layers of p-NiOx were sputtered at room temperature with first and second layer doping concentration of 1 × 10<sup>18</sup> cm<sup>−3</sup> and 1 × 10<sup>19</sup> cm<sup>−3</sup> , respectively. The doping concentration of the p-NiOx layer was confirmed by the Hall measurements and the Hall mobility of the second p-NiOx layer is 1.1 cm<sup>2</sup> /Vs. P-side Ohmic contacts were formed by depositing Ni/Au layers. The field plate was constructed by depositing 300 nm of SiO2, SiO2 etching, and field plate metal evaporation. A summary of the device process schematic flow is shown in Supplementary Fig. 11. 

Device characterizations. The forward I–V and C–V characteristics were carried out by the Keithley 4200 semiconductor analyzer systems. Reverse I–V measurements were performed by Agilent B-1505A high voltage semiconductor analyzer systems with extended high-voltage module up to 10 kV. The hole lifetime measurements were carried out by reverse recovery measurement methods as Supplementary Fig. 9. 

### Data availability 

The data that support the plots within this paper and other findings of this study are available from the corresponding author upon reasonable request. The reason for controlled access is due to privacy issue. The data is available from the corresponding author H.Z. for research purposes and the corresponding author will send the data within one week once received the request. 

7. Li, W., Nomoto, K., Hu, Z., Jena, D. & Xing, H. G. Field-plated Ga2O3 trench Schottky barrier diodes with a BV<sup>2</sup> /Ron,sp of up to 0.95 GW/cm<sup>2</sup> . IEEE Electron Device Lett. 41, 107–110 (2020). 

8. Lin, T., Li, X. & Jang, J. High performance p-type NiOx thin-film transistor by Sn doping. Appl. Phys. Lett. 108, 233503 (2016). 

9. Pattanasattayavong, P., Thomas, S., Adamopoulos, G., McLachlan, M. A. & Anthopoulos, T. D. p-channel thin-film transistors based on spray-coated Cu2O films. Appl. Phys. Lett. 102, 163503 (2013). 

10. Wang, C. et al. Demonstration of the P-NiOx/n-Ga2O3 heterojunction gate FETs and diodes with BV<sup>2</sup> /Ron,sp figure of merits of 0.39 GW/cm<sup>2</sup> and 1.38 GW/cm<sup>2</sup> . IEEE Electron Device Lett. 42, 485–488 (2021). 

11. Roy, S. et al. High-k oxide field-plated vertical (001)β-Ga2O3 Schottky barrier diode with baliga’s figure of merit over 1 GW/cm<sup>2</sup> . IEEE Electron Device Lett. 42, 1540–1143 (2021). 

12. Zhou, F. et al. 1.95-kV Beveled-Mesa NiO/β-Ga2O3 heterojunction diode with 98.5% conversion efficiency and over million-times overvoltage ruggedness. IEEE Trans. Power Electron. 37, 1223–1227 (2021). 

13. Irmscher, K., Galazka, Z., Pietsch, M., Uecker, R. & Fornari, R. Electrical properties of beta-Ga2O3 single crystals grown by the Czochralski method. J. Appl. Phys. 110, 063720 (2011). 

14. Thomas, S. R. et al. High electron mobility thin-film transistors based on Ga2O3 grown by atmospheric ultrasonic spray pyrolysis at low temperatures. Appl. Phys. Lett. 105, 092105 (2014). 

15. Wang, C. et al. Progress in state-of-the-art technologies of Ga2O3 devices. J. Phys. D: Appl. Phys. 54, 243001 (2021). 

16. Baliga, B. J. Fundamentals of Power Semiconductor Devices (Springer, 2008). 

17. Lu, X. et al. 1-kV sputtered p-NiO/n-Ga2O3 heterojunction diodes with an ultra-low leakage current below 1 μA/cm<sup>2</sup> . IEEE Electron Device Lett. 41, 449–452 (2020). 

18. Gong, H. H. et al. A 1.86-kV double-layered NiO/β-Ga2O3 vertical p–n heterojunction diode. Appl. Phys. Lett. 117, 022104 (2020). 

19. Kokubun, Y., Kubo, S. & Nakagomi, S. All-oxide p–n heterojunction diodes comprising p-type NiO and n-type β-Ga2O3. Appl. Phys. Exp. 9, 091101 (2016). 

20. Schlupp, P., Splith, D., Wenckstern, H. V. & Grundmann, M. Electrical properties of vertical p-NiO/n-Ga2O3 and p-ZnCo2O4/n-Ga2O3 pnheterodiodes. Phys. Status Solidi A 216, 1800729 (2019). 

21. Lv, Y. et al. Oxygen annealing impact on β-Ga2O3 MOSFETs: improved pinch-off characteristic and output power density. Appl. Phys. Lett. 117, 133503 (2020). 

22. Schroder, D. K. Semiconductor Material and Device Characterization, 3rd ed. (Hoboken, NJ, USA: Wiley, 2006). 

23. Dutta, M. et al. Determination of minority carrier lifetime of holes in diamond p-i-n diodes using reverse recovery method. IEEE Electron Device Lett. 39, 552–555 (2018). 

24. Streetman, B. & Banerjee, S. K. Junctions. in Solid State Electronic Devices 6th edn, (Englewood Cliffs, NJ, USA: Prentice-Hall, 2006). 

25. Lv, Y. et al. Demonstration of β-Ga2O3 junction barrier Schottky diodes with a Baliga’s figure of merit of 0.85 GW/cm<sup>2</sup> or a 5A/700 V handling capabilities. IEEE Trans. Power Electron. 36, 6179–6182 (2021). 

26. Yang, J. et al. High breakdown voltage (−201) β-Ga2O3 Schottky rectifiers. IEEE Electron Device Lett. 38, 906–910 (2017). 

### Code availability 

The simulation code that supports the plots within this paper and other findings of this study are available from the corresponding author upon reasonable request. The reason for controlled access is due to privacy issue. The data are available from the corresponding author H.Z. for research purposes and the corresponding author will send the data within one week once received the request. 

Received: 2 November 2021; Accepted: 22 June 2022; 



27. Allen, N. et al. Vertical Ga2O3 Schottky barrier diodes with small-angle beveled field plates: a Baliga’s figure-of-merit of 0.6 GW/cm<sup>2</sup> . IEEE Electron Device Lett. 40, 1399–1402 (2019). 

28. Konishi, K. et al. 1-kV vertical β-Ga2O3 field-plated Schottky barrier diodes. Appl. Phys. Lett. 110, 103506 (2017). 

29. Li, W. et al. 2.44 kV Ga2O3 vertical trench Schottky barrier diodes with very low reverse leakage current. In Proc. IEEE International Electron Devices Meeting (IEDM), 8.5.1-8.5.4 (2018). 

30. Lin, C. H. et al. Vertical Ga2O3 Schottky barrier diodes with guard ring formed by nitrogen-ion implantation. IEEE Electron Device Lett. 40, 1487–1490 (2019). 

31. Zhou, H. et al. High-performance vertical β-Ga2O3 Schottky barrier diode with implanted edge termination. IEEE Electron Device Lett. 40, 1788–1791 (2019). 

### References 

1. Pearton, S. J. et al. A review of Ga2O3 materials, processing, and devices. Appl. Phys. Rev. 5, 011301 (2018). 

2. Higashiwaki, M. & Jessen, G. H. Guest Editorial: the dawn of gallium oxide microelectronics. Appl. Phys. Lett. 112, 060401 (2018). 

3. Zhou, H. et al. A review of the most recent progresses of state-of-art gallium oxide power devices. J. Semicond. 40, 011803 (2019). 

4. Zheng, Z. et al. Gallium nitride-based complementary logic integrated circuits. Nat. Electron. 4, 595–604 (2021). 

5. Nela, L. et al. Multi-channel nanowire devices for efficient power conversion. Nat. Electron. 4, 284–290 (2021). 

6. Tsao, J. Y. et al. Ultrawide-bandgap semiconductors: research opportunities and challenges. Adv. Electron. Mater. 4, 1600501 (2018). 

32. Yan, Q. et al. β-Ga2O3 hetero-junction barrier Schottky diode with reverse leakage current modulation and BV<sup>2</sup> /Ron,sp value of 0.93 GW/cm<sup>2</sup> . Appl. Phys. Lett. 118, 122102 (2021). 

33. Gong, H. et al. 1.37 kV/12 A NiO/β-Ga2O3 heterojunction diode with nanosecond reverse recovery and rugged surge-current capability. IEEE Trans. Power Electron. 36, 12213–12217 (2021). 

34. Hao, W. et al. Low defect density and small I-V curve hysteresis in NiO/βGa2O3 pn diode with a high PFOM of 0.65 GW/cm<sup>2</sup> . Appl. Phys. Lett. 118, 043501 (2021). 

35. Zhang, Y. et al. Demonstration of a 2 kV Al0.85Ga0.15N Schottky barrier diode with improved on-current and ideality factor. IEEE Electron Device Lett. 41, 457–460 (2020). 

36. Donato, N., Rouger, N., Pernot, J., Longobardi, G. & Udrea, F. Diamond power devices: state of the art, modelling, figures of merit and future perspective. J. Phys. D: Appl. Phys. 53, 093001 (2020). 

7 

NATURE COMMUNICATIONS | (2022) 13:3900 | https://doi.org/10.1038/s41467-022-31664-y | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-31664-y 

37. Makino, T. et al. Diamond Schottky-pn diode with high forward current density and fast switching operation. Appl. Phys. Lett. 94, 262101 (2009). 

38. Traore, A. et al. Zr/oxidized diamond interface for high power Schottky diodes. Appl. Phys. Lett., 104, 052105 (2014). 

39. Wang, J. et al. Demonstration of Al0.85Ga0.15N Schottky barrier diode with >3 kV breakdown voltage and the reverse leakage currents formation mechanism analysis. Appl. Phys. Lett. 118, 173505 (2021). 

40. Butler, J. E. et al. Exceptionally high voltage Schottky diamond diodes and low boron doping. Semicond. Sci. Technol. 18, S67–S71 (2003). 

41. Fu, H. et al. Demonstration of AlN Schottky barrier diodes with blocking voltage over 1kV. IEEE Electron Device Lett. 38, 1286 (2017). 

42. Gong, H. et al. Ga2O3 vertical heterojunction barrier Schottky diodes terminated with p-NiO field limiting rings. Appl. Phys. Lett. 118, 202102 (2021). 

43. Yu, Y. et al. 1.2 kV/2.9 mΩ·cm<sup>2</sup> vertical NiO/β-Ga2O3 heterojunction diodes with high switching performance. In Proc. 32nd International Symposium on Power Semiconductor Devices ICs (ISPSD), 178–181 (2020). 

44. Gong, H. et al. Vertical field-plated NiO/Ga2O3 heterojunction power diodes. In Proc. Electron Devices Technology and Manufacturing Conference (EDTM), 2021. 

45. Xiao, M. et al. 10 kV, 39 mΩ·cm<sup>2</sup> multi-channel AlGaN/GaN codes. IEEE Electron Device Lett. 42, 808–811 (2021). 

46. Xiao, M. et al. 5 kV multi-channel AlGaN/GaN power Schottky barrier diodes with junction-fin-anode. In Proc. IEEE International Electron Devices Meeting (IEDM), pp. 5.4.1–5.4.4 (2020). 

47. Han, S. W. et al. Experimental demonstration of charge-balanced GaN superheterojunction Schottky barrier diode capable of 2.8 kV switching. IEEE Electron Device Lett. 41, 1758–1761 (2020). 

48. Colón, A. et al. Demonstration of a 9 kV reverse breakdown and 59 mΩ.cm<sup>2</sup> specific on-resistance AlGaN/GaN Schottky barrier diode. Solid-State Electron. 151, 47–51 (2019). 

49. Ma, J. et al. 2 kV slanted tri-gate GaN-on-Si Schottky barrier diodes with ultra-low leakage current. Appl. Phys. Lett. 112, 052101 (2018). 

50. Zhang, T. et al. A > 3 kV/2.94 mΩ.cm<sup>2</sup> and low leakage current with low turnon voltage lateral GaN Schottky barrier diode on silicon substrate with anode engineering technique. IEEE Electron Device Lett. 40, 1583–1586 (2019). 

51. Ghandi, R., Bolotnikov, A., Lilienfeld, D., Kennerly, S. & Ravisekhar, R. 3 kV SiC charge-balanced diodes breaking unipolar limit. In Proc. 31st International Symposium on Power Semiconductor Devices ICs (ISPSD), 179–182 (2019). 

52. Lynch, J., Yun, N. & Sung, W. Design considerations for high voltage SiC power devices: an experimental investigation into channel pinching of 10 kV SiC junction barrier Schottky (JBS) diodes. In Proc. 31st International Symposium on Power Semiconductor Devices ICs (ISPSD), 223–226 (2019). 

53. Millan, J. et al. High-voltage SiC devices: diodes and MOSFETs. In Proc. International Semiconductor Conference (CAS), 11–18 (2015). 

### Acknowledgements 

research institute for the 10-kV high voltage breakdown measurements. We are also grateful to Prof. Y. H. Zhang for the valuable discussions. 

### Author contributions 

H.Z. and J.C.Z. conceived the idea and proposed the Ga2O3 HJ PN diodes. Y.H. supervised the whole process and designed the experiment. P.F.D. did the device fabrication and some I-V characterizations. K.D., Y.N.Z., and Q.L.Y. carried out the breakdown measurements, taking SEM and TEM pictures, wafer packaging. H.X., Z.H.L., and M.W.S. carried out the hole lifetime measurements and set-up, partial I–V measurements, and partial data analyze. J.S. performed the DFT calculations. J.C.G. and M.F.K. performed the hole injection TCAD simulation. H.Z. and J.C.Z. co-wrote the manuscript and all authors commented on it. 

### Competing interests 

The authors declare no competing interests. 

### Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-022-31664-y. 

Correspondence and requests for materials should be addressed to Hong Zhou. 

Peer review information Nature Communications thanks the anonymous reviewers for their contribution to the peer review of this work. Peer reviewer reports are available. 

Reprints and permission information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2022 

The work was supported by National Natural Science Foundation of China under the grant nos. 62004147 and 61925404. We are grateful to Dr. Y. Huang from Xidian Wuhu 

8 

NATURE COMMUNICATIONS | (2022) 13:3900 | https://doi.org/10.1038/s41467-022-31664-y | www.nature.com/naturecommunications 

