# Bioadhesive polymer semiconductors and transistors for intimate biointerfaces

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Science |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 225 |
| 作者 | Nan Li, Yang Li, Zhe Cheng, You-Di Liu, Ya-Hao Dai, Seounghun Kang, Song-Song Li, Naisong Shan et al. |
| DOI | 10.1126/science.adg8758 |
| 源文件 | 008_Li_2023_Bioadhesive-polymer-semiconductors-and-transisto.pdf |

---
# **Title: Bioadhesive polymer semiconductors and transistors for intimate biointerfaces** 

5 

**Authors:** Nan Li<sup>1,2</sup> , Yang Li<sup>1</sup> , Zhe Cheng<sup>2</sup> , Youdi Liu<sup>1</sup> , Yahao Dai<sup>1</sup> , Seounghun Kang<sup>1</sup> , Songsong Li<sup>1</sup> , Naisong Shan<sup>1</sup> , Shinya Wai<sup>1</sup> , Aidan Ziaja<sup>1</sup> , Yunfei Wang<sup>3</sup> , Joseph Strzalka<sup>4</sup> , Wei Liu<sup>1</sup> , Cheng Zhang<sup>1</sup> , Xiaodan Gu<sup>3</sup> , Jeffrey A. Hubbell<sup>1,5,6</sup> , Bozhi Tian<sup>2</sup> , Sihong Wang<sup>1,7</sup> * 

## **Affiliations:** 

1Pritzker School of Molecular Engineering, The University of Chicago, Chicago, IL, 60637, USA 

2Department of Chemistry, The University of Chicago, Chicago, IL, 60637, USA 

10 

- 3School of Polymer Science and Engineering, University of Southern Mississippi, Hattiesburg, MS, 39406, USA 

4X-Ray Science Division, Argonne National Laboratory, Lemont, IL 60439, USA 

- 5Committee on Immunology, The University of Chicago, Chicago, IL, 60637, USA 

- 6Committee on Cancer Biology, The University of Chicago, Chicago, IL, 60637, USA 

15 

- 7Nanoscience and Technology Division and Center for Molecular Engineering, Argonne National Laboratory, Lemont, IL, 60439, USA 

- *Corresponding author. Email: sihongwang@uchicago.edu 

20 

25 

30 

**Abstract:** The use of bioelectronic devices relies on direct contact with soft bio-tissues. For transistor-type bioelectronic devices, the semiconductors that need to have direct interfacing with bio-tissues for effective signal transduction do not adhere well with wet tissues, thereby limiting the stability and conformability at the interface. We report a bioadhesive polymer semiconductor through a double-network structure formed by a bioadhesive brush polymer and a redox-active semiconducting polymer. The resulting semiconducting film can form rapid and strong adhesion with wet tissue surfaces, together with high charge-carrier mobility of ~1 cm<sup>2</sup> V<sup>-1</sup> s<sup>-1</sup> , high stretchability, and good biocompatibility. Further fabrication of a fully-bioadhesive transistor sensor enabled us to produce high-quality and stable electrophysiological recording on an isolated rat heart and on in vivo rat muscles. 

**One-Sentence Summary:** Bioadhesive brush polymer designs endow semiconductors with bioadhesion for stable and amplified biosignals recording. 

1 

5 

10 

15 

20 

25 

30 

35 

## **Main Text:** 

Integrating biocompatible electronic devices with living biological tissues is emerging as a promising avenue for achieving the real-time measurement of biological signals with high spatiotemporal resolutions for biological studies and health monitoring ( _1-3_ ). An overarching goal for the development of bioelectronic devices is to achieve conformable and stable interfacing between the sensing surface and the tissue ( _4-6_ ). This requires soft and stretchable properties on devices for adapting to curvilinear tissue surfaces, combined with stable bonding between the electrical sensing surface and the tissue. Progress has been made in the development of stretchable bioelectronic materials and devices ( _7-12_ ). However, for interface bonding ( _13_ ) that necessitates the adhesion property of electronic materials to wet tissue surfaces, successes have been limited to conductors ( _14-17_ ), which can only be used for passive sensing that has moderate sensitivity. 

To realize higher sensitivity, transistor-based active sensing devices are the more advanced option that can provide built-in amplification ( _18, 19_ ). For bio-interfaced sensing, organic electrochemical transistors (OECTs) ( _20-23_ ) based on semiconducting polymers (Fig. 1A) are one of the more promising options with a number of advantages, including high amplification, low operation voltage, intrinsic compatibility with ion-based biological events, and the possibility of achieving tissue-like stretchability. The sensing function of an OECT is achieved by directly attaching its semiconducting channel to the tissue surface (Fig. 1A), so that a biopotential or targeted biochemical signal can electrostatically modulate the bulk conductivity of the channel ( _24-27_ ). Since such bio-signal transduction is essentially determined by the microscopic distance between the semiconducting channel and a tissue surface ( _4_ ), neither the conventional periphery fixation through suturing or stapling (Fig. 1B), nor applying a separate adhesive (Fig. 1C) can give the most conformable and stable contact between the semiconducting polymers and tissue surfaces. Instead, the more desired interfacing is to have the semiconducting channel directly adhere to the tissue surface. 

We report the design of a BioAdhesive polymer SemiConductor (BASC) film that can form robust and rapid adhesion (Fig. 1D) with bio-tissues under gentle pressure, while providing high chargecarrier mobility. This is achieved through a double-network structure formed by a semiconducting polymer and a separate tissue-adhesive polymer. Although there have been reports of tissueadhesive polymers and hydrogels ( _28-31_ ), none of these is suitable for the creation of bioadhesive semiconductor films. First, as semiconducting polymers typically having long side chains, it is a challenge to ensure the accessibility of the bioadhesive groups on the film surface. Second, the bioadhesive polymer needs to have co-processibility with semiconducting polymers that are typically soluble in organic solvents. To achieve good electrical performance, the obtained morphology needs to both keep continuous charge transport pathways and have only a moderate level of aqueous swellability. 

## **Design of the bioadhesive semiconductor** 

40 

We designed a brush-architectured BioAdhesive Polymer (BAP) (Fig. 1E) for forming a doublenetwork film with a semiconducting polymer. This bioadhesive polymer has a polyethylene backbone with long linear side chains terminated with two types of functional units in a controlled ratio: carboxylic acid (COOH) and _N_ -hydroxysuccinimide (NHS) ester. The COOH group provides water-absorption for temporarily drying the tissue surface and forms electrostatic interactions with tissue surfaces. The NHS ester group, as the primary contributor to bio-adhesion, covalently bonds with the primary amine groups on the tissue surface ( _28, 29_ ). To allow the effective exposure of these groups on the film surface when blending with a semiconducting 

45 

2 

5 

10 

15 

20 

25 

polymer, a key innovation in our design is the extension of the side chain length by inserting tetra(ethylene glycol) (TEG) structure (Fig. 1E). This structure is selected for its moderate level of polarity for providing a suitable level of swelling, which, on the one hand, can help to drain the fluid on the tissue surface and facilitate ion transport, and on the other hand, won’t cause exaggerated swelling and volume expansion. 

The semiconductor phase is served by a type of redox-active polymer semiconductor, poly(3,3’bis(2-(2-(2-methoxyethoxy)ethoxy)ethoxy)-2,2’:5’,2’’-terthiophene) (p(g2T-T), shown in Fig. 1F), which has shown high performance in OECT devices for biosensing functions ( _32, 33_ ). For the preparation of the double-network film, we blend p(g2T-T) with the two types of acrylate monomers (COOH-terminated and NHS ester-terminated, respectively) in a controlled ratio (Table S2) in chloroform. We then spin-coat the blended solution on a substrate to form thin films, and further polymerize and crosslink the bioadhesive monomers in the films under UV light (fig. S1). Such an in-situ polymerization process not only solves the co-solubility issue, but also controls the phase separation scale for achieving better percolation connectivity of the p(g2T-T) phase (fig. S2). The obtained bioadhesive semiconductor further enables us to fabricate a fully-bioadhesive and stretchable OECT sensor, and realize tissue-interfaced sensing (e.g., electrophysiological recording on a wet heart, Fig. 1G) with stable bonding and built-in signal amplification. 

## **Water absorption, morphology, and adhesion properties** 

30 

35 

40 

According to our hypothesis, when the BASC is in contact with the tissue surface, the brush-type BAP phase starts to absorb and remove water on the tissue surface. To validate this, we first investigate the water absorption and swelling behavior of a neat brush BAP. After soaking in phosphate-buffered saline (PBS) solution, the mass of BAP increases by ~20 % after 2 min from rapid water absorption, which is followed by slow absorption over the next 24 hours (Fig. 2A). This is also reflected by the volumetric swelling, with a lateral expansion ratio of ca. 1.05 (Fig. 2B). Comparatively, the 1:1 blending of the more hydrophilic COOH group and less hydrophilic NHS ester group renders the BAP with a moderate level of water absorption and swelling, which stands between the levels of the two brush polymers with only COOH or NHS ester terminated side chains (namely BAP-COOH and BAP-NHS, respectively) (fig. S3). The water absorption behaviors of these three brush-architectured polymers are all much milder than poly(acrylic acid) (fig. S4), which could come from different film morphologies and porosities (Fig. 2C and fig. S5) from the two different polymer architectures (i.e., brush vs. non-brush) ( _34, 35_ ). Overall, the moderate level of water absorption for BAP is beneficial for the stability of electrical performance from BASC films. 

When the BAP is blended with p(g2T-T) to form BASC films through spin-coating processes, the p(g2T-T) phase self-assembles into interconnected nanofibril structures (Fig. 2E), as evidenced by atomic force microscopy (AFM) images (Fig. 2D and fig. S6) for the top and bottom surfaces of a film with the blending ratio of 1:40 (in mass) for p(g2T-T)-to-BAP. In the thickness direction, depth-profiling X-ray photoelectron spectroscopy (XPS) shows an increasing fraction of p(g2TT) from the top to the bottom surface (Fig. 2F). This high ratio of BAP is chosen to ensure sufficient surface density of NHS ester groups for high adhesive property, as validated further below. Such a dominant amount of BAP in the BASC film also renders the BASC film with similar mechanical properties to BAP, as featured by a low modulus and viscoelasticity (Fig. 2G and figs. S7 and S8). These tissue-like mechanical properties are crucial for achieving conformal physical contact with tissue surfaces ( _36_ ), and adhesion. 

3 

5 

10 

15 

20 

25 

30 

35 

We next study the adhesion behavior of BASC films through 180-degree peel, lap-shear, and tensile tests on various synthetic materials and bio-tissues, by first holding these films (supported on thermoplastic polyurethane (TPU) substrates) to the different surfaces with gentle pressure (around 5 kPa) for 1 min (fig. S9). On amine-treated glass surfaces, which can form covalent interaction with NHS ester, BASC films display much stronger and tougher adhesion than neat p(g2T-T) films, with an over 40-fold increase in the interfacial toughness, which achieves even higher level than the BAP film (Fig. 2, H and I, and fig. S10). Tests of BASC films with other blending ratios manifest the general trend of higher adhesion from higher ratios of BAP in the film (fig. S11). On several other synthetic surfaces (i.e., gold, TPU, PDMS), BASC films also form much stronger adhesion than neat p(g2T-T) films (fig. S12). 

With the side chain design of the BAP playing the key role in the adhesion property of BASC films, we further compare the BAP (1:1 ratio of COOH and NHS ester) with three polymers with the same backbone but different side chains: BAP-COOH, BAP-NHS, and regular PAAc. Comparisons are also made on the three blended semiconducting films (namely BASC-COOH, BASC-NHS, and SC-PAAc) from each of these polymers with p(g2T-T) in the ratio of 1:40. Through testing on amine-functionalized glass surfaces, several observations can be made. First, among the three types of brush BAPs and the resulting BASCs, the higher amount of NHS ester gives higher adhesion, which proves that the adhesion is mainly provided by the NHS group. Second, the three BASCs built with the three brush BAPs all provide comparable or higher adhesion properties with their corresponding BAPs. In contrast, blending of PAAc with p(g2T-T) results in a decrease of adhesion by about 90 % (Fig. 2J). This validates our design hypothesis for BAP, that long side chains are needed for overcoming the shielding effect from the long side chains of p(g2T-T) on the adhesive groups. 

We then characterize the adhesion performance of BASC films on wet tissue surfaces (figs. S13 and S14). As shown for porcine muscle surfaces, BASC films achieve an interfacial toughness of ~24 J m<sup>-2</sup> , a shear strength of ~7 kPa, and a tensile strength of ~4.4 kPa, which are, ca. 10-fold increase than that from neat p(g2T-T) films for interfacial toughness (Fig. 3, K and L). These adhesion properties are achieved with an equal ratio of brush COOH and NHS ester side chains, and are higher than those with COOH or NHS ester only side chains (i.e., BASC-COOH and BASC-NHS) (Fig. 2L and fig. S15) or other unbalanced mixing ratios of the two groups (figs. S16 and S17). Such a trend of the side-chain influence is different from the behaviors on dry amineglass surfaces, which manifests the importance of hydrophilic COOH groups for absorbing water in establishing adhesion on wet tissue surfaces. The BASC film can also be applied to various wet tissues, including the heart, skin, spleen, with high interfacial toughness, high shear strength, and high tensile strength (Fig. 2M and fig. S15). 

## **Electrical performance in OECT devices** 

40 

45 

Designed as a semiconductor, the electrical performance of BASC films was characterized in OECT devices (Fig. 3A). The OECT’s transfer curve with an on/off ratio of 10<sup>4</sup> indicates ideal semiconducting performance from the BASC film (Fig. 3B and fig. S18), which is on par with p(g2T-T). As calculated from the transconductance ( _g_ m), the obtained charge-carrier mobility of the BASC film approaches 1 cm<sup>2</sup> V<sup>-1</sup> s<sup>-1</sup> , which is comparable to that of the neat p(g2T-T) film (Fig. 3C and figs. S19 and S20). This is given by the percolated charge-transport pathway formed by the p(g2T-T) phase in the BASC film. On the device level, the maximum transconductance, as the key figure-of-merit for OECT performance, the BASC film displays a slight increase compared to the p(g2T-T) film (Fig. 3C), which should come from a much higher thickness (1.9 µm) of the 

4 

5 

15 

30 

BASC film than that (35 nm) of the neat p(g2T-T) film. On the other hand, the measurement of the OECT response speed of these semiconducting films shows that the higher thickness of the BASC film does not lead to a slower response to the gating compared to the neat p(g2T-T) film (Fig. 3D), as ions can transport very efficiently in the blended BAP. 

10 

20 

25 

We carried out grazing incidence X-ray diffraction (GIXD) and ultraviolet-visible (UV-vis) spectroscopy (Fig. 3G and fig. S21) to study interchain packing morphology of the p(g2T-T) phase in the film. The GIXD results (Fig. 3, E and F) reveal that blending with the brush-architected BAP almost completely suppresses the long-range crystallization, which could decrease the modulus of the p(g2T-T) phase. However, the UV-vis absorption spectroscopies show that the p(g2T-T) phase in the BASC film has a higher level of short-range aggregation than the neat film, as represented by the ratios between 0-0 and 0-1 optical transition peaks (Fig. 3G). At the molecular level, this explains the well-maintained mobility from the BASC film. 

For the direct interfacing of a semiconducting polymer with a bio-tissue surface for sensing biophysical or biochemical signals, the other two important interface factors that influence the recorded signal amplitudes are interfacial impedance and the separation distance between the recording and tissue surfaces. For the interfacial impedance, electrochemical impedance spectroscopy (EIS) measurements do show that our double-network BASC design gives lower impedance than applying a separate adhesive at the interface (figs. S22-24). More importantly, our BASC design helps to keep the closest distance between the semiconducting film and the tissue surface during recording. To semi-quantitatively assess the effect of using separate adhesion layers in increasing the distance between the device and tissue surfaces ( _37-40_ ), we coated our BAP polymer in two different thicknesses (3.8 µm and 300 µm) onto a pair of p(g2T-T)-based recording electrodes (Fig. 3H). This layout emulates the channel and the gate in OECT devices. To show the recording capability, AC signals were applied through another pair of gold electrodes that are attached to the top surface of the BAP coating layer, which was fully soaked with PBS solution. As shown in Fig. 3I, the BAP layers with thickness increased from 3.8 µm to 300 µm leads to significant decreases in the potential sensed between the two p(g2T-T) electrodes, which shows major signal decay caused by the use of a separate adhesive layer. 

## **Abrasion resistance, stretchability, and biocompatibility** 

35 

40 

When a polymer semiconductor is interfaced with bio-tissues, several other properties, including abrasion resistance, stretchability, and biocompatibility, are important to the robustness and longterm stability of the interface and the function. During insertion and/or attachment of a device into/onto bio-tissues, physical abrasion can occur on the device surface (Fig. 4A). With conjugated polymers typically having relatively low stretchability and toughness, the films are generally susceptible to abrasions ( _41_ ). Our BASC film shows abrasion-resistance, which should come from the ultrasoft and viscoelastic properties (fig. S26) of the film. To characterize this, we used a piece of polytetrafluoroethylene (PTFE)-covered glass to slide back and forth on a BASC film under a pressure of 1 kPa. After 1,000 cycles of such surface sliding, the BASC film remains mostly intact in appearance under an optical microscope and electrical performance in an OECT device (Fig. 4, B and C). In comparison, a neat p(g2T-T) film was damaged by the surface abrasion processes. To better mimic the abrasion during device implantation processes, we also carried out the comparison using porcine skin, which gives a similar trend (fig. S25). The brief tissue contact during typical abrasion processes would not be sufficient for BASC films to generate adhesion with the tissue surfaces and further create higher frictional force. 

5 

5 

10 

15 

20 

25 

30 

As both p(g2T-T) and the BAP gel are highly stretchable ( _10_ ), the resulting BASC films also have high stretchability (Fig. 4D), which benefits conformability to curvilinear tissue surfaces and robustness under tissue deformations. From the optical microscopy and AFM images, the BASC film can be stretched to 100 % strain without forming any cracks (Fig. 4E). Instead, strain-induced alignment of the p(g2T-T) nanofibers is observed. When tested in OECT devices, the BASC film displays highly stable electrical performance during stretching to 100 % strain, even after 100 repeated cycles (Fig. 4F and fig. S27). 

When a device is interfaced with tissue, the foreign-body response (FBR) is one of the main factors that limit the longevity ( _42, 43_ ), which is influenced by the modulus and the surface chemistry of an implant. We study this behavior of our BASC films by laminating them on both sides of SEBS (polystyrene- _block_ -poly(ethylene- _ran_ -butylene)- _block_ -polystyrene) substrates and implanting subcutaneously in mice. After one-month implantation, fibrotic capsules formed around the BASC samples are thinner than those formed around SEBS control samples, as shown by Masson’s trichrome staining results (Fig. 4, G to I). Besides, immunofluorescence imaging of FBR-related biomarkers (i.e., α-SMA and CD68) shows lower amounts of fibroblasts and macrophages deposited on the BASC surface than those on the SEBS samples (Fig. 4, J to M). These results collectively show that BASC films have better biocompatibility than SEBS, which further elevates the promise for directly interfacing with bio-tissues through implantable devices. In addition, in vitro cell culture (fig. S28) confirms minimal cytotoxicity of the films. 

## **Fully-bioadhesive OECT sensor for ex vivo and in vivo electrophysiological recording** 

We designed and fabricated an OECT-based sensor (Fig. 5A and fig. S29) using BASC films as both the semiconducting channel and the redox-active gate. The surrounding area is occupied by the substrate, which is covered by our BAP film. With the use of microcrack-based stretchable gold (figs. S30 and S31) as the electrodes ( _44, 45_ ) and thin SEBS layers (~570-nm thick) as the encapsulation for the interconnects and the bottom side of the electrodes, the OECT sensor is also stretchable. An as-fabricated fully-bioadhesive OECT displays ideal transfer behavior at 0 % strain and when stretched to 50 % strain (Fig. 5B and fig. S32), and forms strong adhesion when attached to the surface of a wet porcine muscle (Fig. 5C). 

35 

40 

We further demonstrate the benefit of the bioadhesive property of the OECT sensor on epicardial electrocardiogram (ECG) recording from an isolated rat heart (Fig. 5D). The bioadhesive OECT can be conveniently adhered to the wet heart surface by gently pressing for 20 s. During the recording process, the bioadhesive and stretchable properties, working in conjunction, help the OECT to well accommodate the heart beating, thereby maintaining spatially stable and conformable contact on the heart (Fig. 5E, fig. S34, and movie S1). Even under external mechanical perturbation (e.g., pulling), stable attachment is still maintained. The ECG recording from both the left ventricle (LV) and right ventricle (RV) surfaces also remain stable (Fig. 5G and fig. S34). In comparison, for a non-bioadhesive OECT (figs. S35 and S36), which can only stay on the heart surface through capillary force from the fluid, gradual drifting and complete detachment can happen as a result of either heart beating or external perturbation (e.g., pulling) (Fig. 5F, fig. S34, and movie S2). This significantly affects the quality and stability of ECG recording (Fig. 5H). 

We also demonstrate the in vivo use of the bioadhesive OECT on under-skin electromyogram (EMG) recording from the gastrocnemius medialis (GM) muscle of a live rat, for which the OECT can also form stable adhesion by gentle pressing (Fig. 5I and fig. S37). During electrical 

6 

5 

10 

15 

stimulation of the sciatic nerve for triggering leg movements, EMG signals corresponding to each stimulation can be stably recorded without being affected by mechanical perturbation (e.g., pulling) (Fig. 5, J and L, movies S3), which is in stark contrast with the non-bioadhesive OECT (Fig. 5, K and M, movies S4). Furthermore, we also validated the benefits of such direct tissue adhesion as compared to suturing (fig. S38) or a separate adhesive layer (fig. S39), in low invasiveness, and/or higher signal amplitude and stability. Such benefits couple with the built-in amplification ability of OECT-based active sensor (as illustrated by the comparison with a PEDOT:PSS-based passive recording device in fig. S40). 

## **References and Notes** 

1. S.-H. Sunwoo, K.-H. Ha, S. Lee, N. Lu, D.-H. Kim, Wearable and Implantable Soft Bioelectronics: Device Designs and Material Strategies. _Annual Review of Chemical and Biomolecular Engineering_ **12** , 359-391 (2021). 

2. H. Yuk, B. Lu, X. Zhao, Hydrogel bioelectronics. _Chem Soc Rev_ **48** , 1642-1667 (2019). 3. I. You _et al._ , Artificial multimodal receptors based on ion relaxation dynamics. _Science_ **370** , 961-965 (2020). 

4. J. Rivnay, H. Wang, L. Fenno, K. Deisseroth, G. G. Malliaras, Next-generation probes, particles, and proteins for neural interfacing. _Science Advances_ **3** , e1601649 (2017). 

20 

5. S. Liu, Y. Rao, H. Jang, P. Tan, N. Lu, Strategies for body-conformable electronics. _Matter_ **5** , 1104-1136 (2022). 

6. H. Yuk, J. Wu, X. Zhao, Hydrogel interfaces for merging humans and machines. _Nature Reviews Materials_ **7** , 935-952 (2022). 

25 

7. J. Xu _et al._ , Highly stretchable polymer semiconductor films through the nanoconfinement effect. _Science_ **355** , 59-64 (2017). 

8. S. Wang _et al._ , Skin electronics from scalable fabrication of an intrinsically stretchable transistor array. _Nature_ **555** , 83-88 (2018). 

9. Y. Jiang _et al._ , Topological supramolecular network enabled high-conductivity, stretchable organic bioelectronics. _Science_ **375** , 1411-1417 (2022). 

30 

10. Y. Dai _et al._ , Stretchable Redox-Active Semiconducting Polymers for High-Performance Organic Electrochemical Transistors. _Advanced Materials_ **34** , 2201178 (2022). 

11. Z. Yan _et al._ , Highly stretchable van der Waals thin films for adaptable and breathable electronic membranes. _Science_ **375** , 852-859 (2022). 

35 

   12. K. Sim _et al._ , An epicardial bioelectronic patch made from soft rubbery materials and capable of spatiotemporal mapping of electrophysiological activity. _Nature Electronics_ **3** , 775-784 (2020). 

   13. Q. Yang _et al._ , Photocurable bioresorbable adhesives as functional interfaces between flexible bioelectronic devices and soft biological tissues. _Nat Mater_ **20** , 1559-1570 (2021). 

- 40 

14. X. Wang _et al._ , Bioadhesive and conductive hydrogel-integrated brain-machine interfaces for conformal and immune-evasive contact with brain tissue. _Matter_ **5** , 1204-1223 (2022). 

15. I. K. Han _et al._ , Electroconductive, Adhesive, Non-Swelling, and Viscoelastic Hydrogels for Bioelectronics. _Adv Mater_ , e2203431 (2022). 

45 

16. J. Deng _et al._ , Electrical bioadhesive interface for bioelectronics. _Nat Mater_ **20** , 229-236 (2021). 

17. S. Li, Y. Cong, J. Fu, Tissue adhesive hydrogel bioelectronics. _J Mater Chem B_ **9** , 4423- 

7 

4443 (2021). 

18. F. Torricelli _et al._ , Electrolyte-gated transistors for enhanced performance bioelectronics. _Nat Rev Methods Primers_ **1** , 1-24 (2021). 

5 

19. A. Marks, S. Griggs, N. Gasparini, M. Moser, Organic Electrochemical Transistors: An Emerging Technology for Biosensing. _Advanced Materials Interfaces_ **9** , 2102039 (2022). 

20. J. Rivnay _et al._ , Organic electrochemical transistors. _Nature Reviews Materials_ **3** , 1-14 (2018). 

21. B. D. Paulsen, K. Tybrandt, E. Stavrinidou, J. Rivnay, Organic mixed ionic–electronic conductors. _Nature Materials_ **19** , 13-26 (2020). 

10 

15 

20 

   22. J. Chen _et al._ , Highly stretchable organic electrochemical transistors with strain-resistant performance. _Nat Mater_ **21** , 564-571 (2022). 

   23. Y. Jimbo _et al._ , An organic transistor matrix for multipoint intracellular action potential recording. _Proceedings of the National Academy of Sciences_ **118** , e2022300118 (2021). 

   24. G. D. Spyropoulos, J. N. Gelinas, D. Khodagholy, Internal ion-gated organic electrochemical transistor: A building block for integrated bioelectronics. _Science Advances_ **5** , eaau7378 (2019). 

   25. C. Cea _et al._ , Enhancement-mode ion-based transistor as a comprehensive interface and real-time processing unit for in vivo electrophysiology. _Nat Mater_ **19** , 679-686 (2020). 

   26. S. L. Bidinger _et al._ , Pulsed transistor operation enables miniaturization of electrochemical aptamer-based sensors. _Science Advances_ **8** , eadd4111 (2022). 

   27. K. Guo _et al._ , Rapid single-molecule detection of COVID-19 and MERS antigens via nanobody-functionalized organic electrochemical transistors. _Nat Biomed Eng_ **5** , 666-677 (2021). 

   28. J. Li _et al._ , Tough adhesives for diverse wet surfaces. _Science_ **357** , 378-381 (2017). 

- 25 

29. H. Yuk _et al._ , Dry double-sided tape for adhesion of wet tissues and devices. _Nature_ **575** , 169-174 (2019). 

30. B. Xue _et al._ , Hydrogel tapes for fault-tolerant strong wet adhesion. _Nat Commun_ **12** , 7156 (2021). 

30 

31. Z. Ma _et al._ , Controlled tough bioadhesion mediated by ultrasound. _Science_ **377** , 751-755 (2022). 

32. C. B. Nielsen _et al._ , Molecular Design of Semiconducting Polymers for HighPerformance Organic Electrochemical Transistors. _J Am Chem Soc_ **138** , 10252-10259 (2016). 

35 

   33. S. Inal, G. G. Malliaras, J. Rivnay, Benchmarking organic mixed conductors for transistors. _Nat Commun_ **8** , 1767 (2017). 

   34. M. Zhang, A. H. E. Müller, Cylindrical polymer brushes. _Journal of Polymer Science Part A: Polymer Chemistry_ **43** , 3461-3481 (2005). 

   35. E. Dashtimoghadam _et al._ , Injectable non-leaching tissue-mimetic bottlebrush elastomers as an advanced platform for reconstructive surgery. _Nat Commun_ **12** , 3961 (2021). 

- 40 

36. C. M. Tringides _et al._ , Viscoelastic surface electrode arrays to interface with viscoelastic tissues. _Nat Nanotechnol_ **16** , 1019-1029 (2021). 

37. A. Marblestone* _et al._ , Physical principles for scalable neural recording. _Frontiers in Computational Neuroscience_ **7** , 61935 (2013). 

45 

38. J. Du _et al._ , High-Resolution Three-Dimensional Extracellular Recording of Neuronal Activity With Microfabricated Electrode Arrays. _Journal of Neurophysiology_ **101** , 16711678 (2009). 

39. O. Herreras, Local Field Potentials: Myths and Misunderstandings. _Frontiers in Neural Circuits_ **10** , 205896 (2016). 

8 

40. N. Pérez-Prieto, M. Delgado-Restituto, Recording Strategies for High Channel Count, Densely Spaced Microelectrode Arrays. _Frontiers in Neuroscience_ **15** , 681085 (2021). 

5 

   41. A. X. Chen, A. T. Kleinschmidt, K. Choudhary, D. J. Lipomi, Beyond Stretchability: Strength, Toughness, and Elastic Range in Semiconducting Polymers. _Chemistry of Materials_ **32** , 7582-7601 (2020). 

   42. S. Capuani, G. Malgir, C. Y. X. Chua, A. Grattoni, Advanced strategies to thwart foreign body response to implantable devices. _Bioeng Transl Med_ **7** , e10300 (2022). 

- 10 

   43. R. Biran, D. C. Martin, P. A. Tresco, Neuronal cell loss accompanies the brain tissue response to chronically implanted silicon microelectrode arrays. _Exp Neurol_ **195** , 115-126 (2005). 

   44. N. Matsuhisa, X. Chen, Z. Bao, T. Someya, Materials and structural designs of stretchable conductors. _Chem Soc Rev_ **48** , 2946-2966 (2019). 

   45. Y. Lee _et al._ , Standalone real-time health monitoring patch based on a stretchable organic optoelectronic system. _Science Advances_ **7** , eabg9180 (2021). 

- 15 

   46. A. Chortos _et al._ , Highly Stretchable Transistors Using a Microcracked Organic Semiconductor. _Advanced Materials_ **26** , 4253-4259 (2014). 

   47. A. Inoue, H. Yuk, B. Lu, X. Zhao, Strong adhesion of wet conducting polymers on diverse substrates. _Science Advances_ **6** , eaay5394 (2020). 

- 20 

   48. S. Zhang _et al._ , Probing the Viscoelastic Property of Pseudo Free-Standing Conjugated Polymeric Thin Films. _Macromolecular Rapid Communications_ **39** , 1800092 (2018). 

   49. L. Zhang _et al._ , Fully organic compliant dry electrodes self-adhesive to skin for long-term motion-robust epidermal biopotential monitoring. _Nat Commun_ **11** , 4683 (2020). 

   50. T. Zhou _et al._ , 3D Printable High Performance Conducting Polymer Hydrogel for AllHydrogel Bioelectronics. _bioRxiv_ , 2022.2001.2029.478311 (2022). 

- 25 

51. A. Prominski _et al._ , Porosity-based heterojunctions enable leadless optoelectronic modulation of tissues. _Nat Mater_ **21** , 647-655 (2022). 

52. Z. Zhao, G. D. Spyropoulos, C. Cea, J. N. Gelinas, D. Khodagholy, Ionic communication for implantable bioelectronics. _Science Advances_ **8** , eabm7851 (2022). 

30 

53. Z. Yang, Z. Ma, S. Liu, J. Li, Tissue adhesion with tough hydrogels: Experiments and modeling. _Mechanics of Materials_ **157** , 103800 (2021). 

54. T. Zhang, H. Yuk, S. Lin, G. A. Parada, X. Zhao, Tough and tunable adhesion of hydrogels: experiments and models. _Acta Mechanica Sinica_ **33** , 543-554 (2017). 

35 

   55. Y. Sato _et al._ , Microfluidic cell engineering on high-density microelectrode arrays for assessing structure-function relationships in living neuronal networks. _Front Neurosci_ **16** , 943310 (2022). 

   56. M. E. Obien, K. Deligkaris, T. Bullmann, D. J. Bakkum, U. Frey, Revealing neuronal function through microelectrode array recordings. _Front Neurosci_ **8** , 423 (2014). 

   57. R. Huys _et al._ , Single-cell recording and stimulation with a 16k micro-nail electrode array integrated on a 0.18 mum CMOS chip. _Lab Chip_ **12** , 1274-1280 (2012). 

- 40 

58. J. R. Naughton _et al._ , Suppression of crosstalk in multielectrode arrays with local shielding. _Frontiers in Nanotechnology_ **4** , 948337 (2022). 

59. D. A. Bernards, G. G. Malliaras, Steady-State and Transient Behavior of Organic Electrochemical Transistors. _Advanced Functional Materials_ **17** , 3538-3544 (2007). 

45 

60. G. Li _et al._ , Highly Conducting and Stretchable Double-Network Hydrogel for Soft Bioelectronics. _Adv Mater_ **34** , e2200261 (2022). 

61. M. Yang _et al._ , Robust Neural Interfaces with Photopatternable, Bioadhesive, and Highly Conductive Hydrogels for Stable Chronic Neuromodulation. _ACS Nano_ , 885-895 (2023). 

62. L. Q. Flagg _et al._ , Polymer Crystallinity Controls Water Uptake in Glycol Side-Chain 

9 

Polymer Organic Electrochemical Transistors. _Journal of the American Chemical Society_ **141** , 4345-4354 (2019). 

63. A. Giovannitti _et al._ , Controlling the mode of operation of organic transistors through side-chain engineering. _Proc Natl Acad Sci U S A_ **113** , 12017-12022 (2016). 

5 

   64. M. Moser _et al._ , Side Chain Redistribution as a Strategy to Boost Organic Electrochemical Transistor Performance and Stability. _Advanced Materials_ **32** , 2002748 (2020). 

   65. J. Rivnay _et al._ , Organic Electrochemical Transistors with Maximum Transconductance at Zero Gate Bias. _Advanced Materials_ **25** , 7010-7014 (2013). 

- 10 

- 15 

   66. S. M. Kim _et al._ , Influence of PEDOT:PSS crystallinity and composition on electrochemical transistor performance and long-term stability. _Nat Commun_ **9** , 3858 (2018). 

   67. H. Jia _et al._ , Engineering donor–acceptor conjugated polymers for high-performance and fast-response organic electrochemical transistors. _Journal of Materials Chemistry C_ **9** , 4927-4934 (2021). 

   68. M. Moser _et al._ , Polaron Delocalization in Donor–Acceptor Polymers and its Impact on Organic Electrochemical Transistor Performance. _Angewandte Chemie International Edition_ **60** , 7777-7785 (2021). 

- 20 

69. H. Sun _et al._ , Complementary Logic Circuits Based on High-Performance n-Type Organic Electrochemical Transistors. _Advanced Materials_ **30** , 1704916 (2018). 

70. A. Giovannitti _et al._ , N-type organic electrochemical transistors with stability in water. _Nat Commun_ **7** , 13066 (2016). 

25 

71. X. Chen _et al._ , n-Type Rigid Semiconducting Polymers Bearing Oligo(Ethylene Glycol) Side Chains for High-Performance Organic Electrochemical Transistors. _Angewandte Chemie International Edition_ **60** , 9368-9373 (2021). 

72. A. Giovannitti _et al._ , The Role of the Side Chain on the Performance of N-type Conjugated Polymers in Aqueous Electrolytes. _Chemistry of Materials_ **30** , 2945-2953 (2018). 

30 

35 

40 

**Acknowledgments:** The authors thank the University of Chicago Animal Resources Center (RRID:SCR_021806), especially Ani Solanki for his assistance with animal surgery and housing. All the animal experiments performed in this research were approved by the Institutional Animal Care and Use Committee of the University of Chicago, under the protocols of ACUP 72378 and ACUP 72450. 

## **Funding:** 

This work is supported by the National Science Foundation (award number 2105367), the US National Institute of Health Director’s New Innovator Award (1DP2EB034563), the US Office of Naval Research (N00014-21-1-2266), and the start-up fund from the University of Chicago. This work used the Soft Matter Characterization Facility (SMCF) at the University of Chicago. This research used resources of the Advanced Photon Source, a U.S. Department of Energy (DOE) Office of Science user facility operated for the DOE Office of Science by Argonne National Laboratory under Contract No. DE-AC02-06CH11357. Y.W. and X.G. thank the financial aid from NSF grant DMR-2047689. 

**Author contributions:** S.Wang conceived and supervised this research. N.L. and S.Wang designed the experiments. N.L., N.S. synthesized and characterized the monomers and polymers. N.L., Y.L. performed the mechanical tests. N.L., Y.L., Y.L., Y.D., S.L., and A.Z. 

45 

10 

5 

10 

15 

fabricated the transistor devices and performed the measurements. N.L., Y.D., and J.S. performed the GIXD characterization. Z.C., N.L. performed the ex vivo ECG and in vivo EMG measurements. S.K., N.L., and S.Wai performed the biocompatibility study. Y.W., X.G. conducted the film-on-water test. W.L., C.Z. participated the discussions. N.L. and S.Wang co-wrote the paper. All authors reviewed and commented on the manuscript. 

**Competing interests:** S.Wang and N.L. are inventors on patent application no. UCHI 23-T101 submitted by the University of Chicago. 

**Data and materials availability:** All data are available in the manuscript or the supplementary materials. 

## **Supplementary Materials** 

Materials and Methods 

Figs. S1 to S40 Tables S1 to S4 Movies S1 to S4 

11 

5 

10 

15 





**Fig. 1. Bioadhesive polymer semiconductors for electrochemical-transistor-based tissue interfacing.** ( **A** ) Use of electrochemical transistors at tissue interfaces for biosensing with built-in amplification, for which bio-signals couple into the polymer semiconductor channels through direct tissue contact. ( **B** to **C** ) Conventional device attachment methods on tissue surfaces, such as peripheral suturing and applying a non-electrical adhesive layer, and their corresponding limitations. ( **D** ) Direct adhesive attachment achieved by a bioadhesive polymer semiconducting (BASC) channel and a wet tissue surface. The double-network design of the BASC contains a semiconducting polymer and an adhesive polymer achieving covalent bonding with tissue surfaces. ( **E** ) Chemical structures of the adhesive monomers with even longer linear side chains terminated with NHS ester and COOH groups, and the schematic of formed brush-architectured bioadhesive polymer (BAP). ( **F** ) Chemical structure and a schematic of the utilized polymer semiconductor p(g2T-T) with long linear side chains. ( **G** ) Photograph showing a fully-bioadhesive OECT with BASC channel adhered to a rat heart for ECG recording, which can stand for mechanical agitations. 

12 

5 

10 

15 





**Fig. 2. Adhesive-relevant properties of the BASC films.** ( **A** to **B** ) Water content measured through gravimetric analysis ( **A** ) and dimensional swelling ( **B** ) of the BAPs with three types of side-chain designs when soaked in PBS solution over time. ( **C** ) SEM images showing the microscale features of a BAP-COOH film and a PAAc film in the dry state. ( **D** ) AFM phase images showing the top and bottom surfaces of a BASC film. ( **E** ) 3D schematic morphology of a BASC film. ( **F** ) XPS-measured ratios between the S element and the N element from the top to the bottom surface of a BASC film. ( **G** ) Rheological measurement of the BASC polymer in the dry state. ( **H** ) 180-degree peel test (ASTM D3330) for interfacial toughness measurement on rigid substrates. ( **I** ) Interfacial toughness of the adhesion between a BASC film and an amine-functionalized, dry glass substrate, in comparison to a neat p(g2T-T) film, and a BAP film. ( **J** ) On amine-functionalized glass substrates, interfacial toughness achieved by BASC films and BAP (including PAAc) films with different types of side chains. The two dashed lines mark the levels of interfacial toughness for the BASC and BAP films from ( **I** ). ( **K** ) 180-degree peel test (ASTM F2256) for interfacial toughness measurement on bio-tissues. ( **L** ) Interfacial toughness, shear strength, and tensile 

13 

5 

10 

15 

strength of the adhesion between wet porcine muscle tissues and a BASC film, a BASC-COOH film, a BASC-NHS film, and a neat p(g2T-T) film, respectively. ( **M** ) Interfacial toughness, shear strength, and tensile strength achieved by BASC films on various wet tissue surfaces. Values in **I** - **J** , **L** - **M** represent the mean and the standard deviation ( _n_ = 3). Statistical significance and _P_ values are determined by two-sided Student’s t-test: * _P_ <0.05; ** _P_ <0.01. 



**Fig. 3. Electrical and structural characterizations of the BASC film.** ( **A** ) Setup for the OECT-based characterizations. ( **B** ) Transfer curves from a BASC film and a p(g2T-T) film serving as the OECT channel ( _V_ g: gate voltage, _I_ d: drain current, _V_ d: drain voltage, _g_ m: transconductance). ( **C** ) Charge-carrier mobility and _g_ m for the BASC and p(g2T-T) films. Values represent the mean and the standard deviation ( _n_ = 5). ( **D** ) Response speed measurement with applied gate voltage pulse and drain current response. ( **E** ) 2D GIXD patterns of the BASC and p(g2T-T) films. ( **F** ) 1D linecuts in the out-of-plane direction (top) and in-plane direction (bottom) of a BASC and a p(g2T-T) film. ( **G** ) Normalized UV-vis absorption of a BASC and a p(g2T-T) film. ( **H** ) Schematic diagram showing the setup for characterizing the influence of the devicetissue distance caused by the use of a separate bioadhesive layer. ( **I** ) AC signal input (grey) and acquired signals between the p(g2T-T) electrodes that are covered with a layer of BAP with two different thicknesses. 

14 

5 

15 

The thin adhesive layer ( _d_ = 3.8 µm) decreases the signal amplitude by 15 % while the thick adhesive layer ( _d_ = 300 µm) decreases the amplitude by 50 %. 





10 

**Fig. 4. Abrasion resistance, stretchability, and biocompatibility of BASC films.** ( **A** ) Schematic diagram illustrating physical abrasions that can happen on the surfaces of implantable devices. ( **B** ) Photographs showing a BASC film and a p(g2T-T) film before and after abrasion by a PTFE-covered glass plate under 1 kPa for 500 cycles. The arrows indicate the direction of the abrasion. ( **C** ) Changes of OECT on-current from the two films after the abrasion cycles along the charge transport direction. Values represent the mean and the standard deviation ( _n_ = 4-5). ( **D** ) Schematic illustrating a BASC film under stretching. The bottom photograph shows a stretched BASC film on a PDMS substrate at 100 % strain. ( **E** ) Optical microscopy and AFM images showing a BASC film stretched to 100 % strain without forming cracks. ( **F** ) Transfer curves of BASC films in the pristine state, and stretched to 100 % strain for 1 and 100 cycles, which were measured with _V_ d = -0.6 V. ( **G** to **H** ) Masson’s trichrome staining of surrounded tissues of a subcutaneously implanted BASC film ( **G** ) and a SEBS film (control, **H** ) after one month in mice. ( **I** ) Calculated fibrotic capsule thickness. ( **J** to **M** ) Immunofluorescence staining of α-SMA for fibroblasts (yellow, **J** and **L** ) and 

15 

5 

10 

CD68 for macrophages (red, **K** and **M** ). Statistical significance and _P_ values are determined by two-sided Student’s t-test: ns, not significant; ** _P_ <0.01. 





**Fig. 5. Fully-bioadhesive OECT sensor and the use for ex vivo and in vivo electrophysiological recording.** ( **A** ) Device structure and picture. Scale bar: 5 mm. ( **B** ) Transfer curves for a fully-bioadhesive OECT under 0 % and 50 % strains. ( **C** ) Shear strength of the adhesion between a fully-bioadhesive OECT on the porcine muscle tissue, in comparison to an OECT with non-bioadhesive surface. ( **D** ) Schematic showing the use of the OECT sensor for ECG recording on a heart surface, and the circuit diagram. ( **E** ) Photographs showing a fully-bioadhesive OECT attached to an isolated rat heart surface maintaining stable contact during mechanical agitation. ( **F** ) Comparison of a non-bioadhesive OECT, for which capillarybased attachment cannot maintain conformable and stable contact. ( **G)** ECG signals recorded by the fullybioadhesive OECT on the LV. ( **H** ) ECG recording by the non-bioadhesive OECT, which ceased after the device detachment from the heart. ( **I** ) Schematic showing the use of the OECT sensor for EMG recording on the GM muscles upon stimulation of the sciatic nerve. ( **J** ) Photographs showing a fully-bioadhesive OECT attached to the GM muscle maintaining stable contact during mechanical agitation. ( **K** ) Comparison 

15 

16 

of a non-bioadhesive OECT, for which capillary-based attachment cannot maintain conformable and stable contact. ( **L** ) EMG signals recorded by the fully-bioadhesive OECT on the GM muscle. ( **M** ) EMG signals recorded by the non-bioadhesive OECT on the GM muscle, which ceased after the device detached from the muscles. 

17 

