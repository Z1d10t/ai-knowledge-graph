# Surface chemical polishing and passivation minimize non-radiative recombination for all-perovskite tandem solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 162 |
| 作者 | Yongyan Pan, Jia-Nan Wang, Zhen-Xing Sun, Jia-Qi Zhang, Zheng Zhou, Chenyang Shi, Sanwan Liu, Fu-Meng Ren et al. |
| DOI | 10.1038/s41467-024-51703-0 |
| 源文件 | 099_Pan_2024_Surface-chemical-polishing-and-passivation-minim.pdf |

---


### Article 

https://doi.org/10.1038/s41467-024-51703-0 

# Surface chemical polishing and passivation minimize non-radiative recombination for all-perovskite tandem solar cells 

|Received: 5 March 2024<br>Accepted: 14 August 2024<br>Check for updates|Yongyan Pan<sup>1,2,7</sup>, Jianan Wang<sup>1,2,7</sup>, Zhenxing Sun<sup>1</sup>, Jiaqi Zhang<sup>1</sup>, Zheng Zhou<sup>1</sup>,<br>Chenyang Shi<sup>1</sup>, Sanwan Liu<sup>1</sup>, Fumeng Ren<sup>1</sup>, Rui Chen<sup>1</sup>, Yong Cai<sup>1</sup>, Huande Sun<sup>1</sup>,<br>Bin Liu<sup>3</sup>, Zhongyong Zhang<sup>3</sup>, Zhengjing Zhao<sup>4</sup>, Zihe Cai<sup>4</sup>, Xiaojun Qin<sup>4</sup>,<br>Zhiguo Zhao<sup>4</sup>, Yitong Ji<sup>5,6</sup>, Neng Li<br>3, Wenchao Huang5,6, Zonghao Liu<br>1,2<br>&<br>Wei Chen<br>1,2|
|---|---|
||All-perovskite tandem solar cells have shown great promise in breaking the<br>Shockley–Queisser limit of single-junction solar cells. However, the efficiency<br>improvement of all-perovskite tandem solar cells is largely hindered by the<br>surface defects induced non-radiative recombination loss in Sn–Pb mixed nar-<br>row bandgap perovskitefilms. Here, we report a surface reconstruction strategy<br>utilizing a surface polishing agent, 1,4-butanediamine, together with a surface<br>passivator, ethylenediammonium diiodide, to eliminate Sn-related defects and<br>passivate organic cation and halide vacancy defects on the surface of Sn–Pb<br>mixed perovskitefilms. Our strategy not only delivers high-quality Sn–Pb mixed<br>perovskitefilms with a close-to-ideal stoichiometric ratio surface but also<br>minimizes the non-radiative energy loss at the perovskite/electron transport<br>layer interface. As a result, our Sn–Pb mixed perovskite solar cells with band-<br>gaps of 1.32 and 1.25 eV realize power conversion efficiencies of 22.65% and<br>23.32%, respectively. Additionally, we further obtain a certified power conver-<br>sion efficiency of 28.49% of two-junction all-perovskite tandem solar cells.|



Organic-inorganic hybrid perovskite solar cells (PSCs) have made significant advancements over the past decade, achieving an impressive power conversion efficiency (PCE) of 26.7% for single-junction solar cells<sup>1</sup> . Currently, constructing monolithic all-perovskite tandem solar cells (TSCs) by integrating an ~1.7–1.9 eV wide-bandgap (WBG) top subcell with an ~1.2–1.3 eV narrow-bandgap (NBG) bottom subcell can break the Shockley–Queisser efficiency limit of single-junction PSCs. The certified PCE of all-perovskite TSCs has reached 30.1%, demonstrating significant efficiency advantages and promising future development<sup>2,3</sup> . 

To improve the efficiency of TSCs, it is crucial to fabricate highquality subcells and interconnecting layers to minimize the optical and electrical losses<sup>4,5</sup> . However, all-perovskite TSCs are still suffering from undesirable high open-circuit voltage (VOC) deficit and relatively low fill factor (FF), primarily due to the defects induced serious nonradiative carrier recombination at the interface between the Sn–Pb mixed perovskite and the fullerene (C60)-based electron transport layer (ETL) in Sn–Pb mixed perovskite bottom cell<sup>6,7</sup> . The presence of defects on the surface of Sn–Pb mixed perovskite films is mainly caused by the uncontrollable crystallization process of Sn–Pb mixed 

> 1Wuhan National Laboratory for Optoelectronics, Huazhong University of Science and Technology, Luoyu Road 1037, Wuhan 430074, China. 2Optics Valley Laboratory, Hubei 430074, China.<sup>3</sup> State Key Laboratory of Silicate Materials for Architectures, Wuhan University of Technology, Wuhan 430070, China. 4Huaneng Clean Energy Research Institute, Beijing, China. 5Key State Laboratory of Advanced Technology for Materials Synthesis and Processing, School of Materials Science and Engineering, Wuhan University of Technology, Wuhan 430070, China.<sup>6</sup> Hubei Longzhong Laboratory, Wuhan University of Technology Xiangyang Demonstration Zone, 441000 Xiangyang, China.<sup>7</sup> These authors contributed equally: Yongyan Pan, Jianan Wang. e-mail: liuzonghao@hust.edu.cn; wnlochenwei@hust.edu.cn 

Nature Communications |  (2024) 15:7335 

1 

Article 

https://doi.org/10.1038/s41467-024-51703-0 

perovskite, which is mainly due to the faster reaction rate of Sn<sup>2+</sup> with organic cations when compared with the pure Pb<sup>2+</sup> counterpart. This phenomenon results in the aggregation of Sn<sup>2+</sup> ions on the top surface of the Sn–Pb mixed perovskite films, where the accumulated Sn<sup>2+</sup> ions are susceptible to be oxidized, leading to the formation of self-doping defects in the form of Sn<sup>4+,8–10</sup> . Moreover, the volatilization of organic species during the annealing process was generally along with the formation of organic ammonium cation and I<sup>−</sup> vacancy related defects (VA and VI), which contributes to the non-stoichiometric ratios of Sn–Pb mixed perovskite, especially on the film surface<sup>11</sup> . Therefore, it is imperative to minimize the non-radiative recombination loss by diminishing or passivating these surface defects. 

Considering the limited effectiveness of a single surface passivator for the elimination of Sn<sup>4+</sup> defects and the passivation of VA and VI related defects to inhibit interfacial non-radiative recombination<sup>12,13</sup> , here, we report an effective surface reconstruction strategy by using 1,4-butanediamine (BDA) and ethylenediammonium diiodide (EDAI2) together as surface modifiers to fabricate high-quality Sn–Pb mixed perovskite film. Our findings indicate that BDA plays a crucial role in reducing Sn<sup>4+</sup> -related surface defects by its chemical polishing effect on the Sn–Pb mixed perovskite film surface and EDAI2 helps to realize effective surface passivation of VA and VI related defects. Utilizing the aforementioned BDA-EDAI2 surface construction strategy yields a 

high-quality surface with a close-to-ideal stoichiometric ratio and uniform surface potential, resulting in well-aligned Femi-levels and reduced non-radiative recombination at the interface between the perovskite and ETL. As a result, our strategy delivered promising PCEs of 22.65% and 23.32% with increased VOC and FF for 1.32 and 1.25 eV bandgap PSCs respectively. Moreover, our best-performing monolithic two-junction TSCs with an active area of 0.0871 cm<sup>2</sup> exhibited a certified PCE of 28.49% with a VOC of 2.12 V and an FF of 83.88%.We also verified the effectiveness of the surface reconstruction in module-level devices and obtained a champion PCE of 23.39% with an aperture area of 11.3 cm<sup>2</sup> . In addition, the encapsulated tandem cells retained 79.7% of their initial PCEs after continuous operation under maximum power point tracking (MPPT) in ambient air for 550 hours. 

## Results and discussion 

Chemical polishing of Sn–Pb perovskite film surface with BDA We first studied the effect of BDA chemical polishing treatment on the surface composition states of ideal bandgap FA0.7MA0.3Pb0.7Sn0.3I3 perovskite films by conducting X-ray photoelectron spectroscopy (XPS) characterizations. As shown in Fig. 1a, the top surface of the control sample possessed obvious deviation from the stoichiometric ratio of I/(Pb + Sn) of a perfect Sn–Pb mixed perovskite and showed a Sn-accumulated surface state despite the content of Pb is higher than 



<!-- Start of picture text -->
a c e 3<br>4  Pb/Sn I/(Pb + Sn ) Etching 10 nm 100 Control Contro l Control<br>2.93<br>2.58 50<br>2 2<br>0.83 1.02<br>0 0<br>Surface<br>2.30<br>1<br>2 −50<br>1.05 0.79<br>0.35<br>−100<br>0<br>Control W BDA 25 20 15 10 5 0 0 μm 3 μm −2 −1 0 1<br>Percentage (%) q xy (Å -1 )<br>b d f 3<br>Sn 3 d 100 W BDA W BDA BDA<br>Control 50<br>2<br>Etching 10 nm<br>for Control 0<br>Sn 0  3d5/2 Sn 0  3d3/2<br>Sn 2+  3d5/2 Sn 2+  3d3/2 −50 1<br>Sn 4+  3d3/2<br>Sn 4+  3d5/2 W BDA<br>−100<br>498 495 492 489 486 483 25 20 15 10 5 0 0 μm 3 μm −2 −1 0 1<br>Binding Energy (eV) Percentage (%) q xy (Å -1 )<br>g<br>+- +-<br>Sn 2+  oxidation to Sn 4+  +<br>A vacancy<br>BI antisite<br>I vacancy<br>Chemical polishing<br>and Passivation<br>A = FA + /MA + B = Sn 2+ /Pb 2+ I - Sn (�) C O -NH2 -NH3+<br>160 mV 200<br>-1Å () q z Counts<br>Atomic Ratio<br>CPD variation (mV)<br>-160 mV 0<br>160 mV 200<br>-1Å () q z Counts<br>Intensity (a.u.)<br>CPD variation (mV)<br>-160 mV 0<br><!-- End of picture text -->

Fig. 1 | Chemical polishing and passivation of perovskite film surface with BDA and EDAI2. a The surface component of control and BDA modified films before and after 10 nm Ar-etching. b The Sn 3d XPS spectra of the control perovskite sample, the inner region of the control sample after 10 nm etching, and perovskite film surface with BDA polishing. c, d KPFM images (3 × 3 μm<sup>2</sup> ) and corresponding CPD 

variation of perovskite surface before and after BDA polishing. e, f GIWAXS patterns of the perovskite film before and after BDA polishing (0.1 mg mL<sup>–1</sup> ) at a grazing incidence angle of 0.5°. g Scheme of BDA-EDAI2 based polishing and passivation of Sn–Pb mixed perovskite surface. 

Nature Communications |  (2024) 15:7335 

2 

Article 

https://doi.org/10.1038/s41467-024-51703-0 

that of Sn in the perovskite precursor. The composition states in the internal bulk of the control sample were further detected by XPS after exfoliating the surface region via Ar-etching. It was observed that the internal bulk region of the control sample exhibited a reduced Sn/Pb ratio and an almost perfect I/(Pb + Sn) ratio of 3:1 by considering the slight iodine loss during etching. The presence of accumulated Sn<sup>2+</sup> with an under-coordinated state on the surface of the perovskite film could be readily oxidized to Sn<sup>4+,14,15</sup> . This leads to the content of Sn<sup>4+</sup> at perovskite surface being much higher than that in perovskite bulk, which was also proven by the deconvolution spectra of the XPS results for Sn 3d (Fig. 1b and Supplementary Table 1). The clear differentiation between bulk and surface characteristics strongly indicates the subpar surface quality of the control film, marked by a Sn-rich and I-deficient surface state. This condition contributes to the generation of significant defects and triggers serious non-radiative recombination losses. 

To modulate the stoichiometric ratio of the perovskite film top surface, we adopted a chemical polishing method by using BDA as the polishing agent to treat the Sn–Pb mixed perovskite film surface. The optimal concentration of BDA in isopropyl alcohol (IPA) is determined to be 0.1 mg mL<sup>−1</sup> based on the effect of BDA/IPA treatment on the apparent film quality and device performance (Supplementary Figs. 1, 2 and Supplementary Table 2). Thus, the following characterizations were conducted based on Sn–Pb mixed perovskite treated with 0.1 mg mL<sup>−1</sup> BDA/IPA solution. The XPS results revealed that the I/(Pb + Sn) ratio at the surface of the BDA-treated film is closer to that of the bulk film compared to the control film (Fig. 1a), which indicates that the I-deficient top surface is considerably removed and the wellcrystallized perovskite phase is exposed. Meanwhile, the Sn<sup>4+</sup> percentage significantly decreased from 27.3% to 19.1% after BDA polishing, aligning well with the composition in the perovskite bulk (Fig. 1b). Besides, it should be noted that the notable metallic Sn<sup>0</sup> signal observed in the bulk of the control sample was generated by the highenergy Ar-plasma utilized during the etching process<sup>16,17</sup> . 

The surface composition change of the perovskite films is usually associated with the variation of surface potential<sup>15</sup> . To study this point, kelvin probe force microscopy (KPFM) characterizations were conducted. The contact potential difference (CPD) images of the films are shown in Fig. 1c, d. The control film showed obvious inhomogeneities of surface potentials with a larger CPD variation, attributed to the presence of numerous defect states on the film surface causing changes in local surface charge. By contrast, the BDA polished film exhibited a more uniform distribution of surface potential, indicating a surface with fewer defects compared to the untreated film. In addition, it was observed that all grain boundaries (GBs) in the films displayed higher potential than that of the grain interior (GI). This is because the high density of defects and the downward-bending band at GBs could induce the accumulation of carriers and their non-radiative recombination (Supplementary Fig. 3)<sup>18,19</sup> . To assess the impact of BDA on the GBs, we quantitatively determined the potential difference ΔCPD (ΔCPD = CPDGBs - CPDGI)<sup>18</sup> for the samples. It was found that the mean value of ΔCPD decreased from 45 to 29 mV accompanied by a narrower distribution after BDA polishing. These results confirm the effectiveness of BDA polishing in suppressing the accumulation of charge carriers and promoting a homogeneous distribution of surface contact potential, thereby facilitating interface charge transfer<sup>18,20</sup> . 

To understand the fundamental mechanism of the BDA polishing treatment, we further investigated the interaction of BDA with perovskite precursors. We first mixed perovskite powder with BDA, IPA, and BDA/IPA, respectively (Supplementary Fig. 4). It was clearly observed that the Sn–Pb mixed perovskite powder was completely dissolved in BDA and BDA/IPA, but not for the IPA case. This observation confirms that BDA is an effective polishing agent and has strong chemical interaction with Sn–Pb mixed perovskites. To support this assertion, we conducted Fourier transform infrared (FTIR) 

measurements on SnI2/PbI2-BDA sample to investigate their interaction. The stretching vibration (3343 and 3284 cm<sup>−1</sup> ) and bending vibration (1599 cm<sup>−1</sup> ) of N-H group in BDA molecule showed obvious shift upon interacting with SnI2/PbI2 in FTIR spectra<sup>21</sup> , suggesting that there was Lewis acid-base coordination between BDA and Pb<sup>2+</sup> /Sn<sup>2+,22</sup> , which can produce complex precipitates in DMF solution (Supplementary Fig. 5). We further studied the interaction between FAI and BDA by conducting<sup>1</sup> H nuclear magnetic resonance (<sup>1</sup> H NMR) characterizations. As shown in Supplementary Fig. 6, a new proton signal at 6.12 ppm arose in the<sup>1</sup> H NMR spectra after mixing BDA with FAI, which can be attributed to the increased hydrogen bond interaction by sharing proton between FA<sup>+</sup> cation and BDA according to the Brønsted–Lowry acid–base reaction<sup>12,23</sup> . Therefore, it could be inferred that the interaction of BDA with perovskite structure via the diamine groups to form Lewis adducts with SnI64−/PbI64− octahedra and hydrogen bond with FA<sup>+</sup> cation is the crucial factor in the chemical polishing process of the Sn–Pb mixed perovskite film surface. Such strong interaction could further lead to the formation of a collapsed structure of perovskite and exhibiting good solubility in IPA<sup>24,25</sup> . 

Since diamines are stronger bases than FA<sup>+</sup> , Brønsted–Lowry acid–base reaction-based proton transfer is highly favored between BDA and FA<sup>+</sup> cation (Supplementary Fig. 6). This might lead to the formation of BDA<sup>+</sup> or BDA<sup>2+</sup> , which could possibly serve as organic spacers to form low-dimensional perovskite on the surface of Sn–Pb mixed perovskite film. Thus, we further conducted grazing-incidence wide-angle X-rayscattering (GIWAXS) measurements to investigate the surface structure of perovskite after polishing<sup>12,26</sup> . As shown in Fig. 1e, f, the main diffraction peaks of BDA (0.1 mg mL<sup>−1</sup> ) polished film belonging to three-dimensional (3D) perovskite are nearly identical with those of control film and no obvious low-q-value scatter signals were observed after BDA polishing, indicating the crystallinity of lowdimensional perovskite was below the instrumental detection limit<sup>27</sup> . Interestingly, the 0.1 mg mL<sup>−1</sup> BDA/IPA treated perovskite film showed smooth morphology, but when further increasing the concentration of BDA in IPA, secondary-phase small particles were observed on the surface of the perovskite films in the scanning electron microscopy (SEM) images, which are mainly located at GBs (Supplementary Fig. 7). These particles are likely attributed to the BDA<sup>+</sup> or BDA<sup>2+</sup> based lowdimensional perovskite as confirmed by the GIWAXS pattern of the perovskite films treated with 0.5 mg mL<sup>−1</sup> BDA/IPA solution, showing an additional reflection ring at scatter vector q = 0.78 Å<sup>−1</sup> (Supplementary Fig 8). Based on the above results, we therefore expected that the residual BDA molecules likely form a surface adsorbed layer on the Sn–Pb mixed perovskite surface at a relative low BDA concentration condition, enabling surface defects passivation. At higher BDA concentration, the generation of BDA<sup>+</sup> and BDA<sup>2+</sup> will occur, leading to the formation of low-dimensional perovskite (Supplementary Note 1). 

We then compared the passivation ability of four alkyl diamine molecules with different alkyl chain to investigate their polishing effect on the Sn–Pb mixed perovskite surface defects. The density functional theory (DFT) calculations demonstrated that BDA exhibited the strongest binding on the VI defect site through Lewis acid-base interaction, and apparently enhancing the barrier of Sn<sup>2+</sup> oxidation (Supplementary Figs. 9–14 and Supplementary Note 2). Correspondingly, the XPS spectra of Sn–Pb mixed perovskite films treated with different diamine polishing agents showed obvious shift of Sn 3d and Pb 4 f signals towards lower binding energy and the largest peak shift was observed for the BDA polished film, further confirming that BDA was an excellent surface polishing candidate for the Sn–Pb mixed perovskite (Supplementary Fig. 15 and Supplementary Table 3). 

On account of the aforementioned findings, a chemical polishing mechanism of BDA on the Sn–Pb mixed perovskite films surface was proposed (Fig. 1g), in which the surface Pb/Sn-related trap states were washed away by chemical polishing, leading to the formation of more complete perovskite phase lattice skeleton at the surface and along 

Nature Communications |  (2024) 15:7335 

3 

Article 

https://doi.org/10.1038/s41467-024-51703-0 

with the passivation of the surface defects. This could help to retard the oxidation of Sn<sup>2+</sup> and also lead to a uniform surface potential, thereby facilitating the suppression of non-radiative recombination at the perovskite/ETL interface for device performance enhancement. 

Based on the observed effects, we conducted a further investigation into the impact of BDA treatment on the film quality of the Sn–Pb mixed perovskite by X-ray diffraction (XRD) (Supplementary Fig. 16) and UV-vis spectroscopy measurements (Supplementary Fig. 17). It is found that the crystal structure and light absorption of the Sn–Pb mixed perovskite film after BDA treatment were nearly unchanged. These results suggested that BDA treatment serves as a gentle polishing method that has minimal impact on the overall quality of the Sn–Pb mixed perovskite layer, as evidenced by SEM and atomic force microscopy (AFM) analyses (Supplementary Figs. 7, 18). It should be noted that the SEM results revealed that the GBs of the Sn–Pb mixed perovskite turned blurred and the polished film possessed a more compact crystalline morphology after BDA polishing, leading to the surface roughness of perovskite films reduce from 28 to 23 nm, which is in line with the KPFM results and also consistent with prior research findings on the pure Pb-based perovskites<sup>12,28</sup> . These observations indicated that besides the polishing of the perovskite film surface, BDA could also interact with and passivated the GBs, leading to a slightly smoother surface and would be beneficial for the interface contact with ETL. 

#### Synergetic passivation of perovskite film surface with BDA and EDAI2 molecules 

To a certain extent, BDA polishing can realize defect passivation at the Sn–Pb mixed perovskite film surface, it is still insufficient to address the serious recombination loss at perovskite/ETL interface, which not only induced by numerous defects on the perovskite surface, but also involved the band offset<sup>4,29</sup> . As a commonly used passivator for accepted-liked defects of Sn-based perovskite, the efficacy of EDAI2 to modified perovskite’s energy level has been demonstrated in previous work<sup>9,30</sup> . Here, we considered that introducing EDAI2 together with BDA would further assist to passivate VA and VI defects and also achieve the synergetic effect of defect-passivation and energy level alignment modulation at perovskite/C60 interface (Fig. 1g). In addition, it should be mentioned that BDA can also improve the passivation capability of EDAI2 by increasing the solubility of EDAI2 in IPA through the chemical interaction of BDA and EDAI2 as verified by<sup>1</sup> H NMR characterizations (Supplementary Fig. 19)<sup>23,31,32</sup> . 

We further studied the synergistic passivation effect of BDA-EDAI2 on the Sn–Pb mixed perovskite film surface by conducting photoluminescence (PL) and time-resolved photoluminescence (TRPL) spectra characterizations. As shown in Fig. 2a, b, the film with BDAEDAI2 modification showed the higher photoluminescence intensity and the longer carrier lifetime (1.55 μs) versus perovskite samples with EDAI2 (1.22 μs) and BDA (1.11 μs) treatment, which proved the enhancement of passivation ability by the synergistic effect. With the defect reduction by chemical polishing and synergistic passivation, the PL mapping in Fig. 2c and Supplementary Fig. 20 showed both improved uniformity and PL intensity, which indicated the suppression of non-radiative recombination at the perovskite film surface. After treatment, the surface of the Sn–Pb mixed perovskite film also showed a dense and uniform morphology without the observation of lowdimensional structure (Supplementary Fig. 21). 

To verify the suppression of non-radiative recombination at the perovskite/ETL interface by BDA-EDAI2 modification, we then carried photoluminescence quantum yield (PLQY) to assess the change of perovskite/ETL interface properties (Fig. 2d and Supplementary Fig. 22). The PLQY of the control perovskite samplewas improved from 0.43% to 0.81%, 0.92% for perovskite with only BDA polishing or EDAI2 passivation, and was further improved to 1.15% for perovskite with BDA-EDAI2 passivation, which is consistent with the PL and TRPL 

results. However, when in contact with the ETL (C60), the PLQY value of the control film experienced a notable reduction to 0.030%, indicating the non-radiative recombination and energy loss production at the interface caused by the numerous interfacial defects<sup>4,33</sup> . In contrast, the PLQY values of the BDA, EDAI2 and BDA-EDAI2 modified perovskite/C60 samples were measured to be 0.22%, 0.26% and 0.58%, respectively. This improvement suggested that the reduction of both donor and accepter-liked defects could effectively suppress interfacial recombination, which is beneficial for the improvement of VOC. 

In addition, we also carried the ultraviolet photoelectron spectroscopy (UPS) to investigate the impact of surface modification on the energy level alignment at the perovskite/C60 interface. The results depicted in Fig. 2e and Supplementary Fig. 23 indicated that the control perovskite film surface exhibits a clear p-type characteristic attributed to the self-doping of numerous Sn<sup>4+</sup> sites, resulting in inadequate energetic alignment with C60. This misalignment could hinder carrier transfer and aggravate defect-assisted carrier recombination losses at the interface<sup>34</sup> . For the perovskite film with BDA polishing or EDAI2 passivation, there was an obviously upshift of Femilevel, which are attributed to the decrease in self-doping and the generation of dipole at Sn–Pb mixed perovskite surface, respectively<sup>30,35</sup> . By contrast, the synergistic modification of perovskite by BDA-EDAI2 showed an obvious Femi-level upshift to –4.72 eV and the largest reduction of band offset between perovskite and C60. This improved alignment of energy levels is anticipated to facilitate charge extraction at the perovskite/ETL interface<sup>18,36</sup> . 

In view of the composition homogeneity of Sn-based perovskite is also correlated to the residual strain, we further performed grazing incident X-ray diffraction (GIXRD) measurements (Supplementary Note 3). As shown in Fig. 2f–h, the control perovskite film showed obvious residual surface tensile strain, which is likely due to the existence of a large number of defects that caused serious lattice distortion<sup>37,38</sup> . After BDA-EDAI2 modification, the residual tensile strain was effectively released from 53.76 to 31.21 MPa, further revealing the effectiveness of chemical polishing and passivation of BDA-EDAI2 modification. 

#### The PV performance of ideal-bandgap Sn–Pb mixed PSCs 

To study the effect of the BDA-EDAI2 modification on device performance, we fabricated PSCs based on ideal-bandgap Sn–Pb mixed perovskite with an inverted architecture of indium tin oxides (ITO)/poly(3,4-ethylenedioxythiophene):poly(styrenesulfonate) (PEDOT:PSS)/perovskite/C60/bathocuproine (BCP)/Ag. It is found that BDA or EDAI2 treatment could largely improve the average efficiency of the devices from 17.63% to 20.97% and 21.13% (Fig. 3a and Supplementary Figs. 24, 25). When BDA-EDAI2 modification was adopted, the average efficiency was further improved to 22.27% with improved reproducibility. The current-voltage (J–V) curves of the best-performance devices were shown in Fig. 3b and Supplementary Fig. 26. The champion PCE reached for the BDA-EDAI2 modified device was 22.65%, with a VOC of 0.898 V, a short-circuit current density (JSC) of 30.96 mA cm<sup>−2</sup> , an FF of 81.47% (Supplementary Tables 4, 5). The JSC of BDA-EDAI2 modified device was slightly increased when compared with the control device due to the enhanced response in the spectra region of 700–900 nm in external quantum efficiency (EQE) spectra shown in Fig. 3c, in which the integrated JSC value was increased to 30.12 mA cm<sup>−2</sup> that was also closed to the JSC value extracted from J–V characteristics. 

In order to gain deeper understanding of the improvements of VOC and FF when BDA-EDAI2 modification was adopted, we conducted systematical investigations of the charge transport properties of the devices. We first investigated the VOC value evolutions under a range of light intensities. As shown in Fig. 3d, the slope of the BDA-EDAI2 device was much lower than the control device, indicating a smaller ideality factor (n) value<sup>39</sup> . This improvement is due to the successful suppression of interfacial defect-assisted non-radiative recombination and 

Nature Communications |  (2024) 15:7335 

4 

Article 

https://doi.org/10.1038/s41467-024-51703-0 



<!-- Start of picture text -->
a b 1 c<br>W BDA-EDAI2 Control<br>W EDAI2 W BDA<br>W BDA W EDAI2<br>Control W BDA-EDAI2<br>0.1<br>0.01<br>720 840 960 1080 0 2 4 6 8 0 μm 50 μm<br>Wavelength (nm) Time (ûs)<br>d e<br>W BDA-EDAI2<br>10 0<br>10 -1<br>Perovskite<br>Perovskite/C60<br> Interfacial loss due to C60 Control<br>10 -2<br>Control W BDA W BDA-EDAI2 16.8 16.4 16.0 15.6 2 1 0 −1 0 μm 50 μm<br>Binding Energy (eV)<br>f g h<br>31.65<br>Control W BDA-EDAI2<br>ψ  = 45°<br>ψ  = 45°<br>31.60 W BDA-EDAI2<br>ψ  = 40°<br>ψ  = 40° 31.55<br>ψ  = 35°<br>ψ  = 35° 31.50 Control<br>ψ  = 25°<br>ψ  = 25° 31.45<br>ψ  = 15° ψ  = 15° 31.40<br>31.0 31.5 32.0 31.0 31.5 32.0 0.0 0.1 0.2 0.3 0.4 0.5<br>2¢ (degree) 2¢ (degree) sin 2 ψ<br>Control<br>PL Intensity (a.u.)<br>Normalized PL Intensity (a.u.)<br>PLQY (%)<br>Intensity(a.u.) W BDA-EDAI2<br>θ  (degree)2<br>Intensity (a.u.) Intensity (a.u.)<br><!-- End of picture text -->

Fig. 2 | Synergetic passivation of perovskite film surface with BDA and EDAI2. a, b PL and TRPL results of perovskite films with different modifications. c 2D PL mapping (50 × 50 μm<sup>2</sup> ) of the perovskite films with and without BDA-EDAI2 modification. d PLQY results for perovskite films, perovskite/C60 stack with and without passivation. e UPS spectra of control, BDA-EDAI2 modified films. f, g The GIXRD 

results of perovskite film with or without BDA-EDAI2 passivation, while the (012) plane (2θ = 31.6°) was chosen to investigate and relied on the shifting of diffraction peaks upon Bragg diffraction to reflect the residual strain at 50 nm region closed to perovskite surface. h Fitted line of 2θ-sin<sup>2</sup> Ψ from GIXRD results for perovskite films before and after BDA-EDAI2 modification. 

the improved energy level alignment, which was consistent with the PLQY and UPS results and further verified by the electrochemical impedance spectroscopy (EIS) and thermal admittance spectroscopy (TAS) results (Supplementary Figs. 27, 28 and Supplementary Note 4). In addition, the Mott-Schottky (M-S) analysis demonstrated that those favorable effects led to an increase from 0.67 to 0.75 eV of the build-in potential (Vbi) (Supplementary Fig. 29), indicating a larger difference between the electron quasi-Fermi energy level (EFn) and hole quasiFermi energy level (EFp) that achieving a higher VOC20,40. The transient photovoltage decay (TPV) and transient photocurrent decay (TPC) results (Supplementary Fig. 30) also supported that BDA-EDAI2 modification can effectively suppress the interface non-radiative recombination and facilitate the charge extraction, realizing the improvement of VOC and FF. 

We further conducted a quantitative analysis of the FF loss and VOC loss and found that the non-radiative loss and charge transport loss both contributed to the decrease of FF (Supplement Notes 5, 6 and Supplementary Fig. 31), which is in line with the above results<sup>41</sup> . While for the VOC loss, the non-radiative recombination loss of control and BDA-EDAI2 modified device showed a significant reduction of 83 mV evaluated from the EQE of electroluminescence (EL) (Fig. 3e)<sup>42,43</sup> . The 

VOC loss path was displayed by the internal electron-hole quasi-Fermi level splitting (QFLS) calculation results (Fig. 3f, Supplementary Fig. 32 and Supplementary Table 6). It can be found that the energy loss in perovskite and at the perovskite/C60 interface is remarkably decreased after BDA-EDAI2 modification, which indicates that the improvement of VOC is mainly attributed to the reduction of non-radiative recombination loss<sup>44</sup> . Based on the effective BDA-EDAI2 modification, we achieved one of the highest PCE reported to date for ideal-bandgap PSCs (Supplementary Table 7). In addition, benefitting from the optimized interfacial properties and released residual strain, the modified devices achieved enhanced stability, and retained 87.6% of initial PCE after 500 hours operation under MPPT and continuous 1 sun illumination (Supplementary Fig. 33), this was also in favor of the further development of the direction of tandem or module. 

To further verify the universality of the chemical polishing and passivation strategy, we applied BDA-EDAI2 treatment to modify FASnI3 and FA0.6MA0.3Cs0.1Pb0.5Sn0.5I3 perovskite filmsurface. The XPS results showed that the well-crystallized perovskite phases were exposed after BDA-EDAI2 modification for both cases (Supplementary Fig. 34). Especially, the ratio of Sn<sup>4+</sup> was apparently reduced with the shift of binding energy of Sn 3d to the lower value (Supplementary 

Nature Communications |  (2024) 15:7335 

5 

Article 

https://doi.org/10.1038/s41467-024-51703-0 



<!-- Start of picture text -->
a b c 100<br>12<br>Control W BDA  W BDA-EDAI2 30<br>10 80<br>8<br>20 Active area: 0.0871 cm 2 60<br>6 Control-FS<br>Control-RS 40<br>4 10 W BDA-FS<br>W BDA-RS<br>2 W BDA-EDAI2-FS 20 C ontrol, 28.96 mA cm -2<br>W BDA-EDAI2-RS W  BDA-EDAI2, 30.12 mA cm -2<br>0 0 0<br>16 17 18 19 20 21 22 23 0.0 0.2 0.4 0.6 0.8 400 600 800 1000<br>PCE (%) Voltage (V) Wavelength (nm)<br>d e f<br>1.0 Control 1.45  k BT/q 0.3 W BDA-EDAIControl 2 1.1 Radiative limit loss paths<br>0.9 BDA-EDAI2<br>0.083 V 1.0 Perovskite<br>0.2<br>0.8<br>0.9<br>n-Interface<br>0.1<br>0.7 p-Interfa ce<br>1.77  k BT/q Δ V non-rad, loss 0.8 V OC<br>0.6<br>0.0<br>0.7<br>10 100 0.1 1 10 100 Control W BDA-EDAI2<br>Light Intensity (mW cm -2 ) Current Density (mA cm -2 )<br>Counts EQE (%)<br>-2Current Density (mA cm )<br> (V) V OC (%)EQEEL<br>QFLS (eV) and (V) V OC<br><!-- End of picture text -->

Fig. 3 | Device performance of ideal-bandgap Sn–Pb mixed PSCs. a The statistic PCE of ideal-bandgap PSCs with different treatment. b J–V curves of the bestperforming devices with an active area of 0.0871 cm<sup>2</sup> under different treatment. c EQE spectra of the control and BDA-EDAI2 modified PSCs. d The plot of light 

intensity-dependent VOC of the control and BDA-EDAI2 modified PSCs. e EQEEL results of the PSCs working as LEDs under different voltages. f Voltage loss mechanism for the control and BDA-EDAI2 modified devices. 

Fig. 35), which was consistent with the previous conclusions. Based on this harmless surface modification (Supplementary Fig. 36), the PCEs of corresponding devices were largely improved (Supplementary Fig. 37 and Supplementary Tables 8, 9). Especially for the 1.25 eV bandgap PSCs, the PCE was improved to 23.32% with a VOC of 0.878 V, and an FF of 81.55%, which is promising for the construction of allperovskite TSCs. Therefore, we conclude that chemical polishing and passivation could universally enhance the film quality and photovoltaic performance of Sn-based PSCs. 

#### Performance and stability of all-perovskite TSCs 

We further integrated BDA-EDAI2 modified FA0.6MA0.3Cs0.1Pb0.5Sn0.5I3based NBG (1.25 eV) subcell and FA0.8Cs0.2Pb(I0.6Br0.4)3-based WBG (1.77 eV) subcell into two-junction all-perovskite TSCs (Supplementary Figs. 38, 39 and Supplementary Table 10). The cross-sectional SEM image of the tandem device was depicted in Fig. 4a, showcasing the favorable crystal morphology of the absorber layers, which is advantageous for photoelectric conversion, and the thickness of the NBG and WBG perovskite absorber layer was approximately 900 nm and 350 nm, respectively. The photovoltage parameters statistic of TSCs are shown in Fig. 4b. The best-performing BDA-EDAI2 modified TSCs obtained a promising PCE of 28.80% (28.76%) under reverse (forward) voltage scan, with a VOC of 2.13 V (2.13 V), a JSC of 16.06 mA cm<sup>−2</sup> (16.04 mA cm<sup>−2</sup> ) and an FF of 84.19% (84.17%) (Fig. 4c). The integrated JSC value of the WBG and NBG subcells from the EQE spectra (Fig. 4d) were 15.70 and 15.32 mA cm<sup>−2</sup> , indicating a highly matched current density and as well in good with the JSC value in the J–V curve. We also sent one of the best-performing devices to a credible third-party organization and got a certified efficiency of 28.49% (Supplementary Fig. 40), which was one of the highest PCEs reported to date for allperovskite TSCs (Supplementary Table 11). 

To further verify the compatibility of BDA-EDAI2 modification with module level devices, we fabricated a tandem solar module with an aperture area of 11.3 cm<sup>2</sup> . As demonstrated in Fig. 4e, the champion module showed a PCE of 23.39% (reverse voltage scan) with a VOC of 

10.2 V, a JSC of 2.937 mA cm<sup>−2,</sup> and an FF of 78.08%, indicating favorable compatibility of BDA-EDAI2 modification with large-area module devices. In addition, we monitored the operational stability of the encapsulated small-area all-perovskite TSCs under MPPT and continuous 1 sun illumination in ambient air (30–40% RH). The BDA-EDAI2 modified tandem device maintained 79.7% of its initial PCE after 550 hours of operation, as illustrated in Fig. 4f, thereby providing additional evidence of the efficacy of the chemical polishing and passivation approach. 

In summary, our work has demonstrated an effective surface reconstruction strategy by using chemical polishing agent BDA together with EDAI2 surface passivator, enabling the fabrication of highquality NBG perovskite films with defects-deficient surface, uniformity surface potential and suppressed interfacial non-radiation recombination. Impressively, our Sn–Pb mixed PSCs with BDA-EDAI2 modification showed PCEs of 22.65% and 23.32% for 1.32 and 1.25 eV bandgap, respectively, and with largely increased VOC and FF. The asconstructed all-perovskite TSCs also enabled a high certified PCE of 28.49% with a VOC of 2.12 V, an FF of 83.88%. Meanwhile, the small-area TSCs retained 79.7% of initial PCE after 550 h MPPT in ambient atmosphere. 

## Methods 

#### Materials 

All materials were used as received without further purification. Methylammonium iodide (MAI, 99.9%), Formamidinium iodide (FAI, 99.9%), Lead iodide (PbI2, 99.99%), and Lead bromide (PbBr2, 99.99%) were purchased from Advanced Election Technology Co., Ltd. Me4PACz (>99.0%), Guanidine thiocyanate (GuaSCN, >99.0%), Cesium iodide (CsI, >99.0%), Methylamine hydrochloride (MACl, >99.0%) and Bathocuproine (BCP > 99.0%) were purchased from Tokyo Chemical Industry Co., Ltd. (TCI). Tin (II) fluoride (SnF2, 99%), Tin (II) iodide (SnI2, beads, 99.99%) Glycine hydrochloride (GlyHCl, 99%), Potassium thiocyanate (KSCN, >99.0%) and Aluminum oxide (Al2O3, nanoparticles) were purchased from Sigma-Aldrich Co., Ltd. (Sigma- 

Nature Communications |  (2024) 15:7335 

6 

Article 

https://doi.org/10.1038/s41467-024-51703-0 



<!-- Start of picture text -->
a b<br>2.16 16.2 30<br>84<br>BDA-EDAI2/C60 2.12<br>28<br>15.9<br>NBG PVK 82<br>2.08<br>26<br>C60/SnO2/Au/PEDOT:PSS 15.6<br>80<br>WBG PVK 2.04<br>1 μm 15.3 24<br>2.00 78<br>Control BDA-EDAI2 Control BDA-EDAI2 Control BDA-EDAI2 Control BDA-EDAI2<br>c d 100 e<br>16 WBG subcell 3.0<br>NBG subcell<br>80 2.5<br>12<br>60 2.0<br>8 1.5<br>40 Integrated  J sc Integrated  J sc<br>15.70 mA·cm -2 15.32 mA·cm -2<br>1.0<br>4 Active area: 0.0871 cm 2 20 5 subcells; aperture area: 11.3 cm 2<br>Forward scan, PCE = 28.76% 0.5 Forward scan, PCE = 23.27%<br>Reverse scan, PCE = 28.80% Reverse scan, PCE = 23.32%<br>0 0 0.0<br>0.0 0.5 1.0 1.5 2.0 400 600 800 1000 0 2 4 6 8 10<br>Voltage (V) Wavelength (nm) Voltage (V)<br>f<br>1.0<br>0.8<br>79.7%<br>0.6<br>0.4<br>Encapsulated devices with BDA-EDAI2 modification<br>0.2 MPPT Under 1 sun illumination, RH 30-40%<br>0.0<br>0 50 100 150 200 250 300 350 400 450 500 550<br>Time (h)<br> (V) V OC FF (%) PCE (%)<br>-2) (mA cm J SC<br>EQE (%)<br>2Current DensitymA cm) (3 -2Current Density (mA cn)<br>Normalized PCE<br><!-- End of picture text -->

Fig. 4 | Device performance of all-perovskite tandem solar cells and modules. a Cross-section SEM image of all-perovskite TSCs with BDA-EDAI2 modification. b The PV parameters statistic of control and BDA-EDAI2 modified tandem devices. c J–V curves of the best-performing all-perovskite TSCs with an active area of 

0.0871 cm<sup>2</sup> . d EQE spectra of the corresponding TSCs. e J–V curves of the tandem module with an aperture area of 11.3 cm<sup>2</sup> . f MPPT of small-area tandem device with encapsulation under continuous 1 sun illumination. 

Aldrich). PEDOT:PSS aqueous solution (Al-4083), Ethylenediammonium diiodide (EDAI2, 99.99%), 1,3-Propyldiammonium diiodide (PDAI2, 99.99%) and Fullerene (C60) were purchased from Xi’an Yuri Solar Co., Ltd (China). 1,4-Butanediamine (BDA, 98%) was purchased from Aladdin. All solvents were purchased from Sigma-Aldrich. 

#### Fabrication of Perovskite Thin Films 

For 1.32 eV bandgap perovskite, the 1.8 M FA0.7MA0.3Pb0.7Sn0.3I3 precursor solution was prepared by mixing 1.26 mmol FAI, PbI2, and 0.54 mmol MAI, SnI2 into 0.25 mL DMSO and 0.75 mL DMF mixed solvent, also with the MACl additive related to 10% molar ratio of PbI2 and the SnF2 additive related to 10% molar ratio of SnI2. Before the spin-coating, the precursor solution was stirred at 45 °C for 1 h and filtered through a 0.22 μm PTFE filter. A two-step spin-coat program was adopted: the first step was spin-coated at 1000 rpm for 10 s and the second step was spin-coated at 4000 rpm for 35 s. To spin-coat the films, the sample was quickly washed with 200 μL chlorobenzene (CB) at 15 s before the end of the procedure. The film was then immediately annealed at 100 °C for 10 min. 

For 1.25 eV bandgap perovskite, the Cs0.1FA0.6MA0.3Sn0.5Pb0.5I3 was prepared by mixing 0.2 mmol CsI, 1.2 mmol FAI, 0.6 mmol MAI, 1.0 mmol PbI2, 1.0 mmol SnI2, 0.1 mmol SnF2, 0.04 mmol GlyHCl, and 

0.02 mmol GuaSCN into 1 mL mixed solvents of DMF and DMSO with the 3:1 ratio to reach the 2.0 M. The precursor solution was stirred at 45 °C for 1 h and then filtered using a 0.22-μm PTFE membrane before use. Adjusted the second spin-coating time to 40 s and the CB was dripped onto the substrate at 20 s before the end of the procedure, then also annealed by the same procedure. 

For the FASnI3 perovskite, the modified precursor and fabricated procedure followed the literature<sup>45</sup> . 

For the narrow-bandgap perovskite chemical polishing and passivation precursor, BDA solution was prepared by adding BDA into IPA with concentrations of 0.05, 0.1, 0.3, and 0.5 mg mL<sup>−1</sup> . The BDA-EDAI2 solution was prepared by dissolving EDAI2 into BDA/IPA solution with different concentrations, each solution was stirred for over 2 h at room temperature and filtered before use. The polishing and passivation agents were spin-coated onto the perovskite at 4000 rpm for 20 s then the film was annealed at 100 °C for around 5 min. 

For the 1.2 M FA0.8Cs0.2Pb(I0.6Br0.4)3 perovskite film with 1.77 eV bandgap, the precursor was prepared by adding 0.96 mol FAI, 0.24 mmol CsI, 0.48 mmol PbI2 and 0.72 mmol PbBr2 and 0.024 mmol KSCN into 1 mL DMF and DMSO mixed solvent (v:v = 3:1) and the film was prepared by spin-coating precursor solution at 5000 rpm for 60 s and CB was quickly dripped onto the substrate at 30 s before the end 

Nature Communications |  (2024) 15:7335 

7 

Article 

https://doi.org/10.1038/s41467-024-51703-0 

of spin-coating, then film was annealed on the hotplate at 100 °C for 10 min. After cooling down to room temperature, the film was subsequently passivated by PDAI2 solution (1.5 mg mL<sup>−1</sup> in IPA), which was spin-coated at 4000 rpm for 20 s and annealed at 100 °C for 5 min. 

#### Device fabrication 

Single-junction perovskite solar cells. Glass/ITO substrates were cleaned thoroughly by sequential ultra-sonication for 20 min in a detergent solution, distilled water, alcohol, and isopropanol. Then, the substrates were dried with N2 flow and cleaned by UV-ozone for 30 min before use. 

For the NBG PSCs, the PEDOT:PSS solution wasspin-coated on ITO substrates at 5000 rpm for 30 s and annealed on a hotplate at 150 °C for 20 min in ambient air. After that, the samples were immediately transferred into an N2-filled glovebox to deposit the rest layers. The Al2O3/IPA dispersion solution was spin-coated onto the HTL at 6000 rpm for 30 s and annealed at 100 °C for 5 min. Then, the perovskite layer with or without surface treatment was prepared by the above procedure. After cooling down to room temperature, the sample was transferred to the vacuum evaporation system and C60 (20 nm), BCP (7 nm), and Ag (100 nm) layers were sequentially deposited to accomplish the device preparation. 

For the WBG PSCs, all the preparation process was conducted in the N2-filled glovebox. The Me-4PACz ethanol solution (0.8 mg mL<sup>−1</sup> ) mg was spin-coated on ITO substrates at 3000 rpm for 30 s and annealed for 10 min at 100 °C. Following that, the Al2O3 and perovskite layers were respectively prepared by the above procedure, and the C60 (20 nm), BCP (7 nm), and Ag (100 nm) layers were sequentially deposited. 

Two-junction all-perovskite tandem solar cells. For the WBG subcell, the Me-4PACz, Al2O3, 1.77 eV bandgap perovskite, PDAI2, and C60 were sequentially deposited by the same procedure in WBG PSCs. Then, the SnO2 (30 nm)/Au (1 nm) tunnel recombination junction was deposited respectively by the atomic layer deposition (ALD) and thermal evaporation system onto the WBG subcell. After that, the PEDOT:PSS/IPA (v:v/1:2) solution was spin-coated at 4000 rpm for 30 s and annealed at 100 °C for 15 min in ambient air. The residue layers for the 1.25 eV bandgap subcell were prepared in N2-filled glovebox followed by the same procedure in NBG PSCs, which was finally making an architecture of Glass/ITO/Me-4PACz/Al2O3/WBG perovskite/PDAI2/C60/ALD-SnO2/ Au/PEDOT:PSS/Al2O3/NBG perovskite/BDA-EDAI2/C60/BCP/Ag for allperovskite tandem solar cell. 

#### Mini-modules fabrication 

The mini-modules were fabricated on the 5.0 cm × 5.0 cm sized glass/ ITO substrate using a 532 nm nanosecond laser scribing with a power of 4 W (P1), isolating into 5 subcells with a width of 6.8 mm. All the spincoated layers in mini-modules were at the same spin-coat speed of small-area devices with the acceleration changed to 1000 rpm s<sup>–1</sup> to ensure that the solution could be evenly coated on the substrate. Before the P2 scribing (0.5 W), the ALD-SnO2 layer with a thickness of 10 nm was deposited on the C60 layer to prevent the oxidation of NBG perovskite and the rear metal electrode of Cu (100 nm) was deposited by thermal evaporation system. Finally, effective monolithically interconnected modules were formed by laser scribing (0.5 W) to form P3 lines. 

#### Characterization and measurements 

Film characterization. The X-ray photoelectron spectroscopy (XPS) was recorded on an AXIS-ULTRA DLD-600 W Ultra spectrometer (Kratos Co., Japan). The Kelvin probe force (KPFM) was performed in the tapping mode by AFM under ambient conditions (SPM9700, Shimadzu Co., Ltd., Japan). Each set of samples was arranged in proximity on a common substrate and was measured using the same tip and 

scanning parameters. Optical absorption measurements were characterized on a UV-vis spectrometer (PerkinElmer Co., USA). The topviewing and the cross-sectional images of the samples were monitored by a field-emission SEM (FEI NOVA NanoSEM 450). The UPS spectra was measured on an AXIS-ULTRA DLD-600W Ultra spectrometer (Kratos Co. Japan). A He discharge lamp (hv = 21.22 eV), emitting ultraviolet energy at 21.22 eV, was used for excitation. The XRD characterizations were measured on an Empyrean X-ray diffractometer with Cu Kα radiation (PANalytical B.V. Co., Netherlands) to explore the information on the crystal structure. The grazing incident X-ray diffraction (GIXRD) was conducted utilizing an X-ray diffractometer (XRD, Rigaku Smartlab) with Cu Kα wavelength λ = 1.54 Å in the 2θ range of 30.6°−32.6°. The GIWAXS measurement was carried out with the Xeuss 3.0 and the incident angle was 0.5°. The Steady-state Photoluminescence (PL) spectra and time-resolved photoluminescence spectrum (TRPL) were respectively recorded by Edinburgh FLS920 fluorescence spectrometer (Edinburgh Co., UK) with an excitation source wavelength of 532 nm and a fluorescence spectrometer with an excitation wavelength of 478 nm (DeltaFlex, HORIBA), the fitting curve of TRPL results were led by the bi-exponential decay function: A1τ1 + A2τ2 τave = A1 + A2<sup>.Thephotoluminescencequantumyield(PLQY)ofthe</sup> corresponding film was measured on QuantaMaster 8000 (HORIBA, Canada) with a 532 nm laser to photoexcite the samples placed in an integrating sphere. 

#### Device characterization 

The current density‒voltage (J‒V) curves of the single and tandem devices were measured by Keithley 2400 source under standard AM1.5 G simulated sunlight (Oriel Class AAA, XES-160S1, SAN-EI ELECTRIC CO., LTD., Japan). The active area of small-area devices was determined by the black masks of 0.0871 cm<sup>2</sup> and the aperture area of mini-module is 11.3 cm<sup>2</sup> . The EQEtandem spectra were obtained in ambient air without bias voltage and the bias illumination from LEDs with emission peaks of 850 nm and 460 nm, which were respectively used for the front and back cells. The corresponding DC mode was adopted by the Newport EQE system (Newport, USA) using monochromatic light of 1×10<sup>16</sup> photons cm<sup>−2</sup> , which was also conducted to measure the EQE spectra of the single junction. The light intensitydependent VOC was measured under different light intensities, and the plots were shown in a logarithm scale. For the electric properties of ideal-bandgap PSCs, the electrochemical impedance spectroscopy (EIS) results, Mott-Schottky (M-S) plots, transient photovoltage decay (TPV), and transient photocurrent decay (TPC) plots, were obtained by a CHI1000c multichannel electrochemistry workstation (Zahner, Germany), the results of Mott-Schottky plots were shown by the equation: C1<sup>2=</sup> 2Að<sup>2</sup> Vq biεε�0VNÞ<sup>, Where V is the applied potential, A is the active</sup> area of the device, C is the capacitance, and the value of ε, ε0, q and N is relative permittivity, vacuum permittivity, elementary charge and charge concentration, respectively. Also, external electroluminescence quantum efficiency (EQEEL) measurement was measured on ELCT-3010 (Enlitech Co., Ltd.). 

###### 1H NMR and FTIR analysis 

1H NMR spectra were recorded on a Bruker AscendTM 600 MHz spectrometer. The FTIR spectra were obtained by Nicolet iS50R FTIR spectrometer (Thermo Scientific Co., America) 

#### DFT calculations 

Density functional theory (DFT) calculations were performed by using the Vienna ab initio simulation package (VASP)<sup>46</sup> . The generalized gradient approximation (GGA) with the Perdew-Burke-Emzerhof (PBE) functional was utilized to describe the exchange-correlation energy<sup>47</sup> . Projector augmented wave (PAW) methods were employed for the pseudopotentials<sup>48</sup> . The energy cutoff for the plane-wave basis was 

Nature Communications |  (2024) 15:7335 

8 

Article 

https://doi.org/10.1038/s41467-024-51703-0 

450 eV, and the convergence threshold for geometry relaxation was 10<sup>−4</sup> eV in energy and 0.02 eV Å<sup>−1</sup> in force. The first Brillouin zone for the energy band calculation was performed using 3 × 3 × 1 k-point meshes. Molecules were simulated in a 3 × 3 × 2 supercell of FASnI3 perovskite to ensure negligible interactions between neighboring cells. A vacuum layer with a thickness of 20 Å was used to model the structure of perovskite. 

#### Reporting summary 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

## Data availability 

The data that support the findings of this study are available in the Supplementary Information/Source Data file. Source data are provided with this paper. 

## References 

1. Best Research-Cell Efficiencies. National Renewable Energy Laboratory, www.nrel.gov/pv/cell-efficiency.html (2024). 

2. Leijtens, T., Bush, K. A., Prasanna, R. & McGehee, M. D. Opportunities and challenges for tandem solar cells using metal halide perovskite semiconductors. Nat. Energy 3, 828–838 (2018). 

3. Green, M. A. A. et al. Solar cell efficiency tables (Version 64). Prog. Photovolt. Res. Appl. 32, 425–441 (2024). 

4. Chen, H. et al. Regulating surface potential maximizes voltage in allperovskite tandems. Nature 613, 676–681 (2023). 

5. Datta, K. et al. Monolithic all-perovskite tandem solar cells with minimized optical and energetic losses. Adv. Mater. 34, 2110053 (2022). 

6. Lin, R. et al. All-perovskite tandem solar cells with improved grain surface passivation. Nature 603, 73–78 (2022). 

7. Lin, R. et al. All-perovskite tandem solar cells with 3D/3D bilayer perovskite heterojunction. Nature 620, 994–1000 (2023). 

8. Dong, H. et al. Crystallization dynamics of Sn‐based perovskite thin films: Toward efficient and stable photovoltaic devices. Adv. Energy Mater. 12, 2102213 (2021). 

9. Liang, Z. et al. A selective targeting anchor strategy affords efficient and stable ideal-bandgap perovskite solar cells. Adv. Mater. 34, 2110241 (2022). 

10. Chen, L. et al. Incorporating potassium citrate to improve the performance of tin‐lead perovskite solar cells. Adv. Energy Mater. 13, 2301218 (2023). 

11. Wang, J. et al. Enhancing photostability of Sn‐Pb perovskite solar cells by an alkylammonium pseudo‐halogen additive. Adv. Energy Mater. 13, 2204115 (2023). 

12. Hu, S. et al. Synergistic surface modification of tin-lead perovskite solar cells. Adv. Mater. 35, 2208320 (2022). 

13. Maxwell, A. et al. All-Perovskite tandems enabled by surface anchoring of long-chain amphiphilic ligands. ACS Energy Lett. 9, 520–527 (2024). 

14. Luo, J. et al. Improved carrier management via a multifunctional modifier for high-quality low-bandgap Sn-Pb perovskites and efficient all-perovskite tandem solar cells. Adv. Mater. 35, 2300352 (2023). 

15. Li, H. et al. Surface reconstruction for tin-based perovskite solar cells. ACS Energy Lett. 7, 3889–3899 (2022). 

16. Fu, S. et al. Polishing the lead-poor surface for efficient inverted CsPbI3 perovskite solar cells. Adv. Mater. 34, 2205066 (2022). 

17. Marino, C. et al. Study of the electrode/electrolyte interface on cycling of a conversion type electrode material in Li batteries. J. Phys. Chem. C. 117, 19302–19313 (2013). 

18. Zhu, Z. et al. Correlating the perovskite/polymer multi-mode reactions with deep-level traps in perovskite solar cells. Joule 6, 2849–2868 (2022). 

19. Li, N. X. et al. Liquid medium annealing for fabricating durable perovskite solar cells with improved reproducibility. Science 373, 561–567 (2021). 

20. Zhou, J. et al. Dual cross‐linked functional layers for stable and efficient inverted perovskite solar cells. Sol. RRL 7, 2300230 (2023). 

21. Yang, T. et al. One-stone-for-two-birds strategy to attain beyond 25% perovskite solar cells. Nat. Commun. 14, 839 (2023). 

22. Liu, Y. et al. Defect passivation and lithium ion coordination via hole transporting layer modification for high performance inorganic perovskite solar cells. Adv. Mater. 36, 2306982 (2024). 

23. Kim, H. et al. Proton-transfer-induced 3D/2D hybrid perovskites suppress ion migration and reduce luminance overshoot. Nat. Commun. 11, 3378 (2020). 

24. Zong, Y. et al. Thin‐film transformation of NH4PbI3 to CH3NH3PbI3 perovskite: a methylamine‐induced conversion–healing process. Angew. Chem. Int. Ed. 55, 14723–14727 (2016). 

25. Zhou, Z. et al. Methylamine-gas-induced defect-healing behavior of CH3NH3PbI3 thin films for perovskite solar cells. Angew. Chem. Int. Ed. 54, 9705–9709 (2015). 

26. Jiang, X. et al. Surface heterojunction based on n-type low-dimensional perovskite film for highly efficient perovskite tandem solar cells. Natl Sci. Rev. 11, nwae055 (2024). 

27. Wei, M. et al. Combining efficiency and stability in mixed tin-lead perovskite solar cells by capping grains with an ultrathin 2D layer. Adv. Mater. 32, 1907058 (2020). 

28. Wu, W.-Q. et al. Bilateral alkylamine for suppressing charge recombination and improving stability in blade-coated perovskite solar cells. Sci. Adv. 5, eaav8925 (2019). 

29. Liu, C. et al. Bimolecularly passivated interface enables efficient and stable inverted perovskite solar cells. Science 382, 810–815 (2023). 

30. Hu, S. et al. Optimized carrier extraction at interfaces for 23.6% efficient tin–lead perovskite solar cells. Energy Environ. Sci. 15, 2096–2107 (2022). 

31. Huang, Y. et al. Finite perovskite hierarchical structures via ligand confinement leading to efficient inverted perovskite solar cells. Energy Environ. Sci. 16, 557–564 (2023). 

32. Xu, W. et al. Rational molecular passivation for high-performance perovskite light-emitting diodes. Nat. Photonics 13, 418–424 (2019). 

33. Chen, R. et al. Reduction of bulk and surface defects in inverted methylammonium- and bromide-free formamidinium perovskite solar cells. Nat. Energy 8, 839–849 (2023). 

34. Stolterfoht, M. et al. The impact of energy alignment and interfacial recombination on the internal and external open-circuit voltage of perovskite solar cells. Energy Environ. Sci. 12, 2778–2788 (2019). 

35. Kamarudin, M. A. et al. Suppression of charge carrier recombination in lead-free tin halide perovskite via lewis base post-treatment. J. Phys. Chem. Lett. 10, 5277–5283 (2019). 

36. Kapil, G. et al. Tin‐lead perovskite fabricated via ethylenediamine interlayer guides to the solar cell efficiency of 21.74%. Adv. Energy Mater. 11, 2101069 (2021). 

37. Hu, M. et al. Regulating the surface passivation and residual strain in pure tin perovskite films. ACS Energy Lett. 6, 3555–3562 (2021). 

38. Zhang, H. & Park, N. G. Strain control to stabilize perovskite solar cells. Angew. Chem. Int. Ed. 61, 202212268 (2022). 

39. Liu, S. et al. Boost the efficiency of nickel oxide-based formamidinium-cesium perovskite solar cells to 21% by using coumarin 343 dye as defect passivator. Nano Energy 94, 106935 (2022). 

40. Meng, X. et al. Effective inhibition of phase segregation in wide‐ bandgap perovskites with alkali halides additives to improve the stability of solar cells. Sol. RRL 7, 2201099 (2023). 

41. Li, Z. et al. Stabilized hole-selective layer for high-performance inverted p-i-n perovskite solar cells. Science 382, 284–289 (2023). 

Nature Communications |  (2024) 15:7335 

9 

Article 

https://doi.org/10.1038/s41467-024-51703-0 

42. Ren, A. et al. Efficient perovskite solar modules with minimized nonradiative recombination and local carrier transport losses. Joule 4, 1263–1277 (2020). 

43. Peng, W. et al. Reducing nonradiative recombination in perovskite solar cells with a porous insulator contact. Science 379, 683–690 (2023). 

44. Ye, F. et al. Overcoming C60-induced interfacial recombination in inverted perovskite solar cells by electron-transporting carborane. Nat. Commun. 13, 7454 (2022). 

45. Zhang, Z. et al. Revealing superoxide-induced degradation in leadfree tin perovskite solar cells. Energy Environ. Sci. 15, 5274–5283 (2022). 

46. Kresse, G., Furthmuller, J. & Hafner, J. Theory of the crystal structures of selenium and tellurium: The effect of generalized-gradient corrections to the local-density approximation. Phys. Rev. B: Condens. Matter 50, 13181–13185 (1994). 

47. Perdew, J. P. et al. Atoms, molecules, solids, and surfaces: Applications of the generalized gradient approximation for exchange and correlation. Phys. Rev. B: Condens. Matter 46, 6671–6687 (1992). 

48. Valiev, M. & Weare, J. H. The projector-augmented plane wave method applied to molecular bonding. J. Phys. Chem. A 103, 10588–10601 (1999). 

## Acknowledgements 

W.C. acknowledge the financial support from the Innovation Project of Optics Valley Laboratory (OVL2021BG008), the Ministry of Science and Technology of China (2021YFB3800104), the National Natural Science Foundation of China (U20A20252). Z.L. acknowledge the National Natural Science Foundation of China (52002140), the Young Elite Scientists Sponsorship Program by CAST, the Natural Science Foundation of Hubei Province (2022CFA093), the Self-determined and Innovative Research Funds of HUST (2020kfyXJJS008). J.W. acknowledge the Fundamental Research Funds for the Central Universities, HUST (2023JYCXJJ041). R.C. acknowledge the China Postdoctoral Science Foundation (2023M731172). X.Q. acknowledge the Scientific Research Foundation of China Huaneng Group (HNKJ21-H26, CERI/TG-24-CERI01). The authors thank the Analytical and Testing Center of HUST for the facilities’ support of sample measurements. 

## Author contributions 

Y.P., J.W. contributed equally to this work. Y.P., J.W., Z.L. and W.C. conceived the project and designed the experiments. Y.P., J.W., Z.S., J.Z., and C.S. were involved in all the experimental parts. Y.P., J.W., Z.S., 

J.Z., Zheng Z., C.S., S.L., F.R., R.C., Y.C., H.S., Z.L. and W.C. co-wrote the paper. B.L., Zhongyong Z., Zhengjing Z., Z.C., X.Q., Zhiguo Z., Y.J., N.L., and W.H. contributed materials and analysis tools. W.C. and Z.L. directed and supervised this project. All authors discussed the results and commented on the manuscript. 

## Competing interests 

The authors declare no competing interests. 

## Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-024-51703-0. 

Correspondence and requests for materials should be addressed to Zonghao Liu or Wei Chen. 

Peer review information Nature Communications thanks Bin Chen, Zhaoning Song, and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. A peer review file is available. 

##### Reprints and permissions information is available at 

http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License, which permits any non-commercial use, sharing, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if you modified the licensed material. You do not have permission under this licence toshare adapted material derived from this article or parts of it. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http:// creativecommons.org/licenses/by-nc-nd/4.0/. 

##### © The Author(s) 2024 

Nature Communications |  (2024) 15:7335 

10 

