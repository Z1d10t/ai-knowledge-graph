# Prospects challenges and stability of 2D MXenes for clean energy conversion and storage applications

| 字段 | 内容 |
|---|---|
| 期刊 | npj 2D Materials and Applications |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 328 |
| 作者 | Anha Bhat, Shoaib Anwer, Kiesar Sideeq Bhat, M. H. Mohideen, K. Liao, Ahsanulhaq Qurashi |
| DOI | 10.1038/s41699-021-00239-8 |
| 源文件 | 052_Bhat_2021_Prospects-challenges-and-stability-of-2D-MXenes.pdf |

---
www.nature.com/npj2dmaterials 

## REVIEW ARTICLE **OPEN** 



# Prospects challenges and stability of 2D MXenes for clean energy conversion and storage applications 

Anha Bhat<sup>1,6</sup> , Shoaib Anwer 2,6, Kiesar Sideeq Bhat3, M. Infas H. Mohideen 4, Kin Liao2,5 and Ahsanulhaq Qurashi4 ✉ 

Two-dimensional materials have gained immense attention for technological applications owing to their characteristic properties. MXene is one of the fast-growing family of 2D materials that exhibits remarkable physiochemical properties that cater numerous applications in the field of energy and storage. This review comprises the significant advancement in the field of 2D MXene and discusses the evolution of the design, synthetic strategies, and stability. In addition to illuminating the state-of-the-art applications, we discuss the challenges and limitations that preclude the scientific fraternity from realizing functional MXene with controlled structures and <mark>p</mark> ro <mark>p</mark> erties for renewable clean ener <mark>gy</mark> conversion and stora <mark>g</mark> e a <mark>pp</mark> lications. 

n <mark>pj</mark> 2D Materials and A <mark>pp</mark> lications (2021) 5:61 ; htt <mark>p</mark> s://doi.or <mark>g</mark> /10.1038/s41699-021-00239-8 

### INTRODUCTION 

The research interest in 2D type materials originated with the graphene discovery<sup>1</sup> along with its rich physics has been the motivating factor to extend the research to vast planar materials like boron nitride<sup>2</sup> and transition metal dichalcogenides (TMDCs)<sup>3</sup> prepared by exfoliating the 3D bulk to 2D planer structures stacked with weak Van der Waals interactions. The 2D materials possess exceptional electronic, mechanical, and optical properties<sup>4–9</sup> , which, in the past decade, have eventually paved the way to its deep root research for diverse applications. These materials also demonstrate as essential basic building units for a wide range of material applications including a layer by layer structures, membranes, and mixed composites<sup>10</sup> . Although many 2D materials possessing a single element have been synthesized, some examples include graphene, silicene<sup>11</sup> , germanene<sup>12,13</sup> , and phosphorene<sup>14,15</sup> , where most of them contain two (such as dichalcogenides and oxides)<sup>16,17</sup> or more than two elements (such as clays)<sup>4</sup> . The addition to the family are the carbides and/or nitrides of a transition metal, termed as MXenes, which were discovered by Gogotsi et al. in 2011<sup>18</sup> . The intense scientific research in this field has directed towards the fast development of numerous synthesized compositions. Since then, an increasing number of about 30 MXene-based compositions are reported (noticeable with blue color in Fig. 1), and several others have been surveyed through computational means (noticeable with the gray color in Fig. 1)<sup>19</sup> . 

The introduction of two transition metals into MXenes imparts distinctive features in the MXene structure. The double transition metals form solid solutions, for example (Ti, Nb)CTx (noticeable with green color in Fig. 1). In addition, the transition metals can also build a single flake of 2D MXene with ordered structures, both by building transition metals atomic sandwiches like Mo2TiC2Tx, or in-plane well-ordered structures like (Mo2/3Y1/3)2CTx. However, in 2014 the ordered MXenes were synthesized and updated in 2015<sup>20</sup> , and several MXene composites have been prepared recently (noticeable with red color in Fig. 1). Scientists have developed many ordered double transition metal MAX phases since 2017 and have rigorously exploited their characteristic 

properties, including magnetic behavior<sup>21–23</sup> . Recently with computational findings on MXenes and their precursor derivatives have estimated numerous possible MXene frameworks<sup>23–27</sup> . A huge number of non-stoichiometric MXenes, with finely tuned properties and mixed transition metals or carbon nitrides, can be synthesized by the creation of solid solutions on M and X sites<sup>28</sup> . Currently, researchers attempt to generate and include additional X elements to 2D boride systems. The carbides, carbonitrides, and nitrides are having hydrophilic surfaces due to the termination of groups such as hydroxyl, fluorine, and oxygen<sup>27,29,30</sup> . They can be turned into films, devices, and coatings because of easy processing and least required stabilization<sup>31–33</sup> . The MXenes are predicted to have intriguing electronic and thermoelectric properties<sup>34–36</sup> , with an optical bandgap of 0.9 eV for oxygen-terminated Ti2C<sup>18,29</sup> . But Ti3C2Tx MXene shows high metallic conductivity while Mo2CTx and Mo2TiC2Tx show semiconductor behavior<sup>28,37</sup> . Due to various combinations and surface terminations, many members of the family are yet to be explored. It also paves the way to explore the ion dynamics between the MXene layers and their possible replacement for electrolytic capacitors which incidentally would increase the voltage window and upgrade the storage level and cycle life<sup>38</sup> . This review has laid its emphasis on providing a bird-eye view on the MXene science. It focuses on structural design and preparation features of MXenes and includes their application from energy storage devices i.e., microsupercapacitors (m-SCs) and batteries to electrochemical catalysts applicable in both hydrogen production reactions and reactions involving oxygen reduction. 

### SYNTHESIS, STRUCTURE, AND PROPERTIES 

The MXenes constitute a family of over 60 members belonging to multilayered and hexagonal geometric metal nitrides, carbides, or carbonitrides like titanium carbides<sup>39</sup> , molybdenum carbides<sup>40</sup> , tungsten carbides<sup>41</sup> , titanium nitrides<sup>42</sup> , tungsten nitrides, molybdenum nitrides<sup>43</sup> , vanadium nitrides<sup>44</sup> , and the combinations of metal carbides and nitrides<sup>45</sup> . MXenes are derived either from inorganic ternary carbides or from nitrides, generally known as 

> 1Department of Electronic Materials Engineering, Australian National University, Canberra, NSW, Australia. 2Department of Mechanical Engineering, Khalifa University, Main Campus, Abu Dhabi, United Arab Emirates.<sup>3</sup> School of Chemical and Biomedical Engineering, Nanyang Technical University, Singapore, Singapore.<sup>4</sup> Department of Chemistry, Khalifa University, Main Campus, Abu Dhabi, United Arab Emirates.<sup>5</sup> Department of Aerospace Engineering, Khalifa University, Abu Dhabi, United Arab Emirates.<sup>6</sup> These authors contributed equally: Anha Bhat, Shoaib Anwer.<sup>✉</sup> email: ahsanulhaq06@gmail.com 

Published in partnership with FCT NOVA with the support of E-MRS 

A. Bhat et al. 

2 



Fig. 1 Different compositions of MXene reported to date. The theoretical (depicted in gray), as well as experimental (depicted in blue) MXenes that have been explored, are included in this table. The top 1st row represents the Mono-M structures of MXenes; the 2nd row represents solid solutions (SS) with Double-M, and their corresponding composition is depicted in green color. The 3rd row represents the ordered Double-M MXenes, and their corresponding compositions are shown in red. The 4th row is an ordered divalent structure, investigated only for M2C MXenes, resulting in M1.33 C MXene due to ∼33 atomic vacancies in its M layers, and their corresponding compositions are shown in pink. Reprinted with permission from ref.<sup>18</sup> . 

MAX phases, here M signifies the early transition metal; A represents an A-group element (usually group IIIA or IVA), X represents carbon and/or nitrogen atom and the value of n can be 1–4<sup>38,46,47</sup> . It has been quite difficult to isolate the Mn+1Xn layers from MAX phases by mechanical shearing due to strong metallic nature of M–A bond. However, by treatment of more chemically active M–A bonds compared to the stronger M–X bonds, prompts to etch A layers selectively. The etching of A layers with high selectivity is the key point for MXene production. The synthesis of MXenes from parent MAX phases by selectively etching A layers is demonstrated in Fig. 2a, b<sup>48,49</sup> . Numerous MXenes can be generated at room temperature to 55 °C while optimizing the time of reaction and concentration of HF as demonstrated in Fig. 2c–e. A multilayered ternary carbide (MAX powder, here, M3AC2) was mixed with an acidic solution of HF (for example, HCl-LiF) to produce multilayered M3C2Tx MXenes. In this process, the A layer (such as aluminum) was selectively etched out and surface groups were terminated with hydroxyl groups, oxygen atoms, or fluorine terminations (Tx). Inclusion of water molecules, cations, dimethylsulfoxide (DMSO), Tetrabutylammonium hydroxide (TBAOH), etc. into the interlayer spacing, pursued by sonochemical treatment delaminates and generates single flake MXene dispersions. The condition of etching of Al-containing MAX phases differs among different transition metals due to the variable structure, size, and bonding of the material. HF possesses very high and selective etching behavior with the capability to remove selectively different SiC polytypes<sup>50</sup> . It has been experimentally found that an increase in the atomic number of M needs a longer time and strong etching, it could be associated with M-Al metallic bonding. Acknowledging that the M-Al bonding nature is metallic, we assume that a larger number of M valence electrons requires stouter etching<sup>48,49</sup> . In general, the quality of MXene in terms of 

surface chemistry and concentration of structural defects can be produced under distinct etching conditions. The Al atoms were etched using aqueous HF in layered hexagonal ternary carbide Ti3AlC2 producing the first MXene Ti3C251. This happened to be the first member discovered of an approximate 70 member family with generic formula Mn+1AXn where the M, A, X are the likes of the combinations of (Mo2Ti)AlC2, Ti3(Al0.5Si0.5)C2, Ti2Al(C0.5N0.5) expelling the A (IIIA or IVA) atoms leaving behind the layers of metal carbide of Mn+1Xn arrangement<sup>52</sup> . The unit cell packing is such that X atoms fill up the octahedral positions packed with M atoms giving rise to the arrangements abiding the formula Mn +1<sup>X</sup> n<sup>interruptedbyAatoms53.Thereisadifferenceinthe</sup> bonding nature of M–X and M–A, the former being ionic or covalent while the latter being purely metallic which makes A more prone to etching, and the distance between the M–A and M–X makes the difference rendering them strong or relatively weak based on the distance<sup>48</sup> . 

There are various terminations functional groups such as –F, –OH, –O in MXenes after the exfoliation from the MAX phases. The F-terminated MXenes are not stable as the F group gets rinsed by washing just adding the O<sup>−</sup> or OH termination. The OH termination change to O on metal adsorption processes or exposure to high-temperature treatments<sup>38</sup> . The etching conditions are necessary to complete the MAX phase conversion to MXenes. Several improvements are being made on that front and the worthy to mention is the proposed use of soft etchant ammonium bifluoride, NH4HF2, in place of HF. The delamination process of MXenes witnesses the simultaneous etching and intercalation thereby giving rise to the reaction below (1). In this reaction, the atomic layers of Ti3C2Tx are more uniformly spaced and stacked nearby due to the intercalation of both NH3 and NH4+ 55. 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 61 

A. Bhat et al. 

3 



Fig. 2 The synthesis of MXenes from parent MAX phases. a The different structures of MAX phases and the respective MXenes. Reprinted with permission from<sup>48</sup> . b Schematic description of MXene synthesis procedure from MAX phases. a, b reprinted with permission from<sup>54</sup> ACS Nano 2012, 6, 1322-1331 Publication Date: January 26, (2012) https://doi.org/10.1021/nn204153h Copyright (2012) American Chemical Society; (c–e) Preparation and morphological characterization of MXenes. c Showing images of MAX structures (such as M3AC2). From left-side to rightside: graphical illustration of the basic atomic structure, optical image of powder Ti3AlC2 source, low and high magnified FESEM micrographs of Ti3AlC2 flake, and high-resolution TEM (HRTEM) image of Mo2TiAlC2. d Showing images of multilayered MXene. From left to right: graphical illustration of the basic atomic structure, optical image of Ti3C2Tx powder, low and high-resolution FESEM images of Ti3C2Tx and HRTEM image of Mo2TiC2Tx. e Showing images of final exfoliated MXene. From left-side to right-side: schematic illustration of the basic atomic structure, optical images of 400 ml of exfoliated Ti3C2Tx in water, an optical image of the Mo2TiC2Tx MXene film formed by vacuum filtration, a crosssectional FESEM image of the Mo2TiC2Tx MXene film, and a single-layer HRTEM image of the Ti3C2Tx flake. Reprinted with permission from<sup>19</sup> . 

Ti3AlC2 + 3NH4HF2 = (NH4)3AlF6 + 3/2H2 + Ti3C2 (1) Ti3C2 + aNH4HF2 + bH2O = (NH3)c (NH4)d Ti3C2(OH)xFy (2) 

Another efficient method of improving the yield of Ti3C2TxMXene is by dissolving Ti3AlC2 powder in a mixture of LiF and HCl solution, supported by heating at 40 °C for long hours (45 h), and subsequently washing the solid sediment and increasing the pH. The as-prepared clay type structure is rolled into free-standing flexible films with high volumetric capacitance<sup>56</sup> . MXene sheets prepared by LiF/HCl method possess defect-free features and larger lateral sizes compared to HF-etched samples<sup>57</sup> . The MXenes like Tin+1Xn, are known to be metallic and this characteristic diminishes as the additional bonds of Ti–X are formed. Titanium nitrides exhibit more metallic properties due to extra electrons on the N atom than the carbon atom on the titanium carbides<sup>58–60</sup> . The terminated MXenes like Hf2CO2, Zr2CO2, Sc2C(OH)2, Sc2CO2, Ti2CO2, and Sc2CF2 have narrow bandgaps and they need tuning of electronic structure to be applicable in optoelectronics<sup>61</sup> . 

Figure 3a depicts the schematic representation of etching steps with the elimination of the Al layers, which is pursued by the inclusion of hydrated lithium ions. In this procedure results bulging of Ti3C2 sediment occurs, as represented in Fig. 3b. Asprepared different concentrations (10–30 mg/mL) of Ti3C2 slurries in glass vials are shown in Fig. 3c, here solutions with high concentration (i.e., 20 and 30 mg mL<sup>−1</sup> ) adhere more strongly to the glass vials. Moreover, besides the high concentration of MXene inks, the MILD method helps to prepare high-quality and larger MXene flakes, showing enhanced electronic properties<sup>62</sup> . The differences between Ti3C2 ink sediment and the Ti3C2 (delaminated) supernatant suspension were quantified by using dynamic light scattering, electrophoretic mobility description along with particle size as well as zeta potential analysis. The high negative ζ-potential value was observed in the stability area 

below −30 mV for both the Ti3C2 supernatant (at pH 5.16) and the Ti3C2 ink sediment (at pH 5.89) as shown in Fig. 3d. It was observed from the particle size that the polydispersity index of 0.472 with the distribution of peak positions at ≈1.5 µm (86.7%), ≈4.7 µm (9.6%), and 0.3 µm (3.6%) was revealed by delaminated supernatant. However, the ink sediment showed a polydispersity of 0.549 with a mixture of larger flakes and many-layered nanostructures exhibiting two distribution peaks near ≈8.3 µm (66.3%) which is intense, and at ≈1.1 µm (33.7%) which is similar to the delaminated supernatant peak. In addition, different concentrations of water-based MXene inks filled in pen cartridges to fabricate MXene Pens as demonstrated in Fig. 3e. 

Water-based MXene inks can be applied in various deposition techniques based on the demand as shown in Fig. 3f–i. These water-based inks can easily be brush painted (f), stamping with higher concentrations of MXene inks i.e., 20–30 mg mL<sup>−1</sup> (g)<sup>63</sup> , printing at a concentration of 1 mg mL<sup>−1</sup> (h), direct writing using a simple rollerball pen filled with MXene ink with the concentration of 30 mg mL<sup>−1</sup> (i). Ti3C2 printing on paper demonstrates the feasibility of applying MXene inks for fabricating functional devices on paper substrate. However, for printing applications, certain parameters such as stability and the rheology of ink need to be well optimized. Figure 3j–n demonstrates that the MXene inks in rollerball pens can be applied to a multitude of surfaces by direct writing. The written patterns on the paper show good stability, better adhesion after folding, also long-term storage. 

### CLEAN ENERGY CONVERSION AND ROLE OF MXENES INK FOR PRINTABLE ELECTRONICS AND FLEXIBLE ENERGY STORAGE DEVICES 

MXenes possess exceptional combinatorial properties, such as higher electrical properties and mechanical behavior of carbides/ 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 61 

A. Bhat et al. 

4 



Fig. 3 Additive-free water-based MXene ink preparation. a schematic illustration of the MILD etching method using LiF/HCl at 35 °C for 24 h, b Ti3C2 sediment swelling during washing step, c different concentrations of MXene inks in glass vials, and d Zeta potential of the Ti3C2 Mxene, e optical images of rollerball pen images for direct writing of Ti3C2 inks., Water-based MXene inks for prototype fabrication: f painting, g stamping, h printing, and i writing of Ti3C2 on a paper substrate, respectively. j MXene has written on different substrates, k drawing apparatus (AxiDraw) with automatic set-up and patterning controlled with a computer, l Ti3C2 ink lines fabricated at different speeds pen writing, m versatile MXene ink patterning with AxiDraw, and n demonstration showing MXene inks portraying patterns onto even fruit surface. Reprinted with permission from<sup>64</sup> . 

nitrides of transition metals; functional groups at the surfaces making them hydrophilic and prone to bonding with different chemical species; comparatively higher negative zeta potential, ability to form and remain stable in aqueous suspensions; and electromagnetic wave absorption with high efficiency. These ubiquitous properties paved the way for a huge number of potential applications. Applications of MXenes have exclusively presented as the circular pie chart in Fig. 4<sup>65</sup> . The first and the most explored MXenes applications remained dedicated to energy storage. The exploitation of MXenes in the biomedical research arenas, although only recently explored, has evolved as one of the emerging study areas, focusing on photothermal cancer therapy, biosensors, theranostics, neural electrodes, and dialysis<sup>65,66</sup> . Another field for MXene being dominant over other nanostructures is electromagnetic applications which include electromagnetic shielding interference and printed antennas<sup>67</sup> . The research work in other fields, such as electronic and structural applications, 



Fig. 4 Applications of MXenes. The circular pie chart demonstrates the proportion of published work within apiece explored characteristic for MXenes application. 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 61 

A. Bhat et al. 

5 

is progressively being studied theoretically as well as experimentally. Many predicted characteristic properties of MXenes such as topological insulators or ferromagnetism, have yet to be investigated and validated experimentally. These nanoelectronics applications give a clear indication that MXene is establishing another crucial 2D material that can attract significant attraction in the portable electronics industry in near future. Generally, the applications of MXene are more predominant in the area of energy conversion devices and storage<sup>68</sup> . 

Mo2CTx MXene plays a very important role as active and conductive support to assist electron transfer for HER catalysis<sup>69,70</sup> . The preparation and thorough structural investigation of the Mo2CTx MXene matrix encapsulated by MoS2 was implemented by Yu et. al<sup>71</sup> . By hydrothermal technique, they combined the MoS2@Mo2CTx hybrids (see Fig. 5a–c) to increase the HER performance in alkaline medium. MoS2@Mo2CTx nanohybrids exhibited significantly increased activity of hydrogen evolution reaction (HER) with a low overpotential of 176 mV at the current density of 10 mA cm<sup>−2</sup> and a very low transfer resistance of 26 Ω as compared to the parent Mo2Ga2C, Mo2CTx and MoS2 catalysts which exhibited much higher overpotentials of 897, 533 and 394 mV, respectively in alkaline medium. This synthesis strategy and designed approach showed that by preparing organ-like molybdenum carbide combined with MoS2 nanoflowers, it is possible to tailor the properties of MXenes for the desired application. It is found that substitution of the mid-to-late transition metals of group III-VI within the host MXene matrix significantly improves the catalytic efficiency and results in relatively stable MXenes<sup>72</sup> . Kuznetsov et al.<sup>73</sup> prepared cobaltincorporated molybdenum carbide (Mo2CTx: Co) MXene by intercalation of gallium yielding Mo2Ga2C: Co lagged by removal of Ga through HF treatment. Simulation studies performed via density functional theory (DFT) calculations revealed that a small quantity of Co in the Mo2CTx host lattice (Fig. 5d, e) imparts a substantial perturbation in the electronic structure of Mo2CTx: Co. The replacement of Mo by Co influences the adsorption energies of hydrogen on the adjacent oxygen atoms of oxygen-terminated Mo2CO2:Co surface, constructing these sites more promising for HER catalysis. Urbankowski et al.<sup>42</sup> (Fig. 5f) reported the first type of 2D transition metal nitride MXene (Ti4N3Tx). Instead of following the traditional MXene synthesis methods, they used a melted fluoride salt to etch Al from a Ti4AlN3 powder at 550 °C in an Argon atmosphere in contrast to etching of MAX phase in aqueous acidic medium. TBAOH was further used to delaminate the subsequent MXene to yield few-layered and monolayers of Ti4N3Tx, where T is a surface termination (F, O, or OH). Produced Ti4N3 was anticipated to be metallic. The simulation study results based on DFT revealed that compare to terminated Ti4N3Tx, bare, non-terminated Ti4N3 have the highest density of states, as well as a magnetic moment of 7.0 µB per unit cell. Later, Djire et al.<sup>74</sup> reported the optical, electrical, and electrocatalytic properties of the 2D Ti4N3Tx and proved that Ti4N3Tx MXene exhibits both metallic and semiconducting behaviors. Specifically, when tested as an electrocatalyst for the hydrogen evolution reaction, the exfoliated Ti4N3Tx presented an overpotential of ∼300 mV at −10 mA cm<sup>−2</sup> and a Tafel slope of ∼190 mV dec<sup>−1</sup> . These potential findings reveal the interesting optical, electrocatalytic, and electrical properties of Ti4N3Tx MXene that extend the potential of these materials into electrocatalysis and optoelectronic applications. Xie et al. found that when metallic Ti3C2Tx MXene flakes are self-assembled with positively charged CNTs as spacers, see in Fig. 5g, h, this 2D/1D combination, when compared to MXene/graphene - 2D/2D films give rise to the much efficient porous structure by interrupting the ordered stacking which aids the MXenes to access the electrolyte. The MXenes/CNT papers demonstrated good rate capability, long cyclic performance, and high volumetric capability due to the formation of the conductive net with effective restacking<sup>75</sup> . Many of these carbides and nitrides have found their applications in 

various clean energy-related areas ranging from batteries, electrode materials, hydrogen evolution, and water splitting. MXene and its nanocomposites and heterostructures are very well explored for HER applications. However, due to its fast oxidation in an aqueous environment, bare MXene is not yet proved as a potential OER electrocatalyst. However, when MXene is combined with other OER active layered double hydroxide catalyst materials i.e. Ni1-x FexPS376,<sup>CoFe77,orwithblack</sup> phosphorus quantum dots<sup>78</sup> , it showed a significant OER performance. The improved OER performance was credited to the synergistic effect of active catalysts materials and the metallic conductivity of 2D MXene. Characteristically, MXene is used as a support due to its large surface area and functional group enrich surface, with other OER active hybrid composites<sup>79</sup> . 

The MXenes find their application in clean energy technologies as well. The parent ternary carbides Mo2Ga2C and Ti2AlC produce MXenes like Mo2CTx and Ti2CTx by HF etching, on removing Ga and Al atoms<sup>80</sup> . The electrochemical activities were demonstrated by three-electrode electrochemical cells which had MXenes drop cast on the glassy carbon electrode. As shown in Fig. 6a the more potential HER catalyst at an overpotential of 283 mV was found to be Mo2CTx attaining a current density of about 10 mA cm<sup>−2</sup> . On the other hand, the Ti2CTx MXene showed comparatively less performance at the overpotential of 609 mV to realize the current density of 10 mA cm<sup>−2</sup> . The HER activity of Ti2CTx decreases further predicting instability as compared to Mo2CTx which undergoes only a slight initial reduction, but later maintains a stable HER, reaching 10 mA cm<sup>−2</sup> at an overpotential of 305 mV. As demonstrated in Fig. 6b, no critical change in overpotential was noticed for either Mo2CTx or Ti2CTx, corresponding XPS in Fig. 6c shows the investigated changes in the chemical state of Mo2CTx before and after HER performance. 

The oxygen reduction reaction (ORR) is a crucial phenomenon when it comes to energy conversion devices. The ORR is a ratelimiting step in the case of proton exchange membrane fuel cells, to generate electricity and determine the performance of the cell. The ideal ORR catalysts are usually Pt-based alloys despite having good catalytic performance, face the limitation of instability and CO poisoning. To combat this, a range of nano dimensional carbides like Mo2C, WC, and V8C have shown increased HER activity while Mo2C, V8C7, and Cr3C2 have shown ORR activity and could be used as cost-effective replacements as demonstrated by Regmi et al.<sup>82</sup> . Using first-principles calculations Liu et al.<sup>81</sup> theoretically investigated the impacts of surface termination groups of MXenes that crucially influence the ORR performance. The properties of various surfaces are explained by thorough computational examinations of the geometries, charges, and their electronic structures. The F-ended surfaces are anticipated to exhibit a superior activity for ORR yet with an inferior stability than the O-ended equivalents (Fig. 6d). The volcano plot in Fig. 6e shows the calculated performance of ORR on different surfaces. The projected theoretical overpotential (ηORR) is characterized by the equation ηORR = 1.23 – min (UORR) (in V), where min (UORR) is the lowest ORR potential in the four electrochemical steps, and the equilibrium potential of ORR is 1.23 V. All the F-terminated surfaces display preferably good performance of ORR than O- terminated surfaces. The lowermost overpotential was experienced by the Pt/v-Ti3C2F2 surface with ηORR = 0.74 V. This work provided a comprehensive understanding of the electronic impact aroused by the termination groups and may stimulate insights of practical MXene frameworks for ORR catalysis. Yang et al. prepared non-noble metal composited catalyst of Fe-N-C@Ti3C2Tx (Fig. 6f) by a separated pyrolysis synthesis technique and experimentally found that Ti3C2Tx MXene not only performs as a decent conductive substrate, yet addition can meritoriously lessen the agglomeration and breakdown of Fe–N–C after carbonization, and enrich the ORR activity and stability of the Fe–N–C catalyst<sup>28</sup> . Fig. 6g, h displays the LSV curves of Fe–N–C, Fe–N–C@MXene, Pt/ 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 61 

A. Bhat et al. 

6 



Fig. 5 MXenes as conductive support. a–c The synthesis scheme of MoS2@Mo2CTx nanohybrids. Reprinted with permission from<sup>71</sup> . d HAADFSTEM micrograph and elemental mapping of delaminated Mo2CTx:Co sheets indicating an even distribution of Mo, C, and O atoms within the sheets, e schematic representation of the Mo2CTx:Co structure and two projections of the coordination situation of cobalt in Mo2CTx:Co. d, e reprinted with permission from<sup>73</sup> Journal of the American Chemical Society 2019, 141, 17809-17816 Publication Date: September 20, (2019) https://doi.org/10.1021/jacs.9b08897 Copyright (2019) American Chemical Society; (f) Graphical scheme showing the Ti4N3Tx synthesis from the molten salt treatment of Ti4AlN3 at 550 °C in Ar atmosphere, followed by delamination of the multilayered MXene by TBAOH. Reprinted with permission from<sup>42</sup> . g graphical representation of the porous MXene/CNT electrode by the self-assembly method, h cross-sectional SEM image of restacked Ti3C2Tx/CNT. g, h used with permission from Elsevier B.V./Xie<sup>75</sup> . 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 61 

A. Bhat et al. 

7 



Fig. 6 MXenes for HER and ORR applications. a Anodic-going iR-corrected LSVs of Mo2CTx and Ti2CTx on glassy carbon as compared with bare glassy carbon electrode compared and the activity of HER activity of Pt nanoparticles is also shown. b Temporal production of potential is needed to retain a constant current density value of 10 mA cm<sup>−2</sup> . c XPS spectra of as-synthesized Mo2CTx, and after HER testing. a–c reprinted with permission from<sup>80</sup> ACS Energy Letters 2016, 1, 589–594; Publication Date: August 09, (2016) https://doi.org/10.1021/acsenergylett.6b00247 Copyright (2016) American Chemical Society; d Graphical diagram shows termination effects of Pt/v-Tin+1CnT2 MXene surfaces for ORR catalysis. e The volcano plot for the ORR potentials (UORR, in V) as a function of the free energies of OOH* (ΔGOOH*, in eV) on different surfaces. d, e reprinted with permission from<sup>81</sup> ACS applied materials & interfaces 2018, 11, 1638–1644; Publication Date: December 12, (2018) https://doi.org/10.1021/acsami.8b17600 Copyright (2018) American Chemical Society; f non-noble metal-based Fe–N–C@Ti3C2Tx catalyst prepared by a facile separated pyrolysis strategy. g LSV curves of MXene, Fe–N–C, Fe–N–C@MXene, and Pt/C in 0.1 M KOH. h LSV curves of MXene, Fe–N–C, Fe–N–C@MXene, and Pt/C in 0.1 M HClO4. Reprinted with permission from<sup>28</sup> . 

C, and MXene in 0.1 M KOH alkaline and 0.1 M HClO4 acidic medium, respectively. The Fe–N–C@MXene exhibited superb electrocatalytic ORR activity with a half-wave potential of 0.887 V and a limited current density of 6.4 mA cm<sup>−2</sup> as compare to pure Fe–N–C having half-wave potential of 0.809 V, limited current density of 5.3 mA cm<sup>−2</sup> , which can even compete with the commercial Pt/C. It is important to note that pure MXene displayed nearly no ORR activity because of the absence of active locations. It was interesting to note that Fe–N–C@MXene disclosed an incredible increment on electrocatalytic ORR activity with a half-wave potential of 0.777 V and a limited current density of 5.7 mA cm<sup>−2</sup> in the acidic medium as well. To date, information 

about designing MXene-based nanocomposites with interesting activities for excellent OER and ORR is still at an early research stage because of their sluggish kinetics. In this view, we foresee that these reports will establish a decent framework to encourage interest in the pursuit of engineering MXene composites for the potential OER and ORR applications in the field of clean energy conversion. These investigations validate the arising role of MXenes as an extraordinary 2D substrate to incorporate with other active catalyst materials to design efficient MXene-based composite heterostructures with nano-interfacial contacts in electrocatalysis. The practice of noble metals like Pt and Ru as an electrocatalyst profoundly inhibited for large-scale application 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 61 

A. Bhat et al. 

8 

due to high cost and shortage. It is concluded that the utilization of transition metals in addition to noble metals nanoparticles opens another pathway to reveal the better and cost-effective MXenes-based electrocatalysis performance. Consequently, the unremitting quest for inexpensive metal nanoparticles incorporated MXenes hybrids with high electrocatalytic activity, efficiency, and stability is still critical and challenging. 

Ti3C2 is gaining much attention in the synthesis of MXene-based photocatalyst as a potential contender to boost the semiconductor photocatalyst efficiency owing to their outstanding electronic properties, tunable surface, and the probability of bandgap engineering. MXenes could be exemplified to be a versatile open-ended exploration area in materials science for energy conversion via photocatalysis<sup>83,84</sup> . MXenes can play various roles in the fabrication of promising hybrid-photocatalyst materials to enhance the activity and stability of pristine semiconductor photocatalysts<sup>85</sup> . When hybridized with other semiconductor photocatalysts<sup>69</sup> , MXene results in a remarkable increase in its efficiency by not only adding more active reaction sites but also altering the energy of surface adsorption<sup>79,86</sup> . 

In this search, Liu et al.<sup>87</sup> reported nanoconfined cocatalyst of Ti3C2/Ru by direct reduction of Ru<sup>3+</sup> ions which led to the 

formation of TiO2–Ti3C2/Ru due to in situ conversion of TiO2 on the surface of Ti3C2/Ru (see Fig. 7a). This typically designed catalyst showed more proficient charge accumulation and transport than observed in the conventional Ru-TiO2–Ti3C2. It is found that increasing the detachment between the sites of reduction and oxidation reaction impedes the recombination of the electron–hole and improves photocatalytic operation<sup>88–90</sup> . The average H2 evolution rate touched 235.3 μmol g<sup>−1</sup> h<sup>−1</sup> for optimized TiO2–Ti3C2/Ru −20 catalyst. (Fig. 7b). The Ti3C2/Ru cocatalyst’s higher work function imitates a low level of Fermi energy, resulting in a rapid transfer rate of photogenerated electrons to the Ti3C2/Ru cocatalyst and eradicates induction the of cycle involved in the photocatalytic H2 production (Fig. 7c)<sup>91</sup> . In this exclusive design strategy, Ti3C2 MXenes played a key role to detach the semiconductor from cocatalyst. The developed material showed the good structure and surface stability as well. In another recent study, Xiao et al.<sup>92</sup> prepared a heterojunction of 1D CdS nanorod/2D Ti3C2 MXene NSs by combining solvothermal-prepared CdS nanorods and 2D Ti3C2 sheets (Fig. 7d). The obtained 1D CdS/ /2D Ti3C2 MXene composite photocatalyst showed sevenfold improved activity of 2407 μmol g<sup>−1</sup> h<sup>−1</sup> than pristine CdS nanorods in the solar-driven hydrogen 



Fig. 7 MXene based photocatalysts. a Schematic synthesis steps to developed TiO2–Ti3C2/Ru, b photocatalytic H2 production trend of the different catalysts, c graphical representation of transportation paths of electron−hole pairs on TiO2–Ti3C2/Ru composite catalyst. a–c Reprinted with permission from<sup>87</sup> ACS Nano 2020, 14, 10, 14181–14189; Publication Date: October 4, (2020) https://doi.org/10.1021/ acsnano.0c07089 Copyright (2020) American Chemical Society; d Schematic diagram of the synthesis of CdS/MXene composites, e Photocatalytic H2 production of prepared samples, f schematic representation of 1D CdS/2D MXene Schottky heterojunction for hydrogen evolution. d–f used with permission from Elsevier B.V./Xiao<sup>92</sup> . g Schematic design for the synthesis steps of hierarchical M@T/ZIS, h Photocatalytic H2 production performance of M@T/ZIS photocatalyst, i graphical representation of photocatalytic H2 evolution mechanism in M@T/ZIS composite. g–i used with permission from Elsevier B.V./Huang<sup>97</sup> . 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 61 

A. Bhat et al. 

9 

production (see Fig. 7e)<sup>93</sup> . The notation of CM-10, CM-20, CM-30, CM-40, and CM-60 only represent 1D CdS/ /2D Ti3C2 catalysts prepared by using different amounts of ultrathin exfoliated Ti3C2 MXene sheets. The improved performance is attributed to the 1D/ 2D Schottky heterojunction, which offered rapid charge separation and low Schottky barrier height for photocatalytic H2 evolution reaction (Fig. 7f)<sup>94–96</sup> . 

Meng et al. prepared a hierarchical Ti3C2 MXene@TiO2/ZnIn2S4 nanostructures by conducting hydrothermal oxidation of Ti3C2 MXene to in situ grow entrenched TiO2 NSs, then ZnIn2S4 was deposited on it by adjusting the appropriate amount of suitable precursors (Fig. 7g)<sup>97,98</sup> . The engineered M@T/ZIS mesoporous hybrid-photocatalyst material exhibited tremendous visible-light absorption performance, exclusive property of separation and transport of photogenerated charges, and high photocatalytic H2 evolution efficiency with a rate of 1185.8 μmol g<sup>−1</sup> h<sup>−1</sup> that was 9.1- and 4.6-folds higher than that of M@TiO2 and pristine ZIS (Fig. 7h), correspondingly. That was attributed to the synergistic effect of ZIS visible-light absorption<sup>99</sup> , suitable TiO2 nanosheet band location<sup>100</sup> , excellent conductivity, favorable light-harvesting, and abundant Ti3C2 active sites<sup>101</sup> , and in particular to the allow interfacial interaction between the three components (Fig. 7i). The specific separation and transfer of photogenerated charges through rapid transfer channels, consisting of a well-designed type II heterojunction between ZIS and TiO2, and a Ti3C2/ semiconductor interfacial Schottky junction, was given by engineered ternary heterojunction<sup>102</sup> . In summary, MXenes based hybrid nanocomposite photocatalysts improve their photo-activity and stability for photocatalytic applications and encourage the coherent exploitation of MXenes in the field of photocatalysis. The practical use of monolayer Ti3C2Tx MXene as a photocatalyst is limited due to the complicated preparation of single-layer Ti3C2Tx MXene, low structural stability due to fast oxidation in water, and ultra-sensitive handling of single-layer or few-layer structures. However, the stability of the MXene-based composite catalysts produced by in situ growth is noteworthy. As a catalyst support, MXenes plays an incredible role due to its hydrophilicity, excellent metallic conductivity, and Ti reactive sites exposed on the surface of MXenes, which indorses catalytic reaction. Regardless of these serious issues that need to be resolved, implementing Ti3C2Tx MXene is well-intentioned for advance exploration in photocatalysis. To make the exploitation of MXene practically feasible in the field of clean energy production/conversion, the primary problem which needs to be address on emergency basis is low structural stability of MXene. 

Ti3C2 MXene inks have been developed and directly applied for direct writing of conductive features for electrical circuits and energy storage appliances on a vast range of substrates<sup>64</sup> . MXene inks of Ti3C2 up to 30 mg mL<sup>−1</sup> can be filled into rollerball point pens for facile and smooth drawing without any leaking or blocking issues. The conductive text of MXene was fabricated promptly on different platforms such as paper, plastic sheets, polypropylene membranes (Celgard), and textiles. Desired patterns of any geometry can be fabricated by writing manually or by employing an automatic instrument for drawing. Direct writing of MXenes for functional devices as a proof-of-concept for m-SC was drawn on a different substrate and utilized as power sources. Another significant progress of using MXenes in m-SCs has been explained by Ghidiu et al.<sup>56</sup> The significance of this research is conceived from the perspective of providing a readymade power source to portable electronics, microsensors, and microelectromechanical systems [MEMS]. MXenes demonstrate high gravimetric capacitances and improved volumetric characteristics owing to a much wider packing density of ∼4.0 g cm<sup>−3 56</sup> . The device was fabricated by the process of spray coating where the large-sized Ti3C2Tx MXene (L-Ti3C2Tx) was deposited on the glass substrate followed by deposition of an electroactive layer of small size Ti3C2Tx spray on the top. This was followed by the aid of direct 

laser cutting to create the interdigital pattern of a specific central area of 8 × 6 mm on the stack arranged MXene film. The suitable electrolyte gel of PVA/H2SO4 was used to develop the interdigital design and then left overnight which led to the development of all MXene-based solid-state m-SCs (L-s-Ti3C2Tx)<sup>56</sup> . 

### ENERGY STORAGE APPLICATIONS OF MXENES 

The accommodation of variable-sized ions between 2D layers of Mn+1XnTx makes MXenes suitable to use in lithium-ion batteries (LiBs), where the electrode materials are limited. Figure 8a demonstrates the key aspects revealing theoretical and experimentally confirmed ion insertion into MXenes sheets from organic electrolytes. When X-ray absorption spectroscopy was used to examine the Li<sup>+</sup> charge storage mechanism in Ti3C2Tx MXene, an incessant variation in the oxidation state of transition metal (i.e., Ti), through charging and discharging, was observed up to 0.5 V versus Li/Li<sup>+</sup> as shown in Fig. 8b<sup>38</sup> . Interestingly, reducing the potential further does not interpret into an alteration in oxidation state. Li atoms form another layer reversibly due to the 2D structure and conductivity of MXenes, as shown in Fig. 8a. This results in boosting the capacity two-fold, and it is expected that the same mechanism applies to other MXene nanostructures<sup>38,103</sup> . MXene-based electrodes with typical capacities fit in the range of 50–200 mAh g<sup>−1</sup> at rates above 10 C (for 6 min charging). As a result, in the galvanostatic charge–discharge outline, the MXenes do not show a plateau region in metal-ion batteries as shown in Fig. 8b, which resembles the behavior of supercapacitors. Furthermore, the optimization of the architecture of the MXenebased electrode enhances the capacity. In addition, integration of porous MXene flakes with carbon nanotubes (CNTs), results in a high lithium-ion capacity of 750 mAh g<sup>−1104</sup> . Fig. 8c shows oxygen-terminated MXenes in Na-, K-, Mg-, Ca- and Al-ion batteries and their theoretical capacities<sup>38</sup> . For Na<sup>+</sup> and other ions, the creation of an extra metal layer was estimated, which would result in an increase of the capacity by twice. Likewise, the various MXenes provide a wide variety of working potentials due to the possibility of tuning their chemical, structural and surface chemistry, which considers them suitable candidates for either anodes<sup>105</sup> or cathodes<sup>106</sup> as shown in Fig. 8d. It has been shown theoretically that Li<sup>+38</sup> and other ions<sup>38,107–109</sup> demonstrate low diffusion barriers in MXenes. These results are in good accord with the experimentally observed performance for many MXenes<sup>105,110,111</sup> . MXene composite electrodes demonstrate promising results for high-rate and high-performance batteries. Like, Ti2CTx or Ti3C2Tx have been applied in Li–S-based batteries as conducting sulfur hosts. The results are dramatic with better stability and cyclability due to robust interface amongst polysulfide species and MXene functional groups, as demonstrated in Fig. 8e<sup>112,113</sup> . Similarly, tin (Sn) nanoparticles encapsulation between the layers of Ti3C2Tx MXene out-products with steady performance and a higher volumetric capacity touching 2000 mAh g<sup>−1</sup> . The same approach of hybridization of other nanomaterials with MXene nanostructures can be used to enhance the rate capability and cycle life of other high-capacity electrodes substantially that undergo a remarkable volume alteration upon intercalation. In this strategy, while preserving the electrical and structural connectivity, the MXenes provide a conductive base of a matrix that assists the contraction and expansion of particles. 

Sun et al. experimentally investigated that gravimetric capacitance of Ti3C2Tx MXenes can be significantly improved by cation intercalation and surface alteration. After removal of termination groups (OH<sup>−</sup> /F<sup>−</sup> ) and cation intercalation, the pseudocapacitance is three times greater than the pure MXene. Furthermore, the assynthesized electrodes show above 99% retaining over 10,000 cycles. The surface-modified MXene revealed outstanding performance with over 500 F g<sup>−1</sup> of specific capacitance at 1 mV s<sup>−1 114</sup> . 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 61 

A. Bhat et al. 

10 



Fig. 8 MXenes as conductive electrodes in batteries. a Schematic representation of Li<sup>+</sup> insertion in the Ti3C2Tx. Without and with the extra lithium film, the valence electron localization functions are described. b Edge energy variation of titanium versus capacity of MXene during delithiation and lithiation process integrated along the analogous voltage contours. c On the oxygen-terminated MXene sheets, theoretical capacities of nonlithium and lithium ions were theoretically obtained. a–c reprinted with permission from<sup>38</sup> JACS 2014, 136, 17, 6385–6394; Publication Date: March 28, (2014) https://doi.org/10.1021/ja501520b Copyright (2014) American Chemical Society; (d) Cyclic voltammetry (CV) curves of V2C and Ti2C in a Na<sup>+</sup> electrolyte. d reprinted with permission from<sup>106</sup> The journal of physical chemistry letters 2015, 6, 2305–2309; Publication Date: June 5, (2015) https://doi.org/10.1021/acs.jpclett.5b00868 Copyright (2015) American Chemical Society; e Performance representation of Ti2C–S MXene composite in Li–S batteries; A graphical demonstration of the substitution of the Ti–OH bond with S–Ti–C bond on the MXene surface upon treatment by heat or contacting with polysulfides (presented on the leftward); the cyclic functioning of a 70 wt% d-Ti2C-S MXene composite at C/2 and C/5 (in middle); and long-period cycling at C/2 is presented on the rightward. Reprinted with permission from<sup>112</sup> . 

Talapin et al. designed a versatile synthesis strategy to introduce and eliminate the surface functional groups on 2D transition metal carbides (MXenes) flakes by conducting substitution and elimination reactions in molten inorganic salts. The effective preparation of MXenes with O, NH, S, Cl, Se, Br, Te surface terminations, and naked MXenes was investigated. Such MXenes demonstrate distinct structural and electronic features<sup>115</sup> . 

### Micro-supercapacitors (m-SCs) 

Because of the rapid growth of portable and wearable electronics, there is an increasing demand for compact miniaturized energy storage devices. In this search, m-SCs are an appealing solution for the design of these microelectronics due to their infinite lifetime and high power density, but the scalable output is also based on electrode materials and manufacturing protocols. Active materials in supercapacitors are picked based on the targeted application. 

For example, a material with a wide active surface area that is accessible to electrolyte ions, such as graphene, can contribute significantly to the electrical double-layer capacitance. However, this is inadequate to meet the needs of future microelectronics. To increase the energy density of supercapacitors, TMDCs and transition metal oxides are used. However, they lack high carbon electrical conductivity, necessitating the use of a carbon-based binder or current collectors to boost efficiency. MXene has emerged as a great solution to this problem in this regard, as a 2D material, it has a wide surface area favorable for electrical double-layer capacitance. Simultaneously, it improves pseudocapacitance significantly, thanks to an intercalation mechanism that can accommodate a wide range of cations. MXenes have recently proven to be a promising material for advanced m-SCs with high energy and power densities. Due to high pseudocapacitance, metallic conductivity, and ease of solution processing, MXenes have recently proven to be a promising material for advanced 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 61 

A. Bhat et al. 

11 



Fig. 9 Micro-supercapacitor fabrication using MXene ink Pen. a An array of micro-supercapacitors of MXene ink written on paper, b optical images of patterned spiral MXene circuit, c cyclic voltammograms (CVs) at different scan rates of MXene-based m-SC on paper, d A series of four MXene-based micro-supercapacitors joined on a rounded paper cup, e corresponding CV, f–i MXene patterns transferred to scotch tape (h, i), from Celgard: a polypropylene membrane (f, g). Reprinted with permission from<sup>64</sup> . 

m-SCs with high energy and power densities. The interdigitated electrode of MXene was patterned on paper and wood substrates by using MXene pens as demonstrated in Fig. 9a, b. This strategy of direct writing allows the fabrication of m-SCs on a broad range of substrates, which is usually difficult to design with standard techniques. A conventional gel electrolyte of polyvinyl alcohol and sulfuric acid (PVA/H2SO4) was employed while performing electrochemical testing of all the fabricated microsupercapacitors. As shown in Fig. 9c, the cyclic voltammograms (CVs) of MXene-based devices on paper substrates reveal the capacitive behavior without employing any metal-based current collectors. Paper-based supercapacitors cannot be used and show non-rectangular CVs graphs due to the increased resistance of the electrode material. In contrast, MXenes demonstrate high electrical conductivity with better capacity without requiring additional post-processing or current collectors. The single MXene-based m-SC produced a typical areal capacitance which was calculated to be 5 mF cm<sup>−2</sup> . This value is superior to the micro-supercapacitors of carbon materials fabricated in a similar format<sup>116</sup> . Graphene and carbon nanotubes were mostly assembled with conductive electrodes as a current collector while MXenes possess greater conductivity enabling the designing of energy storage capacitors and sensors in one step. The flexibility of the writing method was demonstrated by loading a rollerball pen with Ti3C2 to draw micro-capacitor devices onto a curvy paper-based cup. A series of four Ti3C2 based microsupercapacitors in a row demonstrated a voltage of 2.4 V, enough to illuminate a red LED, as presented in Fig. 9d–i. In addition, besides writing on porous substrates, the MXene ink pen can be applied to draw many features on the smooth polypropylene membrane surface. Thus, the versatile MXene pattern writing enables for generating flexible and all MXene-based electronic devices. 

Directly printed additive-free MXene ink-based m-SC has shown an excellent volumetric capacitance of 562 F cm<sup>−3</sup> with an increased energy density of 0.32 µ W h cm<sup>−2</sup> , exceeded compare to current for inkjet/extrusion-printed materials. The designed approach paves a way not only in energy storage but also in smart printed electronics, flexible circuits, packaging, and sensors<sup>117</sup> . Nitrogen doping increases pure MXene’s electrochemical efficiency through improved conductivity and redox activity. Pure MXene-N ink with a moderately low viscosity is achievable to assemble interdigitated m-SCs with the aid of the 2D screen printing method, instantly harvesting an advantageous areal capacitance<sup>118</sup> . In situ synthesis and sodium ascorbate capping of Ti3C2Tx MXenes were performed to obtain a dispersion of SAMXene. Also, after 80 days of storage at room temperature and subjected to sunlight, high oxidation resistance has been achieved. This is due to the rise in SA-MXene sheets interlayer spacing, without compromising their electrical conductivity, demonstrated a volumetric capacitance of 720.7 F cm<sup>−3 119</sup> . To contribute high pseudocapacitance, hydrous RuO2 nanoparticles were introduced between MXene layers and work as spacers to efficiently help adjacent NSs to facilitate the transfer of electrons from MXene to RuO2 nanoparticles while creating an extended electrolyte ion pathway. Without the addition of other inactive additives, the 1D AgNWs coordinate with the 2D RuO2·xH2O@MXene NSs to ensure high viscosity and sufficient rheological activity for electrode ink. The continuous AgNW network in the printed electrodes forms exceedingly conductive electron pathways on a macroscale to facilitate charge transfer while retaining a compatible structure to accommodate bending stresses. After 2000 bending cycles with bending strain of 5%, the screen-printed m-SCs based on this RuO2·xH2O @MXene-AgNW nanocomposite ink exhibited a volumetric capacitance of 864.2 F cm<sup>−3</sup> at a scan rate of 1 mV s<sup>−1</sup> , high rate capacity, superb cycle 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 61 

A. Bhat et al. 

12 

stability, and excellent flexibility retention of 87.3%<sup>120</sup> . Since micro-supercapacitors are advanced energy storage microdevices that exhibit relatively high electrochemical performance with small volume. MXene due to its versatile energy storage abilities, with high surface area conducting properties, are ideal electrode materials for these electrochemical microdevices. 

### MXenes and Lithium-ion batteries 

The accomplishment of LIBs for portable devices was recognized by awarding the Nobel Prize in Chemistry in 2019 to John B. Goodenough, M. Stanley Whittingham, and Akira Yoshino for their research in improving modernized portable electronics<sup>121</sup> . LIBs are ubiquitous today, frequently used for small electronics and electric vehicles because of their superior energy storage density, prolonged cycling life expectancy, and environmentally friendly compared to other substitutes<sup>122,123</sup> . To date, the prevalent LIBs utilizing graphite as anode material are unable to meet the rigorous needs for its less theoretical specific capacity (372 mAh g<sup>−1</sup> )<sup>124</sup> . MXenes proffer high competition with former 2D materials owing to wide structural and chemical properties<sup>125,126</sup> . That is why the theoretical investigation of different types of materials can be useful to select the most encouraging material for energy storage applications. It was observed through theoretical studies that the gravimetric capacity of low formula weight MXenes such as Nb2C, Ti2C, Sc2C, and V2C, are the most favorable materials<sup>127</sup> . As compared to M3X2 and M4X3 electrodes the M2X based electrodes show higher expected gravimetric capacities. The external ions can only reasonably enter between the MXene sheets because the M–X bonding is quite strong. This hypothesis is supported by the experimental findings. For example, Ti2C MXene should possess higher gravimetric capacitance (~50%) than Ti3C2 MXene, the reason being Ti3C2 has one non-active TiC layer, though both have similar surface chemistry. This was supported experimentally; for Li<sup>+</sup> uptake, Ti2CTx MXene’s gravimetric capacity is ~1.5 times greater than Ti3C2Tx, both synthesized similarly<sup>45,110</sup> . It is essential to mention that the capacity for a particular material is not specified solely by its formula weight. For instance, the highest capacity for Li<sup>+</sup> is shown by V2CTx as compared to other MXenes tried under the same conditions (280 mAh g<sup>−1</sup> at 1 C and 125 mAh g<sup>−1</sup> at 10 C cycling rates)<sup>111</sup> . Furthermore, the Nb2CTx (180 mAh g<sup>−1</sup> ) shows higher gravimetric capacity than Ti2CTx (110 mAh g<sup>−1</sup> ) at a similar cycling rate of 1 C, though niobium (Nb) is heavier than titanium (Ti)<sup>111</sup> . In part, the complex nature of ion storage also explains this. Researchers have theoretically proved that surface terminations are the main reason that can influence performance<sup>38,127</sup> . For example, MXene materials with oxygen terminations show better performance as compared to hydroxyls and fluorine-based MXenes, in terms of capacity and lithium-ion transport<sup>38,61</sup> . 

Recently, MXene solely and with other several 2D materials i.e MoS2128, WS2129, g-C3N4130, have been significantly investigated as LIB anodes because of their exceptional electrical conductivity, the possibility of numerous surface terminations, high mechanical strength, hydrophilic nature, advantageous layered structure for ion/electron transportation, and the ability to accommodate intercalants<sup>131</sup> . In 2011, Naguib et al. first suggested that the multilayered flakes of Ti3C2Tx MXene could be a possible candidate as anode for lithium storage<sup>17</sup> . Later studies into MXene electrodes for LIBs have been pursued both computationally and experimentally. In 2012, Naguib et al.<sup>45</sup> published the first use of Ti3C2Tx MXene in LIBs and recorded a high reversible capacity of 225 mAh g<sup>−1</sup> at a current density of C/25. This finding begins another area for researchers to investigate MXenes as Li<sup>+</sup> intercalation host material for LIBs<sup>127</sup> . Later as-obtained Ti3C2Tx “paper” provided a superior reversible capacity of 410 mAh g<sup>−1</sup> at the rate of 1 C, which is significantly superior to etched- Ti3C2Tx MXene<sup>110</sup> . When combined with other 2D materials, MXenes serve 

as conductive spacers to inhibit the agglomeration, leading to the partial preservation of physicochemical properties similar to monolayers<sup>132,133</sup> . Besides, during the charge/discharge process, the vigorous 2D space produced by MXenes can serve as a nanoreactor to limit the diffusion of the intermediates<sup>134</sup> , This can reduce the structural detachment of less stable 2D materials, resulting in a reversible transition process between each layer and a well-preserved interfacial contact. 

Considering this concept, the growth of MoS2/MXenes 2D layered heterostructures by in situ sulfidations of Mo2TiC2Tx precursor was investigated by Chen et al.<sup>135</sup> Schematic Fig. 10a shows that with the help of solution process method, sulfur nanoparticles were introduced between the MXene layers that can in situ react on the Mo2TiC2Tx surface with Mo atom to create the ultimate MoS2-on-MXene hybrid materials. The pure Mo2TiC2Tx XRD pattern (Fig. 10b) reveals the only peaks of (00l) with a d- spacing of 21.53 Å. In the filtered MXene film, the presence of all the (00l) peaks shows the robust restacking of the flakes. For MoS2/Mo2TiC2Tx-500 and MoS2/Mo2TiC2Tx-700, the d-spacing of Mo2TiC2Tx reduced from 21.53 Å to 14.06 and 13.71 Å, respectively. The lattice spacing of around 14.0 Å was measured in the TEM picture (Fig. 10c), which agrees with the (002) peak in the XRD pattern of the Mo2TiC2Tx. Furthermore, an advance-designed layered material with an interlayer spacing of 6.9 Å was obtained on Mo2TiC2Tx, as of bulk MoS2136. Fig. 10c displays that two layers of MoS2 are in near contact with layers of Mo2TiC2Tx, allowing heterostructures of MoS2-on-MXene. Owing to synergistic effects, the MoS2/Mo2TiC2Tx-500 (500 shows that the heating temperature was 500 °C) electrode illustrates an enhanced reversible capacity of 554 mAh g<sup>−1</sup> at 100 mA g<sup>−1</sup> current density and maintains a capacity of 509 mAh g<sup>−1</sup> after 100 cycles (Fig. 10d). The MoS2/ Mo2TiC2Tx-500 electrode demonstrated capacities of 484, 407, 315, and 182 mAh g<sup>−1</sup> , when the current density was amplified to 200, 500, 1000, and 2000 mA g<sup>−1</sup> , respectively. The MoS2/Mo2TiC2Tx500 electrode produced a capacity of 90 mAh g<sup>−1</sup> even at a high current density of 5000 mA g<sup>−1</sup> (Fig. 10e). In addition, the computational findings show that the 2D heterostructures exhibit metallic properties that additionally improve the electrochemical performance of LIBs. MXene-based composite demonstrates enhanced electrochemical storage abilities due to the combination of multiple components. 

### MXenes and sodium-ion batteries 

During the past decades, rechargeable sodium-ion batteries (SIBs) have attracted huge research interest as an economical source for energy storage applications in clean energy, electric vehicles, and smart grid, due to the availability of sodium in nature in contrast to lithium<sup>131,137</sup> . Nevertheless, because of the bigger size of sodium ions, the interlayer space of more than 0.37 nm is an important requirement to improve the sodium-ion diffusion in electrode materials for effective sodium-ion intercalation<sup>138</sup> . This problem could be resolved by developing ultrathin 2D layered electrode materials with expanded interlayer spacing. The diffusion path will be affectedly shortened by decreasing the channels for sodium-ion insertion/removal<sup>136</sup> . On the contrary, the ionic conductivity is fairly influenced by enlarging the interlayer distance, which is useful for effective sodium-ion intercalation<sup>139</sup> . Besides TMDs, graphene, and g-C3N4140, 2D metal carbides (MXenes) with atomically thin NSs, rich chemical composition, extra functional groups, and excellent metallic conductivity have got great perspective for application in inexpensive energy storage and utilization applications<sup>141–143</sup> . It was found that MXene is a promising anode for NIBs with short electronic and ionic transportation pathways because of less diffusion barrier for Na<sup>+</sup> , superb metallic conductivity, and intercalation capability<sup>143,144</sup> . While the diameter of 2D titanium carbide is in atomicscale (monolayer TiC3), it can attain the maximum theoretical 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 61 

A. Bhat et al. 

13 



Fig. 10 Synergistic effect of MoS2/MXene composite. a Schematic diagram of the steps involved in the synthesis of MoS2/MXene composite; (b) XRD patterns of pure Mo2TiC2Tx, MoS2/ Mo2TiC2Tx-500, and MoS2/Mo2TiC2Tx-700; c TEM images of MoS2/Mo2TiC2Tx-500 heterostructures in cross-sectional view; d GCD curves of MoS2/Mo2TiC2Tx-500 at 100 mA g<sup>−1</sup> ; e Pristine Mo2TiC2Tx and MoS2/Mo2TiC2Tx-500 rate performance, Reprinted with permission from<sup>135</sup> . 

capacity up to 1278 mAh g<sup>−1145</sup> . First-principles calculation establishes that open-circuit voltage and low barrier energy can be observed in monolayer TiC3146. It was found that TiC3 maintains a metallic state when alloying two-layer Na atoms, confirming great electric conductivity and prominent ultra-long cycle life<sup>147</sup> . 

Such interesting characteristics mark the TiC3 monolayer, specifically a metal-rich MXene, a favorable anode material for SIBs contrast to multilayered MXenes<sup>142</sup> . To exploit the benefits of MXene matrix with its distinctive 2D structure, exceptional metallic conductivity, and intercalation ability, various techniques were executed to improve the sodium-storage properties, together with enlarging interlayer distance<sup>143,148</sup> , co-functioning with elevated capacity<sup>148,149</sup> and deterring the stuffing of MXene layers by developing permeable structures<sup>75,144</sup> . 

Sun et al.<sup>150</sup> prepared sulfur-decorated Ti3C2 MXenes (S-Ti3C2) via the solution process method based on electrostatic attraction. The delaminated Ti3C2 MXenes were saturated in Na2S solution to procure sodium-intercalated and sulfur-decorated S- Ti3C2 (Fig. 11a). FESEM Fig. 11b shows the uneven surface of Ti3C2 due to sulfur contaminants induced by Na2S solution treatment at the 

surface of Ti3C2 MXenes after soaking. More sodium storage was allocated due to attached sulfur groups and additional fast sodium diffusion paths were observed in sodium-pillared structures and 2D S-Ti3C2 MXenes interlayers<sup>75,147</sup> . Due to self-enhanced kinetic, intercalation pseudocapacitance, and surface-controlled pseudocapacitance, S-Ti3C2 MXenes exhibited an excellent reversible capacity of 135 mAh g<sup>−1</sup> at a current density of 2 A g<sup>−1</sup> after 1000 cycles, while investigated as an anode material for SIB (Fig. 11c)<sup>150,151</sup> . 

To enhance the structural stability and electrochemical activity of MXenes as an anode material for SIBs Zhao et al.<sup>152</sup> combined MXenes with NiCo bi-metallic phosphide (Fig. 12a). The colloidal solution of a few-layered well-etched Ti3C2Tx MXenes was mixed with NaOH solution to prepare 3D wrinkled porous Ti3C2Tx network, Fig. 12b, e shows the respective FESEM and TEM micrographs. A larger layer space was achieved as the high concentration of Na<sup>+</sup> intercalates among MXenes layers to change the Li<sup>+153</sup> . Moreover, the saturated –OH in solution substitutes the –F terminal groups resulted in much higher chemical reactivity. Wrinkled alkali-saturated MXenes Ti3C2/NiCo-LDH precursors were 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 61 

A. Bhat et al. 

14 



Fig. 11 Performance of sulfur-decorated Ti3C2 MXene. a Graphical representation of the synthesis of S-decorated Ti3C2 MXenes. b SEM image of S-Ti3C2 MXenes. c Cycling performance and coulombic efficiencies S-Ti3C2 MXenes and alkali-rich Ti3C2 Mxenes at a current density of 2 A g<sup>−1</sup> . a–c used with permission from Elsevier B.V./Sun<sup>150</sup> . 

hired to get the 3D crinkled porous Ti3C2/NiCo hybrid, followed by in situ phosphorizations to obtain Ti3C2/NiCoP product (see SEM image in Fig. 12c). Figure 12d demonstrates the working principle of a Ti3C2/NiCoP based half-cell anode. Figure 12f shows that the NiCoP particles were homogeneously dispersed at the surface of Ti3C2, the conductive bi-metallic particles could help to prevent aggregation and pulverization, overall resulted in rich redox reaction sites, low charge transfer impedance, and excellent electrical conductivity<sup>154,155</sup> . The synergistic effect between the high structural stability and electrochemical performance components of NiCoP and MXene Ti3C2 determined the outstanding electrochemical efficiency, the high specific capacity of 416.9 mAh g<sup>−1</sup> at the current density of 0.1 A g<sup>−1</sup> (Fig. 12(g)), holding a specific capacity of 261.7 mAh g<sup>−1</sup> at a current density of 1 A g<sup>−1</sup> after 2000 cycles (Fig. 12h). According to these recent findings, Mxene is considered important material for secondary storage batteries due to its inherent redox properties, the intercalation of sodium and Lithium is well established however, there is a need to further investigate the intercalation of multivalent ions. Moreover, Mxene in different forms can be explored in Lithium–sulfur (Li–S), lithium, and solid-state batteries. 

### SHELF-STABILITY OF MXENE DISPERSION 

Delamination of MXene sheets aqueous colloidal solutions produce all types of products; for example, thin films, MXene inks, coatings, and electrodes, etc. However, these 2D materials are extremely prone to oxidation<sup>156</sup> , which could result in chemical degradation and loss of functional properties. Hence, the stability of MXene is of crucial significance for its application, especially in the form of colloidal solutions which is a real challenge. Zhang et al.<sup>157</sup> investigated the oxidation of exfoliated- 

Ti3C2Tx aqueous solutions and summarized procedures to enhance their stability. In uncovered vessels, Ti3C2Tx MXene solutions degraded by 42%, 85%, and 100% after 5, 10, and 15 days, respectively, primary to the formation of cloudy-white colloidal solutions mainly comprising anatase (TiO2). This suggests that Ti3C2Tx MXene aqueous suspension can be maintained wellstable when it is kept in hermetic air-filled bottles at 5 °C due to the dissolved oxygen, which removes the major oxidant of the MXene sheets<sup>157</sup> . Fig. 13a upper panel, demonstrates the higher solubility of oxygen in water offers an incessant supply for MXene degradation. The lower panel shows the lack of dissolved oxygen in water (a moderate oxidant) in Ar-filled surrounding makes MXene NSs degrade gradually. Following the proposed method, the solution’s time constant has been substantially improved (Fig. 13b). They observed that the degradation begins at the edges and tiny flakes were less stable, which showed that the degradation is size-dependent. Recently, an important chemical method for preventing oxidation of colloidal Ti3C2Tx MXene NSs by antioxidant pretreatments like sodium L-ascorbate (Fig. 13c), ascorbic acid, and tannic acid at optimized concentrations has been identified by Zhao et al.<sup>158</sup> Ti3C2Tx, when treated with sodium L- ascorbate maintained its as-synthesized chemical nature for 6 months. Conversely, the nature of Ti3C2Tx NSs colloids kept in water was altered (Fig. 13c inset). After filtration, the purified films were then vacuum dried at 40 °C for 12 h. The accomplishment of the method is apparent with the consistent shape, structure, and stability of Ti3C2Tx colloids. The presented method is more desirable as the electrical conductivity of sodium L-ascorbate treated Ti3C2Tx flakes was much improved in contrast with unreacted ones after 21 days in the existence of water and oxygen (Fig. 13d). Sodium L-ascorbate shields the nanoflake edges, inhibiting water molecules from more reactive sites, endorsed by 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 61 

A. Bhat et al. 

15 



Fig. 12 Performance of Ti3C2/NiCoP hybrid material. a Step-wise schematic representation of the synthesis process of the Ti3C2/NiCoP hybrid. b, c FESEM images of the wrinkled Ti3C2 alkali-induced 3D and the composite network of Ti3C2/NiCoP, respectively. d Schematic charge-discharge process in half-cells. e, f TEM micrographs of the alkali-decorated 3D Ti3C2 hybrid and the Ti3C2/NiCoP composite, correspondingly. g Ti3C2, Ti3C2/Ni2P, and Ti3C2/NiCoP electrodes’ rate capability. h Cycling performance of Ti3C2/Ni2P, and Ti3C2/NiCoP electrodes at a current density of 1.0 A g<sup>-1</sup> after 2000 cycles. Reprinted with permission from<sup>152</sup> . 

molecular dynamic (MD) simulations showing the interaction between the ascorbate anion and the edge of the nanoflake. The report validates the comparatively long-term stabilization of colloidal Ti3C2Tx nanoflakes in aqueous dispersal utilizing sodium L-ascorbate (NaAsc) as the antioxidant. With these conclusions, the shelf-stability of MXenes is feasible, and commercially available MXene related materials could be a reality. 

As colloidal solutions of Ti3C2Tx MXene flakes rapidly degrade under atmospheric conditions due to the conversion of titanium carbide to titanium dioxide, time-dependent MXene oxidation decreases its electrical, mechanical, and electrochemical properties. Therefore, the stability and long shelf life of MXene is the biggest challenge in the present time to exploit it in industrial and daily life applications. Natu et al.<sup>159</sup> . noticed that by capping polyanions such as polyphosphates, polysilicates, or polyborates with the edges of distinct MXene flakes-Ti3C2Tz and V2CTz (Fig. 14a), their tendency to oxidize in aerated water can be decreased for weeks. Wu et al.<sup>119</sup> prepared oxidative resistive MXenes by capping with sodium ascorbate (Fig. 14b). The resulted MXene is highly stable for 80 days and showed areal and volumetric capacitance of 108.1 mF cm<sup>−2</sup> and 720.7 F cm<sup>−3</sup> (Fig. 14c), respectively in a printable SA-MXene ink-based interdigital micro-supercapacitors electrodes made without a current collector (Fig. 14d). Chae et al.<sup>160</sup> investigated the leading factors swaying 

the rate of oxidation of Ti3C2Tx MXene flakes and presented a way to store MXenes by preserving the intrinsic properties of MXenes. The oxidation stability of aqueous solutions of Ti3C2Tx is vividly enhanced by ceasing the oxidation process at sufficiently low storage temperature of −80 °C (Fig. 14e). In this way, aqueous colloids of Ti3C2Tx could be chemically stable for more than 39 weeks even in an O2 atmosphere. The current progress to synthesize stable MXenes along with the preparation strategies and treatment are summarized in Table 1. 

### FUTURE PERSPECTIVES AND SUMMARY 

This review article underlines the most recent research advances on 2D MXene materials for clean energy conversion via electrocatalysis and photo-electrocatalysis namely HER/OER, ORR, and photocatalysis H2 production and for energy storage applications, that includes LIBs, SIBs, m-SCs, and most importantly the stability of the MXene solution as well. While comprehensive studies on these 2D layered materials have been conducted over the past decades, their practical applications are still hindered by many challenges. From the product synthesis side, the main challenge is how to use active exfoliation techniques to produce 2D materials as thin as feasible. Most of MXenes so far have been developed by selectively etching Al from the MAX phase with the 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 61 

A. Bhat et al. 

16 



Fig. 13 Shelf stability of colloidal MXenes. a Schematic diagram of colloidal d-Ti3C2Tx MXene aqueous solution degradation in the air and argon at room temperature denoted as Air@RT and Ar@RT. b The d-Ti2C2Tx stability in Air@RT and Ar@LT. a, b reprinted with permission from<sup>157</sup> Chemistry of Materials 2017, 29, 4848-4856; Publication Date: May 09, (2017) https://doi.org/10.1021/acs.chemmater.7b00745 Copyright (2017) American Chemical Society; c Shelf-stable Ti3C2Tx NSs stabilized by sodium L-ascorbate (NaAsc) solution and stored in deionized water. Ti3C2Tx oxidizes and degrades without antioxidants to form TiO2 and carbon. Sodium L-ascorbate protects against seriously oxidizing the nanosheet; d Conductivity shift vs. time of Ti3C2Tx Buckypaper produced after pretreatment with selected antioxidants. c, d used with permission from Elsevier B.V./Zhao<sup>158</sup> . 

aid of HF as the etchant. Because of the high toxicity of HF, other methods utilizing less toxic etchant, such as a combination of LiF and HCl, have been pursued to successfully etch A element. It is worth highlighting that the research on MXene materials is still at a nascent stage compared with other 2D nanomaterials. Despite countless challenges, concerted further efforts should be devoted to exploring fluoride-free and environmentally friendly etchants as a sought-after alternative for conventional HF. The relative surface area and reactivity of 2D MXene materials will be enhanced by decreasing the diameter. This demonstrated that the surface functional groups have a key influence on the electrochemical properties of MXene. On the other hand, it is also important to modify morphology to increase active sites. The tailored porosity and curved geometry of 2D MXene flakes can produce high surface area and tuned pore size and volume, which can potentially increase the energy storage abilities of supercapacitors and storage batteries. Tuning the porosity of MXenes is remains a challenge. However, the inclusion of DMSO, TBAOH, etc. into the interlayer spacing have shown that the layers could be separated by inserting small molecules. Therefore, using inorganic pillaring agents to pillar the MXene layers could help to tune the porosity. For future perspectives, the class of MXene could be expanded to develop multimetallic Mn+1XnTx with different metals (M) and functions of T and x. Furthermore, it is important but still challenging to grow large-scale single-layered MXenes sheets, unlike graphene which needs to be considered as a current challenge. 

A significant feature of 2D material chemistry is covalent functionalization. Chemically, each sheet of an MXene is made of a layer of transition metal atoms with carbon atoms that can be covalently functionalized to bring multiple organic functionalities 

to the surface to improve their performance in various diverging applications. The development of blended low-dimensional heterostructures i.e. 0D/2D and 1D/2D as well as 3D nanoarchitecture in addition to the 2D/2D layered heterojunction is a promising way to build layered MXene with active basal planes for effective electrocatalytic and photocatalytic reactions. In terms of material engineering, MXene-based nanocomposites’ interfacial and geometry designs are critical for achieving high catalytic efficiency and long-term stability. Despite limited research on MXene-based nanohybrids in clean energy conversion applications except for HER catalysis, the true catalytic pathways and working mechanisms remain mysterious, necessitating further research in the future. Furthermore, high activity, selectivity, and stability are needed for the long-term commercialization of catalysis applications. This can be achieved by combining experimental measurements and theoretical simulations with advanced in situ spectroscopic characterizations to shed light on the evolution of catalyst active sites. 

Building up highly pure and atomically sharp 2D heterostructures will be a prospect owing to the nature of weak van der Waals interlayer interactions and large diversity in 2D materials. These heterostructures can play a critical role in advance emerging energy storage and generation systems due to their diverse intrinsic properties and multicomponent presence. 2D heterostructure can be vertical as well as lateral, however the lateral is much easier for planar integration and exhibit exceptional properties. 2D/2D; 1T-MoS2/Ti3C2 Mxene can be designed by in situ growth through the solution method. Similarly, a selection of metals-based MOFs/MXene heterostructure can be grown in situ single-step hydrothermal synthetic method, respectively. Typically, MXene (or their hybrid composite) can be used as elastic 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 61 

A. Bhat et al. 

17 



Fig. 14 Different synthesis protocols to get oxidation resistive MXenes. a Schematic diagram of edge capping of MXene sheets by polyanions. The middle flake is representative of an as-synthesized MXene flake. The top flake shows capping of MXene edges with polyanions to protect it from oxidation, while the bottom flake shows a bare edge that undergoes oxidation over prolonged exposure to water and air. Reprinted with permission from<sup>159</sup> . b Graphical diagram of the synthesis of stable SA-MXene composite and solid-state m-SCs manufactured by inkjet printing of the SA-MXene. c, d Cycling stability performance at a constant current of 1 A g<sup>−1</sup> of the p-MXene and SAMXene-based supercapacitors. a–d used with permission from Elsevier B.V./Wu<sup>119</sup> . e During different storage time, the sheet resistances of Ti3C2Tx films for 10 weeks in D@-80, D@-18, D@5, and E@5. Including the calculated sheet resistance of Ti3C2Tx stored for 39 weeks at −80 °C. The inset displays optical images of Ti3C2Tx films acquired from MXene’s vacuum filtration solutions after 5 weeks of freezer storage at D@-18, D@5, and E@5 in ethanol. Reprinted with permission from<sup>160</sup> . 

Table 1. Recent progress in stable MXenes synthesis. 

|MXene|Precursor|Etchant|Treatment to improve stability|Stability Time (Days)|Year|Refs.|
|---|---|---|---|---|---|---|
|Ti3C2Tz|Ti3AlC2|LiF–HCl|Edge capping with polyanionic salts (polyphosphates)|30 in an open<br>container|2019|157|
|SA- Ti3C2Tx|Ti3AlC2|LiF–HCl|Capping with Sodium ascorbate|80|2020|117|
|Ti3C2Tx|Ti3AlC2|LiF–HCl|- 80 °C freeze storage|273|2019|158|
|V2CTz|V2AlC|HF|Edge capping with polyanionic salts (polyphosphates)|30|2019|157|
|Ti3C2Tx|Ti3AlC2|LiF–HCl|- 20 °C freeze storage|650|2020|159|
|r-Ti3C2Tx|Ti3AlC2|HF|L-ascorbic acid|28|2020|160|
|Ti3C2|Al-Ti3AlC2|HF–HCl|modified synthesis of Ti3AlC2 to produce a more<br>stoichiometric MAX phase Al-Ti3AlC2|300|2020 (Yury Gogotsi)<br>10.26434/chemrxiv.12805280||



electrodes by using filtration assembly techniques. MXenes can also be used as free-standing electrodes in combination with 1D or 2D substrates. Efforts can be made to enhance specific capacity, energy density, power density, duration, cost, and safety of energy storage and conversion devices. To address these difficulties, different methods and techniques for the processing of 2D MXene materials with exceptional chemical stability and endurance should be developed to improve the efficiency of the resulting products. Therefore, solving the above-cited questions will 

facilitate the exploration of 2D MXene nanomaterials in energy storage and energy conversion devices. 

MXenes find their application from energy conversion to energy storage and have proven to be cost-effective due to the ease of their preparation. The applications like SIBs, LIBs, water splitting, and electric charge storage devices need high-performance catalysts that could survive the poisoning and crossover effect and at the same time be affordable. MXenes have proved to be one such family of materials despite having challenges of instability in aqueous media, orientation, and controlled 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 61 

A. Bhat et al. 

18 

fabrication. Given the wide range of alternatives and exceptional electrochemical properties in the family when compared to present materials like metal oxides, it opens a cost-effective fundamental research to satiate our growing energy sector and a race towards affordable and efficient systems. To make MXenes oxidation resistive, besides edge capping of MXenes single flakes with polyanionic salts, Sodium ascorbate, or L-ascorbic acid, the ice-freezing of MXene solution is the only practicable and effective way to long-term storage of MXene suspension. But the drawback is that needs an unperturbed freezing environment typically at −20 °C. However, it is challenging to develop MXene-based 2D layered materials and to prevent them from oxidation to increase their shelf life in the suspension phase at ambient conditions. As of now most of the MXene-based research has centered on the first revealed MXene, Ti3C2Tx. Taking into account exceptional combinations of MXenes characteristics, numerous stoichiometric varieties of MXene offer a way to modify the bandgap and conductivity of required MXenes, by changing the ratios of M or X elements, thus escalating MXene applications. As a future perspective, comprehensive theoretical and experimental strategies are needed to make better use of MXenes merits, through which it is expected to pacify the captivating MXenes to play a winning role in clean energy conversion, flexible electronics, and the energy storage sector. 

Received: 17 August 2020; Accepted: 23 April 2021; 



18. Anasori, B., Lukatskaya, M. R. & Gogotsi, Y. 2D metal carbides and nitrides (MXenes) for energy storage. Nat Rev Mater 2, 16098 (2017). 

19. Anasori, B. et al. Two-dimensional, ordered, double transition metals carbides (MXenes). ACS Nano 9, 9507–9516 (2015). 

20. Gogotsi, Y. & Anasori, B. The rise of MXenes. ACS Nano 13, 8491–8494 (2019). 

21. Petruhins, A., Lu, J., Hultman, L. & Rosen, J. Synthesis of atomically layered and chemically ordered rare-earth (RE) i-MAX phases;(Mo2/3RE1/3) 2GaC with RE= Gd, Tb, Dy, Ho, Er, Tm, Yb, and Lu. Mater. Res. Lett. 7, 446–452 (2019). 

22. Dahlqvist, M. et al. Prediction and synthesis of a family of atomic laminate phases with Kagomé-like and in-plane chemical ordering. Sci. Adv. 3, e1700642 (2017). 

23. Ashton, M., Hennig, R. G., Broderick, S. R., Rajan, K. & Sinnott, S. B. Computational discovery of stable M 2 A X phases. Phys. Rev. B 94, 054116 (2016). 

24. Dahlqvist, M., Petruhins, A., Lu, J., Hultman, L. & Rosen, J. Origin of chemically ordered atomic laminates (i-MAX): expanding the elemental space by a theoretical/experimental approach. ACS Nano 12, 7761–7770 (2018). 

25. Rajan, A. C. et al. Machine-learning-assisted accurate band gap predictions of functionalized MXene. Chem. Mater. 30, 4031–4038 (2018). 

26. Hu, T. et al. Chemical origin of termination-functionalized MXenes: Ti3C2 T 2 as a case study. J. Phys. Chem. C. 121, 19254–19261 (2017). 

27. Zha, X.-H. et al. Role of the surface effect on the structural, electronic and mechanical properties of the carbide MXenes. EPL (Europhys. Lett.) 111, 26007 (2015). 

28. Wang, W.-T. et al. When MOFs meet MXenes: superior ORR performance in both alkaline and acidic solutions.J. Mater. Chem. A 9, 3952–3960 (2021). 

29. Lane, N. J., Barsoum, M. W. & Rondinelli, J. M. Correlation effects and spin-orbit interactions in two-dimensional hexagonal 5d transition metal carbides, Tan+ 1Cn (n= 1, 2, 3). EPL (Europhys. Lett.) 101, 57004 (2013). 

30. Anwer, S. et al. 2D Ti3C2Tx MXene nanosheets coated cellulose fibers based 3D nanostructures for efficient water desalination. Chem. Eng. J. 406, 126827 (2021). 

31. Jiang, X. et al. Inkjet-printed MXene micro-scale devices for integrated broadband ultrafast photonics. npj 2D Mater. Appl. 3, 1–9 (2019). 

32. Luo, S. Tensile behaviors of Ti3C2Tx (MXene) films. Nanotechnology 31, 395704 (2020). 

### REFERENCES 

1. Geim, A. & Novoselov, K. The rise of graphene. In nanoscience and technology: a collection of reviews from nature journals. 1–19 (2009). 

2. Pacile, D., Meyer, J., Girit, Ç. & Zettl, A. The two-dimensional phase of boron nitride: few-atomic-layer sheets and suspended membranes. Appl. Phys. Lett. 92, 133107 (2008). 

3. Wang, Q. H., Kalantar-Zadeh, K., Kis, A., Coleman, J. N. & Strano, M. S. Electronics and optoelectronics of two-dimensional transition metal dichalcogenides. Nat. Nanotechnol. 7, 699 (2012). 

4. Fiori, G. et al. Electronics based on two-dimensional materials. Nat. Nanotechnol. 9, 768 (2014). 

5. Nicolosi, V., Chhowalla, M., Kanatzidis, M. G., Strano, M. S. & Coleman, J. N. Liquid exfoliation of layered materials. Science 340, 1226419 (2013). 

6. Ferrari, A. C. et al. Science and technology roadmap for graphene, related twodimensional crystals, and hybrid systems. Nanoscale 7, 4598–4810 (2015). 

7. Akinwande, D., Petrone, N. & Hone, J. Two-dimensional flexible nanoelectronics. Nat. Commun. 5, 5678 (2014). 

8. Cepellotti, A. et al. Phonon hydrodynamics in two-dimensional materials. Nat. Commun. 6, 6400 (2015). 

9. Xia, F., Wang, H., Xiao, D., Dubey, M. & Ramasubramaniam, A. Two-dimensional material nanophotonics. Nat. Photonics 8, 899 (2014). 

10. Geim, A. K. & Grigorieva, I. V. Van der Waals heterostructures. Nature 499, 419–425 (2013). 

11. Cahangirov, S., Topsakal, M., Aktürk, E., Şahin, H. & Ciraci, S. Two-and onedimensional honeycomb structures of silicon and germanium. Phys. Rev. Lett. 102, 236804 (2009). 

12. Dávila, M., Xian, L., Cahangirov, S., Rubio, A. & Le Lay, G. Germanene: a novel two-dimensional germanium allotrope akin to graphene and silicene. N. J. Phys. 16, 095002 (2014). 

13. Liu, H. et al. Phosphorene: an unexplored 2D semiconductor with a high hole mobility. ACS Nano 8, 4033–4041 (2014). 

14. Li, L. et al. Black phosphorus field-effect transistors. Nat. Nanotechnol. 9, 372 (2014). 

15. Ataca, C., Sahin, H. & Ciraci, S. Stable, single-layer MX2 transition-metal oxides and dichalcogenides in a honeycomb-like structure. J. Phys. Chem. C. 116, 8983–8999 (2012). 

16. Osada, M. & Sasaki, T. Two‐dimensional dielectric nanosheets: novel nanoelectronics from nanocrystal building blocks. Adv. Mater. 24, 210–228 (2012). 

17. Naguib, M. et al. Two‐dimensional nanocrystals produced by exfoliation of Ti3AlC2. Adv. Mater. 23, 4248–4253 (2011). 

33. Cai, G., Ciou, J.-H., Liu, Y., Jiang, Y. & Lee, P. S. Leaf-inspired multiresponsive MXene-based actuator for programmable smart devices. Sci. Adv. 5, eaaw7956 (2019). 

34. Huang, W., Hu, L., Tang, Y., Xie, Z. & Zhang, H. Recent advances in functional 2D MXene-based nanostructures for next-generation devices. Adv. Funct. Mater. 30, 2005223 (2020). 

35. Kim, H. & Alshareef, H. N. MXetronics: MXene-enabled electronic and photonic devices. ACS Mater. Lett. 2, 55–70 (2019). 

36. Sharma, K., Arora, A. & Tripathi, S. K. Review of supercapacitors: materials and devices. J. Energy Storage 21, 801–825 (2019). 

37. Shahzad, F., Iqbal, A., Kim, H. & Koo, C. M. 2D transition metal carbides (MXenes): applications as an electrically conducting material. Adv. Mater. 32, 2002159 (2020). 

38. Xie, Y. et al. Role of surface structure on Li-ion energy storage capacity of twodimensional transition-metal carbides. J. Am. Chem. Soc. 136, 6385–6394 (2014). 

39. Wallace, T. & Butt, D. The Chemistry of Transition Metal Carbides and Nitrides 53–90 (Springer, 1996). 

40. Halim, J. et al. Synthesis and characterization of 2D molybdenum carbide (MXene). Adv. Funct. Mater. 26, 3118–3127 (2016). 

41. Meshkian, R. et al. W‐based atomic laminates and their 2D derivative W1. 33C MXene with vacancy ordering. Adv. Mater. 30, 1706409 (2018). 

42. Urbankowski, P. et al. Synthesis of two-dimensional titanium nitride Ti4N3 (MXene). Nanoscale 8, 11385–11391 (2016). 

43. Chen, W. F. et al. Hydrogen‐evolution catalysts based on non‐noble metal nickel–molybdenum nitride nanosheets. Angew. Chem. Int. Ed. 51, 6131–6135 (2012). 

44. Choi, D., Blomgren, G. E. & Kumta, P. N. Fast and reversible surface redox reaction in nanocrystalline vanadium nitride supercapacitors. Adv. Mater. 18, 1178–1182 (2006). 

45. Naguib, M. et al. MXene: a promising transition metal carbide anode for lithiumion batteries. Electrochem. Commun. 16, 61–64 (2012). 

46. Deysher, G. et al. Synthesis of Mo4VAlC4 MAX phase and two-dimensional Mo4VC4 MXene with five atomic layers of transition metals. ACS Nano 14, 204–217 (2019). 

47. Hong, L.-f. Recent progress of two-dimensional MXenes in photocatalytic applications: a review. Mater Today Energy 18, 100521 (2020). 

48. Naguib, M., Mochalin, V. N., Barsoum, M. W. & Gogotsi, Y. 25th anniversary article: MXenes: a new family of two‐dimensional materials. Adv. Mater. 26, 992–1005 (2014). 

49. Anasori, B., Lukatskaya, M. R. & Gogotsi, Y. 2D metal carbides and nitrides (MXenes) for energy storage. Nat. Rev. Mater. 2, 1–17 (2017). 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 61 

A. Bhat et al. 

19 

50. Cambaz, G. Z., Yushin, G. N., Gogotsi, Y. & Lutsenko, V. G. Anisotropic etching of SiC whiskers. Nano Lett. 6, 548–551 (2006). 

51. Barsoum, M., El-Raghy, T. & Ali, M. Processing and characterization of Ti 2 AlC, Ti 2 AlN, and Ti 2 AlC 0.5 N 0.5. Metall. Mater. Trans. A 31, 1857–1865 (2000). 

52. Ng, V. M. H. et al. Recent progress in layered transition metal carbides and/or nitrides (MXenes) and their composites: synthesis and applications. J. Mater. Chem. A 5, 3039–3068 (2017). 

53. Barsoum, M. W. The MN+ 1AXN phases: a new class of solids: thermodynamically stable nanolaminates. Prog. Solid State Chem. 28, 201–281 (2000). 

54. Naguib, M. et al. Two-dimensional transition metal carbides. ACS Nano 6, 1322–1331 (2012). 

55. Halim, J. et al. Transparent conductive two-dimensional titanium carbide epitaxial thin films. Chem. Mater. 26, 2374–2381 (2014). 

56. Ghidiu, M., Lukatskaya, M. R., Zhao, M.-Q., Gogotsi, Y. & Barsoum, M. W. Conductive two-dimensional titanium carbide ‘clay’with high volumetric capacitance. Nature 516, 78 (2014). 

57. Mashtalir, O., Naguib, M., Dyatkin, B., Gogotsi, Y. & Barsoum, M. W. Kinetics of aluminum extraction from Ti3AlC2 in hydrofluoric acid. Mater. Chem. Phys. 139, 147–152 (2013). 

58. Hart, J. L. et al. Control of MXenes’ electronic properties through termination and intercalation. Nat. Commun. 10, 1–10 (2019). 

59. Hantanasirisakul, K. et al. Effects of synthesis and processing on optoelectronic properties of titanium carbonitride MXene. Chem. Mater. 31, 2941–2951 (2019). 

60. Bafekry, A., Shayesteh, S. F. & Peeters, F. M. Two-dimensional carbon nitride (2DCN) nanosheets: Tuning of novel electronic and magnetic properties by hydrogenation, atom substitution and defect engineering. J. Appl. Phys. 126, 215104 (2019). 

61. Tang, Q., Zhou, Z. & Shen, P. Are MXenes promising anode materials for Li ion batteries? Computational studies on electronic properties and Li storage capability of Ti3C2 and Ti3C2X2 (X= F, OH) monolayer. J. Am. Chem. Soc. 134, 16909–16916 (2012). 

62. Alhabeb, M. et al. Guidelines for synthesis and processing of two-dimensional titanium carbide (Ti3C2T x MXene). Chem. Mater. 29, 7633–7644 (2017). 

63. Jun, B.-M. et al. Review of MXenes as new nanomaterials for energy storage/ delivery and selected environmental applications. Nano Res. 12, 471–487 (2019). 

64. Quain, E. et al. Direct writing of additive‐free MXene‐in‐Water ink for electronics and energy storage. Adv. Mater. Technol. 4, 1800256 (2019). 

65. Anasori, B. & Gogotsi, Y. 2D Metal Carbides and Nitrides (MXenes): Structure, Properties and Applications (Springer, 2019). 

66. Cheng, L., Wang, X., Gong, F., Liu, T. & Liu, Z. 2D nanomaterials for cancer theranostic applications. Adv. Mater. 32, 1902333 (2020). 

67. Sarycheva, A. et al. 2D titanium carbide (MXene) for wireless communication. Sci. Adv. 4, eaau0920 (2018). 

68. Sun, S., Liao, C., Hafez, A. M., Zhu, H. & Wu, S. Two-dimensional MXenes for energy storage. Chem. Eng. J. 338, 27–45 (2018). 

69. Lim, K. R. G. et al. Rational design of two-dimensional transition metal carbide/ nitride (MXene) hybrids and nanocomposites for catalytic energy storage and conversion. ACS Nano 14, 10834–10864 (2020). 

70. Liang, J. et al. Heterostructure engineering of Co-doped MoS 2 coupled with Mo 2 CT x MXene for enhanced hydrogen evolution in alkaline media. Nanoscale 11, 10992–11000 (2019). 

71. Ren, J. et al. 2D organ-like molybdenum carbide (MXene) coupled with MoS 2 nanoflowers enhances the catalytic activity in the hydrogen evolution reaction. CrystEngComm 22, 1395–1403 (2020). 

72. Li, S., Sun, J. & Guan, J. Strategies to improve electrocatalytic and photocatalytic performance of two-dimensional materials for hydrogen evolution reaction. Chin. J. Catal. 42, 511–556 (2021). 

73. Kuznetsov, D. A. et al. Single site cobalt substitution in 2D molybdenum carbide (MXene) enhances catalytic activity in the hydrogen evolution reaction. J. Am. Chem. Soc. 141, 17809–17816 (2019). 

74. Djire, A., Zhang, H., Liu, J., Miller, E. M. & Neale, N. R. Electrocatalytic and optoelectronic characteristics of the two-dimensional titanium nitride Ti4N3Tx MXene. ACS Appl. Mater. interfaces 11, 11812–11823 (2019). 

75. Xie, X. et al. Porous heterostructured MXene/carbon nanotube composite paper with high volumetric capacity for sodium-based energy storage devices. Nano Energy 26, 513–523 (2016). 

76. Du, C. F. et al. Self‐assemble and in situ formation of Ni1−xFexPS3 nanomosaic‐ decorated MXene hybrids for overall water splitting. Adv. Energy Mater. 8, 1801127 (2018). 

77. Hao, C. et al. Interface-coupling of CoFe-LDH on MXene as high-performance oxygen evolution catalyst. Mater Today Energy 12, 453–462 (2019). 

78. Zhu, X.-D., Xie, Y. & Liu, Y.-T. Exploring the synergy of 2D MXene-supported black phosphorus quantum dots in hydrogen and oxygen evolution reactions. J. Mater. Chem. A 6, 21255–21260 (2018). 

79. Wang, H. & Lee, J.-M. Recent advances in structural engineering of MXene electrocatalysts. J. Mater. Chem. A 8, 10604–10624 (2020). 

80. Seh, Z. W. et al. Two-dimensional molybdenum carbide (MXene) as an efficient electrocatalyst for hydrogen evolution. ACS Energy Lett. 1, 589–594 (2016). 

81. Liu, C.-Y. & Li, E. Y. Termination effects of Pt/v-Ti n+ 1C n T2 MXene surfaces for oxygen reduction reaction catalysis. ACS Appl. Mater. interfaces 11, 1638–1644 (2018). 

82. Regmi, Y. N. et al. Carbides of group IVA, VA and VIA transition metals as alternative HER and ORR catalysts and support materials. J. Mater. Chem. A 3, 10085–10091 (2015). 

83. Peng, J., Chen, X., Ong, W.-J., Zhao, X. & Li, N. Surface and heterointerface engineering of 2D MXenes and their nanocomposites: insights into electro-and photocatalysis. Chem 5, 18–50 (2019). 

84. Zhang, H. et al. Computational studies on the structural, electronic and optical properties of graphene-like MXenes (M 2 CT 2, M= Ti, Zr, Hf; T= O, F, OH) and their potential applications as visible-light driven photocatalysts. J. Mater. Chem. A 4, 12913–12920 (2016). 

85. Yun, S., Vlachopoulos, N., Qurashi, A., Ahmad, S. & Hagfeldt, A. Dye sensitized photoelectrolysis cells. Chem. Soc. Rev. 48, 3705–3722 (2019). 

86. Wang, Y. Challenges and opportunities in utilizing MXenes of carbides and nitrides as electrocatalysts. Adv Energy Mater 11, 2002967 (2021). 

87. Liu, Y. et al. Regulating electron-hole separation to promote photocatalytic H2 evolution activity of nanoconfined Ru/MXene/TiO2 catalysts. ACS Nano 14, 14181–14189 (2020). 

88. Liu, Y. et al. A novel bicomponent Co3S4/Co@ C cocatalyst on CdS, accelerating charge separation for highly efficient photocatalytic hydrogen evolution. Green. Chem. 22, 238–247 (2020). 

89. Cao, S., Shen, B., Tong, T., Fu, J. & Yu, J. 2D/2D heterojunction of ultrathin MXene/Bi2WO6 nanosheets for improved photocatalytic CO2 reduction. Adv. Funct. Mater. 28, 1800136 (2018). 

90. Qurashi, A., Zhang, Z., Asif, M. & Yamazaki, T. Template-less surfactant-free hydrothermal synthesis NiO nanoflowers and their photoelectrochemical hydrogen production. Int. J. Hydrog. Energy 40, 15801–15805 (2015). 

91. Liu, Y. et al. 2H-and 1T-mixed phase few-layer MoS2 as a superior to Pt cocatalyst coated on TiO2 nanorod arrays for photocatalytic hydrogen evolution. Appl. Catal. B: Environ. 241, 236–245 (2019). 

92. Xiao, R. et al. In situ fabrication of 1D CdS nanorod/2D Ti3C2 MXene nanosheet Schottky heterojunction toward enhanced photocatalytic hydrogen evolution. Appl. Catal. B: Environ. 268, 118382 (2020). 

93. Ran, J. et al. Ti3C2 MXene co-catalyst on metal sulfide photo-absorbers for enhanced visible-light photocatalytic hydrogen production. Nat. Commun. 8, 1–10 (2017). 

94. Wang, T. et al. Multidimensional CdS nanowire/CdIn2S4 nanosheet heterostructure for photocatalytic and photoelectrochemical applications. Nano Res. 10, 2699–2711 (2017). 

95. Wang, H. et al. Semiconductor heterojunction photocatalysts: design, construction, and photocatalytic performances. Chem. Soc. Rev. 43, 5234–5244 (2014). 

96. Khan, I., Jalilov, A., Fujii, K. & Qurashi, A. Quasi-1D Aligned nanostructures for solar-driven water splitting applications: challenges, promises, and perspectives. Solar RRL n/a, 2000741. https://doi.org/10.1002/solr.202000741 (2021). 

97. Huang, K., Li, C. & Meng, X. In-situ construction of ternary Ti3C2 MXene@ TiO2/ ZnIn2S4 composites for highly efficient photocatalytic hydrogen evolution. J. Colloid Interface Sci. 580, 669–680 (2020). 

98. Li, Y., Deng, X., Tian, J., Liang, Z. & Cui, H. Ti3C2 MXene-derived Ti3C2/TiO2 nanoflowers for noble-metal-free photocatalytic overall water splitting. Appl. Mater. Today 13, 217–227 (2018). 

99. Xia, Y., Li, Q., Lv, K. & Li, M. Heterojunction construction between TiO2 hollowsphere and ZnIn2S4 flower for photocatalysis application. Appl. Surf. Sci. 398, 81–88 (2017). 

100. Kashiwaya, S. et al. The work function of TiO2. Surfaces 1, 73–89 (2018). 

101. Guo, Z., Zhou, J., Zhu, L. & Sun, Z. MXene: a promising photocatalyst for water splitting. J. Mater. Chem. A 4, 11446–11452 (2016). 

102. Wang, H. et al. Electrical promotion of spatially photoinduced charge separation via interfacial-built-in quasi-alloying effect in hierarchical Zn2In2S5/Ti3C2 (O, OH) x hybrids toward efficient photocatalytic hydrogen evolution and environmental remediation. Appl. Catal. B: Environ. 245, 290–301 (2019). 

103. Sun, D. et al. Structural transformation of MXene (V2C, Cr2C, and Ta2C) with O groups during lithiation: a first-principles investigation. ACS Appl. Mater. interfaces 8, 74–81 (2015). 

104. Ren, C. E. et al. Porous two‐dimensional transition metal carbide (MXene) flakes for high‐performance Li‐ion storage. ChemElectroChem 3, 689–693 (2016). 

105. Wang, X. et al. Pseudocapacitance of MXene nanosheets for high-power sodium-ion hybrid capacitors. Nat. Commun. 6, 6544 (2015). 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 61 

A. Bhat et al. 

20 

106. Dall’Agnese, Y., Taberna, P.-L., Gogotsi, Y. & Simon, P. Two-dimensional vanadium carbide (MXene) as positive electrode for sodium-ion capacitors. J. Phys. Chem. Lett. 6, 2305–2309 (2015). 

107. Ji, X. et al. Probing the electrochemical capacitance of MXene nanosheets for high-performance pseudocapacitors. Phys. Chem. Chem. Phys. 18, 4460–4467 (2016). 

108. Wang, X. et al. Atomic-scale recognition of surface structure and intercalation mechanism of Ti3C2X. J. Am. Chem. Soc. 137, 2715–2721 (2015). 

109. Yu, X.-f et al. Mg intercalation into Ti2C building block. Chem. Phys. Lett. 629, 36–39 (2015). 

110. Mashtalir, O. et al. Intercalation and delamination of layered carbides and carbonitrides. Nat. Commun. 4, 1716 (2013). 

111. Naguib, M. et al. New two-dimensional niobium and vanadium carbides as promising materials for Li-ion batteries. J. Am. Chem. Soc. 135, 15966–15969 (2013). 

112. Liang, X., Garsuch, A. & Nazar, L. F. Sulfur cathodes based on conductive MXene nanosheets for high‐performance lithium–sulfur batteries. Angew. Chem. Int. Ed. 54, 3907–3911 (2015). 

113. Zhao, X. et al. Fabrication of layered Ti3C2 with an accordion-like structure as a potential cathode material for high performance lithium–sulfur batteries. J. Mater. Chem. A 3, 7870–7876 (2015). 

114. Li, J. et al. Achieving high pseudocapacitance of 2D titanium carbide (MXene) by cation intercalation and surface modification. Adv. Energy Mater. 7, 1602725 (2017). 

115. Kamysbayev, V. et al. Covalent surface modifications and superconductivity of two-dimensional metal carbide MXenes. Science 369, 979–983 (2020). 

116. Pech, D. et al. Elaboration of a microstructured inkjet-printed carbon electrochemical capacitor. J. Power Sources 195, 1266–1269 (2010). 

117. Zhang, C. J. et al. Additive-free MXene inks and direct printing of microsupercapacitors. Nat. Commun. 10, 1–9 (2019). 

118. Yu, L. et al. Versatile N‐doped MXene ink for printed electrochemical energy storage application. Adv. Energy Mater. 9, 1901839 (2019). 

119. Wu, C.-W. et al. Excellent oxidation resistive MXene aqueous ink for microsupercapacitor application. Energy Storage Mater. 25, 563–571 (2020). 

120. Li, H., Li, X., Liang, J. & Chen, Y. Hydrous RuO2‐decorated MXene coordinating with silver nanowire inks enabling fully printed micro‐supercapacitors with extraordinary volumetric performance. Adv. Energy Mater. 9, 1803987 (2019). 

121. Choi, J. W. & Aurbach, D. Promise and reality of post-lithium-ion batteries with high energy densities. MNat. Rev. Mater. 1, 16013 (2016). 

122. Blomgren, G. E. The development and future of lithium ion batteries. J. Electrochem. Soc. 164, A5019–A5025 (2017). 

123. Li, M., Lu, J., Chen, Z. & Amine, K. 30 years of lithium‐ion batteries. Adv. Mater. 30, 1800561 (2018). 

124. Wang, G., Shen, X., Yao, J. & Park, J. Graphene nanosheets for enhanced lithium storage in lithium ion batteries. Carbon 47, 2049–2053 (2009). 

125. Bonaccorso, F. et al. Graphene, related two-dimensional crystals, and hybrid systems for energy conversion and storage. Science 347, 1246501 (2015). 

126. Feng, F., Wu, J., Wu, C. & Xie, Y. Regulating the electrical behaviors of 2D inorganic nanomaterials for energy applications. Small 11, 654–666 (2015). 

127. Eames, C. & Islam, M. S. Ion intercalation into two-dimensional transition-metal carbides: global screening for new high-capacity battery materials. J. Am. Chem. Soc. 136, 16270–16276 (2014). 

128. Jiang, H. et al. 2D monolayer MoS2–carbon interoverlapped superstructure: engineering ideal atomic interface for lithium ion storage. Adv. Mater. 27, 3687–3695 (2015). 

129. Yu, X., Pei, C., Chen, W. & Feng, L. 2 dimensional WS2 tailored nitrogen-doped carbon nanofiber as a highly pseudocapacitive anode material for lithium-ion battery. Electrochim. Acta 272, 119–126 (2018). 

130. Wang, S. et al. Layered g-C3N4@ reduced graphene oxide composites as anodes with improved rate performance for lithium-ion batteries. ACS Appl. Mater. interfaces 10, 30330–30336 (2018). 

131. Nan, J. et al. Nanoengineering of 2D MXene-based materials for energy storage applications. Small 17, 1902085 (2020). 

132. Fan, Z. et al. Modified MXene/holey graphene films for advanced supercapacitor electrodes with superior energy storage. Adv. Sci. 5, 1800750 (2018). 

133. Yan, J. et al. Flexible MXene/graphene films for ultrafast supercapacitors with outstanding volumetric capacitance. Adv. Funct. Mater. 27, 1701264 (2017). 

134. Zhu, Y. et al. Multiple roles of a heterointerface in two-dimensional van der Waals heterostructures: insights into energy-related applications. J. Mater. Chem. A 7, 23577–23603 (2019). 

135. Chen, C. et al. MoS2‐on‐MXene heterostructures as highly reversible anode materials for lithium‐ion batteries. Angew. Chem. Int. Ed. 57, 1846–1850 (2018). 

136. Anwer, S. et al. Nature-inspired, graphene-wrapped 3D MoS2 ultrathin microflower architecture as a high-performance anode material for sodium-ion batteries. ACS Appl. Mater. Interfaces 11, 22323–22331 (2019). 

137. Liu, T. et al. Exploring competitive features of stationary sodium ion batteries for electrochemical energy storage. Energy Environ. Sci. 12, 1512–1533 (2019). 

138. Cao, Y. et al. Sodium ion insertion in hollow carbon nanowires for battery applications. Nano Lett. 12, 3783–3787 (2012). 

139. Kang, W., Wang, Y. & Xu, J. Recent progress in layered metal dichalcogenide nanostructures as electrodes for high-performance sodium-ion batteries. J. Mater. Chem. A 5, 7667–7690 (2017). 

140. Chayambuka, K., Mulder, G., Danilov, D. L. & Notten, P. H. Sodium-ion battery materials and electrochemical properties reviewed. Adv. Energy Mater 8, 1800079 (2018). 

141. Pang, J. et al. Applications of 2D MXenes in energy conversion and storage systems. Chem. Soc. Rev. 48, 72–133 (2019). 

142. Geng, D., Cheng, Y. & Zhang, G. Layered materials for energy storage and conversion. Vol. 34 (Royal Society of Chemistry, 2019). 

143. Li, J. et al. Improved sodium-ion storage performance of Ti3C2Tx MXenes by sulfur doping. J. Mater. Chem. A 6, 1234–1243 (2018). 

144. Zhao, M. Q. et al. Hollow MXene spheres and 3D macroporous MXene frameworks for Na‐ion storage. Adv. Mater. 29, 1702410 (2017). 

145. Xiong, D., Li, X., Bai, Z. & Lu, S. Recent advances in layered Ti3C2Tx MXene for electrochemical energy storage. Small 14, 1703419 (2018). 

146. Yu, T. et al. TiC3 monolayer with high specific capacity for sodium-ion batteries. J. Am. Chem. Soc. 140, 5962–5968 (2018). 

147. Kajiyama, S. et al. Sodium-ion intercalation mechanism in MXene nanosheets. ACS nano 10, 3334–3341 (2016). 

148. Lian, P. et al. Alkalized Ti3C2 MXene nanoribbons with expanded interlayer spacing for high-capacity sodium and potassium ion batteries. Nano Energy 40, 1–8 (2017). 

149. Guo, X. et al. Sb2O3/MXene (Ti3C2Tx) hybrid anode materials with enhanced performance for sodium-ion batteries. J. Mater. Chem. A 5, 12445–12452 (2017). 

150. Sun, S., Xie, Z., Yan, Y. & Wu, S. Hybrid energy storage mechanisms for sulfurdecorated Ti3C2 MXene anode material for high-rate and long-life sodium-ion batteries. Chem. Eng. J. 366, 460–467 (2019). 

151. Deng, Z. et al. Electrochemical impedance spectroscopy study of a lithium/sulfur battery: modeling and analysis of capacity fading. J. Electrochem. Soc. 160, A553 (2013). 

152. Zhao, D. et al. Alkali-induced 3D crinkled porous Ti3C2 MXene architectures coupled with NiCoP bimetallic phosphide nanoparticles as anodes for highperformance sodium-ion batteries. Energy Environ. Sci. 12, 2422–2432 (2019). 

153. Ge, X., Li, Z. & Yin, L. Metal-organic frameworks derived porous core/shellCoP@ C polyhedrons anchored on 3D reduced graphene oxide networks as anode for sodium-ion battery. Nano Energy 32, 117–124 (2017). 

154. Wang, X. W. et al. An integrated free‐standing flexible electrode with holey‐ structured 2D bimetallic phosphide nanosheets for sodium‐ion batteries. Adv. Funct. Mater. 28, 1801016 (2018). 

155. Li, X. et al. Cactus‐like NiCoP/NiCo‐OH 3D architecture with tunable composition for high‐performance electrochemical capacitors. Adv. Funct. Mater. 28, 1800036 (2018). 

156. Habib, T. et al. Oxidation stability of Ti3C2Tx MXene nanosheets in solvents and composite films. npj 2D Mater. Appl. 3, 8 (2019). 

157. Zhang, C. J. et al. Oxidation stability of colloidal two-dimensional titanium carbides (MXenes). Chem. Mater. 29, 4848–4856 (2017). 

158. Zhao, X. et al. Antioxidants unlock shelf-stable Ti3C2Tx (MXene) nanosheet dispersions. Matter 1, 513–526 (2019). 

159. Natu, V. et al. Edge capping of 2D‐MXene sheets with polyanionic salts to mitigate oxidation in aqueous colloidal suspensions. Angew. Chem. Int. Ed. 58, 12655–12660 (2019). 

160. Chae, Y. et al. An investigation into the factors governing the oxidation of twodimensional Ti3C2 MXene. Nanoscale 11, 8387–8393 (2019). 

### ACKNOWLEDGEMENTS 

This publication is based upon work supported by the Khalifa University of Science and Technology under Award No. FSU-2020-01 (A.Q.). 

### AUTHOR CONTRIBUTIONS 

The idea was conceived by A.Q. and started writing initially draft with A.B. Ms Anha Bhat drafted initial sections under the supervision of A.Q. and compiled first draft of the manuscript. S.A. contributed to the overall article and included more on energy conversion and storage, up-to-date work on stability of MXene. Moreover, he has significantly improved manuscript including technical comments that make him eligible for equal contribution as first author. K.S.B. involved in middle of the article and contributed some sections and later revised overall manuscript. M.I.H.M. reviewed the overall draft with some changes and added some portion/figure in the middle and helped in revision of the manuscript. K.L. reviewed the overall draft couple of times along with A.Q. 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 61 

A. Bhat et al. 

21 

COMPETING INTERESTS 

The authors declare no competing interests. 

### ADDITIONAL INFORMATION 

Correspondence and requests for materials should be addressed to A.Q. 

Reprints and permission information is available at http://www.nature.com/ reprints 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons. org/licenses/by/4.0/. 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

© The Author(s) 2021 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 61 

