# Tripodal Triazatruxene Derivative as a Face-On Oriented Hole-Collecting Monolayer for Efficient and Stable Inverted Perovskite Solar Cells.

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Journal of the American Chemical Society |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 180 |
| 作者 | M. Truong, Tsukasa Funasaki, Lucas Ueberricke, Wataru Nojo, R. Murdey, Takumi Yamada, Shuai-Feng Hu, Aruto Akatsuka et al. |
| DOI | 10.1021/jacs.3c00805 |
| 源文件 | 062_Truong_2023_Tripodal-Triazatruxene-Derivative-as-a-Face-On-O.pdf |

---
# **A Tripodal Triazatruxene Derivative as a Face-On Oriented HoleCollecting Monolayer for Efficient and Stable Inverted Perovskite Solar Cells** 

Minh Anh Truong,*<sup>,1</sup> Tsukasa Funasaki,<sup>‡,1</sup> Lucas Ueberricke,<sup>‡,1</sup> Wataru Nojo,<sup>‡,1,2</sup> Richard Murdey,<sup>1</sup> Takumi Yamada,<sup>1</sup> Shuaifeng Hu,<sup>1</sup> Aruto Akatsuka,<sup>3</sup> Naomu Sekiguchi,<sup>4</sup> Shota Hira,<sup>1</sup> Lingling Xie,<sup>1</sup> Tomoya Nakamura,<sup>1</sup> Nobutaka Shioya,<sup>1</sup> Daisuke Kan,<sup>1</sup> Yuta Tsuji,<sup>5</sup> Satoshi Iikubo,<sup>4</sup> Hiroyuki Yoshida,<sup>3,6,7</sup> Yuichi Shimakawa,<sup>1</sup> Takeshi Hasegawa,<sup>1</sup> Yoshihiko Kanemitsu,<sup>1</sup> Takanori Suzuki,<sup>2</sup> Atsushi Wakamiya*<sup>,1</sup> 

1Institute for Chemical Research, Kyoto University, Gokasho, Uji, Kyoto, 611-0011, Japan. 

2Department of Chemistry, Faculty of Science, Hokkaido University, Sapporo, 060-0810, Japan. 

3Graduate School of Science and Engineering, Chiba University, 1-33 Yayoi-cho, Inage-ku, Chiba, 263-8522, Japan. 

4Department of Advanced Materials Science and Engineering, Faculty of Engineering Sciences, Kyushu University, Kasuga, Fukuoka, 816-8580, Japan. 

5Department of Advanced Analytical Science for Materials and Devices, Faculty of Engineering Sciences, Kyushu University, Kasuga, Fukuoka, 816-8580, Japan. 

6Graduate School of Engineering, Chiba University, 1-33 Yayoi-cho, Inage-ku, Chiba, 263-8522, Japan. 

7Molecular Chirality Research Center, Chiba University, 1-33 Yayoi-cho, Inage-ku, Chiba, 263-8522, Japan. 

_KEYWORDS: perovskite solar cells, triazatruxene, hole collection, monolayer, chemisorption._ 

**ABSTRACT:** Hole-collecting monolayers have drawn attention in perovskite solar cell research due to their ease of processing, high performance, and good durability. Since molecules in the hole-collecting monolayer are typically composed of functionalized  -conjugated structures, hole extraction is expected to be more efficient when the  -cores are oriented face-on with respect to the adjacent surfaces. However, strategies for reliably controlling the molecular orientation in monolayers remain elusive. In this work, multiple phosphonic acid anchoring groups were used to control the molecular orientation of a series of triazatruxene derivatives chemisorbed on a transparent conducting oxide electrode surface. Using infrared reflection absorption spectroscopy and metastable atom electron spectroscopy, we found that multipodal derivatives align face-on to the electrode surface, while the monopodal counterpart adopts a more tilted configuration. The face-on orientation was found to facilitate hole extraction, leading to inverted perovskite solar cells with enhanced stability and high power conversion efficiencies up to 23.0%. 

## **INTRODUCTION** 

As solar energy is the most abundant renewable energy source, the development of photovoltaics with high efficiency, long-term stability and low cost is vital for realizing a carbon-neutral society. Among next-generation photovoltaics, perovskite solar cells (PSCs) are one of the most promising technologies<sup>1–3</sup> with power conversion efficiencies (PCEs) increasing rapidly to above 25%.<sup>4–9</sup> 

Typical PSC devices are composed of five layers; a transparent electrode, an n-type semiconductor (electroncollecting material, ECM), a light absorbing perovskite, a p-type semiconductor (hole-collecting material, HCM), and a metal electrode. The structure is characterized as 

regular (n-i-p) or inverted (p-i-n), depending on whether electrons or holes are extracted to the transparent bottom electrode, respectively.<sup>10,11</sup> So far, the performance of inverted PSCs still lags behind that of their regular counterparts.<sup>8,9</sup> However, compared to the regular PSCs with metal oxide typically being used as a bottom ECM, inverted PSCs with bottom organic HCM are more suitable for flexible or tandem devices due to their lower processing temperature<sup>12</sup> and lower parasitic absorption loss in the front contact.<sup>13–15</sup> Moreover, hygroscopic dopants which are usually needed for the HCMs in regular PSCs can be omitted, leading to enhanced long-term stability.<sup>16</sup> Therefore, in order to extend the application range of PSCs, it is crucial to improve the performance of the inverted PSC devices. 

## a) Conventional Monopodal Strategy: 



<!-- Start of picture text -->
Perovskite<br>Metal oxide<br><!-- End of picture text -->

## b) Multipodal Strategy: 

Perovskite Metal oxide 



































































































**Figure 1.** Molecular design concept for hole-collecting monolayer materials with (a) conventional monopodal strategy and (b) multipodal strategy. 



**Figure 2.** Molecular structures of triazatruxene based hole-collecting monolayer ( **PATAT** ) materials. 

Besides the film and interfacial engineering of the perovskite layer, the development of HCMs is critical to boost the device performance of inverted PSCs. In addition to performing hole extraction and transport functions, the HCM also impacts the quality of the solution-processed perovskite films.<sup>17,18</sup> Chemically adsorbed monolayers have recently outperformed conventional HCMs including organic materials (e.g., poly(3,4ethylenedioxythiophene):poly(styrenesulfonate) (PEDOT:PSS), poly[bis(4-phenyl)(2,4,6trimethylphenyl)amine] (PTAA)),<sup>19</sup> as well as inorganic metal oxides (e.g., NiOx,<sup>20</sup> CuOx<sup>21</sup> ) in terms of both optical transparency and electrical conductivity. The viability of this concept was first demonstrated by Magomedov et al. in 2018.<sup>22</sup> They used carbazole derivatives (known as **PACz** series) with phosphonic acid anchoring groups which spontaneously adsorb onto the surface of metal oxide substrates to form a conformal monolayer. Since then, several molecules with further structural modifications have been reported to function as hole-collecting monolayers.<sup>23–38</sup> All 

these structures are composed of a  -conjugated backbone connected to a single anchoring group. When chemically adsorbed, these monopodal molecules tend to orient with their  -plane perpendicular (edge-on) to the metal oxide surface.<sup>39,40</sup> This molecular alignment could result in inefficient orbital overlap with the perovskite surface and/or unsought hole transport in the lateral direction, causing undesired interfacial recombination and interfering with the hole extraction process ( **Figure 1a** ).<sup>22,41,42</sup> 

In this work, we propose a multipodal strategy to demonstrate the advantages of molecules with multiple anchoring sites ( **Figure 1b** ). Multiple anchoring groups lock a face-on orientation of the  -conjugated backbone with respect to the substrate, resulting in suppressed interfacial recombination and better hole extraction. The concept was realized through the design and synthesis of a series of phosphonic acid ( **PA** )-functionalized triazatruxene ( **TAT** ) derivatives, namely **xPATAT-Cy** (x is the anchor number x = 1, 2, or 3, while y defines the carbon number in the spacer y = 3 or 4) ( **Figure 2** ). **TAT** was chosen due to its 

planar  -structure and ease of derivatization via three nitrogen atoms. 

The effect of the number of anchors on the performance of inverted perovskite solar cells was investigated by comparing tripodal **3PATAT-C3** with dipodal **2PATAT-C3** and monopodal **1PATAT-C3** . To confirm the influence of the spacer length, **3PATAT-C3** was also compared against its longer homologue **3PATAT-C4** . We confirmed that all the **PATAT** derivatives form monolayers on both indium tin oxide (ITO) and fluoride-doped tin oxide (FTO) surfaces via a bidentate binding mode of the phosphonic acid groups. Multipodal derivatives tend to align parallel (faceon) to the metal oxide surface, resulting in improved hole extraction. The PCE of the inverted device with tripodal **3PATAT-C3** as the hole-collecting monolayer reached 23.0%. The operational stability was superior to both the monopodal and dipodal **PATAT** derivatives. These promising results for the face-on oriented monolayers pave the way for the development of efficient charge-collecting monolayers for PSCs. 

## **RESULTS AND DISCUSSION** 

**Synthesis and Photophysical Properties of Bulk Materials.** The synthetic routes of the triazatruxene derivatives are shown in **Scheme S1** and the detailed procedures 

are provided in Supporting Information. The triazatruxene core ( **TAT** ) was synthesized in 41% yield by intermolecular condensation of oxindole in neat phosphoryl chloride at 100  C for 14 h.<sup>43,44</sup> The obtained product was deprotonated by treating with 1, 2, and 3 equiv of sodium hydride in _N,N_ - dimethylformamide at room temperature, followed by nucleophilic substitution reaction with diethyl(3-bromopropyl)phosphonate at 70  C to give mono- (20% yield), di(22% yield), and triphosphonate substituted compound (49% yield) with three carbon spacers, respectively. As diethyl(4-bromobutyl)phosphonate was not commercially available, 1,4-dibromobutane was chosen as a reactant for the synthesis of the molecule with the four-carbon spacer. The tribromo intermediate was obtained in 70% yield after treatment of **TAT** with 6 equiv of sodium hydride, followed by alkylation reaction with 1,4-dibromobutane. The aliphatic bromide moieties were then transformed into phosphonic acid ethyl esters in quantitative yield by the Arbuzov reaction in neat triethylphosphite at 150  C.<sup>45</sup> The treatment of these ester precursors with bromotrimethylsilane<sup>46</sup> gave the targets **1PATAT-C3** (45% yield), **2PATAT-C3** (37% yield), **3PATAT-C3** (77% yield), and **3PATAT-C4** (74% yield), respectively. 



<!-- Start of picture text -->
a)<br>Bare ITO 1PATAT-C3 3PATAT-C3<br>Contact angle = 8° 74° 75°<br>b) c)<br>in o-DCB solution Working electrode ITO/ 3PATAT-C3<br>Bare ITO<br>50 mA ITO/ 3PATAT-C3<br>5.44 eV<br>E pa = +0.49 V<br>– –<br>1.0 0.8 0.6 0.4 0.2 0.0 - 0.2 - 0.4 4.0 4.5 5.0 5.5 6.0 6.5 7.0<br>Potential (V vs Fc/Fc + ) Photon energy (eV)<br>Current<br>1/31/3Emission yield (cps)<br><!-- End of picture text -->

**Figure 3.** a) Contact angles of the water droplets on bare ITO, **1PATAT-C3** , and **3PATAT-C3** adsorbed ITO substrates. b) CVs using bare ITO or **3PATAT-C3** adsorbed ITO substrate as a working electrode measured in 1,2-dichlorobenzene ( _o_ - DCB) solution at a scan rate of 100 mV s<sup>–1</sup> . c) PYS result of the **3PATAT-C3** adsorbed ITO substrate. 

The chemical structures of the synthesized molecules were verified by nuclear magnetic resonance (NMR) and high-resolution mass spectrometry. All the final compounds are soluble in highly polar solvents, such as methanol, _N,N_ -dimethylformamide (DMF), dimethyl sulfoxide (DMSO), and _N_ -methyl-2-pyrrolidone (NMP). 

Ultraviolet-visible (UV–Vis) absorption spectroscopy was used to investigate the photophysical properties of the **PATAT** series in DMF solution ( **Figure S1** ). The absorption spectra for these compounds are almost identical and show maximum absorption peaks in a range of 308–324 nm attributed to the  –  _*_ electronic transitions of the triazatruxene cores. The **PATAT** series (  edge = 385 nm) exhibits higher transmittance in the near-ultraviolet region even compared to the well-established 3,6-dimethoxycarbazole derivative **MeO-2PACz** (  edge = 398 nm) or PTAA (  edge = 415 nm). 

**Monolayer Fabrication and Characterization.** Films of **PATAT** molecules were fabricated on both ITO and FTO substrates by spin-coating from DMF solution (0.1 mM). Details on the fabrication process are provided in the Supporting Information. 

The existence of an organic layer on the treated metal oxide surfaces can be verified by observing the change in contact angle. As shown in **Figure 3a** and **S2** , the contact 

angle of a water droplet on a bare ITO substrate was 8  , while those of **PATAT** -treated ITO substrates were estimated at around 75  . The large contact angle of the treated surfaces suggests a more hydrophobic surface. The contact angle is also independent of the number of phosphonic acid groups on the **PATAT** molecules, indicating that all the hydrophilic phosphonic acid groups are bound to the oxide surface or at least pointing towards it.<sup>47,48</sup> 

The presence of the **PATAT** derivatives at the ITO surface was also confirmed by comparing cyclic voltammograms (CVs) using bare ITO or **3PATAT-C3** modified ITO as a working electrode ( **Figure 3b** ). No peak is observed for the bare ITO electrode, while a reversible oxidation wave at +0.49 V vs Fc/Fc<sup>+</sup> is readily observed for the **3PATAT-C3** modified ITO electrode, similar to the signal observed for **3PATAT-C3** dissolved in DMF solution (+0.50 V vs Fc/Fc<sup>+</sup> , **Figure S3** ). Similar oxidation waves are also observed for other **PATAT** derivatives ( **Figure S4** ). 

The energies of the highest occupied molecular orbitals (HOMOs) of **PATAT** derivatives were derived from the ionization potentials measured using photoelectron yield spectroscopy (PYS). The HOMO energy of **3PATAT-C3** film was estimated to be −5.44 eV ( **Figure 3c** ) which is almost the same as value obtained from CV. Similar values were found for the remaining derivatives ( **Figure S5** ). 



<!-- Start of picture text -->
a)<br>Si/ITO<br>b) s (P – O – H)<br>a (P – O – H)<br> (P ═ O)<br> (C ═ C) (CH2)  (P – C)<br>1700 1600 1500 1400 1300 1200 1100 1000 900 800 700<br>Wavenumber (cm –1 )<br>Absorbance (a.u.)<br>1236<br>1267<br>1471 1327 732<br>1584 749<br>1400<br>945 721<br>1157 1146 1058 1032 1000 746<br>1234<br>1328 789<br>1572 1475<br>1607 1409 1379<br><!-- End of picture text -->

**Figure 4.** a) IRRAS spectrum of **3PATAT-C3** coated on Si/ITO substrate measured using p-polarization at 80  . b) ATR spectrum of **3PATAT-C3** powder. 

a) Calculated DOS and MO energies 

b) UPS and MAES comparison 



<!-- Start of picture text -->
total DOS<br>6 5 4 3 2 11<br>s2<br>orbitalorbital<br>s1<br>a2 sorbitalorbital<br>a3 a1<br>anchor<br>16 14 12 10 8 6<br>Energy, calculation (eV)<br>Intensity (a.u.)<br><!-- End of picture text -->



<!-- Start of picture text -->
s2<br>a3<br>s1<br>total DOS<br>3<br>6<br>4<br>11 5 2<br>s2 1<br>orbitalorbital a3 s1 ×2<br>UPS<br>3<br>sorbitalorbital 2<br>1<br>×2<br>anchor MAES<br>6 16 14 12 10 8 6<br>Energy from  E VAC (eV)<br> orbitals of  TAT s orbitals of  TAT  and anchors<br>Intensity (a.u.)<br><!-- End of picture text -->

## c) Schematic face-on molecular orientation and typical molecular orbital distributions 



<!-- Start of picture text -->
He*<br><!-- End of picture text -->





**Figure 5.** a) Calculated DOS and MO energies obtained by DFT calculations (B3LYP/6-31G(d)). Vertical bars below the calculated DOS indicate the distribution of MOs. The calculated binding energy scale was contracted by 5.0 eV and shifted to fit with the experimental results. b) Comparison of He I UPS and He<sup>*</sup> MAES spectra of **3PATAT-C3** coated on ITO substrate. c) Schematic face-on molecular orientation of **3PATAT-C3** on ITO and typical molecular orbital distributions (calculated at B3LYP/6-31G(d) level of theory, isovalue: 0.03). 

The HOMO energy level of the **PATAT** derivatives is higher than that of the valence band (VB) of typical perovskite materials such as CH3NH3PbI3 (MAPbI3, VB = −5.45 eV)<sup>49</sup> or Cs0.05FA0.80MA0.15PbI2.75Br0.25 (FA: formamidinium, VB = −5.56 eV),<sup>50</sup> suggesting that these **PATAT** molecules are suitable for extracting holes from perovskite absorbers. 

The nature of the chemical interactions between **3PATAT-C3** and ITO was identified with the help of infrared spectroscopy. The infrared reflection absorption spectroscopy (IRRAS)<sup>51,52</sup> spectrum of **3PATAT-C3** spincoated on the Si/ITO substrate and attenuated total reflection (ATR) spectrum of **3PATAT-C3** powder are shown in **Figure 4** . The assignment for vibrational bands was carried out with the help of density functional theory (DFT) calculations ( **Figure S6** ). Compared to the ATR spectrum of bulk material, a significant decrease in the intensity of peaks at 945, 1146, and 1157 cm<sup>–1</sup> was observed in the IRRAS spectrum of the **3PATAT-C3** film coated on the Si/ITO substrate. These bands are attributed to the P– 

O–H antisymmetric  a(P–O–H) and symmetric  s  P–O–H) stretching vibrations, so the loss of intensity is interpreted as the deprotonation of the phosphonic acid groups. Since the homocondensation of phosphorous derivatives rarely occurs in surface modifications,<sup>53,54</sup> the increase in the relative intensity of the  (P  O) vibrational band at 1236 cm<sup>–1</sup> to the  (P–O–H) vibrational bands suggests that all three phosphonic groups bind to the ITO surface in a bidentate binding mode in which the P  O groups are not chemically interacting with the substrates.<sup>48</sup> All three anchoring groups binding the **3PATAT-C3** molecule to the surface would force the triazatruxene core to align face-on to the ITO substrate. 

Next, we confirmed the orientation of **3PATAT-C3** molecules on the ITO surfaces. It was not possible to observe **3PATAT-C3** molecules adsorbed on both commercial and epitaxial ITO by scanning tunneling microscopy (STM) ( **Figure S7** ) due to the roughness of the ITO surfaces. From the same reason, standard optical techniques observing the transition moment such as near- 

edge X-ray absorption fine structure (NEXAFS) or ellipsometry cannot be applied. We therefore employed the combination of ultraviolet photoelectron spectroscopy (UPS) and metastable atom electron spectroscopy (MAES).<sup>55,56</sup> These techniques observe the density of state (DOS) of valence states but are complementary due to their different probing depths. The probing depth of the UPS is limited by the electron’s mean free path and extends several nanometers into the sample, while the metastable atoms in MAES measurements only interact with the outermost atomic orbitals of the sample surface. Therefore, information about the orientation of the molecule at the surface can be inferred from differences observed between the UPS and MAES spectra. Spectral assignments were made with the help of a calculated DOS obtained by broadening the energies of the molecular orbitals calculated using B3LYP/6-31G(d) level of theory ( **Figure 5a** ). Prominent spectral features associated with  states and s states of **TAT** core are labelled as  i and s i (i = 1,2,3...), respectively, while peaks associated with s states of anchors are labelled as ai. 

The measured UPS spectrum of **3PATAT-C3** on ITO ( **Figure 5b** ) is similar to the calculated total DOS as electron density from entire molecule is detected. In the MAES spectrum, which selectively measures the outermost orbitals, the features derived from  states (  1,  2, and  3) are clearly observed. Further, contributions from higher energy  states (  4 and  6) are more dominant than those from the s states ( s 1 and s 2). These results indicate that only the  orbitals are extended outside the surface meaning that the **3PATAT-C3** molecules are aligned faceon to the ITO surface ( **Figure 5c** ). The same results were also obtained when FTO substrates were used ( **Figure S8a** ). 

Multilayer films were also investigated by increasing the concentration of the **3PATAT-C3** solution and adjusting the spinning speed. In the MAES spectra, the intensity of the s 1 and s 2 signals increases with increasing thickness ( **Figure S8b** ), suggesting a transition to randomlyoriented multilayer. 

Since **2PATAT-C3** with two anchoring groups possesses more degrees of freedom than **3PATAT-C3** even after being adsorbed onto the ITO surface, **2PATAT-C3** may partially adopt face-on orientation. The spectral features of **2PATAT-C3** on ITO ( **Figure S8c** ) are generally similar to **3PATAT-C3** . However, the region of 10–11 eV in the MAES spectrum is flatter than in **3PATAT-C3** case due to the enhanced contribution of s state. The relative intensity of the  and s states indicate that although the orientation of **2PATAT-C3** is also mostly face-on to the substrate, it is overall not as well-oriented as tripodal derivative. 

The preferential face-on orientation of tripodal **3PATAT-C3** molecule on ITO surface was also supported by the first-principles calculations. The adsorption energy of **3PATAT-C3** on the most stable ITO (111) surface was calculated using the periodic density functional theory calculation at the generalized gradient approximation Perdew– Burke–Ernzerhof (GGA-PBE) level with the Vienna Ab ini- 

tio Simulation Package (VASP). The details of the theoretical calculations are provided in the Supporting Information. The adsorption energy of **3PATAT-C3** with monopodal, dipodal, and tripodal anchoring mode was determined to be 0.21, 1.90, and 4.45 eV, respectively ( **Figure S9** ). These results indicate that the face-on orientation with all three phosphonic acid groups anchored to the ITO surface is the most stable configuration. 

For hole extraction in perovskite solar cells, the effective coverage of the hole-collecting molecules on the ITO surface is crucial. The number of molecules adsorbed on a conducting surface can be estimated from cyclic voltammetry by observing the dependency of the oxidative peak intensity on the scan rate as follows:<sup>57</sup> 



<!-- Start of picture text -->
𝑛 2 𝐹 2<br>𝑖p = 4𝑅𝑇𝑁A 𝐴𝛤 ∗ 𝜐          (1)<br><!-- End of picture text -->

In the above equation, _i_ p (A) is the oxidative peak current,  (V s<sup>–1</sup> ) is the voltage scan rate, _n_ is the number of electrons transferred, _F_ (96485.33 C mol<sup>–1</sup> ) is the Faraday constant, _R_ (8.3144 J K<sup>–1</sup> mol<sup>–1</sup> ) is the universal gas constant, _T_ (K) is the temperature, _N_ A (6.022  10<sup>23</sup> mol<sup>–1</sup> ) is the Avogadro constant, _A_ (cm<sup>2</sup> ) is the electrode surface area, and _Γ_<sup>*</sup> (molecules cm<sup>–2</sup> ) is the surface density. The number of the adsorbed molecules per unit area can be determined experimentally by measuring the slope of _i_ p vs  . 

Monolayer films of **1PATAT-C3** , **2PATAT-C3** , **3PATATC3** , **3PATAT-C4** , and **MeO-2PACz** were prepared on ITO by spin coating from 0.1 mM DMF solutions. Using ITO/ **PATAT** substrates as working electrodes, CV measurements were performed at different scan rates in 1,2-dichlorobenzene ( _o_ -DCB) solutions with 0.1 M tetrabutylammonium hexafluorophosphate (<sup>_n_</sup> Bu4N<sup>+</sup> PF6<sup>–</sup> ) as a supporting electrolyte ( **Figure S10, S11** ). 

The surface density of **1PATAT-C3** , **2PATAT-C3** , **3PATAT-C3** , **3PATAT-C4** , and **MeO-2PACz** was determined to be 6.6  10<sup>12</sup> , 5.7  10<sup>12</sup> , 1.0  10<sup>13</sup> , 5.8  10<sup>12</sup> , and 1.6  10<sup>13</sup> molecules cm<sup>–2</sup> , respectively. The surface density of tripodal **3PATAT-C3** molecule is significantly higher than both the monopodal and dipodal derivatives, as well as higher than the **3PATAT-C4** with longer alkyl spacers. Although the number of adsorbed molecules for monopodal **MeO-2PACz** was higher than **3PATAT-C3** , using the molecular footprint of **3PATAT-C3** and **MeO-2PACz** (estimated as 132.1 and 51.6 Å<sup>2</sup> , respectively, from the shadow projection of the DFT optimized structures as shown in **Figure S12** ), the effective coverage of “face-on” oriented **3PATAT-C3** was calculated to be 1.6 times more than “edge-on” oriented **MeO-2PACz** . 

**Perovskite Film Fabrication and Characterization.** As we already reported previously,<sup>58</sup> efficient hole extraction from the perovskite layer requires that the HOMO energy level of the HCM be at least 0.1 eV shallower than the valence band of perovskite material. Therefore, considering that the HOMO energy levels of **PATAT** 

molecules are ca. −5.44 eV ( **Figure S5** ), a mixedcomposition perovskite material (Cs0.05FA0.80MA0.15PbI2.75Br0.25)<sup>50</sup> with a valence band of −5.56 eV was chosen for the devices in this work. 

It was found that the solvent used for fabricating **PATAT** monolayer has a large effect on the deposition of the perovskite layer. With the monolayer fabricated by spin coating **PATAT** from DMSO solution, only perovskite film with poor coverage could be obtained. In contrast, when DMF was used as the solvent for **PATAT** solution, a uniform perovskite layer can be readily fabricated without the need for additional pre-wetting treatment despite the hydrophobicity of **PATAT** monolayer ( **Figure S13** ). The crystallinity and morphology of the perovskite films fabricated on different hole-collecting layers were characterized with the aid of X-ray diffraction (XRD) ( **Figures S14** ) and scanning electron microscopy (SEM) ( **Figures S15–S18** ). The SEM images confirm the perovskite layers to be smooth and pinhole-free. The small bright grains are attributed to excess PbI2 at the surface. From the XRD patterns, we judge that the crystallinity of the perovskite films is not significantly influenced by the choice of hole-collecting materials. 

**Perovskite Solar Cells.** Solar cells were fabricated with the following p-i-n device stack: Glass/indium tin oxide (ITO) or fluoride-doped tin oxide (FTO)/HCM/Cs0.05FA0.80MA0.15PbI2.75Br0.25 (500–600 nm)/ethylenediammonium diiodide (EDAI2, 0.5 nm)/C60 (20 nm)/bathocuproine (BCP, 8 nm)/Ag (100 nm) ( **Figure 6a** ). Textured FTO substrate was found to give superior performance compared to ITO substrate, most likely due to reduced reflection loss over the spectral range of 400– 750 nm as a result of less optical interference. Ethylenediammonium diiodide (EDAI2) was used as a posttreatment for the perovskite surface to increase the cell voltages.<sup>59</sup> The fabrication processes and optimization details (for transparent conductive oxide substrates, solvents, and concentration of HCMs) are provided in the Supporting Information ( **Figure S19–S26** , **Table S1–S4** ). The distribution of the PCE of the optimized PSCs fabricated with FTO substrates and EDAI2 post-treatment is indicated by the box plots shown in **Figure 6b** (also see **Figures S27** ). The current–voltage ( _J–V_ ) characteristics and corresponding incident photon-to-current conversion efficiency (IPCE) spectra for champion device at each condition are shown in **Figure 6c–e** (see also **Figures S28– S30** ), while the device parameters are listed in **Table 1** . 

Among all PSC devices, tripodal **3PATAT-C3** based devices exhibited the best performance with short-circuit current ( _J_ SC), open-circuit voltage ( _V_ OC), fill factor (FF), and PCE derived from the forward _J_ – _V_ scan is 24.5 mA cm<sup>–2</sup> , 1.13 V, 0.83, and 23.0%, respectively. This is one of the best results for PSCs with hole-collecting monolayers ( **Table S5** ). 

Compared to **3PATAT-C3** based devices, the lower performance of devices fabricated with conventional PTAA ( _J_ SC = 23.0 mA cm<sup>–2</sup> , _V_ OC = 1.07 V, FF = 0.79, PCE = 19.4%) and **MeO-2PACz** ( _J_ SC = 23.4 mA cm<sup>–2</sup> , _V_ OC = 1.12 V, FF = 0.80, 

PCE = 21.0%) can be partially attributed to the current loss in the wavelength region <420 nm caused by the parasitic absorption ( **Figure 6d** ). It demonstrated the advantage of **3PATAT-C3** over conventional materials from the view point of light transmittance. 

In order to clarify the effect of the molecular orientation on device performance, devices using monopodal (edge-on or tilted), dipodal (partially face-on), and tripodal (faceon) hole-collecting monolayer materials was compared in detail. The performance of the devices fabricated with the monopodal molecules ( **1PATAT-C3** and the reference material **MeO-2PACz** ) was similar with an average PCE of 20.0 and 20.3% for **1PATAT-C3** and **MeO-2PACz** -based PSCs, respectively. 

The device efficiency was found to be increased as the number of anchoring groups is increased from one to three as shown in **Figure 6e** . The average PCE calculated from the forward _J_ – _V_ scan of the devices using monopodal **1PATAT-C3** , dipodal **2PATAT-C3** , and tripodal **3PATAT-C3** was 20.0, 21.3, and 22.2%, respectively. The champion PCE reached 21.1, 22.2, and 23.0%, respectively. 

The average _J_ SC was 23.0, 23.6, and 24.3 mA cm<sup>–2</sup> for **1PATAT-C3** , **2PATAT-C3** , and **3PATAT-C3** , respectively. The integrated _J_ SC obtained from the IPCE spectra ( **Figure S30** ) are in good agreement with the values derived from the forward _J_ – _V_ scans. Since the absorption bands of **PATAT** derivatives are identical, these results indicate a better internal quantum efficiency of the devices using tripodal **3PATAT-C3** compared to dipodal **2PATAT-C3** and monopodal **1PATAT-C3** . The average _V_ OC for **1PATAT-C3** , **2PATAT-C3** , and **3PATAT-C3** was 1.07, 1.12, and 1.13 V, respectively, and the average FF was 0.81, 0.80, and 0.81. Overall, the current and the voltage of the PSCs increased with the number of anchoring groups, while the FF was largely unaffected. Compared to edge-on oriented **1PATAT-C3** and partially face-on oriented **2PATAT-C3** , the more favorable configuration of tripodal **3PATAT-C3** results in higher _J_ SC and _V_ OC. The better performance of faceon oriented **3PATAT-C3** could be attributed to the shorter hole transfer pathway and/or suppressed unsought hole transport in the lateral direction. 

As a result of the longer insulating alkyl chains, devices with **3PATAT-C4** showed a slight drop in performance compared to the **3PATAT-C3** in average PCE (20.6% vs 22.2%), _J_ SC (22.8 mA cm<sup>–2</sup> vs 24.3 mA cm<sup>–2</sup> ), and _V_ OC (1.11 V vs 1.13 V). 

As multipodal molecules are bound more strongly with the metal oxide surface, the durability of the devices might be expected to improve. To check this, the maximum power point (MPP) of the devices was tracked under AM 1.5G in an inert atmosphere for 100 h. The results are shown in **Figure S31** (also see **Figure S32** ). After 100 h, the output power of the devices using **1PATAT-C3** was 73% of the initial value, while 92% and 95% of the initial output was maintained for the devices using **2PATAT-C3** and **3PATAT-C3** over the same period, respectively. 

### a) Device structure 





<!-- Start of picture text -->
500 nm<br><!-- End of picture text -->

### c) _J–V_ curves 



<!-- Start of picture text -->
2 5<br>2 0<br>1 5<br>1 0<br> P TAA<br> M eO-2PACz<br>5  3 PATAT-C3<br>0<br>0.0 0.2 0.4 0.6 0.8 1.0 1.2<br>Voltage (V)<br>e)  J–V  curves of PSCs with  PATAT  series<br>2 5<br>2 0<br>1 5<br> 1 PATAT-C3<br>1 0<br> 2 PATAT-C3<br> 3 PATAT-C3<br>5<br> 3 PATAT-C4<br>0<br>0.0 0.2 0.4 0.6 0.8 1.0 1.2<br>Voltage (V)<br>-2Current density (mA cm)<br>-2Current density (mA cm)<br><!-- End of picture text -->

### e) _J–V_ curves of PSCs with **PATAT** series 

### b) Box plots of PCEs 



<!-- Start of picture text -->
2 4<br>2 2<br>2 0<br>1 8<br>1 6<br>d) IPCE spectra<br>10 0<br>8 0<br>6 0  P TAA<br>J SC, int. = 22.6 mA cm-2<br>4 0  M eO-2PACz<br>J SC, int. = 23.2 mA cm-2<br>2 0  3 PATAT-C3<br>J SC, int. = 24.2 mA cm-2<br>0<br>300 400 500 600 700 800 900<br>Wavelength (nm)<br>PTAA MeO-2PACz1PATAT-C32PATAT-C33PATAT-C33PATAT-C4<br>PCE ()%<br>IPCE (%)<br><!-- End of picture text -->

### f) Shelf-stability of **3PATAT-C3** based PSC 



<!-- Start of picture text -->
2 5<br>2 0<br>1 5<br>1 0<br>5 - Unencapsulated device<br>- Inert atmosphere<br>0<br>0 500 1000 1500 2000<br>Time (h)<br>PCE (%)<br><!-- End of picture text -->

**Figure 6.** a) The schematic structure and cross-sectional SEM image of p-i-n PSC. b) Box plots of PCEs of the solar cells. c) Forward scan _J–V_ curves and d) IPCE spectra with integrated _J_ SC values ( _J_ SC, int.) of PSCs fabricated using PTAA, **MeO-2PACz** , and **3PATAT-C3** . e) Forward scan _J–V_ curves of PSCs fabricated with **PATAT** series. f) The shelf-stability test in the inert atmosphere under dark condition for the unencapsulated devices fabricated with **3PATAT-C3** . 

**Table 1. Photovoltaic Parameters of PSCs Fabricated on Different FTO/HCM Substrates with EDAI2 Treatment on Top of Perovskite Derived from** **_J_ –** **_V_ Measurements** 

|HCM<sup>a)</sup>|Scan<sup>b)</sup>|_J_SC|_V_OC|FF<sup>c)</sup>|PCE|HI<sup>d)</sup>|
|---|---|---|---|---|---|---|
|||[mA cm<sup>–2</sup>]<sup>c)</sup>|[V]<sup>c)</sup>||[%]<sup>c)</sup>||
|PTAA|Forward|23.0|1.07|0.79|19.4||
|||(22.10.8)|(1.060.01)|(0.780.02)|(18.30.9)|–0.037|
||Reverse|22.5|1.07|0.78|18.7||
|||(21.50.7)|(1.060.01)|(0.760.02)|(17.30.9)||
|**MeO-2PACz**|Forward|23.4|1.12|0.80|21.0||
|||(23.10.2)|(1.110.01)|(0.790.01)|(20.30.5)|–0.050|
||Reverse|23.3|1.11|0.77|20.0||
|||(23.10.2)|(1.100.01)|(0.750.01)|(19.20.6)||
|**1PATAT-C3**|Forward|24.0|1.06|0.82|21.1||
|||(23.00.8)|(1.070.02)|(0.810.02)|(20.00.9)||
||Reverse|23.5|1.10|0.80|20.8|–0.014|
|||(22.70.6)|(1.080.02)|(0.760.03)|(18.51.3)||
|**2PATAT-C3**|Forward|23.3|1.14|0.83|22.2||
|||(23.60.2)|(1.120.01)|(0.800.02)|(21.30.5)|–0.174|
||Reverse|23.0|1.14|0.72|18.9||
|||(23.50.2)|(1.100.02)|(0.750.02)|(19.50.9)||
|**3PATAT-C3**|Forward|24.5|1.13|0.83|23.0||
|||(24.30.3)|(1.130.01)|(0.810.02)|(22.20.7)|–0.031|
||Reverse|24.4|1.13|0.81|22.3||
|||(24.30.4)|(1.120.01)|(0.790.02)|(21.60.9)||
|**3PATAT-C4**|Forward|23.3|1.14|0.83|22.1||
|||(22.80.4)|(1.110.02)|(0.810.02)|(20.60.5)|–0.139|
||Reverse|23.1|1.11|0.75|19.4||
|||(22.50.5)|(1.090.01)|(0.730.02)|(18.10.9)||



> _a_ HCMs were spin-coated on FTO substrates. _b_ Forward and reverse indicate the scan direction from _J_ SC to _V_ OC and from _V_ OC to _J_ SC, respectively.<sup>_c_</sup> The average and standard deviation values were given in parentheses.<sup>_d_</sup> Hysteresis index (HI) = (PCEReverse – PCEForward)/PCEReverse. 



<!-- Start of picture text -->
a) b) 1.1 5<br>Fitting curve<br>40 0<br> MeO-2PACz 1.1 0<br> 1PATAT-C3<br> 2PATAT-C3 1.0 5<br>30 0<br> 3PATAT-C3<br> 3PATAT-C4 1.0 0<br>20 0<br>0.9 5 n id<br> MeO-2PACz: 1.61<br>10 0 0.9 0  1PATAT-C3:  1.60<br> 2PATAT-C3:  1.56<br>0.8 5  3PATAT-C3:  1.47<br> 3PATAT-C4:  1.58<br>0 0.8 0<br>0 100 200 300 400 500 600 0.001 0.01 0.1 1<br>Z ' (Wcm2) Light intensity (mW cm-2)<br>V  (V)OC<br>2 Z " ()Wcm-<br><!-- End of picture text -->

**Figure 7.** a) Complex impedance plots under an inert atmosphere at AM 1.5G illumination and zero applied bias. b) The _V_ OC as a function of illumination intensity of the PSCs fabricated on **MeO-2PACz** , **1PATAT-C3** , **2PATAT-C3** , **3PATAT-C3** , and **3PATAT-C4** monolayers. 

The high durability of the device using multipodal holecollecting monolayers might be the result of higher coverage as determined by the CV experiments and a suppressed charge accumulation induced degradation. 

In shelf-stability test (inert atmosphere, room temperature, dark condition), it was found that unencapsulated devices using **3PATAT-C3** could be stored for at least 2000 hours without any drop in performance compared to the initial state ( **Figure 6f** and **S33** ). One of the **3PATAT-C3** devices was encapsulated and sent to National Institute of Advanced Industrial Science and Technology (AIST, Japan) for certification. The certified efficiency was 21.02% ( **Figure S34** ) is close to our in-house measurement of 21.5% after sealing. The thermal durability of the **3PATAT-C3** monolayer was tested by placing the unencapsulated devices under an ambient atmosphere (room humidity = 60%) at elevated temperatures and periodically measuring the _J_ – _V_ curves ( **Figure S35** ). The PCE remained at 94% of the initial value after heating at 120  C for 1 h, and was still 89% of the initial value after heating at 130  C for additional one hour. 

The charge transfer properties of the hole-collecting materials were examined using steady-state photoluminescence (PL) quenching and time-resolved photoluminescence (TRPL)<sup>60</sup> measurements. PL quenching were performed on quartz/perovskite, glass/ITO/perovskite, and glass/ITO/HCM/perovskite samples ( **Figure S36** ). After fabricating perovskite on HCM layers, PL intensity of the perovskite films fabricated on **PATAT** monolayers was much lower than from the perovskite film on **MeO-2PACz** (<6% vs 45%) ( **Figure S36a** ). The PL lifetime for the pristine perovskite film on quartz was 334 ns<sup>61</sup> and 189 ns for the glass/ITO substrate. It decreased in the HCM/perovskite films to 51, 12, 10, 10, and 8 ns for **MeO2PACz** , **3PATAT-C4** , **3PATAT-C3** , **2PATAT-C3** and **1PATAT-C3** , respectively ( **Figure S36b** ). The stronger PL quenching together with shorter PL lifetime suggest that 

hole extraction into **PATAT** series proceeds more efficiently than with **MeO-2PACz** . 

In most cases, the quenching of PL signals by charge transfer at charge-collecting layer/perovskite interface and by increased recombination rates cannot be unambiguously distinguised.<sup>62</sup> Therefore, the impedance spectroscopy and the light intensity dependence of the open circuit voltages were also conducted. 

The electrical properties of the devices were examined with the impedance spectroscopy (IS).<sup>63</sup> The results measured for the solar cell devices under AM 1.5G at short circuit condition are shown in **Figure 7a** (also see **Figure S37** for other applied bias). The complex impedance data were fitted to a simple equivalent circuit with series and parallel resistance elements and a parallel capacitance. The series resistance ( _R_ s) was confirmed to be low, at about 1 Ω cm<sup>2</sup> for all devices. The parallel resistance ( _R_ p), indicated by the diameter of the main semicircular feature, varied from 165 and 135 Ω cm<sup>2</sup> for **MeO-2PACz** and **1PATAT-C3** , respectively, to 205 Ω cm<sup>2</sup> for **2PATAT-C3** , and to 430 Ω cm<sup>2</sup> for **3PATAT-C3** . The increase in parallel resistance with the number of anchoring groups correlates with the improvements to the fill factor and confirms that hole extraction from the perovskite films is more efficient for face-on oriented molecules. At 235 Ω cm<sup>2</sup> , the parallel resistance of the molecule with the four-carbon spacer chains ( **3PATAT-C4** ) was somewhat reduced compared with **3PATAT-C3** , suggesting that the longer alkyl chains in **3PATAT-C4** impedes hole extraction. 

The light intensity dependence of the open circuit voltages was measured to determine the diode ideality factors ( _n_ id, **Figure 7b** ). The ideality factors varied within a relatively narrow range from 1.61 for **MeO-2PACz** and 1.60 for **1PATAT-C3** to 1.56 for **2PATAT-C3** and 1.47 for **3PATAT-C3** . The ideality factor for **3PATAT-C4** was 1.58. The overall trends here mirror the parallel resistance 

values determined by the impedance measurements. The smaller ideality factor indicates a reduced interfacial trapassisted recombination and correlates closely to the observed trends for the _V_ OC and fill factor.<sup>64</sup> 

## **CONCLUSIONS** 

In summary, a multipodal strategy was proposed to realize face-on orientation of hole-collecting monolayers chemically adsorbed on transparent conducting oxide substrates. For this purpose, a triazatruxene derivative bearing three phosphonic acid anchoring groups ( **3PATAT-C3** ) was designed and synthesized. The face-on orientation of **3PATAT-C3** molecules was verified using a combination of IRRAS, UPS, MAES, and theoretical calculations. Compared to the edge-on oriented monopodal and partially face-on oriented dipodal monolayer materials, the face-on configuration of tripodal **3PATAT-C3** monolayers enhances hole collection and reduces interfacial charge recombination. Perovskite solar cells using tripodal **3PATAT-C3** reached a PCE of 23.0% and showed improved operational stability. These results demonstrate the effectiveness of our multipodal strategy to achieve a face-on orientation and improve the performance of perovskite solar cells. Based on this concept, further structural modifications of hole-collecting materials should lead to further progress in both single-junction and tandem PSC devices. 

## **ASSOCIATED CONTENT** 

#### **Supporting Information** . 

The Supporting Information is available free of charge on the ACS Publication website. Experimental details and characterization data (PDF). 

## **AUTHOR INFORMATION** 

#### **Corresponding Authors** 

* **Minh Anh Truong** – Institute for Chemical Research, Kyoto University, Gokasho, Uji, Kyoto, 611-0011, Japan; E-mail: truong.minhanh.2x@ kyoto-u.ac.jp orcid.org/0000-0003-2649-0282 

* **Atsushi Wakamiya** – Institute for Chemical Research, Kyoto University, Gokasho, Uji, Kyoto, 611-0011, Japan; E-mail: wakamiya@scl.kyoto-u.ac.jp orcid.org/0000-0003-1430-0947 

#### **Authors** 

**Tsukasa Funasaki** – Institute for Chemical Research, Kyoto University, Gokasho, Uji, Kyoto, 611-0011, Japan. **Lucas Ueberricke** – Institute for Chemical Research, Kyoto University, Gokasho, Uji, Kyoto, 611-0011, Japan; orcid.org/0000-0002-5124-5820 

**Wataru Nojo** – Institute for Chemical Research, Kyoto University, Gokasho, Uji, Kyoto, 611-0011, Japan. Department of Chemistry, Faculty of Science, Hokkaido University, Sapporo, 060-0810, Japan. 

**Richard Murdey** – Institute for Chemical Research, Kyoto University, Gokasho, Uji, Kyoto, 611-0011, Japan; orcid.org/0000-0001-7621-9664 

**Takumi Yamada** – Institute for Chemical Research, Kyoto University, Gokasho, Uji, Kyoto, 611-0011, Japan; orcid.org/0000-0002-9171-5364 

**Shuaifeng Hu** – Institute for Chemical Research, Kyoto University, Gokasho, Uji, Kyoto, 611-0011, Japan; orcid.org/0000-0003-1312-075X 

**Aruto Akatsuka** – Graduate School of Science and Engineering, Chiba University, 1-33 Yayoi-cho, Inage-ku, Chiba, 2638522, Japan. 

**Naomu Sekiguchi** – Department of Advanced Materials Science and Engineering, Faculty of Engineering Sciences, Kyushu University, Kasuga, Fukuoka, 816-8580, Japan. 

**Shota Hira** – Institute for Chemical Research, Kyoto University, Gokasho, Uji, Kyoto, 611-0011, Japan. **Lingling Xie** – Institute for Chemical Research, Kyoto University, Gokasho, Uji, Kyoto, 611-0011, Japan. 

**Tomoya Nakamura** – Institute for Chemical Research, Kyoto University, Gokasho, Uji, Kyoto, 611-0011, Japan; orcid.org/0000-0001-7059-931X 

**Nobutaka Shioya** – Institute for Chemical Research, Kyoto University, Gokasho, Uji, Kyoto, 611-0011, Japan; orcid.org/0000-0002-2915-894X **Daisuke Kan** – Institute for Chemical Research, Kyoto University, Gokasho, Uji, Kyoto, 611-0011, Japan; orcid.org/0000-0002-7505-0059 

**Yuta Tsuji** – Department of Advanced Analytical Science for Materials and Devices, Faculty of Engineering Sciences, Kyushu University, Kasuga, Fukuoka, 816-8580, Japan; orcid.org/0000-0003-4224-4532 

**Satoshi Iikubo** – Department of Advanced Materials Science and Engineering, Faculty of Engineering Sciences, Kyushu University, Kasuga, Fukuoka, 816-8580, Japan; orcid.org/0000-0002-5186-4058 

**Hiroyuki Yoshida** – Graduate School of Science and Engineering, Chiba University, 1-33 Yayoi-cho, Inage-ku, Chiba, 263-8522, Japan. Graduate School of Engineering, Chiba University, 1-33 Yayoi-cho, Inage-ku, Chiba, 263-8522, Japan. Molecular Chirality Research Center, Chiba University, 1-33 Yayoi-cho, Inage-ku, Chiba, 263-8522, Japan; orcid.org/0000-0002-8889-324X **Yuichi Shimakawa** – Institute for Chemical Research, Kyoto University, Gokasho, Uji, Kyoto, 611-0011, Japan; orcid.org/ 0000-0003-1019-2512 

**Takeshi Hasegawa** – Institute for Chemical Research, Kyoto University, Gokasho, Uji, Kyoto, 611-0011, Japan; orcid.org/0000-0001-5574-9869 

**Yoshihiko Kanemitsu** – Institute for Chemical Research, Kyoto University, Gokasho, Uji, Kyoto, 611-0011, Japan; orcid.org/0000-0002-0788-131X 

**Takanori Suzuki** –Department of Chemistry, Faculty of Science, Hokkaido University, Sapporo, 060-0810, Japan; orcid.org/0000-0002-1230-2044 

#### **Author Contributions** 

‡T.F., L.U., and W.N. contributed equally to this work. 

#### **Conflicts of Interest** 

A. W. is co-founder and CSO of Enecoat Technologies Co., Ltd. 

## **ACKNOWLEDGMENT** 

This work was supported by JST–MIRAI (JPMJMI22E2), JST– ALCA (JPMJAL 1603), JST–COI (JPMJCE1307), and JSPS KAKENHI (JP19H05465) programs, NEDO, International Collaborative Research Program of ICR, Kyoto University, ICR Grants for Promoting Integrated Research, Kyoto University, grants for the Integrated Research Consortium on Chemical Sciences, Grant-in-Aid for Research Activity Start-up (JP20K22531), Grant-in-Aid for Early-Career Scientists (JP21K14694, JP22K14744), Grant-in-Aid for Scientific Research (C) (JP19K05666), Grant-in-Aid for Scientific Research (A) (JP21H04699), JSPS for a Research Fellowship for Young Scientists (JP20J11569 for W.N., JP21J14762 for S.Hu), and research grant from the Iwatani Naoji Foundation. We thank Prof. Kazukuni Tahara (Meiji University) for fruitful discussions on STM measurements. We thank Ms. Yasuko Iwasaki and Dr. Noboru Ohashi (ICR, Kyoto University) for SEM measurements and ITO sputtering. 

## **REFERENCES** 

- (1) Rong, Y.; Hu, Y.; Mei, A.; Tan, H.; Saidaminov, M. I.; Seok, S. Il; McGehee, M. D.; Sargent, E. H.; Han, H. Challenges for Commercializing Perovskite Solar Cells. _Science_ **2018** , _361_ , eaat8235. 

- (2) Ashworth, C. Reproducible, High-Performance Perovskite Solar Cells. _Nat. Rev. Mater._ **2021** , _6_ , 293. 

- (3) Correa-Baena, J. P.; Saliba, M.; Buonassisi, T.; Grätzel, M.; Abate, A.; Tress, W.; Hagfeldt, A. Promises and Challenges of Perovskite Solar Cells. _Science_ **2017** , _358_ , 739–744. 

- (4) Kim, G.; Min, H.; Lee, K. S.; Lee, D. Y.; Yoon, S. M.; Seok, S. Il. Impact of Strain Relaxation on Performance of α- Formamidinium Lead Iodide Perovskite Solar Cells. _Science_ **2020** , _370_ , 108–112. 

- (5) Jeong, J.; Kim, M.; Seo, J.; Lu, H.; Ahlawat, P.; Mishra, A.; Yang, Y.; Hope, M. A.; Eickemeyer, F. T.; Kim, M.; Yoon, Y. J.; Choi, I. W.; Darwich, B. P.; Choi, S. J.; Jo, Y.; Lee, J. H.; Walker, B.; Zakeeruddin, S. M.; Emsley, L.; Rothlisberger, U.; Hagfeldt, A.; Kim, D. S.; Grätzel, M.; Kim, J. Y. Pseudo-Halide Anion Engineering for α-FAPbI3 Perovskite Solar Cells. _Nature_ **2021** , _592_ , 381–385. 

- (6) Min, H.; Lee, D. Y.; Kim, J.; Kim, G.; Lee, K. S.; Kim, J.; Paik, M. J.; Kim, Y. K.; Kim, K. S.; Kim, M. G.; Shin, T. J.; Il Seok, S. Perovskite Solar Cells with Atomically Coherent Interlayers on SnO2 Electrodes. _Nature_ **2021** , _598_ , 444–450. 

- (7) Yoo, J. J.; Seo, G.; Chua, M. R.; Park, T. G.; Lu, Y.; Rotermund, F.; Kim, Y. K.; Moon, C. S.; Jeon, N. J.; Correa-Baena, J. P.; Bulović, V.; Shin, S. S.; Bawendi, M. G.; Seo, J. Efficient Perovskite Solar Cells via Improved Carrier Management. _Nature_ **2021** , _590_ , 587–593. 

- (8) Li, Z.; Li, B.; Wu, X.; Sheppard, S. A.; Zhang, S.; Gao, D.; Long, N. J.; Zhu, Z. Organometallic-Functionalized Interfaces for Highly Efficient Inverted Perovskite Solar Cells. _Science_ **2022** , _376_ , 416–420. 

- (9) Zhao, Y.; Ma, F.; Qu, Z.; Yu, S.; Shen, T.; Deng, H. X.; Chu, X.; Peng, X.; Yuan, Y.; Zhang, X.; You, J. Inactive (PbI2)2RbCl Stabilizes Perovskite Films for Efficient Solar Cells. _Science_ **2022** , _377_ , 531–534. 

- (10) Li, D.; Zhang, D.; Lim, K. S.; Hu, Y.; Rong, Y.; Mei, A.; Park, N. G.; Han, H. A Review on Scaling Up Perovskite Solar Cells. _Adv. Funct. Mater._ **2021** , _31_ , 2008621. 

- (11) Wang, R.; Mujahid, M.; Duan, Y.; Wang, Z. K.; Xue, J.; Yang, Y. A Review of Perovskites Solar Cell Stability. _Adv. Funct. Mater._ **2019** , _29_ , 1808843. 

- (12) Kim, H.; Lim, K. G.; Lee, T. W. Planar Heterojunction Organometal Halide Perovskite Solar Cells: Roles of Interfacial Layers. _Energy Environ. Sci._ **2016** , _9_ , 12–30. 

- (13) Köhnen, E.; Jošt, M.; Morales-Vilches, A. B.; Tockhorn, P.; AlAshouri, A.; Macco, B.; Kegelmann, L.; Korte, L.; Rech, B.; Schlatmann, R.; Stannowski, B.; Albrecht, S. Highly Efficient Monolithic Perovskite Silicon Tandem Solar Cells: Analyzing the Influence of Current Mismatch on Device Performance. _Sustain. Energy Fuels_ **2019** , _3_ , 1995–2005. 

- (14) Xu, J.; Boyd, C. C.; Yu, Z. J.; Palmstrom, A. F.; Witter, D. J.; Larson, B. W.; France, R. M.; Werner, J.; Harvey, S. P.; Wolf, E. J.; Weigand, W.; Manzoor, S.; A M van Hest, M. F.; Berry, J. J.; Luther, J. M.; Holman, Z. C.; McGehee, M. D. TripleHalide Wide-Band Gap Perovskites with Suppressed Phase Segregation for Efficient Tandems. _Science_ **2020** , _367_ , 1097– 1104. 

- (15) Jošt, M.; Kegelmann, L.; Korte, L.; Albrecht, S. Monolithic Perovskite Tandem Solar Cells: A Review of the Present Status and Advanced Characterization Methods Toward 30% Efficiency. _Adv. Energy Mater._ **2020** , _10_ , 1904102. 

- (16) Lin, X.; Cui, D.; Luo, X.; Zhang, C.; Han, Q.; Wang, Y.; Han, L. Efficiency Progress of Inverted Perovskite Solar Cells. _Energy Environ. Sci._ **2020** , _13_ , 3823–3847. 

- (17) Yin, X.; Song, Z.; Li, Z.; Tang, W. Toward Ideal Hole Transport Materials: A Review on Recent Progress in Dopant-Free Hole Transport Materials for Fabricating Efficient and Stable Perovskite Solar Cells. _Energy Environ. Sci._ **2020** , _13_ , 4057–4086. 

- (18) Roose, B.; Wang, Q.; Abate, A. The Role of Charge Selective Contacts in Perovskite Solar Cell Stability. _Adv. Energy Mater._ **2019** , _9_ , 1803140. 

- (19) Yao, Y.; Cheng, C.; Zhang, C.; Hu, H.; Wang, K.; De Wolf, S. Organic Hole Transport Layers for Efficient, Stable and Scalable Inverted Perovskite Solar Cells. _Adv. Mater._ **2022** , _34_ , 2203794. 

- (20) Yin, X.; Guo, Y.; Xie, H.; Que, W.; Kong, L. B. Nickel Oxide as Efficient Hole Transport Materials for Perovskite Solar Cells. _Sol. RRL_ **2019** , _3_ , 1900001. 

- (21) Rao, H.; Ye, S.; Sun, W.; Yan, W.; Li, Y.; Peng, H.; Liu, Z.; Bian, Z.; Li, Y.; Huang, C. A 19.0% Efficiency Achieved in CuOxBased Inverted CH3NH3PbI3-xClx Solar Cells by an Effective Cl Doping Method. _Nano Energy_ **2016** , _27_ , 51–57. 

- (22) Magomedov, A.; Al-Ashouri, A.; Kasparavičius, E.; Strazdaite, S.; Niaura, G.; Jošt, M.; Malinauskas, T.; Albrecht, S.; Getautis, V. Self-Assembled Hole Transporting Monolayer for Highly Efficient Perovskite Solar Cells. _Adv. Energy Mater._ **2018** , _8_ , 1801892. 

- (23) Yalcin, E.; Can, M.; Rodriguez-Seco, C.; Aktas, E.; Pudi, R.; Cambarau, W.; Demic, S.; Palomares, E. Semiconductor SelfAssembled Monolayers as Selective Contacts for Efficient PiN Perovskite Solar Cells. _Energy Environ. Sci._ **2019** , _12_ , 230– 237. 

- (24) Zhang, S.; Wu, R.; Mu, C.; Wang, Y.; Han, L.; Wu, Y.; Zhu, W.-H. Conjugated Self-Assembled Monolayer as Stable Hole-Selective Contact for Inverted Perovskite Solar Cells. _ACS Materials Lett._ **2022** , _4_ , 1976–1983. 

- (25) Al-Ashouri, A.; Magomedov, A.; Roß, M.; Jošt, M.; Talaikis, M.; Chistiakova, G.; Bertram, T.; Márquez, J. A.; Köhnen, E.; Kasparavičius, E.; Levcenco, S.; Gil-Escrig, L.; Hages, C. J.; Schlatmann, R.; Rech, B.; Malinauskas, T.; Unold, T.; Kaufmann, C. A.; Korte, L.; Niaura, G.; Getautis, V.; Albrecht, S. Conformal Monolayer Contacts with Lossless Interfaces for Perovskite Single Junction and Monolithic Tandem Solar Cells. _Energy Environ. Sci._ **2019** , _12_ , 3356–3369. 

- (26) Aktas, E.; Jiménez-López, J.; Azizi, K.; Torres, T.; Palomares, E. Self-Assembled Zn Phthalocyanine as a Robust p-Type Selective Contact in Perovskite Solar Cells. _Nanoscale Horiz._ **2020** , _5_ , 1415–1419. 

- (27) Li, E.; Bi, E.; Wu, Y.; Zhang, W.; Li, L.; Chen, H.; Han, L.; Tian, H.; Zhu, W. H. Synergistic Coassembly of Highly Wettable and Uniform Hole-Extraction Monolayers for Scaling-up Perovskite Solar Cells. _Adv. Funct. Mater._ **2020** , _30_ , 1909509. 

- (28) Al-Ashouri, A.; Köhnen, E.; Li, B.; Magomedov, A.; Hempel, H.; Caprioglio, P.; Márquez, J. A.; Vilches, A. B. M.; Kasparavicius, E.; Smith, J. A.; Phung, N.; Menzel, D.; Grischek, M.; Kegelmann, L.; Skroblin, D.; Gollwitzer, C.; Malinauskas, T.; Jošt, M.; Matič, G.; Rech, B.; Schlatmann, R.; Topič, M.; Korte, L.; Abate, A.; Stannowski, B.; Neher, D.; Stolterfoht, M.; Unold, T.; Getautis, V.; Albrecht, S. Monolithic Perovskite/Silicon Tandem Solar Cell with >29% Efficiency by Enhanced Hole Extraction. _Science_ **2020** , _370_ , 1300–1309. 

- (29) Aktas, E.; Phung, N.; Köbler, H.; González, D. A.; Méndez, M.; Kafedjiska, I.; Turren-Cruz, S. H.; Wenisch, R.; Lauermann, I.; Abate, A.; Palomares, E. Understanding the Perovskite/Self-Assembled Selective Contact Interface for Ultra-Stable and Highly Efficient p-i-n Perovskite Solar Cells. _Energy Environ. Sci._ **2021** , _14_ , 3976–3985. 

- (30) Li, E.; Liu, C.; Lin, H.; Xu, X.; Liu, S.; Zhang, S.; Yu, M.; Cao, X. M.; Wu, Y.; Zhu, W. H. Bonding Strength Regulates Anchoring-Based Self-Assembly Monolayers for Efficient and Stable Perovskite Solar Cells. _Adv. Funct. Mater._ **2021** , _31_ , 2103847. 

- (31) Liao, Q.; Wang, Y.; Zhang, Z.; Yang, K.; Shi, Y.; Feng, K.; Li, B.; Huang, J.; Gao, P.; Guo, X. Self-Assembled DonorAcceptor Hole Contacts for Inverted Perovskite Solar Cells with an Efficiency Approaching 22%: The Impact of Anchoring Groups. _J. Energy Chem._ **2021** , _68_ , 87–95. 

- (32) Ullah, A.; Park, K. H.; Nguyen, H. D.; Siddique, Y.; Shah, S. F. A.; Tran, H.; Park, S.; Lee, S. I.; Lee, K. K.; Han, C. H.; Kim, K.; Ahn, S. J.; Jeong, I.; Park, Y. S.; Hong, S. Novel Phenothiazine-Based Self-Assembled Monolayer as a Hole Selective Contact for Highly Efficient and Stable p-i-n Perovskite Solar Cells. _Adv. Energy Mater._ **2022** , _12_ , 2103175. 

- (33) Aktas, E.; Pudi, R.; Phung, N.; Wenisch, R.; Gregori, L.; Meggiolaro, D.; Flatken, M. A.; De Angelis, F.; Lauermann, I.; Abate, A.; Palomares, E. Role of Terminal Group Position in Triphenylamine-Based Self-Assembled Hole-Selective Molecules in Perovskite Solar Cells. _ACS Appl. Mater. Interfaces_ **2022** , _14_ , 17461–17469. 

- (34) Deng, X.; Qi, F.; Li, F.; Wu, S.; Lin, F. R.; Zhang, Z.; Guan, Z.; Yang, Z.; Lee, C. S.; Jen, A. K. Y. Co-Assembled Monolayers as Hole-Selective Contact for High-Performance Inverted Perovskite Solar Cells with Optimized Recombination Loss and Long-Term Stability. _Angew. Chem., Int. Ed._ **2022** , _61_ , e202203088. 

- (35) Ullah, A.; Park, K. H.; Lee, Y. W.; Park, S.; Faheem, A. Bin; Nguyen, H. D.; Siddique, Y.; Lee, K. K.; Jo, Y.; Han, C. H.; Ahn, S. J.; Jeong, I.; Cho, S.; Kim, B. S.; Park, Y. S.; Hong, S. Versatile Hole Selective Molecules Containing a Series of Heteroatoms as Self-Assembled Monolayers for Efficient p- i-n Perovskite and Organic Solar Cells. _Adv. Funct. Mater._ **2022** , 2208793. 

- (36) Jiang, W.; Li, F.; Li, M.; Qi, F.; Lin, F. R.; Jen, A. K.-Y.  ‐ Expanded Carbazoles as Hole‐Selective Self‐Assembled Monolayers for High‐Performance Perovskite Solar Cells. _Angew. Chem., Int. Ed._ **2022** , _61_ , e202213560. 

- (37) Li, Z.; Tan, Q.; Chen, G.; Gao, H.; Wang, J.; Zhang, X.; Xiu, J.; Chen, W.; He, Z. Simple and Robust Phenoxazine Phosphonic Acid Molecules as Self-Assembled Hole Selective Contacts for High Performance Inverted Perovskite Solar Cells. _Nanoscale_ **2023** , _15_ , 1676–1686. 

- (38) Li, W.; Cariello, M.; Méndez, M.; Cooke, G.; Palomares, E. Self-Assembled Molecules for Hole-Selective Electrodes in Highly Stable and Efficient Inverted Perovskite Solar Cells 

with Ultralow Energy Loss. _ACS Appl. Energy Mater._ **2023** , _6_ , 1239–1247. 

- (39) Ali, F.; Roldán-Carmona, C.; Sohail, M.; Nazeeruddin, M. K. Applications of Self-Assembled Monolayers for Perovskite Solar Cells Interface Engineering to Address Efficiency and Stability. _Adv. Energy Mater._ **2020** , _10_ , 2002989. 

- (40) Kim, S. Y.; Cho, S. J.; Byeon, S. E.; He, X.; Yoon, H. J. SelfAssembled Monolayers as Interface Engineering Nanomaterials in Perovskite Solar Cells. _Adv. Energy Mater._ **2020** , _10_ , 2002606. 

- (41) Moia, D.; Vaissier, V.; López-Duarte, I.; Torres, T.; Nazeeruddin, M. K.; O’Regan, B. C.; Nelson, J.; Barnes, P. R. F. The Reorganization Energy of Intermolecular Hole Hopping between Dyes Anchored to Surfaces. _Chem. Sci._ **2014** , _5_ , 281–290. 

- (42) Moia, D.; Szumska, A.; Vaissier, V.; Planells, M.; Robertson, N.; O’Regan, B. C.; Nelson, J.; Barnes, P. R. F. Interdye Hole Transport Accelerates Recombination in Dye Sensitized Mesoporous Films. _J. Am. Chem. Soc._ **2016** , _138_ , 13197–13206. 

- (43) Wang, F.; Li, X. C.; Lai, W. Y.; Chen, Y.; Huang, W.; Wudl, F. Synthesis and Characterization of Symmetric Cyclooctatetraindoles: Exploring the Potential as ElectronRich Skeletons with Extended π-Systems. _Org. Lett._ **2014** , _16_ , 2942–2945. 

- (44) Wang, L.; Fang, Q.; Lu, Q.; Zhang, S. J.; Jin, Y. Y.; Liu, Z. Q. Octupolar ( _C_ 3 and _S_ 4) Symmetric Cyclized Indole Derivatives: Syntheses, Structures, and NLO Properties. _Org. Lett._ **2015** , _17_ , 4164–4167. 

- (45) Samanta, D.; Mukherjee, P. S. Sunlight-Induced Covalent Marriage of Two Triply Interlocked Pd6 Cages and Their Facile Thermal Separation. _J. Am. Chem. Soc._ **2014** , _136_ , 17006–17009. 

- (46) Li, D.; Liang, Z.; Chen, J.; Yu, J.; Xu, R. AIE Luminogen Bridged Hollow Hydroxyapatite Nanocapsules for Drug Delivery. _Dalton Trans._ **2013** , _42_ , 9877–9883. 

- (47) Pathak, A.; Bora, A.; Liao, K. C.; Schmolke, H.; Jung, A.; Klages, C. P.; Schwartz, J.; Tornow, M. Disorder-Derived, Strong Tunneling Attenuation in Bis-Phosphonate Monolayers. _J. Phys. Condens. Matter_ **2016** , _28_ , 094008. 

- (48) Paniagua, S. A.; Hotchkiss, P. J.; Jones, S. C.; Marder, S. R.; Mudalige, A.; Marrikar, F. S.; Pemberton, J. E.; Armstrong, N. R. Phosphonic Acid Modification of Indium-Tin Oxide Electrodes: Combined XPS/UPS/ Contact Angle Studies. _J. Phys. Chem. C_ **2008** , _112_ , 7809–7817. 

- (49) Ozaki, M.; Nakaike, Y.; Shimazaki, A.; Jung, M.; Maruyama, N.; Yakumaru, S.; Rafieh, A. I.; Ekanayake, P.; Saito, T.; Shimakawa, Y.; Sasamori, T.; Murata, Y.; Murdey, R.; Wakamiya, A. How to Make Dense and Flat Perovskite Layers for >20% Efficient Solar Cells: Oriented, Crystalline Perovskite Intermediates and Their Thermal Conversion. _Bull. Chem. Soc. Jpn._ **2019** , _92_ , 1972–1979. 

- (50) Ozaki, M.; Ishikura, Y.; Truong, M. A.; Liu, J.; Okada, I.; Tanabe, T.; Sekimoto, S.; Ohtsuki, T.; Murata, Y.; Murdey, R.; Wakamiya, A. Iodine-Rich Mixed Composition Perovskites Optimised for Tin(IV) Oxide Transport Layers: The Influence of Halide Ion Ratio, Annealing Time, and Ambient Air Aging on Solar Cell Performance. _J. Mater. Chem. A_ **2019** , _7_ , 16947–16953. 

- (51) Hasegawa, T.; Shimoaka, T.; Shioya, N.; Morita, K.; Sonoyama, M.; Takagi, T.; Kanamori, T. Stratified DipoleArrays Model Accounting for Bulk Properties Specific to Perfluoroalkyl Compounds. _ChemPlusChem_ **2014** , _79_ , 1421– 1425. 

- (52) Shimoaka, T.; Itoh, Y.; Hasegawa, T. Dynamic Rearrangement of Stearic Acid Molecules Adsorbed on a Gold Surface Induced by Ambient Water Molecules Studied 

by Infrared Spectroscopy. _J. Phys. Chem. C_ **2012** , _116_ , 17142– 17148. 

- (53) Mutin, P. H.; Guerrero, G.; Vioux, A. Hybrid Materials from Organophosphorus Coupling Molecules. _J. Mater. Chem._ **2005** , _15_ , 3761–3768. 

- (54) Pujari, S. P.; Scheres, L.; Marcelis, A. T. M.; Zuilhof, H. Covalent Surface Modification of Oxide Surfaces. _Angew. Chem., Int. Ed._ **2014** , _53_ , 6322–6356. 

- (55) Harada, Y.; Masuda, S.; Ozaki, H. Electron Spectroscopy Using Metastable Atoms as Probes for Solid Surfaces. _Chem. Rev._ **1997** , _97_ , 1897–1952. 

- (56) Mirzehmet, A.; Ohtsuka, T.; Syed, S. A.; Yuyama, T.; Krüger, P.; Yoshida, H. Surface Termination of Solution-Processed CH3NH3PbI3 Perovskite Film Examined Using Electron Spectroscopies. _Adv. Mater._ **2021** , _33_ , 2004981. 

- (57) Bard, A. J.; Faulkner, L. R. _Electrochemical Methods: Fundamentals and Applications_ , 2nd ed.; Wiley: Hoboken, NJ, 2000; pp 589–595. 

- (58) Nishimura, H.; Ishida, N.; Shimazaki, A.; Wakamiya, A.; Saeki, A.; Scott, L. T.; Murata, Y. Hole-Transporting Materials with a Two-Dimensionally Expanded π-System around an Azulene Core for Efficient Perovskite Solar Cells. _J. Am. Chem. Soc._ **2015** , _137_ , 15656–15659. 

- (59) Hu, S.; Pascual, J.; Liu, W.; Funasaki, T.; Truong, M. A.; Hira, S.; Hashimoto, R.; Morishita, T.; Nakano, K.; Tajima, K.; Murdey, R.; Nakamura, T.; Wakamiya, A. A Universal Surface Treatment for P-i-n Perovskite Solar Cells. _ACS Appl. Mater. Interfaces_ **2022** , _14_ , 56290–56297. 

- (60) Handa, T.; Tex, D. M.; Shimazaki, A.; Wakamiya, A.; Kanemitsu, Y. Charge Injection Mechanism at Heterointerfaces in CH3NH3PbI3 Perovskite Solar Cells Revealed by Simultaneous Time-Resolved Photoluminescence and Photocurrent Measurements. _J. Phys. Chem. Lett._ **2017** , _8_ , 954–960. 

- (61) Truong, M. A.; Lee, H.; Shimazaki, A.; Mishima, R.; Hino, M.; Yamamoto, K.; Otsuka, K.; Handa, T.; Kanemitsu, Y.; Murdey, R.; Wakamiya, A. Near-Ultraviolet Transparent Organic Hole-Transporting Materials Containing Partially OxygenBridged Triphenylamine Skeletons for Efficient Perovskite Solar Cells. _ACS Appl. Energy Mater._ **2021** , _4_ , 1484–1495. 

- (62) Levine, I.; Al-Ashouri, A.; Musiienko, A.; Hempel, H.; Magomedov, A.; Drevilkauskaite, A.; Getautis, V.; Menzel, D.; Hinrichs, K.; Unold, T.; Albrecht, S.; Dittrich, T. Charge Transfer Rates and Electron Trapping at Buried Interfaces of Perovskite Solar Cells. _Joule_ **2021** , _5_ , 2915–2933. 

- (63) Bisquert, J. Theory of the Impedance of Electron Diffusion and Recombination in a Thin Layer. _J. Phys. Chem. B_ **2002** , _106_ , 325–333. 

- (64) Wang, Y.; Liao, Q.; Chen, J.; Huang, W.; Zhuang, X.; Tang, Y.; Li, B.; Yao, X.; Feng, X.; Zhang, X.; Su, M.; He, Z.; Marks, T. J.; Facchetti, A.; Guo, X. Teaching an Old Anchoring Group New Tricks: Enabling Low-Cost, Eco-Friendly HoleTransporting Materials for Efficient and Stable Perovskite Solar Cells. _J. Am. Chem. Soc._ **2020** , _142_ , 16632–16643. 



<!-- Start of picture text -->
PCE = 23%<br>25<br>20<br>15<br>Efficient<br>10<br>Face-on<br>5 Tripod<br>Metal oxide<br>0<br>0.0 0.2 0.4 0.6 0.8 1.0 1.2<br>Voltage (V)<br>2Current density (mA cm) –<br><!-- End of picture text -->



<!-- Start of picture text -->
Table of Contents<br><!-- End of picture text -->

15 

