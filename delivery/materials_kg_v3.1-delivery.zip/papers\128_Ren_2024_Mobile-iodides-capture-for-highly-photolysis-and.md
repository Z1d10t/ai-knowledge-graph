# Mobile iodides capture for highly photolysis- and reverse-bias-stable perovskite solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Materials |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 203 |
| 作者 | Xiaoxue Ren, Ji-Fei Wang, Yun Lin, Yingwei Wang, Haipeng Xie, Hance Huang, Bin Yang, Yan-Fa Yan et al. |
| DOI | 10.1038/s41563-024-01876-2 |
| 源文件 | 028_Ren_2024_Mobile-iodides-capture-for-highly-photolysis-and.pdf |

---
## **nature materials** 

#### **Article** 

https://doi.org/10.1038/s41563-024-01876-2 

# **Mobile iodides capture for highly photolysis- and reverse-bias-stable perovskite solar cells** 

|Received: 10 July 2023<br>Accepted: 21 March 2024<br>Published online: 29 April 2024|**Xiaoxue Ren**<br> <sup>**1,2,7**</sup>**, Jifei Wang**<br> <sup>**1,2,7**</sup>**, Yun Lin**<br> <sup>**2**</sup>**, Yingwei Wang**<br> <sup>**2**</sup>**,**<br>**Haipeng Xie**<br> <sup>**1**</sup>**, Han Huang**<br> <sup>**1,2**</sup>**, Bin Yang**<br> <sup>**3**</sup>**, Yanfa Yan**<br> <sup>**4**</sup>**, Yongli Gao**<sup>**5**</sup>**,**<br>**Jun He**<br> <sup>**1,2**</sup><br>**, Jinsong Huang**<br> <sup>**6**</sup><br>**& Yongbo Yuan**<br> <sup>**1,2**</sup>|
|---|---|
|Check for updates|For halide perovskites that are susceptible to photolysis and ion migration,<br>iodide-related defects, such as iodine (I2) and iodine vacancies, are inevitable.<br>Even a small number of these defects can trigger self-accelerating chemical<br>reactions, posing serious challenges to the durability of perovskite solar<br>cells. Fortunately, before I2can damage the perovskites under illumination,<br>they generally diffuse over a long distance. Therefore, detrimental I2can<br>be captured by interfacial materials with strong iodide/polyiodide (I_x_<br>−)<br>affinities, such as fullerenes and perfluorodecyl iodide. However, fullerenes<br>in direct contact with perovskites fail to confine I_x_<br>−ions within the perovskite<br>layer but cause detrimental iodine vacancies. Perfluorodecyl iodide, with<br>its directional I_x_<br>−affinity through halogen bonding, can both capture and<br>confine I_x_<br>−. Therefore, inverted perovskite solar cells with over 10 times<br>improved ultraviolet irradiation and thermal-light stabilities (under 85 °C<br>and 1 sun illumination), and 1,000 times improved reverse-bias stability<br>(under ISOS-V ageing tests) have been developed.|



Halide perovskites with the formula ABX3 have created a new era of perovskite materials and devices<sup>1,2</sup> . The great successes of halide perovskites in optoelectronic devices rely heavily on the use of iodide ions on their X sites, which makes their bandgap narrow enough to absorb (or emit) visible/near-infrared light. Among these, perovskite solar cells (PSCs) are now close to finding practical applications, as witnessed by their very high certified power conversion efficiencies (PCEs)<sup>3–7</sup> . 

However, the instability of PSCs is also closely associated with the presence of iodide ions. This is because, first, the Pb–I bonds in perovskites are prone to break under incident light with _hν_ > 2.5 eV (that is, photolysis)<sup>8</sup> ; and second, I<sup>−</sup> ions are mobile in solid-state perovskites even under a mild electrical field of _E_ ≈ 0.2 V μm<sup>−1</sup> (refs. 9,10). 

In practical use, high-energy photons, local electrical fields and thermal stress dynamically generate iodine vacancy (VI **·** ), iodide interstitial (Ii′) and iodine (I2) defects in perovskite films. VI **·** are electrically benign but photochemically detrimental because they open up additional decay pathways during long-term operation<sup>11–14</sup> , such as enhanced superoxide (O2−) formation (refs. 13,15). I2 present in perovskite films can make perovskites decompose more quickly under illumination, mainly due to the formation of highly reactive iodine radicals<sup>16</sup> . Iodine radicals trigger the dehydrogenation of organic cations (MA or FA) and generate additional detrimental I2 molecules, leading to self-accelerating chemical reactions<sup>16</sup> . Additionally, the I<sup>−</sup> ions migrating out of the perovskite layer can cause irreversible metal corrosion at the electrode 

> 1Hunan Key Laboratory of Super Microstructure and Ultrafast Process, School of Physics and Electronics, Central South University, Changsha, P.R. China. 2Hunan Key Laboratory of Nanophotonics and Devices, School of Physics and Electronics, Central South University, Changsha, P.R. China. 3College of Materials Science and Engineering, Hunan University, Changsha, P.R. China.<sup>4</sup> Department of Physics and Astronomy, Wright Center for Photovoltaics Innovation and Commercialization, University of Toledo, Toledo, OH, USA.<sup>5</sup> Department of Physics and Astronomy, University of Rochester, Rochester, NY, USA. 

> 6Department of Applied Physical Sciences, University of North Carolina, Chapel Hill, NC, USA. 7These authors contributed equally: Xiaoxue Ren, Jifei Wang. e-mail: junhe@csu.edu.cn; jhuang@unc.edu; yuanyb@csu.edu.cn 

Nature Materials | Volume 23 | June 2024 | 810–817 

**810** 

**Article** 

https://doi.org/10.1038/s41563-024-01876-2 

interface<sup>17</sup> , which becomes even more severe under external bias<sup>18</sup> . In fact, although the lifetimes of PSCs at maximum power point tracking under 1 sun illumination have been improved to thousands of hours, it has been widely observed that PSCs decay rapidly under a reverse bias of −1.0 to −2.0 V within a few minutes<sup>19,20</sup> , posing a serious instability issue for these solar devices. In a consensus statement proposed by 59 scientists in 2020, a bias stability (ISOS-V) test was suggested as a necessary protocol<sup>18</sup> . Although optimizing the stoichiometric ratio can reduce the initial density of VI **·** or Ii′ (refs. 14,21), it cannot prevent the dynamic generation of iodide-related defect pairs. Strategies to stabilize these dynamic iodide-related defects and address the relevant device failures are still rare despite their crucial importance. 

In this study, a strategy based on iodide/polyiodide capture has been proposed to protect perovskites against dynamically released iodine and irreversible I<sup>−</sup> ion loss. We demonstrate the importance and feasibility of maintaining a sustainable halide circulation within the perovskite layer by interfacial iodide/polyiodide capture, which dramatically improves the reverse-bias, ultraviolet and thermal-light stability of the PSCs. 

### **I2- and photon-accelerated ageing in perovskites** 

As a starting point, to gain insights into the detrimental roles of I2 dissolved in perovskites, extrinsic I2 molecules were intentionally introduced by spin coating I2/isopropyl alcohol (IPA) solution on perovskite surfaces, resulting in I2-accelerated perovskite degradation under illumination in a N2 atmosphere being the dominant failure mechanism (Fig. 1a). As a reference, the bare MAPbI3 films decompose quickly (see the cross-sectional scanning electron microscopy (SEM) images in Fig. 1b) in the first 10 h of illumination (white light-emitting diode (LED), 100 mW cm<sup>−2</sup> , Supplementary Fig. 1), which agrees with previously reported observations<sup>16</sup> . Tuning the incident light wavelength, _λ_ (Fig. 1c), reveals that the introduced I2 molecules are benign when _λ_ > 450 nm, but become harmful when _λ_ < 450 nm, which falls into the absorption range of I3− (Supplementary Figs. 2–4 and Supplementary Note 1). The much stronger Raman shift peaks at 114 cm<sup>−1</sup> ( _ν_ 1 mode of I3−), 141 cm−1 ( _ν_ 3 mode of I3−) than that at 169 cm−1 ( _ν_ 1 mode of I2) confirmed that the introduced I2 mainly bind with I<sup>−</sup> and form I3− in perovskites22,23 (Fig. 1d). This result suggests that the coexistence of photogenerated carriers and I2 molecules is harmless, but the excitation of I3− is detrimental. 

The large-size iodine is featured as a polarizable species, which means it is ‘soft’ according to the hard and soft Lewis acid and base concept<sup>24</sup> . The electron-accepting I2 molecule is a kind of soft Lewis acid and can form strong charge-transfer compounds with soft Lewis bases, such as the massive I<sup>−</sup> ions in perovskites. I<sup>−</sup> can bond with different amounts of iodine to form I _x_ −, known as polyiodides and also Lewis bases<sup>25</sup> . When illuminated by high-energy photons, the excited I3− will not necessarily split into I<sup>−</sup> and I2, but can produce iodine radicals<sup>26</sup> (I<sup>**·**</sup> or I2− **·** , process 1 shown in Fig. 1e): 



<!-- Start of picture text -->
I − 3 +  hν  ⟶ I 2 −• + I• (1)<br><!-- End of picture text -->

The generated iodine radicals are highly reactive to dehydrogenate organic cations (MA or FA) and trigger the self-accelerating decomposition of MAPbI3 (Fig. 1b,e). 

### **Suppressed IP-ageing in perovskites with iodides capture** 

Based on the same IP-ageing test, MAPbI3 films covered with a fewnanometre-thick coating of Lewis acids, including C60, [6,6]-phenylC61-butyric acid methyl ester (PCBM), perfluorodecyl iodide (PFI) and iodopentafluorobenzene (5FIB), or Lewis bases, including trioctylphosphine oxide (TOPO), poly(4-vinylpyridine) (PVP), 3-hexylthiophene (HTP) and 1,8-diiodooctane (DIO), were compared (Supplementary Figs. 5–8). Surprisingly, in contrast to the rapid decomposition of bare MAPbI3, there were no morphological or optical absorption changes in most of the soft-Lewis-acid-capped MAPbI3 films after 110 h of 

illumination (C60, PCBM, PFI; Fig. 1b and Supplementary Fig. 9). The influence of the Lewis acid capping layer on the penetration of I2 molecules into MAPbI3 can be excluded because depositing a C60 layer (2 nm) underneath the MAPbI3 film can still surprisingly protect it against IP-ageing (Fig. 1b and Supplementary Fig. 10). 

The protective effect of the soft Lewis acids over the entire perovskite film indicates that I2 or iodine radicals may diffuse a surprisingly long distance in perovskite films before they can cause damage. This property enables soft Lewis acids to efficiently scavenge those detrimental I2 or iodine radicals even deep inside perovskite films (Fig. 1f,g). To prove this, the influence of C60 on the location of I3− was studied by Raman shift signal mapping (at 141 cm<sup>−1</sup> ; Fig. 1h and Supplementary Note 2). The samples are MAPbI3 films with introduced I2 and a patterned C60 layer. Irrespective of whether the C60 layer was on the top (mapping A) or the bottom of the perovskite layer (mapping B), the I3− preferentially accumulated at the regions contacting with the patterned C60. It was also confirmed that the I3− ions resulting from the initial I2 on top of the perovskite films disappeared from the top surface (mapping C) when the C60 layer is located on the bottom side, indicating a robust I3−-capture effect of the C60 layer27. The bonding between I2 and the I<sup>−</sup> ions on lattice or grain surface/boundaries may provide the diffusion channels for I2 (that is, process 3 in Fig. 1f) because the hopping of I2 between two I<sup>−</sup> ions is energetically allowed<sup>26</sup> : 



<!-- Start of picture text -->
(I ⋯ I2)− + I− ⟶ I− + I2 ⋯ I− ⟶ I− + (I ⋯ I2)− (2)<br><!-- End of picture text -->

In the presence of a soft Lewis acid as an iodide/polyiodide capturer (ICAP), the random diffusion of I2 ends up with their bonding with the ICAP (that is, process 4 in Fig. 1f): 



<!-- Start of picture text -->
(I ⋯ I2)− + (I ⋯ ICAP)− ⟶ I− + (I ⋯ I2 ⋯ ICAP)− (3)<br><!-- End of picture text -->

Detailed study confirms that, among several organic electron transport materials, only PCBM and C60 can scavenge I2 and stabilize the perovskite films efficiently (Fig. 2a), suggesting that the softness of the Lewis acid is more crucial than the lowest unoccupied molecular orbital level of the material (Supplementary Note 3 and Supplementary Figs. 12 and 13). In addition to fullerenes, molecules with fluorocarbon chains and terminated with an iodine atom are also ICAPs. The strong electron-withdrawing properties of fluorocarbon chains make their terminal iodine positively charged and ready to accept the unpaired electron from negatively charged I<sup>−</sup> or I _x_ − ions. This interaction is also specialized as halogen bonding<sup>28</sup> . The strength with which the terminal iodine binds with I _x_ − is proportional to its positive charge (that is, σ-hole). In our study, PFI and 5FIB molecules have been compared in terms of the formation of halogen bonds with iodide compounds (for example, perovskite, formamidinium iodide (FAI), CsI and PbI2). The chemical shifts of the fluorine atoms on the fluorocarbon chain were characterized by NMR (Fig. 2b,c). After mixing with formamidinium caesium (FACs)-based perovskites, the changes in the chemical shifts of the fluorine atoms nearest to the terminal iodine are significantly larger on PFI (8.1 ppm) than on 5FIB (0.4 ppm)<sup>29,30</sup> . Similarly, PFI forms stronger charge-transfer compounds than 5FIB when mixed with FAI, CsI or PbI2 (Fig. 2c and Supplementary Fig. 14). The shorter separation between electron-withdrawing fluorine and iodine atoms in PFI (I–C–F) compared with in 5FIB (I–C–C–F) might be responsible for the higher I<sup>−</sup> (or I _x_ −) ion affinity of PFI. Consistently, the IP-ageing study shows that the iodide-capture ability of PFI is comparable to that of C60 but much better than that of 5FIB (Fig. 2a). According to our density functional theory calculation, the binding energy between the terminal iodine of PFI and the I<sup>−</sup> ions on the (001) surface of FA-based perovskite is 0.26 eV with a bond length of 3.38 Å (Supplementary Fig. 15 and Supplementary Note 4). 

The interaction between iodide/polyiodide and C60 (and PFI) efficiently suppresses ion migration along the grain surface and boundaries. The measured effective activation energy ( _E_ A) for ion migration (for example, I<sup>−</sup> ) increases from 0.55 eV to 0.84 eV (or 0.94 eV) after C60 (or 

Nature Materials | Volume 23 | June 2024 | 810–817 

**811** 

**Article** 

https://doi.org/10.1038/s41563-024-01876-2 



<!-- Start of picture text -->
a c d<br>141 Pristine<br>I2:IPA 1.0 I3– ( ν 3) With added I2, no C60<br>spin coating<br>114 With added I2, C60 at bottom<br>PVSK 0.8 I3– ( ν 1) (on region C)<br>169<br>Illumination 0.6 390 nm with I2 I2 ( ν 1) 281 335<br>I3– (2 ν 3) I2 (2 ν 1)<br>hν 450 nm with I2<br>0.4 675 nm with I2<br>PVSK Extrinsic I2<br>745 nm with I2<br>0 50 100 150 200 250 100 150 200 250 300 350<br>Time (h) Raman shift (cm –1 )<br>b PTAA/MAPbI3 PTAA/MAPbI3/C60 PTAA/C60/MAPbI3<br>Pristine Pristine Pristine<br>10 h 24 h 24 h<br>e MA (or FA) f Raman<br>mapping A I2<br>HI<br>I • C60<br>4<br>1<br>5<br>2<br>3<br>PVSK<br>hν hν<br>g Raman h Mapping A Mapping B Mapping C<br>mapping C 320<br>242<br>3 5<br>155<br>4<br>67<br>Raman hν –20<br>mapping B w/o C60 w C60 w/o C60 w C60 w/o C60<br>Intensity (a.u.)<br>Normalized absorbance (a.u.)<br>Intensity (a.u.)<br><!-- End of picture text -->

**Fig. 1 | Accelerated ageing of perovskites with extrinsic I2 and photons (IP-ageing) and its suppression. a** , The introduction of I2 in perovskite films for the accelerated ageing test under illumination. **b** , Cross-sectional SEM images of bare PTAA/MAPbI3, PTAA/MAPbI3/C60 (10 nm) and PTAA/C60 (2 nm)/MAPbI3 samples during the IP-ageing process, respectively. Scale bars, 1 μm. **c** , Influence of the wavelength of incident photons on the decay rate of MAPbI3 during IP-ageing. **d** , Raman spectra of MAPbI3 films without (black) or with intentionally introduced I2 (blue). **e** , Illustration of the IP-ageing of perovskites with introduced I2: release of iodine radical from I2 under illumination (1); iodine-radical-induced 

dehydrogenation (2). **f** , Illustration of the long-distance diffusion of I2 in perovskite films (3), the iodide/polyiodide capture effect (4) of the patterned C60 on the top of perovskite films, and the release of iodine radical from ideal perovskites by photolysis (5). **g** , The iodide/polyiodide capture effect provided by the patterned C60 at the bottom of perovskite film. **h** , Mapping of the Raman shift signal at 141 cm<sup>−1</sup> (from I3− ions) in region A (marked in **f** , 50 × 50 μm2), region B and region C (marked in **g** , 50 × 50 μm<sup>2</sup> ), respectively. The Raman spectrum taken at region C is also shown in **d** (green). 

PFI/C60) coverage (Fig. 2d–f). Moreover, while there was no absorption change in the FACs-based perovskite sample after a primary ageing of 48 h with I2 and illumination (Supplementary Fig. 16), the concentration of mobile ions in the control sample increased by ~30 times, and the _E_ A decreased from 0.55 eV to 0.41 eV, which implies that new defects were released and faster ion-migrating channels were formed at this initial 

stage of IP-ageing. By contrast, both C60 and PFI/C60 passivated samples show overlapped Arrhenius plots after the same ageing process, indicating that the IP-ageing has been suppressed by C60 and PFI/C60. 

In perovskite films without extrinsic I2, the detrimental I2 can also be generated by other excitations, such as the breaking of Pb–I bonds with high-energy photon irradiation (that is, photolysis at 

Nature Materials | Volume 23 | June 2024 | 810–817 

**812** 

**Article** 

https://doi.org/10.1038/s41563-024-01876-2 



<!-- Start of picture text -->
a b c<br>Bare FACs-PVSK PFI  5FIB<br>HTP 8.10 ppm PFI/PVSK 10<br>TOPO 8.70<br>8.10<br>PVP 5.10 ppm PFI/PbI2 8<br>DIO<br>5FIB 6<br>PFI 8.90 ppm PFI/CsI 5.10<br>C60 4<br>PCBM 8.70 ppm PFI/FAI<br>PTCDA 2<br>PTCDIF16CuPc I-CF2 CF3 PFI 1.07 0.01 0.80 0.29 0.40<br>0<br>0 200 400 600 –50 –60 –70 –80 –90 I2 FAI PbI2 PVSK<br>Time (h) 19F chemical shift (ppm)<br>d e f<br>(360 K) (360 K)<br>–8 –8 –8<br>(360 K)<br>–10 –10 Before,  E A = 0.84 eV –10 Before,  E A = 0.94 eV<br>After,  E A = 0.41 eV<br>–12 –12 After,  E A = 0.82 eV –12 After,  E A = 0.91 eV<br>Before, (200 K) (200 K) (200 K)<br>–14 E A = 0.55 eV –14 –14<br>30 35 40 45 50 55 60 30 35 40 45 50 55 60 30 35 40 45 50 55 60<br>1/ kT  (eV –1 ) 1/ kT  (eV –1 ) 1/ kT  (eV –1 )<br>g<br>1.0<br>0.8<br>Bare FACs-PVSK<br>0.6 FACs-PVSK/C60<br>FACs-PVSK/PFI/C60<br>0.4<br>0 50 100 150 200 250 300 350 400 450 500<br>Time (h)<br>Fig. 2 | Molecules with strong iodide/polyiodide affinity to prevent  d – f , Arrhenius plots of the conductivity of the bare FACs-PVSK (composition,<br>perovskites from IP-ageing. a , Influence of the capping materials on the ageing  FA0.90Cs0.10PbI2.83Br0.17) ( d ), FACs-PVSK/C60 ( e ) and FACs-PVSK/PFI/C60 ( f ) films<br>time needed for FACs-based perovskites to lose 10% of their absorption at a  before and after 48 h of IP-ageing, respectively, where the  E A are calculated from<br>wavelength of 600 nm.  b , Chemical shifts ( δ ) of the fluorine atoms on PFI before  the slope of the curves.  g , Absorption reduction (at 600 nm) of FACs-PVSK,<br>and after binding with different iodide compounds, respectively.  c , The changes  FACs-PVSK/C60 and FACs-PVSK/PFI/C60 films (without extrinsic I2) under<br>in chemical shifts (Δ δ ) of the fluorine atoms nearest to the terminal iodine on PFI  ultraviolet light exposure (395 nm, 60 mW cm −2 ) at 85 °C.<br>Lewis base<br>Lewis acid<br>Intensity (a.u.)<br>19F chemical shift  (ppm) ∆δ<br>ETL<br>–1) (ln(S m))ln( σ –1))) (ln(S mln( σ –1))) (ln(S mln( σ<br>Normalized absorbance (a.u.)<br><!-- End of picture text -->

**Fig. 2 | Molecules with strong iodide/polyiodide affinity to prevent perovskites from IP-ageing. a** , Influence of the capping materials on the ageing time needed for FACs-based perovskites to lose 10% of their absorption at a wavelength of 600 nm. **b** , Chemical shifts ( _δ_ ) of the fluorine atoms on PFI before and after binding with different iodide compounds, respectively. **c** , The changes in chemical shifts (Δ _δ_ ) of the fluorine atoms nearest to the terminal iodine on PFI and 5FIB after binding with iodine or iodide compounds, respectively. 

_hν_ > 2.5 eV) or heating<sup>31</sup> . Encouragingly, covering perovskite films with a PFI/C60 (10 nm) bilayer slows down the ultraviolet-induced decomposition process by ~20 times (Fig. 2g and Supplementary Fig. 17). The PFI/C60-covered FACs perovskites do not show any absorption changes after a harsh ultraviolet light aging of 393 h under 60 mW cm<sup>−2</sup> at 85 °C (that is, 235 kWh m<sup>−2</sup> ). 

### **ICAPs for PSCs with high reverse-bias stability** 

The results above consistently proved the notable binding of I<sup>−</sup> /I _x_ − ions with C60 and PFI. Systematic studies proved that PFI can protect different perovskites with varied Br<sup>−</sup> ion substitution, for example, FA0.9Cs 0.1<sup>Pb(I</sup> 1− _x_<sup>Br</sup> _x_<sup>)</sup> 3<sup>(</sup><sup>_x_= 0%, 5.7%, 10%), against detrimental I</sup> 2<sup>, indicating the</sup> universality of using ICAPs (Supplementary Figs. 18–20). However, it must be emphasized that an ICAP with good iodide affinity can also be a double-edged sword if it promotes the escape of I<sup>−</sup> /I _x_ − ions. For example, a previous study proposed and proved that metals (for example, silver) outside the perovskite layer can scavenge mobile I<sup>−</sup> ions by forming an irreversible chemical reaction, which gives a reduced current hysteresis but may not be helpful for device stability<sup>32</sup> . 

Unfortunately, C60 with spherical symmetry binds with I<sup>−</sup> /I _x_ − ions non-directionally (Fig. 3a) and hence forms continuous channels for the iodide to transport toward and react with metal cathode. Owing to this feature, I<sup>−</sup> ions or I2 molecules have been frequently found in C60 or PCBM layers<sup>33,34</sup> . The non-directional binding between C60 and I<sup>−</sup> /I _x_ − ions becomes an even more severe problem in reverse-biased PSCs because the applied electrical field aggravates the I<sup>−</sup> /I _x_ − ion migration. In our study, for FACs-based control PSCs with C60 as the electron transport layer (ETL) directly contacting with perovskite, the PCE dropped dramatically from 18.5% to 7.1% (Fig. 3b) after a short reverse-bias treatment (−1.0 V, 200 s); this rate of PCE decline is in agreement with other reported results<sup>19,20</sup> . 

As a major difference, the interaction between PFI and I<sup>−</sup> /I _x_ − ions aided by halogen bonding is directional. The _σ_ -hole located at the end of the terminal iodine only allows I<sup>−</sup> ions to attach in the opposite direction of the I–C bonds with an I⋯I–C binding angle of nearly 180°<sup>28,35</sup> (Fig. 3a). Here, we use this property of PFI to lock the I<sup>−</sup> /I _x_ − ions at the PVSK/PFI interface and meanwhile scavenge harmful I2 (and iodine radicals) from the perovskite layer. Encouragingly, PSCs with PFI/PCBM/C60 as the ETL become highly stable under reverse-bias stress (Fig. 3b, Supplementary 

Nature Materials | Volume 23 | June 2024 | 810–817 

**813** 

**Article** 

https://doi.org/10.1038/s41563-024-01876-2 



<!-- Start of picture text -->
a – I –  ion PFI b<br>24<br>Pristine<br>18<br>12<br>C60 6<br>After –1.0 V, 200 s<br>+ + + 0 PVSK/C60<br>– I –  ion – 24 Pristine<br>18 After –2.0 V, 2.0 h<br>FA + 12<br>6<br>PbI6 0  PVSK/PFI/PCBM/C60<br>octahedra<br>–0.2 0 0.2 0.4 0.6 0.8 1.0 1.2<br>Non-directional binding Directional binding Voltage (V)<br>c After recovery in dark, 6.0 h d<br>PVSK/PFI/PCBM/C60 1.2<br>1.0<br>0.8<br>0.8 T 90 = 5.0 h Before 0.4 PVSK/PFI/PCBM/C60<br>–4.5 V, 85 °C, dark recovery 0 PVSK/PCBM PVSK/C60<br>0.6<br>PVSK/PFI/PCBM/C60<br>T 90 = 18 h<br>0.4 PVSK/C60 –2.0 V, r.t., ligh t 1.0<br>0.2 –1.5 V, r.t., dark –2.0 V, r.t., dark T 90 = 100 h 0.8 300 K   340 K   365 K<br>–1.5 V, r.t., light 320 K   350 K   375 K<br>0.01 0.1 1 10 100 –6 –5 –4 –3 –2 –1 0<br>Reverse-bias duration (h) Reverse bias (V)<br>e With C60 With PFI/PCBM/C60 f g<br>–1.0 V –2.0 V 105 100 °C, 20 h 24<br>2.83 2.60 2.51 2.83 2.83 2.83 100 18<br>5 100 °C, 12 h<br>100 12 With PFI/PCBM/C60<br>5 100 °C, 5 h 6 Fresh sample<br>0 Aged at –2.0 V, 18 h<br>105 w/o heating 0 Before recovery<br>0 After recovery<br>0 h 2 h 4 h 0 h 12 h 24 h –10 –8 –6 –4 –2 0 –0.2 0 0.2 0.4 0.6 0.8 1.0 1.2<br>Reverse-bias duration (h) Voltage (V) Voltage (V)<br>–2)Current density (mA cm<br>Normalized PCE Normalized PCE<br>I:Pb ratio<br>–2)Current density (mA cm –2)Current density (mA cm<br><!-- End of picture text -->

**Fig. 3 | Engineered ICAPs for PSCs with improved reverse-bias stability. a** , Illustration of C60 with non-directional iodine affinity and PFI with directional iodine affinity (that is, a halogen bond), respectively. **b** , Comparison of current density ( _J_ )–voltage ( _V_ ) curves of control PSCs (top) and PFI/PCBM/C60-based PSCs (bottom) before and after reverse-bias treatment (in situ treated under AM1.5G), respectively. **c** , Normalized PCEs of the aged PSCs (at room temperature (r.t.) or 85 °C, dark or illumination) as a function of the reverse-bias hold time. The PFI/PCBM/C60-based PSCs survived from ageing at −2.0 V under light for 18 h, and showed a self-recovery effect after a 6 h storage in the dark (green points), which survived from ageing again at −3.0 V sequentially (Supplementary Fig. 21). 

**d** , PCE values of the aged PSCs as a function of the reverse bias applied (200 s), in which the treatments were carried out at room temperature (top) or elevated temperature (bottom) and the PCE data were extracted from _J_ – _V_ curves after each treatment. **e** , Changes in the iodine 3 _d_ core level peaks as a function of the reverse-bias hold time, where the XPS spectra were measured from the metal electrodes peeled off from control PSCs (bottom) or PFI/PCBM/C60-based PSCs (top), respectively. **f** , _J_ – _V_ curve of the PSCs with PFI/PCBM/C60 interfacial layers and their perovskite films preheated at 100 °C in N2 (before PFI coating) for different times. **g** , _J_ – _V_ curves of the fresh, aged (by −2.0 V, 18 h) and self-recovered (in dark, 6 h) PFI/PCBM/C60-based PSCs, respectively. 

Tables 1 and 2). The device maintains 90% of its initial PCE value after an ultralong reverse-bias stress of 100 h in the dark or 18 h under sunlight at −2.0 V (Fig. 3c and Supplementary Fig. 21), with the reverse-bias stability improved by three orders of magnitude. Moreover, the PFI/PCBM/C60 devices can maintain 90% of their PCE under a high bias of −4.5 V at 85 °C for 5 h (Fig. 3c,d and Supplementary Figs. 22 and 23), in which conditions the control device failed in a few seconds. Notably, this improvement cannot be achieved by replacing PFI with other interfacial layers (Supplementary Fig. 24). These are, to our knowledge, the first devices with regular thickness to survive the harsh ISOS-V-2I ageing test<sup>18</sup> . 

To confirm the relationship between reverse-bias stability and the outward migration of I<sup>−</sup> /I _x_ − ions from the perovskite layer, the elements on the peeled-off silver electrodes before and after reverse-bias treatment were analysed by X-ray photoelectron spectroscopy (XPS). For control 

PSCs, the peeled-off electrode showed significantly increased iodine 3 _d_ (619.11 eV and 630.52 eV) core level peaks in the first 2 h of −1.0 V treatment (Supplementary Fig. 25 and Supplementary Table 3). On the other hand, the I:Pb ratio on the exposed perovskite surface decreased from 2.83 to 2.60 (Fig. 3e, Supplementary Fig. 26 and Supplementary Table 4) due to the iodine loss. In the case of PSCs with a PFI/PCBM/C60 interfacial layer, no additional iodine signal can be detected on the peeled-off electrode even after a prolonged reverse-bias treatment (−2.0 V, 24 h), and the I:Pb ratio (2.83) on the exposed perovskite surface remained unchanged. 

The escape of I<sup>−</sup> /I _x_ − ions results in a gradual increase in the number of VI **·** defects in the perovskite layer, creating a major device failure mechanism under reverse bias. This can be demonstrated by intentionally generating VI **·** defects in perovskite films (before covering PFI molecules) and then carrying out the same reverse-bias stability test. 

Nature Materials | Volume 23 | June 2024 | 810–817 

**814** 

**Article** 

https://doi.org/10.1038/s41563-024-01876-2 



<!-- Start of picture text -->
a b c<br>25<br>20 10 With C60<br>20 8 With PFI/PCBM/C60<br>15<br>15<br>6<br>10 10 With CWith C6060, F, R 4<br>5 Bare PVSK film 5 With PFI/PCBM/C60, F 2<br>PVSK film with PFI With PFI/PCBM/C60, R<br>0 0 0<br>0 10 20 30 40 0 0.2 0.4 0.6 0.8 1.0 1.2 16 17 18 19 20 21<br>Heating time (h) Voltage (V) PCE (%)<br>d<br>1.0<br>0.8<br>0.6<br>0.4 With C60 With PFI/PCBM/C60<br>0 50 100 150 200 250 300<br>e<br>1.0<br>0.8<br>0.6<br>0.4<br>0 300 600 900 1,200 1,500 1,800 2,100<br>f<br>1.0<br>0.8<br>0.6<br>0.4<br>0 100 200 300 400 500 600 700 800<br>Time (h)<br>g<br>Annihilation of 3 E A1 for I i ’ Trapping interfacial barrier<br>Frenkel defects migration of I i ’<br>5<br>I –<br>Energy level I – I – I –<br>for I i ’ ( E | i ) I –<br>2 ∆ E 2 E | i , s I –  ions affinityof ETL<br>2 1 E D<br>I – E sto– I, s<br>∆ E 1<br>Energy level for I – V I . I – V I . I – I – I – V I . Levels after binding<br>stoichiometric I – with ICAP<br>in  x -site ( E sto– I)<br>Trapping<br>E A2 of VI . 4 Excitation of annihilationSurface of VI .<br>migration Frenkel defects<br>PCE (%) Counts<br>–2)Current density (mA cm<br>Normalized PCE<br><!-- End of picture text -->

**Fig. 4 | PFI/PCBM/C60-based PSCs with improved efficiency and stability. a** , PCEs of PSCs fabricated with the perovskite films post-treated with light (1 sun) and thermal annealing (85 °C) for different times before the deposition of the ETL. **b** , Typical _J_ – _V_ curves of the control and PFI/PCBM/C60-based PSCs. **c** , Statistics of PCE distribution for PSCs with C60 or PFI/PCBM/C60 as the ETL, respectively. **d** – **f** , Normalized PCEs of PSCs with a C60 (pink sphere) or PFI/PCBM/C60 (blue sphere) interfacial layer as a function of the continuous ageing time, in which the devices were aged under ultraviolet illumination (395 nm, 60 mW cm<sup>−2</sup> ) ( **d** ), 1 sun illumination (AM1.5G) at room temperature ( **e** ) and 1 sun illumination (LED lamp) combined with 85 °C heating ( **f** ). **g** , Brief illustration of the energy diagram for 

the mobile defects (Ii′ and VI **·** ) in perovskites. The processes of excitation of a pair of Frenkel defects (1, with defect formation energy of _E_ D), bulk (left) and surface (right) annihilation between Ii′ and VI **·** (2), migration of Ii′ (3, with activation energy of _E_ A1) and VI **·** (4, with activation energy of _E_ A2), outward migration of I− ions from perovskites to the ETL (5) are schematically shown. Capturing the dynamically generated iodide species (I2 and Ii′) and confining iodide species inside the perovskite layer with PFI/PCBM/C60 facilitates a sustainable halide circulation. Data points in **a** are presented as mean ± s.d. ( _n_ = 10–16). The data in **d** , **e** are shown as mean ± s.d. ( _n_ = 3). Data in **f** are presented as mean ± s.d. ( _n_ = 20). In cases where error bars are not visible, they are smaller than the symbol size. 

Even if the escape of I<sup>−</sup> /I _x_ − ions can be prevented with the PFI layer, a dramatically decreased reverse breakdown voltage of PSCs from ~−7.9 V to ~−2.5 V can be observed once the initial concentration of VI **·** defects in perovskite layer has been increased by 20 h of thermal annealing (Fig. 3f and Supplementary Note 5). Accordingly, the reverse-bias stability under sunlight at −2.0 V decreased by one order of magnitude (Supplementary Fig. 27). We speculate that the increased VI **·** defects can migrate and accumulate under reverse bias, which triggers strong locate band bending and charge carrier influx. For perovskite regions flooded with charge carriers, new troublesome defects would be formed or permanent destruction would occur. 

The close relationship between ion migration and reverse-bias stability is also supported by studying the transient displacement current (Supplementary Note 6). In control PSCs, the displacement current caused by ion migration is significant at room temperature and can be frozen when the device is cooled to 250 K (Supplementary Figs. 28 and 29). Consistently, the control PSCs also become reverse-bias-stable at _T_ < 250 K (Supplementary Fig. 30). On the contrary, no ionic displacement current can be detected in PSCs with a PFI/PCBM/C60 interfacial layer up to a high reverse bias of −5.5 V (Supplementary Fig. 31). 

More surprisingly, the 10% PCE loss observed in the PFI/PCBM/C60based device after 18 h of −2.0 V ageing can be self-recovered after 

Nature Materials | Volume 23 | June 2024 | 810–817 

**815** 

**Article** 

https://doi.org/10.1038/s41563-024-01876-2 

storage in the dark overnight (Fig. 3c,g). This self-recovery effect might be related to the gradual annihilation between the I<sup>−</sup> /I _x_ − ions accumulated at the PVSK/PFI interface and the diffusive VI **·** defects36, which essentially benefits from the strong I<sup>−</sup> /I _x_ − ion confinement offered by PFI. The 1,000 times slower PCE degradation rate and the timely self-recovery effect suggest that instability related to reverse bias, or shading, is not a limiting factor for perovskite thin-film solar cells. 

surface. Directional halogen bonds offered by PFI molecules can lock the I<sup>−</sup> ions and facilitate a sustained iodide circulation in the perovskite layer. PSCs with PFI/PCBM/C60 as the ETL can survive 100 h of the ISOS-V-I ageing test (−2.0 V at room temperature) and 5 h of the ISOS-V-2I ageing test (−4.5 V at 85 °C). These devices also show comprehensively improved ultraviolet stability (12 times higher dosage than the IEC61215 requirement) and thermal-light stability (85 °C, 765 h at conditions near the MPP). 

### **Solar cell performance and operational stability** 

The I<sup>−</sup> ion confinement offered by PFI helps to prevent unintentional iodide loss during fabrication (for example, thermal annealing), which minimizes the initial VI **·** concentration in the resulting perovskite films. As a demonstration, the as-cast FACs perovskite films were intentionally annealed at 85 °C in N2 under white light (approximating to 1.0 sun) for 40 h (Fig. 4a and Supplementary Note 5), after which a PSC was subsequently fabricated and measured. The PCE of the control sample (without PFI) dropped from 18.5% to ~7.3%, whereas the PCE of the sample covered with PFI maintains 94% of its initial efficiency (19.9%). This increased heating tolerance broadens the processing windows and hence improves the fabrication yield of PSCs. Furthermore, the dipole direction of the PFI molecules on the perovskite surface is beneficial for charge collection in PSCs with an inverted structure<sup>37</sup> . Due to these advantages, PFI/PCBM/C60-based PSCs generally show increased open-circuit voltage ( _V_ OC)(Fig. 4b, Supplementary Fig. 32 and Supplementary Table 5) and PCE (Fig. 4c). 

The operational stabilities of PSCs have been substantially improved after inserting the PFI layer. Under ultraviolet illumination (395 nm, 60 mW cm<sup>−2</sup> ), the PFI/PCBM/C60-based device can maintain 85% of its initial PCE after 300 h of illumination, corresponding to an ultraviolet irradiation dose of 180 kWh m<sup>−2</sup> (Fig. 4d). The ultraviolet stability of PSCs has been improved to be 12 times of that required in the IEC61215 ultraviolet test<sup>38</sup> . 

When ageing near their maximum power points (MPPs) at 1 sun illumination (unencapsulated, in N2, AM1.5G), the PFI/PCBM/C60 device maintained 90% of its initial PCE after 1,500 h, the lifetime of which has been improved by ~30 times compared with the control devices. It should be noted that PSCs are susceptible to multiple influencing factors under practical working conditions, such as interfacial degradation related to the hole transport layer. The decline in efficiency of the PFI/PCBM/C60 device observed in Fig. 4e might be caused by other factors beyond the photolysis-released I2 or the loss of I<sup>−</sup> ions, which need to be further addressed by combining ICAP with other stabilizing strategies. Nevertheless, running the PSCs near the MPP condition at an elevated temperature of 85 °C can add more insights into the intrinsic stability of PFI/PCBM/C60-based devices. In contrast to the control device, which showed ~40% efficiency decline after 120 h of operation, the PFI/PCBM/C60-based device maintained 80% of its initial PCE after 765 h of operation (Fig. 4f and Supplementary Fig. 33), which is among the highest stability of inverted PSCs achieved so far under such harsh test conditions. 

All these much improved stabilities described above are attributed to the PFI layer. The PFI layer dynamically scavenges the released iodine at elevated temperature while preventing iodine loss from the perovskite layer, which is a different mechanism with the steric effect on organic cations and water molecules<sup>39</sup> . For a better understanding, a brief schematic energy diagram of the I<sup>−</sup> ion is proposed in Fig. 4g and explained in Supplementary Note 7. The PFI has a superior role compared with C60 in preventing I<sup>−</sup> ion loss because it eliminates the iodine transport channels near the PVSK/ETL interface, and therefore creates a closed and benign circulation of iodine-related defects in halide perovskites. 

In summary, due to the long diffusion distance of I2 in perovskites, the highly detrimental I2 deep in the perovskite layers can be scavenged by ICAPs on the surface of perovskites. Conversely, the reverse-bias stability of inverted PSCs is very sensitive to ICAPs on the perovskite 

### **Online content** 

Any methods, additional references, Nature Portfolio reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41563-024-01876-2. 

### **References** 

1. Kojima, A., Teshima, K., Shirai, Y. & Miyasaka, T. Organometal halide perovskites as visible-light sensitizers for photovoltaic cells. _J. Am. Chem. Soc._ **131** , 6050–6051 (2009). 

2. Mitzi, D. B., Field, C. A., Harrison, W. T. A. & Guloy, A. M. Conducting tin halides with a layered organic-based perovskite structure. _Nature_ **369** , 467–469 (1994). 

3. Zhao, Y. et al. Inactive (PbI2)2RbCl stabilizes perovskite films for efficient solar cells. _Science_ **377** , 531–534 (2022). 

4. Fei, C. et al. Lead-chelating hole-transport layers for efficient and stable perovskite minimodules. _Science_ **380** , 823–829 (2023). 

5. Gu, H. et al. Design optimization of bifacial perovskite minimodules for improved efficiency and stability. _Nat. Energy_ **8** , 675–684 (2023). 

6. National Renewable Energy Laboratory, Best Research-Cell Efficiency Chart (2023); https://www.nrel.gov/pv/cell-efficiency. html 

7. Green, M. A. et al. Solar cell efficiency tables (Version 63). _Prog. Photovoltaics Res. Appl._ **32** , 3–13 (2024). 

8. Phung, N. et al. Photoprotection in metal halide perovskites by ionic defect formation. _Joule_ **6** , 2152–2174 (2022). 

9. Eames, C. et al. Ionic transport in hybrid lead iodide perovskite solar cells. _Nat. Commun._ **6** , 7497 (2015). 

10. Yuan, Y. & Huang, J. Ion migration in organometal trihalide perovskite and its impact on photovoltaic efficiency and stability. _Acc. Chem. Res._ **49** , 286–293 (2016). 

11. Deng, Y. et al. Defect compensation in formamidinium–caesium perovskites for highly efficient solar mini-modules with improved photostability. _Nat. Energy_ **6** , 633–641 (2021). 

12. Xie, H. et al. Decoupling the effects of defects on efficiency and stability through phosphonates in stable halide perovskite solar cells. _Joule_ **5** , 1246–1266 (2021). 

13. Lin, D. et al. Ion migration accelerated reaction between oxygen and metal halide perovskites in light and its suppression by cesium incorporation. _Adv. Energy Mater._ **11** , 2002552 (2021). 

14. Tan, S. et al. Shallow iodine defects accelerate the degradation of α-phase formamidinium perovskite. _Joule_ **4** , 2426–2442 (2020). 

15. Aristidou, N. et al. Fast oxygen diffusion and iodide defects mediate oxygen-induced degradation of perovskite solar cells. _Nat. Commun._ **8** , 15218 (2017). 

16. Wang, S. et al. Accelerated degradation of methylammonium lead iodide perovskites induced by exposure to iodine vapour. _Nat. Energy_ **2** , 16195 (2017). 

17. Kato, Y. et al. Silver iodide formation in methyl ammonium lead iodide perovskite solar cells with silver top electrodes. _Adv. Mater. Interfaces_ **2** , 1500195 (2015). 

18. Khenkin, M. V. et al. Consensus statement for stability assessment and reporting for perovskite photovoltaics based on ISOS procedures. _Nat. Energy_ **5** , 35–49 (2020). 

Nature Materials | Volume 23 | June 2024 | 810–817 

**816** 

**Article** 

https://doi.org/10.1038/s41563-024-01876-2 

19. Ni, Z. et al. Evolution of defects during the degradation of metal halide perovskite solar cells under reverse bias and illumination. _Nat. Energy_ **7** , 65–73 (2022). 

20. Razera, R. A. Z. et al. Instability of p–i–n perovskite solar cells under reverse bias. _J. Mater. Chem. A_ **8** , 242–250 (2020). 

21. Kang, D. H., Kim, S. Y., Lee, J. W. & Park, N. G. Efficient surface passivation of perovskite films by a post-treatment method with a minimal dose. _J. Mater. Chem. A_ **9** , 3441–3450 (2021). 

22. Udalova, N. N. et al. New features of photochemical decomposition of hybrid lead halide perovskites by laser irradiation. _ACS Appl. Mater. Interfaces_ **12** , 12755–12762 (2020). 

23. Petrov, A. A. et al. A new formation strategy of hybrid perovskites via room temperature reactive polyiodide melts. _Mater. Horiz._ **4** , 625–632 (2017). 

24. Pearson, R. G. & Songstad, J. Application of the principle of hard and soft acids and bases to organic chemistry. _J. Am. Chem. Soc._ **89** , 1827–1836 (1967). 

25. Svensson, P. H. & Kloo, L. Synthesis, structure, and bonding in polyiodide and metal iodide–iodine systems. _Chem. Rev._ **103** , 1649–1684 (2003). 

26. Boschloo, G. & Hagfeldt, A. Characteristics of the iodide/triiodide redox mediator in dye-sensitized solar cells. _Acc. Chem. Res._ **42** , 1819–1826 (2009). 

27. Xu, J. et al. Perovskite–fullerene hybrid materials suppress hysteresis in planar diodes. _Nat. Commun._ **6** , 7081 (2015). 

28. Metrangolo, P. et al. Halogen bonding in perovskite solar cells: a new tool for improving solar energy conversion. _Angew. Chem. Int. Ed._ **61** , e202114793 (2022). 

29. Abate, A. et al. Halogen-bond driven self-assembly of perfluorocarbon monolayers on silicon nitride. _J. Mater. Chem. A_ **7** , 24445–24453 (2019). 

30. Abate, A. et al. Supramolecular halogen bond passivation of organic–inorganic halide perovskite solar cells. _Nano Lett._ **14** , 3247–3254 (2014). 

31. Liu, F. et al. Is excess PbI2 beneficial for perovskite solar cell performance? _Adv. Energy Mater._ **6** , 1502206 (2016). 

32. Teymourinia, H. et al. Interfacial passivation of perovskite solar cells by reactive ion scavengers. _ACS Appl. Energy Mater._ **4** , 1078–1084 (2021). 

33. Akbulatov, A. F. et al. Effect of electron-transport material on light-induced degradation of inverted planar junction perovskite solar cells. _Adv. Energy Mater._ **7** , 1700476 (2017). 

34. Hu, J. et al. Tracking the evolution of materials and interfaces in perovskite solar cells under an electric field. _Commun. Mater._ **3** , 39 (2022). 

35. Ball, M. L., Millic, J. V. & Loo, Y.-L. The emerging role of halogen bonding in hybrid perovskite photovoltaics. _Chem. Mater._ **34** , 2495–2502 (2022). 

36. Kim, G. Y. et al. Large tunable photoeffect on ion conduction in halide perovskites and implications for photodecomposition. _Nat. Mater._ **17** , 445–449 (2018). 

37. Canil, L. et al. Tuning halide perovskite energy levels. _Energ. Environ. Sci._ **14** , 1429–1438 (2021). 

38. Mei, A. et al. Stabilizing perovskite solar cells to IEC61215:2016 standards with over 9000-h operational tracking. _Joule_ **4** , 2646–2660 (2020). 

39. Wolff, C. M. et al. Perfluorinated self-assembled monolayers enhance the stability and efficiency of inverted perovskite solar cells. _ACS Nano_ **14** , 16156–16156 (2020). 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law. 

© The Author(s), under exclusive licence to Springer Nature Limited 2024 

Nature Materials | Volume 23 | June 2024 | 810–817 

**817** 

**Article** 

https://doi.org/10.1038/s41563-024-01876-2 

### **Methods** 

##### **Materials** 

_N_ , _N_ -Dimethylformamide (DMF, 99.8%, anhydrous), dimethylsulfoxide (DMSO, 99.8%, anhydrous), chlorobenzene (CB, 99.8%, anhydrous), IPA (anhydrous, 99.8%), PbI2 (99.999%), PbBr2 (99.999%), CsI (99.99%), PFI (97%), TOPO (99%), PVP ( _M_ w = 160,000), DIO (98%), bathocuproine (BCP, 99.99%), _N_ , _N_ ′-diphenyl-3,4,9,10-perylenedicarboximide (PTCDI, 98%), 1,2,3,4,8,9,10,11,15,16,17,18,22,23,24,25-hexadecafluo ro-29 _H_ ,31 _H_ -phthalocyanine (F16CuPc; dye content, 80%), perylene -3,4,9,10-tetracarboxylic dianhydride (PTCDA, 97%) and 5FIB (99%) were purchased from Sigma-Aldrich. Toluene (99.5%) was purchased from Sinopharm Chemical Reagent. HTP (98%) was purchased from J&K Scientific. Fullerene (C60, 99.95%) was purchased from Nano-C. Methylammonium iodide (MAI) and formamidinium iodide (FAI) were purchased from Greatcell Solar. PTAA was purchased from Xi’an Polymer Light Technology. PCBM was purchased from Luminescence Technology. All reagents and solvents were used directly if not specified. 

##### **Device testing** 

The current density ( _J_ )–voltage ( _V_ ) curves of PSCs were measured in an N2 glovebox with a Keithley 2400 at a voltage scan rate of 0.02 V s<sup>−1</sup> , a delay time of 50 ms and a sweep region from −0.2 V to 1.2 V (that is, forward voltage scanning) under 100 mW cm<sup>−2</sup> AM1.5G illumination provided by an AAA-class solar simulator (Enli Technology). An NREL-certificated silicon reference cell (SRC-2020, Enli Technology) was used for calibration. The mismatch factor was calculated to be 0.96. The device area is defined to be 0.10 cm<sup>2</sup> by metal masks. The external quantum efficiency (EQE) was characterized by a QE-R solar cell quantum efficiency measurement system (Enli Technology), and the light source was a 75 W xenon lamp. The monochromatic light intensity for the EQE was calibrated with a NIST-certified silicon photodiode from 300 nm to 1,100 nm. The EQE spectrum was integrated over AM1.5G photon flux to obtain the photocurrent density. In the probe station chamber, under a vacuum of 10<sup>−3</sup> Pa, the ion activation energy of a lateral solar cell was measured. A Keithley 4200 semiconductor analyser was used for voltage–current characterization. The displacement current of PSCs under reverse bias was measured with a Keithley 4200 semiconductor analyser. 

##### **Solution preparation** 

**FA0.90Cs0.10PbI2.83Br0.17 perovskite.** FAI (2.91 M), PbBr2 (1.36 M) and PbI2 (1.41 M) were dissolved in DMF:DMSO = 9:1 (v/v) mixed solvent, and CsI (1.50 M) was dissolved in DMSO. The ‘mixed’ perovskite precursor solutions of FA0.90Cs0.10PbI2.83Br0.17 were prepared with FAI (0.90 M), PbI2 (0.92 M), PbBr2 (0.085 M) and CsI (0.10 M) from the predissolved solution; this perovskite precursor solution was then aged for 6–8 h at 65 °C before use. 

**MAPbI3 perovskite.** For the preparation of MAPbI3 perovskite solution, the PbI2 solution was prepared by dissolving 1.3 M PbI2 into 1 ml DMF solvent and stirring for 6 h before use. The MAI solution was prepared by dissolving 60 mg MAI in 1 ml IPA. 

##### **Device fabrication** 

The indium tin oxide glass was cleaned with detergent, deionized water, acetone, ethanol and IPA successively. PTAA was dissolved in chlorobenzene to give a 2.0 mg ml<sup>−1</sup> solution and then spin-coated on precleaned indium tin oxide substrate at 6,000 r.p.m. for 30 s and annealed at 65 °C for 10 min in N2. 

For MAPbI3 perovskite film, a two-step method was used. The PbI2 solution was spin-coated on the substrate at 3,000 r.p.m. for 30 s. Next, the MAI solution was spin-coated at 3,000 r.p.m. for 30 s, and then the films were annealed at 80 °C for 1 h. 

For FA0.90Cs0.10PbI2.83Br0.17 perovskite film, a one-step method was used. The perovskite precursor solutions of FA0.90Cs0.10PbI2.83Br0.17 were spin-coated at 6,000 r.p.m. for 30 s with pouring chlorobenzene as an antisolvent. Then the substrates were annealed at 100 °C for 20 min in N2. PCBM with a concentration of 15 mg ml<sup>−1</sup> in CB was spin-coated on perovskites at 3,000 r.p.m. for 30 s and annealed at 80 °C for 10 min. 

For perovskite films coated with soft Lewis acids (for example, C60, PCBM, PFI and 5FIB) or soft Lewis bases (for example, TOPO, PVP, HTP and DIO), the PFI (2.5 mg ml<sup>−1</sup> in IPA), 5FIB (8% in IPA, v/v), TOPO (5 mg ml<sup>−1</sup> in toluene), PVP (1 mg ml<sup>−1</sup> in IPA) or HTP (1% in CB, v/v) layers were fabricated by spin-coating at 4,000 r.p.m. for 30 s. C60, F16CuPc, PTCDI or PTCDA were evaporated in vacuum on the perovskite films at a rate of 0.1 Å s<sup>−1</sup> to give layers 10 nm thick. For the introduction of extrinsic I2 molecules to perovskite films, predissolved iodide solution (10 mM in IPA, 80 °C for 10 h) was deposited onto the perovskite by spin-coating at 4,000 r.p.m. for 30 s, followed by a quick baking at 65 °C for 5 min. 

Finally, for the BCP (7 nm thick) interfacial layer, copper or silver electrodes (80 nm thick) were thermally evaporated sequentially on the films in vacuum at a rate of 0.2 Å s<sup>−1</sup> and 2 Å s<sup>−1</sup> , respectively. 

##### **Device operational and electrical bias stability tests** 

Long-term operational stability measurements of unencapsulated perovskite devices were operated under a solar simulator (Newport 94011A) with a light intensity of 100 mW cm<sup>−2</sup> AM1.5G in N2. The temperature of the devices under illumination was measured to be 40–45 °C. All devices were loaded with a resistor so that they worked at conditions near the MPP during the test. The light and thermal stability of unencapsulated PSCs were measured under a 1 sun condition (white LED lamp; the light intensity was adjusted to maintain fresh PSCs with a _J_ SC of 23 mA cm<sup>−2</sup> ) combined with 85 °C heating in N2. The ultraviolet light ageing test of the perovskite devices was operated under a lamp with 395 nm and 60 mW cm<sup>−2</sup> in N2. The reverse-bias stability test for the PSCs was performed in the N2 glovebox, where a specific reverse bias (for example, −0.5 V to −5.5 V) was provided by the Keithley 2400, and the _J_ – _V_ curve of the device was measured immediately after a given bias was applied to the device for a certain time. 

##### **Film characterization** 

The chemical state and surface composition of the samples were analysed by XPS using an ESCAKAB 250Xi system equipped with a monochromatic SPECS XR-MF X-ray source (Al Kα, _hν_ = 1,486.7 eV; base pressure, 2.0 × 10<sup>−10</sup> mbar). Raman scattering measurements on perovskite films were taken with an inVia Qontor system (Renishaw) using 532 nm excitations with a spot size <10 μm and an 1,800 lines mm<sup>−1</sup> grating. SEM images of the perovskite crystals were obtained by using a scanning electron microscope (TESCAN MIRA3 LMU) equipped with an electron beam accelerated at 10–20 kV and a vacuum transfer accessory at KW-ST lab (www.kewei-scitech.com). The absorption spectra were obtained by using an ultraviolet–visible spectrometer (Thermo Evolution 201) in the spectral range of 300–1,100 nm. 

##### **NMR spectra** 

The<sup>19</sup> F NMR measurements were performed by a Bruker AVANCE-500 instrument. 

##### **Ion migration studies** 

The activation energy ( _E_ A) for ion migration was measured at different temperatures with a Keithley 4200 source meter using a lateral device with the structure gold/perovskite/gold on a glass substrate. The electric field of the lateral device was 0.2 V μm<sup>−1</sup> . The device was put in a Lakeshore Probe Station to obtain the desired temperature. 

##### **Reporting summary** 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

Nature Materials 

**Article** 

https://doi.org/10.1038/s41563-024-01876-2 

### **Data availability** 

The data that support the findings of this study are available from the corresponding authors on reasonable request. Source data are provided with this paper. 

### **Acknowledgements** 

Y. Yuan acknowledges financial support from National Key Research and Development Program of China (2022YFB3803300), financial support from National Natural Science Foundation of China (52273202, 51673218). J. He acknowledges financial support from National Natural Science Foundation of China (62275275). L.Y. acknowledges financial support from National Natural Science Foundation of China (62104261). B.Y. acknowledges financial support from National Natural Science Foundation of China (62004066). H.H. acknowledges financial support from National Natural Science Foundation of China (11874427). Y. Yuan acknowledges the Major Scientific and Technological Project of Changsha (kq2301002), the Key Project of the Natural Science Program of Xinjiang Uygur Autonomous Region (2023D01D03) and the Innovation-Driven Project of Central South University (2020CX006). Y.W. acknowledges financial support from the Natural Science Foundation of Hunan Province (2021JJ40709, 2022JJ20080). 

### **Author contributions** 

Y. Yuan conducted the project, conceived the ideas, designed the experiments and analysed the data. J. Huang supervised the project and analysed the data. J. He supervised the Raman spectral and absorption spectral studies. X.R. fabricated the perovskite films, and 

studied the iodide/polyiodide capture effect of Lewis acids. J.W. and X.R. fabricated the solar cells, and obtained the _J_ – _V_ curves, the EQE and the NMR specta. X.R. and J.W. measured the activation energies of ion migration, the reverse-bias stability and the working stability of solar cells. X.R., Y.L. and Y.W. carried out the ultraviolet–visible absorption spectrum measurements, X.R. and B.Y. carried out the SEM measurements, J.W., H.X. and Y.G. carried out the XPS test and analysis. X.R. and H.H. carried out the Raman spectral tests. Y. Yan carried out the density functional theory calculations. Y. Yuan, J. Huang and J. He wrote the paper; all authors revised the manuscript. 

### **Competing interests** 

The authors declare no competing interests. 

### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41563-024-01876-2. 

**Correspondence and requests for materials** should be addressed to Jun He, Jinsong Huang or Yongbo Yuan. 

**Peer review information** _Nature Materials_ thanks Antonio Abate, Jin-Wook Lee and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at 

www.nature.com/reprints. 

Nature Materials 





