# Narrow Bandgap Metal Halide Perovskites for All-Perovskite Tandem Photovoltaics

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Chemical Reviews |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 179 |
| 作者 | Shuai-Feng Hu, J. Thiesbrummel, Jorge Pascual, M. Stolterfoht, A. Wakamiya, H. Snaith |
| DOI | 10.1021/acs.chemrev.3c00667 |
| 源文件 | 064_Hu_2024_Narrow-Bandgap-Metal-Halide-Perovskites-for-All.pdf |

---
This article is licensed under <u>CC-BY 4.0</u> 

<mark>Review</mark> 









pubs.acs.org/CR 

# Narrow Bandgap Metal Halide Perovskites for All-Perovskite Tandem Photovoltaics 

Shuaifeng Hu,<sup>§</sup> Jarla Thiesbrummel,<sup>§</sup> Jorge Pascual,<sup>§</sup> Martin Stolterfoht, Atsushi Wakamiya,* and Henry J. Snaith* 

Cite This: Chem. Rev. 2024, 124, 4079−4123 

Read Online 

ACCESS Metrics & More 

Article Recommendations 

ABSTRACT: All-perovskite tandem solar cells are attracting considerable interest in photovoltaics research, owing to their potential to surpass the theoretical efficiency limit of single-junction cells, in a cost-effective sustainable manner. Thanks to the bandgap-bowing effect, mixed tin−lead (Sn−Pb) perovskites possess a close to ideal narrow bandgap for constructing tandem cells, matched with wide-bandgap neat lead-based counterparts. The performance of all-perovskite tandems, however, has yet to reach its efficiency potential. One of the main obstacles that need to be overcome is theoftentimeslow quality of the mixed Sn−Pb perovskite films, largely caused by the facile oxidation of Sn(II) to Sn(IV), as well as the difficult-to-control film crystallization dynamics. Additional detrimental imperfections are introduced in the perovskite thin film, particularly at its vulnerable surfaces, including the top and bottom interfaces as well as the grain boundaries. Due to these issues, the resultant device performance is distinctly far lower than their theoretically achievable maximum efficiency. Robust modifications and improvements to the surfaces of mixed Sn−Pb perovskite films are therefore critical for the advancement of the field. This Review describes the origins of imperfections in thin films and covers efforts made so far toward reaching a better understanding of mixed Sn−Pb perovskites, in particular with respect to surface modifications that improved the efficiency and stability of the narrow bandgap solar cells. In addition, we also outline the important issues of integrating the narrow bandgap subcells for achieving reliable and efficient all-perovskite double- and multi-junction tandems. Future work should focus on the characterization and visualization of the specific surface defects, as well as tracking their evolution under different external stimuli, guiding in turn the processing for efficient and stable single-junction and tandem solar cell devices. 

## CONTENTS 

|1. Introduction|4080|
|---|---|
|2. Origins of Efficiency Losses|4082|
|2.1. Crystallization|4082|
|2.2. Oxidation|4084|
|2.3. Mass Loss|4085|
|2.4. Ion Movements and Charge Carrier Trans-<br>port|4087|
|2.5. Section Summary|4087|
|3. Interface Engineering for Solar Cells|4088|
|3.1. Exposed Surface|4088|
|3.1.1. Protection from Oxidation|4089|
|3.1.2. Defect Passivation and Energy Struc-||
|ture|4090|
|3.2. Grain Boundaries|4093|
|3.2.1. Defect Passivation|4093|
|3.2.2. Energy Disorder|4095|
|3.3. Buried Surface|4095|
|3.3.1. Amino Acid Salts|4095|
|3.3.2. Interlayers and PEDOT:PSS Modifica-||
|tions|4096|
|3.3.3. Other HTL Modifications|4096|
|3.4. 2D Capping|4098|
|3.5. Section Summary|4099|



|4. All-Perovskite Tandems|4101|
|---|---|
|4.1. Interconnect<br>|4101|
|4.2. Current Matching<br>|4101|
|4.3. Device Stability<br>f|4102|
|4.4. Trends and Different Device Architectures<br>|4104|
|4.4.1. Deposition Methods and Modulariza-<br>||
|tion<br>|4104|
|4.4.2. Bifacial Devices<br>|4105|
|4.4.3. Flexible Devices<br>|4105|
|4.4.4. Triple-Junction Tandems<br>|4106|
|4.5. Section Summary<br>|4106|
|5. Summary and Future Outlook<br>|4106|
|5.1. Summary<br>|4106|
|5.2. Future Outlook<br>|4107|
|Author Information|4107|
|Corresponding Authors<br>|4107|
|Authors|4107|





Received: September 18, 2023 Revised: March 7, 2024 Accepted: March 15, 2024 Published: March 25, 2024 

© 2024 The Authors. Published by American Chemical Society 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

4079 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 1. Origins of efficiency losses. Crystallization: Schematic illustration of well- and less-ordered crystallographic domains of perovskite films with the crystallinity reflected by XRD results. Oxidation: Sn(II) oxidizes to Sn(IV), leading to Sn(II) vacancies in the lattice and resulting in self-pdoping, with the extent of oxidation reflected by XPS results. Mass loss: The loss of perovskite lattice ions leads to a severe decline in cell performance. Ion movement: A significant concentration of the ions in perovskite films leads to an evident loss of current over time which leads to degradation and initial efficiency losses of the PSCs. 

|Author Contributions|4107|
|---|---|
|Notes|4107|
|Biographies|4107|
|Acknowledgments|4108|
|References|4108|



## 1. INTRODUCTION 

Following the policies for the decarbonization of our energy system, the development of new-generation sustainable green energy is urgently needed.<sup>13,14</sup> Metal halide perovskites are a new type of material, possessing exceptionally high adsorption coefficients, tunable bandgaps, and solution- and dryprocessable fabrication protocols.<sup>16−19</sup> Thus, they have enabled us to advance photovoltaic solar energy conversion efficiency and promise to deliver a low-cost photovoltaic (PV) technology that can be sustainable at the multiterawatt scale.<sup>21−24</sup> The most efficient, and arguably closest to-market, type of perovskite-containing photovoltaics are two-terminal monolithic tandems, with perovskite-on-Si leading the efficiency and scale-up race, and perovskite−perovskite tandems in close pursuit.<sup>22,27</sup> In these devices, the efficient utilization of solar energy is achieved through collectively harvesting a broad portion of the solar spectrum while 

minimizing thermalization losses, with the two absorbers having different bandgaps.<sup>34</sup> The optimal gap for the front perovskite subcell is ∼1.65 to 1.70 and ∼1.80 to 1.85 eV for perovskite-on-Si and perovskite−perovskite tandems, respectively, while the counterpart for the narrow-bandgap (NBG) rear perovskite subcell is generally ∼1.25 eV, which is currently the narrowest achievable bandgap for efficient metal halide perovskite photovoltaics.<sup>27,34,37</sup> In perovskite−perovskite (perovskite-on-Si) tandems, the photons with higher energy are absorbed by the wide-bandgap (WBG) front perovskite absorber, while those with lower energy are harvested by the rear NBG perovskite (Si) absorber. Then, a charge recombination layer (CRL) is employed to connect those two subcell units. In this way, the devices present a theoretical maximum achievable efficiency under standard AM1.5 100 mW cm<sup>−2</sup> irradiance of about 45%,<sup>38,39</sup> which pronouncedly surpasses radiative limits for the single-junction solar cells, at approximately 33%, based on the principle of detailed balance.<sup>45</sup> For single-junction perovskite solar cells (PSCs), within only about one decade since their first discovery,<sup>46−49</sup> efficiencies surpassed 25%,<sup>52,53</sup> for the devices constructed with both n-i-p (regular)<sup>54−59</sup> and now p-i-n (inverted)<sup>60−63</sup> stackings, putting them on par with state-of-the-art crystalline silicon solar cells, at 26.8%.<sup>64,65</sup> For monolithic perovskite-on- 

4080 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> <u><mark>pubs.acs.org/CR</mark></u> <mark>Review</mark> 



Figure 2. Crystallization. (a) (i) Crystal structure of PbI2·2DMSO and SnI2·3DMSO complexes generated with the CIF file from refs 4 and ref 6, respectively. (ii) La Mer diagram for monodispersed particle formation (homogeneous nucleation). CS is the solubility, Cmin* is the minimum concentration for nucleation, i.e., the minimum supersaturation level for homogeneous nucleation, and Cmax* is the maximum concentration for nucleation. Regions I, II, and III represent prenucleation, nucleation, and growth stages, respectively. (iii) Processing of the spin-coated perovskite films with the main role of each process noted at the bottom. (b) (i) Isotopes of elements from the perovskite precursor materials active in NMR and<sup>207</sup> Pb NMR spectra of the perovskite precursor solution with different concentrations. Reproduced with permission from ref 26. Copyright 2021 Royal Society of Chemistry under a Creative Commons Attribution 3.0 Unported License. (ii) Optimized geometries for selected [PbImXn]<sup>2−m</sup> iodoplumbate complexes in DMF solvent with the UV−vis absorption spectra giving the characteristic absorption of the iodoplumbates. Reproduced with permission from ref 28. Copyright 2019 American Chemical Society. (c) (i) Basic scheme of a small angle scattering instrument. Reproduced with permission from ref 26. Copyright 2021 Royal Society of Chemistry under a Creative Commons Attribution 3.0 Unported License. (ii) Representative SAXS pattern of the perovskite solution. (iii) DLS results of a mixed Sn−Pb perovskite precursor solution. Reproduced with permission from ref 9. Copyright 2022 Royal Society of Chemistry. (d) (i) Schematic illustration of in situ GIWAXS and PL measurements during the spin coating stage of perovskite film formation. Reproduced with permission from ref 50. Copyright 2022 American Chemical Society. (ii) Illustration of the in situ GIWAXS results. (iii) Illustration of the in situ PL results, taken from ref 67. Copyright 2021 American Association for the Advancement of Science under a Creative Commons Attribution License 4.0 (CC BY). 

Si and perovskite−perovskite tandems, the current record efficiencies reported have surpassed 33%<sup>52</sup> and 29%,<sup>71</sup> respectively, surpassing the Shockley−Queisser (S-Q) theoretical efficiency limit of 33.7% for single-junction solar cells,<sup>45</sup> with the leading efficiency of 33.9% achieved by perovskite-on-Si tandem PV technology.<sup>76</sup> 

Considering the advantage of further lowering production costs, reducing embodied energy and energy payback, allperovskite tandems including double- and multi-junction cells have been considered as a central target to be realized. Currently, one of the core limitations is on the NBG cell, which generally employs mixed Sn−Pb perovskites containingmost of the timea half Sn(II) and half Pb(II) composition at the B-site of the 3D perovskite lattice. Unfortunately, the introduction of tin into the perovskite 

lattice comes with several emerging drawbacks, such as the facile oxidation of Sn(II),<sup>78,79</sup> especially at the film surface,<sup>12</sup> and the substandard quality of the films resulting from the fast and difficult to control crystallization dynamics.<sup>85,86</sup> The consequent structural imperfections, i.e., vacancies, interstitial and substitutional sites, crystallographic phase impurities, reactive remnants, and lattice stacking faults, are dominantly located at the film surfaces,<sup>87−89</sup> including interfaces and grain boundaries. Therefore, for mixed Sn−Pb PSCs, modifying the surfaces of the perovskite films is pivotal to improving their efficiency and durability. 

In this Review, we first summarize different sources of efficiency losses for the mixed Sn−Pb PSCs, such as Sn(II) oxidation, unregulated crystallization, operational stress, and ion migration. We highlight particularly the impact of these 

4081 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

defects at perovskite surfaces and the resulting severe nonradiative charge carrier recombination. The detailed surface states of perovskite films are discussed in the context of their structural, electronic, and defect characteristics. We discuss the strategies that have been employed at the different surfaces (top and bottom interfaces, grain boundaries) to mitigate these detrimental effects in single-junction and allperovskite tandem devices, with specific highlights of the twodimensional (2D) capping strategies. We then outline the important aspects of routinely and reproducibly integrating the NBG absorber into all-perovskite double- and multi-junction tandem devices. In the end, we discuss the future potential of surface characterization and modification for the mixed Sn−Pb perovskites from the view of intrinsic material properties and photovoltaic applications. 

## 2. ORIGINS OF EFFICIENCY LOSSES 

To gain a global picture of the PSCs, understanding the origin of their efficiency losses is of particular importance. These losses are largely influenced by imperfections in the thin film generated during its fabrication, as well as due to their intrinsic instability. In this section, we will be discussing the importance of the crystallization process for the production of high-quality thin films, as well as the impact of oxidation, mass loss, and ion movement on the generation of defects affecting the device performance (Figure 1). 

### 2.1. Crystallization 

In the fabrication of solution-processed perovskite thin films, the final material will be polycrystalline with a large portion of surfaces (e.g., grain boundaries) and the consequent surface and structural defects, which can introduce trap states.<sup>91,92</sup> Furthermore, defects will be present throughout the crystalline domains, and the density and prevalence of specific defects will be influenced by nucleation and growth conditions and environment. Hence, the crystallization process profoundly determines the final quality of the material, and thereby the device’s efficiency and stability. Therefore, careful control of the crystallization process is key to achieving the optimum optoelectronic properties of the perovskite films. In solutionbased film processing (Figure 2a), the use of the solvent dimethyl sulfoxide (DMSO) was a critical milestone in decelerating the crystallization of Pb and Sn perovskites through the formation of intermediate phases involving the metal halides and the sulfoxide.<sup>94−96</sup> For the case of Sn perovskites, however, owing to their inherent propensity for faster nucleation, the effect of DMSO is insufficient to effectively retard the crystallization process.<sup>98,99</sup> Indeed, Snbased precursors strongly accelerate the crystallization process in mixed Sn−Pb perovskite films.<sup>102</sup> Due to this rapid crystallization, mixed Sn−Pb perovskite thin films typically suffer from poor morphology with less-oriented grains, which in turn dramatically affects their optoelectronic properties. In addition, the different crystallization dynamics between Pb and Sn perovskites create competition between these two materials, inevitably leading to inhomogeneities in the distribution of the two metals throughout the film.<sup>103</sup> This nonstoichiometric nature of the material is a source of trap states from tin interstitials in tin-rich spots and tin vacancies in tin-poor spots<sup>104</sup> and leads to energy disorder inside the perovskite film. 

Controlling the crystallization of the films is relatively less studied for the mixed Sn−Pb perovskite film,<sup>105,106</sup> and the detailed mechanism is thus still largely being covered. Several 

attempts have been made using accustomed processing techniques, such as vacuum-assisted growth,<sup>107</sup> gas-quenching,<sup>108</sup> or two-step processing,<sup>109</sup> to manipulate the crystallization kinetics. Other, more established protocols propose the use of 2D materials for controlling the growth and orientation of the grains,<sup>110−112</sup> with close reliance on the perovskite compositions in some cases,<sup>113</sup> and the addition of SnF2 to deliver more homogeneous nucleation of neat Sn-based perovskite films through the action of the F<sup>−</sup> anion.<sup>114</sup> In this aspect, reports on the use of chloride-containing additives suggest that this halide would have a similar role to the F<sup>−</sup> anion.<sup>115</sup> Additives containing pseudohalides,<sup>116</sup> such as ammonium thiocyanate (NH4SCN)<sup>117,118</sup> or lead(II) thiocyanate (Pb(SCN)2),<sup>119,120</sup> have been applied to adjust the crystallization kinetics of the perovskite films, especially in combination with low-dimensional species,<sup>121</sup> and/or the binding ligands.<sup>122</sup> Despite the benefits of these strategies to control the crystallization of mixed Sn−Pb perovskites, the community still struggles to fabricate thin films with sufficient quality, considering the lower defect tolerance of these mixed perovskites compared to their conventional neat Pb counterparts. Thus, further efforts should be directed toward understanding the crystallization process of mixed Sn−Pb perovskites, in order to enable films with reduced grain boundaries, enhanced crystallinity with fewer intragrain defects, and a homogeneous distribution of tin- and leadbased units. 

Perovskite inks are not a fully dissolved mixture of ions but are rather a colloidal dispersion by nature and contain complexes.<sup>123</sup> This makes their crystallization a particularly complicated process, where the combination of classical and nonclassical nucleation theories introduces a number of possible nucleation and crystal growth pathways that cannot be straightforwardly ascribed to each specific perovskite case.<sup>124−126</sup> Therefore, it is particularly relevant to gain a further understanding of the precursor colloidal dispersions and precursor chemistry during the early stages of perovskite crystallization. The nature of these colloids is going to determine the nucleation and crystal growth pathways of the perovskite material, and therefore it is critical to investigate their physicochemical characteristics and how they can be manipulated to control the crystallization process (Figure 2b, c). For this purpose, a series of traditional and novel techniques have been proposed in the literature. Conventional methods such as dynamic light scattering (DLS)<sup>127</sup> and UV−vis spectroscopy<sup>128</sup> can reveal important information on colloidal properties. However, these determinations are carried out indirectly, which could mislead researchers and result in inaccurate interpretations.<sup>129</sup> Instead, small-angle X-ray (SAXS) and neutron scattering (SANS) are nondestructive techniques that provide critical structural properties of the perovskite dispersions, such as the size, shape, and structure of the colloids, while avoiding the limitations of DLS and UV−vis spectroscopy.<sup>26,114,129−131</sup> In addition, small-angle scattering can be combined with other characterization methods to reveal further insights into the arrangement and interactions of metal halide species and additives in the precrystallization stages. For instance, 207Pb-NMR (nuclear magnetic resonance) can describe the chemical environment of the iodidoplumbates in solution to support the findings by SAXS.<sup>26</sup> Although the use of NMR for studying perovskite colloidal dispersions is very scarce, we anticipate a high potential and versatility for such a simple, fast, and nondestructive technique. Other techniques 

4082 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

also have the ability to uncover solution properties. For instance, cryogenic transmission electron microscopy (cryoTEM) has found colloids in neat Pb precursor solutions to be crystalline, nonperovskite materials rather than amorphous materials.<sup>132</sup> Identifying how colloidal properties affect precursor material evolution into perovskite material during the crystallization process would allow for control over the optoelectronic properties of the resulting thin films, describing the origin of defects and suppressing their formation from the solution stage. 

The different polyiodide plumbates (PbXm2−m) and stannates (SnXm2−m) formed in the solution offer relevant information on the nature of these perovskite precursor solutions. The ligands present in the mixtures, i.e., solvent molecules, halides, and potential additives, compete to coordinate the metallic centers. Thus, their relative binding strength will define the valency and structure of these MXm2−m species, which will consequently show as isolated complexes or even form colloids.<sup>28,133</sup> Characterization of these solutions by absorption spectroscopy has revealed the ability of stronger binding solvents (e.g., DMSO > DMF) and halides (Cl<sup>−</sup> > Br<sup>−</sup> > I<sup>−</sup> ) to decrease the number of high valency polyhalide metalates (i.e., lower m), providing the guidelines to control the properties of the precursor solutions. New solvent and halide mixtures have been proposed for successful crystallization tuning of neat Sn<sup>79,134−137</sup> or even mixed Sn−Pb perovskites.<sup>138</sup> Therefore, we would like to emphasize the great potential of structural modifications and solvent engineering approaches to address the current flaws in Sn-containing perovskite crystallization, avoiding the more common overdependence on additives. Unfortunately, most of the reports on absorption spectroscopy focus on neat Pb solutions, while examples for Sn-containing solutions remain scarce.<sup>135,138−140</sup> In fact, the relevance of polyhalide metalate complexes in mixed Sn−Pb perovskite precursor solutions and how to manipulate them is often disregarded and, as a consequence, key aspects of these solutions remain unexplored. Thus, we predict exhaustive absorption measurement studies on Sncontaining perovskite solutions to be critical for the advancement of the processing of these materials. 

One main challenge ascribed to Sn-containing perovskites processing is their faster crystallization kinetics with respect to Pb perovskites, as mentioned above.<sup>6</sup> Particularly, Sn perovskites suffer from heterogeneous nucleation and rapid crystal growth. Most of the relevant studies reported in the field highlight the importance of increasing the stability and homogeneity of the generated nuclei, as well as adjusting their formation rate to crystal growth.<sup>136,138,141−143</sup> Numerous strategies have, in fact, successfully controlled crystallization to some extent and improved thin film quality, but the fundamental reasons determining this nature inherent to Sn perovskites remain largely underexplored. The stronger Lewis acidity and different electronic structure of Sn(II) in comparison to Pb(II) are critically influencing the energetics and chemical characteristics (e.g., coordination, size, geometry, etc.) of the species that will be formed in solution and into a solid thin film.<sup>144</sup> Studying them would not only be crucial for the development of neat Sn-based perovskites but would also offer highly relevant information about chemical properties, degradation processes, and thin film processing in mixed Sn−Pb perovskites. As we observed, the limitations encountered in the processing of high-quality mixed Sn−Pb perovskite thin films may stem from the fact that both their precursor 

solution chemistry and film crystallization dynamics are potentially dominated by Sn-based species. Here, we can selectively regulate the chemical environment of specific metalbased precursors in solution to control the different crystallization kinetics between the Sn and Pb perovskites. In this regard, additives like sulfate anion, with the ability to selectively coordinate Sn-based precursors, can slow the kinetics of the perovskite formation, adjusting it to become comparable to the Pb-based precursors.<sup>145</sup> A balanced crystallization of both species leads to a more homogeneous distribution of the Sn and Pb species and consequently a higher uniformity in the energy distribution in the perovskite film. Based on the solubility difference of the Sn- and Pb-based perovskite species, in contrast, the vertical compositional gradient structure of the mixed Sn−Pb films has also been intentionally introduced by controlling the temperature of the antisolvent applied during the spin coating process.<sup>146</sup> This gradient structure is supposed to provide a better energetic alignment between the perovskite and the charge transport layers. However, the thermal stability, e.g., under a temperature of 85 °C, of this structure may be an issue considering the ion movement of the metal cations inside the 3D mixed Sn−Pb perovskite films. We accordingly prospect that a rational design of this gradient structure could be realized by introducing 2D spacer(s) into the system to improve the thermal durability of the perovskite material, to some extent, while a reshape of the band structure, e.g., bandgap, of the material could be expected.<sup>147</sup> Nevertheless, a deeper fundamental understanding is required in order to increase the number of available strategies to tackle/utilize the imbalance between Sn and Pb perovskite crystallization. 

Moreover, up to now, there are few reports on intermediate crystallization for neat Sn or mixed Sn−Pb perovskites, and opposite to PbI2 in neat Pb materials, no much solvated crystal structures containing organic species have been reported yet, except for some cases of bidentate ligands like maltol.<sup>12</sup> Some interesting species reported that may exist as intermediates are DMSO- and DMF-based SnX2 solvates: SnI2·DMSO,<sup>141</sup> SnI2· 2DMSO,<sup>148</sup> SnI2·3DMSO,<sup>6</sup> SnI2·DMF, 3(SnI2)·2DMF, SnBr2· DMF, SnBr2·2DMSO, SnCl2·DMF, and 2(SnF2)·2DMSO.<sup>148</sup> The interactions established between the Sn 5s antibonding orbital and the donor orbitals,<sup>149,150</sup> as well as the shorter Sn−O bond compared to Pb−O (for MX2-solvent) owing to the stronger binding by DMSO to Sn, lead to geometry differences between PbX2 and SnX2 solvates.<sup>151−153</sup> The actual implications of this variation in the characteristics of the intermediates and the difficulty to identify them are yet to be defined, however. It is worth noting that intermediate phases have been found for mixed Sn−Pb perovskites, though they could not be unambiguously assigned yet.<sup>138,154,155</sup> From here, some advanced techniques (Figure 2d), such as in situ grazing incidence wide-angle X-ray scattering (GIWAXS),<sup>156</sup> in situ photoluminescence (PL),<sup>157</sup> and adsorption spectroscopy,<sup>158</sup> as well as liquid-phase TEM<sup>159</sup> with the combination of matured single-crystalline XRD, may be key to shed light on the intermediate crystallization pathway of Sn-containing perovskites and bridge the gap between liquid precursors, crystallization, and final solid state of the films.<sup>110</sup> However, one main obstacle to the applicability of these techniques to mixed Sn−Pb perovskites, particularly in the case of in situ GIWAXS, is the instability of Sn-containing materials to atmospheric agents. In this sense, adapting these techniques to the inert sample environments required by oxidizable species 

4083 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

would open the door to new types of characterization and insights into these materials. 

Nevertheless, current solution-based processing protocols, inherited from the processing of neat Pb perovskites, remain challenging to adapt to the Sn-containing materials.<sup>160,161</sup> The explorations on epitaxial growth of perovskites may be proving this point.<sup>81,162</sup> In these works, the perovskites with different compositions, including mixed Sn−Pb perovskites, lead to excellent quality thin films with a reduction of structural defects. The resulting films experienced a significant improvement in carrier mobility and recombination dynamics for their application in photovoltaic devices. Although the techniques presented in these works may not be readily transferable to general use, they highlight the actual potential of these materials and the importance of understanding and controlling the perovskite crystallization process. We also anticipate the strong potential of additive engineering strategies involving molecules with specific functional groups, for modulating mixed Sn−Pb perovskite colloids in the solution stage and positively influencing the crystallization process.<sup>9</sup> 

### 2.2. Oxidation 

Stability to ambient factors is critical for the industrial application of PSCs. While water, for instance, is a widely reported degradation source for metal halide perovskites,<sup>163−165</sup> the instability of mixed Sn−Pb halide perovskite materials and devices are governed by the action of oxidant species on Sn(II)-based materials,<sup>166−169</sup> mainly by atmospheric oxygen, and it can be accelerated by moisture.<sup>170</sup> This is due to the thermodynamically favorable oxidation process of Sn(II), where the acquirement of two electrons by Sn(IV) has a positive standard reduction potential as low as 0.15 V. The origin of this critical difference between Sn and Pb elements stems from the lanthanide contraction affecting Pb, which is in the same group as Sn but in a higher period number.<sup>171</sup> The full 4f subshell electrons present in Pb have a low shielding ability on outer subshells, not being able to compensate for the increase in the atomic number by 14. Thus, the more charged nucleus exerts a stronger attraction on the outer 6s orbital, stabilizing +2-oxidation state. This is not the case for Sn, which lacks the 4f subshell and can easily lose both 5s and 5p orbital electrons. In addition, this also causes the valence band maximum (VBM) of Sn perovskites to be shallower than for Pb perovskites<sup>172</sup> and destabilizes the Sn−I antibond, contributing to the facile oxidation of Sn(II) into Sn(IV) and the formation of Sn(II) vacancies. According to the Frost−Ebsworth diagrams,<sup>173</sup> we can observe that the oxidation of Sn(II) species is much more thermodynamically favorable than that of Pb(II) species. Moreover, the application of light or voltage can easily generate I2 from I<sup>−</sup> , which would have the ability to oxidize Sn(II). Severely harmful for neat Sn perovskites, this degradation is suppressed when blended with Pb in mixed Sn−Pb perovskite materials and devices, raising the oxidation reaction activation energy and slowing down the kinetics of the process.<sup>104,174</sup> The oxidation mechanism necessarily involves several adjacent Sn(II) centers.<sup>174</sup> Therefore, the intercalation of Pb centers in mixed Sn−Pb perovskites raises significant obstacles to the oxidation process. Further studies of the degradation pathways found that air exposure results predominantly in the formation of deep trap states, rather than electronic doping generally observed in neat Sn perovskites.<sup>104</sup> This finding is in opposition to previously reported theoretical calculations, suggesting bandgaps free of 

deep trap states for mixed Sn−Pb perovskites.<sup>175</sup> Previous findings by X-ray photoelectron spectroscopy (XPS) propose the formation of SnO2 and the consequent generation of defects, i.e., tin and iodide vacancies and tin interstitials, as the origin of these deep trap states.<sup>176</sup> As a consequence, the monomolecular recombination of free carriers is accelerated, resulting in the decline of the optoelectronic properties of perovskite films. Thus, the presence of SnO2 will negetively impact the device performance, even at low concentrations, due to its high number of defect states.<sup>177</sup> Concerning this, current analysis techniques of the Sn(IV) content (i.e., mainly XPS) do not have the sensitivity to detect the very low maximum concentrations of oxidized species that are tolerated for optimum cell performance (∼10<sup>−8</sup> M),<sup>79</sup> and thus seeking suitable analysis methods for the appropriate content range would aid the community to reach precise control on the materials. 

A simple and direct method to extend the stability of Sncontaining perovskite devices to extrinsic elements is to employ encapsulation technologies. These strategies significantly alleviate the instability of these materials by preventing oxygen from entering the device. While current industry standard encapsulation methods are about sufficient for Pbbased devices,<sup>188</sup> their suitability for Sn-containing devices still needs to be further studied. These materials will certainly require more strict conditions since even small quantities of oxygen absorbed on the perovskite surfaces can already cause the formation of detrimental species.<sup>176</sup> Therefore, encapsulation may provide just a partial solution to the oxidation issue. To address this, the community should develop device fabrication protocols that inherently increase the stability of the material to oxidation, in parallel with the combined implementation of adapted encapsulation strategies. Here, the simultaneous optimization of the different surfaces in the Sncontaining materials can make a critical difference in tackling their unstable nature. As mentioned before, perovskite surfaces in the film (grain boundaries, interfaces) are a major site of degradation and efficiency loss. Current strategies propose the use of various additives,<sup>189</sup> such as SnF2,<sup>190,191</sup> Sn(0),<sup>184,186</sup> and Pb(0)<sup>192</sup> species, some reductants/antioxidants,<sup>86,146,193−195</sup> V<sup>3+</sup> /V<sup>2+</sup> ionic pair as a redox shuttle,<sup>196</sup> and the electron-withdrawing ligand that improves the redox potential of the tin adduct.<sup>197</sup> They effectively reduce the content of Sn(IV) in the precursor solution and thus suppress the p-doping in the films caused by the forming of the Sn(II) vacancies. For example, the SnF2 addition in neat Sn and mixed Sn−Pb perovskite films makes a significant reduction in the background hole density due to the reduced Sn(II) vacancies.<sup>198</sup> Consequently, the carrier lifetimes are elongated, the energetic disorder is decreased, and Burstein−Moss shifts<sup>199,200</sup> are reduced for the films. In addition, fluoride anions in SnF2 selectively capture Sn(IV) species and eliminate them from the bulk,<sup>114</sup> which was later confirmed by DFT calculations, suggesting the sequestration of Sn(IV) through the thermodynamically favorable formation of mixed valence Sn3F8.<sup>187</sup> Doping with heterovalent metallic cations, like Ag<sup>+</sup> and Ga<sup>3+</sup> ,<sup>155,201</sup> has also opened another interesting way to increase the antioxidative character of the mixed Sn−Pb perovskite material. Unfortunately, the currently established additive-based strategies fall short of fully eliminating these trap states, highlighting the need for advanced strategies that more strongly inhibit the oxidation-related defects simulta- 

4084 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

### <u>Chemical Reviews</u> 

neously in grain boundaries and interfaces of mixed Sn−Pb perovskite films. 

So far, our discussion has touched upon the atmospheric oxygen-driven decomposition, which is the main contributor to the oxidation of Sn(II) species.<sup>176</sup> However, iodine species (I2 and triiodide ion, I3−) are other oxidants and an important source of defects to be considered because they have been reported to be formed as a decomposition product of iodidecontaining perovskite materials and under the presence of illumination and bias (applied voltage).<sup>176</sup> It also takes part in the cyclic degradation of tin halide perovskites, due to the formation and regeneration of SnI4.<sup>178</sup> In addition, the conventional solvent to process these materials, DMSO, can also be reduced in the presence of iodide ions, generating in turn iodine-based oxidant species that can degrade Sn(II) perovskite material.<sup>78,79,183</sup> The extent of this oxidation and its actual impact on the device performance is still to be determined and might be particularly critical for neat tin perovskites due to their higher ratio of tin content. Promising works in neat Sn PSCs point out the potential benefits of DMSO-free fabrication processes.<sup>134,136,168,202</sup> A recent study proved its efficacy for mixed Sn−Pb perovskites, where the utilization of a DMPU (N,N′-dimethylpropyleneurea)-based solvent system largely reduced the formation of Sn(IV).<sup>138</sup> Finally, the charge transport materials are an additional source of oxidation of the perovskite component. Metal oxide semiconductors, such as NiOX and TiO2, have active species that can induce Sn(II) oxidation at the perovskite interface.<sup>180,203−205</sup> In Figure 3, we summarize every reaction reported so far related to the oxidation process of Sn materials. We listed the different sources of oxidant species O2 and I2 and coupled them with the cyclic oxidation mechanism of ASnX3 materials.<sup>178</sup> Moreover, we have also included the main antioxidant strategies and how they influence the degradation process by removing oxidized species from the cycle. 

Oxidation of the mixed Sn−Pb perovskite material is a complex process that involves a considerable number of sources, such as oxygen from the air, metal oxide contacts, or I2 from the perovskite itself or the influence of DMSO solvent. In addition, each of them would require a specific strategy to be dealt with. The atmospheric oxygen may pose the biggest challenge, due to the difficulty of fully avoiding its insertion in the material. While the combination of current additive-based antioxidants with proper encapsulation techniques could lead to encouraging results, there exists the risk they may dissatisfy the high standards required to keep Sn(II) stable.<sup>168</sup> Therefore, future efforts should be aimed at increasing the intrinsic stability of Sn-containing materials through structural and process modifications. Moreover, the strongest impact of oxidation happens at the perovskite interfaces, due to their higher exposure and their more detrimental effect on device performance. Thus, the processes to be designed by the community should be directed not only to inhibiting the oxidation process but also particularly to safeguarding these sites in solar cell devices. 

### 2.3. Mass Loss 

To analyze the viability of PSCs for practical use, the evaluation of perovskite degradation upon external stress, induced by factors such as temperature, light, humidity, electrical bias, and radiation, is essential. For neat Pb PSCs, the material loss has been widely investigated and is now rather well understood, as well as for neat Sn PSCs, where material 



Figure 3. Oxidation. (a) Frost−Ebsworth diagram for tin demonstrating the favorable comproportionation reaction between Sn(IV) and Sn(0) to form Sn(II). Reproduced with permission from ref 144. Copyright 2023 American Chemical Society under CC-BY-NC-ND 4.0. (b) Reactions reported so far involved in the oxidation process of Sn materials, based on the cyclic degradation mechanism previously proposed.<sup>178</sup> Molecules in orange represent oxidant species, while arrows in gray and green describe, respectively, oxidation processes and oxidant-removal processes through additives. (i) Oxidation of 3D Sn-based perovskite material ASnI3 by molecular oxygen, generating oxidized Sn-materials SnI4 or A2SnI6.<sup>174,178,179</sup> (ii) Oxidation of Snbased perovskite material by metal oxides as HTM, generating SnO2 at the interface.<sup>180</sup> (iii) Oxidation of iodide by undercoordinated iodide ions (e.g., interstitial iodides, Ii+) or molecular oxygen to the oxidant species iodine (I2).<sup>179,181</sup> (iv) Triiodide formation reaction from iodine.<sup>181</sup> (v) Cyclic oxidation mechanism of Sn-based perovskite material through the regeneration of SnI4 and I2 species under ambient conditions.<sup>178</sup> (vi) Oxidation of iodide ions to iodine by DMSO.<sup>182,183</sup> (vii) Comproportionation reaction of SnI4 and Sn<sup>0</sup> species to SnI2.<sup>184−186</sup> (viii) Selective complexation of Sn(IV) material by fluoride anions in SnF2, resulting in Sn3F8 mixed valence phase and regeneration of SnI2.<sup>137,186,187</sup> (ix) Formation of SnI2 by the redox reaction between Sn<sup>0</sup> and I2.<sup>141</sup> (x) Reaction between I2 oxidant and SnF2 reductant to form SnI2 and Sn3F8 mixed valence phase.<sup>187</sup> 

loss is largely linked to oxidation.<sup>206</sup> However, mass loss in mixed Sn−Pb perovskites is more complex due to the more convoluted material chemistry. Still, several attempts have been made to investigate this critical aspect. 

Mass loss in mixed Sn−Pb PSCs is tightly linked to redox chemistry,<sup>174</sup> showing the dependence of mass loss mechanisms on the Sn/Pb ratio, with the activation energy in Sn-rich perovskites (>50% Sn) being lower than that for perovskites where Sn sites are surrounded by a larger number of Pb sites. Moreover, surfaces are key in this degradation mechanism and, in this sense, the removal or modification of the conventional hole transport contact, poly(3,4-ethylenedioxythiophene) polystyrenesulfonate (PEDOT:PSS), can lead to more stable 

4085 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

cells, which are less prone to oxidation and therefore suffer less mass loss.<sup>207</sup> 

To identify structural changes within mixed Sn−Pb perovskite devices under operation, synchrotron-based operando XRD can probe changes in the crystal structure of the perovskite absorber.<sup>176</sup> Interestingly, the combined stressors of heat, light, and electrical bias induced no change in the bulk crystal structure. The film surface, on the other hand, degraded increasingly fast due to activated corrosion processes, confirming that detrimental chemical reactions dominate degradation in mixed Sn−Pb PSCs. Organic cations are lost at the surface through deprotonation, a process that is accelerated at elevated temperatures (Figure 4). XPS analysis 



Figure 4. Mass loss. Schematic of proposed chemical degradation mechanism in perovskite surface regions, including interfacial regions between the perovskite active layer and charge collective layers as well as grain boundaries. Reproduced with permission from ref 179. Copyright 2020 American Chemical Society. 

showed the existence of I3− species, suggesting that photochemical reactions of I<sup>−</sup> with photoactivated/generated holes 

are also likely to occur, which eventually culminates in the loss of I2 at the surface. Finally, regarding the loss of the metal cations from the lattice, this commonly originates from the oxidation of Sn(II) to SnO2, while Pb(II) can reduce to Pb(0) under ambient-catalyzed conditions. While the combined presence of oxygen and humidity accelerates the oxidation process of Sn(II),<sup>170</sup> the intentional hydrolysis of the superficial Sn(IV) with H2O can, however, form a thin SnOX layer, which decreases Sn(IV) defects and forms a passivated and n-type surface that contacts desirably with the electron transport layer (ETL).<sup>208</sup> 

Temperature is a critical parameter affecting the degradation mechanisms. Most degradation processes, be them triggered by light, charge density, electric field, or oxygen, are chemical reactions that are thermally activated, with increasing temperature accelerating the degradation rates. For instance, the oxidation process of Sn(II) by DMSO is too slow to be detected at room temperature but becomes very evident under elevated temperatures, e.g., over 100 °C.<sup>183</sup> Meanwhile, the traditional A-site cation methylammonium (MA<sup>+</sup> ) has low thermal stability<sup>209</sup> and is known to leave the film as various degradation products, including methylamine, ammonia, and hydroiodic acid.<sup>210</sup> These gaseous materials will leave the perovskite film and react with the other materials in the device structure, such as the metal electrode. Thus, removing MA<sup>+</sup> from the perovskite material, neat Pb perovskite included, increases the thermal and long-term operational stability of the devices.<sup>207,209,211</sup> 

Besides stressors such as temperature, electrical bias, and light, the impact of proton irradiation on mixed Sn−Pb PSCs, an aspect that is specifically important for their prospective implementation in space, has also been investigated. Interestingly, mixed Sn−Pb PSCs are remarkably radiation tolerant<sup>212,213</sup> and far outperform other thin film technologies in this respect, making them ideal candidates for space applications. 



Figure 5. Ion movement. Illustration of the ion migration pathways enabled by (a) Schottky defects (b) Frenkel defects, (c) open space and (d−f) wrong bonds at grain boundaries. Lattice distortions due to (d) accumulated charges, (e) dissolved impurities, (f) nonuniform strain caused by the piezoelectric effect, and (g) softened lattice caused by the light illumination induced bond weakening. Reproduced with permission from ref 7. Copyright 2016 American Chemical Society. 

4086 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

Overall, the chemical degradation in mixed Sn−Pb PSCs is surface-dominated, and the oxidation of Sn(II) in the perovskite is a process that occurs in combination with the oxidation of I<sup>−</sup> and the reduction of metals. The initiation of these redox reactions depends on local electrochemical potentials, which are in turn defined by a complex combination of defects, the presence and concentration of mobile species, and additional decomposition products. Thus, it is essential to develop strategies to increase the quality of the surface (decreasing the superficial defects) and protect it from further degradation, such as surface engineering with post-treatments or the insertion of passivating thin layers. Furthermore, parallel degradation mechanisms involving the organic A-site component will also influence the mass loss and defect generation in mixed Sn−Pb PSCs. With MA<sup>+</sup> being the main component affected by thermal decomposition, the development of inorganic and MA-free mixed Sn−Pb PSCs is necessary to achieve long-term stable devices that could meet the criteria for practical applications. 

### 2.4. Ion Movements and Charge Carrier Transport 

The presence of mobile ions in metal halide perovskites of different compositions has been well established and linked to hysteresis and device (in)stability.<sup>214−220</sup> Although there is still debate about exactly which ions are moving and how high the corresponding mobile ion densities are,<sup>221−223</sup> the important role that mobile ions play in PSCs is generally well recognized (Figure 5). In addition to causing phase instabilities and chemical decomposition of the perovskite, mobile ions can influence the performance of PSCs by altering their electronic properties. For example, mobile ions can cause light-soaking effects, leading to a change in open-circuit voltage (VOC) over time upon exposure to light.<sup>224</sup> Furthermore, they can drastically impact the device short-circuit current density (JSC) and fill factor (FF). 

Recently, a combination of transient charge extraction and photoluminescence measurements demonstrated that both neat Pb and mixed Sn−Pb PSCs suffer from current losses during the first seconds of operation, caused by the movement of mobile ions in the devices and subsequent field screening.<sup>220,225</sup> Thiesbrummel and Le Corre et al. showed that these current losses were a consequence of band flattening caused by the redistribution of mobile ions and the consequent screening of the internal electric field. However, ion-induced shifts to the energetics at the charge extraction contacts were not considered, which may also play a role in the reduction in charge extraction efficiency. In mixed Sn−Pb PSCs, besides the mobile ions which are also present in neat Pb PSCs, there might be additional ions involved due to the oxidation of perovskite. Mobile ions such as FA<sup>+</sup> or I<sup>−</sup> are likely formed upon oxidation of Sn-containing perovskites, which would mean that oxidation of Sn(II) to Sn(IV) in the perovskite could increase mobile ion densities, leading to increased current losses.<sup>174</sup> Furthermore, the reduced absorption coefficient of mixed Sn−Pb perovskites compared to neat Pb ones,<sup>225</sup> as a consequence of the lower exciton binding energy in the Sn-containing perovskites, means that thicker perovskite layers need to be used, further enhancing the effects of mobile ion-induced band flattening on the output current density. On the other hand, however, recent publications do suggest that incorporating Sn in perovskites reduces the initial impact of mobile ions on device performance by increasing activation energies that ions would need to overcome to move, thereby 

reducing the diffusion rate of mobile ions.<sup>226,227</sup> Nevertheless, the extent to which ion movement is present in Sn-containing perovskites, as well as the mobility of these ions, may depend strongly on their composition and thin film quality, which could be easily influenced by the use of additives, such as RbI.<sup>228</sup> Finally, there are indications that mobile ion densities in Sn-containing perovskites strongly increase upon aging, similarly to those in their neat Pb-based counterparts, as well as upon oxidation.<sup>229</sup> All in all, we anticipate additional research efforts in this direction, which will eventually reveal the critical aspects of ion migration in mixed Sn−Pb perovskites. 

Mobile ion density and the active layer thickness, however, are not the only factors determining the ion-induced current losses in PSCs. The quality of the interfaces plays a large role in determining the eventual ion-induced current losses. Improved interface quality can significantly reduce the impact of mobile ions on the device performance,<sup>223</sup> for example, by inhibiting mobile ions from diffusing into the transport layers<sup>230</sup> or reducing nonradiative recombination at the interfaces.<sup>231</sup> Charge transportation and extraction can be limited by defect-induced trap states. These traps mainly accumulate at the surfaces, including both the grain boundaries and the perovskite interfaces with the charge extraction layers. The interfaces with the charge carrier selective contacts are also a source of losses. The energy level mismatch induced by the transporting layers is largely associated with the nonradiative recombination of the accumulated (minority and majority) carriers at the interfaces,<sup>232</sup> stressing the importance of interface engineering to overcome this loss mechanism. Another way for interface improvement is using doped transport layers that can increase the internal voltage over the perovskite layer, significantly reducing interface recombination.<sup>233</sup> Both the reduced interface recombination and the increased internal field reduce the detrimental effect of mobile ions. Generally, the more pronounced the nonradiative recombination is in the device (typically limited by the interface), the more the device will be impacted by ioninduced field screening and the corresponding reduction in charge carrier extraction efficiency. 

Overall, ion movement phenomena are present in mixed Sn−Pb perovskites, with the additional contribution from Sn(II) oxidation, and are responsible for current losses. However, current reports indicate that intrinsic ion migration in freshly prepared perovskite films may be reduced with increasing Sn content. Furthermore, the interfaces largely influence the ion-induced current losses. We forecast that the mobile ions present in the perovskite might largely stem from grain boundaries and interfaces, where activation energies for the creation of mobile species might be lower than in the bulk. These results once again underline the importance of interface optimization in mixed Sn−Pb PSCs. 

### 2.5. Section Summary 

Perovskite surfaces play a critical role in the performance of optoelectronic devices. Defects in these surfaces, namely, grain boundaries and interfaces, are particularly detrimental to the device operation, leading to profound nonradiative recombination and harming charge transport and extraction. On the one hand, the crystallization process dictates the final quality of the perovskite thin film. Tin species have a natural tendency to crystallize faster and in a hard-to-control manner, which competes with Pb species in the crystallization of mixed Sn−Pb perovskites and leads to morphological flaws and 

4087 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 6. Interface engineering for solar cells. (a) Efficiency progress of mixed Sn−Pb PSCs with p-i-n structure, depending on the surface that was modified. The best-performing cell for each publication was included in the graph. (b) Stacked bar chart of the publications of mixed Sn−Pb PSCs classified with the interface-related treatment in each year. Exposed, grain, buried, and 2D denote exposed surface modifications, grain boundary modifications, buried surface modifications, and 2D capping strategies, respectively. The data were updated by June 10, 2023. 

unoriented grains, generating, in turn, a significant variety of defects. Thus, we propose further research in the understanding of the perovskite solution properties and its evolution into thin films to better control the crystallization process, with emphasis on the nature of colloids and the stabilization of intermediates. On the other hand, intrinsic material instability to oxidation, mass loss mechanisms, and ion movement phenomena in materials and devices are the other main origins of surface defects and consequent device performance decline. Particularly, the oxidation and mass loss at the surface region of the material could lead to the formation of extraction barriers that prohibit charge carrier extraction, leading to the loss of cell efficiency. In the same line, mobile ions in metal halide perovskites can lead to inefficient charge extraction at the interfaces. Overall, the above-mentioned sources of imperfections will ultimately have their most harmful consequences at the interfaces, with a concentration of defects in these sites. Such treatments will ultimately improve the stimuli resistance,<sup>97</sup> reduce the photochemical reactions and suppress movements as well as reduce their impact on device performance, enabling all-perovskite tandem devices with excellent long-lasting performances that are suitable for commercialization. 

## 3. INTERFACE ENGINEERING FOR SOLAR CELLS 

Generally, planar PSCs are assembled in either a p-i-n or n-i-p device structure.<sup>234</sup> Like the conventional neat Pb PSCs, the first series of mixed Sn−Pb PSCs were made with the n-i-p architecture. In 2014, two groups independently fabricated n-ip devices with PCEs (power conversion efficiencies) above 4 and 7%.<sup>235,236</sup> Although several more attempts have been made since then,<sup>81,232,237−240</sup> the best PCE for mixed Sn−Pb n-i-p PSCs is still just around 16%,<sup>241</sup> far below the current record of close to 24% realized with p-i-n devices.<sup>9,77,242</sup> This efficiency gap is caused mainly by the detrimental chemical reactions between the charge transport material and the perovskite component in n-i-p devices. For example, it has been shown that oxygen vacancies from metal oxide n-type semiconductors,<sup>203−205</sup> such as SnO2 and TiO2, induce Sn(II) oxidation at the ETL/perovskite interface.<sup>180,203−205</sup> Moreover, the degradation of the perovskite may also be triggered by hygroscopic dopants (i.e., Li or Co salts) in the conventional hole transport layer (HTL) used in n-i-p devices,<sup>232,243</sup> 2,2′7,7′-tetrakis(N,N-di-p-methoxyphenylamine)-9,9′-spirobifluorene (spiroMeOTAD). As a result, the charge extraction at the perovskite interfaces with the charge transporting layers is largely hindered, leading to strongly limited device efficiencies. Generally, the passivation of the metal oxide layer, which has 

been frequently demonstrated with an organic n-type semiconductor, like PC61BM<sup>240</sup> and C60-SAM,<sup>239</sup> is crucial for the growth of high-quality mixed Sn−Pb perovskite films. Likewise, interface modification and new HTL implementation could be an efficient way to mitigate interface recombination and improve the performance of the n-i-p devices. 

Because of their more widely implemented useespecially for all-perovskite tandemsand higher efficiencies as well as better device stability, in this section, we mainly focus on the devices fabricated with the p-i-n architecture, which has several advantages for the manufacturing of large-area modules<sup>244</sup> and flexible electronics.<sup>245</sup> As for the n-i-p architecture, the first p-in mixed Sn−Pb PSC was also reported in 2014, with a PCE of around 10% with the perovskite composition of MAPb0.85Sn0.15X3.<sup>115</sup> Since then, significant efforts have been made regarding the optimization of the 3D perovskite composition and stoichiometry,<sup>31,246−260</sup> especially via tuning the ratio of Sn(II) and Pb(II) cations.<sup>261−270</sup> In the current stage, half Sn(II) and half Pb(II) content for the B-site cation is the most common combination because of its good optoelectronic quality and desirable bandgap for photovoltaic applications, especially as the rear absorber for the allperovskite tandems.<sup>269</sup> Here, we summarize the results from recent surface modification reports based on the singlejunction mixed Sn−Pb PSCs and various related all-perovskite tandems. Each section differentiates each type of surface in the perovskite films and the specific characteristics and treatment requirements. In particular, we consider the top exposed surface, the grain boundaries, the bottom buried surface, and surfaces capped with 2D phases (Figure 6). We summarize some representative works and main strategies employed for each surface and point out the directions to investigate in the future to further improve these interfaces. 

### 3.1. Exposed Surface 

The most vulnerable surface of the perovskite films would be the exposed surface, due to its relatively extended period of contact with the atmosphere during the cell fabrication. Meanwhile, the p-doping in Sn-containing perovskites favors the accumulation of Sn(IV) at the surface, which in turn acts as electron traps that promote recombination and lattice degradation toward secondary phases.<sup>271</sup> Degradation at the exposed surface will also negatively affect the charge extraction at the top contact, i.e., the electron extraction of the ETL in the case of a p-i-n cell. In addition, C60 molecules commonly employed in the p-i-n cells act as deep trap states when in direct contact with the perovskite films.<sup>272</sup> All these things considered, engineering this surface to enable efficient charge transport and reduce interface recombination is crucial to 

4088 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u><mark>pubs.acs.org/CR</mark></u> <mark>Review</mark> 

### <u>Chemical Reviews</u> 



Figure 7. Exposed surfaces. (a) (i) Illustration of the mixed Sn−Pb perovskite films with different post-treatments. PEA<sup>+</sup> : phenethylammonium; HA<sup>+</sup> : hydrazinium; Ac<sup>−</sup> : acetate. (ii) Time-resolved photoluminescence (TRPL) decay curves of the perovskite films fabricated without and with maltol post-treatment on quartz substrates. Reproduced with permission from ref 12. Copyright 2021 Royal Society of Chemistry under a Creative Commons Attribution-NonCommercial 3.0 Unported License. (iii) Schematic illustration of how a PCBM layer deposits on a rough mixed Sn−Pb perovskite layer with Al2O3 nanoparticles post-treatment. (iv) J−V curves under simulated AM 1.5G illumination in forward (Fwd.) (JSC to VOC) and reverse (Rev.) (VOC to JSC) scan directions of the champion control and the champion device with an optimized Al2O3-nanoparticle interlayer thickness. Reproduced with permission from ref 30. Copyright 2023 Wiley-VCH under the terms of the Creative Commons Attribution License. (b) (i) Schematic illustrations of CPTA binding to the exposed Sn(II) at the surface of mixed Sn−Pb perovskite films. (ii) Graded heterojunction of mixed Sn−Pb perovskite films and DF-C60 fullerene introduced through the antisolvent. (iii) Schematic showing the charge extraction and recombination processes without and with the PCBM layer. τf shows the forward injection time from the mixed Sn−Pb perovskite films to C60. Reproduced with permission from ref 40. Copyright 2018 American Chemical Society. (iv) Comparison of electron mobility μ in electron-only devices with different interlayers. μ was determined by the space-charge-limited-current (SCLC) method. Reproduced with permission from ref 66. Copyright 2022 Wiley-VCH under the terms of the Creative Commons Attribution License. (c) (i) Illustration of the mixed Sn−Pb perovskite films with different post-treatments. EDA binds to the metal center of the perovskite. EDA<sup>2+</sup> , PP<sup>2+</sup> , and CysH<sup>+</sup> create the desirable surface dipole that facilitates electron extraction. EDA: ethylenediamine; EDA<sup>2+</sup> : ethylenediammonium; PP<sup>2+</sup> : piperazine-1,4-diium; CysH<sup>+</sup> : cysteinium. (ii) Electronic structure of the mixed Sn−Pb perovskite films fabricated without and with the post-treatments. (iii) Universal EDAI2 post-treatment for p-i-n PSCs through both wet and dry processes. The mixed solvent of IPA (i-PrOH) and toluene (PhMe) is important for wet processing.<sup>9</sup> (iv) J−V curves under simulated AM 1.5G illumination of the champion control and the champion device with optimized wet and dry EDAI2 posttreatments. Reproduced with permission from ref 72. Copyright 2022 American Chemical Society. (d) Representative chemical reactions disclosed in the perovskites for solar cell application. (a) Proton transfer reaction between FA<sup>+</sup> and piperazine.<sup>80</sup> (b) Condensation reaction scheme of FA<sup>+</sup> and 3-APy.<sup>61</sup> (c) Reaction of FA<sup>+</sup> with EDA to produce Imn<sup>+</sup> and ammonia.<sup>50</sup> (d) HMTA reaction with FA<sup>+</sup> , leading to tetrahydrotriazinium (THTZ-H<sup>+</sup> ).<sup>82</sup> (e) Reaction between 3,3′-((perfluoropropane-2,2-diyl)bis(4,1-phenylene)) bis(3-(trifluoromethyl)-3H-diazirine) and FA<sup>+</sup> generating the product with newly-formed covalent bonds.<sup>83</sup> 

achieving high device performance.<sup>273,274</sup> The interface could be successfully improved by (1) improving the quality of the perovskite films (smoothness and crystallinity), (2) reducing the Sn(IV) content at the surface, (3) passivating the defects at the surface, and (4) altering the surface electronic properties toward an electron-transport favorable character in p-i-n cells. Theoretically, polishing the surface with chemical<sup>9,275</sup> or mechanical<sup>276</sup> approaches or even using lasers<sup>277</sup> would 

allow for the removal of the defective nanostructures at the exposed surface. In addition, molecules that ensure effective chemical interaction with the perovskite lattice and efficient carrier extraction would be suitable for perovskite posttreatment at contact with extraction layers. 

3.1.1. Protection from Oxidation. Post-treatments of perovskite crystallized films, or precrystallized films during the quenching step,<sup>278</sup> are highly effective strategies for increasing 

4089 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 8. Chemical structures of C60 and its derivatives that have been employed in mixed Sn−Pb PSCs. 

the robustness of the material and its resistance to degradation from atmospheric O2, as well as removing oxidized species that existed at the surface. The newly-formed interfaces can block the invasion of air into the perovskite layer, and desired chemical bonds built during the process may also increase the intrinsic resistance of the material. The most commonly employed chemicals for post-treatment in the metal halide PSCs community are ammonium salt, e.g., phenethylammonium (PEA<sup>+</sup> )-based materials.<sup>279,280</sup> Similar to its effects in neat Pb PSCs (Figure 7a-i),<sup>279</sup> post-coated PEA<sup>+</sup> can also improve the performance of mixed Sn−Pb PSCs.<sup>281−283</sup> Due to the hydrophobicity and superior A-site binding capacity of PEA<sup>+</sup> , the modified films tend to be more robust with reduced defect states and decreased Sn(IV) concentrations at the surface. Besides A-site substitutes, strong X-site binding species, e.g., pseudohalide acetates (Ac<sup>−</sup> ), are also effective in inhibiting the oxidation of Sn(II) and suppressing ionic migration, as their coordinating energy with Sn(II)/Pb(II) is larger than that for the I<sup>−</sup> anion.<sup>283</sup> However, ammonium ligands or pseudohalides that can form 2D phases require careful control as the 2D phase will probably introduce an energy level that is unfavorable for the carrier extraction at the interface in the p-i-n devices.<sup>284</sup> Besides aiding in the passivation of the perovskite surface, some ammonium salts can also introduce a second crystal growth via Ostwald ripening, leading to a significant increase in grain size.<sup>285</sup> For example, the grain size of the films exposed to methylammonium chloride (MACl) vapor can be increased to reach over 1 μm during the post-treatment, yielding polycrystalline films with improved quality.<sup>106</sup> The PCE of the resultant cells was improved along with device resistance to air: Unencapsulated mixed Sn−Pb PSCs maintained their full performance after 150 h at 85 °C in air. There are also several different molecules that have the ability to reduce the amount of Sn(IV) or suppress its formation, such as hydrazinium (HA<sup>+</sup> ),<sup>286</sup> dopamine cation (DAH<sup>+</sup> ),<sup>287</sup> and borohydride-based materials,<sup>288,289</sup> or maltol, a metal-chelating compound, which was used to produce perovskite films with carrier lifetimes of over 7 

μs, which were later implemented to fabricate devices with PCEs over 21% (Figure 7a-ii).<sup>12</sup> 

Developing chelating molecules that efficiently passivate and stabilize the fresh films, without inducing unfavorable carrier recombination, offers an effective way to improve the performance of mixed Sn−Pb perovskite electronics.<sup>290</sup> On the other hand, electrical shunts might be another serious issue for an efficient device considering that mixed Sn−Pb films present a high degree of roughness, especially when a thin ETL is deposited in the following via spin coating (Figure 7a-iii, iv). In order to reduce the layer roughness and improve the conformality of subsequently coated ETLs, an extra layer might be required. Recent work shows a successful example of this, using an ultrathin noncontinuous Al2O3 nanoparticle layer to improve the efficiency and stability of the mixed Sn−Pb perovskite devices.<sup>30</sup> By treating the buried or exposed surface of the perovskite films, researchers in the field have widely used Al2O3 and some other conventional metal oxides as thin interlayers, either with mesoporous or dense continuous form, for improving the stability and efficiency of PSCs.<sup>63,291−295</sup> Regarding this particular successful application of Al2O3 nanoparticles in mixed Sn−Pb PSCs, the reason behind this would be the higher stability of Al2O3 compared to other metal oxides, such as TiO2 and NiOX, thanks to the stronger metal−O bond and less redox reactivity.<sup>296−299</sup> 

3.1.2. Defect Passivation and Energy Structure. The 

facile oxidation of Sn(II) and the iodide ions lead to the generation of an abundance of defects at the perovskite surface, such as tin and iodide vacancies, as well as interstitials. Iodide vacancies generally exist in all kinds of I-containing perovskite films. In addition, halide anions are particularly mobile, especially at elevated temperatures. Theoretical calculations show that in mixed Sn−Pb perovskite polycrystalline films, iodide ions centered with Sn can be more easily detached compared to those centered with Pb,<sup>80</sup> suggesting that the surfaces of tin-containing perovskites will present a higher density of exposed metal(II) centers compared to leadcontaining perovskites. Apart from that, various site vacancies 

4090 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

and interstitial states exist at the surface that also alter the surface energetic states of the films. 

3.1.2.1. Fullerene Derivatives. The vast amount of available knowledge on surface and defect chemistry in mixed Sn−Pb perovskites offers the potential to design passivation strategies that target specific surface defects through functionalized molecules. Fullerenes are versatile electron-transport molecules, typically applied on top of perovskite films,<sup>300,301</sup> that can bear a variety of functional groups for specific purposes. Their flexibility and adaptability grants them enormous potential for improving the perovskite top interface. An example of a fullerene that is used for interface improvement in mixed Sn−Pb perovskites is the carboxylic group-containing fullerene derivative C60 pyrrolidine tris-acid (CPTA) (Figure 7b-i).<sup>80</sup> XPS characterization showed that CPTA predominantly binds to Sn sites rather than to Pb sites, owing to the predominant exposure of the Sn sites at the film surface. The n-type nature of the fullerene derivatives also provides the treated films with superior electron extraction at the top surface. Consequently, PCE values of up to 22.7% were achieved for the devices fabricated using CPTA treatment, with VOC values approaching 0.90 V, reaching a minimum voltage loss of ∼92% of the radiative limit for a ∼1.26 eV bandgap. Previously, fluoroalkyl-substituted fullerene N-methyl-2-(3,5bis(perfluorooctyl)phenyl)-3,4-fulleropyrrolidine (DF-C60), in combination with indene-C60 bis-adduct (ICBA) as ETL, presented excellent passivation effects and enhanced surface protection (Figure 7b-ii).<sup>302</sup> Owing to the improved charge collection and reduced recombination losses at the interface, these PSCs also had high VOC values of up to 0.89 V. Apart from their ability to establish favorable interactions with perovskite, fullerene derivatives, such as phenyl-C61-butyric acid methyl ester (PCBM), can create a spike-like energy band at the top interface, leading to a strongly suppressed carrier recombination at this top interface (Figure 7b-iii).<sup>40</sup> Similarly, indene-C60-propionic acid butyl ester (IPB) and indene-C60propionic acid hexyl ester (IPH), with improved electron mobility, suppress interface recombination by providing a higher conduction band offset to hamper charge-carrier-backtransfer recombination (Figure 7b-iv).<sup>66</sup> 

Apart from fullerenes (Figure 8), alternatives, such as carborane-based molecules, e.g., phenylamino-decorated carborane (CB-NH2),<sup>273</sup> applied in neat Pb PSCs recently, might be worth investigating. Beyond that, the very large range of “non-fullerene acceptors”, which have been developed for organic photovoltaics, remain largely unexplored for mixed Sn−Pb perovskites. 

3.1.2.2. Diamines, Diammonium Salts, and Metal Doping. The results with fullerene derivatives highlight the ability of surface post-treatments to manipulate device energy diagrams, enhancing in turn the electron extraction at the top interface. In particular, compositional doping, generally realized by organic and inorganic cations that potentially incorporate/bind to the lattice or some particular amines with free electron donating pairs, at the perovskite absorber surface has proven to be an excellent strategy. Coating a layer of a neutral diamine, ethylenediamine (EDA), on the mixed Sn−Pb perovskite films leads to n-type doping of the surface (Figure 7c-i, ii),<sup>303</sup> leading to a downward band bending and the passivation of undercoordinated tin at the top interface. The resultant devices have shown PCEs up to 21.74% for Brcontaining mixed Sn−Pb PSCs (Eg = 1.25 eV), with a reduced voltage deficit (difference between bandgap energy and VOC) 

of 0.39 V. However, amines like EDA with significant basicity and high vapor pressure can also damage the perovskite films. Thus, they are in principle not ideal candidates for extensive perovskite interface engineering, especially for the Sn-based perovskite films that are generally very sensitive. In this regard, the conjugated acid of EDA, ethylenediammonium (EDA<sup>2+</sup> ), is a better option to successfully create the n-type character of the treated film at the surface.<sup>9</sup> In addition, the diammonium cation post-treatment forms a surface dipole, which facilitates electron extraction at the top surface due to the consequently enlarged built-in potential. This can suppress the interface recombination even in the device that originally displayed nonideal band alignment. One of the most attractive aspects of this strategy is its universal applicability to perovskites of different compositions (neat Pb, neat Sn, and mixed Sn−Pb), to passivate the surface through both solution-based processing and thermal evaporation (Figure 7c-iii, iv).<sup>72</sup> The most pronounced improvement in device efficiency, mainly through a strong increase in VOC, is for the case of Sn-containing films, highlighting the particularly beneficial aspect of this strategy on surfaces with a high concentration of defects, which in this case are likely dominated by tin chemistry. The preferential anchoring of EDA<sup>2+</sup> to Sn-related sites, i.e., VA(Sn), is still apparent even for wider bandgap (FA0.8MA0.2Pb0.8Sn0.2I3, Eg = 1.33 eV) perovskite films which contain a much lower relative Sn content.<sup>304</sup> Similarly, an amino acid-based material (which will be further discussed in section 3.3 (Buried Surface)) can also be used to regulate the perovskite surface potential energy and introduce a beneficial surface dipole that facilitates electron extraction at the top surface.<sup>305</sup> We note that the orientation of the ligand applied should be carefully designed. For example, in the case of cysteine,<sup>305</sup> the acid group side interacts more strongly with the perovskite lattice than that of the ammonium group thanks to the assistance of the −SH group, leading to the surface dipole formed with the desired orientation (Figure 7c-i). Over the past years, diamines and diammonium salts have been extensively employed for the surface modification of p-i-n PSCs by various research groups.<sup>144,306</sup> The wide structural diversity of this group of chemicals enables testing modifiers for specific desired effects. For example, by increasing the alkyl chain length, the diammonium ligand1,3-propane-diammonium (PDA<sup>2+</sup> ) is more effective than EDA<sup>2+</sup> in maximizing the photoluminescence quantum yield (PLQY) retention of perovskite films covered with a C60 layer.<sup>307</sup> Despite the high similarity in the chemical structure of these two diammonium compounds, the significantly different behavior as surface modifiers points out the need for further investigation of the underlying mechanism. 

While small ligands such as EDA<sup>2+</sup> , piperazine-1,4-diium (PP<sup>2+</sup> ),<sup>80</sup> and PDA<sup>2+</sup> are unable to form a 2D perovskite on the surface of an iodide-based perovskite,<sup>308</sup> increasing the chain length up to 1,4-butane-diammonium (BDA<sup>2+</sup> ) can reconstruct the perovskite surface with a newly formed Dion−Jacobson (DJ) perovskite phase,<sup>308</sup> which substantially alters the interfacial charge carrier dynamics. In general, the small diammonium ligandsEDA<sup>2+</sup> , PP<sup>2+</sup> , and PDA<sup>2+</sup> dope or dedope the perovskite surface to shift the Fermi level to lie closer to the conduction band minimum (CBM), forming a more favorable electronic structure for the electron extraction at the n-type interface in p-i-n cells. The possible underlying mechanism of this doping/dedoping effect can be related to the factors that are responsible for the variation of the carrier 

4091 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 9. Grain boundary. (a) (i) Schematic illustration of the perovskite films and the crystallographic domain and grain boundaries. (ii) Binding energy (Eb) between passivators and various acceptor-like defects. Maximum electrostatic potentials (φ) of the surfactants are provided with the chemical structure of the passivators. Reproduced with permission from ref 8. Copyright 2022 Springer Nature. (iii) Crystal structure of 1D PyPbI3, viewed along the c-axis, generated with the CIF file from ref 20. (iv) Grain boundary of mixed Sn−Pb perovskite films passivated with 5FPEA<sup>+</sup> . (b) (i) Lewis acid (A)−base (B) reaction to form an adduct (A·B) with a dative bond, and the Lewis base forms the dative bond with Sn(II) of the mixed Sn−Pb perovskite lattice. (ii) Lewis bases with oxygen donor (O-donor), sulfur donor (S-donor), and nitrogen donor (N-donor). Reproduced with permission from ref 33. Copyright 2016 American Chemical Society. (iii) Lewis base molecules and passivating ions that have been applied for improving the mixed Sn−Pb perovskite films. (c) (i) An amino acid contains both acidic (carboxylic acid fragment) and basic (amine fragment) centers. The isomer on the right is a zwitterion. (ii) (ii-a) Formamidine sulfinic acid (FSA) and its zwitterion. (ii-b) Oxidation of FSA. (iii) Schematic illustration of antioxidation and defect passivation at grain surfaces (including film surface and grain boundaries) of mixed Sn−Pb perovskite films enabled by FSA. Reproduced with permission from ref 44. Copyright 2020 Springer Nature. (d) (i) Equation of Urbach energy, where α(E) is the absorption coefficient spectra and αg is the value of α at the bandgap energy (Eg). Higher values of EU show higher subgap absorption and vice versa. The relationship between device VOC and Urbach energy shows that the value is affected by the film processing condition and perovskite composition. Reproduced with permission from ref 68. Copyright 2022 American Chemical Society. (ii) BBMS interacts with Sn(II) and FA<sup>+</sup> from perovskite. BBMS binds to the mixed Sn−Pb perovskite film, leading to the Urbach energy reduction of the mixed Sn−Pb film from 28 to 19 meV. Reproduced with permission from ref 73. Copyright 2022 Wiley-VCH. 

concentrations.<sup>309</sup> In this particular case, it might be caused by, for example, (i) the suppressed formation of defects raising the p-doping, tin vacancies and interstitial iodine defects,<sup>310,311</sup> owing to the enhanced lattice stability; (ii) the change of the perovskite surface composition to the state with an increased formation energy of the tin vacancies;<sup>312,313</sup> (iii) the change of the surface defect states being dominated by the donor-type shallow defects;<sup>88,310</sup> (iv) the change of the length of the metal−halide bond and/or the tilt of the MX6 octahedral of the perovskite lattice,<sup>314</sup> upon the binding of the ligands to the surface of the perovskite; and/or (v) the enhanced charge transfer doping from the next contact, i.e., ETL, in the stacked structure.<sup>309,315,316</sup> To the best of our knowledge, however, a comprehensive study is still lacking for mixed Sn−Pb perovskites in these aspects. Meanwhile, the cyclic diamines piperazine (PP), 4-aminopiperidine (4APP), and 4- (aminomethyl)piperidine (4AMP) also lead to the formation of an n-type surface in mixed Sn−Pb perovskites.<sup>80</sup> Interestingly, these diamines even react in situ with the organic material at the surface of the perovskite films, primarily FA<sup>+</sup> , scavenging protons from the cation(s) (Figure 7d). In these cases, the working mechanism of the diamines is likely comparable to the diammonium ligands, where molecules with 

less than four carbon atoms between amines/ammoniums mostly will not lead to the formation of 2D phases. However, the diamines presented additional effects caused by the mentioned deprotonation of A-site cations. On top of that, they cause more morphological “erosion” of the surface due to their stronger basicity.<sup>80</sup> Alternatively, for other amines, amineFA<sup>+</sup> condensation reactions can take place, expelling ammonia, as identified for MA<sup>+</sup> in solution.<sup>317</sup> Methylenediammonium (MDA<sup>2+</sup> ) also oligomerizes into hexamethylenetetramine (HMTA), which can then react with FA<sup>+</sup> to form tetrahydrotriazinium (THTZ-H<sup>+</sup> ).<sup>82</sup> These reactions can potentially happen at the solid film surface, for example, when it is modified with 3-(aminomethyl)pyridine (3-APy)<sup>61</sup> and likely 2-thiophenemethylamine (TMA),<sup>318</sup> EDA, and other alkylamines.<sup>50,317</sup> In the case of 3-APy, the product is N-(3-methylpyridine) formamidinium (MPyFA<sup>+</sup> ), or for amine-MA<sup>+</sup> reaction, a simple transfer or sharing of acidic protons happens, forming 3-APy<sup>+</sup> . The authors further claimed that the formed MPyFA<sup>+</sup> cation sits at the A-site of the perovskite, with the pyridine ring promoting the formation of positively charged VI (iodide vacancies), which act as shallow donors and induce a field that facilitates electron extraction. These top surface modifications seem to ensure less interfacial 

4092 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

recombination and, accordingly, better performance for the resultant cells, but further work is necessary to fully understand multiple concurrent and unusual effects. These interesting in situ chemical reactions occurring between the neutral amines or other molecules, such as bis-diazirine,<sup>83</sup> and the organic cation(s) of the precursor material offer huge potential for further exploration/improvement in PSCs and other perovskite-based applications. In particular, precisely targeted chemical reactions or surface species can be implemented into the perovskite system for specific aims.<sup>50,318−323</sup> Various unexpected/underexplored chemical reactions generated in this complex system also make the perovskite research more exciting. 

On the other hand, various metal cations have also been examined to tune the properties of mixed Sn−Pb perovskites. Bowman et al. found that the presence of Zn<sup>2+</sup> ions in the precursor solution enabled improved Pb:Sn homogeneity in the as-crystalized films and increased charge carrier lifetime, but they also observed the slightly increased p-type nature of the mixed Sn−Pb perovskite.<sup>324</sup> The surface of the mixed Sn−Pb perovskite films has also been improved with the small metal cation Zn<sup>2+</sup> , thanks to its stronger ionic interaction with the iodide than that of Sn and Pb cations.<sup>325</sup> Alternatively, the perovskite lattice has also been doped with foreign metal cations by substituting the B-site cations and/or filling the B- site vacancies,<sup>326−329</sup> e.g., with Cd<sup>2+</sup> for mixed Sn−Pb perovskites.<sup>330,331</sup> Interestingly, Huang et al. found that the alkaline earth metal cation, Ba<sup>2+</sup> , stays at the interstitial sites and works as a shallow electron donor, creating an n-type/less p-type surface of the mixed Sn−Pb perovskite films.<sup>332</sup> This work inspires the community to study the effectiveness of the rest of the alkaline earth metal cations for improved mixed Sn−Pb perovskites, such as Mg<sup>2+</sup> , Ca<sup>2+</sup> , and Sr<sup>2+</sup> , bearing in mind that the perovskite material will likely be particularly sensitive to the doping concentration.<sup>333</sup> 

The application of functionalized molecules or rationally selected metal cations on the top perovskite surface is a straightforward approach to improve charge extraction at the interface and enhance device performance. Fullerenes and, more recently, diammonium compounds and diamines have been widely employed for modifying the mixed Sn−Pb perovskite top interface, and its effectiveness has also been successfully extended to the p-i-n devices with various perovskite compositions. The easy structural tunability of these materials offers the possibility to modify perovskite surfaces with specifically desired results. Considering the vulnerable nature of the exposed surface and its importance for electron extraction, future studies should focus on strategies to precisely passivate specific defect states, especially in combination with energy level tailoring. We note that altering the surface energetic states (e.g., to a more n-type character) will likely activate halide migration, aggravating device instability.<sup>334</sup> Therefore, despite the beneficial effects on the device performance of some surface passivation strategies, the detrimental side effects limit the maximum stability improvement of the resultant PSCs, especially under elevated temperatures. To overcome this trade-off, a deeper understanding of surface defect characteristics and accordingly designing improved strategies, for example, with the participation of some interesting sulfur-containing materials<sup>335−337</sup> to overcome these hurdles, is of utmost importance. 

### 3.2. Grain Boundaries 

Perovskites processed by conventional solution-based methods form polycrystalline thin films featuring a high number of grain boundaries (Figure 9a-i). These sites contain vacancies and interstitials of different characteristics due to the intrinsic nature and instability of grain boundaries, reducing the optoelectronic quality of the film. Therefore, the passivation of grain surfaces and interfaces is critical for attaining maximum performance for solar cells. Strategies reported so far for modifying grain boundaries generally rely on introducing additives into the perovskite precursor solution. The component should be sufficiently large to avoid being incorporated into the 3D perovskite lattice, while at the same time also chemically unable to split up the 3D perovskite lattice, such that it would ultimately end up at the grain boundaries of the polycrystalline films. Additive engineering simultaneously allows for keeping tighter control of the crystallization process, with the possibility to modulate and reduce defect formation already during the thin film fabrication. 

3.2.1. Defect Passivation. 3.2.1.1. Ammonium Salts. Ammonium cations are a species that resemble the material already present in the perovskite lattice, offering a unique opportunity to use them as additives for defect passivation in grain boundaries. In addition, the structure of these molecules can be easily tuned to achieve the desired properties in perovskite thin films. The most popular additives of this family are ammonium cations,<sup>338</sup> which have shown a very high reproducibility in numerous works. A comparison among PEA<sup>+</sup> , phenylammonium (PA<sup>+</sup> ), and 4-trifluoromethyl-phenylammonium (CF3-PA<sup>+</sup> ), using ab initio molecular dynamics simulations, suggested that these passivators are absorbed on the surface of the grain boundaries, with a binding energy that depends on its chemical nature (Figure 9a-ii).<sup>8</sup> For CF3-PA<sup>+</sup> , the superior electron-withdrawing character of the fluorinated substituent results in a more electropositive ammonium head, ensuring the strongest binding with the negatively charged defects, i.e., A- and B-site vacancies. Moreover, the absorbed CF3-PA<sup>+</sup> also reduces the donor-type defects, e.g., VI, by increasing the desorption energy at the corresponding sites. Although proven only for neat Pb perovskites, CF3-functionalized PEA surfactant (CF3-PEA<sup>+</sup> ) presents a high molecular polarity, ensuring a strong interaction both with the perovskite modified underneath and the C60 coated atop.<sup>339</sup> This enhances the charge extraction together with a reduced energetic mismatch between the perovskite and the ETL, thereby enlarging the quasi-Fermi level splitting (QFLS) and increasing the device VOC. Owing to the reduced surface defects and elongated carrier diffusion length of the mixed Sn−Pb films, the CF3-PA<sup>+</sup> modification yielded device efficiencies of over 22% for single-junction PSCs and a certified efficiency of 26.4% for all-perovskite tandem solar cells.<sup>339</sup> Varying the structure of the ammonium additives also offers the possibility to control the dimensionality of the phases that form. The medium-sized cation pyrrolidinium (Py<sup>+</sup> ) forms a one-dimensional (1D) PySnxPb1−xI3 phase (Figure 9a-iii), which passivates the film surface and grain boundaries, leading to films with elongated device operational life.<sup>20</sup> Meanwhile, other fluorinated ammonium cations, such as 2,3,4,5,6-pentafluorophenethylammonium (5FPEA<sup>+</sup> ) (Figure 9a-iv),<sup>340</sup> also reduce trap-assisted recombination losses and lower the background carrier density in mixed Sn−Pb 

4093 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> <mark>Review</mark> 



Figure 10. Buried interface. (a) (i) Schematic illustration of the perovskite films sandwiched with the charge transport layer with the buried interface highlighted. (ii) Schematic illustration of GlyHCl as an additive for processing mixed Sn−Pb perovskite films, creating a surface dipole at the buried interface by the preferential molecular accumulation. (iii) Schematic illustration of top-down and bottom-up crystallization. (iv) Schematic for the mechanism of additive segregation during the film formation. Reproduced with permission from ref 11. Copyright 2023 Springer Nature under a Creative Commons Attribution 4.0 International License. (b) (i) Tuning the energy level of the perovskite with CEAHCl treatment. Reproduced with permission from ref 25. Copyright 2022 American Chemical Society. (ii) Structure of N,Cl-codoped graphene quantum dots (GQDs). Reproduced with permission from ref 35. Copyright 2022 Elsevier. (iii) Tuning the energy level of PEDOT:PSS by GQDs doping or dilution. (iv) Current−voltage (I−V) characteristics of the PEDOT:PSS films without and with Au nanochains (AuNCs) modification. The plot was generated with WebPlotDigitizer 4.6 based on the original graph published.<sup>43</sup> Copyright 2022 Royal Society of Chemistry. (c) (i) Long-term stability of the mixed Sn−Pb PSCs with different HTMs. Reproduced with permission from ref 69. Copyright 2021 Wiley-VCH. (ii) Molecules bind to the NiOX HTL to passivate its defects, alter its work function, and/or passivate the defects in the perovskite films. (iii) New organic HTL drawing CzAn as an example. (iv) New inorganic HTL presenting the device stability of SnOCl modified HTL as an example. The plot was generated with WebPlotDigitizer 4.6 based on the original graph published in ref 74. Copyright 2022 Wiley-VCH. (d) (i) Schematic illustration of the misaligned energy levels of the perovskite and SAM-based hole selective contact (left). Optical images of the finished devices, showing the substrate coverage by triple-cation perovskite films fabricated on the Me-4PACz selective contact layer (right). Reproduced with permission from ref 75. Copyright 2023 American Chemical Society under CC-BY 4.0. (ii) Co-adsorption of SAM and small filler, MPA (left) and 6dPA (right). (iii) Chemical structures of CbzNaPh and 3PATAT-C3. The correspondingly modified ITO substrates show HOMO levels of −5.24 and −5.44 eV, respectively. (iv) Schematic illustration of SAM and Al2O3-based hole selective contact (left). Schematic illustration of the SAM molecule codeposited with perovskite precursor solution (right). 

perovskite films. Overall, ammonium species are remarkably efficient for passivating the grain surfaces of perovskite films. 

3.2.1.2. Lewis Bases. One key species used as additives in perovskite solutions to modulate defects and control the crystallization are Lewis bases (Figure 9b-i, ii). These nucleophilic compounds can establish strong interactions with perovskite precursor materials during film processing and inside the final films (Figure 9b-iii).<sup>33,341</sup> For instance, the antioxidant caffeic acid has the ability to prevent Sn(IV) formation, modulate the crystallization, and mitigate the defect densities in the films.<sup>86</sup> The molecule owes its versatile properties to the presence of the Lewis base carboxylate and 

the antioxidative hydroxyl groups. As a result, the solar cells presented a VOC of 0.855 V with enhanced shelf stability. Likewise, N,N,N′,N′-tetraphenylmalondiamide (TPMA), a β- diketone-based Lewis base ligand, can effectively passivate the undercoordinated Pb(II) defects and interact with Sn(II) in perovskite films to inhibit its oxidation via binding with the ketone group.<sup>342</sup> In addition, the hydrophobic benzene groups ensure an improved resistance of the films. Apart from various donor groups from organic species,<sup>343−347</sup> the coordination with the metal can also be realized by compounds bearing pseudohalide anions, such as thiocyanate (SCN<sup>−</sup> ),<sup>247</sup> acetate (Ac<sup>−</sup> ),<sup>348</sup> and tetrafluoroborate (BF4−).242 For instance, the 

4094 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

addition of KSCN improves the resistance of Sn(II) against oxidation, since the SCN<sup>−</sup> anions interact with the undercoordinated Sn(II). These modified mixed Sn−Pb PSCs show enhanced air stability, with reported solar cells maintaining over 50% of their initial PCE after 5 days of air exposure.<sup>349</sup> Moreover, K<sup>+</sup> cations can reduce grain boundaries and defect states in films.<sup>350</sup> Thus, the proper design of inorganic/organic salts offers the possibility to introduce both cations and anions with different benefits simultaneously. For example, imidazolium tetrafluoroborate (IMBF4) contains the IM<sup>+</sup> cation that passivates the surface and its counteranion BF4− that reduces the lattice strain of the films.<sup>351</sup> As a result, the mixed Sn−Pb films show improved quality and reduced structural disorder. 

3.2.1.3. Zwitterions. Zwitterionic molecules are another promising family of additive candidates for achieving substantial passivation at surfaces and grain boundaries, as they contain an equal number of positively and negatively charged binding groups (Figure 9c-i). As an example of a small zwitterionic compound, formamidine sulfinic acid (FSA)<sup>44</sup> reduces both the donor- and acceptor-like defects via binding to the sites with its sulfinic and acetamidinium heads, respectively. Apart from the defect passivation effect, FSA can also suppress the formation of Sn(IV) at the precursor solution, thanks to its reducing ability (Figure 9c-ii, iii). Thus, multifunctional additives offer multiple opportunities for processing high-quality mixed Sn−Pb perovskite films and efficient solar cell devices. 

3.2.2. Energy Disorder. Another potential of the additive engineering strategy is the reduction of energy disorder. The energetic disorder of the perovskite films is generally evaluated with the Urbach energy (EU), determined from the absorption tail of the films. Most lead halide perovskite polycrystalline films have an EU of around 12 to 20 meV,<sup>352</sup> with Sn containing perovskites generally having EU over 20 meV,<sup>68</sup> with the absolute value related to the device processing or nature of the perovskite composition (Figure 9d-i). This indicates the existence of subgap defects, which contribute to the Urbach tail and act as Shockley−Read−Hall recombination centers. Therefore, lower EU values in films should imply that these samples also have longer charge carrier diffusion lengths and carrier lifetimes. For mixed Sn−Pb perovskite, the addition of 1-bromo-4-(methylsulfinyl)benzene (BBMS) and SnF2 leads to a record-low EU of 19 meV.<sup>73</sup> The films showed improved crystallinity and resistance to oxidation, and consequently, the treated devices presented outstanding stability, retaining 98% of their original efficiency after heating at 60 °C for 2660 h under N2. BBMS enables less defective grain surfaces and interfaces via its ability to interact with the organic and inorganic cations, i.e., FA<sup>+</sup> and Sn<sup>2+</sup> (Figure 9d-ii). 

The defects at the surfaces are closely related to the degradation processes in devices, and therefore, their mitigation is key to achieving long-term stable PSCs. This fragile and defective nature of grain boundaries can be easily abated by employing the proper molecules as additives in the precursor solution during the thin film formation process. The functionalities present in these compounds will determine their ability to bind the perovskite materials, affecting the crystallization process and being able to bind with specific defect sites. Lewis bases and ammonium salts are the most widely studied additives for processing Sn-containing perovskite films with higher quality, fewer defects, and higher resistance against external stimuli. They benefit from their excellent ability to not just modulate the crystallization 

dynamics but also bind with the readily oxidized Sn<sup>2+</sup> and mobile ions at the grain surfaces. Thus, developing functional molecules that improve the grain surfaces is essential for achieving high-quality polycrystalline perovskite films. Meanwhile, grain-boundary-free films, i.e., single-crystalline perovskite films,<sup>81,353</sup> would also be a direction worth exploring for these materials. In any case, a deeper knowledge and control over the crystallization process of neat Sn and mixed Sn−Pb perovskites remains a necessity, which will open the door to the fabrication of materials with improved intrinsic quality and reduce the dependence on such a high number of additives/ impurities. 

### 3.3. Buried Surface 

Efficient charge carrier management at the buried surface is critical for proper device functioning. This can be achieved by modifying the perovskite film and/or adjacent HTL (Figure 10a-i).<sup>354</sup> Generally, a reduced energy-level offset between the HTL and the perovskite layer would provide benefits for the hole extraction and at the same time reduce the nonradiative charge carrier recombination at the interface. Also, this interface is typically most strongly affected by defects, mainly due to imperfect crystallization of the perovskite material or the detrimental chemical reactions occurring at the bottom surface. Lowering the defect density at the interface would minimize surface recombination and alleviate material degradation, thus improving the stability of the solar cell devices. 

3.3.1. Amino Acid Salts. To address the imperfections at the buried interface, the addition of amino acid salts, e.g., glycine hydrochloride (GlyHCl), into the precursor solution of mixed Sn−Pb perovskites is one of the most effective strategies (Figure 10a-ii).<sup>9</sup> Based on the NMR study, the GlyH<sup>+</sup> cation preferentially binds to the perovskite colloidal particles at the early stages of the processing, due to chemical interactions of the ammonium head with the octahedral units of the perovskite colloids in the solution. This binding causes the particles to reach relatively larger sizes and consequently be heavier than the free component in the solution. During the following crystallization processes, the heavy particles sediment on the substrate, leading to the accumulation of GlyH<sup>+</sup> at the bottom region of the as-prepared films. In particular, the ammonium head of GlyH<sup>+</sup> binds to the perovskite lattice primarily due to the −NH3+ group dominating the interaction of the molecule with perovskites over −COOH,<sup>9</sup> and the electronegative carboxyl groups at the bottom surface face outward from the perovskite, toward the HTL. This results in a surface dipole at the buried interface, which creates an electric field that assists in driving the holes to the HTL. Besides this facilitated hole extraction at the buried surface, GlyHCl also increases the crystallinity and reduces the defect density of the films. As a result, the mixed Sn−Pb PSCs (Eg = 1.25 eV) resulting from this strategy achieved a PCE of 23.6%, with an FF of 0.82 and a VOC of 0.91 V (∼93% of the radiative limit). The unencapsulated devices also showed improved stability under AM 1.5G, retaining over 80% of the initial efficiency after 200 h under continuous maximum power point tracking in an inert atmosphere at ∼55 °C. This GlyH<sup>+</sup> additive strategy has since been successfully adopted by several other groups working with mixed Sn−Pb PSCs and all-perovskite tandem cells.<sup>355,307,356−359</sup> 

The successful and targeted introduction of the additives in the perovskite films requires a profound understanding of the 

4095 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

crystallization mechanism. Regarding the crystallization direction of the films, the downward (top-down) pathway generally applies more frequently than the upward (bottomup) path for the films processed via solution-based methods (Figure 10a-iii). In most cases, this happens since the evaporation of the residual solvent is initialized from the top surface of the “wet” films, leading to the advanced supersaturation and the formation of nuclei.<sup>360</sup> The downward crystallization can, however, lead to fluctuating distributions of the additive based on its properties. In a downward crystallization process, generally, the additives, if not volatile, will be locked at the top surface when their colloidal particles have low solubility.<sup>360,361</sup> Meanwhile, if colloidal particles show a higher solubility and weigh more than the colloids containing only 3D perovskite precursors, they will be sedimented at the bottom region of the wet films.<sup>9</sup> Exceptionally, if the additives establish no strong interaction with the perovskite or contain an ion that is exchangeable with the perovskite composition,<sup>348</sup> they will most likely be squeezed out and end up accumulating at the bottom region of the films. In some specific cases,<sup>362−364</sup> however, bottom-up crystallization dominates. For example, keeping the surface of the films wet and intentionally exposing them to solvent vapor would allow the crystal growth to initialize from the buried interface.<sup>365</sup> By manipulating the compositions of the intermediate states, interestingly, multiple crystallization routes can be present. For example, in perovskite (MAPbI 3 ), perovskite/MA 2 Pb 3 I 8 (DMSO) 2 , and MA2Pb3I8(DMSO)2, perovskite crystal growth can take place through a downward-growth, both downward- and upwardgrowth, and upward-growth mechanisms, respectively.<sup>366</sup> The effect in the mixed Sn−Pb perovskite system is yet to be examined, however. Furthermore, if significant chemical interactions exist between the ligand and substrate, this will also lead to the accumulation of the additive at the bottom interface.<sup>367</sup> Recently, Wang et al.<sup>11</sup> claimed that the centrifugal force (kinetics), together with the unfavorable enthalpic interactions (thermodynamics) between additive and perovskite components, provides a strong driving force for the additive segregation in the final spin-coated films (Figure 10aiv). Thermodynamic considerations dictate that high-surfaceenergy polar moieties tend to migrate toward the substrate, i.e., downward segregation, to minimize the free energy of the system.<sup>368</sup> Conversely, nonpolar low-surface-energy moieties preferentially enrich the top surface to reduce the overall free energy of the system, by substituting high-surface-energy perovskite components at the surface, i.e., upward segregation. We note that the knowledge established in solution-based processes may not be directly transferable to vacuum-based dry processing as the crystallization routes are mostly different.<sup>369</sup> 

Back to amino acid salts, the ones with long chain lengths, such as 5-aminopentanoic acid (5AVA<sup>+</sup> ),<sup>370,371</sup> will, however, induce the formation of low-dimensional perovskites.<sup>370,372</sup> Using amino acids with a length no larger than 3-ammonium propionic acid (3APA<sup>+</sup> ) would avoid the formation of lowdimensional phases as the appropriate spatial conformation.<sup>372</sup> Additives with long chain lengths, on the other hand, will largely confine the perovskite growth and result in a more remarkable reduction of grain size compared to their shorter chain counterparts.<sup>373,374</sup> More research on the solution chemistry and the new intermediate states<sup>154,375</sup> that form due to the different amino acid salts,<sup>376</sup> especially using in situ measurements,<sup>377</sup> will guide the design of new materials and the optimization of the cell fabrication processes. However, a 

global picture of how these molecules affect the precursor solution stage and how this impacts the crystallization process, including their influence on defect states and carrier dynamics in cells, is mostly lacking. 

3.3.2. Interlayers and PEDOT:PSS Modifications. Currently, the main advancements of efficient mixed Sn−Pb PSCs largely use PEDOT:PSS as the HTL. This is mainly because of the following: (i) The superior wettability of the PEDOT:PSS film<sup>378</sup> provides sufficient nucleation sites for the rapidly crystallized Sn-containing perovskite films with no pin holes.<sup>379</sup> (ii) The well optimized PEDOT:PSS film processing protocol guarantees the fabrication of compact films with high reproducibility, thus reducing current leakage in the device and improving the yield of efficient PSCs. (iii) The redox-inactive nature, under normal conditions, of PEDOT:PSS reduces the possibility of the Sn(II) oxidation of the Sn-containing perovskites. However, maximizing the potential of PEDOT:PSS requires sometimes various modifications at the bottom interface. For example, managing the energy level of perovskite films can provide a better alignment with the HOMO level of the HTL, suppressing carrier nonradiative recombination at the buried interface. To this end, a layer of 2- chloroethylammonium (CEA<sup>+</sup> ) coated between the perovskite films and the HTL can reduce defect densities and enhance the antioxidative character at both the surface and the bulk of perovskite films (Figure 10b-i).<sup>25</sup> As a consequence, solar cell efficiency and air stability increased, with over 50% PCE retained by unencapsulated devices after 400 h in ambient air. Meanwhile, the use of ammonium salts which contain extra functional groups, such as carboxylic and halide/pseudohalide species, is another promising and versatile additive strategy for mixed Sn−Pb perovskite systems. 

Other strategies for the treatment of the bottom contact focus on inserting a p-type layer between perovskite and PEDOT:PSS films, or modifying PEDOT:PSS itself to achieve a more favorable energy level alignment (Figure 10b-ii, iii),<sup>380</sup> a reduced interfacial resistance,<sup>381</sup> and a further enhanced conductivity, e.g., by gold nanochains (AuNCs) (Figure 10biv).<sup>43</sup> For instance, graphene quantum dots (GQDs)<sup>35</sup> can be easily functionalized with electron-deficient atoms to alter their work functions and give them a p-type character. Accordingly, the N,Cl-codoped quantum dots (N,Cl-GQDs) induce an improved band alignment with the perovskite films, achieving mixed Sn−Pb PSCs (Eg = 1.25 eV) with improved stability, an efficiency of 21.5%, and a VOC of 0.89 V. On the other hand, simultaneously introducing cations and anions at the buried interface through their salts can generate some synergistic effects on both the PEDOT:PSS and the perovskite layers. It was found that incorporating potassium citrate, a weak base, into the PEDOT:PSS can not only neutralize the acidity of PEDOT:PSS but also improve the quality of the perovskites thanks to the coordination of citrate anion with the Sn(II) centers and the potassium cation enhanced film crystallinity.<sup>382</sup> The resultant mixed Sn−Pb PSCs show a PCE of up to 22.7% with a VOC value of 0.894 V, together with improved stability. 3.3.3. Other HTL Modifications. Nevertheless, the longterm stability of mixed Sn−Pb PSCs is largely restricted due to the acidic and hygroscopic nature of the conventional bottom contact, the PEDOT:PSS layer.<sup>383</sup> Finding suitable substitutes is thus critical for ensuring the intrinsic stability of the cell stack.<sup>384</sup> NiOX is the most studied HTL, with the ability to increase the stability of the PSCs compared to the PEDOT:PSS-based devices (Figure 10c-i), maintaining about 

4096 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

91% of its original efficiency at 80 °C for 20 h and 92% of its initial performance after 46 days storage in inert conditions.<sup>385</sup> However, NiOX presents Ni<sup>≥3+</sup> sites and multiple types defects that can induce degradation pathways at the perovskite interface.<sup>386</sup> The insertion of poly[(9,9-bis(3′-(N,Ndimethylamino)propyl)-2,7-fluorene)-alt-2,7-(9,9-dioctylfluorene)] (PFN) successfully passivates these sites, as well as improving the energy level alignment.<sup>69</sup> With this strategy, PSCs with a high VOC of 0.88 V and outstanding stability for the encapsulated cells under ambient conditions can be fabricated. Meanwhile, small polar molecules, such as 4- hydroxyphenethylammonium (OH-PEA<sup>+</sup> ),<sup>387</sup> have also been applied to reduce the defect states of NiOX films and improve the energy level alignment at the buried interface of the PSCs. In these cases, the surfactants generally interact/react with NiOX through the terminal that can bind with the metal center, e.g., −OH,<sup>387</sup> −COOH,<sup>388</sup> −PO(OH)2,<sup>386</sup> −S,<sup>389</sup> etc., to passivate the defects in the NiOX layer (Figure 10c-ii). Then, the opposite terminal of the surfactant points away from the NiOX and to the perovskite material coated above, altering the work function of NiOX and concurrently passivating the defect states of the perovskite layer. In addition, this strategy could also abate the delamination-induced failure of solar cell devices, thanks to the enhanced interlayer interaction.<sup>390</sup> Interestingly, tuning the work function of NiOX can also be realized by modifying its processing conditions, such as the annealing temperature.<sup>391</sup> In comparison with high-temperature-annealed NiOX films, the films processed at room temperature show improved crystallinity and reduced Ni vacancies, leading to a deeper valence band and lower trap densities.<sup>391</sup> 

Despite the evident advantages of the intrinsic chemical properties of NiOX versus PEDOT:PSS, the processed films are generally less conductive and not chemically inert<sup>298</sup> and defect-free.<sup>386</sup> Thus, the community is still constantly looking for some alternative promising organic and inorganic HTLs (Figure 10c-iii, iv)<sup>384,392−395</sup> and hole-selective self-assembled monolayers (SAMs),<sup>396,397</sup> or the best combination of these two. A solution-processed ternary tin(II) alloy (SnOCl) has been proposed as a novel HTL for mixed Sn−Pb PSCs.<sup>74</sup> Due to its textured structure, SnOCl layers provide reduced optical losses in the full device stack. In addition, it induces a wellcontrolled grain growth with the suppressed formation of small grains at the buried interface. The resultant PSCs presented greatly enhanced stability (87% of their initial efficiency retained after 1-sun illumination for 1200 h and 85% under 85 °C thermal stress for 1500 h). Superior efficiencies of 23.2 and 26.3% for the single-junction devices and the all-perovskite tandem cells, respectively, were realized with a mixture of SnOCl and neutral PEDOT, thanks to the improvement in the coverage and work function alignment with the indium tin oxide (ITO) substrate. 

The application of SAMs in Sn-containing perovskites has faced many challenges that have delayed the first reports of their successful implementation, in comparison to the first ones in neat Pb PSCs (Figure 10d-i).<sup>398,399</sup> However, when 2-(9Hcarbazol-9-yl)ethyl]phosphonic acid (2PACz) was blended with methyl phosphonic acid (MPA), mixed Sn−Pb PSCs reached an efficiency of 23.3% and a significantly improved stability, i.e., no loss after 1000 h of constant illumination under inert conditions.<sup>400</sup> Besides matching the energy levels, here, the key to achieving efficient PSCs fabricated on SAMbased FTO substrates is related to improving their coverage 

through the MPA filler (Figure 10d-ii). FTO substrates used are generally textured, which can lead to current leakage and consequently energy loss at the interface. Due to negligible parasitic absorption, SAM-based cells show a large current gain compared to their PEDOT:PSS-based counterparts. Compared with the neat Pb PSCs, however, we find that the SAM-based mixed Sn−Pb PSCs do generally suffer from reduced batch-tobatch reproducibility. This problem has led to very few successful attempts made by a limited number of groups in the Sn-containing PSCs.<sup>400−402</sup> There are several reasons related to this, e.g., (i) unsuitable energy level alignment which will generate severe nonradiative carrier recombination, and (ii) poor coverage of the SAMs on the TCO substrate that will lead to the current leaking and/or detrimental side reactions between the perovskite and substrate. Most of the SAMs developed currently have HOMO levels around −5.6 to −5.9 eV,<sup>396,403</sup> which match the valence band maximum (VBM) of the neat Pb perovskite films but is much deeper than the VBM of most Sn-containing analogues, generally from −5.0 to −5.4 eV,<sup>12,379,404,405</sup> as the energy level of the Sn 5s orbital is shallower than that of 6s of Pb.<sup>172</sup> Therefore, tuning the work function of the SAM-based contact by introducing small binding molecules that canto some extentcompensate for the polarity of the employed SAM is worth pursuing. Furthermore, the development of new SAMs with energetics adjusted to Sn-containing perovskite films is important (Figure 10d-iii).<sup>406</sup> We note that the TCO substrates covered with Me4PACz<sup>403</sup> SAM show exceptionally poor wettability to the perovskite precursor solution, even for the neat Pb-based perovskites with a DMF-rich solvent system (Figure 10d-i).<sup>75</sup> Al2O3 nanoparticles<sup>63,407,408</sup> and/or some ammonium salts<sup>409</sup> as a wetting layer, or 1,6-hexylenediphosphonic acid (6dPA) as a second component to the SAM precursor solution,<sup>75</sup> can be implemented to overcome this wettability issue, enabling solar cells with improved efficiency and reproducibility as well as alleviated film delamination. Thus, an improved understanding of SAM processing, especially the impact from the processing solvent, and the surface chemistry, alongside the design of new versatile<sup>410</sup> and processing-tolerant SAMs, will be key to aiding the community to reach the next milestone on both cell efficiency and reliability.<sup>144</sup> To further simplify the PSCs processing, codeposition of the hole-selective contact and the perovskite absorber would be worth investigating in future work. Taking advantage of the chemical interactions between the bottom bare FTO/ITO substrate and SAMs, SAM molecules introduced directly from the precursor solution system would also guarantee the device with good performance (Figure 10d-iv).<sup>411−413</sup> This strategy would also allow for alteration of the energy level of the perovskite films at the bottom region, creating a bend banding at the buried interface that benefits hole extraction.<sup>413</sup> 

Obtaining efficient PSCs without any hole transport/ selective contact at all should also be feasible once the energy levels are well aligned in the heterojunction,<sup>207</sup> e.g., realized by some particular treatments,<sup>414</sup> and there are no detrimental reactions, e.g., Sn(IV) oxidation,<sup>415</sup> taking place at the interface. Mixed Sn−Pb PSCs stacks without HTL generally present elongated operation lifetimes compared to conventional PEDOT:PSS-based PSCs. HTL-free PSCs capped with a sputtered indium zinc oxide (IZO) electrode are currently one of the most stable mixed Sn−Pb PSCs reported.<sup>207</sup> These PSCs retained 95% of their initial efficiency after 1000 h, at 85 °C in the air under dark conditions without encapsulation as 

4097 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 11. 2D capping. (a) (i) Schematic illustration of the 2D perovskite phase space with boundaries defined by the ACI, RP, and DJ crystal phases (corresponding to alternating cations, Ruddlesden−Popper, and Dion−Jacobson phases, respectively). The coordinates indicate the shift between consecutive perovskite layers along the a and b axes of the 2D perovskite structure. (0, 0) and (1/2, 1/2) correspond to the eclipsed and staggered structures. Crystal structures of (GA)(MA)PbI4,<sup>1</sup> (n-BA)2SnI4,<sup>2,3</sup> and (4AMP)PbI410 shown as an example of the structures of ACI, RP, and DJ perovskite phases, respectively. (ii) Schematic illustration of 2D-capped grain boundaries of the mixed Sn−Pb perovskite films along with the HRTEM image of the grain boundary region of the perovskite prepared with 7% GuaSCN additive. Reproduced with permission from ref 29. Copyright 2019 American Association for the Advancement of Science. (iii) 2D GIWAXS patterns for (t-BA)2(A)(Pb0.6Sn0.4)3I10 (A = FA0.85Cs0.15) films. Reproduced with permission from ref 36. Copyright 2018 American Chemical Society. (b) (i) Schematic illustration of mixed Sn−Pb film surface capped with different low-dimensional phases. The 2L phase formed with the TEASCN treatment shows a lower interfacial energetic barrier than the 1L phase generated with the TEAI treatment. (ii) Molecular structures of the spacers used for modifying mixed Sn−Pb perovskites. (iii) Expanding the low-dimensional perovskite phase library from the Pb-based to the Zn or other metal-based new materials. Reproduced with permission from ref 51. Copyright 2023 Springer Nature. 

well as in a damp heat test with encapsulation. Under operating conditions (0.8 sun was used), the ITO-sandwiched cells with no metal top contact fully maintained their initial efficiency for over 1000 h under inert conditions. This indicates that removing defects and degrading materials at transport layers can greatly improve the performance of the PSCs. 

Different strategies can be employed to improve the buried perovskite surface. Modification or replacement of conventional PEDOT:PSS can avoid the instability issues linked to it. In particular, SAM-based and HTL-free structures recently showed high potential for enhancing device efficiency and stability. On the other hand, we noticed the delamination of perovskite films from SAM-based substrates during the hightemperature annealing, e.g., at 150 °C. This canto some extentbe alleviated by using a thin substrate or preheating the substrate and/or using the SAM molecules that could interact with or chemically bind to the perovskite atop. From a different perspective, the additive GlyHCl proved the ability of specifically functionalized molecules to form large perovskite colloids and primarily sediment on the bottom surface to facilitate charge extraction. Similarly, amino acids or SAMs with −PO(OH)2 or −COOH acid terminals can not only passivate the defects in NiOX and perovskite films but also induce an intentional modification of the bottom region of the films, tuning the energy level and facilitating the hole extraction. These works point out the broad applicability of amino acids for improving the bottom interface in mixed Sn−Pb PSCs, which we believe has a strong potential yet to be uncovered, in terms of structural and mechanistic diversity. Besides the top surface modification mentioned above, Al2O3 nanoparticles show excellent ability to solve the wettability issue for different substrates and passivating the buried interface. This also indicates that modifying both the exposed and buried surfaces of perovskite films using Al2O3 nano- 

particles will boost the performance of the solar cells further. Ideally, a similar function could also be provided by the other analogues, such as SiO2 and ZrO2. We note that the dielectric nature of these nanoparticles will likely cause FF reduction of the cells because of the series resistance loss when increasing the thickness of the interlayer. Thus, a porous insulator contact design<sup>63</sup> was recently developed to mitigate this trade-off effect. These new functionalities will allow the community to target more efficient and robust device structures, particularly with simplified procedures<sup>412</sup> to be easily implemented into large areas and flexible cells.<sup>81</sup> 

### 3.4. 2D Capping 

3D perovskites generally stack with infinite corner-sharing octahedral units, while 2D perovskites form when they cleave along a crystallographic plane, e.g., ⟨100⟩, ⟨110⟩, or ⟨111⟩, to form sheets that are linked with large cations. The properties of 2D perovskites can be easily tuned by changing the layer thickness (defined by the n number), the cage cation, and the spacer cation, resulting in excellent structural diversity. The most common 2D perovskites are the ⟨100⟩-oriented ones, which can be further divided into the alternating cations in the interlayer space (ACI) phase,<sup>1</sup> Ruddlesden−Popper (RP) phase,<sup>416</sup> and Dion−Jacobson (DJ) phase (Figure 11a-i).<sup>10</sup> In the different phases, the inorganic slabs of the 2D perovskites are defined as quantum wells, while the spacer acts as a barrier.<sup>308</sup> Due to the quantum and dielectric confinement effects,<sup>417</sup> 2D perovskites present interesting semiconductor characteristics, such as an increase in bandgap with the decrease of the 2D layer thickness, and the tunability of the exciton binding energy by the dielectric constant of the spacer cation. Due to their high structural formation energy and the hydrophobic nature of the spacer, 2D perovskites also show excellent stability under different stimuli, such as heat and 

4098 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

humidity. However, these 2D phases generally display low carrier mobility, which induces current loss in the devices. As we noted in the above sections, therefore, judicious design is required when using the 2D spaces to cap the grain boundaries and surfaces of the 3D polycrystalline perovskites being employed to fabricate efficient and stable photovoltaics. 

For mixed Sn−Pb PSCs, the most widely implemented spacers are guanidinium (GA<sup>+</sup> ) (ACI-type) and PEA<sup>+</sup> (RPtype), while the DJ-type has been relatively less explored. The ACI-type spacer GA<sup>+</sup> can be used to form 2D-composed grain boundaries with suppressed tin vacancies and enhanced structural stability (Figure 11a-ii).<sup>29</sup> These 2D-capped 3D films show a largely reduced energetic disorder, increased carrier lifetimes, and reduced surface recombination velocity. The resulting mixed Sn−Pb perovskite (Eg = 1.25 eV) singlejunction cells reached > 20% efficiency, as well as 25% for 4-T and 23.1% for 2-T all-perovskite tandem cells. Several groups have since successfully applied GA<sup>+</sup> cations to enhance the performance of PSCs.<sup>418−420</sup> Apart from the potential passivation effects from the three ammonium groups, the authors also claimed that GA<sup>+</sup> cation also offers the possibility of tuning the band structures, generally moving the Fermi level of the perovskite closer to the CBM, due to the reduced background hole density. 

An RP-type 2D or quasi-2D Sn−Pb perovskite, (tBA)2(FA0.85Cs0.15)n−1(Pb0.6Sn0.4)nI3n+1 (n = 2−9, t-BA: t- butylammonium) was first investigated in 2018 for its application in solar cells (Figure 11a-iii).<sup>36</sup> The authors found that perovskites composed of n = 4 2D species display superior ambient stability, presumably owing to the combined suppression of both inherent defects as well as externally (air) induced degradation. Later on, the PEA<sup>+</sup> cation was extensively examined for its exceptional ability to regulate crystal growth and suppress multiple defect states.<sup>281,421−423</sup> In addition, a fluorinated PEA<sup>+</sup> cation, 2-(4-fluorophenyl)ethylammonium (FPEA<sup>+</sup> ), is effective for regulating the 2D/3D mixed phases, causing film formation with a preferential crystal orientation perpendicular to the substrate plane.<sup>424</sup> Unencapsulated mixed Sn−Pb PSCs with FPEA<sup>+</sup> capping showed enhanced stability under both inert and ambient conditions. Aiming to maximize the gain from 2D species, dual spacer cations were also proposed, because of their synergistic complementary effects on the manipulation of crystallization and carrier transport.<sup>425,426</sup> Combining previously discussed PEA<sup>+</sup> and GA<sup>+</sup> spacers,<sup>29</sup> a preferential formation of the n = 2 PEA2GAPb2I7 phase can be induced into the grain surface and the 3D film surface.<sup>426</sup> In comparison to the n = 1 pure 2D structure, n = 2 quasi-2D structures present longer carrier lifetimes and better out-of-plane charge transport. Thus, it enables minimizing the charge recombination and enhancing the charge extraction at the 3D/2D interface. As a result, mixed Sn−Pb PSCs reached PCE values of 22.3% with outstanding VOC values as high as 0.916 V, representing the best values reported for perovskite absorbers with a bandgap of ∼1.25 eV. At the same time, tandem solar cells showed PCE values of up to 25.5%. More importantly, the solar cells presented improved operation stabilities, with over 82% of their efficiency maintained after 1830 h in N2 for the mixed Sn−Pb single-junction cells, and with 80% of the initial efficiency maintained after 1500 h operation in N2 for the 2-T tandem cells. Interestingly, when applying 2-thiopheneethylammonium on top of the asprepared films,<sup>427</sup> a 2L quasi-2D structure can be formed by using an SCN-based salt, which is different from the 1L 2D 

phase generated with the I-based salts (Figure 11b-i). Thanks to the reduced energy barrier at the top interface, the carrier transfer and the performance of the cells fabricated with the 2L capped film were substantially improved compared with the 1L case. Other 2D phases composed with new spacers have also been investigated as capping layers for the 3D bulk perovskites, such as N-(3-aminopropyl)-2-pyrrolidinone and 4-hydroxyphenethylammonium,<sup>428</sup> and the DJ types, p-phenyl dimethylammonium,<sup>429</sup> 3-(aminomethyl)piperidinium,<sup>430</sup> 3,4-dihydroxyphenethylammonium,<sup>287</sup> and 1,4-butanediammonium diiodide (Figure 11b-ii).<sup>431</sup> 

The capping of 3D perovskite films with 2D perovskite phases is a key strategy for achieving perovskite films with improved quality and stability. In addition, the modulation of the spacer and layer number of the 2D phase allows for finetuning of the properties of this layer. Future work should focus on understanding the role that the low-dimensional species play in altering the semiconductor properties of the novel mixed-dimensional perovskite films (Figure 11b-iii).<sup>51</sup> DJ-type species would generally be expected to be more stable than RP-type species, due to the elimination of the weak van der Waals forces between the spacers. However, the stability of DJ phase perovskites also largely relies on the property of the spacer utilized. For example, the DJ phase composed with the spacer 1,4-cyclohexanedimethylammonium (CyDMA<sup>2+</sup> ), with medium rigidity, is more robust to the external stimuli than the DJ phase composed with a spacer having higher or lower rigidity, e.g., phenylenedimethylammonium (PhDMA<sup>2+</sup> ) and hexyldiammonium (HDA<sup>2+</sup> ), respectively.<sup>432</sup> For low-dimensional phases, however, similarly to MA<sup>+</sup> cation,<sup>433</sup> the ammonium spacers may eventually suffer from thermally induced chemical decomposition or reorganization in films.<sup>434</sup> Therefore, more studies on 2D species, especially the DJ type, are needed to achieve more robust mixed dimensional Sn−Pb PSCs. Finally, mixing the spacers<sup>435</sup> to balance the pros and cons of each of them would also be a very promising way to improve the mixed Sn−Pb perovskites for photovoltaic applications. 

### 3.5. Section Summary 

Surfaces in perovskite films are vulnerable sites prone to high defect densities and degradation. Surface modification strategies have proven critical to improving the quality of mixed Sn−Pb perovskite films in p-i-n solar cells. Depending on the specific requirements of each perovskite and device composition, surface treatments can be adapted to selectively improve a certain perovskite surface: (i) The top perovskite surface can be substantially improved with fullerene derivatives and diammonium/diamine molecules, where the bonds established with surface defects play a key role. (ii) Grain boundaries can be modified with functional additives like Lewis bases and ammonium species that can modulate crystallization and passivate defects at the grain surfaces. (iii) For the buried interface, the conventional HTM, PEDOT:PSS, can be modified or substituted with, for example, efficient SAMs, or novel functional molecules as additives that modify perovskite colloids and accordingly the buried interface. (iv) Easily tunable 2D phases can be applied to cap the 3D perovskite domains to enhance their optoelectronic properties and stability profoundly. The knowledge gained through the works discussed here should motivate the community to develop novel passivating agents and device structures that successfully limit surface defects throughout the perovskite 

4099 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 12. Tandem cells. (a) (i) ASTM G173-03 reference solar spectrum. The data was downloaded from NREL. Cell stack of monolithic doublejunction two-terminal all-perovskite tandem solar cells and EQE spectra of the WBG and NBG subcells. The EQE spectrum of the NBG cells was generated with the data published before in ref 9. Copyright 2022 Royal Society of Chemistry. Meanwhile, the EQE spectrum of WBG is unpublished data from our lab. (ii) Efficiency progress of mixed Sn−Pb perovskite-containing all-perovskite tandem solar cells, updated by June 10, 2023. (b) (i) Schematic illustration of the tandem cell stack highlighting the interconnecting layers. The most used interconnection layers have the structure of fullerene/SnOX/Au (ITO)/PEDOT:PSS based on the reported cell data plotted in Figure 12a-ii. (ii) Scanning electron micrograph of a 2T perovskite−perovskite tandem. Reproduced with permission from ref 31. Copyright 2016 American Association for the Advancement of Science. (iii) Schematic illustration of simplifying the interconnecting layers by removing the ITO and PEDOT:PSS layers (left). Energy diagram for the C60/SnO1.76/NBG/C60 layers in all-perovskite tandem solar cells (the full device structure is shown at the bottom) (right). The energy diagram shows that the holes from the NBG perovskite film are injected into the SnO1.76 through the midgap states (orange lines) and then recombine with electrons extracted from the WBG perovskite film by the doped C60 layer. Evac and EF denote vacuum and Fermi levels, respectively. Reproduced with permission from ref 41. Copyright 2020 Springer Nature. (c) (i) EQE spectra for the 1.8 and 1.2 eV subcells. Reproduced with permission from ref 31. Copyright 2016 American Association for the Advancement of Science. (ii) EQE spectra of the best CF3-PA device (with 1.2-μm-thick absorber). Reproduced with permission from ref 8. Copyright 2022 Springer Nature. (iii) J−V, EQE, and total absorptance (1-R) curves of the champion tandem device with perovskite heterojunction. Reproduced with permission from ref 77. Copyright 2023 Springer Nature. (iv) Schematic illustration of the tandem cell stack highlighting the application of low parasitic absorption materials, such as the SAM-based hole selective layer (HSL) and electron selective layer (ESL), and MOX (M = metal) layer. (d) (i) Schematic illustration of the tandem cell stack highlighting the main origin of the stability loss from each device layer. (ii) Continuous maximum power point (MPP) tracking of an encapsulated tandem solar cell over 600 h under simulated AM 1.5G illumination (100 mW cm<sup>−2</sup> , multicolor LED simulator) in ambient air with a humidity of 30−50%. The device had an initial PCE of 27.4%. The device temperature was around 35 °C during operation due to the self-heating under solar illumination. There was no passive cooling during device operation while the environmental temperature was kept at around 25 °C. The plot was regenerated by WebPlotDigitizer 4.6 based on the original graph published in ref 77. Copyright 2023 Springer Nature. Inset shows a cross-sectional SEM image of all-perovskite tandem solar cells highlighting the full lead perovskite capped at the top of the NBG mixed Sn−Pb perovskite films. Reproduced with permission from ref 77. Copyright 2023 Springer Nature. (iii) Bar graphs showing the PCEs of mixed Sn−Pb devices measured in the ambient without (black) and with (orange) SiOX for various ambient exposure times. Reproduced with permission from ref 97. Copyright 2023 Springer Nature. 

films. In parallel, a deeper understanding of the perovskite crystallization process and related defect generation and defect nature would allow better control of the final film quality. The development of enhanced passivation strategies for perovskite surfaces in the future will allow a critical advancement in the 

efficiency and stability of mixed Sn−Pb PSCs, pushing the field 

forward toward commercialization of efficient all-perovskite 

tandem photovoltaics. 

4100 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

## 4. ALL-PEROVSKITE TANDEMS 

Tandem technologies are one of the most promising applications for metal halide perovskite materials (Figure 12a).<sup>24,27,34,37,436,437</sup> Nevertheless, the challenges that allperovskite tandems face are still plenty.<sup>38,438</sup> First, the interconnection layer should have optimal properties to allow holes and electrons from both cells to recombine efficiently. However, the deposition of high-quality layers is complicated and could potentially damage the perovskite material underneath. Second, maximizing the current matching of the two absorbers is not trivial, as the bandgap, thickness, and crystal quality of both perovskite films have to be perfectly optimized for the particular tandem cells. Third, all-perovskite tandems suffer from poor stability largely inherent to mixed Sn−Pb perovskite subcells,<sup>439</sup> caused by, for example, the thermally and photochemically unstable MA<sup>+</sup> content, the oxidation of Sn(II), and the acidity and hygroscopicity of the often used PEDOT:PSS HTL. Finally, the deposition of all of the layers and the upscaling of the process is a complex task that requires careful optimization. In this section, we summarize the limitations of current protocols, the challenges faced by the field, and future promising research directions to enable efficient and stable all-perovskite tandem solar cells. 

### 4.1. Interconnect 

To connect the subcells of the tandem devices, the interconnection layers (ICLs) are indispensable (Figure 12bi). The CRL acts as a medium that collects holes and electrons from the interfaced subcells and allows them to recombine with each other. An efficient interconnecting layer largely determines the shape of the devices’ current density−voltage (J−V) characteristics, which should concurrently possess low contact resistance, high optical transparency, and mechanical/ chemical robustness. Finding a perfect candidate is, however, very challenging. 

For constructing the device, the interconnecting layer is generally composed of ETL(HTL)/conducting layer/HTL(ETL) where the conducting layer is optional occasionally. For instance, in n-i-p tandems, doping the HTL with Li-TFSI and tBP additives greatly improves the efficiency of the tandems stacked with no extra conducting layer.<sup>440</sup> The Li/Li<sup>+</sup> redox shuttle takes the holes and electrons from the subcells to be involved in the reaction, improving the conductivity of the interconnecting layer. The dopant, however, can potentially react with the perovskite materials with the migration of the small ions, e.g., Li<sup>+</sup> , accelerating the device’s degradation or failure. Inert materials are highly preferred in this regard. For example, the less mobile, 2,2′-(perfluoronaphthalene-2,6diylidene (F6-TCNNQ) dimalononitrile) and N<sup>1</sup> ,N<sup>4</sup> -bis(tri(ptolyl)phosphoranylidene)benzene-1,4-diamine (PhIm) dopant are used to dope N<sup>4</sup> ,N<sup>4</sup> ,N<sup>4</sup> ′′,N<sup>4</sup> ′′-tetra([1,1′-biphenyl]-4-yl)[1,1′:4′,1′′-terphenyl]-4,4′′-diamine (TaTm) and C60, respectively, serving as the extra charge selective layer between the half cells in the p-i-n tandem architecture.<sup>441,442</sup> In addition, these dopants can be deposited with a vacuum-based thermal deposition method, avoiding the air exposure of the subcell fabricated at first and the use of the solvent that is generally harmful to the environment. These doped extra layers, however, likely cause a considerable increase in the fabrication cost of tandem photovoltaics and introduce additional parasitic absorption/detrimental interfacial carrier recombination that limits the efficiency of photon conversion. 

Thanks to the low production cost, low absorption, and high stability, ALD-grown thin, while compact, layers of metal oxide materials, such as Al2O3, ZnO, SnO2, and TiO2, are broadly implemented (Figure 12b-ii) to reduce the damage to the front perovskite absorber from the solvent-mediated processing of the second subabsorber.<sup>443</sup> To increase the ohmic contact, extra material(s) are then deposited above the metal oxide(s), e.g., metal Ag or Au (generally of about 1 nm thickness and hence forming noncontinuous nanoparticles),<sup>8,426,444,445</sup> or sputtered-ITO,<sup>31,446</sup> indium zinc oxide (IZO),<sup>397</sup> and aluminum-doped zinc oxide (AZO).<sup>84,447</sup> However, these materials commonly introduce parasitic absorption that increases with the thickness, and the metals potentially penetrate through the layers and react with the perovskite material;<sup>448,449</sup> moreover, additional layers also increase the device processing complexity. Accordingly, they cause cost increases, loss in the energylifetime yield, and longevity reduction of the tandem PVs. Thus, a metal-free CRL is recommended.<sup>41,450</sup> The direct contact of ALD-SnO2 and PEDOT:PSS (in p-i-n structure) generally leads to s-kinks in the J−V curves, due to the formation of a Schottky barrier. To overcome this, it is pivotal to control the properties of the deposited metal oxide and develop bifunctional layers that allow direct contact with the perovskite.<sup>446</sup> A single layer would need to collect both electrons and holes from opposite sides; therefore, the ambipolar carrier transport property is required. To this end, increasing the defect density of the ALD-SnOX would help to improve the carrier density and thus conductivity of the layer (Figure 12b-iii). Lowering the content of Sn(IV) in SnOX can accordingly increase the density of Sn(II) in the layer, which induces middle-gap energetic states that attract charge carriers.<sup>41</sup> In addition, intentionally creating defect states by controlling the pulse length of the SnOX precursorse.g., tetrakis(dimethylamino)tin and deionized water<sup>450</sup> allows for fabricating layers with desired carrier concentration and sufficiently low contact resistance. 

From the chemistry aspect, there is still much room for modifying the properties of the ALD-SnOX layer. Searching for new superior MOX (M = metal) layers, or developing nucleation media that allow growing the CRL conformally and efficiently, is a critical step for the further improvement of tandem photovoltaics, specifically for flexible devices.<sup>84</sup> The interconnecting layer also affects the output voltage of the tandem cells. It is potentially caused by the detrimental interfacial recombination generated at the perovskite interface contacts with ETL/HTL. In principle, the approaches that reduce interfacial recombination in single-junction cells will also be effective in tandem devices sharing the same contact.<sup>451</sup> Overall, a simple yet effective charge recombination architecture for advancing the performance of all-perovskite tandem devices is highly demanded. So far, the ICLs have been largely limited with very thin (ALD-SnO2/Au/PEDOT) or wrong refractive index (ITO) materials. Developing conductive, red and near IR transparent and higher refractive index interlayers is an important future direction. 

### 4.2. Current Matching 

In the monolithic configuration, where all subcells are connected in series, the current through the different subcells is ideally the same, while their voltages are added. Therefore, good matching of the current generated by the two subcells is crucial for maximizing their operating performance. 

4101 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

In general, the output current of PSCs is largely associated with the bandgap of the perovskite absorber. As vastly examined, the ideal match of the subcell in monolithic double-junction two-terminal tandem PVs is ∼1.2 and ∼1.8 eV absorbers for the NBG rear and WBG front cells, respectively (Figure 12c-i).<sup>31,452</sup> The bandgap increases with the amount of I<sup>−</sup> substituted by Br<sup>−</sup> ion at the X-site of the neat Pb perovskite films,<sup>453</sup> owing to the influence of the anion electronic states.<sup>454</sup> For the WBG subcells, thus, the composition with the I/Br ratio around 3/2 gives the neat Pb perovskite with a bandgap of ∼1.8 eV.<sup>453</sup> Meanwhile, the single accessible way currently to lower the bandgap down to ∼1.2 eV is the B-site substitution, i.e., a certain amount of Pb(II) replaced by Sn(II) cation, thanks to the anomalous bandgap bowing effect.<sup>236</sup> To reach a bandgap as small as ∼1.2 eV, the Sn/Pb ratio would be close to 1/1, as given by most of the reports.<sup>31,251,455</sup> 

With the ideally matched bandgaps, maximizing the output current still requires further optimization. For example, it can sometimes be realized by optimizing the thickness of the subabsorbers. Reducing the thickness of the WBG absorber would allow more midenergy photons to escape from the front subcell and accordingly be absorbed by the rear subcell. As for the NBG absorber, a thickness over 1000 nm would be required to generate the current that matches the current generated from the WBG subcell (Figure 12c-ii, iii). However, increasing the thickness of the NBG mixed Sn−Pb perovskite films generally leads to lower performances, due to the insufficient carrier lifetime and diffusion length. Therefore, strategies to improve the current match by enhancing the quality of thick mixed Sn−Pb perovskite films have been extensively investigated.<sup>8,29,185,330,332,426,452,456</sup> Usually, the big grain size in polycrystalline films indicates good perovskite quality and, thus, long carrier lifetime and diffusion length as well. Some strategies to improve the quality of the films involve retarding the crystallization of the films by, for example, slowing down the release speed of the solvent from the wet intermediate-phase perovskite films<sup>31,456</sup> or introducing halide or pseudohalide ions in the process.<sup>29,457,458</sup> However, films with big grain sizes do not always give high output current of the cell, as it also associates with their crystallinity and orientation. Films with <100>-dominated orientation generally show higher carrier mobility; thus, manipulating the crystal growth to make the film oriented with the face possessing the highest carrier mobility is also equally critical. Generally, this can be realized by changing the processing method<sup>459</sup> and/or introducing some specific additives<sup>154,305</sup> or low-dimensional spacers<sup>459,460</sup> to regulate the crystal growth. As we introduced above, in addition, the unintentional p-doping caused by the Sn(II) oxidation and abundant defect states raised by the imperfect surfaces also shorten the carrier lifetime of the films even with big and well-oriented grains. Using antioxidants,<sup>44</sup> reducing agents<sup>185</sup> or ionic dopants<sup>330,332</sup> to alleviate the p- doping and surfactants<sup>8</sup> to passivate the surface imperfections would effectively elongate the carrier lifetime of the mixed Sn−Pb perovskite films, consequently eliminating the current mismatch of the tandems. Alternatively, light trapping engineering would also contribute to extending the light absorption for the rear subcell. For example, embedding a light-scattering micrometer-sized particle layer into a perovskite to trap light effectively increases absorptance in the infrared region.<sup>42</sup> Composing the subcells with the films having big grains, desired orientation, elongated carrier lifetimes, and 

extended light traveling path would be beneficial for the current matching in tandems. 

From the CRL side, materials with low absorbance would allow more photons to penetrate through and get absorbed by the rear NBG absorber (Figure 12c-iv), thus refining the current match of the resultant tandem devices. For instance, the absorption coefficient of poly(3-hexylthiophene-2,5-diyl) (P3HT) is higher than that of poly[bis(4-phenyl)(2,4,6trimethylphenyl)amine] (PTAA) in the visible light range;<sup>440,461</sup> thus, it will decrease the number of the photons absorbed by the rear subcell of the corresponding n-i-p tandem cells. Currently, the most employed CRL is composed of ALDSnO2 sandwiched charge selective layers. Given the p-i-n structure as an example, C60 or PCBM/SnO2/Au or ITO or IZO/PEDOT:PSS is the most tested combination (refs 8, 15, 32, 44, 70, 90, 185, 305, 307, 330, 332, 339, 397, 444−446, 456, 458, 460, 462−466) even for the multijunction cells.<sup>93,101</sup> Further simplifying the structure will reduce the parasitic absorption of the CRL layer as we discussed in section 4.1, and accordingly, ameliorate the current match in tandems. As for the charge selective layers, we need to search for more transparent alternatives, even though the absorption of C60 and PCBM is mainly in the UV−vis region where a multi-junction cells could be affected.<sup>467</sup> In this regard, we anticipate a huge potential of using hole/electron selective SAMs or evaporable fullerene derivatives with binding moiety<sup>468</sup> as this will also possibly solve the delamination issue caused by the weak interaction between the perovskite and charge selective layers, especially the C60 layer.<sup>469</sup> However, compared with the holeselective SAMs, electron-selective SAMs are less developed.<sup>449</sup> In addition, hole-selective SAMs that allow the fabrication of the Sn-containing PSCs with high efficiency and reproducibility are still largely missing because of various reasons we discussed above (with more details that we recently summarized<sup>144</sup> ). This would ask for more efforts from the community, especially from the chemistry aspect. On the other hand, an extra gain on the output current could be realized by properly introducing antireflection materials out of the cell<sup>70,470</sup> or even out of the encapsulation glass.<sup>471</sup> Additionally, moving from two-terminal to four-terminal tandems<sup>452,472</sup> would face no current mismatch issues but would imply needing to manufacture two separate tandem modules and then to laminate them together. 

### 4.3. Device Stability 

Stability is key to realizing the practical application of efficient perovskite photovoltaics. As for all-perovskite tandems, the quality of every layer matters to the operational life of the devices (Figure 12d-i). In this section, we mainly discuss the subcells in all-perovskite tandems, while leaving the rest of the discussion on stability to already published focus reviews.<sup>37,473−475</sup> 

The operational stability of both the WBG and NBG perovskite subcells still requires significant improvement for these tandems to become commercially viable. The WBG subcells often suffer from halide segregation, which leads to increased charge transport and open-circuit voltage losses, resulting in lower PCEs.<sup>476</sup> Strategies such as compositional, interface, and additive engineering have been successfully employed in an effort to increase the operational stability of these WBG subcells.<sup>477,478</sup> Furthermore, thermally induced phase control has been shown to reduce defects and prevent halide segregation, leading to strongly improved device 

4102 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 13. Trends and different device architectures. (a) (i) Schematic illustration of the architecture of the all-perovskite tandem solar cell with both WBG and NBG subabsorbers fabricated with the EDAI2 post-treatment. The WBG front absorber was fabricated with thermal evaporation.<sup>5</sup> (ii) Schematic illustration of hybrid evaporation-solution fabrication route with the inorganic and organic materials deposited by the vacuum-based thermal evaporation and solution-based spin coating or blade coating. (iii) Schematic of hot gas-assisted blade coating applied for the NBG mixed Sn−Pb perovskite subabsorber fabrication. Reproduced with permission from ref 15. Copyright 2022 Springer Nature. (iv) Schematic of hot gasassisted blade coating applied for the WBG neat Pb perovskite subabsorber fabrication. Reproduced with permission from ref 32. Copyright 2022 American Association for the Advancement of Science. (b) (i) Schematic illustration of the superstrate and substrate cell configuration. (ii) Sketch of light absorption in a bifacial all-perovskite tandem device with additional albedo light (top). Equivalent efficiency distribution of 15 bifacial tandems fabricated in the same batch with 1.78 and 1.65 eV WBG top cells under illumination with 30% of albedo light (bottom). Reproduced with permission from ref 42. Copyright 2022 American Association for the Advancement of Science under a Creative Commons Attribution NonCommercial License 4.0 (CC BY-NC). (iii) Operating stability of unencapsulated superstrate- and substrate-configured tandems. The encapsulated device retained 100% of its initial efficiency after 600 h of operation. All tests were carried out under 1-sun illumination (100 mW cm<sup>−2</sup> ) and maximum power point tracking. The plot was generated by WebPlotDigitizer 4.6 based on the original graph published in ref 70. Copyright 2023 Springer Nature under a Creative Commons Attribution 4.0 International License. Inset: Cross-sectional SEM image of the edge of a substrate-configured tandem. Reproduced with permission from ref 70. Copyright 2023 Springer Nature under a Creative Commons Attribution 4.0 International License. (c) (i) Optical image showing an array of flexible single-crystal photovoltaic islands with a total working area of 6.25 cm<sup>2</sup> (0.5 cm × 0.5 cm × 25). Inset: Cross-sectional SEM image of the single-crystal perovskite photovoltaic device (left). Cycling test results of the graded photovoltaic device at r ≈ 5 mm. Inset: J−V curves at different bending radii (right). Reproduced with permission from ref 81. Copyright 2020 Springer Nature. (ii) Schematic depicting AZO growth on C60 and PEIE-treated C60 surfaces. Transmission electron microscopy images of 5 nm C60/4 nm AZO and 5 nm C60/PEIE/4 nm AZO showing differences in AZO structure at the C60 interface with fast Fourier transform insets to highlight differences in crystallinity. Reproduced with permission from ref 84. Copyright 2019 Elsevier. (iii) Bending tests of flexible tandem cells based on NiO and MB-NiO with a bending radius of 15 mm. The initial PCEs of flexible tandem cells based on NiO and MB-NiO are 22.0% and 24.6%, respectively. Inset: Digital image and device structure of a flexible tandem cell under bending. Reproduced with permission from ref 90. Copyright 2022 Springer Nature. (d) (i) Schematic illustration of the device stack showing the double- and triple-junction tandems. (ii) Device configuration of 1.99 eV/1.60 eV double-junction cell and schematic diagram of PTAA and NiO/PTAA layers spin coated on the front subcell. Reproduced with permission from ref 93. Copyright 2020 American Chemical Society. (iii) Triple-junction device configuration and EQE spectra of 1.73, 1.57, and 1.23 eV subcells in a triple-junction device with C60/SALD-SnO2/Au/PEDOT:PSS ICLs. The JSC was obtained by integrating with the AM 1.5G spectrum. Reproduced with permission from ref 100. Copyright 2020 Springer Nature under a Creative Commons Attribution 4.0 International License. (iv) Schematic diagram of device structure and J−V curves of reverse and forward scans for champion all-perovskite triple-junction tandem cells. Reproduced with permission from ref 101. Copyright 2023 Springer Nature. 

4103 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

stability.<sup>479</sup> Finally, the use of ionic liquids has been demonstrated to effectively stabilize the perovskite phase and make it less susceptible to environmental stresses.<sup>447,480</sup> We herein also suggest the readers take a look at the focus reviews on the stability of WBG subcells published recently.<sup>481</sup> 

The evident loss in the durability of the all-perovskite tandems largely comes from the severe MA<sup>+</sup> reliance of the perovskite composition, especially in the NBG subcell. In many studies, a mixed Sn−Pb perovskite film with good quality generally requires the MA<sup>+</sup> content to be no less than 30% of the A-site component.<sup>12,29,146,185</sup> Involving MA<sup>+</sup> cation in the A-site improves the crystallinity of the films, while its volatile nature recedes durability,<sup>482</sup> especially under thermal stress<sup>210,483</sup> and light soaking.<sup>484</sup> Lowering the MA<sup>+</sup> content while maintaining the mixed Sn−Pb perovskite films with superior quality is challenging, however, as the crystallization process is relatively hard to control compared to the neat Pb analogues. For example, decreasing the MA<sup>+</sup> cation down to 10% will imply changing the fabrication process with the addition of a crystallization modulator to maintain/improve the film quality.<sup>459</sup> In the MA-free system,<sup>154,228,446,485</sup> the PCE of the cells is generally lower than the films containing MA<sup>+</sup> cation.<sup>9,281,400</sup> Interestingly, the addition of Rb<sup>+</sup> cation in the MA-free mixed Sn−Pb perovskite films seems to effectively increase the film quality in terms of defect density and carrier lifetime.<sup>228,486</sup> The origin behind this is, however, yet to be fully understood, for example, from the view of solution chemistry, since increasing the content of the inorganics most likely varies the colloidal properties of the precursor solution. We believe that the MA-free mixed Sn−Pb PSCs will ultimately outperform the MA-containing counterparts, while more understanding of the crystallization and the solution chemistry is required. Moreover, PEDOT:PSS also induces instability due to its notorious acidity and hygroscopicity.<sup>383</sup> A PEDOT:PSS-free structure,<sup>207</sup> and using modified PEDOT<sup>42,465,487</sup> or all-SAM based structure,<sup>488</sup> should be explored in all-perovskite tandems. Therefore, we think that, with the combination of optimal cell structure and dimensional and surface engineering for the films,<sup>29,44,426,459,485</sup> the MAfree system with environmentally friendly processing protocols will dominate future studies. These aspects can also be applied to the stability enhancement of the WBG neat Pb subcells in tandem devices.<sup>32,339,397,445,462,466,489</sup> Based on the literature, the currently reported record efficiency for monolithic allperovskite tandem cells is 28.5%, and more importantly, the cells showed promising stability as well, with 93% initial PCE being retained after 600 h MPP (maximum power point) tracking under simulated one-sun illumination at around 35 °C (Figure 12d-ii).<sup>77</sup> 

Under ambient conditions, on the other hand, stability loss mainly happens due to the loss of Sn-based content. Therefore, developing in situ and ex situ encapsulation techniques is highly important (Figure 12d-iii). Room temperature nondestructive encapsulation<sup>490</sup> that allows PSCs to endure the damp heat and high-temperature light soaking test would be the long-standing pursuit. Changing the cell structure from the conventional superstrate to the substrate configuration together with depositing the mixed Sn−Pb perovskite films beforehand would allow the robust neat Pb films to act as an in situ encapsulant. As proved by Wang et al., this kind of tandem can even endure air exposure for up to hundreds of hours.<sup>70</sup> The ex situ encapsulation is even more crucial considering its ability to improve the robustness of the whole device.<sup>491</sup> 

Interestingly, it was found that the tandems implemented in space show high proton irradiation robustness,<sup>213</sup> suggesting its promising potential for satellite and space exploration applications.<sup>492−494</sup> Before that though, the community still needs to develop new robust materials/techniques that would guarantee the device to be able to sustain atomic oxygen, high vacuum, and large temperature variations.<sup>97</sup> 

The stability of a mixed Sn−Pb single junction and the corresponding tandem cells under operational conditions is lagging when compared to the sharp efficiency increase, restraining their further development and application.<sup>495</sup> This requires further study to understand the degradation mechanism of mixed Sn−Pb perovskites and the influence of the perovskite composition and the device architecture, especially in the tandem device. 

### 4.4. Trends and Different Device Architectures 

Besides standard, solution-processed two- or four-terminal allperovskite tandem solar cells, which currently dominate the field, there are also developments beyond these standard devices, in terms of both deposition methods and different device architectures. An overview of recent attempts can be found below. 

4.4.1. Deposition Methods and Modularization. As for single-junction PSCs, one of the major challenges for allperovskite multijunction solar cells lies in the upscaling of device fabrication. The fabrication of commercially viable perovskite multijunction cells requires deposition techniques that can provide a homogeneous film formation at high throughput rates. To tackle this issue, several approaches have been applied, with varying success rates. 

Evaporated perovskite multijunctions might be the most promising candidate for upscaling, with a recent report of record efficiency of 24.1% for two-terminal all-perovskite tandem cells with vacuum-deposited WBG perovskite films (Figure 13a-i).<sup>5</sup> The NBG perovskite films, however, were deposited from the solution-based process. Several attempts have been previously made to deposit mixed Sn−Pb perovskites through vacuum deposition,<sup>258,496,497</sup> with the ultimate goal to fabricate all-perovskite multijunction solar cells where both subcells are deposited through vacuum-based deposition methods. However, the quality of the mixed Sn−Pb perovskite films still needs to be improved, with bulk recombination currently being one of the major limiting factors. This is likely because, on the one hand, the route has less ability to allow for maximizing the effect of the key additives, such as SnF2, and, on the other hand, controlling the perovskite stoichiometric composition as precisely as in solution-based methods is increasingly challenging. The difference in the physicochemical properties of the organic and inorganic perovskite precursor materials causes severe crosstalk of the materials in the codeposition procedure. Thus, like for solution-based processing, the two-step (sequential) deposition method<sup>498</sup> would also apply to the vacuum-based process, with the organic precursor material(s) deposited after the inorganic(s). Moreover, the hybrid evaporation-solution method<sup>499−501</sup> would allow the ready addition of various additives into the perovskite films while avoiding the usage of toxic solvents, such as the extensively employed amides and ureas (Figure 13a-ii). In this method, the inorganics are deposited first by the solvent-free vacuum-based deposition method. Then the organic precursor material(s), together with some organic additives, are processed with an environmentally 

4104 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

friendly solvent, such as isopropanol. Thus, this will also overcome the issue of dissolving the underlying perovskite films in the tandem cell fabrication procedures, as it will only rely on the alcohol-based solvent(s), while the usage of polar solvents, DMF and DMSO, will be unnecessary. The application of these methods, however, is yet to be widely examined for both the single-junction mixed Sn−Pb PSCs and the corresponding all-perovskite tandems. 

Blade coating is another promising deposition technique, which was successfully employed recently<sup>15,32</sup> to fabricate highly efficient monolithic all-perovskite tandems, where both subcells were fabricated through this method (Figure 13a-iii, iv). Previous attempts mainly focused on fabricating the WBG subcells through blade coating, while still making use of spin coating for the thicker, more challenging to produce NBG subcells. One alternative sustainable processing route would be the adaptation of the hybrid evaporation-solution method, with the inorganics processed through the vacuum-based method while depositing the organic materials with solution-based blade coating. 

Unlike small-area PSCs, perovskite solar modules require a three-step laser or mechanical scribing (namely, P1, P2, and P3) to connect the subcells in series.<sup>32,502−505</sup> Therefore, besides advancing the large-area deposition methods, the modularization of all-perovskite tandems requires more technological advancements toward better design of the module structures and fabrication controls for minimizing the cell-to-module efficiency and stability gap. For example, the material interdiffusion between subcells and the reaction of halides and metal electrodes at the interconnecting areas of the modules has been a long-standing issue that raises severe loss of the device’s stability.<sup>32,506</sup> Although some chemically inactive barrier materials can, to some extent, suppress the material interdiffusion in the module,<sup>32,506</sup> it is generally accompanied by a reduction in the geometric FF of the modules due to the increased dead area. In general, the studies on the modularization of all-perovskite tandems are very limited,<sup>15,32,444,507</sup> with the leading PCEs of no higher than 24%, lagging far behind the lab-based small-area cells. This suggests the pressing necessity for the further development of both large-area deposition methods and modularization technologies. We thus expect more efforts from both the academic and industrial communities regarding the modularization of the all-perovskite tandem PVs in the near future. 

4.4.2. Bifacial Devices. Bifacial devices are generally fabricated in such a configuration with the light that the light can reach the device from both sides to generate free charge carriers simultaneously in both subabsorbers (Figure 13b-i).<sup>508</sup> This substrate cell structure would also be more realistic considering the installation ground,<sup>509</sup> which generally reflects light. Thanks to the extra use of the reflected light, the bifacial tandems would generate more output power under the same irradiation compared to the monofacial counterparts and have mostly no current matching issue, especially when the ground has a high albedo.<sup>464</sup> In addition, bifacial configurations would be industrially more promising with bifacial modules expected to account for a 55% share of the global PV market by 2031.<sup>510</sup> The scientific research made on the development of bifacial allperovskite tandems is very limited, however. 

The tandems with substrate configuration can be fabricated through (i) the lamination of two single subcells or (ii) the sequential deposition of the layers stacked on. In the first method, two subcells with HTL and ETL layers are first 

fabricated separately with the glass-based substrate, and then, the subcells are mechanically laminated.<sup>440</sup> For the second method, which is also the currently most employed method, all the layers with different functions are deposited sequentially with the transparent electrode ending on the top.<sup>511</sup> 

The bifacial-orientated tandems can be fabricated beginning with either the WBG or the NBG subcells.<sup>442</sup> Meanwhile, the substrate-oriented devices could potentially be fabricated on a large variety of opaque and inexpensive substrates,<sup>70</sup> such as plastic and glass foils, for building/vehicle-integrated PVs.<sup>512</sup> Highly flexible deposition routes would allow more freedom in the device design, thus likely reducing the fabrication cost of the solar panels further. 

According to the limited attempts made so far, the best equivalent efficiency reported for the bifacial two-terminal double-junction all-perovskite tandems has reached 29.3% (with 30% of albedo light) (Figure 13b-ii),<sup>42</sup> which is higher than the highest result published in the literature with the superstrate-oriented monofacial device, 28.5%.<sup>77</sup> This suggests the exceptionally high potential of the bifacial tandem devices. From the stability aspect, the substrate-oriented tandems also outperform the superstrate analogues under both inert and ambient conditions (Figure 13b-iii).<sup>70</sup> In this structure, the interconnecting and WBG perovskite layers are deposited sequentially above the NBG mixed Sn−Pb perovskite films. In this sense, the reactive species, such as the metal from the interconnecting layer and the halides from the WBG neat Pb perovskite films, will hardly reach the mixed Sn−Pb perovskite films underneath thanks to the protection by the ALD-SnO2 layer deposited above. Accordingly, the unencapsulated tandem devices can operate even over 250 h with no efficiency loss, substantially greater than the superstrate-oriented tandems tested under the same condition, i.e., with almost no efficiency retained in 20 h of continuous operation.<sup>70</sup> Moreover, the utilization of the reflected light would also allow us to reduce the bandgap of the WBG subcell while maintaining a good match of the current between two subcells,<sup>42,464</sup> meaning a reduction of the Br content at the X-site of the composition. Accordingly, this will reduce the extent of the halide segregation that normally causes instability.<sup>476</sup> The bandgap of the WBG subcell can be reduced from the commonly optimized 1.78 eV down to 1.65 eV by reducing the amount of Br ions at the X-site while providing the bifacial cells with considerably enhanced performance.<sup>42</sup> As demonstrated by these pioneering works, we think the community should pour more effort into the development of all-perovskite tandems with substrate configurations that are applicable for bifacial operation and, meanwhile, should also build a thorough reporting standard that would allow comparisons of the cell efficiencies. 

4.4.3. Flexible Devices. Besides rigid PSCs, flexible devices, both single junctions as well as multijunctions, have interesting applications, for example, in aerospace, vehicleintegrated photovoltaics, and wearable electronics.<sup>512</sup> Furthermore, they would allow roll-to-roll processing, enabling efficient scale-up, as well as easy installation of the modules with decreased package weight.<sup>513</sup> Although processing the NBG perovskite on flexible substrates comes with additional challenges,<sup>514,515</sup> most research efforts in the direction of flexible all-perovskite tandem devices focus on resolving issues with the WBG subcells and the interconnect.<sup>84,90,516</sup> This thus calls for further investigation into the fabrication of high- 

4105 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

quality flexible NBG perovskite films in the community (Figure 13c).<sup>81</sup> 

4.4.4. Triple-Junction Tandems. With the development of all-perovskite tandems, multijunctions with more than two junctions are attracting more and more attention (Figure 13di).<sup>240,517</sup> In principle, the higher energy yield can be readily realized by increasing the absorbers stacked in the tandems, if optical losses related to charge extraction and interconnecting difficulties can be overcome. Every additional junction will introduce optical losses due to the requirement to enable electron−hole recombination between every subcell. As demonstrated with extremely high EQE spectra for Si subcells in perovskite-on-silicon tandems, however, the optical losses with each additional subcell should be able to be mitigated to around 1%, with the appropriate optical design and management. Therefore, ultimately multijunction perovskites with four or five junctions should prove to deliver the highest efficiency and highest energy yields.<sup>39</sup> It is our view, however, that for terrestrial applications surpassing three junctions will be unlikely, but this does give the realistic opportunity to realize close to 40% efficient PV cells.<sup>24</sup> Importantly, when scaling up from two to three junctions, the NBG subcell does not need to be altered much, and insights into processing can be directly transferred from NBG subcells into multijunction tandems (Figure 13d-ii, iii, iv). The main challenge currently lies with the development of efficient front WBG subcells suitable for triple junctions, which implies bandgaps of over 1.9 eV.<sup>93,100,101</sup> Although this is an important area for future research, this goes beyond the scope of the current Review, and we refer the reader to recent publications of PSCs with bandgaps of over 1.9 eV and triple-junction tandems.<sup>93,100,101,518</sup> In addition, we expect more advancements in perovskite materials with an even wider bandgap to promise the success of tandem solar cells with the junction over three, e.g., quadruple-junction devices. 

### 4.5. Section Summary 

Overall, all-perovskite tandem solar cells have a huge potential for efficient and cheap photovoltaic applications in all kinds of environments. The possibility to tune perovskite film properties through its composition allows for maximizing power generation by combining a WBG and an NBG material in a tandem junction. However, the current performance of these devices is still far from their maximum potential. The main challenges and the strategies with the strongest potential to overcome them are as follows. (i) Current interconnecting layers have parasitic absorption, potentially react with perovskite materials and have a fragile fabrication process. The development of new interconnecting layers and tighter control of the deposition process would reduce the contact resistance, increase its transparency and avoid unwanted chemical reactions at the interfaces. (ii) Fully optimizing the current matching of the two WBG and NBG absorbers requires precise control of the bandgaps and thicknesses to ensure capturing all photons of specific energies. However, the high Br- content in WBG and Sn(II) content in NBG perovskites introduce further difficulties regarding their crystallization into compact and highly crystalline films. In particular, the insertion of Sn(II) in the structure strongly accelerates the crystallization process of the perovskite, making it hard to produce homogeneous and thick (>1000 nm) mixed Sn−Pb perovskite films. To this end, a deeper knowledge of Sn-containing perovskite crystallization is required, in order to develop novel 

strategies that can ensure high-quality thin film production (see section 2.1). In addition, conventional ETMs and HTMs absorb part of the spectrum, reducing the total amount of light that can be captured by the perovskite absorbers. We highlight the potential of SAM-modified contacts to avoid this problem and enhance device efficiency. (iii) Achieving long-term stability is a must in order to commercialize this type of device. The current obstacles for all-perovskite tandems in this direction are mostly linked to the NBG absorber. Mixed Sn−Pb perovskite devices normally suffer failure from loss of their MA<sup>+</sup> and Sn(II) content; in addition, the acidic PEDOT:PSS and delaminating C60 layer make these compositions and cells even more unstable. Thus, we anticipate the future potential of MA-free mixed Sn−Pb perovskites for NBG absorbers stacked with optimal charge selective SAMs, in combination with advanced encapsulation techniques for the protection of the material against environmental factors. (iv) Thermal evaporation of the whole tandem fabrication would be desired for its upscaling. However, it is hard to obtain layers of the same quality as with solution-based methods. Here, the optimization of thermal evaporation processes, together with the development of hybrid fabrication methods, i.e., combining thermal evaporation- and solutionbased methods, would help maintain a high film quality while advancing toward upscaling. (v) Finally, bifacial, flexible, and triple-junction devices still need to be developed to enable the full applicability of all-perovskite tandem solar cells. 

## 5. SUMMARY AND FUTURE OUTLOOK 

### 5.1. Summary 

The performance of perovskite optoelectronic devices is highly affected by the nature of the different surfaces present in perovskite films and devices. Grain boundaries and interfaces of low quality will inevitably increase nonradiative recombination and hinder charge transport and extraction. For the particular case of Sn-containing perovskites, such as mixed Sn−Pb, surfaces are of exceptional concern. Sn-based perovskites suffer from higher defect densities, due to challenges with controlling crystallization and the tendency of Sn(II) to oxidize. In addition, mass loss mechanisms and ion movement phenomena in these Sn−Pb perovskites further complicate their development. Nevertheless, mixed Sn−Pb perovskites hold formidable potential for applications in both singlejunction and tandem solar cells. 

Reports in the literature present different methods to address the fragile surfaces in Sn-containing perovskites. On the one hand, controlling the crystallization process and preventing the oxidation of Sn(II) in the material allows for the fabrication of thin films with higher intrinsic quality and lower defect densities. On the other hand, different additives and treatments can be applied for the passivation of imperfect surfaces. Fullerene derivatives, Lewis bases, and ammonium species, properly functionalized to control their properties, are so far the most successful surface modification agents. While similar strategies have been successfully applied for neat Pb perovskites, Sn-containing perovskite films can particularly benefit from surface passivation strategies, considering their particularly defect-rich and imperfect character. The implementation of these surface treatments has allowed the community to quickly improve the efficiency and stability of mixed Sn−Pb PSCs. 

4106 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

Mixed Sn−Pb perovskites, when properly designed and processed, have shown excellent performance when implemented in all-perovskite tandem solar cells as the NBG rear absorber. However, fabricating a good all-perovskite tandem requires further efforts than obtaining a high-quality NBG. In particular, we should pursue good current matching between the NBG and the WBG to maximize the current generation, a good interconnecting layer to allow charges to recombine efficiently while maximizing forward transmission of light into the NBG absorber, a proper cell design that avoids degradation processes, and further development of the fabrication protocols and device structures. Reaching these objectives would enhance the future applicability and commercialization of allperovskite tandem solar cells. 

### 5.2. Future Outlook 

While excellent efficiencies of over 23% and 29% have been achieved for mixed Sn−Pb single-junction PSCs and allperovskite tandems, respectively, there is still a lot of progress to be made in terms of reproducibility, compositional and device structure engineering, and device stability. We underline the urgency for developing novel, simple processing protocols that reduce the number of defects and mobile ions generated in the perovskite films. Tracking the crystallization dynamics and understanding how the solvents or potential additives affect the perovskite colloids and the crystallization process will be a critical step forward. In particular, future studies should unravel the different crystallization dynamics between Sn and Pb, and how they are involved in the generation of metal distribution heterogeneities in the final perovskite films. In particular, techniques that can distinguish between Sn and Pb, such as hyperspectral imaging and nanofocused WAXS, can be excellent tools for evaluating the homogeneity of the mixed Sn−Pb films. 

Tracking the generation and evolution of defect and mobile ion densities as well as understanding oxidation processes better may reveal new ways to mitigate ion migration and other degradations. The community should seek new methods to identify the defects and understand the characteristics and differences between them. Furthermore, new materials and methods should be developed for robust surface defect passivation. In particular, new studies should focus on the strengthening of the Sn−I bond, for instance, by altering the chemical environment or introducing new anions to bind Sn strongly at the weak points, such as surfaces. Alternatively, developing single-crystal PSCs would greatly reduce the defect density in the perovskite films and strengthen the robustness against degradation. 

Finally, the community should bridge the gap between labscale research and commercialization of mixed Sn−Pb perovskite-based optoelectronic devices via, for example, vacuum-based thermal evaporation and green solvent-based, two-step hybrid evaporation-solution deposition assisted by blade coating. To improve the current matching and durability of the NBG absorber materials, we highlight the need for tighter control of the crystallization and new perovskite and device compositions with higher durability even under extreme conditions, for example, largely elevated temperatures and severe thermal cycles to match the practical application of this PV technology. If the mentioned issues can be resolved, we expect a big potential for perovskites on optimal substrates (e.g., rationally designed SAMs), combined with robust sealing techniques. Moving away from spin coating and toxic solvents 

toward more scalable deposition methods is hugely important. For instance, improved thermal evaporation processes and the development of novel hybrid deposition protocols will be beneficial for upscaling. In addition, a better understanding of the performance under mechanical stress will allow the development of flexible single-, double-, and multi-junction PVs. Finally, machine learning can aid the data-driven design of high-performance perovskite materials, which would ultimately accelerate the industrialization of the all-perovskite tandem PVs. 

## AUTHOR INFORMATION 

Corresponding Authors 

- Henry J. Snaith − Clarendon Laboratory, Department of Physics, University of Oxford, Oxford OX1 3PU, United Kingdom; orcid.org/0000-0001-8511-790X; Email: henry.snaith@physics.ox.ac.uk 

- Atsushi Wakamiya − Institute for Chemical Research, Kyoto University, Uji, Kyoto 611-0011, Japan; orcid.org/00000003-1430-0947; Email: wakamiya@scl.kyoto-u.ac.jp 

### Authors 

- Shuaifeng Hu − Clarendon Laboratory, Department of Physics, University of Oxford, Oxford OX1 3PU, United Kingdom; Institute for Chemical Research, Kyoto University, Uji, Kyoto 611-0011, Japan; orcid.org/0000-0003-1312075X 

- Jarla Thiesbrummel − Clarendon Laboratory, Department of Physics, University of Oxford, Oxford OX1 3PU, United Kingdom; Institute for Physics and Astronomy, University of Potsdam, 14476 Potsdam-Golm, Germany 

- Jorge Pascual − Institute for Chemical Research, Kyoto University, Uji, Kyoto 611-0011, Japan; Polymat, University of the Basque Country UPV/EHU, 20018 Donostia-San Sebastian, Spain; orcid.org/0000-0001-6486-0737 

- Martin Stolterfoht − Institute for Physics and Astronomy, University of Potsdam, 14476 Potsdam-Golm, Germany; Electronic Engineering Department, The Chinese University of Hong Kong, Hong Kong 999077 SAR, China; orcid.org/ 0000-0002-4023-2178 

Complete contact information is available at: https://pubs.acs.org/10.1021/acs.chemrev.3c00667 

### Author Contributions 

### §These authors contributed equally to this work. 

### Notes 

The authors declare the following competing financial interest(s): H. J. S. is the co-founder and CSO of Oxford PV Ltd. and Helio Display Materials Ltd. A. W. is the co-founder and CSO of Enecoat Technologies Co., Ltd. 

### Biographies 

Shuaifeng Hu is a postdoctoral researcher in the group of Prof. Henry J. Snaith at University of Oxford, U.K. He obtained his Master’s degree at Huazhong University of Science and Technology, China, in 2019, supervised by Prof. Xing Lu on the crystallographic characterization of endohedral metallofullerenes, and his Ph.D. at Kyoto University, Japan, in 2023, supervised by Prof. Atsushi Wakamiya. His research focuses on fabricating well-performing p-i-n perovskite solar cells with a particular interest in narrow-bandgap mixed Sn−Pb perovskite solar cells and perovskite-containing tandems. The core of his current work is on understanding the surface characteristics of the 

4107 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

neat perovskite films and their multilayer architecture devices, and then using the feedback knowledge to fabricate state-of-the-art singlejunction, all-perovskite tandem, and perovskite-on-Si tandem photovoltaics with sustainable deposition routes. 

Jarla Thiesbrummel obtained her Ph.D. at University of Oxford, U.K., under the supervision of Prof. Henry J. Snaith. She was also a visiting researcher in the group of Prof. Neher and Dr. Stolterfoht at the University of Potsdam, Germany. Her research focuses on trying to get a better physical understanding of different perovskite systems. Currently, she is mainly looking into the effect of mobile ions and doping on device performance. To do this, she uses a combination of experimental work and simulations. 

Jorge Pascual is a postdoctoral researcher at POLYMAT, University of the Basque Country, Spain. He obtained his Ph.D. at the same place in 2019, supervised by Prof. Juan Luis Delgado and Dr. Ramon Tená Zaera. After his Ph.D., he carried out postdoctoral studies at Helmholtz-Zentrum Berlin, Germany, under the supervision of Prof. Antonio Abate, and at Kyoto University, Japan, under the supervision of Prof. Atsushi Wakamiya. His research focuses on the chemistry of Sn-containing perovskite materials for photovoltaic applications. 

Martin Stolterfoht is a Vice-Chancellor Associate Professor at The Chinese University of Hong Kong. Before 2023, he was leading the Perovskite Subgroup within the Soft Matter Physics Group at the University of Potsdam, Germany. He completed his Master’s degree in Physics at the University of Graz, Austria, in 2012 and obtained his Ph.D. at the University of Queensland, Australia, in 2016. His research focuses on providing a fundamental description of thin-film solar cell operation and charge recombination processes from picoseconds to the steady state through electro-optical measurements and numerical modeling. He also aims at improving perovskite singlejunction and multijunction solar cells through the identification and suppression of recombination losses. 

Atsushi Wakamiya is a Professor at the Institute for Chemical Research of Kyoto University in Japan. His research focuses on the design of novel function materials that are applicable for making efficient and reliable perovskite solar cells and the development of fabrication strategies for perovskite solar modules and flexible lightweight perovskite solar cells. A. W. is also the cofounder and CSO of Enecoat Technologies Co., Ltd., a start-up company commercializing perovskite PVs. 

Henry J. Snaith is the Binks Professor of Renewable Energy in the Department of Physics, University of Oxford, U.K. His research focuses on developing and understanding new materials and device concepts for photovoltaic solar energy conversion. His research group works with organic, metal oxide, and metal halide perovskite semiconductors, processed via solution or vapor phase deposition methods. His interdisciplinary work ranges from new material synthesis and discovery, device fabrication and development, advanced characterization methodologies, and theoretical modeling. Beyond his academic appointment, Henry J. Snaith is also a cofounder and CSO of two spin-out companies, Oxford PV, Ltd., and Helio Display Materials, Ltd., commercializing metal halide perovskites for PV and light-emitting applications, respectively. 

## ACKNOWLEDGMENTS 

We acknowledge the Engineering and Physical Sciences Research Council (EPSRC), U.K., under Grant numbers EP/ S004947/1, EP/V010840/1, and EP/T025077/1, JSPS for a Research Fellowship for Young Scientists (21J14762), the China Scholarship Council (CSC) scholarships, the Rank Prize, the Deutsche Forschungsgemeinschaft (DFG, German 

Research Foundation) within the SPP 2196 (HIPSTER 424709669), the DonostiaINN, the Heisenberg program from the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation), Project number 498155101, HyPerCells (a joint graduate school of the University of Potsdam and the Helmholtz-Zentrum Berlin) and the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation), Project numbers 423749265 and 424709669-SPP 2196) (SURPRISE2 and HIPSTER-PRO), the JST-Mirai Program (JPMJMI22E2), NEDO, the International Collaborative Research Program of ICR, Kyoto University, and the European Union’s Horizon Europe research and innovation programme under Grant agreement no. 101075330 of the NEXUS project for funding. We thank Joel A. Smith, Heon Jin, and Junke Wang (University of Oxford) for sharing the data that allowed us to generate Figure<sup>2,</sup> d-ii), Figure<sup>7</sup> a-iv), and Figure<sup>13</sup> d-iii), respectively. We thank the community for making tremendous advancements in the field, which allowed us to construct the current comprehensive Review. 

## REFERENCES 

(1) Soe, C. M. M.; Stoumpos, C. C.; Kepenekian, M.; Traoré, B.; Tsai, H.; Nie, W.; Wang, B.; Katan, C.; Seshadri, R.; Mohite, A. D.; et al. New type of 2D perovskites with alternating cations in the interlayer space, (C(NH2)3)(CH3NH3)nPbnI3n+1: Structure, properties, and photovoltaic performance. J. Am. Chem. Soc. 2017, 139 (45), 16297−16309. 

(2) Zhang, T.; Zhou, C.; Feng, X.; Dong, N.; Chen, H.; Chen, X.; Zhang, L.; Lin, J.; Wang, J. Regulation of the luminescence mechanism of two-dimensional tin halide perovskites. Nat. Commun. 2022, 13 (1), 60. 

(3) Mitzi, D. B. Synthesis, crystal structure, and optical and thermal properties of (C4H9NH3)2MI4 (M = Ge, Sn, Pb). Chem. Mater. 1996, 8 (3), 791−800. 

(4) Guo, Y.; Shoyama, K.; Sato, W.; Matsuo, Y.; Inoue, K.; Harano, K.; Liu, C.; Tanaka, H.; Nakamura, E. Chemical pathways connecting lead(II) iodide and perovskite via polymeric plumbate(II) fiber. J. Am. Chem. Soc. 2015, 137 (50), 15907−15914. 

(5) Chiang, Y.-H.; Frohna, K.; Salway, H.; Abfalterer, A.; Pan, L.; Roose, B.; Anaya, M.; Stranks, S. D. Vacuum-deposited wide-bandgap perovskite for all-perovskite tandem solar cells. ACS Energy Lett. 2023, 8, 2728−2737. 

(6) Hao, F.; Stoumpos, C. C.; Guo, P.; Zhou, N.; Marks, T. J.; Chang, R. P.; Kanatzidis, M. G. Solvent-mediated crystallization of CH3NH3SnI3 films for heterojunction depleted perovskite solar cells. J. Am. Chem. Soc. 2015, 137 (35), 11445−11452. 

(7) Yuan, Y.; Huang, J. Ion migration in organometal trihalide perovskite and its impact on photovoltaic efficiency and stability. Acc. Chem. Res. 2016, 49 (2), 286−293. 

(8) Lin, R.; Xu, J.; Wei, M.; Wang, Y.; Qin, Z.; Liu, Z.; Wu, J.; Xiao, K.; Chen, B.; Park, S. M.; et al. All-perovskite tandem solar cells with improved grain surface passivation. Nature 2022, 603 (7899), 73−78. (9) Hu, S.; Otsuka, K.; Murdey, R.; Nakamura, T.; Truong, M. A.; Yamada, T.; Handa, T.; Matsuda, K.; Nakano, K.; Sato, A.; et al. Optimized carrier extraction at interfaces for 23.6% efficient tin-lead perovskite solar cells. Energy Environ. Sci. 2022, 15 (5), 2096−2107. 

(10) Mao, L.; Ke, W.; Pedesseau, L.; Wu, Y.; Katan, C.; Even, J.; Wasielewski, M. R.; Stoumpos, C. C.; Kanatzidis, M. G. Hybrid DionJacobson 2D lead iodide perovskites. J. Am. Chem. Soc. 2018, 140 (10), 3775−3783. 

(11) Wang, X.; Ying, Z.; Zheng, J.; Li, X.; Zhang, Z.; Xiao, C.; Chen, Y.; Wu, M.; Yang, Z.; Sun, J.; et al. Long-chain anionic surfactants enabling stable perovskite/silicon tandems with greatly suppressed stress corrosion. Nat. Commun. 2023, 14 (1), 2166. 

(12) Hu, S.; Truong, M. A.; Otsuka, K.; Handa, T.; Yamada, T.; Nishikubo, R.; Iwasaki, Y.; Saeki, A.; Murdey, R.; Kanemitsu, Y.; et al. Mixed lead-tin perovskite films with > 7 μs charge carrier lifetimes 

4108 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

realized by maltol post-treatment. Chem. Sci. 2021, 12 (40), 13513− 

13519. 

(13) Ryan, A. J.; Rothman, R. H. Engineering chemistry to meet COP26 targets. Nat. Rev. Chem. 2022, 6 (1), 1−3. 

(14) Barnham, K. W. J.; Mazzer, M.; Clive, B. Resolving the energy crisis: Nuclear or photovoltaics? Nat. Mater. 2006, 5 (3), 161−164. (15) Dai, X.; Chen, S.; Jiao, H.; Zhao, L.; Wang, K.; Ni, Z.; Yu, Z.; Chen, B.; Gao, Y.; Huang, J. Efficient monolithic all-perovskite tandem solar modules with small cell-to-module derate. Nat. Energy 2022, 7 (10), 923−931. 

(16) Green, M. A.; Ho-Baillie, A.; Snaith, H. J. The emergence of perovskite solar cells. Nat. Photonics 2014, 8 (7), 506−514. 

(17) Stranks, S. D.; Snaith, H. J. Metal-halide perovskites for photovoltaic and light-emitting devices. Nat. Nanotechnol. 2015, 10 (5), 391−402. 

(18) Huang, J.; Yuan, Y.; Shao, Y.; Yan, Y. Understanding the physical properties of hybrid perovskites for photovoltaic applications. Nat. Rev. Mater. 2017, 2 (7), 17042. 

(19) Liu, M.; Johnston, M. B.; Snaith, H. J. Efficient planar heterojunction perovskite solar cells by vapour deposition. Nature 2013, 501 (7467), 395−398. 

(20) Xu, A. F.; Wang, R. T.; Yang, L. W.; Jarvis, V.; Britten, J. F.; Xu, G. Pyrrolidinium lead iodide from crystallography: a new perovskite with low bandgap and good water resistance. Chem. Commun. 2019, 55 (22), 3251−3253. 

(21) Cai, M.; Wu, Y.; Chen, H.; Yang, X.; Qiang, Y.; Han, L. Costperformance analysis of perovskite solar modules. Adv. Sci. 2017, 4 (1), 1600269. 

(22) Li, Z.; Zhao, Y.; Wang, X.; Sun, Y.; Zhao, Z.; Li, Y.; Zhou, H.; Chen, Q. Cost analysis of perovskite tandem photovoltaics. Joule 2018, 2 (8), 1559−1572. 

(23) Mathews, I.; Sofia, S.; Ma, E.; Jean, J.; Laine, H. S.; Siah, S. C.; Buonassisi, T.; Peters, I. M. Economically sustainable growth of perovskite photovoltaics manufacturing. Joule 2020, 4 (4), 822−839. (24) Hörantner, M. T.; Leijtens, T.; Ziffer, M. E.; Eperon, G. E.; Christoforo, M. G.; McGehee, M. D.; Snaith, H. J. The potential of multijunction perovskite solar cells. ACS Energy Lett. 2017, 2 (10), 2506−2513. 

(25) Zhang, X.; Hao, Y.; Li, S.; Ren, J.; Wu, Y.; Sun, Q.; Cui, Y.; Hao, Y. Multifunction sandwich structure based on diffusible 2- chloroethylamine for high-efficiency and stable tin-lead mixed perovskite solar cells. J. Phys. Chem. Lett. 2022, 13 (1), 118−129. 

(26) Flatken, M. A.; Hoell, A.; Wendt, R.; Härk, E.; Dallmann, A.; Prause, A.; Pascual, J.; Unger, E.; Abate, A. Small-angle scattering to reveal the colloidal nature of halide perovskite precursor solutions. J. Mater. Chem. A 2021, 9 (23), 13477−13482. 

(27) Jošt, M.; Kegelmann, L.; Korte, L.; Albrecht, S. Monolithic perovskite tandem solar cells: A review of the present status and advanced characterization methods toward 30% efficiency. Adv. Energy Mater. 2020, 10 (26), 1904102. 

(28) Radicchi, E.; Mosconi, E.; Elisei, F.; Nunzi, F.; De Angelis, F. Understanding the solution chemistry of lead halide perovskites precursors. ACS Appl. Energy Mater. 2019, 2 (5), 3400−3409. 

(29) Tong, J.; Song, Z.; Kim, D. H.; Chen, X.; Chen, C.; Palmstrom, A. F.; Ndione, P. F.; Reese, M. O.; Dunfield, S. P.; Reid, O. G.; et al. Carrier lifetimes of > 1 μs in Sn-Pb perovskites enable efficient allperovskite tandem solar cells. Science 2019, 364 (6439), 475. 

(30) Jin, H.; Farrar, M. D.; Ball, J. M.; Dasgupta, A.; Caprioglio, P.; Narayanan, S.; Oliver, R. D. J.; Rombach, F. M.; Putland, B. W. J.; Johnston, M. B.; et al. Alumina nanoparticle interfacial buffer layer for low-bandgap lead-tin perovskite solar cells. Adv. Funct. Mater. 2023, 33 (35), 2303012. 

(31) Eperon, G. E.; Leijtens, T.; Bush, K. A.; Prasanna, R.; Green, T.; Wang, J. T.-W.; McMeekin, D. P.; Volonakis, G.; Milot, R. L.; May, R.; et al. Perovskite-perovskite tandem photovoltaics with optimized band gaps. Science 2016, 354 (6314), 861−865. 

(32) Xiao, K.; Lin, Y.-H.; Zhang, M.; Oliver, R. D. J.; Wang, X.; Liu, Z.; Luo, X.; Li, J.; Lai, D.; Luo, H.; et al. Scalable processing for 

realizing 21.7%-efficient all-perovskite tandem solar modules. Science 2022, 376 (6594), 762−767. 

(33) Lee, J.-W.; Kim, H.-S.; Park, N.-G. Lewis acid-base adduct approach for high efficiency perovskite solar cells. Acc. Chem. Res. 2016, 49 (2), 311−319. 

(34) Wang, R.; Huang, T.; Xue, J.; Tong, J.; Zhu, K.; Yang, Y. Prospects for metal halide perovskite-based tandem solar cells. Nat. Photonics 2021, 15 (6), 411−425. 

(35) Guo, T.; Wang, H.; Han, W.; Zhang, J.; Wang, C.; Ma, T.; Zhang, Z.; Deng, Z.; Chen, D.; Xu, W.; et al. Designed p-type graphene quantum dots to heal interface charge transfer in Sn-Pb perovskite solar cells. Nano Energy 2022, 98, 107298. 

(36) Ramirez, D.; Schutt, K.; Wang, Z.; Pearson, A. J.; Ruggeri, E.; Snaith, H. J.; Stranks, S. D.; Jaramillo, F. Layered mixed tin-lead hybrid perovskite solar cells with high stability. ACS Energy Lett. 2018, 3 (9), 2246−2251. 

(37) Zheng, X.; Alsalloum, A. Y.; Hou, Y.; Sargent, E. H.; Bakr, O. M. All-perovskite tandem solar cells: A roadmap to uniting high efficiency with high stability. Acc. Mater. Res. 2020, 1 (1), 63−76. 

(38) Leijtens, T.; Bush, K. A.; Prasanna, R.; McGehee, M. D. Opportunities and challenges for tandem solar cells using metal halide perovskite semiconductors. Nat. Energy 2018, 3 (10), 828−838. 

(39) Peters, I. M.; Rodriguez Gallegos, C. D.; Lüer, L.; Hauch, J. A.; Brabec, C. J. Practical limits of multijunction solar cells. Progress in Photovoltaics 2023, 31 (10), 1006−1015. 

(40) Kapil, G.; Ripolles, T. S.; Hamada, K.; Ogomi, Y.; Bessho, T.; Kinoshita, T.; Chantana, J.; Yoshino, K.; Shen, Q.; Toyoda, T.; et al. Highly efficient 17.6% tin-lead mixed perovskite solar cells realized through spike structure. Nano Lett. 2018, 18 (6), 3600−3607. 

(41) Yu, Z.; Yang, Z.; Ni, Z.; Shao, Y.; Chen, B.; Lin, Y.; Wei, H.; Yu, Z. J.; Holman, Z.; Huang, J. Simplified interconnection structure based on C60/SnO2-x for all-perovskite tandem solar cells. Nat. Energy 2020, 5 (9), 657−665. 

(42) Chen, B.; Yu, Z.; Onno, A.; Yu, Z.; Chen, S.; Wang, J.; Holman, Z. C.; Huang, J. Bifacial all-perovskite tandem solar cells. Sci. Adv. 2022, 8 (47), No. eadd0377. 

(43) Song, J.; Yin, X.; Hu, L.; Su, Z.; Jin, Y.; Deng, D.; Li, Z.; Wang, G.; Bao, Q.; Tian, W. Plasmon-coupled Au-nanochain functionalized PEDOT:PSS for efficient mixed tin-lead iodide perovskite solar cells. Chem. Commun. 2022, 58 (9), 1366−1369. 

(44) Xiao, K.; Lin, R.; Han, Q.; Hou, Y.; Qin, Z.; Nguyen, H. T.; Wen, J.; Wei, M.; Yeddu, V.; Saidaminov, M. I.; et al. All-perovskite tandem solar cells with 24.2% certified efficiency and area over 1 cm<sup>2</sup> using surface-anchoring zwitterionic antioxidant. Nat. Energy 2020, 5 (11), 870−880. 

(45) Shockley, W.; Queisser, H. J. Detailed balance limit of efficiency of p-n junction solar cells. J. Appl. Phys. 1961, 32 (3), 510−519. 

(46) Kojima, A.; Teshima, K.; Shirai, Y.; Miyasaka, T. Organometal halide perovskites as visible-light sensitizers for photovoltaic cells. J. Am. Chem. Soc. 2009, 131 (17), 6050−6051. 

(47) Im, J.-H.; Lee, C.-R.; Lee, J.-W.; Park, S.-W.; Park, N.-G. 6.5% efficient perovskite quantum-dot-sensitized solar cell. Nanoscale 2011, 3 (10), 4088−4093. 

(48) Kim, H.-S.; Lee, C.-R.; Im, J.-H.; Lee, K.-B.; Moehl, T.; Marchioro, A.; Moon, S.-J.; Humphry-Baker, R.; Yum, J.-H.; Moser, J. E.; et al. Lead iodide perovskite sensitized all-solid-state submicron thin film mesoscopic solar cell with efficiency exceeding 9%. Sci. Rep. 2012, 2 (1), 591. 

(49) Lee, M. M.; Teuscher, J.; Miyasaka, T.; Murakami, T. N.; Snaith, H. J. Efficient hybrid solar cells based on meso-superstructured organometal halide perovskites. Science 2012, 338 (6107), 643−647. 

(50) Taddei, M.; Smith, J. A.; Gallant, B. M.; Zhou, S. R.; Westbrook, R. J. E.; Shi, Y. W.; Wang, J.; Drysdale, J. N.; McCarthy, D. P.; Barlow, S.; et al. Ethylenediamine addition improves performance and suppresses phase instabilities in mixed-halide perovskites. ACS Energy Lett. 2022, 7 (12), 4265−4273. 

(51) Ye, S.; Rao, H.; Feng, M.; Xi, L.; Yen, Z.; Seng, D. H. L.; Xu, Q.; Boothroyd, C.; Chen, B.; Guo, Y.; et al. Expanding the low- 

4109 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

dimensional interface engineering toolbox for efficient perovskite solar 

cells. Nat. Energy 2023, 8 (3), 284−293. 

(52) NREL. Best research-cell efficiency chart. https://www.nrel. gov/pv/cell-efficiency.html (accessed on 2023-07-07). 

(53) Green, M. A.; Dunlop, E. D.; Yoshita, M.; Kopidakis, N.; Bothe, K.; Siefer, G.; Hao, X. Solar cell efficiency tables (Version 63). Prog. Photovolt.: Res. Appl. 2024, 32 (1), 3−13. 

(54) Yoo, J. J.; Seo, G.; Chua, M. R.; Park, T. G.; Lu, Y.; Rotermund, F.; Kim, Y.-K.; Moon, C. S.; Jeon, N. J.; Correa-Baena, J.-P.; et al. Efficient perovskite solar cells via improved carrier management. Nature 2021, 590 (7847), 587−593. 

(55) Kim, M.; Jeong, J.; Lu, H.; Lee, T. K.; Eickemeyer, F. T.; Liu, Y.; Choi, I. W.; Choi, S. J.; Jo, Y.; Kim, H.-B.; et al. Conformal quantum dot-SnO2 layers as electron transporters for efficient perovskite solar cells. Science 2022, 375 (6578), 302−306. 

(56) Kim, J. Y.; Lee, J.-W.; Jung, H. S.; Shin, H.; Park, N.-G. Highefficiency perovskite solar cells. Chem. Rev. 2020, 120 (15), 7867− 7918. 

(57) Zhao, Y.; Ma, F.; Qu, Z.; Yu, S.; Shen, T.; Deng, H.-X.; Chu, X.; Peng, X.; Yuan, Y.; Zhang, X.; et al. Inactive (PbI2)2RbCl stabilizes perovskite films for efficient solar cells. Science 2022, 377 (6605), 531−534. 

(58) Zhang, T.; Wang, F.; Kim, H.-B.; Choi, I.-W.; Wang, C.; Cho, E.; Konefal, R.; Puttisong, Y.; Terado, K.; Kobera, L.; et al. Ionmodulated radical doping of spiro-OMeTAD for more efficient and stable perovskite solar cells. Science 2022, 377 (6605), 495−501. 

(59) Min, H.; Lee, D. Y.; Kim, J.; Kim, G.; Lee, K. S.; Kim, J.; Paik, M. J.; Kim, Y. K.; Kim, K. S.; Kim, M. G.; et al. Perovskite solar cells with atomically coherent interlayers on SnO2 electrodes. Nature 2021, 598 (7881), 444−450. 

(60) Li, Z.; Li, B.; Wu, X.; Sheppard, S. A.; Zhang, S.; Gao, D.; Long, N. J.; Zhu, Z. Organometallic-functionalized interfaces for highly efficient inverted perovskite solar cells. Science 2022, 376 (6591), 416−420. 

(61) Jiang, Q.; Tong, J.; Xian, Y.; Kerner, R. A.; Dunfield, S. P.; Xiao, C.; Scheidt, R. A.; Kuciauskas, D.; Wang, X.; Hautzinger, M. P.; et al. Surface reaction for efficient and stable inverted perovskite solar cells. Nature 2022, 611 (7935), 278−283. 

(62) Zhang, S.; Ye, F.; Wang, X.; Chen, R.; Zhang, H.; Zhan, L.; Jiang, X.; Li, Y.; Ji, X.; Liu, S.; et al. Minimizing buried interfacial defects for efficient inverted perovskite solar cells. Science 2023, 380 (6643), 404−409. 

(63) Peng, W.; Mao, K.; Cai, F.; Meng, H.; Zhu, Z.; Li, T.; Yuan, S.; Xu, Z.; Feng, X.; Xu, J.; et al. Reducing nonradiative recombination in perovskite solar cells with a porous insulator contact. Science 2023, 379 (6633), 683−690. 

(64) Green, M. A.; Dunlop, E. D.; Hohl-Ebinger, J.; Yoshita, M.; Kopidakis, N.; Bothe, K.; Hinken, D.; Rauer, M.; Hao, X. Solar cell efficiency tables (Version 60). Prog. Photovolt.: Res. Appl. 2022, 30 (7), 687−701. 

(65) Lin, H.; Yang, M.; Ru, X.; Wang, G.; Yin, S.; Peng, F.; Hong, C.; Qu, M.; Lu, J.; Fang, L.; et al. Silicon heterojunction solar cells with up to 26.81% efficiency achieved by electrically optimized nanocrystalline-silicon hole contact layers. Nat. Energy 2023, 8 (8), 789−799. 

(66) Hu, H.; Moghadamzadeh, S.; Azmi, R.; Li, Y.; Kaiser, M.; Fischer, J. C.; Jin, Q.; Maibach, J.; Hossain, I. M.; Paetzold, U. W.; et al. Sn-Pb mixed perovskites with fullerene-derivative interlayers for efficient four-terminal all-perovskite tandem solar cells. Adv. Funct. Mater. 2022, 32 (12), 2107650. 

(67) Huang, T.; Tan, S.; Nuryyeva, S.; Yavuz, I.; Babbe, F.; Zhao, Y.; Abdelsamie, M.; Weber, M. H.; Wang, R.; Houk, K. N. Performancelimiting formation dynamics in mixed-halide perovskites. Sci. Adv. 2021, 7 (46), No. eabj1799. 

(68) Subedi, B.; Li, C.; Chen, C.; Liu, D.; Junda, M. M.; Song, Z.; Yan, Y.; Podraza, N. J. Urbach energy and open-circuit voltage deficit for mixed anion-cation perovskite solar cells. ACS Appl. Mater. Interfaces 2022, 14 (6), 7796−7804. 

(69) Hou, X.; Li, F.; Zhang, X.; Shi, Y.; Du, Y.; Gong, J.; Xiao, X.; Ren, S.; Zhao, X.-Z.; Tai, Q. Reducing the energy loss to achieve high open-circuit voltage and efficiency by coordinating energy-level matching in Sn-Pb binary perovskite solar cells. Sol. RRL 2021, 5 (8), 2100287. 

(70) Wang, Y.; Lin, R.; Wang, X.; Liu, C.; Ahmed, Y.; Huang, Z.; Zhang, Z.; Li, H.; Zhang, M.; Gao, Y.; et al. Oxidation-resistant allperovskite tandem solar cells in substrate configuration. Nat. Commun. 2023, 14 (1), 1819. 

(71) Tan, H. Japan’s JET certifies Renshine Solar’s 29.0% steadystate efficiency for all-perovskite tandem solar cell. Taiyang News, 2023.https://taiyangnews.info/technology/29-0-all-perovskitetandem-solar-cell-efficiency/ (accessed on 2023-04-15). 

(72) Hu, S.; Pascual, J.; Liu, W.; Funasaki, T.; Truong, M. A.; Hira, S.; Hashimoto, R.; Morishita, T.; Nakano, K.; Tajima, K.; et al. A universal surface treatment for p-i-n perovskite solar cells. ACS Appl. Mater. Interfaces 2022, 14 (50), 56290−56297. 

(73) Peng, C.; Li, C.; Zhu, M.; Zhang, C.; Jiang, X.; Yin, H.; He, B.; Li, H.; Li, M.; So, S. K.; et al. Reducing energy disorder for efficient and stable Sn-Pb alloyed perovskite solar cells. Angew. Chem., Int. Ed. 2022, 61 (23), No. e202201209. 

(74) Yu, Z.; Wang, J.; Chen, B.; Uddin, M. A.; Ni, Z.; Yang, G.; Huang, J. Solution processed ternary tin(II) alloy as hole-transport layer of Sn-Pb perovskite solar cells for enhanced efficiency and stability. Adv. Mater. 2022, 34 (49), 2205769. 

(75) Al-Ashouri, A.; Marčinskas, M.; Kasparavičius, E.; Malinauskas, T.; Palmstrom, A.; Getautis, V.; Albrecht, S.; McGehee, M. D.; Magomedov, A. Wettability improvement of a carbazole-based holeselective monolayer for reproducible perovskite solar cells. ACS Energy Lett. 2023, 8 (2), 898−900. 

(76) LONGi. LONGi sets a new world record of 33.9% for the efficiency of crystalline silicon-perovskite tandem solar cells. LONGi News, 2023. https://www.longi.com/en/news/new-world-record-forthe-efficiency-of-crystalline-silicon-perovskite-tandem-solar-cells/. 

(77) Lin, R.; Wang, Y.; Lu, Q.; Tang, B.; Li, J.; Gao, H.; Gao, Y.; Li, H.; Ding, C.; Wen, J. All-perovskite tandem solar cells with 3D/3D bilayer perovskite heterojunction. Nature 2023, 620, 994. 

(78) Saidaminov, M. I.; Spanopoulos, I.; Abed, J.; Ke, W.; Wicks, J.; Kanatzidis, M. G.; Sargent, E. H. Conventional solvent oxidizes Sn(II) in perovskite inks. ACS Energy Lett. 2020, 5 (4), 1153−1155. 

(79) Pascual, J.; Di Girolamo, D.; Flatken, M. A.; Aldamasy, M. H.; Li, G.; Li, M.; Abate, A. Lights and shadows of DMSO as solvent for tin halide perovskites. Chem. Eur. J. 2022, 28 (12), No. e202103919. (80) Hu, S.; Zhao, P.; Nakano, K.; Oliver, R. D. J.; Pascual, J.; Smith, J. A.; Yamada, T.; Truong, M. A.; Murdey, R.; Shioya, N.; et al. Synergistic surface modification of tin-lead perovskite solar cells. Adv. Mater. 2023, 35 (9), 2208320. 

(81) Lei, Y.; Chen, Y.; Zhang, R.; Li, Y.; Yan, Q.; Lee, S.; Yu, Y.; Tsai, H.; Choi, W.; Wang, K.; et al. A fabrication process for flexible single-crystal perovskite devices. Nature 2020, 583 (7818), 790−795. 

(82) Duijnstee, E. A.; Gallant, B. M.; Holzhey, P.; Kubicki, D. J.; Collavini, S.; Sturdza, B. K.; Sansom, H. C.; Smith, J.; Gutmann, M. J.; Saha, S.; et al. Understanding the degradation of methylenediammonium and its role in phase-stabilizing formamidinium lead triiodide. J. Am. Chem. Soc. 2023, 145 (18), 10275−10284. 

(83) Liu, K.; Rafique, S.; Musolino, S. F.; Cai, Z.; Liu, F.; Li, X.; Yuan, Y.; Bao, Q.; Yang, Y.; Chu, J. Covalent bonding strategy to enable non-volatile organic cation perovskite for highly stable and efficient solar cells. Joule 2023, 7, 1033. 

(84) Palmstrom, A. F.; Eperon, G. E.; Leijtens, T.; Prasanna, R.; Habisreutinger, S. N.; Nemeth, W.; Gaulding, E. A.; Dunfield, S. P.; Reese, M.; Nanayakkara, S.; et al. Enabling flexible all-perovskite tandem solar cells. Joule 2019, 3 (9), 2193−2204. 

(85) Dong, H.; Ran, C.; Gao, W.; Sun, N.; Liu, X.; Xia, Y.; Chen, Y.; Huang, W. Crystallization dynamics of Sn-based perovskite thin films: Toward efficient and stable photovoltaic devices. Adv. Energy Mater. 2022, 12 (1), 2102213. 

(86) Liu, H.; Wang, L.; Li, R.; Shi, B.; Wang, P.; Zhao, Y.; Zhang, X. Modulated crystallization and reduced VOC deficit of mixed lead-tin 

4110 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

perovskite solar cells with antioxidant caffeic acid. ACS Energy Lett. 2021, 6 (8), 2907−2916. 

(87) Park, K.; Lee, J.-H.; Lee, J.-W. Surface defect engineering of metal halide perovskites for photovoltaic applications. ACS Energy Lett. 2022, 7 (3), 1230−1239. 

(88) Li, B.; Chang, B. H.; Pan, L.; Li, Z. H.; Fu, L.; He, Z. B.; Yin, L. W. Tin-based defects and passivation strategies in tin-related perovskite solar cells. ACS Energy Lett. 2020, 5 (12), 3752−3772. 

(89) Xue, J.; Wang, R.; Yang, Y. The surface of halide perovskites from nano to bulk. Nat. Rev. Mater. 2020, 5 (11), 809−827. 

(90) Li, L.; Wang, Y.; Wang, X.; Lin, R.; Luo, X.; Liu, Z.; Zhou, K.; Xiong, S.; Bao, Q.; Chen, G.; et al. Flexible all-perovskite tandem solar cells approaching 25% efficiency with molecule-bridged hole-selective contact. Nat. Energy 2022, 7 (8), 708−717. 

(91) Ran, C.; Xu, J.; Gao, W.; Huang, C.; Dou, S. Defects in metal triiodide perovskite materials towards high-performance solar cells: origin, impact, characterization, and engineering. Chem. Soc. Rev. 2018, 47 (12), 4581−4610. 

(92) Gao, W.; Li, P.; Chen, J.; Ran, C.; Wu, Z. Interface engineering in tin perovskite solar cells. Adv. Mater. Interfaces 2019, 6 (24), 1901322. 

(93) Xiao, K.; Wen, J.; Han, Q.; Lin, R.; Gao, Y.; Gu, S.; Zang, Y.; Nie, Y.; Zhu, J.; Xu, J.; et al. Solution-processed monolithic allperovskite triple-junction solar cells with efficiency exceeding 20%. ACS Energy Lett. 2020, 5 (9), 2819−2826. 

(94) Wu, Y.; Islam, A.; Yang, X.; Qin, C.; Liu, J.; Zhang, K.; Peng, W.; Han, L. Retarding the crystallization of PbI2 for highly reproducible planar-structured perovskite solar cells via sequential deposition. Energy Environ. Sci. 2014, 7 (9), 2934−2938. 

(95) Ahn, N.; Son, D.-Y.; Jang, I.-H.; Kang, S. M.; Choi, M.; Park, N.-G. Highly reproducible perovskite solar cells with average efficiency of 18.3% and best efficiency of 19.7% fabricated via Lewis base adduct of lead(II) iodide. J. Am. Chem. Soc. 2015, 137 (27), 8696−8699. 

(96) Hao, F.; Stoumpos, C. C.; Guo, P.; Zhou, N.; Marks, T. J.; Chang, R. P. H.; Kanatzidis, M. G. Solvent-mediated crystallization of CH3NH3SnI3 films for heterojunction depleted perovskite solar cells. J. Am. Chem. Soc. 2015, 137 (35), 11445−11452. 

(97) Kirmani, A. R.; Ostrowski, D. P.; VanSant, K. T.; Byers, T. A.; Bramante, R. C.; Heinselman, K. N.; Tong, J.; Stevens, B.; Nemeth, W.; Zhu, K.; et al. Metal oxide barrier layers for terrestrial and space perovskite photovoltaics. Nat. Energy 2023, 8 (2), 191−202. 

(98) Wang, J.; Gao, Z.; Yang, J.; Lv, M.; Chen, H.; Xue, D.-J.; Meng, X.; Yang, S. Controlling the crystallization kinetics of lead-free tin halide perovskites for high performance green photovoltaics. Adv. Energy Mater. 2021, 11 (39), 2102131. 

(99) Pitaro, M.; Tekelenburg, E. K.; Shao, S.; Loi, M. A. Tin halide perovskites: From fundamental properties to solar cells. Adv. Mater. 2022, 34 (1), 2105844. 

(100) Wang, J.; Zardetto, V.; Datta, K.; Zhang, D.; Wienk, M. M.; Janssen, R. A. J. 16.8% Monolithic all-perovskite triple-junction solar cells via a universal two-step solution process. Nat. Commun. 2020, 11 (1), 5254. 

(101) Wang, Z.; Zeng, L.; Zhu, T.; Chen, H.; Chen, B.; Kubicki, D. J.; Balvanz, A.; Li, C.; Maxwell, A.; Ugur, E.; dos Reis, R.; Cheng, M.; Yang, G.; Subedi, B.; Luo, D.; Hu, J.; Wang, J.; Teale, S.; Mahesh, S.; Wang, S.; Hu, S.; Jung, E. D.; Wei, M.; Park, S. M.; Grater, L.; Aydin, E.; Song, Z.; Podraza, N. J.; Lu, Z.-H.; Huang, J.; Dravid, V. P.; De Wolf, S.; Yan, Y.; Gratzel, M.; Kanatzidis, M. G.; Sargent, E. H. Suppressed phase segregation for triple-junction perovskite solar cells. Nature 2023, 618, 7479. 

(102) Wang, J.; Datta, K.; Li, J.; Verheijen, M. A.; Zhang, D.; Wienk, M. M.; Janssen, R. A. J. Understanding the film formation kinetics of sequential deposited narrow-bandgap Pb-Sn hybrid perovskite films. Adv. Energy Mater. 2020, 10 (22), 2000566. 

(103) Bowman, A. R.; Klug, M. T.; Doherty, T. A. S.; Farrar, M. D.; Senanayak, S. P.; Wenger, B.; Divitini, G.; Booker, E. P.; AndajiGarmaroudi, Z.; Macpherson, S.; et al. Microsecond carrier lifetimes, 

controlled p-doping, and enhanced air stability in low-bandgap metal halide perovskites. ACS Energy Lett. 2019, 4 (9), 2301−2307. 

(104) Lim, V. J. Y.; Ulatowski, A. M.; Kamaraki, C.; Klug, M. T.; Miranda Perez, L.; Johnston, M. B.; Herz, L. M. Air-degradation mechanisms in mixed lead-tin halide perovskites for solar cells. Adv. Energy Mater. 2023, 13 (33), 2200847. 

(105) Sun, Y.; Yang, S.; Pang, Z.; Quan, Y.; Song, R.; Chen, Y.; Qi, W.; Gao, Y.; Wang, F.; Zhang, X.; et al. Preferred film orientation to achieve stable and efficient Sn-Pb binary perovskite solar cells. ACS Appl. Mater. Interfaces 2021, 13 (9), 10822−10836. 

(106) Lv, S.; Gao, W.; Ran, C.; Li, D.; Chao, L.; Wang, X.; Song, L.; Lin, Z.; Fu, L.; Chen, Y. Antisolvent-free fabrication of efficient and stable Sn-Pb perovskite solar cells. Sol. RRL 2021, 5 (11), 2100675. 

(107) Abdollahi Nejand, B.; Hossain, I. M.; Jakoby, M.; Moghadamzadeh, S.; Abzieher, T.; Gharibzadeh, S.; Schwenzer, J. A.; Nazari, P.; Schackmar, F.; Hauschild, D.; et al. Vacuum-assisted growth of low-bandgap thin films (FA0.8MA0.2Sn0.5Pb0.5I3) for allperovskite tandem solar cells. Adv. Energy Mater. 2020, 10 (5), 1902583. 

(108) Werner, J.; Moot, T.; Gossett, T. A.; Gould, I. E.; Palmstrom, A. F.; Wolf, E. J.; Boyd, C. C.; van Hest, M. F. A. M.; Luther, J. M.; Berry, J. J.; et al. Improving low-bandgap tin-lead perovskite solar cells via contact engineering and gas quench processing. ACS Energy Lett. 2020, 5 (4), 1215−1223. 

(109) Qin, Z.; Qin, M.; Lu, X. High-Efficiency Low-Lead Perovskite Photovoltaics Approaching 20% Enabled by a Vacuum-Drying Strategy. Small Methods 2023, 7 (9), No. e2300202. 

(110) Ruggeri, E.; Anaya, M.; Gałkowski, K.; Delport, G.; Kosasih, F. U.; Abfalterer, A.; Mackowski, S.; Ducati, C.; Stranks, S. D. Controlling the growth kinetics and optoelectronic properties of 2D/3D lead-tin perovskite heterojunctions. Adv. Mater. 2019, 31 (51), 1905247. 

(111) Xi, J.; Duim, H.; Pitaro, M.; Gahlot, K.; Dong, J.; Portale, G.; Loi, M. A. Scalable, template driven formation of highly crystalline lead-tin halide perovskite films. Adv. Funct. Mater. 2021, 31 (46), 2105734. 

(112) Ma, Y.; Zheng, F.; Li, S.; Liu, Y.; Ren, J.; Wu, Y.; Sun, Q.; Hao, Y. Regulating the crystallization growth of Sn-Pb mixed perovskites using the 2D perovskite (4-AMP)PbI4 substrate for high-efficiency and stable solar cells. ACS Appl. Mater. Interfaces 2023, 15 (29), 34862−34873. 

(113) Qin, Z.; Pols, M.; Qin, M.; Zhang, J.; Yan, H.; Tao, S.; Lu, X. Over-18%-efficiency quasi-2D Ruddlesden-Popper Pb-Sn mixed perovskite solar cells by compositional engineering. ACS Energy Lett. 2023, 8 (7), 3188−3195. 

(114) Pascual, J.; Flatken, M.; Félix, R.; Li, G.; Turren-Cruz, S.-H.; Aldamasy, M. H.; Hartmann, C.; Li, M.; Di Girolamo, D.; Nasti, G.; et al. Fluoride chemistry in tin halide perovskites. Angew. Chem., Int. Ed. 2021, 60 (39), 21583−21591. 

(115) Zuo, F.; Williams, S. T.; Liang, P.-W.; Chueh, C.-C.; Liao, C.Y.; Jen, A. K. Y. Binary-metal perovskites toward high-performance planar-heterojunction hybrid solar cells. Adv. Mater. 2014, 26 (37), 6454−6460. 

(116) Zhang, F.; Zhu, K. Additive engineering for efficient and stable perovskite solar cells. Adv. Energy Mater. 2020, 10 (13), 1902579. (117) Zhang, X.; Wu, G.; Yang, S.; Fu, W.; Zhang, Z.; Chen, C.; Liu, W.; Yan, J.; Yang, W.; Chen, H. Vertically oriented 2D layered perovskite solar cells with enhanced efficiency and good stability. Small 2017, 13 (33), 1700611. 

(118) Zhang, X.; Wu, G.; Fu, W.; Qin, M.; Yang, W.; Yan, J.; Zhang, Z.; Lu, X.; Chen, H. Orientation regulation of phenylethylammonium cation based 2D perovskite solar cell with efficiency higher than 11%. Adv. Energy Mater. 2018, 8 (14), 1702498. 

(119) Ke, W.; Xiao, C.; Wang, C.; Saparov, B.; Duan, H.-S.; Zhao, D.; Xiao, Z.; Schulz, P.; Harvey, S. P.; Liao, W.; et al. Employing lead thiocyanate additive to reduce the hysteresis and boost the fill factor of planar perovskite solar cells. Adv. Mater. 2016, 28 (26), 5214− 5221. 

4111 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

(120) Yu, Y.; Wang, C.; Grice, C. R.; Shrestha, N.; Zhao, D.; Liao, W.; Guan, L.; Awni, R. A.; Meng, W.; Cimaroli, A. J.; et al. Synergistic effects of lead thiocyanate additive and solvent annealing on the performance of wide-bandgap perovskite solar cells. ACS Energy Lett. 2017, 2 (5), 1177−1182. 

(121) Zhou, N.; Zhang, Y.; Huang, Z.; Guo, Z.; Zhu, C.; He, J.; Chen, Q.; Sun, W.; Zhou, H. Mobile media promotes orientation of 2D/3D hybrid lead halide perovskite for efficient solar cells. ACS Nano 2021, 15 (5), 8350−8362. 

(122) Liu, B.; Chen, H.; Cao, J.; Chen, X.; Xie, J.; Shu, Y.; Yan, F.; Huang, W.; Qin, T. Imidazole derivative assisted crystallization for high-efficiency mixed Sn-Pb perovskite solar cells. Adv. Funct. Mater. 2024, 34 (6), 2310828. 

(123) Yan, K.; Long, M.; Zhang, T.; Wei, Z.; Chen, H.; Yang, S.; Xu, J. Hybrid halide perovskite solar cell precursors: Colloidal chemistry and coordination engineering behind device processing for high efficiency. J. Am. Chem. Soc. 2015, 137 (13), 4460−4468. 

(124) De Yoreo, J. J.; Gilbert, P. U. P. A.; Sommerdijk, N. A. J. M.; Penn, R. L.; Whitelam, S.; Joester, D.; Zhang, H.; Rimer, J. D.; Navrotsky, A.; Banfield, J. F.; et al. Crystallization by particle attachment in synthetic, biogenic, and geologic environments. Science 2015, 349 (6247), aaa6760. 

(125) Zhou, Y.; Game, O. S.; Pang, S.; Padture, N. P. Microstructures of organometal trihalide perovskites for solar cells: Their evolution from solutions and characterization. J. Phys. Chem. Lett. 2015, 6 (23), 4827−4839. 

(126) Karthika, S.; Radhakrishnan, T. K.; Kalaichelvi, P. A review of classical and nonclassical nucleation theories. Cryst. Growth Des. 2016, 16 (11), 6663−6681. 

(127) Kim, J.; Park, B.-w.; Baek, J.; Yun, J. S.; Kwon, H.-W.; Seidel, J.; Min, H.; Coelho, S.; Lim, S.; Huang, S.; et al. Unveiling the relationship between the perovskite precursor solution and the resulting device performance. J. Am. Chem. Soc. 2020, 142 (13), 6251−6260. 

(128) Shin, G. S.; Kim, S.-G.; Zhang, Y.; Park, N.-G. A correlation between iodoplumbate and photovoltaic performance of perovskite solar cells observed by precursor solution aging. Small Methods 2020, 4 (5), 1900398. 

(129) O’Kane, M. E.; Smith, J. A.; Kilbride, R. C.; Spooner, E. L. K.; Duif, C. P.; Catley, T. E.; Washington, A. L.; King, S. M.; Parnell, S. R.; Parnell, A. J. Exploring nanoscale structure in perovskite precursor solutions using neutron and light scattering. Chem. Mater. 2022, 34 (16), 7232−7241. 

(130) Flatken, M. A.; Radicchi, E.; Wendt, R.; Buzanich, A. G.; Härk, E.; Pascual, J.; Mathies, F.; Shargaieva, O.; Prause, A.; Dallmann, A.; et al. Role of the alkali metal cation in the early stages of crystallization of halide perovskites. Chem. Mater. 2022, 34 (3), 1121−1131. 

(131) Hidalgo, J.; An, Y.; Yehorova, D.; Li, R.; Breternitz, J.; Perini, C. A. R.; Hoell, A.; Boix, P. P.; Schorr, S.; Kretchmer, J. S.; et al. Solvent and A-site cation control preferred crystallographic orientation in bromine-based perovskite thin films. Chem. Mater. 2023, 35 (11), 4181−4191. 

(132) Dutta, N. S.; Noel, N. K.; Arnold, C. B. Crystalline nature of colloids in methylammonium lead halide perovskite precursor inks revealed by cryo-electron microscopy. J. Phys. Chem. Lett. 2020, 11 (15), 5980−5986. 

(133) Kaiser, W.; Radicchi, E.; Mosconi, E.; Kachmar, A.; De Angelis, F. Iodide vs chloride: The impact of different lead halides on the solution chemistry of perovskite precursors. ACS Appl. Energy Mater. 2021, 4 (9), 9827−9835. 

(134) Di Girolamo, D.; Pascual, J.; Aldamasy, M. H.; Iqbal, Z.; Li, G.; Radicchi, E.; Li, M.; Turren-Cruz, S.-H.; Nasti, G.; Dallmann, A.; et al. Solvents for processing stable tin halide perovskites. ACS Energy Lett. 2021, 6 (3), 959−968. 

(135) Cao, X. R.; Li, J. R.; Dong, H.; Li, P. Z.; Fan, Q. H.; Xu, R. Y.; Li, H. M.; Zhou, G. J.; Wu, Z. X. Stability improvement of tin-based halide perovskite by precursor-solution regulation with dual-functional reagents. Adv. Funct. Mater. 2021, 31 (40), 2104344. 

(136) Nasti, G.; Aldamasy, M. H.; Flatken, M. A.; Musto, P.; Matczak, P.; Dallmann, A.; Hoell, A.; Musiienko, A.; Hempel, H.; Aktas, E.; et al. Pyridine controlled tin perovskite crystallization. ACS Energy Lett. 2022, 7, 3197−3203. 

(137) Pascual, J.; Flatken, M.; Felix, R.; Li, G.; Turren-Cruz, S. H.; Aldamasy, M. H.; Hartmann, C.; Li, M.; Di Girolamo, D.; Nasti, G.; et al. Fluoride chemistry in tin halide perovskites. Angew. Chem., Int. Ed. Engl. 2021, 60 (39), 21583−21591. 

(138) Zhang, Z.; Liang, J.; Wang, J.; Zheng, Y.; Wu, X.; Tian, C.; Sun, A.; Huang, Y.; Zhou, Z.; Yang, Y.; et al. DMSO-free solvent strategy for stable and efficient methylammonium-free Sn-Pb alloyed perovskite solar cells. Adv. Energy Mater. 2023, 13 (17), 2300181. 

(139) He, L.; Gu, H.; Liu, X.; Li, P.; Dang, Y.; Liang, C.; Ono, L. K.; Qi, Y.; Tao, X. Efficient anti-solvent-free spin-coated and printed Snperovskite solar cells with crystal-based precursor solutions. Matter 2020, 2 (1), 167−180. 

(140) Wang, M.; Wang, W.; Shen, Y.; Ma, J.; Shen, W.; Cao, K.; Liu, L.; Chen, S. Stirring-time control approach to manage colloid nucleation size for the fabrication of high-performance Sn-based perovskite solar cells. ACS Appl. Mater. Interfaces 2022, 14 (48), 53960−53970. 

(141) Jiang, X.; Li, H.; Zhou, Q.; Wei, Q.; Wei, M.; Jiang, L.; Wang, Z.; Peng, Z.; Wang, F.; Zang, Z.; et al. One-step synthesis of SnI2· DMSOx adducts for high-performance tin perovskite solar cells. J. Am. Chem. Soc. 2021, 143 (29), 10970−10976. 

(142) Su, Y.; Yang, J.; Liu, G.; Sheng, W.; Zhang, J.; Zhong, Y.; Tan, L.; Chen, Y. Acetic acid-assisted synergistic modulation of crystallization kinetics and inhibition of Sn<sup>2+</sup> oxidation in tin-based perovskite solar cells. Adv. Funct. Mater. 2022, 32 (12), 2109631. 

(143) Rao, H.; Su, Y.; Liu, G.; Zhou, H.; Yang, J.; Sheng, W.; Zhong, Y.; Tan, L.; Chen, Y. Monodisperse adducts-induced homogeneous nucleation towards high-quality tin-based perovskite film. Angew. Chem., Int. Ed. 2023, 62 (33), No. e202306712. 

(144) Hu, S.; Smith, J. A.; Snaith, H. J.; Wakamiya, A. Prospects for tin-containing halide perovskite photovoltaics. Precis. Chem. 2023, 1 (2), 69−82. 

(145) Zhang, W.; Yuan, H.; Li, X.; Guo, X.; Lu, C.; Liu, A.; Yang, H.; Xu, L.; Shi, X.; Fang, Z.; et al. Component distribution regulation in Sn-Pb perovskite solar cells through selective molecular interaction. Adv. Mater. 2023, 35 (39), 2303674. 

(146) Cao, J.; Loi, H.-L.; Xu, Y.; Guo, X.; Wang, N.; Liu, C.-k.; Wang, T.; Cheng, H.; Zhu, Y.; Li, M. G.; et al. High-performance tinlead mixed-perovskite solar cells with vertical compositional gradient. Adv. Mater. 2022, 34 (6), 2107729. 

(147) Fu, P.; Quintero, M. A.; Vasileiadou, E. S.; Raval, P.; Welton, C.; Kepenekian, M.; Volonakis, G.; Even, J.; Liu, Y.; Malliakas, C.; et al. Chemical behavior and local structure of the Ruddlesden-Popper and Dion-Jacobson alloyed Pb/Sn bromide 2D perovskites. J. Am. Chem. Soc. 2023, 145 (29), 15997−16014. 

(148) Ozaki, M.; Katsuki, Y.; Liu, J.; Handa, T.; Nishikubo, R.; Yakumaru, S.; Hashikawa, Y.; Murata, Y.; Saito, T.; Shimakawa, Y.; et al. Solvent-coordinated tin halide complexes as purified precursors for tin-based perovskites. ACS Omega 2017, 2 (10), 7016−7021. 

(149) Walsh, A.; Watson, G. W. Influence of the anion on lone pair formation in Sn(II) monochalcogenides: A DFT study. J. Phys. Chem. B 2005, 109 (40), 18868−18875. 

(150) Persson, I.; D’Angelo, P.; Lundberg, D. Hydrated and solvated tin(II) ions in solution and the solid state, and a coordination chemistry overview of the d<sup>10</sup> s<sup>2</sup> metal ions. Chem. Eur. J. 2016, 22 (51), 18583−18592. 

(151) Smith, P. J. Chemistry of tin; Springer Dordrecht: 1998; DOI: 10.1007/978-94-011-4938-9. 

(152) Cao, J.; Jing, X.; Yan, J.; Hu, C.; Chen, R.; Yin, J.; Li, J.; Zheng, N. Identifying the molecular structures of intermediates for optimizing the fabrication of high-quality perovskite films. J. Am. Chem. Soc. 2016, 138 (31), 9919−9926. 

(153) Cheng, F. W.; Jing, X. J.; Chen, R. H.; Cao, J.; Yan, J. Z.; Wu, Y. Y. Q.; Huang, X. F.; Wu, B. H.; Zheng, N. F. N-Methyl-2pyrrolidone as an excellent coordinative additive with a wide 

4112 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

operating range for fabricating high-quality perovskite films. Inorg. Chem. Front. 2019, 6 (9), 2458−2463. 

(154) Zhang, Z.; Liang, J.; Wang, J.; Zheng, Y.; Wu, X.; Tian, C.; Sun, A.; Chen, Z.; Chen, C.-C. Resolving mixed intermediate phases in methylammonium-free Sn-Pb alloyed perovskites for high-performance solar cells. Nanomicro Lett. 2022, 14 (1), 165. 

(155) Chang, Z.; Zheng, D.; Zhao, S.; Wang, L.; Wu, S.; Liu, L.; Li, Z.; Zhang, L.; Dong, Q.; Wang, H.; et al. Designing heterovalent substitution with antioxidant attribute for high-performance Sn-Pb alloyed perovskite solar cells. Adv. Funct. Mater. 2023, 33 (22), 2214983. 

(156) Alsari, M.; Bikondoa, O.; Bishop, J.; Abdi-Jalebi, M.; Ozer, L. Y.; Hampton, M.; Thompson, P.; T. Hörantner, M.; Mahesh, S.; Greenland, C.; et al. In situ simultaneous photovoltaic and structural evolution of perovskite solar cells during film formation. Energy Environ. Sci. 2018, 11 (2), 383−393. 

(157) Pratap, S.; Babbe, F.; Barchi, N. S.; Yuan, Z.; Luong, T.; Haber, Z.; Song, T.-B.; Slack, J. L.; Stan, C. V.; Tamura, N.; et al. Outof-equilibrium processes in crystallization of organic-inorganic perovskites during spin coating. Nat. Commun. 2021, 12 (1), 5624. 

(158) Babbe, F.; Sutter-Fella, C. M. Optical absorption-based in situ characterization of halide perovskites. Adv. Energy Mater. 2020, 10 (26), 1903587. 

(159) Wang, W.; Ghosh, T.; Yan, H.; Erofeev, I.; Zhang, K.; Loh, K. P.; Mirsaidov, U. The growth dynamics of organic-inorganic metal halide perovskite films. J. Am. Chem. Soc. 2022, 144 (39), 17848− 17856. 

(160) Babayigit, A.; D’Haen, J.; Boyen, H.-G.; Conings, B. Gas quenching for perovskite thin film deposition. Joule 2018, 2 (7), 1205−1209. 

(161) Li, Z.; Klein, T. R.; Kim, D. H.; Yang, M.; Berry, J. J.; van Hest, M. F. A. M.; Zhu, K. Scalable fabrication of perovskite solar cells. Nat. Rev. Mater. 2018, 3 (4), 18017. 

(162) Lei, Y.; Li, Y.; Lu, C.; Yan, Q.; Wu, Y.; Babbe, F.; Gong, H.; Zhang, S.; Zhou, J.; Wang, R.; et al. Perovskite superlattices with efficient carrier dynamics. Nature 2022, 608 (7922), 317−323. 

(163) Huang, W.; Manser, J. S.; Kamat, P. V.; Ptasinska, S. Evolution of chemical composition, morphology, and photovoltaic efficiency of CH3NH3PbI3 perovskite under ambient conditions. Chem. Mater. 2016, 28 (1), 303−311. 

(164) Huang, J.; Tan, S.; Lund, P. D.; Zhou, H. Impact of H2O on organic-inorganic hybrid perovskite solar cells. Energy Environ. Sci. 2017, 10 (11), 2284−2311. 

(165) Siegler, T. D.; Dunlap-Shohl, W. A.; Meng, Y.; Yang, Y.; Kau, W. F.; Sunkari, P. P.; Tsai, C. E.; Armstrong, Z. J.; Chen, Y.-C.; Beck, D. A. C.; et al. Water-accelerated photooxidation of CH3NH3PbI3 perovskite. J. Am. Chem. Soc. 2022, 144 (12), 5552−5561. 

(166) Noel, N. K.; Stranks, S. D.; Abate, A.; Wehrenfennig, C.; Guarnera, S.; Haghighirad, A.-A.; Sadhanala, A.; Eperon, G. E.; Pathak, S. K.; Johnston, M. B.; et al. Lead-free organic-inorganic tin halide perovskites for photovoltaic applications. Energy Environ. Sci. 2014, 7 (9), 3061−3068. 

(167) Hao, F.; Stoumpos, C. C.; Cao, D. H.; Chang, R. P. H.; Kanatzidis, M. G. Lead-free solid-state organic-inorganic halide perovskite solar cells. Nat. Photonics 2014, 8 (6), 489−494. 

(168) Aktas, E.; Rajamanickam, N.; Pascual, J.; Hu, S.; Aldamasy, M. H.; Di Girolamo, D.; Li, W.; Nasti, G.; Martínez-Ferrero, E.; Wakamiya, A.; et al. Challenges and strategies toward long-term stability of lead-free tin-based perovskite solar cells. Commun. Mater. 2022, 3 (1), 104. 

(169) Liu, J. K.; Yao, H. H.; Wang, S. R.; Wu, C.; Ding, L. M.; Hao, F. Origins and suppression of Sn(II)/Sn(IV) Oxidation in tin halide perovskite solar cells. Adv. Energy Mater. 2023, 13 (23), 2300696. 

(170) Meng, Y.; Sunkari, P. P.; Meilă, M.; Hillhouse, H. W. Chemical reaction kinetics of the decomposition of low-bandgap tinlead halide perovskite films and the effect on the ambipolar diffusion length. ACS Energy Lett. 2023, 8 (4), 1688−1696. 

(171) Chen, L.; Fu, S.; Li, Y.; Sun, N.; Yan, Y.; Song, Z. On the durability of tin-containing perovskite solar cells. Adv. Sci. 2024, 11 (1), 2304811. 

(172) Goyal, A.; McKechnie, S.; Pashov, D.; Tumas, W.; van Schilfgaarde, M.; Stevanovic, V. Origin of pronounced nonlinear band gap behavior in lead-tin hybrid perovskite alloys. Chem. Mater. 2018, 30 (11), 3920−3928. 

(173) Awais, M.; Kirsch, R. L.; Yeddu, V.; Saidaminov, M. I. Tin halide perovskites going forward: Frost diagrams offer hints. ACS Mater. Lett. 2021, 3 (3), 299−307. 

(174) Leijtens, T.; Prasanna, R.; Gold-Parker, A.; Toney, M. F.; McGehee, M. D. Mechanism of tin oxidation and stabilization by lead substitution in tin halide perovskites. ACS Energy Lett. 2017, 2 (9), 2159−2165. 

(175) Meggiolaro, D.; Ricciarelli, D.; Alasmari, A. A.; Alasmary, F. A. S.; De Angelis, F. Tin versus lead redox chemistry modulates charge trapping and self-doping in tin/lead iodide perovskites. J. Phys. Chem. Lett. 2020, 11 (9), 3546−3556. 

(176) Mundt, L. E.; Tong, J.; Palmstrom, A. F.; Dunfield, S. P.; Zhu, K.; Berry, J. J.; Schelhas, L. T.; Ratcliff, E. L. Surface-activated corrosion in tin-lead halide perovskite solar cells. ACS Energy Lett. 2020, 5 (11), 3344−3351. 

(177) Xu, P.; He, H.; Ding, J.; Wang, P.; Piao, H.; Bao, J.; Zhang, W.; Wu, X.; Xu, L.; Lin, P.; et al. Simultaneous passivation of the SnO2/perovskite interface and perovskite absorber layer in perovskite solar cells using KF surface treatment. ACS Appl. Energy Mater. 2021, 4 (10), 10921−10930. 

(178) Lanzetta, L.; Webb, T.; Zibouche, N.; Liang, X.; Ding, D.; Min, G.; Westbrook, R. J. E.; Gaggio, B.; Macdonald, T. J.; Islam, M. S.; et al. Degradation mechanism of hybrid tin-based perovskite solar cells and the critical role of tin (IV) iodide. Nat. Commun. 2021, 12 (1), 2853. 

(179) Mundt, L. E.; Tong, J. H.; Palmstrom, A. F.; Dunfield, S. P.; Zhu, K.; Berry, J. J.; Schelhas, L. T.; Ratcliff, E. L. Surface-activated corrosion in tin-lead halide perovskite solar cells. ACS Energy Lett. 2020, 5 (11), 3344−3351. 

(180) Chen, M.; Dong, Q.; Xiao, C.; Zheng, X.; Dai, Z.; Shi, Y.; Luther, J. M.; Padture, N. P. Lead-free flexible perovskite solar cells with interfacial native oxide have > 10% efficiency and simultaneously enhanced stability and reliability. ACS Energy Lett. 2022, 7 (7), 2256− 2264. 

(181) Samu, G. F.; Balog, A.; De Angelis, F.; Meggiolaro, D.; Kamat, P. V.; Janáky, C. Electrochemical hole injection selectively expels iodide from mixed halide perovskite films. J. Am. Chem. Soc. 2019, 141 (27), 10812−10820. 

(182) Saidaminov, M. I.; Spanopoulos, I.; Abed, J.; Ke, W. J.; Wicks, J.; Kanatzidis, M. G.; Sargent, E. H. Conventional solvent oxidizes Sn(II) in perovskite inks. ACS Energy Lett. 2020, 5 (4), 1153−1155. (183) Pascual, J.; Nasti, G.; Aldamasy, M. H.; Smith, J. A.; Flatken, M.; Phung, N.; Di Girolamo, D.; Turren-Cruz, S.-H.; Li, M.; Dallmann, A.; et al. Origin of Sn(II) oxidation in tin halide perovskites. Mater. Adv. 2020, 1 (5), 1066−1070. 

(184) Gu, F. D.; Ye, S. Y.; Zhao, Z. R.; Rao, H. X.; Liu, Z. W.; Bian, Z. Q.; Huang, C. H. Improving performance of lead-free formamidinium tin triiodide perovskite solar cells by tin source purification. Sol. RRL 2018, 2 (10), 1800136. 

(185) Lin, R.; Xiao, K.; Qin, Z.; Han, Q.; Zhang, C.; Wei, M.; Saidaminov, M. I.; Gao, Y.; Xu, J.; Xiao, M.; et al. Monolithic allperovskite tandem solar cells with 24.8% efficiency exploiting comproportionation to suppress Sn(II) oxidation in precursor ink. Nat. Energy 2019, 4 (10), 864−873. 

(186) Nakamura, T.; Yakumaru, S.; Truong, M. A.; Kim, K.; Liu, J.; Hu, S.; Otsuka, K.; Hashimoto, R.; Murdey, R.; Sasamori, T.; et al. Sn(IV)-free tin perovskite films realized by in situ Sn(0) nanoparticle treatment of the precursor solution. Nat. Commun. 2020, 11 (1), 3008. 

(187) Meggiolaro, D.; Gregori, L.; De Angelis, F. Formation of a mixed valence Sn3F8 phase may explain the SnF2 stabilizing role in tinhalideperovskites. ACS Energy Lett. 2023, 8 (5), 2373−2375. 

4113 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

(188) Lu, Q.; Yang, Z.; Meng, X.; Yue, Y.; Ahmad, M. A.; Zhang, W.; Zhang, S.; Zhang, Y.; Liu, Z.; Chen, W. A review on encapsulation technology from organic light emitting diodes to organic and perovskite solar cells. Adv. Funct. Mater. 2021, 31 (23), 2100151. 

(189) Cao, J. P.; Yan, F. Recent progress in tin-based perovskite solar cells. Energy Environ. Sci. 2021, 14 (3), 1286−1325. 

(190) Kumar, M. H.; Dharani, S.; Leong, W. L.; Boix, P. P.; Prabhakar, R. R.; Baikie, T.; Shi, C.; Ding, H.; Ramesh, R.; Asta, M.; et al. Lead-free halide perovskite solar cells with high photocurrents realized through vacancy modulation. Adv. Mater. 2014, 26 (41), 7122−7127. 

(191) Chen, Q.; Luo, J.; He, R.; Lai, H.; Ren, S.; Jiang, Y.; Wan, Z.; Wang, W.; Hao, X.; Wang, Y.; et al. Unveiling roles of tin fluoride additives in high-efficiency low-bandgap mixed tin-lead perovskite solar cells. Adv. Energy Mater. 2021, 11 (29), 2101045. 

(192) Zhang, W.; Li, X.; Fu, S.; Zhao, X.; Feng, X.; Fang, J. Leadlean and MA-free perovskite solar cells with an efficiency over 20%. Joule 2021, 5 (11), 2904−2914. 

(193) Li, Z.; Chang, Z.; Wang, K.; Bai, D.; Liu, L.; Yang, Y.; Wang, L.; Wang, S.; Liu, S. 4-Hydrazinobenzoic-acid antioxidant for highefficiency Sn-Pb alloyed perovskite solar cells. Energy Technol. 2022, 10 (6), 2200217. 

(194) Wang, C.; Gu, F.; Zhao, Z.; Rao, H.; Qiu, Y.; Cai, Z.; Zhan, G.; Li, X.; Sun, B.; Yu, X.; et al. Self-repairing tin-based perovskite solar cells with a breakthrough efficiency over 11%. Adv. Mater. 2020, 32 (31), 1907623. 

(195) Wen, Q.; Duan, C.; Zou, F.; Luo, D.; Li, J.; Liu, Z.; Wang, J.; Yan, K. All-inorganic CsPb1-xSnxI2Br perovskites mediated by Dicyandiamide additive for efficient 4-terminal tandem solar cell. Chem. Eng. J. 2023, 452, 139697. 

(196) He, D.; Chen, P.; Hao, M.; Lyu, M.; Wang, Z.; Ding, S.; Lin, T.; Zhang, C.; Wu, X.; Moore, E.; et al. Accelerated redox reactions enable stable tin-lead mixed perovskite solar cells. Angew. Chem., Int. Ed. 2024, 63, No. e202317446. 

(197) Yu, D.; Pan, M.; Liu, G.; Jiang, X.; Wen, X.; Li, W.; Chen, S.; Zhou, W.; Wang, H.; Lu, Y. Electron-withdrawing organic ligand for high-efficiency all-perovskite tandem solar cells. Nat. Energy 2024, 9, 298−307. 

(198) Savill, K. J.; Ulatowski, A. M.; Farrar, M. D.; Johnston, M. B.; Snaith, H. J.; Herz, L. M. Impact of tin fluoride additive on the properties of mixed tin-lead iodide perovskite semiconductors. Adv. Funct. Mater. 2020, 30 (52), 2005594. 

(199) Burstein, E. Anomalous optical absorption limit in InSb. Phys. Rev. 1954, 93 (3), 632−633. 

(200) Moss, T. S. The interpretation of the properties of indium antimonide. Proc. Phys. Soc. B 1954, 67 (10), 775−782. 

(201) Park, C.; Choi, J.; Min, J.; Cho, K. Suppression of oxidative degradation of tin-lead hybrid organometal halide perovskite solar cells by Ag doping. ACS Energy Lett. 2020, 5 (10), 3285−3294. 

(202) Kama, A.; Tirosh, S.; Itzhak, A.; Ejgenberg, M.; Cahen, D. New Pb-free stable Sn-Ge solid solution halide perovskites fabricated by spray deposition. ACS Appl. Energy Mater. 2022, 5 (3), 3638− 3646. 

(203) Altinkaya, C.; Aydin, E.; Ugur, E.; Isikgor, F. H.; Subbiah, A. S.; De Bastiani, M.; Liu, J.; Babayigit, A.; Allen, T. G.; Laquai, F.; et al. Tin oxide electron-selective layers for efficient, stable, and scalable perovskite solar cells. Adv. Mater. 2021, 33 (15), 2005504. 

(204) Lee, S. J.; Shin, S. S.; Im, J.; Ahn, T. K.; Noh, J. H.; Jeon, N. J.; Seok, S. I.; Seo, J. Reducing carrier density in formamidinium tin perovskites and its beneficial effects on stability and efficiency of perovskite solar cells. ACS Energy Lett. 2018, 3 (1), 46−53. 

(205) Diau, E. W.-G.; Jokar, E.; Rameez, M. Strategies to improve performance and stability for tin-based perovskite solar cells. ACS Energy Lett. 2019, 4 (8), 1930−1937. 

(206) Stoumpos, C. C.; Malliakas, C. D.; Kanatzidis, M. G. Semiconducting tin and lead iodide perovskites with organic cations: Phase transitions, high mobilities, and near-infrared photoluminescent properties. Inorg. Chem. 2013, 52 (15), 9019−9038. 

(207) Prasanna, R.; Leijtens, T.; Dunfield, S. P.; Raiford, J. A.; Wolf, E. J.; Swifter, S. A.; Werner, J.; Eperon, G. E.; de Paula, C.; Palmstrom, A. F.; et al. Design of low bandgap tin-lead halide perovskite solar cells to achieve thermal, atmospheric and operational stability. Nat. Energy 2019, 4 (11), 939−947. 

(208) Hu, M.; Zhang, Y.; Gong, J.; Zhou, H.; Huang, X.; Liu, M.; Zhou, Y.; Yang, S. Surface Sn(IV) hydrolysis improves inorganic SnPb perovskite solar cells. ACS Energy Lett. 2023, 8 (2), 1035−1041. 

(209) Turren-Cruz, S.-H.; Hagfeldt, A.; Saliba, M. Methylammonium-free, high-performance, and stable perovskite solar cells on a planar architecture. Science 2018, 362 (6413), 449−453. 

(210) Juarez-Perez, E. J.; Ono, L. K.; Maeda, M.; Jiang, Y.; Hawash, Z.; Qi, Y. Photodecomposition and thermal decomposition in methylammonium halide lead perovskites and inferred design principles to increase photovoltaic device stability. J. Mater. Chem. A 2018, 6 (20), 9604−9612. 

(211) Burwig, T.; Heinze, K.; Pistor, P. Thermal decomposition kinetics of FAPbI3 thin films. Phys. Rev. Mater. 2022, 6 (6), 065404. (212) Durant, B. K.; Afshari, H.; Sourabh, S.; Yeddu, V.; Bamidele, M. T.; Singh, S.; Rout, B.; Eperon, G. E.; Kim, D. Y.; Sellers, I. R. Radiation stability of mixed tin-lead halide perovskites: Implications for space applications. Sol. Energy Mater. Sol. Cells 2021, 230, 111232. (213) Lang, F.; Eperon, G. E.; Frohna, K.; Tennyson, E. M.; AlAshouri, A.; Kourkafas, G.; Bundesmann, J.; Denker, A.; West, K. G.; Hirst, L. C.; et al. Proton-radiation tolerant all-perovskite multijunction solar cells. Adv. Energy Mater. 2021, 11 (41), 2102246. 

(214) Tress, W.; Marinova, N.; Moehl, T.; Zakeeruddin, S. M.; Nazeeruddin, M. K.; Grätzel, M. Understanding the rate-dependent J- V hysteresis, slow time component, and aging in CH3NH3PbI3 perovskite solar cells: the role of a compensated electric field. Energy Environ. Sci. 2015, 8 (3), 995−1004. 

(215) van Reenen, S.; Kemerink, M.; Snaith, H. J. Modeling anomalous hysteresis in perovskite solar cells. J. Phys. Chem. Lett. 2015, 6 (19), 3808−3814. 

(216) Zhang, Y.; Liu, M.; Eperon, G. E.; Leijtens, T. C.; McMeekin, D.; Saliba, M.; Zhang, W.; de Bastiani, M.; Petrozza, A.; Herz, L. M.; et al. Charge selective contacts, mobile ions and anomalous hysteresis in organic-inorganic perovskite solar cells. Mater. Horiz. 2015, 2 (3), 315−322. 

(217) Khenkin, M. V.; K M, A.; Katz, E. A.; Visoly-Fisher, I. Biasdependent degradation of various solar cells: Lessons for stability of perovskite photovoltaics. Energy Environ. Sci. 2019, 12 (2), 550−558. (218) Cheng, Y.; Li, H.-W.; Qing, J.; Yang, Q.-D.; Guan, Z.; Liu, C.; Cheung, S. H.; So, S. K.; Lee, C.-S.; Tsang, S.-W. The detrimental effect of excess mobile ions in planar CH3NH3PbI3 perovskite solar cells. J. Mater. Chem. A 2016, 4 (33), 12748−12755. 

(219) Zhong, Y.; Yang, J.; Wang, X.; Liu, Y.; Cai, Q.; Tan, L.; Chen, Y. Inhibition of ion migration for highly efficient and stable perovskite solar cells. Adv. Mater. 2023, 35 (52), 2302552. 

(220) Le Corre, V. M.; Diekmann, J.; Peña-Camargo, F.; Thiesbrummel, J.; Tokmoldin, N.; Gutierrez-Partida, E.; Peters, K. P.; Perdigón-Toro, L.; Futscher, M. H.; Lang, F.; et al. Quantification of efficiency losses due to mobile ions in perovskite solar cells via fast hysteresis measurements. Sol. RRL 2022, 6 (4), 2100772. 

(221) Belisle, R. A.; Nguyen, W. H.; Bowring, A. R.; Calado, P.; Li, X.; Irvine, S. J. C.; McGehee, M. D.; Barnes, P. R. F.; O’Regan, B. C. Interpretation of inverted photocurrent transients in organic lead halide perovskite solar cells: proof of the field screening by mobile ions and determination of the space charge layer widths. Energy Environ. Sci. 2017, 10 (1), 192−204. 

(222) Bertoluzzi, L.; Belisle, R. A.; Bush, K. A.; Cheacharoen, R.; McGehee, M. D.; O’Regan, B. C. In situ measurement of electric-field screening in hysteresis-free PTAA/FA0.83Cs0.17Pb(I0.83Br0.17)3/C60 perovskite solar cells gives an ion mobility of ∼ 3 × 10<sup>−-7</sup> cm<sup>2</sup> /(V s), 2 orders of magnitude faster than reported for metal-oxidecontacted perovskite cells with hysteresis. J. Am. Chem. Soc. 2018, 140 (40), 12775−12784. 

(223) Futscher, M. H.; Lee, J. M.; McGovern, L.; Muscarella, L. A.; Wang, T.; Haider, M. I.; Fakharuddin, A.; Schmidt-Mende, L.; Ehrler, 

4114 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

B. Quantification of ion migration in CH3NH3PbI3 perovskite solar cells by transient capacitance measurements. Mater. Horiz. 2019, 6 (7), 1497−1503. 

(224) Herterich, J.; Unmussig,̈ M.; Loukeris, G.; Kohlstädt, M.; Wurfel,̈ U. Ion movement explains huge VOC increase despite almost unchanged internal quasi-Fermi-level splitting in planar perovskite solar cells. Energy Technol. 2021, 9 (5), 2001104. 

(225) Thiesbrummel, J.; Le Corre, V. M.; Peña-Camargo, F.; Perdigón-Toro, L.; Lang, F.; Yang, F.; Grischek, M.; GutierrezPartida, E.; Warby, J.; Farrar, M. D.; et al. Universal current losses in perovskite solar cells due to mobile ions. Adv. Energy Mater. 2021, 11 (34), 2101447. 

(226) Dey, K.; Ghosh, D.; Pilot, M.; Pering, S. R.; Roose, B.; Deswal, P.; Senanayak, S. P.; Cameron, P. J.; Islam, M. S.; Stranks, S. D. Substitution of lead with tin suppresses ionic transport in halide perovskite optoelectronics. Energy Environ. Sci. 2024, 17, 760. 

(227) Senanayak, S. P.; Dey, K.; Shivanna, R.; Li, W.; Ghosh, D.; Zhang, Y.; Roose, B.; Zelewski, S. J.; Andaji-Garmaroudi, Z.; Wood, W.; et al. Charge transport in mixed metal halide perovskite semiconductors. Nat. Mater. 2023, 22 (2), 216−224. 

(228) Yang, F.; MacQueen, R. W.; Menzel, D.; Musiienko, A.; AlAshouri, A.; Thiesbrummel, J.; Shah, S.; Prashanthan, K.; Abou-Ras, D.; Korte, L.; et al. Rubidium iodide reduces recombination losses in methylammonium-free tin-lead perovskite solar cells. Adv. Energy Mater. 2023, 13, 2204339. 

(229) Thiesbrummel, J.; Gutierrez-Partida, E.; Zu, F.; Camargo, F.; Zeiske, S.; Diekmann, J.; Ye, F.; Peters, K.; Brinkmann, K.; Warby, J.; Jeangros, Q.; Lang, F.; Wu, Y.; Albrecht, S.; Riedl, T.; Armin, A.; Neher, D.; Koch, N.; Corre, V.; Snaith, H.; Stolterfoht, M.; Shah, S. Ion induced field screening governs the early performance degradation of perovskite solar cells. Research Square 2023, DOI: 10.21203/rs.3.rs-2495973/v1. 

(230) Li, Q.; Zheng, Y. C.; Wei, Z. P.; Xie, J.; Zou, C.; Liu, X. Y.; Liu, D.; Zhou, Z. R.; Yang, H. G.; Yang, S.; et al. Halide diffusion equilibrium and its impact on efficiency evolution of perovskite solar cells. Adv. Energy Mater. 2022, 12 (48), 2202982. 

(231) Wolff, C. M.; Caprioglio, P.; Stolterfoht, M.; Neher, D. Nonradiative recombination in perovskite solar cells: The role of interfaces. Adv. Mater. 2019, 31 (52), 1902762. 

(232) Zhang, K.; Forberich, K.; Luer,̈ L.; Cerrillo, J. G.; Meng, W.; Du, X.; Le Corre, V. M.; Zhao, Y.; Niu, T.; Xue, Q.; et al. Understanding the limitations of charge transporting layers in mixed lead-tin halide perovskite solar cells. Adv. Energy Sustain. Res. 2022, 3 (3), 2100156. 

(233) Diekmann, J.; Caprioglio, P.; Futscher, M. H.; Le Corre, V. M.; Reichert, S.; Jaiser, F.; Arvind, M.; Toro, L. P.; Gutierrez-Partida, E.; Peña-Camargo, F.; et al. Pathways toward 30% efficient singlejunction perovskite solar cells and the role of mobile ions. Sol. RRL 2021, 5 (8), 2100219. 

(234) Jena, A. K.; Kulkarni, A.; Miyasaka, T. Halide perovskite photovoltaics: Background, status, and future prospects. Chem. Rev. 2019, 119 (5), 3036−3103. 

(235) Ogomi, Y.; Morita, A.; Tsukamoto, S.; Saitho, T.; Fujikawa, N.; Shen, Q.; Toyoda, T.; Yoshino, K.; Pandey, S. S.; Ma, T.; et al. CH3NH3SnxPb(1-x)I3 perovskite solar cells covering up to 1060 nm. J. Phys. Chem. Lett. 2014, 5 (6), 1004−1011. 

(236) Hao, F.; Stoumpos, C. C.; Chang, R. P. H.; Kanatzidis, M. G. Anomalous band gap behavior in mixed Sn and Pb perovskites enables broadening of absorption spectrum in solar cells. J. Am. Chem. Soc. 2014, 136 (22), 8094−8099. 

(237) Chang, C.-Y.; Tsai, B.-C.; Hsiao, Y.-C.; Lin, M.-Z.; Meng, H.F. Solution-processed conductive interconnecting layer for highlyefficient and long-term stable monolithic perovskite tandem solar cells. Nano Energy 2019, 55, 354−367. 

(238) Zhang, W.; Liu, H.; Qi, X.; Yu, Y.; Zhou, Y.; Xia, Y.; Cui, J.; Shi, Y.; Chen, R.; Wang, H.-L. Oxalate pushes efficiency of CsPb0.7Sn0.3IBr2 based all-inorganic perovskite solar cells to over 14%. Adv. Sci. 2022, 9 (11), 2106054. 

(239) Liu, M.; Chen, Z.; Chen, Z.; Yip, H.-L.; Cao, Y. A cascadetype electron extraction design for efficient low-bandgap perovskite solar cells based on a conventional structure with suppressed opencircuit voltage loss. Mater. Chem. Front. 2019, 3 (3), 496−504. 

(240) McMeekin, D. P.; Mahesh, S.; Noel, N. K.; Klug, M. T.; Lim, J.; Warby, J. H.; Ball, J. M.; Herz, L. M.; Johnston, M. B.; Snaith, H. J. Solution-processed all-perovskite multi-junction solar cells. Joule 2019, 3 (2), 387−401. 

(241) Yuan, J.; Jiang, Y.; He, T.; Shi, G.; Fan, Z.; Yuan, M. Twodimensional perovskite capping layer for stable and efficient tin-lead perovskite solar cells. Sci. China Chem. 2019, 62 (5), 629−636. 

(242) Wang, J.; Uddin, M. A.; Chen, B.; Ying, X.; Ni, Z.; Zhou, Y.; Li, M.; Wang, M.; Yu, Z.; Huang, J. Enhancing photostability of Sn-Pb perovskite solar cells by an alkylammonium pseudo-halogen additive. Adv. Energy Mater. 2023, 13 (15), 2204115. 

(243) Cappel, U. B.; Daeneke, T.; Bach, U. Oxygen-induced doping of Spiro-MeOTAD in solid-state dye-sensitized solar cells and its impact on device performance. Nano Lett. 2012, 12 (9), 4925−4931. 

(244) Reddy, S. H.; Di Giacomo, F.; Di Carlo, A. Low-temperatureprocessed stable perovskite solar cells and modules: A comprehensive review. Adv. Energy Mater. 2022, 12 (13), 2103534. 

(245) Kaltenbrunner, M.; Adam, G.; Głowacki, E. D.; Drack, M.; Schwödiauer, R.; Leonat, L.; Apaydin, D. H.; Groiss, H.; Scharber, M. C.; White, M. S.; et al. Flexible high power-per-weight perovskite solar cells with chromium oxide-metal contacts for improved stability in air. Nat. Mater. 2015, 14 (10), 1032−1039. 

(246) Yang, Z.; Rajagopal, A.; Chueh, C.-C.; Jo, S. B.; Liu, B.; Zhao, T.; Jen, A. K. Y. Stable low-bandgap Pb-Sn binary perovskites for tandem solar cells. Adv. Mater. 2016, 28 (40), 8990−8997. 

(247) Liao, W.; Zhao, D.; Yu, Y.; Shrestha, N.; Ghimire, K.; Grice, C. R.; Wang, C.; Xiao, Y.; Cimaroli, A. J.; Ellingson, R. J.; et al. Fabrication of efficient low-bandgap perovskite solar cells by combining formamidinium tin iodide with methylammonium lead iodide. J. Am. Chem. Soc. 2016, 138 (38), 12360−12363. 

(248) Liu, X.; Yang, Z.; Chueh, C.-C.; Rajagopal, A.; Williams, S. T.; Sun, Y.; Jen, A. K. Y. Improved efficiency and stability of Pb-Sn binary perovskite solar cells by Cs substitution. J. Mater. Chem. A 2016, 4 (46), 17939−17945. 

(249) Yang, Z.; Rajagopal, A.; Jo, S. B.; Chueh, C.-C.; Williams, S.; Huang, C.-C.; Katahara, J. K.; Hillhouse, H. W.; Jen, A. K. Y. Stabilized wide bandgap perovskite solar cells by tin substitution. Nano Lett. 2016, 16 (12), 7739−7747. 

(250) Zong, Y.; Wang, N.; Zhang, L.; Ju, M.-G.; Zeng, X. C.; Sun, X. W.; Zhou, Y.; Padture, N. P. Homogenous alloys of formamidinium lead triiodide and cesium tin triiodide for efficient ideal-bandgap perovskite solar cells. Angew. Chem., Int. Ed. 2017, 56 (41), 12658− 12662. 

(251) Prasanna, R.; Gold-Parker, A.; Leijtens, T.; Conings, B.; Babayigit, A.; Boyen, H.-G.; Toney, M. F.; McGehee, M. D. Band gap tuning via lattice contraction and octahedral tilting in perovskite materials for photovoltaics. J. Am. Chem. Soc. 2017, 139 (32), 11117− 11124. 

(252) Yang, Z.; Rajagopal, A.; Jen, A. K. Y. Ideal bandgap organicinorganic hybrid perovskite solar cells. Adv. Mater. 2017, 29 (47), 1704418. 

(253) Tosado, G. A.; Lin, Y.-Y.; Zheng, E.; Yu, Q. Impact of cesium on the phase and device stability of triple cation Pb-Sn double halide perovskite films and solar cells. J. Mater. Chem. A 2018, 6 (36), 17426−17436. 

(254) Li, C.; Song, Z.; Zhao, D.; Xiao, C.; Subedi, B.; Shrestha, N.; Junda, M. M.; Wang, C.; Jiang, C.-S.; Al-Jassim, M.; et al. Reducing saturation-current density to realize high-efficiency low-bandgap mixed tin-lead halide perovskite solar cells. Adv. Energy Mater. 2019, 9 (3), 1803135. 

(255) Zhu, Z.; Li, N.; Zhao, D.; Wang, L.; Jen, A. K. Y. Improved efficiency and stability of Pb/Sn binary perovskite solar cells fabricated by galvanic displacement reaction. Adv. Energy Mater. 2019, 9 (7), 1802774. 

4115 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

(256) Ke, W.; Spanopoulos, I.; Tu, Q.; Hadar, I.; Li, X.; Shekhawat, G. S.; Dravid, V. P.; Kanatzidis, M. G. Ethylenediammonium-based “hollow” Pb/Sn perovskites with ideal band gap yield solar cells with higher efficiency and stability. J. Am. Chem. Soc. 2019, 141 (21), 8627−8637. 

(257) Kapil, G.; Bessho, T.; Ng, C. H.; Hamada, K.; Pandey, M.; Kamarudin, M. A.; Hirotani, D.; Kinoshita, T.; Minemoto, T.; Shen, Q.; et al. Strain relaxation and light management in tin-lead perovskite solar cells to achieve high efficiencies. ACS Energy Lett. 2019, 4 (8), 1991−1998. 

(258) Ball, J. M.; Buizza, L.; Sansom, H. C.; Farrar, M. D.; Klug, M. T.; Borchert, J.; Patel, J.; Herz, L. M.; Johnston, M. B.; Snaith, H. J. Dual-source coevaporation of low-bandgap FA1-xCsxSn1-yPbyI3 perovskites for photovoltaics. ACS Energy Lett. 2019, 4 (11), 2748−2756. 

(259) Moghadamzadeh, S.; Hossain, I. M.; Duong, T.; Gharibzadeh, S.; Abzieher, T.; Pham, H.; Hu, H.; Fassl, P.; Lemmer, U.; Nejand, B. A.; et al. Triple-cation low-bandgap perovskite thin-films for highefficiency four-terminal all-perovskite tandem solar cells. J. Mater. Chem. A 2020, 8 (46), 24608−24619. 

(260) Tong, J.; Gong, J.; Hu, M.; Yadavalli, S. K.; Dai, Z.; Zhang, F.; Xiao, C.; Hao, J.; Yang, M.; Anderson, M. A.; et al. High-performance methylammonium-free ideal-band-gap perovskite solar cells. Matter 2021, 4 (4), 1365−1376. 

(261) Zhu, L.; Yuh, B.; Schoen, S.; Li, X.; Aldighaithir, M.; Richardson, B. J.; Alamer, A.; Yu, Q. Solvent-molecule-mediated manipulation of crystalline grains for efficient planar binary lead and tin triiodide perovskite solar cells. Nanoscale 2016, 8 (14), 7621− 7630. 

(262) Liu, C.; Fan, J.; Li, H.; Zhang, C.; Mai, Y. Highly efficient perovskite solar cells with substantial reduction of lead content. Sci. Rep. 2016, 6 (1), 35705. 

(263) Zhao, B.; Abdi-Jalebi, M.; Tabachnyk, M.; Glass, H.; Kamboj, V. S.; Nie, W.; Pearson, A. J.; Puttisong, Y.; Gödel, K. C.; Beere, H. E.; et al. High open-circuit voltages in tin-rich low-bandgap perovskitebased planar heterojunction photovoltaics. Adv. Mater. 2017, 29 (2), 1604744. 

(264) Li, L.; Zhang, F.; Hao, Y.; Sun, Q.; Li, Z.; Wang, H.; Cui, Y.; Zhu, F. High efficiency planar Sn-Pb binary perovskite solar cells: controlled growth of large grains via a one-step solution fabrication process. J. Mater. Chem. C 2017, 5 (9), 2360−2367. 

(265) Liu, J.; Wang, G.; Song, Z.; He, X.; Luo, K.; Ye, Q.; Liao, C.; Mei, J. FAPb1-xSnxI3 mixed metal halide perovskites with improved light harvesting and stability for efficient planar heterojunction solar cells. J. Mater. Chem. A 2017, 5 (19), 9097−9106. 

(266) Zhao, J.; Wei, L.; Jia, C.; Tang, H.; Su, X.; Ou, Y.; Liu, Z.; Wang, C.; Zhao, X.; Jin, H.; et al. Metallic tin substitution of organic lead perovskite films for efficient solar cells. J. Mater. Chem. A 2018, 6 (41), 20224−20232. 

(267) Ji, L.; Zhang, X.; Zhang, T.; Wang, Y.; Wang, F.; Zhong, Z.; Chen, Z. D.; Xiao, Z.; Chen, L.; Li, S. Band alignment of Pb-Sn mixed triple cation perovskites for inverted solar cells with negligible hysteresis. J. Mater. Chem. A 2019, 7 (15), 9154−9162. 

(268) Yang, Z.; Zhang, X.; Yang, W.; Eperon, G. E.; Ginger, D. S. Tin-lead alloying for efficient and stable all-inorganic perovskite solar cells. Chem. Mater. 2020, 32 (7), 2782−2794. 

(269) Klug, M. T.; Milot, R. L.; Patel, J. B.; Green, T.; Sansom, H. C.; Farrar, M. D.; Ramadan, A. J.; Martani, S.; Wang, Z.; Wenger, B.; et al. Metal composition influences optoelectronic quality in mixedmetal lead-tin triiodide perovskite solar absorbers. Energy Environ. Sci. 2020, 13 (6), 1776−1787. 

(270) Kuan, C.-H.; Shen, H.-H.; Lin, C.-F. Low photoactive phase temperature all-inorganic, tin-lead mixed perovskite solar cell. RSC Adv. 2021, 11 (6), 3264−3271. 

(271) Ambrosio, F.; Meggiolaro, D.; Almutairi, T. M.; De Angelis, F. Composition-dependent struggle between iodine and tin chemistry at the surface of mixed tin/lead perovskites. ACS Energy Lett. 2021, 6 (3), 969−976. 

(272) Warby, J.; Zu, F. S.; Zeiske, S.; Gutierrez-Partida, E.; Frohloff, L.; Kahmann, S.; Frohna, K.; Mosconi, E.; Radicchi, E.; Lang, F.; et al. 

Understanding performance limiting interfacial recombination in pin perovskite solar cells. Adv. Energy Mater. 2022, 12 (12), 2103567. 

(273) Ye, F.; Zhang, S.; Warby, J.; Wu, J.; Gutierrez-Partida, E.; Lang, F.; Shah, S.; Saglamkaya, E.; Sun, B.; Zu, F.; et al. Overcoming C60-induced interfacial recombination in inverted perovskite solar cells by electron-transporting carborane. Nat. Commun. 2022, 13 (1), 7454. 

(274) Shi, Y.; Rojas-Gatjens, E.; Wang, J.; Pothoof, J.; Giridharagopal, R.; Ho, K.; Jiang, F.; Taddei, M.; Yang, Z.; Sanehira, E. M.; et al. (3-Aminopropyl)trimethoxysilane surface passivation improves perovskite solar cell performance by reducing surface recombination velocity. ACS Energy Lett. 2022, 7 (11), 4081− 4088. 

(275) Zhao, L.; Li, Q.; Hou, C.-H.; Li, S.; Yang, X.; Wu, J.; Zhang, S.; Hu, Q.; Wang, Y.; Zhang, Y.; et al. Chemical polishing of perovskite surface enhances photovoltaic performances. J. Am. Chem. Soc. 2022, 144 (4), 1700−1708. 

(276) Lin, Y.; Liu, Y.; Chen, S.; Wang, S.; Ni, Z.; Van Brackle, C. H.; Yang, S.; Zhao, J.; Yu, Z.; Dai, X.; et al. Revealing defective nanostructured surfaces and their impact on the intrinsic stability of hybrid perovskites. Energy Environ. Sci. 2021, 14 (3), 1563−1572. 

(277) Kedia, M.; Rai, M.; Phirke, H.; Aranda, C. A.; Das, C.; Chirvony, V.; Boehringer, S.; Kot, M.; Byranvand, M. M.; Flege, J. I.; et al. Light makes right: Laser polishing for surface modification of perovskite solar cells. ACS Energy Lett. 2023, 8, 2603−2610. 

(278) Pan, L.; Li, H.; Chang, B.; Yin, L. Crystallization and defect regulation in Sn-Pb perovskite solar cells via optimized anti-solvent passivation strategy. Sol. RRL 2022, 6 (10), 2200398. 

(279) Jiang, Q.; Zhao, Y.; Zhang, X.; Yang, X.; Chen, Y.; Chu, Z.; Ye, Q.; Li, X.; Yin, Z.; You, J. Surface passivation of perovskite film for efficient solar cells. Nat. Photonics 2019, 13 (7), 460−466. 

(280) Tian, C.; Zhang, Z.; Sun, A.; Liang, J.; Zheng, Y.; Wu, X.; Liu, Y.; Tang, C.; Chen, C.-C. Tuning phase stability and interfacial dipole for efficient methylammonium-free Sn-Pb perovskite solar cells. Nano Energy 2023, 116, 108848. 

(281) Jiang, T.; Xu, X.; Lan, Z.; Chen, Z.; Chen, X.; Liu, T.; Huang, S.; Yang, Y. Efficient MA-free Pb-Sn alloyed low-bandgap perovskite solar cells via surface passivation. Nano Energy 2022, 101, 107596. 

(282) Zhang, J.; Hu, H.; Zhang, Y.; Liang, Z.; Zhu, P.; Li, Z.; Wang, D.; Chen, J.; Zeng, J.; Jiang, Z.; et al. Tuning perovskite surface polarity via dipole moment engineering for efficient hole-transportlayer-free Sn-Pb mixed-perovskite solar cells. ACS Appl. Mater. Interfaces 2023, 15 (12), 15321−15331. 

(283) Xue, X.; Zhang, L.; Hao, Y.; Ren, J.; Wu, Y.; Sun, Q.; Cui, Y.; Wang, A.; Hao, Y.; Li, S. High performance 2D/3D tin-lead perovskite solar cells achieved by phenethylamine acetate posttreatment. ACS Mater. Lett. 2023, 5, 1601−1610. 

(284) Chen, H.; Teale, S.; Chen, B.; Hou, Y.; Grater, L.; Zhu, T.; Bertens, K.; Park, S. M.; Atapattu, H. R.; Gao, Y.; et al. Quantum-sizetuned heterostructures enable efficient and stable inverted perovskite solar cells. Nat. Photonics 2022, 16 (5), 352−358. 

(285) Kong, T.; Zhang, Y.; Liu, X.; Bi, D. Multifunctional effects of biguanide derivative in the application of highly efficient tin-lead perovskite solar cells. Small 2023, 2307206. 

(286) Zhang, K.; Späth, A.; Almora, O.; Le Corre, V. M.; Wortmann, J.; Zhang, J.; Xie, Z.; Barabash, A.; Hammer, M. S.; Heumuller,̈ T.; et al. Suppressing nonradiative recombination in lead-tin perovskite solar cells through bulk and surface passivation to reduce open circuit voltage losses. ACS Energy Lett. 2022, 7 (10), 3235−3243. 

(287) Meng, R.; Li, C.; Shi, J.; Wan, Z.; Li, Z.; Zhi, C.; Zhang, Y.; Li, Z. Reductive 2D capping layers through dopamine salt incorporation for Pb-Sn mixed perovskite solar cells. ACS Energy Lett. 2023, 8 (12), 5206−5214. 

(288) Song, J.; Kong, T.; Zhang, Y.; Liu, X.; Saliba, M.; Bi, D. Synergistic effect of sodium cyanoborohydride in Pb-Sn perovskite solar cells. Adv. Funct. Mater. 2023, 33 (51), 2304201. 

(289) Sanchez-Diaz, J.; Sánchez, R. S.; Masi, S.; Krecmarová,̂ M.; Alvarez, A. O.; Barea, E. M.; Rodriguez-Romero, J.; Chirvony, V. S.; Sánchez-Royo, J. F.; Martinez-Pastor, J. P.; et al. Tin perovskite solar 

4116 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

cells with > 1,300 h of operational stability in N2 through a synergistic chemical engineering approach. Joule 2022, 6 (4), 861−883. 

(290) Lu, J.; Wang, H.; Fan, T.; Ma, D.; Wang, C.; Wu, S.; Li, X. Back interface passivation for efficient low-bandgap perovskite solar cells and photodetectors. Nanomaterials 2022, 12 (12), 2065. 

(291) Koushik, D.; Verhees, W. J. H.; Kuang, Y.; Veenstra, S.; Zhang, D.; Verheijen, M. A.; Creatore, M.; Schropp, R. E. I. Highefficiency humidity-stable planar perovskite solar cells based on atomic layer architecture. Energy Environ. Sci. 2017, 10 (1), 91−100. 

(292) Brinkmann, K. O.; Gahlmann, T.; Riedl, T. Atomic layer deposition of functional layers in planar perovskite solar cells. Sol. RRL 2020, 4 (1), 1900332. 

(293) Das, C.; Kot, M.; Hellmann, T.; Wittich, C.; Mankel, E.; Zimmermann, I.; Schmeisser, D.; Khaja Nazeeruddin, M.; Jaegermann, W. Atomic layer-deposited aluminum oxide hinders iodide migration and stabilizes perovskite solar cells. Cell Reports Physical Science 2020, 1 (7), 100112. 

(294) Choi, E.; Lee, J.-W.; Anaya, M.; Mirabelli, A.; Shim, H.; Strzalka, J.; Lim, J.; Yun, S.; Dubajic, M.; Lim, J.; et al. Synergetic effect of aluminum oxide and organic halide salts on two-dimensional perovskite layer formation and stability enhancement of perovskite solar cells. Adv. Energy Mater. 2023, 13 (39), 2301717. 

(295) Yang, Y.; Cheng, S.; Zhu, X.; Li, S.; Zheng, Z.; Zhao, K.; Ji, L.; Li, R.; Liu, Y.; Liu, C. Inverted perovskite solar cells with over 2,000 h operational stability at 85 °C using fixed charge passivation. Nat. Energy 2024, 9, 37. 

(296) Kartamyshev, A. I.; Vo, D. D.; Lipnitskii, A. G. The interaction between light impurities and vacancies in titanium and aluminum metals: A DFT study. St. Petersburg Polytechnical University Journal: Physics and Mathematics 2016, 2 (2), 96−102. 

(297) Ping, F.-P.; Hu, Q.-M.; Bakulin, A. V.; Kulkova, S. E.; Yang, R. Alloying effects on properties of Al2O3 and TiO2 in connection with oxidation resistance of TiAl. Intermetallics 2016, 68, 57−62. 

(298) Boyd, C. C.; Shallcross, R. C.; Moot, T.; Kerner, R.; Bertoluzzi, L.; Onno, A.; Kavadiya, S.; Chosy, C.; Wolf, E. J.; Werner, J.; et al. Overcoming redox reactions at perovskite-nickel oxide interfaces to boost voltages in perovskite solar cells. Joule 2020, 4 (8), 1759−1775. 

(299) Li, J.; Liang, H.; Xiao, C.; Jia, X.; Guo, R.; Chen, J.; Guo, X.; Luo, R.; Wang, X.; Li, M. Enhancing the efficiency and longevity of inverted perovskite solar cells with antimony-doped tin oxides. Nat. Energy 2024, 9, 308−315. 

(300) Ai, M.; Chen, M.; Yang, S. Recent advances in functionalized fullerenes in perovskite solar cells. Chin. J. Chem. 2023, 41 (18), 2337−2353. 

(301) Fang, Y.; Bi, C.; Wang, D.; Huang, J. The functions of fullerenes in hybrid perovskite solar cells. ACS Energy Lett. 2017, 2 (4), 782−794. 

(302) Rajagopal, A.; Liang, P.-W.; Chueh, C.-C.; Yang, Z.; Jen, A. K. Y. Defect passivation via a graded fullerene heterojunction in lowbandgap Pb-Sn binary perovskite photovoltaics. ACS Energy Lett. 2017, 2 (11), 2531−2539. 

(303) Kapil, G.; Bessho, T.; Maekawa, T.; Baranwal, A. K.; Zhang, Y.; Kamarudin, M. A.; Hirotani, D.; Shen, Q.; Segawa, H.; Hayase, S. Tin-lead perovskite fabricated via ethylenediamine interlayer guides to the solar cell efficiency of 21.74%. Adv. Energy Mater. 2021, 11 (25), 2101069. 

(304) Liang, Z.; Xu, H.; Zhang, Y.; Liu, G.; Chu, S.; Tao, Y.; Xu, X.; Xu, S.; Zhang, L.; Chen, X.; et al. A selective targeting anchor strategy affords efficient and stable ideal-bandgap perovskite solar cells. Adv. Mater. 2022, 34 (18), 2110241. 

(305) Luo, J.; He, R.; Lai, H.; Chen, C.; Zhu, J.; Xu, Y.; Yao, F.; Ma, T.; Luo, Y.; Yi, Z.; et al. Improved carrier management via a multifunctional modifier for high-quality low-bandgap Sn-Pb perovskites and efficient all-perovskite tandem solar cells. Adv. Mater. 2023, 35 (22), No. e2300352. 

(306) Zheng, Y.; Wu, X.; Zhuang, R.; Tian, C.; Sun, A.; Tang, C.; Liu, Y.; Hua, Y.; Chen, C. C. Managing interfacial hot-carrier cooling and extraction kinetics for inverted MA-free perovskite solar cells over 

23% efficiency via Dion-Jacobson 2D capping layer. Adv. Funct. Mater. 2023, 33 (25), 2300576. 

(307) Chen, H.; Maxwell, A.; Li, C.; Teale, S.; Chen, B.; Zhu, T.; Ugur, E.; Harrison, G.; Grater, L.; Wang, J.; et al. Regulating surface potential maximizes voltage in all-perovskite tandems. Nature 2023, 613 (7945), 676−681. 

(308) Li, X.; Hoffman, J. M.; Kanatzidis, M. G. The 2D halide perovskite rulebook: How the spacer influences everything from the structure to optoelectronic device efficiency. Chem. Rev. 2021, 121 (4), 2230−2291. 

(309) Euvrard, J.; Yan, Y.; Mitzi, D. B. Electrical doping in halide perovskites. Nat. Rev. Mater. 2021, 6 (6), 531−549. 

(310) Meggiolaro, D.; Ricciarelli, D.; Alasmari, A. A.; Alasmary, F. A. S.; De Angelis, F. Tin versus lead redox chemistry modulates charge trapping and self-doping in tin/lead iodide perovskites. J. Phys. Chem. Lett. 2020, 11 (9), 3546−3556. 

(311) Li, H.; Chang, B.; Wang, L.; Wu, Y.; Liu, Z.; Pan, L.; Yin, L. Surface dedoping for methylammonium-free tin-lead perovskite solar cells. ACS Energy Lett. 2024, 9, 400−409. 

(312) Xu, P.; Chen, S.; Xiang, H.-J.; Gong, X.-G.; Wei, S.-H. Influence of defects and synthesis conditions on the photovoltaic performance of perovskite semiconductor CsSnI3. Chem. Mater. 2014, 26 (20), 6068−6072. 

(313) Shi, T. T.; Zhang, H. S.; Meng, W. W.; Teng, Q.; Liu, M. Y.; Yang, X. B.; Yan, Y. F.; Yip, H. L.; Zhao, Y. J. Effects of organic cations on the defect physics of tin halide perovskites. J. Mater. Chem. A 2017, 5 (29), 15124−15129. 

(314) Ghosh, D.; Acharya, D.; Zhou, L.; Nie, W.; Prezhdo, O. V.; Tretiak, S.; Neukirch, A. J. Lattice expansion in hybrid perovskites: Effect on optoelectronic properties and charge carrier dynamics. J. Phys. Chem. Lett. 2019, 10 (17), 5000−5007. 

(315) Schulz, P.; Whittaker-Brooks, L. L.; MacLeod, B. A.; Olson, D. C.; Loo, Y.-L.; Kahn, A. Electronic level alignment in inverted organometal perovskite solar cells. Adv. Mater. Interfaces 2015, 2 (7), 1400532. 

(316) Olthof, S.; Meerholz, K. Substrate-dependent electronic structure and film formation of MAPbI3 perovskites. Sci. Rep. 2017, 7 (1), 40267. 

(317) Wang, X.; Fan, Y.; Wang, L.; Chen, C.; Li, Z.; Liu, R.; Meng, H.; Shao, Z.; Du, X.; Zhang, H.; et al. Perovskite solution aging: What happened and how to inhibit? Chem 2020, 6 (6), 1369−1378. 

(318) Liang, J.; Sun, A.; Zhang, Z.; Zheng, Y.; Wu, X.; Tian, C.; Chen, Z.; Chen, C.-C. Volatile 2-thiophenemethylammonium and its strongly bonded condensation product for stabilizing α-FAPbI3 in sequential-deposited solar cells. ACS Mater. Lett. 2023, 5, 1395−1400. (319) Dessimoz, M.; Yoo, S. M.; Kanda, H.; Igci, C.; Kim, H.; Nazeeruddin, M. K. Phase-pure quasi-2D perovskite by protonation of neutral amine. J. Phys. Chem. Lett. 2021, 12 (46), 11323−11329. 

(320) Noel, N. K.; Wenger, B.; Habisreutinger, S. N.; Snaith, H. J. Utilizing nonpolar organic solvents for the deposition of metal-halide perovskite films and the realization of organic semiconductor/ perovskite composite photovoltaics. ACS Energy Lett. 2022, 7 (4), 1246−1254. 

(321) Zhu, Z. J.; Mao, K. T.; Zhang, K.; Peng, W.; Zhang, J. Q.; Meng, H. G.; Cheng, S.; Li, T. Q.; Lin, H. Z.; Chen, Q.; et al. Correlating the perovskite/polymer multi-mode reactions with deeplevel traps in perovskite solar cells. Joule 2022, 6 (12), 2849−2868. 

(322) Huang, Y.; Yan, K.; Niu, B.; Chen, Z.; Gu, E.; Liu, H.; Yan, B.; Yao, J.; Zhu, H.; Chen, H. Finite perovskite hierarchical structures via ligand confinement leading to efficient inverted perovskite solar cells. Energy Environ. Sci. 2023, 16, 557−564. 

(323) Chen, L.; Tekelenburg, E. K.; Gahlot, K.; Pitaro, M.; Xi, J.; Lasorsa, A.; Feraco, G.; Protesescu, L.; van der Wel, P. C. A.; Portale, G.; et al. In situ SnSe deposition as passivation for scalable and stable quasi-2D lead-tin perovskite solar cells. Energy Environ. Sci. 2023, 16 (11), 5315−5324. 

(324) Bowman, A. R.; Klug, M. T.; Doherty, T. A. S.; Farrar, M. D.; Senanayak, S. P.; Wenger, B.; Divitini, G.; Booker, E. P.; AndajiGarmaroudi, Z.; Macpherson, S.; et al. Microsecond carrier lifetimes, 

4117 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

controlled p-doping, and enhanced air stability in low-bandgap metal halide perovskites. ACS Energy Lett. 2019, 4 (9), 2301−2307. 

(325) Huang, J.; Xing, Y.; Shang, M.; Li, J.; Guo, T.; Lin, X.; Xiong, J.; Wang, Q.; Huang, L.; Liu, X.; et al. Ternary-metal Sn-Pb-Zn perovskite to reconstruct top surface for efficient and stable less-Pb perovskite solar cells. Small 2024, 20, 2305736. 

(326) Zou, S.; Liu, Y.; Li, J.; Liu, C.; Feng, R.; Jiang, F.; Li, Y.; Song, J.; Zeng, H.; Hong, M.; et al. Stabilizing cesium lead halide perovskite lattice through Mn(II) substitution for air-stable light-emitting diodes. J. Am. Chem. Soc. 2017, 139 (33), 11443−11450. 

(327) Klug, M. T.; Osherov, A.; Haghighirad, A. A.; Stranks, S. D.; Brown, P. R.; Bai, S.; Wang, J. T. W.; Dang, X.; Bulović, V.; Snaith, H. J.; et al. Tailoring metal halide perovskites through metal substitution: influence on photovoltaic and material properties. Energy Environ. Sci. 2017, 10 (1), 236−246. 

(328) Lau, C. F. J.; Zhang, M.; Deng, X.; Zheng, J.; Bing, J.; Ma, Q.; Kim, J.; Hu, L.; Green, M. A.; Huang, S.; et al. Strontium-doped lowtemperature-processed CsPbI2Br perovskite solar cells. ACS Energy Lett. 2017, 2 (10), 2319−2325. 

(329) Hu, Y.; Bai, F.; Liu, X.; Ji, Q.; Miao, X.; Qiu, T.; Zhang, S. Bismuth incorporation stabilized α-CsPbI3 for fully inorganic perovskite solar cells. ACS Energy Lett. 2017, 2 (10), 2219−2227. 

(330) Yang, Z.; Yu, Z.; Wei, H.; Xiao, X.; Ni, Z.; Chen, B.; Deng, Y.; Habisreutinger, S. N.; Chen, X.; Wang, K.; et al. Enhancing electron diffusion length in narrow-bandgap perovskites for efficient monolithic perovskite tandem solar cells. Nat. Commun. 2019, 10 (1), 4498. 

(331) Wu, W.-Q.; Rudd, P. N.; Ni, Z.; Van Brackle, C. H.; Wei, H.; Wang, Q.; Ecker, B. R.; Gao, Y.; Huang, J. Reducing surface halide deficiency for efficient and stable iodide-based perovskite solar cells. J. Am. Chem. Soc. 2020, 142 (8), 3989−3996. 

(332) Yu, Z.; Chen, X.; Harvey, S. P.; Ni, Z.; Chen, B.; Chen, S.; Yao, C.; Xiao, X.; Xu, S.; Yang, G.; et al. Gradient doping in Sn-Pb perovskites by barium ions for efficient single-junction and tandem solar cells. Adv. Mater. 2022, 34 (16), 2110351. 

(333) Phung, N.; Félix, R.; Meggiolaro, D.; Al-Ashouri, A.; Sousa e Silva, G.; Hartmann, C.; Hidalgo, J.; Köbler, H.; Mosconi, E.; Lai, B.; et al. The doping mechanism of halide perovskite unveiled by alkaline earth metals. J. Am. Chem. Soc. 2020, 142 (5), 2364−2374. 

(334) Tan, S.; Huang, T.; Yavuz, I.; Wang, R.; Yoon, T. W.; Xu, M.; Xing, Q.; Park, K.; Lee, D.-K.; Chen, C.-H.; et al. Stability-limiting heterointerfaces of perovskite photovoltaics. Nature 2022, 605 (7909), 268−273. 

(335) Suo, J.; Yang, B.; Mosconi, E.; Bogachuk, D.; Doherty, T. A. S.; Frohna, K.; Kubicki, D. J.; Fu, F.; Kim, Y.; Er-Raji, O. Multifunctional sulfonium-based treatment for perovskite solar cells with less than 1% efficiency loss over 4,500-h operational stability tests. Nat. Energy 2024, 9, 172−183. 

(336) Guo, X.; Lu, C.; Zhang, W.; Yuan, H.; Yang, H.; Liu, A.; Cui, Z.; Li, W.; Hu, Y.; Li, X.; et al. In Situ surface sulfidation of CsPbI3 for inverted perovskite solar cells. ACS Energy Lett. 2024, 9, 329−335. 

(337) Liu, C.; Yang, Y.; Chen, H.; Xu, J.; Liu, A.; Bati, A. S. R.; Zhu, H.; Grater, L.; Hadke, S. S.; Huang, C.; et al. Bimolecularly passivated interface enables efficient and stable inverted perovskite solar cells. Science 2023, 382 (6672), 810−815. 

(338) Lai, H.; Hu, J.; Zhou, X.; Cai, L.; He, Q.; Chen, C.; Xu, Z.; Xiao, X.; Lan, D.; Mai, Y.; et al. Suppressing bulk and interfacial recombination losses in Sn-Pb perovskites for efficient printable lowbandgap photovoltaic devices. Sol. RRL 2022, 6 (10), 2200619. 

(339) Li, T.; Xu, J.; Lin, R.; Teale, S.; Li, H.; Liu, Z.; Duan, C.; Zhao, Q.; Xiao, K.; Wu, P. Inorganic wide-bandgap perovskite subcells with dipole bridge for all-perovskite tandems. Nat. Energy 2023, 8, 610− 620. 

(340) Pitaro, M.; Pau, R.; Duim, H.; Mertens, M.; Van Gompel, W. T. M.; Portale, G.; Lutsen, L.; Loi, M. A. Tin-lead-metal halide perovskite solar cells with enhanced crystallinity and efficiency by addition of fluorinated long organic cation. Appl. Phys. Rev. 2022, 9 (2), 021407. 

(341) Shen, X.; Kang, K.; Yu, Z.; Jeong, W. H.; Choi, H.; Park, S. H.; Stranks, S. D.; Snaith, H. J.; Friend, R. H.; Lee, B. R. Passivation strategies for mitigating defect challenges in halide perovskite lightemitting diodes. Joule 2023, 7 (2), 272−308. 

(342) Wang, R.; Gao, H.; Yu, R.; Jia, H.; Ma, Z.; He, Z.; Zhang, Y.; Yang, J.; Zhang, L.; Tan, Z. a. β-Diketone coordination strategy for highly efficient and stable Pb-Sn mixed perovskite solar cells. J. Phys. Chem. Lett. 2021, 12 (49), 11772−11778. 

(343) Chen, W.; Su, K.; Huang, Y.; Brooks, K. G.; Kinge, S.; Zhang, B.; Feng, Y.; Nazeeruddin, M. K.; Zhang, Y. Bifunctional additive 2- amino-3-hydroxypyridine for stable and high-efficiency tin-lead perovskite solar cells. J. Mater. Chem. C 2022, 11 (1), 151−160. 

(344) Yeom, K.-W.; Lee, D.-K.; Park, N.-G. Hard and soft acid and base (HSAB) engineering for efficient and stable Sn-Pb perovskite solar cells. Adv. Energy Mater. 2022, 12 (48), 2202496. 

(345) Jiang, X.; Li, C.; Wang, X.; Peng, C.; Jiang, H.; Bu, H.; Zhu, M.; Yin, H.; He, B.; Li, H.; et al. Multifunctional regulation of highly orientated tin-lead alloyed perovskite solar cells. ACS Energy Lett. 2023, 8 (2), 1068−1075. 

(346) Chen, W.; Huang, Y.; Cui, H.; Li, S.; Feng, Y.; Zhang, B. Reduced VOC deficit of mixed lead-tin perovskite solar cells via strainreleasing and synergistic passivation additives. Small Methods 2023, 7 (3), 2201276. 

(347) Bai, L.; Guli, M.; Yang, Y.; Chen, Q.; Zhang, Y. Optimization of Sn defects through multiple coordination effect to realize stable SnPb mixed perovskite solar cells. Sol. Energy Mater. Sol. Cells 2023, 254, 112283. 

(348) Tao, Y.; Liang, Z.; Ye, J.; Xu, H.; Liu, G.; Aldakov, D.; Pan, X.; Reiss, P.; Tian, X. Bidirectional anions gathering strategy afford efficient mixed Pb-Sn perovskite solar cells. Small 2023, 19 (20), 2207480. 

(349) Wang, L.; Wang, Z.; Li, H.; Chang, B.; Pan, L.; Xie, Z.; Yin, L. Pseudohalide anions to suppress oxidative degradation for efficient formamidinium-based Sn-Pb halide perovskite solar cells. ACS Appl. Mater. Interfaces 2022, 14 (16), 18302−18312. 

(350) Chen, Q.; Wu, J.; Matondo, J. T.; Bai, L.; Maurice, D. M.; Guli, M. Optimization of bulk defects in Sn/Pb mixed perovskite solar cells through synergistic effect of potassium thiocyanate. Sol. RRL 2020, 4 (12), 2000584. 

(351) Kim, H.; Lee, J. W.; Han, G. R.; Kim, S. K.; Oh, J. H. Synergistic effects of cation and anion in an ionic imidazolium tetrafluoroborate additive for improving the efficiency and stability of half-mixed Pb-Sn perovskite solar cells. Adv. Funct. Mater. 2021, 31 (11), 2008801. 

(352) De Wolf, S.; Holovsky, J.; Moon, S.-J.; Löper, P.; Niesen, B.; Ledinsky, M.; Haug, F.-J.; Yum, J.-H.; Ballif, C. Organometallic halide perovskites: Sharp optical absorption edge and its relation to photovoltaic performance. J. Phys. Chem. Lett. 2014, 5 (6), 1035− 1039. 

(353) Alsalloum, A. Y.; Turedi, B.; Almasabi, K.; Zheng, X.; Naphade, R.; Stranks, S. D.; Mohammed, O. F.; Bakr, O. M. 22.8%Efficient single-crystal mixed-cation inverted perovskite solar cells with a near-optimal bandgap. Energy Environ. Sci. 2021, 14 (4), 2263− 2268. 

(354) Wang, Y.; Han, M.; Wang, R.; Zhao, J.; Zhang, J.; Ren, H.; Hou, G.; Ding, Y.; Zhao, Y.; Zhang, X. Buried interface passivation strategies for high-performance perovskite solar cells. J. Mater. Chem. A 2023, 11, 8573−8598. 

(355) Kim, H.; Lee, J. W.; Han, G. R.; Kim, Y. J.; Kim, S. H.; Kim, S. K.; Kwak, S. K.; Oh, J. H. Highly efficient hole transport layer-free low bandgap mixed Pb-Sn perovskite solar cells enabled by a binary additive system. Adv. Funct. Mater. 2022, 32 (12), 2110069. 

(356) Zhang, W.; Huang, L.; Zheng, W.; Zhou, S.; Hu, X.; Zhou, J.; Li, J.; Liang, J.; Ke, W.; Fang, G. Revealing key factors of efficient narrow-bandgap mixed lead-tin perovskite solar cells via numerical simulations and experiments. Nano Energy 2022, 96, 107078. 

(357) Huang, L.; Cui, H.; Zhang, W.; Pu, D.; Zeng, G.; Liu, Y.; Zhou, S.; Wang, C.; Zhou, J.; Wang, C.; et al. Efficient Narrow- 

4118 

https://doi.org/10.1021/acs.chemrev.3c00667 Chem. Rev. 2024, 124, 4079−4123 

