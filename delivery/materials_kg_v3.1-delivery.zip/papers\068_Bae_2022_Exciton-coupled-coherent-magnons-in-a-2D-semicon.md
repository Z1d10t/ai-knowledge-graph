# Exciton-coupled coherent magnons in a 2D semiconductor

| 字段 | 内容 |
|---|---|
| 期刊 | Nature |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 287 |
| 作者 | Y. Bae, Jue Wang, A. Scheie, Jun-Wen Xu, Daniel G. Chica, Geoffrey M. Diederich, John Cenker, Michael E. Ziebel et al. |
| DOI | 10.1038/s41586-022-05024-1 |
| 源文件 | 068_Bae_2022_Exciton-coupled-coherent-magnons-in-a-2D-semicon.pdf |

---
# **Exciton-Coupled Coherent Magnons in a 2D Semiconductor** 

Youn Jue Bae<sup>1</sup> , Jue Wang<sup>1</sup> , Allen Scheie<sup>2</sup> , Junwen Xu<sup>3</sup> , Daniel G. Chica<sup>1</sup> , Geoffrey M. Diederich<sup>4,5</sup> , John Cenker<sup>4</sup> , Michael E. Ziebel<sup>1</sup> , Yusong Bai<sup>1</sup> , Haowen Ren<sup>3</sup> , Cory R. Dean<sup>6</sup> , Milan Delor<sup>1</sup> , Xiaodong Xu<sup>4</sup> , Xavier Roy<sup>1</sup> , Andrew D. Kent<sup>3</sup> , Xiaoyang Zhu<sup>1,*</sup> 

- 1 Department of Chemistry, Columbia University, New York, NY  10027, USA 

- 2 Neutron Scattering Division, Oak Ridge National Laboratory, Oak Ridge, TN 37831, USA 

- 3 Department of Physics, New York University, New York, NY, USA 10003, USA 

- 4 Department of Physics, University of Washington, Seattle, WA 98195, USA 

- 5 Intelligence Community Postdoctoral Research Fellowship Program, University of Washington, Seattle, WA 98195, USA 

- 6 Department of Physics and Astronomy, Columbia University, New York, NY 10027, USA 

**<mark>ABSTRACT. Two-dimensional (2D) magnetic semiconductors feature both tightly-bound excitons with large oscillator strength and potentially long-lived coherent magnons due to the presence of bandgap and spatial confinement. While magnons and excitons are energetically mismatched by orders of magnitude, their coupling can lead to efficient optical access to spin information. Here we report strong magnon-exciton coupling in the 2D van der Waals (vdW) antiferromagnetic (AFM) semiconductor CrSBr. Coherent magnons launched by above-gap excitation modulate the interlayer hybridization, which leads to dynamic modulation of excitonic energies. Time-resolved exciton sensing reveals magnons that can coherently travel beyond 7 µm, with coherence time above 5 ns.</mark> We observe this exciton-coupled coherent magnons in both even and odd number of layers, with and without compensated magnetization, down to the bilayer limit.** **<mark>Given the versatility of vdW heterostructures, these coherent 2D magnons may be basis for optically accessible magnonics and quantum interconnects.</mark>** 

The recent discoveries of 2D magnets<sup>1–6</sup> have expanded the horizon of 2D phenomena and applications. Like other 2D materials, these magnets can be stacked into van der Waals (vdW) structures, leading to new, enhanced, and controllable properties<sup>7–11</sup> . One exciting application of 

> * To whom correspondence should be addressed. E-mail: xyzhu@columbia.edu 

1 

2D magnets is to exploit their spin waves (i.e. coherent magnons)<sup>12</sup> as energy efficient information carriers in spintronics and magnonics<sup>13,14</sup> or as interconnects in hybrid quantum systems<sup>15–17</sup> . For spintronics and magnonics, antiferromagnetic (AFM) materials can be advantageous because the zero net magnetization makes devices insensitive to stray fields or cross-talk<sup>18–21</sup> . However, the absence of magnetization also makes detecting the coherent magnon particularly challenging. For hybrid quantum systems, coherent magnons may couple to other quantum modules for transduction, coherent control, and remote entanglement. Such coupling requires a net magnetization and has been realized only for FM<sup>15–17,22,23</sup> , not the more prevalent AFM materials. 

A particular opportunity arises when a 2D material possesses both magnetic and semiconducting properties, as reported recently for CrSBr<sup>24–26</sup> and NiPS3<sup>27–29</sup> that feature excitonic transitions and are A-type antiferromagnets with intralayer FM order and interlayer AFM coupling. We choose CrSBr here because of its excellent semiconducting properties,<sup>24,25</sup> and more importantly, the discovery of strong coupling of Wannier excitons to interlayer magnetic order<sup>26</sup> . Atomically-thin flakes of CrSBr can be produced via mechanical exfoliation and the bulk magnetic structure is maintained down to the FM monolayer with a Curie temperature _T_ C = 146 K and to the AFM bilayer with a Néel temperature _T_ N = 140 K<sup>25</sup> ; the latter is higher than the bulk _T_ N of 132 K. CrSBr is also a direct-gap semiconductor down to the monolayer, with an electronic gap of 1.5 eV and an excitonic gap of 1.34 eV<sup>24</sup> . Towards the 2D limit, the material can be with or without net magnetization for odd or even number of layers, respectively<sup>25</sup> . The coexistence of both magnetic and semiconducting properties implies that a spin wave may coherently modulate the electronic structure which, in a 2D semiconductor, is reflected in the dominant excitonic transitions<sup>30,31</sup> . Such 2D magnon-exciton coupling allows the launch and detection of spin waves from strong absorption, emission, or reflection of light in the energy range corresponding to excitonic transitions 

. This is a major advantage over conventional methods to optically access magnons via i) resonant excitation in microwave spectroscopy based on microwave antenna and waveguides<sup>13</sup> ; ii) magneto optical effects based on precise detection of light polarization rotation<sup>12,19</sup> , or iii) symmetry changes detected in nonlinear optical spectroscopy with high power pulsed lasers<sup>19,25</sup> . 

2 

The coupling of Wannier excitons to interlayer magnetic order in CrSBr comes from the spindependent inter-layer electron exchange interaction.<sup>26</sup> Using first order perturbation theory, we can approximate the shift in the exciton energy (∆𝐸!" ) due to changes in the interlayer electron exchange interaction as ∆E!" ∝cos(<sup>𝜃</sup> +2,# where 𝜃 is the angle between the magnetic moments (M) in neighboring layers<sup>26</sup> . In the AFM state (q = π), the interlayer hybridization is spin-forbidden (∆E!" = 0); in the FM state (q = 0), interlayer electron exchange interaction is the greatest and ∆E!" is -20 meV<sup>26</sup> . The dependence of ∆𝐸!" on q is the basis for exciton sensing of coherent spin waves. To probe the dynamical change in ∆𝐸!", we excite CrSBr with a femtosecond laser pulse with above-gap photon energy ( _hν_ 1), and probe the resulting spin waves with a femtosecond broadband pulse at a controlled distance ( _d_ ) between the pump and probe spots (Fig. 1a and Fig. S1). We identify the magnon modes from coherent oscillations in 𝐸!" , and corroborate this assignment with frequency-domain magnetic resonance spectroscopy. The long-lived coherent magnons and their strong coupling to excitons allow us to directly image coherent magnons propagating in the 2D surface plane. 

We prepare CrSBr flakes with thicknesses ranging from bilayer to thin-bulk onto a Si wafer with a 90 nm thick SiO2 layer<sup>25,26</sup> . In order to enhance excitonic sensing of the spin waves, we apply an external magnetic field ( _B_ 0) along the _c_ -axis to tilt the spins. In the AFM phase, a change to _Eex_ due to interlayer hybridization is ∆𝐸!" ∝cos(<sup>𝜃</sup> +2,#, with 𝜃= (𝜋−𝛼$) ± 𝛼; 𝛼$ is the reduction of q caused by _B_ 0 and a is the time-dependent modulation of q by the coherent spin wave. Because 𝑑𝐸!"/𝑑𝜃∝𝑠𝑖𝑛(𝛼$ + 𝛼), having a non-zero 𝛼$ enhances the oscillatory signal, which we measure as oscillation in 𝐸!". We excite CrSBr by _h_ n1 = 1.7 eV and measure the change in reflectance at a variable time delay (D _t_ ) by a broadband probe ( _hν_ 2 = 1.3 – 1.4 eV) to obtain transient reflectance, ΔR/R, where ΔR is the differential reflectance with and without the pump and R is reflectance without the pump. This energy region probes the excitonic transitions<sup>26</sup> , as shown by a static reflectance spectrum in Fig. 1b. Each ΔR/R spectrum with above-gap photoexcitation features coherent oscillations on top of an incoherent background (Fig. S2). We isolate the pure oscillatory response by subtracting the incoherent signal attributed to electronic excitations for a thin bulk CrSBr at _T_ = 5 K and _d_ = 0 μm (Fig. 1c). We choose the pump laser power in the linear electronic excitation region with sufficient oscillatory amplitude (Fig. S3). 

3 



**Fig. 1. Coupling of excitons to coherent magnons.** (a) Detecting spin waves from transient reflectance. A femtosecond pump pulse with above gap photon energy launches spin waves in the layered AFM semiconductor CrSBr. Reflectance from a broadband probe pulse measures coherent oscillation at excitonic transitions. An external canting field, _B0_ = 0.2 T, is applied along the _c_ -axis (normal to the 2D planes), to enhance the oscillatory signal. (b) Reflectance ( _R_ ) from CrSBr is normalized to that of the SiO2 substrate ( _R0_ ). (c) Transient reflectance spectra DR/R as a function of pump-probe delay (Dt) and probe photon energy ( _hν_ ). An incoherent background has been subtracted from DR/R (see Fig. S2). The pseudo color scale is DR/R, where R is reflectance without pump and DR is pump-induced change in reflectance. (d) 2D fast Fourier transform (FFT) of the data in panel (c). The pseudo color (normalized, 0-1) is the FFT amplitude. (e) The two spin wave frequencies are shown as a function of sample temperature below TN. The inset is the probe hn-integrated FFT trace showing the two peaks at 24 and 34 GHz at 5 K. (f) Two horizontal cuts of the 2D pseudo-color plot in panel (d) at the two peak frequencies (red, 24 GHz; blue 34 GHz). Also shown is the first derivative (black) of the reflectance spectrum in (b). All experiments are done at a sample temperature of 5 K, except panel (e) where the sample temperature is varied between 5 and 140 K. The pump pulse at _hν_ 1 = 1.7 eV (pulse width: 150 fs, rep-rate 250 kHz, power 1 µW, spot diameter: 1.4 µm) and the probe pulse at _hν_ 2 = 1.3 – 1.4 eV (pulse width ~100 fs, power 0.2 µW, spot diameter ~1.2 µm) are used. 

The oscillatory components must come from the coherent spin waves because (i) they are observed only below _TN_ and the frequencies decrease with _T_ (Fig. S4 and Fig. 1e discussed below); and (ii) the amplitude of oscillation signal is much weaker in the absence of a canting field (Fig. S5) and increases with _B0_ . To obtain the frequencies of the coherent spin waves, we perform a fast Fourier transform (FFT) of the oscillatory response. Fig. 1d plots the FFT amplitude (pseudo color) as a function of spin wave frequency (nmag) and _hν2_ . There are two peak frequencies at ~24 GHz 

4 

and ~34 GHz, both independent of probe _hν2_ . This is expected because the coherent spin waves modulate the interlayer electronic hybridization, and thus all excitonic transitions. We use the _h_ n2integrated FFT spectrum (inset of Fig. 1e for a typical spectrum at _T_ = 5K), to quantify the peak frequencies: nmag1 = 24.6 ± 0.7 GHz and n mag2 = 34 ± 1 GHz. With increasing _T_ , the magnetic order decreases and this results in lowering of the spin wave frequencies (Fig. 1e). Around _TN,_ both n mag1 and n mag2 approach zero. The T-dependences of n mag1 and n mag2 closely follow that of the magnetic order parameter<sup>25</sup> . 

The strong coupling of excitons to coherent magnons is revealed by clear π-phase flips of the oscillatory signal at _hν2_ corresponding exactly to the peaks of excitonic transitions, (Fig. 1b, c). The π-phase shift is a signature of an optical transition modulated by coherent oscillation in a coupled mode<sup>32</sup> , as is also known for coherent phonon-exciton coupling<sup>33,34</sup> . Likewise, the FFT amplitudes of bothn mag1 and n mag2 (respectively red and blue spectra in Fig. 1f) track the first derivative (black) of the static reflectance spectrum. The strength of the coupling between excitons and coherent magnons can be calculated by the modulation of the exciton energy (detailed in SI and Figs. S6-12). We obtain exciton energy modulation caused by coherent magnons of dEex = 4.0 ± 0.5 meV. Note that this coupling is perturbative in nature, not due to resonant hybridization between two modes that differ in energies by four-orders of magnitude: Eex ~ 1.3 eV and h _ν_ mag = 0.10 and 0.14 meV (for n1 and n2, respectively). 

To support assignments of coherent magnon modes from excitonic sensing, we use magnetic resonance spectroscopy. Fig. 2a shows a series of magnetic resonance spectra at selected microwave frequencies ( _ν_ = 5-21 GHz) for bulk CrSBr at _T_ = 5 K. The spectra reveal a single resonance in the low frequency (≤ 18 GHz) region and two resonances in the high frequency (> 22 GHz) region. We extract peak frequencies ( _ν_ mag) of the resonances (Fig. S13) and plot them as function of the magnetic field applied along the _c_ -axis ( _B_ 0) (Fig. 2b). For _B_ 0 smaller than a saturation field ( _B_ sat ~1.7 T), we observe two nmag branches whose frequencies decrease with increasing _B_ 0, consistent with reduction in AFM order as spins are progressively canted away from the easy _b_ -axis. Frequencies of these two branches are assigned to the in-phase ( _ν_ IP) and out-ofphase ( _ν_ OP) spin precessions, similar to those observed in the 2D AFM materials CrCl3 and CrI3 12,35,36. Above _B_ sat, the spins are fully polarized parallel to _B_ 0 and nmag increases linearly with _B_ 0 (seen here for the out-of-phase magnon), which is expected for a ferromagnetic resonance<sup>37</sup> . In 

5 

agreement with the magnetic resonance results, the _B_ 0 dependence of the excitonic transitions in transient reflectance exhibits the same dispersion, Fig. 2c for the low-frequency in-phase branch. The temperature dependence of the magnon frequencies from magnetic resonance measurements (Fig. S16) are in good agreement with those obtained from optical measurements (Fig. 1f). 



**Fig. 2. Magnetic-field dependent magnon frequencies and calculated dispersions.** (a) magnetic resonance spectra at the indicated frequencies (5-21 GHz) from a bulk CrSBr crystal at _T_ = 5K, with the magnetic field applied along the _c_ -axis. The spectra are offset for clarity. (b) Peak resonance frequencies as a function of magnetic field (symbols). Solid curves are dispersion fits from LSWT as detailed in SI section 7. (c) Transient reflectance spectra at a single probe wavelength with respect to the applied field along the _c_ -axis of the bulk CrSBr crystal at 5 K. The inset shows the extracted peak frequency from the FFT spectrum as a function of magnetic field. 

We quantitatively analyze the _B_ 0 **calculated dispersions.** (a) magnetic resonance spectra at the indicated frequencies (5-21 GHz) from a bulk CrSBr crystal at dependence of magnon frequencies _T_ = 5K, with the magnetic field applied along the _c_ -axis. The using the Heisenberg spin spectra are offset for clarity. (b) Peak resonance frequencies as a function of magnetic field (symbols). Solid curves are Hamiltonian and fitting the dispersion fits from LSWT as detailed in SI section 7. (c) Transient reflectance spectra at a single probe wavelength with magnetic resonance spectroscopy respect to the applied field along the _c_ -axis of the bulk CrSBr data using linear spin wave theory crystal at 5 K. The inset shows the extracted peak frequency from the FFT spectrum as a function of magnetic field. (LSWT)<sup>38</sup> , with the fitting details shown in Fig. S14 (SI section 6). The triaxial anisotropy in spin exchange interaction and interlayer exchange interaction in CrSBr results in two non-degenerate magnon modes. The LSWT analysis gives the in-phase mode at frequency _ν_ IP =2𝑆=𝐴"𝐴% + 𝐴"𝐽&'( and the out-of-phase mode at frequency _ν_ OP = 2𝑆=𝐴"𝐴% + 𝐴%𝐽&'(. Here, Jint is the interlayer exchange and Ax and Az are single ion anisotropy constants. The _Ax_ , _Az_ and _Jint_ values from LSWT fits (solid curves in Fig. 2b) are 14 μeV, 58 μeV and 6 μeV, respectively. The fits give magnon frequencies at _B_ 0 = 0.2 T (external field used in Fig. 1) of _ν_ IP =24.4 GHz and _ν_ OP = 33.8 GHz, in good agreement with those measured from exciton sensing. Similar agreement with experimental results is also achieved in analysis based on the classical Landau-Lifshitz (LL) equation<sup>37</sup> , with the spin configuration shown in Fig. S15 (SI, section 7). 

6 



**Fig. 3. Exciton sensing of propagating coherent AFM spin waves in the 2D plane.** (a) Optical image of a CrSBr bulk crystal with pump and probe pulse spatially separated by _d_ = 2 μm. (b) Transient reflectance spectra of the measurement shown in (a) ( _d_ = 2 μm) from which the incoherent electronic signal was subtracted. (c-f) Probe-wavelength integrated STFT spectra at different pump-probe distances for the (c) 24 GHz mode along the a- and b- axis and (d) 34 GHz mode along the a-axis. The moving time window of 0.15 ns and 0.6 ns are used for magnon and acoustic phonon modes, respectively. The same pump and probe laser conditions as in Fig. 1 are used and the sample temperature is 5 K. (g) spatially resolved MOKE imaging at pump-probe delay time of 100 ps. 

We exploit the efficient exciton sensing to implement time and spatially resolved spectroscopic imaging to investigate propagating coherent spin waves. We perform this with the pump and probe beam separated by a controlled distance ( _d_ ), Fig. 3a. The diffraction-limited excitation spot can create a gradient in the driving force for launching coherent magnons in a finite momentum window at | _k_ | > 0. The propagating nature of the coherent spin wave is clearly seen in the delayed rise of the oscillatory signal for _d_ > 0, as illustrated for _d_ = 2 µm along the _a_ -axis, Fig. 3b (see Fig. S17 for probe photon energy resolved propagation images). This delayed response is in stark contrast to the prompt rise of the spin wave signature when the pump and probe pulses overlap spatially ( _d_ = 0) in Fig. 1c. FFT analysis of the propagating waves reveals the two coherent spin waves at 24 and 34 GHz. Along the _a_ - axis, we detect two magnon frequencies (24 and 34 GHz); along the _b-_ axis, we only detect the 24 GHz component. We perform short-time FT (STFT) with respect to Dt for different _d_ values for the 24 and 34 GHz modes along the _a_ -axis (Figs. 3c-d) and 

7 

for the 24 GHz mode along the _b_ -axis (Fig. 3e). In each case, the peak Dt shifts linearly with _d_ , establishing the propagating nature of these coherent waves. From these shifts, we obtain group velocities of _V_ g = 1.0 ± 0.1 and 3.0 ± 0.3 km/s, for the 24, 34 GHz along the _a_ -axis, respectively and _V_ g = 0.7 ± 0.1 for the 24 GHz mode along the _b_ -axis.  (Fig. S17-S18). From the probe distancedependent measurements along the _b_ -axis (Fig. S19), we obtain lower bounds for the coherent transport lengths of lcoh = 6 and 7 μm for the 24 and 34 GHz modes, respectively. In complementary experiments, carry out time-resolved imaging based on the magneto-optical Kerr effect (MOKE). Following initial excitation in the center of the image frame, the MOKE responses expand in space with Dt, as expected from the propagating nature of the spin waves (detailed in SI, section 2). Fig. 3f shows a representative early time (Dt = 0.1 ns) MOKE image, which will be discussed below. 



**Fig. 4. Magnon dispersions.** (a) Calculated magnon dispersions<sup>38</sup> . Note the dispersions from the weak interlayer spin exchange in the G-Z direction (dashed oval) are nearly flat. (b) A magnified view of the G-Z direction showing the dispersions of in the out-of-phase (OP, blue) and in-phase (IP, red) modes. (c) and (d) momentum dependence of magnon group velocity along GàX and G -Y directions, respectively. 

To understand the origin of propagating spin waves, we show calculated magnon dispersions along high symmetry directions (Fig 4a, b), obtained from LSWT fits to neutron scattering data<sup>38</sup> , taking into account the small interlayer spin exchange in the vertical direction ( _c_ -axis) and anisotropy exchange constants from fitting the magnetic resonance spectroscopy data in Fig 2b. 

8 

The dispersions along the in-plane G-X ( _a_ -axis) and G-Y ( _b_ -axis) directions are determined by the strong FM exchange interaction. Along the G-Z ( _c_ -axis) direction, dispersion is essentially flat on the energy scale for G-X and G-Y and becomes visible only when we zoom-in by two orders-ofmagnitude, Fig. 4b. The weak interlayer AFM couplings give rise to vertical bandwidths of only ~70 µeV, as compared to ~40 meV in the in-plane directions. From the dispersions in Fig. 4a, we obtain group velocities ( _V_ g) along the G-X and G-Y directions (Fig. 4c, d). There are two reasons why the propagating spin waves observed in experiments cannot be attributed to their intrinsic properties at sufficiently high momentum vectors ( _Q_ ): i) To reach the measured _V_ g values of 1-3 km/s, the intrinsic spin waves in the 2D plane (a- or b-axis) must possess _Q_ values > 1 nm<sup>-1</sup> , which is three orders of magnitude larger than the moment vector ~1 µm<sup>-1</sup> expected from the spatial gradient from a diffraction-limited excitation spot; ii) The calculated _Vg_ values of the IP and OP modes are nearly identical in broad _Q_ ranges along both _a-_ and _b-_ axes, contrary to the experimental ratio of _V_ g, OP/ _V_ g, IP = 3.0±0.4 along the _a_ -axis and observation of only the IP mode along the _b_ - axis _._ 

A well-known mechanism for fast propagation of magnons at small momentum vector is attributed to hybridization between magnon and acoustic phonons via magnetoelastic coupling<sup>39–</sup> 41. In this mechanism, the above gap pump pulse creates thermally induced strain in a magnetic materials and launches the hybridized magnon and phonon modes. Confirmation of this coupling mechanism comes from the short-time MOKE image (Fig. 3f) with the distinct quadrupolar shape, which is a signature of coupling of magnons to longitudinal acoustic phonons<sup>39,42</sup> . Further support for this mechanism comes from peak splitting in the frequency domain (Fig S20), which be directly attributed hybridization and resulting avoided crossing between the two modes. The two different group velocities presumably originate from crossing between two different acoustic phonon branches with different dispersions in momentum space. 

The detection of coherent spin waves in CrSBr from simple exciton sensing allows us to extend the measurements to the 2D limit on exfoliated flakes. Note that this approach cannot be used to probe the FM monolayer because it lacks interlayer exciton coupling<sup>26</sup> . Similar to findings on the bulk crystal, the transient reflectance spectra from two (2L) to five (5L) layers 2L-5L feature coherent oscillations attributed to spin waves. Fig.  5a shows spectra for 5L CrSBr obtained under the same conditions as that in Fig. 1c. There is clear p phase flip in the oscillatory signal at the 

9 

exciton peak of ~1.362 eV due to the strong coupling of coherent magnons to the exciton. Fig. 5b shows a line cut at hn2 = 1.359 eV for the longest delay within our experimental limit, Dt = 7.6 ns. The coherent oscillation clearly persists beyond the experimental time window. Lorentzian fit to its FFT, Fig. S21, gives a full-width-at-half-maximum of 0.20±0.02 GHz, corresponding to tcoh = 5 ns. Similar measurements for 2L - 4 L are shown in Fig. S9 and Fig. S12. These nanosecond spin wave coherences times are similar to those in the bulk crystal, tcoh = 2.5 - 5.0 ± 0.5 ns (Fig. S19). Note that the measured tcoh and lcoh represent lower bounds in the intrinsic coherence times and lengths, as the measurement with finite excitation pulse width, gradient in excitation profiles, and inhomogeneity in sample environment introduces extrinsic decoherence. 



**Fig. 5. Detection of coherent spin waves from excitonic transitions in CrSBr down to the 2D limit.** (a) 2D pseudo-color plot of transient reflectance spectra from 5L CrSBr flake as a function of pumpprobe delay (Δt) and probe photon energy (hn2) at 5 K. (b) Vertical cut of the spectra in (a) at hn2 = 1.359 eV showing long-lived coherence. (c) frequency of the in-phase (IP) and out-of-phase (OP) modes as a function of sample thickness; (d) magnitude of the exciton energy modulation with respect to the number of layers. The error bars are obtained from multiple samples and from the time average for dEex in each sample. 

Fig. 5c summarizes the dependence of the spin wave frequencies on the layer number. With increasing thickness, the frequency of the in-phase mode gradually decreases by ~10% (from 24.0 ± 1.0 to 24.6± 0.7 GHz), while that of the out-of-phase mode increases by ~10% (from 31±1 to 34±1 GHz). Fig. 5d plots the modulation in exciton energies, dEex, by the coherent magnons for layer thicknesses ranging from 3L to thin bulk. The lower signal-to-noise ratio from the 2L sample prohibits a quantitative analysis of dEex. Within experimental uncertainty, the magnon-exciton 

10 

coupling energy from 3L to 5L is the same as that from the bulk, dEex = 4.0 ± 0.5 meV (Fig. S11). An attractive attribute of the coherent magnons approaching the 2D material limit is that there can have net magnetization for odd (not even) number of layers. Having a net magnetization is essential to application as quantum interconnect<sup>15–17,22,23</sup> . In this regard, the sufficiently long coherence time and coherent length may meet the needs for remote coupling of qubits or quantum emitters. 

Our findings of exciton-coupled coherent magnons in a 2D semiconductor represent several key advances. The coupling of coherent magnons, living in the sub-meV energy range, to excitons living in the eV region, can enable direct coupling between microwave photons and near-IR to visible photons, potentially useful for quantum transduction. This coupled exciton-magnon also offers a unique opportunity to control exciton properties of CrSBr via magnon or vice versa using optical or microwave cavities and electrostatic gating.  In addition, the efficient exciton-magnon coupling opens the door to exciting applications, including integration with optoelectronics using on-chip light-emitting diodes and photodetectors. In this context, our discoveries of coherent magnons with excellent coherent properties down to the 2D bilayer limit implies that it could be combined with other 2D materials through vdW heterojunctions, leading to novel device architectures and applications. 

**Acknowledgement.** The spectroscopic and imaging work at Columbia University was supported by the Materials Science and Engineering Research Center (MRSEC) through NSF grant DMR2011738. Synthetic of the CrSBr crytals is supported as part of Programmable Quantum Materials, an Energy Frontier Research Center funded by the U.S. Department of Energy (DOE), Office of Science, Basic Energy Sciences (BES), under award DE-SC0019443.  The AFMR work at NYU was supported by the Air Force Office of Scientific Research under Grant FA9550-19-1-0307. The magnetic field-dependent experiment described in Fig. 2c was performed at the University of Washington and supported by the Department of Energy, Basic Energy Sciences, Materials Sciences and Engineering Division (DE-SC0012509). The PPMS used to perform vibrating sample magnetometry measurements was purchased with financial support from the NSF through a supplement to award DMR-1751949. This research used resources at the Spallation Neutron Source, a DOE Office of Science User Facility operated by the Oak Ridge National Laboratory. G.D. acknowledges the support by an appointment to the Intelligence Community Postdoctoral 

11 

Research Fellowship Program at University of Washington, administered by Oak Ridge Institute for Science and Education through an interagency agreement between the U.S. Department of Energy and the Office of the Director of National Intelligence. We are grateful to Dr. Kihong Lee, Dr Taketo Handa and Dr Yanan Dai for providing invaluable help and insightful discussions. 

# **References** 

1. Lee, J.-U. _et al._ Ising-type magnetic ordering in atomically thin FePS3. _Nano Lett_ **16** , 7433–7438 (2016). 

2. Gong, C. _et al._ Discovery of intrinsic ferromagnetism in two-dimensional van der Waals crystals. _Nature_ **546** , 265–269 (2017). 

3. Huang, B. _et al._ Layer-dependent ferromagnetism in a van der Waals crystal down to the monolayer limit. _Nature_ **546** , 270–273 (2017). 

4. Gibertini, M., Koperski, M., Morpurgo, A. F. & Novoselov, K. S. Magnetic 2D materials and heterostructures. _Nat Nanotechnol_ **14** , 408–419 (2019). 

5. Gong, C. & Zhang, X. Two-dimensional magnetic crystals and emergent heterostructure devices. _Science_ **363** , eaav4450 (2019). 

6. Mak, K. F., Shan, J. & Ralph, D. C. Probing and controlling magnetic states in 2D layered magnetic materials. _Nature Reviews Physics_ **1** , 646–661 (2019). 

7. Zhong, D. _et al._ Layer-resolved magnetic proximity effect in van der Waals heterostructures. _Nature Nanotechnology_ **15** , 187–192 (2020). 

8. Tang, C., Zhang, Z., Lai, S., Tan, Q. & Gao, W. Magnetic Proximity Effect in Graphene/CrBr3 van der Waals Heterostructures. _Advanced Materials_ **32** , 1908498 (2020). 

9. Tong, Q., Liu, F., Xiao, J. & Yao, W. Skyrmions in the Moiré of van der Waals 2D Magnets. _Nano Lett_ **18** , 7194–7199 (2018). 

10. Huang, B. _et al._ Emergent phenomena and proximity effects in two-dimensional magnets and heterostructures. _Nature Materials_ **19** , 1276–1289 (2020). 

11. Wang, C., Gao, Y., Lv, H., Xu, X. & Xiao, D. Stacking domain wall magnons in twisted Van der Waals magnets. _Physical Review Letters_ **125** , 247201 (2020). 

12. Zhang, X.-X. _et al._ Gate-tunable spin waves in antiferromagnetic atomic bilayers. _Nature Materials_ **19** , 838–842 (2020). 

13. Chumak, A. V, Vasyuchka, V. I., Serga, A. A. & Hillebrands, B. Magnon spintronics. _Nature Physics_ **11** , 453–461 (2015). 

14. Kruglyak, V. V, Demokritov, S. O. & Grundler, D. Magnonics. _Journal of Physics D: Applied Physics_ **43** , 264001 (2010). 

15. Li, Y. _et al._ Hybrid magnonics: Physics, circuits, and applications for coherent information processing. _Journal of Applied Physics_ **128** , 130902 (2020). 

16. Lachance-Quirion, D., Tabuchi, Y., Gloppe, A., Usami, K. & Nakamura, Y. Hybrid quantum systems based on magnonics. _Applied Physics Express_ **12** , 70101 (2019). 

12 

17. Awschalom, D. D. _et al._ Quantum Engineering With Hybrid Magnonic Systems and Materials. _IEEE Transactions on Quantum Engineering_ **2** , 1–36 (2021). 

18. Baltz, V. _et al._ Antiferromagnetic spintronics. _Reviews of Modern Physics_ **90** , 15005 (2018). 

19. Němec, P., Fiebig, M., Kampfrath, T. & Kimel, A. V. Antiferromagnetic opto-spintronics. _Nature Physics_ **14** , 229–241 (2018). 

20. Duine, R. A., Lee, K.-J., Parkin, S. S. P. & Stiles, M. D. Synthetic antiferromagnetic spintronics. _Nat Phys_ **14** , 217–219 (2018). 

21. Jungwirth, T. _et al._ The multiple directions of antiferromagnetic spintronics. _Nature Physics_ **14** , 200–203 (2018). 

22. Dany, L.-Q. _et al._ Entanglement-based single-shot detection of a single magnon with a superconducting qubit. _Science_ **367** , 425–428 (2020). 

23. Yutaka, T. _et al._ Coherent coupling between a ferromagnetic magnon and a superconducting qubit. _Science_ **349** , 405–408 (2015). 

24. Telford, E. J. _et al._ Layered Antiferromagnetism Induces Large Negative Magnetoresistance in the van der Waals Semiconductor CrSBr. _Advanced Materials_ **32** , 2003240 (2020). 

25. Lee, K. _et al._ Magnetic Order and Symmetry in the 2D Semiconductor CrSBr. _Nano Lett_ **21** , 3511–3517 (2021). 

26. Wilson, N. P. _et al._ Interlayer Electronic Coupling on Demand in a 2D Magnetic Semiconductor. _Nature Materials_ **20** , 1657–1662 (2021). 

27. Kang, S. _et al._ Coherent many-body exciton in van der Waals antiferromagnet NiPS3. _Nature_ **583** , 785–789 (2020). 

28. Hwangbo, K. _et al._ Highly anisotropic excitons and multiple phonon bound states in a van der Waals antiferromagnetic insulator. _Nature Nanotechnology_ 1–6 (2021). 

29. Wang, X. _et al._ Spin-induced linear polarization of photoluminescence in antiferromagnetic van der Waals crystals. _Nature Materials_ **20** , 964–970 (2021). 

30. Mak, K., Lee, C., Hone, J., Shan, J. & Heinz, T. Atomically Thin MoS2: A New Direct-Gap Semiconductor. _Physical Review Letters_ **105** , 136805 (2010). 

31. Splendiani, A. _et al._ Emerging photoluminescence in monolayer MoS2. _Nano Letters_ **10** , 1271–1275 (2010). 

32. Kumar, A. T. N., Rosca, F., Widom, A. & Champion, P. M. Investigations of amplitude and phase excitation profiles in femtosecond coherence spectroscopy. _The Journal of Chemical Physics_ **114** , 701–724 (2001). 

33. Thouin, F. _et al._ Phonon coherences reveal the polaronic character of excitons in twodimensional lead halide perovskites. _Nat Mater_ **18** , 349–356 (2019). 

34. Lüer, L. _et al._ Coherent phonon dynamics in semiconducting carbon nanotubes: A quantitative study of electron-phonon coupling. _Phys Rev Lett_ **102** , 127401 (2009). 

35. MacNeill, D. _et al._ Gigahertz Frequency Antiferromagnetic Resonance and Strong Magnon-Magnon Coupling in the Layered Crystal CrCl3. _Physical Review Letters_ **123** , 47204 (2019). 

36. Shen, X. _et al._ Multi-domain ferromagnetic resonance in magnetic van der Waals crystals CrI3 and CrBr3. _Journal of Magnetism and Magnetic Materials_ **528** , 167772 (2021). 

37. Gurevich, A.G., & Melkov, G. A. _Magnetization Oscillations and Waves_ . (1996). 

13 

38. Scheie, A. _et al._ Spin waves and magnetic exchange Hamiltonian in CrSBr. (2022). 

39. Ogawa, N. _et al._ Photodrive of magnetic bubbles via magnetoelastic waves. _Proceedings of the National Academy of Sciences_ **112** , 8977–8981 (2015). 

40. Hashimoto, Y. _et al._ All-optical observation and reconstruction of spin wave dispersion. _Nat Commun_ **8** , 1–6 (2017). 

41. Shen, K. & Bauer, G. E. W. Laser-induced spatiotemporal dynamics of magnetic films. _Phys Rev Lett_ **115** , 197201 (2015). 

42. Shen, K. & Bauer, G. E. W. Theory of spin and lattice wave dynamics excited by focused laser pulses. _Journal of Physics D: Applied Physics_ **51** , 224008 (2018). 

14 

# SUPPORTING INFORMATION 

# **Exciton-Coupled Coherent Magnons in a 2D Semiconductor** 

Youn Jue Bae<sup>1</sup> , Jue Wang<sup>1</sup> , Allen Scheie<sup>2</sup> , Junwen Xu<sup>3</sup> , Daniel G. Chica<sup>1</sup> , Geoffrey M. Diederich<sup>4,5</sup> , John Cenker<sup>4</sup> , Michael E. Ziebel<sup>1</sup> , Yusong Bai<sup>1</sup> , Haowen Ren<sup>3</sup> , Cory R. Dean<sup>6</sup> , Milan Delor<sup>1</sup> , Xiaodong Xu<sup>4</sup> , Xavier Roy<sup>1</sup> , Andrew D. Kent<sup>3</sup> , Xiaoyang Zhu<sup>1,†</sup> 

- 1 Department of Chemistry, Columbia University, New York, NY  10027, USA 

- 2 Neutron Scattering Division, Oak Ridge National Laboratory, Oak Ridge, TN 37831, USA 

- 3 Department of Physics, New York University, New York, NY, USA 10003, USA 

- 4 Department of Physics, University of Washington, Seattle, WA 98195, USA 

- 5 Intelligence Community Postdoctoral Research Fellowship Program, University of Washington, Seattle, WA 98195, USA 

- 6 Department of Physics and Astronomy, Columbia University, New York, NY 10027, USA 

> † To whom correspondence should be addressed. E-mail: xyzhu@columbia.edu 

15 

# <u>1. CrSBr Synthesis and Sample Preparation</u> 

**Reagents** . The following reagents were used as received unless otherwise stated: chromium powder (99.94%, -200 mesh, Alfa Aesar), sulfur pieces (99.9995%, Alfa Aesar), and bromine (99.99%, Aldrich). 

**Synthesis of CrBr3** . Chromium (1.78 g, 34.2 mmol) and bromine (8.41 g, 105 mmol) were loaded into a bent, 19 mm O.D., 14 mm I.D. fused silica tube. The tube was evacuated to a pressure of ~30 mtorr and flame sealed while the bottom was submerged in liquid nitrogen. The end of the tube containing the chromium was heated at 1000 °C for 3 days while the other end outside the furnace was maintained below 50 °C to prevent over pressurizing the tube. _Caution: Heating the entire tube above 120°C with significant excess of bromine can result in the explosion of the tube._ 

**Synthesis of CrSBr** . In a typical reaction, chromium (0.189 g, 3.63 mmol), sulfur (0.196 g, 6.11 mmol), and chromium tribromide (0.720 g, 2.47 mmol) were loaded into a 12.7 mm O.D., 10.5 mm I.D. fused silica tube. The tube was evacuated to a pressure of ~30 mtorr and flame sealed to a length of 12 cm. The tube was placed into a computer-controlled, two-zone, tube furnace. The source side was heated to 550 °C in 6 hours, allowed to soak for 12 hours, heated to 930 °C in 12 hours, allowed to soak for 84 hours, and then water quenched. The sink side was heated to 570 °C in 6 hours, allowed to soak for 12 hours, heated to 970 °C in 12 hours, allowed to soak for 24 hours, cooled to 850 °C in 12 hours, allowed to soak for 48 hours, and then water quenched. _Caution: Proper PPE should be worn when water quenching tubes including face shield, thick heat resistant gloves, and fire-resistant lab coat._ The crystals were cleaned by soaking in acetonitrile for 1 hour, followed by soaking in DI water for 16-24 hours at 70°C. After soaking, the crystals were thoroughly rinsed with DI water and acetone. 

Bulk crystals were mechanically exfoliated on a Si/SiO2 substrate passivated by 1-dodecanol inside a glovebox. 

# <u>2. Pump-probe Spectroscopy/Microscopy Setups</u> 

Montana cryostat is used to cool down the temperature down to 4K. A permanent magnet is attached to the sample holder using epoxy glue to achieve 0.2 T at the sample position. The magnetic field at the sample position is measured at room temperature using a magnetometer 

16 

(Extech SDL900). The steady state reflectance is measured using a 3200K halogen lamp (KLS EKE/AL). The broadband white light reflected from the CrSBr sample and the substrate are collected by an InGaAs photodiode array (PyLoN-IR, Princeton Instruments). 



**Fig. S1.** Schematic illustration of pump-probe confocal optical microscope. 

The detailed description of the transient reflectance set up is discussed previously.<sup>1</sup> Briefly, femtosecond laser pulses from the Ti:sapphire regenerative amplifier (Coherent RegA 9050, 250 kHz, 800 nm, 100 fs) is split into two beams: one for the tunable pump (Coherent OPA 9450) and the other for the broadband white light. A sapphire crystal is used to generate probe beam. The pump pulse is delayed using a motorized delay stage up to 7 ns and modulated using an optical copper to record pump-on and pump-off reflected signal using the InGaAs detector. The difference signal is normalized with the pump-off signal to yield ΔR/R. The pump and the probe beam get combined using a 50:50 beam splitter in front of an objective lens. A dual-axis galvo mirror scanning system is used to locate a probe pulse a few μm distance away from the pump pulse (Figure S1). The detailed description is written elsewhere.<sup>2</sup> Although the angle of incidence of the probe pulse at the back focal plane of an objective changes during the scanning process, the angle of incidence to the sample plane is kept normal for both the probe and pump pulse. Since the numerical aperture of the objective is high, the angle of incidence spans from -45° to 45°. Reflected 

17 

pump and probe pulse travels the same path and the pump pulse is removed using a 800nm long pass filter. 

**Magneto-optical Kerr effect (MOKE).** For MOKE imaging measurement shown in Fig. 3f, a pre-amplified balanced detector (PDB210A, Thorlabs), lock-in amplifier (SR830, Stanford research systems) with a chopper frequency as a reference frequency and a half-waveplate were used. A 880nm bandpass filter with the 70nm full-width-half-maximum (FWHM) was used for the broadband white light and 740 nm pump pulse from the OPA was used to excited the sample at 5K. Both the pump and probe beams pass through the same Glan-Taylor polarizer (polarized along the _b_ -axis of the crystal). A 50:50 beam splitter was placed between the objective and the Glan-Taylor polarizer to direct the reflected beam into a balanced detector passing thorough a 800 nm longpass filter, half-waveplate, Wollaston prism, and a lens. Here, the probe beam travels through a dual-axis galvo scanning mirrors to precisely control the position with respect to the pump beam and to collect the pump-induced change in Kerr rotation. 

**Transient reflectance with variable magnetic field.** For transient reflectance measurements, the 930 nm pulses from a 76 MHz Ti:Sapph oscillator were focused into a BBO crystal to produce 465 nm SHG which was then separated from the fundamental by a dichroic beam-splitter. The 930 probe pulses were delayed via retroreflectors on a mechanical delay line, attenuated, and polarized along the _b_ axis of the sample crystal. The 465 pump pulses were sent through a mechanical chopper, attenuated, and polarized before being recombined with the probe pulses and sent to a 0.6 NA microscope objective where they were focused to a spot size of ~2 micron on the sample. The reflected pulses were picked off by an OD 3 reflective neutral density filter and sent through a Wollaston prism to separate orthogonal polarization states and each beam was passed through an absorptive long pass filter and lightly focused onto one of two detectors on a balanced photoreceiver. The signal is then sent to a lock-in amplifier, demodulating at the frequency of the mechanical chopper to ensure that only the pump-induced signal change is measured. 

To generate delays and measure the dynamics, the stage is continuously swept across its range at low speed while the lock-in amplifier streamed the demodulated data to the host computer. Such scans (typically N > 25) are collected and averaged to form the final data set, with the delay calculated from the stage speed, its initial position, and the measured timebase of the lock-in 

18 

amplifiers internal clock.  Each photodiode on the balanced detector is sent to a different lock-in channel and their sum provides the transient reflectance. 

For magnetic field measurements, the cryostat used has an integrated superconducting magnet capable of applying 5 Tesla in the _z_ direction across all temperatures (base temperature is ~2K). This introduces polarization rotations due to the Faraday effect in the objective glass, which we measure and correct with half waveplates in the pump, probe, and signal beam paths. 

# <u>3. Additional Spectra and Analysis of Transient Reflectance</u> 



**Fig. S2.** (a) Transient reflectance spectra as a function of pump-probe delay and probe wavelength for a bulk CrSBr crystal at 5 K and with an external canting field, Bo = 0.2 T applied along the _c_ -axis (normal to the 2D planes. The pump pulse at hn1 = 1.7 eV (pulse width: 150 fs, rep-rate 250 kHz, power 1 µW, spot diameter: 1.4 µm) and the probe pulse at hn2 = 1.3 – 1.4 eV (pulse width ~100 fs, power 0.2 µW, spot diameter ~1.2 µm) are used. (b) a vertical cut of the transient reflectance in (a) at 909 nm (green circles). The solid curve is a fit of the data to a gaussian convoluted with a bi-exponential decay to account for the smooth background attributed to excitonic excitation. Subtraction of the data by the smooth fit leaves the oscillatory part, whose Fourier transform yields the frequency spectrum in the inset. The subtraction the smooth background is done at every probe wavelength to yield the D _R/R_ spectra in Fig. 1c. 

19 

**Power dependence and polarization dependence.** At low power the magnon FFT amplitude linearly increases with the pump power but eventually plateaus. The pump power has a minimal effect in magnon frequency. In addition to the pump power dependence, we also use linearly polarized pump along the _b_ - and _a_ -axis using the same pump power (0.4 μW). Since the transition dipole is along the _b_ -axis, more carriers are generated when pump beam is polarized along the _b_ - axis. Thus, greater stress is also induced and we observe a greater magnon amplitude. In addition, decreased amplitude is also observed with a circularly polarized light because less carrier is generated. 



**Fig. S3** . (a) ΔR/R signal at 1.336 eV vs _._ pump power. (b) Linearly polarized along the _b_ -axis pump power dependent FFT amplitude and (c) the maximum peak amplitude vs. pump power at 24 and 34 GHz. (d) polarization dependent FFT amplitude. Note the same pump power of 0.4 μW is used for different polarizations. 

20 





21 

**Fig. S4.** ΔR/R spectra at different temperatures below and above the Neel temperature ( _TN_ = 135K). 



**Fig. S5.** (a) ΔR/R spectra without the incoherent electronic signal (b) FFT frequency vs. probe photon energy ( _h_ ν) and (c) the summation of the FFT amplitude from (b) at B0 = 0 T. 

# <u>4. Exciton Energy Modulation by Coherent Spin Waves</u> 

**CrSBr bulk crystal** . We estimate the energy modulation of excitons in the CrSBr bulk sample by adding scaled steady state reflectance to the ΔR/R spectra. Here, we subtract the incoherent electronic signal from the raw ΔR/R spectra (Fig. S2b). The resulting subtracted spectra at different probe wavelengths are shown in Fig. S5. The time-dependent spectral change of the minimum and the maximum of the subtracted ΔR/R spectra can be approximated as the magnitude of the energy modulation (Fig. S6). Taking the FFT of the energy modulation, we obtain the two magnon frequencies, 24 and 34 GHz. We quantify the magnitude of the modulated exciton energy by adding the steady state reflectance spectra to the subtracted ΔR/R spectra (Fig. S8).  The phase flip in the signal can be understood as the exciton energy moving to the left or right with respect to the 

22 

exciton energy at time 0. For bulk CrSBr, the measured change in exciton energy is 0.9 meV in the 1.358 eV region and 3.2 meV in the 1.340 eV region. 



**Fig. S6.** Transient reflectance spectra around the exciton energy of (a) 1.340 eV and (b) 1.358 eV. 



**Fig. S7.** Time dependent traces of maximum (black) and minimum (red) peak of the ΔR/R at (a) 1.358 eV and (b) 1.340 eV. 

23 



**Fig. S8.** Addition of the scaled steady state reflectance spectra to the subtracted ΔR/R spectra. 

24 

**Energy modulation in a few layer CrSBr.** The same analysis is applied to a few layers of CrSBr samples. Unlike the bulk sample, a few layers CrSBr samples contain one major exciton peak around 910 nm. Although the amplitude of magnon oscillation is large at a single probe wavelength down to the trilayer CrSBr, the amplitude is small in the bilayer. Therefore, the magnon frequencies in the bilayer sample is integrated over the entire exciton peak. Thus, the magnitude of the energy modulation cannot be identified for bilayer but magnon frequencies can be still detected. 



**Fig. S9.** Transient reflectance spectra of (a) 4L and (b) 3L after the subtraction of incoherent electronic signals. The corresponding spectrum for 5L is shown in the main text Fig. 4a. 

25 



**Fig. S10.** Time dependent traces of maximum (black) and minimum (red) peak of the subtracted ΔR/R. 



**Fig. S11.** Addition of the scaled steady state reflectance spectra to the subtracted ΔR/R spectra. 



**Figs. S12.** FFT spectrum averaged over the entire probe photon energy of 2L. 

26 

Table S1. Magnon frequencies and energy modulation 

|Sample|Energy modulation|
|---|---|
|Bulk|1.340 eV (3.2 meV) 1.358 eV (0.9 meV)|
|5L|5.1 meV|
|4L|3.7 meV|
|3L|4.0 meV|



# <u>5. AFMR Data Collection and Analysis</u> 

**AFMR measurement.** Antiferromagnetic resonance spectra are collected by using a broadband coplanar waveguide method in a Quantum Design Physical Property Measurement system at variable temperature and a variable magnetic field. An exfoliated CrSBr bulk sample (5 mm by 2mm) is mounted on a coplanar waveguide where an ac current provides a small oscillating Oersted field that drives the magnetization into a small angle precession. At the resonance condition, the amplitude of precession is maximized. An external dc magnetic field is applied perpendicular to the sample plane. The frequency of ac field is fixed while the dc magnetic field is swept from 3T to zero with a step size of 0.02 T. Both the transmission and reflection spectra are collected using a vector network analyzer (VNA). The real part from the transmission port is plotted with respect to the swept magnetic field (Fig. S13). A linear combination of symmetric and antisymmetric Lorentzian functions is used to extract peak position of resonance peaks (Fig. S13). 

27 



**Fig. S13.** (a) The real part of the spectra of S12, transmission port at different resonance frequencies at 100K.  (b) Peak fitting using a linear combination of symmetric and antisymmetric Lorentzian functions. 

# <u><mark>6. Linear spin wave theory (LSWT)</mark></u> 

<mark>As a semiclassical alternative approach to the classical LL equations shown below, we also calculated the magnon modes using linear spin wave theory (LSWT). Because the relevant exchange interactions for the Q=0 modes observed here do not depend upon the in-plane exchange interactions, we can model the system as a 1D antiferromagnetic spin chain with anisotropy. We write the Hamiltonian as</mark> 



<!-- Start of picture text -->
∙ 𝟐 𝟐<br>𝑯 𝑱𝒊𝒏𝒕 𝑺 𝒊 𝑺𝒊,𝟏 + 𝑨𝒙𝑺𝒙 + 𝑨𝒛𝑺𝒛<br>= A<br>𝒊<br><!-- End of picture text -->

<mark>where J</mark> int <mark>is the net interlayer exchange interaction, and A</mark> x <mark>and A</mark> z <mark>are single ion anisotropy terms. Here we assume that A</mark> x <mark>and A</mark> z <mark>are both positive and A</mark> y <mark>is zero such that the easy axis is in the b direction. Solving this equation for the magnon modes using the Holstein-Primakoff formalism</mark><sup>3</sup> <mark>gives the formulae in the main text for the two low energy modes. (Note that these modes are the acoustic intraplane magnon mode, split by the presence of interplane exchange and magnetic anisotropy. Note also that the presence of an intermediate axis is crucial to the observation of two</mark> 

28 

<mark>modes at zero applied magnetic field: in a single easy-axis case A</mark> z <mark>=A</mark> x <mark>, the two B=0 modes are degenerate.</mark> 



**Fig. S14.** LSWT fitting of magnetic field dependent AFMR data shown in Fig. 2b in main text using different single ion anisotropy and interlayer exchange constans. 

<mark>We then model the field-dependence of the modes by minimizing the spin structure with various values of external magnetic field, and recalculating the Q=0 modes using the</mark> _<mark>SpinW</mark>_ <mark>software package.</mark><sup>4</sup> <mark>Because the interplane exchange is unknown, we model the field dependence using many different J</mark> int <mark>values, adjusting A</mark> z <mark>and A</mark> x <mark>to produce the observed zero field magnon energies (Fig. S14). We find that an interplane exchange energy below 0.04 meV is required to have both magnon modes initially decrease energy with magnetic field, with a more realistic value closer to 0.02 meV. (Note that getting the LSWT calculated transition field---the kink in magnon energy--to match experiment requires an adjusting of the</mark> _<mark>g</mark>_ <mark>value to less than 2, similar to the adjustment required for the gyromagnetic ratio in the LL equations below. Thus, by having observed the energy and field dependence of the Q=0 magnon modes, we can place an upper bound on the CrSBr interplane exchange interactions: three orders of magnitude weaker than the intraplanar exchange.</mark><sup>5</sup> 

29 

# <u>7. Analysis Based on the Landau-Lifshitz (LL) Equation</u> 

In order to understand the three branches from AFMR measurement, we modeled the dynamical spin precession using the LL equation: 



<!-- Start of picture text -->
𝑑𝑚GGGGGGG⃗(2)<br>𝑑𝑡 = −𝜇$𝛾𝑚GGGGGGG⃗× 𝐻(2) GGGGGGGGGGGG⃗   (𝑒𝑞. 1)!44(")<br><!-- End of picture text -->

Here, 𝑚GG⃗(&) is the magnetic moment where _i_ =1 (top) or 2 (bottom) layer. 

GGGGGGGGG⃗ : We first write down the total energy and use the following equation to find the 𝐻!44 



<!-- Start of picture text -->
𝐻GGGGGGGGGGGG⃗=!44(") −1 ∇777777777⃗6(") 𝐸 (9(:;     (𝑒𝑞. 2)<br>𝜇$𝑀5<br><!-- End of picture text -->

Since CrSBr is a triaxial, AFM system with an easy axis along the b-axis, intermediate axis along the a-axis and hard-axis along c-axis, we consider four energy contributions, Zeeman energy, two different magnetocrystalline anisotropy energy and interlayer exchange energy. 



<!-- Start of picture text -->
GGGGGGGGGGG⃗− 1 # − 1 # − 1 # − 1 #<br>𝐸(9(:; = −𝑚GGGGG⃗∙𝐻< GGGGGGGGGGG⃗−𝑚!"(,> GGGGG⃗∙𝐻# !"(,> 𝐻?𝑚@,< 𝐻?𝑚@,# 𝐻A𝑚:,< 𝐻A𝑚:,#<br>2 2 2 2<br>+𝐻B𝑚GGGGG⃗∙𝑚< GGGGG⃗      (𝑒𝑞. 3)#<br><!-- End of picture text -->

Here, 𝐻!"( is applied along the c-axis, 𝑚GGGGG⃗< and GGGGG⃗𝑚# are magnetic moments in the layer 1 and layer 2, respectively, 𝐻? describes the magnetic anisotropy along the easy axis, 𝐻A along the intermediate axis and 𝐻B is the AFM interlayer exchange field (Fig. S14). 𝐻? is greater than 𝐻A because b-axis is the easy axis. We ignored a universal factor of μ0 _M_ s. 



**Fig. S15.** Magnetic moments represented in crystallographic axis 

30 

Following the coordinate system shown in Figure S12, the total energy can be written down as: 



<!-- Start of picture text -->
𝐸(9(:; = −2𝐻!"( sin 𝜃−𝐻?𝑐𝑜𝑠 # 𝜃−𝐻B𝑐𝑜𝑠2𝜃 −𝐻A(sin(𝜃) sin(𝜑)) #  (𝑒𝑞. 4)<br><!-- End of picture text -->

Taking the derivative with respect to θ and φ, 



<!-- Start of picture text -->
𝑑𝐸(9(:;<br>= −2𝐻!"( cos(𝜃) + 2𝐻? cos(𝜃) sin(𝜃) 4𝐻B cos(𝜃) sin(𝜃)<br>𝑑𝜃<br>−2𝐻A sin(𝜃) cos(𝜃) sin # (𝜑) (𝑒𝑞. 5)<br><!-- End of picture text -->



<!-- Start of picture text -->
𝑑𝐸<br>= 2𝐻A sin # (𝜃) sin(𝜑) cos(𝜑)   (𝑒𝑞. 6)<br>𝑑𝜑<br><!-- End of picture text -->

CB$%$&' CB$%$&' At equilibrium, = 0 and = 0 gives CD CE 



<!-- Start of picture text -->
𝐻!"(<br>𝑠𝑖𝑛𝜃=   (𝑒𝑞. 7)<br>2𝐻B + 𝐻?<br><!-- End of picture text -->



<!-- Start of picture text -->
𝑑𝐸<br>= 2𝐻A sin # (𝜃) sin(𝜑) cos(𝜑) = 0     (𝑒𝑞. 8)<br>𝑑𝜑<br><!-- End of picture text -->

Thus φ = 0 at equilibrium. 

Using the eq. 2, GGGGGGGGG⃗𝐻!44 for each layer can be written as the following where i and j refer to top and bottom layer: 



<!-- Start of picture text -->
𝐻GGGGGGGGGGGGGGGGGGGG⃗= 𝐻!44(2F<,#) GGGGGGGGGGG⃗−𝐻!"(,> BGGGG⃗+ 𝐻𝑚G ?𝑚@,&𝑏 `  + 𝐻A𝑚:,&𝑎b     (𝑒𝑞. 9)<br><!-- End of picture text -->

We will first find the eigenfrequencies when the out-of-plane field is large enough to saturate both magnetization, Hext,c  > Hs. In this case, the magnetic moment in AFM coupled layers can be written as,  𝑚< ≈(𝑚:,<   1    𝑚@,< , and 𝑚# ≈(𝑚:,#  1   𝑚@,#,. 

Then the effective field and the time derivative of magnetic moment can be written as, 



<!-- Start of picture text -->
0 𝑚:,# 0 𝑚:,<<br>𝐻!44(<) 1 1 0 0<br>GGGGGGGGGGGGGG⃗= 𝐻!"(,> e0f −𝐻B e𝑚@,#f + 𝐻? e𝑚@,<f + 𝐻A  g 0 h (𝑒𝑞. 9)<br><!-- End of picture text -->

31 



<!-- Start of picture text -->
GGGGG⃗ 𝑚:,<<br>𝑑𝑚<<br>0<br>𝑑𝑡<br>= e𝑚@,<f  (𝑒𝑞. 10)<br><!-- End of picture text -->

where the magnetization has the form of 𝑒<sup>H&I(</sup> .  Plugging these into the eq.1 without a damping term and ignoring the 2<sup>nd</sup> order and higher terms we get the 4 x 4 matrix: 



<!-- Start of picture text -->
𝑚:,<<br>&I 𝑚@,<<br>J(K 𝑚:,#<br>i𝑚@,#j =<br>0 𝐻? −𝐻!"( + 𝐻B 0 −𝐻B<br>𝐻!"( −𝐻B −𝐻A 0 𝐻B 0<br>0 −𝐻B 0 𝐻? −𝐻!"( + 𝐻B<br>i  𝐻B 0 𝐻!"( −𝐻B −𝐻A 0 j  (𝑒𝑞. 11)<br><!-- End of picture text -->

Moving the left term to the right and taking the determinant equals to 0, we can get two eigenfrequencies: 



<!-- Start of picture text -->
𝑓< = 𝜇$𝛾 =(𝐻? + 2𝐻B −𝐻!"()(𝐻A + 2𝐻B −𝐻!"()  (𝑒𝑞. 12)<br>2𝜋<br>𝑓# = 𝜇$𝛾 =(𝐻? −𝐻!"()(𝐻A −𝐻!"()   (𝑒𝑞. 13)<br>2𝜋<br><!-- End of picture text -->

where 𝑓< and 𝑓# corresponds to the in-phase and out-of-phase precession above Hs. 

When the external field is below the saturation field, the magnetic moment m1 and m2 have the opposite sign. Assuming that m1>0 and m2<0, and the sub-lattice 1 is on the top and sub lattice 2 is at the bottom, we can write magnetic moment in the each other’s frame by applying rotation matrix of sublattice 2 respective to sublattice 1: 



<!-- Start of picture text -->
1 0 0<br>0 −cos(2𝜃) + sin(2𝜃)<br>𝛤#,< = e0 −sin(2𝜃) −cos(2𝜃)f  (𝑒𝑞. 14)<br><!-- End of picture text -->

Similarly, the rotation matrix from sublattice 1 to sublattice 2 is: 

32 



<!-- Start of picture text -->
1 0 0<br>0 −cos(2𝜃) + sin(2𝜃)<br>𝛤#,< = e0 + sin(2𝜃) −cos(2𝜃)f  (𝑒𝑞. 15)<br><!-- End of picture text -->

Applying the rotation matrix to the magnetic moment and solving the eq.1 without a damping term, we obtain the 4 x 4 matrix: 



<!-- Start of picture text -->
𝑚:,<<br>&I 𝑚@,<<br>J(K 𝑚:,#<br>i𝑚@,#j =<br>0 −𝐻B −𝐻?𝑐𝑜𝑠 # (𝜃) 0 𝐻Bcos (2𝜃)<br>𝐻B + 𝐻? −𝐻A 0 𝐻B 0<br>⎛  ⎞  (𝑒𝑞. 16)<br>0 𝐻Bcos (2𝜃) 0 −𝐻B −𝐻?𝑐𝑜𝑠 # (𝜃)<br>⎝ 𝐻B 0 𝐻B + 𝐻? −𝐻A 0 ⎠<br>Once again, moving the left term to the right and taking the determinant equals to 0 and using the<br>eq 7, we get the two eigenfrequencies:<br>𝑓< = 𝜇$𝛾 𝐻!"( #)  (𝑒𝑞. 17)<br>2𝜋 (𝐻? + 2𝐻B) s<br>q(𝐻? −𝐻A)(𝐻? + 2𝐻B)(1 − r<br><!-- End of picture text -->

Once again, moving the left term to the right and taking the determinant equals to 0 and using the eq 7, we get the two eigenfrequencies: 



<!-- Start of picture text -->
𝑓#<br>= 𝜇$𝛾 𝐻!"( # 𝐻!"( # −1)) (𝑒𝑞. 18)<br>2𝜋 (𝐻? + 2𝐻B) s −1)h + 2𝐻B( r (𝐻? + 2𝐻B) s<br>q(𝐻? −𝐻A + 2𝐻B)(g2𝐻B −𝐻?( r<br><!-- End of picture text -->

where 𝑓< and 𝑓# corresponds to the in-phase and out-of-phase precession below Hs. 

At 0 magnetic field, the two eigenfrequencies obtained from LL, (eq. 17) and (eq. 18), become 𝑓< = <u>J#L(K</u> =(𝐻? −𝐻A)(𝐻? + 2𝐻B) and 𝑓# = <u>J#L(K</u> =𝐻?(𝐻? −𝐻A + 2𝐻B) for _ν_ IP and _ν_ OP, respectively. These equations are complementary to the two eigenfrequencies obtained from LSWT, 2𝑆=𝐴"𝐴% + 𝐴"𝐽&'( and 2𝑆=𝐴"𝐴% + 𝐴%𝐽&'(, since HA, HB, and Jint are proportional to (Az- 

33 

Ay), (Az-Ax) and 2HE, respectively. Since Ay is set to 0 during LSWT fitting, we can recover the same equations by replacing anisotropy and exchange field to single ion anisotropy and exchange constants. 

Although we expect to see 4 branches as described in the 4 eigenfrequencies, we only observe three branches without the in-phase precession branch after saturation field. This is persistent throughout all temperature ranges. We suspect that due to some symmetry constraint, we cannot detect this branch, similar to that observed in CrCl3.<sup>6</sup> We fit three branches using the three eigenfrequencies described in eq 12, 17 and 18. We obtain consistent exchange (HE) and anisotropy fields (HA and HB) from fitting different branches and they match well with the measured anisotropy fields from magnetic isotherm (Table S4). The electron gyromagnetic ratio <u>J(K</u> term, slightly deviates from the expected value, 28 GHz/T at different temperatures (Tables #L S2-S4). Presumably, ignoring higher order terms could lead to slightly lower value of gyromagnetic ratio. This is also observed in LSWT fitting as discussed above. 

34 



**Fig. S16.** AFMR frequency vs. magnetic field plots at different temperature. Note, the saturation field is decreasing with the temperature. 

35 

Table S2. LLG fit parameters for the out-of-phase precession below the saturation field 

|Temperature (K)|γ/2π (T)|HE(T)|HA(T)|HB(T)|
|---|---|---|---|---|
|5|24.9|0.26|1.60|0.64|
|20|28|0.22|1.3|0.5|
|40|27|0.14|1.5|0.8|
|60|26|0.13|1.4|0.8|
|80|27|0.12|1.0|0.3|
|100|28|0.11|0.69|0.2|



Table S3. LLG fit parameters for the in-phase precession below the saturation field 

|Temperature (K)|γ/2π (T)|HE(T)|HA(T)|HB(T)|
|---|---|---|---|---|
|5 (AFMR)|16.8|0.27|1.6|0.50|
|5 (Optical)|28|0.16|1.4|1.0|
|20|28|0.24|1.2|0.77|
|40|25|0.20|1.1|0.64|
|60|21|0.10|1.2|0.6|
|80|27|0.2|0.78|0.48|
|100|21|0.10|0.72|0.33|



36 

Table S4. LLG fit parameters for the out-of-phase precession above the saturation field 

|Temperature (K)|γ/2π (T)|HA(T)|HB(T)|
|---|---|---|---|
|5|23|1.3|0.5|
|20|21|1.2|0.8|
|40|22|1.0|0.46|
|60|22|1.2|0.65|
|80|21|0.83|0.34|
|100|24|0.53|0.44|



# <u><mark>8. Vibrating Sample Magnetometry</mark></u> 

Vibrating sample magnetometry (VSM) measurements were conducted on a Quantum Design PPMS DynaCool system. Two single crystals of CrSBr were co-aligned and attached to a quartz paddle using GE varnish with the crystallographic a-axis aligned parallel to the length of the quartz paddle, which coincides with the direction of the applied field. Variable-field magnetization curves were collected from 0 to 5 T (20 Oe/s) at the temperatures listed in Table S5. For each temperature, one linear fit was applied to the high-field data ( _H_ > 2 T), above the saturation field, and a second linear fit was applied to the linear region at low fields. The intersection of these two lines yields the anisotropy field for the _a_ -axis as its abscissa. The crystals were then removed from the quartz paddle using a 1:1 ethanol/toluene solution and re-attached to the paddle with the _c_ -axis aligned parallel to the field direction. The same measurement and data analysis procedures were then applied to obtain the c-axis anisotropy fields. 

37 

Table S5. Anisotropy field from temperature dependent magnetization measurement with the magnetic field applied along _a_ - and _c_ - axis. 

|Temperature (K)|HA-HB(_a_-axis) T|HA(_c_-axis) T|
|---|---|---|
|2|1.054|1.661|
|10|1.027|1.647|
|20|0.979|1.597|
|30|0.924|1.532|
|40|0.887|1.474|
|50|0.827|1.397|
|60|0.771|1.330|
|70|0.723|1.243|
|80|0.655|1.156|
|90|0.592|1.071|
|100|0.524|0.965|
|110|0.480|0.852|
|120|0.388|0.731|
|130|0.284|0.582|



38 

# <u>9. Coherent Spin Wave Propagation</u> 

The probe-wavelength dependent short time Fourier transform (STFT) is performed at a fixed frequency of 2 GHz, 24 GHz and 34 GHz along both a and b-axis. Using the MATLAB built in STFT function, time window of 600 ps and a hamming window of 590 ps are used for 2 GHz mode. For 24 GHz and 34 GHz, time window of 150 ps with a hamming window of 140 ps is used. The rise and decay of the STFT indicates that magnons are propagating coherently. At a longer probe distance, the width of the amplitude gets broader and the amplitude decays as the propagating magnons lose temporal and spatial coherence. The group velocities of magnon and phonon are obtained from the linear fitting of the pump-probe distance (d) v.s. pump-probe time delay (Fig. S17). 



**Fig. S17.** STFT spectra of 24 GHz and 34 GHz magnon modes along the _a_ - and _b_ -axis of the bulk CrSBr. 

39 



**Fig. S18.** Pump-probe distance (d) vs. time delay for magnon modes with group velocities of x, y, and z for 24 GHz mode along a and b axis and for 34 GHz mode along the a-axis. 

40 

