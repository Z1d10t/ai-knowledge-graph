# Very-large-scale integrated quantum graph photonics

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Photonics |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 211 |
| 作者 | J. Bao, Z. Fu, T. Pramanik, J. Mao, Y. Chi, Ying-Kang Cao, Chong-Hao Zhai, Y. Mao et al. |
| DOI | 10.1038/s41566-023-01187-z |
| 源文件 | 018_Bao_2023_Very-large-scale-integrated-quantum-graph-photon.pdf |

---
## **nature photonics** 

**Article** 

https://doi.org/10.1038/s41566-023-01187-z 

# **Very-large-scale integrated quantum graph photonics** 

Received: 18 November 2022 **A list of authors and their affiliations appears at the end of the paper** Accepted: 26 February 2023 Graphs have provided an expressive mathematical tool to model Published online: 6 April 2023 quantum-mechanical devices and systems. In particular, it has been Check for updates recently discovered that graph theory can be used to describe and design quantum components, devices, setups and systems, based on the two-dimensional lattice of parametric nonlinear optical crystals and linear optical circuits, different to the standard quantum photonic framework. Realizing such graph-theoretical quantum photonic hardware, however, remains extremely challenging experimentally using conventional technologies. Here we demonstrate a graph-theoretical programmable quantum photonic device in very-large-scale integrated nanophotonic circuits. The device monolithically integrates about 2,500 components, constructing a synthetic lattice of nonlinear photon-pair waveguide sources and linear optical waveguide circuits, and it is fabricated on an eight-inch silicon-on-insulator wafer by complementary metal–oxide– semiconductor processes. We reconfigure the quantum device to realize and process complex-weighted graphs with different topologies and to implement different tasks associated with the perfect matching property of graphs. As two non-trivial examples, we show the generation of genuine multipartite multidimensional quantum entanglement with different entanglement structures, and the measurement of probability distributions proportional to the modulus-squared hafnian (permanent) of the graph’s adjacency matrices. This work realizes a prototype of graph-theoretical quantum photonic devices manufactured by very-large-scale integration technologies, featuring arbitrary programmability, high architectural modularity and massive manufacturing scalability. 

Graph theory that can be used to model the pairwise relation between objects provides a powerful tool to pictorially describe quantum devices and systems. For example, graph states are the key resource for measurement-based universal quantum computing<sup>1,2</sup> . Quantum walks on graphs allow the simulations of transport processes in networks<sup>3–5</sup> . The use of graphs allows the characterizations of quantum correlations<sup>6</sup> and investigations of quantum networks<sup>7</sup> . Recently, different to these graph quantum connections, another interesting model-and-device 

correspondence between the abstract graph theory and the quantum photonic experiment has been proposed<sup>8–11</sup> . In this framework, graphs can virtually describe different quantum photonic components, devices, setups and systems, based on nonlinear photon-pair sources and linear optical circuits. Graph theory can be adopted to interpret, model and design diverse advanced quantum photonic experiments<sup>8,9</sup> . Adopting the visualizability and mathematical machinery of graphs, it allows the discovery of complex entanglement resources and even 

e-mail: yyang10@ime.ac.cn; dxdai@zju.edu.cn; yudin@fotonik.dtu.dk; jww@pku.edu.cn 

Nature Photonics | Volume 17 | July 2023 | 573–581 

**573** 

**Article** 

https://doi.org/10.1038/s41566-023-01187-z 

previously unexplored capabilities for quantum technologies<sup>10,11</sup> . However, realizing graph-based quantum devices remains significantly challenging experimentally, as it requires global quantum coherence over the device to impose genuine multiprocess quantum interference. 

In this work, we demonstrate a graph-theoretical quantum photonic device of nonlinear optical sources and linear optical circuits by very-large-scale integration (VLSI) of silicon quantum photonics. The topologies of graphs are physically defined by the connectivity of nonlinear optical sources and by the pathway of single photons in linear optical circuits, and can be arbitrarily reprogrammed by reconfiguring the device structures. The device is able to implement very general linear optical quantum experiments. As two examples, we reprogram it to generate and verify complex structures of genuine multipartite multidimensional entanglement, as well as measure the distributions of perfect matchings of general (bipartite) graphs corresponding to the modulus-squared hafnian (permanent) matrix functions. Note that the graph-theoretical quantum devices here are different to the graph states for one-way quantum computing<sup>1,2</sup> or quantum walk on graphs<sup>3–5</sup> (Supplementary Section 7). 

Figure 1a–c illustrates the correspondence between graph theory and quantum device, describing pairwise relations in mathematical and physical representations, respectively. The pairwise relation can be described by a complex-weighted undirected graph _G_ = ( _V_ , _E_ ), with a set of edges _E_ that connects pairs of vertices _V_ , with _n_ vertices in total. Determining the number of perfect matchings of a graph (a perfect matching is a subgraph in which every vertex is linked to exactly one edge) is equivalent to estimating the hafnian function of the adjacency matrix of the graph, that is, #-P hard<sup>12</sup> . The original scheme was proposed in bulk optics, to map an abstract graph to a physical setup<sup>8–11</sup> . In such a mapping, each pathway of a single photon represents a vertex, and each nonlinear crystal represents an edge. The detected multiphoton quantum correlations at the output of the device returns the number of perfect matchings of the graphs. This correspondence promises a type of versatile quantum photonic device based on graph theory, and could provide a fresh perspective on the existing ones<sup>13–15</sup> . 

Retaining quantum coherence over the entire device is the key<sup>16,17</sup> . We achieve this by ensuring all the processes contributing to multiphoton correlations are quantum-mechanically indistinguishable. Figure 1a shows an example of the bulk optical scheme for implementing the quantum device. Pairs of single photons, generated in different crystals and routed along different pathways to the same detectors, are no longer distinguishable and undergo quantum interference of identical processes. At each crystal, pump photons must synchronously meet with the incoming single photons from the previous crystal. Pump beams must simultaneously reach the crystals positioned in the same column. That is, one cannot identify the which-source information of single-photon generation. In addition, pumps and single photons have different colours and they typically propagate non-collinearly in bulk optics. Thus, retaining global coherence of the device requires complex and precise control of many-photon wavefunctions in the temporal, spatial and spectral domains. Moreover, processing different graphs requires a strong reconfigurability of the device, achievable by altering the links (amplitudes and phases) between crystals and rerouting single photons in linear circuits. Implementing such a lattice in bulk optics, even for a small-scale demonstration, remains experimentally challenging. 

We demonstrate an integrated graph-based quantum device with VLSI silicon photonics (Fig. 1b,d). We call it ‘Boya’. It is a synthetic two-dimensional 4 × 4 lattice that consists of an array of spontaneous four-wave mixing integrated photon-pair sources and a network of programmable linear optical waveguide circuits. The device directly enables complex-weighted undirected graphs with eight vertices. Each pathway of single photons from one source to one detector represents a vertex. Each photon-pair source connects two separate pathways and represents an edge. Quantum correlations in the device (Fig. 1b), 

emerging at sources and sharing between pathways, corresponds to the pairwise relation in the graph (Fig. 1c). An example is identified by two coloured pathways (vertices) and a source (edge). Moreover, connections between vertices can be altered by reconfiguring the waveguide circuits; amplitudes and phases of edges can be individually controlled by an array of key switches before sources and phase shifters before quantum erasers, respectively (Supplementary Table 1). 

The VLSI graph quantum device was fabricated in-house on a 200 mm silicon-on-insulator wafer by 180 nm complementary metal– oxide–semiconductor processes. Figure 1d illustrates a photograph of the full wafer. Each wafer contains 30 dies, each die contains four devices with slightly different designs, and each device integrates 2,446 components in a 12 mm × 15 mm footprint (Fig. 1d, white box). Wafer-scale charaterizations of the propagation loss are shown in Supplementary Fig. 4. A device has an array of 32 spontaneous four-wave mixing sources, forming a 4 × 4 grid, and each pair of adjacent sources produces one pair of degenerate single photons by reverse Hong–Ou– Mandel (RHOM) interference within a Mach–Zehnder interferometer<sup>18</sup> (Fig. 1b, green highlights). The RHOM fringes for all the sources exhibit high contrast (Fig. 1g). The device contains 216 reconfigurable phase shifters (Supplementary Fig. 6d shows the characterizations). Four eight-mode reconfigurable linear optical circuits (mean fidelity, 0.925(32); Fig. 1f and Supplementary Fig. 7) and a network of 463 ultralow-loss waveguide crossers (mean loss, 0.038(4) dB; Fig. 1e) are used to reroute photons across the various paths. The device is fully optically and electrically packaged, and accessed by 100 optical inputs/ optical outputs and 432 electronic inputs. With VLSI silicon photonics, the device here is the largest-scale integrated quantum photonic device to date, to the best of our knowledge<sup>19–21</sup> . 

In the experiment, amplitudes and phases of the complex-weighted edges of graphs (that is, the complex elements of graph’s adjacency matrices) are fully controlled. The connectivity of edges was altered by reconfiguring the eight-mode Mach–Zehnder interferometer meshes (Fig. 1b), whose characterizations (imaginary part is not included) are reported in Fig. 1f. The real and imaginary parts of the two graphs’ edges are shown in Fig. 3b,i. Photon pairs were produced at the sources with a probability of 3.0%–4.5%, dependent on the pump power. We tested the quantum interference of indistinguishable photons by performing a heralded RHOM measurement between separate nonlinear sources (Fig. 1h). A post-filtering process was used to improve the spectral purity of photon sources at the cost of photon counts. The characterization and analysis of purity and indistinguishability are provided in Supplementary Section 4. Photons were detected by multichannel fibre-coupled superconducting nanowire single-photon detectors. Multiphoton correlations, corresponding to the distributions of perfect matchings of graphs, were recorded by a multichannel counting module. We observed a four-photon rate of 20 mHz in a typical setting of the experiment. 

The realization of the graph quantum device in integrated optics (Fig. 1b) offers unique advantages, compared with the bulk optical one (Fig. 1c). It can perfectly match the optical length of paths for all the photons routing along lithographically defined circuits, ensuring good temporal mode matching. All the sources and circuits are monolithically integrated, enabling the reliable processing of graphs. Instead of pinning sources to the 4 × 4 grid, we here flatten this two-dimensional grid into a one-dimensional array, transposing the device structure into a braiding of waveguide circuits. This, thus, forms a synthetic graph lattice. It overcomes the problem of loss accumulation on pump and single photons, forced to pass through a series of sources<sup>22</sup> (even for microring sources<sup>23</sup> ), which causes circuit-depth-dependent edge amplitudes. It also avoids the complex de-multiplexing and re-multiplexing of photons with different colours. Moreover, to ensure the global coherence of the device, the which-source information of all the single photons along every pathway must be coherently erased (Fig. 1b). The erasure process based on postselection ensures quantum coherence at the cost 

Nature Photonics | Volume 17 | July 2023 | 573–581 

**574** 

**Article** 

https://doi.org/10.1038/s41566-023-01187-z 



<!-- Start of picture text -->
a A c A B<br>Pump B<br>y D<br>H C<br>x D<br>E<br>F G D<br>G<br>H F E<br>Photon-pair source Tunable beamsplitter Reflector Mode and phase shifter Detector<br>b EI Boya ( ) OO<br>11<br>A<br>12<br>13<br>B<br>14<br>21<br>C<br>22<br>23<br>D<br>OI 24<br>31<br>E<br>32<br>33<br>F<br>34<br>41<br>G<br>42<br>43<br>H<br>44<br>Keys Nonlinear photon-pair sources Reconfigurable linear optic circuits (y) Low-loss routing network (x) Pathway erasers<br>15 mm<br>d e 20 Loss = 0.038(4) dB f Fidelity = 0.925(32)<br>|2�<br>|4�<br>10<br>|6�<br>1.0<br>0.60.8 |8�<br>0 |2� |4� |6� |8�<br>0 200 400<br>No. of crossers Input<br>g 1.0 h<br>400<br>0.8<br>200<br>0.6 0 C  = 0.782(26)<br>200 mm SOI S1, S2 S31, S32 0 π/2 π 3π/2 2π<br>Sources Phase<br>12 mm<br>Splitters<br>Loss (dB) Output<br>Contrast<br>Four fold CC<br><!-- End of picture text -->

**Fig. 1 | A VLSI graph-theoretical quantum photonic device. a** – **c** , Diagrams of a graph-based quantum device with 4 × 4 nonlinear photon-pair sources in bulk optics ( **a** ) and integrated optics ( **b** ), which can directly encode and process a complex-weighted undirected graph ( **c** ). An example to illustrate the correspondence of graph theory and quantum device: one pair of single photon created at the source (3,2) and separately routed along the orange and purple pathways corresponds to an edge linked to two vertices in **c** . The device is fully programmable, consisting of switchable nonlinear photon-pair sources and reconfigurable linear optical waveguide circuits. The device in **b** monolithically integrates 2,446 components, including 32 spontaneous four-wave mixing degenerate photon-pair sources, 216 phase shifters and 432 transmission lines, 351 low-loss beamsplitters, 463 ultralow-loss waveguide crossers, 420 lengthmatching delay lines, 100 optical optical inputs/optical outputs (OIs/OOs) and 432 electronic inputs (EIs). Each source can be turned on or off or a state in between using the Mach–Zehnder interferometer keys to alter the edge amplitudes, whereas each phase shifter before the erasers can be addressed to alter the edge phases. By coherently erasing the which-source information using 

an array of pathway erasers, genuine quantum interference of indistinguishable processes of photon generation takes place. **d** , Photograph for the ‘Boya’-graphbased quantum device in a 200 mm silicon-on-insulator (SOI) wafer, fabricated by complementary metal–oxide–semiconductor processes. The white dashed box refers to a single copy of the device. **e** , Characterizations of waveguide crossers with a measured loss of 0.038(4) dB each. **f** , Classical characterizations (associated with the real part of the graph’s edges) of four eight-mode reconfigurable linear optical circuits. The colour in each grid represents the measured classical statistical fidelity and a mean value of 0.925(32) is obtained from all the 256 measured fidelities. The losses are corrected by normalizing the outcomes. **g** , Histogram of the measured contrast ( _C_ ) of all the RHOM quantum interference fringes between two adjacent sources. **h** , Heralded RHOM quantum interference fringe. It quantifies the indistinguishability of separate quantum processes that create pairs of single photons. A number of 5,600 fourfold coincidence counts (CC) were collected. The error bars (±1 _σ_ ) in **e** are given by characterizing five copies of chips in different dies; the error bars (±1 _σ_ ) in **g** and **h** are estimated from Poissonian photon statistics. 

Nature Photonics | Volume 17 | July 2023 | 573–581 

**575** 

**Article** 

https://doi.org/10.1038/s41566-023-01187-z 

of photon counts, although by collecting all the outputs, the number of graphs’ vertices can be greatly enlarged (Supplementary Figs. 15 and 16 show the theoretical and experimental results). 

We consider a general case of _m_ × _m_ quantum device, described by graph _G_ with 2 _m_ vertices and _m_<sup>2</sup> edges. The _n_ pairs of single photons are created at _n_ sources (a maximum of one pair per source, that is, weakly squeezed light source) and detected by 2 _m_ single-photon detectors at 2 _m_ output modes ( _n_ ≤ _m_ ). The distributions of 2 _n_ -fold coincidences are measured in the basis of { _S_ 1, _S_ 2,…, _S_ 2 _m_ }, where _Si_ denotes the number of photons in the _i_ th mode. We consider no more than one photon click at each detector, that is, _Si_ = {0, 1}. Each 2 _n_ -fold output of the 2 _n_ × 2 _n_ sublattice represents a perfect matching of subgraph _G_ s with 2 _n_ vertices, where the subscript ‘s’ denotes the subgraph. All the permutations of the 2 _n_ -photon outputs exactly represent a superposition of all the perfect matchings of _G_ s. Recording the multiphoton coincidences, thus, returns the probability distributions of the modulus-squared hafnian or permanent of the adjacency submatrix _O_ s, that is, Prob( _s_ ) ∝ ∣Perm( _O_ s)∣<sup>2</sup> for a bipartite graph and Prob( _s_ ) ∝ ∣Haf( _O_ s)∣<sup>2</sup> for a general graph. In this context, similar to the standard quantum boson sampling<sup>24–28</sup> , our device can return the sampling results from its output distribution, which, in general, has an exponentially large number of outcomes. An estimation of a single probability typically requires an exponentially increased running time to obtain a small error<sup>28</sup> . 

### **Creating genuine multiphoton multidimensional entanglement** 

Integrated quantum optics chips have allowed the generation of 15-dimensional Bell state<sup>29</sup> , four-qutrit hyper-entangled cluster state<sup>30</sup> , four-qubit graph state<sup>23,31</sup> and eight-qubit hyper-entangled graph state<sup>32</sup> . Entangling multiple particles in multiple dimensions could provide the key resources for strong quantum correlation tests<sup>33</sup> and qudit-based quantum computing<sup>34</sup> . Recently, the multidimensional multiphoton Greenberger–Horne–Zeilinger (GHZ) states with three photons across three dimensions have been demonstrated in bulk optical setups, which are designed by machine learning techniques<sup>35</sup> . However, the on-chip generation of multidimensional multiphoton entangled states remains experimentally exclusive. 

1 We target a general multidimensional multiphoton state _d_ −1 |GHZ⟩ _nd_ = √ _d_<sup>∑</sup> _k_ =0<sup>||</sup><sup>_k_⟩</sup> ⊗ _n_ , where _n_ is the number of photons, _d_ is the local dimension of each photon and | _k_ 〉 is the logical state in the _k_ th mode. Reconfiguring a sublattice (part of Fig. 1b), we create different |GHZ⟩ _nd_ entangled states. As an example, we discuss how to generate the |GHZ⟩43 state in a 2 × 3 sublattice (Fig. 2a), whose configuration is given by the graph. The success of detecting fourfold coincidences only occurs in three indistinguishable processes in the device. Physically, two pairs of photons emerge either at sources {00, 00}, {11, 11} or {22, 22} (indicated on the sources), each representing the logical basis. Mathematically, these correspond to the three perfect matchings of the graph shown in Fig. 2a. Hence, as a result of the quantum interference of the three indistinguishable processes, we obtain the coherent entangled state |GHZ⟩43<sup>= (|0000⟩+ |1111⟩+ |2222⟩)/√</sup> 3 . To verify the entanglement structures, we adopt an entanglement witness based on the Schmidt rank vector<sup>36</sup> . 

Figure 2a shows an estimated density matrix of the |GHZ⟩43<sup>state.</sup> The density matrix _ρ_ is partially reconstructed by measuring 81 diago⊗ _n_ nal elements in the computational basis ̂Λ _i_ and three off-diagonal ⊗ _n_ 8 terms in a coherent basis ̂Λ _i_<sup>, where ̂Λ</sup> _i_ =1<sup>is the Gell–Mann basis. Note</sup> that quantum erasers (Fig. 1b) also work as arbitrary local projectors for qutrit states and thus allow full-state measurement. We used an array of 12 detectors to record fourfold coincidence counts. From computational basis measurements (diagonal of _ρ_ ), we could unambiguously confirm the existence of three perfect matchings, in good agreement with Haf(O) = 3. We define a classical statistical overlap _γ_ = ∑ _i_ <u>√</u> _piqi_ to characterize the results, where _pi_ and _qi_ are the experimental and theoretical distributions, respectively; we obtain a _γ_ value 

of 0.937. Coherence measurement results of _γ_ = ∑ _i_ <u>√</u> _piqi_ are provided in Supplementary Fig. 10. We estimate the quantum-state fidelity _F_ = 〈 _ψ_ 0∣ _ρ_ ∣ _ψ_ 0〉 from the density matrix, where | _ψ_ 0〉 is the ideal pure state. For the general state |GHZ⟩ _nd_<sup>, if the value of</sup><sup>_F_is larger than (</sup><sup>_d_− 1)/</sup><sup>_d_,</sup> it is genuinely entangled in the dimension of _d_ (Supplementary Section 5)<sup>36</sup> . We measure the fidelity of |GHZ⟩43<sup>to be 0.72(2), greater</sup> than the lower bound of 2/3. We have, therefore, verified genuine four-photon GHZ entanglement in at least three dimensions, that is, having the Schmidt rank vector of {3, 3, 3, 3}. 

We also present experimental results for other genuinely entangled states: GHZ-{2, 2, 2, 2} in a 2 × 2 sublattice (Fig. 2b), GHZ-{3, 3, 3} in a 2 × 3 sublattice (Supplementary Fig. 11) and Bell-{3, 3} in a 1 × 3 sublattice (Fig. 2c; it represents the simplest two-vertex graph<sup>29,37</sup> ). Figure 2d reports the experimental results for another class of multipartite entangled state of | _W_ ⟩3 = (|100⟩+ |010⟩+ |001⟩)/<sup><u>√</u></sup> 3 . The measured distribution (diagonal of _ρ_ ) implies a number of three perfect matchings, consistent with Haf(O) = 3, and it shows a _γ_ value of 0.957. If the fidelity is more than 2/3, it verifies the presence of entanglement. We obtain the fidelity of 0.727(19) and thus confirm the generation of a genuine three-photon _W_ state. Moreover, tracing out one photon of | _W_ 〉3, the remaining photons are still partially entangled. The photon-loss robustness of the _W_ state is illustrated in Fig. 2e. 

### **Measuring the perfect matchings of complex graphs** 

We then reprogram the entire graph-based quantum device to measure the probability distributions of the modulus-squared permanent and hafnian matrix functions for more complex graphs. This task translates to the estimations of the number of perfect matchings of the corresponding bipartite graph and a general graph, respectively, that can be directly read out from the multiphoton coincidence patterns at the output of the quantum device. 

Figure 3 shows the topologies of bipartite and general graphs, device configurations and corresponding measured perfect matching distributions. Their adjacency matrices are given in Supplementary Section 6. Figure 3b,i depicts the experimentally prepared bipartite and general graphs, in which the edge amplitudes and phases are indicated by thickness and colour, respectively. Edge’s amplitudes of the two graphs are randomly set, and the edge’s phases of the bipartite graph are set as {0, π} to indicate the quantum interference of processes, whereas phases of the general graph are randomly chosen to showcase the capability of realizing arbitrary graphs. There are a total of 70 permutations of four-photon coincidences for all the submatrices, corresponding to all the submatrices and subgraphs. We collected _N_ = 5,000 and 7,000 events in the bipartite and general graph experiments, with 68 and 120 h of data collection, respectively. Figure 3c,j reports the measured probability distributions for the bipartite and general graphs, respectively, which are in good agreement with the theoretical predictions by classically calculating ∣Per( _O_ s)∣<sup>2</sup> and ∣Haf( _O_ s)∣<sup>2</sup> for every submatrix. To characterize the results, we use the statistical overlap _γ_ = ∑ <u>√</u> _piqi_ and Kolmogorov distance _D_ = ∑∣ _pi_ − _qi_ ∣/2, where _pi_ and _qi_ are the theoretical and experimental probabilities, respectively. Ideally, we have _γ_ = 1 and _D_ = 0. In the experiment, we obtain _γ_ = 0.979(2) and _D_ = 0.122(7) for permanent (Fig. 3c) and _γ_ = 0.986(2) and _D_ = 0.098(7) for hafnian (Fig. 3j). Non-perfect indistinguishability of the sources and processes has been taken into consideration in theory<sup>38–40</sup> (Supplementary Sections 4.4 and 6.1). A set of measurements for a double-layered graph is reported in Supplementary Fig. 16. 

The implementation of quantum graph processing requires an efficient approach for the validation of experimental outcomes. Validation helps to rule out other possible hypotheses. We compare the experimental results with those having an input of distinguishable photons, as well as a uniform weighted graph (uniform matrix). We adopt a Bayesian updating method, like that used for the validation of boson sampling experiments<sup>41</sup> . In Fig. 3d,k, a Bayesian analysis is 

Nature Photonics | Volume 17 | July 2023 | 573–581 

**576** 

**Article** 

https://doi.org/10.1038/s41566-023-01187-z 



<!-- Start of picture text -->
00 11 22 AB C A |00� 00 11 AB C A |00�<br>|11� |11�<br>|22�<br>C C<br>00 11 22 D D B 00 11 D D B<br>C A C A C A C A C A<br>A<br>A<br>+ + n  = 4,  d  = 2 D +<br>D<br>D B D B D B D B D B<br>|0000� |1111� |2222� |0000� |1111�<br>B C<br>B C<br>n  = 4,  d  = 3 b<br>Re( ρ )<br>|GHZ� 4 2<br>a |GHZ� 4 3 F  = 0.792(12) 1/2<br>F  = 0.722(18)<br>|1111�<br>�1111|<br>Re( ρ )<br>1/3 |0000� �0000|<br>|2222�<br>�2222|<br>Re( ρ )<br>1/3<br>|1111�<br>|22�<br>�1111| �22|<br>c | GHZ� 2 3 |11� �11|<br>F  = 0.966(2) |00� �00|<br>|00� A B<br>|0000� �0000| 00 11 22 A |11�<br>B A B<br>|22� n  = 2,  d  = 3<br>01 01 01 A C A |00|01�� e | W �2 C<br>B C |10�<br>|11� Re( ρ ) B D<br>00 00 00 C D B B D 1/2<br>D<br>C A C A C A<br>|1C1D�<br>�1C1D|<br>d | W �3 F  = 0.727(19) + +<br>C |0C0D� �0C0D| C<br>Re( ρ ) D B D B D B<br>|0100� |0010� |0001�<br>1/2 B D B D<br>Re( ρ ) Re( ρ )<br>1/2 1/2<br>|1B1C1D�<br>�1B1C1D|<br>|1B1D� |1B1C�<br>�1B1D| �1B1C|<br>|0B0C0D� �0B0C0D| |0B0D� �0B0D| |0B0C� �0B0C|<br><!-- End of picture text -->

**Fig. 2 | Generation and verification of genuine multidimensional multiphoton entanglement in the graph-based quantum device. a** – **e** , By reconfiguring the sublattice and accordingly the graph’s topologies, it allows on-chip generation, manipulation, analysis and verification of different multidimensional multiphoton entanglement structures. For each state, it shows the graph topology with a superposition of perfect matchings, and the corresponding two-dimensional lattice (depicted for simplicity, but exactly implemented in the VLSI device) with a certain configuration of connectivity of nonlinear sources (yellow squares) and single-photon pathways (red lines). The encoding of a logical basis is indicated on the sources. The photon pathways are labelled by {A, B, C, D}. The entangled states are represented by concentric circles connected by green lines, where the circles represent photonic qudits and the number of circles implies their local dimension; the lines represent entanglement between the photonic qudits. Here _n_ denotes the number of photons and 

_d_ denotes the local dimensionality. The norm values of the reconstructed density matrices (∣ _ρ_ ∣) and measured quantum-state fidelities ( _F_ ) are shown for the below states: four-photon three-dimensional |GHZ⟩43<sup>state,</sup><sup>_F_= 0.722(18)</sup> > 2/3 ( **a** ); four-photon two-dimensional |GHZ⟩42<sup>state,</sup><sup>_F_= 0.792(12) > 1/2 (</sup><sup>**b**);</sup> two-photon three-dimensional |GHZ⟩23<sup>(Bell) state,</sup><sup>_F_= 0.966(2) (</sup><sup>**c**); three-photon</sup> | _W_ 〉3 state, _F_ = 0.729(19) > 1/2 ( **d** ); tracing out one part of | _W_ 〉3 and the remaining part retains the entanglement ( **e** ). Partial density matrices are reconstructed by measuring _d_<sup>_n_</sup> diagonal elements (in the computational basis) and _d_ off-diagonal elements (in the coherent basis) coloured in blue in all the plots, whereas the remaining elements in yellow are not measured. In **c** , the complete quantumstate tomography is implemented instead. The values in the parentheses denote the ±1 _σ_ uncertainty, estimated by Monte Carlo methods considering Poissonian photon statistics. 

Nature Photonics | Volume 17 | July 2023 | 573–581 

**577** 

**Article** 

https://doi.org/10.1038/s41566-023-01187-z 



<!-- Start of picture text -->
a c h j<br>|Perm(adj[ G s])| 2 300 200 100 0 100 200 300 |Haf(adj[ G s])| 2 400 200 0 200 400<br>41 31 21 11 A 41 31 21 11 A<br>B B<br>42 32 22 12 D 42 32 22 12 C<br>C D<br>43 33 23 13 E 43 33 23 13 E<br>F F<br>44 34 24 14 H 44 34 24 14 G<br>G H<br>G A<br>b i<br>A B<br>C D<br>D C<br>π 2 π<br>E F π E F<br>0 H G 0<br>H B<br>d 1.00 k 1.00<br>0.75 Quantum graph 0.75 Quantum graph<br>0.5 0 0.50<br>0.25 Distinguishable graph 0.25 Distinguishable graph<br>0 0<br>e 0 50 100 150 200 l 0 200 400 600 800 1,000<br>1.00 1.00<br>0.75 Quantum graph 0.75 Quantum graph<br>0.5 0 0.5 0<br>0.25 Uniform graph 0.25 Uniform graph<br>0 0<br>0 50 100 150 200 Theory Experiment 0 50 100 150 200 Theory Experiment<br>Detected events Detected events<br>f g m n<br>0.08 Exp. 0.08 Exp.<br>0.04 1 0.04 1<br>0 0<br>0 0<br>0.04<br>0.04<br>0.08 Theory –1 0.08 Theory –1<br>(1, 2) (7, 8) –1.1 –0.7 –0.3 (1, 2) (7, 8) –1.2 –0.8 –0.4<br>Output pairs ( i ,  j ) S Output pairs ( i ,  j ) S<br>|11110000� |11110000�<br>Bayesian  C Bayesian  C<br>Bayesian  C Bayesian  C<br>|00001111� |00001111�<br>CV CV<br>Correlator Correlator<br><!-- End of picture text -->

**Fig. 3 | Measurement and validation of probability distributions of the permanent and hafnian matrix functions in the graph-based quantum device. a** , **h** , Configurations of the graph-based quantum photonic device. The connectivity of nonlinear sources is set by rerouting single photons along different pathways. **b** , **i** , Topological structures of a bipartite graph ( **b** ) and a general graph ( **i** ). The edge thickness and colour represent the amplitude and phase, respectively. The real and imaginary parts of the edges are characterized by the two-photon correlation measurement. The edges with negligible thickness are not displayed for clarity. **c** , **j** , Measured probability distributions of all the perfect matchings for the bipartite graph in **b** ( **c** ) and the general graph in **i** ( **j** ), which correspondingly returns the distribution of modulus-squared permanent and hafnian matrix functions. The experimental results (green bars) are obtained by measuring four-photon coincidences for all the permutations of subgraphs (submatrices). The theoretical results (orange bars) are obtained by classically calculating the full distributions for all the permutations of subgraphs shown in **b** and **i** . The partial indistinguishability of photons has been taken into consideration. **d** , **k** , Bayesian analysis for validation that 

experimental data are from the quantum interference of indistinguishable processes, rather than from distinguishable ones, for the bipartite graph ( **d** ) and the general graph ( **k** ). **e** , **l** , Bayesian analysis for the validation of experimental results, ruling out the hypothesis of uniform graph. **f** , **m** , Statistical validation of genuine quantum interference using the correlation function. The experimental (green) and theoretical (red) _C_ datasets are the plots for a full collection (total, 28) of the two-mode correlators _Cij_ between all the paired output modes ( _i_ , _j_ ). A number of 5,000 (7,000) events in **d** and **f** ( **k** and **m** ) were collected with 68 h (120 h). **g** , **n** , Coefficient of variation (CV) and skewness (S) plane, allowing the discrimination between indistinguishable and distinguishable photons for the bipartite and general graphs. The experimental data (red circle) can be assigned to the cloud of indistinguishable photons (blue), far away from the cloud of distinguishable photons (yellow). The clouds of samples are numerically obtained from 5,000 random bipartite and general graphs. In **c** , **j** , **f** and **m** , the error bars refer to the ±1 _σ_ uncertainty estimated from photon statistics, and the centres for errors refer to the measured photons or normalized correlators. 

Nature Photonics | Volume 17 | July 2023 | 573–581 

**578** 

**Article** 

https://doi.org/10.1038/s41566-023-01187-z 

used to validate the experimental results for the bipartite and general graphs, against the hypothesis that photons generated from different nonlinear processes are distinguishable. The confidence of discrimination is higher than 99.99%, demonstrating the genuine quantum interference of multiphoton processes in the device. In Fig. 3e,i, we discriminate between our experimental data and those predicted by a uniform graph, and this hypothesis is also ruled out. Other validations using a likelihood ratio test are provided in Supplementary Fig. 12. 

Moreover, another new protocol using the statistical analysis<sup>42,43</sup> of the sampled datasets can efficiently rule out the hypothesis of distinguishable photons, and such a protocol has been adopted to validate boson sampling<sup>44–47</sup> . It is based on the two-mode correlation function, defined as _Cij_ = ⟨̂ _ni_ ̂ _nj_ ⟩−⟨̂ _ni_ ⟩⟨̂ _nj_ ⟩, where ̂ _n_ is the bosonic number operator and _i_ , _j_ indicate the two output modes of the devices. Figure 3f,m reports the experimental _C_ dataset for the general and bipartite graphs that are in good agreement with the theoretical results. We place the experimental data point into a (CV, S) plane (CV is the coefficient of variation and S is the skewness), to discriminate it with the cloud of indistinguishable photons rather than the cloud of distinguishable photons. The clouds are numerically obtained from 5,000 random graphs. The results are shown in Fig. 3g,n. The results of the histogram of _C_ dataset and the statistical analysis in a (CV, NM) plane (NM is the normalized mean) are provided in Supplementary Fig. 13. This statistical analysis, thus, confirms the genuine many-photon quantum interference in the graph-based quantum device. 

We have reported a reconfigurable graph-based quantum device on the VLSI photonic chip, and we reprogrammed it to execute diverse tasks defined by graphs. The device was reconfigured to show the generation, manipulation and certification of genuine multiphoton multidimensional entanglement, which could provide a key resource for universal multidimensional quantum computing<sup>34</sup> and information processing in the future<sup>48</sup> . Using this approach, it could create multidimensional multiphoton GHZ states with an arbitrary dimension, their heralded states and gates by algorithmic optimization<sup>10,11</sup> . We reconfigured the device to map abstract general graphs onto the physical hardware, and estimated these graphs’ perfect matchings by quantum measurements. 

Interestingly, akin to quantum boson samplers<sup>24–28</sup> that have recently shown quantum computational advantages<sup>45–47</sup> , as well as photonic quantum annealers<sup>49,50</sup> that can simulate large spin models, the graph quantum devices also seek the results of graphor matrix-associated problems (Supplementary Section 7). The graph-based quantum device benchmarked in this work represents a general linear optical quantum device that can be arbitrarily reprogrammed to implement many diverse tasks in quantum information processing. Adopting a graph’s high-level visualizability and powerful mathematical machinery, it could provide a versatile hardware platform, such as to engineer complex quantum entanglement<sup>8,9</sup> , design new quantum gates and resources states<sup>11</sup> , learn complex quantum systems<sup>51,52</sup> and train quantum processors<sup>10,53</sup> . With advanced silicon photonic quantum devices and technologies, for example, highly pure and indistinguishable integrated photon-pair sources<sup>54</sup> , low-loss sources with wavelength (de)multiplexers that can be embedded in a two-dimensional mesh, large-scale integration of high-efficiency single-photon detectors<sup>55</sup> and wafer-scale integration of photonic circuits<sup>56</sup> (Supplementary Section 8 provides the analysis and calculation), there is tremendous latent promise of complex graph-theoretical quantum processing for potential interesting quantum applications<sup>57,58</sup> . 

### **Online content** 

Any methods, additional references, Nature Portfolio reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41566-023-01187-z. 

### **References** 

1. Raussendorf, R. & Briegel, H. J. A one-way quantum computer. _Phys. Rev. Lett._ **86** , 5188–5191 (2001). 

2. Walther, P. et al. Experimental one-way quantum computing. _Nature_ **434** , 169–176 (2005). 

3. Harris, N. C. et al. Quantum transport simulations in a programmable nanophotonic processor. _Nat. Photon._ **11** , 447–452 (2017). 

4. Ehrhardt, M. et al. Exploring complex graphs using three-dimensional quantum walks of correlated photons. _Sci. Adv._ **7** , eabc5266 (2021). 

5. Qiang, X. et al. Implementing graph-theoretic quantum algorithms on a silicon photonic quantum walk processor. _Sci. Adv._ **7** , eabb8375 (2021). 

6. Cabello, A., Severini, S. & Winter, A. Graph-theoretic approach to quantum correlations. _Phys. Rev. Lett._ **112** , 040401 (2014). 

7. Perseguers, S. et al. Quantum random networks. _Nat. Phys_ . **6** , 539–543 (2010). 

8. Krenn, M., Gu, X. & Zeilinger, A. Quantum experiments and graphs: multiparty states as coherent superpositions of perfect matchings. _Phys. Rev. Lett._ **119** , 240403 (2017). 

9. Gu, X. et al. Quantum experiments and graphs II: quantum interference, computation, and state generation. _Proc. Natl Acad. Sci. USA_ **116** , 4147–4155 (2019). 

10. Krenn, M. et al. Conceptual understanding through efficient automated design of quantum optical experiments. _Phys. Rev. X_ **11** , 031044 (2021). 

11. Ruiz-Gonzalez, C. et al. Digital discovery of 100 diverse quantum experiments with PyTheus. Preprint at _arXiv_ https://doi. org/10.48550/arXiv.2210.09980 (2022). 

12. Valiant, L. The complexity of computing the permanent. _Theor. Comput. Sci._ **8** , 189–201 (1979). 

13. Pan, J.-W. et al. Multiphoton entanglement and interferometry. _Rev. Mod. Phys._ **84** , 777–838 (2012). 

14. Slussarenko, S. & Pryde, G. J. Photonic quantum information processing: a concise review. _Appl. Phys. Rev._ **6** , 041303 (2019). 

15. Flamini, F., Spagnolo, N. & Sciarrino, F. Photonic quantum information processing: a review. _Rep. Prog. Phys._ **82** , 016001 (2018). 

16. Mandel, L. Coherence and indistinguishability. _Opt. Lett._ **16** , 1882–1883 (1991). 

17. Krenn, M. et al. Entanglement by path identity. _Phys. Rev. Lett._ **118** , 080401 (2017). 

18. Silverstone, J. W. et al. On-chip quantum interference between silicon photon-pair sources. _Nat. Photon._ **8** , 104–108 (2013). 

19. Wang, J. et al. Integrated photonic quantum technologies. _Nat. Photon._ **14** , 273–284 (2020). 

20. Elshaari, A. W. et al. Hybrid integrated quantum photonic circuits. _Nat. Photon_ . **14** , 285–298 (2020). 

21. Pelucchi, E. et al. The potential and global outlook of integrated photonics for quantum technologies. _Nat. Rev. Phys_ . **4** , 194–208 (2022). 

22. Feng, L.-T. et al. On-chip quantum interference between the origins of a multi-photon state. _Optica_ **10** , 105–109 (2023). 

23. Llewellyn, D. et al. Chip-to-chip quantum teleportation and multi-photon entanglement in silicon. _Nat. Phys._ **16** , 148–153 (2020). 

24. Aaronson, S. & Arkhipov, A. The computational complexity of linear optics. In _Proc. Forty-Third Annual ACM Symposium on Theory of Computing_ **9** , 143–252 (ACM, 2013). 

25. Bentivegna, M. et al. Experimental scattershot boson sampling. _Sci. Adv._ **1** , e1400255 (2015). 

26. Hamilton, C. S. et al. Gaussian boson sampling. _Phys. Rev. Lett._ **119** , 170501 (2017). 

27. Kruse, R. et al. Detailed study of Gaussian boson sampling. _Phys. Rev. A_ **100** , 032326 (2019). 

Nature Photonics | Volume 17 | July 2023 | 573–581 

**579** 

**Article** 

https://doi.org/10.1038/s41566-023-01187-z 

28. Brádler, K. et al. Gaussian boson sampling for perfect matchings of arbitrary graphs. _Phys. Rev. A_ **98** , 032310 (2018). 

29. Wang, J. et al. Multidimensional quantum entanglement with large-scale integrated optics. _Science_ **360** , 285–291 (2018). 

30. Reimer, C. et al. High-dimensional one-way quantum processing implemented on _d_ -level cluster states. _Nat. Phys._ **15** , 148–153 (2019). 

31. Adcock, J. C. et al. Programmable four-photon graph states on a silicon chip. _Nat. Commun._ **10** , 3528 (2019). 

32. Vigliar, C. et al. Error-protected qubits in a silicon photonic chip. _Nat. Phys._ **17** , 1137–1143 (2021). 

33. Friis, N. et al. Entanglement certification from theory to experiment. _Nat. Rev. Phys._ **1** , 72–87 (2019). 

34. Chi, Y. et al. A programmable qudit-based quantum processor. _Nat. Commun._ **13** , 1166 (2022). 

35. Erhard, M. et al. Experimental Greenberger–Horne–Zeilinger entanglement beyond qubits. _Nat. Photon._ **12** , 759–764 (2018). 

36. Huber, M. & de Vicente, J. I. Structure of multidimensional entanglement in multipartite systems. _Phys. Rev. Lett._ **110** , 030501 (2013). 

37. Kysela, J. et al. Path identity as a source of high-dimensional entanglement. _Proc. Natl. Acad. Sci. USA_ **117** , 26118–26122 (2020). 

38. Tichy, M. C. Sampling of partially distinguishable bosons and the relation to the multidimensional permanent. _Phys. Rev. A_ **91** , 022316 (2015). 

39. Renema, J. J. et al. Efficient classical algorithm for boson sampling with partially distinguishable photons. _Phys. Rev. Lett._ **120** , 220502 (2018). 

40. Spagnolo, N. et al. Experimental validation of photonic boson sampling. _Nat. Photon._ **8** , 615–620 (2014). 

41. Paesani, S. et al. Generation and sampling of quantum states of light in a silicon chip. _Nat. Phys._ **15** , 925–929 (2019). 

42. Walschaers, M. et al. Statistical benchmark for boson sampling. _New J. Phys._ **18** , 032001 (2016). 

43. Phillips, D. S. et al. Benchmarking of Gaussian boson sampling using two-point correlators. _Phys. Rev. A_ **99** , 023836 (2019). 

44. Giordani, T. et al. Experimental statistical signature of many-body quantum interference. _Nat. Photon._ **12** , 173–178 (2018). 

45. Zhong, H.-S. et al. Quantum computational advantage using photons. _Science_ **370** , 1460–1463 (2020). 

46. Zhong, H.-S. et al. Phase-programmable Gaussian boson sampling using stimulated squeezed light. _Phys. Rev. Lett._ **127** , 180502 (2021). 

47. Madsen, L. S. et al. Quantum computational advantage with a programmable photonic processor. _Nature_ **606** , 75–81 (2022). 

48. Erhard, M., Krenn, M. & Zeilinger, A. Advances in high-dimensional quantum entanglement. _Nat. Rev. Phys._ **2** , 365–381 (2020). 

49. Marandi, A. et al. Network of time-multiplexed optical parametric oscillators as a coherent Ising machine. _Nat. Photon._ **8** , 937–942 (2014). 

50. Inagaki, T. et al. Large-scale Ising spin network based on degenerate optical parametric oscillators. _Nat. Photon._ **10** , 415–419 (2016). 

51. Flam-Shepherd, D. et al. Learning interpretable representations of entanglement in quantum optics experiments using deep generative models. _Nat. Mach. Intell._ **4** , 544–554 (2022). 

52. Wang, J. et al. Experimental quantum Hamiltonian learning. _Nat. Phys._ **13** , 551–555 (2017). 

53. Banchi, L., Quesada, N. & Arrazola, J. M. Training Gaussian boson sampling distributions. _Phys. Rev. A_ **102** , 012417 (2020). 

54. Paesani, S. et al. Near-ideal spontaneous photon sources in silicon quantum photonics. _Nat. Commun._ **11** , 2505 (2020). 

55. Pernice, W. H. P. et al. High-speed and high-efficiency travelling wave single-photon detectors embedded in nanophotonic circuits. _Nat. Commun._ **3** , 1325 (2012). 

56. Zhang, X. et al. A large-scale microelectromechanical-systems-based silicon photonics lidar. _Nature_ **603** , 253–258 (2022). 

57. Huh, J. et al. Boson sampling for molecular vibronic spectra. _Nat. Photon._ **9** , 615–620 (2015). 

58. Banchi, L. et al. Molecular docking with Gaussian boson sampling. _Sci. Adv._ **6** , eaax1950 (2020). 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons. org/licenses/by/4.0/. 

© The Author(s) 2023 

**Jueming Bao**<sup>**1,14**</sup> **, Zhaorong Fu**<sup>**1,14**</sup> **, Tanumoy Pramanik**<sup>**1,14**</sup> **, Jun Mao**<sup>**1,14**</sup> **, Yulin Chi**<sup>**1,14**</sup> **, Yingkang Cao**<sup>**1**</sup> **, Chonghao Zhai**<sup>**1**</sup> **, Yifei Mao**<sup>**1**</sup> **, Tianxiang Dai**<sup>**1**</sup> **, Xiaojiong Chen**<sup>**1**</sup> **, Xinyu Jia**<sup>**1**</sup> **, Leshi Zhao**<sup>**1**</sup> **, Yun Zheng**<sup>**1**</sup> **, Bo Tang**<sup>**2**</sup> **, Zhihua Li**<sup>**2**</sup> **, Jun Luo**<sup>**2**</sup> **, Wenwu Wang**<sup>**2**</sup> **, Yan Yang**<sup>**2**</sup> **, Yingying Peng**<sup>**3**</sup> **, Dajian Liu**<sup>**3**</sup> **, Daoxin Dai**<sup>**3**</sup> **, Qiongyi He**<sup>**1,4,5,6**</sup> **, Alif Laila Muthali**<sup>**7,8**</sup> **, Leif K. Oxenløwe**<sup>**7,8**</sup> **, Caterina Vigliar**<sup>**7,8**</sup> **, Stefano Paesani**<sup>**9**</sup> **, Huili Hou**<sup>**10**</sup> **, Raffaele Santagati**<sup>**11**</sup> **, Joshua W. Silverstone**<sup>**10**</sup> **, Anthony Laing**<sup>**10**</sup> **, Mark G. Thompson**<sup>**10**</sup> **, Jeremy L. O’Brien**<sup>**12**</sup> **, Yunhong Ding**<sup>**7,8,13**</sup> **, Qihuang Gong**<sup>**1,4,5,6**</sup> **& Jianwei Wang**<sup>**1,4,5,6**</sup> 

> 1State Key Laboratory for Mesoscopic Physics, School of Physics, Peking University, Beijing, China. 2Institute of Microelectronics, Chinese Academy of Sciences, Beijing, China.<sup>3</sup> State Key Laboratory for Modern Optical Instrumentation, College of Optical Science and Engineering, Ningbo Research Institute, International Research Center for Advanced Photonics, Zhejiang University, Hangzhou, China.<sup>4</sup> Frontiers Science Center for Nano-optoelectronics & Collaborative Innovation Center of Quantum Matter, Peking University, Beijing, China.<sup>5</sup> Peking University Yangtze Delta Institute of Optoelectronics, Nantong, China.<sup>6</sup> Hefei National Laboratory, Hefei, China.<sup>7</sup> Department of Electrical and Photonics Engineering, Technical University of Denmark, Kgs. Lyngby, Denmark.<sup>8</sup> Center for Silicon Photonics for Optical Communication (SPOC), Technical University of Denmark, Kgs. Lyngby, Denmark.<sup>9</sup> Center for Hybrid Quantum Networks (Hy-Q), Niels Bohr Institute, University of Copenhagen, Copenhagen, Denmark.<sup>10</sup> Quantum Engineering 

Nature Photonics | Volume 17 | July 2023 | 573–581 

**580** 

**Article** 

https://doi.org/10.1038/s41566-023-01187-z 

Technology Labs, H. H. Wills Physics Laboratory and Department of Electrical and Electronic Engineering, University of Bristol, Bristol, UK.<sup>11</sup> QuantumLab, Boehringer Ingelheim, Ingelheim am Rhein, Germany.<sup>12</sup> Department of Physics, The University of Western Australia, Perth, Western Australia, Australia. 13SiPhotonIC ApS, Virum, Denmark. 14These authors contributed equally: Jueming Bao, Zhaorong Fu, Tanumoy Pramanik, Jun Mao, Yulin Chi. e-mail: yyang10@ime.ac.cn; dxdai@zju.edu.cn; yudin@fotonik.dtu.dk; jww@pku.edu.cn 

Nature Photonics | Volume 17 | July 2023 | 573–581 

**581** 

**Article** 

https://doi.org/10.1038/s41566-023-01187-z 

### **Data availability** 

The data that support the plots within this paper and other findings of this study are available from the corresponding authors upon reasonable request. 

### **Acknowledgements** 

We thank L. Jin, H. Zhao, and J. Feng from the United Microelectronics Center in Chongqing (CUMEC) for experimental assistance. We acknowledge I. Faruque from the University of Bristol, M. Krenn (currently in Max Planck Institute) and M. Erhard from Vienna University, and C. Y. Lu and X. Gu from the University of Science and Technology of China for useful discussions. We acknowledge support from the Natural Science Foundation of China (nos. 62235001, 61975001, 62274179, 62125503, 91950205, 61961146003, 12125402, 11975026), the Innovation Program for Quantum Science and Technology (no. 2021ZD0301500), the National Key R&D Program of China (nos. 2019YFA0308702, 2018YFA0704404, 2022YFB2802400), Beijing Natural Science Foundation (Z190005, Z220008) and Key R&D Program of Guangdong Province (2018B030329001). D.D. acknowledges support from the National Science Fund for Distinguished Young Scholars (61725503), the Fundamental Research Funds for the Central Universities and the Leading Innovative and Entrepreneur Team Introduction Program of Zhejiang (2021R01001). S.P. acknowledges funding from the Cisco University Research Program Fund no. 2021-234494. J.W.S. acknowledges the generous support from the Leverhulme Trust (ECF-2018-276) and the UKRI (MR/T041773/1). A.L. acknowledges support from the EPSRC Hub in Quantum Computing and Simulation (EP/T001062/1). Y.D. acknowledges support from the Villum Fonden Young Investigator project QUANPIC (ref. 00025298) and Danish National Research Foundation Center of Excellence, SPOC (ref. DNRF123). 

### **Author contributions** 

J.W. conceived the idea and initiated the project. J.B., Z.F., T.P., J.M. and Y. Chi equally contributed to this work (J.B. and Z.F. characterized and measured the devices; J.B., Z.F. and T.P. analysed the entanglement and matrix functions data; and J.M. and Y. Chi fabricated the devices). J.B., Z.F., J.M., Y.M., T.D., L.Z. and Y.Z. implemented the experiment. C.V., S.P., H.H., R.S., J.W.S. and J.W. implemented some early measurements. J.M., Y. Chi, B.T., Y.Y., A.L.M. and Y.D. fabricated the device. J.B., Z.F., Y. Cao, C.Z., T.D., X.C., Y.P., D.L., D.D. and J.W. designed the devices. J.B., Z.F., T.P., Y. Cao, C.Z., X.J. and Q.H. performed the theoretical analysis. D.D., Z.L., J.L., W.W., A.L., L.K.O., M.G.T., J.L.O., Y.D., Q.G. and J.W. managed the project. J.B., Z.F., T.P., J.M., Y. Chi and J.W. wrote the manuscript, with input from all the authors. 

### **Competing interests** 

The authors declare no competing interests. 

### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41566-023-01187-z. 

**Correspondence and requests for materials** should be addressed to Yan Yang, Daoxin Dai, Yunhong Ding or Jianwei Wang. 

**Peer review information** _Nature Photonics_ thanks the anonymous reviewers for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at www.nature.com/reprints. 

Nature Photonics 

