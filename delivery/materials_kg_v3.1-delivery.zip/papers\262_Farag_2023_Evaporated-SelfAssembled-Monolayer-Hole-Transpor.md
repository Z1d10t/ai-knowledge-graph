# Evaporated Self‐Assembled Monolayer Hole Transport Layers: Lossless Interfaces in p‐i‐n Perovskite Solar Cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Advanced Energy Materials |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 201 |
| 作者 | Ahmed Farag, Thomas Feeney, Ihteaz M. Hossain, Fabian Schackmar, P. Fassl, K. Küster, Rainer Bäuerle, Marco A. Ruiz-Preciado et al. |
| DOI | 10.1002/aenm.202203982 |
| 源文件 | 049_Farag_2023_Evaporated-SelfAssembled-Monolayer-Hole-Transpor.pdf |

---
**ReseaRch aRticle** 



**www.advenergymat.de** 

# **Evaporated Self-Assembled Monolayer Hole Transport Layers: Lossless Interfaces in** **_p-i-n_ Perovskite Solar Cells** 

_Ahmed Farag,* Thomas Feeney, Ihteaz M. Hossain, Fabian Schackmar, Paul Fassl, Kathrin Küster, Rainer Bäuerle, Marco A. Ruiz-Preciado, Mario Hentschel, David B. Ritzer, Alexander Diercks, Yang Li, Bahram Abdollahi Nejand, Felix Laufer, Roja Singh, Ulrich Starke, and Ulrich W. Paetzold*_ 

## **1. Introduction** 

**Engineering of the interface between perovskite absorber thin films and charge transport layers has fueled the development of perovskite solar cells (PSCs) over the past decade. For** **_p-i-n_ PSCs, the development and adoption of hole transport layers utilizing self-assembled monolayers (SAM-HTLs) based on carbazole functional groups with phosphonic acid anchoring groups has enabled almost lossless contacts, minimizing interfacial recombination to advance power conversion efficiency in single-junction and tandem solar cells. However, so far these materials have been deposited exclusively via solution-based methods. Here, for the first time, vacuumbased evaporation of the most common carbazole-based SAM-HTLs (2PACz, MeO-2PACz, and Me-4PACz) is reported. X-ray photoelectron spectroscopy and infrared spectroscopy demonstrate no observable chemical differences in the evaporated SAMs compared to solution-processed counterparts. Consequently, the near lossless interfacial properties are either preserved or even slightly improved as demonstrated via photoluminescence measurements and an enhancement in open-circuit voltage. Strikingly, applying evaporated SAM-HTLs to complete PSCs demonstrates comparable performance to their solution-processed counterparts. Furthermore, vacuum deposition is found to improve perovskite wetting and fabrication yield on previously non-ideal materials (namely Me-4PACz) and to display conformal and high-quality coating of micrometer-sized textured surfaces, improving the versatility of these materials without sacrificing their beneficial properties.** 

Rapid development of single-junction organic–inorganic metal halide perovskite solar cells (PSCs) has occurred following their inception, with power conversion efficiencies (PCEs) approaching those reported for single-junction silicon (Si)based solar cells and even surpassing several established thin film absorber materials, such as copper–indium–gallium–selenide (CIGS) and CdTe.<sup>[1]</sup> However, while planar PSCs in _n-i-p_ architecture have displayed PCEs of up to 25.7%,<sup>[2]</sup> development of planar inverted ( _p-i-n_ ) PSCs lags behind, with maximum certified PCEs of 24.3%.<sup>[3]</sup> Further development of planar _p-i-n_ PSCs is crucial due to several inherent advantages. Specifically, these encompass straightforward incorporation into monolithic tandem photovoltaic (PV) devices with established thin film technologies,<sup>[4–8]</sup> low temperature requirements for fabrication, low currentvoltage hysteresis and high inherent operational stability.<sup>[3,9–14]</sup> These qualities make planar _p-i-n_ PSCs a promising candidate for eventual commercialization.<sup>[12,15–17]</sup> 

A. Farag, T. Feeney, F. Schackmar, P. Fassl, M. A. Ruiz-Preciado, 

D. B. Ritzer, A. Diercks, Y. Li, B. A. Nejand, F. Laufer, R. Singh, 

U. W. Paetzold 

Light Technology Institute Karlsruhe Institute of Technology (KIT) Engesserstrasse 13, 76131 Karlsruhe, Germany E-mail: ahmed.farag@kit.edu; ulrich.paetzold@kit.edu 

The ORCID identification number(s) for the author(s) of this article can be found under https://doi.org/10.1002/aenm.202203982. 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH. This is an open access article under the terms of the Creative Commons Attribution License, which permits use, distribution and reproduction in any medium, provided the original work is properly cited. 

### **DOI: 10.1002/aenm.202203982** 

A. Farag, I. M. Hossain, F. Schackmar, P. Fassl, M. A. Ruiz-Preciado, D. B. Ritzer, Y. Li, B. A. Nejand, R. Singh, U. W. Paetzold Institute of Microstructure Technology Karlsruhe Institute of Technology (KIT) Hermann-von-Helmholtz-Platz 1, 76344 Eggenstein-Leopoldshafen, Germany 

K. Küster, U. Starke Max Planck Institute for Solid State Research Heisenbergstrasse 1, 70569 Stuttgart, Germany 

R. Bäuerle InnovationLab Speyerer Str. 4, 69115 Heidelberg, Germany M. Hentschel 

4th Physics Institute and Research Center SCoPE Pfaffenwaldring 57, 70569 Stuttgart, Germany 

**2203982 (1 of 13)** 

_Adv. Energy Mater._ **2023** , _13_ , 2203982 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

A significant portion of the difference in achieved PCEs as compared to planar _n-i-p_ PSCs is attributed to an increased open-circuit voltage ( _V_ OC) deficit for planar _p-i-n_ PSCs, this being the difference between theoretically achievable _V_ OC based on the Shockley–Queisser limit for a given bandgap and the external _V_ OC of the solar cell. Due to the significant impact of surface recombination at the hole transport layer (HTL)/ perovskite interface on _V_ OC losses, choice of a proper HTL is essential for high efficiency PSCs. Various HTLs such as PTAA, poly-TPD and NiO _x_ are widely employed in the _p-i-n_ architecture, however these common options have several drawbacks. NiO _x_ in particular requires additional processing steps such as doping, thermal treatment, and/or targeted tailoring of process gases to improve its quality.<sup>[18–23]</sup> Furthermore, the metal oxide interacts with the perovskite thin film resulting in interfacial degradation and hence _V_ OC losses, necessitating further interfacial engineering.<sup>[19,24–27]</sup> Meanwhile, PTAA and poly-TPD suffer poor surface wettability and require doping and/or defect modulation to enable high _V_ OC.<sup>[9,19,28–34]</sup> 

Development of self-assembled monolayer based hole transport layers (SAM-HTLs) for perovskite PV was investigated early in the technology's development with varied success.<sup>[35–38]</sup> SAMs are (primarily organic) materials that autonomously form a self-limiting functional layer by developing covalent bonds to the substrate, typically a transparent conductive oxide (TCO), whose component parts can be tailored to apply to a variety of functions.<sup>[39,40]</sup> The latest major breakthrough in this field occurred when Albrecht and coworkers developed a series of such materials that form an essentially lossless HTL/ perovskite interface.<sup>[8]</sup> Their key finding was the design of two promising SAMs derived from carbazole bodies<sup>[41,42]</sup> with phosphonic acid binding groups,<sup>[43]</sup> [2-(9H-carbazol-9-yl)ethyl]phosphonic acid (2PACz) and [2-(3,6-dimethoxy-9H-carbazol-9-yl) ethyl]phosphonic acid (MeO-2PACz). Since this discovery, a third molecule in the same family was introduced, [4-(3,6-dimethyl-9 _H_ -carbazol-9-yl)butyl]phosphonic acid (Me-4PACz), that resulted in the highest perovskite/Si tandem PCE of 29.2% at that time.<sup>[44]</sup> Compared to other HTLs, these materials have been praised for high hole selectivity, fast charge carrier extraction, and very low non-radiative recombination at the HTL/perovskite interface.<sup>[8,44]</sup> The primary cause for this has been attributed to a combination of the presence of carbazole bodies, known to form strong hole selective materials<sup>[29]</sup> and the phosphonic acid functional group, which exhibits selflimiting and self-assembling growth to form very thin stable layers on TCOs.<sup>[43,45]</sup> MeO-2PACz SAM-HTLs have achieved special interest in the field of evaporated perovskites, where they display the ability to stabilize the photoactive black perovskite phase in FAMAPbI3 based perovskites absorber materials.<sup>[46]</sup> Considering the myriad advantages of SAM-HTLs, they dominate recent record and high PCEs for monolithic tandems.<sup>[1,4,5,44,47,48]</sup> Furthermore, synthesis and investigation of new SAMs employing different functional groups has shown remarkable progress.<sup>[49]</sup> 

Critically, deposition of SAM-HTLs has thus far been limited to solution-based methods.<sup>[8,44,46,48–52]</sup> Development of alternative scalable deposition methods, such as vacuum-based evaporation techniques, is crucial to improve process flexibility. Commercial PV production lines predominantly utilize 

**www.advenergymat.de** 

vacuum-based deposition methods, allowing ready incorporation of vacuum-based methods for large-scale perovskite production. Furthermore, evaporation facilitates conformal and uniform coatings, even over textured surfaces, which is expected to improve process yield and reproducibility. 

In response to this challenge, we report for the first time on physical vapor deposition (PVD) via thermal evaporation (hereafter referred to as evaporation) of widely known SAM-HTLs (2PACz, MeO-2PACz, and Me-4PACz) and incorporate them into planar _p-i-n_ PSCs. As evaporation utilizes temperatures with the potential to degrade the evaporated organic molecules, we prove that evaporated 2PACz has not undergone a chemical change by comparing the characteristic binding energy peaks and molecular vibrational bands with those of solution-processed 2PACz using X-ray photoelectron spectroscopy (XPS) and infrared spectroscopy. We further show that the evaporated SAMs covalently bond with the subjacent TCO, indicated by the presence of PO species in the reflection–absorption infrared spectrum independent of film thickness, a necessity for high efficiency PSCs. With evidence of no significant change in chemical properties, we determine ideal deposition conditions for evaporated SAM-HTLs and discuss how surface wettability and resultant perovskite absorber morphology are impacted. Analysis via time-resolved photoluminescence spectroscopy (TRPL) and photoluminescence quantum yield (PLQY) measurements reveals an improved HTL/perovskite interface which, when applied to complete PSCs, is demonstrated to result in an enhanced _V_ OC. Overall, our optimized evaporated 2PACz, MeO2PACz, and Me-4PACz SAM-HTLs achieve comparable PCE to their solution-processed counterparts. Finally, with the goal of establishing key steps toward the development of monolithic two-terminal (2T) perovskite/Si tandem solar cells utilizing micrometer-sized textured Si bottom cells, we show that evaporated SAMs continue to form high quality near lossless interfaces over textured surfaces, outperforming other conformal HTL options. 

## **2. Results and Discussion** 

### **2.1. Photovoltaic Performance and Photophysical Properties** 

Since their first introduction to the perovskite community in 2019,<sup>[8]</sup> 2PACz and MeO-2PACz have been integrated into _p-i-n_ PSCs primarily by spin-coating and dip-coating.<sup>[8,46,48,51–53]</sup> Recently, Cassella et al. reported on further alternative solutionprocessing techniques for deposition of MeO-2PACz namely ultrasonic spray coating and airbrush coating.<sup>[51]</sup> This work provides the first report of PVD of SAMs via thermal evaporation from a crucible in vacuum. To compare the performance of _p-i-n_ PSCs with evaporated SAM-HTLs to their solution-processed (spin-coated) counterparts, we employ the inverted _p-i-n_ architecture: glass/indium tin oxide (ITO)/SAM/perovskite/ LiF/C60/BCP/Ag (see **Figure 1** a). Our triple-cation perovskite absorber layer has a bandgap of ≈1.68 eV with the composition Cs0.05MA0.22FA0.73Pb(I0.77Br0.23)3.<sup>[54]</sup> This composition is extensively used in recent literature, being particularly prevalent in monolithic perovskite/Si tandem solar cells.<sup>[44,47]</sup> Figure 1b shows the statistics of PV parameters corresponding to 52 

**2203982 (2 of 13)** 

_Adv. Energy Mater._ **2023** , _13_ , 2203982 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 1.** a) Schematic diagram of the device stack employing triple-cation perovskite (PVK) composition (Cs0.17FA0.83PbI2.75Br0.25) and evaporated 2PACz hole transport layer (HTL). Also shown is a rendering of evaporation process. b) Statistical distribution of the open-circuit voltage ( _V_ OC), fill factor (FF), short-circuit current density ( _J_ SC), and power conversion efficiency (PCE) of perovskite solar cells employing evaporated (≈6 nm) and solution-processed 2PACz HTLs. A comparison between forward and reverse scan is shown in Figure S1, Supporting Information. 

devices, both for reference solution- processed and evaporated 2PACz as HTL. The best reference PSC exhibits a PCE of 19.6% in the reverse scan with a short-circuit current density ( _J_ SC) of 20.6 mAcm<sup>−2</sup> , a _V_ OC of 1.195 V, a FF of 79.9%, and a hysteresis factor of 0.3%. Under maximum power point (MPP) tracking, as shown in Figure S2, Supporting Information, it performs at a stable 19.3%. Corresponding mean values are 18.5%, 19.7 mAcm<sup>−2</sup> , 1.190 V, 78.9% and 0.5%, denoting comparable PV performance to _p-i-n_ PSCs reported in literature for similar perovskite compositions and device stacks.<sup>[47]</sup> Strikingly, the champion device using evaporated 2PACz shows comparable performance to its solution-processed counterpart and exhibits a PCE of 19.5% (19.1% stabilized under MPP tracking shown in Figure S2, Supporting Information) with a _J_ SC of 20.1 mAcm<sup>−2</sup> , a _V_ OC of 1.214 V, a FF of 80.1% and a hysteresis factor of 1.2%, with corresponding mean values of 18.9%, 20.0 mAcm<sup>−2</sup> , 1.205 V, 78.5% and 1.1% respectively. Additional supporting data and comparisons, including external quantum efficiency (EQE) measurements, integrated current density, and absorption spectra are present in Figures S3 and S4, Supporting Information. We highlight that the evaporated 2PACz yields similar or slightly superior performance compared to its solution-processed counterpart despite a substantially different processing method. We attribute the minor FF differences to the increased SAM-HTL thickness (from ≈2–3 nm in solution-processed to ≈6 nm in evaporated). We note that we also achieve similar performance for evaporated MeO-2PACz compared to its solutionprocessed counterpart (see Figure S5, Supporting Information). 

Next, we examine non-radiative recombination at the HTL/ perovskite interface for both reference solution-processed and evaporated SAMs in detail. First, we perform PLQY measurements on samples in the half-stack ITO/2PACz/perovskite (see **Figure 2** a). We refrained from introducing an electron transport layer (ETL) to exclude the prominent non-radiative 

recombination losses at the perovskite/ETL interface when employing C60.<sup>[55,56]</sup> For the reference stack, we measure an average PLQY of ≈1.26% corresponding to an implied _V_ OC of 1.253 V, comparable to previously reported values for similar perovskite composition.<sup>[44,57]</sup> In line with the measured _V_ OC statistics, the PLQY and implied _V_ OC in case of evaporated 2PACz are slightly enhanced to average values of ≈1.7% and 1.261 V, respectively (Figure 2a,b). To obtain the internal ideality factor ( _n_ id), we perform intensity-dependent PLQY measurement for the corresponding half-stacks and apply a fit to the calculated implied _V_ OC as reported in our previous work.<sup>[56,58]</sup> The ideality factor for evaporated 2PACz is _n_ id = 1.48, which is comparable to _n_ id = 1.50 for solution-processed 2PACz, emphasizing that the recombination mechanism at the HTL/perovskite interface is similar in both cases (Figure 2c). This is further corroborated by TRPL measurements that exhibit similar decay dynamics for both solution-processed and evaporated 2PACz with an average lifetime of 435 and 474 ns, respectively (Figure 2d). Further investigations on full device stacks employing solutionprocessed and evaporated 2PACz utilizing electrochemical impedance spectroscopy, transient photocurrent, and capacitance–frequency measurements show comparable trends as well (see Figure S6, Supporting Information). Similarly, we investigate the photophysical properties of ITO/MeO-2PACz/ perovskite half-stacks. As indicated by PLQY, implied _V_ OC, ideality factor and TRPL data in Figure S7, Supporting Information, employing evaporated MeO-2PACz exhibits comparable results to its solution-processed counterpart, in full agreement with the results for 2PACz. Overall, this data suggests that the quality of the PSCs with evaporated SAM-HTL is very similar to the solution-processed counterparts. 

As solution-processed carbazole-based SAM-HTLs possessing a monolayer signature are reported to form a near lossless interface,<sup>[8,44]</sup> it is necessary to investigate the quality of the 

**2203982 (3 of 13)** 

_Adv. Energy Mater._ **2023** , _13_ , 2203982 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 











**Figure 2.** a) Comparison of the photoluminescence quantum yield (PLQY) for the half-stack ITO/2PACz/PVK, for solution-processed and evaporated (≈6 nm) 2PACz. b) The corresponding implied _V_ OC. c) Ideality factor ( _n_ id) extracted from a fit to the intensity-dependent implied _V_ OC. d) Time-resolved photoluminescence (TRPL) spectrum for the corresponding half-stack employing the two HTLs. 

evaporated SAM/perovskite interface if the evaporated SAM thickness is varied. To advance our understanding of the evaporated SAM-HTL materials, we perform a systematic study on the effect of evaporated SAM layer thickness on the photophysical properties utilizing 2, 4, 6, 8, and 20 nm thick evaporated 2PACz in the layer stack ITO/evaporated 2PACz/perovskite. We find that the evaporated 2PACz/perovskite interface is of high quality and non-radiative recombination is effectively suppressed independent of the evaporated 2PACz film thickness as indicated by the PLQY, implied _V_ OC, ideality factor, and TRPL data in Figure S8, Supporting Information. Although photophysical properties are independent of evaporated film thickness, we note a slight drop in FF for PSCs employing thicker layers of evaporated 2PACz (>8 nm), which we attribute to a slight increase in series resistance. Furthermore, the hysteresis factor increases from 1.7% in PSCs employing the optimized thickness (≈6 nm) to 4.7% when ≈20 nm evaporated 2PACz layer is employed (see Figure S9, Supporting Information). Applying an extra washing step to the optimized film thickness (≈6 nm) of evaporated 2PACz, as described in the Experimental Section, we see remarkable difference neither in photophysical properties (see Figure S11, Supporting Information) nor PV parameters (see Figure S12, Supporting Information), in full agreement with the previously reported solution-processed 2PACz case.<sup>[8]</sup> 

We conclude that the comparable PV parameters implied _V_ OC, ideality factor, and charge carrier lifetime for evaporated 

and solution-processed SAMs indicate that the evaporated SAMs/perovskite interface is of a high quality and effectively minimizes non-radiative recombination. Since PSCs employing evaporated SAMs are of a high PV performance, it is interesting to advance our understanding of the thermally evaporated films by next investigating their chemical environment and comparing it to their solution-processed counterparts to ensure any minor changes are not due to chemical changes in the evaporated material. 

### **2.2. Chemical Environment and Surface Chemistry of Evaporated 2PACz** 

The chemical environment and surface chemistry of evaporated and solution-processed 2PACz thin films are quite similar, demonstrated using XPS measurements of ≈6 nm evaporated 2PACz thin films deposited on glass/ITO substrates. Overall, we observe no significant differences in characteristic XPS peak positions and relative area for the evaporated film compared to previously reported data of solution-processed 2PACz layers.<sup>[8,59]</sup> The surface-sensitive XPS spectrum of the evaporated 2PACz film exhibits a prominent peak of the C 1s core levels in the corresponding binding energy region (see **Figure 3** a). The N 1s and P 2p regions are shown in Figure S10, Supporting Information. No sign of degradation is apparent, which would give rise to unexpected contributions to the signals, indicating no chemical 

**2203982 (4 of 13)** 

_Adv. Energy Mater._ **2023** , _13_ , 2203982 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 3.** a) X-ray photoelectron spectrum for the C 1s region of the ≈6 nm 2PACz thin film evaporated onto glass/ITO substrate. The orange solid line represents a fit to the real data points (orange dots) and the dashed black lines show the components thereof. b) Reflection–absorption infrared spectra of evaporated 2PACz thin films with different thickness onto glass/ITO substrates. The green dashed line represent the peak position of POH vibration band of the bulk 2PACz reported in Ref. [8] while the black dashed line represent the PO monolayer signature in a solution-processed 2PACz layer.<sup>[8]</sup> c–e) Top view scanning electron microscope images of perovskite thin films deposited over c) solution-processed 2PACz layer, d) ≈6 nm evaporated 2PACz layer, and e) ≈200 nm evaporated and washed 2PACz layer, respectively. The scale bar is 1 µm. 

changes in the 2PACz molecule upon evaporation compared to previously reported solution-processed samples.<sup>[8]</sup> Similar to previous works, we associate the C 1s signal of 2PACz with 3 characteristic components attributed to CC and CH bonds with a binding energy of ≈284.0 eV, a CN bond with a binding energy of ≈284.7 eV, and a third peak at ≈285.8 eV. The third peak with a similar binding energy has previously been attributed to C atoms bonded to three other atoms in the carbazole fragments hypothesized by Al-Ashouri et al.<sup>[8]</sup> An alternative explanation was posited by Levine et al., who attributed this peak to CP bonds.<sup>[59]</sup> Furthermore, the peak might also correlate to a hypothetical contamination that gives rise to COC or COH contaminations.<sup>[60]</sup> Irrespective, the similarity in XPS signal strongly suggest a similar chemical environment of the evaporated and solution-processed layer. Furthermore, the XPS signal of the C 1s region for 2PACz powder (see Figure S13, Supporting Information) is comparable to that of the evaporated 2PACz thin film, indicating no sign of degradation due to thermal evaporation. 

Comparing the relative area associated to these peaks, the chemical environment in the thin films is analyzed in more detail. For evaporated 2PACz thin films, we find that the CC and CH bonds exhibit a relative weight/area of 53.4% and the CN bond exhibits a relative weight/area of 33.1%. It should be noted that CN bonds are also evident in the N 1s binding energy region as shown in Figure S10a, Supporting Information. While it is possible to attribute the third peak in the C 1s binding energy region to CP bonds,<sup>[59]</sup> it is necessary to ensure the presence of the essential functional phosphonic anchoring group component in the evaporated thin film by investigating the P 2p binding energy region. Indeed, the P 2p binding energy region (see Figure S10b, Supporting Information) 

shows a strong phosphorus presence, with a signal that can be extracted into two peaks representing P 2p3/2 and P 2p1/2 at ≈133 and ≈134 eV, respectively. Literature indicates these peaks potentially correlate to PO species, however, this is still insufficient evidence to claim they prove the formation of a monolayer at the ITO interface.<sup>[61–64]</sup> Further investigations on the In 3d, and Sn 3d energy regions, display no remarkable shift in the peak positions when the 2PACz is evaporated or solutionprocessed over ITO (see Figure S14, Supporting Information), and we don't expect the deposition method to have a strong impact on the work function. We attribute the decreased signal to the higher thickness of the evaporated 2PACz thin film (≈6 nm), compared to a solution-processed layer (≈2–3 nm). Next to the surface sensitive analysis with XPS, we employed reflection–absorption infrared spectroscopy (RAIRS) on evaporated 2PACz thin films (≈6, ≈100, and ≈200 nm) to evaluate their surface chemistry and confirm our observations on the chemical environment. The characteristic absorption bands of the molecular vibrational modes for evaporated 2PACz thin films are shown in Figure 3b. We note that evaporated thin films exhibit molecular vibrational bands comparable to previously reported solution-processed 2PACz monolayers.<sup>[8]</sup> Notably, the carbazole ring stretching vibration bands are present in the 1454–1486 cm<sup>−1</sup> region, and the two characteristic carbazole ring stretching modes are present at 1239 and 1346 cm<sup>−1</sup> , indicating the carbazole ring is intact.<sup>[8]</sup> Interestingly, and more importantly in the context of using evaporated 2PACz thin films for PSCs, the organic phosphonic acid functional group is detected to be covalently bonded to the metal oxide surface as indicated by the peak at ≈1017 cm<sup>−1</sup> , which is assigned to the PO species bound to the ITO.<sup>[8]</sup> The presence of this PO peak is a strong fingerprint that the bonding at 

**2203982 (5 of 13)** 

_Adv. Energy Mater._ **2023** , _13_ , 2203982 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

the interface between evaporated 2PACz and ITO is the same as for solution-processed 2PACz (see black dashed reference line in Figure 3b). Coupled with our previous XPS data, this is sufficient evidence to claim that evaporated 2PACz thin films exhibit the same interfacial bonds with ITO compared to the solution-processed SAMs. 

Further study of the RAIR spectrum for thicker 2PACz films provides additional insights. Notably, the POH peak at ≈951 cm<sup>−1</sup> , which has previously been shown to be prominent in the bulk of the 2PACz,<sup>[8]</sup> is not present for our thin evaporated 2PACz film (≈6 nm, see Figure 3b(i)). However, for thick evaporated 2PACz films (≈100 and ≈200 nm, see Figures 3b(ii) and 3b(iii), respectively), the POH peak emerges in the RAIR spectrum, in perfect agreement with the reported peak position of the Fourier-transform infrared (FTIR) spectrum obtained from 2PACz powder pressed into a KBr tablet (see green dashed reference line in Figure 3b).<sup>[8]</sup> The presence of this broad POH peak in the evaporated thick film indicates that thicker films possess similar chemical properties to the bulk material. Remarkably, the fingerprint of the PO bond is visible even if not all the phosphonic acid anchoring groups are deprotonated (e.g., in an ≈200 nm thick film), indicating that the bond at the ITO interface is similar independent of film thickness. 

In theory, washing a thick evaporated 2PACz film thoroughly is expected to remove weakly bound bulk molecules, leaving only a residual monolayer comprised of strongly bound PO species at the ITO interface, which are essential for efficient PSCs (the same principle holds for solution-processed layers as reported by Al Ashouri et al. with estimated thickness of ≈1–3 nm for the residual monolayer).<sup>[8]</sup> Indeed, washing 200 nm films with ethanol as described in the Experimental Section, enabled fabrication of PSCs with ≈80% FF and an average PCE of ≈19% (see Figure S15, Supporting Information), comparable to PSCs fabricated using solution-processed 2PACz and the 4–8 nm evaporated 2PACz films discussed above. 

We conclude that evaporating SAMs shows no indication of a change to the chemical environment of the molecules, nor does it impact the nature of the bonding with subjacent ITO. Furthermore, efficient PSCs can be fabricated employing very thick evaporated 2PACz films, given they have been sufficiently washed. However, this washing step is not required for thin films and we recommend using the optimized thickness (4–8 nm) without an extra washing step to increase the throughput. 

### **2.3. Solving the Dilemma of Low Fabrication Yield for Me-4PACz HTLs** 

The SAM-HTL Me-4PACz was introduced to the perovskite community in 2020.<sup>[44]</sup> It demonstrated enhanced phase and long term stability, reduced non-radiative recombination at the HTL/perovskite interface and more efficient charge carrier extraction as compared to the previously reported carbazolebased SAMs of 2PACz and MeO-2PACz.<sup>[44,59]</sup> However, to the best of our knowledge, it has been employed in only 6 publications since then,<sup>[5,47,59,65–67]</sup> which seems surprising considering the excellent reported properties.<sup>[44]</sup> The primary reason 

**www.advenergymat.de** 

for this is the poor surface coverage for perovskite thin films deposited onto a Me-4PACz coated ITO surface (see Figure S17, Supporting Information), which results in a very low fabrication yield. This observation is supported by literature utilizing Me-4PACz, indicating it is not an issue exclusively present in our work.<sup>[5,47,67]</sup> 

Recently, Tockhorn et al. reported a 29.80% PCE for a monolithic perovskite/Si tandem solar cell employing Me-4PACz as HTL (the world record as of 24th of May, 2022).<sup>[47]</sup> The study stresses a low fabrication yield (≈50%) caused by poor surface coverage of solution-processed perovskite thin films on Me-4PACz coated planar Si bottom cells. Fabrication yield increased dramatically (up to ≈95%) by nano-texturing the Si bottom cell, which was attributed to an improved droplet retention of the precursor solution on textured surfaces. In the same context, Jošt et al. have reported the current world record of monolithic perovskite/CIGS tandem solar cells with a PCE of 24.2% employing Me-4PACz as HTL.<sup>[5]</sup> In full agreement with Tockhorn et al., the low fabrication yield issue was discussed and assigned to poor wetting. Their discussion on methods to further improve PCE theorizes that Me-4PACz wettability issue needs to be tackled.<sup>[5]</sup> In this regard, Taddei et al. have employed a layer of Al2O3 nanoparticles on top of Me-4PACz to enhance its surface wettability.<sup>[67]</sup> 

In full agreement with these previous reports,<sup>[5,47,67]</sup> we find that the solution-processed Me-4PACz surface exhibits exceptionally poor surface wettability as indicated by high contact angles summarized in **Figure 4** a and Table S1, Supporting Information.<sup>[68–70]</sup> This comes along with a low surface coverage of the perovskite thin film (as shown in Figure S17, Supporting Information) and, in turn, low fabrication yield and poor performance. We note that washing the solution-processed Me4PACz layers does not enhance the surface wettability. Strikingly, the evaporated Me-4PACz surface exhibits significantly lower contact angles for H2O, C2H6O2, and CH2I2, (27.1°, 9.2°, and 21.5°, respectively), in stark contrast to the solution-processed counterpart (64.4°, 36.2°, and 39.6°, respectively). This enhanced surface wettability results in considerably improved surface coverage for solution-processed perovskites when evaporated Me-4PACz is employed as HTL as shown in Figure S17, Supporting Information. 

Comparing the two other SAMs (2PACz and MeO-2PACz), contact angle measurements on evaporated MeO-2PACz exhibit no statistically significant change compared to solution-processed layers for H2O and C2H6O2 (62.5°/63.6° and 39.1°/39.7°, respectively) and a relatively minor decrease for CH2I2 (29.6°/22.9°). While the H2O contact angle of MeO2PACz is similar to solution-processed Me-4PACz, the CH2I2 contact angle is in line with 2PACz or evaporated Me-4PACz. We consider this indicative of a higher dispersive free energy at the sample surface (estimated in Table S1, Supporting Information),<sup>[71]</sup> which can explain the lack of reported wetting problems when utilizing MeO-2PACz. Meanwhile, evaporated 2PACz surfaces exhibit significantly reduced contact angles for polar solvents compared to their solution-processed counterparts (52°/17.7° for H2O and from 31.7° to complete wetting for C2H6O2), with a minor decrease for the non-polar CH2I2 (29.7°/25.7°). Overall, evaporated SAMs exhibit clear trends of lower contact angles compared to their solution-processed 

**2203982 (6 of 13)** 

_Adv. Energy Mater._ **2023** , _13_ , 2203982 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 







**Figure 4.** a) On top, comparison of the contact angle of water, ethylene glycol, and diiodomethane droplets with the half-stack glass/ITO/evaporated and solution-processed Me-4PACz. Below are images of the water droplet in the two cases. The light blue line, indicating the tangent of the solvent at the surface is used to calculate contact angle. b) Statistical distribution of the FF, _J_ SC, _V_ OC, and PCE of perovskite solar cells employing evaporated (≈6 nm) Me-4PACz and solution-processed 2PACz HTLs. A comparison between forward and reverse scan is shown in Figure S16, Supporting Information. 

counterparts, which indicates improved wettability, surface coverage and consequently a higher fabrication yield of PSCs. 

While we observe a significant improvement in wettability and surface coverage for evaporated Me-4PACz layers, it is important to ensure this has not occurred at the expense of interfacial properties and device performance. Therefore, we investigated the impact of evaporating Me-4PACz on the photophysical properties of the half-stack ITO/Me-4PACz/perovskite similar to the analysis for 2PACz and MeO-2PACz above. Evaporated Me-4PACz exhibits no significant difference in charge carrier lifetime from TRPL decay as shown in Figure S18a, Supporting Information (585 and 568 ns for evaporated and solution-processed, respectively). Furthermore, PLQY, implied _V_ OC, and ideality factor measurements (see Figure S18b–d, Supporting Information) indicate that evaporated Me-4PACz layers with an optimized thickness of ≈6 nm even slightly outperform their solution-processed counterparts. This clearly indicates the interface quality is maintained and non-radiative recombination is effectively suppressed (PLQY, TRPL, implied _V_ OC, and ideality factor data for different Me-4PACz thicknesses are shown in Figure S19, Supporting Information). 

Having tackled the poor surface coverage problem, and ensuring there is no drawback in photophysical properties for evaporated Me-4PACz, we investigate its impact on fabrication yield and photovoltaic device performance. Strikingly, we succeed in fabricating planar single-junction PSCs with close to ≈100% fabrication yield using ≈6 nm evaporated Me-4PACz without washing as HTL. In the same batch, we were unsuccessful in fabricating comparable devices using solution processing Me-4PACz for the above discussed reasons, making a direct comparison unreliable. Instead, we perform a comparison to solution-processed 2PACz from the same batch. As shown in Figure 4b, the average _V_ OC of PSCs fabricated with evaporated Me-4PACz as HTL in the device stack ITO/Me-4PACz/ perovskite/LiF/C60/BCP/Ag is ≈1.22 V, which is ≈20 mV higher than the equivalent stack employing solution-processed 2PACz. 

The enhancement in _V_ OC for Me-4PACz based PSCs is in full agreement with the reported results for solution-processed Me4PACz employing the same device stack.<sup>[44]</sup> While the average FF decreased for evaporated Me-4PACz as compared to solution-processed 2PACz, the lack of a direct comparison to solution-processed Me-4PACz prevents us from determining if this is an effect of the material or deposition method. Devices with evaporated Me-4PACz exhibit a slightly higher average PCE of 19.2% as compared to solution-processed 2PACz with 19.0% (see Figure 4b). 

We conclude that evaporated SAM-HTLs consistently display a reduced contact angle for a variety of solvents, improving wettability and surface coverage of the subsequent solutionprocessed perovskite absorber. This is most relevant for Me4PACz, which has established problems with yield and surface coverage, and is expected to facilitate an easier adoption of the material into architectures that have previously been considered incompatible. When deposited via thermal evaporation, we improve the fabrication yield dramatically, achieving nearly 100% yield. Finally, we confirm that evaporated Me-4PACz have comparable optoelectronic properties as compared to solutionprocessed Me-4PACz, resulting in PSCs with similar PCE and slightly improved _V_ OC to that of solution-processed 2PACz. We consider this an indication that the excellent properties of Me4PACz remain unaffected by evaporation. 

### **2.4. Evaporated 2PACz over Micrometer-Sized Textures** 

Recently, a record PCE of 31.25% for monolithic 2T perovskite/ Si tandem solar cells has been reported utilizing a textured Si sub-cell.<sup>[1]</sup> There are no doubts as to the efficient light harvesting that a textured surface enables due to its light trapping effect.<sup>[48,72–79]</sup> However, introducing a conformal HTL layer over textures using solution-processed techniques remains challenging due to the complex geometry of a micrometer sized 

**2203982 (7 of 13)** 

_Adv. Energy Mater._ **2023** , _13_ , 2203982 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

pyramidal texture.<sup>[77]</sup> Furthermore, the large surface area that a textured surface exhibits compared to a planar surface is expected to result in high non-radiative recombination losses. Hence, selecting a proper HTL and ensuring total surface coverage when processing over a textured surface is necessary to minimize voltage losses at the HTL/perovskite interface and maintain high fabrication yield. 

NiO _x_ deposited via PVD methods has consistently demonstrated conformal coverage over micrometer-sized textures.<sup>[75,80]</sup> Although NiO _x_ -based PSCs often exhibit good long-term stability,<sup>[23,81,82]</sup> it has been reported to result in relatively high hysteresis and voltage losses.<sup>[19,26,83–85]</sup> Combining a sputtered NiO _x_ layer to provide uniform and conformal coverage with solutionprocessed SAMs as a double-layer HTL has demonstrated comparable or even superior PCEs compared to PSCs using standalone solution-processed SAMs processed over planar and micrometer-sized textured substrates.<sup>[4,17,27,49,50,86–88]</sup> Given that uniform coverage is even more crucial for a textured surface, this combination is expected to be beneficial. Recently, Liu and coworkers have reported on fully textured, production line compatible monolithic perovskite/Si tandem solar cells with ≈29% PCE.<sup>[17]</sup> In their work, they extensively investigated the benefit of introducing a double-layer HTL of NiO _x_ and solution-processed 2PACz. The increase in _V_ OC for tandems employing the double-layer HTL compared to standalone solution-processed 2PACz is remarkable (≈30 mV). 

Evaporated SAMs are expected to possess the virtues of NiO _x_ without the associated issues. They ensure conformal surface 

coverage akin to a vacuum-deposited NiO _x_ layer, preventing detrimental shunting paths. Simultaneously, SAMs suppress non-radiative recombination, leading to the desired reduced _V_ OC losses at the HTL/perovskite interface. To confirm our expectations, specifically with regards to non-radiative recombination at the HTL/perovskite interface, we evaporate (≈6 nm) 2PACz over micrometer-sized textured Si substrates (see scanning electron microscope [SEM] image in Figure S20, Supporting Information). To quantify interfacial recombination, PLQY measurements on the half-stack of textured Si/ITO/HTL/perovskite ( **Figure 5** a) employing NiO _x_ , a double-layer of NiO _x_ and solution-processed 2PACz, and standalone evaporated 2PACz as HTLs are compared. We use a 1.6 m solution of the doublecation perovskite with the composition Cs0.17FA0.83PbI2.75Br0.25, optimized in our previous work for deposition on textured surfaces.<sup>[86]</sup> For the reference stack (employing single-layer NiO _x_ as HTL), we note a very low PLQY with an average of 0.3%, indicating substantial interfacial recombination. Depositing a solution-processed 2PACz layer onto the sputtered NiO _x_ film enhances the PLQY to an average value of 2.5%. At an average value of 4.3%, evaporated 2PACz exhibits roughly double this PLQY, as shown in Figure 5b. These results translate to an implied _V_ OC of 1.213 V for evaporated 2PACz compared to 1.145 V for the NiO _x_ single-layer and 1.195 V for the NiO _x_ /solution-processed 2PACz double-layer HTL (see Figure 5c). The ideality factor for the three stacks employing NiO _x_ , NiO _x_ /solution-processed 2PACz and evaporated 2PACz are 1.74, 1.53 and 1.33 respectively, indicating the superiority of evaporated 2PACz 













**Figure 5.** a) Schematic diagram of the ITO/HTL/PVK (double-cation [Cs0.17FA0.83PbI2.75Br0.25]) half-stack on a micrometer-sized textured Si substrate. The HTL applies for NiO _x_ , a double-layer of NiO _x_ and solution-processed 2PACz, and standalone (≈6 nm) evaporated (Evap.) 2PACz. b) Comparison of the PLQY for the half-stack when the three different HTLs are used and c) the corresponding implied _V_ OC. d) Ideality factor ( _n_ id) extracted from a fit to the intensity-dependent implied _V_ OC. 

**2203982 (8 of 13)** 

_Adv. Energy Mater._ **2023** , _13_ , 2203982 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

over the micrometer-sized texture. Overall, replacing a NiO _x_ - based HTL with a purely evaporated 2PACz HTL results in a significantly improved interface, with suppressed non-radiative recombination and thus improved implied _V_ OC. 

## **3. Outlook** 

In the race toward PCEs beyond the theoretical limit of a singlejunction solar cell, monolithic tandems utilizing a textured bottom subcell have shown quite some progress holding the current record PCE.<sup>[1]</sup> The above demonstrated compatibility and uniform coverage of evaporated SAM-HTLs onto such textured surfaces will be a significant step forward toward high fabrication yield and potentially further improved PCEs. 

As perovskite technologies push toward large area commercialization, a considerable research focus has been applied to depositing active layers via scalable deposition techniques. Such techniques like thermal evaporation, blade coating, spray coating, inkjet printing, and slot-die coating have recently shown a step forward toward efficient large area PSCs.<sup>[46,51,52,76,89–95]</sup> In this regard, evaporating SAMs opens further channels for lossless HTLs to be employed in large active area devices and modules. 

In the same context, evaporated perovskites have presented themselves as a strong candidate for efficient PSCs being employed as a single-junction or in tandem solar cells with relatively high efficiencies.<sup>[46,96–103]</sup> Current high efficiency evaporated perovskites utilize solution-processed MeO-2PACz as HTL, both to mitigate voltage losses and because it has been theorized to stabilize the resultant perovskite and enhance stability.<sup>[46,103]</sup> As the evaporated SAMs shown in this work display comparable performance to their solution-processed predecessors, they open the road for further development into all-evaporated high efficiency PSCs. 

## **4. Conclusion** 

In this work, we present for the first time thermal evaporation of near-lossless SAM-HTL layers (2PACz, MeO-2PACz, and Me-4PACz) to enhance their process flexibility. We determined through FTIR and XPS that the chemical properties of SAMs are unchanged by the thermal evaporation process, identifying the monolayer signature to demonstrate they continue to form a monolayer at the ITO interface independent of final film thickness. Through analysis of PLQY data we observe a slight improvement in implied _V_ OC when evaporating these layers (1.253 to 1.261 V for 2PACz, 1.219 to 1.220 V for MeO-2PACz, and 1.259 to 1.265 V for Me-4PACz). When coupled with TRPL measurements, we conclude that the lossless interfacial properties are preserved. The quality of the interface is reflected in PV parameter data, with an improvement in mean values from 18.5% to 18.9% PCE measured for 2PACz. Furthermore, a study of contact angle for each film finds that the wettability of perovskite on Me-4PACz is significantly improved for evaporated samples, increasing the fabrication yield to nearly 100%, significantly enhancing the applicability of this promising material. Finally, we demonstrate that high quality layers are uniformly 

**www.advenergymat.de** 

deposited even over textured surfaces, which have previously typically required an additional NiO _x_ layer to ensure conformal coating. Evaporated layers show an improved implied _V_ OC compared to NiO _x_ layers from 1.145 to 1.213 V. In summary, we find that our new deposition method for these materials enhances their applicability without sacrificing their lauded interfacial properties or resultant PSC performance. 

## **5. Experimental Section** 

_Evaporation of Self-Assembled Monolayer Thin Films_ : Evaporated SAM (2PACz, TCI), (MeO-2APCz, TCI), and (Me-4PACz, TCI) thin films were fabricated via PVD from a crucible in a thermal evaporation system (Creaphys, OPTIvap). All films were deposited at pressures of ≈5 × 10<sup>−6</sup> mbar, at rates of 0.15–0.25 Ås<sup>−1</sup> measured using a quartz crystal microbalance (QCM). Increasing deposition rates up to 0.6 Ås<sup>−1</sup> did not have a noticeable impact on device performance. Initial deposition temperatures for each evaporated SAM were as follows: 160 °C for 2PACz, 140 °C for MeO-2PACz, and 170 °C for Me-4PACz. Prior to each deposition, crucibles were cleaned with isopropyl alcohol such that each deposition utilized only a new material. While 2PACz and Me-4PACz films did not demonstrate a noticeable change in device performance when depositing without removing previous material from the crucible, for consistency new material was used each time. 

_Washing of Evaporated Thin Films_ : Evaporated films were washed using 1 step spin-coating program (3000 rpm for 40 s) and 600 µL of ethanol (Sigma-Aldrich, anhydrous). 150 µL of ethanol was dripped statically ≈5 s before starting the spin-coating program, followed by 150 µL dynamically every ≈10 s. This additional washing step was only utilized for specified films. 

_Fabrication of Perovskite Solar Cells_ : Planar _p-i-n_ PSCs were fabricated with the architecture of: glass/ITO/SAM/ Cs0.17FA0.83PbI2.75Br0.25/LiF/ C60/BCP/Ag. ITO substrates (Luminescence Technology) were cut to a 1.6 cm × 1.6 cm area and cleaned with acetone and isopropanol in an ultrasonic bath for 15 min each. Substrates were treated with oxygen plasma for 3 min immediately prior to deposition of the HTL. 

Solution-processed SAM HTLs were prepared and processed as reported in Ref. [44]. Evaporated SAM HTLs were deposited as detailed above, with optimal thicknesses of 4–8 nm. 

Perovskite precursor solution was prepared by dissolving lead iodide (PbI2, TCI) in 4:1 _N_ , _N_ -dimethylformamide (DMF, Sigma Aldrich):dimethyl sulfoxide (DMSO, Sigma Aldrich). The solution was heated up for 25 min at 120 °C and left to cool down for ≈10 min. Afterward, the mixed solution was transferred to the lead bromide (PbBr2, TCI), cesium iodide (CsI, Alfa Aesar), methylammonium bromide (MABr, Great Cell Solar), and formamidinium iodide (FAI, Great Cell Solar) and vigorously agitated until all the powders were dissolved. The deposition parameters and further details can be found in Ref. [4]. The double-cation perovskite was prepared and processed as reported in Ref. [27]. 

A 1 nm LiF passivation layer followed by an ETL comprised of 20 nm fullerene (C60, Alfa Aesar) and 7 nm bathocuproine (BCP, Luminescence Technology), was thermally evaporated at a 0.1–0.2 Ås<sup>−1</sup> rate (determined via quartz crystal microbalance [QCM]) under a pressure of ≈10<sup>−6</sup> mbar in an vacuum evaporation system (Angstrom). All samples were finished with the evaporation of a 100 nm Ag rear electrode, with an active area of 10.5 mm<sup>2</sup> defined via shadow mask. 

_Characterization Methods_ : Field emission top-view SEM images were taken with a SEM (ZEISS, LEO Gemini 1530) with an aperture size of 20 µm and an accelerating voltage of 5 kV. 

_Contact Angle Measurements_ : Contact angle measurements used an optical contact angle and drop contour analyzer (DataPhysics Instruments GmbH, OCA 200). The polar and dispersive parts of the surface free energy were calculated after the OWRK model.<sup>[71]</sup> A highspeed camera (2450 fps) was utilized for the measurements to minimize potential liquid-surface interactions, which would preclude exact calculations of surface energetics.<sup>[104]</sup> 

**2203982 (9 of 13)** 

_Adv. Energy Mater._ **2023** , _13_ , 2203982 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

_Current Density–Voltage (J-V) Measurements_ : _J–V_ characteristics were measured using a class AAA solar simulator (Newport, Oriel Sol3A) at a power density of 100 mWcm<sup>−2</sup> , calibrated via a silicon solar cell (Newport) equipped with a KG5 bandpass filter to simulate the AM 1.5G solar spectrum. Scan rate during measurement was set to 0.6 Vs<sup>−1</sup> using a source meter (Keithley, 2400 A). Stable power output efficiency of PSCs was determined by tracking MPP under continuous AM 1.5G illumination. Solar cell temperature during measurements was actively regulated by a Peltier element connected to a microcontroller set to 25 °C. 

_External Quantum Efficiency (EQE) and Absorption Measurements_ : EQE spectra were measured in the wavelength range of 300 to 850 nm using photovoltaic QE system (Bentham instruments, PVE300). The system was calibrated with a silicon reference cell and employed a 0.74 mm<sup>2</sup> illumination area, chopping frequency of ≈575 Hz, and an integration time of 500 ms to acquire the spectra. The transmittance and reflectance measurements were performed using a LAMBDA 1050 spectrometer (PerkinElmer). 

_Time-Resolved Photoluminescence Measurements (TPRL)_ : TRPL was acquired based on an FLSP920 Fluorescence Spectrometer (Edinburgh Instruments Ltd.) using the time-correlated single photon counting (TCSPC) acquisition technique. A picosecond pulsed laser diode (PicoQuant, 635 nm) externally triggered by a delay generator (repetition rate: 150 kHz) was employed as the excitation light. The emission was collected by a photomultiplier tube (Hamamatsu R928P). The measurements were conducted in air. 

_Photoluminescence Quantum Yield Measurements and Calculations (PLQY)_ : The measurements were performed as detailed in the authors’ previous work.<sup>[27,56]</sup> 

_X-Ray Photoelectron Spectroscopy Measurements (XPS)_ : XPS measurements were performed with a Kratos Axis Ultra system equipped with a monochromatic Al k _α_ X-ray source (1486.6 eV). High-resolution data were acquired with a pass energy of 20 eV and survey spectra with a pass energy of 80 eV. CasaXPS was used to analyze the data. The peaks were fitted with a mixture of Gaussian and Lorentzian shape after subtraction of a Shirley background. For the P 2p3/2 and P 2p1/2 peaks the binding energy splitting and the area ratio was constrained to 0.84 eV and 2:1, respectively. The samples were stored in Argon filled boxes, which were opened shortly before the samples were mounted on the sample holder. A charge-neutralizer was used and the binding energy was calibrated to Sn 3d5/2 peak of the ITO at 486.5 eV. The 2PACz powder sample was prepared by pressing ≈1.5 mg of the material into indium foil and mounted to the holder using double-sided tape. 

_Reflection-Absorption Infrared Spectroscopy (RAIRS)_ : RAIRS data were recorded using a spectrometer (Bruker, Vertex 80v) equipped with a liquid nitrogen cooled narrow-band MCT detector. Samples were placed onto a horizontal accessory in a spectrometer chamber under low vacuum (≈3 mbar). A bare ITO substrate was used for a reference. Spectra were taken with p-polarized incident light after incubation of samples in vacuum for 180 s. Spectral resolution was set to 4 cm<sup>−1</sup> , aperture size to 4 mm, and spectra were acquired by averaging 256 scans. 

_Electrochemical Impedance Spectroscopy (EIS)_ : EIS for the full device stack was conducted using Paios system. The sweep frequency was from 1 Hz to 1 MHz with 70 mV amplitude and offset voltage equivalent to the device's _V_ OC. Further details can be found in Ref. [105]. 

**www.advenergymat.de** 

(HYIG of U.W.P. [VHNG-1148]), the Helmholtz Energy Materials Foundry (HEMF), the German Federal Ministry for Economics and Climate Action (BMWK) through the project 27Plus6 (03EE1056B) as well as project SHAPE (03EE1123A), and the Karlsruhe School of Optics and Photonics (KSOP). The authors acknowledge the Helmholtz Association (program-oriented funding IV, Materials and Technologies for the Energy Transition, Topic 1: Photovoltaics and Wind Energy, Code: 38.01.02). M.H. acknowledges RISC funding. A.F. thanks Harald Giessen from the University of Stuttgart for his cooperation. A.F. thanks Helge Eggers for organizing the measurements at the Innovation Lab in Heidelberg. The authors are grateful for funding from the  European Commission, Horizon Europe research and innovation program  under grant agreement no. 101075330 (NEXUS). 

Open access funding enabled and organized by Projekt DEAL. 

## **Conflict of Interest** 

The authors declare no conflict of interest. 

## **Author Contributions** 

A.F. and T.F. contributed equally to this work. U.W.P. supervised the whole project. A.F. and T.F. planned all the experiments under the supervision of U.W.P. P.F. performed the PLQY measurements and analyzed the data. I.M.H. performed the first evaporation of 2PACz with assistance from T.F. T.F. developed the deposition process of the evaporated SAMs used in this work with significant assistance from A.F. A.F. fabricated the PSCs with assistance from T.F. A.D. performed the SEM measurements. F.S. performed the contact angle measurements and designed the graphical abstract. M.A.R. and D.B.R. developed the triple-cation perovskite. R.S. performed the EIS measurements and B.A.N. developed the double-cation perovskite. R.B. and M.H. performed the RAIRS measurements. K.K. and U.S. performed and analyzed the XPS measurements. Y.L. performed the TRPL measurements. F.L. provided notable assistance in writing and correcting the manuscript. All authors have contributed in correcting and enhancing the quality of the discussion in the manuscript. 

## **Data Availability Statement** 

The data that support the findings of this study are available from the corresponding author upon reasonable request. 

## **Keywords** 

hole transport layers, implied open-circuit voltage, interface engineering, perovskite solar cells, self-assembled monolayers 

Received: November 22, 2022 Revised: December 15, 2022 Published online: January 4, 2023 

## **Supporting Information** 

Supporting Information is available from the Wiley Online Library or from the author. 

## **Acknowledgements** 

The authors thank Christoph Klein for fruitful and inspirational discussions. The authors gratefully acknowledge financial support by the Initiating and Networking funding of the Helmholtz Association 

- [1] NREL Best Research-Cell Efficiency Chart, https://www.nrel.gov/ pv/cell-efficiency.html (accessed: November 2022). 

- [2] M. Kim, J. Jeong, H. Lu, T. K. Lee, F. T. Eickemeyer, Y. Liu, I. W. Choi, S. J. Choi, Y. Jo, H. B. Kim, S. I. Mo, Y. K. Kim, H. Lee, N. G. An, S. Cho, W. R. Tress, S. M. Zakeeruddin, A. Hagfeldt, J. Y. Kim, M. Grätzel, D. S. Kim, _Science_ **2022** , _375_ , 302. 

- [3] Z. Li, B. Li, X. Wu, S. A. Sheppard, S. Zhang, D. Gao, N. J. Long, Z. Zhu, _Science_ **2022** , _376_ , 416. 

**2203982 (10 of 13)** 

_Adv. Energy Mater._ **2023** , _13_ , 2203982 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

- [4] M. A. Ruiz-Preciado, F. Gota, P. Fassl, I. M. Hossain, R. Singh, F. Laufer, F. Schackmar, T. Feeney, A. Farag, I. Allegro, H. Hu, S. Gharibzadeh, B. A. Nejand, V. S. Gevaerts, M. Simor, P. J. Bolt, U. W. Paetzold, _ACS Energy Lett._ **2022** , _7_ , 2273. 

- [5] M. Jošt, E. Köhnen, A. Al-Ashouri, T. Bertram, Š. Tomšič, A. Magomedov, E. Kasparavicius, T. Kodalle, B. Lipovšek, V. Getautis, R. Schlatmann, C. A. Kaufmann, S. Albrecht, M. Topič, _ACS Energy Lett._ **2022** , _7_ , 1298. 

- [6] D. H. Kim, C. P. Muzzillo, J. Tong, A. F. Palmstrom, B. W. Larson, C. Choi, S. P. Harvey, S. Glynn, J. B. Whitaker, F. Zhang, Z. Li, H. Lu, M. F. A. M. van Hest, J. J. Berry, L. M. Mansfield, Y. Huang, Y. Yan, K. Zhu, _Joule_ **2019** , _3_ , 1734. 

- [7] M. Jošt, T. Bertram, D. Koushik, J. A. Marquez, M. A. Verheijen, M. D. Heinemann, E. Köhnen, A. Al-Ashouri, S. Braunger, F. Lang, B. Rech, T. Unold, M. Creatore, I. Lauermann, C. A. Kaufmann, R. Schlatmann, S. Albrecht, _ACS Energy Lett._ **2019** , _4_ , 583. 

- [8] A. Al-Ashouri, A. Magomedov, M. Roß, M. Jošt, M. Talaikis, G. Chistiakova, T. Bertram, J. A. Márquez, E. Köhnen, E. Kasparavičius, S. Levcenco, L. Gil-Escrig, C. J. Hages, R. Schlatmann, B. Rech, T. Malinauskas, T. Unold, C. A. Kaufmann, L. Korte, G. Niaura, V. Getautis, S. Albrecht, _Energy Environ. Sci._ **2019** , _12_ , 3356. 

- [9] S. Wu, J. Zhang, Z. Li, D. Liu, M. Qin, S. H. Cheung, X. Lu, D. Lei, S. K. So, Z. Zhu, A. K. Y. Jen, _Joule_ **2020** , _4_ , 1248. 

- [10] G. Yang, Z. Ren, K. Liu, M. Qin, W. Deng, H. Zhang, H. Wang, J. Liang, F. Ye, Q. Liang, H. Yin, Y. Chen, Y. Zhuang, S. Li, B. Gao, J. Wang, T. Shi, X. Wang, X. Lu, H. Wu, J. Hou, D. Lei, S. K. So, Y. Yang, G. Fang, G. Li, _Nat. Photonics_ **2021** , _15_ , 681. 

- [11] S. Wu, Z. Li, M. Q. Li, Y. Diao, F. Lin, T. Liu, J. Zhang, P. Tieu, W. Gao, F. Qi, X. Pan, Z. Xu, Z. Zhu, A. K. Y. Jen, _Nat. Nanotechnol._ **2020** , _15_ , 934. 

- [12] B. Li, W. Zhang, _Commun. Mater._ **2022** , _3_ , 65. 

- [13] A. Mei, Y. Sheng, Y. Ming, Y. Hu, Y. Rong, W. Zhang, S. Luo, G. Na, C. Tian, X. Hou, Y. Xiong, Z. Zhang, S. Liu, S. Uchida, T. W. Kim, Y. Yuan, L. Zhang, Y. Zhou, H. Han, _Joule_ **2020** , _4_ , 2646. 

- [14] Y. Kang, A. Wang, R. Li, Y. Song, X. Wang, H. Li, W. Xu, L. Zhang, Q. Dong, Y. Kang, A. Wang, R. Li, Y. Song, H. Li, W. Xu, Q. Dong, X. Wang, L. Zhang, _Adv. Mater._ **2022** , _34_ , 2203166. 

- [15] L. Meng, J. You, Y. Yang, _Nat. Commun._ **2018** , _9_ , 5265. 

- [16] Y. Rong, Y. Hu, A. Mei, H. Tan, M. I. Saidaminov, S. Il Seok, M. D. McGehee, E. H. Sargent, H. Han, _Science_ **2018** , _361_ , https:// doi.org/10.1126/science.aat8235. 

- [17] L. Mao, T. Yang, H. Zhang, J. Shi, Y. Hu, P. Zeng, F. Li, J. Gong, X. Fang, Y. Sun, X. Liu, J. Du, A. Han, L. Zhang, W. Liu, F. Meng, X. Cui, Z. Liu, M. Liu, L. Mao, H. Zhang, Y. Hu, P. Zeng, F. Li, J. Gong, X. Fang, Y. Sun, X. Liu, M. Liu, T. Yang, et al., _Adv. Mater._ **2022** , _34_ , 2206193. 

- [18] X. Yin, J. Han, Y. Zhou, Y. Gu, M. Tai, H. Nan, Y. Zhou, J. Li, H. Lin, _J. Mater. Chem. A_ **2019** , _7_ , 5666. 

- [19] C. C. Boyd, R. C. Shallcross, T. Moot, R. Kerner, L. Bertoluzzi, A. Onno, S. Kavadiya, C. Chosy, E. J. Wolf, J. Werner, J. A. Raiford, C. de Paula, A. F. Palmstrom, Z. J. Yu, J. J. Berry, S. F. Bent, Z. C. Holman, J. M. Luther, E. L. Ratcliff, N. R. Armstrong, M. D. McGehee, _Joule_ **2020** , _4_ , 1759. 

- [20] I. J. Park, G. Kang, M. A. Park, J. S. Kim, S. W. Seo, D. H. Kim, K. Zhu, T. Park, J. Y. Kim, _ChemSusChem_ **2017** , _10_ , 2660. 

- [21] M. Michalska, M. A. Surmiak, F. Maasoumi, D. C. Senevirathna, P. Chantler, H. Li, B. Li, T. Zhang, X. Lin, H. Deng, N. Chandrasekaran, T. A. N. Peiris, K. J. Rietwyk, A. S. R. Chesman, T. Alan, D. Vak, U. Bach, J. J. Jasieniak, _Sol. RRL_ **2021** , _5_ , 2100342. 

- [22] D. Di Girolamo, F. Di Giacomo, F. Matteocci, A. G. Marrani, D. Dini, A. Abate, D. Di Girolamo, _Chem. Sci._ **2020** , _11_ , 7746. 

- [23] T. Abzieher, S. Moghadamzadeh, F. Schackmar, H. Eggers, F. Sutterlüti, A. Farooq, D. Kojda, K. Habicht, R. Schmager, 

**www.advenergymat.de** 

   - A. Mertens, R. Azmi, L. Klohr, J. A. Schwenzer, M. Hetterich, U. Lemmer, B. S. Richards, M. Powalla, U. W. Paetzold, _Adv. Energy Mater._ **2019** , _9_ , 1802995. 

- [24] S. Thampy, W. Xu, J. W. P. Hsu, _J. Phys. Chem. Lett._ **2021** , _12_ , 8495. 

- [25] D. Di Girolamo, N. Phung, M. Jošt, A. Al-Ashouri, G. Chistiakova, J. Li, J. A. Márquez, T. Unold, L. Korte, S. Albrecht, A. Di Carlo, D. Dini, A. Abate, _Adv. Mater. Interfaces_ **2019** , _6_ , 1900789. 

- [26] Y. Hu, Z. Yang, X. Cui, P. Zeng, F. Li, X. Liu, G. Feng, M. Liu, _ACS Appl. Mater. Interfaces_ **2022** , _14_ , 13431. 

- [27] A. Farag, P. Fassl, H. Hu, T. Feeney, A. Quintilla, M. A. Ruiz-Preciado, W. Hempel, D. Bagrowski, P. Noack, B. Wattenberg, T. Dippell, U. W. Paetzold, A. Farag, P. Fassl, H. Hu, T. Feeney, M. A. Ruiz-Preciado, U. W. Paetzold, A. Quintilla, W. Hempel, D. Bagrowski, P. Noack, B. Wattenberg, T. Dippell, _Adv. Funct. Mater._ **2022** , https://doi.org/10.1002/adfm.202210758. 

- [28] G. Yang, Z. Ni, Z. J. Yu, B. W. Larson, Z. Yu, B. Chen, A. Alasfour, X. Xiao, J. M. Luther, Z. C. Holman, J. Huang, _Nat. Photonics_ **2022** , _16_ , 588. 

- [29] F. M. Rombach, S. A. Haque, T. J. Macdonald, _Energy Environ. Sci._ **2021** , _14_ , 5161. 

- [30] X. Xu, X. Ji, R. Chen, F. Ye, S. Liu, S. Zhang, W. Chen, Y. Wu, W.-H. Zhu, X. Xu, X. Ji, F. Ye, S. Liu, S. Zhang, Y. Wu, W.-H. Zhu, R. Chen, W. Chen, _Adv. Funct. Mater._ **2022** , _32_ , 2109968. 

- [31] K. Chen, W. Kong, N. Ali, W. Song, Z. Wang, A. Wang, Z. Yu, J. Tao, S. Yang, G. Fu, _Sol. RRL_ **2020** , _11_ , 2000365. 

- [32] E. Aydin, M. De Bastiani, S. De Wolf, _Adv. Mater._ **2019** , _31_ , 1900428. 

- [33] B. Li, Y. Xiang, K. D. G. I. Jayawardena, D. Luo, Z. Wang, X. Yang, J. F. Watts, S. Hinder, M. T. Sajjad, T. Webb, H. Luo, I. Marko, H. Li, S. A. J. Thomson, R. Zhu, G. Shao, S. J. Sweeney, S. R. P. Silva, W. Zhang, _Nano Energy_ **2020** , _78_ , 105249. 

- [34] J. You, F. Guo, S. Qiu, W. He, C. Wang, X. Liu, W. Xu, Y. Mai, _J. Energy Chem._ **2019** , _38_ , 192. 

- [35] A. Magomedov, A. Al-Ashouri, E. Kasparavičius, S. Strazdaite, G. Niaura, M. Jošt, T. Malinauskas, S. Albrecht, V. Getautis, _Adv. Energy Mater._ **2018** , _8_ , 1801892. 

- [36] E. Yalcin, M. Can, C. Rodriguez-Seco, E. Aktas, R. Pudi, W. Cambarau, S. Demic, E. Palomares, _Energy Environ. Sci._ **2019** , _12_ , 230. 

- [37] Z. Gu, L. Zuo, T. T. Larsen-Olsen, T. Ye, G. Wu, F. C. Krebs, H. Chen, _J. Mater. Chem. A_ **2015** , _3_ , 24254. 

- [38] L. Liu, A. Mei, T. Liu, P. Jiang, Y. Sheng, L. Zhang, H. Han, _J. Am. Chem. Soc._ **2015** , _137_ , 1790. 

- [39] F. Schreiber, _Prog. Surf. Sci._ **2000** , _65_ , 151. 

- [40] M. Halik, A. Hirsch, M. Halik, A. Hirsch, _Adv. Mater._ **2011** , _23_ , 2689. 

- [41] H. Hoegl, _J. Phys. Chem._ **1965** , _69_ , 755. 

- [42] M. S. Kang, S. Do Sung, I. T. Choi, H. Kim, M. Hong, J. Kim, W. I. Lee, H. K. Kim, _ACS Appl. Mater. Interfaces_ **2015** , _7_ , 22213. 

- [43] S. A. Paniagua, A. J. Giordano, O. L. Smith, S. Barlow, H. Li, N. R. Armstrong, J. E. Pemberton, J. L. Brédas, D. Ginger, S. R. Marder, _Chem. Rev._ **2016** , _116_ , 7117. 

- [44] A. Al-Ashouri, E. Köhnen, B. Li, A. Magomedov, H. Hempel, P. Caprioglio, J. A. Márquez, A. B. M. Vilches, E. Kasparavicius, J. A. Smith, N. Phung, D. Menzel, M. Grischek, L. Kegelmann, D. Skroblin, C. Gollwitzer, T. Malinauskas, M. Jošt, G. Matič, B. Rech, R. Schlatmann, M. Topič, L. Korte, A. Abate, B. Stannowski, D. Neher, M. Stolterfoht, T. Unold, V. Getautis, S. Albrecht, _Science_ **2020** , _370_ , 1300. 

- [45] Y. Hou, X. Du, S. Scheiner, D. P. McMeekin, Z. Wang, N. Li, M. S. Killian, H. Chen, M. Richter, I. Levchuk, N. Schrenker, E. Spiecker, T. Stubhan, N. A. Luechinger, A. Hirsch, P. Schmuki, H. P. Steinrück, R. H. Fink, M. Halik, H. J. Snaith, C. J. Brabec, _Science_ **2017** , _358_ , 1192. 

**2203982 (11 of 13)** 

_Adv. Energy Mater._ **2023** , _13_ , 2203982 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

- [46] M. Roß, S. Severin, M. B. Stutz, P. Wagner, H. Köbler, M. Favin-Lévêque, A. Al-Ashouri, P. Korb, P. Tockhorn, A. Abate, B. Stannowski, B. Rech, S. Albrecht, _Adv. Energy Mater._ **2021** , _11_ , 2101460. 

- [47] P. Tockhorn, J. Sutter, A. Cruz, P. Wagner, K. Jäger, D. Yoo, F. Lang, M. Grischek, B. Li, J. Li, O. Shargaieva, E. Unger, A. Al-Ashouri, E. Köhnen, M. Stolterfoht, D. Neher, R. Schlatmann, B. Rech, B. Stannowski, S. Albrecht, C. Becker, _Nat. Nanotechnol._ **2022** , _2022_ , 1214. 

- [48] J. Liu, M. De Bastiani, E. Aydin, G. T. Harrison, Y. Gao, R. R. Pradhan, M. K. Eswaran, M. Mandal, W. Yan, A. Seitkhan, M. Babics, A. S. Subbiah, E. Ugur, F. Xu, L. Xu, M. Wang, A. ur Rehman, A. Razzaq, J. Kang, R. Azmi, A. A. Said, F. H. Isikgor, T. G. Allen, D. Andrienko, U. Schwingenschlögl, F. Laquai, S. De Wolf, _Science_ **2022** , _377_ , 302. 

- [49] E. Aktas, N. Phung, H. Köbler, D. A. González, M. Méndez, I. Kafedjiska, S. H. TurrenCruz, R. Wenisch, I. Lauermann, A. Abate, E. Palomares, _Energy Environ. Sci._ **2021** , _14_ , 3976. 

- [50] J. Roger, L. K. Schorn, M. Heydarian, A. Farag, T. Feeney, D. Baumann, H. Hu, F. Laufer, W. Duan, K. Ding, A. Lambertz, P. Fassl, M. Worgull, U. W. Paetzold, _Adv. Energy Mater._ **2022** , _12_ , 2200961. 

- [51] E. J. Cassella, E. L. K. Spooner, T. Thornber, M. E. O'Kane, T. E. Catley, J. E. Bishop, J. A. Smith, O. S. Game, D. G. Lidzey, _Adv. Sci._ **2022** , _9_ , 2104848. 

- [52] B. Abdollahi Nejand, D. B. Ritzer, H. Hu, F. Schackmar, S. Moghadamzadeh, T. Feeney, R. Singh, F. Laufer, R. Schmager, R. Azmi, M. Kaiser, T. Abzieher, S. Gharibzadeh, E. Ahlswede, U. Lemmer, B. S. Richards, U. W. Paetzold, _Nat. Energy_ **2022** , _2022_ , 620. 

- [53] N. Phung, M. Verheijen, A. Todinova, K. Datta, M. Verhage, A. AlAshouri, H. Köbler, X. Li, A. Abate, S. Albrecht, M. Creatore, _ACS Appl. Mater. Interfaces_ **2022** , _14_ , 2166. 

- [54] M. Saliba, T. Matsui, J. Y. Seo, K. Domanski, J. P. Correa-Baena, M. K. Nazeeruddin, S. M. Zakeeruddin, W. Tress, A. Abate, A. Hagfeldt, M. Grätzel, _Energy Environ. Sci._ **2016** , _9_ , 1989. 

- [55] D. Menzel, A. Al-Ashouri, A. Tejada, I. Levine, J. A. Guerra, B. Rech, S. Albrecht, L. Korte, _Adv. Energy Mater._ **2022** , _12_ , 2201109. 

- [56] S. Gharibzadeh, P. Fassl, I. Hossain, P. N. Rohrbeck, M. Frericks, M. Schmidt, T. Duong, M. R. Khan, T. Abzieher, B. A. Nejand, F. Schackmar, O. Almora, T. Feeney, R. Singh, D. Fuchs, U. Lemmer, J. P. Hofmann, S. Weber, U. W. Paetzold, _Energy Environ. Sci._ **2021** , _14_ , 5875. 

- [57] K. Xu, A. Al-Ashouri, Z.-W. Peng, E. Köhnen, H. Hempel, F. Akhundova, J. A. Marquez, P. Tockhorn, O. Shargaieva, F. Ruske, J. Zhang, J. Dagar, B. Stannowski, T. Unold, D. Abou-Ras, E. Unger, L. Korte, S. Albrecht, _ACS Energy Lett._ **2022** , _29_ , 3600. 

- [58] P. Fassl, V. Lami, F. J. Berger, L. M. Falk, J. Zaumseil, B. S. Richards, I. A. Howard, Y. Vaynzof, U. W. Paetzold, _Matter_ **2021** , _4_ , 1391. 

- [59] I. Levine, A. Al-Ashouri, A. Musiienko, H. Hempel, A. Magomedov, A. Drevilkauskaite, V. Getautis, D. Menzel, K. Hinrichs, T. Unold, S. Albrecht, T. Dittrich, _Joule_ **2021** , _5_ , 2915. 

- [60] M. C. Biesinger, _Appl. Surf. Sci._ **2022** , _597_ , 153681. 

- [61] D. G. Larrude, M. E. H. M. Da Costa, F. H. Monteiro, A. L. Pinto, F. L. Freire, _J. Appl. Phys_ **2012** , _111_ , 064315. 

- [62] A. Furlan, G. K. Gueorguiev, Z. Czigány, H. Högberg, S. Braun, S. Stafström, L. Hultman, _Phys. Status. Solidi. Rapid. Res. Lett._ **2008** , _2_ , 191. 

- [63] L. G. Bulusheva, V. E. Arkhipov, K. M. Popov, V. I. Sysoev, A. A. Makarova, A. V. Okotrub, _Materials_ **2020** , _13_ , 1173. 

- [64] A. M. Puziy, O. I. Poddubnaya, R. P. Socha, J. Gurgul, M. Wisniewski, _Carbon_ **2008** , _46_ , 2113. 

- [65] H. Bin, K. Datta, J. Wang, T. P. A. Van Der Pol, J. Li, M. M. Wienk, R. A. J. Janssen, _ACS Appl. Mater. Interfaces_ **2022** , _14_ , 16497. 

- [66] D. Song, S. Narra, M. Y. Li, J. S. Lin, E. W. G. Diau, _ACS Energy Lett._ **2021** , _6_ , 4179. 

- [67] M. Taddei, J. A. Smith, B. M. Gallant, S. Zhou, R. J. E. Westbrook, Y. Shi, J. Wang, J. N. Drysdale, D. P. Mccarthy, S. Barlow, S. R. Marder, H. J. Snaith, D. S. Ginger, https://doi.org/10.48550/ arXiv.2209.15100. 

- [68] C. Bi, Q. Wang, Y. Shao, Y. Yuan, Z. Xiao, J. Huang, _Nat. Commun._ **2015** , _6_ , 7747. 

- [69] S. Kim, H. Van Quy, H. W. Choi, C. W. Bark, _Energies_ **2020** , _13_ , 1069. [70] M. Pylnev, A. M. Barbisan, T. C. Wei, _Appl. Surf. Sci._ **2021** , _541_ , 148559. 

- [71] D. K. Owens, R. C. Wendt, _J. Appl. Polym. Sci._ **1969** , _13_ , 1741. 

- [72] W. Qarony, M. I. Hossain, V. Jovanov, A. Salleo, D. Knipp, Y. H. Tsang, _ACS Appl. Mater. Interfaces_ **2020** , _12_ , 15080. 

- [73] F. E. Subhan, A. D. Khan, A. D. Khan, N. Ullah, M. Imran, M. Noman, _RSC Adv._ **2020** , _10_ , 26631. 

- [74] F. Gota, F. Gota, R. Schmager, R. Schmager, A. Farag, A. Farag, U. W. Paetzold, U. W. Paetzold, _Opt. Express_ **2022** , _30_ , 14172. 

- [75] M. De Bastiani, A. J. Mirabelli, Y. Hou, F. Gota, E. Aydin, T. G. Allen, J. Troughton, A. S. Subbiah, F. H. Isikgor, J. Liu, L. Xu, B. Chen, E. Van Kerschaver, D. Baran, B. Fraboni, M. F. Salvador, U. W. Paetzold, E. H. Sargent, S. De Wolf, _Nat. Energy_ **2021** , _6_ , 167. 

- [76] A. S. Subbiah, F. H. Isikgor, C. T. Howells, M. De Bastiani, J. Liu, E. Aydin, F. Furlan, T. G. Allen, F. Xu, S. Zhumagali, S. Hoogland, E. H. Sargent, I. McCulloch, S. De Wolf, _ACS Energy Lett._ **2020** , _5_ , 3034. 

- [77] F. H. Isikgor, F. Furlan, J. Liu, E. Ugur, M. K. Eswaran, A. S. Subbiah, E. Yengel, M. De Bastiani, G. T. Harrison, S. Zhumagali, C. T. Howells, E. Aydin, M. Wang, N. Gasparini, T. G. Allen, A. ur Rehman, E. Van Kerschaver, D. Baran, I. McCulloch, T. D. Anthopoulos, U. Schwingenschlögl, F. Laquai, S. De Wolf, _Joule_ **2021** , _5_ , 1566. 

- [78] F. Sahli, J. Werner, B. A. Kamino, M. Bräuninger, R. Monnard, B. Paviet-Salomon, L. Barraud, L. Ding, J. J. Diaz Leon, D. Sacchetto, G. Cattaneo, M. Despeisse, M. Boccard, S. Nicolay, Q. Jeangros, B. Niesen, C. Ballif, _Nat. Mater._ **2018** , _17_ , 820. 

- [79] M. Jošt, E. Köhnen, A. B. Morales-Vilches, B. Lipovšek, K. Jäger, B. Macco, A. Al-Ashouri, J. Krč, L. Korte, B. Rech, R. Schlatmann, M. Topič, B. Stannowski, S. Albrecht, _Energy Environ. Sci._ **2018** , _11_ , 3511. 

- [80] Y. Hou, E. Aydin, M. De Bastiani, C. Xiao, F. H. Isikgor, D. J. Xue, B. Chen, H. Chen, B. Bahrami, A. H. Chowdhury, A. Johnston, S. W. Baek, Z. Huang, M. Wei, Y. Dong, J. Troughton, R. Jalmood, A. J. Mirabelli, T. G. Allen, E. Van Kerschaver, M. I. Saidaminov, D. Baran, Q. Qiao, K. Zhu, S. De Wolf, E. H. Sargent, _Science_ **2020** , _367_ , 1135. 

- [81] M. B. Islam, M. Yanagida, Y. Shirai, Y. Nabetani, K. Miyano, _ACS Omega_ **2017** , _2_ , 2291. 

- [82] N. Pant, A. Kulkarni, M. Yanagida, Y. Shirai, T. Miyasaka, K. Miyano, _Adv. Mater. Interfaces_ **2020** , _7_ , 1901748. 

- [83] D. Di Girolamo, F. Matteocci, F. U. Kosasih, G. Chistiakova, W. Zuo, G. Divitini, L. Korte, C. Ducati, A. Di Carlo, D. Dini, A. Abate, _Adv. Energy Mater._ **2019** , _9_ , 1901642. 

- [84] S. Zhumagali, F. H. Isikgor, P. Maity, J. Yin, E. Ugur, M. De Bastiani, A. S. Subbiah, A. J. Mirabelli, R. Azmi, G. T. Harrison, J. Troughton, E. Aydin, J. Liu, T. Allen, A. ur Rehman, D. Baran, O. F. Mohammed, S. De Wolf, _Adv. Energy Mater._ **2021** , _11_ , 2101662. 

- [85] J. Zhang, J. Long, Z. Huang, J. Yang, X. Li, R. Dai, W. Sheng, L. Tan, Y. Chen, _Chem. Eng. J._ **2021** , _426_ , 131357. 

- [86] A. Farag, R. Schmager, P. Fassl, P. Noack, B. Wattenberg, T. Dippell, U. W. Paetzold, _ACS Appl. Energy Mater._ **2022** , _5_ , 6700. 

- [87] M. Ebert, H. Stascheit, I. Hädrich, U. Eitner, The _Impact of Angular Dependent Loss Measurement on PV Module Energy Yield_ 

**2203982 (12 of 13)** 

_Adv. Energy Mater._ **2023** , _13_ , 2203982 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

_Prediction 29th European PV solar energy conference and exhibition_ , Amsterdam, The Netherlands, https://www.ise.fraunhofer.de/content/dam/ise/de/documents/publications/conference-paper/29eupvsec-2014/Ebert_5CV210.pdf. 

- [88] A. R. M. Alghamdi, M. Yanagida, Y. Shirai, G. G. Andersson, K. Miyano, _ACS Omega_ **2022** , _7_ , 12147. 

- [89] L. H. Chou, Y. T. Yu, X. F. Wang, I. Osaka, C. G. Wu, C. L. Liu, _Energy Technol._ **2020** , _8_ , 2000216. 

- [90] I. A. Howard, T. Abzieher, I. M. Hossain, H. Eggers, F. Schackmar, S. Ternes, B. S. Richards, U. Lemmer, U. W. Paetzold, _Adv. Mater._ **2019** , _31_ , 1806702. 

- [91] M. Jung, S. G. Ji, G. Kim, S. Il Seok, _Chem. Soc. Rev._ **2019** , _48_ , 2011. [92] B. Chen, Z. J. Yu, S. Manzoor, X. Dai, Z. C. Holman, J. Huang, S. Wang, W. Weigand, Z. Yu, G. Yang, Z. Ni, _Joule_ **2020** , _4_ , 850. 

- [93] J. Li, J. Dagar, O. Shargaieva, M. A. Flatken, H. Köbler, M. Fenske, C. Schultz, B. Stegemann, J. Just, D. M. Többens, A. Abate, R. Munir, E. Unger, _Adv. Energy Mater._ **2021** , _11_ , 2003460. 

- [94] F. Huang, M. Li, P. Siffalovic, G. Cao, J. Tian, _Energy Environ. Sci._ **2019** , _12_ , 518. 

- [95] C. Liu, Y.-B. Cheng, Z. Ge, _Chem. Soc. Rev._ **2020** , _49_ , 1653. 

- [96] S. R. Bae, D. Y. Heo, S. Y. Kim, _Mater. Today Adv._ **2022** , _14_ , 100232. 

- [97] H. Li, J. Zhou, L. Tan, M. Li, C. Jiang, S. Wang, X. Zhao, Y. Liu, Y. Zhang, Y. Ye, W. Tress, C. Yi, _Sci. Adv._ **2022** , _8_ , 7422. 

- [98] R. Ji, Z. Zhang, C. Cho, Q. An, F. Paulus, M. Kroll, M. Löffler, F. Nehm, B. Rellinghaus, K. Leo, Y. Vaynzof, _J. Mater. Chem. C_ **2020** , _8_ , 7725. 

- [99] L. Gil-Escrig, C. Dreessen, I. C. Kaya, B. S. Kim, F. Palazon, M. Sessolo, H. J. Bolink, _ACS Energy Lett._ **2020** , _5_ , 3053. 

- [100] D. B. Ritzer, T. Abzieher, A. Basibüyük, T. Feeney, F. Laufer, S. Ternes, B. S. Richards, S. Bergfeld, U. W. Paetzold, _Prog. Photovolt.: Res. Appl._ **2022** , _30_ , 360. 

- [101] L. Gil-Escrig, M. Roß, J. Sutter, A. Al-Ashouri, C. Becker, S. Albrecht, _Sol. RRL_ **2021** , _5_ , 2000553. 

- [102] T. Abzieher, T. Feeney, F. Schackmar, Y. J. Donie, I. M. Hossain, J. A. Schwenzer, T. Hellmann, T. Mayer, M. Powalla, U. W. Paetzold, _Adv. Funct. Mater._ **2021** , 2104482. 

- [103] M. Roß, L. Gil-Escrig, A. Al-Ashouri, P. Tockhorn, M. Jošt, B. Rech, S. Albrecht, _ACS Appl. Mater. Interfaces_ **2020** , _12_ , 39261. 

- [104] D. Y. Kwok, A. W. Neumann, _Adv. Colloid Interface Sci._ **1999** , _81_ , 167. 

- [105] H. Hu, S. Moghadamzadeh, R. Azmi, Y. Li, M. Kaiser, J. C. Fischer, Q. Jin, J. Maibach, I. M. Hossain, U. W. Paetzold, B. A. Nejand, _Adv. Funct. Mater._ **2022** , _32_ , 2107650. 

**2203982 (13 of 13)** 

_Adv. Energy Mater._ **2023** , _13_ , 2203982 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

