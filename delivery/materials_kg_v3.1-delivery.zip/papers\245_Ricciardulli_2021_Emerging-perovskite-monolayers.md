# Emerging perovskite monolayers

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Nature Materials |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 238 |
| 作者 | A. G. Ricciardulli, Sheng Yang, J. Smet, Michael Saliba |
| DOI | 10.1038/s41563-021-01029-9 |
| 源文件 | 045_Ricciardulli_2021_Emerging-perovskite-monolayers.pdf |

---
Review ARticle **https://doi.org/10.1038/s41563-021-01029-9** 





# **Emerging perovskite monolayers** 

**Antonio Gaetano Ricciardulli**<sup>**1,5,6**</sup> **, Sheng Yang**<sup>**2,6**✉</sup> **, Jurgen H. Smet**<sup>**2**✉</sup> **and Michael Saliba**<sup>**1,3,4**✉</sup> 

**The library of two-dimensional (2D) materials has been enriched over recent years with novel crystal architectures endowed with diverse exciting functionalities. Bulk perovskites, including metal-halide and oxide systems, provide access to a myriad of properties through molecular engineering. Their tunable electronic structure offers remarkable features from long carrier-diffusion lengths and high absorption coefficients in metal-halide perovskites to high-temperature superconductivity, magnetoresistance and ferroelectricity in oxide perovskites. Emboldened by the 2D materials research, perovskites down to the monolayer limit have recently emerged. Like other 2D species, perovskites with reduced dimensionality are expected to exhibit new physics and to herald next-generation multifunctional devices. In this Review, we critically assess the preliminary studies on the synthetic routes and inherent properties of monolayer perovskite materials. We also discuss how to exploit them for widespread applications and provide an outlook on the challenges and opportunities that lie ahead for this enticing class of 2D materials.** 

wo-dimensional (2D) materials hold great promise for next-generation technologies in the fields of electronics, Toptoelectronics, spintronics and beyond. The tremendous impact of atomically thin layers has been bolstered by the surge of successfully isolated and unique 2D crystals that span all the way from wide-bandgap insulators to superconductors. As a matter of fact, they probably offer access to all known ground states of condensed matter. Their diverse features, often very dissimilar from their bulk counterparts, provide a fertile playground for disclosing novel paradigms in physics and towards innovative applications<sup>1,2</sup> . As time progresses, more and more monolayer crystals are successfully isolated or fabricated, either from their parent bulk crystal or entirely through ab initio synthesis. Among numerous functional materials, perovskites represent a unique class of ionic materials comprising several types of oxide and halide structures. Oxide perovskites display diverse physical and chemical properties, which are widely used in ferroelectric, dielectric, piezoelectric, magnetic and energy conversion/storage devices<sup>3</sup> . In contrast, halide perovskites standout as powerful semiconductors for optoelectronic applications, due to their striking electrical and optical properties<sup>4,5</sup> , such as high carrier mobilities<sup>6,7</sup> , long carrier-diffusion lengths<sup>8</sup> , high absorption coefficients<sup>9</sup> and tunable optical bandgaps<sup>10</sup> . So far, mainstream research has focused on their integration into photovoltaics, where three-dimensional (3D) frameworks in the form of bulk nanocrystals or polycrystalline thin films are popular choices due to improved charge extraction properties. 

Recently, layered perovskites have come under the spotlight by virtue of their enhanced stability and structural tunability<sup>11,12</sup> . They consist of single or multiple inorganic slabs of corner-sharing metal-oxide or metal-halide octahedra interleaved with cations, which are monovalent and divalent for Ruddlesden–Popper (RP) and Dion–Jacobson (DJ) phases, respectively. In the case of hybrid halide perovskites, the insulating organic moieties surrounding semiconducting inorganic layers are responsible for a strong quantum and dielectric confinement, so that superlattices are formed with the inorganic layers in between acting as quantum wells. This results in stable excitons with large binding 

energies up to hundreds of millielectronvolts. The unit cell size can be varied through molecular engineering of the organic chains. This affects the overall physics and key electronic properties such as the bandgap and exciton binding energy. In particular, because the organic spacers between two adjacent unit cells of RP-phase halide perovskites are often connected by weak interaction such as van der Waals forces, individual perovskite layers can be isolated from their bulk crystals in the way that graphene has been. In the past, a number of comprehensive reviews on thinly layered halide perovskites have been reported<sup>13–15</sup> . By scaling down the physical thickness to the monolayer limit, the intrinsic properties become accessible and it is possible to gain a deeper understanding of the structure–property relationship and how this changes as the number of unit cells is increased. 

Unlike traditional 2D inorganic materials, monolayer perovskites are composed of a soft lattice and a dynamically disordered framework<sup>16</sup> . This makes them particularly susceptible to external stimuli, such as interface strain, temperature, pressure and electric fields. They are open to chemical functionalization, which grants access to a plethora of new 2D materials with tailorable features, going beyond the structural diversity of bulk analogues. Importantly, the broken inversion symmetry at the interfaces of ferroelectric species can enhance the Rashba splitting<sup>17</sup> , with which the charge carrier lifetime and the magnetic and electronic structure can be manipulated<sup>18</sup> . Currently, ultrathin sheets of halide perovskites have been prepared by either mechanical cleavage from the stacked RP-phase crystals<sup>19</sup> or by bottom-up synthetic approaches from molecular building blocks, such as chemical vapour deposition and epitaxial growth<sup>20,21</sup> . The latter routes are also applicable for growing single layers of oxide perovskites<sup>22</sup> , the latest member in the monolayer family. For a long time, oxide perovskites were thought to have a critical minimum thickness down to five unit cells, below which the lattice of the film would collapse<sup>23</sup> . Recently, an oxide perovskite monolayer was however successfully exfoliated by ion-exchange methods from DJ-phase bulk materials<sup>24</sup> . The inorganic slab was composed of three layers. It is noteworthy that 3D oxide perovskites cover insulators to semiconductors as well as metals and superconductors. 

> 1Technical University of Darmstadt, Darmstadt, Germany. 2Max Planck Institute for Solid State Research, Stuttgart, Germany. 3Institute for Photovoltaics, University of Stuttgart, Stuttgart, Germany.<sup>4</sup> Helmholtz Young Investigator Group FRONTRUNNER, Forschungszentrum Jülich, Jülich, Germany.<sup>5</sup> Present address: Université de Strasbourg, CNRS, ISIS UMR 7006, Strasbourg, France.<sup>6</sup> These authors contributed equally: Antonio Gaetano Ricciardulli, Sheng Yang.<sup>✉</sup> e-mail: s.yang@fkf.mpg.de; j.smet@fkf.mpg.de; michael.saliba@ipv.uni-stuttgart.de 

**NAtuRE MAtERiAlS** | VOL 20 | OCTObER 2021 | 1325–1336 | www.nature.com/naturematerials 

**1325** 

<mark>Review ARticle</mark> 

**NaTuRE MaTERIaLs** 

##### **Box 1 | A brief history of perovskite materials** 

The progenitor of perovskite materials, CaTiO3, was discovered in the Ural Mountains by Gustav Rose in 1839. It was named in honour of the mineralogist Lev Aleksevic von Perovski<sup>91</sup> . The general chemical formula of perovskites is ABX3, where A and B are both cations and A is generally larger than B, and X is usually an oxide or a halide anion. The replacement of ionic species led to a myriad of perovskites with distinct features and properties. These include ferroelectricity, superconductivity, strong optical absorption, low exciton-binding energy and so on. 

Since the 1940s, oxide perovskites have found their way in the field of catalysis, sensing, electrical and optical devices<sup>3,92</sup> . For example, BaTiO3 is a classic ferroelectric material with high dielectric constant. Since the 1950s, it has been widely used in capacitors and condensers. The discovery of superconductivity in the La–Ba–Cu–O cuprate system at ∼30 K was an important milestone in 1986. It triggered the search for superconducting materials with a higher critical temperature ( _T_ c) within the oxide 

perovskite family<sup>26</sup> . Among the cuprates, the substitution of La with Y caused a big leap forward pushing _T_ c up to 93 K only one year later<sup>93</sup> . In 1988, compositional engineering enabled even highertemperature superconductors without any need for rare-earth elements. For example, with BiSrCaCu2O _x_ , it is possible to achieve a _T_ c of 105 K (ref.<sup>94</sup> ). The more recent discovery of superconductivity in a 2D electron system that spontaneously emerges at the LaAlO3/SrTiO3 (001) and SrTiO3/KTaO3(111) polarized interfaces brought this old topic back into the spotlight<sup>69,95</sup> . The history of halide perovskites dates back to 1893, when CsPbX3 was first discovered<sup>16</sup> . From the 1920s to 1950s, many others were prepared, such as CsSnX3 and CsGeX3. The discovery of intrinsic photoconductivity<sup>96</sup> in lead-based halide perovskites (CsPbCl3 and CsPbBr3) attracted considerable attention and marked the start for novel thin-film electronic devices. Early structural studies on layered perovskites date from the 1960s<sup>25</sup> . Two decades later, chemical intercalation enabled a large interlayer expansion of 



<!-- Start of picture text -->
c La2– x Ba x CuO4 e (C4H9NH3)2(CH3NH3) n –1Sn n I3 n +1 g (C4H9NH3)2(CH3NH3) n –1Pb n I3 n +1 i (C4H9NH3)2PbI4–(C4H9NH3)2PbBr4<br>Pb ( n  = 1–4) Pb<br>I I<br>O l n  = 1–5 Br<br>Sn<br>Cu n  = 2 2.1 nm<br>La/Ba C4H9NH3 1L<br>CH3NH3 4 µm<br>3 µm 3 µm<br>Discovery of high- T c Layered hybrid perovskites Monolayer halide perovskites  Monolayer halide perovskites<br>superconductivity in the with variable unit thickness with precise thickness control with lateral heterostructures<br>Ba–La–Cu–O system<br>1986 1994 2018 2020<br>1839 1964 2015 2019<br>3D perovskite Layered inorganic Early-stage intercalation of Atomically thin Monolayer oxide perovskite<br>discovery  perovskite a perovskite crystal halide perovskite<br>a b d f h Two unit cells thick<br>l<br>Pb<br>O Cl Organic<br>Ti Cu moiety  10 µm 1 µm 2 µm<br>Ca NH4 Guest molecules Expandedspacing BrPb Two unit cells thick2 nm Si OTi<br>Organic Sr<br>moiety<br>CaTiO3 (NH4)2CuCI4 Intercalated (C10H21NH3)2PbI4 n  = 1–4<br>n  = 1<br>(C4H9NH3)2PbBr4 SrTiO3 or BiFeO3<br><!-- End of picture text -->

**timeline of key milestones towards dimensionality reduction in the field of perovskites from the discovery of 3D perovskites to the successful isolation of perovskite monolayers. a** , The first perovskite material, CaTiO3, was discovered in 1839 by Gustav Rose. **b** , Determination of the (NH4)2CuCl4 crystal structure. This material contains discrete, planar CuCl42− layers25. **c** , The discovery of superconductivity at ∼30 K in La2− _x_ ba _x_ CuO4 unleashed a flood of work in the search for higher- _T_ c superconductivity in perovskite structures<sup>26</sup> . **d** , The successful intercalation of layered halide perovskites crystals paved the way for the exfoliation of atomically thin sheets<sup>27</sup> . **e** , Discovery of a series of layered tin-based halide perovskites with controllable layer thickness. A trend from semiconducting to metallic-like behaviour is observed with increasing number _n_ of the perovskite layer<sup>28</sup> . **f** , Solution-based growth of a perovskite with a thickness of a single unit cell. The structural relaxation in monolayers causes a change in the bandgap compared with the gap of the bulk counterpart<sup>35</sup> . The insets show an optical image of (bA)2Pbbr4 sheets (left) and an atomic force microscopy image of several single layer square-shaped sheets (right). **g** , Large-size halide perovskite monolayers with different well thicknesses, such as a different _n_ , were successfully fabricated by mechanical cleavage from bulk crystals. The exfoliated sheets offer tunable optoelectronic features due to their mouldable structure<sup>19</sup> . The inset shows an atomic force microscopy image corresponding to single layer (1L)-thick (bA)2(MA)Pb2I7. **h** , Epitaxial-growth of free-standing SrTiO3 and biFeO3 films down to the monolayer. The ultrathin and highly crystalline films are transferrable onto a variety of different substrates (such as silicon, holey carbon)<sup>22</sup> . The insets show cross-sectional (bottom) and low-magnification plane-view (top) annular dark-field images at high angle of a two-unit-cell freestanding SrTiO3 film. **i** , The fabrication of lateral heterostructures containing monolayer halide perovskite semiconductors. Diverse conjugated organic ligands, metals and halides are mixed to tune the optoelectronic properties of these more complex 2D architectures<sup>37</sup> . The insets show the optical (left) and photoluminescence (right) images of a (bA)2PbI4–(bA)2Pbbr4 lateral heterostructure. Credit: panels adapted with permission from: **f** , ref.<sup>35</sup> , AAAS; **g** , ref.<sup>19</sup> , Springer Nature Ltd; **h** , ref.<sup>22</sup> , Springer Nature Ltd; **i** , ref.<sup>37</sup> , Springer Nature Ltd. 

**NAtuRE MAtERiAlS** | VOL 20 | OCTObER 2021 | 1325–1336 | www.nature.com/naturematerials 

**1326** 

<mark>Review ARticle</mark> 

**NaTuRE MaTERIaLs** 

##### **Box 1 | A brief history of perovskite materials (continued)** 

a hybrid perovskite<sup>27</sup> . However, the extraction of perovskite monolayers was not achieved until recently<sup>19,22,35,37</sup> , owing to both technical difficulties and the disproportionate attention paid to halide perovskites for photovoltaics. 

In 1986, Maruyama and co-workers reported the first layered halide perovskite (CH3(CH2)8NH3)2PbI4 (ref.<sup>27</sup> ) and marked the start of the synthesis of state-of-the-art 2D hybrid perovskites. Mitzi and co-workers carried out systematic synthesis studies of layered halide perovskite semiconductors with designable organic moieties and tunable electrical properties during the 1990s<sup>28</sup> . The work of Miyasaka and colleagues in 2009 represents another important step forward by exploiting the photovoltaic function of bulk organic–inorganic hybrid perovskite (CH3NH3PbI3)<sup>97</sup> . It sparked extensive research of halide perovskites as light-absorbing layers in photovoltaic devices. A decade later, the initial efficiency 

of 3.8% of perovskite solar cells reached an impressive 25.5% in a single junction and 29.5% as perovskite/silicon tandem devices<sup>98</sup> . Layered halide perovskites also offer other interesting photonic, electronic and spin related properties. However, these mostly stem from spin-coated polycrystalline thin films and thick single crystals. 

The fabrication of and control over perovskite monolayers is an important recent research direction in the field of perovskite materials. Recently, pioneering studies on ultrathin perovskite halides and oxides have revealed their potential<sup>19,22,35,37</sup> , being more prone to property changes upon external stimuli and molecular engineering than their bulk counterparts. Monolayers can be incorporated into various electronic devices in which the inherent characteristics of the perovskite can be fully exploited, leading to the discovery of a rich spectrum of novel properties. 



<!-- Start of picture text -->
Monolayer<br>n  = 3<br>3D perovskite ABX3<br>n  = 1 n  = 2 n  = 3<br>= BX6 = A = A′<br>RP phase A′2A n –1B n X3 n +1 DJ phase A′A n –1B n X3 n +1<br>= Van der Waals gap<br><!-- End of picture text -->

**Fig. 1 | Perovskite types.** Schematic of the general structure of perovskites with non-layered AbX3, layered RP phase A′2A _n_ −1b _n_ X3 _n_ +1 or DJ phase A′A _n_ −1b _n_ X3 _n_ +1. Here, the case of _n_ = 1, 2 and 3 is shown but _n_ can go up to 5 (ref.<sup>16</sup> ). 

The research on exotic 2D correlated electronic phases in these oxides is, however, still in its infancy. 

In this Review, we provide an up-to-date overview of pioneering advances in this exciting arena of perovskite-type 2D materials with a focus on their synthesis, characterization and fundamental physical properties. In particular, we highlight the opportunities to manipulate the properties of perovskite monolayers and offer our insights into the future directions and challenges towards new materials, new device concepts and innovative applications in this emerging field. Due to the widely tailorable chemical and physical properties, the developments on monolayer perovskites are bound to stimulate fruitful interactions between the currently distinct scientific communities working on perovskites and 2D materials. The tremendous potential that the merger of these two material classes holds may not be fully appreciated yet. 

#### **Structural versatility** 

The perovskite structure originates from calcium titanium oxide (CaTiO3), a mineral discovered in 1839 (Box 1). This crystal structure exhibits exceptional flexibility through ionic substitutions, structural defects and superstructures, resulting in hundreds of halide and oxide perovskites with layered or non-layered geometries (Fig. 1)<sup>25–28</sup> . The layered perovskites can be further divided into the RP phases, the DJ phases and the Aurivillius phases (exclusively for oxide perovskites), which adopt the general formulas of A′2A _n−_ 1B _n_ X3 _n_ +1, A′A _n–_ 1B _n_ X3 _n_ +1 and (Bi2O2)(A _n–_ 1B _n_ O3 _n_ +1), respectively<sup>16</sup> . Compared with RP phases, DJ-phase layered perovskites possess strong interlayer interactions because they have only one divalent interlayer cation A′ per formula unit<sup>29</sup> . When X is an oxide 

anion, the classical examples of oxide perovskites consist of alkaline, alkaline-earth or rare-earth cations at the A sites, and transition or _p_ -block metals at the B sites. When X is a halide anion (such as Cl<sup>−</sup> , Br<sup>−</sup> or I<sup>−</sup> ), A′ is a bulky aromatic or aliphatic alkylammonium spacer, such as butylammonium (BA) and 2-phenylethylammounium (PEA), and B is a divalent metal cation from group XIV (for example, Pb²<sup>+</sup> , Sn²<sup>+</sup> , Ge²<sup>+</sup> and so on) in RP-phase hybrid halide perovskites<sup>30</sup> . The hybrid perovskite superlattices contain multiple units or quantum wells. The organic moieties act as insulator or barrier to confine charge carriers in each inorganic layer. The introduction of monovalent cations A, such as Cs<sup>+</sup> , methylammonium (MA) or formamidinium (FA), modulates the thickness of the quantum well and _n_ ( _n_ = 1, 2, 3…) refers to the number of [MX6]<sup>4−</sup> octahedral layers. Note that, when _n_ is greater than 5, hybrid perovskite layers usually undergo a spontaneous degradation towards more thermodynamically stable mixtures including thinner perovskite layers and 3D perovskites<sup>16</sup> . For _n_ → ∞, the layered perovskite evolves into a rigid 3D network with formula ABX3, where the aristotype, undistorted structure can be defined in a cubic unit cell with B atoms at the centre of the cube, A cations at the corners and X anions at the middle of the faces. 

#### **Synthesis of perovskite monolayers** 

Inspired by the research on atomically thin 2D crystals, such as graphene, transition metal dichalcogenides (TMDs) and black phosphorus<sup>2</sup> , mechanical exfoliation has been deployed for van der Waals stacked perovskite bulk crystals to achieve perovskite monolayers. Also the direct growth of monolayers in liquids or on substrates has been pursued to control precisely the thickness _n_ and the 

**NAtuRE MAtERiAlS** | VOL 20 | OCTObER 2021 | 1325–1336 | www.nature.com/naturematerials 

**1327** 

<mark>Review ARticle</mark> 

**NaTuRE MaTERIaLs** 



<!-- Start of picture text -->
a Top-down exfoliation b Bottom-up synthesis<br>Liquid-phase growth<br>Mechanical cleavage<br>RP-phase Perovskite<br>perovskites monolayers<br>Ion-exchange exfoliation<br>Epitaxial growth on substrates<br>DJ-phase<br>perovskites<br><!-- End of picture text -->

**Fig. 2 | Perovskite types and perovskite monolayer synthesis methods. a** , Top-down strategies for the delamination of bulk layered perovskite crystals through mechanical cleavage (top) and ion-exchange exfoliation of bulk layered perovskite crystals (bottom). **b** , bottom-up synthesis of perovskite monolayers using liquid-phase growth (top) or epitaxial growth (bottom). 

crystal structure. For example, molecular beam epitaxy (MBE) and chemical vapour deposition are employed to grow highly crystalline single sheets of non-layered perovskites. The chosen synthesis method has an impact on the surface morphology, which in turn affects the overall behaviour of the perovskite monolayers. Device fabrication through mechanical exfoliation and transfer are the most successful techniques to obtain high-quality monolayer nanocrystals from either native layered structures or from starting material grown on top of a substrate. Properties inherent to the 2D materials, such as the quantum Hall effect and superconductivity, have been observed on exfoliated flakes, but were either not observable or suppressed in samples prepared by other approaches<sup>31</sup> . Both mechanical exfoliation and MBE usually enable 2D material growth with a clean surface and well-defined morphology, whereas the chemical method based on bottom-up growth in solution often causes surface contamination of the isolated sheets. Therefore, compared with solution-prepared perovskite monolayers, the mechanically exfoliated sheets and those obtained by MBE are more suitable for device assembly and the exploration of new properties. 

**Top-down exfoliation.** Pioneering attempts to isolate single- and few-layer hybrid halide perovskites from bulk material resorted to mechanical cleavage (Fig. 2a)<sup>32,33</sup> . Compared with rigid layered inorganic materials, the combination of an elastic crystal lattice and weak interlayer interactions makes layered halide perovskites (with mainly _n_ = 1) easier to delaminate into thin sheets with large sizes, high crystallinity and surface cleanness. These parameters are critical for fundamental studies and fabrication of high-performance electrical and optical devices based on single flakes. However, the relatively weak in-plane ionic bonds usually cause structural cracks and yield uneven flakes with reduced lateral size as well as thickness fluctuations. Recently, micrometre-scale uniform monolayers with a controlled number of inorganic layers _n_ ( _n_ = 1–4) have been exfoliated from large crystals of an RP-phase halide perovskite<sup>19</sup> . Mechanical cleavage is not suited for DJ-phase halide perovskites, because the organic spacers (for example, 3-(aminomethyl)piperidinium) between the quantum wells are linked with ionic bonds, which are much stronger than van der Waals forces<sup>12</sup> . However, the DJ-phase oxide perovskites can be exfoliated into monolayers through an ion-exchange approach. The replacement of larger interlayer cations (such as Cs<sup>+</sup> and K<sup>+</sup> ) with smaller cations, such as protons, breaks the strong interlayer interaction and creates a new 

layered solid, which is crucial for the subsequent exfoliation<sup>24,34</sup> . This exfoliation procedure is mainly conducted in dispersion. It enables excellent solution processability of the exfoliated sheets. Despite the disturbed surfaces from residual chemicals and large distribution of lateral sizes (mainly below 5 µm) and thickness (down to few nanometres), the as-prepared thin films are useful for large-area optoelectronic devices. 

**Bottom-up synthesis.** Wet-chemical approaches offer an alternative route towards the production of widely tunable and well-defined monolayers (Fig. 2b). Direct growth of atomically thin sheets in solution has been demonstrated in a ternary co-solvent system composed of acetonitrile, chlorobenzene and _N_ , _N_ -dimethylformamide<sup>35</sup> . It yields square-shaped (BA)2PbBr4 flakes with a random thickness (from monolayer to few layer) and lateral dimensions up to 8 μm. The selection of different solvents can alter the balance between dissolution and crystallization of the specific halide perovskite. One of the most fascinating merits of solution growth methods is the freedom of spectral tunability by molecular design. It allows the incorporation of large conjugated organic moieties into the crystal lattice. For example, large tetra-thiophene-based monoammonium cations trigger the formation of halide perovskite sheets down to single-unit-cell thickness<sup>36</sup> . The introduction of steric groups into the organic ligands aids in restricting sheet growth to the lateral dimension and prevents the self-aggregation of 2D sheets into 3D crystals. This technique has been applied to synthesize complex monolayer lateral heterostructures with sharp interfaces and well-defined edges through a solution-phase sequential growth mechanism<sup>37</sup> . In a colloidal synthesis process, the addition of organic spacers with long alkylammonium chains enables ultrathin lead- and tin-based hybrid perovskite nanosheets ( _n_ = 1, 2) with excellent thickness homogeneity<sup>38</sup> . However, the thickness control fails for the growth of sheets with higher _n_ ( _n_ = 3, 4, 5…) and sheets of mixed thickness are obtained instead. 

In addition, solution-based synthesis is available for non-layered, molecularly thin sheets with a rigid ABX3 network, such as CsPbX3 (X = Cl<sup>−</sup> , Br<sup>−</sup> , I<sup>−</sup> )<sup>39,40</sup> , in which the cations at the A site can be further replaced by organic molecules. For example, ultrathin methylammonium lead halides (MAPbX3) sheets with thickness down to 1.3 nm can be prepared through precise control of the solvent evaporation rate<sup>41</sup> . So far, the major drawbacks of solution-based growth methods are the large distribution of thicknesses and lateral 

**NAtuRE MAtERiAlS** | VOL 20 | OCTObER 2021 | 1325–1336 | www.nature.com/naturematerials 

**1328** 

<mark>Review ARticle</mark> 

**NaTuRE MaTERIaLs** 

**Table 1 | Physical properties of the perovskite monolayers** 

||**inorganic halide perovskites**|**Hybrid organic–inorganic halide perovskites**|**Oxide perovskites**|
|---|---|---|---|
|Stoichiometric formula|AbX3,A2bX4,AbX4|A′2A_n_−1b_n_X3_n_+1,A′A_n_−1b_n_X3_n_+1|AbO3,A′A_n_−1b_n_O3_n_+1,A′2A_n_−1b_n_O3_n_+1|
|Examples of the host<br>elements|A=Cs<sup>+</sup>, Rb<sup>+</sup><br>b=Pb<sup>2+</sup>, Sn<sup>2+</sup>and others<br>X=Cl<sup>−</sup>, br<sup>−</sup>, I<sup>−</sup>|A′ =bulky organic cations, such as bA<sup>+</sup>, PEA<sup>+</sup><br>A=MA<sup>+</sup>, FA<sup>+</sup>, Cs<sup>+</sup><br>b=Pb<sup>2+</sup>, Sn<sup>2+</sup>and others<br>X=Cl<sup>−</sup>,br<sup>−</sup>,I<sup>−</sup>|A′ =K, Ca and others<br>A=Sr, La, K, bi, ba and others<br>b=Ti, Al, Ta, Fe, Nb and others|
|Typical crystal structure|Orthorhombic or tetragonal|Orthorhombic or tetragonal|Orthorhombic or monoclinic|
|Typical thickness (nm)|1.7 (CsPbbr3on substrate)<sup>45</sup>|1.4–3.3 ((bA)2(MA)_n_−1Pb_n_I3_n_+1,_n_ =1–4, on<br>substrates)|0.3–0.5 (freestanding SrTiO3and<br>biFeO3)<sup>22</sup>; 1.5–1.8 (Ca2Nb3O10and<br>Sr2Nb3O10on substrates)<sup>24,34</sup>|
|Typical ranges of bandgaps<br>(eV)|1.3–2.8|1.5–3.5|2.5–3.9|
|Exciton bindingenergy(meV)|<350|<500|–|
|Device mobility (cm<sup>2</sup>V<sup>−1</sup>s<sup>−1</sup>)|77.9 (CsPbbr3thin film)<sup>46</sup>|1.2–40 (thin films and single crystals)|>10,000 (SrTiO3interface at<br>_T_ =2 K)<sup>47</sup>|
|Electronic conductivity|Low/moderate|Low/moderate|Low|
|Ambient stability|High/moderate|Low/moderate|High|
|Potential applications|Photovoltaics,<br>photodetectors, field-effect<br>transistors|Solar cells, photodetectors, spintronics,<br>field-effect transistors|Spintronics, catalysts, photodetectors|



sizes of the 2D sheets, which might be a limiting factor for device assembly. In addition, surface contamination and structural defects such as grain boundaries, phase impurities and a considerable dislocation density affect the intrinsic properties of solution-processed perovskite monolayers. 

MBE is an alternative strategy to grow uniform thin films on compatible substrates with controlled thickness and structural precision at the atomic level. This technique is particularly suited for the preparation of ultrathin sheets of non-layered perovskites, in which, strong bonds between the layers usually prevent the isolation of individual sheets. In particular, the combination of epitaxial growth and selective etching enables the fabrication of freestanding single-crystalline oxide perovskite membranes, including SrTiO3 and La0.7Sr0.3MnO3, with lateral dimensions on the millimetre scale and thicknesses of a few unit cells<sup>42</sup> . A key process step consists of the deposition of a water-soluble sacrificial Sr3Al2O6 film before the growth of the target oxide perovskite. Ultrathin sheets can then be released in water and transferred onto any desired substrate or 2D material for multifunctional electronic devices. By carefully controlling the sacrificial buffer layer, further reduction of the perovskite thickness down to the extreme monolayer limit (one unit cell) is achievable<sup>22</sup> . The optimized conditions are applicable for the growth of single-crystal large-sized SrTiO3 and BiFeO3 membranes with variable thickness from one to four unit cells. MBE can not only be deployed for the growth of oxide perovskites but also be used to grow inorganic halide perovskites<sup>43</sup> . However, this method usually requires high temperatures and flux energies that are incompatible with the organic components of hybrid perovskites. Although organic molecular beam deposition has been developed for the growth of organic semiconducting layers<sup>44</sup> , the different growth mechanism and kinetics for organic layers and inorganic units, and the large lattice mismatch during their sequential growth, strongly hamper the synthesis of hybrid perovskite monolayers. 

#### **tunable electronic and optical properties** 

The flexibility in modifying the structure and composition endows perovskite materials with tunable electronic and optical properties (Table 1)<sup>45–47</sup> . The bandgap is one of the most significant parameters for semiconductors. Its size has implications for the types of 

possible application. For example, the narrow-bandgap perovskite semiconductors are widely used for applications related to photon absorption or emission<sup>48</sup> . The recently reported hybrid halide perovskites have relatively small bandgaps between 1.1 eV and 1.8 eV, whereas inorganic halide and oxide analogues usually exhibit larger intrinsic bandgaps exceeding 2 eV (ref.<sup>49</sup> ), which are interesting for light-emitting diodes and lasers. Some oxide species such as Sr2Nb3O10 have even wider bandgaps (for example, 3.9 eV) corresponding to ultraviolet photon energies<sup>24</sup> . However, not all bandgaps are available through direct synthesis and band structure engineering is critical for achieving desired bandgaps and physical characteristics. So far, many techniques, including alloying, heating, anion exchange, electronic doping, and applying external stimuli, are used to modulate the bond length and bond angle of perovskite lattices, thereby manipulating the band structure<sup>50,51</sup> . 

The thickness reduction when moving from bulk to monolayers broadens the bandgap due to quantum confinement. Especially in halide perovskite monolayers, the optical bandgap further increases as the quantum well thickness decreases (Fig. 3a)<sup>52</sup> . For example, the optical bandgap of exfoliated (BA)2(MA) _n_ −1Pb _n_ X3 _n_ +1 evolves from 1.85 eV to 2.42 eV by lowering _n_ from 5 to 1 (ref.<sup>53</sup> ). Although the trend is in good agreement with that of thin films, the bandgap is redshifted by as much as 300 meV for _n_ values between 3 and 5. By adding or removing monovalent cations, that is, increasing or decreasing _n_ , the thickness of the inorganic layer of the unit cell or quantum well is altered, which has a dramatic influence on the properties. As an example, the electrical properties of tin-based organic–inorganic halides alter as a function of _n_ from intrinsically semiconducting when _n_ = 1 to the heavily doped and ‘metallic like’ when _n_ = ∞. Such a transition may result from the disorder of organic fragments within the structure<sup>28</sup> . In this class of materials, the charge carriers are tightly confined in the inorganic layers sandwiched between the insulating organic layers forming a natural superlattice<sup>54</sup> . The spatial confinement and the dielectric mismatch between the organic and inorganic layers causes the formation of excitons with a Bohr radius that exceeds the well thickness<sup>55</sup> . This results in an exceptionally high binding energy (Fig. 3b)<sup>56</sup> . These electronic and excitonic properties are easily tuned as the spatial confinement is varied via _n_ . Likewise, the exciton-binding 

**NAtuRE MAtERiAlS** | VOL 20 | OCTObER 2021 | 1325–1336 | www.nature.com/naturematerials 

**1329** 

<mark>Review ARticle</mark> 

**NaTuRE MaTERIaLs** 



<!-- Start of picture text -->
a 2.6 b 500 6.0 c Exfoliated crystals  n  > 2<br>2.4 400 X LES<br>5.5<br>2.2 300<br>Exfoliated crystal 5.0<br>2.0 200 Edge states<br>Thin film 4.5<br>1.8 100<br>c ˄ Stacking<br>1.6 0 4.0<br>0 1 2 3 4 5 6 0 1 2 3 4 5 6<br>n n<br>d e f<br>68 nm n  = 1<br>Exfoliated crystal edges Bulk n  = 2<br>n  = 3<br>Order Disorder<br>n  = 4<br>Thin film Exfoliated  Monolayer<br>crystal<br>1.4 1.6 1.8 2.0 2.2 400 450 500 550 600 650 700 750 800 450 500 550 600 650 700 750<br>Energy (eV) Wavelength (nm) Wavelength (nm)<br>Optical bandgap (eV) Dielectric constant<br>Exciton binding energy (meV)<br>Intensity (a.u.) Intensity (a.u.)<br>Photoluminescence intensity (a.u.)<br><!-- End of picture text -->

**Fig. 3 | thickness-dependent optical and electronic properties in halide perovskites. a** , Optical bandgap extracted from absorption (open symbols) and photoluminescence experiments (filled symbols), as a function of _n_ , in both (bA)2(MA) _n_ −1Pb _n_ I3 _n_ +1 thin films and exfoliated flakes<sup>53</sup> . **b** , The evolution of the exciton binding energy<sup>56</sup> and high-frequency dielectric constant<sup>52</sup> in (bA)2(MA) _n_ −1Pb _n_ I3 _n_ +1 as a function of _n_ . **c** , Schematic of photoemission mechanisms based on exciton emission (X) and layer edge states in exfoliated perovskites with _n_ > 2. The main exciton and the layer edge state (LES) emission were probed at 2.010 eV and 1.680 eV, respectively<sup>53</sup> . **d** , Comparison of the photoluminescence spectra recorded on an exfoliated crystal, at the edge of the exfoliated crystal and on the corresponding thin film of (bA)2(MA)2Pb3I10. The spectrum obtained from the edge of the flake exhibits photoluminescence features of both the thin film and the exfoliated crystal, suggesting a common origin of the photoluminescence from layer edge states in exfoliated crystals and the photoluminescence of a thin polycrystalline film with _n_ > 2 (ref.<sup>53</sup> ). **e** , Order–disorder transition induced by laser illumination in an encapsulated perovskite monolayer. Surface relaxation gives rise to a shift of the photoluminescence line. This is reversible upon laser annealing in vacuum at higher power<sup>19</sup> . **f** , Shift of the photoluminescence line when going from bulk (bA)2(MA) _n−_ 1Pb _n_ I3 _n_ +1 to a single quantum well or monolayer with _n_ ranging from 1 to 4 (ref.<sup>19</sup> ). Credit: panels adapted with permission from: **a** , **c** , **d** , ref.<sup>53</sup> , AAAS; **b** , ref.<sup>52</sup> , National Academy of Sciences (right _y_ axis); **b** , ref.<sup>56</sup> , under a Creative Commons license CC bY 4.0 (left _y_ axis); **e** , **f** , ref.<sup>19</sup> , Springer Nature Ltd. 

energies of all-inorganic halide perovskites increase dramatically as _n_ decreases ( _n_ ≤ 3). In spite of the absence of organic layers, the value of monolayer Cs2PbI4 (181.7 meV) is almost three times larger than that of the bulk phase (CsPbI3, 59.1 meV)<sup>57</sup> . Nonlinear optical processes are possible in the hybrid dielectric-confined systems that host excitons with strong binding energies and also possess transitions with large oscillator strength<sup>58,59</sup> . Unfortunately, bulk samples suffer from grain boundaries and defect states limiting the coherence of 2D excitons<sup>11</sup> . These issues can be avoided in thinner single crystalline layers. Nonlinear optical studies on such 2D nanosheets have revealed thickness-dependent third-harmonic generation, which is suppressed in bulk polycrystalline halide perovskites, due to signal depletion and phase-matching conditions. The delaminated flakes with reduced thickness exhibit a third-order susceptibility, _χ_<sup>(3)</sup> , as high as 1.12 × 10<sup>−17</sup> m<sup>2</sup> V<sup>−2</sup> and conversion efficiencies are five orders of magnitude larger compared with other 2D materials<sup>60</sup> . 

The excitonic properties of exfoliated halide perovskites, especially those of monolayers consisting of only a single unit cell (~2.4 nm), can easily be manipulated through the dielectric environment it surrounds<sup>33</sup> . This can be the substrate or an encapsulating layer (if available) with dielectric properties distinct from the bulk crystal. Dielectric screening from the supporting substrate can be particularly prominent for halide perovskite monolayers, 

as evidenced by drastic changes in bandgap and exciton properties in TMDs<sup>61</sup> . For instance, in molecularly thin (BA)2PbBr4 sheets, the change in the dielectric environment causes an increase of the exciton binding energy to 490 meV, almost one-third larger compared with the binding energy in the corresponding layered bulk perovskite<sup>33,55</sup> . Absorption and photoluminescence studies suggest the formation of edge states in exfoliated perovskite single crystals with unit cells for which _n_ is larger than 2 (Fig. 3c,d). This is the result of the distortion of the lattice, the formation of chemically induced surface states and the resulting self-trapping of excitons. These states at the grain boundaries of monolayers promote the dissociation of photogenerated excitons into long-lived free carriers that are protected from non-radiative recombination. This intrinsic dissociation process is not observed in other quantum-confined systems. In contrast to thicker perovskites, excitons in exfoliated layers with _n_ ≤ 2 decay through the usual processes. There can be no doubt that halide perovskite monolayers represent a fertile playground for further photophysical investigations. 

Their optoelectronic properties depend not only on the quantum well thickness, such as _n_ , but also the stiffness of the lattice. The soft and ionic nature of the layers makes these ultrathin sheets susceptible to larger lattice deformations upon external mechanical, optical, thermal and electrical stimuli compared with bulk 

**NAtuRE MAtERiAlS** | VOL 20 | OCTObER 2021 | 1325–1336 | www.nature.com/naturematerials 

**1330** 

<mark>Review ARticle</mark> 

**NaTuRE MaTERIaLs** 



<!-- Start of picture text -->
a 80 b c<br>60 30 nm90 nm R + T like BiFeO3 E ( k )<br>120 nm<br>40 T like<br>200 5 µm 5 µm E  F k y<br>–20 R + T  k x<br>–40 BiFeO3 T<br>R + T<br>–60<br>–80 5 µm 5 µm k x<br>–20,000 –10,000 0 10,000 20,000<br>Magnetic field (Oe)<br>d e f 500<br>12.5 8 T<br>V 10.0<br>7.5 400 180 mT<br>H d.c. M NiFe 5.0 0 T<br>2.5 300<br>h rf AlO x 0 54 mT<br>Spin current LaAIO3<br>2DEG –2.5 200<br>SrTiO3 Charge current –5.0<br>–7.5 100 SrTiO3<br>Gate contact –10.0<br>V g –12.5 0 2 nm<br>0 100 200 300 400<br>Gate voltage (V) T  (mK)<br>–250 –200 –150 –100 –50 0 50 100 150 200 250<br>–1Magnetization (emu cc)<br>–1() R Ω ◻sheet<br>–2–1Charge current (A m T) m<br><!-- End of picture text -->

**Fig. 4 | interfacial properties of oxide perovskites. a** , Magnetic response of biFeO3 thin films (with a thickness of 30 nm, 90 nm and 120 nm) grown on SrTiO3. **b** , Electrochromism of biFeO3 thin film (50–70 nm thick). The reversible transformation from the mixed R + T-like phase to the T-like phase can be achieved in a selected region with the assistance of an electric field. The transformation causes a variation of the optical absorption intensity. The left panels are topography images and the right panels are transmission optical images. **c** , Left: the energy dispersion of a 2D electron system with Rashba spin splitting. Right: the related Fermi surface consisting of two concentric circles hosting electron spins with opposite chiralities. The spin angular momentum is locked to the linear momentum. _E_ is the electron energy, _E_ F is the Fermi level and _k_ is the momentum ( _kx_ and _ky_ are the in-plane momentum directions). **d** , Schematic of a device for spin injection and spin-charge conversion. _M_ is the magnetization, _V_ g is the gate voltage and _H_ d.c. and _h_ rf are the direct current and the radiofrequency magnetic fields, respectively. **e** , Gate voltage dependence of the normalized current produced by the inverse Edelstein effect in a 2DEG that forms at a SrTiO3/AlO _x_ heterointerface. The blue and green plotted traces reflect the gate sweep from 200 V to −200 V, and from −200 V to 200 V, respectively. **f** , The variation of sheet resistance ( _R_ sheet) as a function of temperature ( _T_ ) at different magnetic fields. The inset shows the heterointerface between LaAlO3 and SrTiO3 thin layers. Credit: panels adapted with permission from: **a** , ref.<sup>64</sup> , AAAS; **b** , ref.<sup>65</sup> , under a Creative Commons license CC bY 4.0; **c** , ref.<sup>89</sup> , AAAS; **d** , ref.<sup>71</sup> , Springer Nature Ltd; **e** , ref.<sup>90</sup> , Springer Nature Ltd; **f** , ref.<sup>69</sup> , Springer Nature Ltd. 

materials. A reversible shift in excitonic energies is generated upon laser irradiation in large-sized monolayers encapsulated by a layer of hexagonal boron nitride (Fig. 3e)<sup>19</sup> . This unique behaviour arises from dynamic surface relaxation and compression effects in these highly deformable monolayers. Such effects are far less pronounced in their thicker multilayer parent compounds. We note that the hexagonal boron nitride prevents photoinduced degradation of the exfoliated flakes. Unlike other inorganic 2D materials, thin sheets of halide perovskite undergo crystal lattice relaxation, which might be driven by the strong structural distortions in bulk hybrid halide perovskites<sup>33</sup> . The resulting in-plane lattice expansion in monolayer perovskite (~0.1 Å for (BA)2PbBr4) is responsible for the blueshift of both bandgap and photoluminescence emission, compared with the bulk counterpart. The emission characteristics are easily modulated by changing the halide composition or layer thickness (Fig. 3f)<sup>35,62</sup> . Moreover, the substitution of Pb with Ge and Sn lowers the bandgap range from 2.5–3.5 eV to 1.7–2.5 eV ref.<sup>63</sup> ). The incorporation of large semiconducting conjugated organic spacers into the inorganic matrix leads to charge transfer at the organic–inorganic interface on the timescale of a few picoseconds<sup>36</sup> . Such large conjugated ligands can also enhance the thermal and environmental stability of the isolated perovskite quantum wells. 

In contrast to halide perovskite monolayers, the study of oxide perovskite monolayers remains at a nascent stage. Bulk crystals and 

thin films of this material family have already unveiled rich physical phenomena since the late 1980s, including high-temperature superconductivity, multiferroic behaviour and colossal magnetoresistance, due to electron–electron interactions and correlations in the constituent transition metal ions<sup>22,26</sup> . However, it is not well understood how these effects would transform when approaching the monolayer limit. So far, only two archetypical examples out of many possible candidates have been experimentally realized since 2019<sup>22</sup> . Previous studies on BiFeO3 thin films suggest a thickness-dependent magnetic moment<sup>64</sup> (Fig. 4a) as well as an electric-field-tunable optical transmission (Fig. 4b)<sup>65</sup> . Ultrathin freestanding BiFeO3 sheets, which are not subjected to epitaxial strain, exhibit lattice distortions and a giant polarization, because of a transition of the lattice from the R to the T-like phase when approaching the 2D limit<sup>22</sup> . Near interfaces, unusual 2D electron phases can arise due to the strong ionic character of oxide perovskites<sup>66</sup> . In ferroelectric crystals with broken spatial inversion symmetry, energy bands split as a result of Rashba spin–orbit coupling (Fig. 4c)<sup>18</sup> . This effect allows for the detection of spin currents as well as the conversion of charge current to spin current and vice versa, using the direct and inverse Edelstein effects without the need for ferromagnetic contacts or an external applied magnetic field (Fig. 4d,e)<sup>67</sup> . Through the application of a gate voltage across the interface, it is possible to manipulate the electron occupation as well as the asymmetry of 

**NAtuRE MAtERiAlS** | VOL 20 | OCTObER 2021 | 1325–1336 | www.nature.com/naturematerials 

**1331** 

<mark>Review ARticle</mark> 

### **NaTuRE MaTERIaLs** 



<!-- Start of picture text -->
a b c<br>Perovskite monolayer Laser beam<br>Perovskite monolayer<br>Transparent electrode<br>Source Source<br>Hole injection layer<br>Perovskite monolayer Drain Drain<br>Electron injection layer Gate dielectric Gate dielectric<br>Metal electrode Gate Gate<br>d e f<br>Polariton laser Electrolyte<br>Gate Perovskite monolayer<br>Gate dielectric Electrode<br>Source<br>Drain p-type DBR Metal anode<br>Gate dielectricGate Perovskite monolayer Perovskitemonolayer<br>n-type DBR<br>Electrode<br><!-- End of picture text -->

**Fig. 5 | Potential applications for perovskite monolayers.** Perovskite monolayers offer a fertile playground of functionalities for a wide array of devices. **a** – **f** , For example, they can be embedded in light-emitting diodes as emissive layers ( **a** ), photodetectors as absorption layers ( **b** ), thermoelectric generators as thermoconducting materials ( **c** ), spintronic devices as spin channels ( **d** ), polariton lasers as active layers (DbR is the distributed bragg reflector) ( **e** ) and metal–air batteries as air cathodes ( **f** ). 

the quantum well. This control over the interfacial potential drop alters the strength of the Rashba parameter and allows tuning of the magnitude of the Rashba spin–orbit splitting. For example, SrTiO3 is a wide bandgap insulator that hosts a two-dimensional electron gas (2DEG) at the surface with a giant Rashba splitting producing two subbands separated with an energy gap of 90 meV and two concentric circular Fermi surfaces containing electron spins with opposite chiralities<sup>68</sup> . Interfacial superconductivity was discovered at SrTiO3/LaAlO3 heterointerfaces, where the use of back-gating can control electrostatically the superconductor–metal–insulator transition (Fig. 4f)<sup>69</sup> . At SrTiO3/γ-Al2O3 heterointerfaces, this 2DEG displays an electron mobility of up to 1.4 × 10<sup>5</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> (ref.<sup>47</sup> ). The combination of high mobility and long spin lifetime<sup>70</sup> are important prerequisites for efficient spin-charge conversion. A spin-charge conversion efficiency ten times larger than what has been reported in topological insulators such as HgTe and α-Sn has been reported in these 2DEGs<sup>71</sup> . This makes SrTiO3-based 2DEGs an appealing platform for the design of all-electrical spintronic devices. We note that according to density functional theory, similar properties can be expected in bismuth aluminate (BiAlO3). It has been suggested that the polar distortion in this ferroelectric perovskite oxide in conjunction with a sizeable Rashba spin splitting<sup>72</sup> may enable the full conversion between spin and charge through polarization switching in a reversible manner. 

While Rashba splitting has been a well-known effect at the interfaces of oxide perovskites, the use of monolayer perovskites instead of the surface of a bulk layer offers additional degrees of freedom and considerably expands the toolbox of the spintronics community. For instance, the Rashba effect can be modulated by the structural distortions associated with diverse surface terminations. The charge conduction, spin transport and Rashba strength parameter can be far more easily manipulated by extrinsic parameters, including substrates (for example, suspended, encapsulated), contacts and heteroatom doping. Such ultrathin perovskite layers can also be used as a tunnel barrier in a junction, where the spin Hall effect appears because of the non-centrosymmetric nature of the barrier<sup>73</sup> . Spin polarization can also be controlled through chemical design<sup>74</sup> . The integration of chirality into perovskite structures can be achieved by embedding chiral organic and inorganic compo- 

nents<sup>75</sup> . This provides attractive venues in fields such as chiroptics, biosensing, quantum computing and for devices with non-volatile memory functionality. We note for the sake of completeness that large Rashba splittings not only occur in oxide perovskites but also have been observed in layered halide perovskite with energy splittings as large as (40 ± 5 meV) enriching this field further with the possibility of achieving ferroelectric control over spin textures<sup>17</sup> . 

#### **Potential device applications** 

As described in the previous section, different synthesis methods result in perovskite monolayers with diverse thickness, size, composition and controllability, which have a direct impact on their potential utilization. Monolayer perovskites grant the possibility to design and fabricate vertical/lateral heterostructures and artificial superlattices in any desirable fashion<sup>37</sup> . The molecular engineering offers a myriad of opportunities to tailor the optical, electronic and chemical properties in addition to the possibilities available through structural modifications and external dielectric screening<sup>76</sup> . Oxide perovskite monolayers are predestined for the use as catalysts due to their tunable structures and defect chemistry, while halide perovskite monolayers are attractive for photovoltaic applications, although their study for this purpose is at an early stage. Beyond that, also advanced photodetectors, batteries and other devices based on polariton interactions are conceivable, as described in more detail below (Fig. 5). 

**Photodetectors.** Monolayer perovskites with moderate bandgaps are good candidates for photodetectors, because of efficient light adsorption, charge extraction and the absence of grain boundaries. The versatile band structure engineering methods, which can be deployed on halide or oxide perovskites, allow devices with light detection across a broad range of the electromagnetic spectrum. Moreover, in combination with conventional 2D materials (such as MoS2, WSe2 and so on) the surface and interface properties can be modified to improve the photocarrier extraction<sup>15</sup> . As an example, a heterostructure device consisting of a monolayer tungsten disulfide (WS2) and a thickness-tunable hybrid halide perovskite (MA) _n_ +1Pb _n_ I3 _n_ +1 has been shown to exhibit remarkable photosensing and charge separation capabilities<sup>77</sup> . Indeed, the p–n junction 

**NAtuRE MAtERiAlS** | VOL 20 | OCTObER 2021 | 1325–1336 | www.nature.com/naturematerials 

**1332** 

<mark>Review ARticle</mark> 

**NaTuRE MaTERIaLs** 



<!-- Start of picture text -->
a<br>Organic layer<br>E g E h +<br>Organic layer Electric field<br>Organic layer<br>e –<br>Organic layer<br>Two coupled quantum wells<br>b<br>e –<br>E c2 e –<br>Monolayer 1<br>… … E c1<br>h +<br>… … E v2<br>E v1<br>Monolayer 2<br>h +<br>Heterobilayers with type-II band alignment<br><!-- End of picture text -->

**Fig. 6 | the formation of interlayer excitons. a** , Schematic of two stacked organic–inorganic hybrid perovskite layers. When applying a vertical electric field, electrons and holes will be located in different quantum wells and form interlayer excitons. _E_ g is the bandgap energy. **b** , Schematic of a perovskite-based heterobilayer with type-II band alignment. Here, electrons and holes get separated by the built-in electric field to form interlayer excitons. _E_ v1 and _E_ c1 are the energies of the valence and conduction band edges in monolayer 1, respectively; _E_ v2 and _E_ c2 are the energies of the valence and conduction band edges in monolayer 2, respectively. 

with atomically sharp interfaces has a type-II band alignment (type I for thicker perovskite samples), which leads to an excellent photoresponsivity on the order of 10<sup>4</sup> AW<sup>−1</sup> and an ultrafast photoresponse (64 μs). The photosensing ability of pristine halide perovskite has recently been demonstrated down to the monolayer level<sup>19</sup> . The internal quantum efficiency was 34% for a monolayer (BA)2(MA)3Pb4I13 and 19% for the bulk crystal. The higher efficiency is attributed to the enhanced charge-collection efficiency in molecularly thin sheets. Moreover, the devices show ultralow dark current and on/off current ratios as high as 10<sup>5</sup> . The fortunate combination of excellent detection capability with the deformable nature of perovskite monolayers can potentially be brought in perfect synergy in smart photodetectors responding to external stimuli. 

**Batteries.** Oxide perovskites and their derivatives can serve as efficient and stable catalysts in metal–air batteries, where oxygen reduction and evolution reactions (ORR/OER) play crucial roles. For example, LaMnO3+ _δ_ and LaNiO3 particles exhibit significant intrinsic activity in ORR, which is comparable with a noble metal catalyst (such as Pt/C)<sup>78</sup> . The ORR performance of oxide perovskites is correlated with the amount of O2 _σ_ *-antibonding and the degree of B-site transition metal–oxygen covalency. Given that the ORR performance of these materials mostly depends on the surface area, oxide perovskite monolayers with completely exposed active sites can further boost the device performance. Some types of oxide perovskite, such as La0.5Li0.5TiO3, also have excellent lithium-ion conductivity up to 1 × 10<sup>−3</sup> Ω<sup>−1</sup> cm<sup>−1</sup> (ref.<sup>79</sup> ). Embedded oxide monolayers with fast Li<sup>+</sup> diffusion at the interface are promising ion conductors for rechargeable all-solid-state batteries. 

**Devices based on polariton effects.** The optical and excitonic characteristics of 2D halide perovskites are also promising to benefit from polaritons in the strong light–matter interaction regime<sup>80</sup> . 

The exciton–phonon interaction in (PEA)2PbI4 is one order of magnitude larger than in gallium arsenide (GaAs) quantum wells<sup>81</sup> . Hence, monolayer halide perovskites are attractive active layers in electrically driven quantum well microcavity devices for polariton laser emission, which operate in the regime of strong coupling between excitons and photons<sup>82</sup> . Additional opportunities in electro-optics and nonlinear optics may arise by tuning the exciton– polariton interaction through chemical composition engineering of monolayer halide perovskites. 

The remarkable rise in power conversion efficiency of metal halide bulk perovskite photovoltaic cells can be largely attributed to favourable charge-carrier mobilities. Electrical transport studies on monolayers should therefore be an important target to unveil the fundamental charge transport mechanism. Currently, most studies still concentrate on field-effect transistors fabricated on spin-coated polycrystalline thin films. The measured carrier mobility ranges from 0.1 to 40 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> (ref.<sup>83</sup> ). This value, however, probably underestimates the intrinsic carrier mobility, because of the defects and grain boundaries in the polycrystalline samples<sup>84,85</sup> . Although the use of halide single crystals can reduce the number of grain boundaries, at room temperature, the mobility is also limited by ion migration of the perovskite layers and the importance of the Fröhlich interaction<sup>6</sup> . Unfortunately, the incorporation of monolayer halide perovskites into field-effect transistors faces electrical contact issues. The insulating organic molecules on the surfaces act as a tunnelling gap and suppress the injection of electrons. An obvious strategy to try to achieve good electrical contacts is replacing the standard gold contacts with other metals, such as aluminium, titanium, silver, platinum and others to modulate the height of the Schottky barrier ( _Φ_ SB)<sup>86</sup> . Due to strong Fermi level pinning, this approach can only be effective when the pinning occurs near one of the perovskite band edges. To improve the influence of the metal work-function, it is necessary to insert an ultrathin insulating 

**NAtuRE MAtERiAlS** | VOL 20 | OCTObER 2021 | 1325–1336 | www.nature.com/naturematerials 

**1333** 

<mark>Review ARticle</mark> 

**NaTuRE MaTERIaLs** 

layer (such as MoO **_x_** ) between the metal and the perovskite layer. The oxide interlayer reduces the Schottky barrier height, but does introduce an extra tunnel barrier<sup>87</sup> . Hence, an optimization of the competition between the desirable reduction of the Schottky barrier and the increase of the overall barrier thickness is required. Also graphene can be used as interlayer material. Even though it is a Dirac semimetal, the Fermi level or chemical potential can easily be adjusted by applying a gate bias, thereby effectively reducing the barrier height. Such additionally inserted layers can also protect the perovskite from ambient degradation. 

#### **Outlook** 

In contrast to the tremendous progress made in bulk perovskite crystals, the journey of exploring monolayer perovskites has just started. So far, only a few types of monolayers have been prepared, although numerous perovskites are stable in the 2D regime. It is of primary importance to develop new protocols to grow high-quality layered crystals and wafer-scale monolayers with high phase purity, sharp thickness control, tailorable composition and uniform crystal orientation. However, this requires a better understanding of the crystallization kinetics and thermodynamics of crystal nucleation. In addition, it is crucial to address the challenge of material instability under ambient conditions, especially for the halide perovskite monolayers. Attempts to isolate monolayers from bulk crystals should not be limited to sticky tape delamination or cleavage. Other exfoliation techniques, including shear-induced delamination, supercritical fluid-assisted exfoliation and ball milling, are worthwhile pursuing to make perovskite nanosheets. The resulting products can be dispersed in appropriate solvents that are attractive for printing technologies. On the other hand, epitaxial growth offers a fresh hunting ground to customize the lattice structure of monolayer perovskites through precise layer-by-layer deposition, which may lead to large-area films and interesting heterojunctions, such as Janus monolayers. 

Apart from the required tour de force in synthesis, an intense research thrust to disclose the fundamental physics of perovskite monolayers and the structure–property relationship, and to exploit their potential in prospective, innovative device concepts, is needed. For example, hybrid perovskite monolayers are direct-bandgap semiconductors with a ‘built in’ quantum well confinement potential and a remarkably strong light–matter interaction<sup>15</sup> . Bilayer devices allow the spatial separation of electrons and holes in the two quantum wells by applying a perpendicular electric field, so that interlayer excitons can form (Fig. 6a). The reduced overlap of the electron and hole wavefunctions increases the excitonic lifetime. Inorganic halide perovskite monolayers form a large family of 2D semiconductors possessing different bandgaps and work functions. By combining two of them or a single one with a TMD monolayer (MX2, where M = Mo, W and X = S, Se, Te), it is possible to create a type-II band alignment as shown in Fig. 6b<sup>88</sup> ; in such a configuration, electrons and holes will also occupy separate layers, causing a permanent electric dipole moment. Moreover, it should be possible to create a moiré superlattice potential via rotational misalignment or different lattice constants of perovskite heterobilayers. The induced moiré potential can trap interlayer excitons to create an ordered array of quantum dot-like emitters as well as enhance the effects of exciton–exciton interactions that contribute to the optical nonlinearity. Perovskite ionic lattices are also inherently more sensitive to strain than TMDs and external forces are bound to have a larger influence on the moiré potential landscape of perovskite heterobilayers. This may offer additional opportunities to manipulate interlayer excitons and the exciton moiré mini-bands as well as control the exciton–exciton interactions by external electric and magnetic fields in these systems. 

In certain types of oxide perovskite, the coexistence of tunable Rashba splitting and superconductivity in 2DEGs predestine 

these compounds for the identification and fundamental study of Majorana fermions<sup>67</sup> , the key players in one of the paradigms towards quantum computation. Because of the completely exposed surfaces, monolayer oxide perovskites provide great ease to generate, control and convert spin current, the key ingredients for low-power spintronics. At present, monolayer-based perovskite devices are rather simplistic. Their integration with other 2D inorganic materials (such as boron nitride) or organic semiconductors (such as 2D metal–organic frameworks) will probably boost their usefulness, performance and functionality similar to what has happened in recent years with other 2D materials with the advent of van der Waals stacking. Ingenuity will coincide with the agony of choice. We posit that this class of new 2D material holds enormous potential for the future development of multidisciplinary research combining electronics, photonics and spintronics. 

Received: 22 June 2020; Accepted: 28 April 2021; Published online: 10 June 2021 

#### **References** 

1. Fiori, G. et al. Electronics based on two-dimensional materials. 

   - _Nat. Nanotechnol._ **9** , 768–779 (2014). 

2. Novoselov, K. S. et al. Two-dimensional atomic crystals. _Proc. Natl Acad. Sci. USA_ **102** , 10451–10453 (2005). 

3. Sun, C., Alonso, J. A. & Bian, J. Recent advances in perovskite-type oxides for energy conversion and storage applications. _Adv. Energy Mater._ **11** , 2000459 (2021). 

4. Jeon, N. J. et al. Compositional engineering of perovskite materials for 

   - high-performance solar cells. _Nature_ **517** , 476–480 (2015). 

5. Tsai, H. et al. High-efficiency two-dimensional Ruddlesden–Popper perovskite solar cells. _Nature_ **536** , 312–316 (2016). 

6. Herz, L. M. Charge-carrier mobilities in metal halide perovskites: fundamental mechanisms and limits. _ACS Energy Lett._ **2** , 1539–1548 (2017). 

7. Brenner, T. M., Egger, D. A., Kronik, L., Hodes, G. & Cahen, D. Hybrid organic–inorganic perovskites: low-cost semiconductors with intriguing charge-transport properties. _Nat. Rev. Mater._ **1** , 15007 (2016). 

8. Xing, G. et al. Long-range balanced electron- and hole-transport lengths in organic–inorganic CH3NH3PbI3. _Science_ **342** , 344–347 (2013). 

9. De Wolf, S. et al. Organometallic halide perovskites: sharp optical absorption edge and its relation to photovoltaic performance. _J. Phys. Chem. Lett._ **5** , 1035–1039 (2014). 

10. Saliba, M., Correa-Baena, J.-P., Grätzel, M., Hagfeldt, A. & Abate, A. Perovskite solar cells: from the atomic level to film quality and device performance. _Angew. Chem. Int. Ed._ **57** , 2554–2569 (2018). 

11. Stoumpos, C. C. et al. Ruddlesden–Popper hybrid lead iodide perovskite 2D homologous semiconductors. _Chem. Mater._ **28** , 2852–2867 (2016). 

12. Mao, L. et al. Hybrid Dion–Jacobson 2D lead iodide perovskites. _J. Am. Chem. Soc._ **140** , 3775–3783 (2018). 

13. Leng, K., Fu, W., Liu, Y., Chhowalla, M. & Loh, K. P. From bulk to molecularly thin hybrid perovskites. _Nat. Rev. Mater._ **5** , 482–500 (2020). 

14. Shi, E. et al. Two-dimensional halide perovskite nanomaterials and heterostructures. _Chem. Soc. Rev._ **47** , 6046–6072 (2018). 

15. Qi, X. et al. Photonics and optoelectronics of 2D metal-halide perovskites. _Small_ **14** , 1800682 (2018). 

16. Mao, L., Stoumpos, C. C. & Kanatzidis, M. G. Two-dimensional hybrid halide perovskites: principles and promises. _J. Am. Chem. Soc._ **141** , 1171–1190 (2019). 

17. Zhai, Y. et al. Giant Rashba splitting in 2D organic–inorganic halide perovskites measured by transient spectroscopies. _Sci. Adv._ **3** , e1700704 (2017). 

18. Manchon, A., Koo, H. C., Nitta, J., Frolov, S. M. & Duine, R. A. New perspectives for Rashba spin–orbit coupling. _Nat. Mater._ **14** , 871–882 (2015). 

19. Leng, K. et al. Molecularly thin two-dimensional hybrid perovskites with tunable optoelectronic properties due to reversible surface relaxation. _Nat. Mater._ **17** , 908–914 (2018). 

20. Wang, Y. et al. Chemical vapor deposition growth of single-crystalline cesium lead halide microplatelets and heterostructures for optoelectronic applications. _Nano Res._ **10** , 1223–1233 (2017). 

21. Li, L. et al. Two-step growth of 2D organic–inorganic perovskite microplates and arrays for functional optoelectronics. _J. Phys. Chem. Lett._ **9** , 4532–4538 (2018). 

22. Ji, D. et al. Freestanding crystalline oxide perovskites down to the monolayer limit. _Nature_ **570** , 87–90 (2019). 

23. Hong, S. S. et al. Two-dimensional limit of crystalline order in perovskite membrane films. _Sci. Adv._ **3** , eaao5173 (2017). 

**NAtuRE MAtERiAlS** | VOL 20 | OCTObER 2021 | 1325–1336 | www.nature.com/naturematerials 

**1334** 

### **NaTuRE MaTERIaLs** 

24. Li, S., Zhang, Y., Yang, W., Liu, H. & Fang, X. 2D perovskite Sr2Nb3O10 for high-performance UV photodetectors. _Adv. Mater._ **32** , 1905443 (2020). 

25. Willett, R. D. Crystal structure of (NH4)2CuCl4. _J. Chem. Phys._ **41** , 2243–2244 (1964). 

26. Bednorz, J. G. & Müller, K. A. Possible high _T_ c superconductivity in the Ba−La−Cu−O system. _Physica B_ **64** , 189–193 (1986). 

27. Dolzhenko, Y. I., Inabe, T. & Maruyama, Y. In situ X-ray observation on the intercalation of weak interaction molecules into perovskite-type layered crystals (C9H19NH3)2PbI4 and (C10H21NH3)2CdCl4. _Bull. Chem. Soc. Jpn_ **59** , 563–567 (1986). 

28. Mitzi, D. B., Feild, C. A., Harrison, W. T. A. & Guloy, A. M. Conducting tin halides with a layered organic-based perovskite structure. _Nature_ **369** , 467–469 (1994). 

29. Schaak, R. E. & Mallouk, T. E. Perovskites by design: a toolbox of solid-state reactions. _Chem. Mater._ **14** , 1455–1471 (2002). 

30. Chen, Y. et al. 2D Ruddlesden–Popper perovskites for optoelectronics. _Adv. Mater._ **30** , 1703487 (2018). 

31. Huang, Y. et al. Universal mechanical exfoliation of large-area 2D crystals. _Nat. Commun._ **11** , 2453 (2020). 

32. Niu, W., Eiden, A., Prakash, G. V. & Baumberg, J. J. Exfoliation of self-assembled 2D organic–inorganic perovskite semiconductors. _Appl. Phys. Lett._ **104** , 171111 (2014). 

33. Yaffe, O. et al. Excitons in ultrathin organic–inorganic perovskite crystals. _Phys. Rev. B_ **92** , 045414 (2015). 

34. Li, D. et al. Graphene-sensitized perovskite oxide monolayer nanosheets for efficient photocatalytic reaction. _Adv. Funct. Mater._ **28** , 1806284 (2018). 

35. Dou, L. et al. Atomically thin two-dimensional organic-inorganic hybrid perovskites. _Science_ **349** , 1518–1521 (2015). 

36. Gao, Y. et al. Molecular engineering of organic–inorganic hybrid perovskites quantum wells. _Nat. Chem._ **11** , 1151–1157 (2019). 

37. Shi, E. et al. Two-dimensional halide perovskite lateral epitaxial heterostructures. _Nature_ **580** , 614–620 (2020). 

38. Weidman, M. C., Seitz, M., Stranks, S. D. & Tisdale, W. A. Highly tunable colloidal perovskite nanoplatelets through variable cation, metal, and halide composition. _ACS Nano_ **10** , 7830–7839 (2016). 

39. Bekenstein, Y., Koscher, B. A., Eaton, S. W., Yang, P. & Alivisatos, A. P. Highly luminescent colloidal nanoplates of perovskite cesium lead halide and their oriented assemblies. _J. Am. Chem. Soc._ **137** , 16008–16011 (2015). 

40. Akkerman, Q. A. et al. Solution synthesis approach to colloidal cesium lead halide perovskite nanoplatelets with monolayer-level thickness control. _J. Am. Chem. Soc._ **138** , 1010–1016 (2016). 

41. Liu, J. et al. Two-dimensional CH3NH3PbI3 perovskite: synthesis and optoelectronic application. _ACS Nano_ **10** , 3536–3542 (2016). 

42. Lu, D. et al. Synthesis of freestanding single-crystal perovskite films and heterostructures by etching of sacrificial water-soluble layers. _Nat. Mater._ **15** , 1255–1260 (2016). 

43. Wang, Y. et al. High-temperature ionic epitaxy of halide perovskite thin film and the hidden carrier dynamics. _Adv. Mater._ **29** , 1702643 (2017). 

44. Kowarik, S., Gerlach, A. & Schreiber, F. Organic molecular beam deposition: fundamentals, growth dynamics, andin situstudies. _J. Phys. Condens. Matter_ **20** , 184005 (2008). 

45. Song, J. et al. Monolayer and few-layer all-inorganic perovskites as a new family of two-dimensional semiconductors for printable optoelectronic devices. _Adv. Mater._ **28** , 4861–4869 (2016). 

46. Yang, Z. et al. Engineering the exciton dissociation in quantum-confined 2D CsPbBr3 nanosheet films. _Adv. Funct. Mater._ **28** , 1705908 (2018). 

47. Chen, Y. Z. et al. A high-mobility two-dimensional electron gas at the spinel/ perovskite interface of γ-Al2O3/SrTiO3. _Nat. Commun._ **4** , 1371 (2013). 

48. Ning, C.-Z., Dou, L. & Yang, P. Bandgap engineering in semiconductor alloy nanomaterials with widely tunable compositions. _Nat. Rev. Mater._ **2** , 17070 (2017). 

49. Iqbal, A., Sun, Z., Wang, G. & Hu, J. Optimizing band gap of inorganic halide perovskites by donor–acceptor pair codoping. _Inorg. Chem._ **59** , 6053–6059 (2020). 

50. Ou, Q. et al. Band structure engineering in metal halide perovskite nanostructures for optoelectronic applications. _Nano Mater. Sci._ **1** , 268–287 (2019). 

51. Ou, Q. et al. Strong depletion in hybrid perovskite p–n junctions induced by local electronic doping. _Adv. Mater._ **30** , 1705792 (2018). 

52. Soe, C. M. M. et al. Structural and thermodynamic limits of layer thickness in 2D halide perovskites. _Proc. Natl Acad. Sci. USA_ **116** , 58–66 (2019). 

53. Blancon, J.-C. et al. Extremely efficient internal exciton dissociation through edge states in layered 2D perovskites. _Science_ **355** , 1288–1292 (2017). 

54. Muljarov, E. A., Tikhodeev, S. G., Gippius, N. A. & Ishihara, T. Excitons in self-organized semiconductor/insulator superlattices: PbI-based perovskite compounds. _Phys. Rev. B_ **51** , 14370–14378 (1995). 

55. Ishihara, T., Takahashi, J. & Goto, T. Exciton state in two-dimensional perovskite semiconductor (C10H21NH3)2PbI4. _Solid State Commun._ **69** , 933–936 (1989). 

## <mark>Review ARticle</mark> 

56. Blancon, J. C. et al. Scaling law for excitons in 2D perovskite quantum wells. _Nat. Commun._ **9** , 2254 (2018). 

57. Ding, Y.-F. et al. Strong thickness-dependent quantum confinement in all-inorganic perovskite Cs2PbI4 with a Ruddlesden–Popper structure. _J. Mater. Chem. C_ **7** , 7433–7441 (2019). 

58. Hanamura, E., Nagaosa, N., Kumagai, M. & Takagahara, T. Quantum wells with enhanced exciton effects and optical non-linearity. _Mater. Sci. Eng. B_ **1** , 255–258 (1988). 

59. Even, J., Pedesseau, L. & Katan, C. Understanding quantum confinement of charge carriers in layered 2D hybrid perovskites. _ChemPhysChem_ **15** , 3733–3741 (2014). 

60. Abdelwahab, I. et al. Highly enhanced third-harmonic generation in 2D 

   - perovskites at excitonic resonances. _ACS Nano_ **12** , 644–650 (2018). 

61. Ugeda, M. M. et al. Giant bandgap renormalization and excitonic effects in a monolayer transition metal dichalcogenide semiconductor. _Nat. Mater._ **13** , 1091–1095 (2014). 

62. Chen, J. et al. A ternary solvent method for large-sized two-dimensional 

   - perovskites. _Angew. Chem. Int. Ed._ **56** , 2390–2394 (2017). 

63. Pandey, M., Jacobsen, K. W. & Thygesen, K. S. Band gap tuning and defect tolerance of atomically thin two-dimensional organic–inorganic halide perovskites. _J. Phys. Chem. Lett._ **7** , 4346–4352 (2016). 

64. Wang, J. et al. Response to comment on ‘Epitaxial BiFeO3 multiferroic thin film heterostructures’. _Science_ **307** , 1203–1203 (2005). 

65. Sando, D. et al. Large elasto-optic effect and reversible electrochromism in multiferroic BiFeO3. _Nat. Commun._ **7** , 10718 (2016). 

66. Mannhart, J. & Schlom, D. G. Oxide interfaces—an opportunity for electronics. _Science_ **327** , 1607–1611 (2010). 

67. Varignon, J., Vila, L., Barthélémy, A. & Bibes, M. A new spin for oxide interfaces. _Nat. Phys._ **14** , 322–325 (2018). 

68. Santander-Syro, A. F. et al. Giant spin splitting of the two-dimensional electron gas at the surface of SrTiO3. _Nat. Mater._ **13** , 1085–1090 (2014). 

69. Saito, Y., Nojima, T. & Iwasa, Y. Highly crystalline 2D superconductors. _Nat. Rev. Mater._ **2** , 16094 (2016). 

70. Şahin, C., Vignale, G. & Flatté, M. E. Derivation of effective spin–orbit Hamiltonians andspin lifetimes with application to SrTiO3 heterostructures. _Phys. Rev. B_ **89** , 155402 (2014). 

71. Vaz, D. C. et al. Mapping spin–charge conversion to the band structure in a topological oxide two-dimensional electron gas. _Nat. Mater._ **18** , 1187–1193 (2019). 

72. da Silveira, L. G. D., Barone, P. & Picozzi, S. Rashba–Dresselhaus spin-splitting in the bulk ferroelectric oxide BiAlO3. _Phys. Rev. B_ **93** , 245159 (2016). 

73. Matos-Abiague, A. & Fabian, J. Tunneling anomalous and spin Hall effects. _Phys. Rev. Lett._ **115** , 056602 (2015). 

74. Long, G. et al. Spin control in reduced-dimensional chiral perovskites. _Nat. Photon._ **12** , 528–533 (2018). 

75. Long, G. et al. Chiral-perovskite optoelectronics. _Nat. Rev. Mater._ **5** , 423–439 (2020). 

76. Borghardt, S. et al. Engineering of optical and electronic band gaps in transition metal dichalcogenide monolayers through external dielectric screening. _Phys. Rev. Mater._ **1** , 054001 (2017). 

77. Yang, T. et al. Ultrahigh-performance optoelectronics demonstrated in ultrathin perovskite-based vertical semiconductor heterostructures. _ACS Nano_ **13** , 7996–8003 (2019). 

78. Suntivich, J. et al. Design principles for oxygen-reduction activity on perovskite oxide catalysts for fuel cells and metal–air batteries. _Nat. Chem._ **3** , 546–550 (2011). 

79. Alonso, J. A. et al. On the location of Li<sup>+</sup> cations in the fast Li-cation conductor La0.5Li0.5TiO3 perovskite. _Angew. Chem. Int. Ed._ **39** , 619–621 (2000). 

80. Weisbuch, C., Nishioka, M., Ishikawa, A. & Arakawa, Y. Observation of the coupled exciton-photon mode splitting in a semiconductor quantum microcavity. _Phys. Rev. Lett._ **69** , 3314–3317 (1992). 

81. Gauthron, K. et al. Optical spectroscopy of two-dimensional layered (C6H5C2H4-NH3)2-PbI4 perovskite. _Opt. Express_ **18** , 5912–5919 (2010). 

82. Schneider, C. et al. An electrically pumped polariton laser. _Nature_ **497** , 348–352 (2013). 

83. Liang, Y., Li, F. & Zheng, R. Low-dimensional hybrid perovskites for field-effect transistors with improved stability: progress and challenges. _Adv. Electron. Mater._ **6** , 2000137 (2020). 

84. Reid, O. G., Yang, M., Kopidakis, N., Zhu, K. & Rumbles, G. Grain-size-limited mobility in methylammonium lead iodide perovskite thin films. _ACS Energy Lett._ **1** , 561–565 (2016). 

85. Senanayak, S. P. et al. Understanding charge transport in lead iodide perovskite thin-film field-effect transistors. _Sci. Adv._ **3** , e1601935 (2017). 

86. Allain, A., Kang, J., Banerjee, K. & Kis, A. Electrical contacts to two-dimensional semiconductors. _Nat. Mater._ **14** , 1195–1205 (2015). 

87. Schulman, D. S., Arnold, A. J. & Das, S. Contact engineering for 2D materials and devices. _Chem. Soc. Rev._ **47** , 3037–3058 (2018). 

**NAtuRE MAtERiAlS** | VOL 20 | OCTObER 2021 | 1325–1336 | www.nature.com/naturematerials 

**1335** 

**NaTuRE MaTERIaLs** 

## <mark>Review ARticle</mark> 

88. Rivera, P. et al. Observation of long-lived interlayer excitons in monolayer MoSe2–WSe2 heterostructures. _Nat. Commun._ **6** , 6242 (2015). 

89. Song, Q. et al. Observation of inverse Edelstein effect in Rashba-split 2DEG between SrTiO3 and LaAlO3 at room temperature. _Sci. Adv._ **3** , e1602312 (2017). 

90. Noël, P. et al. Non-volatile electric control of spin–charge conversion in a SrTiO3 Rashba system. _Nature_ **580** , 483–486 (2020). 

91. Lemanov, V. V., Sotnikov, A. V., Smirnova, E. P., Weihnacht, M. & Kunze, R. Perovskite CaTiO3 as an incipient ferroelectric. _Solid State Commun._ **110** , 611–614 (1999). 

92. Kubicek, M., Bork, A. H. & Rupp, J. L. M. Perovskite oxides—a review on a versatile material class for solar-to-fuel conversion processes. _J. Mater. Chem. A_ **5** , 11983–12000 (2017). 

93. Wu, M. K. et al. Superconductivity at 93 K in a new mixed-phase Y–Ba–Cu–O compound system at ambient pressure. _Phys. Rev. Lett._ **58** , 908–910 (1987). 

94. Maeda, H., Tanaka, Y., Fukutomi, M. & Asano, T. A new high- _T_ c oxide superconductor without a rare earth element. _Jpn J. Appl. Phys._ **27** , L209–L210 (1988). 

95. Liu, C. et al. Two-dimensional superconductivity and anisotropic transport at KTaO3 (111) interfaces. _Science_ **371** , 716–721 (2021). 

96. MØLler, C. K. Crystal structure and photoconductivity of cæsium plumbohalides. _Nature_ **182** , 1436–1436 (1958). 

97. Kojima, A., Teshima, K., Shirai, Y. & Miyasaka, T. Organometal halide perovskites as visible-light sensitizers for photovoltaic cells. _J. Am. Chem. Soc._ **131** , 6050–6051 (2009). 

98. Al-Ashouri, A. et al. Monolithic perovskite/silicon tandem solar cell with >29% efficiency by enhanced hole extraction. _Science_ **370** , 1300–1309 (2020). 

#### **Acknowledgements** 

We thank P. Zhang (Technische Universität Dresden), Y. Li (Technische Universität Chemnitz) and C. Anichini (University of Strasbourg) for contributing Figs. 2 and 5. J.H.S. acknowledges financial support from the EU Graphene Flagship Core 3 programme and the DFG (SPP 2244). M.S. acknowledges financial support from the German Science Foundation (DFG: GRK 2642). 

#### **Author contributions** 

A.G.R. and S.Y. conceived the project and wrote the manuscript. All authors contributed to the revision of the manuscript. 

#### **Competing interests** 

The authors declare no competing interests. 

#### **Additional information** 

**Correspondence** should be addressed to S.Y., J.H.S. or M.S. 

**Peer review information** _Nature Materials_ thanks Qiaoliang Bao and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at www.nature.com/reprints. 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

© Springer Nature Limited 2021 

**NAtuRE MAtERiAlS** | VOL 20 | OCTObER 2021 | 1325–1336 | www.nature.com/naturematerials 

**1336** 

