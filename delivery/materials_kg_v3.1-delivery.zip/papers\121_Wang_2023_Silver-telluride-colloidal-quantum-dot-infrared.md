# Silver telluride colloidal quantum dot infrared photodetectors and image sensors

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Photonics |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 210 |
| 作者 | Yong-Jie Wang, Lu-Cheng Peng, Julien Schreier, Yu Bi, A. Black, Aditya Malla, S. Goossens, G. Konstantatos |
| DOI | 10.1038/s41566-023-01345-3 |
| 源文件 | 021_Wang_2023_Silver-telluride-colloidal-quantum-dot-infrared.pdf |

---
# **Silver Telluride Colloidal Quantum Dot Infrared Photodetectors and Image Sensors** 

Yongjie Wang<sup>1</sup> , Lucheng Peng<sup>1</sup> , Julien Schreier<sup>2</sup> , Yu Bi<sup>2</sup> , Andres Black<sup>2</sup> , Aditya Malla<sup>1</sup> , Stijn Goossens<sup>2</sup> , Gerasimos Konstantatos<sup>1,3*</sup> 

1ICFO-Insitut de Ciencies Fotoniques, The Barcelona Institute of Science and Technology, Castelldefels, 08860 Barcelona, Spain. 

2 Qurv Technologies S.L., Castelldefels, 08860, Spain 

3ICREA-Institució Catalana de Recerca i Estudiats Avançats, Lluis Companys 23, 08010 Barcelona, Spain. 

*e-mail: Gerasimos.Konstantatos@icfo.eu 

**Photodetectors that are sensitive in shortwave infrared (SWIR) range (1 µm - 2 µm) are of significant interest for applications in 3D, night and adverse weather imaging, machine vision and autonomous driving, among others. Currently available technologies in the SWIR rely on costly epitaxial semiconductors that are not monolithically integrated with CMOS electronics. Solution-processed quantum dots can address this challenge by enabling low-cost manufacturing and simple monolithic integration on silicon in a backend-of-line (BEOL) process. To date, colloidal quantum dot (CQD) materials to access the SWIR are mostly based on lead sulfide (PbS) and mercury telluride (HgTe) compounds, imposing major regulatory concerns and impeding their deployment in consumer electronics due to toxicity concerns. Here we report a new synthesis method for environmentally-friendly silver telluride (Ag2Te) quantum dots and their application in high-performance SWIR photodetectors. The CQD photodetector stack employs materials compliant with the** **_Restriction of Hazardous Substance_ (RoHS) directives and is sensitive in the spectral range from 350 nm - 1600 nm. The room-temperature detectivity is of the order 10**<sup>**12**</sup> **Jones, the 3dB bandwidth is in excess of 0.1 MHz and the linear dynamic range is over 118 dB. We also realize a monolithically integrated SWIR imager** 

1 

# **based on solution processed, heavy-metal-free materials, thus paving the way of this technology to consumer electronics market.** 

Shortwave infrared (SWIR) light for sensing and imaging is of paramount importance owing to its unique characteristics: It is eye-safe; It can penetrate through fog, haze, and other atmospheric conditions, enabling imaging under adverse weather for automotive applications, environmental  and remote sensing;<sup>1–3</sup> the presence of night glow under night in the SWIR enables passive night vision;<sup>4</sup> visual imaging combined with infrared spectroscopy enables machine vision,<sup>3</sup> bio-imaging,<sup>5–8</sup> food and process quality inspection etc.<sup>9,10</sup> Of particular relevance in the SWIR is the band around 1.35 -1.4 µm that provides an eye-safe window, free of background light under day/night conditions enabling long-range LIDAR and 3D imaging for automotive and Augmented/Virtual Reality (AR/VR) applications.<sup>11</sup> 

In view of the huge market potential and the fact that established technologies to address the SWIR are based on highly costly and non-monolithic to silicon III-V technologies, significant efforts over the last 15 years have led to the demonstration of highly performing colloidal quantum dot photodetectors and image sensors.<sup>2,9,12–22</sup> However, to date, the available CQD materials to access the SWIR are based on heavy metals of Pb and Hg that are RoHS regulated elements and currently prohibited for use in consumer electronics. 

In this work we sought for a new heavy-metal free colloidal quantum dot semiconductor that would preserve the favorable properties of its heavy-metal counterparts in terms of broad bandgap tuneability and facile solution processing. We identified silver telluride quantum dots (Ag2Te CQDs), as promising contender and after a thorough literature review we realized that while Ag2Te CQDs have been synthesized and applied in bio-imaging applications as fluorophores in the near infrared and as a template to form efficient p-type doped HgTe CQD hole transporting layer  in HgTe QDs photodiodes,<sup>2,15,23–26</sup> its demonstration as highly 

2 

performant absorbers with tuneable and strong optical absorption akin to other colloidal quantum dot materials has remained elusive. So far, reported silver chalcogenide CQDs operate in photo-conductor mode featuring high dark current and low operating speed.<sup>24,27–32</sup> The only reported performance of Ag2Te QDs based photodiode showed an external quantum efficiency less than 0.5% in the near infrared region.<sup>33</sup> 

We posited that the origin of the challenge to achieve wide size tunability and thus broadband tunable optical properties, lies in the limited choice of tellurium precursors.<sup>26,34</sup> Up to now, the most widely used tellurium precursor has been tri-alkyl-phosphine-tellurium (R3P = Te), while phosphine has been suspected to adversely affect surface passivation, thereby the photoluminescence quantum yield.<sup>26</sup> At the same time, phosphine-based ligands are calculated to bind more strongly to Ag on the surface of QDs than thiols,<sup>26,35</sup> and are probably not an optimal ligand choice for CQDs that would need to undergo a ligand exchange process to render the films electrically conductive. 

# **Phosphine-free Ag2Te CQDs.** 

Various methods and precursors have been used to synthesize Ag2Te QDs under different reaction conditions.<sup>23,25,36,37</sup> However, achieving size tunability in these QDs has been challenging. Recently, large-sized Ag2Te QDs with a photoluminescence peak exceeding 2000 nm were obtained using phosphine-induced ripening.<sup>26</sup> Nevertheless, obtaining a decent excitonic absorption peak above 1500 nm remains elusive, indicating insufficient control over size uniformity.<sup>38</sup> This limitation leads to energetic disorder and hinders charge transport, thereby compromising the performance of optoelectronic devices.<sup>39–41</sup> Therefore, there is an urgent need to develop a synthetic method capable of producing monodisperse Ag2Te QDs with distinct excitonic peaks, which can be exploited in promising optoelectronic applications. 

3 

Herein, we introduce a phosphine-free tellurium precursor that led us obtain Ag2Te QDs with well-controlled size distribution and distinct excitonic peaks over a very broad range (800 nm to 2000 nm). Silver-oleylamine and tellurium-thiol complexes were used as precursors for hot injection, wherein tellurium oxide was reduced by thiols<sup>42</sup> and further reacted with silver precursors (Supplementary Note 1). Thanks to the absence of phosphine, Ag2Te QDs are stable in crude solution for hours under heating without showing Ostwald ripening, enabling us to easily tune sizes with controlled precursor supply. As shown in Fig. 1a, the absorption spectrum of Ag2Te QDs showed clear excitonic peaks, whose positions were controlled by reaction temperatures or continuous injection method (See Experimental Methods). The Ag2Te QDs showed compelling colloidal stability upon storing in air for two weeks (Supplementary Fig. 1). Intense photoluminescence was also observed under near infrared light excitation (Supplementary Fig. 2).  More importantly, we report here for the first time, Ag2Te QDs with distinct excitonic peaks (peak-valley ratio > 1.2) over 1500 nm, which has been a formidable obstacle for phosphine-based methods.<sup>26,34</sup> 

X-ray photoelectron spectroscopy was first employed to examine the material composition and stoichiometry as function of QD size (Supplementary Fig. 3). The Te to Ag ratio increases with the bandgap decreasing (size increasing), matching well with the calculated ratio of a cationrich surface configuration (Supplementary Fig. 3c&d). Transmission electron microscopy (TEM) images (Fig. 1b-k) confirmed the controllable and tunable QD sizing from less than 2.9 nm to over 6.6 nm, with regular spherical shapes. High resolution TEM (Fig. 1l) showed high quality single-crystal characteristics with an evident lattice spacing of 0.23 nm, with terminate facets being (2<sup>�</sup> 04), (211) and (210) (Supplementary Fig. 4). XRD patterns of various sizes Ag2Te QDs further confirmed the _Hessite_ crystal phase, matching well with the high resolution TEM images (Supplementary Fig. 5). Thanks to the wide size and consequent bandgap tunability, we were able to extract the sizing curve from TEM size distribution and absorption 

4 

spectra. The second derivatives of absorption spectra were used to extract the multiple excitonic peaks (Supplementary Fig. 6). The sizing curve was further fitted into equation:<sup>43</sup> 



<!-- Start of picture text -->
⎡ ⎤<br>⎢ − 𝑑𝑑 ⎥<br>2 ⎢ 𝑑𝑑0 ⎥<br>⎣ 𝑒𝑒 − 𝑑𝑑 ) 2 ⎦<br>𝐸𝐸𝑔𝑔 =  1 𝐸𝐸0 + �𝐸𝐸02 + 8𝐸𝐸0𝛼𝛼𝜋𝜋2 𝑅𝑅𝑦𝑦𝑎𝑎0<br>𝑑𝑑0<br>𝜀𝜀∞𝑑𝑑0<br>(1 + 𝑒𝑒<br><!-- End of picture text -->

where _Eg_ is the size dependent bandgap, _E0_ is the bulk bandgap, _Ry_ is the Rydberg energy (13.606 eV), _a0_ is he Bohr radius of hydrogen (0.053 nm), _α_ is a prefactor accounting the size dispersion (~0.7), _ε∞_ is the dielectric constant (here, ~16),<sup>44</sup> _d0_ is the exciton Bohr diameter, _d_ is the QD diameter.  By fitting the first excitonic peak with QD sizes (Fig. 1m), the exciton Bohr diameter was estimated to be ~10 nm, and the bulk bandgap _E0_ was ~0.53 eV. We note that there exist various reports of the bulk bandgap of Ag2Te with different values, which may stem from the various crystal phases and non-stoichiometry effects of this semiconductor compound.<sup>45–47</sup> We believe further investigations, including theoretical calculations, would provide more insights. 

# **Ag2Te CQDs SWIR photodiode.** 

Having obtained Ag2Te QDs with good monodispersity, we aimed to implement them into a low-temperature, solution-processed, non-toxic SWIR photodiode device that is compatible with complementary metal–oxide–semiconductor (CMOS) readout integrated circuits (ROICs). Ag2Te QDs photodiodes were initially fabricated with a configuration of ITO/SnO2/Ag2Te QDs/Au (Fig. 2a). However, devices showed poor rectification with high reverse bias dark current (Fig. 2c). Based on band positions from ultraviolet photoelectron spectroscopy (UPS, Supplementary Fig. 7), we suspected that the poor device performance originates from severe interface recombination between SnO2 and Ag2Te QDs (Fig. 2b) and therefore sought to introduce a buffer layer that would act as an intermediate electron acceptor offering lower carrier density and better band alignment than SnO2. We found that inserting a buffer layer of 

5 

AgBiS2 nanocrystals between SnO2 and Ag2Te QDs improves drastically the device diode quality, leading to a reduced reverse bias dark current density down to ~ 2 μA/cm<sup>2</sup> @ -0.1V and ~6 μA/cm<sup>2</sup> @ -0.5 V (Fig. 2c and Supplementary Fig. 8). Further diode analysis showed that devices without AgBiS2 NC interface layer have severe non-Ohmic leakage from interface recombination current and a very low dark current activation energy (Supplementary Note 2). In addition to dark current reduction, the external quantum efficiency (EQE) showed substantial improvement with AgBiS2 NCs buffer layer, together with a red-shift of EQE peak position, primarily due to optical Fabry-Perot cavity effect (Supplementary Fig. 9). The optimal photodiodes reached an EQE up to ~20% @1400 nm under 0 V bias (Fig. 2d) and 30% @-0.1 V (Supplementary Fig. 10), while the devices without AgBiS2 NCs showed peak EQE of only ~5%. In comparison, devices with phosphine based methods showed poor rectification and very low photo-responsivity (Supplementary Note 3), similar to previous reports,<sup>33</sup> further suggesting the superiority of our phosphine-free synthetic method. 

Considering its importance, device stability was assessed in terms of dark _JV_ curves and photoresponsivity. Un-encapsulated devices showed decent air stability maintaining original performance after 25 days’ air storage and 180 hours’ continuous operation under SWIR light (Supplementary Note 4). The linear dynamic range (LDR) of optimal Ag2Te QD photodiode was further evaluated by varying the incident light intensity. As shown in Fig. 3a, the photocurrent maintained linearity with incident light power over a broad range and LDR is estimated to be over 118 dB, which compares favorably over PbS or HgTe QDs based photodiodes.<sup>17,48</sup> Frequency dependent response was measured under zero bias, showing a - 3dB bandwidth up to 110 kHz (Fig. 3b), which is in accordance with the fast rise and decay times of 1.3 μs and 3.3 μs under modulated light excitation (Fig. 3b inset). Frequency dependent noise spectral density was further measured with fast Fourier Transform (FFT) current transients for low frequency and a lock-in amplifier for high frequency range (Supplementary 

6 

Fig. 11). The obtained noise spectrum showed a 1/f noise dominating at low frequency and a generation-recombination noise at high frequency. The device reaches a noise floor of ~10<sup>-14</sup> A Hz<sup>-0.5</sup> at frequencies over 20 kHz, which is comparable with many PbS QDs based photodiodes.<sup>17,49</sup> The measured room-temperature specific detectivity ( _D_<sup>_*_</sup> ) was thus calculated according to: 



<!-- Start of picture text -->
𝐷𝐷 ∗ =  𝑅𝑅 � 𝐴𝐴∆𝑓𝑓<br>𝑖𝑖𝑛𝑛<br><!-- End of picture text -->

where _A_ is the device area, _Δf_ is the noise bandwidth (1 Hz), _in_ being the noise spectral density. The frequency dependent _D_<sup>_*_</sup> reached over 10<sup>10</sup> _Jones_ at 1 Hz and a maximum of ~ 3 × 10<sup>12</sup> _Jones_ at 20 kHz (Supplementary Fig. 12). Moreover, the photodiode showed a _D_<sup>_*_</sup> over 10<sup>12</sup> _Jones_ across a very broad spectral range covering from 350 nm to 1500 nm (Fig. 3c). These results support the potential of Ag2Te CQD photodetectors in broadband SWIR imaging as well as machine vision applications. 

Furthermore, with the size tunability of Ag2Te QDs developed here, we further extended the spectral peak to 1500 nm by employing larger QDs. The devices with 1520 nm absorption peak QDs showed responsivity of over 0.1 A/W at 1500 nm, -3 dB bandwidth of 220 kHz, _D_<sup>_*_</sup> reaching 8.8 ×10<sup>11</sup> _Jones_ at 1500 nm (Supplementary Fig. 13). 

To the best of our knowledge, the photodiode devices reported here realized, for the first time, solution-processed, non-toxic shortwave infrared photodiodes with figures of merit on par with other heavy-metal containing counterparts (Fig. 3d). These results further support the fact that Ag2Te QDs emerges as a promising RoHS-compliant material for low-cost, high performance SWIR photodetector applications. 

# **Ag2Te CQDs SWIR imager.** 

7 

Having developed a heavy-metal-free CQD photodetector, we were then motivated to demonstrate its proof-of-concept potential in a SWIR image sensor use case. Prior to direct integration onto a read-out-integrated circuit (ROIC) we sought to optimize and evaluate its performance in a top-illuminated configuration on a mimic ITO-coated glass substrate (Fig. 4a) using patterned gold as bottom electrodes and 10 nm thin Au as a top semi-transparent electrode. The top-illuminated photodiode exhibited rectification characteristics under dark, albeit inferior to that of the bottom-illuminated devices. Due to the use of ultra-thin Au as a top electrode, forward bias larger than 0.1V led to device damage, preventing us to apply larger forward bias. The detector reaches an EQE ~9% at 1200 nm in short-circuit conditions, further increasing with reverse bias (Fig. 4b). Sputtered ITO was also tried to replace Au as top electrodes, however the devices showed very low responsivity (Supplementary Fig. 14), presumably due to the damage on Ag2Te QDs upon ITO sputtering.<sup>17</sup> 

We thus employed Au-top-electrode-based stack for an image sensor by integrating it on a read-out-integrated circuit (ROIC) to form a focal plane array (FPA) (see methods for details). Fig. 4d illustrates a schematic of the Ag2Te CQD image sensor. Fig 4e illustrates the fabricated die in the electronic printed circuit board enclosure and Fig. 4f shows a zoomed-in photo of the die comprising the QD stack atop the ROIC. The performance of our Ag2Te CQD imager was briefly evaluated with printed ISO-12233 test chart and USAF Resolution Target (Supplementary Note 5). Fig. 4g-i illustrate a few examples of images taken using this imager under SWIR light exposure (detecting range 900 nm – ~1600 nm) along with photos taken with a standard mobile phone silicon-based camera. The figures show the transmission of silicon wafers under SWIR light as well as the possibility to visualize the content of plastic bottles that are opaque in the visible. The image sensor performance is envisioned to be further improved building upon recent progress on high quality image sensors reported based on Pb- and Hgbased CQDs<sup>17,20–22</sup> . 

8 

# **Conclusion.** 

In conclusion, we have first developed a novel synthetic method for size-tunable, phosphinefree Ag2Te quantum dots. Photodiodes based on these Ag2Te QDs further demonstrate compelling performance in shortwave infrared region with wide linear dynamic range over 118 dB, -3 dB bandwidth over 110 kHz, and a high room-temperature specific detectivity over 3×10<sup>12</sup> _Jones_ . We further employed heterogeneous monolithic integration of Ag2Te CQD photodiodes onto Silicon ROICs to demonstrate for the first time a non-toxic, solutionprocessed SWIR imager operating at room temperature. The results reported here not only circumvent prior challenges in the synthesis of size-tunable, phosphine-free Ag2Te QDs, but also unleash their potential as a novel RoHS-compliant infrared size-tuneable optoelectronic material. Finally, our work paves the way for the introduction of SWIR colloidal quantum dot technology in consumer electronics markets. 

# **Acknowledgements.** 

G.K. acknowledges financial support from the European Research Council (ERC) under the European Union’s Horizon 2020 research and innovation programme (grant agreement No 101002306), the Fundació Joan Ribas Araquistain (FJRA), the Fundació Privada Cellex, the program CERCA, and ‘Severo Ochoa’ Centre of Excellence CEX2019-000910-S funded by the Spanish State Research Agency. Y.W. acknowledges support from the European Union’s Horizon 2020 research and innovation programme under the Marie Skłodowska-Curie grant agreement no. 754558. L.P. acknowledges support from the Horizon Europe Framework Programme, the Marie Skłodowska-Curie Postdoctoral Fellowships (grant agreement no.101052595). S.G. acknowledges support from the Horizon – EIC action under the grant agreement no. 101113088 – QSTACK. We would like to thank Yurong Ren, Dr. Debranjan 

9 

Mandal for their help during metal electrodes deposition and Dr. Timofiy Khodkov for supplying the diced chips for the imager. 

# **Author contributions.** 

G.K. supervised and directed the study. Y.W. and G.K. conceived the idea, designed this study and co-wrote the manuscript, with feedback from the co-authors. Y.W. synthesized the materials, performed the material characterization, fabricated and characterized the devices, and analyzed the data. L.P. contributed to the development and synthesis of the material. Y.W. fabricated the image sensor with the help of A.B. and Y.B. Y.B. contributed to the design of experiment for the integration of QD film onto the ROIC. J.S. performed the characterization of the image sensor and took the images. Y.W. and J.S. did the performance analysis of the imagers. A. M. contributed to the device fabrication. S.G. contributed in the supervision and design of experiments for the image sensor demonstration. 

# **Competing interests.** 

G.K and Y.W. have filed patent application. G.K. serves as co-founder, share-holder and scientific advisor at Qurv. J.S. and A.B. are employees of Qurv. S.G. is shareholder and employee of Qurv. The remaining authors declare no competing interests. 

10 

# **FIGURES** 

**Fig. 1 | Size-tunable Ag2Te QDs. a** , Absorption spectra of various-sized Ag2Te QDs. Transmission electron microscope (TEM) images of Ag2Te QDs with absorption peak at **b** , 1310 nm, **d** , 1430 nm, **f** , 1520 nm, **h** , 1750 nm, **j** , 1940 nm, and **c** , **e** , **g** , **i** , **k** their size distribution histograms ( _n_ = ( **c** ) 90, ( **e** ) 117, ( **g** ) 179, ( **i** ) 123, ( **k** ) 288), respectively. Scale bars are 20 nm in **b** , **d** , **f** , **h** , and **j** . TEM sample grids, except the 1940 nm one, were immersed in methanol to remove organic residues for better resolution. **l** , High resolution TEM image of a single QD, showing single crystalline features. Scale bars are 2 nm in both **l** and the inset. **m** , Sizing curve of Ag2Te QDs from absorption peak positions and TEM size distribution. Dash line indicates the fitting line of first exciton peaks. Error bars indicates the standard deviation of sizes (from **c** , **e** , **g** , **i** , **k** ) and full width half maximum (FWHM) of absorption peaks. 

**Fig. 2 | Ag2Te QD Shortwave infrared photodiode. a** , Schematics of Ag2Te QD photodiodes, with and without AgBiS2 NCs buffer layer. **b** , Band diagram of photodiode device. **c** , Dark current density-voltage ( _J-V_ ) curves of photodiodes with and without buffer layer. **d** , External quantum efficiency (EQE) spectrum and responsivity ( _R_ ) of Ag2Te QD photodiode with and without AgBiS2 NCs buffer layer. 

**Fig. 3 | Performance of Ag2Te QD photodiode. a** , Linear dynamic range (LDR) of Ag2Te QD photodiode under 1310 nm pulse light illumination with power densities from ~10 nW/cm<sup>2</sup> to ~10mW/cm<sup>2</sup> . **b** . Response bandwidth of Ag2Te QD photodiode. **c** . Specific detectivity spectrum at 20 kHz. **d** . Wavelength dependent specific detectivity of shortwave infrared photodiodes reported in literature.<sup>17,48–55</sup> 

11 

**Fig. 4 | Top-illuminated Ag2Te QD photodetector and imager. a** , Schematic of topilluminated Ag2Te QD photodetector. **b.** Current density-voltage curves under dark and 0.7 mW/cm<sup>2</sup> 1200 nm light illumination **. c.** EQE spectrum of top-illuminated device. **d** . Schematic of ROIC integrated Ag2Te QDs SWIR imager. **e** . Photo of the imager and **f** zoom in of the ROIC die. **g** . Photos of a silicon wafer on ICFO logo with smartphone visible camera and Ag2Te QD SWIR camera. **h** . photos of hand holding silicon wafer with visible camera and Ag2Te QD SWIR camera. **i** . Photos of a dark bottle with liquid using smartphone visible camera and Ag2Te QD SWIR camera. 

12 

# **References** 

1. Guan, X. _et al._ Recent Progress in Short- to Long-Wave Infrared Photodetection Using 2D Materials and Heterostructures. _Adv. Opt. Mater._ **9** , 2001708 (2021). 

2. Tang, X., Ackerman, M. M., Chen, M. & Guyot-Sionnest, P. Dual-band infrared imaging using stacked colloidal quantum dot photodiodes. _Nat. Photonics_ **13** , 277–282 (2019). 

3. Saran, R. & Curry, R. J. Lead sulphide nanocrystal photodetector technologies. _Nat. Photonics_ **10** , 81–92 (2016). 

4. Uwe Adomeit & Jürgen Krieg. Shortwave infrared for night vision applications: illumination levels and sensor performance. in vol. 9641 964104 (2015). 

5. Wu, Z., Zhai, Y., Kim, H., Azoulay, J. D. & Ng, T. N. Emerging Design and Characterization Guidelines for Polymer-Based Infrared Photodetectors. _Acc. Chem. Res._ **51** , 3144–3153 (2018). 

6. Naczynski, D. J. _et al._ Rare-earth-doped biological composites as in vivo shortwave infrared reporters. _Nat. Commun._ **4** , 2199 (2013). 

7. Cosco, E. D. _et al._ Shortwave infrared polymethine fluorophores matched to excitation lasers enable non-invasive, multicolour in vivo imaging in real time. _Nat. Chem._ **12** , 1123–1130 (2020). 

8. Bruns, O. T. _et al._ Next-generation in vivo optical imaging with short-wave infrared quantum dots. _Nat. Biomed. Eng._ **1** , 0056 (2017). 

9. Konstantatos, G. & Sargent, E. H. Nanostructured materials for photon detection. _Nat. Nanotechnol._ **5** , 391–400 (2010). 

10. García de Arquer, F. P., Armin, A., Meredith, P. & Sargent, E. H. Solution-processed semiconductors for next-generation photodetectors. _Nat. Rev. Mater._ **2** , 16100 (2017). 

11. Goossens, S., Konstantatos, G. & Oikonomou, A. Colloidal Quantum Dot Image Sensors: Technology and Marketplace Opportunities. _Inf. Disp._ **37** , 18–23 (2021). 

12. Konstantatos, G. _et al._ Ultrasensitive solution-cast quantum dot photodetectors. _Nature_ **442** , 180– 183 (2006). 

13. McDonald, S. A. _et al._ Solution-processed PbS quantum dot infrared photodetectors and photovoltaics. _Nat. Mater._ **4** , 138–142 (2005). 

13 

14. Keuleyan, S., Lhuillier, E., Brajuskovic, V. & Guyot-Sionnest, P. Mid-infrared HgTe colloidal quantum dot photodetectors. _Nat. Photonics_ **5** , 489–493 (2011). 

15. Ackerman, M. M., Tang, X. & Guyot-Sionnest, P. Fast and Sensitive Colloidal Quantum Dot Mid-Wave Infrared Photodetectors. _ACS Nano_ **12** , 7264–7271 (2018). 

16. Zhang, H. _et al._ Material Perspective on HgTe Nanocrystal-Based Short-Wave Infrared Focal Plane Arrays. _Chem. Mater._ acs.chemmater.2c02955 (2022) 

doi:10.1021/acs.chemmater.2c02955. 

17. Liu, J. _et al._ A near-infrared colloidal quantum dot imager with monolithically integrated readout circuitry. _Nat. Electron._ 1–9 (2022) doi:10.1038/s41928-022-00779-x. 

18. Goossens, S. _et al._ Broadband image sensor array based on graphene–CMOS integration. _Nat. Photonics_ **11** , 366–371 (2017). 

19. Livache, C. _et al._ A colloidal quantum dot infrared photodetector and its use for intraband detection. _Nat. Commun._ **10** , 2125 (2019). 

20. Luo, Y. _et al._ Megapixel large-format colloidal quantum-dot infrared imagers with resonantcavity enhanced photoresponse. _APL Photonics_ **8** , 056109 (2023). 

21. Zhang, S. _et al._ Direct Optical Lithography Enabled Multispectral Colloidal Quantum-Dot Imagers from Ultraviolet to Short-Wave Infrared. _ACS Nano_ **16** , 18822–18829 (2022). 

22. Zhang, S. _et al._ Wafer-Scale Fabrication of CMOS-Compatible Trapping-Mode Infrared Imagers with Colloidal Quantum Dots. _ACS Photonics_ **10** , 673–682 (2023). 

23. Yang, H. _et al._ Au-Doped Ag2Te Quantum Dots with Bright NIR-IIb Fluorescence for In Situ Monitoring of Angiogenesis and Arteriogenesis in a Hindlimb Ischemic Model. _Adv. Mater._ **n/a** , 2103953. 

24. Zhang, Y. _et al._ Controlled Synthesis of Ag2Te@Ag2S Core–Shell Quantum Dots with Enhanced and Tunable Fluorescence in the Second Near-Infrared Window. _Small_ **16** , 2001003 (2020). 

25. Chen, C., He, X., Gao, L. & Ma, N. Cation Exchange-Based Facile Aqueous Synthesis of Small, Stable, and Nontoxic Near-Infrared Ag 2 Te/ZnS Core/Shell Quantum Dots Emitting in the Second Biological Window. _ACS Appl. Mater. Interfaces_ **5** , 1149–1155 (2013). 

14 

26. Liu, Z.-Y. _et al._ Breaking through the Size Control Dilemma of Silver Chalcogenide Quantum Dots via Trialkylphosphine-Induced Ripening: Leading to Ag 2 Te Emitting from 950 to 2100 nm. _J. Am. Chem. Soc._ jacs.1c06661 (2021) doi:10.1021/jacs.1c06661. 

27. Hafiz, S. B. _et al._ Silver Selenide Colloidal Quantum Dots for Mid-Wavelength Infrared Photodetection. _ACS Appl. Nano Mater._ **2** , 1631–1636 (2019). 

28. Hafiz, S. B., Al Mahfuz, M. M. & Ko, D.-K. Vertically Stacked Intraband Quantum Dot Devices for Mid-Wavelength Infrared Photodetection. _ACS Appl. Mater. Interfaces_ **13** , 937–943 (2021). 

29. Liu, Y.-W. _et al._ Near-Infrared Absorption of Monodisperse Silver Telluride (Ag 2 Te) Nanocrystals and Photoconductive Response of Their Self-Assembled Superlattices. _Chem. Mater._ **23** , 4657–4659 (2011). 

30. Lee, W.-Y. _et al._ Room-Temperature High-Detectivity Flexible Near-Infrared Photodetectors with Chalcogenide Silver Telluride Nanoparticles. _ACS Omega_ **7** , 10262–10267 (2022). 

31. Sahu, A., Qi, L., Kang, M. S., Deng, D. & Norris, D. J. Facile Synthesis of Silver Chalcogenide (Ag 2 E; E = Se, S, Te) Semiconductor Nanocrystals. _J. Am. Chem. Soc._ **133** , 6509–6512 (2011). 

32. Scimeca, M. R. _et al._ Origin of Intraband Optical Transitions in Ag 2 Se Colloidal Quantum Dots. _J. Phys. Chem. C_ **125** , 17556–17564 (2021). 

33. Ouyang, J. _et al._ Ag 2 Te Colloidal Quantum Dots for Near-Infrared-II Photodetectors. _ACS Appl. Nano Mater._ **4** , 13587–13601 (2021). 

34. Zhang, M.-Y. _et al._ Regulation of Silver Precursor Reactivity via Tertiary Phosphine to Synthesize Near-Infrared Ag 2 Te with Photoluminescence Quantum Yield of up to 14.7%. _Chem. Mater._ acs.chemmater.1c02610 (2021) doi:10.1021/acs.chemmater.1c02610. 

35. Chen, H. _et al._ Regulating surface potential maximizes voltage in all-perovskite tandems. _Nature_ (2022) doi:10.1038/s41586-022-05541-z. 

36. Shi, X.-H., Dai, Y.-Y., Wang, L., Wang, Z.-G. & Liu, S.-L. Water-Soluble High-Quality Ag 2 Te Quantum Dots Prepared by Mutual Adaptation of Synthesis and Surface Modification for In Vivo Imaging. _ACS Appl. Bio Mater._ **4** , 7692–7700 (2021). 

15 

37. Yarema, M. _et al._ Infrared Emitting and Photoconducting Colloidal Silver Chalcogenide Nanocrystal Quantum Dots from a Silylamide-Promoted Synthesis. _ACS Nano_ **5** , 3758–3765 (2011). 

38. Wu, W., Schulman, J. N., Hsu, T. Y. & Efron, U. Effect of size nonuniformity on the absorption spectrum of a semiconductor quantum dot system. _Appl. Phys. Lett._ **51** , 710–712 (1987). 

39. Liu, M. _et al._ Hybrid organic–inorganic inks flatten the energy landscape in colloidal quantum dot solids. _Nat. Mater._ **16** , 258–263 (2017). 

40. Gilmore, R. H., Lee, E. M. Y., Weidman, M. C., Willard, A. P. & Tisdale, W. A. Charge Carrier Hopping Dynamics in Homogeneously Broadened PbS Quantum Dot Solids. _Nano Lett._ **17** , 893– 901 (2017). 

41. Kagan, C. R. & Murray, C. B. Charge transport in strongly coupled quantum dot solids. _Nat. Nanotechnol._ **10** , 1013–1026 (2015). 

42. Stürzenbaum, S. _et al._ Biosynthesis of luminescent quantum dots in an earthworm. _Nat. Nanotechnol._ **8** , (2012). 

43. Aubert, T. _et al._ General Expression for the Size-Dependent Optical Properties of Quantum Dots. _Nano Lett._ **22** , 1778–1785 (2022). 

44. Rodenkirchen, C. _et al._ Employing Interfaces with Metavalently Bonded Materials for Phonon Scattering and Control of the Thermal Conductivity in TAGS-x Thermoelectric Materials. _Adv. Funct. Mater._ **30** , 1910039 (2020). 

45. Lee, M., Rosenbaum, T. F., Saboungi, M.-L. & Schnyders, H. S. Band-Gap Tuning and Linear Magnetoresistance in the Silver Chalcogenides. _Phys. Rev. Lett._ **88** , 066602 (2002). 

46. Pei, Y., Heinz, N. A. & Snyder, G. J. Alloying to increase the band gap for improving thermoelectric properties of Ag2Te. _J. Mater. Chem._ **21** , 18256 (2011). 

47. Das, V. D. & Karunakaran, D. Semiconducting behavior of Ag 2 Te thin films and the dependence of band gap on thickness. _J. Appl. Phys._ **54** , 5252–5255 (1983). 

48. Yang, J. _et al._ Ligand-Engineered HgTe Colloidal Quantum Dot Solids for Infrared Photodetectors. _Nano Lett._ acs.nanolett.2c00950 (2022) doi:10.1021/acs.nanolett.2c00950. 

16 

49. Chen, D. _et al._ Passivating 100 Facets of PbS Colloidal Quantum Dots via Perovskite Bridges for Sensitive and Stable Infrared Photodiodes. _Adv. Funct. Mater._ **n/a** , 2210158. 

50. Sun, B. _et al._ Fast Near-Infrared Photodetection Using III–V Colloidal Quantum Dots. _Adv. Mater._ **34** , 2203039 (2022). 

51. Leemans, J. _et al._ Colloidal III–V Quantum Dot Photodiodes for Short-Wave Infrared Photodetection. _Adv. Sci._ **9** , 2200844 (2022). 

52. Vafaie, M. _et al._ Colloidal quantum dot photodetectors with 10-ns response time and 80% quantum efficiency at 1,550 nm. _Matter_ **4** , 1042–1053 (2021). 

53. Biondi, M. _et al._ Facet-Oriented Coupling Enables Fast and Sensitive Colloidal Quantum Dot Photodetectors. _Adv. Mater._ **n/a** , 2101056 (2021). 

54. Zhang, Y. _et al._ Electron Transport Layers Employing Strongly-Bound Ligands Enhance Stability in Colloidal Quantum Dot Infrared Photodetectors. _Adv. Mater._ **n/a** , 2206884 (2022). 

55. Lu, S. _et al._ High-Performance Colloidal Quantum Dot Photodiodes via Suppressing Interface Defects. _ACS Appl. Mater. Interfaces_ **15** , 12061–12069 (2023). 

# **Methods** 

**Chemicals.** Reagents were purchased from Sigma-Aldrich, except Tellurim (IV) oxide, which is from Thermo Fisher. 

**Synthesis of AgBiS2 nanocrystals.** The synthesis of AgBiS2 nanocrystals followed previous reports.<sup>56,57</sup> Briefly, silver acetate (3.2 mmol) and bismuth acetate (4 mmol) were loaded into a flask together with 24 mL oleic acid and 15 mL 1-octadecene. The flask was then pumped under 100 °C to reach a pressure < 0.2 mbar. 4 mmol hexamethyldisilathiane with 5 ml predried 1-octadecene was quickly injected into the flask after switching the flask into Argon atmosphere. The heating was then stopped and the reaction was quenched by water bath. The nanocrystals were purified with acetone for three times and finally dissolved in anhydrous toluene for further use. 

17 

**Synthesis of Ag2Te quantum dots.** Ag2Te QDs are synthesized with Schlenk line technique from silver iodide-oleylamine (AgI-OLAm) and Tellurium Oxide-dodecanethiol (TeO2-DDT) precursors. Typically, 30 mL oleylamine (OLAm) and 15 mL 1-octadecene (ODE) were loaded into a three-neck flask and pumped at 100°C to remove oxygen and moisture. The flask was then switched into argon atmosphere. 

_AgI-OLAm precursor_ : silver precursor was prepared by dissolving 10 mmol silver iodide into 10 mL pre-dried OLAm at room temperature under inert atmosphere. Slight heating would facilitate the dissolution process. 

_TeO2-DDT precursor_ : tellurium precursor was prepared by dissolving 2.5 mmol tellurium oxide (TeO2) into 10 mL dodecanethiol (DDT) under 100 °C heating and inert atmosphere. 

The flask containing OLAm and ODE was then heated up to desired temperatures for different size of QDs. Once the temperature reached set point. 3 mL AgI-OLAm precursor was added into the flask. After ~5 min, 5 mL TeO2-DDT precursor was injected into the flask swiftly. The precursor changed into dark black color immediately, indicating the nucleation of Ag2Te QDs. After 15 min, the heating was stopped and left cooling down naturally. The crude solution was then transferred into inert gas filled glovebox for purification. Methanol was added into the crude solution to precipitate the QDs, followed by 6000 revolutions per minute for 5 min centrifuge. The solid pellet was then fully dispersed into ~30 mL toluene. 3 mL AgI-OLAm precursor was then added into the QD solution, followed by 6000 revolutions per minute centrifuge to remove any precipitates. ~15 mL methanol was added into the supernatant, followed by centrifuge again. The precipitate was discarded and the supernatant, where the QDs are, was kept. ~30 mL methanol was further added into the solution to fully precipitate the QDs, followed by centrifuge. Finally, the solid pellet was collected and the supernatant was 

18 

discarded. The QD solid was dissolved into anhydrous toluene at various concentration for further characterization and device fabrication. 

For the synthesis of large (> 1600 nm) Ag2Te QDs, continuous injection and growth method was used. Briefly, after injecting 3 mL AgI-OLAm and 5 mL TeO2-DDT precursor at 140 °C, the flask was maintained at this temperature. 1 mL AgI-OLAm and 1.8 mL TeO2-DDT precursor was added dropwise and sequentially with a syringe pump at ~0.05 mL/min. Multiple cycles were executed according to desired sizes. The purification followed the same procedure as previously described for smaller dots. 

**Characterization of Ag2Te QDs.** UV-vis absorption measurements were performed with a Cary 5000 UV-Vis-NIR spectroscope in solution. For photoluminescence measurements, four channel Thorlabs laser was used as excitation light and a Kymera 328i spectrograph (Oxford Instruments, Andor) was used as the detector ( < 1600 nm). The XRD data were collected using a Rigaku SmartLab powder diffractometer in the Bragg–Brentano geometry with Cu Kα radiation on drop-casted powder samples. TEM was performed at the Scientific and Technological Centres of the University of Barcelona. The TEM images were obtained using a JEOL 2100 microscope operating at an accelerating voltage of 200 kV. TEM samples were prepared by dropping diluted QD solution on ultrathin carbon grids, followed by immersing into pure methanol to remove organics for higher resolution. The XPS/UPS measurements were performed with a SPECS PHOIBOS 150 hemispherical analyser under ultrahigh-vacuum conditions (10<sup>−10</sup> mbar) at the Institut Català de Nanociència i Nanotecnologia. 

**Device fabrication.** All the device fabrication steps were carried out in ambient air. ITOcovered glass substrates (Universität Stuttgart, Institut für Großflächige Mikroelektronik) were cleaned by sonication in soapy water, acetone and isopropanol for 20 min each and dried with nitrogen, followed with 0.5 h ultraviolet/ozone treatment. SnO2 electron transport layer was 

19 

then deposited with an ALD technique at 150 °C to achieve a thickness of ~20 nm. Two layers of AgBiS2 NCs were further spin-coated from 20 mg ml<sup>−1</sup> toluene solution via the layer-bylayer method. For each AgBiS2 NC layer, one drop of AgBiS2 NC solution was spin coated onto SnO2/ITO substrates during spinning (2,000 r.p.m.). Then, 1,2-ethanedithiol (EDT)/acetonitrile (ACN) (0.1% v/v) solution was applied to the NC film for 20 s, followed by two rinse–spin steps with acetonitrile and once with toluene. Five layers (~100 nm) of Ag2Te QDs were further deposited on top of AgBiS2 NCs. For each Ag2Te QD layer, 50 mg mL<sup>-1</sup> QD solution was spin-coated at 3000 r.p.m. and ligand-exchanged with EDT/ACN (0.1%) for 30 s, followed by rinse twice with ACN and once with toluene. The films were completed by annealing in air for 10 min at 100 °C. Finally, a Kurt J. Lesker NANO 36 system was used to deposit 100 nm Au as top electrode with a device area of 3.1 mm<sup>2</sup> . For top-illuminated devices, 5 nm Ti and 50 nm Au were deposited onto glass substrates using shade masks to have 1 mm wide stripes. 25 nm SnO2 was deposited by ALD technique, followed by 40 nm AgBiS2 nanocrystal layer and 60 nm Ag2Te QD layer. 10 nm thin Au was further deposited as top semitransparent electrode with 1 mm stripe shade mask to define a device area as 1 mm<sup>2</sup> . For imager, we used a global shutter ROIC with a resolution of 640 x 480 pixels that is read-out in an integrate then read (ITR) fashion. The ROIC features two gain modes and programmable detector bias. The in-pixel amplifier is a capacitive trans-impedance amplifier (CTIA).  Kapton tape was used to isolate peripheral electrode pads from the detector stack that comprised: 25 nm ALD-SnO2, 40 nm AgBiS2 NCs, 60 nm Ag2Te QDs and 10 nm thin Au as top electrode. 

**Device characterization.** All the device characterizations were performed in air under ambient conditions. Current-voltage (I-V) measurements were performed with a Keysight Semiconductor Parameter Analyzer (B1500A) with the devices kept in a shield box. The EQE was measured using a Newport Cornerstone 260 monochromator, a Thorlabs MC2000 chopper, a Stanford Research SR570 transimpedance amplifier and a Stanford Research SR830 lock-in 

20 

amplifier. Calibrated Newport 818-UV and 818-IR photodetectors were used as the reference. For the noise measurements, devices were kept in a dark, shielded enclosure at room temperature under zero bias and directly connected with Stanford Research SR830 lock-in amplifier using its noise measurement function, following many other previous reports.<sup>12,17,49,58–63</sup> In order to measure the 3dB bandwidth, nanosecond laser (520 nm) was used as incident light, which was modulated by a waveform generator (Agilent 33220A) at various frequencies with 50% duty cycle. The output current was recorded with an oscilloscope. For linear dynamic range measurements, four-channel laser (Thorlabs) at 1310 nm was used as light source at a frequency of 7 Hz modulated by Agilent waveform generator. The light was directed by a beam-splitter to a Newport 818-IG detector and the device. The current was amplified by an SR570 amplifiers and recorded by an oscilloscope. 

For image capture we used a Tungsten halogen lamp (1000W - 60° beam angle), placed at a distance of ~2m from the objects. The QD image sensor captured images of the objects at a distance of 1 – 1.5 m using a SWIR objective lens (VS-0814H1-SWIR) with a bandpass of 900 – 2000 nm. In addition to the sensitive range of the photodiode of 350nm to 1600nm, the imager captures the light from 350nm to 1600nm. The integration time was set at 10 ms and the applied revers bias of the pixels was 0.2 V.  Due to the Kapton tape induced edge effects, the images were cropped into 510×365 pixel resolution with ~100% effective pixel rate. Further optimization on etching process would lead to full VGA resolution. 

# **Data availability.** 

All data that support the findings of this work are shown in the main text and Supplementary Information. Source data are provided with this paper. 

21 

# **References** 

56. Wang, Y. _et al._ Cation disorder engineering yields AgBiS2 nanocrystals with enhanced optical absorption for efficient ultrathin solar cells. _Nat. Photonics_ **16** , 235–241 (2022). 

57. Wang, Y., Peng, L., Wang, Z. & Konstantatos, G. Environmentally Friendly AgBiS 2 Nanocrystal Inks for Efficient Solar Cells Employing Green Solvent Processing. _Adv. Energy Mater._ **12** , 2200700 (2022). 

58. Clifford, J. P. _et al._ Fast, sensitive and spectrally tuneable colloidal-quantum-dot photodetectors. _Nat. Nanotechnol._ **4** , 40–44 (2009). 

59. Bao, C. _et al._ Low-Noise and Large-Linear-Dynamic-Range Photodetectors Based on HybridPerovskite Thin-Single-Crystals. _Adv. Mater._ **29** , 1703209 (2017). 

60. Dou, L. _et al._ Solution-processed hybrid perovskite photodetectors with high detectivity. _Nat. Commun._ **5** , 5404 (2014). 

61. García de Arquer, F. P. _et al._ Field-emission from quantum-dot-in-perovskite solids. _Nat. Commun._ **8** , 14757 (2017). 

62. Guo, F. _et al._ A nanocomposite ultraviolet photodetector based on interfacial trap-controlled charge injection. _Nat. Nanotechnol._ **7** , 798–802 (2012). 

63. Feng, J. _et al._ Single-crystalline layered metal-halide perovskite nanowires for ultrasensitive photodetectors. _Nat. Electron._ **1** , 404–410 (2018). 

22 

