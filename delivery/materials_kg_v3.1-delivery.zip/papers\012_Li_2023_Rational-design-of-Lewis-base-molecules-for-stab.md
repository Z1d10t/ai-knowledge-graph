# Rational design of Lewis base molecules for stable and efficient inverted perovskite solar cells

| 字段 | 内容 |
|---|---|
| 期刊 | Science |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 544 |
| 作者 | Chong-Wen Li, Xiao-Ming Wang, Enbing Bi, Fang-Yuan Jiang, So Min Park, You Li, Lei Chen, Zai-Wei Wang et al. |
| DOI | 10.1126/science.ade3970 |
| 源文件 | 012_Li_2023_Rational-design-of-Lewis-base-molecules-for-stab.pdf |

---
9 

10 

11 

12 

13 

14 

15 

16 

17 

18 

19 

20 

21 

22 

# 1 **Rational design of Lewis base molecules for stable and efficient inverted** 2 **perovskite solar cells** 

- 3 

- 4 **Authors:** Chongwen Li<sup>1</sup> , Xiaoming Wang<sup>1</sup> , Enbing Bi<sup>1</sup> , Fangyuan Jiang<sup>2</sup> , So Min Park<sup>3</sup> , You 

- 5 Li<sup>1</sup> , Lei Chen<sup>1</sup> , Zaiwei Wang<sup>3</sup> , Lewei Zeng<sup>3</sup> , Hao Chen<sup>3</sup> , Yanjiang Liu<sup>3</sup> , Corey R. Grice<sup>1,4</sup> , Abasi 

- 6 Abudulimu<sup>1</sup> , Jaehoon Chung<sup>1</sup> , Yeming Xian<sup>1</sup> , Tao Zhu<sup>1</sup> , Huagui Lai<sup>5</sup> , Bin Chen<sup>3,6</sup> , Randy J. 7 Ellingson<sup>1</sup> , Fan Fu<sup>5</sup> , David S. Ginger<sup>2</sup> , Zhaoning Song<sup>1</sup> , Edward H. Sargent<sup>3,6,7</sup> , Yanfa Yan<sup>1*</sup> 

8 

## **Affiliations:** 

- 1Department of Physics and Astronomy and Wright Center for Photovoltaics Innovation and Commercialization, The University of Toledo, Toledo, Ohio 43606, United States. 

- 2Department of Chemistry, University of Washington, Seattle, Washington 98195, United States 

- 3The Edward S. Rogers Department of Electrical and Computer Engineering, University of Toronto, Toronto, Ontario M5S 3G4, Canada 

- 4Center for Materials and Sensors Characterization, The University of Toledo, Toledo, Ohio 43606, United States. 



<!-- Start of picture text -->
23<br><!-- End of picture text -->

- 5Laboratory for Thin Films and Photovoltaics, Empa–Swiss Federal Laboratories for Materials Science and Technology, Duebendorf 8600, Switzerland. 

24 

- 25 6Department of Chemistry, Northwestern University, Evanston, Illinois 60208, United States. 



<!-- Start of picture text -->
26<br><!-- End of picture text -->

- 27 7Department of Electrical and Computer Engineering, Northwestern University, Evanston, 28 Illinois 60208, United States. 

- 29 

- 30 *Corresponding author. Email: yanfa.yan@utoledo.edu 

1 

- 31 **Abstract:** Lewis-base molecules that bind undercoordinated Pb atoms at interfaces and grain 32 boundaries (GBs) are known to enhance the durability of metal halide perovskite solar cells 33 (PSCs). Using density functional theory calculations, we found that phosphine (P)-containing 

- 34 molecules have the strongest binding energy among members of a library of Lewis base 

- 35 molecules studied herein. Experimentally, we found that the best inverted PSC treated using 1,336 bis(diphenylphosphino)propane (DPPP), a diphosphine Lewis base which passivates, binds, and 37 bridges interfaces and GBs, retained a power conversion efficiency (PCE) slightly higher than its 38 initial PCE of ~23% following continuous operation under simulated AM1.5 illumination at the 

- 39 maximum power point and at ~40°C for >3,500 hours. DPPP-treated devices showed a similar 40 increase in PCE after being kept at open-circuit and at 85 Celsius for >1,500 hours. 

- 41 

- 42 **One-Sentence Summary:** The Lewis base molecule DPPP enables inverted perovskite solar cells 

- 43 with superior stability under both operating and open circuit accelerated ageing conditions. 

2 

55 

56 

57 

58 

59 

60 

61 

62 

63 

64 

65 

## 44 **Main Text:** 

45 Metal halide perovskite solar cells (PSCs) offer a route to lowering the cost of solar electricity 46 given their high power conversion efficiencies (PCEs) ( _1-4_ ). However, durability remains a major 47 hurdle along the path to technological relevance ( _5-7_ ) and must be assessed through accelerated 48 degradation tests ( _8_ ). Damp-heat testing at 85°C in dark and 85% relative humidity (RH), a test 49 standard for crystalline silicon (Si) and thin-film PV modules, has been adopted for accelerating 50 the durability test of PSCs ( _9 - 11_ ). These tests are typically used to evaluate packaging rather than 51 PV material durability. PSCs can also show degradation under photoexcited conditions ( _12_ ), and 52 especially at open-circuit (OC) conditions ( _13_ ), that are more acute than one sees in standardized 53 silicon tests. Mechanistically, such this findings are often assigned to ion migration ( _14, 15_ ) and 54 charge accumulation at interfaces ( _9, 16,17_ ). 

We studied the operating stability at 85<sup>o</sup> C under simulated one sun illumination and OC conditions – important test conditions under which PSCs have been studied to date only to a limited degree ( _18-20_ ). Light- and heat-induced degradation in PSCs is related to point defects formed at interfaces and grain boundaries (GBs) ( _14, 21_ ). Moisture-induced degradation is curtailed using encapsulation ( _22_ ); whereas the passivation of defects at interfaces and GBs within the perovskite film is required to improve the PCE and intrinsic durability of PSCs ( _11, 23-26_ ). Particular promise in increasing durability has been seen in the use of P-, N-, S-, and O- containing Lewis-base molecules to form coordinate covalent bonds (dative bonds) that donate electrons to undercoordinated Pb atoms at interfaces and GBs ( _27-29_ ). 

66 Using density functional theory (DFT), we saw evidence that P-containing Lewis base molecules 67 showed the strongest binding with uncoordinated Pb atoms. We thus pursued diphosphine68 containing molecules, reasoning that these would provide additional binding and bridging at 69 interfaces and GBs. For experimental studies we selected 1,3-bis(diphenylphosphino)propane 70 (DPPP),  a diphosphine Lewis base. We found that treating perovskites with a small amount of 71 DPPP improves PCE and durability: inverted ( _p_ - _i_ - _n_ ) PSCs after DPPP treatment showed a 72 champion PCE of 24.5%. A DPPP-treated PSC with an initial PCE of ~23% stabilized at ~23.5% 73 after maximum power point (MPP) tracking under continuous simulated AM1.5 illumination at 74 ~40°C for >3,500 hours. DPPP-stabilized PSCs showed no PCE degradation after being kept at 75 OC and 85°C conditions for >1,500 hours. 

3 

86 

87 

88 

89 

90 

91 

92 

93 

94 

95 

99 

## 76 **Bonding interactions of Lewis bases** 

### 77 

78 

79 

80 

81 

82 

83 

84 

85 

The P, N, S, and O atoms in Lewis base molecules donate electrons to the Lewis acid sites in perovskites, such as the undercoordinated Pb<sup>2+</sup> at perovskite surfaces, in order to form coordinate covalent bonds. In general, the Lewis basicity, which is inversely proportional to electronegativity, is expected to determine the binding energy and the stabilization of interfaces and GBs. We compared binding energies of prototypical Lewis bases, trimethylphosphine (TMP), trimethylamine (TMA), dimethylsulfide (DMS), and dimethylether (DME), with sp<sup>3</sup> hybridization to the surface of FAPbI3 through DFT calculations (Fig. 1A). The calculated binding strength followed the order P > N > S > O, indicating the electronegativity rule did not strictly apply – a finding we attribute to the remaining lone pair electrons in the case of S and O following binding with perovskites. We also compared frequently-reported Lewis base molecules with the _sp_<sup>2</sup> oxygen in the carbonyl groups and took acetone and methyl acetate (MeOAc) as examples in Fig. 1A ( _26, 30_ ). The binding energies were similar to that of DME. 

96 

97 

98 

Lewis base molecules have mostly been used to passivate uncoordinated Pb atoms ( _24, 31 - 33_ ). A Lewis base molecule with two electron donating atoms can potentially bind and bridge interfaces and GBs, offering the potential to enhance the adhesion and strengthen the mechanical toughness of PSCs and provide additional benefits related to the durability of PSCs. For this reason, we selected DPPP, a diphosphine Lewis base molecule in seeking to stabilize and passivate PSCs. As shown in Fig. 1B and fig. S1, a DPPP molecule has two P atoms with sp<sup>3</sup> hybridization in tetrahedral coordination. The lone pair electrons occupy the missing vertex of the tetrahedron, and if donated to Lewis acids (metal cations) to form a covalent bond, the fully tetrahedral coordination would realize and gain more stabilization. 

100 

101 We calculated the binding of DPPP on the surfaces of FAPbI3 both with PbI2 and FAI 102 terminations. Although DFT calculations predicted that the FAI terminated surface was more 103 stable ( _34_ ), experimental evidence showed that the PbI2 terminated surface is readily formed 104 during the solvent treatment from depositing subsequent layers ( _35_ ). DFT calculations also 105 showed that DPPP was chemically bonded to the PbI2 terminated surface through P-Pb bond 106 formation with a binding energy of 2.24 eV but was weakly bonded to the FAI-terminated 107 surface by the van der Waals interaction with a binding energy of 1.09 eV (Fig. 1, C and D). 

4 

108 Moreover, the calculated binding energy of DPPP with perovskites in two adjacent slabs 109 (3.08 eV) was larger than that in the same slab (2.24 eV) (Fig. 1, D and E). Similarly, the 110 binding energy of DPPP with both the perovskite and NiOx slabs (4.31 eV) was larger than 111 that (3.28 eV) in the same NiOx slab (Fig. 1F and fig. S2). Thus, DPPP was predicted to 112 bind, bridge and stabilize perovskite GBs and perovskite/NiOx interface. DPPP molecules 113 also provided hole transport channels through the P-terminated alkane chain of DPPP (fig. 114 S3). 

115 



116 **Fig. 1. DFT calculated DPPP binding with perovskites.** ( **A** ) Chemical structures of 

117 prototypical Lewis base molecules. The numbers are the DFT-calculated binding energies (in eV) 118 of the Lewis base molecule bonded to the FAPbI3 surface with PbI2 termination. ( **B** ) Molecular 119 structure of DPPP. The P atom of DPPP donates a lone-pair electron to the metal cation forming 120 a coordinate covalent bond. Covalent bonding and van der Waals bonding for DPPP bound on 121 FAPbI3 surfaces with ( **C** ) FAI and ( **D** ) PbI2 terminations, respectively. DPPP binds ( **E** ) two 122 perovskite slabs and ( **F** ) perovskite and NiOx substrate through chemical-bond formation between 123 P and Pb/Ni atoms in a Lewis acid-base reaction. 

5 

124 

125 **Synthesis and structure** 

126 

131 132 

133 

127 

128 

129 

130 

134 

135 

136 

137 

138 

139 

140 

141 

142 

143 

144 

145 

146 

147 

148 

149 

150 

151 

The interaction between DPPP molecules and Pb<sup>2+</sup> is seen via the formation of a new adduct when a thin layer of DPPP was deposited on a PbI2 layer (fig. S4). When fabricating devices, we deposited the FA-based perovskite layer on DPPP coated NiOx hole transport layer. During the growth of perovskite films, some DPPP molecules re-dissolved and segregated at both the perovskite/NiOx interface and the perovskite surface regions, as verified by the time-of-flight secondary ion mass spectrometry (ToF-SIMS) depth profiles shown in Fig. 2A. X-ray photoelectron spectroscopy (XPS) revealed that after DPPP treatment, the core levels of the elements in both perovskite and NiOx shifted (Pb and Ni XPS spectra in Fig. 2B and Fig 2C and the O, C, N, and I spectra in fig. S5). The universal shift of core levels caused by electrostatic interaction indicates the existence of DPPP at both the interfaces. The DPPP treatment also slightly improved the crystallinity of perovskite films, as can be seen from the enhancement of grain domain size (fig. S6) and XRD peak intensity (fig. S7). DPPP treatment did not change the bandgap of the perovskite films (fig. S8). Photoluminescence (PL) and time-resolved PL spectroscopy (TRPL) spectra (Fig. 2, D and E) showed enhanced PL intensity and ~50% improved lifetime from 0.98 to 1.49 µs for the DPPP-treated perovskite films, consistent with the expected reduction in nonradiative recombination and defect density upon Lewis-base treatment ( _29, 36_ ). We further verified that DPPP treatment enhanced the mechanical toughness of the perovskite/NiOx interface. Perovskite films were deposited on a half-cell structure with and without DPPP treatment, protected by a thin PMMA layer, and adhered to a glass plate with epoxy (see details in the Supplementary Materials and fig. S9). A tensile load was applied to delaminate the films using a testing machine shown in fig. S10. After delamination, both the NiOx and perovskite surfaces of the NiOx/perovskite interface showed P signals, indicating DPPP remained on both surfaces (fig. S11). The tensile force recorded during the delamination process (Fig. 2F) suggest that DPPP treatment enhanced the mechanical strength of the perovskite/NiOx interface through the binding of DPPP at the interface. 

6 

152 



153 **Fig. 2. Effects of DPPP on perovskite film quality and device performance.** ( **A** ) ToF-SIMS 154 depth profile of a DPPP-treated sample showing DPPP molecules segregate at both interfaces. 155 XPS spectra comparing ( **B** ) binding energy of Pb-4f core levels of control and DPPP-treated 156 samples and ( **C** ) binding energy of Ni-2p core levels of NiOx before and after DPPP treatment. 157 PL (D) and TRPL (E) spectra of control and DPPP-treated perovskite films measured from the 158 film side. The samples were excited with a continuous-wave 633-nm laser at a fluence of 159 1.5×10<sup>17</sup> photons cm<sup>-2</sup> s<sup>-1</sup> . ( **F** ) Histogram and standard deviation values of loads at break of 10 160 sets of control and DPPP-treated samples. 

161 

162 Hyperspectral PL mapping measured from the buried interfaces and PL intensity histograms in 163 Fig. 3, A to D revealed an overall higher PL intensity of the DPPP-treated perovskite film that 164 was consistent with the longer PL lifetimes and indicated reduced defect density as compared to 165 the control perovskite films. The PL emission heterogeneity increased and more dark spots were 166 observed over time in the control film after light aging (fig. S12). These dark spots showed lower 167 PL emission intensity, and we attributed them to the initial sites of photodegradation at localized 168 defects and local heterogeneities, which were more prevalent in the control sample without 169 DPPP. PL decay takes place mostly in regions with low initial PL counts, while PL enhancement 170 takes place in regions with high initial PL counts (fig. S13). This observation proves that local 171 PL enhancement/decay in the control sample is associated with local defect heterogeneities. In 172 comparison, the DPPP-treated films exhibited higher uniformity and better light stability, with 

7 

173 most of the pixels showing photo-brightening with increased PL counts, rather than photo-decay 174 with decreased PL counts as was observed for the control perovskite film (Fig. 3, B and D and 175 fig. S12). Scanning electron microscopy (SEM) images measured from the bottom surface show 176 needle-shaped PbI2 crystals on the as-prepared control film, which is likely caused by the excess 177 PbI2 added to the precursor solution (fig. S14A). The as-prepared DPPP-treated film showed 178 distinct layered structures (fig. S14B), which we speculated could possibly be the Lewis acid179 base adduct of PbI2 and DPPP. After aging, the PbI2 crystals in the control film decomposed and 180 produced pinholes on the grains (Fig. 3E). In contrast, the DPPP-treated films exhibited much181 suppressed degradation (Fig. 3F), consistent with the optical microscopy above. Time-resolved 182 mass spectroscopy was also conducted on control and DPPP-treated films under illumination to 183 investigate the degradation process. The control sample showed the release of HI and I species 184 (fig. S15), which are by-products of the photoinduced decomposition and trigger irreversible 185 chemical chain reactions that accelerate the decomposition of perovskites ( _37, 38_ ). In addition to 186 the iodide species, another perovskite decomposition by-product, metallic Pb0, was also observed 187 on the control film after light soaking. The XPS spectrum of the control film after light-soaking 188 showed two Pb0 peaks at ~136 and ~141 eV (Fig. 3G), whereas no Pb0 peaks were observed in 189 DPPP-treated film. These results reveal that DPPP treatment could effectively suppress the 190 photodecomposition at the NiOx/perovskite interface, likely by reducing the density of reactive 191 undercoordinated lead sites (halide vacancies) at the surface and interfaces. 

- 192 

8 

193 

194 **Fig. 3. Characterization of perovskite film stability before and after DPPP treatment.** (A to 



195 **D** ) Hyperspectral PL images and histograms of control and DPPP-treated perovskite films before 196 and after light aging. The PL images were taken from the buried interface side, and the PL count 197 at each pixel refers to the integrated PL counts over the whole spectrum. ( **E** and **F** ) SEM top198 view images taken from the buried interface of control and DPPP-treated perovskite films after 199 light soaking. ( **G** ) XPS measured from the buried interface of control and DPPP-treated 

200 perovskite films after light soaking. 

201 

### 202 

## **Solar cell fabrication and performance** 

203 We fabricated PSCs with the _p_ - _i_ - _n_ configuration of glass/FTO/NiOx/Me-4PACz/(with or without) 204 DPPP/FA0.95Cs0.05PbI3/PEAI/C60/SnO2/Ag to show the effect of DPPP treatment on improving 

- 205 device performance and stability. Note that NiOx was treated by a very thin layer of Me-4PACz to 206 improve the reproducibility (fig. S16). The statistics of our device performance results are shown 

9 

225 

226 

227 

228 

229 

230 

231 

232 

233 

234 

235 

207 in fig. S17. A small amount of DPPP (1 or 2 mg/mL) consistently improved the open-circuit 208 voltage ( _V_ OC) and fill factor (FF) across the comparison of 40 devices. Both the improvement in 209 _VOC_ and FF are expected to accompany a reduction in surface recombination velocity through a 210 reduction in surface defects ( _39_ ), and are also in qualitative agreement with the increase in film 211 PL and PL lifetime upon treatment. Higher concentrations of  DPPP (4 mg/mL) decreased short212 circuit current density ( _J_ SC) and FF, which may be resulted from the overreaction between DPPP 213 and perovskites. Figure 4A shows _J_ - _V_ scans of the champion control and DPPP (2 mg/mL)214 treated devices with 0.1 cm<sup>2</sup> aperture masks under forward and reverse scans. The PCE of the 215 DPPP-treated device improved from 22.6% to 24.5%, with the _VOC_ increased from ~1.11 to ~1.16 216 V and FF increased from ~79% to ~82% (see detailed device parameters in table S1). External 217 quantum efficiency (EQE) spectra (Fig. 4B) verified the JSC values obtained from the _J_ - _V_ 218 measurement. The enhanced EQE at short wavelengths also indicates improved carrier extraction 219 at the front interface, which may be associated with the passivated interface achieved through the 220 use of DPPP. We have also fabricated PSCs with a larger active area (1.05 cm<sup>2</sup> ) to validate the 221 benefits of DPPP treatment. The target devices with DPPP treatment also showed overall 222 improvement in device parameters (fig. S18), with the champion target device showing PCEs of 223 23.9% and 23.6% under reverse and forward scans (fig. S19 and table S2). The improvement on 224 FF and _VOC_ confirmed the reduction on defect density at the NiOx/perovskite front interface after 225 DPPP treatment. 

236 

237 238 

For durability tests, we replaced the Ag electrodes by Cr/Cu to avoid instability caused by Ag corrosion and diffusion but slightly lowered the device efficiency (by ~ 4 %) (fig. S20). We used 0.1 cm<sup>2</sup> aperture masks for solar cells when conducting all the stability tests. We first tested the effect of DPPP on device stability by maximum power point tracking (MPPT) under continuous 1 sun illumination in N2 environment and at a temperature of ~40 °C. As shown in Fig. 4C, the DPPP-treated device exhibited an initial PCE of ~23%, increased to ~23.5% after ~450 hours and maintained unchanged after 3,500 hour <mark>s. The increased PCE was contributed by the increased voltage at MPP (fig. S21), which is likely due to the light-induced annihilation of halide defects</mark> ( _10, 40-43_ ). However, the PCE of the control device decreased to <80% of its initial PCE after 1,000 hours. The film area of the control PSC turned dark yellow, indicating the decomposition of perovskite to PbI2 after 3,500 hours (fig. S22). In contrast, the film area of the DPPP-treated device remained dark, indicating more stabilized perovskite after DPPP treatment. 

10 

239 

251 

252 

240 We then conducted accelerated durability tests at elevated temperatures. We kept the PSCs in a 241 dark oven at 85°C and in the ambient, and measured the PCEs periodically for the 242 thermal stress test (ISOS-D-2). We tested 18 PSCs and summarize their statistics in fig. S23. The 243 average PCEs and their corresponding standard deviations (Fig. 4D) reveal that the DPPP-treated 244 devices retain on average ~90% of their initial PCE after 1500 hours, while, in contrast, the 245 average PCE of the control devices dropped to <90% after 168 hours. 

246 

247 

248 

249 

250 

253 

254 

255 

256 

257 

We conducted a more rigorous accelerated durability test under the OC condition and continuous ~0.9 sun illumination. The devices were kept in an oven at a temperature of 85 °C and humidity of ~65% and measured every 208 s. The devices measured at 85 °C showed slightly lower PCEs possibly due to the negative temperature coefficient (fig. S24).  The PCE was stable for the first ~300 hours and then slightly increased to ~108% of its initial value and showed no degradation after 1,500 hours (Fig. 4E). However, the control device degraded rapidly after 400 hours, dropping to ~80% of its initial PCE. Two more DPPP-treated PSCs were measured to validate the improved stability by DPPP treatment (fig. S25). The photos of devices after 1,500 hours of illumination were shown in fig. S26. The glass-side view of the control film turned gray, which was likely the result of delamination of the perovskite film at the 

258 NiOx/perovskite front interface and the degradation of the perovskite layer. In contrast, the 259 DPPP-treated device showed partial delamination on the edge but remained dark in most of the 

260 film area. 

11 

261 

262 **Fig. 4. Performance and stability of control and DPPP-treated devices.** (A) _J_ - _V_ curves of 



263 champion control and DPPP treated devices. ( **B** ) EQE spectra of the corresponding control and 264 DPPP-treated devices. ( **C** ) MPPT of control and DPPP-treated devices measured under 

265 continuous one sun illumination in N2 environment and at a temperature of ~40 ºC. ( **D** ) Thermal 266 stress test of control and DPPP-treated devices aged at 85 °C following the ISOS-D-2 protocol. 267 ( **E** ) Tracking of control and DPPP-treated devices measured at 85 °C and under continuous ~0.9 268 sun illumination and OC condition. 

269 

270 **Discussion** 

271 Taking experimental findings together with DFT studies,  we offer that DPPP molecules 272 strengthen the NiOx/perovskite interface and stabilize the perovskite phase. The robust binding 

12 

- 273 between the NiOx and perovskite enabled by DPPP modification appears to be an enabler of the 

- 274 stable operation of PSCs under outdoor conditions. The measured stability under accelerated 

- 275 testing conditions indicates a benefit from DPPP in improving device stability and provides ways 

- 276 to realizing commercialization of PSCs. 

13 

- 277 **Reference and Notes** 

- 278 1. A. K. Jena, A. Kulkarni, T. Miyasaka, Halide perovskite photovoltaics: background, 279 status, and future prospects. _Chem. Rev._ **119** , 3036-3103 (2019). 

- 280 2. Z. Li _et al._ , Scalable fabrication of perovskite solar cells. _Nat. Rev. Mater._ **3** , 18017 281 (2018). 

- 282 3. H. Min _et al._ , Perovskite solar cells with atomically coherent interlayers on SnO2 283 electrodes. _Nature_ **598** , 444-450 (2021). 

- 284 4. Y. Zhao _et al._ , Inactive (PbI2)2RbCl stabilizes perovskite films for efficient solar cells. 285 _Science_ **377** , 531-534 (2022). 

- 286 5. Y. Rong _et al._ , Challenges for commercializing perovskite solar cells. _Science_ **361** , 287 eaat8235 (2018). 

- 288 6. L. Meng, J. You, Y. Yang, Addressing the stability issue of perovskite solar cells for 289 commercial applications. _Nat. Commun._ **9** , 5265 (2018). 

- 290 7. P. Holzhey, M. Saliba, A full overview of international standards assessing the long-term 291 stability of perovskite solar cells. _J. Mater. Chem. A_ **6** , 21794-21808 (2018). 

- 292 8. K. Domanski, E. A. Alharbi, A. Hagfeldt, M. Grätzel, W. Tress, Systematic investigation 293 of the impact of operation conditions on the degradation behaviour of perovskite solar 294 cells. _Nat. Energy_ **3** , 61-67 (2018). 

- 295 9. M. V. Khenkin _et al._ , Consensus statement for stability assessment and reporting for 296 perovskite photovoltaics based on ISOS procedures. _Nat. Energy_ **5** , 35-49 (2020). 

- 297 10. R. Azmi _et al._ , Damp heat–stable perovskite solar cells with tailored-dimensionality 298 2D/3D heterojunctions. _Science_ **376** , 73-77 (2022). 

- 299 11. C. C. Boyd _et al._ , Understanding degradation mechanisms and improving stability of 300 perovskite photovoltaics. _Chem. Rev._ **119** , 3418-3451 (2018). 

- 301 12. M.-c. Kim _et al._ , Imaging real-time amorphization of hybrid perovskite solar cells under 302 electrical biasing. _ACS Energy Lett._ **6** , 3530-3537 (2021). 

- 303 13. E. Bi, Z. Song, C. Li, Z. Wu, Y. Yan, Mitigating ion migration in perovskite solar cells. 304 _Trends in Chemistry_ **3** , 575-588 (2021). 

- 305 14. K. Domanski _et al._ , Migration of cations induces reversible performance losses over 306 day/night cycling in perovskite solar cells. _Energy Environ. Sci._ **10** , 604-613 (2017). 

- 307 15. T. Duong _et al._ , Light and electrically induced phase segregation and its impact on the 308 stability of quadruple cation high bandgap perovskite solar cells. _ACS Appl. Mater._ 

14 

- 309 _Interfaces_ **9** , 26859-26866 (2017). 

- 310 16. B. Chen _et al._ , Synergistic effect of elevated device temperature and excess charge 311 carriers on the rapid light-induced degradation of perovskite solar cells. _Adv. Mater._ **31** , 312 1902413 (2019). 

- 313 17. Y. Yuan, J. Huang, Ion migration in organometal trihalide perovskite and itsimpact on 314 photovoltaic efficiency and stability. _Acc. Chem. Res._ **49** , 286-293 (2016). 

- 315 18. L. Shi _et al._ , Accelerated lifetime testing of organic–inorganic perovskite solar cells 316 encapsulated by polyisobutylene. _ACS Appl. Mater. Interfaces_ **9** , 25073-25081 (2017). 

- 317 19. S. Yang _et al._ , Stabilizing halide perovskite surfaces for solar cell operation with wide318 bandgap lead oxysalts. _Science_ **365** , 473-478 (2019). 

- 319 20. Y.-H. Lin _et al._ , A piperidinium salt stabilizes efficient metal-halide perovskite solar cells. 320 _Science_ **369** , 96-102 (2020). 

- 321 21. S. Bai _et al._ , Planar perovskite solar cells with long-term stability using ionic liquid 322 additives. _Nature_ **571** , 245-250 (2019). 

- 323 22. Z. Li _et al._ , Organometallic-functionalized interfaces for highly efficient inverted 324 perovskite solar cells. _Science_ **376** , 416-420 (2022). 

- 325 23. T.-H. Han _et al._ , Perovskite-polymer composite cross-linker approach for highly-stable 326 and efficient perovskite solar cells. _Nat. Commun._ **10** , 520 (2019). 

- 327 24. M. Zhu _et al._ , Interaction engineering in organic–inorganic hybrid perovskite solar cells. 328 _Mater. Horiz._ **7** , 2208-2236 (2020). 

- 329 25. D. W. deQuilettes et al., Photoluminescence lifetimes exceeding 8 µs and quantum yields 330 exceeding 30% in hybrid perovskite thin films by ligand passivation. _ACS Energy Lett._ **1** , 331 438-444 (2016). 

- 332 26. C. Shi _et al._ , Molecular hinges stabilize formamidinium-based perovskite solar cells with 333 compressive strain. _Adv. Funct. Mater._ 2201193 (2022). 

- 334 27. Z. Yang _et al._ , Multifunctional phosphorus-containing Lewis Acid and Base passivation 335 enabling efficient and moisture-stable perovskite solar cells. _Adv. Funct. Mater._ **30** , 336 1910710 (2020). 

- 337 28. N. K. Noel _et al._ , Enhanced photoluminescence and solar cell performance via Lewis 338 Base passivation of organic–inorganic lead halide perovskites. _ACS Nano_ **8** , 9815-9821 339 (2014). 

- 340 29. N. Ahn _et al._ , Highly reproducible perovskite solar cells with average efficiency of 18.3% 

15 

- 341 and best efficiency of 19.7% fabricated via Lewis base adduct of lead (II) iodide. _J. Am._ 342 _Chem. Soc._ **137** , 8696-8699 (2015). 

- 343 30. A. Seidu, M. Dvorak, J. Järvi, P. Rinke, J. Li, Surface reconstruction of tetragonal 344 methylammonium lead triiodide. _APL Mater._ **9** , 111102 (2021). 

- 345 31. S. Tan _et al._ , Surface reconstruction of halide perovskites during post-treatment. _J. Am._ 346 _Chem. Soc._ **143** , 6781-6786 (2021). 

- 347 32. D. W. de Quilettes et al., Impact of microstructure on local carrier lifetime in perovskite 348 solar cells. _Science_ **348** , 683-686 (2015). 

- 349 33. Z. Song _et al._ , Probing the origins of photodegradation in organic–inorganic metal halide 350 perovskites with time-resolved mass spectrometry. _Sustain. Energy Fuels_ **2** , 2460-2467 351 (2018). 

- 352 34. F. Fu _et al._ , I2 vapor-induced degradation of formamidinium lead iodide based perovskite 353 solar cells under heat–light soaking conditions. _Energy Environ. Sci._ **12** , 3074-3088 354 (2019). 

- 355 35. J. Wang et al., Reducing surface recombination velocities at the electrical contacts will 356 improve perovskite photovoltaics. _ACS Energy Lett._ **4** , 222-227 (2019). 

- 357 36. J. A. Christians _et al._ , Tailored interfaces of unencapsulated perovskite solar cells 358 for >1,000 hour operational stability. _Nat. Energy_ **3** , 68-74 (2018). 

- 359 37. W. Nie _et al._ , Light-activated photocurrent degradation and self-healing in perovskite 360 solar cells. _Nat. Commun._ **7** , 11574 (2016). 

- 361 38. G. Kresse, J. Furthmüller, Efficient iterative schemes for ab initio total-energy 362 calculations using a plane-wave basis set. _Phys. Rev. B._ **54** , 11169-11186 (1996). 

- 363 39. G. Kresse, J. Furthmüller, Efficiency of ab-initio total energy calculations for metals and 364 semiconductors using a plane-wave basis set. _Comput. Mater. Sci._ **6** , 15-50 (1996). 

- 365 40. P. E. Blöchl, Projector augmented-wave method. _Phys. Rev. B._ **50** , 17953-17979 (1994). 

- 366 41. J. P. Perdew, K. Burke, M. Ernzerhof, Generalized gradient approximation made simple. 367 _Phys. Rev. Lett._ **77** , 3865-3868 (1996). 

- 368 42. S. Grimme, J. Antony, S. Ehrlich, H. Krieg, A consistent and accurate ab initio 369 parametrization of density functional dispersion correction (DFT-D) for the 94 elements 370 H-Pu. _J. Chem. Phys._ **132** , 154104 (2010). 

- 371 43. A. R. M. Alghamdi, M. Yanagida, Y. Shirai, G. G. Andersson, K. Miyano, Surface 372 passivation of sputtered NiOx using a SAM interface layer to enhance the performance of 

16 

- 373 perovskite solar cells. _ACS Omega_ **7** , 12147-12157 (2022). 

- 374 44. G. Kresse, J. Furthmüller, Efficient iterative schemes for ab initio total-energy 

- 375 calculations using a plane-wave basis set. _Phys. Rev. B._ **54** , 11169-11186 (1996). 

- 376 45. G. Kresse, J. Furthmüller, Efficiency of ab-initio total energy calculations for metals and 377 semiconductors using a plane-wave basis set. _Comput. Mater. Sci._ **6** , 15-50 (1996). 

- 378 46. P. E. Blöchl, Projector augmented-wave method. _Phys. Rev. B._ **50** , 17953-17979 (1994). 

- 379 47. J. P. Perdew, K. Burke, M. Ernzerhof, Generalized gradient approximation made simple. 380 _Phys. Rev. Lett._ **77** , 3865-3868 (1996). 

- 381 48. S. Grimme, J. Antony, S. Ehrlich, H. Krieg, A consistent and accurate ab initio 382 parametrization of density functional dispersion correction (DFT-D) for the 94 elements 383 H-Pu. _J. Chem. Phys._ **132** , 154104 (2010). 

- 384 49. A. R. M. Alghamdi, M. Yanagida, Y. Shirai, G. G. Andersson, K. Miyano, Surface 385 passivation of sputtered NiOx using a SAM interface layer to enhance the performance of 386 perovskite solar cells. _ACS Omega_ **7** , 12147-12157 (2022). 

387 

388 

## **Acknowledgments** 

389 This material is based upon work supported by the U.S. Department of Energy’s Office of 390 Energy Efficiency and Renewable Energy (EERE) under the Solar Energy Technologies Office 391 Award Numbers DE-EE0008970 and DE-EE0008753, and by the U.S. Air Force Research 392 Laboratory under agreement number FA9453-21-C-0056. F. J. and D. S. G.’s contributions, 393 focusing on hyperspectral imaging for cell metrology, are based primarily on work supported by 394 EERE under the Solar Energy Technologies Office (Award Number DE-EE0009528) as well as 395 institutional support from the B. Seymour Rabinovitch Endowment and state of Washington. 396 DFT calculations were supported by the Center for Hybrid Organic-Inorganic Semiconductors 397 for Energy (CHOISE), an Energy Frontier Research Center funded by the Office of Basic Energy 398 Sciences, Office of Science within the U.S. Department of Energy and the National Science 399 Foundation under contract number DMR-1807818. The DFT calculations were performed using 400 computational resources sponsored by the Department of Energy's Office of Energy Efficiency 401 and Renewable Energy and located at the National Renewable Energy Laboratory and the DOS 402 calculations used resources of the National Energy Research Scientific Computing Center 403 (NERSC), a U.S. Department of Energy Office of Science User Facility located at Lawrence 404 Berkeley National Laboratory, operated under Contract No. DE-AC02-05CH11231 using 

17 

- 405 NERSC award BES-ERCAP0017591. The U.S. Government is authorized to reproduce and 

- 406 distribute reprints for Governmental purposes notwithstanding any copyright notation 

- 407 thereon. The views expressed are those of the authors and do not reflect the official guidance or 408 position of the United States Government, the Department of Defense or of the United States Air 409 Force. The appearance of external hyperlinks does not constitute endorsement by the United 

- 410 States Department of Defense (DoD) of the linked websites, or the information, products, or 

- 411 services contained therein. The DoD does not exercise any editorial, security, or other control 

- 412 over the information you may find at these locations. Approved for public release; distribution is 413 unlimited. Public Affairs release approval #AFRL-2022-3776. C.L. acknowledges Dr. Deying 414 Luo for important discussions about the XPS analysis. 

18 

423 

424 

### 415 

## **Author contributions:** 

416 C.L. and Y.Y. conceived the idea. Y.Y. supervised the projects and process. C.L. <mark>, S.M.P.</mark> and 417 E.B. fabricated perovskite films and devices for characterization and performance measurement. 418 X.W <mark>. and Y.X.</mark> carried out DFT calculations. C.L. <mark>, L.C., T.Z. and L.Z.</mark> carried out SEM, UV-vis 419 and XRD measurements and data analysis. Z.S. carried out time-resolved mass spectroscopy 420 measurement and data analysis. F.J. and D.S.G. carried out hyperspectral microscope 

421 

422 

425 

426 

427 

428 

429 

430 

431 

measurement and associated data analysis. <mark>C.L. and J.C. prepared NiO</mark> x <mark>substrates. Y</mark> .L. carried out stability tests and data analysis. Z.W., Y.L. and H.C. carried out XPS measurements and data analysis. H.L. and F.F. carried out the Tof-SIMS measurements and data analysis. C.R.G. carried out tensile force measurements and data analysis. A.A. and R.J.E carried out the PL and TRPL measurement and data analysis. C.L., X.W., S.Z., and Y.Y. wrote the first draft of the manuscript. E.H.S. and Y.Y. reviewed and edited the manuscript. All authors discussed the results and contributed to the revisions of the manuscript. 

**Competing interests:** C.L. and Y.Y are inventors on a patent application related to this work filed by the University of Toledo. The other authors declare no competing interests. 

**Data and materials availability:** All data are available in the main text or the supplementary materials. 

- 432 

- 433 

## **Supplementary Materials** 

- 434 

- 435 

Materials and Methods 

- 436 

Figs. S1 to S26 

- 437 Tables S1 to S2 

- 438 

19 

439 

20 

