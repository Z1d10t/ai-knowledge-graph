# Long-term operating stability in perovskite photovoltaics

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Reviews Materials |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 661 |
| 作者 | Hongwei Zhu, S. Teale, M. Lintangpradipto, Suhas Mahesh, Bin Chen, M. McGehee, E. Sargent, O. Bakr |
| DOI | 10.1038/s41578-023-00582-w |
| 源文件 | 007_Zhu_2023_Long-term-operating-stability-in-perovskite-phot.pdf |

---
TSpace Research Repository tspace.library.utoronto.ca 

# **Long-term operating stability in perovskite photovoltaics** 

Hongwei Zhu, Sam Teale, Muhammad Naufal Lintangpradipto, Suhas Mahesh, Bin Chen, Michael D. McGehee, Edward H. Sargent and Osman M. Bakr 

**Version** Post-Print\Accepted Manuscript 

**Citation** (Zhu, H., Teale, S., Lintangpradipto, M. N., Mahesh, S., Chen, B., McGehee, M. **(published** D., ... & Bakr, O. M. (2023). Long-term operating stability in perovskite **version)** photovoltaics. Nature Reviews Materials, 8(9), 569-586.) 

DOI https://doi.org/10.1038/s41578-023-00582-w 

**Publisher** This version of the article has been accepted for publication, after peer review and is **Terms of** subject to Springer Nature’s AM terms of use, but is not the Version of Record and **Use** does not reflect post-acceptance improvements, or any corrections. The Version of Record is available online at: https://doi.org/10.1038/s41578-023-00582-w 

#### **How to cite TSpace items** 

**Always cite the published version** , so the author(s) will receive recognition through services that track citation counts, e.g. Scopus. If you need to cite the page number of the **author manuscript from TSpace** because you cannot access the published version, then cite the TSpace version **in addition to** the published version using the permanent URI (handle) found on the record page. 

#### **This article was made openly accessible by U of T Faculty. Please** **<u>tell us how this access benefits you. Your story matters.</u>** 



## **Long-term operating stability in perovskite photovoltaics** 

Hongwei Zhu<sup>1 #</sup> , Sam Teale<sup>2 #</sup> , Muhammad Naufal Lintangpradipto<sup>1</sup> , Suhas Mahesh<sup>2</sup> , Bin Chen<sup>2</sup> , Michael D. McGehee<sup>3</sup> , Edward H. Sargent<sup>2,4,5 *</sup> and Osman M. Bakr<sup>1 *</sup> 

#### **Affiliations:** 

1KAUST Catalysis Center, Division of Physical Sciences and Engineering, King Abdullah University of Science and Technology, Thuwal 23955-6900, Kingdom of Saudi Arabia 

2Department of Electrical and Computer Engineering, University of Toronto, 35 St. George Street, Toronto, Ontario M5S 1A4, Canada 

3 Materials Science and Engineering Program, University of Colorado Boulder, 4001 Discovery Drive, Boulder, CO 80303, USA 

4 Department of Chemistry, Northwestern University, Evanston IL 60208 USA 

5 Department of Electrical and Computer Engineering, Northwestern University, Evanston IL 60208 USA 

#### **Abstract** ： 

Perovskite solar cells (PSCs) have demonstrated the efficiencies needed for technoeconomic competitiveness. With respect to the demanding stability requirements of photovoltaics, many techniques have been employed to increase stability, and tremendous improvements have been made over the course of a decade of research. The relatively poor stability of devices that use unstable configurations can hide the overall trend of increasing stability, with recent studies demonstrating operating lifetimes > 1 year and estimated _T_ 80 lifetimes approaching that of established solar technology. Nevertheless, PSCs’ still-limited stability remains to be fully understood and addressed. In this Review, we summarize progress in single-junction, lead–based perovskite photovoltaic stability and discuss the origins of chemical lability and how this impacts stability under a range of relevant stressors. We highlight categories of prominent stabilityenhancing strategies, including compositional tuning, barrier layers and the fabrication of stable transport layers. In the conclusion of this Review, we discuss the challenges that remain, and we offer a perspective on how the field can continue to advance to 25-year and 30-year stable perovskite solar modules. 

1 

### **[H1] Introduction** 

Because of their remarkable properties, the discovery of metal-halide perovskite (MHP) semiconductors has ushered in a new era of solar cell research. MHPs form an ABX3 structure in which the A-site is a monovalent cation (typically a mixture of cesium, methylammonium or formamidinium), the B-site is a divalent metal (usually Pb or Sn), and the X-site is a pure halide or mixture of halides (I, Br, Cl) ( **Fig 1a** ). Owing to their large absorption coefficients, high mobilities, long diffusion lengths and tunability, polycrystalline thin films of perovskite have been used to fabricate perovskite solar cells (PSCs) with bandgaps from 1.2 to 2.3 eV<sup>1,2</sup> and power conversion efficiencies (PCE) approaching 26% (~ 1.5 eV).<sup>3</sup> Metal-halide perovskites are commonly known to have intrinsic defect tolerance, but modest temperatures (60 °C +) can cause perovskite crystal decomposition<sup>4,5</sup> and 1-sun illumination can break bonds to induce degradation.<sup>6,7</sup> Unsurprisingly, the time taken for early PSCs to drop to 80% of their original performance (their _T_ 80 lifetime) was only a few hours.<sup>8</sup> However, since then, great strides have been made and some PSCs have demonstrated 1000s of hours of operational stability at ≥ 65 °C with negligible loss to PCE.<sup>9,10</sup> Despite these improvements, fundamental understanding of instabilities and the mechanisms behind stability-enhancing methods are often overlooked. 

In this Review, we focus on lead-based perovskites used in single-junction PSCs. First, we discuss the special properties of perovskite materials and the major advances in PSCs stability. Then, we discuss the factors affecting PSC stability, techniques used thus far to combat them, and potential routes to further improvement. Several <mark>reports have demonstrated encapsulation that renders humidity and oxygen effects negligible on timescales up to 1 year.</mark><sup>11</sup> <mark>Hence, it seems reasonable to consider moisture and oxygen ingress separately as an encapsulation issue. The need for robust, long-term encapsulation techniques and how best to encapsulate PSCs are discussed at length in this review.</mark><sup>12</sup> <mark>H</mark> ere, w <mark>e instead focus on illumination, bias and temperature-based degradation.</mark> 

### **[H1] Differences between perovskites and traditional semiconductors** 

Perovskites and traditional semiconductors (Si, CdTe, III-V etc.) have several differences ( **Fig. 1a and 1b** ), which ultimately affect their stability. Paramount to the success of perovskites is their 

2 

defect tolerance, a result of their band structure ( **Fig. 1c** ). In typical semiconductors, the valence band maximum (VBM) is formed from bonding orbitals and the conduction band minimum (CBM) from antibonding orbitals.<sup>13</sup> When these bonds are broken, dangling bonds form close to where the original bonds were, creating defects deep within the semiconductor bandgap ( **Fig. 1c** ). Perovskites instead form their bandgap from antibonding orbitals at both the VBM and CBM, and thus breaking these bonds produces states away from the bandgap, either shallow defects or states within the valence band. The upshot of this is that polycrystalline perovskite films with defect densities 10<sup>6</sup> times greater than single crystal silicon can produce similar solar cell performance.<sup>14</sup> The downside is that high defect densities reduce the energy needed for ions to migrate through films and defects tend to propagate over time, resulting in faster degradation of the absorber.<sup>15</sup> 



**Figure 1: The unusual properties of perovskite semiconductors.** a) The crystal structure of perovskite semiconductors. b) The crystal structure of traditional III-V semiconductors. c) Band structure of perovskite and traditional semiconductors. d) Illustration of lattice distortion due to the lone pair effect in perovskite semiconductors. e) Temperature-dependant Raman spectra of MAPbBr3 demonstrating the fluid-like bonding nature of metal-halide perovskites (MHPs) at room temperature. f) Schematic of light-induced ionic restructuring in iodine-based perovskites. g) Time-of-flight secondary ion mass spectroscopy (ToF-SIMS) showing a build up of iodine ions at the metal/HTL interface after aging a PSC. The build up is due to halide diffusion through charge transport layers (CTLs). h) PL measurements of a 40% Br film which show the increase of 

3 

emission from iodine rich regions as a function of illumination time. Panel a is adapted from REF.<sup>16</sup> Panel b is adapted from REF.<sup>17</sup> Panel c is adapted from REF.<sup>13</sup> Panel d is adapted from REF.<sup>18</sup> Panel e is adapted from REF.<sup>19</sup> Panel f is adapted from REF.<sup>20</sup> Panel g is adapted from REF.<sup>21</sup> Panel h is adapted from REF.<sup>22</sup> 

A second important difference between perovskites and traditional semiconductors is the lone pair effect. The divalent metal B-site (usually Pb or Sn) forms with a lone pair of electrons that dictates the local geometry of the perovskite lattice ( **Fig. 1d** ).<sup>18</sup> Similarly to how a water molecule is bent by the lone electron pairs on the oxygen, the perovskite lattice is distorted by the lone pair on the B-site. However, rather than distorting to one specific orientation (like in the case of water), several local minima exist and at room temperature the perovskite lattice is continually moving and reorienting. This behavior is not clearly resolved by x-ray diffraction, which reveals the average lattice spacing, but is obvious in the Raman spectra of perovskites, which at room temperature appear similar to fluids ( **Fig. 1e** ).<sup>19</sup> The dynamic nature of the perovskite lattice has many profound consequences on its stability. The thermal expansion coefficients of metal halide perovskites are typically 10 times that of silicon, which is an important consideration when evaluating the mismatch in expansion and thus strain between perovskite and contacts. Additionally, the dynamic lattice increases the density of interstitials and vacancies and facilitates ion migration.<sup>18</sup> 

Ion migration is of great consequence in perovskite photovoltaics. High defect densities generate high ion densities (up to 10<sup>17</sup> cm<sup>-3</sup> )<sup>23</sup> and provide pathways for ion migration through the lattice or along grain boundaries. The ion migration energy of halides is lower than cations or metal species,<sup>24</sup> meaning halide drift is generally attributed as the reason perovskites act as both electronic and ionic conductors. PSCs are typically made by sandwiching a mostly intrinsic perovskite semiconductor layer between an electron transport layer (ETL) and a hole transport layer (HTL). Mobile ions in the perovskite migrate to the interfaces until they screen the built-in electric field that would normally exist when a semiconductor with a relatively low carrier density is between electrodes with different work functions. If the voltage across a PSC is changed so quickly that the ions cannot redistribute fast enough, then, depending on the direction of the voltage scan, the field can either be larger than normal (which favors electron extraction) or it can point in the wrong direction (which hinders electron extraction).<sup>23</sup> Upon initial testing,  hysteresis is measured between forward and reverse _J-V_ scans with large dependency on scan speed.<sup>25,26</sup> In the long term, ion redistribution results in a loss of current over time due to either flattening bands at 

4 

the device interface or a buildup of insulating interface material.<sup>27</sup> More troublingly, we now know that in iodide-based MHPs, the density of mobile ions is increased under illumination. As the VBM is formed from iodide bonds, photogenerated <mark>holes could oxidize iodide to make neutral iodine interstitials and iodide vacancies (</mark> **<mark>Fig. 1f</mark>** <mark>) causing several knock-on effects: I</mark> odine interstitials act as recombination centers and, because iodide vacancies are conductive, they move towards the interfaces,<sup>28,29</sup> I2 gas is produced and can leave the perovskite, and iodine ions diffuse into charge transport layers (CTLs) where they can react with metal electrodes reducing conductivity ( **Fig. 1g** ).<sup>30</sup> 

Another phenomenon which affects perovskite stability is phase segregation under illumination. For most perovskites in the family AB[I1-xBrx]3, iodine and bromine can be mixed uniformly for x ranging from 0 to 1. However, typically when x is greater than 20-33%, the perovskite phase separates into iodide-rich and bromide-rich regions under illumination.<sup>31</sup> The characteristic demonstration of this phase segregation is red-shifted photoluminescence. When the film absorbs light, electrons and holes migrate to (lower energy) iodide-rich regions, and as segregation progresses the photoluminescence red-shifts over time ( **Fig. 1h** ). The fundamental driver for segregation is debated, some suggesting it is thermodynamic in origin,<sup>32,33</sup> others suggesting it is the result of polaron-induced lattice strain<sup>34,35</sup> or charge carrier gradients.<sup>36,37</sup> Some consensus is emerging that iodide is oxidized by photogenerated holes and has a higher mobility than bromine, and this sets up the opportunity for halide segregation.<sup>38,39</sup> Regardless, phase segregation limits the potential open circuit voltage ( _VOC_ ) of ≥ 1.7 eV bandgap PSCs necessary for tandem photovoltaics. 

### **[H1] Device stability to date** 

The PCE of PSCs now rival that of Si PV, thus device stability is of utmost importance. The stability of PSCs depends on many factors ( aging condition, perovskite composition, CTLs, electrodes, encapsulation and passivation) and is thus a complex issue. Considering aging conditions alone, a consensus statement on stability testing of perovskite solar cells was made in 2020<sup>40</sup> and researchers are encouraged to use the ISOS testing protocols to enable comparison between studies. PSCs are classified into two architectural configurations: conventional ( _n-i-p_ ) and inverted ( _p-i-n_ ) structures ( **Fig. 2a and b** ). **Fig. 2c** shows a timeline of PSCs comparing record- 

5 

certified efficiency in _n-i-p_ and _p-i-n_ cells along with reported stability. We find that even though the efficiency of the record _n-i-p_ devices has improved hugely in the last decade, their stability has improved relatively slowly. Some reports on record devices are without stability measurements, others use different device fabrication with lower efficiency for stability testing and those which use the same architecture record _T_ 80 lifetimes at room temperature of only a few hundred hours.<sup>41</sup> These results give the impression that poor stability is abundant amongst the best PSCs. Scrutinizing further one finds that the situation is more positive. The stability of record _p-i-n_ devices, for example, has vastly improved, with devices demonstrating stability under illumination and heat (ISOS-L2/3) with _T_ 80 > 1000 h from initial PCEs > 23%. It should be noted that similarly high stability has been demonstrated in _n-i-p_ , but not with record efficiency.<sup>8,10,27</sup> Indeed, we also notice that many impressive stability milestones have been achieved. These are generally accomplished with low efficiency devices first and a few years is taken to achieve the same stability in a device with record efficiency. 

6 



**Figure 2: Timeline for stability in perovskite solar cells (PSCs).** The configuration of typical a) _p-i-n_ and b) _n-i-p_ PSCs c) A timeline for stability amongst PSCs with record efficiency, The **blue and green lines** represent record certified efficiency (steady-state) in _n-i-p_ and _p-i-n_ respectively, whereas the **red squares** denote the earliest report of certain stability milestones: D1 = Dark storage (room temp), D2 = Dark storage (high temp.), L2 = maximum power point (MPP) tracked under illumination (high temp.), D3 = Dark storage (high temp. + high humidity), LC1 = Light cycled (room temp.) O3 = Outdoor testing at MPP. References can be found in Supplementary Table S1. 

7 

Factors other than aging condition that affect perovskite stability are often considered separately to efficiency, with many reports using different CTLs or metal contacts for their stability testing than what are used to obtain their best PCEs. This is particularly popular in _n-i-p_ devices where the hole transporting material (HTM) spiro-OMeTAD is replaced with more stable HTMs.<sup>42-45</sup> This causes two problems: stability is achieved with significantly lower (often unreported) PCEs than the best efficiencies, and cells are optimised for efficiency using spiro-OMeTAD when these optimisations may not be beneficial using other CTLs. As the field matures, it is important to combine stability with efficiency, considering how best to optimise devices within a stable architecture. 

Another development is outdoor perovskite stability testing. Initially, real-world testing produced _T_ 80 lifetimes of only a few days.<sup>46</sup> More recently, however, the use of lamination-based glass-glass encapsulation has produced cells with no PCE degradation after 10 months of maximum power point (MPP) tracking outdoors in Berlin ( **Fig. 2c** ).<sup>47</sup> A small scale (~ 3 m<sup>2</sup> active area) perovskite solar farm with lamination encapsulation and an initial efficiency ~ 12.5% PCE was tested over the course of a year, with a recorded _T_ 80 of 5,832 h (8-months) following the ISOS-O3 protocol.<sup>48</sup> These results indicate that the lifetime of PSCs is increasing beyond what is practically assessable and there is a need to move from standard test conditions towards accelerated testing. 

8 

##### [bH1] 

##### **The Perovskite database** 

An open access database of PSC results has been generated with data from > 40,000 devices published between 2012 and 2020,<sup>49</sup> most of which have no stability data associated with them. Still, there are > 1,000 devices with stability referenced to the ISOS protocols, which we used to generate the Figure below. 

Panel a) of the Figure compares stability over time from all PSCs in _The Perovskite Database_ with corresponding ISOS protocols. The data is understandably noisy, as there are various perovskite compositions, device architectures and aging parameters included. The trendline still demonstrates an increase in _T_ 80 lifetime from ~ 10 to ~ 100 h over 6 years. However, noise brought about by the huge volume of studies underrepresents the stability gains. Looking instead at only PSCs aged under illumination (see the Figure, panel b), the increase in stability from 2015 to 2020 becomes more obvious, likely because this is a more intense aging test in which early devices faired poorly. To update _The Perovskite Database_ statistics, we added 26 data points from recent high impact studies from 2021 onwards (Table S2). From this data, we can see that in modern studies 1,000 h operational stability is readily achievable. This higher stability becomes particularly obvious when one realises that only <mark>4 of the 26 devices decayed to 80% of their original efficiency during stability testing. For the other 22, the number recorded is either the</mark> _<mark>T</mark>_ 90 <mark>,</mark> _<mark>T</mark>_ 95 <mark>or</mark> _<mark>T</mark>_ 100 <mark>lifetime. Indeed, with lifetimes extending well beyond 1000 h, researchers are turning to accelerated aging to assess stability, evidenced by the fact that 15 of the 26 devices were tested above room temperature (45 °C – 85 °C).</mark> 

9 



Panel c) of the Figure compares _n-i-p_ and _p-i-n_ cell stability. Considering cell configuration, we find that (when normalised to ISOS-L1 conditions using a simple acceleration factor model discussed in Supplementary Note 1) there is little difference in stability on average between _ni-p_ and _p-i-n_ devices, which is surprising as many state the stability of transport layers in _p-i-n_ as an advantage to the configuration.<sup>50-52</sup> Still, this equivalence is bolstered when considering our 26 recent datapoints with high stability which are evenly spread between _n-i-_ p and _p-i-n_ (Fig. S1). Finally, we find that the vast majority of PSC stability is reported in cells with bandgaps from ~ 1.5 to 1.65 eV (Panel d) of the Figure). This result is unsurprising as the majority of PSC research is in this range, but demonstrates the need for more work in the areas of low bandgap (~ 1.2 eV Pb/Sn) and wide bandgap (~ 1.8 eV) cells that are used in allperovskite tandems. Though not the subject of this review, it should be noted that in lead-free, 

10 

Sn containing perovskites, the oxidation of Sn(II) to Sn(IV) results in poorer stability for narrowbandgap PSCs.<sup>53</sup> Additionally, higher ionic conductivity and halide segregation hamper the stability of wide bandgap films with > 20% Br concentration.<sup>54</sup> 

### **[H1] Factors affecting PSC stability** 

To understand the rapid increase in PSC stability and how to improve it further, we must first understand which materials and stressors contribute. Despite differences in configuration between _n-i-p_ and _p-i-n_ devices, both consist of similar layers: the electron transporting layer (ETL), hole transporting layer (HTL), perovskite light absorbing layer, cathode and anode contacts ( **Fig. 2a and b** ). Under different external stressors (that is, illumination, thermal and bias) the instability of each constituent layer and the interfaces between layers are both important factors leading to operational instability. 

#### **[H2] Perovskite stability** 

##### **[H3] The inherent stability of perovskite structure/phase** 

Before delving into the stability of full PSCs, we should examine the intrinsic stability of the perovskite structure. The majority of highly efficient PSCs are based on a 3D perovskite in a cubic crystal phase (also known as the α-phase). The Goldschmidt tolerance factor τ (eq. X) can be used to determine the stability of a given perovskite from the ionic radii of its constituent ions: 𝜏𝜏= (𝑅𝑅𝐴𝐴 + 𝑅𝑅𝑋𝑋)/√2(𝑅𝑅𝐵𝐵 + 𝑅𝑅𝑋𝑋 ), where RA, RB and RX are the ionic radii of the corresponding ions. In general, if τ for a given A, RB and RX are the ionic radii of the corresponding ions. In general, if τ for a given , RB and RX are the ionic radii of the corresponding ions. In general, if τ for a given B and RX are the ionic radii of the corresponding ions. In general, if τ for a given  and RX are the ionic radii of the corresponding ions. In general, if τ for a given X are the ionic radii of the corresponding ions. In general, if τ for a given  are the ionic radii of the corresponding ions. In general, if τ for a given 

where RA, RB and RX are the ionic radii of the corresponding ions. In general, if τ for a given A, RB and RX are the ionic radii of the corresponding ions. In general, if τ for a given , RB and RX are the ionic radii of the corresponding ions. In general, if τ for a given B and RX are the ionic radii of the corresponding ions. In general, if τ for a given  and RX are the ionic radii of the corresponding ions. In general, if τ for a given X are the ionic radii of the corresponding ions. In general, if τ for a given  are the ionic radii of the corresponding ions. In general, if τ for a given perovskite composition is between 0.9 – 1.0, it forms an ideal cubic structure. If τ is between 0.71 and 0.9, it will form an orthorhombic structure around room temperature. For MHPs it has been 

11 

observed that if τ > 1 or τ < 0.8, then the lattice distortion generated induces a photo-inactive, nonperovskite structure to form, normally known as the δ-phase.<sup>55</sup> 

MAPbI3 has a τ value of ~ 0.9 and an ideal cubic structure at room temperature. FAPbI3 (τ of ~ 1) is near the upper boundary for a cubic structure, hence it exhibits two phases at room temperature: cubic (α-phase) and hexagonal (δ-phase). Reports have shown that high-temperature annealing (> 433 K) is required to obtain α-phase FAPbI3,<sup>56</sup> but δ-phase formation only needs a temperature ~ 285 K.<sup>57</sup> Because the δ-phase is more stable than the α-phase, it is difficult to stabilize cubic FAPbI3. In contrast, τ is approximately 0.8 for CsPbI3, which is close to the lower range for the cubic perovskite structure. The thermodynamically stable phase of CsPbI3 at room temperature is the non-photoactive δ-phase, and the photoactive α-phase is obtained by high-temperature annealing of the δ-phase (> 633 K).<sup>58</sup> 



<!-- Start of picture text -->
a b c<br>d<br>e f g h<br><!-- End of picture text -->

**Figure 3: Factors affecting PSC stability.** a) FAPbX3 (X = Br, I or mixed halide) <mark>degradation processes under illumination and thermal stress. Processes are indicated by different arrows (red indicates breaking</mark> 

12 

<mark>processes and green indicates re-forming processes), irreversible processes are indicated by a single red arrow.</mark> b) MAPbI3 perovskite degradation processes under illumination or thermal (same arrow convention) c) Energy diagram of a perovskite solar cell at -3 V showing the main processes occurring in reverse bias. (1) Hole injection: halide vacancies drift towards the hole transport layer (HTL), resulting in favorable band energetics for hole injection via trap assisted tunneling at the ETL/perovskite interface. (2) Hole drift: a strong electric field pulls the holes away from the space charge region. Holes accumulate at the edge of the region where there is no net electric field. (3) Hole diffusion: a high concentration gradient of holes in the bulk results in diffusion of the holes towards the HTL. (4) Halide oxidation by holes: part of the holes that build up in the perovskite bulk oxidize halides into neutral halogens. (5) Hole extraction into the HTL. In this band diagram EC and EV are the perovskite conduction and valence bands, respectively. EFn and EFp are the hole and electron quasi-Fermi levels, respectively. Below is the distribution of the holes injected by surface-state-assisted tunneling and accumulating close to the edge of the vacancy-depleted-region at reverse bias for a tunneling current of 0.3 mA/cm<sup>2</sup> . d) The 12 types of native point defects found in metal halide perovskites. Diffusion paths for e) VI, f) VMA, g) VPb and h) Ii defects. Panel a is adapted from REF.<sup>59</sup> Panel b is adapted from REF.<sup>60</sup> Panel c is adapted from REF.<sup>61</sup> Panel d is adapted from REF.<sup>62</sup> Panel e-h are adapted from REF.<sup>63</sup> 

##### **[H3] Perovskite degradation under thermal stress** 

Some perovskite materials will undergo decomposition reactions under thermal stress. It is important to consider both operational temperatures (- 40 °C to 75 °C. 65 °C is commonly used as the upper end of PSC operating temperature, but there is evidence that this could be as high as 70 – 75 °C.<sup>48,64</sup> ) and temperatures > 75 °C for accelerated degradation testing. Note that temperatures used for accelerated aging should not introduce  a new decay mode that would not be observed below 75 °C. MAPbX3 (X = Cl, Br, I) have low decomposition temperatures (< 100 ˚C), with MAPbI3 in particular degrading within the operational range (~ 60 °C), which likely precludes it as a stable PSC material.<sup>65</sup> 

The thermal stability of FAPbI3 is reportedly higher than MAPbI3. FAPbI3 films exposed to 150 °C for 60 mins are stable without discoloration, whereas MAPbI3 discolors after ~ 30 mins.<sup>66</sup> This enhanced stability is attributed to the stronger interaction between FA<sup>+</sup> and [PbI6]<sup>4+</sup> compared with MA<sup>+</sup> .<sup>67</sup> Despite this, FAPbI3 will undergo thermal decomposition at relatively low temperatures (> 

13 

50 ℃), where formamidinium iodide (FAI) decomposes into formamidine and HI ( **Fig 3a** ).<sup>59</sup> Both of these reactions are reversible and in a well-encapsulated device might not be fatal. When the temperature is around 95 ℃, formamidine decomposes into sym-triazine and ammonia through irreversible reactions ( **Fig. 3a).**<sup>56</sup> When the temperature exceeds the phase transition temperature of α-FAPbI3 (160 °C), FAPbI3 partially decomposes into PbI2 as FAI evaporates to HCN and NH3.<sup>68</sup> This degradation behaviour suggests that FAPbI3 has potential as a stable PSC material between -40 °C and 75 °C, though accelerated aging above 95 °C is likely non-representative. 

Because CsPbI3 does not contain volatile and decomposable organic components, it does not break down at low temperatures, and α-CsPbI3 is stable at temperatures as high as 390 °C. Above this, PbI2 volatilizes and leaves CsI as residue.<sup>69</sup> Hence, accelerated aging beyond 300 °C is feasible, though the stability of other PSC layers would come into question. 

##### **[H3] Perovskite degradation under illumination** 

UV and blue wavelengths have the strongest impact on PSC stability.<sup>70</sup> Perovskites rapidly decompose under illumination when oxygen is present, though without oxygen illumination can still trigger decomposition through simultaneous reversible and permanent reactions.<sup>71,72</sup> Our discussion will focus on illumination without oxygen, assuming high quality encapsulation. 

PbI2 films degrade into metallic Pb<sup>0</sup> and I2 gas under simulated sunlight (Xe lamp), with an activation energy ( _E_ a) of ~ 9 kcal mol<sup>-1</sup> , or 0.4 eV per Pb atom.<sup>60</sup> The activation energy is increased by a factor of 6 (~ 57 kcal mol<sup>-1</sup> ) using a white light LED. The degradation is retarded completely for photon energies less than 2.3 eV,<sup>73</sup> which is the bandgap of PbI2, suggesting that degradation is caused by light absorption. For MAPbI3 under a Xe lamp, the _Ea_ for Pb<sup>0</sup> /I<sup>2</sup> decomposition is lower than PbI2 (~ 6 kcal mol<sup>-1</sup> ) due to the lower bandgap of MAPbI3 and [PbI6] octahedral distortion which produces shorter I–I bond distances facilitating the release of I2.<sup>60</sup> Moreover, when MAPbI3 is illuminated with energies higher than 450 nm, signals from CH3NH2 and H2 are detected, indicating that the N-H bond in the perovskite can dissociate under sunlight ( **Fig 3b** ).<sup>74</sup> Though most studies examining degradation under illumination have been carried out on MAPbI3, decomposition into Pb<sup>0</sup> has been witnessed in FACs perovskites also.<sup>75</sup> 

Most perovskites with a > 20% Br to I ratio will segregate into I-rich and Br-rich regions under illumination.<sup>76</sup> Considering stability, the funneling of charges into lower bandgap (I-rich) regions 

14 

effectively reduces the maximum _VOC_ of wide bandgap devices, resulting in a ~ 10% decrease in _VOC_ over the first hour or so of operation.<sup>32,77</sup> Illumination can also induce a similar process in mixed cation perovskites in which cations aggregate leading to phase transitions. DFT simulations indicate that cation aggregation in a FA0.89Cs0.11PbI3 perovskite with a uniform distribution of cations can be triggered with relatively little energy (0.133 kJ mol<sup>−1</sup> ).<sup>78</sup> 

##### **[H3] Perovskite degradation under bias** 

In a solar module, partial shading by neighboring trees, dirt or snow prevents some of the cells from generating photocurrent.<sup>79</sup> Because all cells must pass the same amount of current for the panel to generate power, the cells that are illuminated put the shaded cells into whatever reverse bias is needed for current matching to occur. Cells in reverse bias have both short-term reversable and irreversible degradation problems. 

Several interesting observations have been made on the reverse bias behavior of perovskite solar cells. When metal electrodes are used, the metal filaments grow all the way through the device under reverse bias to create a shunt.<sup>80</sup> In a reverse bias current-voltage scan, the current increases very suddenly when the shunt forms and localized heating is observed with thermal imaging.<sup>61,81</sup> The extreme heating at the shunt causes permanent damage to most layers of the cell. In contrast, this behavior is not seen when transparent conducting oxides and carbon electrodes are used. In these cells, there is an exponential increase in current that starts typically between -1 V and -4 V when sweeping the voltage to increasing negative values. This current is enabled by the tunneling of holes from the electron transport layer due to strong band bending associated with mobile ions redistributing to screen the applied field. After passing current through a cell in reverse bias for as little as one minute, the efficiency can be reduced by more than 50%. Much, but not all, of this efficiency recovers if the cell is exposed to one sun at a positive voltage for approximately 30 mins. The rapid degradation most likely occurs because the hole density while passing the short circuit current density in reverse bias is similar to what it would be at the maximum power point under one-sun illumination, but the electron density is nearly zero. Consequently, the holes can oxidize iodide more rapidly to form smaller neutral iodine species that can move to interstitial sites, creating a vacancy in the process. With few electrons being present, the reverse reaction is slow. The iodine interstitials act as recombination centers, which dramatically reduces the efficiency of the cell. During the recovery process at positive voltage, the iodine interstitials are reduced and return to the octahedral corners. The recovery only occurs, however, if the iodine 

15 

species stay in the perovskite film. For this reason, internal barriers that confine the iodine to the perovskite are critically important. 

If strategies for preventing degradation in reverse bias are not found, then engineering solutions for preventing degradation due to partial shading will be needed. In silicon solar panels, strings of cells are protected by a few bypass diodes that are located in the junction box. The current can be routed to the diodes through metal ribbons. The approach could be used relatively easily in panels made with perovskite-silicon tandems.<sup>82</sup> The breakdown voltage of the tandem is the sum of the breakdown voltages of the subcells. Many tandems can be protected by one bypass diode because of the high breakdown voltage of silicon. It is not clear, however, how to use bypass diodes in thin film panels in which cells with a length greater than a meter are separated from each other by laser scribes. If one of these cells were shaded, some of the current would have to travel as far as the length of the cell to get to the bypass diode on the edge of the panel and then travel back. One of the electrodes would likely be a transparent conducting oxide and the voltage drop over such a large distance would be excessive. It is for this reason that bypass diodes are typically not used in commercial CdTe solar panels. 

It is quite possible that the degradation in reverse bias is similar in nature to what happens under one sun at the maximum power point in good solar cells that do not have weaknesses associated with poor packaging, mobile additives or reactive electrodes. Because degradation in reverse bias is approximately 100,000 times faster, it might offer an excellent way to test new materials and processing conditions rapidly to assess their impact on stability. In particular, reverse biasing can be used to generate mobile iodine in order to assess barrier quality ( **Fig. 3c** ). 

##### **[H3] The effect of defects on PSC stability** 

A large number of defects are generated during perovskite crystallization. Defect densities > 10<sup>14</sup> cm<sup>-3</sup> have been reported for optimized perovskite thin films,<sup>83</sup> the majority of which appear at surfaces and grain boundaries. Perovskite composition and fabrication conditions have a substantial influence on defect type and concentration.<sup>84</sup> The primary defects affecting PSC performance are point defects at grain boundaries or surfaces,<sup>85</sup> including antisites (MAPb, MAI, PbMA, IMA and IPb), interstitials (MAi, Pbi and Ii) and vacancies (VMA,VPb and VI) ( **Fig. 3d** ).<sup>86</sup> MHPs 

16 

are defect tolerant materials but even shallow defects can lead to non-radiative recombination and reduce _VOC_ , albeit to a much lesser extent than traditional semiconductors. More important to stability, defects facilitate ion migration meaning defects migrate ( **Fig. 3e-h** ),<sup>87</sup> accumulate and propagate leading to irreversible degradation.<sup>62</sup> 

Calculations of ion migration activation energies find that halide ions contribute the most to ion migration (5 times higher that MA or Pb, for example<sup>63</sup> ). Ion migration energies vary due to measurement, perovskite composition, defect densities and PSC fabrication, however values between 0.1 eV and 0.9 eV have been reported.<sup>10,88-90</sup> Typically, these values are calculated as a function of temperature only, however ion migration is governed by temperature and illumination. For example, ion migration activation energy has been observed to decrease substantially (0.29 eV to 0.1 eV) when films are under low intensity illumination (10 mWcm<sup>-2</sup> ).<sup>91</sup> 

Defects also collect and trap carriers, inducing irreversible degradation of perovskite.<sup>92,93</sup> Two deep level trap bands, I (0.27 eV) and II (0.36 eV) have been observed in iodine-based PSCs which correspond to iodide interstitials (Ii<sup>-</sup> and Ii<sup>+</sup> ). Under reverse bias, a trap-filling process occurs between Ii<sup>-</sup> and the injected holes (h<sup>+</sup> ), to form Ii<sup>0</sup> . The Ii<sup>0</sup> can be oxidized to Ii<sup>+</sup> by the valence band (VB) oxidation<sup>94</sup> or can form I2 through a bimolecular reaction, which induces iodide loss and leads to irreversible degradation.<sup>61,95</sup> 

#### **[H2] The effect of metal electrodes on PSC stability** 

Most highly efficient PSCs use a metal top electrode; gold is the most-used electrode in _n-i-p_ devices, and copper or silver for _p-i-n_ devices. Metal electrodes are easily corroded by halides that migrate from the perovskite layer, which reduces conductivity over time. Furthermore, metal ions generated by corrosion can migrate into the perovskite accelerating PSC degradation.<sup>96</sup> For example, iodide on perovskite film surfaces can diffuse through CTLs to the surface of a silver electrode. The ions react with silver and form silver iodide (Ag-I), an insulating layer that hinders charge transport.<sup>97</sup> The opposite is also possible. Au<sup>-</sup> can migrate through spiro-OMeTAD into the perovskite layer under 70 °C annealing to induce perovskite degradation.<sup>98</sup> It is believed that under illumination, the ion migration in perovskites is reversible and does not cause permanent degradation. However, when ions, especially halides, migrate to a metal electrode and react, this causes irreversible degradation.<sup>99</sup> 

17 

#### **[H2] The effect of charge transport layers on PSC stability** 

For highly efficient PSCs, charge transport layers (CTLs) are indispensable. Any physical or chemical alteration of the transport layer material, the perovskite/CTL interface<sup>100</sup> or the CTL/electrode interface can affect the long-term stability of PSCs.<sup>101</sup> 

For example TiO2, a common electron transporting material in _n-i-p_ PSCs, has abundant oxygen vacancy defects (Ti<sup>3+</sup> sites - especially at the surface) that are effectively deep electron-donating sites. In the presence of ultraviolet light, iodide ions at the perovskite/TiO2 interface can be oxidized into iodine, resulting in the decomposition of the perovskite.<sup>102</sup> NiOx and PEDOT:PSS can undergo photo or chemical reactions with lead halides. On the contrary, PTA and PTAA appear inert to lead halides.<sup>103</sup> Currently, spiro-OMeTAD-based PSCs hold the record for single-junction PSC efficiency. Pristine spiro-OMeTAD has intrinsically low hole-mobility. As such, it is necessary to increase the hole mobility by adding additives, with the most used additives being LiTFSI and tBP.<sup>104,105</sup> Although Li-TFSI and tBP improve PSC performance, they also bring challenges to long-term stability. tBP can corrode the perovskite layer through reaction with PbI2 and Li<sup>+</sup> in Li-TFSI can diffuse into the perovskite interior and decompose the perovskite structure.<sup>106-108</sup> 

### **[H1] Strategies for stable PSCs** 

Several stability enhancing strategies have been developed, such as increasing ion migration energies and crystal stability through alloying, protecting the perovskite and CTLs from external stressors and passivating interfacial defects using barrier layers, decreasing defect density and suppressing ion migration using functional additives, and using robust CTLs ( **Fig. 4 and 5** ). 

18 



<!-- Start of picture text -->
a b<br>c d e<br>f g h<br><!-- End of picture text -->







**Figure 4: Strategies for stable PSCs.** a) Effect of A cations on the valence band maximum (VBM) and the conduction band minimum (CBM) of different perovskite systems, obtained from ultraviolet photoelectron spectroscopy (UPS) and inverse photoemission spectroscopy (IPES) spectra. For better comparability, the curves are offset vertically and the high energy cutoffs are aligned at the excitation energy of 21.22 eV, marked by line A. Lines B, C and D indicate characteristic features in the DOS, corresponding to the position of Cs, MA, and FA related states, respectively. The extracted positions of VBM and CBM are given by black vertical markers, and the Fermi level positions are marked by triangles. b) _T_ 80 lifetime statistics for mixed-cation, mixed-halide perovskite film with different Br concentrations. Each Br concentration contains results from 32 different cation compositions. Films were tested at 65°C and one-sun illumination. c) A perovskite solar cell (PSC) using a 2D Cs2PbI2Cl2 layer atop the 3D perovskite active layer; d) PSC using a Bi interlayer and schematic of its shielding capability, prohibiting both inward and outward permeation. e). Schematic illustration of perovskite films protection through in situ formation of a lead sulfate top layer on the perovskite surface. f) Calculated crystal structure illustrating 

19 

the passivation of an I<sup>−</sup> vacancy at the FAPbI3 surface by a HCOO<sup>−</sup> anion. All chemical species are shown in ball-and-stick representation. Pb<sup>2+</sup> , yellow; I<sup>−</sup> , pink; oxygen atoms, red; carbon, green; nitrogen, blue; hydrogen, white. g) FTIR spectra of PbI2· PMMA prepared by mixing PMMA with PbI2 in a molar ratio of 1:1, and the pristine PMMA films. The arrows indicate the stretching vibration peak of C=O in the two films. This shift in FTIR signal indicates the existence of a C=O, PbI2 adduct which regulates crystallization. h) Illustration of an ion modulated radical doping strategy for spiro-OMeTAD developed by Gao et al. Panel a is adapted from REF.<sup>109</sup> Panel b is adapted from REF.<sup>27</sup> Panel c is adapted from REF.<sup>10</sup> Panel d is adapted from REF.<sup>110</sup> Panel e is adapted from REF.<sup>91</sup> Panel f is adapted from REF.<sup>111</sup> Panel g is adapted from REF.<sup>112</sup> Panel h is adapted from REF.<sup>113</sup> 

#### **[H2] Perovskite phase stabilization** 

##### **[H3] A-cation alloying** 

The A-site in the perovskite crystal structure does not directly affect the band edge states as these states are formed from Pb and halide orbitals. It does, however, affect the bandgap indirectly through changes to octahedral tilting or distortion of the MX6 framework, which changes the B-X bond length and induces VBM and CBM changes ( **Fig. 4a** ).<sup>109,114</sup> Indeed, as the size and geometry of the A cation affects the bond length and bond angle of the perovskite crystal, it has great influence on the crystal stability and the electrical properties of the perovskite. 

FAPbI3 has a narrower band gap (1.48 eV) than that of MAPbI3 (1.6 eV) ( **Fig. 4a** ), thus FAPbI3based perovskites are preferred as their bandgap is closer to optimal for maximum device efficiency (1.34 eV).<sup>115</sup> Indeed, the majority of high-efficient PSCs are FAPbI3-rich recipes. However, due to the tolerance factor for FAPbI3 being close to 1, FAPbI3 will naturally lose its cubic phase at room temperature. To stabilize α-FAPbI3, partial replacement of FA<sup>+</sup> with smaller radii cations (MA<sup>+</sup> , Cs<sup>+</sup> , Rb<sup>+</sup> ) is used. The introduction of MA<sup>+</sup> enables the perovskite to obtain its α-phase at a lower temperature than pristine FAPbI3,<sup>116</sup> but is generally thought to decrease the light and thermal stability of FAPbI3 perovskite as MA<sup>+</sup> is more volatile than FA<sup>+</sup> .<sup>117</sup> Counterintuitively, up to ~ 10% MA incorporation has been shown to improve stability.<sup>27,118</sup> 

Partially replacing FA<sup>+</sup> with smaller radii cations like Cs<sup>+</sup> not only stabilizes α-FAPbI3 but also improves thermal stability due to the strong chemical bonding between Cs<sup>+</sup> and [PbI6]<sup>4+</sup> . Cs0.1FA0.9PbI3 has shown better photo and moisture stability compared to FAPbI3. This stability is attributed to the introduction of Cs<sup>+</sup> that shrinks the perovskite crystal cubo-octahedral volume and 

20 

increases the A-site-I bond energy.<sup>117</sup> To further improve stability, complex mixed cation systems have also been explored, such as CsMAFA and RbCsMAFA. Adding more elements increases the entropy of mixing to stabilize the perovskite phase.<sup>45,119</sup> 

Various other methods to stabilize α-FAPbI3 have been discussed in the literature (for example employing pseudo-halides<sup>111</sup> or using methylenediammonium<sup>43</sup> or isopropylammonium<sup>120</sup> as additives). For many of these, it is unclear whether perovskite alloying has occurred. Including a small amount of Cs<sup>+</sup> or MA<sup>+</sup> to stabilize FAPbI3 results in a non-cubic perovskite crystal structure with a ~ 2° octahedral tilt at room temperature.<sup>121</sup> This α-phase stabilization is not exclusive to alloying additives as it can also be achieved by additives at the perovskite grain boundaries. Moreover, if alloying cations are unevenly distributed, nano-scale local regions of perovskite can lose their 2° tilt, forming regions of hexagonal polytypes that expand over time, resulting in δ- phase formation.<sup>121</sup> Increasing the annealing temperature or the annealing time results in more homogenous mixing of A-site cations and higher PSC stability.<sup>122</sup> 

Introducing large radius cations such as PEA<sup>+</sup> or BA<sup>+</sup> into FAPbI3 perovskite is another important strategy to improve perovskite stability.<sup>123</sup> The exchange of large radii cations leads to the collapse of the three-dimensional perovskite crystal structure and the introduction of a quantum confined, usually 2D structure.<sup>124</sup> If large A-cations are mixed directly into the perovskite precursors, then a mixed, quasi-2D film containing various thicknesses of 2D and quasi-2D perovskite tends to form. This mixed film has enhanced stability due to an increased hydrophobicity and the presence of large-cation layers hindering ion transport, but lower efficiency due to an increased bandgap, decreased mobility and higher exciton binding energies.<sup>125</sup> Applying 2D perovskite atop the bulk 3D to passivate the surface and block ion transport out of the cell can be used to remediate these issues. 

A summary of operational stability enhancements from A-site alloying is found in Table S3. 

##### **[H3] X- anion alloying** 

Unlike the A-site cation, the X-site anion directly contributes to the band edge of the perovskite. Replacing I<sup>-</sup> with Br<sup>-</sup> or Cl<sup>-</sup> can tunes the bandgap, can regulate perovskite grain growth and improve the chemical stability of perovskite films. Partially replacing I<sup>-</sup> with Br<sup>-</sup> can suppress the δ-phase formation of FA-rich or Cs-rich perovskites,<sup>126,127</sup> and perovskites with 5% Br has shown better _T_ 80 stability ( **Fig. 4b** ).<sup>27</sup> 

21 

The introduction of Cl<sup>-</sup> into perovskite precursors can substantially improve the quality, morphology<sup>128</sup> and crystallinity of majority iodine perovskites, although whether Cl alloys into the perovskite is still debated and likely depends on various factors.<sup>129</sup> Introducing MACl into FAPbI3 perovskite is one of most popular methods to prepare stable α-FAPbI3 films<sup>130</sup> , as the Cl-containing perovskite system is more thermodynamically stable and the introduction of MA shrinks the volume of the FAPbI3 crystal, which also improves the stability of the perovskite structure.<sup>131</sup> In wider band gap perovskites that contain important amounts of Cs and Br, the lattice parameters are smaller and more chlorine can be incorporated on the X site.<sup>132</sup> These compounds are more stable against light-induced phase separation. 

##### **[H3] All-inorganic perovskites** 

All-inorganic perovskites (Cs,Rb)Pb(I,Br)3 are more thermally stable than their hybrid counterparts. Because the bandgaps of all-inorganic perovskites are wider than FA-based perovskites, they are typically considered for tandem applications. The narrowest bandgap available is CsPbI3 (~1.7 eV) which is well matched for Si/perovskite tandems. Like for FAPbI3, the photoactive phase of CsPbI3 is difficult to maintain at room temperature. Many strategies have been developed to stabilize α-CsPbI3: A-cation alloying, X-anion alloying and additive engineering. For example, 18-crown-6 ether has been used as an additive to stabilize the cubic phase of CsPbI3, and devices maintained ∼ 91% of their initial PCE after 1000 h in N2 at 85 °C.<sup>133</sup> PVP has likewise been used, with PSCs showing no visible decrease in PCE after 3,500 h at 35 °C, and decreasing by only 20% after 2100 h under continuous illumination at 110 °C ( **Fig. 4c** ).<sup>10</sup> 

Though highly thermally stable, all-inorganic PSCs tend to suffer from lower efficiencies than their hybrid counterparts. These lower efficiencies have been attributed to high defect densities induced by fast crystallization, resulting in short carrier lifetimes and low photoluminescent quantum efficiency (PLQE).<sup>134</sup> To improve efficiency, dimethylammonium has been used to stabilize the β-phase CsPbI3 and to control perovskite crystallization,<sup>135</sup> and surface treatments have been employed to reduce surface defect densities.<sup>134</sup> Using a CsF surface treatment, an allinorganic PSC with a 1.74 eV bandgap achieved 21% PCE;<sup>136</sup> ~75% of the thermodynamic limit. The highest performing hybrid perovskites can achieve > 80% of this limit,<sup>137</sup> so there is some room for improvement. The carrier lifetimes recorded for these all-inorganic films are roughly one 

22 

quarter that of the highest performing hybrid films (~700 ns compared to ~2900 ns) suggesting that defect densities can be further reduced. 

#### **[H2] Barrier layers for stable PSCs** 

Barrier layers are thin layers deposited at interfaces within a PSC to improve efficiency and stability. These layers can protect from external stressors (such as moisture or UV light), passivate interface defects, block ion migration and inhibit interfacial chemical reactions.<sup>138</sup> 

##### **[H3] CTL/electrode interface barrier layers** 

The main function of a barrier layer at the CTL/anode interface is to block the migration of perovskite and metal ions crossing the interface without reducing conductivity. There are various barrier layers in use (metal oxides,<sup>139</sup> graphene<sup>140</sup> and organic SAMs<sup>141</sup> ). An illustrative example is Au or Ag infiltration in PSCs aged at high temperature. Introducing 10 nm of chromium between an Au anode and the HTL entirely mitigates Au infiltration into the perovskite layer after 75 °C aging under light, suggesting Cr is an effective barrier to metal ion migration.<sup>98</sup> Alternatively, bismuth interlayers can protect metal electrodes from iodine corrosion or perovskite ingress, preventing all detectable Ag infiltration into the perovskite layer after aging at 85 °C for 100 h under light. Bismuth-protected devices maintain 95% and 97% of their initial PCE after 500 h under 85 °C and light soaking conditions respectively.<sup>110</sup> Transparent conductive oxide (TCO) electrodes such as indium tin oxide (ITO) or indium zinc oxide (IZO) can also reduce ion infiltration and increase stability. The most effective TCO layers are fabricated by sputter deposition, but high energy sputtering can easily damage other layers. Atomic layer deposition (ALD) can remediate this issue as has been demonstrated with SnO2 in both perovskite tandems and single junction devices.<sup>142</sup> SnO2 can act as a barrier layer in its own right, or in conjunction with a sputtered TCO layer.<sup>143</sup> 

Alternatively, one can replace metal electrodes with carbon electrodes to avoid degradation due to electrode corrosion or metal ion migration. Interface barrier layers are often used to improve the contact or energy level alignment between the carbon electrode and the perovskite layer, partially offsetting the efficiency decrease caused by the carbon electrode.<sup>144</sup> 

##### **[H3] Perovskite/CTL interface barrier layers** 

The high surface defect density of perovskite films accelerates degradation while corrupting other layers through ion migration. Barrier layers that can passivate surface defects and block ion migration are highly attractive. Various materials have been demonstrated as perovskite/HTL 

23 

interface barrier layers including 2D materials,<sup>145</sup> QDs,<sup>146</sup> metal oxides,<sup>147,148</sup> functional polymers,<sup>149</sup> small molecular compounds<sup>150,151</sup> and ammonium salts.<sup>152,153</sup> The most popular passivation/barrier layer in modern PSCs is a layer of 2D perovskite, with several reports of good operational stability at ≥ 60 °C in 2022 alone.<sup>9,10,51,154</sup> For example, pure-phase 2D perovskite single crystals dispersed in acetonitrile were coated onto 3D perovskite to form a highly controllable 2D/3D interface. An advantage of 2D perovskite is its relatively high conductivity compared to other insulating barrier layers, meaning layers up to 80 nm in thickness have been employed without resistive losses.<sup>155</sup> Using a conformal 50-nm-thick 2D layer, devices with > 23% PCE were fabricated, which also demonstrated a T99 > 2000 h following the ISOS-L-1 (MPP, 60 °C) protocols, a dramatic increase compared to control devices ( _T_ 80 of ~ 500 h) ( **Fig. 4d** ).<sup>9</sup> Depositing CsCl onto CsPbI3 has been used to form an all-inorganic 2D/3D heterostructure ( **Fig 4c** ). This strategy increased the barrier to ion migration in PSCs by a factor of 2 and increased the _T_ 80 stability (ISOS-L3) by a factor of ~ 3 at 110 °C to > 2000 h. Device stability was measured at several temperatures and used to extrapolate the _T_ 80 lifetime at 35 °C to be ~ 5 years.<sup>10</sup> 

Using non-2D perovskite barrier layers, such as inorganic lead sulfate, also lead to impressive stability results. For example, though the ion migration energy of control devices is ~ 0.1 eV, no transition to ionic transport was observed in lead-sulfate-capped PSCs below 55 °C ( **Fig. 4e** ). Using this technique produced > 20% PCE cells with a _T_ 97 > 1000 h at 65 °C (ISOS-L3).<sup>91</sup> In addition, hybrid material ferrocenyl-bis-thiophene-2-carboxylate (FcTc2) strongly binds to the perovskite surface and effectively prevents surface MA<sup>+</sup> from escaping the film under light (1-sun) and heat (85 °C). Devices with PCE ~ 24% exhibited a _T_ 98 of 1,500 h (ISOS-L1, room temperature).<sup>156</sup> 

#### **[H2] Additive engineering** 

Perovskite grain boundaries and surfaces are vital to the stability of PSCs as they contain the majority of defects, and these defects tend to propagate over time.<sup>15,157</sup> Reducing the density of defects at grain boundaries inhibits degradation and ion migration. Both functional materials and solvent additives can regulate crystallization to increase grain size and passivate grain boundaries.<sup>158</sup> This section investigates the effects of salts and organic compound additives on PSC stability. 

24 

##### **[H3] Additive salts** 

A popular set of additives are organic ammonium halide salts. These additives exist in different formations at perovskite grain boundaries and surfaces. Some ammonium species form lowdimensional perovskites, which improve PSC stability by inhibiting ion migration.<sup>159,160</sup> Alternatively, organic cations with large molecular volumes, such as NH3I(CH2)8NH3I, cannot form low-dimensional perovskite but can heal surface defects through hydrogen bonding, X-site vacancy passivation (halogens) and NH3 groups binding to A-site vacancies or Pb−X antisite defects.<sup>2,161</sup> 

Ionic liquids (ILs) are increasingly used to improve the stability of PSCs through three mechanisms<sup>162</sup> . First, the IL reacts with PbI2 to form an intermediate complex, which increases the activation barrier to perovskite nucleation growth thus increasing grain size and reducing grain boundary density. Next, the formation of hydrogen bonds between the IL and MA<sup>+</sup> or FA<sup>+</sup> inhibits relevant ion migration, thereby increasing PSC stability. Finally, ILs have various functional groups that can passivate different perovskite surface defects, suppress ion migration and retard lead oxidation and the compositional segregation of perovskites. Formamidinium formate (FAHCOO) was used to fabricate > 25% PCE PSCs with a _T_ 80 of 400 h (compared to 150 h for control devices) ( **Fig. 4f** ).<sup>111</sup> 



25 

**Figure 5: PSC stability overview. The** green lines represent causes and effects (see arrow direction), the yellow lines represent mitigation strategies and the blue lines specific implementations. MA is methylammonium, FA is formamidinium, TCO is transparent conductive oxide, 2D/3D represents the use of a 2D/3D heterostructure solar cell, SAMs are self assembled monolayers, CuSCN is copper thiocyanate, Poly-TPD is Poly[N,N’-bis(4-butylphenyl)-N,N’bis(phenyl)benzidine], ALD stands for atomic layer deposition, CTL stands for charges transport layer. Spiro is 2,2',7,7'-Tetrakis(N,N-di-p-methoxyphenylamine)-9,9'-spirobifluorene. 

##### **[H3] Organic compounds as additives** 

Organic compounds are one of the most commonly used perovskite additives. These materials contain N-donor, S-donor or O-donor groups. The electron lone pair of these groups can react with lead halide precursors to form complexes that, similarly to ILs, retard the nucleation rate of perovskites and reduce the density of grain boundaries.<sup>163</sup> Concurrently, these electron donors effectively passivate perovskite defects, thereby improving the stability of PSCs. Some oligomer additives can also be used as linkers between grains to improve grain boundary stability.<sup>164</sup> Besides the above functions, conjugated organic additives can modify energy-level alignment to promote carrier extraction at interfaces, inhibiting the accumulation of charges and improving stability.<sup>165,166</sup> 

A notable example is PMMA, which contains C=O functional groups. When PMMA is added to a perovskite precursor solution, an intermediate adduct is formed between C=O and PbI2 ( **Fig. 4g** ). The intermediate adduct formation effectively regulates the crystallization process of the perovskite and increases the perovskite crystal size significantly.<sup>112</sup> As another example, the theophylline molecule contains N-H and C=O functional groups. The N-H groups can form a hydrogen bond with iodine and assist the interaction of C=O with antisite Pb (lead) defects on the perovskite surface leading to suppressed ion migration, devices with theophylline showing better stability under operation.<sup>167</sup> 

It should be noted that there is currently no standard for evaluating which type of additive is better, nor is there any authoritative comparative study indicating additive hierarchy. At present, there is consensus in the field of PSCs that materials containing S, N, O or P atoms can form adducts through Lewis acid-base reactions with lead atoms, which regulate perovskite crystallization and 

26 

reduce defects in perovskite films.<sup>163,168</sup> However, how best to comparably evaluate the efficacy of different additives remains a problem for the field. 

#### **[H2] Robust transport materials and relevant additives for stable PSCs** 

For _p-i-n_ PSCs and _p-i-n_ based tandem devices, the most commonly used HTLs (PTAA, NiOx and SAMs) have shown good stability,<sup>42,50</sup> and ALD SnOx as ETL can show good stability and high efficiency. For _n-i-p_ devices, SnO2 appears to effectively solve the instability induced by TiO2,<sup>169</sup> but resolving the instability induced by spiro-OMeTAD whilst ensuring higher efficiency is a challenge.<sup>170-172</sup> Here we highlight work on improving the stability of spiro-OMeTAD and on the development of additive-free HTMs, as many HTM additives cause degradation when they diffuse into the perovskite. 

PSCs with record efficiency have consistently been fabricated in the _n-i-p_ structure. SpiroOMeTAD is the best performing HTM for these cells in terms of efficiency, but, spiro-OMeTAD requires dopant additives to increase its mobility, and stability problems caused by additives in spiro-OMeTAD have resulted in consistently poor stability from record devices ( **Fig. 2c** ). To solve or offset the negative effects of spiro-OMeTAD additives, several strategies have been employed, including reducing the use of additives,<sup>173</sup> introducing Li<sup>+</sup> complex agents to inhibit Li<sup>+</sup> migration,<sup>174,175</sup> introducing substances with hydrophobic groups<sup>176</sup> and developing new doping regulators.<sup>177</sup> For example, stable organic radicals have been used as dopants along with ionic salts as doping regulators to oxidize spiro-OMeTAD and increase its hole mobility ( **Fig. 4h** ). The efficiency of devices made using this method exceeded 25% PCE, with the _T_ 80 of unencapsulated devices aged at 70 °C (measured in a N2 glovebox) increasing from ~ 264 to ~ 796 h.<sup>113</sup> 

Many researchers are focused on the development of additive-free HTMs including organic small molecule materials,<sup>104,178</sup> polymers<sup>179</sup> and inorganic hole-transport materials.<sup>180</sup> For example, PSCs using compact, conformal CuSCN as a HTL have recorded PCEs exceeding 20% and show excellent stability at 60 °C over 1000 h.<sup>181</sup> Furthermore, the efficiency of additive-free, polymerHTL-based PSCs has exceeded 24% and maintain 80% original efficiency after ~ 1,000 h under one-sun irradiation (white LED, 100 mW cm<sup>−2</sup> , 25 °C, under N2).<sup>182</sup> 

### **[H1] Accelerated lifetime testing** 

27 

It is impractical to use decades-long protocols for stability testing. Hence, correlation between accelerated testing protocols, degradation models and real-world outdoor testing were used to establish the IEC standards used to certify Si PV panels.<sup>183</sup> These standards do not extend to perovskite PV as the acceleration factors (AFs) used to correlate simulated and real-world testing are different.<sup>40</sup> Additionally, perovskite PV demonstrates behavior unknown in Si PV related to ion migration and electrochemistry, such as performance recovery under dark conditions.<sup>184,185</sup> 

There are two purposes to stability testing. The first is to identify the rough operational stability of a device in comparison to a control or another study – this type of reporting is common across PSC research. The second is to identify the failure modes of devices and to develop a model for how devices degrade with time. Considering that many PSCs have been reported with little to no degradation under ISOS-L1 conditions for > 1000 h,<sup>9,51,186</sup> accelerated testing and modeling of degradation modes is becoming ever more important. This concept has been used successfully in organic photovoltaics (OPV) and in Si PV where degradation is assumed to derive from a set of individual activation energies that interact multiplicatively,<sup>187</sup> but has seldom been used in perovskite PV. 

In OPV and Si PV, thermally-induced decay is modeled using the Arrhenius equation, to which light intensity is simply assumed to apply multiplicatively. For example, for an arbitrary decay function with some number of constant decay rates 𝑘𝑘, where each decay rate represent a different decay mode in the material, (such as halide migration, 𝑃 **𝑃** 𝑃𝑃(𝑡𝑡) = 𝑓𝑓(𝑘𝑘1, 𝑘𝑘2, 𝑘𝑘3, … , 𝑡𝑡) + 𝑃𝑃 

where each decay rate represent a different decay mode in the material, (such as halide migration, 𝑃 **𝑃** cation diffusion, B-site oxidation…). Traditional models use<sup>**𝑎**</sup> 



<!-- Start of picture text -->
 � 1 − 1 �<br>𝐴<br>𝐸𝐸𝑎<br>𝑘𝑘𝑏𝑏 𝑇𝑇𝑟 𝑟 𝑟𝑟 𝑇𝑇𝑎 𝑎 𝑎𝑎<br>=  𝑘𝑘𝑎 𝑎 𝑎𝑎<br>= 𝑒𝑒<br>𝑘𝑘𝑟𝑟 𝑟 𝑟𝑟<br>𝑃𝑃𝑎𝑎𝑎𝑎is the activation energy for thermal<br>𝑟 𝑎<br><!-- End of picture text -->

**𝑟 𝑎**<sup>**𝑎**</sup> 𝑘𝑘𝑟𝑟 **𝑟** 𝑟𝑟 as the acceleration factor for thermal degradation, where 𝑃𝑃𝑎𝑎𝑎𝑎is the activation energy for thermal light intensity, a factor is multiplied such that degradation and 𝑇𝑇𝑟 **𝑟** 𝑟𝑟 and 𝑇𝑇𝑎 **𝑎** 𝑎𝑎 are reference and elevated temperatures respectively.<sup>187</sup> To include **𝐴 𝐴 𝐴**<sup>**𝑎**</sup> 



<!-- Start of picture text -->
𝑟 𝑎<br> � 1 −  1 �<br>𝐸𝐸𝑎<br>𝑘𝑘𝑏𝑏 𝑇𝑇𝑟 𝑟 𝑟𝑟 𝑇𝑇𝑎 𝑎 𝑎𝑎<br>𝐴 𝐴 𝐿𝐿+𝑇𝑇 = 𝐴 𝐴 𝐿𝐿𝐴 𝐴 𝑇𝑇  = 𝐼𝐼𝑎 𝑎 𝑎𝑎  𝑒𝑒<br>𝐼𝐼𝑟 𝑟 𝑟𝑟<br><!-- End of picture text -->

28 

Depending on the decay mode, one might find that only some decay rates are affected by heat and where 𝐼𝐼𝑎 **𝑎** 𝑎𝑎 and 𝐼𝐼𝑟 **𝑟** 𝑟𝑟 represent the light intensity of accelerated and reference testing respectively. others by illumination intensity.<sup>10</sup> For example, a simple model for N2-encapsulated CsPbI3 PSCs that considers only one light intensity has been reported.  The PCE of devices with and without a 2D capping layer degraded according to a biexponential relationship, with two decay rates. Interestingly, both decay rates followed the same relationship with temperature, so were both derived from the same activation energy. Fitting data to this simple model found good agreement, and the lifetime of cells operated at 35 °C could be predicted to be > 5 years ( **Fig 6a,b).** This result is even more impressive when considering that these cells were under constant 1-sun illumination which is roughly 5 times the average irradiation experienced by a typical real-world panel, suggesting a similar lifetime to that of established PV technology.<sup>30</sup> 

An interesting finding from this work is that the common fast initial decay, often classified as “burn-in,” could be generated by the same mechanism that causes slow long-term decay. What is still unclear, however, is why ion migration has two different decay modes and to what extent each of them is reversible. 



29 

**Figure 6: Accelerated aging.** a) Results from accelerated aging at different temperatures for CsPbI3 all-inorganic perovskite solar cells (PSCs). b) Modeling this data using an Arrhenius factor fitting to calculate an acceleration factor (AF), suggesting that the cell aged at 35 °C should have a _T_ 80 > 5 years. c) Summary of a more complex aging model incorporating light intensity, temperature, oxygen and moisture. d) Maximum power point (MPP) tracked PSC data at 10-sun intensity using a <mark>FTO/SnO</mark> 2 <mark>/PCBM/FA</mark> 0.83 <mark>Cs</mark> 0.17 <mark>PbI</mark> 2.7 <mark>Br</mark> 0.3 <mark>/PTAA/Au structure. e) Data comparing MPP tracked PSCs using constant 1-sun intensity and light cycling. The light cycled devices produced 96% of its initial efficiency on average throughout the 250 h test, whereas the device under constant illumination produced only 88% of its initial efficiency on average. f) Average absolute difference (ΔPCE) of the PCE(</mark> _<mark>T,I</mark>_ <mark>) measured during the Tress aging experiment.</mark> Panel a and b are adapted from REF.<sup>10</sup> Panel c is adapted from REF.<sup>188</sup> Panel d is adapted from REF.<sup>189</sup> Panel e is adapted from REF.<sup>184</sup> Panel f is adapted from REF.<sup>190</sup> 

A more comprehensive model for MAPbI3 that includes humidity, oxygen, light intensity as well as temperature has been developed ( **Fig. 6c** ).<sup>188</sup> In this model, the light intensity AF is (Iacc/Iref)<sup>0.7</sup> , so less important than the linear multiplicative factor used for established PV, but still indicates that high light intensities could substantially speed up degradation testing. Little work has been done on accelerated testing using high light intensities, though two reports demonstrate stability up to 10-sun intensity ( _T_ 90 ~ 150 h, **Fig. 6d** ) suggesting this could be a useful parameter to accelerate testing timescales.<sup>189,191</sup> 

Another key consideration when selecting accelerated testing scenarios is the effect of cycling aging conditions as, in real-world use, a large discrepancy between light-cycled devices (12 h light, 12 h dark) and continuously-illuminated devices will occur. For example, in one study, a lightcycled device yielded an average efficiency of 96% initial PCE across 250 h, compared to a continuously-illuminated cell that averaged only 88% initial efficiency ( **Fig. 6e** ). In the same study, temperature-cycled devices (65 °C to - 10 °C every 2 h) degraded at a rate inbetween devices held at either -10 °C and 65 °C respectively.<sup>184</sup> Monitoring the performance of a device subjected to simulated weather conditions from two days of each month in the year resulted in several interesting observations. Over the course of each day, the PSC degraded substantially compared to what was expected from single MPP measurements at each light intensity and temperature. Initially, the degradation was reversible and the device completely recovered by the second day, but the proportion of reversible decay reduced over time and after the first week most degradation was irreversible. Exposure to high light intensities appeared to dominate PSC degradation rather than high temperatures ( **Fig. 6f** ). Understanding what causes reversible and irreversible change to 

30 

PCE is a pertinent question for future testing. Even this small pool of results suggests that many different testing conditions need to be applied, modeled and compared to build up a reliable testing protocol. 

Testing with multiple stressors at once is essential to obtain reliable results. For example, in one study, encapsulated <mark>Cs</mark> 0.05 <mark>FA</mark> 0.8 <mark>MA</mark> 0.15 <mark>Pb(I</mark> 0.85 <mark>Br</mark> 0.15 <mark>)</mark> 3 <mark>cells showed no degradation after 2000 h of IEC standard damp-heat testing. When subjected to MPP tracking under illumination, however, the same cells degraded to 80% of their initial PCE in a few tens of h under illumination at an elevated temperature (45 °C).</mark><sup>192</sup> <mark>To combat this discrepancy, researchers should compare different aging conditions individually and in combination. First, researchers should find an encapsulation technique that can allow cells to pass the IEC61215:2016 damp-heat test (85 °C/85%RH), and then operational testing under different light and temperature conditions should be examined. These conditions should include varying light intensity (0.1 to 10 suns – with and without UV light), temperature cycling (- 40 °C to 85 °C) and light cycling (0 to 1 sun).</mark> 

### **[H1] Perspective and conclusion** 

For many years now, stability rather than efficiency has been the most pressing issue in PSC research. In this time, great progress has been made and the field has produced a toolbox with which we can fabricate highly stable PSCs. Indeed, it should come as no surprise that the strongest operational stability reported to date (REF.#10) used PSCs that are all inorganic (high temperature stability), have Cr/Au electrodes, and use 2D perovskite and Al2O3 barrier layers. Clearly the field is advancing and by employing many stability enhancing techniques in parallel, multiyear operational stability has been achieved. 

A few final pieces are needed to demonstrate long-term stability: accurate models that allow faster accelerated aging on a wider range of PSCs, methods to increase predicted _T_ 80 stability to > 25 years and techniques to upscale stable methods for large area modules. Here, we give our view on how best to approach these challenges. 

#### **[H2] Modelling degradation** 

In theory, one can accurately model the degradation from multiple stressors and degradation modes by patiently examining stability curves and fitting them to increasingly complex functions. Instead, it is easier to work on a PSC architecture that is already reasonably robust, which reduces the 

31 

number of potential degradation modes and simplifies the model. Encapsulating cells in multiple layers, and/or using glass-glass lamination appears to negate environmental effects. Then, by using stable transport layers and conformal blocking layers, we can focus on the perovskite film. Limiting temperatures to < 90 °C for FA-based perovskites and to < 300 °C for inorganic perovskites can restrict unrealistic thermal decomposition.  Previous testing suggests that only a few degradation modes are present after such isolation: ion drift, decomposition of Pb-I to Pb<sup>0</sup> and I<sup>2</sup> gas, cation segregation and halide segregation. Though still a complex system, these processes are governed by ion migration energies and light-induced decomposition, thus only a small number of measurements are required. We expect sophisticated models that capture this behavior to appear soon. Once established, they can be used to accelerate testing protocols further using high illumination intensities and high temperatures. 

#### **[H2] Methods to increase perovskite stability** 

Though impressive increases to PSC stability have been achieved, these results do not yet meet the requirements for commercial application. To further increase stability, additional techniques should be considered in combination with other strategies. We suggest some underappreciated methods below. 

##### **[H3] Single crystal PSCs** 

Single crystal (SC) perovskites are archetypal materials for investigation as they have no grain boundaries and defect densities several orders of magnitude lower than their polycrystalline counterparts.<sup>193-195</sup> As such, single crystals demonstrate suppressed ion migration, charge accumulation and defect-induced phase transitions.<sup>196</sup> The relatively small number of reports on SC-PSCs have shown that SCs are superior to polycrystalline films at withstanding humidity and heat.<sup>197</sup> Through modified HTL/perovskite interface, MAPbI3 SC-devices with 22.1% PCE have been achieved. These devices maintained 90% of their initial PCE after 1000 h in air, compared to controls maintaining only 61%.<sup>198</sup> Given their inherent advantages, we expect SC-PSCs to display impressive stability under operation, but more work is still necessary to conclude on the matter. 

##### **[H3] Quasi single-crystalline PSCs** 

We Currently lack methods to upscale SC-PSCs and cell areas are limited to ~ 0.1 cm<sup>2</sup> . Quasi single crystal film growth (that is, the growth of films composed of µm-scale single crystallites through seeded growth) represents a promising middle ground between traditional thin film 

32 

processing and SC-PSCs. For example, perovskite thin films have been fabricated by first forming a repeating array of 5 µm crystals spaced 5 µm apart, seeding the growth of a continuous film with grain size exceeding 3 µm.<sup>199</sup> Stability tracking of encapsulated devices (FTO/SnO2/perovskite/PEAI/spiro-OMeTAD/Au) at room temperature under AM1.5 1-sun intensity (ISOS-L1) demonstrated a _T_ 80 lifetime of 200 h for control devices and a _T_ 90 of 2000 h for the seeded growth films (initial PCE ~24%). Optimized PSC architecture could further improve the stability of quasi-single crystal devices. 

##### **[H3] Down conversion layer** 

Because shorter wavelength light is the most detrimental to perovskite stability, introducing a UV barrier layer to absorb UV light is an obvious way to enhance PSC stability. However, this approach also reduces _J_ SC.<sup>71</sup> Using a down-conversion material as a UV barrier layer solves this issue by absorbing UV light and converting it into longer (visible) wavelengths. Though this concept has attracted some attention<sup>76</sup> , it has mostly been applied to non-optimized MAPbI3 cells in an attempt to increase the current density, rather than to achieve higher stability. Conversion layers with photoluminescent quantum efficiency (PLQE) > 80% induce only a ~ 2% increase in _J_ SC, and this small improvement in current probably does not justify the added cost of the additional layers. These down conversion layers, however, could be integrated in cells to improve their stability. For example, MAPbI3 cells using a CsPbCl3:Mn quantum dot conversion layer yielded a 4-fold increase in stability under UV light.<sup>200</sup> The use of this method in a highly stable cell architecture is an exciting prospect. 

#### **[H2] Upscaling stability** 

The majority of the methods described herein were demonstrated on cells with < 1cm<sup>2</sup> active area. Upscaling this to modules involves a change in approach, moving away from spin coating to techniques such as blade coating, slot-die coating, screen printing or vacuum evaporation. These processes have a whole host of new engineering challenges to produce PCEs and stabilities comparable with small scale, spin coated devices. For solution-processed films, volatile solvents such as DMSO are usually employed, but unevaporated, trapped DMSO can escape to produce voids between the perovskite and CTLs. This issue is accentuated in large area devices causing rapid degradation under light and heat. Using non-volatile carbohydrazide to replace DMSO can overcome this issue. Carbohydrazide is reported to remain in films even after long-term exposure to 1-sun illumination at 60 °C, and 50 cm<sup>2</sup> modules using carbohydrazine have been fabricated<sup>201</sup> 

33 

with  efficiencies approaching 20% PCE and T85 lifetimes of 1000 h under 1-sun illumination at 50 °C. Even more encouraging is the report of a T97 > 1-year for 20 cm<sup>2</sup> devices under light cycling by replacing DMSO with another less volatile agent (diphenyl sulphoxide).<sup>202</sup> 

In monolithically-integrated panels, P2 laser scribing can leave thermally damaged perovskite near the edges of the scribe. Furthermore, if metal is used to fill the via (the trench created in the scribing process), the direct contact with the perovskite can cause rapid degradation because halides react with metal.<sup>203</sup> Making singulated cells is advantageous to avoid the use of laser scribes. This approach keeps barriers intact, avoids passing metal through the perovskite, avoids thermal damage associated with laser scribing, and allows the binning of cells by efficiency. If singulated cells are connected with a wire, current can be routed around a cell and through a bypass diode to prevent the cell from being pushed into reverse bias if it is in the shade while the other cells are illuminated.  Perovskite-silicon tandems naturally take this approach. 

These promising results suggest that highly stable modules are achievable. We expect a continued focus on module stability as the field progresses towards commercial stability. 

#### **[H2] Conclusion** 

Despite being a persistent problem in perovskite photovoltaics, stability has improved by orders of magnitude in the first decade of mainstream perovskite PV research. With the introduction of various stability enhancing methods, the operational stability of PSCs is maturing beyond practically achievable testing lifetimes. The introduction of degradation modeling and lifetime estimation has suggested that some current PSC configurations could already have lifetimes similar to established PV. Currently, PSC researchers are using the ISOS protocols adapted from OPV research. Further degradation analysis and comparison with outdoor testing is critical to generate perovskite-specific protocols for calculating cell lifetimes and to understand how to improve stability further. Because many factors cause PSC degradation, solving stability issues using only one method is unrealistic, and the synergistic utilization of various stability-enhancing methods is the way forward. Considering what has already been achieved and the continued huge effort expended in this field, we expect that perovskite solar modules that retain 90% of their initial performance after 25 years of operation will emerge in the near future. 

##### **Conflicts of Interest** 

McGehee is an advisor to Swift Solar. 

34 

##### **Acknowledgements** 

H.Z., S.T., M.N.L., S.M., B.C., E.H.S. and O.M.B. acknowledge funding support from Saudi Aramco. 

S.T. was supported by the Hatch Graduate scholarship 

##### **Author contributions** 

H.Z. and S.T contributed equally to the article. 

##### **REFERENCES** 

- 1 Jena, A. K. _et al._ Halide Perovskite Photovoltaics: Background, Status, and Future Prospects. _Chem. Rev._ , 3036–3103 (2019). 

- 2 Zhu, H. _et al._ Efficient and Stable Large Bandgap MAPbBr3 Perovskite Solar Cell Attaining an Open Circuit Voltage of 1.65 V. _ACS Energy Lett._ **7** , 1112–1119 (2021). 

- 3 Green, M. A. _et al._ Solar cell efficiency tables (Version 60). _Prog. Photovolt.: Res. Appl._ **30** , 687701 (2022). 

- 4 Dualeh, A. _et al._ Thermal Behavior of Methylammonium Lead-Trihalide Perovskite Photovoltaic Light Harvesters. _Chem. Mater._ **26** , 6160-6164 (2014). 

- 5 Conings, B. _et al._ Intrinsic Thermal Instability of Methylammonium Lead Trihalide Perovskite. _Adv. Energy Mater._ **5** , 1500477 (2015). 

- 6 Zhao, X. _et al._ Room-temperature-processed fullerene single-crystalline nanoparticles for highperformance flexible perovskite photovoltaics. _J. Mater. Chem. A_ **7** , 1509-1518 (2019). 

- 7 Kim, G. Y. _et al._ Large tunable photoeffect on ion conduction in halide perovskites and implications for photodecomposition. _Nat. Mater._ **17** , 445-449 (2018). 

- 8 Leijtens, T. _et al._ Overcoming ultraviolet light instability of sensitized TiO2 with mesosuperstructured organometal tri-halide perovskite solar cells. _Nat. Commun._ **4** , 2885 (2013). 

- 9 Sidhik, S. _et al._ Deterministic fabrication of 3D/2D perovskite bilayer stacks for durable and efficient solar cells. _Science_ **377** , 1425-1430 (2022). 

- 10 Zhao, X. _et al._ Accelerated aging of all-inorganic, interface-stabilized perovskite solar cells. _Science_ **377** , 307-310 (2022). 

- 11 Grancini, G. _et al._ One-Year stable perovskite solar cells by 2D/3D interface engineering. _Nat. Commun._ **8** , 15684 (2017). 

- 12 Wang, Y. _et al._ Encapsulation and stability testing of perovskite solar cells for real life applications. _ACS Mater. Au_ **2** , 215-236 (2022). 

- 13 Brandt, R. E. _et al._ Searching for “Defect-Tolerant” Photovoltaic Materials: Combined Theoretical and Experimental Screening. _Chem. Mater._ **29** , 4667-4674 (2017). 

- 14 Huang, Y.-T. _et al._ Perovskite-inspired materials for photovoltaics and beyond-from design to devices. _Nanotechnology_ **32** , 132004 (2021). 

- 15 Macpherson, S. _et al._ Local Nanoscale Phase Impurities are Degradation Sites in Halide Perovskites. _Nature_ **607** , 294–300 (2022). 

- 16 Du, Y. A. _et al._ Ga antisites, and Au impurities in zinc blende and wurtzite GaAs nanowire segments from first principles. _Physical Review B_ **87** , 075308 (2013). 

- 17 Lai, M. L. _et al._ Tunable Near-Infrared Luminescence in Tin Halide Perovskite Devices. _J. Phys. Chem. Lett._ **7** , 2653-2658 (2016). 

- 18 Fabini, D. H. _et al._ The underappreciated lone pair in halide perovskites underpins their unusual properties. _MRS Bull._ **45** , 467-477 (2020). 

35 

- 19 Yaffe, O. _et al._ Local Polar Fluctuations in Lead Halide Perovskite Crystals. _Phys. Rev. Lett._ **118** , 136001 (2017). 

- 20 _Light gets ions going,_ _<u>https://www.fkf.mpg.de/7824789/news_publication_12009261_transferred</u>_ <u>, (2018).</u> 

- 21 Huang, Z. _et al._ Suppressed Ion Migration in Reduced-Dimensional Perovskites Improves Operating Stability. _ACS Energy Lett._ **4** , 1521–1527 (2019). 

- 22 Knight, A. J. _et al._ Halide Segregation in Mixed-Halide Perovskites: Influence of A-Site Cations. _ACS Energy Lett._ **6** , 799-808 (2021). 

- 23 Bertoluzzi, L. _et al._ Mobile Ion Concentration Measurement and Open-Access Band Diagram Simulation Platform for Halide Perovskite Solar Cells. _Joule_ **4** , 109-127 (2020). 

- 24 Eames, C. _et al._ Ionic transport in hybrid lead iodide perovskite solar cells. _Nat. Commun._ **6** , 7497 (2015). 

- 25 Chen, B. _et al._ Origin of J–V Hysteresis in Perovskite Solar Cells. _J. Phys. Chem. Lett._ **7** , 905-917 (2016). 

- 26 Tress, W. _et al._ Understanding the rate-dependent J–V hysteresis, slow time component, and aging in CH3NH3PbI3 perovskite solar cells: the role of a compensated electric field. _Energy Environ. Sci._ **8** , 995-1004 (2015). 

- 27 Zhao, Y. _et al._ A bilayer conducting polymer structure for planar perovskite solar cells with over 1,400 hours operational stability at elevated temperatures. _Nat. Energy_ **7** , 144-152 (2022). 

- 28 Yang, T.-Y. _et al._ The Significance of Ion Conduction in a Hybrid Organic–Inorganic Lead-IodideBased Perovskite Photosensitizer. _Angew. Chem., Int. Ed._ **54** , 7905-7910 (2015). 

- 29 Senocrate, A. _et al._ Thermochemical Stability of Hybrid Halide Perovskites. _ACS Energy Lett._ **4** , 2859-2870 (2019). 

- 30 Boyd, C. C. _et al._ Understanding Degradation Mechanisms and Improving Stability of Perovskite Photovoltaics. _Chem. Rev._ **119** , 3418-3451 (2018). 

- 31 Lehmann, F. _et al._ The phase diagram of a mixed halide (Br, I) hybrid perovskite obtained by synchrotron X-ray diffraction. _RSC Adv._ **9** , 11151-11159 (2019). 

- 32 Zhu, T. _et al._ Coupling photogeneration with thermodynamic modeling of light-induced alloy segregation enables the discovery of stabilizing dopants. _ArXiv.org, e-Print Arch., Condens. Matter_ (2023). 

- 33 Brivio, F. _et al._ Thermodynamic Origin of Photoinstability in the CH3NH3Pb(I1–xBrx)3 Hybrid Halide Perovskite Alloy. _J. Phys. Chem. Lett._ **7** , 1083-1087 (2016). 

- 34 Bischak, C. G. _et al._ Origin of Reversible Photoinduced Phase Separation in Hybrid Perovskites. _Nano Letters_ **17** , 1028-1033, (2017). 

- 35 Wang, X. _et al._ Suppressed phase separation of mixed-halide perovskites confined in endotaxial matrices. _Nat. Commun._ **10** , 1-7 (2019). 

- 36 Belisle, R. A. _et al._ Impact of Surfaces on Photoinduced Halide Segregation in Mixed-Halide Perovskites. _ACS Energy Lett._ **3** , 2694-2700 (2018). 

- 37 Barker, A. J. _et al._ Defect-Assisted Photoinduced Halide Segregation in Mixed-Halide Perovskite Thin Films. _ACS Energy Lett._ **2** , 1416-1424 (2017). 

- 38 Kerner, R. A. _et al._ The role of halide oxidation in perovskite halide phase separation. _Joule_ **5** , 2273-2295 (2021). 

- 39 DuBose, J. T. & Kamat, P. V. Hole Trapping in Halide Perovskites Induces Phase Segregation. _Acc. Mater. Res._ **3** , 761–771 (2022). 

- 40 Khenkin, M. V. _et al._ Consensus statement for stability assessment and reporting for perovskite photovoltaics based on ISOS procedures. _Nat. Energy_ **5** , 35-49 (2020). 

- 41 Burschka, J. _et al._ Sequential deposition as a route to high-performance perovskite-sensitized solar cells. _Nature_ **499** , 316-320 (2013). 

36 

- 42 Jiang, Q. _et al._ Surface Passivation of Perovskite Film for Efficient Solar Cells. _Nat. Photonics_ **13** , 460-466 (2019). 

- 43 Min, H. _et al._ Efficient, stable solar cells by using inherent bandgap of α-phase formamidinium lead iodide. _Science_ **366** , 749-753 (2019). 

- 44 Zhao, Y. _et al._ Inactive (PbI2)2RbCl stabilizes perovskite films for efficient solar cells. _Science_ **377** , 531-534 (2022). 

- 45 Saliba, M. _et al._ Incorporation of rubidium cations into perovskite solar cells improves photovoltaic performance. _Science_ **354** , 206-209 (2016). 

- 46 Jost, M. _et al._ Perovskite Solar Cells go Outdoors: Field Testing and Temperature Effects on Energy Yield. _Adv. Energy Mater._ **10** , 2000454 (2020). 

- 47 Emery, Q. _et al._ Encapsulation and Outdoor Testing of Perovskite Solar Cells: Comparing Industrially Relevant Process with a Simplified Lab Procedure. _ACS Appl. Mater. Interfaces_ **14** , 5159–5167 (2022). 

- 48 Pescetelli, S. _et al._ Integration of two-dimensional materials-based perovskite solar panels into a stand-alone solar farm. _Nat. Energy_ **7** , 597-607 (2022). 

- 49 Jacobsson, T. J. _et al._ An open-access database and analysis tool for perovskite solar cells based on the FAIR data principles. _Nat. Energy_ **7** , 107-115 (2022). 

- 50 Zheng, X. _et al._ Managing grains and interfaces via ligand anchoring enables 22.3%-efficiency inverted perovskite solar cells. _Nat. Energy_ **5** , 131-140 (2020). 

- 51 Chen, H. _et al._ Quantum-size-tuned heterostructures enable efficient and stable inverted perovskite solar cells. _Nat. Photonics_ **16** , 352–358 (2022). 

- 52 Jiang, Q. _et al._ Surface reaction for efficient and stable inverted perovskite solar cells. _Nature_ **611** , 278–283 (2022). 

- 53 Pitaro, M. _et al._ Tin Halide Perovskites: From Fundamental Properties to Solar Cells. _Adv. Mater._ , 2105844 (2021). 

- 54 Tao, L. _et al._ Stability of mixed-halide wide bandgap perovskite solar cells: Strategies and progress. _J. Energy Chem._ **61** , 395-415 (2021). 

- 55 Li, Z. _et al._ Stabilizing Perovskite Structures by Tuning Tolerance Factor: Formation of Formamidinium and Cesium Lead Iodide Solid-State Alloys. _Chem. Mater._ **28** , 284-292 (2016). 

- 56 Stoumpos, C. C. _et al._ Semiconducting Tin and Lead Iodide Perovskites with Organic Cations: Phase Transitions, High Mobilities, and Near-Infrared Photoluminescent Properties. _Inorg. Chem._ **52** , 9019-9038 (2013). 

- 57 Fabini, D. H. _et al._ Reentrant Structural and Optical Properties and Large Positive Thermal Expansion in Perovskite Formamidinium Lead Iodide. _Angew. Chem., Int. Ed._ **55** , 15392-15396 (2016). 

- 58 Cao, D. H. _et al._ 2D Homologous Perovskites as Light-Absorbing Materials for Solar Cell Applications. _J. Am. Chem. Soc._ **137** , 7843-7850 (2015). 

- 59 Juarez-Perez, E. J. _et al._ Thermal degradation of formamidinium based lead halide perovskites into sym-triazine and hydrogen cyanide observed by coupled thermogravimetry - mass spectrometry analysis. _J. Mater. Chem. A_ **7** , 16912-16919 (2019). 

- 60 Juarez-Perez, E. J. _et al._ Photodecomposition and thermal decomposition in methylammonium halide lead perovskites and inferred design principles to increase photovoltaic device stability. _J. Mater. Chem. A_ **6** , 9604-9612 (2018). 

- 61 Bertoluzzi, L. _et al._ Incorporating Electrochemical Halide Oxidation into Drift-Diffusion Models to Explain Performance Losses in Perovskite Solar Cells under Prolonged Reverse Bias. _Adv. Energy Mater._ **11** , 2002614 (2021). 

- 62 Xue, J. _et al._ The surface of halide perovskites from nano to bulk. _Nat. Rev. Mater._ **5** , 809-827 (2020). 

37 

- 63 Azpiroz, J. M. _et al._ Defect migration in methylammonium lead iodide and its role in perovskite solar cell operation. _Energy Environ. Sci._ **8** , 2118-2127 (2015). 

- 64 Choi, K. _et al._ Heat dissipation effects on the stability of planar perovskite solar cells. _Energy Environ. Sci._ **13** , 5059-5067 (2020). 

- 65 Brunetti, B. _et al._ On the Thermal and Thermodynamic (In)Stability of Methylammonium Lead Halide Perovskites. _Sci. Rep._ **6** , 31896 (2016). 

- 66 Eperon, G. E. _et al._ Formamidinium lead trihalide: a broadly tunable perovskite for efficient planar heterojunction solar cells. _Energy Environ. Sci._ **7** , 982-988 (2014). 

- 67 Liu, Z. _et al._ Efficient and Stable FA-Rich Perovskite Photovoltaics: From Material Properties to Device Optimization. _Adv. Energy Mater._ **12** , 2200111 (2022). 

- 68 Pang, S. _et al._ NH2CH═NH2PbI3: An Alternative Organolead Iodide Perovskite Sensitizer for Mesoscopic Solar Cells. _Chem. Mater._ **26** , 1485-1491 (2014). 

- 69 Burwig, T. _et al._ Crystal Phases and Thermal Stability of Co-evaporated CsPbX3 (X = I, Br) Thin Films. _J. Phys. Chem. Lett._ **9** , 4808-4813 (2018). 

- 70 Lee, S.-W. _et al._ UV Degradation and Recovery of Perovskite Solar Cells. _Sci. Rep._ **6** , 38150 (2016). 

- 71 Wang, Z. _et al._ Recent Advances and Perspectives of Photostability for Halide Perovskite Solar Cells. _Adv. Opt. Mater._ **10** , 2101822 (2022). 

- 72 Lang, F. _et al._ Influence of Radiation on the Properties and the Stability of Hybrid Perovskites. _Adv. Mater._ **30** , 1702905 (2018). 

- 73 Dawood, R. I. _et al._ The Photodecomposition of Lead Iodide. _Proceedings of the Royal Society of London. Series A, Mathematical and Physical Sciences_ **284** , 272-288 (1965). 

- 74 Nickel, N. H. _et al._ Unraveling the Light-Induced Degradation Mechanisms of CH3NH3PbI3 Perovskite Films. _Adv. Electron. Mater._ **3** , 1700158 (2017). 

- 75 Donakowski, A. _et al._ Improving Photostability of Cesium-Doped Formamidinium Lead Triiodide Perovskite. _ACS Energy Lett._ **6** , 574-580 (2021). 

- 76 Hoke, E. T. _et al._ Reversible photo-induced trap formation in mixed-halide hybrid perovskites for photovoltaics. _Chem Sci_ **6** , 613-617 (2015). 

- 77 Mahesh, S. _et al._ Revealing the origin of voltage loss in mixed-halide perovskite solar cells. _Energy Environ. Sci._ **13** , 258-267 (2020). 

- 78 Bai, Y. _et al._ Initializing film homogeneity to retard phase segregation for stable perovskite solar cells. _Science_ **378** , 747-754, doi:10.1126/science.abn3148 (2022). 

- 79 Lan, D. _et al._ Combatting temperature and reverse-bias challenges facing perovskite solar cells. _Joule_ **6** , 1782-1797 (2022). 

- 80 Bowring, A. R. _et al._ Reverse Bias Behavior of Halide Perovskite Solar Cells. _Adv. Energy Mater._ **8** , 1702365 (2018). 

- 81 Razera, R. A. Z. _et al._ Instability of p-i-n perovskite solar cells under reverse bias. _J. Mater. Chem. A_ **8** , 242-250 (2020). 

- 82 Wolf, E. J. _et al._ Designing Modules to Prevent Reverse Bias Degradation in Perovskite Solar Cells when Partial Shading Occurs. _Sol. RRL_ **6** , 2100239 (2022). 

- 83 Ni, Z. _et al._ Resolving spatial and energetic distributions of trap states in metal halide perovskite solar cells. _Science_ **367** , 1352-1358 (2020). 

- 84 Wang, J. _et al._ Photoinduced Dynamic Defects Responsible for the Giant, Reversible, and Bidirectional Light-Soaking Effect in Perovskite Solar Cells. _J. Phys. Chem. Lett._ **12** , 9328-9335 (2021). 

- 85 Xu, B. _et al._ Bifunctional spiro-fluorene/heterocycle cored hole-transporting materials: Role of the heteroatom on the photovoltaic performance of perovskite solar cells. _Chem. Eng. J._ **431** , 133371 (2022). 

38 

- 86 Luo, D. _et al._ Minimizing Non-radiative Recombination Losses in Perovskite Solar Cells. _Nat. Rev. Mater._ **5** , 44-60 (2019). 

- 87 Reichert, S. _et al._ Probing the ionic defect landscape in halide perovskite solar cells. _Nat. Commun._ **11** , 6098 (2020). 

- 88 Chen, C. _et al._ Arylammonium-Assisted Reduction of the Open-Circuit Voltage Deficit in WideBandgap Perovskite Solar Cells: The Role of Suppressed Ion Migration. _ACS Energy Lett._ **5** , 2560– 2568 (2020). 

- 89 Liu, J. _et al._ Correlations between Electrochemical Ion Migration and Anomalous Device Behaviors in Perovskite Solar Cells. _ACS Energy Lett._ **6** , 1003–1014 (2021). 

- 90 McGovern, L. _et al._ Reduced Barrier for Ion Migration in Mixed-Halide Perovskites. _ACS Appl. Energy Mater._ **4** , 13431–13437 (2021). 

- 91 Yang, S. _et al._ Stabilizing halide perovskite surfaces for solar cell operation with wide-bandgap lead oxysalts. _Science_ **365** , 473-478 (2019). 

- 92 Ahn, N. _et al._ Trapped charge-driven degradation of perovskite solar cells. _Nat. Commun._ **7** , 13422 (2016). 

- 93 Wang, Q. _et al._ Scaling behavior of moisture-induced grain degradation in polycrystalline hybrid perovskite thin films. _Energy Environ. Sci._ **10** , 516-522 (2017). 

- 94 Samu, G. F. _et al._ Electrochemical Hole Injection Selectively Expels Iodide from Mixed Halide Perovskite Films. _J. Am. Chem. Soc._ **141** , 10812–10820 (2019). 

- 95 Ni, Z. _et al._ Evolution of defects during the degradation of metal halide perovskite solar cells under reverse bias and illumination. _Nat. Energy_ **7** , 65-73 (2022). 

- 96 Lin, C.-H. _et al._ Electrode Engineering in Halide Perovskite Electronics: Plenty of Room at the Interfaces. _Adv. Mater._ **34** , 2108616 (2022). 

- 97 Back, H. _et al._ Achieving long-term stable perovskite solar cells via ion neutralization. _Energy Environ. Sci._ **9** , 1258-1263 (2016). 

- 98 Domanski, K. _et al._ Not All That Glitters Is Gold: Metal-Migration-Induced Degradation in Perovskite Solar Cells. _ACS Nano_ **10** , 6306-6314 (2016). 

- 99 Guerrero, A. _et al._ Interfacial Degradation of Planar Lead Halide Perovskite Solar Cells. _ACS Nano_ **10** , 218-224 (2016). 

- 100 Zhen, C. _et al._ Strategies for modifying TiO2 based electron transport layers to boost perovskite solar cells. _ACS Sustainable Chem. Eng._ **7** , 4586-4618 (2019). 

- 101 Sakhatskyi, K. _et al._ Assessing the Drawbacks and Benefits of Ion Migration in Lead Halide Perovskites. _ACS Energy Lett._ **7** , 3401–3414 (2022). 

- 102 Ito, S. _et al._ Effects of Surface Blocking Layer of Sb2S3 on Nanocrystalline TiO2 for CH3NH3PbI3 Perovskite Solar Cells. _J. Phys. Chem. C_ **118** , 16995-17000 (2014). 

- 103 Boldyreva, A. G. _et al._ Unraveling the impact of hole transport materials on photostability of perovskite films and p-i-n solar cells. _ACS Appl. Mater. Interfaces_ **12** , 19161–19173 (2020). 

- 104 Zhu, H. _et al._ Low-cost dopant additive-free hole-transporting material for a robust perovskite solar cell with efficiency exceeding 21%. _ACS Energy Lett._ **6** , 208-215 (2021). 

- 105 Bauer, M. _et al._ Cyclopentadiene-Based Hole-Transport Material for Cost-Reduced Stabilized Perovskite Solar Cells with Power Conversion Efficiencies Over 23%. _Adv. Energy Mater._ **11** , 2003953 (2021). 

- 106 Fu, Q. _et al._ Ionic Dopant-Free Polymer Alloy Hole Transport Materials for High-Performance Perovskite Solar Cells. _J. Am. Chem. Soc._ **144** , 9500–9509 (2022). 

- 107 Habisreutinger, S. N., Wenger, B., Snaith, H. J. & Nicholas, R. J. Dopant-Free Planar n-i-p Perovskite Solar Cells with Steady-State Efficiencies Exceeding 18%. _ACS Energy Lett._ **2** , 622-628 (2017). 

39 

