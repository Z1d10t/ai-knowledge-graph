# Degradation mechanism of hybrid tin-based perovskite solar cells and the critical role of tin (IV) iodide

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Communications |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 419 |
| 作者 | Luis Lanzetta, Thomas Webb, N. Zibouche, Xin-Xing Liang, D. Ding, Ganghong Min, R. Westbrook, Benedetta Gaggio et al. |
| DOI | 10.1038/s41467-021-22864-z |
| 源文件 | 024_Lanzetta_2021_Degradation-mechanism-of-hybrid-tin-based-perovs.pdf |

---


## ARTICLE 



> https://doi.org/10.1038/s41467-021-22864-z **OPEN** 

# Degradation mechanism of hybrid tin-based perovskite solar cells and the critical role of tin (IV) iodide 

Luis Lanzetta 1, Thomas Webb 1,3, Nourdine Zibouche2,3, Xinxing Liang1, Dong Ding1, Ganghong Min1, Robert J. E. Westbrook<sup>1</sup> , Benedetta Gaggio<sup>1</sup> , Thomas J. Macdonald 1, M. Saiful Islam 2✉ & Saif A. Haque 1✉ 

Tin perovskites have emerged as promising alternatives to toxic lead perovskites in nextgeneration photovoltaics, but their poor environmental stability remains an obstacle towards more competitive performances. Therefore, a full understanding of their decomposition processes is needed to address these stability issues. Herein, we elucidate the degradation mechanism of 2D/3D tin perovskite films based on (PEA)0.2(FA)0.8SnI3 (where PEA is phenylethylammonium and FA is formamidinium). We show that SnI4, a product of the oxygen-induced degradation of tin perovskite, quickly evolves into iodine via the combined action of moisture and oxygen. We identify iodine as a highly aggressive species that can further oxidise the perovskite to more SnI4, establishing a cyclic degradation mechanism. Perovskite stability is then observed to strongly depend on the hole transport layer chosen as the substrate, which is exploited to tackle film degradation. These key insights will enable the future design and optimisation of stable tin-based perovskite optoelectronics. 

> 1 Department of Chemistry and Centre for Processable Electronics, Molecular Sciences Research Hub, Imperial College London, London, UK. 2 Department of Chemistry, University of Bath, Bath, UK.<sup>3</sup> These authors contributed equally: Thomas Webb, Nourdine Zibouche.<sup>✉</sup> email: m.s.islam@bath.ac.uk; s.a. haque@imperial.ac.uk 

1 

NATURE COMMUNICATIONS | (2021) 12:2853 | https://doi.org/10.1038/s41467-021-22864-z | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-22864-z 

ybrid lead halide perovskites remain at the forefront of research activity on next-generation solar cells. Power Hconversion efficienciesficienciesciencies (PCEs) for APbI33 perovskites 

conversion efficienciesficienciesciencies (PCEs) for APbI33 perovskites (where A is typically CH3NH3<sup>+</sup> /MA<sup>+</sup> , CH3(NH2)2<sup>+</sup> /FA<sup>+</sup> and/or Cs<sup>+</sup> ) have evolved from 3.8% to 25.5% within the last decade, surpassing well-established solar cells based on polycrystalline silicon and CuInGaSe2<sup>1,2</sup> . Their outstanding performance is due to their favourable properties such as high carrier diffusion lengths, broad absorption in the visible and near infra-red, and low density of trap states<sup>3–9</sup> . 

However, the widespread commercial scaleup of Pb perovskite devices raises concerns in relation to potential health and environmental hazards that their Pb content may cause. As such, this makes the development of Pb-free and environmentally friendly perovskite alternatives a high priority. In order to mitigate the toxicity of Pb-halide perovskites but simultaneously retain their favourable photovoltaic properties, Pb<sup>2+</sup> can be replaced by lowertoxicity cations with similar outer shell electron configurations, such as Sn<sup>2+</sup> , Ge<sup>2+</sup> , Bi<sup>3+</sup> or Sb<sup>3+10–15</sup> . Among these options, Sn halide perovskites have emerged as the most promising alternative<sup>16–29</sup> , exhibiting significantly lower bioavailability compared to Pb-based perovskites<sup>30</sup> and delivering the highest PCEs among Pb-free perovskite solar cells since devices based on CH3NH3SnI3−xBrx were reported in 2014<sup>10,11</sup> . Interest in these materials also arises from their superior semiconductor properties compared to their Pb analogues, such as broader absorption range, nearly-ideal bandgaps (~1.3 eV) and higher charge carrier mobilities<sup>31,32</sup> . 

With record PCEs surpassing 13%<sup>33</sup> , Sn-based perovskite solar cells have steadily become more competitive due to intensive research efforts. However, the device performance of tin perovskite solar cells has advanced at a slower pace relative to their Pb counterparts, mainly due to their poorer stability under ambient environmental conditions. Such stability issues with these materials relate mainly to the facile oxidation of Sn<sup>2+</sup> to Sn<sup>4+</sup> , which is also known to introduce p-type self-doping in the perovskite<sup>34</sup> . This in turn leads to high rates of monomolecular electron-hole recombination and therefore poor solar cell performance<sup>35</sup> . A number of strategies have been explored to address these issues, which include the use of SnX2 additives to mitigate self-doping<sup>36,37</sup> , as well as the introduction of inherently 



Fig. 1 Proposed cyclic degradation mechanism of a tin iodide perovskite under ambient air exposure. Unless stated otherwise, ‘A’ refers to the organic cations chosen for the preparation of the hybrid tin perovskite (20% PEA and 80% FA in the present work). Reaction 1: oxidation of perovskite by O2 and SnI4 formation; Reaction 2: solid-state formation of A2SnI6 from SnI4 and AI, where A ≡ FA. Reaction 3: hydrolysis of SnI4 by H2O and HI formation; Reaction 4: oxidation of HI by O2 and I2 formation; Reaction 5: oxidation of perovskite by I2 and SnI4 formation. 

more stable low-dimensional phases<sup>38–46</sup> . However, these approaches do not completely solve the problem and therefore a full elucidation of the decomposition pathways of Sn perovskites is needed to address the stability bottleneck more effectively. To date, reports describing the degradation mechanism of Sn perovskites remain limited, in contrast with Pb-based analogues<sup>47–53</sup> . For example, some studies have shown that ASnX3 (A = Cs<sup>+</sup> , MA<sup>+</sup> or FA<sup>+</sup> ; X = I<sup>-</sup> , Br<sup>-</sup> ) can decompose in air to form A2SnX6 (vacancy-ordered double perovskite<sup>54</sup> ) and SnO2<sup>31,55–57</sup> , while others revealed that FASnI3 and (PEA)2SnI4 (where PEA refers to phenylethylammonium) degrade in the presence of oxygen to SnI4, SnO2 and FAI/PEAI<sup>58,59</sup> . Whilst these findings provide plausible air-mediated decomposition routes of Sn-based perovskites, a more detailed understanding of the degradation mechanism as well as knowledge of inconspicuous reaction pathways is required. For example, it is reasonable to suppose that SnI4 can participate in further degradation reactions of ASnI3 on account of its high reactivity with water and oxygen relative to FAI, SnO2 and A2SnI6<sup>11,60–65</sup> . Therefore, a more indepth understanding of the role of SnI4 in tin perovskite degradation is necessary. 

In this paper, we report on the degradation mechanism of ASnI3 perovskites (where A represents 20% PEA and 80% FA) under ambient environmental conditions using a combination of diffraction, spectroscopy and ab initio simulation techniques. Herein, we identify SnI4 as a major contributor to the degradation process and therefore to the instability of such perovskites. Specifically, SnI4 is a direct product of the decomposition of 2D/3D (PEA)0.2(FA)0.8SnI3 under ambient air<sup>58,59</sup> . We go on to explore the impact of SnI4 on the optoelectronic properties, solar cell performance and stability of (PEA)0.2(FA)0.8SnI3 films. We show that the presence of SnI4 leads to enhanced non-radiative recombination and poorer device PCE, which is due to high free hole density caused by the introduced Sn<sup>4+</sup> states. Crucially, we observe that SnI4-richer perovskite films degrade faster under ambient conditions, suggesting that SnI4 accelerates the decomposition of Sn-based perovskites upon exposure to ambient air. 

We then investigate the role of SnI4 in the degradation mechanism of (PEA)0.2(FA)0.8SnI3 films and demonstrate that SnI4 in the film readily evolves to form I2 via a two-step process, namely, (i) the hydrolysis reaction of SnI4 with H2O to give HI and (ii) the oxidation of HI by O2 to form I2. Interestingly, the perovskite is found to rapidly degrade when exposed to I2 resulting in the formation of more SnI4, thus establishing a cyclic degradation mechanism shown schematically in Fig. 1. 

Finally, we find that the stability of (PEA)0.2(FA)0.8SnI3 perovskite films are highly dependent on the hole transport layer chosen as a substrate (i.e., NiOx, CuSCN and PEDOT:PSS). We observe an improvement in perovskite film stability as the hole withdrawal ability of the bottom layer is increased. We suggest that this process chemically reduces the perovskite film, mitigating the high sensitivity of the Sn-based perovskite to both exogenous and endogenous oxidising species (O2 and I2). Thus, we expect the implementation of highly efficient hole acceptors to provide a pathway towards more stable tin-based perovskite optoelectronics. 

### Results 

Degradation in air. As can be seen in Fig. 1, SnI4 plays a pivotal role in the degradation of tin iodide perovskites. As such, we first identify the presence of this species as a degradation product of 2D/3D (PEA)0.2(FA)0.8SnI3 thin films comparable to those employed in state-of-art solar cells<sup>39–42,44</sup> . Unless specified otherwise, all degradation experiments reported herein were carried out by exposing samples to ambient air (relative humidity, 

2 

NATURE COMMUNICATIONS | (2021) 12:2853 | https://doi.org/10.1038/s41467-021-22864-z | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-22864-z 



<!-- Start of picture text -->
a<br>1.0 0 min<br>SnI4 ref.<br>0.8 5 min<br>0.6 16 min<br>0.4 28 min<br>0.2<br>47 min<br>0.0<br>320 360 400 440 480<br>Wavelength (nm)<br>0 min<br>* 30 min<br>60 min<br>* 24 h<br>* FA2SnI6<br>14.0 14.2 14.4 14.6 *<br>* 2 (º)<br>12.0 12.5 13.0 13.5 14.0 14.5 15.0 15.5<br>2 (degrees)<br>Absorbance<br>Intensity (a. u.)<br>Intensity (a. u.)<br><!-- End of picture text -->



<!-- Start of picture text -->
b<br><!-- End of picture text -->



Fig. 2 Degradation of Sn perovskite under ambient air. a Time evolution of the (100) XRD reflection of (PEA)0.2(FA)0.8SnI3 films exposed to ambient air at 100 °C (top; inset: absorbance spectra of SnI4 dissolved in 3 mL of toluene after its sublimation from the heated film and capture in a Petri dish during different times) and room temperature (bottom; inset: magnification of peaks corresponding to 60 min and 24 h). Peaks labelled with * correspond to FA2SnI6. b Adsorption of an O2 molecule on a (001) surface of FASnI3 perovskite and charge density difference, which highlights bond formation between O and Sn atoms (from DFT simulations). Yellow and green charge densities refer to electron accumulation and depletion respectively (with an isosurface value of 0.006 Å<sup>−3</sup> ). 

RH = 38.0 ± 7.5%; temperature, T = 22.9 ± 0.9 °C), consistent with normal working conditions. Figure 2a shows the time evolution of the (100) reflection (orthorhombic system, Amm2 space group; full pattern in Supplementary Fig. 5a) obtained from the X-ray diffraction (XRD) patterns of (PEA)0.2(FA)0.8SnI3 films aged at 100 °C (Fig. 2a, top) and room temperature (Fig. 2a, bottom). 

Tin perovskite films degraded under ambient conditions whilst subjected to 100 °C heating show a rapid drop in the (100) reflection as they evolve in appearance from black/brown to transparent. This observation is consistent with the disruption of the perovskite crystalline structure due to the oxidative effect of atmospheric oxygen. Such degradation results in the formation of SnI4, which rapidly sublimes under heating. Evidence for the sublimation of SnI4 was obtained by covering the perovskite films with a glass Petri dish during the experiment and immediately extracting the captured products with toluene. The UV–Visible spectra of the captured product (Fig. 2a, top (inset)) clearly indicate the presence of SnI4 as a degradation product. We, therefore, propose Reaction 1 as the first step of Sn perovskite degradation in air, in good agreement with previous reports<sup>58,59</sup> : 



<!-- Start of picture text -->
2 ASnI3 þ O2 ! SnI4 þ SnO2 þ 2 AI ð1Þ<br><!-- End of picture text -->

To further complement the experimentally proposed degradation pathways of the Sn perovskite film, we have examined the energetics of Reaction 1 for FASnI3 using density functional theory (DFT) methods. We note that the FA perovskite system was simulated, rather than including PEA, due to the lack of precise experimental crystal structural data for PEA/FA systems similar to the (PEA)0.2(FA)0.8SnI3 precursor ratio as a reliable starting point and to allow a more focused approach on deriving trends of the reaction and surface properties. The reaction energy is calculated as the difference between the products and the reactants (in which a negative value indicates a favourable exothermic reaction). Details of 

the simulations and procedures, which have been applied recently to tin halide perovskites<sup>66,67</sup> , are provided in the Methods section. We calculate a highly favourable energy (−3.46 eV) for Reaction 1, which indicates that the perovskite film indeed degrades in the presence of oxygen as the initial step to form FAI, SnO2, and SnI4 in accord with the experimentally observed reaction products. 

To examine the microscopic mechanisms of this reaction with oxygen, we also simulated the adsorption of an O2 molecule on the FASnI3 perovskite surface. We examined three possible adsorption configurations of an O2 molecule on the (001) surface with FA/I and Sn/I terminations. We focused on the (001) surface as it has been shown to be one of the most stable and most extensively studied halide perovskite surfaces<sup>68,69</sup> . In the case of FA/I termination, the O2 molecule remains at a certain distance from the surface after relaxation independent of the initial configuration showing no interaction with surface species, which indicates that adsorption does not take place (as shown in Supplementary Fig. 22). For the Sn/I terminated surface, the most stable adsorption structure after relaxation is shown in Fig. 2b, which corresponds to the initial configuration of O2 located right above an Sn atom (for additional views, see Supplementary Fig. 18b). It is clear that one of the oxygen atoms of the O2 molecule forms a chemical bond with the Sn atom at the Sn/I terminated surface, as shown by the charge density difference in Fig. 2b. 

Regarding the thermodynamics of adsorption on the surface, we have calculated an adsorption energy of 0.7 eV. The Sn–O bond length is found to be 2.31 Å, which is close to the experimental Sn–O bond length in SnO2 (~2.1 Å<sup>70</sup> ). We also found that the O–O distance is stretched by over 0.1 Å beyond the bond length of the O2 molecule; this elongation suggests that the O2 molecule is likely to be dissociated on the surface and may subsequently participate in the formation of SnO2 (which is a phase detected in our samples via X-ray photoelectron spectroscopy (XPS); Supplementary Fig. 7 and Supplementary Table 1). 

3 

NATURE COMMUNICATIONS | (2021) 12:2853 | https://doi.org/10.1038/s41467-021-22864-z | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-22864-z 

Our simulation results are therefore consistent with the experimentally proposed Reaction 1 and provide additional atomistic insights into the reaction mechanism of the initial stage in the oxidation of the tin perovskite. 

The XRD data in Fig. 2a (bottom panel) show that in the film degraded at room temperature the (100) peak intensity also decreases during the course of an hour as a result of ambient air mediated degradation (relative signal loss vs time: 0% at 0 min, 3% at 30 min, 73% at 60 min; see Supplementary Fig. 1a). In addition, we observe the appearance of a small diffraction peak at 2θ ~14.4° (see Fig. 2a, bottom (inset), 60 min), which we attribute to the vacancy-ordered double perovskite variant FA2SnI6<sup>71</sup> (see a full pattern after 24 h of exposure to ambient air in Supplementary Fig. 1b). However, the emergence of this phase appears to be delayed as compared to perovskite degradation (12% rise of FA2SnI6 peak vs. 73% drop of (PEA)0.2(FA)0.8SnI3 peak after 60 min; Supplementary Fig. 1a). This suggests that degradation products formed via Reaction 1 gradually accumulate in the film for a prolonged time (~30–60 min) before triggering the solidstate process between SnI4 and FAI to form FA2SnI6 (Reaction 2)<sup>71,72</sup> : 



<!-- Start of picture text -->
SnI4 þ 2 AI ! A2SnI6 ð2Þ<br><!-- End of picture text -->

Taken together, the data in Fig. 2 suggest that the presence of FA2SnI6 in the film only occurs after substantial perovskite degradation and therefore the early interaction between this phase and (PEA)0.2(FA)0.8SnI3 is unlikely. In contrast, it is evident that SnI4, SnO2, FAI and PEAI coexist with the tin perovskite in the film during the initial stages of the material decomposition. DFT simulations indicate a very small energy (−0.21 eV) for Reaction 2 involving SnI4 interacting with FAI to form the FA2SnI6 phase, which is consistent with the slower formation of this phase. Upon degrading the sample under heating, we also note that the eventual formation of FA2SnI6 is impeded due to the rapid sublimation of SnI4. 

Optoelectronic and stability effects of tin (IV) iodide. Next, we examine the effect of SnI4 on the optoelectronic properties, device performance and ambient stability of (PEA)0.2(FA)0.8SnI3 films. For this, the SnI4 content in the perovskite films was varied by tuning the SnI4 concentration in the perovskite precursor solution by both thermally purifying the control (commercially sourced) SnI2 precursor to minimise its SnI4 impurities and by replacing 2 mol% control SnI2 by equimolar amounts of SnI4. We note that details of precursor purification (experimental setup and conditions, Supplementary Fig. 2; thermogravimetric analysis (TGA), Supplementary Fig. 3a; SnI4 identification and quantification, Supplementary Fig. 4), the effect of control/purified SnI2 on the perovskite film structure (XRD, Supplementary Fig. 5), morphology (scanning electron microscopy (SEM), Supplementary Fig. 6), and composition (XPS; Supplementary Fig. 7 and Supplementary Table 1) are provided in the Supplementary Information. 

Figure 3a shows the UV–Visible absorption characteristics of three perovskite films: sample (A), film made with purified commercial SnI2 (0.06% SnI4 content); sample (B), film made with as-received commercial SnI2 (0.65% SnI4 content) and sample (C), film made with commercial SnI2 and 2 mol% SnI4 (3.95% SnI4 content). We note that XPS measurements confirm an increase in Sn<sup>4+</sup> content in films processed with SnI4-richer SnI2 precursors (Supplementary Fig. 7). Moreover, it is apparent from Fig. 3a that the optical bandgaps of samples (A) and (B) are found to be ~1.32 eV, while that of sample (C) is 1.35 eV (Tauc plots provided in Supplementary Fig. 8). It is possible that the larger bandgap observed in sample (C) may originate from its 

more pronounced p-type character; a higher SnI4 content introduces more Sn<sup>4+</sup> states in the perovskite, resulting in a hole-richer valence band and therefore causing band-to-band electron transitions to occur at higher energies. 

Figure 3b presents time-resolved photoluminescence (PL) decays for samples (A), (B) and (C). It is apparent that longer fluorescence lifetimes are observed in films made with less exogenous SnI4 (sample A: τ = 5.49 ns > sample B: τ = 2.09 ns > sample C: τ = 0.60 ns). We attribute the increase in emission lifetime in sample A as compared to samples B and C to a reduction in non-radiative monomolecular recombination rates that arise from the fewer Sn<sup>4+</sup> states that are incorporated into the perovskite structure; this being in good agreement with our XPS data (Supplementary Fig. 7 and Supplementary Table 1) and previous work<sup>73</sup> . Taken together, the data presented in Fig. 3a, b highlight the detrimental impact of SnI4 on the photophysical properties of Sn-based perovskites. It is pertinent to note that purifying the precursor (via sublimation) prior to film processing results in an improvement in the optoelectronic properties of the material. 

We next consider the influence of SnI4 on device performance. Figure 3c shows current density–voltage (J–V) curves of Sn perovskite solar cells based on a typical inverted architecture (ITO/PEDOT:PSS/(PEA)0.2(FA)0.8SnI3/PC60BM/BCP/Ag; see inset). Photovoltaic figures of merit of our devices are summarised in Supplementary Fig. 9 (box plots) and Supplementary Table 2. Solar cells made with the purified SnI2 attain high efficiencies (5.23%) compared to previous reports based on similar 2D/3D absorbers<sup>39,74</sup> . The high open-circuit voltage (Voc) (0.61 V) and fill factor (71%) achieved indicate low trap-mediated recombination and balanced charge transport. However, the relatively low shortcircuit current density (Jsc) is possibly caused by charge losses at perovskite/PEDOT:PSS and/or perovskite/PC60BM interfaces. In contrast, it is evident from J–V data in Fig. 3c that increasing the SnI4 content in the perovskite layer leads to a significant drop in the PCE (5.23% > 1.73%) due to a drop in Voc (0.61 V > 0.55 V) and Jsc (12.00 mA/cm<sup>2</sup> > 4.61 mA/cm<sup>2</sup> ); this is consistent with increased carrier recombination and lower carrier mobility as Sn<sup>4+</sup> doping is introduced<sup>75,76</sup> . 

Next, we consider the effect of SnI4 on the stability of (PEA)0.2(FA)0.8SnI3 films. Contour graphs showing normalised absorbance of samples (A), (B) and (C) as a function of time and wavelength are shown in Supplementary Fig. 10. These measurements indicate a drop in absorbance across the spectrum but more notably around 660 and 870 nm, close to the energies of the two main allowed optical transitions in these materials<sup>77</sup> . Normalised absorbance decays at 660 nm are plotted in Fig. 3d for comparison. The data presented in Fig. 3d show that the presence of SnI4 significantly increases the rate of degradation of (PEA)0.2(FA)0.8SnI3 films (stability: sample (A) > sample (B) > sample (C)). 

Evolution of tin (IV) iodide to iodine. So far, we have shown that: (i) SnI4 is generated as a product of the oxygen-induced degradation of Sn-based perovskite films and (ii) the presence of SnI4 in the film is highly detrimental to the optoelectronic properties, device performance and ambient stability of (PEA)0.2(FA)0.8SnI3 films. Whilst the deterioration of the optoelectronic properties and photovoltaic performance in the material can be attributed to non-radiative recombination caused by Sn<sup>4+</sup> dopants, the role of SnI4 in the degradation mechanism and stability of Sn perovskites remains unclear. It is reasonable to suppose that SnI4 can spontaneously evolve into iodine in the presence of moisture and oxygen<sup>11,60–65</sup> as indicated in Fig. 1. This is in agreement with empirical thermodynamic data<sup>78,79</sup> 

4 

NATURE COMMUNICATIONS | (2021) 12:2853 | https://doi.org/10.1038/s41467-021-22864-z | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-22864-z 



Fig. 3 Effect of tin (IV) iodide on Sn perovskite optical properties, solar cell performance and stability. a UV–Visible spectra of glass/ (PEA)0.2(FA)0.8SnI3 thin films made with varying SnI4 concentrations. b Time-resolved PL decays of perovskite films acquired at 875 nm with 404 nm excitation and their fitting curves. Average τf for films are 5.49 ns (film made with purified SnI2; biexponential decay fit), 2.09 ns (film made with control SnI2; biexponential decay fit) and 0.60 ns (film with added SnI4; monoexponential decay fit). c. Current density–voltage (J–V) curves of champion solar cells based on (PEA)0.2(FA)0.8SnI3 made with varying SnI4 concentrations. d. Time evolution of relative absorbance at 660 nm of perovskite thin films made with varying SnI4 concentrations. Degradation experiments were carried out under dark and ambient air conditions (23 °C, 38% RH). 

showing that (i) SnI4 can hydrolyse to form SnO2 and HI (Gibbs free energy: ΔG° = −0.60 eV) and, similarly, (ii) HI can react with oxygen to give I2 and H2O (ΔG° = −2.20 eV). To investigate whether these reactions are feasible in the perovskites reported herein, a combination of proton nuclear magnetic resonance (<sup>1</sup> H- NMR) and UV–Visible spectroscopies were used. 

First,<sup>1</sup> H-NMR spectroscopy is used to analyse the interaction of SnI4 with moisture in a (PEA)0.2(FA)0.8SnI3 film degraded under ambient air for 24 h and dissolved in deuterated DMSO (Fig. 4a). We note that full (downfield) NMR spectra of the solvent, FAI, PEAI, fresh (PEA)0.2(FA)0.8SnI3, aged (PEA)0.2 (FA)0.8SnI3 and their peak assignment are provided in Supplementary Fig. 11, indicating that FA<sup>+</sup> and PEA<sup>+</sup> do not undergo any structural alterations within the 24 h degradation period. However, the peak assigned to H2O traces is detected at ~3.53 ppm in the upfield degraded perovskite spectrum, in contrast with its position at ~3.35 ppm in the reference DMSO-d6, FAI, PEAI and fresh perovskite spectra (Fig. 4a). The downfield shift in the H2O peak is indicative of a decrease in electron density around water protons (de-shielding effect), consistent with the protonation of water (i.e., formation of H3O<sup>+</sup> ). The acidification of water is consistent with the formation of HI through the reaction of SnI4 with H2O, as detailed in Reaction 3<sup>8,60,61,63–65</sup> : 



<!-- Start of picture text -->
ð3Þ<br><!-- End of picture text -->

SnI4 þ 2 H2O ! 4 HI þ SnO2 

It is pertinent to note that HI can participate in further reactions under ambient conditions due to its highly reactive nature. For example, HI formed as a result of water-mediated degradation of CH3NH3PbI3<sup>80,81</sup> has been suggested to evolve in the air to form I2<sup>82</sup> . As such, a plausible reaction route for HI oxidation to give I2 and H2O is represented in Reaction 4: 



<!-- Start of picture text -->
4 HI þ O2 ! 2 I2 þ 2 H2O ð4Þ<br><!-- End of picture text -->

Further evidence for Reactions 3 and 4 occuring was obtained from studying the reaction of water with SnI4, followed by exposure to air (Supplementary Fig. 12). Specifically, upon the addition of SnI4 to water, we observe a drop in pH and the precipitation of a white solid, consistent with the formation of HI and SnO2, respectively. Moreover, ageing this mixture in air leads to a colour change (from clear to yellow/orange) along with new absorption features that indicate the oxidation of HI to I2 (see Supplementary Fig. 12). We note that the photoinduced decomposition of HI into its elements (H2 and I2) cannot be excluded, although we expect this path to be less favourable due to thermodynamic limitations<sup>83–85</sup> . Taken together, Reactions 3 and 4 suggest that SnI4 is highly likely to evolve into I2 through the cooperative action of atmospheric H2O and O2, with HI most likely acting as a short-lived, intermediate species. We note that the direct reaction of SnI4 with O2 to form I2 and SnO2 is also a possibility; nonetheless, this process is known to require high 

5 

NATURE COMMUNICATIONS | (2021) 12:2853 | https://doi.org/10.1038/s41467-021-22864-z | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-22864-z 





Fig. 4 Evolution of tin (IV) iodide to iodine and Sn perovskite oxidation by iodine. a Upfield<sup>1</sup> H-NMR spectra of DMSO-d6, FAI, PEAI, fresh (PEA)0.2(FA)0.8SnI3 and (PEA)0.2(FA)0.8SnI3 aged for 24 h in ambient air. b UV–Visible spectra of degradation products extracted in toluene (3 mL) from a PMMA-coated (PEA)0.2(FA)0.8SnI3 thin-film fully aged in ambient air for 3 weeks, the same solution after Na2S2O3 addition and I2 reference solution (dotted line) c UV–Visible spectra of degradation products extracted in toluene (3 mL) from (PEA)0.2(FA)0.8SnI3 thin films aged under different conditions (indicated in legend) and SnI4 and I2 reference solutions (dashed lines). d Top and side views of the structural arrangement of an adsorbed I2 molecule (purple) on the (001) surface of FASnI3 (from DFT calculations). 

temperatures to occur<sup>62</sup> and therefore we consider it to be much slower relative to Reactions 3 and 4 combined. 

In order to verify the evolution of SnI4 into I2 in (PEA)0.2 (FA)0.8SnI3 perovskite films under air, we next analyse degraded samples via UV–Visible spectroscopy to detect the halogen. The absorbance spectrum of degradation products extracted via toluene from a film aged in ambient air for 3 weeks is presented in Fig. 4b. The resulting UV–Visible characteristics in Fig. 4b show a shoulder at ~360 nm, assigned to SnI4, and two further features at ~300 and ~500 nm consistent with the presence of I2 (see I2 reference spectrum, Fig. 4b). The elimination of these two features by testing the solution with Na2S2O3, which is known to reduce I2 to I<sup>−</sup> , further supports the presence of I2 as a product of the degradation of SnI4. We note that the evolution of SnI4 to I2 is also observed in toluene solutions (Supplementary Fig. 13). 

Perovskite oxidation by iodine. The next question that arises relates to whether iodine can directly react with the perovskite and cause further degradation of the material. To investigate this, we exposed fresh (PEA)0.2(FA)0.8SnI3 films to artificially generated I2 atmospheres for short periods of time (~350 ppm I2, ~3 min) and used UV–Visible spectroscopy to study the reaction. Details of the experimental procedure and sample characterisation can be found in ‘Methods’. We find that Sn perovskite films exposed to I2 vapour result in a dramatic colour change (from black/brown to pale orange, Supplementary Fig. 14) attributed to perovskite degradation. Figure 4c shows the absorbance spectrum of degradation products extracted in toluene from an I2-exposed film. The absorption peak at ~360 nm reveals once more the presence of SnI4, confirming that I2 oxidises the Sn perovskite to 

SnI4 (via Reaction 5): 



<!-- Start of picture text -->
ASnI3þI2 ! SnI4 þ AI ð5Þ<br><!-- End of picture text -->

DFT calculations find a favourable energy (−0.61 eV) for this reaction (5) involving I2 interacting with FASnI3 to form SnI4 and FAI, which again agrees with experimental observation. To further analyse the detrimental role of I2, we also simulated the absorption of an I2 molecule on the (001) surface of FASnI3 in a similar methodology to the case of O2. Figure 4d shows the most stable structure after relaxation on the Sn/I terminated surface, which corresponds to I2 above the FA molecular cation (for further views, see Supplementary Fig. 20). The top view in Fig. 4d shows that the I2 molecule forms bridge-like bonds between the Sn and I atoms at the Sn/I terminated surface. The side view shows that the Sn atom that is bonded with one of the I atoms of the molecule is pulled out of the SnI2 surface, distorting the local regular Sn coordination of the perovskite structure. This suggests that the I2 species reacts with the perovskite crystal and most likely results in the formation of additional SnI4 as proposed experimentally in Reaction 5. When the surface is FA/I terminated, the I2 molecule interacts with the outer iodine atom of the surface and forms a triiodide-like molecular shape, independent of the initial configurations, as shown in Supplementary Fig. 23. Overall, these results show that our simulations are in line with the experimental findings of the cyclic degradation process, as well as providing new mechanistic insights at the atomic level. 

Cyclic degradation mechanism of Sn perovskite. Our findings provide a detailed description of the degradation processes in Sn perovskite films under ambient air, as schematically depicted in Fig. 1. The decomposition of the material is triggered by oxygen, 

6 

NATURE COMMUNICATIONS | (2021) 12:2853 | https://doi.org/10.1038/s41467-021-22864-z | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-22864-z 

which oxidises the perovskite to SnI4 (Reaction 1). Next, this degradation product can follow two reaction pathways, namely (i) its solid-state evolution to form a vacancy-ordered Sn(IV) double perovskite (Reaction 2) and, more critically, (ii) its evolution in the presence of moisture and oxygen via, most likely, a HI intermediate to give I2 (Reactions 3 and 4), which we find to be a fast process (<10 min; Supplementary Note 1). (PEA)0.2 (FA)0.8SnI3 films are found to degrade rapidly (<3 min) when exposed to I2 at lower concentrations than atmospheric O2 (~0.035% I2 < ~21% O2). As can be seen in Fig. 1, SnI4 and I2 can interconvert while causing the decomposition of the perovskite. We believe that our mechanistic insights explain why SnI4 impurities in the perovskite precursor lead to greater premature perovskite degradation (Fig. 3d): the presence of exogenous SnI4 in the perovskite may speed up the formation of highly aggressive I2, which in turns leads to the degradation of the perovskite. 

In order to obtain further evidence for our degradation mechanism presented in Fig. 1, we investigated the stability of (PEA)0.2(FA)0.8SnI3 films in the presence or absence of agents that 



Fig. 5 Sn perovskite degradation tests under dry/moist air/nitrogen flow. Optical degradation of (PEA)0.2(FA)0.8SnI3 films at 660 nm upon exposure to a flow of dry N2 (RH = 0%), moist N2 (RH = 90%), dry air (RH = 0%) and moist air (RH = 90%). 



trigger material decomposition, i.e., O2 and H2O. In these experiments, we exposed the perovskite films to an artificially generated flow of N2 or air under different relative humidity conditions (RH = 0% or RH = 90%) and tracked their optical degradation at 660 nm for a period of 30 min (see Fig. 5). We note that experimental details of these studies are provided in the Methods section. As expected, no degradation is observed when the films are exposed to dry or moist N2 (RH = 0% and RH = 90% respectively). The presence of H2O in the latter may cause hydrolysis of SnI4 impurities in the film to HI via Reaction 3, but O2 is required for the degradation cycle to progress into I2. Moreover, perovskite films exposed to dry air (RH = 0%) show a decay in absorbance that is consistent with the O2-mediated degradation of the material via Reaction 1. However, when the perovskite film is exposed to moist air (RH = 90%) optical degradation becomes much more pronounced, which we attribute to the presence of H2O activating the degradation cycle via Reaction 3. As such, these findings further support the proposed degradation mechanism and highlight the importance of avoiding oxygen and moisture to preserve Sn perovskite stability. We anticipate that the use of highly hydrophobic coatings in perovskite optoelectronic devices (e.g., ultrathin interlayers) will dramatically increase material resilience under ambient conditions, in accordance with the findings detailed here. 

Stabilisation of Sn perovskite films. We have shown that Sn perovskite films degrade under the oxidative action of atmospheric O2 and endogenously formed I2. These agents chemically decompose the perovskite, causing the oxidation of Sn<sup>2+</sup> to Sn<sup>4+</sup> to form SnI4. The details of the mechanism governing the degradation process provided here enable strategies to stabilise the Sn perovskite. As such, the removal of SnI4 and thus Sn<sup>4+</sup> species from the precursor and film may help delay the perovskite decomposition in air. To further minimise the oxidation of Sn<sup>2+</sup> to Sn<sup>4+</sup> , it is also important to consider the impact that other layers in the device (e.g., charge transport layers) may have on perovskite stability. 

To this end, we explore the influence of the bottom, hole transport materials (HTM) on the stability of ITO/HTM/ (PEA)0.2(FA)0.8SnI3 samples exposed to air. Specifically, NiOx, CuSCN and PEDOT:PSS were used as HTMs and glass/ (PEA)0.2(FA)0.8SnI3 was employed as a control sample. The samples were exposed to ambient air for 60 min and UV–Visible spectroscopy was employed to monitor degradation. Figure 6a shows the absorbance at 660 nm vs. time. We note that normalised UV–Visible absorption graphs vs. wavelength and 



Fig. 6 Effect of bottom hole transport layers on Sn perovskite stability. a Time evolution of relative absorbance at 660 nm of perovskite thin films deposited on glass and ITO/HTM substrates and exposed to ambient conditions (23 °C, 38% RH). b Schematic illustrating hole withdrawal from the perovskite via charge transfer to the HTM layer. c Steady-state PL spectra of perovskite thin films deposited on glass and ITO/HTM substrates (shown in legend). From these data, we estimate the yields of PL quenching to be 18% (ITO/NiOx/(PEA)0.2(FA)0.8SnI3), 82% (ITO/CuSCN/(PEA)0.2(FA)0.8SnI3) and 88% (ITO/PEDOT:PSS/(PEA)0.2(FA)0.8SnI3). 

7 

NATURE COMMUNICATIONS | (2021) 12:2853 | https://doi.org/10.1038/s41467-021-22864-z | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-22864-z 

time are presented in Supplementary Fig. 16. From the data presented in Fig. 6a, we observe that the stability of the tin perovskite layer strongly depends on the substrate it is used with. For example, ITO/PEDOT:PSS/perovskite and ITO/CuSCN/ perovskite samples exhibit superior stability, followed by the ITO/NiOx/perovskite sample and then glass/perovskite sample. 

Next, we discuss the possible origins of this trend. NiOx, CuSCN and PEDOT:PSS have been used as HTMs in highperformance Sn perovskite solar cells<sup>43,44,86</sup> . We propose that NiOx, CuSCN and PEDOT:PSS can also accept the excess of dark holes inherently found in the Sn-based perovskite valence band that cause their unwanted p-doping (Fig. 6b). It is plausible that this effect may chemically translate as the reduction of Sn<sup>4+</sup> states within the depletion region to Sn<sup>2+</sup> , which would delay the degradation steps described in Fig. 1 and preserve the Sn perovskite structure for longer. To test the overall ability of HTMs to withdraw holes from the perovskite, we measured the steadystate PL spectra of our samples (Fig. 6c). We observe that perovskite emission is reduced in all perovskite/HTM substrates relative to a perovskite/glass control; this is consistent with PL quenching via photoinduced hole transfer. 

More direct evidence for hole transfer was obtained via timeresolved PL spectroscopy (Supplementary Fig. 17); faster charge recombination kinetics is observed in all samples containing HTM substrates, indicating efficient hole transfer from the perovskite. Taken together, the data presented in Fig. 6 suggest that the stability of the tin perovskite layer can be enhanced by improving hole transfer at the perovskite/HTM heterojunction. We note that other factors may also influence stability, such as HTM/perovskite interface passivation, chemical reactivity between HTM and perovskite and substrate-dependent point defect formation. A detailed description of the role of these issues is beyond the scope of the current manuscript and will be reported in future work. 

### Discussion 

Using a combination of diffraction, spectroscopy and ab initio simulation techniques, this study provides a greater understanding of the degradation mechanisms in tin perovskites, which is crucial in addressing their stability issues. The present findings illustrate the important role of SnI4 in the optoelectronic properties, device performance and ambient degradation of tin perovskite films based on 2D/3D (PEA)0.2(FA)0.8SnI3. We reveal that SnI4, both as a precursor impurity and as a perovskite degradation product, can rapidly evolve in ambient air to form I2, with the latter found to be a highly aggressive species. Specifically, we show that I2 causes the prompt oxidation of perovskite to form additional SnI4, as shown in Fig. 1. 

The understanding gained from these new mechanistic insights into the degradation of the Sn-based perovskite (PEA)0.2(FA)0.8SnI3 enables the development of mitigation strategies aimed at reducing its sensitivity towards oxidation. We find that the choice of the bottom HTM substrate can have a significant impact on perovskite film stability. We propose that dark hole withdrawal from the perovskite can cause the chemical reduction of Sn<sup>4+</sup> species to Sn<sup>2+</sup> , which counteracts the oxidation prompted by O2 and thereby delays the formation of SnI4 and its evolution to highly aggressive I2; this ultimately leads to improved stability of the tin perovskite film. In summary, this study sheds new light upon critical features of the degradation mechanism of hybrid tin iodide perovskites, paving the way towards stable and highperformance tin-based perovskite optoelectronics. 

### Methods 

Materials. All chemicals were purchased from Sigma-Aldrich and used as received unless stated otherwise. Likewise, solvents were acquired from Acros Organics, unless otherwise specified, and used without further purification. 

SnI2 precursor purification. A SnI2 ampule (99.999%, trace metals basis) was opened under an N2-filled glovebox. The particles of the chemical were crushed in a separate vial with a metallic spatula and placed inside a covered Petri dish, which was then put onto a hot plate and heated at 250 °C for 1 h to eliminate SnI4 via sublimation. After the treatment, SnI2 is kept under dark conditions in a clean vial for future use. 

Substrate preparation. Glass microscope slides (VWR) were cut into 1.2 cm × 1.2 cm pieces and cleaned in an ultrasonic bath in three 10-min cycles (1: 4% v/v Hellmanex soap in ultrapure water; 2: acetone (VWR), 3: isopropanol (VWR)). Between every step, substrates are thoroughly rinsed with the solvent used in the previous step and then with the solvent to be used in the next step. Next, substrates are dried with a nitrogen gun and treated with UV–light/ozone for 15 min. Substrates are then used directly for perovskite/HTM deposition. ITO substrates (Psiotec, 1.2 cm × 1.2 cm, 15 Ω/cm<sup>2</sup> ) were first rinsed with acetone and exposed to the same cleaning protocol. After UV/ozone, substrates were used immediately for HTM deposition. PEDOT:PSS (Heraeus Clevios GmbH) was filtered (0.45 µm, PTFE) and deposited via spin-coating at 5000 rpm for 30 s followed by heating at 140 °C for 20 min. 300 mg of CuSCN were dissolved in 1 mL of diethyl sulphide (Sigma Aldrich) under stirring for 5 h and filtered (0.45 µm, PTFE), followed by spin-coating deposition (4000 rpm/40 s) and heating (60 °C, 10 min). 248.8 mg of nickel acetate tetrahydrate are dissolved in 10 mL ethanol (VWR) and 60 µL ethanolamine under stirring and heating at 65 °C for 40 min and deposited via spin-coating at 4000 rpm/40 s. Substrates are then annealed at 300 °C for 1 h to obtain NiOx thin films. PMMA coatings required for some perovskite layers were obtained by dissolving 10 mg of the polymer in 1 mL chlorobenzene by heating and stirring at 50 °C overnight. The solution is then applied via spin coating (2000 rpm/ 30 s) onto perovskite films. 

Perovskite thin film preparation. Under an inert atmosphere, a 4:1 v/v mixture of DMF and DMSO (both ultradry and bottled with molecular sieves) were filtered with 0.2 µm PTFE filters. Next, PEAI (GreatCell Solar), FAI (GreatCell Solar), SnI2 and SnF2 (99%) powders are weighed in a 0.2:0.8:1:0.1 molar ratio, respectively, to obtain 500 µL of a 0.8 M (PEA)0.2(FA)0.8SnI3 perovskite precursor solution by heating and stirring at 70 °C for 1 h. The solutions were then filtered (0.2 µm, PTFE) and deposited on the chosen substrate via a two-step spin-coating procedure (1: 1000 rpm/10 s; 2: 5000 rpm/30 s, 800 µL of ultradry toluene are dropped in the middle of the substrate after 12 s), followed by 70 °C annealing for 20 min. 

Sample characterisation. UV–Visible spectroscopy measurements were performed with a Shimadzu UV-2600 integrating-sphere spectrophotometer. Powder XRD patterns were acquired with a PANalytical X’Pert Pro MRD diffractometer by employing Ni-filtered Cu Kα radiation at 40 kV and 40 mA. Steady-state PL spectra were measured with a Jobin Ybon Horiba Fluoromax-3 spectrofluorometer. Timeresolved PL decays (time-correlated single-photon counting) were measured with a Horiba Deltaflex Modular Fluorescence Lifetime setup fitted with a PPD 900 detector. The excitation wavelength was chosen as 404 nm or 635 nm (whichever specified) and applied via a nanoLED (Model N-07; repetition rate: 1 MHz; pulse duration <200 ps). XPS measurements were performed on ITO/PEDOT:PSS/ (PEA)0.8(FA)0.2SnI3 films using a Thermo K-Alpha<sup>+</sup> Surface Analysis setup (photon source: Al Kα, 1486.6 eV). Transport of films from the glovebox to the measuring setup was done by using a customised transfer chamber to avoid film exposure to air. Surface scans were made under ultra-high vacuum conditions with no prior etching to avoid unwanted sample reduction. Spectral fitting and deconvolution were carried out with CasaXPS software. Possible shifts in the acquired spectra were corrected by using the C 1 s peak at 284.8 eV. TGA measurements were conducted with a Mettler Toledo Thermogravimetric analyser under an N2 atmosphere at a 5 °C/min heating rate. Perovskite film thickness (~250 nm) was measured with an Alpha Step Tencor D500 Surface Profilometer. SEM images were taken with an LEO 1525 Field Emission Scanning Electron Microscope used at 10 kV and fitted with an In-Lens detector. Prior to image acquisition, analysed films were unavoidably exposed to air (~1 min) and coated with 10 nm of Cr via sputtering.<sup>1</sup> H-NMR measurements were taken with a 400 MHz Bruker setup, using TopSpin software. 

> 1H-NMR sample preparation. FAI, PEAI, a fresh (PEA)0.8(FA)0.2SnI3 film and a (PEA)0.8(FA)0.2SnI3 film degraded under ambient conditions for 24 h were dissolved separately in a DMSO (VWR)/DMSO-d6 mixture in the glovebox and then sealed into NMR tubes and taken outside for sample measurement. 

I2 detection in fully aged (PEA)0.2(FA)0.8SnI3 films. The detection of the halogen in toluene via UV–Visible spectroscopy in perovskite films exposed to ambient air for 3 weeks was achieved by previously coating perovskite with PMMA to capture the highly volatile halogen. We note that fully degraded samples are analysed so that I2 does not react rapidly with perovskite as soon as it forms. In consequence, only SnI4 is detected in samples analysed without PMMA coating after shorter exposure times (Supplementary Fig. 15). 

8 

NATURE COMMUNICATIONS | (2021) 12:2853 | https://doi.org/10.1038/s41467-021-22864-z | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-22864-z 

Perovskite film exposure to artificial I2 atmospheres and characterisation. I2rich atmospheres were generated by allowing I2 crystals to rest overnight in the glovebox at the bottom of closed vials initially containing N2 only, which allows I2 to achieve equilibrium vapour pressure. Taking T = 22.9 °C, we estimate the gaseous I2 content inside the vials to be ~0.035% (~350 ppm)<sup>87</sup> . Next, (PEA)0.2 (FA)0.8SnI3 films were quickly transferred and sealed into the vials containing the I2 vapours and kept there for a period of 3 min, after which films were removed for their characterisation. Film degradation products were extracted with 3 mL toluene in the glovebox (films degraded with I2 and control fresh films kept in N2) or in ambient air (films degraded with I2 and later exposed to ambient air and films degraded under ambient air) for UV–Visible spectroscopy measurements. 

Optical degradation tests under dry/moist gas flow. In total, 1.2 cm × 0.6 cm (PEA)0.2(FA)0.8SnI3 films were sealed inside 1 cm × 1 cm quartz cuvettes with rubber covers under glovebox dry N2 environment. Cuvettes were then placed outside the glovebox and purged with constant air or N2 gas flow from cylinders. Prior to reaching the sample, gas is bubbled through water/glycerol solutions to control humidity (relative humidity in gas flow determined by water/glycerol ratio, as specified elsewhere<sup>88</sup> ). Simultaneously, optical degradation of perovskite is tracked by measuring the absorbance of the sealed film every 5 min for a 30 min period. 

Device fabrication. PEDOT:PSS is deposited on ITO substrates as specified above and transferred to an N2-filled glovebox. A (PEA)0.8(FA)0.2SnI3 perovskite solution (0.8 M) made with 9:1 v/v DMF:DMSO is stirred for 1 h at 70 °C and filtered (0.2 µm, PTFE) before film deposition. The solution is applied onto PEDOT:PSS via spin-coating at 4000 rpm for 20 s. Diethyl ether is used as the antisolvent (500 µL applied at the tenth second), followed by annealing at 70 °C for 20 min. Next, a 30 mg/mL PC60BM (Ossila) solution in chlorobenzene is deposited at 2000 rpm for 20 s. Next, a bathocuproine (BCP) solution in isopropanol (0.5 mg/mL) is used to coat PC60BM at 5000 rpm for 20 s. Hundred nanometre-thick Ag electrodes are then processed via vacuum (10<sup>−6</sup> mbar) thermal evaporation by using a mask leading to a 0.045 cm<sup>2</sup> device active area. 

Device characterisation. J–V characteristics were measured immediately after fabrication by using simulated AM1.5 solar light (Oriel Instruments) and a Keithley 2400 source metre at a scan rate of 50 mV/s in forwarding bias. Light intensity calibration was carried out with a silicon photodiode. Devices were kept under inert conditions during the measurements by loading them in the glovebox in a homemade measuring chamber. 

Computational details. We carried out DFT<sup>89</sup> calculations as implemented in the Quantum ESPRESSO package<sup>90,91</sup> . For the reaction energies, the Kohn–Sham wave-functions and energies are calculated with the GGA-PBEsol<sup>92</sup> for electron exchange and correlation, using a plane-wave basis, with energy and charge density cutoffs of 50 and 500 Ry, respectively. Ultrasoft pseudopotentials<sup>93</sup> are used to describe the core–valence interactions. The structural relaxation is performed until the force on each atom is smaller than 0.01 eV/Å. The Brillouin zone integration was sampled following the Monkhorst–Pack scheme<sup>94</sup> and convergence with respect to the k-points grid was tested for each compound. For FASnI3, we have used a supercell of 96 atoms to allow for more degrees of freedom for a lowsymmetry structure. 

The reactions energies, ER, are calculated as the sum of total energies, ETot, of the product minus the sum of total energies of the reactants (ER = niΣproducts(ETot(i)) – niΣreactants(ETot(i))), where ni and Etot are the numbers and the total energy of the compounds and chemical species involved in the reaction. For example, the energy of reaction (1) is calculated as: 

#### ERð1Þ ¼ ½ETotðSnI4Þ þ ETot ðSnO2Þ þ 2ETot ðAIÞ��½2ETot ðASnI3Þ þ ETot ðO2Þ�: 

In order to take into account the contribution of the zero-point energy and the entropy effects to the reaction energies, we have calculated the Gibbs free energy (ETot = G(T) = EL + E0 + ET − TS) for each reaction component at the PBE level within the harmonic approximation at 300 K as implemented in the CRYSTAL17 code<sup>95–98</sup> . Here EL is the electronic energy corresponding to the DFT total energy at 0 K, E0 is the zero-point energy, ET is the thermal contribution to the vibrational energy and TS is the entropy contribution. Effective core pseudopotentials were adopted for the heavy atoms Sn (Sn_ECP28MDF-411(51d)G), and I (I_POB_TZVP_2018) and all-electron Gaussian basis sets for N (N_pob_TZVP_2012), C (C_pob_TZVP_2012), H (H_pob_TZVP_2012) and O (O_8-411d11G_valenzano_2006) atoms. These basis sets are taken from the online library of the CRYSTAL17 code<sup>95,96</sup> . For the periodic systems we have used a 2 × 2 × 2 supercell for SnI4 (320 atoms) and FAI salt (288 atoms), 3 × 3 × 3 supercells for FASnI3 (324 atoms), and a 4 × 4 × 4 supercell for SnO2 (384). We note that the calculated reaction energies with DFT at 0 K are −4.67 eV, −0.09 eV, and 0.67 eV for reactions (1), (2), and (5), respectively, which yields similar trends as with the harmonic approximation. We also note that we have used the FASnI3 system for the calculation of the energetics of Reaction (1), instead of the stoichiometric compound PEA0.2FA0.8SnI3 studied in our experiments due to the lack of a welldefined crystal structure from XRD. 

For surface calculations, we have cut the FASnI3 supercell structure along the crystalline plane (001) with Sn/I and FA/I terminations. The resulting slabs have symmetrically equivalent terminations to avoid large dipole effects. To maintain the bulk electronic properties, the slab thickness is chosen to be three times the above supercell of the bulk structure in the out-of-plane direction. To avoid the interaction between the repeated images, the out-of-plane direction of the box containing the slab and the vacuum layer was fixed to 50 Å. The slab without molecules was, first, fully relaxed using the generalised gradient approximation (GGA) with Perdew–Burke–Ernzerhof (PBE) formalism<sup>99</sup> for the exchangecorrelation. The van der Waals corrections were accounted for using the Grimme dispersion correction DFT-D3<sup>100</sup> . As above, ultrasoft pseudopotentials were used for describing the core–valence interactions. The energy and charge density cutoffs were set to 40 Ry and 400 Ry, respectively. The Brillouin zone integration was sampled with a 4 × 4 × 1 k-points grid. Dipole corrections were accounted for to eliminate dipole–dipole interactions between image supercells. For the adsorption of O2 or I2 molecules, we have considered three different configurations of the molecules on the FASnI3 surface, then letting them fully relax. In the case of Sn/I termination, the molecules were initially positioned at distances of 4.5 Å from the SnI2 surface on top of (a) I atom, (b) Sn atom, and (c) FA cation as shown in Supplementary Fig. 18. In the case of FA/I termination, two configurations were considered on top of (a) FA cation and (b) I atom, as shown in Supplementary Fig. 21. The final structures after relaxations are shown in Supplementary Figs. 19 and 20 for O2 and I2, respectively. To further examine the sensitivity of the optimised distance between the O2 molecules and the surface to the initial position before relaxation when the O2 are placed on top of FA and I (Supplementary Fig. 18a, c), we have manually placed the molecules closer to the surface than the optimised distance. After subsequent relaxation, the molecules were repelled to the optimised positions of the initial relaxation; this indicates that there is no bonding interaction between the O2 molecule and the FA or I at the surface. 

Reporting summary. Further information on experimental design is available in the Nature Research Reporting Summary linked to this paper. 

### Data availability 

The data and computational methods that support the findings of this manuscript are available from the corresponding authors upon reasonable request. 

### Code availability 

The CRYSTAL and Quantum Espresso codes that were used are well established computational materials science codes. Quantum Espresso is a General Public Licensed programme and freely accessible and CRYSTAL is distributed according to specific license terms that are available from the developers. 

Received: 10 July 2020; Accepted: 30 March 2021; 



### References 

1. Kojima, A., Teshima, K., Shirai, Y. & Miyasaka, T. Organometal halide perovskites as visible-light sensitizers for photovoltaic cells. J. Am. Chem. Soc. 131, 6050–6051 (2009). 

2. NREL Best Research-Cell Efficiency Chart. https://www.nrel.gov/pv/cellefficiency.html (2021). 

3. Stranks, S. D. et al. Electron-hole diffusion lengths exceeding 1 micrometer in an organometal trihalide perovskite absorber. Science 342, 341–344 (2013). 

4. Xing, G. et al. Long-range balanced electron- and hole-transport lengths in organic-inorganic CH3NH3PbI3. Science 342, 344–347 (2013). 

5. Adinolfi, V. et al. The in-gap electronic state spectrum of methylammonium lead iodide single-crystal perovskites. Adv. Mater. 28, 3406–3410 (2016). 

6. Yin, W. et al. Unusual defect physics in CH3NH3PbI3 perovskite solar cell absorber. Appl. Phys. Lett. 104, 063903 (2014). 

7. Snaith, H. J. Present status and future prospects of perovskite photovoltaics. Nat. Mater. 17, 372–376 (2018). 

8. Correa-Baena, J. P. et al. The rapid evolution of highly efficient perovskite solar cells. Energy Environ. Sci. 10, 710–727 (2017). 

9. Jena, A. K., Kulkarni, A. & Miyasaka, T. Halide perovskite photovoltaics: background, status, and future prospects. Chem. Rev. 119, 3036–3103 (2019). 

10. Noel, N. K. et al. Lead-free organic-inorganic tin halide perovskites for photovoltaic applications. Energy Environ. Sci. 7, 3061–3068 (2014). 

11. Hao, F., Stoumpos, C. C., Cao, D. H., Chang, R. P. H. & Kanatzidis, M. G. Lead-free solid-state organic–inorganic halide perovskite solar cells. Nat. Photon. 8, 489–494 (2014). 

12. Stoumpos, C. C. et al. Hybrid germanium iodide perovskite semiconductors: active lone pairs, structural distortions, direct and indirect energy gaps, and strong nonlinear optical properties. J. Am. Chem. Soc. 137, 6804–6819 (2015). 

9 

NATURE COMMUNICATIONS | (2021) 12:2853 | https://doi.org/10.1038/s41467-021-22864-z | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-22864-z 

13. Krishnamoorthy, T. et al. Lead-free germanium iodide perovskite materials for photovoltaic applications. J. Mater. Chem. A 3, 23829–23832 (2015). 

14. Park, B.-W. et al. Bismuth based hybrid perovskites A3Bi2I9 (A: methylammonium or cesium) for solar cell application. Adv. Mater. 27, 6806–6813 (2015). 

15. Hebig, J. C., Kühn, I., Flohre, J. & Kirchartz, T. Optoelectronic properties of (CH3NH3)3Sb2I9 thin films for photovoltaic applications. ACS Energy Lett. 1, 309–314 (2016). 

16. Konstantakou, M. & Stergiopoulos, T. A critical review on tin halide perovskite solar cells. J. Mater. Chem. A 5, 11518–11549 (2017). 

17. Lee, S. J. et al. Reducing carrier density in formamidinium tin perovskites and its beneficial effects on stability and efficiency of perovskite solar cells. ACS Energy Lett. 3, 46–53 (2018). 

18. Jokar, E. et al. Slow surface passivation and crystal relaxation with additives to improve device performance and durability for tin-based perovskite solar cells. Energy Environ. Sci. 11, 2353–2362 (2018). 

19. Gao, W. et al. Robust stability of efficient lead-free formamidinium tin iodide perovskite solar cells realized by structural regulation. J. Phys. Chem. Lett. 9, 6999–7006 (2018). 

20. Jokar, E., Chien, C.-H., Tsai, C.-M., Fathi, A. & Diau, E. W.-G. Robust tinbased perovskite solar cells with hybrid organic cations to attain efficiency approaching 10%. Adv. Mater. 31, 1804835 (2018). 

21. Diau, E. W. G., Jokar, E. & Rameez, M. Strategies to improve performance and stability for tin-based perovskite solar cells. ACS Energy Lett. 4, 1930–1937 (2019). 

22. Nasti, G. & Abate, A. Tin halide perovskite (ASnX3) solar cells: a comprehensive guide toward the highest power conversion efficiency. Adv. Energy Mater. 10, 1902467 (2019). 

23. Liu, G. et al. Regulated crystallization of efficient and stable tin-based perovskite solar cells via a self-sealing polymer. ACS Appl. Mater. Interfaces 12, 14049–14056 (2020). 

24. Liu, X. et al. Templated growth of FASnI3 crystals for efficient tin perovskite solar cells. Energy Environ. Sci. 13, 2896–2902 (2020). 

25. Wang, C. et al. Self-repairing tin-based perovskite solar cells with a breakthrough efficiency over 11%. Adv. Mater. 32, 1907623 (2020). 

26. Nakamura, T. et al. Sn(IV)-free tin perovskite films realized by in situ Sn(0) nanoparticle treatment of the precursor solution. Nat. Commun. 11, 3008 (2020). 

27. Wang, T. et al. Highly air-stable tin-based perovskite solar cells through grainsurface protection by gallic acid. ACS Energy Lett. 5, 1741–1749 (2020). 

28. Liu, X. et al. Efficient and stable tin perovskite solar cells enabled by amorphous-polycrystalline structure. Nat. Commun. 11, 2678 (2020). 

29. He, X. et al. Highly efficient tin perovskite solar cells achieved in a wide oxygen concentration range. J. Mater. Chem. A 8, 2760–2768 (2020). 

30. Li, J. et al. Biological impact of lead from halide perovskites reveals the risk of introducing a safe threshold. Nat. Commun. 11, 310 (2020). 

31. Stoumpos, C. C., Malliakas, C. D. & Kanatzidis, M. G. Semiconducting tin and lead iodide perovskites with organic cations: phase transitions, high mobilities, and near-infrared photoluminescent properties. Inorg. Chem. 52, 9019–9038 (2013). 

32. Herz, L. M. Charge-carrier mobilities in metal halide perovskites: fundamental mechanisms and limits. ACS Energy Lett. 2, 1539–1548 (2017). 

33. Nishimura, K. et al. Lead-free tin-halide perovskite solar cells with 13% efficiency. Nano Energy 74, 104858 (2020). 

34. Takahashi, Y., Hasegawa, H., Takahashi, Y. & Inabe, T. Hall mobility in tin iodide perovskite CH3NH3SnI3: Evidence for a doped semiconductor. J. Solid State Chem. 205, 39–43 (2013). 

35. Johnston, M. B. & Herz, L. M. Hybrid perovskites for photovoltaics: chargecarrier recombination, diffusion, and radiative efficiencies. Acc. Chem. Res. 49, 146–154 (2016). 

36. Kumar, M. H. et al. Lead-free halide perovskite solar cells with high photocurrents realized through vacancy modulation. Adv. Mater. 26, 7122–7127 (2014). 

37. Marshall, K. P., Walker, M., Walton, R. I. & Hatton, R. A. Enhanced stability and efficiency in hole-transport-layer-free CsSnI3 perovskite photovoltaics. Nat. Energy 1, 16178 (2016). 

38. Lanzetta, L., Marin-Beloqui, J. M., Sanchez-Molina, I., Ding, D. & Haque, S. A. Two-dimensional organic tin halide perovskites with tunable visible emission and their use in light-emitting devices. ACS Energy Lett. 2, 1662–1668 (2017). 

39. Liao, Y. et al. Highly oriented low-dimensional tin halide perovskites with enhanced stability and photovoltaic performance. J. Am. Chem. Soc. 139, 6693–6699 (2017). 

40. Cao, D. H. et al. Thin films and solar cells based on semiconducting twodimensional Ruddlesden–Popper (CH3(CH2)3NH3)2(CH3NH3)n−1SnnI3n+1 perovskites. ACS Energy Lett. 2, 982–990 (2017). 

41. Shao, S. et al. Highly reproducible sn-based hybrid perovskite solar cells with 9% efficiency. Adv. Energy Mater. 8, 1702019 (2017). 

42. Wang, F. et al. 2D-quasi-2D-3D hierarchy structure for tin perovskite solar cells with enhanced efficiency and stability. Joule 2, 2732–2743 (2018). 

43. Li, M. et al. Tin halide perovskite films made of highly oriented 2D crystals enable more efficient and stable lead-free perovskite solar cells. ACS Energy Lett. 5, 1923–1929 (2020). 

44. Jiang, X. et al. Ultra-high open-circuit voltage of tin perovskite solar cells via an electron transporting layer design. Nat. Commun. 11, 1245 (2020). 

45. Chen, M. et al. High-performance lead-free solar cells based on tin-halide perovskite thin films functionalized by a divalent organic cation. ACS Energy Lett. 5, 2223–2230 (2020). 

46. Ran, C. et al. Conjugated organic cations enable efficient self-healing FASnI3 solar cells. Joule 3, 3072–3087 (2019). 

47. Aristidou, N. et al. The role of oxygen in the degradation of methylammonium lead trihalide perovskite photoactive layers. Angew. Chem. Int. Ed. 54, 8208–8212 (2015). 

48. Bryant, D. et al. Light and oxygen induced degradation limits the operational stability of methylammonium lead triiodide perovskite solar cells. Energy Environ. Sci. 9, 1655–1660 (2016). 

49. Aristidou, N. et al. Fast oxygen diffusion and iodide defects mediate oxygeninduced degradation of perovskite solar cells. Nat. Commun. 8, 15218 (2017). 

50. Aristidou, N., Eames, C., Islam, M. S. & Haque, S. A. Insights into the increased degradation rate of CH3NH3PbI3 solar cells in combined water and O2 environments. J. Mater. Chem. A 5, 25469–25475 (2017). 

51. Bu, X. et al. Surface passivation of perovskite films via iodide salt coatings for enhanced stability of organic lead halide perovskite solar cells. Sol. RRL 3, 1800282 (2018). 

52. Lanzetta, L., Aristidou, N. & Haque, S. A. Stability of lead and tin halide perovskites: the link between defects and degradation. J. Phys. Chem. Lett. 11, 574–585 (2020). 

53. Zhang, Y. et al. Ambient fabrication of organic–inorganic hybrid perovskite solar cells. Small Methods 5, 2000744 (2020). 

54. Rahim, W. et al. Geometric analysis and formability of the cubic A2BX6 vacancyordered double perovskite structure. Chem. Mater. 32, 9573–9583 (2020). 

55. Qiu, X. et al. From unstable CsSnI3 to air-stable Cs2SnI6: a lead-free perovskite solar cell light absorber with bandgap of 1.48 eV and high absorption coefficient. Sol. Energy Mater. Sol. Cells 159, 227–234 (2017). 

56. Ke, W., Stoumpos, C. C. & Kanatzidis, M. G. “Unleaded” perovskites: status quo and future prospects of tin-based perovskite solar cells. Adv. Mater. 31, 1803230 (2018). 

57. Kubicki, D. J. et al. Local structure and dynamics in methylammonium, formamidinium, and cesium Tin(II) mixed-halide perovskites from<sup>119</sup> Sn Solid-state NMR. J. Am. Chem. Soc. 142, 7813–7826 (2020). 

58. Leijtens, T., Prasanna, R., Gold-Parker, A., Toney, M. F. & McGehee, M. D. Mechanism of tin oxidation and stabilization by lead substitution in tin halide perovskites. ACS Energy Lett. 2, 2159–2165 (2017). 

59. Liang, H. et al. High color purity lead-free perovskite light-emitting diodes via Sn stabilization. Adv. Sci. 7, 1903213 (2020). 

60. Moeller, T., Edwards, D. C., Brandt, R. L. & Kleinberg, J. Tin (IV) iodide. Inorg. Synth. 4, 119–121 (1953). 

61. Hickling, G. G. Gravimetric analysis—the synthesis of tin iodide. J. Chem. Educ. 67, 702–703 (1990). 

62. Sundqvist, J., Ottosson, M. & Hårsta, A. CVD of epitaxial SnO2 films by the SnI4/O2 precursor combination. Chem. Vap. Depos. 10, 77–82 (2004). 

63. Babayigit, A. et al. Assessing the toxicity of Pb-and Sn-based perovskite solar cells in model organism Danio rerio. Sci. Rep. 6, 18721 (2016). 

64. Ke, J. C. R. et al. Ambient-air-stable inorganic Cs2SnI6 double perovskite thin films via aerosol-assisted chemical vapour deposition. J. Mater. Chem. A 6, 11205–11214 (2018). 

65. Zhu, W. et al. Deciphering the degradation mechanism of the lead-free all inorganic perovskite Cs2SnI6. npj Mater. Degrad. 3, 7 (2019). 

66. Zibouche, N. & Islam, M. S. Structure-electronic property relationships of 2D Ruddlesden–Popper tin- and lead-based iodide perovskites. ACS Appl. Mater. Interfaces 12, 15328–15337 (2020). 

67. Wang, Z., Ganose, A. M., Niu, C. & Scanlon, D. O. First-principles insights into tin-based two-dimensional hybrid halide perovskites for photovoltaics. J. Mater. Chem. A 6, 5652–5660 (2018). 

68. Haruyama, J., Sodeyama, K., Han, L. & Tateyama, Y. Surface properties of CH3NH3PbI3 for perovskite solar cells. Acc. Chem. Res. 49, 554–561 (2016). 

69. Quarti, C., De Angelis, F. & Beljonne, D. Influence of surface termination on the energy level alignment at the CH3NH3PbI3 perovskite/C60 interface. Chem. Mater. 29, 958–968 (2017). 

70. Huang, S., Wu, X., Niu, J. & Qin, S. Structural, magnetic and electronic properties of CrO2 at multimegabar pressures. RSC Adv. 8, 24561–24570 (2018). 

71. El Ajjouri, Y. et al. Mechanochemical synthesis of Sn(II) and Sn(IV) iodide perovskites and study of their structural, chemical, thermal, optical, and electrical properties. Energy Technol. 8, 1900788 (2019). 

72. Funabiki, F., Toda, Y. & Hosono, H. Optical and electrical properties of perovskite variant (CH3NH3)2SnI6. J. Phys. Chem. C 122, 10749–10754 (2018). 

10 

NATURE COMMUNICATIONS | (2021) 12:2853 | https://doi.org/10.1038/s41467-021-22864-z | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-22864-z 

73. Bian, Z. et al. Improving performance of lead-free formamidinium tin triiodide perovskite solar cells by tin source purification. Sol. RRL 2, 1800136 (2018). 

74. Rath, T. et al. Photovoltaic properties of a triple cation methylammonium/ formamidinium/phenylethylammonium tin iodide perovskite. J. Mater. Chem. A 7, 9523–9529 (2019). 

75. Zhu, Z., Chueh, C. C., Li, N., Mao, C. & Jen, A. K. Y. Realizing efficient leadfree formamidinium tin triiodide perovskite solar cells via a sequential deposition route. Adv. Mater. 30, 1703800 (2017). 

76. Yang, Z. et al. Enhancing electron diffusion length in narrow-bandgap perovskites for efficient monolithic perovskite tandem solar cells. Nat. Commun. 10, 4498 (2019). 

77. Parrott, E. S. et al. Effect of structural phase transition on charge-carrier lifetimes and defects in CH3NH3SnI3 perovskite. J. Phys. Chem. Lett. 7, 1321–1326 (2016). 

78. Gamsjäger, H., Gajda, T., Sangster, J., Saxena, S. K. & Voigt, W. Chemical Thermodynamics Vol.12—Chemical Thermodynamics of Tin. (eds Perrone, J.) (Nuclear Energy Agency of the OECD, Issy-les-Molineaux, France, 2012). 

79. Atkins, P. & De Paula, J. Atkins’ Physical Chemistry 8th edn (Oxford University Press, Oxford, United Kingdom, 2006). 

80. Frost, J. M. et al. Atomistic origins of high-performance in hybrid halide perovskite solar cells. Nano Lett. 14, 2584–2590 (2014). 

81. Yang, J., Siempelkamp, B. D., Liu, D. & Kelly, T. L. Investigation of CH3NH3PbI3 degradation rates and mechanisms in controlled humidity environments using in situ techniques. ACS Nano 9, 1955–1963 (2015). 

82. Niu, G., Guo, X. & Wang, L. Review of recent progress in chemical stability of perovskite solar cells. J. Mater. Chem. A 3, 8970–8980 (2015). 

83. Tyagi, D., Varma, S. & Bharadwaj, S. R. Pt/zirconia catalyst for hydrogen generation from HI decomposition reaction of S-I cycle. Int. J. Energy Res. 39, 484–493 (2015). 

84. Zhang, Y. et al. HI decomposition over carbon-based and Ni-impregnated catalysts of the sulfur-iodine cycle for hydrogen production. Ind. Eng. Chem. Res. 54, 1498–1504 (2015). 

85. Singhania, A. & Bhaskarwar, A. N. Development of catalysts for hydrogen production from hydrogen iodide decomposition in thermo-chemical watersplitting sulfur-iodine cycle: a review. Catal. Rev.—Sci. Eng. 59, 446–489 (2017). 

86. Cao, J. et al. Enhanced performance of tin-based perovskite solar cells induced by an ammonium hypophosphite additive. J. Mater. Chem. A 7, 26580–26585 (2019). 

87. Leenson, I. A. Sublimation of iodine at various pressures. Multipurpose experiments in inorganic and physical chemistry. J. Chem. Educ. 82, 241–245 (2005). 

88. Forney, C. F. & Brandl, D. G. Control of humidity in small controlledenvironment chambers using glycerol-water solutions. Horttechnology 2, 52–54 (1992). 

89. Kohn, W. & Sham, L. J. Self-consistent equations including exchange and correlation effects. Phys. Rev. 140, A1133–A1138 (1965). 

90. Giannozzi, P. et al. Advanced capabilities for materials modelling with quantum ESPRESSO. J. Phys. Condens. Matter 29, 465901 (2017). 

91. Giannozzi, P. et al. Quantum espresso: a modular and open-source software project for quantum simulations of materials. J. Phys. Condens. Matter 21, 395502 (2009). 

92. Perdew, J. P. et al. Restoring the density-gradient expansion for exchange in solids and surfaces. Phys. Rev. Lett. 100, 136406 (2008). 

93. Vanderbilt, D. Soft self-consistent pseudopotentials in a generalized eigenvalue formalism. Phys. Rev. B 41, 7892–7895 (1990). 

94. Monkhorst, H. J. & Pack, J. D. Special points for Brillouin-zone integrations. Phys. Rev. B 13, 5188–5192 (1976). 

95. Dovesi, R. et al. Quantum-mechanical condensed matter simulations with CRYSTAL. WIREs Comput. Mol. Sci. 8, e1360 (2018). 

96. R. Dovesi et al. CRYSTAL17 User’s Manual (University of Torino, Torino, 2017). 

97. Pascale, F. et al. The calculation of the vibrational frequencies of crystalline compounds and its implementation in the CRYSTAL code. J. Comput. Chem. 25, 888–897 (2004). 

98. Zicovich-Wilson, C. M. et al. Calculation of the vibration frequencies of α- quartz: the effect of hamiltonian and basis set. J. Comput. Chem. 25, 1873–1881 (2004). 

99. Perdew, J. P., Burke, K. & Ernzerhof, M. Generalized gradient approximation made simple. Phys. Rev. Lett. 77, 3865–3868 (1996). 

100. Grimme, S., Antony, J., Ehrlich, S. & Krieg, H. A consistent and accurate ab initio parametrization of density functional dispersion correction (DFT-D) for the 94 elements H-Pu. J. Chem. Phys. 132, 154104 (2010). 

### Acknowledgements 

S.A.H. acknowledges support from EPSRC (grant numbers EP/R020574/1, EP/R023581/ 1 and EP/P032591/1). L.L. was supported by the EPSRC Centre for Doctoral Training in Plastic Electronics (grant number EP/L016702/1). M.S.I. and N.Z. gratefully acknowledge the EPSRC Grant “Towards Self-scrubbing Stable and Scalable Perovskite Solar Cells” (EP/R020485/1). For supercomputer resources, we thank the MCC/Archer consortium (EP/L000202/1) and Isambard UK National Tier-2 HPC Service operated by GW4 and the UK Met Office and funded by EPSRC (EP/P020224/1). 

### Author contributions 

S.A.H. designed and supervised the experimental project. M.S.I. and N.Z. designed and performed the computational work. L.L. designed experiments, performed sample preparation, spectroscopy and XRD measurements, solar cell fabrication and characterisation, TGA and took photographs of the experimental setup. T.W. carried out sample preparation, spectroscopy measurements, solar cell fabrication and characterisation, TGA and took photographs of the experimental setup. X.L. conducted sample preparation, spectroscopy and XRD measurements and solar cell fabrication and characterisation. D.D. contributed to solar cell fabrication. G.M. performed sample preparation, optical spectroscopy and microscopy measurements and took photographs of the experimental setup. R.J.E.W. contributed to optical spectroscopy measurements and analysis. B.G. provided assistance in optical degradation measurements. T.J.M. conducted solar cell fabrication and characterisation, sample preparation and spectroscopy measurements. T.J.M would like to thank the Royal Commission for the Exhibition of 1851 for their financial support through an 1851 Research Fellowship. L.L., S.A.H., N. Z. and M.S.I. drafted the initial version of the manuscript. All authors contributed to the analysis, discussion and preparation of the final version of the paper. 

### Competing interests 

The authors declare no competing interests. 

### Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-021-22864-z. 

Correspondence and requests for materials should be addressed to M.S.I. or S.A.H. 

Peer review information Nature Communications thanks the anonymous reviewer(s) for their contribution to the peer review of this work. 

Reprints and permission information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2021 

11 

NATURE COMMUNICATIONS | (2021) 12:2853 | https://doi.org/10.1038/s41467-021-22864-z | www.nature.com/naturecommunications 

