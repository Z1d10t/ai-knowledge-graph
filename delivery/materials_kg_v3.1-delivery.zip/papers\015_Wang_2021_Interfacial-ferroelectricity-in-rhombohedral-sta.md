# Interfacial ferroelectricity in rhombohedral-stacked bilayer transition metal dichalcogenides

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Nanotechnology |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 516 |
| 作者 | Xi-Rui Wang, K. Yasuda, Yang Zhang, Song Liu, K. Watanabe, T. Taniguchi, J. Hone, L. Fu et al. |
| DOI | 10.1038/s41565-021-01059-z |
| 源文件 | 015_Wang_2021_Interfacial-ferroelectricity-in-rhombohedral-sta.pdf |

---
**Title:** Interfacial ferroelectricity in rhombohedral-stacked bilayer transition metal dichalcogenides 

**Authors:** Xirui Wang<sup>1†</sup> , Kenji Yasuda<sup>1†*</sup> , Yang Zhang<sup>1</sup> , Song Liu<sup>2</sup> , Kenji Watanabe<sup>3</sup> , Takashi Taniguchi<sup>3</sup> , James Hone<sup>2</sup> , Liang Fu<sup>1</sup> and Pablo Jarillo-Herrero<sup>1*</sup> 

**Affiliations:** 

1Department of Physics, Massachusetts Institute of Technology, Cambridge, Massachusetts, USA. 

2Department of Mechanical Engineering, Columbia University, New York, NY, USA. 

3National Institute for Materials Science, Tsukuba, Japan. 

†These authors contributed equally to this work 

*Correspondence to: yasuda@mit.edu, pjarillo@mit.edu 

# **Introductory paragraph:** 

Van der Waals (vdW) materials have greatly expanded our design space of heterostructures by allowing individual layers to be stacked at non-equilibrium configurations, for example via control of the twist angle. Such heterostructures not only combine characteristics of the individual building blocks, but can also exhibit emergent physical properties absent in the parent compounds through interlayer interactions<sup>1</sup> . Here we report on a new family of emergent, nanometer-thick, semiconductor 2D ferroelectrics, where the individual constituents are well-studied non-ferroelectric monolayer transition metal dichalcogenides (TMDs), namely WSe2, MoSe2, WS2, and MoS2. By stacking two identical monolayer TMDs in parallel, we obtain electrically switchable rhombohedral-stacking configurations, with out-of-plane polarization that is flipped by in-plane sliding motion. Fabricating nearly-parallel stacked bilayers enables the visualization of moiré ferroelectric domains as well as electric-field-induced domain wall motion with piezoelectric force microscopy (PFM). Furthermore, by using a nearby graphene electronic sensor in a ferroelectric field transistor geometry, we quantify the ferroelectric builtin interlayer potential, in good agreement with first-principles calculations. The novel semiconducting ferroelectric properties of these four new TMDs opens up the possibility of studying the interplay between ferroelectricity and their rich electric and optical properties<sup>2–5</sup> . 

# **Main text:** 

Symmetry plays a central role in the electronic band structure and the electronic properties of crystals. Recent advances in the fabrication of 2D layered materials and their heterostructures have enabled convenient control of their crystal symmetry and electronic structures<sup>1</sup> . One of the most prominent examples is the 2H-type transition metal dichalcogenides (TMDs), MX2. Although the bulk crystal is inversion symmetric, spatial inversion symmetry is broken when it is exfoliated down to a monolayer, since the metal (M) and chalcogen (X) atoms occupy different crystallographic sites. The in-plane broken inversion symmetry, together with the spinorbit coupling,  endows monolayer TMDs with an interesting band structure characterized by spin-valley locking, where the spin direction is locked to the valley pseudospin direction<sup>6</sup> . Such spin-valley locking has been shown to induce various unique optical and electronic properties, _e.g._ , valley-polarized excitons<sup>7</sup> , the valley Hall effect<sup>8</sup> , and Ising superconductivity<sup>9–11</sup> . The symmetry and the electronic band structure of TMDs can be further modified by stacking the two monolayers with a precisely controlled angle. When two layers are stacked in an antiparallel manner, the hexagonal-stacked (H-stacked) bilayer TMD is realized, and global inversion symmetry is restored (Fig. 1a). In contrast, when two layers are stacked in parallel, the rhombohedral-stacked (R-stacked) structure is realized<sup>12,13</sup> , which breaks the out-of-plane mirror symmetry, in contrast to monolayer, H-stacked bilayer, or bulk 2H-type crystals. The R-stacked structure takes either an MX- or XM-stacked form, where every M atom on the top layer lies over an X atom in MX stacking, while every X lies over an M in XM stacking (Fig. 1b,c)<sup>14</sup> . The broken mirror symmetry causes interlayer charge transfer through hybridization between the occupied states of one layer and the unoccupied states of the other layer, generating an out-of-plane electric dipole moment<sup>2,3</sup> . Since the two stacking orders are transformed into each other by a lateral shift of the two layers, the out-of-plane polarization could be switched by an in-plane interlayer shear motion, resulting in interfacial ferroelectricity<sup>15,16</sup> . 

The concept of interfacial ferroelectricity has been recently successfully demonstrated in parallel-stacked bilayer boron nitride (BN), where BN is turned into a ferroelectric when two sheets of BN are stacked in parallel<sup>17–19</sup> . In contrast to the conventional top-down approach to obtain 2D ferroelectrics by exfoliating layered polar materials<sup>20–23</sup> , the bottom-up approach based on van der Waals assembly can engineer 2D ferroelectrics out of 

non-ferroelectric parent compounds<sup>17–19,24</sup> . As the latter approach is not limited by the thermodynamic stability of the bulk crystal, it can significantly expand the available 2D ferroelectric materials. In this paper, focusing on the similarity of the TMD and BN crystal structures, we generalize and identify four new interfacial ferroelectrics, namely R-stacked bilayer WSe2, MoSe2, WS2, and MoS2. In addition to the potential application for non-volatile memory devices<sup>4,15,25</sup> , R-stacked bilayer TMDs can incorporate intrinsic ferroelectricity into semiconductors to realize ferroelectric semiconductor field-effect transistors<sup>4,5</sup> . Moreover, as R-stacked bilayer TMDs exhibit polarization-dependent excitonic responses, one can expect ferroelectric switching of the optical properties<sup>2,3</sup> . 

First, we performed PFM on a small-angle twisted bilayer MoSe2 crystal at room temperature to characterize the physical responses on MX and XM domains. Since MX- and XM-stacking are the local energy minima in the parallel stacked form, small-angle twisted TMDs prepared by the tear-and-stack method<sup>26,27</sup> will form triangular domains composed of MX and XM stacking regions (after lattice relaxation<sup>14</sup> ). In fact, triangular patterns of domains are observed in the vertical PFM amplitude image (Fig. 1e). The strong contrast at the domain wall between the adjacent domains (red dotted lines) is attributed to the flexoelectric effect originating from the strain gradient at the domain wall<sup>28</sup> . In addition, we find a relatively weak but finite contrast between the adjacent MX and XM domains (blue circles). As strain gradients are negligible inside the domain, the contrast purely originates from the piezoelectric effect, meaning that each domain has spontaneous out-of-plane polarization in the opposite direction. This observation is consistent with the previous reports in which broken mirror symmetry was detected as contrast in the tunneling current in conductive atomic force microscopy<sup>14</sup> . 

As MX and XM domains have opposite out-of-plane polarizations, they will react differently to the out-of-plane electric field. To study their responses, we performed lateral PFM on an R-stacked bilayer MoSe2 under electric field, as shown in Fig. 1e. Since lateral PFM is sensitive to the flexoelectric effect at the domain wall<sup>28</sup> , but not to the piezoelectric effect at the domain, we track the evolution of the domains through domain wall motion. At _VB_ = −4 V, up and down domains coexist in the field of view (Fig.1e, left schematic and adjacent image). As _VB_ is changed from −4 V to 2 V, the domain walls gradually move, leading to the shrinkage of the down domains until they almost vanish (Fig.1e, right schematic and the adjacent image). The down domains expand when _VB_ 

is swept back, confirming the ferroelectric nature of the R-stacked bilayer MoSe2 (see Fig. S3 and Supplementary Video 1 for detailed images). We note that the polarization switching always occurs through domain wall motion, not through the nucleation of a domain within our electric field range. This indicates that ferroelectric switching may be harder to realize in single-domain devices, and points to the important role of pre-existing domain walls pinned by wrinkles, cracks, and bubbles for the switching. 

The ferroelectricity of R-stacked bilayer TMDs is also detectable by using graphene as an electric sensor<sup>18,23</sup> , which not only allows an accurate estimation of the polarization but also is significant as a proof-of-concept demonstration of a ferroelectric field-effect transistor. For these purposes, we fabricated dual-gated devices as shown in the inset of Fig. 2a, where the resistance of graphene reflects the ferroelectric polarization of the R- stacked bilayer TMDs. As a narrow resistance peak is ideal for probing the polarization, we sandwich graphene with top and bottom BN so as not to directly contact the TMDs, which prevents the broadening of the resistance peak due to spin-orbit coupling<sup>29</sup> , disorder, and defects<sup>30</sup> from TMDs (see Fig. S4 and discussion in Supplementary Materials). Measuring the resistance as a function of the top gate does not lead to hysteresis (Fig. 2a), while prominent hysteresis is observed upon sweeping the bottom gate (Fig. 2b). The resistance peak at the charge neutrality point is shifted by  _VB_ / _dB_ = 0.018 V nm<sup>−1</sup> between the forward and backward scan, where _VB_ is the bottom gate voltage and _dB_ is the total thickness of the bottom dielectrics. In addition, abrupt jump features of resistance are observed at _VB_ / _dB_ = −0.35 V nm<sup>−1</sup> and _VB_ / _dB_ = +0.32 V nm<sup>−1</sup> , as shown in the inset of Fig. 2b. The appearance of hysteresis only in the bottom gate scan suggests that the hysteresis originates from the R- stacked bilayer WSe2 between the bottom gate and graphene. Taken together with the PFM results, we interpret that the hysteresis and the jump features are due to ferroelectric switching through the change of the stacking configuration from MX to XM, or vice versa. The ferroelectric polarization induces additional charge carriers in the graphene, leading to the shift of the resistance peak as the electric field switches the polarization. To study the generality of the ferroelectricity in R-stacked bilayer TMDs, we applied the same procedure to MoSe2, WS2, and MoS2 (Figs. 2c-e). The bottom gate scans exhibit two resistance peaks and the height of each peak changes depending on the sweeping direction. The appearance of the two resistance peaks can be explained by the coexistence of two domains, with each peak corresponding to each domain configuration. For example, the 

whole device is polarized upward in the backward scan of Fig. 2c, while MX and XM domains spatially coexist in the forward scan. 

To further confirm the ferroelectric switching origin of the hysteresis, we measured the resistance of device WSe2 d1 as a function of top and bottom gate voltages. We scanned the top gate repeatedly while changing the bottom gate slowly forward or backward, as indicated by the white arrows in Figs. 3a,b. We observe a diagonal feature corresponding to the graphene charge neutrality point resistance peak, as the bottom gate is scanned backward, with a sudden parallel shift of the diagonal line from the left to the right at _VB_ / _dB_ = −0.28 V nm<sup>−1</sup> (Fig. 3a) Similarly, a parallel shift from the right to the left is observed at _VB_ / _dB_ = +0.37 V nm<sup>−1</sup> for the forward scan (Fig. 3b). As in typical dual-gated devices, the diagonal feature tracks the charge neutrality point, where the net induced carrier density is approximately _n0 = εBN_ ( _VB_ / _dB_ + _VT_ / _dT_ )/ _e_ , with _εBN_ being the dielectric constant of BN, _e_ being the elementary charge, and _dT_ being the thickness of the top BN. The shift of the resistance peak is explained by the extra carrier density induced by the polarization of the R-stacked bilayer TMD: As the polarization switches from up to down, the total carrier density changes from _n0_ +Δ _nP_ to _n0_ −Δ _nP_ . The coercive field in device WSe2 d1 (~0.30 V nm<sup>−1</sup> , Fig. 3c) is larger than those of parallel-stacked bilayer BN devices (~0.10 V nm<sup>−1</sup> )<sup>18</sup> , probably due the higher energy barrier between the oppositely polarized states and the smaller polarization in R-stacked bilayer TMDs (Fig. 4)<sup>15,16</sup> . 

Unlike the abrupt and complete switching in the entire device in WSe2 d1, device WSe2 d2 features step-like ferroelectric switching (Fig. 3d). We replot the resistance map in Fig. 3d as a function of _VB_ / _dB_ + _VT_ / _dT_ and _VB_ / _dB_ (Fig. 3e,f) to highlight the contribution of the extra charge carrier density induced by the polarization. Two vertical resistance peaks are observed in the skewed plots (Fig. 3e,f), which correspond to up and down domains, respectively. As the electric field _VB_ / _dB_ is decreased (increased), the spectral weight shifts from the left (right) peak to the right (left) peak, meaning the expansion of down (up) domains. Hence, we can extract the average polarization ⟨ _P_ ⟩ from the height of the two peaks by performing a two-peak fitting. We observe a multi-step change of polarization as a function of the electric field with a relatively small coercive field (Fig. 3c). Similar features are observed in all the devices except device WSe2 d1 (Fig. S10-S13). We speculate that these behaviors 

originate from the pinning of multiple domain walls within a device. The ferroelectric switching due to the motion of pre-existing domain walls lead to a relatively small coercive field, and multi-step switching is induced by the independent motion of each domain wall. 

Finally, we extract the built-in interlayer potential Δ _VP_ for each material and compare with theory. The blue line in the device schematic (Fig. 4a inset) represents the electrostatic potential profile across the graphite and graphene. When the polarization points up (down), an extra bottom gate voltage _VB_ = −Δ _VP_ ( _VB_ = +Δ _VP_ ) is required to tune graphene to the charge neutrality point. Thus, we can extract Δ _VP_ from the relation Δ _VP_ = Δ _VB_ /2, where Δ _VB_ is the shift of the resistance peak or the separation of the two resistance peaks in the bottom gate scan (Fig. S16b). The experimentally obtained Δ _VP_ as a function of _dB_ for each material is plotted in Fig. 4a. The variations of Δ _VP_ between each device of R-stacked bilayer WSe2, MoSe2, and parallel-stacked bilayer BN are all small, demonstrating the fidelity of our estimation. Δ _VP_ for the four R-stacked bilayer TMDs are all around 55 mV, which is about half of that in parallel-stacked bilayer BN<sup>18</sup> . The experimentally obtained built-in interlayer potentials are in reasonable agreement with our first-principles calculations, as shown in the Fig. 4b table. The consistency obtained for all the materials supports the reliability of both our experimental scheme and the theoretical calculations. 

The ferroelectric hysteresis of R-stacked bilayer TMDs is robust up to room temperature (Figs. 3g and S14), and the switching operation at room temperature demonstrates the potential application for non-volatile memory devices (Fig. S15). The robust ferroelectricity in R-stacked bilayer TMDs not only vastly expands the families of ultrathin 2D ferroelectrics, but also opens up the possibility of studying the interplay between ferroelectricity and the abundant physical properties of TMDs as follows: First, as semiconductor TMDs are electrically doped by gating, we can obtain ferroelectric semiconductors where electronic conduction is switched on and off by the polarization direction<sup>4,5</sup> . Second, TMDs show extraordinary rich optical properties due to tightly bound exciton formation with valley degrees of freedom<sup>2,3</sup> . The ferroelectric polarization couples to these excitonic properties through band structure, enabling the non-volatile electrical control of the optical response. Third, beyond the parallel-stacked systems, the layer polarized nature of MX- and XM-stacked TMDs demonstrated in our study 

will serve as fundamental building blocks of twisted homo-bilayer TMDs, and will cause dramatic electric field response both in real and momentum spaces<sup>14,31,32</sup> . Finally, all of these unique properties will be easily incorporated by making heterostructures with different 2D materials to construct novel functional devices. 

# **Methods:** 

Device fabrication: 

MoSe2 and WSe2 crystals used for device MoSe2 d2, WSe2 d1-d3, and PFM measurement were grown by selfflux growth<sup>33</sup> . Crystals used for device MoSe2 d1 and WS2 were purchased from HQ Graphene. MoS2 crystals were purchased from 2D Semiconductors. BN, graphite, and TMD crystals were exfoliated onto SiO2 (285 nm295 nm)/Si substrate. Graphene and monolayer TMDs were identified using optical contrast. The thickness of BN flakes was acquired by AFM. We exfoliated graphite for bottom gates on SiO2 (285 nm)/Si substrates with pre-patterned markers, followed by heat cleaning in an atmosphere of Ar (40 sccm) and H2 (20 sccm) gases at 350 °C for more than 12 hours to remove the tape residues. Each stack was made by the sequential pickup of top BN, graphene, bottom BN, and the bilayer TMD with a poly(bisphenol A carbonate) (PC)-film-covered Polydimethylsiloxane (PDMS) stamp on a glass slide. After picking up top BN, graphene, and bottom BN, we removed the trapped bubbles by moving the PC stamp and the stack up and down slowly a few times at 70-90 °C. R-stacked bilayer TMD is obtained by the sequential pickup of monolayer TMD flake at room temperature with the tear-and-stack method described in Refs 26 and 27. The whole stack was released to the bottom graphite at 170 °C. The stack was identified with an optical microscope and AFM for bubble-free regions. MoS2 flakes were identified and transferred in a glovebox to avoid oxidation. The stack of MoS2 was annealed in an Ar-only atmosphere at 70 sccm at 300 °C for 6 hours to reduce the bubbles. The stacks were etched into a Hall bar shape by reactive ion etching (RIE) for measurement, and all the contacts and top gates were deposited with Cr/Au with a thermal evaporator. 

Piezoelectric force microscopy measurements: 

The samples for vertical piezoelectric force microscopy (PFM) measurements (Figs. 1d and S2) were fabricated by picking up graphite and small-angle-twisted bilayer MoSe2 with PC on PDMS in sequence. The PC films 

were peeled off from PDMS and placed onto SiO2 (285 nm)/Si substrates, which were then heated up to 200 °C for better adhesion. For the sample for lateral PFM measurements (Fig. 1e), we first prepared BN (13.7 nm)/graphite stack, and heat cleaned in the atmosphere of Ar and H2 gases at 300 °C for 14 hours. We then exfoliated MoSe2 on PDMS and transferred small-angle-twisted bilayer MoSe2. Finally, graphite exfoliated on PDMS was transferred to make electrical contact. The fabricated stack is annealed under Ar-only atmosphere at 170 °C for 10 mins. The PFM measurements were performed with Asylum Research Cypher S atomic force microscope at room temperature. We used Asyelec-01-R2 with a force constant of around 2.8 N m<sup>−1</sup> and a contact resonance frequency of around 280 kHz with the applied AC bias voltage of 1 V for the vertical PFM measurements. We used AC240TM-R3 with a force constant of around 1.5 N m<sup>−1</sup> and a contact resonance frequency of around 600 kHz with the applied AC bias voltage of 2 V for the lateral PFM measurements. The gate voltage was applied by a source meter (Keithley: Model 2400). The contact strength was set to be lower than 30 nN to avoid unintentional damage to the flake and twist angle relaxation. 

Transport measurements: 

The devices were bonded using aluminum wire. The four-probe measurements were done with lock-in amplifiers (SRS: SR830 and SR860), a current preamplifier (DL: Model 1211) and a voltage preamplifier (SRS: SR560) at a frequency of 35.5 Hz. The lock-in time constant was 100ms. The measuring current was 100 nA for device WSe2 d1, WSe2 d2, MoSe2 d2, MoS2, and 1 μA for device WSe2 d3 and WS2. The measurement of device MoSe2 d1 was performed at 100 nA in the main text and 1 μA in the Supplementary Materials. The hysteresis measurements were performed by waiting for 1.5 s at each point to avoid measurement lag. The gate voltages were applied by source meters (Keithley: Model 2400). Devices WSe2 d2 and WSe2 d3 were measured in a He3 cryostat (Janis research). Devices MoSe2 d1, MoSe2 d2, WS2, and MoS2 were measured in a homemade insert. Device WSe2 d1 was measured in both systems. The data of device WSe2 d1 in Fig. 3a,b were taken during the warm-up, when the temperature increased by 30 K due to the lack of helium. The temperature noted in Fig. 3a,b is the average temperature during this measurement. 

DFT calculations: 

Density functional calculations are performed using Perdew-Burke-Ernzerhof generalized gradient approximation<sup>34</sup> with the vdW correction incorporated by DFT-D3 method with Becke-Jonson damping<sup>35</sup> , as implemented in the Vienna Ab-initio Simulation Package<sup>36</sup> . All the calculations are done with projector augmented wave (PAW) pseudopotentials with spin-orbit interaction included. The interlayer distance of R- stacked bilayer MoSe2, WS2, and MoS2 is taken from the bulk lattice constant of 3R-TMDs, and the interlayer distance of R-stacked bilayer WSe2 is taken from the lattice constant of bulk 2H-WSe2 as an approximation<sup>12,37,38</sup> . The vacuum size was chosen to be 20 Å to simulate isolated bilayers. To ensure the periodic boundary condition in the out-of-plane direction, we used the inverted double-bilayer structures and compensated the built-in electric field. The plane-wave cutoff energy is set to be 1200 eV to ensure the convergence of electrostatic potential inside the vacuum, and the Brillouin zone sampling mesh is 12×12×1. We calculated the sum of ionic potential and Hartree potential from charge density to evaluate the built-in interlayer potential. The calculation shows good consistency with an independent work on R-stacked bilayer TMDs<sup>39</sup> . 

# **Acknowledgements:** 

We thank Sergio de la Barrera for fruitful discussions. This research was primarily supported by the U.S. Department of Energy, Office of Science, Basic Energy Sciences, under Award Number DE-SC0020149 (measurement, data analysis, and DFT calculation), by the Center for the Advancement of Topological Semimetals, an Energy Frontier Research Center funded by the U.S. Department of Energy Office of Science, through the Ames Laboratory under contract DE-AC02-07CH11358 (device concept and design), by the Army Research Office (nanofabrication development) through grant #W911NF1810316, and the Gordon and Betty Moore Foundations EPiQS Initiative through grant GBMF9643 to P.J-H. This work made use of the Materials Research Science and Engineering Center Shared Experimental Facilities supported by the National Science Foundation (NSF) (Grant No. DMR-0819762). This work was performed in part at the Harvard University Center for Nanoscale Systems (CNS), a member of the National Nanotechnology Coordinated Infrastructure Network (NNCI), which is supported by the National Science Foundation under NSF ECCS award no. 1541959. K.W. and T.T. acknowledge support from the Elemental Strategy Initiative conducted by the MEXT, Japan, Grant Number JPMXP0112101001, JSPS KAKENHI Grant Numbers JP20H00354 and the CREST(JPMJCR15F3). K. 

Y. acknowledges partial support by JSPS Overseas Research Fellowships. Synthesis of WSe2 and MoSe2 was supported by the NSF MRSEC program through Columbia in the Center for Precision-Assembled Quantum Materials (DMR-2011738). 

# **Author contributions:** 

K.Y. designed and conceived the project. X.W. and K.Y. fabricated the devices and performed transport measurements. K.Y. performed PFM measurements. Y.Z. and L.F. performed the theoretical calculation. S.L. and J.H. grew the WSe2 and MoSe2 (used in device MoSe2 d1) crystals. K.W. and T.T. grew the BN crystal. X.W., 

K.Y, Y.Z., and P.J-H. analyzed the data and wrote the manuscript with the input from all the other authors. 

# **Competing interests:** 

The authors declare no competing interests. 

# **References:** 

1. Du, L. _et al._ Engineering symmetry breaking in 2D layered materials. _Nat. Rev. Phys._ **3** , 193–206 (2021). 

2. Sung, J. _et al._ Broken mirror symmetry in excitonic response of reconstructed domains in twisted MoSe2/MoSe2 bilayers. _Nat. Nanotechnol._ **15** , 750–754 (2020). 

3. Andersen, T. I. _et al._ Excitons in a reconstructed moiré potential in twisted WSe2/WSe2 homobilayers. _Nat. Mater._ **20** , 480–487 (2021). 

4. Cui, C., Xue, F., Hu, W. J. & Li, L. J. Two-dimensional materials with piezoelectric and ferroelectric functionalities. _npj 2D Mater. Appl._ **2** , 18 (2018). 

5. Si, M. _et al._ A ferroelectric semiconductor field-effect transistor. _Nat. Electron._ **2** , 580–586 (2019). 

6. Xiao, D., Liu, G. Bin, Feng, W., Xu, X. & Yao, W. Coupled spin and valley physics in monolayers of MoS2 and other group-VI dichalcogenides. _Phys. Rev. Lett._ **108** , 196802 (2012). 

7. Mak, K. F., He, K., Shan, J. & Heinz, T. F. Control of valley polarization in monolayer MoS2 by optical helicity. _Nat. Nanotechnol._ **7** , 494–498 (2012). 

8. Mak, K. F., McGill, K. L., Park, J. & McEuen, P. L. The valley Hall effect in MoS2 transistors. _Science_ **344** , 1489–1492 (2014). 

9. Saito, Y. _et al._ Superconductivity protected by spin-valley locking in ion-gated MoS2. _Nat. Phys._ **12** , 144–149 (2016). 

10. Lu, J. M. _et al._ Evidence for two-dimensional Ising superconductivity in gated MoS2. _Science_ **350** , 1353–1357 (2015). 

11. Xi, X. _et al._ Ising pairing in superconducting NbSe2 atomic layers. _Nat. Phys._ **12** , 139–143 (2016). 

12. Towle, L., Oberbeck, V., Brownt, B. E. & Stajdohar, R. E. Molybdenum diselenide: Rhombohedral high pressure-high temperature polymorph. _Science_ **154** , 895–896 (1966). 

13. Suzuki, R. _et al._ Valley-dependent spin polarization in bulk MoS2 with broken inversion symmetry. _Nat. Nanotechnol._ **9** , 611–617 (2014). 

14. Weston, A. _et al._ Atomic reconstruction in twisted bilayers of transition metal dichalcogenides. _Nat. Nanotechnol._ **15** , 592–597 (2020). 

15. Li, L. & Wu, M. Binary compound bilayer and multilayer with vertical polarizations: Two-dimensional ferroelectrics, multiferroics, and nanogenerators. _ACS Nano_ **11** , 6382–6388 (2017). 

16. Park, J., Yeu, I. W., Han, G., Hwang, C. S. & Choi, J. H. Ferroelectric switching in bilayer 3R MoS 2 via interlayer shear mode driven by nonlinear phononics. _Sci. Rep._ **9** , 14919 (2019). 

17. Stern, M. V. _et al._ Interfacial ferroelectricity by van der Waals Sliding. _Science_ **372** , 1462–1466 (2021). 

18. Yasuda, K., Wang, X., Watanabe, K., Taniguchi, T. & Jarillo-Herrero, P. Stacking-engineered ferroelectricity in bilayer boron nitride. _Science_ **372** , 1458–1462 (2021). 

19. Woods, C. R. _et al._ Charge-polarized interfacial superlattices in marginally twisted hexagonal boron nitride. _Nat. Commun._ **12** , 347 (2021). 

20. Yuan, S. _et al._ Room-temperature ferroelectricity in MoTe2 down to the atomic monolayer limit. _Nat. Commun._ **10** , 1775 (2019). 

21. Liu, F. _et al._ Room-temperature ferroelectricity in CuInP2S6 ultrathin flakes. _Nat. Commun._ **7** , 12357 (2016). 

22. Zhou, Y. _et al._ Out-of-plane piezoelectricity and ferroelectricity in layered α-In2Se3 nanoflakes. _Nano Lett._ **17** , 5508–5513 (2017). 

23. Fei, Z. _et al._ Ferroelectric switching of a two-dimensional metal. _Nature_ **560** , 336–339 (2018). 

24. Zheng, Z. _et al._ Unconventional ferroelectricity in moiré heterostructures. _Nature_ **588** , 71–76 (2020). 

25. Wu, M. Two-Dimensional van der Waals Ferroelectrics: Scientific and Technological Opportunities. _<mark>ACS</mark>_ 

_<mark>Nano</mark>_ **<mark>15,</mark>** <mark>9229–9237</mark> (2021). 

26. Kim, K. _et al._ Van der Waals heterostructures with high accuracy rotational alignment. _Nano Lett._ **16** , 1989– 1995 (2016). 

27. Cao, Y. _et al._ Superlattice-induced insulating states and valley-protected orbits in twisted bilayer graphene. _Phys. Rev. Lett._ **117** , 116804 (2016). 

28. McGilly, L. J. _et al._ Visualization of moiré superlattices. _Nat. Nanotechnol._ **15** , 580–584 (2020). 

29. Avsar, A. _et al._ Spin-orbit proximity effect in graphene. _Nat. Commun._ **5** , 4875 (2014). 

30. Rhodes, D., Chae, S. H., Ribeiro-Palau, R. & Hone, J. Disorder in van der Waals heterostructures of 2D materials. _Nat. Mater._ **18** , 541–549 (2019). 

31. Zhang, Y., Liu, T. & Fu, L. Electronic structures, charge transfer, and charge order in twisted transition metal dichalcogenide bilayers. _Phys. Rev. B_ **103** , 155142 (2021). 

32. Wang, L. _et al._ Correlated electronic phases in twisted bilayer transition metal dichalcogenides. _Nat. Mater._ **19** , 861–866 (2020). 

33. Edelberg, D. _et al._ Approaching the Intrinsic Limit in Transition Metal Diselenides via Point Defect Control. _Nano Lett._ **19** , 4371–4379 (2019). 

34. Perdew, J. P., Burke, K. & Ernzerhof, M. Generalized gradient approximation made simple. _Phys. Rev. Lett._ **77** , 3865 (1996). 

35. Grimme, S., Antony, J., Ehrlich, S. & Krieg, H. A consistent and accurate _ab initio_ parametrization of density functional dispersion correction (DFT-D) for the 94 elements H-Pu. _J. Chem. Phys._ **132** , 154104 (2010). 

36. Kresse, G. & Furthmüller, J. Efficiency of ab-initio total energy calculations for metals and semiconductors using a plane-wave basis set. _Comput. Mater. Sci._ **6** , 15–50 (1996). 

37. Schutte, W. J., De Boer, J. L. & Jellinek, F. Crystal structures of tungsten disulfide and diselenide. _J. Solid State Chem._ **70** , 207–209 (1987). 

38. Takeuchi, Y. & Nowacki, W. Detailed crystal structure of rhombohedral MoS2 and systematic deduction of possible polytypes of molybdenite. _Schweiz. Miner. Petrog._ **44** , 105–120 (1964). 

39. Ferreira, F., Enaldiev, V. V., Fal’ko, V. I. & Magorrian, S. J. Weak ferroelectric charge transfer in layerasymmetric bilayers of 2D semiconductors. _Sci. Rep._ **11,** 13422 (2021). 

**Figures:** 



Figure 1: Crystal structures and piezoelectric force microscopy of bilayer TMDs. **a** , H-stacked bilayer TMD. The two layers are stacked in antiparallel configuration, and the inversion symmetry is restored as a whole. M: metal atom (W or Mo). X: chalcogen atom (S or Se). **b** , **c,** MX ( **b** ) and XM ( **c** ) stacking forms of R-stacked bilayer TMD. The two layers are stacked in parallel, and an out-of-plane polarization exists due to the vertical alignment of different atoms. **d** , Amplitude image of vertical PFM on small-angle-twisted bilayer MoSe2. The adjacent triangular domains (blue dots) exhibit finite PFM contrast. **e** , Schematic illustration of lateral PFM measurement on a gated small-angle-twisted bilayer MoSe2 device (left). The thickness of BN is 13.7 nm. Amplitude image of lateral PFM under different bottom gate voltages _VB_ . Schematic of the domain configuration is illustrated for _VB_ = −4 V (left) and _VB_ = 2 V (right), as a guide to the eyes. The area surrounded by the solid green curves is the bilayer MoSe2 region. The wrinkles, cracks, and bubbles are shown in dotted green curves. The red and blue regions correspond to up and down domains, respectively. 



Figure 2: Hysteresis in R-stacked bilayer TMD devices. **a** , The resistance of graphene in device WSe2 d1 as a function of top gate in the forward (red) and backward (blue) scan directions. Scan range: −0.43 V nm<sup>−1</sup> to +0.51 V nm<sup>−1</sup> . Inset: The device structure and the optical image of device WSe2 d1. The data was taken from the device on the right. **b** - **e** , The resistance of graphene in R-stacked bilayer TMD devices as a function of bottom gate in the forward and backward scan directions. The scan ranges in **c-e** are enlarged for a better visualization of the resistance peaks. **b** , WSe2 d1. Scan range: −0.38 V nm<sup>−1</sup> to +0.38V nm<sup>−1</sup> . Inset: enlarged data. **c** , MoSe2 d1. Scan range: −0.22 V nm<sup>−1</sup> to +0.28 V nm<sup>−1</sup> . **d** , WS2. Scan range: −0.12 V nm<sup>−1</sup> to +0.15 V nm<sup>−1</sup> with −0.080V nm<sup>−1</sup> applied to the top gate. **e** , MoS2. Scan range: −0.17 V nm<sup>−1</sup> to +0.19 V nm<sup>−1</sup> . 



















Figure 3: Electric field dependence of the polarization. **a** , Bottom gate backward scan of device WSe2 d1. The fast-scan axis, _VT_ / _dT_ , was scanned from +0.62 V nm<sup>−1</sup> to −0.47 V nm<sup>−1</sup> . The slow-scan axis, _VB_ / _dB_ , was scanned from +0.46 V nm<sup>−1</sup> to −0.51 V nm<sup>−1</sup> . The two parallel-shifted resistance ridges correspond to up and down domains, with carrier densities equal to _n0_ +Δ _nP_ , and _n0_ −Δ _nP_ , respectively ( _n0 = εBN_ ( _VB_ / _dB_ + _VT_ / _dT_ )/ _e_ ). The ranges in the _x_ and _y_ axes are slightly enlarged for a better visualization of the resistance peak, same for **b** and **d** . **b** , Bottom gate forward scan of device WSe2 d1. **c** , Average polarization ⟨ _P_ ⟩ in device WSe2 d1 and device WSe2 d2 as a function of _VB_ / _dB_ in the forward (red) and backward (blue) scan directions. ⟨ _P_ ⟩ of device WSe2 d2 was acquired by two-peak Lorentzian fitting of the linecuts of the dual-gate scan. **d** , Bottom gate backward scan of device WSe2 d2. The fast-scan axis, _VT_ / _dT_ , was scanned from +0.32 V nm<sup>−1</sup> to −0.29 V nm<sup>−1</sup> . The slow-scan axis, _VB_ / _dB_ , was scanned from +0.30 V nm<sup>−1</sup> to −0.23 V nm<sup>−1</sup> . **e** , Skewed plot of **d** with _VB_ / _dB_ + _VT_ / _dT_ as the _x_ axis. **f** , Skewed plot of the bottom gate forward scan with the same scan range as **d** . **g** , The resistance of graphene in device WSe2 d1 as a function of bottom gate in the forward (red) and backward (blue) scan directions at _T_ = 300 K. Scan range: −0.38 V nm<sup>−1</sup> to +0.46 V nm<sup>−1</sup> . 





Figure 4: Estimation of built-in interlayer potential in R-stacked bilayer TMDs and comparison with theory. **a** , Built-in interlayer potential, Δ _VP_ , plotted as a function of the total thickness of bottom dielectrics, _dB_ . Parallelstacked bilayer BN (extracted from Ref. 18) (blue), WSe2 (purple), MoSe2 (green), MoS2 (red), and WS2 (pink). The experimental value of BN was extracted from the original data in Ref. 18. Dashed lines represent Δ _VP_ = 55 mV (black) and Δ _VP_ = 110 mV (blue) as a guide to the eyes. Inset: Schematic of electrostatic potential profile between graphite and graphene. Blue line: electrostatic potential. The upper and lower figures show the opposite polarized states. **b,** Experimental and theoretical estimations of Δ _VP_ in parallel-stacked bilayer BN and R-stacked bilayer TMDs. The numbers in the parentheses indicate the standard deviation between the devices. 

