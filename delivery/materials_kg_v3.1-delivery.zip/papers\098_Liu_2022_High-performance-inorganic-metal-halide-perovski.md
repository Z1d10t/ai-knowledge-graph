# High-performance inorganic metal halide perovskite transistors

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Electronics |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 226 |
| 作者 | Ao Liu, Hui-Hui Zhu, Sai Bai, Youjin Reo, Tao-Yu Zou, Myung-Gil Kim, Yong-Young Noh |
| DOI | 10.1038/s41928-022-00712-2 |
| 源文件 | 098_Liu_2022_High-performance-inorganic-metal-halide-perovski.pdf |

---
Articles 

**https://doi.org/10.1038/s41928-022-00712-2** 





# **High-performance inorganic metal halide perovskite transistors** 

**Ao Liu**<sup>**1,5**</sup> **, Huihui Zhu**<sup>**1,5**</sup> **, Sai Bai**<sup>**2,3,5**</sup> **, Youjin Reo**<sup>**1**</sup> **, Taoyu Zou**<sup>**1**</sup> **, Myung-Gil Kim**<sup>**4**✉</sup> **and Yong-Young Noh**<sup>**1**✉</sup> 

**The p-type characteristic of solution-processed metal halide perovskite transistors means that they could be used in combination with their n-type counterparts, such as indium–gallium–zinc-oxide transistors, to create complementary metal–oxide– semiconductor-like circuits. However, the performance and stability of perovskite-based transistors do not yet match their n-type counterparts, which limit their broader application. Here we report high-performance p-channel perovskite thin-film transistors based on inorganic caesium tin triiodide semiconducting layers that have moderate hole concentrations and high Hall mobilities. The perovskite channels are formed by engineering the film composition and crystallization process using a tin-fluoride-modified caesium-iodide-rich precursor with lead substitution. The optimized transistors exhibit field-effect hole mobilities of over 50 cm**<sup>**2**</sup> **V**<sup>**−1**</sup> **s**<sup>**−1**</sup> **and on/off current ratios exceeding 10**<sup>**8**</sup> **, as well as high operational stability and reproducibility.** 

etal halide perovskites are promising semiconductors for use in cost-effective, high-performance tranMsistors because of their ease in processing and high charge carrier mobilities<sup>1–5</sup> . Early work on perovskite transistors using two-dimensional organic–inorganic hybrid perovskites, such as phenethylammonium tin iodide ((PEA)2SnI4) (refs.<sup>6,7</sup> ), demonstrated field-effect mobilities ( _μ_ FE) of up to 2.6 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> . More recently, advances in perovskite-based photovoltaics and light-emitting diodes<sup>8,9</sup> , which have led to a range of optimized strategies for materials and thin films, have rejuvenated research on perovskite transistors. Nevertheless, only limited improvements in device performance have been achieved<sup>10–16</sup> . 

Three-dimensional inorganic caesium tin triiodide (CsSnI3) perovskite is a p-type semiconductor with high electrical conductivity that can be easily deposited at low temperatures. It is widely used in thermoelectric devices and solar cells<sup>17–19</sup> . Due to its low hole effective mass of 0.069 _m_ e (where _m_ e is the free-electron mass) and intrinsic defect tolerance<sup>20,21</sup> , a room-temperature hole mobility of approximately 585 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> has been reported for CsSnI3 ingots using the Hall-effect measurement<sup>22</sup> . CsSnI3 is, thus, a promising candidate for use in high-performance p-channel transistors, which are needed for large-area, low-cost electronic devices<sup>23,24</sup> . The p-type nature of CsSnI3 originates from the strong Sn 5 _s_ –I 5 _p_ antibonding coupling near the valence band maximum (~−5 eV) and the generation of Sn vacancies ( _V_ Sn) as the hole source<sup>17,22</sup> . However, because of the low formation energy of _V_ Sn and the easy oxidation of Sn<sup>2+</sup> to Sn<sup>4+</sup> , CsSnI3 usually suffers from a strong self-p-doping effect, leading to metallic behaviour, which is unsuitable for transistor application<sup>22,25–27</sup> . In addition, the lack of controllable crystallization, which has been found to be fast and highly sensitive to the fabrication conditions<sup>28,29</sup> , leads to low crystallinity and poor uniformity in the deposited films, hindering application in transistors. 

In this Article, we report halide perovskite thin-film transistors (TFTs) that are based on CsSnI3 semiconducting channels and optimized through precursor engineering. We modulate the composition 

and crystallization process of CsSnI3 films using a tin fluoride (SnF2)-modified caesium iodide (CsI)-rich precursor with a portion of the tin iodide (SnI2) substituted with lead iodide (PbI2). The engineered perovskite films exhibit a uniform morphology, high crystallinity, moderate hole concentrations and high Hall mobilities. Using our approach, we create p-channel CsSnI3-based TFTs that exhibit _μ_ FE of over 50 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> and on/off current ratios ( _I_ on/ _I_ off) exceeding 10<sup>8</sup> , as well as high reproducibility and operational stability. 

#### **Device optimizations of CsSnI3-based perovskite TFTs** 

We deposited perovskite channel layers on silicon dioxide (SiO2) (100 nm)/p<sup>+</sup> -Si substrates by the spin coating of precursors comprising CsI and SnI2 (CsI/SnI2 = _x_ ) in _N_ , _N_ -dimethylformamide (DMF), constructing bottom-gate/top-contact perovskite TFTs (Fig. 1a). An additive of SnF2 (10 mol% with respect to the amount of SnI2), which has proved efficient in suppressing Sn<sup>2+</sup> oxidation and modulating the crystallization of Sn-based perovskites<sup>25,30,31</sup> , was incorporated in the precursors for channel deposition. 

We found that perovskite channels processed from CsSnI3 precursors containing slightly excess CsI are highly desirable for TFTs with improved electrical performance. The device was inactive when a CsI-poor precursor with _x_ = 0.85 was used (Supplementary Fig. 1a). For comparison, the channel layer processed from the stoichiometric precursor ( _x_ = 1.00) enabled TFT fabrication with p-channel characteristics, delivering _μ_ FE of 0.01 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> and _I_ on/ _I_ off ≈ 10<sup>5</sup> . The TFT performance was further improved under CsI-rich conditions ( _x_ = 1.10 and 1.25), showing an average _μ_ FE of 1.0 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> and _I_ on/ _I_ off ≈ 10<sup>7</sup> for the optimal devices ( _x_ = 1.25) (Fig. 1b and Supplementary Fig. 1a). The film component analysis using high-resolution inductively coupled plasma mass spectrometry delivers comparable stoichiometry to the feed ratio (Cs/Sn = 1.08:1.00 in the _x_ = 1.25 precursor with 10 mol% SnF2). Note that the proposed CsI-rich synthesis approach markedly differs from the commonly used strategy in Sn-based perovskite photo voltaic devices, where SnI2-rich precursors are preferred<sup>28,29,32</sup> . This striking 

> 1Department of Chemical Engineering, Pohang University of Science and Technology, Pohang, Republic of Korea. 2Institute of Fundamental and Frontier Sciences, University of Electronic Science and Technology of China, Chengdu, China.<sup>3</sup> Department of Physics, Chemistry and Biology (IFM),  Linköping University, Linköping, Sweden.<sup>4</sup> School of Advanced Materials Science and Engineering, Sungkyunkwan University, Suwon, Republic of Korea. 

> 5These authors contributed equally: Ao Liu, Huihui Zhu, Sai Bai. ✉ e-mail: myunggil@skku.edu; yynoh@postech.ac.kr 

**NATuRe eLeCTRoNICS** | VOL 5 | FEBRUARy 2022 | 78–83 | www.nature.com/natureelectronics 

**78** 

<mark>Articles</mark> 

**Nature electroNics** 



<!-- Start of picture text -->
a b c<br>10 8 2.5<br>10 9 40<br>10 7 2.0 10 8<br>Au Au<br>10 6 1.5 10 7 30<br>CsSnI3-based perovskite 10 5 10 6<br>1.0 20<br>SiO2 10 5<br>10 4<br>Si ++  (G) 0.5 10 4 10<br>10 3<br>10 3<br>0<br>10 2 10 2 0<br>1.00 1.10 1.25 1.40 5 10 15 20<br>CsI/SnI2 molar ratio Pb substitution ratio (mol%)<br>d e f<br>10 –2 0 10 –2<br>V DS = –40 V 100 TFTs<br>10 –3 10 –3<br>10 –4 –2<br>10 –4<br>10 –5<br>10 –5<br>10 –6 µ FE = 55 cm 2  V –1  s –1 –4 10 –6 40<br>10 –7 I on/ I off = 3 × 10 8 30<br>10 –7<br>V TH = 12.5 V<br>10 –8 20<br>SS = 0.5 V dec –1 –6 10 –8<br>10 –9 10 –9 10<br>Ig<br>10 –10 –8 10 to –50 V, –10 V per step 10 –10 045 50 55 60<br>10 –11 µ FE (cm 2  V –1  s –1 )<br>10 –11<br>–40 –20 0 20 40 –40 –30 –20 –10 0 –40 –20 0 20 40<br>V GS (V) V DS (V) V GS (V)<br>/ I offon / I offon<br>FE µ (cm) s V2–1 FE µ (cm) s V2–1<br> (A) I –DS  (mA) I DS  (A) I –DS<br>Counts<br><!-- End of picture text -->

**Fig. 1 | Device structure and characteristics of inorganic CsSnI3-based perovskite TFTs. a** , Schematic of the bottom-gate/top-contact TFT structure used in this study. **b** , **c** , _μ_ FE and _I_ on/ _I_ off of TFTs based on channels fabricated from CsSnI3 precursors with different CsI/SnI2 molar ratios ( **b** ) and CsI-rich ( _x_ = 1.25) precursors with different Pb substitution ratios ( **c** ). The error bars were calculated from 12 individual devices. **d** , **e** , Transfer ( **d** ) and output ( **e** ) characteristics of the optimized TFTs ( _x_ = 1.25, 10 mol% Pb substitution and SnF2 = 7 mol%). _I_ g in **d** indicates the gate leakage current. **f** , Transfer characteristics of 100 individual perovskite TFTs fabricated from ten different batches based on the channels processed from the optimal precursor ( _V_ DS = −40 V). The inset shows the _μ_ FE statistics of the 100 devices. 

difference can be rationalized by the different operating mechanisms between transistors and solar cells, calling for different optimization strategies and compositions of perovskite active layers. Briefly, thin channel layers facilitating either electron- or hole-dominated charge transport are desired for unipolar transistors, whereas thick light-harvesting films with long and balanced ambipolar charge transport properties are required for photovoltaic devices (Supplementary Discussion). A further increase in _x_ to 1.40, however, resulted in degraded device performance, which is likely due to the phase segregation of CsI, as discussed later. Despite the achievement of the first CsSnI3 perovskite transistor, the device showed ordinary electrical performance and unstable operating characteristics with an obvious threshold voltage ( _V_ TH) shift after multiple scans (Supplementary Fig. 1b). 

Interestingly, the TFT performance was notably improved by partially substituting SnI2 for PbI2 in the CsI-rich perovskite precursor ( _x_ = 1.25). An optimized Pb substitution ratio of 10 mol% resulted in a much improved TFT performance with high _μ_ FE of 31.5 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> and _I_ on/ _I_ off of 4 × 10<sup>8</sup> , whereas either lower or higher ratios of Pb substitution decreased _μ_ FE (Fig. 1c and Supplementary Fig. 2). Additionally, in the CsI-rich precursor ( _x_ = 1.25) with optimal Pb substitution (10 mol%), minor adjustments of the SnF2 feed ratio (with respect to the total amount of SnI2 and PbI2) notably modulated the _μ_ FE and _V_ TH values of the TFT due to its strong hole-suppression ability (Supplementary Fig. 3). Meanwhile, the 

thickness of the perovskite channel needed to be carefully controlled to enable effective hole depletion for high _I_ on/ _I_ off at a relatively low gate voltage ( _V_ GS) (Supplementary Fig. 4). As a result, 15-nm-thick perovskite channels processed from the Pb-substituted (10 mol%) precursor containing 7 mol% SnF2 enabled further improved TFT performance. A representative device delivered high _μ_ FE of 55 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , _I_ on/ _I_ off of 3 × 10<sup>8</sup> and _V_ TH of 12.5 V (Fig. 1d), representing a remarkable breakthrough in halide perovskite transistors and the p-channel transistor community (Supplementary Table 1). The corresponding output curves of the TFT showed good linearity at low drain–source voltages ( _V_ DS) and current saturation at high _V_ DS (Fig. 1e), indicating negligible charge injection barriers between the perovskite channel and gold electrodes. A reasonably low contact resistance of ~1.7 kΩ cm was calculated using the transmission-line method<sup>33</sup> (Supplementary Fig. 5). Moreover, perovskite channels processed from the optimized precursor ensured high device reproducibility, showing average _μ_ FE of 51.4 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> and _I_ on/ _I_ off exceeding 10<sup>8</sup> calculated from 100 devices in ten different batches (Fig. 1f). 

#### **Thin-film characterizations** 

To clarify the beneficial effects induced by excess CsI and Pb substitution on perovskite channels and the ensuing TFTs, corresponding film characterizations were carried out. As shown in Fig. 2a, both films deposited with excess CsI ( _x_ = 1.25) and additional 10 mol% Pb substitution exhibit minor differences in the absorption spectra 

**NATuRe eLeCTRoNICS** | VOL 5 | FEBRUARy 2022 | 78–83 | www.nature.com/natureelectronics 

**79** 

<mark>Articles</mark> 

**Nature electroNics** 



<!-- Start of picture text -->
a c<br>x  = 1.25 with 10 mol% Pb substitution x  = 1.00 x  = 1.25 10 mol% Pb substitution<br>x  = 1.25<br>x  = 1.25<br>x  = 1.00<br>500 nm 500 nm 500 nm<br>400 600 800 1,000 1,200<br>Wavelength (nm)<br>b d 10 17 e 500<br>x  = 1.25 with 10 mol% Pb substitution 10 mol% Pb substitution<br>x  = 1.25 (220) 7 mol% SnF2<br>x  = 1.00 450<br>(110) (004) 150<br>(112) (224) 10 16<br>100<br>10 mol% Pb substitution<br>50<br>7 mol% SnF2<br>B-γ-CsSnI3<br>10 15 0<br>10 20 30 40 50 1.00 1.10 1.25 1.40 1.00 1.10 1.25 1.40<br>2 θ  (°) CsI/SnI2 molar ratio CsI/SnI2 molar ratio<br>Absorbance (a.u.)<br>Intensity (a.u.)<br>–3Hole concentration (cm) –2–1–1Hall mobility (cm) V s<br><!-- End of picture text -->

**Fig. 2 | Characterizations of perovskite films processed from different precursors. a** – **c** , Ultraviolet–visible absorption spectra ( **a** ), XRD patterns ( **b** ) and SEM images ( **c** ) of perovskite films deposited from precursors with different ratios of CsI:SnI2 ( _x_ ) and that from CsI-rich ( _x_ = 1.25) precursor with 10 mol% Pb substitution (7 mol% SnF2). **d** , **e** , Hall-measurement-derived hole concentration ( **d** ) and Hall mobility ( **e** ) of thin films processed from precursors with different ratios of CsI:SnI2 (without SnF2) and that from the optimal CsI-rich ( _x_ = 1.25) precursor with 10 mol% Pb substitution (7 mol% SnF2). The error bars were calculated from six individual measurements. 

compared with those of the CsSnI3 precursor with _x_ = 1.00. In addition, X-ray diffraction (XRD) patterns revealed the formation of an identical three-dimensional orthorhombic phase (B-γ-CsSnI3) for all the perovskite films (Fig. 2b). The film processed from the CsI-rich ( _x_ = 1.25) precursor exhibited higher diffraction peak intensities, suggesting enhanced crystallinity. The scanning electron microscopy (SEM) image of the film deposited from the stoichiometric precursor exhibited poor uniformity (Fig. 2c). This is caused by the fast and highly sensitive crystallization of solution-processed CsSnI3 perovskite films, similar to observations in previous studies<sup>28,29,32</sup> . Interestingly, a smooth film morphology with full coverage was obtained using the _x_ = 1.25 precursor, which can be ascribed to the retarded perovskite crystallization by the excess CsI. This slow crystallization rate compared with the stoichiometric precursor is confirmed by a slower evolution of the absorption spectra of the CsI-rich sample at different spin-coating periods (Supplementary Fig. 6). A further increase in _x_ to 1.40, however, resulted in the formation of CsI aggregates, as evidenced by the appearance of the CsI phase in the XRD pattern and bright clusters in the SEM image (Supplementary Fig. 7), which were undetectable in the film deposited with _x_ = 1.25. 

We emphasize that an optimized Pb substitution (10 mol%) in the CsI-rich precursor ( _x_ = 1.25) greatly enhanced the crystallinity of the perovskite films, which was verified by the notably increased intensities of the main diffraction peaks and the coarsening of crystals. Because of the lower Lewis acidity of Pb<sup>2+</sup> compared with Sn<sup>2+</sup> (refs.<sup>34,35</sup> ), a small amount of Pb substitution (below 10 mol%) in the CsSnI3 precursor can retard conversion to the perovskite phase, which is beneficial in improving the crystalline quality of Sn-based 

perovskites<sup>36</sup> (Supplementary Fig. 8a). However, further increasing the Pb substitution ratios to over 10 mol% resulted in obviously decreased crystallization peak intensities (Supplementary Fig. 8a). This can be ascribed to the different crystallization behaviours between the Sn<sup>2+</sup> -based perovskite and its Pb analogue during the one-step spin-coating process without the use of an antisolvent; therefore, the slow Pb-based nuclei formation can impede the crystal growth of the CsSnI3 perovskite film<sup>34,36–38</sup> . 

We then conducted the Hall-effect measurements to evaluate the electrical properties of the film. The perovskite films deposited from the stoichiometric precursor showed an average hole concentration of 3 × 10<sup>16</sup> cm<sup>−3</sup> and an average Hall mobility of 54 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> (Fig. 2d,e). For comparison, both CsI-rich precursors with _x_ = 1.10 and 1.25 resulted in slightly lower hole concentrations but obviously increased Hall mobilities of the samples, which were related to the improved film uniformity/crystallinity and decreased defect density, for example, _V_ Sn. The decreased Hall mobility for the perovskite film processed from the precursor with _x_ = 1.40 was due to the phase segregation of CsI. This was in line with the declined TFT performance, highlighting the necessity of carefully controlling the amount of excess CsI in the precursor. Notably, a moderate hole concentration of ~3 × 10<sup>15</sup> cm<sup>−3</sup> and a superior Hall mobility of 486 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> were simultaneously achieved for films deposited from the optimal CsI-rich precursor ( _x_ = 1.25) with 10 mol% Pb substitution containing 7 mol% SnF2 additive (Fig. 2d,e). It is noted that _μ_ FE of the TFT is much lower than the measured Hall mobility value, mainly because of the different transport modes, that is, interface transport for TFTs whereas bulk transport for Hall measurement. Compared with bulk transport, the charge carrier 

**NATuRe eLeCTRoNICS** | VOL 5 | FEBRUARy 2022 | 78–83 | www.nature.com/natureelectronics 

**80** 

<mark>Articles</mark> 

**Nature electroNics** 



<!-- Start of picture text -->
a 10 –2 10 –2<br>10 –3 10 –3<br>10 –4 10 –4<br>10 –5 10 –5<br>10 –6 10 –6<br>10 –7 10 –7<br>10 –8 10 –8<br>10 –9 10 –9<br>10 –10 10 –10<br>0 10 20 0 200 400 600 800 1,000 1,200 1,280 1,290 1,300<br>Time (s)<br>b c<br>10 –2 10 –2<br>10 –3 10 –3<br>10 –4 10 –4<br>Measurement time Δ V TH = 5.2 V<br>10 –5 10 –5<br>1st<br>10 –6 10th 10 –6<br>20th Stress time<br>10 –7 30th 10 –7 Initial<br>40th 600 s<br>10 –8 50th 10 –8 1,200 s<br>60th 1,800 s<br>10 –9 70th 10 –9 3,600 s<br>80th Recovered ≤1 min<br>10 –10 90th 10 –10<br>100th<br>10 –11<br>10 –11<br>–40 –20 0 20 40 –40 –20 0 20 40<br>V GS (V) V GS (V)<br> (A) –I DS<br> (A) –I DS  (A) –I DS<br><!-- End of picture text -->

**Fig. 3 | operational stability of the optimized perovskite TFTs. a** , Continuous on/off switching test with 2,000 cycles ( _V_ GS = ±40 V) of one representative TFT based on the optimized perovskite channel. **b** , Consecutive transfer curve measurement results for 100 cycles ( _V_ DS = −40 V) of one optimized perovskite TFT. **c** , Transfer curves of one optimized perovskite TFT under negative-bias stress measurement for different durations and the recovery behaviour (open circles) ( _V_ GS = _V_ DS = −40 V). 

transport near the semiconductor/dielectric interface is much more likely to be affected by interface defects and roughness, showing lower mobilities. 

The hole mobility ( _μ_ h) of a p-type semiconductor is mainly determined by the hole effective mass ( _m_ h*) and average scattering time ( _τ_ ) following _μ_ h = _qτ_ / _m_ h*, where _q_ is the elementary charge. Considering comparable _m_ h* values between CsPbI3 (0.095 _m_ e) and CsSnI3 (0.069 _m_ e), the 10 mol% Pb substitution should have caused a small change in _m_ h*. Thus, we ascribed the impressive Hall mobility enhancement to the greatly increased carrier scattering time, which is intrinsically dominated by scattering from phonons and substantially affected by extrinsic scattering from grain boundaries, charged impurities and other features. Interestingly, previous studies have predicted that substituting Sn with Pb would lead to enhanced Fröhlich interactions between the charge carriers and phonons, lowering the room-temperature mobility<sup>4</sup> . Considering the poor crystallinity of the pure CsSnI3 film in this work, we believe that extrinsic scattering mechanisms should be dominant over the above intrinsic phonon scattering in determining the mobility. According to the film characterization results, the 10 mol% Pb 

substitution dramatically enhanced the film crystallinity and therefore should have suppressed possible scattering from grain boundaries and crystal disorders, contributing to the notably increased mobility. We note that the film Hall mobilities and TFT performance as a function of the Pb substitution ratio show a consistent trend with the film crystallinity (Supplementary Fig. 8 and Fig. 1c), confirming the key role of crystalline quality in determining the electrical properties of Pb-substituted CsSnI3. On the other hand, with the extracted subthreshold swing (SS) value of 0.6 V dec<sup>−1</sup> from the optimal TFT (Fig. 1c), we calculated a trap state density ( _N_ trap) of 1.87 × 10<sup>12</sup> cm<sup>−2</sup> eV<sup>−1</sup> at the SiO2/perovskite interface (Methods), which is around threefold lower compared with pristine CsSnI3 TFTs ( _x_ = 1.25), that is, 6.8 × 10<sup>12</sup> cm<sup>−2</sup> eV<sup>−1</sup> calculated from an SS value of 1.8 V dec<sup>−1</sup> . This suggested that Pb substitution in the precursor not only boosted the film crystallinity and Hall mobility but also improved the quality of the dielectric/perovskite interface. Such optimizations are key to facilitating charge carrier transport during device operation, rationalizing the exceptional device performance. 

Having elucidated the critical roles of Pb substitution in achieving high-quality CsSnI3 perovskite channels, we attempted to 

**NATuRe eLeCTRoNICS** | VOL 5 | FEBRUARy 2022 | 78–83 | www.nature.com/natureelectronics 

**81** 

<mark>Articles</mark> 

**Nature electroNics** 

evaluate whether other metal elements also produce similar results. Referring to previous attempts on perovskite-based photovoltaic devices<sup>39–41</sup> , we substituted Sn<sup>2+</sup> with several different metal ions, including Cd<sup>2+</sup> , Zn<sup>2+</sup> , Mn<sup>2+</sup> , Bi<sup>3+</sup> , Sb<sup>3+</sup> and In<sup>3+</sup> . Unfortunately, the incorporation of these metals resulted in poor film morphology and lower crystallinity compared with bare CsSnI3 (Supplementary Fig. 9). Notably decreased Hall mobilities and reduced TFT performance were also observed, which derives from the severe scattering from impurities and crystal disorders in the perovskite channels (Supplementary Fig. 9). This result is reasonable considering that both Sn<sup>2+</sup> and Pb<sup>2+</sup> belong to group 14 elements and have similar ionic radii, valence states and coordination configuration<sup>42</sup> . As a result, Sn<sup>2+</sup> is more tolerant to Pb substitution and exhibits high solid solubility compared with the explored alternative metal elements. 

#### **Stability evaluation of high-performance perovskite TFTs** 

Finally, we assessed the stability of perovskite TFTs, which is another key figure of merit for their practical applications. Due to the easy oxidization of Sn<sup>2+</sup> , the device suffered fast degradation after exposure to ambient air, but the durability was dramatically improved with cover glass encapsulation (Supplementary Fig. 10). To evaluate the device operational stability, we performed the measurements in a N2-filled glove box, with TFTs simply encapsulated by a poly(perf luorobutenylvinylether) layer to minimize the possible trace oxygen effects (oxidization and physical absorption<sup>43</sup> ) during the measurements. The on/off switching characteristics of the optimized TFTs showed a constant current response with clear on and off states for 2,000 cycles (Fig. 3a). Reliable device operation was also verified by the negligible change in transfer curves after performing scanning tests for 100 times (Fig. 3b). A more intense device stability evaluation was conducted under constant negative bias voltages ( _V_ GS = _V_ DS = −40 V), which resulted in a negative _V_ TH shift of 5.2 V after 1 h bias stress test (Fig. 3c). The _V_ TH shift could be ascribed to hole trapping in the channel layer and/or at the channel/dielectric interface of the TFT under bias stress<sup>44</sup> . Note that the SS of the transfer curves remained constant during the measurements, suggesting that the devices were robust during operation, and no extra trap states were generated under the intense bias stress<sup>45</sup> . Interestingly, the shifted _V_ TH rapidly recovered to its initial value within 1 min after the measurement, indicating that the trapped holes easily escaped on the removal of applied voltages. This may be due to the unique defect-tolerant character of metal halide perovskites, that is, the majority of the trap states, if introduced by the defects, are close to the band edges acting as shallow traps for the carriers<sup>46</sup> . The fast performance recovery is strikingly different from the observations in commercialized TFTs based on p-type polycrystalline silicon or n-type metal oxide channels<sup>47</sup> , where a notably longer time (in hours) or additional thermal treatments are required to drive the performance recovery after bias stress measurements, suggesting a unique feature of perovskite TFTs. 

#### **Conclusions** 

We have reported high-performance p-channel TFTs using inorganic CsSnI3-based perovskite semiconductors. By carefully engineering SnF2 additive, excess CsI, and Pb substitution ratio in the precursor solution, we could obtain CsSnI3-based perovskite films with high crystallinity and excellent electrical properties. The optimized TFTs deliver _μ_ FE of over 50 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> and _I_ on/ _I_ off exceeding 10<sup>8</sup> , meeting the requirements for applications in the backplane of high-end displays and integrated logic circuits. We also investigated the effects of the precursor components on the film properties and established guidelines for channel optimization in high-performance tin-based perovskite TFTs. Our approach could help lead to the development of high-performance p-channel transistors and complementary electronics that require only low-cost solution processes. 

#### **Methods** 

**Materials.** All the materials and chemicals of CsI (99.9%), PbI2 (99%), SnI2 (99.99%), SnF2 (99%) and DMF (anhydrous, 99.8%) were purchased from Sigma-Aldrich and were used as received without further purification. Poly(perfluorobutenylvinylether) was purchased from AGC (TCL-801M). 

**Preparation of precursor solutions.** The CsSnI3 (0.1 M) precursor solutions were prepared by dissolving CsI and SnI2 powders in various molar ratios (CsI:SnI2 = _x_ , where _x_ = 0.85, 1.00, 1.10, 1.25 and 1.40) in DMF followed by stirring on a hot plate at 50 °C for 2 h. The prepared SnF2 solution (6 mg ml<sup>–1</sup> ) in DMF was stirred overnight at room temperature. The SnF2 in DMF was then added to the CsSnI3 precursors to obtain the solutions (10 mol% SnF2 with respect to SnI2) for film deposition and device fabrication. The mixed solutions were stirred on a hot plate at 50 °C for 20 min and then cooled for 10 min before use. All the precursor solutions were prepared in 4 ml amber vials. For the precursor solutions with Pb substitution, a portion of SnI2 was replaced by PbI2, and the molar ratio of CsI:(SnI2 + PbI2) was fixed at 1.25. The incorporation ratio of SnF2 additive (10 mol%, unless specified otherwise) in the precursors with Pb substitution was adjusted according to the total amount of (SnI2 + PbI2) in the solution. All the precursor preparations were carried out in a N2-filled glove box. 

**Thin-film fabrication and characterization.** The samples for film characterization were prepared by spin coating the precursors on different substrates at 4,000 r.p.m. followed by thermal annealing at 120 °C for 5 min. The film deposition was carried out in a N2-filled glove box with O2 and H2O at 1–2 ppm. The crystal structures of the different films were analysed using XRD with Cu Kα radiation (Bruker D8 ADVANCE) based on samples on glass substrates. The SEM images were recorded using a Hitachi S4800 based on samples on Si wafer. The optical absorption of thin films on quartz was measured using an ultraviolet–visible spectrophotometer (JASCO V-770). The perovskite film component was characterized using highresolution inductively coupled plasma mass spectrometry (Thermo Element XR). 

**Device fabrication.** We fabricated the TFTs based on a bottom-gate, top-contact device structure in a N2-filled glove box. Heavily doped Si substrates (Kunshan Sino Silicon Technology; resistivity, 1–100 Ω cm) with 100 nm thermally grown SiO2 were used as the gate electrode and dielectric layer. The substrates were first cleaned in an ultrasonic bath with acetone, deionized water and isopropyl alcohol for 10 min each. After oven drying at 110 °C, the substrates were treated under argon plasma for 20 s to improve the surface wettability. The precursor solutions were spun on SiO2/Si substrates at 4,000 r.p.m. for 150 s and then annealed at 120 °C for 5 min. The transistor fabrication was completed by evaporating the Au source and drain electrodes (40 nm) with a shadow mask under a high vacuum (10<sup>−7</sup> torr) using a thermal evaporator placed in a N2-filled glove box. The channel length/ width of the TFTs was 150/1,000 μm. 

**Device characterization.** All the perovskite TFTs were characterized at room temperature (approximately 20 °C) in the dark and N2-filled glove box (O2 and H2O levels, 1–2 ppm) using a Keithley 4200-SCS in the continuous bias mode. The perovskite channel layer was patterned via probe scratch for low _I_ g and reliable device characteristics.<sup>45</sup> The _μ_ FE value of the TFTs was calculated in the saturation region from the forward transfer curves as follows: 

2L ~~I~~ DS _μ_ FE = , (1) WCi ( ∂∂ ~~<u>√</u>~~ VGS )2 where _L_ , _W_ and _C_ i are the channel length, channel width and areal capacitance of the dielectric (34 nF cm<sup>–2</sup> ), respectively. Further, _I_ DS and _V_ GS are the source–drain current and gate–source voltage, respectively; _V_ TH was estimated by linearly fitting _I_ DS1/2 with respect to _V_ GS. The SS is the inverse of the maximum slope of the _I_ DS– _V_ GS plot. The TFT _N_ trap was calculated as Ntrap = [ SS×kT/qlog[e] − 1] Cqi<sup>, where</sup><sup>_k_is the</sup> Boltzmann’s constant, _e_ is the base of natural logarithm, and _T_ is the absolute temperature. 

**Hall measurements.** The Hall measurements were performed using the van der Pauw method, using a 0.51 T magnet and a home-made sample holder in a N2-filled glove box at room temperature. The electrical signal during the Hall measurement was obtained using a Keithley 4200-SCS instrument. 

#### **Data availability** 

The data that support the findings of this study are available from the corresponding authors upon reasonable request. 

Received: 1 April 2021; Accepted: 5 January 2022; Published online: 17 February 2022 

#### **References** 

1. Manser, J. S., Christians, J. A. & Kamat, P. V. Intriguing optoelectronic properties of metal halide perovskites. _Chem. Rev._ **116** , 12956–13008 (2016). 

**NATuRe eLeCTRoNICS** | VOL 5 | FEBRUARy 2022 | 78–83 | www.nature.com/natureelectronics 

**82** 

### **Nature electroNics** 

2. Xiao, Z., Song, Z. & Yan, Y. From lead halide perovskites to lead-free metal halide perovskites and perovskite derivatives. _Adv. Mater._ **31** , 1803792 (2019). 

3. Zhu, H., Liu, A. & Noh, Y.-Y. Perovskite transistors clean up their act. _Nat. Electron._ **3** , 662–663 (2020). 

4. Herz, L. M. Charge-carrier mobilities in metal halide perovskites: 

   - fundamental mechanisms and limits. _ACS Energy Lett._ **2** , 1539–1548 (2017). 

5. Paulus, F., Tyznik, C., Jurchescu, O. D. & Vaynzof, Y. Switched-on: progress, challenges, and opportunities in metal halide perovskite transistors. _Adv. Funct. Mater._ **31** , 2101029 (2021). 

6. Kagan, C., Mitzi, D. & Dimitrakopoulos, C. Organic-inorganic hybrid materials as semiconducting channels in thin-film field-effect transistors. _Science_ **286** , 945–947 (1999). 

7. Mitzi, D. B. et al. Hybrid field-effect transistor based on a low-temperature melt-processed channel layer. _Adv. Mater._ **14** , 1772–1776 (2002). 

8. Liu, X.-K. et al. Metal halide perovskites for light-emitting diodes. _Nat. Mater._ **20** , 10–21 (2021). 

9. Kim, J. Y., Lee, J.-W., Jung, H. S., Shin, H. & Park, N.-G. High-efficiency perovskite solar cells. _Chem. Rev._ **120** , 7867–7918 (2020). 

10. Senanayak, S. P. et al. Understanding charge transport in lead iodide perovskite thin-film field-effect transistors. _Sci. Adv._ **3** , e1601935 (2017). 

11. Li, F. et al. Ambipolar solution-processed hybrid perovskite phototransistors. _Nat. Commun._ **6** , 8238 (2015). 

12. Gao, Y. et al. Highly stable lead-free perovskite field-effect transistors incorporating linear π-conjugated organic ligands. _J. Am. Chem. Soc._ **141** , 15577–15585 (2019). 

13. Zhu, H. et al. High-performance and reliable lead-free layered-perovskite transistors. _Adv. Mater._ **32** , 2002717 (2020). 

14. Matsushima, T. et al. Solution-processed organic–inorganic perovskite field-effect transistors with high hole mobilities. _Adv. Mater._ **28** , 10275–10281 (2016). 

15. She, X.-J. et al. A solvent-based surface cleaning and passivation technique for suppressing ionic defects in high-mobility perovskite field-effect transistors. _Nat. Electron._ **3** , 694–703 (2020). 

16. Shao, S. et al. Field-effect transistors based on formamidinium tin triiodide perovskite. _Adv. Funct. Mater._ **31** , 2008478 (2021). 

17. Chung, I., Lee, B., He, J., Chang, R. P. H. & Kanatzidis, M. G. All-solid-state dye-sensitized solar cells with high efficiency. _Nature_ **485** , 486–489 (2012). 

18. Lee, W. et al. Ultralow thermal conductivity in all-inorganic halide perovskites. _Proc. Natl Acad. Sci. USA_ **114** , 8693–8697 (2017). 

19. Xie, H. et al. All-inorganic halide perovskites as potential thermoelectric materials: dynamic cation off-centering induces ultralow thermal conductivity. _J. Am. Chem. Soc._ **142** , 9553–9563 (2020). 

20. Huang, L.-y & Lambrecht, W. R. L. Electronic band structure, phonons, and exciton binding energies of halide perovskites CsSnCl3, CsSnBr3, and CsSnI3. _Phys. Rev. B_ **88** , 165203 (2013). 

21. Brandt, R. E., Stevanović, V., Ginley, D. S. & Buonassisi, T. Identifying defect-tolerant semiconductors with high minority-carrier lifetimes: beyond hybrid lead halide perovskites. _MRS Commun._ **5** , 265–275 (2015). 

22. Chung, I. et al. CsSnI3: semiconductor or metal? High electrical conductivity and strong near-infrared photoluminescence from a single material. High hole mobility and phase-transitions. _J. Am. Chem. Soc._ **134** , 8579–8587 (2012). 

23. Liu, A., Zhu, H. & Noh, Y.-Y. Solution-processed inorganic p-channel transistors: recent advances and perspectives. _Mat. Sci. Eng. R Rep._ **135** , 85–100 (2019). 

24. Salahuddin, S., Ni, K. & Datta, S. The era of hyper-scaling in electronics. _Nat. Electron._ **1** , 442–450 (2018). 

25. Kumar, M. H. et al. Lead-free halide perovskite solar cells with high photocurrents realized through vacancy modulation. _Adv. Mater._ **26** , 7122–7127 (2014). 

26. Xu, P., Chen, S., Xiang, H.-J., Gong, X.-G. & Wei, S.-H. Influence of defects and synthesis conditions on the photovoltaic performance of perovskite semiconductor CsSnI3. _Chem. Mater._ **26** , 6068–6072 (2014). 

27. Wu, B. et al. Long minority-carrier diffusion length and low surface-recombination velocity in inorganic lead-free CsSnI3 perovskite crystal for solar cells. _Adv. Funct. Mater._ **27** , 1604818 (2017). 

28. Li, B. et al. Tin-based defects and passivation strategies in tin-related perovskite solar cells. _ACS Energy Lett._ **5** , 3752–3772 (2020). 

29. Marshall, K. P., Walker, M., Walton, R. I. & Hatton, R. A. Enhanced stability and efficiency in hole-transport-layer-free CsSnI3 perovskite photovoltaics. _Nat. Energy_ **1** , 16178 (2016). 

30. Savill, K. J. et al. Impact of tin fluoride additive on the properties of mixed tin-lead iodide perovskite semiconductors. _Adv. Funct. Mater._ **30** , 2005594 (2020). 

31. Gupta, S., Cahen, D. & Hodes, G. How SnF2 impacts the material properties of lead-free tin perovskites. _J. Phys. Chem. C_ **122** , 13926–13936 (2018). 

32. Song, T.-B., Yokoyama, T., Aramaki, S. & Kanatzidis, M. G. Performance enhancement of lead-free tin-based perovskite solar cells with reducing atmosphere-assisted dispersible additive. _ACS Energy Lett._ **2** , 897–903 (2017). 

## <mark>Articles</mark> 

33. Liu, C., Xu, Y. & Noh, Y.-Y. Contact engineering in organic field-effect transistors. _Mater. Today_ **18** , 79–96 (2015). 

34. Hao, F., Stoumpos, C. C., Chang, R. P. & Kanatzidis, M. G. Anomalous band gap behavior in mixed Sn and Pb perovskites enables broadening of absorption spectrum in solar cells. _J. Am. Chem. Soc._ **136** , 8094–8099 (2014). 

35. Klug, M. T. et al. Metal composition influences optoelectronic quality in mixed-metal lead–tin triiodide perovskite solar absorbers. _Energy Environ. Sci._ **13** , 1776–1787 (2020). 

36. Wang, J. et al. Understanding the film formation kinetics of sequential deposited narrow-bandgap Pb–Sn hybridperovskite films. _Adv. Energy Mater._ **10** , 2000566 (2020). 

37. Zuo, F. et al. Binary-metal perovskites toward high-performance 

   - planar-heterojunction hybrid solar cells. _Adv. Mater._ **26** , 6454–6460 (2014). 

38. Xiao, M. et al. A fast deposition-crystallization procedure for highly efficient lead iodide perovskite thin-film solar cells. _Angew. Chem. Int. Ed._ **53** , 9898–9903 (2014). 

39. Zhou, Y., Chen, J., Bakr, O. M. & Sun, H.-T. Metal-doped lead halide perovskites: synthesis, properties, and optoelectronic applications. _Chem. Mater._ **30** , 6589–6613 (2018). 

40. Wang, K. et al. Metal cations in efficient perovskite solar cells: progress and perspective. _Adv. Mater._ **31** , 1902037 (2019). 

41. Rudd, P. N. & Huang, J. Metal ions in halide perovskite materials and devices. _Trends Chem._ **1** , 394–409 (2019). 

42. Giustino, F. & Snaith, H. J. Toward lead-free perovskite solar cells. _ACS Energy Lett._ **1** , 1233–1240 (2016). 

43. Liu, A. et al. Key roles of trace oxygen treatment for high-performance Zn-doped CuI p-channel transistors. _Adv. Electron. Mater._ **7** , 2000933 (2021). 

44. Lin, Y.-H. et al. Hybrid organic–metal oxide multilayer channel transistors with high operational stability. _Nat. Electron._ **2** , 587–595 (2019). 

45. Liu, A. et al. High-performance p-channel transistors with transparent Zn doped-CuI. _Nat. Commun._ **11** , 4309 (2020). 

46. Kovalenko, M. V., Protesescu, L. & Bodnarchuk, M. I. Properties and potential optoelectronic applications of lead halide perovskite nanocrystals. _Science_ **358** , 745–750 (2017). 

47. Fortunato, E., Barquinha, P. & Martins, R. Oxide semiconductor thin-film transistors: a review of recent advances. _Adv. Mater._ **24** , 2945–2986 (2012). 

#### **Acknowledgements** 

This study was supported by the Ministry of Science and ICT through the National Research Foundation, funded by the Korean government (2021R1A2C3005401, 2020R1A4A1019455, 2020M3F3A2A01085792, 2020M3D1A1110548 and 2020R1A2C4001617) and Samsung Display Corporation. 

#### **Author contributions** 

A.L. and Y.-Y.N. conceived the study and designed the experiments. A.L. and H.Z. fabricated the transistors. A.L., H.Z., Y.R. and T.Z. performed the film characterization and data analysis. S.B. and M.-G.K. contributed to the experimental design and data analysis. A.L., S.B., H.Z., M.-G.K., and Y.-Y.N. wrote the manuscript. Y.-Y.N. supervised the project. All the authors contributed to the final version of the manuscript. 

#### **Competing interests** 

The authors declare no competing interests. 

#### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41928-022-00712-2. 

**Correspondence and requests for materials** should be addressed to Myung-Gil Kim or Yong-Young Noh. 

**Peer review information** _Nature Electronics_ thanks Letian Dou and the other, 

anonymous, reviewer(s) for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at www.nature.com/reprints. 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons. org/licenses/by/4.0/. 

© The Author(s) 2022 

**NATuRe eLeCTRoNICS** | VOL 5 | FEBRUARy 2022 | 78–83 | www.nature.com/natureelectronics 

**83** 

