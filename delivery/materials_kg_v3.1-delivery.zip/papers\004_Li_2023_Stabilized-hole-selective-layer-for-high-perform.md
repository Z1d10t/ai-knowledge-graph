# Stabilized hole-selective layer for high-performance inverted p-i-n perovskite solar cells

| 字段 | 内容 |
|---|---|
| 期刊 | Science |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 703 |
| 作者 | Zhen Li, Xiang-Lang Sun, Xiao-Peng Zheng, Bo Li, Dan-Peng Gao, Shou-Feng Zhang, Xin Wu, Shuai Li et al. |
| DOI | 10.1126/science.ade9637 |
| 源文件 | 004_Li_2023_Stabilized-hole-selective-layer-for-high-perform.pdf |

---
1 

2 

10 

# **Stabilized hole-selective layer for high-performance inverted p-i-n** 

# **perovskite solar cells** 

- 3 

Zhen Li<sup>1</sup> †, Xianglang Sun<sup>1, 2</sup> †, Xiaopeng Zheng<sup>3,5</sup> †, Bo Li<sup>1</sup> †, Danpeng Gao<sup>1</sup> , Shoufeng 

4 Zhang<sup>1</sup> , Xin Wu<sup>1</sup> , Shuai Li<sup>1</sup> , Jianqiu Gong<sup>1</sup> , Joseph M. Luther<sup>3</sup> , Zhong’an Li<sup>2</sup> *, Zonglong 5 Zhu<sup>1,4</sup> * 

6 

- 7 

- 1 Department of Chemistry, City University of Hong Kong, Kowloon 999077, Hong Kong. 

8 

9 

- 11 

- 2 Key Laboratory for Material Chemistry of Energy Conversion and Storage, Ministry of Education, School of Chemistry and Chemical Engineering, Huazhong University of Science and Technology Wuhan, 430074, P. R. China. 

12 

13 

- 3 National Renewable Energy Laboratory, Golden, CO 80401, United States. 

14 

- 15 4 Hong Kong Institute of Clean Energy, City University of Hong Kong, Kowloon 999077, Hong 16 Kong. 

- 17 5 Center of Materials Science and Optoelectronics Engineering, College of Materials Science 18 and Optoelectronic Technology, University of Chinese Academy of Science, Beijing, 100049, 19 P. R. China 

20 

- 21 

- *Corresponding authors. Email: zonglzhu@cityu.edu.hk; lizha@hust.edu.cn 

22 

- 23 †These authors contributed equally to this work. 

- 24 

1 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

- 1 **Abstract** 

- 2 P-i-n geometry perovskite solar cells (PSCs) offer simplified fabrication, greater amenability 

- 3 to charge extraction layers, and low-temperature processing over n-i-p counterparts. Self- 

- 4 assembled monolayers (SAMs) can enhance that performance of p-i-n PSCs, but ultrathin 

- 5 SAMs can be thermally unstable. We report a thermally robust hole-selective layer comprised 

- 6 of nickel oxide (NiOx) nanoparticle film with the surface-anchored (4-(3,11-dimethoxy-7H- 

- 7 dibenzo[c,g]carbazol-7-yl)butyl)phosphonic acid (MeO-4PADBC) SAM that can improve and 8 stabilize the NiOx/perovskite interface. The energetic alignment and favorable contact and 9 binding between NiOx/MeO-4PADBC and perovskite reduced the voltage deficit of PSCs with 

- 10 various perovskite compositions and led to strong interface toughening effects under thermal 11 stress. The resulting 1.53 electron-volt devices achieved 25.6% certified power conversion 12 efficiency and maintained >90% of their initial efficiency after continuously operating at 65 13 Celsius for 1,200 hours under 1 sun illumination. 

14 

15 Phosphonic acid self-assembled monolayers (SAMs) with a carbazole core have enabled 16 performance advances in perovskite solar cells (PSCs), for both single-junction ( _1-4_ ) and 17 perovskite-based tandem solar cells ( _5-9_ ), because of their high hole selectivity, fast hole18 transfer rate, and low interfacial trap state density ( _10-13_ ). However, compared to conventional 19 polymeric and metal oxide hole-transporting materials (HTMs), SAM-based PSCs have 20 exhibited poorer thermal stability ( _14-18_ ). The investigation of the device’s operational 21 stability, with electrical bias under maximum power point (MPP) operation or at open-circuit 22 voltage ( _V_ OC), under elevated temperatures (65° to 85 ℃) is critical to improve the confidence 23 in their stability and to meet the qualification of international stability standards (i.e., ISOS and 24 IEC 61215 standards) ( _19_ ). While most studies on the SAM-based PSCs have reported the 25 operational stability at room temperature or enhanced the device’s durability under thermal 26 stress by stabilizing perovskite surface and bulk ( _20, 21_ ), the degradation effect of SAM27 forming molecules under elevated temperature (>65 ℃) have rarely been discussed (Fig. S1, 28 Table S1). The thermal stability of SAM-forming molecules depends largely on their bonding 29 to the selected substrates, as the bond between the anchoring group and the spacer of the 30 molecule can be broken through temperature-induced desorption ( _22-25_ ). 

31 We report a new SAM, (4-(3,11-dimethoxy-7H-dibenzo[c,g]carbazol-7-yl)butyl)phosphonic 32 acid (MeO-4PADBC), which we anchored to the NiOx film to fabricate inverted p-i-n PSCs 33 (Fig. S2). The NiOx/MeO-4PADBC exhibited an optimal dipole moment and amenable surface 

2 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

- 1 for favorable contact with perovskite that resulted in an ideal energetic alignment, fast hole 

- 2 extraction, and low defect density. Such an interface configuration also immobilized the SAM 

- 3 molecules at the NiOx/perovskite interface and produced a robust hole-selective layer (HSL) 

- 4 for thermally stable PSCs that had thermal-degradation activation energy ~3 times greater than 

- 5 that for ITO/MeO-4PADBC. These synergetic effects enabled 1.53 eV p-i-n PSCs _V_ OC of 1.19 

- 6 V (95% of calculated potential) and a verified power conversion efficiency (PCE) of 25.6%. 

- 7 1.68 eV and 1.80 eV wide-bandgap perovskite composition devices also showed encouraging 

- 8 PCEs of 22.7% and 20.1%, respectively. Moreover, 1.53 eV PSCs using NiOx/MeO-4PADBC 9 HSL maintained >90% of initial efficiency in long-term operational stability tests under 65 ℃ 

- 10 for 1,200 hours, and extrapolation of the Arrhenius energy indicates that the solar cells should 11 maintain 80% of initial efficiency for more than 10 months at 25 ℃. 

12 

13 

## **SAM design and synthesis** 

14 Modulating the terminal functional group is an effective way to tune the interfacial interactions 15 between SAMs and perovskite. For example, the introduction of two methoxy groups (-OMe) 16 into [2-(9H-carbazol-9-yl)ethyl]phosphonic acid (2PACz) enabled a new SAM, [2-(3,617 dimethoxy-9H-carbazol-9-yl)ethyl]phosphonic acid (MeO-2PACz, Fig. 1A), which improved 18 the interfacial contact and enabled a higher efficiency of p-i-n PSC compared to 2PACz ( _10_ ). 19 Nonetheless, the methoxy substitution on carbazole core also caused a decrease of dipole 20 moment from ~2.0 D of 2PACz to ~0.2 D of MeO-2PACz, which in turn led to the offset 21 between the highest occupied molecular orbital (HOMO) of SAM molecule and the valence 22 band maximum (VBM) of the perovskite ( _10, 26_ ). This phenomenon can be ascribed to high 23 planarity and symmetry of the carbazole-structure; the incorporation of two -OMe groups with 24 opposite direction of dipole moment resulted in the net molecular dipole moment of MeO25 2PACz close to zero (Fig. 1 A). We addressed this issue by using a non-coplanar screw-shaped 26 dibenzo[c,g]carbazole (DBC) unit as the core to reduce the negative effect on the dipole 27 moment when introducing -OMe groups, affording a new SAM of MeO-4PADBC (Fig. 1B). 28 Density functional theory (DFT) calculations verified that MeO-4PADBC only has a slightly 29 decreased dipole moment (2.4 D) compared to that of (4-(7H-dibenzo[c,g]carbazol-730 yl)butyl)phosphonic acid (4PADBC) (2.9 D), which is quite different from those obtained for 31 carbazole-based SAMs (Figs. S3 and S4). 

32 The synthetic route of MeO-4PADBC is shown in Fig. S5, along with structural 

3 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

- 1 characterizations presented in Figs. S6 to S9. The calculated HOMO and lowest unoccupied 

- 2 molecular orbital (LUMO) distributions are shown in Fig. S10, with values of -4.91 and -1.15 

3 eV, respectively. To gain a deeper insight of the SAM molecule structure, we grew a single 4 crystal of 3,11-dimethoxy-7H-dibenzo[c,g]carbazole (MeO-DBC, CCDC number: 2279245), 5 which lacked the anchoring group that would disrupt intermolecular interactions. As shown in 6 Fig. S11 A and B, two naphthalene rings are located at different sides of the pyrrole ring and 7 exhibit a dihedral angle of 12.44°, which greatly reduces the planarity and symmetry of the 8 skeleton structure to enable a negligible effect on the dipole moment when introducing -OMe 9 groups. Moreover, the MeO-DBC core had a slipped π-stacked packing motif with strong C- 10 H···π (2.72 Å) and π-π (3.79 Å) interactions (Fig. S11 C) that could induce a highly ordered 11 one-dimensional assembly that favor a dense, tilted, highly ordered monolayer on the substrate 12 (Fig. S11 D) ( _9, 27, 28_ ). 

13 We then calculated the interfacial binding energies between SAMs and perovskite, showing 14 that MeO-4PADBC has a stronger binding with perovskite with a total binding energy ( _Eb_ ) of 15 -7.19 eV, compared with that of -5.27 eV for MeO-2PACz. (Fig. S12). The main electrostatic 16 interaction of the calculated SAMs is the O atoms from -OMe groups with the Pb from 17 perovskite, however MeO-4PADBC has a more energetically favorable contact with perovskite 18 compared with MeO-2PACz, which can be ascribed to the more concentrated electron 19 distribution of the coordinated -OMe group on MeO-4PADBC than that on MeO-2PACz (Fig. 20 S13). Moreover, Bader charge analysis also suggests a stronger Pb-O interaction between 21 MeO-4PADBC and perovskite with a shorter calculated interaction length of 4.7 Å than that of 22 MeO-2PACz of 4.9 Å (Fig. S14), which can be further confirmed by the results of<sup>1</sup> H NMR 23 spectra of the SAMs in DMSO- _d6_ with or without mixing with PbI2 (Fig. S15). 

24 

#### 25 

## **Hole-selective layer applications** 

26 We compared MeO-4PADBC SAM and NiOx/MeO-4PADBC as the HSLs for p-i-n PSCs (Fig. 27 1C). Fourier-transform infrared (FTIR) spectra were then collected by scraping the NiOx and 28 NiOx/MeO-4PADBC films off the substrates to amplify the signal, in which the P=O (1169 cm<sup>-</sup> 29 1) and P-OH (1035 and 950 cm-1) absorption peaks show a clear shift (Fig. 1D), indicating the 30 formation of a chemical bond ( _29_ ). This can be further confirmed by the changes of Ni _2p_ core 31 level of NiOx and NiOx/MeO-4PADBC films deposited on the indium tin oxide (ITO) 32 substrates obtained by X-ray photoelectron spectroscopy (XPS) spectra (Fig. S16). The crystal 

4 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

- 1 structure and absorbance of representative perovskite film with a composition of 

- 2 Cs0.05FA0.85MA0.1PbI3 on both substrates remained unchanged (Figs. S17 and S18). However, 

- 3 the perovskite deposited on ITO/NiOx/MeO-4PADBC substrate had larger crystal domains than 

- 4 those on control substrates (Fig. S19). This is because the denser anchoring of SAM molecules 

- 5 onto the ITO/NiOx substrate through more robust tridentate binding absorption, which can not 

- 6 only reduce the surface roughness of ITO/NiOx substrate ( _30-32_ ) (Figs. S20 and S21), but also 

- 7 lead to a more hydrophobic surface (Fig. S22) and stronger interaction of perovskite ( _33-35_ ). 

- 8 These synergetic effects contribute to facilitating the perovskite crystal nucleation and growth, 

- 9 thus enhancing the perovskite crystallization. 

10 



5 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

10 

11 

1 **Fig. 1 Molecular structure and electrical properties of HSLs.** Molecular structure and side view of 2 **(A)** MeO-2PACz and **(B)** MeO-4PADBC; **(C)** Schematic illustration of MeO-4PADBC anchoring on 3 NiOx nanoparticle as the HSL in PSC; **(D)** FTIR spectra of MeO-4PADBC and NiOx/MeO-4PADBC, 4 respectively; **(E)** UPS spectra of ITO substrates covered by NiOx, MeO-4PADBC and NiOx/MeO5 4PADBC, respectively. Left: UPS spectra around the secondary electron cutoff (WF refers to work 6 function); right: UPS spectra in the valence band (VB) region. **(F)** Schematic representation of the band 7 edge positions of the studied HSLs based on values from UPS measurements, referenced to the vacuum 8 level. _EF_ and _EVAC_ represent Fermi-level, and vacuum level, respectively. EVBM and ECBM represent the 9 energy of valence band maximum, and conduction band minimum, respectively. 

12 

13 

14 

15 

16 

17 

18 

19 

20 

21 

22 

23 

24 

25 

We further used ultraviolet photoelectron spectroscopy (UPS) to assess the energetic alignment of different substrates relative to perovskite absorbers with different bandgaps (1.53, 1.68, and 1.8 eV, see Fig. 1E, and Fig. S23), and the results are summarized in Fig. 1F. The HOMO energy levels are -5.34 eV for ITO/MeO-4PADBC and -5.45 eV ITO/NiOx/MeO-4PADBC, respectively, and the work function (Φ) of the latter substrate is deeper than that of  former one (-4.95 versus (vs.) -4.90 eV), an indicative of better energetic alignment with different perovskite absorbers. However, upon application of the carbazole-based SAM molecules onto the ITO/NiOx surface, the ITO/NiOx/MeO-2PACz system exhibited an upward shift of the Φ, in contrast to the ITO/NiOx/2PACz substrate ( _26, 36_ ) (Fig. S24). This phenomenon can be attributed to the incorporation of -OMe on 2PACz, which significantly reduces the diploe moment. This reduction can be explained by the highly planar carbazole motif, as discussed earlier. Time-resolved photoluminescence (TRPL) decay data showed a decreased carrier lifetime from 925.5 ns for the perovskite on ITO to 42.9 and 32.3 ns for the perovskite on ITO/MeO-4PADBC and ITO/NiOx/MeO-4PADBC, respectively, indicating a more facilitated hole extraction resulted by the ITO/NiOx/MeO-4PADBC substrate (Fig. S25, Table S2). 

26 

27 

## **Solar cell performance and characterization** 

28 We further evaluated the photovoltaic performance of PSCs with a p-i-n device configuration: 29 glass/ITO/HSL/perovskite/2D passivation layer/C60/bathocuproine (BCP)/Ag (Fig. 2A). The 30 2D passivation layer was a mixture of 4-trifluorophenylethylammonium iodide (CF3-PEAI) 31 and methylammonium iodide (MAI) with an optimal volume ratio of 3:1 ( _4_ ). The cross-section 32 scanning electron microscopy (SEM) images of the PSC (1.53 eV) showed a thickness of ~ 33 715 nm for the perovskite films (Fig. S26). The device with NiOx/MeO-4PADBC as the HSL 34 (1.53 eV) showed negligible hysteresis and had a high verified PCE of 25.6% for a mask area 35 of 0.0414 cm<sup>2</sup> (Figs. S27 and S28), with a _V_ OC of 1.19 V, a short-circuit current density ( _J_ SC) 36 of 25.4 mA cm<sup>-2</sup> , and a fill factor (FF) of 84.6%, which outperformed the MeO-4PADBC- 

6 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

- 1 based device (PCE = 24.2% with _V_ OC = 1.16 V, _J_ SC = 25.4 mA cm<sup>-2</sup> , and FF = 82.1%). The 2 NiOx control device without a SAM only showed a PCE of 21.6%, attributed to a mismatch of 3 energetic alignment and high surface defect density on NiOx film ( _37, 38_ ) (Fig. 2B). Moreover, 4 we have also conducted the HSL engineering by applying carbazole-based SAM anchoring on 5 NiOx. The _V_ OC of NiOx/MeO-2PACz-based device (1.15 V) is lower than that of the device 6 with NiOx/2PACz (1.17 V) (Figs. S29 A and B). This issue was well addressed by replacing 7 the carbazole motif with a non-planar DBC core in SAM molecules (Figs. S29 C and D). To 8 better understand the mechanism of the improved _V_ OC and FF with the use of NiOx/MeO9 4PADBC as HSL, we further conducted the FF loss (supplementary text, Fig. S30) and _V_ OC 

- 10 loss calculations (supplementary text, Fig. S31, Table S3). We observed that the improved _V_ OC 11 and FF of NiOx/MeO-4PADBC were mainly attributed to the suppressed non-radiative 12 recombination loss, indicating reduced trap state density at the HSL/perovskite interface. 

13 Our NiOx/MeO-4PADBC strategy also worked effectively for 1.68 eV and 1.80 eV PSCs, 14 resulting in PCEs of 22.7% and 20.1%, respectively (Fig. 2C, Figs. S32, Table S4). Steady15 state power output (SPO) confirmed the device performance of three bandgap devices, with 16 stabilized PCEs of 25.5%, 22.3%, and 19.5% for 1.53, 1.68 and 1.8 eV, respectively (Fig. 2D). 17 Additionally, the calculated _J_ SC values from external quantum efficiency (EQE) of the 18 champion devices were consistent with those extracted from the current density-voltage ( _J-V_ ) 19 measurements (Fig. S33), and the derivatives of EQE spectra can further confirm the perovskite 20 bandgaps applied here (Fig. S34). We further presented the EQE with internal quantum 21 efficiency (IQE) results of representative 1.53 eV device with HSLs of NiOx, MeO-4PADBC 22 and NiOx/MeO-4PADBC in Fig. S35. The IQE between 550 nm to 700 nm is spectrally flat 23 and approaches nearly 100% for both of MeO-4PADBC and NiOx/MeO-4PADBC based 24 devices, indicating efficient charge collection and transfer at the perovskite interface achieved 25 by the incorporation of SAM ( _12, 39_ ). 

26 The defect density profiles were then studied to identify enhanced photovoltaic performance 27 through space charge limit current (SCLC) method (Fig. S36). The hole-only devices with 28 NiOx/MeO-4PADBC showed the lowest defect density of 1.96× 10<sup>15</sup> cm<sup>-3</sup> , compared with 29 those with MeO-4PADBC (2.91× 10<sup>15</sup> cm<sup>-3</sup> ) and NiOx (3.81× 10<sup>15</sup> cm<sup>-3</sup> ). In addition, the 30 decreased slope of the light intensity dependence _V_ OC plot for NiOx/MeO-4PADBC-based 31 devices supported a reduced interfacial trap density at the HSL/perovskite interface ( _40_ ) (Fig. 32 S37). We note that PSCs based on NiOx/MeO-4PADBC further demonstrated a lower leakage 33 current than those on other HSL (Fig. S38), which we attributed to the compact NiOx layer 

7 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

- 1 preventing the perovskite from contacting ITO through the pinholes in the ultrathin SAM layer. 2 These results demonstrated that the NiOx/MeO-4PADBC HSL effectively increased _V_ OC of the 3 PSCs. 

- 4 To quantify the interface losses, quasi-Fermi level splitting (QFLS) analysis for partial cell 5 stacks was conducted. A laser wavelength of 375 nm was used to illuminate a PSC with 1-sun 6 equivalent intensity by accommodating the generated current near _J_ SC under a standard solar 7 simulator ( _41, 42_ ) (supplementary text, Fig. S39). As shown in Fig. 2E, the QFLS of 8 ITO/NiOx/MeO-4PADBC/perovskite stack was comparable to the glass/perovskite stack, with 

- 9 implied _V_ OC of 1.17 V vs. 1.18 V for 1.53 eV perovskite film, 1.26 V vs. 1.27 V for 1.68 eV 

- 10 perovskite film, and 1.35 V vs. 1.36 V for 1.80 eV perovskite film, respectively. These results 

- 11 indicated a low voltage loss on the interface between NiOx/MeO-4PADBC and perovskites. 

- 12 We further performed the QFLS measurements on the ITO/HSL/perovskite/passivation 13 layer/electron-transporting layer (ETL) stacks (Fig. 2F), with the _V_ OCs of the PSCs listed as a 14 comparison. The differences between the QFLS of PSCs on ITO/NiOx/MeO-4PADBC and the 

- 15 _V_ OC extracted from related _J-V_ measurements were comparable, demonstrating spatially flat 

- 16 Fermi levels throughout the device and low energy offset on the HSL for carrier extraction ( _27,_ 

- 17 _28_ ). It is noteworthy that the _V_ OC of our 1.53 eV devices (1.19 V) reached 95% of their 

- 18 calculated potential, and the _V_ OC of our 1.68 eV (1.25 V) and 1.80 eV (1.34 V) devices also 19 approached 90% of the calculated potential (Fig. 2G). 

8 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

1 

12 



2 **Fig. 2 Photovoltaic performance of PSCs with different HSLs. (A)** Schematic illustration of p-i-n 3 PSC. **(B)** _J-V_ curves of the best performing 1.53 eV devices with NiOx, MeO-4PADBC, and NiOx/MeO4 4PADBC as HSL. **(C)** _J-V_ curves of the best performing NiOx/MeO-4PADBC-based devices with the 5 bandgap of 1.53 eV, 1.68 eV, 1.80 eV (Rev. refers to reverse scan, For. refers to forward scan). **(D)** SPO 6 at the MPP for the best performing NiOx/MeO-4PADBC-based PSCs with three bandgaps of perovskite 7 absorbers. **(E)** QFLS in the case of three bandgaps of perovskite with different HSLs. **(F)** Comparison 8 of the _V_ OC of actual PSCs with the corresponding QFLS of representative layer stacks. **(G)** Comparison 9 of the _V_ OC with different bandgaps of devices from literatures to our work. The line represents the _V_ OC 10 extracted from calculated potential. Wide-bandgap region refers to 1.6 to 1.9 eV in the figure. 11 

### **PSC stability studies** 

13 Previous reports have demonstrated that SAMs desorb under thermal stress from the anchored 14 substrate ( _29, 30_ ), but few effective solutions to this problem have been explored. To estimate 15 the thermal stability of the ITO/NiOx/MeO-4PADBC substrate, we applied Kevin probe force 16 microscopy (KPFM) to record the surface potential evolution of the SAM under heat treatment 17 by taking pristine ITO/MeO-4PADBC as a reference. Before thermal aging, the ITO/MeO- 

18 4PADBC and ITO/NiOx/MeO-4PADBC substrates both exhibited relatively uniform surface 19 potential with a narrow contact potential distribution (CPD) of ~40 mV, indicating the SAM 

9 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

- 1 molecules were densely packed onto both of ITO and NiOx surfaces (Fig. 3, A and B). After 

- 2 aging on a hotplate at 65 ℃ for 1,200 hours, the NiOx/MeO-4PADBC substrate displayed 3 negligible CPD changes, whereas the ITO/MeO-4PADBC CPD value increased to ~70 mV 

- 4 (Fig. 3, C and D). We propose that the fluctuations of CPD for the ITO/MeO-4PADBC substrate 5 could be attributed to either desorption or morphological changes under thermal stress, or both 

- 6 of them. 

- 7 To further explore the binding ability of SAM to the substrate under heating, DFT simulations 

- 8 were conducted to investigate the binding energies between MeO-4PADBC and ITO or NiOx 

- 9 substrate at 300 K (~27 °C) and 340 K (~67 ℃) (Fig. 3, E and F). MeO-4PADBC had a higher 

- 10 binding energy with NiOx (-22.4 eV) than with ITO (-16.7 eV) at 300 K, suggesting a stronger 

- 11 bonding strength on the NiOx film. This difference was attributed to the higher density of 12 hydroxyl groups on the NiOx surface than on the ITO, which is critical to the chemisorption of 13 SAM on the metal oxide ( _43, 44_ ). The tridentate binding between SAM and NiOx was stronger 

- 14 than the bidentate binding between SAM and ITO ( _29, 45_ ). At 340 K, the binding energy 

- 15 between SAM and ITO decreased from -16.7 to -11.6 eV, but that between MeO-4PADBC and 

- 16 NiOx film showed minor changes (-20.3 eV). These results indicated that MeO-4PADBC on 17 the NiOx film is more robust against thermal stress compared to MeO-4PADBC on bare ITO. 

18 



10 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

1 **Fig. 3 Analysis of the degradation mechanism of PSCs. (A to D)** Surface potential images obtained 2 by scanning Kelvin probe microscopy (scale bar: 500 nm) of the HSLs before and after aging at 65<sup>o</sup> C 3 for 1,200 hours. At the bottom of the figure are the statistical potential distributions of film surfaces. **(E)** 4 DFT calculation of the binding energy of MeO-4PADBC with ITO and NiOx, respectively. **(F)** Binding 5 energies ( _Eb_ ) of MeO-4PADBC with ITO and with NiOx at the temperature of 300 and 340 K. 

6 

7 Thermal accelerated aging measurements were conducted to evaluate the reliability of SAM8 based PSCs. To avoid the influence of 2D capping layer, the encapsulated devices without top 9 passivation were prepared for stability testing. The initial _J-V_ curves and photographs of the 10 encapsulated devices are shown in Fig. S40 and S41, respectively. The PSCs were operated 11 under constant 1-sun illumination at fixed resistance loads near the MPP with the temperature 12 ranging from 25° to 100℃, following ISOS-L-2I procedure ( _19_ ). The MeO-4PADBC-based 13 devices degraded to 85% and 65% of starting PCE after 1,200 hours at 25 ℃ and 65 ℃, 14 respectively (Fig. 4A). When the aging temperature increased to 85 ℃, only 47% of its initial 15 PCE retained after 800 hours. The NiOx devices retained 85% and 65% of initial PCEs at 65° 16 and 85 ℃, respectively, after 1,200 hours (Fig. 4B). However, the NiOx/MeO-4PADBC-based 17 devices retained 90% and 74% of initial PCEs after 1,200 hours at 65° and 85 ℃, respectively 18 (Fig. 4C), which was consistent with the degradation analysis in Fig. 3. Both devices based on 19 NiOx, MeO-4PADBC, or NiOx/MeO-4PADBC as HSL showed a more obvious downward 20 trend when the aging temperature raised to 100 ℃. For a more comprehensive evaluation of 21 the thermal stability of our NiOx/MeO-4PADBC strategy, we further applied the PSCs with top 22 passivation to conduct the operational stability at 65 ℃ for 500 hours (Fig. S42). The devices 23 presented a slightly improved stability compared to the device without passivation at the same 24 time stage, which maintained 96% of its initial PCE. This may be due to the higher hydrophobic 25 surface brought by the CF3-PEAI passivation ( _46_ ). 

26 We then determined the activation energy ( _E_ a) of the temperature-dependent degradation of our 27 PSCs with different HSLs according to previously reported method (supplementary text) ( _47_ ). 28 The _Ea_ value of NiOx/MeO-4PADBC-based devices (0.389 ± 0.022 eV) was almost three times 29 higher than that of MeO-4PADBC-based devices (0.150 ± 0.017 eV). The lifetime acceleration 30 factor ( _AF_ ) of each temperature can be obtained from _Ea_ (Fig. 4D), from which it can be 31 estimated that PSCs with NiOx/MeO-4PADBC HSL could retained 80% of its initial PCE at 32 room temperature after 7,567 hours operation, without top passivation treatment. 

11 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

1 

9 

10 

11 

12 

13 



2 **Fig. 4 Long-term stability assessment of PSCs under different temperatures. (A to C)** Operational 3 stability of PSCs with HSL of **(A)** MeO-4PADBC **(B)** NiOx, and **(C)** NiOx/MeO-4PADBC at 4 temperature of 25, 65, 85, and 100 ℃, respectively. **(D)** Natural logarithm of slow degradation rate 5 ( _kslow_ ) versus 1/ _kB_ T obtained from biexponential fits, where _kB_ is Boltzmann’s constant and _T_ is aging 6 temperature. The dash line comes from the linear fits to extract the _E_ a from each exponential (left); and 7 natural logarithm of _AF_ versus 1/ _kB_ T. Standard operating condition for _AF_ value calculation refers to 1- 8 sun illumination at 25 ℃ (right). 

### **Conclusions** 

14 

15 

16 

17 

18 

19 

We have demonstrated an efficient and stabilized HSL with greatly improved thermal stability for high efficiency SAM-containing inverted p-i-n PSCs. Rational molecular structure design of MeO-4PADBC and in-depth analysis revealed that optimal dipole moment and favorable contact with perovskite are the keys for ideal energy alignment and fast hole extraction to improve the device efficiency and stability. Moreover, the anchoring of MeO-4PADBC SAM molecules on the NiOx film can form a stronger tridentate bond with NiOx, which effectively reduces the voltage loss and further maintains a strong fixation effect under thermal stress. <mark>Our study provides theoretical guidance for the design of efficient and stable HSL and paves the path for facile access to commercially available inverted p-i-n PSCs.</mark> 

20 

21 

## **Reference and notes** 

- 22 1. Q. Jiang _et al._ , _Nature_ **611** , 278-283 (2022). 

   2. Q. Tan _et al._ , _Nature_ , https://doi.org/10.1038/s41586-023-06207-0 (2023). 

23 2. Q. Tan _et al._ , _Nature_ 24 3. S. Zhang _et al._ , _Science_ **380** , 404-409 (2023). 25 4. X. Zheng _et al._ , _Nat. Energy_ **8** , 462-472 (2023). 26 5. H. Chen _et al._ , _Nature_ **613** , 676-681 (2023). 

3. S. Zhang _et al._ , _Science_ **380** , 404-409 (2023). 

4. X. Zheng _et al._ , _Nat. Energy_ **8** , 462-472 (2023). 

12 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

- 1 6. X. Y. Chin _et al._ , _Science_ **381** , 59-63 (2023). 

- 2 7. S. Mariotti _et al._ , _Science_ **381** , 63-69 (2023). 3 8. K. O. Brinkmann _et al._ , _Nature_ **604** , 280-286 (2022). 

- 4 9. R. He _et al._ , _Nature_ **618** , 80-86 (2023). 

- 5 10. A. Al-Ashouri _et al._ , _Energy Environ. Sci._ **12** , 3356-3369 (2019). 

- 6 11. A. Al-Ashouri _et al._ , _Science_ **370** , 1300-1309 (2020). 

- 7 12. I. Levine _et al._ , _Joule_ **5** , 2915-2933 (2021). 

- 8 13. F. H. Isikgor _et al._ , _Nat. Rev. Mater._ **8** , 89-108 (2022). 

- 9 14. C. M. Crudden _et al._ , _Nat. Chem._ **6** , 409-414 (2014). 

- 10 15. L. Srisombat, A. C. Jamison, T. R. Lee, _Colloids and Surfaces A: Physicochem. Eng._ 11 _Aspects_ **390** , 1-19 (2011). 12 16. H. Chen _et al._ , _Nat. Photon._ **16** , 352-358 (2022). 

- 13 17. X. Li _et al._ , _Science_ **375** , 434-437 (2022). 14 18. Z. Li _et al._ , _Science_ **376** , 416-420 (2022). 15 19. M. V. Khenkin _et al._ , _Nat. Energy_ **5** , 35-49 (2020). 16 20. S. M. Park _et al._ , _Science_ **381** , 209-215 (2023). 17 21. G. Li _et al._ , _Science_ **379** , 399-403 (2023). 

- 18 22. G. Mani _et al._ , _Langmuir_ **24** , 6774-6784 (2008). 

- 19 23. P. Thissen, M. Valtiner, G. Grundmeier, _Langmuir_ **26** , 156-164 (2010). 

- 20 24. E. Delamarche, B. Michel, H. Kang, C. Gerber, _Langmuir_ **10** , 4103-4108 (1994). 

- 21 25. X. Wan _et al._ , _J. Phys. Chem. C_ **124** , 2531-2542 (2020). 

- 22 26. L. Li _et al._ , _Nat. Energy_ **7** , 708-717 (2022). 

- 23 27. W. Jiang _et al._ , _Angew. Chem. Int. Ed._ **61** , e202213560 (2022). 

- 24 28. H. J. Yoon _et al._ , _Angew. Chem. Int. Ed._ **51** , 4658-4661 (2012). 

- 25 29. J. Sun _et al._ , _Solar RRL_ **5** , 2100663 (2021). 26 30. E. Yalcin _et al._ , _Energy Environ. Sci._ **12** , 230-237 (2019). 27 31. R. Guo _et al._ , _Adv. Funct. Mater._ **33** , 2211955 (2023). 28 32. W. Wang _et al._ , _Adv. Energy Mater._ **13** , 2300694 (2023). 29 33. M. Li _et al._ , _Nat. Commun._ **14** , 573 (2023). 

- 30 34. H. Zhang, C. Zhao, J. Yao, W. C. H. Choy, _Angew Chem Int Ed_ **62** , e202219307 (2023). 31 35. S. Y. Kim, S. J. Cho, S. E. Byeon, X. He, H. J. Yoon, _Adv. Energy Mater._ **10** , 2002606 32 (2020). 

- 33 36. I. Lange _et al._ , _Adv. Funct. Mater._ **24** , 7014-7024 (2014). 34 37. D. Di Girolamo _et al._ , _Chem. Sci._ **11** , 7746-7759 (2020). 35 38. F. Ma _et al._ , _J. Energy Chem._ **52** , 393-411 (2021). 36 39. Q. Lin, A. Armin, R. C. R. Nagiri, P. L. Burn, P. Meredith, _Nat. Photon._ **9** , 106-112 37 (2015). 38 40. J. Wang _et al._ , _Nat. Commun._ **11** , 177 (2020). 39 41. M. Stolterfoht _et al._ , _Adv. Mater._ **32** , 2000080 (2020). 40 42. M. Stolterfoht _et al._ , _Nat. Energy_ **3** , 847-854 (2018). 41 43. N. Phung _et al._ , _ACS Appl. Mater. Interfaces_ **14** , 2166-2176 (2022). 42 44. D. Koushik _et al._ , _J. Mater. Chem. C_ **7** , 12532-12543 (2019). 43 45. C. J. Flynn _et al._ , _ACS Appl. Mater. Interfaces_ **8** , 4754-4761 (2016). 

- 44 46. R. Chen _et al._ , _Nat. Energy_ , https://doi.org/10.1038/s41560-023-01288-7 (2023). 45 47. X. Zhao _et al._ , _Science_ **377** , 307-310 (2022). 46 48. F. Li _et al._ , _Nat. Photon._ **17** , 478-484 (2023). 

- 47 49. W. Peng _et al._ , _Science_ **379** , 683-690 (2023). 48 50. R. Azmi _et al._ , _Science_ **376** , 73-77 (2022). 

- 49 51. C. Li _et al._ , _Science_ **379** , 690-694 (2023). 50 52. C. Fei _et al._ , _Science_ **380** , 823-829 (2023). 

13 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

- 1 53. S. Chen, X. Xiao, H. Gu, J. Huang, _Sci. Adv._ **7** , eabe8130 (2021). 

- 2 54. X. Zheng _et al._ , _Nat. Energy_ **5** , 131-140 (2020). 

- 3 55. S. Yang _et al._ , _Science_ **365** , 473-478 (2019). 

- 4 56. A. Sakakura, K. Suzuki, K. Ishihara, _Adv. Synth. Catal._ **348** , 2457-2465 (2006). 

- 5 57. C. Maeda, T. Todaka, T. Ema, _Org. Lett._ **17** , 3090-3093 (2015). 

- 6 58. M. A. Green, _Sol. Cells_ **7** , 337-340 (1982). 

- 7 59. W. Shockley, H. J. Queisser, _J. Appl. Phys._ **32** , 510-519 (2004). 

- 8 60. P. Caprioglio _et al._ , _Adv. Energy Mater._ **9** , 1901631 (2019). 

- 9 61. Z. Zhang, H. Wang, T. J. Jacobsson, J. Luo, _Nat. Commun._ **13** , 7639 (2022). 

- 10 62. T. D. Siegler _et al._ , _J. Am. Chem. Soc._ **144** , 5552-5561 (2022). 

- 11 63. C. Eames _et al._ , _Nat. Commun._ **6** , 7497 (2015). 

- 12 64. O. Haillant, D. Dumbleton, A. Zielnik, _Sol. Energy Mater Sol. Cells_ **95** , 1889-1895 

- 13 

   - (2011). 

- 14 65. J. Kettle _et al._ , _Sol. Energy Mater Sol. Cells_ **167** , 53-59 (2017). 

- 15 66. S. Züfle, R. Hansson, E. A. Katz, E. Moons, _Sol. Energy_ **183** , 234-239 (2019). 

- 16 67. Q. Burlingame _et al._ , _Nature_ **573** , 394-397 (2019). 17 

14 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

## 1 **Acknowledgments** 

- 2 **Funding** : The work was supported by Innovation and Technology Fund (GHP/100/20SZ, 3 GHP/102/20GD, MRP/040/21X), the ECS grant (21301319) and GRF grant (11306521) from 4 the Research Grants Council of Hong Kong, Green Tech Fund (GTF202020164), the Science 5 Technology and Innovation Committee of Shenzhen Municipality 6 (SGDX20210823104002015, JCYJ20220818101018038). Z-A. L. also thanks the financial 7 supports from National Natural Science Foundation of China (No. 21975085) and Excellent 8 Youth Foundation of Hubei Scientific Committee (2021CFA065). This work was authored in 9 part by the National Renewable Energy Laboratory, operated by Alliance for Sustainable 

- 10 Energy, LLC, for the U.S. Department of Energy (DOE) under Contract DE-AC3611 08GO28308. The views expressed in the article do not necessarily represent the views of the 12 DOE or the U.S. Government. **Author contributions:** Z.L., X.S., X.Z., and B.L. contributed 13 equally to this work. Z.Z. conceived the ideas and designed the project with Z-A.L., J.M.L, 14 X.Z. Z.Z directed and supervised the research. Z.L. fabricated the devices, conducted the 15 characterization, and analyzed the data. Z-A.L. directed X.S. to design and synthesize the hole16 selective molecule. B.L. and D.G. also contributed to the device fabrication, characterization, 17 and data analyses. S.Z. conducted the DFT calculations. S.L. and J.Q. also help to fabricate the 18 devices. Z.L., X.Z., B.L., Z-A.L., J.M.L. and Z.Z. drafted, revised, and finalized the manuscript. 19 All the authors revised the manuscript. **Competing interests** : Authors declare that they have 20 no competing interests. The application of patent has been submitted. **Data and materials** 21 **availability:** All data needed to evaluate the conclusions in the paper are present in the paper 22 or the Supplementary Materials. 

- 23 

- 24 **SUPPLEMENTARY MATERIALS** 

25 

26 

27 

28 

Materials and Methods 

Supplementary Text Figs. S1-S42 

Tables S1-S5 

- 29 References (1-67) 

- 30 

15 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

