# Degradation pathways in perovskite solar cells and how to meet international standards

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Communications Materials |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 200 |
| 作者 | Deyi Zhang, Dai-Yu Li, Yue Hu, An-Yi Mei, Hong-Wei Han |
| DOI | 10.1038/s43246-022-00281-z |
| 源文件 | 032_Zhang_2022_Degradation-pathways-in-perovskite-solar-cells-a.pdf |

---


# REVIEW ARTICLE 



> https://doi.org/10.1038/s43246-022-00281-z **OPEN** 

Degradation pathways in perovskite solar cells and how to meet international standards Deyi Zhang 1, Daiyu Li1, Yue Hu1, Anyi Mei1 & Hongwei Han 1✉ 

Commercialization is widely believed to be achievable for metal halide perovskite solar cells with high efficiency and low fabrication cost. However, stability remains a key obstacle for them to compete with established photovoltaic technologies. The photovoltaic community relies on the International Electrotechnical Commission (IEC) standard for the minimum stability assessment for any commercialized solar cell. In this review, we summarize the main degradation mechanisms of perovskite solar cells and key results for achieving sufficient stability to meet IEC standards. We also summarize limitations for evaluating solar cell stability and commercialization potential within the framework of the current IEC standard, and discuss the importance of outdoor testing. 

he exploitation of the solar energy, most typically the photovoltaic (PV) application, is a pivotal way to realize carbon neutrality<sup>1</sup> . PV installation has been growing, and is Texpected to reach 4500 GW globally by 2050<sup>2,3</sup> . Present commercial PV production is dominated by crystalline silicon (c-Si) solar cells and significant progress has been made<sup>4</sup> . To make photovoltaics the most competitive energy choice for power generation, researchers are encouraged to explore alternative PV technologies with better cost performance. 

Among emerging PV materials, metal halide perovskites have aroused enormous research interest owing to their excellent optical and electrical properties. The perovskite consists of the monovalent cation A (such as methylammonium (MA<sup>+</sup> ), formamidinium (FA<sup>+</sup> ) or Cs<sup>+</sup> ), the divalent metal cation B (such as Pb<sup>+</sup> or Sn<sup>+</sup> ) and the monovalent anion X (such as I<sup>−</sup> , Br<sup>−</sup> or Cl<sup>−</sup> ) to form an ABX3 formula. Recently, perovskite solar cells (PSCs) have achieved extraordinary progress in reaching high record power conversion efficiency (PCE) of 25.7%<sup>5</sup> for single-junction ones, 28.0% for perovskite/perovskite tandem ones and 29.8% for perovskite/silicon tandem ones<sup>6</sup> . Moreover, the fabrication cost of PSCs has been estimated potentially to be half as low as that of c-Si solar cells<sup>7</sup> . These attractive achievements encourage the initial attempts of evolving PSCs from research items into commercial products<sup>8–12</sup> . 

Besides the high PCE, high stability is another ticket to the PV market since the levelized cost of energy for PV power generation is comprehensively determined by the PCE, the material and fabrication cost, and the lifetime of the solar panels. A PV product is expected to be stable against diverse operational environments under global application scenarios, especially under harsh conditions like extremely high/low temperatures and light soaking. Some stability tests with intentionally harsh conditions to accelerate the module aging are established to extrapolate the potential long-term operational performance of solar modules. Among them, the International Electrotechnical Commission (IEC) series tests are the most widespread. The details of test conditions and passing requirements are gathered to be the IEC 61215 standard. Figure 1 and Table 1 show the simplified flowchart and protocols of module stability tests based on IEC 61215<sup>13,14</sup> . The test results are used to primarily judge the feasibility of the production. Overviewing from the literature, we can find that PSCs have the ability to pass parts of IEC 61215<sup>15,16</sup> , while the following problems still exist: (1) The test conditions are not strictly in accordance with 

> 1 Michael Grätzel Center for Mesoscopic Solar Cells, Wuhan National Laboratory for Optoelectronics, Key Laboratory of Materials Chemistry for Energy Conversion and Storage of Ministry of Education, Huazhong University of Science and Technology, 430074 Wuhan, Hubei, P. R. China.<sup>✉</sup> email: Hongwei. Han@mail.hust.edu.cn 

1 

COMMUNICATIONS MATERIALS | (2022) 3:58 | https://doi.org/10.1038/s43246-022-00281-z | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00281-z 



Fig. 1 Full test flow for design qualification and type approval of PV modules<sup>13,14</sup> . The tests that have already been reported for PSCs are highlighted in orange. STC, standard test condition; NMOT, nominal module operating temperature. 

the standard. For example, testing devices in N2 or other innert atomosphere instead of air. (2) Passing single test instead of a test sequence. For example, Fig. 1 shows that ultraviolet (UV) precondition test, thermal cycling test and humidity freeze test are carried out in sequence, which means the requirements for device stability are much higher than those for passing a single test. (3) The comprehensive degradation mechanisms of PSCs remain to be further clarified and specific standards for evaluating the stability of perovskite devices should be formulated as suggested by the consensus of the perovskite community<sup>17</sup> . 

From Fig. 1, we can find that light, heat, moisture and reverse bias are the main threats for solar cells to face under outdoor working conditions in addition to the mechanical stress. In this review, we retrospected the main degradation mechanisms of PSCs under those stimulations and summarized the improvement strategies with some remarkable work. All components of PSCs would bring stability issues and careful design of each layer is essential for stable PSCs. In addition to the materials themselves, related interfaces also contribute a lot to the stability. As for the 

halide perovskite, attention should also be paid to the grain boundaries (GBs). We proposed that specific standards for PSCs can assist in promoting research in the field. Accelerated aging tests cannot cover all the circumstances that a PV product would encounter during operation. Outdoor demonstration is a good opportunity to gain deeper understanding of operational stability. Success in it is quite meaningful to boost the confidence of investors and customers. 

## Stability of PSCs 

Temperature and humidity stability. Solar cells in practical applications are supposed to cope with varied weather conditions, of which temperature and humidity are the crucial factors. In the IEC standard, three stability tests of thermal cycling, damp heat and humidity freeze correlate closely to the two factors. As seen in Fig. 1 and Table 1, requirements for these three tests resemble each other. The stability issues against temperature and humidity can be overviewed from the perovskite material, the functional layers, the interfaces and the back electrode. 

2 

COMMUNICATIONS MATERIALS | (2022) 3:58 | https://doi.org/10.1038/s43246-022-00281-z | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00281-z 

Table 1 Summary of important tests of the IEC 61215 for PSCs<sup>13</sup> . 

|Test|Conditions|
|---|---|
|Measurement of temperature coefficients<br>Measurement of nominal module operating<br>temperature|Temperature coefficients for the current (α), voltage (β) and peak power (δ).<br>Module operating near maximum power point<br>Total solar irradiance: 800 W/m<sup>2</sup><br>Ambient temperature: 20 °C<br>Wind speed: 1 m/s|
|Performance at low irradiance|Cell temperature: 25 °C<br>Irradiance: 200 W/m<sup>2 </sup>with IEC 60904-3 reference solar spectral distribution|
|Light soaking test|Cell temperature: 50 ± 10 °C<br>800–1000 W/m<sup>2 </sup>with IEC 60904-9 reference solar spectral distribution or a class CCC or better<br>simulator|
||At maximum power point tracking|
|UV precondition test|15 kWh/m<sup>2 </sup>total UV irradiation in the wavelength range from 280 nm to 400 nm with 3% to 10%<br>UV irradiance in the wavelength range from 280 nm to 320 nm at 60 ± 5 °C|
|Thermal cycling test|50 or 200 cycles from −40 °C to 85 °C with current as per technology specific part up to 80 °C|
|Damp heat test|1000 h at +85 °C, 85% RH|
|Humidity freeze test|10 cycles from 85 °C, 85% RH to −40 °C with circuitry continuity monitoring|
|Hot-spot endurance test|Exposure to 1000 W/m<sup>2 </sup>irradiance in worst-case hot-spot condition|
|Outdoor exposure test|60 kWh/m<sup>2</sup>|
|Robustness of terminations|Test of junction box retention and cord anchorage|
|Wet leakage current test|Test voltage increase at a rate not exceeding 500 V/s to 500 V or the maximum system voltage for<br>the module, whichever is greater. Maintain the voltage at the level for 1 min.|
|Static mechanical load test|Three cycles of uniform load specified by the manufacturer, applied for 1 h to front and back surfaces<br>in turn. Minimum test load: 2400 Pa|
|Hail test|25 mm diameter ice ball at 23.0 m/s, directed at 11 impact locations|
|Bypass diode thermal test|Bypass diode thermal test:<br>1 h at ISC and 75 °C<br>1 h at 1.25 times ISC and 75 °C<br>Bypass diode functionality test|
||At 25 °C perform voltage and current measurements|



Tests are performed in sequence as shown in Fig. 1. 

Chemicals including water and oxygen molecules from the ambient condition could react with halide perovsktite and speed up the decomposition (Fig. 2a)<sup>18</sup> . MA<sup>+</sup> and H2O form strong hydrogen bond, weakening the original bond between MA<sup>+</sup> and the Pb-I octahedral. The deprotonation of the organic cation is accelerated and the proton could transfer to I<sup>−</sup> via H2O, producing volatile species of CH3NH2 and HI, while the reductive I<sup>−</sup> could be oxidized by the oxygen. When the ambient chemicals are well blocked outside, they will not damage the perovskite. Organic-inorganic hybrid halide perovskites including MA-based and FA-based ones also face the thermal stability issue<sup>19</sup> . From the thermogravimetric analysis, hybrid halide perovskites exhibited a high decomposition temperature over 250 °C (Fig. 2b)<sup>20,21</sup> . This temperature is much higher than the required 85 °C for terrestrial photovoltaic panels. However, decomposition of those organic-inorganic halide perovskites at 85 °C due to the volatilization and loss of various organic species in the open space was reported<sup>19</sup> . The loss of organic salts from hybrid perovskites could happen in different pathways which are determined by the components in perovskites and heating temperatures (Fig. 2c). The heat-induced degradation products of halide perovskite involve various gasses. As described, heat and moisture-induced decomposition pathways involve the escape of gaseous species from the device and the entry of species into the device. When the outgassing process is suppressed, the decomposition reaction tends to reach equilibrium before significant damage occurs to perovskites. With this aspect, the less volatile FA<sup>+</sup> and inorganic Cs<sup>+</sup> are also usually used as alternatives for MA<sup>+</sup> . However, non-photoactive yellow δ-phase of FAPbI3 and CsPbI3 rather than the black phase is thermodynamically stable at room temperature. Synthesis of low dimensional perovskite materials, compositional engineering and addition of external 

additives are three main approaches to improving the phase stability of FAPbI3 and CsPbI3 reported in the literature<sup>22</sup> . The stability of perovskite phase is the very premise of the long-term stability of PSCs. 

Encapsulation is effective for preventing those unwanted ingress and escape actions as all solar cells need to be well encapsulated before their practical applications. The encapsulation materials and methods are of vital importance to gain the satisfactory lifetime. A hermetic encapsulation scheme creates a pressure-tight environment and prevents the escape of gaseous decomposition products, retarding the degradation of PSCs (Fig. 2d)<sup>23</sup> . A suitable encapsulant should have low water vapor transmission rate to minimize the harm of moisture ingress. Thermal expansion coefficient (TEC) for the encapsulant should match that of the substrate to keep moisture blocking throughout the stability test. Otherwise, invading moisture freezes to cause further breaking of the encapsulation during the humidity freeze test. Other requirements for encapsulation materials include high adhesion, suitable processing temperature, chemical inertness, low oxygen transmission rate, good mechanical strength, etc<sup>24</sup> . PSCs that pass the IEC damp heat, humidity freeze or thermal cycling tests are dominantly based on a glass-to-glass encapsulation scheme, where PSCs are sandwiched between two glass sheets that are cohesive with the polymer encapsulant (Fig. 2d)<sup>23</sup> . With the encapsulation of glass/Ethylene vinyl acetate (EVA) or polyolefin (POE)/glass and the butyl rubber edge seal, PSCs achieved ~108% of its initial PCE after 1000 hours’ aging at 85 °C/85% RH and 200 thermal cycles<sup>25,26</sup> . Encapsulating perovskite solar cells with a piece of back cover glass and filling the space between the substrate and the back cover with the polymer of POE or polyisobutylene made MA-containing PSCs survive more than 1800 hours of damp heat test and 75 

3 

COMMUNICATIONS MATERIALS | (2022) 3:58 | https://doi.org/10.1038/s43246-022-00281-z | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00281-z 



Fig. 2 Thermal stability of halide perovskite components. a MAPbI3 reversibly forms monohydrate or dihydrate with moisture. Insertion of H2O weakens the bond between MA<sup>+</sup> and Pb-I octahedral, speeding up thermal decomposition. Adapted with the permission from ref.<sup>18</sup> Copyright © 2015, American Chemical Society. b Thermogravimetric curves of MAPbI3 and FAPbI3, both of which show high decomposition threshold over 250 °C. Adapted with the permission from ref.<sup>21</sup> Copyright © 2019, American Chemical Society c Released gas species of several organic salts detected by chromatography–mass spectrometry upon heating at different temperatures. Thermal decomposition of perovskites could occur at the relatively low temperature of 85 °C. d Blanket and edge-sealing encapsulation for PSCs. Suitable blanket encapsulation provides a pressure-tight environment to suppress the outgassing process. c, d Adapted with the permission from ref.<sup>23</sup> Copyright © 2020, The American Association for the Advancement of Science. 

cycles of humidity freeze test, exceeding the requirement of IEC61215:2016 standard<sup>23</sup> . Inorganic compounds such as the indium-doped tin oxide (ITO) or MgF2 were also used to form the pressure-tight coverage and inhibit the thermal decomposition of halide perovskites in a similar manner. In addition, the escape of MAI mainly starts with the GBs and surfaces of halide perovskite films. Strengthening the GBs also benefit the thermal stability of halide perovskites. Preventing the temperature increase of PSCs under working conditions is also helpful. 

Heat also challenges perovskite-related interfaces. Under thermal stress, the mismatch of TEC between the perovskite and the substrate results in strain in the perovskite film. The strain can reach as high as 50 MPa and become a driving force of film deformation and ion migration at the interface<sup>27</sup> . The mismatched TEC also brings about delamination of the layered structure (Fig. 3a)<sup>28,29</sup> , and fracture could even occur due to the low fracture energy of PSCs during the thermal cycling test and the humidity freeze test<sup>30</sup> . The strain can be alleviated with compositional engineering, low-temperature annealing, high TEC substrate and transporting layer selection<sup>27</sup> . An encapsulant with low elastic modulus and high mechanical strength enables mechanically stable PSC<sup>31</sup> . Strain is not always harmful since it can also be a tool to enhance the phase stability of FA or Cs perovskite. Masi et. al. proposed to stabilize FAPbI3 perovskite 

with embedded colloidal PbS quantum dots (QDs)<sup>32</sup> . PbS acted as a template, heading the growth of the perovskite due to its similar lattice parameter to FAPbI3. This template-grown FAPbI3 strained in both directions parallel to and perpendicular to the PbS-FAPbI3 interface, facilitating a stabilized black phase. Strain may be altered and relieved under thermal stress, inducing the loss of the stabilization effect. PbS provided deeper stabilization mechanisms of surface energies and chemical bonds beside strain. The PbS-FAPbI3 interface reduced the thermodynamic preference for the yellow phase by creating stronger chemical bonds with the black one. The increase in surface energies was small for the black phase but large for the yellow one, which selectively favored the black phase over the yellow one. For the counter interface, ions such as I<sup>−</sup> from halide perovskite could diffuse across the interface into the adjacent charge transport layer (CTL) and even to the back electrode and react with it. Toughening the surface of the perovskite film or preparing an ion diffusion barrier layer between the perovskite layer and the adjacent CTL makes sense for solving this concern<sup>33,34</sup> . 

Organic HTMs have long been recognized as a contributor to the instability of PSCs. For the most widely used hole transport layer (HTL) of 2,2',7,7'-Tetrakis[N,N-di(4-methoxyphenyl) amino]-9,9'-spirobifluorene (Spiro-OMeTAD), it would undergo morphology change via outgassing or crystallization under heat, 

4 

COMMUNICATIONS MATERIALS | (2022) 3:58 | https://doi.org/10.1038/s43246-022-00281-z | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00281-z 



Fig. 3 Thermal stability concerns other than perovskite components. a. Cross-section SEM images showing delamination at the perovskite and substrate interface aged by strain. The strain can be produced under thermal stress due to the mismatched TEC. Adapted from ref.<sup>29</sup> b Formation of voids in t-BP/LiTFSI co-doped Spiro-OMeTAD under thermal stress. Adapted with the permission from ref.<sup>35</sup> Copyright © 2017, American Chemical Society c Time-offlight secondary-ion mass spectrometry of multiple ions in the fresh (dashed lines) and the 85 °C–1000 h-aged (solid lines) PSCs. Li<sup>+</sup> from Spiro-OMeTAD could diffuse into the perovskite layer upon heating. Adapted with the permission from ref.<sup>39</sup> Copyright © 2021 Wiley-VCH GmbH d Reconstructed elemental 3D maps for the ions in 70 °C-aged devices. Au atoms could diffuse in PSCs. Adapted with the permission from ref.<sup>43</sup> Copyright © 2016, American Chemical Society e A compact-Bi layer beneath the metal electrode to block the diffusion of both the metal electrode and the external factors. Adapted from ref.<sup>44</sup> . 

leading to the formation of voids and failure of separation (Fig. 3b)<sup>35,36</sup> . Additionally, migrated I<sup>−</sup> and gaseous iodine product from perovskite deteriorate its hole transport ability<sup>37,38</sup> . The commonly used Li-TFSI dopant could attract water due to its hygroscopic nature, which in turn causes the moisture-induced decomposition of the perovskite. Li<sup>+</sup> could also migrate in the device and cause performance decay (Fig. 3c)<sup>39</sup> . Structural modification of existing hole transport materials (HTMs), alternative dopants and novel dopant-free HTMs are attempted to solve the HTL-induced instability, which have been summarized in previous review articles<sup>40,41</sup> . HTL-free device configurations are also good choice for solving this stability concern<sup>42</sup> . 

Atoms from the metal back electrode such as composed of Au or other metals could diffuse across the HTL into the perovskite layer in PSCs at elevated temperatures under working conditions (Fig. 3d)<sup>43</sup> . The diffused metal atoms caused irreversible loss of VOC, FF, and JSC of the aged devices. Inserting an diffusion barrier layer such as composed of less-movable Cr<sup>43</sup> or Bi<sup>44</sup> , amorphous (a)-TiO2<sup>45</sup> , graphene and derivatives<sup>46,47</sup> , ITO<sup>48</sup> or MoS2<sup>49</sup> underneath the metal electrode suppressed the detrimental effect of the metal electrode on device stability (Fig. 3e). Replacing those metal electrodes with chemically inert and non-movable back electrodes also works<sup>50</sup> . Conductive compounds including metal 

oxides such as ITO could work as stable back electrodes for PSCs<sup>51–54</sup> . Carbon materials including graphite, carbon black, carbon nanotubes and graphene are very promising electrode materials for PSCs<sup>55–58</sup> . 

Light soaking stability. Light soaking stability is the most basic and most important indicator for solar cells. Currently, as the stability of perovskite has been gradually established, many reports used light soaking aging test for judging PSCs’ stability<sup>59–62</sup> , and some test protocols met the IEC standard<sup>63,64</sup> . To pass the light soaking aging test, it is necessary to understand the mechanisms of photo-induced degradation. Light soaking would cause the degradation of halide perovskites with a slow and complicated process, which has not been comprehensively revealed and is generally affected by the combination of light and light-induced heat and electric field in PSCs. The challenge brought by light soaking to PSCs is discussed as follows. 

Different from ambient chemicals, light soaking is the basic requirement for PSCs to operate and cannot be sheltered. Therefore, halide perovskites must face the challenge of light soaking when all the other components in PSCs are made stable. Halide salts including PbI2, PbBr2, and PbCl2 are light sensitive and undergo photodissociation at elevated temperatures since 

5 

COMMUNICATIONS MATERIALS | (2022) 3:58 | https://doi.org/10.1038/s43246-022-00281-z | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00281-z 



Fig. 4 The challenge brought by light soaking to PSCs. a Possible pathways for light-induced ion migration, including Schottky defects, Frenkel defects, open space and wrong bonds at GBs, lattice distortions, nonuniform strain, and soften lattice. Adapted with the permission from ref.<sup>65</sup> Copyright © 2016, American Chemical Society b Schematic of the generation of iodide interstitial defects (Ii) in the PSC under illumination. The orange and green lines indicate the energetic and spatial distribution of degradation-generated Ii<sup>−</sup> and Ii<sup>+</sup> , respectively. The solid red and blue balls represent photogenerated holes and electrons, respectively. Photogenerated holes can be readily captured by Ii<sup>−</sup> due to its short trapping time. Adapted with the permission from ref.<sup>66</sup> Copyright © 2021, The Author(s), under exclusive licence to Springer Nature Limited c Schematic diagram of light-soaking upon films with different strains and photographs of the films after 500 h illumination. Adapted from ref.<sup>67</sup> . 

photogenerated holes would be captured by halide ions at the surface or boundaries to form neutral iodine while electrons would be captured by lead cations to form neutral lead (Fig. 4b)<sup>66,68</sup> . Therefore, excess lead salts such as PbI2 in the perovskite films for PSCs would cause light soaking stability issue<sup>69–72</sup> . 

Halide perovskites themselves are not so sensitive as lead halides since the photodissociation is highly correlated with the dynamic behavior of carriers while halide perovskites possess excellent photoluminescence properties and the photogenerated carriers can also be effectively extracted by selective contacts in PSCs. Elevated temperature induced by light soaking affects the carrier dynamics in PSCs. In addition, ions in halide perovskites are migratable and operating conditions affect the migration behavior of those ions. Ions mainly migrate through the point defects, GBs and surface or interfaces (Fig. 4a)<sup>65</sup> . Expanded or distorted lattice due to thermal expansion also promotes the migration of ions such as I<sup>−</sup> into the interstitials. The elevated temperature and light irradiation also promote the migration ability of the loosely bound ions such as MA<sup>+</sup> and I<sup>−</sup> by reducing the ion migration activation energy (Ea)<sup>65</sup> . Ion migration could be driven by residual strain (Fig. 4c)<sup>67</sup> and electric field caused by the accumulated charges in the device. 

On one hand, migrated ions led to the phase segregation of the mixed halide and mixed cation perovskites. MAPbI(BrxI1-x)3 segregated into two I-rich and Br-rich crystalline domains under light soaking<sup>73,74</sup> . A photoinactive and current-blocking Cs-rich phase was reported to form in FA0.9Cs0.1PbI3 under illumination<sup>75</sup> . The illumination-induced phase segregation could be suppressed by proper composition design. On the other hand, the migrated ions could retard the transport of photogenerated carriers and lead to accumulated charges. The accumulated charges could then interact with the migrated ions to form defects such as I<sup>0</sup> and Pb<sup>0</sup> , leading to gradual decay of PSCs during the long-term applications<sup>34</sup> . In fact, even the migrated ions do not interact with photogenerated carriers, it is still challenging for 

them to return to their original sites completely. Potential strategies for overcoming the above stability concerns include increasing Ea, removing driving force and blocking migration pathyways for ion migration. 

Maintaining the device at a low temperature could increase Ea and prolong the lifetime of PSCs<sup>76</sup> . Immobilizing ions at GBs by introducing selected additives also contributed to the operational stability enhancement of PSCs<sup>77</sup> . Fluorine anions with enhanced electronegativity for a strong hydrogen bond with organic cations and a strong ionic bond with lead cations in halide perovskites suppressed ion migration at GBs and improved the device operational stability (Fig. 5a)<sup>78</sup> . In addition to common halogen ions, some pseudohalogen ions, such as SCN<sup>−</sup> , BF4<sup>−</sup> and PF6<sup>−</sup> , are expected to have a similar effect on suppressing ion migration<sup>79–81</sup> . Besides halogen ions, FA<sup>+</sup> and Cs<sup>+</sup> are more capable to suppress cation migration. Cs<sup>+</sup> could increase the activation barrier for halide migration by inducing lattice compression<sup>82</sup> while lager-sized cations such as acetamidinium, azetidinium and guanidinium could slow ion migration by the steric hindering effect<sup>83–86</sup> . Potassium was also reported to fill halide vacancies and immobilize halide ions at GBs of halide perovskites<sup>87,88</sup> . Various salt additives were applied to mitigate ion migration on the perovskite surface and grain boundarie for enhanced stability. The introduction of 5-ammonium valeric acid hydroiodide (5-AVAI) helped printable hole-conductor-free mesoscopic PSCs (p-MPSCs) with carbon electrodes pass the key IEC61215:2016 test and the fabricated device operated stably for >9000 h under light soaking test without obvious decay<sup>63</sup> . The ionic liquid additives including 1-butyl-3-methylimidazolium (BMIMBF4) and 1-butyl-1-methylpiperidinium tetrafluoroborate ([BMP]<sup>+</sup> [BF4]<sup>−</sup> ) suppressed ion migration and formation of I2 at the GBs (Fig. 5b)<sup>89–91</sup> . The introduction of [BMP]<sup>+</sup> [BF4]<sup>−</sup> dramatically improved the operational stability of the inverted p-i-n PSCs under full sunlight at 85 °C and the T95 lifetime (time until the PCE drops to 95% of its initial value) for the device was estimated to be 1200 hours. Meanwhile, preparing perovskite 

6 

COMMUNICATIONS MATERIALS | (2022) 3:58 | https://doi.org/10.1038/s43246-022-00281-z | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00281-z 



Fig. 5 Methods for inhibiting the ion migration in PSCs. a Incorporation of NaF into the perovskite units to form strong bonds with both cations and anions to immobilize ions at GBs. Adapted with the permission from ref.<sup>78</sup> Copyright © 2019, The Author(s), under exclusive licence to Springer Nature Limited b Photoluminescence images of control film and BMIMBF4-containing film under a constant applied bias (10 V). The bright areas represent photoluminescence emission from the perovskite films. The ionic liquid additive BMIMBF4 exhibits effectiveness to suppress the ion migration in halide perovskite. Adapted with the permission from ref.<sup>90</sup> Copyright © 2019, The Author(s), under exclusive licence to Springer Nature Limited. 

films with reduced GBs could reduce migration pathways and deterioration space, contributing to solving related stability issues. 

Trapping and insufficient charge extraction led to accumulation of photogenerated carriers. Preparing perovskite films with reduced deep trap states and passivating those trap states via proper additives reduced charge trapping. Slightly excess FAI was reported to compensate iodine vacancies and suppress the generation of defects during long-term operation of PSCs<sup>92</sup> . Charge extraction is determined by the interface contact between perovskite and CTLs, the energy level alignment in the device and the charge extraction ability of CTLs. Substrate-related interface voids could be formed due to the slow volatilization of residual dimethyl sulfoxide (DMSO) solvents at the interface during the preparation of perovskite films. Meanwhile, the interface between the perovskite film and the commonly used substrate is brittle. Under working conditions, stress induced by high and low temperature caused reconstruction, delamination, and formation of voids at the interface due to mismatched TEC and weak interface bonding as discussed in the last section. Voids and delamination prevented the injection of carriers and led to the accumulation of charges and formation of defects at the interface. The deteriorated interface further slowed down charge extraction and accelerated the deterioration. Partially replacing the liquid DMSO solvent with the solid-state additive of carbohydrazide reduced interfacial voids and stabilized the interface (Fig. 6a)<sup>93</sup> . The toughness of the interface can be enhanced by interface modification. 5-AVAI strengthened the TiO2/perovskite interface with its bifunctional groups of ammonium and carboxyl. Iodineterminated self-assembled monolayer (I-SAM) between SnO2 electron transport layer (ETL) and the perovskite layer achieved a 50% increase of adhesion toughness and enhanced the 

mechanical reliability, which suppressed the formation of voids and delamination at the interface under working conditions (Fig. 6b)<sup>94</sup> . A coherent interface layer of FASnClx constructed by residual chloride on the surface of SnO2 colloids was also proposed and realized for the interface modification of PSCs with enhanced device stability<sup>5</sup> . The enhanced contact can also block ion migration pathways at the interface. In addition to the mechanical contact, the energy level and charge extraction ability of the selective contact materials should be carefully designed for sufficient charge extraction. Optimizing the structure of the substrate such as making it porous or arrayed to make the interface bulk contact could also improve the interface-related operational stability. More studies on developing stable and costeffective charge transport materials with suitable lattice or appropriate specific surface energy and stable charge extraction ability to match the perovskite for tougher interface with excellent mechanical and electrical contact is also desired for fabricating stable PSCs. 

When I<sup>0</sup> and Pb<sup>0</sup> are formed in PSCs, converting them back to Pb<sup>2+</sup> and I<sup>−</sup> timely can also strengthen the device stability. A demonstrated method for this is introducing a redox shuttle into the film. A reported shuttle is the Eu<sup>3+</sup> -Eu<sup>2+</sup> pair (Fig. 7a). It was found that although the reaction between I<sup>0</sup> and Pb<sup>0</sup> could happen thermodynamically, a kinetic energy barrier existed in the reaction which made the reaction incomplete. The introduced redox shuttle can effectively transfer electrons in a cyclical manner with the reduction of I<sup>0</sup> by Eu<sup>2+</sup> and the oxidization of Pb<sup>0</sup> by Eu<sup>3+</sup> . As a result, the Pb<sup>0</sup> and I<sup>0</sup> were eliminated and the redox shuttle returned to its original state<sup>95</sup> . When aging perovskite films under 1 sun illumination for more than 1000 h, the Pb<sup>0</sup> /(Pb<sup>0</sup> +Pb<sup>2+</sup> ) ratio in the film with the redox shuttle 

7 

COMMUNICATIONS MATERIALS | (2022) 3:58 | https://doi.org/10.1038/s43246-022-00281-z | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00281-z 



Fig. 6 Stability issues at the interfaces. a Interfacial voids could be formed due to the slow release of residual DMSO. Adapted with the permission from ref.<sup>93</sup> Copyright © 2021, The American Association for the Advancement of Science b I-SAM increased the toughness of perovskite/SnO2 interface and suppressed the deterioration of the interface under long-term operating. Adapted with the permission from ref.<sup>94</sup> Copyright © 2021, The American Association for the Advancement of Science. 

was about 2.5%, while that in the control film was 7.4%. The introduction of Eu<sup>3+</sup> -Eu<sup>2+</sup> made PSCs retain 92% and 89% of the peak PCE under 1-sun continuous illumination or heating at 85 °C for 1500 h. Gd<sup>3+</sup> -Gd<sup>2+</sup> could also work in a similar manner. In addition, the cheap metal element of iron was designed to realize this<sup>96</sup> . Fe<sup>3+</sup> is oxidative while Fe<sup>2+</sup> is reductive. The challenge is Fe<sup>3+</sup> can not only oxidize Pb<sup>0</sup> , but also oxidize I<sup>−</sup> which leads to the formation of I<sup>0</sup> . Ferrocene (Fc) avoids such concern. Fc has been reported to react with I<sup>0</sup> to form FcI, while FcI could react with Pb<sup>0</sup> to form PbI2 and convert back to Fc for improved stability of PSCs (Fig. 7b)<sup>96</sup> . 

Light soaking also interacts with functional layers such as ETL in PSCs and led to instability. UV could lead to the desorption of adsorbed oxygen molecules which passivated oxygen vacancies (OVs) on the surface of metal oxide ETLs (mainly TiO2) while the exposed OVs caused non-radiative recombination at the interface and performance decay of PSCs. UV shelters or down-conversion material could be used to block or convert the UV light to visible light for improved stability<sup>97,98</sup> . Surface modification of metal oxides or introducing an interlayer also suppressed the detrimental effect of those OVs<sup>61,99,100</sup> . Potential electron transport materials that have reduced intrinsic UV activated deep traps such as SnO2 or van der Waals tin oxides of Sn2O3 and Sn3O4 are available choices for stable PSCs<sup>101–107</sup> . SnO2 is the presently popular electron transport material and various surface modification strategies on SnO2 were developed for efficient and stable PSCs<sup>108,109</sup> . 

Typical stability demonstration of PSCs. In Fig. 8, we exhibited typical stability results that were obtained by settling those above- 

mentioned degradation mechanisms. Figure 8a showed a p-i-n inverted planar PSC whose perovskite was incorporated with an ionic solid additive [BMP]<sup>+</sup> [BF4]<sup>−89</sup> . [BMP]<sup>+</sup> [BF4]<sup>−</sup> suppressed deep trap states in the perovskite and enhanced its stability under light soaking at 85 °C. The ability of suppressing deep trap states in perovskite is a key issue for the enhanced stability at 85 °C. The thermally more stable poly(4-butylphenyl-diphenylamine) (polyTPD) rather than Spiro-OMeTAD or NiO was selected to avoid HTL-related stability issues. Additionally, the Au electrode was modified with Cr to avoid the instability caused by the metal electrode. As a result, T95 lifetime of 1200 hours under full sunlight at 85 °C was achieved. The triple-mesoscopic p-MPSC is also a typical device design for inherent structural stability (Fig. 8b)<sup>110</sup> . In p-MPSCs, no additional HTL was used and holes transported in perovskite itself. The hydrophobic, chemically inert, and non-diffusible carbon electrode was adopted to replace the metal electrode. Meanwhile, the MAPbI3 crystal was localized and buried in the thick mesoscopic scaffolds of several micrometers and the interfaces or boundaries were strengthened by 5-AVAI. The decomposition or reconstruction was inhibited, and the irreversible ionic migration was suppressed. The prepared p-MPSCs successfully passed the main items of IEC61215:2016 qualification tests with over 9000-h operational tracking<sup>63</sup> . The n- i-p PSCs also demonstrated very excellent stability by retaining 99% of its peak PCE after 1450 h of continuous operation at 65 °C in N2 (Fig. 8c)<sup>111</sup> . In this work, the ETL was constructed by multilayer stacking of SnO2, [6,6]-phenyl-C61-butyric acid methyl ester (PCBM) and MnSO4. High throughput screening platform was designed to find the stable perovskite compositions 

8 

COMMUNICATIONS MATERIALS | (2022) 3:58 | https://doi.org/10.1038/s43246-022-00281-z | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00281-z 



Fig. 7 The redux shuttles for degenerate the defects in halide perovskite films to prolong the operational lifetime of PSCs. a Mechanism diagram of cyclically elimination of Pb<sup>0</sup> and I<sup>0</sup> defects and regeneration of Eu<sup>3+</sup> -Eu<sup>2+</sup> metal ion pair. Adapted with the permission from ref.<sup>95</sup> Copyright © 2019, The American Association for the Advancement of Science b Sustainable recovery mechanism on comprehensive defects in MAPbI3 perovskite via a two-cyclical 4-step chain-reaction strategy. The red cycle represents redox potentials of Fc/Fc<sup>+</sup> pair transferring charges from I<sup>0</sup> to Pb<sup>0</sup> defects, and blue cycle means intermediated FcPbI3 perovskite fixing MA defect back to MAPbI3. Adapted with the permission from ref.<sup>96</sup> Copyright © 2021 WileyVCH GmbH. 

such as MA0.1Cs0.05FA0.85Pb(I0.95Br0.05)3. A bilayer HTL composed of the stacking of dopant-free polymer of PDCBT (poly[2,2ʹʹʹʹ-bis[[(2-butyloctyl)oxy] carbonyl] [2,2ʹ:5ʹ,2ʹʹ:5ʹʹ,2ʹʹʹquaterthiophene]-5,5ʹʹʹ-diyl])) and acid-doped polymer of the conjugated poly(triarylamine) polymer (PTAA) doped by the stable Lewis acid tris(pentafluorophenyl)borane (BCF) was designed to form stable ohmic contact at elevated temperatures and buffer iodine vapors. In addition, a capping layer of MgF2 was prepared on top of Au electrode to form the close-contact encapsulation. 

Stability of perovskite solar modules (PSMs). Contrasting with the relatively abundant stability demonstrations of PSCs, there has been only a handful of reports on PSMs. This partially indicates the increasing complexity of the stability of PSMs. Fundamentally, the quality and uniformity of all functional layers in PSMs may be inferior to those of PSCs, which are potential threats to the long-term stability. Additionally, PSMs have their unique degradation mechanisms and pathways against PSCs. 

Reverse bias stability. Hot-spot effect due to reverse bias is specifically related to solar modules and has been recognized as the severest damage mode for operational modules<sup>112</sup> . Hot-spot effect is caused by the reverse bias when the cells connected in series or in parallel fail to work synchronously because of either intrinsic fault or extrinsic shading or soiling. Such process mostly correlates with those modules that are regularly shaded by neighboring trees or buildings. In solar panels, those sub-cells or regions which fail to offer as high voltage as the parallel-connected ones or as high current density as the series-connected ones would serve as the load, 

which bears the reverse bias and wastes the electricity. The reverse bias has been reported to cause overheating. Decomposition of perovskites could be triggered then by the voltage and the heat<sup>113</sup> . This overheating may degrade the PSM as well as destroy the encapsulating materials. The reverse bias could also drive the migration of heat-activated mobile ionic species to accumulate at the interface of the perovskite and CTL, mediating a tunneling process of either electrons or holes. With a short duration of the bias, the reverse bias degradation is partially recoverable via redistribution of the migrated ions. When the bias is prolonged or repeated, the degradation gradually turns irreversible, involving the oxidation of I<sup>−</sup> by injected holes<sup>66</sup> . It was reported that placing an interfacial ion blocking layer and decreasing the number of mobile ionic defects could alleviate reverse bias degradation. Installing bypass diodes is adopted in well-established photovoltaic technologies like silicon cells to avoid the reverse bias damage. However, the breakdown voltages for PSCs are reported to be considerably lower, implying lower bias tolerance. This means that more bypass diodes would be needed, raising the fabrication cost. It is significant to identify PSCs with better voltage tolerance. Recently, Bogachuk et. al. represented superior resilience against reverse bias of p- MPSCs, which did not degrade until the applied reverse-bias exceeds −9 V<sup>114</sup> . They fabricated p-MPSMs with 56.8 cm<sup>2</sup> aperture area and subjected them to the hot-spot test with the requirement of IEC 61215–2:2016, no efficiency loss was found, indicating that the PSMs passed the hot-spot accelerated test. This result has again shown unique structural advantages of p-MPSCs for stability, underlining the greatest potential for industrialization. 

Laser scribe issues. The interconnection of sub-cells in a solar module is typically achieved via laser scribe. Three scribes called P1, P2 and P3 are designed to selectively ablate the front electrode, the perovskite layer and CTLs, and the back electrode, respectively. These scribes mainly result in four degradation pathways in PSMs<sup>115</sup> . Firstly, laser could induce light and thermal degradation of the perovskite following the pathways discussed in previous sections. Degradation products like PbI2 will trigger further degradtion of PSMs. Secondly, incomplete removal of the CTLs during scribes creates extra shunt resistance, possibly increasing the risk of potential-induced degradation. Thirdly, P2 scribe leads to the direct contact between the perovskite and the back electrode. Irreversible damage would occur due to the reaction between perovskite and metal. Introducing interlayers or using unreactive back electrode materials are effective solutions, as is clarified above. Lastly, unideal P3 scribe leaves grooves for moisture and oxygen ingress. Encapsulation solves this problem while elaborate encapsulation designs for PSMs are required. 

Figure 9 summarized some reported stability results of PSCs and PSMs according to the IEC light soaking test, UV precondition test, damp heat test and thermal cycling test. The present progresses are very encouraging. In those accelerated aging test, PSCs have exhibited positive results towards industrialization. One remaining challenge is that most test conditions are diverse and not very strict. Such as for the key light soaking stability, the temperature for the test ranged from room temperature to 85 °C. As discussed in previous sections, the light soaking stability of PSCs dramatically relied on the temperature. It seems light soaking stability under higher temperature is more persuasive. Light soaking stability of PSCs at 85 °C is not widely reported at present. In addition, as discussed in the introduction section, some stability results should be collected for cells aged under various conditions in a sequence. Related studies for this have not been well reported. In addition, more studies on modules towards the IEC standard and outdoor demonstrations are also desired in the next stage of PSCs’ development. 

9 

COMMUNICATIONS MATERIALS | (2022) 3:58 | https://doi.org/10.1038/s43246-022-00281-z | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00281-z 



Fig. 8 Typical stability results for dissolving multiple degradation pathways. a A p-i-n inverted planar PSC utilizing the [BMP]<sup>+</sup> [BF4]<sup>−</sup> additive to suppress deep trap states, the thermally stable HTL polyTPD, and Cr-modified Au electrode to achieve excellent stability under full sunlight at 85 °C. Adapted with the permission from ref.<sup>89</sup> Copyright © 2020, The American Association for the Advancement of Science. b The p-MPSCs with the triplemesoscopic structure, no HTL and carbon electrode as an inherently stable structural design. Stability of over 9000-h operational tracking was achieved due to localized effect of mesopores and interface strengthening effect of 5-AVAI. Adapted with the permission from ref.<sup>110</sup> Copyright © 2014, The American Association for the Advancement of Science. Adapted with the permission from ref.<sup>63</sup> Copyright © 2020 Elsevier Inc. c A modified n-i-p PSC structure with multiple layers of ETL, inherently stable perovskite composition, stable bilayered HTL, and MgF2 capping layer atop Au enables long-term operational stability at 65 °C under metal-halide lamps in N2. Adapted with the permission from ref.<sup>111</sup> Copyright © 2021, The Author(s), under exclusive licence to Springer Nature Limited. 



Fig. 9 Several promising stability results of PSCs and PSMs according to the IEC standard. a Light soaking test<sup>63,116–120</sup> . b UV precondition test<sup>64,100,121</sup> . c Damp heat test<sup>23,63,116,119,122,123</sup> . d Thermal cycling test<sup>31,63,123,124</sup> . 

10 

COMMUNICATIONS MATERIALS | (2022) 3:58 | https://doi.org/10.1038/s43246-022-00281-z | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00281-z 

## Conclusion and outlook 

Several pioneering companies are actively pushing the industrialization of PSCs. The IEC standard on terrestrial PV modules, with the latest version of IEC 61215:2021, sets a series of strict stability tests for the evaluation of PV modules’ performance against known degradation and failure modes. As the most widely accepted protocol for PV technologies, it is deemed a minimum threshold for PSCs to the market. In this review, we introduced intrinsic and extrinsic factors that would cause failure to pass the tests, summarized common methods for solving these issues, and exhibited some results of passing the tests. It is important to note that current reports of passing single or several tests with separate PSCs are far from being satisfactory. Meeting the IEC 61215 standards requires passing the full tests. Achieving this demands comprehensive and profound understanding of perovskite components, stability properties of device structures, and encapsulation. More results of PSMs’ stability are also welcome. A merit of PSCs against Si-based and thin film solar cells is the solution-processable fabrication. However, solution-processed films tend to be rough and have defective regions, such as burs. These imperfections may lead to seams between the perovskite and the CTL. This is unfavorable to device performance and leaves channels for the destructive factors. Traditional layer-bylayer PSC structures are rather prone to the roughness especially when each functional layer is quite thin. For p-MPSCs, the perovskite grows inside the as-fabricated scaffold, the contact problem can be ignored. The undulated scaffold consisting of disordered nanoparticles endows p-MPSCs with high tolerance of imperfect perovskite morphology. The triple mesoscopic device structure is advantageous on large-area fabrication via screenprinting technique. The inherent stability of this structure lies in the hydrophobicity and inertness of carbon electrodes, the elimination of susceptible HTLs, and the protective mesoporous scaffold. 

The IEC standard was initially set up in 1993 based on research experience on crystalline silicon solar cells and modules. It was modified and supplemented in accordance with deeper understanding of known failure modes and newly discovered modes in both experimental and practical investigations. Testing requirements of amorphous silicon, CdTe, and Cu(In,GA)(S,Se)2 based modules had been included as its subsets. Inheriting current IEC standard for the qualification of PSCs may not be appropriate, considering the largely distinct material properties and device architectures over those PV technologies. The ionic nature of perovskites accounts for the biggest difference. Some unique phenomena including hysteresis, efficiency fluctuation during day/night cycles, bias-induced degradation and others have been attributed to ion migration. We believe a suitable stability qualification protocol for PSCs should place emphasis on ionic behaviors. A feasible scheme is modifying test details and adding new tests for existing protocols (e.g., the International Summit on Organic Photovoltaic Stability (ISOS) protocols<sup>125</sup> ), considering the relatively short development time of PSCs. A proprietary protocol for PSCs is expected to be established with adequate knowledge of degradation mechanisms from research and primary commercialization trials. Additionally, we think it is important to make the protocol openly-accessible, which is not the case for the IEC standard. This will trigger the improvement in PSCs’ stability via the convenience for comparisons and communications of stability results from different research groups. 

Finally, test results from any qualification protocol are not construed as a quantitative prediction of module lifetime. The artificial aging conditions are not equivalent to real operational environment. There may be unexpected failure modes observed in operation that are not covered in the protocol<sup>126</sup> . Hence, we 

suggest that outdoor stability tracking is highly required beyond accelerated aging tests in lab. Velilla et. al. carried out a highthroughput outdoor performance analysis of MAPbI3 minimodules and identified different performance evolution patterns. The ideal factor (nID) was calculated taking advantage of the different illumination conditions encountered during day–night cycles. A linear relationship was observed between the time until modules reached 80% of its initial PCE (T80) and until nID reached 2 (TnID2). Since nID values reflect recombination processes in the devices, this relationship made it possible to link recombination pathways to the degradation profile. This methodology provided insight to enable improved understanding of the device degradation processes under outdoor conditions that are relevant to the commercial application of PSCs<sup>127</sup> . Several researchers have conducted outdoor measurements and gathered meaningful data on real-world operation of PSCs and PSMs<sup>128–131</sup> . WonderSolar put up demonstration power systems with areas of 110 m<sup>2</sup> based on 3600 cm<sup>2</sup> p-MPSMs. We believe that this would further gain confidence from investors and customers. 

Received: 27 February 2022; Accepted: 5 August 2022; 



## References 

1. Zhang, L., Du, Q., Zhou, D. & Zhou, P. How does the photovoltaic industry contribute to China’s carbon neutrality goal? Analysis of a system dynamics simulation. Sci. Total Environ. 808, 151868 (2022). 

2. Ghosh, S. & Yadav, R. Future of photovoltaic technologies: a comprehensive review. Sustainable Energy Technol. Assess 47, 101410 (2021). 

3. Tawalbeh, M. et al. Environmental impacts of solar photovoltaic systems: a critical review of recent progress and future outlook. Sci. Total Environ. 759, 143528 (2021). 

4. Meng, L., You, J. & Yang, Y. Addressing the stability issue of perovskite solar cells for commercial applications. Nat. Commun. 9, 5265 (2018). 

5. Min, H. et al. Perovskite solar cells with atomically coherent interlayers on SnO2 electrodes. Nature 598, 444–450 (2021). 

6. Green, M. A. et al. Solar cell efficiency tables (Version 60). Prog. Photovoltaics Res. Appl. 30 (2022). 

7. Song, Z. et al. A technoeconomic analysis of perovskite solar module manufacturing with low-cost materials and techniques. Energy Environ. Sci. 10, 1297–1305 (2017). 

8. Guo, Z., Jena, A. K., Kim, G. M. & Miyasaka, T. The high open-circuit voltage of perovskite solar cells: a review. Energy Environ. Sci. 15, 3171–3222 (2022). 

9. Siegler, T. D. et al. The path to perovskite commercialization: a perspective from the United States Solar Energy Technologies Office. ACS Energy Lett. 7, 1728–1734 (2022). 

10. Roy, P., Kumar Sinha, N., Tiwari, S. & Khare, A. A review on perovskite solar cells: evolution of architecture, fabrication techniques, commercialization issues and status. Sol. Energy 198, 665–688 (2020). 

11. Wu, T. et al. The main progress of perovskite solar cells in 2020–2021. NanoMicro Lett. 13, 152 (2021). 

12. Service, R. F. Perovskite solar cells gear up to go commercial. Science 354, 1214–1215 (2016). 

13. Holzhey, P. & Saliba, M. A full overview of international standards assessing the long-term stability of perovskite solar cells. J. Mater. Chem. A 6, 21794–21808 (2018). 

14. Hu, Y. et al. Standardizing perovskite solar modules beyond cells. Joule 3, 2076–2085 (2019). 

15. Kim, H.-J., Kim, H.-S. & Park, N.-G. Progress of perovskite solar modules. Adv. Energy Sustainable Res. 2, 2000051 (2021). 

16. He, S., Qiu, L., Ono, L. K. & Qi, Y. How far are we from attaining 10-year lifetime for metal halide perovskite solar cells? Mater. Sci. Eng. Rep. 140, 100545 (2020). 

17. Rong, Y. et al. Challenges for commercializing perovskite solar cells. Science 361, eaat8235 (2018). 

18. Leguy, A. M. A. et al. Reversible hydration of CH3NH3PbI3 in films, single crystals, and solar cells. Chem. Mater. 27, 3397–3407 (2015). 

19. Conings, B. et al. Intrinsic thermal instability of methylammonium lead trihalide perovskite. Adv. Energy Mater. 5, 1500477 (2015). 

11 

COMMUNICATIONS MATERIALS | (2022) 3:58 | https://doi.org/10.1038/s43246-022-00281-z | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00281-z 

20. Philippe, B. et al. Chemical and electronic structure characterization of lead halide perovskites and stability behavior under different exposures—A photoelectron spectroscopy investigation. Chem. Mater. 27, 1720–1731 (2015). 

21. Ma, L. et al. Temperature-dependent thermal decomposition pathway of organic–inorganic halide perovskite materials. Chem. Mater. 31, 8515–8522 (2019). 

22. Masi, S., Gualdrón-Reyes, A. F. & Mora-Seró, I. Stabilization of black perovskite phase in FAPbI3 and CsPbI3. ACS Energy Lett. 5, 1974–1985 (2020). 

23. Shi, L. et al. Gas chromatography-mass spectrometry analyses of encapsulated stable perovskite solar cells. Science 368, eaba2412 (2020). GC-MS identified signature volatile products of the thermal decomposition of organic hybrid perovskites and a simple low-cost pressure-tight encapsulation enables PSCs to pass IEC tests. 

24. Aranda, C. A., Caliò, L. & Salado, M. Toward commercialization of stable devices: an overview on encapsulation of hybrid organic-inorganic perovskite solar cells. Crystals 11, 519 (2021). 

25. Cheacharoen, R. et al. Encapsulating perovskite solar cells to withstand damp heat and thermal cycling. Sustainable Energy Fuels 2, 2398–2406 (2018). 

26. Bush, K. A. et al. 23.6%-efficient monolithic perovskite/silicon tandem solar cells with improved stability. Nat. Energy 2, 17009 (2017). 

27. Rolston, N. et al. Engineering stress in perovskite solar cells to improve stability. Adv. Energy Mater. 8, 1802139 (2018). 

28. De Bastiani, M. et al. Mechanical reliability of fullerene/tin oxide interfaces in monolithic perovskite/silicon tandem cells. ACS Energy Lett. 7, 827–833 (2022). 

29. Dong, Q. et al. Interpenetrating interfaces for efficient perovskite solar cells with high operational stability and mechanical robustness. Nat. Commun. 12, 973 (2021). 

30. Ma, S. et al. Development of encapsulation strategies towards the commercialization of perovskite solar cells. Energy Environ. Sci. 15, 13–55 (2022). 

31. Cheacharoen, R. et al. Design and understanding of encapsulated perovskite solar cells to withstand temperature cycling. Energy Environ. Sci. 11, 144–150 (2018). 

32. Masi, S. et al. Chemi-structural stabilization of formamidinium lead iodide perovskite by using embedded quantum dots. ACS Energy Lett. 5, 418–427 (2020). 

33. Li, X. et al. Constructing heterojunctions by surface sulfidation for efficient inverted perovskite solar cells. Science 375, 434–437 (2022). 

34. Wang, Y. et al. Stabilizing heterostructures of soft perovskite semiconductors. Science 365, 687–691 (2019). 

35. Jena, A. K., Ikegami, M. & Miyasaka, T. Severe morphological deformation of Spiro-OMeTAD in (CH3NH3)PbI3 solar cells at high temperature. ACS Energy Lett. 2, 1760–1761 (2017). 

36. Song, W. et al. Improving the morphology stability of Spiro-OMeTAD films for enhanced thermal stability of perovskite solar cells. ACS Appl. Mater. Interfaces 13, 44294–44301 (2021). 

37. Carrillo, J. et al. Ionic reactivity at contacts and aging of methylammonium lead triiodide perovskite solar cells. Adv. Energy Mater. 6, 1502246 (2016). 

38. Kerner, R. A. et al. Organic hole transport material ionization potential dictates diffusion kinetics of iodine species in halide perovskite devices. ACS Energy Lett. 6, 501–508 (2021). 

39. Kim, S. G. et al. Capturing mobile lithium ions in a molecular hole transporter enhances the thermal stability of perovskite solar cells. Adv. Mater. 33, e2007431 (2021). 

40. Zhou, W., Wen, Z. & Gao, P. Less is more: dopant-free hole transporting materials for high-efficiency perovskite solar cells. Adv. Energy Mater. 8, 1702512 (2018). 

41. Rombach, F. M., Haque, S. A. & Macdonald, T. J. Lessons learned from SpiroOMeTAD and PTAA in perovskite solar cells. Energy Environ. Sci. 14, 5161–5190 (2021). 

42. Zhang, D., Rong, Y., Hu, Y., Mei, A. & Han, H. Hole-conductor-free perovskite solar cells. MRS Bull 45, 449–457 (2020). 

43. Domanski, K. et al. Not all that glitters is gold: Metal-migration-induced degradation in perovskite solar cells. ACS Nano 10, 6306–6314 (2016). The diffusion of Au into the perovskite layer was identified as a big contributor to efficiency losses of PSCs under thermal stress. 

44. Wu, S. et al. A chemically inert bismuth interlayer enhances long-term stability of inverted perovskite solar cells. Nat. Commun. 10, 1161 (2019). 

45. Seo, S. et al. Amorphous TiO2 coatings stabilize perovskite solar cells. ACS Energy Lett. 6, 3332–3341 (2021). 

46. Jeong, G. et al. Suppressed interdiffusion and degradation in flexible and transparent metal electrode-based perovskite solar cells with a graphene interlayer. Nano Lett. 20, 3718–3727 (2020). 

47. Hu, X. et al. Air and thermally stable perovskite solar cells with CVDgraphene as the blocking layer. Nanoscale 9, 8274–8280 (2017). 

48. Boyd, C. C. et al. Barrier design to prevent metal-induced degradation and improve thermal stability in perovskite solar cells. ACS Energy Lett. 3, 1772–1778 (2018). 

49. Agresti, A. et al. Two-dimensional material interface engineering for efficient perovskite large-area modules. ACS Energy Lett. 4, 1862–1871 (2019). 

50. Zhao, J. et al. Is Cu a stable electrode material in hybrid perovskite solar cells for a 30-year lifetime? Energy Environ. Sci. 9, 3650–3656 (2016). 

51. Liang, L., Cai, Y., Li, X., Nazeeruddin, M. K. & Gao, P. All that glitters is not gold: recent progress of alternative counter electrodes for perovskite solar cells. Nano Energy 52, 211–238 (2018). 

52. Bush, K. A. et al. Thermal and environmental stability of semi-transparent perovskite solar cells for tandems enabled by a solution-processed nanoparticle buffer layer and sputtered ITO electrode. Adv. Mater. 28, 3937–3943 (2016). 

53. Hou, Y. et al. Efficient tandem solar cells with solution-processed perovskite on textured crystalline silicon. Science 367, 1135–1140 (2020). 

54. Wang, M. et al. A Bi2Te3 topological insulator as a new and outstanding counter electrode material for high-efficiency and endurable flexible perovskite solar cells. ACS Appl. Mater. Interfaces 11, 47868–47877 (2019). 

55. Zhou, C. & Lin, S. Carbon-electrode based perovskite solar cells: Effect of bulk engineering and interface engineering on the power conversion properties. Sol. RRL 4, 1900190 (2020). 

56. Fagiolari, L. & Bella, F. Carbon-based materials for stable, cheaper and largescale processable perovskite solar cells. Energy Environ. Sci. 12, 3437–3472 (2019). 

57. Li, X. et al. Outdoor performance and stability under elevated temperatures and long-term light soaking of triple-layer mesoporous perovskite photovoltaics. Energy Technol. 3, 551–555 (2015). 

58. Liu, S. et al. Highly oriented MAPbI3 crystals for efficient hole-conductorfree printable mesoscopic perovskite solar cells. Fundam. Res. 2, 276–283 (2021). 

59. Chen, W. et al. Efficient and stable large-area perovskite solar cells with inorganic charge extraction layers. Science 350, 944 (2015). 

60. Chen, W., Xu, L., Feng, X., Jie, J. & He, Z. Metal acetylacetonate series in interface engineering for full low-temperature-processed, high-performance, and stable planar perovskite solar cells with conversion efficiency over 16% on 1 cm2 scale. Adv. Mater. 29, 1603923 (2017). 

61. Tan, H. et al. Efficient and stable solution-processed planar perovskite solar cells via contact passivation. Science 355, 722 (2017). 

62. Saliba, M. et al. Incorporation of rubidium cations into perovskite solar cells improves photovoltaic performance. Science 354, 206–209 (2016). 

63. Mei, A. et al. Stabilizing perovskite solar cells to IEC61215:2016 standards with over 9000-h operational tracking. Joule 4, 2646–2660 (2020). P-MPSCs pass IEC qualification tests with a 9,000-h operational tracking with the boundary strengthening, component loss inhibition and ionic migration suppression of 5AVAI. 

64. Hang, P. et al. Stabilizing fullerene for burn-in-free and stable perovskite solar cells under ultraviolet preconditioning and light soaking. Adv. Mater. 33, 2006910 (2021). 

65. Yuan, Y. & Huang, J. Ion migration in organometal trihalide perovskite and its impact on photovoltaic efficiency and stability. Acc. Chem. Res. 49, 286–293 (2016). A critical review was provided on the ion-migration science in hybrid perovskites and its impacts on PSCs’ stability and efficiency was summarized. 

66. Ni, Z. et al. Evolution of defects during the degradation of metal halide perovskite solar cells under reverse bias and illumination. Nat. Energy 7, 65 (2021). 

67. Zhao, J. et al. Strained hybrid perovskite thin films and their impact on the intrinsic stability of perovskite solar cells. Sci. Adv. 3, eaao5616 (2017). 

68. Schoonman, J. Organic–inorganic lead halide perovskite solar cell materials: a possible stability problem. Chem. Phys. Lett. 619, 193–195 (2015). 

69. Liu, F. et al. Is excess PbI2 beneficial for perovskite solar cell performance? Adv. Energy Mater. 6, 1502206 (2016). 

70. Roose, B., Dey, K., Chiang, Y.-H., Friend, R. H. & Stranks, S. D. Critical assessment of the use of excess lead iodide in lead halide perovskite solar cells. J. Phys. Chem. Lett. 11, 6505–6512 (2020). 

71. Tumen-Ulzii, G. et al. Detrimental effect of unreacted PbI2 on the long-term stability of perovskite solar cells. Adv. Mater. 32, 1905035 (2020). 

72. Zhao, L. et al. Chemical polishing of perovskite surface enhances photovoltaic performances. J. Amer. Chem. Soc. 144, 1700–1708 (2022). 

73. Brennan, M. C., Draguta, S., Kamat, P. V. & Kuno, M. Light-induced anion phase segregation in mixed halide perovskites. ACS Energy Lett. 3, 204–213 (2017). 

74. Hoke, E. T. et al. Reversible photo-induced trap formation in mixed-halide hybrid perovskites for photovoltaics. Chem. Sci. 6, 613–617 (2015). 

12 

COMMUNICATIONS MATERIALS | (2022) 3:58 | https://doi.org/10.1038/s43246-022-00281-z | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00281-z 

75. Li, N. et al. Microscopic degradation in formamidinium-cesium lead iodide perovskite solar cells under operational stressors. Joule 4, 1743–1758 (2020). 

76. Chen, B. et al. Synergistic effect of elevated device temperature and excess charge carriers on the rapid light-induced degradation of perovskite solar cells. Adv. Mater. 31, e1902413 (2019). 

77. Zhang, T. et al. Crystallinity preservation and ion migration suppression through dual ion exchange strategy for stable mixed perovskite solar cells. Adv. Energy Mater. 7, 1700118 (2017). 

78. Li, N. et al. Cation and anion immobilization through chemical bonding enhancement with fluorides for stable halide perovskite solar cells. Nat. Energy 4, 408–415 (2019). 

79. Tai, Q. et al. Efficient and stable perovskite solar cells prepared in ambient air irrespective of the humidity. Nat. Commun. 7, 11105 (2016). 

80. Zhang, J., Wu, S., Liu, T., Zhu, Z. & Jen, A. K. Y. Boosting photovoltaic performance for lead halide perovskites solar cells with BF4<sup>−</sup> anion substitutions. Adv. Funct. Mater. 29, 1808833 (2019). 

81. Chen, J., Kim, S.-G. & Park, N.-G. FA0.88Cs0.12PbI3−x(PF6)x interlayer formed by ion exchange reaction between perovskite and hole transporting layer for improving photovoltaic performance and stability. Adv. Mater. 30, 1801948 (2018). 

82. Muscarella, L. A. et al. Lattice compression increases the activation barrier for phase segregation in mixed-halide perovskites. ACS Energy Lett. 5, 3152–3158 (2020). 

83. Haruyama, J., Sodeyama, K., Han, L. & Tateyama, Y. First-Principles study of ion diffusion in perovskite solar cell sensitizers. J. Amer. Chem. Soc. 137, 10048–10051 (2015). 

84. Tan, S. et al. Steric impediment of ion migration contributes to improved operational stability of perovskite solar cells. Adv. Mater. 32, 1906995 (2020). 

85. Pering, S. R. et al. Azetidinium lead iodide for perovskite solar cells. J. Mater. Chem. A 5, 20658–20665 (2017). 

86. Jodlowski, A. D. et al. Large guanidinium cation mixed with methylammonium in lead iodide perovskites for 19% efficient solar cells. Nat. Energy 2, 972–979 (2017). 

87. Abdi-Jalebi, M. et al. Maximizing and stabilizing luminescence from halide perovskites with potassium passivation. Nature 555, 497–501 (2018). 

88. Cao, J., Tao, S. X., Bobbert, P. A., Wong, C.-P. & Zhao, N. Interstitial occupancy by extrinsic alkali cations in perovskites and its impact on ion migration. Adv. Mater. 30, 1707350 (2018). 

89. Lin, Y.-H. et al. A piperidinium salt stabilizes efficient metal-halide perovskite solar cells. Science 369, 96–102 (2020). A p-i-n inverted planar PSC utilizing the BMPBF4 additive for suppressing deep trap states, the thermally stable HTL polyTPD, and Cr-modified Au electrode to achieve 1200 h stability under full sunlight at 85 °C. 

90. Bai, S. et al. Planar perovskite solar cells with long-term stability using ionic liquid additives. Nature 571, 245–250 (2019). 

91. Yang, J. et al. Uncovering the mechanism of Poly(ionic-liquid)s multiple inhibition of ion migration for efficient and stable perovskite solar cells. Adv. Energy Mater. 12, 2103652 (2022). 

92. Deng, Y. et al. Defect compensation in formamidinium–caesium perovskites for highly efficient solar mini-modules with improved photostability. Nat. Energy 6, 633–641 (2021). 

93. Chen, S. et al. Stabilizing perovskite-substrate interfaces for high-performance perovskite modules. Science 373, 902–907 (2021). 

94. Dai, Z. et al. Interfacial toughening with self-assembled monolayers enhances perovskite solar cell reliability. Science 372, 618–622 (2021). The importance of interface on PSCs’ stability was emphasized and an I-terminated selfassembly monolayer method was proposed. 

95. Wang, L. et al. A Eu<sup>3+</sup> -Eu<sup>2+</sup> ion redox shuttle imparts operational durability to Pb-I perovskite solar cells. Science 363, 265–270 (2019). Eu<sup>3+</sup> -Eu<sup>2+</sup> can shuttle electrons and recover lead and iodine ions to suppress the formation of defects in PSCs under aging conditions. 

96. Chang, Q. et al. Ferrocene-induced perpetual recovery on all elemental defects in perovskite solar cells. Angew. Chem. Int. Ed. Engl. 60, 25567–25574 (2021). 

97. Bella, F. et al. Improving efficiency and stability of perovskite solar cells with photocurable fluoropolymers. Science 354, 203–206 (2016). 

98. Shi, Z. et al. Dual interfacial engineering to improve ultraviolet and nearinfrared light harvesting for efficient and stable perovskite solar cells. Chem. Eng. J. 435, 134792 (2022). 

99. Pathak, S. K. et al. Performance and stability enhancement of dye-sensitized and perovskite solar cells by Al doping of TiO2. Adv. Funct. Mater. 24, 6046–6055 (2014). 

100. Ji, J. et al. Two-stage ultraviolet degradation of perovskite solar cells induced by the oxygen vacancy-Ti<sup>4+</sup> states. iScience 23, 101013 (2020). 

101. Wang, X. et al. Cerium oxide standing out as an electron transport layer for efficient and stable perovskite solar cells processed at low temperature. J. Mater. Chem. A 5, 1706–1712 (2017). 

102. Yoon, S. et al. Solution-processed indium oxide electron transporting layers for high-performance and photo-stable perovskite and organic solar cells. Nanoscale 9, 16305–16312 (2017). 

103. Fernandes, S. L. et al. Nb2O5 hole blocking layer for hysteresis-free perovskite solar cells. Materials Letters 181, 103–107 (2016). 

104. Jiang, Q. et al. Enhanced electron extraction using SnO2 for high-efficiency planar-structure HC(NH2)2PbI3-based perovskite solar cells. Nat. Energy 2, 16177 (2016). 

105. Shin Seong, S. et al. Colloidally prepared La-doped BaSnO3 electrodes for efficient, photostable perovskite solar cells. Science 356, 167–171 (2017). 

106. Wei, J. et al. UV-Inert ZnTiO3 electron selective layer for photostable perovskite solar cells. Adv. Energy Mater. 9, 1901620 (2019). 

107. Li, S. et al. van der waals mixed valence tin oxides for perovskite solar cells as UV-stable electron transport materials. Nano Lett 20, 8178–8184 (2020). 

108. Deng, K., Chen, Q. & Li, L. Modification engineering in SnO2 electron transport layer toward perovskite solar cells: Efficiency and stability. Adv. Funct. Mater. 30, 2004209 (2020). 

109. Uddin, A. & Yi, H. Progress and challenges of SnO2 electron transport layer for perovskite solar cells: A critical review. Sol. RRL 6, 2100983 (2022). 

110. Mei, A. et al. A hole-conductor-free, fully printable mesoscopic perovskite solar cell with high stability. Science 345, 295–298 (2014). 

111. Zhao, Y. et al. A bilayer conducting polymer structure for planar perovskite solar cells with over 1,400 hours operational stability at elevated temperatures. Nat. Energy 7, 144–152 (2021). Inherently stable device structure and perovskite composition were employed to achieve 99% efficiency retaining after 1450 h of continuous operation at 65 °C in N2. 

112. Jordan, D. C., Silverman, T. J., Wohlgemuth, J. H., Kurtz, S. R. & VanSant, K. T. Photovoltaic failure and degradation modes. Prog. Photovoltaics Res. Appl. 25, 318–326 (2017). 

113. Bowring, A. R., Bertoluzzi, L., O’Regan, B. C. & McGehee, M. D. Reverse bias behavior of halide perovskite solar cells. Adv. Energy Mater. 8, 1702365 (2018). 

114. Bogachuk, D. et al. Perovskite photovoltaic devices with carbon-based electrodes withstanding reverse-bias voltages up to −9 V and surpassing IEC 61215:2016 international standard. Sol. RRL 6, 2100527 (2021). The first report on passing the IEC hot-spot test for PSCs, exhibiting the inherent stability of the triple mesoscopic device structure. 

115. Galagan, Y. Stability of perovskite PV modules. J. Phys. Energy 2, 021004 (2020). 

116. Yang, T.-Y. et al. Achieving long-term operational stability of perovskite solar cells with a stabilized efficiency exceeding 20% after 1000 h. Adv. Sci. 6, 1900528 (2019). 

117. Bi, D. et al. Multifunctional molecular modulators for perovskite solar cells with over 20% efficiency and high operational stability. Nat. Commun. 9, 4482 (2018). 

118. Yang, Z. et al. Slot-die coating large-area formamidinium-cesium perovskite film for efficient and stable parallel solar module. Sci. Adv. 7, eabg3749 (2021). 

119. Bi, E. et al. Efficient perovskite solar cell modules with high stability enabled by iodide diffusion barriers. Joule 3, 2748–2760 (2019). 

120. Hu, Y. et al. Stable large-area (10 × 10 cm<sup>2</sup> ) printable mesoscopic perovskite module exceeding 10% efficiency. Sol. RRL 1, 1600019 (2017). 

121. Arora, N. et al. Low-cost and highly efficient carbon-based perovskite solar cells exhibiting excellent long-term operational and UV stability. Small 15, 1904746 (2019). 

122. Sha, Y. et al. A scalable integrated dopant-free heterostructure to stabilize perovskite solar cell modules. Adv. Energy Mater. 11, 2003301 (2021). 

123. Xiao, X. et al. Lead-adsorbing ionogel-based encapsulation for impactresistant, stable, and lead-safe perovskite modules. Sci. Adv. 7, eabi8249 (2021). 

124. Wang, S. et al. Mesoporous-carbon-based fully-printable all-inorganic monoclinic CsPbBr3 perovskite solar cells with ultrastability under high temperature and high humidity. J. Phys. Chem. Lett. 11, 9689–9695 (2020). 

125. Khenkin, M. V. et al. Consensus statement for stability assessment and reporting for perovskite photovoltaics based on ISOS procedures. Nat. Energy 5, 35–49 (2020). 

126. Osterwald, C. R. & McMahon, T. J. History of accelerated and qualification testing of terrestrial photovoltaic modules: A literature review. Prog. Photovoltaics Res. Appl. 17, 11–33 (2009). 

127. Velilla, E., Jaramillo, F. & Mora-Seró, I. High-throughput analysis of the ideality factor to evaluate the outdoor performance of perovskite solar minimodules. Nat. Energy 6, 54–62 (2021). 

128. Jošt, M. et al. Perovskite solar cells go outdoors: field testing and temperature effects on energy yield. Adv. Energy Mater. 10, 2000454 (2020). 

13 

COMMUNICATIONS MATERIALS | (2022) 3:58 | https://doi.org/10.1038/s43246-022-00281-z | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00281-z 

129. Stoichkov, V. et al. Outdoor performance monitoring of perovskite solar cell mini-modules: diurnal performance, observance of reversible degradation and variation with climatic performance. Sol. Energy 170, 549–556 (2018). 

130. De Rossi, F. et al. An interlaboratory study on the stability of all-printable hole transport material–free perovskite solar cells. Energy Technol. 8, 2000134 (2020). 

131. Fu, Z. Y. et al. Encapsulation of printable mesoscopic perovskite solar cells enables high temperature and long-term outdoor stability. Adv. Funct. Mater. 29, 1809129 (2019). 

## Additional information 

Correspondence and requests for materials should be addressed to Hongwei Han. 

Peer review information Communications Materials thanks the anonymous reviewers for their contribution to the peer review of this work. Primary Handling Editors: Emilio Juarez-Perez and John Plummer. 

Reprints and permission information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

## Acknowledgements 

The authors acknowledge financial support from the National Natural Science Foundation of China (Grant No. 52172198, 51902117, 91733301), the Fundamental Research Funds for the Central Universities (No. 2019kfyXJJS051), the Science and Technology Department of Hubei Province (No. 2017AAA190), the 111 Project (No. B07038) and the Program for HUST Academic Frontier Youth Team (2016QYTD06). 

## Author contributions 

D. Y. Z., supported by D. Y. L, wrote and edited the manuscript under the supervision of A. Y. M. and H. W. H. with advice and feedback from Y. H. All authors provided critical feedback at the stage of revisions. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

## Competing interests 

The authors declare no competing interests. 

© The Author(s) 2022 

14 

COMMUNICATIONS MATERIALS | (2022) 3:58 | https://doi.org/10.1038/s43246-022-00281-z | www.nature.com/commsmat 

