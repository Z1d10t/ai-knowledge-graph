# Lead halide–templated crystallization of methylamine-free perovskite for efficient photovoltaic modules

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Science |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 550 |
| 作者 | Tong-Le Bu, Jing Li, Heng-Jian Li, Cong-Cong Tian, Jie Su, Guo-Qing Tong, L. Ono, Chao Wang et al. |
| DOI | 10.1126/science.abh1035 |
| 源文件 | 010_Bu_2021_Lead-halidetemplated-crystallization-of-methylam.pdf |

---
RESEARCH 



it is hard for the FAI deposited in the second step to diffuse into the bottom of the PbI2 film to induce a complete reaction (22). In the perovskite precursor solution, if the FAI and PbI2 species do not form perovskites or solventcoordinated perovskite complexes, the nucleation will be dominated by PbI2 and therefore it will be easier to form a dense film. Because FAI is embedded during the formation of the PbI2 film, it is easier to induce an in situ reaction between the PbI2 and FAI by the subsequent thermal annealing, resulting in a dense perovskite film. Thus, the crystallization of the perovskite is templated by the PbI2-derived crystals. 



### SOLAR CELLS 

# Lead halide–templated crystallization of methylamine-free perovskite for efficient photovoltaic modules 

Tongle Bu<sup>1,2,3</sup> , Jing Li<sup>1</sup> , Hengyi Li<sup>1</sup> , Congcong Tian<sup>1</sup> , Jie Su<sup>4</sup> , Guoqing Tong<sup>3</sup> , Luis K. Ono<sup>3</sup> , Chao Wang<sup>1</sup> , Zhipeng Lin<sup>1</sup> , Nianyao Chai<sup>1</sup> , Xiao-Li Zhang<sup>5</sup> , Jingjing Chang<sup>4</sup> , Jianfeng Lu<sup>2,6</sup> , Jie Zhong<sup>1,2</sup> , Wenchao Huang<sup>1</sup> , Yabing Qi<sup>3</sup> , Yi-Bing Cheng<sup>2</sup> , Fuzhi Huang<sup>1,2</sup> * 

Upscaling efficient and stable perovskite layers is one of the most challenging issues in the commercialization of perovskite solar cells. Here, a lead halide–templated crystallization strategy is developed for printing formamidinium (FA)–cesium (Cs) lead triiodide perovskite films. High-quality large-area films are achieved through controlled nucleation and growth of a lead halide•N-methyl-2-pyrrolidone adduct that can react in situ with embedded FAI/CsI to directly form a-phase perovskite, sidestepping the phase transformation from d-phase. A nonencapsulated device with 23% efficiency and excellent long-term thermal stability (at 85°C) in ambient air (~80% efficiency retention after 500 hours) is achieved with further addition of potassium hexafluorophosphate. The slot die–printed minimodules achieve champion efficiencies of 20.42% (certified <mark>efficiency 19.3%) and 19.54% with an active area of 17.1 and 65.0 square centimeters, respectively.</mark> 

Here, we report a lead halide–templated crystallization strategy to prepare compact methylamine-free perovskite films for the fabrication of antisolvent–free and ambient air–printed high-performance PSMs. The key point to obtaining high-quality large-area FAbased perovskite films is to completely inhibit the formation of a solvent-coordinated perovskite intermediate complex via the formation of a stable PbI2•N-methylpyrrolidone (NMP) adduct, which can react in situ with embedded FAI/CsI species. In addition, by using this process, we can lower the formation energy of a-phase perovskite, which is an unstable hightemperature phase, thus converting the a-phase FA-based perovskite film (FA0.83Cs0.17PbI3) even at room temperature. The resulting perovskite films are further passivated by a KPF6 salt, which contributes to high-performance hysteresis-free PSCs with an efficiency of 23.35% and dramatically enhanced thermal and light stability. Eventually, a slot die– printed high-quality large-area perovskite film is realized using this strategy. The corresponding solar minimodules demonstrate efficiencies of 20.42% on 17.1 cm<sup>2</sup> and 19.54% on 65.0 cm<sup>2</sup> , respectively. 

strategies—including antisolvent bathing (7), softcover coating (8), gas flow (9), vacuum (10) or thermal assisting (11), and additive engineering (12)—have been successfully used to fabricate high-quality large-area perovskite films. For example, Hu and others used an air blade to quickly remove the solvent of the methylammonium lead triiodide (MAPbI3) perovskite wet film to promote the concentration of the perovskite precursor and induce a higher nucleation rate, forming a dense perovskite film (13). Huang and others reported a thermally assisted blade-coated perovskite film with an efficiency of 14.6% on 57.2-cm<sup>2</sup> perovskite solar modules (PSMs) using a surfactantadded MAPbI3−xClx perovskite ink (11). 

ybrid organic-inorganic metal halide perovskite solar cells (PSCs) have attracted intensive interest during the past decade, with power conversion efficienH cies (PCEs) now greater than 25% (1). Such a development is attributed to the intrinsically superior photoelectric properties of the perovskite materials that possess tunable bandgaps, high absorption coefficients, and long carrier diffusion lengths (2–4). In particular, the PSCs can be fabricated through a myriad of low-cost solution processes, which offers great promise for future commercialization. However, scalability and stability issues have impeded their industrialization. 

The most important prerequisite for fabricating large-area PSCs is the deposition of high-quality perovskite thin films. The nucleation and crystal growth of the perovskite in solution are largely uncontrollable, often leading to a porous film that would greatly impair the device’s performance (5, 6). The larger the area is, the harder it will be to achieve a uniform crystalline film. Various efforts have been devoted to controlling the nucleation and crystal growth for scaling up perovskite films. Many 

However, MAPbI3 perovskites have shown poor stability at high temperatures or under light illumination (14, 15). Instead, the MA-free perovskites such as formamidinium lead triiodide (FAPbI3) or formamidinium-caesium lead triiodide [(FACs)PbI3] show promising thermal stability owing to their higher phasetransformation temperatures (16–18). In addition, the narrower optical bandgap of FAPbI3 with respect to that of MAPbI3 can contribute to higher efficiencies (19). Recently, the FAbased PSCs without MA have attracted intensive attention, especially for large-area devices (20). Unfortunately, the nucleation and crystal growth of the FA-based perovskites are even harder to control. Alternatively, it might be feasible to control the nucleation of perovskite intermediates such as their solventcoordinated complexes (9, 21). However, the nucleation rate of solvent-coordinated FA-based perovskite complexes is still not high enough. Indeed, besides the one-step method, the twostep method is also widely used in fabricating small-area perovskite films. It is rather easy to achieve a dense PbI2 film in the first step, but 

FAPbI3 has the narrowest bandgap (~1.48 eV) among the Pb-based perovskites and much better thermal stability than MA-based perovskite. However, pure a-FAPbI3 is unstable, so Cs is normally introduced to stabilize the phase (23). Here, FA0.83Cs0.17PbI3 perovskite is used to study its nucleation and crystal growth kinetics. N,N-dimethylformamide (DMF) is a commonly used solvent for perovskite precursor ink because of its high solubility and volatility. We found that during the natural drying process, only a few nuclei form at the beginning (fig. S1i), then several flat, needle-shaped crystals grow, surrounding every nucleus. After drying completely, a scanning electron microscopy (SEM) image (Fig. 1Ai) shows a rough film with dendrites, large pores, and some densely packed large grains lying underneath the dendrites, clearly indicating that there are two types of structures. To trace the formation processes of such structures, in situ x-ray diffraction (XRD) was conducted to investigate phase 

> 1State Key Laboratory of Advanced Technology for Materials Synthesis and Processing, Wuhan University of Technology, Wuhan 430070, PR China.<sup>2</sup> Foshan Xianhu Laboratory of the Advanced Energy Science and Technology Guangdong Laboratory, Foshan 528216, PR China.<sup>3</sup> Energy Materials and Surface Sciences Unit (EMSSU), Okinawa Institute of Science and Technology Graduate University (OIST), Okinawa 904-0495, Japan.<sup>4</sup> Xidian University, School of Microelectronics, State Key Discipline Lab of Wide Band Gap Semiconductor Technology, Shaanxi Joint Key Lab of Graphene, Advanced Interdisciplinary Research Center for Flexible Electronics, Xian 710071, PR China.<sup>5</sup> School of Materials Science and Engineering, Zhengzhou University, Zhengzhou 450001, PR China.<sup>6</sup> State Key Laboratory of Silicate Materials for Architectures, Wuhan University of Technology, Wuhan 430070, PR China. *Corresponding author. Email: fuzhi.huang@whut.edu.cn 

1 of 6 

Bu et al., Science 372, 1327–1332 (2021) 18 June 2021 

RESEARCH | REPORT 



diamond, PbI2•NMP; open diamond, PbX2•0.5NMP•0.5DMF; a.u., arbitrary units. (C) SEM images of the corresponding perovskite ink spun onto FTO/glass substrates at 3000 rpm. (D) The corresponding XRD patterns of spin-coated (at 3000 rpm) perovskite films annealed at different temperatures for 10 min. (E) Schematic diagram of crystal growth with or without NMP. (F) Free-energy calculation for the formation of FAPbI3 perovskites with or without NMP. 

Fig. 1. Nucleation and crystallization of MA-free perovskites. (A and B) Shown are (A) SEM and (B) in situ XRD patterns of 10-ml perovskite precursor inks (1.1 M) with or without different additives drying on the 1.5-cm–by–1.5-cm FTO/glass substrates: (i) FA0.83Cs0.17PbI3/DMF, (ii) FA0.83Cs0.17PbI3-NMP/DMF, and (iii) FA0.83Cs0.17PbI3-NMP-10%PbCl2/DMF. Cs2Pb3I8•4DMF, solid blue triangle; FA2Pb3I8•4DMF, purple circle; open triangle, d-(FACs)PbI3; solid green 

form and then transform to d-(FACs)PbI3. Finally, FA2Pb3I8•4DMF and d-(FACs)PbI3 are mainly present in the film. Although perovskites in the DMF form intermediate solventcoordinated complexes, the nucleation rate is still too low during the natural drying process. To accelerate the nucleation rate, the precursor solution is spun at 3000 rpm to quickly 

change during the natural drying process. According to the density functional theory (DFT) fitting (fig. S2) and a comparison with the in situ XRD patterns from different components with additives (fig. S3), it can be inferred from Fig. 1Bi and fig. S4 that at the beginning, solvent-coordinated perovskite intermediate phases of Cs2Pb3I8•4DMF and FA2Pb3I8•4DMF 

remove the solvent. The morphology change is shown in Fig. 1Ci. There are some large-area dense zones that formed, with a few rods randomly distributed. So even with the assistance of solvent removal by spinning, the nucleation rate is not high enough, because there are still many large pores. This demonstrates that it is hard to change the nucleation 

2 of 6 

Bu et al., Science 372, 1327–1332 (2021) 18 June 2021 

RESEARCH | REPORT 



Fig. 2. Photovoltaic performance of antisolvent– free coated PSCs with KPF6 passivation. (A) Schematic of the PSC with the structure FTO/SnO2/3D-perovskite/ 2D-perovskite/spiro-OMeTAD/ Au. PVSK, perovskite. (B and C) Champion J-V curves of 3D/2D perovskite–based devices with or without KPF6 additive tested using a metal mask with an aperture area of (B) 0.148 cm<sup>2</sup> and (C) 1.0 cm<sup>2</sup> . (D) J-V characteristics of the 3D/2D perovskite films with or without KPF6 additive derived from the SCLC measurements with a structure of ITO/ perovskite/Au (ITO, indium tin oxide). VTFL, trap-filled limited voltage. (E and F) Time-resolved confocal PL lifetime maps of (E) 3D/2D and (F) 3D/2D-KPF6 perovskite films, respectively. 

kinetics of FA-based perovskites through the approach of forming intermediate solventcoordinated complexes. The XRD patterns (Fig. 1Di) show the presence of major d-(FACs) PbI3 in the final film. 

the FA2Pb3I8•4DMF. When the film is prepared by spin-coating the precursor solution at 3000 rpm, the film becomes smoother and denser and has a light brown color (fig. S5), but it still has some small pores and several needles (Fig. 1Cii). XRD patterns (Fig. 1Dii) show the presence of an almost pure PbI2•NMP phase. Interestingly, we also find that minor a-(FACs)PbI3 emerges in the film. When we increase the spinning speed to 5000 rpm, the peak intensity of the a-phase becomes stronger (fig. S6). It is completely different from that of the film derived from the pure DMF solution. When the film is annealed at 70°C, an obvious a-(FACs)PbI3 phase appears (Fig. 1Dii), and the film becomes a black color (fig. S5). With a further increase in annealing temperature to 150°C, the peak of the a-phase becomes even stronger. For the DMF-derived film, when annealed at 70°C, the peak of the d-(FACs)PbI3 phase becomes stronger (Fig. 1Di) and the film still remains a yellow color (fig. S5). However, when further annealed at 150°C, the d-phase is completely transformed into a-phase (Fig. 1Di) and becomes a black color (fig. S5). According to the DFT calculation (Fig. 1F), because a-FAPbI3 is a hightemperature phase, the conversion energy is high if it is from d-FAPbI3, which is rapidly transformed from the DMF-coordinated complexes. However, when PbI2•NMP reacts with FAI to form perovskite, the a-FAPbI3 formation energy is dramatically decreased. This is why the addition of NMP can induce an a-phase perovskite at room temperature with the incorporation of Cs. The study of pure FAPbI3 films growing from 2-methoxyethanol 

(2-Me), an uncoordinated solvent, with or without corresponding coordination solvent additives further confirms the above findings, as shown in fig. S7. In short, the presence of the intermediate phases (the perovskite-DMF complexes) will result in porous d-phase perovskite films, whereas the existence of PbI2-NMP will directly produce dense a-phase perovskite films (fig. S4E). Therefore, an improved quality of perovskite film can be obtained by inhibiting the formation of the perovskite-DMF complexes. 

In our initial study, we found that NMP can form a strong PbI2•NMP adduct (fig. S3). As proposed, if PbI2•NMP can remain in the perovskite precursor solution, then the nucleation will be dominated by the PbI2•NMP adduct. After the formation of the film, the FAI/CsI species are also homogeneously distributed in the film. It is very easy to induce the reaction of PbI2 and FAI/CsI in the film by thermal annealing. Thus, the film morphology will be well controlled. Then NMP with a molar ratio of 1:1 to PbI2 is added into the FA0.83Cs0.17PbI3/DMF solution. Similar studies are carried out, and we find that there are two types of nuclei (fig. S1ii). The nuclei that induce the growth of needle-shaped crystals have no obvious changes, but the length of the needle becomes a little shorter, indicating that the growth of the solventcoordinated perovskite complexes is suppressed. More importantly, a large number of the second type of nuclei form, growing into spherical particles. Through the in situ XRD (Fig. 1Bii), we find that the initial strong peaks of FA2Pb3I8•4DMF become weaker and the later-appearing PbI2•NMP peaks become stronger, leaving the final film consisting of FA2Pb3I8•4DMF and PbI2•NMP. The SEM image (Fig. 1Aii) also shows that there are two types of structures in the rough film: densely packed particles in the layered structure and some dendrite structures that originated from 

Thus, it is more preferable if a-(FACs)PbI3 is directly formed from the solution without a second phase transformation, which would suppress the formation of defects and traps during the d- to a-phase transition. From the above results, we can conclude that in the (FACs)PbI3 perovskite DMF solution, solventcoordinated perovskite intermediate phases of Cs2Pb3I8•4DMF and FA2Pb3I8•4DMF that later convert to d-(FACs)PbI3 are likely to form and thus result in poor morphology, as depicted in Fig. 1E. When NMP is added, the intermediate phases of Cs2Pb3I8•4DMF and FA2Pb3I8•4DMF are restrained by the competition of PbI2•NMP, resulting in the formation of a-(FACs)PbI3. To further improve the film quality, the intermediate phase of FA2Pb3I8•4DMF should be completely inhibited. By the further introduction of excess PbCl2 to the precursor solution, we find that the growth of the FA2Pb3I8•4DMF nuclei is further suppressed by the formation of an additional PbX2•0.5NMP•0.5DMF adduct, as shown in fig. S1iii, and the film becomes much denser (Fig. 1Aiii), more transparent, 

3 of 6 

Bu et al., Science 372, 1327–1332 (2021) 18 June 2021 

RESEARCH | REPORT 



and brown in color (fig. S5), indicating much faster nucleation of lead halide–NMP adducts and effective suppression of d-phase formation. Further evidence can be found from the in situ XRD patterns (Fig. 1Biii), which show the presence of a much lower peak of FA2Pb3I8•4DMF, and the SEM image of the spin-coated film, which shows negligible pores (Fig. 1Ciii). The related XRD patterns (Fig. 1Diii) of the spin-coated film show the presence of PbI2•NMP and PbX2•NMP/DMF complexes without FA2Pb3I8•4DMF. The XRD patterns (fig. S6) and SEM images (fig. S8) indicate that a relatively low volatilization rate of the precursor solution during the deposition (spin rate >3000 rpm) is sufficient to achieve dense perovskite films even without an antisolvent process. The annealing even at 

70°C could induce a stronger peak of a-(FACs) PbI3 phase. The additional peak belonging to PbI2 at 150°C is due to the added excess PbX2. The excess PbI2 is generally beneficial to the device because of the passivation effect (24). 

curves of PSCs are shown in fig. S9. The devices made from pure DMF-derived perovskite films exhibit a poor PCE of 7.64%, whereas the NMP-engineered perovskite devices show a much higher efficiency of greater than 20%. We further modulated the addition of PbCl2 and obtained mirror-like black films (fig. S5). The efficiencies are substantially improved when the amount of PbCl2 is increased to no more than 10% while the hysteresis continues to decrease. A champion efficiency of 21.92% is achieved by the addition of 10% PbCl2 (fig. S9). After further characterization of the crystal properties by XRD, UV-visible (UV-Vis) absorption spectroscopy, and SEM for perovskite films with different amounts of added PbCl2 (fig. S10), we found that the intrinsic reasons for the improved performance by introducing PbCl2 are the suppression of d-phase formation, the improvement of coverage with increased grain size, and the in situ formation of PbI2 at the grain boundary as a passivator (fig. S10) due to the substitution of I<sup>−</sup> or I<sup>−</sup> vacancies by Cl<sup>−</sup> to form a FA0.83Cs0.17PbI3−xClx perovskite (25, 26). 



To study the corresponding film’s device performance, we used a normal structure of FTO/SnO2/perovskite/spiro-OMeTAD/Au [FTO, fluorine-doped tin dioxide; spiro-OMeTAD, 2,2′,7,7′-tetrakis(N,N-di-p-methoxyphenyl-amine) 9,9′-spirobifluorene]. To facilitate industrial production, we adopted a two-step annealing process for perovskites, namely a 70°C annealing in the glovebox to dry the films followed by another 150°C annealing in air to promote crystal growth with the assistance of humidity. The champion current density–voltage (J-V) 



To further improve performance, we introduced a posttreatment of bromide-based large cation salt (isobutylamine bromide, iBABr) on the as-fabricated FA0.83Cs0.17PbI3−xClx [labeled as three-dimensional (3D) perovskite] surface to form a 3D/2D structured perovskite layer according to previous reports (27, 28) (fig. S11), which would contribute to stability improvement and open-circuit voltage (Voc)–loss reduction for the solar cells. The corresponding device structure is shown in Fig. 2A. An improved efficiency of 23.02% under reverse scan (RS) for the 3D/2D perovskite-based solar cells is achieved, with a Voc of 1.166 V, a short-circuit current density (Jsc) of 23.97 mA cm<sup>–2</sup> , and a fill factor (FF) of 0.824. A lower efficiency of 20.71% is achieved under forward scan (FS), with a Voc of 1.142 V, Jsc of 24.01 mA cm<sup>−2</sup> , and a FF of 0.755, respectively (Fig. 2B and table S1). An obvious hysteresis with a hysteresis index (HI) of 0.10 is still present. 

Hysteresis reflects the stability that is one of the major obstacles to the commercialization of PSCs (29). To eliminate the hysteresis and further improve the photovoltaic performance and stability, we used a potassium-based salt, KPF6, as an additive to the perovskite precursor solution. XRD, UV-Vis absorption spectroscopy, and SEM characterizations (fig. S12) confirm the incorporation of KPF6 to perovskites. The corresponding photovoltaic characteristics are shown in fig. S13. With the addition of KPF6, the hysteresis continues to decrease and the HI reaches 0.00 at a 5% additive concentration. To accurately evaluate the real PCE, steady-state power output (SPO) measurements were conducted. With a lower HI, the PCE from SPO becomes closer to the PCE from J-V scans. When the concentration 

Fig. 3. Thermal stability characterization. (A) Average PCE evolution of the unencapsulated devices measured over a 500-hour stability test at 85°C in ambient air (relative humidity ~15 ± 5%). The shaded regions represent the variation range of the PCE obtained from eight cells. (B) TOF-SIMS of Pb, P, and F ions in the FA0.83Cs0.17PbI3−xClx perovskite film with KPF6 additive on a Si substrate (measurement area 80 mm by 80 mm). (C and D) Cross-sectional SEM images of different devices: (C) fresh 3D/2D device before and after 360 hours of 85°C aging and (D) fresh 3D/2D-KPF6 device before and after 360 hours of 85°C aging. (E and F) TOF-SIMS spectra of (E) 3D/2D and (F) 3D/2D-KPF6 devices after 360 hours of 85°C aging. HTL, hole transport layer; ETL/FTO, electron transport layer/fluorine-doped tinoxide. 

4 of 6 

Bu et al., Science 372, 1327–1332 (2021) 18 June 2021 

RESEARCH | REPORT 



resulting in a small Voc loss of ~0.37 eV (fig. S17). This passivation strategy would be beneficial to stability. 



Figure 3A shows the thermal stability of widely researched CsFAMA triple-cation-based perovskite Cs0.05(FA0.85MA0.15)0.95Pb(I0.85Br0.15)3 and our MA-free perovskite (FA0.83Cs0.17PbI3)– based solar cells measured at 85°C in ambient air (15 ± 5% relative humidity). The efficiency of CsFAMA devices quickly decreases to 2.9 ± 3.1% within 360 hours. Obvious holes are observed from the cross-sectional SEM image because of the degradation of the CsFAMA device after aging at 85°C (fig. S18). Although the MA-free 3D/2D devices exhibit a considerable improvement and retain the black appearance, the devices still show a salient decrease after aging at 85°C for 500 hours, retaining less than 50% of the initial efficiency. However, this degradation can be substantially suppressed with the addition of KPF6. The 3D/2D-KPF6 devices exhibit ~80% of the initial efficiency after aging at 85°C for 500 hours. The J-V curves of different devices under the thermal stability measurements are plotted in fig. S19. There is a negligible change of FF in the device processed with KPF6, indicating the undamaged interfaces of devices. 

Fig. 4. Photovoltaic performance characterization of large-area modules. (A) Schematic illustration for the slot-die printing of perovskite films with low-pressure dry air blowing. The inset shows a photo of a printed 20-cm–by–20-cm perovskite film. (B) Champion J-V curves of the 5-cm–by–5-cm minimodules based on the antisolvent-free spin-coating method and slot-die printing method. The inset shows the schematic diagram of a six-subcell series-connected module. F, forward scan; R, reverse scan; P1, P2, and P3, three laser scribing steps. (C) Champion J-V curves of the 10-cm–by–10-cm minimodule using the largescale perovskite film fabricated by the slot-die printing method. (D) Champion efficiencies of PSCs as a function of the area from this work and recent representative reports (9, 11, 20, 25, 34–36). 

This substantial improvement in stability can be ascribed to the PF6−-induced complex in perovskite films. The complex stays on the surface, passivating the grain boundaries, as seen from the SEM images (fig. S12C). In addition, to unravel the distribution of the PF6− complex across the perovskite layer, we conducted time-of-flight secondary-ion mass spectrometry (TOF-SIMS) for 1.5 mol % KPF6– contained FA0.83Cs0.17PbI3−xClx perovskite film (Fig. 3B). A block-by-block distribution of the agglomerated PF6− ions is shown in the 3D visualization images. The corresponding depth profiles of TOF-SIMS and x-ray photoelectron spectroscopy also show detected signals of K and F elements throughout the perovskite films (fig. S20, A to C). In addition, Fourier transform infrared spectra show that the N–H and P–F corresponding peaks shift to lower wave numbers with the increasing amount of KPF6 additives, revealing the presence of the hydrogen bonding between perovskite and PF6− (fig. S20, D to F). Thus, the PF6− additives would greatly affect both the perovskite grain boundary and the interfacial properties of the devices, contributing to better performance by passivating the surface defects. 

cessed with or without KPF6 additives are shown in fig. S15. Ultraviolet photoemission spectroscopy (UPS) and UV-Vis absorption spectroscopy (fig. S16) characterizations reveal the lifted conduction band minimum from −4.14 eV for 3D perovskite to −4.10 eV for 3D/ 2D perovskite, and further to −3.94 eV for 3D/ 2D-KPF6 perovskite, which contributes to the enhanced Voc of the modified devices. 

is above 0.5%, the hysteresis is actually almost negligible. A champion efficiency is obtained with the addition of 1.5 mol % KPF6 salts (labeled as 3D/2D-KPF6), showing a higher Voc of 1.178 V, a Jsc of 24.03 mA cm<sup>−2</sup> , a FF of 0.825, and a PCE of 23.35% under RS, and a Voc of 1.175 V, a Jsc of 24.06 mA cm<sup>−2</sup> , a FF of 0.818, and a PCE of 23.13% under FS. The average PCE of 23.24% is very close to the PCE from SPO of 23.2%, which is much higher than the control device (21.9%) (fig. S14A). It is not surprising to see that further addition of KPF6 decreases the PCE, although there is no hysteresis, because too much KPF6 will affect the nucleation behavior and lead to poorer film morphology (fig. S12C). The corresponding external quantum efficiency spectra show an integrated Jsc of 23.70 and 23.78 mA cm<sup>−2</sup> for devices with and without KPF6, respectively (fig. S14B), which match well with the measured Jsc. In addition, PSCs that are 1.0 cm<sup>2</sup> in size also exhibit substantial improvements in PCE, increasing from 21.92% (RS) and 19.31% (FS) to 22.53% (RS) and 22.27% (FS) with the addition of KPF6 (Fig. 2C and table S2). The distribution of J-V parameters for both small-area and 1.0-cm<sup>2</sup> -sized cells pro- 

We further used the space charge–limited current (SCLC) measurements to characterize the trap density of these different films (30–32). The calculated defect density decreases from 6.17 × 10<sup>15</sup> to 4.97 × 10<sup>15</sup> cm<sup>−3</sup> , indicating the reduced defects of the perovskite film with the addition of KPF6 (Fig. 2D). Time-resolved confocal photoluminescence (PL) microscopy measurements were also performed to characterize the charge carrier properties of these perovskite films in microsize (10 mm by 10 mm) (Fig. 2, E and F). The blue region with a short PL lifetime for the pristine 3D/2D perovskite transits to a green region with a much longer PL lifetime after the addition of KPF6. It indicates a reduced trap-induced or nonradiative recombination by the defect passivation due to the addition of KPF6, thus 

The corresponding cross-sectional SEM images of the thermally aged devices with or without KPF6 additives are shown in Fig. 3, C and D. We found that there is no obvious change of the perovskite/spiro-OMeTAD interface with the KPF6 additive, whereas the interface becomes intersected without the KPF6 additive. We further used TOF-SIMS characterization to probe the thermally aged devices and fresh devices (Fig. 3, E and F, and fig. S21). 

5 of 6 

Bu et al., Science 372, 1327–1332 (2021) 18 June 2021 

RESEARCH | REPORT 



efficiencies greater than 20.4% (table S3). Certified efficiencies of 19.3 and 18.9% with a mask area of 17.1 cm<sup>2</sup> are achieved, respectively, for the slot die–printed and spin-coated PSMs (figs. S26 and S27). The hysteresis-suppression effect of KPF6 is also proven in large solar modules, which exhibit a very stable efficiency (fig. S28, A and B). We also achieved a champion FF of 0.806 for a 4-cm–by–4-cm solar module (mask area of 10.0 cm<sup>2</sup> ) (fig. S28C), which is the highest FF recorded among the reported PSMs. Furthermore, the solar module also shows excellent performance under weak light illumination and continuous multiple testing (fig. S28D). Our results indicate that the very high uniformity of large-area perovskite films that is achieved from this lead halide–templated crystallization strategy contributes to high-performance solar modules. 

In the device without KPF6, Cs, Pb, and I ions are shifted toward the spiro-OMeTAD layer. The Co ions that are a dopant in spiro-OMeTAD diffuse into the perovskite layer after thermal aging (Fig. 3E), matching well with the above SEM finding. With KPF6, the diffusion of ions is considerably suppressed (Fig. 3F). 





17. Y.-H. Lin et al., Science 369, 96–102 (2020). 

18. X. X. Gao et al., Adv. Mater. 32, e1905502 (2020). 

19. M. Jeong et al., Science 369, 1615–1620 (2020). 

20. M. Du et al., Adv. Mater. 32, e2004979 (2020). 

21. N. Ahn et al., J. Am. Chem. Soc. 137, 8696–8699 (2015). 

22. F. Guo et al., Adv. Funct. Mater. 29, 1900964 (2019). 

23. M. Saliba et al., Energy Environ. Sci. 9, 1989–1997 (2016). 

24. Q. Jiang et al., Nat. Energy 2, 16177 (2016). 

25. A. Ren et al., Joule 4, 1263–1277 (2020). 

26. M. I. Saidaminov et al., Nat. Energy 3, 648–654 (2018). 

We also measured the light illumination stability of the devices. The solar cells were continuously measured five times under 1 sun AM 1.5G solar illumination. A rapid degradation of Voc and FF for the 1.0-cm<sup>2</sup> 3D/2D PSC is observed, whereas the KPF6-modified device exhibits negligible degradation (fig. S22). The long-term light illumination stability was also characterized, as shown in fig. S23A. The champion device with KPF6 additives exhibits a better photostability than the pristine device, retaining 82% of its initial efficiency after 500 hours under continuous 1 sun AM 1.5G solar illumination without a UV filter, at an open-circuit condition that is harsher than the operating condition (33). A more stable statistic PCE evolution of the devices with KPF6 additive compared with the pristine devices is shown in fig. S23B. Therefore, the KPF6 additive plays an important role in improving the stability of perovskite devices as well. 

27. Y. Liu et al., Angew. Chem. Int. Ed. 59, 15688–15694 (2020). 

28. D. Luo et al., Science 360, 1442–1446 (2018). 

29. P. Liu, W. Wang, S. Liu, H. Yang, Z. Shao, Adv. Energy Mater. 9, 1803017 (2019). 

30. Z. Liu et al., Nat. Commun. 9, 3880 (2018). 

31. E. A. Duijnstee et al., ACS Energy Lett. 5, 376–384 (2020). 

32. J. Chen, S.-G. Kim, N.-G. Park, Adv. Mater. 30, e1801948 (2018). 

33. K. Domanski, E. A. Alharbi, A. Hagfeldt, M. Grätzel, W. Tress, Nat. Energy 3, 61–67 (2018). 

34. T. Bu et al., Solar RRL 4, 1900263 (2019). 

35. J. Li et al., Joule 4, 1035–1053 (2020). 

36. X. Dai et al., Adv. Energy Mater. 10, 1903108 (2019). 

We further scaled up the perovskite films to print a 10-cm–by–10-cm solar module with a series connection of 14 subcells and demonstrated a hysteresis-free solar module with high efficiency of 19.54% under RS and 19.22% under FS with a mask area of 65.0 cm<sup>2</sup> (Fig. 4C). The module efficiencies from different upscaling methods with different areas that were achieved in the past several years are summarized in Fig. 4D. The antisolvent-free modulated high-quality perovskite films in this work exhibit the highest efficiencies among all the reported works, indicating the high processability for achieving large-area high-quality perovskite films. 

#### ACKNOWLEDGMENTS 

Funding: This work is financially supported by the National Key Research and Development Plan (2019YFE0107200 and 2017YFE0131900), the National Natural Science Foundation of China (91963209 and 21875178), the Technological Innovation Key Project of Hubei Province (2018AAA048), and the Foshan Xianhu Laboratory of the Advanced Energy Science and Technology Guangdong Laboratory (XHD2020-001 and XHT2020-005). The Analytical and Testing Centre of Wuhan University of Technology and Hubei Key Laboratory of Low Dimensional Optoelectronic Material and Devices, Hubei University of Arts and Science, are acknowledged for the XRD and SEM characterizations. G.T., L.K.O., and Y.Q. acknowledge funding support from the Energy Materials and Surface Sciences Unit of the Okinawa Institute of Science and Technology Graduate University. Author contributions: F.H. and T.B. conceived the ideas and designed the experiments. Y.-B.C. provided helpful advice on the work. T.B. conducted the corresponding device and module fabrication and basic characterization. J.L., H.L., and C.T. helped with the module fabrication and encapsulation. J.L. and C.W. helped with the efficiency certification of modules. T.B. and J.S. conducted the DFT calculations. G.T. and L.K.O. helped with the XPS, UPS characterization, and analyses. Z.L. and N.C. helped with the stability test. J.C., J.L., J.Z., X.-L.Z., W.H., Y.Q., and Y.-B.C. provided valuable suggestions for the manuscript. F.H. and T.B. participated in all of the data analyses. F.H. and T.B. wrote the paper, and all authors revised the paper. Competing interests: None declared. Data and materials availability: All data needed to evaluate the conclusions in the paper are present in the paper or the supplementary materials. 

Just as the dense perovskite films can be easily prepared by spin-coating with the developed ink at a relatively low speed, similarly a moderate dry-air gas can also promote nucleation (fig. S24A). Thus, a gas-assist slot-die printing technology toward the continuous deposition of large-area perovskite films is developed here, as demonstrated in Fig. 4A. With a low pressure of ~0.3-MPa dry air blowing, the printed wet perovskite film quickly changes to a brown color with a mirror-like surface, as shown in movie S1. The inset in Fig. 4A shows a photograph of the printed large-area 20-cm–by–20-cm perovskite film. A pinhole-free high-quality perovskite layer with clear grain boundaries is shown in the SEM image (fig. S24B). 

#### REFERENCES AND NOTES 

1. National Renewable Energy Laboratory (NREL), Best research-cell efficiency chart (2021); www.nrel.gov/pv/ cell-efficiency.html. 

2. S. D. Stranks et al., Science 342, 341–344 (2013). 

3. D. Shi et al., Science 347, 519–522 (2015). 4. Q. Dong et al., Science 347, 967–970 (2015). 

5. F. Huang et al., Nano Energy 10, 10–18 (2014). 

6. M. Xiao et al., Angew. Chem. Int. Ed. 53, 9898–9903 (2014). 

7. Y. Y. Kim et al., Nat. Commun. 11, 5146 (2020). 

8. H. Chen et al., Nature 550, 92–95 (2017). 

9. Y. Deng et al., Sci. Adv. 5, eaax7537 (2019). 

10. Z. Xu et al., J. Mater. Chem. A Mater. Energy Sustain. 7, 26849–26857 (2019). 

#### SUPPLEMENTARY MATERIALS 

The 5-cm–by–5-cm PSMs are then fabricated, and the J-V curves are shown in Fig. 4B. The inset shows the schematic diagram of a sixsubcell series-connected 5-cm–by–5-cm module, and fig. S25 shows its photo. The slot die– printed PSM shows comparable performance to the spin-coated counterpart (Fig. 4B), with 

science.sciencemag.org/content/372/6548/1327/suppl/DC1 Materials and Methods Figs. S1 to S28 Tables S1 to S4 References (37–43) Movie S1 16 February 2021; accepted 6 May 2021 10.1126/science.abh1035 

11. Y. Deng et al., Nat. Energy 3, 560–566 (2018). 

12. C. Li et al., J. Am. Chem. Soc. 141, 6345–6351 (2019). 

13. J. Ding et al., Joule 3, 402–416 (2019). 

14. B. Conings et al., Adv. Energy Mater. 5, 1500477 (2015). 

15. E. J. Juarez-Perez et al., J. Mater. Chem. A Mater. Energy Sustain. 6, 9604–9612 (2018). 

16. S.-H. Turren-Cruz, A. Hagfeldt, M. Saliba, Science 362, 449–453 (2018). 

6 of 6 

Bu et al., Science 372, 1327–1332 (2021) 18 June 2021 



## **Lead halide–templated crystallization of methylamine-free perovskite for efficient photovoltaic modules** 

Tongle Bu, Jing Li, Hengyi Li, Congcong Tian, Jie Su, Guoqing Tong, Luis K. Ono, Chao Wang, Zhipeng Lin, Nianyao Chai, Xiao-Li Zhang, Jingjing Chang, Jianfeng Lu, Jie Zhong, Wenchao Huang, Yabing Qi, Yi-Bing Cheng, and Fuzhi Huang 

_Science_ **372** (6548), .  DOI: 10.1126/science.abh1035 

### **Suppressing nucleation over large areas** 

Although formamidinium-based lead iodide (PbI2) perovskites have a favorable bandgap and good thermal stability, the difficulty in controlling nucleation makes it difficult to grow high-quality, large-area films compared with methylammonium counterparts. Bu _et al._ show that adding _N_ -methyl-2-pyrrolidone to the perovskite precursors forms an adduct with PbI2 that promotes the formation of the desired black #-phase at room temperature. The addition of potassium hexafluorophosphate eliminated hysteresis by passivating interfacial defects and promoted long-term thermal stability at 85°C in unencapsulated devices. Large-area modules (17 square centimeters) achieved power conversion efficiencies of 20.4%. 

_Science_ , abh1035, this issue p. 1327 

**View the article online** https://www.science.org/doi/10.1126/science.abh1035 **Permissions** 

https://www.science.org/help/reprints-and-permissions 

Use of this article is subject to the Terms of service 

_Science_ (ISSN 1095-9203) is published by the American Association for the Advancement of Science. 1200 New York Avenue NW, Washington, DC 20005. The title _Science_ is a registered trademark of AAAS. 

Copyright © 2021 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works 

