# Field-free superconducting diode effect in noncentrosymmetric superconductor/ferromagnet multilayers

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Nanotechnology |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 193 |
| 作者 | H. Narita, J. Ishizuka, R. Kawarazaki, D. Kan, Y. Shiota, T. Moriyama, Y. Shimakawa, A. Ognev et al. |
| DOI | 10.1038/s41565-022-01159-4 |
| 源文件 | 044_Narita_2022_Field-free-superconducting-diode-effect-in-nonce.pdf |

---
# **Field-free superconducting diode effect** 

# **in noncentrosymmetric superconductor/ferromagnet multilayers** 

Hideki Narita<sup>1</sup> *, Jun Ishizuka<sup>2</sup> , Ryo Kawarazaki<sup>1</sup> , Daisuke Kan<sup>1,3</sup> , 

Yoichi Shiota<sup>1,3</sup> , Takahiro Moriyama<sup>1,3</sup> , Yuichi Shimakawa<sup>1,3</sup> , Alexey V. 

Ognev<sup>4</sup> , Alexander S. Samardak<sup>4</sup> , Youichi Yanase<sup>5, 6</sup> and Teruo Ono<sup>1,3,4,7</sup> * 

1 Institute for Chemical Research, Kyoto University, Gokasho, Uji, Kyoto, 611- 

0011, Japan. 

2Institute for Theoretical Physics, ETH Zurich, 8093 Zurich, Switzerland 

3 Center for Spintronics Research Network, Institute for Chemical Research, 

Kyoto University, Gokasho, Uji, Kyoto, 611-0011, Japan. 

4 Laboratory of Spin-Orbitronics, Institute of High Technologies and Advanced 

Materials, Far Eastern Federal University, Vladivostok 690950, Russia 

5 Department of Physics, Graduate School of Science, Kyoto University, Kyoto, 

606-8502, Japan 

6 Institute for Molecular Science, Okazaki, 444-8585, Japan 

7 Center for Spintronics Research Network, Graduate School of Engineering 

Science, Osaka University, Machikaneyama 1-3, Toyonaka, Osaka 560-8531, Japan 

- Correspondence: E-mail: narita.hideki.3x@kyoto-u.ac.jp (Hideki Narita); <u>ono@scl.kyoto-u.ac.jp (Teruo Ono)</u> 

1 

**The diode effect is fundamental to electronic devices and is widely used in rectifiers and AC–DC converters. At low temperatures, however, conventional semiconductor diodes possess a high resistivity, which yields energy loss and heating during operation. The superconducting diode effect (SDE)**<sup>**1-8**</sup> **, which relies on broken inversion symmetry in a superconductor may mitigate this obstacle: in one direction a zero-resistance supercurrent can flow through the diode, but for the opposite direction of current flow, the device enters the normal state with ohmic resistance. The application of a magnetic field can induce SDE in Nb/V/Ta superlattices with a polar structure**<sup>**1,2**</sup> **, in superconducting devices with asymmetric patterning of pinning centres**<sup>**9**</sup> **, or in superconductor/ferromagnet hybrid devices with induced vortices**<sup>**10,11**</sup> **. The need for an external magnetic field limits their practical application. Recently, a field-free SDE was observed in a NbSe2/Nb3Br8/NbSe2 junction, and it originates from asymmetric Josephson tunneling that is induced by the Nb3Br8 barrier and the associated NbSe2/Nb3Br8 interfaces**<sup>**12**</sup> **. Here, we present another implementation of zero-field SDE using noncentrosymmetric [Nb/V/Co/V/Ta]20 multilayers. The magnetic layers provide the necessary symmetry breaking and we can tune the SDE by adjusting the structural parameters, such as the constituent elements, film thickness, stacking order, and number of repetitions. We control the polarity of the SDE through the magnetization direction of the ferromagnetic layers. Artificially stacked structures**<sup>**13-18**</sup> **, as the one used in this work, are of particular interest as they are compatible with microfabrication techniques and can be integrated with devices such as Josephson junctions**<sup>**19-22**</sup> **. Energy-loss-free SDEs as presented in this work may therefore enable novel non-volatile memories and logic circuits with ultralow power consumption.** 

2 

In this regard, we fabricated noncentrosymmetric ferromagnet/superconductor multilayers [Nb (4.5 nm)/V (4.5 nm)/Co (1.7 nm)/V (4.5 nm)/Ta (4.5 nm)]20 by replacing the V layers in Nb/V/Ta superlattices<sup>1,2,23,24</sup> with symmetric V/Co/V units to control the Rashba superconductor<sup>25</sup> by magnetization. The crystalline structure of the multilayers was characterized by low- and high-angle X-ray diffraction (XRD) profiles (see Methods and Supplementary Fig. S1). Figure 1a shows a schematic of the measurement configuration, wherein the magnetic field, electrical current, and polar axis are perpendicular to each other. Figure 1b shows a photomicrograph of the device with the polar axis along the _z_ -direction. Electric current and magnetic field were applied along the _y_ - and _x_ -directions, respectively. 

Figure 1c shows the temperature dependence of the resistivity of the device at an electrical current density of 0.455 kA/cm<sup>2</sup> under various magnetic fields ranging from 0 to 0.5 T. 

The superconducting transition temperature, _T_ c (the temperature at which the resistivity drops to half of that above the transition), of the device was determined to be 2.6 K in the absence of a magnetic field. The _T_ c of the present device is lower than that of the previously studied [Nb (1nm)/V (1 nm)/Ta (1 nm)]40 device<sup>1</sup> . This is possibly due to the pair-breaking effect of the Co layers<sup>16</sup> and/or the difference in the repetition number (see Supplementary Fig. S2). 

Furthermore, vortices were observed to start breaking the superconducting phase with increasing magnetic field, and the superconducting phase completely disappeared above 0.5 T at the lowest measurement temperature of 1.9 K. The superconducting coherence length ξ(0) was estimated to be 24 nm (see Supplementary Fig. S3). The magnetization curves of the multilayers at different temperatures in Fig. 1d show the 

3 

characteristic ferromagnetic responses with a coercive field of 0.065 T in the multilayers above and below the _T_ c. 

Figure 1e presents the magnetic field dependences of the resistivity at several electrical current densities evaluated at 1.9 K. We observed switching between normal and superconducting states, similar to that observed in previous studies<sup>13,14</sup> . This is caused by the interplay between superconductivity and ferromagnetism. Previous reports have suggested that the switching between the normal and superconducting states is due to the internal exchange field at the superconductor/ferromagnet interface<sup>13,14</sup> . In our experiments, the switching between the normal and superconducting states was observed in the current density range of 0.455–20.45 kA/cm<sup>2</sup> . Because of the suppression of superconductivity by the external magnetic fields, the electrical resistivity increases monotonically with the magnetic fields at a low current density of 0.455 kA/cm<sup>2</sup> . 

As the current density increases, the hysteresis of magnetoresistance becomes more pronounced, and the conventional magnetoresistance of Co is observed above 22.72 kA/cm<sup>2</sup> , where the superconductivity is completely destroyed. The observation of the conventional magnetoresistance of Co also indicates that the device fabrication process does not alter the ferromagnetic properties of the multilayers. 

Figures 2a and 2b show the resistivity as a function of the current density, _J_ , under various magnetic fields for positive and negative currents at 1.9 K. We observed the SDE in our noncentrosymmetric superconductor/ferromagnet multilayers; the critical current density _J_ c (the current density at which the resistivity increases to half of that above the transition) depends on the polarity of the current. Note that _J_ c is determined by the transition from the superconducting state to the normal conductive state. Therefore, there is no influence from the Joule heating. The variation in _J_ c with the magnetic field at 1.9 

4 

K is shown in Fig. 2c. In these _J_ c measurements, the magnetic field was initially set to +0.5 T, which is sufficiently large to saturate the magnetization, determined from the results in Fig. 1c. Subsequently, _J_ c was measured by sweeping the magnetic field in the order of +0.5, 0, −0.5, 0, +0.5 T. _J_ c also exhibits hysteresis, reflecting the magnetic hysteresis of the Co layer. _J_ c shows a symmetric behavior with respect to zero field (dashed line) for the sweep of the magnetic field in the order of −0.5, 0, +0.5, 0 T. The pronounced peak around the coercive field can be attributed to enhanced vortex pinning on the network of proliferating domain walls<sup>26</sup> . 

Figure 2d shows the magnetic field dependences of the nonreciprocal components of the critical current densities,  _J_ c = |+ _J_ c| − |− _J_ c|, at different temperatures (+ _J_ c and − _J_ c are the critical current densities corresponding to positive and negative currents, respectively). Here, the magnetic field was initially set to +0.5 T. Then,  _J_ c was measured by sweeping the magnetic field in the order of +0.5, 0, −0.5, 0, +0.5 T. In the downward sweep from the magnetic field of +0.5 T at 1.9 K (black dots), a negative peak of  _J_ c appears at approximately +0.008 T, and  _J_ c approaches zero at 0 T. As the magnetic field decreases further, large negative and positive peaks of  _J_ c appear at approximately −0.008 and −0.04 T, respectively.  _J_ c then gradually decreases to zero at around −0.5 T. After saturating the magnetization at −0.5 T,  _J_ c was measured again by sweeping the magnetic field in the order of −0.5, 0, +0.5 T. Moreover, the magnetic field dependence of  _J_ c in the upward sweep shows a trend (red dots) opposite to that of the downward sweep (black dots). The microscopic origin of the observed peaks and dip structures in the magnetic field dependence of  _J_ c is not clear. However, it is possibly related to the evolution of complex magnetic domains. We also checked the reproducibilities of _J_ c and 

5 

 _J_ c in additional two devices (see Supplementary Fig. S4), and we observed that there was no clear hysteresis of  _J_ c in the configurations of **_B_** // **_x_** and **_B_** // **_z_** (see Supplementary Fig. S5).  This hysteresis behavior of  _J_ c for **_B_** // **_y_** is in clear contrast with the SDE observed in Nb/V/Ta superlattices<sup>1</sup> , wherein no hysteresis is observed. Note that the symmetric [Nb/V/Co/V/Nb]20 multilayers without a polar structure do not exhibit the clear nonreciprocal components of the critical current densities even though they exhibit hysteresis in the magnetization curves (see Supplementary Fig. S6). Therefore, the polar structure is essential to realize the magnetization-mediated SDE. 

The polarity control of SDE in a zero field is essential to develop non-volatile devices based on SDEs. We demonstrate it using the minor hysteresis loops of the magnetization. Figure 3a shows the magnetic field dependences of _J_ c for positive and negative currents in minor hysteresis loops. For this, the magnetic field was swept in the order of +0.5, 0, −0.15 T (downward sweep) and then −0.15, 0, +0.15 T (upward sweep). The limiting field of the minor loops is 0.15 T, as shown by the dashed line in Fig. 1d. Owing to the asymmetrical magnetic field sweeping, _J_ c shows asymmetry with respect to the zero field (dashed line). Consequently, we observe the positive  _J_ c in the zero-field after sweeping the magnetic field in the order of +0.5, 0, −0.15, 0 T, as shown in Fig. 3b. Moreover, _J_ c also shows asymmetry with respect to zero field after sweeping the magnetic field in the order of −0.5, 0, +0.15, 0 T, resulting in a negative  _J_ c under the zero-field condition, as shown in Figs. 3c and 3d, respectively. Therefore, we could control the polarity of SDE by magnetization. 

Here, we demonstrate the non-volatile SDE. The red and black dots in Fig. 3e represent the resistivities measured with _J_ = 72.7 kA/cm<sup>2</sup> at 1.9 K for negative (− **_M_** ) and positive magnetizations (+ **_M_** ), respectively. The − **_M_** (+ **_M_** ) is the state after sweeping the 

6 

magnetic field in the order of +0.5, 0, −0.15, 0 T (−0.5, 0, +0.15, 0 T). The device exhibits a superconducting state or a normal conducting state depending on the polarity of the current, and the polarity of SDE depends on the direction of magnetization. 

Finally, we discuss theoretical viewpoints in detail. We performed firstprinciples band structure calculation in the nonmagnetic electronic state for a [Nb/V/Co/V/Ta] supercell, where two atomic layers of bcc-Nb, V, Co, V, and Ta were repeatedly stacked, as shown in  Figs. 4a and b. The Rashba splitting of bands at the Fermi energy _E_ F was observed as _E_ R = 1–10 meV, which is close to the value of a [Nb/V/Ta] superlattice. Although the Rashba splitting of Co bands was minor (~ 1 meV), the density of states due to the Co bands near _E_ F was predominantly larger than that due to the Nb, V, and Ta bands, as shown in Fig. 4b. To gain more insight, we also performed a spin-polarized band structure calculation with the magnetization direction (010) and obtained a ferromagnetic ground state, where the total energy was lower than the nonmagnetic state, as shown in Figs. 4c and d. The magnitude of magnetic moment | _M_ | at Co atoms was calculated as | _M_ | = 1.93  B. The V atoms adjacent to Co atoms had a considerable magnetization | _M_ | = 0.5–1  B, while others had only | _M_ | = 0.01–0.05  B. Thus, the atoms that are not adjacent to Co atoms can stabilize the superconductivity against the Pauli depairing effect due to the ferromagnetic spin polarization. We indeed noticed that the partial densities of states are almost unchanged for Nb, V, and Ta atoms, and all atoms contribute at _E_ F in the ferromagnetic state, as shown in Fig. 4d. In other words, the superconducting transition temperature of this system may be determined from the total density of states consisting of three types of atoms. 

Pairing states that exhibit the diode effect would correspond to helical 

superconductivity, which has been investigated in noncentrosymmetric superconductors 

7 

such as CePt3Si<sup>27,28</sup> , the surface/interface of SrTiO3/LaAlO3<sup>29</sup> , and heavy-fermion superlattices<sup>30</sup> . The asymmetric band dispersion is essential for the helical superconductivity, and it appears in the noncentrosymmetric ferromagnet. Our spinpolarized band structure calculation indeed shows asymmetric behaviors (see Supplementary Fig. S7). The SDE has been analyzed by the Ginzburg-Landau (GL) theory and microscopic Hamiltonian<sup>3, 6-8</sup> . Higher-order gradient terms in the GL expansion exhibit the nonreciprocity of critical current, and the microscopic calculation predicts an anomalous “sign-reversal effect” in the helical superconducting state<sup>6</sup> . Thus, it is intriguing to clarify the asymmetric and sign-reversing behavior observed in Fig. 2d in future works. 

The experiments revealed that noncentrosymmetric superconductor/ferromagnet multilayers exhibited magnetization-mediated nonreciprocal critical currents, _i.e._ , a magnetization-mediated SDE. The field-free SDE demonstrated here enables rectification without an external magnetic field. However, significant issues still need to be overcome for practical application. The rectification still requires precise controls of the applied current and temperature, which are major limitations for practical device operation. Therefore, it is essential to explore materials with a larger  _J_ c and higher _T_ c to realize a wide temperature range of operation. The proposed method of symmetry breaking using artificial stacked structures is versatile and controllable. Furthermore, the electronic band structure can be controlled by modulating the thickness and period of each constituent layer, which offers a promising route for exploring new materials for practical application. Our findings pave the way for obtaining rewritable superconducting diode logic circuits using the nonvolatility of magnetic materials. 

8 

## **Acknowledgments** 

This work was partly supported by JSPS KAKENHI (Grant No. 15H05702, 15H05884, 15H05745, 18H04225, 18H01178, 18H05227, 19H05823, 20H05665, 21K13883 and 21K18145); the Cooperative Research Project Program of the Research Institute of Electrical Communication, Tohoku University; and the Collaborative Research Program of the Institute for Chemical Research, Kyoto University. This study was also supported by the Futaba Foundation's Futaba Research Grant Program, and Iketani Science and Technology Foundation. A. V. O, A. S. S. and T. O. acknowledge the Russian Ministry of Science and Higher Education for state support of scientific research conducted under the supervision of leading scientists in Russian institutions of higher education, scientific foundations and state research centers (Project No. 075-15-2021-607). 

## **Author contributions** 

H. N. and T. O. conceived the project. H. N. deposited the multilayers and fabricated the devices. H. N. performed the measurements and data analysis. H. N. and T. O. wrote the manuscript with the assistance of the other authors. J. I. and Y. Y. calculated the band structure and assisted with the analysis of the experimental results. All authors contributed jointly to the interpretation of the results. 

## **Competing Interests** 

The authors declare no competing financial interests. 

## **Figure Legends** 

**Fig. 1. Device structure, transport, magnetic properties, and SDE. a** , Schematic of the SDE and measurement configuration. The magnetic field is applied perpendicular to 

9 

both the polar axis and the electrical current. **b** , Photomicrograph of the device. The wires of the [Nb/V/Co/V/Ta]20 multilayers were electrically connected to the Au (100 nm)/Ti (5.0 nm) metal electrodes. **c** , Temperature dependence of the device resistivity at an electrical current density (0.455 kA/cm<sup>2</sup> ) in the multilayers under a magnetic field in the range of 0 to 0.5 T. **d** , Magnetization loops at several temperatures for the multilayers above and below _T_ c. **e** , Magnetic field dependence of the resistivity in the multilayers for several electrical current densities at 1.9 K. The direction of the magnetic field was perpendicular to the polar axis and the electrical current. 

**Fig. 2. Magnetic field and temperature dependences of SDE. a** , Current density ( _J_ ) dependence of the resistivity under various magnetic fields for positive and negative currents at 1.9 K. The magnetic field was swept from +0.5 T to −0.5 T (downward sweep). **b** , Dependence of the resistivity on _J_ under various magnetic fields for positive and negative currents at 1.9 K. The magnetic field was swept from −0.5 T to +0.5 T (upward sweep). **c** , _J_ c as a function of the magnetic field at 1.9 K. First, the magnetic hysteresis of _J_ c was measured from +0.5 to −0.5 T (downward sweep) for positive (red) and negative (black) currents. Subsequently, the sweep direction was reversed, and the magnetic field was swept from −0.5 to +0.5 T (upward sweep) for positive (blue) and negative (green) currents. The arrows indicate the sweep directions. **d** , Nonreciprocal component of the critical current density,  _J_ c, as a function of the magnetic field at various temperatures. The magnetic hysteresis of  _J_ c was measured from +0.5 to −0.5 T (downward sweep, black). Subsequently, the sweep direction was reversed, and the magnetic field was swept from −0.5 to +0.5 T (upward sweep, red). The arrows indicate the sweep direction. 

10 

**Fig. 3. Field-free SDE controlled by magnetization a** , Magnetic field dependences of _J_ c for positive and negative currents in minor hysteresis loops at 1.9 K. Magnetic field was swept in the order of +0.5, 0, −0.15 T (downward sweep) and then −0.15, 0, +0.15 T (upward sweep). **b** , Magnetic field dependence of  _J_ c in the minor hysteresis loops obtained by Fig. 3 **a** . **c** , Magnetic field dependences of _J_ c for positive and negative currents in minor hysteresis loops at 1.9 K. Magnetic field was swept in the order of −0.5, 0, +0.15 T (upward sweep), and then +0.15, 0, −0.15 T (downward sweep). **d** , Magnetic field dependence of  _J_ c in the minor hysteresis loops obtained by Fig. 3 **c** . **e** , Repeated application of current densities _J_ = 72.7 kA/cm<sup>2</sup> and _J_ = −72.7 kA/cm<sup>2</sup> at 1.9 K without a magnetic field. **f** , Non-volatile SDE at 1.9 K. Red and black dots represent the results for negative magnetization (- **_M_** ) and positive magnetization (+ **_M_** ), respectively. The device shows a superconducting state or normal conducting state depending on the polarity of the current. Note that the polarity of SDE depends on the direction of magnetization. The - **_M_** or + **_M_** state is achieved after sweeping the magnetic field in the order of +0.5, 0, −0.15, 0 T or −0.5, 0, +0.15, 0 T. 

## **Fig. 4. Band structure of a bulk [Nb/V/Co/V/Ta] superlattice** 

**a** , Band structure obtained from first-principles calculation for paramagnetic state. **b** , Partial density of states for paramagnetic state. **c** , Band structure for ferromagnetic state. **d** , Partial density of states for ferromagnetic state. 

11 

## **References** 

1. Ando, F. _et al_ . Observation of superconducting diode effect. _Nature_ **584** (7821), 373–376 (2020). 10.1038/s41586-020-2590-4 

2. Miyasaka, Y. _et al._ Observation of nonreciprocal superconducting critical field. _Appl. Phys. Express_ **14** (7), 073003 (2021). 10.35848/1882-0786/ac03c0 

3. Wakatsuki, R. _et al_ . Nonreciprocal charge transport in noncentrosymmetric superconductors. _Sci. Adv._ **3** (4), e1602390 (2017). 10.1126/sciadv.1602390 

4. Yasuda, K. _et al_ . Nonreciprocal charge transport at topological insulator/superconductor interface. _Nat. Commun._ **10** (1), 2734 (2019). 10.1038/s41467- <u>019-10658-3</u> 

5. Itahashi, Y. M. _et al_ . Nonreciprocal transport in gate-induced polar superconductor SrTiO3. _Sci. Adv._ **6** , eaay9120 (2020). 10.1126/sciadv.aay9120 

6. Daido, A., Ikeda, Y. & Yanase, Y. Intrinsic superconducting diode effect. _Phys. Rev. Lett_ . **128** , 037001 (2022). 10.1103/PhysRevLett.128.037001 

7. Yuan, N. F. Q. & Fu, L. Supercurrent diode effect and finite momentum superconductors. PNAS **119** , e2119548119 (2022). 10.1073/pnas.2119548119 

8. He, J. J., Tanaka, Y. & Nagaosa, N. A phenomenological theory of superconductor diodes.  New J. Phys. **24** `,` 053014 (2022). <u>10.1088/13672630/ac6766/meta</u> 

9. Lyu, Y. -Y. _et al_ . Superconducting diode effect via conformal-mapped nanoholes. _Nat. Commun._ **12** , 2703 (2021). 10.1038/s41467-021-23077-0 

12 

10. Aladyshkin A. Yu., Fritzsche, J. & Moshchalkov, V. V., Planar superconductor/ferromagnet hybrids: Anisotropy of resistivity induced by magnetic templates, _Appl. Phys. Lett._ **94** , 222503 (2009). 10.1063/1.3149698 

11. Aladyshkin A. Yu., _et al_ . Reverse-domain superconductivity in superconductorferromagnet hybrids: Effect of a vortex-free channel on the symmetry of 𝐼-𝑉 

characteristics, _Appl. Phys. Lett._ **97** , 052501 (2010). 10.1063/1.3474622 

12. Wu, H. _et al._ The field-free Josephson diode in a van der Waals heterostructure. Nature **604** , 653–656 (2022). s41586-022-04504-8 

13. Zhu, Y., Pal, A., Blamire, M. G. & Barber, Z. H. Superconducting exchange coupling between ferromagnets. _Nat. Mater._ **16** (2), 195–199 (2017). 10.1038/nmat4753 

14. Li, B. _et al._ Superconducting spin switch with infinite magnetoresistance induced by an internal exchange field. _Phys. Rev. Lett._ **110** (9), 097001 (2013). <u>10.1103/PhysRevLett.110.097001</u> 

15. Baek, B., Rippard, W. H., Benz, S. P., Russek, S. E. & Dresselhaus, P. D. Hybrid superconducting-magnetic memory device using competing order parameters. _Nat. Commun._ **5** , 3888 (2014). 10.1038/ncomms4888 

16. Obi, Y., Ikebe, M., Wakou, H. & Fujimori. H. Superconducting transition temperature and dimensional crossover in Nb/Co and V/Co multilayers. _J. Phys. Soc. Jpn_ **68** , 2750–2754 (1991). 10.1143/JPSJ.68.2750 

13 

17. Monton, C., de la Cruz, F. & Guimpel, J. Magnetic behavior of superconductor/ferromagnet superlattices. _Phys. Rev. B_ **75** (6) 064508 (2007). <u>10.1103/PhysRevB.75.064508, 064508</u> 

18. Banerjee, N. _et al_ ., Controlling the superconducting transition by spin-orbit coupling. _Phys. Rev. B_ **97** (8), 184521 (2018). 10.1103/PhysRevB.97.184521 

19. Misaki, K. & Nagaosa, N. Theory of the nonreciprocal Josephson effect. _Phys. Rev. B_ **103** (24) 245302 (2021). 10.1103/PhysRevB.103.245302 

20. Baumgartner, C. _et al._ A Josephson junction supercurrent diode. _Nat. Nanotechnol_ . **17** , 39–44 (2022). 10.1038/s41565-021-01009-9 

21. Davydova, M., Prembabu, S., Fu, L. Universal Josephson diode effect Preprint at ArXiv:2201.00831 (2022). 

22. Bauriedl, L. _et al_ ., Supercurrent diode effect and magnetochiral anisotropy in fewlayer NbSe2. Preprint at ArXiv:2110.15752v2 (2022). 

23. Ando, F. _et al_ . Fabrication of noncentrosymmetric Nb/V/Ta superlattice and its superconductivity. _J. Magn. Soc. Jpn_ **43** (2), 17–20 (2019). 10.3379/msjmag.1903L001 

24. Ando, F. _et al_ . Investigation of the upper critical field in artificially engineered Nb/V/Ta superlattices. _Jpn. J. Appl. Phys._ **60** (6), 060902 (2021). <u>10.35848/13474065/abfdc1</u> 

25. Wakatsuki, R. & Nagaosa, N. Nonreciprocal current in noncentrosymmetric Rashba superconductors. _Phys. Rev. Lett._ **121** (2), 026601 (2018). 

<u>10.1103/PhysRevLett.121.026601</u> 

14 

26.    Curran, P. J. _et al_ . Continuously tunable critical current in superconductorferromagnet multilayers. _Appl. Phys. Lett._ **110** (26) (2017). 10.1063/1.4989693, 262601 

27.    Baur, E. _et al_ . Heavy Fermion Superconductivity and Magnetic Order in Noncentrosymmetric CePt3Si. _Phys. Rev. Lett._ **92** (4) 027003 (2004). <u>10.1103/PhysRevLett.92.027003</u> 

28.    Kaur, R. P., Agterberg, D. F., and Sigrist, M., Helical Vortex Phase in the Noncentrosymmetric CePt3Si. _Phys. Rev. Lett_ . **94** (4), 137002 (2005). 

29.    Reyren, N. _et al_ . Superconducting interfaces between insulating oxides. Science **317** , 1196–1199 (2007).  10.1126/science.1146006 

30.    Naritsuka, M. _et al_ . Extremely strong-coupling superconductivity in artificial twodimensional Kondo lattices. _Phys. Rev. B._ **96** , 174512 (2017). 

<u>10.1103/PhysRevB.96.174512</u> 

## **METHODS** 

## **Device fabrication** 

The [Nb/V/Co/V/Ta]20 multilayers were grown on MgO (100) substrates by direct current (DC) magnetron sputtering in a high-vacuum system with a base pressure of approximately 5 × 10<sup>−6</sup> Pa. Before the film growth, the MgO (100) substrate was heated at 600 °C for 30 min in a sputtering chamber to remove impurities. Subsequently, the MgO substrate was heated to 300 °C during the deposition. All the films were deposited 

under an Ar pressure of approximately 0.1 Pa. The Nb, V, Co, V, and Ta layers were repeatedly sputtered on the MgO substrate in the same sequence for 20 cycles. The 

15 

deposition rates were maintained constant at 0.36, 0.22, 0.45, and 0.18 Å/s for Nb, V, Ta, and Co, respectively. The total deposition time was approximately 5 h. After deposition, the films were then cooled from 300 to 30 °C. XRD was performed using a conventional 4-circle diffractometer (PANalytical, X’pert MRD) with Cu-K _α_ 1 radiation ( _λ_ = 0.154 nm). Supplementary Fig. S1a and b show the low- and high-angle XRD profiles of the multilayers, respectively. In this study, the thickness of the ferromagnetic layer was adjusted to realize ferromagnetic properties, and it was set to be sufficiently small to avoid the Bloch domain wall effect. 

The deposited films were then patterned into a wire (dimensions: 50 μm × 1000 μm × 0.44 μm) using conventional photolithography and Ar-ion milling. Finally, Au (100 nm)/Ti (5.0 nm) metal electrodes were electrically connected to the wire. The surface layer was removed through weak Ar-ion milling before the electrode deposition to create Ohmic contacts. 

## **Transport and magnetization measurements** 

During the transport measurements, the temperature and magnetic field were controlled using a commercial refrigerator (Quantum Design, Physical Property Measurement System) with DC applied using a current source (Yokogawa 7651). The voltage was measured using a four-terminal configuration with a nanovoltmeter (Keithley 2182A). 

The magnetization of the sample was studied under a magnetic field parallel to the film surface, using a superconducting quantum interference device magnetometer (Quantum Design MPMS3). Before starting the measurements, the magnetic field was reduced from 1.0 to 0 T using an oscillating field sequence to remove any trapped flux in 

16 

the superconducting magnet. Subsequently, the magnetic hysteresis loops of the zerofield-cooled magnetization were measured in the “DC and no overshoot” mode using film samples with dimensions of 7 mm × 2 mm. The magnetization of the MgO substrate was subtracted to determine the intrinsic magnetic properties of the multilayers with the field parallel to the surface. 

## **Details of band structure calculation** 

We conducted first-principles calculations for nonmagnetic and ferromagnetic states on a bulk [Nb/V/Co/V/Ta] superlattice. We adopted the full-potential linearized augmented plane wave+local orbitals method within the generalized gradient approximation in the WIEN2k package<sup>31, 32</sup> . A supercell was constructed with ten layers consisting of five two-layers of Nb, V, Co, V, and Ta atoms. We used the muffin-tin radius _R_ MT of 2.50 a.u., the maximum reciprocal lattice vector _K_ max as _R_ MT _K_ max = 8.0, and 21 × 21 × 4 _k_ -points sampling for self-consistent calculation. Figure S7 shows the band structures and the partial densities of states in nonmagnetic and ferromagnetic states. If we neglect the Co bands, the band structure is similar to that in the [Nb/V/Ta] superlattice. The partial densities of the states of Co show an exchange splitting, while they are almost unchanged for Nb, V, and Ta. Thus, Nb, V, and Ta layers form spinsplitting bands with weak magnetization. Therefore, it is verified that [Nb/V/Co/V/Ta] is a noncentrosymmetric superconductor that exhibits a SDE without a magnetic field. 

## **Data Availabillity** 

The data that support the findings of this study are available from the corresponding authors upon reasonable request. 

17 

## **Methods-only references** 

31.    Blaha, P., Schwarz, K., Madsen, G., Kvasnicka, D., Luitz, J., Laskowski, R., Tran, 

F., & Marks, L., WIEN2k: An Augmented Plane Wave+Local Orbitals Program for 

Calculating Crystal Properties (Karlheinz Schwarz, Techn. Universität, Wien, Austria, 2018). 

32.    Blaha, P., Schwarz, K., Tran, F., Laskowski, R., Madsen, G., & Marks, L., WIEN2k: An APW+lo program for calculating the properties of solids. J. Chem. Phys. 152, 074101 (2020). 10.1063/1.5143061 

18 



<!-- Start of picture text -->
Fig. 1<br>a b V Magnetic field<br>z<br>Co<br>V x y<br>Nb<br>Ta<br>V y<br>Co<br>V . x<br>Nb z<br>50<br>c d<br>e<br>Polar axis<br><!-- End of picture text -->







19 



<!-- Start of picture text -->
Fig. 2<br>a b<br>c<br>d<br><!-- End of picture text -->

20 



<!-- Start of picture text -->
Fig. 3<br>a c<br>b d<br>e<br>(e)<br>f<br><!-- End of picture text -->

21 

Fig. 4 



<!-- Start of picture text -->
a<br>c<br><!-- End of picture text -->



<!-- Start of picture text -->
b<br>d<br><!-- End of picture text -->

22 

# **Supplementary information** 

# **Field-free superconducting diode effect in noncentrosymmetric superconductor/ferromagnet multilayers** 

Hideki Narita<sup>1</sup> *, Jun Ishizuka<sup>2</sup> , Ryo Kawarazaki<sup>1</sup> , Daisuke Kan<sup>1,3</sup> , 

Yoichi Shiota<sup>1,3</sup> , Takahiro Moriyama<sup>1,3</sup> , Yuichi Shimakawa<sup>1,3</sup> , Alexey V. 

Ognev<sup>4</sup> , Alexander S. Samardak<sup>4</sup> , Youichi Yanase<sup>5, 6</sup> and Teruo Ono<sup>1,3,4,7</sup> * 

1 Institute for Chemical Research, Kyoto University, Gokasho, Uji, Kyoto, 611- 

0011, Japan. 

2Institute for Theoretical Physics, ETH Zurich, 8093 Zurich, Switzerland 

3 Center for Spintronics Research Network, Institute for Chemical Research, 

Kyoto University, Gokasho, Uji, Kyoto, 611-0011, Japan. 

4 Laboratory of Spin-Orbitronics, Institute of High Technologies and Advanced 

Materials, Far Eastern Federal University, Vladivostok 690950, Russia 

5 Department of Physics, Graduate School of Science, Kyoto University, Kyoto, 

606-8502, Japan 

6 Institute for Molecular Science, Okazaki, 444-8585, Japan 

7 Center for Spintronics Research Network, Graduate School of Engineering Science, 

Osaka University, Machikaneyama 1-3, Toyonaka, Osaka 560-8531, Japan 

- Correspondence: E-mail: narita.hideki.3x@kyoto-u.ac.jp (Hideki Narita); 

<u>ono@scl.kyoto-u.ac.jp (Teruo Ono)</u> 

23 



<!-- Start of picture text -->
a b *<br>Ta(110) Nb(110) V()110 Co(111) Co(100) Ta(200) Nb(200) V()200<br><!-- End of picture text -->

**Fig. S1. Low- and high-angle XRD profiles. a** , Measured (black) and simulated (purple) low-angle XRD profiles of the [Nb/V/Co/V/Ta]20 multilayer. **b** , High-angle XRD profile of the multilayer. 

Figure S1a shows the design of the [Nb/V/Co/V/Ta]20 multilayer structure and its low-angle X-ray diffraction (XRD) profile. The measured curve was fitted as a function of the thickness and roughness of the Nb, V, Ta, and Co layers using the PANalytical X’Pert reflectivity program. Furthermore, the simulated curve reproduced the measured Bragg and Kiessing fringes. The calculated thicknesses of the Nb, V, Ta, and Co layers were approximately 4.5, 4.5, 4.5, and 1.7 nm, respectively, which did not precisely match the original design parameters of the multilayers [Nb (5 nm)/V (5 nm)/Co (2 nm)/V (5 nm)/Ta (5 nm)]20, because the mean value of the interfacial roughnesses obtained from the fit is approximately 1.0 nm. Co layers with a thickness of 1.7 nm can serve as pairbreaking layers, thus suppressing superconductivity and completely decoupling the Nb layers<sup>1</sup> . 

24 

Supplementary Fig. S1b shows the high-angle XRD profile around the (200) MgO reflection for the multilayers. The dotted lines in the figure represent the  positions  f the reflections expected from the constituent layers of the multilayer structure. 

The peak at  ≈ 38° corresponds to the overlapped (110) peaks expected from bcc-Nb and bcc-Ta. However, distinguishing the expected peaks of the bcc-V and Co layers is difficult because of their overlap with the (200) MgO peak. In addition, the (200) peaks of the bcc-Nb, Ta, and V layers are not observed. Therefore, the fabricated multilayers mainly consist of layers with a bcc structure and are preferentially oriented along the (110) direction. The grain size was estimated to be 15 nm from the full-width at half-maximum of the (110) peak using the characteristic wavelength of the Cu-K _α_ 1 radiation, full-width at half-maximum = 0.0118 rad, _θ_ = 0.669 rad, and Scherrer constant _K_ = 0.89. 



**Fig. S2 Transport properties in [Nb (4.5 nm)/V (4.5 nm)/Co (1.7 nm)/V (4.5 nm)/Ta (4.5 nm)]10 multilayers.** Dependence of the resistivity of the device on the temperature with an electrical current density of 0.90 kA/cm<sup>2</sup> in the multilayers in the absence of a magnetic field. 

25 

The orbital limiting field 𝐵c2orb(the critical magnetic field at which the resistivity drops to half the value obtained above the transition) is given as 𝐵c2orb( _T_ ) = _Φ_ 0/2πξ2 ( _T_ ), where _Φ_ 0 = 2.07 × 10<sup>−15</sup> [T m<sup>2</sup> ] is the flux quantum. The superconducting coherence length was estimated from the temperature dependence of 𝐵c2. Note that, 𝐵c2orb(0) is usually calculated from the initial slope of the plot of 𝐵c2 versus temperature around the _T_ c using the Werthamer–Helfand–Hohenberg formula, which is expressed as, 𝐵c2orb(0) = −0.69𝑇c(𝑑𝐵c2/𝑑𝑇)𝑇c in the dirty limit<sup>2</sup> . As a result of linear fitting, we evaluated 𝐵c2orb(0) (~ 0.58 T) and the superconducting coherence length ξ(0) (~ 24 nm). 

The Pauli limit in a BCS superconductor can be estimated using the following equation: 𝐵c2Pauli(0) ~ 1.84 _T_ c [T]. We evaluated 𝐵c2Pauli(0) (~ 4.8 T) using _T_ c (~ 2.6 K) in the [Nb (4.5 nm)/V (4.5 nm)/Co (1.7 nm)/V (4.5 nm)/Ta (4.5 nm)]20 multilayers. 

Therefore, the out-of-plane upper critical field is determined by the orbital pair-breaking effect rather than the Pauli pair-breaking effect. 



<!-- Start of picture text -->
Experiment B  //  z<br>Fitting<br><!-- End of picture text -->

**Fig. S3 Temperature dependence of upper critical field** 𝐵c2 

𝐵c2 as a function of temperature at _J_ = 0.455 kA/cm<sup>2</sup> . 

26 



<!-- Start of picture text -->
a b<br><!-- End of picture text -->



<!-- Start of picture text -->
c d<br><!-- End of picture text -->

**Fig. S4 Reproducibilities of transport properties** 

**a** , **b** , _J_ c as a function of the magnetic field along the **_y_** axis at 1.9 K for other devices (DEV2 and DEV3) composed of asymmetric ferromagnet/superconductor [Nb (4.5 nm)/V (4.5 nm)/Co (1.7 nm)/V (4.5 nm)/Ta (4.5 nm)]20 multilayers. **c** , **d** , Nonreciprocal component of the critical current density,  _J_ c, as a function of the magnetic field at 1.9 K for DEV2 and DEV3. 

27 



<!-- Start of picture text -->
a b<br>c d<br><!-- End of picture text -->

**Fig. S5 Transport properties in the configurations of** **_B_ //** **_x_ and** **_B_ //** **_z._** 

**a** , _J_ c as a function of the magnetic field along the **_x_** -axis at 1.9 K. **b** , Nonreciprocal component of the critical current density,  _J_ c, as a function of magnetic field at 1.9 K for the asymmetric ferromagnet/superconductor [Nb (4.5 nm)/V (4.5 nm)/Co (1.7 nm)/V (4.5 nm)/Ta (4.5 nm)]20 multilayers. **c** _J_ c as a function of the magnetic field along the **_z_** -axis at 1.9 K. **d** Nonreciprocal component of the critical current density,  _J_ c, as a function of magnetic field at 1.9 K for the asymmetric ferromagnet/superconductor [Nb (4.5 nm)/V (4.5 nm)/Co (1.7 nm)/V (4.5 nm)/Ta (4.5 nm)]20 multilayers. 

28 



<!-- Start of picture text -->
a b<br><!-- End of picture text -->

**Fig. S6 Transport and magnetic properties in [Nb (4.5 nm)/V (4.5 nm)/Co (1.7 nm)/V (4.5 nm)/Nb (4.5 nm)]20 multilayers.** 

**a** , Nonreciprocal component of the critical current density,  _J_ c, as a function of 

magnetic field at 1.9 K in the symmetric ferromagnet/superconductor [Nb (4.5 nm)/V (4.5 nm)/Co (1.7 nm)/V (4.5 nm)/Nb (4.5 nm)]20 multilayers. **b** , Magnetization loops for the multilayers above and below the _T_ c. 

The [Nb (4.5 nm)/V (4.5 nm)/Co (1.7 nm)/V (4.5 nm)/Nb (4.5 nm)] multilayers, with _T_ c = 3.74 K, were grown on MgO (100) substrates using the same method as that used for depositing [Nb (4.5 nm `)` /V (4.5 nm)/Co (1.7 nm)/V (4.5 nm)/Ta (4.5 nm)]. The 

crystalline structure of the multilayers was characterized using XRD measurements. To measure  _J_ c, the multilayers were used to fabricate a device with the same dimensions as those shown in Fig. 1b in the main text. For the  _J_ c measurement, the magnetic field was initially set to +0.5 T. Then,  _J_ c was measured by sweeping the magnetic field in the order of +0.5, 0, −0.5, 0, and +0.5 T. 

29 



<!-- Start of picture text -->
a b<br><!-- End of picture text -->

**Fig. S7. Low-energy electron band structure of a bulk [Nb/V/Co/V/Ta]** 

**superlattice.** 

**a** , Low-energy electron band near the  point for paramagnetic state. **b** , Low-energy 

electron band near the  point for ferromagnetic state. The energy dispersion _E_ (- _kx_ , 0, 0) is shown in the dashed line as a guide for eyes. 

30 

## **References** 

1. Robinson, J. W., Piano, S., Burnell, G., Bell, C. & Blamire, M. G. Critical current oscillations in strong ferromagnetic pi junctions. _Phys. Rev. Lett._ **97** (17), 177003 (2006). <u>10.1103/PhysRevLett.97.177003</u> 

2. Werthamer, N. R., Helfand, E. & Hohenberg, P. C. Temperature and purity dependence of the superconducting critical field, _H_ c2. III. Electron spin and spin-orbit effects. _Phys. Rev_ . **147** , 295–302 (1966). 10.1103/PhysRev.147.295 

31 

