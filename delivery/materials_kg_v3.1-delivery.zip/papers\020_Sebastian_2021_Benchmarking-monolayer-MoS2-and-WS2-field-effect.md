# Benchmarking monolayer MoS2 and WS2 field-effect transistors

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Communications |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 465 |
| 作者 | Amritanand Sebastian, Rahul Pendurthi, T. Choudhury, J. Redwing, Saptarshi Das |
| DOI | 10.1038/s41467-020-20732-w |
| 源文件 | 020_Sebastian_2021_Benchmarking-monolayer-MoS2-and-WS2-field-effect.pdf |

---


## ARTICLE 



> https://doi.org/10.1038/s41467-020-20732-w **OPEN** 

# Benchmarking monolayer MoS2 and WS2 field-effect transistors 

Amritanand Sebastian 1, Rahul Pendurthi1, Tanushree H. Choudhury2, Joan M. Redwing2,3,4 & Saptarshi Das 1,3,4✉ 

Here we benchmark device-to-device variation in field-effect transistors (FETs) based on monolayer MoS2 and WS2 films grown using metal-organic chemical vapor deposition process. Our study involves 230 MoS2 FETs and 160 WS2 FETs with channel lengths ranging from 5 μm down to 100 nm. We use statistical measures to evaluate key FET performance indicators for benchmarking these two-dimensional (2D) transition metal dichalcogenide (TMD) monolayers against existing literature as well as ultra-thin body Si FETs. Our results show consistent performance of 2D FETs across 1 × 1 cm<sup>2</sup> chips owing to high quality and uniform growth of these TMDs followed by clean transfer onto device substrates. We are able to demonstrate record high carrier mobility of 33 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> in WS2 FETs, which is a 1.5X improvement compared to the best reported in the literature. Our experimental demonstrations confirm the technological viability of 2D FETs in future integrated circuits. 

> 1 Department of Engineering Science and Mechanics, Penn State University, University Park, PA 16802, USA. 2 2D Crystal Consortium-Materials Innovation Platform (2DCC-MIP), Penn State University, University Park, PA 16802, USA.<sup>3</sup> Department of Materials Science and Engineering, Penn State University, University Park, PA 16802, USA.<sup>4</sup> Materials Research Institute, Penn State University, University Park, PA 16802, USA.<sup>✉</sup> email: sud70@psu.edu 

1 

NATURE COMMUNICATIONS | (2021) 12:693 | https://doi.org/10.1038/s41467-020-20732-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-020-20732-w 

wo-dimensional (2D) semiconducting materials beyond graphene<sup>1,2</sup> are receiving increasing attention owing to Ttheir ultra-thin body nature that can mitigate detrimental short-channel effects in aggressively scaled devices through improved electrostatics, enabling them to replace or complement the aging Si technology<sup>3–5</sup> . Molybdenum disulfide (MoS2) and tungsten disulfide (WS2), belonging to the family of transition metal dichalcogenides (TMDs), have been studied extensively in this context. In fact, high performance MoS2 field-effect transistors (FETs) with a contact pitch of 70 nm and 42 nm have already been experimentally demonstrated<sup>6,7</sup> . Circuit level implementations of 2D FETs such as inverters, logic operators, ring oscillators, and radio-frequency devices have also been achieved<sup>8–12</sup> . Recently, a microprocessor based on MoS2 FETs was reported<sup>13</sup> . Additionally, 2D FETs have found applications in various emerging technologies such as sensors for internet of things, neuromorphic computing, biomimetic devices, valleytronics, straintronics, and optoelectronic devices<sup>14–21</sup> . While initial demonstrations of prototype devices relied on exfoliated flakes, the 2D community has rapidly transitioned towards the growth of large-area films to address manufacturing needs for any commercial applications. In this context, chemical vapor deposition (CVD)<sup>22,23</sup> and metal-organic CVD (MOCVD)<sup>7,24</sup> are the most promising techniques, enabling growth of high quality 2D materials with different thermal budgets on various substrates. In fact, there are several reports demonstrating high-performance FETs based on CVD and MOCVD grown monolayer MoS2 and WS2. However, most of these studies are based on one or only a few devices. 

To assess the potential of 2D materials for future very large scale integrated (VLSI) circuits, it is important to study the variation in key device parameters that determine the ON-state and OFF-state performance across a large number of devices. Unfortunately, there are only a few studies that report device-todevice variation in 2D FETs<sup>7,25,26</sup> . Smithe et al. measured multiple parameters across 200 MoS2 FETs and demonstrated low threshold voltage variation and low contact resistance on the order of 1 kΩ−μm<sup>25</sup> . Similarly. Xu et al. analyzed 380 top-gated MoS2 FETs and reported variation in threshold voltage and electron mobility<sup>26</sup> . However, both works concentrate on longer channel devices where the effects of contact resistance are not pronounced. In a separate study, Smithe et al.<sup>22</sup> measured scaled MoS2 FETs based on synthetic monolayers; however, they did not provide any statistics. Smets et al.<sup>7</sup> demonstrated the most significant study on scaling of CVD grown monolayer MoS2, wherein multiple devices with channel lengths ranging from 5 μm down to 29 nm were measured. However, their study was focused on the OFF-state performance. Finally, all of the aforementioned studies are based on MoS2 FETs, and none exist for WS2 FETs. 

This work focuses on a comprehensive study of variation in key parameters related to both OFF-state and ON-state performance, such as threshold voltage, subthreshold slope, ratio of maximum to minimum current, field-effect carrier mobility, contact resistance, drive-current, and carrier saturation velocity, for different channel lengths ranging from 5 μm down to 100 nm using 230 MoS2 FETs and 160 WS2 FETs. In addition, we offer extensive benchmarking of our devices with respect to the abovementioned demonstrations as well as ultra-thin body (UTB) silicon (Si) on insulator (SOI) FETs with similar gate lengths to assess the technological viability and maturity of 2D FETs. Using statistical measures such as mean, median, standard deviation, and minimum/maximum values, we show low device-to-device variation. We are also able to demonstrate record high carrier mobility of 33 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> in WS2 FETs, which is a 1.5X improvement compared to the best reported in the literature. We 

attribute our accomplishments to the epitaxial growth of highly crystalline 2D monolayers on sapphire substrate via MOCVD technique at 1000 °C using chalcogen and sulfur precursors that minimize carbon contamination in the film, as well as to the clean transfer of the film from the growth substrate to the device fabrication substrate. 

### Results 

Synthesis and characterization of monolayer MoS2 and WS2. MoS2 and WS2 were deposited by MOCVD on epi-ready 2″ diameter c-plane sapphire wafers. Figure 1 summarizes the growth, structural, and optical characterization of the MOCVD grown MoS2 and WS2. Figure 1a shows the schematic of the MOCVD system, comprising of a cold-wall horizontal reactor with an inductively heated graphite susceptor equipped with wafer rotation as previously described<sup>27</sup> . Molybdenum hexacarbonyl (Mo(CO)6) and tungsten hexacarbonyl (W(CO)6) were used as metal precursors, while hydrogen sulfide (H2S) was the chalcogen source with H2 as the carrier gas. MoS2 was deposited in a single step process at 1000 °C, where coalesced monolayer growth across the 2″ wafer was achieved in 18 min. WS2 was deposited using a multi-step process with nucleation at 850 °C and lateral growth at 1000 °C, resulting in coalesced monolayer growth across the 2″ wafer in 10 min<sup>28</sup> . In both cases, after growth the substrate was cooled in H2S to 300 °C to inhibit decomposition of the MoS2 and WS2 films. Figure 1b shows uniformly grown MoS2 and WS2 films over 2″ sapphire wafers. Further growth details can be found in the “Methods” section. The morphology of the monolayer films at the center and edge of the 2″ wafer is shown in Fig. 1c, d for MoS2 and WS2, respectively, using atomic force microscopy (AFM). Height profiles obtained from scratch testing confirm monolayer film formation (see Supplementary Fig. 1a, b). The monolayers are fully coalesced, with undulations arising from steps on the sapphire surface. The overall bilayer density is low but a higher density of bilayers is present at the center of the MoS2 film compared to the WS2 film. The in-plane X-ray diffraction (XRD) patterns in Fig. 1e, f highlight the epitaxial relation between the sulfide monolayers and the underlying sapphire substrates. The fullwidth at half maxima of the ϕ-scan peaks are 0.3° and 0.17° for MoS2 and WS2, respectively, indicating a low rotational misorientation of domains within the monolayers. The films were transferred to Al2O3/Pt/TiN/p<sup>++</sup> -Si substrates for device fabrication, as discussed later. The transferred film quality was assessed using Raman maps as shown in Fig. 1g, h, and photoluminescence (PL) maps as shown in Fig. 1i, j, for MoS2 and WS2, respectively. Raman maps show less than 5% variation in the representative A1g peak position. The uniform PL peak positions observed at 1.84 eV for MoS2 and 1.97 eV for WS2 correspond to their monolayer response. Representative Raman and PL spectra are included in the Supplementary Fig. 1c–f. 

Monolayer MoS2 and WS2 device fabrication and characterization. To investigate the electrical properties of the MOCVD grown TMD films, back-gated FETs were fabricated on Al2O3/Pt/ TiN/p<sup>++</sup> -Si substrates. 50 nm Al2O3 gate dielectric was deposited using atomic layer deposition (ALD). The choice of a thin, high-k gate dielectric with an effective oxide thickness (EOT) of 22 nm, compared to conventionally used 300 nm SiO2, was to allow for better gate electrostatics. The Pt/TiN/ p<sup>++</sup> -Si stack acts as the gate electrode (see “Methods” section for more details on gate dielectric fabrication) for each substrate. The TMD films were transferred from sapphire (growth substrates) onto the Al2O3 substrates via the poly(methyl methacrylate) (PMMA)-assisted wet-transfer process<sup>29</sup> , as shown in Fig. 2a (see “Methods” section 

2 

NATURE COMMUNICATIONS | (2021) 12:693 | https://doi.org/10.1038/s41467-020-20732-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-020-20732-w 



Fig. 1 Monolayer film growth and characterization. a Schematic of the MOCVD system with a cold-wall horizontal reactor. b 2″ sapphire wafer with MOCVD grown MoS2 and WS2. AFM images of c MoS2 and d WS2 at the center and edge of the respective wafers. Towards the center of the MoS2 film, few bilayers are seen. In-plane XRD ϕ-scan of e MoS2 and f WS2 on sapphire (α-Al2O3), showing the epitaxial relationship between the monolayers and the sapphire substrate. Raman map of the A1g peak position for g MoS2 and h WS2 films transferred from the growth substrate onto the device fabrication substrate with 50 nm ALD Al2O3. Low variation in the peak position is observed for both MoS2 and WS2 with an average of ≈403.5 cm<sup>−1</sup> and ≈417 cm<sup>−1</sup> , respectively. PL peak map of i MoS2 with an average of ≈1.85 eV and j WS2 with an average of ≈1.97 eV, confirm monolayer films. PL is a characteristic of monolayer film owing to indirect to direct bandgap transition. 

for more details on transfer of monolayer films). Following transfer, electron beam (e-beam) lithography and dry etching using SF6 plasma were used to isolate the channel area of each device. Next, transmission line measurement (TLM) structures were defined using another set of e-beam exposures. Finally, e- beam evaporation was performed to sequentially deposit 40 nm Ni and 30 nm Au to serve as the contacts for the FETs (see “Methods” section for more details on device fabrication). The TLM structures were designed to have channel lengths (LCH) of 100 nm, 200 nm, 300 nm, 400 nm, 500 nm, 1 μm, 2 μm, 3 μm, 4 μm, and 5 μm, while the channel width (W) was kept constant at 5 μm. Figure 2b, c, respectively, show the schematic and scanning electron microscope (SEM) image of the fabricated TLM structures. Figure 2d–g show the transfer characteristics, i.e., drain current (IDS) versus gate voltage (VGS), for different drain voltages (VDS) in linear and logarithmic scales for representative longest-channel length (LCH = 5 μm) and shortest-channel length (LCH = 100 nm) FETs, for both MoS2 and WS2. Strong n-type conduction is observed due to Fermi-level pinning of the contact metal close to the conduction band of both MoS2 and WS2<sup>30</sup> . Figure 2h–k show the corresponding output characteristics, i.e., IDS versus VDS, for different VGS. Measurement protocols are described in the “Methods” section. 

Device-to-device variation in monolayer MoS2 and WS2 FETs. To understand the variation in the FET performance across the entire 1 × 1 cm<sup>2</sup> substrates, as well as to study of the impact of channel length scaling on FET performance, 230 MoS2 FETs (23 TLM structures) and 160 WS2 FETs (16 TLM structures) were 

measured. Figure 3a, b display the transfer characteristics of all measured MoS2 and WS2 FETs, respectively, for different LCH, which were used to extract key device parameters. For each parameter, the mean, median, standard deviation, minimum, and maximum values are reported. Finally, median values are used for benchmarking since they reflect the central tendency, even in the presence of outliers in the data, and offer higher accuracy in case of skewed distributions. Devices with the best number for a given parameter are termed as “champion” devices. 

Threshold voltage. Threshold voltage is extracted using three different methods: linear extrapolation (Vtlin ), Y-function (VtY ), and constant-current method (Vtcc ). Supplementary Fig. 2a–c describes the extraction of Vtlin , VtY , and Vtcc , Supplementary Fig. 2d, e show their corresponding median values as a function of LCH, and Supplementary Fig. 2f, g show their distributions across all devices for MoS2 and WS2, respectively. Supplementary Note 1 and Supplementary Table 1 summarize the device-to-device variations. It was found that the threshold voltage is independent of the channel length for both MoS2 and WS2 FETs. Figure 4a, b show the distributions of Vtlin for all measured MoS2 and WS2 FETs, respectively. Median Vtlin of 2.9 V with a standard deviation of σVt = 0.8 V is obtained for MoS2, and median Vtlin of 6.4 V with a σVt = 0.8 V is obtained for WS2. Threshold voltage was found to be more positive for WS2 FETs compared to MoS2 FETs, which can be attributed to higher intrinsic n-type doping of MoS2 either due to the specific nature of the impurity present in the MOCVD grown MoS2 film or due to surface charge transfer induced 

3 

NATURE COMMUNICATIONS | (2021) 12:693 | https://doi.org/10.1038/s41467-020-20732-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-020-20732-w 



Fig. 2 Device fabrication and electrical measurements. a Schematic representation of PMMA-assisted wet transfer of monolayer TMD films from sapphire (growth substrate) to an Al2O3 substrate. b Schematic representation and c SEM of a TLM structure defined using e-beam lithography. TLM structures with channel length (LCH) from 100 nm to 5 μm are fabricated and the channel width is defined to be 5 μm. Transfer characteristics, i.e., drain current (IDS) versus gate voltage (VGS), for different drain voltages (VDS) in logarithmic and linear scale for d longest-channel (LCH = 5 μm) and e shortestchannel (LCH = 100 nm) MoS2 field-effect transistors (FETs), and f longest-channel (LCH = 5 μm) and g shortest-channel (LCH = 100 nm) WS2 FETs. Corresponding output characteristics, i.e., IDS versus VDS, for different VGS for h longest-channel and i shortest-channel MoS2 FETs, and j longest-channel and k shortest-channel WS2 FETs. 

doping due to the underlying ALD grown Al2O3. This charge transfer is accredited to the higher conduction band offset between MoS2 and Al2O3 compared to WS2 and Al2O3<sup>31</sup> . 

Variation in threshold voltage is widely used for benchmarking emerging devices based on novel materials<sup>25</sup> . Note that median Vtlin depends on the work function of the gate metal and unintentional/intrinsic doping of the 2D material and that both Vtlin and σVt depend on the thickness of the gate oxide. Hence for a fair comparison we use SσVt , which is defined as the projected threshold voltage variation at a scaled effective oxide thickness (SEOT) obtained using Eq. (1). We use SEOT = 0.9 nm for comparison with other literature results. 



<!-- Start of picture text -->
SEOT<br>SσVt ¼ σVt EOT ð1Þ<br><!-- End of picture text -->

This equation assumes linear scaling of variation in threshold voltage with respect to the EOT. However, for ultra-scaled devices, deviation from the linear scaling can be expected due to increased effect of metal-gate granularity<sup>32</sup> . For our MoS2 and WS2 FETs, we project SσVt = 33 mV, which is similar to the value projected for CVD grown monolayer MoS2 FETs reported by Smithe et al.<sup>25</sup> . We also employed this method to other reports on top-gated and wafer-scale monolayer MoS2 FETs and extracted SσVt = 45 mV for<sup>26</sup> and SσVt = 11 mV for<sup>12</sup> , respectively. Recently, Smets et al.<sup>7</sup> have demonstrated σVt = 44 mV for an EOT of 1.9 nm that would correspond to SσVt = 20 mV for monolayer MoS2 FETs with channel lengths scaled down to 

30 nm. These results are compared with the state-of-the-art UTB SOI and Si FinFET (Table 1). Channel dimensions are included in Table 1 since σVt has been found to be inversely proportional to the channel area in ultra-scaled devices which is shown using Pelgrom plots<sup>32,33</sup> . However, we did not observe such a trend due to relatively large channel areas in our MoS2 and WS2 FETs. It is encouraging that monolayer 2D FETs show SσVt comparable to the state-of-the art Si FETs in spite of an order of magnitude smaller body thickness. Note that UTB Si FETs are expected to encounter challenges associated with the precise thickness control, random dopant fluctuations, and detrimental quantum confinement effects beyond 5 nm body thickness<sup>34,35</sup> , which are unlikely for 2D monolayers. At the same time further improvement in threshold voltage variation can be achieved for 2D FETs through optimization of the monolayer growth and improvement in the fabrication process flow (see Supplementary Note 2 for further discussion). Hence, 2D materials offer an alternative for the realization of UTB MOSFETs. The exhibition of low deviceto-device variation in this work, which can be attributed to uniform and contaminant-free MOCVD growth of monolayer TMDs and clean device fabrication process can accelerate the incorporation of 2D FETs in future VLSI technologies. 

Subthreshold slope. Subthreshold slope (SS) is extracted over 1 (SS1), 2 (SS2), 3 (SS3), and 4 (SS4) orders of magnitude change in IDS for MoS2 and WS2 FETs, respectively. Supplementary Fig. 3a, b show the median values for SS1, SS2, SS3, and SS4 as a function of LCH, and Supplementary Fig. 3c, d show the distributions for 

4 

NATURE COMMUNICATIONS | (2021) 12:693 | https://doi.org/10.1038/s41467-020-20732-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-020-20732-w 



Fig. 3 Statistics of scaled devices. A total of 230 MoS2 FETs and 160 WS2 FETs were fabricated using 23 and 16 TLM structures with channel lengths ranging from LCH = 100 nm to LCH = 5 μm for a MoS2 and b WS2, respectively, to analyze the device-to-device variation and impact of scaling on the device performance. The corresponding transfer characteristics, i.e., IDS versus VGS, for VDS of 1 V are shown in the logarithmic scale. 



Fig. 4 Variation in OFF-state performance. Histograms showing the variation in threshold voltage extracted using linear extrapolation (Vt,lin) for a MoS2 and b WS2 FETs. The median values for these extracted threshold voltages were found to be more positive for WS2 FETs compared to MoS2 FETs due to higher intrinsic n-type doping of MoS2. Histograms of SS extracted across 4 orders of magnitude change in the drain current (SS4) for c MoS2 and d WS2 FETs. The deviation of SS from the ideal 60 mV.dec<sup>−1</sup> corresponds to the presence of interface traps. Histograms of interface trap density (DIT) for e MoS2 and f WS2 FETs calculated from SS4. Histograms of maximum to minimum current ratio (Imax/Imin) for g MoS2 and h WS2 FETs. 

SS1 and SS4 for all MoS2 and WS2 devices, respectively. Supplementary Table 2 summarizes the device-to-device variation in SS. For a FET with ohmic contacts, it is expected that SS1 = SS2 = SS3 = SS4. However, for a Schottky barrier (SB) FET, the SS may increase when extracted for higher orders of magnitude change in 

IDS. A greater increase can be attributed to higher SB height at the metal/semiconductor interface, which not only limits the ONcurrent but also impacts the OFF-state performance. In the existing 2D FET literature there is a tendency to report SS value without mentioning the orders of magnitude change in IDS over 

5 

NATURE COMMUNICATIONS | (2021) 12:693 | https://doi.org/10.1038/s41467-020-20732-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-020-20732-w 

Table 1 Benchmarking device-to-device variation in threshold voltage. 

||σVtðVÞ|Gate dielectric|SσVtðVÞ at SEOT = 0.9 nm|Channel dimensions (µm)|
|---|---|---|---|---|
|25—MoS2|1.05|30 nm SiO2|33 × 10<sup>−3</sup>|W=11.6, LCH=4–8.6|
|26—MoS2 1 continuous layer|0.25|30 nm HfO2|45 × 10<sup>−3</sup>|W=–, LCH=30|
|26—MoS2 1 layer + ML|0.1|30 nm HfO2|19 × 10<sup>−3</sup>|W= –, LCH=30|
|12—MoS2|0.17|30 nm Al2O3|11 × 10<sup>−3</sup>|W=30, LCH=4|
|7—MoS2|44 × 10<sup>−3</sup>|4 nm HfO2|20 × 10<sup>−3</sup>|W=1, LCH=0.1|
|Our work-MoS2, WS2|0.8|50 nm Al2O3|33 × 10<sup>−3</sup>|W=5, LCH=0.1, 0.2, 0.3, 0.4, 0.5, 1, 2, 3, 4, 5|
|33—UTB SOI|24.5 × 10<sup>−3</sup>|EOT=1.65 nm|13 × 10<sup>−3</sup>|W=0.060, LCH=0.025|
|32—FinFET|10 × 10<sup>−3</sup>|EOT=0.8 nm|11 × 10<sup>−3</sup>|W=0.0075, LCH=0.034|



which it is evaluated. This leads to considerable discrepancy and unfair comparisons. In fact, most SS values are reported for only one or two orders of magnitude of the drain current, whereas circuit operations require at least four orders of magnitude ON/ OFF ratio to be technologically relevant. 

We found that the median SS values are independent of LCH for both MoS2 and WS2 FETs (Supplementary Fig. 3a, b). Fig. 4c, d show the distributions of SS4 for all measured MoS2 and WS2 FETs, respectively. A median SS4 of 431.9 mV.dec<sup>−1</sup> with a standard deviation of σSS = 138.1 mV.dec<sup>−1</sup> is obtained for MoS2, and a median SS4 of 541.4 mV.dec<sup>−1</sup> with a σSS = 41.8 mV.dec<sup>−1</sup> is obtained for WS2. The median SS4 values show slight increase from the corresponding median SS1 values of 327.1 mV.dec<sup>−1</sup> and 438.2 mV.dec<sup>−1</sup> for MoS2 and WS2, respectively (Supplementary Table 2). However, no significant difference is found in the standard deviation values for SS1 and SS4. Note that the “champion” MoS2 FET demonstrates SS1 = 93.3 mV.dec<sup>−1</sup> and SS4 = 166 mV.dec<sup>−1</sup> , and the “champion” WS2 FET demonstrates SS1 = 295.6 mV.dec<sup>−1</sup> and SS4 = 452.8 mV.dec<sup>−1</sup> . The deviation of SS from its ideal value of 60 mV.dec<sup>−1</sup> even for “champion” devices can be explained using Eq. (2). 



<!-- Start of picture text -->
mkBT CS CIT<br>SS ¼ lnð10Þ; m ¼ 1 þ þ ; CIT ¼ qDIT ð2Þ<br>q � COX COX�<br><!-- End of picture text -->

Here, kB is the Boltzmann constant, T is the temperature, q is the electronic charge, m is the body factor, CS is the semiconductor capacitance, CIT is the interface trap capacitance, COX is the oxide capacitance, and DIT is the interface trap density. For fully depleted UTB FETs such as monolayer MoS2 and WS2 FETs, CS = 0. In case of a clean oxide-semiconductor interface, CIT � COX, ensuring that m = 1 and SS = 60 mV.dec<sup>−1</sup> . Clearly, in our MoS2 and WS2 FETs, m > 1 indicates the presence of interface traps at the 2D/ dielectric interface (finite value of CIT). 

TMD/Al2O3 interface can be mitigated either by scaling the EOT (i.e., increasing COX)<sup>37</sup> or by improving the interface (i.e., reducing DIT). The presence of structural defects such as sulfur vacancies are known to introduce trap sites which contribute to DIT. It has been found that DIT can be reduced by various surface passivation techniques<sup>38,39</sup> . In addition, photoresist residue from the lithography and/or the wet transfer process can cause an increase in DIT. Therefore it is possible to reduce DIT through further optimization of growth, post-growth processing, and improvement in fabrication process flow. 

Current ON/OFF ratio. Fig. 4g, h show the distribution of the ratio of maximum to minimum current (Imax/Imin) across all MoS2 and WS2 FETs, respectively. Here, Imax is the maximum current obtained from the transfer characteristics for VDS = 1 V and Imin is the average noise floor. Note that the true device current in the OFF-state is beyond the measurement range of the instrument. See Supplementary Fig. 4a, b for the distribution of Imax and Imin, Supplementary Fig. 4c, d for the distribution of Imax/Imin for different LCH for MoS2 and WS2 FETs, and Supplementary Table 3 for a summary of device-to-device variation in Imax/Imin. The median and standard deviation for Imax/Imin were found to be 2.1 × 10<sup>7</sup> and 5.5 × 10<sup>7</sup> for MoS2 FETs and 2.1 × 10<sup>7</sup> and 2.6 × 10<sup>7</sup> for WS2 FETs. These values are over an order of magnitude higher than the Imax/Imin of 1.3 × 10<sup>6</sup> for UTB Si MOSFETs<sup>36</sup> . Imax/Imin is benchmarked against literature reports for LCH = 100 nm as shown in Supplementary Table 4. Note that the key OFF-state performance indicators, i.e., threshold voltage, SS, DIT, and Imax/Imin, are mostly found to be independent of LCH. Even for LCH = 100 nm, no detrimental short-channel effects are observed, which is expected and can be ascribed to the atomically thin body nature of monolayer TMDs, as well as the use of thin and high-k Al2O3 as the gate dielectric with EOT = 22 nm. 

Interface traps. To evaluate the quality of the interface, we have extracted DIT using Eq. (2) and the corresponding distributions are shown in Fig. 4e, f for MoS2 and WS2 FETs, respectively. Median DIT of 6.2 × 10<sup>12</sup> eV<sup>−1</sup> cm<sup>−2</sup> and 8 × 10<sup>12</sup> eV<sup>−1</sup> cm<sup>−2</sup> were obtained for MoS2 and WS2, respectively. The device-todevice variation in DIT is shown in Supplementary Table 2. For fully depleted UTB Si MOSFETs with 35 nm thick Si and 110 nm gate length, SS = 80 mV.dec<sup>−1</sup> for an EOT = 4 nm, which corresponds to a DIT = 1.5 × 10<sup>12</sup> eV<sup>−1</sup> cm<sup>−236</sup> . Note that, while the DIT values for our monolayer 2D FETs are comparable with stateof-the-art Si FETs, thicker EOT = 22 nm results in smaller COX and hence higher median values for the SS for MoS2 and WS2 FETs. For a fair comparison, we project the scaled-SS (SSS) for an EOT of 0.9 nm using the DIT. We found SSS to be 76 mV.dec<sup>−1</sup> and 80 mV.dec<sup>−1</sup> for MoS2 and WS2, respectively, and 64 mV.dec<sup>−1</sup> for the UTB Si MOSFET in ref.<sup>36</sup> . A similar exercise was performed for other reports on MoS2 FETs from the literature and the results are summarized in Table 2. The impact of higher DIT at the 

Field-effect mobility and contact resistance. Field-effect mobility (μFE) is an important device parameter that strongly influences the ON-state performance of a FET. While intrinsic mobility is a material related parameter, μFE is determined by extrinsic effects, such as contact resistance (Rc), and often depends on how it is extracted from the device characteristics. Three popular methods for extracting μFE are peak transconductance (μgm ), Y-function (μY)<sup>40</sup> , and TLM (μTLM) as described in Supplementary Note 3. Figure 5a, b, show the distribution and the corresponding median values for μgm as a function of LCH for MoS2 and WS2 FETs, respectively. Additionally, 25th and 75th percentile values of the distribution are also marked. Clearly, μgm shows a strong LCH dependence, with the median value varying from 23.9 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> to 3.6 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> for MoS2 and 29 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> to 2.7 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> for WS2 as the devices are scaled from LCH = 5 μm down to LCH = 100 nm. Supplementary Fig. 5a, b shows a similar analysis of μY for MoS2 and WS2 FETs, respectively and 

6 

NATURE COMMUNICATIONS | (2021) 12:693 | https://doi.org/10.1038/s41467-020-20732-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-020-20732-w 

Table 2 Benchmarking median subthreshold slope for LCH = 100 nm. 

||SS (mV.dec<sup>−1</sup>)|EOT (nm)|Gate dielectric|DIT (10<sup>12 </sup>eV<sup>−1 </sup>cm<sup>−2</sup>)|SSS (mV.dec<sup>−1</sup>) at SEOT=0.9 nm|
|---|---|---|---|---|---|
|7—MoS2|80|1.9|4 nm HfO2|3.7 × 10<sup>12</sup>|70|
|7—MoS2|160|2.7|8 nm HfO2|1.3 × 10<sup>13</sup>|93|
|7—MoS2|200|3.8|12 nm HfO2|1.3 × 10<sup>13</sup>|93|
|7—MoS2|1350|50|50 nm SiO2|9.2 × 10<sup>12</sup>|83|
|Our work-MoS2|450|22|50 nm Al2O3|6.3 × 10<sup>12</sup>|76|
|Our Work-WS2|550|22|50 nm Al2O3|8 × 10<sup>12</sup>|80|
|36—UTB SOI|80|4|4 nm SiO2|1.8 × 10<sup>12</sup>|64|





Fig. 5 Device-to-device variation in field-effect mobility and contact resistance. Distribution of mobility extracted using peak transconductance (μgm ) for different channel lengths for a MoS2 and b WS2 FETs. Median, 25th percentile, and 75th percentile is also denoted. Total resistance (RT) versus LCH for c MoS2 and d WS2 for different carrier concentrations (nS) extracted using a representative TLM structure. The distribution of contact resistance (Rc) across multiple TLM structures, extracted from the y-intercepts in c and d, as a function of nS for e MoS2 and f WS2, respectively. The relative contribution of Rc and channel resistance (Rch) to the total resistance for g MoS2 and h WS2 for different LCH. In scaled devices, as Rch scales with the channel length, the contribution of Rc (note that Rc is independent of LCH), i.e., 2Rc/RT, is more significant compared to Rch, i.e., Rch/RT. 

Supplementary Table 5 summarizes the device-to-device variation in μgm and μY. Both μgm and μY extracted from shorter-channel devices show significant reduction in their median values, indicating the dominant role of Rc in scaled 2D FETs<sup>6</sup> . The contact resistance is seen as a result of Fermi-level pinning at the metal/TMD contact interface, resulting in a finite SB height<sup>30</sup> . To investigate further, we used the TLM structure shown in Fig. 2c to extract Rc and evaluate its impact on LCH scaling as shown in Fig. 5c–f. We used Eq. (3) to extract Rc. 



<!-- Start of picture text -->
LCH LCH<br>RT ¼ 2Rc þ Rch; Rch ¼ ;<br>μTLMCOXðVGS � Vtlin Þ  ¼ qnSμTLM<br>ð3Þ<br>COXðVGS � Vtlin Þ<br>nS ¼<br>q<br><!-- End of picture text -->

Here, RT is the total measured resistance of the FET, and Rch is the channel resistance, which is directly proportional to LCH and inversely proportional to the carrier density (nS) when the FET is measured in the linear operation regime. However, Rc is independent of LCH and hence can be extracted from the y-intercept of RT versus LCH plots, as shown in Fig. 5c, d for MoS2 and WS2, respectively, for different nS<sup>41</sup> (see Supplementary Note 4 for further discussion on the extraction of nS). Figure 5e, f show the distribution of corresponding extracted Rc as a function of nS. A steady decrease in Rc with increasing nS is attributed to the 

phenomenon of contact-gating in global back-gated FET geometry, since the SB width at the metal/2D interface is modulated by the back-gate voltage<sup>30</sup> . Lower SB width allows for easier carrier tunneling, reducing Rc. For the MoS2 FET, the median Rc value was found to be 9.2 kΩ−μm, corresponding to nS = 1 × 10<sup>13</sup> cm<sup>−2</sup> . However, for WS2, nS was limited to 4.4 × 10<sup>12</sup> cm<sup>−2</sup> , owing to the more positive Vtlin , resulting in a higher median Rc = 29.2 kΩ−μm. For a case of identical carrier concentration, nS = 2.7 × 10<sup>12</sup> cm<sup>−2</sup> , similar median Rc values of 33 kΩ−μm and 39.4 kΩ−μm are obtained for MoS2 and WS2, respectively. The difference in Rc between MoS2 and WS2 can be explained from the fact that the charge neutrality level is closer to the conduction band for MoS2 than it is for WS2, resulting in a higher SB height at the Ni/WS2 contact interface compared to the Ni/MoS2 contact interface<sup>42</sup> . 

The relative effect of Rc is assessed for different LCH. Figure 5g, h show the contribution of Rc and Rch to the total resistance RT using stacked bar plots as a function of LCH for MoS2 and WS2, respectively. It is clear that for LCH ≤ 1 μm, the contact effects are significant since 2Rc > Rch. This explains why the extracted μgm is LCH dependent and is severely underestimated by more than 80% for both MoS2 and WS2 when extracted from scaled devices with LCH = 100 nm. Since μgm extraction is limited by Rc, extracting μTLM following Eq. (3) is more appropriate for short channel devices. Supplementary Fig. 5c, d show the distribution of μTLM 

7 

NATURE COMMUNICATIONS | (2021) 12:693 | https://doi.org/10.1038/s41467-020-20732-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-020-20732-w 

Table 3 Benchmarking ON-state performance at VDS = 1 V (best values are compared with median/mean values shown within parentheses). 

||μ(cm<sup>2 </sup>V<sup>−1 </sup>s<sup>−1</sup>)|Rc(kΩ−μm)|ION(μA.μm<sup>−1</sup>)|nS(cm<sup>−2</sup>)|
|---|---|---|---|---|
|25—MoS2|μgm =42 (34.2)|0.73 (1)|22, LCH=5.4μm|1.3 × 10<sup>13</sup>|
|22—MoS2|<br>μTLM=20|6.5|270, LCH=80 nm|1 × 10<sup>13</sup>|
|12—MoS2|μgm =80 (≈40)|2.4|13, LCH =4μm|6.6 × 10<sup>12</sup>|
|65—MoS2|<br>μTLM =30|1.7|260, LCH=10 nm|4.7 × 10<sup>13</sup>|
|7—MoS2|μTLM=15|1|250, LCH=29 nm|1.5 × 10<sup>13</sup>|
|26—MoS2|μ4-point≈75 (70)|14|–|–|
|Our work-MoS2|μTLM=47 (27)|3(9.2)|73 (54), LCH=100 nm|1 × 10<sup>13</sup>|
|64—WS2|μgm =11|–|25, LCH=4μm|2.1 × 10<sup>13</sup>|
|47—WS2|<br>μgm =20.4|–|0.6, LCH=1μm|2.5 × 10<sup>12</sup>|
|50—WS2|μgm =5|–|≈0.05, LCH=10μm|≈7.2 × 10<sup>12</sup>|
|50—WS2 (Graphene contact)|<br>μgm =50 (27)|–|≈1.1, LCH=10μm|≈7.2 × 10<sup>12</sup>|
|Our work-WS2|<br>μTLM=33 (16)|2.1 (29)|26 (17), LCH=100 nm|4.4 × 10<sup>12</sup>|
|51—UTB SOI|μ4-point=6|–|≈35 * 10<sup>−3</sup>, LCH=100μm|≈9 × 10<sup>12</sup>|



across MoS2 and WS2 TLM structures, respectively, and Supplementary Table 6 summarizes the variation across the different TLM structures. The extracted median value for μTLM was found to be 27 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> and 16 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> for MoS2 and WS2 FETs, respectively. Long channel devices are less vulnerable to Rc and corresponding μgm values are more accurate representations of intrinsic channel mobility, albeit with some challenges as described by Nasr et al.<sup>43</sup> . Nevertheless, our “champion” long-channel MoS2 and WS2 FETs with LCH = 5 μm demonstrated μgm = 30 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> and 33 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , respectively. Similarly, “champion” MoS2 and WS2 TLM structures demonstrated μTLM = 46 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> and 33 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , respectively. 

Table 3 shows the benchmarking of our “champion” devices with the best reports from the literature using μFE (μgm for longer channel devices and μTLM for shorter channel devices) and Rc for both MoS2 and WS2. We have also included median/mean values wherever applicable. Note that while higher μFE values have been reported based on “champion” exfoliated and CVD grown MoS2 FETs<sup>7,12,24,25,44–46</sup> , our report is statistically more significant as it demonstrates variation across multiple TLM structures. For WS2, μFE = 33 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> is the highest reported, 1.5X better than the previous report on synthetic WS2<sup>47</sup> . Higher μFE values reported for WS2 are either for exfoliated materials at room temperature<sup>48</sup> and low temperatures<sup>49</sup> , or for CVD grown materials with contact engineering via the use of multilayer graphene as interlayers<sup>50</sup> . More interestingly, UTB Si MOSFETs with 0.9 nm thick Si show μFE ≈ 6 cm<sup>2</sup> V<sup>−1</sup> s<sup>−151</sup> , which is more than 2 orders of magnitude smaller compared to bulk Si mobility and is primarily attributed to thickness fluctuation in UTB Si. 

Metal/2D contact resistances are comparatively high even for the “champion” devices with Rc = 3 kΩ−μm and Rc = 2.1 kΩ−μm for MoS2 and WS2, respectively, when compared to the Rc = 0.1 kΩ−μm typically reported for state-of-the-art Si FETs. However, various methods have been developed to reduce the effect of SB-limited carrier transport in 2D TMDs<sup>52</sup> , such as work function engineering to reduce the SB height<sup>30</sup> , introduction of interlayers such as graphene to decouple the metal/2D interface to alleviate Fermi-level pinning<sup>53,54</sup> , and achieving higher carrier concentration underneath or near the metal/2D contacts through substitutional or surface charge transfer doping to reduce the SB width<sup>42,55</sup> . Nevertheless, our MOCVD grown monolayer MoS2 FETs demonstrate Rc similar to values reported in the literature<sup>7,22,25,56</sup> . The “champion” devices are 

benchmarked in Table 3. To the best of our knowledge, this is the first report of Rc for synthetic WS2. Additionally, our work marks the first study on the extraction of contact resistance from multiple TLM structures for both MoS2 and WS2. Smithe et al.<sup>25</sup> have demonstrated a pseudo-TLM analysis where independent devices with different channel lengths and widths were used to extract the distribution of RT. TLM analysis is done on the devices between 10th and 90th percentile<sup>25</sup> . Our demonstration involves the extraction of contact resistance from separate TLM structures and finding the variation across these TLM structures, and the analysis is not limited to a percentile limit. 

Drive-current and saturation velocity. Finally, high performance FETs are benchmarked using the drive current (ION) that is achievable for a given supply voltage (VDS = VDD). Higher values of ION ensure faster circuit operation as the intrinsic delay of a FET is proportional to CVDD/ION, where C is the load capacitance. In digital electronics, higher ION allows larger fan-out. Figure 6a, b display the output characteristics of MoS2 and WS2 FETs, respectively, for different channel lengths, which were used to assess the ON-state performance of the devices. At high biases, high current density leads to self-heating, resulting in negative differential resistance (NDR) behavior. This is a common phenomenon seen in ultra-thin body FETs, including SOI FETs<sup>57</sup> , nanowire FETs<sup>58</sup> , graphene FETs<sup>59</sup> , and, more recently, exfoliated multilayer MoS2 FETs<sup>60</sup> and CVD grown monolayer MoS2 FETs<sup>61</sup> . It is possible to reduce or eliminate the self-heating effect through pulsed measurements with pulse widths less than 100 μs<sup>60</sup> . 

Figure 7a–d show the median for ION as a function of LCH for VDS = 1 V and VDS = 5 V for MoS2 and WS2 FETs, respectively, extracted from their respective output characteristics. For both TMDs, at low VDS = 1 V, i.e., in the linear region, ION is expected to demonstrate an inverse channel length dependence following Eq. (4). 



<!-- Start of picture text -->
ION IDS;LIN VDS<br>W ¼ W ¼ qnSμgm LCH ð4Þ<br><!-- End of picture text -->

This trend is observed for both MoS2 and WS2 FETs in Fig. 7a, b, respectively, for channel lengths LCH ≥ 1 μm. However, for devices with channel length LCH < 1 μm, the inverse channel length dependence is obscured by Rc. Similar linear dependence is observed for ION in longer-channel devices (LCH ≥ 1 μm) at 

8 

NATURE COMMUNICATIONS | (2021) 12:693 | https://doi.org/10.1038/s41467-020-20732-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-020-20732-w 



Fig. 6 ON-state performance of monolayer MoS2 and WS2 FETs. Output characteristics for channel lengths ranging from LCH = 100 nm to LCH = 5 μm, obtained from a representative transmission-line measurement structure for a MoS2 and b WS2 FETs. Current saturation is achieved in shorter-channel devices for both MoS2 and WS2 FETs. 



Fig. 7 Drive current and saturation velocity. Median of drive current (ION) as a function of 1/LCH for a MoS2 and b WS2 FETs at VDS of 1 V corresponding to the linear region of the FETs, and c MoS2 and d WS2 FETs at VDS of 5 V corresponding to the saturation region of the FETs. These are extracted at carrier concentrations (nS) of 1 × 10<sup>13</sup> cm<sup>−2</sup> and 4.4 × 10<sup>12</sup> cm<sup>−2</sup> for MoS2 and WS2, respectively. The saturation current (IDS,SAT) for e MoS2 and f WS2, extracted from their corresponding shorter-channel devices (LCH < 1 μm) as a function of nS. The slope indicates the saturation velocity (vSAT). The distribution of vSAT for g MoS2 and h WS2 shorter-channel FETs. 

VDS = 5 V for both MoS2 and WS2 FETs in Fig. 7c, d, respectively, following Eq. (5). 



<!-- Start of picture text -->
ION IDS;SAT ¼ COXμgm ðVGS � Vtlin Þ 2 ¼ q 2 μgm n 2 S ð5Þ<br>W ¼ W 2LCH COX 2LCH<br><!-- End of picture text -->

These results are in accordance with classic long-channel FET characteristics (i.e., at low drain bias, the device operates in the 

linear regime (Eq. (4)), whereas for VDS ≥ VGS � Vtlin , the channel is pinched-off, resulting in current saturation). The saturation current follows a square-law dependence on the overdrive voltage and, therefore, on nS (Eq. (6))<sup>62</sup> . In shorter-channel devices (LCH < 1 μm), as the lateral electric field (ξ � LVCHDS<sup>)becomesmore</sup> than the critical electric field (EC), the carrier velocity reaches 

9 

NATURE COMMUNICATIONS | (2021) 12:693 | https://doi.org/10.1038/s41467-020-20732-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-020-20732-w 

saturation velocity (vSAT). This leads to current saturation, with the saturation current being independent of LCH as described by Eq. (6)<sup>62</sup> . 



<!-- Start of picture text -->
ION IDS;SAT<br>W ¼ W ¼ COXvSAT�VGS � Vtlin � ¼ qnSvSAT ð6Þ<br><!-- End of picture text -->

However, in order to observe current saturation due to velocity saturation, the drain bias must meet the criterion given by Eq. (7). 



<!-- Start of picture text -->
vSAT qnS<br>LCH < VDS < VGS � Vtlin ¼ ð7Þ<br>μgm � COX�<br><!-- End of picture text -->

For example, as seen in Fig. 6, current saturation is achieved at VDS = 4 V for 100 nm MoS2 FET and WS2 FET, which is much lower than the corresponding VGS � Vtlin of 11.6 V and 6.7 V, respectively. This explains why the drive current in shorterchannel MoS2 and WS2 FETs display little-to-no channel length dependence for high drain bias (VDS = 5 V), as seen in Fig. 7c, d. Nevertheless, scaled MoS2 and WS2 FETs with channel lengths of 100 nm demonstrate high median drive currents of ION = 54 μA. μm<sup>−1</sup> and ION = 17 μA.μm<sup>−1</sup> , respectively, for VDS = 1 V and ION = 146 μA.μm<sup>−1</sup> and ION = 30 μA.μm<sup>−1</sup> , respectively, for VDS = 5 V. Furthermore, ION at VDS = 5 V can reach as high as 161 μA.μm<sup>−1</sup> and 53 μA.μm<sup>−1</sup> in “champion” MoS2 and WS2 FETs, respectively. The distribution of ION for VDS = 1 V and VDS = 5 V as a function of LCH is shown in Supplementary Fig. 6 and the corresponding device-to-device variation is summarized in Supplementary Table 7 for MoS2 and WS2 FETs. The higher drive current seen for MoS2 FETs compared to that of WS2 FETs is a direct consequence of lower Vtlin , which allows for higher nS in MoS2 channels. Further improvement in the drive current of scaled 2D FETs can be achieved by reducing Rc. Note that, while there are reports of higher ION in large-area grown MoS2 films, none of the earlier studies provide extensive device statistics<sup>22,63–65</sup> . ION for UTB Si MOSFET is 35 nA.μm<sup>−1</sup> for 0.9 nm thick Si<sup>51</sup> . The “champion” devices are benchmarked in Table 3. Supplementary Table 8 shows benchmarking of our statistical study on MoS2 FETs using field-effect mobility and drive current (at VDS = 2 V) with similar channel length dependent statistical studies from the literature. The mean and standard deviation is compared with the LCH dependence and plotted in Supplementary Fig. 7. Better performance is seen for our channel length dependence study compared to ref.<sup>66</sup> for both the drive current and mobility. 

Finally, saturation velocity (vSAT) is another key material parameter that determines ION in scaled FETs. This is because at low lateral electric field (ξ) the average electron drift velocity increases linearly through the mobility (vd ¼ μFEξ), but at large electric fields, which are easily achievable in sub-micron FETs, the carrier velocity saturates. Thus, ION becomes less dependent on μFE and is instead proportional to vSAT, following Eq. (6). Additionally, high vSAT is needed for faster switching<sup>11</sup> . Figure 7e–h show the extraction of vSAT and the distribution of vSAT for MoS2 and WS2, respectively. The linear dependence of the saturation current (IDS,SAT) on nS following Eq. (6), is used to extract vSAT. Median vSAT values of 6.4 × 10<sup>5</sup> cm.s<sup>−1</sup> and 4 × 10<sup>5</sup> cm.s<sup>−1</sup> and “champion” vSAT values of 1.1 × 10<sup>6</sup> cm.s<sup>−1</sup> and 6.9 × 10<sup>5</sup> cm.s<sup>−1</sup> are obtained for MoS2 and WS2, respectively. The corresponding device-to-device variations are summarized in Supplementary Table 9. The vSAT values are significantly lower compared to bulk Si with vSAT ≈ 10<sup>7</sup> cm.s<sup>−167,68</sup> . Nathawat et al. have reported higher vSAT ≈ 6 × 10<sup>6</sup> cm.s<sup>−1</sup> in CVD grown monolayer MoS2<sup>69</sup> . However, their measurements were done using nanosecond range pulses to reduce the impact of selfheating and hot carrier capture by deep oxide traps. For WS2, this is the first report of vSAT. 

### Discussion 

In conclusion, we have performed a detailed study of device-todevice variation and impact of channel length scaling on the electrical parameters, such as threshold voltage, subthreshold slope, density of interface trap states, ratio of minimum to maximum current, field-effect electron mobility, drive current, contact resistance, and saturation velocity, of MOCVD grown MoS2 and WS2 monolayer based FETs using statistical measures such as median, mean, standard deviation, and minimum/maximum values and have benchmarked our findings against other similar reports from 2D literature as well as UTB Si FETs. While in absolute terms the spatial variations in the respective benchmarking parameters appear to be large for MoS2 and WS2 FETs, when compared at scaled oxide thickness, our results are not significantly different from the projected variations for UTB Si FETs. Our “champion” long-channel MoS2 and WS2 FETs with LCH = 5 μm demonstrated electron mobilities of 30 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> and 33 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , respectively, when extracted using peak transconductance and 46 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> and 33 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , respectively, when extracted using TLM method. For synthetic monolayer WS2 films, these are the highest reported room temperature electron mobilities, 1.5X better than the best report from the literature. Similarly, our “champion” shortest channel length MoS2 and WS2 FETs, with LCH = 100 nm, demonstrated drive currents as high as 161 μA.μm<sup>−1</sup> and 53 μA.μm<sup>−1</sup> for VDS = 5 V at carrier densities of nS = 1 × 10<sup>13</sup> cm<sup>−2</sup> and 4.4 × 10<sup>12</sup> cm<sup>−2</sup> , respectively, in spite of the presence of high contact resistances. We attribute our accomplishments to the epitaxial growth of highly crystalline 2D monolayers on sapphire substrate via MOCVD at 1000 °C using chalcogen and sulfur precursors that minimize carbon contamination in the film, as well as to the clean transfer of the film from the growth substrate to the device fabrication substrate. Our findings suggest that 2D FETs are promising alternatives for future VLSI circuits. 

### Methods 

MOCVD growth. Uniform monolayer deposition was achieved in a cold-wall horizontal reactor with an inductively heated graphite susceptor equipped with wafer rotation as previously described<sup>27</sup> . Molybdenum hexacarbonyl (Mo(CO)6) and tungsten hexacarbonyl (W(CO)6) were used as metal precursors while hydrogen sulfide (H2S) was the chalcogen source with H2 as the carrier gas. Mo (CO)6 maintained at 10 °C and 950 Torr in a stainless-steel bubbler was used to deliver 0.036 sccm. W(CO)6 maintained in a bubbler at 10 °C and 760 Torr delivered 6.4 × 10<sup>−4</sup> sccm. The flow rate of H2S was 400 sccm and the reactor pressure was 50 Torr for both sulfides. MoS2 was deposited in a single step process at 1000 °C where coalesced monolayer growth across the 2″ wafer was achieved in 18 min. WS2 was deposited using a multi-step process with nucleation at 850 °C and lateral growth at 1000 °C, which resulted in coalesced monolayer growth across the 2″ wafer in 10 min<sup>28</sup> . In both cases, after growth, the substrate was cooled in H2S to 300 °C to inhibit decomposition of the MoS2 and WS2 films. 

Material characterization. A Bruker Icon atomic force microscope was used to measure surface morphology and film thickness. Scanasyst AFM tips with a nominal tip radius of ≈2 nm and spring constant of 0.4 Nm<sup>−1</sup> were used in the peak-force tapping mode for the measurements. Photoluminescence (PL) maps were acquired over a 5 × 5 μm<sup>2</sup> area with a laser wavelength of 532 nm and 300 grooves per mm grating in a WITec apyron Confocal Raman Microscope. A PANalytical MRD diffractometer with a 5-axis cradle was used for in-plane X-ray diffraction characterization of the sulfide films<sup>70</sup> . A Cu anode X-ray tube operated at 40 kV accelerating voltage and 45 mA filament current was used as the X-ray source. On the primary beam side, a mirror with ¼° slit and Ni filter were used to filter the Cu Kα line. On the diffracted beam side, an 0.27° parallel plate collimator with 0.04 rad Soller slits with PIXcell detector in open detector mode were employed. To determine the in-plane epitaxial relation of the film with respect to a substrate, sample surface was ≈2–4° away from the X-ray incidence plane. 

Transfer of monolayer films. Both the MoS2 and WS2 films were grown on 2″ sapphire wafers. The 2″ sapphire wafers were then cut into 1 × 1 cm<sup>2</sup> pieces. For each material, two (2) 1 × 1 cm<sup>2</sup> sapphire substrates were chosen, one corresponding to the center and another one corresponding to the edge of the 2-inch wafer. To fabricate the FETs, monolayer MoS2 and WS2 films grown on sapphire 

10 

NATURE COMMUNICATIONS | (2021) 12:693 | https://doi.org/10.1038/s41467-020-20732-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-020-20732-w 

substrates were transferred onto 1 × 1 cm<sup>2</sup> device fabrication substrates, i.e., 50 nm Al2O3 on Pt/TiN/p<sup>++</sup> -Si, using a PMMA (polymethyl-methacrylate) -assisted wet transfer process. First, the sapphire substrate with the monolayer film was spin coated with PMMA and then baked at 180 °C for 90 s. The corners of the spin coated films were scratched using a razor blade and immersed inside a 1 M NaOH solution kept at 90 °C. Capillary action drew NaOH into the substrate/film interface, separating the PMMA/monolayer film stack from the sapphire substrate. The separated film was then rinsed multiple times inside a water bath and finally transferred onto the 50 nm alumina substrate and baked at 50 °C and 70 °C for 10 min each to remove moisture and residual PMMA, ensuring a pristine interface. 

Gate dielectric fabrication. Direct replacement of thermally oxidized SiO2 with a high-κ dielectric such as Al2O3 grown via atomic layer deposition (ALD) is a logical choice to scale the EOT. However, we found that a Al2O3/p<sup>++</sup> -Si interface is not ideal for back gated FET fabrication owing to higher gate leakage current, more interface trap states, and large hysteresis, all of which negatively impact the performance of the device. Replacing Si with Pt, a large work function metal (5.6 eV) allows for minimal hysteresis and trap state effects<sup>71</sup> . Since Pt readily forms a Pt silicide at temperatures as low as 300 °C, a 20 nm TiN diffusion barrier deposited by reactive sputtering was placed between the p<sup>++</sup> Si and the Pt, permitting subsequent high temperature processing<sup>72</sup> . This conductive TiN diffusion barrier allows the back-gate voltage to be applied to the substrate, thus simplifying the fabrication and measurement procedures. The polycrystalline Pt introduces very little surface roughness to the final Al2O3 surface, with a rms roughness of 0.7 nm. 

Device fabrication. Back gated field-effect transistors (FET) are fabricated using e- beam lithography. To define the channel region the substrate is spin coated with PMMA and baked at 180 °C for 90 s. The photoresist is then exposed to e-beam and developed using 1:1 mixture of 4-methyl-2-pentanone (MIBK) and 2 propanol (IPA). The monolayer MoS2 film is subsequently etched using sulfur hexafluoride (SF6) at 5 °C for 30 s. Next the sample is rinsed in acetone and IPA to remove the photoresist. In order to fabricate the source/drain contacts the substrate is again spin coated with MMA and PMMA followed by the e-beam lithography, developed using MIBK and IPA, and e-beam evaporation of 40 nm Ni/30 nm Au stack. Finally, the photoresist is rinsed away by lift off process using acetone and IPA. 

Electrical characterization. Lake Shore CRX-VF probe station and Keysight B1500A parameter analyzer were used to perform the electrical characterization at room temperature in high vacuum (≈10<sup>−6</sup> Torr). Standard DC sweeps are used for the measurements of transfer and output characteristics of all devices. To ensure that the FETs are stabilized, they are conditioned by multiple repetitions of the same measurement. The transfer characteristics are measured three times to condition each FET and the fourth measurement is used for the analysis. The output characteristics are measured twice following the transfer characteristics and the second measurement is used for the analysis. We have found that no burn-in procedure is needed to ensure proper contact formation. Both MoS2 and WS2 FETs were measured as-fabricated. 

Reporting summary. Further information on research design is available in the Nature Research Reporting Summary linked to this article. 

### Data availability 

The datasets generated during and/or analyzed during the current study are available from the corresponding authors on reasonable request. 

### Code availability 

The codes used for plotting the data are available from the corresponding authors on reasonable request. 

Received: 27 July 2020; Accepted: 17 December 2020; 



### References 

1. Bhimanapati, G. R. et al. Recent advances in two-dimensional materials beyond graphene. ACS Nano 9, 11509–11539 (2015). 

2. Das, S., Robinson, J. A., Dubey, M., Terrones, H. & Terrones, M. Beyond graphene: progress in novel two-dimensional materials and van der Waals solids. Annu. Rev. Mater. Res. 45, 1–27 (2015). 

3. Yoon, Y., Ganapathi, K. & Salahuddin, S. How good can monolayer MoS2 transistors be? Nano Lett. 11, 3768–3773 (2011). 

4. Majumdar, K., Hobbs, C. & Kirsch, P. D. Benchmarking transition metal dichalcogenide MOSFET in the ultimate physical scaling limit. IEEE Electron Device Lett. 35, 402–404 (2014). 

5. Alam, K. & Lake, R. K. Monolayer MoS2 transistors beyond the technology road map. IEEE Trans. Electron Devices 59, 3250–3254 (2012). 

6. English, C. D., Shine, G., Dorgan, V. E., Saraswat, K. C. & Pop, E. Improved contacts to MoS2 transistors by ultra-high vacuum metal deposition. Nano Lett. 16, 3824–3830 (2016). 

7. Smets, Q. et al. Ultra-scaled MOCVD MoS2 MOSFETs with 42 nm contact pitch and 250 µA/µm drain current. IEEE International Electron Devices Meeting 23.2.1–23.2.4 (2019). 

8. Tosun, M. et al. High-gain inverters based on WSe2 complementary fieldeffect transistors. ACS Nano 8, 4948–4953 (2014). 

9. Yu, L. et al. High-performance WSe2 complementary metal oxide semiconductor technology and integrated circuits. Nano Lett. 15, 4928–4934 (2015). 

10. Radisavljevic, B., Whitwick, M. B. & Kis, A. Integrated circuits and logic operations based on single-layer MoS2. ACS Nano 5, 9934–9938 (2011). 

11. Sanne, A. et al. Radio frequency transistors and circuits based on CVD MoS2. Nano Lett. 15, 5039–5045 (2015). 

12. Yu, L. et al. Design, modeling, and fabrication of chemical vapor deposition grown MoS2 circuits with E-mode FETs for large-area electronics. Nano Lett. 16, 6349–6356 (2016). 

13. Wachter, S., Polyushkin, D. K., Bethge, O. & Mueller, T. A microprocessor based on a two-dimensional semiconductor. Nat. Commun. 8, 14948 (2017). 

14. Sebastian, A., Pannone, A., Radhakrishnan, S. S. & Das, S. Gaussian synapses for probabilistic neural networks. Nat. Commun. 10, 4199 (2019). 

15. Das, S. Two dimensional electrostrictive field effect transistor (2D-EFET): A sub-60 mV/decade Steep slope device with high ON current. Sci. Rep. 6, 34811 (2016). 

16. Schaibley, J. R. et al. Valleytronics in 2D materials. Nat. Rev. Mater. 1, 16055 (2016). 

17. Das, S., Dodda, A. & Das, S. A biomimetic 2D transistor for audiomorphic computing. Nat. Commun. 10, 3450 (2019). 

18. Lee, C. W., Suh, J. M. & Jang, H. W. Chemical sensors based on twodimensional (2D) materials for selective detection of ions and molecules in LIQuid. Front. Chem. 7, 708 (2019). 

19. Dodda, A. et al. Stochastic resonance in MoS2 photodetector. Nat. Commun. 11, 4406 (2020). 

20. Jayachandran, D. et al. A low-power biomimetic collision detector based on an in-memory molybdenum disulfide photodetector. Nat. Electron. 3, 646–655 (2020). 

21. Nasr, J. R. et al. Low-power and ultra-thin MoS2 photodetectors on glass. ACS Nano 14, 15440–15449 (2020). 

22. Smithe, K. K. H., English, C. D., Suryavanshi, S. V. & Pop, E. Intrinsic electrical transport and performance projections of synthetic monolayer MoS2 devices. 2D Mater. 4, 011009 (2016). 

23. Dumcenco, D. et al. Large-area epitaxial monolayer MoS2. ACS Nano 9, 4611–4620 (2015). 

24. Kang, K. et al. High-mobility three-atom-thick semiconducting films with wafer-scale homogeneity. Nature 520, 656–660 (2015). 

25. Smithe, K. K. H., Suryavanshi, S. V., Munoz Rojo, M., Tedjarati, A. D. & Pop, E. Low variability in synthetic monolayer MoS2 devices. ACS Nano 11, 8456–8463 (2017). 

26. Xu, H. et al. High-performance wafer-scale MoS2 transistors toward practical application. Small 14, e1803465 (2018). 

27. Xuan, Y. et al. Multi-scale modeling of gas-phase reactions in metal-organic chemical vapor deposition growth of WSe2. J. Cryst. Growth 527, 125247 (2019). 

28. Chubarov, M. et al. Wafer-scale epitaxial growth of single orientation WS2 monolayers on sapphire. arXiv e-prints, arXiv:2006.10952. Preprint at https:// ui.adsabs.harvard.edu/abs/2020arXiv200610952C (2020) 

29. Zhang, F., Erb, C., Runkle, L., Zhang, X. & Alem, N. Etchant-free transfer of 2D nanostructures. Nanotechnology 29, 025602 (2018). 

30. Das, S., Chen, H. Y., Penumatcha, A. V. & Appenzeller, J. High performance multilayer MoS2 transistors with scandium contacts. Nano Lett. 13, 100–105 (2013). 

31. Leonhardt, A. et al. Material-selective doping of 2D TMDC through AlxOy encapsulation. ACS Appl. Mater. Interfaces 11, 42697–42707 (2019). 

32. Bhoir, M. S. et al. Variability sources in nanoscale bulk FinFETs and TiTaN- a promising low variability WFM for 7/5 nm CMOS nodes. In 2019 IEEE International Electron Devices Meeting (IEDM), 36.2.1–36.2.4 (2019). 

33. Weber, O. et al. High immunity to threshold voltage variability in undoped ultra-thin FDSOI MOSFETs and its physical understanding. In 2008 IEEE International Electron Devices Meeting, 1–4 (2008). 

34. Tsutsui, G., Saitoh, M., Nagumo, T. & Hiramoto, T. Impact of SOI thickness fluctuation on threshold voltage variation in ultra-thin body SOI MOSFETs. IEEE Trans. Nanotechnol. 4, 369–373 (2005). 

35. Samsudin, K., Adamu-Lema, F., Brown, A. R., Roy, S. & Asenov, A. Combined sources of intrinsic parameter fluctuations in sub-25nm generation UTB-SOI 

11 

NATURE COMMUNICATIONS | (2021) 12:693 | https://doi.org/10.1038/s41467-020-20732-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-020-20732-w 

MOSFETs: A statistical simulation study. Solid-State Electron. 51, 611–616 (2007). 

36. Min, C., Kamins, T., Voorde, P. V., Diaz, C. & Greene, W. 0.18-μm fullydepleted silicon-on-insulator MOSFET’s. IEEE Electron Device Lett. 18, 251–253 (1997). 

37. Liu, H. & Ye, P. D. MoS2 Dual-Gate MOSFET with atomic-layer-deposited Al2O3 as top-gate dielectric. IEEE Electron Device Lett. 33, 546–548 (2012). 

38. Guo, J., Yang, B., Zheng, Z. & Jiang, J. Observation of abnormal mobility enhancement in multilayer MoS2 transistor by synergy of ultraviolet illumination and ozone plasma treatment. Phys. E: Low.-Dimensional Syst. Nanostruct. 87, 150–154 (2017). 

39. Yu, Z. et al. Towards intrinsic charge transport in monolayer molybdenum disulfide by defect and interface engineering. Nat. Commun. 5, 5290 (2014). 

40. Chang, H.-Y., Zhu, W. & Akinwande, D. On the mobility and contact resistance evaluation for transistors based on MoS2 or two-dimensional semiconducting atomic crystals. Appl. Phys. Lett. 104, 113504 (2014). 

41. Das, S. & Appenzeller, J. Where does the current flow in two-dimensional layered systems? Nano Lett. 13, 3396–3402 (2013). 

42. Yang, L. et al. Chloride molecular doping technique on 2D materials: WS2 and MoS2. Nano Lett. 14, 6275–6280 (2014). 

43. Nasr, J. R., Schulman, D. S., Sebastian, A., Horn, M. W. & Das, S. Mobility deception in nanoscale transistors: an untold contact story. Adv. Mater. 31, 1806020 (2019). 

44. Rai, A. et al. Air stable doping and intrinsic mobility enhancement in monolayer molybdenum disulfide by amorphous titanium suboxide encapsulation. Nano Lett. 15, 4329–4336 (2015). 

45. Schulman, D. S. et al. Facile electrochemical synthesis of 2D monolayers for high-performance thin-film transistors. ACS Appl Mater. Interfaces 9, 44617–44624 (2017). 

46. Sebastian, A. et al. Electrochemical polishing of two-dimensional materials. ACS Nano 13, 78–86 (2019). 

47. Yun, S. J. et al. Synthesis of centimeter-scale monolayer tungsten disulfide film on gold foils. ACS Nano 9, 5510–5519 (2015). 

48. Cui, Y. et al. High-performance monolayer WS2 field-effect transistors on high-kappa dielectrics. Adv. Mater. 27, 5230–5234 (2015). 

49. Ovchinnikov, D., Allain, A., Huang, Y. S., Dumcenco, D. & Kis, A. Electrical transport properties of single-layer WS2. ACS Nano 8, 8174–8181 (2014). 

50. Aji, A. S., Solís-Fernández, P., Ji, H. G., Fukuda, K. & Ago, H. High mobility WS2 transistors realized by multilayer graphene electrodes and application to high responsivity flexible photodetectors. Adv. Funct. Mater. 27, 1703448 (2017). 

51. Schmidt, M. et al. Mobility extraction in SOI MOSFETs with sub 1nm body thickness. Solid-State Electron. 53, 1246–1251 (2009). 

52. Schulman, D. S., Arnold, A. J. & Das, S. Contact engineering for 2D materials and devices. Chem. Soc. Rev. 47, 3037–3058 (2018). 

53. Lee, S., Tang, A., Aloni, S. & Wong, H. S. Statistical study on the schottky barrier reduction of tunneling contacts to CVD synthesized MoS2. Nano Lett. 16, 276–281 (2016). 

54. Liu, Y. et al. Pushing the performance limit of sub-100 nm molybdenum disulfide transistors. Nano Lett. 16, 6337–6342 (2016). 

55. Luo, P. et al. Doping engineering and functionalization of two-dimensional metal chalcogenides. Nanoscale Horiz. 4, 26–51 (2019). 

56. Zhu, Y. et al. Monolayer molybdenum disulfide transistors with single-atomthick gates. Nano Lett. 18, 3807–3813 (2018). 

57. Anghel, C. Ionescu, A., Hefyene, N. & Gillon, R. Self-heating characterization and extraction method for thermal resistance and capacitance in high voltage MOSFETs. In ESSDERC’03. 33rd Conference on European Solid-State Device Research, 2003. 449–452 (2003). 

58. Shin, S. et al. Impact of nanowire variability on performance and reliability of gate-all-around III-V MOSFETs. In 2013 IEEE International Electron Devices Meeting, 7.5. 1–7.5. 4 (2013). 

59. Islam, S., Li, Z., Dorgan, V. E., Bae, M.-H. & Pop, E. Role of Joule heating on current saturation and transient behavior of graphene transistors. IEEE electron device Lett. 34, 166–168 (2013). 

60. Li, X. et al. Performance potential and limit of MoS2 transistors. Adv Mater. 27, 1547–1552 (2015). 

61. Yalon, E. et al. Energy dissipation in monolayer MoS2 electronics. Nano Lett. 17, 3429–3433 (2017). 

62. Taur, Y. & Ning, T. Fundamentals of Modern VLSI Devices 2nd ed. (Cambridge, Cambridge University Press, 2009). 

63. Smithe, K. K. H., English, C. D., Suryavanshi, S. V. & Pop, E. High-field transport and velocity saturation in synthetic monolayer MoS2. Nano Lett. 18, 4516–4522 (2018). 

64. Gong, Y., Carozo, V., Li, H., Terrones, M. & Jackson, T. N. High flex cycle testing of CVD monolayer WS2 TFTs on thin flexible polyimide. 2D Mater. 3, 021008 (2016). 

65. English, C. D., Smithe, K. K. H., Xu, R. L. & Pop, E. Approaching ballistic transport in monolayer MoS2 transistors with self-aligned 10 nm top gates. 5.6.1–5.6.4 (2016). 

66. Liu, H. et al. Statistical study of deep submicron dual-gated field-effect transistors on monolayer chemical vapor deposition molybdenum disulfide films. Nano Lett. 13, 2640–2646 (2013). 

67. Lundstrom, M. Fundamentals of Carrier Transport, 2nd edn (Cambridge University Press, 2000). 

68. Sze, S. M. & Ng, K. K. Physics of Semiconductor Devices, 3rd edn (John Wiley & Sons, 2007). 

69. Nathawat, J. et al. Transient hot-carrier dynamics and intrinsic velocity saturation in monolayer MoS2. Phys. Rev. Mater. 4, 014002 (2020). 

70. Chubarov, M., Choudhury, T. H., Zhang, X. & Redwing, J. M. In-plane x-ray diffraction for characterization of monolayer and few-layer transition metal dichalcogenide films. Nanotechnology 29, 055706 (2018). 

71. CRC Handbook of Chemistry and Physics, 98th edn (Internet Version 2018) ed. (CRC Press/Taylor & Francis, Boca Raton, FL, 2018). 

72. Crider, C. A., Poate, J. M., Rowe, J. E. & Sheng, T. T. Platinum silicide formation under ultrahigh-vacuum and controlled impurity ambients. J. Appl. Phys. 52, 2860–2868 (1981). 

### Acknowledgements 

The work was partially supported by Army Research Office (ARO) through Contract Number W911NF1920338. Authors also acknowledge the support from the National Science Foundation (NSF) through the Pennsylvania State University 2D Crystal Consortium–Materials Innovation Platform (2DCCMIP) under NSF cooperative agreement DMR-1539916. 

### Author contributions 

S.D. conceived the idea. S.D. and A.S. designed the experiments and wrote the manuscript. A.S. and R.P. performed the measurements, S.D., A.S., and R.P. analyzed the data, discussed the results, and agreed on their implications. T.H.C, and J.M.R synthesized and characterized MoS2 and WS2 monolayers. All authors contributed to the preparation of the manuscript. 

### Competing interests 

The authors declare no competing interests. 

### Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-020-20732-w. 

Correspondence and requests for materials should be addressed to S.D. 

Peer review information Nature Communications thanks Giovanni De Micheli, Quentin Smets and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. Peer reviewer reports are available. 

Reprints and permission information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2021 

12 

NATURE COMMUNICATIONS | (2021) 12:693 | https://doi.org/10.1038/s41467-020-20732-w | www.nature.com/naturecommunications 

