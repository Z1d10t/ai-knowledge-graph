# An in-memory computing architecture based on a duplex two-dimensional material structure for in situ machine learning

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Nanotechnology |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 188 |
| 作者 | Hongkai Ning, Zhi-Hao Yu, Qingtian Zhang, Hengdi Wen, Bin Gao, Yun Mao, Yuankun Li, Ying Zhou et al. |
| DOI | 10.1038/s41565-023-01343-0 |
| 源文件 | 051_Ning_2023_An-in-memory-computing-architecture-based-on-a-d.pdf |

---
- 1 **An in-memory computing architecture based on a duplex 2D material structure** 

- 2 **for** **_in-situ_ machine learning** 

- 3 Hongkai Ning<sup>1</sup> †, Zhihao Yu<sup>1,2</sup> †*, Qingtian Zhang<sup>3</sup> †, Hengdi Wen<sup>1</sup> †, Bin Gao<sup>3</sup> †*, Yun 

- 4 Mao<sup>1</sup> , Yuankun Li<sup>3</sup> , Ying Zhou<sup>3</sup> , Yue Zhou<sup>4</sup> , Jiewei Chen<sup>4</sup> , Lei Liu<sup>1</sup> , Wenfeng Wang<sup>1</sup> , 

- 5 Taotao Li<sup>1</sup> , Yating Li<sup>1</sup> , Wanqing Meng<sup>1</sup> , Weisheng Li<sup>1</sup> , Yun Li<sup>1</sup> , Hao Qiu<sup>1</sup> , Yi Shi<sup>1</sup> , Yang 

- 6 Chai<sup>4</sup> , Huaqiang Wu<sup>3</sup> * & Xinran Wang<sup>1,5,6</sup> * 

- 7 _1National Laboratory of Solid State Microstructures, School of Electronic Science_ 

- 8 _and Engineering and Collaborative Innovation Center of Advanced Microstructures,_ 

- 9 _Nanjing University; Nanjing 210093, China_ 

- 10 _2School of Integrated Circuit Science and Engineering, Nanjing University of Posts_ 

- 11 _and Telecommunications; Nanjing 210023, China_ 

- 12 

   - _3School of Integrated Circuits, Tsinghua University; Beijing 100084, China_ 

- 13 _4Department of Applied Physics, The Hong Kong Polytechnic University; Hung Hom,_ 

- 14 _Kowloon, Hong Kong, China_ 

- 15 _5School of Integrated Circuits, Nanjing University; Suzhou 215163, China._ 

- 16 _6Suzhou Laboratory, Suzhou, China._ 

- 17 *Corresponding author. Email: zhihao@nju.edu.cn, <u>gaob1@tsinghua.edu.cn,</u> 

- 18 <u>wuhq@tsinghua.edu.cn, xrwang@nju.edu.cn</u> 

- 19 † These authors contributed equally to this work 

- 20 **Abstract** 

- 21 The growing computational demand in artificial intelligence (AI) calls for 

- 22 hardware solutions that are capable of in-situ machine learning, where both training and 

- 1 inference are performed by edge computation. This not only requires extremely energy- 

- 2 efficient architecture (such as in-memory computing, IMC) but also memory hardware 

- 3 with tunable properties to simultaneously meet the demand for training and inference. 

- 4 Here, we report a duplex device structure based on ferroelectric field-effect transistor 

- 5 (FeFET) and atomically thin MoS2 channel and realize a universal IMC architecture for 

- 6 in-situ learning. By exploiting the tunability of ferroelectric energy landscape, the 

- 7 duplex building block demonstrates overall excellent performance in endurance (>10<sup>13</sup> ), 

- 8 retention (>10 years), speed (4.8 ns) and energy consumption (22.7 fJ/(bit·μm<sup>2</sup> )). We 

- 9 implemented a hardware neural network using arrays of two-transistor-one-duplex- 

- 10 FeFET (2T1D) cells and achieved 99.86% accuracy in non-linear localization task with 

- 11 in-situ trained weights. Simulations show that the proposed device architecture could 

- 12 achieve the same level of performance as graphics processing unit under notably 

- 13 improved energy efficiency. Our device core can be combined with silicon circuitry 

- 14 through three-dimensional heterogeneous integration to give a hardware solution 

- 15 toward general edge intelligence (EI). 

2 

- 1 **Introduction** 

- 2 Modern AI relies on central cloud to process data generated at edge devices. Such 

- 3 cloud-edge separated model is not energy efficient due to the von Neumann architecture 

- 4 underpinning digital computing systems as well as the data communications<sup>1-3</sup> . There 

- 5 is strong motivation to develop _in-situ_ machine learning hardware with training-and- 

- 6 inference-in-one (TIIO) architecture (Fig. 1a), which is the ultimate goal of EI. TIIO 

- 7 offers the benefit of data security, real-time processing and bandwidth, but it requires 

- 8 extremely high energy and area efficiency due to limited resources at edge. For example, 

- 9 typical edge training scenarios involve over 10<sup>12</sup> MAC operations per second under 

- 10 milliwatt power, which far exceed the capability of existing hardware technologies<sup>4</sup> . 

- 11 Recently, IMC based on non-volatile memories (NVMs) emerges as a promising 

- 12 solution for EI<sup>4,5,7-14</sup> . However, using a single NVM technology to perform 

- 13 simultaneous training and inference has been challenging<sup>5-7</sup> . This is because training 

- 14 and inference take different aspects of memory properties<sup>5</sup> . In particular, training 

- 15 involves abundant data so it requires good endurance, speed and energy efficiency. On 

- 16 the other hand, inference relies on pre-stored cell weights so retention is critical. In both 

- 17 scenarios, analog capability is desirable to improve the accuracy and energy efficiency 

- 18 of neural networks<sup>5</sup> . Unfortunately, most NVMs lack large tunability in memory 

- 19 properties, preventing a universal IMC architecture that simultaneously satisfies the 

- 20 requirements for training and inference. 

- 21 Ferroelectrics was proposed as NVM in 1950s and recently became technologically 

- 22 promising after the discovery of ferroelectricity in binary fluorite oxides (HfO2 and 

- 23 ZrO2) down to the thickness limit<sup>15-19</sup> . As the basic device building block for IMC, 

- 24 FeFET has been demonstrated on various channel materials, delivering some of the 

- 25 most promising characteristics for edge computing<sup>20-28</sup> . Among the channel materials, 

3 

- 1 2D semiconductors (such as transition-metal dichalcogenides) are especially appealing 

- 2 because: 1) they have atomic thickness and therefore low power consumption through 

- 3 leakage at scaled device dimension<sup>29-31</sup> ; 2) the reduced screening allows the reduction 

- 4 of gate voltage and expands design margin for analog computing<sup>32,33</sup> ; 3) they are back- 

- 5 end-of-line (BEOL) compatible with complementary metal-oxide-semiconductor 

- 6 (CMOS) and can be integrated with peripheral circuitry<sup>34</sup> , although some challenges 

- 7 of material, device, and integration need to be addressed<sup>35,36</sup> ; 4) they offer a variety of 

- 8 sensory properties to facilitate the fusion of sensor with computing<sup>23,37,38</sup> . 

- 9 Here, we combined FeFET with monolayer MoS2 channel and devised a duplex 

- 10 device structure for _in-situ_ machine learning. The duplex structure comprised of a split11 gate FeFET with different ferroelectric (FE)/dielectric (DE) capacitance ratio ( _C_ FE/ _C_ DE) 

- 12 optimized for training and inference, respectively. The duplex structure exhibited 

- 13 excellent endurance (>10<sup>13</sup> ), retention (>10 years), speed (4.8 ns) and energy 

- 14 consumption (22.7 fJ/(bit·μm<sup>2</sup> )) simultaneously to meet the requirement for edge 

- 15 training and inference. Multi-layer neural network was implemented with array of 

- 16 2T1D cells and achieved 99.86% accuracy in non-linear localization using _in-situ_ 

- 17 trained weights and all-analog computing. Our results suggest that combining 2D 

- 18 materials with ferroelectrics is a promising hardware solution for EI. 

- 19 **The duplex FeFET device structure** 

- 20 We exploited the tunability of FeFET by engineering the FE energy landscape in 

- 21 the metal–ferroelectric–metal–insulator–semiconductor (MFMIS) device structure. Fig. 

- 22 1b shows the schematic illustration of the duplex device structure consisting of two split 

- 23 gates with different _C_ FE sharing the same MoS2 channel. The metal layer between FE 

- 24 and DE acts as floating gate in memory operation. The potential drop across the FE is 

- 25 expressed as: 

4 

1 



<!-- Start of picture text -->
𝐶𝐷𝐸<br>𝑉𝐹𝐸 = 𝑉𝑔 × ,   (1)<br>𝐶𝐷𝐸+𝐶𝐹𝐸<br><!-- End of picture text -->

- 2 where 𝑉𝑔, 𝐶𝐹𝐸 and 𝐶𝐷𝐸  represent the gate voltage and the capacitance of FE and 

- 3 DE layer, respectively. The Gibbs free energy of the FE-DE system is expressed 

- 4 as 𝐺𝐹𝐸𝑡𝐹𝐸 + 𝐺𝐷𝐸𝑡𝐷𝐸 where 𝐺𝐹𝐸(𝐺𝐷𝐸) and 𝑡𝐹𝐸(𝑡𝐷𝐸) are the free energy and thickness of 

- 5 the FE (DE) layer, respectively. By changing the 𝐶𝐹𝐸/𝐶𝐷𝐸, the FeFET can evolve from 

- 6 “FE-like” to “DE-like” as a result of the evolving FE energy landscape, leading to 7 continuously tunable memory characteristics (Extended Data Fig. 1). Specifically, 8 when operating on the gate with small (large) 𝐶𝐹𝐸, the duplex FeFET is “FE-like” ("DE9 like”), which is more suitable for inference (training). In the extreme case of infinite 

- 10 𝐶𝐹𝐸/𝐶𝐷𝐸 (without FE), the device is “pure DE” and can serve as selector transistor in a 11 cross-bar array. 

- 12 Fig. 1c displays the optical micrograph of a 2T1D duplex cell, where the two split 

- 13 gates of the duplex FeFET are connected to training- (T-) and inference- (I-) selectors 

- 14 through vertical vias. Fig. 1d illustrates the programing sequence during the _in-situ_ 15 machine learning process. The T- and I- word line, which is the gate voltage of the 

- 16 corresponding selector, is used to select the T-type and I-type synapse during training 17 and inference, respectively. During _in-situ_ training, multiple weight-tuning pulses are 

- 18 applied on T-type synapses through the bit line. After the network has been trained, the 

- 19 weights are transferred to I-type synapses through the same bit line, which are stored 

- 20 there and used for inference. The _V_ in, which is the drain voltage of the FeFET, acted as 

- 21 both weight read for backpropagation during training and data voltage input for feed 22 forward during inference. 

- 23 **Device performance of duplex FeFET** 

- 24 All the devices in this work used chemical-vapor deposited monolayer MoS2 as 

5 

- 1 channel<sup>39</sup> and local backgate structure consisting of two dielectrics layers (16 nm 

- 2 HfxZr1-xO2 FE and 12 nm HfO2 DE, corresponding permittivity of 18 and 19 

- 3 respectively) and three metal layers (backgate, floating gate, and source/drain) (Fig. 2a, 

- 4 see Methods for details of fabrication). All detailed geometric device parameters can be 

- 5 found in Supplementary Table 1. The temperature of the entire MoS2 transfer and device 

- 6 fabrication process was kept below 450 ℃. We first studied the memory properties of 

- 7 the FeFET as a function of 𝐶𝐹𝐸/𝐶𝐷𝐸. To this end, we fabricated a test structure with 

- 8 FE/DE area ratio 𝐴𝐹𝐸/𝐴𝐷𝐸 ranging from 0.007 to 2.667. Fig. 2b plots the double-sweep 

- 9 _I_ ds- _V_ g characteristics of the FeFET as a function of 𝐴𝐹𝐸/𝐴𝐷𝐸. As expected, the memory 

- 10 window progressively narrowed with 𝐴𝐹𝐸/𝐴𝐷𝐸 due to the increasing DE contribution 

- 11 in the gate stack (Extended Data Fig. 1). In the pure DE case (by shorting the floating 

- 12 gate and backgate), the device returned to transistor behavior with negligible hysteresis 

- 13 (Fig. 2b, black line). 

- 14 The retention and endurance characteristics of the FeFET were summarized in Figs. 

- 15 2c, 2d and Extended Data Figs. 2, 3. In contrast to the binary memory in logic circuits, 

- 16 multi-bit data retention is desirable for inference using IMC. We performed accelerated 

- 17 retention test of 16 states in an I-type FeFET (AFE/ADE = 0.053) under 85<sup>o</sup> C before 

- 18 (Fig. 2c) and after endurance cycling (Extended Data Fig. 3h). Both fresh device and 

- 19 device undergone 10<sup>5</sup> endurance cycles, the conductance of the states was well 

- 20 separated and did not show obvious degradation up to 10<sup>3</sup> s. More remarkably, even 

- 21 under 125<sup>o</sup> C accelerated test<sup>40</sup> , we could still extrapolate 10-year retention in the I- 

- 22 type FeFET with on/off ratio of 10<sup>6</sup> (Extended Data Fig. 3f). To evaluate endurance, we 

6 

- 1 continuously applied programing and erasing voltage pulses with a period of 20 ns and 

- 2 measured the transfer curve to extract 𝐼𝑜𝑛 and 𝐼𝑜𝑓𝑓 at intervals of several cycles<sup>41</sup> (Fig. 

- 3 2d inset, see Methods for more details). Fig. 2d and Supplementary Fig. 1 show the 

- 4 endurance of a T-type FeFET (AFE/ADE = 0.67). The devices survived 10<sup>13</sup> cycles without 

- 5 breaking, and the on/off ratio of 10<sup>5</sup> which was adequate for memory operations. We 

- 6 measured the endurance for a range of 𝐴𝐹𝐸/𝐴𝐷𝐸 and observed trade-off behavior with 

- 7 retention, which was consistent with the transition from “FE-like” to “DE-like” 

- 8 behavior (Extended Data Figs. 1 and 2a). Nevertheless, the endurance exceeded the 

- 9 requirement for edge training (10<sup>9</sup> ) and even cloud training (10<sup>12</sup> ) in a wide range of 

- 10 𝐴𝐹𝐸/𝐴𝐷𝐸<sup>7,42</sup> , providing a large design space for different applications. To 

- 11 experimentally evaluate the scaling potential of device metrics, we fabricated and 

- 12 measured scaled devices with different channel length. We found that even for channel 

- 13 length down to 85 nm, the strong 𝐴𝐹𝐸/𝐴𝐷𝐸 dependence, the high retention of DE-like 

- 14 devices and the high endurance of FE-like devices maintained a high consistency with 

- 15 long-channel devices (Supplementary Note 5 and Extended Data Fig. 2). 

- 16 We further performed benchmark with existing memory technologies, including 

- 17 Flash, RRAM, PCRAM, MRAM, FTJ and FeRAM (Fig. 2f, Supplementary Tables 2 

- 18 and 3). As a building block for IMC, our duplex FeFET structure simultaneously 

- 19 demonstrated good endurance and retention characteristics. It is worth noting that the 

- 20 degenerated endurance of Hf-based FeFET originates from numerous factors, such as 

- 21 high coercive field for saturation polarization, imprint induced by interfacial traps or 

- 22 defects, uncompensated charge by MFIS structure, etc. Compared with MFIS structure, 

7 

- 1 the MFMIS releases interfacial voltage stress and reduces the trap and defect 

- 2 generation<sup>20</sup> while embracing symmetrical electrodes and compensated charge. 

- 3 Moreover, benefit from the strong gate dependence of atomic MoS2, the reduced 𝑉𝐹𝐸 

- 4 with the unsaturated polarization can still achieve the multi-bit storage required for 

- 5 training (more flattened _E-P_ relationship, see details in Extended Data Fig. 1), thereby 

- 6 effectively improving endurance. As a result, our devices improved the endurance over 

- 7 existing Si- and MoS2-based FeFETs by 10<sup>2</sup> and 10<sup>8</sup> , respectively. 

- 8 Memory speed and energy consumption was also critical for training with massive 

- 9 data. We characterized the switching speed and read speed by ultrafast pulse 

- 10 measurements and read-after-write measurements (Extended Data Fig. 4). As shown in 

- 11 Fig. 2e, the FeFET could be reliably programed and erased by 4.8 ns electrical pulses 

- 12 (limited by our experimental setup) with good retention and on/off ratio. The FE 

- 13 polarization can be effectively read with minimal delay of 20 ns after programmed, and 

- 14 there is almost no visible shift in both of high and low threshold voltages, which 

- 15 demonstrates very leading read speed (Supplementary Table 4). The switching speed 

- 16 was one of the fastest in FeFET and already met the International Roadmap for Devices 

- 17 and Systems (IRDS) target for NVM<sup>43</sup> . We also calculated the switching energy of 3.4 

- 18 pJ (or 22.7 fJ/𝜇𝑚<sup>2</sup> ) from the transient response (Extended Data Fig. 5), which was also 

- 19 among the lowest in NVM (Supplementary Table 2, 5). More importantly, Hf-based 

- 20 ferroelectric has been successfully integrated with advanced processes such as Fin- 

- 21 FET<sup>44</sup> and FDSOI<sup>45</sup> , and the memory window has also been reduced to 1.5 V or even 

- 22 lower, which demonstrates the great advantages of ferroelectrics in future advanced 

8 

- 1 manufacturing integrated circuit applications. 

- 2 We further assessed the analog storage capability. Extended Data Fig. 6a-c shows 

- 3 the 7-bit (128-state) output characteristics and the corresponding 

- 4 potentiation/depression process of a T-type FeFET (𝐴𝐹𝐸/𝐴𝐷𝐸 = 0.43, see Methods for 

- 5 details of measurement). The good linearity of output curves allows all-analog 

- 6 computing (as demonstrated later in the neural network), which is more energy efficient 

- 7 than binary encoding (Supplementary Note 2). The reliable multi-level performance is 

- 8 attributed to the dangling bond-free interface of MoS2 which could potentially 

- 9 overcome the trap-induced performance degradation in Si-based FeFET<sup>33</sup> . Overall, our 

- 10 duplex FeFET demonstrated excellent memory performance to meet the _in-situ_ learning 

- 11 requirements on device level. 

- 12 **Hardware implementation of** **_in-situ_ learning** 

- 13 To demonstrate the potential of the duplex FeFET architecture in _in-situ_ learning, 

- 14 we built an artificial neural network (ANN) (Fig. 3a) containing three neuron layers 

- 15 (input, hidden and output) and solved the localization problem in 2D space (Fig. 3b), 

- 16 which is higher-order classification problem that cannot be implemented by single- 

- 17 layer or binary network (Supplementary Note 3). The neural network was physically 

- 18 implemented by an 8× 3 array of 2T1D TIIO cells (Fig. 1c). Two 7-bit cells were 

- 19 combined together to realize positive and negative weights to imitate excitation and 

- 20 inhibition in biology. Therefore, the size of L1 synapse (connecting input and hidden 

- 21 layer) and L2 synapse (connecting hidden and output layer) are 2 × 4 and 4 × 1, 

- 22 respectively, with 8-bit precision. Within each cell, the T-type and I-type synapse shared 

9 

- 1 the MoS2 channel with 𝐴𝐹𝐸/𝐴𝐷𝐸 of 0.43 and 0.053, respectively. In this pseudo-cross- 

- 2 bar array, training and inference functions were performed as the voltage sequence 

- 3 operation described in Fig. 1d. The datasets were imported as a voltage sequence to _Vin_ 

- 4 without any encoding (Extended Data Fig. 6d). The weight was stored by FE 

- 5 polarization and translated as the channel conductance of FeFET and the output _I_ ds was 

- 6 summed over each column according to Kirchhoff's Law. Owing to the linear _I_ ds _-V_ ds 

- 7 curve and long data retention, high-fidelity analog output waveforms were achieved. 

- 8 The measurement setup, software and interfaces were customized to facilitate the 

- 9 

   - hardware test flow (see Methods, Extended Data Fig. 7). 

- 10 The _in-situ_ learning process was divided into three steps, namely on-chip training, 

- 11 weight transfer, and on-chip inference. Fig. 3c shows a typical training process using 

- 12 T-type synapse, where the accuracy and loss gradually converge with distinguished 

- 13 boundaries of the dataset as the epoch progresses. The 2D heatmaps represent the 

- 14 pristine input data and the classification results after the 6<sup>th</sup> , 12<sup>th</sup> , and 17<sup>th</sup> training epoch. 

- 15 After the 17<sup>th</sup> epoch, the accuracy of both training and test reached 100%, while the 

- 16 cost dropped to 0.067 and 0.083, respectively. The evolution of the localization 

- 17 boundary during the training process was displayed in Supplementary Video 1. The 

- 18 histogram distribution of the synapse weights before and after training are shown in Fig. 

- 19 3d, suggesting that the weights were changed effectively by the backpropagation 

- 20 algorithm. The robustness and reliability of the classification results were further 

- 21 verified by computer simulations using the same architecture and learning scheme 

- 22 (Extended Data Fig. 8). 

10 

- 1 After training, the weights were transferred to I-type synapses in the TIIO cell for 

- 2 subsequent inference (see Methods). Subsequently, we performed classification of 

- 3 additional 10,000 data points as shown in Fig. 3e. Thanks to the excellent retention of 

- 4 I-type synapse, the output maintains high accuracy of 99.86% (14 mis-classified points 

- 5 out of 10,000). The histogram shows that most data points are distributed around 0.9 

- 6 (“inside”) or 0 (“outside”) away from the boundary (0.5), indicating high fidelity of the 

- 7 inference results. 

- 8 **Simulation of large-scale artificial neural network** 

- 9 Autonomous robotic vision is an important application for _in-situ_ learning. 

- 10 Biological systems typically adopt binocular vision, which rely on disparity of optical 

- 11 path difference entering the left and right eyes to render the real-time 3D space. 

- 12 Monocular depth estimation, on the other hand, is attractive for computer vision due to 

- 13 the reduced hardware volume and computation resources<sup>46</sup> (Fig. 4a). However, 

- 14 monocular depth estimation is like seeing 3D space when one eye, which requires 

- 15 repeated data training to adapt the foreshortening effects and therefore extremely high 16 energy efficiency. 

- 17 A widely adopted approach for monocular depth estimation is the encoder-decoder 

- 18 architecture (Fig. 4b). The encoder part uses massive pre-trained weights through 

- 19 transfer learning<sup>47</sup> but minimal weight update, which requires long data retention 

- 20 (corresponding to I-type synapse). On the contrary, the decoder part focused on feature 

- 21 extraction from training with abundant data (corresponding to T-type synapse). Here, a 

- 22 15-block U-Net<sup>48</sup> with 178 layers was simulated using the duplex architecture, where 

11 

- 1 I-type (T-ype) synapses were used in the 9-block encoder (6-block decoder) with all the 

- 2 device parameters derived from experiments (see Methods and Extended Data Fig. 9). 

- 3 Two variation models were constructed for training and inference to ensure the 

- 4 simulation reliability (See Methods). The simulated chip consisted of 128 × 128 2T1D 

- 5 cells with peripheral analog-to-digital converter (ADC), sample-and-hold circuits 

- 6 multiplexer, controller, and driver (Fig. 4c inset). Fig. 4d and Extended Data Fig. 10e 

- 7 show several street scenes in autonomous driving. Our duplex TIIO chip successfully 

- 8 identified all the features and captured their relative depth with comparable 

- 9 convergence rate as GPU (Fig. 4c). The recognition accuracy (sigma 3 level of 

- 10 threshold) and RMSE (Root Mean Square Error) reached 96.85% and 6.31%, 

- 11 respectively (see Extended Data Fig. 10a,10c). Compared to GPU, the convolution 

- 12 circuit of duplex TIIO exhibits better energy efficiency while maintaining the equal 

- 13 computing accuracy. We designed rigorous scaling rules based on ITRS reports and cell 

- 14 layout with appraised parasitic parameter to perform energy efficiency projection for 

- 15 our TIIO cell at advanced 22 nm node (Supplementary Note 6). For training (inference) 

- 16 process, the pre- and post- simulation of projected cell energy efficiency is 2110 (111.86) 

- 17 TOPS/W and 1151 (111.86) TOPS/W. We noticed that the reduced energy efficiency in 

- 18 the post-simulation is induced by the larger operating voltage of the bit line, which also 

- 19 leads to further drop in energy efficiency as the array scale increases. Therefore, 

- 20 reducing the thickness of HZO and realizing the integration of more advanced 

- 21 technology node will be crucial to improving chip-level energy efficiency. Thanks to 

- 22 the BEOL advantages of 2D materials and ferroelectric HZO, the neuromorphic 

12 

- 1 computing cores can be the monolithically integrated with other necessary functional 

- 2 blocks of pooling, activation, routing and buffering in the future, and further improve 

- 3 overall energy efficiency. 

- 4 

# **Conclusions** 

- 5 In this work, we have shown large tunability of memory metrics by device 

- 6 architecture design, which is lacking for most non-volatile memory technologies. We 

- 7 demonstrated an IMC architecture that can complete in-situ machine learning, using a 

- 8 unitary device technology. By integrating split FE capacitors with complementary 

- 9 characteristics in the same memory cell, the proposed duplex architecture solves the 

- 10 problem of conflicting memory requirements for training and inference, which has long 

- 11 plagued EI applications. It not only simplifies the hardware fabrication process, but also 

- 12 merges the training and inference process in one memory building block. Such compact 

- 13 design can improve parallel computation and thus deliver higher energy efficiency. 

- 14 Based on 22 nm technology node, our architecture shows a post-simulation projected 

- 15 energy efficiency for training of 1151 TOPS/W, using the single TIIO cell. It is, however, 

- 16 worth noting that the projection here is somewhat overestimated because the 

- 17 contribution of the necessary peripheral circuitry is not included. Compared with 

- 18 previous work that focused on training and inference, we use the non-volatile multi-bit 

- 19 characteristics for both learning and inference on a single device, and demonstrate 2D 

- 20 localization task on a small-scale hardware circuit, which maintains high area efficiency 

- 21 and energy efficiency for IMC applications. Our design also embraces transfer learning 

- 22 which is widely applied in image processing, natural language processing and emotion 

- 23 recognition, thus will likely become a key component in lifelong learning applications. 

- 24 

13 

- 1 **Acknowledgements.** 

- 2 This work is supported by the National Key R&D Program of China (grant no. 3 2022YFB4400100 (X. W.), 2021YFA0715600 (H. Q.), 2021YFA1202903 (W. L.)), 4 the National Natural Science Foundation of China (grant no. T2221003 (X. W.), 5 61927808 (X. W.), 61734003 (X. W.), 61851401 (X. W.), 91964202 (Z. Y.), 6 62204124 (Z. Y.), 51861145202 (X. W.)), the Leading-edge Technology Program 7 of Jiangsu Natural Science Foundation (grant no. BK20202005 (X. W.)), the 8 Strategic Priority Research Program of Chinese Academy of Sciences (grant no. 9 XDB30000000 (X. W.)), the Research Grant Council of Hong Kong (no. 15205619 

- 10 (Y. C.)), Key Laboratory of Advanced Photonic and Electronic Materials, 11 Collaborative Innovation Center of Solid-State Lighting and Energy-Saving 12 Electronics, and the Fundamental Research Funds for the Central Universities, 13 China. In addition, we thank the NJU Micro-fabrication and Integration Center for 14 support during device fabrication and measurement, and thank the Beijing 15 Advanced Innovation Center for Integrated Circuits for support on device 16 modeling and simulations. 

- 17 

- 18 **Author Contributions.** 

- 19 Z. Y. and X. W. conceived and supervised the project. H. N. performed the 20 fabrication of device and TIIO array with assistance from Z. Y., H. Wen., W. M., 21 W. L., Yating L. and Y. L. H. N. did electrical measurements with assistance with 22 Z. Y. and H. Wen. Y. Mao and H. Qiu performed projections and simulations of 23 22nm-node FeFET. L. L., W. W. and T. L. performed MoS2 growth. Q. Z., 24 Yuankun. L., Ying Z., Yue Z., J. C. contributed to simulations of monocular depth 25 estimation, with the guidance from B. G., Y. C. and H. Wu. H. N., Z. Y., X. W co26 wrote the manuscript with input from other authors. All the authors contributed to 27 discussions. 

- 28 

- 29 **Competing interests.** The authors declare no competing financial interest. 

- 30 

31 

14 

- 1 **Fig. 1.** **_In-situ_ machine learning with TIIO cell. a** , Inference and training process in 

- 2 machine learning. During inference, the weights are saved in a synapse array, where 

- 3 massive multiply-and-accumulate (MAC) are done in parallel. During training, weights 

- 4 in synapses are updated frequently. The proposed TIIO cell can integrate inference (I-) 

- 5 type and training (T-) type synapse in the same memory building block to realize _in-_ 

- 6 _situ_ learning. **b** , Schematics of duplex 2D material CIM device. **c** , Optical microscope 

- 7 image and programming sequence of a TIIO cell comprised of 2T1D. Besides the 

- 8 duplex FeFET core, two selector transistors (T- and I-) are involved to form a pseudo- 

- 9 crossbar structure. Scale bar, 20 μm. 

- 10 

15 

- 1 **Fig. 2. The duplex FeFET device performance** . **a** , Schematic drawing of the test 

- 2 structure with different _A_ FE/ _A_ DE sharing the same MoS2 channel. **b** , Transfer 

- 3 characteristics of FeFET with different _A_ FE/ _A_ DE, revealing large tunability of memory 

- 4 window. **c** , 16-level (chosen from 128 states) data retention of an I-type FeFET 

- 5 (AFE/ADE = 0.053) under 85<sup>o</sup> C accelerated test. **d** , The endurance of a T-type FeFET 

- 6 (AFE/ADE = 0.67). Inset shows the pulse sequence during test. **e** , Switching of FeFET 

- 7 under 4.8 ns programming and erasing pulses. **f** , Benchmark of endurance and retention 

- 8 with other memory technologies. The three horizontal lines mark the endurance 

- 9 requirement for cloud training (>10<sup>12</sup> ), edge training (>10<sup>9</sup> ), and storage (>10<sup>5</sup> ). STP: 

- 10 short-term plasticity; LTP: long-term plasticity. The references for the data in **f** are 

- 11 summarized in Supplementary Tables 2, 3. 

- 12 

16 

- 1 **Fig. 3.** **_In-situ_ machine learning with TIIO ANN. a** , Left, microscopic image of chip 

- 2 layout with TIIO ANNs and test structures. Scale bar, 1 mm. Right, one TIIO ANN 

- 3 with pseudo-crossbar structure containing two synapse layers (L1 and L2), 8 bit lines, 

- 4 8 hidden nodes, 6 word lines, 2 input lines and 1 output line. Scale bar, 100 μm. **b** , 

- 5 Scene illustration of the 2D localization task. This non-linear classification requires 

- 6 neural network with at least 2 synapse layers. The target of this ANN was classifying 

- 7 location data as “inside (1)” or “outside (0)” with a high accuracy. **c-e** , Training ( **c, d** ) 

- 8 and inference ( **e** ) with the TIIO ANN. **c** , Cost and accuracy as a function of training 

- 9 epoch (blue stands for training data and yellow stands for test data). The training 

- 10 finished at the 17<sup>th</sup> epoch with 100% accuracy. Classification heatmaps of the initial 

- 11 and 6<sup>th</sup> , 12<sup>th</sup> and 17<sup>th</sup> epoch are plotted. Data points with white (210 points) and black 

- 12 border (90 points) stand for training and test data, respectively. **d** , The distribution of 

- 13 weights and bias parameters before and after training. **e** , The inference result of 10,000 

- 14 data points using in-situ trained weights. 99.86% accuracy was achieved. The dash line 

- 15 at 0.5 draws out the threshold of classification, where the outputs ≥0.5 were classified 

- 16 as “inside (1)”, and the outputs <0.5 were classified as “outside (0)”. 

- 17 

17 

- 1 **Fig. 4. Simulation of large-scale TIIO ANN. a** , The scene illustration of monocular 

- 2 depth estimation in autonomous driving. **b** , The employed neural network with 

- 3 encoder-decoder architecture. **c** , Test loss as a function of epoch simulated on GPU 

- 4 (gray) with 8-bit precision and 128×128 TIIO ANN (yellow). The yellow shaded region 

- 5 stands for standard error from 5 independent runs. And the center line with yellow 

- 6 symbols stands for the mean values of these 5 runs. Inset, schematic chip architecture 

- 7 used in this simulation. **d** , A representative scene of depth estimation containing 4 cars 

- 8 and 5 poles. The TIIO correctly distinguishes all the features with sharp edges. 

- 9 

18 

- 1 **References:** 

- 2 1. Hutson, M. Has artificial intelligence become alchemy? _Science_ . **360** , 478–478 3 (2018). 

- 4 2. Christensen, D. V. et al. 2022 roadmap on neuromorphic computing and 5 engineering. _Neuromorph. Comput. Eng._ **2** , 022501 (2022). 

- 6 3. Mehonic, A. & Kenyon, A. J. Brain-inspired computing needs a master plan. 7 _Nature_ . **604** , 255–260 (2022). 

- 8 4. Salahuddin, S., Ni, K. & Datta, S. The era of hyper-scaling in electronics. _Nat._ 9 _Electron._ **1** , 442–450 (2018). 

- 10 5. Kendall, J. D. & Kumar, S.  The building blocks of a brain-inspired computer. _Appl._ 11 _Phys. Rev._ **7** , 011305 (2020). 

- 12 6. Ambrogio, S. et al. Equivalent-accuracy accelerated neural-network training 13 using analogue memory. _Nature_ . **558** , 60–67 (2018). 

- 14 7. Yu, S. Neuro-inspired computing with emerging nonvolatile memory. _Proc. IEEE_ . 15 **106** , 260–285 (2018). 

- 16 8. Zhou, Z. et al. Edge intelligence: paving the last mile of artificial intelligence with 17 edge computing. _Proc. IEEE_ . **107** , 1738–1762 (2019). 

- 18 9. Keshavarzi, A., Ni, K., Hoek, W. V. D., Datta, S. & Raychowdhury, A. 19 FerroElectronics for edge intelligence. _IEEE Micro_ . **40** , 33–48 (2020). 

- 20 10. Yao, P. et al. Fully hardware-implemented memristor convolutional neural network. 21 _Nature_ . **577** , 641–646 (2020). 

- 22 11. Demasius, K.-U., Kirschen, A. & Parkin, S. Energy-efficient memcapacitor devices 23 for neuromorphic computing. _Nat. Electron._ **4** , 748–756 (2021). 

- 24 12. Chen, W. et al. CMOS-integrated memristive non-volatile computing-in-memory 25 for AI edge processors. _Nat. Electron._ **2** , 420–428 (2019). 

- 26 13. Cheng, C. et al. In-memory computing with emerging nonvolatile memory devices. 27 _Sci. China Inf. Sci._ **64** , 221402 (2021). 

- 28 14. Li, C. et al. Analogue signal and image processing with large memristor crossbars. 29 _Nat. Electron._ **1** , 52–59 (2018). 

- 30 15. Müller, J. et al. Ferroelectricity in simple binary ZrO2 and HfO2. _Nano Lett._ **12** , 8, 31 4318–4323 (2012). 

19 

- 1 16. Böscke, T. S., Müller, J., Bräuhaus, D., Schröder, U. & Böttger, U. Ferroelectricity 2 in hafnium oxide thin films. _Appl. Phys. Lett._ **99** , 102903 (2011). 

- 3 17. Cheema, S. S. et al. Enhanced ferroelectricity in ultrathin films grown directly on 4 silicon. _Nature_ . **580** , 478–482 (2020). 

- 5 18. Cheema, S. S. et al. Emergent ferroelectricity in subnanometer binary oxide films 6 on silicon. _Science_ . **376** , 648-652 (2022). 

- 7 19. Gao, Z. et al. Identification of ferroelectricity in a capacitor with ultra-thin (1.58 nm) Hf0.5Zr0.5O2 film. _IEEE Electron Device Lett._ **42** , 1303-1306 (2021). 

- 9 20. Khan, A. I., Keshavarzi, A. & Datta, S. The future of ferroelectric field-effect 

- 10 transistor technology. _Nat. Electron._ **3** , 588–597 (2020). 

- 11 21. Schroeder, U., Park, M. H., Mikolajick, T. & Hwang, C. S. The fundamentals and 12 applications of ferroelectric HfO2. _Nat. Rev. Mater._ , 1–17 (2022). 

- 13 22. Jerry, M. et al. Ferroelectric FET analog synapse for acceleration of deep neural 14 network training. In _2017 IEEE International Electron Devices Meeting (IEDM)_ 15 6.2.1-6.2.4. (IEEE, 2017). 

- 16 23. Ni, K. et al. SoC logic compatible multi-bit FeMFET weight cell for neuromorphic 17 applications. In _2018 IEEE International Electron Devices Meeting (IEDM)_ 18 13.2.1-13.2.4. (IEEE, 2018). 

- 19 24. Sun, X., Wang, P., Ni, K., Datta, S. & Yu, S. Exploiting hybrid precision for training 20 and inference: a 2T-1FeFET based analog synaptic weight cell. In _2018 IEEE_ 21 _International Electron Devices Meeting (IEDM)_ 3.1.1-3.1.4. (IEEE, 2018). 

- 22 25. Tong, L. et al. 2D materials-based homogeneous transistor-memory architecture 23 for neuromorphic hardware. _Science_ . **373** , 1353–1358 (2021). 

- 24 26. Zhang, W. et al. Neuro-inspired computing chips. _Nat. Electron._ **3** , 371–382 (2020). 

- 25 27. Luo, Q. et al. A highly CMOS compatible hafnia-based ferroelectric diode. _Nat._ 26 _Commun._ **11** , 1391 (2020). 

- 27 28. Radisavljevic, B., Radenovic, A., Brivio, J. et al. Single-layer MoS2 transistors. 28 Nature Nanotech **6** , 147–150 (2011). 

- 29 29. Akinwande, D. et al. Graphene and two-dimensional materials for silicon 30 technology. _Nature_ . **573** , 507–518 (2019). 

- 31 30. Liu, C. et al. Two-dimensional materials for next-generation computing 32 technologies. _Nat. Nanotechnol._ **15** , 545–557 (2020). 

20 

- 1 31. Marega, M. et al. Logic-in-memory based on an atomically thin semiconductor. 2 _Nature_ **587,** 72–77 (2020). 

- 3 32. Chung, Y.-Y. et al. High-accuracy deep neural networks using a contralateral-gated 4 analog synapse composed of ultrathin MoS2 nFET and nonvolatile charge-trap 5 memory. _IEEE Electron Device Lett._ , 1–1 (2020). 

- 6 33. Chen, L., Pam, M. E., Li, S. & Ang, K. -W. Ferroelectric memory based on two7 dimensional materials for neuromorphic computing. _Neuromorph. Comput. Eng._ **2** , 8 022001 (2022). 

- 9 34. Meng, W. et al. Three-dimensional monolithic micro-LED display driven by 

- 10 atomically thin transistor matrix. _Nat. Nanotechnol._ **16** , 1231–1236 (2021). 

- 11 35. Schram, T., Sutar, S., Radu, I. & Asselberghs, I. Challenges of wafer‐scale 12 integration of 2D semiconductors for high‐performance transistor circuits. _Adv._ 13 _Mater._ **2109796** (2022). 

- 14 36. Waltl, M. et al. Perspective of 2D integrated electronic circuits: scientific pipe 15 dream or disruptive technology? _Adv. Mater._ **2201082** (2022). 

- 16 37. Chai, Y. In-sensor computing for machine vision. _Nature_ . **579** , 32–33 (2020). 

- 17 38. Mennel, L. et al. Ultrafast machine vision with 2D material neural network image 18 sensors. _Nature_ . **579** , 62–66 (2020). 

- 19 39. Li, T. et al. Epitaxial growth of wafer-scale molybdenum disulfide semiconductor 20 single crystals on sapphire. _Nat. Nanotechnol_ . **16** , 1201–1207 (2021). 

- 21 40. Müller, J. et al., Ferroelectric hafnium oxide: A CMOS-compatible and highly 22 scalable approach to future ferroelectric memories. In _2013 IEEE International_ 23 _Electron Devices Meeting (IEDM)_ 10.8.1-10.8.4 (IEEE, 2013). 

- 24 41. N. Gong & T. -P. Ma, A Study of Endurance Issues in HfO2-Based Ferroelectric 25 Field Effect Transistors: Charge Trapping and Trap Generation. _IEEE Electron_ 26 _Device Lett._ **39** , 1, 15-18 (2018). 

- 27 42. Y. Liu et al., 4.7 A 65nm ReRAM-enabled nonvolatile processor with 6× reduction 28 in restore time and 4× higher clock frequency using adaptive data retention and 29 self-write-termination nonvolatile logic. In _2016 IEEE International Solid-State_ 30 _Circuits Conference (ISSCC)_ 84-86 (IEEE, 2016). 

- 31 43. _International Roadmap for Devices and Systems (IRDS_<sup>TM</sup> _) 2021 Edition_ (IEEE, 32 2021); _<u>https://irds.ieee.org/editions/2021</u>_ . 

21 

- 1 44. <mark>Krivokapic, Z. et al.</mark> 14nm Ferroelectric FinFET technology with steep 2 subthreshold slope for ultra low power applications. In _2017 IEEE International_ 3 _Electron Devices Meeting (IEDM)_ 15.1.1-15.1.4 (IEEE, 2017). 

- 4 45. Dünkel, S. et al. A FeFET based super-low-power ultra-fast embedded NVM 5 technology for 22nm FDSOI and beyond. In _2017 IEEE International Electron_ 6 _Devices Meeting (IEDM)_ 19.7.1-19.7.4 (IEEE, 2017). 

- 7 46. Zhao, C., Sun, Q., Zhang, C., Tang, Y. & Qian, F. Monocular depth estimation 8 based on deep learning: An overview. _Sci. China Technol. Sci._ **63** , 1612–1627 9 (2020). 

- 10 47. Alhashim, I. & Wonka, P. High quality monocular depth estimation via transfer 11 learning. Preprint at https://arxiv.org/abs/1812.11941 (2018). 

- 12 48. Ronneberger, O., Fischer, P. & Brox, T. U-Net: convolutional networks for 13 biomedical image segmentation. In _Medical Image Computing and Computer-_ 14 _Assisted Intervention – MICCAI_ 234-241 (Springer, 2015). 

22 

- 1 

# **Methods:** 

- 2 **The fabrication of the duplex FeFET/ TIIO Array** . 

- 3 On the p-type silicon substrate with 275 nm SiO2, back gate (M1) was defined by 4 electron beam lithography (EBL), 3 nm Ti/9 nm Pt were deposited by electron beam 5 evaporator (EBE). 16 nm H0.5Z0.5O2 (HZO) film was deposited at 200℃ by atomic layer 6 deposition (ALD) using precursors TDMA-Hf and TDMA-Zr, while water as the 7 oxygen source. Next, floating gate (FG) was defined by EBL, and about 14nm Pt were 8 evaporated using EBE. With FG metal covered, crystallizing of ferroelectric HZO was 9 realized by rapid thermal annealing (RTA) at 450℃ in N2 atmosphere for 30s. 12 nm 

- 10 HfO2 film was deposited at 150℃ by ALD using precursor TEMA-Hf, while O2 plasma 11 as the oxygen source. 

- 12 There are slight differences for fabrication of TIIO array. During the substrate 13 fabrication, the input line and output line were made with M1 metal. The 14 training/inference word line was made with M2 metal. The bit line and hidden nodes 15 were made with M3 metal. Interconnection via was defined by EBL and etched using 16 BCl3/Ar by GSE C200 Series Plasma Etcher, with Pt as etch stop after M1, M2 and 17 dielectric. There were 4 different via types in a TIIO array: M1-M3, The input line in 18 connection with drain of the FeFET; M1-M3, The bottom metal in connection with 19 source of selector FET; M1, For probing the input line and output line; M2, For probing 20 the training/inference word line. The size and distribution of pads were specially 21 designed for customized probe cards. 

- 22 Single-crystalline monolayer MoS2 films were grown on custom-designed C/A23 plane sapphire wafers in a home-made CVD furnace. Assisted by 35nm flat Au films, 24 the MoS2 film was transferred to target substrate by PMMA and PDMS. 25 PDMS/PMMA/Au stack was laminated on fresh new MoS2/sapphire. Next, MoS2 was 26 dry-delaminated from the sapphire and transferred onto substrates with pre-patterned 27 gate layout in glovebox. Then, the unnecessary Au/MoS2 (defined by EBL) was 28 removed by sequential Au etching (using Transense TFA) and MoS2 etching (using SF6 29 and O2 plasma in reactive ion etcher (RIE)). The last step of EBL defined the 30 Source/Drain pattern, and M3 metal of 10nm Ti/35nm Pd/10 nm Ti were deposited by 31 EBE. Finally, self-aligned etch was performed to open channel via S/D metal mask 

- 32 using Transense TFA. An annealing (200℃) was performed to remove adsorbates and 33 improve contact with base pressure ~10<sup>-6</sup> Pa in vacuum atmosphere. 

23 

- 1 **Electrical measurement of duplex FeFET** 

- 2 We developed a home-made system for the various _in-situ_ measurements of 3 FeFET and TIIO array. The system contained Keithley 4200 semiconductor 4 characterization system (SCS) with 4 SMUs for DC test and 4225- remote pulse and 5 switch module (RPM) for pulse test, a National Instruments (NI)-PXIe 2532B matrix 6 switch (with 8×64 terminal block), PXIe-5433 arbitrary waveform generator (AWG) 7 and Keysight MSOX6004A oscilloscope. 

- 8 The transfer and output characteristics were measured by SMUs with pre-amplifier, 9 which enable a current resolution of 0.1 fA _._ As for data retention, the FeFET was 

- 10 programmed to ON state or erased to OFF state, then a DC sampling test ran for 11 thousands of seconds. In addition, we measured retention at temperatures of 85<sup>o</sup> C and 12 125<sup>o</sup> C in a vacuum atmosphere in the Lake Shore CRX-VF probe station. We 13 extrapolated the high-temperature 10-year retention by linear fitting. 

- 14 In the multi-state test, potentiation and degression were realized by positive and 15 negative pulses, generated by 4225-RPMs. While applying pulses at gate, the drain and 16 source of FET were both grounded. Once the pulse finished, we ground the gate and 17 applied Vds to read the conductance of FeFET. For a shorter pulse width in the speed 18 test, we switched to NI PXIe-5433 AWG, which can generate pulses with amplitudes 19 up to 10 V and pulse widths as small as 4.8 ns. A Keysight MSOX6004A oscilloscope 20 was used here to collect real-time pulse amplitude and width. The mode of AWG was 21 set to user-defined waveform, list output, and immediate trigged. The duration was set 22 carefully to make sure that only one pulse generated for every output. In endurance test, 23 based on the AWG, we change the duration to output a sequence of identical pulses, 24 with different cycles number of 1, 10, 1E3, 1E4, …, 1E13. At the very end of one 

- 25 sequence, we check the transfer curve of FeFET to monitor the performance 26 degradation. Considering the time spent was very large for 1E12, 1E13 cycling, we just 27 measured Ion and Ioff for discrete cycles rather than every cycle. 

- 28 **Hardware** **_in-situ_ machine learning on TIIO array** 

- 29 In the array measurement, we modified the vacuum probe station to meet the 

- 30 special requirements. The NI PXIe 2532B matrix switch, in the 8×64 terminal set-up, 

24 

- 1 helped connect the SMUs/PMUs test sources with the device under test (DUT). We 2 loaded two customized probe cards (12 pins for A, 15 pins for B) on the original arms 3 in the probe station. These probe cards were electrically connected with flexible flat 

- 4 cables (FFC), adapters, cable hub (48-line feed through), and in the end, the test 5 instruments outside. All the test were performed in the vacuum environment. 

- 6 For training process, we added one PC here in connected with Keithley 4200 SCS 7 for running program codes, which defined the initial parameters and hyperparameters, 8 flow of ANN training, interfaces for software-hardware interaction, and related data 9 processing. On the level of hardware, two selectors share one drain in one 2T1D cell, 

- 10 thus the operation mode depends on which word line (T- or I-type) accesses the duplex 11 FeFET. A typical process is mode transferring from training to inference, which means 12 resetting the T-type capacitor, switching to I-word line, and programing I-type capacitor 13 to a well-trained weight. More details about the algorithm can be found in the 14 Supplementary Note 4. 

- 15 

# **Device modeling and hardware evolution** 

16 Based on the measuring results of duplex FeFET devices (Supplementary Fig. 6,7), 

- 17 we constructed two variation models for the inference and training, respectively. 18 Without loss of generality, random variables sampled from the Gaussian distribution 19 with zero mean and σ<sup>2</sup> variance are used to simulate the inference and training variation. 20 A linear variation model is used in this work. 

- 21 



<!-- Start of picture text -->
𝑊𝑤/ 𝑛𝑜𝑖𝑠𝑒  = 𝑊𝑤/𝑜 𝑛𝑜𝑖𝑠𝑒  + 𝑊𝑤/𝑜 𝑛𝑜𝑖𝑠𝑒 × 𝑁𝑜𝑖𝑠𝑒𝑤𝑒𝑖𝑔ℎ𝑡𝑠 ,   (2)<br><!-- End of picture text -->

22 



<!-- Start of picture text -->
𝑁𝑜𝑖𝑠𝑒𝑤𝑒𝑖𝑔ℎ𝑡𝑠~𝑁(0, 𝜎𝑤𝑒𝑖𝑔ℎ𝑡𝑠2 ). (3)<br><!-- End of picture text -->

- 23 The standard deviation σweights is 0.056 μS (3μm Lch) and 0.040μS (scaled device, 

- 24 85nm Lch). 

- 25 Similar to the inference variation, a similar linear model is used to simulate the training 

- 26 variation: 

27 



<!-- Start of picture text -->
𝑉𝑢𝑝𝑑𝑎𝑡𝑒 𝑤/ 𝑛𝑜𝑖𝑠𝑒  = 𝑉𝑢𝑝𝑑𝑎𝑡𝑒 𝑤/𝑜 𝑛𝑜𝑖𝑠𝑒  + 𝑉𝑢𝑝𝑑𝑎𝑡𝑒 𝑤/𝑜 𝑛𝑜𝑖𝑠𝑒 × 𝑁𝑜𝑖𝑠𝑒𝑢𝑝𝑑𝑎𝑡𝑒, (4)<br><!-- End of picture text -->



<!-- Start of picture text -->
28<br><!-- End of picture text -->



<!-- Start of picture text -->
𝑁𝑜𝑖𝑠𝑒𝑢𝑝𝑑𝑎𝑡𝑒~𝑁(0, 𝜎𝑢𝑝𝑑𝑎𝑡𝑒2 ). (5)<br><!-- End of picture text -->

25 

- 1 The standard deviation σupdate is 0.043 μS (3μm Lch) and 0.017μS (scaled device, 2 85nm Lch). 

- 3 **Dataset and neural network structure in monocular depth estimation** 

- 4 We evaluated our devices on a monocular pixel-level depth prediction task based 5 on a subset of the KITTI dataset. The data in KITTI dataset is captured by driving 6 around in rural areas and on highways in the mid-size city of Karlsruhe. The dataset 7 comprises stereo and optical flow image pairs, stereo visual odometry sequences, and 8 object annotations captured scenarios<sup>49</sup> . In this work, we tried to predict the depth of 9 each pixel in the raw RGB images from a monocular camera. We randomly selected 

- 10 2,802 images for training and 608 images for the test. 

- 11 We simulated a transfer learning algorithm to demonstrate the superiority of TIIO 12 architecture in both inference and training. The neural network adopts the U-Net 13 structure, which consists of the encoder and decoder<sup>47,48</sup> . The encoder is realized by a 14 169-layer DenseNet<sup>50</sup> with four dense blocks and four transition blocks. The decoder 15 is realized by a convolutional layer and five upsampling blocks. Each upsampling block 

- 16 contains a bilinear upsampling layer and two convolutional layers with Leaky-ReLU 

- 17 activations. The four dense blocks in the encoder are connected to the first four 

- 18 upsampling blocks, respectively. The whole network configuration is shown in 

- 19 Supplementary Table 9. The encoder is pretrained on ImageNet classification task<sup>50,51</sup> . 

- 20 While the decoder is randomly initialized using a uniform model and trained for this 

- 21 depth prediction task with the encoder together. 

- 22 **Training details in monocular depth estimation** 

- 23 The loss function with L1-norm loss and structural similarity (SSIM) loss<sup>52</sup> is 

- 24 used: 

- 25 



<!-- Start of picture text -->
𝐿𝑜𝑠𝑠 = 𝜆𝐿1(𝑦, ŷ) + 𝐿𝑆𝑆𝐼𝑀(𝑦, ŷ) ,   (6)<br><!-- End of picture text -->

- 26 where y indicates predicted image and ŷ indicates ground truth. The pixel-wise 

- 27 L1-norm loss is defined as: 

- 28 



<!-- Start of picture text -->
𝐿1(𝑦, ŷ) = 𝑛1 ∑|𝑦𝑛𝑝 𝑝 −ŷ𝑝 |. (7)<br><!-- End of picture text -->

- 29 The SSIM loss is defined as: 

26 

1 



<!-- Start of picture text -->
1−𝑆𝑆𝐼𝑀(𝑦,ŷ)<br>𝐿𝑆𝑆𝐼𝑀(𝑦, ŷ) = . (8)<br>2<br><!-- End of picture text -->

- 2 

   - λ is set to 0.1 in this work. 

- 3 To update the weights according to the gradients, a series of identical pulses are 

- 4 applied on the duplex FeFET devices and the without-verify strategy is used in this 

- 5 simulation. When the gradient is less than a quarter of the average change of one 6 pulse, the devices will not be changed. 

7 The other parameter setting of the training are listed in Supplementary Table 10. 

8 

# **Evaluation of predicted depth** 

9 We evaluated the accuracy of predicted depth with different tolerant level (δ1, δ2, δ3), 10 the absolute relative depth error ( _abs_ Rel.), the root mean square error of depth (RMS), 11 and the Log Mean Absolute Error ( _log_ MAE)<sup>53</sup> of our duplex FeFET _in-situ_ training 12 algorithm. The predicted depth of a pixel is considered correct with tolerant level δ 13 depending on whether the relative error between the predicted depth and the ground 14 truth is smaller than δ. 

- 15 



<!-- Start of picture text -->
𝑑𝑒𝑝𝑡ℎ𝑝𝑟𝑒𝑑 𝑑𝑒𝑝𝑡ℎ𝑔𝑡<br>, (9)<br>𝑚𝑎𝑥( 𝑑𝑒𝑝𝑡ℎ𝑔𝑡 𝑑𝑒𝑝𝑡ℎ𝑝𝑟𝑒𝑑 ) < δ.<br><!-- End of picture text -->

16 The tolerant level used in this work is 1.25, 1.25<sup>2</sup> , and 1.25<sup>3</sup> . The other evaluation 

17 indicators are calculated as follows. 

18 



<!-- Start of picture text -->
19<br><!-- End of picture text -->



<!-- Start of picture text -->
20<br><!-- End of picture text -->



<!-- Start of picture text -->
1 |𝑦𝑝𝑟𝑒𝑑−𝑦𝑔𝑡|<br>𝑎𝑏𝑠 Rel. = ∑ , (10)<br>n 𝑦𝑔𝑡<br><!-- End of picture text -->



<!-- Start of picture text -->
1<br>n |𝑦𝑝𝑟𝑒𝑑 −𝑦𝑔𝑡| 2 , (11)<br>RMS = √<br><!-- End of picture text -->



<!-- Start of picture text -->
1<br>𝑙𝑜𝑔 MAE = n ∑|𝑙𝑜𝑔(𝑦𝑝𝑟𝑒𝑑) −𝑙𝑜𝑔(𝑦𝑔𝑡)|. (12)<br><!-- End of picture text -->

21 The comparisons between GPU and TIIO are shown in Extended Data Fig 10. 



<!-- Start of picture text -->
22<br><!-- End of picture text -->

27 

- 1 **Data availability:** Source data are provided with this paper. 

- 2 

- 3 **Code availability:** The codes used to build the interfaces (0~3) in the demonstrations 

- 4 in Fig. 3, and used for the simulations in Extended Data Fig. 8 are available from the 

- 5 corresponding author upon reasonable request. 

- 6 

- 7 

28 

- 1 **Methods-only references:** 

- 2 49. Geiger, A., Lenz, P. & Urtasun, R. Are we ready for autonomous driving? The 3 KITTI vision benchmark suite. In _2012 IEEE Conference on Computer Vision and_ 4 _Pattern Recognition (CVPR)_ 3354-3361 (IEEE, 2012). 

- 5 50. Huang, G., Liu, Z., Maaten, L. V. D. & Weinberger, K. Q. Densely connected 6 convolutional networks. In _2017 IEEE Conference on Computer Vision and Pattern_ 7 _Recognition (CVPR)_ 2261-2269 (IEEE, 2017). 

- 8 51. Deng, J. et al. ImageNet: A large-scale hierarchical image database. In _2009 IEEE_ 9 _Conference on Computer Vision and Pattern Recognition (CVPR)_ 248-255 (IEEE, 

- 10 2009). 

- 11 52. <mark>Wang, Z., Bovik, A. C., Sheikh, H. R. & Simoncelli, E. P. Image quality assessment:</mark> 12 <mark>from error visibility to structural similarity.</mark> _<mark>IEEE Transactions on Image</mark>_ 13 _<mark>Processing</mark>_ **<mark>13</mark>** <mark>, 600-612 (2004).</mark> 

- 14 53. Eigen, D., Puhrsch, C. & Fergus, R. Depth Map Prediction from a Single Image 15 using a Multi-Scale Deep Network. In _the 28th Conference on Neural Information_ 16 _Processing Systems (NIPS)_ (NIPS, 2014). 

- 17 

29 

