# How to GIWAXS: Grazing Incidence Wide Angle X‐Ray Scattering Applied to Metal Halide Perovskite Thin Films

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Advanced Energy Materials |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 208 |
| 作者 | J. Steele, E. Solano, David Hardy, Damara G Dayton, Dylan M. Ladd, K. White, Peng Chen, Jing-Wei Hou et al. |
| DOI | 10.1002/aenm.202300760 |
| 源文件 | 045_Steele_2023_How-to-GIWAXS-Grazing-Incidence-Wide-Angle-XRay.pdf |

---
**PERSPECTIVE** 



**www.advenergymat.de** 

# **How to GIWAXS: Grazing Incidence Wide Angle X-Ray Scattering Applied to Metal Halide Perovskite Thin Films** 

_Julian A. Steele,* Eduardo Solano, David Hardy, Damara Dayton, Dylan Ladd, Keith White, Peng Chen, Jingwei Hou, Haowei Huang, Rafikul Ali Saha, Lianzhou Wang, Feng Gao, Johan Hofkens, Maarten B. J. Roeffaers, Dmitry Chernyshov, and Michael F. Toney_ 

## **1. Introduction** 

**The frequency of reports utilizing synchrotron-based grazing incident wide angle X-ray scattering (GIWAXS) to study metal halide perovskite thin films has exploded recently, as this technique has proven invaluable for understanding several structure-property relationships that fundamentally limit optoelectronic performance. The GIWAXS geometry and temporal resolution are also inherently compatible with in situ and operando setups (including ISOS protocols), and a relatively large halide perovskite research community has deployed GIWAXS to unravel important kinetic and dynamic features in these materials. Considering its rising popularity, the aim here is to accelerate the required learning curve for new experimentalists by clearly detailing the underlying analytical concepts which can be leveraged to maximize GIWAXS studies of polycrystalline thin films and devices. Motivated by the vast range of measurement conditions offered, together with the wide variety of compositions and structural motifs available (i.e., from single-crystal and polycrystalline systems, to quantum dots and layered superlatices), a comprehensive framework for conducting effective GIWAXS experiments is outlined for different purposes. It is anticipated that providing a clear perspective for this topic will help elevate the quality of future GIWAXS studies—which have become routine—and provide the impetus required to develop novel GIWAXS approaches to resolve unsettled scientific questions.** 

The remarkable progress of metal halide perovskite-based optoelectronics holds promise for several types of next-generation technologies, including cheap and efficient solar cells.<sup>[1]</sup> Their widespread success is due, in part, to a relatively unique ability to preserve highquality optoelectronic performance<sup>[2]</sup> while being easily solution-processed into grainy, polycrystalline films.<sup>[3]</sup> Combined with their inherently diverse materials chemistry, dimensionality (e.g., 0D, 1D, 2D, and 3D systems), and fabrication methods, the scope of reported short- and long-range crystalline structure in perovskite thin films has accelerated in recent years. We will herein refer to this multi-length scale structural order as simply the thin film structure, encompassing features like crystal phase, lattice unit cells, structural disorder, the population of present phase(s), and the preferential orientation of individual grains or structural 

J. A. Steele, P. Chen, J. Hou, L. Wang Australian Institute for Bioengineering and Nanotechnology The University of Queensland Brisbane, Queensland 4072, Australia E-mail:julian.steele@kuleuven.be J.A.Steele School of Mathematics andPhysics TheUniversity of Queensland Brisbane,Queensland4072,Australia 

The ORCID identification number(s) for the author(s) of this article can be found under https://doi.org/10.1002/aenm.202300760 © 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH. This is an open access article under the terms of the Creative Commons Attribution-NonCommercial License, which permits use, distribution and reproduction in any medium, provided the original work is properly cited and is not used for commercial purposes. 

J. A. Steele, H. Huang, R. A. Saha, M. B. J. Roeffaers cMACS Department of Microbial and Molecular Systems KU Leuven Leuven 3001, Belgium E. Solano NCD-SWEET beamline ALBA Synchrotron Light Source Cerdanyola del Vallès, Barcelona 08290, Spain D. Hardy, F. Gao Department of Physics Biomolecular and Organic Electronics Chemistry and Biology (IFM) Linköping University Linköping 58183, Sweden D. Dayton, D. Ladd, K. White, M. F. Toney Materials Science and Engineering Program University of Colorado Boulder Boulder, CO 80309, USA 

### **DOI: 10.1002/aenm.202300760** 

**2300760 (1 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



### **www.advancedsciencenews.com** 

domains. With the materials portfolio in halide perovskite research rapidly expanding, both the accurate characterization and optoelectronic implications of perovskite structure has needed to keep pace,<sup>[4]</sup> as several structure-property relationships have been fundamentally linked to important device metrics;<sup>[2,5–8]</sup> for example, environmental stability (i.e., response to changes in temperature, light, atmosphere), effective scaling of production (i.e., crystallization behavior and the formation of pinholes), and the capacity to yield efficient photo-conversion (photovoltaics) or -emission (light emitting diodes; LEDs). This has reinforced the paradigm that structure defines properties in perovskite research, though the exact structure of the film can in fact remain ambiguous.<sup>[4]</sup> 

Within this context, synchrotron-based grazing incident wide angle X-ray scattering (GIWAXS) has emerged as an essential technique to probe and understand the structure of perovskite thin films.<sup>[4,9–11]</sup> The relatively rapid and widespread adoption of GIWAXS experiments has ultimately introduced ambiguity into the design, reporting and interpretation of GIWAXS data. Our aim in this work is to fast-track the learning curve required for newcomers to employ synchrotron-based GIWAXS experiments to resolve significant structural questions: Beginning from the basics of X-ray scattering from a (poly)crystalline thin film in a grazing incidence geometry, we detail the fundamental phenomenological and analytical concepts underpinning GIWAXS experiments when applied to multi-phase metal halide perovskite thin film systems. Combined with the ability to optimize important experimental parameters (e.g., X-ray energy, sample-todetector distance and grazing incidence angle) and sample environment (such as temperature and atmosphere), we take a holistic approach to effective experimentation by considering the design, execution and analysis of measurements from start to finish; see **Figure 1** . Toward this end, the paper is broken into three general sections. 

Starting from the fundamentals of light-matter interactions, and how the material chemistry and thin film structure influence the observed X-ray scattering signal, Section 2 examines the range of experimental considerations involved in synchrotronbased GIWAXS. We provide a detailed look into the principles of X-ray diffraction in a grazing geometry, show how the reciprocal space recorded by the large-area detector should be interpreted, and offer a useful perspective for unique GIWAXS signatures found in metal halide perovskite thin films. Due to its 

|J. Hofkens|
|---|
|Department of Chemistry|
|KU Leuven|
|Celestijnenlaan 200F, Leuven 3001, Belgium|
|J. Hofkens|
|Max Plank Institute for Polymer Research|
|D-55128 Mainz, Germany|
|D. Chernyshov|
|Swiss-Norwegian Beamlines at the European Synchrotron Radiation<br>Facility|
|71 Avenue des Martyrs, Grenoble F-38000, France|
|M. F. Toney|
|Renewable and Sustainable Energy Institute (RASEI)<br>University of Colorado Boulder|
|Boulder, CO 80309, USA|



### **www.advenergymat.de** 

fundamental importance, the role of the grazing incidence angle is given detailed treatment, which governs features like the incident beam’s footprint and penetration depth, as well as anomalous refraction effects including waveguiding within a thin film. 

With a well-developed understanding of the principles of GIWAXS, Section 3 presents examples of GIWAXS data analysis in action. This includes the identification of phase and symmetry changes, and methods to verify structural characteristics via simulations of both the 2D GIWAXS images and their 1D azimuthally integrated profiles. Within this context, there exists a growing need to reliably assess hybrid perovskite materials by means of GIWAXS, to accurately determine the structure and space group of the perovskites when fashioned into thin films, as well as resolve important structure-property relationships.<sup>[12]</sup> While several Review articles have recently covered aspects of GIWAXS on metal halide perovskites,<sup>[4,9,10,13]</sup> our goal here is different from these, as we elucidate the important considerations for completing reliable measurements, their interpretation, and realizing a quantitative analysis of the integrated GIWAXS patterns. These all support meaningful comparison of material characteristics. 

Considering first the management of beam damage and the technical requirements of in situ parameter control, Section 4 showcases emerging in situ GIWAXS techniques which are enabling important discoveries in halide perovskite thin film research. This encompasses the evaluation of dynamic and kinetic aspects of the film like grain rotations, liquid-solid crystallization kinetics and degradation pathways which limit device longevity. By comprehensively covering the major aspects of GIWAXS experimental design, execution and interpretation, it is anticipated that this work will assist experimentalists utilizing this popular technique. We herein address often overlooked and un-optimized critical measurement parameters to guide and enable informed experimental design, thus assisting the community to effectively resolve their own scientific questions. 

## **2. Fundamentals of Synchrotron GIWAXS** 

X-ray diffraction (XRD) has become a routine technique to assess the atomic and crystalline structure of solids. As such, the fundamental principles of XRD have been extensively detailed elsewhere.<sup>[14,15]</sup> Nevertheless, it is important to position these principles clearly within the context of metal halide perovskites, that is, considering their unique compositions ( **Figure 2** A) and structural motifs, which currently forms a relatively large and interesting materials parameter space. Figure 1 provides an illustrative summary of the topics covered in this section; beginning with the basics of light-matter interactions and instrumental limitations, we build toward a rational framework for understanding GIWAXS experiments performed on different metal halide perovskite thin films compositions and structures. We explore how GIWAXS experiments capture the structural properties of the film, as encoded in the shape, width, and azimuthal angular distribution ( _𝜒_ ) of Debye-Scherrer diffraction rings (Figure 1). Finally, it will become evident that collecting quality GIWAXS data suitable for reliable Rietveld refinement or texture analysis (Section 3) is far from trivial, and our goal is to demonstrate how to carefully shape the design of meaningful GIWAXS experiments. Within this context, we clearly link several key scientific and 

**2300760 (2 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



### **www.advancedsciencenews.com** 

### **www.advenergymat.de** 



**Figure 1.** Illustrative overview of the fundamental aspects to consider when designing a synchrotron-based GIWAXS experiment for metal halide perovskite thin films. By identifying the target perovskite composition, film structure, and important environmental parameters, one can set out to optimize the experimental procedure. 

technical aspects of GIWAXS experiments which are commonly applied within metal halide perovskite research. 

### **2.1. Radiation-Matter Interactions** 

X-ray diffraction experiments require elastic scattering events, although some electromagnetic radiation can also be inelastically scattered, as well as absorbed and emitted.<sup>[15,16]</sup> For example, while metal halide perovskites commonly contain relatively heavy Pb atoms, metallic lead is widely known as an effective X- ray shielding/stopping material and exhibits strong X-ray luminescence which can be detected as background. Combined with a high-brilliance light source, the dose of ionizing radiation can be significant and must be managed to limit beam damage (Section 4.1). As the compositional space of metal halide perovskites grows, and as the exploration of doping elements and hybrid organic-inorganic structures become more complex (Figure 2A), these interactions are increasingly important to consider. 

wavevectors defines the resultant scattering vector; _⃗ q_ = _⃗ kf_ − _⃗ kf_ . The value of _fa_ reaches a maximum in the same direction of the incident X-rays (sin _𝜃_ / _𝜆_ = 0; _q_ = 0), and decreases as a function of the scattering angle ( _𝜃_ ), that is, scattering intensity reduces with growing _q_ ; Figure 2B. 

Atomic scattering factors are calculated via a Fourier transform of the atomic electron density and their values can be found in the International tables of Crystallography, volume C:<sup>[17]</sup> 



<!-- Start of picture text -->
(1)<br>fa ( q ) = ∫ 𝜌 ( r )  e iqr dr<br><!-- End of picture text -->

Here _𝜌_ ( _r_ ) is the electronic density around the atom and _r_ is the distance from the center of mass, where for the limit _q_ → 0, _fa_ → _Z_ , while for _q_ → ∞, _fa_ → 0. Therefore, the scattering amplitude at a given _q_ is directly related to both the X-ray wavelength/energy and increases with the Z (Figure 2B). For a diffracting crystal, the structure factor _F_ captures the sum of the atomic scattering factors for the different N-elements in a unit cell, at _Rj_ : 

### _2.1.1. Scattering_ 

Compared to scattering off one free electron, the amplitude of the X-rays scattered by the electrons in a given atomic shell represents the atomic scattering factor, _fa_ . Thus, _fa_ will not only scale with the number of electrons in an atom, but also their density, meaning that charged ions of the same atomic number “Z” will have different form factors. Through the scattering process, the electrons oscillate to form a dipole and a spherical wave is sent back out. The difference in the incoming ( _⃗ki_ ) and outgoing ( _k⃗ f_ ) 



<!-- Start of picture text -->
N<br>F = ∑ f ( j )} e − iqRj (2)<br>j =1<br><!-- End of picture text -->

The intensity of the scattered radiation _I_ ( _q_ ) for crystals is proportional to the square of the form factor ( _F_ ) and is by: 



<!-- Start of picture text -->
I ( q ) = | F | 2 × LP ×  A (3)<br><!-- End of picture text -->

where _A_ accounts for the X-ray absorption and LP embodies the combination geometric and polarization factors at the beamline. 

**2300760 (3 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.advenergymat.de** 



**Figure 2.** A) Summary of the different elements reported in metal halide perovskite compounds and their doped derivatives, encompassing common chemical architectures. The general crystal structures corresponding to cubic single (ABX3) and double (A2B’B’’X6) perovskites are shown along the top. Reproduced with permission.<sup>[19]</sup> Copyright 2019, The Authors, published by American Association for the Advancement of Science. B) Elastic scattering factor of the common elements forming the perovskite structures of interest for different _q_ values. The inset illustrates the relative incoming and outgoing intensity of scattering X-rays in real-space for the example of carbon, that is, as the angle of scatting increases the magnitude of scatting decreases. C) Mass attenuation and normalized X-ray fluorescence emission lines for different elements. The data have been extracted from the X-ray database project: https://github.com/xraypy/XrayDB. D) Origin of atomic X-ray emission: a core electron is excited by synchrotron photons and then decays by emitting a characteristic X-ray photon to fill the core hole. 

Notably, the multiplicity of the reflection, that is, the number of symmetry-equivalent reflections contributing to the single observed peak, will influence the observed intensity. 

### _2.1.2. Absorption_ 

X-ray absorption is the process of beam attenuation within the material, commonly described by: 

_It_ = _I_ 0 _e_<sup>−</sup><sup>_𝜇d_</sup> (4) 

where _It_ and _I_ 0 are the transmitted and incident intensities and _d_ the material thickness. Since _μ_ , the linear absorption coefficient, depends on the material density, it can be transformed to the mass attenuation coefficient by dividing by the material density ( _𝜌_ ). 

Parameter _μ_ contains all possible effects of X-ray attenuation; namely, contributions from both elastic and inelastic scattering, as well as photoelectric absorption. As observed in Figure 2C, _μ_ strongly scales with _Z_ . For lower X-ray energies (e.g., below 50 keV, depending on the material), the total mass absorption is dominated by the photoelectric effect<sup>[18]</sup> (Figure 1). As X-ray 

**2300760 (4 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.advenergymat.de** 

energy increases, the smooth decline of _μ/𝜌_ is interrupted by a series of sharp rises at elemental absorption edges (Figure 2C). These correspond to the oxidation state-dependent binding energy of characteristic electron orbitals, whereby absorbed X-rays promote electrons to higher energetic levels, or to continuum, leaving the atom in an excited state (Figure 2D). 

### _2.1.3. Emission_ 

Following X-ray photo-electric absorption, a secondary result is X- ray emission. Once energized into an excited state, characteristic X-rays are emitted as outer shell electrons of excited atoms lose energy to transition to an unoccupied state at lower energy; this is commonly known as X-ray fluorescence (XRF; Figure 2D). XRF yields emission in all spatial directions from the excited sample volume, acting as a local X-ray photon source. The ability of XRF to penetrate back through and escape from the material depends on their energy. Heavier elements like Pb ( _Z_ = 82) and Sn ( _Z_ = 50) have much more energetic X-rays which will be able to pass through large distances within the sample and reach the detector, in contrast to lighter elements, such as C. 

While the unique X-ray emission lines can serve as atomic fingerprints for chemical identification<sup>[20]</sup> within other contexts, emitted X-rays impinging on the detector will elevate the background intensity. Thus, selecting an X-ray energy above the absorption edge of a high-Z element can be troublesome, as detectable signal contributions from X-ray fluorescence can introduce excess noise and ultimately contribute to the loss of retrievable information. Consequently, signals related to XRF should be minimized to ensure high-quality data. 

GIWAXS experiment that should be considered. We summarize here the key beamline and end stations components that should be considered in the design of GIWAXS studies. 

### _2.2.1. Synchrotron Light Source_ 

GIWAXS requires a monochromatic X-ray source and, due to the grazing incidence and potential for in situ studies (Section 4), a high photon flux (beam “brilliance”). These requirements are generally not satisfied inside of the laboratory and GIWAXS experiments are typically conducted at synchrotron facilities. As illustrated in Figure 1: electrons are injected into a linear accelerator and transferred to the inner ring, before being injected at relativistic speeds (≈ _c_ ) into the main polygon-shaped storage ring. When curved, the electrons in the storage ring produce synchrotron radiation tangentially to the curvature radius (Figure 1). Key features of a synchrotron source include: 

- X-ray source: bending magnets, undulators, or wiggles are used to deflect the path of electrons orbiting in the storage ring to generate vertically collimated X-ray photons with a distribution of energies, fanning out along the synchrotron plane. 

- Monochromatic filtering: different crystal monochromators (e.g., Si(111), Si(220), or Si(311)) are used to select the wavelength of interest from the polychromatic source with a high energy resolution; ≈1 eV or better for a Si (111) monochromator used to filter 12.4 keV photons.<sup>[31]</sup> 

- Focalization/collimation: GIWAXS experiments rely on geometry and the scattering angle to probe reciprocal space, with a non-divergent, collimated beam being preferred. 

- Beam size and shape: a combination of mirrors, slits, and pinholes help to shape the beam dimensions and flux density. 

### _2.1.4. General Recommendations_ 

When exciting far above the absorption edge of a high-Z elements, like Pb, fluorescence signals can arise. For these reasons, GIWAXS experiments conducted on Pb-based perovskites are typically performed just below the L absorption edges (Figure 1), at X-ray beam energies between 10–12.9 keV.<sup>[21–29]</sup> Specific absorption edges for the different elements can be found in the literature<sup>[20,30]</sup> and are recommended to be evaluated before wavelength selection. Nonetheless, the optimal wavelength will also depend on the limitations of the instrument optics and detector response; an effective setup should emerge once the material and instrument are sensibly considered together following the guidance herein. 

- Beam stop: placed in the beam path just shy of the detector to block the direct beam and the spill-over of intense diffuse scattering in the scattering plane. Importantly, its shape and size can limit access to small _q_ . 

- Fast shutter: a fast mechanical system that synchronized with the measurement and blocks irradiation of the sample between data collection, limiting potential beam damage. 

- Sample positioning system: the need for precise geometric alignment of the sample between the incident beam and 2D detector requires a precise motor positioning system. Further, it is essential that the sample surface is centered on the rotation point of the three spatial tilts to avoid a relative translation of the beam with respect to a given tilt direction. 

### _2.2.2. X-Ray Scattering Detection System_ 

### **2.2. Equipment and Instrumental Limitations** 

Synchrotron-based GIWAXS instruments vary throughout the world. The design of a targeted GIWAXS experiment should be based on inherent instrument capabilities and limitations;<sup>[16]</sup> which will differ substantially between beamlines. Such considerations include the available energy range, flux, size, and shape of the incident X-ray beam, focusing optics, 2D area detector properties, as well as the temporal and spatial resolution of the detector. Together, these features define the central capabilities of the any 

The scattered photons are recorded using a pixelated area detector to directly convert X-ray photons into electric signals and map the 2D reciprocal space ( **Figure 3** A). The scattering vector, _⃗ q_ , directly depends on the wavenumber _k_ 0: _k_ 0 = 2 _𝜆𝜋_<sup>(</sup><sup>_𝜆_the monochro-</sup> matic X-rays wavelength), the exiting ( _𝛼f_ , _𝜃f_ ) and incidence ( _𝛼i_ ) angles; note that Section 2.3 provides extended discussion of this topic. Consequently, increasing (decreasing) the X-ray energy implies a reduction (enlarging) of the exiting angles for a given crystallographic scattering plane, _⃗ qB_ . While raising the energy can 

**2300760 (5 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



### **www.advancedsciencenews.com** 



**Figure 3.** A) Pixel detector area and geometrical configuration to calculate the _q_ -space maps for GIWAXS; with _p_ s being the pixel size, _L_ SD the sample-to-detector direct beam distance, _d_ the sample to pixel distance, _r_ the direct beam to pixel distance, _𝛼_ i the incident angle, _𝛼_ f the exiting vertical angle, _𝜃_ f the exiting horizontal angle, and rot1 and rot2 are the detector rotations. B) Calculated of fraction of absorbed X-ray photons by a 300 μm thick semiconductor pixel made from common direction conversion semiconductor materials as a function of irradiation energy. 

access a larger reciprocal space, it hinders the resolving power of the large 2D detector composed of well-defined pixel sizes (Figure 3A). For a fixed sample geometry and sample-to-detector distance, the total reciprocal space mapped depends on the active area of the detector and inversely depends to its distance from the sample. On the other hand, the angular resolution depends directly on the sample-to-detector distance and inversely to the pixel size, whereby increasing the distance equates to better angular resolution. Thus, there exists a compromise struck between gathering a large range in reciprocal space and obtaining data with high-angular resolution. 

Direct X-ray detection is the basis of state-of-the-art hybrid pixel array detector (HPAD),<sup>[32]</sup> which directly converts the photon to an electronic signal, acting as a photon counting detector, since each photon directly registers an event. They are based on the electronic excitation of a semiconductor layer (e.g., Si, Ge, CdTe) and recorded by a complementary metal–oxide– semiconductor (CMOS) system, giving huge versatility and efficiency (unlike older CCD technologies which are still in use). The HPAD technology is characterized by a fast single-photon 

### **www.advenergymat.de** 

counting pixel (negligible noise without cryogenic cooling), good spatial resolution, and versatile working energy range. Notably, however, each type of semiconductor does possess an optimal X- ray energy detection range (Figure 3B) and if the selected energy is far from an optimal response, the detector efficiency will roll off. For example, the half-way drop-off point (where 50% absorption reduction takes place) for different semiconducting detectors will be different, such as Si (18 keV), Ge (45 keV), and CdTe (70 keV). 

### _2.2.3. Reciprocal Space Calibration_ 

In contrast to traditional transmission powder diffraction where only the magnitude of the scattering vector is of interest, the thin film plane within GIWAXS experiments creates a spatial reference frame that requires that each pixel is re-meshed onto an equally spaced 2D grid where each pixel has an in-plane scattering vector component ( _q_ xy) and an out-of-plane component ( _q_ z). Calibration of the scattering vector _⃗ q_ is needed for each instrumental configuration, using a well-known scattering standard; some common examples include powders of Cr2O3, _𝛼_ -Al2O3, ZnO, LaB6, and CeO2. These compounds generate scattering patterns that are projected onto the flat, 2D detector plane. If the detector is perfectly perpendicular to the beam, the diffraction forms circles (eccentricity = 0), while distorted circles (ellipses; 0 _<_ eccentricity _<_ 1) emerge if detector rotations are present with respect to the incident beam. Using the distance between the rings and their observed eccentricity, the known d-spacing of the scattering standard is used to calibrate the GIWAXS image. Several free programs provide command line or graphical user interfaces (GUI) to calculate the detector configuration: pyFAI,<sup>[33,34]</sup> DAWN,<sup>[35,36]</sup> GIXSGUI.<sup>[37]</sup> There are additional corrections to be made in GIWAXS experiments due to the curvature of the Ewald sphere (that is “sliced” by the flat detector plane; Figure 1) and are dealt with in the next section. 

### **2.3. X-Ray Diffraction from Metal Halide Perovskites and the GIWAXS Geometry** 

While the principles of XRD have been exhaustively detailed for decades,<sup>[14]</sup> the combination of the GIWAXS geometry and perovskite films with complex structure warrants another in-depth look. Here, we will start from the basics to build up to a mathematical framework that is capable of cataloguing the various scattering signatures expressed by metal halide perovskites at the thin film-level (Figure 14). 

### _2.3.1. Principles of X-Ray Diffraction_ 

X-ray diffraction is the result of elastic scattering from atoms in the material. The incident X-ray beam diffracts in precise directions at a scattering angle (2 _𝜃_ ), undergoing constructive interference, as predicted by the well-known Bragg’s law ( **Figure 4** A): _n𝜆_ = 2 _d_ sin _𝜃_ . Here _n_ is the order of the diffraction and the direction of the orientated scattering planes, given by Miller indices _h, k, l_ . In reciprocal space, an incident beam with momentum, _⃗ ki_ , is 

**2300760 (6 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.advenergymat.de** 



**Figure 4.** A) Illustration of Bragg diffraction from X-rays scattering off atoms (red circles) positioned along a lattice plane (red line) separated by distance _d_ . B) Scattering wavevector, _q_ , resulting from the wavevector change of the incoming and outgoing waves. C) Plot of _N_ = 20 Gaussian functions with _fwhm_ = _b_ ~~√~~ ln(2) and periodic separation _a_ ; _f_ ( _x_ ) =<sup>∑</sup> _N_<sup>exp[−(</sup><sup>_x_−</sup><sup>_Na_)2∕</sup><sup>_b_2]. D) Normalized amplitudes of the Fourier Transform of function</sup><sup>_f_(</sup><sup>_x_), for</sup> different values of n; _g_ ( _k_ ) ∝ ( _N_<sup>1)</sup><sup>_b_exp(−</sup><sup>_b_2</sup> 4<sup>_k_2) sin(</sup><sup>_Nka_∕2)∕sin(</sup><sup>_ka_∕2).</sup> 

scattered from the crystal with momentum, _⃗ kf_ . It follows that the scattering vector, _⃗ q_ , points orthogonal to the lattice planes (Figure 4B) and is given by 



<!-- Start of picture text -->
q  = ⃗ k f − ⃗ k i (5)<br><!-- End of picture text -->

where _q_ = (<sup>4</sup> _𝜆_<sup>_𝜋_)sin</sup><sup>_𝜃._The Bragg condition is satisfied when the</sup> scattered waves from adjacent lattice planes interfere constructively, simplifying to 



<!-- Start of picture text -->
q =  qB = 2 𝜋 . (6)<br>dhkl<br><!-- End of picture text -->

While the real lattice vectors ( _⃗a,⃗ b,⃗ c_ ) describe the distance and orientation of the unit cells in the crystal, the magnitudes and orientations of _d_ hkl for corresponding lattice plane ( _h,k,l_ ) forms the reciprocal lattice ( _⃗a_<sup>∗</sup> _,⃗ b_<sup>∗</sup> _,⃗ c_<sup>∗</sup> ): _⃗ a_<sup>∗</sup> = 2 _𝜋 a⃗_ ⋅ _b_ ( _b⃗_ ×× _c⃗ c⃗_ )<sup>;</sup><sup>_⃗b_∗=</sup> 2 _𝜋 a⃗_ ⋅ _c_ (× _b⃗_ × _a⃗ c⃗_ )<sup>;</sup><sup>_⃗c_∗=2</sup><sup>_𝜋_</sup> _a⃗_ ⋅ _a_ ( _b⃗_ ×× _b⃗ c⃗_ )<sup>. The values of momentum transfer where</sup> 

the _⃗ q_ = _⃗ qB_ signifies the reciprocal lattice points and represents the Fourier transform of the real lattice, which can be restated as: _qhkl_ = ( _h⃗a_<sup>∗</sup> + _kb⃗_<sup>∗</sup> + _l⃗c_<sup>∗</sup> ). Considering this in 3D, these peaks arise when the surface Ewald sphere in Figure 1 intersects with the reciprocal lattice. The isolated values of _⃗ q_ where the Laue conditions are satisfied and scattering is observed, we can also write: 

plore the influence of finite scattering sites (i.e., periodic atoms) in a single linear dimension. Figure 4C,D demonstrates the effect of finite periodicity (in a single dimension, _x_ ) on the diffraction pattern in reciprocal space.<sup>[38]</sup> Here, the measured interference pattern | _g_ ( _k_ )|<sup>2</sup> in reciprocal space exhibits several inherent relations to the features of _f_ (x), which are connected to real space. More specifically: 

- Peak spacing in reciprocal space is inversely related to real space lattice distances. 

- The peak width and “ringing” observed in reciprocal space is governed by number of Gaussians points in real space, _n_ . 

- For a single discrete delta function scattering point in real space, the reciprocal space becomes broad (infinitely broad for a delta function). In reality, thermal disorder will always introduce a distribution of scattering site positions, rather than a single point. 

### _2.3.2. X-Ray Scattering from a Periodic Lattice_ 

For a given spatial vector, _⃗ r_ = ( _x, y, z_ ) _,_ the amplitude of the scattered electric field is determined by the Fourier transform of the charge density ( _𝜌_ = charge/volume), such that: 



<!-- Start of picture text -->
E scat ∝ ⃗ E 0 𝜌 ( r ) e i⃗q ⋅ ⃗r d 3 r (8)<br>∫<br>all−space<br><!-- End of picture text -->



<!-- Start of picture text -->
q  ⋅ ⃗ a  = 2 𝜋h,⃗ q  ⋅ ⃗ b  = 2 𝜋k,⃗ q  ⋅ ⃗ c = 2 𝜋l. (7)<br><!-- End of picture text -->

This definition will become useful later when describing the conditions of X-ray diffraction in systems with limited dimensionality. 

_Role of Reduced Periodicity of Scattering Sites_ : Elastic X-ray scattering maps reciprocal space and measures the Fourier transform of the autocorrelation of the electron density in real space. Using the fact that the Fourier Transform of a Gaussian function, _f_ (x), is itself a Gaussian, _g_ ( _k_ ), it becomes educational to briefly ex- 

While the charge density _𝜌_ ( _⃗r_ ) described here is generic, the charge around each atom in the crystal is well known and is related to the atomic form factor, _fa_ ( _q_ ), introduced in Section 2.1, which is the Fourier transform of _𝜌_ ( _⃗r_ ) of an atom of type _a_ . 

We assume that _𝜌_ ( _⃗r_ ) is spherically symmetric for each atom, so that _fa_ ( _⃗q_ ) = _fa_ (| _⃗q_ |) and expresses a maximum value when the scattering vector is a minimum, that is, _⃗ q_ ≈ 0 ( _fa_ ≈ _Z_ , the atomic number). To calculate the X-ray scattering amplitude from an extended crystal lattice, we first consider an individual unit cell and 

**2300760 (7 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

the atomic form factor for each atom inside. The scattering amplitude of the unit is thus determined by summing up the contribution from each _j_ th atom, yielding the structure factor: 



<!-- Start of picture text -->
F ( q ⃗ ) = ∑ fj (|| ⃗q ||) ei⃗q ⋅ ⃗rj (9)<br>j<br><!-- End of picture text -->

Extending this to encompass an entire infinite crystal, the amplitude of the scattered radiation at a position _⃗ R_ relative to the scattering electron with classical radius _re_ ( ≈ 2.8 × 10<sup>−5</sup> Å) is: 



<!-- Start of picture text -->
E scat ( ⃗q ) =  E 0 re F ( q ⃗ ) ∑ e i⃗q ⋅ ⃗Rn (10)<br>n<br>||| ⃗R |||<br><!-- End of picture text -->

Here, the sum is carried out over all unit cells, with vectors ( _⃗a,⃗ b,⃗ c_ ) within the irradiated volume, where _⃗ Rn_ represents the position of the origin of the _n_<sup>_th_</sup> unit cell within the lattice; _⃗ Rn_ = _n_ 1 _a_ + _n_ 2 _b_ + _n_ 3 _c_ , for integer values _n1, n2_ , and _n3_ . 

### _2.3.3. A Dynamic Lattice and the Temperature Factor_ 

The model used to describe scattering from periodic sites has thus far assumed a static picture for the lattice, whereby atoms in the crystal sit at fixed positions. However, in reality, lattice dynamics (phonons) and thermal fluctuations will influence the scattering intensity. The Debye Waller factor (or temperature factor), _DWF_ , is commonly used to account for the root mean square displacements of atoms from their average lattice positions ( _u⃗_ ) and is effectively a modification to the atomic form factors. Assuming the atomic motions are harmonic, the Debye Waller factor is compactly described as 



<!-- Start of picture text -->
DWF =  e − 3 1 q 2⟨ u 2⟩ (11)<br><!-- End of picture text -->

Here the value of 〈 _u_<sup>2</sup> 〉 indicates a temporal average of each unit cell followed by a spatial (thermal) average over every unit cell, which is typically depicted in terms of the so-called B-factor = 8 _𝜋_<sup>2</sup> 〈 _u_<sup>2</sup> 〉. The influence of the Debye Waller factor directly depends on the properties of the crystalline system, like its temperature and atomic species, and must be accounted for to accurately model X-ray scattering data, that is, as a fitting parameter during Rietveld refinement (Section 3.3). For reference, values of _U_ (value of root mean squared displacement) are often given in the literature as _U_ = 〈 _u_<sup>2</sup> 〉 and unrealistic values of the Debye Waller factors may indicate an incorrect structural model is being used. 

### _2.3.4. Experimental Detection of the Scattered X-Rays_ 

In practice, the X-ray detectors used in scattering experiments record the number of scattered X-ray photons over a selected time, rather than the field amplitude, and the measured intensity is given simply as 



<!-- Start of picture text -->
2<br>(12)<br>I scat = C | || E⃗ scat | ||<br><!-- End of picture text -->

where constant _C_ = 12<sup>_𝜂n𝜀_</sup> _c_<sup><u>0</u>, which captures several unique phys-</sup> ical properties of the experimental detection setup; namely, _n_ in 

### **www.advenergymat.de** 

this case is the refractive index, _𝜖_ 0 is the vacuum permittivity, and _𝜂_ is related to the detection process (efficiency, conversion factors, etc.) and will vary from instrument to instrument. This definition of diffraction intensity omits dynamical effects and makes use of the kinematical approximation arising from atoms and crystals. The equations and results subsequently derived also make use of the kinematical approximation. 

### _2.3.5. The Ewald Sphere, GIWAXS Geometry and the Missing Wedge_ 

The main distortion of GIWAXS experiments lies in the geometry employed (Figure 1). Whereas a transmission geometry is typically used to record XRD patterns from powders and single crystals, GIWAXS has the X-ray beam strike a flat surface of the sample under a shallow incident angle, _𝛼_ i, Relative to the fixed incident beam with wavevector, _⃗ ki_ , the sample is inclined to set _𝛼_ i and scattered light emerges from the sample surface with wavevector _⃗ kf_ . Furthermore, unlike small angle scattering, which considers a relatively long-range correlations (several nm to μm), wide angle scattering resolves atomic structure on the order of bond lengths and unit cells. Synchrotron GIWAXS typically requires a sample-to-detector distances in the range of 100–500 mm. At this distance, detected signals must factor in curvature of the Ewald sphere. Considering this in 3D, Bragg peaks arise when the Ewald sphere in Figure 1 intersects with the reciprocal lattice, producing a curved surface that is projected onto the flat 2D detector. As such, image correction is necessary to account for the curved surface of the Ewald sphere. 

The coordinate system used in GIWAXS is placed onto the sample surface at the point of diffraction, with _z_ in the normal direction and the _x_ - and _y_ -axes parallel to the sample surface. Emanating in 3D, the X-ray diffraction signals scattered by the sample are incident on the flat X-ray detector as a function of the in-plane exit angle ( _𝛼_ f) and out-of-plane angle ( _𝜓_ ), with the scattering plane being defined here by the incident and secularly reflected X-rays. In 3D, the scattering wavevector is given by: 



<!-- Start of picture text -->
⎛ qx ⎞ ⎛cos  𝛼 f cos  𝜓 − cos  𝛼 i⎞<br>q  = ⎜ qy ⎟ = ⎜ cos  𝛼 f sin  𝜓 ⎟ (13)<br>⎜⎝ qz ⎟⎠ ⎜⎝ sin  𝛼 i + sin  𝛼 f ⎟⎠<br><!-- End of picture text -->

As depicted in Figure 1, the geometry of the planar surface imposes constraints on the orientation-dependent information contained in the different scattering wavevectors. For instance, while _⃗ qz_ points in the out-of-pane direction with respect to the sample surface, _⃗ qx_ and _⃗ qy_ reside in-pane. Put differently, while signals from randomly orientated planes leads to the formation of complete Debye–Scherrer rings (with homogenous intensity distributions), the directionality of the scattering of highly-oriented scattering planes manifests as non-uniform distributions and is characterized as a function of the azimuthal angle, _𝜒_ . This phenomenon is known as film texture and is discussed for metal halide perovskite thin films below in detail. 

For the relatively large scattering angles assessed via GIWAXS, that is, large _q_ z, there is always a non-negligible contribution in _qx_ (along the incident beam direction). The in-plane scattering 

**2300760 (8 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.advenergymat.de** 



**Figure 5.** A) GIWAXS image recorded on the area detector. B) GIWAXS image after transformation with respect to _q_ z and _q_ r, whose contour lines are shown in gold and red in (A). The color scale of these images represents the minimum to maximum recorded intensity as spectral blue to red, respectively. Reproduced with permission.<sup>[37]</sup> Copyright 2015, International Union of Crystallography. 

wavevector in the GIWAXS geometry can be described by: 



<!-- Start of picture text -->
qr = √ q 2 x +  q 2 y ≠ 0 (14)<br><!-- End of picture text -->

This inability to access _qr_ = 0 manifests as a blindspot in reciprocal space along _q_ z, forming a missing wedge-shaped area in the final corrected GIWAXS image ( **Figure 5** ).<sup>[39,40]</sup> Only by producing the GIWAXS frame in terms of _q_ r, and including the missing wedge, can truly quantitative information be revealed in real space. In fact, along the _q_ z direction only two points are probed: the direct and reflected beam positions. If evaluating the out-of-plane direction is needed, different incident angles can be recorded, or specific techniques like X-ray reflectivity/rocking curves can be used to evaluate this part of the reciprocal space. 

### _2.3.6. Radial Integration of 1D Scattering Profiles and Azimuthal Polar Analysis of Film Texture_ 

Processing of the full scattering signal via GIWAXS by integrating a 1D scattering profile is closely related to other various forms of wide-angle X-ray scattering. There are some important differences, however, related to the grazing incidence when it comes to the orientation-dependent information contained in the GIWAXS. In polycrystalline thin films, the orientation of scattering crystallites is often non-random, forming well-defined angular distributions on the area detector. For this reason, conclusions should not be drawn from Bragg–Brentano measurements alone, since these only probe the out-of-plane scattering axis. This orientation-dependent information is referred to as crystallographic “texture”—representing the preferred orientation or distribution of crystallite orientations—and can be quantitatively analyzed using the GIWAXS image. 

Fiber texturing classically refers to a thin film orientation where one characteristic plane of the material (the “texture” plane) preferentially crystallizes parallel to the substrate, but the individual crystallites are randomly oriented within the film 

plane and is named for the resemblance to drawn metal fiber diffraction patterns.<sup>[39,41]</sup> For example, strong fiber texture is often found in solution-processed metal halide perovskite thin films,<sup>[24]</sup> where out-of-plane scattering appears as high intensity partial arcs with angular broadening, representative of the material’s degree of texture. An example of this in **Figure 6** A for a solution-processed thin film of _𝛾_ -CsPbIBr2 which exhibits (110) reflections out-of-plane and appears isotropic along the in-plane direction (Figure 6B). In the absence of any other directional forces (e.g., films made via blade coating), perovskite films generate the same GIWAXS detector pattern as they are rotated about the film normal axis (Figure 6C). Under these conditions, calculating the integrated profile from a single GIWAXS frame can in fact be performed with a simple polar integration over _𝜒_ for the observed _q_ range (see Figure 6A). 

A comparison of the integrated 1D scattering profile generated by both the whole image and only the out-of-plane scattering signals is provided in Figure 6D. Due to strong texture in the polycrystalline film, the out-of-plane profile exaggerates the intensity of the present peaks, while completely missing the inplane peaks. This is in contrast to the more complete scattering profile integrated over the whole azimuthal range. This comparison highlights the limitations of using a vertical scanning XRD instrument to characterize highly oriented thin films in the laboratory, that is, using a Bragg-Brentano geometry. 

To examine the orientation distribution of crystallites in the perovskite film measured in Figure 6A, the scattering intensity is measured along the azimuthal angle, _𝜒_ (Figure 1 depicts this in 3D in relation to the thin film surface). The symmetry of the fiber texture can be used here to examine the scattering distribution in a single frame (Figure 6B). As an example, a profile of the (110) peak in Figure 6A is extracted along a _𝜒_ arc and integrating over the full Bragg peak width. Accounting for the background signal, the intensity is presented in Figure 6E. To accurately link the orientation distribution in the I( _𝜒_ ) versus _𝜒_ curve to real space, only the corrected reciprocal space image (i.e., _q_ r, _q_ z) can be considered. A comparison of similar profile made to differently 

**2300760 (9 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.advenergymat.de** 



**Figure 6.** A) 2D GIWAXS image recorded from a 200 nm-thick polycrystalline thin film of _𝛾_ -CsPbIBr2 grown by solution processing (i.e., spin coat), exhibiting monoaxial texture. B) Reciprocal-space map in _q_ xy and _q_ z for a film with fiber texture oriented in the _z_ direction. The red lines in the scheme show how the same GIWAXS image is recorded when the sample rotated around normal. Reproduced with permission.<sup>[41]</sup> Copyright 2018, International Union of Crystallography. C) Illustration of the intersection of the Ewald sphere, scattering peak populations (rings on the sphere) and the detected intensity. The observed scattering “ring” becomes smaller at larger _𝜒_ angles, varying by a factor of |sin _𝜒_ | for the case of in-plane isotropic symmetry. Here _𝜑_ represents the angle of rotation about the film normal axis. D) Comparison of scattering profiles generated from integrated both out-of-plane (without the Ewald sphere correction) and over the whole GIWAXS image shown in (A). These data have been normalized to the (110) peak intensity near _q_ = 10 nm<sup>−1</sup> and background corrected (removal of glass signals in this region). E) Azimuthal intensity profiles of the (110) peak shown in (A) using different GIWAXS image formats; the red profile is generated from the ( _q_ x,y, _q_ z) image without Ewald sphere corrections and is an incorrect representation, the black profile is from the ( _q_ r, _q_ z) image which includes the Ewald sphere correction (correct representation), and the blue trace further includes the quantitative correction involving a factor of |sin( _𝜒_ )|. 

calibrated images is also contained in Figure 6E. While information about the orientation of grains in the film can be discerned from a profile along ( _q_ xy, _q_ z), the information remains semi-quantitative; the missing wedge must be factored in for quantified interpretation of the texture. 

Care is also needed when interpreting the angular dependence of the I( _𝜒_ ) versus _𝜒_ curve (Figure 6E). This is because a single GIWAXS frame only “sees” a 2D slice through 3D reciprocal space and fails to probe the full scattering intensity for a given population of crystallites (Figure 6B). For fiber texture, rotating the film around the surface normal is not needed to reconstruct reciprocal-space, as the symmetry again allows us to simplify; in this case we rescale the I( _𝜒_ ) versus _𝜒_ curve by factor of |sin ( _𝜒_ )| to account for the variation outlined in Figure 6C. The corrected curve is plotted in Figure 6E, which depicts an intensity that is linearly representative of the scattering population. We can then compute the relative quantities by summing up the 

area under the curve and allocating them to different modes of orientation. For the example in Figure 6E, the intensity variation indicates the existence of two types of populations for (110)oriented domains in the film; a strong out-of-plane (110) texture, along with a random isotropic population, forming the even baseline. This is the reason textures are often experimentally resolved out-of-plane—their scattering population is typically more intense. There are several free programs available online to readily integrate user-defined polar regions of the GIWAXS image: DAWN,<sup>[35,36]</sup> GIXSGUI,<sup>[37]</sup> FIT2D,<sup>[42]</sup> view.gtk.<sup>[43]</sup> 

### _2.3.7. A Brief Introduction to 2D Perovskite Materials_ 

Low-dimensional metal halide perovskite crystals have become a relatively popular structural motif for researchers in recent years,<sup>[46–48]</sup> due to their ability to exhibit structural diversity and, 

**2300760 (10 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.advenergymat.de** 



**Figure 7.** A) Illustration of low-dimensional perovskite structures with different numbers of perovskite layers ( _n_ ) ranging from 2D ( _n_ = 1) and quasi2D ( _n >_ 1), to bulk 3D ( _n_ = ∞), where R represents bulky organic cations which separate consecutive sheets of inorganic perovskites. Reproduced with permission.<sup>[44]</sup> Copyright 2019, Springer Nature. B) Schematic representation of Ruddlesden−Popper (RP) and Dion−Jacobson (DJ) interfaces commonly found in 2D metal halide perovskites, formed using differently charged cations and structural offsets. Reproduced with permission.<sup>[45]</sup> Copyright 2019, American Chemical Society. 

subsequently, tunable materials properties. In particular, lowdimensional metal halide materials consisting of a few layers of corner shared metal-halide octahedral, and are thus technically not perovskites (described by the general ABX3 composition), we describe as “2D perovskites”, as this is common in the literature. These have demonstrated significant improvements in the device stability compared to 3D perovskites due to their increased hydrophobicity (i.e., resistance to moisturedriven degradation) and suppressed ion migration. These materials can be visualized by cutting the typical perovskite 3D crystal consisting of corner-sharing lead halide octahedra along (100), (110), and (111) directions<sup>[49,50]</sup> and inserting bulky organic spacer cations,<sup>[48]</sup> as shown in **Figure 7** A for the _<_ 100 _>_ direction. 

Generally, the growth of low-dimensional perovskite thin films by solution-processing introduces a distribution of structural properties, most notably the dimensionality of the perovskite sheets and the number of octahedral layers, _n_ . Ignoring the distribution of phases, 2D perovskites are obtained when one octahedral layer is separated by spacer cations ( _n_ = 1), while quasi2D perovskites are obtained when a larger number of _n_ octahedral layers ( _n_ = 2, 3,…) are separated. The somewhat arbitrary boundary between quasi-2D and 3D is typically drawn at around _n_ = 5 layers,<sup>[51]</sup> beyond which the optoelectronic properties of the low-dimensional perovskite become comparable to the bulk material,<sup>[52]</sup> for example, properties like the exciton binding energies, optical bandgaps, etc. In reality, solution-processed lowdimensional perovskite films typically contain domains with different _n_ values, that is, multiple phases and off-stoichiometry 

compositions, and optimization of the growth process is needed to improve phase purity.<sup>[53]</sup> 

2D perovskites can be further divided into Ruddlesden–Popper (RP)<sup>[54]</sup> and Dion–Jacobson (DJ) type<sup>[55]</sup> structures (Figure 7B), depending on the relative alignment of inorganic layers of the metal halide perovskite sublattice. Specifically, with monovalent cations as a spacer cation, the RP-type interface is offset half a unit cell between slabs.<sup>[47,54]</sup> On the other hand, DJ phase structures utilize divalent spacer molecules as the spacer cations and results in no offset in the alignment of stacked inorganic layers (Figure 7B).<sup>[56]</sup> The general formulas of RP and DJ phase perovskites are A′2A _n_ −1B _n_ X3 _n_ +1 and A′′A _n_ −1B _n_ X3 _n_ +1, respectively, where A′ and A′′ represent the monoammonium and diammonium organic cations.<sup>[57]</sup> For RP perovskites, one side of the monoammonium cation is connected to the inorganic slab by hydrogen bonds and the other side is connected to organic molecules by weak van der Waals forces.<sup>[58]</sup> By contrast, there are no weak van der Waals interactions in 2D DJ perovskites. In most DJ perovskites, two—NH3+ terminals tightly connect the adjacent inorganic slabs through hydrogen bonds and the adjacent inorganic slabs perfectly align with each other in a short interlayer distance.<sup>[59]</sup> 

As shown in **Figure 8** A, there is a range of organic molecules, and different spacing lengths, that can be implemented in 2D metal halide perovskite systems. The interlayer stacking distance in the 2D perovskite scales roughly linearly<sup>[45]</sup> with the molar volume of the molecular spacer (Figure 8B) and their optoelectronic properties are intimately connected to this distance. For example, the organic sublattice acts as a dielectric moderator (for 

**2300760 (11 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.advenergymat.de** 



**Figure 8.** Molecular and spacing diversity in 2D metal halide perovskite systems. A) Examples of different sized organic cations commonly used to form 2D perovskites. AVA+, ammonium valeric acid; BA<sup>+</sup> , butylammonium; NMA<sup>+</sup> , naphthylmethylammonium; PEA<sup>+</sup> , phenylethylammonium; PMA<sup>+</sup> , phenylmethylammonium. Reproduced with permission.<sup>[44]</sup> Copyright 2019, Springer Nature. B) Crystal structures of 2D perovskites NMA2PbBr4 (Orthorhombic), (PEA)2PbI4 (triclinic),<sup>[60]</sup> and BA2PbI4 (orthorhombic).<sup>[61]</sup> Here, _n_ = 1 is shown (only a single octahedral sheet), although in reality these 2D sheets can be made up of more AB6 units separated by traditional 3D cations, as depicted in (C). C) Illustration of an orthorhombic (101) vertically oriented BA2MA3Pb4I13 2D perovskite structure, with (202) planes parallel to the substrate, which is reportedly discerned from the GIWAXS pattern shown in (D), recorded from a thin film spin-coated from DMAc solution. The simulated experimental peak positions (black square) from an orthorhombic phase suggest that a (101) plane which vertically orients the BA2MA3Pb4I13 structure. Reproduced with permission.<sup>[22]</sup> Copyright 2018, Springer Nature. E) Integrated XRD profile from GIWAXS experiments. The value of _q_ can be obtained from the XRD pattern, and the corresponding interplane spacing _d_ is 1.13, 1.69, and 2.20 nm for BAB, PEA, and NMA, respectively. Reproduced with permission.<sup>[62]</sup> Copyright 2019, American Association for the Advancement of Science (AAAS). 

the electrostatic interaction between electron–hole pairs<sup>[63]</sup> ), hybridizing the bonding motifs via incorporating weak dispersion forces into the crystal lattice and providing an insulating barrier for photogenerated charge carriers.<sup>[64,65]</sup> Thus, the quantum well energy barrier and band alignment between consecutive perovskite sheets will depend on the choice of spacer. Furthermore, when the 2D perovskite plane is orientated so that it aligns normal to the substrate, the optoelectronic metal halide sublattice can connect the electrodes on each side of an optical device, facilitating beneficial charge transport<sup>[22,66,67]</sup> (see Figure 8C,D). Consequently, the already vast catalogue of molecules used to fashion 2D perovskite continues to grow and take advantage of new structures.<sup>[68]</sup> The long-range ordering of large organic cations in 2D perovskites produces a characteristic low- _q_ peak in the GIWAXS profile (Figure 8E). **Table 1** provides a comprehensive overview of organic ligands used to make 2D perovskites and their expected lattice spacing. 

tures, we will introduce the concept of crystal truncation rods (CTR). Though the origin of streaking in low-dimensional perovskites is unclear, the notion of CTRs can be evoked to rationalize diffuse X-ray scattering perpendicular to the layering direction,<sup>[89–93]</sup> like ultrathin layered materials, crystal surfaces and interfaces. We will hereafter refer to the streaking recorded from low-dimensional halide perovskites as CTR-like features, although this terminology is imprecise. 

_Infinite 3D Crystal_ : For convenience, the structure factor, _F_ ( _⃗q_ ) _,_ absorbs the prefactors found in Equations (10) and (12). Further combining these equations and expanding the dot product, we can describe the measured intensity of scattered X-rays in 3D as: 



<!-- Start of picture text -->
2 2<br>I 3D ( q ) = F ( q )  ∑ e i⃗q ⋅ ⃗Rn = F ( q ) ∑ e i ( n 1 qaa + n 2 qbb + n 3 qcc )<br>||||| n ||||| |||||| n 1 ,n 2 ,n 3 ||||||<br>(15)<br><!-- End of picture text -->

### _2.3.8. From Infinite to Finite Crystal Scattering_ 

Next, we outline a scattering model to understand how limited crystalline dimensions can smear Bragg reflections in reciprocal space.<sup>[88]</sup> Specifically, to help understand the anomalous streaking of Bragg peaks in GIWAXS images recorded from different types of low-dimensional metal halide perovskite struc- 

where _qa_ = _⃗ q_ ⋅ _⃗ a_ , _qb_ = _⃗ q_ ⋅ _⃗ b_ , and _qc_ = _⃗ q_ ⋅ _⃗ c_ . For a bulk 3D crystal where the number of unit cells in each dimension is sufficiently large, we can evoke an infinite limit such that; − ∞ _< n_ 1, _n_ 2, _n_ 3 _<_ ∞. With these limits, the summation can be reduced further using the identity of the Dirac delta function: 21 _𝜋_ ∑∞ _n_ = −∞<sup>_einx_=</sup> _𝛿_ ( _x_ − 2 _𝜋m_ ). This description is valid for Brillouin scattering centered around 2 _𝜋m_ , which is the case for most crystals, where _m_ 

**2300760 (12 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advenergymat.de** 



**www.advancedsciencenews.com** 

**Table 1.** List of common organic ligand spacers used to fabricate 2D metal halide perovskites and their observed lattice spacing and Bragg peak positions. 

|Material|Facet|_d_[Å]|_q_[Å<sup>−1</sup>]|ref|
|---|---|---|---|---|
|BA2PbI4|001|12.7|0.49|[54]|
|BA2MAPb2I7|001|20.37|0.31|[54]|
|BA2MAPb2I7|111|2.88|2.18|[54]|
|BA2MAPb3I10|001|23.96|0.26|[54]|
|BA2MAPb3I10|111|2.92|2.15|[54]|
|BA2MAPb4I13|001|32.58|0.19|[54]|
|BA2MAPb4I13|111|2.92|2.15|[54]|
|BA2PbBr4|001|27.64|0.23|[73]|
|iso-BA2MA3Pb4I13|111|6.28|1.00|[74]|
|iso-BA2MA3Pb4I13|101|6.29|1.00|[74]|
|PEA2MAPb2I7|001|44.96|0.14|[76]|
|PEA2MAPb3I10|001|57.91|0.11|[76]|
|PEA2PbI4|001|30.45|0.21|[77]|
|PEA2PbBr4|001|32.11|0.20|[78]|
|(GA)2MA4Pb5I16|111|6.29|1.00|[79]|
|(GA)2MA4Pb5I16|101|6.31|1.00|[79]|
|(PDMA)(MA)n−1PbnI3n+1|011|6.23|1.01|[80]|
|(PDMA)(MA)n−1PbnI3n+1|010|8.70|0.72|[80]|
|(PEA)2MA3Pb4I13|111|6.23|1.01|[82]|
|(PEA)2MA3Pb4I13|101|6.26|1.00|[82]|
|CHA2PbI4|001|27.4|0.23|[85]|
|4-BrPEA2MA4Pb5I16|111|6.32|0.99|[87]|
|4-BrPEA2MA4Pb5I16|101|6.37|0.99|[87]|
|PA2MA4Pb5I16|111|6.38|0.99|[69]|
|PA2MA4Pb5I16|101|6.30|1.00|[69]|
|IC2H4NH32PbI4|001|12.92|0.49|[70]|
|THMA2MA2Pb3I10|111|6.19|1.02|[71]|
|THMA2MA2Pb3I10|101|6.37|0.99|[71]|
|PDAMAPb2I7|001|28.53|0.22|[72]|
|PDAMA2Pb3I10|001|40.16|0.16|[72]|
|PDAMA3Pb4I13|001|53.56|0.11|[72]|
|PDMAPbI4|001|24.88|0.25|[75]|
|PDMAPbI4|001|5.90|1.06|[75]|
|PDMAFAPb2I7|001|22.36|0.28|[75]|
|PDMAFAPb2I7|111|5.90|1.06|[75]|
|PDMAFA2Pb3I10|001|22.36|0.28|[75]|
|PDMAFA2Pb3I10|111|6.80|0.92|[75]|
|PDMAFA3Pb4I13|001|22.36|0.28|[75]|
|PDMAFA3Pb4I13|111|6.80|0.92|[75]|
|BA2MA4Pb5I16|001|6.28|1.00|[81]|
|BA2MA4Pb5I16|111|38.39|0.16|[81]|
|(PPA)2PbBr4|001|19.10|0.33|[83]|
|(CA-C4)2PbI4|001|25.50|0.25|[84]|
|(BDA)1-a (PEA2)aMA4Pb5X16|111|6.23|1.01|[86]|
|(BDA)1-a (PEA2)aMA4Pb5X16|101|7.17|0.88|[86]|



is an integer, and the above equation becomes 



<!-- Start of picture text -->
2<br>I 3 D ( q⃗ ) = F ( q ⃗ ) (2 𝜋 ) 2 ∑<br>|||||| h,k,l 𝛿 ( qaa  − 2 𝜋h ) 𝛿 ( qbb  − 2 𝜋k ) 𝛿 ( qcc  − 2 𝜋l )||| |||<br>(16)<br><!-- End of picture text -->

The diffracted intensity is the product of three periodic _𝛿_ - function arrays and Bragg scattering is thus observed for specific values of _⃗ q_ , as described by the Laue conditions in , that is, the three separate conditions that have to be met simultaneously for the occurrence of a Bragg peak. 

_Finite 2D Crystal_ : In the above description, the crystallite dimension is the same in all directions—infinite. If we isolate a slab of crystal cut along a plane perpendicular to the _c_ -axis, we can evaluate the influence of a low dimensional system possessing a finite number of planes, _Nc_ , in the _⃗ c_ direction. We note that the use of this approximation to a 2D or quasi-2D crystals is rough as these crystals, if perfect, have periodicity along the _⃗ c_ direction. We use this as a way of illustrating the streaking observed. Thus, while the rest of the summation for infinite _n_ 1 and _n_ 2 integers within Equation (15) remains the same, along the _c_ -axis a finite number of unit cells is represented by _N_ c. 

Note the _c_ -axis here, which is arbitrarily chosen, can align with any crystallographic direction. Fortuitously many lowdimensional perovskites are orientated along high-symmetry or low-Miller index planes to form interfaces/surfaces. Thus, our approximate description becomes: 



<!-- Start of picture text -->
2<br>∞ Nc<br>I 2 D ( q ) = F ( q ) ∑ e i ( n 1 qaa + n 2 qbb ) ∑ e in 3 qcc (17)<br>|||||| n 1 ,n 2=0 n 3=0 ||||||<br><!-- End of picture text -->

Isolating the term of interest, the second term, parallels can be drawn to the so-called N-slit interference function used in the field of optics, whereby 



<!-- Start of picture text -->
2 Nc qcc<br>Nc 2<br>1 − e iNcqc c sin 2 ( 2 )<br>∑ e in 3 qcc = |||| 1 − e iqcc |||| = qcc (18)<br>|||||| n 3= 0 |||||| sin 2 ( 2 )<br><!-- End of picture text -->

This complex quantity represents a simplified version of the scattering amplitude for a 1D crystal containing _N_ atoms. Subbing this back into Equation (17) becomes 



<!-- Start of picture text -->
2<br>(  Nc 2 qc c )<br>I 2D ( q⃗ ) = F ( q ⃗ ) (2 𝜋 ) 2 ∑ 𝛿 ( qaa  − 2 𝜋h ) 𝛿 ( qbb  − 2 𝜋k ) sin<br>||||||| h,k sin ( q 2 c c ) |||||||<br>(19)<br><!-- End of picture text -->

We now have an expression which captures the effect of finite scattering along a 1D in real space on the observation recorded in reciprocal space, that is, GIWAXS images of highly oriented, isolated slab. 

We next explore the consequences of this expression by imposing some extreme limits; consider a 2D crystal sheet possessing a single plane of atoms perpendicular to _⃗ c_ . First, using the case of single scattering layer, _N_ c = 1, the last term in Equation (19) is equal to 1 and, importantly, the equation becomes invariant 

**2300760 (13 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.advenergymat.de** 



**Figure 9.** A) Schematic diffraction patterns (pointing in _q_ z) corresponding to scattering from the crystal surface under different crystal dimension limitations; (top) from an isolated 2D layer, (middle) from a 2D layer and/or surface of a 3D crystal, and (bottom) a realistic representation of quasi2D system (i.e., type of pattern that is typically captured in experiments) showing a variation of intensity along the rods. Adapted with permission.<sup>[94]</sup> Copyright 1992, IOP Publishing. B) Simulated scattering (in units of reciprocal lattice units) from an infinite 3D crystal, a finite 2D layer with a sharp boundary, and a 2D layer with a thickness of zero.<sup>[88]</sup> C) Illustrative image of simulated crystal truncation rods (CTRs) in reciprocal space. 

to changes in _q_ c. More specifically, as long as the in-plane Bragg conditions are satisfied in the plane perpendicular to the _c_ -axis, an unbroken scattering rod exists along _q_ c, passing through the Bragg points of the bulk ( **Figure 9** A). These are called Bragg rods in analogy to Bragg points in 3D. 

Another relevant limit to explore is the case where is _N_ c is still finite, but relatively large; _N_ c _>>_ 1. For this, the intensity profile can be again derived via the N-slit function in Equation (18). With _N_ c being large, the numerator, sin<sup>2</sup> (<sup>_Nc_</sup> 2<sup>_<u>qcc</u>_), varies rapidly long qc</sup> and is smeared out in a real-world experiment because of finite resolution. Since the numerator oscillates rapidly with qc and is always positive, we can take its mean value as ⟨| sin(<sup>_Nc_</sup> 2<sup>_<u>qcc</u>_)|</sup> 2⟩ = 1∕2. This yields a simpler form of the equation using the limits imposed by a large number of layers, and is now conveniently independent of _N_ c. Thus, Equation (19) becomes 



<!-- Start of picture text -->
2<br>1<br>I 2D ( ⃗q ) = 21 F ( q ⃗ ) (2 𝜋 ) 2 ∑ 𝛿 ( qaa  − 2 𝜋h ) 𝛿 ( qbb  − 2 𝜋k )<br>||||||| h,k sin ( q 2 c c ) |||||||<br>(20)<br><!-- End of picture text -->

depicts the basic arrangement of this structural evolution, where a layer of corner-sharing metal halide octahedra are cut along the _<_ 100 _>_ direction. This is achieved by introducing PEA into the precursor solution, generating a self-assembled lamellar structure consisting of 2D sheets of corner-sharing lead-iodide octahedra separated by a nanometer-scale bilayer of monovalent, organic cations. The two extremes in dimensionality are then easily realized by controlling the stoichiometric mix, which subsequently varies the average thicknesses of a perovskite-like layer between the bilayers of the larger organic cations. 

Figure 10B presents GIWAXS patterns recorded from the systematic shift in the processing solution, whereby increasing the amount of PEA changes the pattern from a characteristic 3D polycrystalline signal to an oriented low-dimensional system, with the lead iodide planes parallel to the substrate surface. For the 100% PEA, CTR-like features are streaked along constant values of _q_ x,y, which correspond to in-plane lattice spacing of the oriented metal halide sublattice. Notably, our description for Bragg scattering from a finite sheet did not account for changes in the scattering selection rules when the crystal dimensionality is reduced. 

Although this approximation breaks down at the Bragg points, it describes scattering from surfaces where long-range scattering exists along the surface and a non-zero intensity is measured between diffraction peaks. In reciprocal lattice units (R.L.U.), Figure 9B contrasts the calculated patterns determined for these three different limits. Figure 9C presents the simulated diffraction pattern for a surface. 

The description for a quasi-2D material (i.e., involving an intensity which varies along the streaking rods) typically has the closest correspondence to the experimental record. Herz et al.<sup>[95]</sup> reported the GIWAXS evolution which takes place as the perovskite transitions from a 3D MAPbI3 system to the 2D layered perovskite, as the bulky phenylethylammonium (PEA) cation is incorporated into the structure, forming (PEA)2PbI4. **Figure 10** A 

### _2.3.9. Small Angle X-Ray Scattering in the GIWAXS Image_ 

Often implemented for non-crystalline diffraction, grazing incidence small angle X-ray Scattering (GISAXS) yields information on the structure of large molecular assemblies in ordered environments. Such structure is characteristic of many complex materials, such as polymers and colloids, and even living organisms. Small angle of course infers a small exit angle for the Bragg peak, but this ultimately depends on both the energy of X-rays used and the size of the lattice spacing. Hereon we will instead refer merely to the lattice spacing distance and differentiate between small and wide angle scattering by their corresponding positions in reciprocal space for a regular perovskite unit cell; 

**2300760 (14 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 10.** A) Schematic crystal structures of MAPbI3, (PEA)2PbI4, and intermediate mixed MA–PEA 2D perovskites. The % labels indicate the mole percentage of PEA as a fraction of the total organic cation composition. B) Experimental GIWAXS patterns showing the structural evolution of varying the perovskite dimensionality between a 3D system MAPbI3 to a highly oriented 2D (PEA)2PbI4 perovskite. The blue and red circles identify scattering peaks lost via the move to lower dimensions and examples of streaking are highlighted in green. Reproduced with permission.<sup>[95]</sup> Copyright 2016, American Chemical Society. 



**Figure 11.** A) GIWAXS image recorded from an in-plane oriented (PEA)2PbI4 2D perovskite film grown by evaporation on a glass substrate, recorded with an Incident angle is 0.2°. The out-of-plane small angle peak (002) (organic PEA spacer) and Bragg streaking pointing in the vertical direction ( _c_ -axis) are identified. B) The scattering signals integrated in- and out-of-plane (using the image without Ewald correction) with corresponding Bragg peaks labeled. The solid green lines found in (A) and (B) delineate the general wide and small angle scattering regimes; above and below the perovskite unit cell in this case. The inset showing the scattering planes in the (PEA)2PbI4 crystal structure at 300 K (CIF file taken from Du et al.<sup>[60]</sup> ) 

_q_ (∀<sup>−1</sup> ) =<sup>2</sup><sup>_𝜋_</sup> _d_ (∀) −− 6 _._ 283∕ _d_ (∀) _._ Further, we identify SAXS to cover all angles below the characteristic Bragg peaks of 3D crystalline halide perovskites (Figure 9), or roughly _q_ ≤ 1 Å<sup>−1</sup> and _d_ ≥ 6.3 Å. Like all other definitions of SAXS versus WAXS, this definition is admittedly arbitrary. 

_2D Metal Halide Perovskites_ : The GIWAXS image recorded from a thin film of highly-oriented (PEA)2PbI4 2D perovskite 

sheets (green lines in **Figure 11** ) highlights these two regimes. As illustrated in the inset of Figure 11B, the intense small angle peak corresponds to the interlayer spacing between the inorganic octahedral layers, arising from bulky spacer cation bilayer, _d_ ≈ 16 Å. A wide variety of small angle peaks have been reported for different spacings within 2D perovskites (Table 1); ranging from _d_ = 57.9 Å ( _q_ = 0.11 Å<sup>−1</sup> ) for the (001) plane of PEA2MAPb3I10,<sup>[76]</sup> 

**2300760 (15 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



### **www.advancedsciencenews.com** 

to the relatively smaller spacing of _d_ = 2.88 Å ( _q_ = 2.18 Å<sup>−1</sup> ) for the (111) plane of BA2MAPb2I7.<sup>[54]</sup> For small-angle scattering, the impact of the curvature of the Ewald sphere is diminished and it becomes reasonable to approximate the detector image as a flat slice through reciprocal-space, that is, one can assume _qx_ ≈ 0. As such, Bragg peaks in the region can be probed directly. For instance, Figure 11B confirms that the 2D sheets lay flat on the substrate, directing a small angle (002) peak out-of-plane. Moreover, the structure imposes broadening on the Bragg point in the _q_ z direction. 

_Halide Perovskite-Based Superlattices_ : For hierarchical superlattice-type structures based on halide perovskites, organic ligands can be used as spacers to assemble and coordinate longrange ordering of structure, that is, self-assembled nanocrystals (cubes)<sup>[96]</sup> and oriented lamellar of 2D perovskites.<sup>[97]</sup> Compared to Bragg peaks arising from the metal halide sublattice, the relatively large spacing between periodic segments of perovskite crystal manifest as small angles in the GIWAXS image. For instance, a 3D superlattice composed of self-assembled nanocubes<sup>[96]</sup> will express long-ordering correlated (approximately) to the side length of the cubes (≈5–10 nm). Introducing a second compound into the self-assembly process, binarycomponent 3D superlattice structures were recently reported with far larger long-range ordering;<sup>[98]</sup> here the superlattice repeats itself with a period of 10s of nanometers (Figure 12A and B). Through the combination of nanocrystals of various shapes and sizes, a considerable structural space can be explored on similar length scales.<sup>[99]</sup> 

In this regime, an optimized GISAXS instrument is required to reliably probe the relatively small area of reciprocal space scattered around the incident beam (Figure 12C). This essentially requires repositioning the detector further back from the sample, to “zoom in” and improve the detection resolution of small angle scattering, as well as careful mitigation of air-background signals produced by the long scattering path, that is, using a long vacuum tube. While GISAXS experiments are closely related to GIWAXS, there are important differences, and the interested reader can find these documented elsewhere.<sup>[40]</sup> 

### _2.3.10. Perovskite Structural Motifs and Their Corresponding GIWAXS Signatures_ 

Beyond compositional engineering, tuning the film structure and dimensionality of perovskite crystals has opened a new realm of applications due to their added ability to tune the optoelectronic properties. These changes mainly originate from their anisotropic photophysical features<sup>[100]</sup> and quantum confinement effects.<sup>[101–104]</sup> For example, depending on the synthetic approach employed,<sup>[105]</sup> the dimensions of the archetypal 3D perovskite can be limited in one or more spatial directions, yielding nano-scale building blocks with local order spanning 3D to 0D ( **Figure 13** A). Recently, Yang et al.<sup>[106]</sup> reported a supramolecular route which constitutes an entirely new general strategy for designing and tailoring the halide perovskite structures; starting with a “dumbbell” supramolecular building block in solution, crystals are assembled through interactions of alkali metalbound crown ethers with the [M(IV)X6]<sup>2−</sup> octahedra. Notably, such crystal architectures are not solely limited to alkali metal- 

### **www.advenergymat.de** 



**Figure 12.** A) HAADF-STEM micrographs recorded along the [001] zone axis of a binary Fe3O4-CsPbBr3 3D super lattice structure. The colored inset shows a corresponding EDX-STEM map for Fe (grey, K line) and Pb (blue, L line) species in the crystal. B) Unit cell of the superlattice structure, with grey sphere indicating the Fe3O4 component and the blue cubes represented the CsPbBr3 perovskite nanocubes housed in the larger oxide framework. C) 2D GISAXS image recorded from the superlattice showing long-range order within the in- ( _q_ H) and out-of-plane ( _q_ V) domains. Adapted with permission.<sup>[98]</sup> Copyright 2021, Springer Nature. 

bound crown ethers, but also among analogous structures like vacancy-ordered double halide perovskites.<sup>[107]</sup> 

Both molecular and morphological<sup>[104]</sup> engineering are used to control the assembly, which includes the formation of nanosheets, nanorods, nanocubes, and quantum dots<sup>[105,108–111]</sup> (Figure 13B). This particular aspect of material design has significantly expanded the structural diversity and potential application space of metal halide perovskite thin films in recent years.<sup>[13,112]</sup> 

Perovskite crystals fashioned into thin films tend to orient relative to the substrate depending on the solution chemistry and energetics of the substrate interface. Combined with different dimensions (Figure 9) and short- and long-range ordering (Figure 13), a rich variety of GIWXAS signatures have been experimentally reported. As such, we present in **Figure 14** an illustrative overview of GIWAXS signals characteristic of different perovskite dimensionalities and preferential orientations. In general, solution-processed perovskite thin film systems can exhibit a mixture of phases (i.e., 3D, quasi-2D, 2D) and/or orientations. Consequently, the GIWAXS patterns recorded from these mixed phase films will contain a combination of scattering patterns which can be deconvoluted and isolated if parsed carefully. 

Considering the different GIWAXS signatures presented in Figure 14, there are some general trends worth noting. The planar nature of low-dimensional perovskite structures can facilitate the assembly of highly oriented thin films either in- or 

**2300760 (16 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



### **www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 13.** A) Overview of the different structural motifs of metal halide perovskite structures, ranging from (top row) extended corner sharing BX6 octahedral building blocks with different dimensionality, to the construction of (bottom row) 2D<sup>[113]</sup> and 3D<sup>[114]</sup> superlattice-type structures expressing long-range order (i.e., beyond the nominal few octahedral units), and the supramolecular assembly of BX6 octahedra.<sup>[106]</sup> Adapted with permission.<sup>[113]</sup> Copyright 2020, Royal Society of Chemistry. Reproduced with permission.<sup>[114]</sup> Copyright 2022, American Chemical Society. Adapted with permission.<sup>[106]</sup> Copyright 2022, American Chemical Society. B) Schematic images of how these crystal structures can form different basic morphologies. 



**Figure 14.** Overview of common GIWAXS signatures for different oriented structural motifs and degrees of ordering in thin films. Bragg peaks arising from the perovskite structure are depicted in grey, forming either points or rings, depending on their degree of orientation. Likewise, in addition to Bragg peaks, diffuse scattering emerges in low-dimensional systems due to stacking defects. Quasi 2D systems and mixed _n_ phase materials yield elongated peaks orthogonal to the stacking disorder. Low dimensional 2D materials ( _n_ ≈ 1, and systems which can also possess 2D layering faults) can give rise to relatively long streaks. The blue and green colored GIWAXS features represent the small angle features originating from long-range ordering of the generalized superlattice depicted. For simplicity, the diffraction from the 3D superlattice building block is overlooked here. 

**2300760 (17 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



### **www.advancedsciencenews.com** 

out-of-plane. Small nanocrystals and quantum dots will impose peak broadening due to their small size. Likewise, for relatively low dimensionality (i.e., 2D perovskites nearing _n_ ≈ 1 layer), the Bragg peaks are typically elongated orthogonal to the 2D planes due to stacking disorder<sup>[95]</sup> and with some peaks becoming weak. Depending on the degree of orientation present in the in the film, incomplete or complete Debye-Scherrer diffraction rings are recorded. For the case of highly oriented films, for example, strong fiber texturing, sharp Bragg points are apparent on the detector due to the reciprocal lattice of a fixed orientation. Likewise, the presence of relatively large grain sizes can manifest as a spotty pattern. 

When superlattice-type structures are formed in either 2D or 3D, the longer-range periodicity within the material yields smallangle peaks due to their relatively large lattice spacings, typically with _q_ less than about 1 Å<sup>−1</sup> . These are captured in Figure 14 by the blue and green colored reflections. 

### **2.4. Dielectric Properties and Consequences of the Grazing Incidence** 

A grazing incidence is generally established when small incident angles, _𝛼i_ , are employed with respect to the thin film surface (typically below 1°). This is because the so-called critical angle ( _𝛼c_ ), that is, the angle below which total external reflection of X-rays occurs, typically resides below 1°. Many important aspects of GIWAXS experiments depend on knowing the grazing incidence angle and several anomalous scattering features can be introduced. Depending on the required GIWAXS analysis, _𝛼_ i will typically impose the largest limitations on data quality. This section is, therefore, dedicated to the consequences of the small grazing incidence angle. 

### _2.4.1. Complex Refractive Index_ 

Numerous effects discussed in the following section depend on the complex refractive index and can vary widely between different metal halide perovskite compositions. While for low-energy photons (e.g., ultraviolet, visible, infrared) the refractive index is larger than 1, at very high frequencies the value of electric permittivity is slightly less than 1, as the perovskite material looks like the ideal Drude model in the high-energy regime. In this case, far from X-ray absorption edges, the refractive index is defined by:<sup>[91,115]</sup> 

**www.advenergymat.de** 



**Figure 15.** Material density and refractive parameters of 2D perovskite (BA)2(MA) _n_ −1Pb _n_ I3 _n_ +1 as a function of the number of perovskite unit cell layers. The experimental determination of density is taken from Ref. [61] ( _n_ = 1), Ref. [54] ( _n_ = 2,3,4), Ref. [116] ( _n_ = 6,5), and Ref. [117] (3D MAPbI3) The fits to the data are made using a powder law function and are simply an aid for the eye. 

mass, _fk_<sup>0thenon-resonanttermoftheatomicscatteringfactor,</sup> which can be approximated to the number of atom electrons, and _fk_<sup>′and</sup><sup>_f_</sup> _k_ ′′<sup>are the dispersion corrections.</sup> 

Since both _𝛿_ and _𝛽_ are proportional to the material density ( **Figure 15** ), accurate calculations of the refractive index directly rely on reliable values for _𝜌_ m. Different perovskite structures can thus significantly alter the material density depending on the synthesis conditions, that is, the final fraction of organics introduced into the system can dramatically vary compared to the inorganic metal halide sublattice. This becomes important for lowdimensional 2D perovskite films when the material is composed of a distribution of layer numbers, _n_ (Figure 15). 



<!-- Start of picture text -->
n ( 𝜆 ) = 1 − 𝛿 ( 𝜆 ) − i𝛽 ( 𝜆 ) (21)<br><!-- End of picture text -->

where _𝛿_ ( _𝜆_ ) and _𝛽_ ( _𝜆_ ) are the dispersion and absorption factors of the X-rays, respectively, and can be calculated as: 



<!-- Start of picture text -->
𝛿 ( 𝜆 ) = r 2 e𝜆 𝜋 2 𝜌 m ∑ k [ fk 0 ∑ ( 𝜆 k ) m  + k  f k ′ ( 𝜆 )] (22)<br><!-- End of picture text -->



<!-- Start of picture text -->
𝛽 ( 𝜆 ) = r 2 e𝜆 𝜋 2 𝜌 m ∑ ∑ k f kk ′′ m ( k 𝜆 ) (23)<br><!-- End of picture text -->

with _re_ being the classical electron radius ( _re_ = 4 _𝜋𝜀_ 0 _e_<sup>2</sup> _mec_<sup>2),</sup><sup>_𝜆_the</sup> wavelength, _𝜌_ m the material density (in g cm<sup>−3</sup> ), _mk_ the atomic 

### _2.4.2. The Critical Angle, 𝛼c_ 

At high photon energies, perovskites have a refractive index less than 1 and the X-ray beam is bent away from the surface normal. At small _𝛼_ i angles, the photons will be totally reflected, while at higher angles they penetrate the material. The transition between these disparate scattering conditions defines the critical angle ( _𝛼_ c), and depends on the X-ray energy and the dispersion factor, _𝛿_ ( _𝜆_ ): 



<!-- Start of picture text -->
r e 𝜌 e<br>𝛼 c = 𝜆 = √ 2 𝛿 (24)<br>√ 𝜋<br><!-- End of picture text -->

**2300760 (18 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.advenergymat.de** 



**Figure 16.** Critical angles of different metal halide perovskite materials at room temperature, as a function of X-ray energy using in the GIWAXS experiment. 

where _𝜌_ e is the electron density of the material. While the physical properties of the material are important, there is an inverse relationship with the beam energy and the value of _𝛼_ c ( **Figure 16** ). 

For GIWAXS measurements made below _𝛼c_ , the beam is fully reflected by the film, with the X-ray electromagnetic field only interacting a short distance below the film surface due to the evanescent wave (5–10 nm). It therefore becomes useful to compare GIWAXS data recorded both above and below _𝛼c_ , to determine if surface structure agrees with the bulk,<sup>[118]</sup> although surface roughness can significantly impact this type of measurement. 

### _2.4.3. Refraction Effects_ 

The grazing-incidence geometry of GIWAXS leads to a variety of effects not observed in traditional modes of XRD. In particular, the refractive index of the film (and substrate) will cause the incident beams to refract toward the film surface. Overall, refraction will take place at the air-film interface and reflections can occur at the air-film and film-substrate interfaces. Consequently, depending on the conditions, the location, and shape of the detected scattering peaks can be distorted. 

_Waveguiding and Scattering Enhancement_ : With shallow grazing incidence angles, the interfaces become strongly reflective and multiple-reflection events can occur within the film with high probability. For instance, near _𝛼_ c of the perovskite film, the incident beam will be refracted so that it is essentially travelling parallel to the film plane. In this scenario, a significant fraction of X-rays then bounced back-and-forth between the opposing interfaces (as if in a waveguide) and act to enhance the number of scattering events within the perovskite film. For a flat film surface and suitable refraction conditions, this phenomenon can be used within GIWAXS to maximize the overall detected scattering intensity ( **Figure 17** ). For instance, the study of thinner films ( _<<_ 100 nm) can benefit from the enhanced scattering near the 



**Figure 17.** The integrated Bragg intensity of the convoluted (110)/(002) peak in tetragonal halide perovskite thin film as a function of the grazing incidence angel, _𝛼_ c. The red line indicates the calculated critical angle for this particular composition and X-ray energy. 

critical angle. Notably, however, given the surfaces of polycrystalline halide perovskite films are often rough, the impinging beam can become incident over a distribution of angles nearing the intended angle; this local variation interrupts the scattering enhancement. 

_Refraction Shift_ : Incident X-rays will refract at the airperovskite interface and shift the detected Bragg peak positions for a given scattering plane. Unlike in-plane scattering which is left relatively unaffected by refraction, out-of-plane scattering peaks are detected (2 _𝜃_ 0) at angles larger than one might expect from solving the Bragg equation (2 _𝜃_ 1). For out-of-pane scattering, the dielectric properties of the film will determine the degree of refraction and we can adopt the following definition for angular shift prescribed by Toney et al.:<sup>[119]</sup> 



<!-- Start of picture text -->
Δ2 𝜃 ≅ 𝜃 0 − 𝜃 1 (25)<br><!-- End of picture text -->



<!-- Start of picture text -->
1<br>≅ 𝜃 0 − {[( 𝜃 0 2 − 2 𝛿 )1∕2 + 4 𝛽 2] − 2 𝛿 +  𝜃 0 2 }2 (26)<br>√ 2<br><!-- End of picture text -->

Here the refractive effects are largest at relatively smaller incidence and scattering angles, though remain non-trivial for the small-angle peaks arising from a common perovskite unit cell, and a maximum positive shift is reached near the critical angle (on the order of several tenths of a degree).<sup>[120]</sup> 

To complete accurate structural refinement one must account for the refraction effects, which can be lessened by moving to higher _𝛼_ i values. If available, powder diffraction can serve as a reference and even facilitate accurate peak correction when quantitative structural analysis is sought, like Rietveld refinement (Section 3.3). 

**2300760 (19 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.advenergymat.de** 



**Figure 18.** A) Experimental GIWAXS image demonstrating the observation of a double peak in 100 nm-thick CsPb(BrCl)3 thin film ( _𝛼_ c = 0.16°) on a 2.5 mm-wide glass substrate ( _𝛼_ c = 0.11°) for differen incidence angles, using 12.95 keV X-rays. Here the diamond symbol identifies the emergence of the high-angle dynamic scattering peak pointing out-of-plane and the missing wedge is omitted for clarity. Note these images do not account for the missing wedge. B) In-plane (IP) and out-of-plane (OOP) GIWAXS profiles as a function of the incident angle. The angles identified by * indicate the range of values where the double peak is resolved. C) Schematic of the double-peak effect, showing the ray tracing for the two equivalent geometric scenarios where the beam is first reflected and then scattered (Left), and when the direct beam is scattered and then reflected (Right). The reflected beam exits at an angle (purple) which is relatively larger than the case of pure scattering (red), and this difference increases as _𝛼_ increases. Reproduced with permission.<sup>[119]</sup> Copyright 2020, International Union of Crystallography. 

### _2.4.4. Dynamical Scattering from Thin Films and the Anomalous Double Peak_ 

Beyond the splitting of Bragg peaks due to two (or more) lattice planes having a similar lattice distance (Section 3.1), dynamical scattering effects will split peaks. More specifically, X-ray reflections at the film-substrate interface will introduce a high-angle shoulder for all Bragg points pointing out-of-plane. For phase identification and analysis (Section 3.2), it is vital to identify the peak splitting origins. Further, if considerations of the peak intensity are to be made, one must consider the summed total of both. 

The exemplar appearance of double GIWAXS peaks is shown in **Figure 18** A, with their corresponding in- and out-of-plane profiles as a function _𝛼_ i of contained in Figure 18B. For comparison , Figure 18C depicts the paths of the double peak; either 

first scattered then reflected from the substrate, or vice versa. In Figure 18B, the double peaks overlap the Bragg point at 0.09° and moves to higher _q_ values with rising _𝛼_ i values. The highest intensity and splitting take place near _𝛼_ c of the film (0.15°), beyond which the splitting disappears (Figure 18A). While refracted signals should be avoided, a combination of factors will act to smear and redistribute the actual angle of incidence(s) and make this more difficult near _𝛼_ c. 

### _2.4.5. X-Ray Penetration Length and the Scattering Information Depth_ 

Optoelectronic perovskite devices are typically fashioned using thin films, given that it maximizes the active optical surface area and can facilitate coupling/integration with existing planar 

**2300760 (20 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



**Figure 19.** A general scheme for an optoelectronic thin film device and the typical thickness requirements for different technologies employing metal halide perovskites as the active layer. TCO; transparent conducting oxide layer. Near total solar absorption in PV is found well below 1 μ, in the range of 200–400 nm;<sup>[121]</sup> LEDs are typically thin ( _<_ 100 nm) to maximize electroluminescence; thermoelectric devices are limited by a thickness dependences of the Seebeck coefficient and electrical conductivity.<sup>[122,123]</sup> Field-effect transistors (FETs) are sensitive to screening of the gate electric field,<sup>[124,125]</sup> and thus must remain relatively thin to suppressed fielddriven phenomena like structural polarization or ion migration. Halide perovskite thin films used as piezoelectrics and ferroelectrics are reported in the relatively large range of 20 nm to 1 μm.<sup>[126–128]</sup> 

### **www.advenergymat.de** 

energy. Systematically, higher energies are shown here to yield deeper penetration profiles as a function of _𝛼_ i. 

While X-rays can penetrate the thin film into the substrate, the penetration depth does not correspond to the scattering information depth given that detection of scattered X-rays requires photons to traverse and exit back through the surface of the film. Thus, we consider the attenuation of the diffracted beam, which depends on both the incident angle _𝛼_ i and the exiting angle _𝛼_ f. The X-ray scattering length considering this path is described as:<sup>[130]</sup> 



<!-- Start of picture text -->
sin ( 𝛼 f )<br>Λ ∗ = (28)<br>sin ( 𝛼 i ) + sin ( 𝛼 f ) Λ<br><!-- End of picture text -->

The X-ray penetration depth does not imply that the scattering information collected has originated along all of the penetration depth. For relatively low incident and exit angles, the X-ray scattering path is exaggerated and the information depth will be quite shallow. Conversely, greater exit angles will yield signals that penetrate deeper. For example, Λ* may even become far greater than the thickness of the film ( _D_ ) and the above equation does not describe the actual depth of the information collected. 

With the majority of information detected near the film surface,<sup>[131]</sup> the scattering information depth is defined as:<sup>[130]</sup> 



<!-- Start of picture text -->
De − D ∕Λ∗<br>Λ = Λ ∗ − (29)<br>1 − e − D ∕Λ∗<br><!-- End of picture text -->

photonic technologies. Depending on the application the thickness of the thin film material can vary ( **Figure 19** ) and the GIWAXS scattering depth must be considered. 

To extract information as a function of the depth, competing factors need to be considered; namely, the divergence and incident angle of the beam, the X-ray energy, the surface morphology/roughness, compositional profile, the scattering and attenuation properties of the perovskite, the thickness of the film, and the type of substrate used. Without a well-informed model, one or more of these factors will limit the quality of the depth-profile. GIWAXS typically possesses some degree of divergence, which manifests as a spread of incidence angles around the intended target angle. If discernable, such divergence should be included into the definitions below. 

For an ideal non-divergent X-ray beam, the penetration depth (Λ) is defined as the depth where the radiation intensity is attenuated to 1/e (≈37%) of the original value.<sup>[129]</sup> For small angles ( _<_ 1°), it can be calculated as:<sup>[129]</sup> 



<!-- Start of picture text -->
𝜆 √√ 2<br>Λ = √ (27)<br>4 𝜋<br>√ √( 𝛼 i 2 − 𝛼 i 2 ) 2 + 4 𝛽 2 − ( 𝛼 i 2 − 𝛼 c 2 )<br><!-- End of picture text -->

The penetration depth depends only on the wavelength and the optical properties of the material. **Figure 20** A depicts the penetration depth of commonly investigated perovskites and substrates at an X-ray beam energy of 12 keV. Here higher density materials present a lower penetration depth, as expected with higher X-ray absorption from the elements forming the perovskite. Conversely, Figure 20B considers the varied penetration depth for a target inorganic perovskite composition as a function of X-ray 

In the limit where the thickness of the film far outweighs the penetration depth ( _D_ /Λ* → ∞), Λ = Λ<sup>∗</sup> _._ Conversely, for relatively thin films and/or deep penetration depth ( _D_ /Λ* → 0), this equation approaches _D_ /2. 

To elucidate how these different descriptions vary with the incident angle, Figure 20C presents them for a 300 nm CsPbI3 thin film. Here _𝛼f_ = 18.1<sup>_o_</sup> , which roughly corresponds to the (002)/(110) Bragg reflections in _𝛾_ -CsPbI3 perovskite phase using 12 keV X-rays. This demonstrates that the information recorded from top side of the film will dominate the overall signal. 

_General Recommendations for Depth Profiles_ : The example calculation in Figure 20C illustrates that GIWAXS information is weighted toward the surface. For _𝛼_ i ≤ _𝛼_ c, the X-ray electromagnetic field interacts only a short distance below the film surface due to the evanescent damping (5–10 nm), and constitutes the evanescent regime defined in Figure 20C. Consequently, the three descriptions for scattering depth are comparable for small angles up to the critical angle. However, for angles far above _𝛼_ c, this difference becomes important and accounting for the attenuated Bragg peak (Λ) imposes a stringent limit on the depths at which thin film structural information can be retrieved (Figure 20C). This misapprehension is extended to the wider GIWAXS characterization community in general, resulting in scientific results and assumptions that can be misleading. 

A depth profile can be constructed based on the observed changes with increasing incident angle, ranging from the top surface ( _𝛼_ i _< 𝛼_ c), to the sub-surface and bulk of the film ( _𝛼_ i _> 𝛼_ c). For angles below or just above the critical angle, a reliable quantitative depth analysis can be generated using the simpler description of depth, Λ, which does not require knowledge of the Bragg exit angles. This regime constitutes most 

**2300760 (21 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



### **www.advancedsciencenews.com** 

### **www.advenergymat.de** 



**Figure 20.** A) X-ray (12 keV) penetration depth (Λ) for different perovskite compounds as a function of the grazing incidence angle. B) Energy dependent of penetration for CsPbI3 perovskite. C) Comparison of the penetration depth corrected for an exit angle of 18.1<sup>o</sup> (Λ*) and the scattering depth (Λ) of a CsPbI3 thin film for different film thicknesses, with a density 4.54 g cm<sup>−3</sup> with an X-ray beam of 12 keV. The values of the thin film thickness ( _D_ ) and half of it ( _D_ /2) are also indicated for 300 nm-thick film. The red circle shows the critical angle, below which resides the surface-sensitive evanescent regime. 



**Figure 21.** A) X-ray beam footprint as a function of the incident angle for different beam vertical sizes. The inset shows the footprint recorded on photo-resistive paper for a 75 μm vertical size beam at 1<sup>o</sup> of incident angle. Panels (B)–(E) show examples of different GIWAXS footprints incident on a simulated 20 × 5 mm substrate, with varied beam dimensions (horizontal × vertical), positions and geometric profiles. B) 150 × 50 μm elliptical beam shape (Gaussian profile) centered on sample (position = 0 mm) and incident at _𝛼_ c = 0.30°. C) 500 × 50 μm elliptical beam shape (sharp edges), with the same conditions as (B). D) 500 × 50 μm rectangular beam shape (sharp edges), with the same conditions as (B). E) 150 × 50 μm elliptical (Gaussian) beam with an incident angle of _𝛼_ c = 0.18° and a sample position of 5 mm. The color scale of these images represents the minimum to maximum recorded intensity as spectral blue to red, respectively. Reproduced with permission.<sup>[119]</sup> Copyright 2020, International Union of Crystallography. 

applications of GIWAXS depth analyses reported by the field, as perovskite thin film solar cells are typically quite thin (300– 500 nm) and small grazing incidence angles are typically employed. Analyzing depth-dependent information as a function of _𝛼_ i also implies that the beam footprint on the sample changes, varying the ratio of surface/bulk signals and the scattering volume. Due to abrupt changes in the scattering intensity near the critical angle (Figure 17), the generation of quantitative depth profiling further requires a careful intensity normalization.<sup>[119]</sup> In a simple two-phase layered system, this could take the form of examining the relative intensity of the different scattering species rather than the absolute integrated signal. 

### _2.4.6. Grazing Incidence Footprint_ 

Understanding where and how the beam is incident on the perovskite film surface improves the reproducibility of the experiment. The grazing incidence projects a relatively large beam footprint length, _Lf_ , on the sample surface and is dependent of the beam height, _H_ , and incidence angle: 



<!-- Start of picture text -->
H<br>Lf = (30)<br>sin ( 𝛼 i )<br><!-- End of picture text -->

As illustrated in **Figure 21** A, a 50 μm tall beam will present a footprint of nearly 2 cm at _𝛼_ i= 0.15°, reducing quickly to 2.8 mm at _𝛼_ i= 1°. Thus, the footprint at low angles is often larger than the typical length of the sample and can easily be simulated to calculate the final incident profile for different angles of incidence, beam shapes and sizes, as well as varied sample lengths and positions (Figure 21B–E). 

While a desirable beam shape forms a sharp-edged rectangle, incident beams can also resemble more of an elliptical cross section (see Figure 1). The beam profile line shape may also vary, producing different distributions, i.e., rectangular or elliptical beam shapes with smooth (Gaussian/Lorentzian profile) or sharp edges. Figure 21B–E showcases some examples of these combinations, along with the effect of introducing an offset in the sample position. 

A larger footprint implies a larger probed surface area, which is useful to maximize the scattering intensity in thin films. However, longer footprints will smear out the detected signal and lower the resolution of recorded peaks (geometric broadening), because of the convolution of signals originating from the back and front of the footprint. Having a large footprint also implies that the beam can spill over the sample surface and scatter in the surrounding environment (air or underlying substrate), adding 

**2300760 (22 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.advenergymat.de** 



**Figure 22.** A) Schematic illustration of the beam-sample geometry when increasing the incident angle, _𝛼_ i. B) Synchrotron-based (ESRF BM01) GIWAXS patterns recorded from a halide perovskite/Si solar cell (≈20 × 20 mm<sup>2</sup> ) at different incident angles, using a 150 × 360 μm<sup>2</sup> ( _H_ × _V_ ) X-ray beam (12.964 keV). The perovskite layer is a 500 nm-thick CsI0.05[FA0.83MA0.17Pb(I0.83Br0.17)3]0.95 film. The perovskite structure has relatively high crystal symmetry at this mixed composition and is well-described by a cubic unit cell ( _Pm_ 3 _m_ ). C) Waterfall plot showing the azimuthal integration of 300 GIWAXS frames recorded between −0.42°≤ _𝛼_ i ≤ 4.0°, in increments of 0.02°. The green dotted line represents a continuation of the reflected X-ray beam which is incident on the detector, which intersects and defines _𝛼_ i = 0°. The color scale represents a heat map, of black (minimum) through to red, and eventually white (maximum). D) Full width at half maximum (FWHM) of the peak centered near 2.24 A<sup>−1</sup> . E) 1D integrated scattering profiles of the same peak at selected incident angles. 

to the background. Scattering from rough or dislodged particles at the edges can introduce dynamic microbeams artifacts that will compromise the data quality, that is, introduce distorted photon beam trajectories. 

(≈20 × 20 mm<sup>2</sup> ) and thick (500 nm), exaggerating the features identified above. A waterfall plot of the integrated 1D data (Figure 22C) help track several distinct transitions in the scattering conditions: 

### _2.4.7. General Evolution of the GIWAXS Signal with Increasing 𝛼i_ 

As showcased throughout this section, numerous aspects of GIWAXS are fundamentally determined by, and evolve with, the grazing incidence angle. Thus, in practice, it can be advantageous to acquire multiple GIWAXS images over a range of _𝛼_ i angles ( **Figure 22** A), rather than a single frame at a pre-determined _𝛼_ i value. Such datasets help manage several anomalous effects, including instrumental broadening, refraction, the missing wedge, and the in-plane scattering horizon. To examine how these features continuously evolve with _𝛼_ i, Figure 22B–E presents GIWAXS data recorded from a CsI0.05[FA0.83MA0.17Pb(I0.83Br0.17)3]0.95 perovskite thin film deposited on silicon, scanning over −0.42° ≤ _𝛼_ i ≤ 4.0°. Intended for solar cell applications, this perovskite wafer is relatively large 

- _𝛼_ i _<<_ 0: the beam is blocked by the raised edge of the sample and only a small part is transmitted through the sample edge, producing a high-angle shoulder peak. 

- _𝛼_ i ≤ 0: a significant part of the beam is absorbed by the edge or passes over and misses the surface, dropping the sample scattering background to a local minimum at _𝛼_ i = 0. 

- 0 _< 𝛼_ i ≤ _𝛼_ c: weak scattering signals emerge from the surfacesensitive evanescent regime ( _<_ 10 nm). A low- _q_ shoulder is formed due to scattering from the raised sample edge near the detector and refraction/waveguiding effects. The sample shadow (or horizon) appears on the detector. 

- _𝛼_ i ≥ _𝛼_ c: Scattering near the critical angle helps to maximize scattering from the films. A relatively large footprint (several millimeters) induces significant peak broadening. 

- _𝛼_ i _>> 𝛼_ c: The penetration depth increases, while the beam footprint rapidly decreases, narrowing all reflected Bragg 

**2300760 (23 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



**Figure 23.** Simulated evolution of the missing wedge boarder as a function of the grazing incidence angle. Note that the scattering horizon also increases along _q_ z with increasing _𝛼_ i, and is not shown here for clarity, that is, it will depend of features like the sample width and X-ray energy used. 

peaks. The scattering horizon continues to rise up the detector and other anomalous scattering and refraction effects disappear in this regime. 

Raising the detector-facing edge increases the angle of specular reflection vertically on the detector. Consequently, in Figure 22C the intersection of this feature with _q_ = 0 yields an accurate value for _𝛼_ = 0° without prior knowledge or calibration. 

Samples intended for solar cells typically near a full wafer, that is, tens to hundreds of mm<sup>2</sup> . The absorbing layer thickness is also relatively thick to absorb all the incident solar photons, and higher incident angles might be sought to improve the data quality. Incidentally, the raised sample edge casts a shadow/horizon on the detector and in-plane scattering information is consequently lost at high incident angles (Figure 22B). Under these conditions, evaluating the integrated GIWAXS profile of a textured thin film becomes troublesome as the detector might only record a subset of the Bragg peaks, impeding phase identification and/or structural analysis. 

The incident angle ( _𝛼_ i) also governs access to reciprocal space, as increasing _𝛼_ i will systematically narrow, and upward shift, the missing wedge residing out-of-plane ( **Figure 23** ). It follows that if a small-angle Bragg feature is oriented out-of-plane and not wellresolved at low _𝛼_ i values, increasing _𝛼_ i will expand access to this reciprocal space along _q_ r = 0. Alternatively, the missing reciprocal space can be recovered by collecting the scattering pattern at the incident angle matching the Bragg angle of interest, that is, tilting the sample normal to align with the Bragg scattering angle. 

### _2.4.8. GIWAXS Instrumental Peak Broadening_ 

The “true” linewidth of Bragg peaks scattered from a highly crystalline perovskite crystal are typically narrow and will depend on features like the crystallite size(s), disorder, and strain,<sup>[4]</sup> that is, 

### **www.advenergymat.de** 

aspects which are sample-dependent and contribute to the intrinsic peak width. In the real world, however, all diffractometers have their finite resolutions and the observed width will likely be dominated by instrumental/geometric broadening. Notably, the instrumental broadening introduced during GIWAXS substantially differs from other XRD methods. This is because, at small grazing angles ( _𝛼_ i _<_ 1°), the projected beam footprint will be extremely long. This can overpower all other contributions to peak broadening by smearing the scattering volume along beam path and forming a distribution of point-detector distances (Figure 21). This is in contrast to, say, the transmission XRD which merely exhibit a sample-limited scattering volume, for example, the dimensions of the sample holder/capillary. This is why GIWAXS profiles are generally always broader than the patterns recorded from powder XRD. 

The peak broadening introduced by GIWAXS instruments will be a convolution of geometric broadening ( _I_ ; beam divergence and scattering distance, pixel width, etc.), the emission resolution function of the beam ( _R;_ negligible for modern synchrotrons) and the dimensions of the scattering volume ( _F_ ), which is defined by the incident beam profile and footprint. Combined with the intrinsic scattering profile of the sample ( _S_ ), the product of these factors (i.e., _I_ × _S_ × _R_ × _F_ ) generate the observed peak width; **Figure 24** illustrates this for a simple step-like beam profile. Note that these descriptions are merely illustrative and quantitative description are still to come. To see the different influences in actions, Figure 22C presents the GIWAXS profiles of a highsymmetry cubic polycrystalline perovskite film (≈20 × 20 mm<sup>2</sup> ) over a range of _𝛼_ i values, while Figure 22D,E tracks the changes in a single representative peak. Considering the general line shape evolution, the competing factors identified in Figure 24A change over the different regimes of grazing incidence; a step-like function dominates at small _𝛼_ i and narrows quickly toward higher _𝛼_ i, before asymptotically approaching the inherent limit of _I_ × _S_ × _R_ . 

With fixed contributions from _S_ , _R_ , and _F_ , the magnitude of instrumental broadening is dependent on setup geometry and, specifically, the scattering angle, 2 _𝜃_ . One common line broadening function stems from early Caglioti papers;<sup>[132]</sup> the width of the diffraction peaks will gradually broaden non-linearly toward higher Bragg angles due to divergence, with an angular dependency represented simply via three broadening coefficients ( _U_ , _V_ , and _W_ ): 



<!-- Start of picture text -->
FWHM inst 2 = U tan2 𝜃 k +  V  tan  𝜃 k +  W (31)<br><!-- End of picture text -->

For a diffraction experiment with the area detector set normal to the incoming beam, this approximation needs to be used with care.<sup>[133]</sup> A well-defined standard powder sample is typically used to accurately characterize the instrumental broadening of a setup, like the NIST LaB6 standard, which has negligible sample broadening. In this way (assuming Gaussian-type peaks), extracting the widths of each peak in the experimental profile ( _FWHM_ exp) profile can yield the sample contribution ( _FWHM_ samp) via: 



<!-- Start of picture text -->
FWHM exp = √ FWHM inst 2 +  FWHM samp 2 (32)<br><!-- End of picture text -->

Instrumental broadening within GIWAXS profiles is dominated by geometric broadening, _B_ geo, which is introduced by the 

**2300760 (24 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



**Figure 24.** A) Qualitative illustration of the dominating factors leading to peak broadening in the observed the _𝛼i_ -dependent 1D GIWAXS profile, formed via azimuthal integration. The arrows in the instrumental broadening and GIWAXS footprint components indicate how the function narrows/broadening. B) Scatting profiles taken from the data set in Figure 20 recorded at different _𝛼_ i values. C) The widths of observed diffraction peaks, FWHM<sup>2</sup> , as a function of scattering angle (in units of degrees) for the GIWAXS patterns shown in (B). Fits have been made using Equation (31), showing a continuous change in the broadening with rising _𝛼_ i. 

scattering footprint ( **Figure 25** A). As _𝛼_ i increases the footprint reduces and the influence of geometric broadening falls away (Figure 22D,E). However, even titling the sample several degrees, that is, far beyond the critical angle, the footprint-induced broadening does not fall to zero; the changes in the peak broadening in Figure 22B,C continues to slowly evolve at relatively large _𝛼_ i values. For a rectangular beam with an incident footprint of length, _L_ f, on the sample surface, which is at a distance _L_ SD from the detector, the contribution of geometric broadening in the GIWAXS profile is described by<sup>[119]</sup> 



<!-- Start of picture text -->
Lf tan 2 𝜃<br>B geo = (33)<br>L SD<br><!-- End of picture text -->

The recording of broad GIWAXS peaks will impede the data quality, and even obstruct the phase identification of lower symmetry perovskite crystals which have subtle peak splitting and overlapping features. As such, it needs to be managed carefully if good resolution is sought. From the description of _B_ geo above, an easy strategy to reduce broadening is to increase _L_ SD, at the cost however of also reducing the measured _q_ range. 

### **www.advenergymat.de** 

On the other hand, a relatively straightforward and effective approach is to limit the scattering footprint to the width of the sample (Figure 25B). Notably, this is done by a reduction in the overall scattering volume/intensity from the sample surface and the final signal-to-noise needs to be monitored. To demonstrate the improvement realized via a sample-limited footprint, Figure 25C compares the normalized GIWAXS profile recorded from the same low-symmetry orthorhombic _𝛾_ -CsPbI3 perovskite thin film prepared into pieces with varying widths. Using the widest sample for the GIWAXS measurement, that is, on the order of full small-scale PV devices, several overlapping peaks remain obscured due to the broad line shapes. The use of narrower samples markedly improves the data quality and overlapping features associated with the orthorhombic distortion become wellresolved (Figure 25C). 

### _2.4.9. Scherrer Crystallite-Size Analysis in a GIWAXS Geometry_ 

Finite size effects within the scattering crystal leads to the distinct broadening of Bragg peaks and is quantifiably different to other forms of broadening, for example, instrumental broadening. Thus, the average crystallite size (more accurately the scattering coherence length) in a material can be estimated from an analysis of the peak widths using the widely adopted Scherrer grain-size analysis method.<sup>[135]</sup> It is tempting to treat GIWAXS data in a similar fashion and possibly correlate observed changes in the peak width with differences in crystallinity. As we have seen, however, the origins of peak broadening in GIWAXS may be convoluted and to employ a Scherrer analysis, Smilgies<sup>[134]</sup> prescribes a popular<sup>[136]</sup> correction. 

The Scherrer equation relates the broadening of a diffraction peak ( _hkl_ ), _B_ hkl, to the average grain length, _D_ hkl, in the material by: 



<!-- Start of picture text -->
K𝜆<br>Dhkl = (34)<br>B hkl cos  𝜃 hkl<br><!-- End of picture text -->

where _𝜆_ is the x-ray wavelength, _𝜃hkl_ is the Bragg angle and the shape factor _K_ is most often given a value of 0.9,<sup>[136]</sup> as originally reported by Scherrer. This can be represented in reciprocal space rather than angular space, as 



<!-- Start of picture text -->
Δ  q hkl = 4 𝜋 cos ( 𝜃 hkl)  B hkl (35)<br>𝜆 2<br><!-- End of picture text -->

where we identified the breadth _B_ hkl = Δ(2 _𝜃_ hkl) to obtain the simple expression 



<!-- Start of picture text -->
D hkl = 2 𝜋K ∕Δ q hkl (36)<br><!-- End of picture text -->

This can subsequently be linked to another useful parameter which represents the average number of Bragg scattering planes, 



<!-- Start of picture text -->
N hkl = D hkl = q hkl (37)<br>d hkl Δ q hkl<br><!-- End of picture text -->

To apply these equations to GIWAXS data (recorded using a large-area detector), the measured peak broadening needs to be 

**2300760 (25 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 25.** A) Schematic depiction of the radial, geometric broadening from both a top and side view, introduced by the finite scattering volume/footprint. Reproduced with permission.<sup>[134]</sup> Copyright 2009, International Union of Crystallography. B) Illustration of the scattering footprint for a fixed beam height and incidence angle, which is beam limited for relatively large samples (left) and sample limited when its width is reduced (right). The arrows indicate the relative separation of scattering signals, which broadens all peaks. C) Comparison of normalized 1D integrated GIWAXS scattering profiles recorded from a solution-processed _𝛾_ -CsPbI3 perovskite thin films of varying widths using an incident angle of 0.2°, a beam energy of 12.95 keV and a sample-to-detector distance of 22.9 cm. Narrower scattering features are realized with a sample-limited footprint, whereby some overlapping peaks of the low-symmetry orthorhombic phase ( _Pbnm_ ) can be resolved (marked by crosses). 

corrected<sup>[134]</sup> for the beam divergence ( _B_ div), the energy bandwidth ( _B_ BW), and the GIWAXS geometry ( _B_ geo). The energy bandwidth is given by the narrow energy resolution of the monochromatic X-ray source (i.e., Δ _E_ / _E_ ≈ 10<sup>−4</sup> ), and thus can be ignored. On the other hand, if the widths of a Gaussian shaped X-ray beam are measured at the sample ( _𝜎_ S) and at the beam stop ( _𝜎_ B), the beam divergence can be found by 



<!-- Start of picture text -->
√ 𝜎 S 2 − 𝜎 B 2<br>B div = (38)<br>L SD<br><!-- End of picture text -->

The impact of _B_ div is typically unimportant and broadening due to the footprint ( _B_ geo) will dominate. Fitting each peak in the experimental range with a pseudo-Voigt profile<sup>[137]</sup> we can correct the measured widths, _B_ expt, accounting for the resolution of the setup: 



<!-- Start of picture text -->
B hkl = √ B 2 expt − B res 2 (39)<br><!-- End of picture text -->

where the angular resolution is defined as 



<!-- Start of picture text -->
B res (2 𝜃, 𝜒 ) = √ B div( 𝜒 ) 2 +  B geo(2 𝜃 ) 2 (40)<br><!-- End of picture text -->

or in terms of reciprocal resolution 



<!-- Start of picture text -->
Δ  q res = 4 𝜋 cos (41)<br>𝜆 ( 2 𝜃 2hkl )  B 2res<br><!-- End of picture text -->

This correction has now been widely deployed to estimate the crystallite sizes in polycrystalline metal halide perovskite thin 

films using GIWAXS.<sup>[118,136,138–140]</sup> Notably, however, this model does not actually capture the average crystal grain size, but the average coherence length within ordered scattering domains. Further, the application of this model subsequently assumes that the crystallite size is the sole contributor to sample-related peak broadening, ignoring other aspects of disorder, and determinations of _D_ hkl are often states in terms of estimated upper/lower limits. 

## **3. GIWAXS Data Processing and Analysis** 

### **3.1. Resolving Perovskite Symmetry Changes and Phase Transitions** 

Thermal phase transitions in metal halide perovskites are influenced by a soft inorganic metal halide sublattice composed of corner-sharing octahedral, [BX6]<sup>4−</sup> , that facilitate tilting about one or more of the principal axes. While both halide and oxide perovskites form the archetypal cubic _Pm3m_ ̅ space group at high temperatures, decreasing temperature reduces the unit cell volume and drives octahedral tilting, which lowers the average crystal symmetry into tetragonal and orthorhombic space groups. Group theory identifies fifteen candidate space groups for metal halide perovskites identified with their Glazer notation in **Figure 26** A.<sup>[141,144,145]</sup> Increasingly large tilt angles eventually destabilize the perovskite structure and can cause a transition to non-perovskite phases.<sup>[23]</sup> 

Subtle differences in crystal structure between related polymorphs (Figure 26B) complicate efforts to accurately resolve phase transitions or symmetry changes imposed by external factors, like substrate clamping.<sup>[25]</sup> The transitions from a 

**2300760 (26 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 





**Figure 26.** A) Overview of reported group-subgroup symmetries of tilted halide perovskites, with comparison to the archetypal CaTiO3 perovskite system. The tilts are identified using Glazer’s<sup>[141]</sup> notation and the dashed lines correspond to first-order transitions. Other subgroups have been reported under atypical environments and are not included. Reproduced with permission.<sup>[142]</sup> Copyright 2002, International Union of Crystallography. B) Illustration of reversible phase transitions in polymorphic perovskite structures, transitioning between cubic and pseudocubic structures via octahedral tilting. Reproduced with permission.<sup>[143]</sup> Copyright 2020, American Chemical Society. 

cubic to the tetragonal and orthorhombic phases manifest in X-ray diffraction as narrow splitting of the Bragg peaks, with the emergence of new, lower intensity, superlattice reflections. This is exemplified in **Figure 27** , which shows simulated diffraction patterns of metal halide perovskites in _Pm3m, P4/mbm_ ̅ , and _Pbnm_ space groups with peak broadening of 0.01 and 0.11Å<sup>−1</sup> FWHM.<sup>[26]</sup> For the simulated profile to correctly capture the physical structure, it must account for all of the diffraction peaks, not just a single targeted Bragg reflection. This is unfortunately not done in all reports. Ideally, the whole pattern should be used to model all structures (Section 3.2.3.). 

Accurate phase determination warrants X-ray scattering experiments with good angular resolution to confidently deconvolute closely overlapping peaks. Likewise, a high signal-to-noise ratio is beneficial to distinguish the low-intensity superlattice peaks that emerge during a symmetry reduction. A GIWAXS experiment designed to study phase transitions may elect to: 1) position the area detector farther from the sample, improving _q_ -resolution at the cost of _q_ -range, and 2) employ a larger incidence angle (i.e., 3°) to reduce smearing from a large beam footprint. Even with 



**Figure 27.** Top: Integrated 1D GIWAXS profiles recorded from nanocrystals of mixed-cation FA _x_ Cs1− _x_ PbI3 perovskite thin films. Bottom: Comparison to simulated XRD patterns for compositions _𝛼_ -FAPbI3, _𝛽_ - FA0.5Cs0.5PbI3, and _𝛾_ -CsPbI3 in the indicated space group. The solid arrows in (A) indicate the appearance of low-symmetry reflections, from cubic to tetragonal splitting, while the dashed arrows identify orthorhombic splitting. Darks line are for peak FWHM of 0.01 Å<sup>−1</sup> while lighter lines are for 0.11Å<sup>−1</sup> FWHM. Reproduced with permission.<sup>[26]</sup> Copyright 2020, American Chemical Society. 

high angular resolution and minimized instrumental broadening, sample contributions to peak broadening are important. For example, Scherrer broadening increases peak widths as crystallite size decreases and halide perovskite nanocrystals are accordingly even more prone to such peak broadening.<sup>[146]</sup> Further, nonuniform strain where the lattice parameter varies locally, such as at a material interface, also broadens peak widths alongside lattice defects and compositional heterogeneity. 

Despite the challenges posed to effective experimental design and analysis, GIWAXS has been employed widely to study the phase space of perovskites and toward improving the stability of desirable phases. The azimuthal information that manifests in GIWAXS is particularly useful to observe the orientation of lower symmetry phases in films. For example, studies of all-inorganic and hybrid halide perovskite films have shown the annealinginduced strain in cubic phase films relaxes during tetragonal and orthorhombic phase transitions by aligning the longer _c_ crystallographic axis with a resultant tensile stress introduced by substrate clamping ( **Figure 28** ).<sup>[25,147]</sup> Phase modification of perovskite nanocrystals has also been demonstrated by compositional alloying of the A-site cation (Figure 27). The full phase progression from a cubic FAPbI3 to an orthorhombic CsPbI3 was observed with GIWAXS, that is, for FA _x_ Cs1− _x_ PbI3 alloys. Despite peak broadening from nanocrystals,<sup>[148]</sup> reliable phase determination is made possible by high resolution scattering 

**2300760 (27 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.advenergymat.de** 



**Figure 28.** A) GIWAXS data of MAPbI3 film on glass substrate at room temperature showing scattering vector ( _Q_ ) with respect to the azimuthal angle on the 2D area detector where _𝜒_ = 90°, −90° corresponds to scattering in-plane with respect to the film surface, and _𝜒_ = 0° corresponds to scattering normal to film surface. The color scale represents a heat intensity map, with red as the maximum and dark blue as the minimum. The white lines coincide to B) integrated intensity profiles at a fixed _𝜒_ , identified by their corresponding horizontal while lines in (A). The tetragonal-split (002) peak is better resolved as _𝜒_ moves away from surface normal, showing a preferred in-plane orientation of the longer crystallographic axis. Reproduced with permission.<sup>[147]</sup> Copyright 2022, American Chemical Society. 

and attentive Rietveld refinement.<sup>[26]</sup> High flux and fast integration times also enable the practical mapping of multimodal phase space for alloys, demonstrated for inorganic mixed-halide compositions.<sup>[149]</sup> 

### **3.2. Analysis of 1D GIWAXS Profiles** 

### _3.2.1. Simulating 1D Diffraction Patterns and Phase Identification_ 

Phase identification is essential for the accurate interpretation of X-ray scattering data. Metal halide perovskite systems can demonstrate a mixture of constituent phases, including the intended photoactive perovskite phase, and inactive polymorphs,<sup>[150–152]</sup> as well as degradation byproducts, solvate intermediate phases,<sup>[153–159]</sup> and lower-dimensional phases (i.e., 2D, quasi-2D).<sup>[160,161]</sup> The phase fractions that form vary, even between films of equivalent target stoichiometry,<sup>[162]</sup> with the phases present dependent on parameters such as the processing conditions and preparation environment, as well as the storage environment and sample age.<sup>[163,164]</sup> 

Accurate structural refinement requires an understanding of potential phases, as well as a set of expected phases in the film. To achieve this, a superposition of the simulated 1D (or powder) diffraction patterns from known constituent phases is used to identify the relative intensity contribution of these phases; see **Figure 29** . Gratia et al. briefly discuss the importance of quantitative phase analysis when drawing conclusions from scattering data on perovskite thin films.<sup>[150]</sup> The authors note the existence of multiple reflections evident across hexagonal polymorphs (2H, 4H, 6H) of the perovskite (FAPbI3) _x_ (MAPbBr3)1− _x_ stoichiometry. These reflections coincide with the commonly indexed (001) 2H-PbI2 reflection at _q_ ≅ 0.9 Å<sup>−1</sup> (2 _𝜃_ ≅ 12.7°, CuK _𝛼_ ). Additionally, in this work, Gratia et al. suggest that 2H-PbI2 is often erroneously indexed in place of hexagonal polymorphs of the perovskite and point to examples in the literature. Figure 29 shows 

examples of possible phases that may coexist alongside the target perovskite phase—further highlighting the importance of quantitative phase analysis for accurate interpretation of X-ray scattering data. 

Crystallographic Information Files (CIF) are a standardized format for encoding structural information—this information can be used to simulate diffraction of a crystal system at a selected X-ray wavelength. Software packages such as VESTA,<sup>[170]</sup> FullProf,<sup>[171]</sup> GSAS-II,<sup>[172]</sup> and TOPAS<sup>[173]</sup> make use of these CIFs to simulate diffraction data and/or for structure profile refinement (Rietveld). Multiple CIF databases exist to aid researchers looking to simulate 1D diffraction data for phase identification and quantitation; these include Materials Project,<sup>[174]</sup> Inorganic Crystal Structure Database (ICSD),<sup>[175,176]</sup> ICDD PDF-4+,<sup>[177]</sup> Crystallography Open Database,<sup>[178]</sup> American Mineralogist,<sup>[179]</sup> and CCDC Cambridge Structure Database.<sup>[180]</sup> 

### _3.2.2. Limitations to Quantitative Analysis and Structural Refinement of GIWAXS Data_ 

Conversion of raw 2D GIWAXS area detector images to quantitatively useable “reduced” 1D profiles requires care. In general, accurate conversion requires a thorough understanding of the sample characteristics and geometric constraints of the X-ray detection scheme—both of which contribute to the 2D detector intensity. Nevertheless, under-corrected (or entirely uncorrected) 2D GIWAXS detector images are often presented in the literature, and use of these can result in erroneous quantitative phase analyses. Appropriate sample preparation (Figure 25) and wellconstructed experimental collection schemes are essential for obtaining quality data and mitigating sources of error to improve the accuracy of structural refinement using GIWAXS data. 

The preparation of high-quality metal halide perovskite thin films for analysis requires stringent substrate choices based on the application. Topologically rough films are generally 

**2300760 (28 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 





**Figure 29.** Simulated Cu K _𝛼_ powder diffraction patterns of various phases indexed in the literature that pertain to thin film metal halide perovskites. Here, we list several examples of potential phases, including hexagonal polymorphs (2H, 4H, 6H, 8H) of the (FAPbI3) _x_ (MAPbBr3)1− _x_ and FAPbX3 perovskite phases, cubic ( _𝛼_ ), tetragonal ( _𝛽_ ), and trigonal ( _𝛿_ ) FAPbI3 phases, PbI2 • _n_ (solv.) solvate intermediate phases, and polyphases of the lead halide perovskite precursor salt PbI2. The dashed vertical line represents the commonly indexed (001) 2H-PbI2 reflection at _q_ ≅ 0.9 Å<sup>−1</sup> (2 _𝜃_ ≅ 12.7°, CuK _𝛼_ ). Crystallographic information files (CIFs) used for powder XRD simulations are cited in numeric order with respect to decreasing order of the figure legend (2H, 4H, 6H, …, P63mc, R-3m, P3m1). The CIF files for the alphabetical labels in the figure can be retrieved from Refs.<sup>[48,117,150,153,154,158]</sup> , and<sup>[165–169]</sup> . Note that we have used the experimentally determined lattice constants from Ref. [167] to update the lattice parameters databased for the 2H-PbI2. 

unavoidable in halide perovskite synthesis and occasionally even advantageous for optical scattering in devices. On the contrary, smooth films are desirable for acquiring quality 2D GIWAXS data. Smoother films may be obtained by using a flat Si-wafer substrate and it is recommended to conduct contact-angle wetting experiments to validate that the substrate surface energy remains nominally the same with respect to the surface energy of transport layers used in typical device structures (e.g., 2PACz, PTAA, PEDOT:PSS).<sup>[4]</sup> Conversely, it is sometimes advisable to utilize the true device architecture to preserve the structural characteristics of the film, particularly if the film texture is notably sensitive to the substrate contact-angle and surface roughness. 

Film thickness must also be considered when quantitatively comparing phase fractions and texturing between different thin film samples. Variation in film thickness results in a disparity between total scattered intensity. It is thus prudent to empirically verify the spatial dependence of perovskite film thickness, particularly in the case of spin-coat deposited samples. Cleaving the edges of samples is an effective technique for removing sample edge artifacts and non-uniform film formation. Reducing the sample width will reduce the beam footprint of the in-plane scattered X-rays, improving the resolution of the detected scattering intensity (Figure 25) when acquiring data at grazing angles of incidence.<sup>[181]</sup> 

Most X-ray scattering beamlines at synchrotrons rely on the use of pixelated large 2D area detectors to log data. Capturing diffraction data using a 2D detector geometry has significant benefits in terms of information gained, however, use of such a detection scheme comes at the user expense of more complicated data 

analysis. During data collection, undesirable effects can corrupt the image quality and corrections must be applied to minimize their distortion. For quantitative analysis of GIWAXS images and the structural refinement of integrated scattering patterns, careful corrections are necessary. 

Nowadays, modern detectors apply detector specific corrections before saving the raw image. Additional image corrections depend on the instrument used and are comprehensively discussed in the literature;<sup>[37,182,183]</sup> we summarize the most important corrections in **Table 2** . Accurate image transformation is critical for meaningful phase identification and interpretation of crystallite orientation and texture. A proper depiction of the intensity measured using a 2D area detector requires mapping a projection of the Ewald sphere, or “sphere-of-reflection”, onto the detector plane.<sup>[39]</sup> It is essential to use the known geometry of the sample and detector configurations to transform the 2D GIWAXS detector images into _q_ z and _q_ r ( _q_ xy) in reciprocal space. These Ewald sphere image corrections are required prior to 1D analysis for accurate data interpretation, quantitative phase analyses, and structure refinement. 

Accurate structure refinement is complicated by information loss along the out-of-plane scattering axis that results from the GIWAXS experiment geometry. Pole figure construction is a useful method for obtaining an accurate representation of the orientational distribution of crystallites in the film.<sup>[39,184]</sup> Acquisition of both a grazing incidence diffraction pattern and a local specular diffraction pattern at the Bragg condition ( _q_ B), also known as a “wide-angle rocking curve”, allows for the merging of both datasets to construct a complete pole figure. 

**2300760 (29 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Table 2.** Indexed list of common and useful 2D image corrections used in both WAXS and general diffraction experiments. 

|#|Image correction|Description|a)IAS|b)IES|c)CI|Ref.|
|---|---|---|---|---|---|---|
|1|Reference calibration|Maps the 2D detector pixel to some_q_/2_𝜃_-range based on<br>detector geometry: PoNI (point-of-normal-incidence),<br>sample-detector-distance, and detector rotations.<br>Calculated with respect to an isotropic powder reference<br>sample.|✓|✓|CR|[185–189]|
|2|Ewald, orientation sphere|Corrects for image distortion from a planar detector<br>intersecting the scattering sphere. Detector geometry and<br>incidence angle modify this correction.|✓|✓|CR|[39,190]|
|3|Detector masking|Removes non-zero intensity (dead pixels), pixel gaps, and<br>anomalously intense pixels (e.g., hot or saturated pixels)|✓|×|CR|[191]|
|4|Detector flatfield correction|Corrects for interpixel sensitivity – can vary on the order of<br>15%.|✓|×|CR|[191,192]|
|5|Background subtraction|Remove background signal from substrate, dark current (see<br># 11), or additional inline media (i.e., Kapton film).|✓|×|CDC|[191]|
|6|Solid angle correction|Pixel intensity varies with the solid angle subtended by that<br>pixel; pixels accept different widths of scattered intensity.|✓|×|CR|[189,191]|
|7|Detector Efficiency|Detector pixels at greater oblique angles have a larger medium<br>attenuation and increased absorption probability by the<br>detector sensor. Pairs with solid angle correction geometry.|✓|×|CR|[182]|
|8|Beam footprint|Beam footprint (height and width) determine the<br>measurement area. Footprint is modified with incidence<br>angle or tunable through X-ray optics (e.g., collimator,<br>Soller slits).|✓|✓|CDC|[119]|
|9|Polarization correction|Horizontal polarization of synchrotron radiation results in<br>angle-dependence of diffracted intensity variation.|✓|×|CDC|[39,193,194]|
|10|Lorentz correction|Peaks with different scattering intercept the Ewald sphere to<br>differing extents.|✓|✓|CDC|[194,195]|
|11|Dark current correction|Subtract detector signal measured with a cover over the<br>detector, to eliminate background from “dark current”.|✓|✓|CDC|[191]|
|12|“Dezingering”|Removes cosmic background radiation "zingers" that are<br>incidentally detected, saturating the image at a single pixel.|✓|×|CR|[191]|
|13|X-ray refractive index|Material specific parameter, the X-ray refractive index is a<br>function of wavelength, given as:_n_=1 –_𝛿_+_i𝛽_|✓|✓|CDC|[119]|
|14|Absorbance correction|X-ray pathlength determines attenuation of the beam through<br>the measured sample volume. Pathlength is modified by<br>complex X-ray refractive index (# 13), film thickness, and<br>incidence angle.|✓|✓|CDC|[39,182]|
|15|“sin(_𝜒_)” correction|Rescales detected intensity to accurately represent the<br>preferred orientation of probed crystallites. Crystallites with<br>_qB_ oriented to the out-of-plane scattering axis do not result<br>in observable diffraction. Pairs with corrections in (# 16).|✓|✓|CDC|[39,184]|
|16|Pole figure construction|Technique for filling in the “missing wedge” of information,<br>evident after the Ewald sphere correction (# 2).|✓|×|CDC|[39]|
|17|Incident beam intensity<br>rescaling|Synchrotron injection modes influence the stability of beam<br>intensity. Proper intensity rescaling should accommodate<br>for the injection scheme.|✓|✓|CDC|[196]|
|18|Scherrer broadening/axial<br>divergence|Used in refinement as a smearing parameter, rather than a<br>desmearing parameter for image correction. Beam<br>collimation (and beam divergence) contribute to the<br>linewidth resolution of the instrument.|✓|×|CDC|[197]|
|19|Energy dispersion|Energy resolution of the incident X-ray beam spot impacts the<br>range of outgoing scattering vectors. Monochromators are<br>generally used to aide with this issue, but sources will<br>generally have some finite energy resolution. Normally<br>unimportant.|✓|×|CDC|[194]|



> a) IAS, Intra-sample correction; b) IES, Inter-sample correction; c) CI, Correction importance; CR, Critical correction; CDC, Case dependent correction. 

**2300760 (30 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### _3.2.3. Quantitative Phase Analysis and Rietveld Refinement_ 

Quantitative phase analysis is commonly conducted using the Rietveld method for structure refinement.<sup>[198]</sup> Introduced by Hugo Rietveld in 1969,<sup>[199]</sup> it remains a popular approach to this day for modelling diffraction patterns (initially neutrons, later utilized for X-rays) of crystalline materials. By directly examining the Bragg profile intensities recorded via a step-wise scanning measurement of a randomly orientated crystalline powder, the area, width and position of these peaks can be used to determine many aspects of the materials structure. In a GIWAXS geometry, several of the underlying analytical principles of Rietveld refinement are greatly impacted and special attention must be paid when modeling the integrated profile.<sup>[198,199]</sup> To contextualize this impact, the basic analytical principles include: 

_Peak Line Shape_ : If a Gaussian distribution is assumed, then the contribution of any given Bragg peak (centered at 2 _𝜃_ k) to the scattering profile, _yi_ (2 _𝜃_ ), is given by: 



<!-- Start of picture text -->
2<br>y i =  I B exp −4 ln (42)<br>[ ( FWHM 2 ) (2 𝜃 − 2 𝜃 B)2 ]<br><!-- End of picture text -->

Here _I_ B is the calculated intensity of the Bragg peak. As outlined in Section 2.1, the intensity is determined from the structure factor, the Lorentz factor, and the multiplicity of the reflection. For the latter contribution, low-dimensional structural motifs, like 2D metal halide perovskites, are more complex as they have lowsymmetry unit cells. Likewise, several other aspects of the GIWAXS geometry will impact the accurate determination of the peak intensity; for instance, the scattering horizon, texture formation in the film, and the limited access to features scattered directly out-of-plane (i.e., the missing wedge). 

_Preferred Orientation_ : In powder XRD, the intensity of any given Bragg peak, _I_ B, is calculated considering the scattering cross-section, and assumes a fully random orientation of 3D scattering domains. In reality, however, the observed intensity in a GIWAXS experiment is heavily influenced preferred crystal orientations (Figure 11), that is, texture. Under such circumstances, the observed peak intensities will differ from that calculated for a given crystal symmetry with a completely random distribution. When the effect is not too pronounced and the large-area X-ray detector can detect a sufficient sample of the scattering profile, a correction factor is introduced to account for the preferred orientation of the system. In its simplest form,<sup>[200]</sup> this correction can be described as: 



<!-- Start of picture text -->
I corr =  I obs exp ( − G𝜔 2) . (43)<br><!-- End of picture text -->

Here _I_ obs is the intensity expected for a random sample, _G_ is the preferred orientation parameter which can be optimized during structural refinement and _𝜔_ is the acute angle between the scattering vector and the normal of the crystallites (i.e., texture direction). 

_Structural Refinement_ : At a given _2𝜃_ , more than one diffraction peak may contribute to the profile, and the intensity is simply the sum of all peaks contributing at that _2𝜃_ . The basic principle of structural refinement is to minimize a function _M_ which represents the difference between a calculated profile ( _y_ calc) and the 

**www.advenergymat.de** 

observed data ( _y_ obs): 



<!-- Start of picture text -->
M = ∑ W i{ y i obs − 1 c y i calc }2 (44)<br>i<br><!-- End of picture text -->

where _W_ i is the statistical weight (from the counting statistics) and _c_ is an overall scale factor fitting parameter. 

Rietveld refinement involves the input of a user estimated structure solution, including both image correction factors and intra-/inter-sample refinement parameters. This initial guess is then “refined” using a non-linear least squares minimization (Equation (4)) to reduce the weighted difference between measured and calculated scattering patterns. Prior to input of an approximate structure for structure determination, it is necessary to index each identifiable peak in the data to classify known phases, using this as a basis to assign a space group to each phase and fit the whole pattern.<sup>[201]</sup> It should be noted that the Rietveld refinement method uncovers a local minimum in the extensive parameter space of possible structure solutions—meaning that any calculation is a possible structure solution. Nevertheless, when used appropriately, the Rietveld approach is a powerful and insightful tool for conducting quantitative phase analysis. 

As an example, Vigil et al. demonstrated the application of Rietveld refinement on 2D GIWAXS images ( **Figure 30** ) collected on compositionally varied FA _x_ Cs1- _x_ PbI3 nanocrystal (NC) samples.<sup>[26]</sup> Refinement of azimuthally integrated 1D GIWAXS patterns were used to construct a relationship between compositional range ( _x_ in FA _x_ Cs1- _x_ PbI3) and structural parameters, to determine crystallographic phase transition regions (i.e., _𝛼_ , _𝛽_ , _𝛾_ -phases). Notably, complications in the refinement arise during the modeling of split-occupancy between organic-inorganic cations, in which the disorder of the organic cation is unable to be accurately refined. Site-occupancy fraction (SOF) of the organicinorganic A-site cation in FA _x_ Cs1- _x_ PbI3 is modelled by replacing the FA<sup>+</sup> organic cations with an electron density equivalent Mn<sup>0</sup> inorganic cation. Using this approximation, a simplified model of the FA _x_ Cs1- _x_ site occupancy fraction is calculated using a mixed Cs<sup>+</sup> /Mn<sup>0</sup> system. 

### _3.2.4. The Le Bail Refinement Method_ 

An accurate Rietveld refinement procedure ideally uses a wide scattering range, narrow/unbroadened Bragg peaks and an intensity profile which accurately represents the crystal scattering cross-section.<sup>[202]</sup> Several geometric features of GIWAXS impact the reliability of the Rietveld refinement approach by not adequately meeting these needs. Alternatively, if one considers simply the crystal symmetry (i.e., the space group) and omits inputs related to the material composition, a simpler model with less parameters can be used to model the whole scattering profile, and accurately confirm the phase and extract the unit cell parameters. For this, the Le Bail profile fitting approach<sup>[203]</sup> has proven successful for the lattice refinement of GIWAXS data recorded from metal halide perovskite thin films.<sup>[23–25,28]</sup> 

The Le Bail method considers the intensities of Bragg peaks (from powder diffraction data) in order to generate profiles that are suitable to determine the phase/symmetry of the crystal and refine its unit cell. It is not necessary to know the structural 

**2300760 (31 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 30.** A) 2D GIWAXS images recorded from spin-cast FA _x_ Cs1− _x_ PbI3 nanocrystal thin films as a function of mixed cation composition, _x_ . Here the dashed lines indicate the _q_ -range for the out-of-plane and in-plane intensity profiles shown in (B) and (C). Scattering profile integrated B) out-of-plane and C) in-plane. The solid and dashed arrows correspond to the emerging tetragonal and orthorhombic reflections, respectively. D) Shows the sequence of new Bragg reflections due to symmetry reductions. E–G) Rietveld refinements of 1D integrated GIWAXS patterns; data (red circles) were refined (blue lines) to the space group inset. The difference patterns are shown as gray circles. Here, the refinement on the metal halide perovskite system containing complex A-site organic cations (e.g., FA+) was simplified through the substitution of a similar electron density element Mn<sup>0</sup> . Reproduced with permission.<sup>[26]</sup> Copyright 2020, American Chemical Society. 

factor and associated structural parameters, since they are not considered in the fit. A general workflow follows; i) locating peak positions; ii) indexing the pattern to determine the unit cell parameters, and iii) determination of the space group (Figure 26A) based on anticipated symmetry and the presence/absence of certain reflections (Figure 30D). The Le Bail algorithm then involves optimizing the profile (including the Bragg line shapes) and the peak intensities to refine the diffraction pattern. An added advantage of the Le Bail method is its ability to readily include multiple material phases and allow the evaluation of phase-purity. 

### **3.3. Simulating 2D GIWAXS Images** 

An understanding of 1D X-ray diffraction simulation and the GIWAXS data corrections described in Section 3.2 are critical to accurately analyze and interpret experimental scattering patterns. 

For polycrystalline thin films with varied degrees of texture, the scattering in _q_ -space are spheres with non-uniform intensity distributions and give rise to incomplete arcs on an area detector.<sup>[204]</sup> It is therefore also important to understand and simulate the 2D nature of oriented GIWAXS patterns, and this represented the preferred method of analysis. 

Simulating 2D GIWAXS images is of particular interest when considering low-dimensional perovskite systems ( **Figure 31** ), due to their inherent structural asymmetry, preferential crystallization, and optoelectronic anisotropy.<sup>[10,41,205]</sup> Care must be taken to accurately simulate the relative intensity of scattering peaks, where scattering factors, ionic charge, polarization, and polymorphism must be considered. Scherrer analysis can help guide the quantitative analysis of peak broadening, elucidating crystallite size, and structural defects (Section 2.4).<sup>[206,207]</sup> 

As an example, Figure 31 presents an approach for reliably simulating the 2D GIWAXS pattern from a highly oriented 

**2300760 (32 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.advenergymat.de** 



**Figure 31.** A) Experimentally collected GIWAXS from a thin film of (BA)2(MA)2Pb3I10 Ruddlesden–Popper 2D perovskite. B) Simulated GIWAXS pattern with peak broadening to agree with experimental GIWAXS results. C) Comparison of linecuts of both the experimental and simulated intensity along the _qxy_ axis. Reproduced with permission.<sup>[208]</sup> Copyright 2018, American Chemical Society. 

quasi-2D (BA)2(MA)2Pb3I10 perovskite with fiber texture. Using the solved crystal structure in the literature,<sup>[54]</sup> the structure factors and d-spacings were exported using VESTA<sup>[170]</sup> and peak positions in the _qxy–qz_ plane were calculated assuming a fibertexture geometry. Diffraction peaks were approximated as Gaussian functions and the height associated with the peak was given by the square of the structure factor (𝐼ℎ𝑘𝑙 = |𝐹<sup>2</sup> ℎ𝑘𝑙<sup>|)foragiven</sup> Bragg reflection accounting for geometric effects such as Lorenzpolarization (LP, see Equation (3)). The resultant image is the final simulated diffraction pattern was realized after summing all contributions. While it is common in the literature for researchers to write their own scripts using Python or MATLAB, several are also available on GitHub, such as X-ray Scattering Tools.<sup>[209]</sup> This package simulates peak positions and intensities, and requires an input CIF file, VESTA, and Python 3.<sup>[208,210]</sup> GIXSGUI is a MATLAB-based software developed to visualize data and support a detailed analysis of the orientation of crystalline nanostructures from scattering data, as well as 3D indexing, and offers the useful capability for indexing a measured data set against CIF simulations.<sup>[194]</sup> NANOCELL is an additional option to simulate periodic continuous nanostructures in films.<sup>[211]</sup> SimDiffraction is another program designed to quantitatively analyze and model the GIWAXS patterns of textured films.<sup>[212]</sup> The program indexGIXS allows for the interactive visualization of GIWAXS data.<sup>[213]</sup> The DPC (Diffraction Pattern Calculator) toolkit is for the identification of crystal unit-cell parameters from GIWAXS, however, it requires a well-defined single-crystal scattering reference.<sup>[214,215]</sup> For polymorphic or incompletely crystallized films, GIWAXS-SIIRkit ( **Figure 32** ) is a freely available package of tools facilitating the direct comparison between the observed experimental scattering and scattering data simulated with Monte Carlo calculations, without assuming a prior knowledge of material packing.<sup>[41]</sup> 



**Figure 32.** Result of the “view peaks” button, one of several tools available in the GIWAXS-SIIRkit GUI<sup>[119]</sup> which can be used to view and modify the data indexing and simulation results. Reproduced with permission.<sup>[119]</sup> Copyright 2020, International Union of Crystallography. 

ing texture.<sup>[4,216]</sup> As we saw in Section 2.3, such features can be quantified through careful GIWAXS analysis. Below we will identify low-dimensional perovskites as being oriented out-ofplane, or aligned vertically, when they have their inorganic metal halide sublattice orientated along the direction of the substrate normal. Conversely, a 2D sheet oriented in-plane aligns with the film plane. Subsequently, at the device-level, the implications of orientation-dependent properties become apparent in textured 2D perovskite films, which possess significant charge transport<sup>[66,67]</sup> and optical absorption anisotropy.<sup>[87]</sup> 

edge of material packing.<sup>[41]</sup> The highly orientated stacking of low-dimensional layered perovskites within a thin film deserves a specialized analysis, where the entire family of peaks is integrated over a set _q_ -width in _qxy_ **3.4. Crystal Orientation and Texture Formation in** or _qz_ . Both the radial and angular widths of the GIWAXS diffrac- **Low-Dimensional Halide Perovskite Thin Film Devices** tion spots should be considered. The angular width is correlated to the degree of crystallite orientation (Section 2.3), while the raThe properties of polycrystalline perovskite thin film are highly dial width of the diffraction peaks may be related to the average dependent on various structural features in the film, includcrystallite size through the Scherrer equation (Section 2.4).<sup>[206]</sup> 

**2300760 (33 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



**Figure 33.** A) Fully isotropic polycrystalline film, where scattering rings are detected where the area detector intersects the diffraction spheres. B) Outof-plane fiber texture typical of metal halide perovskite thin films, where the scattering is detected as arcs. Reproduced with permission.<sup>[204]</sup> Copyright 2014, Woodhead Publishing Limited. 

In the literature, the degree of orientation may be quantified as a ratio of peak intensities, which neglects the scattering effects of overlapping peaks, incomplete crystallinity, and film quality, and is therefore not recommended. Though, it is possible to resolve different modes of overlapping orientated signals.<sup>[217]</sup> 

The orientation distribution ( **Figure 33** ), known as pole figures<sup>[204]</sup> to represent the film texture, are generated by integrating the intensity along the q-axis as a function of the polar angle chi ( _𝜒_ °), corrected for with the “sin( _𝜒_ ) correction” (see section 2.3 and<sup>#</sup> 15 in Table 2).<sup>[39,160]</sup> The pole figure construction assumes that the sample is isotropic in-plane, which is true for perovskite films without directed in-plane orientational processing, for example, introduced via blade coating. The width and shape of the pole figure is a quantitative metric of film texture, which can be directly compared between scans of similar materials or for in situ crystallization studies (Figure 33).<sup>[39,204]</sup> Further, the use of self-organizing maps (SOM) in MATLAB can be used to track individual GIWAXS features to monitor the grain rotation, texture, and lattice deformation of the film’s morphological evolution.<sup>[10,218]</sup> 

There are several aspects to consider in the quantitative GIWAXS analysis of textured 2D perovskite thin films due to strong peak overlap for various _n_ -phases, so caution is recommended as well as consulting the literature before reporting the synthesis of an oriented pure high- _n_ 2D perovskite phase. This reveals the difficulty of producing phase pure samples from solution processing and has prompted an extensive discussion regarding the origin of and the impact of impurities and phase distributions on electronic transport phenomena.<sup>[219]</sup> Complementary experiments of both GIWAXS and transmission thin film X-ray scattering (i.e., using Myler substrates) may be used to resolve these issues.<sup>[220]</sup> 

Understanding the processing-structure-performance correlations requires a GIWAXS-focused multimodal characteriza- 

### **www.advenergymat.de** 

tion approach, correlating crystallographic orientation and performance to deduce the associated processing-controlled tunability. X-ray and electron diffraction can be combined in a straightforward combined structural characterization methodology. TEM/SAED allow for atom-scale confirmation of _n_ - phase, but all orientational information is lost in thin film preparation.<sup>[208,221,222]</sup> Further complementary characterization techniques often seen in the literature include photoluminescence (PL), nuclear magnetic resonance (NMR), or molecular dynamics simulations.<sup>[116,206,223,224]</sup> 

## **4. In Situ GIWAXS Methods** 

With the development of sensitive and fast 2D X-ray detectors, and bright synchrotron X-ray sources, the use of time-resolved GIWAXS to study metal halide perovskite thin films and devices has become valuable for understanding film formation and a kinetic material properties. The high photon count rate enables the design of experiments that can probe at relatively short time scales ( _<_ 0.1 s).<sup>[1]</sup> With the ability to develop customized GIWAXS setups, a broad range of in situ techniques can be performed at modern synchrotron facilities. For example, an environmental chamber for controlling atmosphere and installing a spin- or blade-coater can be used to simulate glovebox conditions and explore film synthesis procedures developed in the laboratory. By natural extension, GIWAXS is inherently compatible with operando studies based upon the International Summit on Organic Photovoltaic Stability (ISOS) protocols.<sup>[225]</sup> As such, similar external controls can be used to explore operando conditions of fully formed films and devices. 

Recording frames sequentially over time from the same sample will unavoidably result in elevated radiation exposure/beam dose, and under these conditions potential beam damage must be monitored (and ideally reported).<sup>[226]</sup> Metal halide perovskites are notoriously sensitive to external stimuli, for example, (photo)physical changes are typically tied to parameters like temperature, light illumination, electric fields, or atmosphere. In this section, we examine the current experimental trends found in the literature for the study perovskite thin films and devices using in situ GIWAXS techniques. 

### **4.1. Synchrotron Beam Damage** 

Exposure to ionizing radiation has the potential to alter the physical and chemical character of not only metal halide perovskites, but functional materials in general. Thus, assessment and understanding of the effects induced by ionizing radiation are vital within structural and in situ, or operando, studies where scattering features are tracked over multiple GIWAXS images. 

High photon flux from synchrotron X-ray sources can increase the likelihood of beam-induced structural degradation, usually manifesting as a reduction in the Bragg peak intensity or even ablation of perovskite films over prolonged exposure in air ( **Figure 34** ).<sup>[226,227]</sup> Degradation mechanisms under ionizing radiation may differ somewhat for inorganic CsPbX3 and the hybrid organic-inorganic compositions (FA,MA)PbI3. In the former, loss of halide ions and an accumulation of vacancy defects leads to the formation of metallic Pb<sup>0</sup> and CsX degradation 

**2300760 (34 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.advenergymat.de** 



**Figure 34.** Evaluation of synchrotron beam damage (10.995 keV) of MAPbI3 films at room temperature. A) Images of the films after ≈24 h of X-ray exposure in different atmospheres. B) Powder XRD patterns before and after 1 h of exposure to X-rays in an ambient air atmosphere with the difference plotted below, showing significant changes due to beam damage. Reproduced with permission.<sup>[226]</sup> Copyright 2017, American Chemical Society. 

products. Hybrid systems are more susceptible to beam damage, generally attributed to radiolysis of the organic A-site cation.<sup>[228]</sup> Beam-induced effects in metal halide perovskites may accelerate environmental degradation to which these materials are already prone.<sup>[229]</sup> Additional considerations should be made for operando X-ray studies, as there may be a reduction of photocurrent in PV devices due to beam-enhanced recombination.<sup>[230]</sup> 

Mitigation of X-ray beam damage may include reducing environmental factors, especially humidity, by completing measurements in inert atmospheres. The X-ray beam energy can be judiciously selected to mitigate absorption-driven ionization. Increasing X-ray energy generally reduces absorption, but the experimenter may take care to select an energy below any elemental absorption edges (Section 2.1). Reducing X-ray fluence is generally favorable to mitigate damage, but for long exposures, one may choose to stay below a certain flux threshold to slow the rate of degradation, at the loss of signal-to-noise. Moreover, due to changes in the projected beam footprint at different incident angles (Section 2.4), the photon density of the beam will increase as the grazing incidence angle increases and the sample surface rotates to face the beam. Alternatively, new regions of material can be continuously sampled during long exposures or in situ experiments, via lateral motion of the film.<sup>[29]</sup> 

Even with efforts to mitigate beam damage, the experimental design should incorporate strategies to quantitatively assess (and later report) accumulating degradation in the sample.<sup>[231]</sup> Integrating frequent scans over a long continuous exposure can identify changes in the material over time, and possibly identify an exposure time before the onset of significant damage. In situ or operando studies may include an end-point scan with identical parameters to the first to determine what changes were induced over the course of the experiment. Deliberately assessing and reporting beam damage in terms of flux thresholds, fluence limits, and X-ray energy selection are important inclusions to support experimental results. Moreover, this practice informs experimental design and the completion of quality GIWAXS studies across 

metal halide perovskites and broad functional materials fields in general. 

### **4.2. In Situ Structural Dynamics and Phase Transitions in Thin Films** 

Beyond interpreting steady-state structural features in a single GIWAXS frame, tracking a statistically relevant number of XRD spots can elucidate dynamic structure in thin films under different processing conditions, for example, monitoring the realtime structural evolution of perovskite precursors and crystallites by tracking the evolution of diffraction peaks in reciprocal space.<sup>[218]</sup> By examining the collective behavior of discrete spots on the detector (due to individual crystallites; **Figure 35** A), Lilliu et al.<sup>[218]</sup> used in situ GIWAXS to simultaneously probe large populations of grains and capture their rotation within a polycrystalline MAPbI3 thin film, with the purpose of investigating texture evolution during thermal annealing. Starting from perovskite precursor which turns into a perovskite crystal over time, two signals (i.e., precursor vs perovskite) are tracked through the annealing process (Figure 35B). Here the authors implemented a spot tracking routine to follow several of the moving diffraction spots and extracted a series of “tracks” that quantify the evolution of the scattering vector of each spot with time. Considering the development via two example precursor and perovskite tracks (Figure 35C), the precursor diffraction indicates a monotonic negative azimuthal displacement with a continuous counter-clockwise rotation within the initial annealing stage of 7 min, while the perovskite crystallite spot undergoes a positive azimuthal move accompanied with a clockwise rotation in the annealing period. By tracking the motions of over 600 GIWAXS diffraction spots, one can summarize the rotation and azimuthal behaviors of perovskite grains during pre-crystallization stage, as presented in **Figure 36** D. Notably, these apparent rotations of intermediate perovskite grains under thermal stress can be mainly 

**2300760 (35 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



### **www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 35.** A) Illustration of X-ray scattering from a single grain as it rotates in time, moving its Bragg peak across a large-area detector. B) Real-time GIWAXS observations of precursor (beginning of annealing) and perovskite crystallite rotation (end of annealing). The red dots highlight the local peak population used in the study. C) Selected areas of the GIWAXS detector images tracked over a temporal sequence of precursor and perovskite spot movement/rotations. The color scale of these images respectively represents the minimum to maximum recorded intensity as spectral blue to red and through black, and track the rotation of the perovskite (210) peak. D) Analysis over a population of GIWAXS diffraction spots corresponding to the precursor- (black) and perovskite-related (red) peaks, extracted as a function of time from an in situ annealing data set. TOP: Azimuth displacement Δ _𝜒_ versus time, showing changes in the orientations of the scattering domains. Bottom: Changes in the scattering vectors of each spot over time, Δ _q_ versus time. Each line or trace shows a single spot that was tracked. Notably, most of the changes are observed early on during annealing are linked to the evaporation of the solvent and sublimation of byproducts. Reproduced with permission.<sup>[216]</sup> Copyright 2016, Royal Society of Chemistry. 

ascribed to the evaporation of residual solvents and sublimation of Cl-containing byproducts. 

As was showcased in Section 3.2, the subtleties of phase transitions and symmetry changes in the perovskite crystal are sometimes tricky to identify. Furthermore, examining the material as a device-ready thin film can also help elucidate the role of the substrate interface during thermal processing and polymorphic behavior. To study the thermal-phase relations of inorganic CsPbI2.7Br0.3 thin films, Steele et al.<sup>[25]</sup> tracked the structure of the film during a series of thermal cycles using _t–T_ GIWAXS profiling, with the as-grown material initially starting from a yellow non-perovskite state (Figure 36A). During the first high- 

temperature ramp the film transitions to the perovskite phase, before successive cooling and heating ramps cycle through the different _𝛼_ -, _𝛽_ -, and _𝛾_ -phase symmetries. Agreeable overlapping of the crystal unit cell parameters (Figure 36B) demonstrates negligible hysteresis during this process, determined using the Le Bail refinement method. 

To limit the potential role of sample misalignment in **Figure 37** A, due to thermal expansion, a relatively high incident angle ( _𝛼_ i = 1°) was used. The role of substrate clamping is revealed within these GIWAXS data, from formation of interfacial strain at low temperatures due to a thermal expansion coefficient mismatch between the perovskite film (≈50 × 10<sup>−6</sup> K<sup>−1</sup> ) and 

**2300760 (36 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.advenergymat.de** 



**Figure 36.** Phase kinetics of thermally cycled strained perovskite thin film. A) GIWAXS time-temperature ( _t–T_ ) profile of inorganic CsPbI2.7Br0.3 thin film as is undergoes a high-temperature non-perovskite-to-perovskite phase transition (1), followed by thermal cycling, where it remains thereafter in a perovskite phase. The Δ _d_ parameter which is plotted on the top tracks the spontaneous orthorhombic distortion: Δ _d_ = 1 − _d_ (110)/ _d_ (001). B) Normalized<sup>[23]</sup> lattice parameters as a function of temperature. Phase changes are numerically identified in (B) and align with those depicted in (A). Reproduced with permission.<sup>[25]</sup> Copyright 2019, American Association for the Advancement of Science (AAAS). 

the underlying glass substrate (≈5 × 10<sup>−6</sup> K<sup>−1</sup> ). After the initial yellow-to-black transition, a stable black thin film with a strained interface is realized thereafter. To elucidate the strain-induced shift in the phase energetics, the authors used thermodynamic ab initio calculations of strained crystal formation to confirm the stabilizing effect of substrate clamping. 

With the presence of quantum wells constructed by insulating bulky organic cations, quasi-2D perovskites show isotropic out-of-plane and in-plane charge carrier mobility under excitation. With fast crystallization kinetics during solution processing, quasi-2D perovskite thin films normally exhibit a broad n- value distribution from high- _n_ to low- _n_ fragments, as well as random orientations. In the perovskite research community, GIWAXS has been recognized as an indispensable tool to identify the fragment orientation and n-value distribution of quasi-2D perovskites, which favors the development of hot-casting deposi- 

tion protocolquasi-2D perovskite materials oriented out-of-plane with encouraging efficiencies over 20%.<sup>[67,232]</sup> 

As revealed by Zhang et al.,<sup>[232]</sup> a preheated substrate triggers the fast evaporation of DMF-DMSO solvents for the direct phase transition from precursor to the RP phase quasi-2D perovskite crystals without the emergence of any intermediate solvate phase. Unfortunately, these authors did not implement the required “missing wedge” correction (Figure 37A). Importantly, the host-casting deposition protocol induces a preferred perpendicular crystal orientation to the substrate with eliminated lown fragments, which enables efficient out-of-plane charge transport in the formed quasi-2D perovskite thin films, as indicated by the 2D GIWAXS patterns from room-temperature and preheated substrates (Figure 37A). Based on different lattice distances, GIWAXS can easily distinguish quasi-2D perovskite films with different n values, as in the case of in situ grown 2D perovskite capping layer on top of 3D perovskite film using bulky organic cation post-treatment. As shown in the contour map and in situ GIWAXS patterns of a 3D perovskite layer treated with a bulky organic halide solution (Figure 37B,C), the formed 2D perovskite capping layer experienced a progressive reduction of dimensionality from _n_ = 3 to 1 in a short period, which suggests the reconstruction of the 2D lattice is derived from the spontaneous displacement of cations.<sup>[233]</sup> Currently, the most durable perovskite solar cells with over one-year operational stability are based on quasi-2D perovskites, but their efficiencies are still far lower than their 3D counterparts.<sup>[234,235]</sup> The key issue in this growing area is how to improve the charge carrier mobility of quasi-2D perovskite thin films with bulky cation contents. In situ GIWAXS can help screen desirable quasi-2D perovskites with a preferred perpendicular crystal orientation on the substrate and abundant high-n phase domains for efficient out-of-plane charge transport and reduced quantum wells, respectively. Further, in situ GIWAXS can serve as a diagnostic tool to mitigate the internal energy band disorder within quasi-2D perovskite layers by monitoring the unfavorable cation migration and phase redistribution. 

### **4.3. Thin Film Crystallization and Growth Kinetics** 

Solvated perovskite precursors can form many secondary/intermediate phases before crystallizing into a perovskite structure: hexagonal 2H, 4H, 6H, PbI2, or even intermediate ligand phases (Figure 29). Furthermore, due to the tendency for octahedral tilting, the perovskite can crystalize into several unique related, phases: cubic ( _𝛼_ ), tetragonal ( _𝛽_ ), orthorhombic ( _𝛾_ ), orthorhombic ( _𝛿_ ), or even 2D interfacial phase, like the RP phase, each with varying physical and optoelectronic properties. Through a well-supported model, the existence of these different structural phases will give rise tounique Bragg signatures and are influenced by several factors, such as the synthesis recipe, environmental conditions, the solvent/antisolvent used, as well as the thermal annealing conditions.<sup>[9]</sup> 

Perovskite recipes can be tuned in many ways and crystallization pathways depend on the synthesis. In fact, even among simple related ABX3 spin-cast films, MAPbI3 possesses significantly different crystallization behavior to FAPbI3, with MAPbI3 exhibiting intermediate non-perovskite phases, and the latter forming a photoinactive _𝛿_ -FAPbI3 phase, prior to thermal 

**2300760 (37 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.advenergymat.de** 



**Figure 37.** A) GIWAXS images recorded ex situ from 2D perovskite films annealed at different temperatures. Note that the missing wedge has not been accounted for in these images. Reproduced with permission.<sup>[232]</sup> Copyright 2018, John Wiley and Sons. B) Contour map and their corresponding C) in situ GIWAXS patterns for a film of (MAPbBr3)0.05(FAPbI3)0.95 treated with a solution of 1 mm BABr in 3:97 IPA:CF. Patterns were collected with an incident angle of 0.1˚. Reproduced with permission.<sup>[233]</sup> Copyright 2021, Springer Nature. 

annealing.<sup>[236]</sup> Additionally, varied halide selection leads to further diversity. Broadly speaking, bromide alloying may result in potential phase segregation and the growth of intermediate hexagonal polytypes, while chloride alloying introduces intermediate phases, such as MA2Pb2Cl2⋅MAI for MAPbI3− _x_ Cl _x_ perovskites, which promote ordered crystal grain formation.<sup>[237]</sup> 

Essentially all of the desirable traits in a device-ready film— from crystallite size and coverage, to crystal chemistry, quality, and trap density—are dependent on the solution processing and the crystallization kinetic process. Thus, through careful experimental design it is possible to isolate the different factors that influence crystal growth in the film, and study the crystallization dynamics ( **Figure 38** ). Together with the use of modern 2D X-ray detectors, the high phonon flux provided at synchrotrons facilitates the recording of GIWAXS images in the order of 0.1 to 1 s per frame,<sup>[238]</sup> which is relatively short compared to the time scale of typical solution-based crystallization processes that unfold on the order of 10–100 s.<sup>[9]</sup> Notably, however, some growth procedures can involve processes that are _<<_ 0.1 s (i.e., anti-solvent methods), and relatively faster X-ray imaging<sup>[239]</sup> is required. Within this context, there has been a recent flurry of different in situ GIWAXS approaches deployed to understand the crystallization kinetics and determine key intermediate stages of growth, toward the fabrication of high-performance optoelectronic devices.<sup>[9]</sup> As such, it is impossible to cover all of the different approaches taken and we highlight just a few examples below. 

For relatively complex mixed cation/halide perovskite solar cells recipes, Qin et al. utilized in situ GIWAXS to reveal that cesium quantities _>_ 10% in the mixed 



**Figure 38.** Illustration of a typical setup used to perform in situ GIWAXS during perovskite crystallization. The sample is sealed in a housing with a two X-ray transparent windows for the beam to enter and scatter out of, typically made of a polymeric material like Kapton. Gas inlet/outlets allow the internal atmosphere to be precisely controlled. Films can either be deposited (i.e., Spin Coating) or thermally annealed remotely. While remote post deposition treatments (i.e., antisolvents or gas quenching) can be applied to manipulate crystallization behavior. 

Csx(FA0.83MA0.17)1− _x_ Pb(I0.83Br0.17)3 perovskite system can reduce the crystallization pathway from a three stage process, that produces unwanted hexagonal 2H, 4H, 6H, and MAI-PbI2DMSO phases, to only the first two stages—directly forming perovskite phases.<sup>[240]</sup> GIWAXS frames recorded during spin coating of the precursor and antisolvent application, under a N2 atmosphere, form the kinetic data shown in **Figure 39** A. To preserve good alignment between the incident beam and 

**2300760 (38 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.advenergymat.de** 



**Figure 39.** A) Temporal GIWAXS waterfall plot showing that the addition of 10% Cs<sup>+</sup> into mixed cation Csx(FA0.83MA0.17)1− _x_ Pb(I0.83Br0.17)3, shortens the crystallization process and suppresses non-perovskite phases. Reproduced with permission.<sup>[240]</sup> Copyright 2019, John Wiley and Sons. B) Temporal GIWAXS waterfall plot combined with the photo-conversion efficiency (PCE) data and SEM images, revealing how antisolvent application during the GIWAXS revealed Sol-gel stage maximizes film quality and device performance. Reproduced with permission.<sup>[241]</sup> Copyright 2019, John Wiley and Sons. Temporal plots of Characteristic Peak intensity for intermediate and perovskite phases exhibited in MAPbI(3− _x_ )Cl _x_ film formation at C) 100 °C and D) 140 °C. Immediate application of _T >_ 140 °C directly and rapidly forms perovskite, avoiding the typical three stage process seen at 100 °C. Dashed lines show degradation to an amorphous phase. Reproduced with permission.<sup>[242]</sup> Copyright 2016, American Chemical Society. 

the sample surface during spin coating, and as the material subsequently transitions from a liquid into a solid, a high incidence angle of 2° is used. This also acts to increase the scattering resolution (Section 2.4.7.) and stabilize the scattering geometry while the sample physically rotates, as unbalanced spinning can introduce small vibrations and dramatically alter the grazing conditions at smaller _𝛼_ i, that is, nearer to the critical angle. The order and relative intensity of the competing phases that emerge are visible in the time-dependent intensity maps in Figure 39A, allowing for clear comparisons between Cs<sup>+</sup> content and the classification of different crystallization stages. Qin et al. subsequently labeled the critical second stage as the “annealing window” during which the perovskite film must be annealed to prevent intermediate phases and ensure a high-quality morphology. 

Wang et al. further demonstrated the importance of antisolvent timing for spin coated films of both MAPbI3, FAPbI3, and many complex mixed cation/halide perovskites.<sup>[241]</sup> By spin coating different perovskite compositions in situ without antisolvent application, GIWAXS revealed the temporal details of the sol–gel window and the perovskite crystallization pathway. For added insight, their temporal results were subsequently correlated with solar cell performance data and SEM characterization (Figure 39B) in order to optimize the device processing. Such complementary data offered a clear picture of how the antisolvent timing effects the crystallization and, in the end, antisolvent dripping within the sol-gel window, that is, before the emergence 

of competing non-perovskite phases, was found crucial to achieve high quality films and high device efficiencies. 

Beyond deposition, it is important to decipher the thermal annealing process used to induce crystallization. Chang et al. studied the effect of substrate temperature upon MAPbI3- _x_ Cl _x_ perovskite by preheating silicon substrates on a temperaturecontrolled stage before remotely depositing perovskite precursor solution and collecting in situ GIWAXS data.<sup>[242]</sup> This setup thus forgoes an in situ temperature ramp, helping to better control the kinetics and understand the observed crystallization behavior, that is, kinetic equations often assume the temperature is a fixed parameter.<sup>[236]</sup> They report that for the drop cast films, differing substrate temperatures induce distinct changes in crystallization behavior, that is, a three-stage solution-intermediateperovskite process at ≤100 °C (Figure 39C), while temperatures ≥140 °C produce a direct perovskite formation with fast kinetics (Figure 39D). Indeed, annealing optimization is particularly important for FAPbI3 and CsPbI3 perovskites, which must be converted from the unwanted _𝛿_ -phase to the photoactive _𝛼_ -phase at elevated temperatures.<sup>[236]</sup> In addition to the annealing temperature, atmospheric changes, such as solvent vapor annealing—a process known to reduce grain boundaries and improve film quality—have a clear impact on crystallization kinetics.<sup>[243]</sup> Meng et al. compared the effect of DMF, DMSO, and 1:1 DMF:DMSO on MAPbI3 films through an temperature cycle, RT-100 °C-RT, and described unique crystallization steps for each environment.<sup>[244]</sup> The DMF sample presents perovskite 

**2300760 (39 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



**Figure 40.** A typical in situ GIWAXS setup for perovskite degradation studies. Perovskite films or full device stacks are sealed in a housing with a two X-ray transparent windows for the beam to enter and scatter out of, typically made of a polymeric material like Kapton plastic. Gas inlet/outlets allow the internal atmosphere and humidity to be precisely controlled. Samples can be illuminated (through a quartz optical window) and heated (via the samples stage) to simulate real world conditions. Electrical test leads allow real-time _J–V_ data to be collected from in operando devices during X-ray irradiation to complement the GIWAXS data. 

scattering at only 70 °C, while the other samples present no such value until 100 °C is maintained, demonstrating that DMSO vapor restrains perovskite formation. This slower growth drastically increases crystal size, and all samples present greater grain size and orientation than N2 annealed samples. 

### **4.4. Degradation and Device Failure Under Operando Conditions** 

It is well understood that perovskite films, and specifically solar cell devices, are vulnerable to environmentally-induced degradation under typical ambient or “rooftop” conditions.<sup>[245,246]</sup> Indeed, unavoidable aspects like humidity, light, and heat all induce a form of inevitable device decay.<sup>[225,247]</sup> While an abundance of work has focused on improving the operational stability of perovskite solar cells, the details of device failure, and specifically the fundamental degradation mechanisms, are often far less surveyed. Isolating, and thus mitigating, these decay pathways in perovskite thin films is important if perovskite solar cells are to commercially compete with well-established solar harvesting materials.<sup>[248]</sup> In situ GIWAXS is well suited for this task, as it is flexible enough to accommodate common device failure scenarios. Using an instrument equipped with controllable atmosphere, temperature, illumination, and device metric tracker, one can investigate film structural dynamics under operando conditions ( **Figure 40** ). Further, such studies are not merely limited to exposed films, as fully formed device stacks can be studied via a simple incident angle adjustment to allow X-ray beams to penetrate the perovskite. This reveals the crystalline evolution both within the perovskite film, and at its interface with other device layers (i.e., charge transport layers or interlayers) during device operation. 

As a solar module may exceed 65 °C during operation, it is necessary that perovskite materials be thermally resilient. Unfortunately, MAPbI3 has a well-documented thermal degradation 

### **www.advenergymat.de** 

behavior, reported from both in situ temperature-dependent GIWAXS experiments,<sup>[249]</sup> and ex situ post-mortem studies, and readily decomposes into volatile CH3I and NH3 and PbI2 around 80–100 °C.<sup>[250,251]</sup> Therefore, FAPbI3 and mixed cation systems have risen in popularity in recent years due to improved stability. FAPbI3 is noted to degrade into amorphous structures only above 150 °C, fully decomposing to PbI2 _>_ 260 °C.<sup>[252]</sup> 

Humidity is detrimental to the film stability by causing both phase transitions<sup>[143]</sup> and perovskite decomposition. GIWAXS experiments under an ambient atmosphere, or controlled humid environments, can track phase transitions and reveal how these interactions kinetically evolve. For organic-inorganic systems, the organic cation is volatile when exposed moisture, resulting in hydration processes.<sup>[253]</sup> For example, in MAPbI3, humid air hydrates the perovskite reversibly forming a 2D MAPbI3·H2O phase, while condensation upon the film surface causes irreversible decomposition to isolated octahedra in (MA)4PbI6·2H2O and PbI2 ( **Figure 41** A).<sup>[254,255]</sup> On the other hand, the application of all-inorganic systems, like CsPbI3, does not guarantee moisture tolerance. Here moisture acts as a catalyst for the black-to-yellow phase transition (Figure 41B).<sup>[25,256,257]</sup> In the mixed cation/halide Cs _x_ FA1− _x_ Pb(Br _y_ I1− _y_ )3 a combination of effects are observed under humid conditions, with differing ratios of Cs:FA and Br:I exhibiting either hydrated non-perovskite (Cs _x_ FA1− _x_ )4Pb(Br _y_ I1− _y_ )6·2H2O, hexagonal 4H, 6H phases or _𝛿_ - CsPb(I _x_ Br1− _x_ )3 phases.<sup>[258]</sup> Therefore, by considering the different humidity induced degradation pathways that occur as a result of cation and halide selection, these GIWAXS studies may assist in tuning perovskite recipes to further inhibit moisture degradation. 

The prior studies focus on exposed perovskite films which do not capture the roles of interfaces<sup>[260]</sup> found in a complete device stack. Fransishyn et al. reported the failure mechanism of operando devices based on MAPbI3 perovskite under humid conditions by tracking photovoltaic parameters and azimuthally integrated GIWAXS patterns over time.<sup>[259]</sup> For this, the airtight chamber was equipped with electrical test leads and quartz window to allow real-time _J–V_ tests during X-ray irradiation, while an X-ray flight tube and a Kapton window enable simultaneous acquisition of GIWAXS data.<sup>[259]</sup> Using a testing setup equipped with a controllable atmosphere, one can investigate the film structural dynamics of perovskite thin films under water vapor diffusion, thermal stress, continuous light illumination, as well as beam damage by ruling out the other conditions (Figure 41C,D). For instance, beam damage can be evaluated by conducting GIWAXS measurement when purging the chamber with dry nitrogen flow under dark conditions, and targeted control parameter (i.e., light or gases) can be subsequently introduced and, importantly, parsed. Interestingly, unlike other studies which examined MAPbI3 films exposed to different stimuli, Fransishyn et al.<sup>[259]</sup> report only a modest loss of the perovskite peak scattering intensity, and no emergence of hydrate phases within the time frame required for device failure (Figure 41C). This lack o hydrate formation only occurs under a hot (40 °C) halogen light source, with LED illumination/dark conditions yielding the expected hydrate phases ( _q_ = 0.61 Å<sup>−1</sup> ) and decomposed PbI2 ( _q_ = 0.94 Å<sup>−1</sup> ), demonstrating both the thermal reversibility of hydrate phases, and more importantly the care with which operando GIWAXS studies must be constructed to 

**2300760 (40 of 50)** 

_Adv. Energy Mater._ **2023** , _13_ , 2300760 

© 2023 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

