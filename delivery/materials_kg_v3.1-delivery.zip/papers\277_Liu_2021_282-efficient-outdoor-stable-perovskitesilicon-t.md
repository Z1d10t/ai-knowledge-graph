# 28.2%-efficient, outdoor-stable perovskite/silicon tandem solar cell

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Joule |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 174 |
| 作者 | Jiang Liu, E. Aydin, J. Yin, Michele De Bastiani, Furkan H. Isikgor, Atteq ur Rehman, E. Yengel, Esma Ugur et al. |
| DOI | 10.1016/j.joule.2021.11.003 |
| 源文件 | 061_Liu_2021_282-efficient-outdoor-stable-perovskitesilicon-t.pdf |

---
**ll** 

Article 

# 28.2%-efficient, outdoor-stable perovskite/ silicon tandem solar cell 



<!-- Start of picture text -->
Outdoor stability tests<br>Stabilized PCE: 28.6%<br>30 20<br>25 15<br>20 10<br>15 5<br>10 0<br>10 20 30 40 50 60 0 5 10 35 40<br>Time (s) Time (day)<br>2)<br>m<br>c/<br>W<br>( ttmpo reopuuw ( )WPmm<br>Sdzilibtea<br><!-- End of picture text -->

Jiang Liu, Erkan Aydin, Jun Yin, ..., Omar F. Mohammed, Fre´ de´ ric Laquai, Stefaan De Wolf 

jiang.liu@kaust.edu.sa (J.L.) stefaan.dewolf@kaust.edu.sa (S.D.W.) 

Highlights A strategy to suppress halide segregation and reduce nonradiative recombination loss 

Certified 28.2% efficient perovskite/silicon tandem solar cells on a textured structure 

Significant stability improvement upon carbazole treatment 

The addition of carbazole molecules in bulk perovskite layers effectively suppressed the phase segregation. Monolithic perovskite/silicon solar cells were fabricated from a textured silicon heterojunction solar cell. A stabilized PCE of 28.6% (independently certified at 28.2%) was achieved over �1 cm<sup>2</sup> and 27.1% over 3.8 cm<sup>2</sup> . The long-term stability tests show the carbazole-treated tandem devices demonstrated significantly improved stability. 

Liu et al., Joule 5, 3169–3186 December 15, 2021 ª 2021 Elsevier Inc. https://doi.org/10.1016/j.joule.2021.11.003 



**ll** 

#### Article 

## 28.2%-efficient, outdoor-stable perovskite/silicon tandem solar cell 

Jiang Liu,<sup>1,</sup> * Erkan Aydin,<sup>1</sup> Jun Yin,<sup>2</sup> Michele De Bastiani,<sup>1</sup> Furkan H. Isikgor,<sup>1</sup> Atteq Ur Rehman,<sup>1</sup> Emre Yengel,<sup>1</sup> Esma Ugur,<sup>1</sup> George T. Harrison,<sup>1</sup> Mingcong Wang,<sup>1</sup> Yajun Gao,<sup>1</sup> Jafar Iqbal Khan,<sup>1</sup> Maxime Babics,<sup>1</sup> Thomas G. Allen,<sup>1</sup> Anand S. Subbiah,<sup>1</sup> Kaichen Zhu,<sup>3</sup> Xiaopeng Zheng,<sup>2</sup> Wenbo Yan,<sup>1</sup> Fuzong Xu,<sup>1</sup> Michael F. Salvador,<sup>1</sup> Osman M. Bakr,<sup>2</sup> Thomas D. Anthopoulos,<sup>1</sup> Mario Lanza,<sup>3</sup> Omar F. Mohammed,<sup>2</sup> Fre´ de´ ric Laquai,<sup>1</sup> and Stefaan De Wolf<sup>1,4,</sup> * 

##### SUMMARY 

Stacking perovskite solar cells onto crystalline silicon bottom cells in a monolithic tandem configuration enables power-conversion efficiencies (PCEs) well above those of their single-junction counterparts. However, state-of-the-art wide-band-gap perovskite films suffer from phase stability issues. Here, we show how carbazole as an additive to the perovskite precursor solution can not only reduce nonradiative recombination losses but, perhaps more importantly, also can suppress phase segregation under exposure to moisture and light illumination. This enables a stabilized PCE of 28.6% (independently certified at 28.2%) for a monolithic perovskite/silicon tandem solar cell over �1 cm<sup>2</sup> and 27.1% over 3.8 cm<sup>2</sup> , built from a textured silicon heterojunction solar cell. The modified tandem devices retain �93% of their performance over 43 days in a hot and humid outdoor environment of almost 100% relative humidity over 250 h under continuous 1-sun illumination and about 87% during a 85/85 damp-heat test for 500 h, demonstrating the improved phase stability. 

##### INTRODUCTION 

Over the past decade, metal-halide perovskites have triggered immense research activities in the photovoltaics (PVs) field.<sup>1–3</sup> Their band-gap tunability, processing flexibility, and excellent optoelectronic properties make them an ideal subcell candidate for tandem applications, specifically when paired with mainstream crystalline silicon (c-Si) PVs.<sup>4–6</sup> Owing to their high absorption coefficient and low voltage loss, perovskite top cells can reduce the thermalization losses in the blue portion of the solar spectrum—relative to a narrower band-gap single-junction c-Si cell— and enable power-conversion efficiencies (PCEs) of tandem beyond the single-junction limits.<sup>6,7</sup> High-efficiency perovskite/silicon tandem devices can be realized by tuning the perovskite top-cell band gap (Eg) to a value of 1.65–1.70 eV, where the ideal value may vary according to the field operation temperature and possible parasitic optical losses in the device layer stack.<sup>8–17</sup> Utilizing such perovskites as top-cell absorbers, paired with silicon heterojunction (SHJ) bottom cells, perovskite/silicon tandem solar cells have been realized with PCEs of up to 29.5%,<sup>18</sup> which is already well beyond the best reported single-junction SHJ bottom cells.<sup>19,20</sup> 

##### Context & scale 

In the past decade, the efficiency of perovskite solar cells has rapidly improved. A promising strategy to further improve efficiency is to construct tandem devices, especially when paired with Si bottom cells. The phase instability of the wide-band-gap perovskite top cell is limiting the tandem performance and also its application prospects. Thus, it is highly desirable to develop strategies to suppress the halide segregation in the perovskite layer without compromising device performance. Here, we incorporated carbazole, a nitrogen-containing heterocyclic molecule, as an additive to the perovskite layer. The carbazole treatment suppresses halide segregation, reduces nonradiative recombination loss, and lowers defect density. With an optimized 1.68 eV perovskite top cell and double-sided textured Si heterojunction bottom cell, we obtained certified 28.2% efficiency over �1 cm<sup>2</sup> . A series of stability tests prove that carbazole improves the long-term stability of tandem devices. 

To achieve high efficiency in such devices with long-term operational stability, implementing phase-stable wide-band-gap perovskites is imperative.<sup>21</sup> However, to date, 



Joule 5, 3169–3186, December 15, 2021 ª 2021 Elsevier Inc. 3169 

**ll** 

Article 

wide-band-gap metal-halide perovskites (i.e., for which Eg >1.65 eV) have been associated with considerable device phase-stability issues.<sup>22,23</sup> Many efforts, such as via compositional engineering,<sup>24–26</sup> crystallinity control,<sup>27–29</sup> and defect passivation,<sup>30–</sup> 32 have been devoted in the past few years to not only suppress the phase-segregation issue of wide-band-gap perovskites, but also reduce nonradiative recombination loss. For instance, increasing the Cs and reducing the Br concentrations or adopting triple halides in the perovskite for a target band gap have been demonstrated as effective strategies to stabilize the perovskite layer under illumination.<sup>25,26</sup> However, a high Cs concentration in the perovskite precursor solution usually results in a poor film morphology and deteriorated electronic properties, possibly due to induced stresses in the resulting films.<sup>33,34</sup> Several earlier reports show that improved crystallinity and reduced trap densities render perovskite films to be more stable against halide segregation under illumination.<sup>27–29</sup> In addition, grain boundaries (GBs) accommodate a significant amount of charged defects due to the ionic nature of the perovskite film.<sup>35–37</sup> The passivation of trap states via some specific additives inside the precursor, such as theophylline,<sup>38</sup> imidazolium,<sup>39</sup> piperidinium,<sup>40</sup> and some amine salts,<sup>31,32</sup> has been reported as an effective strategy to circumvent this issue.<sup>30,31</sup> In these approaches, molecular passivation deactivates some defects via coordinate binding and hence reduces nonradiative recombination and improves photostability. Inspired by this, we incorporated carbazole as an additive into the perovskite precursor and found that this additive can passivate deep charge traps, enhance performance, and suppress phase segregation of wide-band-gap perovskites. We find that this organic nitrogen-containing heterocyclic molecule interacts with halide anions through hydrogen bonds, immobilizes halide species, and passivates trap states. Specifically, this happens at the GBs because the carbazole molecules, with a relatively large molecular radius, cannot be incorporated into the perovskite lattice. Combining this enhancement with minimized optical losses, we demonstrate a record-certified PCE of 28.2% for double-sided, textured perovskite/silicon tandems among published results. Equally important, passivating the defects at GBs inhibits ion migration within the perovskite film and improves the long-term stability of the tandem device. The carbazole-treated tandem device retains over 93% of its initial performance for more than 40 days when tested outdoors, demonstrating the improved phase stability of the wide-band-gap perovskites. 

##### RESULTS AND DISCUSSION 

###### Improved phase stability with carbazole additive 

We performed systematic photoluminescence (PL) measurements to understand the role of the carbazole additive on the halide segregation in our 1.68-eV perovskites with a composition of Cs0.05FA0.8MA0.15Pb(I0.75Br0.25)3. We confirmed the band gap of our perovskite layer from a Tauc plot and the PL peak position (Figure S1). To exclude the influence of environmental factors such as humidity and oxygen,<sup>41</sup> we encapsulated the samples in a nitrogen glove box. Under 1-sun equivalent illumination, we did not observe a significant change in the PL peak position within 15 min for both pristine and carbazole-treated samples (Figure S2). However, this does not guarantee that these perovskite films will remain stable under long-term operation. To accelerate the degradation test, we increased the light intensity to 10 suns (Figures 1A and 1B). In that case, the pristine film shows an obvious extra peak in its lower-energy region, which gradually increases with irradiation time, indicating the formation of light-induced I-rich trap states in the pristine film.<sup>25,42</sup> Notably, the carbazole-treated sample is much less affected, suggesting improved phase stability. Halide segregation of wide-ban-gap perovskite films, activated by strain, commonly occurs at GBs.<sup>23</sup> Surface scanning electron microscopy (SEM) and X-ray diffraction (XRD) analyses are fully detailed in the supplemental information (Figures 

> 1KAUST Solar Center (KSC), Division of Physical Sciences and Engineering (PSE), King Abdullah University of Science and Technology (KAUST), Thuwal 23955-6900, Kingdom of Saudi Arabia 

> 2Advanced Membranes and Porous Materials Center (AMPMC) and KAUST Catalysis Center (KCC), Division of Physical Sciences and Engineering (PSE), King Abdullah University of Science and Technology (KAUST), Thuwal 23955-6900, Kingdom of Saudi Arabia 

3Division of Physical Sciences and Engineering (PSE), King Abdullah University of Science and Technology (KAUST), Thuwal 23955-6900, Kingdom of Saudi Arabia 4Lead contact 

> *Correspondence: jiang.liu@kaust.edu.sa (J.L.), stefaan.dewolf@kaust.edu.sa (S.D.W.) https://doi.org/10.1016/j.joule.2021.11.003 

3170 Joule 5, 3169–3186, December 15, 2021 

**ll** 

#### Article 



<!-- Start of picture text -->
A B C<br>15 min Control, encapsulated 15 min Carbazole, encapsulated With carbazole As-prepared<br>air, 24h<br>532 nm laser, 10 sun 532 nm laser, 10 sun air, 70h<br>0 0<br>Excitation<br>Control As-prepared<br>Perovskite air, 24h<br>Glass substrate air, 70h<br>Over time<br>600 650 700 750 800 850 900 600 650 700 750 800 850 900 600 650 700 750 800 850 900<br>Wavelength (nm) Wavelength (nm) Wavelength (nm)<br>D<br>E F<br>15 Control 170 pA With carbazole 70 pA<br>GB1<br>12 pristine<br>with carbazole<br>0.77 eV<br>9<br>GB2<br>0.38 eV GB1<br>6<br>GB2<br>GB3 GB4<br>3<br>0 GB3<br>-3<br>0 pA 0 pA<br>-6 GB4<br>35 40 45 50 55 60 65 70<br>1/kT (eV -1 )<br>).(LPamrou.. ).(LPamoru.. ).(LPamrou..<br>N N N<br>)<br>ln(<br><!-- End of picture text -->

Figure 1. Phase stability and ion migration characterization of perovskite films 

(A and B) Evolution of time-dependent PL spectra under 10 sun equivalent laser illumination for the control (A) and carbazole-treated encapsulated perovskite films (B). 

(C) Evolution of steady-state PL spectra for the unencapsulated pristine films and carbazole-treated films upon exposure to air. (D) The temperature-dependent conductivity of the pristine film and carbazole-treated film. 

(E and F) c-AFM images of the perovskite films without and with carbazole, each of them with four grain boundaries (GB) indicated with white lines. Scale bar: 200 nm. 

S3 and S4; Note S1). We speculate that carbazole molecules most probably stay at the GBs due to their incompatible size to fit the perovskite lattice. Thus, we can preliminarily infer that the introduction of carbazole additives to the perovskite precursor solution can hinder the migration of ions in the film, thereby suppressing halide segregation. 

We further investigated the influence of ambient air on phase stability and thus performed PL measurements on unencapsulated samples exposed to ambient air (relative humidity [RH] �55%). Clearly, exposure to humidity accelerates phase segregation (Figure 1C), especially for the control sample. When the pristine film was exposed toambient air under dark for about 3 days, the remeasured PL spectrum shows a significant red shift, whilethe carbazole-treatedfilmwas muchlessaffected, implyingenhanced phase stability even under humid conditions. In addition, we also found that the synergistic effect of light and humidity will accelerate phase segregation (Figure S5). Our results show that the illumination intensity, the environmental atmosphere, and trap passivation all alter the dynamics of halide segregation. In the case of superposition of multiple stressors, halide segregation occurs faster, but the addition of carbazole minimizes this behavior. 

To gain insight into the activation energy (Ea) of ion migration in the perovskite layer, temperature-dependent conductivity measurements were carried out (Figure 1D). 

Joule 5, 3169–3186, December 15, 2021 3171 

**ll** 

Article 

The Ea for the pristine and carbazole-treated perovskite films were calculated to be 0.38 and 0.77 eV in the activation region (>260 K), respectively. Theoretical calculations have predicted that the halide ions are the most mobile ions in the perovskite films since they have the lowest activation energy.<sup>43</sup> Thus, the Ea measured here can mainly be linked to that for halide migration. The obvious increase in Ea after carbazole treatment offers quantitative evidence for additive-suppressed ion migration, which may be attributed to the bonding effect of carbazole at the GBs. 

We performed conductive atomic force microscopy (c-AFM) measurements to study the conductivity difference between the grains and the GBs, potentially induced by the carbazole treatment. The topographic and current maps collected for both samples (see Figures 1E, 1F, and S6) clearly indicate that the GBs have different conductivities compared with the grains. In the whole grain area, the carbazole-treated sample seems to have a lower current than the pristine one, which may be attributed to the higher bulk resistance of the carbazole-treated film. The more important information for this characterization is the difference in conductivity between the grain surface and the GB. The line profile in Figure S6 clearly shows that for the carbazole-treated sample, most GB regions show a lower current compared with their surrounding grain region, which could be attributed to the suppression of ion migration by carbazole at the GBs. However, for the control sample, the GB region exhibits a higher dark conductivity than the grain surface, indicating higher ion migration activity at the GBs, which is also consistent with previous results that GBs can function as a channel for ion migration.<sup>44</sup> 

###### Mechanism of carbazole grain-boundary passivation 

In order to investigate the interaction between the carbazole and the perovskite, we conducted Fourier transform infrared (FTIR) spectroscopy. In Figure 2A, the absorption peak of the pure carbazole sample at around 3,416, 1,597, and 1,449 cm<sup>�1</sup> could be attributed to N–H stretching, N–H related bending, and C–N stretching frequencies, respectively.<sup>45</sup> For the carbazole-PbI2 sample, the C–N stretching feature did not show any major shift in frequency, while the N–H stretching and N–H-related bending vibrations shifted to 3,410 and 1,602 cm<sup>�1</sup> , respectively, indicating that carbazole could interact with the perovskite through N–H bonding. We show the possible interaction mechanism of carbazole at the GBs of perovskites in Figure 2C. 

In addition, we performed density functional theory (DFT) calculations on carbazole/ perovskite interfacial models to further understand the role of carbazole on passivating the perovskite surface, as well as the atomistic interaction between them. Based on the XRD patterns (Figure S3), we considered three representative (100), (101), and (111) perovskite surfaces with different terminations and estimated the binding affinities of carbazole with these surfaces. (All of the optimized perovskite slab structures before and after carbazole adsorption are shown in Figures S7 and S8.) Figure 2B illustrates the carbazole/perovskite interfacial structures, where the perovskite surfaces are terminated with an outermost I or formamidinium iodide (FAI) layer. We find that the carbazole molecule is inclined to bind with surface I<sup>�</sup> ions via hydrogen bonding (i.e., N–H$$$I, 2.73 to 2.92 A<sup>˚</sup> ), where such interactions result in binding energies (Eb) in the range of �0.4 to �0.7 eV for FAI-rich (100) and I-rich (111) surfaces, respectively. For the I-rich (101) surface, a shorter hydrogen-bond length (2.60 A<sup>˚</sup> ) as well as a larger Eb value (�2.26 eV) for the carbazole adsorption is found, suggesting that the carbazole molecules can stabilize the perovskite surface through hydrogen bonding interactions with halide ions, preventing halide-ion migration from the surface into the bulk. 

3172 Joule 5, 3169–3186, December 15, 2021 

**ll** 

#### Article 



<!-- Start of picture text -->
A B<br>FAI-rich FAPbI3 (100) I-rich FAPbI3 (101) FAI-rich FAPbI3 (111) I-rich FAPbI3 (111)<br>N-H stretching N-H related<br>bending<br>C-N stretching<br>Carbazole-PbI2<br>Carbazole<br>3400 1600 1400 1200<br>Wavenumber (cm -1 ) N–H···I = 2.92 Å N–H···I = 2.60 Å N–H···I = 2.73 Å N–H···I = 2.74 Å<br>E b = -0.55 eV E b = -2.26 eV E b = -0.70 eV E b = -0.41 eV<br>C D 1 E 27<br> Control<br>26  0.25% carbazole<br> 1% carbazole<br>25<br>0.1 ps-pulse laser<br>24<br>Perovskite<br>ITO/2PACz<br>Glass substrate 23<br>0.01 Pristine, on 2PACz 22<br>With carbazole, on 2PACz<br>21<br>0 1000 2000 3000 4000 3.0x10 18 6.0x10 18 9.0x10 18<br>Decay time (ns) Carrier density (cm -3 )<br>).<br>(au.<br>n<br>ois<br>si<br>m<br>s<br>n<br>Tar<br>).<br>(au.<br>L 2-1-1(cm) V s<br>P. Σμ<br>mor φ<br>N<br>,ytilib<br>o<br>M<br><!-- End of picture text -->

Figure 2. Mechanism of the grain-boundary passivation with carbazole additive (A) FTIR spectroscopy of pure carbazole and cabazole-PbI2 films. (B) Optimized interfacial structures for carbazole/FAPbI3 models with different surface orientations and terminations of FAPbI3, together with hydrogen-bond lengths (red dashed lines) and binding energies (Eb) between carbazole and perovskite. (C) Schematic illustration of interaction of carbazole with perovskite films. 

(D) Time-resolved photoluminescence (TRPL) spectra of the wide-band-gap (1.68 eV) perovskite films with or without carbazole on 2PACz-coated ITO glass substrate. 

(E) Mobility as a function of excitation carrier density, extracted from terahertz spectroscopy (TS). 

To demonstrate the passivation effect of this additive, time-resolved PL (TRPL) measurements were carried out (Figures 2D and S9). The perovskite films with carbazole additive on both PTAA- and 2PACz-based substrates exhibit a prolonged average PL decay time tave, which improved from 910 to 1,403 ns in the case of 2PACz. These results indicate that nonradiative recombination is significantly suppressed upon the addition of carbazole, which is expected to benefit the open-circuit voltage (Voc) and fill factor (FF) of the tandem device. Photothermal deflection spectroscopy (PDS) shows carbazole-treated perovskite has a smaller Urbach energy (Figure S11). We also investigated the electronic properties of our perovskite films upon carbazole additive via contactless terahertz (THz) spectroscopy (Figure 2E). The extracted yield mobility product (4Sm) generally decreases with increasing carrier density. At the lowest photoinduced carrier densities (�1.6 310<sup>18</sup> cm<sup>�3</sup> ), the pristine film shows a 4Sm mobility of around 22.1 cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> ; this value increases to 25.8 for 0.25 mol % and to 24.6 cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> for a 1-mol % sample. Combining the charge lifetime, tave, from TRPL results and the average mobility 4Sm/2 (Table S1), we can calculate the charge diffusion length L to be 5.1 and 6.8 mm, respectively, for the pristine and passivated films, which are noticeably longer than the thickness of the absorber in the devices. The improved carrier diffusion length in the perovskite film, which is the result of largely suppressed trap density, can benefit charge collection. In addition, we also performed Hall-effect measurements (Table S2). Both films exhibit a 

Joule 5, 3169–3186, December 15, 2021 3173 

**ll** 



<!-- Start of picture text -->
Article<br><!-- End of picture text -->



<!-- Start of picture text -->
A B C<br>15 8<br>10  Control, Forward,  7 PristineWith carbazole 1.2  Control<br>Control, Reverse  Carbazole n=1.74<br>5 Jsc  = 20.3 mA/cm 2 FF  = 78.7% 6<br>Voc  = 1.207 V          PCE  = 19.2%<br>0 5 1.1<br>n=1.86<br>-5 Carbazole, Forward 4<br>Carbazole, Reverse<br>-10 Jsc  = 20.6 mA/cm 2 FF  = 80.6% 3 1.0<br>Voc  = 1.218 V          PCE  = 20.2% 2<br>-15<br>1 0.9<br>-20<br>0<br>0.0 0.2 0.4 0.6 0.8 1.0 1.2 16 17 18 19 20 21 1 10 100<br>Voltage (V) Efficiency (%) Light intensity (%)<br>D<br>16 E Pristine  (eV) F With carbazole (eV)<br>Pristine<br> 280 K<br>12  300 K<br>with additive<br> 280 K<br>8  300 K<br>4<br>0<br>0.2 0.3 0.4 0.5<br>E �  (eV)<br>2)<br>m<br>c/<br>A<br>(m st<br>n<br>ytisn ou<br>e C  (V)Voc<br>d<br>tn<br>e<br>rr<br>u<br>C<br>16 -3-1 tDOS  (10).eVcm<br><!-- End of picture text -->

Figure 3. Single-junction device performance 

(A) J-V curves of the champion 2PACz-based perovskite devices with or without carbazole treatment. 

(B) The statistics of PCE distribution. 

(C) Voc evolution as a function of light intensities for the control and carbazole-treated perovskite devices. 

(D) Trap density of states (tDOS) distribution deduced from temperature-dependent C-f plots for the pristine and carbazole-treated devices. (E and F) Quasi-Fermi level splitting (QFLS) mapping for the ITO/2PACz/1.68 eV perovskite/LiF/C60 samples on glass under 1 sun equivalent light intensity. 

very weak p-type conductivity. The pristine films show a hole mobility of 32.3 cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> under a 1-T magnetic field, which is slightly higher than the results obtained with THz spectroscopy, while the carbazole-treated film show a relative increase of 13% to 39.0 cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> . 

Role of carbazole additive on the performance of single-junction devices We first optimized the carbazole additive concentration on single-junction perovskite devices. For this, we fabricated p-i-n devices with a glass/ITO/2PACz/1.68 eV perovskite/LiF/C60/BCP/Ag configuration. To obtain micrometer-thick perovskites, similar as those used on textured Si bottom cells in our tandem, we used here concentrated perovskite precursors (1.7 M), which results in a �900 nm perovskite layer on a planar substrate (Figure S12). Such thick films provided a test platform to optimize the carbazole additives for subsequent application to tandem devices. The best single-junction current-voltage (J-V) curves under forward and reverse scans are shown in Figure 3A, and the PV parameters are listed in Table S3. The 2PACz-based control device shows a PCE of 19.2% with a Voc of 1.21 V, an FF of 0.79. With carbazole treatment, the device exhibited a Voc of 1.22 V, a short-circuit current density (Jsc) of 20.6 mA$cm<sup>�2</sup> , and an FF of 0.81, yielding a PCE of 20.2%. The statistical PCE results demonstrate the reproducibility of the performance improvement after a small amount of carbazole addition was used (Figures 3B, S13, and S14; Note S2). The integrated photocurrent density based on external 

3174 Joule 5, 3169–3186, December 15, 2021 

**ll** 

#### Article 

quantum efficiency (EQE) spectra is compatible with Jsc in the J-V curves (Figure S15). Clearly, the improvement mainly comes from Voc and FF, which we attribute to the suppressed nonradiative recombination, as also supported by the TRPL results in Figure 2C. The built-in potential change upon carbazole addition has been evaluated by the Mott-Schottky analysis (Figure S16). Compared with the control device, the carbazole-treated device shows a shift toward a higher cutoff voltage, indicating a higher flat-band potential, which is also consistent with improved Voc after carbazole treatment. 

To further demonstrate the minimized carrier recombination upon carbazole treatment, we obtained the dependence of the Voc on the light intensity, as shown in Figure 3C. From the semilogarithmic plot, we can find a linear relationship, following the expression,slope = <u>nkTq</u><sup>log10e,wherenisthediodequalityfactor.Thecontrol</sup> and carbazole-treated devices exhibit n values of 1.86 and 1.74, respectively. The lower n value indicates that trap-assisted recombination was suppressed in the carbazole-treated device. On the device level, we demonstrated the reduced defect density at the GBs via temperature-dependent admittance spectroscopy measurements (Figure 3D). The capacitance distortion (Figure S17) mainly occurs at the frequency range of 10 to 1,000 Hz, in which the defect densities could be derived. In order to avoid the influence of ion migration on the derived trap density, no preconditioning was applied, and the device was in a zero bias and dark state environment during the measurement. The trap density of states (tDOS) analysis shows that at 300 K, the pristine device displays a peak trap density of 1.32 3 10<sup>17</sup> cm<sup>�3</sup> eV<sup>�1</sup> at 0.44 eV, while the passivated device has a smaller peak intensity of 1.23 3 10<sup>17</sup> cm<sup>�3</sup> eV<sup>�1</sup> at 0.39 eV. 

We also carried out absolute PL imaging on the two perovskite devices under 1 sun light illumination. Following the previously established process,<sup>46,47</sup> the absolute PL image could be converted into quasi-Fermi level splitting (QFLS) and Urbach energy (Eu) mapping (Figures 3E, 3F, and S18; Note S3). The carbazole-passivated devices exhibit a slightly higher and narrower QFLS distribution than the control, with their statistical mean value of 1.20 and 1.19 eV, respectively. The QFLS directly reflects the internal voltage of the complete devices, and it is indeed remarkably close to the Voc obtained from the 1-sun J-V curves. Ultraviolet photoelectron spectroscopy (UPS) results confirmed that the work function (WF) shifted down from 5.07 to 5.22 eV upon carbazole treatment (Figure S10), which could enable a higher internal voltage and more effective electron transfer at the interface between ETAl. and perovskite layer. In addition, the Eu distribution map with a mean value of 16.2 meV (Figure S18) was also obtained for the control sample, while the mean value for the carbazolepassivated sample is about 15.8 meV. The relatively larger QFLS and smaller Eu for carbazole-passivated devices provide further evidences for suppressed nonradiative recombination. 

###### Monolithic tandem device performance 

After verifying our results in the single-junction platforms, we applied our carbazolemodified 1.68-eV perovskites on double-side textured-SHJ bottom cells in the form of a tandem device. The schematic diagram of the device structure and the corresponding band structure are sketched in Figures 4A and S19, respectively. Our Si bottom cell is mildly textured with a relatively small pyramid size (Figure S27), so that our nearly micron-thick perovskite layer can cover the pyramid structure. The cross-section SEM image (Figure S20) of our tandem device shows that our perovskite-deposition technique provides end-to-end coverage. Previous optical simulations and experimental works<sup>12,13,48</sup> have shown that conformal-coated perovskite 

Joule 5, 3169–3186, December 15, 2021 3175 

**ll** 

#### Article 



<!-- Start of picture text -->
A B C<br>Ag<br>MgF2 0 V oc J sc FF PCE  30 Stabilized PCE: 28.6%<br>IZO (V) (mA/cm 2 ) (%) (%)<br>SnO2/C60/LiF Forward 1.859 19.6 78.2 28.6 10<br>Perovskite -5 Reverse 1.870 19.6 78.6 28.9 25 8<br>α-Si (i)/α-Si (n2-PACz/ITO/ + ) -10 20 6<br>4<br>Aperture area:<br>n-type Si -15 1.03 cm 2 2<br>15<br>0<br>24 25 26 27 28 29<br>α-Si (i)/α-Si (p + )/ITO/Ag -20 ReverseForward 10 PCE (%)<br>0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 10 20 30 40 50 60<br>Voltage (V) Time (s)<br>D E F<br>1.0 0.0<br>0<br>Voc Jsc FF PCE  0.8 0.2<br>(V) (mA/cm 2 ) (%) (%)<br>-5<br>Forward 1.866 19.1 74.3 26.5<br>Reverse 1.880 19.1 75.5 27.1 0.6 Spot1-PVK   19.75 mA/cm 2 0.4<br>-10 Spot2-PVK   19.62 mA/cm 2<br>0.4 Spot3-PVK   19.78 mA/cm 2 0.6<br>Spot1-Si  19.70 mA/cm 2<br>-15 Spot2-Si  19.80 mA/cm 2<br>0.2 Spot3-Si  19.74 mA/cm 2 0.8<br>3.8 cm 2 aperture area 1 cm -20 Forward<br>Reverse<br>0.0 1.0<br>0.0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 400 600 800 1000 1200<br>Voltage (V) Wavelength (nm)<br>2)<br>m<br>2)m c/W<br>c/(Aytisdtmenn (ttmporeopuuw Cstnou<br>rre de<br>u<br>C zilib<br>Sta<br>2)<br>m<br>c/<br>(Am )%(<br>ytisne QEE<br>d<br>ten Reflectance (%)<br>rr<br>u<br>C<br><!-- End of picture text -->

Figure 4. Tandem device performance 

(A) Schematic of the textured monolithic perovskite/Si tandem device. 

(B) J-V curves of the champion tandem cell with an aperture area of 1.03 cm<sup>2</sup> . The inset shows the photo of the corresponding device. The substrate size is around 23 * 23 mm. 

(C) Stabilized power output of the champion tandem device at the maximum power point (MPP) under AM 1.5G illumination. The inset shows the statistics of PCE distribution for our tandem devices fabricated in several batches. 

(D) Photo of the tandem device with an aperture area of 3.8 cm<sup>2</sup> . 

(E) J-V curves of the champion 3.8 cm<sup>2</sup> tandem device. 

(F) EQE spectra from three different spots on one tandem device. 

on the textured bottom cells is an ideal structure. However, front-end flat devices fabricated on double-sided, mildly textured bottom cells still provide promising optical gain, as we demonstrated here. In our tandem devices, the conformal coated 2PACz layers on 20 nm ITO layers act as the recombination junction. Figure 4B shows the J-V characteristic of the champion perovskite/Si tandem device under an aperture area of 1.03 cm<sup>2</sup> . The inset in Figure 4B displays the PV parameters for the champion device, with a PCE of 28.9% and negligible J-V hysteresis. From maximum power point (MPP) measurements with the three-point perturbation method, we recorded a stabilized PCE of 28.6%, with a VMPP of 1.58 V (Figure 4C). We verified the reproducibility of our processes, finding a narrow statistical distribution, as given in Figure 4C (inset), acquired from 14 devices of multiple processing batches. The corresponding EQE spectra for this champion tandem device were obtained, as shown in Figure S21. The integrated photocurrent density was calculated to be 19.70 and 19.95 mA/cm<sup>2</sup> , for perovskite and silicon subcells, respectively, which are in good agreement with the Jsc values from the J-V scan curve. The calculated spectral mismatch (see Figure S22; Note S4) for our tandem is 1.0163 for the top cell and 0.9799 for the bottom cell. We verified our in-house measurements with 28.2% stabilized power output certified by an accredited laboratory, the Japan Electrical Safety & Environment Technology Laboratories, (JET) (Figure S23). Our tandem device is commensurate with the state-of-the-art tandem devices in the 

3176 Joule 5, 3169–3186, December 15, 2021 

**ll** 

#### Article 

literature and represents the record-certified PCE for double-textured perovskite/Si tandem devices (Table S4). Importantly, our tandem device shows a relatively high Jsc value, by taking advantage of the improved light management in double-sided, textured bottom cell structures. The relatively large refractive index difference between the Si and perovskite layer generally causes a considerable reflectance from the overall device. Applying a random-pyramid textured structure at the top side of the Si bottom cell increases the optical light path and reduces the reflectance loss. To demonstrate the superiority of the double-textured structure in terms of light-harvesting, we compared the EQE and reflectance of the perovskite subcell on planar and textured Si substrates (Figure S24). Clearly, the textured structure significantly reduces the light reflectance in the response region of the c-Si subcell, as evidenced by the reflection curve in Figure S24. A certain percentage of photons at the band edge of the perovskite layer (wavelength of 580 to 720 nm) still could transmit through the perovskite cell to reach the Si bottom cell. With our highly crystalline, micrometer-thick perovskite, the photon utilization of the perovskite subcell near the band edge was also greatly improved. 

We showed the scalability potential of our tandem devices on a larger substrate with an aperture area of 3.8 cm<sup>2</sup> . A best PCE of 27.1% under reverse scan was achieved, as shown in Figure 4E. The Voc of this device reached 1.88 V, even slightly higher than that of our �1 cm<sup>2</sup> area devices. The analysis on performance contribution of perovskite and Si subcells are detailed in the supplemental information (Figures S25–S27; Note S5). Based on the respective performance results of perovskite and silicon single-junction devices, the Voc contribution from perovskite and Si subcell may be �1.19 and �0.69 V, respectively. The EQE spectra (Figure 4I) from three different spots show that the integrated Jsc is within a range of G0.08 mA/cm<sup>2</sup> . All these findings confirm the uniformity of our devices on larger substrates. The absolute �3% FF and 0.5 mA/cm<sup>2</sup> Jsc losses between �1 cm<sup>2</sup> and �3.8 cm<sup>2</sup> devices are due to the relatively large series resistance of evaporated silver contacts, and additional shading losses of the silver fingers. We expect that the utilization of industrially compatible screen-printed Ag contacts can help reduce these electrical losses, which will be considered in a future study. 

###### Stability evaluation 

To evaluate the effect of the carbazole additive on the stability of our tandem devices, we carried out a series of tests on encapsulated devices under different environmental conditions including outdoor and continuous light-soaking tests, as well as 85<sup>�</sup> C/85% IEC 61215:2016 (also called ISOS-D3) damp-heat tests. Specifically, 43 days of outdoor testing in a hot and sunny desert climate (Figures S28 and S29) includes all quadrants of the operational conditions such as continuous operation under illumination and heat and heat cycles from day to night. The daily peak device temperature can reach above 45<sup>�</sup> C (Figure S30) and the light intensity on a sunny day can reach 0.95 suns (measured by a pyranometer) at noon. These conditions represent an ideal test platform to understand the real-world behavior of tandem devices at a targeted operational location, such as for large solar energy plants. For better comparison, the daily performance evolution of the pristine device (dashed gray line) is superimposed on that of the carbazole-treated device (colored fill areas) in Figure 5A. On the subgraph of the short-circuit current (Isc), the two devices show an almost coinciding trend. However, the daily peak Voc and power output (Pm) trend curves gradually diverge with the passing of time. Clearly, the carbazole-treated device exhibits superior stability compared with the control. For the carbazole-treated device on the first day (23 Nov 2020), the peak Pm value and the corresponding light intensities were 18.2 mW/cm<sup>2</sup> and 0.937 sun, 

Joule 5, 3169–3186, December 15, 2021 3177 

**ll** 

Article 



<!-- Start of picture text -->
A<br>0.9<br>0.6<br>0.3<br>20<br>15<br>10<br>5<br>1.8<br>1.6<br>1.4<br>1.2<br>15<br>10<br>5<br>8 0<br>60<br>40<br>20<br>0<br>0 5 10 15 20 25 30 35 40<br>Time (day)<br>B<br>1.2<br>1.0<br>1.2<br>0.8 1.0<br>0.6 0.8 MPP Tracking (1-sun, RT) With Carbazole Without Carbazole<br>0 4 8 12 16<br>0 50 100 150 200 250<br>C Time (hour)<br>1.2<br>Voc Isc FF PCE<br>1.0<br>85  o C and 85% RH<br>0.8<br>0 100 200 300 400 500<br>Time (hour)<br>D E F<br>1.0 Pristine<br>Whole area<br>Area1<br>0.8<br>Area2<br>0.6 With carbazole<br>Whole area<br>0.4<br>area1<br>area2<br>0.2<br>0.0<br>1.4 1.5 1.6 1.7 1.8 1.9 2.0<br>Energy (eV)<br>Suns<br> (mW)Pm<br> (V)Voc<br> (mA)Isc<br>FF (%)<br>Norm. Pmpp<br>e<br>ula<br>v<br>d<br>e<br>zila<br>mro<br>N<br>x<br>ul<br>F<br>too<br>h<br>P<br>L<br>P<br>2Photons/(eV.m.s) 2Photons/(eV.m.s) omr.<br>N<br><!-- End of picture text -->

Figure 5. Stability analysis of the tandem devices (A) Outdoor performance of the tandem device in a hot desert climate, measured at the KAUST campus at Thuwal, Jeddah, Saudi Arabia for 43 days. J-V scans under forward direction were performed approximately every 10 min during the daytime. The colored fill areas represent the results of the carbazole-treated encapsulated tandem device, while the dashed gray line in PV parameters data represents that of the pristine device without additive. 1 sun indicates 100 mW/cm<sup>2</sup> solar irradiance. The daily maximum values of Voc and Pm are connected by dotted lines in an interpolated manner. (B) Long-term MPP tracking of the tandem devices with and without carbazole, under continuous xenon light illumination. (C) PV performance evolution of one encapsulated tandem device which was subjected to a damp-heat environment at 85<sup>�</sup> C and 85% RH. (D and E) Absolute PL intensity mapping at 1.68 eV under 1-sun light illumination for the encapsulated control (D) and carbazole-treated devices after outdoor tests (E). 

(F) PL spectra of the device in different positions. 

3178 Joule 5, 3169–3186, December 15, 2021 

**ll** 

#### Article 

respectively, yielding a PCE of 19.4% (Table S5). After 38 days of outdoor testing, the Pm can reach 19.3 mW/cm<sup>2</sup> under 1.015 sun, potentially implying the PCE retention could reach almost 98% if it is assumed that the spectrum on the 38th day is almost the same as that on the first day. In contrast, the control device shows a faster decay in performance, with the power output decreasing from 17.7 mW/cm<sup>2</sup> initially to 13.0 mW/cm<sup>2</sup> and the PCE from 19% to 14.6% after 40 days. To demonstrate the change in PV performance on the first day and the thirty-eighth day, Figure S31 shows the J-V curves recorded every �10 min under forward scan from 7 AM to 6 PM. Depending on the intensity and distribution of the daily spectrum, the daily PCE or retention shows fluctuations. Overall, after 40 days of outdoor testing, the performance retention reaches over 93% for the carbazole-treated device, while it is only about 77% for the control device. The performance degradation in the pristine device was mainly from the decrease in Voc, possibly indicating that the degradation in this field test was from the perovskite itself. These results could demonstrate that the carbazole additive can improve the stability of tandem devices under light and heat stress. 

We further carried out the operational stability evaluation of tandem devices in a controlled lab environment under continuous xenon-lamp illumination with MPP tracking (Figure 5B). After 250 h, the reference device showed about 8% performance loss. In contrast, our carbazole-treated device retained nearly 100% of the initial performance. The main difference between the two devices is in the initial few hours of the aging process, which may be associated with a rapid increase in the density of trap states for the pristine device. The bias during the aging process may cause ion migration and promote the generation of trap defects, which especially occurred in the initial aging process. In the subsequent aging process, the trap-state density may be favorably stabilized at the GBs or at the interfaces, and accordingly, the performance would be relatively stable. Therefore, we can infer that the defect-formation rate in the reference device was faster than that in the carbazole-treated one. 

To demonstrate the tolerance of our encapsulated devices to high temperature and high humidity environments, we performed a damp-heat test at 85<sup>�</sup> C with 85% RH (Figures 5C and S32). Notably, after nearly 500 h, the Voc and Jsc in our tandems were quite stable, and the PCE retention could reach 87%. The performance degradation was found mainly in the FF, which could be associated with degraded top contact electrode. The highly stable Voc implies that the perovskite layer itself did not degrade after 500 h of damp-heat testing. We can speculate that as the testing time progressed, the degradation in our damp-heat test should be due to moisture invasion rather than inherent thermal decomposition. 

After the long-term stability test, the cross-sectional morphology of the tandem devices was characterized. The devices were taken out by deliberately destroying the encapsulation glass. For the carbazole-treated device after several months of outdoor testing, we could not observe an obvious change in the cross-sectional SEM images (Figure S33). The PL mappings (Figures 5D and 5E) on two tandem devices were obtained. For the pristine device, significant phase segregation could be observed in the range of hundreds of microns, possibly implying irreversible degradation. Based on the PL spectra (Figure 5F), some narrow band-gap (<1.68 eV) regions appeared in a large areal portion; these regions show a stronger PL intensity because the iodine-rich phase primarily acts as a recombination trap.<sup>32,49</sup> In contrast, such phase segregation was not observed in the carbazole-treated devices after outdoor testing, as evidenced by the uniform distribution of PL spectra in 

Joule 5, 3169–3186, December 15, 2021 3179 

**ll** 

Article 

Figure S34. These results confirm that the carbazole treatment suppressed phase segregation, thus improving the long-term operational stability of the tandem devices. 

###### Conclusions 

We demonstrated that the addition of carbazole could suppress phase segregation and passivate the perovskite films under light and humid air stress, leading to a significant reduction in the density of trap states. After integrating our optimized wide-band-gap perovskite cell onto a SHJ bottom cell, we achieved a certified 28.2%-efficient monolithic perovskite/silicon tandem device. A series of stability tests on encapsulated tandem devices were carried out to prove the durability of our tandem devices, showing that the carbazole additive leads to a significant improvement in device stability even in a hot and humid outdoor environment. Our work demonstrates great prospects for future practical applications of perovskite/Si tandem solar cells. A further understanding of the passivation characteristics of additives in perovskite films will likely be essential for the development of efficient and stable perovskite-silicon tandem solar cells. 

##### EXPERIMENTAL PROCEDURES 

###### Resource availability 

###### Lead contact 

Further information and requests for resources should be directed to and will be fulfilled by the lead contact, Stefaan De Wolf (stefaan.dewolf@kaust.edu.sa). 

###### Materials availability 

This study did not generate new unique materials. 

###### Data and code availability 

The data that support the findings of this study are available from the corresponding author upon reasonable request. 

###### Materials 

Patterned tin-doped indium oxide (ITO) (�15 U/sq) coated glass was purchased from Xin Yan Technology LTD. Lead iodide (PbI2) and lead bromide (PbBr2) were purchased from Alfa Aesar. FAI, methylammonium bromide (MABr) were purchased from Greatcell Solar. Cesium iodide (CsI), anhydrous dimethylformamide (DMF), anhydrous dimethyl sulfoxide (DMSO), anhydrous chlorobenzene (CB), lithium fluoride (LiF), carbazole were purchased from Sigma-Aldrich. PTAA was bought from Xi’an p-OLED. [2-(9H-carbazol-9-yl)ethyl]phosphonic acid (2PACz) was purchased from TCI. C60 (>99.5% purity) was purchased from Nano-C. Bathocuproine (BCP, >99.5% purity) was bought from Ossila Ltd. The ceramic 2-inch IZO target was purchased from Plasmaterials, Inc. All the chemicals were used as received without further purification. 

###### Si bottom cell fabrication 

4-inch n-doped float-zone (FZ) Si wafer with a thickness of 260–280 mm was used for Si bottom cell fabrication. The double-side texture structure with random distributed pyramids was obtained using an alkaline solution. The size of the pyramids is controlled by adjusting the alkaline concentration and the process temperature. The wafers were dipped in hydrofluoric acid solution followed by cleaning process, before transferred into a plasma enhanced chemical vapor deposition (PECVD) cluster (Indeotec Octopus II) for amorphous silicon (a-Si) deposition. 8 nm intrinsic (i), 6 nm n-doped, and 13 nm p-doped a-Si layer were grown on wafer using the PECVD 

3180 Joule 5, 3169–3186, December 15, 2021 

**ll** 

#### Article 

cluster tool. The process temperatures are 200<sup>�</sup> C. The power for i-a-Si:H layer deposition is 50 W with a 800 sccm H2 and 25 sccm SiH4. The n-doped a-Si layer was deposited under 40 W with 15 sccm SiH4 and 92 sccm 2% PH3/H2, and the p-doped a-Si layer was deposited under 40 W with 50 sccm SiH4 and 75 sccm 2% Trimethylborane/H2. 150 nm ITO and 250 nm Ag were sputtered on the backside of the wafer. 15 nm ITO recombination junction was sputtered on the front side. In order to recover sputtering damage, an annealing step at 200<sup>�</sup> C for 10 min was carried out. 

###### Single-junction perovskite solar cell fabrication 

ITO glasses were ultrasonically cleaned with detergent, deionized water, acetone, and isopropanol successively, and then blow-dried with compressed nitrogen. The substrates were subjected to UV-Ozone treatment for 15 min before any film deposition. For PTAA deposition, 2 mg/mL PTAA solution in CB was used. For 2PACz deposition, 1 mg/mL 2-PACz in ethanol was used. The 2PACz molecule can covalently bind to the underlying ITO layer through its phosphonic acid anchoring group, thereby forming a conformal self-assembled monolayer. The PTAA or 2PACz as hole transport layer (HTL) was spin-coated on ITO-coated substrates at 5,000 rpm for 50 s, followed by drying at 100<sup>�</sup> C for 10 min. 1.7 M Cs0.05FA0.8MA0.15Pb(I0.75Br0.25)3 perovskite precursor solution was prepared by dissolving a mixture of FAI, MABr, CsI, PbI2, and PbBr2 in a mixed solvent (DMF/DMSO = 4:1). A certain amount of carbazole was added into the perovskite solution. A low spin-coating speed with a relatively long dwell time is beneficial to obtain a complete coverage of perovskite layer on the textured silicon cells. The perovskite films were spin-coated at 2,000 rpm for 50 s then followed with 7,000 rpm for 10 s. Chlorobenzene was dropped in the center of the substrates 12 s before the end of the spin-coating process. After the rotation ceased, the substrates were immediately transferred onto a hotplate of 100<sup>�</sup> C and were annealed for 15 min. 1 nm LiF, 25 nm C60, 6 nm BCP and 100 nm Ag layers were thermally evaporated on perovskite films sequentially. 

###### Perovskite top cell fabrication on Si substrate 

The Si bottom wafers were subjected to UV-Ozone treatment for 15 min before transferred into the glovebox. The processes for HTL and perovskite deposition is the same as that on single-junction devices. After perovskite deposition, 1 nm LiF and 15 nm C60 were subsequently deposited by thermal evaporation. 20 nm SnO2 was then deposited by atomic layer deposition (ALD) using a Picosun system. The substrate temperature was maintained at 100<sup>�</sup> C during ALD deposition with TDMASn precursor source at 80<sup>�</sup> C and H2O source at 18<sup>�</sup> C. The pulse and purge time for tetrakis(dimethylamino)tin(IV) (TDMASn) is 1.6 and 5.0 s with a 90 sccm carrier gas of nitrogen, for H2O is 1.0 and 5.0 s with 90 sccm N2. 140 cycles was used. For IZO deposition, a 3-inch IZO ceramic target containing 98 wt% In2O3 and 2 wt% ZnO was used. 25 sccm Ar with 0.5% O2 was used a process gas, yielding a �0.5 mTorr process pressure. 70 nm IZO was sputtered on top of the SnO2 through a shadow mask using a 43 W sputtering power. Ag finger with a thickness of 350 nm was thermally evaporated using a high precision shadow mask. Finally, 120 nm MgF2 was thermally evaporated as an anti-reflection layer. The thickness of LiF, C60, IZO and MgF2 layers were first calibrated by spectroscopic ellipsometer. The evaporation rate and thickness of each experiment were monitored by quartz crystal microbalance sensors. 

###### Device encapsulation and stability tests 

The tandem devices were sandwiched between two cover glasses with black butyl rubber sealant at the edges. Tinned plated copper strips were used to contact the 

Joule 5, 3169–3186, December 15, 2021 3181 

**ll** 

Article 

upper and lower electrodes of the tandem devices using Ag paste, and extend to the outside of the cover glass. For outdoor stability measurement, the encapsulated devices were mounted at KAUST campus in a hot desert climate, with a tilt angle of 25<sup>�</sup> and south-facing orientation. Devices were masked with a black tape, and J-V scans were performed approximately every 10 min during the daytime. The solar irradiance was recorded using a calibrated pyranometer. Data acquisition was performed using EKO’s MP160 software. For indoor stability measurement, the encapsulated devices were placed on a metal plate with a controlled temperature of 25<sup>�</sup> C. The devices were continuously exposed to white light generated by xenon lamp of Newport solar simulator, and were tracked at MPP using a home-made software. For damp-heat test, the devices were placed inside an environmental chamber with a condition of 85<sup>�</sup> C and 85% RH and were taken out for J-V measurement at some intervals. 

###### Solar cell characterization 

Single-junction opaque devices were tested in a glove box using Keithley 2,400 at room temperature under AM 1.5G illuminations (1,000 W/m<sup>2</sup> ) from an Abet Technologies Sun 3000 solar simulator which was calibrated using a standard silicon cell (RERA). Current-voltage (J-V) curves were obtained both in reverse (1.3 V / �0.1 V) and forward scan (�0.1 V / 1.3 V) with a step size of 10 mV. J-V measurements on tandem devices were performed in the air under LED-based solar simulator (Wavelabs Sinus 220). About 200 mV/s scan speed was used and no preconditioning was used in this work. A mask with an aperture area of 1.03 cm<sup>2</sup> for tandem device was used. The light intensity was calibrated using Fraunhofer ISE CalLab certified c-Si solar cells. EQE measurements were measured using a LOANA system (PVTools). The chopped monochromatic light beam was focused entirely on the active area of the solar cells. When measuring Si bottom subcell, a blue LED light (525 nm) was illuminated on the cell and a 0.6 V bias voltages were applied. When measuring perovskite top subcell, a near-infrared LED (950 nm) was illuminated on the cell and a 0.9 V bias voltages were applied. 

###### Atomic force microscopy measurement 

Current and topographic mappings were obtained using a Digital Instruments Multimode AFM (Veeco Metrology Group). Current mappings were obtained using PeakForce TUNA mode. AFM tips (model: PFTUNA) with nominal tip radius 25 nm, nominal spring constant 0.4 N/m and 20 nm PtIr coating. The perovskite films were deposited on ITO-coated glass substrate. A voltage of 1 V was applied to the substrate and the tip was grounded. 

###### PL measurement 

Steady PL and TRPL measurements were carried out with a spectrofluorometer (Fluoroma-Modular, Horiba Scientific). For steady PL, 500 nm monochromatic light was continuously illuminated on the surface of the films. Emission spectra with wavelengths between 650 and 850 nm were collected. For TRPL, a 633 nm pulsed laser which was generated from a picosecond laser diode (PicoQuant) was used for the pump excitation. The fluence is estimated to be around �10 nJ/cm<sup>2</sup> . A long-pass 650 nm filter was used, and 738 nm light was probed. 

For time-dependent PL spectra measurement, the perovskite films on bare glass were encapsulated in a nitrogen glovebox using an ultra-thin glass cover slide with edge sealed by UV-curable epoxy. The PL spectra was recorded about each 1 min using hyperspectral luminescence imaging system equipped with an 

3182 Joule 5, 3169–3186, December 15, 2021 

**ll** 

#### Article 

optical microscope with a 203 objective and a 532 nm laser with controlled laser intensity. 

###### Terahertz spectroscopy (TS) measurement 

Upon light excitation, the non-equilibrium photo-generated free charge will cause the conductivity change (DS) in the perovskite film, which causes changes in THz transmission. A relationship may be expressed as 



<!-- Start of picture text -->
DT<br>DS = ε0cðnA + nBÞ<br>� T �<br><!-- End of picture text -->

where DT is the photoinduced change in terahertz electric field. nA and nB are the refractive index of the perovskite film and quartz substrate. The number of photoexcited charge carriers N was determined using 



<!-- Start of picture text -->
E<br>N = F hn Abs<br><!-- End of picture text -->

Where E is the total energy of the excitation pulse, hn is photon energy, Abs is the absorptivity of the sample to the excitation light. F is the ratio of charges created per photon absorbed. 

The charge carrier mobility m is given by 



<!-- Start of picture text -->
DSAeff<br>m = F<br>Ne<br><!-- End of picture text -->

where Aeff is the overlapping area between the spots of optical pumping light and THz probe light. 

###### Ion-migration activation energy measurement 

The temperature-dependent conductivity measurement was carried out to extract ion-migration activation energy following previously established processes.<sup>50</sup> Laser scribing with a wavelength of 532 nm was first applied onto ITO-coated substrates, resulting in a scribing width of �40 mm. Lateral devices were then fabricated by depositing perovskite layer on the patterned ITO substrates. The devices were placed inside a Lakeshore Probe Station under vacuum condition. The device was first cooled and stabilized at 170 K for 30 min. Then, the device was slowly heated to 320 K with a step of 10 K. A 50 V voltage was applied to the two insolated ITO electrodes, and current was collected after a stabilization time of 10 s. The activation energy for ion migration was extracted based on the following Nernst-Einstein equations: 



<!-- Start of picture text -->
s0 �Ea<br>sðTÞ = T exp � kT�<br><!-- End of picture text -->

where s0 and k are constants, s and T are temperature-dependent conductivity and temperature, respectively, and Ea is the activation energy for ion migration. Ea can be derived from the slope of the ln(sT) versus 1/kT curves. 

###### Trap density measurements by thermal admittance spectroscopy 

Frequency-dependent capacitance measurement on complete devices was carried out at different temperature conditions. The density of the defect is given by the equation below 



<!-- Start of picture text -->
Vbi dC u<br>NT ðEuÞ = �<br>qW du kBT<br><!-- End of picture text -->

Joule 5, 3169–3186, December 15, 2021 3183 

**ll** 

Article 



<!-- Start of picture text -->
bT 2<br>Eu = kBTln<br>u<br>!<br><!-- End of picture text -->

where Vbi denotes the built-in voltage in the junction, u is the angular frequency, q is the elementary charge, k is the Boltzmann’s constant, T is the temperature,Eu is the demarcation energy, and b is a temperature independent parameter. Only the defects below the demarcation energy can follow the applied ac voltage, and the charging and discharging of the defect contribute to the capacitance. 

� <u>Ea</u> Following the equation u0 = bT<sup>2</sup> exp kT , the defect activation energy (Ea) � � and b can be extracted from the slope and intercept of the ln(u0=T<sup>2</sup> ) versus 1/kT curves. The characteristic transition frequency u0 can be determined by the extreme value of the capacitance spectrum derivative with respect to frequency (-f*dC/df). 

###### Density functional theory (DFT) calculations 

We performed DFT calculations on the carbazole/FAPbI3 interfaces by using the generalized gradient approximation (GGA) approach and the Perdew-Burke-Ernzerhof (PBE) functional as implemented in Vienna ab initio simulation package (VASP).<sup>51,52</sup> The carbazole/FAPbI3 interfacial models were built by placing carbazole molecules on both the top and bottom surfaces of FAPbI3 slabs. We further relaxed the atomic positions until the total Hellmann-Feynman forces in each atom were less than 0.01 eV/A<sup>˚</sup> . The cutoff energy of plane-wave basis set for the wavefunctions was set at 500 eV. The Uniform Brillouin zone grids of a 63636 k-mesh for the cubicphase FAPbI3 bulk, a 4 3 4 3 1 k-mesh for the FAPbI3 slabs and for the carbazole/ FAPbI3 interfaces were used. The binding energies (Eb) were calculated with the equation of Eb = (E(total) � E(FAPbI3) � E(carbazole))/2, where E(total) is the total energy, E(FAPbI3) is the energy of FAPbI3 slab, and E(carbazole) is the energy of carbazole molecule. 

##### SUPPLEMENTAL INFORMATION 

Supplemental information can be found online at https://doi.org/10.1016/j.joule. 2021.11.003. 

##### ACKNOWLEDGMENTS 

This work was supported by the King Abdullah University of Science and Technology (KAUST) Office of Sponsored Research (OSR) under Award No: OSR-CARF URF/1/3079-33-01, KAUST OSR-CRG 400 RF/1/3383, and KAUST OSR-CRG20183737. 

##### AUTHOR CONTRIBUTIONS 

J.L. conceived and conducted the research. J.L. and E.A. wrote the paper. J.Y. performed DFT calculations. M.D.B., A.U.R., and T.G.A. fabricated the Si bottom cell. E.Y. performed the ion-migration activation energy measurement. E.U. helped to conduct PL measurements. G.T.H. performed XPS measurements. M.W and Y.G performed THz and PDS measurements. J.I.K. contributed to TRPL data analysis. M.D.B., M.B., and M.F.S. contributed to outdoor tests. F.H.I., A.S.S., X.Z., W.Y., and F.X. contributed to data analysis. K.Z. and M.L. performed AFM measurement. O.M.B., T.D.A., M.L., O.F.M., F.L., and S.D.W. supervised the project and contributed to the manuscript draft. 

3184 Joule 5, 3169–3186, December 15, 2021 

**ll** 

#### Article 

##### DECLARATION OF INTERESTS 

J.L., E.A., and S.D.W. are inventors on a patent application related to this work filed by King Abdullah University of Science and Technology (filed 23 August 2021). The other authors declare no competing interests. 

Received: August 10, 2021 Revised: September 22, 2021 Accepted: October 28, 2021 Published: November 29, 2021 

##### REFERENCES 

1. Kojima, A., Teshima, K., Shirai, Y., and 11. Chen, B., Yu, Z.J., Manzoor, S., Wang, S., Miyasaka, T. (2009). Organometal halide Weigand, W., Yu, Z.H., Yang, G., Ni, Z.Y., Dai, perovskites as visible-light sensitizers for X.Z., Holman, Z.C., and Huang, J. (2020). Bladephotovoltaic cells. J. Am. Chem. Soc. 131, coated perovskites on textured silicon for 26%6050–6051. efficient monolithic perovskite/silicon tandem solar cells. Joule 4, 850–864. 

2. Lee, M.M., Teuscher, J., Miyasaka, T., Murakami, T.N., and Snaith, H.J. (2012). Efficient hybrid solar cells based on mesosuperstructured organometal halide perovskites. Science 338, 643–647. 

   12. Sahli, F., Werner, J., Kamino, B.A., Bra¨uninger, M., Monnard, R., Paviet-Salomon, B., Barraud, L., Ding, L., Diaz Leon, J.J., Sacchetto, D., et al. (2018). Fully textured monolithic perovskite/ silicon tandem solar cells with 25.2% power conversion efficiency. Nat. Mater. 17, 820–826. 

3. Jeon, N.J., Noh, J.H., Kim, Y.C., Yang, W.S., Ryu, S., and Seok, S.I. (2014). Solvent engineering for high-performance inorganicorganic hybrid perovskite solar cells. Nat. Mater. 13, 897–903. 

   13. Aydin, E., Allen, T.G., De Bastiani, M., Xu, L.J., A<sup>´</sup> vila, J., Salvador, M., Van Kerschaver, E., and De Wolf, S. (2020). Interplay between temperature and bandgap energies on the outdoor performance of perovskite/silicon tandem solar cells. Nat. Energy 5, 851–859. 

   14. Hou, Y., Aydin, E., De Bastiani, M., Xiao, C., Isikgor, F.H., Xue, D.J., Chen, B., Chen, H., Bahrami, B., Chowdhury, A.H., et al. (2020). Efficient tandem solar cells with solutionprocessed perovskite on textured crystalline silicon. Science 367, 1135–1140. 

4. De Bastiani, M., Subbiah, A.S., Aydin, E., Isikgor, F.H., Allen, T.G., and De Wolf, S. (2020). Recombination junctions for efficient monolithic perovskite-based tandem solar cells: physical principles, properties, processing and prospects. Mater. Horiz. 7, 2791–2809. 

5. Werner, J., Niesen, B., and Ballif, C. (2018). Perovskite/silicon tandem solar cells: marriage of convenience or true love story? - an overview. Adv. Mater. Interfaces 5, 1700731. 

   15. Al-Ashouri, A., Ko¨ hnen, E., Li, B., Magomedov, A., Hempel, H., Caprioglio, P., Ma´rquez, J.A., Morales Vilches, A.B., Kasparavicius, E., Smith, J.A., et al. (2020). Monolithic perovskite/silicon tandem solar cell with >29% efficiency by enhanced hole extraction. Science 370, 1300– 1309. 

6. Leijtens, T., Bush, K.A., Prasanna, R., and McGehee, M.D. (2018). Opportunities and challenges for tandem solar cells using metal halide perovskite semiconductors. Nat. Energy 3, 828–838. 

   16. Aydin, E., Liu, J., Ugur, E., Azmi, R., Harrison, G.T., Hou, Y., Chen, B., Zhumagali, S., De Bastiani, M., Wang, M.C., et al. (2021). Ligandbridged charge extraction and enhanced quantum efficiency enable efficient n-i-p perovskite/silicon tandem solar cells. Energy Environ. Sci. 14, 4377–4390. 

7. Lal, N.N., Dkhissi, Y., Li, W., Hou, Q., Cheng, Y.-B., and Bach, U. (2017). Perovskite tandem solar cells. Adv. Energy Mater. 7, 1602761. 

8. Mazzarella, L., Lin, Y.-H., Kirner, S., MoralesVilches, A.B., Korte, L., Albrecht, S., Crossland, E., Stannowski, B., Case, C., Snaith, H.J., and Bach, U. (2019). Infrared light management using a nanocrystalline silicon oxide interlayer in monolithic perovskite/silicon heterojunction tandem solar cells with efficiency above 25. Adv. Energy Mater. 9, 1803241. 

   17. Bush, K.A., Palmstrom, A.F., Yu, Z.J., Boccard, M., Cheacharoen, R., Mailoa, J.P., McMeekin, D.P., Hoye, R.L.Z., Bailie, C.D., Leijtens, T., et al. (2017). 23.6%-efficient monolithic perovskite/ silicon tandem solar cells with improved stability. Nat. Energy 2, 17009. 

9. Kim, D., Jung, H.J., Park, I.J., Larson, B.W., Dunfield, S.P., Xiao, C., Kim, J., Tong, J., Boonmongkolras, P., Ji, S.G., et al. (2020). Efficient, stable silicon tandem cells enabled by anion-engineered wide-bandgap perovskites. Science 368, 155–160. 

   18. N.R.E.L. (2021) Best research-cell efficiency chart. https://www.nrel.gov/pv/cell-efficiency.html. 

   19. Allen, T.G., Bullock, J., Yang, X., Javey, A., and De Wolf, S. (2019). Passivating contacts for crystalline silicon solar cells. Nat. Energy 4, 914–928. 

10. Chen, B., Yu, Z., Liu, K., Zheng, X., Liu, Y., Shi, J., Spronk, D., Rudd, P.N., Holman, Z., and Huang, J. (2019). Grain engineering for perovskite/ silicon monolithic tandem solar cells with efficiency of 25.4. Joule 3, 177–190. 

20. Yoshikawa, K., Kawasaki, H., Yoshida, W., Irie, T., Konishi, K., Nakano, K., Uto, T., Adachi, D., Kanematsu, M., Uzu, H., and Yamamoto, K. (2017). Silicon heterojunction solar cell with 

interdigitated back contacts for a photoconversion efficiency over 26. Nat. Energy 2, 17032. 

21. Knight, A.J., and Herz, L.M. (2020). Preventing phase segregation in mixed-halide perovskites: a perspective. Energy Environ. Sci. 13, 2024–2046. 

22. Hoke, E.T., Slotcavage, D.J., Dohner, E.R., Bowring, A.R., Karunadasa, H.I., and McGehee, M.D. (2015). Reversible photo-induced trap formation in mixed-halide hybrid perovskites for photovoltaics. Chem. Sci. 6, 613–617. 

23. Zhao, Y., Miao, P., Elia, J., Hu, H., Wang, X., Heumueller, T., Hou, Y., Matt, G.J., Osvet, A., Chen, Y.-T., et al. (2020). Strain-activated lightinduced halide segregation in mixed-halide perovskite solids. Nat. Commun. 11, 6328. 

24. Duong, T., Pham, H., Kho, T.C., Phang, P., Fong, K.C., Yan, D., Yin, Y., Peng, J., Mahmud, M.A., Gharibzadeh, S., et al. (2020). High Efficiency perovskite–silicon Tandem Solar Cells: effect of Surface Coating versus Bulk Incorporation of 2D perovskite. Adv. Energy Mater. 10, 1903553. 

25. Xu, J., Boyd, C.C., Yu, Z.J., Palmstrom, A.F., Witter, D.J., Larson, B.W., France, R.M., Werner, J., Harvey, S.P., Wolf, E.J., et al. (2020). Triple-halide wide-band gap perovskites with suppressed phase segregation for efficient tandems. Science 367, 1097–1104. 

26. Bush, K.A., Frohna, K., Prasanna, R., Beal, R.E., Leijtens, T., Swifter, S.A., and McGehee, M.D. (2018). Compositional engineering for efficient wide band gap perovskites with improved stability to photoinduced phase segregation. ACS Energy Lett 3, 428–435. 

27. Rehman, W., McMeekin, D.P., Patel, J.B., Milot, R.L., Johnston, M.B., Snaith, H.J., and Herz, L.M. (2017). Photovoltaic mixed-cation lead mixed-halide perovskites: links between crystallinity, photo-stability and electronic properties. Energy Environ. Sci. 10, 361–369. 

28. Zhou, Y., Jia, Y.-H., Fang, H.-H., Loi, M.A., Xie, F.-Y., Gong, L., Qin, M.-C., Lu, X.-H., Wong, C.-P., and Zhao, N. (2018). Composition-tuned wide bandgap perovskites: from grain engineering to stability and performance improvement. Adv. Funct. Mater. 28, 1803130. 

29. Braly, I.L., Stoddard, R.J., Rajagopal, A., Uhl, A.R., Katahara, J.K., Jen, A.K.-Y., and Hillhouse, H.W. (2017). Current-induced phase segregation in mixed halide hybrid perovskites and its impact on two-terminal tandem solar cell design. ACS Energy Lett 2, 1841–1847. 

Joule 5, 3169–3186, December 15, 2021 3185 

### **ll** 

#### Article 

30. Abdi-Jalebi, M., Andaji-Garmaroudi, Z., Cacovich, S., Stavrakas, C., Philippe, B., Richter, J.M., Alsari, M., Booker, E.P., Hutter, E.M., Pearson, A.J., et al. (2018). Maximizing and stabilizing luminescence from halide perovskites with potassium passivation. Nature 555, 497–501. 

31. Zhou, Y., Wang, F., Cao, Y., Wang, J.-P., Fang, H.-H., Loi, M.A., Zhao, N., and Wong, C.-P. (2017). Benzylamine-treated wide-bandgap perovskite with high thermal-photostability and photovoltaic performance. Adv. Energy Mater. 7, 1701048. 

32. Isikgor, F.H., Furlan, F., Liu, J., Ugur, E., Eswaran, M.K., Subbiah, A.S., Yengel, E., De Bastiani, M., Harrison, G.T., Zhumagali, S., et al. (2021). Concurrent cationic and anionic perovskite defect passivation enables 27.4% perovskite/silicon tandems with suppression of halide segregation. Joule 5, 1566–1586. 

33. Bush, K.A., Rolston, N., Gold-Parker, A., Manzoor, S., Hausele, J., Yu, Z.J., Raiford, J.A., Cheacharoen, R., Holman, Z.C., Toney, M.F., et al. (2018). Controlling thin-film stress and wrinkling during perovskite film formation. ACS Energy Lett 3, 1225–1232. 

34. Turren-Cruz, S.-H., Hagfeldt, A., and Saliba, M. (2018). Methylammonium-free, highperformance, and stable perovskite solar cells on a planar architecture. Science 362, 449–453. 

35. Chen, B., Rudd, P.N., Yang, S., Yuan, Y., and Huang, J. (2019). Imperfections and their passivation in halide perovskite solar cells. Chem. Soc. Rev. 48, 3842–3867. 

36. Yang, S., Dai, J., Yu, Z., Shao, Y., Zhou, Y., Xiao, X., Zeng, X.C., and Huang, J. (2019). Tailoring passivation molecular structures for extremely small open-circuit voltage loss in perovskite solar cells. J. Am. Chem. Soc. 141, 5781–5787. 

37. Aydin, E., De Bastiani, M., and De Wolf, S. (2019). Defect and contact passivation for 

- perovskite solar cells. Adv. Mater. 31, 46. Stolterfoht, M., Wolff, C.M., Ma´rquez, J.A., e1900428. Zhang, S., Hages, C.J., Rothhardt, D., Albrecht, S., Burn, P.L., Meredith, P., Unold, T., and 

- 38. Wang, R., Xue, J., Wang, K.-L., Wang, Z.-K., Neher, D. (2018). Visualization and suppression Luo, Y., Fenning, D., Xu, G., Nuryyeva, S., of interfacial recombination for high-efficiency Huang, T., Zhao, Y., et al. (2019). Constructive large-area pin perovskite solar cells. Nat. molecular configurations for surface-defect Energy 3, 847–854. passivation of perovskite photovoltaics. Science 366, 1509–1513. 47. Braly, I.L., deQuilettes, D.W., Pazos-Outo´ n, 

   47. Braly, I.L., deQuilettes, D.W., Pazos-Outo´ n, L.M., Burke, S., Ziffer, M.E., Ginger, D.S., and Hillhouse, H.W. (2018). Hybrid perovskite films approaching the radiative limit with over 90% photoluminescence quantum efficiency. Nature Photon 12, 355–361. 

39. Bai, S., Da, P., Li, C., Wang, Z., Yuan, Z., Fu, F., Kawecki, M., Liu, X., Sakai, N., Wang, J.T.-W., et al. (2019). Planar perovskite solar cells with long-term stability using ionic liquid additives. Nature 571, 245–250. 

   48. Santbergen, R., Mishima, R., Meguro, T., Hino, M., Uzu, H., Blanker, J., Yamamoto, K., and Zeman, M. (2016). Minimizing optical losses in monolithic perovskite/c-Si tandem solar cells with a flat top cell. Opt. Express 24, A1288– A1299. 

40. Lin, Y.-H., Sakai, N., Da, P., Wu, J., Sansom, H.C., Ramadan, A.J., Mahesh, S., Liu, J., Oliver, R.D.J., Lim, J., et al. (2020). A piperidinium salt stabilizes efficient metal-halide perovskite solar cells. Science 369, 96–102. 

41. Ugur, E., Alarousu, E., Khan, J.I., Vlk, A., Aydin, E., De Bastiani, M., Balawi, A.H., Gonzalez Lopez, S.P., Ledinsky´, M., De Wolf, S., and Laquai, F. (2020). How humidity and light exposure change the photophysics of metal halide perovskite solar cells. Sol. RRL 4, 2000382. 

   49. Caprioglio, P., Caicedo-Da´vila, S., Yang, T.C.-J., Wolff, C.M., Pen˜ a-Camargo, F., Fiala, P., Rech, B., Ballif, C., Abou-Ras, D., Stolterfoht, M., et al. (2021). Nano-emitting heterostructures violate optical reciprocity and enable efficient photoluminescence in halidesegregated methylammonium-free wide bandgap perovskites. ACS Energy Lett 6, 419–428. 

42. Belisle, R.A., Bush, K.A., Bertoluzzi, L., GoldParker, A., Toney, M.F., and McGehee, M.D. (2018). Impact of surfaces on photoinduced halide segregation in mixed-halide perovskites. ACS Energy Lett 3, 2694–2700. 

   50. Zhao, J., Deng, Y., Wei, H., Zheng, X., Yu, Z., Shao, Y., Shield, J.E., and Huang, J. (2017). Strained hybrid perovskite thin films and their impact on the intrinsic stability of perovskite solar cells. Sci. Adv. 3, eaao5616. 

43. Eames, C., Frost, J.M., Barnes, P.R., O’Regan, B.C., Walsh, A., and Islam, M.S. (2015). Ionic transport in hybrid lead iodide perovskite solar cells. Nat. Commun. 6, 7497. 

   51. Kresse, G., and Furthmu¨ ller, J. (1996). Efficient iterative schemes for ab initio total-energy calculations using a plane-wave basis set. Phys. Rev. B Condens. Matter 54, 11169– 11186. 

44. Yuan, Y., and Huang, J. (2016). Ion migration in organometal trihalide perovskite and its impact on photovoltaic efficiency and stability. Acc. Chem. Res. 49, 286–293. 

45. Jana, S., Kumar Trivedi, M., and Branton, A. (2015). Physical and structural characterization of Biofield energy treated carbazole. Pharm. Anal. Acta 6, 1000435. 

52. Kresse, G., and Joubert, D. (1999). From ultrasoft pseudopotentials to the projector augmented-wave method. Phys. Rev. B 59, 1758–1775. 

3186 Joule 5, 3169–3186, December 15, 2021 

