# A crystal capping layer for formation of black-phase FAPbI3 perovskite in humid air

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Science |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 182 |
| 作者 | Yu Zou, Wen-Jin Yu, Hao-Qing Guo, Qi-Zhi Li, Xiangdong Li, Liang Li, Yueli Liu, Hantao Wang et al. |
| DOI | 10.1126/science.adn9646 |
| 源文件 | 060_Zou_2024_A-crystal-capping-layer-for-formation-of-black-p.pdf |

---
RESEARCH 

◥ 



solvent system in state-of-the-art PSCs, an indepth investigation is warranted to assess and enhance the applicability of cosolvents under similar high-humidity conditions. 



## <mark>RESEARCH ARTICLE</mark> 

#### SOLAR CELLS 

In this study, we used multiple spectroscopic characterization techniques to understand the influence of DMSO-based complexes on perovskite crystallization in humid air. The hygroscopic nature of DMSO negatively affected ambient processing, in that the formation of a-FAPbI3 perovskites at room temperature was only observed in the absence of DMSO molecules, in stark contrast to the solution process in inert environments (36). To minimize water intrusion and regulate crystal growth, we implemented an in situ–formed capping layer (CL) using chlorine-containing organic molecules. This approach preserved the benefits of DMSO-PbI2 coordination even at an RH of up to 80% and resulted in reproducible PSCs with improved ambient stability. 

# A crystal capping layer for formation of black-phase FAPbI3 perovskite in humid air 

Yu Zou<sup>1</sup> †, Wenjin Yu<sup>1</sup> †, Haoqing Guo<sup>1</sup> †, Qizhi Li<sup>2</sup> †, Xiangdong Li<sup>1</sup> , Liang Li<sup>3</sup> , Yueli Liu<sup>1</sup> , Hantao Wang<sup>1</sup> , Zhenyu Tang<sup>1</sup> , Shuang Yang<sup>1</sup> , Yanrun Chen<sup>3</sup> , Bo Qu<sup>1</sup> *, Yunan Gao<sup>1</sup> , Zhijian Chen<sup>1</sup> , Shufeng Wang<sup>1</sup> , Dongdong Zhang<sup>4</sup> , Yihua Chen<sup>5</sup> , Qi Chen<sup>5</sup> , Shaik M. Zakeeruddin<sup>6</sup> , Yingying Peng<sup>2</sup> , Huanping Zhou<sup>3</sup> , Qihuang Gong<sup>1</sup> , Mingyang Wei<sup>6</sup> *, Michael Grätzel<sup>6</sup> *, Lixin Xiao<sup>1,7</sup> * 

Black-phase formamidinium lead iodide (a-FAPbI3) perovskites are the desired phase for photovoltaic applications, but water can trigger formation of photoinactive impurity phases such as d-FAPbI3. We show that the classic solvent system for perovskite fabrication exacerbates this reproducibility challenge. The conventional coordinative solvent dimethyl sulfoxide (DMSO) promoted d-FAPbI3 formation under high relative humidity (RH) conditions because of its hygroscopic nature. We introduced chlorine-containing organic molecules to form a capping layer that blocked moisture penetration while preserving DMSO-based complexes to regulate crystal growth. We report power conversion efficiencies of >24.5% for perovskite solar cells fabricated across an RH range of 20 to 60%, and 23.4% at 80% RH. The unencapsulated device retained 96% of its initial performance in air (with 40 to 60% RH) after 500-hour maximum power point operation. 

#### Intermediate films in humid air 

We focused on the two-step solution-deposition process (Fig. 1A) to analyze the evolution of the DMSO-PbI2 complexes (D-complexes) and their impact on the subsequent perovskite formation in air (with an RH of ~60% at 25°C). Compared with the one-step process, the two-step process distinguishes D-complex formation from reactions with ammonium halides (8, 12). Following the reported procedure, we fabricated PbI2 intermediate films using conventional DMF and DMSO mixed solvents in the first step (2, 37, 38). Thermal annealing at 70°C removed the volatile DMF and partially evaporated DMSO to yield a film consisting of PbI2 and D-complexes. We varied the annealing duration from 0 to 300 s to control the content of the D-complexes. The intermediates were then converted into perovskite phases through the deposition of FAI, followed by thermal annealing at 150°C for 15 min. 

erovskite solar cells (PSCs) based on black-phase formamidinium lead iodides (a-FAPbI3), which have an optimal bandgap of 1.5 eV, have achieved an impresP sive power conversion efficiency (PCE) 

tive d-phase (8, 13–15). However, this process is often limited to fabrication in an inert gas or dry air atmosphere with strictly controlled relative humidity (RH) (16–22). The reproducibility and stability of unsealed a-FAPbI3 PSCs under high-humidity ambient conditions (with RH >60%) remain challenging. 

sive power conversion efficiency (PCE) of 26.1% (1). Solvent engineering has proven crucial for achieving high-quality a-FAPbI3 perovskite films (2–12). To date, most solutionprocessing methods have used a cosolvent system containing volatile solvents such as dimethylformamide (DMF) and acetonitrile (2–4) and high-boiling-point solvents such as dimethyl sulfoxide (DMSO) and N-methyl-2pyrrolidone (NMP) (5–9) that coordinate with lead iodide (PbI2). The nonvolatile solvent molecules form key intermediate complexes, such as DMSO-PbI2 and NMP-PbI2-FAI (formamidinium iodide), through Lewis acid–base interactions (10–12). These intermediates promote orderly and homogeneous crystallization that facilitates the direct conversion to a-FAPbI3 and prevents the formation of the photoinac- 

Water adsorption triggers incomplete conversion from the intermediate complexes to perovskites and accelerates a-FAPbI3 to d-phase transformation (23–27). To improve the reproducibility of PSCs, several strategies have been devised to reduce the adverse effects of moisture during solution processing. For example, preheating the substrate and precursor solution can create a localized low-RH environment (28, 29). The use of antisolvents and nonhalide lead sources can protect the intermediate complexes from excess moisture penetration (30, 31). Water adsorption has also been shown to be highly dependent on FAPbI3 crystal facets (23). Very recently, Yan et al. postulated that perovskite hydration primarily occurred at surface vacancies (32). The addition of guanabenz acetate salt was found to minimize vacancy formation and thus reduce water adsorption, leading to efficient PSCs produced under ambient conditions. 

Scanning electron microscopy (SEM) images (Fig. 1B and fig. S1) showed that after 60-s thermal annealing (a condition widely used) (37), the PbI2 intermediate film exhibited uniform and compact structures, with an average domain size of ~150 nm as analyzed from topview SEM images (fig. S1). When we extended the annealing time to 300 s, an inhomogeneous skeleton with disordered, large-sized domains (averaging 310 nm) formed (Fig. 1B and fig. S1). We attributed this change to excessive DMSO evaporation—given the smaller d-spacing of PbI2 compared with complexes, which led to a collapsed structure with reduced film thicknesses (from 620 nm down to 420 nm) (12). 

> 1State Key Laboratory for Artificial Microstructure and Mesoscopic Physics, School of Physics, Peking University, Beijing 100871, P. R. China.<sup>2</sup> International Center for Quantum Materials, School of Physics, Peking University, Beijing 100871, P. R. China.<sup>3</sup> School of Materials Science and Engineering, Peking University, Beijing 100871, P. R. China. 

> 4Key Laboratory of Organic Optoelectronics and Molecular Engineering of Ministry of Education, Department of Chemistry, Tsinghua University, Beijing 100084, P. R. China. 

> 5Experimental Center of Advanced Materials, School of Materials Science and Engineering, Beijing Institute of Technology, Beijing 100081, P. R. China.<sup>6</sup> Laboratory of Photonics and Interfaces, Ecole Polytechnique Fédérale de Lausanne, 1015 Lausanne, Switzerland.<sup>7</sup> Beijing Huairou Laboratory, Beijing 101400, P. R. China. 

Nevertheless, despite solvents having an important role in crystallization, their impact on ambient processing has often been overlooked. Yet most coordinating solvents are hygroscopic, which might induce the formation of hydrated compounds (33). Ionic liquids have been used to form the black FAPbI3 phase under highhumidity ambient conditions that leverages their strong interactions with PbI2 (34, 35). However, given the extensive usage of the co- 

We quantitatively monitored the DMSO evaporation during the annealing with x-ray diffraction (XRD), proton nuclear magnetic resonance (<sup>1</sup> H NMR), and grazing-incidence wide-angle x-ray scattering (GIWAXS) measurements. The XRD analysis revealed that 

*Corresponding author. Email: bqu@pku.edu.cn (B.Q.); mingyang.wei@epfl.ch (M.W.); michael.graetzel@epfl.ch (M.G.); lxxiao@pku.edu.cn (L.X.) †These authors contributed equally to this work. 

1 of 7 

Zou et al., Science 385, 161–167 (2024) 12 July 2024 

RESEARCH | RESEARCH ARTICLE 





<!-- Start of picture text -->
A B C<br>DMSO escape 16<br>60 seconds 3000<br>14<br>FAI insert PbI2<br>1 m 12<br>300 seconds<br>10<br>Intermolecular exchange 8 D-complex<br>1 m 40<br>DMSO FAI PbI2 6<br>0 100 200 300<br>Annealing time (s)<br>D E F #: DMSO adduct -FAPbI3 *: PbI2<br>1.0 Intermediate 1.0 1.0 Intermediate4° 60 s * (001)annealed(111) (002)<br>0.8 XRD peak area 0.8 0.8 1° 1/2<br>0.6 Residual DMSO by NMR 0.6 0.6 0.5° ## # w/o annealing 1 m<br>0.4 0.4 0.4 Incidence angle 300 s<br>annealed<br>0.2 (011)<br>0.2 0.2<br>0.0 w/o annealing 1 m<br>0.0 0.0<br>0 60 120 180 240 300 0 60 120 180 240 300 5 10 15 20 25 30<br>Annealing time (s) Annealing time (s) 2 (°)<br>G H<br>60-second<br>80 Intermediate annealing + FAI PbI2<br>DMSO<br>70<br>H2O<br>60 s<br>60<br>FAI<br>Moisture absorption<br>300 s<br>50 -FAPbI3<br>+ FAI<br>40<br>-FAPbI3<br>300-second<br>30 0 2 4 6 8 annealing hard to insert DMSO-H2O<br>Contact time (s) Intermediate Perovskite w/o annealing<br>(°)<br>2<br>Intensity (a.u.)<br>Intensity (a.u.)<br>XRD peak area (Norm.) Residual DMSO (Norm.)<br>GIWAXS peak area (Norm.)<br> (°)Contact angle<br><!-- End of picture text -->

films before and after annealing based on intermediate films with 60 s (top) and 300 s (bottom) of annealing. The signal of unannealed perovskites based on the 60-s-annealed intermediate is displayed after multiplying by one-half. (Inset) Top-view SEM images of annealed perovskites. (G) DCA measurements of intermediate films with 60 and 300 s of annealing as a function of contact time. (Inset) Contact angle images at the contact time indicated by the arrows. (H) Schematic of the transformation process of the intermediate and perovskite films in humid air. 

Fig. 1. Dynamic transformation of intermediate films in humid air. (A) Schematic of the intermolecular exchange between FAI and D-complexes in the two-step solution-deposition process. (B) Cross-sectional SEM images of the intermediate films after 60 and 300 s of annealing. (C and D) Evolution of XRD signals (C) and XRD peak area and content of residual DMSO measured by<sup>1</sup> H NMR (D) during annealing of intermediate films. a.u., arbitrary units. (E) GIWAXS peak area evolution of intermediates (at 0, 60, and 300 s of annealing) at incidence angles of 0.5°, 1°, and 4°. (F) XRD patterns of perovskite 

To correlate the evaporation of DMSO with the crystal quality of perovskite films, we selected two representative intermediate films, one subjected to thermal annealing of 60 s (control) and the other to 300 s (prolonged) for the perovskite conversion. Top-view SEM images (Fig. 1F and fig. S6) revealed that, despite the uniform structure and abundant D-complexes in the control intermediate film, the resultant perovskite film exhibited a smaller average domain size (550 nm versus 680 nm) than that derived from the prolonged intermediate film (see supplementary text 2 in the supplementary materials). Atomic force microscopy (AFM) indicated rougher surface 

morphologies for the control perovskite film (fig. S7). XRD results (Fig. 1F) further indicated altered crystallization pathways from different intermediates. After the solution processing of FAI, the control film converted solely to the photoinactive d-FAPbI3, along with intermediate adducts (7, 42), whereas both a- and d-FAPbI3 were observed in the prolonged intermediate film. Although subsequent thermal annealing enhanced the formation of a-FAPbI3, this transformation was incomplete and disordered, as evidenced by the coexistence of (001) and (111) diffraction peaks as well as strong signals of PbI2 residues in the final film. Combining these results, we 

the D-complex phase (corresponding to the diffraction peak at 9.7°) underwent a continuous transition to crystalline PbI2 (at 12.6°) and was undetectable after an annealing period of 180 s (Fig. 1, C and D) (12, 39). The escape of DMSO was further confirmed by<sup>1</sup> H NMR measurement (Fig. 1D and fig. S2), albeit with residual DMSO molecules remaining under prolonged annealing (>180 s) (40, 41). GIWAXS measurements (at incidence angles of 0.5°, 1°, and 4°) indicated that the loss of D-complexes occurred at similar rates across different film depths, suggesting an unrestricted release of DMSO from the entire film (Fig. 1E, figs. S3 to S5, and table S1). 

2 of 7 

Zou et al., Science 385, 161–167 (2024) 12 July 2024 

RESEARCH | RESEARCH ARTICLE 





<!-- Start of picture text -->
A B C D<br>16<br>60 seconds 1.0 1540<br>0.8 S - -60 s 14 PbI2<br>1  m 0.6 S - -300 s 12<br>CL thickening<br>300 seconds 0.4 10<br>C6--60 s<br>0.2 C6--300 s 8 D-complex<br>1  m 0.0 40<br>6<br>TTM-7BCz 0 20 40 60 80 100 0 100 200 300<br>Sputter time (s) Annealing time (s)<br>E F G 110 H #: DMSO adduct -FAPbI3 *: PbI2<br>1.0 Target intermediate 1.0 1.0 Target intermediate Target intermediate 60 s (001) (111) (002)<br>0.80.6 XRD peak areaResidual DMSO by NMR 0.80.6 0.80.6 4°1°0.5° 10090 300 s ## # * w/o annealingannealed 1  m<br>0.4 80 60 s 300 s<br>0.4 0.4<br>1/10<br>0.2 70<br>0.2 0.2 annealed<br>0.0 0.0 0.0 60 w/o annealing 1  m<br>0 60 120 180 240 300 600 0 60 120 180 240 300 0 2 4 6 8 5 10 15 20 25 30<br>Annealing time (s) Annealing time (s) Contact time (s) 2 (°)<br>I J K<br>Blocked moisture intrusion<br>Target perovskite 0.5° Pristine perovskite 0.5°<br>1° 1°<br>2° 2°<br>3° 3° Capping layer<br>4° 4°<br>Blocked DMSO evaporation<br>PbI2 DMSO<br>0 30 60 90 120 150 0 30 60 90 120 150 180 TTM-7BCz H2O<br>Azimuth (°) Azimuth (°)<br>(°)<br>2<br>Intensity (a.u.)<br>Intensity (Norm.)<br>Contact angle (°) Intensity (a.u.)<br>XRD peak area (Norm.) Residual DMSO (Norm.)<br>GIWAXS peak area (Norm.)<br>Intensity (a.u.) Intensity (a.u.)<br>… … …<br><!-- End of picture text -->

Fig. 2. Intermediate films with an in situ–formed capping layer. (A) Chemical structure of TTM-7BCz additive. (B) Cross-sectional SEM images of the target intermediates with TTM-7BCz after 60 and 300 s of annealing. (C) TOF-SIMS profiles of target intermediates. (D and E) Evolution of XRD signals (D) and XRD peak area and content of residual DMSO measured by<sup>1</sup> H NMR (E) during annealing of intermediate films. (F) GIWAXS peak area evolution at incidence angles of 0.5°, 1°, and 4°. (G) DCA measurements of target intermediates as a function of contact time. (Inset) Contact angle images at the contact time 

indicated by the arrows. (H) XRD patterns of target perovskites before and after annealing based on different intermediates. The signal of annealed perovskites based on the 300-s-annealed target intermediate is displayed after multiplying by one-tenth. (Inset) Top-view SEM images of annealed perovskites. (I and J) Integrated GIWAXS intensity plots azimuthally along the diffraction ring at q = 0.99 Å<sup>−1</sup> , assigned to the (001) plane of target (I) and pristine (J) perovskites. (K) Schematic of the structure and function of intermediate films with an in situ–formed CL. 

time. We further assessed the water content in different intermediates using<sup>1</sup> H NMR, confirming that reducing DMSO content minimizes water absorption (fig. S9). Water molecules lower the formation barrier and Gibbs free energy of d-FAPbI3 (23). In humid air, DMSO led to adverse intermediate film hydration (Fig. 1H), which outweighed its benefits in facilitating intermolecular exchange, resulting in impurity phase formation and reduced crystal quality. 

lution (Fig. 2A). Cross-sectional SEM revealed that with the addition of TTM-7BCz, the resultant intermediate film had a bilayer structure with a crystal CL appearing on the surface (with thicknesses of 90 and 190 nm for annealing periods of 60 and 300 s, respectively) (Fig. 2B and fig. S1). This CL corresponded to the accumulation of TTM-7BCz near the upper surface of the film, as observed with time-of-flight secondary ion mass spectrometry (TOF-SIMS), whereas DMSO was more abundant deeper within the film (Fig. 2C and fig. S10). GIWAXS measurements (at an incidence angle of 0.5°) showed reduced crystallinity of PbI2 with the TTM-7BCz additive compared with pristine intermediates, with no additional crystalline phases observed (figs. S11 to S13). The CL formation was further evidenced in x-ray photoelectron spectroscopy (XPS). A 0.13-eV downshift in the Pb 4f binding energy was observed with the addition of TTM-7BCz (fig. S14), indicating its interaction with PbI2 (44). In addition, we investigated 

reasoned that under high-RH conditions, the presence of DMSO was detrimental because it steered the crystallization process toward the formation of d-FAPbI3. 

Forcomparison,thetwo-stepsolution-deposition process was performed in a nitrogen (N2) atmosphere (fig. S8). Under these conditions, the presence of DMSO promoted a-FAPbI3 formation through the intermolecular exchange between DMSO and FAI (12), whereas prolonged thermal annealing induced d-FAPbI3 formation owing to the limited intercalation of FAI into crystalline PbI2 (12, 34). From dynamic contact angle (DCA) measurements (Fig. 1G), we attributed the difference between inert and humid air conditions to the hygroscopic properties of intermediate films with varying DMSO content: The control intermediate film had a propensity to absorb water molecules, and the contact angle decreased from 68.8° to 58.3° within the initial 9.3 s. In contrast, the contact angle of the prolonged intermediate film remained constant over 

#### Hydrophobization of intermediate films with a capping layer 

We sought to minimize the hydration of intermediate films, even with D-complexes present, under ambient conditions. Molecular additives with hydrophobic features tend to aggregate on the film surface because of reduced surface energy (43). Reasoning that such a CL could block moisture penetration, we introduced an organic molecule, (4-N-benzo[c]carbazolyl2,6-dichlorophenyl)bis(2,4,6-trichlorophenyl) methyl radical (TTM-7BCz), into the PbI2 so- 

3 of 7 

Zou et al., Science 385, 161–167 (2024) 12 July 2024 

RESEARCH | RESEARCH ARTICLE 



fig. S2). GIWAXS (Fig. 2F and figs. S11 and S12) revealed that within the initial 60 s, DMSO escaped at similar rates throughout the film thickness. The loss of DMSO was reduced compared with that in pristine films, as seen in<sup>1</sup> H NMR and XRD (Figs. 1D and 2E). From 60 to 180 s, the in situ thickening of the CL (as observed in SEM and TOF-SIMS) led to slower DMSO evaporation rates at deeper thicknesses (Fig. 2, B, C, and F, and table S1). No further changes in the content of the D-complexes were observed under prolonged thermal annealing (>180 s), in agreement with XRD and 1H NMR results (Fig. 2, E and F). 

7H-benzo[c]carbazole (7BCz), triphenylmethane (TPM), and (4-N-benzo[c]carbazolyl-2,6-dichlorophenyl)bis(2,4,6-trichlorophenyl)methane (HTTM7BCz). CL formation was observed only for chlorinated additives, which also showed coordination between chlorine atoms and Pb<sup>2+</sup> , indicative of the crucial rule of chlorine substitution in facilitating interactions with PbI2 (fig. S15). 

water molecules. When the CL was thickened through 180-s thermal annealing, the target intermediate film exhibited a higher degree of moisture resistance, as evidenced by a consistent contact angle over time (Fig. 2G), which led to the formation of a-FAPbI3 following the solution processing of FAI (Fig. 2H). It is noted that, for the pristine intermediate film under prolonged thermal annealing, d-FAPbI3 formation dominated despite minimized hydration (Fig. 1, F and G, and fig. S9). Therefore, both the retention of DMSO and suppressed water absorption are crucial for favoring the generation of a-FAPbI3 perovskites. 

The impact of the CL formation on intermediate film structures was then investigated as a function of annealing time. Compared to films without TTM-7BCz (pristine), those with TTM-7BCz (target) exhibited persistent signals of the D-complex phase in XRD, as well as a delayed appearance of PbI2 (Fig. 2D). Analyzing the diffraction peak area of D-complexes (Fig. 2E), we observed a rapid decrease in their content within the initial 60 s of film annealing. This change was followed by a gradual increase in the peak intensity from 60 to 180 s and stabilization of signals with the annealing time up to 600 s. These results suggested that the CL inhibited the loss of D-complexes under prolonged annealing. This finding was confirmed by<sup>1</sup> H NMR measurements (Fig. 2E and 

The resulting a-FAPbI3 perovskite film was (001)-oriented with a near-stoichiometric composition at the surface, an average domain size exceeding 1.7 mm, and minimal microstrain and impurity phases (Fig. 2H and figs. S6 and S16 to S19). In GIWAXS (Fig. 2I and fig. S20), this optimal perovskite film displayed a distinct (001) diffraction peak (at q = 0.99 Å<sup>−1</sup> ) near the 90° azimuthal angle, indicative of consistent crystal orientations (21, 36). Conversely, the pristine perovskite film exhibited a (001) Debye-Scherrer 

DCA measurements (Fig. 2G) revealed that the target intermediate film, when subjected to 60-s thermal annealing, remained hygroscopic despite the surface enrichment of TTM-7BCz and improved hydrophobicity (with an initial contact angle of 83.1°).<sup>1</sup> H NMR measurements confirmed the presence of water absorption (fig. S9). As a result, d-FAPbI3 was still preferentially formed during subsequent FAI deposition (Fig. 2H), similar to the pristine intermediate film, which indicates the adverse effects of 

Fig. 3. Crystallization dynamics during the two-step process. (A) In situ UV-vis absorption spectra evolution over time for pristine and target samples during consecutive stages including intermediate annealing, FAI spincoating, and perovskite annealing. (B) Time evolution of the absorbance at 480 nm during intermediate annealing, revealing the suppressed crystallization of PbI2 and the retention of D-complexes in target intermediates. (C) Time evolution of the absorbance at 735 nm during FAI spin-coating and perovskite annealing, revealing the slower and more orderly perovskite crystallization process of the target sample with CL. The orange dashed area highlights a turning point in the absorbance evolution profile. (D) Film thickness 



<!-- Start of picture text -->
A Intermediate annealing FAI spin-coating Perovskite annealing<br>800 Pristine Pristine Pristine<br>700<br>600 high<br>500 ∆t = 2.6 s<br>400<br>800 Target  Target Target<br>700<br>600 low<br>500<br>∆t = 14.5 s<br>400<br>0 60 120 180 240 300 0 5 10 15 20 25 30 0 5 10 15 20 25 30 35 40<br>Annealing time (s) Spin-coating time (s) Annealing time (s)<br>B C D<br>Drip FAI Transfer to hotplate 1000<br>Pristine at 480 nm 1.2 Spin-coating Annealing<br>760 760 770<br>Target 800<br>770<br>0.8 600<br>Pristine 620<br>Target 400 Collapse Expansion<br>420<br>0.4<br>200 Pristine<br>Target<br>0.0 0<br>0 60 120 180 240 300 0 10 20 30 40 50 60 Intermediate Intermediate Perovskite<br>Time (s) Time (s) -60 s -300 s<br>Wavelength (nm)<br>Absorbance<br>Wavelength (nm)<br>Absorbance (a.u.) Absorbance (a.u.) Film thickness (nm)<br><!-- End of picture text -->

variation throughout the entire two-step solution-deposition process. 

4 of 7 

Zou et al., Science 385, 161–167 (2024) 12 July 2024 

RESEARCH | RESEARCH ARTICLE 



ring with weak orientations at around 38° and 142° azimuthal angles (Fig. 2J and fig. S20), along with an obvious diffraction peak of d-FAPbI3 impurities (18). Grazing incidence x-ray diffraction (GIXRD) measurements indicated that the perovskite conversion occurred from the top-down direction (fig. S21). Meanwhile, the CL region converted into perovskites, accompanied by reduced PbI2 remnants compared with pristine perovskite surfaces (fig. S22). After conversion, TTM-7BCz remained on the perovskite surface, thus reducing the hydration of perovskite films (fig. S23). Combining these findings, we illustrate the function of TTM-7BCz molecules in Fig. 2K. 

To further understand the crystallization dynamics occurring during the two-step process, we performed in situ ultraviolet-visible (UV-vis) absorption spectroscopy (Fig. 3A and fig. S24). The absorption edge of the pristine intermediate film redshifted toward the characteristic absorption of crystalline PbI2 near 525 nm during thermal annealing (45), indicative of the continuous loss of the D-complexes. In contrast, the absorption edge of the target intermediates maintained at the characteristic absorption of the D-complexes (near 450 nm) (Fig. 3B and fig. S25). After the application of the FAI solution onto the 300-s-annealed pris- 

tine intermediates, rapid nucleation and initial crystal growth were observed, as evidenced by the absorption shift toward ∼800 nm (i.e., the characteristic absorption edge of a-FAPbI3) within 2.5 s (Fig. 3, A and C). In contrast, the absorption of the target film underwent a redshift toward 600 nm within 30 s, indicative of the retention of adducts and partial intermolecular exchange process (42, 46). Perovskite crystallization was slower for the target film during the subsequent thermal annealing; the transition to a-FAPbI3 was completed at 14.5 s, as opposed to 2.6 s for the pristine film (Fig.3,AandC)(18, 36).Thiscontrolledandorderly crystallization process was also reflected by the minimal thickness variation of the entire film during the two-step solution-deposition process, attributed to DMSO retention and TTM7BCz interaction (Fig. 3D and fig. S26) (12). 

Photophysical properties of perovskite films We evaluated the optoelectronic properties of the resultant perovskite films. The target perovskite films exhibited a sevenfold enhancement in the intensity of steady-state photoluminescence (PL) with a redshifted PL peak (809 versus 803 nm) compared with the pristine films (Fig. 4A), indicative of reduced nonradiative recombination (37). Time-resolved 

PL (TRPL) decay revealed a prolonged PL lifetime of 6120 ns in the target film, which was nearly an order of magnitude longer than that of the pristine film (∼640 ns) (Fig. 4B). In addition, the target films exhibited a lower trap density (4.5 × 10<sup>15</sup> cm<sup>−3</sup> versus 10.0 × 10<sup>15</sup> cm<sup>−3</sup> ) and enhanced carrier mobility (1.0 × 10<sup>−2</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> versus 2.6 × 10<sup>−3</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ), as determined by the space-charge-limited current (SCLC) measurements (fig. S27). 

Kelvin probe force microscopy (KPFM) and ultraviolet photoelectron spectroscopy (UPS) were used to investigate the electronic structure of perovskite surfaces. Compared to the pristine film, there was an increase of 140 meV in the work function (WF) of the target film, accompanied by a more uniform WF distribution that may have been caused by a more homogeneous surface morphology and the presence of holeselective TTM-7BCz (Fig. 4C and fig. S28). UPS measurements confirmed the WF increase from 4.78 eV for the pristine film to 4.95 eV for the target film (fig. S16D). The valence band maximum (VBM) was determined to be 5.82 eV for the pristine and 5.68 eV for the target films, respectively. A graded heterojunction was expected for the target film, which was confirmed through sputtering UPS measurements (Fig. 4D and fig. S29A). This can reduce the VBM offset 

Fig. 4. Photophysical properties of perovskite films. (A and B) Steady-state PL spectra (A) and TRPL (B) of pristine and target perovskite films. (C) KPFM images, root-mean-square surface roughness (Rq), and work function distributions of pristine and target perovskite films. Scale bars, 1 mm. (D) Energy band diagrams of target perovskite with CL, illustrating the formation of a graded heterojunction. VBM, CBM, WF, and Evac represent the valence band maximum, conduction band minimum, work function, and vacuum energy level, respectively. The electronic structures of the bulk of perovskites were determined using sputtering UPS measurements. 



<!-- Start of picture text -->
A B<br>10 0<br>Pristine 809<br>Target<br>10 -1<br>10 -2 Pristine<br>Target<br>803<br>10 -3<br>700 750 800 850 900 0 5 10 15 20<br>Wavelength (nm) Time (μs)<br>C D<br>45<br>Pristine Pristine<br>40<br>E VAC ∆ = 0.17 eV<br>4.815 Target 35 HTL<br>Perovskite WF<br>30 4.95 eV<br>WF<br> Pristine<br>4.78 eV<br> Target<br>CBM Interface<br>Target<br>Extra field<br>Bulk 5.22 eV<br>5.68 eV<br>4.675<br>VBM 5.78 eV<br>4.6 4.7 4.8 4.9<br>Work function (eV)<br>PL intensity (a.u.)<br>PL intensity (Norm.)<br> (nm)Rq<br>Work function (eV)<br>Pixel (a.u.)<br><!-- End of picture text -->

5 of 7 

Zou et al., Science 385, 161–167 (2024) 12 July 2024 

RESEARCH | RESEARCH ARTICLE 



versus 25.2 mA cm<sup>−2</sup> ) (Fig. 5C). Meanwhile, the stabilized power output (SPO) of 24.5 mW cm<sup>−2</sup> at the maximum power point (MPP) aligned with the PCE from the current density–voltage (J-V) curve (fig. S31). 

in Fig. 5A. When fabricated under ambient conditions with an RH of 20%, the PCE of the champion target device improved from 22.1% to 24.7%, with the open-circuit voltage (VOC) rising from 1.113 V to 1.179 V and the fill factor (FF) from 79.8% to 82.9%, relative to the pristine device, under the reverse current-voltage sweep (Fig. 5B and table S2). The corresponding PCEs under the forward scan were 24.6% for the target device and 21.3% for the pristine device, respectively. The VOC dependence on illumination intensity suggested reduced nonradiative recombination in the target PSCs (fig. S30). The current density (JSC) calculated from the external quantum efficiency (EQE) measurements matched closely with the JSC obtained under AM1.5G illumination (25.0 mA cm<sup>−2</sup> 

between the perovskite and the hole-transporting layer (HTL) and provide an enhanced electric field to facilitate hole extraction (47, 48). TRPL of the perovskite/tetrakis[N,N-di(4-methoxyphenyl) amino]-9,9′-spiro-bifluorene (Spiro-OMeTAD) bilayer showed a faster PL decay within the initial few nanoseconds with the addition of TTM-7BCz (fig. S29B). Conversely, HTTM-7BCz induced an n-type behavior of the perovskite surface, which impeded the hole transfer (fig. S29, B to D). 

Reproducible PSCs under varying highhumidity ambient conditions are a prerequisite for their commercialization (49). We observed that the conventional two-step process is highly sensitive to humidity levels: The average PCE decreased from 20.4% to 15.1% as the RH increased from 20% to 60%, accompanied by broader performance distributions (Fig. 5D and table S3). No photovoltaic performance was observed when the RH reached around 80%, because of the inability to form the photoactive a-phase (fig. S32). Although prolonged 

#### Solar cell reproducibility and stability 

We fabricated PSCs with the n-i-p configuration of indium tin oxide (ITO)/SnO2/FAPbI3/ Spiro-OMeTAD/Au. The cross-sectional SEM images of the complete PSC devices are shown 



<!-- Start of picture text -->
A D<br> Pristine-60 s   Target-60 s   Pristine-300 s   Target-300 s<br>24<br>20<br>Pristine 1 μm 16<br>12<br>8<br>4<br>Target 1 μm ~20% RH ~40% RH ~60% RH ~80% RH<br>0<br>non-photoactive<br>B E<br>1.0<br>25<br>0.8<br>20<br>15 0.6 Target, PCEinitial = 24.2% Target,  91.8%,  T  = 8262 hours<br>Pristine, PCEinitial = 22.0%  Pristine, 41.5%,  T  = 4128 hours<br>10 0.4<br>Pristine-reverse ISOS-D-1 protocol<br>Pristine-forward Unencapsulated, ambient atmosphere<br>5 Target-reverse 0.2<br>~20°C ~25°C ~30°C ~25°C<br>Target-forward<br>10-30% RH 30-50% RH 60-80% RH 30-50% RH<br>0 0.0<br>0.0 0.2 0.4 0.6 0.8 1.0 1.2 0 1000 2000 3000 4000 5000 6000 7000 8000 9000<br>Voltage (V) Time (hour)<br>C 100 F<br>25 1.0<br>80 20 0.8 Target,  95.8%,  T  = 500 hours<br>Pristine, 57.4%,  T  = 250 hours<br>60 15 0.6<br>40 10 0.4 Target, PCEinitial = 24.3%<br>Pristine, PCEinitial = 21.7% ISOS-L-1 protocol<br>20   Pristine 5 0.2 Unencapsulated<br>  Target ~50°C, 40-60% RH<br>0 0 0.0<br>300 400 500 600 700 800 900 0 100 200 300 400 500<br>Wavelength (nm) Time (hour)<br>PCE (%)<br>PCE (Norm.)<br>-2Current density (mA cm)<br>EQE (%)<br>PCE (Norm.)<br>-2 (mA cm)Integrated  J SC<br><!-- End of picture text -->

and target (eight devices) PSCs stored under varying ambient conditions. Data are presented as mean values ± standard deviation. (F) Operational stability of pristine and target devices; the unencapsulated devices were assessed under continuous 1-sun-equivalent illumination at the MPP in an ambient atmosphere (40 to 60% RH, ~50°C device temperature). T refers to the aging time of different devices. 

Fig. 5. Performance, reproducibility, and stability of PSCs with the CL strategy. (A) Cross-sectional SEM images of the complete PSCs. (B) J-V curves of champion pristine and target devices. (C) EQE curves of the pristine and target devices. (D) PCE for pristine and target devices based on 60- and 300-sannealed intermediates, respectively, under varying RH at 25°C (15 devices for each condition). (E) Long-term stability of unencapsulated pristine (six devices) 

6 of 7 

Zou et al., Science 385, 161–167 (2024) 12 July 2024 

RESEARCH | RESEARCH ARTICLE 



stability against heating (fig. S39, C and D). Operational stability (Fig. 5F and fig. S41) of the unencapsulated devices was assessed under continuous 1-sun-equivalent white LED illumination at MPP in air (with ∼40 to 60% RH) without cooling (∼50°C device temperature). The PCE of the pristine device degraded to 57.4% of the initial value (21.7%) within 250 hours. In contrast, the target device (with an initial PCE of 24.3%) showed a relative 4.2% reduction in performance after 500 hours of testing, demonstrating high operating stability. In addition, we conducted ISOS-L-2I operating stability tests at 85°C for three target devices (fig. S42). The best device achieved a T90 (time to retain 90% of the initial PCE) of 500 hours. The operating stability under accelerated aging conditions was attributed to both the phase stability and morphological homogeneity of the perovskite films, as evidenced by XRD, GIWAXS, PL, and lightbeaminducedcurrent(LBIC) measurements, respectively (figs. S19, S22, and S39, C to F). 

thermal annealing (300 s) of intermediate films removed hygroscopic DMSO, thus allowing for a-FAPbI3 formation at 80% RH, the average PCE was limited to 11.6%. A further reduction in the average PCE was observed when the annealing duration of pristine intermediates was extended to 600 s, owing to the higher crystallinity of PbI2 (fig. S33). 





17. J. J. Yoo et al., Nature 590, 587–593 (2021). 

18. J. Jeong et al., Nature 592, 381–385 (2021). 

19. C. Liu et al., Science 382, 810–815 (2023). 

20. S. M. Park et al., Science 381, 209–215 (2023). 

21. D. P. McMeekin et al., Nat. Mater. 22, 73–83 (2023). 

22. J. Park et al., Nature 616, 724–730 (2023). 

23. C. Ma et al., Science 379, 173–178 (2023). 

24. D. Barrit et al., Adv. Funct. Mater. 30, 1907442 (2020). 

25. A. Binek, F. C. Hanusch, P. Docampo, T. Bein, J. Phys. Chem. Lett. 6, 1249–1253 (2015). 

26. K. Ho, M. Wei, E. H. Sargent, G. C. Walker, ACS Energy Lett. 6, 934–940 (2021). 

In comparison, the CL strategy improved the reproducibility of PSCs across a wide range of RH at 25°C (Fig. 5D and table S3): The target devices achieved PCEs of >24.5% across RH from 20 to 60% and reached a PCE of 23.4% at 80% RH, which we ascribed to the suppressed hydration of the intermediate film combined with the preservation of D-complexes that improved crystallization. As a result, the device performance was retained even when we increased the annealing duration of target intermediates to 600 s (fig. S33). Compared to previous studies, the CL strategy demonstrated improved performance consistency for PSCs fabricated under large variations in ambient RH (fig. S34 and table S4) (32, 34, 46). In addition, we fabricated 1-cm<sup>2</sup> -sized PSCs at an RH of 50%, achieving a PCE of 22.4%, and carbon-electrode PSCs that attained a PCE of 18.8%, both showing improvements compared with the pristine devices (fig. S35). The potential for scalability was indicated by the similar performance drop between small and centimeter-scale PSCs across various RH levels (fig. S36 and table S5). The CL strategy was also applied to various perovskite compositions (such as MAPbI3 and FA0.9Cs0.1PbI3) and to the one-step solution-deposition process under highhumidity ambient conditions (figs. S35 and S37). Furthermore, we found that similar chlorinecontaining radicals improved the PCE and reproducibility of PSCs (fig. S38), validating the applicability of the CL strategy. In contrast, the aH precursor, HTTM-7BCz, led to a reduction in PCE because of hole blocking 

27. P. Raval et al., ACS Energy Lett. 7, 1534–1543 (2022). 

28. K. Sveinbjörnsson et al., J. Mater. Chem. A Mater. Energy Sustain. 4, 16536–16545 (2016). 

29. G. Wang et al., Adv. Mater. 34, e2205143 (2022). 

30. K. Jung et al., Nano Energy 89, 106387 (2021). 

31. Z. Wang et al., Adv. Energy Mater. 11, 2102169 (2021). 

32. L. Yan et al., Nat. Energy 8, 1158–1167 (2023). 

33. J. J. Yoo et al., Energy Environ. Sci. 12, 2192–2199 (2019). 

34. W. Hui et al., Science 371, 1359–1364 (2021). 

35. L. Chao et al., Joule 6, 2203–2217 (2022). 

36. P. Shi et al., Nature 620, 323–327 (2023). 

37. Y. Zhao et al., Science 377, 531–534 (2022). 

38. Z. Huang et al., Nature 623, 531–537 (2023). 

39. Y. Jo et al., Adv. Mater. Interfaces 3, 1500768 (2016). 

40. C. Fei et al., Science 380, 823–829 (2023). 

41. S. Chen et al., Science 373, 902–907 (2021). 

42. M. Li et al., Nat. Commun. 14, 573 (2023). 

43. X. Wang et al., Nat. Commun. 14, 2166 (2023). 

44. J. Wu et al., J. Am. Chem. Soc. 145, 5872–5879 (2023). 

#### Discussion 

45. Y. Wu et al., Energy Environ. Sci. 7, 2934–2938 (2014). 46. M. Wang, H. Sun, L. Meng, M. Wang, L. Li, Adv. Mater. 34, 2200041 (2022). 

The DMF-DMSO cosolvent system is the most commonly used for fabricating a-FAPbI3 perovskite, yet it faces reproducibility challenges at RH levels exceeding 60%. Prior strategies primarily aimed at reducing the hydration of the perovskites themselves (32, 34). We show that the hygroscopic nature of DMSO, which facilitates water absorption into intermediate films, promotes the formation of the d-FAPbI3 impurity phase in humid air. Simply eliminating DMSO is not a viable solution because it has a role in controlling crystal growth through intermolecular exchange. We developed a crystal CL strategy using chlorinated p-radicals, which minimizes moisture penetration because of the hydrophobic and homogeneous characteristics of the CL, while preserving DMSO-PbI2 complexes within the intermediate film. We achieved PCEs exceeding 24.5% for PSCs across RH ranges from 20 to 60%, and 23.5% at 80% RH. Moreover, the unencapsulated device exhibited 500-hour operating stability under ambient conditions with 40 to 60% RH during maximum power point operation. 

47. X. Li et al., Science 375, 434–437 (2022). 

48. X. Chu et al., Nat. Energy 8, 372–380 (2023). 

49. Y. Zhang et al., Small Methods 5, e2000744 (2021). 

##### ACKNOWLEDGMENTS 

We thank the NMR facility of the National Center for Protein Sciences at Peking University for assistance with data acquisition and Z. Fan from Peking University for discussions about photophysical properties. Funding: This work was supported by the National Key Research and Development Program of China [grant 2022YFB4200503 (Z.C.)] and by the National Natural Science Foundation of China [61935016 (L.X.), 52173153 (L.X.), 12174013 (Z.C.), and 12074011 (B.Q.)]. M.G. and M.W. acknowledge financial support from the Günes Perovskite Solar Cell Corporation located in Adana, Turkey. Author contributions: Y.Z. conceived of the idea, fabricated all the devices, and conducted all the characterizations except those described below. Y.Z., W.Y., M.W., M.G., and L.X. designed the project. W.Y. and X.L. conducted the SEM measurements. Y.Z., W.Y., L.L., and H.Z. measured in situ UV-vis absorption spectra. H.G. synthesized and characterized additive materials. Q.L. and Y.P. performed GIWAXS measurements and data analysis. Y.Z., Y.L., and Yanrun Chen fabricated and characterized devices for the accelerated aging test. H.W., Z.T., and S.Y. helped with the material characterization. Yihua Chen and Q.C. carried out the accelerated aging test. Y.G., Z.C., S.W., D.Z., and S.M.Z. provided advice and expertise. B.Q., M.W., Q.G., M.G., and L.X. directed and supervised the work. Y.Z., M.W., M.G., and L.X. co-wrote the manuscript. All authors contributed to data analysis and read and commented on the manuscript. Competing interests: A Chinese patent application related to this article was submitted by Peking University (L.X., Y.Z., H.G., Z.C., B.Q., and Y.L.). Data and materials availability: All data are available in the main text or the supplementary materials. License information: Copyright © 2024 the authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original US government works. https://www.science.org/about/sciencelicenses-journal-article-reuse 

(fig. S29E). 

The long-term stability of the unencapsulated PSCs was evaluated under various stress conditions. The target devices maintained 91.8% of the initial average PCE of 24.2% after 8262 hours of storage under varying ambient conditions—benefiting from the surface hydrophobicity introduced by the accumulation of TTM-7BCz (Fig. 5E and figs. S23 and S39, A and B), compared with 41.5% of the initial average 22.0% PCE after 4128 hours for the pristine devices. The thermal stability was measured at 85°C in an N2 atmosphere following the ISOS-D-2I protocol (fig. S40). After 500 hours of thermal aging, the target devices retained 95.6% of their initial PCE (21.0%), whereas the pristine ones only retained 61.3%. XRD analysis revealed that d-FAPbI3 limited the thermal stability of perovskite films (fig. S39C). The enhanced phase purity of target perovskites led to improved structural and PL 

##### REFERENCES AND NOTES 

1. National Renewable Energy Laboratory, Best research-cell efficiency chart, revised 31 September 2023; https://www.nrel. gov/pv/cell-efficiency.html. 

2. J. Burschka et al., Nature 499, 316–319 (2013). 

3. M. Yang et al., Adv. Mater. 27, 6363–6370 (2015). 

4. Y. Deng et al., Sci. Adv. 5, eaax7537 (2019). 

5. X. Li et al., Science 353, 58–62 (2016). 

6. N. Ahn et al., J. Am. Chem. Soc. 137, 8696–8699 (2015). 

##### SUPPLEMENTARY MATERIALS 

7. N. J. Jeon et al., Nat. Mater. 13, 897–903 (2014). 

science.org/doi/10.1126/science.adn9646 Materials and Methods Supplementary Text Figs. S1 to S42 Tables S1 to S5 References (50–65) 

8. T. Bu et al., Science 372, 1327–1332 (2021). 9. T. Bu et al., Nat. Energy 7, 528–536 (2022). 

10. N. Yaghoobi Nia et al., Nano Energy 69, 104441 (2020). 

11. W. Xiang et al., Joule 6, 315–339 (2022). 

12. W. S. Yang et al., Science 348, 1234–1237 (2015). 

13. P. Shi et al., Adv. Sci. (Weinh.) 6, 1901591 (2019). 

14. X. Liu et al., Nat. Rev. Chem. 7, 462–479 (2023). 

Submitted 10 January 2024; accepted 4 June 2024 10.1126/science.adn9646 

15. R. Chen et al., Nat. Energy 8, 839–849 (2023). 16. H. Min et al., Nature 598, 444–450 (2021). 

7 of 7 

Zou et al., Science 385, 161–167 (2024) 12 July 2024 



### **A crystal capping layer for formation of black-phase FAPbI3 perovskite in humid air** 

Yu Zou, Wenjin Yu, Haoqing Guo, Qizhi Li, Xiangdong Li, Liang Li, Yueli Liu, Hantao Wang, Zhenyu Tang, Shuang Yang, Yanrun Chen, Bo Qu, Yunan Gao, Zhijian Chen, Shufeng Wang, Dongdong Zhang, Yihua Chen, Qi Chen, Shaik M. Zakeeruddin, Yingying Peng, Huanping Zhou, Qihuang Gong, Mingyang Wei, Michael Grätzel, and Lixin Xiao 

_Science_ **385** (6705), .  DOI: 10.1126/science.adn9646 

#### **Editor’s summary** 

Growth of the photoactive black phase of formamidinium lead iodide (#-FAPbI3) usually requires dimethyl sulfoxide solvent, but the hygroscopic nature of this chemical also promotes water-induced degradation to the photoinactive phase. Zou _et al_ . showed that a larger chlorinated organic molecule can form a hydrophobic capping layer that enables perovskite crystallization under humid conditions by protecting growing crystallites from water. Solar cells were fabricated across a relative humidity range of 20 to 60% and reached power conversion efficiencies of 23.4% at 80% relative humidity. An unencapsulated device retained 96% of its initial performance in humid air after 500 hours of illumination at maximum power point operation. —Phil Szuromi 

#### **View the article online** 

https://www.science.org/doi/10.1126/science.adn9646 **Permissions** 

https://www.science.org/help/reprints-and-permissions 

Use of this article is subject to the Terms of service 

_Science_ (ISSN 1095-9203) is published by the American Association for the Advancement of Science. 1200 New York Avenue NW, Washington, DC 20005. The title _Science_ is a registered trademark of AAAS. 

Copyright © 2024 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works 

