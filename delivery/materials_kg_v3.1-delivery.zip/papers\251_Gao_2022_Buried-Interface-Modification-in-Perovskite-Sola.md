# Buried Interface Modification in Perovskite Solar Cells: A Materials Perspective

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Advanced Energy Materials |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 226 |
| 作者 | Zhi-Wen Gao, Yong Wang, W. Choy |
| DOI | 10.1002/aenm.202104030 |
| 源文件 | 038_Gao_2022_Buried-Interface-Modification-in-Perovskite-Sola.pdf |

---
**Review** 



**www.advenergymat.de** 

# **Buried Interface Modification in Perovskite Solar Cells: A Materials Perspective** 

_Zhi-Wen Gao, Yong Wang,* and Wallace C. H. Choy*_ 

is approaching the S–Q limit but the opencircuit voltage ( _V_ oc) and fill factor ( _FF_ ) are still far below the theoretical values. As we know, both _V_ oc and _FF_ relate to charge carrier dynamics including extraction and transport. Therefore, carrier managements including reducing non-radiative carrier recombination (bulk and interface), series or shunt resistance, and improving carrier extraction and transport are critical to further enhance the power conversion efficiency (PCE) of PSCs. In addition to high efficiency, the stability issues in perovskite must be solved before commercialization. 

**Organic–inorganic hybrid perovskite solar cells (PSCs) are promising thirdgeneration solar cells. They exhibit high power conversion efficiency (PCE) and, in theory, can be manufactured with less energy than several more established photovoltaic technologies, particularly solution-processed PSCs. Various materials have been widely utilized to modify the buried bottom interface to improve the performance and long-term stability of PSCs. Here, the latest progress in modifying the buried interface to enhance the performance and stability of PSCs is examined from a materials standpoint, which is classified into inorganic salts, the organic molecular and polymer, carbon materials, perovskite-related materials, and 2D materials. This material perspective is useful in determining the tactics for achieving the theoretical PCE value of PSCs. It also serves as a solid reference of interface adjustment for other layered structure heterojunction devices.** 

From the standpoint of architecture of PSCs, the PSCs are essentially a heterojunction device with a multilayer construction, which consists of perovskite light absorption layer, carrier transport layer (CTL), and electrodes.<sup>[25,30]</sup> As a result, the rational design and modification of heterojunction interfaces have become key strategies to harness the full potential of PSCs.<sup>[31–35]</sup> A lack of in-depth understanding of the heterojunction interfaces and appropriate interface designs, specifically the buried interfaces under polycrystalline perovskite films, is impeding further advancements in perovskite photovoltaic performance and stability.<sup>[36–42]</sup> To date, many researches mainly focus on the top surfaces of perovskite.<sup>[43–47]</sup> However, due to the accumulation of deep-level trap states, it is known that unfavorable non-radiative recombination losses that impede device power outputs exist at the interfaces with bottom contact layers.<sup>[41,48]</sup> Consequently, it is urgently needed to compromise between these detrimental effects and beneficial effects. 

## **1. Introduction** 

Metal halide perovskite with excellent photophysical properties has made great achievements in the field of optoelectronics, such as photovoltaic (PV), light-emitting diode (LED), photodetector, laser, etc.<sup>[1–11]</sup> Among these, the state-of-the-art perovskite solar cells (PSCs) with unprecedented certified record efficiency of 25.7% have made great progress ( **Figure 1** a),<sup>[12–24]</sup> which is comparable to current industrial-grade mono-crystalline silicon solar cells.<sup>[24]</sup> This fantastic efficiency together with low-cost and flexible fabrication makes PSCs more attractive than the other efficient photovoltaic technologies.<sup>[25–27]</sup> 

According to Figure 1b, the efficiency of current state-ofthe-art PSCs is only ≈25.7%, which is far below its Shockley– Queisser (S–Q) limit maximum theoretical efficiency (>30%). It means that there is a large space for the efficiency of PSCs.<sup>[28,29]</sup> According to the examination of photovoltaic parameters in relation to the S–Q limit, the short-circuit current density ( _J_ sc) 

However, investigating these issues is more difficult compared with that on the top surfaces of perovskite. There are two kinds of techniques to study the buried interface, which are the in-situ and ex-situ methods. For in-situ method, the sum frequency generation (SFG) vibrational spectroscopy which is a nonlinear interface sensitive spectroscopy is applied to study/ analyze the molecular structure information at the buried interface.<sup>[49,50]</sup> In addition, the photoluminescence spectroscopy (PL) excited from the glass side can characterize carrier dynamics behavior of buried interface.<sup>[51]</sup> For ex-situ strategy, the buried interface will expose with a peeling-off method. Then the common characterization methods can be used to analyze exposed the buried surface of perovskite layer, such as PL, scanning electron microscope (SEM), atomic force microscopy (AFM), and Fourier transform infrared spectroscopy (FTIR).<sup>[52,53]</sup> It is still challenging to find ways to access the buried interfaces to achieve device efficiency limits.<sup>[54]</sup> 

Z.-W. Gao, Y. Wang, W. C. H. Choy Department of Electrical and Electronic Engineering University of Hong Kong Pokfulam Road, Hong Kong, SAR 999077, P. R. China E-mail: chchoy@eee.hku.hk Y. Wang Department of Physics Chemistry and Biology (IFM) Linköping University Linköping 58183, Sweden E-mail: yonwa27@liu.se 

The ORCID identification number(s) for the author(s) of this article can be found under https://doi.org/10.1002/aenm.202104030. 

### **DOI: 10.1002/aenm.202104030** 

**2104030 (1 of 20)** 

_Adv. Energy Mater._ **2022** , _12_ , 2104030 

© 2022 Wiley-VCH GmbH 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 



**Figure 1.** a) Efficiency evolution of perovskite solar cells. b) Comparison of S–Q limitation and current highest efficiency of single-junction PSCs. 

Nowadays, some materials have been developed to tailor the buried interface for both regular and inverted PSCs with preprocessing or post-processing the bottom CTLs.<sup>[19,55–57]</sup> For example, the recent development of buried interface research has made a great breakthrough in the PSCs with the highest certification record.<sup>[23]</sup> 

Different from some early reviews on the top interface engineering in PSCs, we will focus on the latest progress and perspectives of the most challenging and critical buried interface modification on the development of PSCs with a materials perspective, which have a strong potential to be applied to flexible devices, tandem devices, and other optoelectronic devices. We first introduce the critical roles of buried interfaces in the performance and stability of PSCs. We then systematically review the buried interface modification materials undertaken to tune the various properties of buried interface. These materials in the state-of the-art perovskite devices are ranged from inorganic salts, organic materials, carbon (inorganic) materials, perovskite-related materials, and other 2D materials. They are essential for interface defects passivation, interface band alignment, and carrier mobility for promoting charge-carrier extraction and transport, and act as an interfacial layer for better crystal growth and inhibiting interface chemical reactioninduced instability. Finally, according to current buried interface modification results, outlooks, and perspectives on the bottom interface modification toward efficient and stable PSCs are presented. We believe this work can be adopted for the interface modification of other heterojunction devices. 

## **2. Critical Issues Hidden in the Buried Interface** 

### **2.1. Buried Interface Defects Induced Performance and Stability Degradation** 

There are amounts of defects distributed on both sides of the heterojunction (CTL and perovskite) to deteriorate PV performance and decrease stability. These defects generally come from the surface of both charge transport layers and perovskite light absorption layers. For example, the common bottom 

inorganic CTL including electron transport layer (ETL: SnO2, TiO2, ZnO) and hole transport layer (HTL:NiO _x_ ) possesses abundant defects/traps, such as oxygen vaccines, hydroxyl groups, and unsaturated coordinated metal atoms.<sup>[58,59]</sup> Moreover, sub-micro scale extended imperfections, contact-induced reconstruction, and lead-halide inhomogeneities exist at the bottom surface of perovskite.<sup>[52,60,61]</sup> These deep-level trap-state defects will induce interface reaction and non-radiative recombination, resulting in instability issues and serious interface open-circuit voltage losses, which are major roadblocks toward highly efficient PSCs.<sup>[48]</sup> 

The comprehensive results from including density functional theory (DFT) and X-ray photoelectron spectroscopy (XPS) characterization confirm that many surface detects/traps including hydroxyl groups, exist on the surface of tin oxide (SnO2) ETL. These hydroxyl groups on the surface will introduce deep energy trap states in the bandgap to cause non-radiative recombination and result in energy loss.<sup>[62]</sup> Similar defects also exist at the surface of other metal oxides CTLs including ZnO, TiO2, and NiO _x_ . In addition, on the bottom interface between the perovskite and CTLs, the PbI antisite defects would cause localized states near the valence band edge to capture the holes and become non-radiative recombination centers.<sup>[19]</sup> Because of the nature of metal coordination crystals of organic–inorganic hybrid perovskites and metal oxide CTLs, their surface consists of much undercoordinated metal, halogen, and organic ions. These surface reactive atoms are problematic charge trap states and unstable, which are responsible for recombination and stability losses.<sup>[63–66]</sup> 

At a macro level, Huang and co-workers used the peeling technique to gain insight into the morphology of buried perovskite with a porous film full of voids that will accelerate perovskite material degradation under illumination.<sup>[53]</sup> Recently, the same lift-off strategy is developed to expose and uncover the buried interfaces of polycrystalline perovskite films ( **Figure 2** a). The large flaky lead-halide grains are observed from SEM images at the bottom side, which are larger and more than that at the top side, accelerating the annihilation of the photogenerated charge carriers and device efficiency losses through non-radiative recombination (Figure 2b). Nanoscale-resolved 

**2104030 (2 of 20)** 

_Adv. Energy Mater._ **2022** , _12_ , 2104030 

© 2022 Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 2.** a) Schematic of the lift-off process. A: monovalent organic or inorganic cations, B: Pb<sup>2+</sup> , X: halogen anions. b) SEM images of the top (left) and bottom (right) sides of the perovskite films. Scale bar is 500 nm. c) FA<sup>+</sup> spatial distribution of the top (left) and bottom (right) sides obtained from nano-FTIR. Scale bar is 500 nm. Color bar: the normalized intensity of the reflection signals from the sample. d) The statistical distribution of infrared radiation (IR) intensities of both sides, and the collected IR intensities from the white dotted lines in (c). (a), (b), (c), and (d) Reproduced with permission.<sup>[52]</sup> Copyright 2021, John Wiley and Sons. 

Fourier transform infrared (nano-FTIR) microscopy together with confocal photoluminescence (PL) imaging further reveals a more pronounced inhomogeneity for the lateral concentration of the dominant organic cations at the bottom side as compared with the top side (Figure 2c,d).<sup>[52]</sup> These interface defects on the CTL and perovskite side resulted in both PV performance and stability decay can be considerably mitigated by the interface modification, which unlocks the full potential for improving device performance. 

In addition to causing the non-radiative recombination and facilitating the material degradation, the buried interface defects also can induce the interface chemical reaction, which is also critical to the performance and stability of devices. As 

shown in **Figure 3** a, McGehee and co-workers found that the undercoordinated metal cation sites (Ni<sup>≥3+</sup> ) from NiO _x_ HTL can act both as Brønsted proton acceptors and Lewis electron acceptors to deprotonate cationic amines and oxidize iodide species.<sup>[64]</sup> This defective perovskite region not only increases nonradiative recombination at the bottom interface but also serves as a hole extraction barrier to limit the charge carrier mobility and result in _V_ oc loss. These interfacial reactions are similar to the behavior demonstrated on n-type oxide layers, such as TiO2,<sup>[67,68]</sup> SnO2,<sup>[69]</sup> and ZnO.<sup>[70,71]</sup> Schutt et al. revealed that the root reason for ZnO-perovskite intrinsic instability is the deprotonation of the methylammonium cation, which results in the formation of zinc OH bonds and ZnI bonds (Figure 3b).<sup>[72]</sup> 



**Figure 3.** a) Schematic of the addition of excess A-site and I<sup>−</sup> to the perovskite precursor, which titrates reactive sites at the NiO _x_ surface, preventing the formation of PbI2 at the interface. Reproduced with permission.<sup>[64]</sup> Copyright 2020, Elsevier. b) Schematic for ZnO abstracting H<sup>+</sup> from CH3NH3<sup>+</sup> , forming ZnOH<sup>+</sup> ; CH3NH2 evaporates (top) and for the formation of ZnI bonds (bottom). Reproduced with permission.<sup>[72]</sup> Copyright 2019, John Wiley and Sons. 

**2104030 (3 of 20)** 

_Adv. Energy Mater._ **2022** , _12_ , 2104030 

© 2022 Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 4.** a) Schematic band diagrams of band alignment at the contact/perovskite interfaces. Δ _E_ VBM (holes) and Δ _E_ CBM (electrons) present effective band offsets on the contact/perovskite heterojunctions, respectively. Δ1 and Δ2, the interface dipoles. Reproduced with permission.<sup>[35]</sup> Copyright 2021, John Wiley and Sons. b) Energy band diagram in PSCs at open circuit under illumination. (Left) _eV_ oc equals the QFLS in junctions with aligned CTLs, (right) misalignment of HTL enhancing interface recombination, which makes the _EF,h_ bend at the interface to the HTL and causes a _V_ oc reduction compared to the QFLS. Reproduced with permission.<sup>[30]</sup> Copyright 2021, John Wiley and Sons. 

In addition, the surface hydroxyl groups (OH<sup>−</sup> ) of metal oxide CTL will accelerate the degradation of perovskite.<sup>[73,74]</sup> 

### **2.2. Buried Interface Modified Band Alignment and Carrier Dynamics** 

The band alignment at the buried interface is responsible for extraction of hole (inverted p-i-n) and electron (regular n-i-p) carriers for PSCs, in which the interface energy barrier height is known to impact carrier dynamics.<sup>[75]</sup> A > 0.1 eV interface barrier height can block the majority carriers extraction, resulting in charge accumulation and recombination losses.<sup>[76]</sup> Hence, the valence band (VB) or conduction band (CB)/highest occupied molecular orbital (HOMO) or lowest unoccupied molecular orbital (LUMO) of the HTL or ETL, respectively, should be aligned with the corresponding VB or CB of the perovskite absorber to minimize Δ _E_ VBM and Δ _E_ CBM for efficient majority charge extraction ( **Figure 4** a).<sup>[35]</sup> The extraction barrier is proportional to the charge carrier concentration at the interface. The large barrier will result in an undesired accumulation of charge carriers to enhance the recombination of charge carriers. Such undesirable charge accumulation will reduce the collection efficiency at a certain voltage, finally resulting in the reduced quasiFermi level splitting (QFLS), low fill factor ( _FF_ ), _V_ oc, and serious hysteresis (Figure 4b).<sup>[30,76–78]</sup> In general, a large VB/CB offset at the ETL/perovskite or HTL/perovskite interface is desirable to block hole/electron transport. This will help reduce surface recombination at the respective interfaces, thereby obtaining large QFLS, which determines the maximum _V_ oc. 

When predicting energy level alignment, the major complication is the formation of interface dipoles upon electrostatic interactions and charge transfer. Such dipole layers can modify the values of the discussed barriers and be exploited to tune the energy level alignment.<sup>[79,80]</sup> For instance, when phosphonic acid with different molecular dipoles is used to interact with the oxygen vacancies on SnO2, the work function (WF) of SnO2 ETL can be tuned.<sup>[81]</sup> Furthermore, the equilibrium state requires that the electrochemical potential in the dark at 0 V be constant throughout the device. Therefore, to construct the final band diagram, the WFs of the electrodes and (modified) CTLs are essential, as they can introduce a built-in potential and band tilt/bending that can be more or less beneficial for charge collection. The WF of CTLs can be tuned by modifications with 

different materials, which has the second beneficial effect of increasing the conductivity of the CTL itself. In perovskites as mixed ionic-electronic conductors, mobile ionic defects can further influence the electric field in the device. To rationally design efficient and stable PSCs, it is important to understand the charge transfer processes occurring at the perovskite/CTL interfaces. Hence, the alignment between VB maximum or CB minimum as well as relative work function between CTL and perovskite at the buried interface will cause a significant effect for interface carrier extraction and QFLS. 

In addition to carrier extraction, effective carrier transport is also critical to suppress carrier accumulation at the interface, reducing interface non-radiative recombination and hysteresis.<sup>[18,82–84]</sup> Upon the extraction of photogenerated carriers from the perovskite, they should effectively transport through CTL to electrodes. Hence, the carrier (hole and electron) mobility of CTL plays a key role in promoting carrier extraction and transportation, which can effectively inhibit charge accumulation at the CTL/perovskite interface and improve the _J_ sc for PSCs.<sup>[55,85–87]</sup> The conductivity of bottom CTL can be tuned by interface modification, as shown in **Figure 5** . Moreover, based on previous theoretical and experimental studies, the lattice mismatch at the heterojunction interface brings about a large number of defects, and the interstitial and antisite defects affect charge transport at the interface because they induce a high density of trap states.<sup>[19,88]</sup> 

### **2.3. Buried Interface Promoted Crystalline Perovskite Formation** 

The chemical properties and morphology of the substrate have a significant influence on the formation of perovskite atop of it, which in turn affects device performance and stability.<sup>[90]</sup> As the light absorber and origin of photogenerated carriers, a high-quality crystalline perovskite film is crucial to achieving high performance PSCs. High phase purity and crystallinity with uniform and fewer grain boundaries have been proven to significantly enhance the performance and stability of the device.<sup>[91–95]</sup> To obtain high-quality perovskite films, the prerequisite is to reduce the density of defects, which critically depends on the underlying substrates on which the perovskites are crystallized.<sup>[2,96]</sup> Consequently, it is crucial to realize the controllable growth of pinhole-free, continuous perovskite films on substrates with matched energy-level contacts, via 

**2104030 (4 of 20)** 

_Adv. Energy Mater._ **2022** , _12_ , 2104030 

© 2022 Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 5.** a) _I_ – _V_ characteristics of ITO/SnO2/Au, ITO/SnO2-RbF/Au, and ITO/SnO2/RbF/Au, respectively. Reproduced with permission.<sup>[86]</sup> Copyright 2021, John Wiley and Sons. b) Electron mobility measurement of SnO2 and NH4Cl-SnO2 by using the space-charge-limited current (SCLC) model with a device structure of ITO/Ag/ETL/Ag. Reproduced with permission.<sup>[89]</sup> Copyright 2019, John Wiley and Sons. 

solution-processed preparation methods. Typically, it is a considerable challenge in the inverted PSCs due to the poor wettability of organic charge transport layers, such as poly(triaryl amine) (PTAA)<sup>[41]</sup> and polymeric triphenyldiamines (polyTPD).<sup>[97]</sup> To address this issue, tuning the buried interface by inserting the interface buffer layer will improve the wettability of organic films, such as the poly[(9,9-bis(30-((N,N-dimethyl)N-ethylammonium)-propyl)-2,7-fluorene)-alt-2,7-(9,9-dioctylfluorene)] dibromide layer.<sup>[41]</sup> This interface buffer layer has also been shown to provide crystallinity enhancements during the perovskite crystallization, improving perovskite grain sizes and morphologies, resulting in defect reduction in perovskite films.<sup>[73,98–104]</sup> For inorganic metal oxide CTLs, the buried interface layer can help to form high-quality perovskite films.<sup>[55,57]</sup> 



**Figure 6.** a) Without substrate, the perovskite forming at 100 °C contracts vertically and laterally during cooling. b) With the substrate adhesion, the annealed perovskite film only contracts vertically. (a) and (b) reproduced with permission.<sup>[107]</sup> Copyright 2017, American Association for the Advancement of Science. 

In addition, the mismatching coefficient of thermal expansion between the underlying substrate and perovskite can create serious lattice strain in the film.<sup>[105,106]</sup> As shown in **Figure 6** a,b, considering the large and mismatched thermal expansion between the halide perovskite and glass/indium tin oxide (ITO) substrate, the strain will generate in the perovskite films during cooling process.<sup>[107]</sup> When perovskite cools from high temperature (>100 °C) to room temperature, it tends to contract due to the positive thermal expansion coefficient. When a perovskite film is deposited on a substrate with a much smaller thermal expansion coefficient, the perovskite in contact with the substrate cannot then contract, resulting in tensile strain along the in-plane direction. To compensate for the reduced lateral shrinkage upon cooling, the film shrinks more in the out-ofplane direction, resulting in compressive strain in this direction. The resultant strain will cause non-radiative recombination losses and carrier transport, hurting device performance and stability.<sup>[106–109]</sup> 

## **3. Inorganic Salts as Efficient Interface Modification Materials** 

Inorganic salts are simple and effective interface passivation materials to modify the interface and passivate the buried interface, which has been widely applied in both regular and inverse PSCs. In particular, the ions of inorganic salts have significant effects on the buried interface between inorganic CTLs (NiO _x_ , SnO2, TiO2, ZnO) and the perovskite layer. 

In 2017, Tan et al. discovered that, in the cases of MAX<sup>−</sup> and PbX<sup>2−</sup> terminated (MA = CH3NH3, X = Cl, I) perovskite surfaces, the addition chlorine (Cl) ions at the interface can strongly bind with the undercoordinated site at the TiO2/perovskite interface to reduce the density of interfacial trap states ( **Figure 7** a).<sup>[19]</sup> A similar effect is then confirmed by the followup research work of Pang and co-workers.<sup>[110]</sup> Gao et al. found that chlorine could effectively fill the oxygen vacancy defects of ZnO, suppressing charge recombination and facilitating charge transport at the ZnO/perovskite interface, thus enhancing PCE with suppressed hysteresis. Meanwhile, chlorination of ZnO surface can protect the perovskite layer from decomposition, boosting device stability.<sup>[111]</sup> 

**2104030 (5 of 20)** 

_Adv. Energy Mater._ **2022** , _12_ , 2104030 

© 2022 Wiley-VCH GmbH 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 



**Figure 7.** a) Trap-like localized antisite defects form near the valence band edge for the PbI2-terminated TiO2/perovskite interface. Shallow and delocalized Pb-Cl antisite defects are seen for the PbCl2-terminated interface. Reproduced with permission.<sup>[19]</sup> Copyright 2017, American Association for the Advancement of Science. b) A supercell illustrating the structural details in perovskite/NaCl/NiO _x_ HTL interface. Reproduced with permission.<sup>[60]</sup> Copyright 2019, John Wiley and Sons. c) Elemental scanning in a liner mode through the cross-section of SnO2-KCl/perovskite. The white dash line in the figure indicates the liner scanning direction. Reproduced with permission.<sup>[116]</sup> Copyright 2019, John Wiley and Sons. d) The typical Nyquist plots of PSCs with and without interface potassium passivation. The inset shows the equivalent circuit diagram. Reproduced with permission.<sup>[117]</sup> Copyright 2018, Springer Nature. 

Alkali chloride has been successfully adopted to modify the interface of the NiO _x_ HTL in inverted planar PSCs. The introduction of alkali chloride can not only tune the work function of NiO _x_ but also improve the ordering of perovskite films (Figure 7b). Finally, the defects/traps density at the buried interface between perovskite and NiO _x_ is significantly reduced to suppress interfacial recombination and ion migration, which finally results in enhanced stability.<sup>[60]</sup> Additionally, additional potassium (K) ions are also used to passivate the interface defects and minimize the device hysteresis,<sup>[112,113]</sup> similar to that in bulk.<sup>[20,114,115]</sup> Moreover, the potassium ion on the interface can diffuse through the perovskite film and passivate the grain boundaries (Figure 7c).<sup>[116]</sup> Huang et al. found that a certain amount of interface potassium has a significant effect on perovskite films nucleation and growth, as well as interface charge extraction (Figure 7d).<sup>[117]</sup> Moreover, interface K ions may undergo a substitutional reaction with the bromine (Br) ions at the surface of the perovskite film, passivating halide vacancies at the interface to promote high performance including the hysteresis elimination. 

In addition to chlorine and alkali metal ions, the addition of the CsBr layer can tune the work function of TiO2 ETL and increase the electron transfer rate from the perovskite to the TiO2. More importantly, the inserted CsBr layer dramatically suppresses ultraviolet (UV)-induced degradation of the perovskite films and devices ( **Figure 8** a).<sup>[103]</sup> Similarly, buried CsI modification is employed to improve the resistance to UV illumination.<sup>[118]</sup> Recently, Wang et al. regulated the SnO2 ETL 

with RbF. The active Rb<sup>+</sup> cations escape into bulk perovskite beyond modifying RbF onto the SnO2 surface, which results in a suppressed ion migration in the perovskites as well as a reduced carrier non-radiative recombination at the SnO2/perovskite interface. Finally, the _V_ oc of corresponding PSCs increases from 1.131 to 1.165 V with negligible hysteresis. By introducing RbF into the SnO2 colloidal dispersion, the newly formed FSn bonds change the electron cloud density surrounding the Sn atoms, which helps improve the electron mobility of SnO2 and thus increases _J_ sc.<sup>[86]</sup> Meanwhile, an NdCl3 interface layer has been demonstrated to interdict the iodine ion migration pathway through filling the initial ion vacancies, leading to reduce trap densities over the whole perovskite region, offering significantly improved photostability.<sup>[119]</sup> Another research work indicating potassium thiocyanate (KSCN) provides multiple interface passivation effects, which could be a better choice compared with potassium acetate (KAc) and KCl.<sup>[61]</sup> In addition to potassium passivation, thiocyanate shows two good passivation effects on perovskite and NiO _x_ to achieve triple passivation. The strong NiN bonding exhibits strong polar covalent bond properties to make the electron deviate from the Ni side. Meanwhile, the strong electrostatic force between S and Pb in MAPbI3 makes the Pb atomic layer closer to perovskite to restrain the I atom (Figure 8b). 

Inorganic amine salts are also developed to tune the interface between CTLs and perovskite layer. Liu et al. introduced NH4Cl to modify SnO2 ETL, which can not only increase electron mobility to achieve a proper energy band alignment 

**2104030 (6 of 20)** 

_Adv. Energy Mater._ **2022** , _12_ , 2104030 

© 2022 Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 8.** a) Schematic illustration of the control perovskite solar cell before and after UV irradiation (top), and perovskite solar cell with CsBr interface modification before and after UV irradiation (bottom). Reproduced with permission.<sup>[103]</sup> Copyright 2016, Royal Society of Chemistry. b) Geometries obtained after first-principle molecular dynamics. Calculated charge density difference and slices along NiN and NiS planes at the interface. Reproduced with permission.<sup>[61]</sup> Copyright 2020, John Wiley and Sons. c) Side views of SnO2/NH4Cl/MAPbI3 heterostructure from [001] and [110] directions of bulk SnO2, respectively. Reproduced with permission.<sup>[89]</sup> Copyright 2019, John Wiley and Sons. d) Schematic illustration of NH4F treatment on SnO2 surface. Reproduced with permission.<sup>[62]</sup> Copyright 2020, American Chemical Society. 

well-matched to that of perovskite but also optimize the ETL/ perovskite interface by suppressing the formation of deep-level defects to result in improved performance and stability with negligible hysteresis (Figure 8c).<sup>[89]</sup> Jung et al. reported using ammonium fluoride (NH4F) to reduce defect sites and adjust the Fermi level of SnO2 thin films. As shown in Figure 8d, NH4F surface treatment could eliminate hydroxyl groups from the SnO2 surface, which introduce deep energy states traps in the bandgap and produce non-radiative recombination and result in performance loss, and also dope it with fluorine ions.<sup>[62]</sup> 

Overall, inorganic salt ions are proved to effectively modify the buried interface. In **Table 1** , they can be roughly classified as halogen anions (F<sup>−</sup> , Cl<sup>−</sup> , Br<sup>−</sup> , I<sup>−</sup> ) and other anions (Ac<sup>−</sup> , SCN<sup>−</sup> ) combined with alkali metal cations (Na<sup>+</sup> , K<sup>+</sup> , Rb<sup>+</sup> , Cs<sup>+</sup> ) and ammonium ion (NH4<sup>+</sup> ). These inorganic salt ions can tune the work function, improve carrier mobility, and release surface defects of oxide CTL. Moreover, they also passivate bottom traps of perovskite, even diffuse into the perovskite layer to passivate grain boundary defects. They can not only enhance interface carrier extraction and transport but also act as a buffer layer to inhibit interface chemical reactions between oxide CTL and perovskite. 

**2104030 (7 of 20)** 

_Adv. Energy Mater._ **2022** , _12_ , 2104030 

© 2022 Wiley-VCH GmbH 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

**Table 1.** A review of research on inorganic salts for buried interface modification for PSCs. The device architecture and key parameters are provided. 

|Materials|Structure|_V_oc[V]|_J_sc[mA cm<sup>−2</sup>]|_FF_[%]|PCE [%]|Ref.|
|---|---|---|---|---|---|---|
|Cl|Glass/ITO/TiO2-Cl/MAPbI3−_x_Cl_x_/Spiro-OMeTAD/Au|1.189|22.3|80.6|21.4|[19]|
|Cl|Glass/FTO/SnO_x_-Cl/MAPbI3/Spiro-OMeTAD/Ag|1.19|22.52|75.82|20.31|[110]|
|KCl|Glass/ITO/NiO_x_/KCl/CsFAMA perovskite/PCBM/ZrAcac/Ag|1.15|22.89|79.5|20.96|60|
|NaCl|Glass/ITO/NiO_x_/NaCl/CsFAMA perovskite/PCBM/ZrAcac/Ag|1.14|22.83|79.6|20.71|[]|
|KCl|Glass/ITO/NiO_x_/KCl/MA0.65FA0.35PbI3/PCBM/BCP/Au|1.049|23.27|78.8|19.16|[113]|
|KCl|Glass/FTO/SnO2/KCl/Cs0.05FA0.81MA0.14PbI2.55Br0.45/Spiro-OMeTAD/Au|1.13|23.1|78.57|20.5|[112]|
|KCl|Glass/ITO/SnO2-KCl/(FAPbI3)0.95(MAPbBr3)0.05/Spiro-OMeTAD/Au|1.137|24.2|80.7|22.2|[116]|
|KOH|PET/ITO/SnO2-KOH/Cs0.05(FA0.85MA0.15)0.95Pb(I0.85Br0.15)3/Spiro-OMeTAD/Au|1.146|22.48|79|20.25|[117]|
|CsBr|Glass/FTO/cTiO2/CsBr/MAPbI3−_x_Cl_x_/Spiro-OMeTAD/Au|1.06|20.7|75|16.3|[103]|
|CsI|Glass/FTO/c-TiO2/SnO2-CsI/FAPbI3/Spiro-OMeTAD/Ag|1.15|25.1|80.7|23.3|[118]|
|NH4Cl|Glass/ITO/SnO2-NH4Cl/perovskite/Spiro-OMeTAD/Ag|1.15|24.28|76.83|21.38|[89]|
|NH4Cl|Glass/ITO/ZnO/NH4Cl/MAPbI3/Spiro-OMeTAD/MoO3/Ag|1.104|22.19|77.73|19.04|[111]|
|NH4F|Glass/FTO/SnO2/NH4F/(FAPbI3)0.95(MAPbBr3)0.05/Spiro-OMeTAD/Au|1.16|24.6|81.1|23.2|[62]|
|||1.165|23.99|75.55|21.12||
|RbF|Glass/ITO/SnO2-RbF/perovskite/Spiro-OMeTAD/Au|1.140|24.38|76.53|21.27|[86]|
|NdCl3|Glass/FTO/SnO2/NdCl3/FA1−_x_MA_x_PbI3/Spiro-OMeTAD/Au|1.138|23.65|82.23|22.13|[119]|
|KSCN|Glass/ITO/NiO_x_/KSCN/MAPbI3−_x_Cl_x_/PCBM:C60/ZrAcac/Ag|1.14|23.28|80|21.23||
|KCl|Glass/ITO/NiO_x_/KCl/MAPbI3−_x_Cl_x_/PCBM:C60/ZrAcac/Ag|1.11|22.88|78|19.81|[61]|
|KAc|Glass/ITO/NiO_x_/NaCl/MAPbI3−_x_Cl_x_/PCBM:C60/ZrAcac/Ag|1.09|22.37|78|19.02||



## **4. Organic-Based Interface Layers** 

### **4.1. Small Molecules** 

Organic molecules with tailorable structures are widely adopted to passivate/heal the defects/traps on the top surface of perovskite.<sup>[21,45,120–127]</sup> Moreover, they can play an important role in modifying the buried interface. Various molecules have been developed either as electron donors or electron acceptors for passivating positively/negatively charged traps. Among them, Lewis's acids, including phosphoric acid, sulfonic groups, and ammonium groups, can neutralize undercoordinated halides through coordinate bonding to form Lewis adducts. Lewis bases, such as carboxylate and amine groups, and electron-rich aromatic structures have been reported to reduce undercoordinated metal atoms of oxide CTL and lead atoms of perovskite by donating a lone pair of electrons. 

Yang et al. reported that ethylenediaminetetraacetic acid (EDTA) can tune Fermi level to better match with the conduction band of perovskite, contributing to high open-circuit voltage. Moreover, the enhanced electron mobility can improve electron transfer and suppress charge accumulation at the interface, thereby leading to high efficiency with negligible _J_ – _V_ hysteresis ( **Figure 9** a).<sup>[55]</sup> Additionally, the addition of EDTA can regulate the crystallization kinetics, resulting in high-quality perovskite thin films with a lower trap density (Figure 9a), good crystallinity, and large grain size. Such high-quality thin films are beneficial to suppressing perovskite degradation at grain boundaries and obtaining long-term stability. Ethylenediaminetetraacetic acid dipotassium (EDTAK) is further adopted to mitigate the reaction of OH<sup>−</sup> in SnO2 with perovskite and tune 

the energy-level alignment at the SnO2/perovskite interface, improve charge transport and suppress charge recombination and hysteresis. As a result, a stable SnO2/perovskite contact is obtained through an acid-base neutralization reaction. Compared with EDTA, ethylenediaminetetraacetic acid dipotassium (EDTAK) retain the positive passivation effect of K<sup>+</sup> .<sup>[73]</sup> 

Tu et al. employ a simple, air-robust, and cheap electron donor, triphenylphosphine oxide (TPPO), to improve conductivity and regulate the work function of SnO2. Such strategies enlarge the built-in field from 0.01 to 0.07 eV and decrease the energy barrier from 0.55 to 0.39 eV at the SnO2/perovskite interface. The electrostatic force microscopy (EFM) results identified that electron transfer between the absorbed TPPO molecules and underlying SnO2 nanocrystal film takes place from the R3P<sup>+</sup> -O<sup>−</sup> _σ_ -bond mainly to the peripheral tin atoms (Figure 9b).<sup>[128]</sup> Zhang et al. have introduced 5-aminovaleric acid (5-AVA) molecule to passivate the surface traps of NiMgLiO HTL and achieve a better band alignment at the HTL/perovskite interface, which enhances charge extraction and reduces recombination loss. The carboxyl functional groups in 5-AVA molecules can chemically anchor onto NiMgLiO through esterification with the oxide's surface hydroxyl groups, while the amine functional groups coordinate with the photoactive perovskite layer (Figure 9c).<sup>[129]</sup> A similar interface modification mechanism also exists in the case that the amino acids including glycine, b-alanine, and L-alanine are presumably able to perform as the “linker” at the interface.<sup>[130]</sup> Recently, taking advantage of these characteristics, Wang et al. have utilized 5-AVA to form an oriented dipole layer on the indium tin oxide (ITO) surface to enhance the device performance of ETL-free PSCs.<sup>[131]</sup> It is worth noting that interface amino alone can also 

**2104030 (8 of 20)** 

_Adv. Energy Mater._ **2022** , _12_ , 2104030 

© 2022 Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 9.** a) Electron mobility for EDTA, SnO2, and EDTA-SnO2 (E-SnO2). Dark _I_ – _V_ curves of the electron-only devices with the _V_ TFL kink points. The inset shows the structure of the electron-only device. Reproduced with permission.<sup>[55]</sup> Copyright 2018, Springer Nature. b) Plots of the phase as a function of applied bias. The solid lines are the corresponding polynomial fittings while the dash lines denote the symmetry axis of the fitting parabola. Reproduced with permission.<sup>[128]</sup> Copyright 2019, John Wiley and Sons. c) The schematic diagram illustrates the layer-by-layer structure of the inverted PSC studied in this work, highlighting the 5-AVA modified interface between NiMgLiO and MAPbI3. Reproduced with permission.<sup>[129]</sup> Copyright 2018, John Wiley and Sons. 

complete a good adjustment.<sup>[132]</sup> In addition, some amino acids can form an ambipolar self-assembled monolayer (SAM), which not only induces the growth of perovskite crystals but also improves the energy level alignment with an extra permanent dipole.<sup>[101,133]</sup> The same SAM can form in the presence of other organic molecules, such as (3-iodopropyl)trimethoxysilane and carbazole-based SAMs, to increase adhesion toughness at the interface, enhance mechanical reliability and charge transfer rate.<sup>[59,134]</sup> Some other organic SAMs used in buried interface modification of PSCs are listed in **Table 2** and Yoon et al. review SAM-related interface modification and additive research work in PSCs and organic solar cells.<sup>[63]</sup> 

Other organic molecules, such as diethanolamine (DEA),<sup>[102]</sup> 2,2′-(perfluoronaphthalene-2,6-diylidene)dimalononitrile (F6TCNNQ),<sup>[100]</sup> dopamine,<sup>[88]</sup> 3-(1-pyridinio)-1-propanesulfonate,<sup>[85]</sup> and perylene<sup>[99]</sup> are also employed to modify the interface between NiO _x_ and poly(3,4-ethylenedioxythiophene) polystyrene sulfonate (PEDOT:PSS) HTL or TiO2 and SnO2 ETL and perovskite. Organic molecular can reduce the interface strain. As shown in **Figure 10** , Zhang et al. have found that modified (3-aminopropyl)triethoxysilane (APTES), a protonated amino silane coupling agent (PASCA-Br), can alleviate strain stress, in which pillowy alkyl ammonium bromide terminals act as wellmatched growth sites for the perovskite growth, resulting in reduced lattice distortion and ensuing interface strain. Moreover, R-NH3Br terminals will form strong chemical bonds with undercoordinated Pb atoms, reducing lattice distortion considerably.<sup>[135]</sup> 

### **4.2. Polymers** 

Polymers provide outstanding modification capability for interface as compared to organic molecules because of their insulating and dielectric characteristics. Furthermore, many polymers with water resistance can effectively safeguard the perovskite. In this case, many organic polymers have been widely used to passivate the top interface of PSCs and exhibit many good qualities.<sup>[136–141]</sup> Similarly, organic polymer is a kind of good candidate to tune the buried interface to enhance performance and stability. 

In order to minimize hydroxyl groups on the surface of the resulting ZnO films, polyethyleneimine (PEI) is successfully developed to replace commonly used ethanolamine in the precursor solutions. Increased thermochemical stability of perovskite films is achieved.<sup>[142]</sup> Wei et al. use polyethylene glycol (PEG) to improve the compactness and wetting properties of the SnO2 layer ( **Figure 11** a).<sup>[143]</sup> Tian et al. also reported that an amino-functionalized polymer (PN4N) interlayer can tune the surface wetting property to promote the formation of highquality all-inorganic perovskite films with larger grain size and higher crystallinity. Meanwhile, these PN4N can also interact with the perovskite crystal to efficiently passivate electronic surface trap states and suppress photoinduced halide segregation in perovskite films. The formed interfacial dipole can also reduce the work function of SnO2, and thus improve the electron extraction property.<sup>[90]</sup> 

**2104030 (9 of 20)** 

_Adv. Energy Mater._ **2022** , _12_ , 2104030 

© 2022 Wiley-VCH GmbH 

#### **www.advancedsciencenews.com** 

#### **www.advenergymat.de** 

**Table 2.** A summary of research on organic materials (molecular and polymer) for buried interface modification for PSCs. The device architecture and key parameters are provided. 

|Materials|Structure|_V_oc<br>[V]|_J_sc<br>[mA cm<sup>−2</sup>]|_FF_<br>[%]|PCE<br>[%]|Ref.|
|---|---|---|---|---|---|---|
|EDTA|Glass/ITO/SnO2-EDTA/FA0.95Cs0.05PbI3/Spiro-OMeTAD/Au|1.11|24.55|79.2|21.6|[55]|
|EDTAK|Glass/ITO/SnO2/EDTAK/Cs0.05FA0.54MA0.41Pb(I0.98Br0.02)3/Spiro-OMeTAD/Au|1.10|23.2|78.4|20.1|[73]|
|EDTA|Glass/ZnO-EDTA/MAPbI3/Spiro-OMeTAD/Au|1.134|23.59|76.2|20.39|[146]|
|TPPO|Glass/ITO/SnO2/TOPO/Cs0.05(FA0.85MA0.15)0.95Pb(Br0.15I0.85)3/Spiro-OMeTAD/<br>Au|1.106|24.3|77|20.69|[128]|
|5-AVA|Glass/FTO/NiMgLiO/5-AVA/MAPbI3/PCBM/BCP/Ag|1.129|21.8|79|19.44|[129]|
|5-AVA|Glass/ITO/5-AVA/FA0.9Cs0.1PbI3−_x_Cl_x_/Spiro-OMeTAD/Ag|1.08|23.91|75|19.37|[131]|
|Amino|Glass/ITO/TiO2-NH2/Cs0.05FA0.83MA0.12PbI2.55Br0.45/spiro-OMeTAD/Au|1.19|23.40|76.6|21.33|[132]|
|3-aminopropanoic acid (C3-SAM)|Glass/ITO/PEDOT:PSS/C3-SAM/MAPbI3−_x_Cl_x_/PC61BM/ZnO/Ag|0.89|18.9|69.1|11.6|[101]|
|3-aminopropanoic acid (C3-SAM)|Glass/ITO/ZnO/C3-SAM/MAPbI3/Spiro-OMeTAD/MoO3/Ag|1.07|22.51|65|15.67|[133]|
|(3-iodopropyl)trimethoxysilane<br>(SAM)|Glass/ITO/SnO2/SAM/Cs0.05(FA0.85MA0.15)0.95Pb(I0.85Br0.15)3/Spiro-OMeTAD/Au|1.185|23.26|77.8|21.44|[59]|
|(3-aminopropyl)triethoxysilane<br>(APTES-SAM)|Glass/FTO/SnO2/APTES-SAM/MAPbI3/Spiro-OMeTAD/Au|1.160|21.93|72.00|18.32|[147]|
|Aminopropyltrimethoxysilane (SAM)|Glass/FTO/cTiO2/SAM/ZrO2-MAPbI3/Carbon|0.873|19.51|75|12.77|[148]|
|4-cyanobenzoic acid (CBA)|Glass/ITO/SnO2/CBA/MAPbI3/Spiro-OMeTAD/Au|1.08|21.66|78.1|18.27||
|4-pyridinecarboxylic acid (PA)|Glass/ITO/SnO2/PA/MAPbI3/Spiro-OMeTAD/Au|1.10|22.03|77.4|18.77|[149]|
|Benzoic acid (BA)|Glass/ITO/SnO2/BA/MAPbI3/Spiro-OMeTAD/Au|1.11|21.88|74.6|18.11||
|4-aminobenzoic acid (ABA)|Glass/ITO/SnO2/ABA/MAPbI3/Spiro-OMeTAD/Au|1.04|22.00|72.1|16.5||
|4-imidazoleacetic acid hydrochloride<br>(ImAcHCl)|<br>Glass/FTO/SnO2/ImAcHCl/(FAPbI3)0.95(MAPbBr3)0.05/Spiro-MeOTAD/Au|1.153|23.06|79.0|20.96|[150]|
|Diethanolamine (DEA)|Glass/FTO/NiO/DEA/MAPbI3−_x_Cl_x_/PCBM/PN4N/Ag|0.95|20.90|80|15.90|[102]|
|2,2′-(perfluoronaphthalene-2,6-diyli-<br>dene)dimalononitrile (F6TCNNQ)|Glass/ITO/NiO_x_/F6TCNNQ/CsMAFA perovskite/PCBM/ZrAcac/Ag|1.12|23.15|80.2|20.81|[100]|
|Dopamine|Glass/FTO/TiO2/dopamine/Cs0.05FA0.81MA0.14PbI2.55Br0.45/Spiro-OMeTAD/Au|1.16|23.65|76.3|20.93|[88]|
|3-(1-pyridinio)-1-propanesulfonate|Glass/FTO/SnO2/3-(1-pyridinio)-1-propanesulfonate/perovskite/<br>Spiro-OMeTAD/Au|1.16|23.6|78.4|21.43|[85]|
|Perylene|Glass/ITO/PEDOT:PSS/perylene/MAPbI_x_Cl3−_x_/PCBM/Bphen/Ag|0.96|20.09|77|14.85|[99]|
|APTES|Glass/FTO/TiO2/APTES/Cs0.05(FA0.85MA0.15)0.95Pb(I0.85Br0.15)3/Spiro-OMeTAD/<br>MoO3/Ag|1.12|24.01|75|20.32||
|PASCA-Br|Glass/FTO/TiO2/PASCA-Br/Cs0.05(FA0.85MA0.15)0.95Pb(I0.85Br0.15)3/<br>Spiro-OMeTAD/MoO3/Ag|1.14|24.58|77|21.66|[135]|
|Amino trimethylene phosphonic<br>acid potassium (ATMPK)|Glass/ITO/SnO2-ATMPK/MA_x_FA1−_x_PbI3/Spiro-OMeTAD/Au|1.15|24.42|80.59|22.63|[151]|
|Glycine|Glass/FTO/cTiO2/mTiO2/Glycine/MAPbI3/Spiro-OMeTAD/Au|1.00|18.51|65.00|10.88|[152]|
|Ethanolamine (EA)|Glass/FTO/cTiO2/EA/CH3NH3PbI3−_x_Cl_x_/Spiro-OMeTAD/Au|1.04|22.12|70.90|16.31|[153]|
|Porphyrin|Glass/ITO/PEDOT:PSS/porphyrin/MAPbI3−_x_(SCN)_x_/PCBM/C60/BCP/Al|0.93|21.90|69.00|14.05|[154]|
|4-Cl-benzoic acid|Glass/FTO/cTiO2/mTiO2/4-Cl-benzoic acid/FA_x_MA1−_x_PbI3−_y_Br_y_/Spiro-OMeTAD/<br>Au|1.075|22.28|76.90|18.43|[155]|
|Polyethylenimine (PEI)|Glass/ITO/ZnO/PCBM/MAPbI3/Spiro-OMeTAD/Ag|1.04|19.77|75|15.38|[142]|
|Polyethylene glycol (PEG)|Glass/ITO/SnO2-PEG/Cs0.05FA0.81MA0.14PbI2.55Br0.45/Spiro-OMeTAD/Au|1.12|22.67|81.9|20.8|[143]|
|PN4N|Glass/ITO/PTAA-PS/MAPbI3−_x_Cl_x_/PC61BM/BCP/Ag|1.24|15.1|80.4|15.1|[90]|
|Heparin potassium (HP)|Glass/ITO/SnO2-HP/Cs0.05FA0.85MA0.10Pb(I0.97Br0.03)3/Spiro-OMeTAD/Au|1.163|24.97|79.4|23.06|[144]|
|Polystyrene (PS)|Glass/ITO/PTAA-PS/MAPbI3−_x_Cl_x_/PC61BM/BCP/Ag|1.12|22.5|82.5|20.8|[145]|
|Poly(ethylene glycol) diacrylate<br>(PEGDA)|Glass/ITO/SnO2-PEGDA/FAPbI3/Spiro-OMeTAD/MoO3/Ag|1.14|25.24|81.00|23.31|[57]|



**2104030 (10 of 20)** 

_Adv. Energy Mater._ **2022** , _12_ , 2104030 

© 2022 Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 10.** a) In-plane and out-of-plane grazing incidence X-ray diffraction (GIXRD) results for perovskite films deposited on TiO2, TiO2/APTES, and TiO2/PASCA-Br substrates, respectively. b) The corresponding crystal strains of perovskite films at in-plane and out-of-plane directions. (a) and (b) Reproduced with permission.<sup>[135]</sup> Copyright 2020, John Wiley and Sons. 



**Figure 11.** a) Schematic diagram of the interaction between PEG and SnO2. Contact angle measurement of SnO2 films with and without PEG. Reproduced with permission.<sup>[143]</sup> Copyright 2018, John Wiley and Sons. b) The cross-sectional SEM images of the perovskite layers deposited on SnO2 and SnO2-HP thin films. The _J_ – _V_ curves measured at reverse scan of flexible planar PSCs fabricated on ITO/PET using SnO2 and SnO2-HP as the ETL measured. Reproduced with permission.<sup>[144]</sup> Copyright 2020, John Wiley and Sons. c) Best device performance under reverse scan and forward scan. Reproduced with permission.<sup>[57]</sup> Copyright 2021, American Chemical Society. 

**2104030 (11 of 20)** 

_Adv. Energy Mater._ **2022** , _12_ , 2104030 

© 2022 Wiley-VCH GmbH 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

**Table 3.** A summary of research on carbon materials for buried interface modification for PSCs. The device architecture and key parameters are provided. 

|Materials|Structure|_V_oc[V]|_J_sc[mA cm<sup>−2</sup>]|_FF_[%]|PCE [%]|Ref.|
|---|---|---|---|---|---|---|
|C60-SAM|Glass/FTO/cTiO2/C60-SAM/MAPbI3−_x_Cl_x_/Spiro-OMeTAD/Au|1.04|22.1|75.00|17.3|[159]|
|C60-SAM|Glass/ITO/SnO2/C60-SAM/MAPbI3/Spiro-OMeTAD/Ag|1.07|21.53|65.00|15.18|[160]|
|C60-SAM|Glass/FTO/cTiO2/mTiO2/C60-SAM/MAPbI3−_x_Cl_x_/Spiro-OMeTAD/Au|0.91|19.80|75.40|13.50|[161]|
|PCBM|Glass/FTO/SnO2/PCBM/MAPbI3/Spiro-OMeTAD/Au|1.12|22.61|75.83|19.12|[162]|
|CPTA|Glass/FTO/SnO2/CPTA/{en}FASnI3/PTAA/Au|0.722|13.42|67.00|6.54|[163]|
|C60|Glass/ITO/SnO2/C60/FA0.66MA0.34PbI2.85Br0.15/Spiro-OMeTAD/<br>MoO3/Au|1.04|21.4|69.00|15.3||
|PCBM|Glass/ITO/SnO2/PCBM/FA0.66MA0.34PbI2.85Br0.15/Spiro-OMeTAD/<br>MoO3/Au|1.08|22.1|72.00|17.1|[164]|
|PCBA|Glass/ITO/SnO2/PCBA/FA0.66MA0.34PbI2.85Br0.15/Spiro-OMeTAD/<br>MoO3/Au|1.10|22.2|76.00|18.6||
|C60|Glass/FTO/mTiO2/C60/MAPbI3/Spiro-OMeTAD/Au|1.042±0.011|21.1±0.8|77±2|17.0±0.3|[167]|
|PCBA|Glass/FTO/cTiO2/PCBA/MAPbI3/Spiro-OMeTAD/Ag|1.09|16.97|71.00|13.15|[168]|
|GQDs|Glass/ITO/SnO2-GQDs/MAPbI3/Spiro-OMeTAD/Au|1.134|23.05|77.80|20.31|[166]|
|Red CQs|Glass/ITO/SnO2-RCQs/Cs0.05FA0.81MA0.14PbI2.55Br0.45/<br>Spiro-OMeTAD/MoO3/Au|1.14|24.10|82.9|22.77|[56]|
|I-GQDs|Glass/ITO/SnO2/I-GQDs/FAPbI3/Spiro-OMeTAD/Ag|1.073|25.42|82.00|22.37|[51]|
|Graphdiyne|Glass/ITO/SnO2-Graphdiyne/Perovskite/Spiro-OMeTAD/Au|1.137|23.32|79.62|21.11|[169]|



In addition, a biological polymer (heparin potassium, HP) has been developed to regulate the arrangement of SnO2 and further induce vertically aligned crystal growth of perovskites (Figure 11b). Moreover, sulfate groups in HP can coordinate with undercoordinated lead ions in the perovskite to passivate the trap states. This strategy successfully improves the interface contact between the SnO2 ETL and the perovskite layer, resulting in a high PCE of 19.47% on flexible substrates.<sup>[144]</sup> Xu et al. have further found that mixed polystyrene (PS) and PTAA can produce a textured PTAA/perovskite interface to inhibit internal optical reflection, improve external quantum efficiency, and enhance photocurrent.<sup>[145]</sup> Recently, poly(ethylene glycol) diacrylate (PEGDA) has been introduced to suppress the agglomeration of SnO2 (Figure 11c). Beyond that, it can passivate the defects at the interface between perovskite and ETL and also result in better energy-level alignment between perovskite and ETL, which could facilitate the carrier transport and reduce the energy loss.<sup>[57]</sup> 

There are very few studies on polymers for modifying the buried bottom interface, but theoretical research has shown that these polymers have great potential to better regulate the bottom interface. Due to the inherent insulating properties of polymer materials, these make polymer materials a doubleedged sword. If used improperly, it will greatly increase the charge transfer resistance of the device and reduce the shortcircuit current and fill factor. 

In conclusion, compared with inorganic salts, molecules/polymers show a good ability to passivate interface defects and help to form high-quality perovskite film.<sup>[92,156–158]</sup> Besides, they can tune the electrical properties at the buried interface, such as work function and electron mobility of CTL, energy-level alignment between CTL and perovskite layer. It is worth mentioning that small molecules were reported to modulate the interfacial stress. 

## **5. Carbon-Based Inorganic Materials** 

As listed in **Table 3** , carbon materials and derivatives, such as carbon nanotubes, fullerenes, graphdiyne, graphene, and graphene oxide, possess good conductivity, which can enhance interface charge transport. In 2014, Snaith et al. developed an organic electron-accepting fullerene self-assembled monolayer (C60-SAM) to significantly enhance electron transfer. Meanwhile, the anchoring group in C60-SAM can passivate or inhibit the formation of trap states at the TiO2 surface, while the fullerene moiety in C60-SAM can passivate the defects on the surface of perovskite. As such, reduced nonradiative recombination is achieved at this interface.<sup>[159]</sup> Jen et al. used the C60-SAM to passivate the SnO2 surface, thereby achieving a better phase purity of the perovskite, improved electron transfer, and small hysteresis.<sup>[160]</sup> Similarly, Mora-Sero et al. used self-assembled monolayers (SAMs) of fullerene derivatives to reduce the hysteresis by reducing the capacitive hysteresis ( **Figure 12** a). In addition, with an appropriated functionalization, SAMs can increase photocurrent even when no electron selective contact is present and a SAM is deposited just on top of the transparent conductive oxide.<sup>[161]</sup> 

In 2016, Yan et al. found that fullerenes could promote electron transfer and passivate the SnO2/perovskite interface and reduce interface recombination.<sup>[162]</sup> Xu et al. found that a hydrophilic derivative of fullerene, C60 pyrrolidine tris-acid (CPTA), can improve electron transfer at the interface, tune the conduction band minima to block the holes, and suppresses charge recombination in Sn-Based PSCs.<sup>[163]</sup> Janssen et al. found that fullerenes with the ability to react with surface hydroxyl groups effectively passivate traps at the SnO2 surface and improve the performance and reproducibility of the PSCs, tune energy band level, and enhance electron extraction and transport (Figure 12b).<sup>[164]</sup> Other 

**2104030 (12 of 20)** 

_Adv. Energy Mater._ **2022** , _12_ , 2104030 

© 2022 Wiley-VCH GmbH 

#### **www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 12.** a) Functionalized fullerenes and dark _J_ – _V_ curves in logarithm scaled current representation at different scan rates for PSCs with SAM. Reproduced with permission.<sup>[161]</sup> Copyright 2016, American Chemical Society. b) Chemical structure of C60, PCBM, and PCBA. Energy diagram of different ETL substrates, assuming a fixed Fermi level. Reproduced with permission.<sup>[164]</sup> Copyright 2019, John Wiley and Sons. 

thin fullerenes C60 bottom interface layers can significantly cause enhancement in carrier extraction.<sup>[165]</sup> 

Yang et al. developed graphene quantum dots (GQDs) to modify SnO2. They demonstrate that the photogenerated electrons in GQDs can transfer to the CB of SnO2. The transferred electrons from the GQDs will effectively fill the electron traps to improve the electron density in the CB, lower the work function, and improve the conductivity of SnO2, which is beneficial for improving the electron extraction efficiency and reducing the recombination at the ETLs/perovskite interface.<sup>[166]</sup> Huang et al. used carboxylic acid- and hydroxyl-rich red-carbon quantum dots 

(RCQs) to enhance the electron mobility of ETL ( **Figure 13** a). Moreover, red-carbon quantum dots (RCQs) at the interface can bond efficiently with the incompletely coordinated Pb<sup>2+</sup> of the perovskites and enhance hydrophilic to decrease the Gibbs free energy of the surface, promoting high-quality film formation.<sup>[56]</sup> 

Recent research work has shown that an imidazole bromide functionalized graphene quantum dots (I-GQDs) can regulate the interface between the ETL and formamidinium lead iodide (FAPbI3) perovskite layer (Figure 13b). The incorporation of imidazole bromide functionalized graphene quantum dots (I-GQDs) not only reduces the interface defects, but also 



**Figure 13.** a) Conduction properties of the SnO2 films with and without RCQs. SEM images and 2D-GIXRD patterns of the perovskite films grown on SnO2-RCQs and SnO2. Reproduced with permission.<sup>[56]</sup> Copyright 2019, John Wiley and Sons. b) The SEM images of perovskite films deposited on the pristine SnO2 and SnO2/I-GQDs films. Energy level diagram of SnO2, SnO2/I-GQDs, and the perovskite layer. Reproduced with permission.<sup>[51]</sup> Copyright 2021, John Wiley and Sons. 

**2104030 (13 of 20)** 

_Adv. Energy Mater._ **2022** , _12_ , 2104030 

© 2022 Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.advenergymat.de** 



**Figure 14.** a) Schematic illustration of cross-sectional KPFM measurement under short-circuit condition. From top to bottom, SEM image, KPFM image, and contact potential difference (CPD; averaged) profile of the device on perovskite/FI-SnO2 interface and pristine perovskite/SnO2 interface. Reproduced with permission.<sup>[170]</sup> Copyright 2021, Springer Nature. b) Structural model and corresponding schematics of crystallization process for films with different GUA concentrations on NiO _x_ substrate. Reproduced with permission.<sup>[171]</sup> Copyright 2021, John Wiley and Sons. 

improves the film quality of FAPbI3 perovskite including enlarged grain size, lower trap density, and a long carrier lifetime. Moreover, a better energy level alignment between ETL and perovskite can be obtained.<sup>[51]</sup> 

Overall, carbon materials and derivatives can enhance the conductivity very well to improve charge transfer. Likewise, it can passivate interface defects and regulate energy level alignment, and the formation of perovskite films. 

## **6. Perovskite Materials** 

Perovskite and related materials have rarely been reported to be used as buried interface modification, even though 2D perovskite has been widely used to passivate the surface of perovskite and achieve a fantastic effect. 

In 2021, some reported work achieved very good results for buried interface modification with perovskite and related raw materials. Zhou et al. developed an interpenetrating organic–inorganic halide perovskite (OIHP)/ETL interface with enhanced structural integrity compared with its regular counterpart. This interface can not only prevent ionic/molecular species from diffusing into the device, but also lower the risk of interfacial fracture, responsible for the device reliability enhancement and high mechanical-fatigue endurance. Moreover, the results from Kelvin probe force microscopy (KPFM) indicate that the interpenetrating perovskite/ETL structure allows for more effective photocarriers separation and transport across the interface, compared to an abrupt perovskite/ETL interface, thus increasing the device efficiency ( **Figure 14** a).<sup>[170]</sup> 

Sargent et al. developed a large organic cation that can be used to spontaneously form a 2D buffer layer at the buried interface, which suppresses non-radiative recombination at the buried perovskite/CTL interface and leads to a 72% reduction 

in surface recombination velocity. As shown in Figure 14b, guanidinium (GUA) cation was precipitated on the NiO _x_ surface to form a GUA-rich region. These anchored GUA subsequently crystalize into a thin GUA2PbI4 layer on the substrate during the annealing process. When the exposed preferential oxygen binding sites are saturated, excess GUA molecules are randomly distributed throughout the film, especially at higher GUA concentrations (GUA0.1). They may attach to the grain boundaries of the 3D phase to produce 2D/3D structures or incorporate into perovskite lattice to form mixed-cation perovskite alloy. High GUA concentration leads to reduced _J_ sc and _FF_ as a result of the parasitic absorption and the insulating nature of wide bandgap 2D layers.<sup>[171]</sup> 

The most exciting thing is that Seok et al. reported a crystalline FASnCl _x_ phase interlayer achieved by coupling Cl-bonded SnO2 with a Cl-containing perovskite precursor at the bottom interface. This interlayer has atomically coherent features, which enhance charge extraction and transport from the perovskite layer and have fewer interfacial defects. Eventually, this coherent interlayer made it possible to manufacture PSCs with a record efficiency of 25.8% (25.5% certified).<sup>[23]</sup> The parameters of PSCs with these interface layer are listed in **Table 4** . Perovskite and related materials used to modify the interface can achieve contact between the CTL and perovskite layer. The interface layers are usually a kind of self-formed buried interface layer. Combined with the original materials on both sides of the interface, they will self-form new interface layers which have atomically coherent features. 

## **7. 2D Materials** 

Yan et al. employed 2D material molybdenum disulfide (MoS2) as a perovskite crystallization template. They discovered the 

**2104030 (14 of 20)** 

_Adv. Energy Mater._ **2022** , _12_ , 2104030 

© 2022 Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 

**Table 4.** A summary of research on perovskite-related materials for buried interface modification for PSCs. The device architecture and key parameters are provided. 

|Materials|Structure|_V_oc[V]|_J_sc[mA cm<sup>−2</sup>]|_FF_[%]|PCE [%]|Ref.|
|---|---|---|---|---|---|---|
|FAI|Glass/FTO/SnO2-FAI/Cs0.04(FA0.84MA0.16)0.96Pb(I0.84Br0.16)3/Spiro-OMeTAD/Au|1.18|23.2|80.80|22.2|[170]|
|GUA2PbI4|Glass/ITO/NiOx/GUA2PbI4/Cs0.05FA0.80MA0.1GUA0.05PbI3/PCBM/BCP/Ag|1.226|20.1|81.6|20.1|[171]|
|FASnCl_x_|Glass/FTO/SnO2/FASnCl_x_/FAPbI3/Spiro-OMeTAD/Au|1.1885|25.74|83.2|25.5*|[23]|



|*Certified|
|---|



solution-phase van der Waals (vdW) epitaxy grow of MAPbI3 perovskite on MoS2 flakes, which are ideal for the epitaxial growth of MAPbI3 because the interplane distances of MAPbI3 (008) and MoS2 (110) planes have an identical value of 1.58 Å. As a result, large grain sizes and low defect densities are produced in strongly orientated perovskite films ( **Figure 15** a).<sup>[104]</sup> Moreover, despite the fact that the lattice symmetries of MoS2 (hexagonal) and MAPbI3 (tetragonal) are different, the dangling-bond-free surface of MoS2 flake is advantageous for van der Waals (vdW) epitaxial development of the perovskite layer. Therefore, the in-plane coupling between MoS2 and MAPbI3 can enable the growth of MAPbI3 grains on the surface of MoS2 templates, causing the perovskite layers to be oriented out of plane (110). The dangling-bond-free surface of MoS2 can facilitate the migration of atoms and accelerate the growth of perovskite grains along the lateral direction, leading to the enlargement of perovskite grain size. 

Lin et al. found that 2D black phosphorene (BP) can concurrently enhance carrier extraction at ETL/perovskite with favorable band energy alignment (Figure 15b).<sup>[172]</sup> Song et al. 

used ultrathin 2D titanium carbide MXenes to tune the perovskite/TiO2 ETL interface. The bottom MXene interface layer can improve electron extraction efficiencies at perovskite/ETL, inhibit the ultraviolet-induced photocatalysis of the ETL, and improve crystalline quality of the perovskite film with its large grain size (Figure 15c), resulting in longtime ambient and light stability of PSCs.<sup>[173]</sup> Recently, Chen et al. introduced an ultrathin metal-organic framework (MOF) layer at the interface between the ETL and the perovskite absorber to improve the device stability (Figure 15d). Both Eu ions and organic ligands in the MOF can reduce the defect concentration and improve carrier transport. Moreover, due to the Förster resonance energy transfer effect, Eu-MOF in perovskite films can enhance light utilization and inhibit the decomposition under ultraviolet light. Meanwhile, Eu-MOF also converts tensile strain to compressive strain in the perovskite films.<sup>[174]</sup> **Table 5** summarizes the reported research work about 2D interface layer in PSCs so far. These 2D materials mainly regulate the electrical properties and the formation of perovskite films. 



**Figure 15.** a) The side view of atomic crystal heterojunction of MAPbI3 and MoS2. Energy band structure of the PSC with a MoS2 interlayer. Reproduced with permission.<sup>[104]</sup> Copyright 2019, John Wiley and Sons. b) Energy level diagram of each constituent in perovskite solar cell by depositing BP-3 at the ETL/perovskite interface. Reproduced with permission.<sup>[172]</sup> Copyright 2020, John Wiley and Sons. c) SEM images and contact angles (insert) of TiO2/ perovskite and TiO2/Ti3C2T _x_ quantum dots (TQD)/perovskite. Reproduced with permission.<sup>[173]</sup> Copyright 2020, John Wiley and Sons. d) Schematic illustration of the Eu-MOF effect on perovskite film. Reproduced with permission.<sup>[174]</sup> Copyright 2020, John Wiley and Sons. 

**2104030 (15 of 20)** 

_Adv. Energy Mater._ **2022** , _12_ , 2104030 

© 2022 Wiley-VCH GmbH 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

**Table 5.** A summary of research on 2D materials for buried interface modification for PSCs. The device architecture and key parameters are provided. 

|Materials|Structure|_V_oc[V]|_J_sc[mA cm<sup>−2</sup>]|_FF_[%]|PCE [%]|Ref.|
|---|---|---|---|---|---|---|
|MoS2|Glass/ITO/PTAA/MoS2/MAPbI3/PCBM/BCP/Ag|1.13|22.66|80.26|20.55|[104]|
|BP|Glass/FTO/TiO2/BP/Cs0.05MA0.16FA0.79Pb(I0.83Br0.17)3/Spiro-OMeTAD/Ag|1.10|23.23|70.66|18.15|[172]|
|Phosphorene|Glass/ITO/PTAA/Phosphorene/FA0.95Cs0.05PbI3/PCBM/BCP/Cu|1.093|23.30|0.829|21.14|[175]|
|MXene|Glass/FTO/cTiO2/mTiO2-MXene/Perovskite/Spiro-OMeTAD/Au|1.12|23.51|74.62|19.65|[173]|
|MXene|Glass/FTO/cTiO2/MXene-mTiO2/MXene/MXene-MAPbI3/MXene/<br>Spiro-OMeTAD/Au|1.09|23.82|77.6|20.14|[176]|
|Eu-MOF|Glass/ITO/SnO2/((FA, MA, Cs)Pb(I, Br)3/Spiro-OMeTAD/Au|1.14|23.71|82.00|22.16|[174]|
|Zr-MOF|Glass/ITO/NiO_x_/MOF/MAPbI3/PC61BM/BCP/Ag|1.072|21.85|76.90|18.01|[177]|
|Ti-MOF|PEN/ITO/PCBM-MOF/MA0.05FA0.95PbI3/Spiro-OMeTAD/Au|1.082|23.18|75.5|18.94|[178]|
|ZIF-8|Glass/FTO/cTiO2/mTiO2/ZIF/MAPbI3/Spiro-OMeTAD/Au|1.02|22.82|73.00|16.99|[179]|



## **8. Conclusion and Outlook** 

In recent years, great progress has been achieved in exploring the modification of the buried interface of PSCs. In this review, we have surveyed current developments in the buried interfacial engineering of PSCs. There are several examples where buried interlayers have increased the efficiency and, perhaps more importantly, the long-term device stability of PSCs. The majority of research has concentrated on inorganic salts and organic interlayers between the perovskite layer and the bottom metal oxide CTL; these interlayers aid in inhibiting interface non-radiative recombination, improving charge extraction and transport, releasing interface chemical reactions and determining the morphology of the perovskite layer deposited on top of them. In general, there is still a lot of space for improvement in photovoltaic performance, and perovskite buried interface engineering will continue to work on developing effective material systems and process methods that will push the development of PSCs to a higher level. In particular, lower _V_ oc loss and higher _FF_ may be expected, even close to the theoretical limit. 

We are optimistic about the future of research on buried interface modification and anticipate that researchers will be able to develop more efficient, resilient, and low-cost ideal candidate materials for buried interface modification. At the same time, more advanced and effective characterization methods and in-depth mechanisms exploration for buried interface of PSCs will be motivated to understand the characteristics of the bottom interface more clearly. 

The upcoming findings may further boost the efficiency and stability as well as accelerate the wide application of PSCs. The same applies to other optoelectronic devices. In summary, we believe that a deep insight in terms of precise control of the buried interface at the nanoscale may contribute to solving the problem that makes heterojunction interfaces tend to be perfectly integrated. The materials for buried interface modification need to be carefully chosen because some of them have the potential to be an important part of the toolkit required to scale up and commercialize PSCs. 

## **Acknowledgements** 

The authors would like to support by the University Grant Council of the University of Hong Kong (Grant# 202011159254, and Research 

Equipment Fund), the General Research Fund (Grant 17200518, 17201819, 17211220, and 17200021), and Collaborative Research Grant (C5037-18G and C7035-20G) from the Research Grants Council (RGC) of Hong Kong Special Administrative Region, China. 

## **Conflict of Interest** 

The authors declare no conflict of interest. 

## **Keywords** 

defect passivation, interface, perovskite solar cells, stability 

Received: December 26, 2021 Revised: March 11, 2022 Published online: April 10, 2022 

- [1] Y. Rong, Y. Hu, A. Mei, H. Tan, M. I. Saidaminov, S. I. Seok, M. D. McGehee, E. H. Sargent, H. Han, _Science_ **2018** , _361_ , eaat8235. 

- [2] D. Luo, W. Yang, Z. Wang, A. Sadhanala, Q. Hu, R. Su, R. Shivanna, G. F. Trindade, J. F. Watts, Z. Xu, T. Liu, K. Chen, F. Ye, P. Wu, L. Zhao, J. Wu, Y. Tu, Y. Zhang, X. Yang, W. Zhang, R. H. Friend, Q. Gong, H. J. Snaith, R. Zhu, _Science_ **2018** , _360_ , 1442. 

- [3] H. Min, M. Kim, S.-U. Lee, H. Kim, G. Kim, K. Choi, J. H. Lee, S. I. Seok, _Science_ **2019** , _366_ , 749. 

- [4] X. Zheng, Y. Hou, C. Bao, J. Yin, F. Yuan, Z. Huang, K. Song, J. Liu, J. Troughton, N. Gasparini, C. Zhou, Y. Lin, D.-J. Xue, B. Chen, A. K. Johnston, N. Wei, M. N. Hedhili, M. Wei, A. Y. Alsalloum, P. Maity, B. Turedi, C. Yang, D. Baran, T. D. Anthopoulos, Y. Han, Z.-H. Lu, O. F. Mohammed, F. Gao, E. H. Sargent, O. M. Bakr, _Nat. Energy_ **2020** , _5_ , 131. 

- [5] A. K. Jena, A. Kulkarni, T. Miyasaka, _Chem. Rev._ **2019** , _119_ , 3036. 

- [6] Q. Zhang, M. M. Tavakoli, L. Gu, D. Zhang, L. Tang, Y. Gao, J. Guo, Y. Lin, S.-F. Leung, S. Poddar, Y. Fu, Z. Fan, _Nat. Commun._ **2019** , _10_ , 727. 

- [7] L. Pan, S. Shrestha, N. Taylor, W. Nie, L. R. Cao, _Nat. Commun._ **2021** , _12_ , 5258. 

- [8] Q. Zhang, Q. Shang, R. Su, T. T. H. Do, Q. Xiong, _Nano Lett._ **2021** , _21_ , 1903. 

- [9] Y. Wang, M. I. Dar, L. K. Ono, T. Zhang, M. Kan, Y. Li, L. Zhang, X. Wang, Y. Yang, X. Gao, Y. Qi, M. Grätzel, Y. Zhao, _Science_ **2019** , _365_ , 591. 

**2104030 (16 of 20)** 

_Adv. Energy Mater._ **2022** , _12_ , 2104030 

© 2022 Wiley-VCH GmbH 

#### **www.advancedsciencenews.com** 

- [10] M. Kim, J. Jeong, H. Lu, T. K. Lee, F. T. Eickemeyer, Y. Liu, I. W. Choi, S. J. Choi, Y. Jo, H.-B. Kim, S.-I. Mo, Y.-K. Kim, H. Lee, N. G. An, S. Cho, W. R. Tress, S. M. Zakeeruddin, A. Hagfeldt, J. Y. Kim, M. Grätzel, D. S. Kim, _Science_ **2022** , _375_ , 302. 

- [11] J. Peng, F. Kremer, D. Walter, Y. Wu, Y. Ji, J. Xiang, W. Liu, T. Duong, H. Shen, T. Lu, F. Brink, D. Zhong, L. Li, O. Lee Cheong Lem, Y. Liu, K. J. Weber, T. P. White, K. R. Catchpole, _Nature_ **2022** , _601_ , 573. 

- [12] A. Kojima, K. Teshima, Y. Shirai, T. Miyasaka, _J. Am. Chem. Soc._ **2009** , _131_ , 6050. 

- [13] J.-H. Im, C.-R. Lee, J.-W. Lee, S.-W. Park, N.-G. Park, _Nanoscale_ **2011** , _3_ , 4088. 

- [14] M. M. Lee, J. Teuscher, T. Miyasaka, T. N. Murakami, H. J. Snaith, _Science_ **2012** , _338_ , 643. 

- [15] M. Liu, M. B. Johnston, H. J. Snaith, _Nature_ **2013** , _501_ , 395. 

- [16] N. J. Jeon, J. H. Noh, Y. C. Kim, W. S. Yang, S. Ryu, S. I. Seok, _Nat. Mater._ **2014** , _13_ , 897. 

- [17] N. J. Jeon, J. H. Noh, W. S. Yang, Y. C. Kim, S. Ryu, J. Seo, S. I. Seok, _Nature_ **2015** , _517_ , 476. 

- [18] Q. Jiang, L. Zhang, H. Wang, X. Yang, J. Meng, H. Liu, Z. Yin, J. Wu, X. Zhang, J. You, _Nat. Energy_ **2016** , _2_ , 16177. 

- [19] H. Tan, A. Jain, O. Voznyy, X. Lan, F. P. García de Arquer, J. Z. Fan, R. Quintero-Bermudez, M. Yuan, B. Zhang, Y. Zhao, F. Fan, P. Li, L. N. Quan, Y. Zhao, Z.-H. Lu, Z. Yang, S. Hoogland, E. H. Sargent, _Science_ **2017** , _355_ , 722. 

- [20] M. Abdi-Jalebi, Z. Andaji-Garmaroudi, S. Cacovich, C. Stavrakas, B. Philippe, J. M. Richter, M. Alsari, E. P. Booker, E. M. Hutter, A. J. Pearson, S. Lilliu, T. J. Savenije, H. Rensmo, G. Divitini, C. Ducati, R. H. Friend, S. D. Stranks, _Nature_ **2018** , _555_ , 497. 

- [21] Q. Jiang, Y. Zhao, X. Zhang, X. Yang, Y. Chen, Z. Chu, Q. Ye, X. Li, Z. Yin, J. You, _Nat. Photonics_ **2019** , _13_ , 460. 

- [22] G. Kim, H. Min, K. S. Lee, D. Y. Lee, S. M. Yoon, S. I. Seok, _Science_ **2020** , _370_ , 108. 

- [23] H. Min, D. Y. Lee, J. Kim, G. Kim, K. S. Lee, J. Kim, M. J. Paik, Y. K. Kim, K. S. Kim, M. G. Kim, T. J. Shin, S. Il Seok, _Nature_ **2021** , _598_ , 444. 

- [24] NREL, Best Research-Cell Efficiencies, https://www.nrel.gov/pv/ cell-efficiency.html (accessed: March 2022). 

- [25] J.-P. Correa-Baena, M. Saliba, T. Buonassisi, M. Grätzel, A. Abate, W. Tress, A. Hagfeldt, _Science_ **2017** , _358_ , 739. 

- [26] J. Zhang, W. Zhang, H.-M. Cheng, S. R. P. Silva, _Mater. Today_ **2020** , _39_ , 66. 

- [27] C. Wu, D. Wang, Y. Zhang, F. Gu, G. Liu, N. Zhu, W. Luo, D. Han, X. Guo, B. Qu, S. Wang, Z. Bian, Z. Chen, L. Xiao, _Adv. Funct. Mater._ **2019** , _29_ , 1902974. 

- [28] W. Shockley, H. J. Queisser, _J. Appl. Phys._ **1961** , _32_ , 510. 

- [29] N.-G. Park, H. Segawa, _ACS Photonics_ **2018** , _5_ , 2970. 

- [30] W. Xiang, S. (Frank) Liu, W. Tress, _Angew. Chem., Int. Ed._ **2021** , _60_ , 26440. 

- [31] H. Kim, K.-G. Lim, T.-W. Lee, _Energy Environ. Sci._ **2016** , _9_ , 12. 

- [32] W. Deng, X. Liang, P. S. Kubiak, P. J. Cameron, _Adv. Energy Mater._ **2018** , _8_ , 1701544. 

- [33] P. Schulz, D. Cahen, A. Kahn, _Chem. Rev._ **2019** , _119_ , 3349. 

- [34] E. Ochoa-Martinez, J. V. Milić, _Nat. Energy_ **2021** , _6_ , 858. 

- [35] D. Luo, X. Li, A. Dumont, H. Yu, Z.-H. Lu, _Adv. Mater._ **2021** , _33_ , 2006004. 

- [36] Y. Yang, M. Yang, D. T. Moore, Y. Yan, E. M. Miller, K. Zhu, M. C. Beard, _Nat. Energy_ **2017** , _2_ , 16207. 

- [37] B. Yang, J. Suo, F. Di Giacomo, S. Olthof, D. Bogachuk, Y. Kim, X. Sun, L. Wagner, F. Fu, S. M. Zakeeruddin, A. Hinsch, M. Grätzel, A. Di Carlo, A. Hagfeldt, _ACS Energy Lett._ **2021** , _6_ , 3916. 

- [38] A. Krishna, H. Zhang, Z. Zhou, T. Gallet, M. Dankl, O. Ouellette, F. T. Eickemeyer, F. Fu, S. Sanchez, M. Mensi, S. M. Zakeeruddin, U. Rothlisberger, G. N. M. Reddy, A. Redinger, M. Grätzel, A. Hagfeldt, _Energy Environ. Sci._ **2021** , _14_ , 5552. 

#### **www.advenergymat.de** 

- [39] J. Peng, D. Walter, Y. Ren, M. Tebyetekerwa, Y. Wu, T. Duong, Q. Lin, J. Li, T. Lu, M. A. Mahmud, O. L. C. Lem, S. Zhao, W. Liu, Y. Liu, H. Shen, L. Li, F. Kremer, H. T. Nguyen, D.-Y. Choi, K. J. Weber, K. R. Catchpole, T. P. White, _Science_ **2021** , _371_ , 390. 

- [40] S. Bai, P. Da, C. Li, Z. Wang, Z. Yuan, F. Fu, M. Kawecki, X. Liu, N. Sakai, J. T.-W. Wang, S. Huettner, S. Buecheler, M. Fahlman, F. Gao, H. J. Snaith, _Nature_ **2019** , _571_ , 245. 

- [41] M. Stolterfoht, C. M. Wolff, J. A. Márquez, S. Zhang, C. J. Hages, D. Rothhardt, S. Albrecht, P. L. Burn, P. Meredith, T. Unold, D. Neher, _Nat. Energy_ **2018** , _3_ , 847. 

- [42] S. P. Harvey, F. Zhang, A. Palmstrom, J. M. Luther, K. Zhu, J. J. Berry, _ACS Appl. Mater. Interfaces_ **2019** , _11_ , 30911. 

- [43] Y. Wang, T. Wu, J. Barbaud, W. Kong, D. Cui, H. Chen, X. Yang, L. Han, _Science_ **2019** , _365_ , 687. 

- [44] C. M. Wolff, L. Canil, C. Rehermann, N. Ngoc Linh, F. Zu, M. Ralaiarisoa, P. Caprioglio, L. Fiedler, M. Stolterfoht, S. Kogikoski, I. Bald, N. Koch, E. L. Unger, T. Dittrich, A. Abate, D. Neher, _ACS Nano_ **2020** , _14_ , 1445. 

- [45] X. Zhu, M. Du, J. Feng, H. Wang, Z. Xu, L. Wang, S. Zuo, C. Wang, Z. Wang, C. Zhang, X. Ren, S. Priya, D. Yang, S. (Frank) Liu, _Angew. Chem., Int. Ed._ **2021** , _60_ , 4238. 

- [46] S.-G. Kim, T. H. Le, T. de Monfreid, F. Goubard, T.-T. Bui, N.-G. Park, _Adv. Mater._ **2021** , _33_ , 2007431. 

- [47] Y.-W. Jang, S. Lee, K. M. Yeom, K. Jeong, K. Choi, M. Choi, J. H. Noh, _Nat. Energy_ **2021** , _6_ , 63. 

- [48] Z. Ni, C. Bao, Y. Liu, Q. Jiang, W.-Q. Wu, S. Chen, X. Dai, B. Chen, B. Hartweg, Z. Yu, Z. Holman, J. Huang, _Science_ **2020** , _367_ , 1352. 

- [49] M. Xiao, S. Joglekar, X. Zhang, J. Jasensky, J. Ma, Q. Cui, L. J. Guo, Z. Chen, _J. Am. Chem. Soc._ **2017** , _139_ , 3378. 

- [50] M. Xiao, T. Lu, T. Lin, J. S. Andre, Z. Chen, _Adv. Energy Mater._ **2020** , _10_ , 1903053. 

- [51] Z.-W. Gao, Y. Wang, H. Liu, J. Sun, J. Kim, Y. Li, B. Xu, W. C. H. Choy, _Adv. Funct. Mater._ **2021** , _31_ , 2101438. 

- [52] X. Yang, D. Luo, Y. Xiang, L. Zhao, M. Anaya, Y. Shen, J. Wu, W. Yang, Y.-H. Chiang, Y. Tu, R. Su, Q. Hu, H. Yu, G. Shao, W. Huang, T. P. Russell, Q. Gong, S. D. Stranks, W. Zhang, R. Zhu, _Adv. Mater._ **2021** , _33_ , 2006435. 

- [53] S. Chen, X. Dai, S. Xu, H. Jiao, L. Zhao, J. Huang, _Science_ **2021** , _373_ , 902. 

- [54] D. Luo, R. Su, W. Zhang, Q. Gong, R. Zhu, _Nat. Rev. Mater._ **2020** , _5_ , 44. 

- [55] D. Yang, R. Yang, K. Wang, C. Wu, X. Zhu, J. Feng, X. Ren, G. Fang, S. Priya, S. Liu, _Nat. Commun._ **2018** , _9_ , 3239. 

- [56] W. Hui, Y. Yang, Q. Xu, H. Gu, S. Feng, Z. Su, M. Zhang, J. Wang, X. Li, J. Fang, F. Xia, Y. Xia, Y. Chen, X. Gao, W. Huang, _Adv. Mater._ **2019** , _32_ , 1906374. 

- [57] Z. Xiong, L. Lan, Y. Wang, C. Lu, S. Qin, S. Chen, L. Zhou, C. Zhu, S. Li, L. Meng, K. Sun, Y. Li, _ACS Energy Lett._ **2021** , _6_ , 3824. 

- [58] P. Zhang, J. Wu, T. Zhang, Y. Wang, D. Liu, H. Chen, L. Ji, C. Liu, W. Ahmad, Z. D. Chen, S. Li, _Adv. Mater._ **2018** , _30_ , 1703737. 

- [59] Z. Dai, S. K. Yadavalli, M. Chen, A. Abbaspourtamijani, Y. Qi, N. P. Padture, _Science_ **2021** , _372_ , 618. 

- [60] W. Chen, Y. Zhou, G. Chen, Y. Wu, B. Tu, F.-Z. Liu, L. Huang, A. M. C. Ng, A. B. Djurišić, Z. He, _Adv. Energy Mater._ **2019** , _9_ , 1803872. 

- [61] Z.-W. Gao, Y. Wang, D. Ouyang, H. Liu, Z. Huang, J. Kim, W. C. Choy, _Small Methods_ **2020** , _4_ , 2000478. 

- [62] E. H. Jung, B. Chen, K. Bertens, M. Vafaie, S. Teale, A. H. Proppe, Y. Hou, T. Zhu, C. Zheng, E. H. Sargent, _ACS Energy Lett._ **2020** , _5_ , 2796. 

- [63] S. Y. Kim, S. J. Cho, S. E. Byeon, X. He, H. J. Yoon, _Adv. Energy Mater._ **2020** , _10_ , 2002606. 

- [64] C. C. Boyd, R. C. Shallcross, T. Moot, R. Kerner, L. Bertoluzzi, A. Onno, S. Kavadiya, C. Chosy, E. J. Wolf, J. Werner, J. A. Raiford, C. de Paula, A. F. Palmstrom, Z. J. Yu, J. J. Berry, S. F. Bent, 

**2104030 (17 of 20)** 

_Adv. Energy Mater._ **2022** , _12_ , 2104030 

© 2022 Wiley-VCH GmbH 

#### **www.advancedsciencenews.com** 

   - Z. C. Holman, J. M. Luther, E. L. Ratcliff, N. R. Armstrong, M. D. McGehee, _Joule_ **2020** , _4_ , 1759. 

- [65] H. Uratani, K. Yamashita, _J. Phys. Chem. Lett._ **2017** , _8_ , 742. 

- [66] X. Wu, M. T. Trinh, D. Niesner, H. Zhu, Z. Norman, J. S. Owen, O. Yaffe, B. J. Kudisch, X.-Y. Zhu, _J. Am. Chem. Soc._ **2015** , _137_ , 2089. 

- [67] R. A. Kerner, B. P. Rand, _J. Phys. Chem. Lett._ **2017** , _8_ , 2298. 

- [68] R. C. Shallcross, S. Olthof, K. Meerholz, N. R. Armstrong, _ACS Appl. Mater. Interfaces_ **2019** , _11_ , 32500. 

- [69] T. Hu, T. Becker, N. Pourdavoud, J. Zhao, K. O. Brinkmann, R. Heiderhoff, T. Gahlmann, Z. Huang, S. Olthof, K. Meerholz, D. Többens, B. Cheng, Y. Chen, T. Riedl, _Adv. Mater._ **2017** , _29_ , 1606656. 

- [70] Y. Cheng, Q.-D. Yang, J. Xiao, Q. Xue, H.-W. Li, Z. Guan, H.-L. Yip, S.-W. Tsang, _ACS Appl. Mater. Interfaces_ **2015** , _7_ , 19986. 

- [71] J. Yang, B. D. Siempelkamp, E. Mosconi, F. De Angelis, T. L. Kelly, _Chem. Mater._ **2015** , _27_ , 4229. 

- [72] K. Schutt, P. K. Nayak, A. J. Ramadan, B. Wenger, Y.-H. Lin, H. J. Snaith, _Adv. Funct. Mater._ **2019** , _29_ , 1900466. 

- [73] Z. Liu, L. Qiu, L. K. Ono, S. He, Z. Hu, M. Jiang, G. Tong, Z. Wu, Y. Jiang, D.-Y. Son, Y. Dang, S. Kazaoui, Y. Qi, _Nat. Energy_ **2020** , _5_ , 596. 

- [74] X. Zhao, H. Shen, Y. Zhang, X. Li, X. Zhao, M. Tai, J. Li, J. Li, X. Li, H. Lin, _ACS Appl. Mater. Interfaces_ **2016** , _8_ , 7826. 

- [75] J. P. Correa Baena, L. Steier, W. Tress, M. Saliba, S. Neutzner, T. Matsui, F. Giordano, T. J. Jacobsson, A. R. Srimath Kandada, S. M. Zakeeruddin, A. Petrozza, A. Abate, M. K. Nazeeruddin, M. Grätzel, A. Hagfeldt, _Energy Environ. Sci._ **2015** , _8_ , 2928. 

- [76] M. Stolterfoht, P. Caprioglio, C. M. Wolff, J. A. Márquez, J. Nordmann, S. Zhang, D. Rothhardt, U. Hörmann, Y. Amir, A. Redinger, L. Kegelmann, F. Zu, S. Albrecht, N. Koch, T. Kirchartz, M. Saliba, T. Unold, D. Neher, _Energy Environ. Sci._ **2019** , _12_ , 2778. 

- [77] P. Caprioglio, M. Stolterfoht, C. M. Wolff, T. Unold, B. Rech, S. Albrecht, D. Neher, _Adv. Energy Mater._ **2019** , _9_ , 1901631. 

- [78] W. Tress, J. P. Correa Baena, M. Saliba, A. Abate, M. Graetzel, _Adv. Energy Mater._ **2016** , _6_ , 1600396. 

- [79] X. Lin, A. N. Jumabekov, N. N. Lal, A. R. Pascoe, D. E. Gómez, N. W. Duffy, A. S. R. Chesman, K. Sears, M. Fournier, Y. Zhang, Q. Bao, Y.-B. Cheng, L. Spiccia, U. Bach, _Nat. Commun._ **2017** , _8_ , 613. 

- [80] Q. Chen, C. Wang, Y. Li, L. Chen, _J. Am. Chem. Soc._ **2020** , _142_ , 18281. 

- [81] R. B. M. Hill, S.-H. Turren-Cruz, F. Pulvirenti, W. R. Tress, S. Wieghold, S. Sun, L. Nienhaus, M. Bawendi, T. Buonassisi, S. Barlow, A. Hagfeldt, S. R. Marder, J.-P. Correa-Baena, _ACS Appl. Energy Mater._ **2019** , _2_ , 2402. 

- [82] D. Seol, A. Jeong, M. H. Han, S. Seo, T. S. Yoo, W. S. Choi, H. S. Jung, H. Shin, Y. Kim, _Adv. Funct. Mater._ **2017** , _27_ , 1701924. 

- [83] D. Liu, T. L. Kelly, _Nat. Photonics_ **2014** , _8_ , 133. 

- [84] B. Wu, K. Fu, N. Yantara, G. Xing, S. Sun, T. C. Sum, N. Mathews, _Adv. Energy Mater._ **2015** , _5_ , 1500829. 

- [85] K. Choi, J. Lee, H. I. Kim, C. W. Park, G.-W. Kim, H. Choi, S. Park, S. A. Park, T. Park, _Energy Environ. Sci._ **2018** , _11_ , 3238. 

- [86] J. Zhuang, P. Mao, Y. Luan, N. Chen, X. Cao, G. Niu, F. Jia, F. Wang, S. Cao, J. Wang, _Adv. Funct. Mater._ **2021** , _31_ , 2010385. 

- [87] M. Park, J.-Y. Kim, H. J. Son, C.-H. Lee, S. S. Jang, M. J. Ko, _Nano Energy_ **2016** , _26_ , 208. 

- [88] Y. Zhang, X. Liu, P. Li, Y. Duan, X. Hu, F. Li, Y. Song, _Nano Energy_ **2019** , _56_ , 733. 

- [89] Z. Liu, K. Deng, J. Hu, L. Li, _Angew. Chem., Int. Ed._ **2019** , _58_ , 11497. 

- [90] J. Tian, Q. Xue, X. Tang, Y. Chen, N. Li, Z. Hu, T. Shi, X. Wang, F. Huang, C. J. Brabec, H.-L. Yip, Y. Cao, _Adv. Mater._ **2019** , _31_ , 1901152. 

- [91] W. S. Yang, J. H. Noh, N. J. Jeon, Y. C. Kim, S. Ryu, J. Seo, S. I. Seok, _Science_ **2015** , _348_ , 1234. 

#### **www.advenergymat.de** 

- [92] D. Bi, C. Yi, J. Luo, J.-D. Décoppet, F. Zhang, S. M. Zakeeruddin, X. Li, A. Hagfeldt, M. Grätzel, _Nat. Energy_ **2016** , _1_ , 16142. 

- [93] W. Hui, L. Chao, H. Lu, F. Xia, Q. Wei, Z. Su, T. Niu, L. Tao, B. Du, D. Li, Y. Wang, H. Dong, S. Zuo, B. Li, W. Shi, X. Ran, P. Li, H. Zhang, Z. Wu, C. Ran, L. Song, G. Xing, X. Gao, J. Zhang, Y. Xia, Y. Chen, W. Huang, _Science_ **2021** , _371_ , 1359. 

- [94] Y. Liang, Q. Shang, M. Li, S. Zhang, X. Liu, Q. Zhang, _Adv. Funct. Mater._ **2021** , _31_ , 2106108. 

- [95] F. Zhang, C. Xiao, X. Chen, B. W. Larson, S. P. Harvey, J. J. Berry, K. Zhu, _Joule_ **2019** , _3_ , 1452. 

- [96] K. B. Lohmann, J. B. Patel, M. U. Rothmann, C. Q. Xia, R. D. J. Oliver, L. M. Herz, H. J. Snaith, M. B. Johnston, _ACS Energy Lett._ **2020** , _5_ , 710. 

- [97] O. Malinkiewicz, A. Yella, Y. H. Lee, G. M. Espallargas, M. Graetzel, M. K. Nazeeruddin, H. J. Bolink, _Nat. Photonics_ **2014** , _8_ , 128. 

- [98] K. Chen, P. Wu, W. Yang, R. Su, D. Luo, X. Yang, Y. Tu, R. Zhu, Q. Gong, _Nano Energy_ **2018** , _49_ , 411. 

- [99] Z.-K. Wang, X. Gong, M. Li, Y. Hu, J.-M. Wang, H. Ma, L.-S. Liao, _ACS Nano_ **2016** , _10_ , 5479. 

- [100] W. Chen, Y. Zhou, L. Wang, Y. Wu, B. Tu, B. Yu, F. Liu, H.-W. Tam, G. Wang, A. B. Djurišić, L. Huang, Z. He, _Adv. Mater._ **2018** , _30_ , 1800515. 

- [101] Z. Gu, L. Zuo, T. T. Larsen-Olsen, T. Ye, G. Wu, F. C. Krebs, H. Chen, _J. Mater. Chem. A_ **2015** , _3_ , 24254. 

- [102] Y. Bai, H. Chen, S. Xiao, Q. Xue, T. Zhang, Z. Zhu, Q. Li, C. Hu, Y. Yang, Z. Hu, F. Huang, K. S. Wong, H.-L. Yip, S. Yang, _Adv. Funct. Mater._ **2016** , _26_ , 2950. 

- [103] W. Li, W. Zhang, S. V. Reenen, R. J. Sutton, J. Fan, A. A. Haghighirad, M. B. Johnston, L. Wang, H. J. Snaith, _Energy Environ. Sci._ **2016** , _9_ , 490. 

- [104] G. Tang, P. You, Q. Tai, A. Yang, J. Cao, F. Zheng, Z. Zhou, J. Zhao, P. K. L. Chan, F. Yan, _Adv. Mater._ **2019** , _31_ , 1807689. 

- [105] J. A. Steele, H. Jin, I. Dovgaliuk, R. F. Berger, T. Braeckevelt, H. Yuan, C. Martin, E. Solano, K. Lejaeghere, S. M. J. Rogge, C. Notebaert, W. Vandezande, K. P. F. Janssen, B. Goderis, E. Debroye, Y.-K. Wang, Y. Dong, D. Ma, M. Saidaminov, H. Tan, Z. Lu, V. Dyadkin, D. Chernyshov, V. V. Speybroeck, E. H. Sargent, J. Hofkens, M. B. J. Roeffaers, _Science_ **2019** , _365_ , 679. 

- [106] C. Zhu, X. Niu, Y. Fu, N. Li, C. Hu, Y. Chen, X. He, G. Na, P. Liu, H. Zai, Y. Ge, Y. Lu, X. Ke, Y. Bai, S. Yang, P. Chen, Y. Li, M. Sui, L. Zhang, H. Zhou, Q. Chen, _Nat. Commun._ **2019** , _10_ , 815. 

- [107] J. Zhao, Y. Deng, H. Wei, X. Zheng, Z. Yu, Y. Shao, J. E. Shield, J. Huang, _Sci. Adv._ **2017** , _3_ , eaao5616. 

- [108] T. W. Jones, A. Osherov, M. Alsari, M. Sponseller, B. C. Duck, Y.-K. Jung, C. Settens, F. Niroui, R. Brenes, C. V. Stan, Y. Li, M. Abdi-Jalebi, N. Tamura, J. E. Macdonald, M. Burghammer, R. H. Friend, V. Bulović, A. Walsh, G. J. Wilson, S. Lilliu, S. D. Stranks, _Energy Environ. Sci._ **2019** , _12_ , 596. 

- [109] T. A. S. Doherty, A. J. Winchester, S. Macpherson, D. N. Johnstone, V. Pareek, E. M. Tennyson, S. Kosar, F. U. Kosasih, M. Anaya, M. Abdi-Jalebi, Z. Andaji-Garmaroudi, E. L. Wong, J. Madéo, Y.-H. Chiang, J.-S. Park, Y.-K. Jung, C. E. Petoukhoff, G. Divitini, M. K. L. Man, C. Ducati, A. Walsh, P. A. Midgley, K. M. Dani, S. D. Stranks, _Nature_ **2020** , _580_ , 360. 

- [110] Z. Li, L. Wang, R. Liu, Y. Fan, H. Meng, Z. Shao, G. Cui, S. Pang, _Adv. Energy Mater._ **2019** , _9_ , 1902142. 

- [111] D. Zhang, X. Zhang, S. Bai, C. Liu, Z. Li, W. Guo, F. Gao, _Sol. RRL_ **2019** , _3_ , 1900154. 

- [112] X. Liu, Y. Zhang, L. Shi, Z. Liu, J. Huang, J. S. Yun, Y. Zeng, A. Pu, K. Sun, Z. Hameiri, J. A. Stride, J. Seidel, M. A. Green, X. Hao, _Adv. Energy Mater._ **2018** , _8_ , 1800138. 

- [113] X. Zheng, Z. Song, Z. Chen, S. S. Bista, P. Gui, N. Shrestha, C. Chen, C. Li, X. Yin, R. A. Awni, H. Lei, C. Tao, R. J. Ellingson, Y. Yan, G. Fang, _J. Mater. Chem. C_ **2020** , _8_ , 1972. 

**2104030 (18 of 20)** 

_Adv. Energy Mater._ **2022** , _12_ , 2104030 

© 2022 Wiley-VCH GmbH 

**www.advenergymat.de** 

#### **www.advancedsciencenews.com** 

- [114] T. Bu, X. Liu, Y. Zhou, J. Yi, X. Huang, L. Luo, J. Xiao, Z. Ku, Y. Peng, F. Huang, Y.-B. Cheng, J. Zhong, _Energy Environ. Sci._ **2017** , _10_ , 2509. 

- [115] D.-Y. Son, S.-G. Kim, J.-Y. Seo, S.-H. Lee, H. Shin, D. Lee, N.-G. Park, _J. Am. Chem. Soc._ **2018** , _140_ , 1358. 

- [116] P. Zhu, S. Gu, X. Luo, Y. Gao, S. Li, J. Zhu, H. Tan, _Adv. Energy Mater._ **2020** , _10_ , 1903083. 

- [117] T. Bu, J. Li, F. Zheng, W. Chen, X. Wen, Z. Ku, Y. Peng, J. Zhong, Y.-B. Cheng, F. Huang, _Nat. Commun._ **2018** , _9_ , 4609. 

- [118] H. Xu, Y. Miao, N. Wei, H. Chen, Z. Qin, X. Liu, X. Wang, Y. Qi, T. Zhang, Y. Zhao, _Adv. Energy Mater._ **2021** , _12_ , 2103151. 

- [119] Q. Xiong, C. Wang, Q. Zhou, L. Wang, X. Wang, L. Yang, J. Ding, C. Chen, J. Wu, X. Li, P. Gao, _Adv. Funct. Mater._ **2022** , _32_ , 2107823. 

- [120] F. Li, X. Deng, F. Qi, Z. Li, D. Liu, D. Shen, M. Qin, S. Wu, F. Lin, S.-H. Jang, J. Zhang, X. Lu, D. Lei, C.-S. Lee, Z. Zhu, A. K.-Y. Jen, _J. Am. Chem. Soc._ **2020** , _142_ , 20134. 

- [121] B. Yang, J. Suo, E. Mosconi, D. Ricciarelli, W. Tress, F. De Angelis, H.-S. Kim, A. Hagfeldt, _ACS Energy Lett._ **2020** , _5_ , 3159. 

- [122] J. Suo, B. Yang, E. Mosconi, H.-S. Choi, Y. Kim, S. M. Zakeeruddin, F. D. Angelis, M. Grätzel, H.-S. Kim, A. Hagfeldt, _Adv. Funct. Mater._ **2021** , _31_ , 2102902. 

- [123] J.-H. Kim, S.-G. Kim, N.-G. Park, _ACS Energy Lett._ **2021** , _6_ , 3435. 

- [124] R. Zhao, L. Xie, R. Zhuang, T. Wu, R. Zhao, L. Wang, L. Sun, Y. Hua, _ACS Energy Lett._ **2021** , _6_ , 4209. 

- [125] H. Zhu, Y. Ren, L. Pan, O. Ouellette, F. T. Eickemeyer, Y. Wu, X. Li, S. Wang, H. Liu, X. Dong, S. M. Zakeeruddin, Y. Liu, A. Hagfeldt, M. Grätzel, _J. Am. Chem. Soc._ **2021** , _143_ , 3231. 

- [126] Z. Huang, X. Hu, C. Liu, X. Meng, Z. Huang, J. Yang, X. Duan, J. Long, Z. Zhao, L. Tan, Y. Song, Y. Chen, _Adv. Funct. Mater._ **2019** , _29_ , 1902629. 

- [127] Y. Zhang, Y. Wang, L. Zhao, X. Yang, C.-H. Hou, J. Wu, R. Su, S. Jia, J.-J. Shyue, D. Luo, P. Chen, M. Yu, Q. Li, L. Li, Q. Gong, R. Zhu, _Energy Environ. Sci._ **2021** , _14_ , 6526. 

- [128] B. Tu, Y. Shao, W. Chen, Y. Wu, X. Li, Y. He, J. Li, F. Liu, Z. Zhang, Y. Lin, X. Lan, L. Xu, X. Shi, A. M. C. Ng, H. Li, L. W. Chung, A. B. Djurišić, Z. He, _Adv. Mater._ **2019** , _31_ , 1805944. 

- [129] Y. Zhang, S. Zhang, S. Wu, C. Chen, H. Zhu, Z. Xiong, W. Chen, R. Chen, S. Fang, W. Chen, _Adv. Mater. Interfaces_ **2018** , _5_ , 1800645. 

- [130] Y.-C. Shih, Y.-B. Lan, C.-S. Li, H.-C. Hsieh, L. Wang, C.-I. Wu, K.-F. Lin, _Small_ **2017** , _13_ , 1604305. 

- [131] J. Wang, S. Fu, L. Huang, Y. Lu, X. Liu, J. Zhang, Z. Hu, Y. Zhu, _Adv. Energy Mater._ **2021** , _11_ , 2102724. 

- [132] W. Hu, W. Zhou, X. Lei, P. Zhou, M. Zhang, T. Chen, H. Zeng, J. Zhu, S. Dai, S. Yang, S. Yang, _Adv. Mater._ **2019** , _31_ , 1806095. 

- [133] L. Zuo, Z. Gu, T. Ye, W. Fu, G. Wu, H. Li, H. Chen, _J. Am. Chem. Soc._ **2015** , _137_ , 2674. 

- [134] I. Levine, A. Al-Ashouri, A. Musiienko, H. Hempel, A. Magomedov, A. Drevilkauskaite, V. Getautis, D. Menzel, K. Hinrichs, T. Unold, S. Albrecht, T. Dittrich, _Joule_ **2021** , _5_ , 2915. 

- [135] C.-C. Zhang, S. Yuan, Y.-H. Lou, Q.-W. Liu, M. Li, H. Okada, Z.-K. Wang, _Adv. Mater._ **2020** , _32_ , 2001479. 

- [136] F. Wang, A. Shimazaki, F. Yang, K. Kanahashi, K. Matsuki, Y. Miyauchi, T. Takenobu, A. Wakamiya, Y. Murata, K. Matsuda, _J. Phys. Chem. C_ **2017** , _121_ , 1562. 

- [137] M. Kim, S. G. Motti, R. Sorrentino, A. Petrozza, _Energy Environ. Sci._ **2018** , _11_ , 2609. 

- [138] L. Meng, C. Sun, R. Wang, W. Huang, Z. Zhao, P. Sun, T. Huang, J. Xue, J.-W. Lee, C. Zhu, Y. Huang, Y. Li, Y. Yang, _J. Am. Chem. Soc._ **2018** , _140_ , 17255. 

- [139] L. Zuo, H. Guo, D. W. deQuilettes, S. Jariwala, N. De Marco, S. Dong, R. DeBlock, D. S. Ginger, B. Dunn, M. Wang, Y. Yang, _Sci. Adv._ **2017** , _3_ , e1700106. 

- [140] E. Akman, S. Akin, _Adv. Mater._ **2021** , _33_ , 2006087. 

- [141] F. Tan, H. Tan, M. I. Saidaminov, M. Wei, M. Liu, A. Mei, P. Li, B. Zhang, C.-S. Tan, X. Gong, Y. Zhao, A. R. Kirmani, Z. Huang, 

   - J. Z. Fan, R. Quintero-Bermudez, J. Kim, Y. Zhao, O. Voznyy, Y. Gao, F. Zhang, L. J. Richter, Z.-H. Lu, W. Zhang, E. H. Sargent, _Adv. Mater._ **2019** , _31_ , 1807435. 

- [142] F. Qin, W. Meng, J. Fan, C. Ge, B. Luo, R. Ge, L. Hu, F. Jiang, T. Liu, Y. Jiang, Y. Zhou, _ACS Appl. Mater. Interfaces_ **2017** , _9_ , 26045. 

- [143] J. Wei, F. Guo, X. Wang, K. Xu, M. Lei, Y. Liang, Y. Zhao, D. Xu, _Adv. Mater._ **2018** , _30_ , 1805153. 

- [144] S. You, H. Zeng, Z. Ku, X. Wang, Z. Wang, Y. Rong, Y. Zhao, X. Zheng, L. Luo, L. Li, S. Zhang, M. Li, X. Gao, X. Li, _Adv. Mater._ **2020** , _32_ , 2003990. 

- [145] C. Y. Xu, W. Hu, G. Wang, L. Niu, A. M. Elseman, L. Liao, Y. Yao, G. Xu, L. Luo, D. Liu, G. Zhou, P. Li, Q. Song, _ACS Nano_ **2020** , _14_ , 196. 

- [146] Z. Wang, X. Zhu, J. Feng, C. Wang, C. Zhang, X. Ren, S. Priya, S. (Frank) Liu, D. Yang, _Adv. Sci._ **2021** , _8_ , 2002860. 

- [147] G. Yang, C. Wang, H. Lei, X. Zheng, P. Qin, L. Xiong, X. Zhao, Y. Yan, G. Fang, _J. Mater. Chem. A_ **2017** , _5_ , 1658. 

- [148] L. Liu, A. Mei, T. Liu, P. Jiang, Y. Sheng, L. Zhang, H. Han, _J. Am. Chem. Soc._ **2015** , _137_ , 1790. 

- [149] L. Zuo, Q. Chen, N. De Marco, Y.-T. Hsieh, H. Chen, P. Sun, S.-Y. Chang, H. Zhao, S. Dong, Y. Yang, _Nano Lett._ **2017** , _17_ , 269. 

- [150] J. Chen, X. Zhao, S.-G. Kim, N.-G. Park, _Adv. Mater._ **2019** , _31_ , 1902902. 

- [151] J. Zhang, R. Li, S. Apergi, P. Wang, B. Shi, J. Jiang, N. Ren, W. Han, Q. Huang, G. Brocks, Y. Zhao, S. Tao, X. Zhang, _Sol. RRL_ **2021** , _5_ , 2100464. 

- [152] Y. C. Shih, L. Y. Wang, H. C. Hsieh, K. F. Lin, _J. Mater. Chem. A_ **2015** , _3_ , 9133. 

- [153] J. C. Yu, D. B. Kim, G. Baek, B. R. Lee, E. D. Jung, S. Lee, J. H. Chu, D.-K. Lee, K. J. Choi, S. Cho, M. H. Song, _Adv. Mater._ **2015** , _27_ , 3492. 

- [154] B. Li, C. Zheng, H. Liu, J. Zhu, H. Zhang, D. Gao, W. Huang, _ACS Appl. Mater. Interfaces_ **2016** , _8_ , 27438. 

- [155] L. F. Zhu, Y. Z. Xu, J. J. Shi, H. Y. Zhang, X. Xu, Y. H. Zhao, Y. H. Luo, Q. B. Meng, D. M. Li, _RSC Adv._ **2016** , _6_ , 82282. 

- [156] R. Wang, J. Xue, K.-L. Wang, Z.-K. Wang, Y. Luo, D. Fenning, G. Xu, S. Nuryyeva, T. Huang, Y. Zhao, J. L. Yang, J. Zhu, M. Wang, S. Tan, I. Yavuz, K. N. Houk, Y. Yang, _Science_ **2019** , _366_ , 1509. 

- [157] X. Xu, H. Zhang, E. Li, P. Ru, H. Chen, Z. Chen, Y. Wu, H. Tian, W.-H. Zhu, _Chem. Sci._ **2020** , _11_ , 3132. 

- [158] C.-C. Zhang, Z.-K. Wang, S. Yuan, R. Wang, M. Li, M. F. Jimoh, L.-S. Liao, Y. Yang, _Adv. Mater._ **2019** , _31_ , 1902222. 

- [159] K. Wojciechowski, S. D. Stranks, A. Abate, G. Sadoughi, A. Sadhanala, N. Kopidakis, G. Rumbles, C.-Z. Li, R. H. Friend, A. K.-Y. Jen, H. J. Snaith, _ACS Nano_ **2014** , _8_ , 12701. 

- [160] X. Liu, K.-W. Tsai, Z. Zhu, Y. Sun, C.-C. Chueh, A. K.-Y. Jen, _Adv. Mater. Interfaces_ **2016** , _3_ , 1600122. 

- [161] M. Valles-Pelarda, B. C. Hames, I. García-Benito, O. Almora, A. Molina-Ontoria, R. S. Sánchez, G. Garcia-Belmonte, N. Martín, I. Mora-Sero, _J. Phys. Chem. Lett._ **2016** , _7_ , 4622. 

- [162] W. Ke, D. Zhao, C. Xiao, C. Wang, A. J. Cimaroli, C. R. Grice, M. Yang, Z. Li, C.-S. Jiang, M. Al-Jassim, K. Zhu, M. G. Kanatzidis, G. Fang, Y. Yan, _J. Mater. Chem. A_ **2016** , _4_ , 14276. 

- [163] Z. Yang, M. Zhong, Y. Liang, L. Yang, X. Liu, Q. Li, J. Zhang, D. Xu, _Adv. Funct. Mater._ **2019** , _29_ , 1903621. 

- [164] J. Wang, K. Datta, C. H. L. Weijtens, M. M. Wienk, R. A. J. Janssen, _Adv. Funct. Mater._ **2019** , _29_ , 1905883. 

- [165] A. F. Palmstrom, J. A. Raiford, R. Prasanna, K. A. Bush, M. Sponseller, R. Cheacharoen, M. C. Minichetti, D. S. Bergsman, T. Leijtens, H.-P. Wang, V. Bulović, M. D. McGehee, S. F. Bent, _Adv. Energy Mater._ **2018** , _8_ , 1800591. 

- [166] J. Xie, K. Huang, X. Yu, Z. Yang, K. Xiao, Y. Qiang, X. Zhu, L. Xu, P. Wang, C. Cui, D. Yang, _ACS Nano_ **2017** , _11_ , 9176. 

- [167] J. Jiménez-López, B. M. D. Puscher, D. M. Guldi, E. Palomares, _J. Am. Chem. Soc._ **2020** , _142_ , 1236. 

**2104030 (19 of 20)** 

_Adv. Energy Mater._ **2022** , _12_ , 2104030 

© 2022 Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.advenergymat.de** 

- [168] Y. Dong, W. Li, X. Zhang, Q. Xu, Q. Liu, C. Li, Z. Bo, _Small_ **2016** , _12_ , 1098. 

- [169] S. Zhang, H. Si, W. Fan, M. Shi, M. Li, C. Xu, Z. Zhang, Q. Liao, A. Sattar, Z. Kang, Y. Zhang, _Angew. Chem., Int. Ed._ **2020** , _59_ , 11573. 

- [170] Q. Dong, C. Zhu, M. Chen, C. Jiang, J. Guo, Y. Feng, Z. Dai, S. K. Yadavalli, M. Hu, X. Cao, Y. Li, Y. Huang, Z. Liu, Y. Shi, L. Wang, N. P. Padture, Y. Zhou, _Nat. Commun._ **2021** , _12_ , 973. 

- [171] B. Chen, H. Chen, Y. Hou, J. Xu, S. Teale, K. Bertens, H. Chen, A. Proppe, Q. Zhou, D. Yu, K. Xu, M. Vafaie, Y. Liu, Y. Dong, E. H. Jung, C. Zheng, T. Zhu, Z. Ning, E. H. Sargent, _Adv. Mater._ **2021** , _33_ , 2103394. 

- [172] M. Zhang, M. Ye, W. Wang, C. Ma, S. Wang, Q. Liu, T. Lian, J. Huang, Z. Lin, _Adv. Mater._ **2020** , _32_ , 2000999. 

- [173] X. Chen, W. Xu, N. Ding, Y. Ji, G. Pan, J. Zhu, D. Zhou, Y. Wu, C. Chen, H. Song, _Adv. Funct. Mater._ **2020** , _30_ , 2003295. 

- [174] J. Dou, C. Zhu, H. Wang, Y. Han, S. Ma, X. Niu, N. Li, C. Shi, Z. Qiu, H. Zhou, Y. Bai, Q. Chen, _Adv. Mater._ **2021** , _33_ , 2102947. 

- [175] T. J. Macdonald, A. J. Clancy, W. Xu, Z. Jiang, C.-T. Lin, L. Mohan, T. Du, D. D. Tune, L. Lanzetta, G. Min, T. Webb, A. Ashoka, R. Pandya, V. Tileli, M. A. McLachlan, J. R. Durrant, S. A. Haque, C. A. Howard, _J. Am. Chem. Soc._ **2021** , _143_ , 21549. 

- [176] A. Agresti, A. Pazniak, S. Pescetelli, A. Di Vito, D. Rossi, A. Pecchia, M. Auf der Maur, A. Liedl, R. Larciprete, D. V. Kuznetsov, D. Saranin, A. Di Carlo, _Nat. Mater._ **2019** , _18_ , 1228. 

- [177] C.-C. Lee, C.-I. Chen, Y.-T. Liao, K. C.-W. Wu, C.-C. Chueh, _Adv. Sci._ **2019** , _6_ , 1801715. 

- [178] U. Ryu, S. Jee, J.-S. Park, I. K. Han, J. H. Lee, M. Park, K. M. Choi, _ACS Nano_ **2018** , _12_ , 4968. 

- [179] D. Shen, A. Pang, Y. Li, J. Dou, M. Wei, _Chem. Commun._ **2018** , _54_ , 1253. 



**Zhi-Wen Gao** is currently a Ph.D. candidate in the Department of Electrical and Electronic Engineering at the University of Hong Kong. He received his B.S. degree in 2015 and M.S. in 2018 at Tianjin University. His current research interests mainly focus on the design and synthesis of nanocrystals and perovskites, as well as structure optimization of perovskite optoelectronic device. 



**Yong Wang** obtained his B.E. degree at Sichuan University (2012) and completed his Ph.D. degree at Xi’an Jiaotong University in 2017, followed by working as a Postdoctoral Fellow at Shanghai Jiaotong University, The University of Hong Kong, and Linköping University. His current research interests focus on the coupling relationships among microstructure, physicochemical properties, and device performance in halide lead perovskite for various optoelectronic applications. 



**Wallace C. H. Choy** is a Full Professor in the Department of EEE, HKU. His research interests cover organic/inorganic optoelectronic devices, metal oxides, and nanomaterial devices. He has published more than 250 peer-reviewed papers, several book chapters, patents, and edited one book. He was recognized as top 1% of most-cited scientists in Thomson Reuter's Essential Science Indicators from 2014 to 2020. He is named as one of the "Highly Cited Researchers" by Clarivate Analytics in 2018. He is an elected fellow of OSA/Optica. 

**2104030 (20 of 20)** 

_Adv. Energy Mater._ **2022** , _12_ , 2104030 

© 2022 Wiley-VCH GmbH 

