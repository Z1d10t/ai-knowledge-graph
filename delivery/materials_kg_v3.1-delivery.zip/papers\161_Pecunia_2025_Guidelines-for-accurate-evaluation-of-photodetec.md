# Guidelines for accurate evaluation of photodetectors based on emerging semiconductor technologies

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Photonics |
| 年份 | 2025 |
| 引用量（Semantic Scholar） | 182 |
| 作者 | V. Pecunia, Thomas D. Anthopoulos, A. Armin, B. Bouthinon, Mario Caironi, A. Castellanos-Gomez, Yong-Sheng Chen, Kilwon Cho et al. |
| DOI | 10.1038/s41566-025-01759-1 |
| 源文件 | 061_Pecunia_2025_Guidelines-for-accurate-evaluation-of-photodetec.pdf |

---
## **nature photonics** 

**Consensus Statement** 

https://doi.org/10.1038/s41566-025-01759-1 

# **Guidelines for accurate evaluation of photodetectors based on emerging semiconductor technologies** 

|Received: 2 March 2025|**A list of authors and their affiliations appears at the end of the paper**|
|---|---|
|Accepted: 15 August 2025||
|Published online: 3 November 2025|Photodetector technologies based on emerging semiconductors—for<br>|
|Check for updates|example, organic semiconductors, halide perovskites, quantum dots,<br>low-dimensional semiconductors and metal oxides—hold considerable|
||promise for next-generation optoelectronics. However, the breadth and<br>multidisciplinarity of this field, alongside its diverse range of applications,<br>have resulted in inconsistent performance characterization and reporting<br>practices, hindering the effective benchmarking of these technologies.<br>Here we present a consensus among researchers from academia and<br>industry on accurately capturing the key performance metrics of<br>photodetectors based on emerging semiconductors and utilizing the<br>photoelectric effect. We analyse their underlying assumptions, discuss<br>common misunderstandings, and provide guidelines for accurate<br>characterization and reporting. Additionally, we discuss the benchmarking<br>of these photodetector technologies with respect to diverse applications.<br>We expect that these comprehensive guidelines for characterization,<br>reporting and benchmarking will accelerate and streamline further<br>advancements in the field, propelling emerging photodetector technologies<br>towards their full potential.|



Recent years have witnessed a surge in photodetector research based on emerging semiconducting materials (for example, organic semiconductors, halide perovskites and derivatives, quantum dots, two-dimensional semiconductors, metal oxides and carbon nanotubes<sup>1–11</sup> ), with a focus on devices relying on photocarrier generation and extraction within the device stack (internal photoelectric effect; Supplementary Notes 1 and 2). 

Technological advances are tied to accurate performance characterization and benchmarking. However, the literature on emerging photodetector technologies frequently exhibits inconsistencies in characterization and reporting, posing challenges for benchmarking. These inconsistencies may partly stem from the diverse fields involved in developing these technologies, as well as the emergence of new and distinctive effects, creating difficulties in establishing a common language. Consistency issues also arise from the diversity of 

target applications, technologies and spectral ranges, as well as the knowledge gap between academic and industrial research. Academic efforts have often focused on optimizing a narrow set of performance metrics, which may not always align with the broader application needs pursued by industry. Although a few publications have offered valuable insights into some of these issues<sup>12–16</sup> , a comprehensive examination covering the characterization, reporting and benchmarking of all key performance parameters for emerging photodetector technologies (alongside detailed guidelines) is currently missing. 

Since these challenges impact a vast research community and, therefore, require collective discussion, we have come together as a team representing diverse streams in emerging photodetector technologies, spanning both academia and industry. On the basis of a collaborative effort, we present a Consensus Statement providing comprehensive guidelines for accurate performance 

e-mail: vincenzo_pecunia@sfu.ca; thomas.anthopoulos@manchester.ac.uk 

Nature Photonics | Volume 19 | November 2025 | 1178–1188 

**1178** 

**Consensus Statement** 

https://doi.org/10.1038/s41566-025-01759-1 



<!-- Start of picture text -->
a b<br>Fast sweep<br>Slow sweep<br>Applied voltage<br>Measured current<br>Voltage (arb. units) Time (arb. units)<br>Current (arb. units) Voltage (arb. units)<br>[current (arb. units)]log10<br><!-- End of picture text -->

**Fig. 1 | Dark-current diagnostics. a** , Double-sweep current–voltage curves that may be observed from a photodiode in the dark, revealing sweep-rate dependence and hysteresis. **b** , Transient dark-current effects that may occur following step-voltage application. 

characterization, reporting and benchmarking for emerging photodetector technologies. Detailed tabulated guidelines are provided in Supplementary Tables 1–13. 

### **Dark current** 

Current–voltage sweeps are typically used to characterize the dark current ( _I_ dark) in emerging photodetector technologies (Supplementary Notes 3 and 4). However, this method is unsuitable if transient effects occur during current–voltage sweeps (Fig. 1a; for example, due to charge trapping, capacitive charging/discharging or ion/defect migration)<sup>16,17</sup> . Although minimizing these effects is essential for most application scenarios and requires suitable mitigation strategies<sup>16,18</sup> , such strategies may not be fully developed for early stage technologies that otherwise show promise. In cases where such transient effects are present and mitigation strategies are still under development, accurate _I_ dark measurements require sufficient time for the current to stabilize after applying a voltage<sup>19,20</sup> (Fig. 1b). Moreover, reporting the transient behaviour of the dark current on step-voltage application (Fig. 1b) is valuable for optimizing photodetectors targeting imaging applications (Supplementary Note 5). 

Early stage emerging photodetector technologies may also display _I_ dark drift during the measurement of various other performance parameters. In such cases, monitoring the evolution of _I_ dark over extended periods is crucial. For reliable benchmarking, we advise adopting sufficiently long stabilization periods to ensure that variations in _I_ dark remain below 5% from the beginning to the end of a spectral responsivity measurement (Supplementary Note 6). Accurate reporting should include the time evolution of _I_ dark over this timescale (with the photodetector biased as in a spectral responsivity measurement), with appropriate additional checks to confirm the minimal presence of longer-term transients. 

In analysing device performance, it is often necessary to determine the areal dark-current density ( _j_ dark), especially in devices with charge transport in the out-of-plane direction (Supplementary Note 7). A simple normalization of the measured _I_ dark by the nominal active area is often inaccurate for estimating _j_ dark for emerging photodetector technologies<sup>13</sup> . This is because they often feature semiconducting and/or charge transport layers extending considerably beyond the interelectrode region, leading to dark-current contributions from outside this area, alongside a spatially non-uniform _j_ dark. Therefore, for accurately determining _j_ dark, we recommend fabricating photodetectors with varying electrode and active area sizes to identify the appropriate area for normalizing _I_ dark. 

As the _I_ dark of emerging photodetector technologies may be strongly influenced by temperature, it is important to report 

the temperature at which it is measured and the _I_ dark values across the temperature range relevant to the target application to enable meaningful benchmarking. 

### **Responsivity and external quantum efficiency** 

To accurately determine responsivity and external quantum efficiency (EQE; Supplementary Note 3), the incident optical power spectrum should be measured and consistently monitored with a calibrated reference detector (Supplementary Notes 8 and 9 and Supplementary Fig. 1). Moreover, the illuminated area must be strictly defined for both reference detector and photodetector under test. An ideal solution is to use an aperture that covers 95%–100% of the active area of the photodetector under test, ensuring that the irradiance within this area remains spatially uniform within 5% of its maximum (Fig. 2a, Supplementary Fig. 2 and Supplementary Notes 8 and 10). Overfilling the active area without using such an aperture may cause mischaracterization, as photons absorbed outside the active area can contribute to the photocurrent<sup>21</sup> (Fig. 2a). Moreover, although responsivity and EQE are generally properties of a photodetector as a whole, underfilling the active area assesses only the response of the illuminated portion, potentially misrepresenting the device performance (particularly for emerging photodetector technologies that often exhibit spatial non-uniformities). This problem is exacerbated when the underfilling beam reaches irradiance levels outside the photodetector’s linear dynamic range (LDR) in some regions of its cross-section. This leads to spatially varying responsivity and EQE due to non-uniform illumination (Supplementary Note 8). In general, illumination should be collimated (or pseudo-collimated) and normal to the photodetector plane (unless the angular response is being measured) to avoid inaccuracies due to the angular interplay among the light source, reference detector and photodetector under test<sup>22</sup> . 

For devices with instability or appreciable transient effects, monitoring _I_ dark throughout a responsivity/EQE measurement is necessary to accurately determine the photocurrent (Fig. 2b). Although modulated responsivity/EQE measurements purge the current recorded under the illumination of contributions from a slowly varying background, they are nonetheless affected by drifts in device characteristics. Therefore, for devices with instability or appreciable transient effects, allowing them to stabilize before a responsivity/EQE measurement is recommended<sup>23–25</sup> . Moreover, in modulated measurements to determine the continuous-wave responsivity/EQE, the modulation frequency should be much smaller than the photodetector bandwidth (Fig. 2c,d), with responsivity/EQE varying ≤5% across a frequency decade centred on the modulation frequency. 

The spectral responsivity _R_ ( _λ_ ) ( _λ_ , wavelength) and EQE spectrum should be characterized over the entire spectral range of the incident 

Nature Photonics | Volume 19 | November 2025 | 1178–1188 

**1179** 

**Consensus Statement** 

https://doi.org/10.1038/s41566-025-01759-1 



<!-- Start of picture text -->
a<br>Illumination source<br>Transparent top electrode<br>Semiconductor<br>Extra current<br>contribution Photogeneration volume<br>Extra current contribution<br>D L D L Bottom electrode<br>Mask<br>+<br>–<br>D L D L<br>b c d<br>P i( t )<br>(i) Continuous<br>wave (i)<br>P i( t )<br>(ii) High modulation<br>frequency<br>(ii)<br>Dark current<br>Total current<br>Time (arb. units) Wavelength (arb. units) Time (arb. units)<br>Responsivity (arb. units)<br>Current (arb. units)<br>Current/optical power (arb. units)<br><!-- End of picture text -->

**Fig. 2 | Challenges in responsivity/EQE characterization. a** , Left: overfilling incident beam causing inaccurate responsivity/EQE determination due to carrier generation beyond the nominal active area, extending into a peripheral region of feature size _D_ L. Right: aperture adoption for accurate responsivity/ EQE determination. **b** , Importance of monitoring the time-dependent dark current for accurate responsivity/EQE measurements, during which the device 

is subjected to multiple optical pulses with power _P_ i( _t_ ). **c** , Impact of unsuitable modulation frequency on modulated measurements for continuous-wave responsivity/EQE characterization. **d** , Time-domain illustration of the effect displayed in **c** . Top: suitable modulation frequency, allowing the accurate determination of the continuous-wave responsivity/EQE from a modulated measurement. Bottom: unsuitable modulation frequency. 

optical signals relevant to the application under consideration (reference spectral range; Supplementary Note 3 and Supplementary Fig. 3), with the incident optical power at each wavelength consistently monitored with a calibrated reference detector. For benchmarking purposes, we recommend referring to the conventional reference spectral ranges presented in Supplementary Table 14. 

In the literature covering spectrally selective photodetectors (Supplementary Note 3 and Supplementary Fig. 3), the full width at half maximum of the spectral responsivity or EQE spectrum (FWHMR or FWHMEQE) is sometimes incorrectly considered as a parameter that should necessarily be minimized to achieve high performance. In fact, the necessary FWHMR and FWHMEQE depend on the application of interest. Therefore, emphasis on their minimization should only be reserved to spectrally selective photodetectors targeting multispectral or hyperspectral light sensing. Furthermore, photodetectors lacking a clear responsivity or EQE passband (that is, having a responsivity/ EQE that may not reach half maximum or exhibiting multiple passbands within the reference spectral range) are sometimes erroneously referred to as spectrally selective. For accurate reporting, only devices with a well-defined FWHMR or FWHMEQE should be presented as spectrally selective. 

### **Photoconductive gain versus EQE** 

In reports on devices with injecting electrodes, the emerging photodetector literature sometimes incorrectly uses photoconductive gain ( _G_ ) and EQE interchangeably (Supplementary Notes 3 and 11). In fact, the two are conceptually and quantitatively distinct: EQE measures the number of electrons collected at the contacts per incident photon per unit time, whereas photoconductive gain refers to the number of collected carriers (as a result of illumination) per photogenerated electron–hole pair (Supplementary Notes 3 and 12). 

Furthermore, high apparent EQE (≫100%) and _G_ (≫1) in devices with injecting electrodes do not necessarily indicate superior optoelectronic performance. In devices without photoconductive gain, a high EQE genuinely reflects excellent optoelectronic performance. However, devices with a large photoconductive gain often suffer from a slow response (potentially, persistent changes in conductivity)<sup>25</sup> , making the gain–bandwidth product a more appropriate benchmarking metric<sup>26–28</sup> . Moreover, gain can increase dark current and noise (neglecting this can lead to overestimated specific detectivity and dynamic range<sup>12,29</sup> ). Additionally, gain typically depends on trap filling, which can introduce nonlinear irradiance dependence of the photoresponse<sup>30,31</sup> . Therefore, superlative claims based solely on high apparent EQE and 

Nature Photonics | Volume 19 | November 2025 | 1178–1188 

**1180** 

**Consensus Statement** 

https://doi.org/10.1038/s41566-025-01759-1 



<!-- Start of picture text -->
a b<br>I o ∝  P i I o ∝  P i α<br>I o,M<br>Linear<br>LDR<br>1<br>I o,m<br>Measured Nonlinear<br>Linear fit<br>log10[optical power (arb. units)] log10[optical power (arb. units)]<br>c d<br>I o ∝  P i α Measured<br>Possible trend lines<br>I o,M,app<br>α  = 1 LDRapp 1<br>I o,m,app<br>Noise floor<br>log10[optical power (arb. units)] log10[optical power (arb. units)]<br>α  = 0.6<br>α  = 1<br>α  = 1.4<br>α  = 0.6<br>α  = 1.4<br>[output current (arb. units)]log10 [output current (arb. units)]log10<br>[responsivity (arb. units)]log10<br>[output current (arb. units)]log10<br><!-- End of picture text -->

**Fig. 3 | Linearity and LDR in photodetectors. a** , Representative current– power curve for a linear photodetector and key linearity-related parameters. **b** , Comparison of current–power curves for linear ( _α =_ 1) and nonlinear ( _α_ ≠ 1) photodetectors. **c** , Responsivity versus optical power corresponding to **b** . 

**d** , Sketch of an experimental current–power curve (solid line) for a linear photodetector. Outside the measured range, the curve might evolve as linear or nonlinear (dotted traces). 

_G_ in such devices should be avoided. Instead, their evaluation should consider how gain holistically impacts device performance. 

From a practical perspective, the emphasis on gain versus speed of response varies with application. For instance, fast response is critical for high-speed communication, whereas higher gain may be more important for imaging under low irradiance. Moreover, recent work has highlighted photodetectors with very slow recovery times for use in neuromorphic devices<sup>32</sup> . Therefore, application-specific contextualization is required when photoconductive gain is reported. 

### **Linearity and LDR** 

A misunderstanding often encountered in the emerging photodetector literature is that straight light current ( _I_ o)–optical power ( _P_ i) characteristics plotted on a double-logarithmic scale (Fig. 3a) imply linearity (Supplementary Note 3 and Supplementary Fig. 4). In fact, such straight characteristics with slopes _α_ different from unity correspond to the power law _Io_ ∝ _P_<sup>_α_</sup> _i_<sup>, where</sup><sup>_α_≠ 1 implies nonlinearity</sup> (Fig. 3b). To prevent this misunderstanding, researchers should report the slope _α_ of the log[ _I_ o]–log[ _P_ i] dataset fit (Fig. 3b). The conclusion of linearity should only be drawn when _α_ is practically indistinguishable from unity. In general, the acceptable deviation from unity depends on the application. For benchmarking purposes, however, we recommend referring to a photodetector as strictly linear 

if _α_ falls within [0.99, 1.01] when rounded to the second decimal place, and as quasi-linear if _α_ falls within [0.97, 0.99) and (1.01,1.03] (Supplementary Note 13 and Supplementary Fig. 5). Additionally, the responsivity–optical power plot should be provided for further validation (Fig. 3c). 

A related common misconception is the quantification of the LDR for photodetectors with straight _I_ o– _P_ i characteristics on a double-logarithmic scale but for which _α_ ≠ 1. This is generally incorrect, as LDR is a concept exclusive to linear photodetectors (that is, _α =_ 1). 



<!-- Start of picture text -->
In reporting the LDR of linear photodetectors, confusion sur-<br>rounds the prefactor (20 versus 10) used in its definition, leading to<br>inconsistent values across publications. The formula to be adopted is<br>I o,M<br>LDR (1)<br>def=20log10 [ I o,m ] .<br><!-- End of picture text -->

_I_ o,M and _I_ o,m denote the maximum and minimum light current values, respectively, within which the photodetector behaves linearly (Fig. 3a). Arguments supporting a prefactor of 10 often stem from the expression of LDR in terms of optical power (that is, LDR ∝ log10[ _P_ i,M/ _P_ i,m], where _P_ i,M and _P_ i,m are the optical power values corresponding to _I_ o,M and _I_ o,m, respectively). This association with a prefactor of 10 is drawn from its use in the definition of decibels for signal power (defined as a quantity 

Nature Photonics | Volume 19 | November 2025 | 1178–1188 

**1181** 

**Consensus Statement** 

https://doi.org/10.1038/s41566-025-01759-1 



<!-- Start of picture text -->
a 103 Error (%)106 b c<br>10% 105 102<br>102 1% 104<br>101 1,000% 101032 P i 101<br>100 100% 10,000% 101010 100<br>NEP<br>10–1 10–1<br>100 101 102 103 log10[frequency (arb. units)] log10[optical power (arb. units)]<br>Bandwidth (Hz)<br>d e f<br>0.8 8<br>B  = 10–1 Hz<br>B  = 100 Hz<br>B  = 101 Hz<br>0.6 B  = 102 Hz 6 B  = 10–1 Hz<br> Approx. B  = 100 Hz<br>0.4 4 BB  = 10 = 1012 Hz Hz<br>Approx.<br>0.2 2<br>100 101 102 103 104 100 101 102 103 104 100 101 102 103 104<br>Frequency (Hz) Frequency (Hz) Frequency (Hz)<br>Frequency (Hz)<br>Signal-to-noise ratio<br>[ f ) (arb. units)](log S 10tot<br>[ f ) (arb. units)]log( S 10tot<br>1/2Noise current/ (arb. units) B Specific detectivity (arb. units)<br><!-- End of picture text -->

**Fig. 4 | Noise, NEP and detectivity. a** , Relative error in estimating _i_<sup>2</sup> _n_ , _r_ . _m_ . _s_ .<sup>if the</sup> formula _S_ n( _f_ ) _B_ is used instead of the exact integral (Supplementary Note 16) to quantify the power of a pink-noise source ( _S_ n( _f_ ) ∝ 1/ _f_ ). **b** , Power spectral density of noise superimposed on a modulated signal with decreasing amplitude, eventually becoming indistinguishable from noise. **c** , Corresponding signal-tonoise ratio and NEP determination. **d** , Representative power spectral density of superimposed white and pink-noise components. **e** , Corresponding root-meansquare noise integrated over a bandwidth _B_ , normalized to<sup><u>√</u></sup> _B_ . These results 

show that normalizing the root-mean-square noise by<sup><u>√</u></sup> _B_ is not meaningful in the pink-noise-dominated region. The trace labelled ‘approx.’ refers to the generally inaccurate approximation _in_ , _r_ . _m_ . _s_ = √ _Sn_ ( _f_ ) _B_ . **f** , Specific detectivity corresponding to the data in **d** and **e** , calculated as _D_<sup>∗def</sup> = _D_<sup><u>√</u></sup> _AB_ assuming unity responsivity and area, revealing unreliable _D_ * values in the pink-noise-dominated region. 

quadratically dependent on the signal) in signal theory. However, this perspective is inaccurate because, in the context of LDR, optical power serves as a proxy for photon flux, which does not have a quadratic dependence on the signals at play (for example, the photocurrent and the number of incident photons). 

To address the ambiguity often found in the literature concerning the determination of _I_ o,M and _I_ o,m to calculate the LDR, the tolerable deviation _Δ_ of the measured dataset from linearity should be quantified: 



<!-- Start of picture text -->
±∆def= d logd log1010[[ PI oi]] − 1. (2)<br><!-- End of picture text -->

Although _Δ_ is generally application dependent, _Δ_ = 0.01 and _Δ_ = 0.03 are recommended for benchmarking emerging photodetector technologies that are strictly linear and quasi-linear, respectively (Supplementary Note 13). 

_I_ o,m is sometimes erroneously equated to _I_ dark, or the lowest light current measured with the equipment at hand, or the (calculated or measured) root-mean-square current noise _i_ n,r.m.s. (noise floor). Similarly, _I_ o,M is often incorrectly equated to the maximum light current measured with the equipment at hand. These approaches are incorrect because LDR is defined with respect to the actual extrema of a photodetector’s linear range, instead of estimated values. Moreover, without experimental validation, it is incorrect to assume that the linear trend observed at higher optical powers extends to _i_ n,r.m.s. (Fig. 3d). If limitations of the characterization apparatus prevent reaching the actual extrema of the linear range, the apparent LDR (LDRapp) should be reported instead, referring to it as such (Fig. 3d). LDRapp extends between the apparent minimum and maximum measured light current values ( _I_ o,m,app and _I_ o,M,app, respectively) over which linearity holds (that is, _α_ within [0.99, 1.01] for strictly linear photodetectors or [0.97, 0.99) and (1.01,1.03] in the quasi-linear case): 



<!-- Start of picture text -->
I o,M,app<br>LDRapp (3)<br>def=20 log10 [ I o,m,app ] .<br><!-- End of picture text -->

By definition, LDR ≥ LDRapp. For benchmarking, if _I_ o,m,app or _I_ o,M,app is determined by deviation from linearity, it should be calculated through equation (2) with _Δ_ = 0.01 or _Δ_ = 0.03. 

Although linear photodetector operation with a wide LDR is essential for most applications, some emerging areas (for example, in-sensor computing and neuromorphic devices) may benefit from nonlinear photodetectors<sup>33–35</sup> . Therefore, nonlinear photodetector studies should contextualize their findings within the latter areas, benchmarking their devices exclusively against the relevant literature on nonlinear photodetectors. 

### **Noise** 

To avoid misreporting the noise performance of emerging photodetector technologies, it is essential to quantify and correct for instrumentation noise as part of the characterization of their noise power spectral density, alongside reporting all relevant experimental quantities (Supplementary Notes 3 and 14 and Supplementary Fig. 6). 

The commonly used relation <u>√</u> _Sn_ ( _f_ ) _B_ for quantifying the the root-mean-square value of the intrinsic photodetector noise, _i_ n,r.m.s., over an equivalent noise bandwidth _B_ (Supplementary Note 15) is correct only if the power spectral density of the intrinsic photodetector noise ( _S_ n( _f_ ), where _f_ is the frequency) is frequency independent (white noise) over the frequency range of interest. For instance, for pink noise ( _S_ n( _f_ ) ∝ 1/ _f_<sup>β</sup> , with the constant β typically ranging from 0.8 to 1.5)<sup>36–38</sup> , this relationship does not generally apply (potentially leading to large errors; Fig. 4a) and only approximately holds when _B_ ≪ _f_ (Supplementary Note 16). Therefore, quantifying _i_ n,r.m.s. as 

Nature Photonics | Volume 19 | November 2025 | 1178–1188 

**1182** 

**Consensus Statement** 

https://doi.org/10.1038/s41566-025-01759-1 

<u>√</u> _Sn_ ( _f_ ) _B_ requires prior validation of the frequency independence of _S_ n or other relevant assumptions (for example, _B_ ≪ _f_ for dominant pink noise). 

In general, _i_ n,r.m.s. also depends on device geometry. For instance, in vertical photodiodes with no photoconductive gain, _in_ , _r_ . _m_ . _s_ . ∝<sup><u>√</u></sup> _A_ ( _A_ , nominal in-plane device area) when shot noise dominates. In such cases, normalizing _i_ n,r.m.s. by<sup><u>√</u></sup> _A_ is both useful and accurate for cross-device comparisons. However, the functional dependence of _i_ n,r.m.s. on geometric parameters is not universally of the form<sup><u>√</u></sup> _A_ (Supplementary Note 17). Therefore, normalizing _i_ n,r.m.s. by<sup><u>√</u></sup> _A_ does not generally yield a geometry-independent noise assessment. In other words, using such normalization to compare the intrinsic noise of photodetectors whose _i_ n,r.m.s. does not solely depend on device geometry via<sup><u>√</u></sup> _A_ would lead to erroneous conclusions. For this reason, accurate comparisons of geometry-normalized photodetector noise can only be made between devices with the same geometry and dominant noise mechanisms. Normalizing noise performance by geometric parameters requires prior experimentation and modelling to establish the specific dependence of _i_ n,r.m.s. on those parameters (Supplementary Note 18). 

Experiments on emerging photodetector technologies have revealed that their noise power spectral density cannot be accurately determined through model formulas for white-noise sources—for example, via the shot-noise model<sup>39–41</sup> . However, we acknowledge that many researchers developing emerging photodetector technologies may lack access to apparatus for characterizing noise power spectral density. In such cases, reporting lower-limit noise values based on white-noise models must be accompanied by an explicit acknowledgement of their theoretical nature, with appropriate labelling (for example, using _i_ n,r.m.s.,theor. to denote the theoretical _i_ n,r.m.s.) to distinguish them from the experimental data. Importantly, such theoretical values should not be used as the basis for superlative performance claims, nor should they be compared with experimentally determined noise values from other technologies. 

When theoretical, lower-limit noise values based on white-noise models are determined, choosing the appropriate model is crucial. For instance, thermal noise is often omitted without verifying whether this approximation is correct. Moreover, to calculate shot noise in devices with photoconductive gain _G_ , the basic shot-noise model _in_ , _r_ . _m_ . _s_ , _theor_ . = √2 _qI_ dark _B_ ( _q_ , elementary charge) is not applicable and this alternative equation must be used<sup>29,42,43</sup> . 



<!-- Start of picture text -->
in , r . m . s ., theor . = √2 qI dark GFB (4)<br><!-- End of picture text -->

Here _F_ is the Fano factor ( _F_ = 1 if charge transport is due to uncorrelated, independent events). Using _in_ , _r_ . _m_ . _s_ , _theor_ . = √2 _qI_ dark _B_ instead of equation (4) can lead to substantial noise miscalculations (thereby introducing substantial inaccuracies in derived quantities), given that typically _G_ ≫ 1. To mitigate confusion regarding the choice of models for calculating theoretical white-noise limits, we recommend using the following formula. 



<!-- Start of picture text -->
in , r . m . s , theor . = √2 qI dark GFB  + 4 kBTB / R ( dark PD) (5)<br><!-- End of picture text -->

Here _R_<sup>(</sup> dark<sup>PD) is the differential photodetector resistance (d</sup><sup>_V_bias/d</sup><sup>_I_dark)</sup> in the dark around the same operating voltage _V_ bias used for _I_ dark and photoresponse measurements, _T_ is the absolute temperature and _k_ B is Boltzmann’s constant. We encourage reporting the theoretical white-noise baseline using equation (5)—explicitly presenting it as a theoretical limit—to facilitate cross-study comparisons of theoretical noise performance. However, equation (5) should not be considered a substitute for experimental noise measurements, which remain essential for accurately evaluating noise performance. 

### **Noise-equivalent power and detectivity** 

To quantify the noise-equivalent power (NEP) and detectivity ( _D_ ; Supplementary Note 3 and Supplementary Fig. 7), we recommend acquiring the photodetector output power spectral density (purging it from instrument noise; Supplementary Note 14) as a modulated optical signal of root-mean-square optical power _P_ i,r.m.s. is applied, centred at frequency _f_ and spanning a bandwidth _B_ (Fig. 4b,c). The _P_ i,r.m.s. yielding a photodetector output signal equal to the background noise power spectral density quantifies the photodetector’s NEP at that frequency and bandwidth, whereas its reciprocal gives _D_ . 

Alternatively, if suitable conditions are verified, NEP and _D_ can be determined from the ratio between the measured _i_ n,r.m.s. (for the selected frequency and bandwidth, which must be specified) and the measured responsivity (Supplementary Note 3). This approach is applicable only if the responsivity is measured at an optical power approaching NEP, which requires experimental validation and reporting. If linearity is assessed only at optical powers far above the NEP due to apparatus limitations, it is uncertain whether the apparent responsivity _R_ app measured within the apparent LDR can be used to determine NEP and _D_ . In such cases, the ratio _R_ app/ _i_ n,r.m.s. should be referred to as the apparent detectivity and labelled _D_ app. Correspondingly, the apparent NEP, NEPapp, is calculated as 1/ _D_ app. Importantly, if a photodetector is nonlinear as _P_ i,r.m.s. approaches NEP, its responsivity varies with optical power in that region; hence, using the responsivity measured at an arbitrary optical power far above the NEP would lead to inaccurate NEP and _D_ determination. In such cases, neither _D_ app nor NEPapp is defined, and direct experimental evaluation (Fig. 4b,c) is the only viable approach to determining NEP and _D_ . 

For geometry- and bandwidth-independent benchmarking, the emerging photodetector literature commonly multiplies detectivity by the square root of the product of the nominal in-plane device area ( _A_ ) and noise bandwidth ( _B_ ), which defines the specific detectivity _D_<sup>∗def</sup> = _D_<sup><u>√</u></sup> _AB_ . However, this normalization is meaningful only if _i_ n,r.m.s. depends on bandwidth and geometry solely through the term<sup><u>√</u></sup> _AB_ (for example, as in vertical photodiodes with dominant shot noise). Therefore, _D_ * should be reported only after experimental validation that _i_ n,r.m.s. exhibits this specific functional dependence on bandwidth and geometry (Supplementary Note 18). 

If _i_ n,r.m.s. deviates from the<sup><u>√</u></sup> _AB_ dependence, adopting _D_ * as a benchmarking metric is misleading, as _D_ * itself depends on geometry and noise bandwidth in such cases. For instance, in reference to the photodetector with representative noise power spectral density in Fig. 4d, if one laboratory were to measure noise with _B_ = 1 Hz and another with _B_ = 100 Hz, the latter may mistakenly conclude that they have measured a superior photodetector because of the higher _D_ * (Fig. 4e,f). To overcome the limitations of the definition of _D_ * as _D_<sup><u>√</u></sup> _AB_ for cases with a non-square-root bandwidth dependence of _i_ n,r.m.s. (but confirmed dependence on device geometry via<sup><u>√</u></sup> _A_ ), we recommend using a modified specific detectivity, _D_<sup>∗̄</sup> _B_<sup>, referenced to a fixed</sup> bandwidth ̄ _B_ . 



<!-- Start of picture text -->
D ∗̄ B ( f ,  λ ) def= R  ( f ,  λ ,  Pi , r . m . s . = NEP) √ A / in , r . m . s .( f ,̄  B ) (6)<br><!-- End of picture text -->

Here _R_ ( _f_ , _λ_ , _P_ i,r.m.s. = NEP) is the responsivity measured at modulation frequency _f_ , wavelength _λ_ and _P_ i,r.m.s. = NEP. ̄ _B_ = 1 Hz is a convenient choice for benchmarking purposes, especially for applications operating at frequencies above 10 Hz. 

In general, for a bandwidth- and geometry-independent comparison of detection capabilities across photodetectors for which _i_ n,r.m.s. is not proportional to<sup><u>√</u></sup> _AB_ , a different normalization would be necessary. In such cases, normalization should incorporate the specific functional dependencies of _i_ n,r.m.s. on bandwidth and geometry for the devices at hand. For the same reason, when dealing with photodetectors with distinct functional dependencies on geometry and bandwidth, it is advisable to consider detectivity (or NEP) rather than specific 

Nature Photonics | Volume 19 | November 2025 | 1178–1188 

**1183** 

**Consensus Statement** 

https://doi.org/10.1038/s41566-025-01759-1 



<!-- Start of picture text -->
a b c<br>P i( t ) P i( t ) P i( t )<br>1 Invalid  τ rise,  τ fall Asymptotic<br>Steady state R  >  R 0 Invalid  τ rise,  τ fall<br>R  =  R 0 τ rise τ fall R  >  R 0<br>0<br>Time (arb. units) Time (arb. units) Time (arb. units)<br>d e f<br>P i( t ) Eδ P i( t ) f 3dB<br>R 0<br>0 R 0<br>2<br>R 0 = Qδ –20 Z L<br>Eδ<br>P i I o<br>Qδ t t<br>Invalid  τ rise,  τ fall –40 PD<br>R  <  R 0 τ r, δ<br>Full transient<br>Time (arb. units) Time (arb. units) log10[frequency (arb. units)]<br>Photocurrent (arb. units) Photocurrent (arb. units) Photocurrent (arb. units)<br>[ f )/]20log( R 100<br>Photocurrent (arb. units)<br>Photocurrent (arb. units)<br><!-- End of picture text -->

**Fig. 5 | Speed of response. a** , Response to a rectangular optical pulse, alongside the illustration of rise and fall times. **b** , Response to a rectangular optical pulse with non-monotonic transients. **c** , Although shorter pulses may suggest that steady state is nearly reached, verification of the responsivity under illumination reveals a non-ideal transient. **d** , Example of incorrect extraction of rise and fall 

times for optical pulses that do not allow steady state to be reached. **e** , Response to an optical impulse. **f** , Bode plot of the responsivity of a photodetector behaving as an ideal linear first-order system under sinusoidally modulated light. _Z_ L, load impedance; PD, photodetector. 

detectivity for a meaningful comparison of their detection limits. Indeed, in such cases, _D_ * and _D_<sup>∗̄</sup> _B_<sup>could be easily manipulated by varying</sup> device dimensions or bandwidth. 

Finally, a widespread feature of specific detectivity reports on emerging photodetector technologies is the reliance on noise values obtained from theoretical noise models (for example, shot and thermal noise equations) instead of experimental noise measurements. This approach may be inaccurate up to several orders of magnitude, especially if pink noise dominates. If an apparatus for characterizing the power spectral density of photodetector noise is not readily available, resorting to such models is acceptable only if the resultant detectivity values are presented as theoretical estimates and labelled accordingly. It remains crucial, however, to base estimates on correct model equations. For instance, in devices with photoconductive gain, neglecting the impact of gain on shot noise results in exaggerated detectivity values<sup>12</sup> . Therefore, provided that the assumptions underlying equation (6) hold, it is useful, for benchmarking purposes, to report the theoretical specific detectivity in the white-noise limit, _D_<sup>∗</sup> _theor_ .<sup>(</sup><sup>_f_,</sup><sup>_λ_), using the</sup> following equation. 



<!-- Start of picture text -->
D ∗ theor . ( f ,  λ ) def= R  ( f ,  λ ,  Pi , r . m . s . = NEP) √ A /√2 qI dark GF  + 4 kBT / R ( dark PD) (7)<br><!-- End of picture text -->

Even in studies presenting experimental detectivity assessments, reporting _D_<sup>∗</sup> _theor_ .<sup>is encouraged to facilitate identifying deviations from</sup> ideality and allow cross-study comparisons. However, superlative claims regarding high _D_<sup>∗</sup> _theor_ .<sup>compared with experimentally measured</sup> _D_ * or _D_<sup>∗̄</sup> _B_<sup>must be avoided, as they risk misrepresentation.</sup> 

### **Speed of response** 

An important challenge in reporting and benchmarking the speed of response (Supplementary Note 3) of emerging photodetector technologies is that it generally depends on the applied voltage, load impedance, continuous-wave incident optical power and wavelength. Therefore, the speed of response should be characterized at several 

representative continuous-wave incident optical power levels within the LDR, with all the aforementioned parameters explicitly reported. 

Characterization of speed of response in terms of the 10%–90% rise and fall times ( _τ_ rise and _τ_ fall, respectively) on the application of a rectangular optical pulse (Fig. 5a, Supplementary Note 3 and Supplementary Fig. 8) requires the prior verification of the assumptions underlying these quantities. First, non-monotonic photocurrent transients near the pulse edges prevent the reliable extraction of _τ_ rise and _τ_ fall (for example, Fig. 5b,c and Supplementary Notes 19 and 20). Additionally, if a steady state is not reached after the edges of the optical pulse (for example, Fig. 5d), the extracted _τ_ rise and _τ_ fall are invalid in the context of general benchmarking. Therefore, for general benchmarking, photodetector studies should ensure that, after a pulse edge, the photocurrent waveform plateaus (for benchmarking purposes, we recommend considering that a steady state is achieved for variations of <1% from the peak value) over a timescale of ≥ _τ_ r,p, where _τr_ , _p_ def= ( _τ_ rise + _τ_ fall) /2. Moreover, it is crucial to verify that the photocurrent plateau during the optical pulse is consistent with the continuous-wave responsivity _R_ 0 for the applied optical power (Fig. 5a–c). However, in application scenarios involving short-pulse-train illumination, the photocurrent may not reach a steady state, yet the device may still exhibit high effective responsivity and practical utility. In such cases, transient response characterization under realistic excitation conditions and gain–bandwidth product evaluation may provide meaningful insights for application-specific benchmarking. 

If the speed of response is characterized by applying an ultrashort optical pulse (optical impulse; Fig. 5e, Supplementary Fig. 8 and Supplementary Notes 3 and 21) and quantifying the time _τ_ r, _δ_ taken for the photocurrent to decay from 90% to 10% of its peak value following the impulse (Fig. 5e), it is crucial to verify that the ratio between the integrated photocurrent _Qδ_ and the optical impulse energy _Eδ_ (Fig. 5e) matches the continuous-wave responsivity. Reporting the energy and duration of the applied optical impulse is also essential. 

If the speed of response is characterized in terms of the 3-dB frequency under variable-frequency sinusoidally modulated illumination 

Nature Photonics | Volume 19 | November 2025 | 1178–1188 

**1184** 

**Consensus Statement** 

https://doi.org/10.1038/s41566-025-01759-1 



<!-- Start of picture text -->
a b<br>1 20 °C 40 °C<br>60 °C 80 °C<br>Activation<br>energy,  E a<br>0 Lifetime<br>Time (arb. units) 1/ T  (K –1 )<br>c d<br>Predicted Actual<br>Accelerated<br>ageing Accelerated<br>(measured)range Actual ageing<br>range<br>(measured)<br>Target  Predicted<br>operating Target<br>range operating<br>range<br>1/ T  (K –1 ) 1/ T  (K –1 )<br>Normalized responsivity ln[lifetime (arb. units)]<br>ln[lifetime (arb. units)] ln[lifetime (arb. units)]<br><!-- End of picture text -->

**Fig. 6 | Accelerated ageing tests. a** , Test monitoring responsivity as a function of temperature, quantifying the device lifetime as the time when 80% of the initial responsivity is reached. **b** , Corresponding lifetime–temperature plot, from which the activation energy of the degradation mechanism is extracted. 

**c** , Overestimation of lifetime from an accelerated ageing test in the presence of higher activation energy at higher temperatures. **d** , Underestimation of lifetime from an accelerated ageing test in the presence of a change in activation energy only over a narrow, intermediate temperature range. 

( _f_ 3dB,sin; Supplementary Notes 3 and 15 and Supplementary Fig. 9)—or square-wave modulation with appropriate signal analysis (Supplementary Note 3)—it is crucial to report a clear plateau in responsivity as a function of frequency (with variations of ≤5%) spanning at least one frequency decade in the low-frequency region (Fig. 5f). Moreover, for benchmarking, the amplitude of the applied optical waveform must be specified alongside the continuous-wave optical power component. 

Alternatively, if the 3-dB frequency is obtained by calculating the Fourier transform of the time-varying photocurrent in response to an optical impulse (defining _f_ 3dB, _δ_ ; Supplementary Note 3), it is essential to verify and report that doubling the optical impulse energy (for example, by increasing the impulse amplitude and maintaining its temporal profile) results in an output photocurrent that is identical in shape apart from proportional amplitude scaling, and that the extracted _f_ 3dB, _δ_ remains unchanged. 

If the time evolution of photocurrent with optical power can be described by a linear, first-order differential equation, then _f_ 3dB, _δ_ and _f_ 3dB,sin are equal and can be calculated from time-domain measurements as ln[9]/(2π _τ_ r, _δ_ ) and ln[9]/(2π _τ_ r,p) (ref. 44). Moreover, under the same assumption, _τ_ r, _δ_ and _τ_ r,p are equal. However, a common misconception in the emerging photodetector literature is that these relationships hold by default. In fact, although they are typically accurate for conventional photodetectors, discrepancies among _f_ 3dB, _δ_ , _f_ 3dB,sin, ln[9]/ (2π _τ_ r, _δ_ ) and ln[9]/(2π _τ_ r,p) may be as large as several orders of magnitude for emerging photodetector technologies<sup>15</sup> . This is because the different operating conditions used in measuring _f_ 3dB, _δ_ , _f_ 3dB,sin, _τ_ r, _δ_ and _τ_ r,p and possible effects (for example, charge transport and trapping) with diverse kinetics may invalidate the assumption that the time evolution of photocurrent under a time-varying optical signal can be 

described by a linear, first-order differential equation. Therefore, the aforementioned relationships among speed-of-response parameters cannot be assumed with emerging photodetector technologies until experimental validation is obtained on a case-by-case basis. 

We note that measurements involving ultrashort, high-power light pulses are more prone to triggering nonlinear effects, whereas sinusoidally modulated illumination or rectangular pulses may prevent such effects for sufficiently small excitation amplitudes. Therefore, for general benchmarking, characterizing the speed of response via small-signal sinusoidally modulated illumination or rectangular pulses is recommended, with its reporting and interpretation bounded by the considerations discussed above. However, in specialized applications involving high-intensity ultrashort pulses, characterization should prioritize excitation with pulse width and peak power matching the application’s demands (despite possible nonlinearities) to meaningfully assess the response speed and enable relevant benchmarking, whereas small-signal measurements may still offer complementary insights. 

### **Stability** 

Although the reliability of emerging photodetector technologies is critical to ensure their viability in real-world applications, reports on the stability of emerging photodetector technologies are scarce. By contrast, conventional optoelectronics adhere to standard temperature ratings—typically, 0 °C to 70 °C for standard-grade devices and –20 °C to 85 °C and –40 °C to 85 °C for extended-range and industrial-grade devices, respectively<sup>45</sup> . Their rated deployment times range from 2–3 years for low-end applications to up to ~20 years for higher-end applications<sup>45</sup> . Given the considerably less stringent characterization conditions typically adopted in studies covering emerging 

Nature Photonics | Volume 19 | November 2025 | 1178–1188 

**1185** 

**Consensus Statement** 

https://doi.org/10.1038/s41566-025-01759-1 

photodetector technologies so far, it is evident that aligning such technologies with real-world reliability objectives is a crucial aspect yet to be addressed. 

Conducting stability tests over years or decades is impractical, making accelerated ageing tests essential (Fig. 6a,b). In the research stage of emerging photodetector technologies, a desirable target is to assess suitability for real-world use in a few weeks (~1,000 h) of accelerated ageing. 

To assess reliability and readiness for commercialization, the community researching emerging photodetectors technologies is recommended to adopt standardized accelerated ageing tests already established for optoelectronics (that is, IEC-60749 (ref. 46 and other volumes in the IEC-60749 series), Telcordia GR-468-CORE<sup>47</sup> , JESD22 (ref. 48 and other volumes in the JESD22 series); AEC-Q100 (ref. 49) and ECSS standards<sup>50</sup> ; Supplementary Note 22 and Supplementary Table 15). In approaching the application of these standards, researchers should ensure the predictiveness of their ageing tests by confirming that degradation mechanisms under real-world operating conditions align with those accelerated during testing. For instance, the functional dependence of the observed performance parameter versus time should remain consistent across normal operating and stress test conditions (Fig. 6c,d). Therefore, during the initial exploration of these standardized protocols for emerging photodetector technologies, it is imperative to also conduct tests at intermediate conditions to assess consistency with the degradation kinetics under the accelerated ageing conditions. 

Although existing standards provide a solid foundation for the stability characterization of emerging photodetector technologies under temperature, humidity and bias stress, it is important to note that, unlike conventional inorganic semiconductors, emerging photoactive materials may also degrade under illumination. Therefore, evaluating the stability of emerging photodetectors under continuous or cycled illumination is also essential. Stability characterization under continuous illumination should use optical power levels within the photodetector’s LDR, and performance parameters should be measured at regular intervals to monitor degradation effects. For stability measurements under cycled illumination (with a modulation frequency below _f_ 3dB,sin), the photodetector current should be continuously monitored, and performance parameters should be characterized at both beginning and end of the stress experiment. 

Finally, emerging photodetector technologies have the potential to address a wealth of applications that introduce novel scenarios (for example, seamless interfacing with the human body, biodegradability or edibility). Given the inherent limits of existing standards in this context, we encourage the research community to formulate new accelerated ageing protocols tailored to these innovative application scenarios. 

### **Characterization, reporting and benchmarking in context** 

An important challenge arises from the diversity of photodetector performance parameters and the varying operational conditions used for characterization. Addressing this challenge necessitates presenting performance parameters under consistent operating conditions. This is essential to allow cross-study comparisons and the identification of genuine materials and device advances. For instance, given the dependence of all performance metrics on the applied voltage, it is essential for photodetector studies to report the device characterization at least at one common applied voltage (hereafter referred to as the prevailing voltage) for consistency and benchmarking. 

To mitigate the data reliability challenge posed by potential device instability during characterization, it is strongly recommended to conduct and report a minimum of two repeated instances of current–voltage sweeps in the dark, spectral responsivities and frequency responses under sinusoidally modulated light as a sanity check for the same device 

when presenting such measurements. Additionally, measuring and reporting dark current and spectral responsivity data before and after noise measurements and time-domain characterizations of the speed of response are essential reality checks. Given the potential substantial device-to-device variability in early stage photodetector technologies, it is also crucial to avoid reliance on a single champion measurement. Instead, performance parameters should be reported with statistics derived from a representative batch of nominally identical devices. The exact batch size should be determined based on fabrication complexity and achievable yield. Although a batch of ten nominally identical devices is often a useful starting point, smaller batches may be necessary depending on fabrication scale-up challenges or low yield, in which case these limitations should be explicitly reported. 

Another contextual challenge stems from the multitude of applications relevant to emerging photodetector technologies and the application-specific target ranges for performance metrics (Supplementary Table 16). Narrowly pursuing the maximization/minimization of a specific performance metric without considering this context may hinder adaptability for applications requiring that metric to be engineered in the opposite direction. For instance, in spectrally selective photodetector research, regarding ultranarrowband performance (FWHMR ≈ 10 nm) as a universal objective is inappropriate, as many applications require much larger responsivity passbands. Similarly, regarding ultrafast operation as a universal objective is inappropriate, as several photodetector applications do not necessitate high speed (for example, Supplementary Table 16). To address this challenge, studies presenting advancements in emerging photodetector technologies should identify their application context and the relevant required performance metric ranges. 

Another nuance of the point above concerns avoiding emphasis on performance parameters that may not matter. For instance, many reports emphasize ultrahigh photoconductive gains, obtained, however, by devices with response times of up to minutes. In fact, response times on the order of minutes are unsuitable for most, if not all, applications (for example, Supplementary Table 16). Therefore, making superlative statements about metrics that may not matter should be avoided. 

Finally, given the diverse expertise within the community researching emerging photodetector technologies, we acknowledge that certain studies may focus on innovations in materials and fabrication methods over the characterization of specific performance metrics. For instance, researchers developing highly innovative photodetector materials may lack the necessary equipment for comprehensive performance characterization. In these cases, we recommend adhering to the appropriate theoretical approximations discussed here, transparently presenting them as such, and benchmarking the resultant estimates solely against the literature relying on equivalent approximations. 

### **Conclusions** 

This Consensus Statement tackles the need for accurate characterization, reporting and benchmarking of emerging photodetector technologies. By analysing definitions, misconceptions, context and challenges related to various performance metrics, we offer practical guidance and propose detailed guidelines to support consistent practices, accounting for the diversity of expertise and resources in the field. These guidelines will enhance understanding, evaluation and the real-world impact of emerging photodetector technologies. 

### **Online content** 

Any methods, additional references, Nature Portfolio reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41566-025-01759-1. 

Nature Photonics | Volume 19 | November 2025 | 1178–1188 

**1186** 

**Consensus Statement** 

https://doi.org/10.1038/s41566-025-01759-1 

### **References** 

1. Koppens, F. H. L. et al. Photodetectors based on graphene, other two-dimensional materials and hybrid systems. _Nat. Nanotechnol._ **9** , 780–793 (2014). 

2. Li, Z., Yan, T. & Fang, X. Low-dimensional wide-bandgap semiconductors for UV photodetectors. _Nat. Rev. Mater._ **8** , 587–603 (2023). 

3. García de Arquer, F. P., Armin, A., Meredith, P. & Sargent, E. H. Solution-processed semiconductors for next-generation photodetectors. _Nat. Rev. Mater._ **2** , 16100 (2017). 

4. Pecunia, V., Natali, D. & Caironi, M. in _Photodetectors (Second Edition)_ (ed. Nabet, B.) 73–137 (Woodhead Publishing, 2023). 

5. Konstantatos, G. in _Colloidal Quantum Dot Optoelectronics and Photovoltaics_ (eds Sargent, E. H. & Konstantatos, G.) 173–198 (Cambridge Univ. Press, 2013). 

6. Zhang, Y. et al. Lead-free perovskite photodetectors: progress, challenges, and opportunities. _Adv. Mater._ **33** , 2006691 (2021). 

7. Yoo, H. et al. A review of phototransistors using metal oxide semiconductors: research progress and future directions. _Adv. Mater._ **33** , 2006091 (2021). 

8. Huo, N. & Konstantatos, G. Recent progress and future prospects of 2D-based photodetectors. _Adv. Mater._ **30** , 1801164 (2018). 

9. Ahmadi, M., Wu, T. & Hu, B. A review on organic–inorganic halide perovskite photodetectors: device engineering and fundamental physics. _Adv. Mater._ **29** , 1605242 (2017). 

10. Wu, W. et al. High-speed carbon nanotube photodetectors for 2 μm communications. _ACS Nano_ **17** , 15155–15164 (2023). 

11. Pecunia, V. et al. Roadmap on printable electronic materials for next-generation sensors. _Nano Futures_ **8** , 032001 (2024). 

12. Bianconi, S., Lauhon, L. J. & Mohseni, H. Exaggerated sensitivity in photodetectors with internal gain. _Nat. Photon._ **15** , 714–714 (2021). 

13. Wang, F., Zhang, T., Xie, R., Wang, Z. & Hu, W. How to characterize figures of merit of two-dimensional photodetectors. _Nat. Commun._ **14** , 2224 (2023). 

14. Fang, Y., Armin, A., Meredith, P. & Huang, J. Accurate characterization of next-generation thin-film photodetectors. _Nat. Photon._ **13** , 1–4 (2019). 

15. Schedel, C., Strauß, F. & Scheele, M. Pitfalls in determining the electrical bandwidth of nonideal nanomaterials for photodetection. _J. Phys. Chem. C_ **126** , 14011–14016 (2022). 

16. Moseley, O. D. I., Roose, B., Zelewski, S. J. & Stranks, S. D. Identification and mitigation of transient phenomena that complicate the characterization of halide perovskite photodetectors. _ACS Appl. Energy Mater._ **6** , 10233–10242 (2023). 

17. O’Kane, S. E. J. et al. Measurement and modelling of dark current decay transients in perovskite solar cells. _J. Mater. Chem. C_ **5** , 452–462 (2017). 

18. Tang, Y. et al. Enabling low-drift flexible perovskite photodetectors by electrical modulation for wearable health monitoring and weak light imaging. _Nat. Commun._ **14** , 4961 (2023). 

19. Jeong, S.-H. et al. Characterizing the efficiency of perovskite solar cells and light-emitting diodes. _Joule_ **4** , 1206–1235 (2020). 

20. Song, T., Friedman, D. J. & Kopidakis, N. Comprehensive performance calibration guidance for perovskites and other emerging solar cells. _Adv. Energy Mater._ **11** , 2100728 (2021). 

21. Zhou, X. et al. Electrical edge effect induced photocurrent overestimation in low-light organic photovoltaics. _Joule_ **6** , 1904–1917 (2022). 

22. Jailani, J. M. et al. Accurate performance characterization, reporting, and benchmarking for indoor photovoltaics. _Joule_ **9** , 102126 (2025). 

23. Seo, B. et al. Bias dependence of organic-oxide phototransistors with peak infrared absorption at 1550 nm. _ACS Appl. Electron. Mater._ **5** , 6401–6407 (2023). 

24. Li, N., Eedugurala, N., Azoulay, J. D. & Ng, T. N. Light-induced trap reduction in organic shortwave infrared photodetectors. _ACS Photonics_ **9** , 4030–4037 (2022). 

25. Schneider, D. S. et al. Highly responsive flexible photodetectors based on MOVPE grown uniform few-layer MoS2. _ACS Photonics_ **7** , 1388–1395 (2020). 

26. Rose, A. _Concepts in Photoconductivity and Allied Problems_ (Interscience Publishers, 1963). 

27. Shin, C. et al. Heterojunction bilayers serving as a charge transporting interlayer reduce the dark current and enhance photomultiplication in organic shortwave infrared photodetectors. _Mater. Horiz._ **9** , 2172–2179 (2022). 

28. Adinolfi, V. & Sargent, E. H. Photovoltage field-effect transistors. _Nature_ **542** , 324–327 (2017). 

29. Rogalski, A. Commentary on the record-breaking performance of low-dimensional solid photodetectors. _ACS Photonics_ **10** , 647–653 (2023). 

30. Konstantatos, G. et al. Ultrasensitive solution-cast quantum dot photodetectors. _Nature_ **442** , 180–183 (2006). 

31. Fang, H. & Hu, W. Photogating in low dimensional photodetectors. _Adv. Sci._ **4** , 1700323 (2017). 

32. Islam, M. M. et al. Multiwavelength optoelectronic synapse with 2D materials for mixed-color pattern recognition. _ACS Nano_ **16** , 10188–10198 (2022). 

33. Zhang, Y. et al. Nonlinear photodetector based on InSe p–n homojunction for improving spatial imaging resolution. _Adv. Funct. Mater._ **34** , 2402957 (2024). 

34. Shi, Y. et al. Nonlinear germanium-silicon photodiode for activation and monitoring in photonic neuromorphic networks. _Nat. Commun._ **13** , 6048 (2022). 

35. Nashashibi, S. et al. Engineering graphene phototransistors for high dynamic range applications. _ACS Nano_ **18** , 12760–12770 (2024). 

36. Rogalski, A. & Bielecki, Z. _Detection of Optical Signals_ (CRC Press, 2022). 

37. Lhuillier, E., Keuleyan, S., Rekemeyer, P. & Guyot-Sionnest, P. Thermal properties of mid-infrared colloidal quantum dot detectors. _J. Appl. Phys._ **110** , 033110 (2011). 

38. Keuleyan, S., Lhuillier, E., Brajuskovic, V. & Guyot-Sionnest, P. Mid-infrared HgTe colloidal quantum dot photodetectors. _Nat. Photon._ **5** , 489–493 (2011). 

39. Jansen-van Vuuren, R. D., Armin, A., Pandey, A. K., Burn, P. L. & Meredith, P. Organic photodiodes: the future of full color detection and image sensing. _Adv. Mater._ **28** , 4766–4802 (2016). 

40. Wu, Z., Yao, W., London, A. E., Azoulay, J. D. & Ng, T. N. Elucidating the detectivity limits in shortwave infrared organic photodiodes. _Adv. Funct. Mater._ **28** , 1800391 (2018). 

41. Xiong, S. et al. Universal strategy to reduce noise current for sensitive organic photodetectors. _ACS Appl. Mater. Interfaces_ **9** , 9176–9183 (2017). 

42. De La Moneda, F. H., Chenette, E. R. & Van Der Ziel, A. Noise in phototransistors. _IEEE Trans. Electron Devices_ **18** , 340–346 (1971). 

43. van der Ziel, A. Noise in solid-state devices and lasers. _Proc. IEEE_ **58** , 1178–1206 (1970). 

44. Pecunia, V. _Organic Narrowband Photodetectors: Materials, Devices and Applications_ (IOP Publishing, 2019). 

45. Herrick, R. W. in _Reliability of Semiconductor Lasers and Optoelectronic Devices_ (eds Herrick, R. W. & Ueda, O.) 47–87 (Woodhead Publishing, 2021). 

46. _Semiconductor Devices - Mechanical and Climatic Test Methods - Part 1: General_ IEC 60749-1 (IEC, 2002). 

Nature Photonics | Volume 19 | November 2025 | 1178–1188 

**1187** 

**Consensus Statement** 

https://doi.org/10.1038/s41566-025-01759-1 

47. _Reliability Assurance for Optoelectronic Devices_ GR-468-CORE (Telcordia, 2004). 

48. _Steady-State Temperature-Humidity Bias Life Test_ JESD22-A101D.01 (JEDEC, 2021). 

49. _Qualification Standard for Integrated Circuits_ AEC-Q100 (AEC, 2023). 

50. _Radiation Hardness Assurance: EEE Components_ ECSS-Q-ST-6015C (ECSS, 2012). 

- Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law. 

- © The Author(s), under exclusive licence to Springer Nature Limited 2025 

**Vincenzo Pecunia**<sup>**1**</sup> **, Thomas D. Anthopoulos**<sup>**2**</sup> **, Ardalan Armin**<sup>**3**</sup> **, Benjamin Bouthinon**<sup>**4**</sup> **, Mario Caironi**<sup>**5**</sup> **, Andres Castellanos-Gomez**<sup>**6**</sup> **, Yongsheng Chen**<sup>**7**</sup> **, Kilwon Cho**<sup>**8**</sup> **, Charlotte Clegg**<sup>**1**</sup> **, Xiaosheng Fang**<sup>**9**</sup> **, Peter Fendel**<sup>**10**</sup> **, Boyd Fowler**<sup>**11**</sup> **, Gerwin Gelinck**<sup>**12,13**</sup> **, Heinrich Gottlob**<sup>**14**</sup> **, Philippe Guyot-Sionnest**<sup>**15**</sup> **, Rob Hannebauer**<sup>**16**</sup> **, Gerardo Hernandez-Sosa**<sup>**17,18,19**</sup> **, Mark C. Hersam**<sup>**20,21,22**</sup> **, Lionel Hirsch**<sup>**23**</sup> **, Johnny C. Ho**<sup>**24**</sup> **, Furkan H. Isikgor**<sup>**25**</sup> **, Jérôme Joimel**<sup>**4**</sup> **, Hyun Jae Kim**<sup>**26**</sup> **, Gerasimos Konstantatos**<sup>**27,28**</sup> **, John Labram**<sup>**29**</sup> **, Max C. Lemme**<sup>**30,31**</sup> **, Karl Leo**<sup>**32**</sup> **, Emmanuel Lhuillier**<sup>**33**</sup> **, Elefterios Lidorikis**<sup>**34**</sup> **, Maria A. Loi**<sup>**35**</sup> **, Pawel E. Malinowski**<sup>**36**</sup> **, Patrick Merken**<sup>**37**</sup> **, Thomas Mueller**<sup>**38**</sup> **, Bahareh Nasrollahi**<sup>**1**</sup> **, Dario Natali**<sup>**5,39**</sup> **, Tse Nga Ng**<sup>**40**</sup> **, Thuc-Quyen Nguyen**<sup>**41**</sup> **, Sung Kyu Park**<sup>**42**</sup> **, Lian-Mao Peng**<sup>**43**</sup> **, Paolo Samorì**<sup>**44**</sup> **, Edward H. Sargent**<sup>**21,22,45**</sup> **, Liang Shen**<sup>**46**</sup> **, Sanshiro Shishido**<sup>**47**</sup> **, Ivan Shorubalko**<sup>**48**</sup> **, Prashant Sonar**<sup>**49,50**</sup> **, Samuel D. Stranks**<sup>**51**</sup> **, Sandro F. Tedde**<sup>**52**</sup> **, Koen Vandewal**<sup>**53,54**</sup> **, Marc Verhaegen**<sup>**55**</sup> **, Sumeet Walia**<sup>**56**</sup> **, Feng Yan**<sup>**57**</sup> **, Tomoyuki Yokota**<sup>**58**</sup> **& Fujun Zhang**<sup>**59**</sup> 

1Sustainable Optoelectronics Research Group, School of Sustainable Energy Engineering, Simon Fraser University, Surrey, British Columbia, Canada. 2Henry Royce Institute, Photon Science Institute, Department of Electrical and Electronic Engineering, The University of Manchester, Manchester, UK.<sup>3</sup> Centre for Integrative Semiconductor Materials (CISM), Department of Physics, Swansea University Bay Campus, Swansea, UK.<sup>4</sup> VS Technology, Grenoble, France.<sup>5</sup> Center for Nano Science and Technology, Istituto Italiano di Tecnologia, Milano, Italy.<sup>6</sup> 2D Foundry Research Group, Instituto de Ciencia de Materiales de Madrid (ICMM-CSIC), Madrid, Spain.<sup>7</sup> State Key Laboratory of Elemento-Organic Chemistry, Key Laboratory of Functional Polymer Materials, College of Chemistry, Renewable Energy Conversion and Storage Center (RECAST), Nankai University, Tianjin, People’s Republic of China.<sup>8</sup> Department of Chemical Engineering, Pohang University of Science and Technology (POSTECH), Pohang, Republic of Korea.<sup>9</sup> College of Smart Materials and Future Energy, State Key Laboratory of Molecular Engineering of Polymers, Fudan University, Shanghai, People’s Republic of China. 10Thorlabs Inc., Newton, NJ, USA. 11OmniVision Technologies Inc., Santa Clara, CA, USA. 12Molecular Materials and Nanosystems and Institute of Complex Molecular Systems, Eindhoven University of Technology, Eindhoven, The Netherlands.<sup>13</sup> TNO at Holst Centre, High Tech Campus 31, Eindhoven, The Netherlands.<sup>14</sup> Vishay Semiconductor GmbH, Heilbronn, Germany.<sup>15</sup> James Franck Institute, The University of Chicago, Chicago, IL, USA.<sup>16</sup> Lumiense Photonics Inc., Vancouver, British Columbia, Canada.<sup>17</sup> Light Technology Institute, Karlsruhe Institute of Technology, Karlsruhe, Germany.<sup>18</sup> Institute of Microstructure Technology, Karlsruhe Institute of Technology, Eggenstein-Leopoldshafen, Germany.<sup>19</sup> InnovationLab, Heidelberg, Germany. 20Department of Materials Science and Engineering, Northwestern University, Evanston, IL, USA. 21Department of Electrical and Computer Engineering, Northwestern University, Evanston, IL, USA.<sup>22</sup> Department of Chemistry, Northwestern University, Evanston, IL, USA.<sup>23</sup> Univ. Bordeaux, CNRS, Bordeaux INP, Laboratoire IMS, Talence, France.<sup>24</sup> Department of Materials Science and Engineering, City University of Hong Kong, Kowloon, Hong Kong SAR. 25Department of Chemistry, The University of Manchester, Manchester, UK. 26School of Electrical and Electronic Engineering, Yonsei University, Seoul, Republic of Korea.<sup>27</sup> ICFO—Insitut de Ciencies Fotoniques, The Barcelona Institute of Science and Technology, Castelldefels, Spain.<sup>28</sup> ICREA—Institució Catalana de Recerca i Estudiats Avançats, Barcelona, Spain.<sup>29</sup> Department of Electronic & Electrical Engineering, University College London, London, UK.<sup>30</sup> Chair of Electronic Devices, RWTH Aachen University, Aachen, Germany.<sup>31</sup> AMO GmbH, Aachen, Germany.<sup>32</sup> Dresden Integrated Center for Applied Physics and Photonic Materials (IAPP) and Institute for Applied Physics, Technische Universität Dresden, Dresden, Germany.<sup>33</sup> Sorbonne Université, CNRS, Institut des NanoSciences de Paris, Paris, France.<sup>34</sup> Department of Materials Science and Engineering, University of Ioannina, Ioannina, Greece. 35Photophysics and Optoelectronics Group, Zernike Institute for Advanced Materials, University of Groningen, Groningen, The Netherlands. 36imec vzw, Leuven, Belgium.<sup>37</sup> Exosens, Leuven, Belgium.<sup>38</sup> Institute of Photonics, Vienna University of Technology, Vienna, Austria.<sup>39</sup> Department of Electronics, Information and Bioengineering, Politecnico di Milano, Milano, Italy.<sup>40</sup> Department of Electrical and Computer Engineering, University of California San Diego, La Jolla, CA, USA.<sup>41</sup> Center for Polymers and Organic Solids (CPOS), Departments of Chemistry and Biochemistry, University of California at Santa Barbara, Santa Barbara, CA, USA.<sup>42</sup> Department of Intelligent Semiconductor Engineering, Chung-Ang University, Seoul, Republic of Korea. 43Center for Carbon-based Electronics, School of Electronics, Peking University, Beijing, People’s Republic of China. 44Université de Strasbourg, CNRS, ISIS, Strasbourg, France.<sup>45</sup> Department of Electrical and Computer Engineering, University of Toronto, Toronto, Ontario, Canada.<sup>46</sup> State Key Laboratory of Integrated Optoelectronics, College of Electronic Science and Engineering, International Center of Future Science, Jilin University, Changchun, People’s Republic of China.<sup>47</sup> Green Transformation Division, Panasonic Holdings Corporation, Moriguchi, Japan.<sup>48</sup> Transport at Nanoscale Interfaces Laboratory, Swiss Federal Laboratories for Materials Science and Technology (Empa), Duebendorf, Switzerland.<sup>49</sup> Faculty of Science, School of Chemistry and Physics, Queensland University of Technology (QUT), Brisbane, Queensland, Australia.<sup>50</sup> Centre for Materials Science, Queensland University of Technology (QUT), Brisbane, Queensland, Australia.<sup>51</sup> Department of Chemical Engineering and Biotechnology, University of Cambridge, Cambridge, UK. 52Siemens Healthineers AG, Technology Excellence, Innovation Center Erlangen, Erlangen, Germany. 53Hasselt University, Institute for Materials Research (imo-imomec), Hasselt, Belgium.<sup>54</sup> imec, imo-imomec, Diepenbeek, Belgium.<sup>55</sup> Photon etc., Montréal, Quebec, Canada.<sup>56</sup> Centre for Opto-electronic Materials and Sensors, School of Engineering, RMIT University, Melbourne, Victoria, Australia.<sup>57</sup> Department of Applied Physics, Research Center for Organic Electronics, The Hong Kong Polytechnic University, Kowloon, Hong Kong SAR.<sup>58</sup> Department of Electrical Engineering and Information Systems, Graduate School of Engineering, The University of Tokyo, Tokyo, Japan.<sup>59</sup> School of Physical Science and Engineering, Beijing Jiaotong University, Beijing, People’s Republic of China. e-mail: vincenzo_pecunia@sfu.ca; thomas.anthopoulos@manchester.ac.uk 

Nature Photonics | Volume 19 | November 2025 | 1178–1188 

**1188** 

**Consensus Statement** 

https://doi.org/10.1038/s41566-025-01759-1 

### **Methods** 

This work builds on the outcomes of round-table discussions on photodetector characterization involving a team led by V.P. and involving T.D.A., B.N., D.N., M.C., R.H., G.G., J.L., E. Lidorikis, B.B. and J.J. These discussions took place in August–September 2022. Following these discussions, an outline for the Consensus Statement was drafted, spearheaded by V.P. with input from the team members. Subsequently, additional co-authors were invited based on criteria ensuring representation across diverse research streams in emerging photodetector technologies, inclusion of industry experts and geographical diversity. The manuscript was circulated among all contributing authors multiple times, with their inputs and feedback integrated iteratively until a consensus was reached. 

### **Data availability** 

The data supporting the findings of this study are available within the Consensus Statement and its Supplementary Information. Other raw data files required in another format are available from the corresponding authors upon reasonable request. 

### **Acknowledgements** 

V.P. acknowledges funding support from Simon Fraser University, the Natural Sciences and Engineering Research Council of Canada (NSERC) and the Canada Foundation for Innovation (CFI). T.D.A. acknowledges financial support from UK Research and Innovation (UKRI) and European Research Council (ERC), grant reference number EP/Z534006/1. A.C.-G. acknowledges funding from the Ministry of Science and Innovation (Spain) (PDC2023-145920-I00 and PID2023151946OB-I00). Y.C. acknowledges funding support from the National Key R&D Program of China (2022YFB4200400). C.C. acknowledges funding support from Mitacs. X.F. acknowledges funding support from the National Natural Science Foundation of China (number 52425308). G.H.-S. acknowledges support from the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation) through grant number HE 7056/6-1 and Heisenberg-Professorship HE 7056/7-1. M.C.H. acknowledges support from the National Science Foundation (NSF) Assessing and Predicting Technology Outcomes (APTO) programme (grant number TF-2404035). L.H. acknowledges funding support from the Agence Nationale de la Recherche (DETECT project number ANR-23-CE24-0001) and the Region Nouvelle Aquitaine (OVERPRINT project number AAPR2024-2023-31782910). J.C.H. acknowledges support from a fellowship award by the Research Grants Council of the Hong Kong Special Administrative Region, China (CityURFS2021-1S04). H.J.K. acknowledges support from the National Research Foundation of Korea (NRF) grant funded by the Korean government (MSIT) (number RS-2023-00256917). G.K. acknowledges support from the ERC under the European Union’s Horizon 2020 research and innovation programme (grant agreement number 101002306), the Fundació Privada Cellex, and the programme CERCA. J.L. acknowledges the University College London (UCL) Higher Education Innovation Fund KEI2024-01-34 

HEIF for financial support. M.C.L. acknowledges support from the German Ministry of Education and Research (BMBF) through the project ATIQ (13N16116 and 13N16130). E. Lhuillier acknowledges support from the ERC grant AQDtive (grant number 101086358) and from French National Research Agency (ANR) through the grants 

Bright (ANR-21-CE24-0012-02), DIRAC (ANR-24-ASM1-0001), camIR (ANR-24-CE42-2757) and Piquant (ANR-24-CE09-0786). E. Lidorikis acknowledges funding support from EU Horizon Project ‘AMBROSIA’ (number 101093166). M.A.L. acknowledges support from the European Research Council with the ERC Advanced Grant, DEOM (101055097). T.M. acknowledges support from the European Union (grant agreement number 785219 Graphene Flagship). B.N. acknowledges funding support from Simon Fraser University and the Natural Sciences and Engineering Research Council of Canada (NSERC). T.N.N. acknowledges support from USA National Science Foundation grants ECCS-2318990, CNS-2312715 and CNS-2408393. T.-Q.N. acknowledges support from the Mitsubishi Chemical Center for Advanced Materials at the University of California Santa Barbara and thanks H. M. Luong from Chulalongkorn University for suggestions and comments. P. Samorì acknowledges support from the Agence Nationale de la Recherche through the Interdisciplinary Thematic Institute SysChem via the IdEx Unistra (ANR-10-IDEX-0002) within the programme Investissement d’Avenir, and the Institut Universitaire de France (IUF). P. Sonar acknowledges support from the Australian Research Council grants DP210103006 & DP230101666. S.D.S. acknowledges the Royal Society and Tata Group (UF150033 and URF\R\221026). K.V. acknowledges support from the ERC (grant agreement number 864625). S.W. acknowledges funding support from the Australian Research Council through projects DP240100145, CE230100006 and the Office of National Intelligence Project NI230100026. T.Y. acknowledges support from JST ASPIRE for Rising Scientists (JPMJAP2336). F.Z. acknowledges funding support from the Natural Science Foundation of Beijing (4232073) and the National Natural Science Foundation of China (62175011). 

### **Competing interests** 

B.B. is the CTO of VS Technology. P.F. is the CTO of Thorlabs Inc. B.F. is the CTO of OmniVision Technologies Inc. H.G. is the Director Product Development Sensors for Vishay Semiconductor GmbH. R.H. is the CEO of Lumiense Photonics Inc. J.J. is the CEO of VS Technology. M.C.L. is the CEO of non-profit AMO GmbH. P.E.M. is the Portfolio Manager Imaging Technologies at imec. P.M. is the VP Innovation of Exosens. S.S. is an employee of Panasonic Corporation. S.F.T. is the Technology Innovation Manager of Siemens Healthineers AG. M.V. is the CTO of Photon etc. All other authors declare no competing interests. 

### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41566-025-01759-1. 

**Correspondence and requests for materials** should be addressed to Vincenzo Pecunia or Thomas D. Anthopoulos. 

**Peer review information** _Nature Photonics_ thanks Hooman Mohseni, Haodong Tang and the other, anonymous reviewer(s) for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at www.nature.com/reprints. 

Nature Photonics 

