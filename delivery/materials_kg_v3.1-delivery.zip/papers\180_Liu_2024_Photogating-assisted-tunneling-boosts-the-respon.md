# Photogating-assisted tunneling boosts the responsivity and speed of heterogeneous WSe2/Ta2NiSe5 photodetectors

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 171 |
| 作者 | Ming-Xiu Liu, Jingxuan Wei, Liujian Qi, Junru An, Xing-Si Liu, Yahui Li, Zhi-Ming Shi, Da-Bing Li et al. |
| DOI | 10.1038/s41467-023-44482-7 |
| 源文件 | 080_Liu_2024_Photogating-assisted-tunneling-boosts-the-respon.pdf |

---


Article 

https://doi.org/10.1038/s41467-023-44482-7 

# Photogating-assisted tunneling boosts the responsivity and speed of heterogeneous WSe2/Ta2NiSe5 photodetectors 

|Received: 25 July 2023<br>Accepted: 14 December 2023|Mingxiu Liu<sup>1,2,6</sup>, Jingxuan Wei<br>3,4,6, Liujian Qi<br>1,2,6, Junru An1,2, Xingsi Liu3,<br>Yahui Li<sup>1,2</sup>, Zhiming Shi<br>1,2, Dabing Li<br>1,2<br>, Kostya S. Novoselov<br>5,<br>Cheng-Wei Qiu<br>3<br>& Shaojuan Li<br>1,2|
|---|---|
|Check for updates|Photogating effect is the dominant mechanism of most high-responsivity two-<br>dimensional (2D) material photodetectors. However, the ultrahigh respon-<br>sivities in those devices are intrinsically at the cost of very slow response<br>speed. In this work, we report a WSe2/Ta2NiSe5heterostructure detector<br>whose photodetection gain and response speed can be enhanced simulta-<br>neously, overcoming the trade-off between responsivity and speed. We reveal<br>that photogating-assisted tunneling synergistically allows photocarrier multi-<br>plication and carrier acceleration through tunneling under an electricalfield.<br>The photogating effect in our device features low-power consumption (in the<br>order of nW) and shows a dependence on the polarization states of incident<br>light, which can be further tuned by source-drain voltages, allowing for<br>wavelength discrimination with just a two-electrode planar structure. Our<br>findings offer more opportunities for the long-sought next-generation pho-<br>todetectors with high responsivity, fast speed, polarization detection, and<br>multi-color sensing, simultaneously.|



Photodetectors constitute the base stone of various optical and optoelectronic devices, whose recent development is mainly driven by emerging technologies such as photonic integrated circuits<sup>1–6</sup> , the Internet of Things<sup>7–9</sup> , and automation<sup>10–13</sup> . Those new technologies keep pushing the photodetectors to acquire higher responsivity, faster response, lower power consumption, and more functionalities such as wavelength and polarization sensitivity. However, the above requirements cannot be simultaneously met in the conventional photodetectors based on bulky materials, such as silicon<sup>14</sup> , germanium<sup>15</sup> , and III-V semiconductors<sup>16</sup> . A promising solution could be using twodimensional (2D) materials with strong light-matter interactions, tunable band gaps, compatibility with existing semiconductor production 

lines, and the rich opportunities provided by atomically sharp heterointerfaces<sup>11,17–19</sup> . For example, 2D materials photodetectors with ultra-high responsivities (10<sup>3</sup> −10<sup>7</sup> A/W) have been well documented, in which the photogating effect dominates the photoresponse<sup>20–23</sup> . The excellent responsivity performance results from the significant photodetection gain: G = τ / tL, where τ and tL are the photocarrier lifetime and carrier transit time, respectively<sup>24</sup> . Unfortunately, such a mechanism is always achieved with a long photocarrier lifetime, thereby suffering prolonged response time<sup>20,22,25,26</sup> , with typical values in the millisecond range, unjustified for many applications such as imaging. The trade-off between high responsivity and fast speed is illustrated in Fig. 1a. A closer scrutiny of the photodetection gain 

> 1State Key Laboratory of Luminescence and Applications, Changchun Institute of Optics, Fine Mechanics and Physics, Chinese Academy of Sciences, Jilin 130033 Changchun, PR China.<sup>2</sup> University of Chinese Academy of Sciences (UCAS), 100049 Beijing, PR China.<sup>3</sup> Department of Electrical and Computer Engineering, National University of Singapore, Singapore 117583, Singapore.<sup>4</sup> School of Optoelectronic Science and Engineering, University of Electronic Science and Technology of China, 611731 Chengdu, PR China.<sup>5</sup> Institute for Functional Intelligent Materials, National University of Singapore, Singapore 117544, Singapore.<sup>6</sup> These authors contributed equally: Mingxiu Liu, Jingxuan Wei, Liujian Qi. e-mail: lidb@ciomp.ac.cn; chengwei.qiu@nus.edu.sg; lishaojuan@ciomp.ac.cn 

Nature Communications |  (2024) 15:141 

1 

Article 

https://doi.org/10.1038/s41467-023-44482-7 



<!-- Start of picture text -->
a high c<br>1.4x10 -8 Ta2NiSe5 10 -8<br>Eph≥Eg<br>tarOur get EEF - - - - - 1.2x101.0x10 -8-8 Drain Source 10 -9<br>WSe2<br>20 µm 10 -10<br>Trapped  8.0x10 -9<br>carriers  6.0x10 -9 10 -11<br>Eph≥Eg Eph≥Eg 4.0x10 -9 n  = 1.18 10 -12<br>EF EEF - - - - - 2.0x10 -9 V gs=0 V 10 -13<br>low E P N 0.0 In dark<br>x 10 -14<br>-1.0 -0.5 0.0 0.5 1.0<br>fast slow<br>Response speed V ds (V)<br>b d<br>V ds=<br>10 -6 nph 1.5 V  -0.5 V<br>Ta2NiSe5 1 V  -1 V<br>WSe2 Source 10 -7 0.5 V  -1.5 V<br>Drain<br>10 -8<br>10 -9<br>10 -10 Trapped carriers<br>10 -11<br>Ti/Au SiO2<br>10 -12<br>Si -4 -2 0 2 4<br>V gs (V)<br> (A)  I ds ds  (A)I<br>Responsivity<br>(A) I ds<br><!-- End of picture text -->

Fig. 1 | Bias-tunable transport behavior in our 2D heterostructure photodetector. a Illustration of the trade-off between the responsivity and speed in 2D materials photodetectors. To overcome the trade-off and enter the upper left area, we conventionally need to increase the power consumption, denoted by the red shade. The energy band diagram on the lower left side is the photovoltaic mode of photodetector, the middle is the photoconductive mode, and the upper right side belongs to photogating mode. Where Eph is the photon energy, nph is the photogenerated carrier concentration, Eg is the bandgap, EF is the Fermi level of the material, and E is the external electric field. Different background colors represent the variation trend of possible required power consumption of 2D photodetectors, which increases gradually from the white color at the lower right corner to the red color at the upper left corner of figure. b Schematic of a WSe2/Ta2NiSe5 

heterostructure device. c Source-drain I-V curves of a representative device in dark. No gate voltage was applied (Vgs = 0 V). This device consists of an approximately 60-nm-thick WSe2 flake on top of a 13-nm-thick Ta2NiSe5 flake. The dashed line represents the logarithmic form of the I-V curve. The ideal factor n is defined as n = (q/KT) ⋅ (dV/dlnI), the inset is an optical microscope diagram of the device. d Transfer curves (Ids-Vgs (back gate voltage)) of the device at different source-drain biases, Vds, under the illumination of a white light source. The distinct behaviors between positive (solid lines) and negative (dashed lines) Vds allow us to analyze the underlying photoresponse mechanism. nph represents the carrier concentration under the light illumination, the horizontal arrow represents the shift of transfer curve induced by the trapped carriers. 

formula reveals that the responsivity can also be increased by a shorter transit time. Conventionally, this is achieved using devices with shorter channel lengths or larger bias voltages, which face limitations in practical applications. The channel length cannot be scaled down arbitrarily due to the fabrication capability, increased dark currents and hence power consumption<sup>27–29</sup> ; the bias voltage usually keeps at the Vdd in the complementary metal–oxide–semiconductor (CMOS) circuitry of around 1 V<sup>30,31</sup> . Furthermore, while polarization and wavelength of light play essential roles in widespread applications, most of the existing photodetectors are only sensitive to the intensity of light<sup>9,32,33</sup> . Therefore, how to overcome the responsivity-speed tradeoff and extend the functionalities of photodetectors remains an prominent problem. 

In this work, we report a 2D WSe2/Ta2NiSe5 heterostructure device which can fulfill all the above requirements. Our analysis suggests that a tunneling process can significantly reduce the transit time in our device, dramatically enhancing the photodetection gain and hence the responsivity. As a result, we have a sufficient responsivity budget to reduce the response time below the threshold of around 1 ms for practical imaging applications by managing the trap sites. Namely, due 

to the tunneling enabled short transit time, our device allows high responsivity even at a relatively short carrier lifetime. The responsivity reaches above 10<sup>3</sup> A/W, and the response time is down to ~1 µs. While the above performance is already superior to the existing 2D photogating devices in the case of imaging applications, our device also shows lower power consumption in the order of nW, broad working range from visible to infrared, and polarization dependence due to the intrinsic anisotropy of Ta2NiSe5. Interestingly, the anisotropic photoresponse ratio is bias-tunable and wavelength-dependent, providing a promising platform for wavelength discrimination. Our results may pave the way towards the future development of high-performance 2D photodetectors potentially for applications in miniaturized spectroscopy, spectral imaging, objects and threats identification. 

## Results 

### Bias-tunable transport behavior of WSe2/Ta2NiSe5 device 

Figure 1b shows the schematic of the WSe2/Ta2NiSe5 heterostructure photodetectors. The layered WSe2 and Ta2NiSe5 flakes were mechanically exfoliated from their bulk materials, and the electrodes were composed of titanium/gold (10/80 nm). As a member of the 

Nature Communications |  (2024) 15:141 

2 

Article 

https://doi.org/10.1038/s41467-023-44482-7 

ternary chalcogenides, Ta2NiSe5 has layered monoclinic structures below the transition temperature (328 K)<sup>34–37</sup> , where layers formed by periodically assembled [TaSe6]2 dimer chains and NiSe4 single chains are weakly bonded via van der Waals interactions (Supplementary Fig. 1a). The distorted chain structure leads to a strong in-plane anisotropy and all three lattice constants (a = 3.5 Å, b = 12.8 Å, and c = 15.6 Å) are different<sup>34</sup> . The crystallographic direction can be determined by optical microscopy and angle-resolved polarized Raman spectroscopy in our experiments, in which the long-axis of the exfoliated flake corresponds to the a direction (Supplementary Note 1)<sup>38</sup> . In addition, Ta2NiSe5 maintains its direct bandgap from 0.36 eV in the bulk to monolayer<sup>39</sup> , with a reported high carrier mobility<sup>40</sup> . The atomic structure diagram of 2H-WSe2 possesses an in-plane isotropic hexagonal symmetry (a = b = 3.3 Å) with two layers per repeated unit (Supplementary Fig. 1b). Few-layer WSe2 has a sizeable bandgap of ~1.2 eV, high absorption coefficient and good ambient stability<sup>41,42</sup> . The efficient charge transfer at the WSe2/Ta2NiSe5 interface and the high quality of materials were confirmed by the optical measurements (Supplementary Note 2)<sup>43</sup> . 

Multiple heterostructure devices comprising different thicknesses were investigated (Supplementary Note 3). Figure 1c plots the source-drain current (Ids) of a representative device in dark at room temperature (see the inset of Fig. 1c for a top-view optical image). The devices exhibit typical rectification characteristics with an ideality factor (n) of ~1. We then measured the optoelectrical properties of the device under the illumination of a white light source. The transfer characteristics (Ids-Vgs) of the device are shown in Fig. 1d. The corresponding output curves (Ids -Vds) are depicted in Supplementary Fig. 6. From the curve signatures, we found below phenomena: First, the WSe2/Ta2NiSe5 heterostructure exhibits obvious p-type transport characteristics and a high on/off ratio of ~10<sup>4</sup> , which is ascribed to the strong gate-tunability of p-type WSe2. The electrical polarity of Ta2NiSe5 and WSe2 were investigated separately (Supplementary Note 4). The results confirm the weakly n-type transport property of Ta2NiSe5 and prominent p-type conductivity of WSe2, which is consistent with previous reports<sup>26,44</sup> . The carrier mobility was estimated as 12.43 cm<sup>2</sup> /V ⋅ s and 4.64 cm<sup>2</sup> /V ⋅ s for Ta2NiSe5 and WSe2, respectively. Second, the characteristics indicate Schottky barrier-dominated transport at positive bias (Vds) condition<sup>26,45</sup> . High output current under positive Vds voltage at the metal source contact confirms the formation of a p-type contact that is favorable for hole injection at the WSe2/metal contact, which will be further discussed in detail in the following sections. Third, the device exhibits distinct behaviors under different source-drain bias voltages (Fig. 1d). Under negative Vds, photogating can be seen as a horizontal shift in the Ids–Vgs traces under illumination with increasing the magnitude of Vds. This phenomenon suggests that trap states where carriers can reside for long times exist at defects or at the interface of the heterostructure<sup>46,47</sup> . However, under positive Vds, horizontal shift in the Ids–Vgs traces was largely suppressed, and increment of the number of photocarriers (nph) under higher positive Vds leads to larger output current. The above observations manifest the bias-tunable transport behavior of the WSe2/ Ta2NiSe5 heterostructure. 

### Photogating-assisted tunneling in WSe2/Ta2NiSe5 device 

To further illustrate the bias-tunable behavior of the device, we plot the photocurrent mapping and corresponding schematic band diagrams of a typical device in Fig. 2. The device consists of two metal/ semiconductor junctions at source/drain side and one 60-nm-thick WSe2/13-nm-thick Ta2NiSe5 heterojunction. The spatially resolved photocurrent mapping with the illumination of 532 nm laser (Vgs = 0 V) at various Vds reveals significantly different photocurrent generation images (Fig. 2a, b). Similar results were acquired under 633 nm laser illumination (Supplementary Note 5). The pronounced photocurrent generation in the overlapped WSe2/Ta2NiSe5 region is observed at 

Vds = −1 V. In contrast, when the device is forward biased, the maximum photocurrent is generated near the junction region where the metal electrode contacts WSe2 (Fig. 2b). These observations imply the biastunable operation mechanisms in the WSe2/Ta2NiSe5 heterostructure, attesting the distinct transport behavior in above Fig. 1d. 

The band alignments of few-layer WSe2/Ta2NiSe5 heterostructures were investigated by using density functional theory (DFT) methods. The Perdew–Burke–Ernzerhof (PBE) functional was adapted to describe electronic exchange-correlation interaction since its great reliability to transition metal dichalcogenides (TMDCs) including MoS2, PdSe2, Pd2Se3, InSe and so on<sup>48,49</sup> . The projected band structures of 1–6 Layers WSe2/Ta2NiSe5 heterostructures are shown in Supplementary Note 6. The conduction band minimum (CBM) and valence band maximum (VBM) of Ta2NiSe5 embed in the bandgap of WSe2 despite of the thickness, indicating the type-I alignment. For thicker heterostructures shown in Fig. 2a, b, the relative positions of the conduction band minimum (CBM) and the valence band maximum (VBM) of thick WSe2 (60-nm thick) are ~ 4.0 eV and 5.2 eV, respectively, with a bandgap of 1.2 eV<sup>50,51</sup> . According to recent experimental studies on the energy band of Ta2NiSe540,52, the CBM and VBM of thicker (13-nm thick) Ta2NiSe5 are ~ 4.6 eV and 4.93 eV with a bandgap of 0.33 eV. The offset of Fermi levels between the WSe2 and Ta2NiSe5 is measured to be ~111.5 meV (Supplementary Note 5). The band diagram of the device are then determined as illustrated in Supplementary Note 5, which shows the formation of a type-I heterojunction as well. 

Accordingly, the energy band diagram when the device is negative biased is depicted in Fig. 2c. Since the external bias direction is identical to the built-in electric field in WSe2/Ta2NiSe5 heterojunction, the enhancement of the electric field leads to an efficient separation of photogenerated electron-hole pairs when the incident light irradiates at the heterojunction region. On the contrary, when the device is forward biased. Since the built-in electric field of WSe2/Ta2NiSe5 heterojunction is opposite to the external electric field applied across the device, photoexcited-electrons in the Ta2NiSe5 are drifted towards the interface of WSe2/Ta2NiSe5 and accumulated at the heterojunction interface due to the large electron barrier (Fig. 2d). In this case, the trapped electrons at the interface acts as a negative gate, inducing a photogating effect. As a feedback of this behavior, the Fermi level of WSe2 would shift downwards, so the hole concentration increases, fostering the tunneling of hole carriers from drain electrode to WSe2 which are then transported to source electrode. It is noteworthy that the tunneling of carriers have been proved to be feasible in improving the device response speed in recent reports<sup>53</sup> . To verify the carrier tunneling in our device, the photoresponse curves under light illumination of different wavelengths were measured (Fig. 2e, f and Supplementary Fig. 10). The curves at positive bias voltages are well modeled by a tunneling barrier with the Simmons approximation (Fig. 2g). The fitting plot of ln (I/V<sup>2</sup> ) versus 1/V shows linear dependence with a negative slope under larger Vds, and rises exponentially under small Vds under light illumination, as demonstrated in the figures. Thereby, the dominant tunneling occurs with direct tunneling (DT) at low bias voltage and Fowler–Nordheim tunneling (FNT) at higher voltage (see detailed analysis in Supplementary Note 7)<sup>45,54</sup> . The above observations indicate that the tunneling-dominated transport of charge carriers at the interface of metal/WSe2 dominates the device behavior under positive biases. 

To further explore the effect of incident light on the tunneling barrier of the device, we calculated the change of carrier concentration in the material under different incident light intensities. The change in carrier concentration can be estimated by Δn ðpÞ = Cg ΔqjV thj45,55, where q is electronic charge (1.6 ×10<sup>−19</sup> C), Cg is the gate capacitance (1.23 ×10<sup>−8</sup> F cm<sup>−2</sup> for 300 nm SiO2), Vth is the threshold voltage, which can be extracted from the transfer curve of the heterojunction device in Fig. 2f and Supplementary Fig. 10. The change in the hole concentration (Nd) is expressed as ΔNd = ΔntðpÞ<sup>~~,~~wheretrepresentsthematerial</sup> 

Nature Communications |  (2024) 15:141 

3 

Article 

https://doi.org/10.1038/s41467-023-44482-7 



<!-- Start of picture text -->
a Source Ta2NiSe5 c e 10 -7 V gs=0 V 532 nm<br>WSe2 10 -8<br>-1.979E-7 A - - - -<br>WSe2 Ta2NiSe5 10 -9 17.6<br>20.3<br>- - - 10 -10 23.525.6<br>Drain 10 -11 30.934.6<br>Source 36.6<br>V dsDrain  = -1 V 0 A 10 -12    μW/mm41.3Dark     2<br>10 -13<br>-1.0 -0.5 0.0 0.5 1.0<br>V ds = -1 V V ds (V)<br>f 10 -6<br>b d V ds=1 V  532 nm  Dark20.3<br>Source Ta2NiSe5 WSe2 10 -7 23.5<br>WSe2 8.51E-7 A - - - - -- Ta- -2NiSe5 10 -8 30.934.636.741.325.6<br>10 -9   μW/mm 2<br>Source<br>Drain 10 -10<br>Drain  0 A Δ V gs<br>V ds = 1 V 10 -11 -4 -2 0 2 4<br>V ds = 1 V V gs (V)<br>g 2x10 15<br>-14-12  30.9 Dark 41.3 17.6 532 nm h 1x108x104x10 141415 785 nm i 4  t t tLLL (785 nm) (532 nm) (635 nm) 1010 10<br>  μW/mm 2 8x10 14 3 10 -1<br>-16 6x10 14 635 nm5 10 15 20 25 10 -2<br>4x10 14<br>-18 Photogating-assisted  2x10 14 2 1010 -3-4<br>-20 tunneling 6x104x10 1414 0 532 nm 5 10 1 •• (785 nm) (635 nm) 10 -5<br>2x10 14 • (532 nm) 10 -6<br>-22 -1.0 -0.5 0.0 0.5 1.0<br>25 30 35 40<br>0 10 20 30 40 50<br>Power density (μW/mm 2 ) V ds (V)<br>1/V (V -1 )<br> (A) I ds<br> (A) I ds<br>22ln (I/V) (A/V) -3 (cm)Δ N d<br>Carrier lifetime, (ms)•<br>L (ms) Carrier transit time, t<br><!-- End of picture text -->

Fig. 2 | The photogating-assisted tunneling in the WSe2/Ta2NiSe5 heterostructure. The spatially resolved photocurrent mapping images at (a) Vds = −1 V and (b) Vds = 1 V. The scale bar is 7 μm. The illumination wavelength is 532 nm. The white, blue and yellow dashed lines indicate the regions of WSe2, Ta2NiSe5 and metal electrodes, respectively. The energy band diagrams of the WSe2/Ta2NiSe5 heterostructure device at (c) Vds = −1 V and (d) Vds = 1 V, respectively. The arrow indicates the direction of carrier transport, and the horizontal dashed line represents the Fermi level of the material. e Output curves (Ids-Vds) in dark and under illumination with different power densities. The incident light is at 532 nm 

wavelength, and Vgs = 0 V. f Transfer curves (Ids-Vgs) of the device at Vds = 1 V. ΔVg and the shaded area represent the range of the change of the charge neutrality point. g Fowler–Nordheim plots of the device at positive Vds in dark and under illumination. The dashed lines are the fits to the experimental data. h The changes in hole density (ΔNd) in the device as the increase of incident light power at different wavelengths. Vds = 1 V. The solid lines are drawn to guide the eye. i The extracted photocarrier lifetime (solid lines) and carrier transit time (dashed lines) of the device under different Vds. The solid and dashed lines are drawn to guide the eye. 

thickness, which is 60 nm for WSe2 in the device investigated. It is obvious from the Supplementary Fig. 10 that as the incident light intensity increases, Vth gradually moves towards positive gate voltage. According to the change of Vth, we calculated the change of carrier concentration for different incident light power, as shown in Fig. 2h. Based on this, we can conclude that Nd increases as promoting the optical power density. The tunneling barrier width, d, is reduced accordingly, following the relationship of d / 1=Nd 56, thus a thinner barrier width or a higher tunneling probability further assists the tunneling of carriers, leading to a photogating-assisted tunneling in the device. 

Based on above, a simultaneous increase in device responsivity and response speed under positive Vds are expected due to the photogating-assisted tunneling effect. On one hand, the responsivity scales with the gain, which is significantly enhanced in our device due to the reduction of transit time via the tunneling process; On the other hand, the carrier lifetime is also reduced by managing the trap sites which assists the recombination of photon-excited carriers, leading to a fast response speed. In other words, a large number of photogenerated electrons are blocked in the Ta2NiSe5 conduction band by the barrier of energy band under positive bias, which act as the role of shallow trap sites that capture photogenerated carriers with a shorter 

lifetime. In comparison, the intrinsic carrier traps with both shallow and deep energy levels in the materials plays a dominant role under negative bias, featuring a relatively longer lifetime. The measurements of the carrier transit time and photocarrier lifetime of the device under different Vds is shown in Fig. 2i, in good accordance with above analysis (Details on the extraction process are illustrated in Supplementary Note 8). 

### Responsivity-speed relations of WSe2/Ta2NiSe5 device 

To look into the responsivity-speed relations, we further analyze the optoelectrical properties of WSe2/Ta2NiSe5 heterostructure devices under monochromatic light illuminations (see details in Supplementary Note 9). According to the power-dependent photoresponse, the responsivities, R, against power density are acquired at different Vds (Fig. 3a). Notably, a high responsivity is obtained with R = 2.2 ×10<sup>4</sup> A /W (780 nm, 0.05 μW/mm<sup>2</sup> ) when Vds = 1 V is applied, which is orders of magnitudes higher than that at Vds = −1 V (8.8 A/W). Similar enhancement at positive Vds is also observed in multiple devices (Fig. 3c). The R values are decreased with promoting light power at Vds = ±1 V, and this phenomenon was generally attributed to the shortened photoinduced carrier lifetimes by Auger processes or by the saturation of trap states under a high photon flux<sup>21,57</sup> . The device noise spectral densities (Sn) is 

Nature Communications |  (2024) 15:141 

4 

Article 

https://doi.org/10.1038/s41467-023-44482-7 



<!-- Start of picture text -->
a 10 5 R ( V ds= 1 V)  D* ( V ds= 1 V) b 6x10 -10 V ds= 1 V 3.2x10 -8<br>R ( V ds= -1 V)  D* ( V ds= -1 V) 10 14 5x10 -10 V ds= -1 V 3.0x10 -8<br>10 4<br>10 3 10 13 4x10 -10 α=0.07 2.8x10 -8<br>10 2 3x10 -10<br>α=0.879 2.6x10 -8<br>10 1 10 12 2x10 -10<br>2.4x10 -8<br>10 0<br>10 11 1x10 -10<br>10 -1 2.2x10 -8<br>0<br>10 -2 10 10<br>0 5 10 15 20 25 0 5 10 15 20 25<br>Power density (μW/mm 2 ) Power density (μW/mm 2 )<br>c d<br>10 4<br>10 3 10 3<br>10 2<br>   Device    Device<br> 1  1<br>10 1  2 10 2  2<br> 3  3<br> 4  4<br>10 0  5  5<br> 6  6<br>10 -1 10 1<br>-1 0 1 -1 0 1<br>V ds (V) V ds (V)<br>Speed requirement<br>e 0 f for imaging<br>10 7 Fast<br>-2 f 3dB=195 KHz 10 6 High Gain<br>-4 3 8000 Hz 10 5 This work<br>10 4 Power<br>consumption<br>-6 2 10 3 (W)<br>-8 1 10 2<br>10 1  Single material<br>-10 00.0 0.2 0.4 10 0  2D/2D 2D/3D<br>Time (ms) 10 -1  0D/2D This Work<br>-12<br>10 0 10 1 10 2 10 3 10 4 10 5 10 -2<br>10 -7 10 -6 10 -5 10 -4 10 -3 10 -2 10 -1 10 0 10 1 10 2<br>Light modulation frequency (Hz)<br>Time (s)<br>R (A/W) D* (Jones)  (A) I ph ph (A) I<br> (A/W) R<br>ime (μs) R ise  T<br> (μA) I ds<br>R (A/W)<br>Relative response (dB)<br><!-- End of picture text -->

Fig. 3 | The responsivity-speed relations of the WSe2/Ta2NiSe5 heterostructure. a Extracted device responsivities, R (solid lines), and detectivities, D* (dashed lines), at Vds = −1 V and 1 V, respectively. b Extracted power dependence of the measured photocurrent at different Vds. The solid lines are the exponential fitting between photocurrent and optical power. c Responsivity distribution of devices with different thicknesses. WSe2/Ta2NiSe5: Device 1(D1): 60/13 nm; D2: 69/17 nm; D3: 35/ 23 nm; D4: 13.5/32.9 nm; D5: 10.1/11.6 nm; D6: 6.9/24.1 nm. The different shaded area indicates positive and negative bias conditions. d Response time of devices with different thicknesses. e Relative response with the modulation frequency 

measured for Device 6. Inset: The time-dependent current of the device. The f3dB is defined as the laser modulation frequency when the photocurrent reduces to 0.707 of the maximum value. f The performance comparison with previous reports (gray ellipsoid). Details of quoted references should refer to Supplementary Fig. 18. The WSe2/Ta2NiSe5 heterostructures with different thicknesses are included. Among the devices that fulfill the 1 ms speed limit (The vertical dashed line) for imaging applications, our work shows both high responsivity, fast response and low power consumption. 

derived from the time-resolved darkcurrents (Supplementary Note 11), and the corresponding specific detectivity results display similar trends as R (Fig. 3a). In addition, by fitting the power-dependent photocurrents with a power-law relationship, Iph∝P<sup>α</sup> (Fig. 3b), the α is fitted to be 0.879 at Vds = −1 V, in stark contrast, the α is 0.07 at Vds = +1 V, which means more traps or recombination centers participate in the photoresponse under positive Vds than negative Vds26,58. According to previous reports, there is a trap-induced trade-off between responsivity and response speed (if photogating effect plays a dominant role)<sup>26,46</sup> . However, in our device, this challenge is overcome with significant bias regulation, i.e., not only does the device 

responsivity improves by three orders of magnitude when +1 V bias is applied compared to −1 V bias, the response speed also improves by an order of magnitude (Fig. 3c, d), simultaneously. These phenomena reveal that the speed constrains in defects-induced photogating effect is mitigated at positive Vds. Similar phenomena were also found under the illumination of other wavelengths (e.g., 532 and 635 nm in Supplementary Note 10). Notably, the 3 dB cutoff frequency measured for the devices can reach a high value of ~ 195 kHz at Vds = 1 V (Fig. 3e). The response time of the device is estimated to be ~1.8 µs by the equation: f3dB = 0.35/tr, where tr is the response time of the device, and the corresponding responsivity is 7.3 ×10<sup>3</sup> A/W at Vds = 1 V (details shown in 

Nature Communications |  (2024) 15:141 

5 

Article 

https://doi.org/10.1038/s41467-023-44482-7 



<!-- Start of picture text -->
a 360 Photocurrent (A)-1.8x10 -10 b 360 Photocurrent (A)2.6x10 -8 c V ds= -1 V 3.5x10 -8<br>1310 nm<br>315270 -1.5x10 -10 320280 2.1x10 -8 VV dsds= 0 V= 1 V 3.0x10 -8<br>225 -1.1x10 -10 200240 1.6x10 -8 10 -10 2.5x102.0x10 -8-8<br>180<br>160<br>135 -7.8x10 -11 1.0x10 -8 1.5x10 -8<br>120<br>90 -4.2x10 -11 80 5.1x10 -9 10 -11 1.0x10 -8<br>45 1310 nm 40 1310 nm 5.0x10 -9<br>0 -6.5x10 -12 0 -1.0x10 -10 0 45 90 135 180 225 270 315 360<br>-1.0 -0.8 -0.6 -0.4 -0.2 0.0 0.0 0.2 0.4 0.6 0.8 1.0 Polarization angle (deg)<br>V ds (V) V ds (V)<br>d 10 -8 e f<br> 785 nm  1064 nm<br>0.5  808 nm  1310 nm<br>10 -9  980 nm  1550 nm<br>10 -10<br> 785 nm<br> 808 nm<br>10 -11  980 nm 1064 nm<br> 1310 nm<br> 1550 nm 0.0<br>10 -12<br>-1.0 -0.5 0.0 0.5 1.0<br>-1.0 -0.5 0.5 1.0<br>V ds (V) V ds (V)<br>Photocurrent (A) Photocurrent (A)<br>Polarization angle (deg) Polarization angle (deg)<br>R1 /RR10<br><!-- End of picture text -->

Fig. 4 | The photogating-empowered polarization photoresponse and wavelength discrimination in the WSe2/Ta2NiSe5 heterostructure. a, b Color plots of the polarization photocurrent under 1310 nm illumination at various bias voltages Vds. The photoresponse of WSe2/Ta2NiSe5 photodetector can be tuned by the Vds and the incident light polarization angle, θ. c The polarization photocurrents under 1310 nm illumination. The photocurrent showcases the same dependency on polarization angle, θ, as sweeping Vds from −1 V to 1 V. The solid lines are fits to the polarized photocurrent. d The extracted polarization sensitive contributions R1 

(Vds, λ) from the polarization photocurrents. R1 depends on both the bias voltage Vds and the incident light wavelength. e The anisotropic ratio β, R1/R0, extracted from the polarization insensitive (R0) and sensitive (R1) contributions of the polarization photocurrent. The vertical dashed line indicates the two sectors being analyzed under positive and negative bias conditions. f The calculated correlation matrix between different wavelengths, with the element as the correlation coefficient of two columns of R1: corr{R1(Vds, λ = λ1), R1(Vds, λ = λ2)}, where λ1 and λ2 are two different wavelengths. 

Supplementary Note 9). The bias tunability of our device provides a facile way to boost the device performance, and a target region that can overcome the responsivity-speed limit was reached with small power consumption (with measured values from 0.762 nW to 13 nW) which is comparable to or even lower than the commercial photodetectors based on silicon, germanium and indium gallium arsenide (e.g. FDS1010, FD10D, DSD2 from Thorlabs), as illustrated in Fig. 3f (see more details in Supplementary Fig. 18). 

Photogating-empowered polarized response under positive bias 

Since the number of the photoexcited-carriers in the Ta2NiSe5 is sensitive to polarization of incident light due to its in-plane anisotropic crystal structure, thereby, the light induced photogating at positive Vds is polarization sensitive as well. The polarization-sensitive photogating will empower the device polarized light photodetection capability under positive Vds even though the photocurrent is mainly generated at the metal/WSe2 Schottky junction. Besides, the relatively large bandgap of WSe2 (~1.2 eV) normally limits the device photoresponse to below ~1000 nm. Nevertheless, in the above polarization-sensitive photogating process, the absorption of small-bandgap Ta2NiSe5 determines the operating wavelength range, which will surpass the limitation of photoresponse range of WSe2 itself. 

To verify the above analysis, we characterized our device at different illumination wavelengths in the infrared range up to 2200 nm (Supplementary Note 12). Considering the small bandgap of Ta2NiSe5 (~0.3 eV), our device should also work at even longer wavelengths. The peak EQE reaches 3.5 × 10<sup>6</sup> % at 785 nm illumination and Vds = 1 V (Supplementary Note 13), and the EQE decreases to 157% at 2200 nm wavelength. 

In the following, we investigated the device polarization photoresponse under light illumination of different wavelengths. The schematic light path and measurement results are depicted in 

Supplementary Fig. 22. The polarization angle θ is defined as the angle between light polarization and the metal electrode edge. The photocurrent varied periodically when the θ is rotated counterclockwise from 0° to 360°, and reached the maximum when light polarization is parallel to the elongated axis of Ta2NiSe5, which is corresponding to the a-axis of the flake. Further measurements reveal that the polarization photocurrent showcases the same dependency on crystal orientation as sweeping Vds from −1 V to 1 V (Fig. 4a–c). The polarization dependent photocurrent can be described by a general formula: Iph = R0 + R1 · cos(θ + θ0), with R0 and R1 representing the polarization insensitive and sensitive contributions, respectively. Once the two factors have been extracted, we can calculate the two widely used figure of merits in polarization photodetectors: the polarization ratio as |(R0 + R1)/(R0 − R1)| and the anisotropic ratio β as R1/R0. Notably, both the R0 and R1 are functions of applied source-drain bias and the wavelength of incident light, R0 = R0 (Vds, λ) and R1 = R1 (Vds, λ), as shown in Fig. 4d, e. The polarization dependence is a result of the anisotropic structure of Ta2NiSe5, in which the optical absorption coefficient along a axis is calculated to be higher than that along c axis for both mono- and multilayer Ta2NiSe5 (Supplementary Fig. 23). The calculated ratio of absorption coefficient along different crystalline orientations (a/c) varies for different wavelengths and reaches the peak value around 1310 nm, accounting for the wavelength dependent R0 and R1, in agreement with our experiments. Furthermore, the applied source-drain bias could alter the scattering of the photocarriers in the photogating process of our device so that the anisotropic response also becomes bias-tunable (Supplementary Note 14). The dependence of photoresponse on both bias and wavelength allows our device to discriminate different wavelengths by sweeping the bias. Figure 4f shows the calculated correlation matrix between different wavelengths, with the element as the correlation coefficient of two columns of R1: corr{R1(Vds, λ = λ1), R1(Vds, λ = λ2)}, where λ1 and λ2 

Nature Communications |  (2024) 15:141 

6 

Article 

https://doi.org/10.1038/s41467-023-44482-7 

are two different wavelengths. It is worth noting that our method only requires two electrodes, a simple configuration for practical implementation of high-resolution pixels. 

## Discussion 

In summary, we report a WSe2/Ta2NiSe5 heterostructure with simultaneously improved responsivity and speed, with the aid of photogating-assisted carrier tunneling. The proposed mechanism helps achieve orders of magnitude faster carrier transit time, and shortened carrier lifetime by managing the trap sites, providing a stateof-the-art approach to address the trade-off between responsivity and speed in photodetectors based on photogating effect. Notably, the metal-induced gap state, external disorders/defects induced gap state or interface dipoles may lead to Fermi level pinning (FLP) effect at the metal contact interface<sup>59</sup> . If fully de-pining is realized with van der Waals contacts<sup>60</sup> , the device photoresponse could be further regulated by the gating effect. The observed wavelength-dependent polarization characteristics under positive biases validate that the photogating is polarization-sensitive. In the future work, the polarization photodetection in the infrared region could be further improved by coupling with plasmonic nanostructures or integrating with a circuitry amplification system, and we believe this has practical application for highly sensitive detection in multiple fields. Importantly, the tunable photoresponse of our device by switching source-drain voltages give us insight into the spectral information of incident lights, from which it is possible to reconstruct spectra from their corresponding photoresponse vectors by a unique spectral learning procedure in the future<sup>61–63</sup> . Our results combine the physics of addressing the responsivity-speed trade-off and broadband polarized photodetection with wavelength discrimination, providing possibilities for exploring novel on-chip optoelectronic applications, such as in polarization imaging, high contrast polarizer, miniaturized spectrometer, etc. 

## Methods 

### Device fabrication 

Ta2NiSe5 and WSe2 nanosheets were fabricated via the mechanical exfoliation method from single crystals grown by the chemical vapor transport (CVT) method<sup>44</sup> . Firstly, thin flakes of Ta2NiSe5 were exfoliated from its bulk crystals using scotch tape and then transferred onto a silicon substrate (with 300 nm SiO2). Then, multilayer WSe2 were exfoliated onto the polydimethylsiloxane (PDMS) film and transferred selectively on top of the Ta2NiSe5 flake under the optical microscope assisted by an 3D positioning system. To fabricate the device for measurements, the source/drain electrodes were patterned by ultraviolet photolithography, and Ti/Au (10/80 nm) metals were deposited by the thermal evaporation. 

### Characterization of WSe2/Ta2NiSe5 heterostructure 

The morphologies of the WSe2/Ta2NiSe5 heterostructure were investigated by an optical microscope (BX51, OLMPUS). The Raman mapping and PL mapping were carried out at room temperature by a confocal Raman/PL system (Alpha 300R, WITec) equipped with 532 and 633 nm laser sources. The thicknesses of the WSe2 and Ta2NiSe5 nanoflakes were measured using atomic force microscopy (Cypher S, Asylum Research). The absorption spectra of the materials were measured using a customized microfocused absorption system. 

### Optoelectrical measurements 

The electrical measurements were performed under ambient conditions at room temperature. All static behaviors of the photodetector were characterized by a semiconductor parameter analyzer (Keithley 4200) on a probe station (EVERBEING, C-4) in the dark and under illumination by different lasers: IR (2200, 1550, 1310, 1064, 980 and 808 nm), red (635 nm), green (532 nm). The device has been measured multiple times to ensure the consistency of the dark current, and the 

spot area of incident light was confirmed based on an optical microscope<sup>64</sup> . The temporal responses of the device were recorded by a current meter after the light illumination switching on-off. The device 3 dB bandwidth is measured by modulating the laser switching frequency through a signal generator (RIGOL, DG822), and the modulated optical signal was focused on the photodetector through an optical microscope. 

### Photocurrent mapping 

The spatial-resolved photocurrent mapping was conducted using scanning photocurrent microscopy built on a confocal Raman/PL system (WITec, Alpha 300R) with a high spatial resolution of about 350 nm. The device was laterally moved with steps of 0.5 μm, where a focused laser beam (532/633 nm) was raster-scanned over the whole device area. The source-drain current Ids was recorded by a current meter under various bias voltages Vds. 

### Polarization-sensitive characterization 

A linear polarizer (Thorlabs, LPVIS050) and half-wave plate were used to generate polarized light impinging on the sample in order to measure the polarization-dependent characteristics. The polarization angle was changed by rotating the polarizer. 

### DFT calculations 

All calculations were performed with the Vienna ab initio simulation package<sup>65</sup> . The projector augmented-wave (PAW) method was applied and the van der Waals interactions were considered by using DFT-D3 method<sup>66</sup> . For the geometry optimization and electronic structure calculation with Perdew–Burke–Ernzerhof (PBE) functionals<sup>67</sup> , the plane-wave cutoff energy is 500 eV and the k-point mesh for the first Brillouin zone is 4 × 10 × 1 for both Ta2NiSe5 and WSe2/Ta2NiSe5 heterostructures. A vacuum space of 20 Å is set to avoid the interaction between the adjacent slabs. The convergence of force and total energy is 0.01 eV Å<sup>−1</sup> and 10<sup>−7</sup> eV, respectively. 

The optical absorption coefficient of Ta2NiSe5 is calculated by the following equation<sup>68</sup> : 



<!-- Start of picture text -->
f f i f f i f f f f i f f i f f i f f i f f i f f i f f i f f i f f i f f i f f i f f i f f<br>αðωÞ = pð2Þ ω�qε 2 1 ðωÞ + ε2 2 ðωÞ � ε1ðωÞ�1=2 ð1Þ<br><!-- End of picture text -->

where ε1ðωÞ and ε2ðωÞ are the real and imaginary parts of the complex dielectric function, respectively. ε1ðωÞ can be obtained from ε2ðωÞ based on the Kramer–Kronig relationship. 

## Data availability 

All technical details for producing the figures are enclosed in the supplementary information. Data are available from the corresponding authors D.L., C.-W.Q. or S.L. upon request. 

## References 

1. Sun, C. et al. Single-chip microprocessor that communicates directly using light. Nature 528, 534–538 (2015). 

2. Elshaari, A. W., Pernice, W., Srinivasan, K., Benson, O. & Zwiller, V. Hybrid integrated quantum photonic circuits. Nat. Photon. 14, 285–298 (2020). 

3. Maiti, R. et al. Strain-engineered high-responsivity MoTe2 photodetector for silicon photonic integrated circuits. Nat. Photon. 14, 578–584 (2020). 

4. Yang, Z., Albrow-Owen, T., Cai, W. & Hasan, T. Miniaturization of optical spectrometers. Science 371, eabe0722 (2021). 

5. Xu, X. et al. Self-calibrating programmable photonic integrated circuits. Nat. Photon. 16, 595–602 (2022). 

6. Tian, R. et al. Chip-integrated van der Waals PN heterojunction photodetector with low dark current and high responsivity. Light Sci. Appl. 11, 101 (2022). 

Nature Communications |  (2024) 15:141 

7 

Article 

https://doi.org/10.1038/s41467-023-44482-7 

7. Hui, Y., Gomez-Diaz, J. S., Qian, Z., Alù, A. & Rinaldi, M. Plasmonic piezoelectric nanomechanical resonator for spectrally selective infrared sensing. Nat. Commun. 7, 11249 (2016). 

8. Qian, Z. et al. Zero-power infrared digitizers based on plasmonically enhanced micromechanical photoswitches. Nat. Nanotechnol. 12, 969–973 (2017). 

9. Wei, J. et al. Zero-bias mid-infrared graphene photodetectors with bulk photoresponse and calibration-free polarization detection. Nat. Commun. 11, 6404 (2020). 

10. Bullock, J. et al. Polarization-resolved black phosphorus/molybdenum disulfide mid-wave infrared photodiodes with high detectivity at room temperature. Nat. Photon. 12, 601–607 (2018). 

11. Akinwande, D. et al. Graphene and two-dimensional materials for silicon technology. Nature 573, 507–518 (2019). 

12. Romagnoli, M. et al. Graphene-based integrated photonics for nextgeneration datacom and telecom. Nat. Rev. Mater. 3, 392–414 (2018). 

13. Zhang, Z. et al. All-in-one two-dimensional retinomorphic hardware device for motion detection and recognition. Nat. Nanotechnol. 17, 27–32 (2022). 

14. Lin, K.-T., Chen, H.-L., Lai, Y.-S. & Yu, C.-C. Silicon-based broadband antenna for high responsivity and polarization-insensitive photodetection at telecommunication wavelengths. Nat. Commun. 5, 3288 (2014). 

15. Lischke, S. et al. Ultra-fast germanium photodiode with 3-dB bandwidth of 265 GHz. Nat. Photon. 15, 925–931 (2021). 

16. Miyazaki, H. T. et al. Synchronously wired infrared antennas for resonant single-quantum-well photodetection up to room temperature. Nat. Commun. 11, 565 (2020). 

17. Novoselov, K. S., Mishchenko, A., Carvalho, A. & Castro Neto, A. H. 2D materials and van der Waals heterostructures. Science 353, aac9439 (2016). 

18. Guo, Z. et al. In-situ neutron-transmutation for substitutional doping in 2D layered indium selenide based phototransistor. eLight 2, 9 (2022). 

19. Lee, D. et al. Hyperbolic metamaterials: fusing artificial structures to natural 2D materials. eLight 2, 1 (2022). 

20. Konstantatos, G. et al. Hybrid graphene–quantum dot phototransistors with ultrahigh gain. Nat. Nanotechnol. 7, 363–368 (2012). 

21. Lopez-Sanchez, O., Lembke, D., Kayci, M., Radenovic, A. & Kis, A. Ultrasensitive photodetectors based on monolayer MoS2. Nat. Nanotechnol. 8, 497–501 (2013). 

22. Huo, N. & Konstantatos, G. Ultrasensitive all-2D MoS2 phototransistors enabled by an out-of-plane MoS2 pn homojunction. Nat. Commun. 8, 572 (2017). 

23. Lee, S.-J. et al. Lead halide perovskite sensitized WSe2 photodiodes with ultrahigh open circuit voltages. eLight 3, 8 (2023). 

24. Buscema, M. et al. Photocurrent generation with two-dimensional van der Waals semiconductors. Chem. Soc. Rev. 44, 3691–3718 (2015). 

25. Nikitskiy, I. et al. Integrating an electrically active colloidal quantum dot photodiode with a graphene phototransistor. Nat. Commun. 7, 11954 (2016). 

26. Ghosh, S., Varghese, A., Thakar, K., Dhara, S. & Lodha, S. Enhanced responsivity and detectivity of fast WSe2 phototransistor using electrostatically tunable in-plane lateral p-n homojunction. Nat. Commun. 12, 3336 (2021). 

27. Flöry, N. et al. Waveguide-integrated van der Waals heterostructure photodetector at telecom wavelengths with high speed and high responsivity. Nat. Nanotechnol. 15, 118–124 (2020). 

28. Jiang, H. et al. Ultrasensitive and fast photoresponse in graphene/ silicon-on-insulator hybrid structure by manipulating the photogating effect. Nanophotonics 9, 3663–3672 (2020). 

29. Cao, G., Chen, G. & Li, X. Core–shell single-nanowire photodetector with radial carrier transport: an opportunity to break the 

- responsivity-speed trade-off. Adv. Electron. Mater. 7, 2000920 (2021). 

- 30. Wang, C. et al. Integrated lithium niobate electro-optic modulators operating at CMOS-compatible voltages. Nature 562, 101–104 (2018). 

- 31. International technology roadmap for semiconductors. http:// www.itrs.net/. 

- 32. Wei, J., Xu, C., Dong, B., Qiu, C.-W. & Lee, C. Mid-infrared semimetal polarization detectors with configurable polarity transition. Nat. Photon. 15, 614–621 (2021). 

- 33. Ni, Y. et al. Computational spectropolarimetry with a tunable liquid crystal metasurface. eLight 2, 23 (2022). 

- 34. Nakano, A. et al. Antiferroelectric distortion with anomalous phonon softening in the excitonic insulator Ta2NiSe5. Phys. Rev. B. 98, 045139 (2018). 

- 35. Di Salvo, F. J. et al. Physical and structural properties of the new layered compounds Ta2NiS5 and Ta2NiSe5. J. Less Common Met. 116, 51–61 (1986). 

36. Watson, M. D. et al. Band hybridization at the semimetalsemiconductor transition of Ta2NiSe5 enabled by mirror-symmetry breaking. Phys. Rev. Res. 2, 013236 (2020). 

37. Qiao, J. et al. Highly in-plane anisotropic two-dimensional ternary Ta2NiSe5 for polarization-sensitive photodetectors. ACS Appl. Mater. Interfaces 13, 17948–17956 (2021). 

38. Jog, H., Harnagea, L., Mele Eugene, J. & Agarwal, R. Exchange coupling–mediated broken symmetries in Ta2NiSe5 revealed from quadrupolar circular photogalvanic effect. Sci. Adv. 8, eabl9020 (2022). 

39. Lu, Y. F. et al. Zero-gap semiconductor to excitonic insulator transition in Ta2NiSe5. Nat. Commun. 8, 14408 (2017). 

40. Qiao, J. et al. Perovskite quantum dot-Ta2NiSe5 mixed-dimensional van der Waals heterostructures for high-performance near-infrared photodetection. Adv. Funct. Mater. 32, 2110706 (2022). 

41. Zhou, H. et al. Large area growth and electrical properties of p-type WSe2 atomic layers. Nano Lett. 15, 709–713 (2015). 

42. Jung, Y. et al. Transferred via contacts as a platform for ideal twodimensional transistors. Nat. Electron. 2, 187–194 (2019). 

43. Hong, X. et al. Ultrafast charge transfer in atomically thin MoS2/WS2 heterostructures. Nat. Nanotechnol. 9, 682–686 (2014). 

44. Li, L. et al. Ternary Ta2NiSe5 flakes for a high-performance infrared photodetector. Adv. Funct. Mater. 26, 8281–8289 (2016). 

45. Zhou, X. et al. Tunneling diode based on WSe2/SnS2 heterostructure incorporating high detectivity and responsivity. Adv. Mater. 30, 1703286 (2018). 

46. Liu, C.-H., Chang, Y.-C., Norris, T. B. & Zhong, Z. Graphene photodetectors with ultra-broadband and high responsivity at room temperature. Nat. Nanotechnol. 9, 273–278 (2014). 

47. Wang, Q. et al. Nonvolatile infrared memory in MoS2/PbS van der Waals heterostructures. Sci. Adv. 4, eaap7916 (2018). 

48. Mak, K. F., Lee, C., Hone, J., Shan, J. & Heinz, T. F. Atomically thin MoS2: a new direct-gap semiconductor. Phy. Rev. Lett. 105, 136805 (2010). 

49. Zhu, X., Li, F., Wang, Y., Qiao, M. & Li, Y. Pd2Se3 monolayer: a novel two-dimensional material with excellent electronic, transport, and optical properties. J. Mater. Chem. C. 6, 4494–4500 (2018). 

50. McDonnell, S. et al. Hole contacts on transition metal dichalcogenides: interface chemistry and band alignments. ACS Nano 8, 6265–6272 (2014). 

51. Nassiri Nazif, K. et al. High-specific-power flexible transition metal dichalcogenide solar cells. Nat. Commun. 12, 7034 (2021). 

52. Zhang, Y. et al. Ultra-broadband photodetection based on twodimensional layered Ta2NiSe5 with strong anisotropy and high responsivity. Mater. Des. 208, 109894 (2021). 

Nature Communications |  (2024) 15:141 

8 

Article 

https://doi.org/10.1038/s41467-023-44482-7 

53. Tao, L., Chen, Z., Li, X., Yan, K. & Xu, J.-B. Hybrid graphene tunneling photoconductor with interface engineering towards fast photoresponse and high responsivity. npj 2D Mater. Appl. 1, 19 (2017). 

54. Wu, F. et al. AsP/InSe van der Waals tunneling heterojunctions with ultrahigh reverse rectification ratio and high photosensitivity. Adv. Funct. Mater. 29, 1900314 (2019). 

55. Sze, S. M., Li, Y., Ng, K. K. Physics of semiconductor devices (John Wiley & Sons, 2021). 

56. Seeger K. Semiconductor physics (Springer Science & Business Media, 2013). 

57. Koppens, F. H. L. et al. Photodetectors based on graphene, other two-dimensional materials and hybrid systems. Nat. Nanotechnol. 9, 780–793 (2014). 

58. Feng, S. et al. An ultrasensitive molybdenum-based double-heterojunction phototransistor. Nat. Commun. 12, 4094 (2021). 

59. Liu, Y., Stradins, P., Wei, S.-H. Van der Waals metal-semiconductor junction: weak Fermi level pinning enables effective tuning of Schottky barrier. Sci. Adv. 2, e1600069 (2016). 

60. Kong, L. et al. Doping-free complementary WSe2 circuit via van der Waals metal integration. Nat. Commun. 11, 1866 (2020). 

61. Yang, Z. et al. Single-nanowire spectrometers. Science 365, 1017–1020 (2019). 

62. Yuan, S., Naveh, D., Watanabe, K., Taniguchi, T. & Xia, F. A wavelength-scale black phosphorus spectrometer. Nat. Photon. 15, 601–607 (2021). 

63. Ma, C. et al. Intelligent infrared sensing enabled by tunable moiré quantum geometry. Nature 604, 266–272 (2022). 

64. Wang, F., Zhang, T., Xie, R., Wang, Z. & Hu, W. How to characterize figures of merit of two-dimensional photodetectors. Nat. Commun. 14, 2224 (2023). 

65. Kresse, G. & Joubert, D. From ultrasoft pseudopotentials to the projector augmented-wave method. Phys. Rev. B. 59, 1758–1775 (1999). 

66. Grimme, S., Antony, J., Ehrlich, S. & Krieg, H. A consistent and accurate ab initio parametrization of density functional dispersion correction (DFT-D) for the 94 elements H-Pu. J. Chem. Phys. 132, 154104 (2010). 

67. Perdew, J. P., Burke, K. & Ernzerhof, M. Generalized gradient approximation made simple. Phy. Rev. Lett. 78, 1396–1396 (1997). 

68. Fox, M. Optical properties of solids. Am. J. Phys. 70, 1269–1270 (2002). 

## Acknowledgements 

S.L. acknowledges the financial support from the National Natural Science Foundation of China (No. 62121005, 62022081, 62334010 and 61974099), the National Key Research and Development Program (2021YFA0717600), the Natural Science Foundation of Jilin Province (20210101173JC) and Changchun Key Research and Development Program (21ZY03). K.S.N. is grateful to the Ministry of Education, Singapore (Research Centre of Excellence award to the Institute for Functional Intelligent Materials, I-FIM, project No. EDUNC-33−18-279-V12) and Royal 

Society (UK, grant 304 number RSRP\R\190000) for support. C.-W.Q. acknowledges financial support from the National Research Foundation (Grant No. NRF-CRP26-2021-0004). 

## Author contributions 

S.L., C.-W.Q. and D.L. conceived of the original concept and supervised the project. M.L., J.W. and S.L. performed most of the experiments. L.Q. and Z.S. contributed to the computational theoretical analysis. M.L. and Y.L. contributed to material preparations and characterizations. M.L. and Y.L. contributed to the photoresponse measurements. M.L., J.W., L.Q., J.A., X.L., Y.L., Z.S., K.S.N., D.L. and S.L. analyzed the data and co-wrote the paper. All authors discussed the results and commented on the manuscript. All authors have approved the final version of the manuscript. 

## Competing interests 

The authors declare no competing interests. 

## Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-023-44482-7. 

Correspondence and requests for materials should be addressed to Dabing Li, Cheng-Wei Qiu or Shaojuan Li. 

Peer review information Nature Communications thanks Jian-Bin Xu and the other, anonymous, reviewers for their contribution to the peer review of this work. A peer review file is available. 

#### Reprints and permissions information is available at 

http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2024 

Nature Communications |  (2024) 15:141 

9 

