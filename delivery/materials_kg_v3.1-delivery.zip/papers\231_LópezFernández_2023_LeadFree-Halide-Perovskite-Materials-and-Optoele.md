# Lead‐Free Halide Perovskite Materials and Optoelectronic Devices: Progress and Prospective

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Advanced Functional Materials |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 285 |
| 作者 | Iago López-Fernández, Donato Valli, Chun-Yun Wang, Subarna Samanta, T. Okamoto, Yi-Teng Huang, Kun Sun, Yang Liu et al. |
| DOI | 10.1002/adfm.202307896 |
| 源文件 | 022_LópezFernández_2023_LeadFree-Halide-Perovskite-Materials-and-Optoele.pdf |

---
**REVIEW** 

**www.afm-journal.de** 



# **Lead-Free Halide Perovskite Materials and Optoelectronic Devices: Progress and Prospective** 

_Iago López-Fernández, Donato Valli, Chun-Yun Wang, Subarna Samanta, Takuya Okamoto, Yi-Teng Huang, Kun Sun, Yang Liu, Vladimir S. Chirvony, Avijit Patra, Juliette Zito, Luca De Trizio, Deepika Gaur, Hong-Tao Sun, Zhiguo Xia, Xiaoming Li, Haibo Zeng, Iván Mora-Seró, Narayan Pradhan, Juan P. Martínez-Pastor, Peter Müller-Buschbaum, Vasudevanpillai Biju, Tushar Debnath, Michael Saliba, Elke Debroye, Robert L. Z. Hoye, Ivan Infante, Liberato Manna, and Lakshminarayana Polavarapu*_ 

**Halide perovskites, in the form of thin films and colloidal nanocrystals, have recently taken semiconductor optoelectronics research by storm, and have emerged as promising candidates for high-performance solar cells, light-emitting diodes (LEDs), lasers, photodetectors, and radiation detectors. The impressive optical and optoelectronic properties, along with the rapid increase in efficiencies of solar cells and LEDs, have greatly attracted researchers across many disciplines. However, most advances made so far in terms of preparation (colloidal nanocrystals and thin films), and the devices with highest efficiencies are based on Pb-based halide perovskites, which have raised concerns over their commercialization due to the toxicity of Pb. This has triggered the search for lower-toxicity Pb-free halide perovskites and has led to significant progress in the last few years. In this roadmap review, researchers of different expertise have joined together to summarize the latest progress, outstanding challenges, and future directions of Pb-free halide perovskite thin films and nanocrystals, regarding their synthesis, optical spectroscopy, and optoelectronic devices, to guide the researchers currently working in this area as well as those that will join the field in the future.** 

## **1. Introduction** 

Over the last decade, halide perovskites (HPs) with a general formula ABX3 (where A = CH3NH3+ (MA), HC(NH2)2+ (FA), or Cs<sup>+</sup> ; B = Pb<sup>2+</sup> or Sn<sup>2+</sup> ; X = Cl, Br or I) have emerged at the forefront of materials for high-performance optoelectronics.<sup>[1–5]</sup> Although they have been known since the late 19th century,<sup>[6,7]</sup> they have regained broad attention after the demonstration of their potential as photoactive materials for solar cells in 2009 and for light emission in 2012 by Kojima et al.<sup>[1,8]</sup> , and subsequently for LEDs in 2014 by Tan et al.<sup>[9]</sup> The 2012 breakthroughs<sup>[10,11]</sup> in HP solar cells ignited research into this field, which then spread into different sub-areas of optoelectronics.<sup>[3,4]</sup> Since then, this class of materials, especially the lead halide perovskites (LHPs), has been greatly exploited in terms of their chemistry, 

I. López-Fernández, Y. Liu, D. Gaur, L. Polavarapu D. Valli, E. Debroye CINBIO Department of Chemistry Universidade de Vigo KU Leuven Materials Chemistry and Physics Group Celestijnenlaan 200F, Leuven 3001, Belgium Department of Physical Chemistry C.-Y. Wang, M. Saliba Campus Universitario Lagoas Marcosende Institute for Photovoltaics (ipv) Vigo 36310, Spain University of Stuttgart E-mail: lakshmi@uvigo.es Pfaffenwaldring 47, 70569 Stuttgart, Germany C.-Y. Wang, M. Saliba Helmholtz Young Investigator Group FRONTRUNNER The ORCID identification number(s) for the author(s) of this article IEK5-Photovoltaik can be found under https://doi.org/10.1002/adfm.202307896 Forschungszentrum Jülich 52425 Jülich, Germany © 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH. This is an open access article under the terms of the S. Samanta, T. Debnath Creative Commons Attribution License, which permits use, distribution Centre for Nanotechnology and reproduction in any medium, provided the original work is properly Indian Institute of Technology Guwahati cited. Guwahati, Assam 781039, India 

The ORCID identification number(s) for the author(s) of this article can be found under https://doi.org/10.1002/adfm.202307896 © 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH. This is an open access article under the terms of the Creative Commons Attribution License, which permits use, distribution and reproduction in any medium, provided the original work is properly cited. 

### **DOI: 10.1002/adfm.202307896** 

**2307896 (1 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 



### **www.advancedsciencenews.com** 

optical spectroscopy, and optoelectronic devices.<sup>[2,12–15]</sup> They have received a great deal of attention from researchers working on solar cells, LEDs, lasers, and X-ray detectors.<sup>[3,12,16–20]</sup> The optical and electrical properties of LHPs, such as strong light absorption, tunable bandgap, long charge-carrier lifetime and diffusion length, solution processability, and high defect tolerance are ideal for optoelectronic devices. As a result of the intense efforts of researchers across the globe, the power conversion efficiency (PCE) of LHP single-junction solar cells has increased from 3.8% to over 25%,<sup>[1,21]</sup> while the efficiency of HP-silicon tandem solar cells has surpassed 32%.<sup>[22]</sup> In parallel, there has also been significant progress in HP LEDs, with external quantum efficiencies (EQEs) surpassing 25% for both green and red 

T. Okamoto, V. Biju Research Institute for Electronic Science Hokkaido University Sapporo, Hokkaido 001–0020, Japan T. Okamoto, V. Biju Graduate School of Environmental Science Hokkaido University Sapporo, Hokkaido 060–0810, Japan Y.-T. Huang, R. L. Z. Hoye Inorganic Chemistry Laboratory Department of Chemistry University of Oxford South Parks Road, Oxford OX1 3QR, UK K. Sun, P. Müller-Buschbaum Technical University of Munich TUM School of Natural Sciences Department of Physics Chair for Functional Materials James-Franck-Str. 1, 85748 Garching, Germany Y. Liu, X. Li, H. Zeng MIIT Key Laboratory of Advanced Display Material and Devices School of Materials Science and Engineering Nanjing University of Science and Technology Nanjing 210094, China V. S. Chirvony, J. P. Martínez-Pastor UMDO Instituto de Ciencia de los Materiales Universidad de Valencia Valencia 46980, Spain A. Patra, N. Pradhan School of Materials Sciences Indian Association for the Cultivation of Science Kolkata 700032, India J. Zito, L. De Trizio, L. Manna Istituto Italiano di Tecnologia − IIT Via Morego 30, Genova 16163, Italy H.-T. Sun Research Center for Materials Nanoarchitectonics (MANA) National Institute for Materials Science (NIMS) Tsukuba, Ibaraki 305-0047, Japan Z. Xia School of Physics and Optoelectronics State Key Laboratory of Luminescent Materials and Devices and Guangdong Provincial Key Laboratory of Fiber Laser Materials and Applied Techniques South China University of Technology Guangzhou, Guangdong 510641, P. R. China I. Mora-Seró Institute of Advanced Materials (INAM) Universitat Jaume I Castelló de la Plana, Castelló 12006, Spain 

### **www.afm-journal.de** 

colors.<sup>[23–25]</sup> Currently, perovskite solar cells and LEDs are being intensively investigated to further improve their EQE and longterm stability by device engineering and device encapsulation, tuning the composition, and reducing the trap states through passivation.<sup>[2,4,15,18,26,27]</sup> 

Parallel to all this, we have also witnessed important developments in the field of colloidal HP nanocrystals (NCs) in terms of shape and composition-controlled synthesis, self-assembly, understanding of their optical properties, and their applications to optoelectronic devices.<sup>[2,12,18,19,28–30]</sup> Unlike bulk perovskites, the optical properties of colloidal NCs are tunable not only by their composition but also through quantum confinement effects.<sup>[2,19,28,31]</sup> Most notably, the near-unity photoluminescence quantum yield (PLQY) of LHP NCs makes them promising sources for light-emitting applications including LEDs, lasers, and single-photon generation.<sup>[2]</sup> In addition, they have also been used in the fabrication of solar cells, even though their PCEs are relatively low compared to that of bulk thin films (over 25% for bulk thin films versus over 15% for colloidal NCs).<sup>[18,2,32–34]</sup> Despite great success, LHP NCs are currently undergoing further advancements regarding their colloidal synthesis, screening of ligands for improving the stability and PLQY, and efficiency of the corresponding optoelectronic devices. Besides, recently there has been an increasing interest in HP (bulk and NCs)-based X- ray detectors, and significant advancements have been made in the fabrication of high-sensitivity radiation detectors.<sup>[35–37]</sup> 

Despite rapid progress in LHPs (thin films and NCs) with a steep increase in efficiencies of the corresponding optoelectronic devices, their toxicity and instability (long-term as well as operational) has been a major concern to advance the field in a way similar to that of silicon-based devices.<sup>[38–41]</sup> The instability issues are being tackled by using 2D/3D perovskites and through surface passivation as well as device encapsulation.<sup>[2,41,42]</sup> Still, the lifetime of HP solar cells is far behind that of silicon-based solar cell modules (25 years) and the operational stability of LEDs is even worse, with some of the best-reported lifetimes being only tens of hours.<sup>[43,44]</sup> These LHPs are very sensitive to heat, air, light, moisture, and water, and their degradation releases compounds such as PbI2 that can have a very adverse impact on the environment.<sup>[45,46]</sup> This is especially problematic when PbI2 (or other compounds containing heavy metal ions) dissolves in water systems, leading to the accumulation of toxic metal ions, which then can be up-taken by living organisms.<sup>[47]</sup> 

The ideal scenario would be the replacement of Pb with nontoxic elements in halide perovskites without compromising 

P. Müller-Buschbaum Heinz Maier-Leibnitz Zentrum (MLZ) Technical University of Munich Lichtenbergstr. 1, 85748 Garching, Germany I. Infante BCMaterials Basque Center for Materials Applications, and Nanostructures UPV/EHU Science Park Leioa 48940, Spain I. Infante Ikerbasque Basque Foundation for Science Bilbao 48009, Spain 

**2307896 (2 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 





**Figure 1.** Crystal structures of ABX3 HPs (a), A2B<sup>I</sup> B<sup>III</sup> X6 DPs (b), and A2B<sup>IV</sup> X6 vacancy-ordered perovskites (c). d) Periodic table highlighting the elements that can replace Pb in LHPs. The elements that can occupy the B<sup>I</sup> , B<sup>II</sup> , B<sup>III</sup> , and B<sup>IV</sup> sites of the crystal structures shown in (a–c) are labeled with green, blue, yellow, and red, respectively. 

performance. Several studies have tackled this issue and have proposed different elements that could substitute the lead atoms based on similarity in size, charge, chemical reactivity, properties, and structural tolerance.<sup>[48–52]</sup> **Figure 1** reports the structure of HPs, halide elpasolites (double perovskites (DPs)), and vacancy-ordered perovskites with various possible elements in the periodic table (see below). The elements that could fit in the B-site (with different oxidation states) of each structure are labeled with the same colour, while the elements that have been more frequently reported are highlighted in bold. Among them, the elements in the same group as Pb (Group 14), which are tin (Sn<sup>2+</sup> ) and germanium (Ge<sup>2+</sup> ), have been the first choices (Figure 1). Especially Sn-based HPs have received significant attention because of their properties that are indeed similar to those of LHPs. However, the reported performances of Sn (or Ge)based optoelectronic devices are significantly poorer than those of LHPs.<sup>[52]</sup> In addition, they exhibit low stability due to the rapid oxidation of Sn<sup>2+</sup> and Ge<sup>2+</sup> to Sn<sup>4+</sup> and Ge<sup>4+</sup> under environmental conditions. As a result, it has been extremely challenging to synthesize stable Sn (or Ge)-based HP thin films and NCs with the same level of control achieved for LHPs.<sup>[2,5,53]</sup> Moreover, there is a debate that Sn is even more toxic than Pb, although this aspect needs to be investigated in more detail.<sup>[38]</sup> Despite these issues, there has been some success in the size 

and shape-controlled synthesis of colloidal ASnX3 perovskite NCs,<sup>[54–56]</sup> and significant advances have been made also in the fabrication of Sn-based 2D perovskite thin films.<sup>[57,58]</sup> Ge-based compounds are much less toxic, but their poor stability and performance limit their use. Moreover, only certain Ge-perovskites such as CsGeI3 exhibit suitable bandgap for solar cells.<sup>[52,59]</sup> Another possible replacement for Pb<sup>2+</sup> ions is a combination of a monovalent cation and a trivalent cation, resulting in the formation of DPs with the general formula A2B<sup>I</sup> B<sup>III</sup> X6.<sup>[2,17]</sup> As shown with a color code in Figure 1, various combinations of DPs with different B<sup>I</sup> and B<sup>III</sup> cations (B<sup>I</sup> (green) = Li, Na, K, Rb, Cs, Ag; B<sup>III</sup> (yellow) = Al, Ga, In, Sb, Bi) are theoretically possible according to the Goldschmidt’s tolerance factor.<sup>[48–51]</sup> Among them, Cs2AgBiX6 and Cs2(Ag/Na/K)(Bi/In)X6 stand out as the most extensively studied ones for their high stability, low toxicity and long charge carrier lifetime (comparable to those of LHPs).<sup>[60]</sup> There are also reports of DPs where the B<sup>III</sup> cation is a lanthanide.<sup>[61,62]</sup> Another interesting class of materials is that of vacancy-ordered DPs, with formula A2B<sup>IV</sup> X6, which can be thought of as resulting from the substitution of B<sup>I</sup> and B<sup>III</sup> ions by a B<sup>IV</sup> cation and a vacancy.<sup>[63,64]</sup> A3B2X9 is another type of Pbfree system that has been investigated, although, strictly speaking, it does not belong to the perovskite family based on its crystal structure. 

**2307896 (3 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



**Table 1.** Summary of synthesis methods used for THP NCs with various shapes. 

|Serial<br>Number|Composition|Synthetic Method|Shape of NCs|Reference|
|---|---|---|---|---|
|1.|CsSnX3 (X=Cl, Br, I)|HI|Nanocubes|[55]|
|2.|FASnI3|HI|Nanocubes|[66]|
|3.|CsSnI3<br>+(R-NH3<br>+)2Csn-1SnnI3n+1) nanosheets|HI|Nanocubes+Nanosheets|[56]|
|4.|CsSnI3|HI|Nanocubes|[71]|
|5.|Cs2SnI6|HI|Quantum Dots, Nanorods,<br>Nanowires, Nanobelts,<br>Nanoplatelets|[78]|
|6.|(OCTAm)2SnBr4|Facile aqueous acid-based<br>method|2D Layered Structure|[75]|
|7.|CsSnI3|HI|Nanoplatelets or Nanosheets|[67]|
|8.|L2[ASnX3] _n_−1SnX4, where A=FA, and X=Cl,<br>Br, or I|LARP|Nanoplatelets|[74]|
|9.|CsSnX3 (X=Br, I)|CVD|Nanowires|[81]|
|10.|CsSnX3 (X=Cl, Br, I)|CVD|Nanowires|[82]|
|11.|CsSnX3 (X=Cl, Br, I)|HI|Nanocubes|[54]|
|12.|PEA2SnX4 (X=Br, I)|LARP|Nanoplatelets|[76]|
|13.|MASnBr3-xIx|HI|Quantum Dots|[73]|
|14.|CsSnBr3|HI|Nanocages|[84]|
|15.|CsSnX3 (X=Cl, Br, I)|Solvothermal|nanorods|[83]|
|16.|Cs4SnBr6|HI|Hexagonal|[68]|
|17.|Cs2SnI6|HI|Quasi-spherical|[79]|
|18.|(4Tm)2SnI4|LARP|–|[77]|
|19.|FASnI3|HI|Nanocubes|[69]|
|20.|CsSnX3 (X=Cl, Br, I)|HI|Nanocubes|[70]|
|21.|Cs2SnI6|Metal ion metathesis|Nanoplatelets|[80]|



This review provides a discussion on the state-of-the-art of Pb-free perovskite materials regarding their preparation, optical properties (linear and nonlinear), degradation mechanisms, and their application to solar cells, LEDs, and X-ray detectors. In terms of materials, we will discuss both colloidal NCs as well as bulk thin films (2D layered and 3D). As a note of caution, while we will discuss the synthesis of colloidal HP NCs, the discussion on optoelectronic applications is mainly focussed on thin films, powders, or single crystals. This is because the potential of Pb-free colloidal HP NCs for optoelectronic devices is still relatively unexplored owing to the instability of some compositions (for example the Sn<sup>2+</sup> -based ones) and their low photoluminescence. On the other hand, the optical properties of Pbfree HP NCs as well as thin films in terms of their absorption, photoluminescence, charge carrier dynamics, spin relaxation dynamics, and charge transport properties will be briefly summarized. The Pb-free HP that will be discussed here include ASnX3, A2B<sup>I</sup> B<sup>III</sup> X6 DPs, and vacancy-ordered A2B<sup>IV</sup> X6. We will highlight the research progress in these systems in terms of their fabrication and efficiencies of the corresponding optoelectronic devices along with the outstanding challenges. Finally, an outlook of these Pb-free HP material systems and devices will be presented in terms of their synthesis/fabrication with improved stability and efficiency, having in mind the ultimate goal of their translation from the laboratory to real-world applications. 

## **2. Synthesis of PB-Free Perovskite Materials** 

### **2.1. Synthesis of Tin Halide Perovskite NCs** 

One of the outstanding challenges in the field of colloidal halide perovskite NCs is to synthesize stable tin halide perovskite (THP) NCs.<sup>[2]</sup> Despite the great progress in the shape-controlled synthesis of LHP NCs, only a few reports have demonstrated to date the synthesis of ASnX3 counterparts ( **Table 1** ).<sup>[2,54,55,65–67]</sup> A wide range of approaches (such as the hot injection (HI), ligand-assisted reprecipitation (LARP), hydrothermal, ultrasonication, and emulsion synthesis, etc.)<sup>[2]</sup> have been employed for the preparation of LHP NCs. Among all, HI and LARP are the most commonly adapted approaches for the synthesis of THP NCs.<sup>[2,46,54,55,65–67]</sup> The THP NCs can be broadly classified into three categories: i) ASnX3 (A = Cs, FA, MA; X = Cl, Br, I) type 3D HPs, ii) A<sup>’</sup> 2<sup>SnX</sup> 4<sup>(A’=organicligands;X=Cl,Br,I)type</sup> 2D layered perovskites and iii) A2SnX6 (A = Cs, FA, MA; X = Cl, Br, I) type perovskites. In this section, we summarize the main achievements in these directions, point out the key issues that remain unresolved, and present our perspectives on future research directions. 

ASnX3 Type **3D** Perovskite NCs. The synthesis of ASnX3-type CsSnX3 NCs via the HI route was first reported by Jellicoe et al.<sup>[54]</sup> They synthesized the NCs by dissolving SnX2 salts in tri-n-octyl 

**2307896 (4 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.afm-journal.de** 



**Figure 2.** a) Schematic of the synthesis of CsSnX3 (X = Cl, Br, I) perovskite NCs via the HI route. b) Low-resolution transmission electron microscopy (TEM) images of CsSnI3 NCs with different Cs:Sn ratios. The insets show the histograms of particle size for the corresponding CsSnI3 NCs. c) HRTEM image and corresponding selected area electron diffraction pattern of the sample synthesized with a Cs:Sn ratio of 0.25:4.2. The panels a, b and c are adapted with permission.<sup>[55]</sup> Copyright 2021, American Chemical Society. d) Dark-field scanning transmission electron microscopy (STEM) images of FASnI3 NCs at two different magnifications. The figure is adapted with permission.<sup>[66]</sup> Copyright 2023, American Chemical Society. e) TEM image of CsSnBr3 nanocages. f) Corresponding schematic model of a nanocage structure. The panels e and f are adapted with permission.<sup>[72]</sup> Copyright 2017, Tsinghua University Press and Springer-Verlag Berlin Heidelberg. 

phosphine (TOP) followed by their injection into a Cs-oleate precursor solution containing oleic acid (OA) and oleylamine (OLA) as ligands. However, the obtained NCs showed poor stability and low PLQYs. Later, it was found that the change of capping ligands can tune the morphology of CsSnI3 from nanocubes to nanoplatelets (NPls), though the PLQY is still low.<sup>[67]</sup> The similarity between these two works is the use of SnI2 as the source of both Sn<sup>2+</sup> and I<sup>−</sup> , resulting in a Sn/I ratio of 1:2 in the reaction medium. From the perspective of synthetic chemistry, a more flexible approach that enables facile tuning of reactants (different Sn/I ratios and ligands) is needed to suppress the formation of detrimental structural defects (Sn and halide vacancies) causing nonradiative charge-carrier recombination.<sup>[55,56,66–71]</sup> 

In a recent report, Liu et al. developed a theory-guided colloidal HI synthesis strategy to obtain high-quality CsSnI3 NCs by the rational fine-tuning of the reactant ratio in a wide range.<sup>[55]</sup> **Figure 2** a shows the schematic of the synthesis of THP NCs where Cs2CO3 was initially loaded into a three-neck flask along with octadecene (ODE), OA, and OLA and was then degassed at 80 °C. Subsequently, a mixture of tin(II) 2-ethylhexanoate (Sn(Oct)2), trimethylsilyl iodide (TMSI), and TOP was swiftly injected into the reaction flask at 180 °C, which led to a rapid salt metathesis reaction and resulted in fast nucleation and growth of CsSnI3 NCs. It has been found that the relative amount of the precursors plays a crucial role in governing the phase purity, size 

distribution, and optical properties of NCs, and importantly, a Snrich condition is required for the growth of THP NCs with a high PLQY. All these experimental results are in good agreement with the predictions based on density functional calculations (DFT) and molecular dynamics simulations (MD). Figure 2b presents low-resolution TEM images of the resulting NCs, indicating that with the increase of the Sn amount (when going from a Cs:Sn ratio of 0.25:3 to 0.25:4.8), the average size of cubic-shaped NCs increases from 26 nm (for 0.25:3) to 37 nm (for 0.25:4.8). Figure 2c shows the high-resolution TEM and corresponding selected area electron diffraction pattern of the 0.25:4.2 sample, in which it is possible to appreciate the single-crystalline nature of the NCs. It is noted that the synthesis of CsSnI3 NCs was carried out in an inert atmosphere owing to their extreme sensitivity to air. In a similar synthesis, Wang et al.<sup>[71]</sup> tried to investigate the role of surfactants on the growth kinetics of CsSnI3 NCs and revealed the formation of intermediate complexes between zwitterionic phosphatidylcholine and the precursors. It was found that the steric hindrance of branched fatty acid side-chains of phosphatidylcholine can regulate the growth kinetics of CsSnX3, enabling the synthesis of CsSnX3 NCs with a PLQY of 12%, which is among the highest ever reported.<sup>[71]</sup> Interestingly, Kang et al. found that the use of stannous oxalate (SnC2O4), Cs2CO3, and NH4I as the precursors of Sn, Cs, and I, respectively, yields CsSnI3 NCs with greatly enhanced stability yet having a low PLQY.<sup>[70]</sup> In light of 

**2307896 (5 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

these results, we envisage that simultaneously tuning the precursor ratio in a wide range (as discussed above) and using some specific capping ligands, e.g., multifunctional ligands, that can passivate the NCs’ surface might yield highly luminescent, highly stable CsSnI3 NCs. 

It was also found that the type of precursors could affect the insitu colloidal stability of THP NCs and their final morphology. For example, Wang et al. used tin(II) 2-ethylhexanoate (Sn(Oct)2) and MgBr2·6H2O as the separate precursors for Sn and Br, respectively, for the synthesis of CsSnBr3 NCs by the HI approach.<sup>[72]</sup> In this particular case, a hollow nanocage morphology was achieved via nanocubes self-assembly at _>_ 200 °C (Figures 2e, f). Notably, the selection of tin precursor, i.e., Sn(Oct)2 in this case, is the key factor for the self-assembly process via the oriented attachment of the branched ethylhexanoate group. These nanocages feature a superior stability againstmoisture, oxygen, and light at ambient conditions with respect to THP nanocubes. Nevertheless, it should be noted that the shape-controlled synthesis of stable colloidal THP NCs is still in an early stage compared to that of LHP NCs in terms of the rational control over the reactivity of reactants used for the synthesis, understanding of reaction mechanisms and reproducibility of the synthesis.<sup>[56,65]</sup> In this regard, Gahlot et al. attempted to obtain stable, tunable, and monodisperse CsSnI3 NCs exhibiting well-defined excitonic peaks by an optimized synthetic route.<sup>[56]</sup> It was found that the presence of excess SnI2 precursor and the substoichiometric Sn:ligand ratio are the keys to obtaining stable CsSnI3 NCs. Furthermore, optical and structural characterizations along with first-principle DFT calculations suggested the presence of 2D (R-NH3+)2SnI4 nanosheets, where R = C18H35. Under specific synthetic conditions, stable mixtures of 3D CsSnI3 NCs and 2D (i.e., Ruddlesden–Popper (RNH3+)2Cs _n_ −1Sn _n_ I3 _n_ +1 with _n >_ 1) nanosheets can be obtained, although their photophysical properties need to be investigated in more details. Very recently, Zhang et al.<sup>[65]</sup> reported on the mechanistic insight into the precursor chemistry of CsSnI3 perovskite NCs through a combination of various characterization techniques. They identified that the active intermediate complexes, polymeric alkanoate iodides that form via the reaction of the iodide source with oligomers present in the tin (II) carboxylates, play a role in governing the reactivity of the tin-iodide precursor, resulting in the variation in the size, size uniformity, and PLQY of CsSnI3 NCs.<sup>[65]</sup> The understanding of the reaction mechanism in the synthesis of THP NCs would not only lead to improved synthesis strategies, but also might offer guidelines for fabricating high-quality polycrystalline films that can be used for optoelectronic devices such as LEDs and photovoltaics, considering the similar defect formation mechanisms in both LHP NCs and polycrystalline films. 

There are also a few reports on the synthesis of organicinorganic hybrid THP NCs. In 2021, Dai et al. reported the synthesis of monodisperse FASnI3 perovskite NCs by the LARP approach ( **Figure 3** a). They found that FASnI3 NCs of different sizes can be readily synthesized by a swift injection of FA oleate precursor into SnI2 precursor under vigorous stirring at different temperatures.<sup>[69]</sup> The quantized energy levels are strongly dependent on the size of the NCs as shown in Figure 3b,c. Interestingly, these quantum-confined NCs with separate energy states slow down the relaxation of hot carriers by two orders of magnitude compared to LHP NCs under the same excita- 

### **www.afm-journal.de** 

tion conditions. The observed build-up time of the ground-state bleach at the band edge is two orders of magnitude slower in FASnI3 NCs than in LHP bulk and NCs, which the authors attribute to a phonon bottleneck effect (see also the optical properties section of this review for more details).<sup>[69]</sup> Similarly, Dirin et al. synthesized FASnI3 NCs with good size distribution via the HI approach.<sup>[66]</sup> They found that 10 nm FASnI3 NCs exhibit an unusually large band gap, which cannot be explained merely by quantum confinement effects. The distortion of the lattice through the split of I-sites was thus proposed (Figure 3d), considering that a reduction in the symmetry and bending of the Sn−I−Sn bond can reduce the overlap of Sn and I 5p orbitals. In addition, the HI approach has also been used for the synthesis of MASnBr3-xIx and Cs _x_ FA1– _x_ SnI3 NCs.<sup>[69,73]</sup> We point out that all reported hybrid THP NCs exhibit extremely low PLQYs, suggesting a high density of structural defects contributing to nonradiative recombination. Future studies should be focused on boosting their PLQYs, understanding the reaction mechanism, as well as the unusual photophysical properties of THP NCs. 

A<sup>’</sup> 2<sup>SnX</sup> 4<sup>-type</sup><sup>**2D layered**Perovskites. In 2016, Weidman et al.</sup> first reported the LARP synthesis of A’2SnX4-type 2D layered perovskite NPls with L2[ASnX3]n−1SnX4 formula, where L represents long-chain ligands such as butylammonium or octylammonium, A is Cs, FA, or MA, and n is the number of octahedral units cells (thickness) of the NPls.<sup>[74]</sup> The layered NPls were synthesized by dissolving the respective precursor salts, i.e., AX, SnX2, and LX in dimethylformamide (DMF) followed by mixing them with toluene. The thickness of the NPLs can be tuned by varying the LX/SnX2/AX ratio. Here, the long-chain organic ligand occupies the A-cations sites on the surface and thus hinders the growth of NCs along one dimension (Figures 4a,b), leading to the formation of layered NPls. In contrast to 3D NCs, these 2D perovskites exhibit a higher PLQY and stability against humidity. For instance, Wang et al. synthesized 2D layered (OCTAm)2SnBr4 crystals with near-unity PLQY by a facile aqueous acid-based synthetic method.<sup>[75]</sup> At first, stannous oxide powder was dissolved in hydrobromic acid by sonication, followed by the addition of aqueous H3PO2 to prevent the oxidation of Sn (II). Octylamine was then added to the above reaction mixture. The solution was then heated to 80 °C for 30 min and then cooled at 4 °C to obtain (OCTAm)2SnBr4 crystals. **Figure 4** c illustrates the typical 2D (octylammonium)2SnBr4 layered perovskite, wherein SnBr6 octahedral layers are separated by octylammonium ions. Figure 4d presents the high-resolution TEM images along with the corresponding FFT pattern that shows the interplanar spacing to be 20 Å having a proper matching with the (100) plane. Interestingly, the PLQY of the 2D layered perovskite sample remains unchanged even after 240 days of storage under ambient air and humidity 

In addition, layered NPls can be obtained by replacing the A-site cation with larger organic cations such as 2- phenylethan-1-aminium (PEA = C6H5(CH2)2 NH3+)[76] and 2- (3″′,4′-dimethyl-[2,2′:5′,2″:5″,2″′-quaterthiophen]−5-yl) ethan-1ammonium (4Tm).<sup>[77]</sup> Both, PEA2SnX4 and (4Tm)2SnI4 layered NPls with high PLQYs can be synthesized via the LARP approach. Figure 4e shows the schematic illustration of well-aligned (left) and disordered (right) 2D PEA2SnX4 (X = Cl, Br, I) NPls, while Figure 4f presents a schematic model of the (4Tm)2SnI4 

**2307896 (6 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 3.** a) TEM image of FASnI3 NCs (scale bar, 500 nm). b,c) Quantized energy levels in ≈12.1 nm and ≈8.5 nm FASnI3 NCs, assuming an ideal quantum box model. Reproduced with permission.<sup>[69]</sup> Copyright 2021, Springer Nature Limited. d) Schematic of archetypal cubic structure (left) and cubic structure with I-site disorder (right). Reproduced with permission.<sup>[66]</sup> Copyright 2023, American Chemical Society. 

crystal. It is noted that thin-film field-effect transistors made using (4Tm)2SnI4 showed enhanced hole mobility up to 2.32 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> with a dramatically improved stability over the previous benchmark material (PEA)2SnI4.<sup>[77]</sup> These 2D layered THPs have also been exploited for LEDs, while the NC-based LEDs face severe challenges regarding their stability (discussed in the section of Sn-based LEDs). 

Vacancy-ordered A2SnX6 type double perovskite. The vacancyordered A2SnX6 DPs are typically prepared by the HI approach. Wang et al. synthesized Cs2SnI6 NCs of different shapes by injecting Cs-oleate into a reaction mixture of SnI4, ODE, OA, and OLA.<sup>[78]</sup> **Figure 5** a depicts a sketch of their synthesis route of Cs2SnI6 DPs along with a photograph of the asprepared samples under UV light. Under their reaction conditions, they observed the initial formation of Cs2SnI6 quantum dots which evolved by time into nanorods, then to nanowires (NWs), and finally nanobelts and NPls. Besides, other morphologies of Cs2SnI6 NCs such as ligand-free quasi-spheres of different sizes (Figure 5b,c)<sup>[79]</sup> and NPls were also previ- 

ously reported.<sup>[80]</sup> The size of the quasi-spherical Cs2SnI6 NCs is controllable by the reaction temperature of the HI synthesis, and the various optical properties (photoinduced absorption (PIA), absorption maximum, transient absorption bleach (TA bleach), PL, and diffuse reflectance (DR)) of the NCs are strongly dependent on their average diameter, as illustrated in Figure 5b.<sup>[79]</sup> 

We point out that other methods such as chemical vapor deposition (CVD) and solvothermal reaction were also used for the synthesis of tin-based nanostructures such as CsSnX3 NWs and NCs.<sup>[81–83]</sup> Although some efforts have been devoted to the synthesis of THP NCs (as discussed above), we should note that the stability and photophysical properties ( _e.g_ ., PLQYs) of THP NCs are inferior to their Pb-based counterparts. Future studies should focus on developing more rational synthetic approaches to allow effective suppression of detrimental structural defects in THP NCs, and boosting their stability in harsh environments. This might be achieved by ligand engineering or by forming THPs in porous matrices such as TiO2 and SiO2. 

**2307896 (7 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.afm-journal.de** 



**Figure 4.** 2D layered Sn-based perovskite NPls: a,b) Schematic illustration of 2D L2[ASnI3]n−1SnI4 NPls for n = 1 and 2, respectively, and corresponding TEM image of the NPls for n = 1 and 2 (right side). Reproduced with permission.<sup>[74]</sup> Copyright 2016, American Chemical Society. c,d) Schematic of the crystal structure and HRTEM image of (OCTAm)2SnBr4 NCs, respectively. Reproduced under the terms of CC BY-NC 3.0.<sup>[75]</sup> Copyright 2019, The Authors, published by The Royal Society of Chemistry. e) Schematic illustration of well-aligned (left) and disordered (right) 2D PEA2SnX4 (X = Cl, Br, I) NPls. Reproduced with permission.<sup>[76]</sup> f) Schematic of 2D (4Tm)2SnI4 crystal structure. Reproduced with permission.<sup>[77]</sup> Copyright 2019, American Chemical Society. 

### **2.2. Synthesis of Double Perovskite NCs** 

In the last few years, various DP materials featuring interesting optical properties have been synthesized at the nanoscale, comprising Cs2AgBiX6 (X = Cl, Br, I), Cs2AgInCl6, Cs2NaInCl6, Cs2NaBiCl6, and Cs2AgSbX6 NCs (X = Cl, Br).<sup>[2]</sup> Their broadband and largely Stokes-shifted luminescence, in particular, holds great potential for a variety of applications complementary to those of the narrow-band emitting LHP NCs, e.g., for singlecomponent white LEDs, transparent luminescent solar concentrators, X-ray scintillators, remote thermometry and beyond.<sup>[85]</sup> 

### _2.2.1. Synthesis_ 

The stoichiometries of inorganic DP NCs comprise a minimum of three different metal cation species, which can be as high as six in the case of doped/alloyed systems (e.g., Bi-doped Cs2Ag1–x-yNaxKyInCl6 NCs).<sup>[2,86]</sup> From an experimental standpoint, they require the use of flexible colloidal synthesis procedures. In this regard, the early approaches developed for the synthesis of LHP NCs, dating back to 2015, were based on the use of metal halide salts (e.g., PbX2) as both the metal cation and halide precursors that were reacted with Cs-carboxylates. Such a synthesis scheme, however, was not easily extendable to quaternary or 

quinary NC compounds, just like the DPs.<sup>[30,87,88]</sup> Early reports on the synthesis of DP NCs appeared only in 2018, after Imran et al.<sup>[89]</sup> and Creutz et al. ( **Figure 6** a).<sup>[90]</sup> developed new HI synthesis procedures that relied on benzoyl or silyl halides as halide precursors. In those approaches, the halide precursors were injected in a reaction mixture prepared by mixing the metal cation precursors (e.g., acetates, oxides, and carbonates) and surfactants at the desired temperature, triggering the formation of the NCs. It should be emphasized that side reactions, which could occur prior to the injection of the halide precursor (e.g., reduction of Ag<sup>+</sup> to Ag<sup>0</sup> )<sup>[86]</sup> , should be carefully monitored to achieve control over the quality of the final DP NCs. The halide composition of the DP NCs is easily tunable by treating them with respective silyl halides (Figure 6b). The DP NCs typically have a cubic shape with a high degree of monodispersity (Figure 6c). Later, it was shown that the DP NCs can be synthesized by injection of Cs-oleate into a metal and halide precursor mixture at high temperature,<sup>[91]</sup> similar to the HI synthesis of LHP NCs. 

### _2.2.2. Compositional Engineering_ 

Most of the quaternary DP systems feature a weak PL emission or even no PL emission owing either to an indirect band gap (Cs2AgBiX6, Cs2AgSbX6) or to a direct band gap 

**2307896 (8 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 5.** a) Schematic illustration for the controlled synthesis of perovskite Cs2SnI6 NCs of different shapes (left panel) and photograph of the asprepared Cs2SnI6 samples under UV light (right panel). Reproduced with permission.<sup>[78]</sup> Copyright 2016, American Chemical Society. b,c) Scheme of ligand-free Cs2SnI6 NCs of different sizes and the effect of size on the band gap of the NCs (b), and the corresponding TEM image (c). Reproduced with permission.<sup>[79]</sup> Copyright 2017, American Chemical Society. 

characterized by a parity-forbidden transition (Cs2AgInCl6) or by a parity-allowed transition with a weak oscillator strength (Cs2NaInX6 and Cs2NaBiX6).<sup>[17,92]</sup> Unsurprisingly, a variety of compositional engineering strategies have therefore been developed to enhance the PL of these DP compounds and ultimately disclose their full potential.<sup>[2]</sup> 

_Doping_ : The introduction of Bi<sup>3+</sup> dopants in Cs2AgInCl6 NCs yields an orange PL emission with a PLQY of up to ≈11%,<sup>[93]</sup> further boosted to ≈26% by the introduction of Ce<sup>3+</sup> as codopants.<sup>[94]</sup> Similarly, the use of Sb<sup>3+</sup> dopants in Cs2NaInCl6 and Cs2KInCl6 NCs induces a bright PL emission, respectively in the blue and green regions, with QY values of ≈15−18%.<sup>[95]</sup> The broad and largely Stokes shifted PL emission of both Bi<sup>3+</sup> doped and Sb<sup>3+</sup> doped DP NCs is ascribed to the formation of self-trapped excitons (STEs) favored by the localization of the carriers—at the [BiCl6] and [SbCl6] octahedra, respectively—and by the softness of the DP lattice. The introduction of Mn<sup>2+</sup> dopants in both Cs2AgBiCl6 and Cs2AgInCl6 NCs also gives rise to a broad orange PL emission with QY values as high as ≈16% attributed, in this case, to<sup>4</sup> T1 →<sup>6</sup> A1 atomic-like d–d transitions at the Mn<sup>2+</sup> centers (Figure 6d, e).<sup>[96,97]</sup> Interestingly, Sb<sup>3+</sup> - Mn<sup>2+</sup> co-doped Cs2NaInCl6 NCs exhibit a tunable dual-emission covering the white-light spectrum with the orange-red PL component likely originating from an energy transfer process be- 

tween the STEs and Mn<sup>2+</sup> dopants.<sup>[98]</sup> The use of lanthanide dopants (Ln<sup>3+</sup> ) in Cs2AgInCl6 or Cs2AgBiX6 (X = Cl, Br) NCs instead confers them a near-infrared PL emission (≈1000 nm with Yb<sup>3+[96,99,100,101]</sup> and ≈1537 nm with Er<sup>3+[99,101]</sup> ) resulting from atomic-like f–f transitions characteristic of the Ln<sup>3+</sup> centers. 

_Alloying_ : Alternative strategies to increase the PL emission of DP compounds involve the synthesis of quinary systems by employing a combination of B<sup>I</sup> and B<sup>’I</sup> ions (or B<sup>III</sup> and B<sup>’III</sup> ions). Provided that both A2B<sup>I</sup> B<sup>III</sup> X6 and A2B<sup>’I</sup> B<sup>III</sup> X6 (or A2B<sup>I</sup> B<sup>III</sup> X6 and A2B<sup>I</sup> B<sup>’III</sup> X6) DPs have the same crystal structure with small lattice parameters mismatch, allowing them to mix into solid solutions at any ratio, this approach is referred to as alloying. For instance, the use of both In<sup>3+</sup> and Bi<sup>3+</sup> ions leads to the formation of alloyed Cs2Ag(InxBi1−x)Cl6 NCs, whose band gap can be tuned from indirect ( _x_ = 0, 0.25, 0.5) to direct ( _x_ = 0.75 and 0.9).<sup>[102,103]</sup> As a result, the intermediate Cs2Ag(In0.9Bi0.1)Cl6 composition displays a dual-color PL emission reaching a QY of 36% in the violet region.<sup>[103]</sup> Similarly, the combination of Bi<sup>3+</sup> and Sb<sup>3+</sup> ions in alloyed Cs2Ag(BixSb1−x)X6 (X = Cl, Br) also induces indirect-to-direct band gap transitions and boosts the intensity of their blue PL emission.<sup>[104,105]</sup> On the other hand, alloying of Na<sup>+</sup> and Ag<sup>+</sup> ions confers to Cs2(AgxNa1−x)BiCl6 NCs a largely Stokes-shifted PL emission centered in the red region with a maximum PLQY of ∼3% attained for the Cs2(Ag0.05Na0.95)BiCl6 

**2307896 (9 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 6.** a,b) Synthesis of Cs2AgBiX6 NCs and halide composition tuning by adding TMSX (X = Br or I). c) TEM image of Cs2AgBiBr6 NCs. Reproduced with permission.<sup>[90]</sup> Copyright 2018, American Chemical Society. d) Schematic of hot-injection synthesis of Cs2AgInCl6 NCs and Mn<sup>2+</sup> -doped Cs2AgInCl6 NCs. e) Absorption, PL, and excitation (PLE) spectra of 1.5% Mn<sup>2+</sup> -doped Cs2AgInCl6 NCs. Reproduced with permission.<sup>[97]</sup> Copyright 2018, American Chemical Society. 

composition.<sup>[106,107]</sup> In this case, the PL emission is ascribed to the radiative recombination of trapped excitons localized in spatially connected BiCl6−AgCl6 octahedra and favored by the beneficial shielding effect of the Na-rich DP matrix. 

_Doping and Alloying_ : In analogy with what has been observed in the bulk, the simultaneous doping and alloying of DP compounds represent the most valuable approach to boost their PLQYs at the nanoscale.<sup>[92,97,108]</sup> As a matter of fact, the introduction of Mn<sup>2+</sup> dopants in alloyed Cs2Ag(InxBi1−x)Cl6 NCs, while suppressing the STE emission from the DP matrix, promotes a pure Mn<sup>2+</sup> -related orange PL emission with a PLQY as high as 44.6% for the Cs2Ag(In0.9Bi0.1)Cl6 stoichiometry.<sup>[109]</sup> Interestingly, the use of Bi<sup>3+</sup> dopants in alloyed Cs2(AgxNa1−x)InCl6 NCs also yields bright orange PL emission with PLQY values reaching 22% without the use of Mn<sup>2+</sup> dopants.<sup>[110]</sup> Here, both the doping with Bi<sup>3+</sup> ions and the alloying of Na<sup>+</sup> sites with Ag<sup>+</sup> ions are essential to achieve a PL emission, as the latter stems, again, from the radiative recombination of trapped excitons localized in proximal BiCl6−AgCl6 pairs of octahedra. Crucially, the introduction of small amounts of K<sup>**+**</sup> ions into Bi<sup>3</sup><sup>**+**</sup> -doped Cs2(AgxNa1−x)InCl6 NCs results in a more favorable inter-ligand packing (probably owing to a slight increase in the lattice parameters) therefore boosting the PLQY up to 67% with the Cs2(Ag0.20Na0.73K0.07)InCl6 stoichiometry.<sup>[86]</sup> 

### _2.2.3. Dimensional Engineering_ 

Another approach to tune the optical properties of DP NCs (and in general of semiconductor NCs) is to regulate their size in order to access quantum confinement effects (e.g., going from 3D 

to 2D and 0D systems).<sup>[2,41]</sup> However, the control over the dimensionality of DPs is relatively limited. In fact, for thin film DPs, the dimensionality is controllable from 3D and 2D using organic spacer molecules, and that enables switching from an indirect bandgap of Cs2AgBiBr6 into a direct one.<sup>[113]</sup> A few attempts have also been made to obtain DP NPls with control over thickness.<sup>[41,111,114]</sup> For example, Cs2AgBiX6 (X = Cl, Br, I) DP NPls with some control over their thickness have been synthesized by temperature-controlled hot-injection synthesis (Figures 7a-c).<sup>[111]</sup> However, the NPls exhibit absorption and PL features that are similar to those of bulk Cs2AgBiBr6 DPs ( **Figure 7** b). The reaction yields monolayer NPls at room temperature, and they exhibit blue-shifted emission, likely due to direct bandgap exciton recombination.<sup>[111]</sup> However, the Cs2AgBiBr6 NPls were found to be weakly luminescent. Interestingly, the 2D Cs2AgIn _x_ Bi1- _x_ Cl6 (0 ≤ _x_ ≤ 1) DP NPls with a relatively high PLQY of 40% have been synthesized and their application to electrically driven LEDs was demonstrated (Figure 7d–f), though the EQE is only ≈0.01%, which is far lower than that of LHPs.<sup>[112]</sup> 

### _2.2.4. Surface Engineering_ 

Unfortunately, DP NCs often have much lower PLQYs compared to their bulk counterparts. This difference is commonly ascribed to an incomplete surface passivation of colloidal NCs after the synthesis and/or washing which leads to the presence of under-coordinated ions at their surface and can, in turn, result in the emergence of mid-gap electronic states.<sup>[115–117]</sup> In contrast to the “defect tolerant” LHP systems, DP systems are particularly prone to the formation of these so-called surface trap 

**2307896 (10 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 7.** a) Schematic of the synthesis of Cs2AgBiBr6 DP NPls. (b,c) UV–vis absorption and PL spectra (b) and corresponding TEM image (c) of Cs2AgBiBr6 DP NPls. Reproduced with permission.<sup>[111]</sup> Copyright 2021, American Chemical Society. DP NPl LEDs: d) Schematic of device architecture of DP-NPl LEDs; e) cross-sectional scanning electron microscopy (SEM) image of the device; and f) electroluminescence (EL) spectra of the device. Reproduced with permission.<sup>[112]</sup> Copyright 2023, Wiley-VCH GmbH. 

states.<sup>[118]</sup> For example, the lower PL QY values observed in Sb<sup>3+</sup> -doped Cs2NaInCl6 and Cs2KInCl6 NCs (≈15−18%) compared to those of the bulk materials (≈90%) are attributed to an efficient hole trapping in mid-gap trap states that originates from the under-coordinated surface Cl sites. These traps compete with the emissive SbCl6 centers for charge-carrier localization.<sup>[95]</sup> Similarly, the ultrafast component of the PL decay curves recorded in all Cs2(AgxNa1−x)BiCl6 NC samples, which renders a fraction of the NCs non-emissive or dark at cryogenic temperature, is consistent with the rapid dissociation of trapped charge-carriers (located at the BiCl6−AgCl6 centers) by non-radiative electron trapping at under-coordinated surface Bi sites.<sup>[101]</sup> Analogously, the ultrafast trapping of holes revealed in Bi<sup>3+</sup> -doped Cs2(AgxNa1−x)InCl6 NCs is ascribed to mid-gap trap states originating from under-coordinated surface Cl sites, which prevent their localization at the emissive BiCl6−AgCl6 centers.<sup>[27]</sup> 

To mitigate this issue and to narrow the gap between bulk and nano-sized DP materials in terms of PLQYs, a few surface engineering strategies have recently been explored. In particular, by systematically varying the hydrocarbon chain length of both alkylamines and carboxylic acids employed as surfactants in the synthesis of Bi<sup>3</sup><sup>**+**</sup> -doped Cs2(AgxNa1−x)InCl6 NCs, it is possible to raise the PLQY from 22% with the standard combination of oleylamine and oleic acid (see above) up to 37% with the optimal combination of decylamine and dodecanoic acid.<sup>[27]</sup> Interestingly, by employing GeCl4 as the Cl precursor for the synthesis of Bi<sup>3</sup><sup>**+**</sup> -doped Cs2(AgxNa1−x)InCl6 NCs, the PLQY further rise up to 60%, most likely owing to the formation of NCs with Cl-rich surfaces, i.e., exhibiting a low density of under-coordinated Cl surface sites.<sup>[119]</sup> 

### _2.2.5. Future Challenges and Outlooks_ 

Overall, considering the huge array of potentially compatible B<sup>I</sup> and B<sup>III</sup> cations, only a few (complex) DP systems have been experimentally investigated to date, especially at the nanoscale. For instance, the combination of doping and alloying approaches, which gives optimal results in terms of PL efficiency, has been reported only in two cases. Moreover, co-doping approaches, involving two substituent ions, have not been yet fully exploited to achieve bright and tunable PL emission in DP NCs. Therefore, we believe that the development of increasingly sophisticated compositional engineering strategies will represent an interesting research direction in the field. A few reports demonstrated the potential of 2D DP NPls for photocatalytic and LEDs, but they haven’t been explored as much as the 2D LHP NPls. 

While our knowledge of the ligand shell of Pb-based perovskite NCs is reaching maturity, we know much less about the surface passivation of DP NCs, which seems to play a crucial role in the formation of detrimental surface trap states. In this context, ligand shell engineering via direct synthesis or post-synthesis ligand exchange would help to improve the PLQY of DP NCs and represent another important research direction. Alternative approaches to get rid of surface traps rely on the growth of a (thick) shell of a wider band gap material onto the (photo)active NC core. These have been vastly exploited in II−VI and IV−VI metal chalcogenides but not yet in DP NCs. 

## **3. Optical Properties and Charge Carrier Dynamics** 

The optical properties of HPs are strongly dependent on the [BX6]<sup>4−</sup> octahedral network. For instance, replacing Pb with Sn 

**2307896 (11 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



**Table 2.** Comparison of ultrafast processes, mobility and diffusion length of charge-carriers in Pb-based versus Pb-free perovskites. 

|Perovskite Material|Cooling|Spin Relaxation|Trapping|Recombination|Mobility [cm<sup>2 </sup>V<sup>−1 </sup>s<sup>−1</sup>]|Diffusion length|
|---|---|---|---|---|---|---|
|CsPbCl3 NCs|290 fs<sup>[139]</sup>||1.6 ns<sup>[139]</sup>|12.7 ns<sup>[139]</sup>|30<sup>[157–160]</sup>||
|CsPbBr3 NCs|310 – 390 fs<sup>[125,131]</sup>|1.9 – 3 ps<sup>[126,161]</sup>|45 ps<sup>[140]</sup>|2 ns<sup>[140]</sup>|4500<sup>[162]</sup>|9.2μm<sup>[162]</sup>|
|CsPbI3 NCs|560 – 580<br>fs<sup>[125,140,141]</sup>|6 – 32 ps<br>(≈50K)<sup>[132,161]</sup>, 3.2<br>ps<sup>[126]</sup>|215 ps<sup>[140]</sup>|_>_2 ns<sup>[140]</sup>|118<sup>[163]</sup>|1 – 1.5μm<sup>[164]</sup>|
|MAPbBr3 NCs|270<sup>[131]</sup>|6 ps<sup>[161]</sup>|||57 – 97<sup>[165]</sup>|0.1 – 10μm<sup>[166]</sup>|
|MAPbI3 NCs|400 fs<sup>[142]</sup>|7 ps<sup>[167]</sup>, 10 ps<br>(77K)<sup>[161]</sup>||5.6 ns<sup>[142]</sup>|30 – 70<sup>[158–160]</sup>|0.1 – 10μm<sup>[166]</sup>|
|FAPbBr3 NCs|210 fs<sup>[131]</sup>||||14<sup>[168,169]</sup>|6.25μm<sup>[170]</sup>|
|2D-Layered Perovskites|200-700 fs<sup>[171]</sup>|7 ps<sup>[172]</sup>|15 ps<sup>[173]</sup>|_>_150 ps<sup>[173]</sup>|6 – 11<sup>[174]</sup>|_<_1 – 2.4μm<sup>[170,175]</sup>|
|Cs2AgBiBr6 NCs|250 – 800<br>fs<sup>[132,135,176]</sup>||40 ps<sup>[176]</sup>, 4.7 and<br>49 ps<sup>[135]</sup>|100 ns<sup>[176]</sup>|0.37<sup>[177]</sup>|0.11 – 0.23μm<sup>[177,178]</sup>|
|FASnI3 NCs|14.3 ps<sup>[69]</sup>||||22<sup>[179]</sup>||
|CsSnBr3 NCs||18 ps<sup>[149]</sup>|||||
|CsMnBr3 NCs|50 ps and 400<br>ps<sup>[151]</sup>|||605 ps<sup>[151]</sup>|||
|Cs3Bi2I9|1 ps and 30 ps<sup>[156]</sup>|||_>_3 ns<sup>[156]</sup>|4.6 – 6<sup>[180,181]</sup>|62 – 143μm<sup>[180]</sup>|



results in a decrease of their bandgap and thus leads to a redshifted emission. In contrast, Bi-based DPs are very weakly emissive due to their indirect bandgap nature. Therefore, understanding the optical properties and hot-carrier dynamics is critical for the design of suitable materials for high-efficiency optoelectronic devices. In the last few decades, the charge carrier dynamics of various semiconductors have been significantly explored. For example, the extraction of hot carriers prior to their relaxation could help to overcome the Shockley– Queisser limit in a single junction solar cell.<sup>[120]</sup> The majority of the works on hot carrier dynamics in different semiconductors have been focused on relaxation, extraction, and multiplication,<sup>[121–123]</sup> and the early works on hot carrier dynamics of Pb-based chalcogenides<sup>[123]</sup> have been used as a basis for later studies on Pb-halide perovskites.<sup>[124]</sup> Halidedependent hot carrier relaxation has been studied in Pb-halide perovskites via ultrafast TA and PL (e.g., streak camera imaging, up-conversion) techniques.<sup>[125,126]</sup> The hot carrier relaxation is often found to be phonon-mediated in LHPs, leading to the evolution of both small and large polarons.<sup>[127–130]</sup> Moreover, strong cation-dependent carrier relaxation has also been reported.<sup>[131]</sup> While significant advances have been made in understanding the charge carrier dynamics of LHPs, Pb-free perovskites are comparatively much less explored in this direction. This section briefly discusses the current understanding of the optical properties and charge carrier relaxation of THPs as well as DPs. **Table 2** summarizes the time scales for hot carrier cooling, spin relaxation, trapping, recombination, charge-carrier mobility, and diffusion length for Pb-free systems in comparison with LHPs. 

Among all Pb-free perovskites, Bi-based Cs2AgBiX6 DP NCs (X = Cl, Br, I) have gained significant attention due to their chemical stability and interesting optoelectronic properties.<sup>[2,103,132,133,40]</sup> **Figure 8** a shows the absorption and PL spectra of a Cs2AgBiBr6 thin film at room temperature (295 K) and a cryogenic temperature (4 K).<sup>[134]</sup> The absorption spectrum at room temperature 

shows a strong peak at ≈2.8 eV, which becomes a little narrower at 4 K without any spectral shift. Besides, a large Stokes shift in the PL spectra is observed both at room temperature (295 K) and at cryogenic temperatures (4 K), without any appreciable difference in their PL maxima. Unlike Pb-perovskites, Bibased DPs exhibit very weak PL, with a PLQY of less than 1%. Generally, the sharp and intense feature in the absorption spectrum of Cs2AgBiX6 DPs is attributed to bound excitons, while the broad and large Stokes-shifted PL has been assigned to selftrapped emission or phonon-assisted indirect bandgap emission (Figure 8b).<sup>[40,132,134,135]</sup> The strong exciton resonance in the absorption spectrum and large Stokes-shifted PL have significant consequences on the charge carrier dynamics, which will be discussed in the later part of this section. Similar to Pb-perovskites, the optical properties of ASnX3 NCs are tunable by their halide composition as well as their dimensions. Figure 8c,d reports the absorption and PL spectra of FASnI3 NCs grown at different reaction temperatures (from 25 to 125 °C) which correspond to a size range of 7.3 to 12. 1 nm.<sup>[69]</sup> A wide tunability of the optical spectra, from 650 to 750 nm, is clearly evident for this size range. The size of the NCs has an important consequence on their charge carrier dynamics, as revealed later on in this section. 

To understand the marked differences in the optical properties of Cs2AgBiX6 DPs from those of Pb-based perovskites, the charge carrier dynamics of these materials have been investigated using several ultrafast optical spectroscopic techniques, such as TA, time-resolved PL imaging, and terahertz pump-probe.<sup>[2,40]</sup> For instance, Dey et al. studied the charge carrier dynamics of Cs2AgBiX6 NCs using ultrafast pump-probe and time-resolved PL spectroscopy. The high energy PL peak was attributed to direct band gap emission caused by the formation of a direct bound exciton, while the commonly observed low energy PL with a large Stokes shift was assigned to the indirect transition.<sup>[132]</sup> The time-resolved PL emission spectra acquired with above-bandgap excitation revealed that the PL spectra continuously redshifted from 430 nm in the first 10 ps and finally settled at 650 nm 

**2307896 (12 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 8.** a) Steady-state absorption and PL spectra of a Cs2AgBiBr6 thin film at 4 K and 295 K. b) Schematic illustration of optical transitions in indirect bandgap Cs2AgBiBr6 semiconductor, and a typical phonon induced transition (Egd and Egi refers to direct and indirect bandgap, respectively). Steady State absorption (c) and PL (d) spectra of FASnI3 NCs prepared at different growth temperatures, corresponding to NCs of different sizes. The inset of (d) is a photograph of the corresponding colloidal suspensions. Figures are reproduced with permission.<sup>[134]</sup> (a),<sup>[135]</sup> (b), and<sup>[69]</sup> (c,d). Copyright 2021, American Chemical Society, Reproduced under the terms of CC BY-NC 4.0.<sup>[135]</sup> Copyright 2021, The Authors, published by American Association for the Advancement of Science and Copyright 2021, Springer Nature. 

(Figures 9a,b). The authors attributed the 1 eV redshift within the first 10 ps to the electron scattering from the X-point to the minimum of the conduction band, thus the direct bound exciton becomes indirect, as shown in **Figure 9** d. The faster PL decay (≈3 ps) at 450 nm is consistent with the large binding energy of the direct bound exciton (Figure 9b). In contrast, due to the transfer of direct to indirect bound exciton via electron intervalley scattering, the effective mass of the electron is reduced, leading to smaller exciton binding energy and slower PL decay at the red region of the spectrum (Figure 9b). Furthermore, femtosecond TA spectra in the first 3 ps evidence a low energy bleach at 430 nm due to the direct bound exciton as well as a high energy bleach due to higher lying energy states (Figure 9c). The bleach at 430 nm has a finite rise of ≈320 fs due to the holetrapping process, inducing the formation of the bound exciton, while the higher energetic bleach has a pulse-width limited rise (Figure 9d). 

As discussed previously, the optical properties of DPs are tunable by partially replacing Bi with In or by partially replacing Ag with Na. In this regard, Luo et al. demonstrated an increase in PLQY of Cs2AgInCl6 DPs by partly replacing Ag with Na.<sup>[92]</sup> The increase in PLQY is assigned to the reduction in the electronic dimensionality of the semiconductor by the breakdown of dark transition. Similarly, and as al- 

ready mentioned, Yang et al. demonstrated the tunability of the indirect bandgap of DPs into direct bandgap by partially replacing Bi with In, by forming Cs2AgInxBi1-xCl6 DPs. Both the direct and indirect bandgap DP NCs were investigated by TA as well as DFT calculations (Figure 9e,f).<sup>[103]</sup> While the early time TA spectra of Cs2AgBiCl6 and Cs2AgInxBi1-xCl6 NCs are very similar, the later time spectra show an enhancement of the induced absorption signal in the below-bandgap region of In-alloyed DPs. In contrast, pure Bi-based DPs show bleaching at a longer time delay in the sub-bandgap states ( _>_ 450 nm). Accordingly, the transition is referred to as indirect bandgap transition in the presence of high-density trap states. The presence of a strong induced absorption signal and the absence of sub-bandgap bleaching signal in In-incorporated DPs suggest a direct bandgap transition with negligible trap states. 

A further detailed time-resolved investigation of Cs2AgBiBr6 DPs has been carried out by considering stronger self-trapping of free carriers through deformation potential caused by Fröhlich coupling.<sup>[135]</sup> By the combined study of transient reflection (TR), time-resolved terahertz spectroscopy (TRTS) (Figure 9g), and DFT calculations it was shown that ultrafast self-trapping in Cs2AgBiBr6 DPs causes the formation of highly localized polarons within a few picoseconds, leading to enhancement in 

**2307896 (13 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 9.** a) Time-resolved PL spectra of Cs2AgBiBr6 DP NCs, b) corresponding PL decay transients at different wavelengths upon 375 nm laser excitation, and c) TA spectra of the same sample upon 330 nm pump excitation (linear absorption spectrum is also shown on the top for comparison). d) Schematic illustration showing ultrafast hole trapping and electron intervalley scattering, thereby direct to indirect bound exciton formation in Cs2AgBiBr6 NCs. e) TA spectra Cs2AgIn0.75Bi0.25Cl6 at indicated time delays upon 320 nm pump excitation. f) Band structure of the Cs2AgIn0.75Bi0.25Cl6 showing direct bandgap character upon In incorporation. g) Terahertz transmission kinetics of Cs2AgBiBr6 polycrystalline sample under different pump fluences in time-resolved terahertz spectroscopy (TRTS) measurements. h) Generalized energetic schematic of DP for carrier self-trapping in ultrafast timescale. i) Temperature-dependent effective charge carrier mobilities for the delocalized (green) and localized (blue) states. Reproduced with permission.<sup>[132]</sup> (a–d),<sup>[103]</sup> (e,f),<sup>[135]</sup> (g,h), and r<sup>[134]</sup> (i). Copyright 2020 and 2018 American Chemical Society; Reproduced under the terms of CC BY-NC 4.0.<sup>[135]</sup> Copyright 2021, The Authors, published by American Association for the Advancement of Science. 

the radiative recombination. The self-trapping in Cs2AgBiBr6 DPs with a decay time of ≈4.7 ps is in contrast to the typically observed subpicosecond Fröhlich polaron formation time in Pbbased perovskites. The observed sub-picosecond (0.25 ps) component of the direct exciton relaxation is consistent with the period of a typical longitudinal optical (LO)-phonon vibration. Therefore, the fast decay is attributed to the hot carrier relaxation via LO-phonons and the formation of a Fröhlich polaron. The slower component of the relaxation, which is an order of magnitude slower (4.7 ps), is translated to a phonon energy of ≈1 meV, typical for an acoustic phonon frequency. Therefore, the 

slow component is attributed to the electron–acoustic phonon coupling and ultrafast self-trapping of the carriers by the acoustic phonons (Figure 9h). These results are consistent with the TRTS measurements (Figure 9g), which probe the photoconductivity of the material and thus are insensitive to the chargeneutral exciton. This further supports the argument of carrierphonon interaction, although due to the limited time-resolution (≈1 ps) the sub-picosecond electron-LO-phonon coupling can not be resolved in this case. Furthermore, the Herz group performed cryogenic THz photoconductivity measurements on several DPs to reveal strong carrier-lattice interaction, leading to 

**2307896 (14 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 10.** TA spectra of FASnI3 NCs under a) 1.97 eV and b) 3.1 eV pump excitation. Low and high energy bleach transients for FASnI3 NCs of sizes c) 12.1 nm and d) 8.5 nm under 3.1 eV excitation. e) Singular-value decomposition component spectra obtained from TA measurements of pure FASnI3, FASnI3 +SnF2 and FASnI3 +SnF2 EDAI2, respectively. TA spectra of CsSnBr3 NCs with f) co- and g) counter-circular pump-probe polarization configurations ( _𝜆_ pump = 640 nm). h) Normalized TA kinetics of the low energy bleach (640 nm, B1) with co- (green) and counter- (red) circular polarization condition, and their simultaneous exponential fit with 18 ps spin-relaxation time. i) Schematic illustration for the electron-hole exchange induced spinrelaxation process. j) TA kinetic traces of Cs2SnI6 and Cs2SnI6/SnS2 at the broad positive absorption (PA) feature (540 nm) upon 375 nm pump excitation. k) Schematic for the charge separation and transfer in Cs2SnI6/SnS2 heterostructure. Reproduced with permission.<sup>[69]</sup> (a–d),<sup>[148]</sup> (e),<sup>[149]</sup> (f–i),<sup>[150]</sup> (j,k). Copyright 2021, Springer Nature; Copyright 2020, 2021 and 2019, American Chemical Society. 

the formation of polarons.<sup>[133,134]</sup> By fitting the early time transients in the optical pump terahertz probe experiments, they were able to access the charge-carrier mobility before and after their localization with a simple two-level model in both Cs2AgBiBr6 and Cu2AgBiI6. A rapid decay in the transient at a cryogenic temperature reveals that the mobility of the initial delocalized state, e.g., in Cs2AgBiBr6, is much higher (≈12 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ) than the final localized state (≈0.5 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ).<sup>[134]</sup> In contrast, the high-temperature transients do not show any rapid decay, indicating the charge-carrier mobility of the localized state (≈1.3 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ) approaching the value of the initial delocalized state (≈3 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ). Indeed, the chargecarrier mobility shows a negative exponent for the initial delocalized state suggesting bandlike transport, while a positive exponent was observed for the localized state, indicating temperature-dependent charge hopping in the localized, selftrapped states (Figure 9i). Interestingly, the localization rate is found to be temperature-indepndent. The values of the chargecarrier mobility at the localized state and the localization rate were further used to estimate the charge-carrier diffusion length 

which was found to be ≈400 nm.<sup>[133]</sup> This value is in good agreement with typical Pb-based perovskites,<sup>[136,137]</sup> suggesting that Cs2AgBiBr6 is promising for optoelectronic applications. 

The other important class of LHPs are ASnX3 systems (both thin films and NCs), which are extremely challenging to obtain in stable form as they suffer from poor stability due to the oxidation of Sn<sup>2+</sup> to Sn<sup>4+</sup> (see Section 6). Yet, there are few reports on the optical properties and charge carrier dynamics in these perovskites that show promising opportunities for optoelectronic applications. For instance, Dai et al. recently performed a systematic work on the size-dependent carrier cooling dynamics of FASnI3 NCs via TA spectroscopy upon excitation at near bandgap (630 nm) as well as above bandgap (400 nm) (Figures 10a, b).<sup>[69]</sup> The TA spectra show two bleaching features, one at the band edge and the other at ≈0.3 eV higher than the band edge, and are consistent with the absorption spectra. The appearance of the higher energy bleach upon band-edge excitation can be ascribed to the depopulation of the ground state only ( **Figure 10** a), as the second excited state is not populated under 

**2307896 (15 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 



### **www.advancedsciencenews.com** 

this condition. A similar result was observed in smaller-size LHP QDs.<sup>[138]</sup> However, upon above bandgap excitation (400 nm), the higher energy bleach evolves much faster than the lower energy bleach (Figure 10b). This has been studied via probing the two bleach transients for different size FASnI3 NCs (Figures 10c, d). For large-size NCs (12 nm), a sub-picosecond buildup of the low-energy bleach corresponding to rapid carrier cooling ( _<_ 1 ps) from higher energy states was observed, and is similar to Pbhalide perovskites.<sup>[125,129,131,139–142]</sup> In contrast, for smaller NCs with strong quantum confinement, an extremely slow evolution (≈15 ps) of the low-energy bleach was observed with a concomitant decay of the high-energy bleach. This indicates the slower carrier cooling from the higher energy state to the lower energy state is due to direct relaxation to the band edge state. This slow carrier cooling was reported to be a unique observation in strongly confined Pb-free perovskites due to phonon bottleneck effect, which is around one to two orders slower than Pb-based perovskites (Table 2). Moreover, this slow cooling is an order of magnitude slower than typical II-VI and IV-VI NCs,<sup>[143–145]</sup> although properly engineered IIVI alloyed or core–shell NCs show comparable (≈8 ps)<sup>[146,147]</sup> or even slower (≈1 ns)<sup>[122]</sup> carrier cooling dynamics. Besides, Narra et al. studied the effect of additives SnF2 and ethylenediammonium diiodide (EDAI2) on the charge carrier dynamics of FASnI3.<sup>[148]</sup> The singular-value decomposition analysis of the TA data reveals a significant reduction of the trap states upon the addition of SnF2 or EDAI2 (Figure 10e). In addition, the shallow- and deep-trap mediated charge recombination proceeds extremely slowly upon the addition of these additives, typically 5–10 times slower as compared to that of pristine FASnI3. 

The spin-relaxation of Sn-perovskites was found to be longer as compared to that of Pb-counterparts, and the trend is similar to their PL lifetimes. For instance, Liang et al. studied the spin-relaxation dynamics of CsSnBr3 NCs in which the spinorbit coupling is much weaker than LHPs.<sup>[149]</sup> This provides an opportunity to have a larger spin-relaxation lifetime and therefore may have a useful application in spintronic. Figure 10f,g shows the transient absorption spectra (640 nm excitation) of CsSnBr3 at co- and counter-circular pump/probe polarization configurations. The bleach signal at the band edge position (640 nm, labeled as B1) is due to the state-filling effect of electron and hole, while the bleach signal at higher energy (520 nm, labeled as B2) is due to the state-filling effect of the hole only. This is because the higher energy transition (causing the appearance of B2) cannot be populated by the pump pulse excitation, which is similar to the earlier discussion on FASnI3[69] and CsPbBr3.[138] Figure 10h compares the B1 transients for co- and counter-circular polarization condition, along with their simultaneous fit that yields a spin-relaxation time of 18 ps. The concerted mechanism of spin-relaxation process via electron–hole exchange is depicted in Figure 10i. The reported spin-relaxation time for CsSnBr3 NCs is the longest at room temperature as compared to that of Pb-halide perovskites (see Table 2). Besides, the charge carrier relaxation in Sn-based perovskites can be modified/controlled by combining them with other materials or vice versa. For example, Wang et al. fabricated a heterojunction consisting of lead-free Cs2SnI6 perovskite NC/SnS2 nanosheet hybrid that leads to pro- 

### **www.afm-journal.de** 



**Figure 11.** a) PLE and absorption spectra of CsMnBr3 NCs with assigned d-d transitions of Mn<sup>2+</sup> , b) TA spectra of CsMnBr3 NCs upon 380 nm pump excitation and c) the corresponding transient kinetics at 580 nm ( _𝜆_ pump = 480 nm). d) Schematic depiction of charge carrier relaxation pathways from excited state to ground state of Mn<sup>2+</sup> . Reproduced with permission.<sup>[151]</sup> (a–d). Copyright 2021, American Chemical Society. 

longed charge separation as compared to a SnS2 nanosheet alone (Figures 10j,k).<sup>[150]</sup> The spatial charge separation boosts the photocatalytic CO2 reduction by a few folds compared to the SnS2 nanosheet. 

Besides Sn, there are some reports demonstrating the replacement of Pb with Mn to obtain CsMnX3 NCs. The charge carrier relaxation properties of these materials were also investigated.<sup>[151–153]</sup> Unlike the Pb and Sn-based perovskite systems, the emission from CsMnX3 stems from the octahedrally coordinated Mn<sup>2+</sup> complex. The optical absorption and PLE spectra of CsMnBr3 NCs show several resonances ( **Figure 11** a), corresponding to the d–d transitions present in the octahedrally coordinated Mn<sup>2+</sup> . The PL decay in this system is strongly dependent on the excitation of a particular d–d transition of the absorption feature. Therefore, pump wavelength-dependent TA spectroscopy was performed to understand the decay dynamics. Figure 11b shows the TA spectra of CsMnBr3 NCs upon 380 nm excitation that shows a monotonous decay within a few ns timescale. The decay trace at 580 nm upon 480 nm pump shows interesting photophysics, where initially a fast decay was observed within 50 ps, followed by a rise of 400 ps (Figure 11c). The delay in populating the low-lying excited state of Mn is about 400 ps before returning to the ground state in another 600 ps (Figure 11c). The proposed charge carrier relaxation mechanism is illustrated in Figure 11d. Interestingly, the 400 ps time constant for populating the low-lying states (i.e., cooling to Mn state) matches well with an earlier report on Mndoped CdTeSe alloyed NCs where 700 ps timescale was observed and attributed to a similar phenomenon.<sup>[154]</sup> In addition, ultrafast charge carrier dynamic studies were also performed 

**2307896 (16 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 12.** a) Optical bandgaps of Sn- and Ge-based perovskites. b) Record efficiencies of representative Sn- and Ge-based perovskite solar cells. c) PCE trend of Sn-based perovskite solar cells.<sup>[189–200,59]</sup> The bandgap and PCE data are obtained from references.<sup>[201–204]</sup> Schematic representation of the energy band diagram of different Sn- and Sn/Ge-based perovskite absorbers in comparison with energy levels of different electrodes, HTMs, ETMs, and back electrodes. d) The data are collected from references<sup>[199,201,205]</sup> and the figure is adapted with permission.<sup>[201]</sup> Copyright 2022, Wiley-VCH. 

on Pb-free non-perovskite materials, e.g., Cs3Bi2I9 single crystal where strong carrier-phonon coupling could lead to polaron formation.<sup>[155,156]</sup> 

## **4. Optoelectronic Devices** 

### **4.1. Solar Cells** 

### _4.1.1. Sn- and Ge-Based Perovskite Solar Cells_ 

_Current Status_ : Halide perovskite solar cells (PSCs) have gained enormous attention in scientific research and the photovoltaics industry, owing to their outstanding optoelectronic properties and low-cost production. For LHPs, a record PCE of 26% for single-junction PSCs has been achieved,<sup>[2]</sup> which is comparable to that of single-junction c-Si solar cells (26.8%).<sup>[182]</sup> Furthermore, the unencapsulated PSC devices maintained ≈90% of their initial efficiency after continuous light exposure for 500 h.<sup>[2]</sup> However, the use of toxic Pb may slow down the pace of 

scale-up for commercialization. As discussed in previous sections, various lower-toxicity compounds have been investigated to replace LHPs, such as Sn/Ge-based halides with perovskite structure, some DPs, and Bi/Sb-based halides with perovskitelike structure.<sup>[183–186,2,52]</sup> Among these candidates, ABX3 (B = Sn, Ge) Pb-free perovskites are the most similar to APbX3 in terms of structure and properties and have theoretical efficiencies exceeding 20% under 1-sun illumination.<sup>[187,188]</sup> 

Among the ABX3 (B = Sn, Ge) perovskites shown in **Figure 12** a, ASnI3 (A = Cs, FA, MA) perovskites have direct bandgaps in the range of 1.2–1.4 eV, which have great potential to achieve a high efficiency close to the Shockley-Queisser (SQ) limit (≈33%). However, the record PCE for Sn-based perovskite solar cells has only reached 14.81%,<sup>[206]</sup> which is far behind the theoretical value as well as the PCEs achieved for LHP solar cells. The main issues are: 1) ASnI3 perovskites suffer from serious oxidation, resulting in high background carrier density and high defect density; 2) they exhibit poor film quality because of their rapid crystallization; 3) non-radiative recombination leads to a 

**2307896 (17 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 





**Figure 13.** Shelf stability and operational stability of representative Sn- and Sn/Ge-based LFP solar cells under different conditions, i.e., encapsulated (color filled), unencapsulated (unfilled), ambient air (blue), N2 (green), MPP and relative humidity (RH). The data are extracted from refs. [201,202,213]. 

low open-circuit voltage and fill factor;<sup>[204]</sup> 4) there is inefficient charge-carrier extraction due to poor energy level alignment with charge transport layers. In order to improve efficiency and stability, various engineering approaches have been applied in the last decade, including composition modification (A-site cations and halides), structure dimension tuning by constructing quasi-2D structure or 2D/3D heterostructure, solvent engineering, interfacial engineering via surface/grain boundary passivation using additives, and device architecture engineering.<sup>[2,202,204,207–210]</sup> 

Generally, Sn-based perovskites are very sensitive to ambient conditions that directly affect the efficiency of PSCs and their long-term stability. Composition engineering is one of the most effective approaches to tailor the optoelectronic properties of Snbased perovskites. The optical bandgap (1.2–3.55 eV), lattice stability, and crystallinity of lead-free perovskites can be tuned by modifying the chemical composition of A- or X-site atoms in accordance with Goldschmidt tolerance factor.<sup>[203,211,212]</sup> FASnI3 PSCs have shown faster progress in efficiency and stability than CsSnI3 and MASnI3 PSCs (Figures 12b,c). On the other hand, AGeI3 perovskites have wider optical bandgaps (1.6–1.9 eV) and are even less stable than ASnI3.<sup>[204]</sup> 

A-site cation engineering has been proven to be an effective way to enhance the efficiency and stability of Sn-based perovskites.<sup>[213]</sup> Some additives, such as Sn halides, reducing agents (Sn powder, hydrazine (N2H4) compounds, and gallic acid) and large organic cations, have also been used to enhance the stability.<sup>[186,214]</sup> It has been found that SnF2 can facilitate the formation of dense and compact films with large grains, and is extensively used as an additive for Sn-based PSCs.<sup>[202]</sup> Large organic cations, like phenethylammonium (PEA), butylammonium (BA), and its derivatives can facilitate the formation of a quasi-2D or 2D/3D heterostructure to minimize the efficiency loss by imped- 

ing degradation from outside to the perovskite grains.<sup>[213]</sup> Especially PEA has been the most popular organic cation to fabricate 2D/3D Sn-based PSCs, because it can induce the perpendicular growth of the perovskite domain. In this regard, He et al.<sup>[215]</sup> achieved the highest PCE of 14.81% for Sn-based PSCs in 2021 by using 4-fluoro-phenethylammonium bromide (FPEABr) as an additive in the perovskite films. Some other organic additives such as ethylenediammonium diiodide (EDAI2), guanidinium (CH6N3+, GA), and azetidinium (AZ) were used to enhance the quality and orientation of 2D/3D perovskite films.<sup>[213,216]</sup> 

Regarding Ge-based perovskites, the most interesting ones are the Ge-Sn alloyed HP, which have better stability and narrower bandgaps than pure Ge-based perovskites. The efficiency of pure Ge-based PSCs is lower than 1%.<sup>[204]</sup> On the other hand, a PCE of 10.43% for FASn0.9Ge0.1I3 PSC<sup>[199]</sup> and a PCE of 13.24% for Ge0.01(FA0.9EA0.1)0.98EDA0.01SnI3 PSCs have been achieved.<sup>[197]</sup> The partial substitution of the formamidinium cation with the ethylammonium (EA) cation results in more stable THP crystals with suppressed trap density. Furthermore, the more favorable energy levels of the EA-substituted Sn-based perovskites enhance the charge extraction into the charge transport layers and thus reduce the charge carrier recombination (Figure 12d).<sup>[197]</sup> 

Stability is still one of the major concerns for Sn-based PSCs. Shelf-life and operational stability of representative Sn- and Sn/Ge-based LFP solar cells under different conditions are summarized in **Figure 13** . Regarding the device architecture of Snbased PSCs, the p-i-n structure has better stability than the n-i-p structure. In the n-i-p structure, some metal oxides acting as electron transport materials (ETMs) can accelerate the oxidation of Sn<sup>2+</sup> , and the energy-level mismatch between the charge transport layer and perovskite limits favorable charge extraction, as shown in Figure 12d. The record PCE of Sn-based PSCs with 

**2307896 (18 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



p-i-n architecture (14.81%) is superior to that with n-i-p architecture (9.06%).<sup>[185]</sup> In the p–i–n architecture, PEDOT:PSS and fullerene derivatives (C60, PCBM, and ICBA) are generally used as hole transport materials (HTMs) and ETMs, respectively. The (PEA, FA)SnI3 PSCs with a high PCE of 12.4%, NH4SCN as an additive, and ICBA as ETM show excellent shelf stability by maintaining 90% of the initial efficiency for over 3800 h.<sup>[193]</sup> The FASnI3 PSCs with a p-i-n device architecture (PCE ≈ 10.61%) remained unchanged upon 5 h in air (60% RH) at maximum-power point (MPP) and 96% of the initial PCE was kept after 1300 h at MPP in N2, by incorporating Dipropylammonium iodide (DipI) together with a well-known reducing agent, sodium borohydride (NaBH4).<sup>[217]</sup> These are the highest reported values of operational stability for Sn-based solar cells. 

_Outstanding Challenges_ : Additives play a key role in affecting the efficiency and stability of Sn-based and Ge-based perovskite solar cells. Although researchers have explored many types of additives, there is a lack of systematic research on the structureproperty-performance relationship, which is necessary to get a better understanding of the underlying mechanisms. To optimize the performance of Sn-based solar cells toward commercialization, complementary characterization techniques to understand the mechanism of additives on crystal structure, defect passivation, and optimizing carrier transport in the perovskites are needed. Further discovery of efficient additives that passivate the surface and prevent the oxidation of Sn<sup>2+</sup> is necessary. The main challenges affecting the stability of the Sn-based PSCs are the oxidation of Sn<sup>2+</sup> and degradation upon exposure to moisture, illumination, and (high) temperature. Nevertheless, precise control over the crystallization of Sn-based thin films and fine interfacial contact between different layers of the devices are essential to achieve high-performance PSCs. In addition, efficient encapsulation strategies are required to enhance the long-term stability of PSCs. 

_Future Prospects_ : Sn-based perovskites are the most promising lead-free ones for lead-free PSC applications despite the record PCE is still far behind that of the Pb-based analogs, which limits its potential commercial deployment. The current optimization of Sn-based thin films and PSCs is mostly done via a trial-and-error experimental approach, which is very timeconsuming and inefficient. Combining high-throughput computation and machine learning to accelerate the discovery of various functional additives, Sn-based absorbers, and charge transport materials for potential solar cell applications is one desirable direction. Developing in-situ characterization techniques to observe microstructures, and investigate crystallization dynamic, defects, and charge transport properties is highly demanded. It is also of great interest to develop highly efficient and stable Snbased PSCs with novel functions like semitransparent and flexible devices to integrate with buildings, wearable electronics, and the Internet of Things. 

### _4.1.2. Double Perovskite-Based Solar Cells_ 

Double perovskites (DPs), with the general formula A2B<sup>I</sup> B<sup>III</sup> X6 or A2B<sup>IV</sup> X6 (vacancy-ordered), have emerged as promising alternatives to LHPs owing to their higher stability over Sn- and Ge-based perovskites.<sup>[17,218–223,52]</sup> DPs have been preferred for 

solar cells due to their three-dimensional crystal structure and long carrier lifetimes (≈660 ns).<sup>[224]</sup> DPs consist of A-site monovalent cations (Cs<sup>+</sup> or MA<sup>+</sup> ), B<sup>I</sup> -site monovalent metal cations (e.g., Li, Na, Ag, or Au), B<sup>III</sup> -site trivalent metal cations (e.g., Bi, Sb, In, Fe, Tl, or Au), and halide anions ( **Figure 14** ). As discussed in the previous sections, the combinations of different A, B<sup>I</sup> , B<sup>III</sup> , and X<sup>−</sup> ions results in a library of a large number of DPs with tunability over bandgap and stability. Among all, Bibased DPs, especially Cs2AgBiX6 (X = Br or Cl), have been significantly exploited because Bi<sup>3+</sup> possesses the 6s<sup>2</sup> 6p<sup>0</sup> electronic configuration similar to Pb<sup>2+</sup> .<sup>[224–228]</sup> In 2016, Slavney et al. reported the synthesis of Cs2AgBiBr6 with an indirect bandgap of 1.95 eV, a long PL lifetime of ca. 660 ns, and significant stability against light and humidity.<sup>[224]</sup> More in-depth discussion on the optical and electronic structure of DPs is found in the previous sections. Since 2016, Cs2AgBiBr6 has been greatly investigated for solar cells because its properties are considered promising for photovoltaics. The other Bi-based DPs explored for solar cells are Cs2LiBiCl6 (2.597-3.15 eV),<sup>[229]</sup> Cs2NaBiCl6 (2.9-3.72 eV),<sup>[230]</sup> Cs2NaBiI6 (1.66 eV),<sup>[231]</sup> (CH3NH3)2AgBiBr6 (2.02 eV),<sup>[232]</sup> and (CH3NH3)2TlBiBr6 (2.06 eV).<sup>[233]</sup> Sb-based DPs such as Cs2SbBiX6 (X = Cl<sup>[234,235]</sup> or Br<sup>[228,236]</sup> ) have also been investigated and it was found that the indirect band gaps are contributed by Sb-5s/Ag-4d (valence band maximum) and Sb-5p orbitals (conduction band minimum).<sup>[236]</sup> However, the reported PCEs of these materials are far behind those of LHPs, suggesting that they are relatively less promising for solar cells because of their indirect bandgap and worse absorption of the solar spectrum. 

In addition, In-,<sup>[237–240]</sup> Fe-,<sup>[241,242]</sup> Tl-,<sup>[243]</sup> and Au-based direct bandgap DPs<sup>[244–247]</sup> have been synthesized, and they have lower band gaps than the Bi and Sb- based DPs. However, there are very few reports on the exploration of these DP systems for solar cells. On the other hand, vacancy-ordered DPs (A2B<sup>IV</sup> X6) have been promising candidates for solar cells, and they exhibit an antifluorite crystal structure with isolated BX6 octahedra bridged by A-site cations.<sup>[254]</sup> Among all, Cs2SnI6 is one of the most investigated vacancy-ordered DPs for solar cells. Cs2SnI6 is stable in air as it results from the degradation and reconstruction of CsSnI3 through the reaction CsSnI3 → CsI + SnI2 → CsI + SnI4 → Cs2SnI6.<sup>[255]</sup> Dye-sensitized solar cells fabricated using Cs2SnI6 as a hole transport layer (HTL) have recorded a PCE of 7.8%.<sup>[256]</sup> This has motivated the community to explore vacancy-ordered DPs such as Cs2SnI6[248–252] and Cs2TiBr6[253] as active layers. Figure 14 summarizes the bandgap values of different DPs synthesized experimentally. It is noted that the broad distribution of bandgaps for DPs is due to the differences in size, synthesis methods, and calculation models. Despite the existence of many DPs with suitable direct bandgaps for solar cells, Cs2AgBiBr6 has been the most promising and exploited system to date. 

The device architecture of DP-based solar cells generally consists of substrate/transparent electrode/ ETL/DP/HTL/electrode. A tin-doped indium oxide (ITO) or fluorine-doped tin oxide (FTO) film coated on glass is used as the transparent electrode (cathode). The typical ETL materials are compacted TiO2 (c-TiO2), mesoporous TiO2 (m-TiO2), or SnO2. The HTL materials are 2,2,’7,7′-tetrakis-( _N,N_ -di-4-methoxyphenylamino)−9,9′-spirobifuorene (spiro-OMeTAD), poly(3-hexylthiophene) (P3HT), and poly[bis(4-phenyl)(2,4,6-trimethylphenyl)-amine] (PTAA). The 

**2307896 (19 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 14.** Bandgap values of DPs and vacancy-ordered DPs (orange). The values are obtained from refs. [229,231,224–233,235–251]. 

typical anode layers are Au, Ag, or Cu. Although various DPs have been predicted and synthesized, Cs2AgBiBr6-based solar cells have been the most investigated ones. Although the synthesis of Cs2AgBiBr6-bulk crystals was already reported in 2016,<sup>[224]</sup> the solubility of Cs2AgBiBr6 is too low in standard solvents to prepare the film for solar cells. Bein et al. first reported Cs2AgBiBr6-based solar cells in 2017.<sup>[257]</sup> They applied dimethyl sulfoxide as the solvent for spin-coating ( **Figure 15** a). Then, the sample was heated twice during film preparation for preheating and annealing. Figure 15b,c shows the PCE as a function of preheating and annealing temperatures, respectively. Preheating a precursor solution at a suitable temperature (75 °C) improves the film quality and surface coverage. Annealing the coated film at a higher temperature than 250 °C is required for the formation of phase-pure Cs2AgBiBr6. Thus, the first Cs2AgBiBr6-based solar cell exhibited a PCE of 2.43% with _V_ OC of 0.98 V, _J_ OC of 3.93 mA cm<sup>−2</sup> , and FF of 69% (Figure 15d), 

and showed significant stability under ambient conditions for 25 days. After Bein’s report, various Cs2AgBiBr6 film deposition methods have been proposed, such as low-pressure-assisted spin-coating (PCE of 1.32%),<sup>[258]</sup> sequential evaporation (PCE of 1.03%),<sup>[259]</sup> sequential vapor deposition (PCE of 1.52%),<sup>[260]</sup> precursor engineering using an additive (PCE of 0.73%),<sup>[261]</sup> and spray coating (PCE of 2.3%).<sup>[262]</sup> The reason for the use of different methods is to optimize the quality of DP films in terms of crystallinity, grain size, thickness, phase purity, and crystal orientation to improve the PCE of solar cells. However, the PCE of DPs is significantly lower than that of LHPs. 

Inverted planar heterojunction solar cells were also fabricated, but their PCEs were even lower (2.23%).<sup>[263]</sup> Since 2020, the PCE performance of Cs2AgBiBr6-based solar cells has been effectively improved by bandgap modifications through photosensitizing dyes or MXenes.<sup>[264–267]</sup> For instance, Yang 



**Figure 15.** a) A scheme of the Cs2AgBiBr6 film preparation. b,c) PCE values as a function of b) the preheating temperature (annealed at 250 °C) and c) the annealing temperature (preheated at 75 °C). d) _J_ – _V_ curve of the champion device. Reproduced with permission.<sup>[257]</sup> Copyright 2017, Royal Society of Chemistry. 

**2307896 (20 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.afm-journal.de** 



**Figure 16.** a–c) A cross-section SEM image, b,e,k,n) energy levels, and c,f,l,o) _J_ – _V_ curves of Cs2AgBiBr6-based solar cells. d–f) Absorption spectra of Cs2AgBiBr6 coated on TiO2 and D102, D131, and D149-sensitized TiO2 and molecular structures of the dyes, energy levels, and c,f,l,o) _J_ – _V_ curves of corresponding solar cells. g,h) SEM images and i,j) grain size distributions of Cs2AgBiBr6 film surface without and with Ti3C2Tx. m) Absorption spectra of pristine and hydrogenated Cs2AgBiBr6 film. a–c) Reproduced with permission.<sup>[264]</sup> Copyright 2020, Wiley-VCH; d–f) Reproduced with permission.<sup>[265]</sup> Copyright 2021, American Chemical Society; g–l) Reproduced with permission.<sup>[266]</sup> Copyright 2022, Elsevier B.V.; m–o) Reproduced with permission.<sup>[267]</sup> Copyright 2022, Springer Nature. 

et al. reported Cs2AgBiBr6-based solar cells with N719 (ditetrabutylammonium cis-bis(isothiocyanato) bis (2,2′-bipyridyl4,4′ dicarboxylato)ruthenium (II)) dye interlayer (Figures 16ac).<sup>[264]</sup> The N719 dye broadens the absorption spectrum, suppresses the charge carrier recombination, and accelerates the hole extraction while passivating surface defects. Therefore, the PCE performance is improved by up to 2.84%. Wang et al. introduced indoline dyes into the solar cell to sensitize the TiO2 ETL.<sup>[265]</sup> They compared three types of dyes, D102, D131, 

and D149, which exhibit strong absorbance beyond 500 nm ( **Figure 16** d) and help to crystallize the DP film. They proposed two mechanisms of hole transport from the dyes to spiro-OMeTAD: carrier recombination of the holes generated in the dyes and the electrons generated in the DP and hole transport via the DPs sub-bandgap states (Figure 16e). The D149 dye-based Cs2AgBiBr6 solar cell recorded an improved PCE of 4.23% due to the broadened and enhanced optical absorbance (Figure 16f). The PCE was further improved to 4.47% 

**2307896 (21 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 17.** a) PCE trend and b) champion PCE values of DP-based solar cells. The arrows show the trends in the field. c) A graphical presentation of the current-voltage-efficiency relationships for DP solar cells. 

by introducing D149 dye and Ti3C2Tx MXene nanosheets into the Cs2AgBiBr6-based solar cell.<sup>[266]</sup> Here, the Ti3C2Tx controls the grain size of the Cs2AgBiBr6. Figure 16g–j compares the grain sizes of Cs2AgBiBr6 without and with Ti3C2Tx. The mean size of the grain is increased from 326 to 440 nm by doping Ti3C2Tx. Improved crystallinity of the DP resulted in enhanced electron extraction, reducing defect density, and suppressing carrier recombination. Ti3C2Tx does not modify the energy levels of the solar cell (Figure 16k). First-principles calculations suggest that the high work function of Ti3C2Tx improves the carrier mobility of Cs2AgBiBr6 by adjusting its valence band. Both the D149 dye and Ti3C2Tx contribute to the photocurrent in the Cs2AgBiBr6based solar cell (Figure 16l). Recently, Zhang et al. achieved 6.37% PCE in Cs2AgBiBr6-based solar cells using a hydrogenation method. Doping atomic hydrogen into the interstitial sites of the Cs2AgBiBr6 lattice modified the bandgap from 2.18 to 1.64 eV (Figures 16m-o).<sup>[267]</sup> The resulting solar cells showed excellent photo- and thermo-stabilities in a nitrogen environment for 1440 h. 

In addition, bandgap engineering of DPs has been carried out to improve the PCE of solar cells. The bandgap of Cs2AgBiBr6 (≈2 eV) is larger than the ideal band gap (1.34 eV for 33.7%) for a single-junction solar cell.<sup>[268]</sup> Interestingly, hetero-atom doping into Cs2AgBiBr6,<sup>[269,270]</sup> other DPs,<sup>[231,247]</sup> and vacancy-ordered DPs<sup>[248–253]</sup> help to lower the bandgap. For example, the bandgap of Cs2AgBiBr6 was decreased by partial substitution of Bi<sup>3+</sup> with Sb<sup>3+</sup> .<sup>[269]</sup> As a result, the bandgap of Cs2AgSb _x_ Bi1- _x_ Br6 could be decreased from 2.22 eV ( _x_ = 0) to 1.97 eV ( _x_ = 0.75). Although the PCE of Cs2AgSb _x_ Bi1- _x_ Br6 solar cells has been improved from 0.2% to 0.25% by increasing the Sb<sup>3+</sup> :Bi<sup>3+</sup> ratio up to 1:3, it was decreased to 0.075% with a further in- 

crease in the Sb<sup>3+</sup> :Bi<sup>3+</sup> ratio to 1:1 due to formation of large pinholes, and possibly also the formation of defect states. Although Kumar et al. prepared smooth, compact, and pinholefree Cs2AgBi0.6Sb0.4Br6 NC films, the PCE value of the corresponding solar cell was only 0.09%.<sup>[270]</sup> Zhang et al. designed Cs2NaBiI6 as a narrow bandgap DP (1.66 eV) for solar cells,<sup>[231]</sup> and it showed excellent stability (five months in relative humidity of 70%). Ghosh et al. synthesized MA2Au2X6 (X = Br, I) with a narrow bandgap of ≈1.0 eV.<sup>[247]</sup> However, the PCE of these DP-based solar cells was below 1%. Vacancy-ordered DPs have also been considered and exploited for solar cells. Especially, Cs2SnI6 has attracted attention due to its narrow bandgap (1.2– 1.6 eV), interesting optoelectronic properties, and air stability. Since the 2016′s first report on Cs2SnI6-based solar cells,<sup>[248]</sup> optimization of the films in terms of thickness,<sup>[249]</sup> powder synthesis method,<sup>[250]</sup> halide mixing,<sup>[251]</sup> and A-site alloying<sup>[252]</sup> have been proposed for improving the photovoltaic performance. Although the PCE of solar cells from modified Cs2SnI6 samples was higher than unmodified ones, the overall efficiency remains low ( _<_ 2%), leaving space for further research. In contrast, Chen et al. prepared Cs2TiBr6 films with a band gap of 1.8 eV using a low- temperature vapor-based method,<sup>[253]</sup> which helped improve the PCE to 2.15% without C60 and 3.22% with C60, which is only comparable to Cs2AgBiBr6-based solar cells. 

Despite the relatively low PCE, DP-based solar cells overcome the concerns of LHP solar cells, such as lead toxicity and instability in the air. Figure 17a,b summarizes the trend and champion data of DP-based solar cells. The corresponding currentvoltage characteristics are presented in **Figure 17** c, showing the significance of improving the JSC values of DP solar cells. The 

**2307896 (22 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



**Table 3.** Device configuration and photovoltaic parameter of DP solar cells. 

|Device configuration|DP film deposition method|_V_oc [V]|_J_sc [mA cm<sup>−2</sup>]|FF [%]|PCE [%]|Reference|
|---|---|---|---|---|---|---|
|FTO/dense TiO2/m–TiO2/Cs2AgBiBr6/spiro-OMeTAD/Au|One-step spin coating|0.98|3.93|63|2.43|[257]|
|FTO/c-TiO2/Cs2AgBiBr6/PTAA/Au|One-step spin coating|1.02|1.84|67|1.26|[273]|
|ITO/SnO2/Cs2AgBiBr6/P3HT/Au|Low pressure assisted spin coating and annealing|1.07|1.78|69|1.32|[258]|
|ITO/Cu-NiO/Cs2AgBiBr6/C60/BCP/Ag_<_Inverted_>_|Anti-solvent assisted spin coating and annealing|1.01|3.19|69.2|2.23|[263]|
|FTO/TiO2/ Cs2AgBiBr6/spiro-OMeTAD/MoO3/Ag|One-step spin coating|1.01|3.82|65|2.51|[274]|
|ITO/SnO2/Cs2AgBiBr6/P3HT/MoO3/PTAA/Au|One-step spin coating|1.06|2.80|65|1.94|[275]|
|ITO/SnO2/Cs2AgBiBr6/Spiro-OMeTAD/Au|Sequential evaporation|1.10|1.33|70|1.03|[259]|
|FTO/c-TiO2/Cs2AgBiBr6/P3HT/Cu|One-step spin coating|1.07|2.58|69|1.91|[276]|
|FTO/c-TiO2/m-TiO2/Cs2AgBiBr6/N719/spiro-OMeTAD/Ag|One-step spin coating|1.06|5.13|52.4|2.84|[264]|
|FTO/SnO2/Cs2AgBiBr6/Cu2O/Au|Sequential vapor deposition|1.198|1.72|73.8|1.52|[260]|
|ITO/SnO2/Cs2AgBiBr6/Spiro-OMeTAD/Ag|Precursor engineering using BiBr3(DMSO)2, spin<br>coating and annealing|0.87|1.36|61|0.73|[261]|
|FTO/Ti3C2Tx-TiO2/Cs2AgBiBr6/Spiro-OMeTAD/MoO3/Ag|One-step spin coating|0.96|4.14|70|2.81|[180]|
|FTO/c-TiO2/m-TiO2/C-ChI/Cs2AgBiBr6/Spiro-OMeTAD/Ag|One-step spin coating|1.04|4.09|73.12|3.11|[277]|
|FTO/Cs2AgBiBr6-D149-TiO2/Cs2AgBiBr6/Spiro-OMeTAD/Ag|One-step spin coating|0.73|8.24|70.32|4.23|[265]|
|FTO/c-TiO2/m-TiO2/Cs2AgBiBr6/Spiro-OMeTAD/Au|Spray coating|1.091|3.1|70|2.3|[262]|
|FTO/c-TiO2/m-TiO2/D149-Cs2AgBiBr6@Ti3C2Tx/Ag|One-step spin coating|0.722|8.85|70.1|4.47|[266]|
|FTO/TiO2/ Cs2AgBiBr6/Y6/PBDB-T/MoOx/Ag|One-step spin coating with antisolvent|1.278|3.34|77.5|3.31|[278]|
|FTO/TiO2/BMPyr/Cs2AgBiBr6/carbon|One-step spin coating|1.20|2.61|71.02|2.22|[279]|
|FTO/c-TiO2/m-|One-step spin coating|1.07|3.5|66|2.47|[220]|
|TiO2/Cs2AgBiBr6(3D)/(PEA)4AgBiBr8(2D)/Spiro-<br>OMeTAD/Au|||||||
|ITO/c-TiO2/m-TiO2/Cs2AgBiBr6/Spiro-OMeTAD/Au|One-step spin coating|1.05|1.77|71.67|1.33|[280]|
|ITO/SnO2/ Cs2AgBiBr6/Spiro-OMeTAD/Au|One-step spin coating with antisolvent|0.92|11.40|60.93|6.37|[267]|
|FTO/TiO2/Cs2AgBiBr6/PMMA/carbon|One-step spin coating<br>Other than Cs2AgBiBr6|1.18|2.82|67.6|2.25|[281]|
|FTO/c-TiO2/m-TiO2/Cs2AgSb0.25Bi0.75Br6/Spiro-OMeTAD/Au|One-step spin coating|0.64|1.03|–|0.25|[269]|
|ITO/NiOx/Cs2AgBi0.6Sb0.4Br6/PCBM/Ag|One-step spin coating|0.275|1.07|31|0.09|[270]|
|FTO/c-TiO2/m-TiO2/Cs2NaBiI6/Spiro-OMeTAD/Au|One-step spin coating|0.47|1.99|44|0.42|[231]|
|FTO/m-TiO2/MA2AuBr6/PTAA/Au|Reactive polyiodide melt|0.33|0.052|41.04|0.007|[247]|
|FTO/ZnO seed layer/ZnO nanowires/Cs2SnI6/P3HT/Ag|One-step spin coating|0.52|3.2|51.5|0.857|[248]|
|FTO/TiO2/Cs2SnI6/P3HT/Ag|Two-step vapor deposition|0.51|5.41|35|0.96|[249]|
|FTO/c-TiO2/Cs2SnI6/P3HT/Ag|Chemical bath deposition|0.256|7.41|24.5|0.47|[250]|
|FTO/TiO2/Sn-TiO2/Cs2SnI4Br2/solid-state Cs2SnI6/LPAH<br>/FTO|Two-step solution process|0.563|6.225|57.7|2.025|[251]|
|FTO/TiO2/Sn-TiO2/Cs2SnI6/LPAH/FTO|Two-step solution process|0.367|6.752|59.5|1.47|[251]|
|ITO/CuI/Ag-alloyed Cs2SnI6/PCBM/AZO/Ag|Spray coating|0.378|3.821|45.6|0.659|[252]|
|FTO/TiO2/C60/Cs2TiBr6/P3HT/Au|Two-step vapor deposition|1.02|5.69|56.4|3.28|[253]|



current and voltage values are summarized in **Table 3** . Among all, Cs2AgBiBr6-based solar cells recorded higher PCE values than that of other DPs. The PCE values have been improved from 2.43% in 2017 to 6.37% in 2022. The DP-based solar cell with the champion PCE value exhibits excellent photo- and thermostabilities in a nitrogen environment for two months. However, the efficiencies of reported DP-based solar cells are still lower than those of LHP solar cells. The main issues of DP-based solar cells are the large band gaps, technical challenges with device engineering, and the large gap between experimental and simulated PCE values. Among various DP samples, Cs2AgBiBr6 is not ideal for industrial solar cells mainly due to its large and 

indirect bandgaps.<sup>[271]</sup> Other chemical compositions, vacancyordered DPs, and hetero-atom doping have been tried to overcome the bandgap issue. There is still a large room for improving perovskite layer quality, for example, by adopting inverted or multijunction solar cells or by integrating with other absorbers. Furthermore, machine learning could help to find suitable DP for efficient solar cells.<sup>[272]</sup> Although various high-efficiency DP solar cells are predicted by density functional theory and first principle calculations, most of them are still unexplored experimentally. The gap between the theoretical and experimentally demonstrated PCE values needs to be filled by further collaboration between experimental and theoretical groups. 

**2307896 (23 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



**Table 4.** The performance of electroluminescent LEDs fabricated based on Sn perovskites. _𝜈_ EL, FWHM, EQE, _L_ max, and _R_ max refer to the photon energy of electroluminescence (EL) peak, full-width of half-maximum, external quantum efficiency, the maximum luminescence (in cd m<sup>−2</sup> ), and the maximum radiance (in W sr<sup>−1</sup> m<sup>−2</sup> ), respectively. 

|Composition|Device structure (PK refers to Sn-based<br>perovskites)|_𝜈_EL [eV]|FWHM [eV]|EQE [%]|_L_max<br>[cd m<sup>−2</sup>] or_R_max<br>[W sr<sup>−1 </sup>m<sup>−2</sup>]|Reference|
|---|---|---|---|---|---|---|
|MASn(Br_x_I1-_x_)3 thin film|ITO/PEDOT:PSS/PK/F8/Ca/Ag|1.3-1.86|≈0.2|0.007-0.72|0.087 – 1.8<br>W sr<sup>−1 </sup>m<sup>−2</sup>|[283]|
|FASnI3 thin film|ITO/PEDOT:PSS/PK/TPBi/LiF/Al|1.38|≈0.15|1.5|145<br>W sr<sup>−1 </sup>m<sup>−2</sup>|[285]|
|CsSnI3<br>thin film|ITO/PEDOT:PSS/PK/PBD/LiF/Al|1.31|≈0.2|3.8|40<br>W sr<sup>−1 </sup>m<sup>−2</sup>|[284]|
|CsSnI3<br>thin film|ITO/PEDOT:PSS/PK/B3PYMPM/LiF/Al|1.3|≈0.15|5.4|162<br>W sr<sup>−1 </sup>m<sup>−2</sup>|[319]|
|CsSnI3<br>NCs|ITO/PEDOT:PSS/PK/LiF/Al|1.31|≈0.15|0.007|0.05<br>W sr<sup>−1 </sup>m<sup>−2</sup>|[324]|
|CsSnBr3<br>thin film|FTO/PFI+PEDOT:PSS/PK/TPBI/LiF/Al|1.84|≈0.29|N/A|160 cd m<sup>−2</sup>|[316]|
|CsSn(Br_x_I1-_x_)3<br>Thin films|ITO/PEDOT:PSS/PK/PBD/LiF/Al|1.83-1.31|≈0.15|0.002-0.013|0.01 – 0.13<br>W sr<sup>−1 </sup>m<sup>−2</sup>|[315]|
|PEA2SnI4<br>thin film|ITO/PEDOT:PSS/PK/F8/LiF/Al|2.01|0.12|N/A|0.15 cd m<sup>−2</sup>|[58]|
|PEA2SnI4<br>thin film|ITO/PEDOT:PSS/PK/TPBi/LiF/Al|1.96|0.07|0.3|70 cd m<sup>−2</sup>|[317]|
|PEA2SnI4<br>thin film|ITO/TPBi/LiF/PK/TPBi/LiF/Al|1.97|0.09|0.16|58 cd m<sup>−2</sup>|[57]|
|TEA2SnI4<br>thin film|ITO/TPBi/LiF/PK/TPBi/LiF/Al|1.94|0.09|0.62|322 cd m<sup>−2</sup>|[57]|
|PEA2SnI4<br>thin film|ITO/PEDOT:PSS/PK/TPBi/LiF/Al|1.97|0.09|0.52|355 cd m<sup>−2</sup>|[299]|
|(OAm)2SnBr4<br>microplates|ITO/PEI-ZnO/PK/TCTA/<br>MoO3/Au|1.98|0.52|0.1|350 cd m<sup>−2</sup>|[300]|



### **4.2. Light-Emitting Diodes (LEDs)** 

### _4.2.1. Sn and Ge-based Perovskite LEDs_ 

_Current Status_ : Apart from photovoltaics, Sn/Ge-based perovskites have also been employed as light emitters, either in the form of thin films or colloidal NCs ( **Tables 4** and **5** ).<sup>[2,282,54]</sup> In this part of the review, we will first discuss the emission properties of several Sn and Ge-based perovskites, followed by a discussion of the current progress of LED performance based on these. Because several low-dimensional perovskites have recently drawn more attention in the field of light emission, we will focus the discussion in the first section on materials with different dimensionalities. In the second section, we will separately discuss electroluminescence LEDs (EL LEDs) and phosphor-converted LEDs (PC LEDs), which are the two common LEDs reported thus far. 

3D MASnI3, FASnI3, and CsSnI3 films have been heavily investigated since their direct bandgaps, between 1.3 to 1.4 eV, could lead to intense PL emissions with minimal Stokes shifts.<sup>[283–285]</sup> On the other hand, some of these Sn-based perovskites have been synthesized as NCs, where the stronger quantum confinement tends to widen bandgaps and create more discrete energy levels. As a result, Sn-based perovskite NCs have 

PL peaks with narrower full width at half maxima (FWHM), which is advantageous for achieving higher color saturation and important for ultrahigh-definition displays. Indeed, both CsSnI3 and FASnI3 NCs showed a 0.1 eV blueshift in their bandgaps with a PL FWHM between 70 and 100 meV,<sup>[54,67,286]</sup> which was smaller than their thin film counterparts. Additionally, by changing the A-site or halide site component ( **Figure 18** a), the PL position of Sn-based perovskites can be tuned over a wide range, from visible to NIR (2.95–1.3 eV).<sup>[283,287,288]</sup> Figure 18b displays the energy levels and bandgaps of several Sn-based perovskites with different compositions, where we can see a wide tuneable range of bandgaps from 3.55 to 1.24 eV.<sup>[203]</sup> However, in contrast to LHP NCs with extremely high PLQYs, the highest PLQY reported for Sn-based perovskite NCs (CsSnI3 NCs) so far is only 18.4%,<sup>[55]</sup> which is far below the PLQYs of LHP NCs (approaching 100%).<sup>[29,289]</sup> On the other hand, 3D Ge-based perovskites have slightly larger bandgaps than Sn-based perovskites. For example, MAGeI3, FAGeI3, and CsGeI3 thin films have shown a direct bandgap of around 1.6, 1.9, and 2.2 eV, respectively.<sup>[198]</sup> Similar to Sn-based perovskites, alloying of A-site cations and halide ions could also tune the bandgaps of Ge-based perovskites, which were limited from the UV to the visible region (1.6– 3.67 eV).<sup>[290,291]</sup> Although MA1- _x_ FA _x_ GeI3 thin films have exhibited tuneable PL from 1.97 to 2.25 eV,<sup>[292]</sup> very few studies on the 

**2307896 (24 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



**Table 5.** Phosphor-converted LEDs fabricated based on Sn perovskites. CCT, CIE, and CRI refers to correlated color temperature, color coordinates in the CIE 1931 graph, and color rendering index, respectively. 

|Composition|Device structure (PK refers to Sn-based<br>perovskites)|CCT [K]|CIE|CRI|Reference|
|---|---|---|---|---|---|
|Cs2SnBr6<br>NCs|Cs2SnBr6 +(Sr5(PO4)3Cl:Eu<sup>2+</sup>)/<br>(mixed in PDMS)/<br>365 nm chip|2006|(0.52, 0.41)|84|[318]|
|(C4N2H14Br)4SnBr6<br>single crystals|(C4N2H14Br)4SnBr6 +BaMgAl10O17:Eu<sup>2+</sup><br>(mixed in PDMS)/<br>340 nm chip|4946|(0.35, 0.39)|70|[308]|
|(OCTAm)2SnBr4<br>crystals|(OCTAm)SnBr4 +<br>BaMgAl10O17:Eu<sup>2+ </sup>+G2762<br>(mixed in PS)/<br>365 nm chip|2500/<br>5635/<br>6530|(0.49, 0.42)/<br>(0.33, 0.26)/<br>(0.33, 0.31)|69/<br>81/<br>89|[75]|
|Cs2SnCl6:0.59% Sb<sup>3+</sup><br>crystals|Cs2SnCl6:0.59% Sb<sup>3+ </sup>+Cs2SnCl6:2.75% Bi<sup>3+ </sup>+<br>6815 Ba2Sr2SiO4:Eu<sup>2+</sup><br>(mixed in silicone)/<br>380 nm chip|6815|(0.30, 0.37)|81|[311]|
|Cs2SnCl6:2.75% Bi<sup>3+</sup><br>crystals|Cs2SnCl6:2.75% Bi<sup>3+ </sup>+Ba2Sr2SiO4:Eu<sup>2+ </sup>+<br>GaAlSiN3:Eu<sup>2+</sup><br>(mixed in curable resin)/<br>365 nm chip|2087/<br>4486|(0.55,0.45)/<br>(0.36, 0.37)|N/A|[312]|





**Figure 18.** a) PL spectra of 3D CsSnX3 (X = Cl, Br, I) thin films with different halide compositions. Reproduced with permission.<sup>[288]</sup> Coypright 2016, Royal Society of Chemistry. b) Schematic illustration of energy levels of ABX3 perovskites with different A (MA, FA, and Cs), B (Sn and Pb), and X (Cl, Br, and I). The bandgaps are obtained from the UV−vis absorption measurements, whereas the ionization energy (IE) and electron affinity (EA) are obtained from the inverse photoelectron spectroscopy. Reprinted with permission.<sup>[203]</sup> Copyright 2019, Springer Nature. c) Configuration coordinate diagram depicting two possible emission mechanisms of Sn- and Ge-based perovskites. GS, FE, and STE represent the ground state, free exciton, and self-trapped exciton, respectively. 3D perovskites usually exhibit FE emission while low-dimensional perovskites tend to show STE emission, d) UV– vis absorption (UV), PL excitation (EX) and emission (PL) spectra of 2D (OCTAm)2SnBr4 colloidal solution. The inset shows the photographs of the samples in solution and powder form. Reproduced under the terms of the CC BY-NC license.<sup>[75]</sup> Copyright 2019, The Authors, published by Royal Society of Chemistry. 

**2307896 (25 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 19.** Schematic illustration of the preparation of 2D Sn-based perovskite films for LEDs (TEA: 2-thiopheneethyllammonium). (b) The electroluminescence (EL) spectra of TEA2SnI4-based device at different voltages. Figures (a) and (b) are reproduced with permission.<sup>[57]</sup> Copyright 2020, American Chemical Society. (c) Inkjet printing of PEA2SnI4 films for LEDs fabrication. (d) LED device structure made of inkjet-printed PEA2SnI4 films. (e) EQE versus current density for the PEA2SnI4 LEDs fabricated on glass and polyimide (PI) flexible substrates (inset: photograph of a red-emitting flexible LED operating at 5 V). Panels (c)–(e) are reproduced with permission.<sup>[303]</sup> Copyright 2022, American Chemical Society. 

emission properties of other 3D Ge-based perovskites have been reported thus far. 

Compared to their 3D counterparts, 2D Sn- and Ge-based perovskites usually have larger bandgaps (≈2 eV or above), larger exciton binding energies (hundreds of meV,<sup>[293]</sup> c.f., 20–30 meV for 3D counterparts<sup>[294]</sup> ), and higher environmental stability due to the presence of long-chain organic layers acting as barriers to moisture ingress.<sup>[295]</sup> Interestingly, two different emission mechanisms have been identified in 2D Sn- and Ge-based perovskites and can be interpreted by a configuration coordinate diagram, as illustrated in Figure 18c.<sup>[296,93]</sup> The curves in a configuration coordinate diagram describe the total energy of the lattice in the dark or under illumination at different lattice distortions, which is represented by the configuration coordinate. Following photoexcitation, the lattice changes from the ground state to the free exciton state. Afterward, excitons can relax directly from the free exciton to the ground state without lattice distortion (path 1 in Figure 18c), and this would normally lead to a narrow PL with minimal Stokes shifts.<sup>[297,93]</sup> On the other hand, if the coupling between the excitons (or free charge-carriers) with phonons is strong enough, lattice distortion occurs, and the free exciton can enter into the STE state, leading to the localization of the exciton wavefunction, with a radial distance on the order of a unit cell or smaller. A broadband white light emission with a large Stokes shift often occurs when STEs relax to the GS (path 2 in Figure 18c).<sup>[298,93]</sup> Such a phenomenon is undesirable for ultrahigh definition displays but offers opportunities to achieve solidstate white light emitters. 

The emission of 2D Sn-based perovskites is highly associated with the types of A-site organic cations used, which could lead to either extremely narrow PL (free exciton emission) or broadband white light (STE emission). In terms of free exciton emission, (PEA)2SnI4 (PEA = phenylethylammonium) films have demon- 

strated a PL at 2 eV with a small FWHM of 100 meV and Stokes shift of 40 meV.<sup>[299]</sup> A PLQY of 9.7% was reached in (PEA)2SnI4 films after surface passivation. In the STE emission case, the (OCTAm)2SnBr4 (OCTAm = octylammonium) colloidal solution has shown a PL at 2.07 eV with a large FWHM and Stokes shift of 470 meV and 1010 meV, respectively (Figure 18d).<sup>[75]</sup> A nearunity PLQY and microsecond PL lifetime were also observed in both (OCTAm)2SnBr4 and (OAm)2SnBr4 (OCT = octylammonium; OAm = oleylammonium),<sup>[300,75]</sup> suggesting that photoexcited charge-carriers could relax more efficiently through STE relaxation. Furthermore, the high PLQY could be maintained in 2D Sn-based perovskites stored in an ambient environment for up to 240 days, which verifies their high air stability.<sup>[75]</sup> The PL peaks of 2D Sn-based perovskites could be also tuned by using various halide compositions or A-site organic cations with different chain lengths.<sup>[301,75]</sup> On the other hand, 2D Ge-based perovskites show poorer emission properties compared to Sn-based counterparts. For instance, although the (Bmpip)2GeBr4 (Bmpip = 1-butyl-1-methylpiperidinium) single crystal has displayed a broadband STE emission at 1.85 eV with a large Stokes shift up to 600 meV, its PLQY was found to be less than 1%.<sup>[302]</sup> LEDs made of 2D Sn-based perovskites are often solution-processed by using solutions containing tin halides and organic cation molecules, as illustrated in **Figure 19** a.<sup>[57]</sup> Among various organic cations, PEA and TEA (thiopheneethyllammonium) molecules have been extensively explored to prepare relatively stable 2D Sn-based perovskites with a reasonable PLQY for LEDs. Particularly, TEA2SnI4-based LEDs exhibit electroluminescence (EL) spectra peaking at ≈1.94 eV (638 nm), and an EQE of 0.62% (Figure 19b).<sup>[57]</sup> EL spectra of 2D Sn-based perovskites slightly vary depending on the composed organic cations and are generally consistent with corresponding PL spectra. In addition, 2D Sn-based perovskite LEDs could be also fabricated on flexible 

**2307896 (26 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 

substrates by inkjet printing, and have reached an EQE of 1% in PEA2SnI4-based LEDs (Figure 19c–e).<sup>[303]</sup> 

Surprisingly, no PL emission has been reported in any 1D Sn and Ge-based perovskites thus far, which might be associated with their facile transformation into 0D structures under photoexcitation.<sup>[304]</sup> 0D Sn-based perovskites have also exhibited larger bandgaps (≈3 eV or above) and enhanced air stability compared to their 2D counterparts.<sup>[305]</sup> The significant dimensionality reduction further facilitates STE formation, owing to the removal of the energy barrier for self-trapping.<sup>[298]</sup> A broadband STE emission is hence more commonly observed in 0D Sn-based perovskites. For example, (C4N2H14Br)4Sn(Br0.5I0.5)6 could emit a broadband PL at 2.13 eV (FWHM ≈470 meV) with a large Stokes shift of 1000 meV.<sup>[306]</sup> The center of the broadband emission peak could be also tuned by changing the composition of halides or A-site cations.<sup>[307]</sup> Several 0D Sn-based perovskites have shown microsecond PL lifetimes and near-unity PLQYs, possibly due to their significantly enhanced exciton binding energies (e.g., _>_ 1 eV in Cs4SnBr6).<sup>[306,308,309]</sup> It is also worth mentioning that the PL intensity from 0D Sn-based perovskites could not be saturated at higher excited power,<sup>[308]</sup> which evidenced the intrinsic feature of STE emission and excluded the possibility of defect emission. 

Vacancy-ordered Sn-based double perovskites, with the general formula A2Sn<sup>IV</sup> X6, are also promising emitters, especially since the Sn cations are in the more stable 4+ oxidation state. Vacancy-ordered Sn-based perovskites exhibit a wide range of bandgaps (1.3–4.9 eV) depending on the halide composition.<sup>[310]</sup> While different from 2D and 0D Sn-based perovskites, carrier-phonon coupling in vacancy-ordered Sn-based double perovskites tends to be weaker, in part due to their dispersed band edges.<sup>[256]</sup> As a result, a narrow free exciton emission has been commonly seen in these materials. For instance, a PL at 2 eV with a small FWHM of 160 meV has been reported in Cs2SnI6 NCs.<sup>[78]</sup> Nevertheless, the potentially weaker excitonic binding strength and higher defect density could lead to low PLQYs ( _<_ 1%) and shorter PL lifetimes, of the order of only a few nanoseconds.<sup>[78]</sup> Interestingly, a broader PL at 2.73 eV (FWHM = 400 meV) and 2.06 eV (FWHM = 350 meV) could be individually achieved in Sb- and Bi-doped Cs2SnCl6 crystals.<sup>[311,312]</sup> Although the former was from defect emission, the latter was attributed to the transition from the triplet state to the ground state in Sb<sup>3+</sup> octahedrally coordinated by chlorides. Owing to the local minima in the excited-state potential energy surface for triplets caused by Jahn–Teller distortions<sup>[313,314]</sup> , two PL peaks could be seen at lower temperatures. A higher PLQY of ≈37% and 80% could be also reached in Sb- and Bi-doped Cs2SnCl6 crystals, respectively. 

So far, no emitters made from Ge-based perovskites have been reported, while some EL LEDs and phosphor-converted (PC) LEDs fabricated with Sn-based perovskites have been reported (Tables 4 and 5). EL LEDs emit light via free exciton recombination when charge-carriers are injected through the injection layers from the electrode, and the energy diagram of a typical CsSnI3 EL LED is illustrated in **Figure 20** a. On the other hand, PC LEDs integrated phosphors mixed in a polymer with commercial UV LED chips, which can pump the phosphors to generate broadband white light. 

As shown in Table 4, EL LEDs fabricated with 3D Sn-based perovskites have shown potential for NIR to red light emission, and the emission energy can be tuned by changing their halide 

compositions. Nevertheless, they could also easily degrade with air exposure, leading to a blue shift in the EL (Figure 20c) and a decrease in EQE.<sup>[283,315]</sup> It has been shown that by controlling the crystallization process through the inclusion of additives such as phenethylamine iodide (PEAI) or SnF2, the operational lifetimes (time for the initial peak radiance of the LED to decrease by 50% under continuous operation) of FASnI3 and CsSnBr3 LEDs in an inert environment could exceed 10 and 30 hours (Figure 20b), respectively.<sup>[285,316]</sup> Recently, LEDs fabricated with 2D Sn-based perovskites have also gained more attention owing to their higher intrinsic stability in the air. Particularly, a pure-red EL with rather small FWHMs (less than 0.1 eV) have been demonstrated in (PEA)2SnI4 as well as (TEA)2SnI4 LEDs, and this EL was stable in a wide voltage range<sup>[299,317,57]</sup> (Figure 20b). These LEDs also displayed a low turn-on voltage of 2.2–2.3 V and a maximum luminescence _L_ max over 300 cd m<sup>−2</sup> . Nevertheless, they still encounter the issues of low EQEs ( _<_ 1%)<sup>[57]</sup> and poor operational stability (degraded within a few seconds or minutes),<sup>[57,299]</sup> which has been attributed to the rapid film decomposition caused by Joule heating rather than oxidation. Interestingly, a broadband orange light with a FWHM of 0.52 eV could be also reached in EL LEDs based on (OAm)2SnBr4 microplates.<sup>[300]</sup> This EL resulted from the STE emission with a FWHM that could be broadened when more charge-carriers were thermally activated into the trapped state at higher temperatures. Similarly, (OAm)2SnBr4 LEDs also showed a high _L_ max of 350 cd m<sup>−2</sup> but a low EQE of only 0.1%. 

In terms of PC LEDs, several 0D, 2D, and vacancy-ordered Sn-based double perovskites with strong STE emission have been employed as phosphors. Due to the high air stability of these materials, the emission spectra from these LEDs could be usually maintained for over a few months,<sup>[75,308]</sup> as displayed in Figure 20e. By tuning the ratio of the mixed phosphors, white light emission with different color coordinates in the Commission Internationale de l’Éclairage (CIE) 1931 graph could be achieved in (OCTAm)2SnBr4 and Bi-doped Cs2SnCl6 LEDs.<sup>[75,312]</sup> The emission light spectra from these LEDs could range from “very warm white light” to “day white light”, which corresponds to a correlated color temperature (CCT) ranging from around 2000 K to over 6000 K, as shown in Figure 20f. Moreover, high color rendering index (CRI) values over 80,<sup>[75,311,318]</sup> which reached the requirement of commercial white light LEDs, have also been demonstrated in (OCTAm)2SnBr4 and Sb-doped Cs2SnCl6 LEDs. At present, Sn-based perovskites are more promising in PC LED applications compared to EL LEDs. 

_Outstanding Challenges_ : LHP LEDs have exhibited EQEs approaching 30% with peak luminance exceeding 10<sup>5</sup> cd m<sup>−2</sup> ,<sup>[98]</sup> which substantially outperforms all Sn-based perovskite LEDs reported so far. The greatest challenge for Sn- and Ge-based perovskites remains the facile oxidation of Sn<sup>2+</sup> and Ge<sup>2+</sup> to the +4 oxidation state,<sup>[305,320]</sup> which could lead to their ambient instability, high defect densities, and metallic-like conductivity feature due to self-doping.<sup>[321]</sup> For Sn-based perovskites, it has been claimed that self-doping could lead to very high hole concentration, which further caused unbalanced charge-injection in their LEDs, hence reducing the EQEs.<sup>[319]</sup> Additionally, poor film morphology resulting from a fast crystallization process<sup>[293]</sup> or low precursor solubilities in common organic solvents<sup>[322]</sup> is another factor limiting the device performance of Sn- and Ge-based perovskites. Although NCs could usually show better emission 

**2307896 (27 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 20.** a) A typical energy level diagram of a CsSnI3 LED. PEDOT:PSS and B3PYMPM is poly(3,4-ethylenedioxythiophene):poly(styrenesulfonate) and 4,6-Bis(3,5-di(pyridin-3-yl)phenyl)−2-methylpyrimidine, which acts as the hole and electron injection layer, respectively. Reproduced with permission.<sup>[319]</sup> Coypright 2021, John Wiley and Sons. b) EL spectra of a 3D CsSnI3 LED exposed to air at various times. Reproduced with permission.<sup>[315]</sup> Coypright 2021, John Wiley and Sons. c) The time evolution of the luminance of a CsSnBr3 LED under continuous operation. Reproduced with permission.<sup>[316]</sup> Coypright 2022, American Chemical Society. d) The EL spectra of a 2D PEA2SnI4 LED operated at different voltages. Reproduced under the terms of CC BY 4.0.<sup>[317]</sup> Copyright 2020, The Authors, published by Wiley-VCH. e) The emission spectra of a 0D (C4N2H14Br)4SnBr6 LED pumped by a 340 nm UV LED under air for more than six hours. Reproduced under the terms of CC BY 3.0.<sup>[308]</sup> Copyright 2018, The Authors, published by the Royal Society of Chemistry. f) The Commission Internationale de l’Éclairage (CIE) 1931 graph and correlated color temperatures (CCTs) of white light. The red triangle and white star are the color coordinate of a PC LED based on Sb-doped Cs2SnCl6 only and Sb-doped Cs2SnCl6 with other phosphors, respectively. Reproduced with permission.<sup>[311]</sup> Coypright 2019, Springer Nature. 

properties than thin films, there are few reports of Sn- and Gebased perovskite NC LEDs. This could be attributed to several reasons: first, it is still challenging to synthesize stable Ge-based perovskite NCs through hot injection;<sup>[320]</sup> second, the insulating nature of long-chain ligands surrounding NCs would highly impede charge-injection;<sup>[323]</sup> thirdly, during LED operation, ligands could be also detached, which potentially facilitated unwanted 

NC aggregation or increased defect densities;<sup>[323]</sup> eventually, currents might leak easily through NC films since they are less compact compared to bulk films.<sup>[324]</sup> 

_Future Prospects_ : Although SnX2 (X = halides) additives,<sup>[321,325]</sup> metallic Sn powders,<sup>[326]</sup> organic antioxidants,<sup>[107]</sup> and perfluorooctanoic acid<sup>[78]</sup> are effective in suppressing the oxidation of Sn<sup>2+</sup> , we believe that it is more important to identify 

**2307896 (28 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



**Table 6.** Performance summary of the NCs and thin film WLEDs. 

|EML|Device structure|EL Peak [nm]|EQEmax [%]|Lmax [cd<br>m<sup>−2</sup>]|Lifetime [min]|Reference|
|---|---|---|---|---|---|---|
|Cs2Ag0.6Na0.4InCl6|ZnO/PEIE/EML(VTE)/TAPC/MoO3/Al|552|N/A|≈50|10@50 mA cm<sup>−2</sup>|[92]|
|Cs2AgIn0.9Bi0.1Cl6|PVK/EML/TPBi/LiF/Al|≈410 and 610|0.08|158|48.5@15 mA cm<sup>−2</sup>|[328]|
|Cs2AgInxBi1-xCl6||557|≈0.01%|58|N/A|[329]|
||ITO/PEDOT:PSS/TFB/PVK:NPLs/ZnO/Al|nm|||||



the controversial degradation mechanism of Sn-based perovskites in order to fundamentally resolve their instability issue. Similar studies on Ge-based perovskites are even more crucial since they have not yet been realized in working LEDs. In addition, to achieve higher EQEs in Sn-based perovskite LEDs, more balanced charge-injection should be aimed for, possibly by modifying the film morphology or injection layers. It is also worth mentioning that LEDs fabricated with low-dimensional and vacancy-ordered Sn-based double perovskites have exhibited not only higher color purity or CRI values but also enhanced ambient stability compared to their 3D counterparts. We hence expect that these materials along with analogous Ge-based derivatives, will gain more attention in future studies. Finally, considering the outstanding emission properties in Sn-based perovskite NCs, we also encourage more investigations into relevant ligand engineering, which plays an important role in both charge-carrier transport and defect passivation. 

### _4.2.2. Double Perovskite LEDs_ 

With consideration of environmental friendliness, lead-free luminescent double perovskite (DP) materials with superior stability and high PLQY have emerged as promising candidates for LEDs. The flexibility of compositional engineering and the diversity of the band structure of DPs enables the achievement of multicolor luminescence covering the full visible–NIR gamut. This section summarizes recent progress in lead-free DP-based LEDs. 

_Double Perovskite Thin Film/NCs LEDs_ : In 2018, Tang’s group reported stable white emission from Bi<sup>3+</sup> -doped Cs2Ag0.6Na0.4InCl6 DPs and demonstrated highly efficient white emission based on the thin film LEDs driven by an electric field.<sup>[92]</sup> They claim that the alloying of Cs2AgInCl6 with Na+ catios results in transition of a parity forbidden transition to an allowed transition ( **Figure 21** a). Thus, the alloying of sodium and bismuth cations with Cs2AgInCl6 leads to a dramatic increase in PLQY from _<_ 0.1% to 86%. The LEDs fabricated via thermally evaporated Cs2Ag0.6Na0.4InCl6 films exhibit bias-insensitive broadband emission with a peak current efficiency of 0.11 cd A<sup>−1</sup> . Although the samples showed excellent stability under ambient conditions (Figure 21b), the corresponding LEDs exhibited yellowish electroluminescence, indicating the change of phase under the electric field. This may be attributed to poor film quality and uncontrollable composition segregation. After this early work, several other groups have reported the synthesis and luminescence properties of the doped-DP thin films and NCs and demonstrated the fabrication of LEDs. **Table 6** summarizes some of the representative work on DP (thin films and power)-based LEDs. 

For instance, Zhang et al. synthesized Tb<sup>3+</sup> , Sb<sup>3+</sup> co-doped Cs2NaInCl6 NCs with high PLQY blue-green emission (74%), which then transformed into white emission with Mn<sup>2+</sup> - doping.<sup>[327]</sup> The corresponding light down-conversion-based LEDs emit warm white light with a color rendering index (CRI) is 89.2 and a correlated color temperature (CCT) is 3371 K, meeting the standard of warm white lighting (2500–3500 K). After the early reports on strongly emissive bulk DPs, researchers have demonstrated the synthesis of colloidal doped-DP NCs by wet chemical approaches that were used for LHPs.<sup>[292]</sup> For instance, Cs2AgIn1−xBixCl6 DPs have been synthesized in the form of colloidal NCs with controlled size distribution and emit white light.<sup>[102]</sup> The NCs can be used in light down-conversionbased LEDs by incorporating them into a poly methyl methylacrylate (PMMA) matrix followed by coating on 380 nm LED chips. The down-converting LEDs exhibit white light emission with CIE coordinates of (0.36, 0.35), CRI values of ≈91, and correlated color temperature (CCT) of 4443 K. However, the progress on DP NC-based LEDs is much slower as compared to that of LHPs. There are only a few reports demonstrating the electroluminescence from DP LEDs. Recently, Qu et al. synthesized Cs2AgIn0.9Bi0.1Cl6 NCs with a PLQY of 31.4% and they demonstrated the fabrication of electrically excited white LEDs (WLEDs). Although the films showed bright and uniform warm white emission under UV excitation, the NCWLED exhibited weak electroluminescence (158 cd m<sup>−2</sup> ) with an EQE of 0.08%, as shown in Figure 21c,d.<sup>[328]</sup> Very recently, DP-based LEDs using two-dimensional (2D) Cs2AgInxBi1-xCl6 (0 ≤ x ≤ 1) NPls were reported, showing a luminance maximum of 58 cd/m<sup>2</sup> with a peak current efficiency of 0.013 cd/A (Figure 21e,f).<sup>[329]</sup> However, the resulting EQE and T50 values are significantly lower than the benchmark LEDs made of LHP NCs. This is probably due to the wide band gap ( _>_ 3.6 eV) and poor charge carrier mobility in double perovskites. The efficiency of DP-LEDs needs to be significantly improved for practical applications. We believe that a better understanding of the charge transport properties in DP systems would help to improve the efficiency of the corresponding LEDs. Meanwhile, researchers have turned their attention to DP polycrystalline and single crystals to achieve white light from single-component systems. 

_Double Perovskite Powder-Based LEDs_ : Despite slow progress in DP-based electroluminescent devices, a feasible application of double perovskites is the down-conversion LEDs based on covering GaN-based blue LED chips with highly luminescent DP powders (phosphors). As shown in **Figure 22** a, Nie et al. synthesized Cs2NaInCl6:Sb<sup>3+</sup> DPs by the hydrothermal method, emitting blue PL (PLQY≈ 90%). The corresponding down-conversion LEDs exhibit color coordinates of (0.147, 0.078).<sup>[330]</sup> In such 

**2307896 (29 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



**www.afm-journal.de** 



**Figure 21.** a) Strengthened STE confinement by the surrounding AgCl65− octahedra. Reproduced with permission.[92] Copyright 2018, Springer Nature. b) XRD patterns of a Cs2Ag0.60Na0.40InCl6 film (black line) and powder (red line). The inset shows a 300-nm thick quartz substrate and 500-nm-thick Cs2Ag0.60Na0.40InCl6 films under 254 nm ultraviolet illumination. c,d) Cs2AgIn0.9Bi0.1Cl6 QDs based electroluminescence device, including the device structure, energy band diagram of the Cs2AgIn0.9Bi0.1Cl6 QDs based WLED device. Reproduced under the terms of CC BY 4.0.<sup>[328]</sup> Copyright 2022, The Authors, published by Wiley-VCH. e) Band alignments and proposed charge carrier transfer processes of the NPL-LED; f) Electroluminescence (EL) spectrum of the LED. Reprinted with permission.<sup>[329]</sup> Copyright 2023, Wiley-VCH. 

systems, it is most likely that the emission comes from isolated SbCl6 octahedra.<sup>[95]</sup> Furthermore, doping with manganese ions can alter the spectrum toward the red emission. The dopants can also alter the emission color. Zhang et al. fabricated down-conversion LEDs based on 3% Mn<sup>2+</sup> -doped Cs2NaTbCl6, the orange color spectra showed excellent spectral stability at different voltages and currents applied to the blue LED chip. (Figure 22b).<sup>[331]</sup> The orange LED exhibited bright PL with CIE of (0.579, 0.352) and CCT of 2547 K. In many DP systems, Mn<sup>2+</sup> -doping can result in white light emission as discussed above. For example, Mn<sup>2+</sup> -doped Cs2Na0.4Ag0.6In0.95Bi0.05Cl6 emits white PL with a maximum PLQY of 31.8% and two emission maxima that are at 550 and 610 nm.<sup>[332]</sup> The corre- 

sponding Commission International de L’Eclairage (CIE) coordinates, emission color temperature, and CRI are (0.3784, 0.4216), 4323.4 K, and 82.6, respectively (Figure 22c). To obtain low CCT and high CRI WLEDs, Cs2AgIn1−xBixCl6 was used as an emitter by combining it with a 400 nm UV LED chip (Figure 22d).<sup>[333]</sup> This resulted in efficient, broad, yellowwhite PL (CRI = 85, CCT = 3119 K). These metrics meet the standard for warm white lighting with high color rendering abilities. 

The emission from most DP materials originates from the radiative recombination of STE species. Thus, they exhibit broad emission with large Stokes shift, making them suitable for WLEDs. Another strategy to tune the emission of the DPs is by 

**2307896 (30 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 22.** Different DP phosphors that were coated on an ultraviolet chip for the fabrication of down-conversion LED that emits blue, red, and broad white light emission and narrow infrared radiation. a) Cs2NaInCl6:Sb<sup>3+</sup> DPs. Reproduced with permission.<sup>[330]</sup> Copyright 2022, American Chemical Society. b) 3% Mn<sup>2+</sup> -doped Cs2NaTbCl6. Reprroducedd with permission.<sup>[331]</sup> Copyright 2022, American Chemical Society. c) Mn<sup>2+</sup> - doped Cs2Na0.4Ag0.6In0.95Bi0.05Cl6. Reproduced with permission.<sup>[332]</sup> Copyright 2019, Optical Society of America. d) Broadband White Emission in Cs2AgIn1–xBixCl6 Phosphors. Reprroduced with permission.<sup>[333]</sup> Copyright 2019, American Chemical Society. e) Ho<sup>3+</sup> -doped Cs2(Ag,Na)InCl6 DPs. Reproduced with permission.<sup>[335]</sup> Copyright 2019, Wiley-VCH. f) (Bi,Ce)-codoped Cs2Ag0.4Na0.6InCl6. Reprroduced with permission.<sup>[338]</sup> Copyright 2020, American Chemical Society. g) Cs2AgIn0.9Cl6:0.1Cr<sup>3+</sup> .Reproduced.<sup>[343]</sup> Copyright 2022 American Chemical Society. h) Nd<sup>3+</sup> doped Cs2AgIn0.99Bi0.01Cl6, Cs2NaEr0.4Yb0.6Cl6, and Yb<sup>3+</sup> and Er<sup>3+</sup> doped Cs2Ag0.2Na0.8BiCl6.The panel h is adapted with permission.<sup>[344–346]</sup> Copyright 2022, American Chemical Society; Copyright 2022, Wiley-VCH. 

doping with lanthanides.<sup>[334]</sup> For example, Ho<sup>3+</sup> -doped Cs2(Ag, Na)InCl6 DPs exhibit bright warm-white emission with peaks at 490, 450, and 650 nm (Figure 22e).<sup>[335]</sup> The doped sample exhibited an improvement of CRI from 70.3 to 75.4 as compared to pristine Cs2(Ag,Na)InCl6. On the other hand, the emission color is also tunable by doping different metal ions with a controllable ratio. For instance, by controlling Tb<sup>3+</sup> codopant concentration, the emission color of Bi-doped Cs2Ag(In1-xTbx)Cl6 NCs could be continuously tuned from green to orange, through the efficient energy-transfer channel from STE to Tb<sup>3+</sup> ions.<sup>[336]</sup> Similarly, co-doping Dy<sup>3+</sup> , Sm<sup>3+</sup> , and Tb<sup>3+</sup> ions into Cs2AgInCl6 NCs results in tunable emission from green to yellow-orange by varying the relative dopant concentration. The concept of change in emission color by co-doping can be used to obtain fluorescent patterns by spray coating the DP NC inks for anti-counterfeiting technology.<sup>[337]</sup> In addition, Wei et al. proposed a codoping (Bi, Ce) strategy to enhance the quantum efficiency of orange-emitting Cs2Ag0.4Na0.6InCl6:Bi.<sup>[338]</sup> As shown in Figure 22f, by combining the (Bi,Ce)-codoped sample with a blue BaMgAl10O17:Eu<sup>2+</sup> phosphor, a white light-emitting diode with an excellent color rendering index of 95.7 and a correlated color temperature of 4430 K can be achieved. Deng and coworkers demonstrated that (Bi,Gd)-codoped Cs2Ag0.4Na0.6InCl6 

phosphors are efficient for white LEDs when combined with blue phosphor BaMgAl10O17:Eu<sup>2+</sup> .<sup>[339]</sup> The corresponding warm white LEDs showed color coordinates of (0.3464, 0.3224), a colour rendering index of 93.9 and colour temperature of 4818 K. However, there are no single-matrix phosphors that rely on commercial blue phosphors. Although the CRI of DPs is relatively high, their color temperature is also very high, which is not conducive for daily lighting applications. 

For practical applications, it is necessary to further improve the operational stability of DPs. A few attempts have been made towards improving the operational stability of DP-LEDs. For instance, Li _et. al_ constructed WLED devices by combining Cs2Ag0.7Na0.3InCl6:Bi with a commercial UV-emissive LED chip (370 nm).<sup>[340]</sup> The resulting WLED showed CIE color coordinates of (0.38, 0.44), a CCT of 4347 K, and a high CRI of 87.8 with excellent working stability and a record lifetime above 1000 h. Similarly, Zeng et al. synthesized Cs2AgScCl6:0.05Bi emitting white light and with high stability against thermal and UV radiation.<sup>[341]</sup> Furthermore, a series of Cs2NaxAg1−xInCl6: Bi (x = 0, 0.2, 0.4, 0.6, 0.8, and 1) DP microcrystals were synthesized by a solvent-free melting-crystallization technique.<sup>[342]</sup> The optimized Cs2Na0.4Ag0.6InCl6: Bi microcrystal phosphors were combined with commercial blue and green phosphors and coated on 

**2307896 (31 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



**Table 7.** Performance summary of the powder-based WLEDs. 

|Device structure|PLQY [%]|CIE (_x_,_y_)|CCT [K]|CRI|Reference|
|---|---|---|---|---|---|
|UV LED/Cs2AgIn0.7Bi0.3Cl6 NCs/PMMA|4|(0.36, 0.35)|4443|91|[102]|
|UV LED/Cs2NaInCl6:2.5%Sb,45%Tb,3%Mn NCs|74|(0.41, 0.39)|3371|89.2|[279]|
|UV LED/Cs2(Na, Ag)InCl6:7.09%Ho<sup>3+</sup>|57.09|(0.39, 0.46)|N/A|75.4|[335]|
|UV LED/Cs2Na0.4Ag0.6In0.95Bi0.05Cl6:Mn<sup>2+</sup>|31.8|(0.3784, 0.4216)|4323.4|82.6|[332]|
|UV LED/Cs2AgIn1−xBixCl6|39|(0.417, 0.391)|3119|85|[333]|
|UV LED/Cs2Ag0.4Na0.6InCl6:1% Bi,1%/ BaMgAl10O17:Eu<sup>2+</sup>|98.6|(0.4, 0.38)|4430|95.7|[339]|
|UV LED/Cs2Ag0.4Na0.6InCl6: Bi,Gd/ BaMgAl10O17:Eu<sup>2+</sup>|87.57|(0.3464, 0.3224)|4818|93.9|[339]|
|UV LED/Cs2Ag0.7Na0.3InCl6:Bi|87.2|(0.38, 0.44)|4347|87.8|[340]|
|UV LED/Cs2AgScCl6:0.05Bi|60|(0.366, 0.367)|4100|96|[331]|
|UV LED/Cs2Na0.4Ag0.6InCl6: Bi|73.3|(0.461, 0.443)|2930- 6957|84.8-<br>97.1|[342]|



ultraviolet chips (365 nm) to fabricate WLEDs. The emission was tunable from warm white (2930 K) to cold white (6957 K). **Table 7** provides a summary of the performance of selected DP powderbased WLEDs. 

NIR light sources with broad coverage have drawn a special interest in optical communication, night vision technology, food analysis, health monitoring, and bio-imaging/bio-sensing. In early studies, rare earth ions were used as activators in LHPs to obtain the NIR luminescence, and later they were extended to DP systems. In 2019, Liu et al. reported Cs2AgInCl6:Cr<sup>3+</sup> via the traditional high-temperature solid-state reaction.<sup>[347]</sup> The sample (Cs2AgIn0.9Cl6:0.1Cr<sup>3+</sup> ) emits broad NIR emission with a PLQY of ∼22.03% upon 760 nm excitation (Figure 22g). Inspired by this, Cr<sup>3+</sup> -doped Cs2AgInCl6 NCs were synthesized via hot-injection synthesis, and the sample exhibited tunable emission from 998 to 958 nm by gradually substituting Ag<sup>+</sup> with Na<sup>+</sup> .<sup>[343]</sup> The excellent chemical and moisture stability of the sample enabled the fabrication of Cs2NaInCl6:Cr<sup>3+</sup> NC films by screen printing and thus showcases its potential application in high-resolution images and NIR fluorescent signs. Recently, several reports have been published on lanthanide ion-doped NIR LEDs, such as Nd<sup>3+</sup> doped Cs2AgIn0.99Bi0.01Cl6, Cs2NaEr0.4Yb0.6Cl6, and Yb<sup>3+</sup> and Er<sup>3+</sup> doped Cs2Ag0.2Na0.8BiCl6 (Figure 22h).<sup>[344–346]</sup> These NIR LEDs have demonstrated good night vision and human tissue penetration. Most notably, Wang et al. reported Na<sup>+</sup> -doped bismuth halide perovskite Cs2AgBiCl6 crystals to replace the traditional Cr<sup>3+</sup> -doped systems.<sup>[348]</sup> It was proposed that the incorporation of Na ions weakens the coupling between [AgCl6]<sup>5−</sup> octahedrons and confines the spatial distribution of the STE state around [AgCl6]<sup>5−</sup> and [BiCl6]<sup>3−</sup> . This leads to enhanced overlap of electron and hole orbitals, leading to enhanced NIR emission from STE states.<sup>[110,86]</sup> 

In summary, there has been certainly progress in the field of DP-LEDs, especially WLEDs based on doped DPs. However, there are several significant challenges that need to be overcome for the realization of electric-driven LEDs based on DPs. The quality of thin films could be improved by thermal evaporation methods, but precise control over the composition is critical. In the case of NC LEDs, colloidal DP NCs with high PLQY (both in solution and solid-state) need to be developed. The most critical factor that hinders efficiency is the large bandgap of double perovskites. Hence, the bandgap of DPs must be optimized by com- 

positional engineering or by combining them with other material systems. As demonstrated above, metal ion doping is imperative to improve the properties of DPs by breaking off forbidden transitions, and increasing their radiative transition rates, and simultaneously boosting the energy transfer efficiency. Therefore, there are numerous lead-free perovskite compositions that emit light in the visible to short-wave infrared ranges. The early results demonstrate the potential of DP-based powders for downconversion LEDs. A better understanding of charge-injection, transport, and recombination in DPs would help to improve the efficiency of electrically driven DP-LEDs. 

### **4.3. Radiation Detectors using Pb-free Perovskites** 

Photodetectors (PDs) are devices that convert incoming photons into electrical signals. They find numerous applications in various fields, including research, security, industry, and medical imaging.<sup>[349]</sup> It is important to develop materials that can detect photons of low intensity, especially to detect X-ray radiation as it is being extensively used in medical imaging and diagnostics. This is because high X-ray doses can increase the risk of cancer due to DNA damage. Therefore, materials characterized by a lower detection limit (LoD) are crucial for safer medical imaging allowing for lower radiation doses.<sup>[350]</sup> All PDs involve three key processes: i) photon absorption, ii) charge carrier generation, and iii) collection. Furthermore, ease of synthesis and material stability are mandatory for industrial production (iv). HPs are a class of semiconductors possessing optimal properties to excel in these processes and the ease of production as well. i) They exhibit strong photon absorption coefficients, especially for highenergy radiation such as X-rays, where the heavier elements (e.g., Cs<sup>+</sup> , Pb<sup>2+</sup> , I<sup>−</sup> ) are the main ones responsible for the high attenuation coefficient. Moreover, by varying their composition, the HPs’ bandgap (Eg), hence their absorption range, can be largely tuned. This tunability aids efficiency (ii). Especially for highenergy detection, charge carrier generation depends on Eg. Moreover, the charge carrier mobility can be substantially enhanced while reducing the charge trap density (iii). They can be produced using low-temperature solution methods and cheap constituents, making them cost-effective and easily scalable, in contrast to the commercially standard direct X-ray- PDs for which the 

**2307896 (32 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 





**Figure 23.** Schematic representation of indirect and direct X-ray detection. In the indirect modality, the absorbed X-rays are converted to lower energy photons (v), and their collection by a photodiode result in an electrical signal. The presence of (v) will eventually result in lower image resolution. Reproduced under the terms of CC-BY-3.0 and CC-BY-ND-3.0.<sup>[352]</sup> Copyright 2016, The Authors, published by NDT.net. 

production of the photoactive material (e.g., CdZnTe and CdTe) is cumbersome and expensive. HPs can be used to detect X-rays via direct or indirect methods (the latter mainly by means of elpasolite halide single crystals),<sup>[351]</sup> as illustrated in **Figure 23** . Yet, the most popular LHPs contain toxic lead and exhibit relatively low stability (as compared with commercial materials) under ambient conditions. Consequently, research interest has moved towards the development of Pb-free perovskites, such as Snbased HPs and DPs. In this section, we will focus on these two groups of HP materials, highlighting their properties, performance, and potential application as PDs. For a summary including the materials’ figures of merit (together with operating wavelengths) in the PD field, we refer our readers to **Figures 24** – **26** . It must be noted that the measurements and calculations of noise equivalent power (NEP), are necessary to assess the specific detectivity (D), depending on different types of noises affecting the PD. Therefore, different reports may consider different noise sources, leading to over- or under-estimation of D. 

Waleed et al. were the first to report the use of an THP (MASnI3) as active material in a PD. They fabricated perovskite NWs arrays inside a porous alumina template. The corresponding PD exhibited a responsivity (R) and specific detectivity of 0.47 A/W and 8.80 × 10<sup>10</sup> Jones, respectively, and rise and decay times ( _𝜏_ r and _𝜏_ d) of 1500 and 400 ms.<sup>[353]</sup> However, the NW-based PD showed a photocurrent decrease after only one week at 70% relative humidity, although its stability was almost three orders of magnitude higher than the plain thin film (TF) counterpart.<sup>[353]</sup> The same concept, NWs-based photodetection, was replicated by Han et al. who prepared the all-inorganic equivalents CsSnX3 (X = Cl, Br, and I). Among the different compositions, CsSnI3 showed the best results in the NIR range, as expected from its Eg. The CsSnI3 device exhibited an R and D of 54 mA/W and 3.85 × 10<sup>5</sup> Jones, respectively (940 nm), with a rather fast _𝜏_ r (83.8 ms) 

and _𝜏_ d (243.4 ms). However, also in this case, the sample degraded after six days even with a protective layer.<sup>[82]</sup> To overcome this instability issue related to THPs, Liu et al. developed an airstable FASnI3 using hydroxybenzene sulfonic acid and an excess of SnCl2 as an additive. By applying this approach, they produced a very thin THP film (120 nm), which showed a high R of 1.1 × 10<sup>5</sup> A W<sup>−1</sup> (@ 685 nm), which was attributed to the high hole density and mobility (p-type semiconductor). The device also demonstrated a response to 420 and 850 nm light illumination and high bending stability when FASnI3 was deposited on a flexible substrate. However, relatively low values of _𝜏_ r and _𝜏_ d (31 and 120 s, respectively) were recorded.<sup>[354]</sup> With a similar approach, Cao et al. tried to address the THPs instability issue by using SnF2 and ascorbic acid as additives to reduce the Sn<sup>2+</sup> to Sn<sup>4+</sup> oxidation. The resulting device showed a broad (350–1000 nm) and relatively fast ( _𝜏_ r/ _𝜏_ d of 0.35/1.6 ms) response. Moreover, the device remained stable in the air with approximately 80% humidity for more than one day.<sup>[355]</sup> Together with increasing the ambient stability, scientific attention has been given to device optimization as well. Liu et al. reported a PD based on a vertical heterojunction consisting of FASnI3 and PEDOT:PSS. Because of the resulting photogate effect, the device exhibited a maximum R of 2.6 × 10<sup>6</sup> A W<sup>−1</sup> (the highest reported for THPs) and D of 3.2 × 10<sup>12</sup> Jones with a broadband photoresponse from UV to NIR. Moreover, a flexible device made of a polyimide layer showed a high photoresponse as well.<sup>[356]</sup> Lastly, Howlader et al. improved the performance by morphology engineering via chlorobenzenetreated CsSnI3 TFs and coupling with carbon nanotubes. The resulting device exhibited an R of 10<sup>−2</sup> A W<sup>−1</sup> .<sup>[357]</sup> It must be noted that by slightly modifying the ASnX3 unit formula toward lowerdimensional perovskites, the THPs stability can be further enhanced, while still maintaining a good photoresponse.<sup>[358–360]</sup> Considering THPs, it is interesting to observe that the performances offered by these materials closely approach, and sometimes surpass, the ones of commercially available Si-PDs characterized by an R( _𝜆_ ) ≈ 0.5 A W<sup>−1</sup> and D ≈ 3 × 10<sup>12</sup> Jones.<sup>[361]</sup> However, even though the THPs have emerged as a promising alternative to the traditional LHPs, the use of Sn<sup>2+</sup> comes with a challenge as it is prone to oxidation to Sn<sup>4+</sup> , making it challenging to fabricate THPs with long-term stability using easy solution processes. Nonetheless, despite their slightly inferior optoelectronic properties and indirect bandgap, DPs can provide a more stable alternative to both LHPs and THPs, while still demonstrating a competitive photoresponse over a broad wavelength range. Lei et al. were the first to report a PD based on a Cs2AgBiBr6 TF.<sup>[362]</sup> Their film, made from an easy one-step spin-coating procedure, showed an R of 7.01 A W<sup>−1</sup> (520 nm), an on/off ratio of 2.16 × 10<sup>4</sup> , D of 5.66 × 10<sup>11</sup> Jones and _𝜏_ r/ _𝜏_ d of 956/995 μs. Although these values are comparable to those of Sn-based PDs, the most significant difference is that a Cs2AgBiBr6 -based PD, even without encapsulation, demonstrated remarkable stability during aging tests (36 hours of continuous operation and exposure to ambient conditions) with almost no loss in photodetection performance. Ever since, various research groups have investigated the possible use of Cs2AgBiBr6 TFs as PDs and their long-term stability. For instance, Xiu et al. used a capillary-assisted dip-coating method to obtain a “large-area” coverage with Cs2AgBiBr6 achieving an on/off ratio of 7.<sup>[363]</sup> Wu et al. demonstrated the possibility of self-powered photodetection through a heterojunction made of 

**2307896 (33 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



**www.afm-journal.de** 



**Figure 24.** Figures of merit (D in orange and R in green) for different THP PD compositions and typical device structures (top insets). The THP PD values have been compared to Si-PDs’ average performances (dotted lines).<sup>[361]</sup> a) Reproduced with permission.<sup>[353]</sup> Copyright 2017, American Chemical Society. b) Reproduced with permission.<sup>[82]</sup> Copyright 2019, American Chemical Society. c) Reproduced with permission.<sup>[354]</sup> Copyright 2019, WILEYVCH Verlag GmbH & Co. KGaA, Weinheim. d) Reproduced with permission.<sup>[355]</sup> Copyright 2020, John Wiley & Sons Australia, Ltd on behalf of UESTC. e) Reproduced with permission.<sup>[356]</sup> Copyright 2020, American Chemical Society. f) Reproduced with permission.<sup>[357]</sup> Copyright 2022, Springer Nature. 

Cs2AgBiBr6 /SnO2. Their planar device worked as a blue or UVA light detector without requiring any external bias.<sup>[364]</sup> On the same note, Li et al. created a self-powered PD relying on a favorable band alignment between Cs2AgBiBr6 and GaN.<sup>[365]</sup> Shifting to TF morphology engineering, Yang et al. achieved large grain sizes of ≈1 μm by adding a small amount of DMF to the DMSO precursor solution,<sup>[366]</sup> while Yan et al. suppressed the formation of pinholes and optimized the CABB layer grain size using ultrathin atomic layer deposition of a metal-oxide layer (e.g., NiOx) on an FTO substrate.<sup>[367]</sup> The resulting photodetector showed improved performance compared to the non-optimized substrate device, with a promising weak-light detection capability with a limit of detection as low as 1.9 × 10<sup>−9</sup> W cm<sup>−2</sup> , a high D of 1.2 × 10<sup>13</sup> Jones (surpassing previous reports), and an increased linear-detection-range (LDR) of 165.2 dB. Moreover, in a later report, they demonstrated that interfacial engineering with the HTL material CuSCN enhances the photoresponse as well.<sup>[368]</sup> Lastly, Fang et al. further reduced the thickness of the Cs2AgBiBr6 layer. The resulting nanoflakes- (around 5 nm thick) based PD achieved an R of 54.6 A W<sup>−1</sup> , on/off ratio of 7.4 × 10<sup>4</sup> , D of 7.4 × 10<sup>14</sup> Jones, and response times of 1.7 ms.<sup>[369]</sup> Nevertheless, these very promising values are limited by the nanoflakes’ lateral length (50 μm), which hampers the possibility to fabricate largearea ultrathin film devices. 

Moving to a bigger scale, Cs2AgBiBr6 single crystals (SCs) were used for X-ray and visible light detection by Pan et al. Focusing on visible light, they achieved high values of R, reaching 15.0 A W<sup>−1</sup> , and a D of 1.60 × 10<sup>13</sup> Jones (530 nm).<sup>[370]</sup> These values were possible due to enhanced charge-carrier transport, i.e., low trap density, high mobility-lifetime product, and high resistivity resulting from thermal annealing and surface treatment steps. Later, by optimizing the process of controlled cooling of a super-saturated solution (SSCC), Yin et al. were able to improve Cs2AgBiBr6 (opto)electronic properties and obtained a high R of 113.29 A W<sup>−1</sup> (530 nm).<sup>[371]</sup> In parallel, Dang et al. reported a modified seed-growth SSCC resulting in high-quality SCs.<sup>[372]</sup> 

The possibility of producing NIR PDs from Cs2AgBiBr6 has been demonstrated by several studies. Ji et al. used Cu-doping to shift the absorption edges of Cs2AgBiBr6 to the NIR range (≈860 nm) due to the formation of sub-bandgap states.<sup>[375]</sup> Liu et al. further lowered the band-edge to 1350 nm by Fe-doping, and the PD exhibited an on/off ratio higher than 10 (808, 980 nm),<sup>[376]</sup> while Zhang et al. proved that Ru doping allows NIR photodetection as well.<sup>[377]</sup> These approaches extended the absorption range of the DPs close to the Sn-iodide-based ones while retaining a stable photoresponse over several months compared to the few days or weeks of the Sn-based counterparts.<sup>[364,365]</sup> 

**2307896 (34 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



**www.afm-journal.de** 



**Figure 25.** Figures of merit (D in orange and R in green) for different DP PD compositions and typical device structures (top insets) in the UVVisible range. The DP PD values have been compared to Si-PDs’ average performances (dotted lines). a) Data reported from ref. [362]. b) Reproduced with permission.<sup>[364]</sup> Copyright 2018, WILEY-VCH Verlag GmbH & Co. KGaA, Weinheim. c) Reproduced with permission.<sup>[365]</sup> Copyright 2019, WILEYVCH Verlag GmbH & Co. KGaA, Weinheim. d) Reproduced with permission.<sup>[366]</sup> Copyright 2019, WILEY-VCH Verlag GmbH & Co. KGaA, Weinheim. e) Reproduced with permission.<sup>[367]</sup> Copyright 2020, American Chemical Society. f) Data reported from ref. [368]. g) Reproduced with permission.<sup>[369]</sup> Copyright 2021, Wiley-VCH GmbH. h) Data reported from ref. [370]. i) Reproduced with permission.<sup>[371]</sup> Copyright 2019, WILEY-VCH Verlag GmbH & Co. KGaA, Weinheim. j) Data reported from ref. [372]. k) Reproduced with permission.<sup>[373]</sup> Copyright 2019, WILEY-VCH Verlag GmbH & Co. KGaA, Weinheim. l) Data reported from ref. [240]. m) Reproduced with permission.<sup>[374]</sup> 2020, WILEY-VCH Verlag GmbH & Co. KGaA, Weinheim. 

However, the efficiency of the DP-PD for the NIR range is still lagging. 

It is important to mention that for X-ray PDs based on Pb-free HPs, most of the reports rely on a photoconductor device structure (i.e., Metal/HPs/Metal). In contrast, LHPs-based PDs are implemented in photodiode devices (e.g., p-i-n junction) resulting in self-powered PDs, offering a more efficient control of the device characteristics, and also reducing photoconductive gain. As previously mentioned, Pan et al. demonstrated the possible use of Cs2AgBiBr6 for X-ray detection and Murgulov et al. recently elaborated on this approach.<sup>[370,378]</sup> In their seminal paper, they reported for a vertical Au/ Cs2AgBiBr6/Au device a sensitivity (S) up to 105 μC Gyair−1cm−2 with a LOD of 59.7 nGyair s−1 and long-term operational stability. Similar post-treatment processes were also reported by Zhang et al.<sup>[379]</sup> Importantly, these treatment procedures suppress ion migration and reduce surface conduction channels, hence reducing noise in a device configuration. It is interesting to note that the sensitivity can be further improved by lowering the operating temperature as demonstrated by Steele et al. by cooling the SC CABB device from room temperature (316 μC Gyair−1cm−2) to 100 K (988 μC Gyair−1cm−2).[380] A reason for this behavior is that parasitic recombination path- 

ways are reduced at low temperatures. Later, Yin et al. optimized the SSCC process to produce a PD with a very high S of 1974 μC Gyair−1 cm−2, which is the highest reported value for SC CABB devices up to now.<sup>[371]</sup> In addition, also the LoD reached the lowest value of 45.7 nGyair s<sup>−1</sup> . Another approach to improve the SC device performance is to impart ordering at the level of the [AgX6]<sup>5−</sup> and [BiX6]<sup>3−</sup> inorganic sublattice, which can be achieved by replacing a certain amount of Cs<sup>+</sup> with phenylethylammonium as demonstrated by Yuan et al.<sup>[373]</sup> , while by means of partly substituting Cs<sup>+</sup> with alkali metals (Na<sup>+</sup> , K<sup>+</sup> , and Rb<sup>+</sup> ), the X-ray sensitivity of the Rb-doped device increased by 4.5 times.<sup>[381]</sup> 

Proven the high efficiency of Cs2AgBiBr6 for X-ray detection, a straightforward method for implementing this material into a large-area device was still needed. Potential approaches include the realization of compact and uniform (composite) thick films. In this frame, Li et al. proposed a flexible poly(vinyl alcohol)/Cs2AgBiBr6 (100 μm-thick) heterostructure showing a sensitivity of 40 μC Gyair−1 cm−2 at the rather high bias of 400 V.<sup>[382]</sup> To further improve large-area scalability, Yang et al. fabricated a wafer of CABB with suppressed ion migration thanks to heteroepitaxial passivation with BiOBr.<sup>[383]</sup> When used as 

**2307896 (35 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 





**Figure 26.** Figures of merit (S in orange and LOD in green) for different DP PD compositions and typical device structures (top insets) under X-ray irradiation. The DP PD S values have been compared to a-Se flat panel detectors, which represent the market gold standard X-ray direct conversion PDs. a,b) Data reported from ref. [370,379]. c) Reproduced with permission.<sup>[380]</sup> Copyright 2018, WILEY-VCH Verlag GmbH & Co. KGaA, Weinheim. h) Reproduced with permission.<sup>[383]</sup> Copyrigt 2019, Springer Nature. d–g) Data reported from ref. [371,373,378,382]. i) Reproduced with permission.<sup>[384]</sup> Copyright 2021, American Chemical Society. j) Reproduced with permission.<sup>[385]</sup> Copyright 2022, American Chemical Society. 

X-ray PD, a high S of 250 μC Gyair−1 cm−2 was reached, which is around ten times higher than that of a-Se X-ray detectors (20 μC Gyair−1 cm−2), operating at a much higher electric field of (10 Vμm<sup>−1</sup> ), and even higher than the first Cs2AgBiBr6 SC-based device by Pan et al. However, the measured LoD (95.3 nGyair s<sup>−1</sup> ) was slightly worse. A recent report from Haruta et al. introduced columnar grain grown- Cs2AgBiBr6 by means of mist deposition. The columnar grain structure offers easy integration with the readout electronics and a low density of grain boundaries across the direction of the charge-carrier collection.<sup>[384]</sup> The X-ray detector (92 μm-thick films) showed a high S of 487 μC Gyair−1 cm−2. 

The detection range of Cs2AgBiBr6 can be further extended to gamma-rays. Zhang et al. have grown Cs2AgBiBr6 from Bipoor precursor solutions to suppress deep electron trap formation. The resulting detector showed a response to 59.5 keV gamma-rays with an energy resolution of 13.91% (<sup>241</sup> Am), while a Cs2AgBiBr6 SC grown following the regular procedure did not show any response.<sup>[386]</sup> Responses to higher energy gammaphotons (511 keV<sup>22</sup> Na and 662 keV<sup>137</sup> Cs sources) were also obtained. 

The photodetection capabilities of DP materials are not limited to the Cs2AgBiBr6 composition. Cs2AgInCl6 can be used as a UV-PD<sup>[240]</sup> as reported by Luo et al. showing an on/off ratio of ≈500, D of 10<sup>12</sup> Jones, and a low dark current of ≈10 pA. Fur- 

thermore, Wang et al. demonstrated the viability of Cs2AgBiCl6 TFs for UV-light detection as well. The device exhibited an R ≈10 mA/W and D of ≈10<sup>12</sup> Jones.<sup>[374]</sup> In the X-ray range, Tailor et al. reached an X-ray sensitivity of 325.78 μC Gy<sup>−1</sup> cm<sup>−2</sup> and LoD of 241 nGy s<sup>−1</sup> with the same composition. It must be noted that the device can also work self-powered, but with a way lower S.<sup>[385]</sup> As expected, all the mentioned compositions were highly stable. 

In summary, Pb-free HPs have shown promising results for broad-range radiation detection, spanning from NIR to gamma-rays. Although long-term stability is still a concern for THPs, various strategies such as additive mixing<sup>[82]</sup> , encapsulation<sup>[353]</sup> , thin film engineering<sup>[357]</sup> , amongst others, have been proposed.<sup>[358–360]</sup> Another potential solution is to apply DPs, which possess a higher inherent stability. However, DPs’ best-performing composition, Cs2AgBiBr6, exhibits a higher bandgap than THPs, particularly iodide-based ones, which limits its detection range. Nonetheless, doping of Cs2AgBiBr6 can shift the band edge to the NIR region, making this material a preferred option for broad-range photodetection.<sup>[80,375–377]</sup> Additionally, various methods such as post-treatment,<sup>[370,379]</sup> doping,<sup>[381]</sup> synthesis,<sup>[371,387]</sup> and device engineering<sup>[364,368]</sup> have been reported to improve the DPs’ properties as well and even allow sensing at low light intensities and X-ray doses. Of particular 

**2307896 (36 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 27.** a) Schematics of the bandgaps of MAPbX3, FAPbX3, CsPbX3, MASnX3, and CsSnX3. Reproduced with permission.<sup>[400]</sup> Copyright 2017, WILEYVCH Verlag GmbH & Co. KGaA, Weinheim. b) Whispering gallery modes in a perovskite nanoplatelet. Reproduced with permission.<sup>[408]</sup> Copyright 2014, American Chemical Society. c) Schematic of an individual CsPbBr3 microsphere pumped by 800 nm laser excitation (≈40 fs, 10 kHz). d) Lorentz fitting of a lasing oscillation mode at 542.6 nm, giving an ultrasmall linewidth of ≈0.037 nm, corresponding to an ultrahigh Q factor ≈1.5 × 10<sup>4</sup> . Reproduced with permission.<sup>[103]</sup> Copyright 2018, WILEY-VCH Verlag GmbH & Co. KGaA, Weinheim. e) Waveguide architecture where the pump beam is end-fire coupled from the input edge of the structure. Reproduced with permission.<sup>[409]</sup> Copyright 2020, American Physical Society. 

interest, as the detection limit is lowered to a few tens of nGyairs<sup>−1</sup> lower X-ray dose rates will be sufficient for imaging, thus reducing the risks of radiation damage. Potential innovations for future research activities are suggested to offer enhanced sensitivity at the low-energy spectral range, polarization-selective sensing, and scintillation radiation detectors. These aspects have already been demonstrated, but further investigation is still necessary.<sup>[351,388–393]</sup> 

## **5. Pb-Free Perovskite Lasers** 

Halide perovskites (HPs) have emerged as excellent direct bandgap semiconductor materials due to their interesting properties such as sharp optical absorption edge, high absorption coefficient exceeding 10<sup>4</sup> cm<sup>−1</sup> just above the band edge, defect tolerance, and high PLQY.<sup>[394–396]</sup> Since the first demonstration of low-threshold, stable, tunable amplified spontaneous emissions (ASE) and lasing from methylammonium lead halides in 2014,<sup>[397–399]</sup> 3D HPs of different compositions have been extensively investigated for lasing using a variety of resonators. As discussed in the introduction, one of the most interesting properties of HPs is the tuning of the PL emission in the whole visible range and beyond, which makes them unique for lasing and other lightemitting applications. **Figure 27** a compares the tunable range of PL emission for Pb and Sn perovskite of different A-cation and halide compositions.<sup>[400,401]</sup> By varying the compositional combinations of A (MA, FA, and Cs), B (Pb or Sn), and X (Cl, Br, and 

I), the bandgap energies and emission spectra of all-inorganic ABX3 are readily tunable over the entire visible spectral region to NIR (410−900 nm) with narrow PL bands (with linewidth in the range 12–42 nm) and high PL quantum yield (PLQY) that are beneficial for developing photon sources, as light-emitting diodes (LEDs), optical amplifiers and lasers.<sup>[29]</sup> As shown in Figure 27a, the Sn-based 3D HPs (THPs) can produce lasing in practically the same wide spectral range as the well-studied 3D LHPs. Nevertheless, the exploration of THPs for lasing is at its early stages, and the number of investigated Sn-perovskite systems is only a few, likely due to their relatively low performance in optoelectronic devices and poor stability as compared to LHP-based devices. In this context, we first introduce the achievements made in LHP-based lasers and then discuss the research progress of Sn-perovskite lasers in comparison with LHP systems, and provide an outline for promising directions in the field of Sn-perovskite lasers. 

The total number of publications on ASE in LHPs exceeds a hundred (see for example the review<sup>[402]</sup> ). The observation of ASE is a necessary condition for the fabrication of LHP lasers, but a resonator is also needed to provide positive optical feedback. Due to the soft and flexible nature of HPs, their shapes and sizes can be conveniently manipulated to obtain single crystals with regular and smooth end faces, which can naturally serve as FabryPerot (FP) or Whispering Gallery Mode (WGM) resonant cavities. 

The simplest cavity is the FP geometry, which consists of only two end mirrors. The first LHP NW lasing from hybrid organicinorganic perovskites (MAPbX3) was reported in 2015.<sup>[403]</sup> The 

**2307896 (37 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 

single-crystal NWs of 8.5 μm length exhibit low lasing thresholds (0.22 μJ cm<sup>−2</sup> ), high-quality factors (≈3600), and broad spectral tunability covering from visible to NIR (≈500–790 nm). The single crystalline NWs have an internal FP cavity due to their large dimensions. Various other shapes of LHP single crystals including micro/nanorods and cubes also possess natural FP cavities to achieve optical gain.<sup>[84,353,404–407]</sup> Such single crystals can also exhibit WGM-type lasing. The WGM lasers have another type of cavity in which the light propagates as a ring to form a traveling wave amplification. The interface between the gain medium and air can provide total internal reflection due to the large difference between their refractive indexes. The high quality of microcrystals leads to low optical losses, and thus LHP WGM lasers were demonstrated with record-breaking laser line parameters. The first HP WGM laser based on hybrid organic– inorganic MAPbI3−aXa perovskite NPls of the triangular or hexagonal shapes with a thickness of ≈150 nm and an edge length of ≈32 μm was demonstrated in 2014 (Figure 27b).<sup>[408]</sup> Later on, LHP WGM laser parameters were essentially improved to the quality factor of 1.5 × 10<sup>4</sup> with an FWHM of 0.037 nm for the case of CsPbBr3 spherical microcavity (Figure 27c,d).<sup>[103]</sup> Another prospective approach to achieve low-threshold ASE from planar films is presented in Figure 27e, where the excitation beam is end-fire coupled at the input edge of the optical waveguide determined by the perovskite/PMMA bilayer structure.<sup>[409]</sup> The waveguide is efficiently excited along 1–3 mm longitudes, which results in extremely low ASE thresholds of 20–100 nJ cm<sup>−2</sup> . The first LHP laser with an external cavity was realized in 2014.<sup>[397]</sup> It was FP mode vertical laser based on a distributed Bragg reflector with a lasing threshold as low as 0.2 μJ per pulse. Further optimization of similar Vertical Cavity Surface Emitting LHP Lasers was carried out by using different active compositions for both hybrid organic-inorganic and all-inorganic HPs.<sup>[410–417]</sup> For more examples of these types of lasers, see ref. [402]. 

Despite the high lasing parameters achieved for LHPs, the presence of the hazardous Pb limits their exploitation on an industrial scale.<sup>[418,45]</sup> Therefore, currently, an important task is the development of semiconductor gain media for lasers based on Pb-free halide perovskites with relatively simple and straightforward fabrication methods and similar emission efficiencies as their LHP counterparts. Among all, Sn halide perovskites (THPs) are the most promising candidates to substitute LHPs. It has already been demonstrated that all-inorganic as well as organic-inorganic THPs are suitable absorber materials for solar cells.<sup>[294,419]</sup> Furthermore, tin iodide perovskites exhibit emission in the near-infrared region, which is rare among wet-cast materials and, thus, makes them an attractive candidate for nearinfrared LEDs and lasers.<sup>[283,420]</sup> However, the most challenging issue with THPs is the instability of Sn<sup>2+</sup> ions that are easily oxidized to the Sn<sup>4+</sup> state leaving Sn<sup>2+</sup> vacancies, which results in unintentional p-type doping up to 10<sup>19</sup> cm<sup>−3</sup> .<sup>[421,422]</sup> Such high unintentional doping is undesired for solar cells because it results in fast electrons-hole (e<sup>−</sup> -h<sup>+</sup> ) recombination with characteristic lifetimes of tens to hundreds of picoseconds<sup>[137,420]</sup> and, consequently, short diffusion lengths in tens of nanometers. This is likely one of the main reasons for the relatively low efficiencies of the THP solar cells. Although high unintentional p-doping is detrimental for photovoltaics, it might turn beneficial for light emitting applications because the additional monomolecu- 

lar recombination pathway between photoexcited e<sup>−</sup> and h<sup>+</sup> released from dopants should be radiative for a direct bandgap semiconductor.<sup>[179]</sup> Such enhancement of radiative recombination should be helpful for lasing because the ASE threshold is governed by the radiative efficiency of the material.<sup>[423]</sup> Such examples are available in the literature. For instance, doped GaAs nanowires exhibit improved radiative efficiency and therefore increase in PLQY by several orders of magnitude, resulting in an essential decrease in the ASE threshold.<sup>[424]</sup> Indeed, in the first work demonstrating ASE and lasing in inorganic CsSnI3 perovskites, the addition of 20% SnF2 gives rise to an extremely low ASE threshold of 6 μJ cm<sup>−2</sup> at room temperature,<sup>[425]</sup> which is unattainable in LHPs.<sup>[426]</sup> 

A relatively low ASE threshold (388 μJ cm<sup>−2</sup> ) was reported for FASnI3.<sup>[179]</sup> Note that the use of THPs for light-emitting and lasing applications requires a mandatory decrease in the natural degree of doping that is often observed for pristine materials. The PL lifetime in pristine THPs is as short as tens of picoseconds, which limits the gain for ASE to occur. Interestingly, the addition of 10–20% SnF2 sufficiently decreases the hole doping densities to increase PL lifetime up to ≈0.5 ns which improves the conditions for ASE and lasing to occur.<sup>[427]</sup> The dependence of the ASE threshold on the concentration of the added SnF2 was studied experimentally for CsSnI3 films.<sup>[425]</sup> It was found that the increase in the SnF2 concentration from 5 to 20% leads to a decrease in the ASE threshold from 17 to 6 μJ cm<sup>−2</sup> ( **Figure 28** a). To achieve low ASE thresholds, the shortening of PL lifetime caused by efficient intrinsic non-radiative recombination processes is critical, as in the case of MASnI3 (MASnI3) films.<sup>[428]</sup> The ASE threshold strongly depends on the preparation conditions that determine the PL lifetime and level of unintentional doping.<sup>[429]</sup> In addition, it was also shown why it is so important to ensure low ASE threshold values for lasing because the Auger recombination would increase with the concentration of photogenerated carriers especially for values close and above the Mott transition.<sup>[429]</sup> 

It is important to stress that only a few studies demonstrated NIR ASE or lasing using Sn iodide perovskite thin films.<sup>[179,425,429–432]</sup> Especially, single-mode lasing was observed only in one of the works, where SnF2-treated CsSnI3 drop-casted on a butterfly wing was used as a gain medium with external cavities (Figures 28b-d). In this case, a low lasing threshold of 15 μJ cm<sup>−2</sup> with a quality factor Q ≈ 500 was obtained.<sup>[425]</sup> Very recently, random lasing (RL) with a threshold as high as 18 mJ/cm<sup>2</sup> and a Q-factor of ∼3000 was observed for CsSnI3 films,<sup>[430]</sup> whereas, for FASnI3, low-threshold ASE (2 μJ cm<sup>−1</sup> at 20 K and 50 μJ cm<sup>−2</sup> at room temperature) and RL with a Q ≈ 10<sup>4</sup> was observed.<sup>[431]</sup> Finally, ASE with a threshold as low as 1 μJ cm<sup>−2</sup> at room temperature was observed for FASnI3 film confined in a planar waveguide.<sup>[432]</sup> 

An important distinguishing feature of the RL in FASnI3 films is the spectral stability of the observed narrow laser lines (Δ _𝜆_ ≈ 0.1 nm) in the multimode spectrum.<sup>[431]</sup> The reproducibility of the laser modes in the multimode spectrum is demonstrated in Figure 28e, where a set of RL spectra under excitation fluence increasing from 125 to 1150 μJ cm<sup>−2</sup> is presented. The authors attributed the unusual spectral stability of multimode RL emission to the inhomogeneous broadening of the PL spectrum of FASnI3 films (Figure 28f). It has been shown that each spectral mode in the RL spectrum corresponds to one space mode, and 

**2307896 (38 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 28.** a) Variable fluence measurements of the ASE thresholds for three SnF2-treated (5%, 10%, and 20% of SnF2) samples of the butterfly wing. b) Optical image of a butterfly scale from the white part of the wing. Inset is a photograph of the butterfly. c) SEM image showing lamellae (vertical structures) in the scale. d) A comparison of the PL, ASE, and single mode lasing in CsSnI3 (20% SnF2); e) RL spectra of FASnI3 thin film measured at 20 K under excitation by 532 nm pulses at different excitation fluences. f) Typical PL spectra of FASnI3 films measured at 300 K (red colors) and 20 K (green colors) in different places of a sample under excitation spot size of about 400 μm that illustrates the sample inhomogeneity and PL spectra inhomogeneous broadening. g) The scheme explains the mechanism of generation of reproducible RL modes (narrow dashed contours) under conditions of inhomogeneously broadened amplification contour (solid line). a–d) Reproduced with permission.<sup>[425]</sup> Copyright 2016, WILEY-VCH Verlag GmbH & Co. KGaA, Weinheim. e–g) Reproduced with permission.<sup>[431]</sup> Copyright 2023, WILEY-VCH Verlag GmbH & Co. KGaA, Weinheim. 

all the modes are localized in an excitation spot of ≈100 μm diameter. Such mode overlapping in standard RL systems having no inhomogeneous broadening inevitably results in their strong interaction and instability of the corresponding spectral modes. In systems with inhomogeneous broadening, the spatially overlapped modes do not interact as long as the spectral separation between the modes is larger than the homogeneous linewidth of the emitting centers.<sup>[433,434]</sup> The mechanism of the mode spectral stabilization is illustrated schematically in Figure 28g. Thus, as the previously proposed practical applications of HPs random lasing were mainly limited by speckle-free light sources,<sup>[435]</sup> the recently observed effect of spectral stabilization of multimode RL radiation in FASnI3 thin films opens up prospects for their practical use as cheap sources for narrow laser lines. It is important 

to highlight that the samples of MAPbI3 measured at the same experimental conditions as FASnI3 do not exhibit random RL at room temperature, and the low-temperature RL is not spectrally stable as it was observed for FASnI3.<sup>[431]</sup> Consequently, the THP laser is one of the few current systems that outperform LHP devices. 

All these initial results have opened the doors for the development of NIR lasers based on THPs, where the aspects that are detrimental to the development of solar cells, such as selfdoping or inhomogeneous broadening in the PL spectrum, are beneficial for the development of lasers. However, the development of lasers in the visible spectrum will undoubtedly require more research efforts to find ways to reduce non-radiative recombination. 

**2307896 (39 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 





**Figure 29.** a) Thermal stability (at 85 °C) of the PSC with and without RbCl doping. Reproduced with permission.<sup>[438]</sup> Copyright 2022, The American Association for the Advancement of Science. b) Thermal stability analysis of the encapsulated Sn-based devices under continuous heating 80 °C in air. Reproduced with permission.<sup>[439]</sup> Copyright 2021, Wiley-VCH. c) Schematic illustration of the degradation pathways and mechanisms. 

to investigate the degradation mechanisms of PSCs through the perspectives of morphology and crystal structure and orientation.<sup>[389,441,442]</sup> Regarding electron microscopy techniques, SEM is often used to characterize perovskite morphology on the basis of electron backscattering diffraction (EBSD) and cathodoluminescence (CL), whereas TEM has been used to study the effect of external stress on the crystal structure at the atomic level.<sup>[443]</sup> Nevertheless, electron beam irradiation can result in local heating and even decomposition of perovskites, thus special care is required to avoid beam-induced damage. On the other hand, Kelvin probed forced microscopy (KPFM) has evolved as one of the non-destructive methods that can map the surface potential to obtain the work function of the sample. This provides the electrical changes of optoelectronic devices, which combined with other probing techniques.<sup>[444]</sup> Likewise, optical spectroscopic techniques have also been used to obtain direct information of the recombination kinetics and internal electrochemical potential of free charge-carriers in pure perovskite films, perovskite layer with charge transport layers, and full devices.<sup>[445]</sup> For example, by combing transient PL microscopy with confocal microscopy, one can track the charge carrier transport in the out-of-plane direction to visualize the heterogeneity of charge diffusivities in a 3D perovskite film, which can be correlated with their degradation.<sup>[446]</sup> For extensive details on the characterization techniques used for studying the degradation mechanisms, we refer the readers to the literature.<sup>[440,443,445,447]</sup> 

### **6.1. Degradation Mechanisms of LHPs** 

### _6.1.1. Moisture-Induced Degradation_ 

## **6. Degradation Mechanism of Pb- versus Pb-Free Perovskites** 

Despite the extraordinary increases in the PCE of PSCs, their operational stability is a major obstacle to their commercialization. In particular, the operation stability under external stress, such as light exposure, ambient air, bias, and elevated temperature (6585°C, Figures 29a,b), is far behind that of Si-based solar cells.<sup>[436]</sup> Early-stage stability testing on laboratory-scale perovskite optoelectronic devices according to International Summit on Organic PV stability (ISOS)-L-3 standards is important for bringing the technology from lab to fab.<sup>[437]</sup> Therefore, understanding the degradation mechanism of perovskites (with and without encapsulation) under different stresses is required to find solutions for improving their stability ( **Figure 29** c). This section summarizes the degradation mechanism of Pb- and Sn-based perovskite optoelectronic devices under light, oxygen, humidity, bias, and heat (Figure 29c). In addition, different in-situ characterization techniques that are being used to monitor the degradation process are also discussed along with an outlook of the methods to enhance the stability of Sn-based perovskite solar cells. 

To study the degradation mechanism, several in situ probing techniques with high time resolution are utilized, which include XRD, electron microscopy, tip-based, and visible/infrared absorption.<sup>[440]</sup> Among all, synchrotron-based grazing-incidence X-ray scattering techniques feature good statistics and are nondestructive. These features make them indispensable tools 

The humidity-induced degradation initiates at grain boundaries, and consists of an amorphous intergranular layer that facilitates fast moisture uptake,<sup>[448,449]</sup> and then further expands towards the interior grains along the in-plane direction. In addition, grain fracture is found during moisture invasion, which depends on the tensile strength of the top region of the perovskite film.<sup>[450]</sup> The tensile strength originates from the volume expansion caused by the faster cooling of the top region as compared with the bottom region of perovskite film during annealing. With further permeation of moisture, perovskites undergo hydration and even decomposition. Moisture-induced degradation of perovskites can be also understood from the perspective of defects, where point defects are identified as the degradation sites because of their affinity to water and oxygen molecules.<sup>[451]</sup> In addition, the absorption energy of water molecules at vacancy defects is much higher than that of pristine surfaces, indicating the accelerated degradation at the vacancy sites.<sup>[452]</sup> Notably, the formation of point vacancies, i.e., VI and VMA, are more favorable than the formation of VMAI. Therefore, the formation of CH3NH2 or I2, or HI is more likely than the formation of MAI under moisture-induced degradation.<sup>[453]</sup> It should be noted that the PbI2-terminated surfaces are stable in the presence of water, whereas MAI-terminated surfaces are prone to solvation.<sup>[454]</sup> We further refer readers to the literature that summarized the moisture-induced degradation mechanisms, and methods to enhance the stability against moisture.<sup>[448,455,456]</sup> 

**2307896 (40 of 62)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2307896 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

