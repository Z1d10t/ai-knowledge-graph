# Toward a BT.2020 green emitter through a combined multiple resonance effect and multi-lock strategy

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 196 |
| 作者 | Junyuan Liu, Yun-Hui Zhu, Taiju Tsuboi, Chao Deng, Weiwei Lou, Dan Wang, Tiangeng Liu, Qi-Sheng Zhang |
| DOI | 10.1038/s41467-022-32607-3 |
| 源文件 | 040_Liu_2022_Toward-a-BT2020-green-emitter-through-a-combined.pdf |

---
## nature communications 

Article 

https://doi.org/10.1038/s41467-022-32607-3 

# Toward a BT.2020 green emitter through a combined multiple resonance effect and multi-lock strategy 

|Received: 14 February 2022<br>Accepted: 3 August 2022|Junyuan Liu<br>1, Yunhui Zhu<br>2<br>, Taiju Tsuboi<sup>1</sup>, Chao Deng<sup>2</sup>, Weiwei Lou<sup>2</sup>,<br>Dan Wang<sup>1</sup>, Tiangeng Liu<sup>1 </sup>& Qisheng Zhang<br>1,3|
|---|---|
||Color-saturated green-emitting molecules with high Commission Inter-|
|Check for updates|nationale de L’Eclairage (CIE) y values have great potential applications for<br>displays and imaging. Here, we linked the outer phenyl groups in multiple-<br>resonance (MR)-type blue-emitting B (boron)-N (nitrogen) molecules through<br>bonding and spiro-carbon bridges, resulting in rigid green emitters with<br>thermally activated delayedfluorescence. The MR effect and multiple inter-<br>locking strategy greatly suppressed the high-frequency vibrations in the<br>molecules, which emit green light with a full-width at half-maximum of 14 nm<br>and a CIE y value of 0.77 in cyclohexane. These were the purest green mole-<br>cules with quantum efficiency and color purity that were comparable with<br>current best quantum dots. Doping these emitters into a traditional green-<br>emitting phosphorescence organic light-emitting diode (OLED) endowed the<br>device with a Broadcast Service Television 2020 color-gamut, 50% improved<br>external quantum efficiency, and an extremely high luminescence of<br>5.1 × 10<sup>5 </sup>cd/m<sup>2</sup>, making it the greenest and brightest OLED ever reported.|



To better reproduce the true colors in the world, the color-gamut standard in display technology has gradually advanced from standard RGB (sRGB) to the National Television Standards Committee (NTSC), and now to the Broadcast Service Television 2020 (BT.2020) standard, with the largest color-gamut triangle coverage for Commission Internationale de L’Eclairage (CIE) 1931 color space thus far. To achieve the BT.2020 standard for each of the three primary colors, the emission maximum should be in a specific wavelength region, and the full width at half-maximum (FWHM) should be sufficiently narrow. Among the different types of luminescent materials, quantum dots (QDs) possess extremely high color purity by controlling their nanoscale size<sup>1–3</sup> . However, the high cost and difficulty of their process control and storage hinder the large-scale applications of QDs<sup>4</sup> . The design and synthesis of organic fluorescent molecules with high color purity are both attractive and challenging. The use of narrow-band emitters in organic light-emitting diode (OLED) displays can reduce light loss 

caused by the color filter and/or optical microcavity<sup>5,6</sup> , thereby improving the efficiency and stability of the displays. 

Generally, the emission spectra of fluorescent molecules are broad due to structural deformation in the excited state and the molecular vibrations<sup>7–12</sup> , which are enhanced by thermal conductivity through conjugated π-bonds<sup>13,14</sup> . Recently, Hatakeyama et al. reported on a new kind of thermally activated delayed fluorescence (TADF) emitters based on multiple-resonance (MR)<sup>15–17</sup> . The separation of the highest occupied (HOMO) and lowest unoccupied (LUMO) molecular orbitals at the atomic level resulted in small singlet-triplet exchange energy<sup>18</sup> , as well as suppressed thermal conductivity in the excited state. The spectral FWHM value of the devices containing a blue MRTADF emitter, ν-DABNA, reached 18 nm, which was narrower than state-of-the-art micro-light-emitting diodes and QDs light-emitting diodes, and was quite close to the blue color requirements for the BT.2020 standard<sup>18</sup> . Enhancing the electron-donating and 

> 1MOE Key Laboratory of Macromolecular Synthesis and Functionalization, Department of Polymer Science and Engineering, Zhejiang University, Hangzhou 310027, China.<sup>2</sup> Zhejiang Hongwu Technology Co., Ltd., Taizhou 317100, China.<sup>3</sup> State Key Laboratory of Clean Energy Utilization, Zhejiang University, Hangzhou 310027, China. e-mail: zhuyunhui@hwoled.com; qishengzhang@zju.edu.cn 

Nature Communications |  (2022) 13:4876 

1 

Article 

https://doi.org/10.1038/s41467-022-32607-3 

-withdrawing capabilities of the fragments in the MR-TADF molecules can result in a bathochromic shift in the emission spectra. In 2019, researchers obtained a series of green MR-TADF emitters by introducing an electron-deficient group with fluoro-substituents into sky-blue emitting DtBuCzB (Scheme 1)<sup>19,20</sup> . In 2020, Duan et al. obtained a green MR-TADF emitter, AZA-BN, by introducing an electron-deficient azaaromatics group to expand the molecular conjugation<sup>21</sup> . The device containing AZA-BN achieved a CIE y value of 0.69, which is currently the best performing bottom-emitting green organic light-emitting diode (OLED) to date. However, the above molecular design strategies enhanced the electronic structural changes as well as solid-state solvation in the excited state, which broadened the emission band along with the emission red-shift<sup>19–22</sup> . 

In this work, we reported on two new green MR-TADF molecules, tCzphB-Fl and tCzphB-Ph (Fig. 1), with emissions that can meet the BT.2020 color-gamut standard for photoluminescence (PL) and electroluminescence (EL). These two molecules were evolved from the blue MR-TADF emitter t-DABNA and the sky-blue emitter DtBuCzB<sup>20,23</sup> . t-DABNA contains two isolated phenyl groups that are perpendicular to the BN-core plane. Wang et al. enlarged the π-conjugation length of t-DABNA by directly linking the phenyl groups and BN core through C-C bonds and obtained sky-blue emitting DtBuCzB<sup>20</sup> . However, the two outer phenyl-rings were twisted slightly out of the core plane in DtBuCzB, due to steric repulsion between the adjacent H-atoms. In this work, two more planar green-light emitting molecules were obtained by locking the outer phenyl-rings with the central phenyl-ring in DtBuCzB using spiro-carbon formation, which differed from the previous design strategy through the introduction of electronwithdrawing groups. This new strategy suppressed the excited-state distortion and the vibration modes caused by the strong intramolecular charge transfer (ICT) effect<sup>7</sup> . The spectral FWHM values of these two molecules in cyclohexane solution were as narrow as 14 nm. The OLEDs containing the new emitters achieved a purely green emission with an FWHM value of 24 nm and CIE coordinates of (0.21, 0.75), and this was the purest green emission reported for bottom-emitting OLEDs. Due to the TADF decay pathway for triplet excitons, the devices achieved a very high external quantum efficiency (EQE) of 31%, which was 50% higher than the control devices based on classic green phosphorescent materials. 

### Results 

#### Photophysical properties 

tCzphB-Ph and tCzphB-Fl were prepared with good yields using twostep cascade reactions from 1,5-dibromo-2,4-difluorobenzene and 9,9′- 



<!-- Start of picture text -->
B B<br>N N N N<br>t -DABNA DtBuCzB<br>B B<br>N N N N<br>tCzphB-Fl tCzphB-Ph<br><!-- End of picture text -->

Fig. 1 | Structures of molecules. Scheme showing the molecular design strategy and molecular structures of t-DABNA, DtBuCzB, tCzphB-Ph, and tCzphB-Fl. 

(4,6-dibromo-1,3-phenylene)bis-9H-carbazole, as shown in Supplementary Fig. 1. These two compounds showed very small Stokes shifts of 15 nm in toluene solution (1 × 10<sup>−5</sup> M) at room temperature (RT) (Fig. 2a), implying very small geometric distortion in the emissive state. The emission maxima (λ) of tCzphB-Ph and tCzphB-Fl in toluene were 524 nm and 532 nm, respectively, which considerably red-shifted compared to 483 nm for DtBuCzB (Fig. 2b). The FWHMs of the emission spectra were both 21 nm for the two tCzphBs in toluene, which was narrower than 25 nm for t-DABNA and DtBuCzB. The emission spectra of the two tCzphBs blue-shifted and became narrower with a decrease in solvent polarity (Fig. 2c and Supplementary Fig. 2). In cyclohexane (cHex), the emissions of tCzphB-Ph and tCzphB-Fl had an FWHM value of 14 nm and CIE coordinates of (0.15, 0.77) and (0.19, 0.76), respectively, and these values were comparable to the best green-light emitting QDs<sup>24–26</sup> . This was also the first time the CIE y value of the PL spectrum of a molecule exceeded the NTSC green-light standard of 0.71<sup>19–21,27–31</sup> . An analysis for the appearance of the narrow band in tCzphB-Ph and tCzphB-Fl is given using the Huang-Rhys factor (Supplementary Note 1). Another analysis on the observation of wider PL band of tCzphB-Ph and tCzphB-Fl with FWHM of 21 nm in toluene compared with FWHM of 14 nm in cHex is given in Supplementary Note 2. 

By doping into a classical host material 4,4′-bis(N-carbazolyl) −1,1′-biphenyl (CBP) at a concentration of 2 wt%, tCzphB-Ph, and tCzphB-Fl exhibited their emission maxima at 529 nm and 537 nm with FWHM values of 30 and 33 nm, respectively (Fig. 2c and Supplementary Fig. 2). The FWHM values of these two compounds in the carbazole-based host were considerably broader than in toluene, which was associated with the polarity of the carbazole units and the inhomogeneity of molecular aggregation<sup>32</sup> . To inhibit the effect of solid-state solvation, a low polar sphere-like molecule, 2,2′,7,7′-tetraphenyl-9,9′-spirobi [thioxanthene] (TPSS), was used to replace the commonly used carbazole derivatives as the host. The emission maxima of tCzphB-Ph and tCzphB-Fl in the TPSS host were comparable to those in CBP, and the FWHM values were reduced to 23 and 25 nm, respectively (Fig. 2c). Because the highly rigid molecular frameworks suppressed structural deformation-induced nonradiative decay, the PL quantum yields (PLQYs, Φ) of tCzphB-Ph and tCzphB-Fl doped into the TPSS films (2 wt%) reached 0.98 and 0.93, respectively. In addition to the fluorescence decay with a lifetime (τ) of approximately 7 ns, a TADF component with a lifetime of hundreds of microseconds was observed (Fig. 2d and Supplementary Fig. 3). The TADF lifetimes are much longer than those of a few microseconds observed in traditional ICT-type TADF emitters with similar ΔEST (~0.04 eV, Table 1)<sup>18</sup> , which can be ascribed to the small Huang-Rhys factors of these tCzphBs according to the Marcus–Levich–Jortner theory (Supplementary Note 3). 

Single crystals of tCzphB-Ph and tCzphB-Fl were successfully obtained by slow methanol diffusion in dilute dichloride solutions. The crystal structures shown in Fig. 3a and Supplementary Fig. 4 revealed a planar skeleton in both molecules. The angles between the central phenyl ring and the surrounding phenyl rings were nearly 0 degrees. The phenyl and fluorenyl groups that connected to the spiro-carbons were almost perpendicular to the BN plane. Steric hindrance provided by these groups separated the BN planes of the adjacent molecules by a distance of 7.3 Å, which inhibited the π-π interaction-induced fluorescence quenching and spectral broadening. The natural transition orbital (NTO) pairs for the first excited singlet (S1) state were simulated by time-dependent density functional theory (TD-DFT) at the PBE0/631G (d, p) level<sup>33</sup> . As shown in Fig. 3b and Supplementary Fig. 5, the highest occupied (HONTO) and lowest unoccupied (LUNTO) NTOs of the tCzphBs were spatially separated, the same as those of t-DABNA and DtBuCzB. However, the delocalization range of the orbitals in the tCzphBs was larger than those in t-DABNA and DtBuCzB. The vertical emission energy of tCzphB-Ph was calculated to be 2.53 eV, which was 

Nature Communications |  (2022) 13:4876 

2 

Article 

https://doi.org/10.1038/s41467-022-32607-3 



<!-- Start of picture text -->
a b<br>c d<br>S<br>S<br>TPSS N N<br>CBP<br><!-- End of picture text -->



tetrahydrofuran (THF), dichloromethane (DCM), and organic semiconductor films of CBP and TPSS at RT (inset: image of cyclohexane solution under UV light, and molecular structures of CBP and TPSS). d Transient PL decay spectra of tCzphB-Ph and tCzphB-Fl doped into the TPSS films (2 wt%) at RT. 

Fig. 2 | Absorption, emission, and transient decay spectra. a UV-vis absorption (gray line) and fluorescence (red line) spectra in 10<sup>−5</sup> M toluene at RT and phosphorescence (100–1000 μs component, blue line) spectra in toluene at 77 K. b Fluorescence spectra of t-DABNA, DtBuCzB, tCzphB-Ph, and tCzphB-Fl in toluene at RT. c Fluorescence spectra of tCzphB-Ph in cyclohexane (cHex), toluene (Tol), 

lower than the values of 2.96 eV for t-DABNA and 2.79 eV for DtBuCzB (Supplementary Fig. 6). Because the electron-donating capacity of the fluorenyl group in tCzphB-Fl was higher than the isolated phenyl groups in tCzphB-Ph, the theoretical transition energy of tCzphB-Fl was slightly lower than tCzphB-Ph, which was consistent with the experimental results. 

It is known that the weak electron-vibration coupling is responsible to decrease the FWHM of the emission band when largeamplitude nuclear rearrangement in the S1 state has been suppressed<sup>10–13</sup> . To better understand the excellent color purity achieved by the tCzphBs, the vibrationally-resolved fluorescence spectra were simulated by TD-DFT at the PBE0/6–31G (d, p) level and compared with DtBuCzB (Fig. 3c, d, and Supplementary Fig. 7)<sup>34</sup> . The MR-TADF molecules suppressed spectral broadening due to the stretching vibrations of the π-bonds by alternately embedding electron-rich and electron-poor atoms between the benzene rings. However, because of repulsions by the hydrogen atoms in the adjacent phenyl rings, the tert-butylcarbazole groups and the central phenyl ring in DtBuCzB were not in the same plane. The calculated vibrationally-resolved fluorescence spectra showed that the twisting and stretching vibrations between the tert-butylcarbazole moieties and the central phenyl ring in the excited state broadened the fluorescence spectrum of DtBuCzB. In the tCzphBs, the tert-butylcarbazole moiety and central phenyl ring were locked by a spiro-carbon atom, and consequently, vibrational relaxation in both the ground and excited states was significantly suppressed. The spectral simulations based on the Franck-Condon principle showed that the dominant vibration modes in the tCzphBs were the scissoring of phenyl or fluorenyl groups outside the main plane, and the rocking of the 

substituted tert-butyl groups, which were almost in the low-frequency region (Supplementary Table 1) and had little effect on the fluorescence spectrum. The commonly used simulation method derives all vibration lines by Gaussian function with the same FWHM. However, the rigid tCzphBs exhibit a relatively steep vibrational potential energy curve compared to DtBuCzB (Supplementary Fig. 8), implying a narrower conformational distribution in the ground and excited states. In Franck-Condon analyses of emission spectra, the FWHM used to resolve the major vibrational band for the tCzphBs should be narrower than that for DtBuCzB, which must further enlarge the difference between the FWHMs of the final spectra. 

#### OLED performance 

The thermal decomposition temperatures (Td) of tCzphB-Ph and tCzphB-Fl were both over 400 °C, as recorded by thermogravimetric analysis (TGA) under a purged nitrogen atmosphere (Supplementary Fig. 9). The excellent thermal stability of these two compounds would allow for vacuum evaporation for device fabrication. The EL performance of the tCzphBs was then evaluated by the devices with a structure of ITO/HAT-CN (15 nm)/TAPC (70 nm)/TPSS:emitter (2 wt%, 30 nm)/Bepp2 (5 nm)/Bepp2:Liq (50 wt%, 30 nm)/Liq (1 nm)/Al, where HAT-CN, TAPC, Bepp2, and Liq consisted of 1,4,5,8,9,11-hexaazatriphenylene-hexacarbonitrile, 1,1-bis [(di-4-tolylamino) phenyl] cyclohexane, bis [2-(2-hydroxyphenyl)-pyridine] beryllium, and 8- hydroxyquinolinolato-lithium, respectively (Supplementary Figs. 10–12). As shown in Fig. 4, both devices exhibited pure green emissions with an application voltage greater than 3.0 V. The peaks, FWHMs, and CIE coordinate values of the EL emissions were 527 nm, 24 nm, and (0.21, 0.75) for the tCzphB-Ph-based device, and 535 nm, 

Nature Communications |  (2022) 13:4876 

3 

Article 

https://doi.org/10.1038/s41467-022-32607-3 

|kF<br>d [×108s−1]|1.2|1.1|doped TPSSfilms.||
|---|---|---|---|---|
|τp<br>c [ns]<br>τd<br>c [us]<br>Φ/Φp<br>c|6.9<br>372<br>0.98/0.80|7.3<br>412<br>0.93/0.81|respectively (Supplementary Fig. 10). cMeasured in 2 wt%||
|FWHM c [nm]<br>ΔEST<br>c [eV]|23<br>0.04|25<br>0.04|ylformamide for HOMO and LUMO energy levels,||
|λPL<br>c [nm]|527|535|ne andN,N-dimeth||
|LUMOb [eV]|.72|.73|s in dichlorometha|pectively.|
|O/|−2|−2|m|es|
|WHMa [nm]<br>HOM|1<br>−5.15/|1<br>−5.12/|from the cyclic voltammogra|of the prompt component, r|
|F|2|2|etermined|nd lifetime|
|L<br>a [nm]|3|1|−5M. bD|PLQY a|
|λP|52|53|ion of 10|dividual|
|[nm]|||concentrat|are the in|
|und<br>λabs<br>a|Ph<br>508|Fl<br>518|in toluene with a|, whereΦpandτp|
|Compo|tCzphB-|tCzphB-|aMeasured|dkF=Φp/τp|



26 nm, and (0.26, 0.72) for the tCzphB-Fl-based device, respectively. These values exceeded the requirements for the NTSC green-light standard (CIE y = 0.71) and set a new record for the highest CIE y values among all reported bottom-emitting OLEDs (Supplementary Table 2)<sup>19–21,27–31,35,36</sup> . Because tCzphB-Ph and tCzphB-Fl had sufficiently small ΔEST values, enabling efficient up-conversion from T1 to S1, the external quantum efficiency (EQE) maximum values of their devices reached 29.3% and 26.2%, respectively. However, the devices underwent serious efficiency roll-off as the current density increased, due to the long triplet state lifetimes of the two MR-TADF emitters (Table 1). Using the tCzphB-Ph-based device as an example, EQE dropped dramatically to 13.6% and 2.6% at luminescence values of 500 and 10,000 cd/cm<sup>2</sup> , respectively (Fig. 4d). 

To suppress the efficiency roll-off in the MR-TADF OLEDs, phosphorescence sensitized TADF (PSTADF) OLEDs containing tCzphBs as the emitter were fabricated<sup>37</sup> . On the basis of the device structure mentioned above, the light-emitting layer was replaced with doped films consisting of BCz-o-TRZ: 5 wt% Ir(ppy)3 and BCz-o-TRZ: 5 wt% Ir(ppy)3: 2 wt% tCzphBs (structure I in Supplementary Fig. 11), where BCz-o-TRZ (9-(2-(4,6-diphenyl-1,3,5-triazin-2-yl)phenyl)−9′-phenyl9H,9′H−3,3′-bicarbazole) and Ir(ppy)3 (fac-tris(2-phenylpyridine)iridium) were the bipolar transport materials with a small ΔEST and a classic green phosphor, respectively<sup>38,39</sup> . The device without tCzphBs had a unique EL spectrum of Ir(ppy)3 with an FWHM value of 58 nm and CIE coordinates of (0.26, 0.64) (Fig. 4). The device achieved an EQE maximum of 20.0% and an EQE of 18.0% at a luminance of 10,000 cd/ m<sup>2</sup> . The doping concentration of 5 wt% for Ir(ppy)3 achieved the optimized result (Supplementary Fig. 13). After doping 2 wt% tCzphBPh into the emitting layer of this traditional phosphorescence OLED (PHOLED)<sup>40</sup> , a sharp green emission from tCzphBs was detected instead of emission from Ir(ppy)3, indicating an efficient Forster̈ resonance energy transfer (FRET) from Ir(ppy)3 to tCzphBs (Fig. 4a and Supplementary Fig. 14)<sup>40</sup> . In addition to the improved color purity with CIEy >0.71, the double-doped devices containing tCzphB-Ph and tCzphB-Fl exhibited a greatly improved EQE with a maximum of 31.3% and 29.7%, respectively, compared to the Ir(ppy)3-single-doped device (Fig. 4d). Specifically, the efficiency roll-off caused by phosphor-based triplet-triplet annihilation was significantly reduced in the two doubledoped device, due to the singlet harvest through a long-range FRET pathway (Supplementary Fig. S14) and the subsequent fast radiative decay (kF = 1.2 × 10<sup>8</sup> s<sup>−1</sup> , Table 1)<sup>21</sup> . In addition, the small energy difference between the frontier orbitals of BCz-o-TRZ host (−5.26 eV/ −2.64 eV, ref. 38) and the tCzphBs (Table 1) avoids charge carrier trapping and direct triplet exciton formation at the terminal dopant. The tCzphB-Ph-based PSTADF OLED maintained a high EQE value of 30.6% at a luminance of 10,000 cd/m<sup>2</sup> and achieved an ultrahigh luminescence of 5.1 × 10<sup>5</sup> cd/m<sup>2</sup> , which was associated with a high EQE of 25.9%. These were the best performance results for green-emitting OLEDs without the use of light out-coupling enhancement techniques (Supplementary Table 2). The increased EQE with respect to the control Ir(ppy)3-based device was more closely related to the increased PLQY of the emitting layer. The PLQY values were 0.98 and 0.93 for the double-doped films containing 2 wt% tCzphB-Ph and tCzphB-Fl, respectively, versus 0.67 for the Ir(ppy)3 doped BCz-o-TRZ film (5 wt%). 

Some recent works on TADF-sensitized fluorescence devices indicated that doping fluorescent emitters with high fluorescence rate into the conventional TADF OLEDs can promote their operational stability by reducing the energy and lifetime of the excitons<sup>41,42</sup> . The reliability of the two PSTADF OLEDs was tested under a constant current density of 20 mA/cm<sup>2</sup> , to compare the Ir(ppy)3-based PHOLED. The times to reach 90% of the initial luminance (LT90) were 0.5, 12.0, and 8.1 h for the devices doping tCzphB-Ph, tCzphB-Fl, and only Ir(ppy)3, respectively. The replacement of the TAPC layer with low glass-transition temperature (Tg = 79 °C)<sup>43</sup> by a 60 nm N-([1,1′-biphenyl]−2-yl)-N-(9,9-dimethyl- 

Nature Communications |  (2022) 13:4876 

4 

Article 

https://doi.org/10.1038/s41467-022-32607-3 



<!-- Start of picture text -->
a b<br>Top-view Side-view HONTO LUNTO<br>c d<br><!-- End of picture text -->

Fig. 3 | Molecular structures and simulation results. a Crystal structure of tCzphB-Ph. b HONTO (one electron) and LUNTO (one electron) distributions of tCzphB-Ph in its S1 state in toluene. c, d Simulated vibrationally-resolved fluorescence spectra with dipole strengths of different vibrational modes for c DtBuCzB and d tCzphB-Ph. Only several modes at high energies 

(Supplementary Table 1) are plotted by vertical lines. The simulated fluorescence spectra envelope is derived by mean of Gaussian function with FWHM of 200 cm<sup>–1</sup> for each vibration line which is calculated by the TD-DFT method, to compare the spectra observed in cyclohexane. Inset: the molecular structures and domain vibration modes. 

9H-fluoren-2-yl)−9,9′-spirobi[fluoren]−2-amine layer (Tg = 140 °C)<sup>44</sup> and a 10 nm N,N-di([1,1′-biphenyl]−4-yl)−4′-(9H-carbazol-9-yl)-[1,1′biphenyl]−4-amine layer (structure II in Supplementary Fig. 11)<sup>45</sup> improved the LT90 lifetimes of the above three devices to 1.4, 70.5 and 55.7 h, respectively, without slowing the device efficiency and color purity (Supplementary Fig. 16). The poor stability of tCzphBPh in the devices might be associated with the steric hindrance effect around the two spiro-carbon bridges which decreases the strength of the locking bonds (Supplementary Fig. 17 and Table 3). The bond dissociation energy of tCzphB-Ph was calculated to be 4.50 eV, which is markedly smaller than that of 4.63 eV for tCzphB-Fl (Supplementary Fig. 18). Although the device containing tCzphB-Fl has only an 27% longer lifetime than the Ir(ppy)3-single-doped device with structure II, the initial luminance of the former (2.4 × 10<sup>4</sup> cd/m<sup>2</sup> ) is almost twice as higher as that of the latter (1.3 × 10<sup>4</sup> cd/m<sup>2</sup> ), indicating that doping tCzphB-Fl into a green PHOLED can significantly improve the device lifetime if they are measured at the same initial luminance. Fine-tuning the emission maximum of this type B-N molecule based on the structure of tCzphB-Fl is under way. 

To conclude, color-saturated green-emitting molecules were successfully obtained by locking all of the phenyl rings surrounding the sp<sup>3</sup> -N atoms in MR-type blue-emitting BN molecules. The combination of multiple resonance effect and rigid molecular framework suppresses both irreversible geometry relaxation and reversible stretching and rocking vibration in the excited state, which consequently minimized the Huang-Rhys factor (i.e., minimized the displacement of equilibrium position in the excited state) and narrowed the major vibrational band in the emission spectra. In non-polar solvent cyclohexane, the FWHM and CIE y values of the emission spectra were 14 nm and 0.77, respectively, and these values were comparable to state-of-the-art QDs, revealing great potential for EL and light conversion applications. The OLEDs containing these green emitters doped into a low polarity host material achieved a high EQE of 29.3%, due to the high PLQY (0.98) and TADF properties of the emitters. The device exhibited a color-saturated 

green emission with an FWHM value of 24 nm and CIE coordinates of (0.21, 0.75), and was the purest green bottom-emitting OLED ever reported. Doping these innovative green emitters into PHOLEDs based on classical green phosphor Ir(ppy)3, can simultaneously improve the EL efficiency, color purity, and operational stability. Because phosphor-based triplet-triplet annihilation was suppressed by the FRET pathway, the PSTADF OLED exhibited a reduced efficiency roll-off compared to the control PHOLED, and achieved an extremely high luminescence over 5 × 10<sup>5</sup> cd/m<sup>2</sup> . Therefore, we believe that this multi-lock strategy for MR-TADF materials could be used for the development of narrowband organic emitters with fullcolor emissions, as well as high EL efficiency and stability. 

### Methods 

#### General 

All commercially available reagents were used as received directly unless otherwise stated. All reactions were carried out under a nitrogen atmosphere in dry solvents. Compounds tCzphB-Ph and tCzphB-Fl were synthesized according to Supplementary Fig. 1 and purified by thermal gradient sublimation twice before device fabrication. Detailed synthesis procedures were showed in Supplementary Note 3. 2,2′,7,7′-Tetraphenyl-9,9′-spirobi [thioxanthene] (TPSS) was provided by Zhejiang Hongwu Technology Co.Ltd. The other organic materials for OLED fabrication were purchased from Jilin Optical and Electronic Materials Co. Ltd and were used as received without further purification. Nuclear magnetic resonance spectroscopy (NMR) were recorded by Bruker Avance III 400 spectrometer (<sup>1</sup> H: 400 MHz,<sup>13</sup> C: 101 MHz) and Bruker Avance III 500 spectrometer (<sup>1</sup> H: 500 MHz) at 298 K. The<sup>1</sup> H and<sup>13</sup> C NMR chemical shifts were expressed as δ downfield with the internal standard of tetramethylsilane (TMS). Purity analysis was done by a Thermo Scientific Ultimate 3000 series HPLC system equipped with a RS variable wavelength detector and a Thermo Scientific column (Acclaim-120 series). Mass spectra were recorded by Thermo Scientific ISQ<sup>TM</sup> EC single quadrupole mass spectrometer using positive ion electrospray ionization. Elemental analyses were 

Nature Communications |  (2022) 13:4876 

5 

Article 

https://doi.org/10.1038/s41467-022-32607-3 



<!-- Start of picture text -->
a b<br>c d<br>DET �<br><!-- End of picture text -->

Fig. 4 | OLED characteristics. a EL spectra of the TADF OLEDs containing tCzphBs, PHOLED containing Ir(ppy)3, and the PSTADF OLEDs containing both Ir(ppy)3 and tCzphBs, to compare the absorption (Abs) spectrum of tCzphB-Ph in toluene (inset: image of the PSTADF OLED containing tCzphB-Ph). b Corresponding 1931 CIE coordinates of the device emission. c Current density-voltage-luminance characteristics of the investigated OLEDs. 

d EQE-luminance characteristics of the investigated OLEDs. Inset: diagram of the Förster resonance energy transfer (FRET) and reverse intersystem crossing (RISC) pathways in the PSTADF OLED. The Dexter energy transfer (DET) pathway is greatly suppressed because the low concentration of the terminal dopant prevents the approach of the excited sensitizer and the terminal dopant<sup>21</sup> . 

performed using a EuroEA EA3000 and correlated with linear method. 

500 °C under nitrogen flow, after eliminating residual thermal history of compound. 

#### Quantum chemical calculations 

All calculations were performed with the Gaussian 16 program package<sup>46</sup> . The geometries of all molecules in their ground state (S0) and excited state (S1) were optimized by DFT and TD-DFT, respectively, using the PBE0 function with 6-31G (d, p) basis sets in toluene. By frequency analysis, structures were confirmed at the local minima of the potential surfaces. The models of molecular structure and the HONTO/LUNTO iso-surface distribution were rendered by Multiwfn and VMD<sup>33,47</sup> . Based on the electronic structure in S0 and S1, the Laplacian bond order of each bond was calculated by Multiwfn. The bond dissociation energy for the ground state of tCzphBs was calculated according to the electron energy change in the ring-opening reaction. The single point energies of radical species were calculated at the PBE0/6-31G (d, p) level in toluene. On the basis of the optimized ground state geometry, the vibrational mode that contributes mostly to the fluorescence spectrum was selected to outline the potential energy surface. The geometric structures corresponding to the vibration mode at the amplitudes of ±1, ±0.75, ±0.5, and ±0.25 can be obtained by GaussianView software, and single-point energy calculations were performed on these structures. 

#### Thermal properties 

Thermogravimetric analysis (TGA) were performed by TA-Q50. The TGA curve was measured at heating rate of 10 °C/min from RT to 

#### Cyclic voltammetry measurements 

Electrochemical properties were measured by a CHI-600E electrochemical analyzer S-20 equipped with a glassy carbon working electrode (Φ = 5.0 mm), a platinum wire auxiliary electrode, and an Ag/Ag<sup>+</sup> reference electrode. The oxidation and reduction processes were measured by scanning the potential at a scan rate of 100 mV/s in O2free dichloromethane (DCM) and N,N-dimethylformamide (DMF), respectively, with 0.1 M tetrabutylammonium hexafluorophosphate as supporting electrolyte. The ferrocene couple Fc/Fc<sup>+</sup> was served as the external reference. 

#### Photophysical measurements 

UV-VIS absorption spectra were measured by a Shimadzu UV2600 UV/ VIS spectrophotometer. Photoluminescence spectra and quantum yield of the samples were measured using a PTI QM-40 spectrofluorometer equipped with an integrating sphere. Time-resolved fluorescence (1 ns) and phosphorescence (0.1–1 ms) spectra and microsecond transient decay spectra were recorded by a PTI TimeMaster fluorimeter equipped with a PTI nitrogen laser (GL-3300, λ = 337 nm, pulse width ≈1 ns), a ARS-4HW cryo equipment, and a closed cycle helium refrigerator. Nanosecond transient decay spectra were recorded on Horiba DeltaFlex modular lifetime measurement system patented the time-correlated single-photon counting (TCSPC) technique and equipped with a diode laser as the excitation source (λ = 370 nm, pulse width ≈50 ps). 

Nature Communications |  (2022) 13:4876 

6 

Article 

https://doi.org/10.1038/s41467-022-32607-3 

#### X-ray crystallography 

X-ray diffraction data were measured at 170 K on a Bruker APEX-II CCD diffractometer using graphite-monochromated Mo-Kα radiation (λ = 0.71073 Å) from a rotating anode generator. Using the Olex2 program<sup>48</sup> , the structures were solved with the ShelXT structure solution program using Intrinsic Phasing and refined with the ShelXL refinement package using Least Squares minimisation<sup>49</sup> . All Hydrogen atoms on carbons were placed in calculated positions and refined using the riding model. All non-hydrogen atoms were refined with anisotropic displacement parameters. Solvent molecules in crystal were squeezed. The crystal data as well as the details of data collection and refinement are summarized in Supplementary Tables 4 and 5. 

#### OLED fabrication and measurements 

After carefully precleaned the indium-tin-oxide (ITO) glass substrate, the organic layers and metal layer were thermally evaporated under vacuum (<5 × 10<sup>−5</sup> Pa) with 1 Å/s deposition rate for organic layers and 4 Å/s for aluminum cathode. The active area of the devices is 10 mm<sup>2</sup> . The electrical characteristics of OLEDs were measured with a Keithey 2400 Source meter and a Keithey 2000 Source multimeter equipped with a calibrated silicon photodiode in a dark container. The electroluminescence spectra were recorded using a multichannel spectrometer (PMA12, Hamamatsu Photonics). The external quantum efficiency can be calculated based on the electroluminescence spectrum and electroluminescent performance when Lambertian emission was assumed. The operational lifetimes of the encapsulated OLEDs were measured by a multichannel OLED lifetime test system designed by Prof. Zhilin Zhang at Shanghai University. 

### Data availability 

The data supporting the findings in this study are provided in the Supplementary Information file.The single-crystal data have been deposited in the Cambridge Crystallographic Data Center database (CCDC-2175560 for tCzphB-Ph [https://doi.org/10.5517/ ccdc.csd.cc2c0vcm], CCDC-2175561 for tCzphB-Fl [https://doi.org/ 10.5517/ccdc.csd.cc2c0vdn]). The DFT and TD-DFT raw data are available at the Figshare database (https://doi.org/10.6084/m9. figshare.20319060.v1). Source data are provided with this paper. 

### References 

1. Colvin, V. L., Schlamp, M. C. & Alivisatos, A. P. Light-emitting diodes made from cadmium selenide nanocrystals and a semiconducting polymer. Nature 370, 354–357 (1994). 

2. Coe, S., Woo, W.-K., Bawendi, M. & Bulović, V. Electroluminescence from single monolayers of nanocrystals in molecular organic devices. Nature 420, 800–803 (2002). 

3. Dai, X., Deng, Y., Peng, X. & Jin, Y. Quantum-dot light-emitting diodes for large-area displays: towards the dawn of commercialization. Adv. Mater. 29, 1607022 (2017). 

4. Yang,Z. et al. Recent advances in quantum dot-based light-emitting devices: Challenges and possible solutions. Mater. Today 24, 69–93 (2019). 

5. Yokoyama, H. Physics and device applications of optical microcavities. Science 256, 66–70 (1992). 

6. Köhler, A. & Bässler, H. Electronic Processes in Organic Semiconductors: An Introduction. (Wiley-VCH, Weinheim, 2015). 

7. Grabowski, Z. R., Rotkiewicz, K. & Rettig, W. Structural changes accompanying intramolecular electron transfer: Focus on twisted intramolecular charge-transfer states and structures. Chem. Rev. 103, 3899–4032 (2003). 

8. Kaji, H. et al. Purely organic electroluminescent material realizing 100% conversion from electricity to light. Nat. Commun. 6, 8476 (2015). 

9. Rajamalli, P. et al. New molecular design concurrently providing superior pure blue, thermally activated delayed fluorescence and optical out-coupling efficiencies. J. Am. Chem. Soc. 139, 10948–10951 (2017). 

10. Gierschner, J., Mack, H.-G., Lüer, L. & Oelkrug, D. Fluorescence and absorption spectra of oligophenylenevinylenes: Vibronic coupling, band shapes, and solvatochromism. J. Chem. Phys. 116, 8596–8609 (2002). 

11. Santoro, F., Lami, A., Improta, R., Bloino, J. & Barone, V. Effective method for the computation of optical spectra of large molecules at finite temperature including the Duschinsky and Herzberg–Teller effect: The Qx band of porphyrin asa case study. J. Chem.Phys. 128, 224311 (2008). 

12. Ha, J. M. et al. Rational molecular design of azaacene-based narrowband green-emitting fluorophores: Modulation of spectral bandwidth and vibronic transitions. ACS Appl. Mater. Interfaces 13, 26227–26236 (2021). 

13. Kong, F.-F. et al. Probing intramolecular vibronic coupling through vibronic-state imaging. Nat. Commun. 12, 1280 (2021). 

14. Xu, Y. et al. Molecular engineered conjugated polymer with high thermal conductivity. Sci. Adv. 4, eaar3031 (2018). 

15. Hatakeyama, T. et al. Ultrapure blue thermally activated delayed fluorescence molecules: Efficient HOMO–LUMO separation by the multiple resonance effect. Adv. Mater. 28, 2777–2781 (2016). 

16. Kondo, Y. et al. Narrowband deep-blue organic light-emitting diode featuring an organoboron-based emitter. Nat. Photonics 13, 678–682 (2019). 

17. Suresh, S. M., Hall, D., Beljonne, D., Olivier, Y. & Zysman-Colman, E. Multiresonant thermally activated delayed fluorescence emitters based on heteroatom-doped nanographenes: Recent advances and prospects for organic light-emitting diodes. Adv. Funct. Mater. 30, 1908677 (2020). 

18. Pershin, A. et al. Highly emissive excitons with reduced exchange energy in thermally activated delayed fluorescent molecules. Nat. Commun. 10, 597 (2019). 

19. Zhang, Y. et al. Multi-resonance induced thermally activated delayed fluorophores for narrowband green OLEDs. Angew. Chem. Int. Ed. 58, 16912–16917 (2019). 

20. Xu, Y. et al. Molecular-structure and device-configuration optimizations toward highly efficient green electroluminescence with narrowband emission and high color purity. Adv. Opt. Mater. 8, 1902142 (2020). 

21. Zhang, Y. et al. Achieving pure green electroluminescence with CIEy of 0.69 and EQE of 28.2% from an aza-fused multi-resonance emitter. Angew. Chem. Int. Ed. 59, 17499–17503 (2020). 

22. Wang, Y. et al. A periphery cladding strategy to improve the performance of narrowband emitters, achieving deep-blue OLEDs with CIEy < 0.08 and external quantum efficiency approaching 20%. Org. Electron. 97, 106275 (2021). 

23. Han, S. H., Jeong, J. H., Yoo, J. W. & Lee, J. Y. Ideal blue thermally activated delayed fluorescence emission assisted by a thermally activated delayed fluorescence assistant dopant through a fast reverse intersystem crossing mediated cascade energy transfer process. J. Mater. Chem. C. 7, 3082–3089 (2019). 

24. Bae, W. K. et al. Highly efficient green-light-emitting diodes based on CdSe@ZnS quantum dots with a chemical-composition gradient. Adv. Mater. 21, 1690–1694 (2009). 

25. Kwak, J. et al. Bright and efficient full-color colloidal quantum dot light-emitting diodes using an inverted device structure. Nano Lett. 12, 2362–2366 (2012). 

26. Lee, K.-H. et al. Over 40 cd/A efficient green quantum dot electroluminescent device comprising uniquely large-sized quantum dots. ACS Nano 8, 4893–4901 (2014). 

27. Lee, M.-T. et al. Efficient green coumarin dopants for organic lightemitting devices. Org. Lett. 6, 1241–1244 (2004). 

Nature Communications |  (2022) 13:4876 

7 

Article 

https://doi.org/10.1038/s41467-022-32607-3 

28. Fukagawa, H., Oono, T., Iwasaki, Y., Hatakeyama, T. & Shimizu, T. High-efficiency ultrapure green organic light-emitting diodes. Mater. Chem. Front. 2, 704–709 (2018). 

29. Song, X., Zhang, D., Zhang, Y., Lu, Y. & Duan, L. Strategically modulating carriers and excitons for efficient and stable ultrapuregreen fluorescent OLEDs with a sterically hindered BODIPY dopant. Adv. Opt. Mater. 8, 2000483 (2020). 

30. Xu, Y. et al. Constructing charge-transfer excited states based on frontier molecular orbital engineering: Narrowband green electroluminescence with high color purity and efficiency. Angew. Chem. Int. Ed. 59, 17442–17446 (2020). 

31. Yang, M., Park, I. S. & Yasuda, T. Full-color, narrowband, and highefficiency electroluminescence from boron and carbazole embedded polycyclic heteroaromatics. J. Am. Chem. Soc. 142, 19468–19472 (2020). 

32. Deng, C., Zhang, L., Wang, D., Tsuboi, T. & Zhang, Q. Exciton- and polaron-induced reversible dipole reorientation in amorphous organic semiconductor films. Adv. Opt. Mater. 7, 1801644 (2019). 

33. Lu, T. & Chen, F. Multiwfn: A multifunctional wavefunction analyzer. J. Comput. Chem. 33, 580–592 (2012). 

34. Fortino, M. et al. On the simulation of vibrationally resolved electronic spectra of medium-size molecules: the case of styryl substituted BODIPYs. Phys. Chem. Chem. Phys. 21, 3512–3526 (2019). 

35. Uoyama, H., Goushi, K., Shizu, K., Nomura, H. & Adachi, C. Highly efficient organic light-emitting diodes from delayed fluorescence. Nature 492, 234 (2012). 

36. Wu, T.-L. et al. Diboron compound-based organic light-emitting diodes with high efficiency and reduced efficiency roll-off. Nat. Photon. 12, 235–240 (2018). 

37. Lee, K. H. & Lee, J. Y. Phosphor sensitized thermally activated delayed fluorescence organic light-emitting diodes with ideal deep blue device performances. J. Mater. Chem. C. 7, 8562–8568 (2019). 

38. Zheng, X. et al. Expanding the hole delocalization range in excited molecules for stable organic light-emitting diodes employing thermally activated delayed fluorescence. J. Mater. Chem. C. 8, 10021–10030 (2020). 

39. Baldo, M. A., Lamansky, S., Burrows, P. E., Thompson, M. E. & Forrest, S. R. Very high-efficiency green organic light-emitting devices based on electrophosphorescence. Appl. Phys. Lett. 75, 4–6 (1999). 

40. Baldo, M. A., Thompson, M. E. & Forrest, S. R. High-efficiency fluorescent organic light-emitting devices using a phosphorescent sensitizer. Nature 403, 750–753 (2000). 

41. Nguyen, T. B., Nakanotani, H., Hatakeyama, T. & Adachi, C. The role of reverse intersystem crossing using a TADF-Type acceptor molecule on the device stability of exciplex-based organic lightemitting diodes. Adv. Mater. 32, 1906614–1906620 (2020). 

42. Jeon, S.-O. et al. High-Efficiency, Long-lifetime deep-blue organic light-emitting diodes. Nat. Photonics 15, 208–215 (2021). 

43. Strohriegl, P. & Grazulevicius, J. V. Charge-transporting molecular glasses. Adv. Mater. 14, 1439–1452 (2002). 

44. Li, Q. et al. Hole-transporting material based on spirobifuorene unit with perfect amorphous and high stability for efficient OLEDs. J. Mater. Sci.: Mater. Electron. 30, 11440–11450 (2019). 

45. Bell, B. M. et al. Boron-based TADF emitters with improved OLED device efficiency roll-off and long lifetime. Dyes Pigm. 141, 83–92 (2017). 

46. Frisch, M. J. et al. Gaussian 16 Revision A.03. (Gaussian Inc. Wallingford CT, 2016). 

47. Humphrey, W., Dalke, A. & Schulten, K. VMD: Visual molecular dynamics. J. Mol. Graph. 14, 33–38 (1996). 

48. Dolomanov, O. V., Bourhis, L. J., Gildea, R. J., Howard, J. A. K. & Puschmann, H. OLEX2: a complete structure solution, refinement, and analysis program. J. Appl. Cryst. 42, 339–341 (2009). 

49. Sheldrick, G. M. Crystal structure refinement with SHELXL. Acta Cryst. C. 71, 3–8 (2015). 

### Acknowledgements 

This work was supported by the National Natural Science Foundation of China (Grant no. 51873183). 

### Author contributions 

Q.Z. initiated and supervised the project. J.L. and H.Z. designed, synthesized, and characterized the MR-TADF green emitters. J.L. performed the computational calculation, photophysical and electrochemical measurements of the MR-TADF emitters. J.L. and W.L. fabricated the OLEDs and measured the device performance. J.L. and Q.Z. contributed to the manuscript writing. T.T., C.D., D.W., T.L., and Q.Z. provided suggestions on experiments and writing manuscript. All authors discussed the progress of the research and reviewed the manuscript. 

### Competing interests 

The authors declare no competing interests. 

### Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-022-32607-3. 

Correspondence and requests for materials should be addressed to Yunhui Zhu or Qisheng Zhang. 

Peer review information Nature Communications thanks Xiaosong Cao, and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. Peer reviewer reports are available. 

##### Reprints and permission information is available at 

http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2022 

Nature Communications |  (2022) 13:4876 

8 

