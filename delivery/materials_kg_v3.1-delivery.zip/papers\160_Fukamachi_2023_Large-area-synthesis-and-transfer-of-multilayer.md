# Large-area synthesis and transfer of multilayer hexagonal boron nitride for enhanced graphene device arrays

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Electronics |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 183 |
| 作者 | Satoru Fukamachi, P. Solís-Fernández, K. Kawahara, Daichi Tanaka, T. Otake, Yung-Chang Lin, K. Suenaga, H. Ago |
| DOI | 10.1038/s41928-022-00911-x |
| 源文件 | 060_Fukamachi_2023_Large-area-synthesis-and-transfer-of-multilayer.pdf |

---
## **nature electronics** 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 

# **Large-area synthesis and transfer of multilayer hexagonal boron nitride for enhanced graphene device arrays** 

|Received: 7 February 2022<br>Accepted: 13 December 2022|**Satoru Fukamachi**<sup>**1**</sup>**, Pablo Solís-Fernández**<br> <sup>**1**</sup>**, Kenji Kawahara**<sup>**1**</sup>**, Daichi Tanaka**<sup>**2**</sup>**,**<br>**Toru Otake**<sup>**2**</sup>**, Yung-Chang Lin**<br> <sup>**3**</sup>**, Kazu Suenaga**<sup>**4**</sup>**& Hiroki Ago**<br> <sup>**1,2**</sup>|
|---|---|
|Published online: 6 February 2023<br>Check for updates|Multilayer hexagonal boron nitride (hBN) can be used to preserve the<br>intrinsic physical properties of other two-dimensional materials in|
||device structures. However, integrating the material into large-scale<br>two-dimensional heterostructures remains challenging due to the<br>difficulties in synthesizing high-quality large-area multilayer hBN and<br>combining it with other two-dimensional material layers of the same scale.<br>Here we show that centimetre-scale multilayer hBN can be synthesized<br>on iron–nickel alloy foil by chemical vapour deposition, and then used<br>as a substrate and as a surface-protecting layer in graphene field-effect<br>transistors. We also develop an integrated electrochemical transfer and<br>thermal treatment method that allows us to create high-performance<br>graphene/hBN heterostacks. Arrays of graphene field-effect transistors<br>fabricated by conventional and scalable methods show an enhancement<br>in room-temperature carrier mobility when hBN is used as an insulating<br>substrate, and a further increase—up to a value of 10,000 cm<sup>2</sup>V<sup>−1</sup>s<sup>−1</sup>—when<br>graphene is encapsulated with another hBN sheet.|



Two-dimensional (2D) materials offer a range of unique physical properties and could be used to create a variety of different electronic and photonic devices<sup>1</sup> . Since 2D materials mostly consist of surface atoms, they are highly sensitive to the underlying substrate, as well as to gas adsorbates and polymer impurities that can originate from the transfer and device fabrication process. Hexagonal boron nitride (hBN)—a 2D insulator with a bandgap of around 6 eV—has an atomically flat surface, high chemical stability and high optical transparency in the visible range<sup>2,3</sup> . Multilayer hBN has, thus, become a key material to exploit the intrinsic physical properties of various 2D materials by protecting them from structural and electrostatic perturbations caused by their surroundings<sup>4–9</sup> . 

By using thick hBN layers, high carrier mobility and superconductivity have been observed in monolayer and twisted bilayer graphene, respectively<sup>4,6</sup> . Multilayer hBN has been used in graphene field-effect 

transistors (FETs) between graphene and a SiO2 substrate, to screen the influence of SiO2 (such as surface roughness, charged impurities and dangling bonds) and realize the intrinsic high carrier mobility of monolayer graphene<sup>4,5,9</sup> . Multilayer hBN improves the optical properties of transition metal dichalcogenides and has enabled the observation of valleytronics and moiré physics<sup>8,10</sup> . In addition, hBN itself is a promising material for various applications, including ultraviolet-light emitters<sup>2</sup> , single-photon emitters<sup>11</sup> , gas barrier films<sup>12</sup> and tunnel magnetic resistance devices<sup>13</sup> . 

Graphene and transition metal dichalcogenides can be made at large scales by chemical vapour deposition (CVD) or metal–organic CVD<sup>14,15</sup> . However, the synthesis of uniform multilayer hBN at similar scales is not well established. Large-area monolayer hBN can be synthesized using CVD on transition metal foils, such as copper<sup>16–19</sup> and platinum<sup>20,21</sup> , as well as on thin films such as Cu(111) (refs.<sup>22,23</sup> ), Ni(111) 

> 1Global Innovation Center (GIC), Kyushu University, Fukuoka, Japan. 2Interdisciplinary Graduate School of Engineering Sciences, Kyushu University, Fukuoka, Japan.<sup>3</sup> Nanomaterials Research Institute, National Institute of Advanced Industrial Science and Technology (AIST), Tsukuba, Japan.<sup>4</sup> The Institute of Scientific and Industrial Research (ISIR-SANKEN), Osaka University, Osaka, Japan. e-mail: ago.hiroki.974@m.kyushu-u.ac.jp 

Nature Electronics | Volume 6 | February 2023 | 126–136 

**126** 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 

(refs.<sup>24–26</sup> ) and Ir(111) (ref.<sup>27</sup> ). However, monolayer hBN is not thick enough to effectively reduce the influences of SiO2 surfaces and gas adsorption. Though multilayer hBN films can be obtained without a metal catalyst<sup>28–33</sup> , they have low crystallinity and small grain sizes. Therefore, catalytic CVD based on the dissolution and segregation of boron and nitrogen atoms with a transition metal catalyst appears to be a more promising route for the synthesis of highly crystalline hBN<sup>34–38</sup> . However, it remains challenging to synthesize multilayer hBN with sufficient uniformity and thickness due to difficulty in controlling segregation at high temperatures<sup>39–41</sup> . Electron-beam (EB) lithography is typically used in research on graphene/hBN devices to define specific uniform areas of CVD-grown multilayer hBN that avoids wrinkles, height steps, bubbles and other inhomogeneities that can deteriorate the device performance<sup>34,39</sup> . However, this is not scalable for commercial applications, which require the uniform distribution of a large number of graphene/hBN devices over a large area. 

An additional problem for large-scale device application is the transfer process and integration of 2D materials into heterostacks. High-performance graphene devices are typically fabricated by transferring exfoliated graphene and hBN flakes using dry transfer techniques with a polymeric stamp<sup>42,43</sup> . This provides clean interfaces and precise control of the position and orientation of stacks but cannot be easily applied to large sheets of hBN and graphene. For the transfer of larger areas, wet etching<sup>37,40,41</sup> and electrochemical bubbling<sup>34,44,45</sup> are the most commonly used techniques, but there are few studies reporting the stacking of CVD-grown graphene on CVD-grown hBN and the investigation of their physical properties and device performance at large scales<sup>34,46</sup> . 

In this article, we report the CVD growth of large-area multilayer hBN and its integration with CVD-grown graphene. The hBN multilayers, which have thicknesses of around 5 nm and scales of several centimetres, are grown on an iron–nickel (Fe–Ni) alloy foil. Then, hBN is transferred to a SiO2 substrate using an electrochemical bubbling method and annealed with hydrogen gas after each transfer step. We fabricate distributed arrays of graphene FETs by transferring centimetre-scale CVD-grown graphene onto our hBN films, and the electrical performance of large numbers of devices is characterized. The graphene FETs show an increase in mobility when supported on hBN (maximum hole mobility of 7,074 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> and electron mobility of 7,284 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ) due to the screening of charge impurities from the SiO2 substrate, even though the channels were uniformly fabricated across the sample surface. This is further increased when graphene is encapsulated with a top layer of hBN (maximum hole and electron mobility of 10,219 and 9,571 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , respectively). Notably, this enhancement is observed only after the electrochemical bubbling and annealing transfer process, indicating that careful tuning of the transfer process is critical for device applications at large scales. 

### **CVD growth of uniform multilayer hBN on Fe–Ni foil** 

Large-area multilayer hBN was grown on polycrystalline Fe–Ni alloy foils with borazine (B3N3H6) feedstock (Fig. 1a). The combination of Fe and Ni can suppress the local segregation of hBN that occurs in pure Fe foil as well as the structural transformation of pure Fe at higher temperatures<sup>40,41</sup> . The use of commercial Fe–Ni foils allowed us to grow thicker hBN at large scales and reduced costs. Then, hBN was transferred to a SiO2/Si substrate by an electrochemical bubbling method (hereafter called ‘electrochemical transfer’, where hBNele refers to hBN transferred using this method) (Methods); for comparison, we also employed a wet-etching transfer method (hereafter called ‘wet transfer’ and hBNwet, respectively). 

Optical micrographs of a multilayer hBNele film transferred on SiO2 are shown in Fig. 1b,c. The film exhibits a clear optical contrast, indicating the formation of multilayer hBN (refs.<sup>40,41</sup> ). Although the Fe–Ni foil is polycrystalline and has many grain boundaries, hBN is 

generally uniform and free from very thick flakes (>30 nm), which are observed in hBN grown on Fe foils (Supplementary Fig. 1). The low-magnification image (Fig. 1b, inset) shows a 1 × 1 cm<sup>2</sup> SiO2 substrate almost fully covered with multilayer hBN. Moreover, as shown in Fig. 1d, the use of commercial Fe–Ni foils enables the large-scale synthesis of multilayer hBN at a relatively low cost. These features are important for wafer-scale integration with other 2D materials, such as graphene and transition metal dichalcogenides. 

Figure 1e,f displays the atomic force microscopy (AFM) images of the hBN surface measured after electrochemical transfer and successive H2 annealing at 300 °C for 3 h. Here hBN has a very clean and flat surface with a low surface roughness ( _R_ q) of 0.19 nm, except for a few wrinkles that were formed due to the different thermal expansion coefficients of hBN and Fe–Ni foil. The AFM height profile (Fig. 1f) indicates the presence of multilayer hBN with a thickness of ~6 nm, whereas the thickness of other areas was around 2–10 nm. We found that H2 annealing is effective in cleaning the hBN surface by removing contamination originated in the transfer process (Extended Data Fig. 1a,b). A clean graphene–hBN interface is crucial for the high performance of graphene devices, as discussed further below. For comparison, we carried out the same cleaning procedure for the wet-transferred multilayer hBNwet. As shown in Extended Data Fig. 1c,d, the same H2 annealing procedure did not completely remove the contamination, with large particles observed on the surface, mainly originating from the undissolved metal catalyst. Therefore, electrochemical transfer was more effective for hBN grown on Fe–Ni alloy foils. 

X-ray photoelectron spectroscopy (XPS) of hBNele showed the B1 _s_ and N1 _s_ peaks at 190.4 and 398.0 eV, respectively (Fig. 1g,h). From the XPS peak intensities and their sensitivity factors, a [B]:[N] ratio of 1.00:0.92 was obtained for the transferred hBNele, consistent with that expected for hBN considering the possible error of XPS (Supplementary Fig. 2)<sup>47</sup> . There was no major difference in the [B]:[N] ratio for the as-grown hBN, transferred hBN and that after H2 annealing at 300 °C (Supplementary Fig. 2), indicating that the transfer process as well as H2 annealing did not degrade the quality of multilayer hBN. X-ray diffraction was also measured for a transferred hBNele, showing a clear (002) diffraction peak that indicates the successful growth and transfer of multilayer hBN (Supplementary Fig. 3). 

The uniformity and quality of hBN were also studied by Raman spectroscopy, due to the sensitivity of the E2g phonon mode to the thickness and crystallinity of hBN. Here hBNele showed a clear and sharp E2g band, with homogeneous intensity over the surface that indicates the thickness uniformity of hBN (Fig. 1i,j). The average position of the E2g mode was 1,366.2 cm<sup>−1</sup> (Fig. 1k), close to the value expected for bulk hBN (1,366.0 cm<sup>−1</sup> ) (refs.<sup>3,48</sup> ), ensuring that hBN has sufficient thickness for use as a substrate for other 2D materials. The narrow linewidth of the E2g band (full-width at half-maximum (FWHM), FWHM(E2g)) indicates the high crystallinity of hBN (ref.<sup>49</sup> ). The distribution of FWHM(E2g) of our hBN film varies between 9.0 and 13.0 cm<sup>−1</sup> , with an average value of 9.9 cm<sup>−1</sup> (Fig. 1l). Although slightly larger than those reported for exfoliated flakes from hBN single crystal (7–8 cm<sup>−1</sup> ) (ref.<sup>49</sup> ), these values are much smaller than those observed for CVD films synthesized without a metal catalyst (25–60 cm<sup>−1</sup> ) (refs.<sup>31–33</sup> ) and smaller than those of multilayer hBN grown on Fe–Ni thin films (average value, 17–18 cm<sup>−1</sup> ) (refs.<sup>40,41</sup> ). These differences can be ascribed to the higher crystallinity and larger thickness of the present hBN. 

The high crystallinity of hBN was also confirmed by scanning transmission electron microscopy (STEM), which clearly shows the honeycomb lattice of multilayer hBN with a thickness of roughly 8 nm, as determined by the zero-loss spectrum (Fig. 1m and Extended Data Fig. 2). Selected-area electron diffraction (SAED) patterns of the multilayer hBN indicated an AA’ stacking with a sufficiently large grain size (Extended Data Fig. 3). The grain size was also determined by epitaxially growing monolayer molybdenum disulfide (MoS2) on hBN. The orientation of the grown triangular MoS2 grains reflect the lattice orientation 

Nature Electronics | Volume 6 | February 2023 | 126–136 

**127** 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 



<!-- Start of picture text -->
a b c d<br>Fe–Ni foil<br>B3N3H6<br>2 mm<br>~5 cm<br>500 µm 10 µm<br>e f g h<br>B1 s N1 s<br>20<br>5 µm<br>20<br>10 ~6 nm<br>0 0<br>2 µm 0 2 4 6 8 10 12 198 195 192 189 186 183 405 402 399 396 393 390<br>Distance (µm) Binding energy (eV) Binding energy (eV)<br>i j k l<br>1.8<br>1 200<br>1.6 5 150<br>150<br>1.4 4<br>100<br>4 1.2 3 100<br>3<br>2 1.0 2 50 50<br>1<br>5 0.8<br>5 µm 0 0<br>0.6 1,320 1,360 1,400 1,362 1,364 1,366 1,368 1,370 6 8 10 12 14 16 18<br>Raman shift (cm –1 ) E2g position (cm –1 ) FWHM(E2g) (cm –1 )<br>m n o<br>Energy (eV) Energy (eV)<br>5.5 5.0 4.5 4.0 7 6 5 4 3<br>229<br>201.5 nm<br>20<br>235<br>222 10<br>E g = 6.0 eV<br>0<br>215<br>4.5 5.0 5.5 6.0 6.5<br>Energy (eV)<br>2 nm 220 240 260 280 300 320 340 200.0 300.0 400.0 500.0 600.0<br>Wavelength (nm) Wavelength (nm)<br>~1,200 °C<br>Height (nm)<br>Intensity (arb. units) Intensity (arb. units)<br>Height (nm)<br>Counts (×10)3 Intensity Counts Counts<br>CL intensity (arb. units) Absorbance (arb. units) 2122–2) (×10 αE  eV cm<br><!-- End of picture text -->

**Fig. 1 | Synthesis and characterization of multilayer hBN. a** , CVD setup used to grow multilayer hBN on Fe–Ni alloy foil. **b** , **c** , Optical micrographs of multilayer hBNele transferred on SiO2/Si. The inset in **b** is the low-magnification image of the hBN sheet. **d** , Photograph of the large-area transferred hBN. **e** , **f** , AFM images and height profile of the transferred hBN after H2 annealing. The height profile was measured along the yellow line in **f** . **g** , **h** , High-resolution B1 _s_ ( **g** ) and N1 _s_ ( **h** ) XPS spectra. **i** , Mapping image of the Raman E2g band intensity measured for the hBN 

transferred on SiO2. **j** , Raman spectra collected at the marked positions in **i** . **k** , **l** , Distributions of the E2g band position ( **k** ) and FWHM ( **l** ). **m** , STEM image and SAED pattern (inset) taken from multilayer hBN. **n** , CL spectrum of the transferred hBN measured at 90 K. **o** , Optical absorption spectrum of hBN transferred on a quartz substrate. The inset shows the Tauc plot, indicating that the CVD-grown hBN has a bandgap of 6.0 eV. 

of the underlying hBN, allowing us to visualize the grain structure of multilayer hBN in a similar way as that previously developed for monolayer graphene<sup>50</sup> . As shown in Extended Data Fig. 4, the grain size of hBN was found to be large (>20 μm). 

Cathodoluminescence (CL) is very sensitive to the quality of hBN, that is, the crystallinity and presence of defects and impurities<sup>2,51–53</sup> . Figure 1n shows the CL spectrum of our multilayer hBN transferred 

on a doped Si substrate. The sharp peak at 215 nm, explained by the emission from free excitons, is normally observed in high-quality single-crystal hBN (refs.<sup>2,49,52,53</sup> ). The observation of this peak, which was not reported for the previous CVD-grown hBN on Ni foil<sup>54</sup> , demonstrates the high quality of our CVD hBN for use as a 2D insulating layer. Other peaks observed at higher wavelengths (222, 229 and 235 nm) are mainly attributed to the emission from bound excitons induced by the 

Nature Electronics | Volume 6 | February 2023 | 126–136 

**128** 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 



<!-- Start of picture text -->
CH4 CVD-grown graphene c<br>Multilayer hBN<br>Monolayer graphene<br>Cu(111)<br>*Optional<br>d Transfer e Transfer<br>+ +<br>a b Transfer H2 anneal H2 anneal hBN/graphene/hBNheterostack<br>B3N3H6 CVD-grown hBN Multilayer hBN + Graphene/hBNheterostack<br>H2 anneal<br>Sapphire Fe–Ni foil<br>Fe–Ni foil<br>Fe–Ni foil SiO2/Si<br>Sapphire<br><!-- End of picture text -->

**Fig. 2 | Preparation of heterostacks of graphene and multilayer hBN. a** , **b** , After CVD growth of multilayer hBN ( **a** ), it was transferred onto a SiO2 substrate followed by H2 annealing ( **b** ). **c** , **d** , Monolayer graphene grown on 

Cu(111)/sapphire was transferred on hBN/SiO2 ( **c** ) followed by H2 annealing ( **d** ). **e** , Graphene was encapsulated by transferring another multilayer hBN onto the graphene/hBN/SiO2 stack. 

stacking disorder of hBN layers<sup>49</sup> , whereas the broad peaks at ~280 and ~325 nm can be explained by impurities due to possible contamination from the B3N3H6 source and/or CVD chamber<sup>49</sup> . However, given the high sensitivity of CL to the presence of defects and impurities, it should be noted that the density of impurities is sufficiently low. To support this, no impurities were observed by XPS, except for oxygen and carbon, which are normally unavoidable due to surface adsorption and environmental effects. Optical absorption (Fig. 1o) also shows evidence of the formation of hBN. The hBN exhibited an absorption peak at 201.5 nm, being transparent in the whole visible range. The bandgap estimated from the Tauc plot (Fig. 1o, inset) is 6.0 eV, again proving the growth of hBN. 

Our comprehensive investigations using AFM, XPS, Raman, STEM and CL measurements indicate that the multilayer hBN grown on Fe–Ni alloy foils has high crystalline quality and sufficient thickness for application as an insulating substrate for other 2D materials. 

### **Large-area stacks of graphene on multilayer hBN** 

To investigate the effectiveness of CVD-grown multilayer hBN as an insulating 2D substrate, large-area graphene/hBN heterostructures were fabricated on SiO2/Si by employing a multiple transfer process. The process started with the transfer of as-grown multilayer hBN from Fe–Ni foil onto a SiO2 substrate followed by annealing in a H2–Ar mixed flow at 300 °C (Fig. 2a,b and Methods). Monolayer graphene synthesized on a Cu(111) thin film<sup>55,56</sup> was subsequently transferred onto the hBN, followed by additional annealing in H2–Ar (Fig. 2c,d). Finally, hBN/graphene/ hBN sandwiched heterostructures were fabricated by transferring an additional multilayer hBN sheet over the stack (Fig. 2e). As discussed below, the most critical steps for obtaining high-quality heterostacks are the electrochemical transfer of hBN and annealing in H2 after each step, resulting in reduced densities of impurities and bubbles at the graphene– hBN interface, thus enhancing the performance of graphene devices. 

Effects of substrate and hBN transfer process on graphene were studied by Raman spectroscopy. Figure 3 shows the typical Raman spectra of graphene transferred on SiO2 (Fig. 3a), hBNele (Fig. 3d) and hBNwet (Fig. 3g). Reflecting the high crystallinity of graphene grown on Cu(111), the Raman spectrum of graphene/SiO2 showed a negligibly small defect-related D band (~1,350 cm<sup>−1</sup> ) and an intensity ratio of 2D band to G band ( _I_ 2D/ _I_ G) higher than 2 (Fig. 3a). The linewidth of the 2D band (FWHM(2D)), which is sensitive to strain and doping<sup>5,57</sup> , ranges from 30 to 35 cm<sup>−1</sup> with an average value of 32 cm<sup>−1</sup> (Fig. 3b). The FWHM(2D) mapping showed a uniform spatial distribution (Fig. 3c), suggesting that graphene is under relatively uniform conditions. 

Graphene transferred on hBNele has an increased _I_ 2D/ _I_ G ratio, suggesting decoupling from the SiO2 surface (Fig. 3d). More importantly, the 2D band became much narrower (average, 25 cm<sup>−1</sup> ), as evident in the FWHM(2D) histogram and mapping image (Fig. 3e,f). This is an indication of a decrease in the strain and/or doping of graphene. We plotted the positions of 2D and G bands (Fig. 3j) to determine the amount of doping and strain of graphene for each sample<sup>57</sup> . Graphene directly transferred on SiO2 (grey points) suffered from p-type doping in addition to strain. In contrast, the plot for graphene on hBNele (red) mostly follows the line of strain. This indicates that our hBN, even grown by catalytic CVD, can effectively cancel the effect of charged impurities on the SiO2 surface. 

It should also be mentioned that the post-H2 annealing process substantially reduced the FWHM(2D) of graphene, especially for graphene/hBNele (Extended Data Fig. 5b). This can be explained by the enhanced coupling between graphene and hBNele that reduces the negative influences from impurities at the interfaces, such as bubbles and contaminants. Moreover, neither the transfer process nor annealing induced any damage in graphene, which maintained its high quality (evident from the magnified Raman spectra; Supplementary Fig. 4). The graphene/hBN heterostacks showed only the E2g band of hBN without any appreciable D band from graphene (Supplementary Fig. 4b,c), indicating the presence of hBN underneath the graphene and the low defect density in the transferred graphene. 

In contrast, the graphene transferred on hBNwet showed a wide distribution of FWHM(2D), as shown in the histogram and Raman mapping (Fig. 3h,i). We speculate that the previously described impurities on hBNwet (Extended Data Fig. 1d) are trapped at the interfaces of hBN with graphene and SiO2. This causes the broadening of the 2D band of graphene due to an inhomogeneous distribution of strain (Fig. 3h). Thus, the screening effect expected for multilayer hBNwet is cancelled by the presence of such impurities. The presence of impurities and wrinkles in hBNwet also deteriorate the surface morphology of monolayer graphene transferred on top, as discussed later. 

Overall, our results signify that the multilayer hBN transferred by the electrochemical method is effective to screen out the influences from the SiO2 surface and highlights the importance of the transfer process. 

### **Characterization of the graphene–hBN interface** 

The interface between graphene and hBN was investigated by measuring the cross-section of the graphene/hBNele stack on SiO2 using transmission electron microscopy (TEM). The TEM images (Fig. 4a and 

Nature Electronics | Volume 6 | February 2023 | 126–136 

**129** 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 



<!-- Start of picture text -->
a b c<br>200<br>Gr/SiO2<br>2D<br>150<br>31 cm –1 100<br>G<br>50<br>0 2 µm<br>1,500 2,000 2,500 3,000 20 25 30 35 40 45 50<br>Raman shift (cm –1 ) FWHM(2D) (cm –1 )<br>d e f<br>200<br>Electrochemical transfer 2D<br>Gr/hBN/SiO2<br>150<br>25 cm –1<br>100<br>G<br>50<br>E2g<br>2 µm<br>0<br>1,500 2,000 2,500 3,000 20 25 30 35 40 45 50<br>Raman shift (cm –1 ) FWHM(2D) (cm –1 )<br>g h i<br>200<br>Wet transfer<br>2D<br>Gr/hBN/SiO2<br>150<br>34 cm –1<br>100<br>G<br>50<br>E2g<br>2 µm<br>0<br>1,500 2,000 2,500 3,000 20 25 30 35 40 45 50<br>20 60<br>Raman shift (cm –1 ) FWHM(2D) (cm –1 )<br>FWHM(2D) (cm –1 )<br>j 2,700<br>Compressive<br>strain<br>2,690<br>p doping<br>2,680<br>Tension<br>2,670<br>2,660<br>1,575 1,580 1,585 1,590 1,595 1,600<br>G position (cm –1 )<br>Counts<br>Intensity (arb. units)<br>Counts<br>Intensity (arb. units)<br>Counts<br>Intensity (arb. units)<br>–1)2D position (cm<br><!-- End of picture text -->

**Fig. 3 | Raman spectra of graphene on different substrates. a** , Typical Raman spectrum of graphene (Gr) transferred from Cu(111)/sapphire onto SiO2 substrate. **b** , FWHM(2D) distribution of graphene on SiO2. **c** , Corresponding FWHM(2D) mapping image. **d** – **f** , Raman spectrum ( **d** ), and FWHM(2D) distribution ( **e** ) and mapping ( **f** ) of the graphene transferred on multilayer hBNele. 

**g** – **i** , Raman spectrum ( **g** ), and FWHM(2D) distribution ( **h** ) and mapping ( **i** ) of the graphene transferred on multilayer hBNwet. **j** , Raman peak positions of graphene on SiO2 (grey), hBNele (red) and hBNwet (blue). The two dashed lines represent the influences from strain (black) and doping (blue) to graphene<sup>57</sup> . 

Supplementary Fig. 5) exhibit a clear and continuous layered structure with a thickness of ~4.1 nm, supporting the high crystallinity of hBN. This crystallinity is partly due to the segregation process induced by the Fe–Ni foil. In contrast, disordered or disconnected layered structures have been reported for multilayer hBN sheets grown on Cu foil, 

Ni foil and sapphire<sup>58,59</sup> . The solubility of boron and nitrogen atoms is low in these substrates; therefore, the vapour-phase reactions could contribute to the growth of hBN multilayers with very small grains. 

Figure 4b,c shows a high-magnification TEM image of the cross-section and the corresponding contrast profile, respectively. The 

Nature Electronics | Volume 6 | February 2023 | 126–136 

**130** 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 



<!-- Start of picture text -->
a<br>a - C protective layer<br>Gr/hBN<br>SiO2 10 nm<br>b c<br>0.38 nm<br>A<br>0.33 nm<br>0.38 nm<br>11 layers 0.33 nm A B<br>of hBN<br>B 2 nm 0 1.00 2.00 3.00 4.00 5.00<br>Distance (nm)<br>d e f<br>Point 3<br>B K π* σ*<br>Point 3 Point 2<br>Point 2<br>Point 1 N K<br>Point 1 Gr (ref)<br>hBN (ref) a-C (ref)<br>5 nm<br>200 250 300 350 400 450 260 280 300 320 340<br>Energy loss (eV) Energy loss (eV)<br>Brightness (arb. units)<br>Intensity (arb. units) Intensity (arb. units)<br><!-- End of picture text -->

**Fig. 4 | TEM and STEM analyses of the graphene/hBN stack. a** , Cross-sectional TEM image of the graphene/hBNele/SiO2 sample. **b** , High-magnification image of the TEM image shown in **a** . **c** , Contrast profile along the blue line shown in **b** . A and B indicate the positions shown in **b** . **d** , Annular dark-field STEM image of the 

same sample. **e** , **f** , EELS spectra collected at the positions marked in **d** . Reference spectra of hBN (top view) ( **e** ) and graphene (top view) and a-C ( **f** ). Pink line in **f** indicates the peak position of the carbon σ* band. Black arrow indicates the presence of the σ* band in the spectrum of point 2. 

interlayer distances observed in the profile are 0.33 nm, except for the longer interlayer distance (0.38 nm) between the top and second layers of the graphene/hBN stack. This suggests that the top layer is monolayer graphene deposited on 11 layers of hBN. The longer interlayer distance observed between the top graphene and hBN can be explained by the different stacking angle and different stacked materials. 

To confirm that the observed layered structure is a graphene/ hBN stack, we further analysed the cross-section by using the annular dark-field STEM and electron energy loss spectroscopy (EELS) data (Fig. 4d–f). At point 1 (Fig. 4d, layered structure), the EELS data showed the existence of both boron and nitrogen atoms (Fig. 4e), indicating the presence of multilayer hBN. At points 2 and 3, signals from carbon were detected (Fig. 4f). For comparison, the EELS spectra of monolayer graphene (top view) and amorphous carbon (a-C) are also included (Fig. 4f). The EELS spectrum at point 2 exhibited a distinctive shoulder peak at 291 eV (black arrow), which corresponds to the carbon σ* band. This sharp σ* component indicates the presence of the _sp_<sup>2</sup> network of graphene, which cannot be observed in a-C. Previous study indicated that the EELS σ* peak is much weaker when the EB is incident parallel to the graphene sheet than when it is incident in the normal direction<sup>60</sup> . The reference spectrum of graphene (Fig. 4f, orange spectrum) was collected with the EB normal to the graphene sheet. Therefore, it is reasonable that we observed a weak σ* peak for the present cross-sectional TEM image (point 2; Fig. 4f, red spectrum). On the contrary, no sharp σ* component was observed at the top a-C protective layer (point 3; Fig. 4f, blue spectrum). Therefore, from the EELS spectra, we confirmed the presence of monolayer graphene on the top of multilayer hBN. 

### **Device fabrication and characteristics of large-area graphene–hBN heterostacks** 

One of the most important roles of multilayer hBN is as an insulating substrate for 2D materials in electronic devices, for example to enhance the carrier mobility of graphene FETs<sup>4</sup> . Therefore, to demonstrate the potential of our CVD-grown hBN at large scales, we compared the 

performance of graphene FETs fabricated on SiO2 and on multilayer hBNele. In contrast to devices reported in the previous studies, which were positioned at carefully selected areas using EB lithography<sup>34,39</sup> , we employed photolithography to make large arrays of graphene FETs for a more systematic investigation of the influence of CVD-grown hBN and to prove the scalability of our approach. The detailed device fabrication process is presented in Extended Data Fig. 6. Figure 5a displays a photograph of the device arrays, with graphene/hBN on the left side of the substrate and graphene/SiO2 on the right side, which allows a reliable comparison of the different types of device by avoiding differences that might arise when processing them on different wafers. Figure 5b shows an optical micrograph of a graphene/hBNele channel whose width and length are about 3 and 9 μm, respectively. 

Figure 5c shows the typical transfer curves of graphene FETs fabricated on bare SiO2 (grey) and on multilayer hBNwet (blue) and hBNele (red). The figure also includes the transfer curve obtained for a device with graphene encapsulated by the hBN (green). All these devices showed symmetric transfer curves with the Dirac point at around −10 to 5 V. The carrier mobility determined for each device type is summarized in Fig. 5d–g, with the cumulative curves shown in Fig. 5h. For a reliable analysis, a large number of channels (>60 channels) were measured for each device type. The carrier mobility of graphene on hBNwet was found to be generally lower than that on SiO2 substrate (Fig. 5d,e), whereas the mobility was clearly enhanced for graphene on hBNele (Fig. 5f and Extended Data Fig. 7). Extended Data Table 1 compares the maximum and average carrier mobilities. The highest electron mobility of 7,284 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> (hole mobility, 7,074 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ) was observed on a graphene/hBNele channel, whereas that of graphene on SiO2 was 5,384 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> (5,217 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ). The average mobility was also enhanced by introducing hBNele as a substrate (Extended Data Table 1). Thus, our hBN multilayers are shown to effectively increase the mobility of graphene devices at centimetre scales, whereas previous work reported a decrease in mobility with respect to SiO2 (ref.<sup>46</sup> ). 

Nature Electronics | Volume 6 | February 2023 | 126–136 

**131** 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 



<!-- Start of picture text -->
a 40 h 100<br>d<br>Gr/SiO2<br>30 n  = 131 80<br>60<br>20<br>2 µm<br>Gr/hBN Gr/SiO2 40<br>10 0 20 hBNele/Gr/hBNele<br>Height (nm) Gr/hBNele<br>20 Gr/hBNwet<br>0 e Gr/hBNwet 0 Gr/SiO2<br>40 n  = 62 2 4 6 8 10<br>2 mm 30 Hole mobility (×10 3  cm 2  V –1  s –1 )<br>b 20 2 µm i<br>10<br>10<br>0<br>f<br>2 µm Gr/hBNele<br>30 n  = 70<br>8<br>c 4 hBNele/Gr/hBNele 20<br>Gr/hBNele 2 µm<br>Gr/hBNwet 10 6<br>3 Gr/SiO2<br>0<br>g<br>hBNele/Gr/hBNele<br>4<br>30 n  = 62<br>2<br>20<br>2 µm<br>2<br>1 10<br>0<br>0 2 4 6 8 10 12 0<br>0 –20 –15 –10 –5 0 5 10<br>–20 –10 0 10 20 Hole mobility (×10 3  cm 2  V –1  s –1 )<br>Dirac point (V)<br>V g –  V Dirac (V)<br>Accumulation (%)<br>Frequency (%)<br>32–1 –1)Hole mobility (×10 V cms<br>Conductivity (mS)<br><!-- End of picture text -->

**Fig. 5 | Transport characteristics of the heterostructures of graphene and hBN. a** , Optical image of graphene FET arrays on the same substrate. The left side shows the graphene/hBNele channels, and the right side shows graphene/SiO2 channels. **b** , Optical micrograph of a graphene/hBNele device. **c** , Transfer curves of graphene on SiO2 (grey), hBNwet (blue), hBNele (red) and graphene sandwiched 

by hBNele (green). **d** – **g** , Distributions of carrier mobilities measured for Gr/ SiO2 ( **d** ), Gr/hBNwet ( **e** ), Gr/hBNele ( **f** ) and hBNele/Gr/hBNele ( **g** ). The insets show the representative AFM images of FET channels. **h** , Cumulative graph of carrier mobility. **i** , Distribution of carrier mobility plotted against the Dirac point. The colour of the data is the same as that used for **d** – **g** . 

To understand the possible reasons for the difference in carrier mobilities, some representative FET channels were examined by AFM (Fig. 5d–f, insets). The graphene on SiO2 showed a smooth surface with some low wrinkles (height of a few nanometres) (Fig. 5d, inset). The graphene/hBNwet device exhibits the presence of many small particles and of high wrinkles probably originating in hBN (Fig. 5e, inset). Therefore, the decrease in carrier mobilities of graphene on wet-transferred hBN seems to be caused by these small particles and wrinkles. 

The AFM image of graphene on hBNele exhibits wrinkles and bubbles, but the surface is much cleaner than that on hBNwet (Fig. 5e,f, inset). In most previous research, including those studying exfoliated samples, EB lithography was used to define FETs at specific areas with relatively small channel sizes<sup>34,39</sup> . Therefore, it is worth noting that the mobility of graphene here increased with hBN, even though the channels were uniformly fabricated across the sample surface employing conventional and scalable methods rather than making devices at predefined positions. Despite the presence of these wrinkles and bubbles, the carrier mobility of graphene was enhanced owing to the good insulating nature of multilayer hBN and to the efficiency of the transfer method. Post-transfer H2 annealing was also effective to increase the mobility owing to a reduction in the density of bubbles at the interface. To understand the effect of bubbles and wrinkles on mobility, the channels of graphene/hBNele devices with different 

mobilities were examined by AFM (Extended Data Fig. 8). All the devices contain wrinkles and bubbles, but their density is slightly lower in the device showing the highest mobility. Concerning the possible effect of hBN grain boundaries on the performance of devices, it is expected to be much smaller than that from wrinkles and bubbles, given that the grain sizes (>20 μm) are much larger than the size of the devices (Extended Data Fig. 4). 

The carrier mobility can be further improved by encapsulating graphene with hBNele sheets (Fig. 5g–i). The encapsulated devices showed the highest hole and electron mobilities of 10,219 and 9,571 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , respectively (Extended Data Table 1). We speculate that the dielectric screening effect of the upper graphene surface by hBN sheet and the complete encapsulation with hBN sheets further increased the carrier mobilities. 

Since the two-terminal field-effect mobility underestimates the mobility due to contact resistance, the actual mobility may be higher than the above values. As shown in Fig. 5g (inset), bubbles are agglomerated along the wrinkles after transferring the top hBNele layer, making other areas very flat. The corresponding Raman spectra showed a sharp 2D band, narrower than that of graphene/hBNele and graphene/SiO2 (Extended Data Fig. 9). Although the bubbles can be locally removed by scanning the surface with AFM tips<sup>61</sup> , this is only effective for a small area and not applicable to wafer-scale devices. Thus, further studies 

Nature Electronics | Volume 6 | February 2023 | 126–136 

**132** 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 

are necessary to establish a bubble-free transfer method for large-scale 2D wafers. In addition, a method to suppress the formation of wrinkles in the CVD-grown hBN needs to be developed. 

In Fig. 5i, the hole mobilities are plotted against the Dirac points (Extended Data Fig. 7 shows the mobilities of both holes and electrons). The coloured ellipses indicate the areas within the 95% confidence interval ( _σ_ = 2). It is apparent that the electrochemically transferred large-area hBN can greatly improve the transport properties of monolayer graphene even though multilayer hBN was grown by the CVD method. From the measurement of the devices fabricated on the same wafer (Fig. 5a), we observed the tendency of hBNele to slightly shift the Dirac point of graphene to more negative values compared with the devices on SiO2. Although the exact reason for this is not clear, it is consistent with the suppression of p-type doping by hBNele observed in the Raman measurements (Fig. 3j). On the other hand, the encapsulated device (hBNele/graphene/hBNele) shows more positive Dirac point values than graphene/hBNele devices. Since the encapsulation was performed in ambient condition, oxygen and other gases might be trapped at the hBN–graphene interface, acting as p-type dopants. 

A comparison of the carrier mobilities with those reported in previous studies are listed in Supplementary Table 1. Although some of the discussed works reported higher mobility values<sup>34,39</sup> , it should be noted that the devices in such cases were fabricated by EB lithography at selected positions. In contrast, here we fabricated large arrays of graphene FETs evenly distributed over large areas by photolithography (Fig. 5a). This is a more scalable procedure that allowed us to perform a systematic comparison of different types of device (Fig. 5c–i), including different transfer methods for hBN. Thus, we demonstrated that high carrier mobilities can be attained at centimetre scales even in the presence of wrinkles and bubbles. This indicates the suitability of large-area and uniform multilayer hBN grown on Fe–Ni foil combined with optimized transfer and annealing processes for 2D electronics. Our work demonstrates the great potential of CVD-grown hBN multilayers and sheds light on the issues that need to be addressed for future wafer-scale integrations using large-area hBN wafers. 

### **Conclusions** 

We have reported the synthesis of high-quality multilayer hBN over large areas by CVD on Fe–Ni alloy foils. The hBN multilayer was used to fabricate heterostacks with CVD-grown graphene on centimetre scales; using only conventional and scalable fabrication methods, uniformly distributed arrays of graphene/hBN FETs were fabricated and characterized. An increase in the device performance with hBN substrate was observed compared with SiO2 substrate after optimizing the transfer process and fabrication methods. In particular, the electrochemical transfer of hBN and annealing in H2 gas after each fabrication step was found to be essential for the graphene/hBN devices to perform better than on SiO2. Although the improved performance of graphene devices on hBN substrates has been previously reported, this has been typically restricted to devices fabricated at selected small areas where the quality is high (that is, that avoids wrinkles, bubbles and inhomogeneity). Here we observe increased mobilities for large arrays of devices uniformly fabricated across the hBN using scalable fabrication methods. When the graphene FETs were encapsulated with an additional top layer of hBN, they exhibited a maximum hole mobility of 10,219 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> (average, 5,477 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ) and electron mobility of 9,571 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> (average, 5,551 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ). The high carrier mobilities observed for devices distributed over large areas highlights the potential of CVD-grown hBN multilayers in the development of future 2D electronic devices. 

### **Methods** 

#### **CVD growth of multilayer hBN** 

Multilayer hBN was grown on 20-μm-thick Fe–Ni alloy foils (Super Invar, mainly composed of Fe (~64%) and Ni (32%); Nilaco). Low-pressure CVD was conducted by flowing B3N3H6 in H2 gas at ~1,200 °C and maintaining 

a constant pressure of 30 Pa. Before introducing B3N3H6 vapour, the foil was annealed in H2 flow to clean its surface as well as to remove surface oxide and organic impurities. After flowing the B3N3H6 vapour for 30 min, the sample was cooled down to 700 °C (cooling rate, 5 °C min<sup>−1</sup> ) to promote the uniform segregation of hBN, and then rapidly cooled down to room temperature. 

#### **CVD growth of monolayer graphene** 

Monolayer graphene was synthesized on an epitaxial Cu(111) thin film deposited on _c_ -plane sapphire by ambient-pressure CVD at 1,075 °C using CH4 feedstock<sup>55,56,62</sup> . This catalyst produces high-quality graphene with controlled lattice orientation and almost free from multilayers, unlike graphene grown on polycrystalline Cu foils. 

#### **Fabrication process of large-area graphene–hBN heterostacks** 

Large-area graphene/hBN heterostacks were fabricated on SiO2/Si by a multiple transfer process (Fig. 2). First, the as-grown hBN is protected by a polymethyl methacrylate (PMMA) film and electrochemically delaminated in a 1 M NaOH solution<sup>45</sup> . For comparison, hBN was also transferred by the chemical etching of Fe–Ni in FeCl3–HCl (0.2 M:2.0 M) solution. The PMMA/hBN was then transferred on a SiO2/Si substrate and PMMA was removed with hot acetone. The hBN was then annealed under a H2–Ar mixed flow (10% H2) at 300 °C for 3 h before stacking monolayer graphene. This resulted in a cleaner hBN surface by removing small nanoparticles, probably originating from the PMMA residue (Extended Data Fig. 1). The thermal decomposition temperature of PMMA is 283–327 °C, at which the mass of PMMA becomes half after 30 min of heating in a vacuum<sup>63</sup> . As H2 gas can further enhance decomposition via hydrogenation, it is likely that most of the PMMA residue can be effectively eliminated by heating under a H2 flow at 300 °C for 3 h. The as-grown graphene was then transferred onto hBN, either by electrochemical or wet-etching methods using a PMMA support layer, as we did not notice a major difference in the final quality of graphene (Supplementary Fig. 6). After removing the PMMA with acetone, the graphene/hBN stack was annealed again in H2–Ar. An additional hBN layer can be transferred to form hBN/graphene/hBN heterostacks, following the same procedure as that for the transfer of the first hBN layer. 

As indicated, hBN and graphene were separately transferred, rather than sequentially transferring graphene on as-grown hBN, and then both on SiO2. Although the latter may give a cleaner interface, the former allows a more reliable analysis of surface cleanliness, thickness and crystallinity of hBN films before the transfer of graphene, as well as allows us to perform H2 annealing after each transfer step. 

#### **Characterizations** 

Optical and AFM images were collected by Keyence VHX-7000 and Bruker Nanoscope V, respectively. Raman spectra and mappings were obtained with a Nanofinder 30 (Tokyo Instruments) using 532 nm laser excitation. XPS and CL spectra were collected using Shimadzu KRATOS NovaAXIS-165 and MP-Micro-IRP (attached to a HITACHI S4000 instrument), respectively. The CL was recorded for hBN on a doped Si substrate at 90 K. X-ray diffraction was measured with RIGAKU RINTIII using Cu Kα radiation (1.5418 Å). The optical absorption of hBN was measured with a Shimadzu UV-3600 device. The cross-sectional TEM and STEM measurements were performed using JEOL JEM-F200 (200 kV) and JEOL ARM200F Dual-X (80 kV; spot size, 0.2 nm), respectively, for a graphene/hBNele device that was cut from the silicon wafer by a focused ion beam. The surface of graphene was protected by depositing a layer of a-C before the focused ion beam. EELS was measured with Gatan Enfinium ER. The top-view STEM and TEM images were measured with JEOL Triple C #1 microscope, a JEOL2100F-based microscope equipped with double JEOL delta correctors, and a cold field-emission gun operating at 60 kV. The probe current is about 15 μA for both STEM and TEM observations. The selected-area aperture for acquiring the SAED data in the TEM mode was about 1 μm in diameter. 

Nature Electronics | Volume 6 | February 2023 | 126–136 

**133** 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 

#### **Device fabrication and measurement** 

For device measurements, hBN was transferred to half of a SiO2 substrate, followed by transferring monolayer graphene on the whole substrate (Fig. 5a). Making both graphene/hBN stack and graphene-only channels on the same SiO2 wafer allowed for a reliable comparison of the different types of device by avoiding differences that might arise when processing them on different wafers. Photolithography and O2 plasma treatments were applied to pattern the channels of the graphene layer. Then, second photolithography was performed to pattern the electrodes. The metal electrodes (Au(20 nm)/Ni(3 nm)) were deposited by EB evaporation, followed by lift-off. After introducing the device wafer to the probe station, it was annealed in a vacuum (200 °C) for 15 h before the transport measurements. The transport measurements were performed at room temperature in a vacuum (<5 × 10<sup>−4</sup> Pa) using a Keysight B1500A semiconductor device parameter analyser. Field-effect mobilities ( _μ_ FE) were calculated by the following equation for both holes and electrons: 



<!-- Start of picture text -->
L<br>, (1)<br>μ FE = ( ∂ ∂ V I d g ) WC ox V d<br><!-- End of picture text -->

where _L_ and _W_ are the channel length and width, respectively, and _V_ g and _V_ d are the gate and drain voltages, respectively. Also, _C_ ox is the dielectric capacitance (1.15 × 10<sup>−4</sup> F m<sup>−2</sup> for 300-nm-thick SiO2). 

### **Data availability** 

The data that support the findings of this study are available from the corresponding author upon reasonable request. 

### **References** 

1. Ferrari, A. C. et al. Science and technology roadmap for graphene, related two-dimensional crystals, and hybrid systems. _Nanoscale_ **7** , 4598–4810 (2015). 

2. Watanabe, K., Taniguchi, T. & Kanda, H. Direct-bandgap properties and evidence for ultraviolet lasing of hexagonal boron nitride single crystal. _Nat. Mater._ **3** , 404–409 (2004). 

3. Khan, M. H. et al. Few-atomic-layered hexagonal boron nitride: CVD growth, characterization, and applications. _Mater. Today_ **20** , 611–628 (2017). 

4. Dean, C. R. et al. Boron nitride substrates for high-quality graphene electronics. _Nat. Nanotechnol._ **5** , 722–726 (2010). 

5. Banszerus, L. et al. Ultrahigh-mobility graphene devices from chemical vapor deposition on reusable copper. _Sci. Adv._ **1** , e1500222 (2015). 

6. Cao, Y. et al. Unconventional superconductivity in magic-angle graphene superlattices. _Nature_ **556** , 43–50 (2018). 

7. Lee, G.-H. et al. Flexible and transparent MoS2 field-effect transistors on hexagonal boron nitride-graphene heterostructures. _ACS Nano_ **7** , 7931–7936 (2013). 

8. Jin, C. et al. Observation of moiré excitons in WSe2/WS2 heterostructure superlattices. _Nature_ **567** , 76–80 (2019). 

9. Gannett, W. et al. Boron nitride substrates for high mobility chemical vapor deposited graphene. _Appl. Phys. Lett._ **98** , 242105 (2011). 

10. Zhang, N. et al. Moire intralayer excitons in a MoSé 2/MoS2 heterostructure. _Nano Lett._ **18** , 7651–7657 (2018). 

11. Choi, S. et al. Engineering and localization of quantum emitters in large hexagonal boron nitride layers. _ACS Appl. Mater. Interfaces_ **8** , 29642–29648 (2016). 

12. Li, L. H. et al. Strong oxidation resistance of atomically thin boron nitride nanosheets. _ACS Nano_ **8** , 1457–1462 (2014). 

13. Piquemal-Banci, M. et al. Insulator-to-metallic spin-filtering in 2D magnetic tunnel junctions based on hexagonal boron nitride. _ACS Nano_ **12** , 4712–4718 (2018). 

14. Ago, H. et al. Catalytic growth of graphene: toward large-area single-crystalline graphene. _J. Phys. Chem. Lett._ **3** , 2228–2236 (2012). 

15. Kang, K. et al. High-mobility three-atom-thick semiconducting films with wafer-scale homogeneity. _Nature_ **520** , 656–660 (2015). 

16. Kim, K. K. et al. Synthesis of monolayer hexagonal boron nitride on Cu foil using chemical vapor deposition. _Nano Lett._ **12** , 161–166 (2012). 

17. Stehle, Y. et al. Synthesis of hexagonal boron nitride monolayer: control of nucleation and crystal morphology. _Chem. Mater._ **27** , 8041–8047 (2015). 

18. Wang, S. et al. Catalyst-selective growth of single-orientation hexagonal boron nitride toward high-performance atomically thin electric barriers. _Adv. Mater._ **31** , 1900880 (2019). 

19. Wang, L. et al. Epitaxial growth of a 100-square-centimetre single-crystal hexagonal boron nitride monolayer on copper. _Nature_ **570** , 91–95 (2019). 

20. Kim, G. et al. Growth of high-crystalline, single-layer hexagonal boron nitride on recyclable platinum foil. _Nano Lett._ **13** , 1834–1839 (2013). 

21. Gao, Y. et al. Repeated and controlled growth of monolayer, bilayer and few-layer hexagonal boron nitride on Pt foils. _ACS Nano_ **7** , 5199–5206 (2013). 

22. Uchida, Y. et al. Epitaxial chemical vapour deposition growth of monolayer hexagonal boron nitride on a Cu(111)/sapphire substrate. _Phys. Chem. Chem. Phys._ **19** , 8230–8235 (2017). 

23. Chen, T.-A. et al. Wafer-scale single-crystal hexagonal boron nitride monolayers on Cu (111). _Nature_ **579** , 219–223 (2020). 

24. Taslim, A. B. et al. Synthesis of sub-millimeter single-crystal grains of aligned hexagonal boron nitride on an epitaxial Ni film. _Nanoscale_ **11** , 14668–14675 (2019). 

25. Oh, H. et al. Centimeter-sized epitaxial h-BN films. _NPG Asia Mater._ **8** , e330 (2016). 

26. Meng, J. et al. Aligned growth of millimeter-size hexagonal boron nitride single-crystal domains on epitaxial nickel thin film. _Small_ **13** , 1604179 (2017). 

27. Orlando, F. et al. Epitaxial growth of a single-domain hexagonal boron nitride monolayer. _ACS Nano_ **8** , 12063–12070 (2014). 

28. Gao, M. et al. Catalyst-free growth of two-dimensional hexagonal boron nitride few-layers on sapphire for deep ultraviolet photodetectors. _J. Mater. Chem. C_ **7** , 14999–15006 (2019). 

29. Liu, D. et al. Conformal hexagonal-boron nitride dielectric interface for tungsten diselenide devices with improved mobility and thermal dissipation. _Nat. Commun._ **10** , 1188 (2019). 

30. Behura, S. et al. Chemical interaction-guided, metal-free growth of large-area hexagonal boron nitride on silicon-based substrates. _ACS Nano_ **11** , 4985–4994 (2017). 

31. Jang, A.-R. et al. Wafer-scale and wrinkle-free epitaxial growth of single-orientated multilayer hexagonal boron nitride on sapphire. _Nano Lett._ **16** , 3360–3366 (2016). 

32. Park, H. et al. Large-scale synthesis of uniform hexagonal boron nitride films by plasma-enhanced atomic layer deposition. _Sci. Rep._ **7** , 40091 (2017). 

33. Lee, J. et al. Atomic layer deposition of layered boron nitride for large-area 2D electronics. _ACS Appl. Mater. Interfaces_ **12** , 36688–36694 (2020). 

34. Kim, S. M. et al. Synthesis of large-area multilayer hexagonal boron nitride for high material performance. _Nat. Commun._ **6** , 8662 (2015). 

35. Hui, F. et al. Electrical homogeneity of large-area chemical vapor deposited multilayer hexagonal boron nitride sheets. _ACS Appl. Mater. Interfaces_ **9** , 39895–39900 (2017). 

Nature Electronics | Volume 6 | February 2023 | 126–136 

**134** 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 

36. Ohta, J. & Fujioka, H. Sputter synthesis of wafer-scale hexagonal boron nitride films via interface segregation. _APL Mater._ **5** , 076107 (2017). 

37. Ko, H. et al. Toward non-gas-permeable hBN film growth on smooth Fe surface. _2D Mater._ **8** , 034003 (2021). 

38. Caneva, S. et al. Controlling catalyst bulk reservoir effects for monolayer hexagonal boron nitride CVD. _Nano Lett._ **16** , 1250–1261 (2016). 

39. Shi, Z. et al. Vapor–liquid–solid growth of large-area multilayer hexagonal boron nitride on dielectric substrates. _Nat. Commun._ **11** , 849 (2020). 

40. Uchida, Y. et al. Controlled growth of large-area uniform multilayer hexagonal boron nitride as an effective 2D substrate. _ACS Nano_ **12** , 6236–6244 (2018). 

41. Uchida, Y., Kawahara, K., Fukamachi, S. & Ago, H. Chemical vapor deposition growth of uniform multilayer hexagonal boron nitride driven by structural transformation of metal thin film. _ACS Appl. Electron. Mater._ **2** , 3270–3278 (2020). 

42. Pizzocchero, F. et al. The hot pick-up technique for batch assembly of van der Waals heterostructures. _Nat. Commun._ **7** , 11894 (2016). 

43. Masubuchi, S. et al. Autonomous robotic searching and assembly of two-dimensional crystals to build van der Waals superlattices. _Nat. Commun._ **9** , 1413 (2018). 

44. Wang, Y. et al. Electrochemical delamination of CVD-grown graphene film: toward the recyclable use of copper catalyst. _ACS Nano_ **5** , 9927–9933 (2011). 

45. de la Rosa, C. J. L. et al. Frame assisted H2O electrolysis induced H2 bubbling transfer of large area graphene grown by chemical vapor deposition on Cu. _Appl. Phys. Lett._ **102** , 022101 (2013). 

46. Quellmalz, A. et al. Large-area integration of two-dimensional materials and their heterostructures by wafer bonding. _Nat. Commun._ **12** , 917 (2021). 

47. Shard, A. G. Practical guides for X-ray photoelectron spectroscopy: quantitative XPS. _J. Vac. Sci. Technol. A_ **38** , 041201 (2020). 

48. Cai, Q. et al. Raman signature and phonon dispersion of atomically thin boron nitride. _Nanoscale_ **9** , 3059–3067 (2017). 

49. Schué, L. et al. Characterization methods dedicated to nanometer-thick hBN layers. _2D Mater._ **4** , 015028 (2016). 

50. Ago, H. et al. Visualization of grain structure and boundaries of polycrystalline graphene and two-dimensional materials by epitaxial growth of transition metal dichalcogenides. _ACS Nano_ **10** , 3233–3240 (2016). 

51. Taylor, C. A. II et al. Observation of near-band-gap luminescence from boron nitride films. _Appl. Phys. Lett._ **65** , 1251 (1994). 

52. Watanabe, K., Taniguchi, T., Kuroda, T. & Kanda, H. Effects of deformation on band-edge luminescence of hexagonal boron nitride single crystals. _Appl. Phys. Lett._ **89** , 141902 (2006). 

53. Schué, L. et al. Dimensionality effects on the luminescence properties of hBN. _Nanoscale_ **8** , 6986–6993 (2016). 

54. Prevost, H. et al. Heteroepitaxial growth of _sp_<sup>2</sup> -hybridized boron nitride multilayer on nickel substrates by CVD: the key role of the substrate orientation. _2D Mater._ **7** , 045018 (2020). 

55. Hu, B. et al. Epitaxial growth of large-area single-layer graphene over Cu(111)/sapphire by atmospheric pressure CVD. _Carbon_ **50** , 57–65 (2012). 

56. Ago, H. et al. Epitaxial growth and electronic properties of large hexagonal graphene domains on Cu(111) thin film. _Appl. Phys. Express_ **6** , 075101 (2013). 

57. Lee, J. E. et al. Optical separation of mechanical strain from charge doping in graphene. _Nat. Commun._ **3** , 1024 (2012). 

58. Zhang, D. et al. Thickness-tunable growth of ultra-large, continuous and high-dielectric h-BN thin films. _J. Mater. Chem. C_ **7** , 1871–1879 (2019). 

59. Ismach, A. et al. Toward the controlled synthesis of hexagonal boron nitride films. _ACS Nano_ **6** , 6378–6385 (2012). 

60. Dravid, V. P. et al. Buckytubes and derivatives: their growth and implications for buckyball formation. _Science_ **259** , 1601–1604 (1993). 

61. Rosenberger, M. R. et al. Nano-‘squeegee’ for the creation of clean 2D material interfaces. _ACS Appl. Mater. Interfaces_ **10** , 10379– 10387 (2018). 

62. Ogawa, Y. et al. Domain structure and boundary in single-layer graphene grown on Cu(111) and Cu(100) Films. _J. Phys. Chem. Lett._ **3** , 219–226 (2012). 

63. Madorsky, S. L. _Thermal Degradation of Organic Polymers_ (Interscience Publishers, 1964). 

64. Malis, T., Cheng, S. C. & Egerton, R. F. EELS log-ratio technique for specimen-thickness measurement in the TEM. _J. Elec. Microsc. Tech._ **8** , 193–200 (1988). 

### **Acknowledgements** 

This work was supported by the JSPS Grant-in-Aid for Scientific Research on Innovative Areas (A) ‘Science of 2.5 Dimensional Materials: Paradigm Shift of Materials Science Toward Future Social Innovation’ (KAKENHI grant nos. 21H05232, 21H05233, 21H05235 and 22H05478); JSPS KAKENHI grant nos. JP18H03864 and JP19K22113; JST CREST grant nos. JPMJCR18I1 and JPMJCR20B1; and the JSPS A3 Foresight Program. Cross-sectional TEM/STEM and low-temperature CL measurements were performed at the Toray Research Center and KOBELCO Research Institute, respectively. The XPS spectra were measured by Y. Miura at the Center of Advanced Instrumental Analysis, Kyushu University. The MoS2 CVD growth was performed by M. Kuroki and Z. Ma. 

### **Author contributions** 

H.A., P.S.-F., S.F. and K.K. designed the experiments. S.F., K.K., T.O. and D.T. prepared the hBN, graphene and stacked samples and analysed them. S.F. fabricated the devices, and S.F. and P.S.-F. measured the devices. Y.-C.L. and K.S. measured a part of the STEM and TEM images. H.A., S.F., P.S.-F. and Y.-C.L. wrote the manuscript. All the authors discussed the data and results. 

### **Competing interests** 

The authors declare no competing interests. 

### **Additional information** 

**Extended data** is available for this paper at https://doi.org/10.1038/ s41928-022-00911-x. 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41928022-00911-x. 

**Correspondence and requests for materials** should be addressed to Hiroki Ago. 

**Peer review information** _Nature Electronics_ thanks Don Futaba and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at 

www.nature.com/reprints. 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Nature Electronics | Volume 6 | February 2023 | 126–136 

**135** 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in 

a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons. org/licenses/by/4.0/. 

© The Author(s) 2023 

Nature Electronics | Volume 6 | February 2023 | 126–136 

**136** 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 



**Extended Data Fig. 1 | AFM images of multilayer hBN films transferred from Fe-Ni foils. a** , hBN transferred by the electrochemical method. **b** , The same sample was annealed in H2 at 300 °C for 3 hr. **c** , hBN transferred by the wet etching method. **d** , The same sample was annealed in H2 at 300 °C for 3 hr. The wet transferred hBN showed many residues even after the annealing in H2 at 300 °C 

( **d** ), while the electrochemically transferred hBN exhibits a clean surface ( **b** ). The remaining residues in d are supposed to be originated mainly in the undissolved metal catalyst (Fe and Ni). These residues deteriorate the physical properties of monolayer graphene when transferred on this hBN sheet. The surface roughness ( _R_ q) was measured for the whole image and for the areas indicated by squares. 

Nature Electronics 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 



**Extended Data Fig. 2 | STEM and TEM analyses of CVD-grown multilayer hBN. a** , STEM image of multilayer hBN. **b** , STEM image of an edge of the hBN showing that the hBN has more than 10 layers. **c,d** . TEM images of the multilayer hBN. In **d** , the electron beam created defects on the surface of the multilayer hBN, making thinner areas. The observed triangular defects (highlighted by dashed lines in **d** ) are representative of the hBN defect structure. **e** , EELS spectrum indicating the presence of both B and N. **f** , Thickness of hBN calculated from the zero-loss 

spectrum. The thickness was calculated using the following equation, based on the log-ratio technique<sup>64</sup> . _t_ / _λ_ = ln( _Ι_ t/ _Ι_ 0) where _t_ and λ are the hBN thickness and local inelastic mean free path, respectively. _I_ t is the total number of electrons in the EELS spectrum and _I_ 0 is the number of electrons with no loss energy (the zeroloss peak). _I_ t is the sum of _I_ 0 and the intensity of the inelastic peak ( _I_ inel.). _I_ t = _I_ 0+ _I_ inel. Our EELS measurement indicates that the hBN film has a thickness of about 8 nm in the measured region. 

Nature Electronics 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 



**Extended Data Fig. 3 | Measurement of the hBN lattice orientation. a** , TEM image of one of the holes in the TEM grid used to measure SAED. This hole is mostly covered with multilayer hBN. The measured sample is same as that in Extended Data Fig. 2. The yellow circle indicates one of the areas used for the 

SAED measurement. **b-e** , SAED patterns measured at different grid holes. These diffraction patterns show that the hBN has AA’ stacking and that the alignment is consistent within a given grain. The grain size determined by the SAED is about 10 μm × 20 μm. 

Nature Electronics 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 



**Extended Data Fig. 4 | MoS2-based grain structure analysis of multilayer hBN. a** , Low magnification false-colored SEM image, highlighting the grain structure of hBN determined from the orientations of MoS2 grains. Angles indicate the relative orientations of the hBN grains. **b** , High magnification SEM images displaying triangular MoS2 grains aligned within a hBN grain. These images correspond to the areas highlighted in **a** . **c** , Raman spectrum collected at the yellow circle in a. After the transfer of CVD-grown multilayer hBN onto a SiO2 

substrate, it was subjected to the CVD growth of MoS2 grains using MoO3and sulfur<sup>50</sup> . The MoS2 triangular grains were epitaxially grown on the hBN surface so that the orientation of the MoS2 grain indicates the lattice orientation of the underlying hBN. This method, originally developed for polycrystalline monolayer graphene<sup>50</sup> , allowed us to visualize the grain structure of our multilayer hBN. 

Nature Electronics 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 



**Extended Data Fig. 5 | Influence of H2 annealing on the Raman spectra of graphene.** Monolayer graphene was transferred on SiO2 ( **a** ), hBNele ( **b** ), and hBNwet ( **c** ). The FWHM(2D) distributions are plotted before and after the H2 annealing (300 °C in H2-Ar flow for 3 hours). Insets show the Raman mappings of the FWHM(2D) for each sample. 

Nature Electronics 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 



**Extended Data Fig. 6 | Process flow of the FET fabrication and measurement.** This process flow indicates the device fabrication and measurement steps for a graphene/hBNele heterostack sample. 

Nature Electronics 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 



**Extended Data Fig. 7 | Carrier mobility distributions of graphene FETs.** The hole and electron mobilities are plotted against the Dirac point for all types of devices. 

Nature Electronics 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 



**Extended Data Fig. 8 | Transfer characteristics and corresponding AFM images of graphene/hBNele channels. a** , The channel with the highest hole and electron mobilities. **b** , The channel with the 5th highest hole mobility. 

**c** , A channel with moderate mobilities. **d** , The channel with the lowest hole mobility. The total number of measured devices was 70. The highest mobility device ( **a** ) contains less wrinkles and bubbles with uniform hBN thickness. 

Nature Electronics 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 



**Extended Data Fig. 9 | Raman analysis of the hBNele/graphene/hBNele sandwich structure. a** , Raman FWHM(2D) distributions of monolayer graphene sandwiched by hBNele films. **b** , Raman FWHM(2D) distributions measured 

after the H2-annealing process. Insets show the Raman mapping images of the FWHM(2D). The encapsulation with multilayer hBN further reduced the FWHM(2D) of the graphene/hBNele heterostack. 

Nature Electronics 

**Article** 

https://doi.org/10.1038/s41928-022-00911-x 

#### **Extended Data Table. 1 | Carrier mobilities of graphene FETs obtained in this work**<sup>***1**</sup> 



Nature Electronics 

