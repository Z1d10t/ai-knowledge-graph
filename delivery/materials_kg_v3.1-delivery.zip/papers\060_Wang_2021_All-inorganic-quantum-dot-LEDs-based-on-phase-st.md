# All-inorganic quantum dot LEDs based on phase-stabilized α-CsPbI3 perovskite.

| 字段 | 内容 |
|---|---|
| 期刊 | Angewandte Chemie |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 308 |
| 作者 | Ya‐Kun Wang, Fang-Long Yuan, Yitong Dong, Jiao Li, Andrew K. Johnston, Bin Chen, M. Saidaminov, Chun Zhou et al. |
| DOI | 10.1002/anie.202104812 |
| 源文件 | 060_Wang_2021_All-inorganic-quantum-dot-LEDs-based-on-phase-st.pdf |

---
TSpace Research Repository 

tspace.library.utoronto.ca 

# **All-inorganic quantum dot LEDs based on phase-stabilized α-CsPbI3 perovskite** 

Ya-Kun Wang, Fanglong Yuan, Yitong Dong, Jiao-Yang Li, Andrew Johnston, Bin Chen, Makhsud I. Saidaminov, Chun Zhou, Xiaopeng Zheng, Yi Hou, Koen Bertens, Hinako Ebe, Dongxin Ma, Zhengtao Deng, Shuai Yuan, Rui Chen, Laxmi Kishore Sagar, Jiakai Liu, James Fan, Peicheng Li, Xiyan Li, Yuan Gao, Man-Keung Fung, Zheng-Hong Lu, Osman M. Bakr, Liang-Sheng Liao, Edward H. Sargent 

**Version** post-print 

**Citation** Wang, Y., Yuan, F., Dong, Y., Li, J., Johnston, A., Chen, B., **(published version)** Saidaminov, M. I., Zhou, C., Zheng, X., Hou, Y., Bertens, K., Ebe, H., Ma, D., Deng, Z., Yuan, S., Chen, R., Sagar, L. K., Liu, J., Fan, J., … Sargent, E. H. (2021). All‐inorganic quantum‐dot leds based on a phase‐ stabilized α‐cspbi 3 perovskite. Angewandte Chemie International Edition, 60(29), 16164–16170. https://doi.org/10.1002/anie.202104812 

**Publisher’s Statement This is the peer reviewed version of the following article: Wang, Y., Yuan, F., Dong, Y., Li, J., Johnston, A., Chen, B., Saidaminov, M. I., Zhou, C., Zheng, X., Hou, Y., Bertens, K., Ebe, H., Ma, D., Deng, Z., Yuan, S., Chen, R., Sagar, L. K., Liu, J., Fan, J., … Sargent, E. H. (2021). All‐inorganic quantum‐dot leds based on a phase‐stabilized α‐cspbi 3 perovskite. Angewandte Chemie International Edition, 60(29), 16164–16170. https://doi.org/10.1002/anie.202104812, which has been published in final form at https://doi.org/10.1002/anie.202104812. This article may be used for non-commercial purposes in accordance with Wiley Terms and Conditions for Use of SelfArchived Versions.** 

## **How to cite TSpace items** 

**Always cite the published version** , so the author(s) will receive recognition through services that track citation counts, e.g. Scopus. If you need to cite the page number of the **author manuscript from TSpace** because you cannot access the published version, then cite the TSpace version **in addition to** the published version using the permanent URI (handle) found on the record page. 

## **This article was made openly accessible by U of T Faculty. Please tell us how this access benefits you. Your story matters.** 



**All-inorganic quantum dot LEDs based on phase-stabilized α-CsPbI3 perovskite** 

_Ya-Kun Wang1,2†, Fanglong Yuan1,3†, Yitong Dong1†, Jiao-Yang Li2†, Andrew Johnston1, Bin Chen1, Makhsud I. Saidaminov1,7, Chun Zhou1, Xiaopeng Zheng4, Yi Hou1, Koen Bertens1, Hinako Ebe1, Dongxin Ma1, Zhengtao Deng5, Shuai Yuan2, Rui Chen6, Laxmi Kishore Sagar1, Jiakai Liu4, James Fan1, Peicheng Li3, Xiyan Li1, Yuan Gao1, Man-Keung Fung2, Zheng-Hong Lu3*, Osman M. Bakr4, Liang-Sheng Liao2*, & Edward H. Sargent1*_ 

- 1 Department of Electrical and Computer Engineering, University of Toronto, 10 King’s College Road, Toronto, Ontario, M5S 3G4, Canada. 

2 Institute of Functional Nano & Soft Materials (FUNSOM), Jiangsu Key Laboratory for Carbon-Based Functional Materials & Devices, Soochow University, Suzhou, Jiangsu 215123, PR China. 

- 3 Department of Materials Science and Engineering, University of Toronto, 184 College Street, Toronto, Ontario, M5S 3G4, Canada. 

- 4 Division of Physical Sciences and Engineering, King Abdullah University of Science and Technology (KAUST), Thuwal 23955-6900, Saudi Arabia 

5College of Engineering and Applied Sciences, State Key Laboratory of Analytical Chemistry for Life Science, Nanjing University, Nanjing, Jiangsu, 210023, P. R. China. 

6Department of Electrical and Electronic Engineering, Southern University of Science and Technology, Shenzhen, Guangdong 518055, P. R. China. 

7 Present address: Department of Chemistry and Electrical & Computer Engineering, Centre for Advanced Materials and Related Technologies (CAMTEC), University of Victoria, Victoria, British Columbia, Canada (email: msaidaminov@uvic.ca) 

†These authors contributed equally to this work 

Keywords: CsPbI3 quantum dots, inorganic ligand exchange, strain engineering, pure red emission, perovskite LEDs, 

The all-inorganic nature of CsPbI3 perovskites offers an avenue to enhance stability in perovskite devices. Concerted research efforts have led to improved stability of the black phase in CsPbI3 films; however, these strategies – including strain and doping – are based on organicligand-capped perovskites, which prevent perovskites from forming the close-packed QD solids necessary to achieve high charge transport and thermal transport. Here we develop an inorganic 

ligand exchange that leads to CsPbI3 QD films that unite superior phase stability with increased thermal transport. We demonstrate that the atomic ligand exchanged QD films, once 

1 

mechanically coupled, exhibit improved phase stability, and we link this to distributing strain across the film. Further, operando measurements of the temperature of LEDs indicate that KIexchanged QD films exhibit increased thermal transport compared to controls that rely on organic ligands. The LEDs exhibit a maximum EQE of 23% with EL emission centered at 640 nm (FWHM of ~31 nm). These red LEDs provide an operating half lifetime of 10 hours (luminance of 200 cd/m<sup>2</sup> ), an operating stability that is 6x higher than that of control devices. 

Solution-processed organic-inorganic metal halide perovskites have been used in efficient solar cells<sup>1-3</sup> and LEDs<sup>4-9</sup> ; however, limited stability under operating conditions must be overcome to increase the significance of these otherwise promising materials.<sup>10</sup> Volatile A- site organic cations such as methylammonium (MA) and formamidinium (FA), and the transition from the cubic perovskite phase (α-phase) to the non-perovskite yellow phase (δphase) at room temperature,<sup>11-13</sup> contribute to limited operational stability in devices. Replacing MA and FA with an inorganic cation such as Cs has been explored, but phase stability remains an issue: in CsPbI3 the **_ty_** – defined as the shelf-life storage time after which the XRD signature of the 𝛿-phase of CsPbI3 appears – is only minutes. 

Concerted research efforts have led to strategies to stabilize the α-phase of CsPbI3 at room temperature: synthesizing nanocrystals<sup>14-15</sup> , engineering the composition of the perovskite<sup>16-17</sup> , and functionalizing the surface of perovskite thin films.<sup>18-19</sup> While nanocrystals of CsPbI3 are more stable than traditional thin films due to their higher surface energies, they nevertheless turn transparent at room temperature within one week<sup>20</sup> . 

Substituting lead (Pb<sup>2+</sup> ) with smaller-radius metal ions (strontium or manganese, for example) provides an approach to introduce strain and stabilize the 𝛼-phase of CsPbI3<sup>21-23</sup> in both solution and film. Unfortunately, doping of an ensemble leads to Poisson distribution<sup>24</sup> of the population of dopants per dot and, when QDs are cast into films, these undergo a phase 

2 

change to the 𝛿-phase within a week: the highly-doped nanocrystals in the ensemble remain in the 𝛼-phase, while the nanocrystals with low doping degrade. 

These strategies – including those utilizing alloying, doping, and strain to stabilize α- phase of CsPbI3 – have been accompanied by the use of organic ligands. The films themselves show improved stability; but device operating stability remains low, a fact we trace herein to Joule heating arising due to high thermal resistance.<sup>25-26</sup> 

Resurfacing of perovskite using inorganic ligands has been pursued via solid-state ligand exchanges; however, the aggregation of QDs during the solid-state ligand exchange produces loss of PLQY and spectral redshift<sup>27-28</sup> . Solution-phase ligand exchanges to atomic ligands have been achieved in chalcogenide QDs; however, polar solvents that are needed to dissolve inorganic ligands also dissolve ionic perovskites and destroy perovskite structure<sup>29-30</sup> . 

We reasoned that film stability and thermal transport could be simultaneously achieved if we could combine strong inter-QD interaction to distribute strain, and if simultaneously we could passivate traps: we pursued therefore the goal of using inorganic ligands to improve the dissipation of heat. We report herein an inorganic ligand exchange for perovskite QDs, one wherein a dual-solvent ligand exchange dissolves inorganic ligands and is compatible with perovskite. Films made using KI-exchanged QDs are oriented and mechanically coupled, enabling strain increase across the film: the KI-exchanged films remain in the 𝛼-phase – with no observable 𝛿-phase XRD signature – 7 times longer than do unstrained control films. 

Time-resolved PL decay (TRPL) and femtosecond transient absorption spectroscopy (TAS) reveal that the KI-exchanged CsPbI3 QD films have a lower trap density than the untreated QD films, indicating that the inorganic ligands passivate the QD surfaces. Levering the improved phase stability, increased thermal transport, and > 90% PLQY, we fabricate red light-emitting diodes (LEDs) with the KI-exchanged CsPbI3 QDs. The resulting LEDs show a 

maximum external quantum efficiency (EQE) of 23%; and low driving voltages (turn-on voltage of 2.0 V and driving voltage of 3.0 V at 1000 cd/m<sup>2</sup> ). These devices achieve an 

3 

operating half-life T50 of 10 hours at an initial luminance of 200 cd/m<sup>2</sup> : this is 6x higher than control devices that rely on organic ligands and 100-fold higher than previous record LEDs that rely on mixed halide (Br/I) perovskites<sup>31</sup> . 

We synthesized CsPbI3 QDs with manganese as the dopant and tuned the size of the quantum dots by controlling the thermodynamic equilibrium<sup>32-33</sup> (Methods). Energy dispersive X-ray (EDX) spectroscopy indicates that the doping ratio in the final dots is ~7% (Mn: Pb of 0.07:0.93) (Figure s1). The strain induced by Mn alone is insufficient to stabilize the entire QD film in the 𝛼-phase: the areas of the film composed of undoped QDs will be unstrained, and will thus transition to the 𝛿-phase (see XRD). 

With the goal of ensuring that the film remains in the optically active 𝛼-phase, we sought to produce a film exhibiting uniform strained throughout (Figure 1): we sought to increase the dot-to-dot interaction beyond that of films in which long oleate/OAm ligands space out the adjacent QDs, reasoning that this would better promote strain increase throughout the entirety of the film (Figures 1a). We also pursued oriented films to maximize interfacial interaction and strain extension (Figure 1b). We focused on inorganic ligands to maximize thermal conductivity<sup>34-35</sup> (Figures 1c and 1d). As a result, we developed a solution ligand exchange process to enable the exchange to inorganic ligands. We use a small amount of dimethylformamide (DMF) to help dissolve the iodide-based salts, and added toluene (Tol) to obtain an inorganic ligand-saturated DMF/Tol solution that is compatible with the highly ionic nature of the perovskite. We chose the KI atomic ligand to showcase the benefits of both film and device stability improvement. 

We first verify the inorganic ligand exchange strategy and study the trap density of the CsPbI3 QD films after the exchange process by collecting time-resolved PL decay and femtosecond transient absorption (fs-TA) spectra. As a result of the dynamic nature of perovskite QD surfaces, halide vacancies that are created during ligand substitution often act as traps in the final QD<sup>35</sup> (Figure 2a). The uncoordinated Pb<sup>2+</sup> (Lewis acid) traps need electron- 

4 

rich (Lewis base) agents such as SCN<sup>-</sup> , COO<sup>-</sup> and X<sup>-</sup> to coordinate with Pb<sup>2+</sup> . The inorganic KI provides I<sup>-</sup> rich conditions to passivate Pb<sup>2+</sup> traps; while the potassium counter-ion promotes mechanical coupling in light of its small radius<sup>36-38</sup> . The QD films (unless otherwise stated, the QDs discussed in the following section are ~6 nm in size) after the KI exchange exhibit a longer PL lifetime (20 ns) compared to the as-synthesized QDs (14 ns) (Figure 2b, Table s2), which is consistent with the enhanced PLQY (from 75% to 96%). We measured the PLQY of KIexchanged QD film under different excitation powers (from 0.1 mW/cm<sup>2</sup> to 40 mW/cm<sup>2</sup> ) (Figure s2) and find an 8-fold decrease of trap density of KI-exchanged films<sup>39</sup> . A strong ground state bleach (GSB) centered at 638 nm is observed for CsPbI3 QD films (Figure s3a). We tracked the change of ΔA at the GSB as a function of delay time. The KI-exchanged CsPbI3 QD films show a single-exponent decay (~10 ns), while the control film needs to be fit with a bi-exponential function, with lifetimes of 190 ps and 7 ns (Figure 2c). The fast decay and long decay components are associated with non-radiative and radiative recombination, indicating that there is a higher trap state density – thus a higher rate of non-radiative recombination – in control films. The suppressed non-radiative rate indicates that the KI ligand better passivates the QDs. The spectro-temporal fs-TA map of the KI-exchanged CsPbI3 QD films shows no observable TA bleach peak shift, indicating that the CsPbI3 QDs do not aggregate in film (Figure s3b); in contrast, the TA map of the control film exhibits a shift from 628 nm to 632 nm (Figure s3c). We fabricated hole-only and electron-only devices to investigate the trap state densities with the space charge limit current (SCLC) method (Figures 2d and 2e). Both holeonly and electron-only results show the KI-exchanged films have lower trap-filled limit voltage than the untreated control films. We compare the trap state densities of KI-exchanged and control QDs with the equation below: 



<!-- Start of picture text -->
𝑛𝑡(𝑒/ℎ) = 2𝜀𝜀0𝑉𝑇𝐹𝐿(𝑒/ℎ)/(𝑒𝑑 2 )<br><!-- End of picture text -->

5 

where 𝑛𝑡(𝑒/ℎ) is the trap state density, 𝑉𝑇𝐹𝐿(𝑒/ℎ) is the trap-filled limit voltage, 𝑑 is the distance between electrodes, 𝜀 and 𝜀0 are the vacuum permittivity and relative permittivity and 𝑒 is the elementary charge. The trap state densities of KI-exchanged devices are 1.05  10<sup>15</sup> and 1.4  10<sup>15</sup> cm<sup>-3</sup> for hole-only and electron-only devices respectively, which are each 4x lower than controls (Table s3). 

The absorption spectra and photoluminescence of films from the KI-exchanged QDs exhibit a small red-shift (~8 nm) due to interdot coupling<sup>40</sup> ; the sharp excitonic absorption peak shape is maintained (Figure s3d), suggesting that the QDs are well-protected after the exchange process. The PL emission spectra remained stable after annealing at 100<sup>o</sup> C for 3 h (Figure s3e). We investigate the potassium ion (K<sup>+</sup> ) concentration before and after KI treatment with X-ray photoelectron spectroscopy (XPS). Both exchanged and control QD films exhibit XPS peaks of Cs, Pb, I, O, C and N. XPS of exchanged QD films show K<sup>+</sup> peaks at 292.9 and 295.8 eV, while the control films are virtually featureless in this range (Figure s4). Fourier Transform Infrared Spectroscopy (FTIR) spectra of KI-exchanged QD films are virtually featureless, while untreated QD films show clear C-H and N-H absorption features at a wavenumber of 28003000 cm<sup>-1</sup> and C=O absorption at 1500-1700 cm<sup>-1</sup> (Figure s5). 

We employed transmission electron microscopy (TEM) to verify the effect of KI ligand exchange on film morphology. High-resolution TEM images show adjacent QDs with a centerto-center QD distance of ~6.2 nm (Figure 3a and Figure s6a), which is smaller than QDs employing organic ligands (8-9 nm, Figure s6b). The small interatomic distance (<2 Å) and strong quantum confinement result in a ~8 nm red-shift in the emission spectrum. SEM images show a continuous and flat film over a 500 𝜇m area (Figure s6c). 

To probe orientation in the films, we employed grazing-incidence wide-angle X-ray scattering<sup>41</sup> (GIWAXS). GIWAXS patterns obtained from as-synthesized CsPbI3 QD films indicate that the atomic planes are randomly-oriented (Figure s7). GIWAXS patterns of the KI- 

6 

treated QD films exhibit directional scattering from the (100) planes (Figure 3b). The lack of continuous rings in the pattern indicates that, in films made from fully exchanged QDs, the (001) plane lies parallel to the substrate. The directional scattering of the (001) plane along the qz direction indicates that QDs are ordered such that the (001) plane lies parallel to the substrate 42. Microscopic analysis (TEM) and long-range structural characterization (GIWAXS) taken together indicate that the KI-exchanged CsPbI3 QD films are close-packed and oriented. Oriented films after KI treatment increase the interfacial interaction and facilitate the charge transport, resulting in high luminescence and high current density when used in devices<sup>43</sup> . 

We then turned to PXRD studies in order to investigate strain<sup>44</sup> and its effects on improving film stability in a suite of CsPbI3 QD films. The manganese-doped CsPbI3 QDs show shifted peak positions compared to the undoped QDs (Figure s8a), suggesting the in-QD strain in the doped CsPbI3 QD films<sup>21,33</sup> . The PXRD peaks shift from 14.19<sup>o</sup> (manganese-doped and untreated QDs) to 14.40<sup>o</sup> in KI-exchanged CsPbI3 films (Figures 3c and 3d). To determine if the observed shift was due to cation substitution, we used KBr rather than KI in the ligand substitution of CsPbBr3 QDs. We observed no shift in the XRD pattern (Figure s8b), suggesting that K<sup>+</sup> is not incorporated into the lattice of the QDs. We investigated phase stability by examining the time evolution of the PXRD. The KI-exchanged films show none of the characteristic 𝛿-phase peaks following two months of aging (25<sup>o</sup> C and 40% humidity) (Figure 3e); the untreated QD films exhibit characteristic δ-phase peaks after one week (Figure s8c). The 𝛿-phase peaks of the control films become more intense after one month of aging, while the α-phase peaks are still observable (Figures 3f bottom). The increased stability – suppression of 𝛿-phase peaks – benefit from the strain distribution of the mechanically coupling of the ensemble of dots. 

We incorporated the KI-exchanged CsPbI3 QDs into LEDs to explore how phase stability and inorganic ligands impact device performance and stability. We use an ITO glass substrate anode, poly(3,4-ethylenedioxythiophene) : poly(styrene-sulfonate) (PEDOT:PSS) 

7 

mixed with Nafion as  hole injection layer (HIL), a poly (bis-4butylphenyl-N,Nbisphenyl)benzidine) (PolyTPD) hole transport layer (HTL), a CsPbI3 emission layer, a 1,3,5tris(N-phenylbenzimidazol-2-yl) benzene (TPBI) electron transport layer (ETL), and a LiF/Al double-layered cathode. The energy level diagram is illustrated in Figure s9. We compared the energy levels of CsPbI3 before and after KI treatment with ultraviolet photoelectron spectroscopy (UPS) (Figure s10) and optical absorption spectra. Both control and KIexchanged QD films show a valence band energy of ~ 5.5 eV, which is consistent with the literature<sup>45-46</sup> .  Luminance ( _L_ ) and current density ( _J_ ) curves as a function of voltage (V) for CsPbI3 devices are shown in Figure 4. We obtain the thickness of each layer via cross-section SEM (Figure s11). We fabricated red LEDs with EL emission centered at 640 nm (CIE of (0.69, 0.30)) to establish the effect of inorganic ligand exchange on device performance and stability (Figure 4d). The KI-exchanged LEDs exhibit a record EQE of 23%. The EQE remains at 21% when the luminance reaches 100 cd/m<sup>2</sup> : the EQE at 100 cd/m<sup>2</sup> is 1.4x higher than that of the best previously-reported red perovskite LEDs (EQE of 14.6 at 100 cd/m<sup>2</sup> ) (Figure 4b and Figure s12)<sup>31</sup> .  These LEDs also exhibit a record-low turn-on voltage (2.0 V), which is ~0.06 V higher than the optical bandgap; and they exhibit the lowest driving voltage required to reach 1000 cd/m<sup>2</sup> among all reported red perovskite LEDs – this is fully 2.5x lower than previous record devices at the same luminescence (1000 cd/m<sup>2</sup> )<sup>8,17,22-23,31,47-55</sup> (Figure 4a). We optimized the QD size to approach the Rec. 2100 and achieve EL emission of 635 nm with CIE of (070, 0.29) (Figure s13).  Control devices that used the same QDs but were exchanged with an organic ligand (phenethylamine iodide (PEAI)) exhibit a lower EQE of 16% with a maximum luminescence of 870 cd/m<sup>2</sup> ; these devices show higher efficiency roll-off at high luminescence compared to the KI-exchanged LEDs (Figures 4b and 4c). 

The KI-exchanged CsPbI3 QD LEDs have an operating half-lifetime (T50) of 10 h (L0: 200 cd/m<sup>2</sup> ) (Figure 4e). Control devices that used the same QDs but exchanged using PEAI 

8 

have a T50 of 1.6 h under the same conditions (Figure 4e). Compared to previous record-EQE red perovskite LEDs (EQE = 21.3% with a T50 of 0.08 hour)<sup>31</sup> , the devices in the present work show both a higher EQE of 23%, and a 100-fold longer T50 at a 2-fold higher luminance (Table s1). The high EQE together with the stability represent the best among red perovskite LEDs approaching pure-red emission with EL <  660 nm<sup>31,37,55</sup> . 

To seek further evidence regarding thermal transport in KI-exchanged QD films, we monitored the surface temperature variation at a fixed current density (150 mA/cm<sup>2</sup> ) fabricated with KI-exchanged and control QDs (Figures 4f-4h). We use an infrared-thermal-imagingcamera to monitor the device temperature (Figure s14). KI-exchanged QD LEDs show a maximum temperature below 60<sup>o</sup> C over a duration of 100 s, while the control devices show rapid temperature increase to 80<sup>o</sup> C (after operating for 30 seconds), and they then fail immediately after reaching this temperature (Figures 4f-4h). KI treatment also reduces the surface defects of CsPbI3 QDs, which results in less non-radiative recombination and thus lower device temperature. The better heat-dissipation of KI-exchanged QD reduces Joule heating and enables as a result better operational stability. To further increase operating stability, wellmanaged testing conditions, better encapsulation technique, more stable materials and optimized device structure should be united in the future. 

In sum, we have developed an inorganic ligand exchange for CsPbI3 perovskite quantum dots which enables improved thermal conductivity. The KI-exchanged CsPbI3 QD films show a seven-fold improved phase stability than as-synthesized QD films and over 90% photoluminescence quantum yield (PLQY). We demonstrate that KI-exchanged QD films suppress the Joule-heating-induced temperature increase and accelerated degradation, which enables the union of superior operating device stability with high efficiency in CsPbI3 QD LEDs. 

9 

## **Supporting Information** 

Supporting Information is available from the Wiley Online Library or from the author. 

## **Acknowledgements** 

This work was supported by the Ontario Research Fund Research-Excellence Program and the Natural Sciences and Engineering Research Council of Canada (NSERC grant number 21695612). M.I.S. acknowledges the support of Banting Postdoctoral Fellowship Program administered by the Government of Canada. We acknowledge financial support from Natural Science Foundation of China (Nos. 51821002, 91733301) and the Collaborative Innovation Center of Suzhou Nano Science and Technology. Y.K. Wang acknowledges the financial support of the China Scholarship Council (No. 201806920067). Z.H.L acknowledges the financial support of the National Natural Science Foundation of China (grant number 11774304). 

Received: ((will be filled in by the editorial staff)) Revised: ((will be filled in by the editorial staff)) Published online: ((will be filled in by the editorial staff)) 

References 

1. M.A. Green, A. Ho-Baillie, and H.J. Snaith. _Nat. Photonics_ , **2014** , _8_ **,** 506. 

2. H. Zhou, Q. Chen, G. Li, S. Luo, T.-b. Song, H.-S. Duan, Z. Hong, J. You, Y. Liu, and Y. Yang. _Science_ , **2014** , _345_ **,** 542-546. 

3. H. Tan, A. Jain, O. Voznyy, X. Lan, F.P. García de Arquer, J.Z. Fan, R. Quintero-Bermudez, M. Yuan, B. Zhang, Y. Zhao, F. Fan, P. Li, L.N. Quan, Y. Zhao, Z.-H. Lu, Z. Yang, S. Hoogland, and E.H. Sargent. _Science_ , **2017** , _355_ **,** 722-726. 

4. R.F. Service. _Science_ , **2019** , _364_ **,** 918-918. 

5. M. Yuan, L.N. Quan, R. Comin, G. Walters, R. Sabatini, O. Voznyy, S. Hoogland, Y. Zhao, E.M. Beauregard, P. Kanjanaboos, Z. Lu, D.H. Kim, and E.H. Sargent. _Nat. Nanotechnol_ , **2016** , _11_ **,** 872. 

6. W. Xu, Q. Hu, S. Bai, C. Bao, Y. Miao, Z. Yuan, T. Borzda, A.J. Barker, E. Tyukalova, Z. Hu, M. Kawecki, H. Wang, Z. Yan, X. Liu, X. Shi, K. Uvdal, M. Fahlman, W. Zhang, M. Duchamp, J.-M. Liu, A. Petrozza, J. Wang, L.-M. Liu, W. Huang, and F. Gao. _Nat. Photonics_ , **2019** , _13_ **,** 418-424. 

10 

7. L. Zhang, X. Yang, Q. Jiang, P. Wang, Z. Yin, X. Zhang, H. Tan, Y. Yang, M. Wei, B.R. Sutherland, E.H. Sargent, and J. You. _Nat. Commun._ , **2017** , _8_ **,** 15640. 

8. B. Han, B. Cai, Q. Shan, J. Song, J. Li, F. Zhang, J. Chen, T. Fang, Q. Ji, X. Xu, and H. Zeng. _Adv. Funct. Mater._ , **2018** , _28_ **,** 1804285. 

9. Y. Liu, J. Cui, K. Du, H. Tian, Z. He, Q. Zhou, Z. Yang, Y. Deng, D. Chen, X. Zuo, Y. Ren, L. Wang, H. Zhu, B. Zhao, D. Di, J. Wang, R.H. Friend, and Y. Jin. _Nat. Photonics_ , **2019** , _13_ **,** 760-764. 

10. Y. Yang and J. You. _Nature_ , **2017** , _544_ **,** 155-156. 

11. J.A. Christians, P.A. Miranda Herrera, and P.V. Kamat. _J. Am. Chem. Soc._ , **2015** , _137_ **,** 15301538. 

12. G.E. Eperon, S.D. Stranks, C. Menelaou, M.B. Johnston, L.M. Herz, and H.J. Snaith. _Energy Environ. Sci._ , **2014** , _7_ **,** 982-988. 

13. J. Liang, C. Wang, Y. Wang, Z. Xu, Z. Lu, Y. Ma, H. Zhu, Y. Hu, C. Xiao, X. Yi, G. Zhu, 

H. Lv, L. Ma, T. Chen, Z. Tie, Z. Jin, and J. Liu. _J. Am. Chem. Soc._ , **2016** , _138_ **,** 15829-15832. 

14. Y. Wang, X. Li, J. Song, L. Xiao, H. Zeng, and H. Sun. _Adv. Mater._ , **2015** , _27_ **,** 7101-7108. 15. A. Swarnkar, A.R. Marshall, E.M. Sanehira, B.D. Chernomordik, D.T. Moore, J.A. Christians, T. Chakrabarti, and J.M. Luther. _Science_ , **2016** , _354_ **,** 92. 

16. Z. Li, M. Yang, J.-S. Park, S.-H. Wei, J.J. Berry, and K. Zhu. _Chem. Mater._ , **2016** , _28_ **,** 284292. 

17. M. Lu, X. Zhang, X. Bai, H. Wu, X. Shen, Y. Zhang, W. Zhang, W. Zheng, H. Song, W.W. Yu, and A.L. Rogach. _ACS Energy Lett._ , **2018** , _3_ **,** 1571-1577. 

18. Z. Xiao, R.A. Kerner, L. Zhao, N.L. Tran, K.M. Lee, T.-W. Koh, G.D. Scholes, and B.P. Rand. _Nat. Photonics_ , **2017** , _11_ **,** 108. 

19. Y. Fu, T. Wu, J. Wang, J. Zhai, M.J. Shearer, Y. Zhao, R.J. Hamers, E. Kan, K. Deng, X.Y. Zhu, and S. Jin. _Nano. Lett._ , **2017** , _17_ **,** 4405-4414. 

20. W.J. Mir, A. Swarnkar, and A. Nag. _Nanoscale_ , **2019** , _11_ **,** 4278-4286. 

11 

21. X. Shen, Y. Zhang, S.V. Kershaw, T. Li, C. Wang, X. Zhang, W. Wang, D. Li, Y. Wang, M. Lu, L. Zhang, C. Sun, D. Zhao, G. Qin, X. Bai, W.W. Yu, and A.L. Rogach. _Nano. Lett._ , **2019** , _19_ **,** 1552-1559. 

22. J.-S. Yao, J. Ge, K.-H. Wang, G. Zhang, B.-S. Zhu, C. Chen, Q. Zhang, Y. Luo, S.-H. Yu, and H.-B. Yao. _J. Am. Chem. Soc._ , **2019** , _141_ **,** 2069-2079. 

23. S. Zou, Y. Liu, J. Li, C. Liu, R. Feng, F. Jiang, Y. Li, J. Song, H. Zeng, M. Hong, and X. Chen. _J. Am. Chem. Soc._ , **2017** , _139_ **,** 11443-11450. 

24. J.D. Bryan and D.R. Gamelin. _Prog. Inorg. Chem._ , **2005** , _54_ **,** 47-126. 

25. W. Lee, H. Li, A.B. Wong, D. Zhang, M. Lai, Y. Yu, Q. Kong, E. Lin, J.J. Urban, J.C. Grossman, and P. Yang. _Proc. Natl. Acad. Sci. U.S.A._ , **2017** , _114_ **,** 8693-8697. 

26. P. Tyagi, R. Srivastava, L.I. Giri, S. Tuli, and C. Lee. _Synth. Met._ , **2016** , _216_ **,** 40-50. 

27. E.M. Sanehira, A.R. Marshall, J.A. Christians, S.P. Harvey, P.N. Ciesielski, L.M. Wheeler, P. Schulz, L.Y. Lin, M.C. Beard, and J.M. Luther. _Sci. Adv._ , **2017** , _3_ **,** eaao4204. 

28. L.M. Wheeler, E.M. Sanehira, A.R. Marshall, P. Schulz, M. Suri, N.C. Anderson, J.A. Christians, D. Nordlund, D. Sokaras, T. Kroll, S.P. Harvey, J.J. Berry, L.Y. Lin, and J.M. Luther. _J. Am. Chem. Soc._ , **2018** , _140_ **,** 10504-10513. 

29. M.V. Kovalenko, M. Scheele, and D.V. Talapin. _Science_ , **2009** , _324_ **,** 1417-1420. 

30. M.A. Boles, D. Ling, T. Hyeon, and D.V. Talapin. _Nat. Mater._ , **2016** , _15_ **,** 141-153. 

31. T. Chiba, Y. Hayashi, H. Ebe, K. Hoshi, J. Sato, S. Sato, Y.-J. Pu, S. Ohisa, and J. Kido. _Nat. Photonics_ , **2018** , _12_ **,** 681-687. 

32. Y. Dong, T. Qiao, D. Kim, D. Parobek, D. Rossi, and D.H. Son. _Nano. Lett._ , **2018** , _18_ **,** 37163722. 

33. Q.A. Akkerman, D. Meggiolaro, Z. Dang, F. De Angelis, and L. Manna. _ACS Energy Lett._ , **2017** , _2_ **,** 2183-2186. 

12 

34. C.L. Yaws, _Chapter 9 - Thermal Conductivity of Solid – Inorganic Compounds_ , in _Transport Properties of Chemicals and Hydrocarbons_ , C.L. Yaws, Editor. 2009, William Andrew Publishing: Boston. p. 403-406. 

35. G. Latini, G. Di Nicola, and M. Pierantozzi. _Energy Procedia_ , **2014** , _45_ **,** 616-625. 

36. M. Abdi-Jalebi, Z. Andaji-Garmaroudi, S. Cacovich, C. Stavrakas, B. Philippe, J.M. Richter, M. Alsari, E.P. Booker, E.M. Hutter, A.J. Pearson, S. Lilliu, T.J. Savenije, H. Rensmo, G. Divitini, C. Ducati, R.H. Friend, and S.D. Stranks. _Nature_ , **2018** , _555_ **,** 497-501. 

37. J.-N. Yang, Y. Song, J.-S. Yao, K.-H. Wang, J.-J. Wang, B.-S. Zhu, M.-M. Yao, S.U. Rahman, Y.-F. Lan, F.-J. Fan, and H.-B. Yao. _J. Am. Chem. Soc._ , **2020** , _142_ **,** 2956-2967. 

38. F. Yang, H. Chen, R. Zhang, X. Liu, W. Zhang, J. Zhang, F. Gao, and L. Wang. _Adv. Funct. Mater._ , **2020** , _30_ **,** 1908760. 

39. S.D. Stranks, V.M. Burlakov, T. Leijtens, J.M. Ball, A. Goriely, and H.J. Snaith. _Phy. Rev. Appl._ , **2014** , _2_ **,** 034007. 

40. J.J. Choi, J. Luria, B.-R. Hyun, A.C. Bartnik, L. Sun, Y.-F. Lim, J.A. Marohn, F.W. Wise, and T. Hanrath. _Nano. Lett_ ., **2010** , _10_ , 1805-1811. 

41. M.C. Weidman, D.-M. Smilgies, and W.A. Tisdale. _Nat. Mater._ , **2016** , _15_ **,** 775. 

<mark>42. R</mark> . Quintero-Bermudez, A. Gold-Parker, A.H. Proppe, R. Munir, Z. Yang, S.O. Kelley, A. Amassian, M.F. Toney, and E.H. Sargent. _Nat. Mater._ , **2018** , _17_ **,** 900-907. 

43. N. Cho, F. Li, B. Turedi, L. Sinatra, S.P. Sarmah, M.R. Parida, M.I. Saidaminov, B. Murali, V.M. Burlakov, A. Goriely, O.F. Mohammed, T. Wu, and O.M. Bakr. _Nat. Commun._ , **2016** , _7_ **,** 13407. 

44. J. Zhao, Y. Deng, H. Wei, X. Zheng, Z. Yu, Y. Shao, J.E. Shield, and J. Huang. _Sci. Adv._ , **2017** , _3_ **,** eaao5616. 

45. V.K. Ravi, G.B. Markad, and A. Nag. _ACS Energy Lett._ , **2016** , _1_ **,** 665-671. 

13 

46. D. Cardenas-Morcoso, A.F. Gualdrón-Reyes, A.B. Ferreira Vitoreti, M. García-Tecedor, S.J. Yoon, M. Solis de la Fuente, I. Mora-Seró, and S. Gimenez. _J. Phys. Chem. Lett._ , **2019** , _10_ **,** 630-636. 

47. J. Song, T. Fang, J. Li, L. Xu, F. Zhang, B. Han, Q. Shan, and H. Zeng. _Adv. Mater._ , **2018** , _30_ **,** 1805409. 

48. G. Li, F.W.R. Rivarola, N.J.L.K. Davis, S. Bai, T.C. Jellicoe, F. de la Peña, S. Hou, C. Ducati, F. Gao, R.H. Friend, N.C. Greenham, and Z.-K. Tan. _Adv. Mater._ , **2016** , _28_ **,** 3528-3534. 49. X. Zhang, C. Sun, Y. Zhang, H. Wu, C. Ji, Y. Chuai, P. Wang, S. Wen, C. Zhang, and W.W. Yu. _J. Phys. Chem. Lett._ , **2016** , _7_ **,** 4602-4610. 

50. J. Pan, Y. Shang, J. Yin, M. De Bastiani, W. Peng, I. Dursun, L. Sinatra, A.M. El-Zohry, M.N. Hedhili, A.-H. Emwas, O.F. Mohammed, Z. Ning, and O.M. Bakr. _J. Am. Chem. Soc._ , **2018** , _140_ **,** 562-565. 

51. N. Wang, L. Cheng, R. Ge, S. Zhang, Y. Miao, W. Zou, C. Yi, Y. Sun, Y. Cao, R. Yang, Y. Wei, Q. Guo, Y. Ke, M. Yu, Y. Jin, Y. Liu, Q. Ding, D. Di, L. Yang, G. Xing, H. Tian, C. Jin, F. Gao, R.H. Friend, J. Wang, and W. Huang. _Nat. Photonics_ , **2016** , _10_ **,** 699. 

52. Y. Tian, C. Zhou, M. Worku, X. Wang, Y. Ling, H. Gao, Y. Zhou, Y. Miao, J. Guan, and B. Ma. _Adv. Mater._ , **2018** , _30_ **,** 1707093. 

53. S. Zhang, C. Yi, N. Wang, Y. Sun, W. Zou, Y. Wei, Y. Cao, Y. Miao, R. Li, Y. Yin, N. Zhao, J. Wang, and W. Huang. _Adv. Mater._ , **2017** , _29_ **,** 1606600. 

54. H. Li, H. Lin, D. Ouyang, C. Yao, C. Li, J. Sun, Y. Song, Y. Wang, Y. Yan, Y. Wang, Q. Dong, and W.C.H. Choy, _Adv. Mater._ , 10.1002/adma.202008820 . 

55. Y. Hassan, J.H. Park, M.L. Crawford, A. Sadhanala, J. Lee, J.C. Sadighian, E. Mosconi, R. Shivanna, E. Radicchi, M. Jeong, C. Yang, H. Choi, S.H. Park, M.H. Song, F. De Angelis, C.Y. Wong, R.H. Friend, B.R. Lee, and H.J. Snaith, _Nature_ , **2021** , _591_ **,** 72-77. 

14 



**Figure 1** . **Formation of strained films with increased thermal transport. a.** QD films from as-synthesized dots in which long oleate/OAm ligands isolate the QDs and prevent strain extension. After aging, the QDs transition to the δ-phase. **b.** A film made of unoriented QDs in which QD coupling and thus strain extension are limited. After aging, a partial phase change happens. **c.** Oriented QD films with KI ligand in which rigid inter-QD connection facilitates strain field extension. The phase change is suppressed. **d.** Thermal conductivity of organic and inorganic ligands at 300 K. Thermal conductivity decreases with the increasing length of the organic chain and the KI used in this work has a 20-fold higher thermal-conductivity than do typical organics. 

15 



**Figure 2. Trap analysis of CsPbI3 QD films. a.** Scheme depicting the passivation role of KI during the exchange process. **b.** Time-resolved PL decay spectra of CsPbI3 QD films before and after the exchange process. **c.** Bandedge bleach recovery dynamics of CsPbI3 QD films before and after the exchange process. **d,e.** Current density-voltage curves of the hole-only (d) and electron-only (e) device under dark conditions. Inset shows the scheme of the device structure. 

16 



**Figure 3. Structural, morphological and strain characterization of CsPbI3 perovskite QD films. a.** High-resolution TEM image of CsPbI3 QDs after KI ligand exchange. **b.** GIWAXS pattern of CsPbI3 film after KI ligand exchange. **c.** PXRD comparison of the control film, and KI-exchanged film. **d.** Magnified PXRD pattern from 12 to 16 degrees. **e, f** . PXRD pattern of KI-exchanged film and oleate/OAm ligand film after being stored in room ambient conditions (the red circles highlight the peaks corresponding to the δ-phase) 

17 



**Figure 4| Red LEDs based on perovskite QD solids. a, b, c.** J-V-L and EQE-L curves of red LED devices. **d** . Electroluminescence (EL) spectra of KI-exchanged and control CsPbI3 QD LEDs. **e** . Operating stability of KI-exchanged and control QD LEDs. **f, g** . Temperature-time curves of KI-exchanged and control QD devices at a fixed current density of 150 mA/cm<sup>2</sup> . h. Infrared-thermal-imaging pictures of KI-exchanged and control QD devices at their highest temperature. 

18 

**Stable and efficient CsPbI3 perovskite light-emitting diodes (PLEDs)** are demonstrated by resurfacing perovskite with tha aid of inorganic ligands (KI). The resurfaced perovskites show 7x higher phase stability and higher thermal conductivity than in films with organic ligands. The PLEDs exhibit a record EQE of ~23% and 100-fold improvement operating stability compared to previous record-EQE devices. 

## **Perovskite light-emitting diodes** 

_Ya-Kun Wang, Fanglong Yuan, Yitong Dong, Jiao-Yang Li, Andrew Johnston, Bin Chen, Makhsud I. Saidaminov, Chun Zhou, Xiaopeng Zheng, Yi Hou, Koen Bertens, Hinako Ebe, Dongxin Ma, Zhengtao Deng, Shuai Yuan, Rui Chen, Laxmi Kishore Sagar, Jiakai Liu, James Fan, Peicheng Li, Xiyan Li, Yuan Gao, Man-Keung Fung, Zheng-Hong Lu*, Osman M. Bakr, Liang-Sheng Liao*, & Edward H. Sargent*_ 

**All-inorganic quantum dot LEDs based on phase-stabilized α-CsPbI3 perovskite** 



19 

