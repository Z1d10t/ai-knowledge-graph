# Flexible perovskite solar cells with simultaneously improved efficiency, operational stability, and mechanical reliability

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Joule |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 185 |
| 作者 | Qingshun Dong, Min Chen, Yuhang Liu, F. Eickemeyer, Weidong Zhao, Zhenghong Dai, Yanfeng Yin, Chen Jiang et al. |
| DOI | 10.1016/J.JOULE.2021.04.014 |
| 源文件 | 057_Dong_2021_Flexible-perovskite-solar-cells-with-simultaneou.pdf |

---
**ll** 

### Article 

# Flexible perovskite solar cells with simultaneously improved efficiency, operational stability, and mechanical reliability 



<!-- Start of picture text -->
3D MHP Thin Film  LD/3D MHP Thin Film<br>PbI 2 3 - C BAI  (3-CBA)2PbI4<br>NH3 + NH3 + NH3 +<br>Cl Cl Cl<br>Improved Mechanical Reliability<br>Cl Cl Cl<br>3+NH 3+NH 3+NH<br><!-- End of picture text -->

Qingshun Dong, Min Chen, Yuhang Liu, ..., Michael Gra¨tzel, Nitin P. Padture, Yantao Shi 

nitin_padture@brown.edu (N.P.P.) shiyantao@dlut.edu.cn (Y.S.) 

Highlights 

Fracture mechanics provides the theoretical basis for improving mechanical reliability. 

- 3-CBAI reacts selectively with PbI2 to grow in situ LD MHP layer on the 3D MHP thin film. 

The LD/3D MHP thin film enhances the mechanical reliability of f-PSCs. 

The champion f-PSC with LD/3D MHP film shows a high PCE of 21.0%. 

High power conversion efficiency (PCE) operational stability and mechanical reliability are needed for real-world application of flexible perovskite solar cells (fPSCs). Here, we use 3-CBAI to selectively react with PbI2 on the grain boundary over the 3D metal halide perovskite (MHP) thin film to grow an LD MHP capping layer in situ, which results in f-PSCs with simultaneous improvements in PCE (21.0%), operational stability (T90 = >800 h), and bending durability (T80 = 20,000 tension-only bending cycles). 

Dong et al., Joule 5, 1587–1601 June 16, 2021 ª 2021 Elsevier Inc. https://doi.org/10.1016/j.joule.2021.04.014 



**ll** 

#### Article 

## Flexible perovskite solar cells with simultaneously improved efficiency, operational stability, and mechanical reliability 

Qingshun Dong,<sup>1,6</sup> Min Chen,<sup>2,6</sup> Yuhang Liu,<sup>3,6</sup> Felix T. Eickemeyer,<sup>3</sup> Weidong Zhao,<sup>1</sup> Zhenghong Dai,<sup>2</sup> Yanfeng Yin,<sup>4</sup> Chen Jiang,<sup>1</sup> Jiangshan Feng,<sup>5</sup> Shengye Jin,<sup>4</sup> Shengzhong (Frank) Liu,<sup>5</sup> Shaik M. Zakeeruddin,<sup>3</sup> Michael Gra¨tzel,<sup>3</sup> Nitin P. Padture,<sup>2,</sup> * and Yantao Shi<sup>1,7,</sup> * 

##### SUMMARY 

Although great progress is being made toward improving the power conversion efficiency (PCE) and the operational stability of perovskite solar cells (PSCs), little attention is being paid to their mechanical reliability, which is particularly important for flexible PSCs (f-PCSs). Here, we have grown low-dimensional (LD) metal-halide perovskite (MHP) thin capping layer over the 3D MHP light-absorber thin film in f-PSCs in situ to improve their mechanical reliability. This resulted in f-PSCs with unprecedented, simultaneous improvements in PCE (21.0%), operational stability (T90, retention of 90% of the initial PCE, >800 h), and bending durability (T80 = 20,000 tensiononly bending cycles). These synergistic virtuous effects are attributed to the LD MHP capping layer enhancing photocarriers extraction, providing protection against the environment, and ‘‘sealing’’ surface flaws on the 3D MHP thin film. The latter reduces the propensity for cracking in bending, which results in improved environmental stability and bending durability. 

##### INTRODUCTION 

The power conversion efficiency (PCE) of perovskite solar cells (PSCs) that use metalhalide perovskite (MHP) light absorbers, has skyrocketed from 3.8% in 2009, when they were first invented,<sup>1</sup> to 25.5% in 2020,<sup>2</sup> rivaling Si-based solar cells. The promise of low-cost, solution-processed PSCs with high efficiencies and their potential impact on the global renewable energy landscape, is driving the effort worldwide.<sup>3–5</sup> Another attractive feature of PSCs is that they are much more versatile than conventional photovoltaics (PVs), and the light-weight, thin-film nature of PSCs makes them uniquely suitable as flexible PVs for consumer portable-power applications such as chargers, tents, backpacks, deployable rollups, drones, etc.<sup>6–13</sup> Alternatively, one can envision taking advantage of the flexibility exclusively from a low-cost, continuous manufacturability (e.g., roll-to-roll) standpoint, where largescale flexible PSCs (f-PSCs) could then be packaged into rigid panels for utility-scale PV applications. In this context, although the small amount of toxic Pb present in the state-of-the-art MHP light absorbers in high-performance PSCs is a concern for consumer applications,<sup>14</sup> it might be less of a concern in utility-scale PVs whose physical accessibility is more tightly controlled. Currently, f-PSCs technology is hampered because of the following two main issues, which need to be addressed for f-PSCs to reach the full potential. First, given that flexible polymer substrates cannot withstand temperatures above �150<sup>�</sup> C for extended periods of time, there are severe 

##### Context & scale 

Most commercial devices, including photovoltaics (PVs), have gone through a familiar research and development trajectory—increasing performance, upscaling, improving stability, and enhancing mechanical reliability—before making it to the marketplace successfully. In this context, perovskite solar cells (PSCs) are likely to be no exception, but little attention has been paid to the critically important latter issue of mechanical reliability, which is particularly important for flexible PSCs (f-PCSs). 

Here, we use the basic principles of fracture mechanics to design a novel approach to address this very issue. We demonstrate that by using rationally chosen, in situgrown low-dimensional (LD) metal halide perovskite (MHP) thin capping layer on top of the 3D MHP film can improve PV performance and operational stability; more importantly, it can enhance the mechanical reliability and bending durability through toughening just one interface in f- PSCs. 



Joule 5, 1587–1601, June 16, 2021 ª 2021 Elsevier Inc. 1587 

**ll** 

Article 

limitations on the processing of, and materials used in, the different functional layers in f-PSCs. (The deposition of MHP thin films typically requires temperatures <150<sup>�</sup> C.<sup>15</sup> ) Second, the externally applied mechanical stresses during manufacturing and service (bending, stretching, twisting) in f-PSCs are expected to be more severe, which can result in the fracture of the MHP thin film, the other functional layers, and/or the interfaces. 

There has been steady progress in addressing the first issue by using innovative lowtemperature processes to deposit the other functional layers in f-PSCs.<sup>7–10</sup> This includes electrodes,<sup>16–19</sup> electron-transport layer (ETL),<sup>20–23</sup> and hole-transport layer (HTL).<sup>24</sup> Recently, the PCE of f-PSCs has reached �21%,<sup>25,26</sup> and the efficiency gap with the rigid PSCs can be further reduced through the development of new flexible substrates and manufacturing processes for flexible devices. Regarding the second issue, there has been some effort in mitigating the mechanical damage, and enhancing the flexibility and bending-fatigue in f-PSCs. For example, Lee et al.<sup>27</sup> used a geometrical engineering approach, where the thickness of the polymer substrate is reduced so as to shift the neutral axis during bending, thereby reducing the severity of tensile stresses experienced by the perovskite thin film. They were able to achieve highly flexible 17%-PCE f-PSCs, which can withstand up to 10,000 bending cycles.<sup>27</sup> Engineering the MHP thin film has been another approach used to enhance PCE (up to 20%), bending-fatigue resistance (up to 10,000 cycles), and stability (up to 400 h) of f-PSCs.<sup>28–32</sup> Yet another approach involves interfacial engineering,<sup>33–35</sup> where Meng et al.<sup>33</sup> were able to achieve a PCE of 19.9% in large-area (1 cm<sup>2</sup> ) f-PSCs with 85% PCE retention after 7,000 bending cycles. Although these results are impressive, the scientific explanations of the observed effects based on basic mechanics-of-materials understanding are lacking in several of these studies. 

In this context, here, we use the basic principles of fracture mechanics to design and demonstrate a novel approach to achieve high-performance f-PSCs. The rationale for this approach is as follows: simple convex bending of a f-PSC results in uniaxial tensile stress (sT) in all the layers, which is given by<sup>36</sup> : 



<!-- Start of picture text -->
Eh<br>sT = (Equation 1)<br>2R ;<br><!-- End of picture text -->

where E is Young’s modulus of the layer in question, h is the thickness of the f-PSC (about the same as the substrate thickness because all the other layers combined are negligibly thinner), and R is the bending radius. Most of the PSC layers also have some residual stresses (sR) due to the coefficient of thermal expansion (CTE) mismatch with the substrate, which are typically equi-biaxial in nature, and will superimpose on due to the bending stress.<sup>37,38</sup> Given that sR can be compressive or tensile, it will diminish or augment, respectively, the effect of sT. The net tensile stress (sA) then drives fracture in the MHP thin film within the PSC, which is arguably the most brittle (i.e., ‘‘weakest link’’).<sup>36,37</sup> The criterion for mode I fracture (e.g., in MHP thin film) is given by:<sup>39</sup> 



<!-- Start of picture text -->
f f i f f i f f i f f i  f<br>K = jsAco 0:5RKIC = pGCE; (Equation 2)<br><!-- End of picture text -->

where K is the stress intensity factor, J is a geometrical constant (�2=p **f** ), co is the size of the incipient crack (or flaw), KIC (MPa.m<sup>0.5</sup> units) fracture toughness (critical stress intensity factor) of the MHP, and GC (J.m<sup>�2</sup> units) is the toughness (critical strain-energy release rate) in terms of energy. This results in an array of parallel vertical ‘‘channel’’ cracks (approximately equi-spaced) in the MHP thin film.<sup>36,37</sup> These vertical cracks might not have an appreciable effect on the PCE per se because the calculated reduction in the active area due to such cracking is <1%.<sup>36,37</sup> 

> 1State Key Laboratory of Fine Chemicals, Department of Chemistry, School of Chemical Engineering, Dalian University of Technology, Dalian 116024, P.R. China 

2School of Engineering, Brown University, Providence, RI 02912, USA 

3Laboratory of Photonics and Interfaces (LPI), Department of Chemistry and Chemical Engineering, E<sup>´</sup> cole Polytechnique Fe´ de´ rale de Lausanne (EPFL), CH-1015 Lausanne, Switzerland 

> 4State Key Laboratory of Molecular Dynamics, Dalian Institute of Chemical Physics, Chinese Academy Sciences, Dalian 116023, P.R. China 

5Key Laboratory of Applied Surface and Colloid Chemistry, Ministry of Education, Shaanxi Key Laboratory for Advanced Energy Devices, Shaanxi Engineering Lab for Advanced Energy Technology, School of Materials Science and Engineering, Shaanxi Normal University, Xi’an 710119, P.R. China 

6These authors contributed equally 

7Lead contact *Correspondence: nitin_padture@brown.edu (N.P.P.), shiyantao@dlut.edu.cn (Y.S.) https://doi.org/10.1016/j.joule.2021.04.014 

1588 Joule 5, 1587–1601, June 16, 2021 

**ll** 

#### Article 

However, they provide vertical free surfaces for the nucleation and propagation of the more dangerous horizontal cracks at MHP/ETL or MHP/HTL interfaces, which reduce the PCE significantly.<sup>36,37</sup> All types of cracks allow easy ingress of environmental species (e.g., O2 and H2O), degrading the operational stability of the PSC. In this context, MHPs are extremely brittle, where the KIC of the prototypical 3D MHP, CH3NH3PbI3 (MAPbI3), is �0.22 MPa.m<sup>0.5</sup> for single-crystal,<sup>37</sup> and the grainboundary KIC in polycrystalline MAPbI3 thin films is as low as �0.08 MPa.m<sup>0.540</sup> (for comparison, KIC of Si is �0.7 MPa.m<sup>0.539</sup> ). Thus, in order to reduce the incidence of vertical cracking in the MHP thin film in bending, and the attendant horizontal interfacial cracking, the incipient crack size (co) in Equation 2 needs to be reduced. In the case of MHP thin films, grain-boundary grooves and facets on the top surface typically serve as incipient cracks.<sup>37</sup> To that end, here, we used an in situ-grown LD MHP capping layer on top of the 3D MHP thin film to effectively ‘‘seal’’ the surface flaws. This LD MHP capping layer not only reduces the propensity for fracture in bending but also provides protection against ingression of environmental species. The latter is particularly important in the context of f-PSCs because, unlike in the case of rigid PSCs, the flexible nature of f-PSCs makes it more difficult to achieve hermetically sealed encapsulation. In addition, the LD MHP layer enhances the photocarriers properties at the MHP/HTL interface. These synergistic virtuous effects are used here to demonstrate f-PSCs with unprecedented, simultaneous improvements in PCE (21%), operational stability (T90 >800 h), mechanical reliability, and bending durability (T80 >20,000 cycles), where T90 and T80 refer to retention of 90% and 80%, respectively, of the initial PCE. 

##### RESULTS 

###### Nanostructures of 3D and LD/3D MHP thin films 

The state-of-the-art mixed-composition MHP, (CsPbI3)0.04[(FAPbI3)0.9(MAPbBr3)0.1]0.96, (FA, formamidinium or HC(NH2)2+), optimized for high PCE and stability,41 is chosen here. An excess of 10 mol % PbI2 was added to the MHP precursor, which was deposited (spin coating) on fluorinated-tin-oxide (FTO)/glass rigid substrates by using the ‘‘solvent engineering’’ approach,<sup>42</sup> followed by thermal annealing at 100<sup>�</sup> C for 50 min. This constitutes the control 3D MHP thin film. Figures 1A and 1B are top-surface and cross-sectional scanning electron microscope (SEM) images of this 3D MHP thin film, respectively, showing uniform coverage, but it shows the presence of PbI2 (light contrast), which appears to be confined to the top surface. This is further confirmed by surface-sensitive grazing-incidence wide-angle X-ray scattering (GIWAXS), where, in Figure 1C, the shallower angle (0.1<sup>�</sup> ) pattern (right) shows higher PbI2 intensity than does 1<sup>�</sup> angle (left). From the SEM images in Figures 1A and 1B, it appears that the surface PbI2 is confined to grain boundaries and triple junctions. The LD MHP layer was deposited on the 3D MPH thin film by spin coating 3-chlorobenzylammonium iodide (3-CBAI) solution, followed by thermal annealing at 100<sup>�</sup> C for 2 min. The 3-CBAI reacts with some of the excess PbI2 on the surface in situ to result in the n = 1 type LD (Ruddlesden-Popper or R-P) MHP capping layer, where the chemical composition is (3CBA)2PbnI3n+1. This is confirmed in a control experiment, where 3D MHP thin film with no excess PbI2 results in negligible amount of LD MHP (Figure S1). The corresponding SEM images in Figures 1D and 1E, together with the GIWAXS patterns in Figure 1F, confirm the presence of the LD MHP capping layer (�55-nm thickness) on top of the 3D MHP thin film (�500 nm thickness). The LD MHP capping layer appears to be of uniform thickness in Figure 1D, and it seems to ‘‘seal’’ the 3D MHP grain boundaries. The indexed X-ray diffraction (XRD) pattern in Figure 1G shows relatively strong LD MHP reflections, as compared with those of 3D MHP, indicating strong in-plane texture, which is also seen in Figure 1F (in particular, at 0.1<sup>�</sup> angle). The XRD results indicate that the LD 

Joule 5, 1587–1601, June 16, 2021 1589 

**ll** 



<!-- Start of picture text -->
Article<br><!-- End of picture text -->



<!-- Start of picture text -->
A B PbI2 ILS L/3 3 C 1 o 0.1 0.1 o o<br>D<br>PbI2 2<br>3D-MHP<br>1<br>500 nm 250 nm PbI2 PbI2<br>0<br>-1 0 1 2 -1 0 1 2<br>D E LD-MHP F 1 o 0.1 o<br>3<br>LD-MHP 2<br>3D-MHP<br>1<br>500 nm 250 nm LD-MHP LD-MHP<br>0<br>-1 0 1 2 -1 0 1 2<br>q xy (A -1 ) q xy (A -1 )<br>G (002) H LD/3D MHP<br>3D MHP<br>FTO<br>(004) (006) (008) (0010)<br>LD/3D MHP<br>PbIPbI22 3D 3D 3D3D 3D3D FTO 3D3D<br>3D MHP<br>5 10 15 20 25 30 300 600 900<br>2θ ( o ) Wavelength (nm)<br>-1 (A) q z<br>-1 (A) q z<br>) (002)<br>stin<br>u<br>(bra. (004)<br>(006) (00 10)<br>(008)<br>ytis<br>n<br>Iten<br>(arb.units)Absorbance<br><!-- End of picture text -->

Figure 1. Characterization of as-deposited thin films on FTO/glass rigid substrates (A) Top-view SEM images of the 3D MHP thin film, with the phases marked. (B) Cross-sectional SEM images of the 3D MHP thin film, with the phases marked. (C) 2D GIWAXS patterns of the 3D MHP thin film at 1<sup>�</sup> and 0.1<sup>�</sup> scanning angles, with the PbI2 reflections marked. (D) Top-view SEM images of the LD/3D MHP thin film, with the phases marked. (E) Cross-sectional SEM images of the LD/3D MHP thin film, with the phases marked. (F) 2D GIWAXS patterns of the LD/3D MHP thin film at 1<sup>�</sup> and 0.1<sup>�</sup> scanning angles, with LD MHP reflections marked. (G) Indexed XRD patterns. 

(H) UV-vis absorption spectra of the two thin films. 

MHP capping layer has the MHP octahedra slabs aligned horizontally. The average bulk apparent grain size of the 3D MHP is estimated at �300 nm, and the average lateral grain size in the LD MHP capping layer in Figure 1D is estimated at �600 nm. The UV-vis spectra in Figure 1H show that the thin film with LD MHP capping layer has much higher absorption at lower wavelengths, which, once again, confirms the presence of the LD MHP phase. 

###### Improved mechanical reliability and environmental stability of LD/3D MHP thin films 

Figure 2 presents results from the cyclic bend testing of 3D MHP and LD/3D MHP thin films deposited on indium tin oxide (ITO)/polyethylene terephthalate (PET) flexible substrates (�185 mm thickness). This test was performed in ambient air (�70% RH, �25<sup>�</sup> C) with R = 5 mm for 2,000 tension-only cycles. Note that a cylindrical mandrel of radius (R) 5 mm was used to perform the bend testing, where the specimen is bent around the mandrel, with the MHP thin film in tension (convex). This procedure (Figure S2) ensures uniform uniaxial tensile stress in the MHP thin film given by Equation 1. In most papers in the literature the flexible specimens are bent between ‘‘fingers,’’ which results in non-uniform bending radius (with sharpest R occurring only at the apex) and an analytically indeterminate stress state (Equation 1 has limited validity in this case).<sup>36</sup> In addition, the optimum R = 5 mm was chosen because if this 

1590 Joule 5, 1587–1601, June 16, 2021 

**ll** 

#### Article 



<!-- Start of picture text -->
PbI2<br>C<br>A B<br>After Bend-Testing<br>Aged<br>As-Deposited<br>500 nm 500 nm<br>F<br>D E<br>After Bend-Testing<br>Aged<br>As-Deposited<br>500 nm 500 nm<br>12 13 14 15<br>2θ ( o )<br>(arb.units)Intensity<br>(arb.units)Intensity<br><!-- End of picture text -->

Figure 2. Characterization of thin films on ITO/PET flexible substrates (A) Top-view SEM images of the as-deposited 3D MHP thin films. (B) Top-view SEM images of 3D MHP thin films after cyclic bend testing (inset: cross-section). (C) Corresponding XRD patterns of 3D MHP thin films as-deposited, aged, and after cyclic bend testing. (D) Top-view SEM images of the as-deposited LD/3D MHP thin films. (E) Top-view SEM images of LD/3D MHP thin films after cyclic bend testing (inset: cross-section). (F) Corresponding XRD patterns of LD/3D MHP thin films as-deposited, aged, and after cyclic bend testing. Cyclic bend testing: R = 5 mm, 2,000 tension-only cycles (�200 h), in ambient air (�70% RH, �25<sup>�</sup> C). 

value is lower (sharper), the underlying ITO cracks (Figure S3), which complicates the interpretation of cracking of the MHP thin film above.<sup>36</sup> An increase in R > 5 mm (shallower) results in no cracking in the 3D MHP thin film or the ITO layer. Furthermore, it has been discovered that the very act of SEM observation of uncracked MHP thin films can result in cracking under the electron beam.<sup>36,43</sup> Thus, great care needs to be exercised during the SEM observation of MHP thin films to reduce electron-beam damage and avoid this artifact, such as using lower accelerating voltage and shorter exposure durations to the electron beam.<sup>36,43</sup> Otherwise, this artifact can result in serious misinterpretation of the cracking observed in MHP thin films, which appears to be the case in several SEM images reported in the literature. In addition, note that the tension-only cycle (flat -i convex -i flat) bending is used here (Figure S4A) because in conventional cycle (flat -i convex -i flat -i concave-i flat) bending (Figure S4B), which is what is used in most studies in the literature, the ‘‘concave’’ compression bending produces more complex effects to the MHP film, such as the ‘‘film-peeling’’ effect (small R)<sup>35</sup> or the ‘‘crack-healing’’ effect (large R),<sup>36</sup> which leads to serious misinterpretation of the results. Here, each tension-only cycle takes �1 s, but the thin films are allowed to rest for �6 min in-between cycles in air to study the effect of environment on the stability of the MHP films. Therefore, it takes �200 h to complete the 2,000-cycle tensiononly bend testing. 

Figures 2A and 2D show top-view SEM images of as-deposited 3D MHP and LD/3D MHP thin films on flexible ITO/PET substrates, where the respective microstructures look very similar to those in the case of FTO/glass rigid substrates (Figures 1A and 1D). After cyclic bend testing of the 3D MHP thin film, cracking is clearly evident in Figure 2B. Importantly, interfacial delamination is observed in the cross-sectional SEM (Figure 2B inset). In contrast, the LD/3D MHP thin film after cyclic bend testing has not cracked (Figure 2E and inset). It is presumed that such cracking will allow 

Joule 5, 1587–1601, June 16, 2021 1591 

**ll** 

Article 

easier ingression of environmental species (O2, H2O) from the air, thereby accelerating the environmental degradation of the 3D MHP thin films to PbI2. This was confirmed by using XRD, where a significant increase in the PbI2 peak (marked) was observed in the 3D MHP thin film after cyclic bend testing in Figure 2C (compared with as-deposited), which was not observed in the LD/3D MHP thin film (Figure 2F). (Note that the PbI2 peaks seen in both as-deposited MHP thin films in the XRD patterns are due to the excess PbI2.) To confirm that this degradation is associated with cracking, XRD patterns were obtained from 3D MHP (Figure 2C) and LD/3D MHP (Figure 2F) thin films that were not subjected to cyclic bend testing, but were simply aged in air for 200 h (the same duration of cyclic bend testing); little difference was observed between the aged and the as-deposited XRD patterns in both MHP thin films in Figures 2C and 2F. These results clearly demonstrate the beneficial effect of the LD MHP capping layer in improving both mechanical reliability and environmental stability of the 3D MHP thin films. 

###### Enhanced optoelectronic properties of LD/3D MHP thin films 

The surface passivation of the 3D MHP thin films by the LD MHP capping layer is expected to improve photocarriers properties. Time-resolved photoluminescence (TRPL) spectroscopy data from the LD/3D MHP thin film deposited on glass substrate in Figure 3A show a promising lifetime of 839.8 ns, compared with 502.8 ns for the corresponding 3D MHP thin film. The specific fitting parameters are summarized in Table S1. Figure 3B shows TRPL results for LD/3D MHP thin films coated with a Spiro-OMeTAD hole-quenching layer. Based on the PL decay dynamics the photocarrier diffusion coefficient of 0.3 cm<sup>2</sup> .s<sup>�1</sup> is estimated for holes, which corresponds to a diffusion length of �5.0 mm for holes, which is about 10 times the thickness of the MHP thin film. 

The valence band maxima (VBM) of LD/3D and 3D MHP thin films were determined using ultraviolet photoemission spectroscopy (UPS), results from which are presented in Figure 3C. The VBM (�5.23 eV) of the LD/3D MHP thin film is closer to the reported highest occupied molecular orbital (HOMO) level (�5.0 eV) of SpiroOMeTAD, as compared with that of the 3D MHP thin film VBM (�5.36 eV). 

Absolute-intensity PL measurements were performed on 3D and LD/3D MHP thin films (on ITO/PET substrates), as-deposited and after cyclic bend testing (R = 5 mm, 2,000 tension-only cycles, in air). The results presented in Figure 3D show that PL of the as-deposited LD/3D MHP thin film is significantly higher than that of the 3D MHP thin film, which can be attributed to the passivation of surface defects by the LP MHP capping layer, and the attendant reduced photocarrier-recombination rate. After cyclic bend testing there was a marginal reduction in PL intensity of LD/3D MHP thin film but a significant reduction in the 3D MHP thin film. The latter is attributed to the mechanical and environmental degradation of the MHP and the interface, consistent with the results presented in Figures 2B and 2C. These results clearly demonstrate the beneficial effect of the LD MHP capping layer in enhancing the optoelectronic properties of the 3D MHP thin films. 

###### Improved performance of f-PSCs incorporating LD/3D MHP thin films 

LD/3D and 3D (control) MHP thin films were incorporated in f-PSCs and their PV characteristics were evaluated. The architecture of the n-i-p f-PSCs is shown in Figure 4B inset, where the MHP thin film (�500–600 nm thickness) is sandwiched between SnO2 ETL and Spiro-OMeTAD HTL. ITO (on PET substrate) and Au were used as conducting electrodes on either side. Figure 4A plots the current density (J)-voltage (V) response of the ‘‘champion’’ LD/3D and control MHP-based f-PSCs (0.096 cm<sup>2</sup> active 

1592 Joule 5, 1587–1601, June 16, 2021 

**ll** 

#### Article 



<!-- Start of picture text -->
A B<br>1 1<br>LD/3D MHP<br>Spiro-OMeTAD/<br>0.1 0.1 LD/3D MHP<br>3D MHP<br>Spiro-OMeTAD/<br>3D MHP<br>0.01 0.01<br>0 500 1000 0 50 100<br>Time (ns) Time (ns)<br>C D<br>Before<br>After<br>6<br>LD/3D<br>MHP LD/3D MHP<br>Before<br>After<br>16.67<br>3<br>3D MHP 0.68<br>0.73 3D MHP<br>16.59<br>0<br>18 12 6 0 700 800 900<br>Binding Energy (eV) Wavelength (nm)<br>ytis<br>n<br>Iten<br>d<br>e<br>zila<br>mro<br>N Normalized Intensity<br>)stin<br>u<br>(bra.<br>ytis<br>n<br>Iten Spectral Photon Flux 17-1-2-1)(x10∙nms∙m<br><!-- End of picture text -->

Figure 3. Optoelectronic properties of 3D and LD/3D MHP thin films (A) Normalized PL decay of as-deposited 3D and LD/3D MHP thin films. (B) Normalized PL decay of as-deposited 3D and LD/3D MHP thin films with Spiro-OMeTAD holequenching layer. 

(C) UPS spectra of 3D and LD/3D MHP thin films. 

(D) Absolute-intensity PL measurements using an excitation laser photon flux similar to 1-sun illumination (1.7 3 10<sup>21</sup> s<sup>�1</sup> .m<sup>2</sup> ) of 3D and LD/3D MHP thin films,: as-deposited and after cyclic bend testing (R = 5 mm, 2,000 tension-only cycles [�200 h], in air). 

area, AM 1.5G 1-sun illumination) in reverse and forward scans. The LD/3D MPHbased f-PSC showing negligible hysteresis, and in reverse J-V scan direction, short-circuit current density (JSC) is 23.5 mA.cm<sup>�2</sup> , open-circuit voltage (VOC) is 1.15 V, fill factor (FF) is 0.779, and PCE is an unprecedented 21.0%. This JSC value compares favorably with the integrated JSC of 22.1 mA.cm<sup>�2</sup> estimated from the external quantum efficiency (EQE) spectrum in Figure 4C. A steady PCE output of 20.6% was obtained at the maximum power point (MPP; V = 0.987 V), as shown in Figure 4B, which is very close to the extracted PCEs from J-V curves, attesting to the negligible hysteresis in this f-PSC. The evaluation of PV performance (Figure 4D) of 25 f-PSC devices shows tight reproducibility, with an average PCE of 19.9% G 0.6%. Control f-PSCs incorporating 3D MHP thin films without the LD MHP capping layer were also fabricated. The ‘‘champion’’ control f-PSC has PCE of 18.4% in reverse J-V scan direction (JSC is 23.1 mA.cm<sup>�2</sup> , VOC is 1.12 V, and FF is 0.720), integrated JSC of 21.6 mA.cm<sup>�2</sup> and steady PCE output of 18.1% (Figures 4A–4C). The average PCE measured of 25 control f-PSCs is 16.7% G 1.2% (Figure 4D). These results clearly demonstrate the beneficial effect of the LD MHP capping layer in improving the PV performance of f-PSCs. 

Rigid PSCs on FTO/glass substrates were also fabricated, where the ‘‘champion’’ PSC has (in reverse J-V scan direction) JSC of 24.3 mA cm<sup>�2</sup> , VOC of 1.18 V, FF of 0.785, and PCE of 22.5% (Figure S5). Typically, rigid PSCs do show superior PV performance compared with their flexible counterparts, which is attributed to better light transmission in the glass and the higher quality of the FTO electrode. 

Joule 5, 1587–1601, June 16, 2021 1593 

**ll** 

Article 



<!-- Start of picture text -->
A B<br>C D<br><!-- End of picture text -->

Figure 4. Performance of f-PSCs incorporating LD/3D and 3D MHP thin films (A) J-V responses of ‘‘champion’’ LD/3D and 3D MHP-based f-PSCs in forward (F, JSC / VOC) and reverse (R, VOC / JSC) scans. Inset: PV performance parameters. (B) Stability of PCE in the ‘‘champion’’ f-PSCs at maximum power point. Inset: schematic illustration of n-i-p f-PSC architecture (not to scale). (C) EQE and integrated JSC spectra of the ‘‘champion’’ f-PSCs. 

(D) PCE statistics (�25, each) of LD/3D and 3D MHP-based f-PSCs (histogram) and probability distribution (curve). 

Improved operational stability and bending durability of f-PSCs incorporating LD/3D MHP thin films 

The operational stability of unencapsulated f-PSCs with and without the LD MHP capping layer was evaluated under continuous 1-sun illumination at MPP-tracking in N2 (�45<sup>�</sup> C) where the PCE was measured every 12 h. Figure 5A shows that the PCE of the f-PSC with the LD MHP capping layer has degraded to only 90% of the initial PCE after 800 h (Figure 5A), whereas the control f-PSC without that layer has degraded to 79% after 475 h. These results clearly demonstrate the beneficial effect of the LD MHP capping layer in improving the operational stability of f-PSCs. (See Figure S6 for normalized PV parameters measured every 12 h) 

Long-term cyclic bend testing of f-PSCs with and without LD MHP capping layer were conducted (R = 5 mm, up to 20,000 tension-only cycles, in ambient air [�20% RH, �25<sup>�</sup> C]). As seen in Figure S7, both the 3D and LD/3D MHP f-PSCs showed good short-term stability (14 h). In addition, in order to minimize environmental effects, the cyclic bend testing was performed rapidly (�1 s per cycle or �1 Hz), with a 20,000-cycles test taking �6 h. Video S1 shows the automated setup for performing this testing. The tests were interrupted periodically to measure the J- V responses of the f-PSCs. Figures 5B–5E present the PV parameters as a function of number of bending cycles; the corresponding normalized data are presented in the insets. Overall, the f-PSC with LD/3D MHP thin films show unprecedented bending durability, where 81% of the initial PCE is retained after 20,000 cycles. In comparison, f-PSC without the LD MHP capping layer has retained only 54% if its initial 

1594 Joule 5, 1587–1601, June 16, 2021 

#### Article 





<!-- Start of picture text -->
ll<br><!-- End of picture text -->



<!-- Start of picture text -->
1.0<br>LD/3D MHP<br>90%<br>0.9<br>0.8<br>3D MHP 79%<br>0.7<br>A<br>0.6<br>0 200 400 600 800<br>Continuous Illumination Duration (h)<br>24 1.2<br>B LD/3D MHP C LD/3D MHP<br>3D MHP 1.1<br>22<br>3D MHP<br>1.00 1.0 1.0<br>0.96 0.9<br>20 0.92 0.9 0.8<br>0.88<br>0.7<br>10 0 10 1 10 2 10 3 10 4 10 0 10 1 10 2 10 3 10 4<br>18 0.8<br>0.8<br>D LD/3D MHP 20 E LD/3D MHP<br>0.7<br>18<br>0.6<br>16<br>3D MHP<br>0.5 1.0 1.0<br>0.9 14<br>0.8 3D MHP<br>0.4 0.80.7 12 0.6<br>0.3 0.6 10 0.4<br>0.5<br>10 0 10 1 10 2 10 3 10 4 10 0 10 1 10 2 10 3 10 4<br>0.2 8<br>10 0 10 1 10 2 10 3 10 4 10 0 10 1 10 2 10 3 10 4<br>Tension-Only Bending Cycles,  n Tension-Only Bending Cycles,  n<br>E<br>C<br>P<br>d<br>e<br>zila<br>mro<br>N<br>,ytis<br>n<br>e<br>D<br>tn<br>e<br>rr<br>u<br>C<br>tiu<br>ric -2 (mA∙cm) J SC<br>Ctro- Normalized  J SC Normalized  V OC<br>h<br>S Open-Circuit Voltage,  (V) V OC<br>FF<br>PCE  (%)<br>Normalized FF Normalized PCE<br><!-- End of picture text -->

Figure 5. Operational stability and bending durability of f-PSCs (A) Normalized PCE of unencapsulated f-PSCs with and without the LD MHP capping layer as a function of time under the following conditions: 1-sun continuous illumination, MPP-tracking, flowing N2 atmosphere, �45<sup>�</sup> C. PCE recorded approximately every 12 h. (B–E) (B) JSC, (C) VOC, (D) FF, and (E) PCE of unencapsulated f-PSCs with and without the LD MHP capping layer as a function of number of bending cycles (R = 5 mm, �1 Hz, tension-only, in ambient air [�20% RH, �25<sup>�</sup> C]). Insets, corresponding normalized PV parameters. 

PCE. In Figure 5D, note that the latter f-PSC starts to lose FF after just 10 cycles (�10 s), which is most likely because of delamination cracking; there is a steady decrease in FF up to about 10,000 cycles as the damage continues to accumulate. In contrast, f-PSC with LD MHP capping layer loses FF at a significantly slower rate (Figure 5D), which is attributed to reduced propensity for cracking in this f-PSC. After 10,000 cycles there is a decrease in VOC (Figure 5C) and FF (Figure 5D), which results in a decrease in the PCE (Figure 5E). In contrast, in the f-PSC without the LD MHP capping layer, beyond 10,000 cycles there is a precipitous loss in all three, JSC (Figure 5B), VOC (Figure 5C), and FF (Figure 5D), contributing to the significant loss in the PCE (Figure 5E). The ‘‘concave’’ compression-only cycle and the conventional (convex and concave) cycle tests (R = 5 mm) were also conducted, and the results are shown in Figures S8 and S9. Both 3D and LD/3D MHP f-PSC show good compression-only bending reliability and retain over 90% of the initial PCE after 10,000 cycles, which shows that for R = 5 mm, the compressive stress will not significantly reduce the performance of the functional layers and related interfaces. In the conventional bending cycle test, the f-PSCs with LD/3D MHP thin films show 

Joule 5, 1587–1601, June 16, 2021 1595 

**ll** 

Article 

comparable bending durability to that in tension-only test (Figure 5), where 88% of the initial PCE is retained after 10,000 cycles. However, comparing with the tensiononly test, the performance of the 3D MHP-based device is significantly reduced, which indicates that the film damage generated by the tension bending will deteriorate during the compression bending process, leading to serious performance degradation of the f-PSCs. These results clearly demonstrate the beneficial effect of the LD MHP capping layer in improving the bending durability of f-PSCs. 

##### DISCUSSION 

Here, we have demonstrated unprecedented, simultaneous improvements in efficiency, operational stability, mechanical reliability, and bending durability of f- PSCs, as a result of the incorporation of the LD MHP capping layer on 3D MHP thin film. In this context, several studies have shown that LD MHP capping layers can improve both efficiency and operational stability of PSCs (rigid), which is generally attributed to the improved photocarriers extraction at the LD MHP/HTL (or LD MHP/ETL) interface together with the hydrophobic nature of the LD MHP capping layer.<sup>44–46</sup> This appears to be responsible for the improved environmental stability (Figure 2F), optoelectronic properties (Figures 1H and 3), PCE (Figure 4), and operational stability (Figure 5A) observed in the f-PSCs. However, here, we focused on the improved mechanical reliability due to the in situ-grown LD MHP capping layer and its effect on the operational stability and the bending durability in f-PSCs. 

Biaxial tensile residual stress in typical as-deposited 3D MHP thin films on ITO/PET substrates is sR�50 MPa,<sup>36</sup> which will augment the tensile stress (sT) due to bending to R = 5 mm. The latter can be calculated by using Equation 1, with h = 185 mm (substrate thickness). However, E, and also KIC and GC, values for the mixed-composition MHP used here are not known. Therefore, the corresponding values for best-characterized MHP, MAPbI3, are used in the calculations. Given that these mechanical properties are controlled by the 3D network of the PbX64� octahedra (X = halogen), and there is only small amount of Br<sup>�</sup> in the mixed-composition MHP, this is a reasonable substitution. Using E�17.8 GPa<sup>37</sup> in Equation. 1, sT is calculated to be �330 MPa. Thus, the net tensile stress is sA�380 MPa. Using Equation. 2 for grain-boundary fracture (KIC�0.08 MPa.m<sup>0.5</sup> for MAPbI340) we calculated co�35 nm, i.e., surface flaws larger than �35 nm will propagate as through-thickness vertical cracks under bending. Because this is about the size of grain-boundary grooves in 3D MHP thin films, these films will crack (through-thickness vertically) under bending. As mentioned earlier, the vertical free surfaces thus created facilitate the propagation of horizontal cracks at the MHP/ETL interface. The condition for such cracking is given by:<sup>37,47</sup> 



<!-- Start of picture text -->
G = ð1 � n 2 Þts 2 ARGC; (Equation 3)<br>2E<br><!-- End of picture text -->

where G is the driving strain-energy release rate, n is the Poisson’s ratio (�0.33 for MAPbI348), t is the MHP film thickness (�600 nm), and GC is the toughness of the MHP/ETL interface (�1.1 J.m<sup>�2</sup> for MAPbI3/SnO240). Because the calculated G (�2.2 J.m<sup>�2</sup> ) is twice the interfacial GC, interfacial cracking is expected to occur easily, which is consistent with what is observed in Figure 2B. Note that cracking in general is a stochastic process because there is always a distribution of flaw sizes in any given brittle material, and it follows extreme-value statistics (e.g., Weibull).<sup>39</sup> Thus, repeated tension-only bending cycles (fatigue) increases the probability of multiple cracking and damage accumulation. (This is assuming no environmental interactions and cyclic-fatigue effects on the actual crack-propagation process at the atomic/molecular level in brittle MHP. In general, such effects, if present, will reduce the ‘‘effective’’ toughness.<sup>39</sup> ) 

1596 Joule 5, 1587–1601, June 16, 2021 

**ll** 

#### Article 

It is hypothesized that the LD MHP capping layer ‘‘seals’’ these surface flaws to reduce the effective co. In other words, much higher sA (or sharper bending R) will be needed to produce cracks in LD/3D MHP thin films. (This is akin to the ancient technology of surface-glazing ceramics [pottery], where the glassy glaze not only makes the porous ceramics impervious to liquids but also seals surface flaws, thereby making the glazed ceramic much stronger.<sup>49</sup> ) This resistance to cracking in LD/3D MHP thin films has cascading beneficial effects. First, the LD MHP capping layer, in addition to protecting the underlying 3D MHP thin film from environmental degradation, reduces cracking in the 3D MHP thin film, which further prevents environmental attack. This is consistent with the improved environmental stability observed after cyclic bend testing in Figures 2F and 3D, and demonstrates the tight connection between environmental stability, optoelectronic properties, and mechanical reliability, which has hitherto been neglected in the literature.<sup>50</sup> Finally, the reduced propensity for cracking due to the presence of the LD MHP capping layer in f-PSCs is responsible for their improved durability observed in Figures 5B– 5E under rapid cyclic bend testing, where environmental effects have been minimized. 

In closing, it is imperative that future approaches used to improve the PCE must also improve mechanical reliability of PSCs in general, and f-PSCs in particular. This will allow us to take advantage of its synergistic virtuous effects in improving simultaneously operational stability and durability of PSCs and overcome perhaps the final hurdle in the path toward future commercialization of PSCs. 

##### EXPERIMENTAL PROCEDURES 

###### Resource availability 

Lead contact 

Further information and requests for resources should be directed to and will be fulfilled by the lead contact, Yantao Shi (shiyantao@dlut.edu.cn). 

###### Materials availability 

This study did not generate new unique reagents. 

###### Data and code availability 

This study did not generate or analyze any datasets or codes. The data and results supporting the current study are available from the lead contact upon reasonable request. 

###### Raw materials 

All the chemicals were used as-received from commercial sources, including PbI2 and PbBr2 (>99%, TCI Japan), CH3NH3Br (MABr, 99.8%, Xi’an Polymer Light Technology, China), HC(NH2)2I (FAI, 99.8%, Xi’an Polymer Light Technology, China), CsI (99.999%, Alfa Aesar, UK), FK209 Co (III) TFSI (95%, Greatcell Energy, Australia), SnO2 colloidal dispersion (15 wt % in H2O, Alfa Aesar, UK), 3-chlorobenzylamine (98%+, Adamas, China), Spiro-OMeTAD (99.7%, Lumtec, Taiwan), diethyl ether (99.5%, Sinopharm Chemical Reagent, China), isopropanol (99.8%, Sinopharm Chemical Reagent, China).The reagents 4-tert-butylpyridine (TBP, 96%), bis (trifluoromethane) sulfonimide lithium salt (99.95%), HI (57 wt % in H2O, 99.95%), and solvents acetonitrile (99.9%), dimethylformamide (DMF, 99.8%), dimethylsulfoxide (DMSO, 99.9%), a,a,a-trifluorotoluene (R 99%), and chlorobenzene (CB, 99.8%) were all purchased from Sigma Aldrich (USA). FTO-coated glass substrates (7 U sq<sup>-1</sup> ) were purchased from Suzhou Shangyang Solar Technology (China). The ITO-coated PET substrates (�185 mm thickness) were prepared in-house. 

Joule 5, 1587–1601, June 16, 2021 1597 

**ll** 

Article 

3-CBAI was synthesized by adding 690 mg 3-chlorobenzylamine (3-CBA) to10 mL absolute ethanol in a round-bottom flask that was stirred in an ice-water bath. Then, 1.1 g HI solution was added dropwise to the 3-CBA ethanol solution that was stirred for 2 h. After removing solvent by vacuum distillation, the solid crude 3-CBAI was obained and washed with diethyl ether. Subsequently, the 3-CBAI solid was dissolved in ethanol and recrystallized with diethyl ether, which was repeated three times, and then dried in a vacuum-oven at 60<sup>�</sup> C for 48 h to obtain 3-CBAI crystals. 

###### Device fabrication 

FTO/glass and ITO/PET substrates were etched using a laser-etching machine (Perovs, China) to obtain the electrode pattern. The glass/FTO substrates were washed with cleaning fluid, deionized water, ethanol, acetone, and isopropanol sequentially in an ultrasonic cleaning machine, whereas the ITO/PET substrates were washed with deionized water and isopropanol. Subsequently, SnO2 colloidal dispersion, which was diluted to 2.5 wt % using deionized water (1:3.5 by volume), was spin coated on the substrates at 3,000 rpm for 30 s, and then heated at 150<sup>�</sup> C for 0.5 h (rigid substrate) and 120<sup>�</sup> C for 1.5 h (flexible substrate) to remove the solvent. All ETLs were then treated by UVO for 10 min and transferred to the glovebox (H2O < 0.01 ppm, O2 < 0.01 ppm). The (CsPbI3)0.04[(FAPbI3)0.9(MAPbBr3)0.1]0.96 MHP precursor was prepared by sequentially adding CsI (13.5 mg), MABr (14.0 mg), PbBr2 (45.8 mg), FAI (193.2 mg), and PbI2 (569.6 mg) into 1 mL mixed solvent of DMF and DMSO (4:1 by volume), and stirred at 60<sup>�</sup> C for 30 min. To prepare the perovskite films, 50 mL of the above perovskite precursor was spread on the SnO2-ETL-coated conductive substrates, followed by a two-stage spin-coating process (1,000 rpm for 10 s and 6,000 rpm for 30 s). During the second spin-coating stage, 150 mL of a,a,a-trifluorotoluene was dripped onto the spinning substrate 15 s prior the end of the program. The films were then annealed at 100<sup>�</sup> C for 50 min. For the LD/3D perovskite, the 3-CBAI solution (5 mg mL�<sup>1</sup> in isopropanol) was dropped on the 3D perovskite and held for 1 min. After spin coating at 3,000 rpm for 30 s, the films were annealed at 100<sup>�</sup> C for 1 min. Precursor solution of HTL was prepared by dissolving 72.3 mg spiro-MeOTAD, 28.8 mL 4-tert-butylpyridine, 17.5 mL lithium bis (trifluoromethylsulphonyl) imide acetonitrile solution (520 mg mL<sup>�1</sup> ) into 1 mL chlorobenzene. The HTL solution was then deposited on top of the perovskite layer by spin coating at 3,000 rpm for 30 s. Finally, a 60-nm Au electrode was thermally evaporated on top of the HTL. 

###### Materials characterization 

The microstructures of the thin films were observed using a field-emission SEM (SU8220, Hitachi, Japan). To obtain the cross-sectional SEM images, the flexible samples were embrittled in liquid N2 in the glovebox (H2O < 0.01 ppm, O2 < 0.01 ppm) and fractured between two tweezers, whereas the rigid samples were cut with a glass cutter and fractured by bending. The GIWAXS measurements of perovskite films were performed at the BL14B1 beamline of the Shanghai Synchrotron Radiation Facility using X-rays of wavelength 1.24 A<sup>˚</sup> . Grazing incidence angles of 0.1<sup>�</sup> and 1<sup>�</sup> were used to detect the surface and bulk phase crystalline and orientation structure of the films. XRD of the perovskite thin films was performed using a highresolution diffractometer (SmartLab 9kw, Rigaku, Japan) with CuKa radiation. Diffuse reflectance UV-vis spectra of the perovskite films were obtained using a spectrophotometer (U-4150, Hitachi, Japan). TRPL spectra of perovskite films were recorded using a home-built PL-imaging microscope coupled with a time-correlated single photon counting (TCSPC) module. Excitation of the sample was achieved with a pulse laser (PIXEA-CU-1, AUREA, France) of 406-nm wavelength. The excitation 

1598 Joule 5, 1587–1601, June 16, 2021 

**ll** 

#### Article 

laser beam was focused on the sample through a 1003 air objective lens (NA = 0.60, Olympus SLMPlan N, 100 X) with the spot radius of 1.02 mm (1/e<sup>2</sup> of the maximum intensity measured with an EMCCD camera, DU-897U-CS0-#BV, Andor, UK). UPS was performed using Kratos Analytical spectrometer (AXIS ULTRA DLD, Kratos Analytical, UK), and mono-chromatized He-Ia radiation at 21.2 eV was used. Absolute-intensity PL was measured using an integrating sphere (Fluorolog, Horiba JobinYvon), an Andor Kymera 193i spectrograph and a 660-nm continuous-wave laser (OBIS, Coherent) set at 1-sun equivalent photon flux (1.1 mm beam full-width halfmaximum, 632 mW); the PL signal was collected at normal incidence using a 0.1 NA, 110-mm-diameter optical fiber. For the calibration of these measurements, we used a halogen lamp (HL-3 plus CAL from Ocean Optics). 

###### Solar cells performance testing 

The current density-voltage (J-V) characteristics of PSCs were measured by a source meter (2450, Keithley, USA) at the scan speed of 100 mV s<sup>�1</sup> under AM 1.5G 1-sun illumination (100 mW cm<sup>�2</sup> ) generated by a solar simulator (Sol3A Class AAA, Oriel, Newport, USA). The intensity was calibrated using an ISO-17025 standard calibrated reference silicon cell (91150V-KG3, Newport, USA). The active device area of PSCs during the measurements was 0.096 cm<sup>2</sup> as defined by a metal mask. Steady-state current/PCE outputs were measured using the 2450 Source Meter (Keithley, USA) at voltages determined from the MPPs of the reverse-scan J-V curves. The EQE spectra were obtained using a quantum efficiency measurement system (QE-R, Enlitech). All performance tests are carried out in ambient air at room temperature. 

###### Solar cell stability testing 

Long-term operational stability test of unencapsulated f-PSCs was measured using the Candlelight System (Switzerland). The f-PSCs were placed in a sealed cell holder with a transparent quartz cover. A continuous flow of N2 gas was passed through the holder to minimize the H2O and O2 content in the atmosphere. The PSCs were biased at the maximum-power-point voltage using a potentiostat under continuous white-LED illumination (1 sun) at � 45<sup>�</sup> C. The PV performance parameters were measured every 12 h. 

Cyclic bend testing was performed in air using a mechanical tester (PR-BDM-100, Puri, China) in constant-radius bending mode, where the bending direction was convex (tension-only) with R = 5 mm. For short-term cyclic bend testing of thinfilm specimens 2,000 tension-only cycles were performed, where each bending cycle took �1 s followed by a �6 min rest in air. XRD and absolute-intensity PL were used to track the property changes of thin films. In order to test the long-term bending durability of f-PSCs, continuous (without rest) 1-s different (tension-only, compression-only, and conventional) bending cycles (1 Hz) were performed. The testing was interrupted periodically, where the J-V curves were measured periodically in air using the Source meter (2450, Keithley, USA) at the scan speed of 100 mV s<sup>�1</sup> under AM 1.5G 1-sun illumination (100 mW cm<sup>�2</sup> ) generated by a solar simulator (Sol3A Class AAA, Oriel, Newport, USA). 

##### SUPPLEMENTAL INFORMATION 

Supplemental information can be found online at https://doi.org/10.1016/j.joule. 2021.04.014. 

Joule 5, 1587–1601, June 16, 2021 1599 

**ll** 

Article 

##### ACKNOWLEDGMENTS 

The work at Brown University was funded by the Office of Naval Research (N0001420-1-2574 to Z.D. and N.P.P.) and Brown’s Open Graduate Education fellowship (to M.C.). The work at Dalian University of Technology was supported by the National Natural Science Foundation of China (51773025, 22005043, and 51872036), Natural Science Foundation of Liaoning Province, China (20180510027), Dalian Science and Technology Innovation Fund (2019J12GX032), and China Postdoctoral Science Foundation (2019TQ0046 and 2020M680941). We thank beamline BL14B1 at Shanghai Synchrotron Radiation Facility (SSRF) for providing the beam time. We also thank J.Z. Yin, Y.G. Yang, and Prof. K. Wang for the experimental assistance and D.Q. An and Prof. R. Li for the discussion of mechanics. 

##### AUTHOR CONTRIBUTIONS 

Q.D., M.C., Y.S., and N.P.P. conceived the idea together. M.C. and Q.D. designed and analyzed most of the experiments. Y.L. joined the discussion with M.C. for some of the experimental results. Q.D. conducted device fabrication, testing, and characterization using SEM, UV-vis, GIWAX, UPS, etc. W.Z. designed and synthesized the 3-CBAI molecule. C.J. assisted in the flexible device fabrication and testing. Z.D. performed the device stability testing. F.T.E., Y.L., S.M.Z., and M.G. performed the absolute-intensity PL measurements. Y.Y. and S.J. performed TRPL characterization. J.F. and S.(F).L. fabricated the ITO/PET substrates and provided advice on f- PSCs fabrication. M.C., Q.D., Y.S., and N.P.P. co-wrote the manuscript, with comments from all the other authors. 

##### DECLARATION OF INTERESTS 

The authors declare no competing interests. 

Received: February 1, 2021 Revised: April 6, 2021 Accepted: April 22, 2021 Published: May 25, 2021 

##### REFERENCES 

1. Kojima, A., Teshima, K., Shirai, Y., and Miyasaka, T. (2009). Organometal halide perovskites as visible-light sensitizers for photovoltaic cells. J. Am. Chem. Soc. 131, 6050–6051. 

2. NREL (2021). Best research-cell efficiencies. https://www.nrel.gov/pv/cell-efficiency.html. 

3. Park, N.-G., Gra¨tzel, M., and Miyasaka, T. (2016). Organic-Inorganic Halide Perovskite Photovoltaics: From Fundamentals to Device Architectures (Springer). 

4. Snaith, H.J. (2018). Present status and future prospects of perovskite photovoltaics. Nat. Mater. 17, 372–376. 

5. Jena, A.K., Kulkarni, A., and Miyasaka, T. (2019). Halide perovskite photovoltaics: background, status, and future prospects. Chem. Rev. 119, 3036–3103. 

6. Kaltenbrunner, M., Adam, G., Głowacki, E.D., Drack, M., Schwo¨ diauer, R., Leonat, L., Apaydin, D.H., Groiss, H., Scharber, M.C., White, M.S., et al. (2015). Flexible high powerper-weight perovskite solar cells with 

chromium oxide–metal contacts for improved stability in air. Nat. Mater. 14, 1032–1039. 

7. Zhang, C., Wang, S., Zhang, H., Feng, Y., Tian, W., Yan, Y., Bian, J., Wang, Y., Jin, S., Zakeeruddin, S.M., et al. (2019). Efficient stable graphene-based perovskite solar cells with high flexibility in device assembling via modular architecture design. Energy Environ. Sci. 12, 3585–3594. 

8. Jung, H.S., Han, G.S., Park, N.-G., and Ko, M.J. (2019). Flexible perovskite solar cells. Joule 3, 1850–1880. 

9. Zeng, P., Deng, W., and Liu, M. (2020). Recent advances of device components toward efficient flexible perovskite solar cells. Sol. RRL 4, 1900485. 

10. Hashemi, S.A., Ramakrishna, S., and Aberle, A.G. (2020). Recent progress in flexible– wearable solar cells for self-powered electronic devices. Energy Environ. Sci. 13, 685–743. 

11. Mishra, S., Ghosh, S., and Singh, T. (2021). Progress in materials development for flexible 

perovskite solar cells and future prospects. ChemSusChem 14, 512–538. 

12. Singh, T., Ikegami, M., and Miyasaka, T. (2018). Ambient fabrication of 126 mm thick complete perovskite photovoltaic device for high flexibility and performance. ACS Appl. Energy Mater. 1, 6741–6747. 

13. Kim, Y.Y., Yang, T.Y., Suhonen, R., Kemppainen, A., Hwang, K., Jeon, N.J., and Seo, J. (2020). Roll-to-roll gravure-printed flexible perovskite solar cells using eco-friendly antisolvent bathing with wide processing window. Nat. Commun. 11, 5146. 

14. Ju, M.-G., Chen, M., Zhou, Y., Dai, J., Ma, L., Padture, N.P., and Zeng, X.C. (2018). Toward eco-friendly and stable perovskite materials for photovoltaics. Joule 2, 1231–1241. 

15. Dunlap-Shohl, W.A., Zhou, Y., Padture, N.P., and Mitzi, D.B. (2019). Synthetic approaches for halide perovskite thin films. Chem. Rev. 119, 3193–3295. 

16. Yoon, J., Sung, H., Lee, G., Cho, W., Ahn, N., Jung, H.S., and Choi, M. (2017). Superflexible, 

1600 Joule 5, 1587–1601, June 16, 2021 

**ll** 

#### Article 

high-efficiency perovskite solar cells utilizing graphene electrodes: towards future foldable power sources. Energy Environ. Sci. 10, 337–345. 

17. Hu, X., Meng, X., Zhang, L., Zhang, Y., Cai, Z., Huang, Z., Su, M., Wang, Y., Li, M., Li, F., et al. (2019). A mechanically robust conducting polymer network electrode for efficient flexible perovskite solar cells. Joule 3, 2205–2218. 

18. Azani, M.-R., Hassanpour, A., and Torres, T. (2020). Benefits, problems, and solutions of silver nanowire transparent conductive electrodes in indium tin oxide (ITO)-free flexible solar cells. Adv. Energy Mater. 10, 2002536. 

19. Li, M., Zuo, W.-W., Ricciardulli, A.G., Yang, Y.-G., Liu, Y.-H., Wang, Q., Wang, K.L., Li, G.-X., Saliba, M., Girolamo, D.D., et al. (2020). Embedded nickel-mesh transparent electrodes for highly efficient and mechanically stable flexible perovskite photovoltaics: Toward a portable mobile energy source. Adv. Mater. 32, 2003422. 

20. Shin, S.S., Yang, W.S., Noh, J.H., Suk, J.H., Jeon, N.J., Park, J.H., Kim, J.S., Seong, W.M., and Seok, S.I. (2015). High-performance flexible perovskite solar cells exploiting Zn2SnO4 prepared in solution below 100<sup>�</sup> C. Nat. Commun. 6, 7410. 

21. Yang, D., Yang, R., Wang, K., Wu, C., Zhu, X., Feng, J., Ren, X., Fang, G., Priya, S., and Liu, S.F. (2018). High efficiency planar-type perovskite solar cells with negligible hysteresis using EDTA-complexed SnO2. Nat. Commun. 9, 3239. 

22. Dong, Q., Li, J., Shi, Y., Chen, M., Ono, L.K., Zhou, K., Zhang, C., Qi, Y., Zhou, Y., Padture, N.P., and Wang, L. (2019). Improved SnO2 electron transport layers solution-deposited at near room temperature for rigid or flexible perovskite solar cells with high efficiencies. Adv. Energy Mater. 9, 1900834. 

23. Huang, K., Peng, Y., Gao, Y., Shi, J., Li, H., Mo, X., Huang, H., Gao, Y., Ding, L., and Yang, J. (2019). High-performance flexible perovskite solar cells via precise control of electron transport layer. Adv. Energy Mater. 9, 1901419. 

24. Zhang, H., Cheng, J., Lin, F., He, H., Mao, J., Wong, K.S., Jen, A.K.-Y., and Choy, W.C.H. (2016). Pinhole-free and surfacenanostructured NiOX film by roomtemperature solution process for highperformance flexible perovskite solar cells with good stability and reproducibility. ACS Nano 10, 1503–1511. 

25. Chung, J., Shin, S.S., Hwang, K., Kim, G., Kim, K.W., Lee, D.S., Kim, W., Ma, B.S., Kim, Y.-K., Kim, T.-S., and Seo, J. (2020). Record-efficiency flexible perovskite solar cell and module enabled by a porous-planar structure as an electron transport layer. Energy Environ. Sci. 13, 4854–4861. 

26. Yang, L., Xiong, Q., Li, Y., Gao, P., Xu, B., Lin, H., Li, X., and Miyasaka, T. (2021). Artemisinin- 

passivated mixed-cation perovskite films for durable flexible perovskite solar cells with over 21% efficiency. J. Mater. Chem. A 9, 1574–1582. 

27. Lee, G., Kim, M.-C., Choi, Y.W., Ahn, N., Jang, J., Yoon, J., Kim, S.M., Lee, J.-G., Kang, D., Jung, H.S., and Choi, M. (2019). Ultra-flexible perovskite solar cells with crumpling durability: toward a wearable power source. Energy Environ. Sci. 12, 3182–3191. 

28. Feng, J., Zhu, X., Yang, Z., Zhang, X., Niu, J., Wang, Z., Zuo, S., Priya, S., Liu, S.F., and Yang, D. (2018). Record efficiency stable flexible perovskite solar cell using effective additive assistant strategy. Adv. Mater. 30, e1801418. 

29. Ge, C., Yang, Z., Liu, X., Song, Y., Wang, A., and Dong, Q. (2020). Stable and highly flexible perovskite solar cells with power conversion efficiency approaching 20% by elastic grain boundary encapsulation. CCS Chem 2, 2035– 2044. 

30. Duan, X., Li, X., Tan, L., Huang, Z., Yang, J., Liu, G., Lin, Z., and Chen, Y. (2020). Controlling crystal growth via an autonomously longitudinal scaffold for planar perovskite solar cells. Adv. Mater. 32, e2000617. 

31. Li, M., Yang, Y.G., Wang, Z.K., Kang, T., Wang, Q., Turren-Cruz, S.H., Gao, X.Y., Hsu, C.S., Liao, L.S., and Abate, A. (2019). Perovskite grains embraced in a soft fullerene network make highly efficient flexible solar cells with superior mechanical stability. Adv. Mater. 31, e1901519. 

32. Lan, Y., Wang, Y., and Song, Y. (2020). Efficient flexible perovskite solar cells based on a polymer additive. Flex. Print. Electron. 5, 014001. 

33. Meng, X., Cai, Z., Zhang, Y., Hu, X., Xing, Z., Huang, Z., Huang, Z., Cui, Y., Hu, T., Su, M., et al. (2020). Bio-inspired vertebral design for scalable and flexible perovskite solar cells. Nat. Commun. 11, 3016. 

34. Wang, Z., Zeng, L., Zhang, C., Lu, Y., Qiu, S., Wang, C., Liu, C., Pan, L., Wu, S., Hu, J., et al. (2020). Rational interface design and morphology control for blade-coating efficient flexible perovskite solar cells with a record fill factor of 81%. Adv. Funct. Mater. 30, 2001240. 

35. Dong, Q., Zhu, C., Chen, M., Jiang, C., Guo, J., Feng, Y., Dai, Z., Yadavalli, S.K., Hu, M., Cao, X., et al. (2021). Interpenetrating interfaces for efficient perovskite solar cells with high operational stability and mechanical robustness. Nat. Commun. 12, 973. 

36. Yadavalli, S.K., Dai, Z., Zhou, H., Zhou, Y., and Padture, N.P. (2020). Facile healing of cracks in organic-inorganic halide perovskite thin films. Acta Mater 187, 112–121. 

37. Ramirez, C., Yadavalli, S.K., Garces, H.F., Zhou, Y., and Padture, N.P. (2018). Thermomechanical behavior of organic-inorganic halide perovskites for solar cells. Scr. Mater. 150, 36–41. 

38. Rolston, N., Bush, K.A., Printz, A.D., GoldParker, A., Ding, Y., Toney, M.F., McGehee, M.D., and Dauskardt, R.H. (2018). Engineering stress in perovskite solar cells to improve stability. Adv. Energy Mater. 8, 1802139. 

39. Lawn, B.R. (1993). Fracture of Brittle Solids, Second Edition (Cambridge University Press). 

40. Dai, Z., Yadavalli, S.K., Hu, M., Chen, M., Zhou, Y., and Padture, N.P. (2020). Effect of grain size on the fracture behavior of organic-inorganic halide perovskite thin films for solar cells. Scr. Mater. 185, 47–50. 

41. Saliba, M., Matsui, T., Seo, J.Y., Domanski, K., Correa-Baena, J.P., Nazeeruddin, M.K., Zakeeruddin, S.M., Tress, W., Abate, A., Hagfeldt, A., and Gra¨tzel, M. (2016). Cesiumcontaining triple cation perovskite solar cells: improved stability, reproducibility and high efficiency. Energy Environ. Sci. 9, 1989–1997. 

42. Jeon, N.J., Noh, J.H., Kim, Y.C., Yang, W.S., Ryu, S., and Seok, S.I. (2014). Solvent engineering for high-performance inorganicorganic hybrid perovskite solar cells. Nat. Mater. 13, 897–903. 

43. Yadavalli, S.K., Chen, M., Hu, M., Dai, Z., Zhou, Y., and Padture, N.P. (2020). Electron-beaminduced cracking in organic-inorganic halide perovskite thin films. Scr. Mater. 187, 88–92. 

44. Chen, P., Bai, Y., Wang, S., Lyu, M., Yun, J.-H., and Wang, L. (2018). In situ growth of 2D perovskite capping layer for stable and efficient perovskite solar cells. Adv. Funct. Mater. 28, 1706923. 

45. Liu, Y., Akin, S., Pan, L., Uchida, R., Arora, N., Mili�c, J.V., Hinderhofer, A., Schreiber, F., Uhl, A.R., Zakeeruddin, S.M., et al. (2019). Ultrahydrophobic 3D/2D fluoroarene bilayerbased water-resistant perovskite solar cells with efficiencies exceeding 22%. Sci. Adv. 5, eaaw2543. 

46. Liu, Y., Akin, S., Hinderhofer, A., Eickemeyer, F.T., Zhu, H., Seo, J.Y., Zhang, J., Schreiber, F., Zhang, H., Zakeeruddin, S.M., et al. (2020). Stabilization of highly efficient and stable phase-pure FAPbI3 perovskite solar cells by molecularly tailored 2d-overlayers. Angew. Chem. Int. Ed. Engl. 59, 15688–15694. 

47. Freund, L.B., and Suresh, S. (2003). Thin Film Materials: Stess, Defect Formation and Surface Evolution (Cambridge University Press). 

48. Feng, J. (2014). Mechanical properties of hybrid organic-inorganic CH 3 NH 3 BX 3 (B = Sn, Pb; X = Br, I) perovskites for solar cell absorbers. APL Mater 2, 081801. 

49. Kingery, W.D., Bowen, H.K., and Uhlmann, D.R. (1976). Introduction to Ceramics, Second Edition (Wiley Interscience). 

50. Dai, Z., Yadavalli, S.K., Chen, M., Abbaspourtamijani, A., Qi, Y., and Padture, N.P. (2021). Interfacial toughening with selfassembled monolayers enhances perovskite solar cell reliability. Science 372, 618–622. 

Joule 5, 1587–1601, June 16, 2021 1601 

