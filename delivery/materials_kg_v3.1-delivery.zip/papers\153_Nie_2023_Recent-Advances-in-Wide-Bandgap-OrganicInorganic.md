# Recent Advances in Wide-Bandgap Organic–Inorganic Halide Perovskite Solar Cells and Tandem Application

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nano-Micro Letters |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 187 |
| 作者 | Ting Nie, Z. Fang, Xiao-Dong Ren, Yuwei Duan, S. Liu |
| DOI | 10.1007/s40820-023-01040-6 |
| 源文件 | 053_Nie_2023_Recent-Advances-in-Wide-Bandgap-OrganicInorganic.pdf |

---
e-ISSN 2150-5551 CN 31-2103/TB 

## **<mark>REVIEW</mark>** 

https://doi.org/10.1007/s40820-023-01040-6 



###### **Cite as** 

Nano-Micro Lett. (2023) 15:70 

Received: 3 December 2022 Accepted: 28 January 2023 Published online: 21 March 2023 © The Author(s) 2023 

# **Recent Advances in Wide‑Bandgap Organic–Inorganic Halide Perovskite Solar Cells and Tandem Application** 

Ting Nie<sup>1</sup> , Zhimin Fang<sup>1*</sup> , Xiaodong Ren<sup>1</sup> , Yuwei Duan<sup>1</sup> , Shengzhong (Frank) Liu<sup>1,2*</sup> 

#### **HIGHLIGHTS** 

- Wide-bandgap perovskite solar cells are reviewed in detail from the views of compositions, additives, charge transport layers, interfaces and preparation methods. 

- The key factors affecting open-circuit voltage and photostability are carefully discussed. 

- The future directions and challenges in developing wide-bandgap perovskite solar cells are highlighted. 

**ABSTRACT** Perovskite-based tandem solar cells have attracted increasing interest because of its great potential to surpass the Shockley–Queisser limit set for single-junction solar cells. In the tandem architectures, the wide-bandgap (WBG) perovskites act as the front absorber to offer higher open-circuit voltage ( _V_ OC) for reduced thermalization losses. Taking advantage of tunable bandgap of the perovskite materials, the WBG perovskites can be easily obtained by substituting halide iodine with bromine, and substituting organic ions FA and MA with Cs. To date, the most concerned issues for the WBG perovskite solar cells (PSCs) are huge _V_ OC deficit and severe photo-induced phase separation. Reducing _V_ OC loss and improving photostability of the WBG PSCs are crucial for further efficiency breakthrough. Recently, scientists have made great efforts to overcome these key issues with tremendous progresses. In this review, we first summarize the recent progress of WBG perovskites from the aspects of compositions, additives, charge transport layers, interfaces and preparation methods. The key factors affecting efficiency and stability are then carefully discussed, which would provide decent guidance to develop highly efficient and stable WBG PSCs for tandem application. 



**KEYWORDS** Efficiency; Perovskite; Solar cell; Stability; Wide-bandgap 

> * Zhimin Fang, fangzm@snnu.edu.cn; Shengzhong (Frank) Liu, szliu@dicp.ac.cn 

> 1 Key Laboratory of Applied Surface and Colloid Chemistry, Ministry of Education, Shaanxi Key Laboratory for Advanced Energy Devices, Shaanxi Engineering Lab for Advanced Energy Technology, School of Materials Science and Engineering, Shaanxi Normal University, Xi’an 710119, China 

> 2 Dalian National Laboratory for Clean Energy, iChEM, Dalian Institute of Chemical Physics, Chinese Academy of Sciences, Dalian 116023, China 

1 3 

**70** Page 2 of 44 

Nano-Micro Lett. (2023) 15:70 

### **1 Introduction** 

The development of human society is inseparable from the use of energy. However, traditional fossil energy is exhaustible and not environment friendly. Converting solar energy to electricity is one of the most promising direction to realize sustainable development. So far, the silicon (Si) solar cells are still dominating the photovoltaic (PV) market due to high efficiency, mature fabrication technology and excellent stability. Whereas, the power conversion efficiency (PCE) of silicon solar cells has reached saturation at 26.7% for years. In 2009, organic–inorganic perovskite solar cells (PSCs) came into the view of scientists around the world, since then they have become the most shining solar cells in the past decade, and the certified PCE has rapidly reached 25.7%, showing great potential for commercialization [1–7]. It is known that increasing the PCE is the most effective way to further reduce the PV module cost [8]. Impressively high PCE obtained from III–V compound semiconductors has proven the feasibility of developing multi-junction solar cells to breakthrough Shockley–Queisser ( _S-Q_ ) limit [9–12]. Hence, it is promising to combine wide-bandgap (WBG) perovskite materials with other narrow-bandgap (NBG) light absorbers to construct tandem solar cells (TSCs) to pursue higher PCE [13–17]. 

In addition to fascinating optoelectronic properties like high light-absorption coefficient, bipolar carrier transport, high carrier mobility and low exciton binding energy, the tunable bandgap and solution processibility make perovskite materials desirable candidates for the preparation of TSCs [18–21]. Taking silicon solar cells as example, its efficiency improvement is significantly restricted by the thermalization loss [22]. That is, the photons at short wavelength possess extremely higher energy than the bandgap of Si absorber, leading to the excess energy loss via thermal relaxation of hot carriers as the excited electrons falling back to the band edge (Fig. 1a). In order to simultaneously absorb more photons and reduce thermalization loss (Fig. 1b), it is feasible to construct multi-junction solar cells via bandgap complementarity strategy. In a multi-junction solar cell, the front cell with WBG absorber captures high-energy photons to reduce the thermalization loss and deliver high open-circuit voltage ( _V_ OC), while the rear cell with NBG 

absorber harvests low-energy photons to broaden the photoresponse (Fig. 1c) [23–25]. Therefore, taking advantage of tunable bandgap (1.20–2.3 eV) of perovskite materials, different kinds of perovskite-based tandem solar cells can be obtained [26–28]. To date, there are mainly four types of perovskite-based monolithic TSCs: perovskite/silicon, perovskite/CIGS, all-perovskite and perovskite/organic, which deliver certified PCEs of 32.5%, 24.2%, 29% and 23.4%, respectively [1, 29–31]. Beyond monolithic two-terminal (2-T) TSCs, mechanically stacked four-terminal (4-T) TSCs have also been widely studied [11, 32]. In a 4-T architecture, the two sub-cells are fabricated independently and mechanically stacked. The independent processing of the sub-cells allows each sub-cell to work at their maximum power point conditions, which makes 4-T tandem cells less sensitive to spectral changes. In other words, for 4-T tandems, the demand for the bandgap of perovskites is not strict. The key point is developing highly efficient semitransparent PSCs. However, the 4-T tandems suffer from some inherent disadvantages such as additional balance-of-system (BOS) costs of separate system components and severe parasitic absorption losses due to the use of more transparent electrodes. While a 2-T architecture consists of two sub-cells connected in series through a charge recombination layer, which requires less transparent electrode, showing the advantages of reducing costs and parasitic absorption losses [33]. So far, the highest efficiencies for 2-T and 4-T TSCs have reached 32.5% [1] and 30.24% [34], respectively. The extremely higher PCE makes 2-T perovskite-based TSCs become the research frontier in photovoltaic field, showing great potential for commercialization. As the key front absorber in TSCs, WBG perovskites are vital for all 2-T perovskite-based TSCs. Highly efficient and stable WBG PSCs are important guarantee for high-performance TSCs. Hence, WBG PSCs have attracted increasing attention in recent years [35]. Reviewing the encouraging progress is meaningful to promote the further development of WBG PSCs and tandem application. 

Herein, we reviewed recent progress of WBG PSCs from the aspects of compositions, additives, charge transport layers, interfaces and preparation methods, in which the key factors affecting device performance are carefully discussed. It is highlighted that challenges including _V_ OC 

© The authors 

https://doi.org/10.1007/s40820-023-01040-6 

Page 3 of 44 **70** 

Nano-Micro Lett. (2023) 15:70 



**Fig. 1** Schematic illustration of light absorption in **a** single and **b** multi-junction solar cells. **c** Two-terminal tandem devices. Reproduced with permission from Ref. [22]. Copyright 2021, Nature Publishing Group 

deficit, stability and module fabrication are still the major concerns for WBG PSCs and monolithic tandem application. In the end, we gave an outlook on the strategies toward the highly efficient, long-term stable and large-area monolithic perovskite-based TSCs. 

### **2  Perovskite Materials** 

##### **2.1  Crystal Structure** 

The organic–inorganic hybrid perovskite materials have a typical  ABX3 perovskite structure (Fig. 2a) [36]. The A site is monovalent cation such as methylammonium  (MA<sup>+</sup> ), formamidinium  (FA<sup>+</sup> ) and  Cs<sup>+</sup> , B site is divalent cation such as Pb<sup>2+</sup> and  Sn<sup>2+</sup> , and X site is halide ion such as  I<sup>−</sup> ,  Br<sup>−</sup> and Cl<sup>−</sup> . In the  ABX3 perovskite structure, the A and B cations occupy the corner and center of the cubic unit cell, respectively, while the X anion locates at the face-center. The formability and stability of this structure is commonly evaluated by tolerance factor _t_ and octahedral factor _μ_ , defined as: 



<!-- Start of picture text -->
r A +  r X<br>t  = (1)<br>√2( r B +  r X)<br><!-- End of picture text -->



<!-- Start of picture text -->
휇 = r B (2)<br>r X<br><!-- End of picture text -->

where _r_ A, _r_ B and _r_ X are the ionic radii of the A, B and X ions, respectively. Typically, when 0.8 < _t_ < 1.0, the crystal shows a 3D perovskite structure, and a _μ_ value between 0.4 and 0.9 favors a stable  BX6 octahedra [37–39]. 

##### **2.2  Electronic Structure** 

The electronic structure of hybrid perovskite has been studied by density functional theory (DFT) calculations (Fig. 2b–f) [40]. It is revealed that the conduction band minimum (CBM) is dominated by the antibond from the Pb- _p_ orbital, and the valence band maximum (VBM) is determined by the antibond from the Pb– _s_ and I- _p_ orbitals (Fig. 2c–f). Take  MAPbI3 perovskite for example, the optical transition of  MAPbI3 depends on a direct bandgap _p-p_ transition, giving rise to high absorption coefficient. The extremely high absorption coefficient  (10<sup>4</sup> ~10<sup>5</sup> cm<sup>−1</sup> ) gifts them ability of absorbing sufficient sunlight with a thin film (< 1 μm). The well-dispersed bands near CBM and VBM (Fig. 2b) result in the small effective electron mass ( _m_ e*) and hole mass ( _m_ h*), which is responsible for the efficient bipolar carrier transport property of perovskite materials [41, 42]. 

##### **2.3  Tunable Bandgap** 

The bandgap of perovskite materials can be continuously adjusted via composition engineering. All the _A_ , _B_ and _X_ sites have significant influences on the bandgap of perovskite materials. For instance, the bandgaps for  MAPbI3,  FAPbI3 and  CsPbI3 perovskites are about 1.55, 1.48, and 1.73 eV, respectively. That is, the bandgap increases as the ionic radius of A-site decreases, which is due to the modulation of the Pb-I bond originating from the size effects of A-site cations [43]. Substituting Pb with Sn will result in a remarkable reduction in bandgap, making Pb–Sn mixed perovskites ideal rear sub-cells for all-perovskite TSCs (Fig. 2g) [44, 

1 3 

**70** Page 4 of 44 

Nano-Micro Lett. (2023) 15:70 



**Fig. 2  a** Typical  ABX3 crystal structure of halide perovskites. Reproduced with permission from Ref. [36]. Copyright 2019, Royal Society of Chemistry. **b** Band structure. **c** Total DOS. Partial DOSs of **d** MA<sup>+</sup> , **e** Pb, and **f** I. Reproduced with permission from Ref. [40]. Copyright 2014, AIP Publishing LLC. **g** Schematic of origin of the bandgap bowing in MA(Pb1−xSnx)I3. Reproduced with permission from Ref. [44]. Copyright 2018, American Chemical Society 

45]. _X_ -site regulation is the most widely used approach for adjusting perovskite bandgap. As the X ions in  MAPbX3 vary from I to Br to Cl, the bandgap will increase from 1.55 to 1.80 to 2.30 eV [46]. Particularly, as reported in previous literatures, the  MAPbI3-xClx perovskite shows similar bandgap with  MAPbI3. The reason for the minor effect of Cl-doping could be the little amount of Cl into the lattice [47]. Interestingly, for Br-rich organic–inorganic hybrid perovskites or all-inorganic perovskites, the Cl is capable of occupying _X_ -sites and further widening the bandgap, which is possibly due to that Cl can replace the Br but not I considering the difference in ion radius [48]. Generally, 

for hybrid perovskites with mixed halides and different A and B cations, the X site plays a more prominent impact on bandgap. For example, the WBG organic–inorganic hybrid perovskites are usually obtained by heavy Br doping. Certainly, if we fix the bandgap and reduce Br content, the Cs or MA content should be increased in  CsMAFAPbI3-xBrx systems. In addition to composition, the dimensionality of the crystal structure also dramatically influences the bandgap of perovskites [49]. It should be noted that the bandgap increases as the structural dimensionality decreases [50]. For example, in the quasi-two-dimensional (2D) perovskites, the bandgap increases as the _n_ value decreases [51]. 

© The authors 

https://doi.org/10.1007/s40820-023-01040-6 

Page 5 of 44 **70** 

Nano-Micro Lett. (2023) 15:70 

### **3  WBG Perovskites for Tandem Application** 

##### **3.1  Current Matching for Monolithic TSCs** 

The monolithic or named two-terminal (2-T) perovskitebased TSC is consisted of a WBG PSC, a narrow-bandgap solar cell such as Si, a recombination layer, and a transparent electrode [52]. The WBG absorber harvests high-energy photons, and the transmitted low-energy photons are captured by NBG absorber. The opposite charge carriers produced by the two sub-cells arrive at the recombination layer, thus achieving monolithic circuit [53, 54]. The _V_ OC of the 2-T tandems is equal to the sum of the _V_ OC of the two subcells. Whereas, the short-circuit current ( _J_ SC) of a 2-T TSC is limited by the sub-cell with lowest _J_ SC. Therefore, the current matching is extremely important for 2-T TSCs, which means that the bandgap and the thickness of the two absorbers require precise combination. For the above mentioned four types of 2-T perovskite-based TSCs, owing to the different bandgaps of NBG absorbers, the corresponding optimum bandgaps of WBG perovskites are also different (Fig. 3a) [55]. For Si and CIGS with similar bandgap of 1.10 eV, the required bandgap of front perovskite absorber is about 1.68 eV. For all-perovskite TSCs, the bandgaps of WBG and NBG perovskites are about 1.78 and 1.25 eV, respectively [56]. And for perovskite/organic TSCs, the absorption cutoff edge of organic heterojunction locates at 950 nm, and the matched bandgap of perovskite is about 1.80 eV [15]. Table 1 summarized the performance data of highly efficient perovskite-based TSCs. 

##### **3.2** **_V_ OC Deficit** 

In contrast to the normal bandgap PSCs, WBG PSCs suffer from more serious _V_ OC loss, which significantly affect the efficiency improvement [57]. As is known to all, the _V_ OC is determined by the quasi-Fermi level ( _E_ F) splitting of the perovskite under illumination [58]. The WBG perovskites are expected to offer higher _V_ OC. For WBG perovskites, the CBM and VBM are up and down shifted in some degree, respectively. When contacts with charge transport layers, the quasi- _E_ F of WBG perovskite is counterbalanced. The relatively larger energy gap between perovskite and charge transport layers (CTLs) 

would arise energy loss and interfacial non-radiative charge recombination [59]. Therefore, desirable energy level matching between perovskite and CTLs is essential for higher _V_ OC. Moreover, the trap-assisted non-radiative recombination is recognized as the major killer for _V_ OC [60]. Deep-level trap states in the forbidden band will retard quasi- _E_ F splitting and suppress initial radiative efficiency, thus dramatically limits the _V_ OC improvement. Since grain boundaries and film surface accommodate amounts of trap states during the film formation, passivating these defects is preferred to suppress non-radiative recombination and reduce _V_ OC loss (Fig. 3b) [61]. 

##### **3.3  Photo‑induced Phase Segregation** 

For most WBG perovskites in TSCs, they are Br-rich organic–inorganic hybrid perovskites, which undergo phase separation and arise lower bandgap I-rich and higher-bandgap Br-rich domains under continuous illumination (Fig. 3c) [62–65]. Upon the formation of I-rich region, they would act as the carrier recombination centers irrespective of the carrier generation position in the mixed halide perovskites. This is in consistent with the results of photoluminescence (PL) measurements, which reveals the red shift of PL emission peaks after lightsoaking [66, 67]. In other words, the generated charge carriers would quickly thermalize and accumulate upon encountering any I-rich region. The difference in band structure between uniformly mixed perovskite and I-rich region could also create an electric field that might further help to sweep more carriers into the I-rich region. Hence, nearly all of the PL emission of light-soaked perovskites should come from the radiative relaxation of carriers trapped in I-rich regions. It is believed that the phase segregation is originated from halide migration via halide vacancy, which is more facile at grain boundaries [68–70]. Some results also suggested employing FA or Cs instead of MA as the A-site cation can significantly enhance the photostability, and improving the spatial homogeneity to release lattice microstrain and increase kinetic barrier for ion migration might eliminate or slow phase segregation [71]. Therefore, optimizing the composition and lattice structure, improving crystallinity and compositional uniformity, and reducing trap state density could significantly improve the photostability. 

1 3 

**70** Page 6 of 44 

Nano-Micro Lett. (2023) 15:70 



**Fig. 3  a** Theoretical efficiency limit for 2-T tandems. Reproduced with permission from Ref. [55]. Copyright 2018, Nature Publishing Group. **b** Defects (imperfections) in perovskite film and their passivation strategies. Reproduced with permission from Ref. [61]. Copyright 2019, Royal Society of Chemistry. **c** Phase segregation and corresponding charge transfer behavior. Reproduced with permission from Ref. [62]. Copyright 2016, American Chemical Society 

##### **3.4  Crystallization Control** 

##### **3.5  Long‑Term Stability** 

It is well known that the quality of perovskite films directly determines the efficiency and stability of the PSCs. Different from normal-bandgap perovskites, the solution-processed Br-rich WBG perovskites undergo faster crystallization, which would result in inferior crystallinity, more trap states and irreversible microstrain [72]. The trapstates would act as non-radiative recombination centers to impede the improvement of device performance [60, 61]. Modulating the perovskite crystal growth and suppressing the formation of defects are the major approaches to obtain high-quality WBG perovskite films [73]. Interface engineering and additive engineering are promising strategies to modulate crystallization and passivate defects. 

The major challenge for the commercialization of WBG PSCs and TSCs is the inferior long-term operation stability compared to commercial silicon solar cells [74]. The factors influencing the device stability could be divided into intrinsic phase stability issues and external factors such as UV light, oxygen, moisture, temperature [75, 76]. The organic–inorganic halide perovskites perform poor thermal, air, and light stabilities due to the ionic crystal nature [77]. High-quality perovskite film is fundamentally important for long-term stability. It has been demonstrated that strategies such as compositional engineering, structural engineering and additive engineering can significantly enhance the stability of the PSCs. In addition, the instability of charge transport layers (CTLs) is another key degradation pathway for 

© The authors 

https://doi.org/10.1007/s40820-023-01040-6 

Page 7 of 44 **70** 

Nano-Micro Lett. (2023) 15:70 

**Table 1** Summary of highly efficient perovskite-based TSCs 

|Top Cell|Bottom Cell|_V_OC<br>(V)|_J_SC<br>(mA  cm<sup>−2</sup>)|FF (%)|PCE (%)|References|
|---|---|---|---|---|---|---|
|Cs0.22FA0.78PbI2.55Br0.45|Si|1.886|19.12|75.3|27.13|[99]|
|Cs0.22FA0.78Pb(I0.85Br0.15)3|Si|1.86|19.23|76.22|27.26|[100]|
|Cs0.15(FA0.83MA0.17)0.85Pb(I0.8Br0.2)3|Si|1.80|17.8|79.4|25.4|[141]|
|Cs0.1FA0.2MA0.7Pb(I0.85Br0.15)3|Si|1.92|18.95|78.5|28.56|[147]|
|(FA0.65MA0.20Cs0.15)Pb(I0.8Br0.2)3|Si|1.756|19.1|79.2|26.7|[149]|
|Cs0.05FA0.8MA0.15Pb(I0.75Br0.25)3|Si|1.870|19.6|78.6|28.9|[156]|
|Cs0.22FA0.78Pb(I0.85Br0.15)3|Si|1.185|18.04|80.76|26.95|[69]|
|Cs0.05FA0.8MA0.15Pb(I0.75Br0.25)3|Si|1.790|19.5|79.6|27.8|[177]|
|FA0.75Cs0.25Pb(I0.8Br0.2)3|Si|1.77|18.4|77|25.0|[178]|
|NA|Si|1.794|20.11|79.95|28.84|[188]|
|FA0.8Cs0.2PbI1.8Br1.2|Si|1.75|18.4|78.9|25.4|[191]|
|Cs0.05MA0.15FA0.8Pb(I0.85Br0.15)3|Si|1.828|19.5|75.9|27.1|[198]|
|Cs0.15FA0.85Pb(I0.75Br0.27)3|Si|1.808|19.78|76.85|27.48|[194]|
|Cs0.15MA0.15FA0.7Pb(I0.8Br0.2)3|Si|1.84|19.6|76.0|27.4|[224]|
|Cs0.05(FA0.77MA0.23)0.95Pb(I0.77Br0.23)3|Si|1.90|19.23|79.4|29.01|[107]|
|Cs0.05FA0.8MA0.15Pb(I0.755Br0.255)3|Si|1.92|19.8|80.7|30.5|[13]|
|FAxCs1-xPb(IyBr1-y)3|Si|1.83|18.99|79.46|27.64|[238]|
|CsxFA1−xPb(I,Br)3|Si|1.788|19.53|73.1|25.52|[193]|
|Cs0.05MA0.15FA0.8PbI2.25Br0.75|Si|1.70|19.8|77|26.0|[243]|
|Cs0.1MA0.9Pb(I0.9Br0.1)3|Si|1.82|19.2|75.3|26.2|[180]|
|DMA0.1FA0.6Cs0.3PbI2.4Br0.6|PVK|1.88|16.0|77|23.1|[82]|
|DMA0.1Cs0.4Br0.25Cl0.05|PVK|2.046|16.0|80.1|26.2|[72]|
|FA0.8Cs0.2PbI1.8Br1.2|PVK|2.0|15.6|79.9|24.9|[191]|
|Cs0.4FA0.6PbI1.95Br1.05|PVK|2.03|15.2|79.7|24.6|[199]|
|Cs0.35FA0.65PbI1.8Br1.2|PVK|2.025|15.4|79.4|24.8|[110]|
|Cs0.05(MA0.17FA0.83)0.95Pb(I0.83Br0.17)3|GIGS|1.68|19.17|71.9|23.16|[183]|
|Cs0.05(MA0.23FA0.77)Pb1.1(I0.77Br0.23)3|GIGS|1.77|18.8|71.2|23.7|[29]|
|Cs0.09FA0.77MA0.14Pb(I0.86Br0.14)3|GIGS|1.774|17.3|73.1|22.43|[9]|
|MA0.96FA0.1PbI2Br(SCN)0.12|OPV|1.96|13.8|78.4|21.2|[80]|
|CsPbI2Br|OPV|2.22|12.68|76.0|21.4|[119]|
|CsPbI1.8Br1.2|OPV|2.05|13.36|76.82|21.04|[120]|
|FA0.6MA0.4Pb(I0.6Br0.4)3|OPV|1.88|15.7|74.6|22.0|[148]|



WBG PSCs [78]. Chemically stable CTLs are also crucial for improving the long-term stability of WBG PSCs and TSCs. 

### **4  Optimization for WBG Perovskites** 

##### **4.1  Composition Engineering** 

The composition of WBG perovskites plays a critical role in the device performance because various perovskites in spite of similar bandgap might present different crystal and 

electronic structures, which might influence the formation of trap states in the perovskite films [79–82]. These trap states are directly responsible for the non-radiative recombination and instability issues. Therefore, it is of great significance to investigate the deep relationship between composition and device performance of WBG PSCs, which is fundamentally important for providing more efficient and pointed guidance for the further optimization [83–85]. 

The early research on WBG perovskites mainly focused on  MAPbI3-xBrx. In 2015, Heo et al _._ reported a 2-T allperovskite TSC employing a  MAPbBr3 front cell and a MAPbI3 rear cell, which delivered a PCE of 10.4% with 

1 3 

**70** Page 8 of 44 

Nano-Micro Lett. (2023) 15:70 

a high _V_ OC of 2.25 V (Fig. 4a) [86]. Huang’s group tuned the bandgap of  MAPbI3-xBrx to 1.72 eV via two-step preparation method, in which the MABr and MAI mixed isopropanol solution with different blend ratios were spincoated onto the  PbI2 layer, followed by solvent annealing process [87]. And the target  MAPbI2.4Br0.6 solar cell demonstrated a PCE of 13.1%. Zhu et al _._ prepared a 1.75 eV bandgap  MAPbI2.1Br0.9 perovskite film via a facile halide exchange route, that is, a parent  MAPbI3 film was firstly deposited, and then dipped into MABr isopropanol solution for halide exchange with different reaction time [88]. This approach contributes to more dense and homogenous film with vertically oriented crystals as compared with one-step preparation method, and a 12.67% efficiency was obtained. Since the  (FAPbI3)0.85(MAPbBr3)0.15 was firstly reported, the FA-based perovskites gradually replaced the MA system as the focus due to the higher efficiency and better stability [89]. And inorganic Cs and Rb cations were also incorporated to further modulate the crystallization and improve the device performance [90–92]. Forgács et al _._ presented a 2-T all-perovskite TSC by using 2.0 eV bandgap  Cs0.15FA0.85Pb(I0.3Br0.7)3 as the front absorber, which delivered PCEs of 10.7% and 15.6% for single-junction and tandem solar cells, respectively (Fig. 4b) [93, 94]. Later, they further improved the PCE of  Cs0.15FA0.85Pb(I0.3Br0.7)3 solar cells up to 11.5% [95]. McMeekin et al _._ found that partially substituting the FA with Cs can eliminate the phase instability region in the I-to-Br compositional range, over which the variation in composition, lattice constant, and bandgap precisely follows Vegard’s law (Fig. 4c-f) [96]. The  Cs0.17FA0.83Pb(I0.6Br0.4)3 perovskite exhibited a 1.74 eV bandgap and gave a PCE of 17.1% with 1.2 V _V_ OC, as a result of the suppressed phase separation. Yang et al _._ demonstrated that the use of non-stoichiometric precursor with excess MABr or MACl can significantly improve the crystallinity of  Cs0.17FA0.83Pb(I0.6Br0.4)3 perovskite but without affecting the bandgap [97]. In contrast, an obvious reduction in bandgap was observed when excess MAI was added, which was resulted from the substitution of Br with I. Consequently, the MABr incorporated  Cs0.17FA0.83Pb(I0.6Br0.4)3 solar cell delivered a highest stabilized PCE of 16.4%. 

As either the incorporation of Cs or Br can enlarge the bandgap, there should be a ideal Cs/Br ratio to simultaneously improve _V_ OC and photostability. In view of this, Bush et al _._ systematically investigated the device performance of  CsxFA1-xPb(BryI1-y)3 with various A and X sites 

compositions [98]. It was revealed that Cs17/Br25 and Cs25/Br20 perovskites with bandgap of 1.68 eV demonstrate different performance, so as the Cs17/Br40 and Cs40/ Br30 with bandgap of 1.75 eV. For the two conditions, the slightly high Cs and low Br gifts higher _V_ OC. Moreover, the PL results showed that high Cs and low Br results in better photostability, while low Cs and high Br leads to remarkable halide segregation (Fig. 4g). For the target bandgaps of 1.68 eV and 1.75 eV for tandem application, the Cs25/ Br20 and Cs40/Br30 afforded higher PCEs of 17.4% and 16.3%, respectively, and significantly improved photostability. In order to further decrease the Br content and retain desirable bandgap for perovskite/silicon tandems, Xu et al _._ proposed a triple-halide alloys (I, Br, Cl) method to tailor the bandgap via introducing additional 3 mol%  MAPbCl3 into Cs0.22FA0.78Pb(I0.85Br0.15)3 perovskite [99]. The resulted perovskite film shows a enlarged bandgap from 1.63 to 1.67 eV, increased carrier lifetime and mobility, and suppressed light-induced phase segregation (Fig. 4h). As a result, the single-junction and perovskite/silicon solar cells offered PCEs of 20.42% and 27%, respectively. Based on this recipe, Li et al _._ added 3 mol% inorganic  CsPbCl3-clusters instead of  MAPbCl3 into the perovskite precursor, and obtained a 1.67 eV bandgap as well [100]. Moreover, they further added extra 2 mol% CsCl to enrich the NiO/perovskite interface with Cl, thus suppressing the redox reaction at the interface. The reduction in interfacial non-radiative recombination effectively improves _V_ OC. Consequently, the PCE of singlejunction solar cell improves from 17.82% to 19.76%, giving rise to a 27.26% efficiency for perovskite/silicon tandem cell. Besides, it can be concluded that  PbCl2 but not MACl and CsCl plays a critical role in tailoring the bandgap of Br-rich WBG perovskites. 

In addition to  CsxFA1-xPbI3-yBry WBG systems, mixed A-sites CsMAFA compositions were also widely investigated. Zhou and co-workers prepared four WBG perovskites with different bandgaps, that are  FA0.48MA0.37Cs0.15PbI2.23Br0.77 (1.65 eV),  FA 0.57MA 0.43PbI 2.4Br 0.96 (1.69 eV), FA 0.5MA 0.38Cs 0.12PbI 2.04Br 0.96 (1.69 eV) and FA0.51MA0.38Cs0.11PbI1.85Br1.15 (1.72 eV) for 2-T perovskite/silicon TSCs, wherein the perovskite with 1.69 eV bandgap delivered the best efficiency [101]. Though the FA0.57MA0.43PbI2.4Br0.96 and  FA0.5MA0.38Cs0.12PbI2.04Br0.96 have similar bandgap, the Cs-contained system exhibits much higher carrier lifetime than that of composition without Cs, highlighting the effectiveness of triple A-site 

© The authors 

https://doi.org/10.1007/s40820-023-01040-6 

Page 9 of 44 **70** 

Nano-Micro Lett. (2023) 15:70 



**Fig. 4  a** Device structure of  MAPbBr3-MAPbI3 2-T tandem cell. Reproduced with permission from Ref. [86]. Copyright 2016, Wiley–VCH. **b** Device structure of  Cs0.15FA0.85Pb(I0.3Br0.7)3-MAPbI3 2-T tandem cell. Reproduced with permission from Ref. [93]. Copyright 2017, Wiley– VCH. Photographs of perovskite films with Br composition increasing from x = 0 to 1 for **c** FAPb[I(1-x)Brx]3 and **d** FA0.83Cs0.17Pb[I(1-x)Brx]3. **e** Uv–vis absorption spectra of films of  FAPb[I(1-x)Brx]3 and  FA0.83Cs0.17Pb[I(1-x)Brx]3. **f** XRD pattern of  FAPb[I(1-x)Brx]3 and FA0.83Cs0.17Pb[I(1-x)Brx]3. Reproduced with permission from Ref. [96]. Copyright 2015, Science Publishing Group. **g** PL spectra of Cs17/Br25, Cs25/Br20, Cs17/Br40, Cs40/Br30 perovskites. The initial PL peak is shown as the orange dashed curve. Reproduced with permission from Ref. [98]. Copyright 2018, American Chemical Society. **h** PL spectra of control perovskite films (Cs25Br20) and triple-halide perovskites (Cs22Br15 + Cl3) under 10-sun and 100-sun illumination for 20 min, respectively. Reproduced with permission from Ref. [99]. Copyright 2020, Science Publishing Group 

strategy for high-performance PSCs. Chen et al _._ reported four WBG perovskites with different A-site combinations and fixed Br content, that are  Cs0.6MA0.4Pb(I0.6Br0.4)3, Cs0.6FA0.4Pb(I0.6Br0.4)3,  MA0.6FA0.4Pb(I0.6Br0.4)3 and FA0.6MA0.4Pb(I0.6Br0.4)3 [102]. Interestingly, they found that the Cs-MA and Cs-FA combinations demonstrate better photostability than that of MA-FA combinations, but the MA-FA device delivered the highest _V_ OC and PCE. It has been proposed that the collective rotation of dipolar MA<sup>+</sup> in  MAPbX3 perovskites can enhance charge transport owing to the formation of large polarons or the spatially localized carriers [103]. The liquid-like reorientation and 

dipolar disorder of  MA<sup>+</sup> can protect hot carriers and increase the dielectric constants for  MAPbX3 perovskites [86] 104. Moreover, calculations also revealed that the deep traps in MAPbI3 can be healed by dynamic rotation of  MA<sup>+</sup> [105]. Inspired by these studies, Tan et al _._ demonstrated that the higher density of deep traps in the WBG perovskites than that of sub-1.6 eV bandgap PSCs causes the inferior performance, and they proposed that increasing the defect tolerance via A-site engineering can heal the deep traps and enable further performance improvement for WBG PSCs [106]. They elucidated that the reorientation of dipolar MA<sup>+</sup> can eliminate or render innocuously shallow electronic 

1 3 

**70** Page 10 of 44 

Nano-Micro Lett. (2023) 15:70 

states, which could evolve into deep traps if the MA is absent (Fig. 5a). Consequently, the  Cs0.2FA0.8Pb(I0.75Br0.25)3 (1.67 eV),  Cs 0.05MA 0.15FA 0.8Pb(I 0.75Br 0.25) 3 (1.65 eV),  Cs0.17FA0.83Pb(I0.6Br0.4)3 (1.74 eV) and Cs0.12MA0.05FA0.83Pb(I0.6Br0.4)3 (1.74 eV) solar cells offered PCEs of 18.5%, 20.8%, 17.2% and 19.3%, respectively. Carefully comparing the device performance of WBG PSCs with various compositions (Table 2), we can found that despite of similar bandgap, the CsMAFA system performs better than CsFA in respect of efficiency. For more examples, Al-Ashouri et al _._ employed  Cs0.05(FA0.77MA0.23)0.95Pb(I0.77Br0.23)3 perovskite as the front absorber, the single-junction solar cell gave a PCE of 20.8%, and the 2-T perovskite/silicon tandem solar cell achieved an impressive PCE of 29.15% [107]. Also, Liu et al _._ adopted  Cs0.05FA0.8MA0.15Pb(I0.75Br0.25)3 perovskite as the front cell, which offered 20.46% and 29.3% efficiencies for single-junction and tandem solar cells, respectively [13]. The detailed discussion of these two works will be introduced in the following part of “ _Interface engineering_ ”. This interesting phenomenon deserves deep excavation. For CsFA systems, in order to avoid too much Br content that account for photo-instability, heavy Cs-doping (> 15%) is commonly required for the desirable wide bandgap. As thus, there is a innegligible size mismatching in ionic radius, 1.88 Å for  Cs<sup>+</sup> and 2.53 Å for  FA<sup>+</sup> , which would induce  PbX6 octahedra tilting and lattice microstrain (Fig. 5b) [108]. For instance, both of  FA0.85Cs0.15PbI3 and FA0.75Cs0.25PbI3 are assigned to tetragonal space group P4/ mbm, indicating a reduction in the metal-halide-metal bond angle below 180° that for a cubic structure. Considering the _σ_ * interaction in the metal-halide orbital overlap, the reduction in the bond angle will reduce the degree of overlap between metal and halide orbitals, pushing the valence band toward lower energy and increasing the bandgap as the Cs substitution increases. Whereas, for CsMAFA systems, the relatively lower Cs content leads to less octahedra tilting. Moreover, the  MA<sup>+</sup> (2.17 Å) would act as buffer cations to minimize the size mismatch between  Cs<sup>+</sup> and FA<sup>+</sup> and thus, further suppress the octahedra tilting. The larger octahedra tilting in the heavy Cs-doped CsFA system than that of CsMAFA might introduce additional trap states and thus, sacrifice the _V_ OC and PCE. Whereas, Cs-rich and low-Br WBG perovskites deserve further exploration because of their great potential for highly efficient and photostable PSCs. Therefore, choosing suitable A-site cations 

to eliminate size mismatch is a promising strategy for Csrich PSCs. In addition to  MA<sup>+</sup> ,  DMA<sup>+</sup> ,  EA<sup>+</sup> and  Gua<sup>+</sup> , etc _._ , were also reported to improve the structural stability [82, 109]. Palmstrom and co-workers incorporated 10% DMA into CsFA perovskite to enable a 1.70 eV bandgap, and the  Cs0.3FA0.6DMA0.1PbI2.4Br0.6 solar cell delivered a PCE of 19.6% [82]. Wen et al _._ reported 1.70 eV bandgap PSC with a composition of  Cs0.3FA0.6DMA0.05Gua0.05I2.4Br0.6, which gave a PCE of 20.1% with high _V_ OC of 1.226 V. Tan’ group proposed a steric engineering strategy via introducing 10 mol% DMA and 5 mol% Cl into  Cs0.4FA0.6Pb(I0.75Br0.25)3, to simultaneously realize bandgap tuning and strain relaxation [72]. The resulted film shows a 1.80 eV bandgap with only 25% Br. The co-incorporation of DMA and Cl can significantly promote the strain relaxation, thus suppressing the light-induced halide segregation (Fig. 5c, d) and improving the carrier lifetime (Fig. 5e). The WBG single-junction cell afforded a PCE of 17.7% with a high _V_ OC of 1.26 V, giving rise to a stabilized PCE of 26.0% for all-perovskite TSCs. Moreover, this group systematically tuned the Cs ratio of a MA-free 1.8 eV perovskite, in which the homogeneity of crystallization was effectively improved for the blade-coated Cs0.35FA0.65PbI1.8Br1.2 films over large area (20  cm<sup>2</sup> ) [110]. And the all-perovskite tandem solar modules gave a high PCE of 21.7%. The mixed-halide perovskites suffer from the severe phase segregation, leading to I-rich and Br-rich phases under continuous illumination. Ji et al _._ reported pureiodide WBG perovskites which can fundamentally solve the photo-instability issue [111]. Through further controlling precipitation kinetics of the crystallization process, the Cs0.3DMA0.2MA0.5PbI3 perovskite/silicon TSC gave a PCE of 29.4% with excellent photostability. 

Except from organic–inorganic halide perovskites, allinorganic perovskites like  CsPbI3,  CsPbI2Br and  CsPbBr3 have also attracted extensive attention due to their excellent thermal stability and the potential for tandem applications [112–116]. The bandgap of  CsPbI3 perovskite ranges from 1.68 to 1.73 eV depending on the degree of  PbI6 octahedral tilting. The desirable bandgap without Br incorporation makes  CsPbI3 a promising candidate for perovskite/silicon tandems. Whereas, the major challenge for  CsPbI3-xBrx PSCs is the fraught phase stability against moisture due to its relatively low structural tolerance factor. In addition, preparing stable α-phase all-inorganic perovskites commonly requires high annealing temperature (> 200 °C), which 

© The authors 

https://doi.org/10.1007/s40820-023-01040-6 

Page 11 of 44 **70** 

Nano-Micro Lett. (2023) 15:70 



**Fig. 5  a** Density of states (DOS) of CsFA and CsMAFA perovskites in the case of anti-site defects. Reproduced with permission from Ref. [106]. Copyright 2018, Nature Publishing Group. **b** Perovskite lattice diagrams: undistorted cubic (center panel), with lattice contraction (left panel) and with octahedral tilting (right panel). Below each lattice is a schematic energy level diagram, showing how each kind of distortion affects the valence and conduction bands. Reproduced with permission from Ref. [108]. Copyright 2017, American Chemical Society. XRD patterns and magnified (110) diffraction peaks (inset) of **c** DMA0.1Cs0.4Br0.25Cl0.05 and **d** Cs0.2Br0.4 perovskite films under dark and 1 sun illumination. **e** TRPL spectra of  Cs0.4Br0.25,  DMA0.1Cs0.4Br0.25,  Cs0.4Br0.25Cl0.05, and  DMA0.1Cs0.4Br0.25Cl0.05 perovskite films on glass substrates. Reproduced with permission from Ref. [72]. Copyright 2022, Wiley–VCH 

might damage the underlying silicon cells. Also, for the sake of ideal light management, perovskite-based 2-T TSCs prefer _p-i-n_ inverted PSCs. Because the hole transport layers like Spiro-OMeTAD and PTAA for the _n-i-p_ structure is quite thick (~ 200 nm), which would arise additional parasitic absorption. The efficiency of all-inorganic PSCs with _p-i-n_ structure lags behind that of _n-i-p_ structure. Possibly considering the above concerns, there is still no report about CsPbI3-xBrx based perovskite/silicon or CIGS, or all-perovskite tandems, which need be further exploited. Particularly, CsPbI3-xBrx/organic TSCs have been developed to improve the efficiency, and the  CsPbI3-xBrx front cell can harvest short-wavelength photons that might induce instability 

of organic solar cells. Ding’ group firstly demonstrated a CsPbI2Br/PTB7-Th:COi8DFIC:PC71BM tandem solar cells and delivered a PCE of 15.04% (Fig. 6a) [117]. Later, they further achieved a higher PCE of 20.18% with 2.05 V _V_ OC based on  CsPbI2Br perovskite and D18:Y6 organic solar cell [118]. To date, the highest efficiency  CsPbI2Br-based perovskite/organic TSCs was reported by Zhou’ group, which presented a PCE of 21.4% with an extremely high _V_ OC of 2.22 V (Fig. 6b) [119]. Besides,  CsPbI1.8Br1.2 has also been employed for perovskite/organic TSCs, and a PCE of 21.04% was obtained (Fig. 6c) [120]. 

1 3 

**70** Page 12 of 44 

Nano-Micro Lett. (2023) 15:70 

**Table 2** Summary of WBG organic–inorganic hybrid PSCs employing composition engineering 

|Perovskite|_E_g(eV)|_V_OC<br>(V)|_J_SC<br>(mA  cm<sup>−2</sup>)|FF<br>(%)|PCE (%)|References|
|---|---|---|---|---|---|---|
|Rb0.05(Cs0.05MA0.17FA0.83)0.95Pb(I0.83Br0.17)3|1.63|1.186|22.5|77|20.6|[90]|
|Cs0.05MA0.15FA0.8Pb(I0.75Br0.25)3|1.65|1.22|21.2|80.5|20.8|[106]|
|(FAPbI3)0.85(MAPbBr3)0.2|1.67|1.14|21.15|77.49|18.68|[79]|
|Cs0.22FA0.78PbI2.55Br0.45|1.67|1.217|20.18|83.16|20.42|[99]|
|Cs0.22FA0.78Pb(I0.85Br0.15)3|1.67|1.19|20.33|81.7|19.76|[100]|
|Cs0.2FA0.8Pb(I0.75Br0.25)3|1.67|1.17|20.4|77.3|18.5|[106]|
|Cs0.25FA0.75Pb(I0.8Br0.2)3|1.68|1.10|19.4|81|17.4|[98]|
|Cs0.05(FA0.77MA0.23)0.95Pb(I0.77Br0.23)3|1.68|1.224|20.7|82.0|20.8|[107]|
|Cs0.05FA0.8MA0.15Pb(I0.755Br0.255)3|1.69|1.226|20.58|81.1|20.46|[13]|
|DMA0.1FA0.6Cs0.3PbI2.4Br0.6|1.70|1.20|19.6|82|19.2|[82]|
|MA0.96FA0.1PbI2Br(SCN)0.12|1.72|1.19|18.65|78.4|17.4|[80]|
|MAPbI2.4Br0.6|1.72|1.02|17.5|73.7|13.1|[87]|
|FA0.83Cs0.17Pb(I0.6Br0.4)3|1.74|1.2|19.4|75.1|17.1|[96]|
|Cs0.17FA0.83Pb(I0.6Br0.4)3|1.74|1.22|18.7|75.6|17.2|[106]|
|Cs0.12MA0.05FA0.83Pb(I0.6Br0.4)3|1.74|1.25|19.0|81.5|19.3|[106]|
|MAPbI2.1Br0.9|1.75|1.01|18.19|69|12.67|[88]|
|FA0.83Cs0.17Pb(I0.6Br0.4)3|1.75|NA|17.97|NA|16.77|[97]|
|Cs0.4FA0.6Pb(I0.7Br0.3)3|1.75|1.17|17.5|80|16.3|[98]|
|MA0.6FA0.4Pb(I0.6Br0.4)3|1.75|1.17|16.0|78.6|14.7|[102]|
|Cs0.6MA0.4Pb(I0.6Br0.4)3|1.75|1.17|13.9|68.3|11.1|[102]|
|Cs0.6FA0.4Pb(I0.6Br0.4)3|1.75|1.12|14.0|77.4|12.1|[102]|
|(FA0.58GA0.10Cs0.32)Pb(I0.73Br0.27)3|1.75|1.22|16.3|73.2|14.6|[109]|
|DMA0.1Cs0.4Br0.25Cl0.05|1.8|1.263|17.4|79.7|17.7|[72]|
|MA0.9FA0.1Pb(I0.6Br0.4)3|1.81|1.21|17.8|79.5|17.1|[85]|
|Cs0.15FA0.85Pb(I0.3Br0.7)3|2|1.215|11.41|81.2|10.7|[93]|
|Cs0.15FA0.85Pb(I0.3Br0.7)3|2|1.18|12.32|79.0|11.5|[95]|
|MAPbIBr2|2.05|1.08|15.3|64.7|10.7|[94]|
|MAPbBr3|2.25|1.08|8.6|78|7.2|[86]|



##### **4.2  Additive Engineering** 

Additive engineering has been widely used to modulate crystallization and passivate defects via various chemical interactions to improve the efficiency and stability of PSCs [121–124]. For WBG perovskites, the heavy Cs or Br contents would dramatically accelerate the crystallization process, resulting in inferior crystallinity, rough surface and more trap states, which can significantly limit the _V_ OC improvement and photostability of the devices [125]. Therefore, simultaneously optimizing the crystallization and passivating defects of WBG perovskite films via additive engineering is of great significance for high-performance PSCs. 

Potassium  (K<sup>+</sup> ) ion doping has been identified as an effective approach to suppress _J-V_ hysteresis and improve 

photostability. Tang et al _._ firstly explored the influence of K<sup>+</sup> incorporation on the crystal structure and optical properties of perovskite films [126]. They observed the elongation of crystal lattice after  K<sup>+</sup> doping, which is opposite to the perovskites containing  Cs<sup>+</sup> and  Rb<sup>+</sup> . Meanwhile, the absorption edge of the  K<sup>+</sup> -doped film presented a red shift, indicating the decrease in bandgap. Most importantly, the conduction band minimum (CBM) matched well with the  TiO2 layer, which is conducive to charge transfer, thus diminishing the _J-V_ hysteresis. They hold the opinion that low concentration  K<sup>+</sup> was homogeneously incorporated into the crystal structure. Later,  K<sup>+</sup> attracted extensive interests for improving device performance of PSCs. Zhong and co-workers demonstrated that the hysteresis in PSCs can be completely removed by  K<sup>+</sup> irrespective of the electron 

© The authors 

https://doi.org/10.1007/s40820-023-01040-6 

Page 13 of 44 **70** 

Nano-Micro Lett. (2023) 15:70 



**Fig. 6  a** Schematic for 2-T perovskite/organic TSC. Reproduced with permission from Ref. [117]. Copyright 2019, Elsevier. **b** Device structure and energy levels diagram of  CsPbI2Br/organic TSC. Reproduced with permission from Ref. [119]. Copyright 2022, Elsevier. **c** Left: device structure of all-inorganic perovskite/organic TSC. Right: crystal structure of  CsPbI1.8Br1.2 perovskite and the molecular structures of the donor and acceptor materials. Reproduced with permission from Ref. [120]. Copyright 2022, Wiley–VCH 

transport layers [127]. The  K<sup>+</sup> can intensively improve the crystallization with grain size up to 1 μm, reduce the defect density, prolong the carrier lifetime and promote charge transport, contributing to the hysteresis-free stable and high efficiency PSCs. Son et al _._ proposed that the atomistic origin of the hysteresis of PSCs is the formation of iodide Frenkel defect but not the migration of iodide vacancy, and  K<sup>+</sup> is capable of inhibiting the formation of Frenkel defect because K<sup>+</sup> energetically prefers the interstitial sites (Fig. 7a) [128]. Moreover, the suppression of hysteresis is more pronounced for mixed perovskites than that of pure perovskites due to the lower formation energy of  K<sup>+</sup> interstitial (−1.17 V for mixed perovskite and −0.65 V for  MAPbI3) (Fig. 7b). Combining experimental and theoretical investigation, Cao et al _._ reported the size-dependent interstitial occupancy of extrinsic alkali cations  (Li<sup>+</sup> ,  Na<sup>+</sup> ,  K<sup>+</sup> and  Rb<sup>+</sup> ) incorporated into the CsMAFA perovskite [129]. Since these alkali cations are unfavorable for ideal Goldschmidt tolerance factor when occupy the A site of the Pb-I network due to small ionic radius, they attributed the lattice expansion to the interstitial occupancy by the alkali cations, which was confirmed by DFT calculations that interstitial occupancy is energetically more favorable than A site substitution (Fig. 7c). Furthermore, the calculations and characterization corroborated 

that the increased ion migration barriers after the interstitial occupancy account for the suppression of ion migration, and thus, the elimination of hysteresis. Abdi-Jalebi et al _._ proposed that the  K<sup>+</sup> doping in mixed perovskites can reduce non-radiative loss and light-induced ion migration by passivating the grain boundary and surface with potassium halide layers [130]. According to their point of view, the  K<sup>+</sup> doping would produce KI/KBr compounds that mainly distribute at grain boundary and surface (Fig. 7d), thus to immobilize the halide ions and vacancies, which is mutually contradictory to the above interstitial occupancy theory. Coincidentally, Kubicki et al _._ provided atomic-level characterization for the first time of  K<sup>+</sup> -doped multi-cation and multi-anion perovskites [131]. The results unambiguously revealed that there is no evidence of  K<sup>+</sup> incorporation into the 3D perovskite, but the formation of non-perovskite  KPbI3 (for iodide-based perovskites), mixed-K/Cs non-perovskite phase (for compositions containing Cs), or a mixture of KI and KBr (for mixed iodide-bromide perovskites). These secondary nonperovskite phases lead to variety in the composition of the pristine perovskite and in turn to shifts in XRD, PL, XPS and UPS spectra. In order to elucidate the mechanism of these K<sup>+</sup> doping effects for PSCs, Zheng et al _._ combined ultrafast, time-resolved, and microspectroscopic techniques to 

1 3 

**70** Page 14 of 44 

Nano-Micro Lett. (2023) 15:70 



**Fig. 7  a** Schematic of the Frenkel defect passivated by  K<sup>+</sup> . **b** Current–voltage curves of PSCs employing different perovskite materials with and without  K<sup>+</sup> doping. Reproduced with permission from Ref. [128]. Copyright 2018, American Chemical Society. **c** Schematics of the doping mechanism of Cs/MA/FA perovskite doped with  Cs<sup>+</sup> ,  Rb<sup>+</sup> , and  K<sup>+</sup> . Reproduced with permission from Ref. [129]. Copyright 2018, Wiley–VCH. **d** Schematic of the passivation mechanism of  K<sup>+</sup> , in which the surplus halide is immobilized through complexing with potassium into benign compounds at the grain boundaries and surfaces. Reproduced with permission from Ref. [130]. Copyright 2018, Nature Publishing Group. **e** Schematic of the passivation effect of  K<sup>+</sup> -doped perovskite under illumination. Reproduced with permission from Ref. [132]. Copyright 2019, Wiley–VCH 

dynamically monitor the changes of perovskite films under bias light illumination [132]. Different from the perovskite films without  K<sup>+</sup> doping, they detected a gradual halide ion substitution of  Br<sup>−</sup> by  I<sup>−</sup> under continuous illumination for the  K<sup>+</sup> doping case. And they proposed that illumination is essential to motivate the  K<sup>+</sup> passivation effect via forming immobile KBr-like compounds at the interfaces, leading to the reduction in interfacial defect density and suppression of ion migration (Fig. 7e), thus further results in improved PCE and negligible hysteresis. Besides, Wang et al _._ presented the formation of 2D  K2PbI4 at the grain boundaries of WBG perovskite films, which can reduce the defect density and prevent ion migration, and thus, suppress non-radiative 

recombination and light-induced phase segregation [133]. Despite various theories,  K<sup>+</sup> does improve efficiency and photostability of PSCs. In addition to  K<sup>+</sup> ,  Rb<sup>+</sup> also shows beneficial effect in enhancing the crystallinity, enlarging grain size, reducing the excess  PbI2 phase, as well as suppressing ion migration in WBG perovskite materials [134, 135]. 

Kim et al _._ added a formamide co-solvent into Cs-FA WBG perovskite precursor to control the crystallization aiming at suppressing light-induced phase segregation and hysteresis [136]. The highly polar formamide can bypass the yellow phase and induce direct formation of the black perovskite phase (Fig. 8a), thus reducing the trap density 

© The authors 

https://doi.org/10.1007/s40820-023-01040-6 

Page 15 of 44 **70** 

Nano-Micro Lett. (2023) 15:70 

in film. Consequently, the optimized WBG PSCs ( _E_ g ≈ 1.75 eV) afforded a high _V_ OC of 1.23 V and a PCE of 17.8% with reduced hysteresis. Meanwhile, the perovskite films demonstrated excellent photostability, thermal stability and long-term air stability. Tao et al _._ reported a stable ~ 1.73 eV bandgap MA-based WBG perovskite made from ionic liquid solvent, methylammonium acetate (MAAc) [137]. They revealed that the internal hydrogen bond (N–H···I and N–H···Br) environment in MAAc solvent over traditional DMF and DMSO solvents can stabilize the diffusion of halide ions, which favors the suppression of the light-induced halide segregation. Moreover, the hydrogen bonds can also enable excellent decoupling of the crystal nucleation and film growth, giving rise to a champion PCE of 20.59% with improved ambient light, thermal and air stability. Zhou et al _._ demonstrated that the photo-instability and _V_ OC loss can be addressed by combining crystallization control and grain boundary passivation [138]. They suggested that the Pb(SCN)2 additive can effectively enhance the crystallinity and grain size, while the excess FAX (X = I and Br) can passivate grain boundaries. The synergistic effects enable significantly improved carrier lifetime and suppressed photo-induced phase segregation. Xie et al _._ demonstrated that the Pb(SCN)2 additive can dramatically increase the grain size and inhibit the formation of pinholes in the MAbased WBG perovskite films [139]. And further introducing  Cs<sup>+</sup> cation into the precursor can effectively increase the solubility of  PbI2, thus suppressing the aggregation of  PbI2 particles induced by the Pb(SCN)2. The co-incorporation of Pb(SCN)2 and  Cs<sup>+</sup> cation contributed to high crystallinity and uniform  MA0.9Cs0.1PbI2Br(SCN)0.08 perovskite films with a bandgap of 1.77 eV, yielding a PCE of 16.3%. Zhu’ group investigated the synergistic effect of PEAI and Pb(SCN)2 complementary additives in the WBG FA0.65MA0.2Cs0.15PbI2.4Br0.6 (1.68 eV) perovskite precursor (Fig. 8b) [140]. It is revealed that the incorporation of  PEA<sup>+</sup> spacer can result in the reduction in grain size and limit the charge transport. When there is only Pb(SCN)2 additive, the grain size was increased, but it also induced the formation of large amount of excess  PbI2 phases. Interestingly, the coincorporation of  PEA<sup>+</sup> and  SCN<sup>−</sup> can perfectly overcome the separate issues associated with each additive, giving rise to remarkably improved structural and optoelectronic properties of perovskite films: such as improved crystallinity and carrier mobility, reduced defect density and energetic disorder. The optimized solar cell delivered a PCE approaching 

20%. In addition to  SCN<sup>−</sup> ions that can effectively increase grain size, the MACl additive is also widely used to improve the quality of perovskite film. Chen et al _._ presented that the MACl can significantly enlarge the grain size and improve the film morphology [141]. And further incorporation of MAH2PO2 can passivate the grain boundaries and suppress non-radiative recombination. The coupling of MACl and MAH2PO2 resulted in the WBG (1.64 ~ 1.70 eV) solar cells with improved photocurrent and reduced _V_ OC deficit, leading to a PCE of 25.4% for 2-T perovskite/silicon TSCs. 

Long chain ammonium cations have been widely used to passivate grain boundary and surface of perovskite films by forming 2D structure or themselves [121–124, 142, 143]. Particularly, for WBG PSCs, this a promising strategy for simultaneously improving efficiency and photostability. Zhu and co-workers reported a 2D-passivator engineering for the WBG (~ 1.68 eV) perovskites for the first time [144]. The pentafluorophenethylammonium (F5PEA<sup>+</sup> ) was introduced to partially replace the phenylethylammonium  (PEA<sup>+</sup> ) to form a robust non-covalent coordination between the two spacers (Fig. 8c). The WBG perovskite based on mixed ammoniums exhibited longer carrier lifetime, lower defect density and higher conductivity as compared with those using mono-cations, giving rise to enhanced PCE from 19.58% to 21.10% along with improved stability. Huo et al _._ compared the passivation effect of three organic bromide salts with different chain lengths including phenylammonium bromide (PhABr), phenmethylammonium bromide (PMABr) and phenethylammonium bromide (PEABr) on WBG (1.74 eV) PSCs [145]. PMABr with moderate chain length performs best in passivating defects and suppressing phase segregation. Xu et al _._ incorporated guanidinium bromide (GABr) into  FAPbBr3 precursor to modulate the crystallization and heal the charged defects [146]. It is found that GABr can reduce the wettability of the precursor on the substrate, leading to suppressed heterogeneous nucleation and larger grain size, as well as released microstrain and strengthened lattice structure. Moreover, the ionized -NH3+ group and unsaturated N atoms could simultaneously heal negatively charged (A-site vacancy) and positively charged (uncoordinated  Pb<sup>2+</sup> ) defects, respectively (Fig. 8d). The  FAPbBr3 solar cell gave a PCE of 8.92% with a _V_ OC of 1.639 V. Deep-level defects are recognized as the non-radiative recombination centers and severely sacrifice the _V_ OC of WBG PSCs. Yang et al _._ identified 

1 3 

**70** Page 16 of 44 

Nano-Micro Lett. (2023) 15:70 



**Fig. 8  a** FA-Cs WBG perovskite formation process without and with formamide additive. Reproduced with permission from Ref. [136]. Copyright 2018, Wiley–VCH. **b** Schematic illustration of defect passivation at perovskite grain boundaries (or surfaces) by  PEA<sup>+</sup> and  SCN<sup>−</sup> . Reproduced with permission from Ref. [140]. Copyright 2019, Elsevier. **c** Illustration of perovskite structure based on mixed-cation 2D-PPA. Reproduced with permission from Ref. [144]. Copyright 2020, Wiley–VCH. **d** Schematic mechanism of GABr modulation on  FAPbBr3 based PSCs. Reproduced with permission from Ref. [146]. Copyright 2022, Elsevier. **e** Geometrical structures of  MAPbI3 and MAPb(I0.8Br0.2)3 with iodide interstitials, and the calculated geometrical structure of MAPb(I0.8Br0.2)3 with  Br3–. **f** _J-V_ curves of  Cs0.1FA0.2MA0.7Pb(I0.85Br0.15)3 solar cells with additives of  TPABr3,  TBABr3 or TPACl, respectively. **g** Molecular structures of  TBABr3,  TPABr3 and TPACl. Reproduced with permission from Ref. [147]. Copyright 2022, Nature Publishing Group 

positive iodide interstitials as the deep-level defects in WBG perovskite films that limits the PCE improvement of PSCs [147]. In view of this, they dexterously introduced trimethylphenylammonium tribromide  (TPABr3) as defect passivator into WBG perovskite precursor to inhibit the formation of iodide interstitials. The  Br3− is 

expected to occupy the halide sites or fill halide vacancies and leave two terminal Br atoms, which can inhibit the formation of iodide interstitials due to the space limit. As a result, the reduced charge recombination favored increased carrier collection distance and allowed 1-µm-thick WBG perovskite film on textured silicon cell, 

© The authors 

https://doi.org/10.1007/s40820-023-01040-6 

Page 17 of 44 **70** 

Nano-Micro Lett. (2023) 15:70 

boosting the PCE of fully textured perovskite/silicon TSC to 28.6% (Fig. 8e, f). The tribromide additive can also suppress the light-induced phase segregation and thus enhance the photostability. Qin et al _._ reduced the nonradiative recombination through bulk defect passivation using chloro-formamidinium  (ClFA<sup>+</sup> ) additive [148]. The ClFA<sup>+</sup> can simultaneously passivate iodine vacancy and Pb-I antisite defects, contributing to a 1.25 V _V_ OC and a FF of 83% for  FA0.6MA0.4Pb(I0.6Br0.4)3 solar cells. And the 2-T perovskite/organic TSC delivered a high PCE up to 22.0%. Kim et al _._ proposed a anion engineering to carefully control the structural and electronic properties of 2D  PbI2 passivation layers [149]. A mixture of thiocyanate (SCN) with iodine additive  (PEAI0.25SCN0.75) was added into the  FA0.65MA0.2Cs0.15PbI2.4Br0.6 precursor. As discussed before,  SCN<sup>−</sup> can promote the crystal growth and result in larger grain size, while the  PEA<sup>+</sup> apparently suppresses the crystal growth. Similarly, the coupling of I<sup>−</sup> and  SCN<sup>−</sup> in  PEAI0.25SCN0.75 additive significantly improves the crystallinity and enlarge the grain size, thus enhance the carrier lifetime and mobility. Most importantly,  PEAI0.25SCN0.75 plays a critical role in modulating the desirable orientation of  PbI2 frame work located at grain boundary and surface, favoring better passivation effect and superior stability. As a result, the single-junction PSC and 2-T perovskite/silicon TSC achieved PCEs of 20.7% and 26.7%, respectively. 

Some organic small molecules and polymers bearing Lewis acid or base group are known for passivating defects at grain boundaries and suppressing non-radiative recombination [150–152]. Specific additives, such as imidazolium, theophylline and piperidinium, have also been reported to improve efficiency and stability via coordinate binding [153–155]. Liu et al. incorporated carbazole to passivate deep-level charged defects and suppress phase segregation of WBG perovskites [156]. Commonly, the ion migration starts from grain boundaries and is activated by strain, while the carbazole molecules can effectively stabilize the film surface through hydrogen bonding interactions with halides to impede the ion migration from the surface into the bulk, thus suppressing the phase segregation (Fig. 9a, b). Consequently, the carbazole-based WBG PSC gave a PCE of 20.2%, giving rise to 28.2% efficiency for 2-T perovskite/ silicon TSCs. Zheng et al _._ demonstrated that homogenized 

crystallization of WBG perovskites is crucial for suppressing the initial vertical halide phase separation and reduce _V_ OC loss [157]. Hence, they introduced 4-(2-aminoethyl)-benzenesulfonyl fluoride hydrochloride (ABF) with multifunctional groups into the WBG perovskite precursor to induce downward homogenized crystallization. The ABF can accelerate the pre-nucleation but slowdown the crystal growth, which is conducive to the formation of large-size crystals. And it preferentially precipitated on the surface instead of Br compounds, holding back the aggregation of Br-rich phase and allowing a uniform halides distribution vertically across the film. The ABF-contained pre-nucleation on the surface serves as a template for the downward homogenized crystallization (Fig. 9c). Moreover, fluoride with strong electronegativity can effectively stabilize anions and cations, while the sulfonyl and ammonium groups are expected to passivate positively charged (halide vacancies) and negatively charged (A-site vacancies) defects, respectively. The reduced defect density and uniform halides distribution account for the improved photostability. The ABF-based 1.63 and 1.68 eV PSCs offered PCEs of 21.76% and 20.11%, respectively. Yao et al _._ reported that the detrimental  I2 in the precursor would produce deep-level traps in final perovskite films [34]. A ammonium diethyldithiocarbamate (ADDC) additive is proven to reduce the  I2 back to  I<sup>−</sup> , thus reducing the deep-level defect density in the WBG perovskite film. Due to the decreased halide vacancies, the light-induced phase segregation can be effectively suppressed. The optimized WBG (1.77 eV) solar cell gave a PCE of 18.6% and a _V_ OC of 1.24 V along with great operation stability. Oliver et al _._ demonstrated that the incorporation of ionic additive (1-butyl1-methylpiperidinium tetrafluoroborate) can effectively reduce non-radiative recombination in the bulk of WBG perovskite film and at interfaces contacting with the charge transporting layers [158]. The MA-free WBG (1.79 eV) PSCs yielded a PCE approaching 17%. Chen’ group focused on the strain investigation of the PSCs. The residual strain in the perovskite film is found to significantly affect the crystal and electronic structures, as well as carrier dynamics within the devices, which is mainly determined by the composition, substrates and temperature during the film preparation. They ascribed the photo-instability of WBG perovskites to the local tensile strain in the film, which can facilitate the halides segregation at grain boundaries in the I/Br mixed 

1 3 

**70** Page 18 of 44 

Nano-Micro Lett. (2023) 15:70 



**Fig. 9  a** Optimized interfacial structures for carbazole/FAPbI3 models with different surface orientations and terminations of  FAPbI3, together with hydrogen bond lengths (red dashed lines) and binding energies ( _E_ b) between carbazole and perovskite. **b** Schematic illustration of interaction of carbazole with perovskite films. Reproduced with permission from Ref. [156]. Copyright 2021, Elsevier. **c** Schematic diagram of ABF pre-nucleation assisted crystallization process. Reproduced with permission from Ref. [157]. Copyright 2022, Wiley–VCH. **d** Schematic describing of interaction between ATP and perovskite. **e** XRD spectra in (001) planes of REF and ATP films before and after light soaking for 2 h. **f** W–H analysis for REF and ATP films before and after light soaking. Reproduced with permission from Ref. [69]. Copyright 2022, Wiley– VCH 

perovskites [69]. Through introducing adenosine triphosphate (ATP) additive, they achieved WBG perovskite film with compressive microstrain (Fig. 9d–f), which increases the energy barrier for ion migration and inhibits the photoinduced phase segregation for both A-site and X-site. The single-junction _n-i-p_ solar cell demonstrated a champion PCE of 20.53%, yielding a PCE of 26.95% for monolithic perovskite/silicon tandems. Table 3 summarized the device performance of WBG PSCs employing additive engineering. 

##### **4.3  Charge Transport Layers** 

The device structure of PSCs can be divided into _n-i-p_ and _p-i-n_ types according to the charge transport direction. To date, the certified PCE of _n-i-p_ PSCs is slightly higher than that of _p-i-n_ PSCs [159, 160]. The key reason could be the different CTLs employed in different devices. Compared with _p-i-n_ PSCs, the superior energy level alignment between perovskites and CTLs in _n-i-p_ PSCs 

© The authors 

https://doi.org/10.1007/s40820-023-01040-6 

Page 19 of 44 **70** 

Nano-Micro Lett. (2023) 15:70 

contributes to higher efficiency. Though it is feasible to obtain high-efficiency single-junction WBG PSCs using _n-i-p_ device structure, _p-i-n_ WBG PSCs is preferred for perovskite-based TSCs. For _n-i-p_ PSCs, Spiro-OMeTAD is the mostly used hole transport layers (HTLs) [3]. On the one hand, the hydrophilic properties of dopants like lithium bis(trifluoromethylsulfonyl)imide (LiTFSI) and tertbutylpyridine (tBP) in Spiro-OMeTAD lead to poor device stability in the air [161]. On the other hand, the thick Spiro-OMeTAD film (~ 200 nm) causes high parasitic absorption, thereby reducing the _J_ SC and sacrificing the efficiency of TSCs. Due to the lower parasitic absorption of thinner CTLs in _p-i-n_ PSCs, TSCs with _p-i-n_ structure have received more attention and are more promising to achieve higher PCE. 

CTLs play a critical role in charge transfer and extraction (Fig. 10) [74, 162–165]. For high-performance PSCs, the essential requirements of CTLs are high carrier mobility 

and well-matched energy level alignment with perovskites, which are directly related to the _J_ SC, _V_ OC and FF of PSCs. Meanwhile, good chemical stability of CTLs is also important for long-term device stability. Furthermore, for perovskite-based TSCs, CTLs with good light transmittance is also crucial for better light management. The most commonly used electron transport layers (ETLs) include  TiO2,  SnO2 and fullerene derivatives, and the HTLs are  NiOx, PTAA and Spiro-OMeTAD [166–172]. Whereas, the undesirable energy level alignment between WBG perovskites and these CTLs would induce serious interfacial non-radiative recombination, which is also the reason for substandard _V_ OC of WBG PSCs. Developing novel CTLs or modifying the existing CTLs to achieve better energy level matching is promising to reduce the _V_ OC loss. In the early studies of PSCs,  TiO2 was the most widely used CTLs [86, 93]. However, the deposition of  TiO2 layers requires high temperature 

**Table 3** Summary of WBG PSCs employing additive engineering 

|Perovskite|Additive|_E_g(eV)|_V_OC<br>(V)|_J_SC<br>(mA  cm<sup>−2</sup>)|FF<br>(%)|PCE (%)|References|
|---|---|---|---|---|---|---|---|
|FA0.85MA0.15Pb(I0.85Br0.15)3|KI|1.60|1.167|22.99|76|20.32|[126]|
|Cs0.05(FA0.85MA0.15)0.95Pb(I0.85Br0.15)3|KI|1.59|1.132|22.95|79|20.56|[127]|
|FA0.85MA0.1Cs0.05PbI2.7Br0.3|KI|NA|1.140|22.16|74.3|18.77|[128]|
|FA0.85MA0.15PbI2.7Br0.3|KI|NA|1.136|21.52|72.7|17.11|[128]|
|Cs0.06FA0.79MA0.15Pb(I0.4Br0.6)3|KI|1.78|1.23|17.9|79|17.5|[130]|
|Cs0.05(FA0.85MA0.15)0.95Pb(I0.85Br0.15)3|KI|1.62|1.135|22.88|78|20.25|[132]|
|Cs0.05FA0.79MA0.16Pb(I0.6Br0.4)3|KI|1.75|1.26|19.19|76|18.38|[133]|
|FA0.8Cs0.2Pb(I0.7Br0.3)3|KI|1.71|1.185|19.6|79|18.3|[134]|
|FA0.83Cs0.17Pb(I0.6Br0.4)3|Formamide|1.75|1.23|18.34|79|17.8|[136]|
|MAPb(I0.75Br0.25)3|MAAc|1.73|1.22|20.85|81.11|20.59|[137]|
|MA0.9Cs0.1PbI2Br(SCN)0.08|Pb(SCN)2/CsI|1.77|1.15|17.4|81.4|16.3|[139]|
|FA0.65MA0.20Cs0.15Pb(I0.8Br0.2)3|PEAI/Pb(SCN)2|1.68|1.170|21.2|79.8|19.8|[140]|
|Cs0.15(FA0.83MA0.17)0.85Pb(I0.8Br0.2)3|MACl/MAH2PO2|1.64|1.15|NA|NA|19.3|[141]|
|FA0.64MA0.20Cs0.15Pb0.99(I0.79Br0.2)3|PEAI/F5PEAI|1.68|1.196|21.65|81.5|21.10|[144]|
|FA0.75MA0.15Cs0.1PbI2Br|PMABr|1.74|1.19|18.69|78.21|17.32|[145]|
|FAPbBr3|GABr|2.25|1.639|7.71|71|8.92|[146]|
|Cs0.1FA0.2MA0.7Pb(I0.85Br0.15)3|TPABr3|1.65|1.23|21.2|83.8|21.9|[147]|
|FA0.6MA0.4Pb(I0.6Br0.4)3|ClFA|1.75|1.25|16.9|83|17.6|[148]|
|FA0.65MA0.20Cs0.15Pb(I0.8Br0.2)3|Pb(SCN)2/PEAI/ PEASCN|1.68|1.2|NA|NA|20.7|[149]|
|FA0.87Cs0.13Pb(I0.87Br0.13)3|PEO|NA|1.098|19.87|75|16.46|[152]|
|Cs0.05FA0.8MA0.15Pb(I0.75Br0.25)3|Carbazole|1.68|1.22|20.6|81|20.2|[156]|
|Rb0.05Cs0.05(FA0.75MA0.25)Pb(I0.75Br0.25)3|ABF|1.68|1.207|20.98|79.45|20.11|[157]|
|Rb0.05Cs0.05(FA0.83MA0.17)Pb(I0.83Br0.17)3|ABF|1.63|1.18|22.56|81.76|21.76|[157]|
|NA|ADDC|1.77|1.25|20.11|81.21|20.41|[34]|
|FA0.83Cs0.17Pb(I0.6Br0.4)3|[BMP]<sup>+</sup>[BF4]<sup>−</sup>|1.79|1.22|NA|NA|17|[158]|
|Cs0.22FA0.78Pb(I0.85Br0.15)3|ATP|1.65|1.21|21.08|80.49|20.53|[69]|



1 3 

**70** Page 20 of 44 

Nano-Micro Lett. (2023) 15:70 



**Fig. 10** Energy level diagram of perovskites, ETLs, HTLs and electrodes in PSCs 

(> 500 °C), which would damage the underlying rear cells in TSCs. Though low-temperature processed  TiO2 nanoparticles and chemical bath deposition have been developed, the relatively low carrier mobility limits its further PCE improvement. Low-temperature processed  SnO2 exhibits excellent charge transport property and gradually replace TiO2 in high-efficiency PSCs. Moreover,  SnO2 possesses higher transmittance, making it very popular for transparent electrode in _p-i-n_ TSCs [16, 17]. As discussed above, highly efficient TSCs prefer _p-i-n_ structure. The main HTLs for WBG PSCs and TSCs are PTAA,  NiOx and self-assembled materials (SAMs) [147, 148, 173–175], while the ETLs are fullerene and its derivatives. Table 4 summarized the device performance of WBG PSCs with different CTLs. 

Hu et al _._ demonstrated that the non-wettable PTAA substrate is beneficial for crystal growth with large grain size [176]. Due to the hydrophobic surface, the nucleation would be suppressed and result in increased spacing between the adjacent nuclei, allowing outspread growth and larger grains (Fig. 11a). Large crystals mean less grain boundaries, which is beneficial for enhancing photostability of WBG perovskites. Some researchers would like to improve the conductivity of PTAA by doping with small molecules like F4-TCNQ. Zheng et al _._ reported the _p_ -doping of PTAA to facilitate hole extraction for 2-T perovskite/ silicon TSCs, making the device performance less sensitive to the thickness of PTAA [177]. The _p_ -doping with 

ionic compound 4-isopropyl-4’-methyldiphenyliodonium tetrakis(penta-fluorophenyl-borate) (DPI-TPFB) dopant is activated by light-soaking treatment, resulting in nearly 22 times higher conductivity than that of pristine PTAA. The significantly enhanced conductivity translated into improved FF and boosted the PCE from 25.0% to 27.8%. Though Bush et al _._ demonstrated that PTAA performs better than  NiOx in reducing _V_ OC loss, it is difficult to deposit conformal and fully covered HTL on the textured silicon cells [178]. When the size of the pyramid is significantly decreased (< 1 µm), PTAA is also practicable for textured perovskite/silicon TSCs [179]. Chen et al _._ demonstrated a blade coating technique to produce the desired thin, uniform PTAA layer on the textured silicon surface through elevating the substrate temperature to 70 °C [180]. When the temperature changed to room temperature, PTAA layer is non-uniform even with the assistance of  N2, which can be attributed to the accelerated evaporation of the toluene at 70 °C. As a result, the perovskite-silicon TSC achieved a PCE of 26%. Yang et al _._ revealed that more severe non-radiative recombination at PTAA/perovskite interface through the photoluminescence quantum yield (PLQY) measurement [147]. By introducing a LiF layer at PTAA/WBG perovskite interface, _V_ OC increased up to 1.25 V, which is the smallest _V_ OC deficit reported for WBG PSCs applied in perovskite/silicon TSCs. Compared with PTAA,  NiOx can be deposited on textured surface via electron beam or 

© The authors 

https://doi.org/10.1007/s40820-023-01040-6 

Page 21 of 44 **70** 

Nano-Micro Lett. (2023) 15:70 

**Table 4** Summary of WBG PSCs with different CTLs 

|Perovskite|CTL|_E_g<br>(eV)|_V_OC<br>(V)|_J_SC<br>(mA  cm<sup>−2</sup>)|FF<br>(%)|PCE (%)|References|
|---|---|---|---|---|---|---|---|
|MAPbBr0.8I2.2|In-TiO_x_|1.75|1.21|15.8|77.9|14.9|[176]|
|MAPbBr0.5I2.5|In-TiO_x_|1.70|1.16|18.3|78.2|16.6|[176]|
|Cs0.05(MA0.17FA0.83)0.95Pb(I0.83Br0.17)3|2PACz|1.60|1.188|21.9|80.2|20.9|[183]|
|Cs0.25FA0.75Pb(I0.85Br0.15)3|2PACz|1.65|1.20|22.15|83.81|22.33|[175]|
|FA0.6MA0.4Pb(I0.6Br0.4)3|2PACz|1.75|1.25|16.9|83|17.6|[148]|
|Cs0.12FA0.8MA0.08PbI1.8Br1.2|2PACz|1.77|1.29|15|77.9|15.1|[186]|
|FA0.8Cs0.2Pb(I0.7Br0.3)3|MeO-2PACz/|1.75|1.21|19.3|86.5|20.2|[174]|
|FA0.8Cs0.15MA0.05Pb(I0.82Br0.18)3|Me-2PACz/ MeO-2PACz|1.65|1.221|21.5|83.3|21.9|[187]|
|Cs0.05(FA0.77MA0.23)0.95Pb(I0.77Br0.23)3|Me-4PACz|1.68|1.224|20.7|82.0|20.8|[107]|
|NA|NiO_x_/2PACz|1.65|1.14|23.19|80.6|21.31|[188]|
|Cs0.05(FA0.84MA0.16)0.95Pb(I0.85Br0.15)3|NiO_x_/SAM|1.59|1.10|21.9|77.4|18.6|[190]|
|FA0.8Cs0.2Pb(I0.6Br0.4)3|NiO_x_/Me-4PACz|1.79|1.33|18.06|84.2|20.2|[189]|
|FA0.8Cs0.2PbI1.8Br1.2|VNPB|1.77|1.23|17.0|79.8|16.7|[191]|
|Cs0.1FA0.2MA0.7Pb(I0.85Br0.15)3|PTAA|1.65|1.25|21.1|83|21.2|[147]|
|FA0.65MA0.20Cs0.15Pb(I0.8Br0.2)3|PTAA|1.67|1.195|21.11|81.87|20.64|[173]|
|Cs0.1MA0.9Pb(I0.9Br0.1)3|PTAA|1.65|1.167|21.0|82.0|20.1|[180]|
|MAPb(I0.75Br0.25)3|PTAA|1.68|1.20|NA|NA|18.05|[179]|
|(FA0.83MA0.17)0.95Cs0.05Pb(I0.6Br0.4)3|ICBA-tran3|1.71|1.20|19.7|77.5|18.3|[196]|
|MAPb(I0.73Br0.27)3|C60MC12|1.71|1.24|17.45|77|16.74|[197]|
|Cs0.05MA0.15FA0.8Pb(I0.85Br0.15)3|a-NbO_x_/C60|1.68|1.20|21.6|76.6|19.8|[198]|
|Cs0.4FA0.6PbI1.95Br1.05|C60/SnO1.76|1.78|1.23|16.5|78.9|16.0|[199]|



magnetron sputtering deposition techniques. Recently, selfassembled HTLs have made great progress on perovskite/ silicon and perovskite/CIGS TSCs. These molecules can covalently bind to the conductive oxides like ITO and  NiOx, and they can be prepared by spin-coating or dip-coating within wide processing windows. SAMs are made of small organic molecules, and thus, the chemical synthesis of most SAMs affords precise structures [181, 182]. Due to the ease of synthesis for carboxylic acid and phosphonic acid units, they were widely used in the SAMs. In addition, SAMs are of great potential to modify CTLs due to negligible parasitic optical losses, which can significantly improve the _J_ SC [183, 184]. For instance, MeO-2PACz ((2-(3,6-dimethoxy9H-carbazol-9-yl)ethyl) phosphonic acid) can improve the _J_ SC of _p-i-n_ PSCs by ~ 0.8 mA  cm<sup>−2</sup> compared with PTAA [183]. Similarly, a  C60-SAM ETL improves the _J_ SC of _p-in_ PSCs by absolute 1.2 mA  cm<sup>−2</sup> compared with  TiO2 [185]. In 2019, Albrecht’ group reported a new generation of SAMs as the HTL for perovskite/CIGS TSCs (Fig. 11b) [183]. Compared with Spiro-OMeTAD and PTAA, SAMs are cheap, dopant-free, simple to process and intrinsically scalable. Moreover, they can offer the crucial advantage 

of conformal coverage on the rough CIGS film surface. Three different SAMs, (2-{3,6-bis[bis(4-methoxyphenyl) amino]-9H-carbazol-9-yl}ethyl)phosphonic acid (V1036), MeO-2PACz and [2-(9H-carbazol-9-yl)ethyl]phosphonic acid (2PACz) are employed (Fig. 11c), among which the 2PACz delivered the highest 20.9% efficiency for Cs0.05(MA0.17FA0.83)0.95Pb(I0.83Br0.17)3 solar cell and 23.26% efficiency for perovskite/CIGS TSCs. Later, they utilized methyl-substituted carbazole monolayer, named Me-4PACz ([4-(3,6-dimethyl-9H-carbazol-9-yl)butyl]phosphonicacid) as HTL in WBG PSCs (Fig. 11d), which enabled a high quasi-Fermi level splitting (QFLS) (Fig. 11f), allowing fast hole extraction and minimized non-radiative recombination. At the same time, the Me-4PACz substrate can also notably enhance the photostability under continuous illumination (Fig. 11e). The single-junction PSCs achieved a PCE of 20.8%, contributing to 29.15% efficiency for perovskite/ silicon tandems with _V_ OC as high as 1.92 V [107]. Also, taking advantage of Me-4PACz, they further improve the certified PCE of perovskite/CIGS TSCs up to 24.2%, which is the record for this kind of TSCs [29]. In addition to reducing surface recombination on rigid indium tin oxide (ITO) 

1 3 

**70** Page 22 of 44 

Nano-Micro Lett. (2023) 15:70 



**Fig. 11  a** Schematic illustration of nucleation and growth of grains on wetting and non-wetting hole transport layer surface. Reproduced with permission from Ref. [176]. Copyright 2016, Wiley–VCH. **b** Schematic of the device structure. The zoom-in visualizes how the SAM molecules attach to the ITO surface and therefore enable the hole selective contact to the perovskite above. **c** Chemical structure of the SAM molecules V1036, MeO-2PACz and 2PACz. Reproduced with permission from Ref. [183]. Copyright 2019, Royal Society of Chemistry. **d** Schematic of PL experiment and chemical structure of a general carbazole-based SAM. **e** Time-dependent PL spectra of perovskite films on different substrates. **f** Quasi-Fermi level splitting values of nonsegregated perovskite films on glass substrate and different hole-selective layers. Reproduced with permission from Ref. [107]. Copyright 2020, Science Publishing Group. **g** Theoretical modeling of 2PACz adsorption on ITO (left) and  NiO _x_ (right) surfaces in the presence of surface hydroxyl groups based on DFT calculations. Reproduced with permission from Ref. [188]. Copyright 2022, Wiley–VCH 

substrates, SAMs are also suitable for flexible WBG. Lai et al _._ revealed that WBG perovskite deposited on a flexible polymer substrate shows better optoelectronic quality 

and uniformity by replacing PTAA with 2PACz, resulting a lower _V_ OC loss for a 1.77 eV flexible PSCs [186]. Particularly, in order to obtain uniform coverage of the 2PACz on 

© The authors 

https://doi.org/10.1007/s40820-023-01040-6 

Page 23 of 44 **70** 

Nano-Micro Lett. (2023) 15:70 

the substrate, the solution should be left on the substrate for 60 s and repeated twice before spinning. As a result, flexible all-perovskite TSCs delivered a PCE of 23.8% with a remarkable _V_ OC of 2.1 V. Liu et al _._ deposited 1.65 eV bandgap perovskite on a HTL prepared with Me-2PACZ and MeO-2PACZ mixed solution to reduce recombination losses at perovskite/HTL interface, achieving the PCEs of 21.9% and 29.8% for WBG PSC and perovskite/silicon TSC, respectively [187]. Liu and co-workers developed a molecular-level nanotechnology by introducing an ultrathin hybrid  NiOx/2PACz HTL atop the ITO recombination junction, serving as a vital pivot for the conformal deposition of perovskite layer [152] [188]. Compared with ITO/2PACz contact, the bonding reaction between  NiOx and 2PACz is energetically more favorable (Fig. 11g), which enables a uniform self-assembled 2PACz molecules on the fully textured surface, avoiding direct contact between perovskite and ITO to achieve minimal shunt loss. Recently, Chen et al _._ used  NiOx/Me-4PACz as HTL to construct monolithic allperovskite tandem, resulting a PCE > 27% with a record _V_ OC of 2.19 V [189]. 

Meanwhile, the hybrid HTL also resulted in obviously enhanced crystallinity and enlarged grain size. As a result, the fully textured perovskite/silicon TSCs delivered a record certified PCE of 28.84% on 1.2  cm<sup>2</sup> masked area. Zheng et al _._ also employed  NiOx/2PACz HTL for perovskite/silicon TSCs, and a PCE of 27.6% was obtained [190]. Tan’ group demonstrated increased _V_ OC and PCE of WBG PSCs by replacing commonly used PTAA with _in situ_ cross-linked small molecule _N4_ , _N4_ ′-di(naphthalen-1-yl)- _N4_ , _N4_ ′-bis(4vinylphenyl)biphenyl-4,4′-diamine (VNPB) [191]. The stronger interaction and lower defect density at the VNPB/ perovskite interface contributed to the improved efficiency and stability of WBG PSCs, translating to PCEs of 24.9% and 25.4% for all-perovskite and perovskite-silicon TSCs, respectively. Moreover, by adopting  NiOx/VNPB hybrid HTL for WBG PSCs, they achieved glaring progress for all-perovskite TSCs [56]. Besides, vacuum-deposited SpiroTTB has also been utilized for TSCs [192–194]. In this case, the perovskite on Spiro-TTB should be prepared by twostep (vacuum-solution) or fully vacuum deposition method, because Spiro-TTB can be dissolved in DMF or DMSO solvent [195]. 

To date, the role of fullerene  (C60) in TSCs remains unchallenged.  C60 and its derivatives (like  PC61BM) are major ETLs for _p-i-n_ PSCs. Considering that  C60 can be 

the easily functionalized, it is feasible to synthesize derivatives with desirable energy levels to realize better contact with WBG perovskites. Lin et al _._ demonstrated that the indene-C60 bis-adduct (ICBA) with higher lowest-unoccupied molecular-orbital (LUMO) is beneficial for reducing _V_ OC loss for WBG PSCs [196]. However, the large energy disorder of ICBA will diminish the _V_ OC improvement due to the presence of many polymorphs. They presented that ICBA-tran3 isolated from ICBA-mixture exhibits the same high LUMO, but much smaller energy disorder and higher carrier mobility as compared with pristine ICBAmixture (Fig. 12a). The application of ICBA-tran3 enabled enhanced efficiency up to18.5%. Khadka et al _._ synthesized long alkyl chain-substituted fullerene derivatives as ETL. The  C60-fused _N_ -methylpyrrolidine- _meta_ -dodecyl phenyl (C60MC12) demonstrated high crystallinity compared to amorphous  PC61BM, giving rise to more efficient electron transfer and lower perovskite/ETL interfacial defect (Fig. 12b) [197]. The 1.71 eV bandgap  MAPbI3-xBrx solar cell delivered a PCE of 16.74% with a _V_ OC of 1.24 V. Aydin et al _._ reported _n-i-p_ 2-T perovskite/silicon TSCs by combining sputtered amorphous niobium oxide (a-NbOx) with ligand-bridged  C60 as the underlying ETL and evaporated Spiro-TTB as HTL [198]. The  C60 with a functionalized pyrrolidine tail was designed to achieve a conformal selfassembled monolayer to ensure efficient charge extraction and reduce parasitic absorption (Fig. 12c). The 2-T _n-i-p_ perovskite/silicon TSCs gave a PCE of 27%, which is highest for TSCs with this polarity. Some studies revealed that  C60 can be unintentionally _n_ -doped by iodine ions from the perovskite films, resulting in elevated _E_ F and enhanced electron transportation property. Yu et al _._ found that the Sn/O ratio of  SnO2-x determines the electronic properties of the layer [199]. When 2-x = 1.76, the atomic layer deposition (ALD) processed  SnO2-x layer exhibits an ambipolar carrier transport property. Combining with _n_ -doped  C60, they simplified the interconnection layers  (C60/SnO2-x/ITO/PEDOT:PSS) into  C60/SnO1.76, both of which form good ohmic contacts with the corresponding sub-cells (Fig. 12d). With these merits, they achieved 24.4% efficiency for all-perovskite TSCs. 

Though various fullerene derivatives have been developed,  C60 is still preferred for highly efficient perovskitebased TSCs. Compared with  C60, most of fullerene derivatives shows more parasitic absorption, which is fatal for current improvement in TSCs. Moreover, only  C60 is able to be vacuum deposited, while other fullerene derivatives are 

1 3 

**70** Page 24 of 44 

Nano-Micro Lett. (2023) 15:70 



**Fig. 12  a** Schematic illustration of how energy level and energy disorder of ETLs influences the device _V_ OC. Reproduced with permission from Ref. [196]. Copyright 2017, Wiley–VCH. **b** Schematic illustration of the mechanism for performance enhancement in device with crystalline fullerene derivatives. Reproduced with permission from Ref. [197]. Copyright 2018, American Chemical Society. **c** Schematics of  C60-SAM self-assembly process on  Nb2O5. Reproduced with permission from Ref. [198]. Copyright 2021, Royal Society of Chemistry. **d** Schematic diagram of tandem devices based on typical structured and simplified ICLs. Reproduced with permission from Ref. [199]. Copyright 2020, Nature Publishing Group 

solution-processed. Certainly, vacuum deposition technique allows dense and uniform ETL, which is also crucial for improving efficiency and stability of TSCs. 

##### **4.4  Interface Engineering** 

PSCs present a typical sandwich structure, including perovskite layer, ETL/HTLs, charge buffer layers and electrodes. The multi-stacked structure means various interfacial contacts [200, 201]. The properties of these interfaces directly affect the charge transportation and non-radiative recombination, which are vital for the high-performance PSCs [202]. On the one hand, the non-matched energy levels and interfacial trap-assisted non-radiative recombination induce severe _V_ OC loss and thus limit the efficiency of WBG PSCs [60, 203, 204]. On the other hand, interfacial reactions induced by defects could also damage the device stability [205–207]. 

Therefore, interface engineering has been proven to be one of the most effective methods to achieve high-performance and long-term stable PSCs. 

Constructing interfacial 2D/3D heterostructures via long chain alkylamines is widely used to passivate defects, block ion migration, and suppress phase segregation of PSCs [208–210]. For instance, employing benzylamine (BA) posttreatment for 1.72 eV bandgap  Cs0.15FA0.85Pb(I0.73Br0.27)3 perovskite, a 2D  BA2PbI4 phase was obtained, which can effectively passivate defective regions and prevent decomposition or phase segregation [211]. Moreover, the formation of 2D  BA2PbI4 (Fig. 13a) created an energy cascade with the underneath 3D perovskite, facilitating hole extraction while blocking electron transportation. As a result, the efficiency and ambient stability were greatly improved after the BA modification. Paetzold et al _._ introduced _n_ -butylammonium bromide (BABr) into 1.72 eV bandgap 

© The authors 

https://doi.org/10.1007/s40820-023-01040-6 

Page 25 of 44 **70** 

Nano-Micro Lett. (2023) 15:70 

Cs0.17FA0.83Pb(I0.6Br0.4)3 perovskite to construct a hybrid 2D/3D heterostructure at the interface toward the HTL, which mitigated non-radiative recombination in the perovskite film [212]. The work function increased from -4.27 to -3.94 eV with BABr treatment, suggesting better energy level alignment and thus faster carrier extraction at perovskite/HTL interface. Eventually, the BABr-modified PSCs demonstrated a stable power output conversion efficiency of 19.4% and a _V_ OC up to 1.31 V, which was the highest _V_ OC reported for WBG PSCs. To further confirm whether it is better to introduce 2D perovskite by surface post-treatment or bulk incorporation, Catchpole et al _._ introduced BABr with different strategies to obtain a mixed-dimensional system [213]. It was found that _Ruddlesden–Popper_ quasi-2D perovskite phase formed on the surface can effectively passivate the defects and optimize the electronic structure at the surface of the 3D perovskite, resulting in longer carrier lifetime and higher efficiency. In contrast, incorporating BABr into the precursor solution formed pure 2D perovskite phase, negatively affecting the crystallinity and electronic structure, leading to poor device performance. Though different 

large cation salts have been successfully used for post-treatment, there is still a lack of understanding of the impact of these large cations on the interfacial morphology. Huang et al _._ precisely controlled the surface structure and thickness of the 2D perovskites via phenylmethylamine bromide (PMABr) post-treatment for a 1.74 eV bandgap perovskite film (Fig. 13b) [214]. It is found that the microstructures at the interface were strongly depended on the concentration of the post-treatment solution. Meanwhile, the Br ions in PMABr can passivate the halide vacancies. Recently, thiophene-based quasi-2D _Ruddlesden–Popper_ ( _R-P_ ) and _DionJacobson_ ( _D-J_ ) perovskites have demonstrated preferable photovoltaic performances than their counterparts based on PEA cations due to the improved carrier mobility from the strong polarity of sulfur atoms. Fang et al _._ reported 2-thiopheneethylammonium chloride (TEACl) post-treatment for FA0.8Cs0.2Pb(I0.8Br0.2)3 perovskite (1.68 eV) film, where a 2D interlayer of  TEA2PbI4 with _n_ = 1 was formed between the absorber and ETL [215]. With this desired hierarchical 2D/3D structure, the efficiency and stability were simultaneously improved through passivating the electron and hole 



**Fig. 13  a** Schematic of BA modification on the  Cs0.15FA0.85Pb(I0.73Br0.27)3 thin film. Reproduced with permission from Ref. [211]. Copyright 2017, Wiley–VCH. **b** Schematic perovskite films treated with low, medium or high concentrations of PMABr/IPA solution. Reproduced with permission from Ref. [214]. Copyright 2020, Elsevier. **c** Energy level diagrams of perovskite film. Reproduced with permission from Ref. [217]. Copyright 2019, Elsevier. **d** Energy level diagram of perovskite and HTL after introducing the CsBr interface layer. Reproduced with permission from Ref. [194]. Copyright 2021, Wiley–VCH 

1 3 

**70** Page 26 of 44 

Nano-Micro Lett. (2023) 15:70 

traps, increasing the activation energy of the ion migration and lowering the dark saturation current density of the device. The WBG _n-i-p_ PSCs with TEACl treatment showed a PCE of 20.31%. It has been demonstrated that surface posttreatment using ammonium halides can effectively reduce _V_ OC deficit in WBG PSCs but at present the mechanism is still unclear. He et al _._ reported a phenethylammonium bromide (PEABr) post-treatment strategy with different annealing temperatures for precisely tailoring the phase purity of 2D perovskites on 3D WBG perovskite, passivating surface defects and optimizing surface electric field [216]. After PEABr post-treatment, a pure _n_ = 1 2D perovskite phase formed at 60 °C on the top of a 1.77 eV WBG perovskite, which significantly suppressed non-radiative recombination thereby decreased the _V_ OC deficit. As a result, the 1.77 eV WBG PSC gave a _V_ OC of 1.284 V, which is the lowest _V_ OC deficit (0.486 V) among WBG PSCs with a bandgap higher than 1.75 eV. 

In addition to construct 2D phases, tuning the electronic properties of perovskite film surface is also a effective approach to improve device performance. Yan et al _._ applied guanidinium bromide (GABr) to create graded perovskite homojunction on  FA0.8Cs0.2Pb(I0.7Br0.3)3 perovskite (1.75 eV), where a composition of GAxFA0.8Cs0.2Pb(I0.7Br0.3+x/3)3 was formed between the absorber and HTL [217]. GABr-treated perovskite films demonstrated more _n_ -type property with decreased work function (Fig. 13c). The _V_ OC of GABr-treated _p-i-n_ PSCs increased from 1.12 to 1.24 V with superior photostability. Later, in order to investigate the mechanism of defects passivation with large ammonium cations, they further combined the microscopic probing of localized electrical properties, thermal admittance spectroscopy (TAS) measurements and first-principles calculations of defect migration [218]. TAS measurement showed that PEAI-based device exhibited a higher _E_ a of 0.905 eV as compared with 0.680 eV for the control, indicating the significantly suppressed ion migration, which is in good agreement with the results of the theoretical calculation. Finally, the 1.73 eV bandgap PSCs achieved an efficiency of 19.07% with a _V_ OC deficit of 0.48 V. Catchpole et al _._ studied the effects of three bromide-containing alkylammonium organic cations with different chain lengths on defect passivation [219]. The results suggested that long chain alkyl organic cations were more suitable for defect passivation by changing the electronic structure of perovskite films. The optimized PSCs based on 

FA0.75MA0.15Cs0.1Rb0.05PbI2Br exhibited a PCE of 19.1% with excellent moisture and photostability. Li et al _._ inserted CsBr between HTL and perovskite by thermal evaporation, creating a graded perovskite absorber by reacting with residual  PbI2 [194]. TRPL results showed that CsBr interface layer can accelerate the hole transport from perovskite to HTL through better aligned energy levels (Fig. 13d). With device optimization, perovskite/c-Si tandem cell reached an efficiency of 27.48% with a long-term stability over 10,000 h in  N2 glovebox. 

For the Br-rich WBG perovskites, the light-induced phase segregation primarily originates from the ionic migration via halide vacancies, which mainly occurs at grain boundaries and film surface [220–222]. McGehe et al _._ studied the relationship between the surface modification and lightinduced halide segregation by introducing trioctylphosphine oxide (TOPO) onto  CH3NH3PbI2Br [223]. They proposed possible drift–diffusion mechanisms for halide segregation by detecting the rate of halide segregation, providing a direct link between surface modification and photo-induced trap formation (Fig. 14a). Wolf et al. introduced phenformin hydrochloride (PhenHCl) containing both electron-rich and electron-poor moieties to simultaneously passivate defect and suppress the light-induced phase segregation [224]. As shown in Fig. 14b, DFT calculations for Cs0.13MA0.13FA0.74Pb(I0.81Br0.19)3 corroborate that PhenHCl can effectively passivate different perovskite surfaces, including perfectly cleaved lead iodide  (PbI2) surface, iodide-deficient surface and lead-deficient surface. Absolute PL imaging showed that PhenHCl passivation effectively suppresses phase segregation, in agreement with bandgap imaging of samples. As a result, PhenHCl-based 1.68 eV bandgap PSCs afforded a PCE of 20.5% with no _V_ OC loss after more than 3000 h of thermal stability test at 85 °C. The perovskite/silicon tandem solar cell achieved an efficiency of 26.5%. In addition to post-treatment, surface gradient passivation via anti-solvent can also achieve effective defect passivation and simplify the preparation process. Liu et al _._ proposed a in situ defect passivation strategy by introducing 3,4,5-trifluorobenzylamine (TFBA) into ethyl acetate (EA) as anti-solvent for the film preparation, where protontransfer from formamidinium (FA) and methylammonium (MA) to TFBA (Fig. 14c) was observed [205]. The gradient distribution of TFBA significantly suppressed non-radiative recombination both at the surface and grain boundaries, as well as inhibiting phase segregation. Most of works focused 

© The authors 

https://doi.org/10.1007/s40820-023-01040-6 

Page 27 of 44 **70** 

Nano-Micro Lett. (2023) 15:70 



**Fig. 14  a** Annotated band diagrams produced from drift–diffusion simulations. Reproduced with permission from Ref. [223]. Copyright 2018, American Chemical Society. **b** Electron density differences for the  PhenH<sup>+</sup> molecule on the  PbI2, I-deficient and Pb-deficient surfaces and corresponding binding energies. Reproduced with permission from Ref. [224]. Copyright 2021, Elsevier. **c** Proton-transfer reaction between FA cation and TFBA from Ref. [205]. Copyright 2022, Wiley–VCH. **d** Energy level alignment at the CsMAFA/C60 interface with and without LiF interlayer. Reproduced with permission from Ref. [227]. Copyright 2022, Wiley–VCH. **e** Valence band and photoelectron cut-off region of the perovskite and perovskite/interlayers **f** Energy level diagram of the perovskite/C60 interface with  MgFx insertion layer. Reproduced with permission from Ref. [13]. Copyright 2022, Science Publishing Group 

on improving the _V_ OC of WBG PSCs, but ignore that PCE is also dramatically limited by the fill factor. Non-ideal charge transport between the perovskite absorber and electrodes can increase the series resistance, which limit the device performance. Therefore, Ho-Baillie et al _._ introduced a cationdiffusion-based double-sided interface passivation scheme by GuBr to improve the fill factor for 1.75 eV bandgap PSCs [174]. They showed that partial cation diffusion from the Gu-based passivation layers into the perovskite can suppress the shallow traps in the bulk, while the rest of the Gu cations remained at interfaces to passivate the deeper surface trapstates. As a result, they demonstrated a record FF of 86.5% and a PCE of 20.2%. This provided new insights for future passivation strategies based on ionic diffusion to prepare highly efficient and stable WBG PSCs. 

The contact layer interfaces also play an essential role in determining the device performance of PSCs, especially for TSCs. Both the energy level mismatch and the trap states at interfaces strongly affect the charge transportation [225]. To date,  C60 and  PC61BM are commonly applied 

as ETLs for _p-i-n_ PSCs. Moreover, easy vapor deposition processing technique and low parasitic absorption loss make evaporated  C60 the most popular ETL for perovskitebased TSCs. However, energy level mismatch and severe charge recombination at the perovskite/C60 interface limit the performance of TSCs. In this case, interlayers between perovskite and  C60 are commonly adopted. Neher et al _._ reported an ultrathin LiF layer between perovskite and  C60 to reduce the interfacial recombination loss by 35 meV [226]. Besides, inserting an ultrathin LiF layer at the perovskite/C60 interface for 1.68 eV bandgap _p-i-n_ PSCs leads to a maximum voltage of 1.234 V and a PCE of 20.8% [107]. However, the mechanism of LiF passivation is still poorly understood. Korte et al _._ proposed a field effect passivation by using ultra-sensitive near-UV photoelectron spectroscopy (CFSYS) to study the electronic interface formation and energy level alignment at the perovskite/ C60 interface [227]. The incorporation of a LiF layer at the interface can reduce the hole concentration by a mild dipole effect and probably the presence of fixed charges 

1 3 

**70** Page 28 of 44 

Nano-Micro Lett. (2023) 15:70 

(Fig. 14d). As a result, the defect density in the first monolayers of  C60 was effectively reduced, leading to improved _V_ OC. Similarly, Snaith et al _._ introduced a LiF interface treatment for a MA-free 1.79 eV bandgap perovskite to reduce non-radiative recombination. The _n-i-p_ PSCs with LiF treatment showed a _V_ OC of up to 1.22 V and a PCE approaching 17% [158]. However, on the one hand, the deliquescent behavior and high ion diffusivity of Li salts may reduce device stability. Recently, Wolf et al. investigated a series of metal fluorides to instead of LiF as the interlayers at the perovskite/C60 interface [13]. Ultraviolet photoemission spectroscopy (UPS) and low-energy inverse photoemission spectroscopy (LE-IPES) showed that work function systematically shifts toward smaller values, and the valence band maximum of the perovskite was lowered relative to its Fermi level, implying that the metal fluorides caused a downward band bending at the perovskite interface, which is benefit for more efficient electron extraction (Fig. 14e, f). As a result, the monolithic perovskite/silicon TSCs with a  MgFx contact displacer reached a _V_ OC of 

1.92 V, giving rise to a certified PCE of 29.3% with ~ 95% remain after 1000 h damp-heat testing. Table 5 summarized the device performance of WBG PSCs employing interface engineering. 

##### **4.5  Preparation Method** 

Preparation techniques for perovskite films include one-step and two-step solution methods, vapor-assisted solution and full evaporation methods [228, 229]. Considering the diversity and complexity of WBG perovskites, different preparation techniques might facing different issues and produce different perovskite films. For example, compared with one-step solution method, it is more difficult to tailor the bandgap of perovskites via two-step solution and evaporation methods, as well as realize complete conversion from raw materials to perovskite films. Therefore, optimizing preparation methods of WBG PSCs are also quite important. To date, most highly efficient PSCs are still at lab-cell level, and the active areas are smaller than 1  cm<sup>2</sup> , while the 

**Table 5** Summary of WBG PSCs employing interface engineering 

|Perovskite|Modifying material|_E_g(eV)|_V_OC<br>(V)|_J_SC<br>(mA  cm<sup>−2</sup>)|FF<br>(%)|PCE (%)|References|
|---|---|---|---|---|---|---|---|
|FA0.83Cs0.17Pb(I0.76Br0.24)3|BABr|1.65|1.18|NA|NA|19.2|[208]|
|Cs0.05FA0.79MA0.16Pb(I0.67Br0.33)3|HABr|1.72|1.31|19.60|77.10|19.8|[165,209]|
|Cs0.2FA0.8Pb(I0.82Br0.15Cl0.03)3|ODADI|1.66|1.23|20.79|82.28|21.05|[210]|
|Cs0.15FA0.85Pb(I0.75Br0.27)3|BA|1.72|1.24|19.83|73.7|18.13|[211]|
|Cs0.17FA0.83Pb(I0.6Br0.4)3|BABr|1.72|1.31|19.3|78|19.8|[212]|
|Rb0.05Cs0.095MA0.1425FA0.7125PbI2Br|_n_-BABr|1.72|1.269|18.9|76.2|18.3|[213]|
|FA0.8Cs0.2Pb(I0.7Br0.3)3|PMABr|1.74|1.204|19.84|78|18.51|[214]|
|FA0.8Cs0.2Pb(I0.8Br0.2)3|TEACl|1.68|1.19|20.94|81.8|20.31|[215]|
|FA0.8Cs0.2Pb(I0.7Br0.3)3|GABr|1.75|1.24|17.92|81.90|18.19|[217]|
|FA0.8Cs0.2Pb(I0.7Br0.3)3|PEAI|1.73|1.25|19.48|78.9|19.07|[218]|
|FA0.75MA0.15Cs0.1Rb0.05PbI2Br|_n_-OABr|1.72|1.282|18.9|78.8|19.1|[219]|
|FA0.9Cs0.1PbI2.87Br0.13|CsBr|1.64|1.082|19.59|80.34|17.03|[194]|
|Cs0.15FA0.85Pb(I0.71Br0.29)3|Al2O3|1.72|1.22|15.4|73.4|13.8|[220]|
|Cs0.09FA0.77MA0.14Pb(I0.84Br0.16)3|PEAI|1.64|1.17|18.60|81.1|17.7|[221]|
|Cs0.15MA0.15FA0.7Pb(I0.8Br0.2)3|PhenHCl|1.68|1.22|NA|NA|20.5|[224]|
|Cs0.22FA0.78PbI2.55-xBr0.45Clx|TFBA|1.68|1.204|20.72|81.73|20.39|[205]|
|FA0.8Cs0.2Pb(I0.7Br0.3)3|GuBr|1.75|1.21|19.3|86.5|20.2|[174]|
|(CsPbI3)0.05[(FAPbI3)<br>0.89<sup>(MAPbBr</sup>3<sup>)</sup>0.11<sup>]</sup>0.95|LiF|NA|1.17|21.7|78.6|20.0|[226]|
|Cs0.05(FA0.77MA0.23)0.95Pb(I0.77Br0.23)3|LiF|1.68|1.224|20.7|82.0|20.8|[107]|
|FA0.83Cs0.17Pb(I0.6Br0.4)3|LiF|1.79|1.22|NA|NA|17|[158]|
|Cs0.05FA0.8MA0.15Pb(I0.755Br0.255)3|MgF_x_|1.69|1.226|20.58|81.1|20.46|[13]|



© The authors 

https://doi.org/10.1007/s40820-023-01040-6 

Page 29 of 44 **70** 

Nano-Micro Lett. (2023) 15:70 

large-area cells demonstrate decreased PCE mainly due to the increased trap states. Upscaling fabrication is of prime importance for PSCs commercialization. Slot-die coating, blade coating, inkjet printing, roll-to-roll printing and evaporation are familiar fabrication methods for making PSC modules [230–232]. Here, we will emphatically introduce the preparation methods of WBG perovskites in 2-T tandem conditions. 

Most of perovskite-based TSCs present active area ~ 1 cm<sup>2</sup> , which are realized by one-step spin-coating method with anti-solvent process. Whereas, the Br-rich perovskites undergo faster crystallization than that of normal-bandgap perovskites, which might induce uncontrollable crystal growth, and lead to more trap states and inferior reproducibility. Therefore, modulating the crystallization of one-step processed WBG perovskites is critical for high-performance perovskite-based TSCs [233–235]. For two-step solution method,  PbI2/PbBr2 layer is firstly deposited, followed by reacting with FAX/MAX (X = I, Br, Cl) isopropanol solution. This method is capable of depositing thick perovskite films, while adjusting the bandgap to desirable values is more complicated than one-step method. Though it has been successfully applied to normal-bandgap (< 1.6 eV) PSCs [2, 236], it has not been widely employed for WBG PSCs and 2-T TSCs [101]. Liu et al _._ successfully fabricated WBG perovskites with a bandgap of 1.63–1.65 eV using two-step solution method via optimizing the solution composition and the rotate speed of the second step. Solar cells gave a PCE of 20.35% with a high fill factor of 81.53% [237]. Chen et al _._ introduced formamidinium iodide (FAI) and rubidium acetate (RbAc) into the  PbI2/PbBr2 complex to create temperate particle size for nucleation site, thus facilitating the diffusion of FAI/MABr/MACl [238]. While the control  PbI2/ PbBr2 film demonstrated better crystallinity and larger grain size, which would definitely impede the diffusion of organic salts, resulting in incomplete conversion. Consequently, the FAI + RbAc additives contributed to preferentially (100)-oriented growth of the WBG perovskite film (Fig. 15a), giving rise to a PCE of 27.64% for 2-T perovskite/silicon TSCs. 

Vacuum-deposition of perovskite films is a solvent-free process, which is beneficial for better film stability. Longo et al _._ reported fully vacuum-deposited MAPb(BrxI1−x)3 perovskite films with bandgaps of 1.72 and 1.87 eV via regulating the deposition rates of the different halide raw materials [239]. And the solar cells using these perovskite films afforded PCEs of 15.9% and 10.5%, respectively. Bolink’ 

group developed a 2-T  MAPbI3/MAPbI3 TSC via vacuumdeposition method and achieved a extremely high _V_ OC of 2.30 V, yielding a PCE of 18.02% [240]. In order to reduce the light reflection, texturing process is widely employed for highly efficient silicon solar cells. Whereas, the pyramid textured surface makes it quite difficult to deposit conformal and full-covered perovskite layer upon it. Therefore, combining evaporation and solution process is put forward to prepare perovskite film on textured silicon solar cells, that is, a conformal  PbX2 layer is deposited by evaporation, and then spin-coating organic salts solution. Sahli et al. reported a fully textured perovskite layer by co-evaporating a  PbI2 and CsBr compounds before spin-coating an organohalide solution (FAI, FABr) [193]. The co-evaporation of CsBr can produce a porous  PbI2 layer to facilitate the diffusion of FAI and FABr, achieving the conformal growth of perovskite film directly on the micrometer-sized pyramids of textured silicon cell (Fig. 15b–d). In addition, all the charge transport layers and buffer layers are deposited by evaporation technique, realizing a fully textured 2-T perovskite/silicon TSCs. The perovskite and silicon sub-cells presented fantastic current-matching, that are 20.1 and 20.3 mA  cm<sup>−2</sup> , respectively, contributing to a certified PCE of 25.2%. Albrecht’ group introduced MAI to stabilize the  FAPbI3 during the co-evaporation process [241]. Impressively, by optimizing the MAI/FAI ratio, solar cells maintained 100% of the initial efficiency after constant operation with 1000 h. And the fully textured 2-T perovskite/silicon TSC offered a PCE of 24.6%. Furthermore, they also investigated the influence of the MAI purity on device performance. Usually, the lowpurity MAI contains hydroiodic acid (HI) and hypophosphorous acid  (H3PO2) [242]. They found that the evaporated of low-purity MAI would go straight to the substrate due to the low sublimation temperature, while the evaporation of highpurity MAI requires high sublimation temperature, resulting in a cloud-like MAI vapor in the chamber. The impurities (HI and  H3PO2) in the MAI would lead to poor stability of perovskite films. Liu and co-workers adopted  NiOx/2PACz HTL, co-evaporation of  PbI2 and CsBr followed with spincoating FAI/MABr/MACl ethanol solution for the preparation of perovskite top-cell, achieving a highest certified efficiency of 28.84% for the fully textured perovskite/silicon TSCs (Fig. 15e) [188]. 

In addition to the vacuum deposition technique, solutionprocessed perovskite on textured silicon cells with small 

1 3 

**70** Page 30 of 44 

Nano-Micro Lett. (2023) 15:70 



**Fig. 15  a** Schematic diagram of two-step preparation method. Reproduced with permission from Ref. [238]. Copyright 2022, American Chemical Society. **b** Schematic view of a fully textured monolithic perovskite/SHJ tandem. **c** Secondary electron SEM image of the perovskite layer. **d** Cross section of the full perovskite top cell deposited on the SHJ bottom cell. Reproduced with permission from Ref. [193]. Copyright 2018, Nature Publishing Group. **e** Schematic illustration of the processing procedures of  NiOx/2PACz hybrid HTL and perovskite on fully textured bottom SHJ cell. Reproduced with permission from Ref. [188]. Copyright 2022, Wiley–VCH. **f** SEM top-view and cross-sectional images of the textured _c_ -Si and _c-_ Si/perovskite layers. Reproduced with permission from Ref. [243]. Copyright 2020, Science Publishing Group 

pyramids (< 1 μm) is also realizable. In this case, high concentration of perovskite precursor using multi-step spin coating process is commonly required to achieve thick perovskite film and complete coverage on the pyramids. Hou et al. prepared a 1.65–1.75 M  Cs0.05MA0.15FA0.8PbI2.25Br0.75 precursor solution and adopted three consecutive spin-coating steps of 300, 1,500, and 5,000 rpm, which allowed a micrometer-thick perovskite film on the fully textured silicon cell (Fig. 15f), yielding a 25.7% efficiency for TSCs [243]. Huang’s group demonstrated a nitrogen-assisted blading process to deposit both conformal hole transport layer and perovskite layer that fully covers the silicon cell textured with pyramids less than 1 μm in height [180]. The thickness of the blade-coated perovskite film can be tuned through the concentration of the perovskite precursor, the gap distance between the substrate and blade, and the speed of bladecoating. A crucial challenge is to deposit dense perovskite films with desirable thicknesses that are intimately contact with the textured silicon surface. In view of this, they tuned the ratio of DMSO/Pb in precursor considering that DMSO can coordinate with the perovskite to form intermediate 

phases and thus be expected to control the crystallization. For the DMSO-free system, the dying process starts at the air/solution interface as the solvent evaporates from the top surface, quickly forming a solid shell. The shell can serve as template to grow downward as the remaining precursor dries. When the last 2-methoxyethanol (2-ME) solvent evaporates and no precursor remains to fill its volume, the voids would be formed between the dry film and textured wafer. Fortunately, the DMSO can prohibit the quick formation of solid top shell due to its high boiling point and strong ability of coordinating with perovskite to form intermediate phase, which would allow 2-ME to evaporate and suppress the formation of voids. However, too much DMSO in the precursor could also cause voids formation, which can be explained by the shrinkage of the annealed film as due to the release of DMSO from the intermediate phase (Fig. 16a). Only for moderate DMSO concentration (25% in their experiment) can compensate the volume reduction by perovskite diffusion upon DMSO departure, thus achieving a dense WBG perovskite film on textured surface after annealing. As a result, they achieved a PCE of 26.2% for the perovskite/silicon 

© The authors 

https://doi.org/10.1007/s40820-023-01040-6 

Page 31 of 44 **70** 

Nano-Micro Lett. (2023) 15:70 



**Fig. 16  a** Schematic depiction of the evolution of a perovskite layer on a textured surface. Reproduced with permission from Ref. [180]. Copyright 2020, Elsevier. **b** Schematic illustration of gas-assisted blade coating. Reproduced with permission from Ref. [110]. Copyright 2022, Science Publishing Group. **c** Schematic illustration of slot-die-coating. Reproduced with permission from Ref. [179]. Copyright 2020, American Chemical Society 

TSC. Tan and co-workers found that the crystal nucleation rate of CsFA-based  (CsxFA1-xPbI1.8Br1.2) WBG perovskite films can be well controlled by finely tuning the Cs ratio, combining with a gas-assisted blade-coating technique (Fig. 16b) [110]. Interestingly, the crystallinity and crystal orientation of the blade-coated films were strongly related to the Cs ratio, which showed weak impact on spin-coated films. The champion  Cs0.35FA0.65PbI1.8Br1.2 solar cell offered a PCE of 17.2% with an _V_ OC of 1.266 V, contributing to a 21.7% efficiency for 20  cm<sup>2</sup> area all-perovskite tandem module. Subbiah et al _._ reported slot-die-coated  MAPbI2.25Br0.75 PSCs for three different conditions: using the acetonitrile (ACN) + MA gas (dissolved in methanol) (MA(MeOH)) 

solvent precursor; using the ACN + MA(MeOH) solvent with L-α-phosphatidylcholine (LP) additive; and using the ACN + MA(MeOH) solvent with the LP additive and cysteine hydrochloride (Cys.HCl) surface treatment [179]. Consequently, the slot-die-coated 2-T perovskite/silicon TSC (Fig. 16c) achieved a PCE of 23.8% using the third recipe. Table 6 summarized the device performance of WBG PSCs with representative preparation method. It can see that most of high-performance WBG PSCs are made from one-step spin-coating method, which is not suitable for upscaling fabrication of TSCs. Though blade-coating and slot-die have been widely used for normal-bandgap PSCs, their application in perovskite-based TSCs needs further exploration. 

1 3 

**70** Page 32 of 44 

Nano-Micro Lett. (2023) 15:70 

### **5  Outlook** 

##### **5.1  Crystallization Control** 

High-quality perovskite film is the guarantee of high-performance PSCs. Though there are plenty of crystallization modulation strategies surrounding normal-bandgap and allinorganic perovskites, effective approaches put forward for organic–inorganic hybrid WBG perovskites are relatively few. Both heavy Cs and Br ions doping can arise ultrafast crystallization, leading to inferior crystallinity, amounts of defects and irreversible microstrain, thereby significantly affecting efficiency and stability, especially for upscaling fabrication. Here, we suggest efforts can be carried out from the following aspects: 

- (1) Figuring out the colloidal chemistry of WBG perovskite precursor, such as species of colloidal complexes, solute coordination interaction, and colloidal particle sizes [244]. 

- (2) Forming intermediate phase via suitable additives to slow down the crystallization rate of WBG perovskites, and achieve uniform and large crystals [245, 246]. 

- (3) Optimizing the wettability of substrates, surface of wet precursor film and annealing temperature to modulate the surface free energy for nucleation and crystal growth. 

- (4) Pointedly bonding with halogens to improve the distribution uniformity and immobility of anions. 

##### **5.2  Composition Optimization** 

Although the bandgap of perovskites is the same, their compositions may be diverse, which might induce quite different crystal and electronic structures, thus further affecting the intrinsic optoelectronic properties. Different combinations can also influence the colloidal chemistry and crystallization process to influence the film quality, like grain size, defects and lattice stress. In addition, composition is also vitally important for the stability issues, including structural, light, air and thermal stability. Suggestions on composition engineering of WBG perovskites can be taken into account: 

**Table 6** Summary of WBG PSCs with representative preparation method 

|Perovskite|preparation method|_E_g(eV)|_V_OC<br>(V)|_J_SC<br>(mA  cm<sup>−2</sup>)|FF<br>(%)|PCE (%)|References|
|---|---|---|---|---|---|---|---|
|FAMACsPb(I0.8Br0.2)3|One-step solvent|1.67|1.195|23.06|79.32|21.85|[235]|
|Cs0.22FA0.78PbI2.55Br0.45|One-step solvent|1.67|1.217|20.18|83.16|20.42|[99]|
|Cs0.22FA0.78Pb(I0.85Br0.15)3|One-step solvent|1.67|1.19|20.33|81.7|19.76|[100]|
|Cs0.1FA0.2MA0.7Pb(I0.85Br0.15)3|One-step solvent|1.65|1.25|21.1|83|21.2|[147]|
|Cs0.05FA0.8MA0.15Pb(I0.75Br0.25)3|One-step solvent|1.68|1.218|20.2|80.6|20.2|[156]|
|Cs0.05MA0.15FA0.8Pb(I0.85Br0.15)3|One-step solvent|1.68|1.200|21.6|76.6|19.8|[198]|
|Cs0.15MA0.15FA0.7Pb(I0.8Br0.2)3|One-step solvent|1.68|1.22|NA|NA|20.5|[224]|
|Cs0.05(FA0.77MA0.23)0.95Pb(I0.77Br0.23)3|One-step solvent|1.68|1.224|20.7|82.0|20.8|[107]|
|Cs0.05FA0.8MA0.15Pb(I0.755Br0.255)3|One-step solvent|1.69|1.226|20.58|81.1|20.46|[13]|
|NA|Two-step solvent|1.63|1.13|22.11|81.53|20.35|[237]|
|FAxCs1-xPb(IyBr1-y)3|Two-step solvent|1.63|1.20|21.82|80.40|21.02|[238]|
|FA0.5MA0.38Cs0.12PbI2.04Br0.96|Two-step solvent|1.69|1.162|16.17|69.64|13.09|[101]|
|MAPbI2.4Br0.6|Two-step solvent|1.72|1.02|17.5|73.7|13.1|[87]|
|NA|Vacuum + Solution|1.65|1.14|23.19|80.6|21.31|[188]|
|FA0.9Cs0.1PbI2.87Br0.13|Vacuum + Solution|1.64|1.082|19.59|80.34|17.03|[194]|
|CsxFA1−xPb(I,Br)3|Vacuum + Solution|1.6|1.046|18.4|59.6|11.51|[193]|
|MAPb(Br0.2I0.8)3|Vacuum deposition|1.72|1.119|17.3|82.3|15.9|[239]|
|MAPb(Br0.5I0.5)3|Vacuum deposition|1.87|1.207|11.4|76.9|10.6|[239]|
|Cs0.1MA0.9Pb(I0.9Br0.1)3|Blade coating|1.65|1.167|21.0|82.0|20.1|[180]|
|Cs0.35FA0.65PbI1.8Br1.2|Blade coating|1.80|1.266|16.8|80.9|17.2|[110]|
|MAPb(I0.75Br0.25)3|Slot-die coating|1.68|1.20|NA|NA|18.05|[179]|



© The authors 

https://doi.org/10.1007/s40820-023-01040-6 

Page 33 of 44 **70** 

Nano-Micro Lett. (2023) 15:70 

- (1) Exploring the effect of composition on carrier mobility and lifetime, formation energy of defects, as well as ion migration barrier. 

optimizing these interfaces is also conducive to improving interfacial energy alignment, facilitating charge transfer and reducing interfacial non-radiative recombination. 

- (2) Harmonizing the ratio of A and X-site ions to eliminate or minimize the size mismatch that could induce additional lattice stress. 

- (3) Developing low-temperature processed and high-performance inverted all-inorganic PSCs to promote the application of photostable  CsPbI3-xBrx perovskites in tandem devices. 

##### **5.3  Defect Passivation** 

Defects are deadly for efficiency and stability improvement. Trap-assisted non-radiative recombination is responsible for _V_ OC loss, while ion migration along halide vacancy results in phase segregation. Though great progress has been made focusing on defect passivation, the corresponding mechanism kept fuzzy, and most of works are based on trial-anderror method. In order to reduce _V_ OC loss and improve stability, we believe that: 

- (1) Further illuminating the defect type like vacancies and anti-site defects, positively or negatively charged. This is vital for providing more pointed and effective defect passivation.‘’ 

- (2) Grain boundaries, buried interface and film surface assemble amounts of different defects, simultaneously modifying these positions to achieve better passivation effect deserves further exploration. 

- (3) Multi-site passivation provided by multi-functional molecules are also necessary. 

##### **5.4  Charge Transport Optimization** 

It is critical to develop novel CTLs to minimize the energy level mismatch between WBG perovskite and CTLs, thus to effectively enhance the charge transportation and reduce _V_ OC loss. Meanwhile, for underlying CTLs, it should be able to conformally cover the textured pyramids of silicon cell or rough surface of CIGS cell, and they are also expected to bond with perovskite to passivate buried interface. Furthermore, since PSCs demonstrate a typical sandwich structure, which contains various interfaces, like perovskite/CTLs interfaces, CTLs/electrodes interfaces, etc., 

##### **5.5  Upscaling Fabrication** 

To date, high-efficiency WBG PSCs were successfully achieved by spin-coating method, and it is urgent to transfer the small-area solar cells into upscaling modules [247, 248]. Whereas, the ultrafast crystallization of WBG perovskites makes it challenge for depositing high-quality perovskite films with large-area and low defect density. Therefore, crystallization control and defect passivation become extremely important for upscaling fabrication. In addition, since WBG perovskites facing tandem application, large-area fabrication of CTLs and transparent electrodes cannot be ignored. Magnetron sputtering, electron beam, atomic layer deposition techniques and so on are expected to be widely used. 

##### **5.6  Stability** 

The extremely high efficiency of perovskite-based TSCs makes it promising for commercialization upon the stability issues can be well addressed. Besides the above mentioned strategies via controlling composition and crystallization to prepare high-quality perovskite films to improve film stability, the chemical stability of CTLs or buffer layers are also crucial for device stability [249–251]. They are expected to eliminate the diffusion of ions from metal electrodes or halide ions from perovskite films. Moreover, ALD-deposited  SnO2 and  NiOx have also been proven to greatly strength the device stability. Certainly, industrialized encapsulation technique is quite necessary to protect the device from water and oxygen erosion. Once the longterm stability is addressed, the perovskite-based TSCs will be ready for commercialization. 

### **6  Conclusion** 

In this review, we summarized recent progress of WBG PSCs. The compositions, additives, charge transport layers, interfaces and preparation methods are carefully 

1 3 

**70** Page 34 of 44 

Nano-Micro Lett. (2023) 15:70 

discussed. The effect of crystallization and crystal structure on device performance are highlighted. Challenges including _V_ OC deficit, stability and module fabrication are still the key concerns for WBG PSCs. And we gave an critical outlook on the strategies toward the highly efficient, long-term stable and large-area WBG PSCs for tandem application. As the increasing interest for perovskite-based TSCs around the world, we believe these challenges will be overcome, and the performance of WBG PSCs will continue to surprise us. 

**Acknowledgements** The authors acknowledge support from the 111 Project (B21005), the National Natural Science Foundation of China (Grant No. 62174103) and the National University Research Fund (GK202103108). 

**Funding** Open access funding provided by Shanghai Jiao Tong University. 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http:// creat iveco mmons. org/ licen ses/ by/4. 0/. 

### **References** 

1. National Renewable Energy Laboratory, Best research-cell efficiency chart. https:// www. nrel. gov/ pv/ cell- effic iency. html 

2. Y. Zhao, F. Ma, Z.H. Qu, S.Q. Yu, T. Shen et al., Inactive (PbI2)2RbCl stabilizes perovskite films for efficient solar cells. Science **377** (6605), 531–534 (2022). https:// doi. org/ 10. 1126/ scien ce. abp88 73 

3. T.K. Zhang, F. Wang, H.B. Kim, I.W. Choi, C.F. Wang et al., Ion-modulated radical doping of spiro-OMeTAD for more efficient and stable perovskite solar cells. Science **377** (6605), 495–501 (2022). https:// doi. org/ 10. 1126/ scien ce. abo27 57 

4. M. Kim, J. Jeong, H. Lu, T.K. Lee, F.T. Eickemeyer et al., Conformal quantum dot-SnO2 layers as electron transporters for efficient perovskite solar cells. Science **375** (6578), 302–306 (2022). https:// doi. org/ 10. 1126/ scien ce. abh18 85 

5. T.A.S. Doherty, S. Nagane, D.J. Kubicki, Y.K. Jung, D.N. Johnstone et al., Stabilized tilted-octahedra halide perovskites inhibit local formation of performance-limiting 

phases. Science **374** (6575), 1598–1605 (2021). https:// doi. org/ 10. 1126/ scien ce. abl48 90 

6. Q. Jiang, J. Tong, Y. Xian, R.A. Kerner, S.P. Dunfield et al., Surface reaction for efficient and stable inverted perovskite solar cells. Nature **611** (7935), 278–283 (2022). https:// doi. org/ 10. 1038/ s41586- 022- 05268-x 

7. T. Wu, Z. Qin, Y. Wang, Y. Wu, W. Chen et al., The main progress of perovskite solar cells in 2020–2021. NanoMicro Lett. **13** , 152 (2021). https:// doi. org/ 10. 1007/ s40820- 021- 00672-w 

8. L. Wang, H. Zai, Y. Duan, G. Liu, X. Niu et al., Cost analysis of perovskite/Cu(In, Ga)Se2 tandem photovoltaic with module replacement. ACS Energy Lett. **7** (6), 1920–1925 (2022). https:// doi. org/ 10. 1021/ acsen ergyl ett. 2c008 86 

9. Q.F. Han, Y.T. Hsieh, L. Meng, J.L. Wu, P.Y. Sun et al., Highperformance perovskite/Cu(In, Ga)Se2 monolithic tandem solar cells. Science **361** (6405), 904–908 (2018). https:// doi. org/ 10. 1126/ scien ce. aat50 55 

10. Z.M. Fang, Q. Zeng, C.T. Zuo, L.X. Zhang, H.R. Xiao et al., Perovskite-based tandem solar cells. Sci. Bull. **66** (6), 621– 636 (2021). https:// doi. org/ 10. 1016/j. scib. 2020. 11. 006 

11. H. Li, W. Zhang, Perovskite tandem solar cells: from fundamentals to commercial deployment. Chem. Rev. **120** (18), 9835–9950 (2020). https:// doi. org/ 10. 1021/ acs. chemr ev. 9b007 80 

12. F. Fu, J. Li, T.C. Yang, H. Liang, A. Faes et al., Monolithic perovskite-silicon tandem solar cells: from the lab to fab? Adv. Mater. **34** (24), 2106540 (2022). https:// doi. org/ 10. 1002/ adma. 20210 6540 

13. J. Liu, M. Bastiani, E. Aydin, G.T. Harrison, Y.J. Gao et al., Efficient and stable perovskite-silicon tandem solar cells through contact displacement by  MgFx. Science **377** (6603), 302–306 (2022). https:// doi. org/ 10. 1126/ scien ce. abn89 10 

14. R. Azmi, E. Ugur, A. Seitkhan, F. Aljamaan, A.S. Subbiah et al., Damp heat-stable perovskite solar cells with tailoreddimensionality 2D/3D heterojunctions. Science **376** (6588), 73–77 (2022). https:// doi. org/ 10. 1126/ scien ce. abm57 84 

15. K.O. Brinkmann, T. Becker, F. Zimmermann, C. Kreusel, T. Gahlmann et al., Perovskite-organic tandem solar cells with indium oxide interconnect. Nature **604** (7905), 280–286 (2022). https:// doi. org/ 10. 1038/ s41586- 022- 04455-0 

16. R. Lin, K. Xiao, Z. Qin, Q. Han, C. Zhang et al., Monolithic all-perovskite tandem solar cells with 24.8% efficiency exploiting comproportionation to suppress Sn(II) oxidation in precursor ink. Nat. Energy **4** (10), 864–873 (2019). https:// doi. org/ 10. 1038/ s41560- 019- 0466-3 

17. K. Xiao, R. Lin, Q. Han, Y. Hou, Z. Qin et al., All-perovskite tandem solar cells with 24.2% certified efficiency and area over 1  cm<sup>2</sup> using surface-anchoring zwitterionic antioxidant. Nat. Energy **5** (11), 870–880 (2020). https:// doi. org/ 10. 1038/ s41560- 020- 00705-5 

18. C.C. Chen, S.H. Bae, W.H. Chang, Z. Hong, G. Li et al., Perovskite/polymer monolithic hybrid tandem solar cells utilizing a low-temperature, full solution process. Mater. Horiz. **2** (2), 203–211 (2015). https:// doi. org/ 10. 1039/ c4mh0 0237g 

© The authors 

https://doi.org/10.1007/s40820-023-01040-6 

Page 35 of 44 **70** 

Nano-Micro Lett. (2023) 15:70 

19. Y. Liu, L.A. Renna, M. Bag, Z.A. Page, P. Kim et al., High efficiency tandem thin-perovskite/polymer solar cells with a graded recombination layer. ACS Appl. Mater. Interfaces **8** (11), 7070–7076 (2016). https:// doi. org/ 10. 1021/ acsami. 5b127 40 

20. K. Xiao, J. Wen, Q.L. Han, R.X. Lin, Y. Gao et al., Solutionprocessed monolithic all-perovskite triple-junction solar cells with efficiency exceeding 20%. ACS Energy Lett. **5** (9), 2819– 2826 (2020). https:// doi. org/ 10. 1021/ acsen ergyl ett. 0c011 84 

21. J. Tong, Q. Jiang, F. Zhang, S.B. Kang, D.H. Kim et al., Wide-bandgap metal halide perovskites for tandem solar cells. ACS Energy Lett. **6** (1), 232–248 (2020). https:// doi. org/ 10. 1021/ acsen ergyl ett. 0c021 05 

22. R. Wang, T.Y. Huang, J.J. Xue, J.H. Tong, K. Zhu et al., Prospects for metal halide perovskite-based tandem solar cells. Nat. Photon. **15** (6), 411–425 (2021). https:// doi. org/ 10. 1038/ s41566- 021- 00809-8 

23. J.H. Zheng, G.L. Wang, W.Y. Duan, M.A. Mahmud, H.M. Yi et al., Monolithic perovskite-perovskite-silicon triplejunction tandem solar cell with an efficiency of over 20%. ACS Energy Lett. **7** (9), 3003–3005 (2022). https:// doi. org/ 10. 1021/ acsen ergyl ett. 2c015 56 

24. J. Wang, V. Zardetto, K. Datta, D. Zhang, M.M. Wienk et al., 16.8% monolithic all-perovskite triple-junction solar cells via a universal two-step solution process. Nat. Commun. **11** , 5254 (2020). https:// doi. org/ 10. 1038/ s41467- 020- 19062-8 

25. X. Chen, Z.Y. Jia, Z. Chen, T.M. Jiang, L.Z. Bai et al., Efficient and reproducible monolithic perovskite/organic tandem solar cells with low-loss interconnecting layers. Joule **4** (7), 1594–1606 (2020). https:// doi. org/ 10. 1016/j. joule. 2020. 06. 006 

26. S. Jiang, Y.M. Bai, Z.W. Ma, S.L. Jin, C. Zou et al., Recent advances of monolithic all-perovskite tandem solar cells: From materials to devices. Chinese J. Chem. **40** (7), 856–871 (2022). https:// doi. org/ 10. 1002/ cjoc. 20210 0672 

27. Q. Guo, C.Y. Wang, T. Hayat, A. Alsaedi, J.X. Yao et al., Recent advances in perovskite/organic integrated solar cells. Rare Met. **40** (10), 2763–2777 (2021). https:// doi. org/ 10. 1007/ s12598- 020- 01703-y 

28. Y. Bai, K. Lang, C. Zhao, Q. Guo, R. Zeng et al., Strategies toward extending the near-infrared photovoltaic response of perovskite solar cells. Sol. RRL **4** (2), 1900280 (2019). https:// doi. org/ 10. 1002/ solr. 20190 0280 

29. M. Jošt, E. Köhnen, A. Al-Ashouri, T. Bertram, Š Tomšič et al., Perovskite/CIGS tandem solar cells: from certified 24.2% toward 30% and beyond. ACS Energy Lett. **7** (4), 1298–1307 (2022). https:// doi. org/ 10. 1021/ acsen ergyl ett. 2c002 74 

30. W. Chen, Y. Zhu, J. Xiu, G. Chen, H. Liang et al., Monolithic perovskite/organic tandem solar cells with 23.6% efficiency enabled by reduced voltage losses and optimized interconnecting layer. Nat. Energy **7** (3), 229–237 (2022). https:// doi. org/ 10. 1038/ s41560- 021- 00966-8 

31. M.A. Green, E.D. Dunlop, J. Hohl-Ebinger, M. Yoshita, N. Kopidakis et al., Solar cell efficiency tables (version 60). 

Prog. Photovolt. Res. Appl. **30** (7), 687–701 (2022). https:// doi. org/ 10. 1002/ pip. 3595 

32. D. Yang, X. Zhang, Y. Hou, K. Wang, T. Ye et al., 28.3%-efficiency perovskite/silicon tandem solar cell by optimal transparent electrode for high efficient semitransparent top cell. Nano Energy **84** , 105934 (2021). https:// doi. org/ 10. 1016/j. nanoen. 2021. 105934 

33. C. Gao, D.X. Du, D. Ding, F.Y. Qiao, W.Z. Shen, A review on monolithic perovskite/c-Si tandem solar cells: progress, challenges, and opportunities. J. Mater. Chem. A **10** (20), 10811–10828 (2022). https:// doi. org/ 10. 1039/ d2ta0 1470j 

34. Y. Yao, P. Hang, B. Li, Z. Hu, C. Kan et al., Phase-stable wide-bandgap perovskites for four-terminal perovskite/silicon tandem solar cells with over 30% efficiency. Small **18** (38), 2203319 (2022). https:// doi. org/ 10. 1002/ smll. 20220 3319 

35. R. He, S. Ren, C. Chen, Z. Yi, Y. Luo et al., Wide-bandgap organic-inorganic hybrid and all-inorganic perovskite solar cells and their application in all-perovskite tandem solar cells. Energy Environ. Sci. **14** (11), 5723–5759 (2021). https:// doi. org/ 10. 1039/ d1ee0 1562a 

36. Y. Zhou, Y. Zhao, Chemical stability and instability of inorganic halide perovskites. Energy Environ. Sci. **12** (5), 1495– 1511 (2019). https:// doi. org/ 10. 1039/ c8ee0 3559h 

37. G. Kieslich, S.J. Sun, A.K. Cheetham, Solid-state principles applied to organic-inorganic perovskites: new tricks for an old dog. Chem. Sci. **5** (12), 4712–4715 (2014). https:// doi. org/ 10. 1039/ c4sc0 2211d 

38. W. Travis, E.N.K. Glover, H. Bronstein, D.O. Scanlon, R.G. Palgrave, On the application of the tolerance factor to inorganic and hybrid halide perovskites: a revised system. Chem. Sci. **7** (7), 4548–4556 (2016). https:// doi. org/ 10. 1039/ c5sc0 4845a 

39. M. Becker, T. Kluner, M. Wark, Formation of hybrid  ABX3 perovskite compounds for solar cell application: first-principles calculations of effective ionic radii and determination of tolerance factors. Dalton Trans. **46** (11), 3500–3509 (2017). https:// doi. org/ 10. 1039/ c6dt0 4796c 

40. W.J. Yin, T.T. Shi, Y.F. Yan, Unusual defect physics in CH3NH3PbI3 perovskite solar cell absorber. Appl. Phys. Lett. **104** (6), 063903 (2014). https:// doi. org/ 10. 1063/1. 48647 78 

41. E. Mosconi, A. Amat, M.K. Nazeeruddin, M. Gratzel, F.D. Angelis, First-principles modeling of mixed halide organometal perovskites for photovoltaic applications. J. Phys. Chem. C **117** (27), 13902–13913 (2013). https:// doi. org/ 10. 1021/ jp404 8659 

42. S.N. Yun, X. Zhou, J. Even, A. Hagfeldt, Theoretical treatment of  CH3NH3PbI3 perovskite solar cells. Angew. Chem. Int. Ed. **56** (50), 15806–15817 (2017). https:// doi. org/ 10. 1002/ anie. 20170 2660 

43. A. Amat, E. Mosconi, E. Ronca, C. Quarti, P. Umari et al., Cation-induced band-gap tuning in organohalide perovskites: interplay of spin-orbit coupling and octahedra tilting. Nano Lett. **14** (6), 3608–3616 (2014). https:// doi. org/ 10. 1021/ nl501 2992 

44. A. Goyal, S. McKechnie, D. Pashov, W. Tumas, M. Schilfgaarde et al., Origin of pronounced nonlinear band gap 

1 3 

**70** Page 36 of 44 

Nano-Micro Lett. (2023) 15:70 

behavior in lead–tin hybrid perovskite alloys. Chem. Mater. **30** (11), 3920–3928 (2018). https:// doi. org/ 10. 1021/ acs. chemm ater. 8b016 95 

45. Z. Fan, K. Sun, J. Wang, Perovskites for photovoltaics: a combined review of organic-inorganic halide perovskites and ferroelectric oxide perovskites. J. Mater. Chem. A **3** (37), 18809–18828 (2015). https:// doi. org/ 10. 1039/ c5ta0 4235f 

46. A. Buin, R. Comin, J.X. Xu, A.H. Ip, E.H. Sargent, Halidedependent electronic structure of organolead perovskite materials. Chem. Mater. **27** (12), 4405–4412 (2015). https:// doi. org/ 10. 1021/ acs. chemm ater. 5b019 09 

47. S.D. Stranks, G.E. Eperon, G. Grancini, C. Menelaou, M.J.P. Alcocer et al., Electron-hole diffusion lengths exceeding 1 micrometer in an organometal trihalide perovskite absorber. Science **342** (6156), 341–344 (2013). https:// doi. org/ 10. 1126/ scien ce. 12439 82 

48. Q. Ye, Y. Zhao, S. Mu, F. Ma, F. Gao et al., Cesium lead inorganic solar cell with efficiency beyond 18% via reduced charge recombination. Adv. Mater. **31** (49), 1905143 (2019). https:// doi. org/ 10. 1002/ adma. 20190 5143 

49. M. Ren, S. Cao, J. Zhao, B. Zou, R. Zeng, Advances and challenges in two-dimensional organic-inorganic hybrid perovskites toward high-performance light-emitting diodes. Nano-Micro Lett. **13** , 163 (2021). https:// doi. org/ 10. 1007/ s40820- 021- 00685-5 

50. Y. Han, S. Yue, B.B. Cui, Low-dimensional metal halide perovskite crystal materials: structure strategies and luminescence applications. Adv. Sci. **8** (15), 2004805 (2021). https:// doi. org/ 10. 1002/ advs. 20200 4805 

51. C. Huo, B. Cai, Z. Yuan, B. Ma, H. Zeng, Two-dimensional metal halide perovskites: theory, synthesis, and optoelectronics. Small Methods **1** (3), 1600018 (2017). https:// doi. org/ 10. 1002/ smtd. 20160 0018 

52. J.P. Mailoa, C.D. Bailie, E.C. Johlin, E.T. Hoke, A.J. Akey et al., A 2-terminal perovskite/silicon multijunction solar cell enabled by a silicon tunnel junction. Appl. Phys. Lett. **106** (12), 121105 (2015). https:// doi. org/ 10. 1063/1. 49141 79 

53. Z. Zhang, Z. Li, L. Meng, S.Y. Lien, P. Gao, Perovskitebased tandem solar cells: get the most out of the sun. Adv. Funct. Mater. **30** (38), 2001904 (2020). https:// doi. org/ 10. 1002/ adfm. 20200 1904 

54. M. Jošt, L. Kegelmann, L. Korte, S. Albrecht, Monolithic perovskite tandem solar cells: a review of the present status and advanced characterization methods toward 30% efficiency. Adv. Energy Mater. **10** (26), 1904102 (2020). https:// doi. org/ 10. 1002/ aenm. 20190 4102 

55. T. Leijtens, K.A. Bush, R. Prasanna, M.D. McGehee, Opportunities and challenges for tandem solar cells using metal halide perovskite semiconductors. Nat. Energy **3** (10), 828–838 (2018). https:// doi. org/ 10. 1038/ s41560- 018- 0190-4 

56. R. Lin, J. Xu, M. Wei, Y. Wang, Z. Qin et al., All-perovskite tandem solar cells with improved grain surface passivation. Nature **603** (7899), 73–78 (2022). https:// doi. org/ 10. 1038/ s41586- 021- 04372-8 

57. S. Mahesh, J.M. Ball, R.D.J. Oliver, D.P. McMeekin, P.K. Nayak et al., Revealing the origin of voltage loss in mixedhalide perovskite solar cells. Energy Environ. Sci. **13** (1), 258–267 (2020). https:// doi. org/ 10. 1039/ c9ee0 2162k 

58. J. Huang, Y. Yuan, Y. Shao, Y. Yan, Understanding the physical properties of hybrid perovskites for photovoltaic applications. Nat. Rev. Mater. **2** (7), 17042 (2017). https:// doi. org/ 10. 1038/ natre vmats. 2017. 42 

59. C.M. Wolff, P. Caprioglio, M. Stolterfoht, D. Neher, Nonradiative recombination in perovskite solar cells: the role of interfaces. Adv. Mater. **31** (52), 1902762 (2019). https:// doi. org/ 10. 1002/ adma. 20190 2762 

60. D.Y. Luo, R. Su, W. Zhang, Q.H. Gong, R. Zhu, Minimizing non-radiative recombination losses in perovskite solar cells. Nat. Rev. Mater. **5** (1), 44–60 (2020). https:// doi. org/ 10. 1038/ s41578- 019- 0151-y 

61. B. Chen, P.N. Rudd, S. Yang, Y.B. Yuan, J.S. Huang, Imperfections and their passivation in halide perovskite solar cells. Chem. Soc. Rev. **48** (14), 3842–3867 (2019). https:// doi. org/ 10. 1039/ c8cs0 0853a 

62. S.J. Yoon, S. Draguta, J.S. Manser, O. Sharia, W.F. Schneider et al., Tracking iodide and bromide ion segregation in mixed halide lead perovskites during photoirradiation. ACS Energy Lett. **1** (1), 290–296 (2016). https:// doi. org/ 10. 1021/ acsen ergyl ett. 6b001 58 

63. A.J. Knight, L.M. Herz, Preventing phase segregation in mixed-halide perovskites: a perspective. Energy Environ. Sci. **13** (7), 2024–2046 (2020). https:// doi. org/ 10. 1039/ d0ee0 0788a 

64. A.J. Knight, A.D. Wright, J.B. Patel, D.P. McMeekin, H.J. Snaith et al., Electronic traps and phase segregation in lead mixed-halide perovskite. ACS Energy Lett. **4** (1), 75–84 (2018). https:// doi. org/ 10. 1021/ acsen ergyl ett. 8b020 02 

65. Z. Xu, R.A. Kerner, J.J. Berry, B.P. Rand, Iodine electrochemistry dictates voltage-induced halide segregation thresholds in mixed-halide perovskite devices. Adv. Funct. Mater. **32** (33), 2203432 (2022). https:// doi. org/ 10. 1002/ adfm. 20220 3432 

66. D.J. Slotcavage, H.I. Karunadasa, M.D. McGehee, Lightinduced phase segregation in halide-perovskite absorbers. ACS Energy Lett. **1** (6), 1199–1205 (2016). https:// doi. org/ 10. 1021/ acsen ergyl ett. 6b004 95 

67. T. Duong, H.K. Mulmudi, Y. Wu, X. Fu, H. Shen et al., Light and electrically induced phase segregation and its impact on the stability of quadruple cation high bandgap perovskite solar cells. ACS Appl. Mater. Interfaces **9** (32), 26859–26866 (2017). https:// doi. org/ 10. 1021/ acsami. 7b068 16 

68. S.G. Motti, J.B. Patel, R.D.J. Oliver, H.J. Snaith, M.B. Johnston et al., Phase segregation in mixed-halide perovskites affects charge-carrier dynamics while preserving mobility. Nat. Commun. **12** , 6955 (2021). https:// doi. org/ 10. 1038/ s41467- 021- 26930-4 

69. L. Wang, Q. Song, F. Pei, Y. Chen, J. Dou et al., Strain modulation for light-stable n-i-p perovskite/silicon tandem solar cells. Adv. Mater. **34** (26), 2201315 (2022). https:// doi. org/ 10. 1002/ adma. 20220 1315 

© The authors 

https://doi.org/10.1007/s40820-023-01040-6 

Page 37 of 44 **70** 

Nano-Micro Lett. (2023) 15:70 

70. E. Ruggeri, M. Anaya, K. Galkowski, A. Abfalterer, Y.H. Chiang et al., Halide remixing under device operation imparts stability on mixed-cation mixed-halide perovskite solar cells. Adv. Mater. **34** (36), 2202163 (2022). https:// doi. org/ 10. 1002/ adma. 20220 2163 

71. Z. Wang, Z. Zhang, L. Xie, S. Wang, C. Yang et al., Recent advances and perspectives of photostability for halide perovskite solar cells. Adv. Opt. Mater. **10** (3), 2101822 (2021). https:// doi. org/ 10. 1002/ adom. 20210 1822 

72. J. Wen, Y.C. Zhao, Z. Liu, H. Gao, R.X. Lin et al., Steric engineering enables efficient and photostable wide-bandgap perovskites for all-perovskite tandem solar cells. Adv. Mater. **34** (26), 2110356 (2022). https:// doi. org/ 10. 1002/ adma. 20211 0356 

73. C. Liu, Y.B. Cheng, Z. Ge, Understanding of perovskite crystal growth and film formation in scalable deposition processes. Chem. Soc. Rev. **49** (6), 1653–1687 (2020). https:// doi. org/ 10. 1039/ c9cs0 0711c 

74. Q. Fu, X. Tang, B. Huang, T. Hu, L. Tan et al., Recent progress on the long-term stability of perovskite solar cells. Adv. Sci. **5** (5), 1700387 (2018). https:// doi. org/ 10. 1002/ advs. 20170 0387 

75. G. Nazir, S.Y. Lee, J.H. Lee, A. Rehman, J.K. Lee et al., Stabilization of perovskite solar cells: recent developments and future perspectives. Adv. Mater. **34** (50), 2204380 (2022). https:// doi. org/ 10. 1002/ adma. 20220 4380 

76. C.C. Boyd, R. Cheacharoen, T. Leijtens, M.D. McGehee, Understanding degradation mechanisms and improving stability of perovskite photovoltaics. Chem. Rev. **119** (5), 3418– 3451 (2019). https:// doi. org/ 10. 1021/ acs. chemr ev. 8b003 36 

77. J.Y. Kim, J.W. Lee, H.S. Jung, H. Shin, N.G. Park, Highefficiency perovskite solar cells. Chem. Rev. **120** (15), 7867– 7918 (2020). https:// doi. org/ 10. 1021/ acs. chemr ev. 0c001 07 

78. F.H. Isikgor, S. Zhumagali, L.V.T. Merino, M.D. Bastiani, I. McCulloch et al., Molecular engineering of contact interfaces for high-performance perovskite solar cells. Nat. Rev. Mater. (2022). https:// doi. org/ 10. 1038/ s41578- 022- 00503-3 

79. C.U. Kim, J.C. Yu, E.D. Jung, I.Y. Choi, W. Park et al., Optimization of device design for low cost and high efficiency planar monolithic perovskite/silicon tandem solar cells. Nano Energy **60** , 213–221 (2019). https:// doi. org/ 10. 1016/j. nanoen. 2019. 03. 056 

80. Y.M. Xie, Q. Yao, Z. Zeng, Q. Xue, T. Niu et al., Homogeneous grain boundary passivation in wide-bandgap perovskite films enables fabrication of monolithic perovskite/organic tandem solar cells with over 21% efficiency. Adv. Funct. Mater. **32** (19), 2112126 (2022). https:// doi. org/ 10. 1002/ adfm. 20211 2126 

81. H.X. Dang, K. Wang, M. Ghasemi, M.C. Tang, M.D. Bastiani et al., Multi-cation synergy suppresses phase segregation in mixed-halide perovskites. Joule **3** (7), 1746–1764 (2019). https:// doi. org/ 10. 1016/j. joule. 2019. 05. 016 

82. A.F. Palmstrom, G.E. Eperon, T. Leijtens, R. Prasanna, S.N. Habisreutinger et al., Enabling flexible all-perovskite tandem solar cells. Joule **3** (9), 2193–2204 (2019). https:// doi. org/ 10. 1016/j. joule. 2019. 05. 009 

83. M. Suri, A. Hazarika, B.W. Larson, Q. Zhao, M. VallésPelarda et al., Enhanced open-circuit voltage of wide-bandgap perovskite photovoltaics by using alloyed  (FA1–xCsx) Pb(I1–xBrx)3 quantum dots. ACS Energy Lett. **4** (8), 1954– 1960 (2019). https:// doi. org/ 10. 1021/ acsen ergyl ett. 9b010 30 

84. D. Zhao, C. Wang, Z. Song, Y. Yu, C. Chen et al., Fourterminal all-perovskite tandem solar cells achieving power conversion efficiencies exceeding 23%. ACS Energy Lett. **3** (2), 305–306 (2018). https:// doi. org/ 10. 1021/ acsen ergyl ett. 7b012 87 

85. Y.M. Xie, Z. Zeng, X. Xu, C. Ma, Y. Ma et al., FA-assistant iodide coordination in organic-inorganic wide-bandgap perovskite with mixed halides. Small **16** (10), 1907226 (2020). https:// doi. org/ 10. 1002/ smll. 20190 7226 

86. J.H. Heo, S.H. Im,  CH3NH3PbBr3-CH3NH3PbI3 perovskiteperovskite tandem solar cells with exceeding 2.2 V open circuit voltage. Adv. Mater. **28** (25), 5121–5125 (2016). https:// doi. org/ 10. 1002/ adma. 20150 1629 

87. C. Bi, Y. Yuan, Y. Fang, J. Huang, Low-temperature fabrication of efficient wide-bandgap organolead trihalide perovskite solar cells. Adv. Energy Mater. **5** (6), 1401616 (2015). https:// doi. org/ 10. 1002/ aenm. 20140 1616 

88. W. Zhu, C. Bao, F. Li, X. Zhou, J. Yang et al., An efficient planar-heterojunction solar cell based on wide-bandgap CH3NH3PbI2.1Br0.9 perovskite film for tandem cell application. Chem. Commun. **52** (2), 304–307 (2016). https:// doi. org/ 10. 1039/ c5cc0 7673k 

89. N.J. Jeon, J.H. Noh, W.S. Yang, Y.C. Kim, S. Ryu et al., Compositional engineering of perovskite materials for highperformance solar cells. Nature **517** (7535), 476–480 (2015). https:// doi. org/ 10. 1038/ natur e14133 

90. M. Saliba, T. Matsui, K. Domanski, J.Y. Seo, A. Ummadisingu et al., Incorporation of rubidium cations into perovskite solar cells improves photovoltaic performance. Science **354** (6309), 206–209 (2016). https:// doi. org/ 10. 1126/ scien ce. aah55 57 

91. M. Saliba, T. Matsui, J.Y. Seo, K. Domanski, J.P. CorreaBaena et al., Cesium-containing triple cation perovskite solar cells: improved stability, reproducibility and high efficiency. Energy Environ. Sci. **9** (6), 1989–1997 (2016). https:// doi. org/ 10. 1039/ c5ee0 3874j 

92. G. Kapil, T. Bessho, C.H. Ng, K. Hamada, M. Pandey et al., Strain relaxation and light management in tin-lead perovskite solar cells to achieve high efficiencies. ACS Energy Lett. **4** (8), 1991–1998 (2019). https:// doi. org/ 10. 1021/ acsen ergyl ett. 9b012 37 

93. D. Forgács, L. Gil-Escrig, D. Pérez-Del-Rey, C. Momblona, J. Werner et al., Efficient monolithic perovskite/perovskite tandem solar cells. Adv. Energy Mater. **7** (8), 1602121 (2017). https:// doi. org/ 10. 1002/ aenm. 20160 2121 

94. Y. Zhou, M. Yang, O.S. Game, W. Wu, J. Kwun et al., Manipulating crystallization of organolead mixed-halide thin films in antisolvent baths for wide-bandgap perovskite solar cells. ACS Appl. Mater. Interfaces **8** (3), 2232–2237 (2016). https:// doi. org/ 10. 1021/ acsami. 5b109 87 

1 3 

**70** Page 38 of 44 

Nano-Micro Lett. (2023) 15:70 

95. D. Forgács, D. Pérez-del-Rey, J. Ávila, C. Momblona, L. GilEscrig et al., Efficient wide bandgap double cation-double halide perovskite solar cells. J. Mater. Chem. A **5** (7), 3203– 3207 (2017). https:// doi. org/ 10. 1039/ c6ta1 0727c 

96. D.P. McMeekin, G. Sadoughi, W. Rehman, G.E. Eperon, M. Saliba et al., A mixed-cation lead mixed-halide perovskite absorber for tandem solar cells. Science **351** (6269), 151–155 (2016). https:// doi. org/ 10. 1126/ scien ce. aad58 45 

97. M. Yang, D.H. Kim, Y. Yu, Z. Li, O.G. Reid et al., Effect of non-stoichiometric solution chemistry on improving the performance of wide-bandgap perovskite solar cells. Mater. Today Energy **7** , 232–238 (2018). https:// doi. org/ 10. 1016/j. mtener. 2017. 10. 001 

98. K.A. Bush, K. Frohna, R. Prasanna, R.E. Beal, T. Leijtens et al., Compositional engineering for efficient wide band gap perovskites with improved stability to photoinduced phase segregation. ACS Energy Lett. **3** (2), 428–435 (2018). https:// doi. org/ 10. 1021/ acsen ergyl ett. 7b012 55 

99. J. Xu, C.C. Boyd, Z.J. Yu, A.F. Palmstrom, D.J. Witter et al., Triple-halide wide-bandgap perovskites with suppressed phase segregation for efficient tandems. Science **367** (6482), 1097–1104 (2020). https:// doi. org/ 10. 1126/ scien ce. aaz50 74 

100. R. Li, B. Chen, N. Ren, P. Wang, B. Shi et al., CsPbCl3-cluster-widened bandgap and inhibited phase segregation in a wide-bandgap perovskite and its application to NiOx-based perovskite/silicon tandem solar cells. Adv. Mater. **34** (27), 2201451 (2022). https:// doi. org/ 10. 1002/ adma. 20220 1451 

101. Z. Qiu, Z. Xu, N. Li, N. Zhou, Y. Chen et al., Monolithic perovskite/Si tandem solar cells exceeding 22% efficiency via optimizing top cell absorber. Nano Energy **53** , 798–807 (2018). https:// doi. org/ 10. 1016/j. nanoen. 2018. 09. 052 

102. S. Chen, Y. Hou, H. Chen, X. Tang, S. Langner et al., Exploring the stability of novel wide bandgap perovskites by a robot based high throughput approach. Adv. Energy Mater. **8** (6), 1701543 (2018). https:// doi. org/ 10. 1002/ aenm. 20170 1543 

103. X.Y. Zhu, V. Podzorov, Charge carriers in hybrid organicinorganic lead halide perovskites might be protected as large polarons. J. Phys. Chem. Lett. **6** (23), 4758–4761 (2015). https:// doi. org/ 10. 1021/ acs. jpcle tt. 5b024 62 

104. Z. Guo, Y. Wan, M. Yang, J. Snaider, K. Zhu et al., Longrange hot-carrier transport in hybrid perovskites visualized by ultrafast microscopy. Science **356** (6333), 59–62 (2017). https:// doi. org/ 10. 1126/ scien ce. aam77 44 

105. G.J. Nan, X. Zhang, M. Abdi-Jalebi, Z. Andaji-Garmaroudi, S.D. Stranks et al., How methylammonium cations and chlorine dopants heal defects in lead iodide perovskites. Adv. Energy Mater. **8** (13), 1702754 (2018). https:// doi. org/ 10. 1002/ aenm. 20170 2754 

106. H. Tan, F. Che, M. Wei, Y. Zhao, M.I. Saidaminov et al., Dipolar cations confer defect tolerance in wide-bandgap metal halide perovskites. Nat. Commun. **9** , 3100 (2018). https:// doi. org/ 10. 1038/ s41467- 018- 05531-8 

107. A. Al-Ashouri, E. Kohnen, B. Li, A. Magomedov, H. Hempel et al., Monolithic perovskite/silicon tandem solar cell with 

   - 29% efficiency by enhanced hole extraction. Science **370** (6522), 1300–1309 (2020). https:// doi. org/ 10. 1126/ scien ce. abd40 16 

108. R. Prasanna, A. Gold-Parker, T. Leijtens, B. Conings, A. Babayigit et al., Bandgap tuning via lattice contraction and octahedral tilting in perovskite materials for photovoltaics. J. Am. Chem. Soc. **139** (32), 11117–11124 (2017). https:// doi. org/ 10. 1021/ jacs. 7b049 81 

109. R.J. Stoddard, A. Rajagopal, R.L. Palmer, I.L. Braly, A.K.Y. Jen et al., Enhancing defect tolerance and phase stability of high-bandgap perovskites via guanidinium alloying. ACS Energy Lett. **3** (6), 1261–1268 (2018). https:// doi. org/ 10. 1021/ acsen ergyl ett. 8b005 76 

110. K. Xiao, Y.H. Lin, M. Zhang, R.D.J. Oliver, X. Wang et al., Scalable processing for realizing 21.7%-efficient all-perovskite tandem solar modules. Science **376** (6594), 762–767 (2022). https:// doi. org/ 10. 1126/ scien ce. abn76 96 

111. S.G. Ji, I.J. Park, H. Chang, J.H. Park, G.P. Hong et al., Stable pure-iodide wide-band-gap perovskites for efficient Si tandem cells via kinetically controlled phase evolution. Joule **6** (10), 2390–2405 (2022). https:// doi. org/ 10. 1016/j. joule. 2022. 08. 006 

112. S. Xie, R. Xia, Z. Chen, J. Tian, L. Yan et al., Efficient monolithic perovskite/organic tandem solar cells and their efficiency potential. Nano Energy **78** , 105238 (2020). https:// doi. org/ 10. 1016/j. nanoen. 2020. 105238 

113. P. Wang, W. Li, O.J. Sandberg, C.H. Guo, R. Sun et al., Tuning of the interconnecting layer for monolithic perovskite/ organic tandem solar cells with record efficiency exceeding 21%. Nano Lett. **21** (18), 7845–7854 (2021). https:// doi. org/ 10. 1021/ acs. nanol ett. 1c028 97 

114. X. Gu, X. Lai, Y. Zhang, T. Wang, W.L. Tan et al., Organic solar cell with efficiency over 20% and voc exceeding 2.1V enabled by tandem with all-inorganic perovskite and thermal annealing-free process. Adv. Sci. **9** (28), 2200445 (2022). https:// doi. org/ 10. 1002/ advs. 20220 0445 

115. H. Aqoma, I.F. Imran, F.T.A. Wibowo, N.V. Krishna, W. Lee et al., High-efficiency solution-processed two-terminal hybrid tandem solar cells using spectrally matched inorganic and organic photoactive materials. Adv. Energy Mater. **10** (37), 2001188 (2020). https:// doi. org/ 10. 1002/ aenm. 20200 1188 

116. K. Lang, Q. Guo, Z.W. He, Y.M. Bai, J.X. Yao et al., High performance tandem solar cells with inorganic perovskite and organic conjugated molecules to realize complementary absorption. J. Phys. Chem. Lett. **11** (22), 9596–9604 (2020). https:// doi. org/ 10. 1021/ acs. jpcle tt. 0c027 94 

117. Q. Zeng, L. Liu, Z. Xiao, F. Liu, Y. Hua et al., A two-terminal all-inorganic perovskite/organic tandem solar cell. Sci. Bull. **64** (13), 885–887 (2019). https:// doi. org/ 10. 1016/j. scib. 2019. 05. 015 

118. L. Liu, Z. Xiao, C. Zuo, L. Ding, Inorganic perovskite/organic tandem solar cells with efficiency over 20%. J. Semicond. **42** (2), 020501 (2021). https:// doi. org/ 10. 1088/ 1674- 4926/ 42/2/ 020501 

© The authors 

https://doi.org/10.1007/s40820-023-01040-6 

Page 39 of 44 **70** 

Nano-Micro Lett. (2023) 15:70 

119. Y. Ding, Q. Guo, Y. Geng, Z. Dai, Z. Wang et al., A lowcost hole transport layer enables  CsPbI2Br single-junction and tandem perovskite solar cells with record efficiencies of 17.8% and 21.4%. Nano Today **46** , 101586 (2022). https:// doi. org/ 10. 1016/j. nantod. 2022. 101586 

120. W. Chen, D. Li, X. Chen, H. Chen, S. Liu et al., Surface reconstruction for stable monolithic all-inorganic perovskite/ organic tandem solar cells with over 21% efficiency. Adv. Funct. Mater. **32** (5), 2109321 (2021). https:// doi. org/ 10. 1002/ adfm. 20210 9321 

121. X. Yang, Y. Fu, R. Su, Y. Zheng, Y. Zhang et al., Superior carrier lifetimes exceeding 6 micros in polycrystalline halide perovskites. Adv. Mater. **32** (39), 2002585 (2020). https:// doi. org/ 10. 1002/ adma. 20200 2585 

122. S.W. Liu, X.Y. Guan, W.S. Xiao, R. Chen, J. Zhou et al., Effective passivation with size-matched alkyldiammonium iodide for high-performance inverted perovskite solar cells. Adv. Funct. Mater. **32** (38), 2205009 (2022). https:// doi. org/ 10. 1002/ adfm. 20220 5009 

123. C.H. Li, Y.M. Pan, J.L. Hu, S.D. Qiu, C.L. Zhang et al., Vertically aligned 2D/3D Pb-Sn perovskites with enhanced charge extraction and suppressed phase segregation for efficient printable solar cells. ACS Energy Lett. **5** (5), 1386–1395 (2020). https:// doi. org/ 10. 1021/ acsen ergyl ett. 0c006 34 

124. S. Bai, P. Da, C. Li, Z. Wang, Z. Yuan et al., Planar perovskite solar cells with long-term stability using ionic liquid additives. Nature **571** (7764), 245–250 (2019). https:// doi. org/ 10. 1038/ s41586- 019- 1357-2 

125. Z.M. Fang, N. Yan, S. Liu, Modulating preferred crystal orientation for efficient and stable perovskite solar cells-from progress to perspectives. InfoMat **4** (10), e12369 (2022). https:// doi. org/ 10. 1002/ inf2. 12369 

126. Z. Tang, T. Bessho, F. Awai, T. Kinoshita, M.M. Maitani et al., Hysteresis-free perovskite solar cells made of potassium-doped organometal halide perovskite. Sci. Rep. **7** (1), 12183 (2017). https:// doi. org/ 10. 1038/ s41598- 017- 12436-x 

127. T. Bu, X. Liu, Y. Zhou, J. Yi, X. Huang et al., A novel quadruple-cation absorber for universal hysteresis elimination for high efficiency and stable perovskite solar cells. Energy Environ. Sci. **10** (12), 2509–2515 (2017). https:// doi. org/ 10. 1039/ c7ee0 2634j 

128. D.Y. Son, S.G. Kim, J.Y. Seo, S.H. Lee, H. Shin et al., Universal approach toward hysteresis-free perovskite solar cell via defect engineering. J. Am. Chem. Soc. **140** (4), 1358–1364 (2018). https:// doi. org/ 10. 1021/ jacs. 7b104 30 

129. J. Cao, S.X. Tao, P.A. Bobbert, C.P. Wong, N. Zhao, Interstitial occupancy by extrinsic alkali cations in perovskites and its impact on ion migration. Adv. Mater. **30** (26), 1707350 (2018). https:// doi. org/ 10. 1002/ adma. 20170 7350 

130. M. Abdi-Jalebi, Z. Andaji-Garmaroudi, S. Cacovich, C. Stavrakas, B. Philippe et al., Maximizing and stabilizing luminescence from halide perovskites with potassium passivation. Nature **555** (7697), 497–501 (2018). https:// doi. org/ 10. 1038/ natur e25989 

131. D.J. Kubicki, D. Prochowicz, A. Hofstetter, S.M. Zakeeruddin, M. Gratzel et al., Phase segregation in potassium-doped 

lead halide perovskites from 39K solid-state NMR at 21.1T. J. Am. Chem. Soc. **140** (23), 7232–7238 (2018). https:// doi. org/ 10. 1021/ jacs. 8b031 91 

132. F. Zheng, W. Chen, T. Bu, K.P. Ghiggino, F. Huang et al., Triggering the passivation effect of potassium doping in mixed-cation mixed-halide perovskite by light illumination. Adv. Energy Mater. **9** (24), 1901016 (2019). https:// doi. org/ 10. 1002/ aenm. 20190 1016 

133. L. Wang, G. Wang, Z. Yan, J. Qiu, C. Jia et al., Potassiuminduced phase stability enables stable and efficient widebandgap perovskite solar cells. Sol. RRL **4** (7), 2000098 (2020). https:// doi. org/ 10. 1002/ solr. 20200 0098 

134. J. Liang, C. Chen, X. Hu, Z. Chen, X. Zheng et al., Suppressing the phase segregation with potassium for highly efficient and photostable inverted wide-bandgap halide perovskite solar cells. ACS Appl. Mater. Interfaces **12** (43), 48458– 48466 (2020). https:// doi. org/ 10. 1021/ acsami. 0c103 10 

135. T. Duong, Y. Wu, H. Shen, J. Peng, X. Fu et al., Rubidium multication perovskite with optimized bandgap for perovskite-silicon tandem with over 26% efficiency. Adv. Energy Mater. **7** (14), 1700228 (2017). https:// doi. org/ 10. 1002/ aenm. 20170 0228 

136. J. Kim, M.I. Saidaminov, H. Tan, Y. Zhao, Y. Kim et al., Amide-catalyzed phase-selective crystallization reduces defect density in wide-bandgap perovskites. Adv. Mater. **30** (13), 1706275 (2018). https:// doi. org/ 10. 1002/ adma. 20170 6275 

137. L. Tao, X. Du, J. Hu, S. Wang, C. Lin et al., Stabilizing widebandgap halide perovskites through hydrogen bonding. Sci. China Chem. **65** (8), 1650–1660 (2022). https:// doi. org/ 10. 1007/ s11426- 021- 1306-4 

138. Y. Zhou, Y.H. Jia, H.H. Fang, M.A. Loi, F.Y. Xie et al., Composition-tuned wide bandgap perovskites: from grain engineering to stability and performance improvement. Adv. Funct. Mater. **28** (35), 1803130 (2018). https:// doi. org/ 10. 1002/ adfm. 20180 3130 

139. Y.M. Xie, X. Xu, C. Ma, M. Li, Y. Ma et al., Synergistic effect of pseudo-halide thiocyanate anion and cesium cation on realizing high-performance pinhole-free MA-based widebandgap perovskites. ACS Appl. Mater. Interfaces **11** (29), 25909–25916 (2019). https:// doi. org/ 10. 1021/ acsami. 9b063 15 

140. D.H. Kim, C.P. Muzzillo, J.H. Tong, A.F. Palmstrom, B.W. Larson et al., Bimolecular additives improve wide-band-gap perovskites for efficient tandem solar cells with CIGS. Joule **3** (7), 1734–1745 (2019). https:// doi. org/ 10. 1016/j. joule. 2019. 04. 012 

141. B. Chen, Z.S. Yu, K. Liu, X.P. Zheng, Y. Liu et al., Grain engineering for perovskite/silicon monolithic tandem solar cells with efficiency of 25.4%. Joule **3** (1), 177–190 (2019). https:// doi. org/ 10. 1016/j. joule. 2018. 10. 003 

142. X. Jiang, J. Zhang, X. Liu, Z. Wang, X. Guo et al., Deeper insight into the role of organic ammonium cations in reducing surface defects of the perovskite film. Angew. Chem. Int. Ed. **61** (12), e202115663 (2022). https:// doi. org/ 10. 1002/ anie. 20211 5663 

1 3 

**70** Page 40 of 44 

Nano-Micro Lett. (2023) 15:70 

143. C.L. Zhang, S.H. Wu, L.M. Tao, G.M. Arumugam, C. Liu et al., Fabrication strategy for efficient 2D/3D perovskite solar cells enabled by diffusion passivation and strain compensation. Adv. Energy Mater. **10** (43), 2002004 (2020). https:// doi. org/ 10. 1002/ aenm. 20200 2004 

144. J.Y. Ye, J. Tong, J. Hu, C. Xiao, H. Lu et al., Enhancing charge transport of 2D perovskite passivation agent for widebandgap perovskite solar cells beyond 21%. Sol. RRL **4** (6), 2000082 (2020). https:// doi. org/ 10. 1002/ solr. 20200 0082 

145. X. Huo, Y. Li, Y. Lu, J. Dong, Y. Zhang et al., Suppressed halide segregation and defects in wide bandgap perovskite solar cells enabled by doping organic bromide salt with moderate chain length. J. Phys. Chem. C **126** (4), 1711–1720 (2022). https:// doi. org/ 10. 1021/ acs. jpcc. 1c097 39 

146. H. Xu, Z. Liang, J. Ye, S. Xu, Z. Wang et al., Guanidiniumassisted crystallization modulation and reduction of opencircuit voltage deficit for efficient planar  FAPbBr3 perovskite solar cells. Chem. Eng. J. **437** , 135181 (2022). https:// doi. org/ 10. 1016/j. cej. 2022. 135181 

147. G. Yang, Z. Ni, Z.J. Yu, B.W. Larson, Z. Yu et al., Defect engineering in wide-bandgap perovskites for efficient perovskite-silicon tandem solar cells. Nat. Photon. **16** (8), 588–594 (2022). https:// doi. org/ 10. 1038/ s41566- 022- 01033-8 

148. S. Qin, C. Lu, Z. Jia, Y. Wang, S. Li et al., Constructing monolithic perovskite/organic tandem solar cell with efficiency of 22.0% via reduced open-circuit voltage loss and broadened absorption spectra. Adv. Mater. **34** (11), 2108829 (2022). https:// doi. org/ 10. 1002/ adma. 20210 8829 

149. D. Kim, H.J. Jung, I.J. Park, B.W. Larson, S.P. Dunfield et al., Efficient, stable silicon tandem cells enabled by anionengineered wide-bandgap perovskites. Science **368** (6487), 155–160 (2020). https:// doi. org/ 10. 1126/ scien ce. aba34 33 

150. Y. Cai, J. Cui, M. Chen, M. Zhang, Y. Han et al., Multifunctional enhancement for highly stable and efficient perovskite solar cells. Adv. Funct. Mater. **31** (7), 2005776 (2020). https:// doi. org/ 10. 1002/ adfm. 20200 5776 

151. F. Gao, Y. Zhao, X. Zhang, J. You, Recent progresses on defect passivation toward efficient perovskite solar cells. Adv. Energy Mater. **10** (13), 1902650 (2019). https:// doi. org/ 10. 1002/ aenm. 20190 2650 

152. M. Kim, S.G. Motti, R. Sorrentino, A. Petrozza, Enhanced solar cell stability by hygroscopic polymer passivation of metal halide perovskite thin film. Energy Environ. Sci. **11** (9), 2609–2619 (2018). https:// doi. org/ 10. 1039/ c8ee0 1101j 

153. X.J. Gu, W.C. Xiang, Q.W. Tian, S.Z. Liu, Rational surfacedefect control via designed passivation for high-efficiency inorganic perovskite solar cells. Angew. Chem. Int. Ed. **60** (43), 23164–23170 (2021). https:// doi. org/ 10. 1002/ anie. 20210 9724 

154. R. Wang, J. Xue, K.L. Wang, Z.K. Wang, Y. Luo et al., Constructive molecular configurations for surface-defect passivation of perovskite photovoltaics. Science **366** (6472), 1509–1513 (2019). https:// doi. org/ 10. 1126/ scien ce. aay96 98 

155. X. Li, W. Zhang, X. Guo, C. Lu, J. Wei et al., Constructing heterojunctions by surface sulfidation for efficient inverted 

perovskite solar cells. Science **375** (6579), 434–437 (2022). https:// doi. org/ 10. 1126/ scien ce. abl56 76 

156. J. Liu, E. Aydin, J. Yin, M.D. Bastiani, F.H. Isikgor et al., 28.2%-efficient, outdoor-stable perovskite/silicon tandem solar cell. Joule **5** (12), 3169–3186 (2021). https:// doi. org/ 10. 1016/j. joule. 2021. 11. 003 

157. Y. Zheng, X. Wu, J. Liang, Z. Zhang, J. Jiang et al., Downward homogenized crystallization for inverted wide-bandgap mixed-halide perovskite solar cells with 21% efficiency and suppressed photo-induced halide segregation. Adv. Funct. Mater. **32** (29), 2200431 (2022). https:// doi. org/ 10. 1002/ adfm. 20220 0431 

158. R.D.J. Oliver, P. Caprioglio, F. Peña-Camargo, L.R.V. Buizza, F. Zu et al., Understanding and suppressing nonradiative losses in methylammonium-free wide-bandgap perovskite solar cells. Energy Environ. Sci. **15** (2), 714–726 (2022). https:// doi. org/ 10. 1039/ d1ee0 2650j 

159. Z. Li, B. Li, X. Wu, S.A. Sheppard, S. Zhang et al., Organometallic-functionalized interfaces for highly efficient inverted perovskite solar cells. Science **376** (6591), 416–420 (2022). https:// doi. org/ 10. 1126/ scien ce. abm85 66 

160. B. Chen, N. Ren, Y. Li, L. Yan, S. Mazumdar et al., Insights into the development of monolithic perovskite/silicon tandem solar cells. Adv. Energy Mater. **12** (4), 2003628 (2021). https:// doi. org/ 10. 1002/ aenm. 20200 3628 

161. H.D. Pham, T.C.J. Yang, S.M. Jain, G.J. Wilson, P. Sonar, Development of dopant-free organic hole transporting materials for perovskite solar cells. Adv. Energy Mater. **10** (13), 1903326 (2020). https:// doi. org/ 10. 1002/ aenm. 20190 3326 

162. A.K. Jena, A. Kulkarni, T. Miyasaka, Halide perovskite photovoltaics: background, status, and future prospects. Chem. Rev. **119** (5), 3036–3103 (2019). https:// doi. org/ 10. 1021/ acs. chemr ev. 8b005 39 

163. T.H. Wu, X. Liu, X.H. Luo, X.S. Lin, D.Y. Cui et al., Leadfree tin perovskite solar cells. Joule **5** (4), 863–886 (2021). https:// doi. org/ 10. 1016/j. joule. 2021. 03. 001 

164. Y. Han, H. Zhao, C. Duan, S. Yang, Z. Yang et al., Controlled n-doping in air-stable  CsPbI2Br perovskite solar cells with a record efficiency of 16.79%. Adv. Funct. Mater. **30** (12), 1909972 (2020). https:// doi. org/ 10. 1002/ adfm. 20190 9972 

165. J.R. Zhang, Y.K. Fang, W.G. Zhao, R.J. Han, J.L. Wen et al., Molten-salt-assisted  CsPbI3 perovskite crystallization for nearly 20%-efficiency solar cells. Adv. Mater. **33** (45), 2103770 (2021). https:// doi. org/ 10. 1002/ adma. 20210 3770 

166. P. Mahajan, B. Padha, S. Verma, V. Gupta, R. Datt et al., Review of current progress in hole-transporting materials for perovskite solar cells. J. Energy Chem. **68** , 330–386 (2022). https:// doi. org/ 10. 1016/j. jechem. 2021. 12. 003 

167. F.M. Rombach, S.A. Haque, T.J. Macdonald, Lessons learned from spiro-OMeTAD and PTAA in perovskite solar cells. Energy Environ. Sci. **14** (10), 5161–5190 (2021). https:// doi. org/ 10. 1039/ d1ee0 2095a 

168. F. Ma, Y. Zhao, J.H. Li, X.W. Zhang, H.S. Gu et al., Nickel oxide for inverted structure perovskite solar cells. J. Energy 

© The authors 

https://doi.org/10.1007/s40820-023-01040-6 

