# Biomass-Based Carbon Dots: Current Development and Future Perspectives.

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | ACS Nano |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 557 |
| 作者 | Thomas C Wareing, P. Gentile, A. Phan |
| DOI | 10.1021/acsnano.1c03886 |
| 源文件 | 009_Wareing_2021_Biomass-Based-Carbon-Dots-Current-Development-an.pdf |

---


www.acsnano.org 

## Biomass-Based Carbon Dots: Current Development and Future Perspectives 

Thomas C. Wareing, Piergiorgio Gentile,*<sup>,†</sup> and Anh N. Phan*<sup>,†</sup> 



<!-- Start of picture text -->
Cite This: ACS Nano 2021, 15, 15471−15501 Read Online<br><!-- End of picture text -->

|ACCESS|Metrics & More<br>Article Recommendations|
|---|---|





ABSTRACT: Carbon dots have been considered as a solution to the challenges that semiconductor quantum dots have encountered because they are more biocompatible and can be synthesized from abundant and nontoxic materials such as biomass. This review will highlight the advantages of these biomass-based carbon dots in terms of synthesis, properties, and applications in the biomedical field. Furthermore, future applications especially in the biomedical field of biomass-based carbon dots as well as the challenges of semiconductor quantum dots such as biocompatibility, photobleaching, environmental challenges, toxicity, and poor solubility will be discussed in detail. Biomass-derived quantum dots, a subsection of carbon dots that are the most desirable for future research, will be focused upon including from synthesis to applications. Finally, the future development of biomass derived quantum dots in the biomedical field will be discussed and evaluated to unlock the potential for their applications. KEYWORDS: biomass derived quantum dots, carbon dots, semiconductor quantum dots, synthesis methods, biomass, quantum yield, yield, functionalization, photoluminescence, biomedical applications 

raditional quantum dots are fluorescent nanocrystals consisting of a semiconductor (referred to as semi- 

# T 

conductor quantum dots, SCQDs hereafter) characterized with a range of exclusive optical and electrical properties that are derived from their structure and size: 1− 20 nm and containing 200−10,000 atoms.<sup>1,2</sup> SCQDs usually consist of two semiconductors, a core, and a shell. The core semiconductor has a narrow bandgap (Table 1)<sup>3</sup> that represents the minimum energy required to excite an electron from its ground state into the next highest energy level. This core is enclosed by a shell semiconductor that has a higher band gap. This core/shell relationship helps to confine emission and excitation to the core and protects the core from photobleaching and improves core quantum yield.<sup>4</sup> The performance of SCQDs is evaluated with the quantum yield. Quantum yield is, according to reactive species detection in biology, “the measure of the efficiency of photon emission as 

defined by the ratio of the number of photons emitted to the number of photons absorbed”.<sup>5</sup> 

Hines et al.<sup>6</sup> reported a protocol for synthesizing highly luminescent ZnS-capped CdSe nanocrystals in which the ZnS layer was grown directly to the CdSe cores while retaining the initial core size. The ZnS capping was shown to protect and passivate the surface, and a high quantum yield (50%) was achieved. This research clearly reported the rationale of selecting CdSe and ZnS for their specific roles in this nanocrystal (CdSe having a small indirect band gap and ZnS 



Received: May 7, 2021 Accepted: September 20, 2021 Published: September 24, 2021 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

© 2021 American Chemical Society 

15471 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

Table 1. Band Gap Energies of Different Semiconductors Required to Excite an Electron from Its Ground State into the Next Highest Energy Level 

|semiconductor|band gap (eV)|
|---|---|
|PbSe|0.27|
|PbTe|0.29|
|PbS|0.37|
|InN|0.67|
|Ge|0.67|
|GaSb|0.7|
|Si|1.11|
|InP|1.35|
|GaAs|1.43|
|CdTe|1.58|
|AlSb|1.6|
|CdSe|1.73|
|AlAs|2.16|
|ZnTe|2.25|
|GaP|2.26|
|CdS|2.42|
|AlP|2.45|
|ZnSe|2.7|
|SiC|2.86|
|GaN|3.4|
|ZnS|3.6|
|diamond|5.5|
|AlN|6.2|



having a wide direct band gap); however, the actual energy values of the band gaps were omitted. This information would have been useful for comparison to other crystals, so the relationship of the band gap in the crystals could be studied against their properties. Even though this paper was published in 1996, this structure of the quantum dot is still relevant to date.<sup>7</sup> 

An important parameter in semiconductors is fluorescence, which is caused when energy from light is absorbed and causes a valence band electron to excite to the conductance band; this leaves behind a positive “electron hole” in the valence band. When the electron returns to the valence band and recombines with the hole, a photon is emitted. In bulk semiconductors, electrons and holes recognize each other and move around in the material within the time scale of light absorption. The electron is held in orbit by columbic attraction; this pairing is called an ‘exciton’. The distance within the exciton is called the 

Bohr radius.<sup>8</sup> In a SCQD, the bulk dimensions are reduced to the nanometer scale, smaller than the Bohr radius, causing squeezing of the excitons. This phenomenon is called quantum confinement.<sup>8</sup> Here are some examples of the Bohr exciton radius in some semiconductors:<sup>9</sup> CdTe = 7.14 nm, CdSe = 7.07 nm, ZnSe = 2.29 nm, SnS = 8.04 nm. Quantum confinement dictates how much energy is needed to excite an electron from the valence band to the conductance band. In smaller SCQDs, the quantum confinement is much greater, so it takes more energy to excite the electron away from the positively charged hole that it leaves behind. When the hole and electron recombine, this energy is emitted in the form of a photon. The more energy it takes to excite the electron, the higher the energy of the photon emitted when the electron and hole recombine. The smaller the SCQD, the bigger the band gap and the higher the energy of light that is emitted when the SCQDs is deactivated. This means that larger SCQDs emit low-energy red light and smaller SCQDs emit higher-energy blue light<sup>8,10</sup> (Figure 1). 

A good example of size directly correlating to color was described by Han et al.,<sup>11</sup> where they produced 10 sizes between 2 and 8 nm of ZnS capped CdSe quantum dots which produced 10 distinguishable colors when excited at near-UV lamp. The quantum confinement effect gives SCQDs the exclusive property of a narrow emission wavelength and a tunable band gap by controlling size. These properties, along with a high quantum yield, broad absorbance wavelengths, broad Stokes shifts, and a high resistance to photobleaching,<sup>12,13</sup> make them great candidates for numerous applications.<sup>14</sup> 

Applications. One of the applications of SCQDs are in quantum dot light-emitting diodes (QLEDs), which are made by stacking SCQDs between two layers: an organic hole transport layer and an electron transport layer. QLEDs can be readily synthesized by established processes such as ink jet printing, offering a reduction in the cost of mass production.<sup>15</sup> Moreover, they have applications in creating high-intensity color screens.<sup>16</sup> 

Another application of SCQDs is cellular imaging,<sup>17−19</sup> as shown in Figure 2. The properties of SCQDs that make them appropriate for this application are a very narrow and controllable emission wavelength, especially when compared to organic dyes (which have wavelength-dependent absorption spectra, broad and asymmetric emission spectra, and susceptibility to photobleaching).<sup>14</sup> The wavelength for 



Figure 1. (A) Scheme showing the relationship between dot size and band gap size. Adapted with permission from ref 8. Copyright 2019 Elsevier B.V. (B) QDs of different sizes emitting all over the visible spectral range. Reprinted in part with permission from ref 10. Copyright 2011 John Wiley and Sons. 

15472 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 



Figure 2. Bioimaging using SCQDs. (A) Bright-field and PL merge. QD imaging of HEK 237T cells (top) and U-87 MG malignant glioma cancer cells (bottom). Reprinted with permission from ref 17. Copyright 2020 Elsevier B.V. (B) Fluorescent image of the lymphocyte cells with CdSe-TGA QD. Reprinted with permission from ref 18. Copyright 2015 Elsevier B.V. (C) Cell imaging of CdTe/CdS quantum dots probes in breast cancer cells. Reprinted with permission from ref 19. Copyright 2019 Elsevier B.V. 

Table 2. A Comparison between QDs and Conventional Organic Fluorophores Such As Organic Dyes<sup>14</sup> 

|properties|quantum dots|conventional organic fluorophores|
|---|---|---|
|size|2−20 nm and tunable|<0.5 nm small molecule or protein|
||broad discrete band on the absorption spectra|narrow absorption spectra|
||narrow emission spectra|broad emission spectra with asymmetric red-shift tail|
|optical properties|high quantum yield<br>long fluorescence excited-state lifetime<br>high detection sensitivity|low quantum yield<br>short fluorescence excited-state lifetime<br>low detection sensitivity|
||high resistance to photobleaching|low resistance to photobleaching|
||low aqueous solubility can be improved with surface coating or functionalization<br>medium size-dependent tissue penetration|high aqueous solubility that is controlled by chemistry<br>high tissue penetration|
|bioimaging properties|high spectral multiplexing capability<br>high quantification capability|low multiplexing capability due to spectral overlap<br>low quantification capability|
||potential for toxic accumulation and heavy metal leaching, slow metabolism<br>ease of spectra tenability|chemistry-dependent toxicity, typically rapid metabolism<br>typically stable, water-soluble materials|
|key strengths|quantum yield (up to 100 times brighter)<br>high photostability<br>potential toxicity in vivo|ease of bioconjugation (many available commercially)<br>deep tissue penetration<br>lack of tunability|
|key challenges|poor aqueous solubility and stability<br>difficult to alter biodistribution|prone to photobleaching<br>more difficult to enable in vivo multiplex imaging|



SCQDs can be placed anywhere on the electromagnetic spectrum starting in the UV region to near-infrared by changing their structure and size due to the quantum confinement effect explained above. They also have a single excitation source, high signal strength, and a broad absorbance wavelength. The broad absorbance wavelength means that multiple SCQDs of different sizes and makeup can be excited under a single source.<sup>4</sup> This could translate to different dots being used for different imaging areas or structures in the body at the same time, and the same light source can be used to illuminate both dots. A more in-depth comparison between the SCQD and organic dyes that outlines the key challenges and key strengths of each is illustrated in Table 2.<sup>14</sup> Quantum dots exhibit some excellent properties in both optical and bioimaging applications. 

It has been shown that the capping materials used in SCQDs may be immunogenic and could contribute to hazardous immune reactions.<sup>8</sup> Particularly, the core of SCQD is made of heavy metals that are cytotoxic, and, due to their small size, SCQDs are easily accumulated in the liver, which is sensitive to heavy-metal toxicity, without possibility of elimination.<sup>8</sup> Therefore, due to their high toxicity in addition to the poor solubility, SCQDs may not represent the best candidates for 

bioimaging. However, different works in literature have reported attempts to overcome these drawbacks by using complex surface functionalization.<sup>20</sup> Wu et al.<sup>21</sup> proposed a protocol to solve the water solubility issues by coating the CdSe/ZnS dot with an amphiphilic polymer dot coating that was water-soluble while keeping the dots original surface and fluorescent properties intact. Direct synthesis of water-soluble CdTe quantum dots through a colloidal chemical route was also proposed by Wang et al.,<sup>22</sup> which is an improvement from the approach reported by Wu et al.,<sup>21</sup> indicating the progression in the field. However, there is neither an explanation of the mechanisms of water solubility of the CdTe quantum dots nor comparison of solubility with other examples. 

Furthermore, biocompatibility issues have been addressed by Ballou et al.<sup>13</sup> by functionalizing SCQDs with methoxyterminated PEG5000. This displayed a reduced nonspecific binding in the mouse animal model considerably, increasing the biocompatibility against nontarget cells because nonspecific binding of the dot has been decreased, but it does not address the intrinsic toxicity of the materials used. 

Another drawback to SCQDs is a potential risk for polluting the environment with semiconductors through typical release 

15473 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

Table 3. Description of the Focus and the Gaps of Past Reviews in the Subject of SCQDs, CDs, and Biomass Derived CDs 

|title and reference|focus|scope gaps|
|---|---|---|
|Recent Advances in Nontoxic Quantum Dots and Their Biomedical<br>Advances<sup>23</sup>|toxic effect of traditional semiconductor QDs<br>recent designs of nontoxic QDs|only a small focus on CDs|
|Carbon Quantum Dots from Natural Resource: A Review<sup>24</sup>|CQDs from natural resource using low-cost<br>green techniques<br>fluorescence behavior<br>biomedical applications<br>|no focus on other potential applications|
||use of CQDs for the detection of heavy metals||
|Biomass-Waste Derived Graphene Quantum Dots and Their<br>Applications<sup>25</sup>|synthesis of graphene biomass quantum dots<br>applications of batteries, supercapacitors, and<br>photovoltaics|only focuses on GQDs|
|Construction of Biomass Carbon Dots-Based Fluorescence Sensors<br>and Their Applications in Chemical and Biological Analysis<sup>26</sup>|the potential of biomass asfluorescence sensors<br>optical properties and green synthesis methods<br>from biomass<br>functionalization and fluorescence quenching<br>mechanisms of biomass|only focus on biomass, does not focus on<br>other routes|
||the sensor fabrication of biomass s to various<br>targets<br>the challenges and outlook of biomass-based<br>fluorescence sensors||
|Synthesis, Properties and Biomedical Applications of Carbon-Based<br>Quantum Dots: An Updated Review<sup>27</sup>|synthesis protocols<br>properties<br>biomedical applications|only focuses on CDs as a whole, biomass<br>CDs are not referenced as having<br>particular advantage|
|New Development in Carbon Quantum Dots Technical<br>Applications<sup>28</sup>|development of CQDs with advanced<br>physicochemical properties<br>applications in sensing, bioimaging and catalysis<br>challenges and perspective in the CQDs field|only focuses on CDs as a whole and does<br>not distinguish between types of dots and<br>biomass CDs|
|The Advanced Role of Carbon Quantum Dots in Nanomedical<br>Applications<sup>29</sup>|the increased contribution of CQDs in the<br>nanomedicine sector<br>opportunities and challenges of the CQDs in<br>biomedical applications|poor focus on biomass derived quantum<br>dots|
|Graphene Quantum Dots from Chemistry to Applications<sup>30</sup>|GQDs from synthesis and applications<br>the advances and properties of GQD<br>recent trends of GQDs black|only focuses on GQDs|
|Multifaceted Applications of Green Carbon Dots Synthesized from<br>Renewable Sources<sup>31</sup>|features of CDs<br>summary of the progress of research on green<br>CDs regarding its synthesis, applications, and<br>the challenges.|no focus on the difference between the<br>types of quantum dots|
|Quantum Dots in Biomedical Applications<sup>14</sup>|semiconductor quantum dots, applications, and<br>toxicity|no focus on biomass derived quantum dots|
|Graphene Quantum Dots: Emerging Organic Materials with<br>Remarkable and Tunable Luminescence Features<sup>32</sup>|GQDs from synthesis and application|no focus on CDs as a whole or biomass<br>CDs|
|Natural Carbon-Based Quantum Dots and Their Applications in<br>Drug Delivery: A Review<sup>33</sup>|focus on dots from natural sources<br>drug delivery|narrow focus on drug delivery|
|Food Waste As a Carbon Source in Carbon Quantum Dots<br>Technology and Their Applications in Food Safety Detection<sup>34</sup>|CDs from food waste<br>application in the food industry|no focus on CDs from sources other than<br>food waste<br>no focus on application in areas other than<br>food industry|
|Current and Future Perspectives of Carbon and Graphene<br>|focus on both carbon and graphene dots|no focus on biomedical application|
|Quantum Dots: From Synthesis to Strategy for Building<br>Optoelectronic and Energy Devices<sup>35</sup>|application in optoelectronic and energy<br>devices|no focus on the advantages of biomass<br>derived dots|



pathways such as industrial emissions, waste discharge, buried solid waste, surface runoff, consumer goods, food and water, and pharmaceutical products. The heavy metals, which are nondegradable, migrate into the ecosystems, persisting and accumulating in the environment, entering food chains, and posing threats to human health and wildlife.<sup>22</sup> Therefore, it is important to minimize the use of semiconductors in applications that can easily lead to release into the environment. 

The challenges outlined above could be addressed by an alternative type of fluorescent nanoparticle: biomass-based carbon dots (CDs); a subsection of CDs that have great potential in the same application as other types of quantum dot but with increased biocompatibility, solubility, and environ- 

mentally friendliness. This review compares chemical and biomass derived CDs in both synthesis and applications and evaluates challenges facing biomass CDs and their potential. Table 3 summarizes the existing reviews on CDs and biomass derived CDs, reporting their focus as well as the gaps this review aims to fill. 

Most reviews only focus on one type of dot and rarely do an in-depth comparison between the types. Some also only focus on one application and do not mention all the types of application they could be used for. A lot of the reviews listed above also lack true critical analysis. A review that covers all types of quantum dots with critical comparison and shows the progression of quantum dots is urgently needed. This review covers the topic of quantum dots from biomass and compares 

15474 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 



Figure 3. (A1, A2) Examples of structures of GQDs. Adapted with permission from ref 39. Copyright 2019 RSC Publishing. (B) GQD structure. Adapted with permission under a Creative Commons CC BY from ref 40. Copyright 2018 MDPI. (C1−C3) Different sized graphene dots. Adapted with permission from ref 41. Copyright 2017 RSC Publishing. 

them against semiconductor and chemical CDs. It will cover the background information for all types of quantum dots and explain the advantages of biomass derived quantum dots both for biomedical application and synthesis. The research outlined will be critically analyzed and will include examples of where research needs to be focused on the future, so greener, biomass-based CDs can become viable for widespread application. 

### CARBON DOTS 

Introduction to Carbon Dots. Carbon dots (CDs) are small carbon nanoparticles (<10 nm)<sup>24</sup> with highly attractive features similar to their SCQD counterparts, such as strong photoluminescence (PL) emission and optical properties, good conductivity, broadband optical absorption, high chemical stability, broad excitation wavelength, and tunable emission wavelength by modifying synthesis parameters to change, including size, shape, composition, internal structure, and surface chemistry.<sup>27,36</sup> Moreover, unlike their SCQD counterparts, they are also environmentally friendly, nontoxic, nonblinking, and resistant to photobleaching.<sup>27,36</sup> 

The mechanisms by which CDs exhibit their photoluminescent properties are not yet fully understood.<sup>27</sup> However, the main hypotheses to this are the quantum confinement effect and surface structure, which are discussed later in this review. 

CDs were discovered in 2004 by accident by Xu et al.<sup>37</sup> during the run of a purification of single-walled carbon nanotubes by electrophoresis. Since their discovery, CDs have attracted a lot of research and could be a potential replacement for conventional SCQD in many applications. In comparison, CDs can be synthesized through large-scale, one-step processes without high cost. They are more suitable for biomedical applications than SCQD, as they are chemically inert and have much higher biocompatibility and insignificant cytotoxicity. These properties can be related to precursor materials they are 

made from such as chemicals (i.e., ethanol, citrate, glucosamine and ascorbic acid) or biomass (i.e., pomelo peels, orange juice and strawberry juice).<sup>38</sup> CD are easy to functionalize and very soluble in water. This is because their surface is characterized by several and different functional groups, such as amine or carboxylic groups and polar moieties on their surface.<sup>36</sup> 

Structure of Carbon Dots. The structure of CDs can be split into two categories: graphitic and amorphous. Currently the difference between graphene quantum dots (GQDs) and amorphous CDs (ACDs) is not clear, and both are considered as part of the CD family. Their PL mechanisms are still not fully understood because they present differences with the quantum confinement effect in SCQDs. However, it is thought to play a role in the intrinsic emission of GQDs.<sup>25</sup> 

Graphene Quantum Dots. GQDs are a class of CDs as shown in Figure 3.<sup>39−41</sup> They are made up of a graphene lattice which is <10 layers thick.<sup>42</sup> Graphene quantum dots are cut from sheets of graphene in all dimensions until it is zerodimensional (is <20 nm in all directions). GQDs are thought to have a bandgap due to both quantum confinement and edge effects. GQDs have a crystalline structure and are made up of mainly sp<sup>2</sup> -hybridized carbon.<sup>25</sup> 

Interestingly, Zhu et al. described in their work the photoluminescent mechanism of GQDs as controversial.<sup>43</sup> It is thought to be made up of the quantum confinement effect of conjugated π-domains, surface/edge state, or even a synergistic effect of both. GQDs structure is made up of a graphene core and surrounding chemical groups. The intrinsic emission of the GQD is controlled by the core, and the surface state is controlled by the chemical groups. A GQD with fewer surface chemical groups and a perfect graphene core would have a photoluminescent center in the band gap of the conjugated π- domains. A GQD with more chemical groups attached to the core might have its photoluminescent center in the surface/ edge state. 

15475 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

Sk et al.<sup>44</sup> investigated the mechanisms behind the tunable PL properties of GQDs by systematically using density functional theory and time-dependent density functional theory calculations. They revealed that the emission originating from zigzag edged pristine GQDs could cover the entire visible light spectrum by varying the diameter from 0.89 to 1.80 nm. The PL emission of a heterogeneously hybridized GQD originated from its isolated small sp<sup>2</sup> domains. It was also shown that blue shift emission was caused by the armchair edge and pyrrolic N-doping, whereas chemical functionalities and defects cause the red-shift. Furthermore, the authors reported that the graphene sheets with finite size cause the quantum confinement effect. The band gap opening and PL emission of the dots should be size dependent. For example, smaller dots emit at shorter wavelengths. 

In another work, Zhu et al.<sup>45</sup> investigated the effects of passivation with different molecular weight polymers and its effects on the PL of GQDs. They found that surface passivation with molecules with a higher molecular weight weakens the chemical activity and π−π stacking interaction of the dots but had less of an impact on intrinsic energy gap. This introduced weaker nonradiative recombination which led to better radiative recombination which meant enhanced fluorescence. 

Amorphous Quantum Dots. ACDs (Figure 4) are quasispherical carbon nanoparticles consisting of different ratios of 



Figure 4. Examples of amorphous CDs: (A) ACDs with surface structure. Adapted with permission under a Creative Commons CC BY from ref 46. Copyright 2018 Springer Nature. (B) ACD structure. Adapted with permission under a Creative Commons CC BY from ref 40. Copyright 2018 MDPI. 

graphite and turbostratic carbon mixture at a size range of 2− 10 nm.<sup>40,46</sup> They usually have an amorphous structure and are composed mainly of sp<sup>3</sup> -hybridized carbon. Their XRD patterns show a double character (18.2° and 23.8°) attributed to amorphous and graphitic constituents.<sup>47</sup> Furthermore, ACDs contain more oxygen and less carbon when compared to GQDs. According to Lim et al.<sup>48</sup> XPS spectra (C1s highresolution) of ACDs contained 30.5% carbon to oxygen bonds, while the GQDs only contained 17%. Due to their high oxygen content, ACDs are sometimes referred to as carbogenic nanodots. The fluorescence in ACDs originates from surface defects and functionalization and can be introduced by the passivation of emissive traps.<sup>25</sup> 

Surface modification, such as a higher degree of surface oxidation, can lead to more surface defects with a red-shifted emission, and it can also include attaching fluorophores to the surface or interior of carbon skeleton and display emission 

directly.<sup>26</sup> This is evidenced by Deng et al. that described the phosphorescence of CDs in a poly(vinyl alcohol) matrix.<sup>49</sup> They suggested that the phosphorescence originates from triplet excited states of aromatic carbonyls on the surface of CDs. In another study, Ehrat et al. stated that the first approach for the likely source of the optical properties of CDs is the energy transfer between the core and the surface of the CD.<sup>50</sup> A core of a CD usually contains sp<sup>2</sup> -hybridized domains immersed in an amorphous sp<sup>3</sup> -hybridized matrix, and it was shown also that a combination of just three small polycyclic aromatic hydrocarbons could reproduce the Stokes shift and excitation dependence of the emission wavelength of the CDs. These Stokes shifts can be attributed to on π-stacked molecular dimers. The excitation-dependent PL is explained in terms of direct emission and energy transfer. Furthermore, another model described in Ehrat’s work<sup>50</sup> are the molecular fluorophores, which are derivatives of citrazinic acid formed during the synthesis of the CDs and contribute to their emission significantly. Citrazinic acid has very similar optical properties to CDs such as strong Stokes shifts and similar absorption and emission maxima. Blue-emitting fluorophores, such as citrazinic acid and other 2-pyridone-based molecules, have been shown to be produced in similar syntheses that are used to create CDs. It remains up for debate if these molecular fluorophores are incorporated to structure of CDs, bound to the surface, or just free in solution. 

Aggregation-Induced Emission Luminogens. Some CDs are aggregation-induced emission luminogens (AIEgens); fluorescent materials showing stronger emission when aggregated. They have good optical properties that include a resistance to photobleaching and solid-state emission. Since their proposal in 2001 by Luo et al.,<sup>51</sup> AIEgens have found application in the same areas as other fluorophores such as bioimaging, organic light-emitting diodes, sensing, and cancer therapy. Materials often used to create AIEgens are metal particles, organic molecules, and polymers. Most AIEgens require toxic precursors or complicated synthesis which hinders their application potential.<sup>52</sup> 

CDs often suffer from aggregation caused quenching; this is because of strong π−π interaction in their graphitizing cores. However, some researchers have described CD-AIEgens from plant derived precursors.<sup>52</sup> 

Ge et al.<sup>52</sup> created CD-based AIEgens from rosin (pine tree resin) and ethylenediamine via a hydrothermal method. The CDs has an adjustable emission wavelength between 430 and 582 nm by altering solution concentration. This tuneability is attributed to dynamic fluorescence resonance energy transfer between the carbon cores and surface aggregates of tricyclic phenanthrene moieties, which come from the rosin. This property allowed the fabrication of a two-switch-mode luminescent ink for encryption. The dots also had a quantum yield of up to 28.4%, which is high. Ge et al. suggest that other biomass molecules that possess tricyclic phenanthrene moieties might also be used to prepare CD-AIEgens with adjustable fluorescence emission. This reaction can be considered green because of the use of rosin as the carbon source, but could be even more green by substituting EDA for something less harsh and biomass derived. 

Xiao et al.<sup>53</sup> also synthesized CD-AIEgens with a hydrothermal method. They used quercetin as the carbon source. The CD-AIEgens showed intense adsorption in the UV region from 200 to 400 nm and emission in water between 520 and 660 nm. The CD-AIEgens were used to enhance photosyn- 

15476 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

|ref|25, 27,<br>36,54,|55<br>27, 55,<br>56,<br>57−59<br>37, 55,<br>60, 61<br>27, 36,<br>55,62,<br>63<br>55, 64,<br>65<br>27, 66<br>55, 67|
|---|---|---|
|advantages (Adv) and disadvantages (Dis)|Adv: accessible processes, various carbon sources and large scale|Dis: drastic process that suffers from harsh conditions, multiple<br>steps, and poor control over size<br>Adv: fast, effective, and highly tunable<br>Dis: low yield and can have a low quantum yield, poor size control.<br>Passivation is required for PL<br>Adv: obtained as a byproduct from purification of nanotubes<br>Dis: arc-discharged soot contains impurities that are hard to<br>remove. Expensive equipment is needed<br>Adv: size and nanostructure is controllable, low cost and high<br>output<br>Dis: narrow range of precursors to choose from. Doping with<br>heteroatoms is difficult<br>Adv: uniform composition, degree of crystallization, and size can be<br>tuned<br>Dis: modification to the structure can change the photo-<br>luminescent properties. Complex process and difficult to purify<br>Adv: fast, scalable, inexpensive, and ecofriendly<br>Dis: poor size control<br>Adv: water−surfactant molar ratio tuned narrow size distribution.<br>High product yield and large-scale production can be guaranteed<br>because aggregation is prevented<br>Dis: complicated steps involved|
|properties of dots|thickness of 2−3 nm with a diameter of tens<br>of nm|quantum yields are up to 4.34%<br>passivated dots are strongly photolumines-<br>cent both in solution and in a solid state<br>stable and excitation wavelength-independ-<br>ent PL emission<br>wide emission wavelength covering the<br>visible spectrum and into near-infrared<br>quantum yield from 0.8% and up to 35.4%<br>od is<br>soot.<br>molecular-weight-dependent PL from vio-<br>let-green ranges<br>changing the source changes the properties<br>of the dots including their size distribu-<br>tion and hydrophobicity<br>tunable by controlling water content in the<br>ionic liquid electrolyte<br>monodisperse with a uniform diameter of<br>3−8 nm, usually PL is green<br>quantum yield can be from 0.47% up to<br>25.6%<br>nside<br>narrow size distribution<br>good water solubility<br>no need for further passivation<br>high quantum yield of up to 18.9%<br>quantum yield up to 35%|
|process|<br>uses strong acids to carbonize small organic molecules|uses a laser to irradiate a carbon target to break it into CDs<br>a positive anode is placed a few millimeters away from a graphite rod. The graphite r<br>evaporated by an electric arc. The products are deposited on the chamber walls as a<br>This product can be purified to obtain CDs<br>method of using the electrolysis of high purity graphite anodes<br>uses a mesoporous structure as a template. The CDs are synthesized by calcination i<br>the structure, which is then removed to obtain the dots. No passivation required<br>a fast, green, economic process that uses a conventional microwave to assist in the<br>carbonization of carbon source to obtain CDs<br>uses a reverse micelle as a nanoreactor to carbonize carbon sources|
|method|chemical ablation|top-down<br>laser ablation<br>top-down<br>arc discharge<br>top-down<br>electrochemical<br>top-down<br>template method<br>bottom-up<br>microwave<br>bottom-up<br>reverse micelle<br>method<br>bottom-up|



15477 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

thesis in chloroplasts by absorbing UV light, which chloroplasts cannot absorb, and then emit green and red light which overlap the absorption wavelengths of chloroplasts. The quantum yield is unreported in this paper, so the efficiency of these dots cannot be determined. Because quercetin is derived from plants and no other chemicals are used, this method can be considered green. 

Synthesis Methods. The methods for synthesizing CDs can be divided into two categories: “top-down” and “bottomup”. Top-down methods take a larger material and reduce it down to a nanoparticle. Bottom-up methods make a nanoparticle from smaller building blocks.<sup>36</sup> Top-down processes tend to produce higher yields but can use processes with harsh chemicals for oxidation like acids such as H2SO4. Bottom-up process tend to be more controllable when it comes to size and morphology, but the processes are more timeconsuming and complex.<sup>25</sup> 

Table 4 outlines the most common CD synthesis methods, reporting technical details of each process, the expected properties of the dots, and advantages and disadvantages of each method. 

Some interesting protocols for the CD synthesis are described below by using both top-down and bottom-up approaches with examples reporting technical details of each process and advantages and disadvantages of each method. The greenest method outlined is the microwave method, whereas the least green method is chemical ablation because of the use of strong acids. Chemical ablation is similar to the greener hydrothermal method which uses similar equipment, but uses only water and heat to carbonize the carbon source. This method is outlined in the Biomass Derived Carbon Dots synthesis section. 

Microwave Method. The microwave method can be applied to small molecules and biomass without acid catalysts, and water can be used as reaction medium. It is fast, green, and economic using a conventional microwave to assist in the carbonization of carbon source to obtain CDs that have good water solubility and no need for further passivation. The method can be scalable, inexpensive, and ecofriendly with the correct selection of carbon source and whether acid catalysis is used. The disadvantage of this method is that size control of the CDs is poor.<sup>66,27,68,69</sup> A microwave assisted method was reported by Pajewska-Szmyt et al. that synthesizes sulfur and nitrogen-doped dots using citric acid as the main carbon source, L-glutathione, and thiourea as the nitrogen and sulfur sources, respectively.<sup>68</sup> The quantum yield was high at 26%, due to the doping of S and N, and these dots aimed to be used as Hg<sup>2+</sup> sensor. However, no information on the yield of the dots produced has been reported to evaluate the further scale up and method efficiency. Liu et al.<sup>69</sup> demonstrated a one-step microwave method to synthesize CDs from citric acid, L- cysteine, and dextrin as precursors in water at a high quantum yield (22%) and small size (average of 2.61 nm). The authors explained that the high quantum yield was attributed to small amounts of doping of N and S from the precursors. The dots exhibited high affinity for Cu<sup>2+</sup> and have application within sensing. This method could be improved by changing the precursor to biomass. Careful selection of biomass could eliminate heteroatom sources for doping, and the carbon source can be obtained from waste. 

Chemical Ablation. In contrast, the chemical ablation uses strong acids to carbonize small organic molecules, requiring purification, neutralization steps, and wastewater that needs to 

be treated. The chemical ablation method produces dots with poor control over size.<sup>55,70,71</sup> In 2012 Fang et al.<sup>70</sup> used acetic acid, water, and phosphorus pentoxide (P2O5) and required no external heat source to synthesize fluorescent CDs. Water and P2O3 exothermically reacted to produce heat and polyphosphoric acid (PPA). The PPA was used as a catalyst, and the heat generated helped drive the carbonization of the acetic acid. Although the self-heating aspect becomes very costeffective for the further scale-up, this is in contradiction with the high processing cost related with the use of P2O5. In addition, the CDs produced in this work were quite large (105 nm diameter), which could reduce wide application and functionalization opportunities. Another drawback can be associated with the low reaction yield (0.06% by direct weight transfer of acetic acid to nanoparticles). Shen et al.<sup>71</sup> synthesized CDs via a chemical ablation of polyethylenimine (PEI) with the reflux of PEI and nitric acid at 120 °C. The dots were obtained by centrifugation and then neutralized with K2CO3. The dots had an excitation-dependent emission, but a low quantum yield of 2% and a relatively large particle size (12 nm). This synthesis perfectly outlines why this method is used less often in recent years. The best methods for size control are template and reverse micelle, which are less harsh but add complexity. 

Template Method. The template method uses a mesoporous structure as a template, the CDs are synthesized by calcination inside the structure, which is then removed to obtain the dots. No passivation is required, and the dots produced have a narrow size distribution. This method is highly tunable in terms of size, composition, and crystallinity, but suffers from complexity and difficulty in purifying the produced dots.<sup>64,65,55</sup> An example of the template method was outlined by Liu et al. using silica spheres as carriers for the aqueous synthesis of CDs.<sup>72</sup> The satellite-like polymer/F127/ silica composite templates were prepared by an aqueous route using silica colloid spheres functionalized with amphiphilic triblock copolymer F127 (EO106PO70EO106, Mw = 12 600; EO = ethylene oxide, PO = propylene oxide) as carriers and resols (phenol/formaldehyde resins, Mw < 500) as carbon precursors. This was treated at high temperature to yield CDs after the removal of silica carriers. Acid treatment was used to passivate the surface to yield water-soluble, multicolor photoluminescent CDs. Around 14.7% quantum yield was obtained. The method is expected to be extended to include doping through variation of precursors for example an N-containing pyrrole for nitrogen doping. It was also stated that the controllability of the reaction can help to understand the PL mechanisms for nanomaterials, which is suggested to be down to the presence of surface energy traps that become emissive upon stabilization as a result of the surface passivation. Wang et al.<sup>73</sup> prepared CDs@ zeolites in hydrothermal conditions using three templates: MnLEV, Zn-CHA, and Zn-LEV. The systems produced had different PL properties such as the CDs@Zn-CHA displayed a green PL and CDs@Zn-LEV and CDs@Mn-LEV display a red PL. The quantum yields of CDs@Zn-CHA and CDs@MnLEV these systems are 14.1% and 5.7%, respectfully. The quantum yield of CDs@Zn-LEV was not outlined. The work lacks testing for application and does not suggest how to obtain just the solid dots without the zeolite shells. 

Reverse Micelle Method. The reverse micelle method uses a reverse micelle as a nanoreactor to carbonize carbon sources. The produced dots can be tuned by changing the water− surfactant molar ratio. The dots produced have a narrow size 

15478 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

|disadvantages<br>only separates according to minimum or maximum size; impurities that<br>are the same size or smaller/larger (depending on where your product<br>is) than your product will not be separated<br>impurities that are a similar size or smaller are not separated and remain<br>in the supernatant<br>can take days<br>does not separate products from impurities<br>often does not completely dry dots; cannot remove solid impurities<br>cannot work when dots are in anything other than water<br>cannot remove solid impurities; can take days<br>does not remove solid impurities; can take days<br>chromatography columns are expensive, complex process; harsh solvent<br>mixture might be needed<br>dots will need to be extracted from solvent after|
|---|
|advantages<br>cheap and fast, equipment in most<br>laboratories<br>fast and simple, equipment in most<br>laboratories<br>can be tuned with changes to speed<br>and time<br>pure dots yielded to exact molecular<br>weight<br>cheap and fast, equipment in most<br>laboratories<br>useful for further synthesis steps to<br>improve yield<br>fast and simple; equipment in most<br>laboratories<br>yielded dots are pure, completely dry<br>vacuum ovens widely available,<br>simple process<br>dots from chromatography are very<br>pure; upper and lower bounds for<br>purification can be set|
|reason for use<br>to yield particles above a<br>specific size. This could be<br>waste or synthesis products.<br>removes insoluble impurities<br>used to remove large particles<br>to obtain particles of a specific<br>size.<br>removal of catalysis<br>to obtain a solution with par-<br>ticles of a specific molecular<br>weight<br>removes soluble impurities<br>to break down agglomerates of<br>particles<br>to concentrate solutions; can<br>yield solid particles<br>to yield solid particles from a<br>solution<br>to yield solid particles from a<br>solution<br>to yield particles with specific<br>relationship with solvent|
|process<br>separation of a precipitate from afiltrate using a membrane with a<br>controlled size<br>using centrifugal force to separate particles in a solution according<br>to size<br>using ultrapure water and diffusion through a specifically sized<br>membrane and to gain a solution with a specific particle size<br>use of ultrasonic vibration to separate particles agglomerates to<br>single particles<br><br>uses rotation a vacuum and heat to evaporate a solution to yield a<br>solid product<br>obtains a solid product from a solution by using low temperatures<br>and pressures to freeze the liquid component and removes ice by<br>sublimation dehydrating the product<br>uses low pressure and elevated temperatures to evaporate the<br>liquid component of a solution yielding dry solid products<br>separates particles in a chromatography medium depending on<br>their relationship with a chosen solvent|
|method<br>filtration77−81<br>centrifugation78,82<br>dialysis77,80,81<br>ultrasonication79<br>rotary evaporation83<br>freeze-drying80,84<br>vacuum drying85<br>chromatography86|



15479 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 



Figure 5. Examples of doped CDs: (A) Doped with nitrogen. Adapted with permission from ref 87. Copyright 2017 Elsevier. (B) Doped with phosphorus. Adapted with permission from ref 88. Copyright 2014 RSC Publishing. (C) Doped with boron. Adapted with permission from ref 89. Copyright 2014 RSC Publishing. 

distribution and a high product, yield and large-scale production can be guaranteed because aggregation is prevented. The disadvantage is that this method is complex.<sup>67,55,67</sup> Kwon et al. used the reverse micelle method to produce graphene CDs.<sup>67</sup> The method used sugar as the carbon source and was highly tunable in terms of size and controlled by the water surfactant molar ratios. The dots produced showed size-dependent optical properties, and a high quantum yield of 35% was reported, with applications in bioimaging and photoelectronics. The use of these micelles also prevented aggregation between the particles which results in a high product yield. Product yield was not reported so it is not possible to evaluate the efficiency of this method. 

Laser Ablation. The laser ablation method uses a laser to irradiate a carbon target to break it into CDs. It is fast, effective, and highly tunable, but it also suffers from low production yield, low quantum yield and poor size control. Passivation can be required for PL.<sup>74,57</sup> Calabro et al.<sup>74</sup> reported the use of liquid-phase laser ablation to produce GQDs from carbon nano-onions and compared this to a chemical oxidation method. They showed that their liquidphase laser ablation method was fast, clean, and a simple single step reaction. In comparison to the dots prepared by the chemical oxidation method, the dots were smaller (1.8 nm for laser ablation vs 4.8 nm for the chemical oxidation) and more uniform in size. Furthermore, the dots also showed blue-shifted absorbance and emissive properties with a photoluminescent peak at 445 nm. It was suggested that the PL properties of these dots were mostly affected by the present functional groups and only minorly affected by size. This means that the PL properties can be tuned by changing present functional groups. Kang et al.<sup>57</sup> outlined a synthesis of nitrogen-doped graphene dots from graphene flakes via a pulsed laser ablation. Graphene flakes were dispersed in ethanol and diethylenetriamine, which was the nitrogen source. High-power sonication was applied during laser ablation. It was reported that these dots have potential application in optoelectronic or bioimaging fields, but the authors neglected to demonstrate this. The size of the dots was <6 nm, and they had a low quantum yield (up to 9.1% when the doping with nitrogen but only 1% without doping). 

Arc Discharge. The arc discharge method places a positive anode a few millimeters away from a graphite rod. The graphite rod is evaporated by an electric arc to produce 

products deposited on the chamber walls as a soot, which can be purified to obtain CDs. However, arc-discharged soot contains impurities that are hard to remove, and expensive equipment is needed.<sup>55,60,75</sup> Dey et al. synthesized B-and N- doped GQDs by a two-step chemical route.<sup>75</sup> The first step used gas-phase arc discharge in the presence of a B/N source to prepare B- and N-doped graphene. The second step involved the chemical scissoring of B/N-doped graphene to yield B/N-GQDs using the Hummers method then further thermally deoxidized by heating in 300 °C for 3 h in a nitrogen atmosphere. The dots had an average diameter 5−6 nm with a strong blue PL emission that was excitation wavelength independent due to the narrow size distribution as well as highly crystallinity of dots. The dots also showed upconverted PL emission which would help in different applications. The drawbacks in this protocol are related to the use of several different gases and expensive equipment to create doped CDs, not being feasible for further scale-up. Furthermore, for doped dots, the range of their PL quantum yield was low, ranging from 2.3% to 8.7%, which would reduce the range of application (not specified further than “energy technologies” in the paper). 

Electrochemical Approach. The electrochemical approach uses electrolysis of high-purity graphite anodes. This process is tunable by controlling the water content in the ionic liquid electrolyte which can influence the size and nanostructure of the dots. This method has a low cost and a high output but suffers from a limited choice of carbon source and limited options for doping with heteroatoms.<sup>36,55,62,63</sup> An et al.<sup>63</sup> synthesized dots via electrolysis from o-phenylenediamine (OPD) for the sensing of Fe<sup>3+</sup> and ascorbic acid. The dots have application for sensing Fe<sup>3+</sup> and ascorbic acid. The advantages of this method are the simplicity and no use of harsh chemicals such as acids. The disadvantage is that the quantum yield of the dots produces is very low at 0.47%. Dots with higher quantum yield were synthesized by electrochemical carbonization by Hou et al.<sup>76</sup> by using aqueous solution of sodium citrate and urea as an electrolyte and platinum sheets as electrodes. The reaction took place at 5 V over 1 h, and the dots were obtained from the electrolyte through dialysis. The application of these dots is suitable in the sensing of Hg<sup>2+</sup> , as they are very selective toward it and their fluorescence is quenched efficiently and completely in a matter of seconds at a pH range of 6−9. Both the syntheses outlined above are 

15480 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

limited in scale up due to the cost of the platinum electrodes. This cost could be recovered after the reaction is complete if the platinum is not changed or used up during the reaction, but this is not covered in the papers. If the electrodes are used up during the reaction, a comparison with other potential electrodes against cost should be outlined to prove that platinum is the most economical option. Unfortunately, neither paper reported the efficiency of their reaction (yield of dots). 

Purification and Separation Methods. Table 5 outlines different purification and separation methods with advantages and disadvantages for each method. Most syntheses require multiple methods to yield pure solutions or solid dots. The number and type of purification techniques can influence the dots in terms of purity; fast and simple methods might be costeffective and easy to be performed, but solid CD powders or CD solutions might contain impurities that give a false yield and effect the final properties. Methods that obtain very pure solutions or powders can be time-consuming and expensive, and because multiple steps are used, this also reduces production yield. 

Functionalization. Functionalization of CDs is extremely important for tuning properties of the dots for application. They can be functionalized either by modification of the surface or with doping heteroatoms into the structure of the dots. 

Doping. Doping is the incorporation of heteroatoms into the structure of CDs<sup>87−89</sup> (Figure 5). It is a common practice to improve the emissions of CDs by introducing an upward shift in the Fermi level and electrons in the conduction band.<sup>26,90</sup> 

It has been shown that CDs that have been doped with a heteroatom have improved properties and surface defects. The surface defects can eliminate or inhibit the original O-states and promote radiative recombination, while leading to higher quantum yields and emissions that are independent of excitement. Heteroatoms embedded into the carbon structure of CDs regulate the initial band gap and form new energy levels. An example is when CDs are doped with nitrogen, the most common dopant to change the fluorescent properties of CD due to its 5 valence electrons and similar size to carbon. Another example is boron, characterized by fewer valence electrons than carbon but has a similar radius. Boron introduces some chemical disorder because the bond between the carbon and boron is slightly (0.5%) longer than a carbon− carbon bond.<sup>91,26</sup> 

Heteroatom-doping CDs with different elements can change optical properties of CDs and provide more active sites. This can change the emission wavelength of the dot and increase its quantum yield. In turn, this can mean that the CDs are suitable for different applications. Usually, doping CDs with high electronegative atoms, such as nitrogen and sulfur, causes a blue-shifted emission. Conversely, low electronegative atoms doping, such as phosphorus and boron, leads to a red-shifted emission.<sup>26</sup> 

Comparing nitrogen-doped CDs (N-CD) and sulfur-doped CDs (S-CD), S-CDs are harder to synthesize because C−S bonds are difficult to form, due to the atomic radius of S being greater than that of C, and the C−S bond is 25% longer than the C−C bond. However, S and C show similar electronegativities, and the C−S bond does not provide significant charge transfer. Furthermore, S-doping alters the chemical properties of CQDs because of the mismatch between the 

outermost S and C orbitals; this can result in an uneven distribution of the spin density, increases surface reactivity and catalytic effect,<sup>92</sup> and causes a blue shift in emission.<sup>93</sup> This can be applied in different potential areas such as catalysis or surface functionalization. 

An example of doping procedure has been reported by Ma et al.<sup>94</sup> that developed a method to synthesize N-CDs via a microplasma process. Citric acid was used for the carbon source and ethylene diamine as the nitrogen source. The microplasma technique was applied to the solution for 2 h, after which the CDs were obtained from 24 h dialysis and filtration though a 0.2 μm to remove larger and unreacted particles. The dots had an average particles size of 5.98 ± 1.37 nm, blue emission under a UV lamp, and a quantum yield up to 9.90%. This work successfully outlined a low-energy (when compared to microwave) synthesis of N-doped CDs; however, the limitation of this method is associated with the yield (0.42%). It is suggested that decreasing the size of the electrode can increase the particle production due to increased electron density. This can support the investigation of unknown scenarios by considering different ways to increase electron density, such as by changing the probe size or the composition of the probe. 

Another example of doped dots (P and N with phosphoric acid and formamide as dopants, respectively) using citric acid as a carbon source was outlined via a solvothermal method by Li et al.<sup>95</sup> The PL emission of the dots was tunable from blue to orange regions. The mechanism for PL is reported due to surface defects. Quantum yield was 47%, which is high and favorable in applications in imaging. This method is a great example of heteroatom-doped dots used as imaging agents in HeLa cells. This method uses three chemical precursors which are obtained from laboratories. To make this synthesis greener, biomass could be used. Careful selection of biomass could also lead to auto doping, minimizing costs. 

Moving to biomass derived synthesis protocols, Shi et al.<sup>96</sup> have reported a hydrothermal procedure with a careful selection of biomass to produce N and S self-doped carbon quantum dots. The fungus fibers used as the carbon and heteroatom source were chosen because of their high protein, amino acid, polysaccharide, and vitamin content; they were prepared according to a biosynthetic pathway using both solid and liquid potato dextrose agar and purified with a dilute acid solution. The hydrothermal treatment was performed with 25 mL of DI water in a 50 mL Teflon-lined autoclave at 200 °C for 8 h. Then, a 0.22 μm filter membrane was used to remove larger particles. The obtained dots were characterized by an average diameter of 6.5 ± 0.5 nm and blue emission under UV light, and the quantum yield was estimated as 28.11%. This research work has successfully proposed the biomass derived synthesis by using renewable biomass with a high nitrogen and sulfur content; this meant the dots were self-doped and did not require an alternate source for doping. Furthermore, the dots produced were also tested for application and were shown to have good biocompatibility and excellent photostability with high quantum yield. Unfortunately, the yield of dots produced was not reported for testing the scale-up viability of this method to produce dots at large scale. 

Comparing the techniques outlined above, the biomass derived technique is advantageous because no additional reactant or heteroatom source are required. The hydrothermal technique requires no adaptation and uses mild aquatic 

15481 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 



Figure 6. Examples of covalent and noncovalent modification to CDs. Adapted with permission from ref 99. Copyright 2018 Springer Nature. 



Figure 7. Specific examples of functionalization from the papers outlined above: Amide coupling,<sup>100</sup> esterification,<sup>101</sup> sulphonylation,<sup>103</sup> copolymerization,<sup>104</sup> silylation,<sup>106</sup> π interactions,<sup>107</sup> ion complexation,<sup>108</sup> and electrostatic interaction.<sup>109</sup> 

conditions and simple work up process without dialysis with the production of high quantum yield. 

Finally, examples of biomass doping synthesis using other heteroatoms are reported in literature. Molkenova et al.<sup>97</sup> created a green synthesis for phosphorus-doped CDs via a hydrothermal method by using dextrose as a carbon source and disodium hydro phosphate. The dots had a narrow size distribution of 2.8 ± 0.94 nm and excitation-dependent fluorescence emission. The maximum emission was detected at 452 nm with a quantum yield of 6.73 ± 0.04%. Selectivity 

test revealed that prepared doped CDs were highly selective to ferric ions, therefore demonstrated great potential for monitoring Fe (III) pollutant at low concentration in drinking water. The use of waste biomass with a phosphorus content for synthesizing the dots could enhance the green “level” of this procedure and reduce the synthesis time. 

Surface Modification. The surface of CDs can be functionalized by a range of materials, such as ions, organic molecules, polymers, DNA, and proteins, with the aim to change the properties of the dots. Because CDs are abundant 

15482 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

with surface groups, functional ligands can readily bind to them.<sup>98</sup> Figure 6 shows examples of reactions that can be used to functionalize the surface of CDs, which can subdivided in covalent and noncovalent bonding.<sup>99</sup> Particularly, modification of CD via covalent method involves a reduction of functional molecules and groups on the surface and is used to achieve better control of size, shape, and physical properties of CDs because the groups introduced to the dots surface can increase the electron cloud density. Noncovalent modification utilizes π interaction or van der Waals forces and is less impactful on the structure of CDs when compared to covalent modification because the surface is not chemically changed.<sup>99</sup> More details on the reactions are described briefly in the next paragraphs. Each method described is visualized in Figure 7. 

Amide Coupling. Amide coupling is achieved by reacting amino compounds and acylating reagents, such as acyl chloride or carboxylic acid.<sup>99</sup> This is a common functionalization method because the surface of the dot is abundant with amino or carboxyl groups. The advantage of amide modification is an increase in selectivity and quantum yield of the CDs. Another advantage is to introduce hydrophobic nature to the CDs to make them more accessible to a solvent environment. This is due to the fact that the amide bond possesses no rotational freedom which imparts a partial double character, causing a kink in the CD called “beta-turn” that causes the hydrophobic nature.<sup>99</sup> An example of amide coupling application was described by Dong et al.,<sup>100</sup> where CDs were synthesized by a hydrothermal method from glucose and functionalized with ethylenediamine (EDA). In this work, the EDA was used to enhance the luminescent intensity, but no information on the increase of intensity has been reported (missing the value before the passivation with EDA). 

Esterification. Esterification is a reaction between carboxylic acid and alcohol in the presence of an acid catalyst which forms an ester and water.<sup>99</sup> Esterification methods can expand the number of application of CDs with many carboxyl or hydroxyl groups on their surface by introducing different functional components to interact with these groups. CDs that are modified by esterification exhibit excellent selectivity and reversibility toward targets, especially important for application in detection and cell imaging fields. Esterification can also convert the hydrophilic and oleophobic properties of CDs to lipophilic hydrophobicity.<sup>99</sup> 

CDs used for detection of Ag<sup>+</sup> based on static quenching mechanisms were described by Algarra et al.<sup>101</sup> In this work, the CDs were synthesized from lactose with heating with sulfuric acid and then functionalized with mercaptosuccinic acid (MSA). When Ag<sup>+</sup> is added, the thiol groups on the MSA can form a ground-state complex with Ag<sup>+</sup> resulting in fluorescent quenching. The quantum yields of the CDs improved from 21% to 46% after binding with MSA by changing surface state of CDs. This was a great example of esterification functionalization, but the importance of detecting Ag<sup>+</sup> ion was not outlined. This could be related with the increasing issues on the release of Ag<sup>+</sup> ions from industry toward human health and the environment due to their toxicity.<sup>102</sup> 

Sulfonylation Reaction. CDs with amino-containing groups can be functionalized with sulfonyl chloride compounds via a sulfonylation reaction. This introduces both sulfur atoms and ligands that are attached to the surface of the dot. The atoms provide the dot with increased energy or emissive trap states. 

This increases the rate of photoexcited electron capture, which in turn improves the PL of the dot.<sup>99</sup> 

An example of sulfonylation reaction was applied to conjugate a BHHCT-Eu<sup>3+</sup> probe to the surface of a dot to create a dual-fluorophore nanoparticle as reported by Ye et al.<sup>103</sup> This was used to detect Cu<sup>2+</sup> in water by utilizing the energy transfer from excited Eu<sup>3+</sup> to Cu<sup>2+</sup> that quenched the red fluorescence of the BHHCT-Eu<sup>3+</sup> , while the blue fluorescence of the dot itself was constant. This phenomenon caused a perceived color change from the whole complex from orange to blue when it is exposed to Cu<sup>2+</sup> . This research represents an interesting example of biomass derived synthesis because a hydrothermal synthesis of chitosan was used; however, no information on the yield of dots was reported while investigating its suitability for scale up for application. 

Copolymerization. Active hydrogen can be found within the functional groups on the surface of CDs and can be used for modification by copolymerization reaction with cyclic compounds or double-bond compounds. These reactions can be used to create large molecular weight CDs, which are beneficial to applications in biological systems.<sup>99</sup> Copolymerization was proposed by Li et al.<sup>104</sup> to create CDs functionalized with N-isopropylacrylamide (NIPAM), a derivative monomer of acrylamide. It was proposed as a smart material because its structure presented both hydrophilic amide and hydrophobic isopropyl groups with good temperature sensitivity. Particularly, the dots were first prepared through amide coupling with L-tyrosine and citric acid as a carbon source. Once grafted to the NIPAM, the dots showed excellent dispensability and maintained their fluorescence in water. They also had a thermoresponsive fluorescence property that decreased with the increase of the temperature. The dots could be applied in thermoresponsive imaging and controlled drug release. 

Silylation. Like the copolymerization described above, silylation reactions use active hydrogen on the surface of CDs for modification with silane groups.<sup>99</sup> CDs that have been functionalized with silane are often used as sensors and probes, because the two types of silane functional groups allow easy chemical modification. Silane is also biocompatible and nontoxic, can increase the specific surface area to improve dispersion, can improve the water solubility and selectivity, and greatly reduce the cytotoxicity of CDs. Applications of CDs functionalized in this way are proposed in ion detection and ’ temperature sensing.<sup>99</sup> 105 An example, Roa et al.106 proposed silane-modified CDs as a sensor for Cu<sup>2+</sup> detection. The authors used a hydrothermal synthesis with citric acid as a carbon source. The dots were then functionalized using tetraethyl orthosilicate (TEOS) and 3-aminopropyl triethoxysilane (APTES) via silylation reaction. This results in a balance between inert and active functional groups by reducing particle aggregation and nonspecific binding. A large number of amino groups on the surface of CDs were created to covalently conjugate thioglycolic acid modified CdTe SCQDs via EDC/NHS coupling reaction. This whole system could link Cu<sup>2+</sup> with carboxy and hydroxy groups on the surface of CdTe SCQDs, leading to quenching of the fluorescence of the SCQDs. This led to a color change in the system because the CD dots fluorescence were not quenched. This process could be made more environmentally friendly using a biomass carbon source for the CD and a replacement of the SCQD with a different biomass derived CDS. This would also avoid 

15483 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

issues with the toxicity since the suggested application was to test for Cu<sup>2+</sup> in fruits and vegetables. 

π Interactions. CDs that possess the extended π systems can be modified through π interaction with small aromatic molecules. This extends conjugation domains that increase quantum yield, photostability, and biocompatibility.<sup>99</sup> This type of modification system was used to make a probe for the detection of Ag<sup>+</sup> by Jiang et al.<sup>107</sup> In detail, Si-doped CDs were synthesized from glycerol and (3-aminopropyl)triethoxysilane using a microwave assisted method. The dots were then functionalized by face-to-face π interactions with dopamine. When exposed to Ag<sup>+</sup> , the dopamine can reduce the Ag<sup>+</sup> to silver nanoparticles and the system produces a new peak at 438 nm. Because of its low cytotoxicity, salt stability, and photostability, these produced dots can be applied to intracellular Ag<sup>+</sup> detection and bioimaging. A more environmentally friendly solution could be proposed by selecting a carbon source from biomass instead of using raw glycerol. 

Complexation. CD can be functionalized with molecules or ions through complexation, characterized by coordination bonds formed between the metal ion and functional groups on the CDs surface. When a complexation is made between an amphiphilic molecule and the CD surface, the hydrophobic part enhances the stability of CDs in organic solvents. CDs functionalization through complexation can alter the interfacial properties of CDs, and consequently their application.<sup>99</sup> An example of complexation was described by Guo et al.<sup>108</sup> for the desalination of seawater. The dots were synthesized from citric acid via heating in air and then functionalized with sodium hydroxide. The sodium ions formed a complex with the carbonyl groups on the surface of the CD. This system was used as a highly efficient draw solute of the forward osmosis of seawater. 

Electrostatic. Because the surface groups on CDs are either positively or negatively charged, this makes the CDs charged. This means that they can be modified by charged reagents through electrostatic interaction. This method is often used to functionalize with other fluorophores or targeting molecules.<sup>99</sup> An example was proposed by Jin et al.<sup>109</sup> that reported a green synthesis of hydrothermal treatment of carrot juice to produce CDs. The CDs were then conjugated with both polyethyleneimine (PEI), to improve water solubility, and Nile blue, which is an organic dye and produces a probe with two photon fluorescence. The probe can be first “turned off” via quenching with Cu<sup>2+</sup> ; after exposure to S<sup>2−</sup> , there is the formation of a stable species and the probe is turned back on. This system is highly selective and has a high detection recovery. Additional tests on the toxicity or biocompatibility can be useful in order to evaluate their applications in biological fields. 

Applications. CDs have similar applications as semiconductor-based quantum dots because of their great physical and optical properties. The applications of CDs already outlined in the papers above are luminescent ink,<sup>52</sup> enhancement of photosynthesis,<sup>53</sup> ion sensors (Hg<sup>2+</sup> ,<sup>68,76</sup> Cu<sup>2+</sup> ,<sup>69,103,106,109</sup> Fe<sup>3+</sup> ,<sup>63,97</sup> Ag<sup>+</sup> ,<sup>101,107</sup> ), bioimaging,<sup>67,95,104</sup> photoelectronics,<sup>67</sup> drug release,<sup>104</sup> and seawater desalination.<sup>108</sup> 

This section further outlines examples of chemical CDs for application. Application for biomass-based CDs will be outlined further in Biomass Derived Carbon Dots section and will be compared against chemical CDs. 

Davi et al.<sup>110</sup> synthesized CDs from dansyl chloride via a hydrothermal technique, and these dots were used as a 

radiometric thermal sensor and pH sensor and for reactive oxygen generation. They showed that fluorescence intensity of the dots increased with rising temperature, which is the opposite of what is usually shown with CDs. This property could possibly be used as a “turn on” temperature sensor. Fluorescence intensity also increased with an increase in pH and changed the color of the emitted light. The team also showed that the generation of reactive oxygen species upon photoexcitation exhibited a moderate singlet oxygen quantum yield, reaching 11% for excitation intensities above 10 mW/ cm<sup>2</sup> . Unfortunately, the authors did not outline specific examples of applications for these CDs. 

Li et al.<sup>111</sup> synthesized near-infrared emission CDs for bioimaging. The dots were synthesized via a solvothermal treatment of tetraphenyl porphyrin in sulfuric and hydrochloric acids. It was shown that the fluorescence originated from aggregated molecular states of the CDs and exhibited as a strong NIR emission at 692 nm with a high quantum yield of 23.8%. The CDs also had good dispersibility in water, exceptional biocompatibility, minimal toxicity, and enhanced labeling capability in bioimaging. The use of tetraphenylporphyrin, sulfuric acid, and hydrochloric acid means this synthesis cannot be considered green. Using a greener alternative for both the carbon source and reactants would vastly increase the greenness of this reaction and could further decrease the minimal toxicity seen in the resulting dots. 

Chang et al.<sup>112</sup> synthesized CDs from triammonium citrate for cell imaging and white LEDs using a solvothermal method with urea. The rationale for choosing triammonium citrate is because it is more environmentally friendly and has a higher nitrogen content for doping and the dots produced require less work up. The dots synthesized had low toxicity and high stability. The emission color of the CDs was tunable to wavelengths on the entire visible region by adjusting reaction temperature. The quantum yield for red, green, and blue emissive dots were 24.4%, 17.2%, and 12.1%, respectively. The mechanism through which the dots showed their emission was proposed to be controlled by the surface state. Increasing the number of functional groups of the surface changed the degree of graphitization. The CDs were successfully used to image HeLa cells, and CD/polymer composite films were used to create white LED. Although triammonium citrate is more environmentally friendly than citric acid, this method still cannot be considered green because urea and triammonium citrate are not green chemicals. 

Li et al.<sup>113</sup> used CDs modified with γ-Fe2O3 as a catalyst for the degradation of sulfamethoxazole (SMX) through the activation of persulfate. The CQDs@γ-Fe2O3 were synthesized using a solvothermal method using glucose as a carbon source. The glucose was dissolved in a 50 mL solution of ethanol:H2O (1.5:1), and then γ-Fe2O3 was dispersed in the mixed solution and heated in an autoclave. The researchers showed that the formation of heterojunction structure between CQDs and γ- Fe2O3 reduced the catalyst band gap, which increases the separation rate of electrons and holes, leading to notable efficient SMX degradation as compared to the dark-CQDs@γFe2O3/PDS and vis-γ-Fe2O3/PDS systems. The breakdown of SMX is useful for municipal wastewater plants because SMX has been widely used in human activities and frequently detected in effluents. Residual SMX in waters could cause potential negative effects on human health and the environment. Even though this method uses glucose and ethanol, 

15484 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

|advantages (Adv) and disadvantages (Dis)<br>ref<br>Adv: simple to operate, controllable and nontoxic<br>129−132<br>Dis: poor control over size and presence of impurities.<br>Adv: simple and well-established method<br>93,<br>133−136<br>Dis: high temperatures; further passivation can be<br>needed<br>Adv: most effective and least time-consuming methods;<br>high efficiency and homogeneous heating<br>137−140<br>Dis: poor control over size, microwave radiation is<br>harmful to human beings.<br>Adv: no complicated treatment method; synthesis<br>process is avoided and is low cost<br>141, 142<br>Dis: poor control over properties.<br>Adv: process is simple, easy to control, and promotes<br>crystal structure<br>26, 117<br>Dis: transformations of the dots, poor size control, and<br>a long reaction time<br>Adv: very hydrophilic and variable emission, and<br>effective and facile method suitable for large scale;<br>process is easily modified, and surface state is tunable<br>26, 143<br>Dis: harsh chemical may be used and biotoxicity of the<br>products is increased|
|---|
|properties<br> <br>papaya carbon source produced blue colored CDs with a 2−6 nm<br>size and QY of 18.98%; peach extract produced blue nitrogen-<br>doped with particle size of 8 nm and a QY of 15%<br>konjac flour as precursor produced nitrogen-doped CDs with<br>quasi-spherical shape, average diameter of 3.37 nm and QY of<br>22%<br>CDs from marigold flower had a QY of 7.84% and blue<br>fluorescence.<br>casein dots had high QY of 18.7% and size of 7 nm<br>CDs from rose petals had high QY of 13.45% and size range of<br>4−6 nm<br>dots extracted from Nescafe’ were strongly photoluminescent<br>with a size of 4.4 nm and were well-dispersed in water and with<br>QY about 5.5%<br>beer extracted dots had an average size of 2.5 nm, were highly<br>soluble, and had excellent fluorescence properties; QY of<br>approximately 7.39%<br>food waste dots showed a high degree of solubility in water, a<br>narrow band of PL emission (400−470 nm), a size of 4 nm and<br>excellent photostability<br>biowaste synthesized dots had an average particle size of 5−6 nm<br>and the QY < 2%|
|process<br>uses heat and pressure in aqueous conditions to produce quantum dots in a cheap,<br>convenient, and ecofriendly way; no passivation required for PL<br>uses high temperatures to carbonize organic substances as a simple and<br>ecofriendly way to produce CDs in inert atmospheric conditions<br>uses microwave heating to carbonize organic substances to produce CDs<br>QY and quality of this method can be improved by utilizing short duration<br>heating<br>uses simple centrifugation and filtration to extract CDs made in nature<br>causes biomass to go through dehydration, polymerization and carbonization;<br>CDs are fully synthesized after a short single nuclear burst<br>oxidants (such as H2O2 and H2SO4/HNO3) are used to stimulate the<br>carbonization of biomass materials; the process also introduces oxygen-<br>containing functional groups, such as −OH, −COOH, which increases<br>hydrophilicity|
|method<br>hydrothermal<br>bottom-up<br>pyrolysis<br>bottom-up<br>microwave<br>bottom-up<br>extraction<br>method<br>neither<br>ultrasonic syn-<br>thesis<br>top-down<br>chemical oxi-<br>dation<br>top-down|



15485 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

which are renewable and fairly mild chemicals, the greenness could be further improved by using raw biomass. 

Limitations. One drawback of CDs, when compared against SCQDs, is associated with their low quantum yield which can affect their range of application.<sup>114</sup> The quantum yield of SCQDs can range between 40 and 90%,<sup>115</sup> while, typically, the quantum yield of CDs can reach up to 30%. However, Yang et al.<sup>116</sup> reported a quantum yield of up to 62.8% by doping the dots with nitrogen and synthesized via a microwave methods from resorcinol, OPD, and hydrochloric acid. The high quantum yield has been obtained because the dots contained many N atoms from nitrogen doping, few vacancies in the carbon framework, and a large sp<sup>2</sup> domain within the core. The presence of HCl acted as “promoter” to facilitate the reaction, which led to a bright fluorescence and high production yield. However, applying this method to waste biomass rather than raw chemicals can lessen the impact on the environment. 

Furthermore, another important limitation is associated with the very low production yield of the CD synthesis. As reported before, most studies do not report completely the yield value, and only few studies have obtained dots in gram and kilogram scale. With aim to reduce yield issues, Park et al.<sup>117</sup> developed an approach for the large-scale synthesis of green, watersoluble CDs from waste food. The synthesis method used a solution of 500 L of 10% ethanol with 100 kg of food waste. This mixture was treated with ultrasound for 45 min and then centrifuged at 4500 rpm for 5 min to remove large, agglomerated particles. The dots were filtered twice to remove large particles through a 0.22 μm membrane. Finally, 120 g of CDs could be produced from 100 kg of food waste. This is a yield of 0.12% from biomass. The size of the dots was 2−4 nm and exhibited very good solubility in water. The in vitro bioimaging results demonstrated an immense potential for biomedical application; the produced dots were used as to image HepG2 cells and were shown to have excellent photostability and low cytotoxicity. This method represents a very environmentally considerate procedure; however, despite its low efficiency and yield, the method might still be costeffective for further scale up due do to the fact that no expensive chemicals or a heating process were used. Also, the precursor is very cheap (waste biomass), and the byproducts that do not contain dots can be sold as fertilizer. 

A more efficient method was produced by Li et al.<sup>118</sup> They developed an easy, green, large-scale synthesis of high-quality fluorescent CQDs using a one-step hydrothermal treatment of poplar leaves. The technique used 5 kg of poplar leaves with 19 L of deionized water in a 30 L autoclave. This was heated for 24 h at 200 °C. The quantum dots were obtained by vacuum filtration in the filtrate, and rotary evaporation was used to obtain the dots; they obtained 1.498 kg from one pot, with a yield of 30% from dry biomass. The dots had a photoluminescent quantum yield of 10.64% and were very stable in aqueous media and highly photostable. The surface was rich with functional groups and within a biological pH range showing consistent PL and low cytotoxicity. It was shown that the dots had applications in electrocatalytic water splitting, Fe<sup>3+</sup> sensing, and bioimaging. It showed notable electrocatalytic activity, Fe<sup>3+</sup> sensitivity, and good biocompatibility. 

The highest yielding method of CDs (near 100%) is reported by Ge et al.,<sup>119</sup> where dehydroabietic acid and ethanolamine were mixed with deionized water and heated to 200 °C for 300 min to obtain CDs for application in white- 

emitting LEDs. The dots were soluble in ethanol, and the solutions showed excitation-dependent and tunable fluorescence emission. They had a quantum yield of 10% and an average size of 3.2 nm. There is no explanation provided as to why the yield in this work is so high or even a suggestion of a reaction mechanism. One suggestion could be that the dots are still mixed with impurities. An explanation for why the yield is so high could help other researchers to increase their yields of CDs in different syntheses. These dots are labeled as “biomass derived”, but both the initial reagents used are purchased from laboratories. Chemicals can come from a lot of sources, and while it is better that the chemicals used here are from green sources, there are extra steps introduced such as isolation and purification; only these steps are dealt with by the lab the chemicals are purchased from. This could be another potential reason why the yield is so high; high purity of initial starting reagents. This research could go further by comparing the dots made from raw biomass to the dots made from the purified chemicals to see what difference it has on the yield and other properties and if buying the purified chemicals is actually more economical than using raw biomass. 

It is clear from the research outlined above that more research is needed to develop protocols to synthesize CDs in an environmentally friendly way with very high yields. The methods proposed by Park,<sup>117</sup> Li,<sup>118</sup> and Ge<sup>119</sup> represent a nice starting point to achieve this challenging demand. All three of the methods outlined above made claims that their carbon sources were biomass based. It seems that biomass CDs could have potential in solving some of the challenges CDs face. 

### BIOMASS DERIVED CARBON DOTS 

Biomass is any material that is derived from plants or animals and is usually used in energy production. Biomass can also be split up into three categories: micromolecules derived from biomass (e.g., citric acid, glucose, etc.), biomass components (e.g., cellulose, hemicellulose, lignin, etc.), and natural biomass (e.g., straw, crab shell, etc.).<sup>120</sup> Biomass can be used as a carbon source for CDs and can come from numerous sources, both from waste streams and nonwaste renewable products. Waste biomass, such as leaves, or food waste is considered the most environmentally friendly and facilitates waste management and often has a lower cost. Biomass that cannot be considered waste is still green, but it is less environmentally friendly because it does not facilitate waste management. This type of biomass often has a higher cost compared to waste biomass but can be purer, which can make synthesis more simple. 

This section aims to outline the benefits of environmentally friendly biomass derived CDs. These dots have generally the same properties as chemical CDs: strong PL emission and optical properties, good conductivity, broadband optical absorption, high chemical stability, nonblinking, resistant to photobleaching, broad excitation wavelength, and tunable emission wavelength by modifying synthesis parameters to change, including size, shape, composition, internal structure, and surface chemistry.<sup>27,36</sup> They are also more environmentally friendly and have potential to be less toxic and biocompatible. 

Synthesis of Biomass Derived Carbon Dots. Syntheses to obtain CDs from biomass with good optical and electronic properties are possible though a variety of methods and precursors,<sup>121</sup> as summarized in Table 6 and the paragraphs below, including the advantages and disadvantages of each method. In addition to these methods, other less common 

15486 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

synthesis methods are biogenic,<sup>122</sup> solvo-thermal,<sup>123,124</sup> oxidation,<sup>125</sup> reflux,<sup>126</sup> calcination,<sup>127</sup> and microwave hydrothermal.<sup>128</sup> The least green method outlined below is the chemical oxidation because of the use of strong acids to carbonize the carbon source, whereas the greenest method is the extraction method from biomass waste without the need for heat or chemicals. The extraction method does come with the big disadvantage that there is no control over the properties of the dots obtained. From the analysis, microwave and hydrothermal methods are highly considered for CD synthesis. 

Hydrothermal Method. The hydrothermal method uses high temperature and pressure in aqueous conditions to produce quantum dots in a cheap, convenient, and ecofriendly way. The method is simple to operate, controllable, and nontoxic, and no passivation is required for PL. However, the method has poor control over size, and there are often impurities present.<sup>129−132</sup> 

In 2016, Wang et al.<sup>129</sup> published a work outlining a green synthesis for CDs using hydrothermal carbonization of papaya. The papaya was heated for 5 h at 200 °C, and the products were filtered and extracted via dialysis for 72 h to produce CDs with blue PL with a size of 2−6 nm and high quantum yields of around 18%. The authors demonstrated that the dots were proficient at imaging HeLa cells and for the fluorescence sensing of E. coli bacterial strain. However, as reported previously in other cited research works, the percentage yield was unreported; therefore, the efficacy of this reaction cannot be stated for the further scale-up. 

Atchudan et al.<sup>132</sup> described a hydrothermal method of producing nitrogen-doped dots from unripe peach and aqueous ammonia as a nitrogen source. The dots had a mean size of 8 nm and a quantum yield of 15%, bright fluorescence emission, and low cytotoxicity with great biocompatibility and excellent water dispersity. These dots were shown to have applications in imaging with the imaging of MDA-MB-231 cells. This method is a good example of the hydrothermal synthesis. It is simple and produces dots with good properties; however, this method is not as green as it could be because ammonia is used as a nitrogen source which is harmful to the environment. This is unnecessary, as careful selection of biomass with a high nitrogen content can lead to autodoping. 

Pyrolysis. Another example of a bottom-up process is pyrolysis, which uses elevated temperatures (350−750 °C) to carbonize organic substances as a simple and ecofriendly way to produce CDs in inert atmospheric conditions, for example, nitrogen. It is a well-established and simple method, but high temperatures are required and further passivation of the dots is needed for PL.<sup>134−136</sup> 

An example of pyrolysis was outlined by Teng et al.<sup>135</sup> that used 1 g of konjac flour pyrolyzed in air at 470 °C for 90 min to produce nitrogen-doped CDs with quasi-spherical shape, average diameter of 3.37 nm, and quantum yield of 22%. The production yield was approximately 3%. The authors stated that further passivation with PEG was also required to produce PL dots (tuned by the molecular weight), which could be considered an exception considering the other methods that do not require further passivation step. It was demonstrated by the authors that the dots have potential application in imaging and as “off-on” sensing capabilities for Fe<sup>3+</sup> . 

Another pyrolysis synthesis for CDs for Fe<sup>3+</sup> sensing was outlined by Zhang et al.<sup>136</sup> using marigold as a carbon source. 

This method used compression and fermentation to form pellets, which were then subject to pyrolysis. The product from this was then subject to a reduction with H2SO4-HNO3 and then doped with nitrogen using ethylenediamine. Compared to the method outlined above by Teng et al., this method is a lot less green because there are more steps with harsh chemicals. The quantum yield of the dots is also worse at 7.84%. This method would need a lot more development to become viable. 

Microwave synthesis. Microwave synthesis uses microwave heating to carbonize organic substances to produce CDs. Utilizing a short heating duration improves quantum yield and quality of the dots. This method is the most effective and least time-consuming with high efficiency and homogeneous heating; however, it suffers from poor size control and microwave radiation is harmful to humans, which adds additional controls to large-scale production.<sup>137−140</sup> Feng et al.<sup>140</sup> proposed the microwave synthesis of CDs from rose petals. The petal powder, P2O5, and water were added to a microwave and heated until the color had changed from pink to brown. The mixture was centrifuged and filtered to remove unnecessary products. The filtrate was purified via dialysis. The dots had high quantum yield of 13.45% and size range of 4−6 nm. The production yield of the dots was unreported, so scale up potentiality is unknown. The authors did not justify the reaction pathway or mechanism as well as the rationale for the use of P2O5. Some assumptions can be made on its transformation to phosphoric acid with contact with water; this would act as a catalyst similar to the chemical oxidation method proposed by Suryawanshi et al.<sup>143</sup> 

Another example of a microwave reaction was outlined by Bajpai et al.<sup>137</sup> using the milk protein casein as a carbon source. The synthesis progresses with microwave heating of casein solution, which yielded a semi-solid solution. This residue was diluted with distilled water and centrifuged. The supernatant was collected and analyzed. This method is quite green because there is no harsh chemical used and there are very few steps. The greenness of this method is let down by the fact that the biomass used in this synthesis is lab bought rather than from waste biomass. A comparison of dots made from waste milk and these casein dots outlined in the paper would help to distinguish if these dots could be more economical. The quantum yield of these dots is 18.7%, which is high and show blue PL. The dots were used to image a spinach leaf, and application was suggested in cell imaging for plant-related diseases. 

Ultrasonication. Ultrasonication is a top-down process that causes biomass to go through dehydration, polymerization, and carbonization. CDs are fully synthesized after a short single nuclear burst, so there is no passivation required. This method is simple and promotes crystal structure, but there is poor control over size.<sup>26,117,144</sup> An example of a ultrasonication synthesis was outlined by Huang et al.<sup>144</sup> using cigarette ash. Cigarette ash and PEG-SH were dissolved in DMF and ultrasonically heated for 30 min using an ultrasonic cell disruptor. Supernatant liquor was obtained via centrifugation and then dialyzed against distilled water and alcohol for 3 days to remove any remaining raw materials. The CDs were obtained by rotary evaporation. This method is interesting because the dots are automatically functionalized with PEG, meaning that no further reaction is required. Analysis confirmed the dots had a uniform nanoscale size of 4 nm, notable optical stability under long-term UV light irradiation and various pH values, excellent water dispersibility and great 

15487 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

biocompatibility, a narrow band of PL emission (400−470 nm), and excellent photostability. The dots were shown to have potential application in cell imaging. This method is a good example of an environmentally friendly synthesis because the precursor of cigarette ash is a recycled material that can be easily obtained for scale up. Unfortunately, the efficiency of this reaction cannot be commented on because the yield was not reported. 

Chemical Oxidation. Chemical oxidation uses oxidants such as (such as H2O2 and H2SO4/HNO3) to stimulate the carbonization of biomass materials. The process also introduces oxygen-containing functional groups, such as −OH, −COOH, which produce dots that are very hydrophilic and have variable emission and a tunable surface state. This is an effective and facile method suitable for large scale, and the process is easily modified. But the harsh chemicals used reduce the greenness of this method, and the biotoxicity of the products is increased.<sup>26,143</sup> 

Suryawanshi et al.<sup>143</sup> outlined a method that used acid carbonization to produce graphene CDs. First, porous turbostratic carbon power was produced via pyrolysis of neem leaves at 1000 °C for 5 h in an Ar atmosphere. The carbon powder was then reacted with a 3:1 mix of H2SO4 and NNO3 and heated at 90 °C for 5 h under reflux. The solution was then diluted, filtered, neutralized with NaOH, and then dried in a vacuum to obtain the GQDs. The dots were then further functionalized with amine groups via a hydrothermal treatment. The dots had an average particle size of 5−6 nm and a low quantum yield of <2%. The total production yield of this reaction was unreported; therefore, the efficiency of this method for the large-scale synthesis of dots could not be evaluated. Other limitations can be associated with the several steps and heating methods required: the use of strong acids and low quantum yield obtained (2%). The dots were used as a sensor for Ag<sup>+</sup> using an “on−off” on PL quenching. Further applications for this were suggested in soil, water, and food testing. 

Extraction Method. Extraction method does not synthesize dots itself. It uses simple centrifugation and filtration to extract CDs made in nature or processes such as cooking or brewing. The advantages of this is that there is no complicated treatment method, the synthesis process is avoided, and the method is low cost, but there is poor control over properties.<sup>141,142,145</sup> Wang et al.<sup>142</sup> reported an extraction of CDs from beer for imaging and drug delivery. In detail, 100 mL of beer was stirred to remove gas then concentrated by rotary evaporation. This concentration was filtered to remove large particles and then purified by chromatography. The dots had an average size of 2.5 nm. They were highly soluble and had excellent fluorescence properties with a quantum yield of approximately 7.39%. The production yield of dots was unreported, so the efficiency for scale up is uncertain. The dots were functionalized with doxorubicin (DOX) to be applied as imaging and anticancer agents in the field of nanotheranostics. It could be interesting to compare the yield of dots from newly purchased beer and waste beer such as dregs from kegs or production waste. 

Dhandapani et al.<sup>145</sup> also outlined an extraction of green CDs from fried food waste residue. The method proceeded by mixing fried food waste with water and stirred to yield a colloidal solution that was filtered through 0.22 μm pore size filter paper. The solution was centrifuged at 10000 rpm, yielding a supernatant containing the CDs. This method was 

outlined as a synthesis, but it is actually just an extraction. There are advantages to this method, such as no heating or harsh chemicals are required to obtain the dots, meaning the method is cheap and simple. The disadvantage of this method is that the dots cannot be tuned to have specific properties and are whatever you find. These dots were shown to emit green wavelength emission, have outstanding dispersibility, constant emission, relative long-life emission time, and up-converted emission. Other properties of these dots such as size, quantum yield and production yield of the extraction were completely left out of this paper. These properties are important for both scale-up and for application, and this paper could be enhanced with the inclusion of these details. 

Finally, Table 7 compares the synthesis and properties of biomass derived CDs to chemical synthesis of CDs and SCQDs, respectively. It shows that biomass derived CDs are superior in biocompatibility, environmental aspects, and cost. Furthermore, biomass derived CDs can be produced from waste at low cost and prevents materials from being sent to landfills. 

Applications of Biomass Derived Carbon Dots. Biomass derived CDs have particular application in the biomedical field because of their biocompatibility and low toxicity, which originates with the source material. They are used in bioimaging, as drug carriers, and in sensors which can be used in the body. They also have applications outside the body for sensing and electrical purposes because of their exclusive properties and easy synthesis methods. 

Biomass derived CDs can be used in applications for the same reasons as any CD can be used: their excellent photoluminescent properties. However, they are superior to chemical CDs due to their increased biocompatibility and lower toxicity, due to their biomass source material. This also means they are environmentally friendly, which is better for large-scale production and would mean a better environmental impact. Below some examples are outlined from literature of applications of biomass derived CDs. 

Sensors. Biomass derived CDs can be used as sensors for the sensing of a variety of materials such as anions, metals, and molecules.<sup>147</sup> An example of biomass derived CDs used as sensors was produced by Lu et al.<sup>148</sup> that proposed a hydrothermal treatment of pomelo peel to yield fluorescent CDs that can be used as probes for Hg<sup>2+</sup> detection. It was demonstrated that the nanodots serve as a very effective fluorescent probe for label-free, sensitive, and selective detection of Hg<sup>2+</sup> that has a detection limit as low as 0.23 nm. The sensing works by the fluorescence quenching of the particles by Hg<sup>2+</sup> by facilitating nonradiative electron/hole recombination annihilation through an effective electron- or energy-transfer process. The dots can be recovered when a stronger Hg<sup>2+</sup> chelator, cysteine, is added due to the formation of a Hg−S bond that leads to the removal of Hg<sup>2+</sup> from CD. The detection of even trace amounts of mercury is very beneficial due to the fact that it can easily pass through skin, respiratory, and gastrointestinal tissues, which can lead to damage to DNA, impairment of mitosis, and permanent damage to the central nervous system.<sup>149</sup> Quantum yield of 6.9% could be improved by implementing doping strategies. For manufacturing sensors for detection of Fe<sup>3+</sup> , Huang et al.<sup>150</sup> proposed natural bauhinia flower as a carbon source in the preparation of nitrogen-doped CDs using a facile and green microwave method without further passivation or modification. The dots had a high fluorescent quantum yield of 27%. The 

15488 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

|semiconductor quantum dots|semiconductor sources do not take from waste streams and are<br>toxic|require long and harsh synthesis with organic solvents|resulting dots are toxic, especially to the liver|core shell relationship requires a multistep process|mostly complex synthesis steps while the necessity for special<br>equipment, costly chemicals, and higher energy consumption|generating risky products/byproducts for the environment and<br>human health, made form nonrenewable precursors|PL well understood and defined by the quantum confinement<br>effect|
|---|---|---|---|---|---|---|---|
|ical dots|used|H2SO4 and chemical stabilizing agents; the<br>|y and potential toxicity, uncertainty of|hemicals|cessity for special equipment, costly chemicals,|e environment and human health, made form|d Thought to originate with surface defects and|
|m|nly|nd <br>|vit|c|ne|th|an|
|che|inorganic and metallic precursors are mai|high use of strong acids such as HNO3 a<br>|resulting dots can have unwanted reacti<br>composition|extra passivation step required, often with|mostly complex synthesis steps while the <br>and higher energy consumption|generating risky products/byproducts for <br>nonrenewable precursors|PL requires more research to fully underst<br>the quantum confinement effect|
|d carbon dots|iendly, safe precursors as a<br>hesis via biological techniques|nontoxic and safe reagents,||cal exposure)|sis, consume less energy and<br>|ewable and facilitate waste|ully understand; thought to<br> and the quantum confinement|
|ive|ofr<br>nt|of||mi|he<br>|en|f<br>ts|
|er|ec<br> sy|se <br>|ic|e|nt<br>|/r|to<br>ec|
|biomass d|occurring, <br>on for CD|friendly, u<br>|are nontox|reducing ch|ngle-step sy<br>p<br>f|affordability|re research <br> surface def|
||rally <br> carb|tally<br>|dots|ed (|e, si<br>ale-u<br>|and <br>ent|mo<br>with|
||natu<br>e of|men<br>|ing|sivat|fectiv<br>to sc<br>|ility <br>gem|uires<br>ate <br>|
||use of <br>sourc|environ<br>|result|self-pas|cost-eff<br>easy <br>|availab<br>mana|PL req<br>origin<br>effect|



dots were proved to be an effective “turn-off” fluorescent sensor for detection of Fe<sup>3+</sup> , exhibiting excellent sensitivity with the detection limit of 0.01 μm. The plain dots could be recovered by adding ATP due to high affinity of the ATP for Fe<sup>3+</sup> through Fe−O−P bonds. This meant a “turn-on” fluorescent ATP sensor was also developed with a limit detection calculated to be 0.005 μm. 

Another example of the use of biomass derived dots as a sensor has been reported recently by Jiang et al.<sup>151</sup> that followed a hydrothermal method for synthesizing nitrogendoped carbon quantum dots that used ginkgo leaves as a carbon source. The dots had strong blue fluorescence, excitation-relevant emissions, high monodispersivity, good stability, good water solubility, and a quantum yield of 22.8%. The size of the dots was 3 nm, and they have maximum excitation and emission wavelengths of 350 and 436 nm, respectively. They were used as an effective fluorescent sensing platform for the label-free sensitive detection of salazosulfapyridine (SASP) due to the strong quenching effect of SASP and were successfully applied to detect SASP in mouse plasma. The detection of SASP is important for the management of inflammatory bowel disease, Crohn’s disease, and ulcerative colitis treatment.<sup>152</sup> This is a great synthesis with a high quantum yield at 22.8% due to doping. It is explained that the ginkgo leaves produce carbon products at high yields, yet the yield for CDs goes unreported. Reporting of the yield and an explanation as to why ginkgo leaves give high yields would improve this paper dramatically. Comparing this paper to the ones outlined above, this paper did not report a recovery method to obtain plain dots after they had been used to detect SASP, while the others did. The ability to recover the dots after use is greener and more economical for applications. Further research in this is definitely needed. 

The sensors outlined above are just a few examples of the wide range of applications of biomass derived carbons dots. The impact that high-quality sensors can have can improve people’s lives both in the body and out in the environment. Better detection methods mean that problems can be detected earlier and easier and can be addressed more efficiently. This has an impact on savings in economic terms, environmental terms, and life. 

Bioimaging. Due to their better biocompatibility compared to those that are derived from chemical synthesis, biomass derived quantum dots are considered an appropriate option for biomedical applications. Other properties that make them ideal for bioimaging applications are small size, high water solubility, photostability, and resistance to photobleaching.<sup>31</sup> 

There are numerous examples of biomass derived CDs being used as an imaging agent. Yang et al.<sup>153</sup> synthesized amino functionalized fluorescent CDs from chitosan in a one-step hydrothermal carbonization at a mild temperature. They were used to image a human lung adenocarcinoma A549 cells. They showed low cytotoxicity and excellent biocompatibility but with low yield (7.8%) and quantum yield (up to 43%). 

Another example has been reported by Jiang et al.<sup>141</sup> extracting CDs from coffee powder using centrifugation and filtration. The CDs showed strong PL, excitation-dependent emissions, up-conversion PL, excellent pH stability, and low cytotoxicity. The dots were used to image both carcinoma cells and a small guppy fish which stayed alive within the period of observation (Figure 8 A). 

Finally, Sun et al.<sup>134</sup> used a one-step sulfuric acid carbonization approach on human hair fiber to produce 

15489 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 



Figure 8. Examples of bioimaging using biomass derived CDs. (A) Live guppy fish. Reprinted with permission from ref 141. Copyright 2014 Elsevier B.V. (B) HeLa cells. Reprinted with permission from ref 134. Copyright 2013 Elsevier B.V. 



Figure 9. (Left) Imaging of a live nematode. Reprinted with permission from ref 154. Copyright 2021 Elsevier B.V. (Right) Imaging of live zebra danio fry. Reprinted with permission from ref 155. Copyright 2020 Elsevier B.V. 

nitrogen and sulfur codoped CDs on a large scale. The dots obtained showed good luminescence stability, low toxicity when tested with HeLa cells, (Figure 8B), and high solubility in water and organic solvents, which meant they were a good candidate for bioimaging. In terms of procedure for their synthesis, the authors reported the production yield of the dots at three different reaction temperatures were 40 °C = 9%, 100 °C = 16%, 140 °C = 9%, with the dots with highest quantum yield at 11.1% were the ones prepared at 40 °C. Therefore, the temperature has a strong impact on quantum yield and production yield and represents a process parameter that should be always considered in the dot synthesis. 

The selection of appropriate bioimaging agents is fundamental for enhancing better diagnostics and treatments for many diseases, such as cancer diagnosis and surgery which can improve patient survival rates and experience. The research proposed by the authors proposed a fascinating example of live imaging. However, the production yield from weight of coffee powder was approximately 2%, but the proposed methods did not need high heat and intense pressure, thus scale up could still be a possibility. 

More recently, Atchudan et al.<sup>154</sup> used carbon quantum dots from banana peels for the in vivo bioimaging of a nematode. The synthesis progressed using a hydrothermal method, and the dots were obtained by filtration and freeze-drying. The dots were successfully used to image live nematodes (Figure 9), and different concentrations were tested from 0−200 μm mL<sup>−1</sup> . The nematodes showed a slight decrease in viability of <5%. This showed that the dots had good biocompatibility. This 

paper is a great example of in vivo imaging and a good example of a simple hydrothermal synthesis that does not use any harsh chemicals or complex purification process. The synthesis pathway has been outlined, which is good, but an in-depth mechanism would really elevate this paper further. The production yield of the dots has been omitted. This is required to understand how efficient this method is and if it is viable for scale up. 

Another recent example outlined by Kim et al.<sup>155</sup> is a synthesis of CDs from a marine polysaccharide derived from shark cartilage using a hydrothermal method. These dots were used to image zebra danio fry (Figure 9). This paper is a good example of in vivo imaging using CDs but there are issues relating to the synthesis. First, the choice of starting material could be a lot greener by selecting from a waste stream rather than an expensive chemical purified from shark cartilage. Shark populations around the world are in steep decline with a 70% decrease in shark populations in the last 50 years.<sup>156</sup> Products from sharks should not be used, and other sources of this chemical should be considered, if not replacing with a different, greener, carbon source entirely. Second, the purification process for the dots is a very long four-step process that uses chloroform, which is an organic solvent and not considered green. Further work should be done to reduce the amount of purification this method needs and to eliminate the use of organic solvents. 

Drug Carriers. A lot of the properties that make biomass derived CDs good for bioimaging also make them good candidates for drug delivery, such as great surface area, 

15490 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 



Figure 10. Two release pathways of DOX from the CDs in a cancer cell. Adapted with permission from ref 157. Copyright 2017 Elsevier B. V. 



Figure 11. Release of boldine from CDs into a cancer cell. 

enhanced cellular uptake, and easy conjugation with therapeutics in addition to high biocompatibility.<sup>146</sup> 

An example of biomass derived CDs being used as drug delivery agent has been proposed by Yuan et al.,<sup>157</sup> where they used a hydrothermal treatment of milk to produce CDs and then conjugated with DOX through electrostatic interactions from surface functional groups. The drug carrier complex showed a pH-dependent release behavior, significant toxicity to 

carcinoma cells compared to free DOX and less toxic toward healthy mouse fibroblast cells (Figure 10). 

However, neither yield nor quantum yield values were reported. Another consideration is the raw materials for the synthesis of the biomass derived dots, because for scaling-up the methods, it would likely be cow’s milk, as that is the most prevalent throughout the world.<sup>158</sup> Cow’s milk production in general is environmentally damaging with greenhouse gas 

15491 

https://doi.org/10.1021/acsnano.1c03886 

ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

production from the cows and from feed and is responsible for 1.39 kg of CO2 equivalents to the atmosphere for every liter produced.<sup>159</sup> 

Another example of pH-based release drug delivery system was investigated by Bayda et al.<sup>160</sup> They synthesized CDs from black tea using carbonization through a hydrolysis method and then simple heating, followed by oxidization by HNO3. The dots had a narrow size distribution, tunable optical properties, nontoxic, and with an easy synthesis suitable for large scale. They were shown to be able to label subcellular structures, avoid lysosomal detection, and distribute themselves into cytoplasm to release DOX with better efficacy as the free drug. The release of the drug was controlled by low pH, like in a tumor microenvironment. A high yield was reported (26%). 

Furthermore, acidification was used as a release method by D’Souza et al.<sup>161</sup> They synthesized N-doped CDs from dried shrimps via hydrothermal treatment at 170 °C for 12 h. The dots were used as a traceable drug delivery system for the targeted delivery of boldine to human breast cancer cells. Boldine was taken up by the cancer cells and stored in vesicles. The release of boldine from the vesicles was controlled by acidification (Figure 11). 

There was an increase in the uptake of the boldine-loaded fluorescent CDs by the cancer cells. The synthesized blank CDs were also shown to have potential applications in bioimaging and related fields, particularly for the imaging of human neuroblastoma cells. The quantum yield of 54% represented a high value due to the auto doping of the dots. Another advantage of this method is associated with the dried shrimp that are a good carbon source with no need for an additional nitrogen source for doping. However, production yield was not reported, so scale up efficiency is impossible to predict. 

In conclusion, the biomass derived CDs can have an incredible impact as a drug delivery method in order to design smart treatments for disease such as cancer with fewer side effects. In particular, the platform can directly deliver the drug to the target tissue, reducing the interaction with other nontarget tissues, thus reducing the side effects and increasing the potency of the drug. 

Electrical Applications. Another application of biomass derived quantum dots is in the electrical area. The dots have shown great promise in energy applications, such as photovoltaic devices, batteries, and supercapacitors because of their properties, such as large surface area, good electrical conductivity, tunable luminescence, decreased chemical impedance, and tunable bandgap.<sup>25</sup> CDs used as supercapacitors were described by Hoang et al.<sup>162</sup> The CDs were synthesized from zucchini waste as an inexpensive carbon source using a low-cost synthetic route. The zucchini was selected for its porous nature and the presence of natural carbon and oxygen as well as the low cost. The CDs were hydrothermally reacted with graphene oxide to create a 3D porous reduced graphene oxide forming CD composites. These compounds were then reduced by hydrogen iodide vapor. The CDs acted as a spacer to hinder the restacking of the graphene nanosheets; the hydrogen iodide treatment deoxygenated the composites to improve conductivity and dope heteroatoms in graphene. It was found that the optimal mass loading of the composites was 33 wt % at a 10 min reduction time. The specific capacitance retention of this composite was 71.7%. The authors had also demonstrated the development of a sustainable supercapacitor from agricultural 

waste, but without specifying the application of this supercapacitor and the percentage yield, so scale-up feasibility cannot be confirmed. 

A cheaper alternative to expensive Pt catalysts by using the biomass derived CDs has been reported by Li et al.<sup>163</sup> They used gingko leaves to synthesize nitrogen-doped CDs via a hydrothermal method, which were then functionalized with ruthenium with another hydrothermal reaction with RuCl3. The resulting complex went through a pyrolysis to synthesize an electrocatalyst for a hydrogen evolution reaction. The yield of the CDs was reported at 21.7%, showing the scale-up feasibility of the procedure. 

Chemical Carbon Dots versus Biomass Derived Carbon Dots. Table 8 compares biomass derived CDs and chemically derived CDs in applications with advantages and disadvantages of each method. 

Each section in Table 8 clearly shows that the methods using biomass derived dots are the greenest and, in some cases, better than the ones that are based on chemical CDs. In the Sensors section, both biomass syntheses were green with use of biomass from waste and water. The first synthesis was the best because the method was extremely simple, and the dots were auto doping because of careful selection of biomass which caused a high quantum yield. 

The greenest method in the Bioimaging section is the microwave synthesis which is carried out in water producing dots with good properties. The dots with the best properties, such as a quantum yield of 41%, were from the method that used waste rice as a carbon source. Despite this, the method cannot be considered 100% green as multiple steps were required and chemicals such as acetone, NaBH4, and glutathione were used. 

In the Drug Carriers section, none of the methods outlined can be considered 100% green. However, the use of biomass such as sugar cane without harsh chemicals, and a simple method such as the citric acid synthesis, can increase the greenness of a synthesis. The system which is best for application is the conjugation of the black and gel CDs because it can be used to deliver drug to both bones and through the blood brain barrier, unfortunately the method is long and harsh and has a low production yield; this needs to be improved before widescale use. This method could be investigated further to make it more green by using biomass precursors for either the black or gel CDs. 

The best synthesis approach for electrochemical applications is using cauliflower leaves as a carbon source because the method is green and the properties are the best for supercapacitors such as a high capacitance 278 F g<sup>−1</sup> . The other methods outlined in this section are less green, and the properties of the dots are either just as good or worse than the cauliflower method. 

In summary, it is clear to see that biomass derived, or greener syntheses of CDs, often result in dots that are better than their chemical counterparts. In the future, greener synthesis techniques, such as choosing biomass as a carbon source, will be the go to method for synthesizing CDs. The Future Perspectives section fully outlines which areas of research are most in need of focus to bring biomass derived CDs to the forefront in the quantum dot field. 

### FUTURE PERSPECTIVES 

One of the biggest challenges described in previous sections is associated with a low (or not reported) production yield. The 

15492 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

|advantages<br>disadvantages<br>ref<br>very simple synthesis<br>no outline of yield<br>to evaluate scale<br>up<br>164<br>further application in<br>bioimaging and fluo-<br>rescent ink<br>high quantum yield<br>tunable by changing re-<br>action time and tem-<br>perature<br>good recovery after use<br>(94−108%)<br>complex purifica-<br>tion<br>165<br>high selectivity and sen-<br>sitivity<br>no outline of yield<br>to evaluate scale<br>up<br>ACS Nano|fairly low quantum<br>yield<br>dual emission<br>need to be com-<br>bined with cur-<br>cumin to detect<br>F−<br>166<br>low detection limit and<br>high selectivity<br>chemical carbon<br>sources<br>separate sources<br>needed for dop-<br>ing<br>biomass carbon source<br>long synthesis with<br>a double complex<br>purification<br>167<br>high quantum yield<br>chemicals used<br>such as acetone<br>and HNO3<br>tuned emission with pH<br>production yield<br>not outlined<br>highly luminescent<br>nontoxic and high bio-<br>compatibility<br>biomass carbon source<br>claims microwave<br>method im-<br>proved produc-<br>tion yield but<br>does not outline<br>it.<br>168<br>no extra chemicals used<br>complex purifica-<br>tion<br>multicolor imaging<br>nontoxic and high bio-<br>compatibility<br>excitation-dependent<br>emission<br>application in antioxi-<br>dant activity<br>www.acsnano.org<br>Review|
|---|---|
|ived CDs and Chemically Derived CDs in Applications<br>synthesis<br>properties<br>hydrothermal treatment followed by filtration<br>average particle size of 3.8 nm.<br>quantum yield of 29%<br>blue, green, and yellow emissions: 472, 509,<br>and 565 nm, respectively<br>low cytotoxicity<br>excitation wavelength range 467−543 nm<br>drying hydrothermal treatment followed by filtration, centrifugation and then<br>dialysis<br>size distribution between 1.32 and 4.87 nm<br>quantum yields between 4.29 and 8.13%|blue emissions: 445−435 nm<br>excitation wavelength range: 360 nm and 345<br>nm<br>sonication hydrothermal treatment, followed by filtration and dialysis<br>distribution 1−5 nm, a mean value of<br>approximately 2.5 nm<br>quantum yields of 12 and 33% for yellow and<br>blue emissions respectively<br>blue emissions: 400 nm; yellow emission: 552<br>nm<br>excitation wavelength: blue, 340 nm; yellow,<br>500 nm<br>powdered rice was carbonized in a muffle furnace and purified with acetone;<br>the supernatant was centrifuged then filtered then dialyzed<br>average particle size of ∼2−5 nm<br>prepared dots were the reduced with NaBH4 and then reacted with<br>glutathione then purified again with centrifugation, filtration, and dialysis<br>quantum yield of 41%<br>blue emissions in aqueous solution at 365 nm<br>excitation wavelength: blue, 345 nm<br>babul seed powered was mixed with water and carbonized using a microwave<br>oven; the dots are obtained and purified by centrifugation, filtration, and<br>dialysis<br>average particle size of 4.67 ± 0.60 nm<br>quantum yield of 9.5%<br>blue, green, and red emissions under the<br>excitation wavelengths of 408, 488, and 561<br>nm, respectively, in imaging|
|Table 8. Comparison of Biomass Der<br>application<br>dots<br>sensors<br>N-doped GQDs from passion fruit<br>for sensing Ag+ (biomass)<br>dots from various biomass including<br>orange peel, ginkgo biloba leaves,<br>paulownia leaves and magnolia<br>flower for the sensing of Fe3+<br>(biomass)|chemical CDs for sensing of F−from<br>selenourea, diaminopyridine<br>(chemical)<br>bioimaging<br>glutathione functionalized CDs from<br>white rice waste; dots were used<br>to image bothin vivo(mouse) and<br>in vitro (human lung cancer A549<br>cells) (biomass)<br>carbon dots synthesized from babul<br>seed powder for multicolor imag-<br>ing (biomass)|



15493 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

|disadvantages<br>ref<br>low quantum yield<br>in water<br>169<br>complex purifica-<br>tion<br>ACS Nano|use of solvents<br>chemical precursor<br>complex purifica-<br>tion<br>170<br>use of solvents<br>chemical precursor<br>harsh synthesis<br>with acid<br>low quantum yield<br>of conjugates<br>chemical precursor<br>171<br>low quantum yield<br>long synthesis with<br>multiple steps<br>and high temper-<br>atures<br>172<br>www.acsnano.org|use of strong acids<br>and bases<br>functionalization<br>decreases PL in-<br>tensity<br>chemical sources<br>173<br>Review|
|---|---|---|
|advantages<br>high quantum yield in<br>DMF<br>tunable emission by po-<br>larity|targetability both to mi-<br>tochondria and lyso-<br>some<br>excellent biocompatibil-<br>ity<br>conjugation of B-CDs<br>and G-CDs allows for<br>both bone targeting<br>and crossing of the<br>blood−brain barrier<br>yield of dots included<br>application in imaging−<br>tested with zebra<br>danio larvae<br>simple reaction and pu-<br>rification<br>enhanced toxicity of dox<br>to cancer cells<br>pH controlled release<br>application in imaging<br>biomass carbon source|simple purification<br>functionalization with<br>HAP gives better drug<br>loading capacity<br>simple purification|
|properties<br>average particle size of 5 nm spherical particle<br>R-CDs exhibited the highest quantum yield of<br>47.87% in DMF with a yellow color and a<br>lower quantum yield of 3.40% in water with<br>a red color|polarity-dependent emission from 400 to 500<br>nm<br>maximum excitation and emission wavelengths<br>ofB-GCDs at 325 and 504 nm, respectively<br>size distribution of 3.8 ± 0.8 nm<br>B-G CD conjugates quantum yield 98% <40%<br>of the G-CDs<br>conjugates have 54.4% increase of drug<br>capacity<br>quantum yield of 5%<br>average size of about 1.5 nm<br>excitation between 330 and 380 nm<br>emission 400−700 nm at 380 nm excitation<br>DOX loading was calculated at 70.37%<br>50% release in an acidic environment<br>size:|(1) CD-150, 2.27 ± 0.39<br>(2) CD-170, 3.94 ± 0.79<br>(3) CD-190, 4.72 ± 1.11<br>(4) CD-210, 2.66 ± 0.69<br>excellent biocompatibility<br>excitation of 405 nm<br>PL emission intensity at 192, 1229, 2285, and<br>1835 au at 150, 170, 190, and 210 °C,<br>respectively<br>GQDs//GQDs symmetric microsupercapaci-<br>tor: scan rate up to 1000 V s−1 small RC<br>time constant (103.6 μs), area specific<br>capacitor (468.1 μF cm−2), cycle stability in<br>0.5 M Na2SO4 aqueous solution|
|synthesis<br>p-phenylenediamine was dissolved in ethanol then sonicated; the solution<br>was subjected to heating in an autoclave and centrifuged, and precipitate<br>was collected and purified by column chromatography and dried under<br>vacuum|black CDs; HNO3, H2SO4, and carbon nanopowder were stirred and refluxed<br>in a sand bath; the dots were purified by triple filtration, concentration,<br>organic extraction, centrifugation, dialysis and rotary evaporation<br>gel CDs; EDA was reacted with citric acid under and argon atmosphere; the<br>dots were extracted by removal of unreacted EDA with acetone, and<br>vacuum evaporation was used to yield the dots<br>CDs were synthesized by hydrothermal route citric acid in distilled water was<br>autoclaved at 200 °C; the brown colloidal CQDs was centrifuged<br>CQDs were conjugated with TF by dispersing colloidal CDs in PBS, EDC<br>was added and then stirred, NHS was added and stirred, and transferrin in<br>PBS was added dropwise and stirred.<br>sugar cane bagasse in small pieces were burned in furnace then mixed with<br>sodium hydroxide, the liquid mixture was heated hydrothermally in for 24<br>h, and the precipitate was removed using vacuum filtration|CD-HAP was synthesized at room temperature by mixing calcium nitrate<br>tetrahydrate with CDs in HCL and diammonium hydrogen phosphate in<br>NaOH solution; HAP was yielded by vacuum filtration and drying<br>fabrication of GQDs: At first, graphite oxide (GO) was prepared by a<br>modified Hummers method. GQDs were synthesized from GO power<br>suspended in DMF the aid of ultrasound and heated in an autoclave and<br>then filtered. The dry GQDs powder was obtained by concentrating the<br>brown filter solution with a rotary evaporator|
|ntinued<br>dots<br>red emissive CDs with dual target-<br>ability for imaging polarity in<br>living cells (chemical)|direct conjugation of distinct CDs as<br>lego-like building blocks for the<br>assembly of versatile drug nano-<br>carriers (chemical)<br>DOX delivery to breast cancer cells<br>with transferrin-targeted carbon<br>quantum dots (chemical)<br>biowaste-derived CDs/hydroxyapa-<br>tite nanocomposite as drug deliv-<br>ery vehicle for acetaminophen<br>(biomass)|superior micro-supercapacitors<br>based on graphene quantum dots<br>(chemical)|
|Table 8. co<br>application|drug delivery|electrical ap-<br>plication|



15494 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

|disadvantages<br>ref|long synthesis total<br>production yield<br>not reported|chemical sources<br>174<br>long synthesis total<br>production yield<br>not reported|expensive materials<br>used<br>production yield<br>not reported<br>175|
|---|---|---|---|
|advantages||90% performance in-<br>crease from bare 3DG<br>electrodes<br>three devices made and<br>compared by changing<br>disposition time|biomass precursor<br>simple safe synthesis<br>green method<br>intrinsically doped|
|properties|GQDs//GQDs symmetric microsupercapaci-<br>tor: specific capacitor (1107.4 μF cm−2),<br>energy density (0.154 μWh cm−2)|capacitance of 268 F g−1<br>up to 1 V s−1 scan rate<br>conductivity of 3.7 S m−1|GQDs 2−5 nm in diameter<br>maximum discharge capacitance was 278 F g−1<br>at 0.2 A g−1 with capacitance retention of<br>60% and 63%<br>current density of 100 A g−1<br>scan rate up to 1000 mV s−1|
|synthesis|preparation of two kinds of micro-supercapacitors: GQDs//GQDs<br>symmetric microsupercapacitor and GQDs//MnO2 asymmetric micro-<br>supercapacitors was prepared by electrodeposition|GQDs were synthesized by electrolysis where a graphene rod was chosen for<br>an electrode. The Ag/AgCl electrode and a Pt wire were used as the<br>reference electrode and the counter-electrode, respectively. The dots were<br>purified by filtering and dialysis<br>these dots were decorated on to 3DG electrodes which was synthesized from<br>graphene oxide via HTC method; the 3DG was added to GQDs via an<br>electrolysis method|CDs were synthesized from cauliflower leaves via a hydrothermal method;<br>the dots were obtained by filtration, dialysis, and concentration<br>RGO/CD composites: Graphene oxide was synthesized by the Hummer’s<br>method; RGO/CD were synthesizedviaa hydrothermal treatment of CDs<br>added to a GO solution; composites were obtained through filtration,<br>washing, and vacuum freeze-drying|
|application<br>dots||graphene quantum dots: 3D gra-<br>phene composites for high-per-<br>formance supercapacitors (chem-<br>ical)|high efficiency supercapacitor de-<br>rived from biomass-based CDs<br>and reduced graphene oxide<br>composite (biomass)|



yield can be so low that it is impossible to isolate the dots in a solid form. Analysis is done in solution instead. Researchers should always be reporting yield or lack thereof, even if the yield is so low that it is impossible to quantify. They should also provide a reason as to why the yield is low. This enables those reading the articles to determine which syntheses need more work to improve yield of solid dots. Increasing yield will increase the viability for the biomass derived CDs use in application. Alongside the quantity, quality is also required. Optimization for efficient and large-scale production methods to synthesize high-quality CDs with small, uniform size, and high quantum yield is important. Having a uniform size means that the emission properties are uniform and have a narrower range, while high quantum yield will increase the brightness of the dots. Smaller size increases surface area for functionalization and allows them to be used in a greater range of application, especially in the human body. These properties are much better for application, especially in bioimaging. 

Another challenge to solve is the lack of full description of the optical properties. More research needs to be done to fully understand the mechanisms behind the PL within the different types of CDs and how they are controlled, for example, the effect of size, surface defects, and doping. To report mechanisms, researchers need to take samples periodically during synthesis of CDs. Analysis of these samples will shed more light on what is happening during the synthesis and a mechanism can be proposed. More researchers need to describe the effect of changing synthesis parameters has on the physical and optical properties of the CDs. Reporting a range of dot properties with their respective synthesis conditions would help further outline the link between physical and optical properties. A better understanding of PL mechanisms as well as a better understanding of the link between physical properties and optical properties will enable synthesis of dots that have better optical properties that will be able to be tuned to their specific application. 

Biomass derived CDs are already moving toward to being considered green with some syntheses already claiming the green label. Future synthesis should always strive to incorporate as many of the green principles as possible. This should include choosing biomass from waste streams to prevent waste going into disposal and prevent something new being created for use as a carbon or heteroatom source in synthesis. The syntheses should also be efficient in terms of both atom economy and reduction waste from the reaction and in energy. Nonhazardous and inherently benign chemistry should be used in the synthesis, which also facilitates both accident prevention and product toxicity. Ensuring that future synthesis is forward looking and as green as possible will make biomass derived CDs the most viable solution for many applications for a longer period. 

Because biomass derived CDs have been seen working in both drug delivery and targeted imaging, it stands to reason that biomass derived CDs are great candidates in the nanotheranostics field, that is, integration of an imaging agent with nanoscale drug delivery.<sup>176</sup> To fully explore the concept of biomass derived CDs used in this nanomedicine area, more assessment needs to be done on the different types of therapeutics, such as drugs, nucleic acids and antibodies, that can be loaded on CDs and evaluating their performance in vivo. In bioimaging, more research needs to be done to enhance a precise and efficient targeting of the nucleus and cellular organelles such as Golgi body and mitochondria. This 

15495 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

will increase the biomass derived CDs feasibility for applications in different streams of the nanomedicine. Moreover, the application of biomass derived CDs in vivo and ex vivo models is still absent. So far, there has been no application of biomass derived CDs implanted in vivo in human models. This is simply because the technology for this kind of detection still lacks the ability to be used for in vivo in human applications. Lu et al.<sup>177</sup> state that “imaging that operates in the visible region hampers the high-performance in vivo optical imaging due to the strong tissue absorption and scattering”. This means that it would be difficult to image a lot of areas in the human body currently because it is too deep; the tissues absorb or scatter the light before it gets a chance to be detected. This explains why most instances of fluorescent imaging have only been used on model cells and some small animals; such as fish.<sup>141</sup> This was clearly outlined in a review by Chen et al.,<sup>178</sup> where the penetration of light in the from UV to NIR though skin was reported to be in a range of 0.1−3 mm. penetration increased with wavelength. 

Therefore, advanced research is needed for long-term bioimaging by tuning the biomass derived CDs for higher intracellular photostability in deep tissue imaging along with better detection methods and technology for fluorescent imaging. As well as more research, both the engineering and natural sectors of this research need to work together more closely to improve the fluorescent imaging technology for application in bioimaging. Advancement in this technology could help nanomedicine in treating cancer and other illnesses by using both photodynamic and photothermal therapies. 

Increasing research for application of biomass derived CDs as sensors could allow the investigation of their potential use in more important sensing areas such as global security, radiation prevention, early detection of diseases, and safety of public utilities. To make biomass derived CDs more viable for application as sensors, research needs to be placed on the selectivity of the dots. 

The last area of research that needs more attention is the photocatalysis. Increased research here will help increase understanding the mechanisms of how the dots are involved into the catalysis and create more applications for them in the catalyst field, which will increase efficiency of chemical processes and could have positive economic and environmental impacts. It is obvious that more research is needed to develop biomass derived CDs into application, but even with the current research, they are the next-generation material among carbon structures. 

### AUTHOR INFORMATION 

#### Corresponding Authors 

- Piergiorgio Gentile − School of Engineering, Newcastle University, Newcastle upon Tyne NE1 7RU, United Kingdom; orcid.org/0000-0002-3036-6594; Email: piergiorgio.gentile@ncl.ac.uk 

- Anh N. Phan − School of Engineering, Newcastle University, Newcastle upon Tyne NE1 7RU, United Kingdom; orcid.org/0000-0002-1424-3826; Email: anh.phan@ 

- newcastle.ac.uk 

#### Author 

- Thomas C. Wareing − School of Engineering, Newcastle University, Newcastle upon Tyne NE1 7RU, United Kingdom 

- Complete contact information is available at: 

https://pubs.acs.org/10.1021/acsnano.1c03886 

#### Author Contributions 

> †These authors contributed equally. 

Notes 

The authors declare no competing financial interest. 

### ACKNOWLEDGMENTS 

The authors would like to thank EPSRC for financial support (EPSRC grant EP/R51309X/1). 

### VOCABULARY 

Quantum yield, the measure of the efficiency of photon emission as defined by the ratio of the number of photons emitted to the number of photons absorbed; quantum confinement, a change of properties in a material due to electrons and electron holes being squeezed together because the dimensions of the material are smaller than the exciton Bohr radius; semiconductor, a solid substance that has a conductivity between that of an insulator and that of most metals, either due to the addition of an impurity or because of temperature effects; photoluminescence, light emission from any form of matter after the absorption of photons; it is one of many forms of luminescence and is initiated by photoexcitation; bottom-up synthesis, an approach where the building blocks are added onto the substrate to form the nanostructures; top-down synthesis, an approach where the building blocks are removed from the substrate to form the nanostructure 

### REFERENCES 

(1) Geszke-Moritz, M.; Moritz, M. Quantum Dots as Versatile Probes in Medical Sciences: Synthesis, Modification and Properties. Mater. Sci. Eng., C 2013, 33 (3), 1008−1021. 

(2) Lommens, P.; Loncke, F.; Smet, P. F.; Callens, F.; Poelman, D.; Vrielinck, H.; Hens, Z. Dopant Incorporation in Colloidal Quantum Dots: A Case Study on Co2+ Doped ZnO. Chem. Mater. 2007, 19 (23), 5576−5583. 

(3) Nave, R. Semicondutor Band Gaps. http://hyperphysics.phyastr.gsu.edu/hbase/Solids/bandgap.html (accessed 2020-09-25). 

(4) Walling, A. M.; Novak, A. J.; Shepard, J. R. E. Quantum Dots for Live Cell and in Vivo Imaging. Int. J. Mol. Sci. 2009, 10 (2), 441−491. 

(5) Villamena, F. A. Fluorescence Technique. In Reactive Species Detection in Biology; Villamena, F. A., Ed.; Elsevier: Boston, 2017; pp 87−162. 

(6) Hines, M. A.; Guyot-Sionnest, P. Synthesis and Characterization of Strongly Luminescing ZnS-Capped CdSe Nanocrystals. J. Phys. Chem. 1996, 100 (2), 468−471. 

(7) Moriyasu, T.; Kinan, A.; Baba, Y.; Kumakura, M. Emission Spectral Change of CdSe/ZnS Quantum Dots Caused by the Dilution with Organic Solvents. J. Lumin. 2020, 221, 117089. 

(8) Reshma, V. G.; Mohanan, P. V. Quantum Dots: Applications and Safety Consequences. J. Lumin. 2019, 205, 287−298. 

(9) Geoffrion, L. D.; Guisbiers, G. Quantum Confinement: Size on the Grill! J. Phys. Chem. Solids 2020, 140, 109320. 

(10) Rosenthal, S. J.; Chang, J. C.; Kovtun, O.; McBride, J. R.; Tomlinson, I. D. Biocompatible Quantum Dots for Biological Applications. Chem. Biol. 2011, 18 (1), 10−24. 

(11) Han, M.; Gao, X.; Su, J. Z.; Nie, S. Quantum-Dot-Tagged Microbeads for Multiplexed Optical Coding of Biomolecules. Nat. Biotechnol. 2001, 19 (7), 631−635. 

(12) Watson, A.; Wu, X.; Bruchez, M. Lighting Up Cells with Quantum Dots. BioTechniques 2003, 34 (2), 296−300. 

15496 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

(13) Ballou, B.; Lagerholm, B. C.; Ernst, L. A.; Bruchez, M. P.; Waggoner, A. S. Noninvasive Imaging of Quantum Dots in Mice. Bioconjugate Chem. 2004, 15 (1), 79−86. 

(14) Wagner, A. M.; Knipe, J. M.; Orive, G.; Peppas, N. A. Quantum Dots in Biomedical Applications. Acta Biomater. 2019, 94, 44−63. (15) Pidluzhna, A.; Ivaniuk, K.; Stakhira, P.; Hotra, Z.; Chapran, M.; Ulanski, J.; Tynkevych, O.; Khalavka, Y.; Baryshnikov, G. V.; Minaev, B. F.; Ågren, H. Multi-Channel Electroluminescence of CdTe/CdS Core-Shell Quantum Dots Implemented into a QLED Device. Dyes Pigm. 2019, 162, 647−653. 

(16) He, L.; Fei, M.; Chen, J.; Tian, Y.; Jiang, Y.; Huang, Y.; Xu, K.; Hu, J.; Zhao, Z.; Zhang, Q.; Ni, H.; Chen, L. Graphitic C3N4 Quantum Dots for Next-Generation QLED Displays. Mater. Today 2019, 22, 76−84. 

(17) Caires, A. J.; Mansur, A. A. P.; Carvalho, I. C.; Carvalho, S. M.; Mansur, H. S. Green Synthesis of ZnS Quantum Dot/Biopolymer Photoluminescent Nanoprobes for Bioimaging Brain Cancer Cells. Mater. Chem. Phys. 2020, 244, 122716. 

(18) Sarma, R.; Mohanta, D. Luminescence and Bio-imaging Response of Thio-Glycolic Acid (TGA) and Sodium Dodecyl Sulfate (SDS)-Coated Fluorescent Cadmium Selenide Quantum Dots. J. Lumin. 2015, 161, 395−402. 

(19) Xu, N.; Piao, M.; Arkin, K.; Ren, L.; Zhang, J.; Hao, J.; Zheng, Y.; Shang, Q. Imaging of Water Soluble CdTe/CdS Core-Shell Quantum Dots in Inhibiting Multidrug Resistance of Cancer Cells. Talanta 2019, 201, 309−316. 

(20) Tian, L.-J.; Zhou, N.-Q.; Liu, X.-W.; Liu, J.-H.; Zhang, X.; Huang, H.; Zhu, T.-T.; Li, L.-L.; Huang, Q.; Li, W.-W.; Liu, Y.-Z.; Yu, H.-Q. A Sustainable Biogenic Route to Synthesize Quantum Dots with Tunable Fluorescence Properties for Live Cell Imaging. Biochem. Eng. J. 2017, 124, 130−137. 

(21) Wu, X.; Liu, H.; Liu, J.; Haley, K. N.; Treadway, J. A.; Larson, J. P.; Ge, N.; Peale, F.; Bruchez, M. P. Immunofluorescent Labeling of Cancer Marker Her2 and Other Cellular Targets with Semiconductor Quantum Dots. Nat. Biotechnol. 2003, 21 (1), 41−46. 

(22) Wang, Z.; Tang, M. The Cytotoxicity of Core-Shell or NonShell Structure Quantum Dots and Reflection on Environmental Friendly: A Review. Environ. Res. 2021, 194, 110593. 

(23) Zhu, C.; Chen, Z.; Gao, S.; Goh, B. L.; Samsudin, I. B.; Lwe, K. W.; Wu, Y.; Wu, C.; Su, X. Recent Advances in Non-Toxic Quantum Dots and Their Biomedical Applications. Prog. Nat. Sci. 2019, 29 (6), 628−640. 

(24) Das, R.; Bandyopadhyay, R.; Pramanik, P. Carbon Quantum Dots from Natural Resource: A Review. Materials Today Chemistry 2018, 8, 96−109. 

(25) Abbas, A.; Mariana, L. T.; Phan, A. N. Biomass-Waste Derived Graphene Quantum Dots and Their Applications. Carbon 2018, 140, 77−99. 

(26) Liu, H.; Ding, J.; Zhang, K.; Ding, L. Construction of Biomass Carbon Dots Based Fluorescence Sensors and Their Applications in Chemical and Biological Analysis. TrAC, Trends Anal. Chem. 2019, 118, 315−337. 

(27) Namdari, P.; Negahdari, B.; Eatemadi, A. Synthesis, Properties and Biomedical Applications of Carbon-Based Quantum Dots: An Updated Review. Biomed. Pharmacother. 2017, 87, 209−222. 

(28) Shen, L.-M.; Liu, J. New Development in Carbon Quantum Dots Technical Applications. Talanta 2016, 156−157, 245−256. 

(29) Devi, P.; Saini, S.; Kim, K.-H. The Advanced Role of Carbon Quantum Dots in Nanomedical Applications. Biosens. Bioelectron. 2019, 141, 111158. 

(30) Tian, P.; Tang, L.; Teng, K. S.; Lau, S. P. Graphene Quantum Dots from Chemistry to Applications. Materials Today Chemistry 2018, 10, 221−258. 

(31) Tejwan, N.; Saha, S. K.; Das, J. Multifaceted Applications of Green Carbon Dots Synthesized from Renewable Sources. Adv. Colloid Interface Sci. 2020, 275, 102046. 

(32) Pierrat, P.; Gaumet, J.-J. Graphene Quantum Dots: Emerging Organic Materials with Remarkable and Tunable Luminescence Features. Tetrahedron Lett. 2020, 61 (49), 152554. 

(33) Nair, A.; Haponiuk, J. T.; Thomas, S.; Gopi, S. Natural CarbonBased Quantum Dots and Their Applications in Drug Delivery: A Review. Biomed. Pharmacother. 2020, 132, 110834. 

(34) Fan, H.; Zhang, M.; Bhandari, B.; Yang, C.-h. Food Waste as a Carbon Source in Carbon Quantum Dots Technology and Their Applications in Food Safety Detection. Trends Food Sci. Technol. 2020, 95, 86−96. 

(35) Ghosh, D.; Sarkar, K.; Devi, P.; Kim, K.-H.; Kumar, P. Current and Future Perspectives of Carbon and Graphene Quantum Dots: From Synthesis to Strategy for Building Optoelectronic and Energy Devices. Renewable Sustainable Energy Rev. 2021, 135, 110391. 

(36) Zuo, P.; Lu, X.; Sun, Z.; Guo, Y.; He, H. A Review on Syntheses, Properties, Characterization and Bioanalytical Applications of Fluorescent Carbon Dots. Microchim. Acta 2016, 183 (2), 519− 542. 

(37) Xu, X.; Ray, R.; Gu, Y.; Ploehn, H. J.; Gearheart, L.; Raker, K.; Scrivens, W. A. Electrophoretic Analysis and Purification of Fluorescent Single-Walled Carbon Nanotube Fragments. J. Am. Chem. Soc. 2004, 126 (40), 12736−12737. 

(38) Lim, S. Y.; Shen, W.; Gao, Z. Carbon Quantum Dots and Their Applications. Chem. Soc. Rev. 2015, 44 (1), 362−381. 

(39) Dervishi, E.; Ji, Z.; Htoon, H.; Sykora, M.; Doorn, S. K. Raman Spectroscopy of Bottom-Up Synthesized Graphene Quantum Dots: Size and Structure Dependence. Nanoscale 2019, 11 (35), 16571− 16581. 

(40) Sciortino, A.; Cannizzo, A.; Messina, F. Carbon Nanodots: A ReviewFrom the Current Understanding of the Fundamental Photophysics to the Full Control of the Optical Response. C 2018, 4, 67. 

(41) Elvati, P.; Baumeister, E.; Violi, A. Graphene Quantum Dots: Effect of Size, Composition and Curvature on Their Assembly. RSC Adv. 2017, 7 (29), 17704−17710. 

(42) Wang, D.; Chen, J.-F.; Dai, L. Recent Advances in Graphene Quantum Dots for Fluorescence Bioimaging from Cells through Tissues to Animals. Particle & particle systems characterization 2015, 32 (5), 515−523. 

(43) Zhu, S.; Song, Y.; Wang, J.; Wan, H.; Zhang, Y.; Ning, Y.; Yang, B. Photoluminescence Mechanism in Graphene Quantum Dots: Quantum Confinement Effect and Surface/Edge State. Nano Today 2017, 13, 10−14. 

(44) Sk, M. A.; Ananthanarayanan, A.; Huang, L.; Lim, K. H.; Chen, P. Revealing the Tunable Photoluminescence Properties of Graphene Quantum Dots. J. Mater. Chem. C 2014, 2 (34), 6954−6960. 

(45) Zhu, X.; Li, Z.; Hu, G.; Li, J.; Xiang, B. The Effects of Various Molecular Weight of Passivator on the Photoluminescence Properties of Graphene Quantum Dots. Mater. Chem. Phys. 2021, 258, 123922. 

(46) Siddique, A. B.; Pramanick, A. K.; Chatterjee, S.; Ray, M. Amorphous Carbon Dots and Their Remarkable Ability to Detect 2,4,6-Trinitrophenol. Sci. Rep. 2018, 8 (1), 9770. 

(47) Georgakilas, V.; Perman, J. A.; Tucek, J.; Zboril, R. Broad Family of Carbon Nanoallotropes: Classification, Chemistry, and Applications of Fullerenes, Carbon Dots, Nanotubes, Graphene, Nanodiamonds, and Combined Superstructures. Chem. Rev. 2015, 115 (11), 4744−4822. 

(48) Lim, C. S.; Hola, K.; Ambrosi, A.; Zboril, R.; Pumera, M. Graphene and Carbon Quantum Dots Electrochemistry. Electrochem. Commun. 2015, 52, 75−79. 

(49) Deng, Y.; Zhao, D.; Chen, X.; Wang, F.; Song, H.; Shen, D. Long Lifetime Pure Organic Phosphorescence Based on Water Soluble Carbon Dots. Chem. Commun. 2013, 49 (51), 5751−5753. 

(50) Ehrat, F.; Bhattacharyya, S.; Schneider, J.; Löf, A.; Wyrwich, R.; Rogach, A. L.; Stolarczyk, J. K.; Urban, A. S.; Feldmann, J. Tracking the Source of Carbon Dot Photoluminescence: Aromatic Domains versus Molecular Fluorophores. Nano Lett. 2017, 17 (12), 7710−7716. 

(51) Luo, J.; Xie, Z.; Lam, J. W. Y.; Cheng, L.; Chen, H.; Qiu, C.; Kwok, H. S.; Zhan, X.; Liu, Y.; Zhu, D.; Tang, B. Z. AggregationInduced Emission of 1-Methyl-1,2,3,4,5-Pentaphenylsilole. Chem. Commun. 2001, 18, 1740−1741. 

15497 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

(52) Ge, M.; Han, Y.; Ni, J.; Li, Y.; Han, S.; Li, S.; Yu, H.; Zhang, C.; Liu, S.; Li, J.; Chen, Z. Seeking Brightness from Nature: Sustainable Carbon Dots-Based AIEgens with Tunable Emission Wavelength from Natural Rosin. Chem. Eng. J. 2021, 413, 127457. 

(53) Xiao, D.; Jiang, M.; Luo, X.; Liu, S.; Li, J.; Chen, Z.; Li, S. Sustainable Carbon Dot-Based AIEgens: Promising Light-Harvesting Materials for Enhancing Photosynthesis. ACS Sustainable Chem. Eng. 2021, 9 (11), 4139−4145. 

(54) Peng, H.; Travas-Sejdic, J. Simple Aqueous Solution Route to Luminescent Carbogenic Dots from Carbohydrates. Chem. Mater. 2009, 21 (23), 5563−5565. 

(55) Amer Ridha, A.; Pakravan, P.; Hemati Azandaryani, A.; Zhaleh, H. Carbon Dots; The Smallest Photoresponsive Structure of Carbon in Advanced Drug Targeting. J. Drug Delivery Sci. Technol. 2020, 55, 101408. 

(56) Sun, Y.-P.; Zhou, B.; Lin, Y.; Wang, W.; Fernando, K. A. S.; Pathak, P.; Meziani, M. J.; Harruff, B. A.; Wang, X.; Wang, H.; Luo, P. G.; Yang, H.; Kose, M. E.; Chen, B.; Veca, L. M.; Xie, S.-Y. QuantumSized Carbon Dots for Bright and Colorful Photoluminescence. J. Am. Chem. Soc. 2006, 128 (24), 7756−7757. 

(57) Kang, S.; Jeong, Y. K.; Ryu, J. H.; Son, Y.; Kim, W. R.; Lee, B.; Jung, K. H.; Kim, K. M. Pulsed Laser Ablation Based Synthetic Route for Nitrogen-Doped Graphene Quantum Dots Using Graphite Flakes. Appl. Surf. Sci. 2020, 506, 144998. 

(58) Nideep, T. K.; Ramya, M.; Nampoori, V. P. N.; Kailasnath, M. Optical Limiting and Optical Properties of Water Soluble CDTE Quantum Dots Prepared through a Colloidal Chemical Route. Optik 2019, 179, 1101−1108. 

(59) Cui, L.; Ren, X.; Wang, J.; Sun, M. Synthesis of Homogeneous Carbon Quantum Dots by Ultrafast Dual-Beam Pulsed Laser Ablation for Bioimaging. Materials Today Nano 2020, 12, 100091. 

(60) Yang, L. 5-Carbon Nanostructures: New Materials for Orthopedic Applications. In Nanotechnology-Enhanced Orthopedic Materials; Yang, L., Ed.; Woodhead Publishing: Oxford, 2015; pp 97−120. 

(61) Bottini, M.; Balasubramanian, C.; Dawson, M. I.; Bergamaschi, A.; Bellucci, S.; Mustelin, T. Isolation and Characterization of Fluorescent Nanoparticles from Pristine and Oxidized Electric ArcProduced Single-Walled Carbon Nanotubes. J. Phys. Chem. B 2006, 110 (2), 831−836. 

(62) Lu, J.; Yang, J.-x.; Wang, J.; Lim, A.; Wang, S.; Loh, K. P. OnePot Synthesis of Fluorescent Carbon Nanoribbons, Nanoparticles, and Graphene by the Exfoliation of Graphite in Ionic Liquids. ACS Nano 2009, 3 (8), 2367−2375. 

(63) An, Q.; Lin, Q.; Huang, X.; Zhou, R.; Guo, X.; Xu, W.; Wang, S.; Xu, D.; Chang, H.-T. Electrochemical Synthesis of Carbon Dots with a Stokes Shift of 309 nm for Sensing of Fe3+ and Ascorbic Acid. Dyes Pigm. 2021, 185, 108878. 

(64) Zong, J.; Zhu, Y.; Yang, X.; Shen, J.; Li, C. Synthesis of Photoluminescent Carbogenic Dots Using Mesoporous Silica Spheres as Nanoreactors. Chem. Commun. 2011, 47 (2), 764−766. 

(65) Yang, Y.; Wu, D.; Han, S.; Hu, P.; Liu, R. Bottom-up Fabrication of Photoluminescent Carbon Dots with Uniform Morphology via a Soft−Hard Template Approach. Chem. Commun. 2013, 49 (43), 4920−4922. 

(66) Guan, W.; Gu, W.; Ye, L.; Guo, C.; Su, S.; Xu, P.; Xue, M. Microwave-Assisted Polyol Synthesis of Carbon Nitride Dots from Folic Acid for Cell Imaging. Int. J. Nanomed. 2014, 9, 5071−5078. 

(67) Kwon, W.; Rhee, S.-W. Facile Synthesis of Graphitic Carbon Quantum Dots with Size Tunability and Uniformity Using Reverse Micelles. Chem. Commun. 2012, 48 (43), 5256−5258. 

(68) Pajewska-Szmyt, M.; Buszewski, B.; Gadzała-Kopciuch, R. Sulphur and Nitrogen Doped Carbon Dots Synthesis by Microwave Assisted Method as Quantitative Analytical Nano-Tool for Mercury Ion Sensing. Mater. Chem. Phys. 2020, 242, 122484. 

(69) Liu, Q.; Zhang, N.; Shi, H.; Ji, W.; Guo, X.; Yuan, W.; Hu, Q. One-Step Microwave Synthesis of Carbon Dots for Highly Sensitive and Selective Detection of Copper Ions in Aqueous Solution. New J. Chem. 2018, 42 (4), 3097−3101. 

(70) Fang, Y.; Guo, S.; Li, D.; Zhu, C.; Ren, W.; Dong, S.; Wang, E. Easy Synthesis and Imaging Applications of Cross-Linked Green Fluorescent Hollow Carbon Nanoparticles. ACS Nano 2012, 6 (1), 400−409. 

(71) Shen, L.; Zhang, L.; Chen, M.; Chen, X.; Wang, J. The Production of pH-Sensitive Photoluminescent Carbon Nanoparticles by the Carbonization of Polyethylenimine and Their Use for Bioimaging. Carbon 2013, 55, 343−349. 

(72) Liu, R.; Wu, D.; Liu, S.; Koynov, K.; Knoll, W.; Li, Q. An Aqueous Route to Multicolor Photoluminescent Carbon Dots Using Silica Spheres as Carriers. Angew. Chem., Int. Ed. 2009, 48 (25), 4598−4601. 

(73) Wang, B.; Mu, Y.; Zhang, H.; Shi, H.; Chen, G.; Yu, Y.; Yang, Z.; Li, J.; Yu, J. Red Room-Temperature Phosphorescence of CDs@ Zeolite Composites Triggered by Heteroatoms in Zeolite Frameworks. ACS Cent. Sci. 2019, 5 (2), 349−356. 

(74) Calabro, R. L.; Yang, D.-S.; Kim, D. Y. Liquid-Phase Laser Ablation Synthesis of Graphene Quantum Dots from Carbon NanoOnions: Comparison with Chemical Oxidation. J. Colloid Interface Sci. 2018, 527, 132−140. 

(75) Dey, S.; Govindaraj, A.; Biswas, K.; Rao, C. N. R. Luminescence Properties of Boron and Nitrogen Doped Graphene Quantum Dots Prepared from Arc-Discharge-Generated Doped Graphene Samples. Chem. Phys. Lett. 2014, 595−596, 203−208. 

(76) Hou, Y.; Lu, Q.; Deng, J.; Li, H.; Zhang, Y. One-Pot Electrochemical Synthesis of Functionalized Fluorescent Carbon Dots and Their Selective Sensing for Mercury Ion. Anal. Chim. Acta 2015, 866, 69−74. 

(77) Wen, Q.-L.; Pu, Z.-F.; Yang, Y.-J.; Wang, J.; Wu, B.-C.; Hu, Y.L.; Liu, P.; Ling, J.; Cao, Q. Hyaluronic Acid as a Material for the Synthesis of Fluorescent Carbon Dots and Its Application for Selective Detection of Fe3+ Ion and Folic Acid. Microchem. J. 2020, 159, 105364. 

(78) Xiong, H.-F.; An, B.-L.; Zhang, J.-M.; Yin, C.-l.; Wang, X.-H.; Wang, J.-H.; Xu, J.-Q. Efficient One Step Synthesis of Green Carbon Quantum Dots Catalyzed by Tin Oxide. Materials Today Communications 2021, 26, 101762. 

(79) Masha, S.; Oluwafemi, O. S. Synthesis of Blue and Green Emitting Carbon-Based Quantum Dots (CBQDs) and Their Cell Viability against Colon and Bladder Cancer Cell Lines. Mater. Lett. 2021, 283, 128790. 

(80) Yang, Z.; Liu, Y.; Lu, C.; Yue, G.; Wang, Y.; Rao, H.; Zhang, W.; Lu, Z.; Wang, X. One-Pot Synthesis of CeO2-Carbon Dots with Enhanced Peroxidase-Like Activity and Carbon Dots for Ratiometric Fluorescence Detection of H2O2 and Cholesterol. J. Alloys Compd. 2021, 862, 158323. 

(81) Liu, G.; Li, B.; Liu, Y.; Feng, Y.; Jia, D.; Zhou, Y. Rapid and High Yield Synthesis of Carbon Dots with Chelating Ability Derived from Acrylamide/Chitosan for Selective Detection of Ferrous Ions. Appl. Surf. Sci. 2019, 487, 1167−1175. 

(82) Mai, X.-D.; Thi Kim Chi, T.; Nguyen, T.-C.; Ta, V.-T. Scalable Synthesis of Highly Photoluminescence Carbon Quantum Dots. Mater. Lett. 2020, 268, 127595. 

(83) Xu, H.; Xie, L.; Hakkarainen, M. Coffee-Ground-Derived Quantum Dots for Aqueous Processable Nanoporous Graphene Membranes. ACS Sustainable Chem. Eng. 2017, 5 (6), 5360−5367. 

(84) Shen, T.-Y.; Jia, P.-Y.; Chen, D.-S.; Wang, L.-N. Hydrothermal Synthesis of N-Doped Carbon Quantum Dots and Their Application in Ion-Detection and Cell-Imaging. Spectrochim. Acta, Part A 2021, 248, 119282. 

(85) Rehman, M. Y. u.; Manzoor, S.; Nazar, N.; Abid, A. G.; Qureshi, A. M.; Chughtai, A. H.; Joya, K. S.; Shah, A.; Ashiq, M. N. Facile Synthesis of Novel Carbon Dots@Metal Organic Framework Composite for Remarkable and Highly Sustained Oxygen Evolution Reaction. J. Alloys Compd. 2021, 856, 158038. 

(86) Lu, D.; Yin, K.; Zhao, Y.; Gao, Z.; Godbert, N.; Li, H.; Li, H.; Hao, J. Facile Synthesis of Alkylated Carbon Dots with Blue Emission in Halogenated Benzene Solvents. Colloids Surf., A 2021, 613, 126129. 

15498 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

(87) Hu, R.; Li, L.; Jin, W. J. Controlling Speciation of Nitrogen in Nitrogen-Doped Carbon Dots by Ferric Ion Catalysis for Enhancing Fluorescence. Carbon 2017, 111, 133−141. 

(88) Zhou, J.; Shan, X.; Ma, J.; Gu, Y.; Qian, Z.; Chen, J.; Feng, H. Facile Synthesis of P-Doped Carbon Quantum Dots with Highly Efficient Photoluminescence. RSC Adv. 2014, 4 (11), 5465−5468. (89) Shan, X.; Chai, L.; Ma, J.; Qian, Z.; Chen, J.; Feng, H. B-Doped Carbon Quantum Dots as a Sensitive Fluorescence Probe for Hydrogen Peroxide and Glucose Detection. Analyst 2014, 139 (10), 2322−2325. 

(90) Ayala, P.; Arenal, R.; Loiseau, A.; Rubio, A.; Pichler, T. The Physical and Chemical Properties of Heteronanotubes. Rev. Mod. Phys. 2010, 82 (2), 1843−1885. 

(91) Zhang, L.; Zhang, Z.-Y.; Liang, R.-P.; Li, Y.-H.; Qiu, J.-D. Boron-Doped Graphene Quantum Dots for Selective Glucose Sensing Based on the “Abnormal” Aggregation-Induced Photoluminescence Enhancement. Anal. Chem. 2014, 86 (9), 4423−4430. 

(92) Kou, X.; Jiang, S.; Park, S.-J.; Meng, L.-Y. A Review: Recent Advances in Preparations and Applications of Heteroatom-Doped Carbon Quantum Dots. Dalton Transactions 2020, 49 (21), 6915− 6938. 

(93) Hu, Y.; Yang, J.; Tian, J.; Jia, L.; Yu, J.-S. Waste Frying Oil as a Precursor for One-Step Synthesis of Sulfur-Doped Carbon Dots with PH-Sensitive Photoluminescence. Carbon 2014, 77, 775−782. 

(94) Ma, X.; Li, S.; Hessel, V.; Lin, L.; Meskers, S.; Gallucci, F. Synthesis of N-Doped Carbon Dots via a Microplasma Process. Chem. Eng. Sci. 2020, 220, 115648. 

(95) Li, N.; Lei, F.; Xu, D.; Li, Y.; Liu, J.; Shi, Y. One-Step Synthesis of N, P Co-Doped Orange Carbon Quantum Dots with Novel Optical Properties for Bio-Imaging. Opt. Mater. 2021, 111, 110618. 

(96) Shi, C.; Qi, H.; Ma, R.; Sun, Z.; Xiao, L.; Wei, G.; Huang, Z.; Liu, S.; Li, J.; Dong, M.; Fan, J.; Guo, Z. N,S-Self-Doped Carbon Quantum Dots from Fungus Fibers for Sensing Tetracyclines and for Bioimaging Cancer Cells. Mater. Sci. Eng., C 2019, 105, 110132. 

(97) Molkenova, A.; Atabaev, T. S. Phosphorus-Doped Carbon Dots (P-CDs) from Dextrose for Low-Concentration Ferric Ions Sensing in Water. Optik 2019, 187, 70−73. 

(98) Chen, B. B.; Liu, M. L.; Li, C. M.; Huang, C. Z. Fluorescent Carbon Dots Functionalization. Adv. Colloid Interface Sci. 2019, 270, 165−190. 

(99) Yan, F.; Jiang, Y.; Sun, X.; Bai, Z.; Zhang, Y.; Zhou, X. Surface Modification and Chemical Functionalization of Carbon Dots: A Review. Microchim. Acta 2018, 185 (9), 424. 

(100) Dong, W.; Zhou, S.; Dong, Y.; Wang, J.; Ge, X.; Sui, L. The Preparation of Ethylenediamine-Modified Fluorescent Carbon Dots and Their Use in Imaging of Cells. Luminescence 2015, 30 (6), 867− 871. 

(101) Algarra, M.; Campos, B. B.; Radotić, K.; Mutavdozič ,́ D.; Bandosz, T.; Jiménez-Jiménez, J.; Rodriguez-Castellón, E.; Esteves da Silva, J. C. G. Luminescent Carbon Nanoparticles: Effects of Chemical Functionalization, and Evaluation of Ag+ Sensing Properties. J. Mater. Chem. A 2014, 2 (22), 8342−8351. 

(102) Jin, J.-C.; Wang, B.-B.; Xu, Z.-Q.; He, X.-H.; Zou, H.-F.; Yang, Q.-Q.; Jiang, F.-L.; Liu, Y. A Novel Method for the Detection of Silver Ions With Carbon Dots: Excellent Selectivity, Fast Response, Low Detection Limit and Good Applicability. Sens. Actuators, B 2018, 267, 627−635. 

(103) Ye, Z.; Tang, R.; Wu, H.; Wang, B.; Tan, M.; Yuan, J. Preparation of Europium Complex-Conjugated Carbon Dots for Ratiometric Fluorescence Detection of Copper(II) Ions. New J. Chem. 2014, 38 (12), 5721−5726. 

(104) Li, J.; Liu, J.; Xu, L.; Chen, J. Preparation of Thermoresponsive Fluorescent Carbon Dots for Cellular Imaging. Polym. Int. 2017, 66 (1), 92−97. 

(105) Lei, J.; Yang, L.; Lu, D.; Yan, X.; Cheng, C.; Liu, Y.; Wang, L.; Zhang, J. Carbon Dot-Incorporated PMO Nanoparticles as Versatile Platforms for the Design of Ratiometric Sensors, Multichannel Traceable Drug Delivery Vehicles, and Efficient Photocatalysts. Adv. Opt. Mater. 2015, 3 (1), 57−63. 

(106) Rao, H.; Liu, W.; Lu, Z.; Wang, Y.; Ge, H.; Zou, P.; Wang, X.; He, H.; Zeng, X.; Wang, Y. Silica-Coated Carbon Dots Conjugated to CdTe Quantum Dots: A Ratiometric Fluorescent Probe for Copper(II). Microchim. Acta 2016, 183 (2), 581−588. 

(107) Jiang, Y.; Wang, Z.; Dai, Z. Preparation of Silicon−CarbonBased Dots@Dopamine and Its Application in Intracellular Ag+ Detection and Cell Imaging. ACS Appl. Mater. Interfaces 2016, 8 (6), 3644−3650. 

(108) Guo, C. X.; Zhao, D.; Zhao, Q.; Wang, P.; Lu, X. NA+Functionalized Carbon Quantum Dots: A New Draw Solute in Forward Osmosis for Seawater Desalination. Chem. Commun. 2014, 50 (55), 7318−7321. 

(109) Jin, H.; Gui, R.; Wang, Y.; Sun, J. Carrot-Derived Carbon Dots Modified with Polyethyleneimine and Nile Blue for Ratiometric TwoPhoton Fluorescence Turn-On Sensing of Sulfide Anion in Biological Fluids. Talanta 2017, 169, 141−148. 

(110) Davi, L. B. O.; Silva, M. S.; Ferreira, R. L.; Muniz, W.; Ribeiro, A. S.; Lima, D. J. P.; de Oliveira, I. N.; Barbosa, C. D. A. E. S. Multifunctional Carbon Dots Derived from Dansyl Chloride for Ratiometric Thermal Sensor and Reactive Oxygen Generation. Dyes Pigm. 2021, 194, 109549. 

(111) Li, L.-p.; Ren, X.-f.; Bai, P.-r.; Liu, Y.; Xu, W.-y.; Xie, J.; Zhang, R.-p. Near-Infrared Emission Carbon Dots for Bio-Imaging Applications. New Carbon Materials 2021, 36 (3), 632−638. 

(112) Chang, Q.; Zhou, X.; Xiang, G.; Jiang, S.; Li, L.; Wang, Y.; Li, Y.; Cao, Z.; Tang, X.; Ling, F.; Luo, X. Full Color Fluorescent Carbon Quantum Dots Synthesized from Triammonium Citrate for Cell Imaging and White LEDs. Dyes Pigm. 2021, 193, 109478. 

(113) Li, Y.; Xiang, W.; Zhou, T.; Huang, M.; Wang, C.; Wu, X.; Mao, J.; Wang, P. Visible Light Induced Efficient Activation of Persulfate by a Carbon Quantum Dots (CQDs) Modified γ-Fe2O3 Catalyst. Chin. Chem. Lett. 2020, 31 (10), 2757−2761. 

(114) Song, J.; Liang, X.; Ma, Q.; An, J.; Feng, F. Fluorescent Boron and Nitrogen Co-Doped Carbon Dots with High Quantum Yield for the Detection of Nimesulide and Fluorescence Staining. Spectrochim. Acta, Part A 2019, 216, 296−302. 

(115) Yang, Z.; Gao, M.; Wu, W.; Yang, X.; Sun, X. W.; Zhang, J.; Wang, H.-C.; Liu, R.-S.; Han, C.-Y.; Yang, H.; Li, W. Recent Advances in Quantum Dot-Based Light-Emitting Devices: Challenges and Possible Solutions. Mater. Today 2019, 24, 69−93. 

(116) Yang, P.; Zhu, Z.; Li, X.; Zhang, T.; Zhang, W.; Chen, M.; Zhou, X. Facile Synthesis of Yellow Emissive Carbon Dots with High Quantum Yield and Their Application in Construction of Fluorescence-Labeled Shape Memory Nanocomposite. J. Alloys Compd. 2020, 834, 154399. 

(117) Park, S. Y.; Lee, H. U.; Park, E. S.; Lee, S. C.; Lee, J. W.; Jeong, S. W.; Kim, C. H.; Lee, Y. C.; Huh, Y. S.; Lee, J. Photoluminescent Green Carbon Nanodots from Food-WasteDerived Sources: Large-Scale Synthesis, Properties, and Biomedical Applications. ACS Appl. Mater. Interfaces 2014, 6 (5), 3365−3370. 

(118) Li, W.; Liu, Y.; Wang, B.; Song, H.; Liu, Z.; Lu, S.; Yang, B. Kilogram-Scale Synthesis of Carbon Quantum Dots for Hydrogen Evolution, Sensing and Bioimaging. Chin. Chem. Lett. 2019, 30 (12), 2323−2327. 

(119) Ge, M.; Huang, X.; Ni, J.; Han, Y.; Zhang, C.; Li, S.; Cao, J.; Li, J.; Chen, Z.; Han, S. One-Step Synthesis of Self-QuenchingResistant Biomass-Based Solid-State Fluorescent Carbon Dots with High Yield for White Lighting Emitting Diodes. Dyes Pigm. 2021, 185, 108953. 

(120) Wang, Y.; Sun, J.; He, B.; Feng, M. Synthesis and Modification of Biomass Derived Carbon Dots in Ionic Liquids and Their Application: A Mini Review. Green Chemical Engineering 2020, 1 (2), 94−108. 

(121) Tejwan, N.; Saha, S. K.; Das, J. Multifaceted Applications of Green Carbon Dots Synthesized from Renewable Sources. Adv. Colloid Interface Sci. 2020, 275, 102046. 

(122) Phadke, C.; Mewada, A.; Dharmatti, R.; Thakur, M.; Pandey, 

S.; Sharon, M. Biogenic Synthesis of Fluorescent Carbon Dots at 

15499 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<u>ACS Nano</u> 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

Ambient Temperature Using Azadirachta indica (Neem) Gum. J. Fluoresc. 2015, 25 (4), 1103−1107. 

(123) Zhao, J.; Huang, M.; Zhang, L.; Zou, M.; Chen, D.; Huang, Y.; Zhao, S. Unique Approach to Develop Carbon Dot-Based Nanohybrid Near-Infrared Ratiometric Fluorescent Sensor for the Detection of Mercury Ions. Anal. Chem. 2017, 89 (15), 8044−8049. (124) Ding, H.; Zhou, X.; Qin, B.; Zhou, Z.; Zhao, Y. Highly Fluorescent Near-Infrared Emitting Carbon Dots Derived from Lemon Juice and Its Bioimaging Application. J. Lumin. 2019, 211, 298−304. (125) Romero, V.; Vila, V.; de la Calle, I.; Lavilla, I.; Bendicho, C. Turn−On Fluorescent Sensor for the Detection of Periodate Anion Following Photochemical Synthesis of Nitrogen and Sulphur Co− Doped Carbon Dots from Vegetables. Sens. Actuators, B 2019, 280, 290−297. 

(126) Jayanthi, M.; Megarajan, S.; Subramaniyan, S. B.; Kamlekar, R. K.; Veerappan, A. A Convenient Green Method to Synthesize Luminescent Carbon Dots from Edible Carrot and Its Application in Bioimaging and Preparation of Nanocatalyst. J. Mol. Liq. 2019, 278, 175−182. 

(127) Wei, X.; Li, L.; Liu, J.; Yu, L.; Li, H.; Cheng, F.; Yi, X.; He, J.; Li, B. Green Synthesis of Fluorescent Carbon Dots from Gynostemma for Bioimaging and Antioxidant in Zebrafish. ACS Appl. Mater. Interfaces 2019, 11 (10), 9832−9840. 

(128) Zheng, J.-x.; Liu, X.-h.; Yang, Y.-z.; Liu, X.-g.; Xu, B.-s. Rapid and Green Synthesis of Fluorescent Carbon Dots from Starch for White Light-Emitting Diodes. New carbon materials 2018, 33 (3), 276−288. 

(129) Wang, N.; Wang, Y.; Guo, T.; Yang, T.; Chen, M.; Wang, J. Green Preparation of Carbon Dots with Papaya as Carbon Source for Effective Fluorescent Sensing of Iron (III) and Escherichia coli. Biosens. Bioelectron. 2016, 85, 68−75. 

(130) Liu, S.; Tian, J.; Wang, L.; Zhang, Y.; Qin, X.; Luo, Y.; Asiri, A. M.; Al-Youbi, A. O.; Sun, X. Hydrothermal Treatment of Grass: A Low-Cost, Green Route to Nitrogen-Doped, Carbon-Rich, Photoluminescent Polymer Nanodots as an Effective Fluorescent Sensing Platform for Label-Free Detection of Cu(II) Ions. Adv. Mater. 2012, 24 (15), 2037−2041. 

(131) Sahu, S.; Behera, B.; Maiti, T. K.; Mohapatra, S. Simple OneStep Synthesis of Highly Luminescent Carbon Dots from Orange Juice: Application as Excellent Bio-Imaging Agents. Chem. Commun. 2012, 48 (70), 8835−8837. 

(132) Atchudan, R.; Edison, T. N. J. I.; Lee, Y. R. Nitrogen-Doped Carbon Dots Originating from Unripe Peach for Fluorescent Bioimaging and Electrocatalytic Oxygen Reduction Reaction. J. Colloid Interface Sci. 2016, 482, 8−18. 

(133) Zhou, J.; Sheng, Z.; Han, H.; Zou, M.; Li, C. Facile Synthesis of Fluorescent Carbon Dots Using Watermelon Peel as a Carbon Source. Mater. Lett. 2012, 66 (1), 222−224. 

(134) Sun, D.; Ban, R.; Zhang, P.-H.; Wu, G.-H.; Zhang, J.-R.; Zhu, J.-J. Hair Fiber as a Precursor for Synthesizing of Sulfur- and Nitrogen-Co-Doped Carbon Dots with Tunable Luminescence Properties. Carbon 2013, 64, 424−434. 

(135) Teng, X.; Ma, C.; Ge, C.; Yan, M.; Yang, J.; Zhang, Y.; Morais, P. C.; Bi, H. Green Synthesis of Nitrogen-Doped Carbon Dots from Konjac Flour with “Off-On” Fluorescence by Fe3+ and L-Lysine for Bioimaging. J. Mater. Chem. B 2014, 2 (29), 4631−4639. 

(136) Zhang, Y.-P.; Ma, J.-M.; Yang, Y.-S.; Ru, J.-X.; Liu, X.-Y.; Ma, Y.; Guo, H.-C. Synthesis of Nitrogen-Doped Graphene Quantum Dots (N-GQDs) From Marigold for Detection of Fe3+ Ion and Bioimaging. Spectrochim. Acta, Part A 2019, 217, 60−67. 

(137) Bajpai, S. K.; D’Souza, A.; Suhail, B. Blue Light-Emitting Carbon Dots (CDs) from a Milk Protein and Their Interaction with Spinacia oleracea Leaf Cells. Int. Nano Lett. 2019, 9 (3), 203−212. 

(138) Hu, X.; An, X.; Li, L. Easy Synthesis of Highly Fluorescent Carbon Dots from Albumin and Their Photoluminescent Mechanism and Biological Imaging Applications. Mater. Sci. Eng., C 2016, 58, 730−736. 

(139) Arsalani, N.; Nezhad-Mokhtari, P.; Jabbari, E. MicrowaveAssisted and One-Step Synthesis of PEG Passivated Fluorescent Carbon Dots from Gelatin as an Efficient Nanocarrier for Methotrexate Delivery. Artif. Cells, Nanomed., Biotechnol. 2019, 47 (1), 540−547. 

(140) Feng, Y.; Zhong, D.; Miao, H.; Yang, X. Carbon Dots Derived from Rose Flowers for Tetracycline Sensing. Talanta 2015, 140, 128− 133. 

(141) Jiang, C.; Wu, H.; Song, X.; Ma, X.; Wang, J.; Tan, M. Presence of Photoluminescent Carbon Dots in Nescafe® Original Instant Coffee: Applications to Bioimaging. Talanta 2014, 127, 68− 74. 

(142) Wang, Z.; Liao, H.; Wu, H.; Wang, B.; Zhao, H.; Tan, M. Fluorescent Carbon Dots from Beer for Breast Cancer Cell Imaging and Drug Delivery. Anal. Methods 2015, 7 (20), 8911−8917. 

(143) Suryawanshi, A.; Biswal, M.; Mhamane, D.; Gokhale, R.; Patil, S.; Guin, D.; Ogale, S. Large Scale Synthesis of Graphene Quantum Dots (GQDs) from Waste Biomass and Their Use as an Efficient and Selective Photoluminescence On−Off−On Probe for Ag+ Ions. Nanoscale 2014, 6 (20), 11664−11670. 

(144) Huang, H.; Cui, Y.; Liu, M.; Chen, J.; Wan, Q.; Wen, Y.; Deng, F.; Zhou, N.; Zhang, X.; Wei, Y. A One-Step Ultrasonic Irradiation Assisted Strategy for the Preparation of PolymerFunctionalized Carbon Quantum Dots and Their Biological Imaging. J. Colloid Interface Sci. 2018, 532, 767−773. 

(145) Dhandapani, E.; Duraisamy, N.; Mohan Raj, R. Green Synthesis of Carbon Quantum Dots from Food Waste. Mater. Today: Proc. 2020, DOI: 10.1016/j.matpr.2020.10.025. 

(146) Radnia, F.; Mohajeri, N.; Zarghami, N. New Insight into the Engineering of Green Carbon Dots: Possible Applications in Emerging Cancer Theranostics. Talanta 2020, 209, 120547. 

(147) Zhang, J.; Yu, S.-H. Carbon Dots: Large-Scale Synthesis, Sensing and Bioimaging. Mater. Today 2016, 19 (7), 382−393. 

(148) Lu, W.; Qin, X.; Liu, S.; Chang, G.; Zhang, Y.; Luo, Y.; Asiri, A. M.; Al-Youbi, A. O.; Sun, X. Economical, Green Synthesis of Fluorescent Carbon Nanoparticles and Their Use as Probes for Sensitive and Selective Detection of Mercury(II) Ions. Anal. Chem. 2012, 84 (12), 5351−5357. 

(149) Tchounwou, P. B.; Ayensu, W. K.; Ninashvili, N.; Sutton, D. Review: Environmental Exposure to Mercury and Its Toxicopathologic Implications for Public Health. Environ. Toxicol. 2003, 18 (3), 149−175. 

(150) Huang, Q.; Li, Q.; Chen, Y.; Tong, L.; Lin, X.; Zhu, J.; Tong, Q. High Quantum Yield Nitrogen-Doped Carbon Dots: Green Synthesis and Application as “Off-On” Fluorescent Sensors for the Determination of fe3+ and Adenosine Triphosphate in Biological Samples. Sens. Actuators, B 2018, 276, 82−88. 

(151) Jiang, X.; Qin, D.; Mo, G.; Feng, J.; Yu, C.; Mo, W.; Deng, B. Ginkgo Leaf-Based Synthesis of Nitrogen-Doped Carbon Quantum Dots for Highly Sensitive Detection of Salazosulfapyridine in Mouse Plasma. J. Pharm. Biomed. Anal. 2019, 164, 514−519. 

(152) Sadeghi, S.; Garmroodi, A. Sensitive Detection of Sulfasalazine at Screen Printed Carbon Electrode Modified with Functionalized Multiwalled Carbon Nanotubes. J. Electroanal. Chem. 2014, 727, 171−178. 

(153) Yang, Y.; Cui, J.; Zheng, M.; Hu, C.; Tan, S.; Xiao, Y.; Yang, Q.; Liu, Y. One-Step Synthesis of Amino-Functionalized Fluorescent Carbon Nanoparticles by Hydrothermal Carbonization of Chitosan. Chem. Commun. 2012, 48 (3), 380−382. 

(154) Atchudan, R.; Jebakumar Immanuel Edison, T. N.; Shanmugam, M.; Perumal, S.; Somanathan, T.; Lee, Y. R. Sustainable Synthesis of Carbon Quantum Dots from Banana Peel Waste Using Hydrothermal Process for in Vivo Bioimaging. Phys. E 2021, 126, 114417. 

(155) Kim, K. W.; Choi, T.-Y.; Kwon, Y. M.; Kim, J. Y. H. Simple Synthesis of Photoluminescent Carbon Dots from a Marine Polysaccharide Found in Shark Cartilage. Electron. J. Biotechnol. 2020, 47, 36−42. 

15500 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

<mark>Review</mark> 

<mark>www.acsnano.org</mark> 

#### <u>ACS Nano</u> 

(156) Pacoureau, N.; Rigby, C. L.; Kyne, P. M.; Sherley, R. B.; Winker, H.; Carlson, J. K.; Fordham, S. V.; Barreto, R.; Fernando, D.; Francis, M. P.; Jabado, R. W.; Herman, K. B.; Liu, K.-M.; Marshall, A. D.; Pollom, R. A.; Romanov, E. V.; Simpfendorfer, C. A.; Yin, J. S.; Kindsvater, H. K.; Dulvy, N. K. Half a Century of Global Decline in Oceanic Sharks and Rays. Nature 2021, 589 (7843), 567−571. 

(157) Yuan, Y.; Guo, B.; Hao, L.; Liu, N.; Lin, Y.; Guo, W.; Li, X.; Gu, B. Doxorubicin-Loaded Environmentally Friendly Carbon Dots as a Novel Drug Delivery System for Nucleus Targeted Cancer Therapy. Colloids Surf., B 2017, 159, 349−359. 

(158) Anon Dairy Animals. http://www.fao.org/dairy-productionproducts/production/dairy-animals/en/ (accessed 2021-06-11). 

(159) Anon New FAO Report Assesses Dairy Greenhouse Gas Emissions. http://www.fao.org/news/story/en/item/41348/icode/ (accessed 2021-06-11). 

(160) Bayda, S.; Hadla, M.; Palazzolo, S.; Kumar, V.; Caligiuri, I.; Ambrosi, E.; Pontoglio, E.; Agostini, M.; Tuccinardi, T.; Benedetti, A.; Riello, P.; Canzonieri, V.; Corona, G.; Toffoli, G.; Rizzolio, F. Bottom-Up Synthesis of Carbon Nanoparticles with Higher Doxorubicin Efficacy. J. Controlled Release 2017, 248, 144−152. (161) D’Souza, S. L.; Deshmukh, B.; Bhamore, J. R.; Rawat, K. A.; Lenka, N.; Kailasa, S. K. Synthesis of Fluorescent Nitrogen-Doped Carbon Dots from Dried Shrimps for Cell Imaging and Boldine Drug Delivery System. RSC Adv. 2016, 6 (15), 12169−12179. 

Drug Delivery Vehicle for Acetaminophen. J. Sol-Gel Sci. Technol. 2020, 93 (1), 214−223. 

(173) Liu, W.-W.; Feng, Y.-Q.; Yan, X.-B.; Chen, J.-T.; Xue, Q.-J. Superior Micro-Supercapacitors Based on Graphene Quantum Dots. Adv. Funct. Mater. 2013, 23 (33), 4111−4122. 

(174) Chen, Q.; Hu, Y.; Hu, C.; Cheng, H.; Zhang, Z.; Shao, H.; Qu, L. Graphene Quantum Dots−Three-Dimensional Graphene Composites for High-Performance Supercapacitors. Phys. Chem. Chem. Phys. 2014, 16 (36), 19307−19313. 

(175) Hoang, V. C.; Nguyen, L. H.; Gomes, V. G. High Efficiency Supercapacitor Derived from Biomass Based Carbon Dots and Reduced Graphene Oxide Composite. J. Electroanal. Chem. 2019, 832, 87−96. 

(176) Pei, M.; Li, G.; Liu, P. Tumor-Specific Fluorescent CdotsBased Nanotheranostics by Acid-Labile Conjugation of Doxorubicin onto Reduction-Cleavable Cdots-Based Nanoclusters. Mater. Sci. Eng., C 2020, 110, 110719. 

(177) Lu, L.; Li, B.; Ding, S.; Fan, Y.; Wang, S.; Sun, C.; Zhao, M.; Zhao, C.-X.; Zhang, F. NIR-II Bioluminescence for in Vivo High Contrast Imaging and in SituATP-Mediated Metastases Tracing. Nat. Commun. 2020, 11 (1), 4192. 

(178) Chen, B. B.; Liu, M. L.; Huang, C. Z. Recent Advances of Carbon Dots in Imaging-Guided Theranostics. TrAC, Trends Anal. Chem. 2021, 134, 116116. 

(162) Hoang, V. C.; Gomes, V. G. High Performance Hybrid Supercapacitor Based on Doped Zucchini-Derived Carbon Dots and Graphene. Materials Today Energy 2019, 12, 198−207. 

(163) Li, W.; Liu, Y.; Wu, M.; Feng, X.; Redfern, S. A. T.; Shang, Y.; Yong, X.; Feng, T.; Wu, K.; Liu, Z.; Li, B.; Chen, Z.; Tse, J. S.; Lu, S.; Yang, B. Carbon-Quantum-Dots-Loaded Ruthenium Nanoparticles as an Efficient Electrocatalyst for Hydrogen Production in Alkaline Media. Adv. Mater. 2018, 30 (31), 1800676. 

(164) Wang, Z.; Chen, D.; Gu, B.; Gao, B.; Wang, T.; Guo, Q.; Wang, G. Biomass-Derived Nitrogen Doped Graphene Quantum Dots With Color-Tunable Emission for Sensing, Fluorescence Ink and Multicolor Cell Imaging. Spectrochim. Acta, Part A 2020, 227, 117671. (165) Wang, C.; Shi, H.; Yang, M.; Yan, Y.; Liu, E.; Ji, Z.; Fan, J. Facile Synthesis of Novel Carbon Quantum Dots from Biomass Waste for Highly Sensitive Detection of Iron Ions. Mater. Res. Bull. 2020, 124, 110730. 

(166) Zhang, X.; Tan, X.; Hu, Y. Blue/Yellow Emissive Carbon Dots Coupled with Curcumin: A Hybrid Sensor toward Fluorescence Turn-On Detection of Fluoride Ion. J. Hazard. Mater. 2021, 411, 125184. 

(167) Anthony, A. M.; Murugan, R.; Subramanian, R.; Selvarangan, G. K.; Pandurangan, P.; Dhanasekaran, A.; Sohrab, A. Ultra-Radiant Photoluminescence of Glutathione Rigidified Reduced Carbon Quantum Dots (r-CQDs) Derived from Ice-Biryani for in Vitro and in Vivo Bioimaging Applications. Colloids Surf., A 2020, 586, 124266. (168) Swathi, R.; Bhagavanth Reddy, G.; Rajkumar, B.; Yadagiri Swamy, P. Rapid Fabrication of Carbon Dots from Babul Seed Powder as Green Precursor: Antioxidant Activity and Multicolor Imaging. Materials Today: Proceedings 2021, 43, 1389−1397. 

(169) Shi, X.; Hu, Y.; Meng, H.-M.; Yang, J.; Qu, L.; Zhang, X.-B.; Li, Z. Red Emissive Carbon Dots with Dual Targetability for Imaging Polarity in Living Cells. Sens. Actuators, B 2020, 306, 127582. 

(170) Zhou, Y.; Mintz, K. J.; Cheng, L.; Chen, J.; Ferreira, B. C. L. B.; Hettiarachchi, S. D.; Liyanage, P. Y.; Seven, E. S.; Miloserdov, N.; Pandey, R. R.; Quiroga, B.; Blackwelder, P. L.; Chusuei, C. C.; Li, S.; Peng, Z.; Leblanc, R. M. Direct Conjugation of Distinct Carbon Dots as Lego-Like Building Blocks for the Assembly of Versatile Drug Nanocarriers. J. Colloid Interface Sci. 2020, 576, 412−425. 

(171) Mahani, M.; Pourrahmani-Sarbanani, M.; Yoosefian, M.; Divsar, F.; Mousavi, S. M.; Nomani, A. Doxorubicin Delivery to Breast Cancer Cells With Transferrin-Targeted Carbon Quantum Dots: An in Vitro and in Silico Study. J. Drug Delivery Sci. Technol. 2021, 62, 102342. 

(172) Chung, H. K.; Wongso, V.; Sambudi, N. S.; Isnaeni. Isnaeni, Biowaste-Derived Carbon Dots/Hydroxyapatite Nanocomposite as 

15501 

https://doi.org/10.1021/acsnano.1c03886 ACS Nano 2021, 15, 15471−15501 

