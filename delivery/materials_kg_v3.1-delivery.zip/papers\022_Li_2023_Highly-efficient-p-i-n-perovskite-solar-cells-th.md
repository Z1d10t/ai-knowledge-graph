# Highly efficient p-i-n perovskite solar cells that endure temperature variations

| 字段 | 内容 |
|---|---|
| 期刊 | Science |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 448 |
| 作者 | Guixiang Li, Zhen-Huang Su, Laura Canil, Declan Hughes, M. Aldamasy, J. Dagar, Sergei Trofimov, Luyao Wang et al. |
| DOI | 10.1126/science.add7331 |
| 源文件 | 022_Li_2023_Highly-efficient-p-i-n-perovskite-solar-cells-th.pdf |

---
# Supplementary Materials for 

Highly efficient p-i-n perovskite solar cells that endure temperature variations 

Guixiang Li, Zhenhuang Su, Laura Canil, Declan Hughes, Mahmoud H. Aldamasy, Janardan Dagar, Sergei Trofimov, Luyao Wang,* Weiwei Zuo, José J. Jerónimo-Rendon, Mahdi Malekshahi Byranvand, Chenyue Wang, Rui Zhu, Zuhong Zhang, Feng Yang, Giuseppe Nasti, Boris Naydenov, Wing C. Tsoi, Zhe Li, Xingyu Gao, Zhaokui Wang, Yu Jia, Eva Unger, Michael Saliba, Meng Li,* and Antonio Abate* 

Correspondence to: mengli@henu.edu.cn (M.L.); luyao.wang@helmholtz-berlin.de (L.W.); antonio.abate@helmholtz-berlin.de (A.A.) 

## **This PDF file includes:** 

Materials and Methods Supplementary Text Figs. S1 to S39 Tables S1 to S5 References ( _45–52_ ) 

1 

## **Materials and Methods** 

## <u>Materials</u> 

Organic salts of formamidinium iodide (FAI, 99.99%, trace elements basis) and methylammonium bromide (MABr, 99.99%, trace elements basis) were purchased from Dyenamo. Lead(II) iodide (PbI2, 99.99%, trace metals basis) and lead(II) bromide (PbBr2), as well as selfassembly molecule [2-(3,6-dimethoxy-9H-carbazol-9-yl)ethyl]phosphonic acid (MeO-2PACz, >98.0%) were purchased from TCI. Cesium iodide (CsI, 99.999%, AB 109298) and [6,6]-phenylC61-butyric acid methyl ester (PC61BM, product: OSO226) were provided by HySPRINT Helmholtz Innovation Lab and used without further purification. Bathocuproine (BCP, 99.8%) was acquired from Ossila and Silver shots (Ag, 2-3 mm, 99.999%) was bought from Alfa Aesar, respectively. Chlorobenzene (CB) and _β_ -poly(1,1-difluoroethylene) ( _β_ -pV2F) were purchased from Sigma Aldrich. Dimethyl sulfoxide (DMSO) and _N_ , _N_ -dimethylformamide (DMF) were obtained from Creaphys GmbH. Mucasol solution for substrate cleaning was obtained from Schülke & Mayr GmbH. Besides, ethanol, acetone and 2-propanol (IPA) were used for further substrate cleaning as received from VWR International Ltd. 

## <u>Device Fabrication</u> 

_Substrate Cleaning._ Patterned indium-doped tin oxide (ITO) glass substrates (25 mm x 25 mm, thickness of 80 nm) were firstly cleaned with 2% Mucasol solution dispersed in deionized water under ultrasonication for 15 min, followed by pure deionized water with 5 min ultrasonication. Subsequently, these substrates were sequentially cleaned by acetone and 2- propanol under ultrasonication for 15 min. After that, ITO glass substrates were dried with N2 blowing and hot plate. Ultimately, we used UV-ozone to treat substrates for 30 min. 

_Precursor Solution Preparation._ The perovskite precursor solution was prepared by dissolving 1.5 M triple-cation halide salts according to a formula of Cs0.05(FA0.98MA0.02)0.95Pb(I0.98Br0.02)3 in the mixed solvent of DMF/DMSO (4:1 in _v_ : _v_ ). Additionally, 0.5 mg/mL _β_ -pV2F polymer molecule was dissolved in the DMF/DMSO solvent as the additive into the perovskite precursor. During this process, the mixed solutions were stirred overnight in a shaker with 60 °C. Resultant solutions were filtered through a 0.45 μm hydrophobic PTFE filter before use. 

_Perovskite Solar Cell Fabrication._ The inverted p-i-n architecture perovskite solar cells (PSCs) in a planar system were fabricated through the following procedure. Typically, 100 μL MeO-2PACz (0.335 mg/mL) dissolved in absolute ethanol, as a hole transport material, was spincoated on the ITO glass substrates using a speed of 3,000 rpm for 30 s with an acceleration of 500 rpm/s, followed by annealing at 100 °C for Subsequently, 100 μL perovskite precursor was applied into MeO-2PACz layer. The dispersed perovskite solution was spin-coated with 6000 rpm for 35 s with a ramp of 1000 rpm/s. At 10 s before the end of the procedure, 200 μL chlorobenzene as the antisolvent was dripped into the precast film surface. After that, the substrates were quickly transferred to a hot plate with 100 °C for 45 min annealing. Then, starting the program with 3000 rpm for 30 s with a ramp of 3000 rpm/s, 20 mg/mL PC61BM in chlorobenzene was spin-coated on the obtained perovskite layers after 3 s to acquire the electron selective contact. Sequentially, 8 nm BCP controlled by temperature and 100 nm Ag electrode via controlling power were thermally deposited on the PC61BM layer with a shadow mask, using a thin-film evaporation system under a high vacuum lower than 1x10<sup>−6</sup> mbar. Ultimately, the PSCs with defined areas of 18 mm<sup>2</sup> on 

2 

each pixel were obtained. In addition, the device with defined working area of 1 cm<sup>2</sup> was also fabricated by covering the large-area mask. Notably, the whole device fabrication process was carried out in distraction-free N2-filled gloveboxes. 

## <u>Characterization</u> 

_Performance Measurement._ Photocurrent-voltage ( _J-V_ ) curves of PSCs under 1 sun equivalent illumination were recorded with a programmable Keithley 2400 source meter under a Wavelabs Sinus-70 LED class AAA sun simulator. The light intensity was calibrated using a filtered KG3 silicon reference solar cell from Fraunhofer-Institut für Solare Energiesysteme ISE. _J-V_ scans were carried out with a step size of 0.02 V, monitored by a controllable measurement program written in LabView. Device performance metrics of _J_ sc, FF, _V_ oc and PCE were collected from the _J-V_ measurements. During the _J-V_ measurements, PSCs employed defined device areas of 18 mm<sup>2</sup> and 1 cm<sup>2</sup> . Also, the stabilized power outputs at the maximum power points (MPP) was tracked under illumination, where the PSCs were biased at the MPP voltage. The external quantum efficiency (EQE) spectra from 300 to 850 nm were collected by Oriel Instruments QEPVSI-b system integrated with Xenon arc lamp (Newport 300 W), which was controlled _via_ TracQ-Basic software. The system was equipped with a chopper and the monochromatic light (Newport Cornerstone 260) for filtering the white light. Before measurements, the EQE setup was calibrated through a standard silicon photodetector with known spectral response. The operational stability of the unencapsulated devices is tested at the MPP tracking under simulated 1 sun illumination (LED solar simulator). The illumination intensity of the LED lamp is calibrated. There is an interval of 30 min for data collection. During the MPP tracking, the device is performed in an inert atmosphere at room temperature (25 °C). Thermal stability under elevated temperature is conducted at 75 °C in an inert atmosphere with continuous MPP tracking. The temperaturedependent test setup is mainly equipped with temperature and vacuum controllers, liquid nitrogen, vacuum pump, sample chamber, solar simulator. Specifically, temperature was controlled by hot and cold stage (HCP421V-PM), which is equipped with temperature controller (mK2000B), temperature control sensor (100 Ω Platinum RTD), liquid nitrogen cooling system, 3 L liquid nitrogen dewar (LN2-D3), water pump with heat exchanger, DC power supply, and temperature control software (Instec App). The inner sample chamber is cooled by the liquid nitrogen cooling accessory (INSTEC LN2-P). Setup temperature can range from −190 °C to 400 °C, with temperature stability of ±0.05 °C (>25 °C), ±0.1 °C (<25 °C). Maximum heating rate is +150 °C/min (at 37 °C), cooling rate is −50 °C/min (at 37 °C). Minimum heating and cooling rate is ±0.1 °C/h. During the operation, the device was placed in a chamber with controllable temperature and pressure. Liquid nitrogen was introduced to adjust the device temperature. During our thermal cycling, the temperature was controlled between −60 and +80 °C. For temperature ramps, we performed the WinTemp RAMP temperature (c) AT rate (°C/min) command to set up the ramp parameters in our experiments. The solar simulator with a 450 W xenon lamp (Sol3A Class AAA Solar Simulator, Oriel, USA) was used to record the device performance. 

_Structure Characterization._ Field-emission scanning electron microscope (SEM) measurements were carried out on a Quanta 200 FEG (FESEM, FEI Co.) to investigate the morphology and thickness of perovskites by measuring top and cross-sectional views. Atomic force microscope (AFM) was employed to reveal the topographical features of perovskite films by a Park Systems NX12 equipment. AFM topographies were analyzed using the open-source software Gwyddion<sup>©</sup> . Kelvin probe (KP) was implemented to measure the contact potential 

3 

difference (CPD). The KP setup was installed a vibrating gold mesh driven by a piezo electric crystal (Kelvin probe S and CPD controller from Besocke Delta Phi). X-ray diffraction (XRD) pattern was acquired by Panalytical Empyrean diffractometer with Cu Kα radiation. The synchrotron-based _in situ_ grazing-incidence wide-angle X-ray scattering (GIWAXS) was conducted by the BL14B1 beamline at Shanghai Synchrotron Radiation Facility (SSRF). Corresponding X-ray beam possesses the wavelength of 1.24 Å at a grazing incidence angle of 0.3° and uses an energy of 10 KeV. Two-dimensional (2D) GIWAXS patterns were collected from a MarCCD 225 detector with a distance of 330 mm between samples and detector. The FIT2D software was employed to parse 2D GIWAXS patterns. GIWAXS patterns were presented in scattering vector _q_ coordinates based on the equation _q_ = 4πsin _θ_ /λ, where _θ_ is the half of diffraction angle and λ is the incident wavelength. In the processing of the GIWAXS data, the vector _q_ was calibrated by measuring XRD from a Lanthanum hexaboride reference sample. Fourier-transform infrared spectroscopy (FT-IR) spectra were recorded by a FT/IR-4100 (JASCO) spectrometer, equipped with a universal attenuated total reflectance module. The polymer powder sample was prepared by grinding with potassium bromide (KBr) to produce a pellet, where polymer powder was mixed with KBr. The sample with the applied layer was pressed to the surface of the attenuated total reflection diamond crystal of the spectrometer. The perovskite film on glass was prepared by being cut into a small piece, and then pressed to the surface of the attenuated total reflectance diamond crystal. Water contact angle measurements for perovskite films were analyzed using a JC000DI optical contact-measuring system. We also conducted damp tests on perovskite films by placing them in 50% humidity air for 18 h to examine the resilience of the perovskite against moisture degradation. Steady-state photoluminescence (PL) spectra were obtained from LabVIEW software with a lab-built PL setup, which was installed a reflectance probe and a fiber-optic spectrometer from Ocean Insight. The PL measurements were performed by entering an integrating sphere through optical fiber, where the integration time was 300 ms and a 532 nm pulsed laser was used as excitation source. The device operational stability under the thermal cycling condition was measured without any encapsulation. Time-of-flight secondary ion mass spectrometry (ToF-SIMS) measurements were conducted using TOF-SIMS 5-100 produced by ION-TOF GmbH. The aged completed devices by thermal cycling used a 30 keV Bi+ ion beam as the primary ion beam to peel the samples with an analysis area of 80 × 80 μm<sup>2</sup> . For the sputtering, a Cs beam (500 eV) was performed to obtain the desired depth profile, where the sputtering areas were 230 × 230 μm<sup>2</sup> for devices measurement. During these measurements, negative ion mode was used. Secondary ion clusters or molecular ion signals of Ag<sup>−</sup> , C60<sup>−</sup> , I<sup>−</sup> , AgI2<sup>−</sup> , PbI3<sup>−</sup> , CN2H5I<sup>−</sup> , CF2<sup>−</sup> , and InO2<sup>−</sup> were recorded to track the Ag, PCBM, I, AgI, PbI2, FAI, _β_ -pV2F, and ITO species. 

4 

## **Supplementary Text** 

## <u>Hysteresis Index Calculation</u> 

The hysteresis index is calculated using the difference between forward-scan and reversescan efficiencies obtained from _J-V_ curves, defined as ( _45_ ): 



<!-- Start of picture text -->
𝑃𝐶𝐸𝑟𝑒𝑣𝑒𝑟𝑠𝑒−𝑃𝐶𝐸𝑓𝑜𝑟𝑤𝑎𝑟𝑑<br>Hysteresis index =             (Equation 1)<br>𝑃𝐶𝐸𝑟𝑒𝑣𝑒𝑟𝑠𝑒<br><!-- End of picture text -->

In this work, we used the same scan rate and range for all _J-V_ curves for inverted and forwarded scans to avoid the operational influence. 

## <u>Lattice Strain Calculation</u> 

For assessing the strain index _σ_ of perovskite lattices, we utilize the 2 _θ_ -sin<sup>2</sup> _φ_ method associated with Bragg’s Law and generalized Hooke’s Law, as (equation 2) ( _39, 46_ ). 



<!-- Start of picture text -->
𝐸 𝑑𝜑−𝑑𝑛<br>𝜎=<br>(1+𝑣)𝑠𝑖𝑛 2 𝜑 ∙ ( 𝑑𝑛 )               (Equation 2)<br><!-- End of picture text -->

where _φ_ and _n_ are the scattering vector angles, pertaining to the perovskite film surface normal direction. 

For the out-of-plane and in-plane directions, we obtain that out-of-plane _φ_ = 90° (⊥) and in-plane _n_ = 0° (∥). Then it can be calculated that sin<sup>2</sup> _φ_ = 1, as shown in (equation 3). 



<!-- Start of picture text -->
𝐸 𝑑⊥−𝑑∥<br>𝜎=<br>(1+𝑣) ∙( 𝑑∥ )               (Equation 3)<br>Due to  q  = 2π/ d , we further convert (equation 3) to (equation 4) as follows.<br>𝐸 𝑞∥−𝑞⊥<br>𝜎=<br>(1+𝑣) ∙ ( 𝑞∥ )              (Equation 4)<br><!-- End of picture text -->

We introduce ∆ _q_ to represent the difference between 𝑞∥ and 𝑞⊥ (∆𝑞= 𝑞∥ −𝑞⊥). Since the change in the denominator 𝑞⊥ is negligible compared to that in the numerator ∆ _q_ , we can use a constant value 𝑞0 to represent, resulting as (equation 5). 



<!-- Start of picture text -->
𝐸<br>𝜎= ∙∆𝑞              (Equation 5)<br>𝑞0(1+𝑣)<br><!-- End of picture text -->

where _E_ is Young’s modulus and _v_ is Poisson’s ratio of the perovskite film, respectively. _E_ and _v_ are evaluated as 10 GPa and 0.3, respectively. Also, the scattering vector constant _q_ 0 = 10.12 nm<sup>−1</sup> is available ( _47–49_ ). 

From the resultant (equation 5), we can observe that _σ_ is proportional to ∆ _q_ value. The ∆ _q_ is calculated by subtracting the out-of-plane scattering vector _qz_ value from that ( _qy_ ) of in-plane. 

5 

## **Supplementary Figures** 



**Fig. S1.** The strain intensity as a function of stretching lengths. (The strain (%) is calculated by dividing the _q_ difference (Δ _q_ ) by the _q_ value.) 

We performed wide-angle X-ray scattering (WAXS) of the perovskite film while stretching them by 0, 2 and 4 nm/μm. The _β_ -pV2F’s introduction reduces the strain generation of perovskites during stretching. Among them, the increased concentrations of 0.5 mg/mL and 0.75 mg/mL show a minor deformation and lattice strain. 

6 



**Fig. S2.** Azimuth-integration 1D plots for perovskite films with polymer molecular weight of 180,000, 270,000, 400,000 and 530,000 g/mol. 

From the synchrotron-based grazing-incidence wide-angle X-ray scattering (GIWAXS) results in **Fig. S2** , the 180,000 MW polymer-based perovskite has the strongest peak intensity and the smallest full width at half maximum (FWHM). 

7 



**Fig. S3.** Statistic grain size distribution histograms of ( **A** ) control and ( **B** ) target perovskite films. 

8 



**Fig. S4.** The ( **A** ) XRD patterns and ( **B** ) FWHM of (001) diffraction peaks of control and target perovskite films. 

The introduction of _β_ -pV2F does not show a noticeable peak shift in X-ray diffraction (XRD) patterns ( **Fig. S4A** ), indicating that the _β_ -pV2F molecules are not incorporated into the perovskite crystal lattice. The broadening of the XRD peak usually results from low crystalline quality, while the reduced FWHM extracted from **Fig. S4B** is observed in target perovskite, revealing an improved film quality ( _15_ ). 

9 



**Fig. S5.** AFM images of the surface morphologies of ( **A** ) control and ( **B** ) target perovskite films. 

We employed atomic force microscope (AFM) to analyze the topographical features of perovskite films. 

10 



**Fig. S6.** The FT-IR spectra with fingerprint region of control and target perovskite films. 

We conducted Fourier-transform infrared spectroscopy (FT-IR) measurements to verify the interaction between _β_ -pV2F and perovskite. The FT-IR spectrum at the higher frequency region of 2900-3100 cm<sup>−1</sup> shows the asymmetric ( _ν_ as) and symmetric ( _ν_ s) stretching vibrational bands of −CH2 groups in _β_ -pV2F molecule ( **Fig. S6A** ). After that, we observe the position of _ν_ as band shifts from 3025 cm<sup>−1</sup> to 3019 cm<sup>−1</sup> for the perovskite film treated with _β_ -pV2F compared to the pristine _β_ -pV2F molecule ( **Fig. S6B** ). The result indicates an interaction between –CH2 dipoles of _β_ -pV2F and halide ions of [PbX6]<sup>4−</sup> frame _via_ C-H···X dipole bonding ( _50, 51_ ). 

11 



**Fig. S7.** The water contact angles of ( **A** ) control and ( **B** ) target perovskite films. 

As the growth proceeds, the long-chain _β_ -pV2F are partially expelled to the perovskite film surface, the enhanced hydrophobicity ( **Fig. S7** ). 

12 



**Fig. S8.** GIWAXS profiles for perovskite films before and after damp tests (50% humidity air for 18 h). 

**Fig. S8** shows that the control film exhibits a significant drop in the diffraction signal after being damp, while the target film retains the diffraction peaks close to its initial state. This result further confirms the enhanced film hydrophobicity against moisture degradation. 

13 



**Fig. S9.** Steady-state PL spectra for control and target perovskite thin films prepared on quartz substrates. 

**Fig. S9** shows the enhanced photoluminescence (PL) intensity after introducing _β_ -pV2F into perovskite, corresponding to a reduced defect-induced nonradiative recombination. 

14 



**Fig. S10.** The time dependent PL intensity of target perovskite film under continuous illumination. 

Prolonging the illumination time to 1200 s does not lead to a decrease in the PL intensity ( **Fig. S10** ), suggesting that the _β_ -pV2F-based perovskite films have excellent photostability for overcoming photoinduced defect generation. 

15 



**Fig. S11.** Dark _J_ - _V_ characteristics of the control and target devices. 

To find the cause for the reduced charge recombination, we carried out the dark current densityvoltage ( _J_ - _V_ ) curves measurements for control and target devices. As displayed in **Fig. S11** , the dark current density of the target device is over an order of magnitude lower than that of the control device. It shows that the functionalization of _β_ -pV2F suppresses the leakage current and the photogenerated carriers are effectively separated during the photoelectric conversion process ( _22, 52_ ). This scenario allows the increase of the _V_ oc in devices ( _25, 26_ ). 

16 



**Fig. S12.** SCLC curves of ( **A** ) electron-only and ( **B** ) hole-only control and target devices, respectively. The insets corresponds to the respective device structures. 

The trap concentration is assessed by measuring space-charge-limited-current (SCLC) curves. It can be obtained that, from the dark _J_ - _V_ curves of electron-only devices in **Fig. S12A** , the trapfilled limit voltages ( _V_ TFL) are 0.46 V for control and 0.39 V for target, respectively manifesting the lower electron trap density in target devices. Additionally, the less hole trap density for target devices is shown in **Fig. S12B** . These results confirm that the _β_ -pV2F molecular functionalisation can eliminate trap states in the perovskite bulk and facilitate interfacial charge transfer ( _21, 23_ ). 

17 



**Fig. S13.** Mott–Schottky plots of the devices without and with polymer treatment. 

To further demonstrate the formation of the electric field, we conducted the Mott–Schottky analysis. As shown in **Fig. S13** , the built-in potential ( _V_ bi) values of the control and target PSCs are 1.071 V and 1.154 V, respectively. The increased _V_ bi indicates the formation of an interfacial electric field, resulting in fast charge collection and less carrier accumulation at the interface. 

18 



**Fig. S14.** Time-resolved integrated peak area intensity for intermediate phases of control and target perovskites. 

The intensity fluctuations at 25 s in **Fig. S14** result from antisolvent dropwise. 

19 



**Fig. S15.** The time-dependence X-ray scattering evolution during the ( **A** ) control and ( **B** ) target perovskite film formation process. 

In GIWAXS intensity profiles, several different diffraction signals and stages are presented ( **Fig. 2, A** and **B** , and **Fig. S15** ). The initial t1 stage (during the first 25 s) reveals the scattering halo at low _q_ values from 8 to 8.5 nm<sup>−1</sup> from the solvated colloidal sol precursor. The signal transition at t2 (25 s) originates from the dripping of antisolvent. Subsequently, the supersaturated solvate intermediate emerges as shown at stage t3, accompanied by the spin coating process, and this state is continuously maintained for a gap between the formation of solvate and perovskite crystals. When performing annealing stating at t4 (around 60 s), we directly observe that the intermediate phase signal intensity gradually weakened, as presented t5 stage. As time went by, the black phase centered at scattering vector _q_ = ∼10 nm<sup>−1</sup> along the (001) crystal plane comes into view by degrees at stage t6. The almost only scattering feature observed in the cast film indicates that the colloid has solidified and converted into a black phase. Stage t7 claimes the cessation of further crystal growth. Finally, a larger ending window with uniform diffraction intensity can be observed. 

20 



**Fig. S16.** The schematic diagram of crystallization kinetics. 

21 



**Fig. S17.** Schematic device architecture of the inverted p-i-n PSCs. 

The architecture of inverted p-i-n planar PSCs is constructed as glass/ ITO/ MeO-2PACz/ perovskite/ PC61BM/ BCP/ Ag. 

22 



**Fig. S18.** _J_ - _V_ curves with the reverse and forward sweep for ( **A** ) control and ( **B** ) target devices. 

The hysteresis factors of control and target PSCs are 4.9% and 2.0%, respectively ( **Fig. S18** ), thanks to reduced bulk defects and surface traps for charge recombination loss ( _3_ ). 

23 



**Fig. S19.** Independent efficiency certification result of PSCs by an accredited institute of Test and Calibration Center of New Energy Device and Module, Shanghai Institute of Microsystem and Information Technology, Chinese Academy of Sciences (SIMIT). 

We obtained a certified PCE of 24.24% from SIMIT with _J_ sc of 24.84 mA/cm<sup>2</sup> , _V_ oc of 1.174 V and FF of 83.21% under an aperture area of 9.58 mm<sup>2</sup> ( **Fig. S19** ), further supporting our results. 

24 



**Fig. S20.** Bandgap of perovskite layers calculated from the intercept of the EQE spectra. 

The bandgap of control and target perovskite layers is determined from the derivative EQE spectrum ( **Fig. S20** ), which of both are about 1.55 eV. It indicates that the _β_ -pV2F’s optimisation did not change the material bandgap. 

25 



**Fig. S21.** The statistics of ( **A** ) PCE, ( **B** ) _V_ oc, ( **C** ) FF and ( **D** ) _J_ sc distribution for control and target devices. 

26 



**Fig. S22.** Statistical operational stability of unencapsulated control and target devices ( _n_ = 12) tracking under continuous illumination in N2 atmosphere. 

27 



**Fig. S23.** Normalized PCEs of unencapsulated PSCs as a function of time measured at MPP under continuous illumination in an N2 atmosphere at 75 °C. 

28 



**Fig. S24.** The ( **A** ) reversed-scanned and ( **B** ) forward-scanned _J-V_ characteristics of typical control PSC during thermal cycles. 

29 



**Fig. S25.** The ( **A** ) reversed-scanned and ( **B** ) forward-scanned _J-V_ characteristics of typical target PSC during thermal cycles. 

30 



**Fig. S26.** The hysteresis index evolution against thermal cycles of control and target PSCs. 

31 



**Fig. S27.** Statistical temperature-dependence profiles of ( **A** ) _J_ sc, ( **B** ) _V_ oc, and ( **C** ) FF for control PSCs. 

32 



**Fig. S28.** Statistical temperature-dependence profiles of ( **A** ) _J_ sc, ( **B** ) _V_ oc, and ( **C** ) FF for target PSCs. 

33 



**Fig. S29.** Top-view SEM images of the control films aged by simulated thermal cycling operation. The film ageing is proceeded with the same process as the thermal cycling of the device. (There is a 20 °C/min ramp rate for rapid thermal cycling between −60 °C and +80 °C for 120 cycles, with an extra 2 minutes waiting windows for thermal equilibrium at −60 °C and +80 °C. The temperature starts from room temperature heating to +80 °C and then cooling to −60 °C.  The progress ends at room temperature. The time per complete cycle is 18 min.) 

After thermal cycling aging, control perovskites showed severe morphological degradation ( **Fig. S29** ). 

34 



**Fig. S30.** Top-view SEM images of the target films with _β_ -pV2F treatment aged by simulated thermal cycling operation. (There is a 20 °C/min ramp rate for rapid thermal cycling between −60 °C and +80 °C for 120 cycles, with an extra 2 minutes waiting windows for thermal equilibrium at −60 °C and +80 °C. The temperature starts from room temperature heating to +80 °C and then cooling to −60 °C.  The progress ends at room temperature. The time per complete cycle is 18 min.) 

As presented in **Fig. S30** , no obvious change in morphology was found for aged target perovskites. 

35 



**Fig. S31.** Schematic of ( **A** ) control and ( **B** ) target perovskites aged with simulated thermal cycling. 

36 



**Fig. S32.** Phase transition schematic of ( **A** ) control and ( **B** ) target perovskites during thermal cycling. 

37 



**Fig. S33.** The azimuthally integrated intensity during ( **A** ) first, ( **B** ) second and ( **C** ) third thermal cycles for control perovskite. 

38 



**Fig. S34.** The azimuthally integrated intensity during ( **A** ) first, ( **B** ) second and ( **C** ) third thermal cycles for target perovskite. 

39 



**Fig. S35.** The false-color intensity maps versus _q_ and temperatures from the _in situ_ GIWAXS measurement of control perovskite carried out during ( **A** ) first warming cycle, ( **B** ) first cooling cycle, ( **C** ) second warming cycle, ( **D** ) second cooling cycle, ( **E** ) third warming cycle, ( **F** ) third cooling cycle, and ( **G** ) forth warming cycle processes. 

40 

