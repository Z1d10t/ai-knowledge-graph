# Perovskite–organic tandem solar cells with indium oxide interconnect

| 字段 | 内容 |
|---|---|
| 期刊 | Nature |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 330 |
| 作者 | K. Brinkmann, T. Becker, F. Zimmermann, C. Kreusel, T. Gahlmann, M. Theisen, T. Haeger, S. Olthof et al. |
| DOI | 10.1038/s41586-022-04455-0 |
| 源文件 | 051_Brinkmann_2022_Perovskiteorganic-tandem-solar-cells-with-indium.pdf |

---
Journal Article (Accepted Manuscript) 

## **Monolithic perovskite/organic tandem solar cells based on an ultrathin metal** ‐ **like metal** ‐ **oxide interconnect** 

- K. O. Brinkmann, T. Becker, F. Zimmermann, C. Kreusel, T. Gahlmann, M. Theisen, T. Haeger, S. Olthof, C. Tückmantel, M. Günster, T. Maschwitz, F. Göbelsmann, C. Koch, 

- D. Hertel, P. Caprioglio, F. Peña-Camargo, L. Perdigón-Toro, A. Al-Ashouri, L. Merten, 

- A. Hinderhofer, L. Gomell, S. Zhang, F. Schreiber, S. Albrecht, K. Meerholz, D. Neher, 

- M. Stolterfoht and T. Riedl 

This document is the accepted manuscript version that has been published in final form in: 

Nature **2022** , 604, 280-286. https://doi.org/10.1038/s41586-022-04455-0 

This version of the article has been accepted for publication, after peer review and is subject to Springer Nature’s accepted manuscript terms of use, but is not the Version of Record and does not reflect post-acceptance improvements, or any corrections. The Version of Record is available online at: https://doi.org/10.1038/s41586-022-04455-0 

Persistent identifier of this version: https://doi.org/10.25926/jh6v-wr74 





# **Monolithic perovskite/organic tandem solar cells based on an ultra‐thin metal‐like metal‐oxide interconnect.** 

K. O. Brinkmann<sup>a,b*‡</sup> , T. Becker<sup>a,b*</sup> , F. Zimmermann<sup>a,b</sup> , C. Kreusel<sup>a,b</sup> , T. Gahlmann<sup>a,b</sup> , M. Theisen<sup>a,b</sup> , T. Haeger<sup>a,b</sup> , S. Olthof<sup>c</sup> , C. Tückmantel<sup>a,b</sup> , M. Günster<sup>a,b</sup> , T. Maschwitz<sup>a,b</sup> , F. Göbelsmann<sup>a,b</sup> , C. Koch<sup>c</sup> , D. Hertel<sup>c</sup> , P. Caprioglio<sup>d</sup> , F. Peña-Camargo<sup>d</sup> , L. Perdigon<sup>d</sup> , A. Al-Ashouri<sup>e</sup> , L. Merten<sup>f</sup> , A. Hinderhofer<sup>f</sup> , L. Gomell<sup>g</sup> , S. Zhang<sup>g</sup> , F. Schreiber<sup>f</sup> ,  S. Albrecht<sup>e</sup> , K. Meerholz<sup>c</sup> , D. Neher<sup>d</sup> , M. Stolterfoht<sup>d</sup> and T. Riedl<sup>a,b ‡</sup> 

> _a_ Institute of Electronic Devices, University of Wuppertal, Rainer-Gruenter-Str. 21, 42119 Wuppertal, Germany 

> _b_ Wuppertal Center for Smart Materials & Systems, University of Wuppertal, RainerGruenter-Str. 21, 42119 Wuppertal, Germany 

> _c_ Department of Chemistry, University of Cologne, Greinstrasse 4-6, 50939 Cologne, Germany 

- _d_ Soft Matter Physics, University of Potsdam, Karl-Liebknecht-Str. 24-25, 14476 Potsdam, Germany 

> e Young Investigator Group - Perovskite Tandem Solar Cells, Helmholtz-Zentrum Berlin, Kekuléstr. 5, 12489 Berlin, Germany 

- f Institute of Applied Physics, University of Tübingen, Auf der Morgenstelle 10, 72076 Tübingen, Germany 

g Max-Planck-Institut für Eisenforschung GmbH, Max-Planck-Str. 1, 40237 Düsseldorf, Germany 

##### ‡E-mail: t.riedl@uni-wuppertal.de, brinkmann@uni-wuppertal.de 

*equal contribution 

**Multi-junction solar cells provide an avenue to overcome fundamental efficiency limits of single-junction devices. The facile bandgap tunability of metal-halide perovskite solar cells renders them attractive building-blocks for multi-junction architectures.**<sup>**1**</sup> **Combinations with crystalline silicon and copper indium gallium selenide (CIGS) cells have been reported.**<sup>**2, 3**</sup> **All-perovskite tandem cells have likewise shown promising results.**<sup>**4, 5**</sup> **Meanwhile, narrow-gap non-fullerene acceptors (NFA) have revived the area of organic solar cells (OSCs) and unlocked skyrocketing efficiencies.**<sup>**6, 7**</sup> **Organic and perovskite semiconductors share similar processing technologies, which renders them attractive partners in** 

1 

**multi-junction architectures. As of yet, perovskite/organic tandem cells show subpar efficiencies of**  **20 per cent, limited by the low open circuit voltage (** **_V_ oc) of wide-gap perovskite cells**<sup>**8**</sup> **and losses introduced by the interconnect between the sub-cells.**<sup>**9, 10**</sup> 

**Here, we demonstrate two-terminal** **_p-i-n_ perovskite/organic tandem cells with an efficiency of 24.0 per cent (certified 23.1 per cent) and a high** **_V_ oc of 2.15 volts, operating near the levels predicted by a semi-empirical model. The perovskite sub-cells with optimized charge extraction layers afford an unsurpassed combination of a high Voc and fill-factor.  The organic back-cells provide a high external quantum efficiency in the nearinfrared. In surprising contrast to paradigmatic concerns about limited photostability of non-fullerene cells,**<sup>**11**</sup> **we evidence an outstanding operational stability if excitons are predominantly generated on the NFA, which is the case in a tandem cell, where the illumination is spectrally filtered by the perovskite cell. A novel interconnect based on an ultra-thin (**  **1.5 nanometers) metal-like indium oxide layer offers unprecedented low optical/electrical losses.** 

**This work sets a new milestone for perovskite/organic tandem devices, that outperform the best** **_p-i-n_ perovskite single junctions**<sup>**12**</sup> **and are at par with perovskite/CIGS and all-perovskite multi-junctions.**<sup>**13**</sup> **Perovskite/organic tandem architectures bear a realistic potential to reach an efficiency above 31 per cent.** 

In general, multi-junction solar cells are designed as a series connection of wide-bandgap and narrow-bandgap sub-cells with complementary absorption spectra. An improved overlap with the solar spectrum and reduced thermalization losses are the keys to overcome the ShockleyQueisser efficiency limit of single-junctions.<sup>14</sup> Hybrid metal-halide perovskites have received tremendous attention as photo-active materials in solar cells.<sup>15</sup> Their typical ABX3 composition comprises methylammonium (MA<sup>+</sup> ), formamidinium (FA<sup>+</sup> ), or Cs<sup>+</sup> ions on the A-site, Pb<sup>2+</sup> ions on the B-site, and halide ions, such as I<sup>-</sup> or Br<sup>-</sup> , on the X-site. Some members of this family, e.g. FAxCs1-xPb(IyBr1-y)3, afford tunability of the bandgap energy ( _E_ g) between 1.5-2.3 eV, mainly by variation of the I/Br ratio,<sup>16, 17</sup> rendering them especially attractive for the design of multijunction cells. 

All-perovskite tandem cells require narrow-gap materials ( _E_ g < 1.3 eV), where the lead is partially replaced by tin.<sup>18, 19</sup> However, severe stability 

2 

issues are linked to the unwanted transformation of Sn<sup>2+</sup> to Sn<sup>4+</sup> , which leads to non-intentional p-type doping and an overall degradation of device performance. This effect can be slowed down to some extent by additives, such as a surplus of sacrificial Sn(0) inside the active layer.<sup>4</sup> Alternatively, c-Si or CIGS back-cells have been employed<sup>2, 3</sup> in combination with a wide-gap perovskite front-cell. Some of these tandems already outperform the best c-Si single junctions.<sup>2, 20</sup> On the downside, perovskite/c-Si tandems are not compatible with low-temperature, low-cost, large-area manufacturing - a paradigm that is frequently quoted for perovskite solar technology. In this regard, organic solar cells (OSCs) represent an attractive option as narrow-gap back-cell. OSCs were typically based on so-called bulk-heterojunction architectures, that were formed by a blend of a donor polymer and a fullerene derivative as acceptor.<sup>21</sup> Owing to the limited tunability of the energy levels of the fullerene, progress in OSCs came to a halt at efficiency levels of about 11%.<sup>22</sup> However, with the recent introduction of non-fullerene acceptors (NFAs), OSCs started to see a second wave of outstanding advancement, which has propelled their efficiencies beyond 18%.<sup>6, 7, 23</sup> This progress mainly draws from the narrow energy gap of the acceptor moiety and an efficient exciton dissociation requiring only small energy offsets between donor and acceptor, which is the key to unlock low losses in _V_ oc compared to _E_ g/ _q_ while still providing a high external quantum efficiency (EQE) and thus high short circuit current densities ( _J_ sc).<sup>24, 25</sup> 

### **_Narrow-gap organic sub-cell_** 

For the narrow-gap sub-cell in our tandem architecture, we consider an organic photo-active system based on the polymer PM6, that contains a fluorinated - thienyl benzodithiophene, and the NFA Y6, which consists of a ladder-type dithienothiophen[3.2 - b] - pyrrolobenzothiadiazole central moiety and 2 - (5,6 - difluoro - 3 - oxo - 2,3 - dihydro - 1H - inden - 1 - ylidene)malononitrile units (Figure 1a).<sup>26</sup> We employ a _p-i-n_ type device architecture with molybdenumtrioxide as hole extraction layer (HEL) and a bi-layer of C60/2,9-Dimethyl-4,7diphenyl-1,10-phenanthroline (BCP) for efficient electron extraction. Our cells with binary PM6:Y6 blends (1:1.2) provide a power conversion efficiency (PCE) of up to 16.5%. The EQE spectrum of these devices extends beyond 900 nm (Figure 1b, Figure S1). Adding a certain concentration of the fullerene derivative [6,6]-phenylC61-butyric acid methyl ester (PC61BM) into the PM6:Y6 photo-active layer to form a so-called ternary system, i.e. PM6:Y6:PC61BM (1:1.2:0.2), improves the blend 

3 

morphology, which results in enhanced charge transport and reduced non-radiative recombination.<sup>27, 28</sup> Thus, a notable boost in cell characteristics is achieved with a PCE up to 17.5% (for device statistics see Figure S2). We want to highlight a notably enhanced EQE of > 85% for the ternary cells in the range of  > 650 nm, which is the spectral region of operation when combined with a wide-gap front-cell in a tandem. The absorption spectra of PM6 and Y6 (Figure 1c) show that for  > 650 nm, excitons are predominantly generated on the Y6, which will be shown to be the key that unlocks outstanding device stability. 

Stability of NFA cells under continuous operation is still a serious concern and a subject of vigorous scientific research.<sup>29</sup> To assess the stability of our binary and ternary cells under the illumination conditions applicable in a prospective perovskite/organic tandem cell, we used a filtered white LED (labelled: “LEDVIS”) and a near infrared (NIR) LED (peak at 850 nm; labelled: “LEDNIR”) as light sources, which predominantly create excitons on the PM6 or Y6, respectively (Figure 1c). Under combined VIS/NIR illumination (details can be found in the experimental section), binary and ternary cells show a notable decay of the PCE under continuous operation in the maximum power point (MPP) (Figure 1d), mainly due to a loss in fill factor (FF) (Figure S3). This degradation motif has previously been explained by a photoinduced reorganization in the donor/acceptor blend and the formation of microscopic aggregates of NFA molecules, which leads to a reduced electron mobility and enhanced recombination.<sup>30</sup> Owing to their improved blend morphology, the decay of the ternary cells is notably slower than that of the binary cells.<sup>29</sup> However, most strikingly, under NIR illumination, where excitons are solely generated on the Y6, the devices did not show any burn-in, and we found only minimal signs of degradation even under long-term continuous operation for more than 5,000 h (retaining 95% of its original efficiency). These findings indicate that the detrimental morphological changes, discussed above, would require excitation of the donor polymer PM6 and that they can be substantially mitigated if predominantly the Y6 NFA is excited. Atomic force microscopy (AFM) and grazing incidence wide angle x-ray scattering (GIWAXS) did not reveal morphological changes upon continuous illumination with LEDVIS + LEDNIR under inert conditions, while the results of grazing incidence small angle x-ray scattering (GISAXS) indicate only some minor morphological changes at the surface of samples after aging (Figure S4-S6). On the other hand, we found that upon continuous illumination with the white LED under inert conditions the photoluminescence quantum yield of PM6 shows a notable degradation, while the Y6 is less affected (Figure S7). Therefore, photo-induced degradation of PM6 could likewise play a significant role in addition to possible morphological changes. In any event, our 

4 

findings contradict the paradigmatic association of non-fullerene solar cells with operational instability, and they present the especially encouraging prospect that the long-term operational stability of perovskite/organic tandem cells will not be limited by the narrow-gap OSC. This is in notable contrast to all-perovskite tandems, where the stability of Sn-based narrow-gap PSCs is still a very serious issue. 

The PM6:Y6 organic system provides an energy-gap of 1.33 eV,<sup>26</sup> and we conducted a semi-empirical electro-optical simulation to identify a suitable wide-gap PSC for a tandem. Details of the simulation can be found in the supporting information. According to Figure 1e, an efficiency of 25.5% is predicted with a perovskite bandgap in the range of 1.85-1.92 eV, assuming a tandem FF of 80% and a loss in _V_ oc compared to _E_ g/ _q_ of 0.5 V, in each sub-cell. In a more optimistic scenario (FF = 85% and loss in _V_ oc compared to _E_ g/q of 0.4 V), a tandem of a narrow-gap OSC ( _E_ g = 1.15 eV) with a PSC ( _E_ g = 1.75 eV), provides the prospect to reach an efficiency of 31.3% (Figure S8). As of yet, efficient OSCs with _E_ g = 1.15 eV have not been developed. 



































































































































































**Figure 1 Architecture and properties of the organic sub-cell. a** , Layer sequence of the single junction OSC and chemical structure of the molecules used in the photo-active layer. **b,** External quantum efficiencies (EQE) of binary (PM6:Y6) and ternary (PM6:Y6:PC61BM) cells with a magnified view of the spectral region > 650 nm, which is the relevant range of operation for the OSC in a perovskite/organic tandem cell. **c** , Absorption spectra of the donor and acceptor molecules used in the photo-active layer. The vertical line marks the _E_ g of a possible 

5 

wide-gap front cell material. Spectra of (filtered) light emitting diodes used in the stability assessment to selectively excite the donor/acceptor are also shown (labelled “LEDVIS” and “LEDNIR”). **d** , Long term stability study of binary and ternary organic cells continuously operated using LED light sources with emission spectra shown in Figure 1c (one sun equivalent, nitrogen atmosphere, 25°C) in the maximum power point (MPP) with exciton generation on both acceptor and donor (“VIS+NIR”) or only on the acceptor (“NIR”). Please note the break in the x-axis. **e** , Semi-empirical model of the tandem cell efficiency vs. energy-gap of organic and perovskite sub-cells. The intersection of the dashed lines marks corresponds to the energy gap of the PM6:Y6:PC61BM back-cell and the matching energy-gap of the perovskite front-cell. This simulation states a conservative scenario assuming ∆VOC of 0.5V and a FF of 80%. A more optimistic (yet still realistic) model (∆VOC = 0.4 V, FF= 85%), yields a maximum efficiency higher than 31% (Figure S8). 

### **_Wide-gap perovskite sub-cell_** 

We selected FA0.8Cs0.2Pb(I0.5Br0.5)3 as suitable perovskite composition with a bandgap of 1.85 eV (Figure S9). Early studies have shown, that for high Br content PSCs with _E_ g > 1.75 eV, the _V_ oc did not concomitantly increase with _E_ g, which has frequently been attributed to photo-induced halide-segregation in the perovskite into bromine- and iodine-rich domains.<sup>31</sup> Yet, more recently, recombination losses at the interfaces between the wide-gap perovskite and the adjacent charge extraction layers have been found to be predominately limiting the _V_ OC.<sup>8, 32</sup> As such, we aimed to minimize these interfacial losses in order to narrow in on the highest possible _V_ oc in our PSCs. 

In a first step, we analyzed the quasi-Fermi level splitting (QFLS) in the perovskite upon illumination. The QFLS provides an excellent indication (and upper limit) of the _V_ oc that can be expected in an actual solar cell and it allows to determine the potential loss in _V_ oc associated with the respective charge extraction layers adjacent to the perovskite. Poly[bis(4-phenyl)(2,4,6-trimethylphenyl)amine (PTAA) is currently the most prominent hole extraction layer (HEL) in _p-i-n_ PSCs. However, PTAA comes with serious limitations due to the tradeoff between efficient hole transport, which requires the PTAA to be as thin as possible, and selectivity, that has been found to impose a lower limit to the PTAA thickness.<sup>33</sup> To overcome the issues associated with PTAA, we use [2-(3,6-Dimethoxy-9H-carbazol-9yl)ethyl]phosphonic Acid (MeO-2PACz)<sup>13</sup> as HEL, that forms a dense, pinhole-free self-assembled monolayer on the indium tin oxide (ITO) bottom electrode. In a 

6 

direct comparison, perovskite layers on MeO-2PACz as HEL afford a 90 meV larger QFLS compared to their analogues on PTAA (Figure 2a). Interestingly, in stark contrast to PTAA, with MeO-2PACz as HEL, we also did not observe notable halide segregation under a one sun equivalent illumination on a timescale of several minutes, despite using a Br:I ratio of 0.5:0.5 (Figure S10). This is rather unexpected, as literature suggests notable halide segregation for Br concentrations in this range.<sup>34</sup> Our findings demonstrate that the proper choice of HEL allows to mitigate halide segregation in perovskites even with elevated Br-concentrations. Please note that for longer illumination time (> 30 min) first indications of reversible halide segregation have been observed (Figure S11), evidencing mitigation, yet no complete suppression of halide segregation. A possible origin of the reduced halide segregation by the use of MeO-2PACz as HEL is discussed in Supplementary note 3. 

Before studying the impact of the electron extraction layer (EEL), we implemented passivation strategies, such as the addition of excess lead<sup>35</sup> or the modification of the perovskite surface by the organic halide salt phenethylammonium iodide (PEAI),<sup>36, 37</sup> which promotes the formation of a 2-dimensional perovskite capping layer (see Figure S12 - S15). As evidenced by photoelectron spectroscopy, the insertion of PEA<sup>+</sup> leads to some notable lowering of the perovskite valence band maximum (Figure S16), which prevents photo-generated holes from reaching the EEL and thereby improves the selective extraction of electrons. 

In the absence of an EEL, the surface passivation does not affect the QFLS (Figure 2a), which indicates that defects at the surface or grain boundaries do not impose a limit in this scenario. The situation changes if we complete our _p-i-n_ PSCs by adding PC61BM and Al doped ZnO nanoparticles (AZO NP) as EEL (Figure 2b).<sup>38</sup> Note, for the integration of the PSCs in the tandem cells, an additional SnOx layer, grown by low temperature atomic layer deposition (ALD), is used that serves as permeation barrier, which not only improves the long term stability but also protects the layers underneath against chemical attack by the solvents of subsequent wet chemical processes.<sup>39, 40</sup> 

In striking contrast to PTAA, with MeO-2PACz as HEL, the addition of the EEL infers a substantial reduction of the QFLS, and the resulting _V_ oc shows notable further improvements upon passivation with excess lead and even more by the formation of a 2D perovskite cap (Figure 2c). As for devices with MeO-2PACz and the 2D perovskite cap the observed mean VOC values reproduce the measured QFLS, we conclude that interface recombination, rather than energy misalignment, is the main limiting factor. For champion devices VOC even reaches the QFLS of the bare perovskite indicating superior suppression of recombination losses at the EEL side. 

7 

Ultimately, PSCs with hysteresis-free current-voltage characteristics are achieved, that provide a very high stabilized _V_ oc = 1.34 V (Figure 2 d, e) with a _FF_ that falls within a narrow range of 77-82% (Figure 2c and Figure S17). In previous reports, an increase of _V_ oc typically came at the cost of a lowered _FF_ and a loss in EQE. A comparison with the literature on high Br content PSCs with an _E_ g in the range of 1.8-1.9 eV shows that our careful mitigation of losses at the interfaces unlocked access to previously unreached territory of combined high _V_ oc and _FF_ (Figure 2e). Finally, when operated continuously for more than 100 h, the PCE of the wide-gap PSCs remains above 80% of its initial value (Figure 2f). 





















































































































































**Figure 2 Optimized wide-gap perovskite sub-cell. a** , Splitting of the quasi-Fermi levels (QFLS) in case of varied hole extraction layers (HEL), i.e. Poly[bis(4-phenyl)(2,4,6-trimethylphenyl)amine (PTAA) or [2-(3,6-Dimethoxy-9Hcarbazol-9-yl)ethyl]phosphonic Acid (MeO-2PACz), with and w/o usage of excessive lead or a two dimensional capping layer (2D cap, see text) **b,** Layer sequence of the _p-i-n_ perovskite single junction. **c,** Comparison of the open circuit voltage ( _V_ oc) of actual perovskite solar cells (PSCs) with the corresponding splitting of the quasi-Fermi level (QFLS) of representative layer stacks with and w/o electron extraction layer (EEL) and varied device annealing temperature. The _FF_ of each cell type is shown in the lower panel. The different temperatures refer to the annealing 

8 

conditions after deposition of the AZO NP layer. The dots represent the results of individual devices and indicate the experimental spread. **d,** Current density vs. voltage characteristics for champion PSCs with a 2D capping layer (MeO-2PACz SAM as HEL) or PbI2 excess (PTAA as HEL) on the perovskite active layer. The inset shows the stabilized _V_ oc of 1.34 V for the cell with the SAM as HEL. **e,** Comparison of the _V_ oc and _FF of_ our PSCs with _E_ g = 1.85 eV to PSCs (with _E_ g in the range of 1.8-1.9 eV) with high Br content, reported in the literature. The respective references can be found in Table S1. **f,** Normalized PCE vs. time of the PSCs illuminated with a white LED and operated in the maximum power point. 

### **_Low-loss recombination interconnect_** 

The interconnect is a key component of monolithic (2-terminal) tandem solar cells (Figure 3a). In a _p-i-n_ tandem, it facilitates the recombination of electrons from the bottom perovskite cell with the holes from the top organic cell, ideally without any loss of _V_ oc and _FF_ . In the simplest approach, one could omit the top electrode of the perovskite cell and stack the organic cell directly on top. In this case, the interface between the low-work-function SnOx and the high-work-function MoOx affords only extremely poor, s-shaped _J-V_ characteristics of the resulting tandem cell (Figure 3b). This is due to a Schottky barrier of 0.6 eV that forms at the SnOx/MoOx interface (see Figure 3c, d and Figure S18). 

To render the interconnect ohmic, thin layers ( 1 nm) of a metal (Ag or Au) are frequently inserted between top- and bottom-cell.<sup>10, 41</sup> However, even a Ag-layer as thin as 1 nm already introduces significant optical losses that lower the EQE of the back-cell and the overall _J_ sc of the tandem cell as shown further below. Thus, we developed an interconnect based on an ultra-thin ALD-grown InOx layer with a thickness of only ~1.5 nm (details of the ALD growth process can be found in the experimental section). We leverage the unique property of ALD to provide utmost control of layer thickness even on the level of Ångströms, which is impossible with conventional deposition techniques. The insertion of InOx between SnOx and MoOx outstandingly improves the _J-V_ characteristics of the tandem cells (Figure 3b). As few as 32 ALD cycles (thickness ~1.5 nm, Figure S19) are sufficient to render the SnOx/InOx/MoOx stack ohmic (Figure 3b, c, d). 

To better understand the structural and electronic properties of our interconnect, we conducted high-angle annular dark-field scanning transmission electron microscopy (HAADF-STEM), energy dispersive X-ray spectroscopy (EDS), grazing incidence wide angle X-ray scattering (GIWAXS) and photoelectron spectroscopy. HAADF-STEM and GIWAXS confirm that our ALD grown InOx and SnOx are both amorphous and continuous 

9 

(Figures S20 - S26). Elemental mapping shows that the SnOx/InOx interface is abrupt, and multivariate analysis<sup>42</sup> confirms no sign of In diffusion into the underlying SnOx (Figure S22, 23). As confirmed by highly surface sensitive UV photoelectron spectroscopy measurement of the Sn4d semi-core levels, any hypothetical interdiffusion of Sn and In at the SnOx/InOx interface would be limited to a range of 5 Angstroms (Figure S24). The energetic line-up in the interconnect is unraveled by an extensive study using again photoelectron spectroscopy (Figure 3d and Figure S27 – S31). The upward band bending found in case of SnOx/MoOx is completely alleviated by the insertion of the ultra-thin InOx, enabling barrier-free transport of electrons from the bottom PSC across the SnOx/InOx/MoOx layer sequence. Ultimately, these electrons recombine with the holes from the OSC at the MoOx/organic interface.<sup>43, 44</sup> Notably, after completion of a nucleation phase ( 32 ALD cycles), the InOx layer shows a metallic nature with an electron density ~ 10<sup>20</sup> cm<sup>-3</sup> (Figure 3d, e). While some charge transfer (or doping) at the interface between SnOx and InOx cannot be fully excluded, we confirmed that our ALD grown InOx provides a likewise high carrier density also when deposited on Al2O3 (Figure S32). A high carrier density is frequently found in nominally undoped InOx thin films because of oxygen vacancies and surface defects.<sup>45, 46</sup> In our case, we have determined a stoichiometry of In2O2.8 by photoelectron spectroscopy, which indicates oxygen deficiency. As the metallic InOx layer is ultra-thin, it still provides a very high sheet resistance > 10<sup>6</sup> /sq, which outperforms carefully optimized sputtered metal oxide interconnects by at least an order of magnitude.<sup>5</sup> Note that a high sheet resistance is of critical importance to avoid shorting of the sub-cells in case of local shunt paths. 

High carrier densities typically infer optical absorption, which is another important reason to keep the thickness of the interconnect to a minimum.<sup>47</sup> Most strikingly, our ultra-thin InOx interconnect with a transmittance near unity does not introduce notable optical losses (Figure 3g), which boosts the EQE of the organic back-cell and the overall _J_ sc of the tandem by about 1.5 mA/cm<sup>2</sup> compared to the case of an interconnect based on 1 nm of Ag, which affords a PCE of only about 20% (Figure 3 h, Figure S33). ALD allows for large-area, high-throughput processing (even at atmospheric pressure),<sup>48</sup> and enables conformal coating of textured surfaces that frequently occur in light trapping concepts.<sup>2</sup> Hence, we foresee that the applicability of our interconnect is not limited to perovskite/organic tandem cells, but it may also be favorably used in other tandem cells. 

10 





































































































































**Figure 3 Tandem interconnect. a** , Schematic of a perovskite/organic tandem cell with InOx or Ag as interconnect. **b,** _J-V_ characteristics of tandem cells with varied thickness (# of ALD cycles) of the InOx interconnect. **c,** _J-V_ characteristics of SnOx/(InOx)/MoOx diodes. **d,** Energetic line-up determined with and without InOx. Note, in the first 2 nm of the molybdenum oxide layer we found a mix of oxidation states of the molybdenum ranging from Mo<sup>2+</sup> to Mo<sup>6+</sup> (details in Figure S27-S31). The first 2 nm of the molybdenum oxide are characterized by the presence of MoO4<sup>2-</sup> clusters (details in supporting information). **e,** Sheet resistance and carrier density vs. thickness of the InOx. **f,** Ultra-violet photoelectron spectroscopy of the valence band (VB) density of states (DOS) of InOx, showing the onset of a metallic behavior at 32 ALD cycles. **g,** Optical transmission of an interconnect based on 32 ALD cycles (~1.5 nm) of InOx, bare and sandwiched between SnOx and MoOx. For comparison, the InOx has been replaced by a nominally 1 nm thick layer of Ag. **h,** Resulting EQE spectra of the organic back-cell with InOx or Ag as interconnect demonstrating the significant current losses induced by only 1 nm Ag. 

11 

### **_Monolithic perovskite-organic tandem cells_** 

Drawing from the significant progress outlined above, we prepared monolithic perovskite/organic tandem solar cells with outstanding characteristics. The EQE spectra of the PSC and OSC sub-cells of an optimized perovskite/organic tandem are shown in Figure 4a. Excellent current matching, as required in a series connection, is evidenced by the identical integrated current density of 14.1 mA/cm<sup>2</sup> for both sub-cells. The high EQE values (> 95%) in the wavelength region between 400-500 nm can be explained by optical effects associated with the high refractive index of the perovskite material, that affords an efficient in-coupling of light into the active medium in this spectral range.<sup>49</sup> The high _V_ oc = 2.15 V of the tandem cell results from an almost ideal addition of the _J-V_ characteristics of the sub-cells without any loss in _V_ oc (Figure 4b, Figure S34). As a result, a champion tandem cell with a stabilized PCE of 24.0 % is achieved (Figure 4b,c; Figure S35 & S36). An efficiency of 23.1% (± 1.6%) was certified by the Fraunhofer ISE CalLab, according to the IEC 60904-3 procedure (Figure 4d, S37 – S39). As the certification procedure inflicts some stress to the device prior to the actual certification (see Supplementary Note 5), additionally a control measurement (without certificate) was conducted by the Fraunhofer ISE CalLab without the stressing conditions, which confirmed an efficiency of 23.7%, that we measured in house (Figure S40). 

Our devices state the most efficient monolithic perovskite/organic tandem cells, as of yet, and outperform the most efficient single junction perovskite cells in _p-i-n_ architecture.<sup>12</sup> The tandem characteristics show a very small statistical variation (Figure S35 & S36), resulting from a robust processing of the perovskite sub-cell.<sup>50</sup> We evidence an excellent stability of more than 1,000 h with no sign of degradation when the devices are kept under inert atmosphere, and a T80 of 130 h under continuous operation in the MPP (Figure 4 d,e). Note, the temporal behavior of the tandem under continuous operation is essentially governed by that of the perovskite sub-cell (Figure 2f). 

12 

||scan<br>direction|PCE / %|FF / %|VOC/ V|JSC/ mA/cm²|
|---|---|---|---|---|---|
|PSC|reverse|16.8|81|1.34|15.6|
||forward|16.4|80|1.33|15.5|
|OSC|invariant|17.5|75|0.87|26.7|
|tandem|reverse|24.0|80|2.15|14.0|
||forward|23.8|79|2.14|14.1|



Table 1: Champion solar cell characteristics of the single junctions and tandem cell derived from their _J-V_ characteristics. Note, for all cells, the _J_ sc agrees with the current density obtained from the EQE spectra (deviation less than 1%). 





























































































































































**Figure 4 Perovskite/organic tandem cells. a** , External quantum efficiency spectra of both sub-cells in the tandem cell. For reduced reflection, the backside of the substrate was coated with a 100 nm thick MgF2 layer. **b,** _J-V_ characteristics of tandem cells. **c,** Stabilized power output (SPO) of the tandem cell. (inset) scanning electron microscopy image of the cell cross section. **d,** Statistical data of tandem solar cells as derived from reverse J-V scans also containing the certified and confirmed value measured by the Fraunhofer ISE CalLab (Figure S37 – S39) **e,** Stability of the tandem cells under continuous operation in the MPP, and **f,** when stored in N2. 

13 

**Data availability:** The data that support the findings of this study are available from the corresponding authors on request. 

### **References** 

1. Leijtens T, Bush KA, Prasanna R, McGehee MD. Opportunities and challenges for tandem solar cells using metal halide perovskite semiconductors. _Nature Energy_ **3** , 828-838 (2018). 

2. Hou Y _, et al._ Efficient tandem solar cells with solution-processed perovskite on textured crystalline silicon. _Science_ **367** , 1135-1140 (2020). 

3. Han Q _, et al._ High-performance perovskite/Cu(In,Ga)Se2 monolithic tandem solar cells. _Science_ **361** , 904-908 (2018). 

4. Lin R _, et al._ Monolithic all-perovskite tandem solar cells with 24.8% efficiency exploiting comproportionation to suppress Sn(ii) oxidation in precursor ink. _Nature Energy_ **4** , 864–873 (2019). 

5. Palmstrom AF _, et al._ Enabling Flexible All-Perovskite Tandem Solar Cells. _Joule_ **3** , 2193-2204 (2019). 

6. Yan C _, et al._ Non-fullerene acceptors for organic solar cells. _Nature Reviews Materials_ **3** , 18003 (2018). 

7. Liu Q _, et al._ 18% Efficiency organic solar cells. _Science Bulletin_ **65** , 272-275 (2020). 

8. Mahesh S _, et al._ Revealing the origin of voltage loss in mixed-halide perovskite solar cells. _Energy & Environmental Science_ **13** , 258-267 (2020). 

9. Li C, Wang Y, Choy WCH. Efficient Interconnection in Perovskite Tandem Solar Cells. _Small Methods_ **4** , 2000093 (2020). 

10. Chen X _, et al._ Efficient and Reproducible Monolithic Perovskite/Organic Tandem Solar Cells with Low-Loss Interconnecting Layers. _Joule_ **4** , 1594-1606 (2020). 

11. Zhan L _, et al._ Over 17% efficiency ternary organic solar cells enabled by two nonfullerene acceptors working in an alloy-like model. _Energy & Environmental Science_ **13** , 635-645 (2020). 

12. Zheng X _, et al._ Managing grains and interfaces via ligand anchoring enables 22.3%efficiency inverted perovskite solar cells. _Nature Energy_ **5** , 131-140 (2020). 

13. Al-Ashouri A _, et al._ Conformal monolayer contacts with lossless interfaces for perovskite single junction and monolithic tandem solar cells. _Energy & Environmental Science_ **12** , 3356-3369 (2019). 

14. Shockley W, Queisser HJ. Detailed Balance Limit of Efficiency of p - n Junction Solar Cells. _Journal of Applied Physics_ **32** , 510-519 (1961). 

15. Graetzel M. The light and shade of perovskite solar cells. _Nat Mater_ **13** , 838-842 (2014). 

16. McMeekin DP _, et al._ A mixed-cation lead mixed-halide perovskite absorber for tandem solar cells. _Science_ **351** , 151-155 (2016). 

17. Tao S _, et al._ Absolute energy level positions in tin- and lead-based halide perovskites. _Nature Communications_ **10** , 2560 (2019). 

18. Hao F, Stoumpos CC, Chang RPH, Kanatzidis MG. Anomalous Band Gap Behavior in Mixed Sn and Pb Perovskites Enables Broadening of Absorption Spectrum in Solar Cells. _J Am Chem Soc_ **136** , 8094-8099 (2014). 

14 

19. Zhao D _, et al._ Efficient two-terminal all-perovskite tandem solar cells enabled by high-quality low-bandgap absorber layers. _Nature Energy_ **3** , 1093-1100 (2018). 

20. Green MA, Dunlop ED, Hohl-Ebinger J, Yoshita M, Kopidakis N, Hao X. Solar cell efficiency tables (version 56). _Progress in Photovoltaics: Research and Applications_ **28** , 629-638 (2020). 

21. Yu G, Gao J, Hummelen JC, Wudl F, Heeger AJ. Polymer Photovoltaic Cells: Enhanced Efficiencies via a Network of Internal Donor-Acceptor Heterojunctions. _Science_ **270** , 1789-1791 (1995). 

22. Zhao J _, et al._ Efficient organic solar cells processed from hydrocarbon solvents. _Nature Energy_ **1** , 15027 (2016). 

23. Cheng P, Li G, Zhan X, Yang Y. Next-generation organic photovoltaics based on nonfullerene acceptors. _Nature Photonics_ **12** , 131-142 (2018). 

24. Qian D _, et al._ Design rules for minimizing voltage losses in high-efficiency organic solar cells. _Nature Materials_ **17** , 703-709 (2018). 

25. Liu J _, et al._ Fast charge separation in a non-fullerene organic solar cell with a small driving force. _Nature Energy_ **1** , 16089 (2016). 

26. Yuan J _, et al._ Single-Junction Organic Solar Cell with over 15% Efficiency Using Fused-Ring Acceptor with Electron-Deficient Core. _Joule_ **3** , 1140-1151 (2019). 

27. Yu R, Yao H, Cui Y, Hong L, He C, Hou J. Improved Charge Transport and Reduced Nonradiative Energy Loss Enable Over 16% Efficiency in Ternary Polymer Solar Cells. _Advanced Materials_ **31** , 1902302 (2019). 

28. Zhu Y _, et al._ Rational Strategy to Stabilize an Unstable High-Efficiency Binary Nonfullerene Organic Solar Cells with a Third Component. _Advanced Energy Materials_ **9** , 1900376 (2019). 

29. Gasparini N _, et al._ Exploiting Ternary Blends for Improved Photostability in HighEfficiency Organic Solar Cells. _ACS Energy Letters_ **5** , 1371-1379 (2020). 

30. Du X _, et al._ Unraveling the Microstructure-Related Device Stability for Polymer Solar Cells Based on Nonfullerene Small-Molecular Acceptors. _Advanced Materials_ **32** , 1908305 (2020). 

31. Slotcavage DJ, Karunadasa HI, McGehee MD. Light-Induced Phase Segregation in Halide-Perovskite Absorbers. _ACS Energy Letters_ **1** , 1199-1205 (2016). 

32. Peña-Camargo F _, et al._ Halide Segregation versus Interfacial Recombination in Bromide-Rich Wide-Gap Perovskite Solar Cells. _ACS Energy Letters_ **5** , 2728-2736 (2020). 

33. Stolterfoht M _, et al._ Approaching the fill factor Shockley–Queisser limit in stable, dopant-free triple cation perovskite solar cells. _Energy & Environmental Science_ **10** , 1530-1539 (2017). 

34. Knight AJ, Herz LM. Preventing phase segregation in mixed-halide perovskites: a perspective. _Energy & Environmental Science_ **13** , 2024-2046 (2020). 

35. Park B-w _, et al._ Understanding how excess lead iodide precursor improves halide perovskite solar cell performance. _Nature Communications_ **9** , 3301 (2018). 

36. Jiang Q _, et al._ Surface passivation of perovskite film for efficient solar cells. _Nature Photonics_ **13** , 460-466 (2019). 

15 

37. Doung T, _et al._ High Efficiency Perovskite-Silicon Tandem Solar Cells: Effect of Surface Coating versus Bulk Incorporation of 2D Perovskite, _Advanced Energy Materials_ **10** , 1903553 (2020). 

38. Brinkmann KO _, et al._ Suppressed decomposition of organometal halide perovskites by impermeable electron-extraction layers in inverted solar cells. _Nature Communications_ **8** , 13938 (2017). 

39. Behrendt A _, et al._ Highly Robust Transparent and Conductive Gas Diffusion Barriers Based on Tin Oxide. _Advanced Materials_ **27** , 5961-5967 (2015). 

40. Gahlmann T _, et al._ Impermeable Charge Transport Layers Enable Aqueous Processing on Top of Perovskite Solar Cells. _Advanced Energy Materials_ **10** , 1903897 (2020). 

41. Gu S, Lin R, Han Q, Gao Y, Tan H, Zhu J. Tin and Mixed Lead–Tin Halide Perovskite Solar Cells: Progress and their Application in Tandem Solar Cells. _Advanced Materials_ **32** , 1907392 (2020). 

42. Zhang S, Scheu C, Evaluation of EELS spectrum imaging data by spectral components and factors from multivariate analysis. _Microscopy_ **67** , 133-141 (2018). 

43. Becker T _, et al._ All-Oxide MoOx/SnOx Charge Recombination Interconnects for Inverted Organic Tandem Solar Cells. _Advanced Energy Materials_ **8** , 1702533 (2018). 

44. Meyer J, Hamwi S, Kröger M, Kowalsky W, Riedl T, Kahn A. Transition Metal Oxides for Organic Electronics: Energetics, Device Physics and Applications. _Advanced Materials_ **24** , 5408-5427 (2012). 

45. Hagleitner DR, et al. Bulk and surface characterization of In2O3(001) single crystals. _Phys. Rev. B_ **85** , 115441 (2012). 

46. Lany A, et al.  Surface Origin of High Conductivities in Undoped In2O3 Thin Films. Phys. Rev. Lett. **108** , 016802 (2012). 

47. Bellingham JR, Phillips WA, Adkins CJ. Intrinsic performance limits in transparent conducting oxides. _Journal of Materials Science Letters_ **11** , 263-265 (1992). 

48. Hoffmann L _, et al._ Spatial Atmospheric Pressure Atomic Layer Deposition of Tin Oxide as an Impermeable Electron Extraction Layer for Perovskite Solar Cells with Enhanced Thermal Stability. _ACS Applied Materials & Interfaces_ **10** , 6006-6013 (2018). 

49. Brinkmann KO, _et al._ The Optical Origin of Near-Unity External Quantum Efficiencies in Perovskite Solar Cells. _Solar RRL_ **9,** 2100371 (2021). 

50. Brinkmann KO _, et al._ Extremely Robust Gas-Quenching Deposition of Halide Perovskites on Top of Hydrophobic Hole Transport Materials for Inverted (p–i–n) Solar Cells by Targeting the Precursor Wetting Issue. _ACS Applied Materials & Interfaces_ **11** , 40172-40179 (2019). 

#### **Online Content** 

#### **Acknowledgments** 

We acknowledge the Deutsche Forschungsgemeinschaft (DFG) (Within the SPP 2196: Grant numbers RI1551/18-1, RI 1551/12-1; individual grant numbers: RI 1551/15-1, RI1551/4-3 and HE 2698/7-2), the Bundesministerium für Bildung und Forschung (BMBF) (Grant Number: 01DP20008) and the Bundesministerium für Wirtschaft und Energie (BMWi) (Grant number: ZF4037809DF8) for financial 

16 

support. The research leading to these results has received partial funding from the European Unions's Horizon 2020 Programme under Grant Agreement no. 951774 (FOXES). This work was also partially funded by the European Regional Development Fund (ERDF) (Grant number: EFRE 0801507) SO and CK further thank the SCALUP project. (SOLAR-ERA.NET Cofund 2, id: 32). We thank Mountain Photonics for providing us with a Prizmatix high-power white LED as well as Tesa Germany for providing us with sealing duct tape. We would also like to thank Dr. Junke Wang and Prof. René Janssen from the Eindhoven University of Technology for their support in verifying some external quantum efficiency values reported in this work. We thank Dr. Baptiste Gault and Andreas Sturm from the Max-PlanckInstitut für Eisenforschung GmbH for enabling the STEM measurements. We also thank the ESRF for the admission of x-ray diffraction measurements and gratefully appreciate the support by our local contacts Oleg Konovalov and Maciej Jankowski. Finally, we would like to acknowledge Dr. Jochen Hohl-Ebinger from the Fraunhofer ISE CalLab for valuable consultation throughout the certification process. 

### **Additional information** 

### **Author contributions** 

TR, TB and KB conceived and designed the experiments. TB and KB contributed equally to this work. SO and CKo contributed the XPS, UPS and IPES analysis. KB, TB, FZ, CKr, MG, TM, CT and FG were performing the experimental work on the solar cells. TG and MT contributed the metal oxide ALD layers as well as electrical characterization. TH did the cross-section SEM measurements. PC, LP, DN and MS designed, conducted and evaluated the PLQY/QFLS studies. AA and SA provided the expertise in the processing of the self-assembled monolayers. DH and KM contributed temperature dependent J-V characterization. LM, AH and FS designed and conducted the GIWAXS, LG and SZ the HAADF-STEM and EDS studies. All authors discussed the results and were involved in the writing. 

### **Supplementary Information available** 

### **Competing financial interests: The authors declare no competing financial interests.** 

17 

