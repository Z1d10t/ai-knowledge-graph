# The Roadmap of 2D Materials and Devices Toward Chips

| 字段 | 内容 |
|---|---|
| 期刊 | Nano-Micro Letters |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 245 |
| 作者 | Anhan Liu, Xiaowei Zhang, Zi-Yu Liu, Yu-Ning Li, Xueyang Peng, Xin Li, Yue Qin, Chen Hu et al. |
| DOI | 10.1007/s40820-023-01273-5 |
| 源文件 | 087_Liu_2024_The-Roadmap-of-2D-Materials-and-Devices-Toward-C.pdf |

---
e-ISSN 2150-5551 CN 31-2103/TB 

https://doi.org/10.1007/s40820-023-01273-5 

## **<mark>REVIEW</mark>** 



# **The Roadmap of 2D Materials and Devices Toward Chips** 

###### **Cite as** 

Nano-Micro Lett. (2024) 16:119 

> (2024) 16:119 Anhan Liu<sup>1</sup> , Xiaowei Zhang<sup>1</sup> , Ziyu Liu<sup>2</sup> , Yuning Li<sup>5</sup> , Xueyang Peng<sup>4,6</sup> , Xin Li<sup>3</sup> , Yue Qin<sup>3</sup> , Chen Hu<sup>4,6</sup> , Yanqing Qiu<sup>4,6</sup> , Han Jiang<sup>2</sup> , Yang Wang<sup>2</sup> , Yifan Li<sup>1</sup> , Jun Tang<sup>3</sup> , Jun Liu<sup>3</sup> , Received: 30 June 2023 Accepted: 30 October 2023 Hao Guo<sup>3*</sup> , Tao Deng<sup>5*</sup> , Songang Peng<sup>4,7*</sup> , He Tian<sup>1*</sup> , Tian-Ling Ren<sup>1*</sup> Published online: 16 February 2024 © The Author(s) 2024 

#### **HIGHLIGHTS** 

- This review introduces the potential of 2D electronics for post-Moore era and discusses their current progress in digital circuits, analog circuits, heterogeneous integration, sensing circuits, artificial intelligence chips, and quantum chips in sequence. 

- A comprehensive analysis of the current trends and challenges encountered in the development of 2D materials is summarized. 

- An in-depth roadmap outlining the future development of 2D electronics is presented, and the most accessible and promising avenues for 2D electronics are suggested. 

**ABSTRACT** Due to the constraints imposed by physical effects and performance degradation, silicon-based chip technology is facing certain limitations in sustaining the advancement of Moore’s law. Two-dimensional (2D) materials have emerged as highly promising candidates for the post-Moore era, offering significant potential in domains such as integrated circuits and next-generation computing. Here, in this review, the progress of 2D semiconductors in process engineering and various electronic applications are summarized. A careful introduction of material synthesis, transistor engineering focused on device configuration, dielectric engineering, contact engineering, and material integration are given first. Then 2D transistors for certain electronic applications including digital and analog circuits, heterogeneous integration chips, and sensing circuits are discussed. Moreover, several promising applications (artificial intelligence chips and quantum chips) based on spe- 

cific mechanism devices are introduced. Finally, the challenges for 2D materials encountered in achieving circuit-level or system-level applications are analyzed, and potential development pathways or roadmaps are further speculated and outlooked. 

**KEYWORDS** Two-dimensional materials; Roadmap; Integrated circuits; Post-Moore era 

> Anhan Liu, Xiaowei Zhang, Ziyu Liu, Yuning Li, Xueyang Peng, and Xin Li contributed equally to this work. 

> * Hao Guo, guohao@nuc.edu.cn; Tao Deng, dengtao@bjtu.edu.cn; Songang Peng, pengsongang@ime.ac.cn; He Tian, tianhe88@tsinghua.edu.cn; Tian-Ling Ren, RenTL@tsinghua.edu.cn 

> 1 School of Integrated Circuits and Beijing National Research Center for Information Science and Technology (BNRist), Tsinghua University, Beijing 100049, People’s Republic of China 

> 2 School of Microelectronics, Fudan University, Shanghai 200433, People’s Republic of China 

> 3 State Key Laboratory of Dynamic Measurement Technology, Shanxi Province Key Laboratory of Quantum Sensing and Precision Measurement, North University of China, Taiyuan 030051, People’s Republic of China 

> 4 High-Frequency High-Voltage Device and Integrated Circuits R&D Center, Institute of Microelectronics, Chinese Academy of Sciences, Beijing 100029, People’s Republic of China 

> 5 School of Electronic and Information Engineering, Beijing Jiaotong University, Beijing 100044, People’s Republic of China 

> 6 School of Integrated Circuits, University of Chinese Academy of Sciences, Beijing 100049, People’s Republic of China 

> 7 IMECAS-HKUST-Joint Laboratory of Microelectronics, Beijing 100029, People’s Republic of China 

1 3 

**119** Page 2 of 96 

Nano-Micro Lett. (2024) 16:119 

### **1 Introduction** 

Since the advent of integrated circuits (ICs) in 1958, their technological advancements have been driven by the relentless progression of Moore’s Law [1]. The development of silicon-based complementary metal–oxide–semiconductor (CMOS) technology, from the inception of the first CPU, Intel 4004 to the advent of FinFET-based circuits, has played a pivotal role in driving the advancement of the semiconductor industry and information technology. However, as transistor dimensions have reached the nanoscale, various physical phenomena, such as thickness-fluctuation-induced scattering [2], quantum tunneling, and other short-channel effects (SCEs) [3], have emerged in silicon-based devices, causing severe performance degradation and posing challenges to the continuous advancement of Moore’s law. The conventional CMOS technology, which relies on size reduction for enhanced integration density, is now facing significant obstacles, but the demand for more powerful computing systems remains driven by rapid advances in applications like high-performance computing, Internet of Things (IoT), and artificial intelligence. 

To foster further progress in microelectronics, three development directions have been proposed: More Moore, More than Moore, and Beyond Moore [4, 5]. The More Moore path seeks to persistently scale down transistor dimensions while mitigating the detrimental effects of short-channel phenomena through innovative approaches such as novel device structures or alternative materials. The More than Moore path emphasizes the optimization of circuit design, system algorithms, and advanced packaging techniques to improve chip performance. Furthermore, it aims to diversify the functionalities of electronic systems, encompassing fields such as sensing [6], RF applications [7], flexible electronics, bioelectronics [8], and the IoT [9]. The Beyond Moore direction, meanwhile, explores novel switch devices beyond traditional CMOS technology, including ferroelectric transistors [10], neuromorphic devices [11], and quantum devices [12], to realize advanced information processing capabilities. 

To surmount the limitations of silicon materials and advance the development of post-Moore era, there is a need to explore novel semiconductor materials that can sustain stable and exceptional electrical properties even at reduced dimensions. 2D materials, characterized by their 

atomic-scale thickness, have garnered significant attention. Remarkably, 2D materials exhibit noteworthy carrier mobility and gate control performance even at the ultimate limits of miniaturization [13]. As a result, they have emerged as promising candidates for serving as channel materials in next-generation semiconductor devices within the More Moore domain. Furthermore, 2D materials demonstrate remarkable heterogeneity and compatibility with silicon and other 2D materials [14], allowing for seamless integration in advanced electronic systems. These materials also offer remarkable surface-to-volume ratios and surface activities, rendering them highly suitable for sensing applications within the More than Moore domain [15]. Moreover, their unique quantum properties and phenomena hold considerable potential for breakthroughs in the exploration of quantum devices. In summary, 2D materials hold substantial promise for advancing Moore’s law within the More Moore, More Than Moore, and Beyond Moore directions. They offer exceptional opportunities to overcome the current limitations and push the boundaries of microelectronics technology. 

At present, 2D materials encounter numerous opportunities and uncertainties. The development of mature siliconbased technology and another emerging material, carbon nanotubes (CNTs), could serve as valuable guidance and references for the advancement of 2D materials (Fig. 1a). However, the progression of 2D technology experiences a certain degree of delay due to factors such as limitations in material growth. It is still a challenge to achieve circuits beyond the processor level. More expectations are being placed on the substitution of silicon in specific domains. According to IMEC’s projection, it is anticipated that by 2032, 2D materials will genuinely find application in backend-of-the-line (BEOL) processes [16]. Additionally, the development of 2D materials exhibits variations across diverse application domains. To further search for the most feasible pathway toward the realization of 2D materials’ application, the proposal of a roadmap becomes essential to provide assistance and insight. 

In this review, we first present an overview of the characteristics and current development status of 2D materials. Subsequently, we discuss the advancements in 2D transistor fabrication processes including material synthesis, transistor engineering, material transfer and integration, and 2D package. Then, the recent progress and applications of 2D materials in typical fields are summarized, respectively (logic chips and heterogeneous integration chips in the 

© The authors 

https://doi.org/10.1007/s40820-023-01273-5 

Page 3 of 96 **119** 

Nano-Micro Lett. (2024) 16:119 



**Fig. 1** A schematic diagram of the general roadmap for 2D circuits. **a** Development timeline of silicon-based, carbon nanotube-based, and 2D ICs. **b** Route for the realization of 2D circuits and possible applications in the future. Reproduced with permission [17–20]. Copyright (2017), (2018), (2021), (2022), Springer Nature. Reproduced with permission [21]. Copyright (2023), American Chemical Society. Reproduced with permission [22]. Copyright (2017), Elsevier 

More Moore domain, sensor chips in the More Than Moore domain, artificial intelligence (AI) chips, and quantum chips in the Beyond Moore domain). Finally, we address some of the challenges and issues that persist in the application of 2D materials, along with highlighting the potential directions where early applications of 2D materials are most likely to be realized. 

### **2  Promises of 2D Materials Toward Chips** 

As the most important electronic device in modern ICs, the continuous advancement of the performance of field effect transistors (FETs) has led to rapid progress in electronic technologies. To accurately assess the digital and analog performance of FETs, a set of key device parameters are defined. The fundamental basis for digital logic applications 

1 3 

**119** Page 4 of 96 

Nano-Micro Lett. (2024) 16:119 

is the ability to switch transistors on and off (Fig. 2a). Minimizing the off-state current ( _I_ off) is essential to reduce static power consumption. Achieving a large current ratio between the ON and OFF states ( _I_ on/ _I_ off) exceeding  10<sup>5</sup> is imperative for enhanced control accuracy. The subthreshold swing (SS) determines the switching speed of FETs. When it comes to analog applications, the intrinsic gain  (Av) is one of the most important analog parameters that determines the amplification capability of a single device. However, as the technology node goes down, all these device parameters degrade severely due to the second-order effects (e.g., SCEs) in Si-based FETs, limiting its further development [23]. The ideal semiconductor for sub-10-nm node should include the 

following features: (1) proper bandgap and excellent carrier transport properties with decreasing body thickness; (2) low defect density and good long-term stability; (3) producible in large scale, easy to integrate and compatible with Si CMOS technology [24]. 

The introduction of 2D materials as the channel is an attractive strategy to address the challenges associated with scaling down. Since the first 2D materials to be discovered, graphene was isolated in 2004 [25], a broad library of 2D materials has been explored broadly including transition metal dichalcogenides (TMDCs), black phosphorus (BP), hexagonal boron nitride (h-BN), MXene and so on [26]. Different from conventional bulk silicon materials, 2D materials 



**Fig. 2  a** Schematic of a traditional FET and typical transfer characteristic of FET device. **b** Partial advantages of 2D materials over bulk materials. **c** Number of 2D material publications from 2013 to 2023. (Keywords used for searching “two dimensional materials”, “wafer-scale OR circuit OR array” and the corresponding abbreviation for specific applications like “digital”, several typical 2D materials like  MoS2 are also listed as keywords. Source: Web of Science Core Collection, accessed on January 3, 2024) 

© The authors 

https://doi.org/10.1007/s40820-023-01273-5 

Page 5 of 96 **119** 

Nano-Micro Lett. (2024) 16:119 

exhibit lattice periodicity in the plane, resulting in the formation of Brillouin zones. Within this region, electron energy levels and wave functions are subject to stringent quantum constraints, allowing only specific energy levels to exist and giving rise to a quantized energy band structure. This quantum confinement effect gives 2D materials adjustable energy gaps, carrier confinement, and quantum tunneling effects. By controlling the geometry number of layers, heterostructures, etc., of 2D materials, or applying external strains, and electric fields to them, the lattice periodicity is changed, ultimately influencing the band structure and the size of the band gap. Furthermore, electrons are confined within the ultrathin body that allows excellent gate electrostatic control and has the potential of being immune to the SCEs. The mobility of 2D FETs has been enhanced to 350,000  cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> based on graphene prepared by chemical vapor deposition (CVD) which is accessible for wafer-scale production [27]. In comparison, when the body thickness of silicon is below 5 nm, the fluctuation in material surface thickness and the pronounced scattering caused by surface dangling bonds significantly disrupt the structural periodicity of silicon [28]. The buckled structure of silicene breads the atomic plane’s symmetry, unlike graphene, resulting in particularly strong Zero-Acoustic (ZA) phonon scattering [29], leading to severe mobility degradation. Furthermore, due to the surface sensitivity of silicene derived from its mixed _sp_<sup>2</sup> – _sp_<sup>3</sup> character [30], its instability in air necessitates specific preparation and usage conditions for its realization [31]. 

While graphene is not suitable as an active semiconductor material for electronic switching owing to its gapless band structure and graphene FETs show a limited _I_ on/ _I_ off ratio leading to high power consumption in standby mode [23]. Hence, graphene is usually used as metallic contact or gate materials instead of channel materials [32]. In addition to graphene,  MoS2,  WS2, and  WSe2 from the family of TMDCs are developed to fabricate FETs due to their considerable bandgap (> 0.5 eV) [4]. The  MoS2 FET with a 1-nm-wide gate electrode shows a nearly ideal SS of ~ 65 mV/decade and a large _I_ on/ _I_ off ratio of ~  10<sup>6</sup> [33]. The h-BN is the most common 2D insulator ( _E_ g ≈ 6 eV) and is usually considered to be the most promising gate insulator in 2D-based FETs because of the ideal interface without scattering. Efforts have also been invested in the development of novel 2D dielectric materials, like  CaF2 [34]. The diverse lattice structures and atomic arrangements of 2D materials give rise to distinct electronic band structures, resulting in a wide 

energy band range, covering semimetals, semiconductors, and insulators. Besides, with the dangling-bond-free surface, the carrier mobility of 2D transistors varies little with body thickness and it is easy for 2D materials to integrate with other kinds of materials without being constrained by lattice constant matching [35]. 

Furthermore, with the advent of the big data era, several novel computing architectures and mechanisms have been introduced for next-generation computing technologies. Benefiting from the fascinating characteristics of 2D materials, 2D device innovation has become the focus of intense research such as 2D memory devices, neuromorphic devices, and quantum-engineering devices. 2D memristor, memtransistor, flash memory, and ionic transistor are widely exploited for in-memory computing or artificial intelligence technology [11]. 2D materials can not only extend Moore’s Law to sub-5-nm nodes but also boost memory performance. For example, owing to the ultrathin body of 2D materials, 2D memory devices can use a low working voltage and reduce power consumption. Semi-metallic graphene was reported to be suitable as a contact material for electrodes presenting ultralow switching power or a blocking layer to inhibit efficient carrier injection due to its low density of states [36]. The h-BN could be applied as the switching layer for memristive memory devices with high endurance and long retention time [37]. What’s more, continuous discovery and research on novel physical mechanisms for applications in low-power switches have been proposed and investigated including tunneling transistors [38], ferroelectric transistors [39], and filament-based FET [40]. Those emerging FET devices have great potential to lower the SS and subsequently lower the supply voltage and energy consumption. S. Kim et al. reported a natural heterojunction-tunneling FET with a spatially varying layer thickness in BP without interface problems. And the device’s SS has achieved a record-low level  (SSave_4dec ~ 22.9 mV  dec<sup>−1</sup> ) [38]. The unique quantum properties of 2D materials also have been developed. They have strong spin–orbit coupling strength leading to enhanced Rashba effect and easier modulation of the electron spin through an externally applied electric field. The atomic-scale thickness of 2D van der Waals (vdW) heterostructure can be utilized to maximize the spin-injection efficiencies [12]. And there’s plenty of application room for the computing capability drive after Moore’s law to 2D materials. 

1 3 

**119** Page 6 of 96 

Nano-Micro Lett. (2024) 16:119 

### **3  Process Engineering for 2D Chips** 

Lots of efforts have been devoted to the exploration of 2D materials’ physical characteristics or device optimization. Most of the early demonstrations of 2D FETs are based on mechanically exfoliated flakes. And the research has been confined to individuals or a limited number of devices. However, to achieve circuit-level applications of 2D materials, the scale of devices should be expanded to the waferscale, which poses higher requirements on material synthesis, device processing, and integration technology. In this section, we will introduce and discuss the research progress in the field of process engineering for 2D chips. 

##### **3.1  Material Synthesis** 

Device performance consistency is a crucial foundation for achieving 2D circuits, and device performance fluctuations need to be confined within a certain range [41]. In terms of material quality, the realization of chip-level 2D circuits requires the synthesis of wafer-scale single-crystal (WSSC) materials that are uniform and have low defect densities. Due to constraints related to material size, controllability, and repeatability in the fabrication process, traditional mechanical exfoliation methods are unsuitable for waferscale preparation and industrialization. In this section, we will introduce the preparation methods for wafer-scale 2D materials from various perspectives, including CVD, metal–organic chemical vapor deposition (MOCVD), mechanical exfoliation, and liquid-phase exfoliation, with a particular focus on the wafer-scale preparation of TMDCs materials. 

##### **_3.1.1  Chemical Vapor Deposition_** 

The CVD method is currently one of the most promising approaches for the direct synthesis of large-area monolayer 2D materials [41]. Its advantages of low cost and scalability have sparked widespread research interest in the field of 2D materials. It has been reported that the uniform  MoS2 wafer size could be extended to a 12-inch diameter which is crucial for the transition of TMDC materials from laboratory research to integrated components in next-generation semiconductor devices [42] (Fig. 3a). Due to the sensitivity 

of material growth, the substrate imperfection (e.g., grain boundaries) may lead to vacancies, impurities, wrinkles, and thickness fluctuations in the 2D sheet and the growth of polycrystalline 2D materials, which would threaten the yield and stability of devices or even result in circuit failure. 

Orientation-controlled growth is considered an effective approach for achieving the preparation of WSSC TMDCs materials. By selecting a suitable substrate that matches the lattice of TMDCs, it is possible to grow TMDC films with high crystallinity, complete lattice structure, and controllable lattice orientation [54]. Substrates with specific crystal orientations, such as Au(111) and sapphire (0001), have been successfully employed for the preparation of WSSC TMDCs [43, 55] (Fig. 3b). L. Liu et al. reported the uniform nucleation of bilayer  MoS2 on c-plane sapphire. Without the transfer step, the fabricated short-channel FET devices based on bilayer  MoS2 exhibit an on-state current of 1.27 mA μm<sup>−1</sup> [46]. 

While there is another challenge that must be noted—— the thermal budget. The current CVD growth methods cannot avoid the use of high temperature to achieve good crystalline, while allowable thermal budgets for the BEOL technologies are lower than 400 ℃ [56]. The low growth temperature would lead to the formation of grain boundaries and stoichiometric defects in  MoS2 which is detrimental to lateral transport [68]. The trade-off between CVD temperature and MoS2 mobility determines the potential widespread adoption of CVD-based  MoS2 applications in the future (Fig. 3c). 

##### **_3.1.2  Metal–Organic Chemical Vapor Deposition_** 

Different from the CVD method, MOCVD employs metal–organic compounds as precursors and achieves uniform supply throughout the entire substrate (Fig. 3d). And most 2D TMDC materials could be synthesized without the limitation of substrate constraints benefited from the strong driving force generated through pyrolysis. This enables MOCVD to achieve arbitrary combinations of various thin films and substrates [57]. Additionally, MOCVD can adjust the reactant concentration by controlling the reactant partial pressures, thereby obtaining thin films with uniform electrical properties. Therefore, compared to the CVD method, the MOCVD method is more suitable for the production of high-quality, large-area 2D thin-film materials. Kang et al. reported the fabrication of 4-inch WSSC TMDC materials with high mobility (up 

© The authors 

https://doi.org/10.1007/s40820-023-01273-5 

Page 7 of 96 **119** 

Nano-Micro Lett. (2024) 16:119 



**Fig. 3  a** Schematic of a single 2-inch producing module unit and photograph of uniform  MoS2 film with wafer sizes ranging from 2-, 4-, 8- to 12-inch. Reproduced with permission [42]. Copyright (2023), Science China Press. **b** Schematic illustration of the  MoS2 growth process on Au (111) substrate and representative μ-LEED pattern and photograph of a 1-inch uniform single-crystal  MoS2 monolayer. Reproduced with permission [43]. Copyright (2020), American Chemical Society. **c** The relation between CVD temperature and  MoS2 mobility in several reports [19, 44–52]. **d** Schematic illustration of the MOCVD process. Reproduced with permission [44]. Copyright (2021), Wiley–VCH. **e** Optical images of exfoliated  MoS2 on  SiO2/Si, sapphire, and plastic film. Reproduced with permission [53]. Copyright (2020), Springer Nature 

to 30  cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> at room temperature) using the MOCVD method [58]. Furthermore, MOCVD exhibits excellent process compatibility, enabling heterogeneous integration growth with LEDs while allowing for direct epitaxial growth at lower temperatures, making it highly compatible with CMOS technology [59]. Recently, scientists from MIT have proposed a 

low-thermal-budget synthesis method that enables the lowtemperature rapid growth (< 300 ℃ , growth time < 60 min) of single-layer  MoS2 with a size of up to 200 mm and a high carrier mobility of 35.9  cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> . This breakthrough was achieved by separating the low-temperature growth zone from the high-temperature sulfur precursor decomposition zone 

1 3 

**119** Page 8 of 96 

Nano-Micro Lett. (2024) 16:119 

[46]. However, the toxicity of commonly used precursors in MOCVD, like Mo(CO)6,  H2S, is one of the main limiting factors for their widespread adoption, and further exploration is still required [60]. 

##### **_3.1.3  Mechanical Exfoliation Method_** 

The mechanical exfoliation method is a technique that exploits the layered characteristics of 2D materials to achieve interlayer mechanical separation. The resulting 2D materials can retain a high degree of crystal structure and crystallinity, making them suitable for the preparation of small-area, high-quality single-crystal materials. Additionally, the operation and required equipment for this method are relatively simple, making it an important approach in current research for exploring novel structures or properties of 2D devices. To further increase the size of exfoliated 2D materials, enhancing the adhesion between the crystal source and substrate is a crucial prerequisite. Some noble metals, such as Au and Ni, have been proven to assist in achieving the large-area exfoliation of 2D materials [53, 61]. Y. Huang et al. introduced a one-step, and universal Au-assisted mechanical exfoliation method and successfully isolated 40 types of single-crystalline monolayers, most of which are millimeter-size and high-quality [53] (Fig. 3e). Although the scale of exfoliated 2D materials is extended to a considerable size, the repeatability and uniformity of the improved exfoliated method are still not guaranteed. On the other hand, the size and crystallinity of the source crystals are also critical factors limiting the scalability of the process. To achieve industrial-scale manufacturing in the future, it will be necessary to develop improved exfoliation processes and techniques for the fabrication of wafer-level single-crystal source materials. 

of WSSC 2D materials remains a formidable undertaking. However, it is crucial to acknowledge that not all applications mandate the utilization of high-quality, large-area single-crystal materials. The exceptional flexibility, high surface area, and sensitivity intrinsic to 2D materials render them suitable not only for applications in logic chip manufacturing but also for the development of flexible devices, sensors, wearable technology, and more [62]. These applications exhibit relatively lower demands regarding material quality [63]. Several cost-effective and scalable methods have been proposed, including liquid-phase exfoliation [64], screen printing [65], and inkjet printing [63], among others. These approaches possess the capability of waferscale fabrication, and some printing techniques facilitate patterned design as well. They offer significant advantages in terms of batch production, exfoliation efficiency, and product dimensions. 

In summary, the fabrication of WSSC 2D materials remains a significant challenge in the current development of 2D chips. Researchers have been working on improving existing processes from various angles, including material growth mechanisms, source material selection, and process optimization, particularly in the case of CVD methods. Some progress has been made, but further enhancements are needed in terms of stability, scalability, and manufacturing cost. Additionally, unconventional growth strategies, such as geometric confinement [66] and defect engineering [16], have been proposed to address the limitations of material growth. Moreover, for applications that have relatively lower material quality requirements, some unconventional yet economically viable methods for 2D material fabrication, like printing techniques and liquid-phase exfoliation, hold promise for driving the industrialization of 2D materials [67]. Therefore, it is essential to continue refining the fabrication techniques for WSSC 2D materials while promoting the development of high-performance, cost-effective, and versatile devices based on 2D materials. 

##### **_3.1.4  Other Methods_** 

Currently, the methodologies employed for the synthesis of WSSC monolayer TMDCs remain in a nascent stage of development. Factors such as production cost and the stability of manufacturing processes pose significant challenges, necessitating further dedicated research and optimization efforts for their prospective industrial-scale production. It is worth emphasizing that the cost-effective fabrication 

##### **3.2  FET Engineering Approaching the Theoretical Limit** 

The urgent requirement for the application of 2D materials into chips boosts the research enthusiasm and development of FET engineering. Many studies have endeavored to exploit the unique structure of 2D materials for 

© The authors 

https://doi.org/10.1007/s40820-023-01273-5 

Page 9 of 96 **119** 

Nano-Micro Lett. (2024) 16:119 

the development of novel miniaturized transistor devices, aiming to achieve the ultimate scaling of gate length or channel dimensions. Simultaneously, device performance optimization has been pursued through the optimization of dielectric layer integration and electrode integration techniques. In this part, we will elucidate the approaches for the ultimate optimization of 2D materials from three perspectives: device structure, dielectric layer integration, and contact engineering. 

##### **_3.2.1  Device Configuration_** 

Currently, the typical structures of 2D FETs are top-gated and bottom-gated 2D FETs, which have been widely used for research on the basic properties of layered materials [13, 68]. And bottom-gated 2D FETs can be further divided into global back-gated FETs and buried-gated FETs. Based on these single-gate structures, efforts have been devoted to the size scaling process. In terms of scaling _L_ g (length of the gate electrode), Desai et al. demonstrated  MoS2 transistors with a 1-nm physical gate length using 1D single-wall carbon nanotube (CNT) as the gate electrode [33]. Moreover, a recent report about the application of 2D single-layer graphene has scaled the  Lg down to the physical limit. The 0.34 nm thickness of graphene can be regarded as the shortest _L_ g, which approaches the physical limit among the known materials [69]. When it comes to the scaling down of _L_ ch (length of the channel layer), diverse processing methods have been developed to decrease the _L_ ch such as aluminum selfoxidization technology [70], shadow evaporation method [71], crack formation [72, 73], h-BN spacer [74], and vdW metal electrodes transfer method (Fig. 4) [75]. R. Wu et al. demonstrated sub-100-nm-Lch bilayer tungsten diselenide (WSe2) transistors using vdW epitaxy and controlled crack formation processes. The 20-nm-long  WSe2 transistor shows comparable performance to silicon transistors under similar channel lengths and driving voltages [72]. L. Liu et al. fabricated the sub-1-nm  MoS2 vertical transistors through the low-energy vdW metal integration technique. Similar to the above-mentioned graphene-gated transistors utilizing the intrinsic thickness of 2D materials, this report utilized the 0.65-nm-thick  MoS2 as the vertical channel layer with  Ion/off of ~ 26 [75]. The poor switching performance can be attributed to the SCEs and strong tunneling effect in the off-state. 

To further enhance the gate-control performance of 2D transistor devices, several emerging structures applied in advanced process nodes such as double-gate FET (DGFET) [76], FinFET [77], gate-all-around FET (GAAFET) [78], and complementary FET (CFET) [79] have also been proposed in 2D technology against SCEs. Dorow et al. fabricated DGFETs by optimized atomic-layer-deposition (ALD) process for 2D material surfaces. A steep SS of 75 mV  dec<sup>−1</sup> and a low DIBL of 12 mV  V<sup>−1</sup> were achieved owing to the enhanced electrostatics from double gates and high-quality gate oxide layer [80]. In 2022, the first GAA monolayer MoS2 nanosheet FET was demonstrated by TSMC. And the performance is remarkable with 410 μA μm<sup>−1</sup> _I_ D at 1V _V_ D at 40 nm gate length and nearly zero DIBL that opens the path for stacked sheet GAA devices using 2D materials [78]. The clean surface of 2D materials makes it an ideal candidate for 3D stacking technology in the future. When it comes to 2D FinFET, the first demonstration was fabricated by the template-growth method, while the device performance was unsatisfactory with SS obtained to be 300 mV dec<sup>−1</sup> and extracted mobilities to be in the range of 1 ~ 6 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> [81]. Recently, another 2D FinFET based on Bi2O2Se/Bi2SeO5 epitaxial heterostructures was reported. This FinFET exhibits exciting performance including high electron mobility up to 270  cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , ultralow _I_ off down to ~ 1 pA μm<sup>−1</sup> , and high _I_ on/ _I_ off up to  10<sup>8</sup> [77]. The inspiring results open up new avenues for the further extension of Moore’s law. However, it should be noted that most of these emerging structures used electron beam lithography (EBL) to pattern electrodes and channel layers, which are expensive and time-consuming. More consideration should be focused on its compatibility with Si-based processes and the feasibility of large-scale production. Simultaneously, the optimization of individual devices remains insufficient; the considerations of universality, process repeatability, and the potential for significant enhancement of integration density must also be taken into account. 

##### **_3.2.2  Dielectric Integration_** 

To achieve device size miniaturization, simultaneous progress is required in the development of complementary 2D dielectric systems in parallel with channel materials. Moreover, the atomic-level thickness channels are more sensitive to the interface with gate dielectric, which limits 

1 3 

**119** Page 10 of 96 

Nano-Micro Lett. (2024) 16:119 



**Fig. 4** Typical strategies for ultra-scale transistors. Channel engineering: **a** Sub-1-nm  MoS2 vertical transistors fabricated by transferred vdW metal electrodes [75]. **b** Ultrashort vertical-channel vdW semiconductor transistors [74]. **c** Channel defined by controlled crack formation (natural) [72]. **d** 10 nm short channel transistor fabricated by self-oxidization of aluminum [70]. **e** Channel defined by controlled crack formation (etching) [73]. **f** Ultrashort  MoS2 transistors fabricated by shadow evaporation [71]. Gate engineering: **g** buried CNT gate with a diameter of 1nm [33]. **h** Sidewall graphene edge gate with sub-1-nm thickness [69]. **i,j** 2D FinFET and GAAFET [77, 78]. **k** Complementary FET comprising p-type  WSe2 FET and n-type  MoS2 FET [79] 

further improvement of device performance [82]. Therefore, researches about dielectric integration of 2D FETs are focused on two aspects: One is the search for low equivalentoxide-thickness (EOT) dielectric materials, and the other one is the optimization of preparation methods and interface quality. 

As the downsizing of transistor’s size, the decrease of gate oxide thickness is also one of the critical technologies. Unfortunately, the relatively low permittivity of  SiO2 (εr ≈ 3.9) limits its application in FETs with gate lengths scaled down to sub-10 nm [83]. Thus, novel gate dielectrics with higher dielectric constants should be developed. After decades of search for the appropriate high-k materials, Hf-based oxides, such as  HfO2 (κ ≈ 19), stand out as the first-generation CMOS products, which are also commonly used materials in 2D technologies [84]. Whereas, considering the continuous scaling requirements and possible damage to the channel materials from the deposition process, further efforts have been devoted into the development of 2D dielectrics. 2D vdW insulators, in which atomic layers are stacked via vdW interaction, are regarded as the ultimate solution for dielectric miniaturization. h-BN has been 

widely investigated in 2D transistors as a dielectric layer. The preparation of h-BN has achieved wafer-level and is used for device arrays [85]. However, the excessive tunnel currents through ultrathin h-BN limit its further application in nanoscale 2D devices [86]. Besides, several emerging 2D insulators, like  CaF2,  Bi2SeO5, and  SrTiO3, are explored and exhibit excellent dielectric performance [34, 87, 88]. For example, Zhang et al. created top-gated 2D transistors with sub-0.5-EOT dielectrics,  Bi2SeO5 (κ =  ~ 22), and exhibit leakage current below the low-power limit of 0.015 A  cm<sup>–2</sup> at 1 V gate voltage [89]. Furthermore, the proper range should be estimated in conventional Si MOSFET due to the effects of both drain-induced barrier lowering and fringinginduced barrier lowering (FIBL). However, benefiting from the vdW gap between 2D semiconductors and dielectrics, the unfavorable FIBL effect is mitigated [87]. 

To help improve 2D materials’ actual performance, the optimization of the preparation process and improvement of interface quality are another important issue. ALD is a common method to prepare a dielectric layer which has been applied in industrial production [90], while, due to the dependence of chemical reactions on surface dangling bonds 

© The authors 

https://doi.org/10.1007/s40820-023-01273-5 

Page 11 of 96 **119** 

Nano-Micro Lett. (2024) 16:119 

and nucleation sites, corresponding requirements are put forward for the substrate materials. Considering the clean surface of 2D materials and the existence of organic residues during the transfer process, it is necessary to introduce the optimized ALD method to improve the uniformity and quality of dielectric layer growth [91]. 

Many interfacial activation layers and processes have been developed for the uniform deposition of high-κ oxides on 2D materials including chemical pretreatment of the surface and the introduction of a seeding layer. For example, Li et al. presented a technique to integrate ultrathin high-κ dielectric (EOT =  ~ 1nm) on 2D materials using a PTCDA molecular crystal as a seeding layer. The resulting PTCDA/ HfO2 gate dielectric exhibits low leakage current and high breakdown field, meeting the ITRS requirement for lowpower devices [92]. When selecting a seeding layer for depositing high-κ dielectrics on 2D channels, it is crucial to consider its potential impact on the properties of the channel materials. The ideal seeding layer should help form a uniform and conformal interface with the dielectric without sacrificing the performance of the channels. When it comes to the pretreatment method, functional groups and dangling bonds are introduced by using plasmas [93]. Although this method avoids the introduction of additional layers, the physical plasma damage would result in the degradation of device performance attributed to bond disruption and alignments [94]. In addition to ALD, several gentler integration methods are also developed to minimize the damage to 2D layers like native oxide method and the transfer of waferscale insulators [95]. Certainly, the issues that need to be considered are still the scalability of methods, the uniformity of material quality, and compatibility with current Si-based technologies. 

##### **_3.2.3  Contact Engineering_** 

As a bridge connecting 2D materials with a three-dimensional system, contacts in 2D devices are one of the key aspects to be considered when exploring the electronic properties of 2D materials. The difference in electronic energy levels and lattice structures between the electrode material and 2D material leads to electron transfer and the formation of new interface states, i.e., metal-induced gap states (MIGS). The MIGS results in the Fermi level of 2D materials being pinned to a specific position, known as the Fermi 

level pinning (FLP). In addition, impurities and interface defects introduced by electrode deposition can also lead to substantial contact resistance. These restrict electron flow and adjustment of contact potential, leading to hysteresis or current saturation in transistor devices, the inability to achieve bipolar transport, an increase in device leakage current, and slower switching speeds [99]. Therefore, achieving high-quality contacts in 2D devices is very important, which can help exhibit the expected excellent performance of 2D materials. 

Currently, there are three main strategies for improving contacts: adopting novel contact materials, optimizing the interface structures, and developing new contact processes. Figure 5 summarizes some novel technologies for achieving high-quality contacts. And the development of novel contact materials is a highly active research direction for suppressing MIGS and lowering Schottky barriers in FETs. Among the various metals and semimetals, Scandium (Sc) [100], Bismuth (Bi) [97, 100], and Antimony (Sb) [101] have been successfully verified to effectively optimize the contact conditions. Specifically, Shen et al. demonstrated that the orbital resonance between Bi and  MoS2, along with the near-zero density of states at Fermi level, enabled the fabrication of Bi-MoS2 FETs with reduced contact resistance reduced (123 Ω μm) and improved carrier concentration (1.5 ×  10<sup>13</sup> cm<sup>–2</sup> ) [97]. Similarly, Li et al. reported that the band structure of Sb (0112) overlaps well with  MoS2, which can be further enhanced by strong vdW forces. As a result, the use of Sb as a contact material in 2D FETs led to a significant reduction in contact resistance (42 Ω μm) and a high _I_ on/ _I_ off over 10<sup>8</sup> . Notably, these performances outperformed equivalent silicon CMOS technologies and met the 2028 roadmap target [101]. We could find that by selecting appropriate electrode materials, excellent electrical properties such as low contact resistance can be achieved. However, it is important to evaluate the stability and consider its applicability to other 2D materials. And it is crucial to take into account issues like cost and process compatibility, particularly for large-scale manufacturing. 

Besides, interface modification is considered a viable strategy for mitigating contact resistance, with phase engineering gaining widespread attention due to its strong process compatibility. It has been experimentally observed that some 2D materials like  MoS2,  MoTe2,  MoSe2, and other TMDCs demonstrate varying characteristics in different phases. Utilizing this theory, researchers have proposed 

1 3 

**119** Page 12 of 96 

Nano-Micro Lett. (2024) 16:119 



**Fig. 5** Typical optimized contact strategies for 2D transistors. **a** Introduction of a seeding layer for contact integration or improving contact quality [92]. **b** Doping of contact region or pretreatment of the interface [93]. **c** VdW integration process [96]. **d** Development of novel materials such as semi-metal contact [87, 97]. **e, f** Novel contact modes, filament contact, and edge contact [40, 98] 

phase engineering to reduce FLP and lower the Schottky barrier height (SBH). Various techniques have been proposed and investigated to induce phase transitions, including laser-induced phase patterning [102], electrostatic doping [103], argon (Ar) plasma processing [104], and so on. For instance, laser-induced phase patterning and Ar plasma handling achieve the transition of TMDCs from 2H to 1 T phase through the introduction of chalcogen vacancies. An atomically sharp interface and similar WF between 2H and 1 T phase result in a low contact resistance. Furthermore, these methods are compatible with standard lithography techniques, allowing for the formation of clean homojunctions and mitigating contamination by extraneous chemical components [102, 104]. It is noteworthy, however, that some chemical processing steps can introduce defects and impurities in TMDCs [105]. Additionally, it is essential to recognize that physical methods may not be readily adaptable to large-scale preparation. Moreover, in the pursuit of establishing more durable and dependable interfaces, research endeavors can be directed toward investigating approaches and mechanisms to stabilize the thermodynamically metastable phases of TMDCs [99, 105]. 

Apart from utilizing the inherent properties of the materials, altering the mode of contact represents a methodology for optimizing contact resistance. VdW integration is thought to be a promising strategy for addressing the FLP phenomenon, which is attributed to the presence of surface 

dangling bonds and surface reconstructions. This integration mechanism facilitates the establishment of a physical connection between materials without direct chemical bonding. To date, several methods have been employed to realize vdW contacts, including the growth of buffer layers [106] and physical transfer techniques. For instance, Liu et al. demonstrated a method in which metal electrodes were fabricated on sacrificial substrates. Through a pretreatment procedure, the metal layers were detached from the sacrificial substrate using PMMA and then physically bonded to 2D semiconductors. This approach enabled the attainment of high carrier mobility levels that are compatible with vdW graphene hybrid contacts and strong contact doping [107]. Nevertheless, it is important to highlight that as devices continue to shrink in size, achieving precise alignment between materials becomes increasingly challenging. Additionally, the weak bonding of vdW contact may lead to the deviation of metal electrodes, consequently introducing variations in device performance [108]. 

Except for strategies mentioned above, novel techniques have been put forward to lower the contact resistance. Notably, in 2013, Wang et al. first introduced a novel methodology that used  O2 and  CHF3 plasma etching on a BN-graphene-BN stack, followed by the deposition of metal leads at the stack’s edge, establishing direct electrode contact with the edge of graphene. This 

© The authors 

https://doi.org/10.1007/s40820-023-01273-5 

Page 13 of 96 **119** 

Nano-Micro Lett. (2024) 16:119 

strategic configuration facilitated more efficient carrier injection in comparison with conventional top contacts, thereby yielding reduced resistance [109]. Nevertheless, it is imperative to acknowledge that the stability and fabrication complexity of edge contacts present ongoing challenges [110], prompting extensive research efforts aimed at enhancing their performance, such as the combination of reactive ion etching, in situ  Ar<sup>+</sup> sputtering and annealing [111] and heterostructure growth [112]. Furthermore, an innovative filament contact approach has emerged as a promising avenue for achieving sub-10 mV  dec<sup>−1</sup> subthreshold swing (SS) and high on-current, thus offering a novel strategy for addressing the contact resistance issue [40]. 

In summary, as the prerequisite for harnessing the full potential of 2D materials, realizing good electrical contacts remains the focus field of 2D technology. Numerous strategies aimed at enhancing contacts have been proposed and have yielded significant results. Nevertheless, there are still several factors that demand consideration: (1) The scalability of contact methods, assessing whether the chosen materials or techniques possess broad applicability across different types of 2D materials while remaining cost-effective; (2) Uniformity and compatibility, ensuring that the selected methods compatible with other processes, maintain device uniformity during large-scale production and support circuitlevel applications; (3) The scalability of these methods, as most research directions mentioned earlier still operate at the micrometer scale for electrode sizes. Given the ongoing trend of device size reduction, contact-related challenges will become increasingly prominent. Therefore, the development of devices with nanoscale footprints holds equal importance. 

##### **3.3  Material Transfer and Integration** 

A plethora of studies have reported the fabrication of 2D material-based electronic devices with excellent performance, such as low contact resistance, low leakage current, high on-state current, and short _L_ g [69, 72, 76]. However, it remains uncertain whether such superior device performance can be replicated when scaling up to wafer-scale ICs produced through CVD. Due to the atomic layer thickness and delicate lattice of 2D materials, achieving large-scale integration of 2D devices should fully consider device yield, 

device-to-device variability, stability, and reliability. Such considerations must account for defects inherent to the 2D materials themselves, including vacancies, impurities, wrinkles, and thickness fluctuations, as well as external environmental factors such as changing trap states or residual organic materials. These fluctuations can result in deviations in device performance, ultimately leading to logic function errors, device failure, and decreased device yield [41]. 

So far, several strategies have been reported to form atomically flat interfaces and reduce the surface states from defects, residues, and strains on the 2D semiconductors. For example, to overcome the interface damage and FLP induced by high-energy metal deposition and lithography processes. Wafer-scale vdW integration method has attracted widespread attention. Liu et al. achieved vdW contact between metal and 2D semiconductor by spin-coating a decomposable poly (propylene carbonate) (PPC) as a buffer layer (Fig. 6a). And this method can be readily applicable to different metals and semiconductors [113]. Qi et al. demonstrated an approach of graphene-enhanced vdWs integration, which was realized by the physical transfer of 2D monolayer graphene/3D metal heterojunctions onto 2D semiconductors. The method exhibits a maximum resolution capability at the nanometer scale while yielding a device array with a near-perfect success rate of ~ 100% (Fig. 6b) [96]. The vdW integration method is characterized by its facile integration process, universal applicability, and capacity for enhancing device design flexibility. Nevertheless, the challenge of achieving higher alignment accuracy for small-sized electrodes and higher-density integration needs to be addressed. Moreover, the weak vdW forces demand careful consideration of potential structural deviation or performance degradation caused by subsequent processes, especially those involving high temperature. Additionally, the multiple steps of contact and release during the integration process may introduce unwanted defects or oxidation which necessitates further investigation and exploration of these issues. 

In addition to the metal deposition, the presence of organic residue from polymer-assisted transfer process represents another source of defects. So far, the types of CVD growth substrates for 2D materials are still limited and the transfer process is indispensable. The most commonly used approach currently is to utilize PMMA as a supporting layer for protecting the 2D materials from tension and perturbation. And the insufficient removal of supporting polymer films will degrade the material quality [117]. Better cleaning 

1 3 

**119** Page 14 of 96 

Nano-Micro Lett. (2024) 16:119 



**Fig. 6  a** Wafer-scale vdW integration processes with four steps and optical images of large-scale vdW contacts. Reproduced with permission [113]. Copyright (2023), Springer Nature. **b** Schematic illustration of graphene-enhanced vdWs integration. Reproduced with permission [96]. Copyright (2023), Wiley–VCH. **c** Illustration of the ice-cleaning process. Reproduced with permission [114]. Copyright (2023), Wiley–VCH. **d** Illustration of techniques and mechanism of the crack-free transfer techniques. Reproduced with permission [115]. Copyright (2022), Springer Nature. **e** Variability analysis of multiple parameters of hundreds of  MoS2 FETs. Reproduced with permission [116]. Copyright (2017), American Chemical Society 

methods should be developed. Zhao et al. incorporated oxhydryl groups-contained volatile molecules into PMMA, which can be deformed under heat. The optimized supporting films could achieve a controllable conformal contact without cracks, contamination, and wrinkles (Fig. 6d) [115]. In addition to improvements to traditional organic-assisted transfer methods, Liu et al. proposed novel ice-aided transfer and ice-stamp transfer methods, which utilize the controllable adhesion between ice and various 2D materials. And the new transfer methods can yield ultrahigh quality and exceptional cleanliness (Fig. 6c) [114]. Furthermore, dielectric 

integration is another critical factor that affects device yield. Several researchers have attempted to adjust process steps to improve the interface quality. The gate-first process, which fabricates all the critical components before the  MoS2 transfer step, is believed to reduce variability effectively compared with gate-last process [118]. 

The integration process of 2D materials is exceedingly complex and currently immature, involving numerous process steps and parameters. On the one hand, it is necessary to establish an appropriate evaluation system to assess the impact of various parameters on device variability. Smithe 

© The authors 

https://doi.org/10.1007/s40820-023-01273-5 

Page 15 of 96 **119** 

Nano-Micro Lett. (2024) 16:119 

et al. fabricated and measured hundreds of back-gate  MoS2 FETs and gave a statistical evaluation of the key parameters (Fig. 6e) [116]. This can aid in designing appropriate redundancy in critical parameters and structures to mitigate the effects of variability. On the other hand, it is worth considering the incorporation of machine learning techniques to assist in analyzing and optimizing the preparation process of 2D materials, assisting in the selection of optimal preparation conditions, and accelerating the iteration speed of device processes. 

##### **3.4  2D Package** 

Electronic packaging is one of the essential steps in chipscale integration, serving multiple functions such as signal interconnection and chip protection. However, due to the predominant focus of 2D materials research on the device level and small-scale circuits, there is still relatively limited research dedicated to the packaging of 2D chips. Considering the air sensitivity of 2D materials and their relatively limited voltage tolerance, research and development of 2D packaging technologies remain crucial. In this section, we provide a summary of the current research related to the packaging of 2D devices. 

##### **_3.4.1  Signal Interconnection_** 

Wire bonding was always used to achieve the electrical interconnection between 2D device and printed circuit board (PCB) since it was usually applied in small I/O numbers at low cost. Smith et al. [119] reported that the graphene pressure sensor and humidity sensors were wire bonded to the substrate in the ceramic dual inline package (DIP). Similar work has been reported in Susan’s work [120]. They used 25-μm-thick AlSi wires to connect the optoelectronic devices based on graphene with Ti/Ag contacts to PCB. 

With the I/O of devices based on 2D materials increasing, flip chip technologies can be used in the packaging of 2D devices, which needs further study on the adhesion of 2D materials on the substrate. With more I/O and high performance needed, Chiplets [121], 2.5-dimensional integration [122], and three-dimensional integration [123] can also be adopted to achieve the large-scale integration and improve the integration density. 

##### **_3.4.2  Chip Protection_** 

Protecting layer before packaging: Compared to the traditional semiconductors, most 2D materials exhibit heightened sensitivity to water and oxygen when they are exposed to the ambient air owing to their elevated surface-to-volume ratio [124]. For example, it has been demonstrated that BP is highly reactive to oxygen and water exposed to ambient air, leading to degradation in the electronic and optical properties [125]. Consequently, the encapsulation strategies for 2D materials discussed in the work involve the creation of a protective layer that isolates 2D material from oxygen and water in the air to prevent the reaction. 

The protecting layer encapsulated on 2D materials is primarily divided into organic and inorganic protective layers. Polymethyl methacrylate (PMMA) [126], polyvinyl pyrrolidone (PVP) [127], fluoropolymer CYTOP [128], and parylene C [129] were commonly used as the organic protective layers to protect 2D materials. For example, Jia et al. [130] and Li et al. [131] reported that the PMMA-encapsulated BP FETs exhibit high stability over several weeks and achieve a high field-effect mobility up to 1150  cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> . Besides PMMA, the other organic materials also process the same function to protect 2D materials in ambient air. 

Besides organic protective layer, the inorganic protective layer was commonly used to protect 2D materials. Oxide (Al2O3) [132], zirconium oxide  (ZrO2) [133], and hafnium dioxide  (HfO2) [134] were the most widely materials with the deposition process of atomic layer deposition (ALD). For example, Li et al. [135] directly encapsulated  MoS2 FETs with  Al2O3 by ALD, and then, the  MoS2-based FETs had a high  Ion/Ioff ratio exceeding  10<sup>8</sup> and the mobility around 70  cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> at room temperature.  ZrO2 and  HfO2 are also used to protect h-BN and  MoS2 to improve the device’s performance. 

**Other protections in the packaging and its perspective:** When 2D devices are used in the high-performance memory, molding compound as the package must be used in the future. However, there is still a relatively limited amount of research. Effects of the warpage and stress during the molding process on the 2D devices are worthy of deep studying. 

Electrostatic discharge (ESD) protection is another concern for the packaging of 2D devices. The nano-electronicsbased 2D materials process high _I_ on/ _I_ off ratios in FETs [13] and band gap tunability [136]; thus, it has been widely used 

1 3 

**119** Page 16 of 96 

Nano-Micro Lett. (2024) 16:119 

in low-power transistors [137], sensors [138], and photodetectors [139]. Meanwhile, the 2D materials also can withstand high breakdown voltage. For example, the breakdown voltage of  MoS2 semiconducting gate (SG) FET is 408 V [140]. Thus, 2D devices provide a large design window for ESD protection. 

However, there is a lack of strategies for ESD protection of 2D devices. Thus, we make prospects of ESD protection way based on Si devices: firstly, designing a switch around the device that can be precisely controlled such as a nanophase-switch [141] and gNEMS ESD switch [142] and secondly designing a protection structure in the PCB to discharge any ESD transients such as setting a mixed-mode ESD protection circuit [143] and dual-polarity nano-crossbar array ESD protection structure [144] of the device based on 2D materials. It is worth noting that 2D materials can withstand high breakdown voltage; thus, their ESD protection can be installed on PCB. 

With the development of devices based on 2D materials, their package become more important for application. Therefore, we need more research on package of devices based on 2D materials to achieve the holistic development of 2D materials application. 

### **4  2D Materials for Digital and Analog Chips** 

Integrated circuit (IC) technology breaks the separation of devices and wires in traditional electronic technology, leading the trend of electronic components and lines and even the whole system toward integration [1]. Among all kinds of circuits, digital and analog circuits are the two main streams. Compared to bulk silicon, the ability to achieve extremely thin channels is the most distinctive advantage of 2D materials [145]. This characteristic naturally provides 2D materials with atomically thin channel lengths, excellent electronic transport properties, lower carrier scattering, and tunable band structures [146] in the fabrication of digital and analog ICs, where these advantages offer unique opportunities and potential for the application of 2D materials in the field of IC. 

Transistors serve as the dominant functional devices, whose performance is critical to circuits. Taking the central processing unit (CPU) as an example, as shown in Fig. 7a, the interior of CPU is almost N-type metal–oxide–semiconductor (NMOS) and P-type metal–oxide–semiconductor (PMOS) 

FETs, and other circuits can also be realized based on them. As shown in Fig. 7b, in _I_ DS- _V_ GS curve, we can easily find that each gate-controlled transistor has four working regions. The cutoff region and the variable resistance region are often used in digital circuits to conduct on–off state converting, and the subthreshold region and saturation region are often used in analog circuits through special electrical connections. Based on transistors prepared with 2D materials mentioned above [72, 97, 101, 107], small-scale circuits and large-scale circuits with relatively complex data processing abilities can be fabricated. Furthermore, 2D materials can be easily combined with or stacked with other materials to form composite structures or heterostructures enabling the integration of multiple functions into a single chip. 

In this section, we will first review the recent research progress of 2D materials in digital and analog circuits, respectively. Then, we will combine the development history of traditional silicon-based CMOS circuits to further summarize the status of digital and analog circuits based on 2D materials and give a design flow chart that can be used for future research. Based on the above content, we finally make an outlook for digital and analog chips based on 2D materials. 

##### **4.1  2D Digital ICs** 

Given the essential requirements of high switching speed and low power consumption in digital ICs [147], 2D materials offer significant advantages as they have high carrier mobility, excellent electron transport properties, mediate bandgaps, low electron scattering, as well as flexibility and scalability. Compared with analog ICs, digital ICs mostly use transistors, which is conducive to the completion of preliminary 2D circuit design, to establish logic gates with less utilization of capacitors and inductors, and different logic gates are then employed to achieve arithmetic computation. Therefore, the most likely form of mass production of large-scale circuits based on 2D materials is digital chips. The large-area synthesis of 2D materials and the continuous improvement of the performance of 2D transistors mentioned above have created important prerequisites for the fabrication of 2D digital ICs. However, the optimization of transistors is not the ultimate goal, and more important is the working performance of transistors in practical circuits. Therefore, in the past 5–10 years, more 

© The authors 

https://doi.org/10.1007/s40820-023-01273-5 

Page 17 of 96 **119** 

Nano-Micro Lett. (2024) 16:119 



**Fig. 7  a** Schematic illustration of the enlarged interior of the CPU and applications of transistors, where transistors serve as the dominant functional devices. **b** Transfer characteristic curve of transistors with four working regions suitable for digital or analog circuits: cutoff, subthreshold, variable resistance, and saturation. X-axis is the gate–source voltage, and y-axis is the drain–source current in logarithmic (left y-axis, red line) and linear (right y-axis, blue line) coordinates 

and more researchers focused on digital circuits based on 2D transistors, small-scale logic circuits [118, 148, 149], memory chips [150–153], microprocessor [20], and so on, which have been demonstrated. 

##### **_4.1.1  Logic Function Realization_** 

To achieve logic functions, the fundamental components of a circuit are various logic gates (AND, OR, NOT, XOR, XNOR, etc.). Since inverters are the most basic and simplest modules among various logic gates, we first start with some inverters based on 2D materials and review the research progress of small-scale logic circuits at the same time. 

Inverters realized with 2D MOSFET mainly have three types, including NMOS-only, PMOS-only and CMOS. As shown in Fig. 8a, NMOS-only and PMOS-only inverters use two transistors of the same type above and below, and only one of these two transistors is energized at a time. The other transistor’s gate electrode and source electrode are shorted together as a pull-up or pull-down resistor load. CMOS inverter is formed by connecting the drain electrode of NMOS with that of PMOS. Graphene, as the first 2D material synthesized by humans [25], served as the foundation for early research on 2D logic circuits. Floriano Traversi 

et al. [154] fabricated a complementary logic inverter by integrating p-type and n-type transistors on the same monolayer graphene in 2009, where the Boolean inversion function was obtained by Dirac points modulation. Although this inverter’s voltage gain was only 0.044 and its operating bias was as high as 10 V due to the operation through a conventional silicon bottom gate, limited for direct cascading because of the bad drive capacity, it showed the feasibility of using graphene to form digital circuits. To make full use of the ambipolar feature of graphene for practical use, Song-Lin Li et al. conducted a variety of explorations. In 2010, the first example of graphene voltage inverters with voltage gain up to 4–7 was demonstrated by them [155]. They resolved the issues of bottom-gated-based graphene by employing high-efficiency top gate stacks with natural alumina as the dielectric layer. One year later, they developed graphene logic devices advanced than inverters with electrostatic doping method, introducing a bandgap into the channels and fulfilling elementary NOR and NAND logic gates on bilayer graphene (BLG) channels [156]. 

However, pristine graphene’s inherent zero bandgap structure will increase fabrication complexity if we need p-type and n-type transistors simultaneously. Early logic circuits adopted 2D transistors of the identical conductivity type and 

1 3 

**119** Page 18 of 96 

Nano-Micro Lett. (2024) 16:119 



**Fig. 8  a** Circuit schematic diagram of a resistor-load inverter and NMOS-load inverter. When the NMOS-load inverter works, only one transistor is active, and the upper transistor acts as a resistor. Similarly, the PMOS-load inverter has a similar structure. **b** Mechanically exfoliated monolayer  MoS2 flake (upper) and the schematic illustration of monolayer  MoS2 NMOS inverter (bottom). Reproduced with permission [167]. Copyright (2011), American Chemical Society. **c** Voltage transfer characteristics of a monolayer  MoS2 logic inverter with corresponding voltage gain. Reproduced with permission [167]. Copyright (2011), American Chemical Society. **d** False color optical image of the inverter (scale bar = 4 µm). Reproduced with permission [158]. Copyright (2014), AIP Publishing. **e** Structure of ambipolar EDLTs with ion-gel thin-film coupling based on monolayer CVD-MoS2 onto a sapphire substrate. Reproduced with permission [159]. Copyright (2016), WILEY ‐ VCH Verlag GmbH & Co. KGaA, Weinheim. **f** Optical microscope image of the large-scale chip of  MoS2 devices and circuits. The white dashed box is CVD graphene as electrodes and interconnects and the red dashed box is control devices and circuits using Ti/Au electrodes in adjacent. The scale bar is 500 μm. Reproduced with permission [164]. Copyright (2014), American Chemical Society. **g** Photos of large-area CVD-ReS2 logic circuits after patterning process (scale bar = 500 µm). Reproduced with permission [165]. Copyright (2017), American Chemical Society. **h** Optical microscope image of 1-bit  MoS2 microprocessor with circuit schematics of D-Latch and ALU. The scale bar is 50 µm. Reproduced with permission [20]. Copyright (2017), Springer Nature 

the fabrication of 2D NMOS transistors is more mature than that of PMOS [13, 157], so only NMOS technique was really 

popular at that time. Its simple circuit topology allows for fast switching times and low power consumption compared 

© The authors 

https://doi.org/10.1007/s40820-023-01273-5 

Page 19 of 96 **119** 

Nano-Micro Lett. (2024) 16:119 

to other types of inverters that require complementary MOSFETs or ambipolar transistors. In 2011, Branimir Radisavljevic et al. [13] fabricated the first  MoS2-based logic inverter by connecting two top-gated n-type 2D transistors, as shown in Fig. 8b, enhancing the voltage gain to 4 directly (Fig. 8c), in which single-layer  MoS2 exfoliated from bulk crystals served as the channel material. This work provided ideas for the implementation of digital logic in 2D materials at room temperature and could open the way to using  MoS2 for applications in flexible electronics. Indeed, the methods mentioned above are based on mechanical exfoliation, which is reasonable for achieving high-quality samples, especially for small-scale logic gates where large area coverage is not required. However, to realize large-scale circuits, mechanical exfoliation becomes impractical, and alternative approaches such as CVD need to be employed to achieve the growth of high-quality 2D films on a larger scale. Benefiting from the advancements in 2D material growth techniques, the first monolayer  MoS2-based inverter and circuits using CVD growth were successfully fabricated [52, 148]. By connecting a  MoS2 n-type FET in series with a  MoS2 resistor, the inverter exhibited a voltage gain close to 20 and a wide voltage operation range from 0.5 to 5 V. Moreover, the MoS2-based inverter was also integrated with NAND logic gate, presenting the capability of realizing any Boolean logic functions. 

Inverters made from single-polarity transistors have power dissipation and other limitations. Gradually, some researchers embarked on implying ambipolar 2D materials and complementary conductivity types of 2D transistors aimed at electricity energy saving, improved noise margin, wide voltage range, and so on. 2D  MoS2 flake has been applied in NMOS-only circuits, but it is still challenging to create CMOS inverters based on  MoS2. The pinning of metal Fermi level close to the conduction band of  MoS2 prevents efficient hole injection into the valence band of  MoS2, causing the unavailability of  MoS2 p-type FETs [158].  WSe2, as another significant member of TMDCs’ family, is available for both electron transport and hole transport because metal Fermi levels are pinned close to the middle of its bandgap. In 2014, a fully complementary logic inverter based on a bilayer WSe2 FET by employing contact work-function engineering and electrostatic doping was demonstrated [158]. Saptarshi Das et al. used 20-nm  SiO2 as the bottom gate dielectric to facilitate better electronic gate control and used Pd as the source/drain electrode for p-type FET and Ni as the source/ 

drain electrode for n-type FET to gain better carrier injection from metal to  WSe2, as shown in Fig. 8d. The maximum voltage gain was ~ 25, and the noise margin was close to its ideal value of ~ 2.5 V  (VDD = 5.0 V). Without connecting output and gate electrode to realize MOS-load, the identical ambipolar transistors based on TMDCs reduced power dissipation [149, 159]. Another example is shown in Fig. 8e, a quasi-CMOS inverter [159], where two single-layer  WSe2 ambipolar electric double-layer transistors (EDLTs) were connected on the same wafer-scale film, was fabricated with maximum gain up to 80 ( _V_ DD = 2.8 V, _V_ th = 1.4 V). Meanwhile, by combining p-type  WSe2 and n-type  MoS2 EDLTs, Jiang Pu et al. [159] also realized CMOS inverters among 2D materials, using ion gels as gate electrolytes, promoting the highest voltage gain of 110. In addition to utilizing the polarity characteristics of 2D materials themselves for complementary logic circuits, some researchers have recently published work on utilizing different h-BN thicknesses to modulate electrical conductivity of materials [160]. Furthermore, an increasing number of digital logic functions are being implemented on 2D materials [161–163], creating conditions for the advanced study of more complex circuits. 

##### **_4.1.2  Complex Digital Functional Circuits_** 

Complex 2D digital functional circuits, which build up a basic foundation for data processing, not only require a great number of logic gates to perform intricate logic operations but also need the establishment of combinational logic and sequential logic circuits. Therefore, the overall performance of the circuit in the case of cascades, timing, and feedback is a more important issue. To fabricate complex digital circuits, the first step involves integrating multiple logic gates together, and the following is the quantity or scale increase. Here, we present several representative works as examples to illustrate the process of implementing complex logic functions. Subsequently, we categorize and discuss the research progress in the areas of adders, static random-access memory (SRAM), and ring oscillators (RO). Finally, we provide a further overview of the largest and most functionally complex 1-bit microprocessor fabricated using 2D materials to date. 

After optimizing the discrete electronic components and their basic logic function circuits, a significant next step is the fabrication of fully integrated multistage circuits for 

1 3 

**119** Page 20 of 96 

Nano-Micro Lett. (2024) 16:119 

complex applications. In 2012, Han Wang et al. [150] demonstrated the fully integrated systems including an inverter, a NAND gate, a SRAM, and a five-stage ring oscillator based on a direct-coupled transistor logic technology. On a single sheet of bilayer  MoS2, 2 to 12 transistors were seamlessly integrated side-by-side. In 2014, Lili Yu et al. [164] demonstrated a novel scalable all-2D-material electronics platform using both CVD-grown monolayer  MoS2 and graphene, which is the first logic circuits using CVD-grown 2D heterostructures that are mass-producible. In that work, single-layer  MoS2 served as the channel material, and graphene is used as both the electrode contacts and the interconnects for the circuit system, where the tunable Fermi level in graphene allows excellent work-function match with MoS2 and hence leads to low contact resistance. Figure 8f shows the demonstration of the large-scale chip containing  MoS2-based NMOS inverter arrays and NAND gates (scale bar = 500 μm). In research [165], the gate voltage was reduced under 2 V by applying an ion gate as the gate dielectric with larger gate capacitance. Therefore, the realization of low power PMOS-only logic inverters was available. Figure 8g shows the large-area  ReS2 transistors that were successfully assembled to fabricate logic devices, such as NOT, NAND, and NOR gates. The fabrication of logic gate arrays using large-scale growth of 2D materials through CVD holds significant importance in expanding the scale of 2D digital circuits. Similar to the current mature CMOS technology, the future development of 2D circuits also requires addressing challenges in material growth over large areas and the fabrication of large-scale circuits. Additionally, considerations need to be given to simulation modeling and circuit design processes. Lili Yu et al. [118] presented a feasible approach for large-scale fabrication of  MoS2 circuits using CVD growth in 2016, focusing on the aspects of design, modeling, and fabrication. They initially utilized a gate-first process (all the components were built and optimized before transferring  MoS2) to fabricate the highly uniform enhancement-mode FETs (with mobility as high as 80  cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ) and extracted device parameters to develop Verilog-A compact models for performance prediction. Then, by constructing this computer-aided design (CAD) flow, the researchers proceeded to design combinational logic gates and sequential logic circuits (AND, OR, NAND, NOR, XNOR, latch, edge-triggered register) as well as switched capacitor converter. The co-optimization of fabrication process and circuit performance paved the way for designers to further develop 

the potential of 2D materials. On this basis, further optimization is to increase operating speed and decrease the power dissipation with complementary logic circuits. 

It is not sufficient to only achieve computational functions, and the vast amount of data generated during the computation process needs to be stored for subsequent retrieval and to facilitate further calculations. In the von Neumann architecture, a storage region is required to be integrated within the logic chip, which is commonly realized by using SRAM digital circuits. SRAM consists of a flip-flop and transmission gates, and the key to fabricating it lies in achieving stable storage units. To achieve stable storage, a low-power SRAM with 2 transistors and 2 resistors (2T2R) [152] and a wafer-scale SRAM and RO based on pseudo-NMOS [153] were successfully fabricated and tested. Here, RO is often used to generate a clock signal and provide the way for frequency measurement. The adder is another common smallsize module in digital circuits, that is composed of multiple logic gates and flip-flops. Due to the similarity between these two modules, some researchers tend to realize adders and SRAM in one work. In 2022, a new advancement in monolithic 3D integration of CFET with 2D materials channels has been demonstrated [166], in which the 4-transistor SRAM and 16-transistor half-adder circuit units based on CFET design were experimentally realized for the first time. In this work, Xiong et al. used low-temperature post-metal annealing method to avoid the deteriorated performance of p-channel 2D transistors, with a record high _I_ on of ~ 594 μA μm<sup>−1</sup> and _G_ m of ~ 244 μS μm<sup>−1</sup> ( _V_ d =  − 2 V, _L_ ch = 135 nm). 

In recent years, some researchers have been exploring the possibility of using 2D materials as potential candidates for the next generation of IC chips. However, there have only been limited successful demonstrations of 2D microprocessor with 1-bit computing ability until now. In research [20], the 1-bit microprocessor consists of 115 transistors with different width/length ratios of gate electrodes. And the arithmetic logic unit (ALU) with inputs A and B, accumulator (AC), control unit (CU), instruction register (IR), output register (OR), and program counter (PC) were all fabricated on the same  MoS2-based substrate, whose architecture is shown in Fig. 8h. The 1-bit microprocess dealt with CLK signal generation and memory in an off-chip way. But it’s a pity that there are only a few percent of the fully functional devices within the whole system, even if the yield for subunits was 80%, such as ALU. This is possibly due to mismatch problems resulting from uniformity issues between 

© The authors 

https://doi.org/10.1007/s40820-023-01273-5 

Page 21 of 96 **119** 

Nano-Micro Lett. (2024) 16:119 

transistors, especially variation in _V_ th. In this case, we still need to further improve the yield and uniformity of our 2D devices in large-scale systems practically. 

##### **4.2  2D Analog ICs** 

Despite the dominant market share and chip area occupied by digital circuits, analog circuits are indispensable due to the intrinsic continuity of signals in the physical world. Therefore, although digital circuits are gradually replacing analog circuits with the advancement of IC processing techniques, certain analog circuits such as amplifiers, analog-todigital converter (ADC), clocking, and power management remain indispensable. However, as functions become diverse and density gets higher, the performance improvement of analog ICs with traditional silicon-based CMOS technology has encountered bottlenecks owning to noise and bandwidth limitation. Therefore, researchers aim to enhance the performance, functions, and integration capability by exploring new materials [168–170], device structures [171, 172], and circuit design techniques [173, 174]. 

Among various materials, 2D materials with atomic body thickness show prominent advantages in realizing analogue functions. For example, 2D materials offer unique electrical and optical properties, exhibiting excellent carrier mobility, high thermal conductivity, and low noise characteristics, which are beneficial for high-speed signal processing and low-power operation. Moreover, some 2D materials have inherent characteristics to simplify circuit design directly, such as ambipolar transport properties of graphene and tunable bandgap properties of BP. On the other hand, it is really necessary to further consider the completeness of 2D system-level circuits. So far, a series of researches on 2D digital circuits and sensors have been demonstrated. In the future, 2D materials will establish their development system, and analog circuits are essential to bridge the gap between sensing and computation. In this section, we focus on recent research progress toward the realization of analog electronics and circuits based on different 2D materials. 

In terms of transistors in analog circuits, the continuous voltage and current signal can be processed and amplified, within the conversion from off state to on state. Graphene, with ambipolar transport properties, extremely high mobility [175] and its tunable bandgap through electric field modulation, can be used to develop a new form of nonlinear 

electronics for RF and mixed-signal applications. Han Wang et al. [176] fabricated a frequency-doubling device with just a single graphene FETs (GFETs) in 2009 for the first time. This frequency multiplier can give very high purity at the output without any additional filtering, which was backgated by the p-type Si wafer (Fig. 9a), where its V-shaped transfer characteristic curve displays two polarities of carrier transport on both sides of the minimum conductivity point. Despite the limitation imposed by the 10 kHz input signal frequency, the guiding significance of this research is undeniable. Later, the fabrication of a new kind of singletransistor RF mixer device was demonstrated [177], which can effectively suppress odd-order intermodulations. The calculated _f_ T of these devices was about 190 MHz, limited by the device gate length and gate capacitance. In 2011, Yanqing Wu et al. [178] reported top-gated CVD-graphene RF transistors with gate lengths scaled down to 40 nm, leading to cutoff frequencies as high as 155 GHz. One year later, they enhanced the cutoff frequency of GFET above 300 GHz based on CVD-graphene grown on copper and epitaxial graphene grown on SiC [179], surpassing previous records. Based on the GFETs, a wafer-scale integrated graphene amplifier circuit with voltage and power gains reaching 20 dB was demonstrated. Additionally, graphene RF receivers [168] with a 16-finger T-shaped gate (Fig. 9b) and double-balanced graphene mixer IC [180] with passive-firstactive-last fabrication flow (Fig. 9c, d) offer insights into on-chip integration strategies and demonstrate the potential to compete with other semiconductor technologies in RF front-end applications. 

Nevertheless, the absence of a bandgap in pristine graphene hampers its on–off ratio, because it tends to exhibit linear output characteristics with limited current saturation, making it difficult to achieve high voltage and power gains. In parallel to graphene’s ambipolarity and tunable bandgap properties, BP has emerged as a potential candidate for high-frequency analog circuit applications [68]. Its high carrier mobility, which results in high transconductance and amplifier gain, combined with the ability to tune the bandgap width through thickness modulation, has garnered significant interest among researchers. In 2015, Saptarshi Das et al. [181] reported an analog small signal amplifier based on a BP load resistor and a BP FET integrated on a single flake. The signal gain of this amplifier was ~ 9 for frequency up to 15 kHz, and the direct current (DC) performance was observed with a record-high 

1 3 

**119** Page 22 of 96 

Nano-Micro Lett. (2024) 16:119 



**Fig. 9  a** Ground-signal-ground (GSG) pad design in dual-channel graphene RF transistor (on the left) and structure diagrams of devices on different substrates (diamond-like carbon & silicon carbide) (on the right). **b** Schematic diagram of graphene RF receivers including 11 active and passive components. **c** Schematic diagram of the fabrication process of the graphene IC with the inverted process, a photograph of the 200 mm wafer and the integration flow. Reproduced with permission [180]. Copyright (2015), American Chemical Society. **d** Optical image of the mixer (on the left) and fabricated double-balanced mixer on PCB (on the right). Reproduced with permission [180]. Copyright (2015), American Chemical Society 

ON current of 200 μA/μm ( _V_ DD =  − 0.5 V). In 2016, Sk. F. Chowdhury et al. [169] realized BP-based RF circuits including common source amplifier, mixer and amplitude modulation demodulator, totally working at megahertz range for the first time. However, the difficulty of largescale synthesis of BP films and the stability of BP in air conditions impose restrictions on its further development. 

While designing an analog circuit, we should consider trade-offs between factors, such as intrinsic gain, power consumption, noise, speed, and linearity [182]. TMDCs have excellent gate electrostatic control, resulting in constantly flat output curves for high output impedance and high intrinsic gain, which is crucial and beneficial to overcome device scaling-down problems. As a result, TMDCs are one of the most promising channel materials for future analog electronics. Traditional mechanical exfoliation method is not suitable for industrial-scale processes, and thus, researchers [183] and [184] chose to use monolayer CVD-MoS2 FETs to realize RF electronics and circuits. For better performance in high-frequency electronics, bilayer  MoS2 with higher carrier mobility than that of monolayer can enhance performance owing to the 

higher density of states and small bandgap. To this end, Gao et al. [170] dealt with the problems of large domain bilayer CVD-grown  MoS2 by adjusting the weight of MoO3 precursor on molten glass during growth. Recently, increasingly complex analog circuits based on  MoS2 have been successfully implemented, including operational amplifiers (OPA) [185], current mirrors [172, 173], and phase-locked loops (PLL) [174]. OPA, which demands high uniformity of constituent components strictly, is a basic building block of analogue electronics. In 2020, Dmitry K. Polyushkin et al. [185] demonstrated the first operational amplifier circuits (64 OPAs) based on 2D MoS2 as the active material from the aspect of design, fabrication and characterization. Each OPA contains 12 n-type enhancement-mode FETs with low variability. In the same year, a  MoS2-based current mirror [173] was fabricated by Shunli Ma et al., with the measurement results of the current gain from 2.72 to 171. They also constructed an industrial design flow for the design, simulation, and layout of  MoS2-based chips, which will provide a general idea of the process from the laboratory to the factory. 

© The authors 

https://doi.org/10.1007/s40820-023-01273-5 

Page 23 of 96 **119** 

Nano-Micro Lett. (2024) 16:119 

However, it should be noted that the current state of research in analog domain is still relatively nascent, with a wide range of analog circuit types awaiting further exploration and development. The continuity of analog signals makes them highly sensitive to changes in the external environment, while 2D materials have high surface areato-volume ratios and sensitivity, making them prone to interference from external temperature variations and noise. Therefore, further development of standardized techniques and complementary packaging technologies is needed. 

Comparing the developmental trajectory of 2D materials with silicon-based circuits [67], it becomes evident that the progress in developing essential devices for large-scale digital and analog circuits based on 2D materials is similar to silicon-based technology To a certain extent, the design of circuits based on 2D materials is similar to that of silicon-based circuits because both of them consist of layered stacking in layout design softwares, but with some different fabrication processes. Silicon-based circuits rely on doping for polarity control, whereas 2D materials exhibit unique advantages as they have two kinds of conductivity in the 2D material library. Furthermore, it is noted that future research will focus on the implementation of mixed-signal circuits based on 2D materials, so that subsequent circuits will depend on ADC to realize signal transformation, in other words, to quantize values within a certain range. As shown in Fig. 10a, some researchers 

are dedicated to designing 2D materials-based ADC onchip circuits [148] and addressing integration challenges [172] due to the limited space available and the need for isolation between analog and digital components, making digital–analog mixed circuits come true. Other efforts are put into exploring embedded ADC converters [186] and other assembly methods such as off-chip connected ADC converters [187]. Here, we provide a valuable reference for the design process of 2D mixed-signal circuits, as shown in Fig. 10b. 

Nevertheless, although there is a positive trend in the development of 2D digital and analog ICs, it is undeniable that numerous limitations and technical challenges still exist. In the realm of 2D digital circuits, firstly, the circuit scale is still limited by the synthesis area and quality of 2D materials. Secondly, different from silicon-based circuits via processing, the multilayered metal interconnects of 2D materials may cause damage to the underlying films, and on-plane interconnections between devices can result in crosstalk. Thirdly, improvements are required in device yield, uniformity, and the integration of modules such as storage and clocks, which currently rely on external connections. In the realm of 2D analog circuits, firstly, the design process demands high expertise from researchers, necessitating collaborative efforts between material researchers, device researchers, and design researchers. Besides, the lack of Process Design Kits (PDK) and design tools results in longer design periods. Secondly, implementing devices 



**Fig. 10  a** Diagram of several connection forms between the core circuit and the ADC converter: on-chip, embedded, off-chip. The analog signal with continuous amplitude is sampled, maintained, quantized and encoded by the ADC converter and then output to the decoder to generate the binary value. **b** Feasible design process of 2D mixed-signal circuits 

1 3 

**119** Page 24 of 96 

Nano-Micro Lett. (2024) 16:119 

with excellent performance based on only 2D materials, such as bipolar junction transistors, inductors, and capacitors still poses difficulties. Thirdly, present research efforts largely focus on achieving specific functions of analogue devices, leaving considerable space for enhancing performance parameters. To achieve silicon-like performance, the performance metrics of 2D transistors used in digital and analog circuits need critical assessment and accurate measurement. For example, widely used device parameters in research papers (such as carrier mobility and contact resistance) could not be reliable because of frequent misestimation [28]. To this end, in Table 1, we show a set of key performance parameter values of silicon-based and 2D FETs in circuits. Although 2D digital and analog circuits have yet to demonstrate obvious advantages over that of silicon, their significance will increase as the technology progresses toward sub-1 nm nodes. 

### **5  Heterogeneously Integrated 2D Devices and ICs** 

The big data era has increased the demand for computing systems that can perform functions beyond the capabilities of single-purpose chips. In response to this challenge, heterogeneously integrated technology is emerging as a promising solution. This technological approach entails the stacking of two or more distinct materials in a specific manner, resulting in the formation of a distinctive structure with adjustable properties. The properties of a heterostructure can be adjusted by modifying the composition, thickness, and stacking sequence of its constituent layers. 

Conventional silicon-based technology is faced with several challenges, which include the need for scaling down to tackle problems like short channel effects, high leakage current, high power consumption, and high contact resistance [192, 193]. Therefore, it is imperative to replace conventional electrodes, channel materials, and dielectrics with advanced materials and structures that can alleviate these limitations. To this end, 2D materials and their heterostructures are considered reliable alternatives. As mentioned above, 2D materials can maintain low leakage characteristics at a thickness of just one atomic level, resulting in transistors with high drive current and low energy consumption [194]. In addition to traditional ICs, electronic systems with multiple functions can be achieved by integrating a new generation of circuits 

through 2D heterogeneous integration. For example, in the realm of optoelectronics, photodetectors prepared through heterogeneous integration enable both light-sensing and computing functions. Furthermore, heterogeneously integrated displays can drive micro-LEDs (μ-LEDs) using the good photoelectric performance of 2D FETs. The method of heterogeneous integration has improved many properties of multifunctional applications, such as the capability of photoelectric detection systems to capture light perception and process optical information. Furthermore, circuits made of 2D material FETs can improve problems such as linear amplifier distortion on analog circuits. 

In this section, we examine work on 2D heterostructure devices and circuits that provide insight into how the tunable properties of 2D materials and their heterostructure can enhance performance. We address recent studies in terms of representative 2D materials heterostructures, the fabrication process, and the crucial role of physical parameters that affect the quality of 2D heterostructures and their IC. 

##### **5.1  Heterogeneously Integrated 2D Devices** 

Heterogeneously integrated 2D devices are composed of two or more different 2D materials that are integrated as channel materials to form a functional device. 

These devices are created by stacking layers of 2D materials with different physics/chemical properties to create interfaces with unique electronic, optical, or mechanical properties. The integration of these different materials allows for the creation of new types of devices with enhanced or novel functionalities that cannot be achieved through a single material or structure alone, such as complementary fieldeffect transistors. This configuration can reduce the area by 42%-50% compared with conventional layouts [79]. It could be utilized to further increase device density in ICs. However, silicon-based CFETs have several limitations that can cause performance degradation. These limitations include extra demands on the thermal budget, difficulties with epitaxial growth of the source, complex integration processes, and compensation of electron/hole mobility mismatch and Vth tuning. This last issue is well suited to be solved by the incorporation of 2D semiconductors, as their mobility and  Vth can be easily tuned to match with another material [195]. It is worth mentioning that a 2D-CFET with a GAA 

© The authors 

https://doi.org/10.1007/s40820-023-01273-5 

Page 25 of 96 **119** 

Nano-Micro Lett. (2024) 16:119 

|Silicon-based<br>FETs2|0.6 (LP), 1.5<br>(HP)<br>0.65<br>1.6 ×  107<br>172<br>100<br>65<br>340<br>370|citance.  CG: gate<br>series resistance.<br>i                    been reached in<br>ters (_f_Tand_f_max)|series resistance|1]|
|---|---|---|---|---|
|l-based  FETs1<br>-<br>Advanced Indi-<br>cators|<br>2 (LP), 3 (HP)<br>0.5 ~ 0.7<br>1 ×  107~ 2 ×  107<br>150 ~ 200<br>1000<br>60 ~ 62<br>350 ~ 450<br>400 ~ 500|xide dielectric capa<br>esistance.  RD: drain<br>i                tly possess and have<br>fi           isted as references<br>performance parame|ance (_R_Css), and the|on of_f_maxis from [19|
|Parameters<br>Explanation<br>2D materia<br>Fundamen<br>tal Indica-<br>tors|_I_on(mA·μm−1)<br>_I_DS = _W_ch<br>2_L_ch _휇_FE_C_ox[2(_V_GS−_V_th)_V_DS−_V_2<br>DS](Linear region)_I_DS = _W_ch<br>2_L_ch _휇_FE_C_ox[(_V_GS−_V_th)2](Saturation region)<br>0.5 (LP), 1<br>(HP)<br>_V_DD(V)<br>supporting the high level (1) voltage potential for logic gates<br>1.4<br>_v_sat(cm·s−1)<br>limiting the operating frequency of the device<br>0.5 ×  107<br>_R_ds(on)<br>3(Ω·μm)<br>including_R_Cds,_R_Css,_R_seriesmetal–semiconductor contact resistance<br>400<br>_μFE_<br>4(cm2V−1s−1)<br>_휇_FE =<br>_L_ch_gm_<br>_W_ch_CGV_DS =<br>_L_ch<br>_W_ch_CGV_DS ⋅<br>_dI_DS<br>_dV_GS<br>|||_V_DS=const<br>200<br>_SS_(mV·dec−1)<br>SS=<br>d_V_GS<br>d lg_I_DS influencing switching speed<br>65<br>_f_T<br>4(GHz)<br>_fT_ ≈_gm_<br>2_휋_<br>1<br>(_C_GS+_C_GD)[1+_g_ds(_RS_+_RD_)]+_C_GD_gm_(_RS_+_RD_) the frequency when the voltage gain is equal to 1, representing the<br>maximum bandwidth that a device is able to achieve<br>150<br>_f_max<br>5(GHz)<br>_f_max =<br>_fT_<br>√<br>4_RG_(_gds_+2_휋fTC_GD) the frequency when the power gain is equal to 1<br>150|HP: High Performance. LP: Low Power.  VGS,  VDS: terminal d.c. voltages.  IDS: drain-source current.  Wch: channel width.  Lch: channel length.  Cox: o<br>capacitance. gm: intrinsic transconductance.  CGS: gate-source capacitance.  CGD: gate-drain capacitance. gds: drain conductance.  RS: source series r<br>RG: gate resistance.<br>1The 2D materials here do not specifically refer to one single type of 2D material. Fundamental Indicators: the performance that 2D materials inheren<br>the literatures. Advanced Indicators: the performance that have not been realized or is difficult to achieve at present. These two types of indicators are l<br>2The data of_I_onin the “Silicon-based FETs” column derives from the 2021 target in the ITRS 2015 report [188] and the data of radio-frequency<br>derives from a stacked Si nanosheet [189]|<br>3 _R_ds(on)is the on-state resistance of the FET, including the drain-semiconductor contact resistance (_R_Cds), the source-semiconductor contact resist<br>(_R_)|series<br>4The calculation expressions of_μ_FEand_f_Tare from [190]. In the expression for_μ_FE,_C_Gis the gate capacitance per unit area.5The calculation expressi|



1 3 

**119** Page 26 of 96 

Nano-Micro Lett. (2024) 16:119 

structure has been invented, which provides a potential way for high-performance and low-power electronic applications. In this review, we classified 2D heterostructure CFET based on the process flow, device structure, and channel material. This CFET can be classified into laterally integrated CFET, vertically integrated CFET [79, 195, 196], and GAA CFETs [197]. 

##### **_5.1.1  Complementary Field‑Effect Transistor 2D Heterostructure_** 

The CFET, which stands for complementary field-effect transistor, signifies a progressive device paradigm in the realm of three-dimensional vertical integration, building on the advancements made in FinFET technology. In CFET units, the vertical stacking of p-n-type field-effect transistors is employed through three-dimensional integration, resulting in a substantial reduction in the layout area of ICs. Furthermore, this approach effectively reduces the negative impact of parasitic effects and interconnect overheads. It achieves this reduction by simplifying access to the transistor terminals through the internal shorting of the n/p drain contacts, which improves high performance, low power consumption, and minimizes area requirements. It is worth mentioning that devices with 2D materials as channels also have the aforementioned characteristics. The weak van der Waals force between layers of 2D materials makes them a promising channel material in stacked nanosheets (NS) and CFETs [194]. As 2D materials with flat surfaces and no hanging bonds, high mobility, and low leakage characteristics can be maintained at a thickness of just one atomic level. This property is advantageous for transistors as it allows for high drive current, and low leakage current, and effectively reduces energy consumption [198]. Additionally, these materials can be integrated with various types of substrates at low temperatures, without the need to consider lattice mismatch. 2D transition metal dihalides exhibit properties that are matched to low power applications, as their electronic energy gap is close to 2 eV, resulting in off-state currents down to the (Fa μm<sup>−1</sup> ) order of magnitude, high performance and low energy consumption of transistors can be achieved [194]. 

Despite the continued miniaturization of traditional silicon-based transistors, their performance is limited by the interaction between the  ION and  IOFF. Specifically, as 

the transistor size decreases, an increase in  ION is often accompanied by a corresponding increase in  IOFF, resulting in a significant increase in power consumption. Therefore, 2D materials are more advantageous in terms of channel material selection and more compatible [196]. Compared to materials such as Si, 2D materials are more suitable for stacking at lower temperatures, which is compatible with 3D-integrated backchannel processes. Furthermore, the preparation and layer shifting of 2D materials can also be carried out at lower temperatures, which ensures the utilization of 2D materials in 3D-stacked heterogeneous CFET devices. 

Notably, the scaling of 3D-stacked heterogeneous CFET devices is hindered by several significant barriers, including complex integration processes and challenges in reducing thermal budgets. Challenges arise in the optimization of contact resistance in 2D transistors. Higher current densities flowing through atomically thin materials result in significant thermal effects. In addition, it is worth noting that 2D materials exhibit distinct thermal conductivities in both the in-plane and between-plane models. In the in-plane model, it is observed that 2D materials exhibit favorable thermal conductivity. However, the thermal conductivity of a stacked structure of 2D materials decreases when they are stacked together. Furthermore, the integration of p-type 2D materials into high-performance FETs, logic gates, and ICs poses significant challenges. This is primarily attributed to the limited availability of large-area-grown p-type 2D materials [166]. The modulation of carrier mobility in p-type and n-type FETs is a crucial aspect in addressing the mobility mismatch between electrons and holes [195]. 

In order to further advance the scaling down of complementary FETs, three established scaling methodologies are recognized. The first approach involves substituting CFETs with a novel structure to facilitate additional scaling down. However, the potential for improving gate topology is limited. The second strategy entails reducing the EOT. However, gate leakage current becomes untenable when physical thickness scaling falls below 3 nm. The third and feasible alternative for overcoming the CFET scaling barrier involves reducing the thickness of the semiconductor channel. However, for the traditional Si channel, when the body thickness is below 5 nm, the mobility drastically degrades with the sixth power of thickness (μ ∝ tb<sup>6</sup> ) owing to thickness-fluctuation-induced scattering, which poses 

© The authors 

https://doi.org/10.1007/s40820-023-01273-5 

Page 27 of 96 **119** 

Nano-Micro Lett. (2024) 16:119 

a critical limit to the continued transistor scaling [28]. Future CFETs necessitate channel materials with superior mobility and lower leakage current in small footprints. 2D semiconductors with pristine surfaces will be one of the most promising candidates for further scaling, as they can maintain high mobility and low leakage current at an atomic-scale thickness [197]. 

Vertical stacking of atomic layer thin channels has been a significant challenge in the field of nanoelectronics. This challenge is primarily due to the complexity of integrated top-gate dielectrics and the associated fabrication processes, which result in deteriorated device performance. In 2021, Xiong et al. [79] demonstrated a novel approach to address this issue by vertically stacking  MoS2/WSe2 complementary field-effect transistors that achieved a 50% reduction in footprint, thereby opening up new opportunities for monolithic 3D integration. However, the deterioration of the p-type bilayer transistor using a top-gate structure remains unresolved. In 2022, Xiong et al. [166] improved upon this work by successfully integrating CFETs with 2D materials channels for low-power ICs, solving the longstanding problem of poor electrical properties that prevent p-type and n-type devices from being matched. Specifically, the authors optimized the top gate p-channel bilayer  WSe2 transistor fabrication processes using low-temperature post-metal annealing, achieving record-high _I_ on of ~ 594 μA μm<sup>−1</sup> and _G_ m of ~ 244 μS μm<sup>−1</sup> at _V_ d =  − 2 V with a short _L_ ch = 135 nm. Furthermore, the authors demonstrated the first-ever 4T SRAM and 16T half-adder circuit units based on a 2D heterostructure CFET design, presenting its superiority in performance, power, and area. 

However, there remain challenges that need to be addressed in fully silicon-based systems, such as balancing electron and hole mobility and addressing the high thermal budget. Ling Tong et al. [195] presented a study on a 3D-stacked heterogeneous CFET containing SOI-based p-FETs and  MoS2-based nFETs, presenting an integration approach that leverages the maturity of the silicon process, the low thermal budget of  MoS2, and the low aspect ratio of the device structures to reduce process complexity and device degradation. The authors argued that thickness modulates carrier mobility to match, thereby alleviating the mobility mismatch between electrons and holes in n-FET/p-FET, that is the reason why we take thickness into account in Fig. 11i. In addition, further improvement of the SS can be 

achieved by reducing the thickness of the gate oxide and channel. 

In addition to using 2D material as the channel material of the CFET, a heterogeneous structure combining 2D material and 1D material as the channel material of the CFET also has its advantages, such as high ON/OFF ratios up to 10<sup>6</sup> . As shown in Fig. 11k, Zhixin Li et al. [199] prepared heterogeneous complementary inverters by adopting bilayer MoS2 as an n-channel FET and SWCNTs as a p-channel FET. The n-channel  MoS2-FET exhibited an ON/OFF ratio greater than  10<sup>6</sup> and a high carrier mobility of 19  cm<sup>2</sup> V<sup>–1</sup> s<sup>–1</sup> , and the p-channel SWCNT-FET had an ON/OFF ratio of nearly  10<sup>5</sup> and a large ON current. A schematic of the inverter is shown in the insets of Fig. 11k. This device achieves fundamental logic functions, exhibiting a maximum voltage gain of 15, a minimum power consumption of approximately 10 nW, and a noise margin of 0.45 _V_ DD. Furthermore, the optimization of width-to-length ratios for the CFET presents a promising way to enhance power efficiency, rendering the device well-suited for prospective logic-circuit implementations. 

##### **_5.1.2  GAA Nanosheet Vertical‑Stacked CFET_** 

NS vertical-stacked complementary field-effect transistors, where the NS n-FET and NS p-FET are vertically stacked and controlled using a common gate, would result in maximum device footprint reduction [200]. The 3D schematic view and cross-sectional view of the GAA nanosheet vertical CFET device structure are shown in Fig. 11d, e, respectively. Here GAA structure is regarded as a contributing factor to the high drive current and low leakage current. As shown in Fig. 11e, the n-FET and p-FET are vertically stacked and are controlled using a common gate, allowing the device to achieve maximum footprint reduction. M. Liu et al. [197] demonstrated a GAA NS vertical-stacked CFET based on chemical vapor deposition 1L  MoS2 NS FET and  WSe2 NS FET. The _I_ DS– _V_ GS characteristics of bottom MoS2-NS-n-FET and top  WSe2-NS-p-FET with channel width/length = 5/5 μm in fabricated 2D-CFET at different drain voltages ( _V_ DS) from 0.1 to 0.7 V are shown in Fig. 11g, i, demonstrating that 2D-CFET’s extremely strong current control capability at one-atomic thickness channel, which is shown more obviously in the extracted relationship between on/off ratio and  VDS bias in Fig. 11h, j. Furthermore, the 

1 3 

**119** Page 28 of 96 

Nano-Micro Lett. (2024) 16:119 



**Fig. 11  a** Structure schematic of the vertical stacked CFETs. **b** Structure schematic of the  MoS2/WSe2 CFET. **c** The corresponding equivalent circuit diagram of CFET. **d** Schematic structure and cross-sectional view of the 2D-CFET device structure. **e** The top  WSe2 FET and bottom MoS2 FET are stacked vertically and share a common gate with a gate-all-around structure. **f** EDX line scan across the gate-all-around structure (Fig. 11e). **g, h** Electrical properties of the top  WSe2-NS-p-FET in the 2D-CFET. Transfer characteristics at the source–drain voltage from − 0.1 to − 0.7 V. Current on/off ratio versus _V_ DS (left) and SS versus _I_ DS at _V_ DS =  − 0.7 V (right). **i,j** Electrical properties of the top  WSe2-NS-p-FET in the 2D-CFET. Transfer characteristics at the source–drain voltage from − 0.1 to − 0.7 V. Current on/off ratio versus _V_ DS (left) and SS versus _I_ DS at _V_ DS =  − 0.7 V (right). Reproduced with permission [197] Copyright (2023), John Wiley and Sons. **k** Output voltage as a function of the input voltage for the  MoS2/SWCNT heterogeneous inverters. Reproduced with permission [199] Copyright (2016), Springer Nature. **l** Comparisons of monolithic 2D CFET devices in previous studies [194, 200–203] 

extracted _D_ it values are 9.7 ×  10<sup>11</sup> and 4.3 ×  10<sup>12</sup> cm<sup>−2</sup> eV<sup>−1</sup> for n-FET and p-FET, respectively. These values are lower 

than other CVD-2D-based CFETs, attributing to the GAA NS structure and the clean fabrication process, highlighting 

© The authors 

https://doi.org/10.1007/s40820-023-01273-5 

Page 29 of 96 **119** 

Nano-Micro Lett. (2024) 16:119 

a potential method for high-performance transistor scaling. This demonstration of vertical stacked NS CFET could pave the way for high-performance and low-power electronic applications. We believe that there is an urgent need for such studies to realize ideal device schemes in 2D CFET heterostructures and interfaces. 

The outlook for stacked heterogeneously integrated 2D devices includes footprint reduction and lower power consumption. This approach effectively reduces the negative impact of parasitic effects and interconnect overheads in devices, showing great promise in terms of further scaling down. However, challenges such as thermal management, manufacturing costs, and reliability need to be addressed. The properties of a 2D heterostructure can be adjusted by modifying the composition, thickness, and stacking sequence of its constituent layers. With advancements and innovation, stacked heterogeneously integrated 2D devices are expected to play a crucial role in next-generation highperformance device configurations. 

##### **5.2  Monolithic Heterogeneously Integrated 2D ICs** 

In comparison with traditional circuits that primarily use single-channel materials, heterogeneous circuits have been considered a suitable and reliable strategy for multi-function applications and performance optimization of conventional chips. In addition, 2D materials are among the most promising candidates for the next generation of electronic systems. The potential benefits of combining the unique advantages of 2D materials and traditional circuits on a monolithic large scale could lead to intriguing outcomes, such as combining sensing and computing in one system, reducing power consumption, and enhancing operation speed. In this section, the design of heterogeneously ICs will be discussed, with a focus on both high- and low-density interconnects at the circuit level. 

##### **_5.2.1  Monolithic 2D ICs Heterogeneously Integrated of Low Density_** 

Low-density heterogeneous ICs can combine the excellent properties of 2D materials, such as ultrathin channels and 

weakened short-channel effects, with data processing circuits to achieve a variety of functions. The 2D materials family exhibits numerous outstanding electrical properties. In this section, we will list classic works that integrate 2D materials with traditional circuits while maintaining a low density of interconnect. Additionally, the potential development prospects for this field will be discussed. 

The graphene Hall elements (GHEs) have attracted much attention due to their excellent sensitivity, low noise, nice linearity, and temperature stability. However, the performance of chips made only of GHEs is far from being suitable for commercial use. By heterogeneously integrating 2D materials with Si-based circuits, the performance of such chips will be improved. Here, Tongyu Dai et al. [203] achieved a method of three-dimensional building structure using heterogeneous integration of silicon-based CMOS ICs. They demonstrated a heterogeneous integrated Hall ICs that exhibit current and voltage magnetic sensitivities up to 64,000 A  V<sup>−1</sup> T<sup>−1</sup> and 6.12 V  V<sup>−1</sup> T<sup>−1</sup> , respectively. The structure of this device and its circuit design are shown in Fig. 12a, b. Using an optimized fabrication process and refined design of processing ICs, the hybrid integration of GHE and Si CMOS ICs shows advantages in presenting higher performance and more functions than a single chip alone. 

GHEs play an essential role in magnetic field sensors. In addition, graphene FETs also have strong advantages in analog applications due to their high carrier mobility and high saturation velocity. In order to fully utilize advantages of both graphene FET circuits in analog ICs and CMOS FET circuits in digital ICs, Seul Ki Hong et al. [204] utilized the 3D hybrid integration technology to fabricate an analog–digital mixed signal circuits on a chip. As shown in Fig. 12c, d, the researchers fabricated a graphene FET multimode phase shifter onto a silicon CMOS FET ring oscillator. The mode of the graphene phase shift can be easily controlled by adjusting the bias voltage of both the CMOS circuit and the graphene inverter. The utilization of this technique presents an opportunity to leverage the exceptional inherent properties of 2D materials and the advanced state of existing silicon CMOS technology, thereby facilitating the development of future electronics. 

1 3 

**119** Page 30 of 96 

Nano-Micro Lett. (2024) 16:119 



**Fig. 12  a** Structure design of GHEs with CMOS ICs. **b** Circuit design of GHEs with CMOS ICs. Reproduced with permission [203]. Copyright (2020), American Chemical Society. **c** Structure design of integration of 2D FET analog circuit and CMOS digital circuit. **d** Circuit design of 2D FET analog circuit and CMOS digital circuit. Reproduced with permission [204]. Copyright (2016), American Chemical Society 

The successful fabrication of an analog–digital mixed signal chip is just the beginning of heterogeneous integration between 2D materials and conventional circuits. Although silicon-based chips dominate the semiconductor industry, their application in analog ICs is limited due to the inherent quadratic control relationship of FET, which distorts the amplification. To achieve high linearity in a FET, the extra complexity of inevitable circuits is necessary for conventional chips. In order to overcome the nonlinear distortion in Si-based analog ICs, Liangliang Xu et al. [205] reported the integration of graphene FET and Si-FET components. They successfully engineered a graphene-silicon hybrid analog amplifier IC with excellent linearity characteristics. It’s worth emphasizing that the judicious fusion of 2D materials with established Si-based technologies is a recommended approach. 

Other than the low density of heterogeneous ICs, it is worth mentioning that we have found a lot of large area 2D FET arrays with high density. These works offer a positive outlook for high-density hybrid ICs. Due to its high on/off current ratio, weakened standby current, and near theoretical limit subthreshold slope, the 2D FET exhibits high speed and low power consumption. It is suitable for building processor and logic-in-memory circuits. A micro-processor consisting of 115 transistors was realized 

by Stefan Wachter et al. [20]. Guilherme Migliato Marega et al. [206] showed that 2D materials can enable scaling below 12 nm and increase reliability of chip with a high ON/OFF current ratio. Yikai Zheng et al. [207] used 2D-material-based memtransistor to fabricate a spacesaving and lower energy consumption of Bayesian networks. In the field of near-sensor security, Akhil Dodda et al. [208] demonstrated an 8 × 8 crossbar array of fully integrated crypto engines, with each engine having 5 monolayer  MoS2 memtransistors. In short, the research on large area 2D FET arrays could offer more opportunities for future heterogeneous ICs. 

With the development of large-scale ICs using 2D materials, we will have a greater opportunity to achieve heterogeneous structures. However, what cannot be ignored is that there are still a lot of challenges waiting for solutions in fabricating hybrid chips. Completing the complex process of transferring a large area 2D materials is a significant challenge that restricts the number of research groups capable of exploring more efficient solutions for high-density interconnects. In addition, 2D materials have excellent optoelectronic performance, including tunable bandgap and strong light-matter interaction. In the field of photoelectric chips, the display system using 2D materials or other hybrid circuits requires a high-quality 2D 

© The authors 

https://doi.org/10.1007/s40820-023-01273-5 

Page 31 of 96 **119** 

Nano-Micro Lett. (2024) 16:119 

FET array. Therefore, the connection between 2D FETs is crucial. Achieving high-density integration of 2D FETs is not an easy task. There is still a long way to go for the application of hybrid circuits in real life. 

##### **_5.2.2  Monolithic 2D ICs Heterogeneously Integrated of High Density_** 

We have discussed the low density of 2D materials interconnects with Si-based circuits. However, for complex tasks, a greater number of FETs will be required. Thus, low-density interconnect will no longer satisfy the needs of electronic applications, particularly in heterogeneously integrated optoelectronic systems. Many large-scale arrays of 2D FET arrays have been utilized in image sensors and micro-LED displays. There is potential for high-density 2D materials interconnect with traditional circuits. 

To better exploit the advantages of 2D materials, their exceptional photoelectric properties are used to fabricate high-density heterogeneous integrated optoelectronic chips. In the field of optoelectronics, heterogeneous ICs of 2D materials play an important role. As shown in Fig. 13a, we suggest that main function of electronic chips in the field of optoelectronics is to generate and sense light. The heterogeneous integrated chips that produce light are mainly in the visible light band, such as miniature LEDs and high-resolution displays. The perception of light is mainly through photodetectors, and these photodetectors are no longer limited to detecting only visible light. As shown in Fig. 13b, based on the works in optoelectronics, we have concluded a simplified structure for high-density interconnection. Its distinctive feature is three-dimensional stacking. 

The development of microcircuits and visible-light cameras has been impeded in the past due to the challenge of integrating non-Si electro-optical materials with Si-based circuits. However, combining 2D materials with Si-CMOS is an advisable approach to achieve imaging capabilities beyond the visible range, on-chip low-power optical data communications, and compact sensing systems. In 2017, Stijn Goossens et al. [209] presented an image sensor that heterogeneously integrated graphene with CMOS technology. Their work reopens the door to heterogeneously integrated structures, utilizing a 388 × 288 array of high-quality graphene-quantum dot photodetectors. The resulting image sensor possesses high-mobility phototransistors, which have 

been interconnected with traditional CMOS circuits. This integration shows a broadband image sensor with compact and cost-effective advantages. This device exhibits an ultrahigh gain of  10<sup>8</sup> and excellent responsivity above  10<sup>7</sup> A W<sup>−1</sup> , which is a huge progress for quantum-dot-based imaging systems. In contrast to current methods of heterogeneous integration, there are no fundamental limits to shrinking the pixel size and enhancing resolution of the image. This work is a milestone for low-cost and high-pixel broadband imaging systems. 

Integration of 2D materials and Si-based FET could combine the advantages of both technologies. This structure enables the low power and low-cost monolithic chips. The bulky indirect bandgap of Si is not suitable for portable and flexible electronics. Additionally, organic or polymeric detector arrays have not been certified for combination with Si-FET backplanes [210]. However, ultra-thin monolayer TMDCs with various energy bandgaps could be combined with a Si-FET backplane to enhance the performance of the circuit. In 2016, Chih-Chao Yang et al. [210] demonstrated a monolithic three-dimensional (3D) image sensor, which made use of a TMD phototransistor array heterogeneously integrated with a 3D logic/memory hybrid structure. As shown in Fig. 13d, this 3D image sensor has a high-density interconnect. On the top of this device, the monolayer  MoS2 phototransistor shows excellent responsivity above 20 A W<sup>−1</sup> and exhibits an outstanding linear response to the incident laser power density. At the bottom of this device is a 3D stackable silicon-based FET with a steep subthreshold swing and high driving current. The author obtained a TMD phototransistor array and a 3D stackable silicon-based FET, both of which have demonstrated excellent performance individually. Furthermore, the high interconnection density within them allows for a combination of their advantages, resulting in the rapid emergence of portable and flexible electronics. 

It is promising that the performance of image sensors will be enhanced by 2D semiconducting materials in the near future. Using TMD instead of a Si photodiode array on a chip could produce diverse spectral sensitivities, surpassing the capabilities of a Si CMOS image sensor. Because of TMD monolayer crystals, they can exhibit different bandgaps or absorption wavelengths from infrared to visible. In 2022, Henry Hinton et al. [211] developed a 256 × 200 image sensor. They did not use additional layers, such as quantum dots, for light absorption [209]. Instead, they utilized TMD monolayers above CMOS time-to-digital converters. This 

1 3 

**119** Page 32 of 96 

Nano-Micro Lett. (2024) 16:119 



**Fig. 13  a** Application in photoelectron when using 2D materials. **b** General heterogeneous integrated structure of sensing external light. **c** General heterogeneous integrated structure of generating internal light. **d** Structure of hybrid  3D<sup>+</sup> IC image sensor. **e** Structure design of the image sensor. **f** Circuit design of the image sensor 

chip relies on  MoS2 photo-FETs to convert incident light into a photocurrent, which is then read out by CMOS timeto-digital converters. The cross-section schematic of a pixel is shown in Fig. 13e, and its 51,200-pixel circuits and 200 row-wise time-to-digital converters are shown in Fig. 13f. The design is clearly depicted in this floor plan. In the field of image sensors, the use of 2D materials will foreseeably continue. 

While 2D materials play an outstanding role in image sensors or photodetector, they are also used in the production of micro-LEDs. Micro-LEDs have attracted much attention because of numerous advantages, such as quick response and low power consumption. Furthermore, due to 

the excellent electric performance of 2D FETs, the microLED can exhibit superior properties, such as improved resolution, high-speed operation, and increased brightness limit. Wanqing Meng et al. [212] have reported a monolithic heterogeneously integrated active-matrix display with a resolution of 1270 pixels per inch. In this design, the team utilizes a fast and bright micro-LED driven by 2D FETs. It only requires less than 8 V that could have 7 ×  10<sup>7</sup> cd  m<sup>−2</sup> luminance. It is worth mentioning that the backend of the line in this device’s production is at a low temperature and compatible with the traditional microelectronic manufacturing process. The different heterogeneous integration approaches enable the fabrication of micro-LED chips to 

© The authors 

https://doi.org/10.1007/s40820-023-01273-5 

Page 33 of 96 **119** 

Nano-Micro Lett. (2024) 16:119 

have a higher chance of reaching a higher stage. In order to improve the bonding between LED chips and the backplane circuit, Sumin Hwangbo et al. [59] utilized a method that involved the direct growth of  MoS2 on a GaN epitaxial wafer and the printing of quantum dots. This method was used to demonstrate a full-color micro-LED display using MoS2 transistors. The production yield of micro-LED pixels was approximately 92%. In addition, by the method of vertical stacking, Jiho Shin et al. announced a full-color micro-LEDs with the smallest size (4 μm) and highest array density (5, 100 pixels per inch (PPI)), reported to date (2023–02-01) [213]. 2D FET, which can drive micro-LEDs at low voltage and reduce the power consumption, is proposed as a heterogeneous component in this field. 

Worth mentioning, that in addition to the image sensor and micro-LED display, 2D materials also play an important part in photonic chips due to their adjustable bandgaps. Fabrication of  MoS2-based high responsivity photodetectors has already been reported [214], but an integrated photonic chip with 2D materials is still lacking. This gap has been bridged by heterogeneous integration between  MoS2-based photodetectors and  Si3N4 photonic circuits. Juan Francisco Gonzalez Marin et al. [215] demonstrated the integration of  MoS2-based high responsivity photodetectors with  Si3N4 photonic circuits. The chip that owns photoresponse times below 1 ms is achieved by using a h-BN substrate. Additionally, graphene local gates are used and low power operation is achieved in the final chip. A fast operation speed and using low operation voltages photodetector is made. Usage of 2D materials in different electronic systems will be continue. 

Through heterogeneous integration, a new way to reach excellent device performance has been established. Maybe in the near future, we could see an increasing integration of compound semiconductors and 2D materials in various chips. And now, the primary application of this heterogeneous structure is in optoelectronics systems. Therefore, finding another field to apply this idea is crucial for the development of 2D materials hybrid integration. 

In summary, the transfer of high-quality, large-area 2D materials remains a major technical challenge that limits chip performance and the creation of high-quality interconnects within circuits. Specifically, the challenge lies in integrating p-type 2D materials into high-performance FETs, logic gates, high-quality arrays, and ICs due to the lack of large-area growth of p-type 2D materials. For the device level, there are also challenges in the performance 

deterioration after integrating the top gate dielectric, the difficulty of reducing the thermal budget, and how to optimize the carrier mobility of p-type and n-type FETs. For the circuit level, improved interconnections for transistors and enhanced design in the driver and functional sections are required to obtain high-quality arrays. 

Technology of heterogeneous integration that combines 2D materials and conventional circuits has realized multifunction and exhibited excellent performance in a single chip, such as technologies combining sensing and computing with low power consumption and fast operation speed. Furthermore, manufacturing processes of heterogeneous integration are compatible with conventional silicon-based processes. These hybrid process flows are damage-free for devices. 

Conventional silicon-based circuits are facing difficulties in scaling down. To overcome this challenge, heterogeneous integration with 2D materials emerged as it can enhance space utilization rate. Besides, the advantages of 2D materials and silicon-based CMOS can be exploited this way. In the near future, more hybrid chips will be based on 2D materials and CMOS circuits, such as image sensors that exhibit fast speed, high sensitivity, and wide band. In addition, a mixed-signal chip fabricated by integrating 2D materials with silicon-based circuits can present fast operation speed with linear amplifier. Furthermore, heterogeneous integration of 2D materials and mature silicon-based technology has potential in building wide band sensor, fast in-memory computing, and advanced CMOS logic circuits in one chip. 

### **6  2D Materials Sensor Chips** 

In the era of the Internet of Everything (IoE), sensors determine the comprehensiveness, accuracy and ease of access to information, and for this reason sensors are known as the essential technology to be developed in the future. Recently, complex applications such as artificial intelligence have placed higher demands on sensors’ number, type, and performance to enable large-scale data collection, storage, and analysis. Dimension scaling is a crucial technology for solving the high cost, high power consumption, and low integration of sensor networks [216]. To this end, the new generation of sensors is developing toward intelligent sensor chips. Although conventional silicon-based sensor chips have been heavily researched and commercially used [217], 

1 3 

**119** Page 34 of 96 

Nano-Micro Lett. (2024) 16:119 

they usually face restrictions such as short-channel effects, thermal dissipation, gate modulation, long response times, and insufficient sensitivity [218]. To address these issues, researchers have turned their attention to 2D materials with atomic layer thicknesses [219]. The utilization of 2D materials in sensor technology offers the distinct advantage of exhibiting high sensitivity, rapid response, tunability, and high stability [220]. With the rapid development of waferscale 2D material growth technology and transfer technology, 2D material sensor chips have made remarkable progress in the past decade. 

As is known to all, the most basic unit of the chip is the FET and the development of a 2D material sensor chip also starts from the 2D FET sensor, as summarized in Fig. 14. 2D materials FET sensors not only convert specific physical quantities into electrical parameters, but also can modulate the performance by divergent kinds of gates and are considered a fast, sensitive, and easy-to-operate advanced detection technology [221]. The primary focus of this phase is to assess whether the sensor performance of an individual device aligns with the established standards and validate the theoretical feasibility of the sensor chip. Subsequently, with the advent of silicon-based chip processing techniques, 2D material FET sensors have been progressively advancing toward the realization of large-scale arrays. Arrayed sensors offer significant advantages over individual sensors in terms of accuracy and information, while also enabling richer functionality, such as visual imaging of multiple physical quantities such as light, heat, and force. One of the primary challenges faced by arrayed sensors lies in the realm of large-scale signal processing. There are two primary methodologies: one involves computer-based data collection and processing, while the other entails connecting it to external circuits for achieving functions such as data acquisition, amplification, and transmission. On this basis, external circuits are replaced with specialized chips and combined with sensor arrays to obtain more minor distributed sensor chips. Smart dust is a typical representative of one of these devices, integrating sensors, digital and analog circuits, RF chips and power supply modules [222], although its size has been reduced to the size of a grain of sand. Considering that 2D material sensors predominantly employ micro-electromechanical system (MEMS) processes, the integration of MEMS and CMOS processes on a single chip is also highly desirable. The chip comprises two fundamental modules: the CMOS area, encompassing peripheral circuits such as 

control and signal processing circuits; and the MEMS device area, primarily responsible for the fabrication and processing of 2D material sensors. In the post-Moore era, as chip manufacturing processes gradually approached the physical size limit, researchers opened up a new direction of "More than Moore", and 3D packaging is one of the important implementation paths. 3D packaging, also referred to as stacked chip packaging, encompasses the advanced technology of vertically stacking two or more chiplets within a package while maintaining its original dimensions. Unrestricted by lattice mismatches or process compatibility issues, 3D packaging allows various layers (e.g., transmitter, 2D materials sensors, memory, and Si CMOS) to be stacked vertically to provide additional functionality [223]. Most sensor chips currently use rigid substrates, limiting their use in many applications such as intelligent wear, health detection, and haptic sensing [223]. In contrast, soft and stretchable sensors based on 2D materials can solve these problems and provide disruptive solutions for future flexible sensor chips. With the continuous advancement of 2D material analog ICs, the development of fully flexible sensor chips based on 2D materials is expected to progress rapidly. Apart from that, the explosive development in artificial intelligence has led to an increasingly close connection between sensor chips and artificial neural network algorithms. However, a large amount of data transfer and the lack of computing resources of traditional computer architecture led to a slower overall system speed and massive power consumption. The incorporation of sensors and neural network algorithms for signal preprocessing at the front-end is anticipated to decrease both hardware and software components, thereby simplifying and reducing the cost of the system. 

According to the working mechanism of sensors, sensors can be generally divided into physical, chemical, and biological types. This section summarizes the latest research progress of sensor chips based on 2D materials, discusses physical chemical and biological sensors in terms of sensitive materials, sensing performance and scale, and provides an outlook on their key technologies and application prospects. 

##### **6.1  Physical Sensors** 

Physical sensors are specifically designed to detect variations in the physical properties of a substance, including but 

© The authors 

https://doi.org/10.1007/s40820-023-01273-5 

Page 35 of 96 **119** 

Nano-Micro Lett. (2024) 16:119 



**Fig. 14** Developments of 2D material sensors toward chip. After the discovery of graphene, individual 2D material sensors with different gate structure were also demonstrated in 2007. The advent of 2D materials sensor arrays in conjunction with an external processing circuit in 2014 has increased the scale and utility 2D materials of sensors. In 2018, the combination of CMOS and MEMS processes has led to a reduction in the area of 2D materials sensor chips. In 2022, Mei et al. proposed the concept of digital micro-dust to achieve a high-density integrated, lowcost distributed 2D materials sensor chip. Reproduced with permission [222]. Copyright (2022), Elsevier. In 2025, the emerging 3D packaging technology will overturn the distribution structure of sensing networks and open a new era of ultracompact intelligent sensing systems. In 2028, 2D materials sensor chips will evolve toward full flexibility for enhanced sensing capabilities and close cooperation between humans and machines. In 2032, budding sensor technologies integrate sensor networks and advanced algorithms on a chip to reduce the significant power consumption required for transmission and computation 

not limited to temperature, pressure, strain, and light. The 2D material sensors not only outperform traditional physical sensors in some performance but also align with the trend of miniaturization and integration. Here, we summarize four representative applications of 2D materials physical sensors and chips, and compare their sensing performance in Table 2. 

##### **_6.1.1  Temperature Sensors_** 

Temperature is a ubiquitous environmental parameter, extensively employed in both military and civilian domains, such as epidemic control and equipment monitoring. Traditional 

discrete temperature sensors based on thermistors, thermocouples, and platinum resistors are unable to meet the growing demand for thermal management due to their inability to integrate with large-scale systems-on-a-chip, which is driving the development of temperature sensor chips. The excellent electrical properties and high thermal conductivity of 2D materials make them vital candidates for temperature sensor chips [224]. The fabrication of back cavity and suspension graphene temperature sensors can be achieved through the utilization of MEMS processing technologies, such as lithography and wet etching, enabling their potential for large-scale production. The U-shaped graphene structure with narrow and wide legs [225] was designed to achieve 

1 3 

**119** Page 36 of 96 

Nano-Micro Lett. (2024) 16:119 

**Table 2** The performance of the physical sensors based on 2D materials 

|Type|Materials|Sensitivity|Time|Range|Integration level|References|
|---|---|---|---|---|---|---|
|Temperature sensor|Graphene|–|–|283–303 K|Device|[261]|
|Temperature sensor|MoS2|TCR:∼1 − 2%  K<sup>−1</sup>|∼36 μs|27–85 °C|4 × 4 array|[267]|
|Thermocouple|Graphene|ΔS: 39 μV  K<sup>−1</sup>|–|–|On-chip|[262]|
|Temperature sensor|Graphene||TCR|:∼1%  K<sup>−1</sup>|∼30 ms|6.6–300 K|On-chip|[265]|
|Pressure sensor|MoS2|Δ_R_/_R_0: 0.011  kPa<sup>−1</sup>|180 ms|1 − 120 kPa|8 × 8 array|[270]|
|Pressure sensor|MoS2|1.8  MPa<sup>−1</sup>(< 500 kPa)|25/27 ms|70 Pa to 5 MPa|20 × 20 array|[271]|
|Pressure sensor|Graphene|47.8 aF  Pa<sup>−1</sup>mm<sup>−2</sup>|–|0 − 100 kPa|Sensor chip|[272]|
|Pressure sensor|Graphene|5.32 ×  10<sup>−4</sup>kPa<sup>−1</sup>|–|10 − 100 kPa|MEMS chip|[43]|
|Pressure sensor|Graphene|5.51 ×  10<sup>−5</sup>kPa<sup>−1</sup>|–|0 − 20 MPa|MEMS chip|[273]|
|Strain sensor|Graphene|-|~ 4/7 ms|0 − 1.6%|8 × 8 array|[276]|
|Photodetector|MoS2|119.16 A  W<sup>−1</sup>|44/41 ms|405, 532, 638 nm|8 × 8 array|[279]|
|Photodetector|PtTe2/graphene|∼0.52 A  W<sup>−1</sup>|∼8.4 μs|405–1850 nm|wafer-scale|[281]|
|Photodetector|MoS2|5.2 ×  10<sup>4</sup>A  W<sup>−1</sup>|50 ms|638, 532, 405, and 852 nm|wafer-scale|[282]|



enhanced sensitivity, as shown in Fig. 15a. This design choice is justified by the influence of leg width on the Seebeck coefficient. 

Temperature-sensitive electronic devices usually must detect temperature changes in real time to adapt their performance accordingly. For example, the temperature sensor is embedded directly into the heat source of the power IC to detect the temperature and precisely control the temperature of the power tube, thus improving the reliability of the smart power IC chip [226]. The on-chip integrated graphene temperature sensor provided a reliable assessment of active region lattice temperatures during laser operation [227], as illustrated in Fig. 15b. The temperature coefficient of resistance (TCR) is an important indicator of the sensitivity of a resistive temperature sensor. To enhance the temperature sensitivity, the use of other 2D materials with higher TCRs is also promising. One of the main sensing mechanisms for temperature sensing is touch sensing, which transmits key information about the contact object, such as monitoring changes in human skin temperature. It is necessary to burgeon flexible temperature sensor chips to fit the contact object better and to achieve functions such as accurate temperature distribution imaging. Duas et al. fabricated flexible monolayer  MoS2 temperature sensors and arrays with high TCR ( ∼ 1 − 2%/K) [228]. The response time of this sensor is < 36 μs, realizing real-time thermal sensing on flexible substrates (Fig. 15c). With alumina encapsulation, the cycle operation is stable and can be measured for a long time. Although sensor chips based on 2D materials have many advantages, the explanation of the sensing mechanism is not clear enough, including electron–phonon coupling, thermal 

expansion, electron-charged particle interaction, and the Seebeck effect. 

##### **_6.1.2  Pressure Sensors_** 

Depending on the method of signal conversion, pressure sensors can be categorized as piezoresistive, capacitive, piezoelectric, or triboelectric. Despite the great progress made in conventional pressure sensors, they are still limited to the need for specific sensing ranges, low sensitivity, and these devices are not enough for wide applications in wearable devices, smart robots, and biological systems. In order to accurately sense the pressure distribution and thus achieve multi-touch, trajectory judgment, haptic sensing, and other functions, the new generation of intelligent pressure sensors is committed to the direction of flexible sensor chips with smaller single devices, larger array size and better flexibility. The atomically thin 2D materials miniaturize pressure or strain sensors in significant measure without damaging the object’s surface shape or force signal distribution, rendering them highly promising candidates for next-generation pressure sensors. The pressure sensor chip, as depicted in Fig. 15d, integrated large-area and flexible  MoS2 tactile sensors with an activematrix backplane circuitry [229]. The integrated thin-film transistors enable or disable individual pressure sensors depending on their switching state, thus avoiding interference between adjacent units and effectively increasing the crosstalk isolation value to 24.8 dB, showing significant 

© The authors 

https://doi.org/10.1007/s40820-023-01273-5 

Page 37 of 96 **119** 

Nano-Micro Lett. (2024) 16:119 



**Fig. 15** Temperature, pressure, and strain sensors based on 2D materials. **a** Optical microscope image of single-material graphene thermocouples showing the measurement configuration. Reproduced with permission [225]. Copyright (2020), Wiley–VCH. **b** Scanning electron microscopy image of the on-chip integrated graphene thermometer. Reproduced with permission [227]. Copyright (2023), American Chemical Society. **c** Optical images of the flexible substrate with  MoS2 temperature sensor arrays, and sensor response upon pulsed actuation with the heater. Reproduced with permission [228]. Copyright (2022), American Chemical Society. **d** Schematic illustration of the fully integrated active-matrix  MoS2 tactile sensor array, circuit diagram, and optical micrograph of thin-film transistor enabled single pressure gauge unit. Reproduced with permission [229]. Copyright (2019), American Chemical Society. **e** Active-matrix pressure sensors based on air-dielectric  mos2 transistors for wide detection ranges from footsteps to cellular motions. Reproduced with permission [230]. Copyright (2020), American Chemical Society. **f** Optical image of the sensor chip based on double-layer graphene/PMMA membranes and Ti/Au electrodes. **g** Readout circuitry PCB board and the red circle indicates the pressure sensor chip. Reproduced with permission [231]. Copyright (2020), Nature Publishing Group. **h** Optical image of strain sensors with an 8 × 8 device array and measurement of the electric response on applying finger touching. Reproduced with permission [235]. Copyright (2015), American Chemical Society. **i** Schematic illustration of the structure of pressure sensor arrays based on the photo-reticulated strain localization films, and optical photographs of sensor arrays attached on palm. Reproduced with permission [236]. Copyright (2023), Nature Publishing Group 

1 3 

**119** Page 38 of 96 

Nano-Micro Lett. (2024) 16:119 

commercialization potential. By combing active-matrix arrays of pressure-sensitive  MoS2 FETs with air dielectrics and mechanoluminescent layers [230], as exhibited in Fig. 15e, the fully integrated chip tactfully achieved high sensitivity in the detectable range of pressure from 70 Pa to 5 MPa. With this air-dielectric structure, pressure-sensitive FETs will have a low hysteresis and a high transconductance to improve their reliability and response time, providing the new approach toward next-generation biomachine interface. 

Despite extensive research into pressure sensors using 2D materials, the lifetime of the devices is still extremely short due to the lack of protection of the 2D materials. Hence, highly hermetic, low-cost packaging technology is necessary to achieve increased range and stability of 2D material pressure sensors. Šiškins et al. reported sensitive capacitive pressure sensors using arrays of nearly 10,000 double-layer graphene (DLG) membranes [231], as shown in Fig. 15f. Sensors are packaged in a small vacuum chamber onboard, integrated with chip-scale electronic components, and powered by batteries (Fig. 15g). After optimizing the sensor elements, the chip layout and the readout electronics, resulting in a sensor responsivity of 47.8 aF  Pa<sup>−1</sup> mm<sup>−2</sup> . Furthermore, the combination of silicon nitride [232], boron nitride and the Au/Sn eutectic bonding technology [233] can effectively protect the 2D material and improve its stability under high temperature or humid environments. 

##### **_6.1.3  Strain Sensors_** 

The work of most strain sensors relies on the piezoresistive effect, which are changes in the resistivity of semiconductors upon mechanical strain. Compared with conventional bulk materials, 2D materials undergo greater strain engineering due to their inherent mechanical strength [234]. However, a single 2D material stress sensor cannot perform the measurement task in certain application scenarios, such as pressure distribution measurements on flat or curved surfaces. A strain sensor chip composed of many stress sensor units and processing circuits arranged reasonably can achieve relevant functions and has the advantages of high resolution and high integration. The piezoresistive property of nanographene films can be modulated by the density and lateral dimensions of the quasi-continuous nanographene film [235]. This integrated array of graphene e-skin construct has the ability 

to measure the surface strain distribution of thin films in real time, as shown in Fig. 15h. Zhang et al. demonstrated the ultralow crosstalk sensor array using the photo-reticulated strain localization films [236]. The unique sandwich structure not only ensures that the stacked structure will not separate but also provides physical isolation for the pressure sensor even in the bent state (Fig. 15i). 

##### **_6.1.4  Optical Sensors_** 

2D materials exhibit optoelectronic properties, physical properties, and controlled quantum properties of 2D systems beyond those of conventional semiconductors due to the atomic-level limitations of the longitudinal scale. In addition, the growth, transfer and patterning processes for largearea, high-quality 2D materials have become increasingly mature [237], making them ideal for fabricating miniature high-performance optical sensor chips. The major categories of operation mechanisms in 2D photodetectors are photovoltaic effect, photoconductive effect, photogating effect, photothermoelectric effect, and bolometric effect. Although different detection mechanisms have been reported for 2D photodetectors, their performance can still be judged by the main figures-of-merit, such as photoresponsivity, external quantum efficiency, specific detectivity, response time, optical bandwidth, and so on. 

At present, significant research progress has been made in photodetectors based on 2D materials. However, the current system composed of discrete devices has problems with high noise, high losses, and narrow bandwidth. Therefore, in order to adapt to the rapid development of high-capacity and high-speed optical systems, optoelectronic devices should develop toward low dimensionality, miniaturization, and integration. The incorporation of  MoS2 switching transistors and  MoS2 phototransistors in an active pixel image sensor array, achieved through a two-step large-area growth process, presented a promising approach [238], as shown in Fig. 16a. The transparent top-gate electrodes avoid the shading of the photosensitive area by the traditional top gate and improves the responsiveness of the photodetector (119.16 A  W<sup>−1</sup> ). The opaque top-gate switching transistors enable individual control of 64 pixels (Fig. 16b), facilitating the use of 2D material photodetector chips in next-generation image detection applications. The latest generation of intelligent photodetector chips possess the capability to 

© The authors 

https://doi.org/10.1007/s40820-023-01273-5 

Page 39 of 96 **119** 

Nano-Micro Lett. (2024) 16:119 

perceive and process visual information within a single unit, thereby eliminating the need for redundant data transmission [239]. The monolithic vision enhancement chip, illustrated in Fig. 16c, with a resolution of 619 pixels, encompasses multiple functionalities including optical sensing, storage, and processing. Notably, the  MoS2 analog processing circuit enables dynamic adjustment of photocurrent to align with the characteristics exhibited by human retinal neurons. 

Due to the low absorption of light by single-layer 2D materials, the photoresponsivity of photodetectors based on single-layer 2D materials is often not high enough. 

Constructing 2D material heterojunctions is a major method to improve the overall performance of photodetectors. Figure 16d illustrates a wafer-scale photodetector based on PtTe2/graphene heterostructure by a directly tellurizing platinum film in a furnace [240]. This photodetector exhibited excellent photodetection performances including high _D_ * (~ 2.58 ×  10<sup>10</sup> jones) and a fast response time of ∼ 8.4 μs. Figure 16e exhibits a wafer-scale nanoporous active pixel image sensor matrix with  MoS2 phototransistors and indium–gallium–zinc oxide (IGZO) switching transistors [241]. Nanoporous bilayer  MoS2 was exposed to edges that resulted in the 



**Fig. 16** 2D material-based optical sensors. **a** Schematic illustration of an 8 × 8 image sensor array based on bilayer  MoS2 composed of opaque Ti/Au electrodes switching transistor and transparent IZO electrodes phototransistor. **b** Photograph of the 8 × 8 image sensor array based on bilayer  MoS2 and a pixel circuit diagram of proposed image sensor array. Reproduced with permission [238]. Copyright (2020), Nature Publishing Group. **c** Optical microscopic image and zoom-in image of a fabricated artificial machine vision enhancement  MoS2 chip on a sapphire substrate. Reproduced with permission [239]. Copyright (2022), American Association for the Advancement of Science. **d** Large-scale  PtTe2/ graphene photodetectors on a 4-inch wafer. Reproduced with permission [240]. Copyright (2022), American Chemical Society. **e** Wafer-Scale nanoporous  MoS2 active-matrix image sensor array on 4-inch Si/SiO2 wafer and cross-sectional view of one pixel. Reproduced with permission [241]. Copyright (2023), Wiley–VCH. **f** Optical images of the fully integrated 8 × 8 crossbar array of crypto engines, a representative crypto engine with five  MoS2 memtransistors, and an individual  MoS2 memtransistor. Reproduced with permission [208]. Copyright (2022), Nature Publishing Group 

1 3 

**119** Page 40 of 96 

Nano-Micro Lett. (2024) 16:119 

development of subgap states, which were associated with photogating to achieve an extremely high photoresponsivity of 5.2 ×  10<sup>4</sup> A  W<sup>−1</sup> . In the era of IoT, besides enhancing sensor performance, ensuring the security of sensor information is also crucial. Hence, it is necessary to develop a photoelectric sensor chip with on-chip encryption capability. The integration of crypto engines with  MoS2-based image sensors (Fig. 16f) enabled perception, storage, and protection of information while minimizing hardware investment and average power consumption [208]. 

The majority of current optical sensor chips mostly detect information such as the frequency and amplitude of light. The existing technology has great limitations when the detection target is close to the radiation signal of the background. The detection of polarization can enhance the identification of the target by increasing the amount of information to seven dimensions, thereby improving its precision and accuracy. The conventional polarization detection system is intricate and exhibits a low response rate, which does not align with the current trend of high performance and integration. The emergence and continuous advancement of anisotropic 2D materials is anticipated to address the issue of polarization-sensitive detection [242]. Moreover, the polarization of isotropic 2D materials can be detected through the formation of heterojunctions or rolled-up tubular structures [243]. Further, to address the drawbacks of low yield by conventional wet-etching methods in self-assembly techniques, a meticulously controlled dry-release approach was devised on a large-scale wafer platform [244]. 

##### **6.2  Chemical Sensors** 

The function of chemical sensors is to convert chemical quantities, such as the composition and concentration of chemical substances, into electrical quantities. The enormous specific surface area of 2D materials enhances the intermolecular interactions, thus enabling highly sensitive detection of ultralow concentration analytes. Moreover, 2D materials have a strong surface chemistry that could be improved with chemical functionalization or defect engineering to increase their selectivity for target detection objects. Over the past decade, an increasing number of experimental strategies have integrated multifunctional 2D materials with unique analyte recognition properties into 

miniaturized chips for the simultaneous detection of target analytes. 

##### **_6.2.1  Gas Sensors_** 

Rapid economic development brings a large amount of greenhouse gases and toxic gas emissions, which seriously threaten the natural environment and human health. The emergence of gas sensors has largely solved the problem of monitoring low concentrations of toxic and hazardous gases. Materials science and nanotechnology have contributed substantially to the advancement of gas sensor technology, striving to meet future sensor requirements. Room-temperature gas-sensitive technology based on 2D materials has received widespread attention in building high-density, low-power, and high-sensitivity gas-sensitive devices [245]. The  MoS2 gas-sensitive thin-film transistor (TFT) manufactured over a large area exhibited excellent consistency and achieved independent control [246], as shown in Fig. 17a. Using the principle of reduced conductivity of  NO2 adsorbed on the MoS2 surface, the gas sensor achieves ultrahigh sensitivity detection over a wide detection range of 1 to 256 ppm. Without the constraints of van der Waals interactions between graphene and the substrate surface, suspended graphene technology can significantly improve the gas detection sensitivity [247], as exhibited in Fig. 17b. The integration of CMOS and 2D materials is a feasible method for achieving low-cost and low-power gas sensor chips [248], as illustrated in Fig. 17c. The graphene gas sensor uses a metal throughhole connected to a CMOS readout circuit to enable the detection of  NO2 and  NH3, where the gas molecular interactions on the surface of the graphene sensor are read as delay-sensitive output frequencies. 

##### **_6.2.2  pH Sensors_** 

The pH sensor detects the concentration of hydrogen ions in the measured substance and converts it into a corresponding usable output signal, usually consisting of a chemical part and a signal transmission part. The classic modern commercial pH sensors measure the potential difference and monitor the hydrogen ion concentration in the measured solution utilizing a reference electrode and a target electrode. This method is highly mature in detecting hydrogen ion concentration, but its large volume and high demand for test 

© The authors 

https://doi.org/10.1007/s40820-023-01273-5 

