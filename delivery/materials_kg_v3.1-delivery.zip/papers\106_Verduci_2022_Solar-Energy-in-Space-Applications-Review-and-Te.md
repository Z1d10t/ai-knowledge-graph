# Solar Energy in Space Applications: Review and Technology Perspectives

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Advanced Energy Materials |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 287 |
| 作者 | Rosaria Verduci, Valentino Romano, G. Brunetti, Narges Yaghoobi Nia, A. di Carlo, Giovanna D'Angelo, C. Ciminelli |
| DOI | 10.1002/aenm.202200125 |
| 源文件 | 006_Verduci_2022_Solar-Energy-in-Space-Applications-Review-and-Te.pdf |

---
**Review** 



**www.advenergymat.de** 

# **Solar Energy in Space Applications: Review and Technology Perspectives** 

_Rosaria Verduci, Valentino Romano, Giuseppe Brunetti, Narges Yaghoobi Nia, Aldo Di Carlo,* Giovanna D’Angelo,* and Caterina Ciminelli*_ 

## **1. Introduction** 

**Solar cells (SCs) are the most ubiquitous and reliable energy generation systems for aerospace applications. Nowadays, III–V multijunction solar cells (MJSCs) represent the standard commercial technology for powering spacecraft, thanks to their high-power conversion efficiency and certified reliability/ stability while operating in orbit. Nevertheless, spacecraft companies are still using cheaper Si-based SCs to amortize the launching costs of satellites. Moreover, in recent years, new SCs technologies based on Cu(In,Ga)Se2 (CIGS) and perovskite solar cells (PSCs) have emerged as promising candidates for aerospace power systems, because of their appealing properties such as lightweightness, flexibility, cost-effective manufacturing, and exceptional radiation resistance. In this review the current advancements and future challenges of SCs for aerospace applications are critically discussed. In particular, for each type of SC, a description of the device’s architecture, a summary of its performance, and a quantitative assessment of the radiation resistance are presented. Finally, considering the high potential that 2D-materials (such as graphene, transition metal dichalcogenides, and transition metal carbides, nitrides, and carbonitrides) have in improving both performance and stability of SCs, a brief overview of some important results concerning the influence of radiation on both 2D materials-based devices and monolayer of 2D materials is also included.** 

Since 1957, when the Soviet Union developed and placed into Earth’s orbit the world’s first artificial satellite (Sputnik 1), several milestones have been achieved for space exploration. Nowadays, thousands of artificial satellites are in orbit to photograph and analyze the Sun, the Moon, the Earth, the other planets of our Solar System, asteroids, galaxies, and exoplanets. According to the Union of Concerned Scientists, currently there are more than 6000 satellites orbiting Earth of which 3372 are used for different purposes:<sup>[1]</sup> communication systems (internet, cell phones, radio, TV), global positioning system (location-based services and navigation), Earth observation, sensing and monitoring (weather tracking, disaster prediction). 

One of the main critical components of spacecrafts either in Earth orbit or for destinations far away from our mother star, i.e., the Sun, is the power generation 

R. Verduci, V. Romano Department of ChiBioFarAm University of Messina Messina I-98166, Italy G. Brunetti, C. Ciminelli Department of Electrical and Information Engineering Polytechnic University of Bari Bari I-70125, Italy E-mail: caterina.ciminelli@poliba.it N. Yaghoobi Nia, A. Di Carlo CHOSE-Department of Electronics Engineering University of Rome “Tor Vergata” Roma I-00133, Italy E-mail: aldo.dicarlo@uniroma2.it 

N. Yaghoobi Nia, A. Di Carlo ISM-CNR Institute of Structure of Matter National Research Council Roma I-00133, Italy G. D’Angelo Department of Mathematical and Computer Sciences Physical Sciences and Earth Sciences University of Messina Messina I-98166, Italy E-mail: gdangelo@unime.it 

G. D’Angelo CNR Institute for Chemical-Physical Processes (IPCF) Messina I-98158, Italy 

The ORCID identification number(s) for the author(s) of this article can be found under https://doi.org/10.1002/aenm.202200125. 

© 2022 The Authors. Advanced Energy Materials published by WileyVCH GmbH. This is an open access article under the terms of the Creative Commons Attribution License, which permits use, distribution and reproduction in any medium, provided the original work is properly cited. 

### **DOI: 10.1002/aenm.202200125** 

**2200125 (1 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

**Table 1.** Advantages and disadvantages of the several PGSs used for different space missions. 

|Power generation system|Type of mission|Pros|Cons|
|---|---|---|---|
|Nonrechargeable batteries|Short duration missions|• Inexpensive<br>• Lightweight<br>• High energy density<br>• No risks associated to nuclear wastes/<br>accidents|• Can only be used once|
|Fuel cells|Short duration missions|• Low specific mass<br>• Long lifetime<br>• Lightweight<br>• No risks associated to nuclear wastes/<br>accidents|• Expensive<br>• Not mature technology<br>• Safety issues|
|Photovoltaic|Long duration and inner planets missions|• Stand-alone power generation<br>• Renewable and sustainable energy source<br>• No risks associated to nuclear wastes/<br>accidents|• Dependence on orbit features (day/night<br>cycles, geometrical angle of incidence, etc.)<br>• Need of storage system<br>• Fabrication and installation of solar panels<br>are expensive<br>• Solar panel take up lots of space|
|Nuclear|Long duration and outer planets missions|• Inexpensive source of energy<br>• A small amount of uranium is required to<br>produce a lot of energy<br>• It is not affected by outside conditions|• Nonrenewable<br>• Environmental impact<br>• Potential of nuclear accidents<br>• Security threat<br>• Expensive safety equipment|
|Rechargeable batteries|Long duration and inner/outer planets<br>missions|• High power density<br>• High discharge rate<br>• Good low temperature performance<br>• No risks associated to nuclear wastes/<br>accidents|• Expensive<br>• Safety issues<br>• Low energy density|



system (PGS). Depending on the specific mission (duration and distance from the Sun evaluated in terms of astronomical unitAU, i.e., the average distance between the Sun and the Earth, which is ≈149.6 million km) and the electric power demand, several technologies can be used to obtain an efficient power supply.<sup>[2]</sup> The advantages and disadvantages of the various PGSs are summarized in **Table 1** . 

For very short missions (some weeks/months), electrochemical power sources such as non-rechargeable batteries and fuel cells can be employed.<sup>[2]</sup> For longer missions (several years), photovoltaic (PV) devices or nuclear power systems (NPSs) in conjunction with rechargeable batteries are the only available options to provide uninterrupted and stable electrical power.<sup>[2]</sup> Satellites for inner planets missions (i.e., Mercury 0.4 AU, Venus 0.7 AU, Earth 1.0 AU, and Mars 1.5 AU)<sup>[3]</sup> employ solar cells (SCs).<sup>[2]</sup> This is due to the fact that at these distances the power density of sunlight is sufficient for the production of electricity. Specifically, at 1 AU the irradiance of the sun on the outer Earth’s atmosphere (with a spectral distribution indicated as AM0) is 1367 W m<sup>−2</sup> .<sup>[4,5]</sup> However, the output power (1–2 W) generated by a single SC is not enough for space vehicles that require several kW of electric power, thus solar arrays are used.<sup>[6,7]</sup> A solar array is made up by several solar panels (or modules), that comprise more SCs connected together (in series and/or parallel ways). Quite differently, for satellites for outer planets missions (i.e., Jupiter 5.2 AU, Saturn 9.6 AU, Uranus 19.2 AU, and Neptune 30.0 AU)<sup>[3]</sup> working in low intensity low temperature conditions, NPSs seem the best solution to satisfy mission requirements.<sup>[2]</sup> In fact, the solar irradiance on Jupiter, Saturn, Uranus, and Neptune is 3.7%, 1.1%, 0.28%, 

and 0.1% of that at 1 AU, respectively.<sup>[3]</sup> However, the use of NPSs raises several safety issues. For example, accidents resulting from launch failures and inadvertent re-entry may create dangerous conditions for both people and terrestrial environment.<sup>[8]</sup> For this reason, in the last decades PV research and technology developments paved the way for the exploitation of SCs also for satellites travelling into deep space beyond Mars, by employing several strategies depending on the investigated technology.<sup>[3,9]</sup> For instance, Stardust (sent to the comets Wild 2 and Tempel 1, 2.7 AU),<sup>[10]</sup> Dawn (used for the exploration of the largest asteroid Vesta and the dwarf planet Ceres, 3.0 AU),<sup>[11]</sup> Juno (currently studying Jupiter, 5.4 AU),<sup>[12]</sup> and Rosetta (commissioned for analysis of the comet 67P/Churyumov-Gerasimenko, 5.3 AU)<sup>[13]</sup> are solar-powered spacecraft designed to operate at great distances from the Sun. 

Usually, SCs are heterostructured devices made up by several different materials piled up onto a substrate. Currently, the most used light harvesters in PV technologies for space applications are Si and semiconductors used for multijunction solar cells (MJSCs) such as Ge, III–V semiconductors like GaAs, InP, and their alloys (InGaP, InGaAs, InGaNAs, AlInGaP, and AlInGaAs).<sup>[14–17]</sup> 

In particular, InGaP/InGaAs/Ge 3JSCs and AlInGaP/AlInGaAs/InGaAs/Ge 4JSCs produced by several companies such as, Azur Space, Spectrolab, SolAero, and CESI (with different size, formats, and thickness) and qualified for different space missions (according to the European and the American Space Standards), are nowadays the standard in the aerospace field as they offer better performances than the other PV technologies.<sup>[14–17]</sup> For example, commercially available AlInGaP/AlInGaAs/InGaAs/Ge devices (produced by Azur Space) exhibit a 

**2200125 (2 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

#### **www.advancedsciencenews.com** 

#### **www.advenergymat.de** 



**Figure 1.** Evolution of the PCE of some PV technologies (data source collected from ref. [22]). 

power conversion efficiency (PCE, defined as the ratio of the electrical power produced by the SC to the incident power on the SC)<sup>[4]</sup> up to 32% at the beginning of life (BOL) under 1 sun AM0 illuminations and a PCE up to 28.7% at the end of life (EOL), i.e., after 1 MeV electron irradiation with a dose of 10<sup>15</sup> particles cm<sup>−2</sup> , currently resulting the best performing space SC.<sup>[14]</sup> Despite their high performances, MJSCs suffer from the shortcomings of being rigid, thick (ranging from ≈80 to ≈200 µm),<sup>[14–17]</sup> heavy, i.e., with a specific power of ≈0.4–0.8 W g<sup>−1</sup> for a InGaP/GaAs/Ge 3JSC<sup>[18,19]</sup> (although the proper engineering of the metal contact can lead to values up to 3.8 W g<sup>−1</sup> for InGaP/GaAs/InGaAs)<sup>[20]</sup> and produced through complex fabrication processes (making them extremely expensive).<sup>[21]</sup> Nowadays, the research activity on innovative PV technologies for future missions, e.g., for megaconstellation programs, is focused not only on increasing the PCE (due to higher power demands) but also on reducing costs. In this regard, cheaper production processing techniques have been proposed for single-junction devices based on Si (PCE = 26.1% for lab-scale devices, under 1 sun AM 1.5G illumination),<sup>[22]</sup> making them appealing especially for short duration missions. For example, the satellites of the Starlink megaconstellation (constructed by SpaceX) are equipped with Si solar arrays.<sup>[23]</sup> Currently, Si-based SCs with a PCE of 16.9% at BOL under 1 sun AM0 

conditions are manufactured by AzurSpace and qualified for space missions.<sup>[14]</sup> However, Si-based SCs are nonflexible, heavy (with a thickness >100 µm and a specific power of ≈0.38 W g<sup>−1</sup> ) and require the use of time-consuming and expensive production procedures.<sup>[14,18]</sup> With the growing demand for more compact, lightweight, and cheaper satellites the need to find alternative PV technologies has arisen. In particular, Cu(In,Ga) Se2 (CIGS) thin film-based SCs represent a promising solution for next-generation space missions thanks to the high radiation resistance,<sup>[24,25]</sup> lightweight (specific power ≈3 W g<sup>−1</sup> )<sup>[18]</sup> and the possibility to be manufactured using flexible substrates through low-cost techniques (making them adaptable to many kind of shape and thus allowing the simplification of the spacecrafts design).<sup>[26]</sup> Despite their many advantages, CIGS-based SCs are not commonly used as power source for satellites because of their relatively low PCE (23.4% for lab-scale devices, under 1 sun AM 1.5G conditions).<sup>[22]</sup> Finally, in the last decades another class of materials, hybrid organic–inorganic perovskites such as CH3NH3PbI3 (MAPbI3), have been used for the realization of perovskite solar cells (PSCs) with PCE reaching values up to 25.5% (for lab-scale devices, under 1 sun AM 1.5G conditions).<sup>[22]</sup> Such devices are showing encouraging results<sup>[27,28]</sup> for their future use in space applications because of i) the production through low cost solution-processed techniques,<sup>[29,30]</sup> ii) the realization of flexible devices with low weight (with a thickness <5 µm and a specific power of 23 W g<sup>−1</sup> , the highest of all PV technologies),<sup>[18,29]</sup> and iii) the excellent radiation hardness.<sup>[31–33]</sup> **Figure 1** shows the evolution of PCE of the several PV technologies discussed in this work, while **Table 2** summarizes some technological and performance metrics of both commercially available (MJSCs and Si-based SCs) and promising alternatives (CIGS-based SCs and perovskite SCs) for space applications. 

There are several articles and reviews dealing with different PV technologies for space applications (for example, Si-based SCs,<sup>[34–36]</sup> MJSCs,<sup>[21,37,38]</sup> CIGS-based SCs,<sup>[39–41]</sup> and PSCs<sup>[27,31–33,42,43]</sup> ) but, to the best of our knowledge, a systematic overview on this topic that includes and compares them all has not been provided yet. Herein, we provide a summary of both commercially available PV technologies (Si-based SCs and MJSCs) and some of the promising ones (CIGS-based SCs and PSCs) for space missions. This review is organized as follows: first, the physical processes underlying the operation of an SC and the physical properties that guide the selection of semiconductor materials for the production of PV devices are discussed. In the second part, we describe the space environment and the 

**Table 2.** Comparisons of several technological and performance parameters of the main PV technologies currently used (MJSCs and Si-based SCs) or under investigation (CIGS-based SCs and PSCs) in the field space applications. 

||Multijunction|Silicon|Cu(In,Ga)Se2|Perovskite|
|---|---|---|---|---|
|Efficiency|High|Medium|Medium|Medium|
|Lab-scale record|47.1%|26.1%|23.4%|25.5%|
|Commercially available for space|Up to 32%|≈17%|Not available|Not available|
|Radiation hardness|High|High|Excellent|High|
|Specific power|Low – Medium|Low|Medium|High|
||0.4–3.8 W g<sup>−1</sup>|0.38 W g<sup>−1</sup>|3 W g<sup>−1</sup>|23 W g<sup>−1</sup>|
|Flexibility|Low|Low|High|High|
|Fabrication cost|High|High|Low|Low|



**2200125 (3 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 

**Table 3.** Comparison of the energy bandgap ( _E_ g), Urbach energy ( _E_ u), electron ( _μ_ e) and hole ( _μ_ h) mobilities, and diffusion length ( _L_ D) of semiconductors typically used in PV devices. 

|Material|_E_g[eV]|_E_U[meV]|_μ_e[cm<sup>2</sup>V<sup>−1</sup>s<sup>−1</sup>]|_μ_h[cm<sup>2</sup>V<sup>−1</sup>s<sup>−1</sup>]|_L_D[µm]|Refs.|
|---|---|---|---|---|---|---|
|c-Si|1.12|11|1450|500|100|[51–53]|
|GaAs|1.42|7.5|8|400|100–900|[51,53,54]|
|CIGS|1–1.7|16|100|2.5|0.3–0.52|[55–57]|
|CdTe|1.57|10|1100|100|0.4–1.6|[51,58,59]|
|Ge|0.66|–|3900|1800|–|[51]|
|InGaP|1.34–2.26|9|400–2000|35|2|[60–63]|
|MAPbI3|1.6|15|1.4|0.9|0.3–1|[49,53,64]|



specific requirements that an SC must meet to withstand the rigid and harsh conditions in which it operates. In the third part, we summarize the performance of each type of space SC and the effects that the hostile space environment (considering, for example, high energy particle radiations and thermal fluctuations) has on the properties of different PV technologies. Finally, a perspective about the development of PV devices for future space missions is presented. 

## **2. Materials and Physical Properties for Photovoltaic** 

In SCs, semiconductors are used to absorb sunlight and photogenerated electron–hole pairs. Such charge carriers are then transported through the device and finally collected at the electrodes. Thus, the working principle of SCs can be divided into three main steps: i) light absorption and generation of charge carriers, ii) separation and transport of charge carriers, and iii) collection of charge carriers. The optimization of these three aspects is fundamental to improve device performances. 

In particular, efficient sunlight absorption requires the use of semiconductors with an energy bandgap ( _E_ g) lying in the vis– IR range, since the emission spectrum of the sun is centered in this region.<sup>[44]</sup> Photons with energy equal or higher than _E_ g can be absorbed, thus an optimal light harvester should be characterized by a small _E_ g ( **Table 3** ). However, small _E_ g light harvesters usually lose a huge amount of solar energy because of thermalization (i.e., energy transfer between charge carriers) and cooling (consisting in the emission of phonons) of hot-carriers,<sup>[4,45]</sup> so a trade-off exists in the choice of _E_ g, underlying the need for its proper engineering. Quantitatively, the absorption of radiation is described by means of the absorption coefficient ( _α_ ) that should be panchromatic (to absorb the majority of the sunlight) and high (so that thin samples can be used to harvest the whole solar spectrum, reducing the cost of the resulting SC). **Figure 2** shows the comparisons between _α_ values for a variety of semiconductors used for PV applications. 

Noteworthy, for each material _α_ does not show a steep increase at the corresponding _E_ g value, i.e., sub-bandgap absorption occurs. This is due to the inevitable presence of defects, in the crystal structure of semiconductors, which adds available energy states within the bandgap. As a result, _α_ shows an exponential trend for energies lower than _E_ g _,_ i.e., α( _E_ ) ∝ _e_<sup>_E_</sup> /<sup>_E_</sup> U, where _E_ U is the Urbach energy.<sup>[48]</sup> Thus, _E_ U can be used to quantitatively compare the insurgence of such defect states: 

for example, in the case of Si, GaAs, and MAPbI3 the _E_ U is 11, 7.5, and 15 meV (Table 3).<sup>[49]</sup> The latter is an interesting result, since both Si and GaAs are produced as single crystalline materials,<sup>[50]</sup> while perovskites can be easily processed by solutionbased techniques (that are more prone toward the formation of a microcrystalline structure).<sup>[29,30]</sup> 

Once electron–hole pairs are photogenerated, they can form a neutral bound state (called exciton) that reduces the number of available free carriers and increases the probability of recombination events (the recombination of charge carriers before their separation is termed geminate recombination).<sup>[65]</sup> The binding energy ( _E_ B) of excitons ranges between tens (Wannier– Mott excitons) to thousands (Frenkel excitons) of meV.<sup>[65]</sup> In the former case, _E_ B can be calculated by considering the exciton as ∗ 2 an hydrogenic system obtaining: _E_ B ∝− _m_ rεr− , where _m_ r∗ is the reduced mass of the electron–hole pair and _ε_ r is the relative dielectric function of the material.<sup>[66]</sup> It is then clear that the electronic and dielectric properties of the light harvester are fundamental to generate free charge-carriers. 

Afterward, the free electrons and holes must be further separated and transported toward the interfaces with the electrodes. Separation strategies exploit both drift (due to the presence of an electric field, usually arising because of junctions formed between the light harvester and charge transporting layers) and diffusion (caused by a gradient of carrier concentration) processes.<sup>[4,67,68]</sup> Efficient transport stems from i) the ability of electrons/holes to travel quickly within all the layers making up the SC (which is quantitatively expressed by the mobility _μ_ ) and ii) the low recombination rates of charge carriers. In inorganic materials such as Si and GaAs, three main recombination mechanisms occur: i) nonradiative (due to trap states arising from imperfections of the crystal structure), ii) radiative (associated to the recombination of one electron with a hole), and iii) Auger (a multiparticle process involving also the emission of phonons).<sup>[4,66,69]</sup> The diffusion length ( _L_ D), which represents the average length that charge carriers can travel through a material, can be estimated by extracting the recombination rates of these processes. Consequently, a light harvest should possess an _L_ D higher or equal to its thickness, to ensure that electrons/ holes are efficiently collected at the interfaces. Table 3 lists the values of _μ_ e, _μ_ h, and _L_ D for several PV materials. 

The performances of SCs are evaluated in terms of several parameters (determined from the current–density–voltage ( _J_ – _V_ ) characteristics under illumination) including the shortcircuit current density ( _J_ SC), the open-circuit voltage ( _V_ OC), the fill factor (FF), and the PCE.<sup>[4]</sup> The _J_ SC is the current that 

**2200125 (4 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

#### **www.advancedsciencenews.com** 



**Figure 2.** Dependence of _α_ to excitation wavelenght for several semiconductors used in the PV industry. (data source for MAPbI3, Si, GaAs and Ge collected from ref. [46] while for CIGS and InP collected from ref. [47]). 

flows through the SC when _V =_ 0, i.e., when the SC is short circuited.<sup>[4]</sup> The _V_ OC is the maximum value of V available from an SC when _J_ = 0, i.e., when the SC is in open circuit condition.<sup>[4]</sup> The FF is the ratio of the maximum power generated by the SC to the product of _J_ SC and _V_ OC.<sup>[4]</sup> **Table 4** summarizes the best reported values of these parameters for the discussed PV technologies. The incident power is that of a reference spectrum, for example in terrestrial applications the global air mass 1.5 (AM 1.5G) standard is typically used (i.e., the sunlight spectral distribution taking into account the absorption deriving from the atmosphere’s constituents, corresponding to 1000 W m<sup>−2</sup> for 1 sun illumination),<sup>[70]</sup> while the AM0 (i.e., the sunlight spectral distribution outside the atmosphere, characterized by an intensity of 1367 W m<sup>−2</sup> at 1 sun conditions).<sup>[5]</sup> Usually PCEs of SCs working under AM0 conditions are lower with respect to the AM 1.5G case, since the absence of the atmosphere results in increased contribution in the UV and IR region of the solar spectrum that are scarcely photo-converted.<sup>[71]</sup> 

It is worth emphasizing that the maximum theoretical PCEs are limited by restrictions due to the processes involved during solar-energy conversion. Indeed, for an SC using a single lightharvester with a bandgap of 1.34 eV, at a temperature of 300 K and under 1 sun AM 1.5G illumination, detailed balance limit predicts a maximum PCE of 33% (Shockley–Quiesser limit).<sup>[70]</sup> Such limit increases to 66% for a **SC** made up by an ideal infinite sequence of light harvesters (this idea led to the realization of the so-called MJSCs, which are discussed in more details in the following paragraphs). For the case of AM0 illumination, the maximum (PCE = 30.1%) occurs for a bandgap of 1.26 eV. 

In general, PV technologies fall into three broad categories: wafer-based cells (traditional crystalline Si and III–V semiconductors); commercial thin-film cells (amorphous Si, CdTe, and CIGS); and emerging thin-film technologies (perovskite, organic, and quantum dot solar cells). To classify those PV technologies a well-established framework based on the complexity of the light absorbing material, has been proposed.<sup>[72]</sup> This complexity concept is related to the number 

#### **www.advenergymat.de** 

of atoms in the molecule or crystal unit forming the building block of the material. The classification ranges from waferbased technologies (such as crystalline Si or GaAs) to commercially available devices (as amorphous Si, CdTe, and CIGS) and emerging thin film SCs (as those based on perovskite, organic and quantum dots). Some correlations between complexity and performance have been experimentally demonstrated, i.e., the cost and PCE decreases or increases, respectively, as the material complexity increases.<sup>[72]</sup> 

Currently, crystalline Si-based SCs are the most commercially widespread. However, Si has the disadvantage of being an indirect-bandgap material, thus high thicknesses (>100 µm, which are comparable or even higher than its _L_ D, Table 3) are required to optimize light-harvesting. Lab-scale Si-based SCs hold a record of PCE = 26.1%, while modules show PCE = 24.4%.<sup>[22,73]</sup> On the contrary, III–V semiconductors have direct bandgaps and high _α_ , so theoretically 1–2 µm thick GaAs-based SCs can reach PCE = 30%.<sup>[50]</sup> Indeed, the current record for the highest PCE of single-junction lab-scale SCs is that of GaAs with 27.8% for single crystal and 29.1% for thin-film.<sup>[21,22]</sup> However, the use of this technology is mainly hindered by the expensive costs of both raw materials and fabrication processes and issues related to the disposal of As.<sup>[67]</sup> A very attractive class of materials is that of CIGS since the bandgap can be tuned by proper engineering of the chemical composition, it can be deposited on flexible substrates, low thicknesses are required to harvest light and low temperature techniques are used for the fabrication of CIGS-based SCs.<sup>[50]</sup> According to the Shockley–Quiesser limit, high theoretical PCEs are expected for devices using these materials, but still lower values than Si-based SCs have been reported both on lab-scale (23.4%) and modules (19.2%).<sup>[22,73]</sup> Among the emerging technologies, perovskites gained huge attention because of their tunable bandgap (by engineering the chemical composition), high and panchromatic _α_ allowing thin samples (≈500 nm) to absorb the whole solar spectrum, low cost and fabrication from liquid solutions.<sup>[30,74–76]</sup> As a result, currently labscale perovskite-based SCs show PCE = 25.5%.<sup>[22]</sup> However, such devices still suffer from stability issues mainly related to moisture and oxygen contamination, that hinder their widespread as a single-junction PV technology.<sup>[77]</sup> With the aim to overcome the Shockley–Quiesser limit, several strategies have been proposed, such as the use of lenses and mirrors to increase the intensity of the input solar radiation (concentrated PV systems)<sup>[78]</sup> and MJSCs. The latter kind of device consists of several individual light harvesters (called also subcells) with increasing bandgaps stacked on top of each other and connected in series.<sup>[79]</sup> This structure favors a more efficient absorption of the solar spectrum, indeed MJSCs hold the record for the highest PCEs in both lab-scale and modules cases (47.1% and 40.6%, respectively, both values referring to concentrated 4-JSCs).<sup>[22,73]</sup> 

However, crystalline Si remains the technology to beat, since the emerging PV technologies show complex manufacturing processes and are more expensive. In general, much work has to be done to identify the most appropriate technology to manufacturing low cost, robust, flexible, and lightweight solar modules. Some new applications can be investigated for the novel thin film PV materials, such as absorbing ultraviolet and/ or infrared light, being transparent for the visible light. 

A strong research effort is expected to develop new concepts on solar cells based on carbon nanotubes, hot carrier, 

**2200125 (5 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

**Table 4.** Confirmed SCs parameters measured under the global AM 1.5G spectrum (1000 W m<sup>−2</sup> ) at 25 °C. 

|PV technology|PCE [%]|_V_OC[V]|_J_SC[mA cm<sup>−2</sup>]|FF [%]|Refs.|
|---|---|---|---|---|---|
|Si (single crystal)|26.1|0.73|42.62|84.3|[80]|
|Si (heterostructures)|26.7|0.74|42.5|84.7|[81]|
|CIGS|23.4|0.73|39.58|80.4|[82]|
|CIGS (flexible)|20.82|0.73|36.74|77.2|[83]|
|Perovskite|25.5|1.19|25.74|83.2|[84]|
|Perovskite (flexible)|21.10|1.13|23.79|78.9|[85]|
|InGaP/GaAs/InGaAs|37.9|3.06|14.27|86.7|[86]|



intermediate bandgap, quantum well and quantum dot, perovhas been established for electrons and protons at different skite solar cells, perovskite/Si, and perovskite/CIGS tandems. altitudes around Earth’s atmosphere.<sup>[89,91,98,99]</sup> As concerns Attention should be paid also on solar arrays, which are indirectly ionizing radiations ( _γ_ -rays and neutrons), it was estidemanded to cover all customers’ requirements. This means mated that a space SC can accumulate a dose of: i) ≈10 000 Gy the need of an additional effort on the development of the solar of _γ_ radiation (in 20 years, at low and medium Earth orbit)<sup>[100]</sup> array technology and, in particular, of the panel substrate techand ii) 2.8 × 10<sup>11</sup> particles cm<sup>−2</sup> (in one year) of neutrons (with nology (rigid, flexible), deployment mechanisms, PV assembly energy varying from 10<sup>−1</sup> to 10<sup>11</sup> eV) at the International Space technology, new in-line testing methods and electrical measureStation (ISS) orbit.<sup>[101]</sup> Therefore, on-ground experiments are ment techniques.<sup>[87]</sup> usually conducted through accelerated tests, i.e., by accumulating such high radiation doses, with the aim to simulate longlasting use of devices in the space environment. The fourth **3. Space Environment and Requirements** factor responsible of space-induced degradation is represented by thermal fluctuations (usually ranging between at least **for Space Solar Cells** −180 and 150 °C around Earth orbit).<sup>[102]</sup> Thermal cycles are very **3.1. Space Environment Features** dangerous for spacecraft materials and devices since they can cause thermal stresses and eventually cracking of some comUnderstanding the space environment and its effects on space ponents or delamination of several layers in heterostructured vehicles is of paramount importance for the successful design SCs.<sup>[91,92]</sup> So thermal control systems are fundamental to mainand operation of SCs for different space missions. According to tain the space vehicle at an appropriate temperature range.<sup>[92,103]</sup> the NASA Marshall Space Flight Center, the space environment All the factors discussed up to this point are deeply influenced can be described through seven components.<sup>[88]</sup> The first one by the solar activity (fifth component), i.e., phenomena occuris plasma (or solar wind), i.e., the stream of charged particles ring on the sun’s surface, because it varies the energy and denflowing out of the solar corona,<sup>[88,89]</sup> representing a serious sity distribution of the emitted plasma.<sup>[89,91]</sup> The sixth factor threat to the long lasting function of spacecrafts because it can described by the NASA Marshall Space Flight Centre is the neuinduce surface charging, electrostatic discharge, power loss, and tral atmosphere that influences the lifetime of spacecrafts comshort circuit in electronic and PV components.<sup>[90–92]</sup> Such effects ponents mainly because of the presence of atomic oxygen and can be mitigated through shielding strategies and active control high vacuum conditions.<sup>[92]</sup> While the former is responsible of of potential.<sup>[92–94]</sup> Moreover, when the solar wind approaches several physical and chemical reactions like chemical bonds Earth, interactions with the geomagnetic field occur (second breaking, surface oxidation, and erosion of materials,<sup>[104]</sup> which component of the space environment) which typically trap the can be mitigated through the use of anticorrosive materials and incoming charged particles in two regions, called Van Allen coatings;<sup>[105,106]</sup> vacuum induces several detrimental phenomena radiation belts. Specifically, the inner (extending from an altisuch as materials outgassing, adhesion and cold welding, matetude of 3200 to 16 000 km) and the outer (ranging from 13 000 to rials evaporation, sublimation, and decomposition.<sup>[91,92]</sup> Hence, 38 000 km) belts trap high-energy protons and electrons, respecpressure control systems and sealing strategies are needed. tively.<sup>[89,91,95]</sup> It is then clear that spacecrafts orbiting at these Finally, the seventh factor accounts for the presence of metealtitudes must withstand such conditions, i.e., the effects due oroids and space debris,<sup>[91]</sup> a threat to spacecrafts because of to radiation (the third factor characterizing space). In general, the catastrophic consequences of possible collisions (strucdirectly ionizing radiations (protons and electrons) can damage tural damage of materials, surface erosion, and surface effects spacecraft’s components through ionization and formation of causing variations in material properties).<sup>[91,92]</sup> Thus, several defects.<sup>[96,97]</sup> Similarly, hazards related to indirectly ionizing methods have been adopted aiming to protect spacecrafts and radiations (neutrons and _γ_ -rays) are also problematic for the to control/reduce the amount of debris (for example, metallic stability of spacecrafts since these can release charged particles shielding, recovery, deorbiting, and laser removal).<sup>[92,107,108]</sup> Of within materials or atom displacement (due to scattering or the seven factors aforementioned, the most dangerous for the recoiling of nuclei).<sup>[96]</sup> Consequently, it is fundamental to know stability and lifetime of materials for SCs is due to radiation the average fluxes and energies of all radiation sources aforeeffects, since the remaining ones can be addressed by adopting mentioned. For example, a flux of 10<sup>3</sup> to 10<sup>8</sup> particles cm<sup>−22</sup> s<sup>−11</sup> shielding strategies or by optimal spacecrafts designing. 

Understanding the space environment and its effects on space vehicles is of paramount importance for the successful design and operation of SCs for different space missions. According to the NASA Marshall Space Flight Center, the space environment can be described through seven components.<sup>[88]</sup> The first one is plasma (or solar wind), i.e., the stream of charged particles flowing out of the solar corona,<sup>[88,89]</sup> representing a serious threat to the long lasting function of spacecrafts because it can induce surface charging, electrostatic discharge, power loss, and short circuit in electronic and PV components.<sup>[90–92]</sup> Such effects can be mitigated through shielding strategies and active control of potential.<sup>[92–94]</sup> Moreover, when the solar wind approaches Earth, interactions with the geomagnetic field occur (second component of the space environment) which typically trap the incoming charged particles in two regions, called Van Allen radiation belts. Specifically, the inner (extending from an altitude of 3200 to 16 000 km) and the outer (ranging from 13 000 to 38 000 km) belts trap high-energy protons and electrons, respectively.<sup>[89,91,95]</sup> It is then clear that spacecrafts orbiting at these altitudes must withstand such conditions, i.e., the effects due to radiation (the third factor characterizing space). In general, directly ionizing radiations (protons and electrons) can damage spacecraft’s components through ionization and formation of defects.<sup>[96,97]</sup> Similarly, hazards related to indirectly ionizing radiations (neutrons and _γ_ -rays) are also problematic for the stability of spacecrafts since these can release charged particles within materials or atom displacement (due to scattering or recoiling of nuclei).<sup>[96]</sup> Consequently, it is fundamental to know the average fluxes and energies of all radiation sources aforementioned. For example, a flux of 10<sup>3</sup> to 10<sup>8</sup> particles cm<sup>−22</sup> s<sup>−11</sup> 

**2200125 (6 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

**www.advancedsciencenews.com** 

#### **www.advenergymat.de** 

### **3.2. Other Requirements for Space Solar Cells and Arrays** 

Besides the effects of the harsh space environment, several other technological and economic aspects must be considered for the development of space SCs and solar arrays. Firstly, since the area available for mounting SCs on board of a spacecraft is limited, it needs to have a high PCE to reduce the size of the solar arrays. To date, the best performing commercially available SCs for space applications are offered by MJSCs, with PCEs ranging between 29% and 32% at BOL, AM0 conditions, and 1 AU.<sup>[14–17]</sup> Moreover, a power output of the order of 20 kW (generally using rigid panel arrays) is the standard required on many satellites.<sup>[3]</sup> For higher power demands, flexible blanket array technology is more attractive because it allows to realize solar arrays (where rigid substrates are substituted by mesh or polyimide sheets) that are stowed in a small volume during launch and unfolded/unrolled once the satellite is in orbit.<sup>[3]</sup> It should be noted that this terminology does not refer to the flexibility of the SCs (which comprise unbendable materials such as Si and III–V semiconductors) but to the overall array, which comprises several interconnected panels that can thus be bent along the formed hinges.<sup>[109]</sup> Flexible blanket arrays include, for example, International Space Station arrays (manufactured by Lockheed-Martin), the Ultraflex (manufactured by Northrup Grumman Innovation System) that was used on the Mars Phoenix Lander and the Mars InSight Lander and Roll Out Solar Array (manufactured by Deployable Space Systems).<sup>[3]</sup> In particular, the ISS solar arrays comprise 262.400 Si-based SCs welded and glued to eight thin, flexible blankets, generating up to 160 kW.<sup>[110,111]</sup> However, since both MJSCs and Si-based SCs are rigid and expensive, the use of alternative low-cost and truly flexible materials for SCs (such as CIGS-based SCs and PSCs) is extremely interesting for space missions. Flexible SCs have also the advantage of higher specific power (i.e., the ratio of generated power per kg of mass, measured in W kg<sup>−1</sup> ) with respect to rigid SCs as will be discussed in more detail in the following sections. This is beneficial from an economic point of view because it allows to reduce the quantity of material sent in orbit and thus to minimize the expensive launching costs (ranging between ≈30 000 and ≈1500 $ kg<sup>−1</sup> ).<sup>[112,113]</sup> Finally, flexible PV materials would allow the development of truly rollable and lightweight solar arrays. Currently, flexible blanket solar arrays have a specific power of ≈150 W kg<sup>−1</sup> and an areal power density of ≈338 W m<sup>−2</sup> which is higher than that of rigid panels (≈80 W kg<sup>−1</sup> and ≈330 W m<sup>−2</sup> , respectively). According to a NASA report from December 2017, in the near future (by 2030), research and technology development will allow to produce MJSCs with a PCE of ≈38% and to realize flexible solar arrays with power output >100 kW and specific power up to 250 W kg<sup>−1</sup> .<sup>[3]</sup> These ambitious goals seem reasonable, as MJSCs currently show PCEs up to 32%<sup>[14–17]</sup> and in recent times (June 2021), the solar power of the ISS has received an important upgrade thanks to the newly installed roll-out photovoltaic arrays (leading to an overall increase of the station power of 55 kW).<sup>[111]</sup> 

These significant improvements in the performances of SCs and solar array will ensure to meet the objectives of the bolder and more sophisticated future space missions.<sup>[3]</sup> Finally, since replacement or repair of devices are impossible once the 

satellite is in flight, it is imperative that SCs have high reliability to withstand mechanical stresses during launching phase. Main parameters in terms of power, to be addressed in future exploration missions, with new platforms and constellation programs, are power per unit area P/A (W m<sup>−2</sup> ), power per unit volume when stowed P/V (kW m<sup>−3</sup> ) and power to weight P/M (W kg<sup>−1</sup> ) ratio. Effective requirements for solar generators would be around P/V = 60 kW m<sup>−3</sup> , P/M = 200 W kg<sup>−1</sup> , and a power generation capacity of around 150 kW. This could be achieved using new configurations of innovative solar cell arrays and technologies, because the key power values exceed those currently at the state of the art for large telecom satellites, and, also for next developments of flexible solar array. 

Also, it should be noted that in addition to the solar cell which is a very important component to design, new concepts of solar arrays, cover-glasses, assembly technologies, and measurement techniques have to be developed. 

## **4. Solar Cells Used in Space** 

### **4.1. Solar Cells in Space Missions** 

The first solar-powered satellite, Vanguard 1 was launched into space by the United States, on 17 March 1958.<sup>[3]</sup> In this case, the energy was supplied by single-crystal Si-based SCs (providing a total power of about 1 Watt with PCE = 10% at 28 °C). Remarkably, Vanguard 1 remained operative for 6 years outperforming the battery powered systems that operated for only 20 days.<sup>[114]</sup> For over two decades, Si-based SCs were used to supply the power for space vehicles, with an increase of the devices’ PCE from <10% to >15%.<sup>[3]</sup> However, at the end of 1970s, GaAs-based SCs replaced Si because of their higher performances and radiation resistance.<sup>[3]</sup> The first satellite powered by GaAs-based SCs was the Navigation Technology Satellite 2 (NTS-2), placed into orbit in 1977.<sup>[115]</sup> During the 1990s, further advances in PV technologies led to the fabrication of MJSCs, which use two or more light-harvesters to optimize the absorption of sunlight. These devices are usually made up by III–V alloy semiconductors, offering increased efficiencies and higher radiation resistance compared to Si-based SCs.<sup>[3]</sup> Hughes HS 601HP, launched in 1997, represented the first example of a spacecraft using doublejunction SCs.<sup>[116]</sup> Starting from 2000s, despite the expensive fabrication costs due to the scarcity of materials and the complex production processes, 3JSCs became the standard for space applications, for two main reasons. First of all, commercially available 3JSCs reach PCE ≈30% at the beginning of life (BOL) (the highest of all photovoltaic technologies). The second reason is the high resistance to radiations, with commercial devices showing at the EOL a PCE of ≈27% after irradiation with 1 MeV electrons with fluxes of 10<sup>15</sup> particles cm<sup>−2</sup> .<sup>[14–17]</sup> 

In particular, in mid 2010s a great effort was made to develop the GaInP/GaInAs/Ge MJSCs. Best performance was achieved by the AZUR SPACE Solar Power GmbH with an efficiency of 26.5% at EOL,<sup>[87]</sup> which was really the practical limit of that technology. For this reason, in the last ten years, an important research activity has been carried out to develop a new and more efficient technology, as discussed in the following sections. 

**2200125 (7 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

### _4.1.1. Configurations and Operational Principle of Space MJSCs_ 

Although rigid and heavy (with a specific power of 0.4–0.8 W g<sup>−1</sup> ),<sup>[18,19]</sup> MJSCs based on III–V semiconductors dominate PV technologies for space applications because of their high performances (PCE = ≈32% industrially available)<sup>[14–16]</sup> and radiation resistance (with PCE retention ranging between ≈90% and ≈87% with respect to electron or proton irradiation, as thoroughly discussed later in this section).<sup>[14–16]</sup> Generally, an MJSC consists of several subcells (with increasing bandgaps) grown through epitaxial methods on one substrate and stacked on top of each leading to a standard structure with two terminal contacts ( **Figure 3** a,b). The subcells are connected in series through the introduction of tunnel junctions in order to avoid the formation of inverse p–n junctions which would block the current flow.<sup>[21]</sup> 

However, the realization of these devices can be challenging for several reasons including the need for high-quality crystalline materials<sup>[50]</sup> and the issues related to the monolithic deposition of several light-harvesters on top of each other (Figure 3a,b).<sup>[117]</sup> 

Currently, the state of the art of these devices for space applications is the 3JSC Ga0.50In0.50P/Ga0.99In0.01As/Ge (Figure 3a) grown on Ge substrate. Although in this device all materials are almost perfectly lattice-matched (LM), the bandgap combination of the absorbers is not optimal. In fact, the Ge bottom cell generates about 50% more current than the other two light-harvesters and, since the current of an MJSC is limited by the active layer producing the minimum photocurrent (as dictated by Kirchhoff’s current law), the excess current is wasted as heat.<sup>[118]</sup> The current-mismatch issue experienced by 3JSC is avoided in 4JSC. Indeed, the use of a further absorber layer, between InGaAs and Ge, successfully reduces the light reaching Ge and consequently its photocurrent. In particular, theoretical calculations have shown that, for the added light harvester, an _E_ g = 1 eV is required.<sup>[117,119]</sup> The only materials that can meet this condition, while being LM to both InGaAs and Ge, are the dilute nitride compounds (In _x_ Ga1− _x_ N _y_ As1− _y_ ) (Figure 3b). Indeed, the bandgap and the lattice constant of these compounds can be tuned to the desired values by adapting the In and N contents.<sup>[120]</sup> In particular, optimal matching (for both lattice and current issues) for the In _x_ Ga1− _x_ N _y_ As1− _y_ compound is obtained when _y_ = 0.3 _x_ .<sup>[121]</sup> However, the addition of a InGaNAs layer in a lattice-matched configuration is challenging because of the techniques used for its growth, i.e., metal organic vapor phase epitaxy (MOVPE) or molecular beam epitaxy (MBE).<sup>[122]</sup> In the former case, the high impurity density of hydrogen and carbon (coming from the metal organic precursor) leads to a drastic reduction of the optoelectronic properties of the resulting film (usually exhibiting a carrier diffusion length of ≈10–20 nm) and consequently of the device performances.<sup>[122,123]</sup> In the case of MBE, the incorporation of N atoms (using plasma sources)<sup>[124]</sup> causes the formation of electronic defects that act as nonradiative recombination centers.<sup>[120]</sup> Thus, with both MOVPE and MBE techniques, the growth of InGaNAs usually results in a low quality layer (due to the formation of clusters and interstitial defects),<sup>[125]</sup> so 4JSCs do not reach the theoretical PCE = 41%<sup>[21]</sup> but still lies at PCE ≈ 30%.<sup>[3]</sup> 

For these reasons, new fabrication options were developed to use lattice-mismatched materials: the mechanical stacking method, the metamorphic growth and the wafer bonding.<sup>[128]</sup> The former is not commonly used for large-scale MJSCs production because each subcell has to be grown on a different substrate, which must be afterward removed, making the entire fabrication process more complicated (in particular, each subcell requires its own electrical contact, thus a 3JSC would require six contacts) and expensive (Figure 3c).<sup>[21]</sup> The second method overcomes the constraint of using lattice-matched semiconductors through the deposition of a transparent buffer layer (TBL) between the subcells.<sup>[117]</sup> These TBLs are characterized by a lattice constant that varies gradually from the value of the bottom semiconductor to that of the semiconductor sequentially deposited on top, thus the propagation of defects and dislocations during the growth of the MJSCs is mitigated.<sup>[129]</sup> According to the growth direction (from narrow- to wide- _E_ g subcells or vice versa), this metamorphic growth method can be classified into upright and inverted metamorphic (UMM-IMM) (Figure 3d,e).<sup>[117]</sup> The IMM cell architecture has two advantages compared to the UMM cell. First, the two uppermost subcells (those with larger _E_ g) are grown on a lattice-matched substrate followed by the metamorphic growth of the remaining two subcells (Figure 3e). In this way, the propagation of defects from the lattice mismatched layers into the top junctions is controlled (dislocation density <10<sup>−4</sup> cm<sup>−2</sup> with respect to the typical value >10<sup>−6</sup> cm<sup>−2</sup> in the UMM structure).<sup>[130]</sup> Thanks to the superior quality of the larger _E_ g subcells, the IMM MJSCs show better performances with respect to UMM MJSCs. Moreover, since in IMM the lower _E_ g subcells are the last ones to be deposited, the choice of the materials for these junctions is more flexible (i.e., it is not restricted only to Ge).<sup>[117,130]</sup> Finally, the wafer bonding process basically allows the merging of SCs grown on different wafer substrates. This growth method can be divided into two technological types: direct bonding and intermediate-layer bonding (Figure 3f).<sup>[131,132]</sup> In the former method, two semiconductor wafers (of almost any material) adhere to each other through atomic bonds due to van der Waals forces (without the use of gluing layers or external forces).<sup>[132–134]</sup> The direct bonding technique requires three strict conditions to be met: good mechanical strength, high optical transmittance, and low resistivity at the bonding interface.<sup>[132]</sup> Moreover, to avoid the formation of pinholes at the interface of the two wafers, surface energy, roughness, and morphology must be properly engineered.<sup>[132,135]</sup> In the intermediate-layer case, the surfaces of two wafers are joined through the introduction of an intermediate layer (an adhesive, polymer, solder or metal) with high ductility and good adhesion with the aim to improve the quality of the bonding interface.<sup>[21,131,132]</sup> Despite both metamorphic growth and wafer bonding favor the realization of MJSCs with high PCEs, the manufacturing processes are complex and expensive.<sup>[129]</sup> 

### _4.1.2. Radiation Resistance of Space MJSCs_ 

Here, we report some significant results among the many that have been achieved on the radiation resistance of MJSCs.<sup>[37,38,136–138]</sup> In particular, Sharp et al.<sup>[37]</sup> performed a 

**2200125 (8 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 3.** Schematic representation of the fabrication processes of MJSCs. a) Lattice matched 3JCS and partitions of the AM0 spectrum utilization by a 3JSC. b) Lattice matched 4JCS and partitions of the AM0 spectrum utilization by a 4JSC. c) Schematization of a 4JSC realized by mechanical stacking method. d) Upright metamorphic 4JSC and representation of the lattice constant variations along the growth direction. e) Inverted metamorphic 4JSC and representation of the lattice constant variations along the growth direction. f) Schematization of the direct and intermediate layer wafer bonding process. (a,b) Adapted with permission.<sup>[3]</sup> Copyright 2017, NASA. (d) Adapted with permission.<sup>[126]</sup> Copyright 2014, AIP Publishing LLC. (e) Adapted with permission.<sup>[127]</sup> Copyright 2010, IEEE. 

study concerning the degradation of the PV parameters (short circuit current _I_ SC, _V_ OC, and maximum power _P_ MAX) of a lattice matched GaInP/GaAs/Ge 3JSC under irradiation by protons (with energies and fluences ranging, respectively, from 50 keV to 10 MeV and from ≈ 10<sup>9</sup> to ≈ 10<sup>13</sup> particles cm<sup>−2</sup> ) and electrons 

(with energies of 1, 2, and 12 MeV and at fluences between ≈10<sup>13</sup> and ≈10<sup>16</sup> particles cm<sup>−2</sup> ). As shown in **Figure 4** a–f, at fixed energy values for both ionizing radiations, the performance of the SC decreases with increasing fluences. As concerns the bombardment with electrons, the deterioration of the SC 

**2200125 (9 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 4.** a–f) Degradation of _V_ OC, _I_ SC, and _P_ max of an LM GaInP/GaAs/Ge as a function of proton and electron fluence for various particles energies. Reproduced with permission.<sup>[37]</sup> Copyright 2020, Wiley. 

performance is higher when the electron energy increases while, on the contrary, for proton irradiation the largest damage is produced by low energy particles (50–200 keV). In particular, a _P_ max retention of 13% and 21% is observed for 1 MeV electrons at fluence of 1 × 10<sup>15</sup> particles cm<sup>−2</sup> and for 10 MeV protons at 4.35 × 10<sup>12</sup> particles cm<sup>−2</sup> , respectively. 

Recently, Aierken and co-workers<sup>[38]</sup> studied and compared the degradation of the photovoltaic and optical properties of both Ga0.5In0.5P/Ga0.97In0.03As/Ge LM 3JSC and Ga0.5In0.5P/ GaAs/Ga0.7In0.3As IMM 3JSC under 1 MeV electron and 10 MeV proton irradiation (with fluences ranging from ≈10<sup>11</sup> to ≈10<sup>15</sup> particles cm<sup>−2</sup> ). It is worth highlighting that this work compares the radiation resistance and performances of LM and IMM architectures, with particular emphasis on the current matching condition which is pivotal for the realization of efficient MJSCs. Both SC structures suffer from losses in _V_ oc and _I_ sc (and consequently in _P_ max) as the electron and proton fluences increase (as shown in **Figure 5** a–c). Specifically, _P_ max for IMM and LM 3JSC decreases, from its initial value, to 86.3% and 85.0% for electron irradiation and 73.7% and 75.1% for proton irradiation (this trend can also be observed from the _J_ – _V_ curves reported in Figure 5d,g). Moreover, the degradation of all the PV parameters is greater under proton irradiation than under electron irradiation. This effect can be explained as a consequence of the bigger density of displacement damage (defects within the semiconductor of each subcell that act as nonradiative recombination centers and traps for the electron– hole pairs) induced by proton irradiation compared to electron irradiation. As a result, a higher reduction of the minority 

carrier _L_ D and thus of the PV parameters can be observed after proton bombardment.<sup>[38]</sup> 

Significantly, since in MJSCs current matching is a key factor determining the performance of the entire device, it is important that SCs keep this condition until EOL. For this reason, with the aim to estimate the current output of each subcell, the same authors studied the external quantum efficiency (EQE) of all subcells before and after particles irradiation. The EQE spectra for the nonirradiated IMM and LM 3JSCs and after irradiation with 1 MeV electron at a fluence of 1.0 × 10<sup>15</sup> particles cm<sup>−2</sup> and 10 MeV proton at a fluence of 4.35 × 10<sup>12</sup> particles cm<sup>−2</sup> , are shown in Figure 5e–f,h,i. From these figures it can be observed that proton irradiation causes more damage in both cell structures compared to electron irradiation. 

Interestingly, IMM and LM show a very small variation in the EQE of the GaInP top subcell. Furthermore, the IMM structure suffers from performance losses in the GaAs middle and GaInAs bottom subcells, while the LM structure reveals degradation of the GaInAs middle subcell, and the Ge bottom subcell changes abnormally.<sup>[38]</sup> The authors attributed such behavior to both shunt resistances and luminescence coupling, as already reported by other papers.<sup>[139,140]</sup> **Table 5** reports the value of _J_ sc derived from EQE spectra for each subcell before and after electron and proton irradiation, excluding the Ge absorber. Indeed, since Ge produces the highest _J_ sc among the three subcells before and after irradiation, the same authors do not consider its contribution to the overall performance of LM. From Table 5, it can be seen that for IMM the limiting current is that of 

**2200125 (10 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

**www.advancedsciencenews.com** 

#### **www.advenergymat.de** 



**Figure 5.** a–c) Degradation of _I_ SC, _V_ OC, and _P_ max of IMM GaInP/GaAs/GaInAs and LM GaInP/GaInAs/Ge solar cells irradiated by 1 MeV electron and 10 MeV proton versus fluences. d) _J_ – _V_ curve of an LM GaInP/GaInAs/Ge solar cell before and after irradiation with 1 MeV electron with a fluence of 1.0 × 10<sup>15</sup> particles cm<sup>−2</sup> and 10 MeV proton with a fluence of 4.35 × 10<sup>12</sup> particles cm<sup>−2</sup> . e,f) EQE spectra of an LM GaInP/GaInAs/Ge solar cell before and after irradiation with 1 MeV electron with a fluence of 1.0 × 10<sup>15</sup> particles cm<sup>−2</sup> and 10 MeV proton with a fluence of 4.35 × 10<sup>12</sup> particles cm<sup>−2</sup> . g) _J_ – _V_ curve of an IMM GaInP/GaAs/GaInAs solar cell before and after irradiation with 1 MeV electron with a fluence of 1.0 × 10<sup>15</sup> particles cm<sup>−2</sup> and 10 MeV proton with a fluence of 4.35 × 10<sup>12</sup> particles cm<sup>−2</sup> . h,i) EQE spectra of an IMM GaInP/GaAs/GaInAs solar cell before and after irradiation with 1 MeV electron with a fluence of 1.0 × 10<sup>15</sup> particles cm<sup>−2</sup> and 10 MeV proton with a fluence of 4.35 × 10<sup>12</sup> particles cm<sup>−2</sup> . Reproduced with permission.<sup>[38]</sup> Copyright 2021, Elsevier. 

GaInP, before irradiation, and of GaInAs, after bombardment. In the LM case, the lowest current is that of the GaInAs subcell. Consequently, these results show that the IMM has a better current matching condition at the EOL compared to LM and thus the IMM configuration is a promising candidate for space application. 

The high performance and good radiation tolerance of MJSCs make them a promising technology in the space market. However, with the current space exploration possibilities (also opened up by the privatization of the space industry) cheaper PV technologies are required. For this reason, Si-based SCs still remain the main choice for low power (≈0.38 W g<sup>−1</sup> )<sup>[16]</sup> and short duration missions, because of their good performances and lower production costs.<sup>[34]</sup> 

### _4.1.3. Si-Based Solar Cells_ 

The conventional structure of a Si-based SC consists of a p–n junction, metal contacts on both front and back sides and a front side antireflection coating (ARC) as shown in **Figure 6** a.<sup>[141]</sup> Through the years, the structure of Si-based SCs was modified with the aim to boost the performance. For example, to reduce the recombination loss of the minority carriers at the interface with the back metal contact, a highly doped region, called back surface field (BSF) is introduced (Figure 6b).<sup>[142]</sup> Another important improvement was the addition of a metallic thin layer (usually Al, Au, Ag, and Cu) on the back surface to reduce the transmittance losses, known as the back surface reflector (BSR)<sup>[142]</sup> (Figure 6c) was introduced.<sup>[142]</sup> Further achievements were obtained by using 

**2200125 (11 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

**Table 5.** Values of _J_ sc (extracted from EQE measurements) of Ga0.5In0.5P, GaAs, Ga0.7In0.3As, and Ga0.97In0.03As subcells of the IMM and LM solar cells irradiated with 1 MeV electron with a fluence of 1.0 × 10<sup>15</sup> particles cm<sup>−2</sup> and 10 MeV proton with a fluence of 4.35 × 10<sup>12</sup> particles cm<sup>−2</sup> . Reproduced with permission.<sup>[38]</sup> Copyright 2021, Elsevier. 

|IMM 3JSC|||||
|---|---|---|---|---|
|Energy of particles|Fluence [particles cm<sup>−2</sup>]||_J_SC[mA cm<sup>−2</sup>]||
|||Ga0.5In0.5P|GaAs|Ga0.7In0.3As|
|1 MeV|0|16.34|16.81|16.70|
|electron|1.0×10<sup>15</sup>|15.92|16.08|15.89|
|10 MeV|0|17.01|17.03|17.53|
|proton|4.35×10<sup>12</sup>|16.54|15.86|15.15|
|LM 3JSC|||||
|Energy of particles|Fluence [particles cm<sup>−2</sup>]||_J_SC[mA cm<sup>−2</sup>]||
|||Ga0.5In0.5P|Ga0.97In0.03As|Ge|
|1 MeV|0|17.92|17.87|–|
|electron|1.0×10<sup>15</sup>|17.64|16.97|–|
|10 MeV|0|18.11|17.72|–|
|proton|4.35×10<sup>12</sup>|17.73|16.29|–|



a combination of the BSF and the BSR technologies, resulting in the so-called back surface field and reflector (BSFR) (Figure 6d).<sup>[142]</sup> To date, the highest PCE for Si-based SC for space applications comes from passivated emitter and rear locally-diffused (PERL) configuration (PCE > 20.8 under AM0  conditions).<sup>[141]</sup> The PERL SC consists of i) an inverted pyramid light trapping structure, to minimize surface reflection and improve the amount of sunlight absorbed by the SC, ii) a double-layer ARC, iii) a localized BSF region, and iv) a BSR (Figure 6e).<sup>[141]</sup> 

High-performance devices do not necessarily exhibit a high stability. This implies that a careful analysis of the radiation resistance of the aforementioned architecture is essential to identify the best performing and long lasting Si-based SC. In 1994 the Engineering Test Satellite-VI experienced a failure of its engine thus it was placed on an elliptical orbit instead of a geostationary orbit.<sup>[143]</sup> As a result, the satellite orbited through 

a Van Allen belt accumulating high radiation doses that caused the failure of its Si-based SCs. 

With the aim to evaluate the life-time of Si-based SCs under extremely hostile radiation environment electron and proton induced degradation were investigated by Yamaguchi et al.<sup>[35,36]</sup> In particular, BSF Si-based SCs were irradiated with electrons with 1 MeV energy and a fluence ranging from 10<sup>14</sup> to 10<sup>17</sup> particles cm<sup>−2</sup> . The remaining factors (i.e., the ratio between the value of the SC parameters measured after and before particles irradiation) associated to _I_ SC, _V_ OC, and _P_ max are displayed in **Figure 7** a. 

The results show a gradual reduction of all the aforementioned parameters for fluences < ≈2 × 10<sup>16</sup> particles cm<sup>−2</sup> ; for fluences ranging between ≈2 × 10<sup>16</sup> and ≈5 × 10<sup>16</sup> particles cm<sup>−2</sup> both _I_ SC and _V_ OC reveal an anomalous behavior (the former increases while the latter decreases); finally for higher fluences the devices completely fail. Same trend was observed by the authors, also 



**Figure 6.** Schematic structures of a) conventional Si-based SC, b) BSF Si-based SC, c) BSR Si-based SC, d) BSFR Si-based SC, and e) PERL Si-based SC. 

**2200125 (12 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 7.** Remaining factors of _I_ SC, _V_ OC, and _P_ max of BSF Si-based SCs, irradiated with a) 1 MeV electrons and b) 10 MeV protons at varying fluences. a) Reproduced with permission.<sup>[35]</sup> Copyright 1996, American Institute of Physics; (b) Reproduced with permission.<sup>[36]</sup> Copyright 1996, American Institute of Physics. c) Output power and d) associated remaining factor (under 1 MeV electron irradiation at varying fluence) of Si-based SCs using the conventional, BSF, BSR, and BSFR designs. e) PCE and f) relative output power of PERL and BSF Si-based SCs. Reproduced with permission.<sup>[34]</sup> Copyright 2020, Wiley. 

for BSF Si-based SCs irradiated with protons (10 MeV energy with fluences ranging between 10<sup>11</sup> and 2 × 10<sup>14</sup> particles cm<sup>−2</sup> ) as reported in Figure 7b.<sup>[36]</sup> The authors attribute such trend to three different mechanisms: the decrease of the minority-carriers lifetime (which explains the reduction of _I_ SC and _V_ OC in the lowfluence region), the broadening of the depletion layer (which is responsible for the anomalous increase of _I_ SC and decrease of _V_ OC), and the increase of the series resistance of the Si layer (responsible for the failure of the device at high fluences).<sup>[35,36]</sup> 

A recent work by Yamaguchi et al. showed that, although conventional Si-based devices show a lower BOL power 

(Figure 7c), they have the highest EOL power among several high performance designs, including BSF, BSR, and BSFR (Figure 7d).<sup>[34]</sup> The same behavior was observed for the case of the PERL architecture (characterized by a very high PCE, Figure 7e), that suffers from a higher degradation (under bombardment with electrons with 1 MeV energy) with respect to the BSF design (Figure 7f). All these results are related to increased surface recombination of the front and back interfaces, thus a proper engineering of these regions is fundamental for the optimization of the resulting performances and the use of all these architectures in space PV. 

**2200125 (13 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

**www.advancedsciencenews.com** 

#### **www.advenergymat.de** 



**Figure 8.** a) Schematic representation of the typical architecture used in CIGS-based SCs. Remaining factors associated to b) PCE, c) FF, d) _I_ SC, and e) _V_ OC in proton and electron irradiated CIGS-based SCs at different energies (as reported in the associated legends) and fluences. Reproduced with permission.<sup>[39]</sup> Copyright 2001, AIP publishing. 

## **5. Recent Developments and Future Perspectives of Materials and Device Architectures** 

### **5.1. CIGS-Based Solar Cells** 

Although MJSCs and Si-based SCs are at the forefront of PV devices for space applications, the need for reduced fabrication and maintenance costs, lightweight and flexibility have stimulated research toward other materials. Among these alternatives, CIGS-based SCs hold great promises in such field since they are lightweight (specific power ≈3 W g<sup>−1</sup> ),<sup>[18]</sup> are realized in thin-film architecture (even on flexible substrates such as polyimide or metal sheet)<sup>[144]</sup> and show an excellent stability against radiations. Such devices are heterostructured systems ( **Figure 8** a) comprising: soda-lime glass coated with a Mo layer (acting as electric contact), a p–n junction (formed by a CIGS absorbing layer and a CdS buffer layer), an intrinsic ZnO layer and finally an Al-doped ZnO layer (used as transparent conducting electrode).<sup>[145]</sup> 

There are several very interesting reports on the radiation resistance of CIGS-based SCs. In particular, Jasenek and Rau investigated the effects of high-energy electron and proton irradiation (with energies in the MeV range) at great fluences (up to 10<sup>18</sup> and 10<sup>14</sup> particles cm<sup>−2</sup> , respectively).<sup>[39]</sup> 

Figure 8b–e illustrates the remaining factor of the SC parameters. In particular, Figure 8b shows that fluences > 10<sup>17</sup> particles cm<sup>−2</sup> are needed to observe a PCE degradation of 10% 

for irradiation with electrons having 1 MeV energy, which is a remarkable result since both Si and GaAs experience the same losses for fluences at least one order of magnitude lower.<sup>[39]</sup> As expected, higher electron energies (3 MeV) cause more damage to the CIGS-based devices, while such SCs exhibit a great resistance to electrons with lower energy (0.5 MeV). The authors propose that the degradation mechanism involves the formation of recombination centers within the light harvester, since FF (Figure 8c) and _J_ SC (Figure 8d) are basically not affected by the electron bombardment experiments, while _V_ OC experiences losses (Figure 8e). Quite differently, irradiation with protons having an energy of 4 MeV results in the reduction of all the PV parameters. However, the critical fluence (i.e., the value for which the remaining factor of PCE is 0.6) is ≈10<sup>14</sup> particles cm<sup>−2</sup> , which is still one order of magnitude higher with respect to that of Si and GaAs.<sup>[39]</sup> 

With the aim to analyze proton-induced degradation, Kawakita et al. investigated the mechanisms leading to the recovery of such losses.<sup>[40]</sup> In particular, the authors irradiated, with protons having an energy of 3 MeV and fluence of 10<sup>14</sup> particles cm<sup>−2</sup> , CIGS-based SCs kept at 345 and at 400 K and addressed the consequences on the _I_ SC of devices after the bombardment test. Interestingly, _I_ SC decreases with increasing fluence following a trend which depends on the temperature of the device (higher temperatures lead to lower current losses). Furthermore, when the irradiation is terminated, the _I_ SC recovers its value with a temperature-dependent rate (which is 

**2200125 (14 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

#### **www.advancedsciencenews.com** 

slower for lower temperature). Indeed, further analysis reveals that a process is activated at a temperature of ≈380 K that leads to the recovery of the _I_ SC value measured prior to the bombardment tests.<sup>[40]</sup> Similar results were obtained for irradiation with protons having 0.5 and 10 MeV energy. 

A remarkable work by Kawakita et al. reported for the first time the performances of CIGS-based SCs launched in orbit on board of the MDS-1 satellite.<sup>[41]</sup> Interestingly, such spacecraft was placed in an orbit passing through both Van Allen belts, thus in a very hostile and radiation-rich environment. 

The trends of the remaining factors associated to _I_ SC and _V_ OC as functions of the mission time show the huge radiation tolerance of CIGS-based SCs (no losses were observed by the authors for more than one-year operation). With the aim to understand the mechanisms behind such behavior, the authors performed also on-ground radiation experiments. As low degradation had been already reported for electron bombardment,<sup>[39]</sup> Kawakita et al. focused on the role of protons to the deterioration of these devices, comparing the results obtained with and without the effects due to thermal-recovery.<sup>[41]</sup> According to their simulations, after one year, _I_ SC and _V_ OC losses would be 5% and 15%, respectively, if thermal-recovery is not considered. Conversely, when such effect is considered no loss is observed, as reported by the experimental results. 

All these results point toward the high radiation stability of CIGS-based SCs, thus shielding strategies can be overcome by the intrinsic resistance of this material to bombardment by electrons and protons. As such, this technology represents a very promising candidate for the realization of new PV solutions for space applications, with decreased weight, launching and maintenance costs. 

### **5.2. Perovskite Solar Cells** 

Recently, a class of materials called metal halide perovskites (MHPs) has emerged as an outstanding light harvester for the fabrication of PV devices that recently achieved lab-scale PCE exceeding 25%.<sup>[22]</sup> This is due to the remarkable optoelectronic properties of such materials such as the high and panchromatic absorption coefficient (>10<sup>5</sup> cm<sup>−1</sup> in the visible region),<sup>[49,66]</sup> that allows the realization of thin-film PSCs (with an absorbing layer of ≈0.3–0.5 µm).<sup>[49]</sup> As a consequence, a complete device (including the substrate) can reach a specific power of 23 W g<sup>−1</sup> (allowing the reduction of space launch costs).<sup>[18]</sup> Moreover, PSCs can be prepared through low-fabrication costs from solution-processing techniques, making them cheaper compared to other PV technologies<sup>[29,30,146]</sup> and can be grown on flexible substrates.<sup>[147]</sup> In addition, low energy payback time (0.35 years) and greenhouse gas emission (10.7 g CO2-eq kWh<sup>−1</sup> ) values of the PSCs, compared to 1.52 years and 24.6 g CO2-eq kWh<sup>−1</sup> for the Si benchmark, make them as a promising sustainable alternative for all future PV-market scenarios.<sup>[148,149]</sup> 

The architecture of a PSC consists of a transparent conductive electrode (TCE, such as fluorine-doped tin oxide (FTO) or indium tin oxide (ITO)) deposited on top of a glass substrate, a perovskite absorbing layer sandwiched between an electron transporting layer and a hole transporting layer and a metal contact.<sup>[29,30,150]</sup> According to the order of deposition of the 

#### **www.advenergymat.de** 

charge selective layers, there are two different configurations: planar or mesoscopic regular PSC n–i–p and planar inverted p–i–n ( **Figure 9** a).<sup>[151,152]</sup> 

Owing to the crystalline-liquid characteristics,<sup>[153–155]</sup> MHPs manifest outstanding defect tolerant and self-healing properties that permit MHPs to sustain high doses of radiation<sup>[156]</sup> and consequently well suited or space applications. Several tests investigated the effects of _γ_ -rays,<sup>[31,157,158]</sup> electrons,<sup>[33,159–161]</sup> and protons<sup>[43,159,161,162]</sup> on the performance of PSCs. The results of these studies suggest that PSCs withstand extreme radiation levels making MHPs promising materials for space devices. In particular, exceptional results about the stability of PSCs under high-dose of _γ_ -ray radiation (reaching accumulated doses up to 23 000 Gy) were obtained by Yang et al.<sup>[31]</sup> who performed a study on a p–i–n planar structure based on a triple cation MHP (Cs0.05MA0.14FA0.81PbBr0.45I2.55). Comparison of the _J_ – _V_ curves of the PSC before and after irradiation test, Figure 9b shows a decrease of all PV parameters (in particular, PCE lowers from 18.80% to 14.95%). While _V_ OC remained almost unchanged, _J_ SC exhibited a significant decrease. This behavior is ascribed to the darkening of the glass substrate (i.e., the loss of optical transparency due to the formation of color centers)<sup>[163,164]</sup> after _γ_ -ray irradiation. This effect is confirmed by the transmittance spectra measurements performed on the ITO/glass substrate which confirm the reduction of the transmittance from ≈90% to ≈50–75% after the irradiation (in the spectral range between 300 and 800 nm, Figure 9c). When this loss is taken into account, the PCE value (after irradiation) becomes 18.20%, which is comparable with that of the pristine device, thus evidencing a negligible degradation of the light harvester. 

Other studies addressed the resistance of PSCs to electron radiation, as reported by Song et al.<sup>[33]</sup> (for 1 MeV energy under accumulated dose levels up to 10<sup>16</sup> particles cm<sup>−2</sup> ). Their devices (n–i–p PSC, with structure FTO/SnO2/C60-SAM/ FA0.7MA0.3PbI3/Spiro-OMeTAD/Au) exhibit a very high starting PCE of 20.6%. The _J_ – _V_ curves of reference and irradiated PSCs (measured in forward and reverse scans) are displayed in Figure 9d revealing a PCE reduction to 12.2% and 3.4% after exposure to electron beam with low (1.3 × 10<sup>13</sup> particles cm<sup>−2</sup> ) and high (1 × 10<sup>15</sup> particles cm<sup>−2</sup> ) fluences, respectively. Such performance degradation is mainly attributed to the decrease of _J_ SC while _V_ OC and FF exhibit small variations (Figure 9e–g). The authors attribute the _J_ SC losses to the aforementioned phenomenon of glass-darkening and to the partial decomposition of the MHP absorber layers. 

An example of proton radiation tolerance was reported by Lang et al.<sup>[43]</sup> who investigated a p–i–n PSC (glass/ITO/ PEDOT:PSS/MAPbI3/PCBM/BCP/Ag) under bombardment with a 68 MeV protons at accumulated doses up to 1.02 × 10<sup>13</sup> particles cm<sup>−2</sup> . As shown in Figure 9h, _V_ OC and FF remain constant while _J_ SC, and therefore PCE, decrease for doses >2 × 10<sup>11</sup> particles cm<sup>−2</sup> . Also, in this case, the loss of the PSC performance is attributed to both the degradation of the MHP absorber layer and to the formation of color centers within the glass substrate. When considering this phenomenon, a drop of _J_ SC of only 20% is observed at a proton dose of 10<sup>13</sup> particle cm<sup>−2</sup> (red rhomb in Figure 9h). Remarkably, MHPs show a higher proton radiation resilience compared to c-Si (blue line in Figure 9h), which begins to degrade at a proton dose at 

**2200125 (15 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 



**2200125 (16 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

#### **www.advancedsciencenews.com** 

#### **www.advenergymat.de** 

least three orders of magnitude lower (≈10<sup>10</sup> particles cm<sup>−2</sup> ). In a following study, the same group evaluated the resistance of another MHP light harvester (Cs0.05MA0.17FA0.83Pb(Br0.17I0.83)3) by using proton beams with energies of 20 and 68 MeV and accumulated doses up to 10<sup>12</sup> particles cm<sup>−2</sup> .<sup>[32]</sup> As observed in Figure 9i, such PSC shows negligible variations in all PV parameters during the irradiation tests. In particular, 20 MeV protons do not induce severe losses, while for 68 MeV more pronounced degradation is observed (Figure 9j). 

Finally, the possibility to tune the _E_ g of the MHPs by changing their chemical composition is a very interesting property for the fabrication of MJSCs. In this regard, Lang et al.<sup>[19]</sup> studied the radiation tolerance of MHP/CIGS- and MHP/Si-based SCs to protons with 68 MeV energy at a dose of 10<sup>12</sup> particles cm<sup>−2</sup> . Remarkably, the MHP/CIGS-based SC retains ≈85% of its initial PCE under AM0 illumination (Figure 9k) because of losses mainly due to the small reduction of _V_ OC, while the other PV parameters remain almost constant (as shown in the inset of Figure 9k). Quite differently, the MHP/Si-based device retains only 1% of the pristine PCE under AM0 conditions (Figure 9l), which has been associated to a drastic reduction of _J_ SC to only 2% of its initial value (inset of Figure 9l). Therefore, the results of this work demonstrate that MHP/CIGS-based MJSCs can become a promising technology for space applications because of the high resilience to radiation of both light harvesters, the resulting ultralightweight device (with a specific power of 2.1 W g<sup>−1</sup> , higher than those of commonly used GaInP/GaAs/Ge 3JSC of ≈0.8 W g<sup>−1</sup> )<sup>[19]</sup> and the possibility to realize truly flexible and bendable arrays.<sup>[19]</sup> 

In addition to the laboratory-based experiments, there are a few attempts to track the behavior of PSCs in real space environment to evaluate the full set of environmental parameters through space flight experiments.<sup>[165–167]</sup> As the first reported flight experiment, Cardinaletti et al.<sup>[165]</sup> tested MAPbI3-based PSCs with active area of 0.134 cm<sup>2</sup> in an altitude of 32 km by using a stratospheric balloon and the perovskite film survived during 3 h of stratospheric flight. In another stratospheric test activity, Zhu and coworkers<sup>[166]</sup> tested the mixed-cation PSCs with active an area of 1.00 cm<sup>2</sup> at an altitude of 35 km. The mixed-cation perovskite cell could retain >95% of its initial PCE during the 2 h test under AM0 illumination. Following these investigations, Reb et al.<sup>[167]</sup> also evaluated the performance of the PSCs against space environment through a rocket flight, which reached in 239 km altitude and the PV performance of the cell was tracked in a 6 min 

onboard measurement time. Despite the valuable results achieved through these few real space tests, these pioneer attempts are limited to low efficiency tested cells and relatively short flight time, which need to be addressed in the future activities. 

## **6. Perspectives on Future Materials for Space PV** 

Space represents a unique frontier for materials science and applications as the harsh conditions of the extraterrestrial environment require peculiar physicochemical properties. Among the potential candidates in this field, low-dimensional materials such as graphene and related 2D compounds represent a wide library of possibilities because of i) the tuneability of their properties through functionalization, doping, and other strategies, ii) their lightweight, iii) the possibility to realize flexible devices, and iv) the abundance, on Earth’s crust, of the raw materials typically used for their synthesis (C, W, Mo, S, etc.,). Indeed, space agencies are already testing and proposing some 2D materials-based technologies for space missions: ESA has tested a graphene-based solar sail, reaching an acceleration of 1 m s<sup>−2</sup> through illumination with a 1 W laser;<sup>[168]</sup> Orbex has designed a 3D printed two-stage rocket using carbon fibers and graphene composite materials;<sup>[169]</sup> SpaceX launched (1st April 2022), on board of the Transporter 4 mission, graphene-based devices with the aim to test (for the first time) the response of 2D materials-based technologies to the space environment.<sup>[170]</sup> 

As concerns PVs, 2D materials have been also implemented in some SCs for low TRL terrestrial applications.<sup>[46,150,171–174]</sup> Specifically, 2D materials such as graphene, transition metal dichalcogenides (TMDCs, e.g., MoS2, WS2, etc.) and transition metal carbides, nitrides, and carbonitrides (MXenes, for example Ti3C2T _x_ ) have been proposed as transparent conductive electrodes, counter electrodes, charge transport layers, and interlayers thanks to their outstanding optoelectronic, chemical, and mechanical properties.<sup>[172,173,175]</sup> This low TRL research effort is particularly developed in III-generation PV,<sup>[46]</sup> where the use of 2D materials represents a valid and effective strategy for interface tuning. State-of-art PSCs are nowadays fabricated by using a 2D perovskite layer on top of a bulk (3D) perovskite absorber.<sup>[176]</sup> Such 3D/2D heterostructures strategy is not limited to PSCs, in fact an NREL team has recently demonstrated that this is a general concept that can be efficiently considered for several thin film PV such as CdTe and CIGS.<sup>[177]</sup> 

**Figure 9.** a) Schematic illustration of planar regular n–i–p and planar inverted p–i–n perovskite solar cells. b) Comparison of the _J_ – _V_ curves of a p–i–n PSCs before and after irradiation tests with _γ_ -ray at doses up to 23 000 Gy. c) Transmittance spectra of ITO/glass before and after _γ_ -ray irradiation. Δ _T_ represents the loss in transmittance due to irradiation. Reproduced with permission.<sup>[31]</sup> Copyright 2018, Wiley. d) _J_ – _V_ curves of PSCs under reference (red lines) and irradiation with 1 MeV electrons at fluences of 1.3 × 10<sup>13</sup> particles cm<sup>−2</sup> (blue lines) and 1 × 10<sup>15</sup> particles cm<sup>−2</sup> (green lines). Variation of PV parameters: e) _J_ SC, f) _V_ OC, and g) FF for devices under control and low and high e-beam irradiation conditions. Adapted with permission.<sup>[33]</sup> Copyright 2019, American Chemical Society. h) Variation of the normalized PV parameters as a function of the accumulated proton dose: _J_ SC (red dots), _V_ OC (blue diamonds), FF (black triangles), and PCE (open purple dots, referred as _η_ ) for PSCs. The red rhomb represents the PCE achieved when losses due to the glass/ITO substrate are taken into account. The blue line is the _J_ SC of a reference Si photodiode. Reproduced with permission.<sup>[43]</sup> Copyright 2016, Wiley. i) Normalized variation (with respect to measurements conducted under no proton irradiation) of the PV parameters _J_ SC, _V_ OC, FF, and PCE ( _η_ in the figure) for a PSC under irradiation with protons with energies of 20 (blue line) and 68 (red line) MeV functions of the accumulated proton dose. j) Comparisons of the PV parameters of PSCs before and after irradiation with protons with energies of 20 (blue line) and 68 (red line) MeV and accumulated dose of 10<sup>12</sup> particles cm<sup>−2</sup> . Reproduced with permission.<sup>[32]</sup> Copyright 2019, Royal Society of Chemistry. k–l) _J_ – _V_ curves of reference (solid lines) and 68 MeV proton irradiation at accumulated dose of 10<sup>12</sup> particles cm<sup>−2</sup> (dashed lines) for (g) an MHP/CIGS-based SC and (h) an MHP/Si-based SC. The insets show the remaining factors of the PV parameters ( _J_ SC, _V_ OC, FF, and PCE (indicated as _η_ )). Reproduced with permission.<sup>[19]</sup> Copyright 2020, Elsevier. 

**2200125 (17 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

**Table 6.** Summary of the resistance to radiation of MJSCs, Si-based SCs, CIGS-based SCs, and PSCs. 

|Solar cell technologies|Energy|Dose [particles cm<sup>−2</sup>]|PCEinitial[%]|PCEfinal[%]|Refs.|
|---|---|---|---|---|---|
|Multijunction||||||
|AlInGaP/AlInGaAs/InGaAs/Ge|1 MeV (electron)|10<sup>15</sup>|31.8|28.7|[14]|
|commercially available at AZUR SPACE||10<sup>16</sup>||20.1||
|InGaP/GaAs/Ge<br>commercially available at AZUR SPACE|1 MeV (electron)|10<sup>15</sup>|29.8|26.8|[14]|
|InGaP/GaAs/Ge|1 MeV (electron)|10<sup>16</sup>|32.2|23.1|[15]|
|commercially available at SPECTROLAB||||||
|InGaP/GaAs/Ge<br>commercially available at SPECTROLAB|1 MeV (electron)|10<sup>16</sup>|30.7|21.5|[15]|
|InGaP/GaAs/Ge|1 MeV (electron)|10<sup>14</sup>|29|28.2|[17]|
|commercially available at CESI||10<sup>15</sup>||24.4||
||1 MeV (proton)|10<sup>11</sup>||25.9||
|InGaP/GaAs/Ge|1 MeV (electron)|10<sup>14</sup>|28|26.7|[17]|
|commercially available at CESI||10<sup>15</sup>||23.7||
||1 MeV (proton)|10<sup>11</sup>||24.2||
|Silicon||||||
|Si|1 MeV (electron)|10<sup>15</sup>|16.9|12.5|[14]|
|commercially available at AZUR SPACE||3×10<sup>15</sup>||10.8||
|Cu(In,Ga)Se2||||||
|CIGS|3 MeV (electron)|10<sup>18</sup>|15.5|3.1|[39]|
||4 MeV (proton)|10<sup>14</sup>||7.75||
|Perovskite||||||
|MA0.7FA0.3PbI3|1 MeV (electron)|10<sup>15</sup>|19.2|3.4|[33]|
|MAPbI3|68 MeV (proton)|10<sup>13</sup>|12.1|4.84|[184]|
|Cs0.05MA0.17FA0.83Pb(I0.83Br0.17)3|68 MeV (proton)|10<sup>12</sup>|18.8|17.86|[185]|
|CIGS//Cs0.05(MA0.17FA0.83)0.95Pb(I0.83Br0.17)3|68 MeV (proton)|2×10<sup>12</sup>|18.0|14.9|[19]|
|Si//Cs0.05(MA0.17FA0.83)0.95Pb(I0.83Br0.17)3|68 MeV (proton)|2×10<sup>12</sup>|21.1|0.18|[19]|



A strong effort has been devoted to the use of 2D materials as TCEs in particular graphene and MXenes. This effort has been motivated by the urgent request to find valid alternatives to indium (critical raw material) commonly used in the fabrication on indium tin oxide TCE. This development will not only impact photovoltaics but also other devices such as LEDs, where strong progresses have been made in the use of 2D materials-based TCE.<sup>[178]</sup> Moreover, the development of TCE at industrial level is now considered, and scalable production have been already demonstrated.<sup>[179]</sup> 

Concomitantly, 2D materials have been tested (on Earth) in space-relevant conditions as components of electronic devices such as transistors, sensors, etc. Surprisingly, despite the reduced thickness, 2D materials exhibit excellent resistance under bombardment with high energetic particles (including electrons, protons and _γ_ -rays). For example, Kim et al.<sup>[180]</sup> studied the changes of the _I_ – _V_ curves of a MoS2-based FET under 10 MeV proton irradiation. The authors observed that under a fluence of 10<sup>12</sup> particles cm<sup>−2</sup> , the electrical performance of the device remained unchanged, while for fluences as high as 10<sup>14</sup> particles cm<sup>−2</sup> a dramatic drop of the source–drain current is observed. Vogl et al.<sup>[181]</sup> investigated the electrical properties of MoS2 and WS2 FETs and of single photon sources based on hexagonal boron nitride subjected to the irradiation 

of _γ_ -rays, protons and electrons. The authors demonstrated that, after the irradiation with proton and electron doses of, respectively, 10<sup>12</sup> and 10<sup>16</sup> particles cm<sup>−2</sup> (which are equivalent to those accumulated after 10<sup>3</sup> years of exposure at 500 km altitude), the devices did not experience any significant changes in their performances (assuming an Al shield of 1.85 nm of thickness). Recently, Zhang et al.<sup>[182]</sup> studied the radiation resistance of single- and multilayer MoS2 FETs under another type of common irradiation source in space environment, i.e., He ions. By using 2 MeV He<sup>+</sup> irradiation it was found that singlelayer MoS2 devices showed significant degradation with fluence of 10<sup>11</sup> particles cm<sup>−2</sup> . In comparison, multilayer MoS2 FETs tolerated a fluence of an order of magnitude superior to that of single-layer FETs (about 3 × 10<sup>12</sup> particles cm<sup>−2</sup> ), corresponding to decades of operation and exposure in the space environment. Arnold et al.<sup>[183]</sup> demonstrated that a MoS2 thin layer has an excellent radiation resistance under 2 MeV proton irradiation with fluences ≈10<sup>16</sup> particles cm<sup>−2</sup> , corresponding to hundreds of years of exposure. These radiation tests indicate that devices based on 2D materials can withstand radiation fluences higher than those required in low earth orbits. Thus, since 2D materials show a high potential for both PV and radiation-resistant materials, we believe that 2D materials-based SCs will be a likely future technology for space applications. 

**2200125 (18 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 

## **7. Discussion and Conclusion** 

SCs are the most used option to provide electrical power for space missions that usually last several years. Currently, III–V multijunction SCs are the state of the art of PV devices for space applications because of the highest PCE and radiation resistance compared to the other PV technologies ( **Table 6** ). Despite these appealing features, such devices suffer from the drawbacks of complex and expensive fabrication processes. 

Today, following the privatization of space missions, there is a great demand for cheaper PV technologies. In particular, Si-based SCs are used for low power and short duration mission because of a good compromise between performances and production costs. Moreover, with the aim to reduce fabrication and maintenance costs while satisfying the requirements of lightweight and flexibility (thus paving the way to the manufacturing of flexible solar arrays), alternative PV technologies have been investigated. Actually, the focus of the academic and industrial research is on the cost reduction of SCs and, of course, solar arrays. A cost reduction has been already achieved with the introduction of the high-efficiency (PCE = 30%) SCs on rigid panel arrays. Attempts to further reduce the cost are in progress to use large area SCs obtained using 6 in. wafers. The current trend is toward flexible solar arrays with high power, mainly for telecommunication satellites, which can play a very important role in the development of big market sectors driven by megaconstellation programs and telecommunication satellites. Another important issue is the high radiation resistance required to the solar arrays. Before defining the new trend of the current market now it needs to develop the building block, this because any technological advance originates a cost impact. Thus, it could be useful to find a right compromise between the possible improvements of the technology and what can be commercially available. To this end was defined the European road map on short, mid, and long term development of novel solar cells cost effective.<sup>[87]</sup> For the years 2014/2015 the road map planned the optimization of triple-junction solar cells even on large area wafers manufacturing. The updated roadmap envisages the development of new multijunction solar cells with efficiency up to 32% within 2021 and further technological developments (i.e., lattice mismatched structures) with higher efficiencies even at expenses of a little higher cost, in mid and long term. 

Regarding the materials to be used for solar cells, an important aspect has to be pointed out, that is the need to comply with current regulation EU REACH (Registration, Evaluation, Authorisation and Restriction of Chemicals),<sup>[186]</sup> that identifies materials that can be used and materials subject to restrictions. Moreover, such European Regulation defines also the requirements to be achieved for developing competitive technologies. 

It is worth considering even on the solar cell market that is relatively small, in the order of less than 1 MW per year, while the cost of the industry infrastructure is very high. Thus, the development of competitive technologies for producing solar cells and solar arrays at the state-of-the art and beyond requires substantial funding. As for the solar arrays the market trends push in the direction of flexible arrays, which are a goal to be achieved with a great effort by industry and research community through appropriate R&D common program. 

## **Acknowledgements** 

R.V. and V.R. contributed equally to this work. R.V. acknowledges funding from Dottorati FSE XX X VI ciclo Unime, CIP 2014.IT.05.SFOP. 014/3/10.5/9.2.10/0002 CUP G47C20000190002. V.R. thanks funding from PRIN 2017 MULTI-e ID# 20179337R7. N.Y.N. acknowledges the Ministry of University and Research (MUR) for PON/FSE-REACT EU support, N.Y.N. and A.D.C. acknowledge support from European Union’s Horizon 2020 research and innovation programme under Grant Agreement No. 101006715 (VIPERLAB). R.V., G.B., and C.C. acknowledge financial support by the Ministry of Research and University in the framework of Close to the Earth – CLOSE (No. ARS01_00141) and New Satellite Generation Components – NSG (No. ARS01_01215) projects. 

Open Access Funding provided by Universita degli Studi di Messina within the CRUI-CARE Agreement. 

## **Conflict of Interest** 

The authors declare no conflict of interest. 

## **Keywords** 

photovoltaic technology architectures, radiation hardness, solar cells, space environment 

Received: January 13, 2022 Revised: May 9, 2022 Published online: June 22, 2022 

- [1] L. Greco, UCS Satellite Database, https://www.ucsusa.org/ resources/satellite-database (accessed: May 2022). 

- [2] A. Datas, A. Martí, _Sol. Energy Mater. Sol. Cells_ **2017** , _161_ , 285. 

- [3] R. Surampudi, J. Blosiu, P. Stella, J. Elliott, J. Castillo, T. Yi, J. Lyons, M. Piszczor, J. Mcnatt, C. Taylor, S. Liu, E. Plichta, P. M. Beauchamp, J. A. Cutts, _Strategic Mission and Advanced Concepts of NASA_ , NASA, Washington, DC **2017** . 

- [4] J. Bisquert, _The Physics of Solar Energy Conversion: Perovskites, Organics, and Photovoltaic Fundamentals_ , CRC Press, Boca Raton, FL **2020** . 

- [5] R. Hoheisel, D. Wilt, D. Scheiman, P. Jenkins, R. Walters, in _2014 IEEE 40th Photovoltaic Specialists Conf. (PVSC 2014)_ , Institute of Electrical and Electronics Engineers Inc, Piscataway, NJ **2014** , pp. 1811–1814. 

- [6] A. F. Hepp, J. S. McNatt, S. G. Bailey, R. P. Raffaelle, B. J. Landi, S.-S. Sun, C. E. Bonner, K. K. Banger, D. Rauh, _IEEE Aerosp. Electron. Syst. Mag._ **2008** , _23_ , 31. 

- [7] International Space Station, www.nasa.gov/mission_pages/station/ structure/elements/solar_arrays-about.html (accessed: May 2022). 

- [8] L. Summerer, K. Stephenson, _Proc. Inst. Mech. Eng., Part G_ **2011** , _225_ , 129. 

- [9] A. Boca, C. A. Macfarland, R. S. Kowalczyk, _AIAA Propuls. Energy Forum Expo._ **2019** , _2019_ , 3. 

- [10] D. E. Brownlee, P. Tsou, J. D. Anderson, M. S. Hanner, R. L. Newburn, Z. Sekanina, B. C. Clark, F. Hörz, M. E. Zolensky, J. Kissel, J. A. M. McDonnell, S. A. Sandford, A. J. Tuzzolino, _J. Geophys. Res._ **2003** , _108_ , 8111. 

- [11] P. M. Stella, S. Distefano, M. D. Rayman, A. Ulloa-Severino, _2009 34th IEEE Photovoltaic Specialists Conference (PVSC)_ , Philadelphia, PA, USA, June **2009** , pp. 001617–001621. 

- [12] _NASA Jet Propulsion Laboratory_ , California Institute of Technology, https://www.jpl.nasa.gov/news/press_kits/juno/pdf/juno-hires. pdf (accessed: June 2022). 

**2200125 (19 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

- [13] G. D’Accolti, G. Beltrame, L. Brambilla, R. Contini, E. Ferrando, L. Vallini, R. Mugnuolo, C. Signorini, A. Caon, H. Fiebrich, _European Space Agency (Special Publication on ESA SP)_ , Vol. _502_ , **2002** , p. 445. 

- [14] Azur Space Solar Power, www.azurspace.com/index.php/en/ (accessed: May 2022). 

- [15] Spectrolab, www.spectrolab.com/index.html (accessed: May 2022). [16] SolAero Technologies, Inc., https://solaerotech.com/ (accessed: May 2022). 

- [17] Space Solar Cells | CESI, https://www.cesi.it/space-solar-cells/ (accessed: May 2022). 

- [18] M. Kaltenbrunner, G. Adam, E. D. Głowacki, M. Drack, R. Schwödiauer, L. Leonat, D. H. Apaydin, H. Groiss, M. C. Scharber, M. S. White, N. S. Sariciftci, S. Bauer, _Nat. Mater._ **2015** , _14_ , 1032. 

- [19] F. Lang, M. Jošt, K. Frohna, E. Köhnen, A. Al-Ashouri, A. R. Bowman, T. Bertram, A. B. Morales-Vilches, D. Koushik, E. M. Tennyson, K. Galkowski, G. Landi, M. Creatore, B. Stannowski, C. A. Kaufmann, J. Bundesmann, J. Rappich, B. Rech, A. Denker, S. Albrecht, H. C. Neitzert, N. H. Nickel, S. D. Stranks, _Joule_ **2020** , _4_ , 1054. 

- [20] D. Cardwell, A. Kirk, C. Stender, A. Wibowo, F. Tuminello, M. Drees, R. Chan, M. Osowski, N. Pan, _2017 IEEE 44th Photovoltaic Specialists Conf._ , IEEE, Piscataway, NJ **2017** , pp. 3511–3513. 

- [21] J. Li, A. Aierken, Y. Liu, Y. Zhuang, X. Yang, J. H. Mo, R. K. Fan, Q. Y. Chen, S. Y. Zhang, Y. M. Huang, _Front. Phys._ **2021** , _8_ , 631925. 

- [22] National Renewable Energy Laboratory, Best research-cell efficiencies, www.nrel.gov/pv/cell-efficiency.html (accessed: May 2022). 

- [23] Starlink, https://www.starlink.com/ (accessed: May 2022). 

- [24] H. Afshari, B. K. Durant, C. R. Brown, K. Hossain, D. Poplavskyy, B. Rout, I. R. Sellers, _Sol. Energy Mater. Sol. Cells_ **2020** , _212_ , 110571. 

- [25] A. Jasenek, U. Rau, K. Weinert, H. W. Schock, J. H. Werner, _3rd World Conf. on Photovoltaic Energy Conversion, 2003 Proc._ , IEEE, Piscataway, NJ **2003** , pp. 593–598. 

- [26] K. Otte, L. Makhova, A. Braun, I. Konovalov, _Thin Solid Films_ **2006** , _511–512_ , 613. 

- [27] Y. Tu, J. Wu, G. Xu, X. Yang, R. Cai, Q. Gong, R. Zhu, W. Huang, _Adv. Mater._ **2021** , _33_ , 2006545. 

- [28] W. Xiao, J. Yang, S. Xiong, D. Li, Y. Li, J. Tang, C. Duan, Q. Bao, _Sol. RRL_ **2020** , _4_ , 2070032. 

- [29] M. Saliba, J. P. Correa-Baena, C. M. Wolff, M. Stolterfoht, N. Phung, S. Albrecht, D. Neher, A. Abate, _Chem. Mater._ **2018** , _30_ , 4193. 

- [30] M. Saliba, J. P. Correa-Baena, M. Grätzel, A. Hagfeldt, A. Abate, _Angew. Chem., Int. Ed._ **2018** , _57_ , 2554. 

- [31] S. Yang, Z. Xu, S. Xue, P. Kandlakunta, L. Cao, J. Huang, _Adv. Mater._ **2019** , _31_ , 1805547. 

- [32] F. Lang, M. Jošt, J. Bundesmann, A. Denker, S. Albrecht, G. Landi, H. C. Neitzert, J. Rappich, N. H. Nickel, _Energy Environ. Sci._ **2019** , _12_ , 1634. 

- [33] Z. Song, C. Li, C. Chen, J. McNatt, W. Yoon, D. Scheiman, P. P. Jenkins, R. J. Ellingson, M. J. Heben, Y. Yan, _J. Phys. Chem. C_ **2020** , _124_ , 1330. 

- [34] M. Yamaguchi, K. H. Lee, K. Araki, N. Kojima, Y. Okuno, M. Imaizumi, _Prog. Photovolt.: Res. Appl._ **2021** , _29_ , 98. 

- [35] M. Yamaguchi, S. J. Taylor, S. Matsuda, O. Kawasaki, _Appl. Phys. Lett._ **1996** , _68_ , 3141. 

- [36] M. Yamaguchi, S. J. Taylor, M. Yang, S. Matsuda, O. Kawasaki, T. Hisamatsu, _J. Appl. Phys._ **1996** , _80_ , 4916. 

- [37] P. R. Sharps, D. J. Aiken, M. A. Stan, C. H. Thang, N. Fatemi, _Prog. Photovolt.: Res. Appl._ **2002** , _10_ , 383. 

- [38] J. Li, A. Aierken, Y. Zhuang, P. Q. Xu, H. Q. Wu, Q. Y. Zhang, X. B. Wang, J. H. Mo, X. Yang, Q. Y. Chen, S. Y. Zhang, C. R. Yan, Y. Song, _Sol. Energy Mater. Sol. Cells_ **2021** , _224_ , 111022. 

- [39] A. Jasenek, U. Rau, _J. Appl. Phys._ **2001** , _90_ , 650. 

- [40] S. Kawakita, M. Imaizumi, M. Yamaguchi, K. Kushiya, T. Ohshima, H. Itoh, S. Matsuda, _Jpn. J. Appl. Phys._ **2002** , _41_ , L797. 

- [41] S. Kawakita, M. Imaizumi, T. Sumita, K. Kushiya, T. Ohshima, M. Yamaguchi, S. Matsuda, S. Yoda, T. Kamiya, _3rd World Conf. on Photovoltaic Energy Conversion, 2003 Proc._ , IEEE, Piscataway, NJ **2003** , pp. 693–696. 

- [42] J. Yang, Q. Bao, L. Shen, L. Ding, _Nano Energy_ **2020** , _76_ , 105019. 

- [43] F. Lang, N. H. Nickel, J. Bundesmann, S. Seidel, A. Denker, S. Albrecht, V. V. Brus, J. Rappich, B. Rech, G. Landi, H. C. Neitzert, _Adv. Mater._ **2016** , _28_ , 8726. 

- [44] C. Jiang, S. J. A. Moniz, A. Wang, T. Zhang, J. Tang, _Chem. Soc. Rev._ **2017** , _46_ , 4645. 

- [45] S. Kahmann, M. A. Loi, _J. Mater. Chem. C_ **2019** , _7_ , 2471. 

- [46] S. Bellani, A. Bartolotta, A. Agresti, G. Calogero, G. Grancini, A. Di Carlo, E. Kymakis, F. Bonaccorso, _Chem. Soc. Rev._ **2021** , _50_ , 11870. 

- [47] M. A. Green, A. Ho-Baillie, H. J. Snaith, _Nat. Photonics_ **2014** , _8_ , 506. 

- [48] M. Ledinsky, T. Schönfeldová, J. Holovský, E. Aydin, Z. Hájková, L. Landová, N. Neyková, A. Fejfar, S. De Wolf, _J. Phys. Chem. Lett._ **2019** , _10_ , 1368. 

- [49] T. M. Brenner, D. A. Egger, L. Kronik, G. Hodes, D. Cahen, _Nat. Rev. Mater._ **2016** , _1_ , 15007. 

- [50] S. Irvine, in _Handbook of Electronic and Photonic Materials_ (Eds: S. Kasap, P. Capper), Springer, Berlin **2017** , pp. 1097–1110. 

- [51] S. M. Sze, M.-K. Lee, _Semiconductor Devices: Physics and Technology_ , Wiley, New York **2012** . 

- [52] P. A. Iles, _Sol. Cells_ **1982** , _7_ , 79. 

- [53] S. De Wolf, J. Holovsky, S. J. Moon, P. Löper, B. Niesen, M. Ledinsky, F. J. Haug, J. H. Yum, C. Ballif, _J. Phys. Chem. Lett._ **2014** , _5_ , 1035. 

- [54] C. Gutsche, R. Niepelt, M. Gnauck, A. Lysov, W. Prost, C. Ronning, F. J. Tegude, _Nano Lett._ **2012** , _12_ , 1453. 

- [55] T. Yao, X. An, H. Han, J. Q. Chen, C. Li, _Adv. Energy Mater._ **2018** , _8_ , 1800210. 

- [56] G. Brown, V. Faifer, A. Pudov, S. Anikeev, E. Bykov, M. Contreras, J. Wu, _Appl. Phys. Lett._ **2010** , _96_ , 022104. 

- [57] T. Kirchartz, U. Rau, _J. Appl. Phys._ **2007** , _102_ , 104510. 

- [58] E. Belas, Š. Uxa, R. Grill, P. Hlídek, L. Šedivý, M. Bugár, _J. Appl. Phys._ **2014** , _116_ , 103521. 

- [59] L. Tarricone, N. Romeo, G. Sberveglieri, S. Mora, _Sol. Energy Mater._ **1982** , _7_ , 343. 

- [60] J. S. Cheong, A. Baharuddin, J. S. Ng, A. B. Krysa, J. P. R. David, _Sol. Energy Mater. Sol. Cells_ **2017** , _164_ , 28. 

- [61] F. J. Schultes, T. Christian, R. Jones-Albertus, E. Pickett, K. Alberi, B. Fluegel, T. Liu, P. Misra, A. Sukiasyan, H. Yuen, N. M. Haegel, _Appl. Phys. Lett._ **2013** , _103_ , 242106. 

- [62] N. M. Haegel, T. Christian, C. Scandrett, A. G. Norman, A. Mascarenhas, P. Misra, T. Liu, A. Sukiasyan, E. Pickett, H. Yuen, _Appl. Phys. Lett._ **2014** , _105_ , 202116. 

- [63] D. Benmoussa, M. Boukais, H. Benslimane, _J. Nano- Electron. Phys._ **2016** , _8_ , 01009. 

- [64] G. Xing, N. Mathews, S. Sun, S. S. Lim, Y. M. Lam, M. Grat<sup>�</sup> zel, S. Mhaisalkar, T. C. Sum, _Science_ **2013** , _342_ , 344. 

- [65] M. Fox, _Optical Properties of Solids_ , OUP, Oxford **2002** . 

- [66] L. M. Herz, _Annu. Rev. Phys. Chem._ **2016** , _67_ , 65. 

- [67] K. Jäger, O. Isabella, A. Smets, R. van Swaaij, M. Zeman, _Solar Energy: Fundamentals, Technology, and Systems_ , UIT Cambridge Ltd, Cambridge **2016** . 

- [68] _Unconventional Thin Film Photovoltaics_ (Eds: E. Da Como, F. De Angelis, H. Snaith, A. Walker), Royal Society of Chemistry, London **2016** . 

- [69] M. A. Parker, _Physics of Optoelectronics_ , CRC Press, Boca Raton, FL **2005** . 

- [70] W. Shockley, H. J. Queisser, _J. Appl. Phys._ **1961** , _32_ , 510. 

- [71] J. R. Woodyard, G. A. Landis, _Sol. Cells_ **1991** , _31_ , 297. 

- [72] R. Schmalensee, V. Bulovic, R. Armstrong, C. Batlle, P. Brown, J. Deutch, H. Jacoby, R. Jaffe, J. Jean, R. Miller, F. O'Sullivan, J. Parsons, J. I. Pérez-Arriaga, N. Seifkar, R. Stoner, C. Vergara, 

**2200125 (20 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

#### **www.advancedsciencenews.com** 

in _The Future of Solar Energy: An Interdisciplinary MIT Study_ , Massachusetts Institute of Technology **2015** , Ch. 2. 

- [73] National Renewable Energy Laboratory, Champion module efficiencies, www.nrel.gov/pv/module-efficiency.html (accessed: May 2022). 

- [74] J. P. Correa-Baena, M. Saliba, T. Buonassisi, M. Grätzel, A. Abate, W. Tress, A. Hagfeldt, _Science_ **2017** , _358_ , 739. 

- [75] S. Han, H. Zhang, R. Wang, Q. He, _Mater. Sci. Semicond. Process._ **2021** , _127_ , 105666. 

- [76] B. G. Krishna, G. S. Rathore, N. Shukla, S. Tiwari, _Hybrid Perovskite Compos. Mater._ **2021** , 375. 

- [77] T. Leijtens, K. Bush, R. Cheacharoen, R. Beal, A. Bowring, M. D. McGehee, _J. Mater. Chem. A_ **2017** , _5_ , 11483. 

- [78] J. A. Luceño-Sánchez, A. M. Díez-Pascual, R. P. Capilla, _Int. J. Mol. Sci._ **2019** , _20_ . 

- [79] _McEvoy’s Handbook of Photovoltaics_ (Ed: S. Kalogirou), Elsevier, Amsterdam **2018** . 

- [80] F. Haase, C. Hollemann, S. Schäfer, A. Merkle, M. Rienäcker, J. Krügener, R. Brendel, R. Peibst, _Sol. Energy Mater. Sol. Cells_ **2018** , _186_ , 184. 

- [81] K. Yoshikawa, H. Kawasaki, W. Yoshida, T. Irie, K. Konishi, K. Nakano, T. Uto, D. Adachi, M. Kanematsu, H. Uzu, K. Yamamoto, _Nat. Energy_ **2017** , _2_ , 17032. 

- [82] M. Nakamura, K. Yamaguchi, Y. Kimoto, Y. Yasaki, T. Kato, H. Sugimoto, _IEEE J. Photovoltaics_ **2019** , _9_ , 1863. 

- [83] R. Carron, S. Nishiwaki, T. Feurer, R. Hertwig, E. Avancini, J. Löckinger, S.-C. Yang, S. Buecheler, A. N. Tiwari, _Adv. Energy Mater._ **2019** , _9_ , 1900408. 

- [84] M. Jeong, I. W. Choi, E. M. Go, Y. Cho, M. Kim, B. Lee, S. Jeong, Y. Jo, H. W. Choi, J. Lee, _Science_ **2020** , _369_ , 1615. 

- [85] C. Long, K. Huang, J. Chang, C. Zuo, Y. Gao, X. Luo, B. Liu, H. Xie, Z. Chen, J. He, H. Huang, Y. Gao, L. Ding, J. Yang, _Small_ **2021** , _17_ , 2102368. 

- [86] K. Sasaki, T. Agui, K. Nakaido, N. Takahashi, R. Onitsuka, T. Takamoto, _AIP Conf. Proc._ **2013** , _1556_ , 22. 

- [87] ESA/IPC/THAG(2021)4, “Solar Generators and Solar Cells”, issue 5. 

- [88] K. L. Bedingfield, R. D. Leach, M. B. Alexander, _National Aeronautics and Space Administration_ , Marshall Space Flight Center, Huntsville, AL, USA **1996** , p. 1390. 

- [89] J. L. Barth, _European Space Agency (Special Publication on ESA SP)_ , Springer, Dordrecht, The Netherlands **2003** , pp. 7–29. 

- [90] G. Bonin, N. Orr, R. E. Zee, J. Cain, _24th Annual Conf. on Small Satellites_ , Vol. _9012_ , AIAA, Logan, UT, USA **2010** . 

- [91] V. L. Pisacane, _The Space Environment and Its Effects on Space Systems_ , American Institute of Aeronautics And Astronautics, Reston, VA **2008** . 

- [92] Y. Lu, Q. Shao, H. Yue, F. Yang, _IEEE Access_ **2019** , _7_ , 93473. 

- [93] K. Torkar, R. Nakamura, M. Tajmar, C. Scharlemann, H. Jeszenszky, G. Laky, G. Fremuth, C. P. Escoubet, K. Svenes, _Space Sci. Rev._ **2016** , _199_ , 515. 

- [94] W. Riedler, K. Torkar, F. Rüdenauer, M. Fehringer, A. Pedersen, R. Schmidt, R. J. L. Grard, H. Arends, B. T. Narheim, J. Troim, R. Torbert, R. C. Olsen, E. Whipple, R. Goldstein, N. Valavanoglou, H. Zhao, _Space Sci. Rev._ **1997** , _79_ , 271. 

- [95] D. J. Wrbanek, Y. S. Wrbanek, _Space Radiation and Impact on Instrumentation Technologies_ , **2020** . 

- [96] G. F. Knoll, _Radiation Detection and Measurement_ , Wiley, Hoboken, New Jersey, USA **2010** . 

- [97] J. R. Tesmer, M. Nastasi, Handbook of Modern Ion Beam Analysis, Materials Research Society, Pittsburgh, PA **1995** . 

- [98] D. Mottl, R. Nymmik, _Adv. Space Res._ **2003** , _32_ , 2349. 

- [99] R. Schwenn, in _Encyclopedia of Astronomy & Astrophysics_ (Ed: P. Murdin), Boca Raton, FL, USA, Ch. Solar Wind: Global Properties **2000** , p. 2301. 

- [100] E. J. Daly, G. Drolshagen, A. Hilgers, H. D. R. Evans, Space environment analysis: Experience and trends, in Proceedings of the ESA 1996 Symposium on Environment Modelling for SpaceBased Applications, ESA SP-392, (Eds: W. Burke, T.-D. Guyenne), 

#### **www.advenergymat.de** 

   - Eur. Space Res. and Technol. Center, Noordwijk, Netherlands **1996** , pp. 15–22. 

- [101] T. W. Armstrong, B. L. Colborn, _Radiat. Meas._ **2001** , _33_ , 229. 

- [102] T. A. Schneiderl, J. A. Vaughnl, K. H. WrightJr., B. S. Phillips, _IEEE 42nd Photovoltaic Specialists Conf._ , IEEE, Piscataway, NJ **2015** , pp. 1–6. 

- [103] A. A. Phoenix, E. Wilson, _J. Therm. Sci. Eng. Appl._ **2018** , _10_ , 051020. 

- [104] B. A. Banks, S. K. Miller, K. K. De Groh, _Collection of Technical Papers – 2nd Int. Energy Conversion Engineering Conf._ , Vol. _2_ , **2004** , p. 978. 

- [105] E. Miyazaki, M. Tagawa, K. Yokota, R. Yokota, Y. Kimoto, J. Ishizawa, _Acta Astronaut._ **2010** , _66_ , 922. 

- [106] B. A. Banks, M. J. Mirtich, S. K. Rutledge, D. M. Swec, H. K. Nahra, _AlAA 23rd Aerospace Science Meet. 1985_ , **1985** , p. 420. 

- [107] C. R. Phipps, K. L. Baker, S. B. Libby, D. A. Liedahl, S. S. Olivier, L. D. Pleasance, A. Rubenchik, J. E. Trebes, E. V. George, B. Marcovici, J. P. Reilly, M. T. Valley, _Adv. Space Res._ **2012** , _49_ , 1283. 

- [108] C. P. Mark, S. Kamath, _Space Policy_ **2019** , _47_ , 194. 

- [109] B. Hoang, S. White, B. Spence, S. Kiefer, _2016 IEEE Aerospace Conf._ , IEEE, Piscataway, NJ **2016** , pp. 1–12. 

- [110] About the Space Station Solar Arrays | NASA, https://www.nasa. gov/mission_pages/station/structure/elements/solar_arraysabout.html (accessed: May 2022). 

- [111] New Solar Arrays to Power NASA’s International Space Station Research | NASA, https://www.nasa.gov/feature/new-solar-arraysto-power-nasa-s-international-space-station-research (accessed: May 2022). 

- [112] H. Jones, _48th Int. Conf. on Environmental Systems_ , Albuquerque, New Mexico **2018** . 

- [113] Aerospace Security, https://aerospace.csis.org/data/space-launchto-low-earth-orbit-how-much-does-it-cost/ (accessed: May 2022). 

- [114] S. G. Bailey, R. Raffaelle, K. Emery, _Prog. Photovolt.: Res. Appl._ **2002** , _10_ , 399. 

- [115] D. H. Walker, _Results of the Solar Cell Experiments on the NTS-2 Satellite After 223 Days in Orbit_ , **1978** . 

- [116] M. R. Brown, L. J. Goldhammer, G. S. Goodelle, C. U. Lortz, J. N. Perron, J. S. Powe, J. A. Schwartz, B. T. Cavicchi, M. S. Gillanders, D. D. Krut, _Conf. Record of the IEEE Photovoltaic Specialists Conf._ , IEEE, Piscataway, NJ **1997** , pp. 805–810. 

- [117] S. P. Philipps, A. W. Bett, _Adv. Opt. Technol._ **2014** , _3_ , 469. 

- [118] S. Ku, R. R. King, K. M. Edmondson, D. J. Friedman, N. H. Karam, _Conf. on the Record of the Twenty-Ninth IEEE Photovoltaic Specialists_ , IEEE, Piscataway, NJ **2002** , pp. 1006–1009. 

- [119] V. Polojärvi, A. Aho, A. Tukiainen, M. Raappana, T. Aho, A. Schramm, M. Guina, _Sol. Energy Mater. Sol. Cells_ **2016** , _149_ , 213. 

- [120] V. Sabnis, H. Yuen, M. Wiemer, _AIP Conf. Proc._ **2012** , _1477_ , 14. 

- [121] D. J. Friedman, S. R. Kurtz, _Prog. Photovolt.: Res. Appl._ **2002** , _10_ , 331. 

- [122] K. Volz, D. Lackner, I. Németh, B. Kunert, W. Stolz, C. Baur, F. Dimroth, A. W. Bett, _J. Cryst. Growth_ **2008** , _310_ , 2222. 

- [123] J. E. Ruiz, D. Lackner, P. L. Souza, F. Dimroth, J. Ohlmann, _J. Cryst. Growth_ **2021** , _557_ , 125998. 

- [124] A. Aho, V. M. Korpijärvi, A. Tukiainen, J. Puustinen, M. Guina, _J. Appl. Phys._ **2014** , _116_ , 213101. 

- [125] A. J. Ptak, S. Kurtz, S. W. Johnston, D. J. Friedman, J. F. Geisz, J. M. Olson, W. E. Mcmahon, A. E. Kibbler, C. Kramer, M. Young, S.-H. Wei, S. B. Zhang, A. Janotti, P. Carrier, R. S. Crandall, B. M. Keyes, P. Dippo, A. G. Norman, W. K. Metzger, R. K. Ahrenkiel, R. C. Reedy, L. Gedvilas, B. To, M. H. Weber, K. G. Lynn, S. Kurtz, _National Center for Photovoltaics Solar Progress Review Meet._ , **2003** , pp. 1–4. 

- [126] N. Miller, P. Patel, C. Struempel, _AIP Conf. Proc._ **2014** , _1616_ , 50. 

- [127] A. B. Cornfeld, D. Aiken, B. Cho, A. V. Ley, P. Sharps, M. Stan, T. Varghese, _35th IEEE Photovoltaic Specialists Conf._ , IEEE, Piscataway, NJ **2010** , pp. 105–109. 

- [128] D. Lackner, O. Höhn, A. W. Walker, M. Niemeyer, P. Beutel, G. Siefer, M. Schachtner, V. Klinger, E. Oliva, K. Hillerich, 

- © 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**2200125 (21 of 24)** 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

**www.advenergymat.de** 

#### **www.advancedsciencenews.com** 

   - T. Kubera, W. Guter, A. W. Bett, F. Dimroth, _E3S Web Conf._ **2017** , _16_ , 03009. 

- [129] S. P. Philipps, F. Dimroth, A. W. Bett, _High-Efficiency III–V Multijunction Solar Cells_ , Elsevier Ltd, Amsterdam **2018** . 

- [130] N. H. Karam, C. M. Fetzer, X. Liu, M. A. Steiner, K. L. Schulte, in Metalorganic Vapor Phase Epitaxy (MOVPE): Growth, Materials Properties, and Applications (Eds: S. Irvine, P. Capper), John Wiley and Sons Ltd, Hoboken, New Jersey, US **2019** , Ch. 5. 

- [131] C. T. Pan, P. J. Cheng, M. F. Chen, C. K. Yen, _Microelectron. Reliab._ **2005** , _45_ , 657. 

- [132] S. J. Cunningham, M. Kupnik, _MEMS Materials and Processes Handbook_ (Eds: R. Ghodssi, P. Lin), Springer, Berlin **2010** , Ch. 11. 

- [133] U. Gösele, Q.-Y. Tong, _Annual Review of Materials Science_ **1998** , _28_ , 215. 

- [134] U. Gösele, Y. Bluhm, G. Kästner, P. Kopperschmidt, G. Kräuter, R. Scholz, A. Schumacher, S. Senz, Q.-Y. Tong, L.-J. Huang, Y.-L. Chao, T. H. Lee, _J. Vac. Sci. Technol., A_ **1999** , _17_ , 1145. 

- [135] S. Essig, J. Benick, M. Schachtner, A. Wekkeli, M. Hermle, F. Dimroth, _IEEE J. Photovoltaics_ **2015** , _5_ , 977. 

- [136] W. Rong, L. Yunhong, S. Xufang, _Nucl. Instrum. Methods Phys. Res., Sect. B_ **2008** , _266_ , 745. 

- [137] Y. Zhang, Y. Wu, H. Zhao, C. Sun, J. Xiao, H. Geng, J. Xue, J. Lu, Y. Wang, _Sol. Energy Mater. Sol. Cells_ **2016** , _157_ , 861. 

- [138] A. Aierken, L. Fang, M. Heini, Q. M. Zhang, Z. H. Li, X. F. Zhao, M. Sailai, H. T. Liu, Q. Guo, W. Gao, H. Gao, Q. Sun, _Sol. Energy Mater. Sol. Cells_ **2018** , _185_ , 36. 

- [139] J. J. Li, S. H. Lim, C. R. Allen, D. Ding, Y. H. Zhang, _IEEE J. Photovoltaics_ **2011** , _1_ , 225. 

- [140] S. H. Lim, J. J. Li, E. H. Steenbergen, Y. H. Zhang, _Prog. Photovolt.: Res. Appl._ **2013** , _21_ , 344. 

- [141] A. Rehman, S. H. Lee, S. H. Lee, _J. Korean Phys. Soc._ **2016** , _68_ , 593. 

- [142] F. Treble, _Renewable Energy_ **1998** , _15_ , 473. 

- [143] T. Hisamatsu, O. Kawasaki, S. Matsuda, T. Nakao, Y. Wakow, _Sol. Energy Mater. Sol. Cells_ **1998** , _50_ , 331. 

- [144] J. Ramanujam, D. M. Bishop, T. K. Todorov, O. Gunawan, J. Rath, R. Nekovei, E. Artegiani, A. Romeo, _Prog. Mater. Sci._ **2020** , _110_ , 100619. 

- [145] J. Ramanujam, U. P. Singh, _Energy Environ. Sci._ **2017** , _10_ , 1306. 

- [146] N. Yaghoobi Nia, F. Giordano, M. Zendehdel, L. Cinà, A. L. Palma, P. G. Medaglia, S. M. Zakeeruddin, M. Grätzel, A. Di Carlo, _Nano Energy_ **2020** , _69_ , 104441. 

- [147] P. Ru, E. Bi, Y. Zhang, Y. Wang, W. Kong, Y. Sha, W. Tang, P. Zhang, Y. Wu, W. Chen, _Adv. Energy Mater._ **2020** , _10_ , 1903487. 

- [148] M. Zendehdel, N. Yaghoobi Nia, M. Yaghoubinia, _Reliability and Ecological Aspects of Photovoltaic Modules_ , IntechOpen, London, UK **2020** . 

- [149] X. Tian, S. D. Stranks, F. You, _Sci. Adv._ **2020** , _6_ , eabb0055. 

- [150] A. S. R. Bati, M. Batmunkh, J. G. Shapter, _Adv. Energy Mater._ **2020** , _10_ , 1902253. 

- [151] K. Rakstys, C. Igci, M. Khaja Nazeeruddin, _Chem. Sci._ **2019** , _10_ , 6748. 

- [152] N. Yaghoobi Nia, D. Saranin, A. L. Palma, A. Di Carlo, _Solar Cells and Light Management: Materials, Strategies and Sustainability_ , Elsevier, Amsterdam, Netherlands **2020** , pp. 163–228. 

- [153] H. Zhu, K. Miyata, Y. Fu, J. Wang, P. P. Joshi, D. Niesner, K. W. Williams, S. Jin, X. Y. Zhu, _Science_ **2016** , _353_ , 1409. 

- [154] H. Seiler, S. Palato, C. Sonnichsen, H. Baker, E. Socie, D. P. Strandell, P. Kambhampati, _Nat. Commun._ **2019** , _10_ , 4962. 

- [155] K. Miyata, T. L. Atallah, X. Y. Zhu, _Sci. Adv._ **2017** , _3_ , e1701469. 

- [156] H. Wei, J. Huang, _Nat. Commun._ **2019** , _10_ , 1066. 

- [157] A. G. Boldyreva, A. F. Akbulatov, S. A. Tsarev, S. Y. Luchkin, I. S. Zhidkov, E. Z. Kurmaev, K. J. Stevenson, V. G. Petrov, P. A. Troshin, _J. Phys. Chem. Lett._ **2019** , _10_ , 813. 

- [158] K. Yang, K. Huang, X. Li, S. Zheng, P. Hou, J. Wang, H. Guo, H. Song, B. Li, H. Li, B. Liu, X. Zhong, J. Yang, _Org. Electron._ **2019** , _71_ , 79. 

- [159] J.-S. Huang, M. D. Kelzenberg, P. Espinet-González, C. Mann, D. Walker, A. Naqavi, N. Vaidya, E. Warmann, H. A. Atwater, _2017 IEEE 44th Photovoltaic Specialists Conf. (PVSC)_ , IEEE, Piscataway, NJ **2017** , 1248. 

- [160] J. Barbé, D. Hughes, Z. Wei, A. Pockett, H. K. H. Lee, K. C. Heasman, M. J. Carnie, T. M. Watson, W. C. Tsoi, _Sol. RRL_ **2019** , _3_ , 1900219. 

- [161] Y. Miyazawa, M. Ikegami, H. W. Chen, T. Ohshima, M. Imaizumi, K. Hirose, T. Miyasaka, _iScience_ **2018** , _2_ , 148. 

- [162] S. Kanaya, G. M. Kim, M. Ikegami, T. Miyasaka, K. Suzuki, Y. Miyazawa, H. Toyota, K. Osonoe, T. Yamamoto, K. Hirose, _J. Phys. Chem. Lett._ **2019** , _10_ , 6990. 

- [163] M. F. Bartusiak, J. Becher, _Appl. Opt._ **1979** , _18_ , 3342. 

- [164] A. I. Gusarov, D. Doyle, A. Hermanne, F. Berghmans, M. Fruit, G. Ulbrich, M. Blondel, _Appl. Opt._ **2002** , _41_ , 678. 

- [165] I. Cardinaletti, T. Vangerven, S. Nagels, R. Cornelissen, D. Schreurs, J. Hruby, J. Vodnik, D. Devisscher, J. Kesters, J. D’Haen, A. Franquet, V. Spampinato, T. Conard, W. Maes, W. Deferme, J. V. Manca, _Sol. Energy Mater. Sol. Cells_ **2018** , _182_ , 121. 

- [166] Y. G. Tu, G. N. Xu, X. Y. Yang, Y. F. Zhang, Z. J. Li, R. Su, D. Y. Luo, W. Q. Yang, Y. Miao, R. Cai, L. H. Jiang, X. W. Du, Y. C. Yang, Q. S. Liu, Y. Gao, S. Zhao, W. Huang, Q. H. Gong, R. Zhu, _Sci. China: Phys., Mech. Astron._ **2019** , _62_ , 974221. 

- [167] L. K. Reb, M. Böhmer, B. Predeschly, S. Grott, C. L. Weindl, G. I. Ivandekic, R. Guo, C. Dreißigacker, R. Gernhäuser, A. Meyer, P. Müller-Buschbaum, _Joule_ **2020** , _4_ , 1880. 

- [168] Graphene sail in microgravity, https://www.esa.int/ESA_Multimedia/Images/2020/05/Graphene_sail_in_microgravity (accessed: May 2022). 

- [169] Orbex, https://orbex.space/launch-vehicle (accessed: May 2022). [170] Rocket launch 1st April: sending graphene into space for the first time, https://www.tudelft.nl/en/2022/tnw/rocket-launch-1st-aprilsending-graphene-into-space-for-the-first-time (accessed: May 2022). 

- [171] J. Zhang, J. Fan, B. Cheng, J. Yu, W. Ho, _Sol. RRL_ **2020** , _4_ , 2000502. 

- [172] P. You, G. Tang, F. Yan, _Mater. Today Energy_ **2019** , _11_ , 128. 

- [173] S. Das, D. Pandey, J. Thomas, T. Roy, _Adv. Mater._ **2019** , _31_ , 1802722. 

- [174] A. Di Carlo, A. Agresti, F. Brunetti, S. Pescetelli, _J. Phys. Energy_ **2020** , _2_ , 031003. 

- [175] M. Acik, S. B. Darling, _J. Mater. Chem. A_ **2016** , _4_ , 6185. 

- [176] Z. Li, B. Li, X. Wu, S. A. Sheppard, S. Zhang, D. Gao, N. J. Long, Z. Zhu, _Science_ **2022** , _376_ , 416. 

- [177] D. L. McGott, C. P. Muzzillo, C. L. Perkins, J. J. Berry, K. Zhu, J. N. Duenow, E. Colegrove, C. A. Wolden, M. O. Reese, _Joule_ **2021** , _5_ , 1057. 

- [178] H. Zhang, J. Mischke, W. Mertin, G. Bacher, _Materials_ **2022** , _15_ , 2203. 

- [179] P. Mustonen, D. M. A. Mackenzie, H. Lipsanen, _Front. Optoelectron._ **2020** , _13_ , 91. 

- [180] T.-Y. Kim, K. Cho, W. Park, J. Park, Y. Song, S. Hong, W.-K. Hong, T. Lee, _ACS Nano_ **2014** , _8_ , 2774. 

- [181] T. Vogl, K. Sripathy, A. Sharma, P. Reddy, J. Sullivan, J. R. Machacek, L. Zhang, F. Karouta, B. C. Buchler, M. W. Doherty, Y. Lu, P. K. Lam, _Nat. Commun._ **2019** , _10_ , 1202. 

- [182] Y. Zhang, X. Chen, H. Wang, J. Dai, J. Xue, X. Guo, _J. Phys. Chem. C_ **2021** , _125_ , 2089. 

- [183] A. J. Arnold, T. Shi, I. Jovanovic, S. Das, _ACS Appl. Mater. Interfaces_ **2019** , _11_ , 8391. 

- [184] F. Lang, N. H. Nickel, J. Bundesmann, S. Seidel, A. Denker, S. Albrecht, V. V Brus, J. Rappich, B. Rech, G. Landi, _Adv. Mater._ **2016** , _28_ , 8726. 

- [185] F. Lang, M. Jošt, J. Bundesmann, A. Denker, S. Albrecht, G. Landi, H.-C. Neitzert, J. Rappich, N. H. Nickel, _Energy Environ. Sci._ **2019** , _12_ , 1634. 

- [186] REACH | Internal Market, Industry, Entrepreneurship and SMEs, https://ec.europa.eu/growth/sectors/chemicals/reach_en (accessed: May 2022). 

**2200125 (22 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 









**Rosaria Verduci** received her master degree in Condensed Matter Physics from University of Messina (Italy) in 2019. Currently, she is a Ph.D. student in Advanced Catalytic Processes for using Renewable Energy Sources (ACCESS) at the Department of Chemical, Biological, Pharmaceutical and Environmental Sciences at the University of Messina. Her main research interest focuses on the study of charge transfer processes at the semiconductor/electrolyte interface for solar fuels production. 

**Valentino Romano** is currently a postdoc at the Physics Department of Politecnico di Milano, working on ultrafast spectroscopies on materials for energy applications. He received his Ph.D. in Physics in 2019 at the University of Messina, working on perovskite solar cells and the production/processing of 2D materials (such as graphene and transition metal dichalcogenides) for the realization of supercapacitors, solar cells, and photoelectrodes (for the production of H2 from water splitting). His interests concern solar-powered green technologies, such as photovoltaic devices and systems for solar fuels synthesis, with particular emphasis on the fundamental physical processes behind their working mechanisms. 

**Giuseppe Brunetti** received the M.Sc. degree in Electronic Engineering (cum laude) and the Ph.D. degree in Information Engineering from Politecnico di Bari, Bari, Italy, in 2016 and 2020, respectively. His Ph.D. activity was focused on innovative photonic and optoelectronic devices for Space applications with European Space Agency (ESA) sponsorship in the framework of NPI project (367-2014). Since December 2020, he has been an Assistant Professor with Politecnico di Bari. His research interests include integrated optoelectronics and photonics devices and systems mainly in the context of biomedical and Space field. 

**Narges Yaghoobi Nia** received the Ph.D. in Electronics Engineering from University of Rome Tor Vergata; currently she is working as assistant professor. She was awarded in 2014 a MARIE CURIE Fellowship (Destiny FP7/2007–2013). Skilled in the field of emerging thin film PVs (perovskite solar module, tandem solar module, laser, polymer). She was a member of Espresso, ENEA, PRIN, Perseo project, and collaborator for ASI project. Now is contributing to the VIPERLAB project. In 2022 awarded Global MARIE CURIE Fellowship on Perovskite Photovoltaics for space with Prof. Schirone (Scuola di Ingegneria Aerospaziale Sapienza University) and Prof. Michael Graetzel (EPFL University). 

**2200125 (23 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 







**Aldo Di Carlo** is head of the Institute for Structure of the Matter of the Italian National Research Council (CNR-ISM) and full professor at the University of Rome “Tor Vergata” (Italy). He founded the Centre for Hybrid and Organic Solar Energy (CHOSE) that involves more than 40 researchers for the development and industrialization of the organic and hybrid organic/inorganic photovoltaic technologies. He is author/coauthor of more than 600 scientific publications on international journals, 13 patents, and several book chapters. 

**Giovanna D’Angelo** is full professor at the Physics Department of the University of Messina and Director of the Criogenics Center (Messina University). Her research mainly involves the study of the influence of vibrational and structural disorder on the physical properties of condensed and soft materials. More recently her activity is devoted to the study of fundamental physics processes influencing the charge transport in 2D materials, photovoltaic devises, and solar fuel systems. She has coauthored more than 150 publications and review articles. 

**Caterina Ciminelli** received the Laurea degree (1996) and the Ph.D. (2000) in electronic engineering from Politecnico di Bari, Italy. From 1999 to 2002, she did industrial research activity on optoelectronic components and subsystems with the R&D Division of Pirelli Optical Systems and Cisco Photonics, Italy, before joining Politecnico di Bari as an Assistant Professor of Electronics in 2002. From 2012 to 2021, she has been an associate professor. Since 2021, she has been a full professor with Politecnico di Bari where she is the scientist responsible for the Optoelectronics Laboratory. Her research interests include integrated optoelectronics and photonics. 

**2200125 (24 of 24)** 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2022** , _12_ , 2200125 

