# Time-reversal symmetry breaking superconductivity between twisted cuprate superconductors

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Science |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 189 |
| 作者 | S. Y. Frank Zhao, X. Cui, P. Volkov, H. Yoo, Sang-Min Lee, J. A. Gardener, A. Akey, Rebecca Engelke et al. |
| DOI | 10.1126/science.abl8371 |
| 源文件 | 054_Zhao_2023_Time-reversal-symmetry-breaking-superconductivit.pdf |

---
RESEARCH 



(27–31), often at the cost of considerable interfacial structural reconstruction (29, 31–33), suppressed TC (28–31), low critical current density JC at zero twist angle (27–29, 31), and pronounced anomalies in the resistance-temperature (R-T) curves (28, 29, 31). Most experiments observed no angular sensitivity (27–29), except two (30, 31) where the Josephson coupling angular dependence deviated strongly from conventional models of d-wave superconductivity (15). 



#### SUPERCONDUCTIVITY 

## Time-reversal symmetry breaking superconductivity between twisted cuprate superconductors 

S. Y. Frank Zhao<sup>1</sup> †, Xiaomeng Cui<sup>1</sup> †, Pavel A. Volkov<sup>1,2,3</sup> , Hyobin Yoo<sup>4</sup> , Sangmin Lee<sup>5</sup> , Jules A. Gardener<sup>6</sup> , Austin J. Akey<sup>6</sup> , Rebecca Engelke<sup>1</sup> , Yuval Ronen<sup>1</sup> , Ruidan Zhong<sup>7</sup> ‡, Genda Gu<sup>7</sup> , Stephan Plugge<sup>8</sup> , Tarun Tummuru<sup>8</sup> , Miyoung Kim<sup>5</sup> , Marcel Franz<sup>8</sup> , Jedediah H. Pixley<sup>2</sup> , Nicola Poccia<sup>1,9</sup> *, Philip Kim<sup>1</sup> * 

We overcome these challenges by developing a cryogenic, solvent-free vdW transfer technique in pure argon using a liquid nitrogen– cooled stage kept at <−90°C. We cleave an exfoliated BSCCO crystal into two copies between BiO planes, while thermally freezing out oxygen migration and other chemical processes at the surface (Fig. 1A and fig. S1). One of the crystals is quickly rotated to the targeted twist angle and reassembled with the other. A Josephson junction forms in the overlapping region upon contact (Fig. 1, B to D). Two sets of electrical contacts, both defined by stencil masks and evaporated on a −30°C cold stage (17), are prefabricated nearby before cleaving and placed on the top surface of the bottom crystal after reassembly. This contact geometry probes the twist junction while minimizing bulk crystal contributions (Fig. 1H, upper inset). Additional details are given in section S1 of (34). 

Twisted interfaces between stacked van der Waals (vdW) cuprate crystals present a platform for engineering superconducting order parameters by adjusting stacking angles. Using a cryogenic assembly technique, we construct twisted vdW Josephson junctions (JJs) at atomically sharp interfaces between Bi2Sr2CaCu2O8+x crystals, with quality approaching the limit set by intrinsic JJs. Near 45° twist angle, we observe fractional Shapiro steps and Fraunhofer patterns, consistent with the existence of two degenerate Josephson ground states related by time-reversal symmetry (TRS). By programming the JJ current bias sequence, we controllably break TRS to place the JJ into either of the two ground states, realizing reversible Josephson diodes without external magnetic fields. Our results o <mark>p</mark> en a <mark>p</mark> ath to en <mark>g</mark> ineerin <mark>g</mark> to <mark>p</mark> olo <mark>g</mark> ical devices at hi <mark>g</mark> her tem <mark>p</mark> eratures. 

eak van der Waals (vdW) bonding between neighboring atomic layers offers a distinct opportunity for engineering atomic interfaces with controlled W twist angles (1). Careful adjustment of the twist angle can create the spatial periodicity of a moiré superlattice (2) with narrow electronic bands and topological structure (3). Such twisted structures of various vdW materials, including graphene (3) and transition metal dichalcogenides (4), have been shown to host a plethora of emergent electronic states, including superconductivity (5), magnetism (6), Chern insulators (7), generalized electronic Wigner crystals (8), and correlated insulating states (9). 

BiO] bilayers (16), where the crystal can be mechanically cleaved into atomically flat crystals (17, 18) exhibiting high-temperature superconductivity even in the monolayer limit (19). 

# W 

Josephson junctions (JJs) formed at twist boundaries between cuprate crystals directly probe the pairing symmetry of Cooper pairs (20, 21). For example, using ab-planar tilt grain boundaries, measurements of angle-dependent critical currents (22), nonsinusoidal Josephson current-phase relations (23), and spontaneous supercurrents (21) established the cuprates as d-wave superconductors where the SOP changes sign when Cooper pair momentum is rotated by 90°. 

Cryogenic handling in argon is critical to maintaining pristine atomic interfaces without interfacial reconstruction and oxygen dopant changes. Figure 1D shows cross-sectional highangle annular dark field (HAADF) scanning transmission electron microscope (STEM) image of a q = 46° junction, simultaneously viewing both BSCCO crystals on two different zone axes. Notably, crystalline order is maintained at the interfacial layer with no change to the lattice structure (35) in the [001] direction between atomic layers (Fig. 1E) or along CuO2 planes (Fig. 1, F and G, and figs. S2 to S4). Detailed analysis of the interfacial BiO atomic layer places an upper bound of the twist-angle disorder below 0.2° [section S2 of (34)]. Similar interface quality is uniformly observed across large areas in several additional junctions (see figs. S2 to S4, for example). We compare 26 devices with q ranging from 0° to 180°, with TC > 79 K and average TC of 84 K (Fig. 1H, lower inset), demonstrating high oxygen dopant uniformity even at the junction. Neither TC nor the normal-state conductivity are systematically correlated with q (fig. S8). 

Similarly, interfacial Josephson coupling between twisted nodal d-wave superconductors is strongly modulated by the twist angle (15). Particularly, at a twist angle of q = 45°, direct Cooper pair tunneling is forbidden because of the complete mismatch between the dx2�y2 symmetric SOPs across the interface (15). Any remaining Josephson supercurrents are mediated through second-order processes (10–12, 24); the system is expected to support topological time-reversal symmetry (TRS)–breaking superconducting phases persisting up to the junction superconducting transition temperature TC (11, 12). Alternatively, TRS can be broken away from q = 45° by an applied current, which is predicted to induce a topological superconducting state (13). 

Atomically layered cuprate high-temperature superconductors also offer a platform for twistronics by enabling the engineering of the coupling between nodal superconducting order parameters (SOPs) across a twisted vdW interface (10–15). In Bi2Sr2CaCu2O8+x (BSCCO), superconducting CuO2 bilayers are Josephson-coupled through insulating [SrO- 

> 1Department of Physics, Harvard University, Cambridge, MA 02138, USA.<sup>2</sup> Center for Materials Theory, Department of Physics and Astronomy, Rutgers University, Piscataway, NJ 08854, USA.<sup>3</sup> Department of Physics, University of Connecticut, Storrs, CT 06269, USA.<sup>4</sup> Department of Physics, Institute of Emergent Materials, Sogang University, Seoul 04107, Korea.<sup>5</sup> Department of Materials Science and Engineering, Seoul National University, Seoul 08826, Korea. 

> 6Center for Nanoscale Systems, Harvard University, Cambridge, MA 02138, USA.<sup>7</sup> Department of Condensed Matter Physics and Materials Science, Brookhaven National Laboratory, Upton, NY 11973, USA.<sup>8</sup> Department of Physics and Astronomy and Stewart Blusson Quantum Matter Institute, University of British Columbia, Vancouver, BC V6T 1Z4, Canada.<sup>9</sup> Leibniz Institute for Solid State and Materials Research Dresden (IFW Dresden), 01069 Dresden, Germany. *Corresponding author. Email: n.poccia@ifw-dresden.de (N.P.); pkim@physics.harvard.edu (P.K.) †These authors contributed equally to this work. 

#### Building twisted BSCCO junctions 

At q = 0°, our devices exhibit electronic characteristics similar to the intrinsic Josephson junctions (IJJs) that naturally form between CuO2 layersinBSCCOsinglecrystals(16),demonstrating the high interfacial quality of our JJs. Figure 1I shows the current-voltage (I-V) characteristics (IVCs) measured with four terminals at temperature T = 9 K. In this low-temperature regime, the JJ exhibits a large hysteresis. As we 

The preservation of surface superconductivity of BSCCO crystals after vdW stacking remains an outstanding experimental challenge (17, 18). BSCCO crystals react with moisture (19, 25), and their oxygen dopants become mobile above 200 K (19, 26). BSCCO twist junctions previously required high-temperature oxygen annealing to restore interfacial superconductivity 

‡Present address: Tsung-Dao Lee Institute and School of Physics and Astronomy, Shanghai Jiao Tong University, Shanghai 200240, China. 

1 of 6 

Zhao et al., Science 382, 1422–1427 (2023) 22 December 2023 

RESEARCH | RESEARCH ARTICLE 





<!-- Start of picture text -->
A D  = 46° BiSr E<br>Cu<br>Ca<br>PDMS<br>Au<br>[010]<br>BSCCO<br>< -90 °C [110]<br>B C<br>66 nm [001] 2 nm<br>Integrated Intensity (arb)<br>0.02<br>F +1 UC G [010] FWHM<br>Interface<br>200 Interface-1 UC 0 k[110]  [110] 0.1<br>20  m 5  m BiO Layer k[010]  2 BiO Layer -0.1<br>0 0 1 2 3 4 5 0 10<br>k (nm -1 ) Dist. to Interface (UC)<br>H 1 I 20<br>Au 1 BSCCO  = 0°<br>T = 9 K<br>15<br>Junction 2<br>0.8<br>10<br>5<br>0.6<br>0<br>0.4 60 70 TC (K) 80 84 90 JC<br>6 -5 1<br>-10<br>0.2  = 2.8 K<br>-15<br>0<br>0 0 -20 0.6 J (kA / cm 2 ) 1.2<br>50 100 150 200 250 -1.5 -1 -0.5 0 0.5 1 1.5<br>Temperature (K) Current Density (kA / cm 2 )<br>0° Junction<br>Crystal 12<br>h (nm) [TEM Intens.] -1 (nm)    / k (%)k<br>R / R290K<br>Voltage (mV)<br>N<br>V (mV)<br><!-- End of picture text -->

highlighted in (E), showing atomically sharp structural transition at the interface. (G) BiO layer lattice periodicity variation, dk=<sup>�</sup> k, and peak full width at half maximum (FWHM) from (F), whose fluctuations are within 0.05%, with peak FWHM at fast Fourier transform resolution (0.014 nm<sup>−1</sup> ). (H) In-plane resistance in each bulk crystal versus resistance through the artificial junction between them, showing nearly identical junction TC. Lower inset shows TC distribution among all 26 JJs in the angle-dependence analysis. (I) I-V curve for a q = 0° junction in both sweep directions (arrows). Blue triangle highlights JC comparable to IJJs. Green triangles highlight inelastic scattering features seen at the same voltages in IJJs (16). Inset shows low-voltage region of IVC. 

Fig. 1. Twist Josephson junctions with intrinsic junction quality. (A) Schematic of key fabrication step: a single BSCCO crystal is cleaved using polydimethylsiloxane (PDMS) below −90°C. (B) Optical micrograph of a BSCCO twist junction. Dashes outline identical copies of the same crystal. Corresponding schematic in upper inset of (H). (C) Atomic force microscope topography showing atomically flat interface. Line trace shows topography along dotted line. (D) Cross-sectional annular dark field scanning TEM image of q = 46° junction, showing bulk-like crystalline order at the interface. Bright spots are columns of atoms identified in the upper right corner. (E) Integrated intensity of each layer. arb, arbitrary units. (F) Fourier transform of TEM line cuts at BiO layers 

increase current bias from a large negative value, the resistive quasiparticle branch of the IVC undergoes a series of jumps (green arrows) before retrapping into the superconducting state. Similar jumps were seen in IJJs [see section S5 of (34)] (16). Under positive bias current, V first becomes nonzero at IC1 (Fig. 1I, inset) before jumping about 20 mV to the resistive state at the critical current IC, marked by the blue triangle. The small voltage rise at IC1 was previously seen in some IJJs (16, 36, 37) and was attributed to self-field effects (16, 38), whereas the V jump at IC is comparable in magnitude to the corresponding jump in IJJs (16, 39, 40). Upon reversingthe bias current polarity (dashed line), the JJ’s I-V behavior is mirrored along 

2A shows the normalized dynamic resistance [dV/dI]/RN as a function of T and IRN at q = 0°, 31°, and 44.9° (similar data for 26 JJs studied are shown in fig. S11). Several features are apparent in these datasets. First, as the current sweeps from left to right, on the retrapping side (IRN < 0), constant-voltage inelastic tunneling features appear in arcs of constant V. Next, on the switching side (IRN > 0), both V and dV/dI jump at critical current IC, which depends on T. The detailed behavior of IC(T)RN depends on q, as we detail below. Finally, we find the hysteresis of JJs to be reduced in the hightemperature regime as IC(T)RN decreases. 

I = 0. Normalizing to junction area, we obtain a critical current density JC ≈ 1.2 kA/cm<sup>2</sup> for this junction, similar to the JC of intrinsic junctions (41). Together, these observations indicate that our q = 0° JJ reaches electronic quality comparable to IJJs of single-crystal BSCCO. 

#### Twist angle and temperature–dependent transport 

To compare transport characteristics of different twisted JJs, we normalized the bias current I with the junction normal resistance RN [see section S4 of (34) for experimental definition]. Because IC and R<sup>�</sup> N<sup>1arebothpropor-</sup> tional to the area of the junction, the product ICRN is independent of junction area. Figure 

The analysis of ICRN for 26 devices with q between0°and180°indicatesthatthemagnitude 

2 of 6 

Zhao et al., Science 382, 1422–1427 (2023) 22 December 2023 

RESEARCH | RESEARCH ARTICLE 





<!-- Start of picture text -->
A 90 dVdI R N 0° 31° 44.9° C 16 = 0°<br>10<br>14<br>70<br>12<br>TM<br>0 10 Theory<br>50<br>30 6 TM<br>29°<br>4<br>10 39°<br>-15 -10 -5 0 5 10 15-5 0 IC 5 -2 0 2 2<br>I RN (mV) I RN (mV) I RN (mV) 44.9° x5<br>B 25 0<br>ky 0 10 20 30 40 50 60 70 90<br>20 Temperature (K)<br>D 0° E 0°<br>90° 45° 90° 45°<br>0.6<br>15 60  <  90° <  45°<br> < 135°<br>kx<br>10 40<br>0<br>|A cos(2 )|<br>5 20<br>30 K 0 90<br>12 K 90<br>0 -0.6 0<br>0° 22.5° 45° 67.5° 90° 45° 22.5° 0° 45° 22.5° 0°<br> mod 90° |  45° | |  45° |<br>Temperature (K)<br> (mV)I RCN<br> (mV)IRCN<br> (K)TM<br>] / dT (mV / K)d [IRCN<br><!-- End of picture text -->

magnitude of superconducting gap D�→k<sup>�</sup> superposed in color. At q > 10°, Fermi surfaces intersect at two points per quadrant (circles) with different relative signs of SOPs. (C) Temperature dependence of the critical current for select devices. Dashed lines are linear fits to the low-temperature data. TM is the temperature where IC is maximal. Gray theory line shows expected ICRN(T) behavior [see section S8 of (34)]. (D) The slope of the low-temperature linear fit, d(ICRN)/dT. (E) TM as a function of angle<sup>~</sup> q. 

Fig. 2. d-wave SOP symmetry revealed by supercurrent tunneling. (A) Normalized differential resistance [dV/dI]/RN versus characteristic voltage IRN and temperature T. Current is swept to the right. Blue arrows highlight ICRN. (B) Angular dependence of ICRN at 30 and 12 K. The points follow the ��cos�2<sup>~</sup> q��� curve predicted for nearly incoherent tunneling between d-wave superconductors (15). (Inset) Schematic diagram of the Fermi surface of both crystals, with sign and 

of ICRN becomes smaller closer to 45° and 135°, where the JJs also appear less hysteretic. In Fig. 2B, we plot ICRN at two representative temperatures, 12 and 30 K, as a function of a new variable<sup>~</sup> q ¼ q mod p=2. We observe that ICRN��<sup>~</sup> q follows ��cos�2<sup>~</sup> q���, which is expected for nearly incoherent Cooper pair tunneling between d-wave superconductors (15). Similar angular dependence is seen in junction critical current density and junction voltage just above the critical current V(IC) (see fig. S8). In conventional tunneling JJs, eV(IC) ≈ 2D (42). In BSCCO IJJs, eV(IC) usually reaches about half the spectroscopic gap value (16). 

More quantitative analysis can be found in Fig. 2, D and E, where we plot the low-temperature slope d(ICRN)/dT (dashed lines in Fig. 2C and fig. S12) and observed TM, respectively. These plots show a nonmonotonic behavior of ICRN(T), signaled by the positive slope of ICRN(T) at low temperatures with finite TM, appearing within ��~q � p=4�� < p=8. The strong<sup>~</sup> q dependence of the nonmonotonic IC(T)RN in Fig. 2, D and E, points to SOP d-wave symmetry as its origin. For this explanation, we consider a gap function D1,2(k) superimposed on top of the Fermi surface EF<sup>1;2</sup> ðkÞ (43), where k is the in-plane Cooper pair wave vector in the first Brillouin zone and the index 1 or 2 denotes the top and bottom layer of BSCCO, respectively. In the twisted JJ, EF<sup>1</sup> ð<sup>k</sup> Þ and EF<sup>2</sup> ð<sup>k</sup> Þ are rotated relative to each other by angle q (Fig. 2B, inset). At q ≈ 0, EF<sup>1</sup> ð<sup>k</sup> Þ and EF<sup>2</sup> ð<sup>k</sup> Þ overlap almost completely and D1(k)D2(k) is >0, yielding a uniformly positive contribution to critical current for coherent tunneling (15). As q increases to ∼10°, the Fermi surfaces overlap at two points per quadrant in k-space, but with opposite phase difference between layers, yielding nodal and antinodal contribution where D1(k)D2(k) alternates in sign. Because the supercurrents from these two components carry the opposite sign, their 

contributions to the total critical current compete. As the gap in the nodal region is much smaller than the antinodal one, nonmonotonic temperature-dependent IC(T) is expected for ~q ≈ p=8, where the competition is strongest [see section S8 of (34) and (44) for more quantitative discussion]. We also note that near ~q ≈ p=4, the JJ coupling is strongly suppressed but remains nonzero. For the q = (44.9±.1)° junction, Josephson critical current can be measured up to 79 K, with ICRN about two orders of magnitude smaller than the 0° value. 

#### Second-order Josephson coupling near q = 45° 

The origin of the finite supercurrent near 45° is encoded in the Josephson current-phase relation (CPR) j(ϕ) = j1sin(ϕ) + j2sin(2ϕ), where j and ϕ are the Josephson current density and phase, respectively (10, 12, 24). At<sup>~</sup> q ¼ 45°, the maximally mismatched SOP phase eliminates the conventional direct Cooper pair tunneling term j1. The supercurrent must then flow through second-order mechanisms, which are predicted to support an interfacial superconductivity with doubly degenerate Josephson energy owing to the inherent dx2�y2 symmetry of the SOP within each flake (10–12). The CPR corresponding to this unusual SOP leaves an experimental signature in the in-plane magnetic 

The temperature dependence of Josephson coupling in our twisted junctions provides further insight into the pairing symmetry of the Cooper pairs in BSCCO. Figure 2C shows IC(T)RN for several representative JJs with different<sup>~</sup> q. For<sup>~</sup> q ∼ 0, we find that IC(T)RN monotonically decreases as T increases, approximately following the theory curve for nearly incoherent tunneling between d-wave superconductors [dashed line; see section S8 of (34)]. As<sup>~</sup> q increases, however, a surprising nonmonotonic behavior of IC(T)RN appears. For example, for ~q = 29° and 39° in Fig. 2C, IC(T)RN increases alongside T, reaching a maximum value at T = TM, and then decreases as T approaches TC. 

3 of 6 

Zhao et al., Science 382, 1422–1427 (2023) 22 December 2023 

RESEARCH | RESEARCH ARTICLE 





<!-- Start of picture text -->
A 0.2 1 14.0 mT8.6 mT C 0.1 4.5 -1 D (  ) dVdI E F( )<br>6.7 mT 0.09 10 A / cm 2<br>5.7 mT<br>3.0 mT<br>0.16 B 2.0 mT0 mT 0.08 Near<br>t<br>d 0.07 41.8 GHz70 K<br>0.12 0.06 0 -1 -1V (hf/2e)2 0 12 1 -<br>0<br>0 [dV/dI] / RN 20 0 I RN(mV) 0.25 0.05<br>0.08 w =   10  m<br>t = 132 nm<br>d =   28 nm 0.04<br>0.04 0.03<br>35 K 0.02 44.6° 1  = 2<br>44.9° 48.7 GHz 70 K<br>0 0.01<br>-40 -20 0 20 40 -2 -1 0 1 2 0 1 2<br>Field (mT) Voltage (hf/2e) Frequency (2e/hf) Spectral Power (arb)<br>B 2 F 0.1 G 46.5°<br>10 2 43.7° 20 A / cm 2 2 dBm<br>0.09 47.0 GHz 2<br>32.3 mT -5 dBm 45.0°<br>1.6 10 -1 0.08 44.6°<br>0 mT<br>70 K 43.7°<br>1.2 10 -3 0 I RN (mV) 2 0.070.06 -1 V (hf/2e)0 47.0 GHz1 H -5 2 -3 2 (  ) dVdI-1V (hf/2e)2 I 1 2 3 2 5 2<br>0.05<br>0.8 w =   10  m<br>t = 160 nm<br>d =  1.5 nm 0.04<br>0.4 0.03<br>20 K d = 15 nm 0.02 2  = 1<br>46.3° 70 K<br>0 0.01<br>0 10 20 30 40 50 60 70 -2 -1 0 1 2 0 1 2<br>Field (mT) Voltage (hf/2e) Frequency (2e/hf) Spectral Power (arb)<br>2 dBm<br>-3 dBm<br>) J + Offset RF off<br>V (mV) dV/dI (<br> (mV)I RN 1/2<br>1/2 (mW)PRF<br>V (mV) J + Offset dV/dI + Offset<br> (mV)I RN 1/2<br>1/2 (mW)PRF<br><!-- End of picture text -->

Fig. 3. Half-integer Shapiro steps and magnetic interference patterns emerge close to q = 45°. (A) Response to in-plane magnetic field B|| at q = 44.9°. One well-developed Fraunhofer pattern corresponding to d = 28 nm (14 nm for a second-harmonic CPR) appears, as indicated by the gray dashed line. (Left inset) Junction schematic. The Meissner currents (white lines) in the flakes affect the phase difference at the twist junction, enhancing its effective thickness d for the magnetic flux (42) [see section S13 of (34)]. (Right inset) IVCs at fields highlighted with arrows in the main panel. (B) q = 46.3° JJ. Two Fraunhofer patterns with different magnetic field periodicity appear (dashed lines), with an estimated d = 15 nm (gray) and d =1.5 nm (red). (Inset) I-V characteristics at two different 

B|| values, showing two jumps in V. (C) q = 44.6° JJ. dV/dI as a function of voltage across the junction and microwave illumination power P<sup>1</sup> RF<sup>=2at 70 K. dV/dI dips (white,</sup> pink) correspond to Shapiro steps. (Inset) I-V characteristic with half-integer Shapiro steps. (D) Fourier transform of dV/dI(V) and (E) the spectral power at nf = 1 and 2·2e/hf for the q = 44.6° JJ. (Inset) Schematic of the junction free energy F versus Josephson phase ϕ as twist angle changes. At 45°, the second harmonic dominates the current-phase relation. (F, H, and I) As in (C) to (E), but for the 43.7° device, where only integer Shapiro steps appear. (G) Representative dV/dI for all four devices with Shapiro step measurements at different twist angles. Halfinteger Shapiro steps are only observed in junctions closest to 45°. 

interference(“Fraunhofer”)patternandmicrowaveinduced Shapiro steps in the IVC, which are both sensitive to the presence of two degenerate local minima in Josephson energy that are connected by TRS (10, 11, 24). 

crystal bulk (42). The ratio d/t, where t is the total junction thickness, depends only on the properties of the crystal and junction geometry and should not depend strongly on the twist angle [see section S13 of (34)]. Notably, for the devices in Fig. 3, A and B, which share similar geometry, we obtain d/t ≈ 0.1 for both devices only if we assume that the 44.9° junction is coupled purely through the secondorder process with a doubled FIP period. 

n is an integer. We observe these conventional integer Shapiro steps in the JJs substantially away from<sup>~</sup> q ¼ p=4, as shown in the q = 43.7° device (Fig. 3F). Consistent with the FIP discussed above, the experimentally observed Shapiro steps also show signatures of the second-harmonic CPR as<sup>~</sup> q approaches p/4 (Fig. 3C): specifically, when our devices are within (45±1)°, additional steps at half-integer n appear. As shown in Fig. 3C, microwave illumination causes a series of dV/dI dips corresponding to steps in I-V at both integer and half-integer n to emerge from the symmetric I-V curve of an overdamped JJ. 

Figure 3, A and B, shows Fraunhofer interference patterns (FIPs) obtained at two different angles by applying parallel magnetic field B‖. Figure 3A shows q = 44.9° JJ with IC(B‖) oscillation with a period about 20 times shorter than that expected for intrinsic junctions. At a nearby angle q = 46.3° (Fig. 3B), the shortperiod oscillations appear to coexist with a long-period oscillation characteristic of IJJs (41). A reduction in the FIP period implies an increase in d, the thickness of the interfacial region where magnetic field penetrates owing to field-induced currents extending into the 

The presence of higher-order harmonics in the CPR near 45° is further revealed by measuring Shapiro steps in I-V under microwave illumination of frequency f (Fig. 3, C and F, inset) (11, 24). In conventional JJs, where the CPR is dominated by the first harmonic of ϕ, Shapiro steps appear as plateaus of constant voltage whenever V approaches n·hf/2e, where 

The Fourier components of dV/dI(V) show the relative strengths of integer and half-integer Shapiro steps. For the conventional Shapiro steps appearing in the 43.7° device, the Fourier 

4 of 6 

Zhao et al., Science 382, 1422–1427 (2023) 22 December 2023 

RESEARCH | RESEARCH ARTICLE 



transform shows dominant spectral power for the first harmonic n1 = 2e/hf (Fig. 3, H and I). In contrast, for the devices exhibiting half-integer Shapiro steps (e.g., the 44.6° device at low microwave power), the Fourier transform is dominated by the second harmonic n2 = 4e/hf. The corresponding dV/dI shows dips of similar strength at half-integer and integer steps, indicating that second-order processes dominate over the conventional Josephson coupling close to 45°. 

of angle inhomogeneity–induced TRS breaking in this device (53). 

current sweep sequence. In this scheme, one can controllably prepare the TRS broken initial ±ϕ0 states by the “training current sequence,” as shown in Fig. 4A. We use both positive and negative direction (+/−) and full and half sweep (F/H) to control the location of the phase particle during the retrapping process with high probability (24), where the switching critical current density JC<sup>F</sup> T<sup>=H</sup> is defined from supercurrent to normal current transition. We note that JC<sup>F</sup> þ<sup>=H</sup> ≈ �JC<sup>F</sup> �<sup>=H,reflectingthesymmetry</sup> between ±ϕ0 states due to TRS in the absence of magnetic field. 

#### Current-trainable Josephson diode effect 

The sign of j2 in CPR plays an important role in the quantum properties of twist Josephson junctions when it exceeds j1 in magnitude. When j2 is negative, the JJ ground state splits into a pair of degenerate states with complex phase angle ϕ = ±ϕ0 lying between 0 and p (12, 24) (Fig. 3E, inset). When q is tuned slightly away from 45°, both CPR harmonics coexist, creating asymmetric potential barrier heights aroundeachofthedegenerateenergeticminima. We observe such TRS breaking through an asymmetric critical current, whentheJosephson phase particle begins to roll down the resistively and capacitively shunted Josephson (RCSJ) washboard potential at different tilt angles, corresponding to different bias currents, in each direction (Fig. 4A, schematic) (54). 

Similar second-harmonic Josephson effects have been observed in parallel-connected arrays of 0- and p-JJs, where multiple degenerate ground states can form (45–48). Electronically, Josephson currents across distributions of facets in such junctions create disordered magnetic interference patterns, often with prominent peaks symmetrically centered about zero magnetic field (49–52). This is at odds with our Fraunhofer-like JC(B‖) measurements. Moreover, our TEM analysis [see section S2 of (34)] quantitatively bounds our interfacial twist angle disorder to 0.2°, which excludes the scenario 

Controlled placement of Josephson phase particles in a specific ±ϕ0 valley (broken TRS) and the directionally asymmetric barrier associated with each valley (broken spatial inversion symmetry) are the critical ingredients for a Josephson diode (55–64), as shown in Fig. 4, B and C. Here, by biasing the “training” current into the voltage state in the forward (reverse) direction with the amplitude between ��JCFT=H��, and then back to zero, the running JJ phase particle is retrapped into the −ϕ0 (or +ϕ0) valleys, 

We find that twist JJs slightly away from q = 45° exhibit nonreciprocal Josephson critical current, which can be controlled by the 



<!-- Start of picture text -->
A B 800 D 500 25<br>10 J > Jc+Half 0 0<br>400 20 -500 -25<br>5<br>500 25<br>0 JHalfc+ 0 0 -5000 0-25<br>-5 -400 -20 500 25<br>-10 10 0 0<br>-800 -500 -25<br>800<br>500 25<br>10 400 0-600 0 600 20 -5000 0-25<br>5 Jbias (A/cm 2 ) 5 10 15 20 25 30 35 40<br>0 0 Time (sec)<br>0 Full E<br>-10-5 Jc+ -400-800 |J| < |JFullc- | -20 2001000 54K<br>F(φ) 0 0.4 Time (sec)0.8 1.2 1.6 1000 42K<br>1050 JHalfc- φ C 800400 J < Jc+Full 20 10010000 JFullc- JHalfc- JHalfc+ JFullc+ 32K10K<br>0 0 -600 -500 -400 -300 300 400 500 600<br>-5  Jc (A/cm 2 )<br>-10 -400 0 -20 F 200300 |Jc+Full-JHalfc- |<br>-800 |Jc-Full-JHalfc+ |<br>800<br>10 -10 100<br>50 JFullc- 4000 -600 Jbias (A/cm0 2 ) 600 200 G 0.60 |Jc+Full-JFullc-  |<br>-5 0.4 |Jc+Half-JHalfc- |<br>-400 -20<br>-10 |J| > |Jc-Half| 0.2<br>-600 -400 -200 0 200 400 600 -8000 0.4 0.8 1.2 1.6 025 30 35 40 45<br> Jbias (A/cm 2 ) Time (sec) Twist Angle (deg)<br>Fig. 4. Time-reversal symmetry breaking Josephson diode effects. (E) Temperature-dependent switching current distributions of the four different<br>(A)A)) Junction I-V-VV characteristics obtained from a JJ with q = 39.5° at 12 K, critical currents. (F) Difference between mean full and half sweep DJ ¼ ���JC F= T H � J C H � =F ���<br>revealing four distinct JCC accessible via different current sweep directions and<br>versus twist angle q, and the standard deviation measured at 30 K. Schematics<br>histories. Schematics show RCSJ phase particle on the washboard potential just<br>show the shape of the potential with respect to twist angle, with the phase<br>before reaching JC.C.. (BB and C)) Junction current bias (dashes) and voltage<br>particle in the same well before switching. (G) Difference between positive and<br>response (lines) across training (gray shading) and test pulses. For each<br>subpanel, identical training pulses place the RCSJ phase particle in the same negative DJc ¼ ���JC F= þ H � J C F= � H ���, normalized by average Javg ¼ �J F C = þ H þ J C F= � H �=2<br>state (schematics). Insets show IVC of each test pulse. (D)D)) Junction response measured at 30 K. Schematic shows corresponding potential shape near 45°,<br>to consecutive training and test pulses, showing controllable behavior. where the phase particle is in different wells before switching.<br>j (mV)V<br>j (mV)V<br>j (mV)V<br>j (mV)V<br>j (mV)V<br>j (mV)V<br>2(A/cm) Jbias<br> (mV)Vj<br>2(A/cm) Jbias<br> (mV)Vj<br>2(A/cm) Jbias<br> (mV)Vj 2(A/cm) Jbias<br>Counts<br> (mV)Vj 2(A/cm) Jbias<br> (mV)Vj<br>2(A/cm) ∆J<br> (mV)Vj<br>2(A/cm) Jbias /JJavgc<br><!-- End of picture text -->

Fig. 4. Time-reversal symmetry breaking Josephson diode effects. (A)A)) Junction I-V-VV characteristics obtained from a JJ with q = 39.5° at 12 K, revealing four distinct JCC accessible via different current sweep directions and histories. Schematics show RCSJ phase particle on the washboard potential just before reaching JC.C.. (BB and C)) Junction current bias (dashes) and voltage response (lines) across training (gray shading) and test pulses. For each subpanel, identical training pulses place the RCSJ phase particle in the same state (schematics). Insets show IVC of each test pulse. (D)D)) Junction response to consecutive training and test pulses, showing controllable behavior. 

5 of 6 

Zhao et al., Science 382, 1422–1427 (2023) 22 December 2023 

RESEARCH | RESEARCH ARTICLE 



respectively. A subsequent test sweep measures a critical current whenever the RCSJ washboard potential is tilted sufficiently to overcome the potential barrier, giving rise to asymmetric critical current densities ��JC<sup>F</sup> þ�� and ��JCH���. Note that we can flip the polarity of this Josephson diode by flipping polarity of the training current (Fig. 4C). In this way, we repeatedly and controllably prepare the JJ into either ground state (Fig. 4D). At higher temperatures, the phase dynamics become damped, which hinders the processes depicted in Fig. 4A by trapping ϕ in the local minima of the washboard potential. As a result, the JC<sup>F=H</sup> asymmetry becomes less prominent upon heating and vanishes at about 50 K (Fig. 4E). In this study, we investigated the Josephson diode effect in several JJs with different twist angles. For each JJ, the critical current difference DJ ¼ JC<sup>F</sup> T<sup>=H</sup> � JC<sup>H</sup> ∓<sup>=Freflects the asymmetry</sup> in potential barriers for each ±ϕ0 valley (Fig. 4F), whereas the difference DJc ¼ JC<sup>F</sup> þ<sup>=H�J</sup> C<sup>F</sup> �<sup>=H</sup> reflects asymmetries between the two free energy minima (Fig. 4G). In both cases, the differences are strongest near 43° and weaken at both 45° and ∼35°, where j1 and j2 terms become negligible, respectively. Away from 45°, the absence of the diode effect is caused by the restoration of time-reversal symmetry. At exactly 45°, on the other hand, the purely secondharmonic Josephson potential has an additional symmetry around ±ϕ0: ±ϕ0 ± ϕ ↔ ±ϕ0 ∓ ϕ, which forbids the diode effect. Therefore, the diode effect is expected to vanish at 45° and at sufficiently low twist angles, which is consistent with our results. Thus, the observed diode effect is closely related to the free energy landscape of coexisting first- and second-harmonic CPR terms. The asymmetry between the two ground state valleys as observed in Fig. 4G can arise from an additional cosϕ term in the CPR [see section S14 of (34) for details]. Our demonstration of the polarity-tunable Josephson diode effect in near-45° twist BSCCO JJs thus provides strong experimental evidence for TRS broken superconductivity based on the emergent interfacial SOP. 





10. M. Sigrist, Prog. Theor. Phys. 99, 899–929 (1998). 

   60. J. F. Steiner, L. Melischek, M. Trahms, K. J. Franke, F. von Oppen, Phys. Rev. Lett. 130, 177002 (2023). 

11. Z. Yang, S. Qin, Q. Zhang, C. Fang, J. Hu, Phys. Rev. B 98, 104515 (2018). 

   61. Y. Zhang, Y. Gu, P. Li, J. Hu, K. Jiang, Phys. Rev. X 12, 041013 (2022). 

12. O. Can et al., Nat. Phys. 17, 519–524 (2021). 

13. P. Volkov, J. Wilson, K. Lucht, J. Pixley, Phys. Rev. B 107, 174506 (2023). 

   62. C. Baumgartner et al., J. Phys. Condens. Matter 34, 154005 (2022). 

   63. R. S. Souto, M. Leijnse, C. Schrade, Phys. Rev. Lett. 129, 267702 (2022). 

14. P. A. Volkov, J. H. Wilson, K. P. Lucht, J. H. Pixley, Phys. Rev. Lett. 130, 186001 (2023). 

15. R. A. Klemm, Philos. Mag. 85, 801–853 (2005). 

   64. B. Pal et al., Nat. Phys. 18, 1228–1233 (2022). 

16. K. Schlenga et al., Phys. Rev. B 57, 14518–14536 (1998). 

17. S. Y. F. Zhao et al., Phys. Rev. Lett. 122, 247001 (2019). 

   65. X. Cui et al., Replication Data for: Time-Reversal Symmetry Breaking Superconductivity between Twisted Cuprate Superconductors, version 1, Harvard Dataverse (2023); https://doi.org/10.7910/DVN/BYQDSP. 

18. M. Liao et al., Nano Lett. 18, 5660–5665 (2018). 

19. Y. Yu et al., Nature 575, 156–163 (2019). 

20. H. Hilgenkamp, J. Mannhart, Rev. Mod. Phys. 74, 485–549 (2002). 

21. C. C. Tsuei, J. R. Kirtley, Rev. Mod. Phys. 72, 969–1016 (2000). 

##### ACKNOWLEDGMENTS 

The authors are grateful for sample shipping coordination with J. Y. Park and for fruitful discussions with D. K. Bediako, K. S. Burch, S. Chakram, G.-H. Lee, R. Mélin, J. Wilson, B. Spivak, and S. Kivelson. Funding: The experiments were supported by the NSF (DMR-1809188 and DMR-1922172). P.K. acknowledges support from the US Department of Defense (DOD) Vannevar Bush Faculty Fellowship N00014-18-1-2877. Work at the University of British Columbia was supported by NSERC and CFREF. Stencil masks were fabricated at Harvard CNS, a part of the National Nanotechnology Coordinated Infrastructure (NSF 1541959). STEM imaging was performed at Harvard CNS Imaging and Analysis Facility (NSF ECCS-2025158) and at Seoul National University. N.P. acknowledges the Deutsche Forschungsgemeinschaft (DFG452128813) for partial support of the project. P.A.V. is supported by a Rutgers Center for Materials Theory Postdoctoral Fellowship, and J.H.P. is partially supported by the Air Force Office of Scientific Research under grant FA9550-20-1-0136, NSF CAREER grant DMR-1941569, and the Alfred P. Sloan Foundation through a Sloan Research Fellowship. P.A.V. and J.H.P. acknowledge the Aspen Center for Physics, where part of this work was performed, which is supported by National Science Foundation grant PHY-1607611. This work was partially supported by a grant from the Simons Foundation (P.A.V.). The work at Brookhaven National Laboratory was supported by the US Department of Energy, Office of Basic Energy Sciences, under contract DOE-sc0012704. Author contributions: S.Y.F.Z., N.P., and P.K. conceived of and designed the experiment. S.Y.F.Z. and N.P. developed the air-sensitive cryogenic stacking technique. S.Y.F.Z., X.C., and N.P. performed the experiments. S.L., M.K., H.Y., A.J.A., J.A.G., and R.E. performed the focused ion beam lamella sample preparation and TEM and STEM imaging. R.Z. and G.G. provided the crystals. P.A.V. and J.H.P. performed theoretical analysis of the Fraunhofer patterns and contributed to the analysis of the critical current. M.F., S.P., and T.T. performed theoretical analysis of the critical current. S.Y.F.Z., N.P., X.C., and P.K. analyzed the data and wrote the manuscript, with contributions from P.A.V., J.H.P., M.F., and Y.R. Competing interests: The authors declare that they have no competing interests. Data and materials availability: The data from this study are available at the Harvard Dataverse (65). License information: Copyright © 2023 the authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original US government works. https://www.science.org/about/science-licenses-journalarticle-reuse 

22. F. Lombardi et al., Phys. Rev. Lett. 89, 207001 (2002). 

23. E. Il’ichev et al., Phys. Rev. Lett. 81, 894–897 (1998). 

24. E. Goldobin, D. Koelle, R. Kleiner, A. Buzdin, Phys. Rev. B 76, 224523 (2007). 

25. L. J. Sandilands et al., Phys. Rev. B 90, 081402 (2014). 

26. M. Fratini et al., Nature 466, 841–844 (2010). 

27. Q. Li et al., Phys. Rev. Lett. 83, 4160–4163 (1999). 

28. Y. I. Latyshev, A. P. Orlov, A. M. Nikitina, P. Monceau, R. A. Klemm, Phys. Rev. B 70, 094517 (2004). 

29. Y. Zhu et al., Phys. Rev. X 11, 031011 (2021). 

30. Y. Takano et al., Phys. Rev. B 65, 140513 (2002). 

31. J. Lee et al., Nano Lett. 21, 10469–10477 (2021). 

32. Y. Zhu et al., Phys. Rev. B 57, 8601–8608 (1998). 

33. Y. Takano et al., Physica C 408-410, 296–299 (2004). 

34. See supplementary materials for methods and detailed analysis. 

35. N. Poccia et al., Phys. Rev. Mater. 4, 114007 (2020). 

36. N. B. Othman, G.-i. Oya, M. Kitamura, A. Irie, IEEE Trans. Appl. Supercond. 21, 176–179 (2011). 

37. K. Hirata, S. Ooi, T. Mochiku, Physica C 362, 114–120 (2001). 

38. G. Hechtfischer et al., Phys. Rev. B 55, 14638–14644 (1997). 

39. A. Yurgens, Supercond. Sci. Technol. 13, R85–R100 (2000). 

40. K. Tanabe, Y. Hidaka, S. Karimoto, M. Suzuki, Phys. Rev. B 53, 9348–9352 (1996). 

41. A. Irie et al., Phys. Rev. B 62, 6681–6686 (2000). 

42. A. Barone, G. Paterno, Physics and Applications of the Josephson Effect (Wiley, 1982). 

43. M. Hashimoto, I. M. Vishik, R.-H. He, T. P. Devereaux, Z.-X. Shen, Nat. Phys. 10, 483–495 (2014). 

44. T. Tummuru, S. Plugge, M. Franz, Phys. Rev. B 105, 064501 (2022). 

45. H. Sickinger et al., Phys. Rev. Lett. 109, 107002 (2012). 

46. A. Zyuzin, B. Spivak, Phys. Rev. B 61, 5902–5904 (2000). 

47. A. Buzdin, A. Koshelev, Phys. Rev. B 67, 220504 (2003). 

48. N. G. Pugach, E. Goldobin, R. Kleiner, D. Koelle, Phys. Rev. B 81, 104513 (2010). 

49. S. Scharinger et al., Phys. Rev. B 81, 174535 (2010). 

50. W. K. Neils, D. J. Van Harlingen, Phys. Rev. Lett. 88, 047001 (2002). 

51. J. Mannhart et al., Phys. Rev. Lett. 77, 2782–2785 (1996). 

52. H. Hilgenkamp, J. Mannhart, B. Mayer, Phys. Rev. B 53, 14586–14593 (1996). 

##### SUPPLEMENTARY MATERIALS 

##### REFERENCES AND NOTES 

53. A. C. Yuan, Y. Vituri, E. Berg, B. Spivak, S. A. Kivelson, Phys. Rev. B 108, L100505 (2023). 

science.org/doi/10.1126/science.abl8371 Materials and Methods Supplementary Text Figs. S1 to S24 Table S1 References (66–99) Submitted 8 August 2021; resubmitted 7 February 2023 Accepted 7 November 2023 Published online 7 December 2023 10.1126/science.abl8371 

1. R. Ribeiro-Palau et al., Science 361, 690–693 (2018). 

2. H. Yoo et al., Nat. Mater. 18, 448–453 (2019). 

   54. M. Tinkham, Introduction to Superconductivity (Dover Publications Inc., 1996). 

3. S. Carr, S. Fang, E. Kaxiras, Nat. Rev. Mater. 5, 748–763 (2020). 

   55. K. Misaki, N. Nagaosa, Phys. Rev. B 103, 245302 (2021). 

4. D. M. Kennes et al., Nat. Phys. 17, 155–163 (2021). 

   56. H. Wu et al., Nature 604, 653–656 (2022). 

5. Y. Cao et al., Nature 556, 43–50 (2018). 

   57. M. Davydova, S. Prembabu, L. Fu, Sci. Adv. 8, eabo0309 (2022). 

6. X. Lu et al., Nature 574, 653–657 (2019). 

   58. J. Díez-Mérida et al., Nat. Commun. 14, 2396 (2023). 

7. Y. Saito et al., Nat. Phys. 17, 478–481 (2021). 

   59. C. Baumgartner et al., Nat. Nanotechnol. 17, 39–44 (2022). 

8. Y. Zhou et al., Nature 595, 48–52 (2021). 

9. Y. Cao et al., Nature 556, 80–84 (2018). 

6 of 6 

Zhao et al., Science 382, 1422–1427 (2023) 22 December 2023 



### **Time-reversal symmetry breaking superconductivity between twisted cuprate superconductors** 

S. Y. Frank Zhao, Xiaomeng Cui, Pavel A. Volkov, Hyobin Yoo, Sangmin Lee, Jules A. Gardener, Austin J. Akey, Rebecca Engelke, Yuval Ronen, Ruidan Zhong, Genda Gu, Stephan Plugge, Tarun Tummuru, Miyoung Kim, Marcel Franz, Jedediah H. Pixley, Nicola Poccia, and Philip Kim 

_Science_ **382** (6677), .  DOI: 10.1126/science.abl8371 

#### **Editor’s summary** 

Twisted two-dimensional (2D) structures exhibit a wealth of interesting behaviors. Recently, the 2D materials used in such superlattices have largely been graphene and various transition metal dichalcogenides. However, cuprate superconductors can also be thought of as 2D materials, with the copper-oxide planes coupled to each other through Josephson coupling. Zhao _et al_ . created high-quality twisted structures of a bismuth-based cuprate by cleaving a single exfoliated crystal and placing the two halves on top of each other at various angles. Near the twist angle of 45°, Josephson coupling was suppressed by the d-wave superconducting order parameter of the material. The researchers also observed a Josephson diode effect caused by the breaking of time reversal symmetry. —Jelena Stajic 

#### **View the article online** 

https://www.science.org/doi/10.1126/science.abl8371 **Permissions** 

https://www.science.org/help/reprints-and-permissions 

Use of this article is subject to the Terms of service 

_Science_ (ISSN 1095-9203) is published by the American Association for the Advancement of Science. 1200 New York Avenue NW, Washington, DC 20005. The title _Science_ is a registered trademark of AAAS. 

Copyright © 2023 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works 

