# Engineering ligand reactivity enables high-temperature operation of stable perovskite solar cells

| 字段 | 内容 |
|---|---|
| 期刊 | Science |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 405 |
| 作者 | So Min Park, M. Wei, Jian Xu, H. Atapattu, F. Eickemeyer, Kasra Darabi, Luke Grater, Yi Yang et al. |
| DOI | 10.1126/science.adi4107 |
| 源文件 | 028_Park_2023_Engineering-ligand-reactivity-enables-high-tempe.pdf |

---
Submitted Manuscript: Confidential 

5 

10 

15 

20 

25 

30 

35 

# **Engineering ligand reactivity enables high-temperature operation of stable perovskite solar cells** 

So Min Park,<sup>1</sup> † Mingyang Wei,<sup>2</sup> † Jian Xu,<sup>1</sup> † Harindi R. Atapattu,<sup>3</sup> Felix T. Eickemeyer,<sup>2</sup> Kasra Darabi,<sup>4</sup> Luke Grater,<sup>1</sup> Yi Yang,<sup>5</sup> Cheng Liu,<sup>5</sup> Sam Teale,<sup>1</sup> Bin Chen,<sup>1,5</sup> Hao Chen,<sup>1</sup> Tonghui Wang,<sup>4</sup> Lewei Zeng,<sup>1</sup> Aidan Maxwell,<sup>1</sup> Zaiwei Wang,<sup>1</sup> Keerthan R. Rao,<sup>3</sup> Zhuoyun Cai,<sup>6</sup> Shaik M. Zakeeruddin,<sup>2</sup> Jonathan T. Pham,<sup>6</sup> Chad M. Risko,<sup>3</sup> Aram Amassian,<sup>4</sup> Mercouri G. Kanatzidis,<sup>5</sup> Kenneth R. Graham,<sup>3</sup> * Michael Grätzel<sup>2</sup> * & Edward H. Sargent<sup>1,5,7</sup> * 

1Department of Electrical and Computer Engineering, University of Toronto, 10 King’s College Road, Toronto, Ontario, M5S 3G4, Canada 

2Laboratory of Photonics and Interfaces, Ecole Polytechnique Fédérale de Lausanne, Lausanne, 1015, Switzerland 

3Department of Chemistry, University of Kentucky, Lexington, KY, 40506, USA 

4Department of Materials Science and Engineering, and Organic and Carbon Electronics Laboratories (ORaCEL), North Carolina State University, Raleigh, NC, 27695, USA 

5Department of Chemistry, Northwestern University, Evanston, Illinois 60208, USA 

6Department of Chemical and Materials Engineering, University of Kentucky, Lexington, KY, 40506, USA 

7Department of Electrical and Computer Engineering, Northwestern University, Evanston, Illinois 60208, USA 

† These authors contributed equally to this work. 

* Corresponding authors. E-mails: <u>ted.sargent@utoronto.ca; michael.graetzel@epfl.ch; kenneth.graham@uky.edu</u> 

**Abstract:** Perovskite solar cells (PSCs) consisting of interfacial two-dimensional/threedimensional heterostructures that incorporate ammonium ligand intercalation have enabled rapid progress toward the goal of uniting performance with stability. However, as the field continues to seek ever-higher durability, additional tools that avoid progressive ligand intercalation are needed to minimize degradation at high temperatures. We use ammonium ligands that are nonreactive with the bulk of perovskites and investigate libraries varying ligand molecular structure systematically. We find that fluorinated aniliniums offer interfacial passivation and simultaneously minimize reactivity with perovskites. Using this approach, we report a certified quasi-steady-state power-conversion efficiency of 24.09% for inverted-structure PSCs. In an encapsulated device operating at 85 degrees Celsius and 50% relative humidity, we document a 1560-hour _T_ 85 at maximum power point under 1-sun illumination. 

**One-Sentence Summary:** Suppressing ammonium ligand intercalation stabilizes the interface structure of perovskite solar cells at high temperatures. 

1 

Submitted Manuscript: Confidential 

5 

10 

15 

20 

25 

Metal-halide perovskite solar cells (PSCs) are emerging photovoltaic (PV) technologies that hold promise in terawatt-scale deployment ( _1_ ). They unite high power-conversion efficiencies (certified PCE up to 25.7%) ( _2_ ) with low-cost solution processing using abundant materials ( _3_ – _5_ ). To compete with crystalline silicon ( _c_ -Si) solar cells and to be applied with _c_ -Si in tandem cells, PSCs will need improved evidence of bankability ( _6_ ), such as operating stability at elevated temperatures in accelerated aging ( _7_ – _12_ ). 

Interfaces, which have high defect densities ( _13_ , _14_ ) and low barriers to ion transfer ( _15_ , _16_ ), and are susceptibility to moisture- and oxygen-induced degradation ( _17_ , _18_ ), can provide pathways for energy loss and degradation in PSCs ( _19_ , _20_ ). In record-efficiency PSCs, interfaces have been passivated by using two-dimensional/three-dimensional (2D/3D) hybrid structures ( _21_ – _23_ ), where a thin layer of Ruddlesden-Popper 2D perovskites terminates the 3D-perovskite surface. These 2D/3D structures are constructed by exposing perovskite surfaces to a solution containing ammonium ligands, during which the 3D lattice is fragmented into 2D layers ( _24_ , _25_ ). This approach is beneficial because the 2D overlayer increases the resistance of perovskites to degradation ( _17_ , _26_ ). 

There exists a diversity of findings in reports on the stability of 2D overlayers under stress. Some studies have indicated limited stability of the 3D/2D interface under thermal stress ( _27_ – _29_ ). Progress has been made, with a recent study demonstrating 500-hour operating stability under conditions of 65°C, 50% relative humidity, and maximum power point (MPP) tracking (ISOS-L3-65°C), enhanced by the incorporation of 3-fluorophenethylammonium intercalation ( _23_ ). Another report ( _30_ ) that utilized an oleylammonium-intercalated 2D overlayer showed promising results in a 1000-hour damp-heat test, this study though reporting based on silicon PV module IEC 61215:2016 standards (85°C and 85% relative humidity, dark). 

30 

35 

Given these promising performance and stability improvements, the field continues to pursue everhigher durability targets. There exists interest in raising the standard to 85°C ISOS-L-3 (MPP tracking at 85°C and 50% relative humidity). Here, the reactivity of ammonium ligands with 3D perovskites may lead to further penetration into the bulk perovskite film ( _28_ , _31_ , _32_ ), and may contribute to deterioration in device performance under these very demanding stress conditions ( _27_ , _28_ , _31_ – _33_ ). Thus, we explored non-invasive surface-passivating ligands; but we did note that, in prior studies, these have yet to achieve the remarkable benefits of the 3D:2D strategy. 

We sought to understand how molecular structure impacts ligand reactivity with 3D perovskites. Previous studies used bulkier ammonium ligands to suppress ligand intercalation, whereas certain small-sized ammonium ligands exhibit low reactivity ( _34_ , _35_ ). We attribute this difference to the limited availability of characterization techniques that allow one to compare ligand reactivity among different ammonium molecules – a particularly challenging pursuit in view of the ultrathin nature (typically < 10 nm) of the passivating overlayer ( _23_ ). 

## **Spectroscopy studies of ammonium ligands in perovskites** 

2 

Submitted Manuscript: Confidential 

5 

20 

We used angle-resolved x-ray photoelectron spectroscopy (AR-XPS) and time-of-flight secondary ion mass spectrometry (TOF-SIMS) to investigate the penetration of a library of ammonium ligands into the bulk of perovskites (Fig. 1A), which include varying tail groups and alkyl chain lengths. A small-sized ammonium ligand, anilinium (An) had the lowest reactivity with 3D perovskites. We then explored derivatives of An with different degrees of fluorination to couple low ligand reactivity with effectual interfacial passivation. These molecules improved operating stability for the encapsulated PSC at 85°C and 50% relative humidity. 

10 

15 

25 

30 

35 

Ammonium ligands were deposited on Cs0.05MA0.05FA0.9Pb(I0.95Br0.05)3 perovskite films (Methods), and films were annealed at 100°C ( _31_ ). We used AR-XPS to probe the spatial distribution of ammonium ligands in the out-of-plane direction (Fig. 1B). AR-XPS is a nondestructive depth-profiling technique to determine the composition of ultrathin layers (< 10 nm) at the top surfaces of films ( _36_ , _37_ ). We varied the probe depth by changing the angle between the normal of the perovskite sample and the analyzer. Three different electron take-off angles (0°, 45°, and 75°) were selected with probe depths varying from approximately 6 to 8 nm at 0° to 1 to 2 nm at 75° (Fig. 1C). 

To obtain the proportion of ammonium ligands at a given probe depth, we compared the ratio of C-N, where N signals originated from methylammonium (MA) and ammonium ligands at a binding energy of ~401.5 eV to the N signals originating from formamidinium (FA) at a binding energy of ~399.8 eV in the peak area in the N 1s XPS spectrum (figs. S1 and S2). The C-N/FA N ratio plots (Fig. 1D) revealed that the aryl ammoniums phenethylammonium (PEA) and 3- fluorophenethylammonium (3FPEA) had relatively uniform depth distributions. In contrast, alkyl ammoniums butylammonium (BA) and octylammonium (OA) tended to accumulate on the top surfaces, as evidenced by the C-N/FA N ratio increasing with larger electron take-off angles. However, each of the ligands yielded C-N/FA N ratios greater than those of untreated perovskites (control) for all electron take-off angles (Fig. 1E), indicating their distinct contributions to C-N signals and their intercalation into the bulk of perovskites. 

We then examined long-chain alkyl ammonium decylammonium (DA), along with small-sized An ( _34_ , _35_ , _38_ ). For DA, the C-N/FA N ratio decreased with a larger electron take-off angle (Fig. 1D). The reversed trend, as compared to other alkyl ammoniums, suggested that DA molecules diffused into the bulk of perovskites. In contrast, An exhibited low reactivity and had limited penetration into perovskites. The C-N/FA N ratios for An were ~2 times less than those for PEA at different electron take-off angles and are similar to control perovskites (Fig. 1E). 

At these low C-N/FA N ratios, quantifying the extent of ligand penetration was difficult, given the prominent C-N contribution from MA cations (fig. S2 and table S1). We thereby performed TOFSIMS and found that, whereas PEA cations were distributed throughout the thickness of the perovskite film, An cations were detected only at the top surface of the film (fig. S3). The combining AR-XPS and TOF-SIMS support An remaining surface localized. 

3 

Submitted Manuscript: Confidential 

5 

10 

15 

20 

25 

Although An exhibited low ligand reactivity, it has also been reported to have limited passivating capacity ( _35_ , _39_ ). To promote interfacial passivation, we explored fluorinated An, including 4- fluoroanilinium (4FAn), 2,6-difluoroanilinium (26FAn), and 3,4,5-trifluoroanilinium (345FAn), and tert-butyl-substituted 3,5-di-tert-butylanilinium (35tbuAn) ( _17_ , _40_ , _41_ ). The C-N/FA N ratios (Fig. 1E) revealed that, compared to An, the newly synthesized ligands retained similarly low reactivity with perovskites. For fluorinated An, this low reactivity was also seen in the C-F signal in the F 1s XPS spectrum (fig. S4). We identified a distinct C-F peak for 3FPEA, whereas the C- F signals from 4FAn, 26FAn, and 345FAn were all below the detection limit at the different electron take-off angles. TOF-SIMS further confirmed that 345FAn cations were localized to the surface of the perovskite film (fig. S5). 

<mark>We characterized the phase transformation of perovskites driven by their interaction with ammonium ligands. Ultrafast t</mark> ransient reflectio <mark>n (TR) spectroscopy was used initially to detect 2D perovskite formation (</mark> _<mark>42</mark>_ <mark>). For the PEA-treated perovskite films, negative reflectance features associated with</mark> _<mark>n</mark>_ <mark>= 1, 2, and 3 layered 2D perovskites were observed in the TR spectra (Fig. 2A). The relative proportion of 2D phases increased as the solution exposure time was prolonged (fig. S6) and was indicative of progressive phase transformation. For the An- and 345FAn-treated perovskite films, no 2D phases were observed (Fig. 2, B and C), which we attributed to their inability to convert 3D perovskites into 2D phases (fig. S7). These results reinforce the model that inhibiting 2D phase conversion would also reduce ligand penetration.</mark> 

<mark>Phase transformation was also investigated with grazing incidence wide-angle x-ray scattering (GIWAXS) measurements. Consistent with the TR studies,</mark> _<mark>n</mark>_ <mark>= 2 2D perovskites were observed at around</mark> _<mark>q</mark>_ <mark>= 0.29 Å</mark><sup>−1</sup> <mark>along</mark> _<mark>q</mark>_ z <mark>for the PEA-treated perovskite film (Fig. 2D) that blocks vertical carrier transport (</mark> _<mark>32</mark>_ <mark>). Incidence-angle-dependent diffraction patterns of PEA-treated perovskites revealed that the 2D phase formation was more pronounced near the surface (fig. S8). No 2D phase was detected in the An- and 345FAn-treated perovskites (Fig. 2, E and F).</mark> 

30 

<mark>We also observed the formation of PbI</mark> 2 <mark>at</mark> _<mark>q</mark>_ <mark>= 0.9 Å</mark><sup>−1</sup> <mark>for An-treated perovskite films, which we attributed to polar-solvent-induced decomposition during solution exposure, as seen in x-ray diffraction (XRD) characterization (fig. S9). This is a topic that requires further in-depth investigation. GIWAXS characterization showed that 345FAn protected the underlying perovskites from this solvent-induced degradation (Fig. 2F). We associate the reduction in surface degradation with increased hydrophobicity of this fluorinated ligand (fig. S10) (</mark> _<mark>26</mark>_ <mark>).</mark> 

## **<mark>Theoretical calculations</mark>** 

35 

<mark>The interactions of ammonium ligands and perovskites are depicted in Fig. 3A. We performed density functional theory (DFT) calculations to explore how molecular structure impacted these interactions. We first calculated the binding energies (</mark> _<mark>E</mark>_ b <mark>) of two adjacent perovskite fragments at their interface with the insertion of ammonium ligands (Fig. 3B). A more negative</mark> _<mark>E</mark>_ b <mark>implies it is thermodynamically more favorable to form the 2D/3D heterostructures (</mark> _<mark>24</mark>_ <mark>). Consistent with the</mark> 

4 

Submitted Manuscript: Confidential 

10 

20 

<mark>AR-XPS studies, penetrating PEA had a more negative</mark> _<mark>E</mark>_ b <mark>value than alkyl ammoniums OA and BA, whereas An and its derivatives showed the least tendency to form 2D/3D structures (Fig. 3C).</mark> 

5 

15 

<mark>It has been suggested that the formation of 2D perovskites is related to the steric hindrance around the NH</mark> 3<sup>+</sup> <mark>group (</mark> _<mark>43</mark>_ <mark>). We calculated the steric effect index (STEI, defined as the steric environment around the NH</mark> 3<sup>+</sup> <mark>group) of the ammonium ligand (</mark> _<mark>43</mark>_ <mark>) and found that An had a much larger STEI of 2.34 than that of PEA (1.21). Furthermore, phase transformation entailed the replacement of A- site cations at 2D/3D interfaces (</mark> _<mark>24</mark>_ <mark>). DFT calculations indicated that this process demanded more energy for An-intercalated interfaces than PEA-intercalated ones (fig. S11). This evidence further supported that An was less likely to penetrate the bulk of perovskites through ligand intercalation.</mark> 

<mark>We proceeded to examine the interactions between ammonium ligands and perovskite surfaces. We calculated the interaction energy (</mark> _<mark>E</mark>_ int <mark>) for the scenario where an ammonium ligand occupied an MA-vacancy site on the perovskite surface (Fig. 3D). Electrostatic potential (ESP) calculations showed that fluorine substitution resulted in a higher positive charge density near the ammonium group (fig. S12) that could enhance its binding with the negatively charged MA-vacancy (</mark> _<mark>13</mark>_ <mark>). Indeed, the</mark> _<mark>E</mark>_ int <mark>values were -0.74, -0.89, -0.92, and -1.22 eV for An, 4FAn, 26FAn, 345FAn, respectively (Fig. 3Ee), indicating that 345FAn exhibited the strongest interaction with the perovskite surface. It is also noted that future computational studies could beneficially predict the binding energy of the N 1s XPS peak.</mark> 

## **<mark>Perovskite degradation and solar cell studies</mark>** 

25 

30 

35 

<mark>We used TR and TOF-SIMS to study perovskite degradation. The TR results indicated that PEAbased 2D perovskites were thermally unstable on the film surface and decomposed into PbI</mark> 2 <mark>after thermal aging at 85°C for 2 hours (Fig. 4, A and B). This process we associated with the diffusion of PEA cations into bulk perovskites, as was seen in TOF-SIMS (Fig. 4C) and AR-XPS (fig. S13). The dynamic nature of 2D/3D heterostructures was also confirmed for BA, OA, DA, and 3FPEA (fig. S14). In contrast, neither ligand penetration nor phase degradation was observed for An- and 345FAn-treated films (Fig. 4C and fig. S15). These results suggested that suppressing ligand intercalation into 3D perovskites improved interface stability under thermal stress.</mark> 

<mark>We monitored the photoluminescence (PL) stability of perovskite films after annealing at 85°C (Fig. 4D). The emission intensity of the untreated control and PEA-treated films degraded to 30% of its initial value within 144 hours (Fig. 4E), as seen in the previous reports (</mark> _<mark>31</mark>_ <mark>). In contrast, Anand 345FAn-treated films show improved thermal stability and 345FAn-treated perovskites retained 85% of their initial brightness following annealing.</mark> 

<mark>We fabricated inverted-structure PSCs to investigate how ammonium ligands influenced the efficiency and stability of PSCs. We used both Cs</mark> 0.05 <mark>MA</mark> 0.05 <mark>FA</mark> 0.9 <mark>Pb(I</mark> 0.95 <mark>Br</mark> 0.05 <mark>)</mark> 3 <mark>and Cs</mark> 0.05 <mark>MA</mark> 0.15 <mark>FA</mark> 0.8 <mark>PbI</mark> 3 <mark>perovskites as the absorber, the self-assembled monolayer 2PACz as the hole transport layer (HTL), the thermally evaporated C</mark> 60 <mark>/BCP bilayer as the electron transport</mark> 

5 

Submitted Manuscript: Confidential 

<mark>layer (ETL), and indium tin oxide (ITO) as the transparent electrode (see Methods). Three representative ammonium ligands, including the 2D-forming PEA cation and the non-invasive An and 345FAn cations, were used for interfacial engineering. The cross-sectional SEM image of a complete device is shown in fig. S16.</mark> 

5 

10 

15 

20 

25 

30 

35 

<mark>Device performance (Fig. 5A) showed that compared to control devices, PEA-treated Cs</mark> 0.05 <mark>MA</mark> 0.15 <mark>FA</mark> 0.8 <mark>PbI</mark> 3 <mark>PSCs (16 devices) provided improved PV performance with an average PCE of 23.2% (Fig. 5A and fig. S17). The average PCE of An devices decreased to 19.9%, a finding we linked to perovskite decomposition. Because of the improved surface passivation, 345FAn treatment increased average PCEs of Cs</mark> 0.05 <mark>MA</mark> 0.15 <mark>FA</mark> 0.8 <mark>PbI</mark> 3 <mark>and Cs</mark> 0.05 <mark>MA</mark> 0.05 <mark>FA</mark> 0.9 <mark>Pb(I</mark> 0.95 <mark>Br</mark> 0.05 <mark>)</mark> 3 <mark>PSCs to 23.3% and 22.9%, respectively (Fig. 5A and fig. S18). The external quantum efficiency (EQE) spectra of the champion cells (Fig. 5B) for PEA and 345FAn devices exhibited improved charge collection compared to controls, and their integrated</mark> _<mark>J</mark>_ sc <mark>values matched well with those from the current-voltage (I-V) sweep.</mark> 

<mark>We sent a 345FAn-treated Cs</mark> 0.05 <mark>MA</mark> 0.15 <mark>FA</mark> 0.8 <mark>PbI</mark> 3 <mark>device to National Renewable Energy Laboratory (NREL, USA) for independent characterization. The device delivered a certified PCE of 24.09% using a quasi-steady-state (QSS) I-V sweep (Fig. 5C and fig. S19). The QSS-certified efficiency reported for inverted PSCs is compared to that of other devices in Table S2.</mark> 

<mark>Seeking a better understanding of the improved performance, we used ultraviolet photoelectron spectroscopy (UPS) to characterize the electronic structure of the perovskite films. The secondary electron cut-off spectra (fig. S20) showed that 345FAn decreased the work function of perovskites from 4.64 to 4.17 eV and shifted the valence band maximum from 1.15 eV below the Fermi level in the control perovskites to 1.50 eV below the Fermi level. Taken together, these results show that 345FAn induced more n-type character in the perovskite film (fig. S20), which in inverted PSCs leads to favorable band bending for electron extraction and a decrease in non-radiative carrier recombination (</mark> _<mark>44</mark>_ <mark>,</mark> _<mark>45</mark>_ <mark>).</mark> 

<mark>We performed optoelectronic characterization to investigate carrier recombination. From photoluminescence quantum yield (PLQY) measurements, we identify non-radiative recombination at the perovskite/C</mark> 60 <mark>interface as the limiting factor for the performance of control devices (fig. S21). This recombination loss corresponded to a reduction of the quasi-Fermi level splitting (QFLS) by ~100 meV (table S3) (</mark> _<mark>46</mark>_ <mark>,</mark> _<mark>47</mark>_ <mark>). We found PEA and 345FAn passivation could reduce the interfacial non-radiative recombination, as reflected by the improved QFLS relative to the control stack by ~15 and ~30 meV, respectively. We further analyzed the energy loss of PSCs based on the device diode characteristics (figs. S22 and S23) (</mark> _<mark>48</mark>_ <mark>). Consistent with the PL studies, non-radiative losses are reduced for PEA and 345FAn devices (12.7% and 12.1% for PEA and 345FAn, respectively), compared to those of the control device (16.5%) (fig. S24).</mark> 

<mark>We evaluated the impact of ligand reactivity on the material processing of PSCs. We varied the solution exposure time between 0 s (dynamic spinning) and 120 s and tracked the PV parameters</mark> 

6 

Submitted Manuscript: Confidential 

5 

10 

15 

<mark>of PSCs accordingly (Fig. 5D and fig. S25). The average PCE of PEA devices (8 devices for each condition) dropped to 15.8%, with an average fill factor (FF) of merely 67.4% over the course of solution exposure for 30 s, while 345FAn devices maintained an average PCE of 23.0% (Fig. 5d). Wide solution-processing windows were also achieved for other non-penetrating ligands, such as 35tbuAn, 4FAn, and 26FAn (fig. S26). In pursuit of initial evidence of capacity to scale area, we fabricated perovskite solar modules (PSMs) with an active area of 22 cm</mark><sup>2</sup> <mark>and 9 interconnected subcells (Methods). The champion PCE under reverse voltage scan was improved from 19.9% to 20.8% for the 345FAn-treated PSMs, with a</mark> _<mark>V</mark>_ oc <mark>of 10.13 V, an FF of 74.2%, and a</mark> _<mark>J</mark>_ sc <mark>of 2.77 mA cm</mark><sup>−2</sup> <mark>(fig. S27).</mark> 

20 

25 

30 

<mark>We studied the operating stability of PSCs using ISOS protocols (</mark> _<mark>49</mark>_ <mark>). Accelerated lifetime testing was performed at the ISOS-L-3-85°C level, constituting light-soaking tests at 50% RH and 85°C with maximum power point (MPP) tracking. We used atomic-layer deposition for SnO</mark> 2 <mark>as the buffer layer and Cs</mark> 0.05 <mark>MA</mark> 0.05 <mark>FA</mark> 0.9 <mark>Pb(I</mark> 0.95 <mark>Br</mark> 0.05 <mark>)</mark> 3 <mark>perovskites as the absorber (see Methods). The initial PCEs of the encapsulated control, PEA, and 345FAn devices were 18.9%, 20.1%, and 20.2%, respectively (fig. S28). The stability results are shown in Fig. 5E. We recorded a similar</mark> _<mark>T</mark>_ 80 <mark>of ~220 hours for the control and PEA devices, in accordance with the limited thermal stability of perovskite films (Fig. 3E). We found that 2D/3D PSCs based on alkyl ammonium BA and OA were even less stable than the control device (fig. S29). In contrast, the 345FAn device retained >80% of its initial value after the 800-hour test. We estimate the</mark> _<mark>T</mark>_ 80 <mark>of 810 h for the 345FAn device (fig. S30), representing a fourfold enhancement over the operating lifetime of the PEA device.</mark> 

<mark>To improve the</mark> _<mark>T</mark>_ 80 <mark>further, we moved to fluorine-doped tin oxide (FTO) as an alternative transparent electrode (fig. S31) in light of its chemical stability (</mark> _<mark>50</mark>_ <mark>,</mark> _<mark>51</mark>_ <mark>). We monitored the MPP of the encapsulated device under 1-sun illumination at 50% RH and 85°C. The initial PCE was 19.0%, which increased progressively to a peak value of 19.9% after ~ 50 hours of operation (Fig. 5F). This maximum efficiency (PCE</mark> max <mark>) corresponds to a temperature coefficient of -0.12% /°C relative to the room-temperature device PCE (21.5%), which is consistent with reported results for inverted PSCs (</mark> _<mark>52</mark>_ <mark>). After 1586 hours of continuous operation, the PCE dropped to 16.8% (84% of the PCE</mark> max <mark>), primarily because of a reduction in current density (Fig. 5G). We determined the</mark> _<mark>T</mark>_ 85 <mark>to be ~1560 h (Fig. 5F). A comparison with other ISOS-L-3-stable PSCs is provided in Table S4.</mark> 

## **<mark>Discussion</mark>** 

35 

<mark>Two types of 2D/3D heterostructures have been reported for ISOS-L-3-stable PSCs: 3FPEAintercalated 2D/3D perovskites (</mark> _<mark>23</mark>_ <mark>) and all-inorganic heterostructures (</mark> _<mark>12</mark>_ <mark>). For all-inorganic PSCs, the</mark> _<mark>T</mark>_ 85 <mark>reached an impressive 4000 h at 85°C, but with further room for progress in PCE (<= 17% when measured at 85°C). 3FPEA-based PSCs have achieved PCEs exceeding 23% at room temperature, but stable operation over 500 hours was limited to 65°C.</mark> 

7 

Submitted Manuscript: Confidential 

10 

5 

<mark>Aided by spectroscopic techniques, including AR-XPS, TOF-SIMS, and TR, we see evidence herein that certain 2D/3D heterostructures, such as those employing typical ammonium ligands including PEA, 3FPEA, BA, and OA, may evince thermal degradation, something we assign to the dynamic nature of the interfaces at elevated temperatures. Anilinium and its fluorinated derivatives offer a more robust interface structure correlated with limited penetration into the bulk of perovskites. Fluorinated An contributes interface passivation linked to strong interactions with perovskite surfaces. The resultant optimized 345FAn devices are among the most stable PSCs seen under ISOS-L-3 protocols at 85°C, achieving PCE of 19.9% during MPP tracking at this elevated operating temperature.</mark> 

## **<mark>References and Notes</mark>** 

1. N. M. Haegel _et al._ , Terawatt-scale photovoltaics: Transform global energy. _Science_ . **364** , 836–838 (2019). 

2. National Renewable Energy Laboratory, Best research-cell efficiencies, (available at https://www.nrel.gov/pv/cell-efficiency.html). 

15 

3. H. Min _et al._ , Perovskite solar cells with atomically coherent interlayers on SnO2 electrodes. _Nature_ . **598** , 444–450 (2021). 

4. M. Kim _et al._ , Conformal quantum dot–SnO 2 layers as electron transporters for efficient perovskite solar cells. _Science_ . **375** , 302–306 (2022). 

20 

5. J. Jeong _et al._ , Pseudo-halide anion engineering for α-FAPbI3 perovskite solar cells. _Nature_ . **592** , 381–385 (2021). 

6. Z. Song _et al._ , A technoeconomic analysis of perovskite solar module manufacturing with low-cost materials and techniques. _Energy Environ. Sci._ **10** , 1297–1305 (2017). 

25 

7. Y. Zhao _et al._ , A bilayer conducting polymer structure for planar perovskite solar cells with over 1,400 hours operational stability at elevated temperatures. _Nat. Energy_ . **7** , 144– 152 (2022). 

8. S. Bai _et al._ , Planar perovskite solar cells with long-term stability using ionic liquid additives. _Nature_ . **571** , 245–250 (2019). 

9. Q. Cao _et al._ , Efficient and stable inverted perovskite solar cells with very high fill factors via incorporation of star-shaped polymer. _Sci. Adv._ **7** , 1–12 (2021). 

30 

10. Y. Liu _et al._ , Stabilization of Highly Efficient and Stable Phase‐Pure FAPbI 3 Perovskite Solar Cells by Molecularly Tailored 2D‐Overlayers. _Angew. Chemie Int. Ed._ **59** , 15688– 15694 (2020). 

11. Y.-H. Lin _et al._ , A piperidinium salt stabilizes efficient metal-halide perovskite solar cells. _Science_ . **369** , 96–102 (2020). 

35 

12. X. Zhao _et al._ , Accelerated aging of all-inorganic, interface-stabilized perovskite solar cells. _Science_ . **377** , 307–310 (2022). 

13. R. Lin _et al._ , All-perovskite tandem solar cells with improved grain surface passivation. _Nature_ . **603** , 73–78 (2022). 

14. X. Li _et al._ , Constructing heterojunctions by surface sulfidation for efficient inverted 

8 

Submitted Manuscript: Confidential 

perovskite solar cells. _Science_ . **375** , 434–437 (2022). 

15. L. Chao _et al._ , Origin of High Efficiency and Long-Term Stability in Ionic Liquid Perovskite Photovoltaic. _Research_ . **2020** , 1–13 (2020). 

5 

   16. H. Kim _et al._ , Proton-transfer-induced 3D/2D hybrid perovskites suppress ion migration and reduce luminance overshoot. _Nat. Commun._ **11** , 3378 (2020). 

   17. H. Zhu _et al._ , Tailored Amphiphilic Molecular Mitigators for Stable Perovskite Solar Cells with 23.5% Efficiency. _Adv. Mater._ **32** , 1907757 (2020). 

   18. S. Yang _et al._ , Stabilizing halide perovskite surfaces for solar cell operation with widebandgap lead oxysalts. _Science_ . **365** , 473–478 (2019). 

- 10 

   19. J. Warby _et al._ , Understanding Performance Limiting Interfacial Recombination in pin Perovskite Solar Cells. _Adv. Energy Mater._ **2103567** , 2103567 (2022). 

   20. S. M. Park, A. Abtahi, A. M. Boehm, K. R. Graham, Surface Ligands for Methylammonium Lead Iodide Films: Surface Coverage, Energetics, and Photovoltaic Performance. _ACS Energy Lett._ **5** , 799–806 (2020). 

- 15 

21. J. J. Yoo _et al._ , An interface stabilized perovskite solar cell with high stabilized efficiency and low voltage loss. _Energy Environ. Sci._ **12** , 2192–2199 (2019). 

22. J. J. Yoo _et al._ , Efficient perovskite solar cells via improved carrier management. _Nature_ . **590** , 587–593 (2021). 

20 

23. H. Chen _et al._ , Quantum-size-tuned heterostructures enable efficient and stable inverted perovskite solar cells. _Nat. Photonics_ . **16** , 352–358 (2022). 

24. A. H. Proppe _et al._ , Multication perovskite 2D/3D interfaces form via progressive dimensional reduction. _Nat. Commun._ **12** , 3472 (2021). 

25. S. Sidhik _et al._ , Deterministic fabrication of 3D/2D perovskite bilayer stacks for durable and efficient solar cells. _Science_ . **377** , 1425–1430 (2022). 

25 

26. Y. Liu _et al._ , Ultrahydrophobic 3D/2D fluoroarene bilayer-based water-resistant perovskite solar cells with efficiencies exceeding 22%. _Sci. Adv._ **5** , eaaw2543 (2019). 

27. J. Chakkamalayath, N. Hiott, P. V. Kamat, How Stable Is the 2D/3D Interface of Metal Halide Perovskite under Light and Heat? _ACS Energy Lett._ **8** , 169–171 (2023). 

30 

28. C. A. R. Perini _et al._ , Interface Reconstruction from Ruddlesden–Popper Structures Impacts Stability in Lead Halide Perovskite Solar Cells. _Adv. Mater._ **34** , 2204726 (2022). 

29. A. A. Sutanto _et al._ , In Situ Analysis Reveals the Role of 2D Perovskite in Preventing Thermal-Induced Degradation in 2D/3D Perovskite Interfaces. _Nano Lett._ **20** , 3992–3998 (2020). 

35 

30. R. Azmi _et al._ , Damp heat–stable perovskite solar cells with tailored-dimensionality 2D/3D heterojunctions. _Science_ . **376** , 73–77 (2022). 

31. Q. Jiang _et al._ , Surface passivation of perovskite film for efficient solar cells. _Nat. Photonics_ . **13** , 460–466 (2019). 

32. C. Liu _et al._ , Tuning structural isomers of phenylenediammonium to afford efficient and stable perovskite solar cells and modules. _Nat. Commun._ **12** , 6394 (2021). 

9 

Submitted Manuscript: Confidential 

33. S. Kumar, L. Houben, K. Rechav, D. Cahen, Halide perovskite dynamics at work : Large cations at 2D-on-3D interfaces are mobile. _PNAS_ . **119** , 1–9 (2022). 

5 

34. M. M. Tavakoli _et al._ , Addition of adamantylammonium iodide to hole transport layers enables highly efficient and electroluminescent perovskite solar cells. _Energy Environ. Sci._ **11** , 3310–3320 (2018). 

35. S.-H. Lee _et al._ , Acid Dissociation Constant: A Criterion for Selecting Passivation Agents in Perovskite Solar Cells. _ACS Energy Lett._ **6** , 1612–1621 (2021). 

36. C. S. Fadley, Angle-resolved x-ray photoelectron spectroscopy. _Prog. Surf. Sci._ **16** , 275– 388 (1984). 

10 

37. B. Lv, T. Qian, H. Ding, Angle-resolved photoemission spectroscopy and its application to topological materials. _Nat. Rev. Phys._ **1** , 609–626 (2019). 

38. Y. Wei _et al._ , Reverse‐Graded 2D Ruddlesden–Popper Perovskites for Efficient Air‐ Stable Solar Cells. _Adv. Energy Mater._ **9** , 1900612 (2019). 

15 

39. D. Bi _et al._ , Multifunctional molecular modulators for perovskite solar cells with over 20% efficiency and high operational stability. _Nat. Commun._ **9** , 4482 (2018). 

40. Y. Liu _et al._ , Ultrahydrophobic 3D/2D fluoroarene bilayer-based water-resistant perovskite solar cells with efficiencies exceeding 22%. _Sci. Adv._ **5** , 1–9 (2019). 

20 

41. M. A. Hope _et al._ , Nanoscale Phase Segregation in Supramolecular π ‑ Templating for Hybrid Perovskite Photovoltaics from NMR Crystallography. _J. Am. Chem. Soc_ . **143** , 1529–1538 (2021). 

42. Y. Yang _et al._ , Top and bottom surfaces limit carrier lifetime in lead iodide perovskite films. _Nat. Energy_ . **2** , 16207 (2017). 

25 

43. R. Lyu, C. E. Moore, T. Liu, Y. Yu, Y. Wu, Predictive Design Model for LowDimensional Organic–Inorganic Halide Perovskites Assisted by Machine Learning. _J. Am. Chem. Soc._ **143** , 12766–12776 (2021). 

44. D. Luo _et al._ , Enhanced photovoltage for inverted planar heterojunction perovskite solar cells. _Science_ . **360** , 1442–1446 (2018). 

45. Q. Jiang _et al._ , Surface reaction for efficient and stable inverted perovskite solar cells. _Nature_ . **611** , 278–283 (2022). 

30 

46. M. Stolterfoht _et al._ , How To Quantify the Efficiency Potential of Neat Perovskite Films: Perovskite Semiconductors with an Implied Efficiency Exceeding 28%. _Adv. Mater._ **32** , 2000080 (2020). 

47. M. Stolterfoht _et al._ , Visualization and suppression of interfacial recombination for highefficiency large-area pin perovskite solar cells. _Nat. Energy_ . **3** , 847–854 (2018). 

35 

48. H. Zhang _et al._ , Multimodal host–guest complexation for efficient and stable perovskite photovoltaics. _Nat. Commun._ **12** , 3383 (2021). 

49. M. V. Khenkin _et al._ , Consensus statement for stability assessment and reporting for perovskite photovoltaics based on ISOS procedures. _Nat. Energy_ . **5** , 35–49 (2020). 

50. J. D. Benck, B. A. Pinaud, Y. Gorlin, T. F. Jaramillo, Substrate Selection for Fundamental Studies of Electrocatalysts and Photoelectrodes: Inert Potential Windows in Acidic, 

40 

10 

Submitted Manuscript: Confidential 

Neutral, and Basic Electrolyte. _PLoS One_ . **9** , e107942 (2014). 

   51. R. A. Kerner, B. P. Rand, Electrochemical and Thermal Etching of Indium Tin Oxide by Solid-State Hybrid Organic–Inorganic Perovskites. _ACS Appl. Energy Mater._ **2** , 6097– 6101 (2019). 

- 5 

52. T. Moot _et al._ , Temperature Coefficients of Perovskite Photovoltaics for Energy Yield Calculations. _ACS Energy Lett._ **6** , 2038–2047 (2021). 

53. S. P. Harvey _et al._ , Mitigating Measurement Artifacts in TOF-SIMS Analysis of Perovskite Solar Cells. _ACS Appl. Mater. Interfaces_ . **11** , 30911–30918 (2019). 

10 

   54. R. A. Vargas−Hernández, Bayesian Optimization for Calibrating and Selecting HybridDensity Functional Models. _J. Phys. Chem. A_ . **124** , 4053–4061 (2020). 

   55. J. P. Perdew, K. Burke, M. Ernzerhof, Generalized Gradient Approximation Made Simple. _Phys. Rev. Lett._ **77** , 3865–3868 (1996). 

   56. K. Lee, É. D. Murray, L. Kong, B. I. Lundqvist, D. C. Langreth, Higher-accuracy van der Waals density functional. _Phys. Rev. B_ . **82** , 081101 (2010). 

- 15 

   57. T. Lu, F. Chen, Multiwfn: A multifunctional wavefunction analyzer. _J. Comput. Chem._ **33** , 580–592 (2012). 

   58. J. Endres _et al._ , Valence and Conduction Band Densities of States of Metal Halide Perovskites: A Combined Experimental–Theoretical Study. _J. Phys. Chem. Lett._ **7** , 2722– 2729 (2016). 

- 20 

   59. P. Caprioglio _et al._ , On the Origin of the Ideality Factor in Perovskite Solar Cells. _Adv. Energy Mater._ **10** , 2000502 (2020). 

   60. W. Tress _et al._ , Interpretation and evolution of open-circuit voltage, recombination, ideality factor and subgap defect states during reversible light-soaking and irreversible degradation of perovskite solar cells. _Energy Environ. Sci._ **11** , 151–165 (2018). 

- 25 

61. A. Castro‐Chong _et al._ , Illumination Intensity Dependence of the Recombination Mechanism in Mixed Perovskite Solar Cells. _Chempluschem_ . **86** , 1347–1356 (2021). 

62. S. Chen, X. Xiao, H. Gu, J. Huang, Iodine reduction for reproducible and highperformance perovskite solar cells and modules. _Sci. Adv._ **7** , 1–7 (2021). 

30 

63. X. Zheng _et al._ , Managing grains and interfaces via ligand anchoring enables 22.3%efficiency inverted perovskite solar cells. _Nat. Energy_ . **5** , 131–140 (2020). 

**Acknowledgements: Funding:** This research was made possible by the U.S. Department of the Navy, Office of Naval Research Grant (N00014-20-1-2572). This work was supported in part by 35 Ontario Research Fund-Research Excellence program (ORF7-Ministry of Research and Innovation, Ontario Research Fund-Research Excellence Round 7). This work was also supported under award number OSR-CRG2020-4350.2. S.M.P., H.R.A., and K.R.G. gratefully acknowledge the U.S. Department of Energy, Office of Science, Office of Basic Energy Sciences, and the EPSCoR program, under award no. DE-SC0018208 for XPS measurements. K.R.R., Z.C., J.T.P., 40 C.M.R., and K.R.G. acknowledge funding from the National Science Foundation through 

11 

Submitted Manuscript: Confidential 

5 

10 

15 

20 

Cooperative Agreement Number 1849213. Supercomputing resources on the Lipscomb High Performance Computing Cluster were provided by the University of Kentucky Information Technology Department and Center for Computational Sciences (CCS). M.W. acknowledges funding from the European Union’s Horizon 2020 Research and Innovation program under the Marie Skłodowska-Curie Grant Agreement No. 101026353. TW and AA acknowledge the support of the National Science Foundation under award number ECCS-1936527. AA acknowledges partial support by the Office of Naval Research under award number N00014-20-1-2573. This work made use of the NUFAB and Keck-II facilities of Northwestern University’s NUANCE Center, which has received support from the SHyNE Resource (NSF ECCS-2025633), the IIN, and Northwestern’s MRSEC program (NSF DMR-1720139). 

**Author contributions:** S.M.P., M.W., K.R.G., M.G., and E.H.S. conceived the idea and proposed the experimental and model design. S.M.P. and M.W. fabricated all the devices and conducted the characterization. S.M.P and H.R.A performed XPS and UPS characterization and data analysis. J.X., K.R.R., and C.M.R. conducted the DFT simulation. Y.Y., C.L., and M.G.K. measured TOFSIMS and fabricated PSMs. F.T.E., M.W., S.M.Z., and M.G. conducted the PL characterization and data analysis. K.D., T.W., and A.A. performed the GIWAXS measurements. S.T. and S.M.P. measured the TR spectra. L.G., B.C, H.C., L.Z., A.M., and Z.W helped with the device fabrication and material characterization. Z.C. and J.T.P. performed the contact-angle measurements. M.W., S.M.P., J.X., K.R.G, M.G., and E.H.S. co-wrote the manuscript. All authors contributed to data analysis, read, and commented on the manuscript. 

**Competing interests:** The authors declare no competing interests. 

25 **Data and materials availability:** All data are provided in the main text or the supplementary materials. 

## **Supplementary Materials** 

Materials and Methods 

30 

Supplementary Text Figs. S1 to S31 Tables S1 to S4 References (53-63) 

12 

Submitted Manuscript: Confidential 

5 



























**Fig. 1. AR-XPS characterization of ammonium ligand penetration.** ( **A** ) Chemical structures of the ammonium ligands investigated in this study. ( **B** ) Experimental setup for AR-XPS characterization. The electron take-off angle _α_ is defined as the angle between the normal of the sample substrate and the analyzer. ( **C** ) Schematic indicating the relation between _α_ and the photoelectron probing depth _d_ . ( **D-E** ) C-N to FA N ratios at electron take-off angles of 0°, 45°, and 75° for the control (untreated) and ammonium ligand-treated perovskite films. The results show reduced bulk and surface existence for An and An derivatives. 

13 

Submitted Manuscript: Confidential 

5 

10 



















**Fig. 2. Phase transformation of perovskite films.** ( **A-C** ) Pseudocolor representation of the transient reflectance spectra for the PEA ( **A** ), An ( **B** ), and 345FAn ( **C** ) treated perovskite films, respectively. _n_ = 1, n = 2, _n_ = 3 2D perovskites ( _n_ 1, _n_ 2, and _n_ 3) appear in the film after PEA passivation. ( **D-F** ) GIWAXS image for perovskite films of PEA ( **D** ), An ( **E** ), and 345FAn ( **F** ) passivation, respectively. The color bar shows the diffraction intensity collected from the GIWAXS detector. _q_ xy and _q_ z represent in-plane and near out-of-plane scattering vectors, respectively. _n_ = 2 2D perovskite ( _n_ 2) and PbI2-related diffraction peaks are observed in the PEA and An treated films, respectively. (100) refers to the (100) diffraction peak of 3D perovskites. 

14 

Submitted Manuscript: Confidential 

5 

























**<mark>Fig. 3. DFT studies.</mark>** <mark>(</mark> **A** ) <mark>Schematic depiction of the model of ammonium ligand and perovskite interactions. (</mark> **B** ) Models used in DFT calculations to calculate the binding energy ( _E_ b) of adjacent 2D perovskite fragments. ( **C** ) _E_ b values for seven ammonium ligands substituted into MAPbI3 perovskite slabs. **<mark>(D)</mark>** <mark>Models used to calculate the interaction energy (</mark> _<mark>E</mark>_ int <mark>) of ammonium ligands with the MAPbI</mark> 3 <mark>perovskite surface.</mark> **<mark>(E)</mark>** _<mark>E</mark> i_ nt <mark>values of four ammonium ligands with the perovskite surface.</mark> 

15 

Submitted Manuscript: Confidential 

5 

10 



















**Fig. 4. Thermal stability of perovskite films.** ( **A-B** ) Pseudocolor representation of the transient reflectance spectra for PEA-treated perovskite films before ( **A** ) and after ( **B** ) thermal aging at 85°C for 2 h. 2D perovskites were decomposed into PbI2 after thermal aging. ( **C** ) The distribution of PEA<sup>+</sup> and An<sup>+</sup> in fresh and aged (at 85°C for 2 h) perovskite films using TOF-SIMS. ( **D** ) PL spectra of perovskite thin films under thermal annealing at 85°C. The films were kept on a hot plate at 85°C in the N2-filled glovebox and measured every 24 h in ambient air. ( **E** ) Changes in PL intensity for different annealing times. Data are presented as mean values ± standard deviation. Three films were measured under each condition. 

16 

Submitted Manuscript: Confidential 

5 

10 























**<mark>Fig. 5. P</mark> hotovoltaic performance of** **<mark>PSCs with interface engineering.</mark>** <mark>(</mark> **A** <mark>) PCE for control (8 devices) vs. ammonium ligand treated (16 devices for each type) PSCs.  (</mark> **B** <mark>) EQE curves of the control and ammonium ligand-treated devices. (</mark> **<mark>C</mark>** <mark>) Quasi-steady-state</mark> _<mark>J-V</mark>_ <mark>curve of one representative 345FAn device certified at NREL. Inset: PV parameters of the device. (</mark> **<mark>D</mark>** <mark>) PCE evolution of PEA and 345FAn devices as a function of solution exposure time (8 devices for each condition). Data are presented as mean values ± standard deviation. The inset is a schematic illustration of the solution exposure process for interface engineering. (</mark> **<mark>E</mark>** <mark>) MPP tracking of encapsulated control, PEA, and 345FAn devices using ITO substrates at 85°C with a relative humidity of ~50% under 0.8-sun illumination. (</mark> **<mark>F</mark> -** **<mark>G</mark>** <mark>) PCE (</mark> **<mark>F</mark>** <mark>), current density (</mark> _<mark>J</mark>_ mpp <mark>), and voltage (</mark> _<mark>V</mark>_ mpp <mark>) (</mark> **<mark>G</mark>** <mark>) at the MPP of the encapsulated 345FAn device using an FTO substrate under 1-sun illumination at 85°C and ~50% relative humidity.</mark> 

15 

17 

