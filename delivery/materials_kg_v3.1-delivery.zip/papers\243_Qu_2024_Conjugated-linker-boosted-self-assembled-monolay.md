# Conjugated linker-boosted self-assembled monolayer molecule for inverted perovskite solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Joule |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 240 |
| 作者 | G. Qu, Si-Yuan Cai, Ying Qiao, Deng Wang, Shaokuan Gong, Danish Khan, Yu Wang, Kui Jiang et al. |
| DOI | 10.1016/j.joule.2024.05.005 |
| 源文件 | 033_Qu_2024_Conjugated-linker-boosted-self-assembled-monolay.pdf |

---
**ll** 

### Article 

# Conjugated linker-boosted self-assembled monolayer molecule for inverted perovskite solar cells 



Geping Qu, Siyuan Cai, Ying Qiao, ..., Xihan Chen, Alex K.-Y Jen, Zong-Xiang Xu 

chenxh@sustech.edu.cn (X.C.) alexjen@cityu.edu.hk (A.K.-Y.J.) xu.zx@sustech.edu.cn (Z.-X.X.) 

Highlights 

Enhancing self-assembled monolayer molecular engineering with phenylene linker 

Confirmation of molecular structure’s influence on SAM molecules arrangement 

Ultrafast spectroscopy reveals phenylene linker greatly enhances SAM hole extraction 

Achieving a power conversion efficiency of 26.17% with high stability 

This study improves on commercial self-assembled monolayers (SAMs) like Me4PACz by replacing its linker with a conjugated phenylene, creating Me-PhpPACz for inverted perovskite solar cells (PSCs). The resulting PSCs displayed a record power conversion efficiency (PCE) of 26.17%, along with a fill factor (FF) of 86.79% and exceptional stability. Ultrafast spectroscopy showed that Me-PhpPACz not only regulates the electrode’s work function (WF) but also aids carrier extraction and transport. Our in-depth analysis enhances our understanding of the intricate relationship between SAM molecular design and PSC performance, opening up opportunities for further boosting PSC performance. 

Qu et al., Joule 8, 2123–2134 July 17, 2024 ª 2024 Elsevier Inc. All rights are reserved, including those for text and data mining, AI training, and similar technologies. https://doi.org/10.1016/j.joule.2024.05.005 



**ll** 

##### Article 

## Conjugated linker-boosted self-assembled monolayer molecule for inverted perovskite solar cells 

Geping Qu,<sup>1,5</sup> Siyuan Cai,<sup>1,5</sup> Ying Qiao,<sup>1,5</sup> Deng Wang,<sup>2,5</sup> Shaokuan Gong,<sup>3</sup> Danish Khan,<sup>4</sup> Yu Wang,<sup>1</sup> Kui Jiang,<sup>2</sup> Qian Chen,<sup>1</sup> Letian Zhang,<sup>1</sup> Yang-Gang Wang,<sup>1</sup> Xihan Chen,<sup>3,</sup> * Alex K.-Y Jen,<sup>2,</sup> * and Zong-Xiang Xu<sup>1,6,</sup> * 

###### SUMMARY 

This study builds upon the success achieved from commercial selfassembled monolayers (SAMs), such as Me-4PACz, by replacing its flexible butyl linker with a conjugated phenylene ring to form a SAM molecule, Me-PhpPACz, for inverted perovskite solar cells (PSCs). The Me-PhpPACz-derived PSCs exhibited an unprecedented power conversion efficiency of 26.17% with an extremely high fill factor of 86.79% and exceptional long-term stability. The result from ultrafast spectroscopy shows that phenylene-linked SAMs not only modulate the work function of indium tin oxide electrode but also facilitate charge carrier extraction and transport. Our detailed study helps deepen our understanding of the delicate relationship between SAM molecular design and PSC performance, paving the way for further enhancing the efficiency and stability of PSCs. 

###### INTRODUCTION 

Recently, remarkable advancements have been made in perovskite solar cells (PSCs), with power conversion efficiencies (PCEs) surpassing 26%.<sup>1</sup> Further improvement of PSCs requires the delicate control of the interfaces between the absorber and charge-transporting layers (CTLs). Since there are only limited choices of inorganic materials to be used as proper interlayers for PSCs,<sup>2,3</sup> exploring synthetic organic chemistry to fine-tune material properties in device engineering has been identified as a key for further enhancing the performance of PSCs. Consequently, the perovskite research community has developed numerous organic semiconductors as CTLs for PSCs, including the very promising self-assembled monolayers (SAMs) to serve as a very effective hole-selective layer (HSL) for inverted (p-i-n) PSCs. From a molecular structure perspective, a typical SAM molecule comprises an anchoring group, a linker, and a terminal group. Each of these elements serves a distinct role in enhancing PSC performance.<sup>4</sup> Phosphonic acid (PA) has been found to exhibit very strong binding energy to enhance the stability and performance of SAMs.<sup>5,6</sup> Terminal groups, such as carbazole (Cz) derivatives, contribute to surface coverage, modify surface properties, and generate a dipole moment that can tune the substrate’s work function (WF).<sup>4,7</sup> A widely studied SAM molecule, [4-(3,6dimethyl-9H-carbazol-9-yl)butyl]PA (Me-4PACz), has been extensively used to achieve excellent performance in inverted PSCs.<sup>8,9</sup> However, there is still a lot of room for further improving molecular design to push PCE closer to the ShockleyQueisser (S-Q) limit. The linker group, which connects the terminal group and anchoring group, has a significant influence on the self-assembly process. Although flexible alkyl chains are commonly used in SAMs for PSCs, they are not the optimal 

###### CONTEXT & SCALE 

Self-assembled monolayer (SAM) has become an indispensable component in perovskite solar cells (PSCs) to enhance performance and reduce cost. However, concerns persist about the efficiency and stability of SAM molecules. Additionally, the impact of SAM molecular structure on thin film packing and hole extraction or transport ability on PSC performance remains obscure. Here, we developed a novel SAM, Me-PhpPACz, by replacing the flexible alkyl linker with a conjugated phenylene linker in the commercial SAM Me4PACz. This modification enhances the molecule’s aspect ratio and dipole moment, resulting in improved film coverage and hole extraction. Consequently, the power conversion efficiency and stability of inverted PSCs have significantly improved, reaching 26.17% for Me-PhpPACz compared with 24.14% for Me-4PACz. Moreover, conjugated linkers can also be applied to various carbazolebased SAMs, yielding higher performance compared with nonconjugated alkyl chain-connected SAM molecules. 



Joule 8, 2123–2134, July 17, 2024 ª 2024 Elsevier Inc. All rights are reserved, including those for text and data mining, AI training, and similar technologies. 

2123 

**ll** 

Article 

choice due to their insulating property and flexibility.<sup>10</sup> These factors can hinder charge flow and intermolecular interactions, in addition to affecting the molecular density on the substrate. Therefore, it is rational to employ a conjugated, rigid linker to provide a more robust and conductive backbone to offer improved stability and rapid charge transfer capabilities.<sup>10–12</sup> 

Because SAMs are ultrathin, their compactness and coverage are crucial for efficient charge extraction and minimized shunt paths.<sup>13</sup> Although the co-adsorption of two different SAM molecules has been suggested to fill possible voids,<sup>13,14</sup> the optimal approach is to modify the best available SAMs, such as Me-4PACz. After a combined theoretical and experimental analysis, we developed a SAM, [4-(3,6-dimethyl-9Hcarbazol-9-yl)phenyl]PA (Me-PhpPACz), by replacing the flexible alkyl linker with a rigid, planar, and conjugated phenylene linker. This modification enhances the molecule’s aspect ratio, dipole moment, and charge transfers, which improves the film coverage and hole transport. As a result, the PCE and stability of inverted PSCs have significantly improved, reaching 26.17% for Me-PhpPACz compared with 24.14% for Me-4PACz. 

###### RESULTS AND DISCUSSION 

The detailed synthesis of SAM molecules is depicted in the supplemental information (Figure S1), and all the synthesized key intermediates and the final compounds were characterized by<sup>1</sup> H nuclear magnetic resonance (NMR),<sup>13</sup> C NMR,<sup>31</sup> P NMR, and high-resolution mass spectrometry to examine their molecular structures and purity (Figures S2–S37). Cyclic voltammetry (CV) and UV-vis spectra were also performed to study their electrochemical and optical properties (Figures S38 and S39; Table S1). All SAM materials exhibited p-type semiconductor properties, which are favorable for application in HSL of inverted PSC. 

By replacing an alkyl linker with a phenylene linker, it helps improve the molecular rigidity, materials stability, packing density of the SAMs, and their capability in hole extraction. Calculation analysis of Me-4PACz (Figure 1A) revealed that the highest occupied molecular orbitals (HOMOs) and lowest unoccupied molecular orbitals (LUMOs) of Me-4PACz are both located on the electron-rich Cz terminal group, and the LUMO is as high as �0.95 eV, which results in high photoactivity. Although the HOMO and LUMO orbitals of Me-PhpPACz (Figure 1B) are more effectively delocalized and spatially separated, which helps to enhance the photo- and electrical stability induced by effective electron/charge delocalization and stabilized LUMO energy level (�1.4 eV).<sup>12</sup> These effects are reflected in the CV measurements. The current densities of Me-4PACz decreased significantly during 25 cycles of CV, suggesting lower electrochemical stability compared with Me-PhpPACz (Figures 1C and 1D). For measuring photostability, SAM molecules were dissolved in deuterated dimethyl sulfoxide (DMSO-d6) and exposed to 1 sun equivalent illumination for 12 h. The<sup>1</sup> H NMR spectra showed significant decomposition in Me-4PACz solutions, with peaks emerging at low field (7.3–8.7 ppm) indicating cleavage of Cz fragments (Figure 1E). On the contrary, minimal changes in color and 1H NMR signals were observed for Me-PhpPACz solutions, confirming its higher photostability (Figures 1F and 1G). The results from thermogravimetric analysis (Figure S40) showed that the conjugated linker had minimal impact on the thermal stability of SAMs, both revealing decomposition temperatures exceeding 300<sup>�</sup> C. 

The interaction between the anchoring group of SAM molecules and indium tin oxide (ITO) was analyzed using X-ray photoelectron (XPS) spectroscopy (Figure S41; 

1Department of Chemistry, Southern University of Science and Technology, Shenzhen 518055, Guangdong, China 

2Department of Materials Science and Engineering, City University of Hong Kong, Kowloon 999077, Hong Kong, China 

3Shenzhen Key Laboratory of Intelligent Robotics and Flexible Manufacturing Systems, SUSTech Energy Institute for Carbon Neutrality, Department of Mechanical and Energy Engineering, Southern University of Science and Technology, Shenzhen 518055, Guangdong, China 

4College of New Materials and New Energies, Shenzhen Technology University, Shenzhen 518118, Guangdong, China 5These authors contributed equally 6Lead contact *Correspondence: chenxh@sustech.edu.cn (X.C.), alexjen@cityu.edu.hk (A.K.-Y.J.), xu.zx@sustech.edu.cn (Z.-X.X.) https://doi.org/10.1016/j.joule.2024.05.005 

2124 Joule 8, 2123–2134, July 17, 2024 

**ll** 

##### Article 



Figure 1. Conjugated structures for improving the stability of SAM molecules 

(A and B) Chemical structures, frontier molecular orbitals with energy level diagram, electrostatic potential surfaces (EPSs), and dipole moment (m) of (A) Me-4PACz and (B) Me-PhpPACz. 

(C and D) Repeated CV trace (25 cycles) of (C) Me-4PACz and (D) Me-PhpPACz. 

(E and F)<sup>1</sup> H NMR spectra evolution of (E) Me-4PACz and (F) Me-PhpPACz. 

(G) Photographs of SAM materials solution before and after light aging. 

Table S2). The O 1s spectra of Me-4PACz and Me-PhpPACz powders showed two peaks at 533 and 532 eV, corresponding to P–O–H and P = O,<sup>15,16</sup> respectively (Figures 2A and 2B). The ITO O 1s spectrum had three fitting peaks at 531.77, 530.03, and 528.84 eV, representing surface oxygen vacancies, In–O, and Sn–O, respectively.<sup>10,17</sup> The O 1s spectra of SAM films on ITO displayed multiple fitting 

Joule 8, 2123–2134, July 17, 2024 2125 

**ll** 

Article 



Figure 2. Interaction between SAMs and ITO (A and B) O 1s XPS spectra are presented for bare ITO, powder, and films of (A) Me-4PACz and (B) Me-PhpPACz. 

(C) TEM images of SAMs with SnO2 particles. 

(D) Angular evolution of SAM molecules on ITO surface during AIMD simulations at 300 K, along with the final configurations of SAM molecules on ITO surface. 

(E) XPS mapping images of SAM molecules on ITO (In represents ITO, and N and P represent SAMs). 

(F and G) Conductive AFM images of (F) Me-4PACz and (G) Me-PhpPACz on ITO. 

2126 Joule 8, 2123–2134, July 17, 2024 

**ll** 

##### Article 

peaks. In the films, the peaks for P–O–H and P = O in the powder spectra disappeared, and new peaks emerged at 532.68 eV (Me-4PACz) and 532.64 eV (Me-PhpPACz), indicating P–O–In bond formation with ITO.<sup>18</sup> Furthermore, the P 2p spectra showed a decreased phosphorus binding energy in the SAM films (Figure S42). These findings are consistent with the Fourier-transform infrared spectroscopy (FTIR) results (Figure S43 and Note S1), confirming the tridentate anchoring of the PA groups on ITO. Static density functional theory (DFT) calculations (Figures S44 and S45 and Note S2) reveal high binding energies of around �1.80 eV for both SAM molecules on ITO, indicating strong chemical bonding between the PA groups and the ITO surface. However, the results from transmission electron microscopy (TEM) (Figures 2C, S45D, and S45E) emphasize the role of the linker in intermolecular interactions and backbone strength. Although Me-4PACz has high binding energy to SnO2, some Me-4PACz molecules do not anchor on SnO2. By contrast, Me-PhpPACz assembles densely on SnO2 particles, with no free MePhpPACz observed in vacant positions. This can be attributed to its rigid and conjugated backbone, reducing molecular twisting, and enhancing intermolecular interactions, which are not observed in Me-4PACz-based SAM. 

To explore the role of the rigid ring in Me-PhpPACz, ab initio molecular dynamics (AIMD) simulations were employed to analyze the dynamic behavior of SAM molecules on the ITO surface (Figure S46 and Note S3). Compared with Me-PhpPACz, the flexible linker in Me-4PACz led to twisting and bending toward the ITO substrate. Figure 2D illustrates the angular evolution of SAM molecules on the ITO surface during a 10 ps AIMD simulation at 300 K. The angle between the Cz group and the z axis was defined as the orientation of SAM molecules relative to the ITO surface. Due to the presence of the phenylene, Me-PhpPACz maintained a rigid assembly with an angle of <20<sup>�</sup> relative to the ITO surface. By contrast, Me-4PACz exhibited a twisted assembly on the ITO surface, with the Cz group nearly parallel to the ITO substrate. To experimentally verify this bending and twisting, X-ray reflectivity (XRR) measurements were performed on Me-4PACz and Me-PhpPACz thin films, revealing quite different SAM layer heights of 3.99 and 10.00 A<sup>˚</sup> , respectively. These values were consistent with the theoretically calculated molecular lengths obtained after AIMD simulations: 4.00 G 0.14 A<sup>˚</sup> for Me-4PACz and 10.58 G 0.23 A<sup>˚</sup> for MePhpPACz (Figure S47 and Note S4). After bending and twisting, molecules will have weaker dipole moments, affecting the alignments and uniformity of SAM. However, the rigid structure of Me-PhpPACz promotes uniform and denser molecular packing and enhanced dipole moments from 1.32 to 3.62 D. This is supported by the observations in Figures 2A and 2B and Table S3, where the Me-4PACz film showed more oxygen vacancies, indicating less interaction with ITO. Additionally, XPS mapping revealed weaker N and P intensities on the ITO surface for Me4PACz than those for Me-PhpPACz (Figure 2E). These observations suggest that Me-PhpPACz’s vertical alignment orientation leads to increased packing density on ITO. This is further confirmed by the quantitative analysis of SAMs on ITO through XPS full spectra and fine spectra of nitrogen, phosphorus, and indium, as well as the larger water contact angle of Me-PhpPACz compared with Me-4PACz (Figures S41, S48, and S49; Tables S2 and S4; and Notes S5 and S6). Furthermore, the influence of linking position is investigated by preparing the anchoring group at the m-position of the linking ring, Me-PhmPACz (Figures S50 and S51 and Note S3). This molecule also displays a lying-down molecular configuration. It is well established that denser molecular packing usually leads to smoother surfaces, and aligned packing will contribute to smaller potential differences. These observations are corroborated by our atomic force microscopy (AFM) measurements, with root mean square (RMS) roughness values for Me-4PACz and Me-PhpPACz on ITO amounting to 4.0 

Joule 8, 2123–2134, July 17, 2024 2127 

**ll** 

Article 

and 3.7 nm, respectively (Figure S52 and Note S7). The vertically arranged conjugated SAMs create a highly dense and ordered HSL substrate, which greatly facilitates the perovskite growth.<sup>19,20</sup> This is validated by the improved perovskite quality grown on Me-PhpPACz compared with Me-4PACz, evident by photo images, photoluminescence (PL) mapping, scanning electron microscope (SEM) images, and X-ray diffraction spectroscopy (Figures S53–S57 and Notes S8–S10). 

To explore the role of conjugated linkers on perovskite interactions, adsorption energies were calculated using DFT calculations (Figure S54 and Note S8). The results reveal that perovskite exhibits a higher adsorption affinity for Me-PhpPACz (�1.48 eV) compared with Me-4PACz (�0.23 eV). Improvement in carrier transport is also corroborated by conductive AFM (c-AFM). The maps of both SAMs on ITO are presented in Figures 2F and 2G, visualized through brightness contrast to assess their electrical performance. Compared with Me-4PACz, Me-PhpPACz exhibits higher brightness contrast at larger current values, with an average current of approximately 120 and 160 pA, indicating better charge-transport characteristics within the film. Me-PhpPACz leads to clearer ITO SEM images, suggesting enhanced HSL conductivity (Figure S53). As shown in Figure 3A, the increased dipole moment of Me-PhpPACz SAM must have a positive impact on their energy alignment and, thus, on hole extraction and transport. The spatial charge-limited current measurements revealed a slightly reduced trap state density (3.22 3 10<sup>15</sup> cm<sup>�3</sup> ) and an increased hole mobility (1.15 3 10<sup>�3</sup> cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> ) for Me-PhpPACz sample compared with Me-4PACz (ntrap = 3.68 3 10<sup>15</sup> cm<sup>�3</sup> and mh = 8.4 3 10<sup>�4</sup> cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> ) (Figure S58 and Note S11). 

The influence of dipole moment on energy levels, investigated using UV-vis spectroscopy and ultraviolet photoelectron spectroscopy (UPS) (Figures S59 and S60; Table S5 and Note S12), is schematically depicted in Figure 3B. The orientation of the dipole moment is crucial for achieving a beneficial modification of ITO’s WF, which can be effectively realized if the molecules are suitably organized. This is exemplified by Me-PhpPACz, which restricts bending and maintains a more perpendicular configuration, supported by a rigid linker. The WF of ITO/Me-PhpPACz (�4.65 eV) is notably deeper than the values measured for the bare ITO (�4.20 eV) and ITO/Me-4PACz (�4.55 eV), enabling it to be more efficient for hole extraction and further generating a potential barrier at the perovskite conduction band interface for electron injection. The SAMs also influence the energy level of perovskite. The WF of perovskite changes to be closer to the valence band, from �4.12 to �4.23 and �4.64 eV when deposited on ITO, Me-4PACz, and MePhpPACz, respectively, which can be more favorable for hole transport. Additionally, the energy offsets between the perovskite valence band edge and the WF are 1.53, 1.41, and 0.91 eV for ITO/PVK, ITO/Me-4PACz/PVK, and ITO/Me-PhpPACz/PVK, respectively. This suggests that the energy loss for hole extraction is minimal at the Me-PhpPACz/perovskite interface. The larger energy offset between the perovskite conduction band edge and the WF of ITO/Me-PhpPACz/PVK in comparison to ITO/PVK and ITO/Me-4PACz/PVK could provide better blocking of the electron injection from the perovskite, leading to reduced carrier recombination and enhanced fill factor (FF).<sup>21,22</sup> 

The introduction of a conjugated linker enhances the charge distribution, as shown by the charge density distributions between Me-PhpPACz and the perovskite, which span the entire interface. By contrast, Me-4PACz and the perovskite only exhibit prominent localized features (Figure S61). Furthermore, we noted an irregularly discontinuous charge distribution in the lower part of the alkyl linker region in the 

2128 Joule 8, 2123–2134, July 17, 2024 

**ll** 

##### Article 



Figure 3. Different linker groups in SAMs exhibit varied hole transport mechanisms (A) Molecular dipole moments of Me-4PACz and Me-PhpPACz, along with their dipole moments on ITO. 

(B) Schematic representation illustrating the influence of energy levels and dipole moments of ITO and perovskite films on charge carrier transport (EVA represents the vacuum energy level, EF is the Fermi level, WF is the work function, CB is the conduction band, and VB is the valence band). (C) ELF in the SAM molecular region on the perovskite surface. (D) Schematic illustration of ultrafast pump-probe transient absorption (TA) kinetics measurements and TA kinetics of perovskites excited with 1.65 eV at 10 3 17 cm<sup>�3</sup> carrier concentration. 

(E–G) Surface carrier kinetics from excitation at 2.48, 2.07, and 1.65 eV probed by transient reflection (TR) spectroscopy and fitted with a diffusionsurface extraction model for (E) perovskite, (F) Me-4PACz/perovskite, and (G) Me-PhpPACz/perovskite. 

Me-4PACz molecule, as evident from the electron localization function (ELF) diagram (Figure 3C). By contrast, the Me-PhpPACz molecule with a phenylene linker exhibits continuous charge distributions between the molecule and the perovskite surface. This facilitates photo-induced charge carriers more effective transport along the in-plane direction to the ITO. 

Ultrafast spectroscopic techniques are effective in probing the transport and recombination properties of charge carriers in PSCs.<sup>23,24</sup> As illustrated in Figure 3D, the concentration of bulk carriers shows negligible decay over a time scale of 5,000 ps, suggesting that the bulk carrier recombination process is insignificant. By globally fitting the carrier dynamics obtained from pump pulses of three wavelengths, we can derive carriers’ diffusion coefficients (D) and surface extraction velocities (S) (Figures 3E–3G 

Joule 8, 2123–2134, July 17, 2024 2129 

**ll** 

Article 



Figure 4. Photovoltaic performance of inverted perovskite solar cells 

(A) Device structure and the final configurations of multiple Me-4PACz and Me-PhpPACz molecules stacking on the ITO surface after a 10 ps AIMD simulation. 

(B) Cross-sectional SEM image of the Me-PhpPACz device. 

(C–G) Devices performance for (C) J-V curves of Me-4PACz and Me-PhpPACz-based PSCs (Data S1. JV data for the champion device based on Me-PhpPACz), (D) IPCE curves of Me-4PACz and Me-PhpPACz-based PSCs and integrated JSC over the AM 1.5G standard spectrum, (E) The device FF S-Q limit, consisting of charge-transport loss and non-radiative loss, (F) EQEEL of Me-4PACz and MePhpPACz-based PSCs in the range of 0.01– 2,000 mA/cm<sup>2</sup> and EL images, and (G) MPP tracking under N2 and simulated 1 sun AM 1.5G illumination for uncooled devices (reaching an operating temperature of 50<sup>�</sup> C G 10<sup>�</sup> C). 

and Note S13). The obtained data indicate that the diffusion coefficient of Me-4PACz is nearly four times higher than that of pure perovskite. Interestingly, the surface extraction velocities of Me-4PACz-based perovskite (190 G 270 cm/s) and bare perovskite (100 G 50 cm/s) are almost identical, suggesting that the presence of alkyl chains does not significantly improve surface extraction. By contrast, Me-PhpPACz exhibits significantly enhanced surface extraction velocity up to 2,230 G 380 cm/s compared with the control group, indicating a crucial role of the conjugated structure in the hole extraction process. These results are also consistent with steady PL and timeresolved PL (TRPL) measurements (Figure S62; Table S6; Note S14). 

The device structure and cross-sectional SEM images of the inverted PSCs are presented in Figures 4A, 4B, and S63. AIMD simulations reveal the microscopic stacking arrangement of multiple SAM molecules on the ITO surface. Tauc’s plot and the firstorder derivative of external quantum efficiency (EQE) suggest a perovskite band gap of �1.55 eV (Figure S64). The J–V curves and corresponding photovoltaic 

2130 Joule 8, 2123–2134, July 17, 2024 

**ll** 

##### Article 

parameters for Me-4PACz- and Me-PhpPACz-based champion PSCs are shown in Figure 4C and Table S7. The FF improves from 81.30% for Me-4PACz to 86.79% for Me-PhpPACz. Me-4PACz achieves a champion PCE of 24.14%, while MePhpPACz reaches 26.17% (as shown in Figure S65, the certified PCEs were 25.82% with a steady-state efficiency of 25.18% from the Shanghai Institute of Microsystem and Information Technology (SIMIT) and 26.12% with a steady-state efficiency of 24.81% from the National PV Industry Measurement and Testing Center (NPVM), respectively.) for the reverse scan. This enhancement is consistent with the photovoltaic average parameters of 30 devices (Figure S66). The EQE results indicate that the integrated currents of Me-4PACz and Me-PhpPACz are similar, measuring 24.70 and 25.02 mA/cm<sup>2</sup> , respectively (Figure 4D). Under AM 1.5G simulated solar irradiation in an N2 glovebox, both Me-4PACz and Me-PhpPACz devices exhibit excellent stable continuous output performance after 60 min of steady-state testing. The PCE values decrease from the initial values of 24.06% and 26.05% to 23.75% and 25.87%, respectively (Figure S67). 

The Me-PhpPACz-based devices demonstrated enhanced performance characteristics, induced by a reduced ideality factor (nID), increased carrier migration, and minimized resistance, as determined by various characterization methods such as light intensity-dependent measurements of short circuit current density (JSC) and open circuit voltage (VOC), electrochemical impedance spectroscopy (EIS), MottSchottky plot analysis, transient photocurrent (TPC), and photovoltage (TPV) (Figures S68–S71 and Notes S15–S18). The two main reasons for FF values below the S-Q limit are trap-assisted non-radiative losses and charge-transport losses. According to nID calculations, the maximum FF (FFmax) for Me-4PACz and Me-PhpPACz is found to be 84.66% and 88.15%, respectively (Figure 4E).<sup>25,26</sup> This finding corroborates the notion that using Me-PhpPACz as HSL at the bottom interface can effectively suppress trap-assisted non-radiative recombination and improve chargetransport within the device.<sup>27,28</sup> 

The PSC based on Me-PhpPACz demonstrates superior performance in the external quantum efficiency for electroluminescence (EQEEL), exhibiting higher electroluminescence (EL) emission intensity, which indicates a higher level of carrier injection (Figure S72 and Note S19).<sup>29</sup> The EQEEL values for Me-4PACz-based and MePhpPACz-based PSCs are 3.23% and 4.65%, respectively (Figure 4F). Analogous to the EQEEL results, employing PL quantum yield (PLQY) in semi-stacked and full-stacked devices to estimate quasi-Fermi level splitting (QFLS) reveals higher quantum yield and increased QFLS for Me-PhpPACz (Figure S72D), suggesting that optimized bottom interface energy level alignment not only reduces perovskite defects but also minimizes interface non-radiative recombination losses. In accordance with the ISOS-L-1I standard protocol,<sup>30</sup> the performance of unencapsulated PSCs was tracked at the maximum power point (MPP) under continuous illumination in a cyclic nitrogen environment at 50<sup>�</sup> C G 10<sup>�</sup> C. After more than 3,100 h of continuous exposure, the PSC based on Me-PhpPACz retained 98.70% of its initial PCE, whereas the PSC based on Me-4PACz dropped to 74.07% during the same period (Figure 4G). Additionally, further thermal stability assessments of the encapsulated devices, aged at 85<sup>�</sup> C in ambient air (RH 75% G 15%) and subjected to MPP tracking under continuous 1 sun equivalent LED illumination in ambient air (RH 70% G 20%) at an operating temperature of 65<sup>�</sup> C G 10<sup>�</sup> C, also validate the enhanced stability of Me-PhpPACz (Figure S73). 

In terms of the versatility of SAMs with conjugated linkers, the choice of NiOX as the substrate for Me-PhpPACz in the ITO/NiOX/SAM/PVK/C60/BCP/Cu-based PSCs 

Joule 8, 2123–2134, July 17, 2024 2131 

**ll** 

Article 

structure led to a higher PCE of 25.72%, surpassing Me-4PACz (23.98%) (Figure S74A). Altering the position of the PA anchoring group on the phenylene linker resulted in a PCE of 25.51% for the m-substituted Me-PhmPACz (Figure S74B), which is also higher than Me-4PACz with non-conjugated linker. Examining the influence of the Cz terminal group in SAMs, PhpPACz was synthesized and compared with 4PACz, leading to an efficiency increase from 23.68% to 24.85% (Figure S74C). Furthermore, MeO-PhpPACz demonstrated an increase in PCE from 22.78% to 25.21%, outperforming MeO-4PACz (Figure S74D). Expanding the research to different perovskite compositions, the conjugated linker-based SAM of MeO-PhpPACz was incorporated into wide-band-gap perovskites with a composition of Cs0.2FA0.8PbI1.8Br1.2 (Figure S75), achieving a PCE of 20.08% with a higher VOC of 1.302 V, which is superior to that of MeO-4PACz (PCE of 18.67% and VOC of 1.268 V). These findings emphasize the adaptability of conjugated linker optimization for SAMs in PSCs. 

###### Conclusions 

In this study, we designed and synthesized a SAM material, Me-PhpPACz, which is based on Cz terminal and PA anchoring groups connected by a conjugated phenylene linker. This material was then applied to the HSL of inverted PSCs. The experimental and theoretical simulation results showed that compared with Me-4PACz, which uses butyl chains as a linker, Me-PhpPACz molecules exhibit higher photoelectric stability and are less susceptible to bending and folding during molecular assembly. This facilitates the formation of a high-density, well-ordered SAM film. As a result, the WF of ITO electrodes is better regulated, and the quality of the perovskite thin film is improved. Ultrafast spectroscopic experiments revealed that Me-PhpPACz-based devices exhibit a more compatible energy level alignment, enhanced device hole extraction, and transport efficiency, effectively reduce interface carrier non-radiative recombination, and achieve a FFmax of up to 86.79%. The average efficiency of the Me-PhpPACz PSCs device reached 25.82% G 0.35%, surpassing the 23.69% G 0.45% of the Me-4PACz device, and the device stability was significantly improved. Moreover, this generalizable molecular design strategy using a conjugated linker can also be applied to different Cz-based SAM molecules, yielding higher device performance compared with non-conjugated alkyl chain-connected SAM molecules. 

###### EXPERIMENTAL PROCEDURES 

###### Resource availability 

Lead contact 

Further information should be directed to the lead contact, Zong-Xiang Xu (xu.zx@ sustech.edu.cn). 

###### Materials availability 

All the experimental procedures of the material synthesis are provided in the supplemental information. 

Data and code availability 

- All data needed to evaluate the conclusions in the paper are present in the paper or the supplemental information. 

- All the data are available from the corresponding authors upon reasonable request. 

###### SUPPLEMENTAL INFORMATION 

Supplemental information can be found online at https://doi.org/10.1016/j.joule. 2024.05.005. 

2132 Joule 8, 2123–2134, July 17, 2024 

**ll** 

##### Article 

###### ACKNOWLEDGMENTS 

This work was supported by the National Key Research and Development Project of the Ministry of Science and Technology of China (no. 2021YFB3800103), the National Natural Science Foundation of China (no. 21975116), the Natural Science Foundation of Guangdong Province (2023A1515011145), the Shenzhen-Hong Kong-Macau Science and Technology Plan C (no. SGDX20210823104205034), the Shenzhen Science and Technology Innovation Commission (20231115141039001, JCYJ20220530114809022, and DSYS20220527171403009), the Guangdong Provincial University Science and Technology Program (grant no. 2023KTSCX119), and the Guangdong Major Project of Basic and Applied Basic Research (2023B0303000002). A.K.-Y.J. thanks the sponsorship of the Lee Shau-Kee Chair Professor (Materials Science), the TCFS grant (GHP/018/20SZ) and MRP grant (MRP/040/21X) from the Innovation and Technology Commission of Hong Kong, and the GRF grants (11307621 and 11316422) from the Research Grants Council of Hong Kong. The authors acknowledge the assistance provided by the SUSTech Core Research Facilities. 

###### AUTHOR CONTRIBUTIONS 

Z.-X.X., G.Q., and S.C. conceived and designed the research. G.Q. and D.W. carried out the fabrication and major characterization of PSCs. S.C. synthesized and characterized the SAM molecules. L.Z. contributed to the material synthesis. Y.Q. and Q.C. conducted theoretical simulations. D.W. optimized perovskite components and device structure. G.Q. carried out the fabrication and major characterization of WBG PSCs. K.J. conducted the encapsulation of the devices. S.G. and X.C. performed ultrafast spectroscopic measurements. Y.-G.W. performed PL mapping and TEM measurements. D.K., X.C., and A.K.-Y.J. contributed to the analysis and provided advice. G.Q., Y.Q., S.C., and Z.-X.X. wrote the initial draft, and all authors contributed to the final paper. 

###### DECLARATION OF INTERESTS 

The authors declare no competing interests. 

Received: November 26, 2023 Revised: January 4, 2024 Accepted: May 9, 2024 Published: May 30, 2024 

###### REFERENCES 

1. National Renewable Energy Laboratory. Best Research-Cell Efficiency Chart. https://www. nrel.gov/pv/cell-efficiency.html. 

2. Luo, C., Zheng, G., Gao, F., Wang, X., Zhan, C., Gao, X., and Zhao, Q. (2023). Engineering the buried interface in perovskite solar cells via lattice-matched electron transport layer. Nat. Photon. 17, 856–864. https://doi.org/10.1038/ s41566-023-01247-4. 

3. Schulz, P., Cahen, D., and Kahn, A. (2019). Halide Perovskites: Is It All about the Interfaces? Chem. Rev. 119, 3349–3417. https:// doi.org/10.1021/acs.chemrev.8b00558. 

4. Li, M., Xie, Y., Lin, F.R., Li, Z., Yang, S., and Jen, A.K.-Y. (2023). Self-assembled monolayers as emerging hole-selective layers enable highperformance thin-film solar cells. Innovation 

(Camb) 4, 100369. https://doi.org/10.1016/j. xinn.2022.100369. 

5. Ambrosio, F., Martsinovich, N., and Troisi, A. (2012). What Is the Best Anchoring Group for a Dye in a Dye-Sensitized Solar Cell? J. Phys. Chem. Lett. 3, 1531–1535. https://doi.org/10. 1021/jz300520p. 

6. Guo, R., Zhang, X., Zheng, X., Li, L., Li, M., Zhao, Y., Zhang, S., Luo, L., You, S., Li, W., et al. (2023). Tailoring Multifunctional Self-Assembled Hole Transporting Molecules for Highly Efficient and Stable Inverted Perovskite Solar Cells. Adv. Funct. Materials 33, 2211955. https://doi.org/ 10.1002/adfm.202211955. 

7. Ali, F., Rolda´n-Carmona, C., Sohail, M., and Nazeeruddin, M.K. (2020). Applications of SelfAssembled Monolayers for Perovskite Solar 

Cells Interface Engineering to Address Efficiency and Stability. Adv. Energy Mater. 10, 2002989. https://doi.org/10.1002/aenm. 202002989. 

8. Zheng, X., Li, Z., Zhang, Y., Chen, M., Liu, T., Xiao, C., Gao, D., Patel, J.B., Kuciauskas, D., Magomedov, A., et al. (2023). Co-deposition of hole-selective contact and absorber for improving the processability of perovskite solar cells. Nat. Energy 8, 462–472. https://doi. org/10.1038/s41560-023-01227-6. 

9. Ren, Z., Cui, Z., Shi, X., Wang, L., Dou, Y., Wang, F., Lin, H., Yan, H., and Chen, S. (2023). Poly(carbazole phosphonic acid) as a versatile hole-transporting material for p-i-n perovskite solar cells and modules. Joule 7, 2894–2904. https://doi.org/10.1016/j.joule. 2023.10.014. 

Joule 8, 2123–2134, July 17, 2024 2133 

#### **ll** 

##### Article 

10. Timpel, M., Nardi, M.V., Krause, S., Ligorio, G., Christodoulou, C., Pasquali, L., Giglia, A., Frisch, J., Wegner, B., Moras, P., and Koch, N. (2014). Surface Modification of ZnO(0001)–Zn with Phosphonate-Based Self-Assembled Monolayers: Binding Modes, Orientation, and Work Function. Chem. Mater. 26, 5042–5050. https://doi.org/10.1021/cm502171m. 

11. Li, C., Zhang, Z., Zhang, H., Yan, W., Li, Y., Liang, L., Yu, W., Yu, X., Wang, Y., Yang, Y., et al. (2024). Fully aromatic self-assembled hole-selective layer toward efficient inverted wide-bandgap perovskite solar cells with ultraviolet resistance. Angew. Chem. Int. Ed. Engl. 63, e202315281. https://doi.org/10.1002/ anie.202315281. 

12. Zhang, S., Wu, R., Mu, C., Wang, Y., Han, L., Wu, Y., and Zhu, W.-H. (2022). Conjugated SelfAssembled Monolayer as Stable Hole-Selective Contact for Inverted Perovskite Solar Cells. ACS Materials. Lett. 4, 1976–1983. https://doi.org/10. 1021/acsmaterialslett.2c00799. 

13. Kapil, G., Bessho, T., Sanehira, Y., Sahamir, S.R., Chen, M., Baranwal, A.K., Liu, D., Sono, Y., Hirotani, D., Nomura, D., et al. (2022). Tin–Lead Perovskite Solar Cells Fabricated on Hole Selective Monolayers. ACS Energy Lett. 7, 966–974. https://doi.org/10.1021/ acsenergylett.1c02718. 

14. Li, E., Bi, E., Wu, Y., Zhang, W., Li, L., Chen, H., Han, L., Tian, H., and Zhu, W.-H. (2020). Synergistic Coassembly of Highly Wettable and Uniform Hole-Extraction Monolayers for Scaling-up Perovskite Solar Cells. Adv. Funct. Materials 30, 1909509. https://doi.org/10.1002/ adfm.201909509. 

15. Qi, H., Zhang, H., Wu, X., Tang, Y., Qian, M., Wang, K., and Qi, H. (2020). Matrix-Free and Highly Efficient Room-Temperature Phosphorescence Carbon Dots towards Information Encryption and Decryption. Chem. Asian J. 15, 1281–1284. https://doi.org/10. 1002/asia.202000063. 

16. Thermo Fisher Scientific. Oxygen | XPS Periodic Table – CN. https://www. thermofisher.cn/cn/zh/home/materials- 

   - science/learning-center/periodic-table/nonmetal/oxygen.html.. 

- science/learning-center/periodic-table/non24. Gong, S., Huang, Y., Yu, X., Hu, Q., Liu, J., metal/oxygen.html.. Meng, J., Wen, Y., and Chen, X. (2023). Ultrafast dynamics in perovskite-based optoelectronic 

- 17. Paramonov, P.B., Paniagua, S.A., Hotchkiss, P.J., devices. Cell Reports Physical Science 4, Jones, S.C., Armstrong, N.R., Marder, S.R., and 101580. https://doi.org/10.1016/j.xcrp.2023. Bre´das, J.-L. (2008). Theoretical Characterization 101580. of the Indium Tin Oxide Surface and of Its Binding Sites for Adsorption of Phosphonic Acid 25. Wang, J., Zhang, J., Zhou, Y., Liu, H., Xue, Q., Li, Monolayers. Chem. Mater. 20, 5131–5133. X., Chueh, C.-C., Yip, H.-L., Zhu, Z., and Jen, https://doi.org/10.1021/cm8014622. A.K.Y. (2020). Highly efficient all-inorganic 

      25. Wang, J., Zhang, J., Zhou, Y., Liu, H., Xue, Q., Li, X., Chueh, C.-C., Yip, H.-L., Zhu, Z., and Jen, A.K.Y. (2020). Highly efficient all-inorganic perovskite solar cells with suppressed nonradiative recombination by a Lewis base. Nat. Commun. 11, 177. https://doi.org/10.1038/ s41467-019-13909-5. 

18. Puziy, A.M., Poddubnaya, O.I., Socha, R.P., Gurgul, J., and Wisniewski, M. (2008). XPS and NMR studies of phosphoric acid activated carbons. Carbon 46, 2113–2123. https://doi. org/10.1016/j.carbon.2008.09.010. 

   26. Green, M.A. (1982). Accuracy of analytical expressions for solar cell fill factors. Sol. Cells 7, 337–340. https://doi.org/10.1016/03796787(82)90057-6. 

19. Li, Z., Sun, X., Zheng, X., Li, B., Gao, D., Zhang, S., Wu, X., Li, S., Gong, J., Luther, J.M., et al. (2023). Stabilized hole-selective layer for highperformance inverted p-i-n perovskite solar cells. Science 382, 284–289. https://doi.org/10. 1126/science.ade9637. 

   27. Li, X., Wu, X., Li, B., Cen, Z., Shang, Y., Lian, W., Cao, R., Jia, L., Li, Z., Gao, D., et al. (2022). Modulating the deep-level defects and charge extraction for efficient perovskite solar cells with high fill factor over 86%. Energy Environ. Sci. 15, 4813–4822. https://doi.org/10.1039/ D2EE02543D. 

20. Liu, M., Bi, L., Jiang, W., Zeng, Z., Tsang, S.-W., Lin, F.R., and Jen, A.K.-Y. (2023). Compact Hole-Selective Self-Assembled Monolayers Enabled by Disassembling Micelles in Solution for Efficient Perovskite Solar Cells. Adv. Mater. 35, e2304415. https://doi.org/10.1002/adma. 202304415. 

   28. Cao, Q., Li, Y., Zhang, H., Yang, J., Han, J., Xu, T., Wang, S., Wang, Z., Gao, B., Zhao, J., et al. (2021). Efficient and stable inverted perovskite solar cells with very high fill factors via incorporation of star-shaped polymer. Sci. Adv. 7, eabg0633. https://doi.org/10.1126/sciadv. abg0633. 

21. Cui, P., Wei, D., Ji, J., Huang, H., Jia, E., Dou, S., Wang, T., Wang, W., and Li, M. (2019). Planar p–n homojunction perovskite solar cells with efficiency exceeding 21.3%. Nat. Energy 4, 150–159. https://doi.org/10.1038/s41560-0180324-8. 

   29. Rai, M., Wong, L.H., and Etgar, L. (2020). Effect of Perovskite Thickness on Electroluminescence and Solar Cell Conversion Efficiency. J. Phys. Chem. Lett. 11, 8189–8194. https://doi.org/10.1021/acs.jpclett. 0c02363. 

22. Wang, Q., Shao, Y., Xie, H., Lyu, L., Liu, X., Gao, Y., and Huang, J. (2014). Qualifying composition dependent p and n self-doping in CH3NH3PbI3. Appl. Phys. Lett. 105, 163508. https://doi.org/10.1063/1.4899051. 

   30. Khenkin, M.V., Katz, E.A., Abate, A., Bardizza, G., Berry, J.J., Brabec, C., Brunetti, F., Bulovi�c, V., Burlingame, Q., Di Carlo, A., et al. (2020). Consensus statement for stability assessment and reporting for perovskite photovoltaics based on ISOS procedures. Nat. Energy 5, 35–49. https://doi.org/10.1038/s41560-0190529-5. 

23. Qu, G., Dong, L., Qiao, Y., Khan, D., Chen, Q., Xie, P., Yu, X., Liu, X., Wang, Y., Chen, J., et al. (2022). Dopant-Free Phthalocyanine Hole Conductor with Thermal-Induced Holistic Passivation for Stable Perovskite Solar Cells with 23% Efficiency. Adv. Funct. Materials 32, 2206585. https://doi.org/10.1002/adfm. 202206585. 

2134 Joule 8, 2123–2134, July 17, 2024 

