# Metastable Dion-Jacobson 2D structure enables efficient and stable perovskite solar cells

| 字段 | 内容 |
|---|---|
| 期刊 | Science |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 359 |
| 作者 | Fei Zhang, So Yeon Park, Canglang Yao, Hai-Feng Lu, Sean P. Dunfield, C. Xiao, Soňa Uličná, Xiaoming Zhao et al. |
| DOI | 10.1126/science.abj2637 |
| 源文件 | 041_Zhang_2021_Metastable-Dion-Jacobson-2D-structure-enables-ef.pdf |

---
# **Metastable Dion-Jacobson 2D structure enables efficient and stable perovskite solar cells** 

Fei Zhang,<sup>1†*</sup> So Yeon Park,<sup>1†</sup> Canglang Yao,<sup>2†</sup> Haipeng Lu,<sup>1,</sup> Sean P. Dunfield,<sup>3,4,5</sup> Chuanxiao Xiao,<sup>3</sup> Soňa Uličná,<sup>6</sup> Xiaoming Zhao,<sup>7</sup> Linze Du Hill,<sup>8</sup> Xihan Chen,<sup>1</sup> Xiaoming Wang,<sup>2</sup> Laura E. Mundt,<sup>6</sup> Kevin H. Stone,<sup>6</sup> Laura T. Schelhas,<sup>1,6</sup> Glenn Teeter,<sup>3</sup> Sean Parkin,<sup>9</sup> Erin L. Ratcliff,<sup>8,10,11</sup> Yueh-Lin Loo,<sup>7</sup> Joseph J. Berry,<sup>3,4,12</sup> Matthew C. Beard,<sup>1</sup> Yanfa Yan,<sup>2*</sup> Bryon W. Larson,<sup>1*</sup> Kai Zhu<sup>1*</sup> 

- 1 Chemistry and Nanoscience Center, National Renewable Energy Laboratory, Golden, CO 80401, USA. 

- 2 Department of Physics and Astronomy, and Wright Center for Photovoltaics Innovation and Commercialization, University of Toledo, Toledo, Ohio 43606, USA. 

- 3 Materials Science Center, National Renewable Energy Laboratory, Golden, CO 80401, USA. 

- 4 Renewable and Sustainable Energy Institute, University of Colorado, Boulder, CO 80309, USA. 

- 5 Materials Science and Engineering Program, University of Colorado, Boulder, CO 80309, USA. 

- 6 SLAC National Accelerator Laboratory, Menlo Park, California 94025, USA. 

- 7 Department of Chemical and Biological Engineering, Princeton University, Princeton, NJ 08544, USA. 

- 8 Department of Chemical and Environmental Engineering, University of Arizona, Tucson, AZ 85721, USA. 

- 9 Department of Chemistry, University of Kentucky, Lexington, KY 40506, USA 

- 10 Department of Chemistry and Biochemistry, University of Arizona, Tucson, AZ 85721, USA. 

- 11 Department of Materials Science and Engineering, University of Arizona, Tucson, AZ 85721, USA. 

- 12 Department of Physics, University of Colorado, Boulder, CO 80309, USA. 

- Corresponding authors. Fei.Zhang@nrel.gov (F.Z.); Yanfa.Yan@utoledo.edu (Y.Y.); 

- Bryon.Larson@nrel.gov (B.W.L.); Kai.Zhu@nrel.gov (K.Z.) 

- These three authors contributed equally to this work. 

1 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

## **Abstract:** 

The performance of three-dimensional (3D) organic-inorganic halide perovskite solar cells (PSCs) can be enhanced by surface treatment with 2D layered perovskites that have efficient charge transport. We maximized hole transport across the layers of a metastable Dion-Jacobson (DJ) 2D perovskite that tuned the orientational arrangements of asymmetric bulky organic molecules. The reduced energy barrier for hole transport increased out-of-plane transport rates by a factor of 4 to 5, and the power conversion efficiency (PCE) for the n=1 2D PSC was 4.9%. With the metastable DJ 2D surface layer, the PCE of three common 3D PSCs was enhanced by ~12–16% and could reach ~24.7%. For a triple-cation-mixed-halide PSC, 90% of the initial PCE was retained after 1000-h of 1-sun operation at ~40  C in N2. 

## **One-Sentence Summary:** 

Metastable Dion-Jacobson 2D perovskite surface layer based on asymmetric bulky organic molecules reduced the energy barrier for hole transport, leading to highly efficient and stable perovskite solar cells. 

2 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

## **Main Text:** 

Perovskite solar cells (PSCs) are a promising photovoltaic (PV) technology and certified power conversion efficiencies (PCEs) as high as 25.5% have been reported ( _1_ ). Despite this high performance, device stability hinders their commercialization. Efforts to improve device stability include defect passivation, contact layer modification, and encapsulation ( _2-5_ ). The use of twodimensional (2D) perovskite as the interfacial modification layer has great potential for addressing surface defects, in particular to improve the stability and efficiency of PSCs ( _6-8_ ). The Ruddlesden-Popper (RP) 2D layered perovskites that are based on bulky cations, such as phenethylammonium (PEA<sup>+</sup> ) or butylammonium (BA<sup>+</sup> ), have been widely applied to the surface of 3D perovskite thin films to decrease defect densities and enhance device stability ( _8-11_ ). Such bulky organic cations often self-assemble into a barrier layer that protects against surface water adsorption or ingress. However, bulky-cation-based 2D structures often exhibit anisotropic and poor charge transport across the organic layer and are susceptible to charge-extraction barrier formation that inhibits efficient device operation ( _12-14_ ). 

We show a rational design strategy to maximize the out-of-plane hole transport based on a metastable Dion-Jacobson (DJ) 2D perovskite surface layer with a reduced transport energy barrier by using asymmetric bulky organic molecules, leading to highly efficient and stable perovskite solar cells. Our general design strategy to maximize the out-of-plane charge transport in 2D perovskites is illustrated in Fig. 1. Because the free electrons and holes are localized in the conduction band minimum (CBM) and valence band maximum (VBM) of the [PbI6] planes, respectively, and due to the long distance between two adjacent [PbI6] planes, the out-of-plane charge transport must traverse the bulky cationic organic layers. Thus, it is mainly limited by two factors: (i) the low carrier mobility within the organic layer; and (ii) the energy barrier between the [PbI6] planes and the bulky organic cations. To mitigate the first limit, DJ 2D structures based on a short and single layer of divalent organoammonium cations ( _15-18_ ) are generally more preferable than the RP 2D structures based on double layers of monovalent organoammonium cations ( _19_ ). To mitigate the second limiting factor, the band offsets between the [PbI6] planes and the bulky cationic organic layers need to be optimized. 

3 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 



**Figure 1** . **Design concept.** ( **A** ) Illustration of band offsets between [PbI6] planes and bulky organic cations with a weaker and stronger degree of H-bonding. For clarity, the inorganic framework orbital diagram is omitted in the middle of the panel. ( **B** ) Two possible arrangements of asymmetric DMePDA<sup>2+</sup> cations and the sole arrangement of symmetric BDA<sup>2+</sup> cations. ( **C** ) HSE+vdW calculated total DOSs of the organic cations in BDAPbI4, DMePDAPbI4-1 (with orientation-1 in (B)), and DMePDAPbI4-2 (with orientation-2 in (B)). The VBMs were set to 0.0 eV. 

The coupling (interaction) between [PbI6] planes and the organic cations is through hydrogen bonding, and the change in the bonding strength can affect the band offsets ( _20_ ). For a weaker hydrogen bonding configuration, the bonding states of the bulky organic layers are normally at higher energy position which brings them nearer the VBM of the [PbI6] planes (Fig. 1A). This effect leads to a smaller band offset or barrier for hole transport between the [PbI6] inorganic planes and organic cations. Because of the spin-orbital coupling of Pb 6p orbitals, the antibonding states of the organic layers are much higher than the CBM of the [PbI6] planes. Thus, a DJ structure with weaker hydrogen bonding should improve hole transport. Yet, a weaker hydrogen bonding (or H-bonding) configuration generally means a less stable structure. Thus, a 

4 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

metastable DJ 2D structure with short cationic organic layers could in principle facilitate out-ofplane hole transport. 

A rational strategy to induce the desired metastable H-bonding motifs in DJ 2D structures is to use asymmetric diammonium cations in lieu of symmetric straight chain divalent cations. For example, both _N,N_ -dimethyl-1,3-propane diammonium (DMePDA<sup>2+</sup> ) and 1,4-butane diammonium (BDA<sup>2+</sup> ) form DJ 2D structures with short interlayer distances ( _19_ ). Whereas BDA<sup>2+</sup> is symmetric and features two terminal primary ammonium ions on the butyl (C4) chain, DMePDA<sup>2+</sup> is asymmetric with a primary ammonium on one end and a dimethyl-substituted tertiary ammonium on the other end of the propyl (C3) chain. The “head or tail” H-bonding options for the DMePDA<sup>2+</sup> molecules are asymmetric, giving rise to different possible relative orientations of the adjacent molecules, and the different H-bonding interactions possible within the [PbI6] planes could lead to both stable and metastable energy polymorphs of the 2D structure (see Fig. 1B). The alternating relative head-to-tail alignment of adjacent DMePDA<sup>2+</sup> cations (most stable orientation configuration) provides a larger compensation for overall structural relaxation than other orientation arrangements. In contrast, the symmetric BDA<sup>2+</sup> molecule has only one possible orientation configuration (Fig. 1B) and cannot form metastable polymorphs. 

We further examined single-crystal 2D DJ structures from BDAI2 and DMePDAI2 and conducted first-principle calculations to verify our design strategy. We found that 1,3-propane diammonium diiodine (PDAI2) ⎯ which is often assumed the shortest diamine ( _15, 21_ ) to form DJ 2D perovskites ⎯ templated Pb-I to a non-perovskite structure (empirical formula: [PDAPbI4]15•[PDAI2]) (Figure S1 and Table S1). Thus, BDA<sup>2+</sup> represents the shortest linear-alkylchain diamine that forms an iodide-based 2D DJ structure (BDAPbI4; Figure S2A and Table S2). Interestingly, C3-based DMePDAI2 with two methyl groups attached to one side of PDA can form 2D DJ structures with two polymorphs, which we refer to as DMePDAPbI4-1 (Figure S2B and Table S3) and DMePDAPbI4-2 (Figure S2C; ( _22_ )), respectively. 

We grew the DMePDAPbI4-1 single crystal, based on the most stable DMePDA<sup>2+</sup> orientation alignment, from a concentrated hydroiodic acid solution using a slow-crystallization process as adapted from our previous report ( _23_ ) and is consistent with a previous theoretical predication ( _24_ ). In contrast, the DMePDAPbI4-2 single crystal, based on a metastable orientational alignment, was formed from either a fast cooling ( _22_ ) or antisolvent quenching during 

5 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

single-crystal growth ( _25_ ), both of which represent a fast-crystallization process. In comparison to DMePDAPbI4-1, DMePDAPbI4-2 had an emission wavelength that was ~25-nm red-shifted, which is consistent with the corresponding absorption data (Figure S3). The average interlayer distances were comparable among these 2D structures (~10.10 to 10.39 Å), with that of BDAPbI4 being the shortest. The corresponding hydrogen-bonding configurations for these three singlecrystal structures (Figures S4, S5, and S6) were consistent with the analysis in Fig. 1B. 

Our design strategy was confirmed by density functional theory (DFT) calculation. The effect of organic molecules was calculated by using the screened hybrid functional and van der Waals (vdW) interaction (HSE+vdW) ( _26, 27_ ). The DMePDAPbI4-2 structure was indeed less stable than the DMePDAPbI4-1 structure. The energy level differences of the organic cations in BDAPbI4, DMePDAPbI4-1, and DMePDAPbI4-2 could be seen in the total density of states (DOSs) of the organic cations (the sum of states of C, N, and H atoms, Fig. 1C). The total DOS of BDA<sup>2+</sup> cations in BDAPbI4 was lower in energy (farther from VBM) than that of DMePDA<sup>2+</sup> cations in DMePDAPbI4-1, which in turn was lower in energy compared with the total DOS of DMePDA<sup>2+</sup> cations in DMePDAPbI4-2. Thus, we expected the out-of-plane hole transport to improve from BDAPbI4 to DMePDAPbI4-2. 

6 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 



**Figure 2. 2D thin film structure, transport, and device characteristics.** ( **A** ) X-ray diffraction (XRD) patterns of a solution grown DMePDAPbI4 thin film and the powder XRD patterns (measured and calculated) from DMePDAPbI4-1 and DMePDAPbI4-2 single-crystal structures. X- ray source: Cu K  radiation. Peaks labeled with “*” are from the fluorine tin oxide (FTO) substrates. ( **B** ) Energy profile along the transition path between DMePDAPbI4-1 and DMePDAPbI4-2. ( **C** ) TRMC comparison of out-of-plane charge transport across the layers of n=1 2D perovskites. ( **D** ) J–V characteristics of PSCs based on n=1 2D perovskite thin films using a device stack of glass/FTO/compact-TiO2/2D-perovskite/2,2',7,7'-Tetrakis[N,N-di(4methoxyphenyl)amino]-9,9'-spirobifluorene (spiro-OMeTAD)/Au. 

Rapid perovskite film growth conditions from standard solution deposition also led to the formation of the metastable DMePDAPbI4-2 structure. Figure 2A shows the XRD patterns of the DMePDAPbI4 thin film prepared by spin coating. The powder XRD pattern measured from DMePDAPbI4-1 and DMePDAPbI4-2 single-crystal samples, along with the calculated powder XRD patterns are shown for comparison, revealed the differences of XRD patterns between these two single crystals. The XRD pattern of the thin-film sample matched that of the DMePDAPbI4-2 

7 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

structure. Note that a metastable polymorph does not mean it is unstable under synthetic or ambient conditions. The phase transformation between polymorphs requires 180° rotation of the alkyl chain, which is highly energetically unfavorable (Fig. 2B) (Figures S7 and S8). A wide range of thin-film growth conditions from solution all formed DMePDAPbI4-2 thin films (Figure S9). 

To test our hypothesis that the reduced energy barrier from the asymmetric bulky organic cation layer could facilitate charge transport between inorganic [PbI6] sheets, we conducted timeresolved microwave conductivity (TRMC) measurements along the out-of-plane direction ( _28_ ). Figure 2C compares the normalized TRMC results between several n=1 2D perovskite thin films calibrated by their corresponding internal quantum yield of charges measured in devices. The outof-plane transport for DMePDAPbI4 (or more specifically DMePDAPbI4-2) is about a factor of 4 to 5 faster than that of BDAPbI4 despite the slightly longer interlayer distance. Space-chargelimited current (SCLC) measurements further verified that the DMePDAPbI4-2 structure had faster out-of-plane hole transport than the DMePDAPbI4-1 structure (Figure S10). These results confirmed the role of reducing the energy barrier for improving out-of-plane charge transport. Note that the out-of-plane transport for the two 2D DJ structures (DMePDAPbI4 and BDAPbI4) was faster than those of the two 2D RP structures (BA2PbI4 and PEA2PbI4). These TRMC results were consistent with the current density-voltage ( _J_ – _V_ ) results of PSCs based on the corresponding n=1 2D structures (Fig. 2D and Table S4). The DMePDAPbI4-based PSC reached a PCE of 4.90% (forward scan) and 4.33% (reverse scan), which is among the highest obtained thus far for any n=1 2D lead-iodide-based PSCs ( _6_ ); the corresponding EQE spectrum is shown in Figure S11. 

8 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 



**Figure 3. Surface layer treatment.** ( **A** ) Comparison of grazing incident XRD (GIXRD) patterns of thin films of DMePDAPbI4 and perovskites without (control PVK) and with DMePDAI2 surface treatment (PVK/DMePDAI2). The inset shows the zoom-in view of the GIXRD pattern from 7  to 10  . The peak labeled with “*” is from the FTO substrate. X-ray source: Cu K  radiation. ( **B** to **E** ) Comparison of the <mark>XPS spectra of N1s and C1s</mark> for the control (B and C) and the DMePDAI2modified (D and E) perovskite thin film. 

The use of 2D systems to passivate defects and enhance performance has recently been used in many poly-crystalline PV technologies ( _29_ ). We validated the impact of this metastable design motif with the use of DMePDAPbI4 as a surface layer to improve the quality of 3D perovskite absorbers. We spin coated the corresponding bulky organic halide salt in isopropanol (IPA) solution on top of a 3D perovskite absorber layer ( _6_ ). Specifically, the DMePDAI2/IPA solution was coated atop (FAPbI3)0.85(MAPbI2Br)0.1(CsPbI3)0.05 (or FA0.85MA0.1Cs0.05PbI2.9Br0.1) followed by annealing, where FA is formamidinium and MA is methylammonium. The thin-film XRD results suggested that the DMePDAPbI4-2 structure formed, as evidenced by the characteristic low-angle diffraction peak at ~8.5  for DMePDAPbI4-2, rather than ~8.7  for DMePDAPbI4-1 (Fig. 3A). 

We also checked the 2D structures on top of three other common perovskite compositions of Cs0.05FA0.95PbI3, (FAPbI3)0.95(MAPbBr3)0.05, and FAPbI3 (Figure S12). For these compositions, the characteristics peaks at (002), (004), and (006) matched well to DMePDAPbI4-2, which were absent in the DMePDAPbI4-1 spectrum. Finally, the low-angle diffraction peak associated with 

9 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

the 2D structure from the thin-film XRD results were further confirmed by grazing-incidence wide-angle x-ray scattering (GIWAXS) measurements (Figure S13). In terms of 2D surface layer topology and coverage, the scanning electron microscopy (SEM) measurements indicated that the treatment induced formation of a thin surface layer with small apparent grain sizes (Figures S14 and S15). The conductive-atomic force microscopy (C-AFM) measurements show that the current of the treated film is much more uniform and lower than the control film, which is consistent with the formation of a capping layer over the 3D perovskite layer (Figure S16). 

To gain more insight into how the DMePDAI2 modification affects the optoelectronic properties in perovskite films, we conducted steady-state photoluminescence (PL), time-resolved photoluminescence (TRPL), and TRMC studies on these samples. The DMePDAI2 treatment led to enhanced PL intensity (Figure S17), longer TRPL lifetime (Figure S18 and Table S5), and improved TRMC mobility and lifetime (Figure S19) that were consistent with the improved surface properties ( _8, 30_ ). In addition, the ultraviolet photoelectron spectroscopy (UPS) measurements showed that the 2D surface treatment improved the energetics for hole transport from the 3D perovskite to the 2D surface layer (Figure S20). 

The impact of the DMePDAI2 treatment on the perovskite surface chemistry was investigated by x-ray photoelectron spectroscopy (XPS). Normalized core levels from key elements identified on the sample surface are included in Figures S21 and S22. The spectral shapes of most core levels showed minimal change between the two samples, indicating similar bonding environments, but surface treatment caused change in the C 1s and N 1s core levels. We fit the core levels (Figure 3, B to E) using constrained fitting procedures (summarized in Tables S6 and S7). The control sample had a N 1s region whose relative peak areas were dominated by a C=NH2<sup>+</sup> (FA) peak (~401 eV) with a small shoulder to higher binding energy (~403 eV) that corresponded to C-NH3 (MA). The DMePDAI2 treatment increased the area of the C-NH3 peak and also led to two additional peaks at lower binding energy consistent with C-NH2 (~400 eV) and the tertiary amine in DMePDAI2 (~398 eV). Concomitant with these changes, redistribution occurred in the features in the C 1s spectra comprising of four main peaks that are consistent with primarily C- C/C-H (~285 eV), N-CH3 (~287 eV), HC(NH2)2 (~289 eV), and C-O/C=O bonds (~290 eV). The surface treatment decreased the concentration of HC(NH2)2 bonds from FA on the surface while simultaneously increased the amount of N-CH3 and C-C/C-H bonds. In addition, XPS revealed that surface treatment increased the amount of halide on the surface, from about 2.6 halide-to-lead 

10 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

ratio for the control to 3.1 for the DMePDAI2-treated film. Collectively, these results suggest that both organic and halide components of the additive incorporated into the top surface of the treated films. Undercoordinated lead can cause donor defects on the surface, resulting in downward band bending and increased recombination centers ( _31_ ), so the increase in the halide-to-lead ratio associated with the formation of 2D interfacial component upon surface treatment was consistent with a less defective surface. 



**Figure 4. Device characteristics.** ( **A** to **C** ) _J_ – _V_ characteristics of PSCs based on different perovskite compositions: (A) FA0.85MA0.1Cs0.05PbI2.9Br0.1; (B) FA0.97MA0.03PbI2.91Br0.09; (C) MAPbI3. The insets are stabilized power outputs (SPOs) of the corresponding devices. ( **D** ) Operation ISOS-L-1 stability (maximum power point tracking, in N2, continuous one-sun illumination at ~40  C) of unencapsulated PSC based on FA0.85MA0.1Cs0.05PbI2.9Br0.1. The initial PCE was 20.5% for the control and 23.1% for the DMePDAI2-treated device. 

**Table 1.** PV parameters of PSCs based on control and DMePDAI2-modified perovskite thin films using different perovskite compositions. 

11 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

|**Device**|**Scan**|**Jsc**<br>**(mA/cm**<sup>**2**</sup>**)**|**Voc **<br>**(V)**|**FF**|**PCE**<br>**(%)**|**SPO**<br>**(%)**|
|---|---|---|---|---|---|---|
|FA0.85MA0.1Cs0.05PbI2.9Br0.1|Forward|24.35|1.111|0.773|20.9|20.4|
||Reverse|24.32|1.099|0.764|20.4||
|FA0.85MA0.1Cs0.05PbI2.9Br0.1<br>|Forward|24.97|1.167|0.822|24.0|23.7|
|/DMePDAI2|Reverse|24.93|1.167|0.814|23.7||
|FA0.97MA0.03PbI2.91Br0.09|Forward|25.21|1.103|0.791|22.0|21.7|
||Reverse|25.15|1.108|0.781|21.8||
|FA0.97MA0.03PbI2.91Br0.09<br>|Forward|25.25|1.158|0.843|24.7|24.3|
|/DMePDAI2|Reverse|25.26|1.158|0.839|24.5||
|MAPbI3|Forward|23.09|1.090|0.742|18.7|18.2|
||Reverse|23.09|1.080|0.729|18.2||
|MAPbI3/DMePDAI2|Forward|23.19|1.131|0.797|20.9|20.8|
||Reverse|23.19|1.132|0.794|20.8||



We investigated the impact of DMePDAI2 surface treatment on the PV performance by fabricating PSCs using the standard n-i-p device architecture, glass/FTO/electron transport layer (ETL)/perovskite/hole transport layer (HTL)/Au, where ETL is TiO2 or SnO2, and HTL is spiroOMeTAD, with more details in the experimental section ( _23_ ). Typical cross-section SEM images of devices are shown in Figure S23. Figure 4A compares the _J_ – _V_ curves of the PSCs based on triple-cation-mixed-halide FA0.85MA0.1Cs0.05PbI2.9Br0.1 without and with DMePDAI2 treatment under simulated 100-mW/cm<sup>2</sup> AM1.5G illumination (Table 1). With the surface treatment, the device PCE increased from about 20.9% to 24.0% from forward scan and from 20.4% to 23.7% from reverse scan. The PCE improvement is also consistent with a better perovskite/HTL junction based on the cross-sectional Kelvin probe force microscopy (KPFM) measurements (Figure S24) ( _32_ ). Note that the optimum concentration for DMePDAI2-surface treatment was found at 0.5 mg/mL (Figure S25). 

In addition to the FAMACs-based perovskite composition, we also examined the impact of DMePDAI2 surface treatment on PSCs based on double-cation-mixed-halide (FA0.97MA0.03PbI2.91Br0.09) and single-cation-single-halide (MAPbI3), using ETL of SnO2 and TiO2, 

12 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

respectively, and found PCE improvements for both compositions (Fig. 4, B and C). Noteworthy for PSCs based on FA0.97MA0.03PbI2.91Br0.09, the PCE was improved from 22.0% to 24.7% from forward scan and from 21.8% to 24.5% from reverse scan, with _J_ sc > 25 mA/cm<sup>2</sup> , which is in agreement with the EQE spectrum (Figure S26). For all three perovskite compositions, the stabilized power outputs (SPOs) for PSCs based on the control and DMePDAI2-modified perovskite thin films matched well with the _J_ – _V_ measurements (insets of Figure 4, A to C, and Table 1). The PCE improvement for all three perovskite compositions was reproducible based on the statistical comparison (Figure S27). The devices with this treatment also exhibited higher PCE than devices based on other surface treatments with similar length of bulky organic salts for either RP or DJ 2D perovskites (Figure S28). 

Finally, we checked the operation stability of unencapsulated FA0.85MA0.1Cs0.05PbI2.9Br0.1based PSCs using maximum power point (MPP) tracking at ~40  C in N2, following the ISOS-L-1 stability protocol ( _33_ ). The DMePDAI2-modified PSC (Fig. 4D) showed only 10% relative efficiency drop after 1000 h continuous operation whereas the PCE of the control device decreased by ~43%. The stability improvement with DMePDAI2 surface treatment was also observed when the devices were tested at high moisture (>85% relative humidity) or high temperature (85  C) conditions (Figures S29 and S30). These results suggest that the DMePDAI2-modification to form a 2D DJ phase surface layer is a general way to improve PSC performance. Our use of the metastable 2D DJ structure through hydrogen bonding tuning based on asymmetric bulky organic molecules represents a promising chemical design element for perovskite interfacial engineering to enhance PSC efficiency and stability. 

## **References and Notes** 

1. Best Research-Cell Efficiency Chart, National Renewable Energy Laboratory, https://www.nrel.gov/pv/cell-efficiency.html (Augest,2020) 

2. D. Bi _et al._ , Polymer-templated nucleation and crystal growth of perovskite films for solar cells with efficiency greater than 21%. _Nature Energy_ **1** , 16142 (2016). 

3. X. Zheng _et al._ , Defect passivation in hybrid perovskite solar cells using quaternary ammonium halide anions and cations. _Nature Energy_ **2** , 17102 (2017). 

4. F. Zhang _et al._ , Isomer-pure bis-PCBM-assisted crystal engineering of perovskite solar cells showing excellent efficiency and stability. _Advanced Materials_ **29** , 1606806 (2017). 

13 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

5. X. Li _et al._ , Improved performance and stability of perovskite solar cells by crystal crosslinking with alkylphosphonic acid ω-ammonium chlorides. _Nature Chemistry_ **7** , 703-711 (2015). 

6. F. Zhang _et al._ , Advances in two-dimensional organic–inorganic hybrid perovskites. _Energy & Environmental Science_ **13** , 1154-1186 (2020). 

7. E. H. Jung _et al._ , Efficient, stable and scalable perovskite solar cells using poly(3hexylthiophene). _Nature_ **567** , 511-515 (2019). 

8. H. Min _et al._ , Efficient, stable solar cells by using inherent bandgap of α-phase formamidinium lead iodide. _Science_ **366** , 749-753 (2019). 

9. L. Liang, H. Luo, J. Hu, H. Li, P. Gao, Efficient perovskite solar cells by reducing interface-mediated recombination: a bulky amine approach. _Advanced Energy Materials_ **10** , 2000197 (2020). 

10. Y.-W. Jang _et al._ , Intact 2D/3D halide junction perovskite solar cells via solid-phase inplane growth. _Nature Energy_ **6** , 63-71 (2021). 

11. J. Xue _et al._ , Reconfiguring the band-edge states of photovoltaic perovskites by conjugated organic cations. _Science_ **371** , 636-640 (2021). 

12. D. Thrithamarassery Gangadharan, D. Ma, Searching for stability at lower dimensions: current trends and future prospects of layered perovskite solar cells. _Energy & Environmental Science_ **12** , 2860-2889 (2019). 

13. E. Shi _et al._ , Two-dimensional halide perovskite lateral epitaxial heterostructures. _Nature_ **580** , 614-620 (2020). 

14. Y. Gao _et al._ , Molecular engineering of organic–inorganic hybrid perovskites quantum wells. _Nature Chemistry_ **11** , 1151-1157 (2019). 

15. S. Ahmad _et al._ , Dion-Jacobson phase 2D layered perovskites for solar cells with ultrahigh stability. _Joule_ **3** , 794-806 (2019). 

16. L. Mao _et al._ , Hybrid Dion–Jacobson 2D lead iodide perovskites. _Journal of the American Chemical Society_ **140** , 3775-3783 (2018). 

17. Y. Lv _et al._ , [NH3(CH2)6NH3]PbI4 as Dion–Jacobson phase bifunctional capping layer for 2D/3D perovskite solar cells with high efficiency and excellent UV stability. _Journal of Materials Chemistry A_ **8** , 10283-10290 (2020). 

18. X. Jiang _et al._ , Dion-Jacobson 2D-3D perovskite solar cells with improved efficiency and stability. _Nano Energy_ **75** , 104892 (2020). 

19. X. Li, J. M. Hoffman, M. G. Kanatzidis, The 2D halide perovskite rulebook: How the spacer influences everything from the structure to optoelectronic device efficiency. _Chemical Reviews_ **121** , 2230-2291 (2021). 

20. G. L. F. Miessler, P. J.; Tarr, D. A., _Inorganic Chemistry_ .  (Prentice Hall: Upper Saddle Rive, NJ, ed. 5th Edition, 2014). 

21. C. Ma, D. Shen, T.-W. Ng, M.-F. Lo, C.-S. Lee, 2D perovskites with short interlayer distance for high-performance solar cell application. _Advanced Materials_ **30** , 1800710 (2018). 

22. T. Yu, L. Zhang, J. Shen, Y. Fu, Y. Fu, Hydrogen bonds and steric effects induced structural modulation of three layered iodoplumbate hybrids from nonperovskite to perovskite structure. _Dalton Transactions_ **43** , 13115-13121 (2014). 

23. F. Zhang _et al._ , Surface lattice engineering through three-dimensional lead iodide perovskitoid for high-performance perovskite solar cells. _Chem_ **7** , 774-785 (2021). 

14 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

24. S. Silver, S. Xun, H. Li, J.-L. Brédas, A. Kahn, Structural and electronic impact of an asymmetric organic ligand in diammonium lead iodide perovskites. _Advanced Energy Materials_ **10** , 1903900 (2020). 

25. W. Zhao _et al._ , Asymmetric alkyl diamine based Dion–Jacobson low-dimensional perovskite solar cells with efficiency exceeding 15%. _Journal of Materials Chemistry A_ **8** , 9919-9926 (2020). 

26. A. V. Krukau, O. A. Vydrov, A. F. Izmaylov, G. E. Scuseria, Influence of the exchange screening parameter on the performance of screened hybrid functionals. _The Journal of Chemical Physics_ **125** , 224106 (2006). 

27. S. Grimme, J. Antony, S. Ehrlich, H. Krieg, A consistent and accurate ab initio parametrization of density functional dispersion correction (DFT-D) for the 94 elements H-Pu. _The Journal of Chemical Physics_ **132** , 154104 (2010). 

28. F. Zhang _et al._ , Enhanced Charge Transport in 2D Perovskites via Fluorination of Organic Cation. _Journal of the American Chemical Society_ **141** , 5972-5979 (2019). 

29. D. L. McGott _et al._ , 3D/2D passivation as a secret to success for polycrystalline thin-film solar cells. _Joule_ ,  (2021). 

30. H. Zhu _et al._ , Synergistic Effect of Fluorinated Passivator and Hole Transport Dopant Enables Stable Perovskite Solar Cells with an Efficiency Near 24%. _Journal of the American Chemical Society_ **143** , 3231-3237 (2021). 

31. S. P. Dunfield _et al._ , From defects to degradation: A mechanistic understanding of degradation in perovskite solar cell devices and modules. _Advanced Energy Materials_ **10** , 1904054 (2020). 

32. Y. Hou _et al._ , Efficient tandem solar cells with solution-processed perovskite on textured crystalline silicon. _Science_ **367** , 1135-1140 (2020). 

33. M. V. Khenkin _et al._ , Consensus statement for stability assessment and reporting for perovskite photovoltaics based on ISOS procedures. _Nature Energy_ **5** , 35-49 (2020). 

34. E. H. Anaraki _et al._ , Highly efficient and stable planar perovskite solar cells by solutionprocessed tin oxide. _Energy & Environmental Science_ **9** , 3128-3134 (2016). 

35. G. Ashiotis _et al._ , The fast azimuthal integration Python library: pyFAI. _Journal of Applied Crystallography_ **48** , 510-519 (2015). 

36. C. L. Perkins, F. S. Hasoon, Surfactant-assisted growth of CdS thin films for photovoltaic applications. _Journal of Vacuum Science & Technology A_ **24** , 497-504 (2006). 

37. J. Even, L. Pedesseau, J.-M. Jancu, C. Katan, Importance of Spin–Orbit Coupling in Hybrid Organic/Inorganic Perovskites for Photovoltaic Applications. _The Journal of Physical Chemistry Letters_ **4** , 2999-3005 (2013). 

38. S. X. Tao, X. Cao, P. A. Bobbert, Accurate and efficient band gap predictions of metal halide perovskites using the DFT-1/2 method: GW accuracy with DFT expense. _Scientific Reports_ **7** , 14386 (2017). 

39. M. Guidon, J. Hutter, J. VandeVondele, Auxiliary Density Matrix Methods for Hartree−Fock Exchange Calculations. _Journal of Chemical Theory and Computation_ **6** , 2348-2364 (2010). 

40. J. Hutter, M. Iannuzzi, F. Schiffmann, J. VandeVondele, cp2k: atomistic simulations of condensed matter systems. _WIREs Computational Molecular Science_ **4** , 15-25 (2014). 

41. K. Wang, C. Wu, D. Yang, Y. Jiang, S. Priya, Quasi-Two-Dimensional Halide Perovskite Single Crystal Photodetector. _ACS Nano_ **12** , 4919-4929 (2018). 

15 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

42. J. V. Passarelli _et al._ , Enhanced Out-of-Plane Conductivity and Photovoltaic Performance in n = 1 Layered Perovskites through Organic Cation Design. _Journal of the American Chemical Society_ **140** , 7313-7323 (2018). 

43. A. B. Corradi _et al._ , Structural and Electrical Characterization of Polymeric Haloplumbate(II) Systems. _Inorganic Chemistry_ **38** , 716-721 (1999). 

44. C. Xiao _et al._ , Junction Quality of SnO2-Based Perovskite Solar Cells Investigated by Nanometer-Scale Electrical Potential Profiling. _ACS Applied Materials & Interfaces_ **9** , 38373-38380 (2017). 

## **Acknowledgments** 

**Funding:** The work was partially supported by the U.S. Department of Energy under Contract No. DE-AC36-08GO28308 with Alliance for Sustainable Energy, Limited Liability Company (LLC), the Manager and Operator of the National Renewable Energy Laboratory. The authors acknowledge the support on 2D structure design, first-principle calculations, synthesis of PDAI2 and DMePDAI2, single crystal synthesis and analysis, and optoelectronic characterizations (e.g., TRPL and TRMC), from the Center for Hybrid Organic-Inorganic Semiconductors for Energy (CHOISE), an Energy Frontier Research Center funded by the Office of Basic Energy Sciences, Office of Science within the U.S. Department of Energy. The authors also acknowledge the support on devices fabrication and characterizations and general thin-film perovskite characterizations from the De-Risking Halide Perovskite Solar Cells program of the National Center for Photovoltaics, and the support on SnO2 ETL synthesis along with the corresponding device fabrication and characterization from DE-FOA-0002064 and Award Number DEEE0008790, funded by the U.S. Department of Energy, Office of Energy Efficiency and Renewable Energy, Solar Energy Technologies Office. Portions of this research were carried out at the Stanford Synchrotron Radiation Lightsource, SLAC National Accelerator Laboratory, supported by the U.S. Department of Energy, Office of Science, Office of Basic Energy Sciences under Contract No. DE-AC02-76SF00515. L.D.H. and E.L.R. acknowledge funding support on UPS characterization and analysis from the Office of Naval Research under award #N00014-201-2440. X.Z. and Y.-L.L. acknowledge support on SCLC characterization and analysis from the National Science Foundation, under grant CMMI-1824674, and funding from the Princeton Center for Complex Materials, a National Science Foundation (NSF)-MRSEC program (DMR-1420541). The DFT calculations were performed using computational resources sponsored by the Department of Energy’s Office of Energy Efficiency and Renewable Energy and located at the 

16 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

National Renewable Energy Laboratory, and resource of the National Energy Research Scientific Computing Center (NERSC), a U.S. Department of Energy Office of Science User Facility located at Lawrence Berkeley National Laboratory, operated under Contract No. DE-AC02-05CH11231. The views expressed in the article do not necessarily represent the views of the DOE or the U.S. Government. **Author contributions:** K.Z. and F.Z. designed the experiment. F.Z. and S.Y.P. carried out the experimental study on device fabrication and characterizations. C.Y. conducted DFT calculations under the supervision of Y.Y. H.L. synthesized PDAI2, DMePDAI2, and the corresponding single crystals. S.P. tested and analyzed the structures of single crystals. B.W.L. performed the TRMC and analyzed the TRMC data and some corresponding single crystals data. C.X. performed the AFM, CAFM, and KPFM test. S.P.D. conducted the XPS and analyzed the data with the guidance from G.T. and J.J.B. S.U., L.T.S., and K.H.S. performed the GIWAX and analyzed the data with the help from L.E.M. X.Z. performed the SCLC measurement and analysis under the supervision of Y.-L.L. L.D.H. conducted UPS and analyzed the data with the guidance from E.L.R. X.C. performed the TRPL and analyzed the data under the supervision of M.C.B. F.Z. performed SEM and XRD measurements. J.J.B performed supplemental XRD measurements. F.Z., Y.Y., B.W.L, and K.Z. wrote the first draft of the paper. All authors discussed the results and contributed to the revisions of the manuscript. K.Z. supervised the project. **Competing interests:** F.Z. and K.Z. are inventors on a provisional patent (US patent application number 63/197,652) related to the subject matter of this manuscript. **Data and materials availability:** All data needed to evaluate the conclusions in the paper are present in the paper or the Supplementary Materials. The accession numbers for the crystal structure cif. files reported in this paper are CCDC 2048509 ([PDAPbI4]15•[PDAI2]), CCDC 2048508 (BDAPbI4), and CCDC 2048510 (DMePDAPbI4-1), which are archived at the Cambridge Crystallographic Data Centre. 

## **Supplementary Materials** 

Materials and Methods Figs S1 to S30 Tables S1 to S7 References ( _34_ – _44_ ) 

17 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

