# Laser soliton microcombs heterogeneously integrated on silicon

| 字段 | 内容 |
|---|---|
| 期刊 | Science |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 339 |
| 作者 | Chao Xiang, Jun-Qiu Liu, Joel Guo, L. Chang, Rui-Ning Wang, Wen-Le Weng, J. Peters, Wei-Qiang Xie et al. |
| DOI | 10.1126/science.abh2076 |
| 源文件 | 048_Xiang_2021_Laser-soliton-microcombs-heterogeneously-integra.pdf |

---
**Laser soliton microcombs on silicon** 

Chao Xiang,<sup>1,</sup><sup>_∗_</sup> Junqiu Liu,<sup>2,</sup><sup>_∗_</sup> Joel Guo,<sup>1</sup> Lin Chang,<sup>1</sup> Rui Ning Wang,<sup>2</sup> Wenle Weng,<sup>2</sup> Jonathan Peters,<sup>1</sup> Weiqiang Xie,<sup>1</sup> Zeyu Zhang,<sup>1</sup> Johann Riemensberger,<sup>2</sup> Jennifer Selvidge,<sup>3</sup> Tobias J. Kippenberg,<sup>2,</sup><sup>_†_</sup> and John E. Bowers<sup>1, 3,</sup><sup>_‡_</sup> 

> 1 _ECE Department, University of California Santa Barbara, Santa Barbara, CA 93106, USA_ 

> 2 _Institute of Physics, Swiss Federal Institute of Technology Lausanne (EPFL), CH-1015 Lausanne, Switzerland_ 

> 3 _Materials Department, University of California Santa Barbara, Santa Barbara, CA 93106, USA_ 

**Silicon photonics enables wafer-scale integration of optical functionalities on chip. A silicon-based laser frequency combs could significantly expand the applications of silicon photonics, by providing integrated sources of mutually coherent laser lines for terabit-per-second transceivers, parallel coherent LiDAR, or photonics-assisted signal processing. Here, we report on heterogeneously integrated laser soliton microcombs combining both InP/Si semiconductor lasers and ultralowloss Si** 3 **N** 4 **microresonators on monolithic Si substrate. Thousands of devices are produced from a single wafer using standard CMOS techniques. Using on-chip electrical control of the microcomblaser relative optical phase, these devices can output single-soliton microcombs with 100 GHz repetition rate. Our approach paves the way for large-volume, low-cost manufacturing of chipbased frequency combs for next-generation highcapacity transceivers, datacenters, space and mobile platforms.** 

Optical frequency combs (OFC)<sup>1,2</sup> have revolutionized timing, spectroscopy and metrology<sup>3,4</sup> . Historically, OFCs have been made using femtosecond modelocked lasers with supercontinuum generation for octavespanning spectra, required for self-referencing. Discovered a decade ago<sup>5</sup> , OFCs can also be generated in driven Kerr-nonlinear optical microresonators. These types of OFCs are commonly referred to as "microcombs". Microcombs can be operated in regimes where they form coherent, temporal, dissipative structures<sup>6,7</sup> , i.e. bright dissipative Kerr solitons (DKS)<sup>8</sup> . DKS have unlocked the full potential of microcombs by providing coherent, broadband OFCs with repetition rates in the terahertz to microwave domains, and have been successfully employed in many system-level applications such as RF photonics<sup>9,10</sup> , coherent communication<sup>11,12</sup> , astronomical spectrometer calibration<sup>13,14</sup> , massively parallel coherent LiDAR<sup>15</sup> , optical frequency synthesizers<sup>16</sup> and photonic neromorphic computing<sup>17,18</sup> . On a fundamental level, DKS microcombs have allowed explorations of a plethora of novel nonlinear dynamics and phenomena<sup>19,20</sup> . 

In parallel, there has been substantial progress in photonic integrated platforms<sup>21</sup> for microcomb generation, which to date include Si3N4<sup>22–26</sup> , AlN<sup>27,28</sup> , LiNbO3<sup>29–31</sup> , AlGaAs<sup>32–34</sup> , GaP<sup>35</sup> , and SiC<sup>36</sup> . Among them, the leading platform is Si3N4, which has already been used widely in CMOS microelectronics as diffusion barriers and etch masks. In addition to its native properties such as the 

absence of two-photon absorption, high Kerr nonlinearity, and weak Raman and Brillouin gains<sup>37</sup> , recent advances in fabrication of nonlinear Si3N4 photonic integrated circuits (PIC) have enabled optical propagation losses below 1 dB/m<sup>24,25</sup> . These ultralow losses have significantly reduced the soliton formation threshold power to the levels that integrated lasers can provide<sup>38,39</sup> , and have yielded soliton repetition rates in the microwave X- band<sup>40</sup> . In combination with negligible thermal effects and almost purely Kerr-dominated frequency-dependent response<sup>25</sup> , reliable soliton generation can be attained without complex or fast laser tuning. Additionally, laser self-injection locking<sup>41,42</sup> and hybrid integration of soliton microcombs with RSOAs<sup>43</sup> or DFB lasers<sup>44</sup> allow for current-initiated and electrically controlled modules with low electrical power<sup>43–46</sup> . 

A long-standing goal is to monolithically integrate lasers and high- _Q_ nonlinear microresonators onto a common silicon wafer. Heterogeneously integrated silicon photonics<sup>47–49</sup> offers a compelling solution using low-cost, industry-standard silicon substrates, aided by mature CMOS-compatible fabrication facilities. High-performance, large-scale heterogeneous PICs with complete functionalities, including lasers<sup>50–52</sup> , modulators<sup>53–55</sup> , and photodetectors<sup>56,57</sup> , are disrupting optical interconnect technology and other applications<sup>58–60</sup> . The material-by-design nature enabled by heterogeneous integration offers best-in-class performance. However, heterogeneous integration of highpower, narrow-linewidth, semiconductor lasers with high- _Q_ Si3N4 microresonators has not been demonstrated yet, because multiple material platforms (Si, Si3N4, and IIIV) with significantly different optical properties have to be deployed and combined. Here we overcome these challenges and present the first demonstration of heterogeneously integrated laser soliton microcombs. This is achieved using ultralow-loss Si3N4 PICs based on the photonic Damascene fabrication process in conjunction with direct SOI wafer bonding and heterogeneous III-V integration. The result is a wafer-scale fabrication process that produces thousands of devices from one silicon wafer. Each device allows electrical initiation and control of soliton microcombs. Our technology demonstrates the viability of large-volume, low-cost manufacturing of chip-based OFCs, and allows incorporation of soliton microcombs as new building block into existing complex silicon photonics systems, and in applications requiring reliable performance, small footprint, low cost and low power consumption, such as space or mobile platforms. 

2 



<!-- Start of picture text -->
A I laser I phase B<br>0.5 mm<br>InP<br>Si<br>Si 3 N 4<br>SiO2<br>Si substrate<br>DFB laser Phase tuner High-Q microresonator<br>C<br>10 mm 3 mm 1 mm 0.1 mm<br>D InP/Si Si Si3N4 E 1<br>0<br>0.5 mm<br>Laser current  I laser (a.u.)<br>Comb power (a.u.)<br>I  (a.u.)Phase tuner current phase<br><!-- End of picture text -->

Figure 1. **Device schematics, images and operation principle** . A. Design layout of a laser soliton microcomb device consisting DFB lasers, phase tuners and high- _Q_ microresonators on a common substrate. A continuous-wave (CW) signal (solid red line) emitted from the laser is partially back-scattered in the microresonator. The back-scattered signal (dashed red line) is sent back to the laser, triggering self-injection locking that assists the formation of soliton pulse stream inside the microresonator. The optimization of laser self-injection locking is realized by controlling the laser current _I_ laser and phase tuner current _I_ phase. B. Simplified device cross-section schematics. The laser is based on InP/Si. The microresonator is based on Si3N4. Silicon layer is used to deliver light from the InP/Si layer to the Si3N4 layer. C. Photographs showing the completed 100-mm-diameter wafer, zoom-in of multiple laser soliton microcomb dies, and a microscopic image showing a Si3N4 microring resonator with Si/ Si3N4 interface. D. Bird-view schematic illustration of the large-scale integrated laser soliton microcomb devices enabled by multilayer heterogeneous integration. The lasers, phase tuners and high- _Q_ microresonators are built on InP/Si layer, Si layer and Si3N4 layer, respectively. E. Schematic illustration of the microcomb generation with sweeping laser current _I_ laser and varying phase tuner current _I_ phase (thus to vary the optical phase difference between the forward and backward signals), in the case of laser self-injection locking. This waterfall plot is based on a full nonlinear simulation shown in the Supplementary Information. 

**Device schematic** . As shown in Fig. 1A, a chipscale laser frequency comb consists of three main parts: a distributed feedback (DFB) laser, a thermo-optic phase tuner, and a high- _Q_ nonlinear microresonator, by leveraging multilayer heterogeneous integration<sup>52</sup> (Fig. 1B). Figure 1C shows the photographs of the complete wafer (before dicing into chips), multiple dies, single-die-level devices, and an optical microscope image of a Si3N4 microring resonator interfaced with Si layer. As illustrated in Fig. 1D, the DFB lasers, phase tuners, and nonlinear microresonators are built on indium phosphide/silicon (InP/Si), silicon (Si), and Si3N4 layers, respectively. This vertical, multilayer structure is realized through sequen- 

tial wafer bonding of a silicon-on-insulator (SOI) wafer and an InP multiple-quantum-well (InP MQW) epi wafer to a pre-patterned Si3N4 substrate that is fabricated using the photonic Damascene process<sup>25,52</sup> . Deep ultraviolet (DUV) stepper lithography is used to ensure pattern alignment on each individual layer with an accuracy better than 100 nm. Here we directly apply heterogeneous integration on 100-mm-diameter Si substrates and process the entire substrate on the wafer scale. Our process could be further scaled up with larger wafer substrates such that it is compatible with standard CMOS foundry production lines<sup>59</sup> . 

The DFB laser is a high-power, single longitudinal- 

3 



<!-- Start of picture text -->
A 1 2 3<br>Si3N4 Damascene Si processing InP processing<br>3<br>2<br>Bonding<br>Planarization<br>Deposition 1<br>HH ++ H +<br>SiO 2 Si 3 N 4 P-InP MQW Contact<br>Si sub Si device N-InP Heater Probe<br>B C<br>2.0<br>1.5<br>1.0<br>0.5 Probe P-contact<br>0<br>0.51.0 Si P-InP MQW N-InP N-contact<br>500 nm -1.5 1 μm SiO2<br>-2.0<br>(nm)<br><!-- End of picture text -->

Figure 2. **Simplified wafer-scale fabrication process flow** . A. Multilayer heterogeneous integration process. Left panel shows that a pre-patterned Si3N4 Damascene substrate is planarized and subsequently bonded with an SOI wafer and an InP MQW epi wafer. The wafer undergoes 1.) Si3N4 photonic Damascene process, 2.) Si processing and 3.) InP processing. Right panel shows selected key steps in the wafer fabrication with 1.) Si3N4 photonic Damascene process including LPCVD Si3N4 deposition on the patterned SiO2 substrate (top), excess Si3N4 removal and planarization (middle), and SiO2 spacer deposition, densification and polishing (bottom); 2.) Si processing including Si substrate removal (top), Si waveguide etch for laser and thermal tuner (middle), and for Si grating and Si-Si3N4 mode conversion taper (bottom); 3.) InP processing including InP substrate removal (top), InP mesa etch (middle), and excess Si removal, laser passivation, contact formation, vias open, heaters, and probe metal formation (bottom). B. Left: Atomic-force microscopy (AFM) shows 0.27 nm RMS roughness of the Si3N4 wafer surface, after the second CMP on the SiO2 spacer, before bonding with the SOI wafer. Right: SEM image of Si grating for laser before bonded with InP MQW wafer. C. False-colored SEM image showing the cross-section of the complete device at laser area with multilayer device structure. 

mode pump source with an excellent side mode suppression ratio (SMSR) such that the laser wavelength can be tuned to a microring resonance<sup>61</sup> . The laser has a 1.8mm-long InP/Si gain section, and the grating is etched on both sides of the shallow-etched Si waveguide rib with a 170 nm gap separation to the Si waveguide core. The fully etched grating provides the optical resonant feedback for the pump laser and determines the lasing wavelength _λ_ pump by its pitch Λ ( _λ_ pump = 2 _n_ effΛ). Here Λ = 238 nm and _λ_ pump _∼_ 1550 nm. A quarter wavelength shift section is included at the grating length center to supply non-degenerate phase conditions favoring single longitudinal mode lasing. 

The single-wavelength laser output passes through a thermo-optic resistive heater (for optical phase control), and couples into a high- _Q_ Si3N4 microring resonator where nonlinear four-wave mixing processes generate Kerr microcombs<sup>5,62</sup> . The Si3N4 microresonator exhibits anomalous group velocity dispersion (GVD) in 

the telecommunication C band and have a free-spectral range (FSR) of 100 GHz. The laser directly pumps the microresonator without an intermediate optical isolator, and the entire device is operated via laser control and phase control. Laser self-injection locking<sup>41,44–46,63,64</sup> leverages the narrow-band optical feedback at desired phase relations from a high- _Q_ microresonator to stabilize the pump laser and pulls the laser frequency towards the microring resonance. In this scenario, soliton microcombs can form when optimum laser-resonator frequency detuning is reached. Only the laser and phase tuner currents are electronically controlled, and no sophisticated external electronics feedback controls are required. The DFB laser wavelength increases with increasing laser current, as the grating index increases due to injected electrical power heating. As a result, certain gain currents triggers comb generation if the laser wavelength coincides with a microresonator resonance. The comb generation region resides where the laser is red-detuned to the res- 

4 

onance and the phase of the back-scattered light from the microresonator to the laser fulfills certain phase relations (Fig. 1E, see Supplementary Information for details). Note that the back-scattered light originates from Rayleigh scattering inside the microresonator due to surface roughness and bulk inhomogeneity. 

**Fabrication process flow** . Figure 2A presents the wafer-scale fabrication process flow. It starts with the photonic Damascene process<sup>25</sup> to fabricate the Si3N4 PIC on a Si substrate with 4-µm-thick thermal wet SiO2. The Si3N4 PIC is exposed with DUV stepper lithography and transferred to the SiO2 substrate to form the waveguide preform. Stoichiometric Si3N4 is deposited on the patterned SiO2 preform using low-pressure chemical vapor deposition (LPCVD), filling the trenches and forming waveguide cores. Chemical-mechanical polishing (CMP) is used to remove excess Si3N4 and planarize the wafer front surface, followed by spacer SiO2 deposition of 300 nm thickness on the Si3N4 substrate. The entire substrate is further annealed at 1200<sup>_◦_</sup> C to drive out the residual hydrogen content in the Si3N4 and SiO2 films, and to densify the spacer SiO2. 

A second CMP is performed to create a flat and smooth wafer surface. As shown in Fig. 2B left, the measured RMS roughness of the wafer surface using atomic-force microscopy (AFM) is 0.27 nm, enabling direct substrate bonding with an SOI wafer. After removing the Si substrate of the bonded SOI wafer, the Si device layer is processed to create waveguide structures with different etch depths, including shallow-etched Si waveguides for the lasers and phase tuners, fully-etched hole structures for gratings (cf. Fig. 2B right), and thin-thickness Si tapers for mode conversion between the Si waveguide and underlying Si3N4 waveguide<sup>52</sup> . InP MQW epi is then bonded to the patterned Si device surface at the active regions. The InP process starts with InP substrate removal. InP mesa etches including P-type InP, AlInGaAs MQW, and N-type InP etches are performed using selective dry etching and wet etching. The P- and N-type contact metals are deposited on the P-InGaAs layer and N-InP layer respectively. The excess Si on top of the Si3N4 microresonators is removed before laser passivation using hydrogen-free deuterated SiO2 deposition<sup>65</sup> . Vias are then etched through it for laser electrical contact. Proton implantation is performed on the laser mesa structure to reduce electrical current leakage. Heater and probe metals are deposited at the end of the full process. Finally, the entire wafer is diced into dozens of dies/chips to facilitate testing. Each chip contains tens of devices for soliton generation. Figure 2C shows the scanning electron microscopic (SEM) images of the device crosssection, which is false-colored to illustrate the multilayer structure. 

**Soliton generation** . The experimental setup to characterize the final chip devices is shown in Fig. 3A. We first characterize the laser performance. Figure 3B shows the measured light-current curves (solid blue curve), i.e. the laser output power versus stepped laser injection cur- 

rent of 0.5 mA, fixed phase tuner current of 7 mA, and 20<sup>_◦_</sup> C stage temperature. The measured laser threshold current is 64 mA. The laser power is out-coupled from the Si3N4 waveguide inverse-taper to a lensed fiber. The maximum power in the output fiber is measured as 8 mW, and the corresponding on-chip power in the Si3N4 waveguide is approximately 20 mW. The measured laser center wavelength using a wavelength meter is shown in Fig. 3B (dashed grey curve). Several dips on the optical power are observed at laser currents of 133, 231, 329.5, and 418 mA, where the laser wavelength coincides with microresonator resonances. These dips also verify the microresonator FSR of 100 GHz. Note that a highreflection (HR) coating is applied on the other side of the DFB laser to boost the laser output power. Future devices can avoid using this coating to yield mode-hop-free DFB lasers and linearized laser wavelength dependence on the laser current. The DFB laser has high SMSR at resonance #1 and #2, where high output powers are also obtained that are advantageous for comb generation. Figure 3C shows the single-longitudinal-mode laser spectra at the two resonance wavelengths, with 60 and 57 dB SMSR, respectively. 

Soliton microcomb is generated by tuning the laser frequency to the microresonator resonance via biasing the laser current, together with tuning the current of the phase tuner to control the relative forward/backward phase relations. As no optical isolator is used between the laser and the Si3N4 microresonator, laser self-injection locking<sup>44,63,64</sup> occurs when the laser frequency coincides with a microresonator resonance. More information of the phase dependence on comb generation is revealed by simulating the nonlinear self-injection locking process<sup>66</sup> and is discussed in the Supplementary Information. The calculated Kerr parametric oscillation threshold<sup>62</sup> for Si3N4 microresonators of _Q_ 0 _∼_ 7 _×_ 10<sup>6</sup> (see Supplementary information for _Q_ measurement) and 100 GHz FSR, is estimated to be around 3 mW. With around 329 mA laser current, the estimated on-chip laser power to pump the Si3N4 microresonator exceeds 16 mW. As shown in Fig. 3D, perfect soliton crystal states<sup>67</sup> are observed by fine-tuning the laser frequency. We also observe soliton crystal states with decreasing crystallization orders when increasing the laser current (red-detuning). Further increasing the laser power to around 418 mA current, a two-soliton crystal state with 200 GHz repetition rate and a single-soliton state with 100 GHz repetition rate is generated. The coherent soliton nature is revealed by photodetection of the amplitude noise of the comb lines beat signal. Once generated, the soliton states can be stable for hours in standard lab environments without any external feedback control. This stability benefits from the monolithic nature of the chip device and the laser-microresonator coupling through laser self-injection locking. 

**Self-injection locking and phase noise reduction** . To further characterize the laser self-injection locking, we measured the frequency noise spectra of the pump line 

5 



<!-- Start of picture text -->
A POW B 20<br>I laser I phase Power<br>18<br>WAV Laser wav<br>ISO Laser Ring res<br>16<br>OSA<br>BPF<br>PNA 14<br>PD Comb<br>OSC 12<br>FBG PD<br>ESA 10<br>1554.563<br>C<br>8<br>1553.718<br>res #1 res #2 6<br>60 dB 57 dB 4 1552.879<br>res #1 res #2<br>80 nm 2 1552.055<br>0<br>1552 1554 1556 1558 64 133 231 329.5 418<br>Wavelength (nm) Laser current (mA)<br>D<br>4x FSR soliton crystal 90 o 3x FSR soliton crystal<br>120 o<br>1520 1540 1560 1580 1600 1520 1540 1560 1580 1600<br>Wavelength (nm) Wavelength (nm)<br>0<br>2x FSR soliton crystal 180 o single soliton<br>-60<br>-120<br>0 0.5 1<br>f (GHz)<br>1520 1540 1560 1580 1520 1540 1560 1580<br>Wavelength (nm) Wavelength (nm)<br>Wavelength (nm)<br>Si waveguide power (mW)N34<br>60 dB/div<br>()10 dB/divPower<br>()20 dB/divPower  ()20 dB/divPower<br>()20 dB/divPower  ()20 dB/divPower  Power (dBm)<br><!-- End of picture text -->

Figure 3. **Device characterization and experimental generation of soliton spectra** . A. Schematics of the experimental setup for laser and soliton characterization. _I_ laser and _I_ phase are the current sources to drive the laser and the phase tuner. POW: power meter. WAV: wavelength meter. OSA: optical spectrum analyzer. PNA: phase noise analyzer. OSC: oscilloscope. ESA: electrical spectrum analyzer. ISO: isolator. BPF: band-pass filter. PD: photodetector. B. Light-current sweep measurement with stepped laser current and fixed phase tuner current. Grey color shows the corresponding laser center wavelength as a function of the laser current. Red circles indicate the laser wavelength coinciding with microresonator resonances. Soliton microcombs are generated with laser currents and wavelengths at resonance #1 and resonance #2. C. Single-mode DFB laser spectra at the wavelengths of resonance #1 and resonance #2. D. Optical spectra of soliton microcombs. Inset shows the relative position of multi-solitons circulating inside the microring resonator for 4-, 3-, and 2-FSR soliton crystal states and low-frequency RF spectrum of the single soliton state. 

and comb line in the single soliton state and laser freerunning state, as shown in Fig. 4A. Leveraging a high- _Q_ external cavity, self-injection locking exhibits frequency noise reduction, i.e. laser linewidth narrowing<sup>64</sup> . The fundamental linewidth of the free-running DFB laser is around 60 kHz, and is reduced to about 25 Hz in the self-injection-locked single soliton state. A 10-dB noise 

reduction is observed at 1 kHz Fourier offset frequency and is further increased to more than 30 dB above 300 kHz offset frequency. It has been revealed recently that the frequency noise of a self-injection-locked laser to a high- _Q_ Si3N4 microresonator can be dominantly limited by the thermo-refractive noise of the microresonator<sup>46,68</sup> . Therefore, further noise reduction can be realized by us- 

6 



<!-- Start of picture text -->
A<br>10 9<br>single soliton pump<br>1 st  comb line, -100 GHz<br>10 8<br>1 st  comb line, +100 GHz<br>free running DFB<br>10 7 phase retrieval<br>10 6<br>10 5<br>10 4<br>10 3<br>10 2<br>10 1<br>10 0<br>10 3 10 4 10 5 10 6 10 7<br>Offset frequency (Hz)<br>B<br>10 ms sweep<br>80 1<br>70<br>60<br>50<br>40<br>30<br>20<br>10<br>0 0<br>318 320 322 324 326 328 330 332 334 336<br>Laser current (mA)<br>2/Hz)Frequency noise (Hz<br>Comb power (a.u.)<br>Electrial power on phase tuner (mW)<br><!-- End of picture text -->

Figure 4. **Laser frequency noise spectrum and comb generation with self-injection locking** . A. Frequency noise spectra of the self-injection-locked pump line (green), comb lines with _±_ 100 GHz frequency offset to the pump (blue and red) in the single soliton state, free-running single-mode DFB laser output without self-injection locking (dark grey), and comb line around 1550 nm for the 2-FSR soliton crystal state using optical phase retrieval method (see Supplementary Information). B. Comb power evolution with sweeping laser current (10 milliseconds sweep) under varying electrical power on the phase tuner. 

ing microresonators of larger sizes (i.e. smaller FSR) or engineered material properties with lower thermo-optic transduction. Though the free-running linewidth of the DFB laser is broad, due to the linewidth narrowing provided by self-injection locking, the laser is still able to directly generate soliton states, surpassing its intrinsic limitation of spectral impurity. Additionally, the coherence of the injection-locked pump line is transferred to other comb lines. For example, the first neighboring comb lines, 100 GHz apart from the pump, have a fundamental linewidth around 200 to 300 Hz, and their frequency noise below 10 MHz offset frequency directly inherits that of 

the self-injection-locked pump. The self-injection locking scheme thus enables multi-wavelength, narrow-linewidth laser sources. Our device represents the first demonstration of a self-injection-locked, narrow-linewidth laser on Si. 

Different from the conventional pumping scheme with an optical isolator, the comb generation in the selfinjection locking scheme relies critically on the phase relation between the forward signal (i.e. the laser emission to the microresonator) and backward signal (i.e. the backscattered light from the microresonator to the laser). In this case, comb generation is only allowed when the opti- 

7 

cal phase difference is within a certain optimized range. In previous works using hybrid integrated devices, controlling the phase difference is realized by varying the gap distance between the laser chip and Si3N4 chip, which however also causes power coupling efficiency fluctuation between these two chips. In our monolithic device, this optical phase difference can be directly controlled by varying the current to the phase tuner. We experimentally studied the comb formation with laser current sweep under different currents on the phase tuner. In order to exclude the interference from the mode-hop phenomenon when monitoring the power of the new frequency components, we sweep the laser current across the resonance #1 shown in Fig. 3B. Results shown in Fig. 4B unveils that the comb generation is only permitted with certain phase conditions. More study shown in the Supplementary Information indicates that the back-scattered signal needs to be in phase with the forward signal. Additionally, the phase altering effect is periodic and deterministic with the applied electrical power on the phase tuner. Thus the allowed comb generation area depends mainly on the pump power and the intensity of the back-scattered light (see Supplementary Information). 

In summary, we have presented the first heterogeneously integrated laser soliton microcomb on silicon. Thousands of devices are manufactured from a full waferscale fabrication process using standard CMOS techniques such as DUV stepper lithography, CMP, wafer bonding, etc. We have successfully demonstrated single soliton formation with 100 GHz repetition rate, and characterized laser performance with self-injection locking. More functions could be added based on our current technology. For example, active, high-speed tuning of the Si3N4 microresonators (thus the injection- 

- _∗_ These authors contributed equally to this work. 

- tobias.kippenberg@epfl.ch 

- bowers@ece.ucsb.edu 

- 1 T. Udem, R. Holzwarth, and T. W. Hänsch, Nature **416** , 233 (2002). 

- 2 S. T. Cundiff and J. Ye, Rev. Mod. Phys. **75** , 325 (2003). 

- 3 T. Fortier and E. Baumann, Communications Physics **2** , 153 (2019). 

- 4 S. A. Diddams, K. Vahala, and T. Udem, Science **369** (2020), 10.1126/science.aay3676. 

- 5 P. Del’Haye, A. Schliesser, O. Arcizet, T. Wilken, R. Holzwarth, and T. J. Kippenberg, Nature **450** , 1214 (2007). 

- 6 L. A. Lugiato and R. Lefever, Phys. Rev. Lett. **58** , 2209 (1987). 

- 7 N. Akhmediev and M. Karlsson, Phys. Rev. A **51** , 2602 (1995). 

- 8 T. Herr, V. Brasch, J. D. Jost, C. Y. Wang, N. M. Kondratiev, M. L. Gorodetsky, and T. J. Kippenberg, Nature Photonics **8** , 145 (2013). 

- 9 V. Torres-Company and A. M. Weiner, Laser & Photonics Reviews **8** , 368 (2014). 

locked laser frequency) can be realized using piezoelectric actuators<sup>69,70</sup> . Meanwhile, full integration with other nonlinear photonics platforms such as (Al)GaAs<sup>33,71</sup> and LiNbO3<sup>72–74</sup> could provide _χ_ (2) nonlinearity that can be used for electro-optic modulation and second harmonic generation. The laser gain material can also be modified to utilize quantum-dots<sup>75</sup> or extended to different wavelength ranges from the visible to mid-infrared, significantly complementing existing integrated nonlinear photonic systems. Though demonstrated here on 100-mmdiameter Si substrates, our process could be upgraded to 200- or 300-mm-diameter substrates using modified CMOS foundry pilot lines. Our work paves the way for large-volume, low-cost manufacturing of electrically controlled, chip-based frequency comb modules for future applications in data-centers, space and mobile platforms. 

**Acknowledgments** : We thank Mario Dumont and Jijun He for their help in the device characterization. This work is supported by the Defense Advanced Research Projects Agency (DARPA) under DODOS (HR0011-15-C-055) programmes of the Microsystems Technology Office (MTO). 

**Author contribution** : C.X., L.C., J.L., T.J.K. and J.E.B. conceived the idea and initiated the collaboration. C.X., J.L. and L.C. designed the wafer layout and process flow. J.L. and R.N.W. fabricated the Si3N4 substrate. C.X. and J.P. fabricated the heterogeneous InP/Si lasers and Si circuits with the assistance from W.X., and Z.Z. C.X., J.G., and J.L. tested the final chips. C.X. and J.G. performed the laser soliton experiments with the assistance from J.R.. W.W. performed the numerical simulations of self-injection locking. J.S. took the FIB-SEM image. All authors discussed the data. C.X., J.L. and W.W. wrote the manuscript, with input from others. T.J.K. and J.E.B supervised the project. 

**Data Availability Statement** : All data generated or analysed during this study are available within the paper and its Supplementary Information. Further source data will be made available on reasonable request. 

- 10 J. Wu, X. Xu, T. G. Nguyen, S. T. Chu, B. E. Little, R. Morandotti, A. Mitchell, and D. J. Moss, IEEE Journal of Selected Topics in Quantum Electronics **24** , 1 (2018). 

- 11 P. Marin-Palomo, J. N. Kemal, M. Karpov, A. Kordts, J. Pfeifle, M. H. P. Pfeiffer, P. Trocha, S. Wolf, V. Brasch, M. H. Anderson, R. Rosenberger, K. Vijayan, W. Freude, T. J. Kippenberg, and C. Koos, Nature **546** , 274 (2017). 

- 12 B. Corcoran, M. Tan, X. Xu, A. Boes, J. Wu, T. G. Nguyen, S. T. Chu, B. E. Little, R. Morandotti, A. Mitchell, and D. J. Moss, Nature Communications **11** , 2568 (2020). 

- 13 M.-G. Suh, X. Yi, Y.-H. Lai, S. Leifer, I. S. Grudinin, G. Vasisht, E. C. Martin, M. P. Fitzgerald, G. Doppmann, J. Wang, D. Mawet, S. B. Papp, S. A. Diddams, C. Beichman, and K. Vahala, Nature Photonics **13** , 25 (2019). 

- 14 E. Obrzud, M. Rainer, A. Harutyunyan, M. H. Anderson, J. Liu, M. Geiselmann, B. Chazelas, S. Kundermann, S. Lecomte, M. Cecconi, A. Ghedina, E. Molinari, F. Pepe, F. Wildi, F. Bouchy, T. J. Kippenberg, and T. Herr, Nature Photonics **13** , 31 (2019). 

- 15 J. Riemensberger, A. Lukashchuk, M. Karpov, W. Weng, E. Lucas, J. Liu, and T. J. Kippenberg, Nature **581** , 164 

8 

(2020). 

- 16 D. T. Spencer, T. Drake, T. C. Briles, J. Stone, L. C. Sinclair, C. Fredrick, Q. Li, D. Westly, B. R. Ilic, A. Bluestone, N. Volet, T. Komljenovic, L. Chang, S. H. Lee, D. Y. Oh, M.-G. Suh, K. Y. Yang, M. H. P. Pfeiffer, T. J. Kippenberg, E. Norberg, L. Theogarajan, K. Vahala, N. R. Newbury, K. Srinivasan, J. E. Bowers, S. A. Diddams, and S. B. Papp, Nature **557** , 81 (2018). 

- 17 J. Feldmann, N. Youngblood, M. Karpov, H. Gehring, X. Li, M. Stappers, M. Le Gallo, X. Fu, A. Lukashchuk, A. S. Raja, J. Liu, C. D. Wright, A. Sebastian, T. J. Kippenberg, W. H. P. Pernice, and H. Bhaskaran, Nature **589** , 52 (2021). 

- 18 X. Xu, M. Tan, B. Corcoran, J. Wu, A. Boes, T. G. Nguyen, S. T. Chu, B. E. Little, D. G. Hicks, R. Morandotti, A. Mitchell, and D. J. Moss, Nature **589** , 44 (2021). 

- 19 X. Xue, Y. Xuan, Y. Liu, P.-H. Wang, S. Chen, J. Wang, D. E. Leaird, M. Qi, and A. M. Weiner, Nature Photonics **9** , 594 (2015). 

- 20 Q.-F. Yang, X. Yi, K. Y. Yang, and K. Vahala, Nature Physics **13** , 53 (2017). 

- 21 A. Kovach, D. Chen, J. He, H. Choi, A. H. Dogan, M. Ghasemkhani, H. Taheri, and A. M. Armani, Adv. Opt. Photon. **12** , 135 (2020). 

- 22 D. J. Moss, R. Morandotti, A. L. Gaeta, and M. Lipson, Nature Photonics **7** , 597 (2013). 

- 23 Y. Xuan, Y. Liu, L. T. Varghese, A. J. Metcalf, X. Xue, P.H. Wang, K. Han, J. A. Jaramillo-Villegas, A. A. Noman, C. Wang, S. Kim, M. Teng, Y. J. Lee, B. Niu, L. Fan, J. Wang, D. E. Leaird, A. M. Weiner, and M. Qi, Optica **3** , 1171 (2016). 

- 24 X. Ji, F. A. S. Barbosa, S. P. Roberts, A. Dutt, J. Cardenas, Y. Okawachi, A. Bryant, A. L. Gaeta, and M. Lipson, Optica **4** , 619 (2017). 

- 25 J. Liu, G. Huang, R. N. Wang, J. He, A. S. Raja, T. Liu, N. J. Engelsen, and T. J. Kippenberg, arXiv **2005.13949** (2020). 

- 26 Z. Ye, K. Twayana, P. A. Andrekson, and V. TorresCompany, Opt. Express **27** , 35719 (2019). 

- 27 H. Jung, K. Y. Fong, C. Xiong, and H. X. Tang, Opt. Lett. **39** , 84 (2014). 

- 28 X. Liu, Z. Gong, A. W. Bruch, J. B. Surya, J. Lu, and H. X. Tang, arXiv **2012.13496** (2020). 

- 29 Y. He, Q.-F. Yang, J. Ling, R. Luo, H. Liang, M. Li, B. Shen, H. Wang, K. Vahala, and Q. Lin, Optica **6** , 1138 (2019). 

- 30 C. Wang, M. Zhang, M. Yu, R. Zhu, H. Hu, and M. Loncar, Nature Communications **10** , 978 (2019). 

- 31 Z. Gong, X. Liu, Y. Xu, and H. X. Tang, Optica **7** , 1275 (2020). 

- 32 M. Pu, L. Ottaviano, E. Semenova, and K. Yvind, Optica **3** , 823 (2016). 

- 33 L. Chang, W. Xie, H. Shu, Q.-F. Yang, B. Shen, A. Boes, J. D. Peters, W. Jin, C. Xiang, S. Liu, G. Moille, S.-P. Yu, X. Wang, K. Srinivasan, S. B. Papp, K. Vahala, and J. E. Bowers, Nature Communications **11** , 1331 (2020). 

- 34 G. Moille, L. Chang, W. Xie, A. Rao, X. Lu, M. Davanço, J. E. Bowers, and K. Srinivasan, Laser & Photonics Reviews **14** , 2070043 (2020). 

- 35 D. J. Wilson, K. Schneider, S. Hönl, M. Anderson, Y. Baumgartner, L. Czornomaz, T. J. Kippenberg, and P. Seidler, Nature Photonics **14** , 57 (2020). 

- 36 D. M. Lukin, C. Dory, M. A. Guidry, K. Y. Yang, S. D. Mishra, R. Trivedi, M. Radulaski, S. Sun, D. Vercruysse, 

   - G. H. Ahn, and J. Vučković, Nature Photonics **14** , 330 (2020). 

- 37 F. Gyger, J. Liu, F. Yang, J. He, A. S. Raja, R. N. Wang, S. A. Bhave, T. J. Kippenberg, and L. Thévenaz, Phys. Rev. Lett. **124** , 013902 (2020). 

- 38 D. Huang, M. A. Tran, J. Guo, J. Peters, T. Komljenovic, A. Malik, P. A. Morton, and J. E. Bowers, Optica **6** , 745 (2019). 

- 39 K. A. McKinzie, C. Wang, A. A. Noman, D. L. Mathine, K. Han, D. E. Leaird, G. E. Hoefler, V. Lal, F. Kish, M. Qi, and A. M. Weiner, Opt. Express **29** , 3490 (2021). 

- 40 J. Liu, E. Lucas, A. S. Raja, J. He, J. Riemensberger, R. N. Wang, M. Karpov, H. Guo, R. Bouchand, and T. J. Kippenberg, Nature Photonics **14** , 486 (2020). 

- 41 W. Liang, D. Eliyahu, V. S. Ilchenko, A. A. Savchenkov, A. B. Matsko, D. Seidel, and L. Maleki, Nature Communications **6** , 7957 (2015). 

- 42 N. G. Pavlov, S. Koptyaev, G. V. Lihachev, A. S. Voloshin, A. S. Gorodnitskiy, M. V. Ryabko, S. V. Polonsky, and M. L. Gorodetsky, Nature Photonics **12** , 694 (2018). 

- 43 B. Stern, X. Ji, Y. Okawachi, A. L. Gaeta, and M. Lipson, Nature **562** , 401 (2018). 

- 44 B. Shen, L. Chang, J. Liu, H. Wang, Q.-F. Yang, C. Xiang, R. N. Wang, J. He, T. Liu, W. Xie, J. Guo, D. Kinghorn, L. Wu, Q.-X. Ji, T. J. Kippenberg, K. Vahala, and J. E. Bowers, Nature **582** , 365 (2020). 

- 45 A. S. Raja, A. S. Voloshin, H. Guo, S. E. Agafonova, J. Liu, A. S. Gorodnitskiy, M. Karpov, N. G. Pavlov, E. Lucas, R. R. Galiev, A. E. Shitikov, J. D. Jost, M. L. Gorodetsky, and T. J. Kippenberg, Nature Communications **10** , 680 (2019). 

- 46 W. Jin, Q.-F. Yang, L. Chang, B. Shen, H. Wang, M. A. Leal, L. Wu, M. Gao, A. Feshali, M. Paniccia, _et al._ , Nature Photonics , 1 (2021). 

- 47 T. Komljenovic, M. Davenport, J. Hulme, A. Y. Liu, C. T. Santis, A. Spott, S. Srinivasan, E. J. Stanton, C. Zhang, and J. E. Bowers, Journal of Lightwave Technology **34** , 20 (2016). 

- 48 D. Liang and J. E. Bowers, Light: Advanced Manufacturing 10.37188/lam.2021.005. 

- 49 J. Zhang, G. Muliuk, J. Juvert, S. Kumari, J. Goyvaerts, B. Haq, C. Op de Beeck, B. Kuyken, G. Morthier, D. Van Thourhout, R. Baets, G. Lepage, P. Verheyen, J. Van Campenhout, A. Gocalinska, J. O’Callaghan, E. Pelucchi, K. Thomas, B. Corbett, A. J. Trindade, and G. Roelkens, APL Photonics **4** , 110803 (2019). 

- 50 A. W. Fang, H. Park, O. Cohen, R. Jones, M. J. Paniccia, and J. E. Bowers, Optics Express **14** , 9203 (2006). 

- 51 D. Liang and J. E. Bowers, Nature Photonics **4** , 511 (2010). 

- 52 C. Xiang, W. Jin, J. Guo, J. D. Peters, M. J. Kennedy, J. Selvidge, P. A. Morton, and J. E. Bowers, Optica **7** , 20 (2020). 

- 53 Q. Xu, B. Schmidt, S. Pradhan, and M. Lipson, Nature **435** , 325 (2005). 

- 54 G. T. Reed, G. Mashanovich, F. Y. Gardes, and D. J. Thomson, Nature Photonics **4** , 518 (2010). 

- 55 T. Hiraki, T. Aihara, K. Hasebe, K. Takeda, T. Fujii, T. Kakitsuka, T. Tsuchizawa, H. Fukuda, and S. Matsuo, Nature Photonics **11** , 482 (2017). 

- 56 X. Xie, Q. Zhou, E. Norberg, M. Jacob-Mitos, Y. Chen, Z. Yang, A. Ramaswamy, G. Fish, J. C. Campbell, and A. Beling, Journal of Lightwave Technology **34** , 73 (2016). 

- 57 J. Michel, J. Liu, and L. C. Kimerling, Nature Photonics **4** , 527 (2010). 

9 

- 58 G. Roelkens, L. Liu, D. Liang, R. Jones, A. Fang, B. Koch, and J. Bowers, Laser & Photonics Reviews **4** , 751 (2010). 

- 59 R. Jones, P. Doussiere, J. B. Driscoll, W. Lin, H. Yu, Y. Akulova, T. Komljenovic, and J. E. Bowers, IEEE Nanotechnology Magazine **13** , 17 (2019). 

- 60 J. Sun, E. Timurdogan, A. Yaacobi, E. S. Hosseini, and M. R. Watts, Nature **493** , 195 (2013). 

- 61 L. A. Coldren, S. W. Corzine, and M. Mashanovitch, _Diode lasers and photonic integrated circuits_ (Wiley, 2012). 

- 62 T. J. Kippenberg, S. M. Spillane, and K. J. Vahala, Phys. Rev. Lett. **93** , 083904 (2004). 

- 63 N. M. Kondratiev, V. E. Lobanov, A. V. Cherenkov, A. S. Voloshin, N. G. Pavlov, S. Koptyaev, and M. L. Gorodetsky, Opt. Express **25** , 28167 (2017). 

- 64 W. Liang, V. S. Ilchenko, D. Eliyahu, A. A. Savchenkov, A. B. Matsko, D. Seidel, and L. Maleki, Nature Communications **6** , 7371 (2015). 

- 65 W. Jin, D. D. John, J. F. Bauters, T. Bosch, B. J. Thibeault, and J. E. Bowers, Opt. Lett. **45** , 3340 (2020). 

- 66 A. S. Voloshin, N. M. Kondratiev, G. V. Lihachev, J. Liu, V. E. Lobanov, N. Y. Dmitriev, W. Weng, T. J. Kippenberg, and I. A. Bilenko, Nature Communications **12** , 235 (2021). 

- 67 M. Karpov, M. H. P. Pfeiffer, H. Guo, W. Weng, J. Liu, 

   - and T. J. Kippenberg, Nature Physics **15** , 1071 (2019). 

- 68 G. Huang, E. Lucas, J. Liu, A. S. Raja, G. Lihachev, M. L. Gorodetsky, N. J. Engelsen, and T. J. Kippenberg, Phys. Rev. A **99** , 061801 (2019). 

- 69 W. Jin, R. G. Polcawich, P. A. Morton, and J. E. Bowers, Opt. Express **26** , 3174 (2018). 

- 70 J. Liu, H. Tian, E. Lucas, A. S. Raja, G. Lihachev, R. N. Wang, J. He, T. Liu, M. H. Anderson, W. Weng, S. A. Bhave, and T. J. Kippenberg, Nature **583** , 385 (2020). 

- 71 L. Chang, A. Boes, P. Pintus, J. D. Peters, M. Kennedy, X.-W. Guo, N. Volet, S.-P. Yu, S. B. Papp, and J. E. Bowers, APL Photonics **4** , 036103 (2019). 

- 72 M. Zhang, B. Buscaino, C. Wang, A. Shams-Ansari, C. Reimer, R. Zhu, J. M. Kahn, and M. Lončar, Nature **568** , 373 (2019). 

- 73 A. Boes, B. Corcoran, L. Chang, J. Bowers, and A. Mitchell, Laser & Photonics Reviews **12** , 1700256 (2018). 

- 74 M. He, M. Xu, Y. Ren, J. Jian, Z. Ruan, Y. Xu, S. Gao, S. Sun, X. Wen, L. Zhou, L. Liu, C. Guo, H. Chen, S. Yu, L. Liu, and X. Cai, Nature Photonics **13** , 359 (2019). 

- 75 A. Y. Liu, S. Srinivasan, J. Norman, A. C. Gossard, and J. E. Bowers, Photon. Res. **3** , B1 (2015). 

**Supplementary Information to: Laser soliton microcombs on silicon** 

- Chao Xiang,<sup>1,</sup><sup>_∗_</sup> Junqiu Liu,<sup>2,</sup><sup>_∗_</sup> Joel Guo,<sup>1</sup> Lin Chang,<sup>1</sup> Rui Ning Wang,<sup>2</sup> Wenle Weng,<sup>2</sup> Jonathan Peters,<sup>1</sup> Weiqiang Xie,<sup>1</sup> Zeyu Zhang,<sup>1</sup> Johann Riemensberger,<sup>2</sup> Jennifer Selvidge,<sup>3</sup> Tobias J. Kippenberg,<sup>2,</sup><sup>_†_</sup> and John E. Bowers<sup>1, 3,</sup><sup>_‡_</sup> 

      - 1 _ECE Department, University of California Santa Barbara, Santa Barbara, CA 93106, USA_ 

   - 2 _Institute of Physics, Swiss Federal Institute of Technology Lausanne (EPFL), CH-1015 Lausanne, Switzerland_ 

      - 3 _Materials Department, University of California Santa Barbara, Santa Barbara, CA 93106, USA_ 

2 

# **I. DETAILED DEVICE FABRICATION** 

The full fabrication process of laser soliton microcomb devices starts with a 100 mm-diameter, patterned Si3N4 wafer fabricated using the photonic Damascene process, as described by the main text. After the second CMP on the SiO2 spacer, the wafer front-side surface is sufficiently smooth with less than 0.3 nm RMS roughness. Vertical channels for outgassing, comprising bars of 1 _µ_ m width, are etched with 500 nm depth in the open zoom on the SiO2<sup>1</sup> spacer. After RCA cleaning, we bond a 60 _×_ 60 mm<sup>2</sup> SOI piece on the Si3N4 wafer using plasma-assisted direct wafer bonding. Larger SOI pieces can be used in the future to enable more device throughput. After 2 hours annealing of the bonded substrate at 300<sup>_◦_</sup> C, the Si substrate of the SOI piece is mechanically lapped down to around 80 _µ_ m thickness, followed by Si Bosch process to remove the remaining Si substrate. The 1 _µ_ m thick buried oxide layer is then removed by buffered hydrofluoric acid, leaving only the Si device layer on the Si3N4 substrate for the following steps. 

The Si device layer is 500 nm thick. DUV-stepper lithography (ASML PAS 5500/300, 248 nm) is used to pattern the Si devices, which are then etched into the Si layer from the photoresist mask. Three etch depths are used for the Si devices. The hybrid InP/Si section, phase tuner section, and Si waveguide section have an etch depth around 231 nm, which is controlled during the Si etch using an etch monitor (Intellemetrics LEP50). The 231 nm etch depth thus creates a 269-nm-thick Si layer. On this layer, the Si waveguide is etched and tapered from 400 nm to 200 nm wide for the mode transition between the Si waveguide and the Si3N4 waveguide underneath. Electron beam lithography (EBL) is used to pattern the grating holes on this layer alongside the hybrid InP/Si waveguide section, with 238 nm pitch size and a fill factor around 0.5. The final step for the Si layer processing is to etch 500 nm deep vertical outgassing channels for bonding with InP MQW epi wafers. 

Multiple cleaved InP MQW epi dies are selectively bonded to active regions covering the laser gain areas. The bonded wafer is then annealed at 300<sup>_◦_</sup> C again for 2 hours, and InP substrate material is mechanically lapped down to 60 _µ_ m. The remaining InP substrate removal is performed by using 3:1 hydrochloric acid (HCl)/H2O, such that the wet-etch stops at the P-doped InGaAs layer. InP processing then starts with P-type contact metal deposition (the layer stack is Pd/Ti/Pd/Au with 3/17/17/200 nm thickness, respectively). Afterwards, the InP mesa undergoes three etches: P-type InP dry etch using methane/hydrogen/argon, MQW wet etch using H2O/ hydrogen peroxide (H2O2)/ phosphoric acid (H3PO4) solution, and then N-type InP dry etch using methane/hydrogen/argon. After the InP mesa formation, N-type contact metal (Pd/Ge/Pd/Pt/Au, of 10/110/25/200/1000 nm thickness, respectively) and a second-layer P metal (Ti/Pt/Au, 20/200/1300 nm) are deposited. In addition to Si/Si3N4 tapers, excess bonded Si on top of Si3N4 is removed by XeF2 isotropic gas etch. Deuterated SiO2 of around 900 nm thickness is then deposited<sup>2</sup> 



<!-- Start of picture text -->
H + H +<br>H + H + H +<br>H + HH ++ H +<br><!-- End of picture text -->



**Supplementary Figure** 1. **Extended InP processing flow** . From the left to right columns: InP bonding and substrate removal (top), P-contact metal deposition (middle), P-type InP etch (bottom); MQW etch (top), N-type InP etch (middle), N-contact metal deposition (bottom); Excess Si removal (top), via oxide deposition (middle), via open etch (bottom); Proton implantation (top), heater metal deposition (middle), probe metal deposition (bottom). 

3 

as the via oxide, which is opened at selected P- and N-metal regions by SiO2 dry etch. Proton implantation follows the via oxide open at the InP mesa region. Heaters (Ti/Pt, 10/100 nm) and probe metals (Ti/Au, 23/1500 nm) are deposited. Finally, the entire 4-inch wafer is diced into multiples dies for testing, followed by the laser facet polishing. During the process, all the metal depositions are performed using electron beam deposition. The extended InP processing with cross-sectional views is shown in Supplementary Fig. 1. 

# **II. MEASUREMENTS OF SI** 3 **N** 4 **MICRORESONATOR** _Q_ 

The threshold power for Kerr parametric oscillation<sup>3</sup> is proportional to 1 _/Q_<sup>2</sup> . Therefore for soliton microcomb generation, it is critical to achieve high microresonator _Q_ . This requires: 1. Using the optimized photonic Damascene process<sup>4,5</sup> to achieve the lowest loss possible (thus the highest _Q_ ) in the Si3N4 PIC before the SOI bonding; and 2. Minimizing extra loss introduced during the back-end InP/Si laser processing. Both require us to carefully design and perform the fabrication process. 

To measure the Si3N4 microresonator _Q_ factor of the final chip devices with integrated InP/Si lasers, chips are diced such that light can be coupled into and out of the Si3N4 bus waveguide via edge coupling with input and output lensed fibers. We use the frequency-comb-assisted diode laser spectroscopy<sup>6,7</sup> to characterize the optical resonances of the Si3N4 microresonators and calculate the _Q_ factors. The optical transmission spectrum of the microresonator is calibrated with a self-referenced, fiber-laser-based optical frequency comb. Optical resonances are identified and fitted<sup>8</sup> , enabling extraction of the precise frequency of each resonance _ω/_ 2 _π_ , as well as the resonance’s loaded (full) linewidth _κ/_ 2 _π_ = _κ_ 0 _/_ 2 _π_ + _κ_ ex _/_ 2 _π_ , the intrinsic loss _κ_ 0 _/_ 2 _π_ and the bus-waveguide-to-microresonator external coupling strength _κ_ ex _/_ 2 _π_<sup>9</sup> . Here we mainly analyze the intrinsic loss _κ_ 0 _/_ 2 _π_ that directly reflects the quality of our fabrication process. As shown in Supplementary Fig. 2(a), for the fundamental transverse-electric mode (TE00 mode) of the microresonator, the histograms of _κ_ 0 _/_ 2 _π_ presents a most probable value of 29 MHz, corresponding to an estimated _Q_ 0 _≈_ 6 _._ 8 _×_ 10<sup>6</sup> . To understand how much the _Q_ degrades due to the back-end InP/Si laser fabrication, we also separate a purely passive Si3N4 substrate whose fabrication is completed before the SOI bonding. For chips from this substrate, as shown in Supplementary Fig. 2(b), the histograms of measured _κ_ 0 _/_ 2 _π_ presents a most probable value of 19.5 MHz, corresponding to an estimated _Q_ 0 _≈_ 10 _._ 2 _×_ 10<sup>6</sup> . We note that, due to the absence of top SiO2 cladding in the current case, the _Q_ 0 value is lower than our previous results (e.g. Ref.<sup>5</sup> , _Q_ 0 _>_ 30 _×_ 10<sup>6</sup> ) using fully SiO2-cladded Si3N4. Therefore, with this comparison of _κ_ 0 _/_ 2 _π_ values, we conclude that the microresonator _Q_ indeed degrades due to the following InP/Si laser process. Nevertheless, the current _Q_ value is sufficient for soliton generation of 100 GHz repetition rate. For future work requiring higher _Q_ for e.g. microwave-repetition-rate solitons<sup>10</sup> , thicker SiO2 spacer between the Si3N4 layer and Si layer is desired. In addition, Si removal and cleaning methods can be further optimized. 



<!-- Start of picture text -->
a b<br>Final Si3N4 chip  Passive Si3N4 chip<br>with InP/Si laser without InP/Si laser<br>0 0<br>0 10 20 30 40 50 0 10 20 30 40 50<br>Intrinsic linewidth κ0 / 2π  (MHz) Intrinsic linewidth κ0 / 2π  (MHz)<br>40 40<br>30 30<br>20 20<br>10 10<br>Number of resonances Number of resonances<br><!-- End of picture text -->

**Supplementary Figure** 2. **Histogram of measured intrinsic loss** _κ_ 0 _/_ 2 _π_ **of Si** 3 **N** 4 **microresonators at different stage during fabrication. (a)** For the Si3N4 chip with integrated InP/Si lasers, the most probable value of _κ_ 0 _/_ 2 _π_ is 29 MHz, corresponding to an estimated _Q_ 0 _≈_ 6 _._ 8 _×_ 10<sup>6</sup> . **(b)** For the Si3N4 chip without integrated InP/Si lasers (i.e. purely passive devices), the most probable value of _κ_ 0 _/_ 2 _π_ is 19 MHz, corresponding to an estimated _Q_ 0 _≈_ 10 _._ 2 _×_ 10<sup>6</sup> . Therefore, _Q_ degradation due to the back-end InP/Si laser fabrication is observed and with further optimization the soliton threshold can be lowered in future devices. 

4 

# **III. PHASE NOISE MEASUREMENT USING PHASE RETRIEVAL METHOD** 

The laser phase noise spectra of the center laser line (pump) and the comb line are measured with a commercial phase noise analysis system (PNA, OEWaves4000) and plotted in Fig. 4 of the main manuscript. We find that the suppression of phase and frequency noises due to the self-injection locking depends strongly on the offset frequency, and ranges from 10 dB at 1 kHz Fourier offset frequency to 30 dB at offset frequencies above 10 MHz. The PNA system uses the delayed-homodyne technique to determine the laser phase and frequency noises. It is well known that such systems have limitations in the measurement of narrow-band laser linewidths, and introduce additional highfrequency peaks that are harmonics of the free spectral range of the employed interferometer<sup>11</sup> . In order to benchmark and verify the results of the PNA, we perform a second measurement of the self-injection-locked laser frequency noise by recording a heterodyne beatnote with a second low-noise laser (OEWaves OE4030) on a fast photodetector. The 41 GHz beatnote is down-mixed to 60 MHz and sampled with a low-noise sampling oscilloscope at 125 MHz. A high-pass filter removes the laser intensity noises. The quadature signal of this beatnote is reconstructed via the Hilbert transform 



<!-- Start of picture text -->
Φ( t ) = arctan H ( U ( t )) (1)<br>U ( t )<br><!-- End of picture text -->

The instantaneous phase can be inferred from the In-phase and Quadrature components directly, and the carrier frequency of the heterodyne beat is removed by subtraction of a linear function. The power spectral density of the phase noise is obtained using Welch’s method of windowed Fourier transform and successive averaging. 

# **IV. SIMULATION OF MICROCOMB GENERATION VIA LASER SELF-INJECTION LOCKING** 

We numerically simulate the dynamics of the self-injection-locked-laser-microcomb system using coupled equations that include both the semiconductor laser rate equations and the coupled intracavity field equations for countercirculating fields in the Kerr-nonlinear microresonator. The coupled equations are written as: 



<!-- Start of picture text -->
dN<br>(2)<br>dt = eV I − γN − aV  ( N − N 0) |E laser | 2<br><!-- End of picture text -->



<!-- Start of picture text -->
dE laser<br>=<br>dt � 21 (1  − iα )( aV  ( N − N 0)  − κ )  − i ∆ ω � E laser +  η − 1 κ inj e iθ A ccw (3)<br><!-- End of picture text -->



<!-- Start of picture text -->
∂A∂t cw − i 1 2 D 2 ∂∂φ 2 A 2 cw − ig ( |A cw | 2 + 2 |A ccw | 2 ) A cw = − � κ 2r +  i ( ω 0  − ω laser) � A cw +  iκ sc A ccw +  ηκ inj e iθ E laser (4)<br><!-- End of picture text -->

|Symbol|Value|Unit|Definition|
|---|---|---|---|
|_α_|5||Linewidth enhancement factor|
|_a_|1_×_10<sup>4</sup>|s<sup>_−_1</sup>|Differential gain|
|_N_0|1_×_10<sup>24</sup>|m<sup>_−_3</sup>|Carrier density at transparency|
|_κ_|1_×_10<sup>11</sup> _×_2_π_|rad_·_s<sup>_−_1</sup>|Laser cavity loss rate|
|_I_|0_._24|A|Laser biased current|
|_γ_|1_×_10<sup>9</sup>|s<sup>_−_1</sup>|Carrier recombination rate|
|_V_|2_×_10<sup>_−_16</sup>|m<sup>3</sup>|Volume of active section|
|_e_|1_._6_×_10<sup>_−_19</sup>|C|Elementary electronic charge|
|_κ_r|150_×_10<sup>6</sup> _×_2_π_|rad_·_s<sup>_−_1</sup>|Loaded loss rate|
|_κ_sc|20_×_10<sup>6</sup> _×_2_π_|rad_·_s<sup>_−_1</sup>|cw-ccw coupling rate|
|_κ_inj|4_._75_×_10<sup>8</sup> _×_2_π_|rad_·_s<sup>_−_1</sup>|Laser-microresonator coupling rate|
|_g_|1_._866|rad<sup>_−_1</sup>|single-photon induced Kerr shift|
|_D_2|1_×_10<sup>6</sup> _×_2_π_|rad<sup>2</sup>_·_s<sup>_−_1</sup><br>|Dispersion coefficient|
|_η_|2_._676_×_10<sup>_−_7</sup>|m<br>3<br>2|conversion factor|



Table I. Values and definitions of parameters used in the simulations. 

5 



<!-- Start of picture text -->
6 1<br>0.9<br>5<br>0.8<br>0.7<br>4<br>0.6<br>3 0.5<br>0.4<br>2<br>0.3<br>0.2<br>1<br>0.1<br>0<br>1.5 1 0.5 0 -0.5 -1 -1.5 -2 -2.5<br>Laser cavity resonance offset (GHz)<br> (radian)<br>Microcomb power (arb. units)<br>Optical feedback phase<br><!-- End of picture text -->

**Supplementary Figure** 3. **Simulated microcomb power generation with varied optical feedback phase and laser cavity resonance offset.** The microcomb power is derived using intracavity power excluding the power in the pumped mode. The phase is varied from 0 to 2 _π_ with a step size of _π/_ 40. For each feedback phase value, the laser cavity resonance offset is scanned towards a lower frequency to reproduce the experimental conditions. 



<!-- Start of picture text -->
dA ccw |A cw | 2<br>dt − ig � |A ccw | 2 + 2 �02 π 2 π dφ � A ccw = − � κ 2r +  i ( ω 0  − ω laser) � A ccw +  iκ ∗ sc A cw 0 (5)<br><!-- End of picture text -->

where _E_ laser describes the complex laser field, _N_ is the carrier density, _α_ is the linewidth enhancement factor, _a_ is the differential gain, _V_ is the laser active volume, _N_ 0 is the carrier density at transparency, _γ_ is the carrier recombination rate, and _e_ is the elementary charge. For the microresonator, _A_ cw and _A_ ccw are the slowly varying field amplitudes of the clockwise (cw) and the counterclockwise (ccw) modes respectively, _φ_ is the azimuthal angle, _D_ 2 is the secondorder dispersion coefficient (i.e. GVD), _κ_ r is the microresonator decay rate, _g_ is the single-photon-induced frequency shift due to the Kerr effect, and _κ_ sc is the backscattering-induced coupling rate between the cw and the ccw modes. Since the optical power in the ccw mode is much weaker than the power in the laser-pumped cw mode, and is usually below the parametric four-wave-mixing threshold, here we treat the ccw field as _φ_ -independent, and only the field in the central mode of the microcomb in the frequency domain ( _A_ cw<sup>0)isdirectlycoupledto</sup><sup>_A_ccwviathe</sup> backscattering. The coupling rate between the microresonator and the laser is denoted by _κ_ inj, and _θ_ is the coupling phase determined by the optical feedback path length. In order to increase the computation efficiency, _|E_ laser _|_<sup>2</sup> is the photon density in the laser cavity for the semiconductor laser system, while _|A_ cw _|_<sup>2</sup> and _|A_ ccw _|_<sup>2</sup> are the intracavity photon numbers for the Kerr microresonator system. The parameter _η_ is introduced to the coupling between the laser and the microresonator, so the optical field profiles with different units in the laser and the microresonator are correctly related. Table I summarises the parameter values we use for the simulations. 

The coupled equations with the optical feedback phase swept from 0 to 2 _π_ are solved in the frequency domain using Runge-Kutta method to yield the temporal evolution of the laser field and the microresonator intracavity fields. At each phase value, the laser cavity resonance frequency is frequency-down-swept over a pumped microresonator mode, and complex random noise of very weak magnitude is added to the microresonator intracavity field, such that the comb formation due to modulation instability can be excited when the intracavity power level exceeds the instability threshold. Supplementary Figure 3 shows the contour plot of the simulated intracavity microcomb power (i. e., the intracavity power excluding the power in the pumped mode). This result shows that the successful microcomb generation strongly relies on the appropriate choice of the optical feedback phase, and that the comb generation pattern exhibits a _π_ -periodic dependence on the feedback phase, which are in qualitative agreement with the experimental observations shown in Fig. 4 in the main manuscript). 

In Supplementary Fig. 4, we compare in detail the system dynamics with two different feedback phases ( _θ_ = 0 _._ 2 _π_ for Supplementary Fig. 4 (a, b, c) and _θ_ = _π_ for Supplementary Fig. 4 (d, e, f)). As can be seen from the laser frequency offset (with regard to the microresonator’s cold-cavity-mode resonance frequency) curves, in both situations the laser can be self-injection locked for certain laser-microresonator frequency detuning ranges, and the laser is 

6 



<!-- Start of picture text -->
a 6 d 6<br>θ  = 0.2 π  θ  = π<br>5 5<br>4 1 4<br>3 3<br>2 2<br>1 1<br>0<br>0 0<br>1.5 1 0.5 0 -0.5 -1 -1.5 -2 -2.5 1.5 1 0.5 0 -0.5 -1 -1.5 -2 -2.5<br>Laser cavity resonance offset (GHz) Laser cavity resonance offset (GHz)<br>b 1 Total e 1 Total<br>Pumped mode excluded Pumped mode excluded<br>0.8 0.8<br>0.6 0.6<br>0.4 0.4<br>0.2 0.2<br>0 0<br>1.5 1 0.5 0 -0.5 -1 -1.5 -2 -2.5 1.5 1 0.5 0 -0.5 -1 -1.5 -2 -2.5<br>Laser cavity resonance offset (GHz) Laser cavity resonance offset (GHz)<br>c f 1.5<br>1<br>1<br>0 0.5<br>0<br>-1<br>-0.5<br>-2 -1<br>-1.5<br>-3<br>-2<br>-4 -2.5<br>1.5 1 0.5 0 -0.5 -1 -1.5 -2 -2.5 1.5 1 0.5 0 -0.5 -1 -1.5 -2 -2.5<br>Laser cavity resonance offset (GHz) Laser cavity resonance offset (GHz)<br> (radian)  (radian)<br>Intracavity power (arb. units)<br>Microresonator intracavity power (arb. units) Microresonator intracavity power (arb. units)<br>Lasing frequency offset (GHz) Lasing frequency offset (GHz)<br><!-- End of picture text -->

**Supplementary Figure** 4. **The evolution of microresonator intracavity field and the laser frequency with the feedback phase** _θ_ = 0 _._ 2 _π_ **(left column) and** _π_ **(right column), respectively. (a, d)** The spatiotemporal intracavity power evolution in the Kerr microresonator. **(b, e)** The normalized intracvity power evolution of the cw direction. **(c, f)** The lasing frequency (with regard to the cold-cavity frequency of the pumped mode in the microresonator) as the laser cavity frequency is frequency-down swept. The dashed grey lines indicate the laser frequency change when the feedback is disabled. 

slightly red-detuned (i. e., with a negative lasing frequency offset) in both cases due to the Kerr-nonlinearity-induced microresonator frequency shift. As the laser cavity resonance frequency is down-swept, in the first case the intracavity power rises, at certain point accumulating enough energy for microcomb initiation with the help of intracavity noises, while in the latter case the intracavity power level keeps decreasing, thus never reaching the threshold for microcomb generation. These behaviours have been previously well studied theoretically and numerically<sup>12,13</sup> . 

> _∗_ These authors contributed equally to this work. 

> _†_ tobias.kippenberg@epfl.ch 

> _‡_ bowers@ece.ucsb.edu 

> 1 D. Liang and J. E. Bowers, Journal of Vacuum Science & Technology B: Microelectronics and Nanometer Structures Processing, Measurement, and Phenomena **26** , 1560 (2008). 

> 2 W. Jin, D. D. John, J. F. Bauters, T. Bosch, B. J. Thibeault, and J. E. Bowers, Opt. Lett. **45** , 3340 (2020). 

7 

- 3 T. J. Kippenberg, S. M. Spillane, and K. J. Vahala, Phys. Rev. Lett. **93** , 083904 (2004). 

- 4 M. H. P. Pfeiffer, C. Herkommer, J. Liu, T. Morais, M. Zervas, M. Geiselmann, and T. J. Kippenberg, IEEE Journal of Selected Topics in Quantum Electronics **24** , 1 (2018). 

- 5 J. Liu, G. Huang, R. N. Wang, J. He, A. S. Raja, T. Liu, N. J. Engelsen, and T. J. Kippenberg, arXiv **2005.13949** (2020). 6 P. Del’Haye, O. Arcizet, M. L. Gorodetsky, R. Holzwarth, and T. J. Kippenberg, Nature Photonics **3** , 529 (2009). 

- 7 J. Liu, V. Brasch, M. H. P. Pfeiffer, A. Kordts, A. N. Kamel, H. Guo, M. Geiselmann, and T. J. Kippenberg, Opt. Lett. **41** , 3134 (2016). 

- 8 J. Liu, A. S. Raja, M. Karpov, B. Ghadiani, M. H. P. Pfeiffer, B. Du, N. J. Engelsen, H. Guo, M. Zervas, and T. J. Kippenberg, Optica **5** , 1347 (2018). 

- 9 M. H. P. Pfeiffer, C. Herkommer, J. Liu, H. Guo, M. Karpov, E. Lucas, M. Zervas, and T. J. Kippenberg, Optica **4** , 684 (2017). 

- 10 J. Liu, E. Lucas, A. S. Raja, J. He, J. Riemensberger, R. N. Wang, M. Karpov, H. Guo, R. Bouchand, and T. J. Kippenberg, Nature Photonics **14** , 486 (2020). 

- 11 H. Ludvigsen, M. Tossavainen, and M. Kaivola, Optics Communications **155** , 180 (1998). 

- N. M. Kondratiev, V. E. Lobanov, A. V. Cherenkov, A. S. Voloshin, N. G. Pavlov, S. Koptyaev, and M. L. Gorodetsky, Opt. Express **25** , 28167 (2017). 

- 13 A. S. Voloshin, N. M. Kondratiev, G. V. Lihachev, J. Liu, V. E. Lobanov, N. Y. Dmitriev, W. Weng, T. J. Kippenberg, and I. A. Bilenko, Nature Communications **12** , 235 (2021). 

