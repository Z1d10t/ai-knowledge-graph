# In situ crosslinking-assisted perovskite grain growth for mechanically robust flexible perovskite solar cells with 23.4% efficiency

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Joule |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 184 |
| 作者 | Ye-Yong Wu, Gui-Ying Xu, Jiachen Xi, Yun-Xiu Shen, Xiaoxia Wu, Xiao-Hua Tang, Jun-Yuan Ding, Heyi Yang et al. |
| DOI | 10.1016/j.joule.2022.12.013 |
| 源文件 | 058_Wu_2023_In-situ-crosslinking-assisted-perovskite-grain-g.pdf |

---
**ll** 

## Article 

In situ crosslinking-assisted perovskite grain growth for mechanically robust flexible perovskite solar cells with 23.4% efficiency 



Yeyong Wu, Guiying Xu, Jiachen Xi, ..., Ziyuan Chen, Yaowen Li, Yongfang Li 

ywli@suda.edu.cn 

Highlights 

Enhanced the crystallization of flexible perovskite 

Reduced Young’s modulus of perovskite film 

Exhibited record efficiency Exhibited excellent mechanical stability 

We proposed an in situ crosslinking strategy and carefully designed a functional monomer for tuning the perovskite growth on plastic substrates. The resultant flexible perovskite films have high crystalline quality and low Young’s modulus. The resultant flexible pero-SCs with active areas of 0.062 and 1.004 cm<sup>2</sup> achieved record PCEs of 23.4% (certified 22.9%) and 21.1%, respectively, and showed excellent mechanical stability. 

Wu et al., Joule 7, 398–415 February 15, 2023 ª 2022 Elsevier Inc. https://doi.org/10.1016/j.joule.2022.12.013 



**ll** 

#### Article 

# In situ crosslinking-assisted perovskite grain growth for mechanically robust flexible perovskite solar cells with 23.4% efficiency 

Yeyong Wu,<sup>1,5</sup> Guiying Xu,<sup>1,5</sup> Jiachen Xi,<sup>1</sup> Yunxiu Shen,<sup>1</sup> Xiaoxiao Wu,<sup>1</sup> Xiaohua Tang,<sup>1</sup> Junyuan Ding,<sup>1</sup> Heyi Yang,<sup>1</sup> Qinrong Cheng,<sup>1</sup> Ziyuan Chen,<sup>1</sup> Yaowen Li,<sup>1,2,3,6,</sup> * and Yongfang Li<sup>1,2,4</sup> 

##### SUMMARY 

Flexible perovskite solar cells (pero-SCs) are the best candidates to complement silicon solar cells in the photovoltaic market. However, their power conversion efficiencies (PCEs) and mechanical stability are far behind the industry standards because of the uncontrollable growth of perovskites on plastic substrates and intrinsically high Young’s modulus. We explored an in situ crosslinking bis((3-methyloxetan-3-yl) methyl) thiophene-2,5-dicarboxylate along with perovskite growth, and its coordination ability and crosslinking temperature enabled the fine regulation of the quality of perovskite in real time. The resultant perovskite film exhibits an enlarged grain size, compact stacking, and a preferential crystal orientation. Moreover, the crosslinked elastomer polymer gathered at the perovskite grain boundaries can effectively release the mechanical stress. As a result, the flexible pero-SC based on this perovskite film achieved a record PCE of 23.4% (certified 22.9%), which is comparable with that of the rigid device. Importantly, the flexible pero-SCs also display a robust bending durability. 

##### INTRODUCTION 

Flexible perovskite solar cells (pero-SCs) with the advantages of being light weight<sup>1,2</sup> and flexible<sup>3–5</sup> exhibit unique properties that are suitable for developing portable electronics as well as building-integrated photovoltaic (BIPV) power applications.<sup>6,7</sup> However, their power conversion efficiencies (PCEs) still significantly lag behind those of their rigid counterparts, and using polycrystalline perovskite grains with a high Young’s modulus result in brittle films. These drawbacks hinder the industrialization of flexible pero-SCs. 

The perovskite film growth is highly sensitive to the substrate matrix, and the flexible substrate with a coarse surface always induces a large number of nucleation sites, which leads to an excessive crystallization nucleation, resulting in a poor perovskite film consisting of numerous irregularly shaped small grains.<sup>8,9</sup> To reduce the nucleation sites, Lewis-base organic small molecule additives containing S, N, or O atoms with lone pair electrons have been used as molecular templates for tuning the colloid particle size of the precursor solution.<sup>10,11</sup> For example, dimethyl sulfide with S atoms was found to chelate with Pb<sup>2+</sup> ; the resulting intermediate complex increased the colloid particle size, thereby substantially reducing the number of nucleation sites. In this case, we obtain well-grown perovskite crystalline films on plastic substrates, and these films exhibit large grain sizes and dense morphologies.<sup>12</sup> However, the small molecular template undergoes a substantial diffusion and drift in the 

##### CONTEXT & SCALE 

Flexible perovskite solar cells (pero-SCs) are the best candidates to complement traditional silicon solar cells in the photovoltaic market, but problems such as uncontrolled growth of perovskite on plastic substrates and inherently high Young’s modulus need to be urgently addressed. In this work, we proposed an in situ crosslinking strategy and carefully designed functional bis((3methyloxetan-3-yl) methyl) thiophene-2,5-dicarboxylate (OETC) monomer for tuning the perovskite growth on plastic substrates. The results showed that the strategy can improve the quality of flexible perovskite films and reduce the Young’s modulus. The resultant flexible pero-SCs with active areas of 0.062 cm<sup>2</sup> achieved record efficiency of 23.4% (certified 22.9%) and showed excellent mechanical stability. Thus, we believe that the in situ crosslinking strategy is expected to promote the fabrication of flexible pero-SCs that fulfill the requirements of reallife applications. 



398 Joule 7, 398–415, February 15, 2023 ª 2022 Elsevier Inc. 

**ll** 

#### Article 

perovskite film during continuous operations, causing molecular migration between different functional layers. This molecular migration decreases the long-term stability of the pero-SCs.<sup>13,14</sup> 

In addition, a polycrystalline perovskite film contains a large number of grain boundaries, where a high Young’s modulus is usually generated, making the film more fragile and vulnerable under mechanical stress.<sup>15</sup> Therefore, it is crucial to release the grain boundary stress to decrease the Young’s modulus of the perovskite films for meeting the requirements of real-life applications.<sup>16</sup> Elastomers, such as polyurethane,<sup>11</sup> polyacrylamide, and poly(butyl acrylate),<sup>17</sup> have been used as glues to cohere the grain boundaries. The low-Young’s-modulus characteristic of the elastomers facilitates mechanical stress release for effectively decreasing the Young’s modulus of the perovskite films.<sup>18</sup> However, these mechanical mixing elastomers with long polymer chains can easily tangle the perovskite colloids, which hinders the perovskite crystal growth, resulting in an inhomogeneous and poorly crystalized perovskite film. Recently, some small crosslink monomers were introduced into the precursor solutions to avoid/relieve the influence of polymer long chains on perovskite film growth, although the crosslinking reactions were usually just triggered after completing perovskite film formation, which cannot finely regulate the growth of perovskite film in real time.<sup>19,20</sup> In other cases, the chemical crosslinking additives were introduced in the antisolvent during one step deposition method which can only just reform the top section of perovskite film and suffers from reproducibility and upscaling fabrication.<sup>21</sup> 

Here, we carefully designed functional bis((3-methyloxetan-3-yl) methyl) thiophene-2,5-dicarboxylate (OETC) as an in situ crosslinked monomer for effectively tuning PbI2 colloids and subsequently driving the perovskite growth on plastic substrates. The functional atomic skeleton of OETC was used to enhance its coordination with Pb<sup>2+</sup> ions for obtaining large-sized PbI2 colloids and reducing the number of nucleation sites. Oxetane, which exhibits a high activity, was selected as the crosslinking site to decrease the crosslinking temperature, such that both the in situ crosslinking and perovskite growth process could be triggered simultaneously. Further, driven by the in situ crosslinking, the OETC monomers adhered to the nucleation sites can promote the growth of perovskite grains by consuming the non-oriented small crystals. Notably, the crosslinking OETC (COETC) polymers filled the grain boundaries to release the mechanical stress and lowered the bending resistance of the perovskite film. As a result, the resultant flexible pero-SCs with active areas of 0.062 and 1.004 cm<sup>2</sup> achieved record PCEs of 23.4% (certified 22.9%) and 21.1%, respectively. The robust flexible pero-SCs maintained approximately 90% of their initial efficiency after 5,000 bending cycles with a radius of 5 mm, whereas an 88% efficiency retention was realized even under an extreme bending condition. 

##### RESULTS 

###### Material design and properties 

Figure 1A shows the chemical structure and synthetic route of the crosslinking monomer OETC. In this study, 2,5-thiophene carboxylate (TC) was selected as the functional skeleton, and the O atoms with lone electron pairs (Figure S1) present in the TC structure may exhibit a strong coordination ability for tuning the colloid size of the PbI2 precursor solution.<sup>20–22</sup> Oxetane was selected as the crosslinking site owing to its high activity and crosslinking temperature that is comparable with that of the thermal-assisted perovskite growth. To investigate the effect of the in situ crosslinking process on the grain growth of the perovskite films, a small molecule 

> 1Laboratory of Advanced Optoelectronic Materials, Suzhou Key Laboratory of Novel Semiconductor-optoelectronics Materials and Devices, College of Chemistry, Chemical Engineering and Materials Science, Soochow University, Suzhou 215123, China 

> 2Jiangsu Key Laboratory of Advanced Negative Carbon Technologies, Soochow University, Suzhou 215123, Jiangsu, China 

3State and Local Joint Engineering Laboratory for Novel Functional Polymeric Materials, Jiangsu Key Laboratory of Advanced Functional Polymer Design and Application, College of Chemistry, Chemical Engineering and Materials Science, Soochow University, Suzhou 215123, China 

4Beijing National Laboratory for Molecular Sciences, CAS Key Laboratory of Organic Solids, Institute of Chemistry, Chinese Academy of Sciences, Beijing 100190, China 

5These authors contributed equally 6Lead contact *Correspondence: ywli@suda.edu.cn https://doi.org/10.1016/j.joule.2022.12.013 

Joule 7, 398–415, February 15, 2023 399 

**ll** 

Article 



Figure 1. Design and properties of OETC and MOTC (A) Synthetic routes of MOTC and OETC. 

(B) FTIR spectra of the perovskite films with OETC after thermal annealing at different temperatures. 

(C) FTIR spectra of the OETC and PbI2-OETC films. 

(D) XPS spectra of Pb 4f for the PbI2-pristine and PbI2-OETC films. 

(E and F) DLS measurements in DMF, and the top-view SEM images of PbI2-pristine and PbI2-OETC (scale bar is 500 nm). 

(G) Schematic diagram of the formation of PbI2 colloidal dispersion from PbI2-pristine and PbI2-OETC. 

bis(3-methoxypropyl) thiophene-2,5-dicarboxylate (MOTC), which has a structure similar to that of OETC but lacks crosslinking moieties, was also synthesized for comparison (Figure 1A, down). The details of the synthesis process are described in supplemental information. The molecular structures were confirmed by<sup>1</sup> H and<sup>13</sup> C nuclear magnetic resonance (NMR) spectrum and mass spectroscopy (MS) (Figures S2–S7). 

Fresh OETC is a sticky liquid at room temperature, and this state can be maintained even after adding 5 wt % of an initiator (diphenyliodonium hexafluorophosphate, DH) and thermal annealing at 70<sup>�</sup> C for 5 min (Figure S8A). When the temperature was continuously increased up to 110<sup>�</sup> C, the liquid OETC gradually hardened, and then completely transformed to a white solid until the temperature reached 

400 Joule 7, 398–415, February 15, 2023 

**ll** 

#### Article 

150<sup>�</sup> C (Figure S8B), suggesting that a crosslinking process occurred with the increasing temperature. This assumption was confirmed by the the cyclic oxetane groups (the crosslinking site) at 1,270 and 820 cm<sup>�1</sup> in the Fourier transform infrared (FTIR) spectra of the sample heated from room temperature to 70<sup>�</sup> C for 5 min (Figure S9). The intensity of the cyclic oxetane characteristic peaks began to decline at 110<sup>�</sup> C and disappeared completely at 150<sup>�</sup> C for 5 min. These results indicate that the OETC crosslinking process could be accurately controlled by simply tuning the annealing temperature. Interestingly, the crosslinking temperature of 150<sup>�</sup> C is consistent with the annealing temperature of the perovskite film.<sup>23</sup> 

We further analyzed whether this crosslinking can occur during the perovskite film growth on the plastic substrate. A two-step processing was employed to fabricate the FA0.92MA0.08PbI3 perovskite film. The PbI2 layer was first prepared by spincoating the PbI2 precursor solution on the plastic substrate. Both OETC:DH and MOTC were added to the precursor solution and then annealed at 70<sup>�</sup> C for 1 min. Next, the FAI:MAI:MACl precursor solution was spin-coated onto the formed PbI2 layers, followed by thermal annealing at 150<sup>�</sup> C for 15 min. The PbI2 samples with MOTC and OETC were labeled as PbI2-MOTC and PbI2-OETC, respectively, whereas the pristine PbI2 sample was denoted as PbI2-pristine. The corresponding perovskite films were named as pero-MOTC, pero-COETC, and pero-pristine, respectively. The FTIR measurements revealed that the vibration peaks (1,270 and 820 cm<sup>�1</sup> ) ascribed to the crosslinking site cyclic oxetane groups still existed in the spectrum of the PbI2-OETC film (Figure S10), indicating that the crosslinking did not during the PbI2 layer preparation. However, these characteristic peaks gradually disappeared with the temperature increased from room temperature to 150<sup>�</sup> C, and only the vibration peak of thiophene (1,249 cm<sup>�1</sup> ) remained in the spectra of the perovskite film with OETC (Figure 1B), indicating that under the thermal-annealing temperature stress, OETC undergoes a sufficient in situ crosslinking accompanied by the perovskite film growth.<sup>24</sup> In addition, the vibration peaks assigned to –C=O (1,724 cm<sup>�1</sup> ) of OETC shifted from 1,724 to 1,713 cm<sup>�1</sup> after the blending with PbI2 (Figure 1C), suggesting that the –C=O bond of OETC could coordinate with the Pb<sup>2+</sup> of PbI2 because the lone electron pair on the carboxylic group delocalized to the empty orbit of Pb<sup>2+</sup> .<sup>25,26</sup> The obvious shift of the Pb 4f peak, in the X-ray photoelectron spectroscopy (XPS) profile of the PbI2-OETC film, to a lower binding energy further confirmed this result (Figure 1D).<sup>27,28</sup> 

Before depositing precursor solution, the substrate that highly determined the wetting properties was first investigated.<sup>29</sup> As shown in Figure S11A, the contact angles of various PbI2 precursor solutions on PET/ITO and glass/ITO substrates that coating with SnO2 exhibited similar wetting properties but with large contact angles around 30<sup>�</sup> . This result indicated that the MOTC and OETC with low content (0.6 mg/mL) has less influence on the wetting properties. As for the poor wetting properties, the UVozone treatment was further conducted to decrease the contact angles as low as around 2<sup>�</sup> (Figure S11B). The enhanced wetting properties is benefit in dispersing the colloids formed in the PbI2 precursor solutions. We then evaluated the effect of MOTC and OETC on the perovskite growth via dynamic light scattering (DLS) measurements to characterize the colloids formed in the PbI2 precursor solutions, which plays a critical role in the sequent perovskite growth. The PbI2 colloids in dimethyl-formamide (DMF) are reportedly exfoliated by the DMF molecules because of the coordination interaction between nitrogen in DMF and Pb<sup>2+</sup> in PbI2. The synthesized PbI2 colloids exhibited a flakelet framework composed of (001) planes with longitudinal and lateral dimensions of �1 and >100 nm, respectively, as evidenced from the DLS measurements.<sup>30</sup> As shown in Figure 1E, the 

Joule 7, 398–415, February 15, 2023 401 

**ll** 

Article 

pristine PbI2 precursor solution showed a longitudinal dimension of 0.7 nm and a lateral dimension of 244 nm, which increased to 1.6 and 756 nm, respectively, after incorporating OETC (Figure 1F). We speculate that the enlarged colloids can be attributed to the reduced surface energy of the colloids due to the formation of coordination bonds between the –C=O group and Pb<sup>2+</sup> ; these coordination bonds may weaken the coordination interaction between Pbl2 and DMF.<sup>30–32</sup> Figure 1G shows the schematic diagram of the formation of PbI2 colloidal dispersion. Similar behavior was also observed in the MOTC-blended PbI2 solution, which produced colloids with an enlarged longitudinal dimension of 1.3 nm and lateral dimension of 750 nm (Figure S12). The colloids with different dimensions could significantly influence the nucleation sites of PbI2. Thus, we performed in situ optical microscopy images to monitor the PbI2-pristine and PbI2-OETC films during the solvent evaporation process (Figure S13). The PbI2 crystal nucleus gradually appeared during the solvent evaporation. For the PbI2-pristine film, crystal nucleus was uniformly and densely distributed over the whole surface, and the subsequent crystal growth was almost along the previous nucleus, leading to a compact PbI2 film. On the contrary, the sparser PbI2 crystal nucleus was observed in the PbI2-OETC film, leading to a porous film. The morphology of the obtained PbI2 film was further confirmed by scanning electron microscopy (SEM). The PbI2-pristine film deposited on the plastic substrate exhibited a compact morphology with a small number of pin-holes, consistent with the previous reports. By contrast, the PbI2-MOTC and PbI2-OETC films contained a large number of pin-holes (Figures 1E, 1F, S12, and S14). The porosity of PbI2-pristine, PbI2-MOTC, PbI2-OETC films are then calculated (Figure S15). The relatively higher porosities of PbI2-MOTC and PbI2-OETC films further confirm the formation of mesoporous scaffold in PbI2 film after incorporating MOTC or OETC, which is attributed to the enlarged PbI2 colloid as well as the reduced density of the PbI2 crystal nucleus. 

###### Mechanism of in situ crosslinking strategy 

Subsequently, after coating the FAI:MAI:MACl precursor solution on the prepared PbI2 films (PbI2, PbI2-MOTC, and PbI2-OETC), temperature-dependent X-ray diffraction (XRD) analysis was performed to examine the influence of MOTC and OETC on the crystallization process of the perovskite films (Figure S16). No new Bragg peak or peak shift was observed in the XRD profiles of the pero-MOTC and pero-COETC films at any stage (corresponding to different thermal annealing temperatures), indicating that both MOTC and OETC did not enter into the perovskite crystal lattice during the film growth. Furthermore, all the as-cast perovskite film samples showed obvious d-phase-perovskite and PbI2 characteristic peaks, indicating the formation of a partial perovskite phase at 25<sup>�</sup> C. It has been reported that the PbI2 conversion efficiency to perovskite was largely dependent on the morphology of PbI2 film.<sup>33–35</sup> Compared with the compact PbI2 film, the meso-porous scaffold can offer sufficient room for organic salts penetration into PbI2 film. Thus, the PbI2-MOTC and PbI2OETC films facilitate FA/MA cation efficient penetration and complete reaction, giving the obviously lowed PbI2 peak intensity and enhanced d-phase perovskite peak intensity compared with those in pero-pristine film. With the increasing temperature, the d-phase perovskite gradually transformed to the a-phase (13.7<sup>�</sup> ). As the temperature reached 150<sup>�</sup> C, the d-phase characteristic peak (11.5<sup>�</sup> ) completely disappeared; at this temperature, OETC simultaneously finished crosslinking. Differently, the pero-COETC film showed a higher a-phase peak intensity than did the peroMOTC film, demonstrating that the in situ crosslinking can assist the perovskite film crystallization. The temperature-dependent evolution of the perovskite films was further evaluated by SEM measurements. As shown in Figure S17, a large number of bright grains ascribed to PbI2 was observed in the pero-pristine films, even 

402 Joule 7, 398–415, February 15, 2023 

**ll** 

#### Article 



Figure 2. The effect of in situ crosslinking strategy on perovskite growth was studied by GIWAXS (A–C) 2D GIWAXS patterns of pero-MOTC films annealed at different temperatures. (D–F) 2D GIWAXS patterns of pero-OETC films annealed at different temperatures. (G–I) Polar intensity profiles along the ring at q = 1.00 A<sup>˚�1</sup> for the pero-MOTC and pero-COETC films at different temperatures. 

after annealing at 150<sup>�</sup> C, although the number of PbI2 crystals were drastically reduced in the pero-MOTC and pero-COETC films at any annealing temperature, and these bright crystals almost disappeared after annealing at 150<sup>�</sup> C. As a result, the pero-MOTC and pero-COETC films exhibited significantly improved qualities with high crystallinities, enhanced compactness, and large grains. Notably, the pero-COETC films exhibited even larger grain sizes and less grain boundaries than did the pero-MOTC films when the annealing temperature reached 110<sup>�</sup> C, which was also the crosslinking temperature as demonstrated before. This result further demonstrates that the in situ crosslinking process is beneficial to the perovskite film growth. 

To reveal the relationship between the in situ crosslinking process and the crystallization of perovskite film at the microscale, we conducted grazing-incidence wide-angle X-ray scattering (GIWAXS) measurements.<sup>36</sup> Figures 2A–2F show the two-dimensional (2D) GIWAXS patterns of the pero-MOTC and pero-COETC films 

Joule 7, 398–415, February 15, 2023 403 

**ll** 

Article 

at different annealing temperatures. At 70<sup>�</sup> C, both the pero-MOTC and pero-OETC films showed similar scattering rings at q = 0.80, 0.90, and 1.00 A<sup>˚�1</sup> , which can be assigned to the d-phase perovskite, PbI2, and the a-phase perovskite, respectively. As the temperature increased to 110<sup>�</sup> C, where the crosslinking process occurred, the ring at q = 1.00 A<sup>˚�1</sup> ascribed to the (100) plane of pero-COETC became narrower than that of pero-MOTC, and this diffraction ring was further narrowed and brightened after the annealing at 150<sup>�</sup> C. These results indicate that the in situ crosslinking process can assist the perovskite film crystallization, which is consistent with the results of the XRD and SEM analyses. The polar intensity profiles of the pero-MOTC and pero-OETC films, integrated along the (100) plane (Figures 2G–2I) showed a similar polar intensity localized at 35<sup>�</sup> after the annealing at 70<sup>�</sup> C. This observation indicates that the crystal-plane stacking orientation was along the azimuth angle of 35<sup>�</sup> (Figure 2G). After the annealing at 110<sup>�</sup> C, the intensity of the peak at 35<sup>�</sup> , corresponding to the pero-COETC film, obviously increased, indicating that the in situ crosslinking process induced a more preferential crystal orientation. As expected, when the temperature was increased to 150<sup>�</sup> C, the enlarged intensity difference revealed a further enhanced crystal orientation of the pero-COETC films. The line cuts obtained from the 2D GIWAXS patterns were plotted (Figure S18) to calculate the (100)/(200) and (100)/(110) peak intensity ratios of the a-phase pero-MOTC and pero-COETC films at different annealing temperatures (Figure S19). At 70<sup>�</sup> C, the (100)/(200) intensity ratios of both pero-COETC and pero-MOTC exhibited similar values (1.13 and 1.10). Once the crosslinking occurred, the (100)/(200) ratio of the pero-COETC film increased to 1.95 at 110<sup>�</sup> C and 2.25 at 150<sup>�</sup> C. In contrast, the intensity ratios of the pero-MOTC films remained almost unchanged with the increasing annealing temperature (from 1.10 to 1.30). Furthermore, the (100)/(111) and (100)/(200) intensity ratios showed similar tendencies. These results indicate that the in situ crosslinking process can enhance the perovskite crystallinity with a preferential crystal orientation of the (100) plane along the azimuth angle at 35<sup>�</sup> . 

High-resolution transmission electron microscopy (HR-TEM) analysis was performed to investigate the crosslinking polymer distribution in the perovskite film by focusing on the grain boundary regions, as indicated by the alternating crystalline and amorphous regions (Figures 3A and 3D).<sup>37</sup> The fast Fourier transform analysis of the HRTEM images (Figures 3B and 3E) showed that the crystalline regions (highlighted regions (1) and (3)) were characterized by an interplanar spacing of 3.1 A<sup>˚</sup> , which matched well with the (100) reflection of the a-phase perovskite, suggesting that the crosslinking polymer did not enter the perovskite lattice. To deduce the composition of the two amorphous regions (highlighted regions (2) and (4)), energy-dispersive X-ray spectrometry (EDS) depth profiling (Figures 3C and 3F) was conducted along the red dashed lines shown in Figures 3B and 3E. Clearly, S, representing the crosslinking polymer, was not detected in the pero-pristine film, whereas the observed descending Pb intensity in a �20 nm width suggested that the neighboring perovskite grain boundaries were located a certain distance apart, which is consistent with the value extracted from the results shown in Figure 3B. Thus, we suppose the amorphous region is probably attributed to the amorphous carbon film, which was used as a substrate for the HR-TEM measurements.<sup>38</sup> In contrast, EDS mapping result of the pero-COETC film showed a strong S peak distributed across the grain boundaries, and the distance between the neighboring grains was narrowed to 13 nm. These results reveal that the in situ crosslinking OETC gathers along the grain boundaries and fills the gap between the neighboring grains. Moreover, the residual OETC attached to the grain boundaries and nucleation sites could further promote perovskite grain growth as well as induces the growth of close-lying grains under the crosslinking process. 

404 Joule 7, 398–415, February 15, 2023 

**ll** 

#### Article 



Figure 3. Distribution of the crosslinked OETC and schematic of in situ crosslinking strategy 

(A) HR-TEM images of the pero-pristine film. 

(B) Magnified HR-TEM images of the pero-pristine, inset: highlighted regions 1 and 2. 

(C) EDS elemental line scan profiles for the red line shown in Figure 3B. 

(D) HR-TEM images of the pero-COETC film. 

(E) Magnified HR-TEM images of the pero-COETC, inset: highlighted regions 3 and 4. 

(F) EDS elemental line scan profiles for the red line shown in Figure 3E. 

(G) Schematic of the in situ crosslinking-assisted grain growth process. 

Joule 7, 398–415, February 15, 2023 405 

**ll** 

Article 

Based on the aforementioned investigation, a possible schematic of the crosslinking-assisted grain growth process is presented in Figure 3G. The MOTC and OETC in the PbI2 precursor solution can enlarge the PbI2 colloids through coordination bonds between the –C=O group and Pb<sup>2+</sup> . In addition, the enlarged colloids could effectively reduce the density of the PbI2 crystal nucleus, leading to a mesoporous scaffold of the PbI2 film. The mesoporous PbI2 scaffold can provide sufficient room for facilitating FA/MA cation penetration and reaction, resulting in d-phase perovskite containing MOTC or OETC before annealing. During the annealing process, (100) oriented a-phase perovskite grains with the smallest surface energy grow faster and become larger crystals. For MOTC-based perovskite film, MOTC can adhere to the nucleation sites and numbers of non-oriented small crystals would be transported and distributed desultorily due to the substantial diffusion and drift of the small molecules. In contrast, the OETCbased non-oriented small crystals can directionally move to grain boundaries of the (100) oriented grains due to the triggered crosslinking reaction, leading to the continued growth of the (100) oriented grains by consuming neighboring non-oriented small crystals. As a result, COETC gathered along the grain boundaries and subsequently filled the gap between the neighboring grains. Consequently, a high-quality perovskite film with a high crystallinity, large-sized grains, less grain boundaries, and a preferential crystal orientation was obtained. 

The aforementioned results reveal that the in situ crosslinking process influences the entire perovskite film growth process, starting from the precursor colloid formation, nucleation, and finally the sequent grain growth. Thus, next, we assessed the dependence of this strategy on the substrate matrix. The perovskite films deposited on the plastic and glass substrate were compared (Figure S20). The pero-pristine film deposited on the plastic substrate showed a poor morphology with more voids and irregular small grains, compared with that grown on a glass substrate. Both the pero-MOTC and pero-COETC films deposited on flexible substrates exhibit similar morphologies compared with those on their rigid counterparts. This suggests that the organic-monomer-coordinated PbI2 colloids primarily determined the perovskite film morphology, thereby effectively weakening the substrate-matrix dependence. In addition, compared with pero-pristine and pero-MOTC, the enlarged grain size of pero-COETC, observed on the rigid glass substrate, was also maintained on the plastic substrate with an average grain size of approximately 1.0 mm (Figure S21), as evident from the XRD analysis (Figure S22). This implies that the in situ crosslinking-assisted perovskite growth is weakly dependent on the substrate matrix. The high Young’s modulus of the polycrystalline perovskite films originate from a large number of grain boundaries. Accordingly, we investigated the effect of the crosslinking polymer filled between the grains on the mechanical stress of the perovskite film, through nano-indentation measurements (Figure S23). As expected, the pero-COETC film exhibited a drastically decreased Young’s modulus of 32.5 GPa compared with that of pero-pristine film (41.2 GPa), indicating that the crosslinking OETC is beneficial for releasing the stress distributed along the grain boundaries. 

###### Photovoltaic performance 

Based on the above discussion, n-i-p flexible pero-SCs with PET/ITO/SnO2/perovskite/spiro-OMeTAD (2,2,7<sup>0</sup> ,7<sup>0</sup> -tetrakis (N, N-di-4-methoxyphenylamine)-9,9<sup>0</sup> -spirobi-fluorene)/Au structures were fabricated to evaluate the influence of this in situ crosslinking strategy on the flexible photovoltaic performance. Figure 4A presents the current density-voltage (J-V) response of the champion pero-pristine-, peroMOTC-, and pero-COETC-based flexible pero-SCs (active area: 0.062 cm<sup>2</sup> ; under AM 1.5G 1-sun illumination) obtained in the reverse scan, and the corresponding 

406 Joule 7, 398–415, February 15, 2023 

**ll** 

#### Article 



Figure 4. Photovoltaic performance of pero-SCs (A and B) J-V curves of the 0.062 and 1.004 cm<sup>2</sup> flexible pero-SCs under the illumination of AM1.5G, 100 mW/cm<sup>2</sup> , inset: photograph of the flexible peroSCs. 

(C) Statistical diagram of the device areas and PCE values obtained from the recently reported high-performance flexible pero-SCs. (D) Transient photovoltage decay of the devices. 

(E) Voc versus natural logarithm of light intensity fitted by a linear relationship. 

(F) Current-voltage curves of the electron-only devices. 

parameters are summarized in Table 1. Predictably, the flexible pero-SC with the pero-pristine film showed an inferior PCE of 20.1%, along with a short-circuit current density (Jsc) of 25.0 mA/cm<sup>2</sup> , an open-circuit voltage (Voc) of 1.08 V, and a fill factor (FF) of 74.3%. These measured values are considerably lower than those of the rigid counterpart (PCE = 22.4%). In contrast, the pero-MOTC-based pero-SC showed an enhanced PCE of 22.1%, which again confirmed that the enlarged PbI2 colloids and the reduced PbI2 crystal nucleus could weaken the dependence of the perovskite film growth on the substrate matrix. Encouragingly, when using pero-COETC as the active layer, the flexible pero-SCs delivered a remarkable PCE of 23.4%, with a Voc of 1.14 V, a Jsc of 25.1 mA/cm<sup>2</sup> , and an FF of 81.8%. To the best of our knowledge, the PCE of 23.4% is the highest reported value, to date, among those of the single-junction flexible pero-SCs (Figure 4C; Table S1). These flexible peroSCs delivered a record efficiency of 22.9% certified by the Shanghai Institute of Microsystem and Information Technology, Chinese Academy of Sciences (SIMIT) (Figure S24). Obviously, the difference between the PCEs shown by the flexible and rigid pero-SCs (PCE = 24.1%, Figure S25; Table 1) is greatly narrowed, suggesting that the in situ crosslinking strategy can facilitate the transplantation of a perovskite film from a rigid substrate to a flexible one with a negligible substrate dependence. Notably, there is still a gap in FF between flexible and rigid pero-SCs, which may be attributed to the higher sheet resistance (48 U/sq, with �80 nm thick ITO) of PET/ITO than that of glass/ITO (15 U/sq). To verify this assumption, we used another type PET/ITO (15 U/sq, with �250 nm thick ITO) as the substrate to fabricate flexible pero-SCs, and the device delivered a comparable FF with the rigid device but 

Joule 7, 398–415, February 15, 2023 407 

**ll** 

Article 

Table 1. Photovoltaic parameters of pero-SCs under AM1.5G 100 mW/cm<sup>2</sup> illumination 

|Area (cm<sup>2</sup>)|Substrate type|Active layer|Voc<br>a<br>(V)|Jsc<br>a(mA/cm2)|FF<sup>a </sup>(%)|PCE<sup>a </sup>(%)|
|---|---|---|---|---|---|---|
|0.062|glass/ITO|pero-pristine|1.09G0.03<br>(1.11)|24.3G0.8<br>(25.2)|77.8G2.1<br>(80.2)|21.9G0.5<br>(22.4)|
|||pero-MOTC|1.10G0.02<br>(1.12)|24.8G0.6<br>(25.5)|79.5G1.5<br>(81.5)|22.9G0.5<br>(23.3)|
|||pero-COETC|1.14G0.02 (1.15)|24.6G0.4<br>(25.3)|80.2G1.3<br>(82.9)|23.6G0.4<br>(24.1)|
||PET/ITO|pero-pristine|1.04G0.04<br>(1.08)|24.2G0.9<br>(25.0)|70.6G3.2<br>(74.3)|19.6G0.6<br>(20.1)|
|||pero-MOTC|1.08G0.03<br>(1.12)|24.5G0.6<br>(25.1)|75.6G2.4<br>(78.6)|21.6G0.5<br>(22.1)|
|||pero-COETC|1.13G0.02<br>(1.14)|24.8G0.3<br>(25.1)|79.5G1.5<br>(81.8)|23.0G0.4<br>(23.4)|
|1.004|glass/ITO|pero-pristine|1.08G0.05<br>(1.13)|24.3G0.7<br>(25.2)|70.2G1.5<br>(72.5)|20.0G0.7<br>(20.6)|
|||pero-MOTC|1.10G0.04|24.6G0.7|74.2G1.2|21.2G0.6|
||||(1.15)|(25.3)|(75.5)|(21.9)|
|||pero-COETC|1.15G0.02<br>(1.17)|24.8G0.3<br>(25.3)|76.0G1.1<br>(77.3)|22.3G0.5<br>(22.9)|
||PET/ITO|pero-pristine|1.03G0.05<br>(1.08)|24.0G0.9<br>(24.8)|62.2G3.0<br>(64.0)|16.3G0.9<br>(17.1)|
|||pero-MOTC|1.08G0.03<br>(1.12)|24.5G0.6<br>(25.0)|68.3G2.1<br>(70.8)|18.6G0.6<br>(19.8)|
|||pero-COETC|1.13G0.02|24.8G0.4|72.0G1.5|20.7G0.5|
||||(1.14)|(25.2)|(73.4)|(21.1)|



aAverage and standard deviation values were obtained based on over 20 cells from 3 different batches for each active layer. Parameters of the best cell are reported in brackets. 

decreased Jsc (Figure S26; Table S2). The lower Jsc is attributed to the inferior transmittance compared with that of PET/ITO (80 nm thick) and glass/ITO (Figure S27). In addition, the integrated photocurrents of all the devices, derived from the external quantum efficiency (EQE) spectra, agreed well with the values obtained from the J-V curves, within an approximate deviation of 5% (Figure S28). It is noticed that we obtained the similar Jsc of the devices based on the PET/ITO and glass/ITO, which is attributed to the high transmittance of the PET/ITO (Figure S27). Further, through calculating the hysteresis index (HI) values and maximal steady-state photocurrent output, we can conclude that the flexible and rigid devices exhibited comparable and weak hysteresis behavior. (Figures S29 and S30; Table S3). Importantly, the PCEs of the pero-SCs based on pero-COETC showed the highest reproducibility, as evidenced by their narrower distribution (Figure S31). 

The PCEs of the flexible pero-SCs are significantly dependent on the size of the active area, because controlling the surface roughness, crystal nucleation, and perovskite growth on a plastic substrate is difficult.<sup>39,40</sup> To demonstrate the advantages of the in situ crosslinking-assisted perovskite film growth, we fabricated 1.004 cm<sup>2</sup> flexible pero-SCs and analyzed their performance. The details of the electrode shape and metal grid of 1.004 cm<sup>2</sup> device are described in Note S1. As shown in Figure 4B, the PCE of the pero-COETC-based device reached 21.1%, accompanied by a Voc of 1.15 V, a Jsc of 25.2 mA/cm<sup>2</sup> , and an FF of 72.8%. These values are much higher than that of the device based on the pero-pristine film (PCE = 17.1%). Notably, the PCE of 21.1% is also the highest reported PCE to date for flexible pero-SCs with areas >1 cm<sup>2</sup> (Figure 4C; Table S1). Thus, a high-quality perovskite film is critical for obtaining high-performance flexible pero-SCs on a large area (Figures S32 and S33), as evidenced from the analysis of the 1.004 cm<sup>2</sup> rigid pero-SCs, which showed a promising PCE of 22.9% (Figure S34; Table 1). These 

408 Joule 7, 398–415, February 15, 2023 

**ll** 

#### Article 

results again confirm that the in situ crosslink-assisted perovskite films can aid in the development of high-performance flexible pero-SCs on a large area. Nevertheless, when the device area increased to 1.004 cm<sup>2</sup> , the PCE exhibited a more obvious decline (from 23.4% to 21.1%) than the rigid ones (from 24.1% to 22.9%), mainly ascribed to the decreased FF (from 81.8% to 73.4%). The seriously decreased FF is attributed to the high sheet resistance of PET/ITO (48 U/sq), which can substantially increase the series resistance (Rs) of the devices from 2.254 to 15.261 U/cm<sup>2</sup> as the areas increased.<sup>41–43</sup> We then use the 250 nm ITO flexible electrode with a low sheet resistance of 15 U/sq to fabricate devices, and the FF decline can be effectively alleviated from 82.6% to 76.9% as the device areas enlarged to 1.004 cm<sup>2</sup> (Figure S35; Table S2). Because the low sheet resistance of PET/ITO (250 nm) electrode can reduce the Rs increase by 2.617 U/cm<sup>2</sup> , which is much lower than that of PET/ITO (80 nm) based flexible device (13.007 U/cm<sup>2</sup> ) and comparable with that of glass/ITObased device (1.496 U/cm<sup>2</sup> ) as shown in Table S4. These results mean that the PCE of the large-area flexible pero-SCs could be further increased by using a high-quality flexible electrode with high transmittance and low sheet resistance at the same time. 

To further understand the enhanced photovoltaic performance of the flexible pero-SCs with in situ crosslinked OETC, the charge dynamics of the devices were investigated. It was found that the photocurrent decay time of the devices was drastically reduced from 1.02 to 0.42 ms after the incorporation of the in situ crosslinked OETC in the perovskite films (Figure S36). The faster photocurrent decay indicates that the photogenerated charges can be more efficiently collected because of the enhanced quality of the perovskite film; this is in agreement with the increased FF. The transient photovoltage decay measurements (Figure 4D) showed that the pero-COETC-based device could also prolong the photovoltage decay time, indicating that the in situ crosslinked OETC suppressed carrier recombination in the pero-SC; this result is consistent with the increased Voc. This behavior was also demonstrated by the light-intensity-dependent J-V characteristics, where the Voc versus the seminatural logarithm of light intensity (Figure 4E) showed a linear relationship with a slope of 1.11 kT/q for the pero-COETC-based device; this slope value was much lower than that obtained for the pero-pristine-based device (1.98 kT/q). In addition, the trap density variation of the devices is calculated by the space charge limited current (SCLC) method, and the detailed calculation process was added in Note S2. The three perovskite films (pero-pristine, pero-MOTC, and peroCOETC) showed gradually decreasing trap densities (nt), from 6.64 3 10<sup>15</sup> to 3.82 3 10<sup>15</sup> cm<sup>�3</sup> (Figure 4F). Therefore, we assume that the suppressed carrier recombination can be attributed to the decreased trap density, which results from the improved quality of the perovskite film containing large grains and a small number of grain boundaries. 

###### Mechanical and environmental stabilities 

Finally, we evaluated the effect of the in situ crosslinked OETC on the mechanical and environmental stabilities of the flexible pero-SCs. As shown in Figure 5D, the flexible pero-SC based on the pero-pristine film could retain only 41% of its initial PCE just after 2,000 bending cycles at a radius of 5 mm, whereas a 64% PCE retention was observed for the pero-MOTC device. Notably, the device based on the pero-COETC film maintained 93% of its initial PCE even after 5,000 bending cycles. The bending test performed at different bending radius (Figure 5E) revealed that the pero-COETC-based device could still retain 88% of its initial PCE even under an extreme bending radius of 2 mm after 1,200 bending cycles. This retained PCE fraction is much higher than those retained by the other two devices (19% and 8%). It is noted that the thickness of ITO we used in this work is only �80 nm (Figure S37), much thinner than that of the mostly used ITO coated on PET (�300 nm).<sup>44–46</sup> We tested the sheet resistance of PET/ITO by a four-point probe system after bending for 1,200 cycles at different bending radius 

Joule 7, 398–415, February 15, 2023 409 

**ll** 

#### Article 



Figure 5. The effect of the in situ crosslinked OETC on the mechanical stability (A–C) Top-view SEM images of the pero-pristine, pero-MOTC, and pero-COETC films after 2,000 bending cycles with a radius of 5 mm. (D) PCE of the flexible pero-SCs versus bending cycles at a radius of 5 mm. (E) PCE decay of the flexible pero-SCs versus bending radius after 1,200 bending cycles. 

(F) Finite-element simulation of the flexible pero-SCs based on the pero-pristine and pero-COETC films. 

(Figure S38). There is no breakage when the radius is over 3.5 mm, evidenced by the stable sheet resistance (48 U/sq), which is also proved by the top-view SEM images of those films (Figure S39), and its sheet resistance remains at 68 U/sq even under an extreme bending radius of 2 mm, exhibiting very shallow cracks in the relevant SEM images. Therefore, the significantly improved bending durability of the pero-COETC flexible devices can be attributed to the well-maintained perovskite film. As mentioned above, the crosslinked OETC is filled in the gaps between the neighboring perovskite grains, thereby binding them together. Accordingly, we evaluated the deformation resistance of the perovskite films under mechanical stress (SEM measurements, Figures 5A–5C). Obviously, the pero-pristine film showed a poor deformation resistance, with the appearanceofseverefractures after bending 2,000 cycles ata radiusof 5 mm (Figure 5A). In contrast, the bends and deformations in the pero-MOTC film (Figure 5B) were effectively removed because of the flexible nature of the organic MOTC attached on the grain boundaries and the increased grain size. The pero-COETC film did not show any fracture during the bending tests (Figure 5C), indicating that the crosslinked OETC with elastic properties effectively released the applied stress and relieved the deformations; this agrees well with the decreased Young’s modulus of the pero-COETC film. We further 

410 Joule 7, 398–415, February 15, 2023 

**ll** 

#### Article 

used the finite-element method to simulate the stress distribution on the perovskite films under bending (Table S5; Figure 5F). The results showed that the surface of the peropristine bears a high pulling stress, whereas the SnO2/perovskite interface bears a high-pressure stress. In contrast, the crosslinked OETC filled in between the grain gaps can significantly reduce the stress distribution in the whole perovskite film; this is consistent with the morphological and mechanical measurement results. In addition, the stability of the devices stored in ambient conditions with a relative humidity of �30% was also evaluated. The pero-COETC-based pero-SC without encapsulation retained 90.7% of its initial PCE after aging for 1,000 h, whereas the device based on pero-pristine could retain only 28.6% of its initial PCE (Figure S40). The significantly enhanced ambient stability of the pero-SC based on pero-COETC could be attributed to its strong resistance to water in ambient atmosphere (Figure S41). 

##### DISCUSSION 

In summary, we explored an in situ crosslinking-assisted perovskite film growth to weaken the dependence of the growth process on the substrate matrix as well as enhance the mechanical stability of the grown film. The carefully designed functional OETC monomers facilitated the coordination of OETC with PbI2 to enlarge the colloid size and form a mesoporous PbI2 film for promoting FA/MA cation penetration and reaction. Moreover, OETC with high-reactivity crosslinking sites underwent in situ crosslinking with a simultaneous thermal-assisted perovskite film growth, and the crosslinking process drove the perovskite grain growth, leading to a large-sized grain formation and preferential orientation, through the consumption of the neighboring small non-oriented crystals. We also proved that the obtained polymers (COETC) filled the perovskite grain boundaries, which effectively released the mechanical stress and reduced the Young’s modulus of the perovskite film. As a result, the single-junction flexible pero-SC based on the in situ crosslinked-monomer-containing perovskite film achieved a record PCE of 23.4%, whereas a PCE of 21.1% was obtained for the flexible device with a large area (1.004 cm<sup>2</sup> ). More importantly, these devices displayed robust mechanical properties in terms of bending and moisture stabilities. These findings provide valuable insights on the improvement of both performance and mechanical stability of flexible pero-SCs, and the proposed in situ crosslinking-assisted perovskite film growth is expected to promote the fabrication of flexible pero-SCs that fulfill the requirements of real-life applications. 

##### EXPERIMENTAL PROCEDURES 

###### Resource availability 

Lead contact 

Further information and requests for resources and materials should be directed to and will be fulfilled by the lead contact, Yaowen Li (ywli@suda.edu.cn). 

###### Materials availability 

All the experimental procedures of the material synthesis are provided in the supplemental information. 

###### Data and code availability 

All data are included in the paper and supplemental information. Other data are available from the lead contact or the corresponding author. No code is used in this paper. 

###### Materials 

The PET/ITO substrate with the thickness of �80 nm was purchased from OIKE, and its sheet resistance is 48 U/sq. The PET/ITO substrate with the thickness of �250 nm 

Joule 7, 398–415, February 15, 2023 411 

**ll** 

Article 

was purchased from SuZhou ShangYang Solar Technology, and its sheet resistance is 15 U/sq. Glass/ITO was purchased from South China Xiang Science and Technology Company. The SnO2 colloid precursor was purchased from Alfa Aesar (tin (IV) oxide, 15 wt % in H2O colloidal dispersion). 4-tert-butylpyridine (tBP), chlorobenzene (CB), and acetonitrile were purchased from Sigma-ALDRICH. PbI2 (lead (II) iodide, 99.999%) was purchased from Alfa Aesar. Spiro-OMeTAD (99.8%), bis (trifluoromethylsulfonyl) amine lithium salt (Li-TFSI), and phenethyl-ammonium iodide (PEAI) were purchased from Xi’an Polymer Light Technology. Dimethylformamide (DMF), dimethyl sulfoxide (DMSO), and isopropanol (IPA) were purchased from J&K. All the materials were used as received without any purification. 

###### Device fabrication 

A uniform and dense SnO2 layer was deposited onto glass/ITO and PET/ITO substrates by spin-coating SnO2 nanoparticle solution (Alfa Aesar, tin (IV) oxide, 15% in H2O colloidal dispersion, diluted by water into 7.5% concentration) at 3,000 rpm for 30 s, and annealed in ambient air at 150<sup>�</sup> C for 30 min (glass/ITO) or 120<sup>�</sup> C for 40 min (PET/ ITO). For the control PbI2 film, 691.52 mg/mL PbI2 in DMF/DMSO mixed solvent (9:1) was spin-coated onto SnO2 at 1,500 rpm for 30 s, and then annealed at 70<sup>�</sup> C for 1 min. For the OETC doping PbI2 film, 15 mL OETC (40 mg/mL in DMF) and 15 mL DH (2 mg/mL in DMF) (5 wt % of OETC) were added into 1 mL PbI2 solution (691.52 mg/mL in DMF/DMSO mixed solvent [9:1]). Then, the solution was spin-coated onto SnO2 at 1,500 rpm for 30 s and then annealed at 70<sup>�</sup> C for 1 min. After cooling the PbI2 films to room temperature, a solution of FAI:MACl:MAI (90:9:6.39 in 1 mL IPA) was spin-coated onto the PbI2 layers at 2,000 rpm for 30 s, followed by thermal annealing at 150<sup>�</sup> C for 15 min in ambient air conditions (30%–40% RH) for the growth of the perovskite films. Then the samples were transferred to nitrogen atmosphere glove box for further processing. 5 mg/mL PEAI in IPA was deposited by spin-coating at 5,000 rpm for 30 s on the perovskite films. Spiro-OMeTAD was dissolved in CB to prepare spiroOMeTAD solution with a concentration of 72.3 mg/mL, then 35 mL of lithium bis(trifluoromethanesulfon-yl) imide in acetonitrile (260 mg/mL) and 30 mL of tBP were added into the spiro-OMeTAD solution. The mixture was coated onto the perovskite films at 2,000 rpm for 30 s to form a spiro-OMeTAD HTL. Finally, 100 nm thick Au electrode were thermally evaporated under a pressure of 5 3 10<sup>�5</sup> Torr. The areas of shadow masks are 0.062 and 1.004 cm<sup>2</sup> in this work. 

###### Device characterization 

The J-V characteristics of the devices were measured with a computer-controlled Keithley 2400 Source Measure Unit under AM1.5G illumination (100 mW/cm<sup>2</sup> ) from a SS-F5-3A solar simulator (Enli Technology) without any preconditioning. The light intensity was calibrated by a standard silicon solar cell (SRC-00178, calibrated by Enli Technology) before testing. The J-V curves of all devices were measured in forward scan mode with the scan step length of 0.02 V and a dwell time of 1 ms for each voltage. The cells were placed faceup in the glove box and were illuminated from the bottom during testing at room temperature. The EQE spectra were obtained using a QE-R3011 solar cell spectral response measurement system (Enli Technology). The light intensity at each wavelength was also calibrated with a standard silicon solar cell (RCS103011-E, calibrated by Enli Technology). By calculating the Jsc from EQE based on the solar simulator spectral for the reference silicon cell and our solar cells, the mismatch factor (M) was close to unity (M > 0.99). Steady-state PCE was calculated by measuring stabilized photocurrent density under constant bias voltage (Vmax point). FTIR spectra were measured with a Bruker VERTEX 70 V. SEM images were collected on a SU8010 produced by Hitachi, where the electron beam was accelerated at 5 kV. XRD patterns were obtained by X’Pert 

412 Joule 7, 398–415, February 15, 2023 

**ll** 

#### Article 

Pro MPD (PANalytical B.V.). DLS measurements were conducted on a Malvern Zetasizer NanoZS equipped with a 10 mW HeNe laser at a wavelength of 633 nm. XPS spectra were tested by a Kratos Axis Ultra DLD. TPV/TPC spectra were measured by STPC/TPVC-1. 2D GIWAXS characterization was performed with a Xeuss 3.0 2D (GI) SAXS/WAXS laboratory beamline using a Cu X-ray source (8.05 keV, 1.54 A<sup>˚</sup> ) and a Pilatus3R 300K detector. The incidence angle is 1<sup>�</sup> . Nano-indentation test was performed on Bruker Hysitron TI980. HR-TEM was performed on Thermo Fisher Tecnai F20 transmission electron microscope operated at 200 kV. Contact angle measurement was performed using a JC2000D1. 

##### SUPPLEMENTAL INFORMATION 

Supplemental information can be found online at https://doi.org/10.1016/j.joule. 2022.12.013. 

##### ACKNOWLEDGMENTS 

This work was supported by the National Key Research and Development Program of China (grant no. 2020YFB1506400), National Natural Science Foundation of China (grant nos. 52273188, 22075194, 51820105003, 52103227), the Natural Science Foundation of the Jiangsu Higher Education Institutions of China (grant no. 20KJA430010), the Priority Academic Program Development of Jiangsu Higher Education Institutions (PAPD), Collaborative Innovation Center of Suzhou Nano Science and Technology, the Key Laboratory of Polymeric Materials Design and Synthesis for Biomedical Function, Soochow University, the National Postdoctoral Program for Innovative Talents (grant no. BX20200231), and China Postdoctoral Science Foundation (grant no. 2021M692340). 

##### AUTHOR CONTRIBUTIONS 

Y.W. and G.X. contributed equally to this work. Y.L. conceived the idea and guided the work. Y.W. and G.X. designed the experiments; Y.W., Y.S., X.W., X.T., and Q.C. fabricated the perovskite films and devices and measured their performance; Y.L., Y.W., and G.X. analyzed all measured results. J.X., J.D., H.Y., and Z.C. synthesized OETC and MOTC and measured their properties. Y.L. helped to revise the manuscript. All authors commented on this paper. 

##### DECLARATION OF INTERESTS 

The authors declare no competing interests. 

Received: August 2, 2022 Revised: October 3, 2022 Accepted: December 16, 2022 Published: January 17, 2023 

##### REFERENCES 

1. Lee, M.M., Teuscher, J., Miyasaka, T., 3. Docampo, P., Ball, J.M., Darwich, M., Eperon, Murakami, T.N., and Snaith, H.J. (2012). G.E., and Snaith, H.J. (2013). Efficient hybrid solar cells based on mesoEfficient organometal trihalide superstructured organometal halide perovskite planar-heterojunction solar perovskites. Science 338, 643–647. https://doi. cells on flexible polymer substrates. Nat. org/10.1126/science.1228604. Commun. 4, 2761. https://doi.org/10.1038/ ncomms3761. 

2. Chen, Y., Chen, T., and Dai, L. (2015). Layer-bylayer growth of CH3NH3PbI3�xClx for highly 4. Lotsch, B.V. (2014). New light on an old story: efficient planar heterojunction perovskite solar perovskites go solar. Angew. Chem. Int. Ed. cells. Adv. Mater. 27, 1053–1059. https://doi. Engl. 53, 635–637. https://doi.org/10.1002/ org/10.1002/adma.201404147. anie.201309368. 

5. Malinkiewicz, O., Yella, A., Lee, Y.H., Espallargas, G.M., Graetzel, M., Nazeeruddin, M.K., and Bolink, H.J. (2014). Perovskite solar cells employing organic charge-transport layers. Nat. Photon. 8, 128–132. https://doi. org/10.1038/nphoton.2013.341. 

6. Yang, D., Yang, R., Ren, X., Zhu, X., Yang, Z., Li, C., and Liu, S.F. (2016). Hysteresissuppressed high-efficiency flexible perovskite solar cells using solid-state ionic-liquids for effective electron transport. Adv. Mater. 28, 

Joule 7, 398–415, February 15, 2023 413 

### **ll** 

#### Article 

5206–5213. https://doi.org/10.1002/adma. 201600446. 

7. Dai, X., Deng, Y., Van Brackle, C.H., Chen, S., Rudd, P.N., Xiao, X., Lin, Y., Chen, B., and Huang, J. (2020). Scalable fabrication of efficient perovskite solar modules on flexible glass substrates. Adv. Energy Mater. 10, 1903108. https://doi.org/10.1002/aenm. 201903108. 

8. Wang, Y., Yu, Y.R., Guo, J.H., Zhang, Z.H., Zhang, X.X., and Zhao, Y.J. (2020). Bioinspired stretchable, adhesive, and conductive structural color film for visually flexible electronics. Adv. Funct. Mater. 30, 2000151. https://doi.org/10.1002/adfm. 202000151. 

9. Huang, K.Q., Peng, Y.Y., Gao, Y.X., Shi, J., Li, H.Y., Mo, X.D., Huang, H., Gao, Y.L., Ding, L.M., and Yang, J.L. (2019). High-performance flexible perovskite solar cells via precise control of electron transport layer. Adv. Energy Mater. 9, 1901419. https://doi.org/10.1002/aenm. 201901419. 

10. Jung, H.S., Han, G.S., Park, N.-G., and Ko, M.J. (2019). Flexible perovskite solar cells. Joule 3, 1850–1880. https://doi.org/10.1016/j.joule. 2019.07.023. 

11. Huang, Z.Q., Hu, X.T., Liu, C., Tan, L.C., and Chen, Y.W. (2017). Nucleation and crystallization control via polyurethane to enhance the bendability of perovskite solar cells with excellent device performance. Adv. Funct. Mater. 27, 1703061. https://doi.org/10. 1002/adfm.201703061. 

12. Feng, J., Zhu, X., Yang, Z., Zhang, X., Niu, J., Wang, Z., Zuo, S., Priya, S., Liu, S.F., and Yang, D. (2018). Record efficiency stable flexible perovskite solar cell using effective additive assistant strategy. Adv. Mater. 30, e1801418. https://doi.org/10.1002/adma. 201801418. 

13. Jung, S.K., Heo, J.H., Oh, B.M., Lee, J.B., Park, S.H., Yoon, W., Song, Y., Yun, H., Kim, J.H., Im, S.H., and Kwon, O.-P. (2020). Chiral stereoisomer engineering of electron transporting materials for efficient and stable perovskite solar cells. Adv. Funct. Mater. 30, 1905951. https://doi.org/10.1002/adfm. 201905951. 

14. Xiang, W., Liu, S.F., and Tress, W. (2021). Interfaces and interfacial layers in inorganic perovskite solar cells. Angew. Chem. Int. Ed. Engl. 60, 26440–26453. https://doi.org/10. 1002/anie.202108800. 

15. Hu, X., Meng, X., Zhang, L., Zhang, Y., Cai, Z., Huang, Z., Su, M., Wang, Y., Li, M., Li, F., et al. (2019). A mechanically robust conducting polymer network electrode for efficient flexible perovskite solar cells. Joule 3, 2205–2218. https://doi.org/10.1016/j.joule.2019.06.011. 

16. Peng, J., Walter, D., Ren, Y., Tebyetekerwa, M., Wu, Y., Duong, T., Lin, Q., Li, J., Lu, T., Mahmud, M.A., et al. (2021). Nanoscale localized contacts for high fill factors in polymer-passivated perovskite solar cells. Science 371, 390–395. https://doi.org/10.1126/ science.abb8687. 

17. Ge, C., Liu, X., Yang, Z., Li, H., Niu, W., Liu, X., and Dong, Q. (2022). Thermal dynamic selfhealing supramolecular dopant towards 

efficient and stable flexible perovskite solar cells. Angew. Chem. Int. Ed. Engl. 61, e202116602. https://doi.org/10.1002/anie. 202116602. 

93, 106846. https://doi.org/10.1016/j.nanoen. 2021.106846. 

   28. Yao, Q., Xue, Q., Li, Z., Zhang, K., Zhang, T., Li, N., Yang, S., Brabec, C.J., Yip, H.L., and Cao, Y. (2020). Graded 2D/3D perovskite heterostructure for efficient and operationally stable MA-free perovskite solar cells. Adv. Mater. 32, e2000571. https://doi.org/10.1002/ adma.202000571. 

18. Zhan, Y., Yang, F., Chen, W., Chen, H., Shen, Y., Li, Y., and Li, Y. (2021). Elastic lattice and excess charge carrier manipulation in 1D-3D perovskite solar cells for exceptionally longterm operational stability. Adv. Mater. 33, e2105170. https://doi.org/10.1002/adma. 202105170. 

   29. Castro-Hermosa, S., Lucarelli, G., Top, M., Fahland, M., Fahlteich, J., and Brown, T.M. (2020). Perovskite photovoltaics on roll-to-roll coated ultra-thin glass as flexible highefficiency indoor power generators. Cell Rep. Phys. Sci. 1, 100045. https://doi.org/10.1016/j. xcrp.2020.100045. 

19. Li, X., Zhang, W., Wang, Y.-C., Zhang, W., Wang, H.-Q., and Fang, J. (2018). In-situ crosslinking strategy for efficient and operationally stable methylammoniun lead iodide solar cells. Nat. Commun. 9, 3806. https://doi.org/10. 1038/s41467-018-06204-2. 

   30. Ran, C., Gao, W., Li, N., Xia, Y., Li, Q., Wu, Z., Zhou, H., Chen, Y., Wang, M., and Huang, W. (2019). Facet-dependent control of PbI2 colloids for over 20% efficient perovskite solar cells. ACS Energy Lett. 4, 358–367. https://doi. org/10.1021/acsenergylett.8b02262. 

20. Ge, C., Yang, Z., Liu, X., Song, Y., Wang, A., and Dong, Q. (2021). Stable and highly flexible perovskite solar cells with power conversion efficiency approaching 20% by elastic grain boundary encapsulation. CCS Chem. 3, 2035– 2044. https://doi.org/10.31635/ccschem.020. 202000335. 

   31. Zhou, T., Xu, Z., Wang, R., Dong, X., Fu, Q., and Liu, Y. (2022). Crystal growth regulation of 2D/ 3D perovskite films for solar cells with both high efficiency and stability. Adv. Mater. 34, e2200705. https://doi.org/10.1002/adma. 202200705. 

21. Zhang, H., Chen, Z., Qin, M., Ren, Z., Liu, K., Huang, J., Shen, D., Wu, Z., Zhang, Y., Hao, J., et al. (2021). Multifunctional crosslinkingenabled strain-regulating crystallization for stable, efficient alpha-FAPbI3-based perovskite solar cells. Adv. Mater. 33, 33,, e2008487. https://doi.org/10.1002/adma. https://doi.org/10.1002/adma. 202008487.. 

- perovskite solar cells. Adv. Mater. 33, 33,, 32. Chen, W., Liu, S., Li, Q., Cheng, Q., He, B., Hu, e2008487. https://doi.org/10.1002/adma. https://doi.org/10.1002/adma. Z., Shen, Y., Chen, H., Xu, G., Ou, X., et al. 202008487.. (2022). High-polarizability organic ferroelectric materials doping for enhancing 

- 22. Krishna, A., Zhang, H., Zhou, Z., Gallet, T., the built-in electric field of perovskite solar cells Dankl, M., Ouellette, O., Eickemeyer, F.T., Fu, realizing efficiency over 24. Adv. Mater. 34, F., Sanchez, S., Mensi, M., et al. (2021). e2110482. https://doi.org/10.1002/adma. Nanoscale interfacial engineering enables 202110482. highly stable and efficient perovskite photovoltaics. Energy Environ. Sci. 14, 5552– 33. Burschka, J., Pellet, N., Moon, S.-J., 5562. https://doi.org/10.1039/D1EE02454J. Humphry-Baker, R., Gao, P., Nazeeruddin, 

   33. Burschka, J., Pellet, N., Moon, S.-J., Humphry-Baker, R., Gao, P., Nazeeruddin, M.K., and Gra¨tzel, M. (2013). Sequential deposition as a route to high-performance perovskite-sensitized solar cells. Nature 499, 316–319. https://doi.org/10.1038/ nature12340. 

23. Cheng, Y.J., Cao, F.Y., Lin, W.C., Chen, C.H., and Hsieh, C.H. (2011). Self-assembled and cross-linked fullerene interlayer on titanium oxide for highly efficient inverted polymer solar cells. Chem. Mater. 23, 1512–1518. https://doi. org/10.1021/cm1032404. 

   34. Duan, X., Li, X., Tan, L., Huang, Z., Yang, J., Liu, G., Lin, Z., and Chen, Y. (2020). Controlling crystal growth via an autonomously longitudinal scaffold for planar perovskite solar cells. Adv. Mater. 32, e2000617. https://doi. org/10.1002/adma.202000617. 

24. Li, M., Yang, Y.G., Wang, Z.K., Kang, T., Wang, Q., Turren-Cruz, S.H., Gao, X.Y., Hsu, C.S., Liao, L.S., and Abate, A. (2019). Perovskite grains embraced in a soft fullerene network make highly efficient flexible solar cells with superior mechanical stability. Adv. Mater. 31, e1901519. https://doi.org/10.1002/adma. 201901519. 

   35. Liu, T.H., Hu, Q., Wu, J., Chen, K., Zhao, L.C., Liu, F., Wang, C., Lu, H., Jia, S., Russell, T., et al. (2016). Mesoporous PbI2 scaffold for high-performance planar heterojunction perovskite solar cells. Adv. Energy Mater. 6, 1501890. https://doi.org/10.1002/aenm. 201501890. 

25. Fei, B., Chen, C., Peng, S.W., Zhao, X.J., Wang, X.H., and Dong, L.S. (2004). FTIR study of poly(propylene carbonate)/bisphenol A blends. Polym. Int. 53, 2092–2098. https://doi. org/10.1002/pi.1633. 

   36. Chen, H., Cheng, Q., Liu, H., Cheng, S., Wang, S., Chen, W., Shen, Y., Li, X., Yang, H., Yang, H., et al. (2022). Organic-semiconductor-assisted dielectric screening effect for stable and efficient perovskite solar cells. Sci. Bull. 67, 1243–1252. https://doi.org/10.1016/j.scib. 2022.04.011. 

26. Han, T.-H., Lee, J.-W., Choi, C., Tan, S., Lee, C., Zhao, Y., Dai, Z., De Marco, N., Lee, S.J., Bae, S.H., et al. (2019). Perovskite-polymer composite cross-linker approach for highlystable and efficient perovskite solar cells. Nat. Commun. 10, 520. https://doi.org/10.1038/ s41467-019-08455-z. 

   37. Lin, Y., Liu, Y., Chen, S., Wang, S., Ni, Z., Van Brackle, C.H., Yang, S., Zhao, J., Yu, Z., Dai, X., et al. (2021). Revealing defective nanostructured surfaces and their impact on the intrinsic stability of hybrid perovskites. Energy Environ. Sci. 14, 1563–1572. https://doi. org/10.1039/D1EE00116G. 

27. Xi, J., Wu, Y., Chen, W., Li, Q., Li, J., Shen, Y., Chen, H., Xu, G., Yang, H., Chen, Z., et al. (2022). Cross-linkable molecule in spatial dimension boosting water-stable and highefficiency perovskite solar cells. Nano Energy 

414 Joule 7, 398–415, February 15, 2023 

### **ll** 

#### Article 

38. Zong, Y., Zhou, Y., Zhang, Y., Li, Z., Zhang, L., Ju, M.-G., Chen, M., Pang, S., Zeng, X.C., and Padture, N.P. (2018). Continuous grainboundary functionalization for high-efficiency perovskite solar cells with exceptional stability. Chem 4, 1404–1415. https://doi.org/10.1016/j. chempr.2018.03.005. 

39. Meng, X., Cai, Z., Zhang, Y., Hu, X., Xing, Z., Huang, Z., Huang, Z., Cui, Y., Hu, T., Su, M., et al. (2020). Bio-inspired vertebral design for scalable and flexible perovskite solar cells. Nat. Commun. 11, 3016. https://doi.org/10.1038/ s41467-020-16831-3. 

40. Yang, X., Yang, H.J., Su, M., Zhao, J.M., Meng, X.C., Hu, X.T., Xue, T.Y., Huang, Z.Q., Lu, Y., Li, Y.Z., and Yang, Z. (2022). Scalable flexible perovskite solar cells based on a crystalline and printable template with intelligent temperature sensitivity. Sol. RRL 6, 310. 2100991. https://doi.org/10.1002/solr. 202100991. 

41. Hu, H.B., Wang, S.C., Wang, S.C., Liu, G.W., Cao, T., and Long, Y. (2019). Aligned silver nanowires enabled highly stretchable and transparent electrodes with unusual conductive property. Adv. Funct. Mater. 29, 1902922. https://doi.org/10.1002/adfm. 201902922. 

42. Mao, L., Chen, Q., Li, Y.W., Li, Y., Cai, J.H., Su, W.M., Bai, S., Jin, Y.Z., Ma, C.Q., Cui, Z., and Chen, L. (2014). Flexible silver grid/ PEDOT:PSS hybrid electrodes for large area inverted polymer solar cells. Nano Energy 10, 259–267. https://doi.org/10.1016/j.nanoen. 2014.09.007. 

43. Seo, K.W., Lee, J., Jo, J., Cho, C., and Lee, J.Y. (2019). Highly efficient (>10%) flexible organic solar cells on PEDOT-free and ITO-free transparent electrodes. Adv. Mater. 31, e1902447. https://doi.org/10.1002/adma. 201902447. 

44. Lucarelli, G., and Brown, T.M. (2019). Development of highly bendable transparent window electrodes based on MoOx, SnO2, and Au dielectric/metal/ dielectric stacks: application to indium tin oxide (ITO)-free perovskite solar cells. Front. Mater. 6, 310. https://doi.org/10.3389/fmats. 2019.00310. 

45. Tavakoli, M.M., Yadav, P., Prochowicz, D., and Tavakoli, R. (2021). Efficient, hysteresis-free, and flexible inverted perovskite solar cells using all-vacuum processing. Sol. RRL 5, 2000552. https://doi.org/10.1002/solr. 202000552. 

46. Zheng, Z., Li, F., Gong, J., Ma, Y., Gu, J., Liu, X., Chen, S., and Liu, M. (2022). Pre-buried additive for cross-layer modification in flexible perovskite solar cells with efficiency exceeding 22. Adv. Mater. 34, e2109879. https://doi.org/ 10.1002/adma.202109879. 

Joule 7, 398–415, February 15, 2023 415 

