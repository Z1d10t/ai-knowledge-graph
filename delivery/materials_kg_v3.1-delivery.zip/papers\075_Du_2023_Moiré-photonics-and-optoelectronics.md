# Moiré photonics and optoelectronics

| 字段 | 内容 |
|---|---|
| 期刊 | Science |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 269 |
| 作者 | Luo-Jun Du, M. Molas, Zhiheng Huang, Guang-Yu Zhang, Feng Wang, Zhi-Pei Sun |
| DOI | 10.1126/science.adg0014 |
| 源文件 | 075_Du_2023_Moiré-photonics-and-optoelectronics.pdf |

---
## **UC Berkeley** 

**UC Berkeley Previously Published Works** 

#### **Title** 

Moiré photonics and optoelectronics 

#### **Permalink** 

<u>https://escholarship.org/uc/item/4w9922zh</u> 

#### **Journal** 

Science, 379(6639) 

#### **ISSN** 

0036-8075 

#### **Authors** 

Du, Luojun Molas, Maciej R Huang, Zhiheng <u>et al.</u> 

#### **Publication Date** 

2023-03-31 

#### **DOI** 

10.1126/science.adg0014 

#### **Copyright Information** 

This work is made available under the terms of a Creative Commons AttributionNonCommercial License, available at https://creativecommons.org/licenses/by-nc/4.0/ 

Peer reviewed 

<u>eScholarship.org</u> 

Powered by the California Digital Library University of California 

RESEARCH 



<mark>◥</mark> 

### <mark>REVIEW SUMMARY</mark> 

###### MOIRÉ PHOTONICS 

# Moiré photonics and optoelectronics 

Luojun Du*, Maciej R. Molas, Zhiheng Huang, Guangyu Zhang*, Feng Wang, Zhipei Sun* 

BACKGROUND: Moiré pattern refers to a new, long-length scale of structure arising from the interference between two or more periodic templates. The scientific and engineering value of moiré patterns was firstly appreciated by the physicist Lord Rayleigh in 1874. Thereafter, the study of moiré patterns enabled the birth of moiré techniques for a wide variety of practical applications, e.g., precision measurement and positioning, automatization, and strain measurements. In condensed-matter physics, moiré patterns (also referred to as moiré superlattices) can be formed by vertically stacking two or more two-dimensional (2D) layered materials with a tiny twist angle and/or a slight lattice mismatch. Over the past decade, moiré superlattices have made a spectacular appearance with a cornucopia of previously unachieved new phenomena and distinct functionalities, transforming the landscape of fundamental solidstate physics, materialsscience, and engineering. 

ADVANCES: Moiré superlattices introduce a new length-scale potential much larger than the crystal periodicity of the constituent 2D layers, providing a powerful strategy for engineering electronic band structures and hence resulting in a plethora of emergent quantum phenomena. For example, the long-wavelength moiré periodic potential can fold the electronic band structure into a mini-Brillouin zone, giving rise to the formation of flat bands and a rich phase diagram of correlated states, such as unconventional superconductivity, orbital magnetism, Mott insulator states, and topological multiferroic orders. 

When moiré superlattices meet light, they provide a powerful platform for discovering emergent photonic and optoelectronic phenomena and device architectures. In early 2019, four research groups independently demonstrated the pronounced effects of moiré potential on excitons of transition-metal dichalcogenide 



<!-- Start of picture text -->
... Moire´ lasers ... Photonics of moire´ Infrared/THz  Single-photon  ...<br>correlated states photoresponses detectors<br>Moire´<br>polaritons Hybridized  light sourcesQuantum  Symmetry- breaking<br>excitons optoelectronics<br>Optical<br>Moire´ modulators<br>excitons/trions Moir´e photonics<br>Moir´e optoelectronics<br>Moir´e superlattices<br>Graphene<br>h -BN<br>MoS2<br><!-- End of picture text -->

Moiré photonics and optoelectronics. Moiré superlattices introduce a paradigm to engineer the band structures of collective excitations and light-matter interaction for a plethora of emergent photonic and optoelectronic phenomena, such as moiré excitons, moiré polaritons, photonics of moiré correlated electronic states, intelligent infrared sensing, quantum light sources, single-photon detection, and symmetrybreaking optoelectronics. 

heterostructures from the perspective of both real and momentum spaces. The new degree of freedom afforded by using moiré superlattices provides possibilities for engineering the exciton band structures and light-matter interactions for numerous applications, such as versatile quantum light sources, new quantum many-body physics, and long-sought boson crystals. These breakthroughs in the study of moiré excitons have excited tremendous interest in moiré photonics and optoelectronics. Indeed, a rich diversity of emergent moiré photonic and optoelectronic properties have been witnessed with unprecedented speed over the past few years—properties covering collective moiré excitations, moiré polaritons, photonics of moiré correlated electronic states, giant mid- and farinfrared photoresponses, tunable bulk photovoltaic effect, and so forth. Notably, the moiré bulk photovoltaic effects are ultrastrong and much larger than previous demonstrations, enabling the demonstration of intelligent infrared sensors with merely a subwavelength footprint potentially for next-generation nonlinear photonics and optoelectronics. 

OUTLOOK: Currently, all measurements of moiré photonics and optoelectronics are performed in the far-field limit with a collection of signals from more than 10,000 moiré cells. Therefore, developing advanced techniques that can simultaneously probe the photonic and optoelectronic properties in an individual moiré supercell and evaluate the moiré potential landscape will be valuable for advancing our understanding. Meanwhile, current research efforts on moiré photonics and optoelectronics mainly focus on twisted graphene and twisted transition-metal dichalcogenides. Exploring new moiré systems, such as moiré superlatticescomposed of2D ferroelectric, magnetic, or multiferroic crystals, and moiré devices involving two or multiple single moiré superlattices, will initiate research directions of moiré photonics and optoelectronics. Furthermore, engineering the moiré photonics and optoelectronics through external means (e.g., electric or magnetic field, strain, and ultrafast optical excitations) has the potential to spark the next “gold rush” for technical innovations (e.g., quantum nonlinear optics, ultracompact optical modulators, and terahertz single-photon devices). We are just starting down the path of exploring moiré photonics and optoelectronics, and there will be many more surprises to come.▪ 

The list of author affiliations is available in the full article online. *Corresponding author. Email: zhipei.sun@aalto.fi (Z.S.); luojun.du@iphy.ac.cn (L.D.); gyzhang@iphy.ac.cn (G.Z.) Cite this article as L. Du et al., Science 379, eadg0014 (2023). DOI: 10.1126/science.adg0014 

READ THE FULL ARTICLE AT https://doi.org/10.1126/science.adg0014 

1 of 1 

Du et al., Science 379, 1313 (2023) 31 March 2023 

RESEARCH 



<mark>◥</mark> 

###### Fabrication of moiré superlattices Top-down methods 



### <mark>REVIEW</mark> 

One top-down method for preparing highquality homobilayer moiré superlattices is the “tear-and-stack” technique (37, 38). This technique is based on the deterministic pickup and transfer, and consists of selectively picking up a section of a 2D material and then transferring it onto the remaining section, which has been rotated by a user-designed angle (34, 38). Because the two constituent layers initially have exactly the same crystal orientation, the twist angle can be controlled with a subdegree resolution. By predetermining the principal crystallographic directions of 2D materials, moiré heterostructures with controllable twist angles can also be fabricated via the deterministic pick-up and transfer technique (34). Until now, we have had at our disposal a wide variety of moiré homo- and heterostructures, such as twisted transitionmetal dichalcogenide (TMDC) homobilayers (39, 40), twisted bilayer CrI3 (41, 42), MoSe2/ WSe2 (19, 21), and WS2/WSe2 (20, 43). It is noteworthy that an automated robotic pick-up and transfer technique has been recently developed, enabling the rapid manufacture of moiré superlattices with deliberate design and angle control (44, 45). We envision that the advanced robotic assembly, through integration with wafer-scale 2D material growth, machine learning, and computer-vision algorithms (46, 47), could help realize the full potential of moiré superlattices for new physics and technological advances in photonics and optoelectronics. 

###### MOIRÉ PHOTONICS 

# Moiré photonics and optoelectronics 

Luojun Du<sup>1,2,3</sup> *, Maciej R. Molas<sup>4</sup> , Zhiheng Huang<sup>2,3</sup> , Guangyu Zhang<sup>2,3,5</sup> *, Feng Wang<sup>6</sup> , Zhipei Sun<sup>1,7</sup> * 

Moiré superlattices, the artificial quantum materials, have provided a wide range of possibilities for the exploration of completely new physics and device architectures. In this Review, we focus on the recent progress on emerging moiré photonics and optoelectronics, including but not limited to moiré excitons, trions, and polaritons; resonantly hybridized excitons; reconstructed collective excitations; strong mid- and far-infrared photoresponses; terahertz single-photon detection; and symmetry-breaking optoelectronics. We also discuss the future opportunities and research directions in this field, such as developing advanced techniques to probe the emergent photonics and optoelectronics in an individual moiré supercell; exploring new ferroelectric, magnetic, and multiferroic moiré systems; and using external degrees of freedom to engineer moiré properties for exciting physics and potential technological innovations. 

scale, and provides a platform to engineer the band structures (including both single-particle states and collective excitations, Fig. 1B) and the light-matter interaction for exotic quantum phenomena (12–16). Triggered by the discovery of correlated insulating states and unconventional superconductivity in magic-angle twisted bilayer graphene (TBG) (17, 18), a plethora of exciting electronic, optical, and optoelectronic properties have been discovered in moiré superlattices (Fig. 1C), including moiré excitons (19–22), versatile quantum light sources (23), orbital ferromagnetism (24–26), Wigner crystal states (11, 27, 28), stripe phases (29, 30), topological multiferroic order (31), boson exciton crystals (32), and intelligent infrared sensing (33). 

wo-dimensional (2D) layered materials have ushered in a new era of fundamental research and technological innovation, owing to the electronic, photonic, and T optoelectronic properties that are unattainable in their bulk counterparts (1–3). Today, over 2000 atomically thin 2D materials have been uncovered, ranging from widebandgapinsulators (e.g., h-BN), semiconductors (e.g., MoS2), and polar metals (e.g., Ga) to superconductors (e.g., NbSe2), ferromagnets (e.g., CrI3), and quantum spin liquids (e.g., RuCl3) (1, 4–7). Notably, 2D atomic layers with diverse properties can be stacked together to form van der Waals (vdW) heterostructures without the constraint of lattice matching in conventional heterostructures. This enables opportunities to combine the best characteristics of different ingredients in one ultimate synthetic quantum material and thus leads to the realization of numerous electronic, photonic, magnetic, and topological functionalities that were previously impossible (1, 2, 8, 9). 

###### Bottom-up methods 

Developing direct growth methods for synthesizing large-scale and uniform moiré superlattices is important for future technological applications. One of the effective bottom-up methods is the vdW epitaxy (48). For example, a vast assortment of moiré superlattices with ultraclean interfaces has been epitaxially grown, such as graphene/h-BN (49), WS2/ WSe2 (50), and MoS2/WSe2 (51). Typically, high–symmetry-stacking configurations with the smallest formation energy are preferably deposited during the vdW epitaxial growth (48, 50). Therefore, it is very challenging to obtain moiré superlattices with on-demand twist angles, especially the metastable samples (e.g., magic-angle TBG) that show strong electron-electron correlation and new optoelectronic phenomena. Breaking the energy tendency and realizing the scalable fabrication of moiré superlattices with controllable twist angles and layer-by-layer epitaxy would greatly promote the progress of the field. 

We present an overview of the recent progress on emerging moiré photonics and optoelectronics, such as moiré neutral and charged excitons, resonantly hybridized excitons, moiré polaritons, emergent optical responses of moiré correlated electronic states, reconstructed collective excitations, terahertz single-photon detection, strong mid- and far-infrared photoresponses, symmetry-breaking optoelectronics, etc. We also provide an outlook on the major challenges and future opportunities in this field, as well as the implications for potential new technological innovations. With a particular focus on moiré photonics and optoelectronics, our aim is to complement other recent reviews that discuss the fabrication (34), correlated electronic states (10, 13), and excitonic physics (12, 35, 36). 

Intriguingly, a geometrical moiré superlattice emerges as a result of the interference between the constituent 2D atomic layers with a slight lattice mismatch and/or a small rotational twist (Fig. 1A) (10, 11). This moiré superlattice introduces a new length and energy 

1QTF Centre of Excellence, Department of Electronics and Nanoengineering, Aalto University, Tietotie 3, FI-02150 Espoo, Finland.<sup>2</sup> Beijing National Laboratory for Condensed Matter Physics; Key Laboratory for Nanoscale Physics and Devices, Institute of Physics, Chinese Academy of Sciences, Beijing 100190, China.<sup>3</sup> School of Physical Sciences, University of Chinese Academy of Sciences, Beijing 100190, China. 4Institute of Experimental Physics, Faculty of Physics, University of Warsaw, ul. Pasteura 5, 02-093 Warsaw, Poland. 5Songshan-Lake Materials Laboratory, Dongguan, Guangdong Province 523808, China.<sup>6</sup> Department of Physics, University of California at Berkeley, Berkeley, CA, USA.<sup>7</sup> Institute of Photonics and Photon Technology, Northwest University, Xi’an 710069, China. *Corresponding author. Email: zhipei.sun@aalto.fi (Z.S.); luojun.du@iphy.ac.cn (L.D.); gyzhang@iphy.ac.cn (G.Z.) 

###### Fabrication and visualization of moiré superlattices 

The controlled fabrication and direct visualization of moiré superlattices are essential for unlocking their intriguing electronic and optical properties and future on-demand application development. 

###### Dynamic manipulation 

For the “tear-and-stack” technique or vdW epitaxial growth, the final moiré superlattice 

1 of 14 

Du et al., Science 379, eadg0014 (2023) 31 March 2023 

RESEARCH | REVIEW 



**A C** Theoretical prediction of moiré flat bands in magic-angle twisted **2011** Theory Experiment bilayer graphene<sup>14</sup> Observation of fractal quantum Hall **2012** effect and Hofstadter butterfly in Epitaxial growth of graphene/ _h_ -BN angle-aligned graphene/ _h_ -BN moiré superlattices<sup>49</sup> **2013** superlattices<sup>15, 16</sup> Discovery of correlated insulator states and unconventional **2017** Theory of the moiré excitons and superconductivity in magic-angle moiré quantum emitter array<sup>66, 67</sup> graphene superlattices<sup>17, 18</sup> **2018** Experimental observation of moiré excitons in TMDC vdW Demonstration of versatile heterostructures<sup>19-22</sup> quantum light and Hubbard model quantum simulator<sup>23, 43</sup> **2019** Discovery of orbital magnetism in twisted bilayer graphene<sup>24-26</sup> Optical detection of Wigner crystal states in WSe2/WS2 moiré Imaging the nematicity and broken superlattices<sup>11, 27</sup> **2020** rotational symmetry<sup>29,30</sup> Observation of strong mid-infrared Observation of moiré trions in photoresponse in twisted bilayer TMDC vdW heterostructures<sup>73-75</sup> graphene<sup>126</sup> Demonstration of moiré polaritons **B** Theoretical prediction of **2021** with strong nonlinearity in aligned topological multiferroic order in MoSe2/WS2 moiré superlattices<sup>101</sup> twisted TMDC bilayers<sup>31</sup> Light-induced ferromagnetism in Discovery of correlated exciton insulator in Coulomb-coupled WSe2/WS2 moiré superlattices<sup>120</sup> WSe2 monolayer and WSe2/WS2 **2022** Demonstration of tunable moiré moiré superlattices<sup>110, 111</sup> quantum geometry for intelligent infrared sensing<sup>33</sup> Visualization of moiré magnetism in twisted 2D magnets<sup>41, 42</sup> Evidence of exciton crystals in moiré WSe2/MoSe2/WSe2 trilayer<sup>32</sup> 

Observation of fractal quantum Hall effect and Hofstadter butterfly in angle-aligned graphene/ _h_ -BN superlattices<sup>15, 16</sup> 

of the two constituent TMDC layers. (C) The timeline of selected key developments in the study of moiré physics. Over the past few years, the field of moiré superlattices has grown substantially with a series of new discoveries, such as orbital magnetism, Wigner crystal states, electronic nematic phase, tunable spin-polarized correlated states, simulation of Hubbard model physics, continuous Mott transition, quantum anomalous Hall effect, moiré excitons/polaritons, strong mid-infrared photoresponse, light-induced ferromagnetism, and highly tunable bulk photogalvanic effects. [Adapted with permission from (A) (66)] 

Fig. 1. Moiré superlattices and timeline of key developments in the study of moiré physics. (A) Top: Illustration of the moiré superlattice formed by a nearly 0°-angle–aligned TMDC heterobilayer. The moiré unit cell is outlined in the green diamond. Bottom: Close-ups of the three high-symmetry points (A, B, and C). Atomic registry R<sup>m</sup> h<sup>denotesanR-typestacking,withthemsiteofthe</sup> top layer vertically aligned with the hexagon center (h) of the bottom layer. (B) Schematic of the flat moiré bands in mini Brillouin-zone (mBZ) for moiré heterostructures with type II band alignment. Eg1 and Eg2 stand for the bandgap 

###### Visualization of moiré superlattices 

usually has a fixed twist angle. Therefore, it is often challenging to characterize the twistangle–dependent behavior. Owing to the superlubricity of vdW interfaces, moiré superlattices with dynamically controllable twist angles can be obtained through mechanical, optical, thermal, and magnetic manipulation (52–56). This enables the feasibility to uncover the intrinsic twist-angle–dependent properties. For example, with the atomic force microscope tip manipulation technique, the twist-angle driven evolution of electronic, optical, and mechanical responses in graphene/h-BN moiré superlattices has recently been revealed (53). 

are powerful in the visualization of moiré superlattices, the special sample preparation and complex operating environment (e.g., ultrahigh vacuum and cryogenic temperature) are not conducive to establishing a clear correlation between the direct imaging of moiré structures and the emerging electrical and optical properties. 

Direct visualization of moiré superlattices is fundamentally valuable for the comprehensive understanding and control over emergent moiré physics. In principle, atomic-resolution techniques, such as scanning tunnelling microscopy (STM) and transmission electron microscopy (TEM), offer the opportunity to directly image various moiré superlattices [e.g., magicangle TBG (29), twisted bilayer WSe2 (57), and aligned WS2/WSe2 (20, 50)]. Specifically, STM can also probe the magnitude of moiré potential in situ, offering key insight for understanding the moiré physics. Although STM and TEM 

Because of the broken symmetry and sizable strain gradients at domain walls, moiré superlattices can show nonvanishing electromechanical responses and hence be imaged by piezoresponse force microscopy (PFM) (58). In particular, PFM provides a simple, universal 

2 of 14 

Du et al., Science 379, eadg0014 (2023) 31 March 2023 

RESEARCH | REVIEW 



Table 1. Comparison between the visualization methods of moiré superlattices. 

||Pros|Cons|
|---|---|---|
|Atomic-resolution techniques<br>(such as TEM and STM)<br>..................................................................................................|1. Directly image the local displacement vector.<br>2. Direct visualization of the structural<br>relaxation, disorder, and strain fields.<br>3. Directly visualize the magnitude of<br>the moiré potential (for STM).<br>...................................................................................................................|1. Require specialized sample preparation.<br>2. Require extreme conditions (e.g., ultra-high<br>vacuum and low temperature).<br>3. Incompatible with most device fabrication<br>techniques and optical/transport measurements.<br>.......................................................................................................................|
|AFM-based techniques (such as<br>PFM, SKPM and conductive AFM)<br>..................................................................................................|1. Simple, room-temperature, ambient method.<br>2. Universal applicability.<br>3. Provide the key information of flexoelectricity<br>(for PFM), surface potential (for SKPM),<br>and interlayer hybridization (for conductive AFM).<br>...................................................................................................................|1. Require direct contact with the active area and<br>is incompatible with encapsulated samples.<br>2. Cannot image the local displacement vector.<br>3. Require conducting substrates (for conductive AFM).<br>.......................................................................................................................|
|Near-field techniques (such as<br>SNOM, sMIM, and tip-enhanced Raman)<br>..................................................................................................|1. Ambient conditions.<br>2. Compatible with functional electronic devices.<br>...................................................................................................................|Cannot image the local displacement vector.<br>.......................................................................................................................|
|Secondary electron imaging technique<br>~~..................................................................................................~~|1. Compatible with encapsulated samples and<br>optical/transport measurements.<br>2. Universal applicability.<br>~~...................................................................................................................~~|1. Cannot image the local displacement vector.<br>2. Cannot give the local stacking order.<br>~~.......................................................................................................................~~|



technique to visualize various moiré superlattices under room-temperature and atmospheric conditions (58). However, PFM requires direct contact with the active area and thus prevents the use of h-BN encapsulation and top gates, which are typically required for most optical and transport measurements. Recent studies demonstrate that channeling modulated secondary electron imaging technique can be used to visualize the fully h-BN encapsulated, dual-gated moiré superlattice devices (59). With the help of this advanced technique, the local moiré structures and the exotic photonic properties have been successfully correlated with each other (59), deepening our understanding. Additionally, moiré superlattices can also be visualized by conductive atomic force microscopy (AFM) (60), scanning near-field optical microscopy (SNOM) (61), scanning microwave impedance microscopy (sMIM) (62), scanning Kelvin probe microscopy (SKPM) (63), and hyperspectral Raman imaging (64). Table 1 briefly compares the advantages and disadvantages of different visualization techniques of moiré superlattices. 

###### Moiré photonics 

Moiré superlattices with a long-wavelength periodic potential landscape offer opportunities to engineer the elementary excitations and light-matter interaction for fascinating photonic phenomena. In this section, we review the state-of-the-art moiré photonics, which mainly covers moiré neutral and charged excitons, resonantly hybridized excitons, moiré polaritons, moiré phonons, and reconstructed collective excitations. 

###### Moiré neutral and charged excitons 

The exciton, a Coulomb-bound electron-hole pair, dominates the optical properties of a 

material and hence underlies the development of emerging photonic and optoelectronic applications (65). Recent studies demonstrate that the moiré superlattices open up new avenues for modulating excitonic quasiparticles in both real and momentum spaces, resulting in quantum-dot–like moiré excitons and Braggumklapp moiré excitons, respectively (12). 

###### Quantum-dot–like moiré excitons 

From the perspective of real space, moiré superlattices impose a spatially periodic potential landscape on the excitons (66, 67). Therefore, excitons would likely be trapped at the moiré potential minima (Fig. 2A), forming a lattice of quantum-dot–like moiré excitons, a solid-state analog of a bosonic quantum gas in an optical lattice that is of interest for quantum photonics (19, 66). Recently, moiré-trapped quantumdot-like interlayer excitons (IXs), evidenced as a series of discrete photoluminescence (PL) emission lines with ultranarrow linewidths (e.g., ~100 meV), have been demonstrated in MoSe2/WSe2 heterostructures (Fig. 2B) (19, 68, 69). In particular, the moiré potential minima are located at high-symmetry sites that maintain threefold rotational symmetry (19, 66, 69). Consequently, moiré-trapped excitons can inherit valley-contrasting properties and exhibit strong circular polarization (Fig. 2B), a feature that distinguishes them from quantum emitters localized by random extrinsic potential (19, 70). In addition, owing to the quantum-dot–like confinement, moirétrapped excitons could provide a platform for single-photon sources and quantum photonics, as demonstrated by the photon correlation experiments (Fig. 2D) (23). 

Notably, quantum-dot–like moiré IXs show multiple discrete narrow PL lines at low excitation powers but transform into a broad 

emission peak as the excitation power increases (Fig. 2C) (19, 69). This feature can be understood as follows: At low excitation powers (e.g., a few nanowatts), the number of the photonexcited IXs are around two orders of magnitude smaller than the number of moiré sites, and thus are trapped at different moiré sites (Fig. 2C), because of the dipolar exciton-exciton interactions (69). Absent disorder, only one PL line is expected, as the potential minima in different moiré supercells would be degenerate. However, the ubiquity of inhomogeneity and disorder breaks the degeneracy, leading to spectral isolation of moiré-trapped IXs and a series of PL emission lines (19, 69, 71). As the excitation power increases, more IXs are excited, and thus more moiré trapping sites are populated, resulting in an ensemble band of moiré-trapped IXs with a broad linewidth (Fig. 2C) (69). When the exciton density is high enough, moiré traps would be filled up, and excitons approach the regime of free-particle behavior (19, 72, 73). 

###### Moiré-trapped trions 

Upon doping of moiré superlattices, moirétrapped neutral excitons would interact with the excess charge carriers that are also localized at the moiré sites, forming the moiré charged excitons (i.e., moiré-trapped trions) (74, 75). Recently, moiré-trapped IX trions have been demonstrated in MoSe2/WSe2 heterostructures (69, 73–75). In these experiments, new sets of quantum-dot–like IX trion emission lines with ultranarrow linewidths appear about 7 meV below the moiré-trapped neutral excitons upon electrostatic doping (Fig. 2E) (74, 75). 

Moiré-trapped trions, because oftheircharged nature, can couple with the electrons or holes in nearest-neighbor moiré sites via long-range Coulomb interactions. And because the charge 

3 of 14 

Du et al., Science 379, eadg0014 (2023) 31 March 2023 

RESEARCH | REVIEW 





Fig. 2. Moiré excitons and trions. (A) Representation of an exciton trapped at the moiré potential minima. (B) Circularly polarized PL spectra of moirétrapped IXs of 57° MoSe2/WSe2 heterostructures. (C) Schematic of the occupation of moiré sites by IXs with increasing excitation power. (D) Secondorder photon correlation statistics of moiré-trapped IXs. The antibunching indicates the single-photon nature. (E) PL map as a function of doping. At electron or hole doping, moiré-trapped trions with lower energy emerge. The prominent IX emissions are labeled as A to G. (F) Schematic of the moirétrapped IX energy against electron density. Successive filling of nearest- 

neighbor moiré sites leads to a Coulomb staircase. (G) Sketch depicting the exciton band folding by umklapp scattering off moiré potential. (H and I) Calculated WSe2 A exciton dispersion of WS2/WSe2 moiré superlattices, with three optically allowed transitions denoted I to III (H), which are observed by reflectance contrast spectra (I). (J) Helicity-resolved PL spectra of 1° MoSe2/WSe2 heterobilayers, with alternating circular polarization. (K) Realspace map of the center-of-mass wave functions for the first three umklapp moiré IXs. [Adapted with permission from (A and B) (19), (C) (69), (D) (23), (E and F) (74), (H and I) (20), (J and K) (21)] 

4 of 14 

Du et al., Science 379, eadg0014 (2023) 31 March 2023 

RESEARCH | REVIEW 



distribution of center-of-mass wave functions for the first three Bragg-umklapp moiré IX resonances of MoSe2/WSe2 heterostructures, which correspond to s-, p- and d-wave symmetry, respectively (21, 79). Because of an additional angular momentum ħ (2ħ), Bragg-umklapp moiré IX with the p-waveform (d-waveform) has the opposite (same) optical selection rule as the first s-wave symmetry one, leading to alternating co- and cross-circularly polarized PL (21). 

hybridized excitons combine the merits of both intralayer excitons (e.g., large oscillator strength) and IXs (e.g., appreciable out-of-plane dipole moment), and thus represent an advantageous scenario for nanophotonic and optoelectronic applications (90, 91). Resonantly hybridized excitons have been demonstrated in TMDC homobilayer moiré superlattices with intrinsically aligned band edges (40, 89, 92–94), MoSe2/WS2 moiré heterostructures with nearly degenerate conduction-band edges (Fig. 3A, right panel) (22, 89–91), and WSe2/WS2 moiré superlattices where the upper valence band of WS2 and the lower valence band of WSe2 are closely aligned (Fig. 3A, left panel) (91). Furthermore, according to the available electron band parameters in the literature (95), we envision that resonantly hybridized excitons can also appear in MoS2/WS2, MoSe2/WSe2, MoSe2/ MoTe2, MoTe2/WS2, and MoTe2/WSe2 moiré superlattices. 

carriers are also moiré-trapped, the six nearestneighbor moiré sites are filled sequentially (Fig. 2F) (74). This creates a discrete repulsive Coulomb interaction between moiré-trapped trions and the charge carriers in nearestneighbor moiré sites. Consequently, moirétrapped trions show a staircase-like blueshift of energy (Fig. 2F), providing a noninvasive, local optical technique to characterize the Coulomb interactions and local disorder in moiré superlattices (74). In addition, moirétrapped trions exhibit distinctive valley properties. For example, the valley polarization can be switched from large cocircular polarization under electron doping to negligible crosscircular polarization under hole doping (74, 75), and the valley polarization time can reach ~1 ms, three orders of magnitude longer than that of conventional trions in monolayer TMDCs (75, 76). This opens up possibilities for opto-valleytronic applications and emerging nanophotonic devices, such as spin-valley optical transistors and chiral light-emitting diodes. 





In the presence of itinerant electrons or holes, Bragg-umklapp moiré trions can appear in moiré superlattices (84). Besides excitons and trions, Bragg-umklapp scattering off the moiré potential can also activate other elementary excitations, such as phonons, magnons, and polaritons. For example, Bragg-umklapp moiré phonons have been uncovered in TBG (85, 86), graphene/h-BN superlattices (86, 87), and twisted bilayer TMDCs (64, 88). 

Resonantly hybridized excitons display a sharp energy modulation against the twist angle (Fig. 3B) (22, 89, 90) and manifest energylevel anticrossing under the applied electric fields (Fig. 3C) (89, 91, 92). It is instructive to understand these features using a two-level coupled-oscillator model with Hamiltonian eX W , where the off-diagonal element � W eIX � W denotes the coupling constant and the diagonal elements eX (eIX) describe the energy of uncoupled intralayer exciton (IX). Because the band minimum of IX is located at the corners of mBZ, IXs that can hybridize with optically bright intralayer excitons should have energy eIX ¼ emin þ 2ℏM<sup>2</sup> <u>qIX</u><sup>2,whereMIXis</sup> the total mass of IX, emin is the IX energy at band minimum, andq denotes the momentum of mBZ corners (22, 79, 89, 90). Given that q increases linearly with twist angle, eIX and hence resonantly hybridized excitons exhibit a sharp energy modulation (Fig. 3B) (22, 89, 90). Meanwhile, IX shows a linear energy shift with applied electric fields due to the quantumconfined Stark effect, leading to the electrically tunable resonantly hybridized excitons (91, 96, 97). When the energy of IX is tuned to resonate with eX, resonantly hybridized excitons would show avoided crossing of the energy level, as demonstrated by absorption and PL spectra (Fig. 3C) (91, 92). For WSe2/WS2 moiré superlattices, the extracted coupling constants W can reach ~40 meV, much larger than the exciton linewidths (~10 meV). This indicates that the system is in the exciting strongcoupling regime and provides opportunities for engineering various emerging many-body states, such as Bose-Einstein condensation and polariton superfluidity (91, 98). 

We remark that quantum-dot–like moiré excitons from the real-space perspective and Bragg-umklapp moiré excitons from the momentum-space perspective should be unified in principle. For instance, theoretical calculations show that the first few Braggumklapp moiré excitons with low energy are localized at the moiré potential minima and thus should also belong to the quantum-dot– like moiré states (21, 78, 79). Alternatively, quantum-dot–like moiré excitons observed under ultralow excitation power should correspond to the Bragg-umklapp moiré excitons with the lowest energy. However, quantumdot–like moiré excitons and Bragg-umklapp moiré excitons demonstrated by current experimental measurements seem to exhibit distinctly different behaviors. For example, the linewidths of Bragg-umklapp moiré excitons are more than two orders of magnitude wider than those of quantum-dot–like moiré excitons. These discrepancies may stem from the ubiquity of disorder, strain, or twist-angle inhomogeneity in actual real-world moiré superlattices and deserve further studies to establish a unified understanding. 

###### Bragg-umklapp moiré excitons 

From the perspective of momentum-space, Bragg-umklapp scattering off the long-period moiré potential can fold the dark exciton states with momentum k = kM (where kM is the moiré reciprocal lattice vectors) into the center of the mBZ, resulting in the formation of new excitonic minibands with optical activity (Fig. 2G) (12, 22, 67, 77–80). Figure 2H illustrates the WSe2 A exciton dispersion of aligned WSe2/WS2 superlattices and clearly shows three optically active excitons at the mBZ center (I, II, and III) (20, 67). Experimentally, Bragg-umklapp intralayer moiré excitons have been demonstrated by both absorption spectroscopy in WSe2/WS2 heterobilayers (Fig. 2I) (20, 43) and PL measurements in MoSe2/MoS2 heterostructures (81). Notably, the cutting-edge exciton band structure calculations reveal that different intralayer moiré excitons exhibit distinct hallmarks (82). In WSe2/WS2 moiré superlattices, the lowestenergy moiré resonance I is characterized by a Wannier-type exciton with the tightly correlated electron and hole, whereas the highestenergy moiré exciton peak III is described by an intralayer charge-transfer exciton with spatially separated electron and hole (82). Such distinct characters provide unparalleled insight into the unusual doping responses and magneto-optical responses of moiré excitons (20, 82). 

###### Resonantly hybridized excitons 

Usually, the effects of moiré superlattices on excitons are regarded as a harmonic perturbation potential, then the intralayer excitons and IXs are discussed separately as independent objects (such as the previous section) (66, 67). Such a view holds true for moiré superlattices with a large band-edge offset. On the contrary, when the conduction and/or valence band edges of the constituent layers are aligned in both momentum and energy, the resonant interlayer hybridization can strongly enhance the moiré superlattice effects and mix the intralayer excitons and IXs through spin-conserving interlayer hopping, resulting in the resonantly hybridized excitons (12, 22, 89). Resonantly 

For IX species, Bragg-umklapp moiré exciton transitions have also been uncovered by PL spectra in MoSe2/WSe2 superlattices (Fig. 2J) (21, 83). Owing to the strongly modified excitoncenter-of-masswave functioninrealspace, Bragg-umklapp moiré IX resonances exhibit alternating positive and negative circular polarization. Figure 2K shows the real-space 

###### Moiré polaritons 

Polaritons, a hybrid quasiparticle excitation of part-light and part-matter, enable the fine 

5 of 14 

Du et al., Science 379, eadg0014 (2023) 31 March 2023 

RESEARCH | REVIEW 





Fig. 3. Resonantly hybridized excitons and moiré polaritons. (A) Schematic diagram of resonantly hybridized excitons resulting from the interlayer hole (right) and electron hopping (left). (B) Calculated absorption spectrum of resonantly hybridized exciton versus twist angle in MoSe2/WS2 moiré superlattices, which is demonstrated by PL measurements (inset). (C) Derivative of the reflectance spectrum against the electric field in 60°-aligned WS2/WSe2 moiré superlattices. (D) Angle-resolved reflectance spectra, demonstrating strong coupling between resonantly hybridized excitons and cavity photons. (E) Carrier density–dependent shift of exciton energy (upper), half-linewidth 

(middle), and normalized coupling strength (lower) for lower polaritons (LPs) of MoSe2/WS2 moiré superlattices (denoted as hBL) and monolayer MoSe2 (denoted as ML). (F) Nonlinear coefficient, g, as a function of carrier density for moiré hBL LPs (red) and ML LPs (blue). (G) Extinction mapping of chiral Berry plasmons against wave number and polarization detection angle, demonstrating the magnetic-field–free Faraday effect. (H) Topological transitions triggered by the twist angle from open (hyperbolic) to closed (elliptical) dispersion contours in bilayers of a-MoO3. [Adapted with permission from (B) (22), (C) (91), (D to F) (101), (G) (104), (H) (108)] 

6 of 14 

Du et al., Science 379, eadg0014 (2023) 31 March 2023 

RESEARCH | REVIEW 



modern information and communication technologies, such as subdiffraction imaging, optical sensing, infrared detectors, light-harvesting devices, and electro-optical modulators (99, 100). Moiré superlattices provide a powerful platform for engineering new plasmon-polaritons because of the interlayer quantum coupling and radically altered electronic structures (e.g., the emergence of flat bands). For example, owing to additive contribution from the interband transition between superlattice minibands, plasmon-polaritons in graphene/h-BN moiré superlattices show enhanced scattering amplitudes (102). For TBG moiré superlattices, an exotic interband plasmon-polariton mode originating from the optical transitions between flat minibands is observed, which is radically different from the conventional intraband plasmon in monolayer graphene (103). By using nanostructured surface plasmon resonators, two new plasmon modes are identified in TBG moiré superlattices: a chiral Berry plasmon mode from uncompensated Berry flux, and a slow plasmon mode from interband transitions between nested subbands (104). In particular, because of the nontrivial Berry curvature, the chiral plasmon mode can show the magnetic-field–free Faraday effect with a polarization rotation of ~15° (Fig. 3G) (104). Such a large Faraday rotation angle is comparable to the conventional Faraday effect accessible by a static magnetic field of 7 T, highlighting the great potential of magneticfield–free Faraday rotators (104). The slow plasmon mode is within the highly soughtafter mid-wave infrared spectral window and would open up opportunities for new photonic devices, such as infrared devices, without fundamental damping and phonon scattering processes (104). It is noteworthy that numerous plasmon-polaritons, such as intrinsically undamped plasmon modes (105), quasi-flat plasmonic bands (106), and plasmonic Dirac cone (107), have been predicted in moiré superlattices and deserve further exploration. 

control of light at the nanoscale across a broad spectral range, promising the prospect of new technological applications in nanophotonics and optoelectronics (99, 100). Recent studies show that moiré superlattices offer an opportunity for polariton engineering and photonic quantum technologies. Here, we provide an overview of the state-of-the-art moiré exciton-, plasmon-, and phonon-polaritons. 

is hyperbolic (elliptical) (108, 109). At the twist angle at which the topological transition occurs (dubbed as photonic magic angles), the dispersion becomes flattened, supporting highly collimated, directive, and diffractionless canalized phonon-polaritons for various applications, such as quantum nanophotonics, superlens, nanoimaging, biosensing, and radiative energy transfer (108). 





###### Photonics of moiré correlated electronic states 

###### Moiré exciton-polaritons 

Because of appreciable oscillator strengths and in-built electric dipoles, resonantly hybridized moiré excitons hold great promise for polaritons with quantum nonlinearity and cooperative effects. MoSe2/WS2 moiré superlattices with resonantly hybridized moiré excitons are integrated into a microcavity (101). In place of the resonantly hybridized moiré excitons or the bare cavity photons, three new light-matter hybrid modes with anticrossing of the dispersion curve emerge (Fig. 3D) (101). This demonstrates the moiré exciton-polaritons and the effective coupling between resonantly hybridized excitons and cavity photons. Moreover, the coupling strengths W (~10 meV) of 

Moiré superlattices, with enhanced electronelectron correlations in the flat minibands, provide opportunities for a large portfolio of correlated electronic states, such as Mott insulators, Wigner crystal states, charge density waves, charge-transfer insulators, and exciton insulators (11, 27, 28, 110–113). For example, nearly two dozen correlated insulating states have been unveiled at the commensurate filling fractions of WSe2/WS2 moiré superlattices via an optical sensing technique (Fig. 4A) (11). Certainly, these moiré correlated electronic states would have profound effects on the elementary optical excitations, resulting in a number of photonic responses. 

<u>ðgX þgpÞ</u> moiré exciton-polaritons satisfy W > 2 

First, owing to the gapped nature of moiré correlated electronic states, free carrier screening of the exciton interactions is largely quenched. This would result in the enhancement of oscillator strength and the blueshift of exciton resonance energy for photonics (Fig. 4B) (30, 114, 115). Second, moiré correlated electronic states at commensurate fractional fillings belong to charge-ordered states, e.g., Wigner crystals and charge density waves. Consequently, there is an additional periodic potential for collective excitations, which can fold dark states back to the light cone by Braggumklapp scattering and thus brighten new optical transitions (Fig. 4C) (80, 116). Third, for moiré correlated electronic states at some specific fillings (e.g., v ¼ T 21<sup>; T</sup> <u>35</u><sup>~~)~~, electrons are</sup> arranged in alternating lines with a preferential orientation along the high-symmetry axes of the moiré superlattice (11, 30, 112). Such stripe nature of these moiré correlated electronic states spontaneously breaks the threefold rotational symmetry, enabling the anisotropic optical responses (30, 117). Last but not least, moiré correlated electronic states can facilitate a wide range of magneto-optical phenomena, such as strongly enhanced valley Zeeman splitting, magnetic circular dichroism, Faraday effect, and Kerr rotation (43, 118, 119). For example, a nearly two-orders-of-magnitude– enhanced exciton valley Landé g-factor has been observed for moiré correlated electronic states at v ¼ �1 (Fig. 4D), opening up possibilities for opto-valleytronic applications (43, 118). By optically tuning the spin exchange interactions between moiré-trapped holes, ferromagnetic order emerges at v ¼ � 31<sup>Wigner</sup> state of WSe2/WS2 moiré superlattice, giving 

(gX/gp are the linewidths of the resonantly hybridized excitons and cavity mode), indicating the strongly coupled regime of light– matter interactions (98, 101). 

Moiré exciton-polaritons exhibit radically different excitation density responses than polaritons formed with the constituent monolayer excitons (Fig. 3E) (101). For example, with increasing excitation density, the moiré excitonpolaritons (monolayer exciton-polaritons) show a strong drop in coupling strength by up to 20% (negligible change in coupling strength), but no measurable exciton energy shift or line broadening (considerable blueshift and line broadening). This suggests the strong exciton blockade and suppressed excitation-induced dephasing for moiré exciton-polaritons, and indicates that the resonantly hybridized exciton involved in the polariton formation should be a moiré-trapped 0D-like exciton (101). Benefiting from the moiré quantum confinement effect, moiré exciton-polaritons can show a nonlinearity up to ~6 meV·mm<sup>2</sup> , more than two orders of magnitude larger than typical monolayer TMDC exciton-polaritons (Fig. 3F) (101). Moiré exciton-polaritons combine strong quantum nonlinearity and large coupling strength, opening a huge swath of possibilities for quantum photonics and optoelectronics. 

###### Moiré phonon-polaritons 

Phonon-polaritons, collective oscillations that result from the hybridization of photons and optical phonons in polar crystals, can bestow a wealth of valuable applications, such as nanoscale light propagation, ultramicroscopy, and coherentthermalemission(99, 100).Experimental studies have demonstrated that in twisted stacks of vdW crystal a-MoO3, the interlayer twist angle enables fine control of the dispersion of phonon-polaritons and therefore triggers a topological transition from hyperbolic (open) to elliptical (closed) wavefront geometries (Fig. 3H) (108, 109). Such a transition is determined by a topological quantity and becomes resilient to perturbations, impurities, or disorder. When the topological number is two (four), the dispersion of phonon-polaritons 

###### Moiré plasmon-polaritons 

Plasmon-polaritons are coupled excitations of photons and charge carriers that offer the possibility of manipulating and guiding light at subwavelength scales (99, 100). The ability to control plasmon-polaritons is central to 

7 of 14 

Du et al., Science 379, eadg0014 (2023) 31 March 2023 

RESEARCH | REVIEW 





Fig. 4. Photonics of moiré correlated states and reconstructed moiré superlattices. (A) An abundance of correlated insulating states revealed in WSe2/ WS2 moiré superlattices by optical sensing technique with 2s exciton resonance. (B) Gate-dependent PL map (left) and integrated intensity (right) for the IX states in a WS2/WSe2 moiré superlattice. (C) Dependence of chemical potential of differential reflectance differentiated with respect to energy. Umklapp exciton resonances XU top and XU bot can be clearly observed at v ¼ 1 and v ¼ 2. (D) Exciton valley Zeeman splitting as a function of the magnetic field at zero filling (red circles) and half-filling (black squares). (E) Reflective magnetic circular dichroism (RMCD) as a function of magnetic field and temperature at selected excitation power, indicating lightinduced ferromagnetism. (F) Schematic cartoon of TBG moiré superlattices with 

(right) and without (left) the lattice reconstruction. (G) Infrared nano-imaging (left) and dark-field TEM visualization (right) of TBG moiré superlattices, demonstrating a natural plasmon photonic crystal. (H) The energies of intralayer phonon modes versus twist angle. Clear peak splitting of E2g mode can be observed at 2° ≤ q < 6°, providing information on reconstructed collective excitations. (I) PL spectra of twisted bilayer WSe2 collected from the locations with different moiré wavelengths. A higher-energy exciton peak (type II) emerges with increasing moiré wavelength. (J and K) Gate-dependent PL intensity (J) and linear polarization (DOLP) of reconstructed twisted WSe2 bilayers (K), showing distinct gate tunability and valley coherence properties. [Adapted with permission from (A) (11), (B) (114), (C) (116), (D) (43), (E) (120), (F) (121), (G) (61), (H) (124), (I to K) (59)] 

8 of 14 

Du et al., Science 379, eadg0014 (2023) 31 March 2023 

RESEARCH | REVIEW 



fore, the layer symmetry in reconstructed TMDC moiré superlattices is broken, enabling the emergence of two spatially alternating exciton species with distinct gate tunability and valley coherence properties (Fig. 4, I to K) (40, 59). In addition, reconstructed TMDC moiré superlattices open up new avenues to realize tunable exciton arrays and 1D localized exciton states with electrons and holes residing at opposite sides of the domainwall solitons for applications such as quantum optoelectronics (59). 

rise to the exotic magnetic circular dichroism (Fig. 4E) (120). Additionally, giant Kerr rotations, over an order of magnitude larger than those observed in typical materials, are predicted in moiré correlated electronic states (119). Nevertheless, coupling strongly correlated electronic states in moiré superlattices with light provides an exciting platform to create, probe, and manipulate strongly correlated states and new light-matter hybrids (e.g., photon-mediated superconductivity, ferroelectricity, or ferromagnetism; optically driven topological phenomena; highly correlated lightmatter states; and optical spin Hall effect). 

correlated insulating states, optical transition across the emerging Mott gap can largely enhance the dynamical conductivity and result in strong far-infrared photoresponses. For example, large photoresponses centered at ~18 meV are recently demonstrated at v = ±1/2 Hubbard-Mott insulating states of ABC trilayer graphene/h-BN moiré superlattices (Fig. 5D) (127, 128). We highlight that the strong far-infrared photocurrent responses induced by a correlated insulating gap in moiré superlattices can favor exotic optoelectronics and technological advances (e.g., detectors, sensors, and modulators). 





###### Moiré optoelectronics 

Optoelectronics involves the study and applications of electronic devices that can generate, modulate, detect, interact with, or control light, including photodetectors, light-emitting diodes, photovoltaics, modulators, and so on. Moiré superlattices with combined intriguing electronic and optical properties point to new avenues for cutting-edge optoelectronic applications. In this section, we briefly review the recent developments in state-of-the-art moiré optoelectronics. 

###### Symmetry-breaking optoelectronics 

###### Reconstructed collective excitations 

In the prior discussion, the influence of moiré superlattices on optical properties is based mainly on a rigid lattice model (Fig. 4F, left panel). By contrast, for moiré superlattices with a large period, the interlayer vdW interaction can compete with the intralayer lattice distortion and favor interlayer commensurability to minimize the misalignment energy, resulting in lattice reconstruction and thus breaking down the rigid lattice picture (60, 121, 122). For instance, a tessellated pattern of AB/BA triangular domains, separated by a network of narrow strain solitons, is formed in marginally twisted graphene and TMDC homobilayers (Fig. 4F, right panel) (60, 121, 122). Undoubtedly, the reconstructed moiré superlattices would cause renormalization of the electronic and optical properties. It was reported that the domain-wall solitons of marginally TBG are topologically protected chiral states and can strongly reflect the plasmon-polaritons (Fig. 4G) (61, 123). Consequently, a regular pattern of plasmon-polariton scatterers with a periodicity close to its wavelength is formed, transforming the TBG moiré superlattice into a natural nano-light photonic crystal (61). Crucially, such moiré photonic crystals are lithography-free and electrically tunable, representing an advantageous scenario for optical and optoelectronic telecommunications, as well as controllable quantum optical circuits. 

Moiré superlattices with strong electron correlations usually display various symmetrybreaking [e.g., broken inversion symmetry, broken time-reversal symmetry, and broken U(1) gauge symmetry] and thus provide a powerful platform for symmetry-breaking optoelectronics, such as bulk photovoltaic effect (BPVE), optovalley Hall effects, and chiral light-emitting diodes (3, 34, 129). For example, it was shown that because of moiré-induced symmetry breaking and quantum geometrical properties, strong BPVE at ~5 and 7.7 mm can occur in twisted double bilayer graphene moiré superlattices (Fig. 5E) (33). The moiré quantum geometry strongly depends on the displacement field and Fermi level, resulting in electrically tunable BPVE (e.g., the photovoltage amplitude and phase) in twisted double bilayer graphene superlattices. In addition, the midinfrared BPVE in twisted double bilayer graphene is surprisingly strong and reaches ~3.7 V W<sup>–1</sup> at 7.7 mm, much larger than previous demonstrations (33). We envision that the ultrastrong mid-infrared BPVE in moiré superlattices will stimulate next-generation applications in nonlinear optics and optoelectronics, such as intense terahertz sources, biological sensing, energy harvesting, and alloptical transistors. 

###### Strong mid- and far-infrared photoresponses 

In general, moiré superlattices are expected to show strong light–matter interaction and large photoresponses. First, the formation of flat minibands with a large density of states can enhance the dynamical conductivity. Second, the emergence of superlattice bandgap and correlated insulating gap on the order of tens of millielectronvolts can lead to resonance interband transition and thus favor strong photoresponses in the long-sought midand far-infrared and even terahertz ranges. When the Fermi level lies in the superlattice bandgap (Fig. 5A), the interband transition between the top of the moiré Dirac band and the bottom of the empty band leads to the resonance-enhanced dynamical conductivity and hence strong mid-infrared photoresponses in TBG moiré superlattices (Fig. 5B) (126). A giant extrinsic photoresponsivity of ~26 mA W<sup>−1</sup> at the mid-infrared wavelength of 12 mm is achieved in 1.81° TBG, which is almost a factor of 20 larger than the photoresponsivity of natural bilayer graphene (<1.5 mA W<sup>−1</sup> ) (126). As a result, TBG moiré superlattices provide an attractive material platform for the long-sought-after mid-infrared optoelectronic devices. 

The gate-tunable BPVE in twisted double bilayer graphene moiré superlattices, together with its dependence on incident optical polarization states, power, and wavelength, provides the possibility for the simultaneous decipherment of full-Stokes polarimetry and wavelength. Indeed, using the tunable mid-infrared BPVE in twisted double bilayer graphene as an encoder and a trained convolutional neural network as a decoder (Fig. 5F), a compact intelligent infrared sensor with merely a subwavelength footprint is achieved (33). After proper training of the convolutional neural network, the intelligent infrared sensing can identify the fingerprint of light, including the full Stokes parameters and the wavelength (Fig. 5G) (33), a pathway for future intelligent sensing technologies in an extremely compact, on-chip manner. 

In addition, the domain-wall solitons and soliton interceptions have considerable strain, facilitating strain-engineered photonics. For example, the emergence of strain in reconstructed graphene or MoS2 moiré superlattices distorts the hexagonal unit cell, leading to the splitting of the doubly degenerate E2 g phonon mode (Fig. 4H) (124, 125). The reconstructed moiré superlattices also have profound impacts on symmetry-breaking photonics. For near-0°twist-angle TMDC homobilayers, atomic reconstruction leads to the formation of energetically favorable AB and BA stacking. Owing to the simultaneous breaking of inversion and mirror symmetries, rhombohedral AB and BA stacking configurations show out-of-plane ferroelectric polarization, but with opposite signs. There- 

By using the optical transition between moiré flat minibands, strong far-infrared photocurrent responses have been seen in ABC trilayer graphene/h-BN moiré superlattices (Fig. 5C) (127). Owing to the electrically tunable moiré minibands, including both the bandwidth and bandgap, the photocurrent responses show high tunability over 80 meV in external electric fields (Fig. 5C, inset) (127). Upon doping the flat moiré miniband to form 

9 of 14 

Du et al., Science 379, eadg0014 (2023) 31 March 2023 

RESEARCH | REVIEW 





<!-- Start of picture text -->
A B E<br>E F<br>C D<br>F G<br>c<br>H I J<br><!-- End of picture text -->







Fig. 5. Moiré optoelectronics. (A) Calculated band structure of 1.81° TBG, showing superlattice-induced bandgaps below and above moiré Dirac bands. (B) Photoresponses of TBG moiré superlattices at 5.0-, 7.7-, and 12-mm light illumination. Inset: Schematic diagram of the moiré superlattice device for photocurrent measurement. (C and D) The photocurrent spectra of ABC trilayer graphene/h-BN moiré superlattices at zero-filling (C) and half-filling of the flat valence band (D). Photocurrents in (C) and (D) are dominated by a sharp peak at ~45 meV and a broad peak at ~18 meV, respectively, corresponding to excitation between moiré conduction and valence minibands or to excitation across the emerging Mott gap, as illustrated by the inset. The inset on the right in (D) shows the optical transition across the Mott gap. (E) Photovoltage against the angle of a 

quarter-wave plate (QWP) at different gate voltage biases. (F) Schematic diagram of the convolutional neural network used for detection of the full-Stokes and wavelength. (G) Comparison of the polarization states obtained from convolutional neural network (CNN) outputs (red or orange spheres for training or test data) with those directly measured values (blue spheres), showing high accuracy. (H) Comparison of carrier density and thickness between superconductor magic-angle TBG and 2D, thin-film superconductors below 10 nm. Inset: Phase diagram of magic-angle TBG. (I) Schematic cartoon of magic-angle TBG superconducting single-photon nanocalorimeter. (J) Nano-imaging photocurrent of a TBG moiré superlattice. [Adapted with permission from (A and B) (126), (C and D) (127), (E to G) (33), (H and I) (134), (J) (135)] 

10 of 14 

Du et al., Science 379, eadg0014 (2023) 31 March 2023 

RESEARCH | REVIEW 



those moiré superlattices composed of 2D ferroelectric, magnetic, and multiferroic crystals. In particular, recent studies reveal that magnetic moiré superlattices can display a pattern of nanoscale domains that alternate with layered antiferromagnetic and ferromagnetic states (41, 42). Consequently, magnetic moiré superlattices enable the control of magnetic order, symmetry breaking, and interlayer hybridization on the nanoscale (138), opening a huge swath of possibilities for engineering photonic and optoelectronic properties—for example, nonreciprocal second-harmonic generation (139), magnon-exciton coupling (140), and inelastic light scattering (141). Beyond the single moiré, a moiré landscape involving two or multiple single moiré superlattices provides another direction and has the potential to spark the next “gold rush” of new moiré photonics and optoelectronics. For instance, the long-sought boson exciton crystals have been recently evidenced in a WSe2/MoSe2/WSe2 heterotrilayer consisting of two single moiré patterns, paving a way toward the exploration of quantum optoelectronics and quantum coherent phenomena (32). Further, moiré superlattices beyond 2D materials, such as 1D vdW moiré superlattices (142), and moiré artificial metamaterials (143, 144) could also offer promising avenues for engineering moiré photonics and optoelectronics, e.g., localizationto-delocalization transition of light (143), magicangle lasers (144), and optical solitons (145). 

Apart from the mid-infrared BPVE in twisted double bilayer graphene (33), it was also shown that the symmetry of TBG close to the second magic angle (~0.6°) is reduced to point group C1, breaking both the inversion and rotational symmetries, and enabling the exotic BPVE in the terahertz region (130). It is expected that highly tunable BPVE can also emerge in other moiré superlattices and is worthwhile to explore, especially for rotationally aligned graphene/h-BN, hetero-, and homo-TMDC bilayers, in which electron correlation–triggered symmetry breaking and giant second-order nonlinear responses have recently been uncovered by electrical transport (131, 132). 

large portfolio of fascinating optoelectronic devices with superior performance would emerge, e.g., single photon light-emitting devices, optical modulators, photoinduced valley currents, etc. 





###### Perspectives and conclusions 

The field of moiré photonics and optoelectronics is progressing rapidly. A diverse series of moiré photonic and optoelectronic phenomena have been witnessed in the span of less than 5 years, including but not limited to moiré excitons and polaritons, resonantly hybridized excitons, reconstructed collective excitations, strong mid-infrared photoresponses, intelligent light sensors, and terahertz single-photon detection. This not only opens up exciting possibilities for a wide range of new frontiers in basic scientific research, but also outlines a bright vision for various sophisticated physical phenomena and emerging technological innovations. Moreover, the dizzying pace of recent achievements suggests that we have only seen the tip of the iceberg, and there will be many more surprises to come in moiré photonics and optoelectronics. 

###### Single-photon detection 

The detection of light at the single-photon level is crucial for a host of theoretical, experimental, and technological advances, such as quantum information processing, quantum sensing, quantum key distribution, and radio astronomy (70). By using heat-induced breaking of the superconducting states in nanostructured superconductors, advanced single-photon detectors with operation wavelengths in the range between visible and near-infrared have been well developed and even commercialized. However, because of high electron density and thus large heat capacity in traditional superconductors, single-photon detector technologies in the ultralow photon energy regions (e.g., mid-infrared and terahertz frequencies) are extremely difficult to achieve. Notably, magic-angle TBG moiré superlattices can show dome-shaped superconducting states at a record-low electron density (~10<sup>12</sup> cm<sup>−2</sup> ), and thus, an extremely small heat capacity (e.g., a few hundred times the Boltzmann constant) (Fig. 5H) (133, 134). Consequently, a single photon, even with ultralow energy, can cause a sizable temperature increase to break down the superconducting state, offering extraordinary opportunities for single-photon detection in previously unattainable mid-infrared and even terahertz range (Fig. 5I) (17, 133, 134). Indeed, by quantifying the calorimetric photoresponses, it was demonstrated theoretically that magic-angle TBG can have an ultrabroad detection range of light at the single-photon level from the visible to sub-terahertz with an exceptionally fast response time of ∼4 ns as well as a high energy resolution better than 1 THz (134). Further efforts are required to experimentally demonstrate such exciting single-photon devices. 

###### Advanced scanning probe techniques 

One future direction is to develop new, advanced scanning probe techniques with an ultrahigh spatial resolution (e.g., <5 nm), and therefore that can probe the photonic and optoelectronic properties in an individual moiré supercell. Currently, the measurements of moiré photonics and optoelectronics are based on far-field techniques with a spot size of ~1 mm. As a consequence, the detected results are a collection of signals from more than 10,000 moiré unit cells. Owing to the ubiquity of twist-angle inhomogeneity and strain from the fabrication of devices, the observed results are often highly complex and lack reproducibility. For instance, some moiré photonic and optoelectronic phenomena have been reported by only a single group and are yet to be reproduced by others. Developing new techniques that can locally probe the photonic and optoelectronic properties of different highsymmetry points within a single moiré unit cell [such as 4D scanning TEM spectroscopy (137) and near-field scanning (61)] will undoubtedly advance our understanding of the current conundrums and contradictions and greatly facilitate the further development of moiré photonics and optoelectronics. 

###### Engineering moiré photonics and optoelectronics 

Another crucial direction is to control moiré photonic and optoelectronic properties through different external degrees of freedom (such as ultrafast optical excitations, electric and magnetic field, strain, twist angle, doping, pressure, and Floquet engineering). For instance, it has been theoretically elucidated that because of different local static dipole moments, the electric field can switch the global moiré potential minima from one high-symmetry point to another high-symmetry point via the quantum-confined Stark effect, enabling the possibilities of programming the spatial locations and optical selection rule of moiré-trapped excitons on demand (66). Experimentally, it has also been demonstrated that strain can play a role in tailoring the moiré potential landscape and optoelectronic response (146). To name a few, uniaxial strain can tune the array of quantum dot–like 0D traps into parallel stripes of 1D quantum wires, breaking the threefold rotational symmetry and changing the optical selection rule of moiré exciton from circular to linear (146). It was shown that the itinerant excitons excited by light can highly tune the spin-spin exchange interactions between moiré-trapped carriers and result in ferromagnetic order in WS2/WSe2 moiré superlattices, outlining the possibility of all-optical 

###### New moiré systems 

In close resemblance to reconstructed photonics, moiré superlattices with lattice reconstruction would also lead to the renormalization of optoelectronic properties, such as the formation of photocurrent patterns (Fig. 5J) (135, 136). In addition, by integrating moiré superlattices with other structures, such as waveguides, cavities, plasmonics, and ring resonators, a 

Considering that there are thousands of 2D crystals and the current research on moiré photonics and optoelectronics is only focused on twisted graphene and twisted TMDCs, one of the particularly intriguing directions is to explore the exotic photonic and optoelectronic phenomena of new moiré systems, such as 

11 of 14 

Du et al., Science 379, eadg0014 (2023) 31 March 2023 

RESEARCH | REVIEW 



control of emergent moiré photonic and optoelectronic phenomena (120). 

superlattices, by integrating with other optical systems (e.g., optical cavities, resonances, silicon-based waveguides, and fibers), will undoubtedly outline a bright vision for numerous emerging photonic and optoelectronic applications, such as quantum nonlinear optics, lasers, imaging arrays, modulators, switches, and polarization devices. 





- 81–86 (2019). doi: 10.1038/s41586-019-0986-9; pmid: 30842637 

- 23. H. Baek et al., Highly energy-tunable quantum light from moiré-trapped excitons. Sci. Adv. 6, eaba8526 (2020). doi: 10.1126/sciadv.aba8526; pmid: 32917702 

###### Technical innovations 

24. A. L. Sharpe et al., Emergent ferromagnetism near three-quarters filling in twisted bilayer graphene. Science 365, 605–608 (2019). doi: 10.1126/science.aaw3780; pmid: 31346139 

Particularly interesting fields where moiré optoelectronics have the potential to trigger new on-chip applications include, but are not limited to, high-performance moiré lasers, quantum simulation of the Bose-Hubbard model, and programmable quantum light sources. Recently, by integrating MoS2/WSe2 superlattices with a silicon topological nanocavity, ultralow-threshold broadband excitonic lasing at the technologically important telecommunication O-band (1260 to 1360 nm) has been achieved at room temperature (147). The moiré excitonic laser shows the highest spectral coherence of <0.1-nm linewidth among all 2D material–based laser systems studied so far, facilitating high-performance on-chip photonics and optoelectronics (e.g., electrically pumped wavelength-tunable moiré lasers) (147). Further, owing to enhanced Coulomb interactions, moiré superlattices offer opportunities to create a regular array of spatially ordered quantum emitters. In the case of moiré interlayer excitons with long lifetime and strong dipolar interactions, the perfect arrays provide a promising paradigm for the realization of quantum simulation of BoseHubbard model. It is noteworthy that the Bose-Hubbard model, which underlies rich bosonic states of matter and quantum phase transitions, is challenging to achieve in solidstate systems. Theoretically, a wide variety of bosonic quantum matter phases and quantum phase transition associated with quantumdot–like interlayer excitons have been predicted in moiré superlattices, such as exciton supersolid, superfluid-insulator phase transition, and bosonic Mott insulator (148, 149). Experimentally, exciton Mott insulator and exciton density waves have been recently reported in WSe2/WS2 and Coulomb-coupled WS2/bilayer WSe2/WS2 dual moiré superlattices, respectively (150, 151). 

25. G. Chen et al., Tunable correlated Chern insulator and ferromagnetism in a moiré superlattice. Nature 579, 56–61 (2020). doi: 10.1038/s41586-020-2049-7; pmid: 32132694 

26. M. Serlin et al., Intrinsic quantized anomalous Hall effect in a moiré heterostructure. Science 367, 900–903 (2020). doi: 10.1126/science.aay5533; pmid: 31857492 

27. E. C. Regan et al., Mott and generalized Wigner crystal states in WSe2/WS2 moiré superlattices. Nature 579, 359–363 (2020). doi: 10.1038/s41586-020-2092-4; pmid: 32188951 

28. X. Huang et al., Correlated insulating states at fractional fillings of the WS2/WSe2 moiré lattice. Nat. Phys. 17, 715–719 (2021). doi: 10.1038/s41567-021-01171-w 

###### REFERENCES AND NOTES 

1. K. S. Novoselov, A. Mishchenko, A. Carvalho, A. H. Castro Neto, 

   - 2D materials and van der Waals heterostructures. Science 353, aac9439 (2016). doi: 10.1126/science.aac9439; pmid: 27471306 

2. C. Jin et al., Ultrafast dynamics in van der Waals 

- heterostructures. Nat. Nanotechnol. 13, 994–1003 (2018). doi: 10.1038/s41565-018-0298-5; pmid: 30397296 

- 3. L. Du et al., Engineering symmetry breaking in 2D layered materials. Nat. Rev. Phys. 3, 193–206 (2021). doi: 10.1038/s42254-020-00276-0 

   29. Y. Jiang et al., Charge order and broken rotational symmetry in magic-angle twisted bilayer graphene. Nature 573, 91–95 (2019). doi: 10.1038/s41586-019-1460-4; pmid: 31365921 

   30. C. Jin et al., Stripe phases in WSe2/WS2 moiré superlattices. Nat. Mater. 20, 940–944 (2021). doi: 10.1038/ s41563-021-00959-8; pmid: 33767398 

   31. M. Haavisto, J. Lado, A. O. Fumega, Topological multiferroic order in twisted transition metal dichalcogenide bilayers. SciPost Phys. 13, 052 (2022). doi: 10.21468/ SciPostPhys.13.3.052 

4. B. Huang et al., Emergent phenomena and proximity effects in two-dimensional magnets and heterostructures. Nat. Mater. 19, 1276–1289 (2020). doi: 10.1038/s41563-020-0791-8; pmid: 32948831 

5. N. Briggs et al., Atomically thin half-van der Waals metals enabled by confinement heteroepitaxy. Nat. Mater. 19, 637–643 (2020). doi: 10.1038/s41563-020-0631-x; pmid: 32157191 

6. Q. H. Wang, K. Kalantar-Zadeh, A. Kis, J. N. Coleman, M. S. Strano, Electronics and optoelectronics of two-dimensional transition metal dichalcogenides. Nat. Nanotechnol. 7, 699–712 (2012). doi: 10.1038/ nnano.2012.193; pmid: 23132225 

   32. Y. Bai et al., Evidence for Exciton Crystals in a 2D Semiconductor Heterotrilayer. arXiv:2207.09601 (2022). 

   33. C. Ma et al., Intelligent infrared sensing enabled by tunable moiré quantum geometry. Nature 604, 266–272 (2022). doi: 10.1038/s41586-022-04548-w; pmid: 35418636 

   34. C. N. Lau, M. W. Bockrath, K. F. Mak, F. Zhang, Reproducibility in the fabrication and physics of moiré materials. Nature 602, 41–50 (2022). doi: 10.1038/s41586021-04173-z; pmid: 35110759 

7. L. Du et al., 2D proximate quantum spin liquid state in atomic-thin a-RuCl3. 2D Mater. 6, 015014 (2018). doi: 10.1088/2053-1583/aaee29 

8. A. K. Geim, I. V. Grigorieva, Van der Waals heterostructures. Nature 499, 419–425 (2013). doi: 10.1038/nature12385; pmid: 23887427 

9. Y. Liu et al., Van der Waals heterostructures and devices. Nat. Rev. Mater. 1, 16042 (2016). doi: 10.1038/ natrevmats.2016.42 

   35. D. Huang, J. Choi, C.-K. Shih, X. Li, Excitons in semiconductor moiré superlattices. Nat. Nanotechnol. 17, 227–238 (2022). doi: 10.1038/s41565-021-01068-y; pmid: 35288673 

   36. E. C. Regan et al., Emerging exciton physics in transition metal dichalcogenide heterobilayers. Nat. Rev. Mater. 7, 778–795 (2022). doi: 10.1038/s41578-022-00440-1 

   37. K. Kim et al., van der Waals Heterostructures with High Accuracy Rotational Alignment. Nano Lett. 16, 1989–1995 (2016). doi: 10.1021/acs.nanolett.5b05263; pmid: 26859527 

   38. R. Frisenda et al., Recent progress in the assembly of nanodevices and van der Waals heterostructures by deterministic placement of 2D materials. Chem. Soc. Rev. 47, 53–68 (2018). doi: 10.1039/C7CS00556C; pmid: 29111548 

   39. L. Wang et al., Correlated electronic phases in twisted bilayer transition metal dichalcogenides. Nat. Mater. 19, 861–866 (2020). doi: 10.1038/s41563-020-0708-6; pmid: 32572205 

   40. J. Sung et al., Broken mirror symmetry in excitonic response of reconstructed domains in twisted MoSe2/MoSe2 bilayers. Nat. Nanotechnol. 15, 750–754 (2020). doi: 10.1038/s41565-020-0728-z; pmid: 32661373 

   41. T. Song et al., Direct visualization of magnetic domains and moiré magnetism in twisted 2D magnets. Science 374, 1140–1144 (2021). doi: 10.1126/science.abj7478; pmid: 34822270 

10. E. Y. Andrei et al., The marvels of moiré materials. Nat. Rev. Mater. 6, 201–206 (2021). doi: 10.1038/s41578-021-00284-1 

11. Y. Xu et al., Correlated insulating states at fractional fillings of moiré superlattices. Nature 587, 214–218 (2020). doi: 10.1038/s41586-020-2868-6; pmid: 33177668 

12. N. P. Wilson, W. Yao, J. Shan, X. Xu, Excitons and emergent quantum phenomena in stacked 2D semiconductors. Nature 599, 383–392 (2021). doi: 10.1038/s41586-021-03979-1; pmid: 34789905 

13. K. F. Mak, J. Shan, Semiconductor moiré materials. Nat. Nanotechnol. 17, 686–695 (2022). doi: 10.1038/ s41565-022-01165-6; pmid: 35836003 

14. R. Bistritzer, A. H. MacDonald, Moire bands in twisted doublelayer graphene. Proc. Natl. Acad. Sci. U.S.A. 108, 12233–12237 (2011). doi: 10.1073/pnas.1108174108; pmid: 21730173 

In addition, in the case of intralayer excitons with high quantum efficiency and relatively low sensitivity to disorder in the surrounding dielectric, the spatially ordered moiré exciton array could serve as a superbright quantum light source (12, 66). In particular, moiré quantum light sources show high programmability withpolarization configurationand wavelength controlled by optical pumping, electric field, and strain. Such programmable quantum light sources would provide a firm basis for the exploration of coherent quantum phenomena of optical bosons and the development of various quantum technologies (70), such as the generation of polarization-entangled photon pairs, Dicke superradiance, spin-photon interfaces, quantum information processing, encryption, and sensing. In addition, moiré 

15. L. A. Ponomarenko et al., Cloning of Dirac fermions in graphene superlattices. Nature 497, 594–597 (2013). doi: 10.1038/nature12187; pmid: 23676678 

16. C. R. Dean et al., Hofstadter’s butterfly and the fractal quantum Hall effect in moiré superlattices. Nature 497, 598–602 (2013). doi: 10.1038/nature12186; pmid: 23676673 

17. Y. Cao et al., Unconventional superconductivity in magicangle graphene superlattices. Nature 556, 43–50 (2018). doi: 10.1038/nature26160; pmid: 29512651 

18. Y. Cao et al., Correlated insulator behaviour at half-filling in magic-angle graphene superlattices. Nature 556, 80–84 (2018). doi: 10.1038/nature26154; pmid: 29512654 

   42. Y. Xu et al., Coexisting ferromagnetic-antiferromagnetic state in twisted bilayer CrI3. Nat. Nanotechnol. 17, 143–147 (2022). doi: 10.1038/s41565-021-01014-y; pmid: 34845332 

   43. Y. Tang et al., Simulation of Hubbard model physics in WSe2/WS2 moiré superlattices. Nature 579, 353–358 (2020). doi: 10.1038/s41586-020-2085-3; pmid: 32188950 

   44. A. J. Mannix et al., Robotic four-dimensional pixel assembly of van der Waals solids. Nat. Nanotechnol. 17, 361–366 (2022). doi: 10.1038/s41565-021-01061-5; pmid: 35075299 

   45. S. Masubuchi et al., Autonomous robotic searching and assembly of two-dimensional crystals to build van der Waals superlattices. Nat. Commun. 9, 1413 (2018). doi: 10.1038/ s41467-018-03723-w; pmid: 29650955 

19. K. L. Seyler et al., Signatures of moiré-trapped valley excitons in MoSe2/WSe2 heterobilayers. Nature 567, 66–70 (2019). doi: 10.1038/s41586-019-0957-1; pmid: 30804526 

20. C. Jin et al., Observation of moiré excitons in WSe2/WS2 heterostructure superlattices. Nature 567, 76–80 (2019). doi: 10.1038/s41586-019-0976-y; pmid: 30804525 

   46. Q. Wang et al., Layer-by-layer epitaxy of multi-layer MoS2 wafers. Natl. Sci. Rev. 9, nwac077 (2022). doi: 10.1093/nsr/ nwac077; pmid: 35769232 

21. K. Tran et al., Evidence for moiré excitons in van der Waals heterostructures. Nature 567, 71–75 (2019). doi: 10.1038/ s41586-019-0975-z; pmid: 30804527 

   47. P. Solís-Fernández, H. Ago, Machine Learning Determination of the Twist Angle of Bilayer Graphene by Raman Spectroscopy: Implications for van der Waals 

22. E. M. Alexeev et al., Resonantly hybridized excitons in moiré superlattices in van der Waals heterostructures. Nature 567, 

12 of 14 

Du et al., Science 379, eadg0014 (2023) 31 March 2023 

RESEARCH | REVIEW 







      - dichalcogenides in Van der Waals heterostructures. 2D Mater. 4, 015026 (2016). doi: 10.1088/2053-1583/4/1/015026 

   72. J. Wang et al., Diffusivity Reveals Three Distinct Phases of Interlayer Excitons in MoSe2/WSe2 Heterobilayers. Phys. Rev. Lett. 126, 106804 (2021). doi: 10.1103/ PhysRevLett.126.106804; pmid: 33784140 

- Heterostructures. ACS Appl. Nano Mater. 5, 1356–1366 (2022). doi: 10.1021/acsanm.1c03928 

- 48. P. Chen, Z. Zhang, X. Duan, X. Duan, Chemical synthesis of two-dimensional atomic crystals, heterostructures and superlattices. Chem. Soc. Rev. 47, 3129–3151 (2018). doi: 10.1039/C7CS00887B; pmid: 29528342 

   96. P. Rivera et al., Interlayer valley excitons in heterobilayers of transition metal dichalcogenides. Nat. Nanotechnol. 13, 1004–1015 (2018). doi: 10.1038/s41565-018-0193-0; pmid: 30104622 

73. E. Liu et al., Signatures of moiré trions in WSe2/MoSe2 heterobilayers. Nature 594, 46–50 (2021). doi: 10.1038/ s41586-021-03541-z; pmid: 34079140 

74. H. Baek et al., Optical read-out of Coulomb staircases in a moiré superlattice via trapped interlayer trions. Nat. Nanotechnol. 16, 1237–1243 (2021). doi: 10.1038/ s41565-021-00970-9; pmid: 34556832 

   97. Y. Zhao et al., Interlayer exciton complexes in bilayer MoS2. Phys. Rev. B 105, L041411 (2022). doi: 10.1103/ PhysRevB.105.L041411 

49. W. Yang et al., Epitaxial growth of single-domain graphene on hexagonal boron nitride. Nat. Mater. 12, 792–797 (2013). doi: 10.1038/nmat3695; pmid: 23852399 

   98. C. Schneider, M. M. Glazov, T. Korn, S. Höfling, B. Urbaszek, Two-dimensional semiconductors in the regime of strong light-matter coupling. Nat. Commun. 9, 2695 (2018). doi: 10.1038/s41467-018-04866-6; pmid: 30002368 

50. L. Yuan et al., Twist-angle-dependent interlayer exciton diffusion in WS2-WSe2 heterobilayers. Nat. Mater. 19, 617–623 (2020). doi: 10.1038/s41563-020-0670-3; pmid: 32393806 

   75. X. Wang et al., Moiré trions in MoSe2/WSe2 heterobilayers. Nat. Nanotechnol. 16, 1208–1213 (2021). doi: 10.1038/ s41565-021-00969-2; pmid: 34531556 

   76. K. F. Mak, D. Xiao, J. Shan, Light-valley interactions in 2D semiconductors. Nat. Photonics 12, 451–460 (2018). doi: 10.1038/s41566-018-0204-6 

51. C. Zhang et al., Interlayer couplings, Moiré patterns, and 2D electronic superlattices in MoS2/WSe2 hetero-bilayers. Sci. Adv. 3, e1601459 (2017). doi: 10.1126/sciadv.1601459; pmid: 28070558 

   99. D. N. Basov, M. M. Fogler, F. J. García de Abajo, Polaritons in van der Waals materials. Science 354, aag1992 (2016). doi: 10.1126/science.aag1992; pmid: 27738142 

   100. T. Low et al., Polaritons in layered two-dimensional materials. Nat. Mater. 16, 182–194 (2017). doi: 10.1038/nmat4792; pmid: 27893724 

52. L. Du et al., Modulating PL and electronic structures of MoS2/graphene heterostructures via interlayer twisting angle. Appl. Phys. Lett. 111, 263106 (2017). doi: 10.1063/1.5011120 

53. R. Ribeiro-Palau et al., Twistable electronics with dynamically rotatable heterostructures. Science 361, 690–693 (2018). doi: 10.1126/science.aat6981 

77. H. Yu, Y. Wang, Q. Tong, X. Xu, W. Yao, Anomalous Light Cones and Valley Optical Selection Rules of Interlayer Excitons in Twisted Heterobilayers. Phys. Rev. Lett. 115, 187002 (2015). doi: 10.1103/PhysRevLett.115.187002; pmid: 26565491 

   101. L. Zhang et al., Van der Waals heterostructure polaritons with moiré-induced nonlinearity. Nature 591, 61–65 (2021). doi: 10.1038/s41586-021-03228-5; pmid: 33658695 

78. S. Brem, C. Linderälv, P. Erhart, E. Malic, Tunable Phases of Moiré Excitons in van der Waals Heterostructures. Nano Lett. 20, 8534–8540 (2020). doi: 10.1021/acs.nanolett.0c03019; pmid: 32970445 

   102. G. X. Ni et al., Plasmons in graphene moiré superlattices. Nat. Mater. 14, 1217–1222 (2015). doi: 10.1038/nmat4425; pmid: 26413987 

54. M. Liao et al., UItra-low friction and edge-pinning effect in large-lattice-mismatch van der Waals heterostructures. Nat. Mater. 21, 47–53 (2022). doi: 10.1038/s41563-02101058-4; pmid: 34354215 

      103. N. C. H. Hesp et al., Observation of interband collective excitations in twisted bilayer graphene. Nat. Phys. 17, 1162–1168 (2021). doi: 10.1038/s41567-021-01327-8 

   79. F. Wu, T. Lovorn, A. H. MacDonald, Theory of optical absorption by interlayer excitons in transition metal dichalcogenide heterobilayers. Phys. Rev. B 97, 035306 (2018). doi: 10.1103/PhysRevB.97.035306 

55. S. M. Akkanen, H. A. Fernandez, Z. Sun, Optical Modification of 2D Materials: Methods and Applications. Adv. Mater. 34, e2110152 (2022). doi: 10.1002/adma.202110152; pmid: 35139583 

      104. T. Huang et al., Observation of chiral and slow plasmons in twisted bilayer graphene. Nature 605, 63–68 (2022). doi: 10.1038/s41586-022-04520-8; pmid: 35508778 

   80. T. Smoleński et al., Signatures of Wigner crystal of electrons in a monolayer semiconductor. Nature 595, 53–57 (2021). doi: 10.1038/s41586-021-03590-4; pmid: 34194018 

   81. N. Zhang et al., Moiré Intralayer Excitons in a MoSe2/MoS2 Heterostructure. Nano Lett. 18, 7651–7657 (2018). doi: 10.1021/acs.nanolett.8b03266; pmid: 30403876 

   82. M. H. Naik et al., Intralayer charge-transfer moiré excitons in van der Waals superlattices. Nature 609, 52–57 (2022). doi: 10.1038/s41586-022-04991-9; pmid: 36045239 

   83. A. Ciarrocchi et al., Polarization switching and electrical control of interlayer excitons in two-dimensional van der Waals heterostructures. Nat. Photonics 13, 131–136 (2019). doi: 10.1038/s41566-018-0325-y; pmid: 30886643 

   84. E. Marcellina et al., Evidence for Moiré Trions in Twisted MoSe2 Homobilayers. Nano Lett. 21, 4461–4468 (2021). doi: 10.1021/acs.nanolett.1c01207; pmid: 33970625 

   85. A. Righi et al., Graphene moiré patterns observed by umklapp double-resonance Raman scattering. Phys. Rev. B Condens. Matter Mater. Phys. 84, 241409 (2011). doi: 10.1103/ PhysRevB.84.241409 

56. D. Wang et al., Thermally Induced Graphene Rotation on Hexagonal Boron Nitride. Phys. Rev. Lett. 116, 126101 (2016). doi: 10.1103/PhysRevLett.116.126101; pmid: 27058087 

57. Z. Zhang et al., Flat bands in twisted bilayer transition metal dichalcogenides. Nat. Phys. 16, 1093–1096 (2020). doi: 10.1038/s41567-020-0958-x 

   105. C. Lewandowski, L. Levitov, Intrinsically undamped plasmon modes in narrow electron bands. Proc. Natl. Acad. Sci. U.S.A. 116, 20869–20874 (2019). doi: 10.1073/pnas.1909069116; pmid: 31562197 

   106. T. Stauber, H. Kohler, Quasi-Flat Plasmonic Bands in Twisted Bilayer Graphene. Nano Lett. 16, 6844–6849 (2016). doi: 10.1021/acs.nanolett.6b02587; pmid: 27776411 

58. L. J. McGilly et al., Visualization of moiré superlattices. Nat. Nanotechnol. 15, 580–584 (2020). doi: 10.1038/ s41565-020-0708-3; pmid: 32572229 

   107. L. Brey, T. Stauber, T. Slipchenko, L. Martín-Moreno, Plasmonic Dirac Cone in Twisted Bilayer Graphene. Phys. Rev. Lett. 125, 256804 (2020). doi: 10.1103/PhysRevLett.125.256804; pmid: 33416378 

59. T. I. Andersen et al., Excitons in a reconstructed moiré potential in twisted WSe2/WSe2 homobilayers. Nat. Mater. 20, 480–487 (2021). doi: 10.1038/s41563-020-00873-5; pmid: 33398121 

   108. G. Hu et al., Topological polaritons and photonic magic angles in twisted a-MoO3 bilayers. Nature 582, 209–213 (2020). doi: 10.1038/s41586-020-2359-9; pmid: 32528096 

60. A. Weston et al., Atomic reconstruction in twisted bilayers of transition metal dichalcogenides. Nat. Nanotechnol. 15, 592–597 (2020). doi: 10.1038/s41565-020-0682-9; pmid: 32451502 

   109. M. Chen et al., Configurable phonon polaritons in twisted a-MoO3. Nat. Mater. 19, 1307–1311 (2020). doi: 10.1038/ s41563-020-0732-6; pmid: 32661384 

61. S. S. Sunku et al., Photonic crystals for nano-light in moiré graphene superlattices. Science 362, 1153–1156 (2018). doi: 10.1126/science.aau5144; pmid: 30523109 

      110. Z. Zhang et al., Correlated interlayer exciton insulator in heterostructures of monolayer WSe2 and moiré WS2/ WSe2. Nat. Phys. 18, 1214–1220 (2022). doi: 10.1038/ s41567-022-01702-z 

   86. G. S. N. Eliel et al., Intralayer and interlayer electron-phonon interactions in twisted graphene heterostructures. Nat. Commun. 9, 1221 (2018). doi: 10.1038/s41467-01803479-3; pmid: 29572537 

   87. A. Eckmann et al., Raman fingerprint of aligned graphene/ h-BN superlattices. Nano Lett. 13, 5242–5246 (2013). doi: 10.1021/nl402679b; pmid: 24156357 

   88. M. Liao et al., Precise control of the interlayer twist angle in large scale MoS2 homostructures. Nat. Commun. 11, 2153 (2020). doi: 10.1038/s41467-020-16056-4; pmid: 32358571 

   89. D. A. Ruiz-Tijerina, V. I. Fal’ko, Interlayer hybridization and moiré superlattice minibands for electrons and excitons inheterobilayers of transition-metal dichalcogenides. Phys. Rev. B 99, 125424 (2019). doi: 10.1103/PhysRevB.99.125424 

62. K. Lee et al., Ultrahigh-resolution scanning microwave impedance microscopy of moiré lattices and superstructures. Sci. Adv. 6, eabd1919 (2020). doi: 10.1126/sciadv.abd1919; pmid: 33298449 

   111. J. Gu et al., Dipolar excitonic insulator in a moiré lattice. Nat. Phys. 18, 395–400 (2022). doi: 10.1038/s41567-022-01532-z 

   112. H. Li et al., Imaging two-dimensional generalized Wigner crystals. Nature 597, 650–654 (2021). doi: 10.1038/ s41586-021-03874-9; pmid: 34588665 

63. J. Yu et al., Imaging Graphene Moiré Superlattices via Scanning Kelvin Probe Microscopy. Nano Lett. 21, 3280–3286 (2021). doi: 10.1021/acs.nanolett.1c00609; pmid: 33749279 

   113. L. Ma et al., Strongly correlated excitonic insulator in atomic double layers. Nature 598, 585–589 (2021). doi: 10.1038/ s41586-021-03947-9; pmid: 34707306 

64. K.-Q. Lin et al., Large-Scale Mapping of Moiré Superlattices by Hyperspectral Raman Imaging. Adv. Mater. 33, e2008333 (2021). doi: 10.1002/adma.202008333; pmid: 34242447 

   114. E. Liu et al., Excitonic and Valley-Polarization Signatures of Fractional Correlated Electronic Phases in a WSe2/WS2 Moiré Superlattice. Phys. Rev. Lett. 127, 037402 (2021). doi: 10.1103/PhysRevLett.127.037402; pmid: 34328773 

65. G. Wang et al., Colloquium: Excitons in atomically thin transition metal dichalcogenides. Rev. Mod. Phys. 90, 021001 (2018). doi: 10.1103/RevModPhys.90.021001 

      115. S. Miao et al., Strong interaction between interlayer excitons and correlated electrons in WSe2/WS2 moiré superlattice. Nat. Commun. 12, 3608 (2021). doi: 10.1038/ s41467-021-23732-6; pmid: 34127668 

   90. L. Zhang et al., Twist-angle dependence of moiré excitons in WS2/MoSe2 heterobilayers. Nat. Commun. 11, 5888 (2020). doi: 10.1038/s41467-020-19466-6; pmid: 33208738 

   91. Y. Tang et al., Tuning layer-hybridized moiré excitons by the quantum-confined Stark effect. Nat. Nanotechnol. 16, 52–57 (2021). doi: 10.1038/s41565-020-00783-2; pmid: 33139934 

66. H. Yu, G.-B. Liu, J. Tang, X. Xu, W. Yao, Moiré excitons: From programmable quantum emitter arrays to spin-orbitcoupled artificial lattices. Sci. Adv. 3, e1701696 (2017). doi: 10.1126/sciadv.1701696; pmid: 29152568 

67. F. Wu, T. Lovorn, A. H. MacDonald, Topological Exciton Bands in Moiré Heterojunctions. Phys. Rev. Lett. 118, 147401 (2017). doi: 10.1103/PhysRevLett.118.147401; pmid: 28430504 

   116. Y. Shimazaki et al., Optical Signatures of Periodic Charge Distribution in a Mott-like Correlated Insulator State. Phys. Rev. X 11, 021027 (2021). doi: 10.1103/ PhysRevX.11.021027 

92. Y. Shimazaki et al., Strongly correlated electrons and hybrid excitons in a moiré heterostructure. Nature 580, 472–477 (2020). doi: 10.1038/s41586-020-2191-2; pmid: 32322064 

   117. L. Du et al., Giant anisotropic photonics in the 1D van der Waals semiconductor fibrous red phosphorus. Nat. Commun. 12, 4822 (2021). doi: 10.1038/s41467-021-25104-6; pmid: 34376660 

68. M. Brotons-Gisbert et al., Spin-layer locking of interlayer excitons trapped in moiré potentials. Nat. Mater. 19, 630–636 (2020). doi: 10.1038/s41563-020-0687-7; pmid: 32451512 

   93. H. Yu, W. Yao, Luminescence Anomaly of Dipolar Valley Excitons in Homobilayer Semiconductor Moiré Superlattices. Phys. Rev. X 11, 021042 (2021). doi: 10.1103/ PhysRevX.11.021042 

69. M. Brotons-Gisbert et al., Moiré-Trapped Interlayer Trions in a Charge-Tunable WSe2/MoSe2 Heterobilayer. Phys. Rev. X 11, 031033 (2021). doi: 10.1103/PhysRevX.11.031033 

70. M. Turunen et al., Quantum photonics with layered 2D materials. Nat. Rev. Phys. 4, 219–236 (2022). doi: 10.1038/s42254-021-00408-0 

   118. A. J. Campbell et al., Exciton-polarons in the presence of strongly correlated electronic states in a MoSe2/WSe2 moiré superlattice. npj 2D Mater. Appl. 6, 79 (2022). doi: 10.1038/ s41699-022-00358-w 

94. S. Brem et al., Hybridized intervalley moiré excitons and flat bands in twisted WSe2 bilayers. Nanoscale 12, 11088–11094 (2020). doi: 10.1039/D0NR02160A; pmid: 32400821 

      119. J. Liu, X. Dai, Anomalous Hall effect, magneto-optical properties, and nonlinear optical properties of twisted graphene systems. npj Computat. Mater. 6, 57 (2020). doi: 10.3390/ma14010057 

   95. C. Zhang et al., Systematic study of electronic structure and band alignment of monolayer transition metal 

71. S. Zhao et al., Excitons in mesoscopically reconstructed moiré hetersotructures. arXiv:2202.11139 (2022). 

13 of 14 

Du et al., Science 379, eadg0014 (2023) 31 March 2023 

RESEARCH | REVIEW 







      148. Y.-H. Zhang, D. N. Sheng, A. Vishwanath, SU (4) Chiral Spin Liquid, Exciton Supersolid, and Electric Detection in Moiré Bilayers. Phys. Rev. Lett. 127, 247701 (2021). doi: 10.1103/ PhysRevLett.127.247701; pmid: 34951785 

   134. P. Seifert et al., Magic-Angle Bilayer Graphene Nanocalorimeters: Toward Broadband, Energy-Resolving Single Photon Detection. Nano Lett. 20, 3459–3464 (2020). doi: 10.1021/acs.nanolett.0c00373; pmid: 32315186 

120. X. Wang et al., Light-induced ferromagnetism in moiré superlattices. Nature 604, 468–473 (2022). doi: 10.1038/ s41586-022-04472-z; pmid: 35444320 

121. H. Yoo et al., Atomic and electronic reconstruction at the van der Waals interface in twisted bilayer graphene. Nat. Mater. 18, 448–453 (2019). doi: 10.1038/s41563-019-0346-z; pmid: 30988451 

      149. Z. Bi, L. Fu, Excitonic density wave and spin-valley superfluid in bilayer transition metal dichalcogenide. Nat. Commun. 12, 642 (2021). doi: 10.1038/s41467-020-20802-z; pmid: 33510138 

   135. S. S. Sunku et al., Hyperbolic enhancement of photocurrent patterns in minimally twisted bilayer graphene. Nat. Commun. 12, 1641 (2021). doi: 10.1038/s41467021-21792-2; pmid: 33712611 

122. V. V. Enaldiev, V. Zólyomi, C. Yelgel, S. J. Magorrian, V. I. Fal’ko, Stacking Domains and Dislocation Networks in Marginally Twisted Bilayers of Transition Metal Dichalcogenides. Phys. Rev. Lett. 124, 206101 (2020). doi: 10.1103/PhysRevLett.124.206101; pmid: 32501062 

   150. R. Xiong et al., Bosonic Mott insulator in WSe2/WS2 moiré superlattice. arXiv:2207.10764 [cond-mat.str-el] (2022). 

136. N. C. H. Hesp et al., Nano-imaging photoresponse in a moiré unit cell of minimally twisted bilayer graphene. Nat. Commun. 12, 1640 (2021). doi: 10.1038/s41467-021-21862-5; pmid: 33712606 

      151. Y. Zeng et al., Exciton density waves in Coulomb-coupled dual moiré lattices. Nat. Mater. 22, 175–179 (2023). doi: 10.1038/ s41563-022-01454-4; pmid: 36635591 

   137. X. Yan et al., Single-defect phonons imaged by electron microscopy. Nature 589, 65–69 (2021). doi: 10.1038/ s41586-020-03049-y; pmid: 33408374 

123. L. Jiang et al., Soliton-dependent plasmon reflection at bilayer graphene domain walls. Nat. Mater. 15, 840–844 (2016). doi: 10.1038/nmat4653; pmid: 27240109 

###### ACKNOWLEDGMENTS 

   138. N. P. Wilson et al., Interlayer electronic coupling on demand in a 2D magnetic semiconductor. Nat. Mater. 20, 1657–1662 (2021). doi: 10.1038/s41563-021-01070-8; pmid: 34312534 

124. J. Quan et al., Phonon renormalization in reconstructed MoS2 moiré superlattices. Nat. Mater. 20, 1100–1105 (2021). doi: 10.1038/s41563-021-00960-1; pmid: 33753933 

We acknowledge numerous colleagues with whom we have had the opportunity to work and gain knowledge in the constantly growing field of moiré photonics and optoelectronics. Z.S. also thanks J. Bai and Z. Ren for discussion and assistance during his current visiting professorship at the Northwestern University, China. Funding: The authors gratefully acknowledge the financial support from the National Science Foundation of China (NSFC) (grant nos. 12274447, 61888102, and 11834017), the National Key Research and Development Program (grant no. 2021YFA1202900), the Strategic Priority Research Program of the Chinese Academy of Sciences (grant no. XDB30000000), and the Key-Area Research and Development Program of Guangdong Province (grant no. 2020B0101340001), the Academy of Finland (314810, 333982, 336144, 333099, 336818, 352780, 352930, and 353364), the Academy of Finland Flagship Programme (320167, PREIN), ERC (834742), the EU H2020-MSCA-RISE-872049 (IPN-Bio), the European Union’s Horizon 2020 research and innovation program (965124, FEMTOCHIP), and the National Science Centre, Poland (grant no. 2018/31/B/ST3/02111). F.W. acknowledges the support from US Department of Energy, Office of Science, Office of Basic Energy Sciences, Materials Sciences and Engineering Division under contract no. DE-AC02-05-CH11231 (van der Waals heterostructure program KCFW16). Author contributions: L.D., G.Z, and Z.S. conceived the idea and led the writing. M.M., Z.H., and F.W. contributed substantially to the discussion of the content. All authors reviewed and edited the manuscript before submission. Competing interests: The authors declare no competing interests. License information: Copyright © 2023 the authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original US government works. https://www.sciencemag.org/about/ science-licenses-journal-article-reuse 

125. A. C. Gadelha et al., Localization of lattice dynamics in low-angle twisted bilayer graphene. Nature 590, 405–409 (2021). doi: 10.1038/s41586-021-03252-5; pmid: 33597759 

   139. Z. Sun et al., Giant nonreciprocal second-harmonic generation from antiferromagnetic bilayer CrI3. Nature 572, 497–501 (2019). doi: 10.1038/s41586-019-1445-3; pmid: 31367036 

126. B. Deng et al., Strong mid-infrared photoresponse in small-twist-angle bilayer graphene. Nat. Photonics 14, 549–553 (2020). doi: 10.1038/s41566-020-0644-7 

   140. Y. J. Bae et al., Exciton-coupled coherent magnons in a 2D semiconductor. Nature 609, 282–286 (2022). doi: 10.1038/ s41586-022-05024-1; pmid: 36071189 

127. J. Yang et al., Spectroscopy signatures of electron correlations in a trilayer graphene/hBN moiré superlattice. Science 375, 1295–1299 (2022). doi: 10.1126/science.abg3036; pmid: 35298267 

   141. B. Huang et al., Tuning inelastic light scattering via symmetry control in the two-dimensional magnet CrI3. Nat. Nanotechnol. 15, 212–216 (2020). doi: 10.1038/s41565-019-0598-4; pmid: 31907441 

128. G. Chen et al., Signatures of tunable superconductivity in a trilayer graphene moiré superlattice. Nature 572, 215–219 (2019). doi: 10.1038/s41586-019-1393-y pmid: 31316203 

   142. S. Zhao, R. Kitaura, P. Moon, M. Koshino, F. Wang, Interlayer Interactions in 1D Van der Waals Moiré Superlattices. Adv. Sci. (Weinh.) 9, e2103460 (2022). doi: 10.1002/ advs.202103460; pmid: 34841726 

129. Q. Ma, A. G. Grushin, K. S. Burch, Topology and geometry under the nonlinear electromagnetic spotlight. Nat. Mater. 20, 1601–1614 (2021). doi: 10.1038/s41563-021-00992-7; pmid: 34127824 

   143. P. Wang et al., Localization and delocalization of light in photonic moiré lattices. Nature 577, 42–46 (2020). doi: 10.1038/s41586-019-1851-6; pmid: 31853062 

130. M. Otteneder et al., Terahertz Photogalvanics in Twisted Bilayer Graphene Close to the Second Magic Angle. Nano Lett. 20, 7152–7158 (2020). doi: 10.1021/acs. nanolett.0c02474; pmid: 32915581 

   144. X.-R. Mao, Z.-K. Shao, H.-Y. Luan, S.-L. Wang, R.-M. Ma, Magic-angle lasers in nanostructured moiré superlattice. Nat. Nanotechnol. 16, 1099–1105 (2021). doi: 10.1038/ s41565-021-00956-7; pmid: 34400821 

131. P. He et al., Graphene moiré superlattices with giant quantum nonlinearity of chiral Bloch electrons. Nat. Nanotechnol. 17, 378–383 (2022). doi: 10.1038/s41565-021-01060-6; pmid: 35115723 

   145. Q. Fu et al., Optical soliton formation controlled by angle twisting in photonic moiré lattices. Nat. Photonics 14, 663–668 (2020). doi: 10.1038/s41566-020-0679-9 

132. M. Huang et al., Giant nonlinear Hall effect in twisted bilayer WSe2. Natl. Sci. Rev. 10.1093/nsr/nwac232 (2022). doi: 10.1093/nsr/nwac232 

   146. Y. Bai et al., Excitons in strain-induced one-dimensional moiré potentials at transition metal dichalcogenide heterojunctions. Nat. Mater. 19, 1068–1073 (2020). doi: 10.1038/s41563-020-0730-8; pmid: 32661380 

133. X. Lu et al., Superconductors, orbital magnets and correlated states in magic-angle bilayer graphene. Nature 574, 653–657 (2019). doi: 10.1038/s41586-019-1695-0; pmid: 31666722 

Submitted 28 November 2022; accepted 24 February 2023 10.1126/science.adg0014 

147. Q. Lin et al., A room-temperature moiré interlayer exciton laser. arXiv:2302.01266 (2023). 

14 of 14 

Du et al., Science 379, eadg0014 (2023) 31 March 2023 



##### **Moiré photonics and optoelectronics** 

Luojun Du, Maciej R. Molas, Zhiheng Huang, Guangyu Zhang, Feng Wang, and Zhipei Sun 

_Science_ **379** (6639), eadg0014.  DOI: 10.1126/science.adg0014 

###### **Patterning optoelectronics** 

Moiré patterns develop when two or more periodic lattices are overlaid over each other. These long-range patterns can also be seen in two-dimensional materials and give rise to rich physics within these quantum materials systems. Du _et al_ . reviewed recent developments in moiré-patterned two-dimensional materials with a focus on the photonic and optoelectronic aspects and how the properties can be controlled by engineering the stacking order and twist angle between the layers. The wealth of properties seen indicates that these systems may be a powerful platform to develop an exotic optoelectronic device technology. —ISO 

**View the article online** https://www.science.org/doi/10.1126/science.adg0014 **Permissions** https://www.science.org/help/reprints-and-permissions 

Use of this article is subject to the Terms of service 

_Science_ (ISSN 1095-9203) is published by the American Association for the Advancement of Science. 1200 New York Avenue NW, Washington, DC 20005. The title _Science_ is a registered trademark of AAAS. 

Copyright © 2023 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works 

