# Critical challenges in the development of electronics based on two-dimensional transition metal dichalcogenides

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Electronics |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 175 |
| 作者 | Yan Wang, Soumya Sarkar, Han Yan, Manish Chhowalla |
| DOI | 10.1038/s41928-024-01210-3 |
| 源文件 | 069_Wang_2024_Critical-challenges-in-the-development-of-electr.pdf |

---
# **Critical challenges in the development of electronics based on two-dimensional transition metal dichalcogenides** 

Yan Wang*, Soumya Sarkar, Han Yan, Manish Chhowalla* Department of Materials Science & Metallurgy, University of Cambridge, CB3 0FS, UK. 

Correspondence to: yw472@cam.ac.uk, <u>mc209@cam.ac.uk</u> 

**Abstract:** The development of high-performance electronic devices based on twodimensional (2D) transition metal dichalcogenide semiconductors has recently advanced from one-off proof of principle demonstrations to more reproducible integrated devices. It has, in particular, reached a point where the material quality — as well as the interfaces between the metal contacts, dielectrics and 2D semiconductors — must be optimized to increase device performance. Here we examine the key immediate challenges for the development of electronics based on 2D transition metal dichalcogenides, and identify doping, p-type contacts, and high- _k_ dielectrics as critical issues. We argue that these challenges stem from the high density of defects present in 2D transition metal dichalcogenides, and suggest that the community focus more on the growth of high-quality materials with a low concentration of defects. We also provide recommendations on identifying industry compatible dielectrics for these 2D devices. 

# **Introduction:** 

Electronics based on two-dimensional (2D) transition metal dichalcogenides (TMDs) is advancing rapidly<sup>1</sup> . Recent developments include field-effect transistors (FETs) based on monolayer tungsten diselenide (WSe2) with room temperature mobilities of more than 1000 cm<sup>2</sup> -V<sup>-1</sup> -s<sup>-1</sup> (ref.<sup>2,3</sup> ), n-type FETs based on monolayer molybdenum disulfide (MoS2) with contact resistance values close to the quantum limit<sup>4</sup> , and massive arrays of FETs for active pixel sensors<sup>5</sup> . 2D TMDs are also now firmly on the technology roadmaps of companies including the Taiwan Semiconductor Manufacturing Corporation (TSMC), Intel, Imec, and Samsung<sup>6</sup> . However, a number critical challenges still need to be addressed - and in an industry compatible way - before such devices can be of wider practical value. 

In this Perspective, we explore the challenges involved in the development of electronics based on 2D TMDs. We highlight three key issues: doping<sup>7,8</sup> , low 

1 

resistance contacts (especially p-type), and industry compatible high- _k_ dielectrics. We argue that these challenges stem from the fact that 2D TMDs are riddled with point defects (Fig. 1a) such as charged chalcogen vacancies and isovalent impurities<sup>2,9</sup> — something that the community has been reluctant to discuss openly in context of performance of electronic devices. The defects in 2D TMDs detrimentally affect device properties including on-state current, variation in threshold voltage, and mobility. For optics and photonics, the influence of point defects in 2D TMDs is less pronounced but for electronics, decreasing defect concentration is essential. For example, a photoluminescence quantum yield of close to 100 % can be achieved in 2D TMDs<sup>10,11</sup> but electrically driven luminescence yield is typically less than few percent due to scattering, recombination of carriers, and poor contacts<sup>12</sup> . 

Charged chalcogen vacancies in mechanically exfoliated or chemical vapour deposited 2D TMDs induce high carrier concentration (up to 10<sup>12</sup> per cm<sup>2</sup> ) (ref.<sup>13</sup> ). The large starting carrier concentration due to vacancies along with presence of neutral impurity atoms make it challenging to modulate the carrier concentration with substitutional doping. The inability to dope 2D TMDs also makes it difficult to make good contacts (both p- and n-type): that is, degenerately doped regions are used in silicon for n- and p-type contacts, but similar strategies cannot be used in 2D TMDs. The high chalcogen vacancy concentration also leads to stronger interactions with charges in the dielectric, which introduce interface states and unintentional doping from the substrate<sup>14–16</sup> . For example, p-type FETs with van der Waals (vdW) contacts can only be achieved by suppressing the contribution from the dielectric by passivating the substrate<sup>17–19</sup> . Unintentional doping from vacancies and dielectric also leads to large variation in threshold voltage of transistors. In addition, the defects increase scattering, which leads to low mobilities. For example, room-temperature mobilities of more than 1,000 cm<sup>2</sup> -V<sup>-1</sup> -s<sup>-1</sup> have been achieved in low vacancy WSe2 (ref.<sup>2,3</sup> ) — which is well above the theoretical upper limit of ~ 400 cm<sup>2</sup> -V<sup>-1</sup> -s<sup>-1</sup> (ref.<sup>20</sup> ) — by encapsulating monolayer TMD in hexagonal boron nitride. 

# **Wafer scale but defective** 

2D TMDs consist of a transition metal (such as Mo, W, or Nb) and two chalcogens (S, Se, or Te). The melting temperature of transition metals is substantially higher (> 2000 °C) than that of chalcogens (< 450 °C). Therefore, high temperature synthesis of bulk crystals by chemical vapour transport and single layers of TMDs by chemical vapour 

2 

deposition inevitably leads to chalcogen vacancies upon cooling from the growth temperature (typically > 650 °C)<sup>21</sup> . Other types of point defects, including transition metal vacancies and substitutional atoms, from the growth precursors can also be present<sup>2</sup> . Point defects can be easily observed in high-resolution scanning transmission electron microscopy (STEM) (Fig. 1b)<sup>22</sup> . 

While there are contradictory calculation results about the energy levels of the vacancies and whether they are charged<sup>23,24</sup> , there is general consensus that chalcogen vacancies result in in-gap defect states located close to the conduction band (Fig. 1c)<sup>23</sup> . This is validated by differential conductance (dI/dV) spectra of sulfur vacancies using scanning tunnelling spectroscopy (STS) in a scanning tunnelling microscopy (STM), which show in-gap peaks near the conduction band edge<sup>9,25,26</sup> . Stoichiometry analysis of bulk MoS2 indicates that the Mo:S ratio can range from 1:1.8 to 1:2.05 (ref.<sup>27</sup> ), as measured by high-resolution Rutherford backscattering spectrometry and X-ray photoemission spectroscopy (XPS). The large number of chalcogen vacancies give rise to a low energy shoulder in the XPS Mo peak due to undercoordinated Mo sites<sup>28</sup> . This shoulder has been shown to decrease when the defective sample is exposed to oxygen during XPS measurements<sup>29</sup> . 

Studies also show that the isovalent defects (density of around 10<sup>12</sup> cm<sup>–2</sup> ) such as oxygen passivated sulfur vacancies and impurity metal atoms are not charged<sup>9,30</sup> . Calculations and STS measurements suggest that oxygen can passivate in-gap states<sup>31–33</sup> . It has been shown that oxygen-incorporated MoS2 exhibits enhanced photoluminescence, higher work function, and improved contact resistance due to passivated in-gap states<sup>33</sup> . However, whether passivation of sulfur vacancies with oxygen can improve the channel mobility has yet to be confirmed. 

It is generally known that thermal<sup>22</sup> or metal organic chemical vapour deposition (MOCVD)<sup>34</sup> grown 2D TMDs contain substantial amounts of vacancies and other point defects. Despite this, synthesis papers routinely claim “high quality” and “wafer scale” 2D TMDs. While large scale growth at low temperature is essential for complementary metal oxide semiconductor (CMOS) processing, the quality of the materials will ultimately determine their value for electronic devices. Quality of 2D TMDs is often assessed by measuring the mobility of FETs. Typically, mobility values achieved on mechanically exfoliated, thermal and MOCVD samples can range from 10 – 200 cm<sup>2</sup> - V<sup>-1</sup> -s<sup>-1</sup> (Fig. 1d) and these are taken as good quality materials. We now know that 

3 

mobilities are limited by scattering and decreasing charged and isovalent defect densities below 10<sup>10</sup> cm<sup>-2</sup> and 10<sup>11</sup> cm<sup>–2</sup> (Fig. 1e), respectively, using two-step flux method can lead to room temperature mobilities of > 1000 cm<sup>2</sup> -V<sup>-1</sup> -s<sup>-1</sup> and low temperature values of ~50,000 cm<sup>2</sup> -V<sup>-1</sup> -s<sup>-1</sup> (Fig. 1d)<sup>2,3,35</sup> . Thus, the focus should be on growth of 2D TMDs with low defect concentration and the quality of the grown materials should be determined by the amount of charged vacancies and isovalent substitution defects. 

While the growth by MOCVD continues to improve, defects of up to 10<sup>12</sup> cm<sup>-2</sup> remain along with a sizeable fraction of grain boundaries<sup>36</sup> . Also, most MOCVD growth of 2D TMDs involves the use of salts (such as NaCl) as growth facilitators – especially for low temperature growth<sup>37</sup> . The growth facilitators can be incorporated into the lattice and are not compatible with CMOS fabrication processes. It is therefore important to clearly specify the use of such additives and more importantly to eliminate them altogether. A promising direction on growth is the work on highly oriented epitaxial growth on sapphire for large crystal 2D TMDs over macroscopic areas<sup>38,39</sup> . Understanding how these materials nucleate and grow will provide valuable insight into growth of highly oriented and large grain 2D TMDs. This, along with methods to passivate chalcogen vacancies and minimising impurities will be crucial for realising high quality materials. 

Strategies similar to the two-flux method in which crystal growth occurs in excess chalcogen atmosphere to minimise vacancies should be adopted for wafer scale (MO)CVD approaches. While modest success has been achieved towards chalcogen vacancy healing in monolayers<sup>40</sup> , high-quality materials with low defect concentrations remain elusive. The low vapour pressure of sulfur makes it difficult to grow sulphide 2D TMDs using this approach, however. 

It is challenging to quantify atomic defects over wafer scale samples. Scanning tunnelling microscope (STM) and STEM analysis have been used but they probe small areas. The vacancy concentration obtained by STM (10<sup>10</sup> - 10<sup>11</sup> cm<sup>-2</sup> ) is generally lower than that measured by STEM (10<sup>12</sup> - 10<sup>13</sup> cm<sup>-2</sup> ). Progress in conductive atomic force microscopy (CAFM) provides pathway for quantitatively characterising defects over large areas<sup>41</sup> . Recent work on dilute substitutional doping and their identification 

4 

using CAFM is promising for realizing doped 2D TMDs if defects and the associated carrier concentration can be reduced to ~ 10<sup>10</sup> cm<sup>-2</sup> in wafer scale samples<sup>42</sup> . Xu _et al_ also demonstrated that CAFM and STM could image identical defects, both qualitatively and quantitatively (Fig. 1f)<sup>43</sup> . 

CVD grown 2D TMDs contain significant amounts of chalcogen vacancies and other defects. We therefore recommend that studies that focus more on improving quality of grown materials and not just on wafer scale growth or exotic heterostructures will be more valuable to the community. Authors should report atomic defect densities for new growth processes. High quality TMDs with much lower or passivated vacancies are required for doping. A focus on developing methods for controllable doping of 2D TMDs with initial free carrier concentration of < 10<sup>10</sup> cm<sup>-2</sup> will be useful towards developing doping strategies. 

# **Doping 2D TMD semiconductors** 

Doping 2D TMDs with foreign atoms such as Niobium or Rhenium<sup>44,45</sup> has to be done during growth. Post growth implantation of dopants will destroy the 2D TMD structure. In addition, incorporation of substitutional dopants with different concentrations for the channel and contacts regions during growth will be challenging. Doping via surface charge transfer could be another approach. Over the past few years, it has been demonstrated that potassium (K) and benzyl viologen (BV) introduce electron doping on TMDs while nitrogen dioxide (NO2), chloroauric acid (HAuCl4) and ruthenium chloride (RuCl3) cause hole doping effect on TMDs<sup>3,46–49</sup> . However, those dopants are either highly chemical reactive or have low thermal stability. 

Another promising way of doping 2D TMDs is through localized electrostatic dipole doping. Recent work has shown that sub-stoichiometric oxides such as SiOx, AlOx, TaOx, and HfOx on MoS2 (ref.<sup>50–52</sup> ) can achieve electron doping of up to 2 × 10<sup>13</sup> cm<sup>-2</sup> . Native oxide of WSe2 have been demonstrated to hole dope WSe2 FETs<sup>53</sup> . However, the mechanism and stability of this type of doping is not well understood. It could be due to the electrostatic dipole formed at oxide surface or hybridization between the oxide and TMDs. Localized electrostatic doping can tune of threshold voltage of FETs. For example, HfO2 dielectric with different La or Al interface dipoles can shift the threshold voltage of silicon nanosheet FETs over 0.6 V<sup>54</sup> . SiNx/Al2O3 interface dipoles 

5 

with and without Al2O3 have also been demonstrated to change the polarity of carbon nanotube FETs from N-type to P-type<sup>55</sup> . These studies have yet to be applied on 2D TMDs. 

We recommend that in addition to measuring FET devices, complementary methods such as Raman and XPS that are better for accurately assessing the doping level should be used. For example, A1g mode is MoS2 is sensitive to the carrier concentration due to strong electron-phonon coupling<sup>56</sup> . The Mo 3 _d_ peak position in XPS measures core level to Fermi level that reflects electron/hole doping in MoS2 (ref. 57). 

Degenerate doping of TMDs for contacts is urgently needed, especially p-type doping. Insights into how dielectrics contribute to doping of TMDs are also needed as this interface is critical in the FET device. Chemical and thermal stability of the doping strategy should also be considered. 

# **2D TMD semiconductor/metal contacts** 

It is now widely understood that deposition of metals on top of 2D TMDs leads to damage<sup>58</sup> . Recent developments in clean vdW contacts using indium then bismuth and antimony on 2D TMDs have improved the on state currents of n-type FETs and decreased the contact resistance close to the quantum limit (Fig. 2a,b,c)<sup>4,58,59</sup> . N-type contacts are facilitated by the excess of electrons from defects in the materials. Thus, while these development in n-type contacts are important, they can be classified as low hanging fruit. P-type contacts on 2D TMDs are particularly challenging because they require high work function metals with high melting temperatures. The evaporation of such metals requires high energy, which leads to sublimated atoms with high kinetic energy that is transferred to 2D TMDs upon deposition – leading to defects at the metal/2D TMD interface and pinning of the Fermi level. Our recent work<sup>19</sup> on using gentle deposition of Pt or Pd vdW contacts onto 2D TMDs provides a pathway for realizing high performance p-type FETs (Figure 2d). The resistance for these contacts remains high (as indicated in Fig. 2e) due to low work function of the metals when in contact with WSe2. Studies show that high hole current can be achieved by growing high work function metallic VSe2 as contacts for WSe2 FETs<sup>60,61</sup> . NbS2 and TiS2 as well as semimetal Co3Sn2S2 are predicted to have high work 

6 

functions and can be used as hole injection contacts for WSe2 FETs<sup>62</sup> . In addition to the high work function van der Waals contacts, hole doping of 2D TMDs is required to achieve high performance p-type FETs. The suppression of electron concentration through reduction of point defects is also critical for achieving p-type FETs. 

It should be noted that most of the academic work on contacts is focused on top contacts while practical implementation of 2D TMDs into devices will most likely utilise edge contacts<sup>63</sup> . However, edge contacts are difficult to characterise and therefore top contacts can provide fundamental understanding that can be applied for making edge contacts. In both top and edge contacts, degenerately doped regions will be essential for achieving p- and n-type FETs. 

High quality ferromagnetic (FM) contacts that can efficiently inject and collect spins are needed for spintronic memories based on 2D TMDs<sup>64</sup> . The challenge with FM metals as contacts is that they have high chemical reactivity and therefore readily react with the 2D TMDs – causing spin scattering and loss at the FM/TMD interface<sup>65</sup> . The realisation of vdW contacts on 2D TMDs could enable spin based devices<sup>64,66</sup> . 

In summary, thin metal film deposition on TMDs needs to be further studied and strategies for depositing high work function metal contacts on 2D TMDs without causing damage are required. Degenerately hole doped 2D TMDs with clean van der Waals contacts to achieve p-type contacts with resistances of < 100 Ω· µm are needed. 

# **2D TMD semiconductor/dielectric interface** 

The dielectric/2D TMD interface has been less studied. However, the dielectric is critically important for devices. The main reason silicon was selected over other semiconductors for modern electronics is because it forms the ideal semiconductor/dielectric (Si/SiO2) interface. The chemical inertness of 2D TMDs makes it challenging to nucleate and uniformly grow high _k_ dielectrics. It is generally assumed that the dielectric on which the 2D TMDs are grown or transferred is chemically and electronically inert. However, studies have reported different trion/exciton ratios in photoluminescence of 2D TMDs placed on different dielectric 

7 

substrates<sup>67</sup> . In FETs, p-type operation requires using dielectric substrates that suppress electron doping<sup>19</sup> . These results suggest that the semiconductor/dielectric interface is not passive and can strongly influence the electronic properties. Dielectrics grown by atomic layer deposition (ALD) can contain charged impurities or oxygen deficiencies that can lead to fixed positive charges that create dipoles that can extend into the 2D TMDs<sup>68</sup> (Fig. 3a and 3b) – influencing the metal/semiconductor junction and Schottky barrier height associated with it and activating dopants (from point defects) in the material. This leads to further increase in the carrier (electrons in the case of MoS2) concentration. Strategies to suppress dielectric doping include using PMMA, self-assembled monolayers, or hBN as inert layers<sup>69</sup> . These materials however are not suitable dielectrics for CMOS processes and therefore insulating layers that do not perturb the electronic properties of 2D TMDs are required. 

In the case of 2D TMDs, the surface states of dielectrics become important because unlike on Si, there is no chemical interaction between the dielectric and semiconductor. That is, for 2D TMDs on different dielectrics, the surface states of dielectrics remain unpassivated, which can induce dipoles and electrostatic doping. The development of high _k_ dielectrics for 2D TMD FETs should consider the following key requirements: 

First, the _k_ value of dielectrics should be high enough for scaling. hBN is widely used by the community because it forms clean van der Waals interface with 2D TMDs. However, the low dielectric constant of hBN means that ultra-thin (1.3 nm) layer is required for achieving an equivalent oxide thickness (EOT) of 1 nm. Calculations and experiments show that even with ideal defect-free single crystal hBN, the leakage current is too high for practical FETs<sup>70</sup> . 

Second, inert, stable, and amorphous dielectrics are preferred. The dielectric must be thermodynamically and mechanically stable as well as being chemically inert. For example, while HfO2 and ZrO2 possess similar dielectric attributes, ZrO2 forms ZrSi making it unsuitable for silicon electronics<sup>71</sup> . In the case of 2D TMDs, HfO2 may be less suitable because calculations indicate that Hf-terminated HfO2 surface and MoS2 readily form Hf-S bonds (Fig. 3a)<sup>72</sup> . The interfacial interactions give rise to hysteresis and large subthreshold swing (SS) in the transfer characteristics of FETs (Fig. 3c). Decoupling interactions between 2D TMD semiconductor and oxide dielectric by 

8 

introducing a vdW gap allows FETs with low hysteresis and low SS as illustrated in Fig. 3d-f (ref.<sup>14</sup> ). 

Third, the band offset between the dielectrics and 2D TMDs must be > 1 eV to prevent carrier injection. Dielectrics with band gaps of < 5 eV such as SrTiO3 (band gap ~ 3.2 eV) therefore may not be ideal for 2D TMDs. The band offset at the semiconductor/dielectric interface is affected by dipoles formed by charge transfer (Fig. 3b)<sup>73</sup> . Thus, charge transfer or chemical interaction should be avoided to prevent the band realignment. 

Lastly, low interface defect/trap states should be realized to achieve low subthreshold swing. Defects at the interface arise from chalcogen vacancies in 2D TMDs, oxygen vacancies in the oxide dielectric, impurities, and interface reactions<sup>74</sup> . These defects lead to large threshold voltage shifts, low mobility, large subthreshold swing, large hysteresis in the transfer characteristics (Fig. 3c), and instability in the devices. 

Single-crystal dielectrics such as CaF2, SrTiO3 and Al2O3 that have low defect states exhibit low subthreshold swing for 2D TMD FETs<sup>75–77</sup> . Although crystalline dielectrics typically have higher dielectric constant and lower defect states than their amorphous counterparts, amorphous dielectrics are more uniform and exhibit better thermal and mechanical stability. Furthermore, the low defect interface with amorphous dielectric can be achieved to create a sharp van der Waals interface<sup>14,78</sup> . A bonus of vdW interface between 2D TMD semiconductor and dielectric is that the presence of vdW gap reduces fringing induced barrier lowering, which allows high _k_ dielectric to be used to achieve low subthreshold swing FETs<sup>77</sup> . 

For practical electronic devices, top gated FETs are required. This is fundamentally challenging because 2D TMDs are chemically inert and therefore growth of uniform and continuous dielectric layer on top is challenging<sup>79</sup> . Further, since 2D TMDs are three atoms thick, nucleation of the oxide layer at defects leads to rapid deterioration of the electronic properties of the semiconductor. Strategies using molecules as buffer layers between the 2D TMDs and oxide dielectrics have been used to grow uniform layers<sup>79</sup> . Recent work has shown that it is possible to grow antimony trioxide as a buffer layer on 2D TMDs to allow integration of high- _k_ dielectrics through ALD growth<sup>80</sup> . 

9 

Here we propose that the deposition of vdW contacted thin metal layers on top of 2D TMDs and preferentially oxidising them to form oxide dielectrics could be an interesting way to overcome the nucleation and growth challenges of high _k_ dielectrics on top of 2D TMDs. 

A chemically inert and mechanically robust CMOS compatible dielectric with high _k_ should be developed. The semiconductor/dielectric interface defect density should be reduced to lower than 10<sup>10</sup> cm<sup>-2</sup> eV<sup>-1</sup> to achieve low subthreshold swing and no hysteresis in the transfer curve. Strategies to develop n-type FETs with small positive threshold voltage and p-type FETs with small negative threshold voltage are needed. 

# **Outlook:** 

The central challenge in the development of electronics based on 2D TMDs lies in achieving low-defect wafer-scale synthesis, which will be crucial for creating intrinsic channels and potential doping strategies. The development of clean van der Waals interfaces between metals/semiconductors and semiconductors/dielectrics is also essential for achieving high-performance FETs. In particular, a CMOS compatible high- _k_ dielectric that does not detrimentally influence 2D TMD channels is required. Furthermore, it is essential that any breakthrough in device performance now also considers industrial compatibility, scalability, and stability, to ensure that innovations are practical, reproducible and viable for widespread adoption. 

**Fig. 1: Defects in 2D TMDs. a** , Schematic of monolayer TMD with different point defects. **b** , High-angle annular dark-field scanning transmission electron microscopy image of a single layer MoS2 showing different types of vacancies<sup>22</sup> [single sulfur vacancy (yellow circles), double sulfur vacancy (orange circles), and less observed single molybdenum vacancy (green circle)]. **c** , Local density of states of monolayer MoS2 showing in-gap states from sulfur vacancy (VS) near the conduction band edge<sup>33</sup> . The VS site is highlighted by the dashed circle shown in the inset. **d** , Comparison of mobility values versus temperature of WSe2 fabricated using different approaches<sup>2,18,19,60,83–85</sup> . Most values are in the range of 10 – 200 cm<sup>2</sup> -V<sup>-1</sup> -s<sup>-1</sup> . Room 

10 

temperature mobility of ~ 1000 cm<sup>2</sup> -V<sup>-1</sup> -s<sup>-1</sup> and low temperature value of ~50,000 cm<sup>2</sup> - V<sup>-1</sup> -s<sup>-1</sup> are achieved in low defect density WSe2 (ref.<sup>2</sup> ). **e** , Topographic STM images of single-crystal WSe2 grown by CVT<sup>35</sup> (left) and two-step flux method<sup>2</sup> (right). Defects in the CVT sample (dark spots) are readily visible while no defect features are apparent in the two-step flux sample image. **f** , CAFM (left) and STM (right) images of a flake of MoSe2 at the same location<sup>43</sup> . EC, conduction band energy; EV, valence band energy; LDOS, Local density of states. 

**Fig. 2: Summary of results on electrical contacts for 2D TMDs. a-c** , Transfer characteristics of 2D MoS2 channel FETs with indium, bismuth, and antimony source and drain contacts. The results show ON state currents of FETs in excess of 10 Am<sup>-1</sup> due to low contact resistance. Inset in **a** and **c** are cross-sectional STEM images of metal-MoS2 interface. Inset in **b** is DOS of Bi and MoS2 interface showing MoS2 is degenerately doped by the metal contact. **d** , Transfer curve of monolayer WSe2 channel FET with van der Waals Pt contact showing pure p-type characteristics. Inset: cross-sectional STEM image showing clean interface between Pt and monolayer WSe2. **e** , Contact resistance versus carrier concentration for MoS2 (solid symbols) and WSe2 (empty symbols) with different contact metals and varying size of the van der Waals gap. The solid purple line (d = 0 Å) represents the quantum limit for contact resistance and it can be seen that mature semiconductors technologies approach this limit. The dashed lines represent van der Waals gap values. However, the state-of-art hole contact resistance of WSe2 is still one order higher than practical requirements. The contact resistance values are reproduced from refs<sup>4,18,19,49,58,59,86–90</sup> . hBN, hexagonal boron nitride; UHV, ultra-high vacuum. Panels adapted from refs<sup>4,19,58,59</sup> . 

**Fig. 3. Oxide Dielectrics for 2D TMDs. a** , Schematic of a non-ideal 2D TMD semiconductor/dielectric interface. An amorphous oxide dielectric with defects is represented. The presence of defects leads to following effects: (i) electrons are easily scattered at the interface; (ii) interface dipoles form due to charge impurities within the dielectric; (iii) charge transfer between the dielectric and semiconductor; and (iv) hybridization between non-passivated dielectric surface and the 2D TMDs. **b** , Energy band diagram of a 2D TMD semiconductor and dielectric interface under thermal equilibrium. Oxide insulators such as HfO2 or SiO2 have acceptor traps close to the 

11 

conduction band and donor type traps close to the valence band<sup>81,82</sup> . The acceptor type traps are neutral when empty and negatively charged when filled. The donor type traps are neutral when filled and positively charged when empty. When the 2D TMD semiconductor is placed on the dielectric, interface states created by any interactions between the oxide and 2D TMDs can trap and de-trap carriers of the semiconductors at the interface, causing hysteresis in the transfer characteristics, threshold voltage shifts, and high subthreshold swing values in the device. **c** , Typical transfer curve of n-type FET with non-ideal interfaces. The large hysteresis, large threshold voltage shift, and subthreshold swing value much higher than 60 mV/dec are caused by interface defects. The high current at the y-axis intercept indicates substantial electron doping from defects and dielectric. The presence of defects leads to low FET mobility as indicated by the small slope at high gate voltage region (the red dashed circle in linear transfer curve is typically used to extract the mobility). **d** , Schematic of an ideal 2D TMD semiconductor/dielectric interface with minimal defects and interactions due to the presence of a van der Waals gap between the two materials. **e** , Energy band diagram of a semiconductor/dielectric interface under thermal equilibrium without interfacial interactions. **f** , Ideal transfer characteristics of a n-type FET showing high ON current, high mobility, no hysteresis, low subthreshold swing, and small positive threshold voltage. χs , electron affinity of the semiconductor; χi , electron affinity of the dielectric; EC, conduction band energy of the semiconductor; EF, energy of the Fermi level; EV, valence band energy of the semiconductor; q, charge; SS, subthreshold swing; Vth, subthreshold voltage. 

References: 

1. 2D Transition Metal Dichalcogenides 2023. https://www.rsc.org/events/detail/76461/2d-transition-metal-dichalcogenides2023. 

2. Liu, S. _et al._ Two-Step Flux Synthesis of Ultrapure Transition-Metal Dichalcogenides. _ACS Nano_ **25** , 31 (2023). 

3. Pack, J. _et al._ Charge-transfer Contact to a High-Mobility Monolayer Semiconductor. arXiv:2310.19782 (2023). 

4. Li, W. _et al._ Approaching the quantum limit in two-dimensional semiconductor contacts. _Nature._ **613** , 274–279 (2023). 

5. Dodda, A. _et al._ Active pixel sensor matrix based on monolayer MoS2 phototransistor array. _Nat. Mater._ **21** , 1379–1387 (2022). 

6. Lanza, M. & Radu, I. Electronic Circuits made of 2D Materials. _Adv. Mater._ **34** , 

12 

- 2207843 (2022). 

- 7. Hung, T. Y. T. _et al._ pMOSFET with CVD-grown 2D semiconductor channel enabled by ultra-thin and fab-compatible spacer doping. _Tech. Dig. - Int. Electron Devices Meet. IEDM_ **2022** - **December** , 731–734 (2022). 

8. Sutar, S. _et al._ Spin-on-diffussants for doping in transition metal dichalcogenide semiconductors. _Appl. Phys. Lett._ **114** , 212102 (2019). 

9. Wan, Y. _et al._ Low-defect-density WS2 by hydroxide vapor phase deposition. _Nat. Commun._ **13** , 1–8 (2022). 

10. Lien, D. H. _et al._ Electrical suppression of all nonradiative recombination pathways in monolayer semiconductors. _Science_ **364** , 468–471 (2019). 

11. Amani, M. _et al._ Near-unity photoluminescence quantum yield in MoS2. _Science_ **350** , 1065–1068 (2015). 

12. Lien, D. H. _et al._ Large-area and bright pulsed electroluminescence in monolayer semiconductors. _Nat. Commun._ **9** , 1–7 (2018). 

13. Cui, X. _et al._ Multi-terminal transport measurements of MoS2 using a van der Waals heterostructure device platform. _Nat. Nanotechnol._ **10** , 534–540 (2015). 

14. Luo, P. _et al._ Molybdenum disulfide transistors with enlarged van der Waals gaps at their dielectric interface via oxygen accumulation. _Nat. Electron._ **5** , 849– 858 (2022). 

15. Utama, M. I. B. _et al._ A dielectric-defined lateral heterojunction in a monolayer semiconductor. _Nat. Electron._ **2** , 60–65 (2019). 

16. Ho, P.-H. _et al._ High-Performance Two-Dimensional Electronics with a Noncontact Remote Doping Method. _ACS Nano_ **17** , 12208–12215 (2023). 

17. Liu, Y. _et al._ Approaching the Schottky–Mott limit in van der Waals metal– semiconductor junctions. _Nature_ **557** , 696–700 (2018). 

18. Jung, Y. _et al._ Transferred via contacts as a platform for ideal two-dimensional transistors. _Nat. Electron._ **2** , 187–194 (2019). 

19. Wang, Y. _et al._ P-type electrical contacts for 2D transition-metal dichalcogenides. _Nature_ **610** , 61–66 (2022). 

20. Luisier, M. _et al._ First-principles simulations of 2-D semiconductor devices: Mobility, I-V characteristics, and contact resistance. _Tech. Dig. - Int. Electron Devices Meet. IEDM_ 5.4.1-5.4.4 (2017) 

21. Sun, L. _et al._ Chemical vapour deposition. _Nat. Rev. Methods Prim._ **1** , 1–20 (2021). 

22. Yang, J. _et al._ Single Atomic Vacancy Catalysis. _ACS Nano_ **13** , 9958–9964 (2019). 

23. Komsa, H. P. & Krasheninnikov, A. V. Native defects in bulk and monolayer MoS2 from first principles. _Phys. Rev. B - Condens. Matter Mater. Phys._ **91** , 125304 (2015). 

24. Salehi, S. & Saffarzadeh, A. Atomic defect states in monolayers of MoS2 and WS2. _Surf. Sci._ **651** , 215–221 (2016). 

25. Liu, M. _et al._ Temperature-Triggered Sulfur Vacancy Evolution in Monolayer MoS2/Graphene Heterostructures. _Small_ **13** , 1602967 (2017). 

26. Schuler, B. _et al._ How Substitutional Point Defects in Two-Dimensional WS2 Induce Charge Localization, Spin-Orbit Splitting, and Strain. _ACS Nano_ **13** , 10520–10534 (2019). 

27. Addou, R. _et al._ Impurities and Electronic Property Variations of Natural MoS2 Crystal Surfaces. _ACS Nano_ **9** , 9124–9133 (2015). 

28. Zhu, Y. _et al._ Room-Temperature Photoluminescence Mediated by Sulfur Vacancies in 2D Molybdenum Disulfide. _ACS Nano_ **17** , 13545–13553 (2023). 

13 

29. Grünleitner, T. _et al._ Real-Time Investigation of Sulfur Vacancy Generation and Passivation in Monolayer Molybdenum Disulfide via in situ X-ray Photoelectron Spectromicroscopy. _ACS Nano_ **16** , 20364–20375 (2022). 

30. Mitterreiter, E. _et al._ The role of chalcogen vacancies for atomic defect emission in MoS2. _Nat. Commun._ **12** , 1–8 (2021). 

31. Gogoi, P. K. _et al._ Oxygen Passivation Mediated Tunability of Trion and Excitons in MoS2. _Phys. Rev. Lett._ **119** , 077402 (2017). 

32. Barja, S. _et al._ Identifying substitutional oxygen as a prolific point defect in monolayer transition metal dichalcogenides. _Nat. Commun._ **10** , 1–8 (2019). 

33. Shen, P. C. _et al._ Healing of donor defect states in monolayer molybdenum disulfide using oxygen-incorporated chemical vapour deposition. _Nat. Electron._ **5** , 28–36 (2021). 

34. Kang, K. _et al._ High-mobility three-atom-thick semiconducting films with waferscale homogeneity. _Nature_ **520** , 656–660 (2015). 

35. Edelberg, D. _et al._ Approaching the Intrinsic Limit in Transition Metal Diselenides via Point Defect Control. _Nano Lett._ **19** , 4371–4379 (2019). 

36. Fu, J. H. _et al._ Oriented lateral growth of two-dimensional materials on c-plane sapphire. _Nat. Nanotechnol._ **18** 1289–1294 (2023) 

37. Zhu, J. _et al._ Low-thermal-budget synthesis of monolayer molybdenum disulfide for silicon back-end-of-line integration on a 200 mm platform. _Nat. Nanotechnol._ **18** , 456–463 (2023). 

38. Zhu, H. _et al._ Step engineering for nucleation and domain orientation control in WSe2 epitaxy on c-plane sapphire. _Nat. Nanotechnol._ **18** , 1295–1302 (2023). 

39. Li, T. _et al._ Epitaxial growth of wafer-scale molybdenum disulfide semiconductor single crystals on sapphire. _Nat. Nanotechnol._ **16** , 1201–1207 (2021). 

40. Lin, Y. C. _et al._ Realizing Large-Scale, Electronic-Grade Two-Dimensional Semiconductors. _ACS Nano_ **12** , 965–975 (2018). 

41. Bampoulis, P., Sotthewes, K., Siekman, M. H. & Zandvliet, H. J. W. Local Conduction in MoxW1-xSe2: The Role of Stacking Faults, Defects, and Alloying. _ACS Appl. Mater. Interfaces_ **10** , 13218–13225 (2018). 

42. Vu, N. T. T. _et al._ Single Atomic Defect Conductivity for Selective Dilute Impurity Imaging in 2D Semiconductors. _ACS Nano,_ **16** , 15648–15655 (2023). 

43. Xu, K. _et al._ Validating the Use of Conductive Atomic Force Microscopy for Defect Quantification in 2D Materials. _ACS Nano_ **17** , 24743–24752 (2023). 

44. Zhang, K. _et al._ Tuning the Electronic and Photonic Properties of Monolayer MoS2 via In Situ Rhenium Substitutional Doping. _Adv. Funct. Mater._ **28** , 1706950 (2018). 

45. Suh, J. _et al._ Reconfiguring crystal and electronic structures of MoS2 by substitutional doping. _Nat. Commun._ **9** , 1–7 (2018). 

46. Ho, P. H. _et al._ High-Performance WSe2 Top-Gate Devices with Strong Spacer Doping. _Nano Lett._ **23** , 10236–10242 (2023). 

47. Fang, H. _et al._ Degenerate n-doping of few-layer transition metal dichalcogenides by potassium. _Nano Lett._ **13** , 1991–1995 (2013). 

48. Kiriya, D., Tosun, M., Zhao, P., Kang, J. S. & Javey, A. Air-stable surface charge transfer doping of MoS2 by benzyl viologen. _J. Am. Chem. Soc._ **136** , 7853–7856 (2014). 

49. Chiang, C. C., Lan, H. Y., Pang, C. S., Appenzeller, J. & Chen, Z. Air-Stable P- Doping in Record High-Performance Monolayer WSe2 Devices. _IEEE Electron Device Lett._ **43** , 319–322 (2022). 

50. Ho, P. H. _et al._ High-Performance Two-Dimensional Electronics with a 

14 

- Noncontact Remote Doping Method. _ACS Nano_ **17** , 12208–12215 (2023). 

- 51. McClellan, C. J., Yalon, E., Smithe, K. K. H., Suryavanshi, S. V. & Pop, E. High Current Density in Monolayer MoS2 Doped by AlOx. _ACS Nano_ **15** , 1587–1596 (2021). 

52. Lan, H. Y., Appenzeller, J. & Chen, Z. Dielectric Interface Engineering for HighPerformance Monolayer MoS2 Transistors via hBN Interfacial Layer and Ta Seeding. _Tech. Dig. - Int. Electron Devices Meet. IEDM_ **2022** - **December** , 771– 774 (2022). 

53. Kato, R. _et al._ p-Type Conversion of WS2 and WSe2 by Position-Selective Oxidation Doping and Its Application in Top Gate Transistors. _ACS Appl. Mater. Interfaces_ **15** , 26977–26984 (2023). 

54. Yao, J. _et al._ Record 7(N)+7(P) Multiple VTs Demonstration on GAA Si Nanosheet n/pFETs using WFM-Less Direct Interfacial La/Al-Dipole Technique. _Tech. Dig. - Int. Electron Devices Meet. IEDM_ **2022** - **December** , 3421–3424 (2022). 

55. Zhang, Z. _et al._ Complementary carbon nanotube metal–oxide–semiconductor field-effect transistors with localized solid-state extension doping. _Nat. Electron._ **6** , 999–1008 (2023). 

56. Zheng, X. _et al._ Utilizing complex oxide substrates to control carrier concentration in large-area monolayer MoS2 films, _Appl. Phys. Lett_ **118** , 47 (2021). 

57. Sutar, S. _et al._ Spin-on-diffussants for doping in transition metal dichalcogenide semiconductors, _Appl. Phys. Lett_ **114** , 44 (2019). 

58. Wang, Y. _et al._ Van der Waals contacts between three-dimensional metals and two-dimensional semiconductors. _Nature_ **568** , 70–74 (2019). 

59. Shen, P. C. _et al._ Ultralow contact resistance between semimetal and monolayer semiconductors. _Nature_ **593** , 211–217 (2021). 

60. Li, J. _et al._ General synthesis of two-dimensional van der Waals heterostructure arrays. _Nature_ **579** , 368–374 (2020). 

61. Wu, R. _et al._ Bilayer tungsten diselenide transistors with on-state currents exceeding 1.5 milliamperes per micrometre. _Nat. Electron._ **5** , 497–504 (2022). 

62. Yang, N. _et al._ Ab Initio Computational Screening and Performance Assessment of van der Waals and Semimetallic Contacts to Monolayer WSe2 P-Type FieldEffect Transistors. _IEEE Trans. Electron Devices_ **70** , 2090–2097 (2023). 

63. Hung, T. Y. T. _et al._ Pinning-free edge contact monolayer MoS2 FET. _Tech. Dig. - Int. Electron Devices Meet. IEDM_ **2020** - **December** , 3.3.1-3.3.4 (2020). 

64. Yang, H. _et al._ Two-dimensional materials prospects for non-volatile spintronic memories. _Nature_ **606** , 663–673 (2022). 

65. Walsh, L. A. _et al._ Interface Chemistry of Contact Metals and Ferromagnets on the Topological Insulator Bi2Se3. _J. Phys. Chem. C_ **121** , 23551–23563 (2017). 

66. Zhao, B. _et al._ A Room-Temperature Spin-Valve with van der Waals Ferromagnet Fe5GeTe2/Graphene Heterostructure. _Adv. Mater._ **35** , 2209113 (2023). 

67. Li, Y. _et al._ Photoluminescence of monolayer MoS2 on LaAlO3 and SrTiO3 substrates. _Nanoscale_ **6** , 15248–15254 (2014). 

68. Leonhardt, A. _et al._ Material-Selective Doping of 2D TMDC through AlxOy Encapsulation. _ACS Appl. Mater. Interfaces_ **11** , 42697–42707 (2019). 

69. Li, Y., Xu, C. Y., Hu, P. & Zhen, L. Carrier control of MoS2 nanoflakes by functional self-assembled monolayers. _ACS Nano_ **7** , 7795–7804 (2013). 

70. Knobloch, T. _et al._ The performance limits of hexagonal boron nitride as an 

15 

- insulator for scaled CMOS devices based on two-dimensional materials. _Nat. Electron._ **4** , 98–108 (2021). 

- 71. Copel, M., Gribelyuk, M. & Gusev, E. Structure and stability of ultrathin zirconium oxide layers on Si(001). _Appl. Phys. Lett._ **76** , 436–438 (2000). 

72. Yang, M. _et al._ Interfacial Interaction between HfO2 and MoS2: From Thin Films to Monolayer. _J. Phys. Chem. C_ **120** , 9804–9810 (2016). 

73. Robertson, J. & Wallace, R. M. High- _k_ materials and metal gates for CMOS applications. _Mater. Sci. Eng. R Reports_ **88** , 1–41 (2015). 

74. Rhodes, D., Chae, S. H., Ribeiro-Palau, R. & Hone, J. Disorder in van der Waals heterostructures of 2D materials. _Nat. Mater._ **18** , 541–549 (2019). 

75. Di, Z. _et al._ Single-crystalline metal oxides as dielectrics for top-gate twodimensional transistors. (2023) doi:10.21203/RS.3.RS-3366445/V1. 

76. Illarionov, Y. Y. _et al._ Ultrathin calcium fluoride insulators for two-dimensional field-effect transistors. _Nat. Electron._ **2** , 230–235 (2019). 

77. Huang, J. K. _et al._ High- _κ_ perovskite membranes as insulators for twodimensional transistors. _Nature_ **605** , 262–267 (2022). 

78. Wang, L. _et al._ A general one-step plug-and-probe approach to top-gated transistors for rapidly probing delicate electronic materials. _Nat. Nanotechnol._ **17** , 1206–1213 (2022). 

79. Li, W. _et al._ Uniform and ultrathin high- _κ_ gate dielectrics for two-dimensional electronic devices. _Nat. Electron._ **2** , 563–571 (2019). 

80. Xu, Y. _et al._ Scalable integration of hybrid high- _κ_ dielectric materials on twodimensional semiconductors. _Nat. Mater._ **22** , 1078–1084 (2023). 

81. White, M. H. & Cricchi, J. R. Characterization of Thin-Oxide MNOS Memory Transistors. _IEEE Trans. Electron Devices_ **19** , 1280–1288 (1972). 

82. Rzepa, G. _et al._ Comphy — A compact-physics framework for unified modeling of BTI. _Microelectron. Reliab._ **85** , 49–65 (2018). 

83. Wu, R. _et al._ van der Waals Epitaxial Growth of Atomically Thin 2D Metals on Dangling-Bond-Free WSe2 and WS2. _Adv. Funct. Mater._ **29** , 1806611 (2019). 

84. Cho, H. _et al._ Se-Vacancy Healing with Substitutional Oxygen in WSe2 for HighMobility p-Type Field-Effect Transistors. _ACS Nano_ **17** , 11279–11289 (2023). 

85. Yang, S., Lee, G. & Kim, J. Selective p-Doping of 2D WSe2 via UV/Ozone Treatments and Its Application in Field-Effect Transistors. _ACS Appl. Mater. Interfaces_ **13** , 955–961 (2021). 

86. English, C. D., Shine, G., Dorgan, V. E., Saraswat, K. C. & Pop, E. Improved contacts to MoS2 transistors by ultra-high vacuum metal deposition. _Nano Lett._ **16** , 3824–3830 (2016). 

87. Cui, X. _et al._ Lowerature Ohmic Contact to Monolayer MoS2 by van der Waals Bonded Co/h-BN Electrodes. _Nano Lett._ **17** , 4781–4786 (2017). 

88. Chou, A. S. _et al._ High On-State Current in Chemical Vapor Deposited Monolayer MoS2 nFETs with Sn Ohmic Contacts. _IEEE Electron Device Lett._ **42** , 272–275 (2021). 

89. Smithe, K. K. H., Suryavanshi, S. V., Muñoz Rojo, M., Tedjarati, A. D. & Pop, E. Low Variability in Synthetic Monolayer MoS2 Devices. _ACS Nano_ **11** , 8456–8463 (2017). 

90. Xie, J. _et al._ Low Resistance Ohmic Contact to P-type Monolayer WSe2. _Nano Lett._ **12** , 27 (2023). 

16 

# **Acknowledgements** 

<mark>M.C. and Y.W. received funding from the European Research Council (ERC) Advanced Grant under the European Union’s Horizon 2020 research and innovation programme (grant agreement GA 101019828-2D- LOTTO]), Leverhulme Trust (RPG2019-227), EPSRC (EP/ T026200/1, EP/T001038/1) and Royal Society Wolfson Merit Award (WRM\FT\180009) and Department of Science, Innovation and Technology and the Royal Academy of Engineering under the Chair in Emerging Technologies programme (CiET -2324-134).</mark> 

# **Contributions** 

<mark>Y.W. and M.C. wrote and edited the paper. S. S. and H. Y. contributed to the contact and dielectric studies. All authors commented on the final version of the manuscript.</mark> 

# **Competing interests** 

<mark>The authors declare no competing interests.</mark> 

17 

