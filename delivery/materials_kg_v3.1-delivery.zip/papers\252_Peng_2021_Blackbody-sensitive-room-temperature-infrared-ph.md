# Blackbody-sensitive room-temperature infrared photodetectors based on low-dimensional tellurium grown by chemical vapor deposition

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Science Advances |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 220 |
| 作者 | Meng Peng, Run-Zhang Xie, Zhen Wang, Peng Wang, Fang Wang, Haonan Ge, Yang Wang, Fang Zhong et al. |
| DOI | 10.1126/sciadv.abf7358 |
| 源文件 | 039_Peng_2021_Blackbody-sensitive-room-temperature-infrared-ph.pdf |

---
SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

**M A T E RIALS SCIENC E** 

# **Blackbody-sensitive room-temperature infrared photodetectors based on low-dimensional tellurium grown by chemical vapor deposition** 

**Meng Peng**<sup>**1,2†**</sup> **, Runzhang Xie**<sup>**1,3†**</sup> **, Zhen Wang**<sup>**1,3**</sup> ***, Peng Wang**<sup>**1**</sup> ***, Fang Wang**<sup>**1**</sup> ***, Haonan Ge**<sup>**1**</sup> **, Yang Wang**<sup>**1**</sup> **, Fang Zhong**<sup>**1**</sup> **, Peisong Wu**<sup>**1,3**</sup> **, Jiafu Ye**<sup>**1,3**</sup> **, Qing Li**<sup>**1,4**</sup> **, Lili Zhang**<sup>**1**</sup> **, Xun Ge**<sup>**1,3**</sup> **, Yan Ye**<sup>**5**</sup> **, Yuchen Lei**<sup>**6**</sup> **, Wei Jiang**<sup>**1,3**</sup> **, Zhigao Hu**<sup>**5**</sup> **, Feng Wu**<sup>**2**</sup> **, Xiaohao Zhou**<sup>**1**</sup> **, Jinshui Miao**<sup>**1**</sup> **, Jianlu Wang**<sup>**1**</sup> **, Hugen Yan**<sup>**6**</sup> **, Chongxin Shan**<sup>**7**</sup> **, Jiangnan Dai**<sup>**2**</sup> **, Changqing Chen**<sup>**2**</sup> **, Xiaoshuang Chen**<sup>**1**</sup> **, Wei Lu**<sup>**1**</sup> **, Weida Hu**<sup>**1,3,4**</sup> ***** 

Copyright © 2021 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works. Distributed under a Creative Commons Attribution NonCommercial License 4.0 (CC BY-NC). 

**Blackbody-sensitive room-temperature infrared detection is a notable development direction for future lowdimensional infrared photodetectors. However, because of the limitations of responsivity and spectral response range for low-dimensional narrow bandgap semiconductors, few low-dimensional infrared photodetectors exhibit blackbody sensitivity. Here, highly crystalline tellurium (Te) nanowires and two-dimensional nanosheets were synthesized by using chemical vapor deposition. The low-dimensional Te shows high hole mobility and broadband detection. The blackbody-sensitive infrared detection of Te devices was demonstrated. A high responsivity of 6650 A W**<sup>**−1**</sup> **(at 1550-nm laser) and the blackbody responsivity of 5.19 A W**<sup>**−1**</sup> **were achieved. Highresolution imaging based on Te photodetectors was successfully obtained. All the results suggest that the chemical vapor deposition–grown low-dimensional Te is one of the competitive candidates for sensitive focalplane-array infrared photodetectors at room temperature.** 

#### **INTRODUCTION** 

Blackbody response has been widely applied as one of the standard characterizations for infrared focal plane array detectors, which is an important parameter reflecting the sensitivity of infrared photodetectors and determines the corresponding practical applications ( _1_ ). Up to now, most of the available and high-performance infrared photodetectors with blackbody response are based on traditional III-V and II-VI materials such as InGaAs, InSb, and HgCdTe ( _2_ – _4_ ). However, high growth costs of molecule beam epitaxy, metal-organic chemical vapor deposition, and other epitaxial growth methods, as well as the strict cooling requirements, severely limit the wider application and promotion of these traditional infrared detectors. With the rise and gradual development of low-dimensional materials, narrow bandgap low-dimensional materials have exhibited extraordinary potential for the next-generation infrared photodetectors operating at room temperature ( _5_ – _8_ ). The unique out-of-plane van der Waals force of low-dimensional layered materials makes them free from the surface dangling bonds compared to traditional 

> 1State Key Laboratory of Infrared Physics, Shanghai Institute of Technical Physics Chinese Academy of Sciences, Shanghai 200083, China.<sup>2</sup> Wuhan National Laboratory for Optoelectronics, Huazhong University of Science and Technology, Wuhan 430074, China.<sup>3</sup> University of Chinese Academy of Sciences, Beijing 100049, China. 4Hangzhou Institute for Advanced Study, University of Chinese Academy of Sciences, Hangzhou 310024, China.<sup>5</sup> Technical Center for Multifunctional Magneto-Optical Spectroscopy (Shanghai), Department of Materials, School of Physics and Electronic Science, East China Normal University, Shanghai, 200241, China.<sup>6</sup> Department of Physics, State Key Laboratory of Surface Physics and Key Laboratory of Micro and Nano Photonic Structures (Ministry of Education), Fudan University, 200433 Shanghai, China.<sup>7</sup> Henan Key Laboratory of Diamond Optoelectronic Materials and Devices, School of Physics and Engineering, Zhengzhou University, Zhengzhou 450001, China. 

> *Corresponding author. Email: wdhu@mail.sitp.ac.cn (W.H.); wangzhen@mail.sitp. ac.cn (Z.W.); w_peng@mail.sitp.ac.cn (P.W.); fwang@mail.sitp.ac.cn (F.W.) †These authors contributed equally to this work. 

materials, which reduces the dark current of the devices from surface recombination ( _9_ ). On the other hand, because of the quantum confinement, the strong light-matter interaction of low-dimensional materials enables them to exhibit excellent photodetection ( _10_ ). Currently, the ultrahigh responsivity and detectivity of low-dimensional infrared detectors have been obtained under infrared laser illumination ( _11_ – _14_ ). However, in the practical applications of infrared photodetectors, blackbody source radiation is more similar to the actual irradiation of the detected object rather than the laser source. Blackbody sensitivity means that the low-dimensional system detectors could take an important step toward commercial applications. Up to now, only a few infrared photodetectors based on quantum dots, carbon tubes, and black phosphorus (BP) are reported to have a response to the blackbody radiation ( _9_ , _15_ – _18_ ). 

Black phosphorous infrared detectors have exhibited excellent performance, but the difficult large-area growth and poor stability impede the practical applications ( _16_ ). The strong exciton effect in the carbon tubes and the low mobility of the disordered carbon tube films strongly limit the performance of the carbon tube infrared detectors ( _19_ ). The poor crystallinity of the quantum dot film and its low mobility limit the response time and bandwidth of its infrared detector ( _17_ ). 

Here, we report numerous and high-quality low-dimensional Te synthesized by low-cost chemical vapor deposition (CVD), including nanosheets and nanowires. The morphology evolution and growth kinetics of low-dimensional Te during the growth process are elaborated by density function theory (DFT). Photodetectors based on Te nanosheets and nanowires show an excellent blackbody and polarization response. Our work provides a previously unknown avenue for high-performance blackbody-sensitive roomtemperature low- dimensional materials infrared photodetectors with an efficient and large-scale fabrication. 

Peng _et al_ ., _Sci. Adv._ 2021; **7** : eabf7358     16 April 2021 

**1 of 11** 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

#### **RESULTS AND DISCUSSION** 

### **Material characterizations** 

Figure 1 (A and B) shows the scanning electron microscopy (SEM) images of CVD-synthesized tellurium nanosheets and nanowires on the Si substrate, respectively. The insets in Fig. 1 (A and B) are high-magnification SEM images of Te nanosheets and nanowires, respectively. It is found that Te nanosheets exhibit regular shapes including rectangle, pentagon, and hexagon. The length and width of Te nanosheets exceed and reach up to 50 and 20 m, respectively. The diameter of Te nanowires is approximately 200 nm. Meanwhile, the transmission electron microscopy (TEM) characterization of Te nanosheets and nanowires are displayed in Fig. 1 (C and F). The size, smooth, and neat surface topography of the samples are observed, present in the insets of Fig. 1 (B and E). Figure 1 (B and E) shows the high-resolution TEM (HRTEM) images of Te nanosheet and nanowire, respectively. The corresponding selected-area electron diffraction (SAED) images are exhibited in Fig. 1 (D and F), respectively. The HRTEM and SAED demonstrate that both nanosheet and nanowire have high crystallinity. The interplanar spacing distances of both Te nanosheet and nanowire in HRTEM image are approximately 0.59 nm, which is consistent with the spacing distance of (001) lattice planes of hexagonal Te in previous work ( _20_ ). The corresponding SAED images show the distinctive and sharp 

diffraction of the Te nanosheets and nanowires, which further confirm the excellent single-crystalline of CVD-grown Te with the unique hexagonal structure and corresponding crystal planar spacing distance. The crystal phase of tellurium is confirmed by x-ray diffraction (XRD) in Fig. 1G. The characteristic and sharp peaks of as-grown Te indicate the good crystallinity of Te nanosheets and nanowires with the growth direction along the <100> axis. Figure 1H shows the schematic diagram of the Te crystal structure, where the covalently bonded atoms are arranged by uniaxial spiral connection, and these chains are connected into a hexagonal structure by Van der Waals force. This unique in-plane asymmetry chiral-chain structure also means that this material should be anisotropic. The atomic force microscopy (AFM) images and Raman spectrum without impurity peaks of Te nanosheets are shown in fig. S1, further exhibiting a good crystallinity of Te nanosheets. Moreover, angle-resolved polarized Raman spectroscopy was used to further study the anisotropy properties of Te nanosheets, as shown in fig. S1C. The absorption spectrum of Te nanosheets in Fig. 1I indicates that the absorption cutoff wavelength was approximately 0.35 eV (corresponding to 3.5-m wavelength). Overall, the narrow optical bandgap, significant anisotropy, and excellent crystallinity ensure that infrared photodetector devices based on low-dimensional Te could exhibit excellent optoelectronic performance. 



<!-- Start of picture text -->
A B C<br>Nanosheet<br>2 µm<br>20 µm<br>D E F<br>Nanowire<br>10 µm 500 nm<br>G H I<br>101 Te 1.0<br>102 0.8<br>100 110 200 0.6<br>JCPDS#36-1452 0.4<br>y 0.2<br>z<br>0.0<br>10 20 30 40 50 60 70 0.83 0.62 0.50 0.41 0.35 0.31<br>2θ (°) Photon energy (eV)<br>x<br>y<br>Intensity (a.u.) Absorption intensity (a.u.)<br><!-- End of picture text -->

**Fig. 1. Morphological and material characterizations of low-dimensional Te.** ( **A** and **D** ) SEM images of Te nanosheets and nanowires. Insets are corresponding high-magnification SEM images. ( **B** and **E** ) HRTEM of Te nanosheets and nanowires. Insets are corresponding low-magnification TEM images. ( **C** and **F** ) Corresponding SAED images of Te nanosheets and nanowires. Interplanar spacings of 0.59, 022, and 0.38 nm are the (001), (101), and (100) lattice planes, respectively. ( **G** ) XRD of CVDgrown Te, which is in agreement with the standard powder diffraction file (PDF) card (JCPDS#36-1452). The unmarked peak around 30° is the main peak of TeO3 corresponding to the PDF card (JCPDS#22-0911). ( **H** ) Schematic illustration of Te crystal structure. ( **I** ) Absorption spectrum of Te nanosheet. Insets are the corresponding optical microscopy image of Te nanosheet. a.u., arbitrary units. 

Peng _et al_ ., _Sci. Adv._ 2021; **7** : eabf7358     16 April 2021 

**2 of 11** 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

### **Growth mechanism of low-dimensional Te** 

It is very important to understand the growth mechanism of Te nanosheets and nanowires, which have been grown in different regions on the same silicon substrate. The schematic of low-dimensional Te grown by the CVD method is shown in Fig. 2A. SnTe2 was used as the source to fabricate low-dimensional Te. As an intermetallic compound synthesized by powder metallurgy ( _21_ – _23_ ), SnTe2 decomposed into the tin (Sn) and Te when it is heated up to 600°C. Decomposed Sn and Te atoms move to the growth zone assisted by the N2 carrier gas. After the reaction finished, Te crystals with different morphologies were found in different regions on the substrate. Te nanosheets, with the length and thickness ranging from 20 to 80 m and 20 to 200 nm, respectively, were grown at around 400°C. Te nanowires, with the length ranging from 10 to 50 m and the diameter around 200 nm, are mainly distributed in the low-temperature area of 200°C. Figure 2B shows the growth orientation of Te nanosheets and nanowires. By the analysis of the above TEM data and previously reported results, it is found that the growth directions of hexagonal and pentagonal nanosheets include [001], [100], [101], and [10<sup>¯</sup> 1] orientation. Rectangular nanosheets are mainly in the growth directions of [001] and [100]. While all nanowires grow laterally along the [001] direction. To further verify the results, the surface energies of Te with different crystal orientations calculated by DFT are shown in Fig. 2C. It can be seen that the surface energy of {100}, {010}, {101}, and {001} planes are low as the stable surfaces. According to Wulff construction theory and kinetic Wulff construction 

modeling ( _24_ – _26_ ), these stable surfaces correspond to growth directions of [001], [100], [101], [10  1], [<sup>¯</sup> 10<sup>¯</sup> 1], [100], and [010] orientations.<sup>¯</sup> The schematic diagram of these crystal planes is shown in fig. S2. The {100} and {010} surfaces own the lowest surface energy among all of them, which correspond to the [001] and [100] orientations. In the growth energy area, [001] and [100] orientations own a higher growth rate than others. Te nanosheets are more easily presented as the rectangular morphology grown along these two orientations. When the growth energy becomes higher, the growth rates of the [101], [10<sup>¯</sup> 1], [<sup>¯</sup> 10<sup>¯</sup> 1], and [010] orientations corresponding to other stable surfaces become higher, so that trapezoid, pentagon, and hexagon shapes would gradually appear. The morphology evolution of Te material with the growth energy is shown in fig. S7. 

In the low-temperature region, the growth of Te nanowires is different from that of Te nanosheets. First, a small amount of Sn would deposit on the substrate. Second, when the growth continues and the precursor vapor arrives at the substrate, SnTe alloy seeds would be formed by the diffusion of Te atoms into the Sn catalyst droplets. Te element has a higher melting point, so Te element in the raw material is easier to deposit than Sn element. As the raw materials feeding the alloy continuously, the Te in the SnTe alloy would be gradually saturated, leading to the epitaxial growth of Te nanowires. The growth energy is low in the area where the nanowires grow. According to the analysis of surface energy, the Te nanowires preferentially grow along the [001] direction. Last, Te nanowires are formed. 



<!-- Start of picture text -->
A B<br>C D E<br>0.04 80<br> (100) 1D<br> (010)<br> (001) STEM HAADF detector 2D<br> (101)<br>0.03  (101) 60<br>Te<br>Sn<br>40<br>0.02<br>20<br>0.01<br>0<br>I II III IV<br>0.00<br>Plane PVD Solution CVD<br>Method<br>Range (m)µ<br>2Surface energy (eV/Å)<br><!-- End of picture text -->

**Fig. 2. Growth mechanism of low-dimensional Te.** ( **A** ) Growth schematic of low-dimensional Te. The light blue and yellow spheres represent the Sn and Te elements, respectively. Te nanosheets and nanowires grow at 400° and 200°C, shown in the enlarged illustration. ( **B** ) Schematic diagrams of different morphologies and growth directions. The illustrations in the lower right corner are the corresponding SEM figures. ( **C** ) Simulated surface energies for {100}, {010}, {101}, and {001}. The specific value corresponding to each crystal plane. (100): 0.0166 eV/Å<sup>2</sup> ; (010): 0.0166 eV/Å<sup>2</sup> ; (001): 0.0258 eV/Å<sup>2</sup> ; (101): 0.0239 eV/Å<sup>2</sup> ; (10 1): 0.0237 eV/Å<sup>¯2</sup> . ( **D** ) Growth process schematics of Te nanowire. (I): Formation of the Sn nanoparticle, (II): Formation of Sn-Te neck with the increasing Te concentration, (III): Growth of Te nanowire, and (IV): Formation of Sn-catalyzed Te. TEM image and energydispersive x-ray mappings of Sn-catalyzed Te nanowire are shown in the inset, respectively. STEM, scanning transmission electron microscopy; HAADF, high-angle annular dark field. ( **E** ) Dimensional statistics of low- dimensional Te materials synthesized by different methods. Range refers to lengths for nanowires and widths for nanosheets. 

Peng _et al_ ., _Sci. Adv._ 2021; **7** : eabf7358     16 April 2021 

**3 of 11** 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

The formation of Te nanowires in the low-temperature region of the furnace is dominated by thermodynamics. It is related to the decomposition of Sn from our raw materials SnTe2. To confirm the above nanowire growth process, elemental analysis of the Te nanowires was performed. It is found that Te is uniformly distributed in the whole nanowire, including the axial and radial directions of the nanowires, shown in the inset of Fig. 2D. Sn is obviously accumulated at the top of the nanowire. Energy dispersive spectrometer results further show that the Sn element is dominant at the top of the Te nanowire, and the Sn element only accounts for a very small content in the entire material element composition, as shown in fig. S4A. The results are consistent with the elemental mapping analysis. 

The metal Sn is a common catalyst metal for nanowire growth, and the area and ratio of element Sn distributed in our Te nanowires is a typical phenomenon of Sn as a nanowire catalytic metal in the vapor-liquid-solid mechanism ( _27_ – _29_ ). 

Te nanosheets and nanowires are not simply mixed in the same area. There will be obvious morphological differences in different temperature regions. As shown in fig. S6, combined with the growth mechanism mentioned above, only nanowires exist in the lowtemperature zone (region A). Te nanosheets in the medium temperature zone (region B) are mostly rectangular as shown in fig. S6C. The nanosheets in the high-temperature region (region C) will more exist with the pentagonal or hexagonal morphology. The growth morphology of Te materials in different temperature zones could be controllable. 

Compared to the previous synthesis methods of low-dimensional Te materials, the CVD method is reported here. Figure 2E shows the dimensions of Te materials synthesized by different methods. The length shown in the figure is the lengths for one-dimensional (1D) nanowires and the widths for 2D nanosheets. It can be seen that the sizes of Te materials prepared by CVD, whether it is 1D or quasi-2D, are large in several synthesis methods ( _30_ – _32_ ). Meanwhile, the CVD method has exhibited the unique potential in large-area and templated growth of the nanowires and 2D materials ( _33_ – _35_ ), which lays the foundation for further controlled large-area growth of low-dimensional Te materials. 

### **Optoelectronic properties of low-dimensional Te photodetectors** 

Room-temperature stable infrared detectors are of great significance in a host of fields. Here, we show the potential application of lowdimensional Te in room-temperature infrared detectors. Figure 3A shows the output characteristic curve of the Te nanowire field-effect transistor (FET) device, and the inset is a schematic diagram of the device. Meanwhile, Te nanosheet FET devices were also fabricated. The corresponding transfer characteristic curves, optical microscopy images of different Te devices, are shown in fig. S9. To further confirm the mobility of low-dimensional Te devices, 20 Te devices were fabricated. As shown in fig. S13, one can find that the mobilities of most Te nanowires and nanosheets exceed 100 and 500 cm<sup>2</sup> V<sup>−1</sup> per second, respectively. Moreover, the mobilities are much higher comparing with other transition metal dichalcogenides (table S1), which is suitable for the preparation of fast devices. 

The optoelectronic properties of low-dimensional Te photodetector determine the potential of Te as a future room-temperature infrared detector material. Figure 3B shows that the Te nanowire photodetector has a good response to light with a broadband wavelength from 500 to 2500 nm, which agrees well with the absorption spectra of Te. The spectral response of the Te nanosheet device is 

similar to that of the nanowire device, as shown in fig. S16. In addition, the absorption spectrum and electric field distribution of Te nanosheet and nanowire devices were simulated by the finite difference time domain method. The simulated absorption spectrum of low-dimensional Te photodetectors for different illumination wavelengths was exhibited in fig. S17 (A and C). The simulated curves have significant peaks between 1300 and 1700 nm, which matches the experimental photoresponse of the devices. 

The broadband spectral photoresponses of low-dimensional Te photodetectors exhibit the highest response at the wavelength ranging from 1100 to 1500 nm. Therefore, a 1550-nm laser was mainly applied to characterize the optoelectronic performances of the devices in our work. Figure 3C shows that the photocurrent _I_ ph and gain _G_ are closely dependent on the power intensity. The relationship between the photocurrent and intensity could be fitted through a nonlinear function, _I_ ph = _cp_<sup>_k_</sup> , where the _c_ is a proportionality constant, _p_ is the incident laser intensity, and _k_ is an empirical value. In addition, _k_ = 0.79 is acquired, implying that the device under the laser illumination is affected by the photogating effect, electron-hole generation, trapping, and recombination processes ( _5_ , _36_ ). In general, the gain _G_  I_ ph _h_  of the devices with photogating effects can be defined as _G_ =  e _PA_ <sup>,</sup> where _I_ ph is the photocurrent, e is the electronic charge, _P_ is the average power density of the incident light, _A_ is the illuminated area of the device, and _h_  is the energy of an incident photon. The responsivity _R_ is one of the most important indicators of a photodetector, which  I_ ph can be obtained by _R_ = _PA_<sup>.</sup><sup>_R_of Te photodetector under 1550 nm</sup> laser illumination is up to 6650 A W<sup>−1</sup> , shown in Fig. 3D. For both the Te nanowires and nanosheets devices, the gain is dependent on the wavelength of the laser, and the value of gain is relatively low compared to that of other low-dimensional materials, but the responsivity at the wavelength of 1550 nm is one of the best in state-of-the-art low-dimensional materials devices (see table S2), which can be attributed to the good crystal quality of Te materials as well as surface defects. As two other important performance parameters of the photodetector, noise equivalent power ( _NEP_ ) and detectivity ( _D_ *) are affected by the three main types of noise, Johnson noise, _1/f_ noise, and shot noise from dark current ( _37_ ). The _NEP_ and _D_ * can be calculated by _〈  〈 _i_ n 〉  〉<sup>2</sup> __ A_ √_ B_ the equations, _NEP_ =<sup>√__</sup> _R_<sup>,</sup><sup>_D_* =  √ =  √√</sup> _NEP_<sup>, where</sup><sup>_R_presents the re-</sup> sponsivity, 〈 _i_ n〉〉<sup>2</sup> is the noise current power, _A_ is the effective area of a photodetector, _B_ is the bandwidth. As shown in Fig. 3D, the specific detectivity of Te nanowires photodetector is up to 1.23 × 10<sup>12</sup> Jones at the bias voltage of 0.1 V. Relevant noise power density spectra 

_〈  〈 _i_ n 〉  〉<sup>2</sup> __ A_ √_ B_ the equations, _NEP_ =<sup>√__</sup> _R_<sup>,</sup><sup>_D_* =  √ =  √√</sup> _NEP_<sup>, where</sup><sup>_R_presents the re-</sup> sponsivity, 〈 _i_ n〉〉<sup>2</sup> is the noise current power, _A_ is the effective area of a photodetector, _B_ is the bandwidth. As shown in Fig. 3D, the specific detectivity of Te nanowires photodetector is up to 1.23 × 10<sup>12</sup> Jones at the bias voltage of 0.1 V. Relevant noise power density spectra for Te nanosheets and nanowires are shown in fig. S18. Figure 3D exhibits the obtained _R_ and _D_ * as a function of incident light intensity. As infrared light intensity decreases, both _R_ and _D_ * increase markedly. In addition, the photoresponse speed is a vital parameter for infrared photodetectors. In Fig. 3E, the rise and fall times of the Te nanowire device are 31.7 and 25.5 s, respectively. Compared with the previously reported devices in table S2, the response time of about 20 s represents one of the fastest speeds among all the photo conductive infrared detectors reported in the literature. In summary, the responsivity, response time, and detectivity of low-dimensional Te photodetectors are impressive. In addition to the optoelectronic characteristic 1550 nm, the Te nanosheet and nanowire photodetectors under other light illuminations such as 830 nm, 1310 nm, and 2 m were also characterized. Compared with the performance at 1550 nm, the _R_ and specific _D_ * of Te photodetectors are slightly smaller but still on the same order of magnitude. The statistics of the response time 

Peng _et al_ ., _Sci. Adv._ 2021; **7** : eabf7358     16 April 2021 

**4 of 11** 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

at the different wavelengths (830, 1310, and 1550 nm) are present in Fig. 3F. The response time of Te nanosheet and nanowire photodetectors is relatively stable, most of which are tens of microseconds. 

It is well known that there is a trade-off between gain ( _G_ ) and response time for low-dimensional photoconductive photodetectors ( _38_ ). Because of the limitation of the lifetime of the excited photocarrier in the materials, the gain and bandwidth are in a competitive relationship. Without the decay of gain, the maximum bandwidth can be roughly estimated by 1/, where  is the response time. Thus, the gain-bandwidth product (GBP) of each device is constant. The result shows that photodetectors with a larger responsivity often exhibit a slower response speed. The GBP value of the photodetectors is larger, meaning that the performance of the device is closer to the theoretical limit. Figure 3G shows a summary of GBP values for photoconductive detectors. The GBP values of Te nanosheet and nanowire photodetectors are notably higher than that of other photoconductive photodetectors. Moreover, the GBP of low-dimensional 

Te photodetectors is even comparable to that of the traditional thin-film photodetectors, which is marked by the yellow diagonal line (1 × 10<sup>9</sup> ). 

Air stability is also very important for low-dimensional photodetectors. All optoelectronic properties of the Te devices were measured under atmospheric conditions at room temperature. Compared to other infrared photodetectors, such as BP, b-AsP, and III-V semiconductor nanowires, the stability of low-dimensional Te devices is very excellent, as displayed in Fig. 3H and figs. S27 and S28. The photoelectric polarization performance of the Te nanosheet device under the 830-nm illumination is shown in Fig. 3I. The extinction ratio of the device at 830 nm can reach ~5.8, while the extinction ratios at 1310 and 1550 nm are 1.3 and 1.6, respectively (see fig. S29). Moreover, the polarization-resolved photocurrent mappings of Te nanosheet photodetector were achieved, shown in fig. S29. It is clear that the photocurrent of Te nanosheet device in the mapping diagram gradually decreases with increasing the polarization angle from 0° to 90°. All the results reveal that low-dimensional Te has great 



<!-- Start of picture text -->
A B C<br>6<br>4 V gs = 0 V 1.0  Responsivity Smoothed R 10 −5  Experimental dataFitting Curveλ = 1550 nm  G 6000<br>5000<br>2 0.8 I ph=  P  0.79<br>0.6 4000<br>0<br>10 −6<br>−2 Pt/Au Te 0.4<br>SiO2 3000<br>−4 V gs Si 0.2<br>Si V ds A I ds<br>−6−0.10 −0.05 0.00 0.05 0.10 0.0 500 1000 1500 2000 2500 10 −7 10 −2 10 −1 10 0<br>V ds (V) Wavelength (nm) Intensity (mW mm −2 )<br>D E F<br>8000  R 1.6 × 10 12 Off 543 λ = 830 nm NanowiresNanosheets<br> D * 2<br>6000 1<br>1.2 × 10 12 τr ~ 31.7 µs  τf ~ 25.5 µs  54300 λ20 = 1310 nm40 60 80 NanowiresNanosheets100<br>2<br>4000 1<br>8 × 10 11 On 5400 λ20 = 1550 nm40 60 80 NanowiresNanosheets100<br>3<br>2<br>1<br>0.01 0.1 1 400 Time (µs) 500 1300Time (µs)1400 00 20 40Response time 60 ( s ) 80 100<br>Intensity (mW mm −2 )<br>G H I 90<br>10 11 ZnO MoSGBP = G/τ =102/Gra BP/Gra 9  NW NB 2D HS      This work 120110100 After three months 1510 150 120 60 30<br>10 7 90 5<br>10 3 ReS2 MoS2CdS Te NW InAs Te NS Si/QDs 8070 cycles50  180 0<br>GaSb 60<br>10 −1 Bi2S3 BP 50 210 330<br>SnS2 Gra 40 240 300<br>30 270<br>10 −4 10 −1 10 2 10 5 10 8 10 11 0 10 110 120 130<br>1/τ (s −1 ) Time (s)<br>)A<br>( tn<br>err<br>A I () µds ).u.a( ytisn otocu<br>Ietn hP<br>Photoconductive gain<br>−1) Count<br>(AW<br> ytivisno ).u.a( ytisn Count<br>Reps  Detectivity (Jones) Ietn Intensity (a.u.)<br>Count<br> (µA)  I ph<br>Gain A I () µds<br><!-- End of picture text -->

**Fig. 3. Electrical and optoelectrical properties of low-dimensional Te devices.** ( **A** ) Output characteristic ( _V_ ds- _I_ ds) curve of Te nanowire device, exhibiting a good ohmic contact. The inset shows the schematic diagram of the device. ( **B** ) Photoresponse spectrum of Te nanowire device under the laser illumination with the wavelength from 500 to 2500 nm and a power intensity of 0.01 mW mm<sup>−2</sup> . The device operated at a bias of 0.1 V. ( **C** ) Photocurrent and photoconductive gain versus power intensity under 1550-nm laser illumination. ( **D** ) Responsivity and detectivity versus power intensity under 1550-nm laser illumination. ( **E** ) Time-resolved photoresponse of Te nanowire photodetector under 1550-nm laser illumination. ( **F** ) Photoresponse time statistics of low-dimensional Te photodetectors at different wavelengths. Ten nanowire and nanosheet devices were tested each. ( **G** ) Gain-bandwidth product (GBP) of low-dimensional photodetectors, exhibiting that the high GBP of low-dimensional Te photodetectors. The yellow line represents a typical magnitude order of GBP for traditional thin-film photodetectors, in low-dimensional material systems, except for those hybrid light guides, the values of devices in our work are one of the few ones that are close to this limit. NW, nanowire; NB, nanobelt; NS, nanosheet; HS, hybrid structure. ( **H** ) Stability of Te nanowires device. The device was measured at the _V_ ds = 0.1 V. ( **I** ) Polarization properties of Te nanosheet photodetectors under 830-nm laser illumination. 

Peng _et al_ ., _Sci. Adv._ 2021; **7** : eabf7358     16 April 2021 

**5 of 11** 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

potential for high-sensitive, ultrafast, stable, and broadband infrared photodetectors. 

### **Blackbody detection and imaging of low-dimensional Te photodetectors** 

Blackbody detection, as a detection standard for practical applications, is used to demonstrate the infrared detection performance of photodetectors. Figure 4A presents the schematic diagram of the blackbody detection system. See Materials and Methods for details. Figure 4B shows the responsivity ( _R_ ) and detectivity ( _D_ *) of low-dimensional Te photodetectors under 1200 K blackbody source illumination. No matter how the frequency of the chopper changes during the measurements, the blackbody responses of the devices are basically maintained at the same level. These results further confirm the stability and large bandwidth of the Te detectors. The _R_ and _D_ * of Te nanowire devices can reach up to 2.53 A W<sup>−1</sup> and 4.68 × 10<sup>8</sup> Jones, respectively. The _D_ * of the Te device under this blackbody temperature condition is slightly higher than that of the carbon tube. Although _D_ * of the Te device is not as good as that of the BP or BP/MoS2 devices, the photodetection of the Te devices can be further improved by preparing a p-n junction or hybrid structure. Combined with the performances under the previous laser measurement conditions, the infrared detection performances of detectors based on Te materials are one of the best among low-dimensional photodetectors. Meanwhile, the detection range can also be widened by material doping. 

Photoconductive gain is usually observed in photoconductive devices under laser irradiation. The high _R_ laser and _D_ laser* values of 

photodetectors under laser illumination include the contribution from the gain effect. Thus, the calculated _R_ laser and _D_ laser* are much larger, compared to the measured values of the commercial photodetectors. To show the smaller gain in blackbody detection of the Te photodetectors, pure responsivity _R_ p and pure detectivity _D_ p* elim_ _ inating the gain effect are proposed, where _R_ p =<sup>_R_</sup> _G_<sup>laserand</sup><sup>_D_p* =</sup><sup>_D_</sup> _G_<sup>laser.</sup> When we calculated the pure responsivity of the Te photodetectors, the quantum efficiency has defaulted to 1. The pure responsivity _R_ p is the theoretical maximum responsivity without gain. In addition, the pure detectivity _D_ p* is calculated under the condition of theoretical maximum responsivity without gain. The pure responsivity _R_ p and pure detectivity _D_ p* under the 1550-nm laser can be calculated as 1.25 A W<sup>−1</sup> and 2.3 × 10<sup>8</sup> Jones, respectively, shown in Fig. 4C. Meanwhile, the blackbody peak responsivity of 5.19 A W<sup>−1</sup> and detectivity of 9.6 × 10<sup>8</sup> Jones at the 1550 nm are obtained, respectively. The responsivity _R_ blackbody and detectivity _D_ blackbody under blackbody condition are very close to the pure responsivity _R_ p and pure detectivity _D_ p*. It means that our device also has a gain in detecting blackbody sources, but it is much smaller than the gain of the laser condition. 

The blackbody response of the Te nanosheet device at different polarization angles is shown in Fig. 4D. The extinction ratio of the Te nanosheet device is approximately 2.4. It can be concluded that, because of the excellent anisotropy of the Te crystal, the Te photodetectors exhibit a good photoelectric polarization response under both laser and blackbody illumination. 



<!-- Start of picture text -->
A B<br>Nanowire<br>10 R D *<br>Nanosheet 10 11<br>R D *<br>10 10<br>1<br>10 9<br>10 8<br>0.1<br>10 7<br>0 200 400 600 800 1000<br>Frequency (Hz)<br>C D 90<br>Blackbody  R R/G 120 60<br>10<br>Blackbody  D * D * /G 30<br>10 10 150 30<br>20<br>1<br>10 9<br>10 180 0<br>0.1<br>10 8<br>210 330<br>0.01 10 7<br>0.01 0.1 1<br>Intensity (mW mm −2 ) 240 300<br>270<br>−1Responsivity (A W)  Detectivity (Jones)<br> Intensity (a.u.)<br>1Responsivity (A W)−  Detectivity (Jones)<br><!-- End of picture text -->

**Fig. 4. Blackbody detection of low-dimensional Te photodetectors.** ( **A** ) Polarization blackbody measurement schematic of low-dimensional Te photodetectors under blackbody source illumination. After adding the polarizer and half-wave plate, the blackbody polarization measurement can be performed. ( **B** ) Blackbody responsivity and detectivity of Te nanowire and nanosheet detectors versus the frequency. ( **C** ) Pure responsivity _R_ p and pure detectivity _D_ p* versus power intensity under 1550-nm laser illumination. Pure responsivity _R_ p and pure detectivity _D_ p* are calculated under laser measurement conditions, corresponding to the triangle and pentagram in the figure, and the blackbody calculation results correspond to the dotted lines, which are unrelated to power intensity. ( **D** ) Polarization properties of Te nanosheet photodetector under blackbody source illumination. The polarization angle of the blackbody source is changed by rotating the half-wave plate when the frequency of the chopper is stabilized at 1000 Hz. 

Peng _et al_ ., _Sci. Adv._ 2021; **7** : eabf7358     16 April 2021 

**6 of 11** 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

**Table 1. Comparison of low-dimensional blackbody-sensitive photodetectors.** b-AsP, black phosphorus-arsenic; CQDs, colloidal quantum dots. 

|**Material**|**Stability**<br>**(atmosphere)**|**Synthesis**<br>**method**|**Controlled**<br>**growth**|**Operating**<br>**temperature**|**Blackbody**<br>**chopped**<br>**frequency**|**Detectivity**<br>**(Jones) at**<br>**morphology**|**Polarization**<br>**extinction ratio**|**References**|
|---|---|---|---|---|---|---|---|---|
|BP|<3 days|Mechanical<br>exfoliation|No|300 K|150 Hz|6 × 10<sup>10</sup>at film<br>(32 nm)|~ 10 (3.5-m<br>laser)|(_16_)|
|b-AsP|<3 days|Mechanical<br>exfoliation|No|300 K|150 Hz|2.4 × 10<sup>10</sup>at film<br>(66 nm)|-|(_16_)|
|BP/MoS2|<3 days|Mechanical<br>exfoliation|No|300 K|-|7 × 10<sup>9</sup>at p-n<br>junction (20 nm)|~4 (3.5-m laser)|(_9_)|
|||||||1.9 × 10<sup>7</sup>at|||
|Carbon<br>nanotube|>3 months|LPCVD|Yes|300 K|~2 Hz|carbon nanotube<br>forest film<br>(100m)|-|(_15_)|
|HgTe CQDs|~1 month|Chemical<br>solution<br>growth|Yes|85/295 K|10 kHz|3 × 10<sup>10</sup>/1 × 10<sup>7</sup>at<br>npn structures<br>film (1m)|-|(_18_)|
|Te nanosheet|>3 months|CVD|Yes|300 K|1000 Hz|2.06 × 10<sup>7</sup>at<br>single nanosheet<br>(85 nm)|2.4 (blackbody)||
|||||||4.68 × 10<sup>8</sup>at||This work|
|Te nanowire|>3 months|CVD|Yes|300 K|1000 Hz|single nanowire<br>(diameter<br>~ 200 nm)|-||
||**A**<br>1310 nm|_G_1310 nm= 1500||1550 nm|_G_1550 nm= 4000|Elec|Hole<br>tron||
||Core|||Core|||Light||
||||||||Photogenerated||
||2 µm|_G_2 µm= 500||Blackbody|_G_blackbody= ~5||||
||Core|||Core|||||
||**B**||||||||



**Fig. 5. Response mechanism of Te nanowire photodetectors under laser and blackbody illumination.** ( **A** ) Schematic diagram of the surface state effect of nanowires under different light sources. Under the irradiation of 1310-, 1550-nm, and 2-m laser and blackbody light source, the ability of surface states to capture photogenerated electrons is different, so the gain caused by the surface states are different, respectively, about 1500, 4000, 500, and 5. ( **B** ) Schematic illustration of the defect energy level in the surface state. _E_ t stands for defect energy level. The blackbody source contains photons of various energies, the defect energy level is preferentially occupied by electrons excited by high-energy photons, resulting in a small gain of the blackbody. CB, conduction band; VB, valence band. 

Peng _et al_ ., _Sci. Adv._ 2021; **7** : eabf7358     16 April 2021 

**7 of 11** 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

Among the low-dimensional materials, only a few materials and devices with blackbody response have been reported, as shown in Table 1. Compared with other materials, the stability of low-dimensional Te is better. The synthesis method of CVD is more controllable and has the potential to realize the growth of large-area materials. Meanwhile, low-dimensional Te devices exhibit excellent blackbody response and have the sensitivity of a polarized blackbody source, which provides a novel platform for blackbody detection in the low-dimensional system. 

It can be seen from the above-obtained data that the detectivity of the same device under laser irradiation is much higher than the blackbody peak detectivity at the corresponding wavelength. According to the data analysis of Fig. 4C, it can be inferred that this is related to the gain in low-dimensional Te material. More analysis of the optoelectronic performance data reveals that the gain is dependent on the wavelength, shown in Fig. 5A. As shown in Fig. 3C, gain _G_ decreases as the laser intensity increases. At 1310 nm, 1550 nm, and 2 m with the same intensity of 0.1 mW mm<sup>−1</sup> , the specific gain of the same nanowire device is about 1500, 4000, and 500. However, the gain under the blackbody radiation source is approximately 5, which is much smaller than that of the laser. 

For nanowires photodetectors, the gain is not only derived from the intrinsic materials but also affected by the surface state. After illumination, these states will trap one type of photo-generated carriers and continuously form the gate electric field to modulate the channel conductance, resulting in more electron-hole pairs collected by the electrode, which means higher gain devices. These have been extensively and well studied, and especially under laser irradiation, this phenomenon is more obvious ( _5_ , _38_ – _41_ ). Combined with the previous TEM characterization, it is obvious that there are plentiful surface states in the Te nanowires and nanosheets, which leads to the high gain of the Te photodetectors. In addition, the schematic diagram of the effect of the surface states in the nanowires is shown in Fig. 5A. The surface states with the defect energy level existing above the conduction band are hindered by a barrier from the channel, as shown in Fig. 5B. Hot electrons excited by high-energy photons have enough energy to overcome the barrier and then be trapped by the defects ( _42_ ). The process of electrons releasing from the defects to the conduction band is called the detrapping process, which requires thermal assistance to fulfill. The ability of surface states to capture electrons under different lasers is different, depending on the two processes of trapping and detrapping. The photoresponse properties of the device are obtained under 520-, 637-, 830-, 1310-, 1550-nm, and 2-m laser illumination, as shown in fig. S32. The photocurrent _I_ ph and gain _G_ are closely dependent on power intensity. Figure S31B shows the gain of the same device illuminated by lasers with different wavelengths. The gain of the Te device under 520- and 637-nm lasers is relatively small. For high-energy photons, although the corresponding excited electrons can be easily captured by surface states, they can be efficiently detrapped as well. Thus, a smaller gain is observed for visible light and near-infrared wavelength light. 

The simulated 1200 K blackbody spectrum in the Supplementary Materials shows that the energy of most photons is lower than that of the 2-m laser. However, the higher-energy photons also exist in blackbody sources. 

Under the blackbody source illumination, the Te device is simultaneously illuminated by photons of different energies. The 

defect energy level is preferentially occupied by electrons excited by higher- energy photons ( _42_ ). Thus, the available surface states for lower-energy photon-induced electrons are reduced, leading to a reduced gain under blackbody illumination compared with laser illumination. 

Imaging is a significant application field of photodetectors ( _43_ , _44_ ). To check the imaging capability of Te photodetector, a reflection imaging system has been set up, as shown in Fig. 6A. Two sets of objective samples were prepared. The imaging results of the Te nanosheet detectors are shown in Fig. 6 (B and C). The images under both visible and infrared illuminations are very legible. Even some defects of metal objects generated during the fabrication process could be distinguished, such as small gold nuggets in the letter D and the irregular parts in the lower right corner of the institute icon. A series of imagings illustrate the excellent imaging ability of the low-dimensional Te photodetectors. 

### **Conclusions** 

In summary, large-scale, high-quality tellurium nanosheets and nanowires have been successfully prepared by CVD. Meanwhile, the growth mechanism of low-dimensional Te is illustrated. Both the ultrahigh hole mobility and good crystallinity ensure the excellent photoresponse performance of the devices based on low-dimensional Te. Low-dimensional Te detectors exhibit excellent performance with a large responsivity (6650 A W<sup>−1</sup> ), a high detectivity (1.23 × 10<sup>12</sup> Jones), and an ultrafast photoresponse (25.5 s) under the laser illumination. Noticeably, CVD-grown Te detectors have an obvious roomtemperature blackbody response. Furthermore, high-resolution imaging by the Te photodetectors has confirmed the great potential 



**Fig. 6. Imaging of Te nanosheet photodetectors.** ( **A** ) Schematic of the reflection imaging system for Te nanosheet photodetector. ( **B** and **C** ) Imagings by Te nanosheet photodetectors under the wavelength of 637 nm and 2 m, respectively. The inset shows optical microscopy images of the imaging objective sample. Shanghai Institute of Technical Physics, SITP. (C) “Te,” “INFRARED,” and “HUST.” 

Peng _et al_ ., _Sci. Adv._ 2021; **7** : eabf7358     16 April 2021 

**8 of 11** 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

of Te in practical application fields. In the future, p-n junction or other hybrid structure devices based on pure Te material can be designed to further improve the photodetection performance of the devices. Meanwhile, flexible substrates or array template substrates can be applied to grow high-quality materials and then make full use of the excellent electrical and photoelectric properties of Te materials in not only photodetectors but also functional and integrated devices. 

#### **MATERIALS AND METHODS** 

### **Materials synthesis and characterization** 

The large-area tellurium nanosheets and nanowires were grown via a CVD method. A ceramic boat with SnTe2 powder (Sigma-Aldrich, 99.99%) in it was placed in the middle of a quartz tube. The silicon substrate was placed on another ceramic boat downstream of the carrier gas N2. The flow rate of gas is 50 standard-state cubic centimeters per minute. The SnTe2 in the quartz tube was heated to 650°C. The growth was maintained at atmospheric pressure for 30 min and then naturally cooled down. 

The morphologies of tellurium nanosheets and nanowires were investigated by SEM (JEOL Model JSM-6490). HRTEM, SEAD (JEOL JEM-2100F), and XRD patterns ((Bruker D8) were used to characterize the crystal structure. A Bruker Fourier transform infrared spectrometer (Vertex 70v) integrated with a Hyperion 2000 microscope was used to analyze the absorption spectrum of Te. The topography of materials and devices was characterized by AFM (Bruker MultiMode 8). 

### **Polarized Raman studies** 

Polarization-resolved Raman scattering measurements were recorded every 10° by a micro-Raman spectrometer with backscattering geometry (Jobin-Yvon LabRAM HR Evolution spectrometer). The resolution of spectral is smaller than 1 cm<sup>−1</sup> , and the wavelength of the excitation source is 532-nm laser. The laser source was focused via a ×100 magnification microscope, and the working distance is 18 mm. The scattered signals are dispersed on 1800 grooves/mm grating, and they are collected through a charge-coupled device, which the front-illuminated chip is 1024 × 256 pixels. 

### **Blackbody system and analysis** 

The blackbody source is HFY-206A without a focusing lens. The device was placed 15 cm away from the aperture with a fixed modulation frequency of 1000 Hz chopped by an optical chopper wheel. An 800-nm to 2.7-m bandpass polarizer and a 1-m high-pass halfwave plate are placed in front of the device for blackbody polarization measurements. The total incident power on the device surface 

can be calculated by the approximation formula _P_ =  ___________( _T_ s<sup>4</sup> − _L_<sup>2</sup> _T_<sup>4</sup> 0 ) _A R_<sup>2</sup> , where  is the modulation factor,  is the average emissivity of the blackbody source,  is 0.9 for our blackbody source,  is the Stefan-Boltzmann constant. _T_ s and _T_ 0 are the temperature of the blackbody radiation source and the room temperature (300 K), respectively. _A_ is the device area in units of square centimeters. _R_ is the aperture radius of the blackbody radiation source, and _L_ is the distance between the aperture and sample in units of centimeters. 

### **Imaging system and analysis** 

The light beam emitted by the laser light source is converted into a pulsed beam by a chopper and then reflected by a half mirror and focused on the surface of the imaged object through the objective lens. After being reflected by the object, the laser beam is irradiated onto the detector through the objective lens, a half mirror, and a condensing lens. The electrical signals of the detector are extracted by a lock-in amplifier to obtain the corresponding image. This reflection imaging system is active imaging. The imaging principle is that the light source is irradiated to the surface of the detected object, and the object will reflect the illumination light. For a laser beam of a specific wavelength, different objects have different reflectivity or the same object with different morphologies has different reflectivity, resulting in different reflected light intensities. The system applies the detection device for detecting the change of the reflected beam light intensity, which can reflect the object’s spatial position and shape. Last, the measured object could be reconstructed by plane scanning. 

### **SUPPLEMENTARY MATERIALS** 

Supplementary material for this article is available at http://advances.sciencemag.org/cgi/ content/full/7/16/eabf7358/DC1 

### **Device fabrication and analysis** 

All devices were prepared by using the electron-beam lithography technique. Before depositing the contact metal, Te nanowires and nanosheets were immersed in a 3% hydrofluoric acid solution for about 10 s to remove the natural oxide layer. Then, the substrate was immediately put into the thermal evaporation system. The metal contacts with the Te material directly, achieving a good ohmic contact between the metal and Te semiconductor. Pt/Au (50/100 nm) was used as contacted metal for source/drain electrodes; most of the electronic and optoelectronic properties were measured under ambient conditions at room temperature. All I-V (current/voltage) characteristics were measured by the Agilent B2902A source. The laser source for spectral response is provided by the combination of continuous laser light source and gratings. Other laser light sources are emitted from a monochrome laser, which could be any laser wavelength in the 520 nm to 2 m. High time-resolution response current signal was converted to a voltage signal using a preamp (Stanford Research Systems SR570) and recorded by Tektronix MDO3014 mixed domain oscilloscope. 

### **REFERENCES AND NOTES** 

1. F. Parra, P. Meza, C. Toro, S. Torres, Infrared Focal Plane Array Imaging System Characterization by Means of a Blackbody Radiator, in _Progress in Pattern Recognition, Image Analysis, Computer Vision, and Applications_ (Springer-Verlag, 2011), pp. 105–112. 

2. G. Cao, T. Li, H. Tang, X. Shao, X. Li, H. Gong, Performance of extended wavelength InGaAs/InAsP SWIR detector, in _7th International Symposium on Advanced Optical Manufacturing and Testing Technologies_ , Y. Jiang, J. Yu, B. Kippelen, Eds. (SPIE, 2014), vol. 9284, chap. 1. 

3. E. G. Camargo, K. Ueno, Y. Kawakami, Y. Moriyasu, K. Nagase, M. Satou, H. Endo, K. Ishibashi, N. Kuze, Miniaturized InSb photovoltaic infrared sensor operating at room temperature. _Opt. Eng._ **47** , 014402 (2008). 

4. P. R. McCullough, M. Regan, L. Bergeron, K. Lindsay, Quantum efficiency and quantum yield of an HgCdTe infrared sensor array. _Publ. Astron. Soc. Pac._ **120** , 759–776 (2008). 

5. N. Guo, W. Hu, L. Liao, S. P. Yip, J. C. Ho, J. Miao, Z. Zhang, J. Zou, T. Jiang, S. Wu, X. Chen, W. Lu, Anomalous and highly efficient InAs nanowire phototransistors based on majority carrier transport at room temperature. _Adv. Mater._ **26** , 8203–8209 (2014). 

6. C.-H. Liu, Y.-C. Chang, T. B. Norris, Z. Zhong, Graphene photodetectors with ultrabroadband and high responsivity at room temperature. _Nat. Nanotechnol._ **9** , 273–278 (2014). 

7. J. L. Wang, H. Fang, X. Wang, X. Chen, W. Lu, W. Hu, Recent progress on localized field enhanced two-dimensional material photodetectors from ultraviolet-visible to infrared. _Small_ **13** , 1700894 (2017). 

Peng _et al_ ., _Sci. Adv._ 2021; **7** : eabf7358     16 April 2021 

**9 of 11** 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

8. M. Long, Y. Wang, P. Wang, X. Zhou, H. Xia, C. Luo, S. Huang, G. Zhang, H. Yan, Z. Fan, X. Wu, X. Chen, W. Lu, W. Hu, Palladium diselenide long-wavelength infrared photodetector with high sensitivity and stability. _ACS Nano_ **13** , 2511–2519 (2019). 

9. J. Bullock, M. Amani, J. Cho, Y.-Z. Chen, G. H. Ahn, V. Adinolfi, V. R. Shrestha, Y. Gao, K. B. Crozier, Y.-L. Chueh, A. Javey, Polarization-resolved black phosphorus/molybdenum disulfide mid-wave infrared photodiodes with high detectivity at room temperature. _Nat. Photonics_ **12** , 601–607 (2018). 

10. N. M. R. Peres, J. E. Santos, Strong light-matter interaction in systems described by a modified Dirac equation. _J. Phys. Condens. Matter_ **25** , 305801 (2013). 

11. C. Zhou, X.-T. Zhang, K. Zheng, P.-P. Chen, W. Lu, J. Zou, Correction to Self-assembly growth of In-rich InGaAs core-shell structured nanowires with remarkable near-infrared photoresponsivity. _Nano Lett._ **19** , 2188–2188 (2019). 

12. Q. Liang, Q. Wang, Q. Zhang, J. Wei, S. X. Lim, R. Zhu, J. Hu, W. Wei, C. Lee, C. H. Sow, W. Zhang, A. T. S. Wee, High-performance, room temperature, ultra-broadband photodetectors based on air-stable PdSe2. _Adv. Mater._ **31** , 1807609 (2019). 

13. N. Youngblood, C. Chen, S. J. Koester, M. Li, Waveguide-integrated black phosphorus photodetector with high responsivity and low dark current. _Nat. Photonics_ **9** , 247–252 (2015). 

14. Y. Liu, B. N. Shivananju, Y. Wang, Y. Zhang, W. Yu, S. Xiao, T. Sun, W. Ma, H. Mu, S. Lin, H. Zhang, Y. Lu, C.-W. Qiu, S. Li, Q. Bao, Highly efficient and air-stable infrared photodetector based on 2D layered graphene-black phosphorus heterostructure. _ACS Appl. Mater. Interfaces_ **9** , 36137–36145 (2017). 

15. M. Zhang, D. Ban, C. Xu, J. T. W. Yeow, Large-area and broadband thermoelectric infrared detection in a carbon nanotube black-body absorber. _ACS Nano_ **13** , 13285–13292 (2019). 

16. M. Amani, E. Regan, J. Bullock, G. H. Ahn, A. Javey, Mid-wave infrared photoconductors based on black phosphorus-arsenic alloys. _ACS Nano_ **11** , 11724–11731 (2017). 

17. S. A. McDonald, G. Konstantatos, S. Zhang, P. W. Cyr, E. J. D. Klem, L. Levina, E. H. Sargent, Solution-processed PbS quantum dot infrared photodetectors and photovoltaics. _Nat. Mater._ **4** , 138–142 (2005). 

18. X. Tang, M. M. Ackerman, M. Chen, P. Guyot-Sionnest, Dual-band infrared imaging using stacked colloidal quantum dot photodiodes. _Nat. Photonics_ **13** , 277–282 (2019). 

19. H. Fang, P. Wu, P. Wang, Z. Zheng, Y. Tang, J. C. Ho, G. Chen, Y. Wang, C. Shan, X. Cheng, J. Zhang, W. Hu, Global photocurrent generation in phototransistors based on singlewalled carbon nanotubes toward highly sensitive infrared detection. _Adv. Opt. Mater._ **7** , 1900597 (2019). 

20. Z.-H. Lin, Z. Yang, H.-T. Chang, Preparation of fluorescent tellurium nanowires at room temperature. _Cryst. Growth Des._ **8** , 351–357 (2008). 

21. D. V. Talapin, E. V. Shevchenko, M. I. Bodnarchuk, X. Ye, J. Chen, C. B. Murray, Quasicrystalline order in self-assembled binary nanoparticle superlattices. _Nature_ **461** , 964–967 (2009). 

22. K. Löwe, J. Liu, K. Skokov, J. D. Moore, H. Sepehri-Amin, K. Hono, M. Katter, O. Gutfleisch, The effect of the thermal decomposition reaction on the mechanical and magnetocaloric properties of La(Fe,Si,Co)13. _Acta Mater._ **60** , 4268–4276 (2012). 

23. S. I. Pechenyuk, D. P. Domonov, A. N. Gosteva, G. I. Kadyrova, V. T. Kalinnikov, Synthesis, properties, and thermal decomposition of compounds [Co(En)3][Fe(CN)6]·2H2O and [Co(En)3]4[Fe(CN)6]3·15H2O. _Russ. J. Coord. Chem._ **38** , 596–603 (2012). 

24. N. S. Peev, Another look on wulff construction. _Cryst. Res. Technol._ **52** , 1700100 (2017). 

25. Y. Gu, H. Cai, J. Dong, Y. Yu, A. N. Hoffman, C. Liu, A. D. Oyedele, Y.-C. Lin, Z. Ge, A. A. Puretzky, G. Duscher, M. F. Chisholm, P. D. Rack, C. M. Rouleau, Z. Gai, X. Meng, F. Ding, D. B. Geohegan, K. Xiao, Two-dimensional palladium diselenide with strong in-plane optical anisotropy and high mobility grown by chemical vapor deposition. _Adv. Mater._ **32** , 2003751 (2020). 

26. Y. Zou, Z. Chen, J. Lin, X. Zhou, W. Lu, J. Drennan, J. Zou, Morphological control of SnTe nanostructures by tuning catalyst composition. _Nano Res._ **8** , 3011–3019 (2015). 

27. J. Hu, M. Ouyang, P. Yang, C. M. Lieber, Controlled growth and electrical properties of heterojunctions of carbon nanotubes and silicon nanowires. _Nature_ **399** , 48–51 (1999). 

28. Y. Wu, P. Yang, Direct observation of vapor-liquid-solid nanowire growth. _J. Am. Chem. Soc._ **123** , 3165–3166 (2001). 

29. R. Sun, D. Jacobsson, I.-J. Chen, M. Nilsson, C. Thelander, S. Lehmann, K. A. Dick, Sn-seeded GaAs nanowires as self-assembled radial _p-n_ junctions. _Nano Lett._ **15** , 3757–3762 (2015). 

30. Y. Wang, G. Qiu, R. Wang, S. Huang, Q. Wang, Y. Liu, Y. Du, W. A. Goddard III, M. J. Kim, X. Xu, P. D. Ye, W. Wu, Field-effect transistors made from solution-grown twodimensional tellurene. _Nat. Electron._ **1** , 228–236 (2018). 

31. M. Amani, C. Tan, G. Zhang, C. Zhao, J. Bullock, X. Song, H. Kim, V. R. Shrestha, Y. Gao, K. B. Crozier, M. Scott, A. Javey, Solution-synthesized high-mobility tellurium nanoflakes for short-wave infrared photodetectors. _ACS Nano_ **12** , 7253–7263 (2018). 

32. H.-S. Qian, S.-H. Yu, J.-Y. Gong, L.-B. Luo, L.-f. Fei, High-quality luminescent tellurium nanowires of several nanometers in diameter and high aspect ratio synthesized by a poly (vinyl pyrrolidone)-assisted hydrothermal process. _Langmuir_ **22** , 3830–3835 (2006). 

33. J. Jeon, S. K. Jang, S. M. Jeon, G. Yoo, Y. H. Jang, J.-H. Park, S. Lee, Layer-controlled CVD growth of large-area two-dimensional MoS2 films. _Nanoscale_ **7** , 1688–1695 (2015). 

34. A. Dathbun, Y. Kim, S. Kim, Y. Yoo, M. S. Kang, C. Lee, J. H. Cho, Large-area CVD-grown sub-2 V ReS2 transistors and logic gates. _Nano Lett._ **17** , 2999–3005 (2017). 

35. H. Zhou, W. J. Yu, L. Liu, R. Cheng, Y. Chen, X. Huang, Y. Liu, Y. Wang, Y. Huang, X. Duan, Chemical vapour deposition growth of large single crystals of monolayer and bilayer graphene. _Nat. Commun._ **4** , 2096 (2013). 

36. M. Peng, F. Wu, Z. Wang, P. Wang, F. Gong, M. Long, C. Chen, J. Dai, W. Hu, Enhancementmode CdS nanobelts field effect transistors and phototransistors with HfO2 passivation. _Appl. Phys. Lett._ **114** , 111103 (2019). 

37. X. Gong, M. Tong, Y. Xia, W. Cai, J. S. Moon, Y. Cao, G. Yu, C.-L. Shieh, B. Nilsson, A. J. Heeger, High-detectivity polymer photodetectors with spectral response from 300 nm to 1450 nm. _Science_ **325** , 1665–1667 (2009). 

38. H. Fang, W. Hu, Photogating in low dimensional photodetectors. _Adv. Sci._ **4** , 1700323 (2017). 

39. Y. Yang, X. Peng, H.-S. Kim, T. Kim, S. Jeon, H. K. Kang, W. Choi, J. Song, Y.-J. Doh, D. Yu, Hot carrier trapping induced negative photoconductance in InAs nanowires toward novel nonvolatile memory. _Nano Lett._ **15** , 5875–5882 (2015). 

40. M. M. Furchi, D. K. Polyushkin, A. Pospischil, T. Mueller, Mechanisms of photoconductivity in atomically thin MoS2. _Nano Lett._ **14** , 6165–6170 (2014). 

41. J. O. Island, S. I. Blanter, M. Buscema, H. S. J. van der Zant, A. Castellanos-Gomez, Gate controlled photocurrent generation mechanisms in high-gain In2Se3 phototransistors. _Nano Lett._ **15** , 7853–7858 (2015). 

42. H. Fang, W. Hu, P. Wang, N. Guo, W. Luo, D. Zheng, F. Gong, M. Luo, H. Tian, X. Zhang, C. Luo, X. Wu, P. Chen, L. Liao, A. Pan, X. Chen, W. Lu, Visible light-assisted highperformance mid-infrared photodetectors based on single InAs nanowire. _Nano Lett._ **16** , 6416–6424 (2016). 

43. P. Wang, S. Liu, W. Luo, H. Fang, F. Gong, N. Guo, Z.-G. Chen, J. Zou, Y. Huang, X. Zhou, J. Wang, X. Chen, W. Lu, F. Xiu, W. Hu, Arrayed van der waals broadband detectors for dual-band detection. _Adv. Mater._ **26** , 1604439 (2017). 

44. W.-S. Kuo, C.-N. Chang, Y.-T. Chang, M.-H. Yang, Y.-H. Chien, S.-J. Chen, C.-S. Yeh, Gold nanorods in photodynamic therapy, as hyperthermia agents, and in near-infrared optical imaging. _Angew. Chem. Int. Ed._ **49** , 2711–2715 (2010). 

45. Y. Wang, C. Xiao, M. Chen, C. Hua, J. Zou, C. Wu, J. Jiang, S. A. Yang, Y. Lu, W. Ji, Two-dimensional ferroelectricity and switchable spin-textures in ultra-thin elemental Te multilayers. _Mater. Horiz._ **5** , 521–528 (2018). 

46. G. Kresse, J. Furthmüller, Efficient iterative schemes for ab initio total-energy calculations using a plane-wave basis set. _Phys. Rev. B._ **54** , 11169–11186 (1996). 

47. G. Kresse, J. Furthmüller, Efficiency of ab-initio total energy calculations for metals and semiconductors using a plane-wave basis set. _Comput. Mater. Sci._ **6** , 15–50 (1996). 

48. P. E. Blöchl, Projector augmented-wave method. _Phys. Rev. B._ **50** , 17953–17979 (1994). 

49. J. P. Perdew, K. Burke, M. Ernzerhof, Generalized gradient approximation made simple. _Phys. Rev. Lett._ **77** , 3865–3868 (1996). 

50. S. Grimme, Semiempirical GGA-type density functional constructed with a long-range dispersion correction. _J. Comput. Chem._ **27** , 1787–1799 (2006). 

51. V. Wang, N. Xu, J. C. Liu, G. Tang, W.-T. Geng, VASPKIT: A User-friendly Interface Facilitating High-throughput Computing and Analysis Using VASP Code. arXiv:1908.08269 (2019). 

52. Z. Zhang, A. J. Mannix, X. Liu, Z. Hu, N. P. Guisinger, M. C. Hersam, B. I. Yakobson, Near-equilibrium growth from borophene edges on silver. _Sci. Adv._ **5** , eaax0246 (2019). 

53. D. Cao, T. Shen, P. Liang, X. Chen, H. Shu, Role of chemical potential in flake shape and edge properties of monolayer MoS2. _J. Phys. Chem. C_ **119** , 4294–4301 (2015). 

54. L. Ye, P. Wang, W. Luo, F. Gong, L. Liao, T. Liu, L. Tong, J. Zang, J. Xu, W. Hu, Highly polarization sensitive infrared photodetector based on black phosphorus-on-WSe2 photogate vertical heterostructure. _Nano Energy_ **37** , 53–60 (2017). 

55. J. Hämäläinen, M. Mattinen, K. Mizohata, K. Meinander, M. Vehkamäki, J. Räisänen, M. Ritala, M. Leskelä, Atomic layer deposition of rhenium disulfide. _Adv. Mater._ **30** , 1703622 (2018). 

56. L. Yang, K. Majumdar, H. Liu, Y. Du, H. Wu, M. Hatzistergos, P. Y. Hung, R. Tieckelmann, W. Tsai, C. Hobbs, P. D. Ye, Chloride molecular doping technique on 2D materials: WS2 and MoS2. _Nano Lett._ **14** , 6275–6280 (2014). 

57. H. Liu, A. T. Neal, P. D. Ye, Channel length scaling of MoS2 MOSFETs. _ACS Nano_ **6** , 8563–8569 (2012). 

58. Z. Zhang, T. Li, Y. Wu, Y. Jia, C. Tan, X. Xu, G. Wang, J. Lv, W. Zhang, Y. He, J. Pei, C. Ma, G. Li, H. Xu, L. Shi, H. Peng, H. Li, Truly concomitant and independently expressed shortand long-term plasticity in a Bi2O2Se-based three-terminal memristor. _Adv. Mater._ **31** , 1805769 (2019). 

59. H. Liu, A. T. Neal, Z. Zhu, Z. Luo, X. Xu, D. Tománek, P. D. Ye, Phosphorene: An unexplored 2D semiconductor with a high hole mobility. _ACS Nano_ **8** , 4033–4041 (2014). 

Peng _et al_ ., _Sci. Adv._ 2021; **7** : eabf7358     16 April 2021 

**10 of 11** 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

60. L. Li, Y. Yu, G. J. Ye, Q. Ge, X. Ou, H. Wu, D. Feng, X. H. Chen, Y. Zhang, Black phosphorus field-effect transistors. _Nat. Nanotechnol._ **9** , 372–377 (2014). 

61. A. Abderrahmane, P. J. Ko, T. V. Thu, S. Ishizawa, T. Takamura, A. Sandhu, High photosensitivity few-layered MoSe2 back-gated field-effect phototransistors. _Nanotechnology_ **25** , 365202 (2014). 

62. Z. Wang, P. Wang, F. Wang, J. Ye, T. He, F. Wu, M. Peng, P. Wu, Y. Chen, F. Zhong, R. Xie, Z. Cui, L. Shen, Q. Zhang, L. Gu, M. Luo, Y. Wang, H. Chen, P. Zhou, A. Pan, X. Zhou, L. Zhang, W. Hu, A noble metal dichalcogenide for high-performance field-effect transistors and broadband photodetectors. _Adv. Funct. Mater._ **30** , 1907945 (2020). 

63. J. Sun, M. Peng, Y. Zhang, L. Zhang, R. Peng, C. Miao, D. Liu, M. Han, R. Feng, Y. Ma, Y. Dai, L. He, C. Shan, A. Pan, W. Hu, Z.-x. Yang, Ultrahigh hole mobility of Sn-catalyzed GaSb nanowires for high speed infrared photodetectors. _Nano Lett._ **19** , 5920–5929 (2019). 

      - imaging based on quasi-2D tellurium at room temperature. _Nat. Commun._ **11** , 2308 (2020). 

   76. Z. Sun, Z. Liu, J. Li, G.-A. Tai, S.-P. Lau, F. Yan, Infrared photodetectors based on CVD-grown graphene and PbS quantum dots with ultrahigh responsivity. _Adv. Mater._ **24** , 5878–5883 (2012). 

   77. K. Roy, M. Padmanabhan, S. Goswami, T. P. Sai, G. Ramalingam, S. Raghavan, A. Ghosh, Graphene-MoS2 hybrid structures for multifunctional photoresponsive memory devices. _Nat. Nanotechnol._ **8** , 826–830 (2013). 

   78. F. Wu, Q. Li, P. Wang, H. Xia, Z. Wang, Y. Wang, M. Luo, L. Chen, F. Chen, J. Miao, X. Chen, W. Lu, C. Shan, A. Pan, X. Wu, W. Ren, D. Jariwala, W. Hu, High efficiency and fast van der Waals hetero-photodiodes with a unilateral depletion region. _Nat. Commun._ **10** , 4663 (2019). 

64. J. Miao, W. Hu, N. Guo, Z. Lu, X. Zou, L. Liao, S. Shi, P. Chen, Z. Fan, J. C. Ho, T.-X. Li, X. S. Chen, W. Lu, Single InAs nanowire room-temperature near-infrared photodetectors. _ACS Nano_ **8** , 3628–3635 (2014). 

65. G. Zhou, R. Addou, Q. Wang, S. Honari, C. R. Cormier, L. Cheng, R. Yue, C. M. Smyth, A. Laturia, J. Kim, W. G. Vandenberghe, M. J. Kim, R. M. Wallace, C. L. Hinkle, High-mobility helical tellurium field-effect transistors enabled by transfer-free, low-temperature direct growth. _Adv. Mater._ **30** , 1803109 (2018). 

66. H. Ali, Y. Zhang, J. Tang, K. Peng, S. Sun, Y. Sun, F. Song, A. Falak, S. Wu, C. Qian, M. Wang, Z. Zuo, K.-J. Jin, A. M. Sanchez, H. Liu, X. Xu, High-responsivity photodetection by a self-catalyzed phase-pure p-GaAs nanowire. _Small_ **14** , 1704429 (2018). 

67. D. Zheng, J. Wang, W. Hu, L. Liao, H. Fang, N. Guo, P. Wang, F. Gong, X. Wang, Z. Fan, X. Wu, X. Meng, X. Chen, W. Lu, When nanowires meet ultrahigh ferroelectric field-highperformance full-depleted nanowire photodetectors. _Nano Lett._ **16** , 2548–2555 (2016). 

68. D. Li, C. Lan, A. Manikandan, S. P. Yip, Z. Zhou, X. Liang, L. Shu, Y.-L. Chueh, N. Han, J. C. Ho, Ultra-fast photodetectors based on high-mobility indium gallium antimonide nanowires. _Nat. Commun._ **10** , 1664 (2019). 

69. X. Zhou, X. Hu, B. Jin, J. Yu, K. Liu, H. Li, T. Zhai, Highly anisotropic GeSe nanosheets for phototransistors with ultrahigh photoresponsivity. _Adv. Sci._ **5** , 1800478 (2018). 

70. M. Huang, M. Wang, C. Chen, Z. Ma, X. Li, J. Han, Y. Wu, Broadband black-phosphorus photodetectors with high responsivity. _Adv. Mater._ **28** , 3481–3485 (2016). 

71. F. Xia, T. Mueller, Y.-m. Lin, A. Valdes-Garcia, P. Avouris, Ultrafast graphene photodetector. _Nat. Nanotechnol._ **4** , 839–843 (2009). 

72. D. Kufer, G. Konstantatos, Highly sensitive, encapsulated MoS2 photodetector with gate controllable gain and speed. _Nano Lett._ **15** , 7307–7313 (2015). 

73. J. Lai, X. Liu, J. Ma, Q. Wang, K. Zhang, X. Ren, Y. Liu, Q. Gu, X. Zhuo, W. Lu, Y. Wu, Y. Li, J. Feng, S. Zhou, J.-H. Chen, D. Sun, Anisotropic broadband photoresponse of layered type-II Weyl semimetal MoTe2. _Adv. Mater._ **30** , 1707152 (2018). 

74. X. Yu, P. Yu, D. Wu, B. Singh, Q. Zeng, H. Lin, W. Zhou, J. Lin, K. Suenaga, Z. Liu, Q. J. Wang, Atomically thin noble metal dichalcogenide: A broadband mid-infrared semiconductor. _Nat. Commun._ **9** , 1545 (2018). 

75. L. Tong, X. Huang, P. Wang, L. Ye, M. Peng, L. An, Q. Sun, Y. Zhang, G. Yang, Z. Li, F. Zhong, F. Wang, Y. Wang, M. Motlag, W. Wu, G. J. Cheng, W. Hu, Stable mid-infrared polarization 

**Acknowledgments:** We thank M. M. Han, Z. X. Yang, and J. N. Dai for help in the discussion. **Funding:** This work was supported by the National Natural Science Foundation of China (grant nos. 61725505, 11734016, 61905266, 61904184, 61521005, 62004207, and 31900748), Fund of Shanghai Natural Science Foundation (grant nos. 19XD1404100, 20YF1455900, 19YF1454600, 18ZR1445900, and 18ZR1445800), and special grants from China Postdoctoral Science Foundation (prestation) (grant nos. 2019TQ0333 and 2019TQ0334). Fund of SITP Innovation Foundation (Grant No. CX-348). **Author contributions:** Z.W., P.W., F.W., and W.H. initiated and supervised the project. M.P. performed device fabrication, data collection, and analysis. Z.W., J.Y., and M.P. deposited Te by CVD. Y.W., P.W., and Q.L. assisted in carrying out the device fabrication and characterizations. W.J., L.Z., J.W., and J.M. assisted in the device performance measurements. Y.Y., Y.L., Z.H., and H.Y. performed part of the Raman, PL, and absorption spectrum characterization. R.X., H.G., X.G., C.S., and X.Z. completed the theoretical calculation part. J.D., C.C., F.W., W.L., and X.C. cowrote the manuscript. All authors discussed the results and commented on the manuscript. **Competing interests:** The authors declare that they no competing interests. **Data and materials availability:** All data needed to evaluate the conclusions in the paper are present in the paper and/or the Supplementary Materials. Additional data related to this paper may be requested from the authors. 

Submitted 16 November 2020 Accepted 2 March 2021 Published 16 April 2021 10.1126/sciadv.abf7358 

**Citation:** M. Peng, R. Xie, Z. Wang, P. Wang, F. Wang, H. Ge, Y. Wang, F. Zhong, P. Wu, J. Ye, Q. Li, L. Zhang, X. Ge, Y. Ye, Y. Lei, W. Jiang, Z. Hu, F. Wu, X. Zhou, J. Miao, J. Wang, H. Yan, C. Shan, J. Dai, C. Chen, X. Chen, W. Lu, W. Hu, Blackbody-sensitive room-temperature infrared photodetectors based on low-dimensional tellurium grown by chemical vapor deposition. _Sci. Adv._ **7** , eabf7358 (2021). 

Peng _et al_ ., _Sci. Adv._ 2021; **7** : eabf7358     16 April 2021 

**11 of 11** 



## **Blackbody-sensitive room-temperature infrared photodetectors based on lowdimensional tellurium grown by chemical vapor deposition** 

Meng Peng, Runzhang Xie, Zhen Wang, Peng Wang, Fang Wang, Haonan Ge, Yang Wang, Fang Zhong, Peisong Wu, Jiafu Ye, Qing Li, Lili Zhang, Xun Ge, Yan Ye, Yuchen Lei, Wei Jiang, Zhigao Hu, Feng Wu, Xiaohao Zhou, Jinshui Miao, Jianlu Wang, Hugen Yan, Chongxin Shan, Jiangnan Dai, Changqing Chen, Xiaoshuang Chen, Wei Lu, and Weida Hu 

_Sci. Adv._ **7** (16), eabf7358.  DOI: 10.1126/sciadv.abf7358 

**View the article online** https://www.science.org/doi/10.1126/sciadv.abf7358 **Permissions** https://www.science.org/help/reprints-and-permissions 

Use of this article is subject to the Terms of service 

_Science Advances_ (ISSN 2375-2548) is published by the American Association for the Advancement of Science. 1200 New York Avenue NW, Washington, DC 20005. The title _Science Advances_ is a registered trademark of AAAS. 

Copyright © 2021 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works. Distributed under a Creative Commons Attribution NonCommercial License 4.0 (CC BY-NC). 

