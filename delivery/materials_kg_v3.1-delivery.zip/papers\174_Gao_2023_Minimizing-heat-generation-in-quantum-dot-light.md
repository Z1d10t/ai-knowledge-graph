# Minimizing heat generation in quantum dot light-emitting diodes by increasing quasi-Fermi-level splitting

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Nanotechnology |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 174 |
| 作者 | Yanyuan Gao, Bo Li, Xiaonan Liu, Huai-Bin Shen, Yang Song, Jiao-Jiao Song, Zhi-Jie Yan, Xiaohan Yan et al. |
| DOI | 10.1038/s41565-023-01441-z |
| 源文件 | 074_Gao_2023_Minimizing-heat-generation-in-quantum-dot-light.pdf |

---




<!-- Start of picture text -->
Minimizing heating generation in quantum dot LEDs<br>by increasing quasi -F ermi level splitting<br>Yan Gao<br><!-- End of picture text -->

Henan University Bo Li University of Science and Technology of China Jiaonan Liu Henan University Huaibin Shen Henan University https://orcid.org/0000-0002-6425-0514 Yang Song University of Science and Technology of China Jiaojiao Song Henan University Zhijie Yan University of Science and Technology of China Xiaohan Yan University of Science and Technology of China Yihua Chong Henan University Ruyun Yao Henan University Shujie Wang Henan University Lin Song Li Henan University Fengjia Fan  (  ffj@ustc.edu.cn ) University of Science and Technology of China https://orcid.org/0000-0002-5447-6296 Zuliang Du Henan University https://orcid.org/0000-0002-9780-7593 

Posted Date: January 9th, 2023 

DOI: https://doi.org/10.21203/rs.3.rs-2435127/v1 

License:   This work is licensed under a Creative Commons Attribution 4.0 International License. Read Full License 

Additional Declarations: There is NO Competing Interest. 

Version of Record: A version of this preprint was published at Nature Nanotechnology on July 20th, 2023. See the published version at https://doi.org/10.1038/s41565-023-01441-z. 

# **Minimizing heating generation in quantum dot LEDs by increasing quasi-Fermi level splitting** 

Yan Gao<sup>1</sup> , Bo Li<sup>2</sup> , Xiaonan Liu<sup>1</sup> , Huaibin Shen<sup>1*</sup> , Yang Song<sup>2</sup> , Jiaojiao Song<sup>1</sup> , Zhijie Yan<sup>2</sup> , Xiaohan Yan<sup>2</sup> , Yihua Chong<sup>1</sup> , Ruyun Yao<sup>1</sup> , Shujie Wang<sup>1</sup> , Lin Song Li<sup>1</sup> , Fengjia 5 Fan<sup>2*</sup> , and Zuliang Du<sup>1*</sup> 

1 Key Laboratory for Special Functional Materials of Ministry of Education, National & Local Joint Engineering Research Center for High-efficiency Display and Lighting Technology, Henan University, Kaifeng 475004, China. 

2 Hefei National Laboratory for Physical Sciences at the Microscale and Department of 

10 Modern Physics, CAS Key Laboratory of Microscale Magnetic Resonance, Synergetic Innovation Center of Quantum Information and Quantum Physics, University of Science and Technology of China, Hefei 230026, China 

*e-mails: shenhuaibin@henu.edu.cn; ffj@ustc.edu.cn; zld@henu.edu.cn; 

## 15 **Abstract** 

Minimizing heat accumulation is essential to prolong quantum dot LEDs' operational lifetime. Reducing heat generation at the source is the ideal solution because quantum dot LEDs are composed of low thermal conductivity materials which limits heat dissipation. Achieving high brightness and high quantum efficiency at low driving 20 voltage are the keys to realizing this goal. In this work, we propose to enhance the brightness of quantum dot LEDs at low driving voltages by using a monolayer of large quantum dots to reduce the packing number in the emitting layer. This strategy allows us to achieve a higher charge population per quantum dot for a given number of total charges without charge leakage, enabling enhanced quasi-Fermi level splitting and 25 brightness at low driving voltage. Thanks to the minimized heat generation, these LEDs show a record high power conversion efficiency of 23% and an unprecedented T95 operation lifetime (the time for the luminance to decrease to 95% of the initial value) of more than 48,000 h at 1,000 cd m<sup>-2</sup> . The underline mechanism – enhanced quasi- 

Fermi level splitting enables high brightness at low driving voltage - was confirmed by our latest electrically excited transient absorption spectroscopy. 

## **Introduction** 

Although compared with phasing out thermal artificial light sources, light-emitting 5 diodes (LEDs) generate much less unwanted heat while providing high brightness, allowing high power conversion efficiencies and long lifespans<sup>1</sup> , overheating-induced failure and accelerated aging remain an issue in all inorganic LEDs. Therefore, bulky heat sinks are needed in applications requiring high brightness. In quantum dot (QD) LEDs, heat accumulation is even more severe because they are composed of low 10 thermal conductivity materials (i.e. polymers and nanocrystals) as the charge injection and emitting layers<sup>2-6</sup> . Interestingly, it has been realized six decades ago that while Joule heating is unavoidable<sup>7</sup> , LEDs can absorb the generated heat through the thermalization of charge carriers to higher energy states and then emitting photons. This allows zero net heat generation or even electroluminescence cooling when the driving voltages are 15 equal to or below the photon voltage<sup>1</sup> . As such, achieving high enough brightness at low driving voltages is critical to QD-LEDs, not only because it will mitigate heat generation but also because it is the route one must take toward fascinating electroluminescence cooling. 

10 

According to the extended thermal radiation theory, the photon emission intensity 20 of LED is dependent on the quasi-Fermi level splitting of the emitters<sup>8</sup> , which is determined by the state filling status, i.e. charging rates of the quantum dots. That explains why higher brightness can be achieved at higher driving voltages. However, to let QD-LEDs operate with minimized heat generation, we need to achieve high brightness at low driving voltages – this is challenging. Herein, we propose to enhance 25 the brightness of QD-LED at low driving voltages by using a monolayer of large QDs to reduce the packing number of QDs in the emitting layer. This strategy allows us to achieve a higher charge population per QD with a given number of total charges, enabling enhanced quasi-Fermi level splitting and brightness at low driving voltage. With simultaneously obtained radiative recombination current and high EQE, we 30 achieve the brightness of 1,100 cd m<sup>-2</sup> and 6,000 cd m<sup>-2</sup> at 100% and 115% bandgap 

voltages with record high PCEs of 23% and 21%, respectively. Since heat generation has been depressed, after 2 hours of continuous operation, our devices exhibit no temperature rise at 1000 cd m<sup>-2</sup> and 1℃ rise at 6,000 cd m<sup>-2</sup> , respectively, allowing unprecedented T95 operation lifetimes (the time for the luminance to decrease to 95% 5 of the initial value) of more than 48,000 h at 1,000 cd m<sup>-2</sup> . The underline mechanism – enhanced quasi-Fermi level splitting enables higher brightness at low driving voltage - was confirmed by our latest electrically excited transient absorption (EETA) spectroscopy. 

## 10 **Results and discussion** 

**Minimizing heat generation by achieving high brightness at a low driving voltage** 

It has long been realized that the driving voltage plays a key role in determining the heat generation or even electroluminescence cooling in LEDs (Figure 1a)<sup>1</sup> . We performed a thermal simulation to investigate the impact of brightness and driving 15 voltage on the temperature of LEDs (Figure 1a, see methods for more details) assuming 100% internal quantum efficiency and all photons escape from the emitting area. When the driving voltage is below the photon voltage, QDs need additional energy from phonon to populate the charge carriers to higher energy states<sup>9,10</sup> , leading to cooling rather than heating in LEDs<sup>11</sup> . For a given current, the lower the voltage, the larger the 20 cooling power. When the driving voltage is equal to the photon bandgap voltage, the devices can operate under heating-free conditions regardless of brightness. When the driving voltage is above the bandgap voltage, the devices start to heat up, lower the voltage can mitigate heat generation. The conclusion is clear – achieving high enough brightness at low driving voltages is the key to minimizing heat generation. 

25 

Now we discuss how to achieve high brightness at low driving voltages. According to the extended thermal radiation theory (Figure 1b), the emission intensity of LED is dependent on the quasi-Fermi level splitting of the emitter, the larger the quasi-Fermi splitting, the stronger emission<sup>8</sup> . This explains why does the brightness of LED increase with increasing voltage. In QD-LEDs, the quasi-Fermi level splitting is directly related 

to the charging rate of each QD. The more QDs get charged, the larger Fermi level splitting will be. Given that spreading a given total number of electrons and holes into fewer QDs can increase the charge population per QDs, we propose to use monolayer large QDs to reduce the packing density. We expect it can help us to increase charging 5 rates (i.e. large quasi-Fermi splitting) and therefore achieve high brightness at low driving voltages (Figure 1b). 

Figure 1c provides a more intuitive elaboration of the above abstract theory. For a given hexagonal active emitting area that can enable us to pack, for example, 12 QDs into a monolayer. If we consequently inject an electron and hole, we have a chance of 1 10 to generate an exciton if the effect of exciton binding energy is not considered. If 12 we increase the size of the QDs by 2 times while keeping the monolayer structure (Figure 1), now only 3 QDs can be packed within the same active emitting area. The 1 1 electron population per QD will be increased from to , and the chance for the 12 3 1 injected hole to meet the preexisting electron is increased to , and therefore the 3 

15 radiative recombination is accelerated. 



<!-- Start of picture text -->
a b<br>IQE=100% T (°C)<br>+ T CB<br>E Fe<br>EFe<br>L-V curve 1<br>0<br>hv hv<br>L-V curve 2 EFh EFh<br>VB<br>- T<br>V<Vbandgap Vbandgap V>Vbandgap<br>Voltage (V)<br>c<br>pe=1/12 pe=1/3<br>ph=1/12 pexciton= 121 121  12 ph=1/3 pexciton= 31  31  3<br>-2Luminance (cd m)<br><!-- End of picture text -->

**Figure 1| Mitigating heat generation in QD-LED by achieving high brightness at** 

**low driving voltages.** a, the schematic about the influence of brightness and driving voltage on the temperature of LED. Two LEDs with different luminance ( _L_ ) and voltage ( _V_ ) curves (i.e. one device achieves higher brightness over the other one for a given voltage) are provided for comparison. b, the dependence of brightness on quasi-Fermi 5 level splitting in LED. c, The effect of QD size on electron-hole recombination probability. Schematic to illustrate the exciton formation probabilities in QD-LEDs using large and regular QDs when the injection probabilities per unit area for electrons and holes are the same, respectively. A small area that can pack 12 regular QDs is selected here for illustration. 

10 **Experimental demonstration of achieving high brightness at low driving voltages** 

From the above discussion, we concluded that by using monolayer large QDs, the recombination current could, in principle, be enhanced. However, in previous research, synthesis of large QD with close to unity quantum yield is challenging, this is the case for both CdSe-CdS and CdSe-CdZnSe-based core-shell QDs<sup>12,13</sup> . It has been generally 15 observed that the PL QY decreases with increasing the size once it is over ~ 15 nm<sup>14,15</sup> , which is believed to be due to accumulated compressive strain. Growing alloy intermediate shells between the core and outer shell has been adopted to mitigate the interface strain<sup>15,16</sup> . But complete strain relief requires the growth of multiple shells with small incremental composition change<sup>17</sup> , which may pose challenges for mass 20 production and impact the reproducibility of device fabrication. 

20 

To address this issue, we adopted a different strategy to synthesize large QDs, rather than grow multiple layers of thick shells on small cores, we opt to grow large QDs without a nominal core-shell interface (Figure 2a). These QDs were synthesized in a single vessel with two injections of anion precursors: after the first injection of Se 25 precursor, large QDs with an average size of 17 nm are obtained, and after the injection of S precursor, an additional ZnS-rich protective layer is formed. Since no intermediate purification step is required, the synthesis process is greatly simplified, which is beneficial in terms of improving reproducibility and decreasing difficulty in mass production. To maintain quantum confinement in such large QDs, the relative ratio of 

Cd and Zn cation was gradually varied, which is achieved by taking the advantage of higher reactivity of Cd over Zn precursors when reacting with the selenium precursors. This strategy enables us to synthesize a fully composition-graded (FCG) quantum dot with over 95% PL QY (Supplementary Fig.1). We performed high-angle annular dark5 field scanning transmission electron microscopy (HAADF-STEM) element mapping to characterize the composition distribution and found that the Cd cation distributes over 15 nm inside each QD (Figure 2b and Supplementary Fig.1), accounting for about 60 % of the total size. And the element line scanning characterization of Zn/Cd atom ratio changes slowly along the radius, suggesting the interfaces are smoothened and strain 10 can be relieved efficiently. 



<!-- Start of picture text -->
a One-pot two-injection synthesis b<br> Z n         C d<br>Core  + Protective shell<br>0 10 20 30 40<br>Position (nm)<br>c d<br>e f 10 3 g<br>1ML regular QD<br>10 2 2 0<br>EL= 645nm<br>X100 2 V 10 1 1 0<br>350 400 450 500<br>10 0<br>0<br>3MLs regular QD 10 - 1 1ML large QD 1ML large QD<br>1ML regular QD 1ML regular QD<br>X100 2 V EL= 645nm 10 - 2 2 3 3MLs regular QD 4 -1 0 2 3  3MLs re g ular QD4<br>350 400 450 500 Voltage (V) Volta g e  ( V )<br>h 6 i 6<br>1ML large FCG-QD 5 5<br>EL= 644nm 4 4<br>X100 2 V<br>350 400 450 500 3 3<br>1ML large QD 1ML large QD<br>2 1ML regular QD 2 1ML regular QD<br>400 500 600 700 800 3MLs re g ular  Q D 3MLs re g ular  Q D<br>0 2×10 4 4×10 4 6×10 4 8×10 4 1×10 5 0 2×10 4 4×10 4 6×10 4 8×10 4 1×10 5<br>Wavelength (nm) Luminance (cd m -2 ) Luminance (cd m -2 )<br>Normalized EL Intensity(a.u.)<br>-2Current densitymA cm()<br>Voltage (V) Voltage (V)<br>EQE (%)<br>Intensity (a.u.)<br><!-- End of picture text -->

**Figure 2| Characterizations of QD-LEDs. a** Schematic of conventional and our large FCG-QDs synthesis. **b** , Scanning transmission electron microscopy (STEM) image of QDs. Energy dispersive spectroscopy (EDS) elemental mapping of Cd, Zn several 15 CdSe/CdZnSe/ZnS core/shell QDs (Supplementary Fig. 1e-g). **c** , schematic of QD- 

LED structure. **d** , Sectional transmission electron microscopy (TEM) images of LEDs using large FCG-, and regular QDs, and scanning electron microscopy (SEM) images of QD on the hole transport layer (HTL). **e** , Similar emission peak positions are observed in electroluminescence (EL) spectra of QD-LEDs using QDs with average 5 sizes of 10 and 18.4 nm. Insets show 100 times zoomed-in views of EL spectra from HTL. In QD-LED using monolayer regular QDs (10 nm in size with QY over 95%, Supplementary Fig. 2), noticeable EL from HTL is observed, but it is efficiently eliminated when large QDs (18.4 nm in size) and three monolayers of regular QDs are used instead. **f** , the current-voltage curves of QD-LEDs. Below the turn-on voltage, the 10 current leakage is efficiently depressed in LEDs using large QDs, but conversely, irradiative recombination current above the turn-on voltage is remarkably enhanced. **g** , the EQE of QD-LED using large QD is on par with that of the state-of-the-art QD-LEDs employing multiple QD layers, while the EQE in QD-LED using monolayer regular QD is much lower, increasing the thickness of regular QD can remarkably improve the 15 EQE but at the expense of reduced overall current (Figure 2e). The dependence of bias voltage ( **h** ) and PCE ( **i** ) on the luminance of QD-LEDs using large FCG- and regular QDs, respectively. 

We then use above mentioned FCG-QDs to fabricate bottom emitting LEDs with a simple solution-processed multilayered organic-inorganic hybrid architecture<sup>5,18</sup> 20 (Figure 2c and d, see Methods for more details). Analysis of the current-voltage characteristic curve below the turn-on voltage and EL spectra above reveals noticeable current leakages (Figures 2e and f, Supplementary Fig. 3) in LEDs using monolayer regular QDs. As result, moderate EQEs up to 14.5% (peaking at ~2.5 V) are obtained despite the over 95% PL QY of regular QDs (Figure 2g). We thus increased the 25 thickness of the regular QD layer and observed depressed current leakage and EL of HTL. A much higher peak EQE of 20.3% (at ~2.6 V) is achieved, but the injection resistance is also increased so that the overall current is reduced (Figure 2f). Contrastingly, with a monolayer QD packing, the peak EQE of large FCG-QD-LED reaches 23.8% at 2 V (Figure 2g), close to the out-coupling efficiency limit we 30 calculated (~24.4%)<sup>19</sup> (see Method, outcoupling efficiency simulation, Supplementary 

Table 1 and Supplementary Fig. 4), suggesting an over 95% internal quantum efficiency (IQE). 

Regarding the difference in EQE, Auger recombination is first excluded as the dominant factor here, because the current density is relatively low at low voltage, and 5 high photoexcitation intensity PL decay measurements reveal that large FCG and regular QDs show similar multi-exciton lifetimes (Supplementary Fig. 5). The absence of HTL EL at various voltages (Supplementary Fig. 3) indicating current leakage has been effectively depressed. We attribute this to the fact that HTL and ETL are more spaced out in QD-LED using monolayer large FCG-QDs. 

10 In contrast to the depressed current leakage below 1.9 V, the overall current above turn-on voltage is dramatically increased, which is up to 8 times compared with LEDs using monolayer regular QDs (Figure 2f). Given the EQEs are high, the current is mainly contributed by radiative recombination. Regarding the underline mechanism for the increased current at low voltage, previous studies have found that the hole injection 15 barrier plays an important role<sup>5,6,20</sup> . To investigate whether our QD-LEDs using large QDs benefit from improved hole injections, we performed ultraviolet photoemission spectroscopy (UPS) and single-carrier conductance measurements (Supplementary Fig. 6, Supplementary Fig. 7). The valence band levels are quite close to each other in regular and large FCG-QDs, and hole injection currents in large FCG-QD are smaller 20 below 1.5 V but resemble that of regular QD at higher voltages. Therefore, we conclude that increased recombination currents stem from different recombination dynamics rather than reduced hole injection barriers. 

10 

15 

High EQE and large irradiative recombination current have been simultaneously achieved in our QD-LED using monolayer large FCG-QDs, enabling us to achieve the 25 brightness of 1,100 and 6000 cd m<sup>-2</sup> at the 100% and 115% bandgap voltages (Figure 2h), respectively. In contrast, our QD-LEDs using monolayer and three layers of regular QD show much lower brightness at both the 100% and 115% bandgap voltages, ranging from 10 to 400 cd m<sup>-2</sup> (Figure 2h). In previously reported high-performance QD-LEDs, brightness of 10 - 250 cd m<sup>-2</sup> can be obtained at the bandgap voltages (Supplementary 30 Table 2), and to achieve a brightness of 6000 cd m<sup>-2</sup> these devices need to be operated 

at more than 125% bandgap voltage<sup>3,4,20-24</sup> . Due to the decreased driving voltage, the PCEs of QD-LEDs using large FCG-QDs have also been remarkably improved. They can retain PCEs of 21-23% (Figure 2i) - the highest values to the best of our knowledge - at brightness ranging from 1,000-6,000 cd m<sup>-2</sup> (Supplementary Table 2, 5 Supplementary Table 3). 

## **Electron quasi-Fermi level splitting measurements using electrically excited transient absorption (EETA) spectroscopy** 



<!-- Start of picture text -->
a<br>b c<br>70 0 0.5 10 6 0. 5 1ML large FCG-QD<br>0. 4 1ML regular QD<br>60 0 0.0 10 5 0. 3 3ML regular QD<br>50 0 1ML re g ular QD 0. 2<br>70 0 10 4 0. 1<br>60 0 -0.5 0. 0 2.0 2.2 2.4 2.6 2.8 3.0<br>50 0 3ML re g ular QD 10 3 Voltage (V)<br>70 0 -1.0 1 ML large FCG-QD<br>10 2<br>60 0 1 ML regular QD<br> 3 MLs regular QD<br>50 0 1ML large FCG - QD -1.5 10 1<br>2.0 2.2 2.4 2.6 2.8 3.0 0.84 0.86 0.88 0.90 0.92<br>Voltage (V) EFe (eV)<br>Wavelength (nm) 3 OD)A (10<br>-2Luminance (cd m)<br><N><br><!-- End of picture text -->

**Figure 3| The electron quasi-Fermi level splitting measurements by EETA** 

- 10 **spectroscopy. a** , Schematic diagram of the experimental setup. LEDs are driven by 1 kHz electrical current pulses, and a pulsed supercontinuum white laser beam (2 kHz) is separated by a beam splitter: one beam is shined on LEDs to detect the change in transmission; the other one is used as a reference signal to eliminate the intensify fluctuation of supercontinuum laser. The time delay between the electrical current and 

- 15 laser pulse is controlled by an electronic time delay module. **b** , The EETA spectra under biases of 2-3 V for 1 ML large FCG-, 1 ML and 3MLs regular QD-LEDs, respectively, 

the electrical pulse duration and the time delay are set to be 10 and 5 microseconds, respectively. **c** , Average electron populations < 𝑁>𝐸  in operating LEDs were calculated by comparing the amplitude of bleach signal with that obtained under photoexcitation (see methods for more details), and electron quasi-Fermi level splitting 5 was calculated based on < 𝑁>𝐸 (see methods for more detail). Under a given bias voltage, LEDs using monolayer large FCG-QDs show larger < 𝑁>𝐸 and therefore larger quasi-Fermi level splitting than those using one and three monolayers regular QDs (0.23 vs. 0.01 and 0.0125 at 2 V). 

To experimentally verify whether the electron population per quantum dot has 10 indeed been increased, we developed an electrically excited pump-probe transient absorption spectroscopy to in-situ measure the charge concentration in the operating QD-LEDs (Figure 3a). The main difference between this technique and conventional optically excited transient absorption is that we use an electrical pulse to excite the QD rather than a pulsed laser (See Method for details), which allows us to in-situ monitor 15 the charge carriers. Figure 3b shows the difference in absorbance ∆𝐴 of QD-LEDs using large FCG and regular QDs above the bandgap voltage. The changes in absorption are attributed to the stark effect and the bleach signal, which can be separated through fitting (See Method for more details, Supplementary Fig. 8). We found that the stark effects are negligible in devices using 1 ML large FCG or and regular QD, and therefore 20 the signal is mainly derived from the bleach. In II-VI QDs, since the hole degeneracy is much higher than that of the electron, the bleach signal is mainly contributed by the electron<sup>25</sup> . To get the correlation between the charge concentration with bleach signal magnitude. We further performed the photoexcited nanosecond transient absorption spectrum (ns TA) (Supplementary Fig.9a, b). By measuring the absorption cross25 section and calculating the average electron population at various excitation powers (Supplementary Fig.10, see the method for detail), we get the function between the ∆𝛼 curve and the average electron population < 𝑁> (Figure 3c, Supplementary Fig.9c, d). By comparing the bleach signals from photoexcitation and electrical excitation, we can quantify the average electron population < 𝑁>𝐸 from ∆𝐴 we get. 

10 

We find that < 𝑁>𝐸 at 2 to 3 V are quite small (10<sup>-3</sup> -10<sup>-2</sup> ) in devices using 

30 

regular QDs, while in large FCG-QDs the values increase from 0.23 to 0.34 within the same driving voltage range. We further calculated the electron quasi-Fermi level (see methods for more details) according to the < 𝑁>𝐸. In our QD-LED, since the electron injection is more efficient than that of the holes(Supplementary Fig.7c), and the hole 5 degeneracy is much heavier, the hole quasi-Fermi level splitting is much smaller than that of the electron, and therefore it is neglected in our discussion. The result obtained here qualitatively confirms our hypothesis that < 𝑁>𝐸 and quasi-Fermi level splitting of large FCG-QD is larger than that of the regular QDs. As a result, the probability of injecting a hole into a QD with a preexisting electron is higher, namely, 10 higher brightness can be obtained with a given driving voltage. 

## **Temperature measurements at different brightness** 



<!-- Start of picture text -->
a 0 cd m -2 1,000 cd m -2 2,000 cd m -2 3,000 cd m -2 4,000 cd m -2 5,000 cd m -2 6,000 cd m -2<br>a 45<br>20.3  20.3 °°CC 20.3 °C 20.4 °C 20.6 °C 20.6 °C 21.0 °C 21.3 °C<br>40<br>35<br>20.3 20.3 °C°C 22.1 °C 25.1 °C 28.3 °C 33.5 °C 37.1 °C 40.2 °C<br>30<br>25<br>20.2 20.3 °°CC 20.8 °C 21.8 °C 23.1 °C 24.2 °C 27.1 °C 29.2 °C<br>20<br>b c<br>200 0 1ML   large FCG-QD    4 0  s imulation<br>1ML   regular QD   measurement<br>160 0<br>  3MLs re g ular QD 3 6<br>10 0<br>120 0 8 0 3 2<br>6 0 RT= 20.3 °C<br>80 0 4 0 2 8<br>2 0<br>40 0 0 2 4<br>1×10 3 2×10 3 3×10 3 4×10 3 5×10 3 6×10 3<br>Luminance (cd m -2 )<br>2 0<br>0<br>10 1 10 2 10 3 10 4 10 5 0 1 2 3 4 5 6<br>Luminance (cd m -2 )  Luminance (x10 3  cd m -2 )<br>1ML large FCG-QD<br>3MLs regular QD<br>1ML regular QD<br>-2Heat generation (mW cm)<br>-2Heat generation (mW cm)<br>Temperature after 2 hours operation (C)°<br>Surface Temperature (°C)<br>1ML large FCG-QD<br>1ML regular QD<br>3MLs regular QD<br><!-- End of picture text -->

**Figure 4| Device temperature at different brightness.** a, the temperature of QD- 

- 15 LEDs after 2 hours of continuous operation at room temperature (20.3℃) measured by infrared thermography. b, the calculated heat generations in different LEDs at various 

brightness. c, a summary of the experimental and simulated device temperature at different brightness, the device temperature simulation was performed using COMSOL (see methods for more details). 

To investigate the effect of decreased driving voltage and increased EQE on the 5 heat generation in QD-LEDs, we measured the device temperature using infrared thermography (Figure 4a, see methods for more details). After being continuously operated for 2 hours at room temperature, there is no observable temperature rise in LEDs using large FCG-QDs at the brightness of 1000 cd m<sup>-2</sup> , while the temperature rises 0.8 and 0.5℃ in 1ML and 3ML regular QD-LEDs, respectively. At a high 10 brightness of 6,000 cd m<sup>-2</sup> , the device temperature increases by only 1℃ in large FCGQD-LEDs, in contrast to 8.9 and 9.9 ℃ rises in 1ML and 3ML regular QD-LEDs. By modeling the theoretical photon outcoupling efficiency (see Methods for detailed transfer matrix method calculations, Supplementary Table 1 and Supplementary Fig. 4), we then calculate the heating powers in QD-LEDs (Figure 4b) and perform thermal 15 simulation using COMSOL to get the theoretical device temperature, which agrees well with the experimental results (Figure 4c). 

## **Device stability tests** 

Regarding the stability of the QD-LEDs, electrochemical instabilities of ligand and HTL have been identified as the possible origins of device degradation<sup>26-28</sup> . From 20 a chemical dynamic point of view, those electrochemical reactions that account for device degradation can be accelerated at alleviated driving voltage and temperatures. That is to say, regardless of the exact chemical mechanism, lowering the driving voltage and reducing heat generation in QD-LED simultaneously can, in theory, mitigate the aging process of QD-LED. Recently, it has been reported that the lifetimes of QLEDs 25 can be remarkably improved by improving heat dissipation using sapphire and silicon as substrates<sup>18,29</sup> , however, the driving voltages were not efficiently reduced therefore these devices still suffered from the low power conversion efficiencies. In this work, we propose to address this issue by depressing driving voltage and improving the power conversion efficiency to mitigate heating-induced accelerated aging. 

We then turned to verify whether the reduced driving voltage and improved PCE could enable better device stability. Our testing results reveal that the QD-LED using monolayer and three layers of regular QD show T95 lifetimes of ~ 48 h at 10,433 cd m<sup>−2</sup> and ~ 57 h at 10,041 cd m<sup>−2</sup> , respectively (Figure 5a). Fitting the lifetimes at different 5 brightness with an empirical equation (L0)<sup>n</sup> × T95 = constant<sup>30</sup> (L0 is the initial brightness), we obtained acceleration factors of n≈1.74 (Supplementary Fig. 11a). The T95 operational lifetimes at an initial brightness of 1,000 cd m<sup>−2</sup> are then estimated to be around 2,500 h in monolayer regular QD-LED, the values are 3100 h in three monolayer regular QD-LEDs. The obtained T95 lifetime is already comparable to those 10 of high-performance QD-LEDs reported so far (Supplementary Table 4). Thanks to the reduced driving voltage and unprecedented PCE, QD-LEDs using large FCG-QDs show impressive T95 lifetimes of ~780 h operated at 11,249 cd m<sup>−2</sup> (Figure 5a). With an acceleration factor of n≈1.71 (Supplementary Fig. 11b), the T95 operational lifetimes at an initial brightness of 1,000 cd m<sup>−2</sup> are estimated to be more than 48,000 h, making 15 this device the best-performing solution-processed LED so far (Supplementary Table 4). It is worth noting that the obtained long lifetime here has already surpassed the industrial requirement<sup>22</sup> . Histograms of the lifetimes from more than 24 large FCG-QDLEDs in Figure 3f exhibit T95 lifetimes with an initial luminance of 1,000 cd m<sup>−2</sup> ranging from 39,000 to 48,000 h with a mean of ~43,000 h, suggesting the high device 20 fabrication reproducibility. 



<!-- Start of picture text -->
a b<br>2 5 1 0<br>1ML   large FCG-QD<br>1ML   regular QD<br>1.0×10 4 2 0 8<br>3MLs regular QD<br>J=60.0 mA cm-2; L0=11,249 cd m-2<br>J=64.4 mA cm-2; L0=10,433 cd m-2 1 5 6<br>J=95.2 mA cm-2; L0=10,041 cd m-2<br>5.0×10 3 1 ML   large FCG-QD 1 0 4<br>1 ML   regular QD<br>3 MLs regular QD 2<br>5<br>0. 0 0<br>0 200 400 600 800 2 3 4 40 45 50<br>Time (h) Time (×103 h)<br>Figure 5| Device stability tests.  T95 operational lifetime tests of QD-LED using<br>monolayer and three layers of large FCG and monolayer regular QDs, respectively. The<br>Voltage (V)<br>-2Luminance (cd m) Number of device<br><!-- End of picture text -->

tests were performed under ambient conditions (temperature, 20-25 °C; relative humidity, 30–50%). **f** , Histogram of estimated T95 lifetimes with an initial luminance of 1,000 cd m<sup>−2</sup> from 24, 29, and 19 QD-LEDs using monolayer large FCG-QD, monolayer, and three layers of regular QD, respectively. 

## 5 **Conclusions** 

To minimize heat generation in QD-LEDs, we proposed to enhance the brightness of QD-LED at low driving voltage by increasing the electron population per QD. We implemented this concept by using monolayers of large FCG-QDs, which enables us to simultaneously increase the injection current and retain high EQE in QD-LEDs. We 10 achieved unprecedented high PCEs of 21-23% at brightness ranging from 1000 to 6000 cd cm<sup>-2</sup> in red-emitting LEDs, allowing us to mitigate heat generation and improved T95 life - 48,000 h at a luminance of 1,000 cd m<sup>-2</sup> . The underline mechanism – enhanced quasi-Fermi level splitting enables high brightness at low driving voltage - was confirmed by our latest EETA spectroscopy. We believe developing protocols for 15 synthesizing large QDs with high quantum efficiency as active emitters could be an important strategy to decrease the driving voltage of QD-LEDs and prolong the device operational lifetime. 

## **Reference** 

20 

1. Sadi, T., Radevici, I. & Oksanen, J., Thermophotonic cooling with light-emitting diodes. _Nat. Photon._ **14** , 205-214 (2020). 

25 

2. Ong, W.-L., Rupich, S. M., Talapin, D. V., McGaughey, A. J. H. & Malen, J. A. Surface chemistry mediates thermal transport in three-dimensional nanocrystal arrays, _Nat. Mater._ , **12** , 410-415, (2013). 

3. Dai, X. et al _._ Solution-processed, high-performance light-emitting diodes based on quantum dots. _Nature_ **515** , 96-99 (2014). 

4. Li, X. et al _._ Bright colloidal quantum dot light-emitting diodes enabled by efficient chlorination. _Nat. Photon._ **12** , 159-164 (2018). 

   5. Shen, H. et al. Visible quantum dot light-emitting diodes with simultaneous high brightness and efficiency. _Nat. Photon._ **13** , 192-197 (2019). 

   6. Deng Y.et al. Solution-processed green and blue quantum-dot light-emitting diodes with eliminated charge leakage. _Nat. Photon._ **16** , 505-511 (2022). 

- 5 7. J. Tauc, The share of thermal energy taken from the surroundings in the electroluminescent energy radiated from ap-n junction. _Cechoslovackij fiziceskij zurnal_ **7** , 275-276 (1957). 

   8. P. Wurfel, The Chemical-Potential of Radiation. _J. Phys. C: Solid State Phy._ **15** , 3967-3985 (1982). 

- 10 9. Su Q. & Chen S. M. Thermal assisted up-conversion electroluminescence in quantum dot light emitting diodes. _Nat. Commun._ **13,** 369 (2022). 

   10. Lin X. et al. Xingliang Dai, Zikang Ye, Yufei Shu, Zixuan Song & Xiaogang Peng Highly-efficient thermoelectric-driven light-emitting diodes based on colloidal quantum dots, Nano Research 15, 9402-9409 (2022). 

- 15 11. Li N. et al. Ultra-low-power sub-photon-voltage high-efficiency light-emitting diodes. _Nat. Photon._ **13** , 588-592 (2019). 

   12. Pal, B.N. et al. Giant’ CdSe/CdS Core/Shell Nanocrystal Quantum Dots As Efficient Electroluminescent Materials: Strong Influence of Shell Thickness on LightEmitting Diode Performance _Nano Lett._ **12,** 331−336 (2012) 

- 20 13. Park, Y. S., Lim.J., Klimov, V. I. Asymmetrically strained quantum dots with nonfluctuating single-dot emission spectra and subthermal room-temperature linewidths _Nat Mater._ **18,** 249–255, (2019). 

14. Qin, H. Y. et al. Single-Dot spectroscopy of zinc-blende CdSe/CdS core/shell nanocrystals: nonblinking and correlation with ensemble measurements. _J. Am._ 

25 _Chem. Soc._ **136** , 179-187 (2014). 

   15. Lim, J., Park, Y.-S. & Klimov, V. I. Optical gain in colloidal quantum dots achieved with direct-current electrical pumping. _Nat. Mater._ **17** , 42-49 (2018). 

   16. Lim, J., Park, Y. S., Wu, K. F., Yun, H. J. & Klimov, V. I. Droop-free colloidal quantum dot light-emitting diodes. _Nano Lett._ **18** , 6645-6653 (2018). 

- 30 17. Lee, T. et al. Bright and Stable Quantum Dot Light-Emitting Diodes. _Adv. Mater._ 

**34** , 202106276 (2021). 

   18. Qian, L., Zheng, Y., Xue, J. & Holloway, P. H. Stable and efficient quantum-dot light-emitting diodes based on solution-processed multilayer structures. _Nature Photon._ **5,** 543–548 (2011). 

- 5 19. Neyts, K. A. Simulation of light emission from thin-film microcavities. _J. Opt. Soc. Am. A_ **15** , 962-971 (1998). 

   20. Yang, Y. et al. High-efficiency light-emitting devices based on quantum dots with tailored nanostructures. _Nat. Photon._ **9** , 259-266 (2015). 

- 10 

   21. Mashford, B. S. et al. High-efficiency quantum-dot light-emitting devices with enhanced charge injection. _Nat. Photon._ **7** , 407-412 (2013). 

   22. Cao, W. et al. Highly stable QLEDs with improved hole injection via quantum dot structure tailoring. _Nat. Commun._ **9** , 2608 (2018). 

- 15 

   23. Lin, J. et al. High-performance quantum-dot light-emitting diodes using NiOX holeinjection layers with a high and stable work function. _Adv. Funct. Mater._ **30** , 201907265 (2020). 

   24. Liu, D. et al. Highly stable red quantum dot light-emitting diodes with long T95 operation lifetimes. _J. Phys. Chem. Lett._ **11** , 3111-3115 (2020). 

- 20 

   25. Efros, A. L. et al. Band-edge exciton in quantum dots of semiconductors with a degenerate valence band: dark and bright exciton states. _Phys. Rev. B_ **54** , 4843-4856 (1996). 

   26. Pu, C. et al. Electrochemically-stable ligands bridge the photoluminescenceelectroluminescence gap of quantum dots. _Nat. Commun._ **11** , 937 (2020). 

   27. Chen, S.,et al. On the degradation mechanisms of quantum-dot light-emitting diodes. _Nat. Commun._ **10** , 765 (2019). 

- 25 28. Sun, Y., et al. Investigation on thermally induced efficiency roll-off: towards efficient and ultra-bright quantum-dot light-emitting diodes. _ACS Nano_ **13** , 1143311442 (2019). 

- 30 

29. Sun, Y., Su, Q., Zhang, H., Wang, F. & Chen, S. Investigation on thermally induced efficiency roll-off: towards efficient and ultra-bright quantum-dot light-emitting diodes. _ACS Nano_ **13** , 11433-11442 (2019). 

30. Scholz, S., Kondakov, D., Lüssem, B. & Leo, K. Degradation mechanisms and reactions in organic light-emitting devices. _Chem. Rev._ **115** , 8449-8503 (2015). 

## **Acknowledgements** 

5 We gratefully acknowledge the financial support from the National Natural Science Foundation of China (grant numbers U22A2072, 52272167, 62234006, 81788101, 11761131011, 51872275), the National Key R&D Program of China (Grant No. 2018YFA0306600), Chinese Academy of Sciences (Grants No. XDC07000000, No. GJJSTD20200001, No. QYZDY-SSW-SLH004) and Anhui Initiative in Quantum 10 Information Technologies (Grant No. AHY050000). 

## **Author contributions** 

H.B.S and F.J.F. conceived the concept and designed the experiments. H.B.S., F.J.F and Z.L.D. supervised the project. Y.G, B.L and X.N.L contributed equally. Y.G, X.N.L and J.J.S synthesized the materials, fabricated the devices and collected the 15 performance data of the QLEDs. B.L and Y.S developed the thermal simulation model and the electrical excitation transient absorption measurement. F.J.F, H.B.S and B.L wrote the manuscript. All authors contributed to the scientific discussion and modifying the manuscript. 

## **Competing interests** 

- 20 The authors declare no competing interests 

## **Additional information** 

25 

**Supplementary information** is available for this paper at xxxxxx. **Reprints and permissions information** is available at www.nature.com/reprints. **Correspondence and requests for materials** should be addressed to H.B.S., F.J.F and Z.L.D. 

**Publisher’s note:** Springer Nature remains neutral with regard to jurisdictional claims in 

published maps and institutional affiliations. 

## **Methods** 

**Materials.** Cadmium oxide (CdO, 99.99%), zinc oxide (ZnO, 99.9% powder), sulfur (S, 99.998%, powder), 1-octadecene (ODE, 90%), oleic acid (OA, 90%), trioctylphosphine (TOP,97%), selenium (Se, 99.99%, powder), 1-octanethiol (OT, 5 98%), chlorobenzene (99%), zinc acetate dehydrate (98%) as well as various solvents were purchased from Aldrich and Adamas-beta. dimethyl sulphoxide (DMSO, HPLC grade) were purchased from J&K Chemical Ltd. poly(9,9-dioctylfluorene-co-N-(4-(3methylpropyl))-diphenylamine) (TFB) was purchased from American Dye Source. poly (ethylenedioxythiophene): polystyrene sulphonate poly (ethylenedioxythiophene): 10 polystyrene sulphonate was purchased from Heraeus Deutschland GmbH & Co.KG. All materials were used as received. 

**Preparation of the precursors:** Zinc oleate (Zn(OA)2) precursor: a mixture of ZnO 60 mmol, OA (60 mL), and ODE (90 mL) was loaded into a 250 mL three-neck flask. The mixture was then degassed at 150 °C for 15 min. Finally, the solution was heated to 15 310 °C under nitrogen with vigorous stirring to get a colorless clear solution. Solution for Se precursor: it was made by degassing Se (1.578 g, 20 mmol), 40 mL of TOP in a 100 mL three-necked flask, then it was heated to 150 °C until the solution turn into transparent. Solution for S precursor: it was made by degassing S (0.64 g, 20 mmol), 40 mL of TOP in a 100 mL three-necked flask, then it was heated to 150 °C until the 20 solution turn into transparent. 

## **Synthesis of large full gradient (CdSe/CdZnSe/ZnS) QDs:** 

Red CdSe/CdZnSe/ZnS core/shell QDs were prepared by mixing 1.6 mmol CdO, 4 mmol Zn(OAC)2, and 9 mL OA in a 100ml flask, which is heated to 150 °C in flowing high-purity argon for 30min. Then, 20 ml of ODE was added to the flask and the 25 temperature was elevated to 305 °C. At this temperature, 8 mL of Se precursor was swiftly injected into the reaction flack. The reaction temperature was kept at 305 °C for 30 min for the core growth. For the consecutive overcoating of the ZnS shell, 5 mL of Zn(OA)2 and octanethiol (2.8 mmol, 1.4 equivalent amount refers to Zn(OA)2) were added dropwise into the reaction solution at a rate of 5 mL h<sup>−1</sup> using a syringe pump. 30 Once the reaction was completed, the temperature was brought down to room 

temperature. 

**For a typical synthesis of regular** ( **CdSe/CdZnSe/ZnS** ) **QDs:** 0.5 mmol of CdO, 5 mmol of zinc acetate, and 6 ml of oleic acid were placed in a 50mL flask and heated to 180 °C in flowing high-purity argon for 30 min. Then, 12 mL of 1-octadecene was 5 added to the flask and the temperature was elevated to 300 °C. At this temperature, 2 mL of Se precursor was swiftly injected into the reaction flack. The reaction temperature was kept at 305 °C for 30 min for the core growth. Then 3 mL of Zn(OA)2 and octanethiol (1.68 mmol, 1.4 equivalent amount refers to Zn(OA)2) were added dropwise into the reaction solution at a rate of 5 mL h<sup>−1</sup> using a syringe pump. Finally, 10 the reaction mixture was cooled to room temperature. QDs were purified six times by following a centrifugation precipitation/dispersion method using a mixed solvent of hexane/ ethanol (1/1 in volume ratio). Finally, the purified QDs were redispersed into hexane or chloroform for optical characterization, post-treatments, and the preparation of QD films. 

10 

15 **Fabrication of QD-LEDs:** The devices are composed of glass substrate (0.4 mm), indium tin oxide (ITO, 75 nm), PEDOT:PSS (35 nm), TFB (25 nm), core/shell QDs (18 nm), ZnO nanoparticles (NPs, 55 nm), and aluminum (Al, 100 nm) layers. ZnO NPs were synthesized by a solution-precipitation process using Zn acetate and TMAH<sup>18</sup> . For a typical synthesis, a solution of zinc acetate in DMSO (0.5 m) and 30 mL of TMAH 20 in ethanol (0.55 m) were mixed and stirred for 1 h in ambient air. Then ZnO NPs were washed and dispersed in ethanol. QD-LEDs were fabricated on glass substrates coated with ITO with a sheet resistance of ≈15 Ω sq<sup>−1</sup> . The substrates were cleaned with deionized water, acetone, and isopropanol, consecutively for 15 min each. These substrates were spin-coated with PEDOT:PSS (AI 4083) and baked at 150 °C for 15 25 min in air. The coated substrates were transferred to a N2-filled glove box for spincoating of TFB, QDs, and ZnO NPs. As hole transport layer, TFB were spin-coated using 1.5 wt% in chlorobenzene (2000 rpm for 30 s), followed by baking at 110 °C for 30 min. Then, it was spin-coated by QDs (15 mg mL−1, in octane) and ZnO NPs (45 mg mL<sup>−1</sup> , in ethanol), followed by baking at 80 °C for 30 min. The spin speed was 2500 30 rpm for the QD layer and 3000 rpm for the ZnO layer to achieve layer thickness of ≈18 

and ≈55 nm, respectively. These multilayer structure samples were then loaded into a custom high-vacuum deposition chamber (background pressure, ≈3 × 10<sup>−7</sup> torr) to deposit the top Al cathode (100 nm thick) patterned by an in situ shadow mask to get an active device area of 4 mm<sup>2</sup> . 

5 **Characterization and instrumentation:** UV–visible absorption and PL spectra were measured by an Ocean Optics spectrophotometer (model PC2000-ISA). All PL QY data of QDs were collected by using an Ocean Optics USB2000 spectrometer and an Ocean Optics ISP-50–8-I integrating sphere. Time-resolved fluorescence spectra were measured via the time-correlated single-photon counting method using a JY HORIBA 10 FluoroLog-3 fluorescence spectrometer with a 405 nm picosecond pulsed diode laser with 1 MHz repetition rate and ∼200 ps pulse duration. The optical density (OD) values of the QD samples at the excitation wavelength were all adjusted to be in the range of 0.02−0.05. Transmission electron microscopy (TEM) studies were performed using a JEOL JEM-2010 electron microscope operating at 200 kV. Aberration-corrected high15 angle annular dark-field scanning transmission electron microscopy (HAADF-STEM) images were obtained on a JEOL ARM200F operated at 200 kV. The energy dispersive spectroscopy (EDS) mappings were carried out by four symmetrically designed EDS detectors equipped on FEI Talos F200X. The cross-section images of the QD-LEDs were collected using FEI Talos F200X TEM. The phase and the crystallographic 20 structure of the QDs were investigated by X-ray diffraction (XRD, D8-ADVANCE). The ultraviolet photoelectron spectroscopy (UPS) were performed on a Thermo Scientific ESCALAB 250 XI equipment with a He I discharge lamp (hʋ = 21.22 eV). The J–V characteristics of the QD-LEDs were analysed using an Agilent 4155 C semiconductor parameter analyser with a calibrated Newport silicon diode under 25 ambient conditions. The luminance was calibrated using a Photo Research spectroradiometer (PR735). The electroluminescence spectra were obtained with an Ocean Optics spectrometer (USB2000, relative irradiance mode) and a Keithley 2400 source meter Calculations of the EQE. The EQE is calculated according to the formula below by assuming that the emission obeys a Lambertian profile( _2_ ) whose validity is 30 established later: 



<!-- Start of picture text -->
𝜋𝐿𝑒 ∫ 𝐼 ( 𝜆 ) 𝜆d𝜆<br>𝜂𝐸𝑄𝐸 = 𝐾𝑚ℎ𝑐𝐽 ∫𝐼 ( 𝜆 ) 𝑉 ( 𝜆 ) d𝜆<br><!-- End of picture text -->

where _e_ is the electron charge, _h_ is the Planck constant, _c_ is the velocity of light and K _m_ = 683 lm W<sup>–1</sup> is the maximum luminous efficacy. The current density _J_ is measured from the _J–V_ characteristics using an Agilent 4155 C semiconductor parameter analyser 5 with a calibrated Newport silicon diode under ambient conditions. _I(_ λ _)_ is the relative electroluminescence intensity at wavelength _λ_ , obtained from the electroluminescence spectrum measured with an Ocean Optics spectrometer (USB2000, relative irradiance mode) supplied by a Keithley 2400 source meter, and V(λ) is the normalized photonic spectral response function. L is the total luminance, which is calibrated using a PR735. 10 **PL lifetime measurements:** The PL lifetime at various photoexcitation intensities were measured by using a home-built Time-Correlated Single Photon Counting (TCSPC) system. A 405 nm laser (Advance Laser System, PIL040X) was used for photoexcitation at 10 MHz repetition rate. A biexponential function is utilized to fit the PL lifetime: y = 𝑦0 + 𝐴1𝑒<sup>(−𝑡𝜏</sup> ⁄<sup>1</sup> ) + 𝐴2𝑒(−𝑡𝜏⁄ 2). The fitting curves and corresponding 15 coefficient values are presented in Supplementary Fig. 5. 

**PCE calculation:** For display applications, PCE, also named as wall-plug efficiency or radiant efficiency, is an important parameter even more than the EQE. We have provided details about PCE calculation .  The PCE is calculated according to the following formular: 

20 



<!-- Start of picture text -->
radiation  power<br> 𝑃𝐶𝐸= input power ,<br><!-- End of picture text -->

The radiation power can be calculated by the integral of the product of photon flux and detected optical intensity. 



<!-- Start of picture text -->
ℎ𝑐<br>radiation power = ∫ 𝐼𝑑𝑒𝑡(𝜆) 𝑑𝜆,<br>𝜆<br><!-- End of picture text -->

Where 𝐼𝑑𝑒𝑡(𝜆) is detected optical intensity at wavelength between 𝜆 and 𝜆+ 𝑑𝜆, ℎ 25 is Plank’s constant, q is electronic charge and c is speed of light in vacuum. Input power can be described as: 



<!-- Start of picture text -->
input power = 𝑉𝐼𝑐𝑢𝑟𝑟𝑒𝑡,<br><!-- End of picture text -->

Where 𝐼𝑐𝑢𝑟𝑟𝑒𝑡 is current. 



<!-- Start of picture text -->
𝐼𝑐𝑢𝑟𝑟𝑒𝑛𝑡 = q ∗ ∫ 𝐼𝑑𝑒𝑡(𝜆)𝑑𝜆 .<br>𝐸𝑄𝐸<br><!-- End of picture text -->

∫𝐼𝑑𝑒𝑡(𝜆) 𝑑𝜆 is the number of photons produced per unit time which is equal to the number of consumed electrons per unit time，<sup><u>∫</u>𝐼𝑑𝑒𝑡(𝜆)𝑑𝜆</sup> is the total number for electron 𝐸𝑄𝐸 per unit time. So PCE can be expressed as: 

5 



<!-- Start of picture text -->
𝐼𝑑𝑒𝑡(𝜆)<br>𝑃𝐶𝐸= ℎ𝑐 ∫ 𝜆 𝑑 𝜆 𝐸𝑄𝐸.<br>q𝑉∫𝐼𝑑𝑒𝑡(𝜆)𝑑𝜆<br><!-- End of picture text -->

The PCE of previously reported devices is calculated by assuming that the EL spectra is symmetric, and average photon energy is equivalent to that of the photons with the highest PL count. 



<!-- Start of picture text -->
𝑃𝐶𝐸= ℎ𝑐 𝐸𝑄𝐸<br>𝑞𝑉𝜆<br><!-- End of picture text -->

10 Where 𝜆0 is the central wavelength for electroluminescence, ℎ is Plank’s constant, _q_ is electronic charge, 𝑉 is voltage and _c_ is speed of light in vacuum. 

**Heat generation measurement:** The thermal images of the samples were acquired using a FLUKE Ti401 PRO. The EL region size of QLED is 2 mm×2 mm, and glass substrate size is 25.4 mm×25.4 mm. The QLED is fixed in the aging device. In order to 15 avoid the influence of human body temperature on the device temperature when the device is installed, open the aging instrument when the device temperature drops to the same level as the background temperature, set the initial brightness to 1,000-6,000 cd m<sup>-2</sup> , and test the device temperature according to the set 2 h. 

**Heat generation simulations:** Calculations were carried out using COMSOL 20 Multiphysics® fluid and solid heat transfer module. There are three parts in our simulation: QLED, glass and air, and the size of QLED and glass is same as the device we use (QLED: 2 mm×2 mm, Glass: 25.4 mm×25.4 mm, Air: fluid). The QLED in the simulation is regarded as heat source whose heat power comes from the calculation above and the thermal conductivity for glass and air is 1.34 𝑊∙𝑚<sup>−1</sup> ∙𝐾<sup>−1</sup> and 0.0267 25 𝑊∙𝑚<sup>−1</sup> ∙𝐾<sup>−1</sup> . 

## **Electron quasi Fermi level splitting calculation:** 

According to the semiconductor carrier concentration calculation: 



<!-- Start of picture text -->
𝑘𝑇<br>𝑛= 𝑛0𝑒 ( 𝐸𝐹𝑒−𝐸𝐹 )     (1)<br><!-- End of picture text -->

Where 𝑛0 is the equilibrium electron concentration, 𝐸𝐹𝑒 and 𝐸𝐹 are electron quasi 

30 Fermi level and Fermi level. 𝑘 is the Boltzmann constants and 𝑇 is the temperature. 

And when the conduction band is filled with 2 electrons, the electron quasi Fermi level is lifted to conduction band: 



<!-- Start of picture text -->
𝐸𝐶−𝐸𝐹<br>𝑘𝑇<br>2=𝑛0𝑒 ( )   (2)<br><!-- End of picture text -->

Divide (1) into (2): 

5 



<!-- Start of picture text -->
𝑛 𝐸𝐹𝑒−𝐸𝐶<br>= 𝑒 ( 𝑘𝑇 )    (3)<br>2<br><!-- End of picture text -->

So the electron quasi Fermi level can be written as: 



<!-- Start of picture text -->
𝐸𝐹𝑒 = 𝐸𝐶 + 𝑘𝑇𝑙𝑛(𝑛)     (4)<br>2<br><!-- End of picture text -->

Brightness-electron quasi Fermi level: 



<!-- Start of picture text -->
𝐸𝐹𝑒−𝐸𝐹ℎ 𝐸𝐹𝑒−𝐸𝐹ℎ<br>𝐺= 𝑘𝑛𝑝= 𝑘𝑛0𝑝0𝑒 𝑘𝑇 ∝𝑒 𝑘𝑇<br><!-- End of picture text -->

10 **Out-coupling efficiency calculation:** A transfer-matrix-method<sup>31,32</sup> is used to calculate the out-coupling efficiencies of QLED with two different sizes, and the parameters used in calculation are listed in the Supplementary table 1. Supplementary Fig. 4 shows the calculated emitting power distributions versus the wave-vectors, the out-coupling efficiencies are indicated by their area proportions, which are ~22.4%, 26.5%, and 24.4% 15 for the QD-LEDs using monolayer and three layers regular, and monolayer large FCGQDs, respectively. 

**Electrical excitation transient absorption measurement:** Electrical excitation transient absorption spectrums are obtain by a home-built Electrical excitation transient absorption spectroscopy. Electrical pulse (1 kHz, 10 us) with different voltages 20 generated by arbitrary waveform generator (Keysight, 33512B) as the pump are applied to QD-LEDs. White laser pulse generated by the Supercontinuum white laser (Leukos, Disco) is split into probe beam and reference beam. Delayed by an electronic time delay module, the probe beam is sent to the excitation area by electrical pulse in devices, and then collected to the monochromator and charge-coupled device. Reference beam is 25 collected to eliminating the effect of optical jitter. The collected signal is the difference in probe intensity without and with the pump electrical pulse. 

**Fitting electrical excitation transient absorption spectrum:** According to the previous reports, the change in absorption caused by stark effect can be expressed as 

the linear summary of the first and second derivative of absorption spectrum. So the fitting function can be written as: 



<!-- Start of picture text -->
∆𝛼= 𝑎∗𝐴+ 𝑏∗ 𝑑𝜔 𝑑𝐴 + 𝑐∗ 𝑑𝜔 𝑑2𝐴2 ,<br><!-- End of picture text -->

Here, 𝐴 is the absorption peaks for QDs, which can be expressed as a Guassian 5 function. A and 𝜔 are the absorbance and the frequency. a, b and c are the variables. **Nanosecond transient absorption measurement:** 400 nm laser pulse (1 kHz, 190 fs) generated by a Yb:KGW laser (PHAROS, Light Conversion) is sent to the QD-LEDs as the pump beam. Probe beam (2 kHz) generated by the Supercontinuum white laser (Leukos, Disco) is delayed by an electronic time delay module and applied to the 10 excitation area for QD-LEDs. Probe beam is collected and sent to the monochromator and charge-coupled device. The collected signal is the difference in probe intensity without and with the pump beam. 

**QD films absorption cross-section measurement:** Suppose that the quantum dots are close-packed in the QD films, the QD population per area < 𝑁𝑄𝐷 > for large and 15 regular QD films can be calculated. The absorption cross-section can be calculated by: 



<!-- Start of picture text -->
𝜎= 2.303 ∗𝐴 < 𝑁𝑄𝐷 >  ,<br><!-- End of picture text -->

Here 𝐴 is the absorbance measured by a UV-Vis spectrophotometer (P4PC, Mapada). Supplementary Fig. 10 show the absorption cross-section of variable wavelengths for large and regular QDs. So we get the absorption cross-section 8.67e-14 𝑐𝑚<sup>2</sup> and 20 1.38e-14 𝑐𝑚<sup>2</sup> at 400 nm for large and regular QDs, respectively. 

**Average electron concentration calculation:** the average electron population< 𝑁> by photoexcitation can be calculated by: 



<!-- Start of picture text -->
< 𝑁>= 𝑃∗𝜎,<br><!-- End of picture text -->

Here, 𝑃  and 𝜎  are the excitation power density and absorption cross-section, 25 respectively. Because of the almost linearly increasing for 1S bleach at low excitation power, we obtain the function between the average electron population < 𝑁> and ∆𝛼 from photoexcitation nanosecond transient absorption. Comparing the ∆𝐴 from EETA and ∆𝛼 for ns TA, we get < 𝑁>𝐸 under different voltages in operating devices. 

## **Data availability.** 

The data that support the findings of this study are available from the corresponding 

author upon reasonable request. 

- 31 Benisty, H., Stanley, R. & Mayer, M. Method of source terms for dipole emission 

- 5 modification in modes of arbitrary planar structures. _J. Opt. Soc. Am. A_ **15** , 11921201(1998). 

   - 32 Cho, C. & Greenham, N. C. Computational study of dipole radiation in re‐ absorbing perovskite semiconductors for optoelectronics. _Adv. Sci._ **8** , 2003559 (2020). 

10 

This is a list of supplementary �les associated with this preprint. Click to download. 

Supplementary.pdf 

