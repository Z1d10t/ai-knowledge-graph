# Buried interface molecular hybrid for inverted perovskite solar cells

| 字段 | 内容 |
|---|---|
| 期刊 | Nature |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 988 |
| 作者 | Sanwan Liu, Jing-Bai Li, Wenshan Xiao, Rui-Ting Chen, Zhen-Xing Sun, Yong Zhang, Xia Lei, Shuai-Feng Hu et al. |
| DOI | 10.1038/s41586-024-07723-3 |
| 源文件 | 003_Liu_2024_Buried-interface-molecular-hybrid-for-inverted-p.pdf |

---
**Buried interface molecular hybrid for inverted perovskite solar cells** 

<mark>Sanwan Liu</mark><sup>1,2</sup> <mark>†, Jingbai Li</mark><sup>3</sup> †, <mark>Wenshan Xiao</mark><sup>4</sup> <mark>†, Rui Chen</mark><sup>1</sup> <mark>†</mark> , <mark>Zhenxing Sun</mark><sup>1</sup> <mark>†, Yong Zhang</mark><sup>5</sup> <mark>†, Xia Lei</mark><sup>5,3</sup> <mark>, Shuaifeng Hu</mark><sup>6</sup> <mark>, Manuel Kober-Czerny</mark><sup>6</sup> <mark>, Jianan Wang</mark><sup>1</sup> <mark>, Fumeng Ren</mark><sup>1</sup> <mark>, Qisen Zhou</mark><sup>1</sup> <mark>, Hasan Raza</mark><sup>1</sup> <mark>, You Gao</mark><sup>1</sup> <mark>, Yitong Ji</mark><sup>4</sup> <mark>, Sibo Li</mark><sup>7</sup> <mark>, Huan Li</mark><sup>7</sup> <mark>, Longbin Qiu</mark><sup>7</sup> <mark>, Wenchao Huang</mark><sup>4,8</sup> <mark>, Yan Zhao</mark><sup>9,10</sup> <mark>, Baomin Xu</mark><sup>5</sup> <mark>, Zonghao Liu</mark><sup>1,2</sup> <mark>*, Henry J. Snaith</mark><sup>6</sup> <mark>, Nam-Gyu Park</mark><sup>11,12</sup> <mark>*, Wei Chen</mark><sup>1,2</sup> <mark>*</mark> 

> 1 <mark>Wuhan National Laboratory for Optoelectronics (WNLO), Huazhong University of Science and Technology (HUST), Wuhan 430074, China.</mark> 

> 2 <mark>Optics Valley Laboratory, Hubei, 430074 China.</mark> 

> 3 <mark>Hoffmann Institute of Advanced Materials, Shenzhen Polytechnic University, Shenzhen, 518055, China.</mark> 

4Key State Laboratory of Advanced Technology for Materials Synthesis and Processing, School of Materials Science and Engineering, Wuhan University of Technology, 430070, Wuhan, China. 

5Department of Materials Science and Engineering, Southern University of Science and Technology, Shenzhen, 518055 China. 

6Clarendon Laboratory, Department of Physics, University of Oxford, Oxford OX13PU, U.K. 

7Shenzhen Key Laboratory of Intelligent Robotics and Flexible Manufacturing Systems, Department of Mechanical and Energy Engineering, SUSTech Energy Institute for Carbon Neutrality, Southern University of Science and Technology, Shenzhen, 518055, China 

8Hubei Longzhong Laboratory, Wuhan University of Technology Xiangyang Demonstration Zone, 441000, Xiangyang, China. 

9College of Materials Science and Engineering, Sichuan University, Chengdu 610065, China. 

10The Institute of Technological Sciences, Wuhan University, Hubei, Wuhan 430072, China. 

11School of Chemical Engineering and Center for Antibonding Regulated Crystals, Sungkyunkwan University (SKKU), Suwon 16419, Republic of Korea. 

12SKKU Institute of Energy Science & Technology (SIEST), Sungkyunkwan University, Suwon 

16419, Republic of Korea. 

†These authors contributed equally to this work. 

<mark>*Corresponding authors. E-mail: liuzonghao@hust.edu.cn; npark@skku.edu; wnlochenwei@hust.</mark> 

<mark>edu.cn.</mark> 

1 

**Abstract:** Perovskite solar cells (PSCs) with an “inverted” architecture are a key pathway for commercializing this emerging photovoltaic technology due to the better power conversion efficiency (PCE) and operational stability as compared to the “normal” device structure. Specifically, PCEs of the inverted PSCs have exceeded 25% owing to the development of improved selfassembled molecules (SAMs)<sup>1-5</sup> and passivation strategies<sup>6-8</sup> . Nevertheless, poor wettability and agglomerations of SAMs<sup>9-12</sup> will cause interfacial losses, impeding further improvement in PCE and stability. Herein, we report on molecular hybrid at the buried interface in inverted PSCs by coassembling a multiple carboxylic acid functionalized aromatic compound of 4,4’,4’’nitrilotribenzoicacid (NA) with a popular SAM of [4-(3,6-dime-thyl-9H-carbazol-9yl)butyl]phosphonic acid (Me-4PACz) to improve the heterojunction interface. The molecular hybrid of Me-4PACz with NA could substantially improve the interfacial characteristics. The resulting inverted PSCs demonstrated a record-certified steady-state efficiency of 26.54%. Crucially, this strategy aligns seamlessly with large-scale manufacturing, achieving the highest certified PCE for inverted mini-modules at 22.74% (aperture area: 11.1 cm<sup>2</sup> ). Our device also maintained 96.1% of its initial PCE after more than 2,400 hours of 1-sun operation in ambient air. 

# **Keywords** 

**perovskite solar cells, buried interface, molecular hybrid, efficiency, stability.** 

# **Introduction** 

Perovskite solar cells (PSCs) with an inverted (p-i-n) architecture are recognized to be one of the mainstream technical routes for the commercialization of this emerging photovoltaic technique owing to their competitive PCEs, good stability, and compatibility with tandem solar cells. Currently, their PCEs exceed 25% owing to the development of hole-selective layers (HSLs)<sup>1-4</sup> and passivation strategies<sup>6-8</sup> . In particular, SAMs-based HSLs have been widely used in high-efficiency inverted PSCs reported recently due to the advantages of appropriate energy levels for efficient carrier extraction and low non-radiative recombination loss<sup>4</sup> . However, commonly used SAMs, such as [4(3,6-dimethyl-9H-carbazol-9-yl)butyl]phosphonic acid (Me-4PACz), exhibit inhomogeneous distribution<sup>12,13</sup> on the substrate and poor surface wettability to perovskite precursors<sup>9-11</sup> . Such 

2 

characteristics make the direct deposition of high-quality perovskite film on top of Me-4PACz a challenge. These disadvantages will result in a low fabrication yield and undesired interfacial losses at buried interfaces, especially when manufacturing large-area devices. 

Here, we report a hybrid SAM strategy, where the widely used SAM, Me-4PACz, is assembled with a multiple carboxylic acid functionalized aromatic molecule, 4,4’,4’’-nitrilotribenzoicacid (NA) to form mixed SAMs (denoted as NA-Me) on the surface of nickel oxide (NiO) to fabricate inverted PSCs. With NA molecules in the Me-4PACz layer, the wettability of the perovskite solution on the HSL is improved, leading to the reduction of nanovoids and the release of stress at the buried interface. Due to the interaction between Me-4PACz and the triphenylamine moiety in the NA molecule, NA-Me can reduce the agglomerations of Me-4PACz to homogenize the distribution of Me-4PACz, thus facilitating carrier extraction and reducing nonradiative recombination at the NiO/perovskite interface. The inverted devices based on formamidinium-cesium (FACs) perovskite with the composition of FA0.95Cs0.05PbI3 achieved optimal PCEs of 26.69% with a high open-circuit voltage ( _V_ OC) of 1.201 V (certified steady-state efficiency of 26.54%) and 23.06% (certified 22.74%) for small-area PSCs and mini-modules with an aperture area of 11.1 cm<sup>2</sup> , respectively. Furthermore, our devices retained 96.1% and 97.4% of their initial PCEs after operating at 65 °C under 1-sunequivalent white-light light emitting diode (LED) illumination in ambient air over 2,400 hours and aging under the damp heat test conditions over 500 hours, respectively. 

# **Theoretical screening of hybrid SAMs** 

To design the hybrid SAMs, we sought to understand the interactions between Me-4PACz (Fig. 1a) and three carboxylic acid functionalized aromatic molecules, i.e., NA, benzoic acid (BA), and trimesic acid (TA) when forming mixed SAMs layer between the perovskite and NiO films (Supplementary Fig. 1). We built molecular models for the perovskite/SAMs/NiO heterojunction based on a 10 nm × 10 nm perovskite and NiO surface, filled with 2 nm mixed Me-4PACz and carboxylic acids in 3:1 (Fig. 1b). Computational details can be found in Method section and Supplementary Note 1. Molecular dynamic (MD) simulations show that Me-4PACz can form dimers, trimers, and tetramers in line with the previous report<sup>12</sup> , which could cause the formation of nanovoids on the perovskite bottom surface (Fig. 1c). Adding BA did not reduce the agglomeration of Me-4PACz with limited control of the nanovoids (Fig. 1d). By contrast, the adding of NA (Fig. 

3 

1e) and TA (Fig. 1f) into Me-4PACz delivered more compact hybrid HSLs. Adjacent to the perovskite surface, the adsorption ratio for carboxylic acid increased from 0.07 to 0.43 following BA<TA<NA (Fig. 1g). It resulted in an increasing coverage ratio on the perovskite surface in the BA-Me, TA-Me, and NA-Me hybrids from 0.12 to 0.21 by Me-4PACz and from 0.13 to 0.28 by all SAMs (Fig. 1g and Supplementary Fig. 2). In terms of molecular configuration, density functional theory (DFT) calculations showed the absorbed Me-4PACz lying on the perovskite surface (Fig. 1h) with a preferred configuration for defect passivation. When adsorbed on the NiO surface, both the phosphonic group and π-ring in Me-4PACz could interact with the NiO surface, leading to much higher absorption energy when compared with the three carboxylic acids (Fig. 1i, j, and Supplementary Fig. 3). Interestingly, the NA-Me dimer shows notably higher binding energies than other dimers (Fig. 1k) due to the co-existing π-π interactions and hydrogen bonding. Their interaction energies (–0.61 eV) are comparable to the hydrogen binding energy (–0.62 eV) observed in the Me-4PACz tetramer (Supplementary Fig. 4, Supplementary Note 2, and Supplementary Table 1). Thus, the formation of NA-Me dimer could break the Me-4PACz tetramers, which helps reduce its agglomeration to homogenize its distribution, leading to a compact and uniform NiO/SAMs HSL at the buried interface. 

# **Buried interface quality** 

In addition, the introduction of carboxylic acids into the Me-4PACz layer could enhance the wetting of the perovskite precursor on the NiO/SAM substrate (Supplementary Fig. 5), which helped to improve the apparent coverage of the resultant perovskite film (Supplementary Fig. 6 and 7). To further characterize the effect of the wettability of HSLs on the perovskite quality, we used a scatheless peel-off technique to prepare samples for scanning electron microscopy (SEM) characterization of perovskite bottom surface morphology (Fig. 2a-d and Supplementary Fig. 8)<sup>3,14</sup> . Numerous nanovoids were observed at the bottom surface of the perovskite grown on the Me4PACz SAM due to its hydrophobicity and insufficient wetting. In contrast, the exposed bottom surfaces of the perovskite films deposited on the TA-Me or NA-Me SAMs showed a more compact and smoother film morphology without obvious nanovoids. However, a small number of nanovoids remained in the BA-Me sample. The elimination of nanovoids at the buried interface using the molecular hybrid strategy is further verified by the cross-section SEM characterizations (Fig. 2e-h). 

4 

Interestingly, all the perovskite films showed similar morphologies at the top surface (Supplementary Fig. 9). 

The morphologies improvement is correlated with the crystallinity of the perovskite films at the buried region, although the mixed SAMs did not significantly change the bulk crystal quality of the entire perovskite films (Supplementary Fig. 10). To further explore this point, grazing-incidence wide-angle X-ray scattering (GIWAXS) measurements were performed on the exposed bottom surfaces of the perovskite films with an incidence angle of 0.5° (Fig. 2i-l). All GIWAXS scattering results showed that there was no preferential orientation of the perovskite crystals<sup>1</sup> . However, the scattering intensity of the (100) peak of the perovskite film deposited on Me-4PACz was significantly lower than those of the three hybrid SAMs. Remarkably, the perovskite film on NAMe exhibited the strongest intensity in the (100) peak, followed by the perovskite films on the TAMe and BA-Me SAMs, indicating that the use of mixed SAMs considerably improved the crystal crystallinity of the perovskite films at the buried region. 

The significant improvement in the morphology and crystallinity of the perovskite at the bottom region also affects the release of residual stress<sup>15-17</sup> . We thus investigated the residual stress at the bottom surface of the perovskite films prepared on different HSLs via the grazing incidence X-ray diffraction (GIXRD) technique with the 2 _θ_ -sin<sup>2</sup> _ψ_ method with a penetration depth of 50 nm (Supplementary Note 3). It was found that the diffraction peaks of the perovskite film prepared on Me-4PACz, BA-Me, and TA-Me SAMs fitted with Gaussian distribution gradually shifted to lower 2 _θ_ positions by varying _ψ_ from 5 to 45°, while the diffraction peaks of the perovskite film on NAMe slightly shifted to higher 2 _θ_ positions (Fig. 2m, n and Supplementary Fig. 11a, b). The slopes of the fitted lines for the four conditions by fitting the 2 _θ_ as a function of sin<sup>2</sup> _ψ_ are shown in Supplementary Fig. 11c. The perovskite films on Me-4PACz, BA-Me, and TA-Me substrates exhibited negative slopes, indicating that the films were subjected to tensile stress. In contrast, the slope of the perovskite film on NA-Me showed a diminutive positive value, suggesting a favorable situation with slight compressive stress (Fig. 2o)<sup>18</sup> . These results indicate that the hybrid SAM strategy can release the residual tensile stress of perovskite films, which is favorable for the efficiency and stability of PSCs<sup>19</sup> . 

**Reducing interfacial energy loss** 

5 

Mixed SAMs can be anchored on the NiO surface via their phosphonic acid and carboxylic acid anchoring groups, as demonstrated in the X-ray photoelectron spectrometry (XPS) spectra (Supplementary Fig. 12). The homogeneity of the distribution of three mixed SAMs on the surface of NiO also affects the variation of the surface potential of NiO, as demonstrated in Supplementary Fig. 13. In addition, the surface potential of the mixed BA-Me and TA-Me samples showed a significant shift before and after washing, while the NA-Me sample did not show a significant shift (Fig. 3a-c). This is because the Me-4PACz has stronger adsorption energy at the surface of NiO when compared with the three carboxylic acids, and the presence of NA facilitates a more homogenous distribution of Me-4PACz, thereby enhancing the overall binding effect of the mixed NA-Me at the surface of NiO. 

We further examined the bottom surface uniformity of the perovskite films deposited on different HSLs using laser confocal fluorescence lifetime imaging microscopy (FLIM). As shown in Fig. 3d-f, and Supplementary Fig. 14, the NA-Me-based perovskite film exhibited significantly improved uniformity and enhanced photoluminescence (PL) lifetimes over a probed area of 30 × 30 μm when compared with Me-4PACz and TA-Me cases. This observation indicates that the NA-Me hybrids effectively improve the uniformity of the perovskite bottom surface and reduce the nonradiative recombination loss at the buried interface. 

The modification of NiO with SAMs could affect the energy level alignment at the buried interface. The ultraviolet photoelectron spectroscopy (UPS) results (Supplementary Fig. 15-16 and Supplementary Table 2) indicate that the energy difference between the NiO and perovskite valance bands for hole extraction is the lowest when modifying NiO with NA-Me (Supplementary Fig. 17). This favorable energy level alignment was verified to facilitate the hole extraction at the NiO/perovskite interface by the steady-state PL and time-resolved PL (TRPL) measurements (Supplementary Fig. 18, Supplementary Note 4, and Supplementary Table 3). In addition, the reduced energy loss at the buried interface is also beneficial for improving the devices’ _V_ OC. 

To quantify the interfacial non-radiative recombination loss, we measured the photoluminescence quantum yield (PLQY) to estimate the quasi-Fermi level splitting (QFLS) in the corresponding samples (Supplementary Note 5)<sup>20,21</sup> . As shown in Fig. 3g and Supplementary Fig. 19-21, the NA-Me sample exhibited the maximum PLQY value of 9.19% and QFLS value of 1.228 

6 

eV, leading to the minimal _V_ OC deficit as a result of nonradiation recombination (∆ _V_ non-radOC ) compared to other SAMs. We further used a two-trap level Shockley-Read-Hall (SRH) model<sup>22,23</sup> to quantify the effect of NA-Me on the recombination rates of the perovskite films based on the light intensitydependent PLQY measurements (Fig. 3h, Supplementary Fig. 22, and Supplementary Table 4). We observe that the PLQY of the NA-Me samples is consistently higher than that of the Me-4PACz samples under the examined photon flux densities. From the fits of the measured PLQY to the SRH model, we determine that the trapping rate into a shallow trap level ( _k_ tr) and the non-radiative recombination rate ( _k_ deep) are smaller for the NA-Me sample than the Me-4PACz sample. We interpret this result as the reduced surface recombination at the buried interface for the NA-Me sample and a reduced density of shallow bulk defects. Details and fitted parameters can be found in Supplementary Note 6. 

To further study the passivation mechanism of the hybrid SAMs, we investigated the possible interactions between the hybrid SAMs and the perovskite films by considering four typical perovskite surface defects, I-vacancy (VI), Pb-vacancy (VPb), and Pb–I antisites (PbI and IPb) via DFT calculations. Noteworthy, the bottom perovskite surface was weak _p-_ type corresponding to the approximately stoichiometric Pb and I condition as indicated by UPS results<sup>24,25</sup> . The defect formation energies calculation results are shown in Supplementary Fig. 23-25 (Supplementary Note 7 and Supplementary Table 5). The defect transition level diagram (Fig. 3i) shows the VI, VPb, and IPb defects are thermodynamically more stable than PbI near the Fermi level. We thus focused on the VPb<sup>2+</sup> defect because it led to notable deep traps (Supplementary Fig. 24). The MD simulations for the heterojunction models with a VPb<sup>2+</sup> defect show the Me-4PACz’s π-ring pointing to the defect in all cases (Fig. 3j, Supplementary Note 8, and Supplementary Fig. 26-30), suggesting an essential role of the Me-4PACz’s π-ring in passivating the defect. The projected density of states (Fig. 3k) demonstrated that the Me-4PACz’s π-ring passivates the VPb<sup>2+</sup> deep trap, which could reduce the nonradiative recombination. The VPb<sup>2+</sup> deep trap resulted from the broken ionic I–Pb bond (6.19 Å), which transformed the Pb-vacancy to an I–Pb antisite with an I-vacancy (Fig. 3l). The Me-4PACz’s π-ring is electron-rich, which could extract the positive charges from the defective surface (Supplementary Fig. 31 and Supplementary Note 9). As a result, the partial restoration of the I–Pb bond (4.06 Å) passivated the VPb<sup>2+</sup> deep trap. 

7 

# **Device characteristics** 

We fabricated inverted PSCs with an architecture of indium tin oxide (ITO)/NiO/SAMs/FA0.95Cs0.05PbI3/piperazinium iodide (PI)<sup>26,27</sup> /[6,6]-phenyl-C61-butyric acid methyl ester (PC61BM)/bathocuproine (BCP)/Ag (Supplementary Fig. 32) to evaluate the devices performance. The effects of modifying the NiO/perovskite interface with only NA (TA or BA) on device performance are shown in Supplementary Fig. 33 and Supplementary Note 10. The combination of NiO and Me-4PACz was chosen as the baseline bilayer HSL because it enabled improved efficiencies compared with pristine NiO or Me-4PACz single HSL (Supplementary Fig. 34). The photoelectric parameters of the devices with different HSLs are summarized in Supplementary Table 6. The efficiencies of the devices based on the NA-Me are higher than those with the other two hybrids cases, with the main contribution from the simultaneous enhancements of the _V_ OC and fill factor (FF) (Fig. 4a, b and Supplementary Fig. 35). The current density–voltage ( _J_ – _V_ ) curves of the champion inverted PSCs with different HSLs are shown in Fig. 4c and Supplementary Fig. 36. The champion device with Me-4PACz only gave a substantial but inferior PCE of 23.29%, with _V_ OC = 1.135 V, _J_ SC = 25.80 mA cm<sup>−2</sup> , and FF = 79.53% (steady-state PCE of 23.02%). Meanwhile, the NA-Me device yielded an optimal efficiency of 26.69% and a high _V_ OC of 1.201 V under reverse scan with low hysteresis (Supplementary Table 7) and exhibited a steadystate PCE of 26.61% (Fig. 4d). Specifically, the _J_ SC of the device is 26.3 mA cm<sup>−2</sup> under reverse scan, which accounts for ~93% of the theoretical thermodynamic maximum for a material with this bandgap<sup>28,29</sup> . The champion device with NA-Me SAM exhibits an EQE value and the corresponding integrated _J_ SC is 25.57 mA cm<sup>−2</sup> (Supplementary Fig. 37). One such device was measured by an independently accredited testing center (Chinese National PV Industry Measurement and Testing Center, NPVM), yielding a PCE of 26.54% under reverse scan (Supplementary Fig. 38) and a record steady-state PCE of 26.54% after maximum power-point tracking (MPPT) for 300 s (Supplementary Fig. 39), which is the highest certified efficiency among all single-junction PSCs (Fig. 4e and Supplementary Table 8). This result confirms the superiority of our hybrid SAM strategy (Supplementary Table 9 and Supplementary Note 11). 

The FF loss analysis (Supplementary Note 12, Supplementary Fig. 40 and 41) showed minimized non-radiative recombination loss in the NA-Me sample, suggesting that the defectassisted trap states at the buried interface were suppressed, consistent with our DFT calculations. In 

8 

addition, based on the results of transient photovoltage (TPV) and capacitance _–_ voltage ( _C–V_ ) measurements (Supplementary Fig. 42 and 43), we conclude that NA-Me SAMs can effectively suppress nonradiative recombination and improve charge transfer at the buried interface<sup>30</sup> . We also considered the upscaling capability of the NA _-_ Me hybrid HSL and successfully fabricated highperformance mini-modules (Fig. 4f). The mini-module with an aperture area of 11.1 cm<sup>2</sup> exhibited a PCE of 23.06% (Supplementary Table 10) from the reverse _J–V_ scan with low hysteresis. We sent one of the mini-modules to an independent laboratory (Shanghai Institute of Microsystem and Information Technology, SIMIT, Shanghai, China) for certification, and a PCE of 22.74% was obtained from the reverse _J–V_ scan (PCE of 22.58% from the forward scan, Supplementary Fig. 44). To the best of our knowledge, this result represents the highest reported certified efficiency of inverted perovskite mini-modules to date (Supplementary Fig. 45 and Supplementary Table 11). 

We further estimated the effect of the NA-Me SAM on the perovskite and device stability. The stabilities of the perovskite films with different SAMs (Me-4PACz and NA-Me) were evaluated using in-situ PL measurements in ambient air (Supplementary Fig. 46). The PL intensity of the perovskite film on Me-4PACz decreased after continuous laser irradiation for 120 min at 85 °C, while the PL intensity of the perovskite film on NA-Me showed no significant change. This observation indicates that NA-Me effectively enhanced the thermal and light stability of perovskite films. We suggest that amorphous buried interfaces with numerous defects and high residual stresses are often more prone to decomposition during aging<sup>14,31</sup> (Supplementary Fig. 47). As the incident side of light, the buried interfaces with improved quality would improve device stability. 

The efficiency evolutions of the inverted PSCs under stresses were further monitored. It should be noted that the Bi/Ag bilayer was used to replace Ag as the electrode to fabricate devices with the configuration of ITO/NiO/Me-4PACz or NA-Me/perovskite/PI/PCBM/BCP/Bi/Ag for stability study due to the inferior operational stability of Ag-based devices (Supplementary Fig. 48)<sup>32</sup> . First, we placed encapsulated devices in a chamber (Supplementary Fig. 49) to conduct the damp heat test (85 °C and 85% RH) following the International Electrotechnical Commission (IEC) 61215:2016 standards. As shown in Fig. 4g, the NA-Me-based devices maintained 97.4% of their initial PCEs (26.15%, Supplementary Fig. 50a) over 500 hours under damp heat aging, whereas the devices with Me-4PACz alone retained only 66.8% of their initial PCEs (22.68%, Supplementary Fig. 50b) within the same aging time. Additionally, we also examined the operational stability of the 

9 

encapsulated devices with MPPT under continuous 1-sun-equivalent white-light LED illumination at 65 °C hot plate in ambient air (Fig. 4h). The NA-Me-based device retained approximately 96.1% of its initial PCE (26.21%, Supplementary Fig. 51a) over 2,400 hours, whereas the device with Me4PACz retained only 66.5% of its initial PCE (22.75%, Supplementary Fig. 51b) after 1,580 hours. Therefore, our devices achieved both high efficiency and good operational stability (Supplementary Table 12), which demonstrate that our interface molecular hybrid engineering using NA-Me is an effective approach for significantly improving the efficiency and stability of inverted PSCs. 

# **References** 

1. Zhang, S. et al. Minimizing buried interfacial defects for efficient inverted perovskite solar cells. _Science_ **380** , 404-409 (2023). 

2. Li, Z. et al. Stabilized hole-selective layer for high-performance inverted p-i-n perovskite solar cells. _Science_ **382** , 284-289 (2023). 

3. Tan, Q. et al. Inverted perovskite solar cells using dimethylacridine-based dopants. _Nature_ **620** , 545-551 (2023). 

4. Al-Ashouri, A. et al. Monolithic perovskite/silicon tandem solar cell with >29% efficiency by enhanced hole extraction. _Science_ **370** , 1300-1309 (2020). 

5. Liu, S., Biju, V. P., Qi, Y., Chen, W. & Liu, Z. Recent progress in the development of highefficiency inverted perovskite solar cells. _NPG Asia Mater._ **15** , 27 (2023). 

6. Jiang, Q. et al. Surface reaction for efficient and stable inverted perovskite solar cells. _Nature_ **611** , 278-283 (2022). 

7. Liang, Z. et al. Homogenizing out-of-plane cation composition in perovskite solar cells. _Nature_ **624** , 557-563 (2023). 

8. Chen, H. et al. Improved charge extraction in inverted perovskite solar cells with dual-sitebinding ligands. _Science_ **384** , 189-193 (2024). 

9. Hossain, K. et al. Resolving the hydrophobicity of the Me-4PACz hole transport layer for inverted perovskite solar cells with efficiency>20%. _ACS Energy Lett._ **8** , 3860-3867 (2023). 

10. Pitaro, M. et al. Tuning the surface energy of hole transport layers based on carbazole selfassembled monolayers for highly efficient Sn/Pb perovskite solar cells. _Adv. Funct. Mater._ , 2306571 (2023). 

10 

11. Al-Ashouri, A. et al. Wettability improvement of a carbazole-based hole-selective monolayer for reproducible perovskite solar cells. _ACS Energy Lett._ **8** , 898-900 (2023). 

12. Park, S. M. et al. Low-loss contacts on textured substrates for inverted perovskite solar cells. _Nature_ **624** , 289-294 (2023). 

13. Yu, S. et al. Homogenized NiOx nanoparticles for improved hole transport in inverted perovskite solar cells. _Science_ **382** , 1399-1404 (2023). 

14. Luo, C. et al. Engineering the buried interface in perovskite solar cells via lattice-matched electron transport layer. _Nat. Photon._ **17** , 856-864 (2023). 

15. Chang, X. et al. Two-second-annealed 2D/3D perovskite films with graded energy funnels and toughened heterointerfaces for efficient and durable solar cells. _Angew. Chem. Int. Ed._ **62** , e202309292 (2023). 

16. Wang, H. et al. Interfacial residual stress relaxation in perovskite solar cells with improved stability. _Adv. Mater._ **31** , 1904408 (2019). 

17. Liu, S. et al. Effective passivation with size-matched alkyldiammonium iodide for highperformance inverted perovskite solar cells. _Adv. Funct. Mater._ **32** , 2205009 (2022). 

18. Zheng, Z. et al. Pre-buried additive for cross-layer modification in flexible perovskite solar cells with efficiency exceeding 22%. _Adv. Mater._ **34** , 2109879 (2022). 

19. Gao, Y. et al. Elimination of unstable residual lead iodide near the buried interface for the stability improvement of perovskite solar cells. _Energy  Environ. Sci._ **16** , 2295-2303 (2023). 

20. Li, L. et al. Flexible all-perovskite tandem solar cells approaching 25% efficiency with molecule-bridged hole-selective contact. _Nat. Energy_ **7** , 708-717 (2022). 

21. Stolterfoht, M. et al. The impact of energy alignment and interfacial recombination on the internal and external open-circuit voltage of perovskite solar cells. _Energy Environ. Sci._ **12** , 2778-2788 (2019). 

22. Yang, B. et al. A universal ligand for lead coordination and tailored crystal growth in perovskite solar cells. _Energy Environ. Sci._ **17** , 1549-1558 (2024). 

23. Suo, J. et al. Multifunctional sulfonium-based treatment for perovskite solar cells with less than 1% efficiency loss over 4,500-h operational stability tests. _Nat. Energy_ **9** , 143-153 (2024). 

11 

24. Zhao, Y. et al. Molecular interaction regulates the performance and longevity of defect passivation for metal halide perovskite solar cells. _J. Am. Chem. Soc._ **142** , 20071-20079 (2020). 

25. Wang, Q. et al. Qualifying composition dependent _p_ and _n_ self-doping in CH3NH3PbI3. _Applied Physics Letters_ **105** , 163508-163513 (2014). 

26. Li, F. et al. Hydrogen-bond-bridged intermediate for perovskite solar cells with enhanced efficiency and stability. _Nat. Photon._ **17** , 478-484 (2023). 

27. Mariotti, S. et al. Interface engineering for high-performance, triple-halide perovskitesilicon tandem solar cells. _Science_ **381** , 63-69 (2023). 

28. Ma, C. & Park, N.-G. A realistic methodology for 30% efficient perovskite solar cells. _Chem_ **6** , 1254-1264 (2020). 

29. Rühle, S. Tabulated values of the Shockley-Queisser limit for single junction solar cells. _Sol. Energy_ **130** , 139-147 (2016). 

30. Chu, X. et al. Surface in situ reconstruction of inorganic perovskite films enabling long carrier lifetimes and solar cells with 21% efficiency. _Nat. Energy_ **8** , 372-380 (2023). 

31. Chen, S. et al. Stabilizing perovskite-substrate interfaces for high-performance perovskite modules. _Science_ **373** , 902-907 (2021). 

32. Wu, S. et al. A chemically inert bismuth interlayer enhances long-term stability of inverted perovskite solar cells. _Nat. Commun._ **10** , 1161 (2019). 

# **Figure legends** 

**Fig. 1. Computational simulations for the heterojunction of the HSL. a** . Chemical structure of Me-4PACz and BA, NA, and TA. **b** . Illustration of the perovskite/SAMs/NiO heterojunction model for molecular dynamics simulations. Top and side views of equilibrated molecular representations for the heterojunctions with only Me-4PACz ( **c** ), BA-Me ( **d** ), NA-Me ( **e** ), and TA-Me hybrids ( **f** ). Me-4PACz are shown in orange and blue for the adsorptions on the NiO and perovskite, respectively. Carboxylic acids functionalized molecules are shown in cyan and green for the adsorptions on the NiO and perovskite, respectively. Ni and O atoms are shown in grey and red in the background, respectively. The perovskite is omitted in the top views for clarity. I atoms in the perovskite are 12 

highlighted in purple in the side view. **g** . Adsorption analysis for the perovskite and NiO surface in the heterojunction models. The ratio of carboxylic acids functionalized molecules is determined by the number of carboxylic acids within 10 Å of each surface. The Me-4PACz and surface coverage describe the total area covered by Me-4PACz and all SAMs within 5 Å of each surface. **h** . The optimized adsorption structures of Me-4PACz at the NiO surface. **i** . Adsorption energies for SAMs at NiO surface. **j** . The optimized adsorption structures of Me-4PACz on the perovskite surface. **k** . Binding energies for the typical dimers of SAMs observed in the molecular dynamic simulations. Me-Me is the dimer of Me-4PACz. 

**Fig. 2. The morphology and structure at the perovskite** - **substrate region. a** - **d** , SEM images of the bottom surface of perovskite films on (a) Me-4PACz, (b) BA-Me, (c) TA-Me, and (d) NA-Me SAMs, respectively. Scale bars, 500 nm. **e-h** , Cross-section SEM images of perovskite films on (e) Me-4PACz, (f) BA-Me, (g) TA-Me, and (h) NA-Me SAMs, respectively. Scale bars, 1 μm. **i-l** , 2D GIWAXS patterns of perovskite films deposited on (i) Me-4PACz, (j) BA-Me, (k) TA-Me, and (l) NA-Me SAMs, respectively. The qz and qr represent the out-of-plane and in-plane scattering vector components, respectively. The color bar shows the diffraction intensity collected from the GIWAXS detector. **m** - **n** , GIXRD patterns measured at different _ψ_ angles from 5 to 45° for perovskite films on (m) Me-4PACz and (n) NA-Me HSLs. **o** , Comparison of residual stress in perovskite films on different HSLs. 

**Fig. 3. Reducing interfacial energy loss. a** - **c** , Corresponding CPD distributions for different mixed SAMs coated on NiO before and after washing treatment (N,N-dimethylformamide (DMF)/dimethyl sulfoxide (DMSO), V:V = 4:1): (a) BA-Me, (b) TA-Me, and (c) NA-Me. **d** - **f** , The FLIM of the exposed bottom surface of perovskite layers on (d) Me-4PACz, (e) TA-Me, and (f) NAMe, respectively. **g** , The calculated QFLS of perovskite films on glass and different HSLs. **h** , Photon flux densities-dependent PLQY measurements fitted according to the two-trap level SRH model. **i.** Defect transition level diagram for perovskite surface defects with charges. **j** . Molecular configuration of Me–4PACz adjacent to the VPb<sup>2+</sup> defect in the molecular dynamics simulations for the NA–Me hybrid system. Projected density of states ( **k** ) and 2 × 2 × 1 slice of the optimized structures ( **l** ) of the VPb<sup>2+</sup> defect and Me-4PACz passivated perovskite surfaces. Red arrows 13 

highlight the broken I–Pb ionic bond; blue arrows indicate the distances between Me-4PACz and the perovskite surface. 

**Fig. 4. Photovoltaic performance of devices. a** , _J_ – _V_ curves of PSCs with different SAMs under reverse scan. **b** , Statistics of PCE of PSCs with different SAMs based on 20 devices. **c** , _J_ – _V_ curves of the champion inverted PSC with NA-Me HSL under reverse and forward scan. **d** , Stabilized PCEs of champion inverted PSCs based on different SAMs determined by MPPT for 300 s. **e** , Comparison of our PSCs’s certified PCE and _V_ OC with other reported high-performance inverted PSCs. **f** , _J_ – _V_ curves of champion mini-modules based on NA-Me HSL. (Inset) Photograph of the mini-module with an aperture area of 11.1 cm<sup>2</sup> . **g** , Normalized PCE of encapsulated devices aged under damp heat conditions (85 °C and 85% RH) following the IEC61215:2016 standard. The initial PCEs of the Me-4PACz and NA-Me devices used for the damp heat tests were 22.68% and 26.15%, respectively. **h** , Operational stability of encapsulated devices under continuous 1-sun equivalent white-light LED illumination with MPPT in ambient air. The initial PCEs of the Me-4PACz and NA-Me devices used for the operational stability tests were 22.75% and 26.21%, respectively. 

# **Methods** 

# **Materials** 

All the solvents and reagents were purchased and used directly without further purification. Nickel oxide (NiO) nanoparticles, organic halide salts (formamidinium iodide (FAI), lead iodide (PbI2), [6,6]-phenyl-C61-butyric acid methyl ester (PC61BM) were purchased from Advanced Election Technology Co., Ltd. Methylamine hydrochloride (MACl), [4-(3,6-dimethyl-9H-carbazol-9yl)butyl]phosphonic acid (Me-4PACz), cesium iodide (CsI), and bathocuproine (BCP) were obtained from TCI America. Piperazinium iodide (PI) was purchased from Xi’an Yuri Solar Co., Ltd (China). Benzoic acid (BA), trimesic acid (TA), and 4,4',4''-nitrilotribenzoicacid (NA) were purchased from Aladdin Biochemical Technology Co., Ltd. Unless stated otherwise, all solvents and reagents were purchased from Sigma-Aldrich and used as received. 

# **Perovskite precursor and film preparation** 

For the composition FA0.95Cs0.05PbI3, 1.5 M perovskite precursor solution was prepared by mixing 

14 

CsI, FAI, and PbI2 in DMF: DMSO = 4:1(V/V) mixed solvent subject to the stochiometric ratio. Additional 3 mol% PbI2 and 10 mol% MACl were added to the precursor for better crystallization and perovskite phase transformation. The perovskite precursor (60 μL) was spin-coated at 4000 rpm for 50 s (5 s acceleration to 4000 rpm). 200 μL ethyl acetate was dropped on the film at 20 s before the end of the spinning program. The film was immediately annealed at 100 °C for 30 min. 

# **Small-area devices fabrication** 

Glass/ITO substrates were cleaned thoroughly by sequential ultra-sonication for 20 min in a detergent solution, distilled water, alcohol, and acetone. Then, the substrates were dried with N2 and cleaned with UV ozone for 30 min before use. The NiO hole transport layer was formed by spincoating NiO nanoparticle ink with a concentration of 10 mg mL<sup>−1</sup> in a mixed solution of deionized water and IPA (3:1, V/V) onto the ITO substrate at 3000 rpm for 20 s, then annealed at 110 °C for 10 min in an air environment and then transferred to a N2-filled glovebox. Subsequently, the solutions of Me-4PACz and candidate molecules (benzoic acid, trimesic acid, and 4,4',4''nitrilotribenzoicacid) with the same concentration (1 mmol L<sup>−1</sup> in absolute ethanol) were mixed in a molar ratio of 3:1 in characterization and device fabrication and then were spin-coated on the NiO film at 3000 rpm for 20 s, followed by annealing at 100 °C for 10 min to form mixed Me-4PACz HSLs. Perovskite films were spin-coated on NiO/mixed HSLs (or NiO/Me-4PACz) following the abovementioned method. For the interfacial passivation layer, PI with the concentration of 0.4 mg mL<sup>−1</sup> in IPA was spin-coated on top of perovskite films (5000 rpm, 30 s) and annealed at 100 °C for 5 min. Then, the PCBM solution (20 mg mL<sup>−1</sup> , in chlorobenzene) was spin-coated on top of the interfacial passivation layer as an electron transport layer at 3000 rpm for 30 s and annealed at 70 °C for 10 min. Sequentially, the saturated solution of BCP in methanol was dynamically spin-coated on the PCBM layer at 6000 rpm for 30 s and annealed at 70 °C for 10 min. The device was completed by thermally evaporating the electrode of 100 nm Ag with a controlled evaporation rate of 0.1 to 0.5 Å s<sup>−1</sup> , respectively in a vacuum chamber (< 3×10<sup>−4</sup> Pa). The Bi/Ag (20 nm/100 nm) electrodes in the devices used for stability tests were thermally evaporated with a controlled evaporation rate of 0.1 and 0.1-0.5 Å s<sup>−1</sup> , respectively. 

# **Mini-modules fabrication** 

15 

The mini-modules were fabricated on a 5.0 cm × 5.0 cm sized glass/FTO substrate. The cleaned glass/FTO substrate was laser-scribed using a 532 nm nanosecond laser machine with a power of 2 W to form P1 lines-isolated cell units. The substrates were dried with N2 and cleaned with UV ozone for 30 min before use. 300 μL of the FA0.95Cs0.05PbI3-based perovskite precursor were spin-coated onto the substrates (5.0 cm × 5.0 cm) at 4000 rpm for 50 s (5 s acceleration to 4000 rpm). 500 μL ethyl acetate was slowly dropped on the film at 20 s before the end of the spinning program. After depositing the BCP layer, the module was re-etched to form P2 lines with a power of 0.3 W. Finally, it formed effective monolithically interconnected modules by scribing the Ag (100 nm) electrode using a power of 0.3 W to form P3 lines. P4 is an etching procedure for cleaning the edge of the modules, the laser used in P4 is the same as P1. The fabricated modules typically have 5 sub-cells, and each sub-cell has a width of 6.8 mm. The total scribing line width was ~0.17 mm, giving a GFF of ~97.5% with an aperture area of 11.1 cm<sup>2</sup> . 

# **Characterization** 

The XRD characterizations were recorded on an Empyrean X-ray diffractometer with Cu K𝛼 radiation (PANalytical B.V. Co., Netherlands). The top-viewing and the cross-sectional images of the samples were obtained by a field-emission SEM (FEI NOVA NanoSEM 450). Ultraviolet-visible (UV-vis) absorption spectra were characterized on a UV-Vis spectrometer (PerkinElmer Co., USA). The GIWAXS measurement was carried out with the Xeuss 3.0. The incident angle was 0.5°. The GIXRD patterns were acquired in the air by using a Rigaku Smartlab with Cu Kα radiation in the 2 _θ_ range of 30.6-32.6°. The steady-state photoluminescence (PL) spectra were recorded by the Edinburgh FLS920 fluorescence spectrometer (Edinburgh Co., UK) with an excitation source wavelength of 532 nm. The time-resolved photoluminescence spectrum (TRPL) was obtained by a fluorescence spectrometer with an excitation wavelength of 532 nm (DeltaFlex, HORIBA). The FLIM was obtained from FLIM300. The UPS spectra were investigated by an AXIS‐ULTRA DLD‐ 600W Ultra spectrometer (Kratos Co. Japan) with a non–monochromated He Iα photon source (h _ν_ = 21.22 eV). The water contact angle was recorded by Drop Shape Analyzer DSA100 from KRUSS. The in-situ PL spectra measurement was performed by a laser with the wavelength of 532 nm and this device was fixed on a micro-spectral measurement system, ProSp-Micro40-VIS (Hangzhou SPL Photonics Co., LTD, China), together with spectrograph (Ocean Insight, USA). An XPS system 

16 

(Thermo ESCALAB 250XI) equipped with a monochromatic Al Kα X-ray source (1486.6 eV) operating at 100 W was used to acquire the XPS spectra. KPFM measurements were conducted using a dimension icon scanning probe microscope (Asylum Research, MFP-3D-Stand Alone) in the tapping mode. The _J_ – _V_ curves of the devices were recorded with a black mask with an active area of 0.057 cm<sup>2</sup> by a Keithley 2400 source measurement unit and a solar simulator (Oriel, model 9119) with an AM1.5G spectrum. The light intensity was calibrated with a reference silicon solar cell (KG3, Enlitech). The scanning speed for both forward and reverse scans was 0.01 V s<sup>−1</sup> . The EQE spectra were measured under DC mode with the EQE system (Saifan) using monochromatic light of 1 × 10<sup>16</sup> photons cm<sup>−2</sup> . The transient photovoltage (TPV) measurements and Mott-Schottky plots were obtained by a Zennium electrochemistry workstation (Zahner, Germany). The photoluminescence quantum yield (PLQY) of the corresponding film was measured on QuantaMaster 8000 (HORIBA, Canada) with a 532 nm laser to photoexcite the samples placed in an integrating sphere. The laser’s intensity was calibrated by adjusting the power when it produced a 1-sun-equivalent current density from the devices at _J_ SC condition. 

# **Stability tests** 

The PSC’s encapsulation was processed according to our previous report<sup>33</sup> . After the corresponding encapsulation process, the fabricated devices were performed for operational stability tests. The operational stability of the encapsulated devices was measured by a commercial multichannel stability test system (Wuhan 91PVKSolar Co., Ltd.) operating in the MPP tracking mode at a temperature of 65 °C. The illumination was achieved by a 1-sun equivalent white-light LED and the light intensity was calibrated to achieve the same _J_ SC from the devices measured under a standard solar simulator (AM 1.5G, 100 mW cm<sup>−2</sup> ). For the damp heat test, we put the encapsulated devices in the environmental test chamber at 85 °C/85% RH and measured the PCEs periodically after the devices cooled to room temperature. 

# **Molecular dynamics simulations.** 

Classical molecular dynamics simulations for the perovskite/SAMs/NiO heterojunction used the LAMMPS program<sup>34</sup> . The equation of motions was integrated with a time step of 1 fs using the Velocity Verlet method<sup>35</sup> . The trajectories are propagated in a canonical ensemble (NVT) with the 

17 

Nosé-Hoover thermostat<sup>36,37</sup> , with a time constant of 0.1 fs. The perovskite and NiO surfaces were generated by the 16 × 17 × 3 supercell of FAPbI3 and the 25 × 26 × 2 supercell of NiO and the SAMs layer is set to 20 Å. The SAMs layer in four heterojunction models contains: (i) 90 Me4PACz molecules, (ii) 90 Me-4PACz and 30 BA molecules, (iii) 90 Me-4PACz and 30 NA molecules, (iv) 90 Me-4PACz and 30 TA molecules, which were randomly generated between the surfaces by the Packmol program<sup>38</sup> . Periodic boundary conditions were applied to the x and y directions, while two top perovskite layers and the bottom NiO layers were fixed. The velocities were initialized at 400 K and equilibrated in 10 ps, cooled to 298.15 K in the subsequent 10 ps, and then further equilibrated at 298.15 K in another 10 ps. The production run took 0.5 ns at 298.15 K. The surface adsorption analysis used our in-house code, which assigned SAMs to adjacent surfaces and computed the surface coverage by searching any atoms of SAMs above the surface within a distance threshold of 5 Å and radial threshold of 2 Å. The interactions of the perovskite surface employed the recently developed transferable perovskite force field<sup>39</sup> . The interactions of SAMs used the DREIDING force fields<sup>40</sup> , where the restrained electrostatic potential (RESP) charges<sup>41</sup> were computed at PBE0/cc-pVDZ level using the ORCA 5.0.3 program<sup>42</sup> . The interactions between the perovskite and SAMs use the universal force field<sup>43</sup> . The NiO surface was described by the INTERFACE force field<sup>44</sup> , which showed good compatibility with the DREIDING force field for simulating molecular adsorptions on metal oxides. The interactions between the perovskite and NiO surface were ignored. The molecular dynamics simulations for the heterojunctions with perovskite surface defects used the same setting as the adsorption simulation, except that we created a charged Pb vacancy on the perovskite surface. 

# **DFT calculations.** 

The geometry optimizations for surface adsorptions, molecular clusters, intrinsic surface defects, and passivated surface defects used the VASP code<sup>45</sup> with a plane wave (PW) basis set and projected augmented wave (PAW) pseudopotentials (PPs). We employed the PBE flavor of the GGA PPs, and long-range dispersion interactions were considered by the DFTD3 scheme. The kinetic energy cutoff is 500 eV for the expansion of the wavefunctions. The convergence thresholds were set to 1.0 × 10<sup>–6</sup> eV for energy and –0.05 eV/Å for the norm of the atomic forces. The adsorption calculations on the (100) surface of the perovskite and NiO used the 3 × 3 × 2 FAPbI3 and 5 × 5 × 2 NiO slabs, 

18 

respectively. The Hubbard corrections for Ni used U = 8 eV and J = 0.95 eV. The perovskite surface defect calculations used the 3 × 3 × 2 FAPbI3 slab including the VI, VPb, PbI, and IPb defects with various point charges. A 17 Å and 14 Å vacuum space were added to the perovskite and NiO slabs, respectively. Dipole corrections are applied to the z-direction for all adsorption calculations. All ionic optimizations were done at the gamma point and the bottom two atom layers were fixed during the optimizations. The charge densities of the perovskite defects were recomputed with a 2 × 2 × 1 k-point mesh centered at the gamma point for band structure calculations, including 40 points in the 2D k-space. 

# **Additional References** 

33. Chen, R. et al. Reduction of bulk and surface defects in inverted methylammonium- and bromide-free formamidinium perovskite solar cells. _Nat. Energy_ **8** , 839-849 (2023). 

34. Thompson, A. P. et al. LAMMPS-a flexible simulation tool for particle-based materials modeling at the atomic, meso, and continuum scales. _Comput. Phys. Commun._ **271** , 108171 (2022). 

35. Verlet, L. Computer "experiments" on classical fluids. I. Thermodynamical properties of Lennard-Jones molecules. _Phys. Rev._ **159** , 98 (1967). 

36. Nosé, S. A unified formulation of the constant temperature molecular dynamics methods. _J. Chem. Phys._ **81** , 511-519 (1984). 

37. Hoover. Canonical dynamics: Equilibrium phase-space distributions. _Phys. Rev. A_ **31** , 16951697 (1985). 

38. Martínez, L., Andrade, R., Birgin, E. G. & Martínez, J. M. PACKMOL: A package for building initial configurations for molecular dynamics simulations. _J. Comput. Chem._ **30** , 2157-2164 (2009). 

39. Seijas-Bellido, J. A. et al. Transferable classical force field for pure and mixed metal halide perovskites parameterized from first-principles. _J. Chem. Inf. Model._ **62** , 6423-6435 (2022). 

40. Mayo, S. L., Olafson, B. D. & Goddard, W. A. DREIDING: a generic force field for molecular simulations. _J. Phys. Chem._ **94** , 8897-8909 (1990). 

41. Bayly, C. I., Cieplak, P., Cornell, W. & Kollman, P. A. A well-behaved electrostatic potential 

19 

based method using charge restraints for deriving atomic charges: the RESP model. _J. Phys. Chem._ **97** , 10269-10280 (1993). 

42. Neese, F. Software update: The ORCA program system-Version 5.0. _Wires. Comput. Mol. Sci._ **12** , e1606 (2022). 

43. Rappé, A. K., Casewit, C. J., Colwell, K. S., Goddard III, W. A. & Skiff, W. M. UFF, a full periodic table force field for molecular mechanics and molecular dynamics simulations. _J. Am. Chem. Soc._ **114** , 10024-10035 (1992). 

44. Kanhaiya, K. et al. Accurate force fields for atomistic simulations of oxides, hydroxides, and organic hybrid materials up to the micrometer scale. _J. Chem. Theory Comput._ **19** , 8293-8322 (2023). 

45. Kresse, G. & Furthmuller, J. Efficient iterative schemes for _ab initio_ total-energy calculations using a plane-wave basis set. _Phys. Rev. B_ **54** , 11169-11186 (1996). 

**Acknowledgments:** The authors especially thank the Analytical and Testing Center of HUST for the facilities’ support of sample measurements. The authors thank computing resources supported by the Center for Computational Science and Engineering at Southern University of Science and Technology and Hoffmann Institute of Advanced Materials at Shenzhen Polytechnic University. **Funding:** The authors acknowledge the financial support from the National Key Research and Development Project funding from the Ministry of Science and Technology of China (2021YFB3800104), the National Natural Science Foundation of China (52002140, U20A20252), the Young Elite Scientists Sponsorship Program by CAST, the Natural Science Foundation of Hubei Province (2022CFA093), the Self-determined and Innovative Research Funds of HUST (2020kfyXJJS008), China Postdoctoral Science Foundation (2023M731172), and the Innovation Project of Optics Valley Laboratory (OVL2021BG008). H. J. S. thanks the European Union's Horizon Europe research and innovation program under grant agreement no. 101075330 of the NEXUS project for funding, the Engineering and Physical Science Research Council (EPSRC), UK under the grant numbers of EP/V010840/1. N.-G. P. is grateful for the financial support by the National Research Foundation of Korea (NRF) grants funded by the Korean government (MSIT) under contract NRF-2021R1A3B1076723 (Research Leader Program), NRF-2022M3J1A1085280 (Carbon Neutral Technology Program), RS-2023-00259096 (GRDC Cooperative Hub). 

20 

**Author contributions:** S. L., J. L., W. X., R. C., Z. S., and Y. Z. contributed equally to this work. W. C., N.-G. P., Z. L., and S. L. conceived the project. S. L., Z. S., R. C., and Y. Z. fabricated the devices. S. L., W. X., Z. S., Y. Z., R. C., J. W., F. R., Q. Z., H. R. and carried out the material and device characterizations. S. H. and M. K.-C. conducted the modeling of PLQE dependent on light intensity (two-trap level SRH model) under the supervision of H. J. S. S. L., H. L., and L. Q. carried out the GIXRD measurements. Y. J. and W. H. carried out the GIWAXS measurements. R. C., Y. Z., J. W., F. R., Q. Z, H. R., Y. J., W. H., and Y. G. provided useful suggestions for the paper. W. X. performed the DFT calculations under the supervision of Z. Y., X. L. performed the DFT calculations under the supervision of J. L. and  Y. Z., and J. L. performed the MD simulations and analyzed all computational data. S. L., J. J., Z. S., R. C., B. X., Z. L., and W. C. analyzed all experimental data. S. L., J. L., W. X., R. C., Z. S., and Y. Z. prepared the manuscript under the supervision of Z. L., N.-G. P., and W. C. All authors revised and proofed the written manuscript. 

**Competing interests:** H. J. S. is a co-founder and the Chief Scientific Officer of Oxford PV, a company commercializing perovskite solar cells. 

**Data availability** **<mark>:</mark>** <mark>The data that support the findings of this study are available from the corresponding authors upon reasonable request.</mark> 

**Correspondence and requests for materials** should be addressed to Zonghao Liu, Nam-Gyu Park, or Wei Chen. 

21 



22 



23 



24 



25 

