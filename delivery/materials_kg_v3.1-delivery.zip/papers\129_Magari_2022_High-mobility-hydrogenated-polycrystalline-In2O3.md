# High-mobility hydrogenated polycrystalline In2O3 (In2O3:H) thin-film transistors

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 202 |
| 作者 | Y. Magari, Taiki Kataoka, W. Yeh, M. Furuta |
| DOI | 10.1038/s41467-022-28480-9 |
| 源文件 | 029_Magari_2022_High-mobility-hydrogenated-polycrystalline-In2O3.pdf |

---


# ARTICLE 

https://doi.org/10.1038/s41467-022-28480-9 

**OPEN** 



High-mobility hydrogenated polycrystalline In2O3 (In2O3:H) thin-film transistors Yusaku Magari 1✉, Taiki Kataoka2, Wenchang Yeh1 & Mamoru Furuta2,3 

Oxide semiconductors have been extensively studied as active channel layers of thin-film transistors (TFTs) for electronic applications. However, the field-effect mobility (μFE) of oxide TFTs is not sufficiently high to compete with that of low-temperature-processed polycrystallineSi TFTs (50–100 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ). Here, we propose a simple process to obtain high-performance TFTs, namely hydrogenated polycrystalline In2O3 (In2O3:H) TFTs grown via the low-temperature solid-phase crystallization (SPC) process. In2O3:H TFTs fabricated at 300 °C exhibit superior switching properties with µFE = 139.2 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , a subthreshold swing of 0.19 Vdec<sup>−1</sup> , and a threshold voltage of 0.2 V. The hydrogen introduced during sputter deposition plays an important role in enlarging the grain size and decreasing the subgap defects in SPC-prepared In2O3:H. The proposed method does not require any additional expensive equipment and/or change in the conventional oxide TFT fabrication process. We believe these SPC-grown In2O3:H TFTs have a great potential for use in future transparent or flexible electronics applications. 

> 1 Graduate School of Natural Science and Technology, Shimane University, Matsue, Shimane 690-8504, Japan. 2 School of Environmental Science and Engineering, Kochi University of Technology, Kami, Kochi 782-8502, Japan.<sup>3</sup> Center for Nanotechnology, Research Institute, Kochi University of Technology, Kami, Kochi 782-8502, Japan.<sup>✉</sup> email: magari.yusaku@riko.shimane-u.ac.jp 

1 

NATURE COMMUNICATIONS | (2022) 13:1078 | https://doi.org/10.1038/s41467-022-28480-9 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-28480-9 

ide-bandgap oxide semiconductors (OSs) have been extensively studied as active channel layers of thinWfilm transistors (TFTs) for next-generation flat-panelat-panel 

filmlm transistors (TFTs) for next-generation flat-panelat-panel displays<sup>1,2</sup> , nonvolatile memories<sup>3</sup> , inverters<sup>4</sup> , various sensors<sup>5,6</sup> , Schottky devices<sup>7,8</sup> , and so on. Among OSs, amorphous In–Ga–Zn–O (a-IGZO) TFTs have now become the backplane standard for active-matrix liquid-crystal displays (AMLCDs) and active-matrix organic light-emitting diode (AMOLED) displays because of their reasonable field-effect mobility (μFE) of over 10 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , extremely low leakage current, low process temperature (<350 °C), and large-area scalability<sup>9,10</sup> . Although the μFE value of a-IGZO TFTs is more than ten times higher than that of hydrogenated amorphous Si (a-Si:H) TFTs (<1 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ), it is not sufficiently high to compete with that of low-temperature-processed polycrystalline-Si (LTPS) TFTs (50–100 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> )<sup>11</sup> . The main disadvantages of LTPS TFTs are a relatively high process temperature (450–550 °C) and an expensive crystallization process. The high μFE values of OS TFTs mean these devices could be used in fields that have been dominated by LTPS TFTs and in transparent and flexible devices that are incompatible with Si. Numerous types of approaches to enhance the μFE value of OS TFTs have been investigated, including cation composition<sup>12,13</sup> , multiple channel structures<sup>14,15</sup> , dual-gate architecture<sup>16,17</sup> , metal capping layer structures<sup>18,19</sup> , post treatment<sup>20,21</sup> , and their combination. Among these, cation composition control is the most promising method. It requires no extra complex process for integrating OS TFTs. In-rich OSs have been studied extensively. The large spatial spread of the In 5s orbital with a large overlap can provide a facile electron transport path with a low electron effective mass<sup>22</sup> . However, undoped In2O3 films exhibit a high background electron concentration (10<sup>19</sup> –10<sup>21</sup> cm<sup>−3</sup> )<sup>23,24</sup> , which is attributable to the presence of native defects, such as oxygen vacancies, making it difficult to control the threshold voltage of the TFTs<sup>25,26</sup> . To suppress the carrier concentration in In2O3, elements such as Ga, Hf, Si, Al, and W were added, which have large bond dissociation energies with oxygen<sup>12</sup> . Many AOS TFTs have been explored with multicomponent oxide semiconductors, such as In–W–Zn–O<sup>27</sup> , Al–In–Sn–Zn–O<sup>28</sup> , and In–Ga–Zn–Sn–O<sup>29</sup> . However, multicomponent oxides complicate the composition control of the deposited film. Moreover, multimetal cations cause potential fluctuation near the conduction band minimum, which might hinder electron transport<sup>30</sup> . 

Recently, crystalline OSs have been proposed to enhance the carrier mobility because the disorder-induced subgap states can be suppressed via lattice ordering. Yang et al. reported a μFE value of 60.7 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> for a TFT obtained using polycrystalline In–Ga–O annealed at 700 °C<sup>31</sup> . Although high annealing temperatures result in better electrical properties of the oxide active channel layer, such high temperatures are unsuitable for device application on glass or plastic substrates. Our group reported a μFE value of 50.6 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> for a TFT obtained using hydrogenated polycrystalline In–Ga–O formed via solid-phase crystallization (SPC) at 300 °C<sup>32</sup> . 

This study proposes a simple material and a simple process to obtain high-performance TFTs, namely hydrogenated polycrystalline In2O3 (In2O3:H) TFTs grown via the low-temperature SPC process. In2O3:H TFTs fabricated at 300 °C exhibit superior switching properties with µFE = 139.2 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , a subthreshold swing (SS) of 0.19 V dec<sup>−1</sup> , and a threshold voltage (Vth) of 0.2 V. The hydrogen introduced during sputter deposition plays an important role in enlarging the grain size and decreasing the subgap defects in SPC-prepared In2O3:H. The proposed method has great potential for future transparent or flexible electronics applications. 

## Results 

Structural properties of the In2O3 and In2O3:H films. Figures 1a, b show the XRD patterns of the 50-nm-thick In2O3 and In2O3:H films deposited at various R[H2] values and at a constant R[O2] of 1%. For the as-deposited films (Fig. 1a), the In2O3 film without H2 introduction exhibited a clear crystalline nature with the (222) preferred orientation of the cubic bixbyite In2O3 crystal. There was no noticeable peak for the In2O3:H films deposited at R[H2] values of 3 and 5%. This result indicates that H2 addition suppresses the growth of crystallites during deposition. After annealing at 250 °C in nitrogen for 1 h, the amorphous phase of In2O3:H changed to the crystalline one with the (222) preferred orientation. The angles of the diffracted peaks are in good agreement with the In2O3 powder data (ICSD code: 14388). Moreover, the crystallized films exhibited smaller fullwidth at half-maximum values of the (222) reflection than the film deposited without hydrogen introduction, indicating larger crystallite sizes and smaller strains in the In2O3:H films. 

Figure 1c–h depict the EBSD images along the normal direction for the In2O3 and In2O3:H films with and without annealing at 250 °C in nitrogen. For the as-deposited films (Fig. 1c–e), a randomly oriented small grain structure embedded in the amorphous matrix can be observed in the In2O3 film without H2 introduction. The grain structure disappeared upon increasing the R[H2] value to 5%. In contrast, a huge grain structure appeared for In2O3:H deposited at R[H2] = 5% after annealing at 250 °C (Fig. 1h), indicating SPC occurrence. This is consistent with the results of the XRD analysis shown in Fig. 1a, b. The corresponding area fractions of each lateral grain size are shown in Fig. 1i, j. The detected minimum grain size is around 15 nm, which is limited by the electron beam size of the EBSD measurements. For the as-deposited films (Fig. 1i), all films showed the maximum area fraction for a grain size of 15 nm; however, a small proportion of the area fraction with a grain size of ~70 nm was detected in the In2O3 film, indicating nuclei in the as-deposited film. After annealing at 250 °C (Fig. 1j), the peak of the area fraction shifted toward a larger grain size as R[H2] increased, and the In2O3:H film deposited at R[H2] = 5% showed a maximum area fraction of 23% at a grain size of 140 nm. Furthermore, as R[H2] increased from 0 to 5%, the area fraction of the minimum grain size below 15 nm significantly decreased, and only a few small grains were in between the large grains, as shown in Fig. 1h. Similar results were observed for films annealed at 250 °C in ambient air (shown in Supplementary Fig. 1). The EBSD results show that the nuclei density in the as-deposited film was suppressed by introducing hydrogen during sputtering. Because of the reduction in the nuclei density in the initial In2O3:H film, the grain size of the In2O3:H film could be enlarged through SPC. Thus, the XRD and EBSD results indicate that controlling the crystallinity and nuclei density in the as-deposited film are key factors to achieve high-quality In2O3:H films. 

Electrical and optical properties of the In2O3 and In2O3:H films. Figure 2a–d show the carrier concentration (Ne) and Hall mobility (µH) of the 50-nm-thick In2O3 and In2O3:H films deposited at various R[H2] values as a function of the annealing temperature (Tann). Koida et al. reported that both the Ne and µH of the SPC-prepared In2O3:H films decrease dramatically for the films annealed in vacuum at Tann > 400 °C due to the desorption of the H2O and H2 gases from the films and additional microscopic defects inside the grains<sup>33</sup> . The electrical properties of OSs are strongly affected by the annealing atmosphere<sup>34</sup> ; thus, annealing treatments at temperatures ranging from 150 to 350 °C in nitrogen and ambient air were examined. For the as-deposited films, Ne increased from 7.1 × 10<sup>19</sup> to 5.7 × 10<sup>20</sup> cm<sup>−3</sup> upon increasing R[H2] from 0 to 5%, as shown in Fig. 2a. Since 

2 

NATURE COMMUNICATIONS | (2022) 13:1078 | https://doi.org/10.1038/s41467-022-28480-9 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-28480-9 



Fig. 1 Structural properties of the In2O3 and In2O3:H films. XRD patterns of the In2O3 and In2O3:H films deposited at different R[H2] values and at a constant R[O2] value of 1% a before and b after annealing at 250 °C in N2. EBSD images of the In2O3 and In2O3:H films deposited at different R[H2] values c–e before and f–h after annealing at 250 °C in N2. Area fraction of each grain size obtained from the In2O3 and In2O3:H films deposited at different R[H2] values i before and j after annealing at 250 °C in N2. 

hydrogen acts as a shallow donor in In2O3<sup>35</sup> , the increase in the Ne of the as-deposited In2O3:H film upon increasing R[H2] is attributable to hydrogen doping effects. The In2O3 film deposited without hydrogen introduction exhibited an almost constant Ne value over the whole range of investigated Tann values irrespective of the annealing atmosphere, as shown in Fig. 2a, c. In contrast, there was a strong dependence of Ne on the annealing atmosphere for the In2O3:H films. The Ne of the In2O3:H film annealed in N2 gradually decreased with increasing Tann (Fig. 2a), whereas the Ne of the In2O3:H film annealed in air rapidly decreased for Tann > 

200 °C (Fig. 2c). In addition, the Ne reduction was remarkable in the In2O3:H film deposited at a higher R[H2] value. As a result, an appropriate Ne value of 2.0 × 10<sup>17</sup> cm<sup>−3</sup> for TFT fabrication was obtained at Tann = 300 °C for the In2O3:H film deposited at 

R[H2] = 5%; this Ne value is over two orders of magnitude lower than that of the In2O3 film deposited without hydrogen introduction (3.0 × 10<sup>19</sup> cm<sup>−3</sup> ). Such a large decrease in the Ne value of the In2O3:H films has not been reported before. Although adding H2 induced the formation of free carriers in the asdeposited films, the Ne of the films could be reduced via the relatively low-temperature SPC process and became comparable to that of single-crystalline epitaxial In2O3 films deposited at 650 °C (~1 × 10<sup>17</sup> cm<sup>−3</sup> )<sup>36</sup> . 

Regarding the Hall mobility of the films, In2O3 without hydrogen introduction exhibited an almost constant µH value over the entire range of investigated Tann values irrespective of the annealing atmosphere, as shown in Fig. 2b, c. Upon annealing in N2 at Tann = 200 °C, the µH of In2O3:H increased to 78.6 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> at 

3 

NATURE COMMUNICATIONS | (2022) 13:1078 | https://doi.org/10.1038/s41467-022-28480-9 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-28480-9 



Fig. 2 Electrical and optical properties of the In2O3 and In2O3:H films. a Ne and b µH of In2O3 and In2O3:H deposited at different R[H2] values as a function of the annealing temperature in N2. c Ne and d µH of In2O3 and In2O3:H deposited at different R[H2] values as a function of the annealing temperature in ambient air. e The relationship between µH and Ne for the films annealed at Tann > 200 °C in N2 and ambient air. f Optical absorption spectra of the 50-nm-thick In2O3 and In2O3:H films deposited at different R[H2] values before and after annealing at 250 °C in ambient air. In2O3 films deposited without oxygen and hydrogen are also shown for comparison. 

R[H2] = 3% and 104.0 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> at R[H2] = 5%, indicating that the SPC started at a Tann value between 150 and 200 °C. Furthermore, the increased µH is attributable to the increased grain size, as shown in Fig. 1f–h. As Tann increased, the µH of In2O3:H gradually decreased (Fig. 2b). Upon annealing in air (Fig. 2d), the maximum µH of In2O3:H decreased slightly to 67.1 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> at R[H2] = 3% and 81.2 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> at R[H2] = 5%, and the decrease in µH for Tann > 250 °C was confirmed. 

To understand the transport properties of the In2O3:H films after SPC, the relationship between µH and Ne for the films annealed in the range of temperatures between 200 °C and 350 °C in N2 and ambient air was summarized, as shown in Fig. 2e. The Ne of the In2O3:H film could be controlled by up to three orders of magnitude. Moreover, for the Ne range between 10<sup>19</sup> and 10<sup>20</sup> cm<sup>−3</sup> , µH increases with increasing R[H2], which is attributable to the suppression of grain boundary scattering due to the increasing grain size. For all the films, µH increased with increasing Ne. In general, the grain boundaries have a small impact on µH in transparent conductive oxides with high Ne (>10<sup>20</sup> cm<sup>−3</sup> ) because electrons can tunnel through the narrow width (<1 nm) of the grain barriers at high Ne values (>10<sup>20</sup> cm<sup>−3</sup> ). However, grain boundary scattering is a dominant 

factor that limits the µH in films with lower Ne<sup>37</sup> . Thus, the observed decrease in µH with decreasing Ne (Fig. 2e) is due to grain boundary scattering. Although the µH of In2O3:H decreased for Ne < 10<sup>19</sup> cm<sup>−3</sup> , carriers (with number in the range of 10<sup>19</sup> –10<sup>20</sup> cm<sup>−3</sup> ) will be generated at the In2O3:H/gate insulator interface of the TFTs when applying a voltage to the gate<sup>15</sup> ; thus, a high µFE can be expected in In2O3:H TFTs. 

Figure 2f shows the optical absorption (α) spectra of the In2O3 and In2O3:H films before and after annealing at 250 °C in ambient air. The green line represents the In2O3 film deposited without oxygen and hydrogen (only Ar gas), which is shown for comparison. The spectral features that arise as the photon energy exceeds 2.9 eV are due to the absorption associated with the interband transition in In2O3, whereas the features that arise when the photon energy is below 1.5 eV are due to free carrier absorption. The absorption in the subgap region (<2.9 eV) dropped as R[O2] increased from 0 to 1%, suggesting that oxygen deficiencies, which give rise to subgap defects, are compensated when sputtering in an oxidizing atmosphere. When hydrogen is added during sputter deposition, the absorption is enhanced in the subgap region for the as-deposited films, especially in the 

4 

NATURE COMMUNICATIONS | (2022) 13:1078 | https://doi.org/10.1038/s41467-022-28480-9 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-28480-9 

photon energy region below 1.5 eV, indicating that free electron absorption is increased due to the hydrogen doping effect. On the other hand, after annealing at 250 °C in ambient air (dashed line), the absorption across the subgap of the In2O3:H film decreased significantly and was lower than that of the In2O3 film. Since subgap defects are generated from native defects, such as oxygen vacancies, as described above, it can be inferred that oxygen vacancies were efficiently reduced in In2O3:H via SPC in ambient air. This result is consistent with the Hall effect measurements, where it was found that Ne decreased from 5.7 × 10<sup>20</sup> to 2.0 × 10<sup>18</sup> cm<sup>−3</sup> upon annealing in air at 250 °C, as shown in Fig. 2c. The structural, electrical, and optical properties of the In2O3:H films show that the hydrogen introduced during sputter deposition plays an important role in enlarging the grain size and decreasing the subgap defects after SPC, increasing µH and decreasing Ne. However, a more detailed study will be necessary to carry out quantitative evaluations of the carrier generation and scattering in the SPC-prepared In2O3:H films. 

In2O3:H TFT characteristics. Figure 3a shows the picture and schematic cross-sectional view of the fabricated In2O3:H TFT. All TFTs were fabricated using annealing in ambient air at 300 °C. Figure 3c–e show typical transfer characteristics of the TFTs with 

In2O3 and In2O3:H channels deposited at various R[H2] values. The variations of µFE, subthreshold swing (SS), threshold voltage (Vth), and hysteresis (ΔV) were evaluated from ten TFTs on the same substrate. The µFE was calculated from the linear transfer characteristics as µFE = Lgm/(WCoxVds) at Vds = 0.1 V, where gm is the transconductance, Cox is the oxide capacitance of the gate insulator, and Vds is the drain voltage. Vth was defined by gate voltage (Vgs) at drain current (Ids) of 1 nA, and SS was extracted from Vgs, which required an increase in the Ids from 10 to 100 pA. The In2O3 TFT without H2 introduction (Fig. 3c) did not exhibit any switching (conductive behavior). By contrast, the In2O3:H TFT deposited at R[H2] = 5% exhibited a switching with an extremely high µFE of 139.2 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , a SS of 0.19 V dec<sup>−1</sup> , a Vth of 0.2 V, and a ΔV of 0.3 V as shown in Table 1. The TFT with In2O3:H deposited at R[H2] = 5% showed a slightly small SS value (0.19 V dec<sup>−1</sup> ) compared with that of the TFT with In2O3:H deposited at R[H2] = 3% (0.41 V dec<sup>−1</sup> ). The subgap density of states (Dsg) at the Fermi level was calculated as SS = dVgs/dlogIds = ln10 kBT/e (1 + eDsg/Cox), where kB is Boltzmann’s constant and e is the elementary electric charge<sup>10</sup> . The Dsg decreased from 1.3 × 10<sup>12</sup> to 4.7 × 10<sup>11</sup> cm<sup>−2</sup> eV<sup>−1</sup> by increasing the R[H2] value from 3 to 5%. This result suggests that the disorderoriginated subgap defect states near the conduction band minimum can be reduced in the In2O3:H channel deposited at 



Fig. 3 In2O3:H TFT characteristics. a Photograph and schematic cross-sectional view of the SPC-prepared In2O3:H TFTs. b HRTEM image and corresponding SAED pattern of the active layer of the TFT with In2O3:H channel deposited at R[H2] = 5%. c–e Typical transfer characteristics of the TFTs with In2O3 and In2O3:H channels deposited at various R[H2] values. Variations of f µFE, g SS, h Vth, and i ΔV evaluated from ten TFTs. 

5 

NATURE COMMUNICATIONS | (2022) 13:1078 | https://doi.org/10.1038/s41467-022-28480-9 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-28480-9 

Table 1 Summary of the TFT properties. 

|R[O2] (%)|R[H2] (%)|µFE (cm<sup>2 </sup>V<sup>−1 </sup>s<sup>−1</sup>)|SS (V dec<sup>−1</sup>)|Vth (V)|ΔV (V)|Dsg (cm<sup>−2 </sup>eV<sup>−1</sup>)|
|---|---|---|---|---|---|---|
|1|0|–|–|–||–|
|1|3|142.0 (1.2)|0.41 (0.09)|0.1 (0.3)|0.2 (0.1)|1.3 × 10<sup>12</sup>|
|1|5|139.2 (3.0)|0.19 (0.02)|0.2 (0.2)|0.3 (0.1)|4.7 × 10<sup>11</sup>|



The average values and standard deviations (σ) of the characteristics of ten TFTs on the same substrate. σ are shown in parentheses. 



Fig. 4 Reliability of the In2O3:H TFT. Changes in the transfer characteristics of the In2O3:H (R[H2] = 5%) TFT during the a PBS and b NBS tests. The Vgs values under the PBS and NBS tests were +20 and −20 V, respectively. 

R[H2] = 5%, which is confirmed by the optical measurements of the films shown in Fig. 2f. 

The resulting transfer performance of the SPC-prepared In2O3:H TFT (R[H2] = 5%) was superior to that of previously reported oxide-based TFTs<sup>38</sup> . Although the µH of the In2O3:H (R[H2] = 5%) films decreased to 14.9 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> with Ne of 2.0 × 10<sup>17</sup> cm<sup>−3</sup> by annealing at 300 °C as shown in Fig. 2c, extremely high µFE was obtained from the TFTs because a large number of carriers (10<sup>19</sup> –10<sup>20</sup> cm<sup>−3</sup> ) was generated at the In2O3:H/gate insulator interface when applying a voltage to the gate, which allows electrons to tunnel through the narrow width (<1 nm) of the grain barriers at high Ne values. The high µFE and steep SS of the In2O3:H TFTs can be attributed to the high crystallinity of In2O3:H, especially near the In2O3:H/SiO2 gate insulator interface. 

Figure 3b shows a cross-sectional conventional bright-field HRTEM image and selective area electron diffraction (SAED) pattern obtained from the SPC-prepared In2O3:H TFT (R[H2] = 5%). A clear lattice image was observed over the entire thickness of the In2O3:H channel. Moreover, there was a single crystal-like diffraction pattern in the SAED pattern, even in the thin layers, roughly at a distance of 5 nm from the SiO2 gate insulator without detectable diffuse ring patterns, which would be attributable to an amorphous phase. This observation explains the high µFE of 139.2 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> in the In2O3:H TFTs, which is comparable to the µH of epitaxial single-crystal In2O3 films (~160 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> )<sup>39</sup> . In addition, although In2O3:H is a polycrystalline film, the standard deviations (σ) of µFE, SS, Vth, and ΔV of the In2O3:H TFT (R[H2] = 5%) were 3.0 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , 0.02 V dec<sup>−1</sup> , 0.2 V, and 0.1 V, respectively, indicating high uniformity of the TFT characteristics (shown in Fig. 3f–i and Supplementary Fig. 2). 

To investigate the reliability of the SPC-prepared In2O3:H TFT (R[H2] = 5%), positive-bias stress (PBS) and negative-bias stress (NBS) tests were carried out under a humidity of 50%. The gate stress voltages for the PBS and NBS were +20 and −20 V, respectively. Figure 4a, b show the changes in the transfer characteristics of the In2O3:H TFT during the PBS and NBS tests. The In2O3:H TFT showed no significant positive shift in Vth (only +0.02 V) under the PBS test, indicating the negligible interfacial 

trap states in the In2O3:H/SiO2 gate insulator interface as well as the high quality of the In2O3:H channel layer. In contrast, a large Vth shift of –4.4 V was observed for the NBS test, as shown in Fig. 4b. Furthermore, the Vth shift became more significant when the NBS test was conducted at a higher humidity of 70% (shown in Supplementary Fig. 3). Water molecules are coupled to the backchannel of the IGZO TFTs, and excess electrons are donated to the channel under NBS, resulting in a negative Vth shift<sup>40,41</sup> . Applying a passivation layer to the TFTs is effective in minimizing the influence of the atmospheric environment; however, hydrogen can diffuse into the channel through the passivation layer and increase the Ne of the channel<sup>42</sup> . Although the SiO2 passive layer was applied to the SPC-grown In2O3:H TFT, as shown in Fig. 3a, its protection ability was insufficient because the SiO2 film was deposited via sputtering at RT. Hence, it is believed that the reliability of In2O3:H TFTs can be improved by selecting the appropriate passivation layer, such as SiN, Al2O3, or Y2O3. 

## Discussion 

In this study, we demonstrate the high-performance polycrystalline In2O3:H TFTs using a low-temperature SPC process. To ensure the amorphous state of the as-deposited In2O3:H film, a moderate amount of H2 was introduced into the sputtering system during the In2O3:H deposition. The as-deposited amorphous In2O3:H film converted into a polycrystalline In2O3:H film with a grain size of around 140 nm via low-temperature SPC (at a temperature below 200 °C). As a result, a high µH of 104.0 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> was obtained for the In2O3:H film. This µH value is five times higher than that of the In2O3 film without H2 introduction during sputtering. Furthermore, the Ne of the SPCgrown In2O3:H film decreased significantly to 2.0 × 10<sup>17</sup> cm<sup>−3</sup> after annealing at 300 °C in ambient air; this Ne value is two orders of magnitude lower than that of the In2O3 film without H2 introduction. Thus, introducing hydrogen during sputtering followed by annealing in ambient air is an effective method for improving both the crystallinity and the Ne value of In2O3:H films. The obtained In2O3:H film was employed as the channel of a TFT, and the resulting In2O3:H TFT exhibits an extremely high 

6 

NATURE COMMUNICATIONS | (2022) 13:1078 | https://doi.org/10.1038/s41467-022-28480-9 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-28480-9 

µFE of 139.2 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , an appropriate Vth of 0.2 V, and a small SS of 0.19 V dec<sup>−1</sup> . HRTEM analysis of the TFT revealed the high crystallinity of cubic bixbyite near the In2O3:H/SiO2 gate dielectric interface, which contributed to the high µFE of the TFT. The proposed method does not require any additional expensive equipment and/or change in the conventional oxide TFT fabrication process. Moreover, composition control of binary In2O3 films is easier than that of ternary and quaternary semiconductors. We believe that these SPC-grown In2O3:H TFTs are promising candidates for use in future transparent or flexible electronics applications. 

## Methods 

Fabrication of In2O3:H TFTs. In2O3:H TFTs were fabricated on a heavily doped p- type Si substrate with a 100-nm-thick thermally grown SiO2. The doped p-type Si substrate and the SiO2 were used as the gate electrode and the gate insulator. The 30-nm-thick In2O3 and In2O3:H channels were deposited via pulsed direct-current (DC) magnetron sputtering without substrate heating from a ceramic In2O3 target using a mixture of Ar, O2, and H2 gases. The O2 and H2 gas flow ratios are R[O2] = O2/(Ar + O2 + H2) and R[H2] = H2/(Ar + O2 + H2), respectively. For the Ar + O2-sputtered In2O3 film, R[O2] was set to 1% without H2 introduction. For the Ar + O2 + H2-sputtered In2O3 film (In2O3:H), R[H2] varied from 3 to 5%, whereas R[O2] was fixed at 1%. The deposition pressure and DC power were maintained at 0.6 Pa and 50 W, respectively. The base pressure before gas introduction was below 6 × 10<sup>−5</sup> Pa. The In2O3 and In2O3:H films were then annealed in ambient air at 300 °C for 1 h. After annealing, a 100-nm-thick SiO2 film was deposited via reactive sputtering without substrate heating. This film served as a passive layer. Subsequently, Al source/drain electrodes were deposited via sputtering. Finally, In2O3 and In2O3:H TFTs were annealed at 250 °C in ambient air for 1 h. The In2O3, SiO2, and Al films were deposited through a shadow mask. Both the channel length and the width were 300 µm. 

Characterization of the In2O3:H films and TFTs. Structural, electrical, and optical measurements were conducted on the 50-nm-thick In2O3 and In2O3:H films deposited on a synthetic quartz substrate. The films’ structural changes were evaluated through X-ray diffraction (XRD) (Philips corp., X’pert) with CuKα radiation and electron backscattering diffraction (EBSD) (EDAX-TSL Hikari High Speed EBSD Detector). The films’ carrier concentrations (Ne) and Hall mobility (µH) were determined via Hall effect measurements (Accent, HL5500PC) using the van der Pauw geometry at room temperature (RT). The films’ optical properties were measured via spectrophotometry (Hitachi, U-4100). The current–voltage characteristics were measured using a semiconductor parameter analyzer (Keysight, E5270B) at RT in the dark. High-resolution transmission electron microscopy (HRTEM) (JEOL, JSM-7001F) analysis was also conducted to observe the microstructure of the In2O3:H channel in the TFTs. 

## Data availability 

The authors declare that the all the data supporting the finding of this study are available within this article and its Supplementary Information files and are available from the corresponding author on reasonable request. 

Received: 31 August 2021; Accepted: 11 January 2022; 



7. Magari, Y. et al. Record-high-performance hydrogenated In-Ga-Zn-O flexible Schottky diodes. ACS Appl. Mater. Interfaces 12, 47739–47742 (2020). 

8. Magari, Y. et al. Low-temperature (150 °C) processed metal-semiconductor field-effect transistor with a hydrogenated In-Ga-Zn-O stacked channel. Jpn J. Appl. Phys. 59, 2–7 (2020). 

9. Nomura, K. et al. Room-temperature fabrication of transparent flexible thinfilm transistors using amorphous oxide semiconductors. Nature 432, 488–492 (2004). 

10. Kamiya, T. & Hosono, H. Material characteristics and applications of transparent amorphous oxide semiconductors. NPG Asia Mater. 2, 15–22 (2010). 

11. Ohshima, H. Value of LTPS: present and future. SID Int. Symp. Dig. Tech. Pap. 45, 75–78 (2014). 

12. Aikawa, S., Nabatame, T. & Tsukagoshi, K. Effects of dopants in InOx-based amorphous oxide semiconductors for thin-film transistor applications. Appl. Phys. Lett. 103, 1–5 (2013). 

13. Nakata, M., Zhao, C. & Kanicki, J. DC sputtered amorphous In–Sn–Zn–O thin-film transistors: electrical properties and stability. Solid State Electron. 116, 22–29 (2016). 

14. Taniguchi, S., Yokozeki, M., Ikeda, M. & Suzuki, T. K. Transparent oxide thinfilm transistors using n-(In2O3)0.9(SnO2)0.1/InGaZnO4 modulation-doped heterostructures. Jpn J. Appl. Phys. 50, 2–6 (2011). 

15. Furuta, M. et al. Heterojunction channel engineering to enhance performance and reliability of amorphous In–Ga–Zn–O thin-film transistors. Jpn J. Appl. Phys. 58, 090604 (2019). 

16. Li, X., Geng, D., Mativenga, M. & Jang, J. High-speed dual-gate a-IGZO TFTbased circuits with top-gate offset structure. IEEE Electron Device Lett. 35, 461–463 (2014). 

17. Park, E. J. et al. Transparent flexible high mobility TFTs based on ZnON semiconductor with dual gate structure. IEEE Electron Device Lett. 41, 401–404 (2020). 

18. Zan, H. W. et al. Dual gate indium-gallium-zinc-oxide thin film transistor with an unisolated floating metal gate for threshold voltage modulation and mobility enhancement. Appl. Phys. Lett. 98, 153506 (2011). 

19. Lee, B. H., Sohn, A., Kim, S. & Lee, S. Y. Mechanism of carrier controllability with metal capping layer on amorphous oxide SiZnSnO semiconductor. Sci. Rep. 9, 1–7 (2019). 

20. Jeong, H. J. et al. Ultra-high-speed intense pulsed-light irradiation technique for high-performance zinc oxynitride thin-film transistors. ACS Appl. Mater. Interfaces 11, 4152–4158 (2019). 

21. Nam, Y. et al. Effect of RTP annealing using UV and DUV light on the properties of the Al-IZTO TFTs. SID Int. Symp. Dig. Tech. Pap. 49, 1249–1251 (2018). 

22. Nomura, K. et al. Thin-film transistor fabricated in single-crystalline transparent oxide semiconductor. Science 300, 1269–1272 (2003). 

23. Lany, S. et al. Surface origin of high conductivities in undoped In2O3 thin films. Phys. Rev. Lett. 108, 2–6 (2012). 

24. Koida, T., Ueno, Y. & Shibata, H. In2O3-based transparent conducting oxide films with high electron mobility fabricated at low process temperatures. Phys. Status Solidi 215, 1–14 (2018). 

25. Dhananjay & Chu, C. W. Realization of In2O3 thin film transistors through reactive evaporation process. Appl. Phys. Lett. 91, 1–4 (2007). 

26. Si, M. et al. Why In2O3 can make 0.7 nm atomic layer thin transistors. Nano Lett. 21, 500–506 (2021). 

27. Koretomo, D., Hashimoto, Y., Hamada, S., Miyanaga, M. & Furuta, M. Influence of a SiO2 passivation on electrical properties and reliability of In-WZn-O thin-film transistor. Jpn J. Appl. Phys. 58, 018003 (2019). 

28. Yang, J. H. et al. Highly stable AlInZnSnO and InZnO double-layer oxide thin-film transistors with mobility over 50 cm<sup>2</sup> /V·s for high-speed operation. IEEE Electron Device Lett. 39, 508–511 (2018). 

## References 

1. Hirao, T. et al. Novel top-gate zinc oxide thin-film transistors (ZnO TFTs) for AMLCDs. J. Soc. Inf. Disp. 15, 17 (2007). 

2. Park, S.-H. K. et al. 4.3: Transparent ZnO thin film transistor array for the application of transparent AM-OLED display. SID Symp. Dig. Tech. Pap. 37, 25 (2006). 

3. Inoue, H. et al. Nonvolatile memory with extremely low-leakage indiumgallium-zinc-oxide thin-film transistor. IEEE J. Solid State Circuits 47, 2258–2265 (2012). 

4. Huang, X. et al. Large-swing a-IGZO inverter with a depletion load induced by laser annealing. IEEE Electron Device Lett. 35, 1034–1036 (2014). 

5. Furuta, M. et al. Photocurrent and persistent photoconductivity in zinc oxide thin-film transistors under ultraviolet-light irradiation. Jpn J. Appl. Phys. 50, 110204 (2011). 

6. Kaczmarski, J., Jankowska-Śliwińska, J. & Borysiewicz, M. IGZO MESFET with enzyme-modified Schottky gate electrode for glucose sensing. Jpn J. Appl. Phys. 58, 090603 (2019). 

29. Choi, I. M. et al. Achieving high mobility and excellent stability in amorphous In-Ga-Zn-Sn-O thin-film transistors. IEEE Trans. Electron Devices 67, 1014–1020 (2020). 

30. Kamiya, T., Nomura, K. & Hosono, H. Electronic structures above mobility edges in crystalline and amorphous In-Ga-Zn-O: percolation conduction examined by analytical model. IEEE/OSA J. Disp. Technol. 5, 462–467 (2009). 

31. Yang, H. J. et al. High-performance thin-film transistors with an atomic-layerdeposited indium gallium oxide channel: a cation combinatorial approach. ACS Appl. Mater. Interfaces 12, 52937–52951 (2020). 

32. Furuta, M. et al. High mobility hydrogenated polycrystalline In–Ga–O (IGO:H) thin-film transistors formed by Solid phase crystallization. SID Symp. Dig. Tech. Pap. 52, 69 (2021). 

33. Koida, T. Amorphous and crystalline In2O3-based transparent conducting films for photovoltaics. Phys. Status Solidi 214, 1600464 (2017). 

34. Nomura, K., Kamiya, T., Ohta, H., Hirano, M. & Hosono, H. Defect passivation and homogenization of amorphous oxide thin-film transistor by wet O2 annealing. Appl. Phys. Lett. 93, 1–4 (2008). 

7 

NATURE COMMUNICATIONS | (2022) 13:1078 | https://doi.org/10.1038/s41467-022-28480-9 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-28480-9 

35. King, P. D. C. et al. Shallow donor state of hydrogen in In2O3 and SnO2: implications for conductivity in transparent conducting oxides. Phys. Rev. B 80, 1–4 (2009). 

36. Preissler, N., Bierwagen, O., Ramu, A. T. & Speck, J. S. Electrical transport, electrothermal transport, and effective electron mass in single-crystalline In2O3 films. Phys. Rev. B 88, 1–10 (2013). 

37. Ellmer, K. & Vollweiler, G. Electrical transport parameters of heavily-doped zinc oxide and zinc magnesium oxide single and multilayer films heteroepitaxially grown on oxide single crystals. Thin Solid Films 496, 104–111 (2006). 

38. Lee, S. Y. Comprehensive review on amorphous oxide semiconductor thin film transistor. Trans. Electr. Electron Mater. 21, 235–248 (2020). 

39. Weiher, R. L. Electrical properties of single crystals of indium oxide. J. Appl. Phys. 33, 2834–2839 (1962). 

40. Park, J. S., Jeong, J. K., Chung, H. J., Mo, Y. G. & Kim, H. D. Electronic transport properties of amorphous indium-gallium-zinc oxide semiconductor upon exposure to water. Appl. Phys. Lett. 92, 90–93 (2008). 

41. Yang, J. et al. H2O adsorption on amorphous In-Ga-Zn-O thin-film transistors under negative bias stress. Appl. Phys. Lett. 111, 073506 (2017). 

42. Chen, H. C. et al. Investigation of the capacitance–voltage electrical characteristics of thin-film transistors caused by hydrogen diffusion under negative bias stress in a moist environment. ACS Appl. Mater. Interfaces 11, 40196–40203 (2019). 

## Acknowledgements 

This work was partly supported by JSPS KAKENHI Grant No. 20K22415 and Iketani Science and Technology Foundation No.0331062-A. The EBSD experiment was supported by Next Generation Tatara Co-Creation Centre, Shimane University. 

## Author contributions 

M.F. conceived the concept and supported the device analysis. Y.M. designed the research and experiments. Y.M. performed the film deposition, device fabrication, and their analysis. T.K. supported the electrical and optical measurements. W.Y. designed and fabricated pulse-DC sputtering apparatus for film deposition and set up experimental 

environment for TFT fabrication and evaluation, and supported EBSD measurements. All authors contributed to the discussions and commented on the manuscript. 

## Competing interests 

The authors declare no competing interests. 

## Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-022-28480-9. 

Correspondence and requests for materials should be addressed to Yusaku Magari. 

Peer review information Nature Communications thanks Mamatimin Abbas, M. C. Santhosh Kumar and the other, anonymous, reviewer for their contribution to the peer review of this work. 

Reprints and permission information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2022 

8 

NATURE COMMUNICATIONS | (2022) 13:1078 | https://doi.org/10.1038/s41467-022-28480-9 | www.nature.com/naturecommunications 

