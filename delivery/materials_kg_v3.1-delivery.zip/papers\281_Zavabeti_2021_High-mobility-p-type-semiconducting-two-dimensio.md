# High-mobility p-type semiconducting two-dimensional β-TeO2

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Nature Electronics |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 172 |
| 作者 | A. Zavabeti, Patjaree Aukarasereenont, Hayden Tuohey, Nitu Syed, Azmira Jannat, A. Elbourne, Kibret A. Messalea, Bao-Yue Zhang et al. |
| DOI | 10.1038/s41928-021-00561-5 |
| 源文件 | 081_Zavabeti_2021_High-mobility-p-type-semiconducting-two-dimensio.pdf |

---
Articles **https://doi.org/10.1038/s41928-021-00561-5** 





# **High-mobility p-type semiconducting two-dimensional β-TeO2** 

**Ali Zavabeti**<sup>**1,2,9**✉</sup> **, Patjaree Aukarasereenont**<sup>**1,9**</sup> **, Hayden Tuohey**<sup>**1**</sup> **, Nitu Syed**<sup>**1**</sup> **, Azmira Jannat**<sup>**3**</sup> **, Aaron Elbourne**<sup>**1**</sup> **, Kibret A. Messalea**<sup>**3**</sup> **, Bao Yue Zhang**<sup>**3**</sup> **, Billy J. Murdoch**<sup>**1**</sup> **, James G. Partridge**<sup>**1**</sup> **, Matthias Wurdack**<sup>**4**</sup> **, Daniel L. Creedon**<sup>**5**</sup> **, Joel van Embden**<sup>**1**</sup> **, Kourosh Kalantar-Zadeh**<sup>**6**</sup> **, Salvy P. Russo**<sup>**1,7**</sup> **, Chris F. McConville**<sup>**1,8**✉</sup> **and Torben Daeneke**<sup>**3**✉</sup> 

**Wide-bandgap oxide semiconductors are essential for the development of high-speed and energy-efficient transparent electronics. However, while many high-mobility n-type oxide semiconductors are known, wide-bandgap p-type oxides have carrier mobilities that are one to two orders of magnitude lower due to strong carrier localization near their valence band edge. Here, we report the growth of bilayer beta tellurium dioxide (β-TeO2), which has recently been proposed theoretically as a high-mobility p-type semiconductor, through the surface oxidation of a eutectic mixture of tellurium and selenium. The isolated β-TeO2 nanosheets are transparent and have a direct bandgap of 3.7 eV. Field-effect transistors based on the nanosheets exhibit p-type switching with an on/off ratio exceeding 10**<sup>**6**</sup> **and a field-effect hole mobility of up to 232 cm**<sup>**2**</sup> **V**<sup>**−1**</sup> **s**<sup>**−1**</sup> **at room temperature. A low effective mass of 0.51 was observed for holes, and the carrier mobility reached 6,000 cm**<sup>**2**</sup> **V**<sup>**−1**</sup> **s**<sup>**−1**</sup> **on cooling to −50 °C.** 

igh-performance wide-bandgap oxide semiconductors will be important in the development of next-generation transHparent electronics, power electronics and energy-efficient displays<sup>1–4</sup> . However, the lack of a high-mobility, wide-bandgap p-type semiconductor<sup>5–7</sup> , which is necessary for the design of bipolar transistors, inverter circuits and transparent thin-film transistors<sup>5,7,8</sup> , limits applications. Based on calculations, two-dimensional (2D) beta tellurium dioxide (β-TeO2) has been proposed as a high-mobility p-type semiconductor<sup>9</sup> , and the development of a reliable and scalable method to synthesize few-layer, high-mobility p-type β-TeO2 is expected to enable fast oxide electronics and transparent circuits. However, synthesis of the desired layered β-TeO2 polymorph is challenging, because it only forms within a narrow temperature window, and the undesired non-layered α- and γ-TeO2 polymorphs are dominant across most of the temperature parameter space at ambient pressure<sup>10,11</sup> . 

The exploitation of surface oxidation phenomena at the interface of low-melting-point liquid metals has recently led to the development of printing processes that allow ultrathin oxides—with excellent electronics properties—to be deposited on wafer scales<sup>12,13</sup> . The growth of such 2D oxides through surface oxidation of molten metals and alloys relies on the self-limiting Cabrera–Mott reaction<sup>14</sup> , which leads to the formation of an ultrathin interfacial oxide. These oxides can be delaminated from the liquid metal surface with relative ease, allowing their deposition as large lateral 2D materials via a van der Waals printing process<sup>12</sup> . Similar oxidation processes should occur on the surfaces of molten non-metals. 

Tellurium is a metalloid of the chalcogen family with a melting point of 452 °C (ref.<sup>15</sup> ). The interfacial oxidation of liquid tellurium 

is expected to enable the synthesis of ultrathin TeO2. However, the desired β-TeO2 phase forms only at temperatures below 350 °C, which is below its parent element’s melting point<sup>10,11</sup> , precluding direct synthesis of this polymorph from molten tellurium. In this Article, we report the synthesis of transparent p-type β-TeO2 nanosheets using a eutectic melt formed from the alloying of tellurium with selenium. The eutectic melt contains 5 wt% Te and 95 wt% Se, and features a melting point well below 200 °C (Methods)<sup>16–18</sup> . Tellurium is more oxophilic than selenium, because the oxidation reaction of Te results in a greater reduction of the Gibbs free energy (Δ _G_ f) and is therefore more favoured thermodynamically (Fig. 1b and Supplementary Table 1). By optimizing the synthesis conditions, nanosheets are formed that can be used to create transistors with performance similar to their more common n-type oxide counterparts. 

#### **Synthesis of the β-TeO2 nanosheet** 

To synthesize the β-TeO2 nanosheets, eutectic melt droplets of varying size were placed on SiO2 substrates and rolled across the surface with the help of the tip of a glass rod (Fig. 1a, Supplementary Videos 1–3 and Supplementary Fig. 1). (Detailed characterization of the synthesis parameters is presented in the Methods, Extended Data Fig. 1 and Supplementary Note 1.) During the rolling of the chalcogen melt, the naturally occurring surface oxide that forms in ambient atmosphere adheres to the substrate via van der Waals forces. These sheets can extend over several square millimetres (Fig. 1a and Supplementary Fig. 2). The area of the substrate that is covered can be increased by selecting a larger droplet diameter and by applying slow rolling speeds of >3 min per droplet diameter (Extended Data 

> 1School of Science, RMIT University, Melbourne, Victoria, Australia. 2Department of Chemical Engineering, The University of Melbourne, Parkville, Victoria, Australia.<sup>3</sup> School of Engineering, RMIT University, Melbourne, Victoria, Australia.<sup>4</sup> Nonlinear Physics Centre, Research School of Physics, The Australian National University, Canberra, Australian Capital Territory, Australia.<sup>5</sup> School of Physics, The University of Melbourne, Parkville, Victoria, Australia.<sup>6</sup> School of Chemical Engineering, University of New South Wales (UNSW), Kensington, New South Wales, Australia.<sup>7</sup> ARC Centre of Excellence in Exciton Science, School of Science, RMIT University, Melbourne, Victoria, Australia.<sup>8</sup> Institute for Frontier Materials, Deakin University, Waurn Ponds, Geelong, Victoria, Australia.<sup>9</sup> These authors contributed equally: Ali Zavabeti, Patjaree Aukarasereenont.<sup>✉</sup> e-mail: ali.zavabeti@unimelb.edu.au; chris.mcconville@deakin.edu.au; torben.daeneke@rmit.edu.au 

**NATuRE ELECTRONiCS** | VOL 4 | APRIL 2021 | 277–283 | www.nature.com/natureelectronics 

**277** 

<mark>Articles</mark> 

**Nature electroNics** 



<!-- Start of picture text -->
a c<br>Roll-printing 2D composition O<br>Chalcogen<br>mixture Te<br>TeO2 Se<br>Te Se<br>c<br>2D TeO2<br>SiO2/Si a b<br>substrate<br>b<br>–90<br>–130 2D TeO2<br>–170<br>–210<br>–250 100 µm c<br>b<br>SeO2 SeO3 γ-TeO2α-TeO2 β-TeO2 a<br>97.7 mol% 2.3 mol%<br>5 wt% 95 wt%<br>1 G  (kJ mol)∆− f<br><!-- End of picture text -->

**Fig. 1 | Schematic of tellurium oxide synthesis and transfer. a** , A eutectic chalcogen mixture of 5 wt% Te and 95 wt% Se is rolled on a SiO2 substrate. The bar chart on the left summarizes the elemental composition of the mixture derived from energy-dispersive X-ray spectroscopy (Extended Data Fig. 2) and 2D TeO2. The surface oxide of the melt attaches to the substrate, leaving 2D TeO2 on the surface. An optical image of the printed layer reaching several square millimetres in lateral size is also shown (Supplementary Fig. 2). The bar chart on the right summarizes the elemental composition of the deposited layer determined using XPS (Extended Data Fig. 3a–c). Note that the detected Se is present as a sparse residue across the entire substrate. **b** , Summary of the standard Gibbs free energies of formation for the different oxides that may form (Supplementary Table 1)<sup>35,36</sup> . The line between the energies of formation is a guide to the eye. **c** , Crystal structure of β-TeO2 bilayers and an iso-plot of the charge density for the β-TeO2 bilayer, showing the charge density associated with valence bands within 50 meV from the VBM. The highlighted charge density was determined using DFT calculations and represents the charge distribution associated with the top of the valence band, in which p-type conduction occurs<sup>37</sup> . 

Fig. 1). An increased thickness can also be achieved by repeated printing and potentially via dry transfer (Methods and Extended Data Fig. 4j–m). X-ray photoelectron spectroscopy (XPS) analysis of the resulting oxide composition (Fig. 1a and Extended Data Fig. 3a–c) confirmed that the deposited layer is predominantly TeO2, despite the abundance of selenium in the eutectic mixture, with an oxygen to tellurium ratio of close to 2, attesting to stochiometric TeO2 (Methods and Extended Data Fig. 3a–c). XPS-based elemental mapping of a TeO2 flake was conducted to evaluate the presence of selenium impurities (XPS spectra and mapping are shown in Extended Data Fig. 3a–c and Extended Data Fig. 3d, respectively). The elemental map shows that the 2D TeO2 nanosheets can be clearly identified and are composed predominantly of TeO2. The selenium, on the other hand, is distributed across the entire surface and is not spatially associated with the TeO2 nanosheets, indicating that the selenium is predominantly present in the form of a sparse residue. 

#### **Properties of the β-TeO2 bilayers** 

Atomic force microscopy (AFM) of the transferred layer (Fig. 2d) revealed a thickness of ~1.5 nm, which corresponds to one β-TeO2 unit cell containing two fundamental β-TeO2 layers. The nanosheets were found to be laterally large, exceeding several square millimetres, with consistent thickness. The 2D TeO2 nanosheets were directly transferred onto a transmission electron microscopy (TEM) grid after it was gently touched to the surface of the liquid chalcogen mixture. A low-resolution TEM micrograph of a transferred 2D sheet is shown in Fig. 2a, showing a highly translucent and layered morphology. A high-resolution TEM micrograph (HRTEM) and selective area electron diffraction (SAED) pattern of the 2D sheet are shown in Fig. 2b and 2c, respectively. The HRTEM image confirms that the synthesized nanosheets are 

highly crystalline. The SAED analysis confirmed that the obtained TeO2 has indeed crystallized in the β-TeO2 polymorph, featuring an atomic spacing of 0.41 nm in the HRTEM image that corresponds to the (102) plane of β-TeO2 and reflections corresponding to the (122), (101) and (201) lattice planes of beta tellurite. Raman analysis (Fig. 2e) further confirms that the transferred 2D sheets are β-TeO2. Atomic-resolution AFM imaging of 2D TeO2 transferred onto SiO2 substrates also indicates that the 2D nanosheets crystallize as β-TeO2, which is a prerequisite for practical applications in electronic devices (Extended Data Fig. 5). 

Beta tellurite features a predicted bandgap between 3.32 eV for the bulk and 3.70 eV for monolayer TeO2 (ref.<sup>9</sup> ). Our density functional theory (DFT) analysis indicates that the bulk phase has an indirect bandgap of 3.28 eV (Supplementary Fig. 3) and the bilayer has a direct bandgap of 3.62 eV (Fig. 3d). Analysis of the low-loss region of the electron energy loss spectrum (EELS) allows the electronic bandgap of individual nanosheets to be determined, with the method being particularly suited to wide-bandgap materials<sup>12</sup> . The measured bandgap for a typical 2D β-TeO2 nanosheet was found to be 3.7 eV, confirming that TeO2 is a wide-bandgap material that is optically transparent across the visible spectrum (Fig. 3a and Supplementary Fig. 2). The relative Fermi level position was obtained from XPS valence band spectra, which indicated that the material is indeed a p-type semiconductor because the Fermi level is located closer to the valence band maximum (VBM, Fig. 3b). The bandgap was confirmed using scanning tunnelling spectroscopy (STS), with the relative Fermi level position conclusively identifying the synthesized 2D TeO2 as a wide-bandgap p-type semiconductor (Supplementary Fig. 4). The effective carrier mass mh<sup>∗ was calcu-</sup> lated from STS data, and was determined to be 0.51, which is close to the theoretically predicted value (Supplementary Note 2 and Extended Data Fig. 6)<sup>9</sup> . Furthermore, the work function of β-TeO2 

**NATuRE ELECTRONiCS** | VOL 4 | APRIL 2021 | 277–283 | www.nature.com/natureelectronics 

**278** 

<mark>Articles</mark> 

**Nature electroNics** 



<!-- Start of picture text -->
a b c<br>(122) (101) (201)<br>d 2 = 0.41 nm<br>(102)<br>1 µm 2 nm 2 nm –1<br>d 5 e<br>∆ h  = 1.5 nm 50 nm<br>1<br>β-TeO2<br>–3 SiO2<br>0 5 10 15 20 25 30<br>Distance (µm)<br>SiO2<br>10 µm 2D TeO2 200 400 600 800<br>Raman shift (cm –1 )<br>–20<br>Characterization of the 2D TeO2.2.. a , b , Low-magnification ( a ) and high-resolution ( b ) TEM images of β-TeO2 directly exfoliated to a TEM grid.  β-TeO2 directly exfoliated to a TEM grid.  -TeO2 directly exfoliated to a TEM grid.  2 directly exfoliated to a TEM grid.   directly exfoliated to a TEM grid.<br>, Indexed selected area diffraction pattern for β-TeO2, confirming the high crystallinity and orthorhombic β-TeO2, confirming the high crystallinity and orthorhombic -TeO2, confirming the high crystallinity and orthorhombic 2, confirming the high crystallinity and orthorhombic , confirming the high crystallinity and orthorhombic  Pbca  crystal structure of β-TeO2 (ref. β-TeO2 (ref. -TeO2 (ref. 2 (ref.  (ref.<br>image of a transferred layer on a Si/SiO2 wafer. The inset shows the step height profile with a thickness of 1.5 nm. 2 wafer. The inset shows the step height profile with a thickness of 1.5 nm.  wafer. The inset shows the step height profile with a thickness of 1.5 nm.  e , Raman spectrum of β-TeO2β-TeO2-TeO22 nanosheets<br> substrate. The β-TeO2 and substrate SiO2 peaks are marked with star and square symbols, respectivelyβ-TeO2 and substrate SiO2 peaks are marked with star and square symbols, respectively-TeO2 and substrate SiO2 peaks are marked with star and square symbols, respectively2 and substrate SiO2 peaks are marked with star and square symbols, respectively and substrate SiO2 peaks are marked with star and square symbols, respectively2 peaks are marked with star and square symbols, respectively peaks are marked with star and square symbols, respectively 38,39,3939 . For better visualization of the β-TeO2<br>peaks, the substrate SiO2 peak at 520 cm2 peak at 520 cm peak at 520 cm −11  was capped 39 .<br>a b c<br>4.8<br>CBM<br>Intensity ∝ ( E  –  E g) 0.5  4.4<br>R 2  = 0.91 ~3.7 eV 4.0<br>E F 3.6<br>~0.9 eV<br>3.8 4 4.2 VBM E g = 3.62 eV<br>0<br>E g ~ 3.7 eV –0.2<br>–0.4<br>1 µm –0.6<br>3 4 5 6 7 5 4 3 2 1 0 –1 Γ X S Y Γ<br>Energy loss (eV) Binding energy (eV)<br>Height (nm)<br>Intensity (a.u.)<br> (eV) E E – F<br>Intensity (a.u.) Intensity (a.u.)<br><!-- End of picture text -->

**Fig. 2 | Characterization of the 2D TeO2.2.. a** , **b** , Low-magnification ( **a** ) and high-resolution ( **b** ) TEM images of β-TeO2 directly exfoliated to a TEM grid.  β-TeO2 directly exfoliated to a TEM grid.  -TeO2 directly exfoliated to a TEM grid.  2 directly exfoliated to a TEM grid.   directly exfoliated to a TEM grid. **c** , Indexed selected area diffraction pattern for β-TeO2, confirming the high crystallinity and orthorhombic β-TeO2, confirming the high crystallinity and orthorhombic -TeO2, confirming the high crystallinity and orthorhombic 2, confirming the high crystallinity and orthorhombic , confirming the high crystallinity and orthorhombic _Pbca_ crystal structure of β-TeO2 (ref. β-TeO2 (ref. -TeO2 (ref. 2 (ref.  (ref.<sup>9</sup> ). **d** , AFM image of a transferred layer on a Si/SiO2 wafer. The inset shows the step height profile with a thickness of 1.5 nm. 2 wafer. The inset shows the step height profile with a thickness of 1.5 nm.  wafer. The inset shows the step height profile with a thickness of 1.5 nm. **e** , Raman spectrum of β-TeO2β-TeO2-TeO22 nanosheets on a SiO2 substrate. The β-TeO2 and substrate SiO2 peaks are marked with star and square symbols, respectivelyβ-TeO2 and substrate SiO2 peaks are marked with star and square symbols, respectively-TeO2 and substrate SiO2 peaks are marked with star and square symbols, respectively2 and substrate SiO2 peaks are marked with star and square symbols, respectively and substrate SiO2 peaks are marked with star and square symbols, respectively2 peaks are marked with star and square symbols, respectively peaks are marked with star and square symbols, respectively<sup>38,39,3939</sup> . For better visualization of the β-TeO2 peaks, the substrate SiO2 peak at 520 cm2 peak at 520 cm peak at 520 cm<sup>−11</sup> was capped<sup>39</sup> . 

**Fig. 3 | Electronic and optical characterization of the 2D β-TeO2. a** , TEM-based EELS obtained in dark-field STEM mode revealed a bandgap of 3.7 eV. The top inset shows the fit of the EELS to a direct bandgap with a coefficient of determination of 0.91. Here, _E_ g represents the bandgap and _E_ is the binding energy in eV. The bottom inset shows the corresponding dark-field micrograph and the red mark indicates the location where the spectrum was collected. **b** , XPS valence spectrum and the constructed band diagram of the β-TeO2 show the relative location of the VBM and conduction band minimum (CBM) with respect to the Fermi level, indicating p-type material characteristics. The feature between 3 and 5 eV is associated with the non-binding Te 5 _p_ electrons<sup>40,41</sup> . **c** , Calculated band structure of the β-TeO2 bilayer showing a direct bandgap of 3.62 eV. 

was determined to be 3.88 eV using ultraviolet photoelectron spectroscopy (UPS; Extended Data Fig. 7). For the bilayer, we were also able to project the various atomic orbital contributions to the 

electronic density of states (eDOS) near the VBM (Supplementary Fig. 5 and Extended Data Fig. 8). These results indicate that the 2 _p_ orbitals of O and the 5 _p_ orbitals of Te provide the dominant DOS 

**NATuRE ELECTRONiCS** | VOL 4 | APRIL 2021 | 277–283 | www.nature.com/natureelectronics 

**279** 

<mark>Articles</mark> 

### **Nature electroNics** 



<!-- Start of picture text -->
a<br>2D TeO2 Ag<br>2D TeO2<br>SiO2<br>Ag<br>5 µm<br>b I D (µA) c I D (µA)<br>p-type 2D TeO2 5 40<br>–0.6 –0.4 –0.2 0<br>V D (V)<br>30 V D = –0.25 V<br>–10 V D = –0.50 V<br>20<br>–20<br>V G = 2.5 V 10<br>V G = 0 V<br>–30<br>V G = –2.5 V 0<br>V G (V)<br>V G = –5.0 V –6 –4 –2 0 2 4<br>–40<br>d I D (A) e<br>On/off ratio > 10 6 10 –4 10 4<br>10 –5<br>10 –6 γ ~ 3.1<br>10 3<br>10 –7<br>10 –8<br>10 –9 10 –9 10 2 d l D L<br>10 –10 10 –10 µ p = d V G WV D C ox<br>10 –11 10 –11 µ p ∝  T – γ<br>60 mV dec –1<br>10 –12 10<br>–4 –2 0 2 150 200 250 300<br>V G (V) Temperature (K)<br>2–1–1FET mobility (cm) Vs<br><!-- End of picture text -->

**Fig. 4 | Field-effect transistor measurements of 2D β-TeO2. a** , Schematic of the device showing a Si backgated FET with silver source–drain electrodes. An SEM image of the device is shown on the right. **b** , The p-type characteristic of the FET device. The _x_ axis is the drain–source voltage and the _y_ axis is drain current. **c** , **d** , Gate voltage and drain current transfer curves of the device ( **c** ) and semi-logarithmic presentation of a transfer curve of the device at a drain voltage of −1 V ( **d** ). Inset: the sub-threshold swing (a slope corresponding to 60 mV dec<sup>−1</sup> is shown in red as a reference for an ideal FET). The on/off ratio exceeds 10<sup>6</sup> . **e** , log–log graph of mobility versus temperature. Multiple devices were measured at room temperature. The black square shows the determined average and associated standard deviation. Cryogenic measurements were conducted on selected devices. A field-effect mobility of up to ~6,165 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> was measured at cryogenic temperatures. The mobility was calculated using the equation shown, where _μ_ p is the hole mobility, d _I_ D is the drain–source current, d _V_ G is the gate voltage, _L_ and _W_ are the length and width of the 2D TeO2 channel, respectively, _V_ D is the drain–source voltage and _C_ ox is the capacitance of the substrate SiO2. According to the presented mobility– temperature dependence equation, 𝛾 is estimated from a linear fit to log– log values (shown with a dashed line) (see Methods). 

contribution near the VBM, which is indicative of _π_ bonding and suggests comparatively high hole mobility. 

#### **Application of β-TeO2 in electronic devices** 

DFT analysis of the carrier transport properties of β-TeO2 revealed an exceptionally high hole mobility of 7,690 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> along the _b_ axis and 436 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> along the _a_ axis. Figure 1c shows that the charge density associated with the top of the valence band is concentrated near the van der Waals gap of the bilayer. Adjusting the iso-levels of charge density maps (Fig. 1c and Extended Data Fig. 9) 

reveals that there is a different conduction pathway for hole transport along the _a_ and _b_ axes (Extended Data Fig. 9) and this is the likely reason for the high anisotropy in hole mobility, with the _b_ axis having a shorter conduction pathway than the _a_ axis. 

Field-effect transistors (FETs) were fabricated to evaluate the synthesized 2D β-TeO2 (Fig. 4a) for electronic device applications. As shown in Fig. 4b–d, the FET devices feature p-type switching with an on/off ratio exceeding 10<sup>6</sup> . The sub-threshold swing for the FET was 103 ± 3 mV per decade, which is close to ideal behaviour. The room-temperature field-effect mobility was measured to be 146 ± 42 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> on average, with a mobility of 232 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> for the best-performing device (Supplementary Note 3 provides the FET mobility calculation). The observed field-effect mobility is one to two orders of magnitude higher than that of common high-performance wide-bandgap oxide-based p-type semiconductors and is comparable to the mobility observed in some of the best n-type oxide semiconductors, such as indium oxide<sup>19,20</sup> . A comparison of device performance between this work and other reported p-type oxides is provided in Supplementary Table 2, while n-type oxide performance is summarized in Supplementary Table 3. Characterization of a FET device at cryogenic temperatures revealed an ultra-high mobility above 6,000 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> for temperatures below −50 °C (223 K) (Fig. 4e). These temperatures are easily accessible through conventional compressive refrigeration or thermoelectric cooling, rendering bilayer β-TeO2 one of the highest-mobility p-type semiconductors within this temperature region. Fitting of the temperature-dependent carrier mobility revealed a power-law dependence exponent _γ_ of ~3.1, which is indicative of phonon-scattering-limited transport at room temperature<sup>21</sup> . The 2D TeO2-based FETs were found to be remarkably stable, featuring excellent cyclability with consistent on/off ratio and stable on currents for over 1,000 switching cycles under ambient conditions (Extended Data Fig. 10). Furthermore, the devices were found to suffer no discernible performance degradation when operated under ambient conditions without encapsulation. The observed room-temperature field-effect hole mobility is only one order of magnitude lower than the theoretically predicted attainable mobility that assumes a defect-free bilayer and the absence of substrate interactions. This highlights that the synthesized β-TeO2 is of exceptional quality, while also suggesting that further improvements may be attainable through improved device design. Future work should focus on the design of device architectures that enable the integration of individually addressable transistors into more complex circuits. Possible strategies could include the use of van der Waals heterostructures with dielectrics such as hexagonal boron nitride or Ga2O3 in combination with top gates<sup>22,23</sup> . These device configurations will also enable the determination of important parameters such as the pinch-off voltage, which will be informative for future device integration into functional circuits. 

Hall effect measurements were carried out at room temperature to confirm the anisotropy as well as the hole mobility of β-TeO2. A Hall effect device with van der Pauw configuration was fabricated (Supplementary Fig. 6), which demonstrated typical p-type characteristics with a charge carrier density and effective anisotropy of _n_ 2D = 1.04 × 10<sup>9</sup> cm<sup>−2</sup> and _A_ eff = 4.18, respectively. The hole mobilities for the principal axes of the device were 277.6 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ( _µxx_ ) and 54.5 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ( _µyy_ ), leading to an average mobility of 141 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ( _µ_ Hall) (Supplementary Notes 4 and 5). This average mobility is in excellent agreement with the measured field-effect mobility (146 ± 42 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ). The true anisotropy of β-TeO2 might exceed the measured value, because, despite the observed high crystallinity found in TEM and SAED studies, it is possible that grain boundaries existed within the Hall device. 

The use of 2D materials for the fabrication of van der Waals heterostructures can enable a wide range of applications and is, as such, a key feature of 2D material research. Therefore, a dry transfer 

**NATuRE ELECTRONiCS** | VOL 4 | APRIL 2021 | 277–283 | www.nature.com/natureelectronics 

**280** 

### **Nature electroNics** 

method that permits a 2D β-TeO2 sheet to be picked up and deposited on a desired substrate at a precise location was developed. The TeO2 nanosheet was initially synthesized on a GaAs substrate on which delamination of flakes occurred more readily than on SiO2. The process and results are presented in Extended Data Fig. 4k–m. Although the current transfer success rate is low, it may be applicable to the fabrication of β-TeO2 heterostructures. Direct synthesis on a variety of substrates has also been demonstrated in Extended Data Fig. 4a–i, highlighting that the developed synthesis technique is well suited to the deposition of 2D TeO2 on a range of materials. 

#### **Conclusions** 

We have reported the synthesis of bilayer β-TeO2 through the surface oxidation of a eutectic mixture of tellurium and selenium. The deposition technology is simple and leads to square-millimetre-sized bilayer nanosheets suitable for electronic device fabrication. The synthesis occurs at comparatively low temperatures (270–300 °C) and has the potential to be adapted to the large-area printing of oxide semiconductors. The bandgap of the unit-cell-thick β-TeO2 (bilayer) was found to be ~3.7 eV, rendering this semiconductor material transparent across the visible spectrum. 

Characterization of the β-TeO2 nanosheets revealed that the material was a p-type semiconductor. Field-effect transistors confirmed p-type switching and highlighted that the synthesized material features a high hole mobility for an oxide semiconductor. DFT modelling indicated that the high hole mobility is due to the upper valence band regions being dominated by _p_ orbitals (leading to _π_ bonding), which minimizes charge localization. The theoretically predicted anisotropy of the hole mobility due to different hole conduction paths along the _a_ and _b_ axes has been confirmed with Hall effect measurements. The effective carrier mass was measured to be m<sup>∗</sup> h<sup>= 0.51. The fabricated FET devices featured excellent per-</sup> formance with high on/off ratios, a low sub-threshold swing and high stability in ambient atmosphere. The isolated β-TeO2 provides a high-mobility, wide-bandgap p-type oxide semiconductor and, in combination with existing high-performance wide-bandgap n-type oxides, could lead to the development of fast oxide electronics and transparent logic devices. 

#### **Methods** 

**Hazard statement.** Selenium and selenium compounds are toxic, and tellurium can cause an allergic skin reaction and be harmful to the respiratory system. The synthesis procedure requires a safe working environment, including engineering controls that prohibit the exposure of personnel to the chemical substances and the release of hazards into the environment. 

**Materials.** Selenium pellets and tellurium pieces with a purity of >99.99% trace metals basis were purchased from Sigma Aldrich and used without further purification. All other materials were purchased from common suppliers and used without purification. 

**Alloy synthesis.** Selenium (95 wt%) and tellurium (5 wt%) were mixed inside an argon-filled glovebox system with an O2 content below 0.1 ppm on a hotplate at ~500 °C, which is above the melting point of tellurium (449.57 °C)<sup>17</sup> . The selenium was added after the tellurium was completely molten and the vial was sealed to avoid releasing selenium. The mixture was kept sealed at ~500 °C for 2 h to ensure homogeneous mixing before solidification. The chalcogen mixture was then fractured to form smaller pellets with sizes of a few millimetres. 

**Roll-transfer method.** The pellets of the chalcogen mixture were transferred outside the glovebox into a fume cupboard. Before the start of the experiment, the surface of the solid mixture was cleaned using a lint-free wipe. The eutectic chalcogen alloy was then melted on a SiO2 wafer at ~270 °C. The molten droplet was rolled with the tip of a glass rod across the substrate, imitating the motion of handwriting with a pen (Supplementary Videos 1–3). Ultrathin oxide layers were left behind on the wafer. Owing to the high surface adhesion of the liquid chalcogen, some small droplets may reside on the wafer. These chalcogen droplets can be mechanically removed after solidification. Synthesis parameters, including the influence of growth time, droplet diameters and deposition velocity on the substrate coverage and the lateral dimensions of the sheets, are detailed in Extended Data Fig. 1 and Supplementary Note 1. The same process and conditions 

## <mark>Articles</mark> 

were applied to synthesize 2D TeO2 layers on quartz, a microscope glass slide, 100-nm Pt on a silicon substrate, a plain silicon substrate, 300-nm Al2O3 on a silicon substrate, sapphire, GaAs, and mica and SiO2 substrates, respectively (Extended Data Fig. 4a–i). 

**Transfer of a TeO2 flake.** For the transfer, a sacrificial polypropylene-carbonate (PPC) film on top of a polydimethylsiloxane (PDMS) stamp (supplied by the company Gel-Pak) was prepared<sup>22</sup> . For PPC deposition, PPC in anisole solution (concentration of ~5%) was spin-coated on top of the PDMS for 1 min with a rotational speed of 6,000 r.p.m., and subsequently baked at 100 °C for 5 min. The TeO2 synthesis was carried out directly on a (100) GaAs substrate (Extended Data Fig. 4k). With the PDMS/PPC stack, the TeO2 flakes could be lifted off the GaAs surface by using a heterostructure stacking stage with a sample heating and cooling module. For this process, the PPC was brought in contact with the TeO2 sheets at a substrate temperature of 60 °C. After contact, the substrate was directly cooled to 10 °C with a temperature gradient of 15 °C min<sup>−1</sup> . At 10 °C, the PPC film was lifted off quickly, separating the TeO2 nanosheet from the GaAs (Extended Data Fig. 4l). Subsequently, the TeO2 flakes on PPC could be deterministically transferred onto a desired substrate at 120 °C (ref.<sup>22</sup> ). This process can be used to assemble van der Waals heterostructures<sup>24,25</sup> . Following this, the PDMS stamp was separated from the substrate. After the transfer, the PPC could be washed off with acetone and the sample could then be cleaned with isopropanol and ethanol. A TeO2 flake transferred from GaAs onto a SiO2 chip is presented in Extended Data Fig. 4m. The overall transfer yield was found to be below 5%, with the pickup step being the limiting factor. The yield may be improved by identifying substrates that allow for weaker adhesion than GaAs. Alternatively, wet transfer methods may be developed. 

**Characterization.** A Thermo Scientific K-alpha XPS spectrometer with a monochromated X-ray source providing photons with energy of 1,486.7 eV (Al Kα) with a spot size of 400 µm, and a concentric hemispherical analyser with a pass energy of 50 eV, was used to collect the XPS spectra shown in Fig. 3b and Extended Data Fig. 3a–c. The stoichiometric ratio of TeO2 was determined by Thermo Scientific Avantage data system software by fitting the relevant peaks of O 1 _s_ and Te 3 _d_ 5/2. XPS elemental mapping (Extended Data Fig. 3d) was conducted using a Kratos AXIS Supra photoelectron spectrometer (Kratos Analytical) with Al Kα X-rays (1,486.7 eV). The pass energy used for the images was 160 eV. The same instrument was also used to collect valence-band XPS spectra with a low pass energy of 20 eV. A Horiba Scientific LabRAM HR evolution micro-Raman spectrometer, with a 532 nm laser source and power of 0.3 mW at the sample, 60-s acquisition time, ×50 objective lens and grating with 1,800 lines per mm was used to collect all the Raman data presented. Samples were prepared on SiO2 wafer for AFM, XPS and Raman spectroscopies. A JEOL 2100F TEM/STEM (2011) system operating at an acceleration voltage of 200 kV and equipped with a bright-field Gatan OneView 4k charge-coupled device (CCD) camera was used for both the low-resolution HRTEM imaging and SAED. The same instrument was also used for EELS using a Gatan imaging filter (EELS spectrometer) and Gatan Orius SC1000 CCD camera for dark-field imaging. Digital Micrograph 1.8.4 software was used for imaging and EELS analysis. The EELS measurements were conducted in STEM mode with a zero-loss peak of a full-width at half-maximum ~1.1 eV. To determine the bandgap, EELS was processed with the Digital Micrograph software. During the process, plural scattering was removed with the Fourier-log method. A Gaussian–Lorentzian model was then used to remove the zero-loss peak loss and the spectrum was deconvolved using the zero-loss modifier function. Bandgap determination was performed using MATLAB R2019b curve-fitting toolbox (Fig. 3a), which resulted in an _R_<sup>2</sup> of 0.91. The EELS measurement was obtained from a free-standing TeO2 flake on high-temperature and chemically resistant silicon-nitride TEM grids. Energy-dispersive X-ray spectroscopy was performed using an FEI Nova NanoSEM 200 FEGSEM (2007) system equipped with an Oxford X-Max20 EDX Detector (2014) and Aztec software v3.3. STS was performed using an Omicron variable-temperature scanning tunnelling microscope (VT STM) with matrix SPM controller module. Tungsten tips were purchased from Scientia Omicron for the STS, which were pre-conditioned before each measurement, and the feedback loop was stopped during the collection of _I_ / _V_ curves. The _I_ / _V_ curves were exported using Vernissage software and processed in MATLAB R2019b to produce the d _I_ /d _V_ presented in Supplementary Fig. 4. AFM imaging in Fig. 2d was performed using a Bruker Dimension Icon AFM. The HR-AFM measurements presented in Extended Data Fig. 5a were performed using a Cypher ES Asylum Research system in amplitude-modulated AFM (AM-AFM) mode, under ambient conditions (room temperature, in a sealed environment). Arrow UHFAuD cantilevers with a nominal spring constant of 6 N m<sup>−1</sup> were used. The cantilevers were calibrated, and spring constant and sensitivity values were updated before each experiment. UPS measurements were collected using the He(i) (21.2 eV) line of a helium discharge lamp, with a pass energy of 5 eV and energy step size of 0.025 eV. The work function was determined by a linear fit to the secondary electron cutoff (Extended Data Fig. 7). 

**FET fabrication.** Backgated FETs were fabricated using thermal evaporation-based metal deposition through single-use evaporation masks. The 2D TeO2 sheets were deposited onto conductive silicon substrates with a thermally grown 300-nm-thick 

**NATuRE ELECTRONiCS** | VOL 4 | APRIL 2021 | 277–283 | www.nature.com/natureelectronics 

**281** 

## <mark>Articles</mark> 

SiO2 gate oxide. Kapton lithography stencils/masks for the deposition of the source and drain electrodes of the transistors were prepared and fabricated utilizing the DreamCreaTorV3.0 processing software for laser micro-machining. The laser-cut masks with distinct channel lengths of 5 and 10 µm were manually aligned on top of the grown 2D sheets using an optical microscope. A silver electrode layer (thickness of 70 nm) was then deposited with the aid of a Daedong High Technologies Solar-Bridge evaporator. During the deposition, the samples were rotated at 20 r.p.m. at ambient temperature. To reach the target thickness, the deposition rate was set to 0.1 nm s<sup>−1</sup> for the first 10 nm and increased to 0.2 nm s<sup>−1</sup> afterwards. 

**FET characterization.** A probe station connected to a Keysight B2902A precision source/measure unit (SMU, two channels, 100 fA) was used to perform current–voltage ( _I–V_ ) characterization of the FET devices. Variable-temperature measurements were carried out using a Linkam PE95 temperature controller with a liquid nitrogen-cooled test chamber. The chamber featured miniature electrical probe arms, which were connected to the Keysight SMU. The room-temperature mobility data were obtained from 10 individual devices, with the average mobility and standard deviation having been calculated. Owing to the varying shapes of the 2D sheets, precise measurements of the channel width and length were made for each device by individually inspecting them using SEM. The FET device dimensions _W_ × _L_ presented in Fig. 4b–d and 4e are 3.2 × 9.7 μm and 1.6 × 4.5 μm, respectively. The sub-threshold swing was averaged for drain voltages of ±0.5 and ±0.25 V and is presented as 103 ± 3 mV dec<sup>−1</sup> . The leakage current for sub-threshold swing shown in Fig. 4d was 7.4 pA. The temperature-dependent power-law equation was fitted in the mobility measurements shown in Fig. 4e using the MATLAB R2019b curve-fitting toolbox, resulting in an _R_<sup>2</sup> of 0.93. 

**Computational methods.** Electronic structure calculations were performed using the B3LYP hybrid exchange-correlation functional with a triple zeta valence basis set (TZV)<sup>26,27</sup> . An empirical London-type correction to the energy, to include van der Waals dispersion contributions to the total energy, was also used. The correction term was the one given by Grimme<sup>28</sup> . A Monkhorst–Pack<sup>29</sup> 6 × 6 × 6 k-point mesh was used to sample the first Brillouin zone (6 × 6 × 1 for the bilayer). Calculations were performed using the Gaussian basis set ab initio package CRYSTAL14<sup>30,31</sup> . 

To obtain the relaxed geometry of the bilayer, the following procedure was undertaken. First, bulk β-TeO2 was geometry optimized using a 6 × 6 × 6 k-point mesh. The coordinates of the bulk structure were obtained from the Open Crystallography Database (COD ID 9008125)<sup>32</sup> and then geometry optimized (atom positions and cell parameters). A bilayer slab was then constructed by performing a cut along the (100) surface plane of a 2 × 2 × 2 supercell of the optimized bulk and further optimizing both atomic positions and cell parameters. The band structure of the bilayer was obtained by following a path Γ-X-S-Y-Γ corresponding to the primitive orthorhombic Brillouin zone, where Γ(000), X(1/2,0,0), S(1/2,1/2,0) and Y(0,1/2,0) are the in-plane high symmetry points. The effective masses of the electrons and holes were estimated by performing quadratic fits to the regions of the VBM (for holes) and conduction band minimum (electrons) closest to the Fermi level. Charge carrier mobilities were estimated using the method described by Qiao and colleagues<sup>33</sup> . For the eDOS calculations, the DOS was calculated over a region corresponding to the 11 valence bands and 5 conduction bands closest to the Fermi level. Over this region, we also projected out the Te and O atomic orbitals associated with the 11 valence and 5 conduction bands to show which atomic orbitals contributed to the associated bands. Finally, we were able to produce a series of 2D electron charge density maps corresponding to those valence bands that were within 50 meV of the Fermi level. Each 2D slice spanned the range of the simulation cell along the _a_ and _b_ axes for a particular value of _z_ along the _c_ axis (using the CRYSTAL software keywords NEWK, PDIDE AND ECHG). A total of 120 2D electron charge density maps were produced spanning the entire bilayer along the _c_ axis in increments of 0.1 Å. These charge density maps were then combined to form a 3D energy projected charge density map corresponding the charge density associated with those bands near the Fermi level. The 3D charge density cube file was reformatted to be visualized using the 3D visualization program VESTA<sup>34</sup> . 

**Van der Pauw device fabrication.** Van der Pauw contacts were patterned in a square geometry using an FEI Scios Dualbeam focused ion beam scanning electron microscope (FEI Scios FIB-SEM). The 100-nm platinum contact pads (100 µm × 100 µm) for wire bonding and the contact lines leading to the sample with width of 1 µm were directly deposited utilizing a gas injection system attached to the instrument. Each feature was deposited in series and/or separately for precise control of the deposition sites. Deposition with a current density of ~5 pA µm<sup>−2</sup> was maintained for deposition of all features, leading to an optimized deposition rate. The focused Ga ion beam of the FEI Scios FIB-SEM was used to mill 10 nm and remove material around the contact pads, contact lines and to create a square area that was electrically isolated from the rest of the sample (Supplementary Fig. 6). The substrate used had an oxide thickness of 300 nm SiO2. The etched sections were inspected after the milling process for consistency. SEM images were taken with 10 kV and 0.1 nA using secondary electrons and an Everhardt–Thornley (ETD) detector. 

### **Nature electroNics** 

**Resistivity and Hall effect measurements.** Four-terminal resistivity measurements were performed at ambient temperature using a Keithley 2450 source meter. The same instrument was also used to pass a current of _I_ DC = 200 nA between diagonally opposite contacts of the van der Pauw device and measure the resultant transverse (Hall) voltage. The measurements were taken with a d.c. magnetic field between −0.7 and +0.7 T applied perpendicular to the sample surface. 

#### **Data availability** 

The data used to determine the data points shown within the plots presented in this paper, and other findings from this study, are available from the corresponding authors upon reasonable request. 

Received: 19 May 2020; Accepted: 24 February 2021; Published online: 5 April 2021 

#### **References** 

1. Thomas, G. Invisible circuits. _Nature_ **389** , 907–908 (1997). 

2. Nomura, K. et al. Room-temperature fabrication of transparent flexible thin-film transistors using amorphous oxide semiconductors. _Nature_ **432** , 488–492 (2004). 

3. Wager, J. F. Transparent electronics. _Science_ **300** , 1245–1246 (2003). 

4. Nomura, K. et al. Thin-film transistor fabricated in single-crystalline transparent oxide semiconductor. _Science_ **300** , 1269–1272 (2003). 

5. Zhang, S. et al. Recent progress in 2D group-VA semiconductors: from theory to experiment. _Chem. Soc. Rev._ **47** , 982–1021 (2018). 

6. Chhowalla, M., Jena, D. & Zhang, H. Two-dimensional semiconductors for transistors. _Nat. Rev. Mater._ **1** , 16052 (2016). 

7. He, Q. et al. Quest for p-type two-dimensional semiconductors. _ACS Nano_ **13** , 12294–12300 (2019). 

8. Sanal, K. C., Vikas, L. S. & Jayaraj, M. K. Room temperature deposited transparent p-channel CuO thin film transistors. _Appl. Surf. Sci._ **297** , 153–157 (2014). 

9. Guo, S. et al. Ultrathin tellurium dioxide: emerging direct bandgap semiconductor with high-mobility transport anisotropy. _Nanoscale_ **10** , 8397–8403 (2018). 

10. Hodgson, S. N. B. & Weng, L. Preparation of tellurite thin films from tellurium isopropoxide precursor by sol–gel processing. _J. Non-Cryst. Solids_ **276** , 195–200 (2000). 

11. Hodgson, S. N. B. & Weng, L. Chemical and sol–gel processing of tellurite glasses for optoelectronics. _J. Mater. Sci. Mater. Electron._ **17** , 723–733 (2006). 

12. Zavabeti, A. et al. A liquid metal reaction environment for the room-temperature synthesis of atomically thin metal oxides. _Science_ **358** , 332–335 (2017). 

13. Datta, R. S. et al. Flexible two-dimensional indium tin oxide fabricated using a liquid metal printing technique. _Nat. Electron._ **3** , 51–58 (2020). 

14. Cabrera, N. & Mott, N. F. Theory of the oxidation of metals. _Rep. Prog. Phys._ **12** , 163–184 (1949). 

15. Greenwood, N. N. & Earnshaw, A. in _Chemistry of the Elements_ Ch. 16, 747–788 (Elsevier Butterworth-Heinemann, 1997). 

16. Tsuchiya, Y. Phase equilibria in the liquid sulphur–tellurium system: structural changes and two-melt phase separation. _J. Phys. Condens. Matter_ **4** , 4335–4349 (1992). 

17. Ghosh, G., Sharma, R. C., Li, D. T. & Chang, Y. A. The Se–Te (selenium– tellurium) system. _J. Phase Equilib._ **15** , 213–224 (1994). 

18. Li, D. T., Sharma, R. C. & Chang, Y. A. The S–Te (sulfur–tellurium) system. _Bull. Alloy Phase Diagr._ **10** , 348–350 (1989). 

19. Wang, L. et al. High-performance transparent inorganic–organic hybrid thin-film n-type transistors. _Nat. Mater._ **5** , 893–900 (2006). 

20. Nayak, P. K., Hedhili, M. N., Cha, D. & Alshareef, H. N. High performance In2O3 thin film transistors using chemically derived aluminum oxide dielectric. _Appl. Phys. Lett._ **103** , 033518 (2013). 

21. Chamlagain, B. et al. Mobility improvement and temperature dependence in MoSe2 field-effect transistors on parylene-C substrate. _ACS Nano_ **8** , 5079–5088 (2014). 

22. Wurdack, M. et al. Ultrathin Ga2O3 glass: a large-scale passivation and protection material for monolayer WS2. _Adv. Mater._ **33** , 2005732 (2020). 

23. Lee, G.-H. et al. Highly stable, dual-gated MoS2 transistors encapsulated by hexagonal boron nitride with gate-controllable contact, resistance and threshold voltage. _ACS Nano_ **9** , 7019–7026 (2015). 

24. Geim, A. K. & Grigorieva, I. V. Van der Waals heterostructures. _Nature_ **499** , 419–425 (2013). 

25. Gu, J., Chakraborty, B., Khatoniar, M. & Menon, V. M. A room-temperature polariton light-emitting diode based on monolayer WS2. _Nat. Nanotechnol._ **14** , 1024–1028 (2019). 

26. Laun, J., Vilela Oliveira, D. & Bredow, T. Consistent Gaussian basis sets of double- and triple-zeta valence with polarization quality of the fifth period for solid-state calculations. _J. Comput. Chem._ **39** , 1285–1290 (2018). 

**NATuRE ELECTRONiCS** | VOL 4 | APRIL 2021 | 277–283 | www.nature.com/natureelectronics 

**282** 

<mark>Articles</mark> 

### **Nature electroNics** 

27. CRYSTAL—Basis Sets Library (CRYSTAL Theoretical Chemistry Group, Univ. Torino); http://www.crystal.unito.it/basis-sets.php 

28. Grimme, S. Semiempirical GGA-type density functional constructed with a long-range dispersion correction. _J. Comput. Chem._ **27** , 1787–1799 (2006). 

29. Monkhorst, H. J. & Pack, J. D. Special points for Brillouin-zone integrations. _Phys. Rev. B_ **13** , 5188–5192 (1976). 

30. Dovesi, R. et al. CRYSTAL14: a program for the ab initio investigation of crystalline solids. _Int. J. Quantum Chem._ **114** , 1287–1317 (2014). 

31. Dovesi, R. et al. _CRYSTAL14 User’s Manual_ (Univ. Torino, 2014). 

32. Crystallography Open Database COD ID 9008125; www.crystallography.net 

33. Qiao, J., Kong, X., Hu, Z.-X., Yang, F. & Ji, W. High-mobility transport anisotropy and linear dichroism in few-layer black phosphorus. _Nat. Commun._ **5** , 4475 (2014). 

34. Momma, K. & Izumi, F. VESTA 3 for three-dimensional visualization of crystal, volumetric and morphology data. _J. Appl. Crystallogr._ **44** , 1272–1276 (2011). 

35. Olin, Å., Nolang, B., Osadchii, E. G., Öhman, L.-O. & Rsen, E. _Chemical Thermodynamics of Selenium_ . Vol. 7, 41 (Elsevier, 2005). 

36. Ceriotti, M., Pietrucci, F. & Bernasconi, M. Ab initio study of the vibrational properties of crystalline TeO2: the α, β and γ phases. _Phys. Rev. B_ **73** , 104304 (2006). 

37. Beyer, H. Verfeinerung der Kristallstruktur von Tellurit, dem rhombischen TeO2. _Z. Kristallogr. Cryst. Mater._ **124** , 228–237 (1967). 

38. Mirgorodsky, A. P., Merle-Méjean, T., Champarnaud, J. C., Thomas, P. & Frit, B. Dynamics and structure of TeO2 polymorphs: model treatment of paratellurite and tellurite; Raman scattering evidence for new γ- and δ-phases. _J. Phys. Chem. Solids_ **61** , 501–509 (2000). 

39. Zhang, W. L., Zhang, S., Yang, M. & Chen, T. P. Microstructure of magnetron sputtered amorphous SiO _x_ films: formation of amorphous Si core−shell nanoclusters. _J. Phys. Chem. C_ **114** , 2414–2420 (2010). 

40. Di Nardo, S., Lozzi, L., Passacantando, M., Picozzi, P. & Santucci, S. Reactivity towards oxygen of TeSi(100) surfaces investigated by ultraviolet photoelectron spectroscopy, X-ray photoelectron spectroscopy and low energy electron diffraction spectroscopy. _J. Electron Spectrosc._ **74** , 129–134 (1995). 

41. Shimada, K. et al. Photoemission study of itinerant ferromagnet Cr1 − _d_ Te. _Phys. Rev. B_ **53** , 7673–7683 (1996). 

42. Charton, P., Gengembre, L. & Armand, P. TeO2–WO3 glasses: infrared, XPS and XANES structural characterizations. _J. Solid State Chem._ **168** , 175–183 (2002). 

43. Shalvoy, R. B., Fisher, G. B. & Stiles, P. J. Bond ionicity and structural stability of some average-valence-five materials studied by X-ray photoemission. _Phys. Rev. B_ **15** , 1680–1697 (1977). 

#### **Acknowledgements** 

T.D. acknowledges funds received from the Australian Research Council (ARC) through the DECRA scheme (DE190100100). A.Z. thanks the University of Melbourne for the support received through the McKenzie postdoctoral fellowship programme. This work was supported by ARC Centre of Excellence FLEET (CE170100039) and Exciton Science (CE170100026). We thank RMIT University’s Microscopy and Microanalysis Facility (RMMF), a linked laboratory of the Australian Microscopy and Microanalysis Research Facility (AMMRF), and RMIT University’s MicroNano Research Facility (MNRF) for scientific and technical support. The Cypher ES AFM instrument was funded in part by grant no. LE170100096 from the ARC. This project was also supported by computational resources provided by the Australian government through the National Computational Infrastructure National Facility (NCI-NF) and the Pawsey Supercomputer Centre (ARC). A.E. is supported by the Jack Brockhoff Foundation (JBF grant no. 4655-2019-AE). D.L.C. is supported by the ARC under Discovery Project grant no. DP190102852. 

#### **Author contributions** 

The project was designed and directed by T.D., C.F.M. and A.Z. A.Z. and P.A. synthesized the chalcogen mixture and developed the synthesis procedure for 2D β-TeO2 while also conducting XPS and Raman measurements. A.Z., P.A. and B.Y.Z. performed the AFM imaging. A.E. performed atomic-resolution HR-AFM imaging. A.Z. performed TEM/SAED and HRTEM imaging. P.A. led the device fabrication with contributions from H.T., N.S., A.J., K.A.M. and J.v.E. J.G.P., A.Z. and P.A. characterized the FET devices. B.J.M. carried out UPS measurements and assisted with the XPS analysis. M.W. performed 2D nanosheet transfer experiments. D.L.C. conducted and interpreted Hall effect measurements. S.P.R. performed DFT calculations. T.D., C.F.M., K.K.-Z., A.Z. and P.A. analysed the material and device characteristics and drafted the manuscript. All authors revised the manuscript. 

#### **Competing interests** 

The authors declare no competing interests. 

#### **Additional information** 

**Extended data** is available for this paper at https://doi.org/10.1038/s41928-021-00561-5. **Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41928-021-00561-5. 

**Correspondence and requests for materials** should be addressed to A.Z., C.F.M. or T.D. **Peer review information** _Nature Electronics_ thanks Seungwu Han, Chun-Hu Cheng and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. **Reprints and permissions information** is available at www.nature.com/reprints. **Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

© The Author(s), under exclusive licence to Springer Nature Limited 2021, corrected publication 2021 

**NATuRE ELECTRONiCS** | VOL 4 | APRIL 2021 | 277–283 | www.nature.com/natureelectronics 

**283** 

**<mark>Articles</mark>** 

**Nature electroNics** 



**Extended Data Fig. 1 | See next page for caption.** 

**NATuRE ELECTRONiCS** | www.nature.com/natureelectronics 

**<mark>Articles</mark>** 

**Nature electroNics** 

**Extended Data Fig. 1 | Roll-synthesis technique characterization. a** , Maximum droplet velocity achieved when droplet size was varied (Supplementary Videos 1 and 2). Lower speeds can be applied to the larger droplets as rolling too fast causes the fragmentation. **b** , Oxide thickness against time shows no significant change of the sheet thickness when prolonging the oxidation time. **c** , Rolling time-steps against substrate coverage and sheets lateral dimensions (Supplementary Video 3). Time-steps are defined as resting molten droplet before rolling a droplet-diameter length. Each error bar represents ± 1 standard deviation from four measurements. Discussion on printing parameters can be found in Supplementary Note 1. 

**NATuRE ELECTRONiCS** | www.nature.com/natureelectronics 

**<mark>Articles</mark>** 

**Nature electroNics** 



**Extended Data Fig. 2 | Energy-dispersive X-ray spectroscopy (EDXS) elemental composition spectrum.** The composition of the chalcogen mixture was determined to be 95 wt% selenium and 5 wt% tellurium. 

**NATuRE ELECTRONiCS** | www.nature.com/natureelectronics 

**<mark>Articles</mark>** 

**Nature electroNics** 



**Extended Data Fig. 3 | XPS spectra taken from the transferred TeO2 nanosheets and XPS elemental map.** The results reveal the composition of the 2D sheets, shown in Fig. 1a (97.7 mol% TeO2 and 2.3 mol% Se). **a** , The peak in the O 1 s binding energy region located at 530.6 eV is associated with TeO242 **b** , The Te<sup>4+</sup> 3d5/2 peak is located at 576.4 eV<sup>42</sup> . **c** , A small amount of Se was detected in the Se 3d region with a peak located for the 3d5/2 at 55.2 eV<sup>43</sup> . **d** , XPS elemental map of a deposited flake on the right indicates the TeO2 flake, while Se is revealed as a sparse residue on the substrate. 

**NATuRE ELECTRONiCS** | www.nature.com/natureelectronics 

**<mark>Articles</mark>** 

**Nature electroNics** 



**Extended Data Fig. 4 | Optical images of TeO2. a** - **i** , Transferred 2D TeO2 sheets on a variety of substrates. The labels I-IX refer to the different substrates, while X represents the 2D TeO2 sheet. **j** , A thicker TeO2 sheet can be obtained from repeated roll transfer across the same area. The optical image and AFM step height profile reveal multiple TeO2 sheets stacked on top of one another, which caused an increase in thickness. **k** - **m** , Transfer of a TeO2 flake from a GaAs substrate onto a SiO2 substrate. Optical images of the TeO2 flake on GaAs, polypropylene-carbonate (PPC) and SiO2 substrate, respectively, demonstrate the successful transfer process (See Methods section for the transfer protocol). Black scale bars are 50 μm. 

**NATuRE ELECTRONiCS** | www.nature.com/natureelectronics 

**<mark>Articles</mark>** 

**Nature electroNics** 



**Extended Data Fig. 5 | High-resolution AFM. a** , HRAFM image of 2D β-TeO2 on a Si/SiO2 wafer **b** , The observed spacing is shown in the model crystal structure. 

**NATuRE ELECTRONiCS** | www.nature.com/natureelectronics 

**<mark>Articles</mark>** 

**Nature electroNics** 



**Extended Data Fig. 6 | Hole effective mass.** The calculated hole effective mass ( _m_<sup>∗</sup> _h_<sup>) of 0.51 obtained from Equation S2 utilizing data from STS</sup> measurement (see Supplementary Note 2). 

**NATuRE ELECTRONiCS** | www.nature.com/natureelectronics 

**<mark>Articles</mark>** 

**Nature electroNics** 



**Extended Data Fig. 7 | 2D β-TeO2 valence band spectrum obtained from uPS.** The work function of the material was located at 3.88 eV. 

**NATuRE ELECTRONiCS** | www.nature.com/natureelectronics 

**<mark>Articles</mark>** 

**Nature electroNics** 



**Extended Data Fig. 8 | Atomic Orbital Projected DOS plot of the bilayer.** The results show which types of atomic orbitals of Te and O contribute to the upper valence bands. The projections are partitioned into the different atomic orbital types (s, p, d) for O and Te. The plot clearly shows that in the region near the valence band maximum, O and Te p orbitals form the major contribution to the bands, suggesting π-bonding. 

**NATuRE ELECTRONiCS** | www.nature.com/natureelectronics 

**<mark>Articles</mark>** 

**Nature electroNics** 



**Extended Data Fig. 9 | Conductive path in bilayer β-TeO2.** For simplicity, the crystal structure of the bottom layer of the two layers found in unit cell thick β-TeO2 (Fig. 1c) is shown. The charge density shown in Fig. 1c suggests that conduction most efficiently occurs close to the interlayer band edge (top side of the displayed monolayer), while the DOS associated with the VBM is sparse at the bottom of the shown β-TeO2 layer. Here the conduction pathways are shown along the b-axis (green) and the a-axis (red). The DFT calculations indicate a hole mobility of 7690 cm<sup>2</sup> V<sup>-1</sup> s<sup>-1</sup> along the b-axis and 436 cm<sup>2</sup> V<sup>-1</sup> s<sup>-1</sup> along the a-axis, respectively. The higher mobility along the b-axis arises due to the shorter mean free path lengths and transport through regions of high DOS, while transport along the a-axis requires a longer mean free path that diverts into regions of low DOS. 

**NATuRE ELECTRONiCS** | www.nature.com/natureelectronics 

**<mark>Articles</mark>** 

**Nature electroNics** 



**Extended Data Fig. 10 | Stability testing of a TeO2 field-effect transistor showing 1500 On-Off cycles.** No degradation in performance is observed. Five On-Off cycles are shown on the right. 

**NATuRE ELECTRONiCS** | www.nature.com/natureelectronics 

