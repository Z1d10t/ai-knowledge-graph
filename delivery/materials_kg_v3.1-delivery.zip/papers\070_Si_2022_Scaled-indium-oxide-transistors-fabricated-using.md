# Scaled indium oxide transistors fabricated using atomic layer deposition

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Electronics |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 283 |
| 作者 | M. Si, Ze-Hao Lin, Zhizhong Chen, Xing Sun, Hai-Yan Wang, P. Ye |
| DOI | 10.1038/s41928-022-00718-w |
| 源文件 | 070_Si_2022_Scaled-indium-oxide-transistors-fabricated-using.pdf |

---
## Scaled indium oxide transistors fabricated using atomic layer 

## deposition 

Mengwei Si,<sup>1,2</sup> Zehao Lin,<sup>1</sup> Zhizhong Chen,<sup>1</sup> Xing Sun,<sup>3</sup> Haiyan Wang,<sup>3</sup> Peide D. Ye<sup>1</sup> 

_1School of Electrical and Computer Engineering and Birck Nanotechnology Center, Purdue University, West_ 

_Lafayette, Indiana 47907, United States_ 

_2Department of Electronic Engineering, Shanghai Jiao Tong University, Shanghai 200240, China_ 

_3School of Materials Engineering, Purdue University, West Lafayette, IN 47907, United States_ 

*Address correspondence to: yep@purdue.edu (P.D.Y.) 

##### **Abstract** 

In order to continue to improve integrated circuit performance and functionality, scaled transistors with short channel lengths and low thickness are needed. But the further scaling of silicon-based devices and the development of alternative semiconductor channel materials that are compatible with current fabrication processes is challenging. Here we report atomic-layerdeposited indium oxide transistors with channel lengths down to 8 nm, channel thicknesses down to 0.5 nm and equivalent dielectric oxide thickness down to 0.84 nm. Due to the scaled device dimensions and low contact resistance, the devices exhibit high on-state currents of 3.1 A/mm at a drain voltage of 0.5 V and a transconductance of 1.5 S/mm at a drain voltage 1 V. Our devices are a promising alternative channel material for scaled transistors with back-end-of-line processing compatibility. 

1 

The scaling of complementary metal–oxide–semiconductor (CMOS) technology has been the driving force in the advancement of modern integrated circuits over the past few decades. Enhancing gate electrostatic control to improve immunity to short channel effects (SCEs) has, in particular, been a key strategy in the development of aggressively scaled transistor technology. This includes the development of high-k/metal gate technology for equivalent oxide thickness (EOT) scaling, as well as ultrathin body, fin and stacked nanosheet channel transistors; stacked nanosheet transistors are currently being adopted by the semiconductor industry (following FinFET technology) beyond the 3 nm technology node<sup>1</sup> . To further scale length dimensions, while maintaining good drive current, it is critical to suppress SCEs. This can be achieved using increased numbers of thinner stacked channels. However, the performance of conventional semiconductor based transistors decreases rapidly below a thickness of 3 nm for silicon and 10 nm for InGaAs. 

Two-dimensional (2D) semiconductors are an alternate channel material with nanoscale thicknesses and higher mobilities at monolayer or few-layer thickness compared to conventional semiconductors<sup>2–11</sup> . However, 2D materials suffer from a lack of high-quality large-area CMOScompatible growth techniques. It is also difficult to form dielectrics on their van der Waals surfaces. In addition, the materials are difficult to dope and suffer from high contact resistances induced at the Schottky metal/semiconductor contacts. 

Oxide semiconductors — and amorphous indium gallium zinc oxide (IGZO) in particular — are leading semiconducting channel materials in thin-film transistors (TFTs) for flat-panel display applications<sup>12</sup> . But despite being a mature technology for high-volume manufacturing, oxide semiconductors are rarely considered as channel materials for scaled high-performance transistors. 

2 

This due to their low charge carrier mobility of about 10 cm<sup>2</sup> /V ⋅ s and the fact that when used in mass production they typically require channel thicknesses of up to several tens of nanometer<sup>13</sup> . However, there has been interest in the use of oxide semiconductor transistors in CMOS back-endof-line (BEOL) for monolithic 3D integration applications<sup>14–21</sup> . In particular, an atomic layer deposition (ALD) based oxide semiconductor and device technology was developed with channel thicknesses down to sub-1 nm and high field-effective mobility (μFE) >100 cm<sup>2</sup> /V ⋅ s (ref<sup>20,22–25</sup> ). The wafer-scale homogenous and conformal ALD indium oxide (In2O3) thin film has a low thermal budget of 225 °C and an atomically smooth surface. The ability to deposit conformal films on 3D structures by ALD could be useful for 3D integration applications, including 3D BEOL integration and 3D vertical NAND. 

ALD deposited In2O3 has a number of advantages for use in transistor applications. The layer-bylayer self-limited growth mechanism of ALD<sup>26–29</sup> enables an atomically smooth surface, so that nanometre-thick uniform thin films can be achieved that suppress roughness related carrier scattering and deterioration of band structure. In addition, the charge neutrality level (CNL) of In2O3 lies deep inside the conduction band so a high electron density exists in atomically thin channels providing a more forgiving metal to semiconductor low-resistive contact due to Fermi level pinning<sup>24</sup> , thus leading to the high on-state currents in transistors that use nanometre thick channels. 

In this Article, we report high-performance In2O3 transistors fabricated using ALD. Our devices have channel lengths (Lch) down to 8 nm, channel thicknesses (Tch) as low as 0.5 nm and equivalent dielectric oxide thicknesses (EOT) down to 0.84 nm. The scaling and low contact resistance of the devices enable them to achieve on-state currents (ID,max) of 3.1 A/mm at drain voltages (VDS) of 

3 

0.5 V and transconductance values (gm) of 1.5 S/mm at VDS of 1 V. Our devices offer promising performance compared to devices based on conventional semiconducting materials (such as Si and GaAs), 2D semiconductors, and other oxide semiconductors, particularly at the ultrathin scale of 1–3.5 nm. 

##### **Results and Discussion** 

Fig. 1a illustrates the schematic diagram of the ALD In2O3 transistor in this work. The gate stack includes 40 nm Ni as gate metal and HfO2 as gate dielectric unless otherwise specified, 0.5 to 3.5 nm In2O3 as semiconducting channels. In2O3 by ALD exhibits an atomically smooth surface with surface roughness as low as 0.16 nm,<sup>22</sup> measured by atomic force microscopy (AFM), being beneficial to the thickness scaling of ALD In2O3. The device has a channel width (Wch) of 2 μm for Lch equal or above 40 nm while a Wch of 0.6 μm for Lch below 40 nm. The Wch was accurately defined by e-beam lithography and dry etching as shown in Fig. S1b. A reduced Wch is used to suppress the self-heating effect. Ni by e-beam evaporation is used as source/drain electrodes. The device fabrication process is discussed in great details in methods section. Fig. 1b shows the highangle annular dark field scanning transmission electron microscopy (HAADF-STEM) with energy-dispersive x-ray spectroscopy (EDX) mapping of a representative In2O3 transistor with Lch of 8 nm, Tch of 3.5 nm and hafnium oxide thickness (Tox) of 3 nm, highlighting Ni/In/O elements. EDX mapping with Ni/In/Hf/O elements is shown in Fig. S1a. Lch defined as the distance between source/drain Ni electrodes is measured to be 8 nm in this device. Fig. 1c presents the HAADFSTEM with EDX mapping images on a W/HfO2/Al2O3/In2O3/Ni stack, with In2O3 thicknesses from 0.7 nm to 1.5 nm. The thicknesses of In2O3 are determined by both AFM measurements and TEM images here similar to that in previous work.<sup>24</sup> Fig. 1d and 1e show the ID-VGS and ID-VDS 

4 

characteristics of a representative ALD In2O3 transistor with Lch of 1 μm, Tch of 1.2 nm and 10 nm HfO2/1 nm Al2O3 as gate insulator. The device exhibits high on/off ratio > 10<sup>10</sup> due to the relatively wide bandgap of In2O3 and negligible hysteresis due to the high-quality oxide/semiconductor interface. This device has a subthreshold (SS) of 130.4 mV/dec at VDS of 1 V, which can be furtherly reduced by EOT scaling and proper interface engineering.<sup>22,23</sup> 

To further improve the performance of ALD In2O3 transistors, device scaling is performed including channel length scaling, EOT scaling and channel thickness scaling, where EOT scaling and channel thickness scaling are essential to enhance the gate electrostatic control to improve the immunity to short channel effects. Tch scaling down to 0.5 nm is achieved in this work as shown in the ID-VGS characteristics with Tch of 0.8 nm, 0.65 nm and 0.5 nm in Figs. 2a-2c. The corresponding ID-VDS characteristics are shown in Figs. 2d-2f. The devices have SS of 109.0 mV/dec, 114.3 mV/dec and 108.2 mV/dec at VDS of 1 V for Tch of 0.8 nm, 0.65 nm and 0.5 nm, respectively. Here, 5 nm HfO2 is used as gate dielectric. As we can see, even with Tch of 0.5 nm, well-behaved transfer characteristics with on/off ratio over 7 orders are achieved. A functional transistor made of a 3D semiconducting channel material and with Tch as low as 0.5 nm has never been reported before because of two reasons. First, it is very challenging to achieve atomically smooth and uniform semiconducting film by conventional thin-film deposition techniques such as sputtering, chemical vapor deposition (CVD), etc., resulting in the degradation of electrical performance due to carrier scattering and the change of band structures due to roughness. Second, it is difficult to form a good metal/semiconductor contact with low contact resistivity on ultrathin semiconducting film. Fermi level pinning problem owing to the metal-induced gap states (MIGS) results in the Schottky barrier at metal/semiconductor interface, which is more severe in ultrathin film due to the quantum confinement effects. ALD In2O3 is found to overcome these two 

5 

challenges at nanometer scale. First, the layer-by-layer self-limiting growth mechanism ensures the atomically smooth surface and uniform film. Second, the CNL of bulk In2O3 aligns about 0.4 eV above EC, so that thick In2O3 behaves like a conducting oxide.<sup>30</sup> As a result, Fermi level is 

pinned above EC for metal/In2O3 contact, leading to a low contact resistance below 0.1 Ω ⋅ mm even at nanometer scale. The contact resistance was extracted by transmission line method (TLM) as previously reported in Ref. 20. Note that, the above property is fundamental when searching for a 3D semiconductor with high performance at ultrathin channel. It is expected that a 3D semiconductor with CNL aligns far above EC (or far below valence band edge as EV for p-type devices) is necessary to achieve high-performance transistor with ultrathin channel at nanometer scale. Figs. 2g-2i present the maximum drain current (ID,max), transconductance (gm) and fieldeffective mobility (μFE) scaling metrics. μFE is calculated using the maximum gm at low drain bias. The on-state performance degrades rapid below 1 nm, as shown in Fig. 2. Devices with Tch of 0.4 nm has no detectable drain currents as shown in Fig. S2a. And ID,max reduces exponentially when Tch decreases linearly from 0.8 nm to 0.5 nm, as shown in Fig. S2b due to the impact of quantum confinement on the band structure of In2O3 thin film. The drain current scaling metrics is found to deviate from 1/L as shown in Fig. 2g, indicating that it is more difficult to accumulate carriers in long channels, most likely due to the percolation mechanism.<sup>31</sup> Additional data on SS and VT scaling metrics are shown in Fig. S3. 

A second approach to enhance the gate electrostatic control is EOT scaling. Here, we demonstrate high-performance ALD In2O3 transistors with EOT scaled down to 0.84 nm. Fig. 3a shows the C-V characteristics of the gate stack capacitor (Ni/3 nm HfO2/3.5 nm In2O3/Ni), fabricated together with In2O3 transistors with same gate stack. EOT is calculated to be 0.84 nm, using Cox=ϵ0ϵSiO2/EOT, where ϵSiO2 is 3.9 as dielectric constant of SiO2, ϵ0 is 8.85×10<sup>-14</sup> F/cm as 

6 

vacuum permittivity and Cox is measured from C-V measurement at high VGS at low frequency. These numbers confirm a high-quality bulk gate oxide and oxide/semiconductor interface. The doping concentration (ND) of In2O3 can be extracted from 1/C<sup>2</sup> versus voltage characteristics 2 ~~,~~<sup>32</sup> where q is the elementary charge, ϵS is the relative dielectric according to 𝑁𝑁𝐷𝐷 = 𝑞𝑞𝜖𝜖𝑆𝑆𝜖𝜖0𝑑𝑑(1/𝐶𝐶<sup>2</sup> )/𝑑 constant of In2O3, which is about 8.9.<sup>33</sup> Fig. S4 shows the 1/C<sup>2</sup> versus voltage characteristics obtained from Fig. 3a. From the slope of 1/C<sup>2</sup> versus voltage characteristics, ND can be estimated to be 9.0×10<sup>19</sup> /cm<sup>3</sup> . Fig. 3b shows the ID-VDS characteristics of an In2O3 transistor with Lch of 1 μm, Tch of 3.5 nm and EOT of 0.84 nm, showing well-behaved drain current saturation. Figs. 3c and 3d show the ID-VGS and ID-VDS characteristics of an In2O3 transistor with Lch of 50 nm, Tch of 3.5 nm and EOT of 0.84 nm. The device has SS of 387.3 mV/dec at VDS of 0.7 V. The relatively large SS and apparent drain-induced-barrier-lowering (DIBL) is partly due to the gate leakage current in highly scaled EOT. Maximum ID of 2.4 A/mm is achieved at a low VDS of 0.7 V. Drain current saturation is not achieved due to VGS-VT is much larger than VDS, so that the pinch-off condition is not fulfilled. Figs. 3e and 3f summarize the ION and gm scaling metrics of In2O3 transistors with Lch from 1 μm down to 50 nm, Tch of 3.5 nm and Tox from 3 nm to 5 nm. Each data point represents the average of at least 5 devices. The small error bar in these plots demonstrates that the ALD based In2O3 transistors are highly uniform. ION is extracted at VGSVT=1 V and VDS=1 V. Maximum gm is extracted at VDS=1 V. ION and gm are found to be improved significantly by EOT scaling. A high average ION of 1.2 A/mm is achieved at Lch of 50 nm and at VGS-VT=1 V and VDS=1 V. A high average gm of 1.5 S/mm is achieved at Lch of 50 nm and at VDS=1 V. There values are the best among known reported oxide semiconductor transistors. 

Figs. 4a and 4b show the ID-VGS and ID-VDS characteristics of ALD In2O3 transistors with Lch of 8 nm, Tch of 2.5 nm, and EOT of 0.84 nm. A record high ID,max of 3.1 A/mm is achieved due 

7 

to the scaled device dimension and low contact resistance, where ID > 3 A/mm is achieved on oxide semiconductor transistors. The ID,max and gm scaling metrics with Lch from 1 μm down to 8 nm of In2O3 transistors are shown in Figs. 4c and 4d. A lower VDS of 0.5 V is used for shorter channel length to avoid the self-heating effect due to high power density in ultra-scaled device area. The corresponding VDS at different Lch is marked in the figure. Considering VDS of 0.5 V and ID of 3.1 A/mm, RC can be estimated to be less than 0.08 Ω ⋅ mm. 

The performance of scaled ALD In2O3 transistors in this work are benchmarked with stateof-the-art high-performance transistors with ultrathin channel, such as 2D transistors and oxide semiconductor transistors, using figure of merits of ION, gm, RC and mobility versus channel thickness (the data is summarized in supplementary Table I). ALD In2O3 transistors exhibit the largest ID,max in the range of 1-3.5 nm and largest gm below 3.5 nm, among all known semiconductor thin film to the authors’ best knowledge, as shown in Figs. 5a and 5b. Such highperformance material and device properties are mainly contributed by the low contact resistance benefiting from the unique CNL alignments in In2O3, as shown in Fig. 5c, and the high mobility in nanometer scale between 1-3.5 nm, also benefiting from the atomically thickness control of ALD, as shown in Fig. 5d. 

##### **Conclusion** 

In summary, we have reported an ALD based oxide semiconductor transistor technology that shows promising on-state currents — in comparison to both established and emerging material technologies — when channel thicknesses are fabricated in the range of approximately 1 to 3.5 nm. Our approach takes advantage of the self-limiting growth mechanism of ALD and the unique 

8 

band structure of In2O3. The conformal deposition on 3D structures by ALD also the potential to create new opportunities for 3D integration, such as BEOL compatible transistors for monolithic 3D integration and semiconducting channels for 3D vertical NAND. 

9 

##### **Methods** 

**Device Fabrication.** The device fabrication process is similar to previous work.<sup>22</sup> The device fabrication process started with solvent cleaning of p+ Si substrate with thermally grown 90 nm SiO2. A bi-layer photoresist lithography process (PMGI SF9 + AZ1518) was then applied for the sharp lift-off of 40 nm Ni gate metal by e-beam evaporation. This step is critical to avoid sidewall metal coverage, so that high-quality ALD gate dielectric can be formed for EOT scaling. HfO2 with various thicknesses as gate insulator were deposited by ALD at 200 °C with [(CH3)2N]4Hf (TDMAHf) and H2O as Hf and O precursors. In2O3 thin films with various thicknesses were deposited by ALD at 225 ℃ using (CH3)3In (TMIn) and H2O as In and O precursors. N2 is used as carrier gas at a flow rate of 40 sccm. The base pressure at N2 flow rate of 0 sccm is 169 mTorr while base pressure at N2 flow rate of 40 sccm is 437 mTorr. Concentrated hydrochloric acid was employed for the channel isolation. S/D ohmic contacts were formed by e-beam evaporation of Ni in two steps to avoid the difficulty on sub-10 nm lift-off process. It is difficult to form sub-10 nm channel length by one step e-beam lithography because of the proximity effect that causing the electron back scattering to the channel region. Therefore, a two-step e-beam lithography process was adopted by the formation of source electrode first and then the drain electrode. A wide range of distances between source and drain electrodes are defined in the masks so that both short and long channel length can be achieved. Then, a second step ICP dry etching using BCl3/Ar plasma was used to accurately define the channel width. The devices were annealed in O2 at 250 ℃ for 4 min to further improve the performance. 

**Material Characterization.** The thickness of the In2O3 was determined together by AFM, TEM and ellipsometry. AFM measurement was done with a Veeco Dimension 3100 atomic force microscope system. TEM lamella samples were prepared with Helios G4 UX Dual Beam SEM. 

10 

FEI TALOS F200X operated at 200 kV equipped with super-X electron-dispersive X-ray spectroscopy was used for HAADF-STEM imaging. 

**Device Characterization.** Electrical characterization was carried out with a Keysight B1500 system and with a Cascade Summit probe station in dark and N2 environments at room temperature and at atmosphere. 

**Data availability.** The data that support the plots within this paper and other findings of this study are available from the corresponding author upon reasonable request. 

##### **Acknowledgements** 

This work was supported in part by the Semiconductor Research Corporation (SRC) nCore Innovative Materials and Processes for Accelerated Compute Technologies (IMPACT) Center and in part by the Air Force Office of Scientific Research (AFOSR) and SRC/Defense Advanced Research Projects Agency (DARPA) Joint University Microelectronics Program (JUMP) Applications and Systems-driven Center for Energy Efficient integrated Nano Technologies (ASCENT) Center. 

##### **Author Contributions** 

P.D.Y. and M.S. conceived the idea and proposed the ALD In2O3 scaling research. M.S. developed the atomic layer deposition process of In2O3 as high-performance oxide semiconductor. M.S. and Z.L. did the device fabrication, electrical measurement and analysis on thickness and EOT scaling of ALD In2O3 devices. Z.L. and M.S. conducted the channel length scaling of ALD In2O3 devices 

11 

down to 8 nm. Z.C., X.S. and H.W. performed the STEM and EDX measurements. M.S. and P.D.Y. co-wrote the manuscript and all authors commented on it. 

##### **Financial Interest Statement** 

The authors declare no competing financial interest. 

##### **Supplementary Information** 

Additional details for HAADF-STEM cross-sectional image with EDX element mapping (O, Ni, In and Hf), I-V characterstics of ALD In2O3 transistors with Tch of 0.4 nm, SS and VT scaling metrics, C-V characterization of the gate stack capacitor, detailed information on the benchmarking are in the supplementary information. 

#### **Figure Captions** 

##### **Figure 1 | Schematic diagram, TEM images and I-V characteristics of ALD In2O3 transistors.** 

**a,** Schematic diagram of an ALD In2O3 transistor. **b,** HAADF-STEM cross sectional image with EDX element mapping of an In2O3 transistor with Lch of 8 nm, Tch of 3.5 nm and 3 nm HfO2 as gate insulator, capturing the 8 nm channel length. **c,** HAADF-STEM cross-sectional images with EDX element mapping and AFM measurements of In2O3 transistors with W/HfO2/Al2O3/In2O3/Ni gate stack with Tch of from 0.7 nm to 1.5 nm. **d,** ID-VGS and **e,** ID-VDS characteristics of a representative ALD In2O3 transistor with Lch of 1 μm, Tch of 1.2 nm and 10 nm HfO2/1 nm Al2O3 as gate insulator. The device exhibits high on/off ratio > 10<sup>10</sup> and negligible hysteresis due to the relatively wide bandgap semiconductor and high-quality oxide/semiconductor interface. 

12 

**Figure 2 | Thickness scaling of ALD In2O3 down to 0.5 nm.** ID-VGS characteristics of ALD In2O3 transistors with Lch of 40 nm, Tch of **a,** 0.8 nm, **b,** 0.65 nm and **c,** 0.5 nm and 5 nm HfO2 as gate insulator.  ID-VDS characteristics of the same ALD In2O3 transistors as in Figs. 2a-2c with Lch of 40 nm, Tch of **d,** 0.8 nm, **e,** 0.65 nm and **f,** 0.5 nm and 5 nm HfO2 as gate insulator. **g,** ID,max, **h,** gm and **i,** μFE scaling metrics of ALD In2O3 transistors with different Tch and with 5 nm HfO2 as gate insulator at VDS of 1 V. Each data point represents the average of at least 5 devices. Well-behaved transfer and output characteristics with on/off ratio > 10<sup>7</sup> are achieved with channel thickness down to 0.5 nm. The impact of Schottky barrier at metal/semiconductor interface on output characteristics is clearly observed with Tch is below 1 nm due to the effect of quantum confinement on the band structure of ultrathin In2O3 film. 

**Figure 3 | EOT scaling of ALD In2O3 transistors down to sub-1 nm. a,** C-V measurement of the gate stack capacitor (Ni/3 nm HfO2/3.5 nm In2O3/Ni) at 2 kHz, fabricated together with the ALD In2O3 transistor on the same chip. EOT of 0.84 nm is achieved, suggesting a high quality HfO2/In2O3 interface by ALD. **b,** ID-VDS characteristics of an In2O3 transistor with Lch of 1 μm, Tch of 3.5 nm and EOT of 0.84 nm, showing well-behaved drain saturation due to the high drain bias. A high drain current of 835 μA/μm is achieved at this long Lch of 1 μm. **c,** ID-VGS and **d,** IDVDS characteristics of an In2O3 transistor with Lch of 50 nm, Tch of 3.5 nm and EOT of 0.84 nm, at VDS of 0.05 V and 0.7 V. The relatively low on/off ratio is because of the gate leakage current at off-state, which may be further improve by threshold voltage tuning. **e,** ION and **f,** gm scaling metrics of In2O3 transistors with Lch from 1 μm to 50 nm, Tch of 3.5 nm and Tox of 3, 3.5 and 5 nm. ION is extracted at VGS-VT=1V and VDS=1 V. gm is extracted at VDS=1 V. Each data point represents 

13 

the average of at least 5 devices. High ION of 1.2 A/mm at VGS-VT=1 V and VDS=1 V and gm of 1.5 S/mm at VDS=1 V are achieved. 

**Figure 4 | Channel length scaling of ALD In2O3 transistors down to 8 nm. a,** ID-VGS and **b,** IDVDS characteristics of In2O3 transistors with Lch of 8 nm, Tch of 2.5 nm, and EOT of 0.84 nm. **c,** ID,max and **d,** gm scaling metrics of best-performance In2O3 transistors with Lch from 1 μm to 8 nm with Tch of 2.5 nm. Lower voltages at shorter channel devices are used to avoid the impact of selfheating on devices. 

**Figure 5 | Benchmarking of ALD In2O3 with other ultrathin semiconductors.** Comparison of **a,** ID,max, **b,** gm, **c,** RC and **d,** mobility versus channel thickness characteristics with other highperformance oxide semiconductor (doped-In2O3) devices by sputtering and 2D semiconductor devices (MoS2, WS2, BP). The data used in this figure is listed in supplementary Table I. ALD In2O3 demonstrates best performance in terms of ID,max, gm, RC and mobility in 1-3.5 nm range compared to all known semiconducting materials to the authors’ best knowledge. 

14 

##### **References** 

1. Loubet, N. _et al._ Stacked nanosheet gate-all-around transistor to enable scaling beyond FinFET. in _IEEE Symposium on VLSI Technology_ T230–T231 (IEEE, 2017). doi:10.23919/VLSIT.2017.7998183. 

2. Lingming Yang _et al._ High-performance MoS2 field-effect transistors enabled by chloride doping: Record low contact resistance (0.5 kΩ·µm) and record high drain current (460 µA/µm). in _IEEE Symposium on VLSI Technology_ 192–193 (IEEE, 2014). doi:10.1109/VLSIT.2014.6894432. 

3. Krasnozhon, D., Dutta, S., Nyffeler, C., Leblebici, Y. & Kis, A. High-frequency, scaled MoS2 transistors. in _IEEE Int. Electron Devices Meet._ 703–706 (IEEE, 2015). doi:10.1109/IEDM.2015.7409781. 

4. Liu, Y. _et al._ Pushing the Performance Limit of Sub-100 nm Molybdenum Disulfide Transistors. _Nano Lett._ **16** , 6337–6342 (2016). doi:10.1021/acs.nanolett.6b02713. 

5. Yang, L. M. _et al._ Few-layer black phosporous PMOSFETs with BN/Al2O3 bilayer gate dielectric: Achieving Ion= 850 μA/μm, gm= 340 μS/μm, and Rc=0.58 kΩ·μm. in _IEEE Intl. Electron Devices Meet._ 127-130 (IEEE, 2016). doi:10.1109/IEDM.2016.7838354. 

6. Si, M., Yang, L., Du, Y. & Ye, P. D. Black phosphorus field-effect transistor with record drain current exceeding 1 A/mm. in _2017 75th Annual Device Research Conference (DRC)_ 1–2 (IEEE, 2017). doi:10.1109/DRC.2017.7999395. 

7. Li, X. _et al._ High-speed black phosphorus field-effect transistors approaching ballistic limit. _Sci. Adv._ **5** , eaau3194 (2019). doi:10.1126/sciadv.aau3194. 

8. Chou, A.-S. _et al._ High On-Current 2D nFET of 390 μA/μm at VDS = 1V using Monolayer CVD MoS2 without Intentional Doping. in _IEEE Symposium on VLSI Technology_ TN1.7 

15 

(IEEE, 2020). doi:10.1109/VLSITechnology18217.2020.9265040. 

9. Shen, P. C. _et al._ Ultralow contact resistance between semimetal and monolayer semiconductors. _Nature_ **593** , 211–217 (2021). doi:10.1038/s41586-021-03472-9. 

10. Lin, D. _et al._ Scaling synthetic WS2 dual-gate MOS devices towards sub-nm CET. in _IEEE Symposium on VLSI Technology_ T3-1 (IEEE, 2021). 

11. McClellan, C. J., Yalon, E., Smithe, K. K. H., Suryavanshi, S. V. & Pop, E. High Current Density in Monolayer MoS2 Doped by AlOx. _ACS Nano_ **15** , 1587–1596 (2021). doi: 10.1021/acsnano.0c09078. 

12. Nomura, K. _et al._ Amorphous Oxide Semiconductors for High-Performance Flexible ThinFilm Transistors. _Jpn. J. Appl. Phys._ **45** , 4303–4308 (2006). doi: 10.1143/JJAP.45.4303. 

13. Kamiya, T., Nomura, K. & Hosono, H. Present status of amorphous In–Ga–Zn–O thin-film transistors. _Sci. Technol. Adv. Mater._ **11** , 044305 (2010). doi: 10.1088/14686996/11/4/044305. 

14. Matsubayashi, D. _et al._ 20-nm-Node trench-gate-self-aligned crystalline In-Ga-Zn-Oxide FET with high frequency and low off-state current. in _IEEE Int. Electron Devices Meet._ 141–144 (IEEE, 2015). doi:10.1109/IEDM.2015.7409641. 

15. Li, S. _et al._ Nanometre-thin indium tin oxide for advanced high-performance electronics. _Nat. Mater._ **18** , 1091–1097 (2019). doi:10.1038/s41563-019-0455-8. 

16. Li, S., Gu, C., Li, X., Huang, R. & Wu, Y. 10-nm Channel Length Indium-Tin-Oxide transistors with Ion = 1860 μA/μm, Gm = 1050 μS/μm at Vds = 1 V with BEOL Compatibility. in _IEEE Int. Electron Devices Meet._ 905–908 (IEEE, 2020). doi:10.1109/IEDM13553.2020.9371966. 

17. Samanta, S. _et al._ Amorphous IGZO TFTs featuring Extremely-Scaled Channel Thickness 

16 

and 38 nm Channel Length : Achieving Record High Gm,max of 125 µS/µm at VDS of 1 V and ION of 350 µA/µm. in _IEEE Symposium on VLSI Technology_ TH2.3 (IEEE, 2020). doi:10.1109/VLSITechnology18217.2020.9265052. 

18. Chakraborty, W. _et al._ BEOL Compatible Dual-Gate Ultra Thin-Body W-Doped IndiumOxide Transistor with Ion = 370µA/µm, SS = 73mV/dec and Ion/Ioff ratio > 4x10<sup>9</sup> . in _Symposium on VLSI Technology_ TH2.1 (2020). doi: 10.1109/VLSITechnology18217.2020.9265064. 

19. Si, M. _et al._ Indium–Tin-Oxide Transistors with One Nanometer Thick Channel and Ferroelectric Gating. _ACS Nano_ **14** , 11542–11547 (2020). doi:10.1021/acsnano.0c03978. 

20. Si, M., Lin, Z., Charnas, A. & Ye, P. D. Scaled Atomic-Layer-Deposited Indium Oxide Nanometer Transistors With Maximum Drain Current Exceeding 2 A/mm at Drain Voltage of 0.7 V. _IEEE Electron Device Lett._ **42** , 184–187 (2021). doi:10.1109/LED.2020.3043430. 

21. Han, K. _et al._ First Demonstration of Oxide Semiconductor Nanowire Transistors: a Novel Digital Etch Technique, IGZO Channel, Nanowire Width Down to ~20 nm, and Ion Exceeding 1300 µA/µm. in _IEEE Symposium on VLSI Technology_ (IEEE, 2021). 

22. Si, M., Charnas, A., Lin, Z. & Ye, P. D. Enhancement-Mode Atomic-Layer-Deposited In2O3 Transistors With Maximum Drain Current of 2.2 A/mm at Drain Voltage of 0.7 V by LowTemperature Annealing and Stability in Hydrogen Environment. _IEEE Trans. Electron Devices_ **68** , 1075–1080 (2021). doi:10.1109/TED.2021.3053229. 

23. Charnas, A., Si, M., Lin, Z. & Ye, P. D. Enhancement-mode atomic-layer thin In2O3 transistors with maximum current exceeding 2 A/mm at drain voltage of 0.7 V enabled by oxygen plasma treatment. _Appl. Phys. Lett._ **118** , 052107 (2021). doi:10.1063/5.0039783. 

24. Si, M. _et al._ Why In2O3 Can Make 0.7 nm Atomic Layer Thin Transistors. _Nano Lett._ **21** , 

17 

500–506 (2021). doi:10.1021/acs.nanolett.0c03967. 

25. Si, M., Lin, Z., Chen, Z. & Ye, P. D. First Demonstration of Atomic-Layer-Deposited BEOL-Compatible In2O3 3D Fin Transistors and Integrated Circuits: High Mobility of 113 cm<sup>2</sup> /V ⋅ s, Maximum Drain Current of 2.5 mA/μm and Maximum Voltage Gain of 38 V/V in In2O3 Inverter. in _IEEE Symposium on VLSI Technology_ T2-4 (IEEE, 2021). 

26. Mourey, D. A., Zhao, D. A., Sun, J. & Jackson, T. N. Fast PEALD ZnO thin-film transistor circuits. _IEEE Trans. Electron Devices_ **57** , 530–534 (2010). doi: 10.1109/TED.2009.2037178. 

27. Kim, H. Y. _et al._ Low-Temperature Growth of Indium Oxide Thin Film by PlasmaEnhanced Atomic Layer Deposition Using Liquid Dimethyl(N-ethoxy-2,2dimethylpropanamido)indium for High-Mobility Thin Film Transistor Application. _ACS Appl. Mater. Interfaces_ **8** , 26924–26931 (2016). doi:10.1021/acsami.6b07332. 

28. Ma, Q. _et al._ Atomic-Layer-Deposition of Indium Oxide Nano-films for Thin-Film Transistors. _Nanoscale Res. Lett._ **13** , 4 (2018). doi:10.1186/s11671-017-2414-0. 

29. Lee, J. _et al._ High mobility ultra-thin crystalline indium oxide thin film transistor using atomic layer deposition. _Appl. Phys. Lett._ **113** , 112102 (2018). doi:10.1063/1.5041029. 

30. Robertson, J. & Clark, S. J. Limits to doping in oxides. _Phys. Rev. B_ **83** , 075205 (2011). doi:10.1103/PhysRevB.83.075205. 

31. Kamiya, T., Nomura, K. & Hosono, H. Electronic Structures Above Mobility Edges in Crystalline and Amorphous In-Ga-Zn-O: Percolation Conduction Examined by Analytical Model. _J. Disp. Technol._ **5** , 462–467 (2009). doi: 10.1109/JDT.2009.2022064. 

32. Schroder, D. K. _Semiconductor Material and Device Characterization_ . (John Wiley & Sons, Inc., 2006). doi:10.1002/0471749095. 

18 

33. Hamberg, I. & Granqvist, C. G. Evaporated Sn‐doped In2O3 films: Basic optical properties and applications to energy‐efficient windows. _J. Appl. Phys._ **60** , R123–R160 (1986). doi: 10.1063/1.337534. 

19 

**a** 

**b** 



<!-- Start of picture text -->
Ni  Ni<br>S D<br>8 nm<br>In2O3/HfO2<br>Ni<br>c<br>In Al Hf W Ni<br>Ni<br>In2O3<br>HfO2<br>Al2O3<br>W<br>30 nm<br>2<br>Tch=0.7 nm 2 Tch=1 nm 2 Tch=1.2 nm 2 Tch=1.5 nm<br>0 0 0 0<br>-2 -2 -2<br>-2<br>Length (a.u.) Length (a.u.) Length (a.u.) Length (a.u.)<br>d e<br>10 - 3 18 0<br> V DS=0.05 V<br>10 - 4 VGS=-4 V to 4.6 V in 0.2 V step<br>16 0<br>10 - 5 V DS=1 V<br>14 0<br>10 - 6<br>10 - 7 12 0<br>10 - 8 10 0<br>10 - 9<br>8 0<br>10 -1 0<br>6 0<br>10 -1 1<br>10 -1 2 4 0<br>Lch = 1  m m<br>10 -1 3 2 0<br>Tch = 1.2 nm<br>10 -1 4<br>0<br>10 -1 5<br>-3 -2 -1 0 1 2 3 4 5 0.0 0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0<br>VGS (V)<br>VDS (V)<br>Figure 1<br>Height (nm)<br>I (A/m) m D<br>m)I (A/ m D<br>Height (nm) Height (nm) Height (nm)<br><!-- End of picture text -->

**b** 

**a** 

**c** 



<!-- Start of picture text -->
10-3<br>10-4 10-4<br>10-4 L ch = 40 nm<br>10-5 Lch = 40 nm 10-5 Lch = 40 nm<br>10-5 T ch = 0.8 nm<br>10-6 Tch = 0.65 nm 10-6 Tch = 0.5 nm<br>10-6<br>10-7 10-7<br>10-7<br>10-8 10-8<br>10-8<br>10-9 10-9<br>10-9<br>10-10 10-10<br>10-10<br>10-11  V DS=0.05 V 10-11  V DS=0.05 V 10-11  V DS=0.05 V<br>10-12 10-12 V DS=1 V 10-12<br>V DS=1 V V DS=1 V<br>10-13 10-13 10-13<br>10-14<br>10-14 10-14<br>-1 0 1 2 3 0 1 2 3 0 1 2 3<br>VGS (V)<br>VGS (V) VGS (V)<br>d e f<br>40 0<br>V GS=0 V to 3 V in 0.2 V step 1 0 1. 0 VGS=0 V to 3.6 V in 0.2 V step<br>VGS=0 V to 3.6 V in 0.2 V step<br>8 0. 8<br>30 0<br>6 0. 6<br>20 0<br>4 0. 4<br>10 0<br>2 0. 2<br>0 0. 0<br>0<br>0.0 0.5 1.0 0 1 2 0 1 2<br>VDS (V) VDS (V) VDS (V)<br>h<br>g i<br>103<br>1 0 2<br>1/L<br>102<br>102<br>1 0 1<br>101 101<br>1 0 0<br>100  0.8 nm  0.8 nm<br>100 10-1<br> 0.8 nm<br> 0.65 nm  0.65 nm<br> 0.65 nm<br> 0.5 nm  0.5 nm<br>10-1<br> 0.5 nm 10-2<br>10-1<br>10-2<br>10-3<br>10-1 100 10-1 100 10-1 100<br>Lch ( m m) Lch ( m m)<br>Figure 2 Lch ( m m)<br>I (A/m) m D<br> (IA/m) mm D<br>I (A/m) m D,max<br>I (A/m) m D<br>S/ (m)g m m<br>m)I (A/ m D I (A/m) m D<br>I (A/m) m D<br>2s) (cm/V m× FE<br><!-- End of picture text -->

**b** 

**a** 



<!-- Start of picture text -->
4. 0<br>Ni<br>3. 5 3.5 nm In 2 O 3 2 kHz<br>3 nm HfO 2<br>Ni<br>3. 0<br>2. 5 3 nm HfO2<br>EOT=0.84 nm<br>2. 0<br>-1.0 -0.5 0.0 0.5 1.0<br>Voltage (V)<br>c<br>10- 2<br>Lch = 50 nm<br>10- 3 T ch = 3.5 nm<br>10- 4<br> V DS=0.05 V<br>10- 5<br>V DS=0.7 V<br>V DS=0.05 V<br>10- 6<br>IG<br>V DS=0.7 V<br>10- 7<br>10- 8<br>-3 -2 -1 0 1 2<br>VGS (V)<br>e<br> 5  nm<br> 3 .5 nm<br>10 3<br> 3  nm<br>HfO2<br>10 2<br>VGS-VT=1 V<br>VDS=1 V<br>Tch=3.5 nm<br>10 -1 10 0<br>Figure 3 Lch ( m m)<br>2Capacitance (F/cm) m<br>I (A/m) m D<br>I (A/m) m ON<br><!-- End of picture text -->



<!-- Start of picture text -->
90 0 VGS=-1.6 V to 2 V in 0.2 V step<br>80 0<br>Lch = 1  m m<br>70 0<br>Tch = 3.5 nm<br>60 0<br>50 0<br>40 0<br>30 0<br>20 0<br>10 0<br>0<br>0.0 0.5 1.0 1.5 2.0 2.5 3.0<br>VDS (V)<br>d<br>250 0 VGS=-3.2 V to 2 V in 0.2 V step<br>200 0<br>150 0<br>100 0<br>50 0<br>0<br>0.0 0.5<br>VDS (V)<br>f<br> 5  nm<br> 3 .5 nm<br>10 3<br> 3  nm<br>HfO2<br>10 2<br>VDS=1 V<br>Tch=3.5 nm<br>10 -1 10 0<br>Lch ( m m)<br>I (A/m) m D<br>I (A/m) m D<br>S/ (m)g m m<br><!-- End of picture text -->

**b** 

**a** 



<!-- Start of picture text -->
10- 2<br> V DS=0.1 V VGS=-2.4 V to1.6 V in 0.4 V step<br>300 0<br>V DS=0.5 V<br>Lch=8 nm<br>Tch=2.5 nm<br>10- 3<br>200 0<br>10- 4<br>100 0<br>Lch = 8 nm<br>Tch = 2.5 nm<br>10- 5 0<br>-3 -2 -1 0 1 2 0.0 0.1 0.2 0.3 0.4 0.5<br>VGS (V) VDS (V)<br>c d<br>VDS=0.5 V<br>VDS=0.7 V<br>10 3<br>VDS=1 V<br>10 3<br>VDS=0.5 V<br>VDS=1 V<br>VDS=0.7 V<br>10 2<br>Tch=2.5 nm<br>Tch=2.5 nm<br>10 2<br>10-2 10-1 100 10-2 10-1 100<br>Lch ( m m) Lch ( m m)<br>Figure 4<br>I (A/m) m D<br>I (A/m) m D,max<br>I (A/m) m D<br>S/ (m)g m m<br><!-- End of picture text -->

**b** 

**a** 



<!-- Start of picture text -->
 ALD In2O3 (This work)<br>4<br> Doped-In2O3<br> 2D Materials<br>3<br>2<br>1<br>0<br>100 101<br>Channel Thickness (nm)<br>c<br>10 2<br> ALD In2O3 (This work)<br> Doped-In2O3<br>10 1  2D Materials<br>10 0<br>10 - 1<br>10 - 2<br>10 0 10 1<br>Figure 5 Channel Thickness (nm)<br>I (mA/m) m D,max<br>R (km) W×m C<br><!-- End of picture text -->

# **d** 



<!-- Start of picture text -->
 ALD In2O3 (This work)<br>2. 0<br> Doped-In2O3<br> 2D Materials<br>1. 5<br>1. 0<br>0. 5<br>0. 0<br>100 101<br>Channel Thickness (nm)<br>20 0  ALD In2O3 (This work)<br> Doped-In2O3<br> 2D Materials<br>15 0<br>10 0<br>5 0<br>0<br>10 0 10 1<br>Channel Thickness (nm)<br>2/Vs)Mobility (cm ×<br> (mS/m)g m m<br><!-- End of picture text -->

### Supplementary Information for: 

## Scaled indium oxide transistors fabricated using atomic layer 

## deposition 

Mengwei Si,<sup>1,2</sup> Zehao Lin,<sup>1</sup> Zhizhong Chen,<sup>1</sup> Xing Sun,<sup>3</sup> Haiyan Wang,<sup>3</sup> Peide D. Ye<sup>1</sup> 

_1School of Electrical and Computer Engineering and Birck Nanotechnology Center, Purdue University, West_ 

_Lafayette, Indiana 47907, United States_ 

_2Department of Electronic Engineering, Shanghai Jiao Tong University, Shanghai 200240, China_ 

_3School of Materials Engineering, Purdue University, West Lafayette, IN 47907, United States_ 

*Address correspondence to: yep@purdue.edu (P.D.Y.) 

1 

##### **1. Characteristics of Ultrathin In2O3 Transistors** 



<!-- Start of picture text -->
a b<br>Ni  Ni<br>S<br>In2O3<br>G<br>In2O3/HfO2<br>1 µm D<br>Ni<br><!-- End of picture text -->

**Figure S1. a,** TEM cross-sectional image with EDX element mapping (O, Ni, In and Hf) of an In2O3 transistor with Lch of 8 nm, Tch of 3.5 nm and 3 nm HfO2 as gate insulator. **b,** SEM image from top view of a typical long channel device with a channel width of 2 μm defined by dry etching. 



<!-- Start of picture text -->
a b<br>10 -4<br>10 -5  VDS=0.05 V 10 2<br>Lch=0.1  m m<br>10 -6<br>VDS=1 V<br>10 -7<br>10 1<br>10 -8<br>L ch = 40 nm<br>10 -9<br>10 -10 T ch = 0.4 nm 10 0<br>10 -11<br>10 -12<br>10 -1<br>10 -13<br>10 -14<br>10 -15 10 -2<br>0 1 2 3 0.5 0.6 0.7 0.8<br>Tch (nm)<br>VGS (V)<br>I (A/m) m D<br>m)I (A/ mm D,max<br><!-- End of picture text -->

**Figure S2. a,** ID-VGS characteristics of a representative ALD In2O3 transistor with Lch of 40 nm, Tch of 0.4 nm and 5 nm HfO2 as gate insulator. **b,** ID,max versus Tch characteristics for ALD In2O3 transistors extracted from Fig. 2g. 

2 



<!-- Start of picture text -->
a b<br>5<br> 0.8 nm<br>250  0.65 nm  0.8 nm<br>4  0.65 nm<br> 0.5 nm<br>200  0.5 nm<br>3<br>150<br>2<br>100<br>1<br>50<br>0 0<br>10-1 100 10-1 100<br>Lch ( m m) Lch ( m m)<br>SS (mV/dec)<br>V (V)T<br><!-- End of picture text -->

**Figure S3. a,** SS and **b,** VT scaling metrics of ALD In2O3 transistors with different Tch and with 5 nm HfO2 as gate insulator. 

##### **2. C-V Characterization of the Gate Stack Capacitor** 



<!-- Start of picture text -->
2<br>Ni<br>3.5 nm In2O3<br>3 nm HfO2<br>Ni<br>1<br>ND=9 ´ 1019 /cm3<br>-1 0 1<br>Voltage (V)<br>221141/C (/F)10 cm ´<br><!-- End of picture text -->

**Figure S4.** 1/C<sup>2</sup> versus voltage characteristics of a MOS capacitor with Ni/3 nm HfO2/3.5 nm In2O3/Ni stack. 

##### **3. Benchmarking of ALD In2O3 Transistors** 

Table I. Performance of State-of-the-Art Transistors with Ultrathin Semiconducting Channel 

3 

|**Material**|**Thickness**<br>**(nm)**|**Lch (nm)**|**ID,max (A/µm)**|**gm (S/µm)**|**mobility**<br>**(cm2/V·s)**|**RC (kΩ·µm)**|**Reference**|
|---|---|---|---|---|---|---|---|
|ITO|4|40|5.20E-04|5.50E-04|-|-|[1]|
|ITO|4|100|8.50E-04|-|-|-|[1]|
|ITO|10|200|1.15E-03|-|-|-|[1]|
|ITO|3.5|10|1.86E-03|1.05E-03|40|0.162|[2]|
|IGZO|3.6|38|3.50E-04|1.25E-04|34|-|[3]|
|IGZO|61.3|100|1.30E-03|6.12E-04|-|-|[4]|
|IGZO|15|27|1.10E-04|1.74E-04|-|-|[5]|
|IWO|7|100|5.00E-04|-|20|1.2|[6]|
|MoS2|0.65|35|1.14E-03|-|20|0.123|[7]|
|MoS2|3.8|80|8.30E-04|-|51|0.54|[8]|
|MoS2|4|10|5.20E-04|1.42E-04|-|-|[9]|
|MoS2|5|100|4.60E-04|-|55|0.5|[10]|
|MoS2|0.65|380|7.00E-04|-|33.5|0.48|[11]|
|MoS2|0.65|100|3.90E-04|-|-|1.1|[12]|
|MoS2|1.95|70|3.70E-04|1.00E-04|6|1.8|[13]|
|MoS2|0.65|500|4.50E-04|-|102.6|-|[14]|
|MoS2|2.6|2000|2.71E-04|-|22|2.2|[15]|
|MoS2|3.3|2000|2.04E-04|-|25|-|[15]|
|BP|14.9|200|1.04E-03|-|-|-|[16]|
|BP|12.5|100|1.20E-03|-|-|-|[17]|
|BP|8|200|8.50E-04|3.40E-04|144|0.58|[18]|
|WS2|1.3|100|3.10E-04|3.20E-04|20|-|[19]|
|WS2|2.1|40|7.00E-04|-|-|0.5|[20]|



4 

##### **References** 

1. Li, S. _et al._ Nanometre-thin indium tin oxide for advanced high-performance electronics. _Nat. Mater._ **18** , 1091–1097 (2019). 

2. Li, S., Gu, C., Li, X., Huang, R. & Wu, Y. 10-nm Channel Length Indium-Tin-Oxide transistors with Ion = 1860 μA/μm, Gm = 1050 μS/μm at Vds = 1 V with BEOL Compatibility. in _IEEE Int. Electron Devices Meet._ 905–908 (IEEE, 2020). 

3. Samanta, S. _et al._ Amorphous IGZO TFTs featuring Extremely-Scaled Channel Thickness and 38 nm Channel Length : Achieving Record High Gm,max of 125 µS/µm at VDS of 1 V and ION of 350 µA/µm. in _IEEE Symposium on VLSI Technology_ TH2.3 (IEEE, 2020). 

4. Han, K. _et al._ First Demonstration of Oxide Semiconductor Nanowire Transistors: a Novel Digital Etch Technique, IGZO Channel, Nanowire Width Down to ~20 nm, and Ion Exceeding 1300 µA/µm. in _IEEE Symposium on VLSI Technology_ (IEEE, 2021). 

5. Matsubayashi, D. _et al._ 20-nm-Node trench-gate-self-aligned crystalline In-Ga-Zn-Oxide FET with high frequency and low off-state current. in _IEEE Int. Electron Devices Meet._ 141–144 (IEEE, 2015). 

6. Chakraborty, W. _et al._ BEOL Compatible Dual-Gate Ultra Thin-Body W-Doped IndiumOxide Transistor with Ion = 370µA/µm, SS = 73mV/dec and Ion/Ioff ratio > 4x10<sup>9</sup> . in _Symposium on VLSI Technology_ TH2.1 (IEEE, 2020). 

7. Shen, P. C. _et al._ Ultralow contact resistance between semimetal and monolayer semiconductors. _Nature_ **593** , 211–217 (2021). 

8. Liu, Y. _et al._ Pushing the Performance Limit of Sub-100 nm Molybdenum Disulfide Transistors. _Nano Lett._ **16** , 6337–6342 (2016). 

9. Yang, L., Lee, R. T. P., Rao, S. S. P., Tsai, W. & Ye, P. D. 10 nm nominal channel length MoS2 FETs with EOT 2.5 nm and 0.52 mA/μm drain current. in _2015 73rd Annual Device Research Conference (DRC)_ 237–238 (IEEE, 2015). 

10. Lingming Yang _et al._ High-performance MoS2 field-effect transistors enabled by chloride doping: Record low contact resistance (0.5 kΩ·µm) and record high drain current (460 µA/µm). in _IEEE Symposium on VLSI Technology_ 192–193 (IEEE, 2014). 

11. McClellan, C. J., Yalon, E., Smithe, K. K. H., Suryavanshi, S. V. & Pop, E. High Current Density in Monolayer MoS2 Doped by AlOx. _ACS Nano_ **15** , 1587–1596 (2021). 

12. Chou, A.-S. _et al._ High On-Current 2D nFET of 390 μA/μm at VDS = 1V using Monolayer CVD MoS2 without Intentional Doping. in _IEEE Symposium on VLSI Technology_ TN1.7 (IEEE, 2020). 

13. Krasnozhon, D., Dutta, S., Nyffeler, C., Leblebici, Y. & Kis, A. High-frequency, scaled MoS2 transistors. in _IEEE Int. Electron Devices Meet._ 703–706 (IEEE, 2015). 

5 

14. Li, T. _et al._ Epitaxial growth of wafer-scale molybdenum disulfide semiconductor single crystals on sapphire. _Nat. Nanotechnol._ (2021). 

15. Kang, J., Liu, W. & Banerjee, K. High-performance MoS2 transistors with low-resistance molybdenum contacts. _Appl. Phys. Lett._ **104** , 2–7 (2014). 

16. Si, M., Yang, L., Du, Y. & Ye, P. D. Black phosphorus field-effect transistor with record drain current exceeding 1 A/mm. in _2017 75th Annual Device Research Conference (DRC)_ (IEEE, 2017). 

17. Li, X. _et al._ High-speed black phosphorus field-effect transistors approaching ballistic limit. _Sci. Adv._ **5** , eaau3194 (2019). 

18. Yang, L. M. _et al._ Few-layer black phosporous PMOSFETs with BN/Al2O3 bilayer gate dielectric: Achieving Ion= 850 μA/μm, gm= 340 μS/μm, and Rc=0.58 kΩ·μm. in _IEEE Intl. Electron Devices Meet._ 127-130 (IEEE, 2016). 

19. Lin, D. _et al._ Scaling synthetic WS2 dual-gate MOS devices towards sub-nm CET. in _IEEE Symposium on VLSI Technology_ (IEEE, 2021). 

20. Pang, C.-S., Wu, P., Appenzeller, J. & Chen, Z. Sub-1nm EOT WS2 -FET with IDS > 600μA/μm at VDS =1V and SS < 70mV/dec at LG =40nm. in _IEEE Int. Electron Devices Meet._ 43–46 (IEEE, 2020). 

6 

