# One-stone-for-two-birds strategy to attain beyond 25% perovskite solar cells

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Communications |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 270 |
| 作者 | Ting-Huan Yang, Li-Li Gao, Jing Lu, Chuang Ma, Ya-Chao Du, Peijun Wang, Zi-Cheng Ding, Shi-Qiang Wang et al. |
| DOI | 10.1038/s41467-023-36229-1 |
| 源文件 | 073_Yang_2023_One-stone-for-two-birds-strategy-to-attain-beyon.pdf |

---
Article 



https://doi.org/10.1038/s41467-023-36229-1 

# One-stone-for-two-birds strategy to attain beyond 25% perovskite solar cells 

Received: 12 May 2022 Tinghuan Yang<sup>1,4</sup> , Lili Gao<sup>1,4</sup> , Jing Lu<sup>1</sup> , Chuang Ma<sup>1</sup> , Yachao Du<sup>1</sup> , Peijun Wang<sup>2</sup> , Zicheng Ding<sup>1</sup> , Shiqiang Wang<sup>1</sup> , Peng Xu<sup>2</sup> , Dongle Liu<sup>1</sup> , Haojin Li<sup>1</sup> , Accepted: 18 January 2023 2 Xiaoming Chang<sup>1</sup> , Junjie Fang<sup>1</sup> , Wenming Tian , Yingguo Yang<sup>3</sup> , Shengzhong (Frank) Liu 1,2 & Kui Zhao<sup>1</sup> Check for updates 

Even though the perovskite solar cell has been so popular for its skyrocketing power conversion efficiency, its further development is still roadblocked by its overall performance, in particular long-term stability, large-area fabrication and stable module efficiency. In essence, the soft component and ionic–electronic nature of metal halide perovskites usually chaperonage large number of anion vacancy defects that act as recombination centers to decrease both the photovoltaic efficiency and operational stability. Herein, we report a one-stone-for-two-birds strategy in which both anion-fixation and associated undercoordinated-Pb passivation are in situ achieved during crystallization by using a single amidino-based ligand, namely 3-amidinopyridine, for metal-halide perovskite to overcome above challenges. The resultant devices attain a power conversion efficiency as high as 25.3% (certified at 24.8%) with substantially improved stability. Moreover, the device without encapsulation retained 92% of its initial efficiency after 5000 h exposure in ambient and the device with encapsulation retained 95% of its initial efficiency after >500 h working at the maximum power point under continuous light irradiation in ambient. It is expected this one-stone-for-two-birds strategy will benefit large-area fabrication that desires for simplicity. 

Organic–inorganic hybrid perovskite solar cells (PSCs) have attracted significant attention from researchers since their first demonstration in 2009<sup>1–3</sup> due to the low-cost solution processing<sup>4</sup> , tunable bandgap<sup>5</sup> , high absorption coefficient<sup>6</sup> , low recombination rate<sup>7</sup> , and high mobility of charge carriers<sup>8</sup> . The power conversion efficiency (PCE) of single-junction PSCs has rapidly increased from 3.8% to a certified value of 25.7%<sup>9–11</sup> . The long-term operational stability of unencapsulated PSCs has also exceeded 1000 h in full sunlight after the interface engineering of device structures and molecular passivation of the 

perovskite layer<sup>2,12–14</sup> . Therefore, PSCs represent a promising nextgeneration photovoltaic technology. 

Over the past few years, it has been demonstrated that the elimination of deep-level defects, which act as detrimental nonradiative recombination centers, is critical for realizing high-performance solar cells<sup>15–18</sup> . To date, iodide anions (I<sup>−</sup> ) vacancy defects constitute the majority of non-radiative recombination centers in the FAPbI3 perovskite layer that are very difficult to mitigate<sup>19,20</sup> . These defects are mainly caused by iodine losses during film fabrication or the I<sup>−</sup> ion 

> 1Key Laboratory of Applied Surface and Colloid Chemistry, Ministry of Education; Shaanxi Key Laboratory for Advanced Energy Devices; Shaanxi Engineering Lab for Advanced Energy Technology; Institute for Advanced Energy Materials; School of Materials Science and Engineering, Shaanxi Normal University, Xi’an 710119, China.<sup>2</sup> Dalian National Laboratory for Clean Energy; State Key Laboratory of Molecular Reaction Dynamics and the Dynamic Research Center for Energy and Environmental Materials; iChEM, Dalian Institute of Chemical Physics, Chinese Academy of Sciences, Dalian 116023, China.<sup>3</sup> Shanghai Synchrotron Radiation Facility (SSRF), Zhangjiang Lab, Shanghai Advanced Research Institute, Chinese Academy of Sciences, Shanghai 201204, China.<sup>4</sup> These authors contributed equally: Tinghuan Yang, Lili Gao. e-mail: tianwm@dicp.ac.cn; liusz@snnu.edu.cn; zhaok@snnu.edu.cn 

Nature Communications |  (2023) 14:839 

1 

Article 

https://doi.org/10.1038/s41467-023-36229-1 

migration during device operation, which produces deep-level defects and directly leads to the degradation of photoelectric properties<sup>15–18</sup> . Furthermore, the I<sup>−</sup> ions desorbed from the inorganic framework can be easily oxidized to I<sup>0</sup> species, which initiate chemical chain reactions accelerating the formation of deep-level defects in perovskite layers<sup>21</sup> . This phenomenon is detrimental for devices operating under complex conditions (including high temperature, continuous light illumination, electrical bias, or their combination) and negatively affects the longterm stability of operational PSCs<sup>22,23</sup> . Therefore, inhibiting the formation and migration of I<sup>−</sup> vacancy defects is critical for stabilizing photoactive perovskite layers and preserving their good photoelectric properties. 

Several attempts have been made to passivate anion vacancy defects through the introduction of additives such as quaternary ammonium halide anions and cations<sup>24</sup> , caffeine and theobromine<sup>19</sup> , CsI–DB21C7 complex<sup>25</sup> , naphthalene-1,8-dicarboximide and perylene3,4-dicarboximide<sup>26</sup> . However, these additives are typically used to passivate undercoordinated Pb<sup>2+</sup> ions after anion species have already escaped from the crystal lattice. To inhibit the formation of anion vacancy defects radically, anions should be pinned to the crystal lattice without the possibility of escaping, which can be theoretically realized through a judicious chemical design by molecular engineering. There are five potential benefits of this approach. First, the introduced materials should be strongly bonded to the Pb–I framework to pin anions to the crystal lattice and suppress the formation of anion vacancies in the source. Second, strong chemical bonding should localize anions that have already escaped from the crystal lattice, which would inhibit the migration of delocalized anions. Third, the space occupied by the introduced materials in the Pb–I framework should not be too large to ensure efficient charge transport between different Pb–I frameworks. Fourth, the introduced materials should be stable under thermal stress and illumination. Fifth, the introduced materials should act as growth-controlling agents to promote the crystallization of perovskites. In previous studies, various additives such as phosphonopropionic acid<sup>13</sup> and amino-based organic ligands<sup>27–29</sup> were used as sacrificial agents to inhibit the formation of anion vacancy defects. However, phosphonopropionic molecules tend to degrade upon heating, while amino-based organic ligands cannot form strong chemical bonds to pin anions to the crystal lattice. Furthermore, the large barrier layer of these organic compounds in the Pb–I framework negatively affected charge transport and led to the formation of a charge extraction barrier, making them unsuitable for high-efficiency stable solar cells. 

In this work, we propose a rational design strategy for anion fixation and suppressing the formation of anions vacancy defects synergistically by a sustainable pinning effect while retaining the efficient charge transport using amidino-based organic molecules to construct highly efficient and stable PSCs. 3-amidinopyridine (3AP) molecules form strong chemical bonds with the Pb–I framework to effectively pin anions and considerably increase the energy barrier of the formation and migration of anion vacancies. Therefore, this onestone-for-two-birds strategy enables us to achieve a PCE as high as 25.3% (certified at 24.8%) and significantly improved operation stability following the ISOS-L-1 stability protocol. The present work paves the way for the anion-vacancy defect engineering via molecule–perovskite coordination, providing an effective and simple solution towards efficient and stable perovskite optoelectronics. 

## Results 

### Molecule–Perovskite coordination 

3AP was selected as an additive to pin anions to the crystal lattice, its chemical structure, Nuclear magnetic resonance hydrogen spectroscopy (<sup>1</sup> H-NMR) and High-resolution mass spectral (HRMS) are shown in Fig. 1a, Supplementary Figs. 1 and 2, respectively. The amidino-based terminal group and –NH–C group in the pyridine ring provide strong 

coordination with Pb–I inorganic frameworks and modulate the Pb–I interlayer distance. By analyzing (3AP)PbI4 single crystals (Supplementary Fig. 3 and Supplementary Table 1)<sup>30</sup> , we found that 3AP molecules were arranged in parallel and anti-symmetrically between Pb–I frameworks with a short interlayer distance of 3.45 Å, which is much shorter than that obtained for previously reported ligands, leading to a unique coordination within the crystals (Supplementary Table 2). 

To explore the unique role of the strong coordination between 3AP and the Pb–I inorganic framework, density functional theory (DFT) calculations were conducted for a super cell of an α-FAPbI3 perovskite slab containing 3AP and other commonly used large organic ligands, such as 2-phenethylammonium (PEA), n-butylammonium (BA), 3- (aminomethyl)piperidinium (3AMP), and 3-(aminomethyl)pyridinium (3AMPY), on its surface (Fig. 1b and Supplementary Fig. 4). We calculated the adsorption energies of these ligands on the perovskite surface, formation energies of I<sup>−</sup> vacancies in the perovskite lattice, and migration energy barrier of I<sup>–</sup> vacancies (the calculation details are provided in density functional theory (DFT) calculations). The adsorption energy of 3AP (3.135 eV) was much higher than those of other perovskite systems containing 3AMP (2.784 eV), 3AMPY (2.988 eV), BA (2.968 eV), and PEA (2.498 eV) (Fig. 1c) due to the strong 3AP–perovskite coordination. The formation energy of I<sup>−</sup> vacancies in the perovskite lattice increased from 1.075 eV for MAPbI3 to 1.422 eV for α-FAPbI3, which is consistent with the higher degree of hydrogen bonding in the second structure<sup>31</sup> . The formation energy of I<sup>−</sup> vacancies further increased above 3.812 eV for the 3AP-perovskite system, which exceeded the values obtained for the perovskite systems with 3AMP (3.574 eV), 3AMPY (3.791 eV), BA (3.716 eV), and PEA (3.584 eV) ligands. Furthermore, the migration barrier energy of I<sup>−</sup> vacancies increased from 0.737 to 1.467 eV after the addition of 3AP molecules, which is also higher than those of the systems containing other ligands (0.86–1.29 eV) (Supplementary Fig. 5 and Table 3). These results indicate that the strong 3AP–perovskite coordination plays the role in anion fixation and suppressing the migration of anion vacancies. 

The coordination between 3AP molecules and Pb–I inorganic frameworks was further investigated by nuclear magnetic resonance (NMR) and X-ray photoelectron spectroscopy (XPS). Samples for analysis were prepared by dissolving neat 3AP or 3AP + PbI2 (1:1) powder in d6-dimethyl sulfoxide (DMSO) solvent. The<sup>1</sup> H resonance signals at 9.60 and 9.37 ppm originated from the C=NH2+ and C–NH2 environments of the amidino group of neat 3AP were shifted to 9.41 and 9.00 ppm for the 3AP + PbI2 system (Fig. 1d)<sup>32–34</sup> , respectively. The 1H resonance signal caused by the pyridine ring was also slightly shifted to higher frequencies. These results suggest the formation of hydrogen bonds between 3AP and I<sup>– 35,36</sup> . The interactions between 3AP with PbI2 were further confirmed by Fourier-transform infrared spectroscopy (FTIR) (Supplementary Fig. 6). We found that the stretching and bending vibration frequencies (marked as “s” and “b”) of the –NH (s) and –NH (b) modes of the amidino group were shifted from 3312 to 3221 cm<sup>–1</sup> and from 1512 to 1523 cm<sup>–1</sup> in the presence of 3AP–PbI2 hydrogen bonds, respectively. Correspondingly, the –CH (s) and –CH (b) modes of the pyridine ring<sup>37</sup> were shifted from 3130/3026 to 3080/ 2959 cm<sup>–1</sup> and from 760 to 771 cm<sup>–1</sup> , respectively. Overall, these observations confirm the formation of strong hydrogen bonds between 3AP and the Pb–I inorganic framework, which is expected to stabilize I<sup>−</sup> anions on the crystal surface or at the grain boundaries. Figure 1e shows the Pb 4f XPS profiles of neat PbI2 and 3AP + PbI2 compounds. The Pb 4f5/2 and Pb 4f7/2 peaks of PbI2 located at 142.09 and 138.25 eV, respectively, were shifted towards lower binding energies by 0.4 eV, indicating the existence of an electron-rich environment of Pb in the 3AP-containing PbI2 lattice due to the strong coordination between 3AP and the Pb–I inorganic framework<sup>38–40</sup> . 

The influence of the molecule–perovskite coordination on the activation energy (Ea) of ion migration was further experimentally 

Nature Communications |  (2023) 14:839 

2 

Article 

https://doi.org/10.1038/s41467-023-36229-1 



<!-- Start of picture text -->
� �<br>3AP<br>FA<br>I<br>Pb<br>�<br>4 Absorption energy      Defect formation energy     Energy barrier<br>3<br>2<br>1<br>0<br>FAPbI3 MAPbI3 3AMP 3AMPY 3AP BA PEA<br>Cations<br>� � �<br>3AP PbI2 Activation energy<br>3AP+PbI2 3AP+PbI2 0.20<br>0.16<br>0.12<br>0.08<br>9.5 9.0 8.5 8.0 7.5 147 144 141 138 135<br>Binding energy (eV)<br>ControlWith 3AMPWith 3AMPYWith 3APWith BAWith PEA<br>)V<br>(e<br>y<br>gre<br>n<br>E<br>)stin<br>(brau. )(Vea<br>ytis E<br>n<br>Iten<br><!-- End of picture text -->

Fig. 1 | 3AP–perovskite coordination. a Chemical structure of the 3AP<sup>+</sup> ion. b Supercell constructed for DFT calculations, in which 3AP molecules are adsorbed on the FAPbI3 (001) surface via FAI terminal groups. c Absorption energies of ligands on the perovskite surface, formation energies of I<sup>−</sup> vacancies in the perovskite structure, and migration energy barriers of I<sup>−</sup> vacancies in the perovskite lattice calculated for the perovskite systems with 3AMP, 3AMPY, 3AP, BA, and PEA 

ligands. d<sup>1</sup> H-NMR spectra of neat 3AP and 3AP + PbI2 compounds. e Pb 4f XPS profiles of the neat 3AP and 3AP + PbI2 powders. f Activation energy (Ea) of ion migration derived from the temperature-dependent conductivities of perovskites with various ligands (see Supplementary Fig. 8). Source data are provided as a Source Data file. 

evaluated by measuring the temperature-dependent conductivity of perovskite films (the schematic diagram of device structure is shown in Supplementary Fig. 7). The plots of temperature-dependent conductivity for the neat perovskite film (denoted as the control) and perovskite films with the above-mentioned ligands are shown in Supplementary Fig. 8<sup>41–43</sup> . The Ea values (the Ea values is calculated by Eq. 3 in the “Methods” section) increased from 0.109 eV for the control perovskite sample to 0.198 eV for the perovskite with 3AP (Fig. 1f). The last value is also higher than those of the perovskites containing 3AMP (0.177 eV), 3AMPY (0.187 eV), BA (0.178 eV), and PEA (0.162 eV). Thus, the presence of 3AP in the Pb–I framework can inhibit the formation of I<sup>−</sup> vacancy defects in PSCs. 

### Photovoltaic performance 

We evaluated the photovoltaic performance of PSCs without (denoted as the control) and with x mol% (x = 4, 8) iodized 3-pyridinecarboximidamide (3API).The solar cells were fabricated with a planar n-i-p device architecture (Fig. 2a), in which compact TiO2 (c-TiO2) and 2,2′,7,7′-tetrakis(N,N-di-p-methoxyphenylamine)−9,9′spirobifluorene (Spiro-OMeTAD) were used as electron-transporting and hole-transporting layers, respectively. The cell performance was considerably enhanced by 3API addition, and the 3AP-based cells demonstrated higher open-circuit voltage (VOC), fill factor (FF), shortcircuit current density (JSC), and PCE values as compared with those of the control cell (see the photovoltaic parameters in Supplementary Table 4). The maximum efficiency was observed for the device with 

4 mol% 3API. The control device exhibited a maximum PCE of 22.76% with a JSC of 24.94 mA cm<sup>−2</sup> , VOC of 1.123 V, and FF of 0.81. Meanwhile, the 3AP-based cells achieved a maximum PCE of 25.3% with VOC of 1.181 V, JSC of 26.04 mA cm<sup>−2</sup> , and FF of 82.21% (Fig. 2b, blue data points). Some cells were sent to an accredited photovoltaic test laboratory (National Institute of Metrology, NIM, China) for certification, and their certified quasi-steady-state efficiency was 24.8% (Fig. 2b, red data points; the certification details are presented in Supplementary Fig. 9). Typical current density—voltage (J–V) characteristics of the control and 3AP-based devices are shown in Fig. 2c, and the stabilized power outputs (SPOs) of the corresponding cells are presented in Fig. 2d. The external quantum efficiency (EQE) of the certified cell yielded an integrated JSC of 25.97 mA cm<sup>−2</sup> (Fig. 2e) with a negligible variation (~0.8%) from the measured JSC, which is higher than that of the control sample (integrated JSC of 24.55 mA cm<sup>−2</sup> ). The relationship between VOC and light intensity is plotted in Fig. 2f. It is based on the following equation<sup>27,44,45</sup> : 



<!-- Start of picture text -->
V OC = ðnkBT=qÞlnðIÞ + B, ð1Þ<br><!-- End of picture text -->

where kB is the Boltzmann constant, T is the temperature, q is the electric charge, B is the constant, and n is the ideality factor. The 3AP-based cell exhibited a smaller slope than that of the control (1.26 kBT/q vs. 1.60 kBT/q), which indicates less intense defectassisted non-radiative recombination in the 3AP-containing perovskite layer. 

Nature Communications |  (2023) 14:839 

3 

Article 

https://doi.org/10.1038/s41467-023-36229-1 



Fig. 2 | Photovoltaic performance of the PSCs without (denoted as control) and with 3API. a Planar n-i-p device structure. b Efficiency statistics of both solar cells including the certified value obtained at the National Institute of Metrology (NIM) 

and lab-measured efficiencies. c Current density–voltage (J–V) curves. d Stabilized power outputs (SPOs). e EQE curves and integrated current densities. f VOC dependences on light intensity. Source data are provided as a Source Data file. 

### Film characterization 

To investigate the effect of the molecule-perovskite coordination on perovskite properties, we performed grazing incidence wide-angle scattering (GIWAXS) characterization of the films. The films exhibited a predominant 3C (100) perovskite phase (q = 1.02 Å<sup>−1</sup> ) with the PbI2 (q = 0.90 Å<sup>−1</sup> ) and undesired 6H (101) phases at 0.83 Å<sup>−1</sup> for the control sample (Fig. 3a). The 3API addition suppressed the formation of the undesired 6H phase but promoted the formation of the 3 C phase, as indicated by the higher diffraction intensity (Supplementary Fig. 10). This provides strong evidence that 3AP can result in a complete conversion from undesired phases to perovskite 3 C species, which is one of the key factors for the improvement of device performance. 

Scanning electron microscopy (SEM) observations showed a slight increase in the average grain size of the perovskite film after 3API addition (1.4 vs. 1.0 μm) (Fig. 3b; see the statistical distribution in the inset). The larger grain size of the 3AP-based film is consistent with the behavior observed by GIWAXS. Monolithic grains were present in the cross-sectional SEM images from their tops to bottoms (Fig. 3c). Atomic force microscopy (AFM) observations revealed a decrease in the surface roughness from 23.3 to 17.0 nm with 3API addition due to the stitched grain boundaries (Supplementary Fig. 11). In addition, the Time-of-Flight Secondary Ion Mass Spectrometry (TOF-SIMS) was performed, which indicates a uniform distribution of 3AP<sup>+</sup> throughout the film as shown in Supplementary Fig. 12). 

Steady-state and time-resolved optical microscopies were performed to explore the optoelectronic properties of the perovskite films. The 3API addition did not change the absorption threshold or photoluminescence (PL) peak position (Fig. 3d). The bandgaps of both 

films determined from their Tauc plots were equal to 1.54 eV (Supplementary Fig. 13). However, we observed an apparent increase in the PL intensity of the 3AP-based films, suggesting that 3API addition reduced the non-radiative recombination in the perovskite film, which was further validated by time-resolved photoluminescence (TRPL). The 3AP-based perovskite film demonstrated a full photoluminescence decay of 5.5 μs (Fig. 3e), which was much longer than the control (1.2 μs). Hence, 3AP addition suppressed the non-radiative carrier recombination, which was consistent with the results of DFT calculations indicating that the formation of I<sup>−</sup> vacancy defects was inhibited by the strong molecule–perovskite coordination, and accounted for the improved photovoltaic metrics. 

We further performed space charge-limited current (SCLC) measurements to quantitatively estimate the defect density (Ndefects) and charge mobility (μelectron) of the films. For this purpose, electrondominated devices (fluorine-doped tin oxide (FTO)/c-TiO2/perovskite/ [6,6]-phenyl-C61-butyric acid methyl ester (PCBM)/Au) were fabricated and characterized under different biases in the dark (Fig. 3f). The Ndefects and μelectron are calculated by Eqs. 4 and 5, respectively. Which are described in the Material characterization. The value of Ndefects decreased from 1.43 × 10<sup>16</sup> to 4.76 × 10<sup>15</sup> cm<sup>−3</sup> with 3API addition, while the value of μelectron increased from 0.139 to 0.339 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> . This result is consistent with the suppressed non-radiative carrier recombination probed by TRPL and attributed to the strong 3AP–perovskite coordination that suppressed I<sup>−</sup> vacancy formation. Capacitance–voltage (C–V) measurements were also performed to elucidate the higher VOC values. The obtained C<sup>−2</sup> –V plots and built-in potentials (Vbi) are presented in Supplementary Fig. 14. It shows that 

Nature Communications |  (2023) 14:839 

4 

Article 

https://doi.org/10.1038/s41467-023-36229-1 



<!-- Start of picture text -->
� � 4<br>10 3.8 10 3.8 Control<br>Control 10 3.6 With 3API 10 3.6 3 With 3API<br>3C (100) 10 3.4 10 3.4 2<br>PbI2 10 3.2 10 3.2<br>6H (101) 10 3.0 10 3.0 1<br>10 2.8 10 2.8<br>0<br>-1.5  -1.0  -0.5    0    0.5    1.0  1.5 -1.5  -1.0  -0.5    0    0.5    1.0  1.5 400 500 600 700 800<br>q xy (Å –1 ) q xy (Å –1 ) Wavelength (nm)<br>� 30 20 � 65 Control  With 3API<br>2010 10 43 Fitting<br>0 0.4Grain size 0.8 1.2( )1.6 0 Grain size 0.8 1.6 2.4 2 ve = 5.5<br>= 1.2<br>Control 1 μm With 3API 1 μm 1<br>0 2 4 6 8<br>Time (μs)<br>� �<br>10 -1 Control<br>Au Au With 3API<br>Spiro-OMeTAD Spiro-OMeTAD 10 -3<br>Perovskite Perovskite V TFL= 0.14 V<br>c-TiO2 c-TiO2 10 -5<br>FTO FTO<br>10 -7 V TFL= 0.42 V<br>500 nm 500 nm Ohmic TFL Child<br>Control With 3API<br>0.1 1<br>Voltage (V)<br>02.<br>15.<br>01.<br> (Å–1) q z<br>05.<br>0<br>Absorption (arb. units) PL Intensity (arb. units)<br>Cstnou Cstnou<br>Current (A)<br><!-- End of picture text -->

Fig. 3 | Characteristics of the control and 3AP-based perovskite films. a Twodimensional GWIAXS images of the final two films obtained after thermal annealing. b SEM images of the final films. The insets show the grain size distributions. c The cross-sectional SEM images of the final films. d Steady-state UV–Vis absorption and 

PL spectra of the films. e TRPL intensities of the films. ‘average’ is denoted as ‘ave’. f Dark J–V curves of the electron-only devices with the FTO/c-TiO2/perovskite/ PCBM/Ag architecture. VTFL is the trap-filled limit voltage. Source data are provided as a Source Data file. 

value of Vbi increased from 1.108 to 1.160 V with 3API addition, which is similar to the VOC trend obtained from the J–V curves and suggests the existence of a wider depletion region for the 3AP-based device<sup>28</sup> . Thus, the charge separation and carrier transport are significantly improved after 3API addition. 

The ultraviolet photo-electron spectroscopy (UPS) test was employed to further illustrate the effect of 3API on the energy band alignment of perovskite (Supplementary Figs. 15 and 16). The introduction of 3API reduced the VBM and CBM of perovskite from –5.46 eV and –3.92 eV to –5.55 eV and –4.01 eV, respectively. The results indicate better energy level alignment between the perovskite layer and the electron transport layer, which is beneficial for charge extraction and transfer. Transient photocurrent (TPC) and transient photovoltage (TPV) were also performed to confirm the effectiveness of 3AP<sup>+</sup> (Supplementary Fig. 17a, b). Compared to the reference device, the device with 3API exhibited shorter charge extraction time (4.25 vs. 9.38 μs) and longer charge compounding time (11.2 vs. 3.07 μs). This indicates that the introduction of 3API can effectively improve the charge extraction process and suppress charge complexation, which is consistent with the UPS results. Kelvin probe force microscopy (KPFM) analysis indicates a higher electronic chemical potential of perovskite with the 3AP addition (Supplementary Fig. 18). The higher electronic chemical potential and reduced energy level (Supplementary Figs. 15 and 16) indicate a less n-type surface, which can facilitate the hole extraction in devices<sup>19</sup> . 

Furthermore, we investigated the effects of different halides (3APX, X = Cl, Br) and molecular stacking on the formation of I<sup>−</sup> vacancies in perovskites. First, I<sup>−</sup> ions were replaced with chloride anions (Cl<sup>−</sup> ) and bromide anions (Br<sup>−</sup> ) while preserving the 3AP<sup>+</sup> ions and replicated the similar observations with 3API addition. The resulting films exhibited enlarged grain size (see the SEM images in Supplementary Fig. 19), decreased film surface roughness (Supplementary Fig. 20), increased PL intensity (Supplementary Fig. 21), decreased nonradiative recombination decay (Supplementary Fig. 22), 

and decreased trap densities (Supplementary Fig. 23) as compared with those of the control. The PCEs of the devices containing 3APCl (24.6%) and 3APBr (24.7%) are comparable to that of the 3API-based cell (see the J–V curves in Supplementary Fig. 24 and photovoltaic parameters in Supplementary Table 5), suggesting that 3AP<sup>+</sup> ions are responsible for eliminating vacancy defects. Thus, strong molecule–perovskite coordination is required to suppress the formation of vacancy defects. In addition, we also verify the positive role of 3AP in other different perovskite compositions. Both FA0.9Cs0.1PbI3 and FA0.92MA0.08PbI3 devices exhibit effective enhancements of photovoltaic parameters with the 3API addition (Supplementary Figs. 25 and 26), which demonstrates the universality of the 3AP additive. 

### Stacking defects 

In sought to better understand how the 3AP addition influences stacking defects of perovskites, in situ PL spectroscopy and photocurrent mapping were performed during perovskite fabrication process and for devices when working under illumination, respectively. Figure 4a, b shows the in situ PL spectra of the films during spinning and thermal annealing. During spinning, both films exhibit negligible emission (Fig. 4a, b, left). During the annealing process (Fig. 4a, b, right), the suggesting no illuminating α-FAPbI3 phase shows a rapid formation as evidenced from a quick rise of PL intensity. The following sharp decrease of PL intensity can be attributed to solvent volatilization, film crystallization restructuring, and negative temperature coefficient<sup>46–48</sup> . Note that the control film exhibits a continuous but a slow decrease of PL intensity with further thermal annealing (Fig. 4c), which is indicative of the formation of stacking defects. The 3API addition not only retarded the perovskite crystallization process but also inhibited the formation of stacking defects, as confirmed by the slowly increased PL intensity with further thermal annealing (Fig. 4d). This indicates that in situ crystallization modulation and defect passivation can be realized through the strong anchoring effect of 3API with [PbI6]<sup>4–</sup> during the formation of the films. 

Nature Communications |  (2023) 14:839 

5 

Article 

https://doi.org/10.1038/s41467-023-36229-1 



<!-- Start of picture text -->
� �<br>900 500 1200<br>Control Control<br>800 Anti solvents  327 793<br>dropping<br>700 153 387<br>Spin coating Annealing<br>600 -20 -20<br>0 10 20 30 40 50 0 50 100 150 200 250 0 50 100 150 200 250<br>Time (s) Time (s) Time (s)<br>� �<br>900 500 770<br>With 3API With 3API<br>800 Anti solvents  327 507<br>dropping<br>700 153 243<br>Spin coating Annealing<br>600 -20 -20<br>0 10 20 30 40 50 0 50 100 150 200 250 0 50 100 150 200 250<br>Time (s) Time (s) Time (s)<br>� 1400 21.15 �<br>Control<br>> 16 nA 43%<br>2k<br>700 15.56<br>1k<br>PL intensity 2 μm 0 Photocurrent 2 μm 11.45 010 12 14 16 18 20 22<br>Photocurrent (nA)<br>� 25.70 �<br>1400 With 3API<br>> 16 nA 55%<br>2k<br>700 12.10 1k<br>PL intensity 2 μm 0 Photocurrent 2 μm 5.700 0 8 12 16 20 24<br>Photocurrent (nA)<br>)m<br>(n<br>htg<br>n<br>ele<br>v PL intensity<br>a<br>W<br>)m<br>(n<br>htg<br>n<br>ele<br>v<br>a PL intensity<br>W<br>Control Counts<br>IP<br>A<br>3<br>h<br>ti<br>Counts<br>W<br><!-- End of picture text -->

Fig. 4 | Stacking defects during film formation and in the working devices. a, b In situ PL spectra of films with or without 3API during spin coating and annealing. c, d The PL intensity extract from a and b. e, f PL intensity and 

photocurrents of the working devices with or without 3API. g, h The histogram of photocurrent statistics. Source data are provided as a Source Data file. 

The PL intensity and photocurrent mappings on the working PSCs were recorded by using a laser-scanned and time-resolved PL microscopy coupled with a photocurrent detection module as we reported previously<sup>49</sup> . We collected the PL intensity and local photocurrent mapping within a 10.5 × 10.5 µm area for both devices (Supplementary Fig. 27). Figure 4e, f, left shows the PL intensity mapping, where the distribution of grain size and shape is clearly identifiable. The devices with 3API show a larger perovskite grain size (Supplementary Fig. 28a) and are coupled with a stronger PL intensity than the control devices, which is consistent with the SEM (Fig. 3b), PL (Fig. 3d), TRPL (Fig. 3e) and PL mapping (Supplementary Fig. 21) results. Furthermore, we observed fewer photons from larger grains for both devices, which indicates more efficient charge separation and extraction. The photocurrent mapping on the same area are shown in Fig. 4e, f, right. The devices with 3API exhibit higher photocurrents compared to the control (Supplementary Fig. 28b), which further indicates less stacking defets with 3API. We also performed statistical histograms for the different photocurrent values in the photocurrent images. It is clear that the percentage of photocurrent values >16 nA in the devices increase from 43 to 55% after the introduction of 3API (Fig. 4g, h). Both in situ observation during film formation and ex situ analysis on the working devices explain well the importance of in situ passivation of stacking defects 

during the formation for highly efficient charge separation and extraction in the working devices. 

### Stability enhancement of solar cells 

To assess the stability of solar cells, we first measured the intrinsic phase stability of perovskite films stored in a dark air environment at a temperature of 25 °C and relative humidity of 30–40%. Figure 5a shows the X-ray diffraction (XRD) patterns of the control and 3AP-based perovskite films recorded before and after ambient aging for 74 days. The diffraction signals of the δ-FAPbI3 and PbI2 phases became more prominent in the control perovskite film after aging. However, these undesired phases were not detected in the 3AP-based perovskite film stored under the same conditions, indicating that the strong molecule–perovskite coordination can inhibit the transformation and degradation of the 3C phase. The cross-sectional SEM images and corresponding Energy dispersive spectroscopy (EDS) of complete cells before and after aging indicate less I<sup>−</sup> migration toward Spiro-OMeTAD layer (Supplementary Fig. 29) with the 3AP addition, which is due to strong hydrogen bonding and anchoring effect of 3AP on perovskite. We further investigated the thermal stability of unencapsulated solar cells stored at 85 °C under a nitrogen atmosphere (Fig. 5b). We used Poly[bis(4-phenyl)(2,4,6-trimenthylphenyl)amine] (PTAA) instead of Spiro-OMeTAD and the organic passivation layer was removed to 

Nature Communications |  (2023) 14:839 

6 

Article 

https://doi.org/10.1038/s41467-023-36229-1 



<!-- Start of picture text -->
� �<br>1.0<br>Control With 3API<br>0.8<br>0.6<br>74 days 74 days<br>0.4 Control<br>With 3API<br>0.2<br>Thermal stress at 85 ºC<br>fresh fresh 0.0<br>10 20 30 10 20 30 0 100 200 300 400 500<br>Time (h)<br>�<br>1.0<br>0.8<br>0.6<br>Control<br>0.4 With 3API<br>0.2 Long-term stability at ambient conditions<br>0.0<br>0 1000 2000 3000 4000 5000<br>Time (h)<br>�<br>1.0<br>0.8<br>0.6<br>Control<br>0.4 With 3API<br>0.2 MPP for encapsulated cells in ambient  at ~25 ºC<br>0.0<br>0 100 200 300 400 500<br>Time (h)<br>)stin<br>u<br>(bra.<br>ytis<br>n<br>Iten Normalized PCE<br>Normalized PCE<br>Normalized PCE<br><!-- End of picture text -->

Fig. 5 | Stability studies of perovskite films and solar cells. a XRD patterns of the control and 3AP-based perovskite films recorded before and after aging for 74 days. b PCE evolution observed for the control and 3AP-based devices stored without encapsulation at 85 °C under a nitrogen atmosphere. c PCE evolution observed for the control and 3AP-based devices stored without encapsulation at ambient conditions (25 °C and 30–40% relative humidity). d Stabilized maximum power point (MPP) values recorded for the control and 3AP-based devices with encapsulation under continuous light irradiation with a white LED lamp at 100 mW cm<sup>–2</sup> in ambient (25 °C and 30–40% relative humidity). All the error bars represent the standard deviation for devices. Source data are provided as a Source Data file. 

avoid introducing sources of instability. The 3AP-based cell retained 83% of its initial efficiency after 500 h of thermal treatment, which was higher than that of the control cell (52% of its initial efficiency). Furthermore, the long-term environmental stability of the unencapsulated cells stored under ambient conditions (25 °C and 30–40% relative humidity) was also investigated (Fig. 5c). The PCEs decreased by ~20% for the control cell and only by 8% for the 3AP-based cell after 5000 h. Compared with the control cell, the 3AP-based cell exhibits a smaller FF loss during aging (Supplementary Fig. 30 and Table 6). Finally, we checked the operational stability of encapsulated solar cells by performing maximum power point (MPP) tracking in the ambient (25 °C and 30–40% relative humidity) following the ISOS-L-1 stability protocol<sup>50</sup> . The 3AP-based solar cells exhibits a 5% decrease of their initial efficiency after 510 h. While the PCE of the control device decreased by 16% after only 240 h (Fig. 5d). From these observations, we can conclude that the anion-vacancy defect engineering via strong molecule–perovskite coordination provides an effective and simple solution for increasing both the efficiency and stability of PSCs. 

## Discussion 

In this study, we demonstrate that anion fixation and associated undercoordinated-Pb passivation in FAPbI3-based perovskites can be realized synergistically by functionalizing perovskite surface with amidino-based ligand 3AP. The results of theoretical calculations combined with the NMR, XPS, in situ PL, and in-depth optoelectronic characterization data helped elucidate the mechanism of the molecule–perovskite coordination and its effect on the anion fixation and vacancy defect formation in the perovskite structure. The anionvacancy defect engineering via the molecule–perovskite coordination increased the PCE of planar PSCs from 22.8 to 25.3% (certified at 24.8%) 

and their stability. Our findings offer an effective chemical strategy for the facile fabrication of high-performance stable PSCs and are potentially applicable to other perovskite optoelectronic devices. 

## Methods 

### Materials 

Iodized 3-pyridinecarboximidamide (3API) was synthesized by dissolving 1 g of pyridecarboximidamide (98%, Damas-beta) and 2.25 g hydroiodic acid (HI, 57 wt.% in water, Aldrich) in 10 mL ethanol followed by stirring at 0 °C for 6 h for crystallization. The obtained 3API crystals was dissolved in ethanol for recrystallization. The resulting product was dried at 50 °C in a vacuum oven for 24 h. 3APBr and 3APCl were obtained via a similar fabrication procedure. 

Formamidinium iodide (FAI), Pb (II) iodide (PbI2), and spiroOMeTAD were procured from Advanced Election Technology Co., Ltd. Methylammonium chloride (MACl), Poly[bis(4-phenyl)(2,4,6trimethylphenyl)amine]) (PTAA) and phenylethylammonium iodide (PEAI) were obtained from Xi’an Polymer Light Technology Co. Chlorobenzene (CB) (anhydrous, 99.8%), Toluene (anhydrous, 99.8%) and isopropanol (IPA) (anhydrous, 99.5%) were purchased from Sinopharm Chemical Reagent Co., Ltd. N,N-dimethylformamide (DMF) (anhydrous, 99.8%) and dimethyl sulfoxide (DMSO) (anhydrous, ≥99.9%) were obtained from Alfa Aesar Inc. 4-tert-butylpyridine (t-BP, 99%), bis(trifluoromethane)sulfonamide lithium salt (Li-TFSI, 99.95% trace metals basis), HI solution (55–58 wt.% in water), HBr solution (48 wt.% in water), and HCl (37 wt.% in water), were purchased from Aladdin. 

Synthesis of (3AP)PbI4 single crystals. The synthesis and characterization of (3AP)PbI4 single crystals can be found in previous work<sup>30</sup> . Briefly, 3 mmol (670 mg) PbO was first dissolved into a mixtures solution including 30 mL of HI solution and 3 mL of H3PO2 solution (50 wt.% in water, Aladdin), and stirred continuously at 180 °C to obtain a clear solution. Then, 3 mmol (473 mg) of 3APCl was added to the above solution, and stirred continuously at180 °C until 3APCl was completely dissolved. The temperature of the above solution was then lowered to room temperature to allow the crystals to precipitate. Finally, the products were filtered and dried in an oven at 50 °C for 12 h. All the processes were operated in ambient air. 

### Perovskite film preparation and device fabrication 

Perovskite solar cells (PSCs) were fabricated with a planar n-i-p structure of fluorine-doped tin oxide (FTO)/c-TiO2/FAPbI3/Spiro-OMeTAD/ Au. FTO glass substrates (2.5 × 2.5 cm) were cleaned by ultrasonication in a special cleaning concentrate (Hellmanex III (Sigma–Aldrich) mixed with ultrapure water at a volume ratio of 1–1.5:100) and ultrapure water for 20 min. After that, they were cleaned sequentially with IPA and ethanol for 20 min. Finally, the substrates were dried under a nitrogen flow and treated with ultraviolet (UV) light for 15 min before the deposition of c-TiO2. c-TiO2 layers were prepared by chemical bath deposition on FTO substrates. Before spin coating, FTO/c-TiO2 substrates were annealed at 200 °C for 30 min in air and treated with UVozone for 15 min. To fabricate the FAPbI3 perovskite thin film, a precursor solution (1.5 M) was prepared by dissolving PbI2 and FAI in a solvent mixture of DMF and DMSO (volume ratio: 4:1). 3APX (X = I, Br, Cl) were added to the precursor solutions at different concentrations ranging from 0 to 8 mol%. MACl (34.4 mg) was added to all perovskite precursor solutions. For each sample, 70 μL of the filtered solution was spread over the FTO/c-TiO2 substrate at 6000 rpm for 50 s. During spin coating, 1 mL of diethyl ether was dripped after spinning for 10 s using a pipette. The film was annealed on a hot plate at 150 °C for 10 min to obtain a black film, and after cooling to room temperature (∼25 °C), the perovskite film was spin-coated with PEAI dissolved in IPA (20 mM) at 3000 rpm for 30 s without further processing. The holetransporting layer was deposited onto the top of the perovskite layer 

Nature Communications |  (2023) 14:839 

7 

Article 

https://doi.org/10.1038/s41467-023-36229-1 

at a spin rate of 5000 rpm for 30 s using a Spiro-OMeTAD solution, which consisted of 90 mg Spiro-OMeTAD, 36 μL t-BP, 22 μL Li-TFSI (520 mg Li-TFSI in 1 mL acetonitrile), and 1 mL CB. For the thermal stability of devices (with an initial PCE of 21.59%, a VOC of 1.104 V, a JSC of 25.43 mA cm<sup>–2</sup> , a FF of 76.89% for With 3API, and an initial PCE of 19.45%, a VOC of 1.063 V, a JSC of 25.21 mA cm<sup>–2</sup> , a FF of 72.62% for Control), 12 mg PTAA was dissolved in 1 ml toluene, then 6 μL Li-TFSI (340 mg Li-TFSI in 1 mL acetonitrile) and 6 μL tBP were added. The PTAA solution was spin-coated on surface of the perovskite layer at 2000 rpm. for 30 s. Finally, an 80-nm Au electrode was vapordeposited on the top of the Spiro-OMeTAD layer, and the fabricated device was oxidized for 24 h. 

### Device characterization 

J–V characteristics of the fabricated devices were obtained using a Keithley 2400 SourceMeter under ambient conditions at room temperature. Both reverse scans (1.7 → 0 V, step: 0.02 V, delay time: 20 ms) and forward scans (0 → 1.7 V, step: 0.02 V, delay time: 20 ms) were conducted. The area of the cell is 0.09 cm<sup>2</sup> and a mask of 0.07274 cm<sup>2</sup> (certificated by NIM, China. The certificate No.: CDjc2021-11025) was used to determine the effective area of the device before the test. The power output of the lamp was calibrated using a National Renewable Energy Laboratory traceable KG5-filtered silicon reference cell. The external quantum efficiency (EQE) was measured on a QE-R system (Enli Technology Co., Ltd.) using a 300-W Xe lamp as the light source. The monochromatic light intensity for EQE measurements was calibrated using a reference silicon photodiode. The maximum power point (MPP) tracking were obtained using solar cell aging test system (Shenzhen Lancheng Technology Co., Ltd.) under a simulated continuous AM1.5 G illumination (LED, 100 mW cm<sup>–2</sup> , encapsulation devices in ambient at 25 °C and 30–40% relative humidity). 

### Material characterization 

UV-visible absorption spectra were acquired on a PerkinElmer UVLambda 950 instrument. Steady-state photoluminescence (PL) and time-resolved photoluminescence (TRPL) spectra were recorded with a PicoQuant FT-300 spectrometer. The excitation laser wavelength is 510 nm, the frequency is 40 MHz (for PL) and 0.5 MHz (for TRPL), and the detection wavelength range is 500–900 nm. X-ray diffraction (XRD) studies were performed using a DX-2700BH diffractometer (Dandong Haoyuan Instrument Co., Ltd.). Grazing incidence wideangle scattering (GIWAXS, λ = 1.24 Å, incidence angle: 0.40°) was performed at the National Facility for Protein Science in Shanghai. Scanning electron microscopy (SEM) images were obtained using a Hitachi SU-8020 field-emission scanning electron microscope (Japan). Atomic force microscopy (AFM) images were obtained by a Bruker Dimension Icon instrument (USA). X-ray photoelectron spectroscopy (XPS) was performed on a photoelectron spectrometer (ESCALAB Xi+, Thermo Fisher Scientific). Fourier transform infrared (FTIR) spectra were recorded with a Bruker VERTEX 70 infrared spectrophotometer using KBr sheets.<sup>1</sup> H nuclear magnetic resonance spectra were recorded on a JNM–ECZ400R/S1 apparatus (JEOL, Japan). Capacitance–voltage (C–V) measurements were performed on an electrochemical workstation (Modulab XM, USA) and the frequency was set to 200 kHz and the scan voltage range was 0–1.6 V. The built-in potential (Vbi) was further calculated according to the Mott–Schottky equation: 



<!-- Start of picture text -->
C �2 = 2ðVbi � VaÞ=A 2 eεε0NA ð2Þ<br><!-- End of picture text -->

where NA and Va are the carrier concentration and applied voltage, respectively; ε0 and ε denote the vacuum permittivity and dielectric constant of the perovskite, respectively; and e represents the electron charge<sup>28,33</sup> . 

Temperature-dependent conductivity measurements were performed using a Keysight 4200 source meter to determine the ion 

migration activation energies (Ea) of perovskite films at different temperatures (188–333 K)<sup>43</sup> , were placed in a manual dark probe station equipped with a temperature controller to obtain a required temperature, and the sweep voltage range was 0–3 V. The value of Ea was further calculated according to the Nernst–Einstein relation<sup>41,42</sup> 



<!-- Start of picture text -->
σT = σ0 expð�Ea=kBTÞ ð3Þ<br><!-- End of picture text -->

where σ0 is the constant, kB is the Boltzmann constant, and T is the temperature (K). 

Defect density (Ndefects) and charge mobility (μelectron) were determined from the electron-only dark J–V curves obtained by a space charge-limited current (SCLC) method. The device architecture was FTO/c-TiO2/perovskite/PCBM/Ag. Ndefects was calculated according to the equation<sup>51</sup> : 



<!-- Start of picture text -->
Ndefects = ð2εε0VTFLÞ=ðeL 2 Þ ð4Þ<br><!-- End of picture text -->

where ε0 and ε denote the vacuum permittivity and dielectric constant of the perovskite, and e and L represent the electron charge and thickness of the perovskite film, respectively. μelectron was computed according to the Mott–Gurney law<sup>52</sup> : 



<!-- Start of picture text -->
μelectron = ð8L 3 KÞ=ð9εε0Þ ð5Þ<br><!-- End of picture text -->

where K denotes the slope of the Child regime. 

### DFT calculations 

First-principles calculations were performed in the framework of the density functional theory (DFT) using the program package CASTEP, plane-wave ultra-soft pseudopotential (PW–USPP) method, and Perdew–Burke–Ernzerhof (PBE) form of the generalized-gradient approximation (GGA) exchange–correlation energy functional. Structural optimizations of FAPbI3 and MAPbI3 were conducted using the Broyden–Fletcher–Goldfarb–Shanno (BFGS) algorithm by allowing all atomic positions to relax. To calculate the total energies of 3AMP, 3AMPY, 3AP, BA, and PEA ions, they were placed inside a 10 Å × 10 Å × 10 Å lattice while allowing their atomic positions to vary. The simulations stopped when the total energies converged to 10<sup>−5</sup> eV/ atom, forces on each unconstrained atom were smaller than 0.03 eV/Å, stresses were lower than 0.05 GPa, and displacements were <0.001 Å. The plane-wave cutoff, Ecut, was set to 340 eV. K-point meshes of 4 × 4 × 4, 3 × 3 × 2, and 1 × 1 × 1 were used for the Brillouin zone sampling of FAPbI3, MAPbI3, 3AMP, 3AMPY, 3AP, BA, and PEA ions. 

Absorption energy. To calculate the adsorption energies of 3AMP, 3AMPY, 3AP, BA, and PEA ligands on the FAI-terminated FAPbI3 (001) surface, we modeled the first five layers of this surface. To obtain the most stable structure, structural optimization was performed by fixing the bottom three layers and setting the thickness to 15 Å vacuum. Adsorption energies were calculated by the following equation: 



<!-- Start of picture text -->
ΔEad = Eadsorption system � E FAPbI3 0 01 � E t ½adsorbate� ð6Þ<br><!-- End of picture text -->

where Eadsorption_system, EFAPbI3 001<sup>, and Et[adsorbate] represent the total</sup> energies of the adsorption system, FAI-terminated FAPbI3 (001) surface, and adsorbate, respectively. 

Defect formation energy. The formation energy of I<sup>−</sup> vacancy defects in the perovskites with 3AMP, 3AMPY, 3AP, BA, and PEA ligands on the FAI-terminated FAPbI3 (001) surface was calculated by the following equation: 



<!-- Start of picture text -->
ΔEdef ect = Edef ect system + E t ½I�� E perf ect s ystem ð7Þ<br><!-- End of picture text -->

Nature Communications |  (2023) 14:839 

8 

Article 

https://doi.org/10.1038/s41467-023-36229-1 

where Edefect_system, Eperfect_system, and Et[I] represent the total energies of the defect system, the perfect system, and a single I atom, respectively. 

Transition state (TS). To determine the migration energy barriers of I<sup>−</sup> ions on the FAI-terminated FAPbI3 (001) and MAI-terminated MAPbI3 (001) surfaces, we performed TS searches using the complete linear synchronous transit/quadratic synchronous transit method. 

### Reporting summary 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

## Data availability 

The data that support the findings of this study are available in the Supplementary Information/Source Data file. Source data are provided with this paper. 

## References 

1. Bu, T. et al. Lead halide–templated crystallization of methylaminefree perovskite for efficient photovoltaic modules. Science 372, 1327–1332 (2021). 

2. Dai, Z. et al. Interfacial toughening with self-assembled monolayers enhances perovskite solar cell reliability. Science 372, 618–622 (2021). 

3. Park, N.-G., Grätzel, M., Miyasaka, T., Zhu, K. & Emery, K. Towards stable and commercially available perovskite solar cells. Nat. Energy 1, 16152 (2016). 

4. Kamat, P. V. Evolution of perovskite photovoltaics and decrease in energy payback time. J. Phys. Chem. Lett. 4, 3733–3734 (2013). 

5. Jesper Jacobsson, T. et al. Exploration of the compositional space for mixed lead halogen perovskites for high efficiency solar cells. Energy Environ. Sci. 9, 1706–1724 (2016). 

6. Xing, G. et al. Long-range balanced electronand hole-transport lengths in organic-inorganic CH3NH3PbI3. Science 342, 344–347 (2013). 

7. Huang, J., Yuan, Y., Shao, Y. & Yan, Y. Understanding the physical properties of hybrid perovskites for photovoltaic applications. Nat. Rev. Mater. 2, 17042 (2017). 

8. Yoo, J. J. et al. Efficient perovskite solar cells via improved carrier management. Nature 590, 587–593 (2021). 

9. Akihiro, K., Kenjiro, T., Yasuo, S. & Tsutomu, M. Organometal halide perovskites as visible-light sensitizers for photovoltaic cells. J. Am. Chem. Soc. 131, 6050–6051 (2009). 

10. Min, H. et al. Perovskite solar cells with atomically coherent interlayers on SnO2 electrodes. Nature 598, 444–450 (2021). 

11. National Renewable Energy Laboratory, Best Research-Cell Efficiencies Chart, https://www.nrel.gov/pv/cellefficiency.html (2022). 

12. Alanazi, A. Q. et al. Benzylammonium-mediated formamidinium lead iodide perovskite phase stabilization for photovoltaics. Adv. Funct. Mater. 31, 2101163 (2021). 

13. Xie, H. et al. Decoupling the effects of defects on efficiency and stability through phosphonates in stable halide perovskite solar cells. Joule 5, 1246–1266 (2021). 

14. Mei, A. et al. Stabilizing perovskite solar cells to IEC61215:2016 standards with over 9,000-h operational tracking. Joule 4, 2646–2660 (2020). 

15. Agiorgousis, M. L., Sun, Y. Y., Zeng, H. & Zhang, S. Strong covalency-induced recombination centers in perovskite solar cell material CH3NH3PbI3. J. Am. Chem. Soc. 136, 14570–14575 (2014). 

16. Li, W. et al. Control of charge recombination in perovskites by oxidation state of halide vacancy. J. Am. Chem. Soc. 140, 15753–15763 (2018). 

17. Meggiolaro, D. et al. Iodine chemistry determines the defect tolerance of lead-halide perovskites. Energy Environ. Sci. 11, 702–713 (2018). 

18. Wang, J., Li, W. & Yin, W. J. Passivating detrimental DX centers in CH3NH3PbI3 for reducing nonradiative recombination and elongating carrier lifetime. Adv. Mater. 32, e1906115 (2020). 

19. Wang, R. et al. Constructive molecular configurations for surfacedefect passivation of perovskite photovoltaics. Science 366, 1509–1513 (2019). 

20. Ni, Z. et al. Resolving spatial and energetic distributions of trap states in metal halide perovskite solar cells. Science 367, 1352–1358 (2020). 

21. Chen, S., Xiao, X., Gu, H. & Huang, J. Iodine reduction for reproducible and high-performance perovskite solar cells and modules. Sci. adv. 7, eabe8130 (2021). 

22. Tan, S. et al. Steric impediment of ion migration contributes to improved operational stability of perovskite solar cells. Adv. Mater. 32, 1906995 (2020). 

23. Lee, J.-W., Kim, S.-G., Yang, J.-M., Yang, Y. & Park, N.-G. Verification and mitigation of ion migration in perovskite solar cells. APL Mater. 7, 041111 (2019). 

24. Zheng, X. et al. Defect passivation in hybrid perovskite solar cells using quaternary ammonium halide anions and cations. Nat. Energy 2, 17102 (2017). 

25. Zhang, H. et al. Multimodal host-guest complexation for efficient and stable perovskite photovoltaics. Nat. Commun. 12, 3383 (2021). 

26. Zhang, Z. et al. Marked passivation effect of naphthalene-1,8dicarboximides in high-performance perovskite solar cells. Adv. Mater. 33, 2008405 (2021). 

27. Jiang, Q. et al. Surface passivation of perovskite film for efficient solar cells. Nat. Photonics 13, 460–466 (2019). 

28. Jang, Y.-W. et al. Intact 2D/3D halide junction perovskite solar cells via solid-phase in-plane growth. Nat. Energy 6, 63–71 (2021). 

29. Lin, Y. et al. Enhanced thermal stability in perovskite solar cells by assembling 2D/3D stacking structures. J. Phys. Chem. Lett. 9, 654–658 (2018). 

30. Ma, C. et al. Centimeter-sized 2D perovskitoid single crystals for efficient X-ray photoresponsivity. Chem. Mater. 34, 1699–1709 (2022). 

31. Lee, J.-W. et al. Formamidinium and cesium hybridization for photoand moisture-stable perovskite solar cell. Adv. Energy Mater. 5, 1501310 (2015). 

32. Gompel, W. T. M. V. et al. Degradation of the formamidinium cation and the quantification of the formamidinium–methylammonium ratio in lead iodide hybrid perovskites by nuclear magnetic resonance spectroscopy. J. Phys. Chem. C 122, 4117–4124 (2018). 

33. Zhu, J. et al. Formamidine disulfide oxidant as a localised electron scavenger for >20% perovskite solar cell modules. Energy Environ. Sci. 14, 4903–4914 (2021). 

34. Liu, T. et al. Spacer engineering using aromatic formamidinium in 2D/3D hybrid perovskites for highly efficient solar cells. ACS Nano 15, 7811–7820 (2021). 

35. Li, X. et al. Improved performance and stability of perovskite solar cells by crystal crosslinking with alkylphosphonic acid omegaammonium chlorides. Nat. Chem. 7, 703–711 (2015). 

36. Gallop, N. P. et al. Rotational cation dynamics in metal halide perovskites: effect on phonons and material properties. J. Phys. Chem. Lett. 9, 5987–5997 (2018). 

37. Zhu, H. et al. An effective surface modification strategy with high reproducibility for simultaneously improving efficiency and stability of inverted MA-free perovskite solar cells. J. Mater. Chem. A 7, 21476–21487 (2019). 

38. Yang, X. et al. Superior carrier lifetimes exceeding 6 micros in polycrystalline halide perovskites. Adv. Mater. 32, 2002585 (2020). 

Nature Communications |  (2023) 14:839 

9 

Article 

https://doi.org/10.1038/s41467-023-36229-1 

39. Yang, S. et al. Tailoring passivation molecular structures for extremely small open-circuit voltage loss in perovskite solar cells. J. Am. Chem. Soc. 141, 5781–5787 (2019). 

40. Wu, Z. et al. Highly efficient perovskite solar cells enabled by multiple ligand passivation. Adv. Energy Mater. 10, 1903696 (2020). 

41. Haruyama, J., Sodeyama, K., Han, L. & Tateyama, Y. First-principles study of ion diffusion in perovskite solar cell sensitizers. J. Am. Chem. Soc. 137, 10048–10051 (2015). 

42. Xiao, X. et al. Suppressed ion migration along the in-plane direction in layered perovskites. ACS Energy Lett. 3, 684–688 (2018). 

43. Xia, M. et al. Unveiling the structural descriptor of A3B2X9 perovskite derivatives toward X-ray detectors with low detection limit and high stability. Adv. Funct. Mater. 30, 1910648 (2020). 

44. Zhu, X. et al. High-efficiency perovskite solar cells with imidazolium-based ionic liquid for surface passivation and charge transport. Angew. Chem. Int. Ed. 60, 4238–4244 (2021). 

45. Yang, D. et al. Surface optimization to eliminate hysteresis for record efficiency planar perovskite solar cells. Energy Environ. Sci. 9, 3071–3078 (2016). 

46. Huang, T. et al. Performance-limiting formation dynamics in mixedhalide perovskites. Sci. Adv. 7, eabj1799 (2021). 

47. Wu, K. et al. Temperature-dependent excitonic photoluminescence of hybrid organometal halide perovskite films. Phys. Chem. Chem. Phys. 16, 22476–22481 (2014). 

48. Xing, G. et al. Low-temperature solution-processed wavelength-tunable perovskites for lasing. Nat. Mater. 13, 476–480 (2014). 

49. Zhao, X. et al. A positive correlation between local photocurrent and grain size in a perovskite solar cell. J. Energy Chem. 72, 8–13 (2022). 

50. Khenkin, M. V. et al. Consensus statement for stability assessment and reporting for perovskite photovoltaics based on ISOS procedures. Nat. Energy 5, 35–49 (2020). 

51. Bube, R. H. Trap density determination by space-charge-limited. Curr. J. Appl. Phys. 33, 1733–1737 (1962). 

52. Kiy, M. et al. Observation of the Mott–Gurney law in tris (8-hydroxyquinoline) aluminum films. Appl. Phys. Lett. 80, 1198–1200 (2002). 

## Acknowledgements 

This work was supported by National Natural Science Foundation of China (61974085, K.Z.), the 111 Project (B21005, S.L.), the National 1000 Talents Plan program (1110010341, S.L.), National University Research Fund (GK202201005, K.Z.). The authors also thank beamlines BL17B1 and BL14B1 at the SSRF for providing the beamtime and User Experiment Assist System of SSRF for their help. We also thank Prof. Jingbi You for the useful discussions related to the fabrication of perovskite films. 

## Author contributions 

T.Y. and L.G. conducted the most experimental and DFT studies. J.L. assisted with the PL mapping procedure and C–V and FTIR measurements. C.M. helped with the synthesis and characterization of 3APX (X = I, Br, Cl) single crystals. Y.D., D.L., and Y.Y. assisted with the GIWAXS acquisition. P.W. assisted with the PL and TRPL measurements. Z.D. helped fit the VOC–Sun data. J.F. and S.W. assisted with the XRD measurements. P.X. and W.T. assisted with the PL intensity and photocurrent mapping measurements. H.L. participated in the discussion of the obtained results. X.C. helped with the J–V measurements. K.Z. conceived the study. K.Z. and S.L. supervised the study. All authors discussed the results and commented on the manuscript. 

## Competing interests 

The authors declare no competing interests. 

## Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-023-36229-1. 

Correspondence and requests for materials should be addressed to Wenming Tian, Shengzhong (Frank) Liu or Kui Zhao. 

Peer review information Nature Communications thanks the anonymous reviewer(s) for their contribution to the peer review of this work. Peer reviewer reports are available. 

Reprints and permissions information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2023 

Nature Communications |  (2023) 14:839 

10 

