# Deterministic fabrication of 3D/2D perovskite bilayer stacks for durable and efficient solar cells

| 字段 | 内容 |
|---|---|
| 期刊 | Science |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 478 |
| 作者 | S. Sidhik, Yafei Wang, M. D. De Siena, R. Asadpour, Andrew J Torma, Tanguy Terlier, Kevin Ho, Wen-Bin Li et al. |
| DOI | 10.1126/science.abq7652 |
| 源文件 | 017_Sidhik_2022_Deterministic-fabrication-of-3D2D-perovskite-bil.pdf |

---
# 1 **<mark>Deterministic fabrication of 3D|2D perovskite bilayer</mark>** 2 **<mark>stacks for durable and efficient solar cells</mark>** 

- 3 <mark>Siraj Sidhik</mark><sup>1,2</sup> <mark>, Yafei Wang</mark><sup>2,3</sup> <mark>, Michael De Sienna</mark><sup>4</sup> <mark>, Reza Asadpour</mark><sup>5</sup> <mark>, Andrew Torma</mark><sup>6</sup> <mark>, Tanguy</mark> 4 <mark>Terlier</mark><sup>7</sup> <mark>, Kevin Ho</mark><sup>8</sup> <mark>, Wenbin Li</mark><sup>2,6</sup> <mark>, Anand B. Puthirath</mark><sup>1</sup> <mark>, Xinting Shuai</mark><sup>1</sup> <mark>, Ayush Agarwal</mark><sup>2</sup> <mark>, Boubacar</mark> 5 <mark>Traore</mark><sup>9</sup> <mark>, Matthew Jones</mark><sup>1,10</sup> <mark>,</mark> Rajiv Giridharagopal<sup>8</sup> <mark>, Pulickel M. Ajayan</mark><sup>1</sup> <mark>, Joseph Strzalka</mark><sup>11</sup> <mark>, David</mark> 6 <mark>Ginger</mark><sup>8</sup> <mark>, Claudine Katan</mark><sup>9</sup> <mark>, Muhammad Ashraful Alam</mark><sup>5</sup> <mark>, Jacky Even</mark><sup>12</sup> <mark>*, Mercouri G. Kanatzidis</mark><sup>4,</sup> <mark>and</mark> 7 <mark>Aditya D. Mohite</mark><sup>1,2</sup> <mark>*</mark> 

- 8 **1** **<mark>Material Science and Nanoengineering, Rice University, Houston, Texas 77005, USA.</mark>** 

- 9 **2** **<mark>Department of Chemical and Biomolecular Engineering, Rice University, Houston, Texas</mark>** 

- 10 **<mark>77005, USA.</mark>** 

- 11 **3** **<mark>School of Mechanical and Electric Engineering, Guangzhou University, Guangzhou,</mark>** 12 **<mark>Guangdong, 510006, China.</mark>** 

- 13 **4Department of Chemistry and Department of Materials Science and Engineering,** 14 **Northwestern University, Evanston, Illinois 60208, USA.** 

- 15 **5School of Electrical and Computer Engineering, Purdue University, West** 

- 16 **Lafayette, IN, USA.** 

- 17 **6Applied Physics Graduate Program, Smalley‐Curl Institute, Rice University, Houston,** 18 **Texas, 77005, USA.** 

- 19 **7Shared Equipment Authority, SIMS Laboratory, Rice University, Houston, TX 77005, US** 

- 20 **8Department of Chemistry, University of Washington, Seattle 98195.** 

- 21 **9** **<mark>Univ Rennes, ENSCR, CNRS, ISCR‐UMR 6226, Rennes F‐35000, France.</mark>** 

- 22 **10** **<mark>Department of Chemistry, Rice University, Houston, Texas 77005, USA.</mark>** 

- 23 **11X‐Ray Science Division, Argonne National Laboratory, Argonne, IL, USA** 

- 24 **12** **<mark>Univ Rennes, INSA Rennes, CNRS, Institut FOTON ‐ UMR 6082, Rennes F‐35000, France.</mark>** 

- 25 **<mark>*Correspondence to: adm4@rice.edu, jacky.even@insa‐rennes.fr</mark>** 

- 26 Realizing solution‐processed heterostructures is a long‐enduring challenge in halide perovskites 27 because of solvent incompatibilities that disrupt the underlying layer. By leveraging the solvent 28 dielectric constant and Gutmann donor number, we could grow phase‐pure two‐dimensional (2D) 29 halide perovskite bilayer stacks of the desired composition, thickness, and bandgap onto 3D 

- 30 perovskites without dissolving the underlying substrate. Characterization reveals a 3D‐2D transition 31 region of 20 nm, mainly determined by the roughness of the bottom 3D layer. Thickness dependence 32 of the 2D perovskite layer reveals the anticipated trends for n‐i‐p and p‐i‐n architectures, consistent 

- 33 with band alignment and carrier transport limits for 2D perovskites. We measure a photovoltaic 

- 34 efficiency of 24.5%, with exceptional stability of T99>2000 hours, implying that the 3D/2D bilayer 35 inherits the intrinsic durability of 2D perovskite without compromising efficiency. 

1 

- 1 **One sentence summary:** Design and fabrication of solution-processed scalable 3D|2D 2 heterostructures for highly efficient and durable conversion of light to electrical energy. 

- 3 

## **Main** 

- 4 The progressive increase in the power conversion efficiency (PCE) of solution-processed 

- 5 perovskite solar cells (PSCs) ( _1_ , _2_ ) has been enabled in part  by strategies to passivate the 

- 6 grain boundaries and interfaces between the perovskite absorber and the charge 

- 7 transport layers ( _3_ – _9_ ). Two-dimensional (2D) halide perovskites (HaP) passivation 

- 8 layers, which have been the most effective in improving the open-circuit voltage (VOC) 

- 9 and fill factor (FF) ( _10_ – _13_ ), are commonly grown by spin-coating an organic cation 

- 10 dispersed in isopropyl alcohol or chloroform on top of 3D HaPs( _14_ , _15_ ). This coating 

- 11 removes some excess lead iodide (PbI2) from the 3D perovskite layer to then form 

- 12 heterogeneous 2D phases or ultrathin layers of wide bandgap 2D HaP ( _16_ – _18_ ). 

- 13 These advances have enhanced durability, as demonstrated recently using damp- 

- 14 heat tests by Wolf _et al_ ., the lack of control over the phase purity, film thickness, 

- 15 orientation, and structural phase of the 2D HaP has limited their use as an interfacial 

- 16 passivation layer( _19_ , _20_ ). A solvent-free growth of the 2D BA2PbI4 perovskite on the 3D 

- 17 film by controlling the pressure, temperature, and time was demonstrated by Noh _et al_ ., 

- 18 indicating the importance of a high-quality 3D/2D interface ( _21_ ). However, such solid- 

- 19 state in-plane growth is difficult to scale to large areas. Thus, the fabrication of solution- 

- 20 processed heterostructures of 3D|2D HaP with the desired energy levels, thickness, and 21 orientation has been lacking. 

- 22 We now report a solvent design principle for fabricating solution-processed 

- 23 3D/2D HaP bilayer structures with desired film thickness and phase purity of any 2D HaP, 

- 24 including Ruddlesden-Popper (RP), Dion-Jacobson (DJ), or alternating cation interlayer 

- 25 (ACI), described by the general formula of L’An-1BnX3n+1 where L’: long-chain organic 

2 

- 1 cation, A: small monovalent cation B: divalent metal, and X: monovalent anion, and n: 

- 2 number of PbI6 bonded octahedra along the stacking axis. Our approach leverages two 

- 3 essential properties of the processing solvents, the dielectric constant (εr) and the 

- 4 Gutmann donor number (DN), which controls the coordination between the precursor 

- 5 ions and the solvent ( _22_ ). Processing solvents with dielectric constant εr>30 and 

- 6 Gutmann number, 5<DN<18 could effectively dissolve the 2D HaP powders without 

- 7 dissolving or degrading the underlying 3D perovskite film during processing using spin 8 coating, doctor blading, or slot die coating. 

- 9 Control over the different n-value and film thicknesses allowed us to progressively 

- 10 tune the heterostructure from a type I to a type II with the 2D perovskites acting as a 

- 11 transport layer. We achieved a PCE of 24.5% with a high open-circuit voltage (VOC) of 1.2 12 V in a regular n-i-p device using a RP 2D BA2MA2Pb3I10 perovskite with a thickness of 50 

- 13 nm.  Importantly, a comparison of the International Summit on Organic Photostability 

- 14 ISOS-L-1 protocol [Maximum Power Point tracking under ambient conditions] stability 

- 15 of 3D/phase-pure (PP) 2D HaP bilayer PSC with the 2D passivated 3D, control-3D, and 

- 16 control-2D PSCs showed that the 3D/PP-2D HaP bilayer device exhibited <mark>exceptional</mark> 

- 17 <mark>stability with T</mark> 99 <mark>>2000 hours. Thus,  these structures had the durability of the 2D</mark> 18 <mark>perovskite films without compromising PCE (</mark> _23_ ). 

- 19 The comprehensive selection criteria for solvents that could selectively dissolve 

- 20 either the 2D (or 3D) HaP without disrupting the underlying 3D (or 2D) layer was based 

- 21 on the dielectric constant and the Gutmann donor number (Fig. 1A).  These two distinct 

- 22 attributes are correlated. The dielectric constant determines the power of a solvent to 

- 23 dissolve any ionic compound by screening the Coulomb attraction between the ions, 

- 24 whereas the Gutmann donor number describes the Lewis basicity of the solvent and 

- 25 measures the extent to which coordination compounds may form between solvent and 

3 

1 





**Figure 1. Design principle for fabricating a solution‐processed 3D/phase‐pure 2D HaP bilayer stack. (A)** Plot showing different solvents based on the dielectric constant (εr), and the Gutmann number (DN) to identify the differences in solubility of the 3D and 2D perovskite powders for making a 3D|2D bilayer stack. (B) Optical images of 2D (RP BA2MAPb2I7)  and 3D perovskite powders in different solvents. **C.** Solubility of RP BA2MAn-1PbnI3n+1 (n=1-4), DJ, (4AMP)MAPb2I7 , and AC (GA)MA2Pb2I7-based 2D perovskites (where BA is butylamine, MA is methylammoniume, AMP is aminomethyl piperidine and GA is guanidinium)  in the solvents MeCN, TMS, and PC as shown. ( **D)** Fabrication steps of a 3D/2D HaP bilayer stack. 

4 

- 1 cations (high donor number) or between the precursors themselves (low donor number) 

- 2 in the absence of competitive binding of the solvent ( _24_ , _25_ ). For example, in the 

- 3 precursor solution comprised of methylammonium iodide (MAI), formamidinium iodide 

- 4 (FAI), and PbI2, a solvent with a high Gutmann number would strongly coordinate with 

- 5 divalent metal centers (Pb<sup>2+</sup> ) and suppress the formation of molecular iodoplumbates 

- 6 complexes for example, [PbI6-x(solvent)x]<sup>-(4-x)</sup> , where x≤6 or molecular clusters that 

- 7 would otherwise form in a solvent with low Gutmann number. The strength of these 

- 8 interactions determined the differences in the solubility of the 3D and 2D HaP powders 9 in various solvents (Fig. 1A). 

- 10 Typical vials of RP 2D (BA2MAPb2I7) and the 3D HaP powders (Fig.  1B) illustrate 

- 11 their solubility in different solvents. Polar aprotic solvents (green dots) with a dielectric 

- 12 constant > 30, such as _N_ , _N_ -dimethylformamide (DMF), and dimethyl sulfoxide (DMSO), 

- 13 fully dissolved both 3D and 2D HaP. Solvents such as acetonitrile (MeCN), tetramethyl 

- 14 sulfone (TMS), propylene carbonate (PC), and ethylene carbonate (EC) also have a 

- 15 dielectric constant > 30 but did not dissolve the 3D HaP powders because their weak 

- 16 Lewis basicity (DN value less than 18 kcal/mol) made the formation of Pb<sup>2+</sup> solvent 

- 17 coordination complexes unlikely. However, these solvents completely dissolved the 2D 

- 18 perovskite powders. This difference is consistent with 3D perovskite lattices being more 

- 19 stable and difficult to disrupt with solvents of intermediate DN than the 2D perovskites 

- 20 and implied the presence of additional favorable interactions of these solvents with the 

- 21 organic spacer cations (readily accessible from the edges of the slabs) that were absent 

- 22 in the 3D perovskites. 

- 23 We observed that both nonpolar (blue dots) and polar protic solvents (red dots) 

- 24 did not completely dissolve the 2D HaP powders (Fig. 1B). As controls, we also tested 

5 

- 1 solvents with a high Gutmann number and low dielectric constant, such as 

- 2 tetrahydrofuran (DN=20 kcal/mol, εr=7.6), and vice versa, such as nitromethane (NME) 

- 3 (DN=2.7 kcal/mol, εr=35.9), both of which did not dissolve the 2D perovskite powders 

- 4 (see Fig. S1 and S2). Taken together, these results implied that solvents with a dielectric 

- 5 constant > 30 and the Gutmann number 5<DN<18 kcal/mol should enable the fabrication 

- 6 of 3D|2D HaP bilayers without disrupting or degrading the underlying 3D HaP film. 

- 7 To fabricate 3D|2D HaP bilayers with different phases of 2D perovskite and having 

- 8 desired n-values, and thicknesses, we tested the solubility of the archetypical RP 2D 

- 9 perovskites (BA2MAn-1PbnI3n+1 with n=1-4) and other crystal phases such as DJ 

- 10 ((4AMP)MAPb2I7), and ACI (GA)MA2Pb2I7) in the identified 2D perovskite-selective solvents 

- 11 (Fig. 1C). Because of its high polarity, propylene carbonate dissolved the 2D RP phases 

- 12 better than tetramethyl sulfone or acetonitrile.  In general, we observed an overall 

- 13 decrease in the solubility of RP 2D HaPs with increasing _n_ value, from greater than 100 

- 14 mg/ml for _n_ =1 to 30 to 40 mg/ml for _n_ =4. The decrease in the solubility as a function of 

- 15 increasing n-value was consistent with the increase in inorganic lattice fraction of the 2D 16 HaP as the n-value approached 3D composition. 

- 17 In addition, the _n_ =2 ACI, and DJ perovskites exhibited low solubilities of 20 to 40 

- 18 mg/ml and 10 to 25 mg/ml, respectively, which was consistent with the structure of ACI 

- 19 and DJ 2D perovskites, which was near that of 3D with short interlayer cations that 

- 20 reflected the role of organic spacer cations in the dissolution process. Of all the target 

- 21 solvents, the high volatility of MeCN [boiling point (b.p.) ≈ 82 ̊C] compared to the others, 

- 22 such as TMS (b. p.≈ 285 ̊C), PC (b. p.≈ 242 ̊C), and EC (b. p.≈ 248 ̊C), made it attractive for 

- 23 low-temperature processing without affecting the stability of the entire stack (see Fig. S3, 

- 24 S4, and Movie S1, S2). We focused on the solvent MeCN for fabricating the targeted 3D|2D 

- 25 HaP bilayer. 

6 



**Figure 2. Structural & optical spectroscopic characterization of 3D and 3D/PP‐2D HaP bilayers with n=1‐4. (A)** X-ray diffraction pattern from control 3D Cs _5_ (MA0.10FA0.90)95Pb(I0.90Br0.10)3, and 3D|PP-2D (BA2MAn-1PbnI3n+1, n=1-4, 100 nm) stack stack. ( **B)** Optical absorbance spectra of 3D HaP film and 3D/PP-2D HaP bilayers for RP BA2MAn-1PbnI3n+1 (n=1-4) identified through the excitonic peak. ( **C)** PL spectra of 3D and 3D/PP-2D (BA2MAn-1PbnI3n+1, n=1-4, 100 nm) HaP bilayer measured with excitation at 480 nm and 360 Watts/cm<sup>2</sup> with emission from 3D band edge and 2D HaP from n=1-4. ( **D_** Schematic diagram depicting the 3D/2D (BA2MAPb2I7) bilayer stack with the measured confocal PL map centred at the 3D emission peak (1.6 eV), and at 2D emission peak (2.15 eV) showing uniform coverage of the 2D, and the underlying 3D. 

- 1 The protocols for fabricating the 3D|2D HaP bilayer using spin coating, drop- 

- 2 casting, blade coating, or slot-die coating (Fig. 1D) followed our recent work on obtaining 

- 3 phase-pure 2D HaP films. We created a stable dispersion of 2D perovskite seed solution 

- 4 by dissolving the parent crystal powders in MeCN (see Fig. S5 and detailed discussion in 

7 

- 1 the SI)( _26_ , _27_ ). In general, other than the solvents with Gutmann number 5<DN<18 

- 2 kcal/mol, any Pb<sup>2+</sup> -weakly coordinating solvents like DMF, GBL, and DMAc, compared to 

- 3 DMSO can produce a dispersion of 2D perovskite seed solution.  The precursor solution 

- 4 with 2D perovskite seeds was coated on top of a 3D HaP layer 

- 5 (Cs _5_ (MA0.10FA0.90)95Pb(I0.90Br0.10)3), and then annealed at 80<sup>o</sup> C for 5 min. We also used 

- 6 other scalable techniques, such as doctor blading, drop-casting, and blade-coating coating 

- 7 (see Fig. S6) to demonstrate the industrial viability of the process.  By controlling the 

- 8 concentration and deposition technique, we tuned the thickness of the 2D perovskite 

- 9 layer on top of the 3D film ranging from sub-10 nm to sub-micrometer scales (see Fig. 

- 10 S7). 

- 11 Using the design approach described in Fig. 1, we fabricated a 3D|2D HaP (RP 

- 12 BA2MAn-1PbnI3n+1, (n=1-4)) bilayer stack and characterized its phase purity using x-ray 

- 13 diffraction (XRD), optical absorbance, and photoluminescence (PL) techniques. For the 

- 14 XRD pattern for the control-3D and 3D|2D HaP bilayers with different 2D RP BA2MAn- 

- 15 1PbnI3n+1 perovskite (n=1-4 Fig. 2A), matching the low angle Bragg peaks with the 

- 16 corresponding simulated patterns suggested that the overlying 2D HaP layer had high 

- 17 phase purity (see Fig. S8). The phase purity was further confirmed with absorbance (Fig. 

- 18 2B) and PL (Fig. 2C) measurements. The optical absorbance revealed the presence of a 

- 19 3D HaP band-edge at 1.6 eV for the control film which was accompanied by a sharp 

- 20 excitonic peak varying from 2.4 eV (n=1) to 1.9 eV (n=4) corresponding to the different 

- 21 n-values in the 3D/2D bilayer. The steady-state PL measurements further confirmed the 

- 22 phase purity of the 3D/2D HaP bilayers.  We did not observe any change in the bandgap 

- 23 of the underlying 3D HaP, indicating that the presence of the 2D HaP layer did not disrupt 

- 24 the 3D perovskite. 

8 

- 1 To further assess the spatial homogeneity of the 3D/2D HaP bilayer, we monitored 

- 2 the PL emission centered at the 3D peak (1.6 eV) and the 2D (n=2, 2.15 eV) peak using 

- 3 confocal microscopy (see Fig. 2D). We observed a uniform emission over a large area of 

- 4 20 μm by 20 μm from the 2D, as well as the underlying 3D HaP layer, confirming the 

- 5 homogeneity of the 3D/2D HaP bilayer stack. These measurements indicated we had 

- 6 grown highly crystalline phase pure-2D (PP-2D) HaP of varying _n_ -values on the 3D 

- 7 surface. This fabrication process also worked well with the pure FAPbI3 and MAPbI3 3D 

- 8 HaP, demonstrating its broad applicability (see Fig. S9). 

- 9 

9 





**Figure 3. 3D/PP‐2D HaP interface characterization. (A)** ToF-SIMS depth profile of the control Cs _5_ (MA0.10FA0.90)95Pb(I0.90Br0.10)3 3D perovskite film and ( **B)** 3D|PP-2D (BA2MAPb2I7) HaP stack deposited on top of indium tin oxide shows the distribution of different ions across the thickness and the sharpness of the heterointerface. ( **C** and **D)** Angle-dependent GIWAXS pattern of the 3D|PP-2D (RP BA2MAPb2I7) HaP stack show evolution of 2D and 3D perovskites for increasing incident angle. The most efficient 3D/PP-2D HaP solar cell was obtained for BA2MA2Pb3I10 RP perovskite, which exhibited mixed vertical orientation shown in Fig. 4. **(E)** Simulated x-ray penetration depth curve for the RP-2D HaP at various incident angles showing the critical angle and the thickness of the probed film. ( **F)** Amount of 2D and 3D HaP materials extracted from the angular integrated diffraction peaks. ( **G)** Cross-sectional darkfield HR-TEM image of the 3D/PP-2D (BA2MAPb2I7) HaP stack with the overlaying intensity profile (in red color) shows transition width from 3D to 2D of 20 nm. The scale bar is 100 nm. 

1 

10 

- 1 We used several techniques to characterize the interface between the 3D and PP-2D 

- 2 layers. The time-of-flight secondary ion mass spectroscopy (ToF-SIMS) depth profile of 

- 3 the control 3D (Fig. 3A) and 3D/PP-2D HaP bilayer (Fig. 3B) revealed the distribution of 

- 4 ions as a function of film thickness. Upon introduction of BA2MAPb2I7 2D perovskite layer 

- 5 on top of the 3D film, in addition to the Cs2I<sup>+</sup> , Cs2Br<sup>+</sup> halide ions, and CH5N2<sup>+</sup> (FA<sup>+</sup> ) organic 

- 6 cations, we observed higher intensity of the C4H12N<sup>+</sup> (BA<sup>+</sup> ) compared to the background 

- 7 BA<sup>+</sup> intensity (see detailed discussion in SI) and CH6N<sup>+</sup> (MA<sup>+</sup> ) ions. These ions were 

- 8 uniformly distributed for a thickness of 50 nm, after which there was a sharp decrease in 

- 9 the concentration. Fitting the change in intensity of the BA<sup>+</sup> to the background 

- 10 (representing no BA) yielded an interface transition of 20 nm from the top 2D layer to the 11 underlying 3D HaP. The TOF-SIMS measurements of the 3D|PP-2D (RP BA2MA2Pb3I10) 12 bilayer stack show similar results (see Fig. S10). 

- 13 The grazing incidence wide-angle scattering (GIWAXS) spectra of the 3D|PP-2D 

- 14 HaP bilayer for different incident angles (or depth) (Fig. 3C, and 3D) shows the presence 

- 15 of horizontal oriented BA2MAPb2I7 2D HaP on the surface (𝛼�0.08°�, and the 3D HaP 

- 16 (Cs _5_ (MA0.10FA0.90)95Pb(I0.90Br0.10)3) in the form of rings at the bottom (𝛼�0.5°� (also see 

- 17 Fig. S11, detailed discussion in SI). This result is well correlated with the calculated x-ray 

- 18 penetration depth curve for the RP-2D HaP, showing a critical angle (αc) of 0.181˚ (Fig. 

- 19 3E)( _28_ , _29_ ). The integrated area under the (020) peak (2D signature feature) and the 

- 20 (111)/(001) peak (3D signature feature) from the GIWAXS spectra for various incident 

- 21 angles (0 to 0.5<sup>º</sup> ) (Fig. 3F) revealed the 3D|PP-2D interface at an incident angle of 0.2<sup>º</sup> . 

- 22 The integrated area under the (020) peak became invariant, whereas the (111)/ (001) 

- 23 increased, which confirmed the presence of a 2D HaP layer with a thickness of 50 to 60 

- 24 nm stacked on top of the 3D HaP film as estimated from the penetration depth curve. On 

- 25 the other hand, the BA2MA2Pb3I10 2D HaP shows a mixed orientation in the 3D|PP-2D 

11 

- 1 (n=3, RP) HaP bilayer stack with similar interfacial characteristics (see detailed GIWAXS 

- 2 analysis in Fig. S12). The presence of some texture in the orientation as in the n=3, RP 

- 3 perovskite is required for efficient charge transfer through the 2D perovskite resulting in 

- 4 the efficient 3D|PP-2D bilayer HaP solar cells as will be shown in Fig. 4 ( _26_ , _27_ ). The dark- 

- 5 field cross-sectional high-resolution transmission electron microscopy (HRTEM) image 

- 6 of the 3D|PP-2D (RP BA2MAPb2I7) HaP bilayer grown on the silicon substrate (with gold 

- 7 and carbon as the top protective layer, Fig. 3G) verified the homogeneity of the 2D HaP 

- 8 layer on top of the 3D HaP thin film. The average intensity profile (indicated in red) 

- 9 showed an interfacial 3D|PP-2D sharpness of 20 nm, which was consistent with the TOF- 

- 10 SIMS measurements and matched the roughness of the control-3D film (see Fig. S13). The 

- 11 HRTEM image of the 3D|PP-2D (RP BA2MA2Pb3I10) HaP bilayer stack also showed similar 

- 12 interfacial characteristics (see Fig. S14).  All of these results demonstrated that our 

- 13 solvent design strategy allowed for the fabrication of 3D/PP- 2D bilayers with a high- 

- 14 quality interface without destroying or altering the crystallinity of the underlying 3D 15 perovskite. 

- 16 We fabricated solar cells with the 3D|PP-2D HaP bilayer perovskites and 

- 17 measured their performance and durability. We first created an energy level diagram for 18 the 2D HaP, RP BA2MAn-1PbnI3n+1 (n=1-4), with the 3D perovskite 

- 19 Cs _5_ (MA0.10FA0.90)95Pb(I0.90Br0.10)3 (Fig. 4A) based on values predicted from first- 

- 20 principles calculations (see Fig. S15) and corroborated with photoemission yield 

- 21 spectroscopy (PES) and absorption measurements( _30_ ) (see Fig. S16 to S18). We 

- 22 observed a type II band alignment between the 3D and the _n_ =3 2D HaP with a near- 

- 23 perfect alignment of valence band edges for 3D and 2D HaP, which is ideal for extracting 

- 24 holes but presents a large energy barrier for electrons (Fig. S19). The 3D|PP-2D (n=1, 

12 

- 1 n=2) HaP bilayer stack shows a Type I alignment, further confirmed by fabricating solar 

- 2 cells showing a barrier for charge extraction using higher thicknesses of the 

- 3 corresponding 2D layers (see detailed discussion in the SI, and Fig. S20).  As a result, we 

- 4 fabricated n-i-p PSCs with the architecture FTO|SnO2|3D|PP-2D(n=3)/spiro- 

- 5 OMeTAD|Au, controlling the PP-2D (n=3) HaP thickness by spin coating different 

- 6 concentration of 2D perovskite solution in MeCN (see Fig. S21). 

13 





**Figure 4. Photovoltaic performance and long‐term stability of the 3D|PP‐2D (BA2MA2Pb3I10) HaP bilayer solar cells. (A)** Energy-level alignment for different n-values (n≤4) of 2D perovskite with the 3D perovskite layer with an error of ±0.05eV. ( **B)** Currentvoltage curves of the champion 3D/PP-2D n-i-p PSCs as a function of the 2D layer thickness obtained by spin coating different concentration of the 2D perovskite solution in MeCN. ( **C)** Variation in PCE of the n-i-p and p-i-n planar 3D|PP-2D PSCs as a function of 2D perovskite layer thickness. ( **D)** External quantum efficiency of the device with and without the 2D layer, showing the absorption and current generation ability of the stack. ( **E)** ISOS-L-1 stability measured at maximum power point tracking in ambient condition under continuous 1-sun illumination (55 ̊C) for an epoxy encapsulated PSC. The initial PCE of the control device is 21%, the 3D|2D passivated device, 22.93%, the 3D|PP-2D bilayer PSC, 23.75% and the PP2D perovskite device is 16.3%. 

1 

14 

- 1 Figure 4B shows the current-voltage (J-V) characteristics for three selected thicknesses 

- 2 of 2D HaP layers with 3D HaP as the control. For n-i-p cells, increased 2D HaP thickness 

- 3 from 0 to 50 nm increased VOC from 1.09 V to 1.2 V. This increase in the VOC was 

- 4 accompanied by a slight increase in the FF from 0.80 to 0.84, and even a small increase in 

- 5 JSC from 23.54 to 24.34 mA.cm<sup>-2</sup> resulting in a peak PCE of 24.5% for a 2D HaP thickness 

- 6 of 50 nm with no hysteresis (Fig. S22 and S23). The PCE as a function of 2D HaP thickness 

- 7 shows that increasing the 2D HaP thickness beyond 50 nm decreased the overall PCE (Fig. 

- 8 4C). We attributed this decrease in PCE to the reduced transport of the free charge 

- 9 carriers from 3D to the 2D HaP limited by the <100 nm diffusion length for a 

- 10 polycrystalline 2D n=3, RP HaP film with mixed oriented ( _31_ , _32_ ) (see PV statistics in Fig. 

- 11 S23).However, the p-i-n devices with ITO|PTAA|3D|PP-2D( _n_ =3)|C60|BCP|Cu exhibited 

- 12 an increase in PCE for a 2D HaP thickness of 5 nm, consistent with recent studies of 2D|3D 

- 13 interfaces with an ultrathin 2D layer passivation followed by a drastic decrease for higher 

- 14 thicknesses of 2D HaP (Fig. 4C, black curve, and Fig. S24, S25)( _33_ , _34_ ). The reduction in 

- 15 PCE was consistent with the energy band diagram (Fig. 4A and Fig. S19B), which showed 16 a large barrier to electron collection in the p-i-n geometry. 

- 17 To understand the increase in PV parameters (JSC, VOC, and FF) of the 3D|PP-2D 

- 18 HaP bilayer solar cells, we performed optical and self-consistent transport modelling to 

- 19 simulate the PV characteristics which are supported by the surface photovoltage (SPV), 

- 20 steady-state photoluminescence (PL), and time-resolved PL measurements. The optical 

- 21 modelling revealed that the 2D HaP layer increased the photogeneration of the bilayer 

- 22 stack and improved JSC (see Fig. S26). This result was consistent with the observed increase 

- 23 in the JSC by 1.5 mA/cm<sup>2</sup> as we went from the 3D control to the champion 3D|PP-2D HaP 

- 24 bilayer device validated by external quantum efficiency (EQE) measurements shown in 

15 

- 1 Fig. 4D and the change in EQE (ΔEQE) between them (see Fig. S27, S28 and detailed 2 discussion in SI). 

- 3 The self-consistent transport simulation predicted reduced recombination at the 

- 4 3D/HTL interface after the introduction of a 2D HaP layer, thereby improving the VOC and 

- 5 FF (see Fig. S29). To corroborate these results, we measured the surface photovoltage 

- 6 (SPV) using scanning Kelvin probe microscopy (SKPM) on the ITO|SnO2|3D|PP-2D (RP 

- 7 BA2MA2Pb3I10) stack, which showed an increase in the SPV as a function of the 2D layer 

- 8 thickness (see Figure S30, S31). This result suggested an increase in the quasi-Fermi level 

- 9 separation related to the VOC of the device( _35_ – _38_ ). The dark I-V curve traces of the solar 

- 10 cells further confirm the increase in VOC (see detailed discussion in SI, and Fig. S32). 

- 11 Additionally, the steady-state PL and time-resolved photoluminescence (TRPL) 

- 12 measurements on the ITO|SnO2|3D|PP-2D (RP BA2MA2Pb3I10) stack showed enhanced PL 13 emission and increased charge carrier lifetime up to a 2D HaP thickness of 50 (see Figure 

- 14 S33) but decreases for the higher thickness of 2D HaPs.  The overlaying 2D HaP 15 minimized the nonradiative recombination pathways between the 3D 

- 16 perovskite/electrode (HTL) interface as confirmed by the transport modeling 

- 17 measurements, improving both the FF and the VOC of the 3D/PP-2D devices( _15_ , _39_ ). 

- 18 We tested the long-term operational stability of our 3D|PP-2D bilayer 

- 19 encapsulated device following the ISOS-L-1 protocol ( _23_ ) (see Fig. 4G). After 2000 hours 

- 20 of continuous illumination, the 3D|PP-2D HaP bilayer device showed negligible 

- 21 degradation with T99>2000 hours, whereas the control 3D device lost 25% of its initial 

- 22 PCE. As controls, we also measured the stability of the 3D PSC passivated with a spin- 

- 23 coated organic cation, butylammonium iodide, and compared it with our 3D|PP-2D PSCs 

- 24 using the same conditions. The  2D HaP passivated 3D PSCs show a 10% loss of efficiency 

16 

- 1 after 1000 hours of continuous operation, consistent with other recent reports( _4_ , _19_ ). We 

- 2 also measured a pure 2D HaP control device, which showed a T97> 1500 hours, implying 

- 3 that the 3D/PP-2D bilayer perovskite has acquired the inherent stability of the 2D 4 perovskite material. 

- 5 **REFERENCES** 

- 6 1. J. Jeong, M. Kim, J. Seo, H. Lu, P. Ahlawat, A. Mishra, Y. Yang, M. A. Hope, F. T. Eickemeyer, 7 M. Kim, Pseudo-halide anion engineering for α-FAPbI3 perovskite solar cells. _Nature_ . **592** , 381– 8 385 (2021). 

- 9 2. H. Min, D. Y. Lee, J. Kim, G. Kim, K. S. Lee, J. Kim, M. J. Paik, Y. K. Kim, K. S. Kim, M. G. Kim, 

- 10 Perovskite solar cells with atomically coherent interlayers on SnO2 electrodes. _Nature_ . **598** , 444– 11 450 (2021). 

- 12 3. Q. Jiang, Y. Zhao, X. Zhang, X. Yang, Y. Chen, Z. Chu, Q. Ye, X. Li, Z. Yin, J. You, Surface 13 passivation of perovskite film for efficient solar cells. _Nature Photonics_ . **13** , 460–466 (2019). 

- 14 4. F. Zhang, S. Y. Park, C. Yao, H. Lu, S. P. Dunfield, C. Xiao, S. Uličná, X. Zhao, L. Du Hill, X. Chen, 15 Metastable Dion-Jacobson 2D structure enables efficient and stable perovskite solar cells. _Science_ . 16 **375** , 71–76 (2022). 

- 17 5. X. Zheng, Y. Hou, C. Bao, J. Yin, F. Yuan, Z. Huang, K. Song, J. Liu, J. Troughton, N. Gasparini, 18 Managing grains and interfaces via ligand anchoring enables 22.3%-efficiency inverted 19 perovskite solar cells. _Nature Energy_ . **5** , 131–140 (2020). 

- 20 6. Y. Liu, S. Akin, L. Pan, R. Uchida, N. Arora, J. V. Milić, A. Hinderhofer, F. Schreiber, A. R. Uhl, 21 S. M. Zakeeruddin, Ultrahydrophobic 3D/2D fluoroarene bilayer-based water-resistant 22 perovskite solar cells with efficiencies exceeding 22%. _Science advances_ . **5** , eaaw2543 (2019). 

- 23 7. N. K. Noel, A. Abate, S. D. Stranks, E. S. Parrott, V. M. Burlakov, A. Goriely, H. J. Snaith, 24 Enhanced photoluminescence and solar cell performance via Lewis base passivation of organic– 25 inorganic lead halide perovskites. _ACS nano_ . **8** , 9815–9821 (2014). 

- 26 8. D. W. DeQuilettes, S. Koch, S. Burke, R. K. Paranji, A. J. Shropshire, M. E. Ziffer, D. S. Ginger, 27 Photoluminescence lifetimes exceeding 8 μs and quantum yields exceeding 30% in hybrid 28 perovskite thin films by ligand passivation. _ACS Energy Letters_ . **1** , 438–444 (2016). 

- 29 9. I. L. Braly, D. W. DeQuilettes, L. M. Pazos-Outón, S. Burke, M. E. Ziffer, D. S. Ginger, H. W. 30 Hillhouse, Hybrid perovskite films approaching the radiative limit with over 90% 31 photoluminescence quantum efficiency. _Nature Photonics_ . **12** , 355–361 (2018). 

- 32 10. A. A. Sutanto, P. Caprioglio, N. Drigo, Y. J. Hofstetter, I. Garcia-Benito, V. I. Queloz, D. Neher, 33 M. K. Nazeeruddin, M. Stolterfoht, Y. Vaynzof, 2D/3D perovskite engineering eliminates interfacial 34 recombination losses in hybrid perovskite solar cells. _Chem_ . **7** , 1903–1916 (2021). 

- 35 11. G. Wu, R. Liang, M. Ge, G. Sun, Y. Zhang, G. Xing, Surface Passivation Using 2D Perovskites 36 toward Efficient and Stable Perovskite Solar Cells. _Advanced Materials_ . **34** , 2105635 (2022). 

17 

- 1 12. G. Li, J. Song, J. Wu, Z. Song, X. Wang, W. Sun, L. Fan, J. Lin, M. Huang, Z. Lan, Efficient and 2 Stable 2D@ 3D/2D Perovskite Solar Cells Based on Dual Optimization of Grain Boundary and 3 Interface. _ACS Energy Letters_ . **6** , 3614–3623 (2021). 

- 4 13. M. A. Mahmud, T. Duong, J. Peng, Y. Wu, H. Shen, D. Walter, H. T. Nguyen, N. Mozaffari, G. 5 D. Tabi, K. R. Catchpole, Origin of efficiency and stability enhancement in high-performing mixed 6 dimensional 2D-3D perovskite solar cells: a review. _Advanced Functional Materials_ . **32** , 2009164 7 (2022). 

- 8 14. E. Jokar, P.-Y. Cheng, C.-Y. Lin, S. Narra, S. Shahbazi, E. Wei-Guang Diau, Enhanced 9 performance and stability of 3D/2D tin perovskite solar cells fabricated with a sequential solution 

- 10 deposition. _ACS Energy Letters_ . **6** , 485–492 (2021). 

- 11 15. J. J. Yoo, S. Wieghold, M. C. Sponseller, M. R. Chua, S. N. Bertram, N. T. P. Hartono, J. S. 12 Tresback, E. C. Hansen, J.-P. Correa-Baena, V. Bulović, An interface stabilized perovskite solar cell 13 with high stabilized efficiency and low voltage loss. _Energy & Environmental Science_ . **12** , 2192– 14 2199 (2019). 

- 15 16. T. Zhang, M. Long, M. Qin, X. Lu, S. Chen, F. Xie, L. Gong, J. Chen, M. Chu, Q. Miao, Stable and 16 efficient 3D-2D perovskite-perovskite planar heterojunction solar cell without organic hole 17 transport layer. _Joule_ . **2** , 2706–2721 (2018). 

- 18 17. P. Li, Y. Zhang, C. Liang, G. Xing, X. Liu, F. Li, X. Liu, X. Hu, G. Shao, Y. Song, Phase pure 2D 19 perovskite for high-performance 2D–3D heterostructured perovskite solar cells. _Advanced_ 20 _materials_ . **30** , 1805323 (2018). 

- 21 18. F. Wang, X. Jiang, H. Chen, Y. Shang, H. Liu, J. Wei, W. Zhou, H. He, W. Liu, Z. Ning, 2D-quasi22 2D-3D hierarchy structure for tin perovskite solar cells with enhanced efficiency and stability. 23 _Joule_ . **2** , 2732–2743 (2018). 

- 24 19. R. Azmi, E. Ugur, A. Seitkhan, F. Aljamaan, A. S. Subbiah, J. Liu, G. T. Harrison, M. I. Nugraha, 25 M. K. Eswaran, M. Babics, Damp heat–stable perovskite solar cells with tailored-dimensionality 26 2D/3D heterojunctions. _Science_ , eabm5784 (2022). 

- 27 20. M. Xiong, W. Zou, K. Fan, C. Qin, S. Li, L. Fei, J. Jiang, H. Huang, L. Shen, F. Gao, Tailoring 28 Phase Purity in the 2D/3D Perovskite Heterostructures Using Lattice Mismatch. _ACS Energy_ 29 _Letters_ . **7** , 550–559 (2022). 

- 30 21. Y.-W. Jang, S. Lee, K. M. Yeom, K. Jeong, K. Choi, M. Choi, J. H. Noh, Intact 2D/3D halide 31 junction perovskite solar cells via solid-phase in-plane growth. _Nature Energy_ . **6** , 63–71 (2021). 

- 32 

18 

- 1 22. V. Gutmann, Solvent effects on the reactivities of organometallic compounds. _Coordination_ 2 _Chemistry Reviews_ . **18** , 225–255 (1976). 

- 3 23. M. V. Khenkin, E. A. Katz, A. Abate, G. Bardizza, J. J. Berry, C. Brabec, F. Brunetti, V. Bulović, 

- 4 Q. Burlingame, A. Di Carlo, Consensus statement for stability assessment and reporting for 5 perovskite photovoltaics based on ISOS procedures. _Nature Energy_ . **5** , 35–49 (2020). 

- 6 24. J. C. Hamill Jr, J. Schwartz, Y.-L. Loo, Influence of solvent coordination on hybrid organic– 7 inorganic perovskite formation. _ACS Energy Letters_ . **3** , 92–97 (2017). 

- 8 25. J. C. Hamill Jr, O. Romiluyi, S. A. Thomas, J. Cetola, J. Schwartz, M. F. Toney, P. Clancy, Y.-L. 9 Loo, Sulfur-donor solvents strongly coordinate Pb2+ in hybrid organic–inorganic perovskite 

- 10 precursor solutions. _The Journal of Physical Chemistry C_ . **124** , 14496–14502 (2020). 

- 11 26. S. Sidhik, W. Li, M. H. Samani, H. Zhang, Y. Wang, J. Hoffman, A. K. Fehr, M. Wong, C. Katan, 

- 12 J. Even, Memory seeds enable high structural phase purity in 2D perovskite films for high13 efficiency devices. 

- 14 27. S. Sidhik, Y. Wang, W. Li, H. Zhang, X. Zhong, A. Agrawal, I. Hadar, I. Spanopoulos, A. Mishra, 15 B. Traore, High-phase purity two-dimensional perovskites with 17.3% efficiency enabled by 16 interface engineering of hole transport layer. _Cell Reports Physical Science_ . **2** , 100601 (2021). 

- 17 28. M. Tolan, M. Tolan, _X‐ray scattering from soft‐matter thin films: materials science and basic_ 18 _research_ (Springer, 1999), vol. 148. 

- 19 29. R. M. Kennard, C. J. Dahlman, J. Chung, B. L. Cotts, A. A. Mikhailovsky, L. Mao, R. A. 20 DeCrescent, K. H. Stone, N. R. Venkatesan, Y. Mohtashami, Growth-Controlled Broad Emission in 21 Phase-Pure Two-Dimensional Hybrid Perovskite Films. _Chemistry of Materials_ . **33** , 7290–7300 22 (2021). 

- 23 30. I. Spanopoulos, I. Hadar, W. Ke, Q. Tu, M. Chen, H. Tsai, Y. He, G. Shekhawat, V. P. Dravid, 24 M. R. Wasielewski, Uniaxial expansion of the 2D Ruddlesden–Popper perovskite family for 25 improved environmental stability. _Journal of the American Chemical Society_ . **141** , 5518–5534 26 (2019). 

- 27 31. M. Seitz, A. J. Magdaleno, N. Alcázar-Cano, M. Meléndez, T. J. Lubbers, S. W. Walraven, S. 28 Pakdel, E. Prada, R. Delgado-Buscalioni, F. Prins, Exciton diffusion in two-dimensional metal29 halide perovskites. _Nature communications_ . **11** , 1–8 (2020). 

- 30 32. E. D. Kinigstein, H. Tsai, W. Nie, J.-C. Blancon, K. G. Yager, K. Appavoo, J. Even, M. G. 31 Kanatzidis, A. D. Mohite, M. Y. Sfeir, Edge States Drive Exciton Dissociation in Ruddlesden–Popper 32 Lead Halide Perovskite Thin Films. _ACS Materials Letters_ . **2** , 1360–1367 (2020). 

- 33 33. M. Degani, Q. An, M. Albaladejo-Siguan, Y. J. Hofstetter, C. Cho, F. Paulus, G. Grancini, Y. 34 Vaynzof, 23.7% Efficient inverted perovskite solar cells by dual interfacial modification. _Science_ 35 _advances_ . **7** , eabj7930 (2021). 

- 36 34. X. Wang, K. Rakstys, K. Jack, H. Jin, J. Lai, H. Li, C. S. K. Ranasinghe, J. Saghaei, G. Zhang, P. L. 37 Burn, Engineering fluorinated-cation containing inverted perovskite solar cells with an efficiency 38 of> 21% and improved stability towards humidity. _Nature communications_ . **12** , 1–10 (2021). 

- 39 35. S. Kavadiya, A. Onno, C. Boyd, Z. Yu, M. McGehee, Z. C. Holman, in _2020 47th IEEE_ 40 _Photovoltaic Specialists Conference (PVSC)_ (IEEE, 2020), pp. 1439–1440. 

19 

- 1 36. I. Levine, A. Al-Ashouri, A. Musiienko, H. Hempel, A. Magomedov, A. Drevilkauskaite, V. 2 Getautis, D. Menzel, K. Hinrichs, T. Unold, Charge transfer rates and electron trapping at buried 3 interfaces of perovskite solar cells. _Joule_ . **5** , 2915–2933 (2021). 

- 4 37. L. Kronik, Y. Shapira, Surface photovoltage phenomena: theory, experiment, and 5 applications. _Surface science reports_ . **37** , 1–206 (1999). 

- 6 38. R. Giridharagopal, J. T. Precht, S. Jariwala, L. Collins, S. Jesse, S. V. Kalinin, D. S. Ginger, 7 Time-resolved electrical scanning probe microscopy of layered perovskites reveals spatial 8 variations in photoinduced ionic and electronic carrier motion. _ACS nano_ . **13** , 2812–2821 (2019). 

- 9 39. J. Wang, W. Fu, S. Jariwala, I. Sinha, A. K.-Y. Jen, D. S. Ginger, Reducing surface 

- 10 recombination velocities at the electrical contacts will improve perovskite photovoltaics. _ACS_ 11 _Energy Letters_ . **4** , 222–227 (2018). 

- 12 40. Z. Jiang, X. Li, J. Strzalka, M. Sprung, T. Sun, A. R. Sandy, S. Narayanan, D. R. Lee, J. Wang, The 13 dedicated high-resolution grazing-incidence X-ray scattering beamline 8-ID-E at the Advanced Photon 14 Source. _Journal of synchrotron radiation_ . **19** , 627–636 (2012). 

- 15 41. Z. Jiang, GIXSGUI: a MATLAB toolbox for grazing-incidence X-ray scattering data visualization and 16 reduction, and indexing of buried three-dimensional periodic nanostructured films. _Journal of Applied_ 17 _Crystallography_ . **48** , 917–926 (2015). 

- 18 42. A. L. Patterson, The Scherrer formula for X-ray particle size determination. _Physical review_ . **56** , 978 19 (1939). 

- 20 43. F. Sanchez-Bajo, F. L. Cumbrera, The use of the pseudo-Voigt function in the variance method of X- 21 ray line-broadening analysis. _Journal of Applied Crystallography_ . **30** , 427–430 (1997). 

- 22 44. D.-M. Smilgies, Scherrer grain-size analysis adapted to grazing-incidence scattering with area 23 detectors. _Journal of applied crystallography_ . **42** , 1030–1034 (2009). 

- 24 45. W. I. Goldburg, Dynamic light scattering. _American Journal of Physics_ . **67** , 1152–1160 (1999). 

- 25 46. B. J. Berne, R. Pecora, _Dynamic light scattering: with applications to chemistry, biology, and physics_ 26 (Courier Corporation, 2000). 

- 27 47. W. Wien, Theorie der Warmestrahlung. _Physik_ . **3** , 209 (1915). 

- 28 48. W. Kohn, L. J. Sham, Self-consistent equations including exchange and correlation effects. _Physical_ 29 _review_ . **140** , A1133 (1965). 

- 30 49. J. M. Soler, E. Artacho, J. D. Gale, A. Garcia, J. Junquera, P. Ordejon, D. Sanchez-Portal, The SIESTA 31 method for ab initio order-N materials simulation. _Journal of Physics: Condensed Matter_ . **14** , 2745 32 (2002). 

- 33 50. V. R. Cooper, Van der Waals density functional: An appropriate exchange functional. _Physical_ 34 _Review B_ . **81** , 161104 (2010). 

- 35 51. I. Hamada, M. Otani, Comparative van der Waals density-functional study of graphene on metal 36 surfaces. _Physical Review B_ . **82** , 153412 (2010). 

- 37 52. S. F. Yuk, K. C. Pitike, S. M. Nakhmanson, M. Eisenbach, Y. W. Li, V. R. Cooper, Towards an accurate 38 description of perovskite ferroelectrics: exchange and correlation effects. _Scientific reports_ . **7** , 1–10 39 (2017). 

20 

- 1 53. N. Troullier, J. L. Martins, Efficient pseudopotentials for plane-wave calculations. _Physical review B_ . 2 **43** , 1993 (1991). 

- 3 54. L. G. Ferreira, M. Marques, L. K. Teles, Approximation to density functional theory for the 4 calculation of band gaps of semiconductors. _Physical Review B_ . **78** , 125116 (2008). 

- 5 55. L. Fernandez-Seivane, M. A. Oliveira, S. Sanvito, J. Ferrer, On-site approximation for spin–orbit 6 coupling in linear combination of atomic orbitals density functional methods. _Journal of_ 7 _Physics: Condensed Matter_ . **18** , 7999 (2006). 

- 8 56. D. G. Billing, A. Lemmerer, Synthesis, characterization and phase transitions in the inorganic– 9 organic layered perovskite-type hybrids [(CnH2n+ 1NH3) 2PbI4], n= 4, 5 and 6. _Acta Crystallographica_ 

- 10 _Section B: Structural Science_ . **63** , 735–747 (2007). 

- 11 57. C. C. Stoumpos, D. H. Cao, D. J. Clark, J. Young, J. M. Rondinelli, J. I. Jang, J. T. Hupp, M. G. Kanatzidis, 12 Ruddlesden–Popper hybrid lead iodide perovskite 2D homologous semiconductors. _Chemistry of_ 13 _Materials_ . **28** , 2852–2867 (2016). 

- 14 58. M. T. Weller, O. J. Weber, J. M. Frost, A. Walsh, Cubic perovskite structure of black formamidinium 15 lead iodide, α-[HC (NH2) 2] PbI3, at 298 K. _The journal of physical chemistry letters_ . **6** , 3209–3212 16 (2015). 

- 17 59. E. Bitzek, P. Koskinen, F. Gahler, M. Moseler, P. Gumbsch, Structural relaxation made simple. 18 _Physical review letters_ . **97** , 170201 (2006). 

- 19 60. B. Song, J. Hou, H. Wang, S. Sidhik, J. Miao, H. Gu, H. Zhang, S. Liu, Z. Fakhraai, J. Even, J. C Blancon, 20 A. D. Mohite, D. Jariwala, Determination of Dielectric Functions and Exciton Oscillator Strength of Two21 Dimensional Hybrid Perovskites. _ACS Materials Letters_ . **3** , 148–159 (2021). 

- 22 61. A. Tejada, S. Peters, A. Al-Ashouri, S. H. Turren-Cruz, A. Abate, S. Albrecht, F. Ruske, B. Rech, J. A. 23 Guerra, L. Korte, Hybrid Perovskite Degradation from an Optical Perspective: A Spectroscopic 24 Ellipsometry Study from the Deep Ultraviolet to the Middle Infrared. _Advanced Optical Materials_ . **10** , 25 2101553 (2022). 

- 26 62. M. Filipič, P. Loper, B. Niesen, S. De Wolf, J. Krč, C. Ballif, M. Topič, CH_3NH_3PbI_3 perovskite 27 silicon tandem solar cells: characterization based optical simulations. _Optics Express_ . **23** , A263 (2015). 

- 28 63. J. Gong, X. Wang, X. Fan, R. Dai, Z. Wang, Z. Zhang, Z. Ding, Temperature dependent optica properties 29 of SnO 2 film study by ellipsometry. _Optical Materials Express_ . **9** , 3691 (2019). 

- 30 64. R. Santbergen, R. Mishima, T. Meguro, M. Hino, H. Uzu, J. Blanker, K. Yamamoto, M. Zeman, M. A. 31 Green, K. Emery, Y. Hishikawa, W. Warta, E. D. Dunlop, C. Ballif, J. Werner, G. Nogay, A. Walter, J. 32 Geissbuhler, J. P. Seif, F. J. Haug, S. de Wolf, B. Niesen, C. Allebe, D. Saccetto, M. Despeisse, S. J. Moon, S. 

- 33 Nicolay, J. Bailat, Minimizing optical losses in monolithic perovskite/c-Si tandem solar cells with a flat 34 top cell. _Optics Express, Vol. 24, Issue 18, pp. A1288‐A1299_ . **24** , A1288–A1299 (2016). 

- 35 65. L. A. A. Pettersson, L. S. Roman, O. Inganas, Modeling photocurrent action spectra of photovoltaic 36 devices based on organic thin films. _Journal of Applied Physics_ . **86** , 487–496 (1999). 

- 37 66. R. F. Pierret, _Advanced semiconductor fundamentals_ (Prentice Hall, Upper Saddle River, N.J., 2003). 38 67. Taurus Medici (2010). 

- 39 68. J. Huang, J. Yu, H. Lin, Y. Jiang, Detailed analysis of bathocuproine layer for organic solar cells based 40 on copper phthalocyanine and C 60. _Journal of Applied Physics_ . **105** , 073105 (2009). 

21 

- 1 69. D. Shi, X. Qin, Y. Li, Y. He, C. Zhong, J. Pan, H. Dong, W. Xu, T. Li, W. Hu, Spiro-OMeTAD single crystals: 2 Remarkably enhanced charge-carrier transport via mesoscale ordering. _Science advances_ . **2** , 3 e1501491 (2016). 

- 4 70. E. Farrell, J.-L. Brousseau, Guide for DLS sample preparation. 

- 5 

- 6 

- 7 

## **Acknowledgments** 

- 8 We thank Mohammad H. K. Samani, and Amanda B. Marciel for useful discussions on the 

- 9 DLS measurements. **Funding:** The work at Rice University was supported by the DOE- 

- 10 EERE 0008843 program. J.E. acknowledges the financial support from the Institut 

- 11 Universitaire de France. The work at ISCR and Institut FOTON was performed with 

- 12 funding from the European Union’s Horizon 2020 research and innovation program 

- 13 under grant agreement no. 861985 (Pero CUBE). At Northwestern, the work was 

- 14 supported by the Office of Naval Research (ONR) under grant N00014-20-1-2725. This 

- 15 research used facilities of the Advanced Photon Source, a U.S Department of Energy 

- 16 (DOE) Office of Science User Facility operated for the DOE Office of Science by Argonne 

- 17 National Laboratory under Contract No. DE-AC02-06CH11357. ToF-SIMS analysis were 

- 18 carried out with support provided by the National Science Foundation CBET-1626418. 

- 19 This work is conducted in part using resources of the Shared Equipment Authority at Rice 

- 20 University. The work at the University of Washington, by K. H., R.G., and D. S. G. is 

- 21 supported by DOE BES under Award Number DE-SC0013957. This research used 

- 22 facilities and instrumentation supported by the U.S. National Science Foundation through 

- 23 the UW Molecular Engineering Materials Center (MEM-C), a Materials Research Science 

- 24 and Engineering Center (DMR-1719797). **Author contributions:** A.D.M, S.S. and J. E. 25 conceived the idea, designed the experiments, analysed the data and co-wrote the MS. 

- 26 Y.W. performed 2D|3D passivation experiments. W. L. and J. S. performed GIWAX 

- 27 measurements, A. J. T, performed PL maps, X. T. S performed SEM and AFM imaging, A. A. 

- 28 helped with solar cell fabrication and characterization.  M. D. performed 

- 29 photoluminescence measurements, M. G. K, and M. J analysed the solvation chemistry 

- 30 along with synthesis of 2D HaP crystals. C. K. and B. T, helped understand the 3D|2D 

- 31 interface with DFT modelling. A. P and P. A. performed TEM measurements. K. H, R, G and 

- 32 D. G. performed SKPM measurements, R. A. and M. A. A performed device modelling and 

- 33 optical simulations. T. T. helped perform TOF-SIMS and analyse data. All authors 

- 34 contributed to the MS. **Competing interests:** Rice University have filed patent for 35 method of fabricating the 3D/PP-2D bilayer stack. **Data and materials availability:** All 36 data are available in the main text or the supplementary materials. 

- 37 

- 38 **SUPPLEMENTARY MATERIALS** 

- 39 

- 40 Materials and Methods 

- 41 Movie S1 

- 42 Movie S2 

- 43 Supplementary Text 44 Fig. S1 to S33 

22 

- 1 Tables S1 to S8 

- 2 References 40‐70 

- 3 

- 4 

- 5 

- 6 

- 7 

- 8 

- 9 

- 10 

- 11 

- 12 

23 

