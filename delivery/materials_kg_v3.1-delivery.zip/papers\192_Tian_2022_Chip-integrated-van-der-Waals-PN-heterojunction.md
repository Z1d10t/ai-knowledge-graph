# Chip-integrated van der Waals PN heterojunction photodetector with low dark current and high responsivity

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Light: Science & Applications |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 164 |
| 作者 | Ruijuan Tian, Xue-Tao Gan, Chen Li, Xiaoqing Chen, Siqi Hu, Linpeng Gu, D. van Thourhout, A. Castellanos-Gómez et al. |
| DOI | 10.1038/s41377-022-00784-x |
| 源文件 | 092_Tian_2022_Chip-integrated-van-der-Waals-PN-heterojunction.pdf |

---
# **Chip-integrated van der Waals PN heterojunction photodetector with low dark current and high responsivity** 

Ruijuan Tian<sup>1</sup> , Xuetao Gan<sup>1,</sup> *, Chen Li<sup>1</sup> , Xiaoqing Chen<sup>1</sup> , Siqi Hu<sup>1</sup> , Linpeng Gu<sup>1</sup> , Dries Van Thourhout<sup>2</sup> , Andres Castellanos-Gomez<sup>3</sup> , Zhipei Sun<sup>4</sup> , Jianlin Zhao<sup>1</sup> 

1. Key Laboratory of Light Field Manipulation and Information Acquisition, Ministry of Industry and Information Technology, and Shaanxi Key Laboratory of Optical Information Technology, School of Physical Science and Technology, Northwestern Polytechnical University, 710129 Xi’an, 

      - China 

2. Photonics Research Group, Center for Nano and Biophotonics, Ghent University, B-9000 Gent, Belgium 

3. Materials Science Factory, Instituto de Ciencia de Materiales de Madrid (ICMM-CSIC), E-28049 Madrid, Spain 

4. Department of Micro- and Nanosciences, Aalto University, Tietotie 3, FI-00076 Espoo, Finland 

   - _Email:_ xuetaogan@nwpu.edu.cn 

**Abstract** : Two-dimensional materials are attractive for constructing high-performance photonic chip-integrated photodetectors because of their remarkable electronic and optical properties and dangling-bond-free surfaces. However, the reported chip-integrated two-dimensional material photodetectors were mainly implemented with the configuration of metal-semiconductor-metal, suffering from high dark currents and low responsivities at high operation speed. Here, we report a van der Waals PN heterojunction photodetector, composed of p-type black phosphorous and n-type molybdenum telluride, integrated on a silicon nitride waveguide. The built-in electric field of the PN heterojunction significantly suppresses the dark current and improves the responsivity. Under a bias of 1 V pointing from n-type molybdenum telluride to p-type black phosphorous, the dark current is lower than 7 nA, which is more than two orders of magnitude lower than those reported in other waveguide-integrated black phosphorus photodetectors. An intrinsic responsivity up to 577 mA W<sup>−1</sup> is obtained. Remarkably, the van der Waals PN heterojunction is tunable by the electrostatic doping to further engineer its rectification and improve the photodetection, enabling an increased responsivity of 709 mA W<sup>−1</sup> . Besides, the heterojunction photodetector exhibits a response bandwidth of ~1.0 GHz and a uniform photodetection over a wide spectral range, as experimentally measured from 1500 to 1630 nm. The demonstrated chip-integrated van der Waals PN heterojunction photodetector with low dark current, high responsivity and fast response has great potentials to develop high-performance on-chip photodetectors for various photonic integrated circuits based on silicon, lithium niobate, polymer, etc. 

1 

## **Introduction** 

On-chip photonic integrated circuits (PICs) could provide a versatile platform to revolutionize optical computing, communications, chemical-/bio-sensing, LiDARs, etc<sup>1-4</sup> . Currently, a variety of materials are being employed to develop PICs with their own superiorities. For example, silicon PIC is compatible with the mature CMOS technology for low-cost and large-scale production<sup>5</sup> ; Silicon nitride PIC could tolerate moderately high optical power and large fabrication errors<sup>6,7</sup> ; Lithium niobate PIC could achieve perfect electro-optic modulations with low driven voltage and high linearity<sup>8</sup> . One of the handicaps in these PICs, however, is the monolithic integration of waveguides and photodetectors with a single material. To support the light transmission in the waveguide, the PIC materials cannot absorb the optical signal, making it impossible to realize the integrated photodetector out of a single material. To solve this, hetero-integrations of absorptive bulk materials on PICs have been implemented, which though still present open challenges. For silicon PICs, the heteroepitaxy of germanium or III-V compound semiconductors has achieved decent integrated photodetectors<sup>9-11</sup> . Despite continued advancement, technological factors limit the widespread usage of such detectors, specifically including the high costs associated with the processing of germanium or III-V semiconductors. Wafer-bonding technique is an alternative, which unfortunately involves complicated processes and has material interface issues. For PICs of dielectric materials, such as silicon nitride and lithium niobate, bulk semiconductors can hardly be epitaxially grown on top, though only few works about the integrated photodetectors were reported with complicated bonding processes<sup>12-14</sup> . 

Recently, two-dimensional (2D) materials have emerged as an attractive photon-absorption material for chip-integrated photodetectors<sup>15-20</sup> . 2D materials have no surface dangling bonds, which eliminates the lattice-mismatch constraints to hetero-integrate them with PICs. The family of 2D materials has a rich variety of electronic and optical properties, including semi-metallic graphene, insulating boron nitride, semiconducting transition metal dichalcogenides and black phosphorus. As a consequence, chip-integrated photodetectors operating at various spectral ranges could be constructed by choosing appropriate 2D materials. Optoelectronic properties of 2D materials could be engineered further by stacking dissimilar 2D materials to create van der Waals heterostructures. In addition, large-scale growth of 2D materials 

2 

via chemical vapor deposition method has also been demonstrated with the simplicity of device fabrications<sup>21</sup> . In the last few years, chip-integrated 2D material photodetectors have been reported with excellent merits. Graphene photodetectors were integrated on waveguides of silicon, silicon nitride, and chalcogenide glass<sup>21-24</sup> . An operation bandwidth exceeding 110 GHz was realized owing to the ultrahigh carrier mobility of the graphene<sup>25</sup> . A monolayer molybdenum disulfide was integrated on a silicon nitride waveguide for the photodetector on visible PIC<sup>26</sup> , which exhibits a remarkable responsivity of 10<sup>3</sup> A W<sup>−1</sup> . However, these chip-integrated 2D material photodetectors still have gaps for future PICs, which require a photodetection performance with the combination of low dark current, high responsivity, and fast response speed. Graphene’s zero bandgap causes high dark currents in its photodetectors. Photodetectors of other 2D materials were normally carried out with the geometry of metal-semiconductor-metal (M-S-M), which results in high dark current and low operation bandwidth (see Supplementary Information for more details). 

Here, we report that integrating van der Waals PN heterojunctions of 2D materials on optical waveguides can provide a promising strategy to realize chip-integrated photodetectors with low dark current, high responsivity, and fast speed. In those photodetectors based on bulk materials, PN junctions were widely employed to achieve high performance. Their rectifying characteristics allow the suppression of dark current and the improvements of responsivity and operation bandwidth. PN junctions of bulk materials are generally realized by complicated ion implantation, diffusion of dopants, or epitaxy. Differently, the PN heterojunction of 2D materials employed in this work is formed by simply van der Waals stacking few-layer black phosphorus (BP) and molybdenum ditelluride (MoTe2), which are naturally p- and n-doped, respectively. Because of the ultrathin thickness and a steep interfacial charge carrier gradient, this van der Waals PN heterojunction allows the electrostatic doping to engineer its rectification behavior and to improve the photodetection performance. The BP/MoTe2 PN heterojunction is integrated on a silicon nitride waveguide to carry out the chip-integrated photodetector. Under an external bias voltage of 1 V pointing from n-type MoTe2 to p-type BP, the dark current is lower than 7 nA, which is more than two orders of magnitude lower than those reported in other waveguide-integrated BP photodetectors. The intrinsic responsivity is about 600 mA W<sup>−1</sup> . The dynamic response presents a 3 dB-bandwidth of ~1.0 GHz. Moreover, the operation over a 

3 

broad spectral range is obtained due to BP’s intrinsic narrow bandgap. The proposed van der Waals PN heterojunction could be constructed by other 2D materials<sup>27,28</sup> for photodetectors in other desirable spectral ranges on PICs. 

## **Results** 

## **Structure of the waveguide-integrated van der Waals PN heterojunction** 

Figure 1a presents the schematic of the waveguide-integrated BP/MoTe2 heterojunction photodetector. As reported in our previous work, by mechanically stacking p-doped BP and n-doped MoTe2, their interface forms a van der Waals PN heterojunction with a vertical built-in electric field<sup>29</sup> . The integration of this heterostructure on a silicon nitride waveguide enables its coupling with the evanescent field of the guiding mode. The light absorption is enhanced effectively due to the extended light-BP/MoTe2 interaction length. Drain and source electrodes are transferred directly on the BP and MoTe2 along the two sides of the waveguide, respectively<sup>30</sup> (see Materials and methods section). Note, though the direct transfer-printing technique is employed to fabricate the metal electrodes, the ordinary method with metal deposition and lift-off is also valid for the proposed integrated photodetector<sup>16,20</sup> . The carrier transport direction in the BP/MoTe2 heterojunction channel is perpendicular to the light propagation direction in the waveguide. For light transmitting in the waveguide at the telecom wavelength range, the BP layer would absorb it to generate photocarriers. With the built-in electric field in the PN heterojunction or the external electric field from an applied bias, the photocarriers would be rapidly separated at the heterostructure interface, which yields photocurrent across the heterostructure channel. The MoTe2 layer can also contribute to the photocurrent if the light has a shorter wavelength, such as the visible light, making the waveguide-integrated photodetector more efficient. Actually, other n-doped 2D materials, such as MoS2 and InSe, could be alternative for replacing the n-doped MoTe2 layer if the clean interface of the van der Waals heterostructure is guaranteed. Here, a layer of hexagonal boron nitride (h-BN) is placed between the BP/MoTe2 heterostructure and the silicon nitride waveguide to minimize the substrate rough surface and local potential puddles, which might degrade the intrinsic electronic properties of the 2D materials. Since BP is unstable in the ambient condition, another h-BN layer is employed to encapsulate the BP/MoTe2 heterostructure, which could 

4 

ensure the stability of device performance during the testing. 



**Fig. 1 BP/MoTe2 van der Waals PN heterojunction photodetector integrated on a silicon nitride waveguide** . **a** Schematic of the waveguide-integrated van der Waals PN heterojunction photodetector composed of stacking p-doped BP and n-doped MoTe2, which are evanescently coupled with the guiding mode of the silicon nitride waveguide. **b** Top: Band profiles of BP and MoTe2 layers in the non-equilibrium state. Bottom: Band alignment of BP/MoTe2 PN heterojunction in the thermal equilibrium state. **c** Top: Optical microscope image of the fabricated device, where a BP/MoTe2 heterojunction is integrated on one arm of a Mach-Zehnder interferometer. Bottom: Zoom-in view of the device indicated by the black square box in the top panel. 

The employed silicon nitride waveguide is fabricated in a silicon nitride slab (with a thickness of 300 nm) on a silicon substrate with a middle silicon oxide layer (with a thickness of 2 μm). The silicon substrate is highly doped, which could be functioned as a global back gate of the BP/MoTe2 heterostructure. Similar to the 

5 

configuration of a field effect transistor, the metal electrodes contacting the BP and MoTe2 layers could be defined as the drain and source electrodes, respectively. With the buried silicon oxide layer and the top silicon nitride layer as the dielectric layer, a vertical electric field could be actuated over the top BP/MoTe2 heterostructure when a gate voltage is applied between the drain electrode and the bottom doped silicon substrate. The carrier densities in the BP/MoTe2 heterostructure could be tuned by the electrostatic field, resulting in the tunable heterojunctions. 

Figure 1b shows the energy band diagrams of the BP/MoTe2 van der Waals heterostructure in non-equilibrium (the top panel) and thermal equilibrium states (the bottom panel). The bandgap and electron affinity of BP (MoTe2) are ~0.3 eV (~0.9 eV) and ~4.1 eV (~3.8 eV), respectively<sup>31,32</sup> . The differences in bandgaps and electron affinities give rise to the BP/MoTe2 heterojunction with a conduction band offset  _Ec_ ~0.3 eV and a valence band offset  _Ev_ ~0.3 eV. Under the thermal equilibrium state, the interface between p-doped BP and n-doped MoTe2 forms a typical PN diode, as illustrated in the bottom panel of Fig. 1b. The built-in electric potential of the BP/MoTe2 van der Waals heterostructure is simply estimated by the difference between the Fermi levels of p-doped BP and n-doped MoTe2, which is accompanied by a built-in electric field pointing from MoTe2 to BP. 

To determine the intrinsic responsivity and internal quantum efficiency of the photodetector, the absolute light absorption on the waveguiding mode by the BP/MoTe2 heterostructure should be quantitatively extracted. To obtain that, a Mach-Zehnder interferometer (MZI) based on the silicon nitride waveguide is utilized, as shown in Fig. 1c. The BP/MoTe2 heterostructure is integrated on one arm of the MZI. The width of the waveguide is 1080 nm to ensure the low-loss single mode transmission around the telecom wavelength range. To facilitate the light coupling between single mode fibers and the silicon nitride MZI, two grating couplers are designed at the ends of the MZI. The MZI patterns are carved out of the silicon nitride slab by electron beam lithography and plasma dry-etching. The bottom h-BN, BP, MoTe2, and top h-BN layers are dry transferred and mechanically stacked onto the silicon nitride waveguide in sequence<sup>29</sup> . Before the final encapsulation of the top h-BN layer, pre-patterned Au pads deposited on a silicon substrate are peeled and mechanically transferred onto the BP and MoTe2 flakes to form the drain and source electrodes, respectively<sup>29,30</sup> . To release the air bubbles between the 2D materials and 

6 

metal electrodes for their atomic level contact, the finished device is finally annealed in a tube furnace filled with a forming gas (95% Ar and 5% H2). This effectively assists the formation of the BP/MoTe2 PN heterojunction and decent metal contacts. In the fabricated device, the lengths of the BP and MoTe2 flakes overlapping with the waveguide are ~19.77  m and ~56.6  m, respectively. Their heterostructure is confirmed by Raman spectroscopy (see Fig. S1). The thicknesses of the BP and MoTe2 layers are evaluated by atomic force microscope and found to be ~13 nm and 10.6 nm (see Fig. S2). 

Optical transmissions of the fabricated MZI are measured by coupling a wavelength-tunable narrowband laser (1500 nm to 1630 nm) into one of the grating couplers, and monitoring the output powers at the other grating coupler. Though both the transverse electric (TE) and transverse magnetic (TM) modes are supported in the waveguide, the waveguiding mode with the TE polarization has much lower transmission loss than the TM mode. In our measurement, the TE mode of the silicon nitride waveguide is experimentally excited by controlling the polarization of the incident light from the input fiber to achieve the maximized output power. The transmission spectra could be obtained by sweeping the laser wavelength. During the integration of the BP/MoTe2 heterostructure, the transmission spectra of the MZI are recorded in each step, as shown in Fig. S3. Interference fringes are observed from the transmission spectra with the period determined by the phase difference between the two arms of the MZI. After each transfer process of the 2D materials, the whole interference fringe pattern red-shifts due to the increased phase delay on the long arm of the MZI. Because each integration of 2D materials would induce absorptions or mode scatterings, extinction ratios (ERs) of the interference fringes reduce gradually. From the extracted ERs, the absorption coefficient of the BP layer is evaluated as ~0.09815 dB μm<sup>−1</sup> . The measured light absorption coefficient agrees well with the theoretical prediction value of 0.0911 dB  m<sup>–1</sup> (See Supplementary Information for detail). In other words, the integrated 19.77  m long BP layer absorbs about 42.35% of the optical power transmitted in the waveguide. This high light absorption by the BP layer could be attributed to its narrow direct bandgap and the extended interaction length with the optical guiding mode. It could facilitate the high-efficiency in the photodetection. 

## **Electrical properties and photoresponses of the waveguide-integrated** 

7 

## **BP/MoTe2 PN heterojunction** 

Before we couple light into the waveguide covered with the BP/MoTe2 heterostructure, we measure the electrical characteristics of the BP/MoTe2 channel by applying the drain-source bias voltage _V_ DS from −1 V to 1 V to evaluate the performance of the van der Waals PN heterojunction. The positive (negative) _V_ DS means the drain electrode has a higher (lower) electric potential than the source electrode. As shown in the black curve of Fig. 2a, without optical illumination, the drain-source current _I_ DS presents a strong rectifying characteristic under the positive and negative bias voltage _V_ DS. The ON/OFF current ratio of this diode behavior is about 1.6  10<sup>3</sup> , and the ideality factor is estimated as 1.87 using the Shockley diode equation<sup>33,34</sup> 



<!-- Start of picture text -->
I DS  nV T W  I 0 R s exp  V DS <br>R s  nV T  nV T <br><!-- End of picture text -->

where _V_ T = _k_ B _T_ / _q_ is the thermal voltage at temperature _T_ , _k_ B is the Boltzmann constant, _q_ is the electron charge, _I_ 0 is the saturable current under negative _V_ DS, _n_ is the diode ideality factor, _W_ is the Lambert W function and _R_ s is the series resistance. The result indicates the van der Waals PN heterojunction is successfully formed at the interface of stacked p-doped BP and n-doped MoTe2. 

8 





**Fig. 2 Electrical characteristics and photoresponses (with the coupling light at 1503 nm) of the waveguide-integrated BP/MoTe2 heterojunction photodetector. a** Measured current–voltage characteristics of the photodetector without (black line) and with optical illuminations at different BP absorption powers. **b** Measured zero-bias photocurrents versus the absorbed optical powers. **c** Intrinsic responsivity as a function of the bias voltage. **d** Normalized photocurrent-dark-current ratio (NPDR) as a function of the bias voltage. 

By coupling light at the wavelength of 1503 nm into the MZI via the grating coupler, the _I_ DS– _V_ DS curves of the PN heterojunction are measured at different optical absorption powers by the BP layer, as shown in Fig. 2a. Due to photocarriers in the BP layer, _I_ DS increases considerably under optical illumination, which implies the pronounced photoresponse. The magnitude of the photocurrent _I_ photo is defined by the difference between _I_ DS measured with and without optical illumination. It increases with higher absorbed optical powers because more photocarriers are generated and collected. With the zero bias ( _V_ DS = 0 V), owing to the built-in electric field formed at the BP/MoTe2 interface, the heterojunction could separate the photocarriers and generate large photocurrent. It promises the self-powered on-chip photodetection. 

9 

Upon illumination, the internal electric field at the BP/MoTe2 heterojunction separates photogenerated carriers and gives rise to a photocurrent at zero external bias (short-circuit current, _I_ sc) and a photovoltage with no current flowing (open-circuit voltage, _V_ oc). Figure 2b plots the measured _I_ sc as the BP absorption power increases, showing a linear dependence. It confirms the photovoltaic effect of the van der Waals PN heterojunction. In addition, an open-circuit voltage _V_ oc of 228 mV is measured from the heterojunction with a BP absorption power of 12.79  W, as shown in Fig. S5. The intrinsic responsivity _R_ int is estimated as 277 mA W<sup>−1</sup> , which is defined as _R_ int _=I_ photo/ _P_ photo_int. Here, _P_ photo_int is the optical power absorbed by the BP layer, which is experimentally determined from the interferometry results of the MZI before and after the integration of BP (see the Supplementary Information)<sup>16</sup> . To the best of our knowledge, the obtained zero-bias responsivity is highest among those reported in self-powered waveguide-integrated 2D material photodetectors<sup>15,17,18,21,35</sup> . This could be attributed to the built-in electric field at the interface of the PN heterojunction. The high intrinsic responsivity corresponds to a high internal quantum efficiency  IQE of 22.5% at the wavelength of 1503 nm, which is defined as  IQE = _R_ int  ℏ _ω_ / _q_ . Here, ℏ is the reduced Planck constant,  is the light angular frequency and _q_ is the elementary charge. The high open-circuit voltage and short-circuit current indicate that a van der Waals PN junction is successfully formed in the waveguide-integrated BP/MoTe2 heterostructure. 

We further characterize the photoresponses of the device at varied electrical biases of _V_ DS. The extracted photoresponsivities are shown in Fig. 2c. With the negative _V_ DS, an external electric field pointing from MoTe2 to BP is built at the interface of the PN junction. It would strengthen the built-in electric field of the junction, which therefore improves the separation efficiency of the photocarriers and subsequently increases the responsivity. At _V_ DS = −1 V, the intrinsic (extrinsic) responsivity is increased to 577 (283) mA W<sup>−1</sup> . The extrinsic responsivity ( _R_ ext) is defined as _R_ ext _=I_ photo/ _P_ photo_ext, where _P_ photo_ext is the optical power coupled into the waveguide via the grating coupler. With the positive _V_ DS, the responsivity first decreases to the minimum due to the gradual elimination of the built-in electric field, and then increases rapidly with the effective electric field provided by the external bias considering the thinned depletion region. At _V_ DS = 1 V, the intrinsic (extrinsic) responsivity is about 3 (1.48) A W<sup>−1</sup> . This could be attributed to the photoconductive 

10 

gain. As indicated by the side schematic view of the fabricated device (see Fig. S6), the photogenerated electrons in BP must transport a long channel to get collected by the source electrode, which can lead to a large photoconductive gain. Note that the dark current at _V_ DS = 1 V is about 25  A, as shown in Fig. 2a. Though the responsivity is high at this positive _V_ DS, the large dark current would reduce the signal-to-noise ratio and increase power consumption, which degrades its operation potential. 

On the contrary, at _V_ DS = −1 V, the dark current of the device _I_ dark is as low as 6.8 nA, promising a high-performance photodetection by considering its high intrinsic responsivity of 577 mA W<sup>−1</sup> . The dark current of 6.8 nA at _V_ DS = −1 V is around three orders of magnitude lower than that of waveguide-integrated graphene photodetectors<sup>17</sup> and two orders of magnitude lower than that of waveguide-integrated BP photodetectors<sup>16,35</sup> (see Supplementary Table 1), which benefits from the PN heterojunction in the proposed van der Waals heterostructure. Normalized photocurrent-dark-current ratio (NPDR) is another important performance indicator of an on-chip photodetector<sup>36</sup> , which is expressed as NPDR = ( _I_ photo/ _I_ dark)/ _P_ , where _P_ is the laser power coupled in the waveguide. Taking the external responsivity into account, the evaluated NPDRs of the device at different bias voltages are plotted in Fig. 2d. At _V_ DS = −1 V, the NPDR exceeds 4.13  10<sup>4</sup> mW<sup>−1</sup> , which is larger than those of waveguide-integrated 2D material photodetectors by two to four orders of magnitude<sup>20,37-39</sup> . The NPDR enhancement could be accredited to the effective suppression of the dark current in the PN heterojunction without the sacrifice of the photocurrent. 



11 

**Fig. 3 Steady and dynamic photoresponses of the waveguide-integrated BP/MoTe2 PN heterojunction photodetector. a** Photocurrents measured under the optical illumination at the wavelengths ranging from 1500 nm to 1630 nm. **b** Impulse response of the device at zero, positive and negative biases. The vertical dashed line indicates the time point at which the picosecond laser pulse launches. 

Because of the intrinsic narrow bandgap of the few-layer BP flake, the constructed BP/MoTe2 heterojunction on the waveguide could respond to the optical illumination in a wide spectral range, enabling the broadband photodetection. Figure 3a displays the wavelength-dependent photoresponse of the fabricated device at zero bias. By fixing the laser power and sweeping the laser wavelength, photocurrents are obtained over the wavelength range from 1500 to 1630 nm, which is the operation wavelength range of the employed tunable laser. The photocurrents over the measured wavelength range are moderately uniform. As the laser wavelength increases, the gradually decreased photocurrents could be attributed to the degraded coupling efficiency of the grating couplers at the longer wavelength (see Fig. S3c). 

To evaluate the dynamic response of this waveguide-integrated van der Waals PN heterojunction photodetector, we carry out measurements of its impulse response. A picosecond pulsed laser at the wavelength of 1550 nm is employed as the incident light source, which provides a train of 5 ps long (full width at half-maximum) optical pulses. By sending the pulses into the device, the generated photocurrent pulses are monitored using a real-time oscilloscope (see Fig. S7). Figure 3b shows the measured impulse responses of the device at zero, positive and negative biases, from which we extract the pulse relaxation time  _t_ by counting the full time width at half-maximum of the pulse peak. The results are  _t_ = 440 ps at _V_ DS = −0.7 V,  _t_ = 523.8 ps at _V_ DS = 0 V,  _t_ = 1157 ps at _V_ DS = 0.7 V. The dynamic response bandwidth can be derived by the time-bandwidth product, giving _f_ 3 dB = 0.44/  _t_ = ~1.0 GHz at _V_ DS = −0.7 V, ~0.84 GHz at _V_ DS = 0 V, ~0.38 GHz at _V_ DS = 0.7 V. Because of the ultrathin junction interface of the vertical van der Waals heterostructure, the carrier diffusion time across it would not limit the response speed. The dependence on the bias voltage of the bandwidth could imply that the operation speed is mainly limited by the resistance and capacitance in the BP/MoTe2 channel, _i.e_ ., the RC constant. With a positive (negative) bias _V_ DS, the depleted charge region of the PN BP/MoTe2 junction becomes narrower (wider), which increases (decreases) the junction capacitance. As a result, 

12 

the bandwidths of 1.0 GHz and 0.38 GHz are obtained with _V_ DS = −0.7 V and 0.7 V, respectively. Since the absence of instruments to measure the resistance and capacitance of the device at high frequency in our experiment condition, it is difficult to quantitatively analyze their individual influences on the response speed. In the future device, by shortening the channel length and reducing device area of the the BP/MoTe2 heterostructure to only cover on the waveguide, the RC constant could be decreased greatly to further increase operation bandwidth. 

## **Improving photodetection of the waveguide-integrated BP/MoTe2 PN heterojunction by electrostatic gating** 



































**Fig. 4 Tunable optoelectronic characteristics of the waveguide-integrated BP/MoTe2 heterojunction by electrostatic gating. a** Gate tunable _I_ DS _–V_ DS characteristics of the BP/MoTe2 PN diode in darkness. **b** Dark currents of the device at _V_ DS = − 1 V as a function of the back gate voltage. **c** Gate tunable _I_ DS _–V_ DS characteristics of the BP/MoTe2 PN diode with the optical illumination at the wavelength of 1503 nm. **d** Intrinsic responsivities of the 

13 

device at _V_ DS = − 1 V as a function of the back gate voltage. Inset is the cross-section schematics of the simplified equivalent circuit model of the waveguide-integrated BP/MoTe2 heterojunction. 

To further improve the responsivity of the waveguide-integrated BP/MoTe2 heterojunction photodetetor, an out-of-plane electrostatic field is applied across it by the back gate. The BP/MoTe2 vertical van der Waals heterostructure has an ultrathin thickness and a steep interfacial charge carrier gradient. The carrier density (and Fermi level) of the BP and MoTe2 layers could be tuned efficiently under a vertical electrostatic field applied across them<sup>29</sup> . As mentioned above, the employed silicon nitride waveguide has a back substrate of doped silicon, which could be functioned as a global back-gate with an electrical voltage between it and the source electrode. Figure 4a displays the _I_ DS– _V_ DS curves of the BP/MoTe2 heterojunction measured in the darkness with different gate voltages _V_ G. When the _V_ G increases from  60 V to 60 V, | _I_ DS| under positive and negative bias decreases with a drop in the rectification ratio (Fig. S8). The gate dependent dark current under _V_ DS = −1 V is extracted in Fig. 4b. The dark current decreases from 54 nA to 8.5 nA. Note that, the dark current at _V_ DS = −1 V and _V_ G = 0 V obtained in this measurement is 18 nA, which is larger than the 6.8 nA obtained in Fig. 2a. It could be attributed to the degradation of the BP flake in the ambient condition during the measurements in couple days. The hBN layer is used as the upper protective layer in this work. There are some other possible methods to further improve the stability of the BP flake, such as atomic layer deposition (ALD) of dielectric layer (Al2O3)<sup>40,41</sup> , PMMA upper-cladding<sup>42</sup> , etc. Under the light illumination at a wavelength of 1503 nm, | _I_ DS| under positive bias shows the same trend as that in dark while | _I_ DS| under negative bias increase when _V_ G increases (Fig. 4c). The increase of | _I_ DS| under negative bias indicates a more efficient generation of photocurrent. As shown in Fig. 4d, the intrinsic responsivity is improved from 279 mA W<sup>−1</sup> to 709 mA W<sup>−1</sup> as _V_ G changes from  60 V to 60 V. We notice that the best intrinsic responsivity of 709 mA W<sup>−1</sup> is achieved at _V_ G = 60 V and the value of the responsivity remains unchanged as _V_ G increases, which could be limited by saturation of BP absorption<sup>20</sup> . 

The increase of responsivity and suppression of dark current when _V_ G increases from  60 V to 60 V can be explained with a simplified equivalent circuit model (Fig. S9 or the inset of Fig. 4d). This simplified equivalent circuit model consists of several parts: the contact resistances of Au/MoTe2 ( _R_ MoTe2/Au) and Au/BP ( _R_ BP/Au), the sheet 

14 

resistance of BP ( _R_ BP_1, _R_ BP_0) and MoTe2 channels ( _R_ MoTe2_0), and two diodes (Diode1, Diode2). _R_ BP_0 represents the sheet resistance from the BP in heterostructure area. Diode1 represents the heterostructure on the top of the waveguide while Diode2 represents the other part of the heterostructure. As shown in Fig. S10, MoTe2 is n type while BP is p type. When _V_ G increases from negative to positive values, _R_ MoTe2_0 decreases while _R_ BP_1 and _R_ BP_0 increase. The strongly increased _R_ BP_1 and _R_ BP_0 could account for the decreased dark | _I_ DS| measured under both conditions of positive and negative bias, as the results shown in Fig. 4a. With the optical illumination by the waveguide mode, the photogenerated electrons and holes in the BP layer will contribute to the variations of | _I_ DS|, as shown in Fig. 4c. Under the negative bias ( _V_ DS < 0), | _I_ DS| increases gradually as _V_ G increases from  60 V to 60 V, which is opposite to that in darkness. In the case with a large positive _V_ G (e.g., _V_ G _=_ 60 V), _R_ MoTe2_0 is small and _R_ BP_0 is large due to the field effect (Fig. S10). The effective voltage over the Diode1 is larger than that over the Diode2, which induces a larger built-in electric field across the Diode1 than the Diode2. Since the Diode1 is on the top of the waveguide mode, photogenerated carriers overlaps with the large built-in electric field, resulting in a large photocurrent. As _V_ G decreases gradually to negative values, _R_ MoTe2_0 ( _R_ BP_0) become larger (smaller). The effective voltage (built-in electric field) over the Diode1 is weakened, Hence, the photogenerated carriers in Diode1 region can not be harvested effectively, which reduces the photocurrent. Though the built-in electric field in the Diode2 is strengthened, there is no photogenerated carriers in this region. As a result, under _V_ DS < 0 and the optical illumination, the remarkable photocurrents strengthened by the positive _V_ G make the | _I_ DS| larger than that under the negative _V_ G. Under the positive bias ( _V_ DS > 0), because both Diode1 and Diode2 are turned on, | _I_ DS| is dominated by the dark current though there is an optical illumination. Hence, the _V_ G-dependence of | _I_ DS| in Fig. 4c is same as that in Fig. 4a under _V_ DS > 0. 

This unique gate-tunability of the waveguide-integrated 2D van der Waals heterojunction photodetector is in stark contrast to conventional bulk photodiodes integrated on a waveguide, in which the photocurrent is mainly determined by the intrinsic built-in potential. The junctions in bulk semiconductors cannot be easily modulated once their fabrications were finished. 

## **Discussion** 

In conclusion, we proposed and demonstrated a waveguide-integrated photodetector 

15 

based on a BP/MoTe2 van der Waals PN heterojunction. It presents ultralow dark currents and high responsivities due to the current-rectifying characteristic of the PN heterojunction. From a fabricated device, under an external bias of 1 V pointing from n-type MoTe2 to p-type BP, the intrinsic (extrinsic) responsivity is as high as 577 (283) mA W<sup>−1</sup> with a low dark current of 6.8 nA, leading to a remarkable NPDR of 4.13  10<sup>4</sup> mW<sup>−1</sup> . The built-in electric field of the PN heterojunction also enables a self-driven photodetection with an intrinsic responsivity of 277 mA W<sup>−1</sup> under zero-bias condition. Impulse measurement shows that this kind of photodetectors can operate with a dynamic response bandwidth of 1.0 GHz. Due to the narrow bandgap of the few-layer BP, these photodetection performances are valid over a wide spectral range covering the telecommunication wavelengths. Relying on the ultrathin thickness and steep interfacial charge carrier gradient of the BP/MoTe2 van der Waals heterostructure, its photodetection could be further improved by a simple electrostatic gating. An intrinsic (extrinsic) responsivity of 709 (340) mA W<sup>−1</sup> was obtained with a gate voltage of 60 V under an external bias of 1 V pointing from n-type MoTe2 to p-type BP. Figure of merit of our phototdetector such as dark current and responsivity are on par with the reported Si-Ge waveguide photodetectors though the bandwidth of this device still needs to be optimized, as compared in Supplementary Table 2. While the silicon nitride waveguide is employed in this work, considering the layered structure and dangling-bond-free surface of the 2D materials, the proposed chip-integrated van der Waals PN heterojunction could be applied to on-chip waveguides or resonators based on other PIC materials, such as silicon, lithium niobate, polymers, etc. In addition, the employed transfer-printing technology for constructing the van der Waals PN heterojunction in our proposed device guarantees the cleanliness of the interface at the heterostructure, which does not take care to other factors, such as the twist angles of the stacked layers. Thus, it is possible to fabricate the waveguide-integrated CVD-grown van der Waals heterojunction photodetectors by using standard fabrication technology, based on the mature growth of large-scale crystalline BP and MoTe2 films<sup>43-45</sup> . This could facilitate the development of the proposed device in future practical applications. Our work could open an avenue to develop high-performance on-chip photodetectors for various PICs with ease of fabrication, low dark current, and high responsivity. 

## **Materials and methods** 

16 

## **Device fabrication** 

The employed silicon nitride waveguides and MZIs were fabricated in a 300 nm thick silicon nitride slab on a highly doped silicon substrate with a 2  m buried oxide layer. Electron-beam lithography (EBL, NanoBeam Limited nB5) and inductively coupled plasma etching (Oxford Instruments, Plasma Pro 100 Cobra300) were used to fabricate the silicon nitride waveguides and MZIs. The interface is important for the high quality PN heterojunction. To ensure that, mechanically exfoliated h-BN, BP, MoTe2 (purchased from HQ graphene) were sequentially transferred onto the silicon nitride waveguide with a dry transfer technique<sup>30</sup> . Au electrodes with a thickness of 50 nm were prepared on a clean silicon substrate using a shadow mask by thermal evaporation, which were then mechanically peeled and released onto the BP and MoTe2 flakes<sup>30</sup> . The finished BP/MoTe2 heterojunction was finally annealed in a tube furnace (BTF-1200C, BEQ) filled with forming gas (95% Ar and 5% H2) at 200 ℃ for 2 h. 

## **Electrical and photoresponse characterizations** 

The electrical characteristics of the fabricated BP/MoTe2 heterojunction devices were measured at room temperature under ambient conditions using a Keysight B2912A dual-channel digital source meter. A tunable laser in the telecom-band (TUNICS T100S-HP) was used as the light source. High-frequency photoresponses were performed by the impulse response measurements. A train of optical pulses (with a pulse width of 5 ps and a repetition rate of 100 MHz) at the wavelength of 1550 nm generated by an optical parametric oscillator was coupled into the device via the grating couplers. The impulse photocurrents generated from the fabricated photodetector were extracted by using a RF GS pin (MPI T26A GS150) and a bias Tee (Anritsu, G4N37, 8 kHz-40 GHz). An electrical amplifier (Mini-circuits, ZKL-1R5  , 10-1500 MHz) was used to amplify the extracted impulse photocurrents. Finally, the amplified electrical signal was transmitted into the oscilloscope (Lecroy, 740Zi-A) and the impulse response was measured. 

### **Acknowledgements** 

This project was primarily supported by the National Key R&D Program of China (Grant Nos. 

17 

2018YFA0307200 and 2017YFA0303800), the National Natural Science Foundation of China (Grant Nos. 61905198, 61775183, 11634010, and 61675171), Key Research and Development Program in Shaanxi Province of China (Grant Nos. 2017KJXX-12, 2018JM1058, and 2018KW-009), the Fundamental Research Funds for the Central Universities (Grant Nos. 3102017jc01001, 3102018jcc034, and 3102017HQZZ022). 

### **Author details** 

1Key Laboratory of Light Field Manipulation and Information Acquisition, Ministry of Industry and Information Technology, and Shaanxi Key Laboratory of Optical Information Technology, School of Physical Science and Technology, Northwestern Polytechnical University, 710129 Xi’an, China.<sup>2</sup> Photonics Research Group, Center for Nano and Biophotonics, Ghent University, B-9000 Gent, Belgium.<sup>3</sup> Materials Science Factory, Instituto de Ciencia de Materiales de Madrid (ICMM-CSIC), E-28049 Madrid, Spain.<sup>4</sup> Department of Micro- and Nanosciences, Aalto University, Tietotie 3, FI-00076 Espoo, Finland 

### **Author contribution** 

X. G. conceived and supervised the project. R. T. carried out the device fabrication and characterization. X. C. helped on the data analysis. C. L., S. H., and L. G. assisted the device fabrication. D. T., A. C., Z. S., and J. Z. provided valuable discussions and improvements of manuscript. 

### **Conflict of interest** 

The authors declare that they have no conflict of interest . 

**Supplementary information** is available for this paper at https://doi.org/xx. 

### **References** 

1. Sun, C. _et al_ . Single-chip microprocessor that communicates directly using light. _Nature_ **528** , 534-538 (2015). 

2. Atabaki, A. H. _et al_ . Integrating photonics with silicon nanoelectronics for the next generation of systems on a chip. _Nature_ **556** , 349-354 (2018). 

18 

3. Pérez, D. _et al_ . Multipurpose silicon photonics signal processor core. _Nature Commun._ **8** , 636 (2017). 

4. Bogaerts, W. _et al_ . Programmable photonic circuits. _Nature_ **586** , 207-216 (2020). 

5. Dong, P. _et al_ . Monolithic silicon photonic integrated circuits for compact 100<sup>+</sup> Gb/s coherent optical receivers and transmitters. _IEEE J. Sel. Top. Quantum Electron._ **20** , 6100108 (2014). 

6. Moss, D. J. _et al_ . New CMOS-compatible platforms based on silicon nitride and Hydex for nonlinear optics. _Nat. Photonics_ **7** , 597-607 (2013). 

7. Blumenthal, D. J. _et al_ . Silicon nitride in silicon photonics. _Proc. IEEE_ **106** , 2209-2231 (2018). 

8. Desiatov, B. _et al_ . Ultra-low-loss integrated visible photonics using thin-film lithium niobate. _Optica_ **6** , 380-384 (2019). 

9. Vivien, L. _et al_ . 42 GHz p.i.n Germanium photodetector integrated in a silicon-on-insulator waveguide. _Opt. Express_ **17** , 6252-6257 (2009). 

10. Michel, J., Liu, J. F. & Kimerling, L. C. High-performance Ge-on-Si photodetectors. _Nat. Photonics_ **4** , 527-534 (2010). 

11. Liang, D. & Bowers, J. E. Recent progress in heterogeneous III-V-on-silicon photonic integration. _Light_ : _Adv. Manuf._ **2** , 59-83 (2021). 

12. Piels, M. _et al_ . Low-loss silicon nitride AWG demultiplexer heterogeneously integrated with hybrid III–V/silicon photodetectors. _J. Lightwave Technol._ **32** , 817-823 (2014). 

13. Gao, Y. _et al_ . High-speed van der Waals heterostructure tunneling photodiodes integrated on silicon nitride waveguides. _Optica_ **6** , 514-517 (2019). 

14. Yu, Q. H. _et al_ . Heterogeneous photodiodes on silicon nitride waveguides. _Opt. Express_ **28** , 14824-14831 (2020). 

19 

15. Gan, X. T. _et al_ . Chip-integrated ultrafast graphene photodetector with high responsivity. _Nat. Photonics_ **7** , 883-887 (2013). 

16. Youngblood, N. _et al_ . Waveguide-integrated black phosphorus photodetector with high responsivity and low dark current. _Nat. Photonics_ **9** , 247-252 (2015). 

17. Schuler, S. _et al_ . Controlled generation of a p-n junction in a waveguide integrated graphene photodetector. _Nano Lett._ **16** , 7107-7112 (2016). 

18. Bie, Y. Q. _et al_ . A MoTe2-based light-emitting diode and photodetector for silicon photonic integrated circuits. _Nat. Nanotechnol._ **12** , 1124-1129 (2017). 

19. Wu, Z. R. _et al_ . Integrating graphene/MoS2 Heterostructure with SiNx waveguide for visible light detection at 532 nm wavelength. _Phys. Status Solidi (RRL) – Rapid Res. Lett._ **13** , 1800338 (2019). 

20. Flöry, N. _et al_ . Waveguide-integrated van der Waals heterostructure photodetector at telecom wavelengths with high speed and high responsivity. _Nat. Nanotechnol._ **15** , 118-124 (2020). 

21. Gao, Y. _et al_ . High-performance chemical vapor deposited graphene-on-silicon nitride waveguide photodetectors. _Opt. Lett._ **43** , 1399-1402 (2018). 

22. Pospischil, A. _et al_ . CMOS-compatible graphene photodetector covering all optical communication bands. _Nat. Photonics_ **7** , 892-896 (2013). 

23. Gan, X. T. _et al_ . Controlled light-matter interaction in graphene electrooptic devices using nanophotonic cavities and waveguides. _IEEE J. Sel. Top. Quantum Electron._ **20** , 6000311 (2014). 

24. Lin, H. T. _et al_ . Chalcogenide glass-on-graphene photonics. _Nat. Photonics_ **11** , 798-805 (2017). 

25. Ma, P. _et al_ . Plasmonically enhanced graphene photodetector featuring 100 Gbit/s data reception, high responsivity, and compact size. _ACS Photonics_ **6** , 154-161 (2019). 

20 

26. Gonzalez Marin, J. F. _et al_ . MoS2 photodetectors integrated with photonic circuits. _npj 2D Mate. Appl._ **3** , 14 (2019). 

27. Deng, Y. X. _et al_ . Black phosphorus-monolayer MoS2 van der Waals heterojunction p-n diode. _ACS Nano_ **8** , 8292-8299 (2014). 

28. Gao, A. Y. _et al_ . Observation of ballistic avalanche phenomena in nanoscale vertical InSe/BP heterostructures. _Nat. Nanotechnol._ **14** , 217-222 (2019). 

29. Hu, S. Q. _et al_ . Gate-switchable photovoltaic effect in BP/MoTe2 van der Waals heterojunctions for self-driven logic optoelectronics. _Adv. Opt. Mater._ **9** , 2001802 (2021). 

30. Liu, Y. _et al_ . Approaching the Schottky–Mott limit in van der Waals metal– semiconductor junctions. _Nature_ **557** , 696-700 (2018). 

31. Kang, J. _et al_ . Band offsets and heterostructures of two-dimensional semiconductors. _Appl. Phys. Lett._ **102** , 012111 (2013). 

32. Xie, Y. _et al_ . Gate-tunable photodetection/voltaic device based on BP/MoTe2 heterostructure. _ACS Appl. Mater. Interfaces_ **11** , 14215-14221 (2019). 

33. Banwell, T. C. & Jayakumar, A. Exact analytical solution for current flow through diode with series resistance. _Electron. Lett._ **36** , 291-292 (2000). 

34. Baugher, B. W. H. _et al_ . Optoelectronic devices based on electrically tunable p–n diodes in a monolayer dichalcogenide. _Nat. Nanotechnol._ **9** , 262-267 (2014). 

35. Deckoff-Jones, S. _et al_ . Chalcogenide glass waveguide-integrated black phosphorus mid-infrared photodetectors. _J. Opt._ **20** , 044004 (2018). 

36. Chui, C. O., Okyay, A. K. & Saraswat, K. C. Effective dark current suppression with asymmetric MSM photodetectors in group IV semiconductors. _IEEE Photonics Technol. Lett._ **15** , 1585-1587 (2003). 

37. Mueller, T., Xia, F. N. & Avouris, P. Graphene photodetectors for high-speed optical communications. _Nat. Photonics_ **4** , 297-301 (2010). 

21 

38. Wang, X. M. _et al_ . High-responsivity graphene/silicon-heterostructure waveguide photodetectors. _Nat. Photonics_ **7** , 888-891 (2013). 

39. Ma, P. _et al_ . Fast MoTe2 waveguide photodetector with high sensitivity at telecommunication wavelengths. _ACS Photonics_ **5** , 1846-1852 (2018). 

40. Wood, J. D. _et al_ . Effective passivation of exfoliated black phosphorus transistors against ambient degradation. _Nano Lett._ **14** , 6964-6970 (2014). 

41. Pei, J. J. _et al_ . Producing air-stable monolayers of phosphorene and their defect engineering. _Nat. Commun._ **7** , 10450 (2016). 

42. Yin, Y. L. _et al_ . High-speed and high-responsivity hybrid silicon/black-phosphorus waveguide photodetectors at 2 µm. _Laser & Photonics Rev._ **13** , 1900032 (2019). 

43. Zhou, L. _et al_ . Large-area synthesis of high-quality uniform few-layer MoTe2. _J. Am. Chem. Soc._ **137** , 11892-11895 (2015). 

44. Xu, Y. J. _et al_ . Epitaxial nucleation and lateral growth of high-crystalline black phosphorus films on silicon. _Nat. Communications_ **11** , 1330 (2020). 

45. Wu, Z. H. _et al_ . Large-scale growth of few-layer two-dimensional black phosphorus. _Nat. Mater._ **20** , 1203-1209 (2021). 

22 

