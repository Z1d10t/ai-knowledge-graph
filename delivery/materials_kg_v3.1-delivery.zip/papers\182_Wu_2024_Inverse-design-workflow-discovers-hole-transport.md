# Inverse design workflow discovers hole-transport materials tailored for perovskite solar cells.

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Science |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 169 |
| 作者 | Jian-Chang Wu, Luca Torresi, Manman Hu, Patrick Reiser, Ji-Yun Zhang, Juan S. Rocha-Ortiz, Luyao Wang, Zhi-Qiang Xie et al. |
| DOI | 10.1126/science.ads0901 |
| 源文件 | 082_Wu_2024_Inverse-design-workflow-discovers-hole-transport.pdf |

---
# **Discovering One Molecule Out of a Million: Inverse Design of molecular hole transporting semiconductors tailored for perovskite solar cells** 

Jianchang Wu<sup>1,2*†</sup> , Luca Torresi<sup>3,4†</sup> , ManMan Hu<sup>5†</sup> , Patrick Reiser<sup>3,4†</sup> , Jiyun Zhang<sup>1,2</sup> , Juan S. Rocha-Ortiz<sup>1,2</sup> , Luyao Wang<sup>6*</sup> , Zhiqiang Xie<sup>2</sup> , Kaicheng Zhang<sup>2</sup> , Byung-wook Park<sup>5</sup> , Anastasia Barabash<sup>1,2</sup> , Yicheng Zhao<sup>1,2,7</sup> , Junsheng Luo<sup>2,7</sup> , Yunuo Wang<sup>2</sup> , Larry Lüer<sup>1,2</sup> , LinLong Deng<sup>6</sup> , Jens A. Hauch<sup>1,2</sup> , Sang Il Seok<sup>5</sup> , Pascal Friederich<sup>3,4*</sup> , Christoph J. Brabec<sup>1,2,8*</sup> 

1Forschungszentrum Jülich GmbH, Helmholtz-Institute Erlangen−Nürnberg (HI-ERN), 91058 Erlangen, Germany 

2Faculty of Engineering, Department of Material Science, Materials for Electronics and Energy Technology (i-MEET), Friedrich-Alexander-Universität Erlangen−Nürnberg (FAU), 91058 Erlangen, Germany 

3Institute of Nanotechnology, Karlsruhe Institute of Technology (KIT), 76131 Karlsruhe, Germany 

4Institute of Theoretical Informatics, Karlsruhe Institute of Technology (KIT), 76131 Karlsruhe, Germany 

5Department of Energy Engineering, School of Energy and Chemical Engineering, Ulsan National Institute of Science and Technology (UNIST), Ulsan 44919, Korea 

6State Key Lab for Physical Chemistry of Solid Surfaces, Department of Chemistry, College of Chemistry and Chemical Engineering, Pen-Tung Sah Institute of Micro-Nano Science and Technology, Xiamen University, Xiamen, 361005 China 

7National Key Laboratory of Electronic Films and Integrated Devices, School of Integrated Circuit Science and Engineering, University of Electronic Science and Technology of China, 611731 Chengdu, P. R. China 

8Zernike Institute for Advanced Materials, University of Groningen, Groningen 9747 AG, The Netherlands. 

> * **Corresponding authors.** E-mail: jianchang.wu@fau.de (J.W.); wangluyaoyz@gmail.com (L.W.); pascal.friederich@kit.edu (P.F.); christoph.brabec@fau.de (C.J.B.) †These authors contributed equally to this work. 

1 

## **Abstract** 

The inverse design of tailored organic molecules for specific optoelectronic devices of high complexity holds an enormous potential, but has not yet been realized<sup>1,2</sup> . The complexity and literally infinite diversity of conjugated molecular structures present both, an unprecedented opportunity for technological breakthroughs as well as an unseen optimization challenge. Current models rely on big data<sup>3,4</sup> , which do not exist for specialized research films. However, a hybrid computational and high throughput experimental screening workflow allowed us to train predictive models with as little as 149 molecules. We demonstrate a unique closed-loop workflow combining high throughput synthesis and Bayesian optimization that discovers new hole transporting materials with tailored properties for solar cell applications. A series of highperformance molecules were identified from minimal suggestions, achieving up to 26.23% (certified 25.88%) power conversion efficiency in perovskite solar cells. Our work paves the way for rapid, informed discovery in vast molecular libraries, revolutionizing material selection for complex devices. We believe that our approach can be generalized to other emerging fields and indeed accelerate the development of optoelectronic semiconductor devices in general. 

2 

## **Main** 

The evolution of organic semiconductors has historically been driven by empiricism. The design of hole-transporting materials (HTMs) for perovskite solar cells (PSCs), where experimentalists attempt to qualitatively recognize patterns in HTM structures to improve device performance, is no exception<sup>5-7</sup> . Nevertheless, this approach is challenged by various factors, including a lack of mechanistic understanding for new HTMs and the inherent limitations of human cognition in recognizing patterns in high-dimensional datasets. The rise of big-data techniques has the potential to revolutionize materials discovery. Machine learning is the study and construction of computer algorithms capable of extracting valuable insights and making predictions from vast sets of data<sup>4,8,9</sup> . It can learn from and adapt to new information without being explicitly programmed<sup>10</sup> . The ability of these algorithms to detect meaningful patterns has led to their adoption across various applications in sciences and technology, spanning from organic synthesis<sup>11,12</sup> , and material science<sup>1,13-15</sup> to fabrication process optimization<sup>16,17</sup> . 

However, the discovery of new materials with optimized properties for semiconducting device functionality<sup>17-19</sup> has not yet been achieved. Particularly in the field of emerging photovoltaics, it has not been possible yet to invert the relation between device performance and a material´s structure due to the complex correlation between the material’s structural features, the processing-dominated microstructure of composites and the relative impact of both on device performance. Prior efforts have focused primarily on using ML to optimize the fabrication process or to predict device performance and stability based on fabrication processes. The preliminary exploration has already been conducted in our laboratory, where Gaussian process (GP) regression was employed to model data from robotic device fabrication, enabling the analysis and prediction of device performance and stability<sup>20-23</sup> . The best parameter set and objective function could be quickly identified over the entire parameter space with a minimal number of samples. A similar approach was applied by Xu et al. to optimize the passivation materials for perovskite<sup>24</sup> . However, the training data is limited to the fabrication process or commercial materials, and as a result, it does not include the generation of new molecular structures. Assisting scientists in predicting and discovering new highperformance materials optimized according to the functional requirements of complex semiconductor devices is still a crucial challenge for ML-based materials discovery. Two recent studies have advanced the field by combining ML and organic synthesis. Bai et al. reported a successful case in which a gradient boosted tree regressor model, trained on data from 170 synthesized conjugated polymers, accurately predicted high-performance photocatalysts from a virtual database of 6354 candidates<sup>25</sup> . The trend obtained from the training data set was verified by experimental data on the newly synthesized polymers, leading to further refinement of the model. However, the insoluble characteristics of those polymers, while reducing the challenges of purification and enriching the database, have limited the broader applications of this material class. Gómez-Bombarelli et al. integrated virtual screening, cheminformatics, and organic synthesis to predict emitters for organic-light-emitting diodes<sup>18</sup> . At that time, the overall data volume and iteration number within the closed-loop were restricted by the number of synthesized molecules. Few general findings have emerged from these most recent studies, namely that the autonomous optimization algorithms require sufficiently large data volume but also data diversity, which necessitates the possibility of synthesizing structurally diverse molecules. Given the multidimensional nature of optimizing a chemical structure for device performance, the biggest challenge today is the generation of sufficiently large and consistent data sets to ensure the implementation of these algorithms 1,26,27. 

3 

To tackle these problems, we have developed a high-throughput (HT) organic synthesis platform, which can synthesize and purify more than 100 solution-processable small molecule semiconductors with varying structures and consistent quality over multiple synthesis campaigns within the shortest time<sup>28</sup> . This provided us with sufficient high-qualitative data for training an ML model coupling the structural features of the HTM to the performance of corresponding p-i-n PSCs. We sought to evaluate whether ML can be applied to the scale of data available to modern HT experiments and enable HTM discovery in multidimensional chemical space. To this end, we propose a workflow that couples automatic HT experiments, ML and validation through further HT experiments. These feedback loops will recommend new structures based on device results and allow for a closed optimization of the material to the target criteria of the solar cell. Due to the means of rapidly acquiring a substantial quantity of molecules, multiple iterations of experimental data based on organic conjugated molecules have been successfully carried out for the first time. The model, trained by 149 synthesized molecules, accurately predicted high-performance HTMs from a virtual database of 10<sup>6</sup> candidates. Due to the already considerable complexity of this study, we did not undertake an individual optimization of the device structure for each new HTM during the BO operation. Instead, device optimization was done for a series of HTMs that showed an initial power conversion efficiency (PCE) exceeding 20% after BO operation. These materials finally reached efficiencies of over 26%, highlighting the enormous potential of coupling material and device optimization in a combined workflow. We believe that the relevance of this work goes far beyond the discovery of optimized HTM for PSCs. 

## **Workflow** 

In this study, Suzuki coupling was used to synthesize new HTM molecules for perovskite solar cells. This reaction facilitates the combination of two distinct monomers, an A and a B type molecule, into a B-A-B type conjugated molecule. The workflow (Fig. 1) began with (i) the creation of a source database and the definition of sub-databases. The source database combines all commercially available monomers A and B compatible with Suzuki coupling bromines with boronic acids. The intermediate database, containing DFT calculations, consists of 13,000 randomly selected molecules from the source database. The synthetic database is then selected from the intermediate database according to specific rules (Kennard-Stone for the initial database and Bayesian for iteration database). The initial pre-training was executed for representative monomers (33*13) that were selected to ensure the broadest coverage of chemical features; (ii) DFT calculation of robust chemical descriptors were performed for each molecule; (iii) followed by high-throughput organic synthesis in 4 campaigns, purification and characterization, initially creating a database of 101 molecules (iv) processing & characterizing p-i-n perovskite devices from the 101 molecules (v) the application of machine learning based on calculated descriptors and experimental data for predicting the performance of each new molecule within the virtual compound library. (vi) subsequently, the model was validated by synthesizing 48 molecules suggested by the BO in two further campaigns from a space covering 50 A and 19 B molecules. This process can be iteratively repeated to explore further molecules. Finally, the set of structure-property relationships connecting device performance to molecular properties was built and analyzed by Multi-Task Gaussian process regressors (MTGPR), combining data from HTM films as well as HTM/perovskite interface characterization. Based on those rules, molecular design principles were established, leading to the iterative refinement of the molecular structure. 

## **Initial library generation -- synthesis and device manufacturing** 

As the first step, the formulation of an in-silico library encompassing 10<sup>6</sup> HTMs utilizing the RDKit package (see section S3 supplementary materials for details) is described. To amass a 

4 

substantial dataset, we set two primary criteria for monomer selection: 1. reacting units (Br for monomer A, boronic acid derivatives for monomer B) attached to aromatic moieties; 2. monomer B is restricted to possessing only one reacting unit to prevent polymerization. Apart from this, no other selection criteria or “intuitive” selection rules were applied. Following these criteria, 1132 monomers A and 850 monomers B were selected. Subsequently, a script based on RDKit was employed to annotate the monomers across seven aspects, encompassing types of conjugated frameworks, substituent types, electronic effects, and steric effects (Fig. 2A). The categorization of HTMs along these seven aspects is aligned to the current state of understanding how HTMs impact perovskite device performance<sup>7,29-31</sup> . A representative library of monomers (33 A and 13 B) was then chosen from this space using the Kennard-Stone algorithm (Fig. 2B, 2C and 2D)<sup>32</sup> . This sampling method choice ensures that monomers are selected from uniform regions of the feature space. To guarantee comparability with the reported molecules, a few monomers with good reported performance were manually added. To make more efficient use of the selected monomers and compare the differences in their structure-performance correlation, we refrained from simple pairings. Instead, we divided the monomers into two groups for synthesis: A1-A30 combined with B1-B2, and A30-A33 with B2-B13. A comprehensive description of the synthesis, purification, and pre-characterization was recently published<sup>28</sup> . That routine is an essential pillar for the next step – the autonomous material discovery for optimized device performance – which we report in this work. In essence, we adopted a semi-automated synthesis platform where a microwave reactor accelerated the synthetic process. Subsequently, the synthesized molecules underwent a twostep purification involving fast filtration and recrystallization. Our HT workflow features the generation of 24 molecules within a week, including a most complete data acquisition. To ensure immediate access to the identified promising candidates and to assess the potential impact of synthesis and purification methods on material performance, the batch-to-batch reproducibility of the platform was verified by characterizing 10 representative molecules from different batches, including nuclear magnetic resonance (NMR), mass spectrometry, optoelectronic properties, and device performance (see section S2 in the supplementary materials). Minor fluctuations were observed between the different batches, guaranteeing that the reproducibility of our experimental data set does not limit the functionality of the ML algorithms. Such high reproducibility is further relevant for FAIR-guided data libraries, allowing other scientists to reproduce our experiments. 

These synthesized molecules were employed as dopant-free HTMs in p-i-n structured PSC devices, where the function of the HTM goes beyond merely extracting and transporting holes; it plays a crucial role in influencing the crystal growth of the perovskite<sup>29,33,34</sup> . Here, perovskite is used as an absorber layer, ([6,6]-phenyl-C61-butyric acid methyl ester (PCBM)/ bathocuproine as electron transporting layer and Ag as the top electrode. The resulting current density-voltage ( _JV_ ) curve is depicted in fig. S9. Reference devices based on Poly(triarylamine) (PTAA), a state-of-the-art commercial HTM for p-i-n PSCs, were employed to calibrate the variations within each batch of devices. Furthermore, 6-12 devices were prepared per molecule to provide sufficient statistics on the data relevance. The average value was used as the experimental data point. To further ensure the validity of the data, reference devices were extensively optimized to minimize inter-batch differences. The device performance parameters of each novel molecule were normalized to the reference device with a PTAA hole transport layer before entering them into the ML model. Additionally, throughout the iterative process, the normalization to PTAA allowed us to adapt the perovskite recipe throughout the experimental campaign to achieve better reproducibility at the highest performance. 

The heatmap of the PCEs for all synthesized molecules in Fig. 2E uncovers the first interesting trends. The PCEs of molecules AxB1 are generally higher than AxB2. Similarly, while keeping the monomer B constant, almost all molecules based on A30 as a central building 

5 

block demonstrate the best performance. This signifies the substantial advantage of B1 and A30, triphenylamine (TPA) derivatives, in HTMs. However, there are notable exceptions: 1. A30B2 > A30B1, 2. A31B12 > A30B12, 3. A31B13 > A30B13. The first and second points share a commonality - the monomers B1 and B12 have a TPA structure. This suggests that excess TPA or its placement on the molecule’s periphery may be disadvantageous. As for the third point, it appears challenging to explain it from chemical intuition alone. Utilizing machine learning is necessary to provide further insights and identify underlying mechanisms. 

## **Machine learning models and feature engineering** 

To better understand structure-property relations in the observed data, we constructed an ML model that correlates representative molecular descriptors to the PCEs of the devices. In contrast to categorical labels such as A and B, continuous molecular descriptors can be used to provide an ML readable description that can integrate unseen A/B fragments into the same ontology. Typically, this process requires feature engineering to find meaningful descriptors for the problem at hand. To this end, a large virtual molecular library was generated by evaluating the expected reaction products from a set of A and B building blocks with the RDKit software package. Subsequently, the 3D geometry of the molecules was optimized using a conformer search in CREST and the semiempirical density functional tight-binding program xTB<sup>25,35</sup> , followed by the calculation of molecular descriptors using DFT in TURBOMOLE (see section S3 in the supplementary materials for details). For the ML model, we sought a set of descriptors that adequately capture device differences without relying on a specific hypothesis. To achieve this, we chose a combination of simple molecular statistics, such as the number of atom species, aromatic bonds, and specific functional groups, with theoretically computed features such as the log solubility, molecular orbital energies, dipole moment and geometric properties such as rotational constants. A list of all features with explanations can be found in the supplementary materials. In Fig. 3A, we show the distribution of the most important features, such as the DFT highest occupied molecular orbital (HOMO) level, which should relate to the device performance in a step-function type from basic physical considerations. For model selection, we trained different ML models on a random 10-fold cross-validation of the 101 experimental molecular data points. Tested ML models include random forest regression, linear regression, neural networks, Gaussian process regression (GP), and kernel-ridge regression (Fig. 3B). All simple models perform equally well. For Bayesian optimization we chose the Gaussian processes as a surrogate model since it offers an uncertainty measure required in many acquisition strategies. The prediction accuracy of all device labels beyond PCE for the GP model is shown in Fig. 3C. A more detailed analysis of the influence of features and what physical insights can be learned from the ML models is discussed in the section _model analysis_ . 

## **Experimental validation of the model** 

To demonstrate that the ML model can indeed discover new molecules by predicting viable new organic semiconductors for hole extraction, we conducted two iterations of closed-loop materials optimization. This entails the identification of potential candidates via the ML surrogate model and Bayesian selection criteria, automatic synthesis of candidates, and finally, device characterization used to update the model. In the first iteration, 24 new molecules (blue triangles in Fig. 4A) were synthesized in a single batch and characterized to validate the previously obtained model. New building blocks (A525-pyridinone, A772-dicyanovinyl) and asymmetric structural motifs were considered to enrich the diversity of molecular structures in the database.  The monomer database for synthesis was expanded from 33*13 to 50*19, mainly through machine learning recommendations, supplemented by accessibility, derivatives exhibiting high-performance structures in the initial database, and random acquisition. 

6 

The target for optimization was the device PCE averaged over 12 devices with an upper confidence bound (UCB) acquisition function, which is supposed to identify high-performance HTMs for further exploration. We found that the new series of materials resulted in device efficiencies that were generally higher than those of the materials in the initial database, demonstrating the significant advantage of machine learning over random sampling or grid search approaches when operated in the “exploit” mode. Among them, 6 molecules exceeded the PTAA-based device reference. We also observed outliers to the predictions (samples 110 and 120), which were separately examined (see section S4 in the supplementary materials) and could be explained in terms of impurities, unfavorable wetting behavior or limited solubility. 

For the second iteration, we increased the explorative character of the UCB in the model 12,23. Subsequently, molecules 126-149, recommended by ML, were synthesized (Fig. 4). Although no new champion HTM was found, the average PCE of predictions was still very high, comparable to the first iteration. This is a very strong affirmation of the potential and viability of our workflow, considering the multitude of factors governing the performance of perovskite devices. Device performance is only partially limited by the HTM, as many other layers, including the electron transporting layer or the electrodes as well as the quality and defect density of the absorbing layer, are known to reduce performance. Moreover, the physical models behind these losses cover multiple chemical and physical phenomena, including (i) inherently limiting material properties, (ii) generation, recombination and transport dynamics in semiconductors, (iii) the energetics of interface formation and the corresponding potential landscape in thin film devices, (iv) thin film microstructure formation (v) the device architecture itself and (vi) the macroscopic film homogeneity. All of that is described in the ontology of perovskite devices which has been recently uploaded on Matportal<sup>36</sup> . Under these aspects, we were surprised to see the spread in efficiency among the various HTMs within our library. 

Clearly, we expected a threshold type behavior for HTM materials having a too small bandgap or a too small or even negative offset in the HOMO / LUMO potentials vs. the valence band maximum (VBM) and conduction band minimum (CBM) of the perovskite. However, the broad variation of representative performance values ranging from 15% to 21% postulates that the nature of the HTM molecules is capable of determining the performance of perovskite devices beyond our expectations. It's worth noting that to obtain accurate trends, the performance of these molecules was characterized under uniform device conditions, with the standard device optimized based on PTAA. When exploring the limit of a material's performance, device parameters need to be adjusted according to the material's characteristics. Based on this, three promising molecules were selected for individualized device performance optimization. We adopted a bottom-up optimization approach, from HTM to perovskite to electron transporting material (ETM) (see section S5 in the supplementary materials). Under these efforts, the device efficiency improved by 10% - 20%, reaching performance levels of 23.5% - 24.3% with FF of 87%. Considering that new conditions might affect the original ranking of materials, thereby influencing ML predictions, we selected 20 molecules from the database to observe the impact of individualized optimization on trends. The results showed that it slightly affected the open-circuit voltage ( _Voc_ ) and fill factor (FF) trends, but the impact on the PCE trend was negligible (fig. S30). To further fully explore the potential of those materials on _Voc_ and _Jsc_ , we further refine the perovskite formulation and ETM to better align with the properties of those HTMs (Fig. 4E). As a result, we observed a significant improvement in the performance, achieving a _Voc_ of 1.195 V, a _Jsc_ of 26.01 mA/cm<sup>2</sup> , a FF of 84%. These enhancements culminated a PCE of 26.23% (certified 25.88%) alongside an excellent operational stability, maintain 80% of the initial performance (T80) for over 1000 h. Finding performance values as high as 26.23% for a process, in which the state-of-the-art material MeO-2PACz is reaching an efficiency of about 24% (Supplementary Fig. 32-34), 

7 

demonstrates the power of this approach. Moreover, it outlines the next major steps for the combined material and device acceleration strategy – that has to be walking away from singleobjective optimization tasks to multi-objective optimization tasks. In terms of our work, we see the next major challenge as the simultaneous optimization of the efficiency and operating life of perovskite solar cells as a function of the HTM. 

## **Model analysis** 

To obtain interpretable insight into what our ML models have learned and to identify physical parameters that influence the device performance, we added further experimental material properties and extracted feature importance information from the trained ML models (Fig. 5). Since the HOMO position is relevant for charge extraction from physical considerations, the HOMO level position is expected to be aligned between the electrode and the perovskite, and is identified as an important feature in Fig. 5A<sup>37-39</sup> . In order to identify more decisive features, we conducted a feature analysis using the Recursive Feature Machine (RFM), a kernel machine that recursively learns features importance<sup>40</sup> . As in Radhakrishnan _et al._ , we used a generalization of the Laplacian kernel that incorporates a learnable feature matrix _M_ to compute the Mahalanobis distance between data points<sup>41</sup> . The _R_<sup>_2_</sup> value on the test data of this method was evaluated to be approximately 0.5. On 100 randomized train-test splits, we ranked the largest feature-matrix values of the trained Kernel methods in Fig. 5C. The features, the RFM model focuses on, are purity, HOMO level, HOMO/LUMO gap, and the presence of tertiary amines. Besides the electronic properties of the molecule, the purity of the synthesis product is the most crucial descriptor for the final device performance. This corroborates that impurities typically reduce overall performance due to potential diffusion and the introduction of traps or unwanted doping in adjacent layers. Other important factors are the presence of nitrogen atoms, which reflects the observations mentioned above in Fig. 2F, dipole moment, molecular shape, and to a lesser degree composition and overall bond type or conjugation. 

Additional experimental input from extended characterization was generated to increase the diversity of input/output parameters, including wettability, photoluminescence quantum yield (PLQY), and time-resolved photoluminescence (TRPL) (see section S1 and S4 supplementary materials for details). Since these measurements are often only available after producing the device, we added them as ulterior outputs and trained a multi-task GP model (MTGPR) on the joined target space. The task covariance matrix represents potential correlations that the MTGPR model uses with a kernel function shared among tasks (Fig. 5C). It shows the expected correlation between _Voc_ , _Jsc_ , and FF with the PCE. Furthermore, to a lesser extent, it also indicates correlations between PCE and additional labels, e.g. with TRPL, which would be consistent with current reports<sup>42-45</sup> . However, the correlation is not as pronounced as expected and does not lead to a statistically significant improvement in PCE prediction accuracy when the additional labels are fed to the multi-task model. 

Since the dataset is not strictly i.i.d., we additionally evaluated the generalizability of our ML models in a leave-one-out cross-validation scheme. We iteratively picked each single molecule as a test set and removed the same A and B building blocks from the training set, in order to make sure that the model cannot produce its predictions by simply learning to recognize the molecular fragments. We trained GP and RF models and evaluated their test error with this validation scheme, reaching in both settings an _R_<sup>_2_</sup> value of approximately 0.3. Although the test error increased, the model could still generalize to unseen data points. The most relevant features in this setup remained similar to Fig. 5A in the importance ranking: The presence of tertiary amines, HOMO/LUMO gap, and HOMO level, but also dipole moment and the presence of biphenyl substructures. We can confirm that the model learned to predict the perovskite device performance for unseen HTM molecules, as required for materials discovery. 

8 

To have a more interpretable model, we trained a linear regression model applying first both a forward and a backward sequential feature selection, which is a family of greedy search algorithms used to reduce the feature space to a lower subset. We evaluated the resulting models with the Bayesian information criterion (BIC) to select the best-performing set of features we had learned so far. Our selected model uses eight features (aromatic bonds and atoms counts, logP, count of nitrogen atoms, purity, dipole, rotation constant c, and the presence of tertiary amines) to predict the PCE, achieving an _R_<sup>_2_</sup> of approximately 0.46 (Fig. 5D), which is higher than any other model we found. 

Finally, in order to provide chemists and material scientists with a clearer understanding of our findings, enabling them to delve deeper into molecular design based on our finds, here, we employed chemical language to elucidate the results of ML (Fig. 5B). The feature importance plot distinctly highlights the significance of HOMO and tertiary amine in the model. The significance of HOMO in molecular design has been widely recognized due to its decisive role in charge extraction at interfaces. However, tertiary amine is often overlooked. Upon examining all synthesized molecules, we discovered that tertiary amine often refers to triphenylamine (TPA), whose low ionization potential contributes significantly to the molecule's HOMO<sup>6</sup> . Based on these two descriptors, all synthesized molecules can be categorized into three types: Type I, TPA-absent molecules, referred to as AxBy; Type II, with TPA on the periphery, typically AxB1 structures; and Type III, with TPA at the molecular center, typically A30By structures. Under this classification, a pattern emerges in HOMO and PCE: (I) HOMO ranges from 5.1-6.1 eV with 5%-14% PCE; (II) HOMO from 4.3-5.2 eV with 13-20% PCE;  (III) HOMO from 4.9-5.7 eV with 15-21% PCE. This classification narrows the candidate pool from 9.6 x 10<sup>5</sup> to 5.8 x 10<sup>3</sup> molecules. Once the A position is established as TPA, molecular properties are primarily influenced by the B-position group. The feature importance analysis also highlights the roles of the HOMO/LUMO gap and dipole moment. The combination of TPA and acceptors ensures an appropriate HOMO-LUMO bandgap, with heteroatoms in acceptors also contributing to perovskite passivation. This combination further reduces candidates from 5.8 x 10<sup>3</sup> to 4.6 x 10<sup>2</sup> . To facilitate rapid selection by chemists without DFT calculations, we used the Topological Polar Surface Area (TPSA) as a rough indicator of the building block's polarity and electron-withdrawing capacity, readily searchable via PubChem. Finally, the performance of molecules should be finely tuned based on TPA+acceptors, such as the edge-on orientation positively impacting passivation and charge transport. In the combination of TPA derivative and 5 B groups (fig. S22), device performance is systematically enhanced through fine-tuning of the B-position group and TPA structure. For instance, groups like A770, with slightly weaker symmetry, tend to exhibit better device performance. This finetuning can reduce the number of candidate molecules from 10<sup>2</sup> to 10<sup>1</sup> , a quantity that is well within the realm of high-throughput synthesis. We summarize by highlighting the two-fold strategy learned from training an ML model to be capable of predicting such a complex property as a device performance based on molecular structure input. Such model can be further explored in a two-fold strategy. On the one hand, it can be used in autonomous workflows to identify and predict further novel molecules. On the other hand, synthetic researchers can use that model to predict perovskite device performance for new molecular designs within a certain chemical space. That can be further guided and supported by the set of design rules extracted that are elucidated from a fully trained model. 

## **Conclusion** 

We believe this work transcends the current strategy of discovering new materials focused solely on one specific property. Including organic synthesis in self-driven autonomous labs in combination with autonomous device optimization lines is a huge step towards fully autonomous materials discovery in many application areas. Here, for the first time, we 

9 

demonstrate a unique workflow that has the power to discover functional materials optimized for highly complex applications such as photovoltaic devices. A significant challenge we solved was to build predictive models based on molecular descriptors, allowing us to link the structure of a material to the performance of a highly complex device such as a solar cell. This is particularly important when it comes to device processing and optimization, which necessitates a nuanced understanding of both the material and the process involved. This aspect can constitute a breakthrough for overcoming the structure–process–property nexus for disordered materials. 

Looking forward, we aim to integrate material discovery and device optimization into a seamless, closed-loop process. Achieving this will require a concerted effort in interdisciplinary research, combining insights from material science, engineering, and advanced computational techniques to create a synergistic workflow. This integrated approach is the most promising strategy to revolutionize the way we develop and optimize materials for cutting-edge technological applications. 

## **References** 

- 1 Merchant, A. _et al._ Scaling deep learning for materials discovery. _Nature_ **624** , 80-85 (2023). 2 Rao, Z. _et al._ Machine learning–enabled high-entropy alloy discovery. _Science_ **378** , 78-85 (2022). 

- 3 Hueffel, J. A. _et al._ Accelerated dinuclear palladium catalyst identification through unsupervised machine learning. _Science_ **374** , 1134-1140 (2021). 

- 4 Butler, K. T., Davies, D. W., Cartwright, H., Isayev, O. & Walsh, A. Machine learning for molecular and materials science. _Nature_ **559** , 547-555 (2018). 

- 5 Meng, D. _et al._ Configurable Organic Charge Carriers toward Stable Perovskite Photovoltaics. _Chem. Rev._ **122** , 14954-14986 (2022). 

- 6 Wang, J., Liu, K., Ma, L. & Zhan, X. Triarylamine: Versatile Platform for Organic, DyeSensitized, and Perovskite Solar Cells. _Chem. Rev._ **116** , 14675-14725 (2016). 

- 7 Farokhi, A., Shahroosvand, H., Monache, G. D., Pilkington, M. & Nazeeruddin, M. K. The evolution of triphenylamine hole transport materials for efficient perovskite solar cells. _Chem. Soc. Rev._ **51** , 5974-6064 (2022). 

- 8 Jordan, M. I. & Mitchell, T. M. Machine learning: Trends, perspectives, and prospects. _Science_ **349** , 255-260 (2015). 

- 9 Vamathevan, J. _et al._ Applications of machine learning in drug discovery and development. _Nat. Rev. Drug Discov._ **18** , 463-477 (2019). 

- 10 Hastie, T., Tibshirani, R. & Friedman, J. H. _The elements of statistical learning: data mining, inference, and prediction_ .  (Springer, 2009). 

- 11 Ahneman, D. T., Estrada, J. G., Lin, S., Dreher, S. D. & Doyle, A. G. Predicting reaction performance in C-N cross-coupling using machine learning. _Science_ **360** , 186-190 (2018). 

- 12 Shields, B. J. _et al._ Bayesian reaction optimization as a tool for chemical synthesis. _Nature_ **590** , 89-96 (2021). 

- 13 Mou, T. _et al._ Bridging the complexity gap in computational heterogeneous catalysis with machine learning. _Nat. Catal._ **6** , 122-136 (2023). 

- 14 Maffettone, P. M. _et al._ Crystallography companion agent for high-throughput materials discovery. _Nat. Comput. Sci._ **1** , 290-297 (2021). 

- 15 Liu, Y. _et al._ Experimental discovery of structure–property relationships in ferroelectric materials via active learning. _Nat. Mach. Intell._ **4** , 341-350 (2022). 

- 16 Ozer, E. _et al._ A hardwired machine learning processing engine fabricated with submicron metal-oxide thin-film transistors on a flexible substrate. _Nat. Electron._ **3** , 419-425 (2020). 

- 17 Yang, H. _et al._ Automatic strain sensor design via active learning and data augmentation for soft machines. _Nat. Mach. Intell._ **4** , 84-94 (2022). 

10 

- 18 Gómez-Bombarelli, R. _et al._ Design of efficient molecular organic light-emitting diodes by a high-throughput virtual screening and experimental approach. _Nat. Mater._ **15** , 1120-1127 (2016). 

- 19 Wu, T. C. _et al._ A Materials Acceleration Platform for Organic Laser Discovery. _Adv. Mater._ **35** , 2207070 (2023). 

- 20 Langner, S. _et al._ Beyond Ternary OPV: High-Throughput Experimentation and Self-Driving Laboratories Optimize Multicomponent Systems. _Adv. Mater._ **32** , 1907801 (2020). 

- 21 Du, X. _et al._ Elucidating the Full Potential of OPV Materials Utilizing a High-Throughput Robot-Based Platform and Machine Learning. _Joule_ **5** , 495-506 (2021). 

- 22 Zhang, J. _et al._ Optimizing Perovskite Thin-Film Parameter Spaces with Machine LearningGuided Robotic Platform for High-Performance Perovskite Solar Cells. _Adv. Energy Mater._ **13** , 2302594 (2023). 

- 23 Osterrieder, T. _et al._ Autonomous optimization of an organic solar cell in a 4-dimensional parameter space. _Energy Environ. Sci._ (2023). 

- 24 Xu, J. _et al._ Anion optimization for bifunctional surface passivation in perovskite solar cells. _Nat. Mater._ **22** , 1507-1514 (2023). 

- 25 Bai, Y. _et al._ Accelerated Discovery of Organic Polymer Photocatalysts for Hydrogen Evolution from Water through the Integration of Experiment and Theory. _J. Am. Chem. Soc._ **141** , 9063-9071 (2019). 

- 26 Lu, H. _et al._ Machine learning-aided engineering of hydrolases for PET depolymerization. _Nature_ **604** , 662-667 (2022). 

- 27 Seifermann, M., Reiser, P., Friederich, P. & Levkin, P. A. High-Throughput Synthesis and Machine Learning Assisted Design of Photodegradable Hydrogels. _Small Methods_ **7** , 2300553 (2023). 

- 28 Wu, J. _et al._ Integrated System Built for Small-Molecule Semiconductors via HighThroughput Approaches. _J. Am. Chem. Soc._ **145** , 16517-16525 (2023). 

- 29 Yan, P., Yang, D., Wang, H., Yang, S. & Ge, Z. Recent advances in dopant-free organic holetransporting materials for efficient, stable and low-cost perovskite solar cells. _Energy Environ. Sci._ **15** , 3630-3669 (2022). 

- 30 Jeong, M. _et al._ Large-area perovskite solar cells employing spiro-Naph hole transport material. _Nat. Photon._ **16** , 119-125 (2022). 

- 31 Yu, X. _et al._ Green-solvent Processable Dopant-free Hole Transporting Materials for Inverted Perovskite Solar Cells. _Angew. Chem. Int. Ed._ **62** , e202218752 (2023). 

- 32 Zahrt, A. F. _et al._ Prediction of higher-selectivity catalysts by computer-driven workflow and machine learning. _Science_ **363** , eaau5631 (2019). 

- 33 Yan, W. _et al._ Hole-Transporting Materials in Inverted Planar Perovskite Solar Cells. _Adv. Energy Mater._ **6** , 1600474 (2016). 

- 34 Urieta-Mora, J., García-Benito, I., Molina-Ontoria, A. & Martín, N. Hole transporting materials for perovskite solar cells: a chemical approach. _Chem. Soc. Rev._ **47** , 8541-8571 (2018). 

- 35 Grimme, S. & Bannwarth, C. Ultra-fast computation of electronic spectra for large systems by tight-binding based simplified Tamm-Dancoff approximation (sTDA-xTB). _J. Chem. Phys._ **145** , 054103 (2016). 

- 36 _MatPortal, Thin-film solar cell ontology. https://matportal.org/ontologies/TFSCO_ <u>.</u> 

- 37 Jeon, N. J. _et al._ o-Methoxy Substituents in Spiro-OMeTAD for Efficient Inorganic–Organic Hybrid Perovskite Solar Cells. _J. Am. Chem. Soc._ **136** , 7837-7840 (2014). 

- 38 Jeon, N. J. _et al._ A fluorene-terminated hole-transporting material for highly efficient and stable perovskite solar cells. _Nat. Energy._ **3** , 682-689 (2018). 

- 39 Jeong, M. _et al._ Stable perovskite solar cells with efficiency exceeding 24.8% and 0.3-V voltage loss. _Science_ **369** , 1615-1620 (2020). 

- 40 Adityanarayanan Radhakrishnan, D. B., Parthe Pandit, Mikhail Belkin. Mechanism of feature learning in deep fully connected networks and kernel machines that recursively learn features. _arXiv_ **9** (2023). 

- 41 Bellet, A., Habrard, A. & Sebban, M. _Metric learning_ . Vol. 9 (Springer Nature, 2015). 

11 

- 42 Zhao, Y. _et al._ A bilayer conducting polymer structure for planar perovskite solar cells with over 1,400 hours operational stability at elevated temperatures. _Nat. Energy._ **7** , 144-152 (2022). 

- 43 Zhang, T. _et al._ Ion-modulated radical doping of spiro-OMeTAD for more efficient and stable perovskite solar cells. _Science_ **377** , 495-501 (2022). 

- 44 Li, X. _et al._ Constructing heterojunctions by surface sulfidation for efficient inverted perovskite solar cells. _Science_ **375** , 434-437 (2022). 

- 45 Bu, T. _et al._ Lead halide–templated crystallization of methylamine-free perovskite for efficient photovoltaic modules. _Science_ **372** , 1327-1332 (2021). 

## **Legends of the main text figures** 

**Fig. 1** **_._ Approach overview. I. Database.** There are three kinds of databases. 1. Source database: the virtual combination of two types of commercial monomers using Suzuki coupling rule. 2. Intermediate database: Randomly selected molecules from the source database for DFT calculations. 3. Synthesized database: Synthesized molecular collections in this study, including an initial database for model training and two iteration databases for model validation and correction. **II. DFT calculation** . Descriptors of molecules in the intermediate database are calculated via DFT. **III. HT Synthesis and characterization** . Molecules in the synthesized database are synthesized, purified, and characterized through our in-house high-throughput platform. **IV. Device and semi-device data** . The synthesized molecules are used as HTM in PSCs and characterized in devices and semi-devices (HTM/active layer). **V. Model training and iteration** . The model is trained based on HTM descriptors and device parameters. The new promising molecules are predicted, synthesized and experimentally measured and fed back to the database. The iteration is repeated until the discovery of the best HTM. **Molecular iteration** . Material design principles are summarized and analyzed. 

**Fig. 2. Generation of the initial library.** ( **A** ) Monomer descriptor calculation from different perspectives. I. Aromatic ring species; II. Conjugate length; III. Substituent species; IV. Active group; V. flexible and rigid units; VI. Electronic effect; VII. Spatial effect. ( **B** ) Monomer subset selection (blue ball) with the Kennard-Stone algorithm from a commercial monomer library (square). ( **C** ) and ( **D** ) Selected monomers for the initial database. ( **E** ) Color map of PCEs for HTMs in the initial library. It consists of two parts: the combination of A1-A30 with B1-B2 (upper part) and A30-A33 with B2-B13 (lower part). In the upper part, the serial number of each monomer A is filled in the cell. ( **F** ) In-silico library for HTM descriptors used for initial library selection. 

**Fig. 3. Model training based on experimental data and in silico descriptors.** ( **A** ) Distribution of important features from the dataset used in the model training. ( **B** ) Comparison of the validation error of different models to compare their performance. ( **C** ) The prediction accuracy of the Gaussian Process (GP) for all device labels, including maximum PCE, _Jsc_ , _Voc_ and FF. 

**Fig. 4. New synthesized molecules and experimental data for iteration.** ( **A** ) Predicted properties of the molecular library. ( **B** ) Selected molecules from the database for iterations based on calculated properties, where marker size is proportional to device performance. Blue triangles represent the molecules in the first iteration and the orange ones in the second. ( **C** ) Molecular fragments used of iterative molecules. To clearly visualize the structure of the final molecules, molecular fragments are used to represent the monomers. ( **D** ) Device performance of molecules for the initial dataset and the iterations. The PCE of the samples is the average performance normalized to the reference devices (based on PTAA) of the corresponding batch. ( **E** ) Further personalized optimization of the devices based on representative molecules. Blue: standardized condition. Red: personalized condition based on molecular properties. 

**Fig. 5. Model analysis.** ( **A** ) Feature importance of the RFM evaluated from the M matrix coefficients. ( **B** ) Molecular design rules guided by machine learning results. ( **C** ) Covariance matrix of the multi- 

12 

label GPR for PCE and additional device characteristics. t1perov and t2perov represent the carrier lifetimes of two distinct recombination processes within the perovskite layer when the excitation laser is incident from the side of the perovskite. t1glass and t2glass correspond to data that laser incident from the glass side. _DV0_ and _DJ0_ are the derivatives of the _J-V_ curve in _V_ = 0 and _J_ = 0. ( **D** ) Linear model test predictions for the leave-one-out CV scheme. 

## **Methods** 

## **Materials** 

Reagents and solvents for organic synthesis were purchased from commercial suppliers (Fluorochem, Sigma-Aldrich, BLD pharm, TCI Europe, Apollo, Alfa Aesar) and used with no further purification unless otherwise noted. Thin layer chromatography (TLC) plates were purchased from Sigma-Aldrich. Chemicals for perovskite solar cells: Formamidinium iodide (FAI), methylamonium bromide (MABr) and methylamonium chloride (MACl) were purchased from Greatcell Solar Materials. lead iodide (PbI2), Lead bromide (PbBr2) and Lead chloride (PbCl2) were purchased from TCI chemicals. Cesium iodide (CsI), _N,N_ - Dimethylformamide (DMF, anhydrous), isopropyl alcohol, dimethyl sulfoxide (DMSO, anhydrous), and chlorobenzene were purchased from Sigma-Aldrich. 

## **High through-put synthesis** 

The amount of theoretical products is 0.2 mmol for most reactions, except for some products with too large or too small molecular weight. We set the weights of theoretical products around 100 mg. The stock solution-1 dissolving Pd(OAc)2 (0.01 mmol) and SPhos (0.02 mmol) in dioxane, stock solution-2 of 3 M K3PO4 in H2O, were firstly prepared and degassed with N2. Then monomer A (0.2 mmol, 1.0 equiv.) and monomer B (0.8 mmol, 4.0 equiv.) were added into vials and sealed under the inert atmosphere. 3 ml stock solution-1 and 0.5 ml stock solution-2 were injected into vials with a syringe through the septum. Before the start of the heating program in the microwave reactor, we set a pre-stirring for 5 min to dissolve the starting materials. Then the reaction temperature was raised to 90 °C and kept for 30 min. Here, we set the power of the microwave limit not to exceed 100 W. The reaction mixtures were cooled to room temperature. Aqueous layers were removed manually with pipettes. The remaining organic layers were transferred into the SEP tube of the vacuum manifold. After filtering, the SEP was rinsed 5 times with 2 ml THF. The solvents were removed by a sample concentrator, and the residues were purified by recrystallization with optimized mixed solvent and recrystallization again if needed by encoding. 

## **Device fabrication** 

Perovskite solar cell devices having the structure of ITO/HTM/perovskite/PCBM/BCP/Ag were fabricated, where the Indium tin oxide (ITO) was the bottom layer. The patterned indium tin oxide (ITO) glass substrates are cleaned for 15 minutes with deionized water, Acetone, and Isopropanol in an ultrasonic bath. The layers are then dried well before treated in an UV-ozone cleaner for 15 min. After UV-ozone treatment, the ITO substrates immediately are transferred to N2 filled glovebox. HTM (2 mg/ml in chlorobenzene) was spin-coated on the ITO substrate at 5000 rpm for 30s and then annealed at 100  C for 10 min. Throughout the workflow iterations, we continuously updated the perovskite recipe. The article involves two specific recipes. Recipe 1 is 1.5 M (CsI)0.05(MAPbBr3)0.17(FAPbI3)0.83, and recipe 2 is 1.45M 

13 

(CsI)0.17(FAPbI3)0.83. For recipe 1 (CsMAFA), PbI2 (1.5M) and PbBr2 (1.5M) are dissolved in a mixture of anhydrous Dimethylformamide (DMF): Dimethyl sulfoxide (DMSO) (4:1 volume ratio), respectively, and then added to formamidinium iodide (1.09:1 molar ratio) and methylammonium bromide (1.09:1 molar ratio) powders, respectively, to obtain FAPbI3 and MAPbBr3 solutions. These two solutions are then mixed in a 17:83 volume ratio. Finally, the cesium cation is added from a 1.5 M CsI solution in DMSO in a 5:95 volume ratio. For recipe 2 (CsFA), PbI2 (668.4 mg), FAI (207.0 mg), CsI (64.0 mg), PbCl2 (40.2 mg) and MACl (5 mg) are dissolved in 1ml DMF : DMSO mixture solution (4:1 volume ratio). 

The perovskite solution is spin-coated on top of the HTM layer using the following program: 1000rpm for 10s, 5000 rpm for 30 s. After 25 s, 250 μl of Chlorobenzene is dropped on the spinning substrate. Then the perovskite film is annealed at 100°C for 10 min, and another higher temperature for 10min (120°C for recipe 1 and 150°C for recipe 2). PCBM solution (20 mg/ml in chlorobenzene) is spin-coated on top of perovskite at 1000rpm for 30s, then annealed at 80°C for 10 min. BCP solution (0.5 mg/ml in isopropanol) is spin-coated on top of PCBM at 5000rpm for 30s, annealed 80°C for 5 min. 100 nm thick Ag layer was thermally evaporated under a vacuum of 8×10<sup>−6</sup> mbar at a rate of ∼0.1 nm/s to finish the device fabrication. The device active area was 0.08 cm<sup>−2</sup> . 

Individualized optimization of recipe 2 was conducted based on the final discovered promising molecules. The HTM concentration (0.5-5 mg/ml), antisolvent (chlorobenzene, toluene, and ethyl acetate), additives in perovskite precursor solution (PbCl2, MABr), passivation materials and electron transporting layer were optimized (Figure S31-S38). The best condition is PbCl2 5 mg/ml + MACl 7.5 mg/ml + 145 °C annealing 10 min +N2200 doped PCBM. 

Individualized optimization of recipe 3 (Fig. 4E) with a device structure of FTO/HTM/perovskite/C60/BCP/Ag was conducted based on the final discovered promising molecules. 1.5 M Cs0.05MA0.1FA0.85PbI3 perovskite precursor was fully dissolved in mixed solvents of DMF and DMSO (4:1, v/v) with the molar ratio for FAI/MAI/CsI of 0.85:0.1:0.05. Then, 10 mg ml<sup>−1</sup> MACl was added to the solution to improve the film morphology. The precursor solution was filtered through a 0.22 µm polytetrafluoroethylene membrane before use. A portion of 70 µl of perovskite solution was deposited on the substrate and spun cast at 1,000 rpm for 10 s, followed by 5,000 rpm for 40 s. A 150 µl portion of chlorobenzene was dropped onto the substrate during the last 5 s of spinning, resulting in the formation of dark brown films that were then annealed on a hot plate at 100 °C for 20 min. For the devices with surface passivation treatment, a mixture of PEACl, 1 mg/ml)was dissolved in IPA dynamic spun on the as-prepared perovskite films at 5,000 rpm. for 30 s, then annealing at 100 °C for 10 min. The C60 (30 nm) and BCP (7 nm) were deposited sequentially with a rate of 0.3 Å s<sup>−1</sup> and 0.5 Å s<sup>−1</sup> , respectively, at a pressure of approximately 2 × 10<sup>−6</sup> mbar. Finally, Ag contact (100 nm) was deposited on top of BCP through a shadow mask with the desired aperture area. 

## **Film characterization** 

A self-constructed high-throughput setup for time-resolved photoluminescence (TRPL) was used to collect the signal from the top side of the perovskite films with a 6.4µW laser power 

14 

with an excitation wavelength _λex_ = 402 nm. TRPL were fitted with a two-component exponential decay model. carrier lifetimes 

𝐼(𝑡) = 𝐴1exp(−<sup>𝑡</sup> ⁄𝜏1) + 𝐴2exp(−<sup>𝑡</sup> ⁄𝜏2) 

t1perov and t2perov in Fig.5 C represent the τ1 and τ2 in the formula, where the laser is incident from the side of perovskite. t1glass and t2glass correspond to data that laser incident from the glass side. Similar expressions also exist in PLQY data (PLQYperov and PLQYglass). PLQY was calculated from the absolute PL measurements with integrating sphere, a 405 nm laser diode as the excitation source was adopted, and the laser intensity was altered by a step beam attenuator. The optical fiber was used to connect the sphere and a silicon CCD array detector; a 420 nm filter was used to increase the integrated time. _J–V_ characteristics were measured with a Keithley source measurement unit and a Newport Sol3A solar simulator, which could provide illumination with an AM1.5G spectrum and light intensity of 100 mW cm<sup>-2</sup> . The light intensity was calibrated with a standard crystalline Si device. The film’s contact angles (CA) were measured on a Dataphysics OCA20 contact-angle system at room temperature. 5.0 µl water droplet was dropped onto the HTM films. 

## **Device characterization** 

_J-V_ curve of the solar cells was characterized using a Keithley source under 100 mW/cm2 AM1.5G illumination (Newport Solla simulator). The light intensity was calibrated with a crystalline Si-cell. The _J-V_ data were collected from -0.2 to 1.2 V (forward scan) and 1.2 to - 0.2 V (reverse scan) at a scan rate of 40 mV/s. An aperture mask with an area of 0.08 cm<sup>2</sup> was used. 

## **Data and materials availability** 

All data are available in the main text or the supplementary materials. Code and data to reproduce the plots shown in the machine learning section of the manuscript are publicly available on GitHub (https://github.com/aimat-lab/perovskite_htm_screening). 

**Acknowledgments** J.W. and J.L. acknowledge the financial support from the Sino-German Postdoc Scholarship Program (CSC-DAAD). C.J.B. gratefully acknowledges financial support through the “Aufbruch Bayern” initiative of the state of Bavaria (EnCN and “Solar Factory of the Future”), the Bavarian Initiative “Solar Technologies go Hybrid” (SolTech), and the German Research Foundation (DFG) SFB 953−No. 182849149. J.W., J.H., Y.Z. and C.J.B. gratefully acknowledge the grants “ELF-PV-Design and development of solution processed functional materials for the next generations of PV technologies” (No. 44-6521a/20/4) by the Bavarian State Government. J.Z., Z.X., and K.Z. acknowledge financial support from the China Scholarship Council (CSC). Y.Z. acknowledges the Alexander von Humboldt Foundation for supporting his scientific research during the postdoctoral period (Grant No. 1199604). Calculations were performed on the HoreKa supercomputer funded by the Ministry of Science, Research and the Arts Baden-Württemberg. P.R., L.T. and P.F. acknowledge support by the state of Baden-Württemberg through bwHPC. L.T. and P.F. acknowledge support by the Federal Ministry of Education and Research (BMBF) under Grant No. 01DM21002A (FLAIM). P.F. acknowledges support by the Federal Ministry of Education and Research (BMBF) under Grant No. 01DM21001B (German-Canadian Materials Acceleration Center). J.W. and J.S.R.O gratefully acknowledges the financial support from Solar TAP initiative by the Helmholtz Foundation/BMBF. J.L. gratefully acknowledges financial support from the 

15 

National Natural Science Foundation of China (Grant No. 62104031) and the Technical Field Funds of 173 Project (Grant No. 24JJ210663A). M.H., B-w.P., and S.I.S.  acknowledge financial support from the Basic Science Research Program (NRF-2018R1A3B105282023) through the National Research Foundation of Korea (NRF) funded by the Ministry of Science, ICT and Future Planning (MSIP). 

**Author Contributions** J.W., J.H., P.F., and C.J.B. conceived the idea and supervised the project. J.W. performed the high-throughput synthesis and perovskite device fabrication. L.T., P. R., and P.F. applied the machine learning algorithms. M.H. and J.W. fabricated the perovskite device and wrote the manuscript. J.Z., K.Z., and Y.W. characterized the PLQY and TRPL. Z.X. developed algorithms to process UV-Vis data. J.S.R.O. provided partial materials. L.W., B-w.P., A.B., Y.Z., J.L., and L.L. analyzed the data. All authors reviewed and edited the manuscript. 

**Competing interests** The authors declare no competing interests. 

## **Additional information** 

**Supplementary Information** is available for this paper. 

Correspondence and requests for materials should be addressed to Jianchang Wu, Pascal Friederich, or Christoph J. Brabec. 

16 



<!-- Start of picture text -->
I. Database Source database Intermediate database Synthesized database<br>Kennard-Stone Bayesian Bayesian<br>RDKit Random<br>Monomers 106  104 Initial database (102) Iteration (101) Iteration (101)<br>II. DFT calculation V. Model training and iteration<br>True function<br>NumAtom HOMO DFT data Training MeasurementsModel fit<br>Mw LUMO Feedback<br>Iteration<br>Rotation  Database<br>MolLogP constant b<br>Closed-Loop  Experimental Iteration with<br>data new molecules<br>HTM<br>III. HT synthesis and characterization IV. Device and semi-device data<br>Discovery<br>Microwave reactor<br>HT synthesis HT purification<br>Synthesized J-V Voltage   curve Wetting ability<br>database<br>U  /  I<br>Wavelength  Time (s)<br>HT electrochemical and optical measurements PLQY TRPL<br>Molecular iteration<br>8.5% 15.4% 17.3% 20.5% 20.9%  (24.4%)<br>Higher PCE and FF<br>Vacuum<br>Jsc<br><!-- End of picture text -->

FIGURE 1 

17 



<!-- Start of picture text -->
A           Monomer descriptor calculation B<br>II III IV<br>I<br>V VI VII<br>BrC1=CC(F)=C2C3=CC(C4=C(F<br>)C=C(Br)C=C4)=CC(C5=CC(C)=<br>C(Br)C=C5)=C3CCC2=C1<br>C Monomer A D  Monomer B<br>E PCE % F<br>A1 A2 A3 A4 A5 A6 A7 A8 A9 A10<br>2 0<br>B1 A11 A12 A13 A14 A15 A16 A17 A18 A19 A20<br>A21 A22 A23 A24 A25 A26 A27 A28 A29 A30<br>1 5<br>A1 A2 A3 A6 A7 A8 A10<br>B2 A11 A12 A13 A14 A15 A17 A18 A19 A20<br>A21 A22 A23 A24 A27 A28 A29 A30 1 0<br>A30<br>A31 5<br>A32<br>A33<br>0<br>B2 B3 B4 B5 B6 B7 B8 B9 B10 B11 B12 B13<br><!-- End of picture text -->

FIGURE 2 

18 







FIGURE 3 

19 



<!-- Start of picture text -->
A 0 B 0<br>- 2 - 2<br>- 4<br>- 4<br>- 6<br>- 6<br>- 8<br>1 2 3 4 5 6 2 3 4<br>Band gap (eV) Band gap (eV)<br>C Bromides Boronic acids/acid ester<br>D<br>2 5   Initial library   1st iteration   2nd iteration<br>2 0<br>1 5<br>1 0<br>5<br>0<br>0 20 40 60 80 100 120 140 160<br>E Sample ID<br>25 25 25<br> Forward  Forward  Forward<br> Reverse  Reverse  Reverse<br>20 20 20<br>Voc  = 1.195V Voc  = 1.183V Voc  = 1.173V<br>15 Jsc  = 26.01 mA/cm2 15 Jsc  = 25.92 mA/cm2 15 Jsc  = 25.86 mA/cm2<br>FF = 84.35% FF = 82.78% FF = 83.25%<br>10 PCE = 26.23% 10 PCE = 25.38% 10 PCE = 25.23%<br>5 5 5<br>A1090B769 A1069B769 A1106B3<br>0 0 0<br>0.0 0.2 0.4 0.6 0.8 1.0 1.2 0.0 0.2 0.4 0.6 0.8 1.0 1.2 0.0 0.2 0.4 0.6 0.8 1.0 1.2<br>Voltage (V) Voltage (V) Voltage (V)<br>FIGURE 4<br>Energy level (eV)<br>2Currentdensity (mA/cm)<br>Norm. Avg. PCE (%)<br>2Current density (mA/cm)<br>Energy level (eV)<br>2Current density (mA/cm)<br><!-- End of picture text -->

20 



<!-- Start of picture text -->
A B<br>TPA<br>HOMO<br>LUMO TSPA<br>Dipole Heteroatoms<br>20- 22% (103)<br>Rotation<br>Substituent<br>Constant<br>C D<br>FIGURE 5<br><!-- End of picture text -->

21 

