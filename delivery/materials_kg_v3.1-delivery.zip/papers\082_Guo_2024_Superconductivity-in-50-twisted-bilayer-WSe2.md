# Superconductivity in 5.0° twisted bilayer WSe2

| 字段 | 内容 |
|---|---|
| 期刊 | Nature |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 251 |
| 作者 | Yin-Jie Guo, J. Pack, Joshua Swann, Luke N. Holtzman, Matthew Cothrine, Kenji Watanabe, T. Taniguchi, D. Mandrus et al. |
| DOI | 10.1038/s41586-024-08381-1 |
| 源文件 | 082_Guo_2024_Superconductivity-in-50-twisted-bilayer-WSe2.pdf |

---
# **Superconductivity in twisted bilayer WSe** 2 

Y. Guo<sup>1</sup> , J. Pack<sup>1</sup> , J. Swann<sup>1</sup> , L. Holtzman<sup>2</sup> , M. Cothrine<sup>3</sup> , K. Watanabe<sup>4</sup> , T. Taniguchi<sup>5</sup> , 

D.G. Mandrus<sup>3</sup><sup>_,_6</sup> , K. Barmak<sup>2</sup> , J. Hone<sup>7</sup> , A.J. Millis<sup>1</sup><sup>_,_8</sup> , A. Pasupathy<sup>1</sup><sup>_,_9</sup> , and C.R. Dean<sup>1</sup><sup>_∗_</sup> 

> 1 _Department of Physics, Columbia University, New York, NY 10027, USA_ 

> 2 _Department of Applied Physics and Applied Mathematics,_ 

_Columbia University, New York, New York 10027, United States_ 

> 3 _Department of Materials Science and Engineering,_ 

_University of Tennessee, Knoxville, Tennessee 37996, United States_ 

> 4 _Research Center for Electronic and Optical Materials,_ 

_National Institute for Materials Science, 1-1 Namiki, Tsukuba 305-0044, Japan_ 

> 5 _Research Center for Materials Nanoarchitectonics,_ 

_National Institute for Materials Science, 1-1 Namiki, Tsukuba 305-0044, Japan_ 

> 6 _Materials Science and Technology Division, Oak Ridge National Laboratory, Oak Ridge, Tennessee 37831, United States_ 

> 7 _Department of Mechanical Engineering, Columbia University, New York, NY 10027, USA_ 

> 8 _Center for Computational Quantum Physics, Flatiron Institute; New York, USA and_ 

> 9 _Condensed Matter Physics and Materials Science Division, Brookhaven National Laboratory; Upton, USA._ (Dated: June 6, 2024) 

**The discovery of superconductivity in twisted bilayer and twisted trilayer graphene[1–5] has generated tremendous interest. The key feature of these systems is an interplay between interlayer coupling and a moir´e superlattice that gives rise to low-energy flat bands with strong correlations[6]. Flat bands can also be induced by moir´e patterns in lattice-mismatched and or twisted heterostructures of other twodimensional materials such as transition metal dichalcogenides (TMDs)[7–11]. Although a wide range of correlated phenomenon have indeed been observed in the moir´e TMDs[12–24], robust demonstration of superconductivity has remained absent[12]. Here we report superconductivity in 5 degree twisted bilayer WSe** 2 **(tWSe** 2 **) with a maximum critical temperature of 426 mK. The superconducting state appears in a limited region of displacement field and density that is adjacent to a metallic state with Fermi surface reconstruction believed to arise from antiferromagnetic order[25]. A sharp boundary is observed between the superconducting and magnetic phases at low temperature, reminiscent of spin-fluctuation mediated superconductivity[26]. Our results establish that moir´e flat-band superconductivity extends beyond graphene structures. Material properties that are absent in graphene but intrinsic among the TMDs such as a native band gap, large spin-orbit coupling, spinvalley locking, and magnetism offer the possibility to access a broader superconducting parameter space than graphene-only structures.** 

## **Introduction** 

Flat bands in 2D heterostructures have been a focus of intense study as a way to achieve strongly correlated electronic states. In twisted graphene systems, superconduc- 

tivity [2, 4, 5, 27], magnetic ordering [28] and topological Chern bands [29] have been observed around commensurate fillings of the moir´e band. Superconductivity has also been observed in crystalline graphene, such as rhomboherdral trilayer graphene[30] and Bernal bilayer graphene[31–33], where high density of states is generated at Van Hove singularities (VHs) located at the boundary of Fermi pocket topology transitions. It remains a question of significant debate whether superconductivity in the graphene systems is a conventional BCS type, mediated by phonons[34–37], or unconventional, mediated by another mechanism such as spin fluctuations[38–43], or even contains both types. 

Moir´e-patterned transition metal dichalcogenides (TMDs) also host low energy flat bands[7] and have proven to be a highly tunable system for hosting exotic correlated phases, such as Mott insulators [12, 13], generalized Wigner crystal states [16–18], integer and fractional quantum anomalous Hall states [19–24] and magnetic ordering [14, 15]. Theoretical studies have suggested that superconductivity should also be present in this system [44–59], and with the possibility of exotic character. However, definitive experimental observation remains absent. This raises the question as to whether superconductivity is a universal feature in flatband 2D systems, or if there is some unique feature in the graphene-based structures that plays a key role. 

Here we report observation of superconductivity in bilayer WSe2 fabricated with a 5.0<sup>_o_</sup> twist angle. At zero displacement field we do not observe evidence of correlated behaviour, which may be expected since at this twist angle the moir´e band is nearly ten times wider[12] than that of magic angle twisted bilayer graphene, and can thus be expected to host weaker correlations. However, when an applied displacement field is tuned such that the Van Hove singularity (VHs) of the moir´e band shifts close to half filling (one hole per moir´e unit cell), 

2 



<!-- Start of picture text -->
a b c e D=0, B>0<br>VTG Contact<br>Au gate<br>BN k'B↓ k'T↓<br>VContact FLG Top Gate kT kB<br>VBG BN  θ<br>k+ k-<br>FLG Contact<br>d<br>tWSe2<br>D>0, B=0<br>RuCl3 Contact<br>doping Γ kT k'T↓<br>BN<br>V<br>FLG Bottom k'B↓ kB<br>Gate :  ,<br>:  ,<br>f g ν  (n/nm) h ν  (n/nm)<br>1.5 1 0.5 0.0 1.5 1 0.5 0.0<br>layer polarized 0.8 0.8<br>kT<br>vHs kB 0.6 0.6<br>0.4 RLP 0.4<br>kT kB kT kB 0.2 0.2<br>0.0 RVHs 0.0 R  =0xy<br>R (Ω) Rxy(Ω)<br>0.2 400 0.2<br>50<br>kB 300 25<br>kT 0.4 200 RLP 0.4 0<br>2 5<br>0.6 100 0.6<br>5 0<br>layer polarized 0<br>0.8 0.8<br>-2 -1 0 14 12 10 8 6 4 2 0 14 12 10 8 6 4 2 0<br>Filling fraction (n/nm) n (× 10 12 cm -2 ) n (× 10 12 cm -2 )<br>WSe2<br>FLG Au<br>FLG<br>RuCl3<br>D (V/nm) D (V/nm)<br>Displacement field<br>↓ ↓<br>↓<br>↓<br><!-- End of picture text -->

FIG. 1. **Electronic band structure and the superconducting pocket a** , **b** Schematic illustration of the tWSe2 device structure. Graphite contacts together with charge transfer doping by _α_ -RuCl3 enables Ohmic contact (see text). **c** , Illustration of real space moir´e pattern between twisted WSe2 layers. **d** , Brillouin zones of the top (red) and bottom (blue) layer. The spin states near the _k_ valleys are marked. The small black hexagon shows the moir´e mini Brillouin zone. Both the spin up (down) valley of the top layer and the spin down (up) valley of the bottom layer folds onto the _k_ + ( _k−_ ) valley of the moir´e mini Brillouin zone. **e** , Illustration of the low energy tWSe2 band structure. The spin-valley branches hybridize across the layers as shown. Magnetic field splits the bands via Zeeman coupling (top) where as displacement field distorts each band by layer polarizing. **f** , Schematic phase diagram of of the band structure and Fermi energy for a single isospin branch versus displacment field and carrier density **g** . **h** , Longitudinal resistance _R_ ( **g** ) at zero magnetic field and Hall resistance _Rxy_ ( **h** ) at 200 mT versus density and displacement field. The densities are displayed in negative values to represent hole doping. Labels identify transport features that coincide with the solid and dashed boundaries in **f** (see text). Filling fraction is defined as number of holes per moir´e unit cell. 

a local region of robust superconductivity emerges adjacent to a resistive metallic state that we associate with anti-ferromagnetic ordering[25]. Analysis of the SC-AFM phase diagram suggests the superconductivity may be stabilized by spin fluctuations, analogous to similar behaviour seen in heavy Fermion systems[26]. Since magnetism and superconductivity are both favoured by a high density of electronic states, they often emerge near Van Hove singularities (VHs) and can exhibit either competition or cooperation. The case where magnetic fluctuations mediate superconductivity is particularly interesting since some of the same fundamental electronic interaction determine the ground state[26]. 

## **Tunable flat bands** 

Fig. 1a-b shows a schematic illustration of the device structure. Ohmic contacts were realized by using a combination of graphite as the contact metal and RuCl3 as a charge-transfer dopant in the contact region[60]. The device was assembled by the dry transfer method[61] using exfoliated hBN as dielectric spacers (Fig. 1b). The “cut and stack” technique[62] was employed to realize an AA-stacked tWSe2 with twist angle measured to be 5 _._ 0<sup>_o_</sup> (see SI). The WSe2 layers are derived from high-purity crystals grown by a two-step flux synthesis method[63]. We defined a three gate structure where “top” and “bottom” graphite gates allow tuning of the channel density 

3 

and displacement field, with a third metal gate used to maintain a low electrostatic barrier in the contact region (see methods for details of the device fabrication process). The contact doping scheme enables reliable contact under hole doping only, and therefore we restrict our discussion to studies of the valence band. The contact resistance, estimated from the two-terminal response, is _∼_ 12 kΩ for most of the gate range, rising to 50 kΩat density of 0.95 _×_ 10<sup>12</sup> cm<sup>_−_2</sup> (See SI). 

In monolayer WSe2, owing to the strong spin-orbit coupling, the spin and valley degrees of freedom are locked, creating a combined spin-valley isospin with opposite spin polarization in each of the the _k_ and _k_<sup>_′_</sup> valleys. In twisted bilayer WSe2, the lattice orientation mismatch of the rotated layers results in a moir´e superlattice in real space. At a twist angle of 5 _._ 0<sup>_o_</sup> , the moir´e wavelength is 3.76nm[64]. In reciprocal space, a corresponding moir´e mini Brillouin zone is formed (Fig. 1d). The _k ↓_ ( _k_<sup>_′_</sup> _↑_ ) valley of the top layer and the _k_<sup>_′_</sup> _↑_ ( _k ↓_ ) valley of the down layer in the original Brillouin zone both fold onto the _k_ + ( _k−_ ) valley in the moir´e mini Brillouin zone. Therefore, each valley of the moir´e superlattice contains both spin flavours. 

At small twist angles, interlayer hopping causes hybridization between the layer bands, leaving a saddle point where they intersect (Fig. 1e). The reconstructed bands maintain spin and valley locking, and thus retain a two-fold combined isospin flavour. Band structure calculations[12] indicate that at 5<sup>_o_</sup> twist angle, the band width is approximately _w_ = 93 meV at zero displacement field, whereas the Coulomb energy is _U_ = 109 meV. This gives a ratio of _U/t ∼_ 1, indicating a regime of moderate correlations. Applying a displacement field distorts each band, varying its width, causing the VHs position to shift and increasing the DOS at the VHs (see SI)[12]. At sufficiently large bias and low doping, the displacement field can cause the carriers to polarize to one layer. A cartoon schematic of the VHs position and layer polarization boundaries as a function of displacement field and band filling is shown in Fig. 1f. The effective low energy band structure for just one of the isospin flavours is shown in each region (see SI for detailed calculation of band structure versus displacement field at the relevant angle of _∼_ 5<sup>_o_</sup> ). 

Fig. 1g shows the longitudinal resistance, _R_ as a function of density and displacement field, measured at _B_ = 0 T and cryostat temperature of _T_ = 33 mK. The conversion from applied gate potentials to density, displacement field, and band filling fraction was determined from Landau level trajectories (see SI). We define the filling fraction as the number of holes per moir´e unit cell, _ν_ = _n/nm_ , where full band filling corresponds to _ν_ = 2 owing to the twofold isospin degeneracy. The diverging _R_ seen at low density (yellow in the chosen color scale of Fig. 1g) corresponds to the Fermi level nearing the top of the valence band. The layer polarization boundaries 

and VHs position are also evident, appearing as local peaks in _R_ (light blue trajectories in Fig 1g). The layer polarization boundaries, labelled _R_<sup>_LP_</sup> in Fig. 1g, were confirmed by measurement in the quantum Hall regime where there is a corresponding change in the LL crossing behaviour (see SI). The behaviour of the resistive peak at the approximate VHs position, labelled _R_<sup>_V Hs_</sup> in Fig. 1g, is consistent with bandstructure calculations, which predict that the VHs is located slightly below half band filling at _D_ = 0, and passes through half-filling at approximately _D ∼_ 0 _._ 4 V/nm[65].(See SI) Fig. 1h shows the density and displacement field dependence of the Hall resistance, _Rxy_ , measured at _B_ = 0 _._ 2 T. _Rxy_ changes sign along a similar trajectory (labelled _Rxy_ = 0) as the _R_<sup>_V Hs_</sup> peak, but with a slight offset. 

The temperature dependence of the resistivity indicates that the material is metallic at all doping levels and displacement fields, in contrast to previous studies of devices with smaller twist angles which showed small regions of fully insulating (but modest bandgap) behavior[12, 25]. We attribute the difference to the larger twist angle (implying larger bandwidth) and reduced BN thickness (implying potentially more screening by the gate). Under finite displacement field, approximately when the VHs crosses half-filling (dashed squares in Figs. 1g,h), we observe a local feature with anomalous behavior: _R_ shows a local peak adjacent to a zero-resistance pocket, while _Rxy_ shows a strong enhancement. 

## **Superconductivity in twisted WSe** 2 

Fig. 2a shows a higher resolution map of the region enclosed by the white dashed lines in Fig. 1g, highlighting the zero resistance region (dark blue in the chosen colour scale). In Fig. 2b, temperature dependent resistance at a select point in this region (solid circle in Fig. 2a) is compared with the adjacent resistive peak (open circle in Fig. 2a). The transition to zero resistance shows characteristic behaviour of a two-dimensional superconductor: with decreasing temperature, the resistance exhibits an abrupt downturn followed by a long tail that eventually reaches zero within the measurement noise floor. By comparison, the adjacent resistive peak exhibits an approximately linear in T metallic dependence over the accessible temperature range. Using the empirical convention of identifying the mean field critical temperature to be where _R_ ( _T_ ) equals 50% of the normal state resistance gives _Tc_ = 426 mK at this density and displacement field. 

Fig. 2c shows the temperature dependent voltagecurrent ( _V − I_ ) response for this same point. In the lowtemperature limit, non-linear response typical of superconductivity is observed. We estimate the critical current at base temperature to be approximately _Ic_ = 30 _nA_ . By fitting the power-law dependence (Fig. 2c inset left), we extract a Berezinskii–Kosterlitz–Thouless (BKT) transition temperature of _T_ BKT = 395 mK (see methods) 

4 



<!-- Start of picture text -->
R (Ω)<br>a  filling fraction (n/nm) 0 200 400 b<br>1.2 1.0<br>400<br>0.8 δ𝜈 superconducting<br>metallic<br>350<br>0.7<br>300<br>250<br>0.6<br>200<br>0.5 150 Tc50% = 426mK<br>100<br>0.4<br>50 TBKT = 395mK<br>0<br>10.5 10.0 9.5 9.0 8.5 8.0 7.5 7.0<br>100 200 300 400 500 600 700<br>n (× 10 12 cm -2 ) T (mK)<br>c d<br>10 2 V ∝ I 3 503 mK443 mK410 mK675 mK605 mK 300 1.21.0<br>20 380 mK340 mK<br>300 mK B (mT)<br>10 1 254 mK203 mK144 mK 250 0.8 010<br>10 98 mK33 mK 0.6 2030<br>10 1 10 2 200 40<br>IDC (nA) 0.4 5060<br>0 70<br>200 dV/dI (Ω)0 750 150 0.2 8090<br>100<br>100<br>-10 0.0<br>100 100 200 300 400 500 600 700<br>0 T (mK)<br>-20 -100 50<br>-200-60 0 60 ξ50=57.03nm<br>IDC (nA)<br>0<br>-60 -40 -20 0 20 40 60 0 100 200 300 400 500<br>Idc (nA) Tc (mK)<br>D (V/nm)<br>R (Ω)<br>V (V)μ<br>/RRnxx<br>B (mT)<br>B (mT)<br>V (μV)<br><!-- End of picture text -->

FIG. 2. **Superconductivity in twisted WSe** 2 **. a** , High-resolution map of the region enclosed in the white dashed box in Fig. 1g, showing _R_ around the superconducting pocket. Error bar shows the uncertainty in our determination of the filling fraction (see text). Closed circle corresponds to _D_ = 0 _._ 5 V/nm, _n_ = _−_ 8 _._ 93 _×_ 10<sup>12</sup> cm<sup>_−_2</sup> ; Open circle corresponds to _D_ = 0 _._ 53 V/nm, _n_ = _−_ 9 _._ 05 _×_ 10<sup>12</sup> cm<sup>_−_2</sup> . **b** Resistance versus temperature measured at the locations identified in **a** . The critical temperature, _TC_ , defined at 50% of the normal-state resistance, and BKT temperature, _TBKT_ determined in **c** are labelled. **c** , _Vxx − I_ as a function of temperature for the zero resistance location identified in a. The top left inset shows the _Vxx − I_ curves on a log-log scale. Dashed line indicates where the slope is 3 ( _Vxx ∝ I_<sup>3</sup> ), which gives _T_ BKT = 395 mK. The bottom right inset shows d _Vxx_ /d _I_ versus DC current bias and perpendicular magnetic field **d** , critical temperature as a function of perpendicular magnetic field. The critical temperature is defined at 50% of the normal-state resistance from the family of _R_ ( _T_ ) curves versus magnetic field shown inset. 

which is close to the estimated mean field temperature ( _T_ BKT _/Tc ∼_ 0 _._ 93), as expected for a low-disorder superconductor [66]. Inset right in Fig. 2c is a plot of _dV/dI_ versus DC current and magnetic field. The qualitative behaviour is again consistent with superconductivity and indicates a base temperature critical field of _Bc⊥ ≈_ 100 mT. 

Fig. 2d shows the B-T phase diagram, determined using the same 50% _Rn_ definition for T _c_ (a family of normalized _R_ ( _T_ ) _/Rn_ versus _B_ curves are shown inset in Fig. 2d), where the normal state resistance was defined by the knee of the transition. The critical field varies linearly with temperature, consistent with the Ginzburg-Landau equation, _Hc_<sup>_⊥_</sup> 2<sup>=</sup><sup>_ϕ_0</sup><sup>_/_(2</sup><sup>_πξ_(0)2)(1</sup><sup>_−_(</sup><sup>_T/Tc_)),where</sup><sup>_ϕ_0is</sup> 

5 



<!-- Start of picture text -->
a 𝜈 (n/nm) b 𝜈 (n/nm) e<br>-1.2 -1 -1.2 -1<br>0.8 0 100 200 0.8 -50 0 50 filling fraction (n/nm)<br>-1.2 -1<br>0.7 Rxx(Ω) 0.7 Rxy (Ω) 0.8<br>0.6 0.6 excess RXX<br>excess RXY<br>0.5 0.5 0.7 superconductivity<br>0.4 0.4 AFM RXX max<br>RXY max<br>-10.0 -9.0 -8.0 -7.0 -10.0 -9.0 -8.0 -7.0 0.6 TC max<br>c n (x10 12 cm -2 ) d n (x10 12 cm -2 )<br>700 600<br>600 400 0.5<br>500 200 SC<br>400 0<br>0.4<br>300 -200 n (x10 12 cm -2 )<br>200 -400 -8.41<br>100 -600 -10.54<br>-10.0 -9.0 -8.0 -7.0<br>-6 -4 -2 0 2 4 6 -6 -4 -2 0 2 4 6<br>n (x10 12 cm -2 )<br>B (T) B (T)<br>RxY=0<br>xxR peak<br>D (V/nm) D (V/nm)<br>D (V/nm)<br>Ω ()RXX Ω ()RXY<br><!-- End of picture text -->

FIG. 3. **Magnetism and phase diagram. a** . **b** , Longitudinal resistance ( **a** ) and Hall resistance ( **b** ) as a function of density and displacement field measured at 200 mT T=33mK. A resistive region is seen adjacent to and overlapping with the superconducting phase boundary (indicated by white line) **c** . **d** , Longitudinal resistance ( **c** ) and Hall resistance ( **d** ) versus magnetic field measured at locations indicated by white circles in **a** , _T_ = 1 _._ 6 K. The legend in **d** identifies the corresponding densities. The anomalous magnetotransport is identified with an antiferromagnetic (AFM) order (see text). **e** Diagram showing the relationship between the superconducting and magnetic regions in the density-displacement field phase space. The AFM phase boundary is identified by the region of excess longitudinal resistance observed in **a** and excess Hall resistance observed in **b** . Blue and grey circles mark locations of the maximum value in the 200 mT _Rxx_ and _Rxy_ maps. The maximum _Tc_ position (see Fig. 4) is labelled by the black circle. 

the flux quantum, _Tc_ is the zero field critical temperature and _ξ_ (0) is the coherence length. The slope of the fitted line gives _ξ_ (0) _≈_ 57 nm. The normal-state square resistance, defined at the knee of the transition, is _R_ = 150 Ω. The mean free path, _lm_ , can be estimated From the Drude model, _R_ = _h/e_<sup>2</sup> _kF lm_ , where _h_ is Planck’s constant, _e_ is the elementary charge, and _kF_ = _~~√~~_ 2 _πn_ , giving _lm_ = 229 nm. This in turn gives an estimate for the disorder ratio to be _d_ = _ξ_ (0) _/lm ∼_ 0 _._ 25, suggesting that the superconductor is in the clean limit. **Interplay between superconductivity and magnetic order** 

To further examine the resistive feature adjacent to the superconducting phase, we suppress the superconductor by applying an out-of-plane magnetic field. Fig. 3a,b shows _Rxx_ and _Rxy_ measured at _B⊥_ = 200 mT, with the white line indicating the boundary of the superconducting pocket at zero field. In both channels we observe an excess resistance over a finite range of density and displacement field. Interestingly, the boundaries of the resistive and superconductor features occupy predominately separate regions, with a small overlap. Fig. 3c,d shows _Rxx_ and _Rxy_ versus _B⊥_ , measured 

along the locations indicated by white circles in Fig. 3a. The magnetoresistance characteristics in our 5<sup>_o_</sup> device are very similar to those reported in recent studies on 4.2<sup>_o_</sup> tWSe2 [25], albeit with lower characteristic temperature (see SI). The peak in the Hall resistance and noticeable but less dramatic peak in the longitudinal resistance was interpreted to arise from a Fermi surface reconstruction, most likely due to antiferromagnetic (AFM) order induced by the large susceptibility occurring at wave vectors that connect the Van Hove points of the spin up and down Fermi surfaces. The antiferromagnetic order partially gaps the Fermi surface. In the supplemental information we calculate the density of states and wave vector-dependent susceptibility as a function of carrier concentration and displacement field, using the highest energy band from [65]. The magnitude of the susceptibility increases with increasing displacement field, but the Fermi surface becomes less nested. Based on this trend we suggest that above a critical displacement field the Stoner criterion is satisfied, producing magnetic order, and that in the vicinity of the magnetic state, superconductivity is stabilized. 

A summary schematic of the full AFM-superconductor phase diagram is shown in Fig. 3e. Yellow indicates the 

6 



<!-- Start of picture text -->
a R (Ω) 0 400 c d e<br>-1.2 𝜈 -1<br>0.8 600 AFM R(Ω)<br>300mK<br>0.7 500 AFM AFM 300<br>0.6<br>400 200<br>0.5<br>300 100<br>0.4<br>200 0<br>0.8<br>400mK SC SC SC SC<br>100<br>0.7<br>-9.5 -9.0 -8.5 -8.0 -9.5 -9.0 -8.5 -8.0 -9.2 -8.8 -8.4<br>0.6 n (×10 12 cm -2 ) n (×10 12 cm -2 ) n (×10 12 cm -2 )<br>0.5 400<br>350 670mK 670mK<br>0.4<br>670mK<br>300<br>0.8<br>640mK 250<br>0.7 200<br>0.6 150<br>100<br>0.5<br>50 100mK 100mK 100mK<br>0.4<br>0<br>-9.5 -9.0 -8.5 -8.0 -9.5 -9.0 -8.5 -8.0 -9.2 -8.8 -8.4<br>-10.0 -9.0 -8.0 -7.0 n (×10 12 cm -2 ) n (×10 12 cm -2 ) n (×10 12 cm -2 )<br>n (×10 12 cm -2 )<br>b -1.2 𝜈 -1 f AFM Superconductor Metal g<br>400<br>300 sweep forward Failed SC<br>0.6 sweep reverse SC<br>250<br>200 300<br>200<br>150<br>0.5 100 0 -9.06 -9.02 -8.88 200 Tc 50%  = 308mK<br>n (×10 12  cm -2 )<br>50<br>100<br>0.4 50 Tc 50%  = 426mK<br>0<br>0<br>-10.0 -9.0 -8.0 -9.0 -8.8 -8.6 -8.4 100 300 500 700<br>n (×10 12 cm -2 ) n (×10 12 cm -2 ) T (mK)<br>400mK<br>300mK<br>200mK<br>33mK<br>640mK<br>D (V/nm) T (mK)<br>D (V/nm)<br> (Ω)R<br>D (V/nm)<br>R (Ω)<br>R (Ω)<br> (Ω)R<br>D (V/nm)<br>R-R(Ω)RF<br><!-- End of picture text -->

FIG. 4. **Temperature dependence of the superconducting boundary. a** , _R_ versus displacement field and density measured at 300mK, 400mK and 640mK. As the temperature increases the superconducting pocket shrinks. When temperature exceeds _TC_ , only the region of excess resistance remains, which we associate with the antiferromagnetic regime. **b** , Contour plot of the superconducting boundary versus temperature. The region of excess resistance measured at 640 mK is indicated by the dashed black line. **c-e** , Top panels show _R_ plotted versus temperature and density, acquired by sweeping along line cuts in the _D − n_ phase diagram. The colored bars identify the associated trajectory marked by colored arrows in **a** . Red cuts across the superconducting region with largest _TC_ by varying density at fixed displacement field, _D_ = 0 _._ 50 V/nm. Blue cuts across the strongest resistive peak, _D_ = 0 _._ 53 V/n. Green cuts diagonally through both regions. Lower panels show the associated family of curves. **f** . Forward and reverse trace along the same trajectory measured in **e** showing evidence of hysteresis (emphasized inset) at the SC-AFM transition, and no hysteresis at the SC-normal metal boundary. Bottom panel plots the difference between the traces. **g** , Comparison of _R_ ( _T_ ) measured in the region of overlap between the AFM and SC boundaries (black circle in **b** ), and outside the overlap region (white circle in **b** ). The light blue curve, which is measured in the overlap region, shows characteristics of a superconducting transition but saturates to finite value before reaching zero resistance. 

region of AFM ordering identified by contours of excess resistance in _Rxx_ (blue line) and _Rxy_ (grey line). The blue region represents the arrow shaped superconducting pocket observed at base temperature (Fig. 2a). The dashed grey and red dashed lines indicate the _Rxx_ peak and _Rxy_ = 0 trajectories associated with the Van Hove 

singularity (Fig. 1g,h). The locations of maximal excess resistance in _Rxx_ (blue circle) and _Rxy_ (grey circle) are essentially coincident with each other, and are both adjacent to but not apparently overlapping the location of peak superconducting _Tc_ (black circle, see discussion of Fig. 4 for more details). We note that the appearance of 

7 

superconductivity near an interaction-driven phase transition in the spin-valley ordering is phenomenologically similar to observations in the graphene-based flat band systems[3–5, 27, 30–33, 67] which could point towards a universal mechanism. 

We next examine how the phase diagram evolves with temperature. Fig.4a shows plots of _R_ versus displacement field and density, measured at temperatures 300 mK, 400 mK and 640 mK. As temperature increases, the boundary of the superconducting pocket (dark blue) gradually shrinks. At 640 mK, we see only a region of excess resistance remaining (yellow in the color scale), corresponding to the same phase we identified when suppressing the superconductor with magnetic field (Fig. 3a). Fig. 4b shows a contour plot of the superconducting boundary at different temperatures (defined by 150 Ω, about 50% of the normal state resistance). The dashed black lines mark a contour boundary of the excess resistance corresponding to _R_ = 350 Ωin the 640 mK map. It is notable that as temperature increases, the boundary between the magnetic and superconducting phases remains sharp, whereas the boundary furthest from the magnetic phase gradually recedes. This indicates that the region of most robust superconductivity is directly adjacent to the magnetic phase, but also reveals that the phase transition between to the magnetic and superconducting states is sharply defined - possibly first-order. 

Figs. 4c-e show cross-sections through the full temperature-displacement field-density phase space obtained by measuring temperature dependence along the trajectories marked by coloured arrows in Fig. 4b. In each we get a sense of how the superconducting dome interplays with the surrounding phases. Fig. 4c, obtained by varying density at fixed _D_ = 0 _._ 5 V/nm, cuts across the point of strongest _Tc_ and intersects only the weak edge of the magnetic phase (red arrows in Fig. 4b). The corresponding superconducting dome is approximately symmetric about the maximum _Tc_ . However, the line cuts reveal that the resistance does not fully reach zero in the region of overlap with the magnetic phase. Fig. 4d again corresponds to fixed _D_ but this time cutting across the region of strongest magnetic signature (blue arrows in Fig. 4b). Here the apparent AFM state divides the dome in half, persisting all the way to base temperature. Finally, Fig. 4e cuts across the long diagonal pocket, intersecting the strongest superconductor and magnetic phase regions. The superconducting _Tc_ shows a nearly vertical drop to zero when it encounters the AFM phase boundary, but shows a more usual gradual domelike shape when transitioning to the normal metal on the other side. 

Fig. 4f shows a single forward and reverse gate sweep measured along along this same trajectory. We observe a weak but measurable hysteresis at the SC-AFM transition, and no evidence of hysteresis across the SCmetal transition under identical conditions. This pro- 

vides further evidence of a first-order phase transition across the SC-AFM boundary, and reinforces our interpretation that the Fermi surface reconstruction results from AFM ordering[68]. 

Finally, in Fig. 4g, we compare _R_ ( _T_ ) between regions where the superconductor and AFM overlap versus where they do not overlap, corresponding to the positions marked by the white and black circles, respectively, in Fig. 4b. In the overlapping region (light blue curve), _R_ ( _T_ ) shows a sharp transition that closely resembles the non-overlapping region (dark blue curve), but with lower _Tc_ . Interestingly the transition in the overlap region does not reach zero resistance but instead saturates to a finite value. This behaviour suggests a failed superconductor, which we conjecture arises from a mixed phase of AFM and superconducting regions. 

## **Discussion and conclusions** 

Having demonstrated robust superconductivity in tWSe2, we next consider what its nature might be. We first consider the pairing strength. Estimating the Fermi energy to be _EF ∼_ 50 meV ( _∼_ half of the full band width) gives the ratio for the critical temperature, _TC_ , versus Fermi temperature, _TF_ = _EF /kB_ , to be _Tc/TF ∼_ 0 _._ 0008, a value typically associated with the weak pairing “BCS” regime[69]. The BKT relation implies that at _T_ = _TBKT_ the superfluid stiffness, _ρs_ ( _Tc_ ) = _π_ <u>2</u><sup>_Tc_isapproximately</sup> 0.25 K, about two orders of magnitude less than the clean-limit superfluid stiffness _∼_ 20 _K_ calculated from the band structure given in [65]. The small value of the superfluid stiffness, large value of the coherence length relative to the moir´e lattice constant ( _ξ_ 0 _/am ∼_ 15) and large bandwidth all support BCS pairing. 

It has been theoretically proposed that phononmediated interactions could induce a conventional type superconductivity in the graphene flatband systems, [34, 67, 70], with similar possibility anticipated in for tWSe2 [7, 46]. Although we estimate that this system is in in the BCS limit, we nonetheless conjecture that the superconductivity is unconventional in the sense of being induced by a non-phonon mechanism. A feature that distinguishes our system from the twisted multilayer graphene systems [3–5, 27, 67], but finds similarity with rhombohedral trilayer graphene[30] and Bernal bilayer graphene [31–33], is the emergence of superconductivity coincident with a Fermi-surface reconstruction where magnetic ordering in the spin-valley sector is also evident. In twisted graphene there is ambiguity since the narrowness of the band makes it difficult to determine proximity relationships between the various ordered states[70]. If the superconductivity in our device were phonon mediated with an enhancement by the Van Hove density of states, we might expect it to track the VHs throughout the band. That instead we observe superconductivity only within a narrow window, concomitant with magnetic ordering, points toward the magnetic or- 

8 

der playing a critical role such as mediating pairing via spin fluctuations[26, 53, 71, 72]. 

In summary our interpretation is that at zero displacement field, correlations are too weak for superconductivity to be observable within experimental temperature. However, under application of a displacement field, the resulting increase in density of states at the VHs, and increasing magnetic susceptibility, reach a threshold where a Fermi surface reconstruction to an antiferromagnetic state results. Spin fluctuations in the vicinity of the AFM phase are then responsible for mediating the superconducting pairing state. This interpretation would explain the absence of superconductivity everywhere except in proximity to the AFM phase, while also being qualitatively consistent with the superconducting phase defined by a _Tc_ that rises on approaching the AFM phase, reaches a peak value at the AFM boundary, and then abruptly disappears. Finally we note that this behaviour is very similar to antiferromagnetic heavy Fermion systems in the clean limit where spin fluctuations provide the pairing mechanism[26, 73]. 

A full understanding of the superconductivity that we observe in tWSe2 will certainly require further experimental and theoretical work. In particular a more comprehensive understanding of the interplay between the magnetic order and superconducting state, beyond what can be accomplished by transport alone, will be necessary to determine whether the two phases are cooperative, competing, coincident or some combination of all three. The ability to move throughout the magneticsuperconductor phase diagram within a single device via purely electrostatic gating offers unprecedented opportunity to identify universal versus material specific characteristics of this interplay and could provide new insight beyond what has been achieved in the study of conventional high _Tc_ and heavy Fermion systems. A key question to address will be how the phase diagram evolves with twist angle. This also provides a unique opportunity compared with the graphene systems where it is already established that in the TMDs, correlations survive and evolve over several degrees of twist angle, compared to the relatively narrow “magic” windows in twisted multilayer graphene, and the essentially singular parameter space of rhombohedral stacked multilayers. 

from the JSPS KAKENHI (Grant Numbers 21H05233 and 23H02052) and World Premier International Research Center Initiative (WPI), MEXT, Japan. J.H. and C.R.D. acknowledge additional support from the Gordon and Betty Moore Foundation’s EPiQS Initiative, Grant GBMF10277. 

### **AUTHOR CONTRIBUTIONS** 

Y.G. fabricated the device. Y.G., J.P., J.S. and C.R.D. performed the electronic transport measurements and analyzed the data. L.H. grew the WSe2 crystals under the supervision of J.H. and K.B; M.C. grew the _α_ -RuCl3 crystals under the supervision of D.G.M.; K.W. and T.T. grew the hexagonal boron nitride crystals. A.M. performed theoretical modeling. Y.G., A.M., A.P. and C.R.D. wrote the manuscript with input from all authors. 

### **COMPETING FINANCIAL INTERESTS** 

The authors declare no competing financial interests. 

- _∗_ Email: cd2478@columbia.edu 

- [1] Y. Cao, V. Fatemi, A. Demir, S. Fang, S. L. Tomarken, J. Y. Luo, J. D. Sanchez-Yamagishi, K. Watanabe, T. Taniguchi, E. Kaxiras, R. C. Ashoori, and P. JarilloHerrero, Nature **556** , 80 (2018). 

- [2] M. Yankowitz, S. Chen, H. Polshyn, Y. Zhang, K. Watanabe, T. Taniguchi, D. Graf, A. F. Young, and C. R. Dean, Science **363** , 1059 (2019). 

- [3] X. Lu, P. Stepanov, W. Yang, M. Xie, M. A. Aamir, I. Das, C. Urgell, K. Watanabe, T. Taniguchi, G. Zhang, A. Bachtold, A. H. MacDonald, and D. K. Efetov, Nature **574** , 653 (2019). 

- [4] J. M. Park, Y. Cao, K. Watanabe, T. Taniguchi, and P. Jarillo-Herrero, Nature **590** , 249 (2021). 

- [5] Z. Hao, A. M. Zimmerman, P. Ledwith, E. Khalaf, D. H. Najafabadi, K. Watanabe, T. Taniguchi, A. Vishwanath, and P. Kim, Science **371** , 1133 (2021). 

- [6] R. Bistritzer and A. H. MacDonald, Proceedings of the National Academy of Sciences **108** , 12233 (2011). 

- [7] F. Wu, T. Lovorn, E. Tutuc, and A. H. MacDonald, Physical Review Letters **121** , 026402 (2018). 

### **ACKNOWLEDGMENTS** 

This research is primarily supported by US Department of Energy (DE-SC0019443). WSe2 was synthesized by JH and KM under the support of the Columbia University Materials Science and Engineering Research Center (MRSEC), through NSF grants DMR-2011738. D.M. and M.C. acknowledge support from the Gordon and Betty Moore Foundation’s EPiQS Initiative, Grant GBMF9069. K.W. and T.T. acknowledge support 

- [8] F. Wu, T. Lovorn, E. Tutuc, I. Martin, and A. H. Macdonald, Physical Review Letters **122** (2019), 10.1103/PhysRevLett.122.086402. 

- [9] M. H. Naik and M. Jain, Physical Review Letters **121** , 266401 (2018). 

- [10] D. A. Ruiz-Tijerina and V. I. Fal’ko, Physical Review B **99** , 125424 (2019). 

- [11] C. Schrade and L. Fu, Physical Review B **100** , 035413 (2019). 

- [12] L. Wang, E. M. Shih, A. Ghiotto, L. Xian, D. A. Rhodes, C. Tan, M. Claassen, D. M. Kennes, Y. Bai, B. Kim, K. Watanabe, T. Taniguchi, X. Zhu, J. Hone, A. Rubio, 

9 

A. N. Pasupathy, and C. R. Dean, Nature Materials 2020 19:8 **19** , 861 (2020). 

- [13] Y. Tang, L. Li, T. Li, Y. Xu, S. Liu, K. Barmak, K. Watanabe, T. Taniguchi, A. H. MacDonald, J. Shan, and K. F. Mak, Nature 2020 579:7799 **579** , 353 (2020). 

- [14] Y. Xu, K. Kang, K. Watanabe, T. Taniguchi, K. F. Mak, and J. Shan, Nature Nanotechnology **17** , 934 (2022), arxiv:2202.02055 [cond-mat]. 

- [15] E. Anderson, F.-R. Fan, J. Cai, W. Holtzmann, T. Taniguchi, K. Watanabe, D. Xiao, W. Yao, and X. Xu, “Programming Correlated Magnetic States via Gate Controlled Moir _\_ ’e Geometry,” (2023), arxiv:2303.17038 [cond-mat]. 

- [16] E. C. Regan, D. Wang, C. Jin, M. I. Bakti Utama, B. Gao, X. Wei, S. Zhao, W. Zhao, Z. Zhang, K. Yumigeta, M. Blei, J. D. Carlstr¨om, K. Watanabe, T. Taniguchi, S. Tongay, M. Crommie, A. Zettl, and F. Wang, Nature 2020 579:7799 **579** , 359 (2020). 

- [17] H. Li, S. Li, E. C. Regan, D. Wang, W. Zhao, S. Kahn, K. Yumigeta, M. Blei, T. Taniguchi, K. Watanabe, S. Tongay, A. Zettl, M. F. Crommie, and F. Wang, Nature 2021 597:7878 **597** , 650 (2021). 

- [18] Y. Xu, S. Liu, D. A. Rhodes, K. Watanabe, T. Taniguchi, J. Hone, V. Elser, K. F. Mak, and J. Shan, Nature 2020 587:7833 **587** , 214 (2020). 

- [19] T. Li, S. Jiang, B. Shen, Y. Zhang, L. Li, Z. Tao, T. Devakul, K. Watanabe, T. Taniguchi, L. Fu, J. Shan, and K. F. Mak, Nature 2021 600:7890 **600** , 641 (2021), arxiv:2107.01796. 

- [20] J. Cai, E. Anderson, C. Wang, X. Zhang, X. Liu, W. Holtzmann, Y. Zhang, F. Fan, T. Taniguchi, K. Watanabe, Y. Ran, T. Cao, L. Fu, D. Xiao, W. Yao, and X. Xu, “Signatures of Fractional Quantum Anomalous Hall States in Twisted MoTe2 Bilayer,” (2023), arxiv:2304.08470 [cond-mat]. 

- [21] Y. Zeng, Z. Xia, K. Kang, J. Zhu, P. Kn¨uppel, C. Vaswani, K. Watanabe, T. Taniguchi, K. F. Mak, and J. Shan, “Integer and fractional Chern insulators in twisted bilayer MoTe2,” (2023), arxiv:2305.00973 [condmat]. 

- [22] H. Park, J. Cai, E. Anderson, Y. Zhang, J. Zhu, X. Liu, C. Wang, W. Holtzmann, C. Hu, Z. Liu, T. Taniguchi, K. Watanabe, J.-h. Chu, T. Cao, L. Fu, W. Yao, C.-Z. Chang, D. Cobden, D. Xiao, and X. Xu, “Observation of Fractionally Quantized Anomalous Hall Effect,” (2023), arxiv:2308.02657 [cond-mat]. 

- [23] B. A. Foutty, C. R. Kometter, T. Devakul, A. P. Reddy, K. Watanabe, T. Taniguchi, L. Fu, and B. E. Feldman, Science **384** , 343 (2024). 

- [24] F. Xu, Z. Sun, T. Jia, C. Liu, C. Xu, C. Li, Y. Gu, K. Watanabe, T. Taniguchi, B. Tong, J. Jia, Z. Shi, S. Jiang, Y. Zhang, X. Liu, and T. Li, “Observation of integer and fractional quantum anomalous Hall states in twisted bilayer MoTe2,” https://arxiv.org/abs/2308.06177v2 (2023). 

- [25] A. Ghiotto, L. Wei, L. Song, J. Zang, A. B. Tazi, D. Ostrom, K. Watanabe, T. Taniguchi, J. C. Hone, D. A. Rhodes, A. J. Millis, C. R. Dean, L. Wang, and A. N. Pasupathy, “Stoner instabilities and Ising excitonic states in twisted transition metal dichalcogenides,” (2024), arxiv:2405.17316 [cond-mat]. 

- [26] N. D. Mathur, F. M. Grosche, S. R. Julian, I. R. Walker, D. M. Freye, R. K. W. Haselwimmer, and G. G. Lonzarich, Nature **394** , 39 (1998). 

- [27] Y. Cao, V. Fatemi, S. Fang, K. Watanabe, T. Taniguchi, E. Kaxiras, and P. Jarillo-Herrero, Nature **556** , 43 (2018). 

- [28] A. L. Sharpe, E. J. Fox, A. W. Barnard, J. Finney, K. Watanabe, T. Taniguchi, M. A. Kastner, and D. Goldhaber-Gordon, Science **365** , 605 (2019). 

- [29] M. Serlin, C. L. Tschirhart, H. Polshyn, Y. Zhang, J. Zhu, K. Watanabe, T. Taniguchi, L. Balents, and A. F. Young, Science **367** , 900 (2020). 

- [30] H. Zhou, T. Xie, T. Taniguchi, K. Watanabe, and A. F. Young, Nature **598** , 434 (2021). 

- [31] H. Zhou, L. Holleis, Y. Saito, L. Cohen, W. Huynh, C. L. Patterson, F. Yang, T. Taniguchi, K. Watanabe, and A. F. Young, Science **375** , 774 (2022). 

- [32] Y. Zhang, R. Polski, A. Thomson, ´E. LantagneHurtubise, C. Lewandowski, H. Zhou, K. Watanabe, T. Taniguchi, J. Alicea, and S. Nadj-Perge, Nature **613** , 268 (2023). 

- [33] C. Li, F. Xu, B. Li, J. Li, G. Li, K. Watanabe, T. Taniguchi, B. Tong, J. Shen, L. Lu, J. Jia, F. Wu, X. Liu, and T. Li, “Tunable superconductivity in electron- and hole-doped Bernal bilayer graphene,” (2024), arxiv:2405.04479 [cond-mat]. 

- [34] F. Wu, A. H. MacDonald, and I. Martin, Physical Review Letters **121** , 257001 (2018). 

- [35] B. Lian, Z. Wang, and B. A. Bernevig, Physical Review Letters **122** , 257002 (2019). 

- [36] M. Ochi, M. Koshino, and K. Kuroki, Physical Review B **98** , 081102 (2018). 

- [37] Y.-Z. Chou, F. Wu, J. D. Sau, and S. Das Sarma, Physical Review B **105** , L100503 (2022). 

- [38] C. Xu and L. Balents, Physical Review Letters **121** , 087001 (2018). 

- [39] H. Isobe, N. F. Q. Yuan, and L. Fu, Physical Review X **8** , 041041 (2018). 

- [40] H. Guo, X. Zhu, S. Feng, and R. T. Scalettar, Physical Review B **97** , 235453 (2018). 

- [41] S. Ray, J. Jung, and T. Das, Physical Review B **99** , 134515 (2019). 

- [42] D. V. Chichinadze, L. Classen, and A. V. Chubukov, Physical Review B **101** , 224513 (2020). 

- [43] S. Chatterjee, T. Wang, E. Berg, and M. P. Zaletel, Nature Communications **13** , 6013 (2022). 

- [44] J. Venderley and E.-A. Kim, Physical Review B **100** , 060506 (2019). 

- [45] K. Slagle and L. Fu, Physical Review B **102** , 235423 (2020). 

- [46] Y.-T. Hsu, F. Wu, and S. Das Sarma, Physical Review B **104** , 195134 (2021). 

- [47] C. Schrade and L. Fu, “Nematic, chiral and topological superconductivity in transition metal dichalcogenides,” (2021), arxiv:2110.10172 [cond-mat]. 

- [48] M. B´elanger, J. Fournier, and D. S´en´echal, Physical Review B **106** , 235135 (2022). 

- [49] M. M. Scherer, D. M. Kennes, and L. Classen, npj Quantum Materials **7** , 1 (2022). 

- [50] V. Cr´epel, D. Guerci, J. Cano, J. H. Pixley, and A. Millis, Physical Review Letters **131** , 056001 (2023). 

- [51] F. Chen and D. N. Sheng, Physical Review B **108** , L201110 (2023), arxiv:2302.06765 [cond-mat]. 

- [52] L. Holleis, C. L. Patterson, Y. Zhang, H. M. Yoo, H. Zhou, T. Taniguchi, K. Watanabe, S. Nadj-Perge, and A. F. Young, “Ising Superconductivity and Nematicity 

10 

in Bernal Bilayer Graphene with Strong Spin Orbit Coupling,” (2023), arxiv:2303.00742 [cond-mat]. 

- [53] L. Klebl, A. Fischer, L. Classen, M. M. Scherer, and D. M. Kennes, Physical Review Research **5** , L012034 (2023). 

- [54] Y.-M. Wu, Z. Wu, and H. Yao, Physical Review Letters **130** , 126001 (2023), arxiv:2203.05480 [cond-mat]. 

- [55] B. Zhou and Y.-H. Zhang, Physical Review B **108** , 155111 (2023). 

- [56] M. Zegrodnik and A. Biborski, Physical Review B **108** , 064506 (2023). 

- [57] Y.-M. Xie and K. T. Law, Physical Review Letters **131** , 016001 (2023). 

- [58] W. Akbar, A. Biborski, L. Rademaker, and M. Zegrodnik, “Topological superconductivity with mixed singlettriplet pairing in moir _\_ ’e transition-metal-dichalcogenide bilayers,” (2024), arxiv:2403.05903 [cond-mat]. 

- [59] T. G. Kiely and D. Chowdhury, “Continuous Wigner-Mott transition at $ _\_ nu=1/5$,” (2023), arxiv:2305.13355 [cond-mat]. 

- [60] J. Pack, Y. Guo, Z. Liu, B. S. Jessen, L. Holtzman, S. Liu, M. Cothrine, K. Watanabe, T. Taniguchi, D. G. Mandrus, K. Barmak, J. Hone, and C. R. Dean, “Chargetransfer Contact to a High-Mobility Monolayer Semiconductor,” (2023), arxiv:2310.19782 [cond-mat]. 

- [61] L. Wang, I. Meric, P. Y. Huang, Q. Gao, Y. Gao, H. Tran, T. Taniguchi, K. Watanabe, L. M. Campos, D. A. Muller, J. Guo, P. Kim, J. Hone, K. L. Shepard, and C. R. Dean, Science **342** , 614 (2013). 

- [62] K. Kim, M. Yankowitz, B. Fallahazad, S. Kang, H. C. P. Movva, S. Huang, S. Larentis, C. M. Corbet, T. Taniguchi, K. Watanabe, S. K. Banerjee, B. J. LeRoy, and E. Tutuc, Nano Letters **16** , 1989 (2016). 

- [63] S. Liu, Y. Liu, L. Holtzman, B. Li, M. Holbrook, J. Pack, T. Taniguchi, K. Watanabe, C. R. Dean, A. N. Pasupathy, K. Barmak, D. A. Rhodes, and J. Hone, ACS Nano **17** , 16587 (2023). 

- [64] M. Yankowitz, J. Xue, D. Cormode, J. D. SanchezYamagishi, K. Watanabe, T. Taniguchi, P. JarilloHerrero, P. Jacquod, and B. J. LeRoy, Nature Physics **8** , 382 (2012). 

- [65] V. Cr´epel and A. Millis, “Bridging the small and large in twisted transition metal dicalcogenide homobilayers: A tight binding model capturing orbital interference and topology across a wide range of twist angles,” https://arxiv.org/abs/2403.15546v2 (2024). 

- [66] M. R. Beasley, J. E. Mooij, and T. P. Orlando, Physical Review Letters **42** , 1165 (1979). 

- [67] X. Liu, Z. Wang, K. Watanabe, T. Taniguchi, O. Vafek, and J. I. A. Li, Science **371** , 1261 (2021). 

- [68] Z. Yang, M. Lange, A. Volodin, R. Szymczak, and V. V. Moshchalkov, Nature Materials **3** , 793 (2004). 

- [69] J. Bardeen, L. N. Cooper, and J. R. Schrieffer, Physical Review **108** , 1175 (1957). 

- [70] L. Balents, C. R. Dean, D. K. Efetov, and A. F. Young, Nature Physics **16** , 725 (2020). 

- [71] A. Fischer, L. Klebl, C. Honerkamp, and D. M. Kennes, Physical Review B **103** , L041103 (2021). 

- [72] H. Zhai, F. Wang, and D.-H. Lee, Phys. Rev. B **80** , 064517 (2009). 

- [73] D. J. Scalapino, Reviews of Modern Physics **84** , 1383 (2012). 

### **METHODS** 

### **Device fabrication** 

We use a thin polycarbonate film to pick up the exfoliated layers from SiO2 with the dry transfer method [61]. We use thin boron nitride as the dielectric spacer to increase the displacement field and density range in the phase diagram. Few layer graphites are used for top and bottom gates. We use few-layer graphite as contacts to the WSe2 layers and a thin RuCl3 flake is stacked in the contact region to improve contacts to the WSe2 layers. We stack the layers from top to bottom in the sequence of: topmost bn ( _∼_ 11nm) -graphite top gate - top bn ( _∼_ 5nm) - graphite contacts - twisted WSe2 layers - _α_ -RuCl3 layer - bottom bn ( _∼_ 17nm) - graphite bottom gate. The alignment of the graphite top gate, graphite contact and _α_ -RuCl3 is especially taken care of to make sure that the top gate is local to the channel region and avoid overlapping with the contact region. For stacking the twisted WSe2, we pre-cut a WSe2 monolayer into two pieces with an AFM tip. We pick up one of the pieces and rotate the transfer stage by about 5 degree before picking up the second piece. Finally we drop down the stack onto a SiO2 substrate. 

A metal contact gate is deposited on top of the stack to smooth out the gap between the heavily doped contact region by _α_ -RuCl3 and the intrinsic channel region. Metal leads to the gates and the graphite contacts are deposited after etching through the bn with the same PMMA mask. Finally, the device is etched into a Hall bar shape with alternating SF6 and O2 plasmas with a 30W O2 plasma at the end to etch through the _α_ -RuCl3 flake. PMMA is left on the chip after the etching process to avoid any exposure of _α_ -RuCl3 to solvents. The device is stacked and fabricated in the same way as in this reference[60]. See supplementary material for device image. 

### **Measurements** 

Transport measurements were performed in a variable temperature cryostat with a base temperature of 1.6 K and in a dilution fridge with a base temperature of 33 mK. Four and two terminal resistance measurements were carried out using a low-frequency lock-in technique at frequencies ranging from 6 Hz-25 Hz. Characterization for superconducting region is done with a current source bias of 5nA. IV characteristics were measured in DC using a sourcemeter and nanovoltmeters. dV/dI measurements were done using lockin SR860 to provide an AC signal on top of the DC signal. The current signal is amplified using a SR570 and measured with SR860s and a nanovoltmeter. 

11 

### **BKT temperature extraction** 

We plot _Vxx − I_ curves measured at different temperatures on a log-log scale (Fig. 2c inset). We extract the power at different temperatures in the transition region. To find the temperature where the curve follows _V ∝ I_<sup>3</sup> , we plot power versus temperature and interpolate to find where it crosses 3. (See SI) 

### **Theory** 

We used the formalism of Ref. [65] which presents a three band tight binding model with parameters fit to DFT calculations to determine the band structure. This paper gives parameters only for angles up to 4 _._ 5<sup>_◦_</sup> ; we extrapolated to 5<sup>_◦_</sup> , in the notations of Ref. [65] we find (all energies in meV) _δ_ = 15, _t_ 1<sup>_th_</sup> = 15, _t_<sup>_hh_</sup> 1 = 2 _t_<sup>_th_</sup> 2<sup>=0,</sup><sup>_ttt_</sup> 1<sup>=</sup><sup>_−_2,</sup><sup>_thh_</sup> 3 = 4 _._ and we considered displace- 

ment fields up to 18 _meV_ . We computed the band energies on a dense grid of _k_ -points in the Brillouin zone, identified the highest lying electron band _ε_<sup>3</sup> _k_<sup>andthen</sup> used these energies to construct the single-spin density of states _N_ 0( _ω_ ) = � _BZ_ (2 _<u>dπ</u>_<sup>2</sup> _<u>k</u>_ )<sup>2</sup><sup>_δ_(</sup><sup>_ω−ε_</sup> _k_<sup>3)andthetrans-</sup> _<u>d</u>_<sup>2</sup> _<u>k</u> f_ ( _ε_<sup>3</sup> _k_<sup>_,↑_</sup> ) _−f_ ( _ε_<sup>3</sup> _k_<sup>_,_</sup> <u>+</u><sup>_↓_</sup> _<u>q</u>_<sup>)</sup> verse _χ_<sup>_±_</sup> ( _q,_ 0) = _P_ � _BZ_ (2 _π_ )<sup>2</sup> _ε_<sup>3</sup> _k_<sup>_,↑_</sup> _−ε_<sup>3</sup> _k_<sup>_,_</sup> +<sup>_↓_</sup> _q_ and longitu- _<u>d</u>_<sup>2</sup> _<u>k</u> f_ ( _ε_<sup>3</sup> _k_<sup>_,σ_</sup> ) _−f_ ( _εk_<sup>3</sup><sup>_,σ_</sup> <u>+</u> _<u>q</u>_<sup>)</sup> dinal _χ_<sup>_zz_</sup> ( _q,_ 0) = _P_<sup>�</sup> _σ_ � _BZ_ (2 _π_ )<sup>2</sup> _ε_<sup>3</sup> _k_<sup>_,σ_</sup> _−ε_<sup>3</sup> _k_<sup>_,σ_</sup> + _q_ susceptibilities ( _P_ denotes principal value). At this level of approximation there is no qualitative difference between the longitudinal and transverse susceptibilities. Fig SI. 7 show the density of states for different displacement fields. 

### **DATA AVAILABILITY** 

The data that support the plots within this paper and other findings of this study are available from the corresponding author upon reasonable request. 

