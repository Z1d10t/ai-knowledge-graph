# Generation of long-lived charges in organic semiconductor heterojunction nanoparticles for efficient photocatalytic hydrogen evolution

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Energy |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 332 |
| 作者 | J. Koščo, Soranyel González-Carrero, Calvyn T. Howells, Teng Fei, Yifan Dong, R. Sougrat, G. Harrison, Yuliar Firdaus et al. |
| DOI | 10.1038/s41560-022-00990-2 |
| 源文件 | 050_Koščo_2022_Generation-of-long-lived-charges-in-organic-semi.pdf |

---
### **Title** 

## **Generation of remarkably long-lived charges in organic semiconductor heterojunction nanoparticles to enable efficient photocatalytic hydrogen evolution** 

### **Author list** 

Jan Kosco<sup>1</sup> *, Soranyel Gonzalez-Carrero<sup>1</sup> , Calvyn T. Howells, Teng Fei, Yifan Dong, Rachid Sougrat, George T. Harrison, Yuliar Firdaus, Rajendar Sheelamanthula, Balaji Purushothaman, Floriana Moruzzi, Weidong Xu, Lingyun Zhao, Aniruddha Basu, Stefaan De Wolf, Thomas D. Anthopoulos, James R. Durrant*, Iain McCulloch* 

### **Affiliations** 

Dr. Jan Kosco, Dr. Calvyn T. Howells, Dr. George T. Harrison, Dr. Yuliar Firdaus, Dr. Rajendar Sheelamanthula, Dr. Balaji Purushothaman, Dr. Aniruddha Basu, Prof. Stefaan De Wolf Prof. Thomas Anthopolous, Prof. Iain McCulloch 

King Abdullah University of Science and Technology (KAUST), KAUST Solar Center (KSC), Physical Sciences and Engineering Division (PSE), Thuwal 23955-6900, Kingdom of Saudi Arabia. 

Dr. Soranyel Gonzalez-Carrero, Teng Fei, Dr. Yifan Dong, Weidong Xu, Prof. James R. Durrant 

Department of Chemistry and Centre for Processable Electronics, Imperial College London, Exhibition Road, London, SW7 2AZ, United Kingdom. 

Dr. Rachid Sougrat, Dr. Lingyun Zhao 

KAUST Core Labs, King Abdullah University of Science and Technology (KAUST), Thuwal, 23955–6900 Kingdom of Saudi Arabia 

Floriana Moruzzi, Prof. Iain McCulloch 

Department of Chemistry, University of Oxford, 12 Mansfield Road, Oxford, OX1 4BH, UK 

Email: j.durrant@imperial.ac.uk; iain.mcculloch@kaust.edu.sa; jan.kosco@kaust.edu.sa 

## **Abstract:** 

Organic semiconductor photocatalysts for the production of solar fuels are attractive as they can be synthetically tuned to absorb visible light while simultaneously retaining suitable energy levels to drive a range of processes. However, a greater understanding of the photophysics that determine the function of organic semiconductor heterojunction nanoparticles is needed to optimise performance. Here, we show that such materials can intrinsically generate remarkably long-lived reactive charges, enabling them to efficiently drive sacrificial hydrogen evolution. Our optimized hetereojunction photocatalysts comprise the conjugated polymer PM6 matched with Y6 or PCBM electron acceptors and achieve external quantum efficiencies of 1.0% to 5.0% at 400 to 900 nm and 8.7% to 2.6% at 400 to 700 nm, respectively. Employing transient and operando spectroscopies, we find that the heterojunction structure in these nanoparticles greatly enhances the generation of long-lived charges (ms-s timescale) even in the absence of electron/hole scavengers or Pt. Such longlived reactive charges open potential applications in water splitting Z-schemes and in driving kinetically-slow and technologically-desirable oxidations. 

**Main text** 

## **Introduction:** 

To limit the effects of climate change, fossil fuels must urgently be replaced by carbon neutral energy sources.<sup>1</sup> Solar energy is by far the most abundant form of renewable energy but its intermittency impedes its ability to supply energy on demand.<sup>2</sup> Storing solar energy in the chemical bonds of a fuel is therefore highly desirable.<sup>3</sup> Hydrogen (H2) generated from water using solar energy is one of the most promising such “solar fuels”. H2 can generate heat via combustion, or electricity if combined with oxygen in a fuel cell.<sup>4</sup> In both cases, water is the only by-product. Solar H2 can be generated using photovoltaic electrolysis (PV-E),<sup>5</sup> photoelectrochemical cells (PEC),<sup>6</sup> or photocatalysis. A “particulate” system in which photocatalyst particles are dispersed in water is projected to be the cheapest method of generating solar H2.<sup>7</sup> This has stimulated an intense research effort to develop particulate photocatalysts for H2 evolution, O2 evolution and overall water splitting.<sup>8–10</sup> 

Photocatalysts based on primarily UV-active inorganic semiconductors have been the most widely studied to date. Overall water splitting was first achieved using TiO2,<sup>11</sup> and has recently been reported with an external quantum efficiency (EQE) of 96% at UV wavelengths (350-360 nm) using Al doped SrTiO3.<sup>12</sup> However, less than 5% of solar energy lies in the UV spectrum.<sup>13</sup> Visible light active photocatalysts are therefore needed to meet the Solar to Hydrogen conversion efficiency (ηSTH) target of 5-10% deemed necessary for commercial viability.<sup>7</sup> This has led to the recent interest in developing photocatalysts based on organic semiconductors which can be synthetically tuned to absorb visible light while simultaneously retaining suitable energy levels to drive a range of photocatalytic processes.<sup>14,15</sup> Particular attention has been given to developing photocatalysts capable of driving the hydrogen evolution reaction (HER) from aqueous solutions containing a hole scavenger.<sup>14,15</sup> 

Organic nanoparticles (NPs) that contain a donor/acceptor (D/A) heterojunction are currently among the most efficient visible light active H2 evolution photocatalysts (HEPs).<sup>16–18</sup> However, their active wavelength ranges and EQEs must be increased to achieve practical ηSTH. For example, a HEP operating in a Z-scheme<sup>10</sup> with an O2 evolution catalyst (OEP) that is active up to 500 nm must achieve a minimum EQE of 30% at wavelengths up to 750 nm, or a minimum EQE of 20% at wavelengths up to 1000 nm for the Z-scheme to drive overall water splitting with 5% ηSTH (Supplementary Figure 1). Moreover, studies addressing the photophysics that determine the function of heterojunction photocatalysts have been very limited to date, complicating the systematic optimization of photocatalyst performance. 

In this work, we develop two organic NP HEPs containing a donor/acceptor (D/A) heterojunction. The NPs are formed from blends of the donor polymer PBDB-T-2F (PM6, 1) matched with either the narrow 

bandgap nonfullerene acceptor BTP-4F (Y6, 2) or the fullerene [6,6]-Phenyl C71 butyric acid methyl ester (PCBM, 3). Both NP photocatalysts are among the most efficient organic HEPs reported to date. 

## **Nanoparticle fabrication and optimization** 

Blends of the PM6 donor polymer matched with either Y6 or PCBM electron acceptors were processed into NPs using the miniemulsion method.<sup>19</sup> The NP size distributions were measured by dynamic light scattering (Supplementary Figure 2, Supplementary Tables 1-2). The organic semiconductor combinations were chosen based on their strong visible light absorption (Supplementary Figure 3), type II energy level offsets, and their ability to efficiently convert absorbed photons to photogenerated charges when blended in a bulk heterojunction organic solar cell.<sup>20–22</sup> Furthermore, their energy levels are suitably aligned with respect to the proton reduction and ascorbic acid (AA) oxidation potentials so that photogenerated electrons in the Y6 or PCBM LUMO have  a suitable potential to reduce protons, and photogenerated holes in the PM6 HOMO have a suitable potential to oxidise AA ( **Figure 1** ). 

NPs formed from a range of PM6:Y6 and PM6:PCBM blend compositions were tested for photocatalytic H2 evolution to determine the optimum D:A ratio in each blend ( **Error! Reference source not found.** ). H2 evolution was measured in the presence of AA and Pt that was photodeposited in situ on the organic NP surface.<sup>23</sup> The Pt catalyzes H2 evolution driven by the transfer of photogenerated electrons from the organic NPs,  providing sites for proton adsorption and electron accumulation.<sup>24,25</sup> The AA extracts photogenerated holes from the organic NP, and becomes oxidised to dehydroascorbic acid. 

All NPs composed of a D/A blend achieved higher HER rates than those formed of the pristine semiconductors. This was attributed to improved charge generation in the blend NPs compared to NPs comprised of the individual semiconductors due to the presence of a D/A heterojunction in the NP, as evidenced by the photophysical studies detailed below. Increasing the Y6 fraction in the PM6:Y6 blend increased the HER rate to a maximum at PM6:Y6 7:3 (9.9 µmolh<sup>-1</sup> cm<sup>-2</sup> ) after which further increasing the Y6 fraction decreased the HER rate. In contrast, the maximum HER rate for the PM6:PCBM NPs was obtained at PM6:PCBM 2:8 (11.3 µmolh<sup>-1</sup> cm<sup>-2</sup> ) and decreased rapidly when the PCBM fraction was increased further. Optimizing the Pt loading (Supplementary Figure 6) further increased the average HER rate over 16 h of the PM6:PCBM 2:8 NPs to a maximum of 16.7 µmolh<sup>-1</sup> cm<sup>-</sup> 2 (73.7 mmolh-1g-1) at 5% Pt. Interestingly, the PM6:PCBM 2:8 NPs exhibit higher HER rates than the 

PM6:Y6 7:3 NPs even though the absorption cutoff of the PM6:Y6 7:3 NPs extends approximately 200 nm further into the visible-NIR spectrum. 

The EQE spectrum of the PM6:Y6 7:3 NPs (Figure 3a) reveals that they are active throughout the entire visible wavelength range and continue to be active at near infrared (NIR) wavelengths, which have thus far been under-utilized in most HEPs. We note that quantitative comparison of EQE vs HER rates is complicated by the potential for a non-linear dependence of efficiency upon light intensity. Nevertheless these EQE data are both the broadest wavelength range (from ≤400 nm to ≥900 nm) and the longest single wavelength (900 nm) at which H2 evolution has been reported for an organic photocatalyst to date.<sup>14,26,27</sup> Furthermore, the EQEs at 750-900 nm are comparable to those of some of the most efficient noble metal based plasmonic HEPs; a class of inorganic photocatalysts that are active at NIR wavelengths.<sup>28,29</sup> This highlights the potential of D/A NP photocatalysts that employ narrow bandgap organic semiconductors such as Y6 to efficiently harvest solar photons over a broad spectrum of visible to NIR light. Nevertheless, the optimized PM6:PCBM 2:8 NPs achieve a higher HER rate than the PM6:Y6 NPs due to their approximately 2.5 times higher EQEs throughout the visible spectrum (Figure 3). Moreover, these NPs <mark>are operationally stable for ≥72h (Supplementary Table 3, Supplementary Figure 7).</mark><sup>14,17,18,30</sup> 

## **Nanoparticle imaging** 

Imaging the NPs by cryogenic Transmission Electron Microscopy (cryo-TEM) revealed that the PM6:Y6 NPs contain numerous crystalline domains with lattice spacings of 2.1 to 2.2 nm clearly visible as lines of alternating high and low electron density, Figure 4 and Supplementary Figures 8-17. These spacings correspond to diffraction peaks at q = 0.285 Å<sup>-1</sup> (d = 21.9 Å) and q = 0.300 Å<sup>-1</sup> (d = 20.9 Å) observed in thin films of PM6 and Y6 respectively by grazing incidence wide angle x-ray scattering measurements.<sup>20</sup> Similar spacings are also visible in pure PM6 and pure Y6 NPs (Supplementary Figures 15-16). Because the lattice spacings of PM6 and Y6 are similar, the images do not reveal which domains correspond to Y6 and which domains correspond to PM6. However, it can be clearly seen that neither component forms a shell, and that the NP contains many randomly arranged semicrystalline domains. This suggests that the PM6:Y6 NPs have an intermixed morphology formed of randomly distributed PM6 and Y6 domains. In contrast, the PM6:PCBM NPs display a core/shell structure, with a 5-10 nm PM6 shell partially surrounding a single large PCBM core domain. The 2.0 nm lattice spacing in the shell corresponds to the PM6 lamellar stacking distance,<sup>20</sup> while the structure of the core domain resembles that of pure PCBM NPs (Supplementary Figure 17). The different morphologies of the PM6:Y6 and PM6:PCBM NPs are most likely due to the different miscibilities of 

the semiconductor blends. PM6 and Y6 are highly miscible,<sup>31</sup> which favours an intermixed NP morphology, whereas PM6 and PCBM have low miscibility,<sup>21</sup> which leads to their phase separated core/shell morphology. 

Examining the NP photocatalysts after Pt photodeposition revealed that both the PM6:Y6 NPs (Figure 4b) and the PM6:PCBM NPs (Figure 4d) allow deposition of approximately 1-2 nm diameter Pt particles on their surface. The Pt is distributed fairly uniformly over the PM6:Y6 NP surface but on the PM6:PCBM NPs it is preferentially localized on exposed sections of the PCBM core (see Supplementary Discussion 1 for an explanation of this observation). Consistent with the more efficient localization of Pt on exposed acceptor domains in the PM6:PCBM NPs, we found that the PM6:Y6 NPs require a higher Pt loading for optimum performance (10% and 5% respectively, Supplementary Figure 6). 

## **Photophysical characterization** 

We turn now to the photophysical analyses of the high efficiency of these HEPs, and in particular the higher EQEs obtained with the PM6:PCBM NPs. Photoluminescence (PL) spectra were collected to explore the exciton dissociation following either donor or acceptor photoexcitation in the NPs. Following excitation of PM6 at 630 nm, the PM6:PCBM NPs exhibit strong PL quenching (PLQ) of PM6 excitons (at 700 nm) relative to neat PM6 NPs at all compositions (PLQ > 96 %), indicative of efficient electron transfer from PM6 excitons to the PCBM acceptor ( **Figure 5** a). In contrast, partially selective excitation of PCBM at 470 nm showed inefficient PLQ of PCBM excitons at all compositions (PLQ < 60 %, Figure 5b). These PLQ efficiencies are consistent with the core / shell morphology of these NPs determined from our cryo-TEM data. The thin PM6 shell facilitates PM6 exciton diffusion to heterojunction interfaces, whilst  the lower separation efficiencies observed for PCBM excitons is attributed to the presence of a PCBM core with dimensions larger than the exciton diffusion lengths reported previously for PCBM excitons (~ 5 nm).<sup>32,33</sup> However, PCBM absorption in these NPs is only significant at ultraviolet wavelengths (Supplementary Figure 3). The low efficiency of PCBM exciton separation is therefore unlikely to impact significantly on their solar to hydrogen conversion efficiency. 

The PM6:Y6 NPs exhibited more complex PL data. Following selective excitation of PM6 at 532 nm, all heterojunction NPs exhibited strong PLQ of PM6 exciton at 700 nm. Additionally, an increase of the Y6 PL intensity was observed with increasing PM6 content (Figure 5c), indicative of energy transfer from PM6 to Y6. This observation is consistent with previous reports of ultrafast energy transfer from PM6 to Y6 in bulk heterojunction films, resulting from spectral overlap of PM6 emission and Y6 absorption (Supplementary Figure 18).<sup>34</sup> This energy transfer is likely to operate in parallel with electron transfer from PM6 to Y6, as we discuss further below. It is also notable that Y6 PL blue shifts 

with increasing PM6 content, which would be consistent with a reduction in Y6 crystallinity (this blue shift was observed in the Y6 optical absorption onset, Supplementary Figure 3). Following selective excitation of Y6 at 780 nm (Figure 5d), Y6 emission quenching was observed to be relatively modest, being maximal (PLQ ~ 50%) for a PM6:Y6 composition ratio of 60:40. This composition for maximal Y6 PLQ is similar to the composition observed for maximal H2 generation. This modest Y6 PLQ is indicative of relatively inefficient hole transfer from Y6 excitons to PM6, which may result from the presence of Y6 domains in the intermixed morphology of the PM6:Y6 NPs with a similar length scale to the Y6 exciton diffusion length (measured as 4.8 nm in films),<sup>35</sup> or from an insufficient interfacial energy offset.  In any case, it is likely that a relatively low Y6 exciton separation efficiency is a key factor behind the lower H2 evolution EQEs observed for PM6:Y6 NPs compared to PM6:PCBM, and also explains the reduction in EQE observed for higher Y6 content in these NPs. 

We turn now to ultrafast transient absorption spectroscopy (uf-TAS) to study the dynamics of charge photogeneration in selected NPs on the picosecond time scale. **Figure 6** shows the uf-TAS spectra of PM6, PM6:PCBM 2:8 and PM6:Y6 7:3 NPs in the visible and NIR spectral regions after excitation of PM6 at 550 nm. The uf-TAS spectra of PM6 NPs (Figures 6a) exhibit a broad ground state bleaching (GSB) between 450 nm and 650 nm together with a photoinduced absorption (PIA) with maximum in the NIR region at 1150 nm, attributed to PM6 singlet exciton absorption. These spectral features decay with a half-time of circa 10 ps (Figure 6b), assigned to exciton decay to ground (see Supplementary Figure 19 for excitation density dependence and discussion thereof).<sup>35–37</sup> In PM6:PCBM NPs (Figure 6c), the 1150 nm PM6 exciton absorption feature is strongly reduced in amplitude compared to neat PM6 NPs, and decays completely within 1 ps, assigned to ultrafast, sub-ps electron transfer from PM6 to PCBM, with the residual long lived absorption at this wavelength assigned to PM6<sup>+</sup> absorption (see also Figure 6b and deconvoluted spectra and kinetics in Supplementary Figure 20). This electron transfer is > 40 times faster than PM6 exciton decay to ground, indicative of a near unity exciton separation efficiency, which is in agreement with the efficient PM6 PLQ described above (Figure 5a). For time delays ≥ 1 ps, a long-lived PIA is observed between 700 and 900 nm, assigned to PM6<sup>+</sup> polaron absorption, concomitant with a PM6 GSB signal. These features exhibit relatively slow, excitation density dependent kinetics (half-times ranging from 200 ps to > 6 ns as the excitation density was decreased, Supplementary Figure 21), indicative of their assignment to the bimolecular recombination of separated PM6<sup>+</sup> and PCBM<sup>—</sup> species. For PM6:Y6 NPs, additional features assigned to Y6 GSB at 700-850 nm and Y6 exciton absorption at 925 nm are observed (Figure 6d, see also Supplementary Figures 22-23 for data employing selective Y6 excitation), respectively. PM6 exciton absorption at 1150 nm is observed to be quenched relative to neat PM6 NPs, although this quenching is less strong than for PM6:PCBM NPs, with a residual decay extending for several ps (Figures 6c, d). This quenching 

is assigned to ultrafast electron and energy transfer from PM6 excitons to Y6, as indicated by our PL data discussed above (see more detailed discussion below and Supplementary Figure 24). Overall it can be concluded that PM6 exciton separation in PM6:PCBM NPs occurs with a near unity efficiency in less than 1 ps (Figure 6e). PM6:Y6 NPs exhibit more complex charge generation photophysics, including energy transfer from PM6 to Y6 as well as electron and hole transfer (Figure 6e), and a lower overall charge generation efficiency. 

Ultrafast transient absorption kinetics for PM6:PCBM NPs were observed to be essentially independent of the presence of Pt or AA, indicating that the kinetics of electron/hole transfer to these species occurred on longer (> 6 ns) timescales. To elucidate these kinetics on longer timescales, TAS data on the µs-ms timescales were collected in the presence / absence of Pt and AA for both PM6:PCBM 2:8 and PM6:Y6 7:3 NPs. The TAS spectra are shown in Supplementary Figures 25-26, exhibiting PM6<sup>+</sup> GSB at 550-650 nm and polaron absorption from 650-1050 nm, as well as, for PM6:Y6 NPs, a Y6 GSB signal at 850 nm. The corresponding kinetics at 700 nm, assigned to PM6<sup>+</sup> , are plotted in **Figure 7** . It is apparent that in the absence of AA and Pt, PM6:PCBM NPs exhibit a larger amplitude and longer lived decay transient than PM6:Y6 NPs assigned to slower bimolecular recombination kinetics in the PM6:PCBM NPs, consistent with their more phase segregated core/shell structure.  In the presence of Pt, both NP systems exhibited larger amplitude, longer lived PM6<sup>+</sup> absorption, consistent with suppressed bimolecular recombination due to electron transfer to Pt. The further addition of AA resulted in an accelerated decay of this PM6<sup>+</sup> absorption, consistent with hole transfer to AA. This acceleration was most significant for PM6:Y6 NPs indicating that the lower EQE observed for these NPs does not result from slower hole scavenging by AA. For PM6:PCBM NPs, hole scavenging by AA proceeds on the 10 s timescale, which is much slower than the kinetics of hole scavenging by triethyl amine (10 ps – 1 ns) reported for other polymer photocatalysts.<sup>26</sup> It is striking that even with these relatively slow hole scavenging kinetics, PM6:PCBM NPs still achieve efficient solar to hydrogen conversion, as we discuss further below. 

We now turn to explore the photophysics of our NPs measured on the seconds time scale under operando conditions by using Photoinduced Absorption Spectroscopy (PIAS).<sup>38,39</sup> Dispersions of neat PM6, PM6:PCBM 2:8 and PM6:Y6 7:3 heterojunction NPs were irradiated with quasi-continuous LED pulses (4 s duration, 20 mW cm<sup>-2</sup> at 630 nm) and the change in the absorbance was recorded at different probe wavelengths, Figure 7. 

Remarkably, when measured under these operando conditions, both heterojunction NPs showed long lived (seconds timescale) PIAS signals even in the absence of Pt or sacrificial hole scavenger (Figure 7c). These signals exhibit similar spectral features (Figure 7d) to the transient absorption data shown 

in Figure 6 and are therefore assigned to long lived PM6<sup>+</sup> species. Negligible signals were obtained for neat PM6 NPs (Figure 7c,d), confirming that these remarkably long-lived charges result from charge separation due to the heterojunctions present in our PM6:PCBM and PM6:Y6 NPs. Furthermore, the PM6:PCBM NPs exhibited a higher PIA amplitude than the PM6:Y6 NPs, indicative of a higher accumulation of long lived photogenerated charges in the PM6:PCBM NPs. In the presence of Pt, the PM6<sup>+</sup> PIAS signals increased in amplitude for both heterojunction nanoparticles, indicative of electron transfer to Pt increasing the accumulation of long-lived PM6<sup>+</sup> species. 

The addition of AA resulted in almost complete quenching of PM6<sup>+</sup> signals, indicative of efficient hole extraction in both heterojunction NPs. These observations are consistent with our TAS studies above. Moreover, they indicate that the long-lived PIAS signals observed in the absence of AA indeed result from reactive PM6<sup>+</sup> species. We note that in PM6:Y6 nanoparticles in the presence of Pt and AA, a small residual PIAS signal was observed (Figure 7f) with a spectral shape indicative of long lived Y6 anions unable to transfer to Pt, possibly originating from isolated Y6 domains in the NP bulk. Overall these operando PIAS data indicate that photoexcitation of both PM6:PCBM and PM6:Y6 NPs result in the accumulation of remarkably long-lived charges observable on the seconds timescale. The observation of higher charge accumulation for PM6:PCBM compared to PM6:Y6 NPs is most likely associated with their more phase segregated morphology as indicated from our TEM data, and correlates with their higher hydrogen generation EQEs measured under continuous irradiation. 

Our observation that photoexcitation of both PM6:PCBM and PM6:Y6 heterojunction NPs results in the accumulation of remarkably long lived charges even in the absence of added electron or hole scavengers is particularly striking. These long-lived charges were not observed for PM6 NPs alone. From the amplitude of these signals, we estimate our quasi-steady state irradiation results in the accumulation of circa 600 PM6<sup>+</sup> species per PM6:PCBM NP, with an approximately three fold lower accumulation density for the PM6:Y6 NPs. The H2 evolution rate per NP for the PM6:PCBM NPs compared to the PM6:Y6 NPs displays a similar, 2.3 fold difference, which is consistent with these long-lived charges being responsible for the high photocatalytic activity of the NPs (See Supplementary Method 1 for the associated calculations and error estimations). 

In other single component conjugated polymer NPs, such long lived charges (in this case polymer anions) were only observed in the presence of high concentrations (typically 30% v/v) of triethylamine.<sup>40</sup> Similarly, long lived PIAS signals for carbon nitride photocatalysts have only been reported upon the addition of hole scavengers.<sup>41</sup> For metal oxides, such long lived PIAS or TAS signals are typically only observed under strong electrical bias to extract either electrons or holes, or in the 

presence of electron / hole scavengers or co-catalysts.<sup>42,43</sup> The generation of such remarkably longlived charge carriers in both NPs without added electron / hole scavengers can be attributed primarily to their D/A heterojunction structure which enables the spatial separation of photogenerated charges. We note that in organic solar cells employing analogous bulk heterojunctions such as PM6:Y6, charge recombination measured operando using small perturbation techniques occurs primarily on the microsecond timescale,<sup>35</sup> making our observation herein of such long lived charge accumulation in our NPs even more remarkable. This conclusion is supported by no measurable long-lived charge accumulation being observed in PIAS studies of spin coated PM6:PCBM 2:8 films (Figure 7c, insert). In any case, the ability of these heterojunction NPs to generate long lived charges is likely to be critical to their high performance in the presence of the relatively slow (Figures 7a-b) hole scavenger ascorbic acid, and opens up potential applications of these NPs for driving alternative, kinetically slow and technologically more desirable oxidations, or in water splitting Z-schemes where they could be interfaced with a range of O2 evolution photocatalysts using a suitable redox mediator.<sup>10</sup> 

## **Performance comparison** 

Finally, the HER rates of the optimized PM6:Y6 7:3 and PM6:PCBM 2:8 NPs were compared to a range of benchmark HEPs (Figure 8). H2 evolution was measured under AM1.5g irradiation at 100 mWcm<sup>-2</sup> (1 sun intensity) and the HER rates were normalized to the illumination area rather than to the photocatalyst mass. This is intended to aid the comparison of the data presented in this manuscript with those measured by other research groups. See Supplementary Note 1. 

The average HER rates over 16 h of the optimized PM6:Y6 7:3 and PM6:PCBM 2:8 NPs (9.9 ± 1.0 µmolh<sup>-</sup> 1cm-2 and 16.7 ± 1.6 µmolh-1cm-2 respectively) were almost 20 and over 30 times higher than that of commercial CN (0.5 ± 0.1 µmolh<sup>-1</sup> cm<sup>-2</sup> ) over 3 and 5 times higher than that of P25 TiO2 (3.1 ± 0.1 µmolh<sup>-</sup> 1cm-2), and 1.3 and 2.2 times greater than that of PTB7-Th:EHIDTBR NPs (7.5 ± 0.1 µmolh-1cm-2), an efficient organic HEP.<sup>16</sup> Furthermore, the optimized PM6:PCBM NPs utilize the Pt co-catalyst more efficiently than the PM6:Y6 NPs or any of the benchmark photocatalysts, as evidenced by their greatly enhanced HER rates per mole of Pt (Figure 8b). This can be attributed to the efficient generation of long lived charges in the PM6:PCBM heterojunction as detailed above and their relatively low (5wt.%) optimum Pt loading. 

## **Conclusion:** 

Organic semiconductor NP H2 evolution photocatalysts composed of PM6:Y6 and PM6:PCBM blends were developed. The optimized PM6:Y6 NPs achieved a HER rate of 9.9 µmolh<sup>-1</sup> cm<sup>-2</sup> (43.9 mmolh<sup>-1</sup> g<sup>-1</sup> ) 

and were active from ≤400 nm to ≥900 nm. The optimized PM6:PCBM NPs achieved EQEs of 8.7% to 6.6% at 400 to 620 nm and a HER rate of 16.7 µmolh<sup>-1</sup> cm<sup>-2</sup> (73.7 mmolh<sup>-1</sup> g<sup>-1</sup> ) under a light intensity of 1 sun. Photophysical characterization using a combination of TAS and PIAS revealed that efficient exciton dissociation took place at the D/A heterojunctions within the NPs, leading to the accumulation of remarkably long lived photogenerated charges even in the absence of added Pt or AA. These charges were efficiently extracted upon the addition of the Pt co-catalyst and AA, which suggests that they were responsible for the photocatalytic activity of the NPs. The PM6:PCBM NPs exhibited faster charge generation and greater long lived charge accumulation than the PM6:Y6 NPs, with the latter attributed to their more phase segregated nanomorphology more effectively retarding charge recombination. This is consistent with their higher EQEs compared to the PM6:Y6 NPs. These results demonstrate that organic photocatalysts that contain a D/A heterojunction can intrinsically dissociate excitons to generate long-lived, reactive charges without relying on rapid reductive exciton quenching<sup>40,44,49</sup> by a sacrificial reagent to drive charge separation. This marks an important step towards designing efficient organic photocatalysts that can operate without the aid of undesirable sacrificial reagents. 

## **Methods** 

## **Materials:** 

PM6 and Y6 were purchased from 1material. PC71BM was purchased from Ossila. Sodium 2-(3thienyl)ethyloxybutylsulfonate (TEBS) was purchased from Solaris Chem. All materials were used without further purification. 

## **Nanoparticle fabrication:** 

Individual stock solutions (0.50 mg/mL) of PM6, Y6, and PC71BM were prepared in chloroform. The solutions were heated overnight (80 °C) to ensure complete dissolution and filtered (0.2 um PTFE). Nanoparticle precursor solutions were prepared from the stock solutions by mixing them in the ratio of the desired nanoparticle composition. 5 mL of the nanoparticle precursor solution was then added to a 0.5 wt.% solution of sodium 2-(3-thienyl)ethyloxybutylsulfonate (TEBS) in MilliQ water (10 mL), and stirred vigorously for 15 min at 40 °C to form a pre-emulsion, which was then sonicated for 5 min with an ultrasonic processor (Sonics VibraCell VCX130PB) to form a mini-emulsion. The mini-emulsion was heated at 85 °C under a stream of air to remove the chloroform, leaving a surfactant stabilised nanoparticle dispersion in water.<sup>16</sup> 

## **DLS:** 

The size distribution of each nanoparticle batch was measured by dynamic light scattering (DLS, Malvern Zetasizer ZS, Supplementary Figure 2 and Supplementary Tables 1-2). Supplementary Figure 2 shows that all NP batches had unimodal size distributions and that the Zavg hydrodynamic diameter within each series remained relatively constant. This is important when comparing HER rates between nanoparticles with different compositions because NP size affects the total available surface area, which may affect the HER rate. Having samples with similar size distributions minimises this variation and allows the effects of nanoparticle composition and morphology to be isolated.<sup>16</sup> 

## **Energy level measurement using UPS-IPES:** 

Ultraviolet photoelectron spectroscopy (UPS) and inverse photoemission spectroscopy (IPES) were conducted within the same interconnected UHV (10 -10 mbar) ScientaOmicron multi-probe system, with UPS measured first and then IPES. Samples were prepared by spincoating (4000 rpm, 2-5mgml<sup>-1</sup> ) in a nitrogen glove box on freshly evaporated Au/Si(100) and transferred to vacuum mounted in electrical contact to Omicron style plates. UPS was conducted with a He(1) vacuum ultraviolet source (focus) with and a Sphere II hemispherical electron analyser with a 7-channeltron detector, with a 5 eV pass energy. Samples were recorded under a negative bias of 9.97 V to observe the secondary electron cut-off. IPES was recorded in a home-built system which consisted of a spherical chamber, which housed: a manipulator to hold the sample and apply a retarding bias of 20 V, an internal electron source gun (Staib) with a BaO cathode, with a 0.25-0.5 energy dispersion, internal lens collimator in which light can pass through a quartz window into an assembly of a further lens, band pass filter (280 nm, 4.43 eV) and solid state PMT detector (hammatsu). Spectra were acquired by ramping the electron source energy in the range of 20-30 eV and monitoring the raw PMT intensity. The Ef position and analyser work function was calibrated by measuring the Ef step-edge of a clean Ar+ Au film, the spectra were merged on the same binding energy scale (w.r.t local surface vacuum level) by taking into account the measured work functions in UPS and electron affinity measured in IPES. The energetic onsets (HOMO, LUMO) were 

determined by an approximate linear extrapolation at the edge of the spectra. Uncertainity is estimated at 0.05 eV for UPS and 0.05-0.1 eV for IPES. 

## **Energy level measurement using photoelectron emission spectroscopy in air (PESA) and UV-Visible absorption spectroscopy:** 

Measurements were carried out on thin films of the individual semiconductors spin coated on plasma cleaned glass substrates. The semiconductor workfunction (corresponding to the HOMO energy level) was measured by PESA using a Riken AC-2 Photoelectron Spectrometer. The semiconductor band gap (Eg) was estimated from the absorption onset (λ) measured using an Agilent Cary 5000 UV-Vis-NIR spectrometer using Equation 1. The semiconductor LUMO energy level was estimated using Equation 2.<sup>16</sup> 

Equation 1: Eg (eV) = 1240/λ (nm) 

Equation 2: LUMO (eV) = HOMO (eV) – Eg (eV) 

## **CryoTEM:** 

Cryo Transmission Electron Microscopy (cryoTEM) was carried out with a Thermo-Fisher Scientific Titan Krios 80-300 TEM equipped with a Gatan GIF Quantum 968 energy-filter and a Gatan K2 complementary metal oxide semiconductor (CMOS) camera, to enable the recording of highresolution images at extremely low electron dose conditions (~1 e/Å<sup>2</sup> ). Specimen preparation of cryoTEM samples was carried out by using an automated plunge-freezing tool (Vitrobot Mark-IV). The specimens were prepared on carbon coated copper TEM-grids (Quatifoil MultiA). 3.5 µL of the nanoparticle dispersion was placed on the grid followed by 1 second of blotting-time and plungefreezing into liquid ethane cryogen. The cryoTEM analysis was performed by setting the microscope at the accelerating voltage of 300 kV. The images were recorded under dose-fractionation conditions to minimise beam exposure time and therefore beam damage to the samples. The total electron dose given to images, acquired at low-magnifications (<50,000X) was kept below 10 e/Å<sup>2</sup> . Whereas, higher magnification images (>100,000X) received the electron dose of about 20 e/Å<sup>2</sup> so as to maintain a good signal-to-noise condition. Image acquisition and processing were performed using Gatan Microscopy Suite of version 3.2.<sup>16</sup> 

## **Hydrogen evolution:** 

Hydrogen evolution was measured using ascorbic acid (AA) as a sacrificial electron donor. Nanoparticles (1 mg) in 0.2 M  AA (12 mL, pH 2.4) were loaded into a recirculating batch reactor (illumination area = 4.4±0.1 cm<sup>2</sup> ) connected in-line to a GC equipped with a molecular sieve column and thermal conductivity detector.<sup>45</sup> The desired Pt loading was achieved by adding a specific amount of aqueous potassium hexachloroplatinate solution (0.401 mg/mL Pt). The reactor was evacuated and purged with Ar 5 times to remove oxygen, and the pressure was set to 100 Torr. The suspension was stirred and illuminated with a solar simulator (Asahi Max 303) fitted with a UV-IR mirror module and an AM1.5g filter. The light intensity at the sample surface was adjusted to 100 mWcm<sup>-2</sup> (1 sun) before each experiment using a calibrated reference solar cell (Newport 91150V) and H2 evolution was quantified by a gas chromatograph equipped with a thermal conductivity detector. An opaque insert with a cuboid shaped cavity that holds the nanoparticle suspension under the light beam was used to accurately quantify the illumination area. The length of each side of the cross section of the cavity was 2.1 ± 0.04 cm. The cross-sectional area of the cavity, which also corresponds to the illumination area of the sample, was 4.4 ± 0.1 cm<sup>2</sup> . The dimensions of the cross section of the cavity were chosen to be similar to those of the calibrated silicon photodiode (2.0 × 2.0 cm) used to calibrate the intensity of 

the light source to 1 sun. This ensures that any inhomogeneities in the light intensity within the illumination area are accounted for when calibrating the light intensity because the output of the photodiode is dependent on the total photon flux on its surface.<sup>16</sup> 

## **EQE measurements:** 

EQE measurements were carried out in the same way as hydrogen evolution measurements, but with suitable band pass filters fitted to the light source. The sample was first illuminated under simulated solar light for 3 h to complete Pt photodeposition. Then the reactor was evacuated and purged with Ar 5 times to remove all the H2 evolved during this time. The light source was fitted with a band pass filter, and the photocatalyst was illuminated with filtered light within a narrow wavelength range. The EQE was calculated using Equation 3, where nH2 represents the number of moles of H2 evolved per hour, and n photons represents the total number of photons incident on the sample surface (Illumination area = 4.4±0.1 cm<sup>2</sup> ) per hour. Photon flux was measured using a calibrated spectrometer (Ocean Optics USB2000 calibrated with an Ocean Optics DH3-plus light source) fitted with a fibre optic cable and a 0.4778 cm<sup>2</sup> cosine corrector.<sup>16</sup> 

Equation 3: 



<!-- Start of picture text -->
2𝑛 𝐻2<br>𝐸𝑄𝐸 (%) =  × 100%<br>𝑛 𝑝ℎ𝑜𝑡𝑜𝑛𝑠<br><!-- End of picture text -->

# **Absorption and photoluminescence spectra:** 

<mark>The absorption spectra were recorded in an Agilent Cary 60 UV-Vis.  The PL spectra of PM6:Y6 blends were recorded using and integrated Andor DU420A-BEX2-DD camera, KY193 spectrograph and Avantes integrating sphere system. This system has a quantum efficiency  (EQE) over 20% in the range of 650nm to 900 nm, by combing the detector (iDus 420 BEX2-DD, EQE over 90%) and the grating (SR2-GRT-0300-1000). The PL system is calibrated by a Avantes AvaLight-HAL-CALISP50-MINI light sources with known spectrum. Collimated Laser Diode Modules (CPS450, CPS532 and CPS780, THORLABS) were used as excitation source at 450 nm, 532 nm (33.4 mW cm</mark><sup>-2</sup> <mark>) and 780 nm (33.6 mW cm</mark><sup>-2</sup> <mark>). All NPs suspensions were prepared in water with an absorbance of 0.05 at the excitation wavelength to ensure equal numbers of absorbed photons.</mark> 

## **Transient absorption spectroscopy (TAS):** 

Ultrafast TAS analysis of heterojunction nanoparticles dispersed in water was carried out by using a amplified Ti:sapphire laser (Solstice, Spectra Physics), with a 800 nm laser pulse (< 200 fs, 1 kHz repetition rate). The laser pulse is divided into the pump and the probe by using a beam splitter. The pump laser at the excitation wavelength used is generated through an optical parametric amplifier (TOPAS Prime, Light Conversion) and a frequency mixer (NirUVis, Light Conversion). The probe pulse at specific time delays is generated through a mechanical delay stage, which delay it by an adjustable period (maximum of 6 ns) relative to pump pulse.  The continuous white light probe in the visible (450−800 nm) or NIR (850−1400 nm) region is generated by focusing the probe pulse into a sapphire crystal. Then, the probe pulse is divided before the sample into two pulses, one is directed to the sample and the other is used as the reference. Both pulses are directed to separated multichannel spectrometer (Si or InGaAs sensor). The continuum probe pulse on the samples is spatially overlapped with the pump pulse. The pump pulse is chopped by a synchronized chopper with a frequency of 500 Hz. Pulse energies were measured using an energy meter (OPHIR Photonics, VEGA P/N 7Z01560) with a 500 μm diameter aperture. The samples were measured in Argon atmosphere. All suspensions were 

measured at equal numbers of absorbed photons, with an absorbance of 0.6 at the excitation wavelength. 

Microsecond−Second TAS was carried out by using a Nd:YAG laser (OPOTEK Opolette 355 II, 6 ns pulse width), which generates UV pulses (355 nm) or visible/NIR pulses (410−2200 nm). The probe beam is generated from a 100 W quartz halogen lamp and sequentially directed through the sample and then to a monochromator before directed it onto a Si photodiode detector (Hamamatsu S1722-01). Pump pulses are directed to the sample through a liquid light guide and are overlapped with the probe beam at the position of the sample. Data acquisitions are triggered by scattered laser light using a photodiode. Appropriate long pass filters are positioned before the sample and between the sample and the detector to attenuate scattered laser light. A home-built LabVIEW-based software package was used to acquire the data on two different time scales simultaneously: the microsecond−millisecond signal is sampled using an oscilloscope (Tektronix DPO 3012) after amplification (Costronics 2011 amplifier), whereas the millisecond−second signal is sampled without amplification using a DAQ card (National Instruments USB-6361). Pulse energies were measured using an energy meter (OPHIR Photonics, VEGA P/N 7Z01560). All NPs suspensions were measured at equal numbers of absorbed photons, with an absorbance of 0.6 at the excitation wavelength and in an Argon atmosphere. 

## **Photoinduced Absorption Spectroscopy (PIAS):** 

PIAS analysis were carry out on modified microsecond−second TAS setup. A high-power LED (Cree XLamp XP-E XPERED-L1-0000-00801, 630 nm) was used as excitation source, which is driven by a highprecision DC power supply (TTi QL564P). The LED is directed to the sample through liquid light guide. Light pulses are generated via a MOSFET transistor (STMicroelectronics STF8NM50N) and the gate is modulated by the DAQ card (National Instruments, USB-6361). All data were sampled without prior amplification using the DAQ card. Excitation fluences were measured with a digital power meter (Thorlabs PM100), using a silicon photodiode power sensor (Thorlabs S120UV). 

All the PIA kinetics were measured at the same conditions, 630 nm LED excitation and fluency 20 mWcm<sup>-2</sup> . The NPs suspensions were prepared at equal numbers of absorbed photons (absorbance of 0.6 at the excitation wavelength) and measured in Argon atmosphere. The conditions were optimized to obtain improved signal-to-noise ratio in NPs samples under normal catalytic conditions, however measurement artifact was observed in the kinetics of NPs with low intensity PIA signals (PM6 and PM6:Y6 NPs). 

The accumulated charge density was estimated by using the Beer-Lambert law relation A = ε.c.l, where A is the absorbance measured in the PIAS spectra (Figure 7c), and ε is the extinction coefficient (estimated at 600 nm to be 31500 M<sup>-1</sup> cm<sup>-1</sup> from the magnitude of the PM6 ultrafast transient absorption spectra in Supplementary Figure 19a), c is the concentration of charges and l is the optical path (1 cm) _._ This was converted to the charges / NP by using the solution absorption relative to a 100 nm thick spin coated donor/acceptor film and an NP radius of 40 nm. We note there is approximately a factor of 2 uncertainty in this estimate, due to uncertainty in the excitation spot size used to determine ε. 

## **Data availability** 

The authors declare that all data supporting the findings of this study are available within the paper and Supplementary Information files. 

## **Acknowledgements** 

We acknowledge financial support from KAUST, including Office of Sponsored Research (OSR) awards no. OSR-2018-CRG/CCF-3079 (IM), OSR-2019-CRG8-4086 IED-OSR-2019-4454 (IM) and OSR-2018CRG7-3749 (IM).  We acknowledge funding from ERC Synergy Grant SC2 (610115) (IM), the European Union’s Horizon 2020 research and innovation programme under grant agreement n°952911, project BOOSTER (IM) and grant agreement n°862474, project RoLA-FLEX (IM), as well as EPSRC Project EP/T026219/1 (IM). SG-C acknowledges European Union’s Horizon 2020 research and innovation programme under the Marie Sklodowska-Curie grant agreement No 886664 (PolyNanoCat project) (S.G). 

### **Author Contributions Statement** 

J.K. and S.G.C contributed equally to this work. J.K. designed and performed experiments, analyzed data, and wrote the manuscript. S.G. designed and performed experiments, analyzed data, and cowrote the manuscript. C.T.H., T.F., Y.D., G.T.H., Y.F., R.Sh., B.P., F.M., W.X. and A.B. designed and performed experiments. L.Z. and R.So. imaged nanoparticles. T.D.A., S.D.W, J.R.D. and I.M. supervised the project. 

## **Correspondence** 

Please send correspondence to Iain McCulloch (iain.mcculloch@chem.ox.ac.uk), James Durrant (j.durrant@imperial.ac.uk), Jan Kosco (jan.kosco@kaust.edu.sa). 

### **Competing Interests Statement** 

The authors declare no competing interests. 

### **Tables** 

There are no tables in the main manuscript. 

### **Figure Legends/Captions (for main text figures)** 

**Figure 1:** Chemical structures and energy levels. a) Chemical structures of the organic semiconductors PBDB-T-2F (PM6), BTP-4F (Y6), and [6,6]-Phenyl C71 butyric acid methyl ester (PCBM). b) Combined UPS and IPES spectra of PM6, Y6 and PCBM measured on thin films under vacuum. The solid vertical lines indicate the HOMO and LUMO energy level onsets of each semiconductor. c) Energy level diagram of PM6, Y6 and PCBM as measured by UPS and IPES. The dashed lines correspond to the proton reduction potential (H<sup>+</sup> /H2), water oxidation potential (O2/H2O) and the calculated potential of the two-hole oxidation of ascorbic acid to dehydroascorbic acid in solution (DHA/AA) at pH 2 (the experimentally measured pH of 0.2 mol l<sup>−1</sup> ascorbic acid).<sup>30</sup> All energy levels and electrochemical potentials are expressed on relative to vacuum (using -4.44 V versus vacuum = 0 V versus SHE).<sup>46</sup> Note: Energy levels measured by photoelectron emission spectroscopy in air (PESA) in conjunction with UVVisible absorption spectroscopy (Supplementary Figure 4) indicate slightly different energy levels, as do cyclic voltammetry data.<sup>35</sup> However, in all cases the energy levels are suitable for proton reduction and AA oxidation. 

**Figure 2:** Blend optimization. a) H2 evolution vs. time for PM6:Y6 nanoparticles formed from a range of PM6:Y6 ratios. b) H2 evolution vs. time for PM6:PCBM nanoparticles formed from a range of PM6:PCBM ratios. c) Average H2 evolution rates of PM6:Y6 and PM6:PCBM nanoparticles over 16 h as a function of the Donor (PM6) to Acceptor (Y6 or PCBM) blend ratio. The values displayed for PM6:Y6 7:3 and PM6:PCBM 2:8 are the average of 5 repeat measurements (hollow symbols). See Supplementary Figure 5 for individual data plots. Error bars represent the sample standard deviation (0.4 µmolh-1cm-2 and 0.6 µmolh-1cm-2 for PM6:Y6 7:3 and PM6:PCBM 2:8 respectively). d) UV-Vis absorbance spectra of the PM6:Y6 and PM6:PCBM nanoparticle dispersions at their optimized blend ratios (concentration: 17±1 µg/mL). H2 evolution conditions: 1 mg PM6:Y6 or PM6:PCBM nanoparticles, 0.2 mol l−1 ascorbic acid (12 ml), pH 2.4, 10 µg (10 wt.%) Pt, AM1.5g solar simulator at 100 mWcm-2 (1 sun), 4.4±0.1 cm2 illumination area. See Supplementary Figure 7 for extended stability data and further discussion regarding the nonlinearity of the HER rates. 

**Figure 3:** External Quantum Efficiencies (EQEs). a) EQE at 400, 500, 560, 620, 650, 750, 800, 850 and 900 ± 10 nm and the absorption spectrum of PM6:Y6 7:3 NPs with 10% Pt. b) EQE at 400, 470, 560, 620 and 700 ± 10 nm and the absorption spectrum of PM6:PCBM 2:8 NPs with 5% Pt. 

**Figure 4:** Bright field cryo-TEM images of nanoparticles. PM6:Y6 7:3 NPs before (a) and after (b) photodeposition of 10 wt.% Pt and 20 h H2 evolution. PM6:PCBM 2:8 NPs before (c) and after (d) photodeposition of 5 wt.% Pt and 20 h H2 evolution. Measurements were repeated a minimum of four times with similar results. Note: The presence of photodeposited Pt on the NPs makes them more resistant to the electron beam which enables more detailed images to be acquired. The areas highlighted by the white rectangles display periodic spacings which correspond to PM6 and Y6 lamellar stacking distances. More images of each NP type and detailed analysis of images a-d can be found in supplementary figures 8-17. 

**Figure 5.** <mark>Steady state photoluminescence (PL) spectra. Steady state PL spectra of PM6:PCBM NPs at different PM6:PCBM composition ratios exciting at (a) 532 nm to selectively excite PM6 and b) exciting at  450 nm excitation to preferentially excite PCBM. Steady state PL spectra of PM6:Y6 NPs at different PM6:Y6 ratios excited (b) at 532 nm to preferentially excite PM6 and (c) at 780 nm for selective excitation of Y6. All suspensions were prepared with an absorbance of 0.05 at the excitation wavelength to ensure equal numbers of absorbed photons.</mark> 

**Figure 6.** Ultrafast transient absorption spectroscopic characterization for neat PM6, PM6:Y6 7:3 and PM6:PCBM 2:8 nanoparticles in aqueous suspensions. a) Transient absorption spectra of PM6 NPs at different time delays following excitation at 550 nm (fluence: 7.5 μJ cm<sup>−2</sup> ). b) Comparison of transient absorption decay dynamics for neat PM6, PM6: PCBM 2:8 and PM6:Y6 7:3 NPs excited at 550 nm and probed at 1150 nm, assigned to PM6 exciton decay, with the long lived residual signal assigned to PM6 polaron decay in the heterojunction NPs. c,d)Transient absorption spectra of c) PM6:PCBM 2:8 NPs and d) PM6:Y6 7:3 NPs at different time delays, also excited at 550 nm  (fluence: 7.5 μJ cm<sup>−2</sup> ). The disconnect in the transient absorption spectra axis correspond to the pump laser scattering (550 nm) and the switch from visible to NIR detector (800-850 nm). e) Schematic representation of exciton decay and electron/energy transfer processes in these NPs. 

**Figure 7.** Transient absorption decay dynamics and Photoinduced Absorption Spectroscopy (PIAS) of NPs with and without the addition of Pt and AA. Transient absorption decay dynamics of a) PM6:PCBM 2:8 and b) PM6:Y6 7:3 NPs in water in the absence of Pt and AA (black), with Pt (blue) and in the presence of both Pt and AA (red). Excited at 550 nm (250 μJ cm<sup>-2</sup> ) and probed at 700 nm. c) Comparison of the PIAS kinetics of PM6, PM6:PCBM 2:8 and PM6:Y6 7:3 NPs suspensions probed at 700 nm in the 

absence of Pt and AA. Also shown, insert, are equivalent data for a 2:8 spin coated PM6:PCBM film, exhibiting a negligible PIAS signal. d) Comparison of PIAS spectra of the same NP suspensions measured at 4 s time delay. e,f) PIAS spectra of PM6:PCBM 2:8 (e) and PM6:Y6 7:3 NPs (f) measured at 4s without and with the addition of Pt and/or AA. PIAS measurements were carried out under continuous LED illumination at 630 nm (20 mW cm<sup>-2</sup> ) during 4 seconds. Pt and ascorbic acid additions as for Figure 2. 

**Figure 8:** Performance comparison. a) H2 evolution vs. time b) Average HER rates and Pt turnover frequencies over 16 h of the optimized PM6:Y6 7:3 and PM6:PCBM 2:8 NPs compared to a range of benchmark photocatalysts. Conditions: PM6:Y6 7:3, PM6:PCBM 2:8, and PTB7-Th:EH-IDTBR: 1 mg photocatalyst, 12 ml 0.2 mol l<sup>−1</sup> ascorbic acid (AA). P25 TiO2 and CN: 50 mg photocatalyst, 12 ml 10% triethanolamine (TEOA). The desired Pt loading was achieved by adding a specific amount of K2PtCl6 to the photocatalyst suspension. All measurements were performed under AM1.5g irradiation at an intensity of 100 mWcm<sup>-2</sup> and an illumination area of 4.4±0.1 cm<sup>2</sup> . Note: To ensure a fair comparison, all the photocatalysts were measured in the same reactor using an identical illumination area and the amount of photocatalyst was adjusted to ensure that there was 0% light transmission within the absorption range of the photocatalyst. The Pt loadings for TiO2 (1.5%),<sup>47</sup> CN (1%),<sup>48</sup> and PTB7-Th:EHIDTBR (10%)<sup>16</sup> were chosen based on previously reported optima. The HER rates are higher for TiO2 and CN with TEOA instead of AA as the sacrificial hole scavenger.<sup>16</sup> The Pt normalized HER rates were calculated based on the total amount of Pt added to the reactor. 

## **References** 

1. Hoffert, M. I. _et al._ Advanced technology paths to global climate stability: energy for a greenhouse planet. _Science_ **298** , 981–7 (2002). 

2. Mills, A. D. & Wiser, R. H. Strategies to mitigate declines in the economic value of wind and solar at high penetration in California. _Appl. Energy_ **147** , 269–278 (2015). 

3. Creutzig, F. _et al._ The underestimated potential of solar energy to mitigate climate change. _Nat. Energy_ **2** , 17140 (2017). 

4. Ball, M. & Weeda, M. The hydrogen economy – Vision or reality? _Int. J. Hydrogen Energy_ **40** , 7903–7919 (2015). 

5. Jia, J. _et al._ Solar water splitting by photovoltaic-electrolysis with a solar-to-hydrogen efficiency over 30%. _Nat. Commun._ **7** , 13237 (2016). 

6. Grätzel, M. Photoelectrochemical cells. _Nature_ vol. 414 338–344 (2001). 

7. Pinaud, B. A. _et al._ Technical and economic feasibility of centralized facilities for solar hydrogen production via photocatalysis and photoelectrochemistry. _Energy Environ. Sci._ **6** , 1983 (2013). 

8. Fabian, D. M. _et al._ Particle suspension reactors and materials for solar-driven water splitting. _Energy Environ. Sci._ **8** , 2825–2850 (2015). 

9. Hisatomi, T., Kubota, J. & Domen, K. Recent advances in semiconductors for photocatalytic and photoelectrochemical water splitting. _Chem. Soc. Rev._ **43** , 7520–7535 (2014). 

10. Ng, B. _et al._ Z‐Scheme Photocatalytic Systems for Solar Water Splitting. _Adv. Sci._ **7** , 1903171 (2020). 

11. FUJISHIMA, A. & HONDA, K. Electrochemical Photolysis of Water at a Semiconductor Electrode. _Nature_ **238** , 37–38 (1972). 

12. Takata, T. _et al._ Photocatalytic water splitting with a quantum efficiency of almost unity. _Nature_ **581** , 411–414 (2020). 

13. Maeda, K. & Domen, K. Photocatalytic Water Splitting: Recent Progress and Future Challenges. _J. Phys. Chem. Lett._ **1** , 2655–2661 (2010). 

14. Kosco, J., Moruzzi, F., Willner, B. & McCulloch, I. Photocatalysts Based on Organic Semiconductors with Tunable Energy Levels for Solar Fuel Applications. _Adv. Energy Mater._ **10** , 2001935 (2020). 

15. Dai, C. & Liu, B. Conjugated polymers for visible-light-driven photocatalysis. _Energy Environ. Sci._ **13** , 24–52 (2019). 

16. Kosco, J. _et al._ Enhanced photocatalytic hydrogen evolution from organic semiconductor heterojunction nanoparticles. _Nat. Mater._ **19** , 559–565 (2020). 

17. Liu, A. _et al._ Panchromatic Ternary Polymer Dots Involving Sub-Picosecond Energy and Charge Transfer for Efficient and Stable Photocatalytic Hydrogen Evolution. _J. Am. Chem. Soc._ jacs.0c12654 (2021) doi:10.1021/jacs.0c12654. 

18. Bai, Y. _et al._ Accelerated Discovery of Organic Polymer Photocatalysts for Hydrogen Evolution from Water through the Integration of Experiment and Theory. _J. Am. Chem. Soc._ **141** , 9063– 9071 (2019). 

19. Landfester, K. The Generation of Nanoparticles in Miniemulsions. _Adv. Mater._ **13** , 765–768 (2001). 

20. Yuan, J. _et al._ Single-Junction Organic Solar Cell with over 15% Efficiency Using Fused-Ring Acceptor with Electron-Deficient Core. _Joule_ **3** , 1140–1151 (2019). 

21. Pan, M.-A. _et al._ 16.7%-efficiency ternary blended organic photovoltaic cells with PCBM as the acceptor additive to increase the open-circuit voltage and phase purity. _J. Mater. Chem. A_ **7** , 20713–20722 (2019). 

22. Wadsworth, A., Hamid, Z., Kosco, J., Gasparini, N. & McCulloch, I. The Bulk Heterojunction in Organic Photovoltaic, Photodetector, and Photocatalytic Applications. _Advanced Materials_ vol. 32 2001763 (2020). 

23. Wenderich, K. & Mul, G. Methods, Mechanism, and Applications of Photodeposition in Photocatalysis: A Review. _Chem. Rev._ **116** , 14587–14619 (2016). 

24. Kosco, J. _et al._ The Effect of Residual Palladium Catalyst Contamination on the Photocatalytic Hydrogen Evolution Activity of Conjugated Polymers. _Adv. Energy Mater._ 1802181 (2018) doi:10.1002/aenm.201802181. 

25. Ran, J., Zhang, J., Yu, J., Jaroniec, M. & Qiao, S. Z. Earth-abundant cocatalysts for semiconductor-based photocatalytic water splitting. _Chemical Society Reviews_ vol. 43 7787– 7812 (2014). 

26. Sachs, M. _et al._ Understanding structure-activity relationships in linear polymer photocatalysts for hydrogen evolution. _Nat. Commun._ **9** , 4968 (2018). 

27. Kotani, H. _et al._ Efficient Near-Infrared Light-Driven Hydrogen Evolution Catalyzed by a Saddle-Distorted Porphyrin as a Photocatalyst. _ACS Appl. Energy Mater._ **3** , 3193–3197 (2020). 

28. Jiang, W. _et al._ Integration of Multiple Plasmonic and Co-Catalyst Nanostructures on TiO 2 Nanosheets for Visible-Near-Infrared Photocatalytic Hydrogen Evolution. _Small_ **12** , 1640– 1648 (2016). 

29. Wang, P., Huang, B., Dai, Y. & Whangbo, M. H. Plasmonic photocatalysts: Harvesting visible light with noble metal nanoparticles. _Physical Chemistry Chemical Physics_ vol. 14 9813–9825 (2012). 

30. Wang, X. _et al._ Sulfone-containing covalent organic frameworks for photocatalytic hydrogen evolution from water. _Nat. Chem._ **10** , 1180–1189 (2018). 

31. Jie Lv _et al._ Additive-induced miscibility regulation and hierarchical morphology enable 17.5% binary organic solar cells. _Energy Environ. Sci._ **14** , 3044–3052 (2021). 

32. Dimitrov, S. D. _et al._ Towards optimisation of photocurrent from fullerene excitons in organic solar cells. _Energy Environ. Sci._ **7** , 1037–1043 (2014). 

33. Cook, S., Furube, A., Katoh, R. & Han, L. Estimate of singlet diffusion lengths in PCBM films by time-resolved emission studies. _Chem. Phys. Lett._ **478** , 33–36 (2009). 

34. Karki, A. _et al._ The role of bulk and interfacial morphology in charge generation, recombination, and extraction in non-fullerene acceptor organic solar cells. _Energy Environ. Sci._ **13** , 3679–3692 (2020). 

35. Wu, J. _et al._ Exceptionally low charge trapping enables highly efficient organic bulk heterojunction solar cells. _Energy Environ. Sci._ **13** , 2422–2430 (2020). 

36. Wang, R. _et al._ Charge Separation from an Intra-Moiety Intermediate State in the HighPerformance PM6:Y6 Organic Photovoltaic Blend. _J. Am. Chem. Soc._ **142** , 12751–12759 (2020). 

37. Wang, K. _et al._ Interplay between Intrachain and Interchain Excited States in Donor–Acceptor Copolymers. _J. Phys. Chem. B_ **125** , 7470–7476 (2021). 

38. Le Formal, F. _et al._ Rate Law Analysis of Water Oxidation on a Hematite Surface. _J. Am. Chem. Soc._ **137** , 6629–6637 (2015). 

39. Francàs, L., Mesa, C. A., Pastor, E., Le Formal, F. & Durrant, J. R. Chapter 5 Rate Law Analysis of Water Splitting Photoelectrodes. in _Advances in Photoelectrochemical Water Splitting: Theory, Experiment and Systems Analysis_ 128–162 (The Royal Society of Chemistry, 2018). doi:10.1039/9781782629863-00128. 

40. Sachs, M. _et al._ Tracking Charge Transfer to Residual Metal Clusters in Conjugated Polymers for Photocatalytic Hydrogen Evolution. _J. Am. Chem. Soc._ **142** , 14574–14587 (2020). 

41. Yang, W. _et al._ Electron Accumulation Induces Efficiency Bottleneck for Hydrogen Production in Carbon Nitride Photocatalysts. _J. Am. Chem. Soc._ **141** , 11219–11229 (2019). 

42. Pendlebury, S. R. _et al._ Dynamics of photogenerated holes in nanocrystalline α-Fe2O3 electrodes for water oxidation probed by transient absorption spectroscopy. _Chem. Commun._ **47** , 716–718 (2011). 

43. Collado, L. _et al._ Unravelling the effect of charge dynamics at the plasmonic metal/semiconductor interface for CO2 photoreduction. _Nat. Commun._ **9** , 4986 (2018). 

44. Rodenberg, A. _et al._ Mechanism of photocatalytic hydrogen generation by a polypyridylbased cobalt catalyst in aqueous solution. _Inorg. Chem._ **54** , 646–657 (2015). 

45. Qureshi, M. & Takanabe, K. Insights on Measuring and Reporting Heterogeneous Photocatalysis: Efficiency Definitions and Setup Examples. _Chem. Mater._ **29** , 158–167 (2017). 

46. Trasatti, S. The absolute electrode potential: an explanatory note (Recommendations 1986). _J. Electroanal. Chem. Interfacial Electrochem._ **209** , 417–428 (1986). 

47. Maeda, K. _et al._ Photocatalytic Activities of Graphitic Carbon Nitride Powder for Water Reduction and Oxidation under Visible Light. _J. Phys. Chem. C_ **113** , 4940–4947 (2009). 

48. Haselmann, G. M. & Eder, D. Early-Stage Deactivation of Platinum-Loaded TiO 2 Using In Situ Photodeposition during Photocatalytic Hydrogen Evolution. _ACS Catal._ **7** , 4668–4675 (2017). 

