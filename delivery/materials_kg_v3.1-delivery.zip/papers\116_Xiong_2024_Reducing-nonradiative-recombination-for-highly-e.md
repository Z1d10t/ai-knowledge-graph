# Reducing nonradiative recombination for highly efficient inverted perovskite solar cells via a synergistic bimolecular interface

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 213 |
| 作者 | Shao-Bing Xiong, Fuyu Tian, Feng Wang, Aiping Cao, Zeng Chen, Sheng Jiang, Di Li, Bin Xu et al. |
| DOI | 10.1038/s41467-024-50019-3 |
| 源文件 | 016_Xiong_2024_Reducing-nonradiative-recombination-for-highly-e.pdf |

---


Article 

https://doi.org/10.1038/s41467-024-50019-3 

# Reducing nonradiative recombination for highly efficient inverted perovskite solar cells via a synergistic bimolecular interface 

|Received: 2 December 2023<br>Accepted: 27 June 2024<br>Check for updates|Shaobing Xiong<sup>1,2,11</sup>, Fuyu Tian<sup>3,11</sup>, Feng Wang<br>4,11, Aiping Cao1, Zeng Chen5,<br>Sheng Jiang<sup>1</sup>, Di Li<sup>1</sup>, Bin Xu<sup>1</sup>, Hongbo Wu<sup>6</sup>, Yefan Zhang<sup>7</sup>, Hongwei Qiao<sup>1</sup>,<br>Zaifei Ma<br>6, Jianxin Tang<br>7, Haiming Zhu<br>5, Yefeng Yao<br>1, Xianjie Liu8,<br>Lijun Zhang<br>3<br>, Zhenrong Sun<sup>9</sup>, Mats Fahlman<br>8, Junhao Chu2,<br>Feng Gao<br>4<br>& Qinye Bao<br>1,2,10|
|---|---|
||Reducing interface nonradiative recombination is important for realizing<br>highly efficient perovskite solar cells. In this work, we develop a synergistic<br>bimolecular interlayer (SBI) strategy via 4-methoxyphenylphosphonic acid<br>(MPA) and 2-phenylethylammonium iodide (PEAI) to functionalize the per-<br>ovskite interface. MPA induces an in-situ chemical reaction at the perovskite<br>surface via forming strong P-O-Pb covalent bonds that diminish the surface<br>defect density and upshift the surface Fermi level. PEAI further creates an<br>additional negative surface dipole so that a more n-type perovskite surface is<br>constructed, which enhances electron extraction at the top interface. With this<br>cooperative surface treatment, we greatly minimize interface nonradiative<br>recombination through both enhanced defect passivation and improved<br>energetics. The resulting p-i-n device achieves a stabilized power conversion<br>efficiency of 25.53% and one of the smallest nonradiative recombination<br>inducedVocloss of only 59 mV reported to date. We also obtain a certified<br>efficiency of 25.05%. This work sheds light on the synergistic interface engi-<br>neering for further improvement of perovskite solar cells.|



Inverted p-i-n perovskite solar cells (PSCs) possess remarkable advantages of low-temperature processibility, long-term stability, and compatibility in state-of-the-art tandem cells, making them promising in photovoltaic commercialization<sup>1–3</sup> . Especially, recent explorations on defect elimination, crystallization control and interface design via additive or surface reconstruction have improved their power 

conversion efficiency (PCE) to certified values over 25%<sup>4–6</sup> . Nevertheless, the nonradiative recombination at charge-extracting interfaces in the inverted p-i-n device can be further decreased to push the efficiency towards the Shockley-Queisser limit<sup>7</sup> . 

Surface defects due to interruption of the perovskite crystal lattice result in significant traps for photogenerated carriers that cause 

> 1School of Physics and Electronic Science, East China Normal University, Shanghai 200241, China. 2Shanghai Frontiers Science Research Base of Intelligent Optoelectronics and Perception, Institute of Optoelectronics, Fudan University, Shanghai 200433, China.<sup>3</sup> State Key Laboratory of Integrated Optoelectronics, Key Laboratory of Automobile Materials of MOE, International Center of Computational Method and Software, School of Materials Science and Engineering, Jilin University, Changchun 130012, China.<sup>4</sup> Department of Physics, Chemistry and Biology, Linköping University, Linköping 58183, Sweden. 5Department of Chemistry, Chemistry of High-Performance and Novel Materials, Zhejiang University, Hangzhou 310027, China. 6Center for Advanced LowDimension Materials, Donghua University, Shanghai 201620, China.<sup>7</sup> Institute of Functional Nano & Soft Materials (FUNSOM), Soochow University, Suzhou 215123, China.<sup>8</sup> Laboratory of Organic Electronics, Linköping University, Norrköping 60174, Sweden.<sup>9</sup> State Key Laboratory of Precision Spectroscopy, East China Normal University, Shanghai 200241, China.<sup>10</sup> Collaborative Innovation Center of Extreme Optics, Shanxi University, Taiyuan, Shanxi 030006, China. 

> 11These authors contributed equally: Shaobing Xiong, Fuyu Tian, Feng Wang. e-mail: lijun_zhang@jlu.edu.cn; feng.gao@liu.se; qybao@clpm.ecnu.edu.cn 

Nature Communications |  (2024) 15:5607 

1 

Article 

https://doi.org/10.1038/s41467-024-50019-3 

recombination loss, provide channels for ions migration and external environmental invasion and thus destroy device operational efficiency and stability<sup>8,9</sup> . Functional agents such as Lewis acid and fluoride are commonly applied to passivate perovskite surfaces by forming coordination bonds, ionic bonds or hydrogen bonds<sup>10–12</sup> . However, these resulting bonds are significantly weaker than that of primary covalent bonds used in e.g., silicon solar cells, limiting the passivation efficacy and durability<sup>13,14</sup> . Covalent bonds, which have great robustness and are expected greatly to affect surface chemical and physical properties, are not yet investigated in-depth for perovskite semiconductors. 

Interface energetics largely control the charge extraction and recombination, affecting all the three photovoltaic parameters, i.e., open-circuit voltage (Voc), fill factor (FF), and short-circuit current density (Jsc)<sup>15–17</sup> . Unmatched interface energetics will form a potential well and trap charge carriers at perovskite/charge transport layer (CTL) interfaces, reducing Voc and FF. The resulting charge accumulation is reported to reduce the activation energy for halide migration<sup>18</sup> , so that a well-matched energy level alignment is required both for performance and stability enhancement. 

These currently unsolved challenges emphasize the need to develop a molecularly functionalized interface providing the following critical functionalities: (i) covalent bonds for strong interface passivation and (ii) matched energetics that boost charge extraction into the CTL. However, design and synthesis of a single molecule that can provide both the desired covalent bonding and energy level alignment could be complicated. Co-depositing multiple surface-modifying molecules is also challenging, of which the competing interactions with the perovskite will not only limit the passivation efficiency, but also create an inhomogeneous energy landscape. 

Here we develop a synergistic bimolecular interlayer (SBI) strategy to address the above two issues and achieve high-performance p-in PSCs. A 4-methoxyphenylphosphonic acid (MPA) modulator is employed to chemically solder the perovskite surface via strong P-O-M (metal) bonds, where M refers to Pb<sup>2+</sup> ions. The strong chemical interaction largely suppresses the interface recombination by reducing trap state density and upshifting Fermi level (EF) of the perovskite surface. A second 2-phenylethylammonium iodide (PEAI) layer is then sequentially deposited to further modulate the interface energetics by forming a negative surface dipole, which constructs a more n-type perovskite surface and enhances electron extraction across the top interface. As a result, the SBI-based p-i-n PSC shows a stabilized efficiency of 25.53% and one of the smallest nonradiative recombination induced Voc loss of only 59 mV reported to date. In addition, the target device also features good stability, retaining 95% of its initial efficiency for aging over 1000 h at 55 ± 5 °C. 

## Results 

### SBI strategy and surface reaction 

The p-i-n device configuration is depicted in Fig. 1a, where MPA and PEAI are sequentially inserted between the perovskite Cs0.05(FA0.95MA0.05)0.95Pb(I0.95Br0.05)3 and the electron transport layer (ETL) PCBM to form the SBI (chemical structures of the materials shown in Fig. 1b). The thickness of the SBI is estimated to be <6 nm (Fig. 1c and Supplementary Note 1). We find that the SBI does not adversely affect the perovskite surface morphology, crystallinity, or optical absorption properties (Supplementary Figs. 1–3). The band edge of the perovskite remains constant at 1.55 eV. The water contact angle measurement presents that the SBI-modified perovskite surface is more hydrophobic, beneficial for the long-term stability of PSCs (Supplementary Fig. 4). X-ray photoelectron spectroscopy (XPS) is conducted to demonstrate covalent bonding of perovskite surface with the deposition of MPA. The control perovskite film has an ideally sharp doublet Pb 4f feature assigned to the chemical state of Pb-I/Br, a single N 1s peak referred to CH = NH2+/CH-NH2 of FA+ and a minor signal O 1s peak from absorbed oxygen (Fig. 1d–f). After MPA surface 

modification, the Pb 4f core level splits into two doublets at higher and lower binding energy (BE) compared to the original doublet feature. The intensities of the high BE peak increase with enhancing MPA concentrations (Supplementary Fig. 5a), which we tentatively attribute to the chemical interaction of uncoordinated Pb<sup>2+</sup> with deprotonated -PO(OH)O<sup>−</sup> in terms of P-O-Pb bonds<sup>19</sup> . The deprotonation of phosphonic acid is expected in its dissolution process<sup>20</sup> . As confirmed by the pH test (Supplementary Fig. 6), the ethanol solvent shows lower pH value when MPA is dissolved with more solvated protons, indicating the deprotonation of phosphonic acid in the MPA solution. The O 1s signal represents a significant increase due to the CH3O- (530.9 eV), P=O (532.6 eV), and P-O(H) (533.6 eV) from MPA. In comparison with the O 1 s chemical environment of pristine MPA (Supplementary Fig. 7), a new peak near 531.5 eV emerges and the dominating P-O(H) chemical state is decreased, consistent with the formation of P-O-Pb bonds and the deprotonation of -PO(OH)2. Additionally, the Pb 4f, N 1s, O 1s, I 3d, P 2p and C 1s peaks all shift to lower BE due to the strong surface chemical reaction (Supplementary Fig. 5). We use Fourier-transform infrared (FTIR) spectra to further confirm the generation of P-O-Pb vibration signal near 1076 cm<sup>−1</sup> , and the P-O(H) vibration peaks show obvious downward shifts (Supplementary Fig. 8) in MPA/ Cs0.05(FA0.95MA0.05)0.95Pb(I0.95Br0.05)3 films. As the P=O vibration remains unchanged, the MPA prefers to bind with the perovskite through strong covalent P-O-Pb bonds rather than the weak coordination (i.e., P=O → Pb) that has been widely adopted<sup>21,22</sup> . The achieved interfacial covalent P-O-M (metal) bonds are critical as they have great robustness and can significantly affect surface chemistry and physics of metals and metaloxides<sup>23,24</sup> including a more effective passivation of defects<sup>13,25</sup> . 

Furthermore, the introduction of the PEAI layer exhibits no obvious change to the chemical species of Pb 4f, O 1s, I 3d, and P 2p XPS spectra (Fig. 1d–f and Supplementary Fig. 9). The shift to higher BE of the XPS peaks implies that the physically absorbed PEAI might create a downshifting dipole on the MPA-coated perovskite surface. In addition, it is also expected that PEAI provides additional defect passivation effectiveness to the perovskite surface due to the inconsecutive coverage of the MPA layer. 

### Surface energetics 

The impact of the SBI on the perovskite surface energetics is explored in detail by ultraviolet photoelectron spectroscopy (UPS). The work function (WF) is derived from the secondary electron cutoff, while the position of valenceband maximum (VBM) relative to the EF is extracted from the onset of valence band in a logarithmic photoemission intensity scale (Fig. 2a and Supplementary Fig. 10). The surface WF of the MPA-modified perovskite film decreases from 4.54 to 4.32 eV, ascribed to charge redistribution by the strong surface reaction. The surface WF of the PEAI/MPA-modified perovskite film further decreases to 4.20 eV due to the formation of a surface dipole<sup>17</sup> . The corresponding VBM position shifts from 0.87 to 1.08 and 1.20 eV, respectively. As illustrated in Fig. 2b, the SBI largely tailors the perovskite surface energetics by moving the EF closer to the conduction band and constructs a more n-type perovskite surface, which is expected to introduce an extra built-in electric field and enhance electron extraction while blocking holes at the perovskite/ETL interface, thus also suppressing interface recombination<sup>26,27</sup> . In addition, as the resulting surface WF of the SBI-modified perovskite is smaller than the negative pinning level energy (EICT- = 4.31 eV) of the organic semiconductor PCBM used as ETL<sup>28</sup> , the perovskite surface EF can pin to the negative polaron transport state of PCBM (Fig. 2c) and the perovskite thus creates a good contact with PCBM, further promoting electron transfer across the perovskite/ETL interface. 

We utilize Kelvin probe force microscopy (KPFM) to examine the surface morphology and potential distribution of the perovskite film (Fig. 2d–g, Supplementary Fig. 11). The SBI-modified perovskite film 

Nature Communications |  (2024) 15:5607 

2 

Article 

https://doi.org/10.1038/s41467-024-50019-3 



<!-- Start of picture text -->
a b c<br>Ag<br>Ag<br>PCBM/BCP<br>MPA/PEAI<br>PCBM/BCP<br>MPA/PEAI MPA<br>Perovskite<br>Perovskite<br>ITO/MeO-2PACz<br>MeO-2PACz<br>PEAI 200 nm<br>ITO<br>d e f<br>Pb 4 f MPA/PEAI N 1 s MPA/PEAI O 1 s MPA/PEAI<br>–NH3+<br>Pb-O-P Pb-I/Br MPA CH=NH2+ MPA P-O-Pb MPA<br>P=O<br>P-OH -OCH3<br>Control<br>CH=NH2+/ Control<br>CH-NH2 Control<br>× 2<br>146 144 142 140 138 136 404 403 402 401 400 399 398 536 535 534 533 532 531 530 529<br>Binding energy (eV)  Binding energy (eV) Binding energy (eV)<br>).<br>au.<br>( ytis<br>n<br>te Intensity (a.u.)<br>In Intensity (a.u.)<br><!-- End of picture text -->

Fig. 1 | SBI strategy and surface reaction. a Schematic illustration of p-i-n PSC using MPA/PEAI as SBI. b Chemical structures of MPA and PEAI molecules. c A crosssectional SEM image of PSC. d–f XPS core level characterizations of Pb, N, and O elements on the perovskite films with and without SBI. 

exhibits a diminished contact potential relative to the control, in accordance with UPS results. Moreover, the SBI-modified perovskite film displays a smaller surface potential distribution difference and lower surface roughness. A smoother perovskite surface with a more uniform surface potential distribution is beneficial for forming an efficient contact with the adjacent ETL that prevents nonradiative recombination<sup>16,29</sup> . 

### Defect passivation and enhanced extraction 

We conduct steady-state photoluminescence (PL) and time-resolved PL (TRPL) measurements to probe the effect of SBI on charge carrier dynamics. With the SBI, the PL intensity increases (Fig. 3a) and the corresponding TRPL average carrier lifetime increases by more than one time from 21.50 to 56.45 ns (Fig. 3b, c and Supplementary Table. 1), indicating a significantly reduced defect density on the perovskite surface. The space charge-limited current (SCLC) measurement confirms the decreased defect density from 6.60 × 10<sup>15</sup> to 1.07 × 10<sup>15</sup> cm<sup>−3</sup> obtained from the SBI (Supplementary Fig. 12). The enhanced PL quantum yields (PLQYs) (Fig. 3b) for the SBI-treated perovskite in comparison with the control one indicates improved optoelectronic quality of the perovskite films and suppressed trap-assisted nonradiative recombination, which is expected to enhance the Voc in PSCs<sup>30</sup> . When the SBI-modified perovskite contacts with the PCBM ETL, we find that the TRPL delivers a faster decay with the average carrier lifetime from 7.92 to 4.15 ns (Fig. 3c). We conclude that the SBI helps to boost electron extraction across interface from perovskite to PCBM due to efficient defect 

passivation and improved interface energetics. The high charge transfer efficiency across the interface is critical to obtain high FF in a cell<sup>31,32</sup> . 

We now compare their ultrafast transient absorption spectroscopy (TAS). The two-dimensional (2D) pseudo-color plots of the femtosecond transient absorption (fs-TA) spectrum for the neat perovskite films (without ETL) are depicted in Supplementary Fig. 13. Both the control and SBI-modified perovskite films have characteristic ground-state bleaching (GSB) signal at about 770 nm originating from the band state filling. fs-TA spectra at selected pump-probe delay time exhibits a slower GSB recovery in the SBI-modified perovskite film, which yields a longer decay time (Supplementary Fig. 14), indicating the reduced trap-assisted recombination. For the perovskite films with ETL, similar spectra features are observed but have weaker intensity and shorter GSB recovery process due to the electron extraction (Fig. 3d, e). The SBI-modified perovskite with ETL shows a faster GSB recovery compared to the control (Supplementary Fig. 15). Tracking the respective GSB decays at 770 nm, an earlier electron extraction is achieved after SBI modification (Fig. 3f), demonstrating an enhanced electron extraction at the perovskite/ETL interface. 

### Photovoltaic performance and energy loss 

Motivated by the above success, we fabricate p-i-n PSCs with state-ofthe-art configuration of ITO/MeO-2PACz/perovskite/SBI/PCBM/BCP/ Ag (Fig. 1a), in which the self-assembled [2-(3,6-dimethoxy-9H-carbazol-9-yl)ethyl]phosphonic acid (MeO-2PACz) acts as a hole transport layer (HTL). The concentrations of MPA and PEAI are optimized to be 5 

Nature Communications |  (2024) 15:5607 

3 

Article 

https://doi.org/10.1038/s41467-024-50019-3 



<!-- Start of picture text -->
a b c<br>E v E F E vac<br>VL<br>-1.20 E c EA 3.80 eV<br>4.20 4.31 eV<br>E ICT- 4.31 eV 4.20 eV<br>E F<br>-1.08<br>4.32 E v E F<br>5.32 eV<br>E ICT-<br>E ICT+<br>-0.87 IP<br>6.10 eV<br>4.54<br>-3 -2 -1 0 1 2 3 4 5 6 Control MPA PEAI PCBM SBI-modified PCBM<br>Binding energy (eV) perovskite<br>d e f g<br>Control MPA MPA/PEAI<br>50 nm 50 nm 50 nm  Control<br> MPA<br> MPA/PEAI<br>-50 nm Rq=14.5 nm -50 nm Rq=17.1 nm -50 nm Rq=13.3 nm<br>250 mV 80 mV -150 mV<br>-200 -100 0 100 200 300<br>100 mV 500 nm -100 mV 500 nm -200 mV 500 nm Potential (meV)<br>).<br>au.<br>( ytis<br>n<br>Iten<br>Distribution (%)<br><!-- End of picture text -->

Fig. 2 | Characterization of perovskite surface energetics. a UPS spectra of secondary electron cutoff region and valence band region of perovskite films with and without SBI. b Energy level diagram of the SBI-modified perovskite. c EF of the 

SBI-modified perovskite pinning to negative polaron transport state of PCBM used as ETL. d–f Surface morphology and potential images from KPFM. g Statistical potential distributions of film surfaces. 

and 1 mg ml<sup>−1</sup> , respectively, to obtain the best performance (Supplementary Figs. 16, 17 and Supplementary Tables 2, 3). Figure 4a shows the current density-voltage (J-V) curves for control, MPA- and SBIbased PSCs under AM1.5 G simulated solar illumination and reverse scanning. The control device shows a PCE of 22.52%, with a moderate Voc of 1.112 V, a short-circuit current density (Jsc) of 24.91 mA cm<sup>−2</sup> , and an FF of 81.3% (Supplementary Table 4). In contrast, the MPA-based device displays an enhanced PCE of 24.64%, with an increased Voc of 1.170 V, a Jsc of 25.22 mA cm<sup>−2</sup> , and an FF of 83.5%. Compared with the control and MPA-based devices, the PCE of the SBI-based devices further increases to 25.84% (certified 25.05%, Supplementary Fig. 18), mainly owing to improvements in Voc (1.194 V) and FF (84.9%). The device hysteresis is reduced for the SBI-based devices (Supplementary Fig. 19). Notably, when changing the order of MPA and PEAI, the performance of PEAI/MPA-based device shows limited improvement compared to the target SBI (MPA/PEAI)-based device (Supplementary Fig. 20), and the single PEAI-based device also has a lower efficiency than the single MPA-based device (Supplementary Fig. 21 and Supplementary Table 5), confirming the better passivation efficacy of MPA. 

Corresponding external quantum efficiency (EQE) spectra in Fig. 4b yield comparable integrated Jsc to that extracted from J-V curves. The SBI-based devices are measured at the maximum power point (MPP) tracking for 300 s to obtain a stabilized photocurrent of 24.31 mA cm<sup>−2</sup> and a stabilized PCE of 25.53% (Fig. 4c). The statistical analysis of the photovoltaic parameters based on 25 devices exhibits a satisfying reproducibility (Fig. 4d and Supplementary Fig. 22). We also examine the effect of MPA and SBI on PSCs using MA-free 

Cs0.05FA0.95Pb(I0.95Br0.05)3, which shows increased PCEs from 21.36% (control) to 22.84% (MPA) and 23.99% (SBI), respectively (Supplementary Fig. 23 and Supplementary Table 6). 

We conduct analysis of the photovoltage loss for the SBI-based devices. The improved Voc is concomitantly reflected in capacitancevoltage (C-V) plot via Mott-Schottky analysis: C1<sup>2=</sup> A2<sup>2</sup> <u>ðVeεε bi�0NVAÞ</u><sup>~~,~~where Ais</sup> device area, ε is relative permittivity, ε0 is vacuum permittivity, and NA is carrier concentration. The built-in potential (Vbi) increases from 1.00 (control) to 1.09 (MPA) and 1.14 V (SBI), respectively, due to the improved interface energetics (Supplementary Fig. 24). Additionally, according to detailed balance theory<sup>33</sup> , the EQEEL values of 0.78%, 6.05% and 10.30% at the carrier density close to the Jsc for the control, MPA- and SBI-based devices (Fig. 4e), indicating 126, 73 and 59 mV of nonradiative recombination induced Voc loss (ΔVoc, nonrad), respectively. The low ΔVoc, nonrad of the SBI-based device is one of the smallest values reported in inverted PSCs<sup>34,35</sup> , further demonstrating the excellent impact of SBI on reducing nonradiative recombination loss (Fig. 4f and Supplementary Table 7). The suppressed nonradiative recombination is the main factor contributing to the largely increased Voc of the SBI-based devices (Fig. 4g). 

To gain insights on the FF loss, we perform light intensity dependent Voc measurement of the devices (Supplementary Fig. 27). The diode ideality factor (n), extracted from the slope of Voc evolution in term of nkT/q are 1.73, 1.54, and 1.42 for the control, MPA-and SBIbased devices, respectively. The maximum FF (FFmax) without charge transport loss can be estimated by the equation<sup>36</sup> : 

Nature Communications |  (2024) 15:5607 

4 

Article 

https://doi.org/10.1038/s41467-024-50019-3 



<!-- Start of picture text -->
a b 3 3 c 1<br>Control TRPL lifetime<br>MPA/PEAI PLQY<br>0.1<br>2 2<br>0.01  Control<br> MPA/PEAI<br>1 1  Control/ETL<br> MPA/PEAI/ETL<br>700 750 800 850 Control MPA/PEAI 0 50 100<br>Wavelength (nm) Time (ns)<br>d e f<br>10 3 Control/ETL 0.030 10 3 MPA/PEAI/ETL 0.030 1.0<br>0.020 0.020 0.8<br>10 2 0.010 10 2 0.010 Electron extraction<br>0.000 0.000 0.6<br>10 1 -0.010 10 1 -0.010 0.4<br>w ETL<br>10 0 10 0 0.2 Control<br>MPA/PEAI<br>0.0<br>10 -1 10 -1<br>650 700 750 800 850 900 650 700 750 800 850 900 1 10 100 1000<br>Wavelength (nm) Wavelength (nm) Time (ps)<br>).<br>au.<br>( ytis<br>n<br>te<br>In Norm. PLQY<br>Norm. TRPL lifetime Norm. Intensity (a.u.)<br>)s ∆T/T ∆T/T<br>p<br>(<br>e<br>im<br>T Time (ps)<br>Normalized ∆T/T<br><!-- End of picture text -->

Fig. 3 | Impact of SBI on charge carrier dynamics. a PL spectra. b Normalized TRPL lifetime and PLQY of control and SBI-modified perovskite films. c TRPL spectra of control and SBI-modified perovskite films with ETL and without ETL. 

Comparison of fs-TA 2D pseudo-color plots of (d) control and (e) SBI-modified perovskite films with ETL. f Corresponding GSB decay at 770 nm of control and SBImodified perovskite films with ETL. 

FF max = voc�lnvðocvoc + 1+ 0:72Þ ~~,~~ where voc = <u>qnKTV oc</u><sup>~~.~~ThecalculatedFFmaxofthe</sup> control, MPA- and SBI-based devices are 83.53%, 85.44%, and 86.51%, respectively. The discrepancy of FFmax is well consistent with the suppression of nonradiative recombination loss in the devices. Moreover, charge transport induced FF loss declines from 2.22% (control) to 1.92% (MPA) and 1.63% (SBI), respectively, attributed to the increased electron extraction efficiency at the perovskite/ETL interface (Fig. 4h). 

We further examine the operational stability of unencapsulated devices aging 55 ± 5 °C in dry ambient air. The SBI-based device retains about 95% of its initial efficiency after 1000 h, whereas the control device shows an over 20% efficiency loss (Fig. 4i). The SBI-modified device can maintain 88% of its initial efficiency after MPP tracking for 800 h under 1-sun illumination (Insert of Fig. 4i). We attribute the improved thermal and operational stability to the strong covalent bonding between perovskite and MPA, which not only reduces the vulnerable defect sites but also enhances the perovskite lattice structure. Moreover, the SBI-based device has no efficiency degradation after 2000 h storage in ambient air at room temperature (Supplementary Fig. 28). 

## Discussion 

We perform a theoretical analysis via density functional theory (DFT) calculation to better understand the mechanism of the SBI strategy on performance enhancement. We choose the main component FAPbI3 in the calculation for simplification, and a FAI-terminated (001) perovskite surface with the predominant lattice defect of iodine vacancy (VI) is constructed<sup>37</sup> . A noticeable interaction energy (Eint) of −0.41 eV is obtained when deprotonated MPA is placed and relaxed on the perovskite surface, revealing a thermodynamically favorable reaction with the formation of P-O-Pb bonds (2.49 Å) (Fig. 5a). For the surface without MPA treatment, the VI and exposed uncoordinated Pb<sup>2+</sup> induce a localized charge distribution on the perovskite surface, which generates trap states within band gap (Fig. 5b, c and Supplementary Fig. 29). In contrast, the P-O-Pb bonds induced by MPA restore the six- 

coordinate local chemical environment for Pb and lead to a delocalized charge distribution with the disappearance of trap states as demonstrated in the density of states (DOS) plot, rationalizing the defect passivation ability of the in-situ surface chemical reaction. The findings from the PbI-terminated (001) perovskite surface (Supplementary Figs. 29 and 30) exhibit qualitatively consistent behaviors. 

We conduct solid-state nuclear magnetic resonance (ss-NMR) spectra to consolidate the chemical reaction between perovskite and MPA. As shown in Fig. 5d, the<sup>1</sup> H resonance signals of FA(NH2) and MA (CH3) from perovskite indicate an upward chemical shift after MPA treatment, which can be attributed to the hydrogen bonding between FA<sup>+</sup> /MA<sup>+</sup> and MPA. The introduced hydrogen bonds are expected to enhance perovskite crystal structure and beneficial for device stability. Moreover, a new chemical environment at lower chemical shift (around 28.57 ppm) in the<sup>31</sup> P ss-NMR spectra is recorded form the MPA-treated perovskite (Fig. 5e), further demonstrating the reaction between perovskite and MPA in formation of Pb-O-P bonds. The chemical reaction is also expected to reconstruct the perovskite surface energetics by charge transfer and redistribution. As shown in Fig. 5f, a calculated work function difference (ΔWF1) of −1.43 eV is obtained between the control and MPA-treated perovskite surface, where ΔWF1 = WFMPA-treated − WFcontrol. The reduced WF indicates a more n-type perovskite and agrees with UPS results and previous report<sup>16</sup> . Moreover, it is observed a further work function reduction (ΔWF2) of −0.71 eV when PEAI is deposited on the MPA-coated FAPbI3 surface, attributed to the formation of surface dipole. Here, ΔWF2 = WFSBI − WFMPA-treated. These results well demonstrate the significant roles of our SBI strategy on perovskite surface properties, which show significant effectiveness on minimizing trap density and constructing beneficial perovskite surface energetics, and pave ways for the further improvement of PSCs. 

In summary, we have demonstrated a SBI strategy by sequentially depositing MPA and PEAI modulators on the perovskite surface. The MPA induces a surface chemical reaction with the formation of strong 

Nature Communications |  (2024) 15:5607 

5 

Article 

https://doi.org/10.1038/s41467-024-50019-3 



<!-- Start of picture text -->
a 25 b 100 25 c 30 25.53% 30<br>25 25<br>20 80 20<br>20 24.31 mA cm -2 20<br>15 60 15<br>15 15<br>10 40 10 10 10<br>Control Control<br>5 MPA 20 MPA 5 5 MPA/PEAI based device 5<br>MPA/PEAI MPA/PEAI at MPP (1.05 V)<br>0 0 0 0 0<br>0.0 0.2 0.4 0.6 0.8 1.0 1.2 300 400 500 600 700 800 0 50 100 150 200 250 300<br>Voltage (V) Wavelength (nm) Time (s)<br>d e 16 f<br>1.201.16 1412 ControlMPAMPA/PEAI 180160 This work 1.20<br>1.12 10 MPA/PEAI 787 nm 140 1.18<br>1.08<br>8 120 1.16<br>86 6 100 ref 3<br>84 4 700 800 80 1.14<br>82 Wavelength (nm)<br>80 20 6040 ref 1 ref 2 ref 4 ref 5ref 6 1.12<br>Control MPA MPA/PEAI 0.01 0.1 1 10 100  Recent works on  p-i-n PSCs<br>Current density (mA cm -2 )<br>g 1.30 h i 1.0<br>90<br>1.25 Radiative recombination loss 88 Nonradiative recombination  0.8 55 ± 5 ℃, ambient air<br>loss Control<br>1.20 Nonradiative recombination loss 86 0.6 MPA/PEAI<br>1.0<br>84 0.4<br>1.15 0.8<br>SQ limit SQ limit<br>Rad. limit 82 FFmax 0.2 0.6 MPP, AM 1.5 G, N2<br>1.10 V oc measured FF measured 0 200 400 600 800<br>80 0.0<br>Control MPA MPA/PEAI Control MPA MPA/PEAI 0 200 400 600 800 1000<br>Time (h)<br>Transport loss<br>-2)<br>m<br>c<br>A<br>m<br>( ytis<br>en EQE (%) PCE (%)<br>d<br> t<br>n<br>e<br>rr<br>u<br>C -2 (mA cm)Integrated  J sc -2)Current density (mA cm<br> (V) V oc<br> (V) V oc<br>EQE (%)EL<br>EL intensity (a.u.)<br> (mV) V ∆oc, nonrad<br>FF (%)<br> (V) V oc FF (%)<br>Normalized PCE<br><!-- End of picture text -->

Fig. 4 | Photovoltaic performance for PSCs. a J-V curves of champion control, MPA, and SBI-based devices. b EQE spectra and integrated current densities. c Stabilized power output at the MPP for the SBI-based device. d Statistics of Voc and FF obtained from the control, MPA, and SBI-based devices. e EQEEL values of devices operating in the light emitting diode (LED) mode under different current 

densities. f ΔVoc, nonrad of recent reports on p-i-n PSCs. Detailed (g) Voc loss analysis and (h) FF loss analysis of devices. i Stability of unencapsulated control and SBIbased devices aged at 55 ± 5 °C in ambient air. The inset represents continuous MPP tracking (in N2 atmosphere). 

covalent P-O-Pb bonds that provide efficient defect passivation, and the subsequent PEAI layer further modifies the surface energetics by optimizing the surface Fermi level to the PCBM ETL, leading to enhanced interfacial electron extraction. As a result, the MPA/PEAI treated p-i-n PSC achieves a stabilized efficiency of 25.53%, and one of the smallest nonradiative recombination induced Voc loss of only 59 mV. The certified efficiency is 25.05%. Our results suggest that cooperative interface engineering is an efficient strategy to fully modulate perovskite surface and achieve high performance p-i-n PSCs. 

## Methods 

### Materials 

Lead iodide (PbI2), formamidinium iodide (FAI), methylammonium bromide (MABr) and [6,6]-PhenylC61 butyric acid methyl ester (PCBM) were received from Advanced Election Technology Co. Ltd. Lead bromide (PbBr2), methylamine hydrochloride (MACl), cesium iodide (CsI), 2-phenylethylammonium iodide (PEAI) and bathocuproine (BCP) were purchased from Xi’an Polymer Light Technology Corp. [2-(3,6dimethoxy-9H-carbazol-9-yl)ethyl]phosphonic acid (MeO-2PACz) and 4-methoxyphenylphosphonic acid (MPA) were obtained from TCI America. Dimethylformamide (DMF), dimethyl sulfoxide (DMSO), chlorobenzene (CB), and ethanol and isopropanol (IPA) were 

purchased from Sigma Aldrich. Tin oxide (SnO2) colloid precursor (15% in H2O colloidal dispersion) was received from J&K Scientific. All materials are used as received. 

### Perovskite precursor solution and film preparation 

Triple cation perovskite Cs0.05(FA0.95MA0.05)0.95Pb(I0.95Br0.05)3 precursor (1.3 M) was prepared by mixing PbI2, PbBr2, FAI, MABr, and CsI in DMF/DMSO (4:1 in V/V) mixed solvent according to the stochiometric ratio. An additional 30 mol% MACl was added to the precursor. The perovskite precursor was spin-coated at 4000 rpm for 40 s with a ramp of 800 rpm s<sup>−1</sup> , during which 200 μL CB was dropped on the film at 7 s before the end of the spin-coating. The film was then annealed at 100 °C for 30 min. MA-free perovskite Cs0.05FA0.95Pb(I0.95Br0.05)3 precursor (1.3 M) was prepared by mixing PbI2, PbBr2, FAI, and CsI in DMF/ DMSO (4:1 in V/V) mixed solvent according to the stochiometric ratio. The perovskite film was processed with the same method as triplecation perovskite. 

### Device fabrication 

Patterned indium-tin oxide (ITO) substrate was cleaned by detergent, ultra-pure water, ethanol, and isopropanol under ultrasonication for 15 min, respectively and then dried in an oven. The cleaned ITO was 

Nature Communications |  (2024) 15:5607 

6 

Article 

https://doi.org/10.1038/s41467-024-50019-3 



<!-- Start of picture text -->
a b c<br>E int = -0.41 eV Total<br>2.49 Å Pb<br>I<br>Trap state<br>Pb I Pb I Pb Pb I Pb I Pb Total<br>Pb<br>I<br>MPA<br>0 0.5 1 -2 -1 0 1 2 3<br>Pb I C N P O H<br>Energy (eV)<br>d Perovskite e P-O-Pb f 5 Vacuum<br>Perovskite/MPA<br>MPA FA(NH2) Perovskite/MPA 0<br>-5 E F<br>WF= 4.87 eV<br>MA(CH3) -10 WF= 3.44 eV<br>WF= 2.73 eV<br>-15<br>MPA Control<br>MPA<br>-20<br>MPA/PEAI<br>-5 0 5 10 -100 -50 0 50 100 5 10 15 20 25<br>1H Chemical shift (ppm) 31P Chemical shift (ppm) Z (Å)<br>DOS (a.u.)<br>Potential (eV)<br><!-- End of picture text -->

Fig. 5 | Theoretical analysis of interaction between perovskite and SBI. a Optimized structure of MPA treated FAI-terminated perovskite (001) surface containing an iodine vacancy. b Calculated electron localization function and (c) density of states (DOS) projected onto elements of FAI-terminated surface with an iodine vacancy before and after MPA treatment. The result of the perovskite 

surface without iodine vacancy is shown in Supplementary Fig. 29. d<sup>1</sup> H and (e)<sup>31</sup> P ss-NMR spectra of perovskite, MPA treated perovskite and neat MPA. f Work function difference (ΔWF) among control, MPA-treated, and SBI-treated perovskite surfaces. 

treated by UV-ozone for 20 min before use. MeO-2PACz (0.5 mg ml<sup>−1</sup> in ethanol) as HTL was deposited on ITO at 5000 rpm for 30 s and annealed at 100 °C for 10 min. The perovskite film was coated on HTL by the abovementioned method. MPA (1–7 mg ml<sup>−1</sup> in ethanol) was deposited on the perovskite film at 4000 rpm for 30 s and annealed at 100 °C for 10 min. Then, PEAI (0.5–5 mg ml<sup>−1</sup> in IPA) was spin-coated at 4000 rpm for 30 s without annealing. Notably, MPA is not dissolved in IPA, and hence is not ruined during PEAI deposition. After that, PCBM (20 mg ml<sup>−1</sup> in CB) as ETL was spin-coated at 1800 rpm for 40 s. BCP (0.5 mg ml<sup>−1</sup> in IPA) was dynamically deposited on PCBM at 6000 rpm for 30 s. Finally, 100 nm Ag was thermally evaporated under high vacuum (<2 × 10<sup>−4</sup> Pa). The device active area was defined as 0.05 cm<sup>2</sup> . 

### Film characterization 

Scanning electron microscope (SEM, Zeiss G450) was performed to characterize the surface and cross-section morphology of perovskite films. KPFM was attained by Dimension Icon SPM (Bruker) with a Pt/ Ir-coated tip in lift-mode. X-ray diffraction (XRD) pattern was recorded to examine perovskite crystallinity using PANalytical X-ray diffractometer with Cu Kα radiation. UV-vis absorption spectra were measured by UV-vis-NIR spectrometer (TU-1901). Steady state photoluminescence (PL) and time-resolved photoluminescence (TRPL) were obtained by a time-corrected single photon counting (TCSPC) system with an excitation wavelength of 450 nm. FTIR measurements were conducted by the PerkinElmer FTIR spectrometer equipped with an attenuated total reflectance accessory. TAS was performed with a Yb:KGW laser (1030 nm, 220 fs Gaussian fit, 100 kHz, Light Conversion Ltd) and a spectrometer (Acton SpectraPro 275) equipped with a line array CCD. ss-NMR spectra were recorded in a Bruker Avance (600 MHz) NMR spectrometer. The perovskite powders were scrapped from glass substrates which were deposited by the same method in device process, and then packed in a magic angle spinning 

(MAS) rotor in N2-filled glovebox before being transferred into the NMR probe. Photoluminescence quantum yields (PLQYs) were measured using an integrating sphere with a 450 nm excitation source and 1 sun equivalent intensity. The output of the integrating sphere was collected with a fiber connected with an Andor Kymera 193i spectrometer using a silicon CCD camera (iDus DU240A-OE). The system was calibrated with a halogen calibration lamp (HL-3 plus CAL from Ocean Optics). 

### Device characterization 

Current-voltage (J-V) curves of PSCs were recorded via Keithley 2400 system and solar simulator (SS-F5-3A, Enlitech) in the N2-filled glovebox without any preconditioning. The light intensity (AM 1.5 G, 100 mW cm<sup>−2</sup> ) was calibrated with a NREL certified Si cells (KG-2) to keep the spectral mismatch correction at 1.00 ± 0.01. The measurement was proceeded with a scan rate of 0.1 V s<sup>−1</sup> , a voltage step of 0.02 V and delay time of 10 ms. The EQE spectra from 300 to 850 nm were collected by a QE-R system (Enlitech). The operational stability of the unencapsulated devices at the MPP tracking was tested under a commercial xenon lamp chamber with one-sun (AM 1.5G) illumination in nitrogen atmosphere. Capacitance-voltage (C-V) curve was conducted by an impedance spectroscope (PGSTAT302N, Autolab) with a frequency of 5 kHz. A digital oscilloscope (DOS-X 3104 A) was used to measure the transient photovoltage decay at open-circuit condition. SCLC measurement was applied to determine the electron trap density and mobility using the electron-only devices. The J-V curves are conducted under dark condition, which can be divided into three regions: the Ohmic region (n = 1), the trap-filling limit (TFL) region (n >3) and the SCLC region (n = 2). n refers to the slope of linear region. In the TFL region, the trap density (Nt) is determined by the onset of the trap eNt L<sup>2</sup> filling limit voltage (VTFL) using the equation: V TFL = 2εε0<sup>~~,~~where ε0 is</sup> the vacuum permittivity, and εr is the relative permittivity of 

Nature Communications |  (2024) 15:5607 

7 

Article 

https://doi.org/10.1038/s41467-024-50019-3 

perovskite. L is the thickness of perovskite layer. In the SCLC region, the electron mobility (μe) can be calculated according to the MottoGurney law: Jd = <u>98</u><sup>εε0μ</sup> <u>VL</u><sup>32</sup><sup>~~,~~where Jisthecurrentdensity,andVisthe</sup> base voltage. 

### Photoelectron spectroscopy measurement 

Ultraviolet and X-ray photoelectron spectroscopy (UPS and XPS) measurements were performed in ultrahigh vacuum surface analysis system (base pressure ≈ 10<sup>−10</sup> mbar) equipped with Scienta-R3000 spectrometer. UPS employed a monochromatic He I light (21.22 eV) as the excitation source with an energy resolution of 50 meV. The work function and VBM were derived from the secondary electron cutoff and the frontier edge of the occupied density states to vacuum level, respectively. XPS was measured using the monochromatic Al Kα (1486.6 eV). All spectra were calibrated by referencing to Fermi level and Au 4 f7/2 position of the Ar<sup>+</sup> ion sputter-cleaned Au foil, and Fermi level was referred as the zero BE. 

### Ultrafast transient absorption spectroscopy 

fs-TA spectroscopy was carried out by a Yb:KGW laser amplifier(Light Conversion Ltd), which provides 800 nm fundamental pulses with pulse width of 100 fs at 1 kHz. The fundamental pulses were separated to two light beams, where the pump beam (400 nm) was generated by an optical parametric amplifier (ORPHEUS-N, Light Conversion Ltd), the probe beam (white light continuum) was generated by focusing on a YAG plate. The pump and probe beam were spatially overlapped on the sample at a small angle less than 10°.The transmitted probe light from sample was collected by a linear chargecoupled device (CCD) array. The transient absorption spectra at selected pump-probe delay time were fitted by single-exponential <u>t</u> equation: y = A1 exp�� τ1�. 

### Electroluminescence efficiency measurements 

The electroluminescence (EL) spectra were recorded by a Kymera-328I spectrograph and a Si EMCCD camera (DU970PBVF, Andor). EL efficiency (EQEEL) was performed via a digital source meter (Keithley 2400) for injecting current into perovskite solar cell and a picometer (Keithley 6482) with a Si photodiode for quantifying photons emitted from the device. 

### Density functional theory calculations 

DFT calculations were performed using the plane-wave pseudopotential method as implemented in the Vienna Ab initio Simulation Package. The electron-ion interactions were described by the projected augmented-wave pseudopotentials. The generalized gradient approximation formulated by Perdew, Burke, and Ernzerhof was used as the exchange correlation functional. Structural optimizations were obtained by fully relaxing all the atoms through total energy minimization with the residual forces on the atoms converged to below 0.05 eV Å<sup>−1</sup> . The kinetic energy cutoff for the plane-wave basis was chosen to be 500 eV. To properly consider the long-range van der Waals (vdWs) interactions that play a nonignorable role in the hybrid perovskites involving organic molecules, the optB86b-vdW functional was adopted. The vacuum space was set to 15 Å along the out-of-plane direction of a FAI/PbI-terminated (001) FAPbI3 perovskite surface to avoid interactions between periodic images. Considering the large simulation cell, we used only one k-point (gamma) to sample the Brillion zone. The interaction energy (Eint) is computed as the energy difference between FAI/PbI-terminated (001) FAPbI3 perovskite surfaces containing a single iodine vacancy defect, with and without modification by MPA molecules. 

### Reporting summary 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

## Data availability 

The data that support the findings of this study are available in the Supplementary Information/Source Data file. Source data are provided with this paper. 

## References 

1. Lin, Y.-H. et al. A piperidinium salt stabilizes efficient metal-halide perovskite solar cells. Science 369, 96–102 (2020). 

2. Al-Ashouri, A. et al. Monolithic perovskite/silicon tandem solar cell with> 29% efficiency by enhanced hole extraction. Science 370, 1300–1309 (2020). 

3. Lin, R. et al. All-perovskite tandem solar cells with improved grain surface passivation. Nature 603, 73–78 (2022). 

4. Li, C. et al. Rational design of Lewis base molecules for stable and efficient inverted perovskite solar cells. Science 379, 690–694 (2023). 

5. Li, G. et al. Highly efficient pin perovskite solar cells that endure temperature variations. Science 379, 399–403 (2023). 

6. Peng, W. et al. Reducing nonradiative recombination in perovskite solar cells with a porous insulator contact. Science 379, 683–690 (2023). 

7. Sha, W. E. I., Ren, X., Chen, L. & Choy, W. C. H. The efficiency limit of CH3NH3PbI3 perovskite solar cells. Appl. Phys. Lett. 106, 221104 (2015). 

8. Doherty, T. A. et al. Performance-limiting nanoscale trap clusters at grain junctions in halide perovskites. Nature 580, 360–366 (2020). 

9. Lin, Y. et al. Revealing defective nanostructured surfaces and their impact on the intrinsic stability of hybrid perovskites. Energy Environ. Sci. 14, 1563–1572 (2021). 

10. Wang, R. et al. Constructive molecular configurations for surfacedefect passivation of perovskite photovoltaics. Science 366, 1509–1513 (2019). 

11. Chen, B., Rudd, P. N., Yang, S., Yuan, Y. & Huang, J. Imperfections and their passivation in halide perovskite solar cells. Chem. Soc. Rev. 48, 3842–3867 (2019). 

12. Li, N. et al. Cation and anion immobilization through chemical bonding enhancement with fluorides for stable halide perovskite solar cells. Nat. Energy 4, 408–415 (2019). 

13. Yang, S. et al. Stabilizing halide perovskite surfaces for solar cell operation with wide-bandgap lead oxysalts. Science 365, 473–478 (2019). 

14. Allen, T. G., Bullock, J., Yang, X., Javey, A. & De Wolf, S. Passivating contacts for crystalline silicon solar cells. Nat. Energy 4, 914–928 (2019). 

15. Xiong, S. et al. Direct observation on p- to -type transformation of perovskite surface region during defect passivation driving high photovoltaic efficiency. Joule 5, 467–480 (2021). 

16. Chen, H. et al. Regulating surface potential maximizes voltage in allperovskite tandems. Nature 613, 676–681 (2023). 

17. Yang, J. et al. Energetics and energy loss in 2D Ruddlesden-Popper perovskite solar cells. Adv. Energy Mater. 10, 2000687 (2020). 

18. Tan, S. et al. Stability-limiting heterointerfaces of perovskite photovoltaics. Nature 605, 268–273 (2022). 

19. Sharma, C. K., Clearfield, A., Cabeza, A., Aranda, M. A. & Bruque, S. Deprotonation of phosphonic acids with M<sup>2+</sup> cations for the design of neutral isostructural organic- inorganic hybrids. J. Am. Chem. Soc. 123, 2885–2886 (2001). 

20. Tan, Q. et al. Inverted perovskite solar cells using dimethylacridinebased dopants. Nature 620, 545–551 (2023). 

21. Cheng, C. et al. A novel organic phosphonate additive induced stable and efficient perovskite solar cells with efficiency over 24% enabled by synergetic crystallization promotion and defect passivation. Nano Lett. 23, 8850–8859 (2023). 

22. Liu, J. et al. Dual role of rapid transport and efficient passivation in inverted methylammonium-free perovskite solar cells utilizing a 

Nature Communications |  (2024) 15:5607 

8 

Article 

https://doi.org/10.1038/s41467-024-50019-3 

self-assembled porous insulating layer. Adv. Energy Mater. 14, 2303092 (2024). 

23. Pujari, S. P., Scheres, L., Marcelis, A. T. & Zuilhof, H. Covalent surface modification of oxide surfaces. Angew. Chem., Int. Ed. 53, 6322–6356 (2014). 

24. Paniagua, S. A. et al. Phosphonic acids for interfacial engineering of transparent conductive oxides. Chem. Rev. 116, 7117–7158 (2016). 

25. Li, T. et al. Inorganic wide-bandgap perovskite subcells with dipole bridge for all-perovskite tandems. Nat. Energy 8, 610–620 (2023). 

26. Cui, P. et al. Planar p-n homojunction perovskite solar cells with efficiency exceeding 21.3. Nat. Energy 4, 150–159 (2019). 

27. Li, X. et al. Constructing heterojunctions by surface sulfidation for efficient inverted perovskite solar cells. Science 375, 434–437 (2022). 

28. Bao, Q. et al. Trap-assisted recombination via integer charge transfer states in organic bulk heterojunction photovoltaics. Adv. Funct. Mater. 24, 6309–6316 (2014). 

29. Li, N. et al. Liquid medium annealing for fabricating durable perovskite solar cells with improved reproducibility. Science 373, 561–567 (2021). 

30. Xu, W. et al. Impact of interface energetic alignment and mobile ions on charge carrier accumulation and extraction in p-i-n perovskite solar cells. Adv. Energy Mater. 13, 2301102 (2023). 

31. Peng, J. et al. Nanoscale localized contacts for high fill factors in polymer-passivated perovskite solar cells. Science 371, 390–395 (2021). 

32. Peng, J. et al. Centimetre-scale perovskite solar cells with fill factors of more than 86 per cent. Nature 601, 573–578 (2022). 

33. Wang, J. et al. Highly efficient all-inorganic perovskite solar cells with suppressed non-radiative recombination by a Lewis base. Nat. Commun. 11, 177 (2020). 

34. Li, Z. et al. Organometallic-functionalized interfaces for highly efficient inverted perovskite solar cells. Science 376, 416–420 (2022). 

35. Li, F. et al. Regulating surface termination for efficient inverted perovskite solar cells with greater than 23% efficiency. J. Am. Chem. Soc. 142, 20134–20142 (2020). 

36. Jeong, M. J. et al. Boosting radiation of stacked halide layer for perovskite solar cells with efficiency over 25%. Joule 7, 112–127 (2023). 

37. Jeong, J. et al. Pseudo-halide anion engineering for α-FAPbI3 perovskite solar cells. Nature 592, 381–385 (2021). 

## Acknowledgements 

The work is financially supported by the National Key Research and Development Program of China (2022YFB3803300), the National Science Foundation of China grant (62322407, 22279034, 52261145698, 62125402, 62321166653), and Shanghai Science and Technology Innovation Action Plan (22ZR1418900). S.X. thanks the project funded by China Postdoctoral Science Foundation grant (BX20220089, 2022M720742). X.L, M.F., F.W., and F.G. acknowledge support by the Swedish Government Strategic Research Area in Materials Science on Functional Materials at Linköping University (Faculty Grant SFO Mat LiU no. 200900971). Calculations were performed in part at the highperformance computing center of Jilin University. We thank Tiankai 

Zhang (Linköping University) for discussion on PL and PLQY measurements. 

## Author contributions 

Q.B. and F.G. supervised the research project. S.X. fabricated the devices, conducted the characterizations, and wrote the manuscript. S.X. and S.J. contributed to the UPS and XPS measurements. F.T. performed the DFT calculations. A.C. performed KPFM measurements. Z.C. conducted TAS measurements. D.L. performed the PL and TRPL measurements. B.X. conducted SEM measurements. H.W. performed EQEEL measurements. H.Q. carried out ssNMR measurements. Y.Z. carried out FTIR measurements. F.W., Z.M., J.T., H.Z., Y.Y., X.L., L.Z., Z.S., M.F., J.C., F.G. and Q.B. contributed to the data analysis and revised the manuscript. All authors discussed the results and contributed to the manuscript. 

## Funding 

Open access funding provided by Linköping University. 

## Competing interests 

The authors declare no competing interests. 

## Additional information 

Supplementary information The online version contains supplementary material available at 

https://doi.org/10.1038/s41467-024-50019-3. 

Correspondence and requests for materials should be addressed to Lijun Zhang, Feng Gao or Qinye Bao. 

Peer review information Nature Communications thanks Guang Yang and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. A peer review file is available. 

Reprints and permissions information is available at 

http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http://creativecommons.org/ licenses/by/4.0/. 

#### © The Author(s) 2024 

Nature Communications |  (2024) 15:5607 

9 

