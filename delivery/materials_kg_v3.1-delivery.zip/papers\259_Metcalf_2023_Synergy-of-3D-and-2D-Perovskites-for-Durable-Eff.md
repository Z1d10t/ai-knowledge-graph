# Synergy of 3D and 2D Perovskites for Durable, Efficient Solar Cells and Beyond.

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Chemical Reviews |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 206 |
| 作者 | Isaac Metcalf, S. Sidhik, Hao Zhang, A. Agrawal, Jessica H. Persaud, Jin-Yu Hou, J. Even, A. Mohite |
| DOI | 10.1021/acs.chemrev.3c00214 |
| 源文件 | 046_Metcalf_2023_Synergy-of-3D-and-2D-Perovskites-for-Durable-Eff.pdf |

---
pubs.acs.org/CR 

<mark>Review</mark> 



# **Synergy of 3D and 2D Perovskites for Durable, Efficient Solar Cells and Beyond** 

_Published as part of the Chemical Reviews virtual special issue “Emerging Materials for Optoelectronics”._ Isaac Metcalf, Siraj Sidhik, Hao Zhang, Ayush Agrawal, Jessica Persaud, Jin Hou, Jacky Even, and Aditya D. Mohite* 

**Cite This:** _Chem. Rev._ 2023, 123, 9565−9652 

**Read Online** 

## ACCESS 

Metrics & More Article Recommendations 

ABSTRACT: Three-dimensional (3D) organic−inorganic lead halide perovskites have emerged in the past few years as a promising material for low-cost, high-efficiency optoelectronic devices. Spurred by this recent interest, several subclasses of halide perovskites such as two-dimensional (2D) halide perovskites have begun to play a significant role in advancing the fundamental understanding of the structural, chemical, and physical properties of halide perovskites, which are technologically relevant. While the chemistry of these 2D materials is similar to that of the 3D halide perovskites, their layered structure with a hybrid organic−inorganic interface induces new emergent properties that can significantly or sometimes subtly be important. Synergistic properties can be realized in systems that combine different materials exhibiting different dimensionalities by exploiting their intrinsic compatibility. In many cases, the weaknesses of each material can be alleviated in heteroarchitectures. For example, 3D-2D halide perovskites can demonstrate novel behavior that neither material would be capable of separately. This review describes how the structural differences between 3D halide perovskites and 2D halide perovskites give rise to their disparate materials properties, discusses strategies for realizing mixeddimensional systems of various architectures through solution-processing techniques, and presents a comprehensive outlook for the use of 3D-2D systems in solar cells. Finally, we investigate applications of 3D-2D systems beyond photovoltaics and offer our perspective on mixed-dimensional perovskite systems as semiconductor materials with unrivaled tunability, efficiency, and technologically relevant durability. 

### **CONTENTS** 

- 3.1.3. Nonradiative Recombination in 3D Hal- 

- ide Perovskites 9576 

- 3.1.4. Carrier Transport in 3D Halide Perovskites 9576 

- 3.1.5. Urbach Energy in 3D Halide Perovskites 9577 3.1.6. Solution Processability of 3D Halide Perovskites 9577 

|1. Introduction|9566|
|---|---|
|Part 1. Individual Properties of 3D and 2D Halide<br>Perovskites|9567|
|2. Structural Properties of 3D and 2D Halide||
|Perovskites|9567|
|2.1. Crystallographic Structure of 3D Halide<br>Perovskites|9567|
|2.2. From 3D to 2D: Reduced Dimensionality<br>while Maintaining Corner-Sharing Octahe-<br>dra|9568|
|2.3. From 2D to Quasi-2D: Introducing_n_-Value|9569|
|3. Optoelectronic properties of 3D and 2D Halide<br>Perovskites|9572|
|3.1. Semiconductor Properties of 3D Halide<br>Perovskites|9572|



- 3.1.7. Ionic Mobility in 3D Halide Perovskites and Resistance to Extrinsic Electrical Doping 

      - 9580 9580 

   - 3.1.8. Bulk Ferroelectricity in 3D Halide Perovskites 9580 

   - 3.1.9. Best-Performing 3D Halide Perovskite Devices 9582 

3. Optoelectronic properties of 3D and 2D Halide Perovskites 3.1. Semiconductor Properties of 3D Halide Perovskites 



Received: April 5, 2023 Published: July 10, 2023 9572 9574 

- 3.1.1. From Structure to Optoelectronic Properties: The Physical Basis for 3D Halide Perovskites’ Bandgap 

- 3.1.2. Origin of Defect Tolerance in 3D Halide Perovskites 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

© 2023 American Chemical Society 

**9565** 

### **<u>Chemical Reviews</u>** 

|**Chemical Reviews**|**p**|**ubs.acs.org/CR**<br>|Review|
|---|---|---|---|
|3.2. Semiconductor Properties of 2D Halide<br>Perovskites<br>|9583|6.1.5. Solvent Selective Technique for Solution<br>Processed Phase-Pure 2D Halide Perov-||
|3.2.1. Origin of 2D Halide Perovskites’ Wider||skites|9623|
|Bandgap and Optical Spectrum<br>|9583|6.2. Orientation of 2D Halide Perovskites on 3D<br>||
|3.2.2. Defect Tolerance in 2D Halide Perov-||Halide Perovskites|9623|
|skites|9585|6.3. Dimensional (_n_-Value) Control of the 2D||
|3.2.3.NonradiativeRecombinationin2DHal-||Halide Perovskite Layer on 3D Halide Perov-||
|<br>ide Perovskites|9585|<br>skites|9624|
|3.2.4. Carrier Transport of 2D Halide Perov-<br>||6.4. Thickness Control of the 2D Halide Perov-<br>||
|skites|9587|skite Layer on 3D Halide Perovskites|9627|
|3.2.5. Urbach Energy in 2D Halide Perovskites|9590|6.5. Semiconductor Heterojunctions|9630|
|3.2.6. Solution Processability of 2D Halide||6.5.1. Graded Heterojunctions|9630|
|Perovskites|9590|6.5.2. Sharp Heterojunctions|9631|
|3.2.7. Ionic Mobility in 2D Halide Perovskites||7. Synergistic Applications of Mixed 3D-2D Halide||
|and Potential for Electrical Doping|9593|Perovskites|9631|
|3.2.8.Bulk Ferroelectricity in 2D Halide Perov-||7.1.Two-DimensionalHalidePerovskitesas||
|<br>skites|9594|<br>Selective Contacts|9631|
|329Photodopingof2DHalidePerovskites/||723D/2D Halide Perovskites for Light Emitting||
|...     <br>Light-Induced Lattice Dynamics|9595|..  <br>Diodes|9632|
|3.2.10. Best-Performing 2D Halide Perovskite||7.3. 3D/2D Halide Perovskites for Photodetectors|9632|
|Devices|9596|7.4. 3D/2D Halide Perovskites in Lasing Applica-||
|4. Stability of 3D and 2D Halide Perovskites|9598|tions|9633|
|4.1. Issues with 3D Halide Perovskite Stability|9598|8. Conclusions|9634|
|<br>4.1.1. Chemical Instability of MAPbI3|9598|8.1. Future Work for 3D-2D Stacks|9634|
|4.1.2. Phase Instability of FAPbI3and CsPbI3<br>|9599<br>|8.1.1. Orientation Control of 2D Layers<br>|9634|
|4.1.3. Phase Segregation in Mixed Systems|9599|8.1.2. Interface Sharpness, Chemistry Control,||
|<br>414Solar Cell Device-Level Stabilit and the||and_n_-Value Control of 2D Laers|9634|
|... y<br>Effect of Bias|9600|y<br>8.1.3. 2D Band Tuning and Electrical Doping|9634|
|f<br>415BSit Oidti i S d PbS Hlid||<br>8142D3D d 2D3D2D Stk|9634|
|... -e xaon n n an -n ae<br>Perovskites|9600|... - an -- acs<br>8.1.5. Functionalizing 2D Layers|9634|
|4.1.6. 3D Halide Perovskite Self-Healing|9600|<br>8.2. Future Work for 3D-2D Composites|9634|
|417Current State-of-the-Art 3D Stability|9601|821Improving Hydrophobicity and Stability||
|...  <br>4.2. Improved Stability with 2D Halide Perov-||...  <br>of 3D-2D Composites|9634|
|skites<br>|9602|8.2.2. Multifunctional A**′**-Site Cations for De-<br>||
|4.2.1. Comparing the Stability of RP, DJ, and||fect Passivation|9634|
|ACI 2D Halide Perovskites<br>|9602|8.2.3. Lattice Matching and Strain Control<br>|9634|
|4.2.2. Mechanistic Rationale for 2D Halide||8.2.4. Imbuing 3D Bulk with 2D Materials||
|Perovskites’ Improved Stability|9602|Properties|9635|
|4.2.3. Novel Degradation Pathways in 2D||8.2.5. Characterization of 3D-2D Microstruc-||
|Halide Perovskites|9604|ture|9635|
|4.2.4.Stabilityof2DHalidePerovskitesCom-||Author Information|9635|
|<br>pared to 3D Halide Perovskites|9605|<br>Corresponding Author|9635|
|425MethodstoImrove2DHalidePerov-||Authors|9635|
|...   p   <br>skite Stability|9605|Notes|9635|
|<br>Part 2. Combining 3D and 2D Halide Perovskites|9607|Biographies|9635|
|5. Doping 3D Halide Perovskites with 2D Halide||Acknowledgments|9636|
|Perovskites|9607|List of Terms|9636|
|5.1. Long Chain Monoammonium Cations|9608|Structures and Architectures|9636|
|<br>5.2. Zwitterion-Type Spacer Cations (Bifunctional||<br>Device Layers|9637|
|Spacer Cations)|9611|Chemicals|9637|
|<br>5.3. Aromatic Ring Monoammonium Spacer||Characterization Techniques|9637|
|Cations|9615|<br>Physics Terms|9637|
|5.4. Diammonium Spacer Cations|9620|Device Parameters|9637|
|<br>55ACIT S Cti|9620|Mt Cditi|9637|
|.. -ype pacer aons<br>6. Capping 3D Halide Perovskite with 2D Halide||easuremen onons<br>References|9637|
|Perovskite|9620|||
|61ProcessingMethodsforCapped3D-2D||||
|..     <br>Halide Perovskites|9620|**1. INTRODUCTION**||
|6.1.1. Interdiffusion Method<br>|9620<br>|The projected economic, environmental, and huma|nitarian|
|6.1.2. Antisolvent Method<br>h|9621<br>|costs of climate change have prompted an urgent call f<br>|or rapid<br>|
|6.1.3. Vapor-Based Metod<br>6.1.4. Solid Phase in-Plane Growth|9621<br>9623|and sustained decarbonization of all aspects of human<br>Wihhiihliiii|activity.<br>h|



The projected economic, environmental, and humanitarian costs of climate change have prompted an urgent call for rapid and sustained decarbonization of all aspects of human activity. With the recognition that electricity generation is among the easiest sectors to decarbonize, most road maps for deep 

**9566** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

decarbonization suggest the immediate replacement of fossil fuel generating capacity with renewables and long-duration energy storage and the simultaneous electrification of as many highemission sectors, such as transportation and industry, as possible. As a result, global renewable electricity generation capacity must increase from 3.1TW in 2021 to 7.1TW by 2030, and between 2030 and 2050 an additional 630GW of solar photovoltaic capacity alone must be installed every year.<sup>1−3</sup> While the building of renewable energy generating capacity must begin immediately to avoid intractably destructive climate change, it must also continue for decades in order to create the infrastructure needed for a sustainable future, justifying both the rapid manufacture of silicon solar cells and continued research into lower-cost near- and medium-term solar technology. 

Halide perovskite solar cells are perhaps the most promising emerging solar technology for near-term deployment, having reached efficiencies exceeding those of silicon solar cells for single-junction devices using completely recyclable materials and manufacturing processes with near-ambient temperatures, thus making them potentially much cheaper than silicon.<sup>4</sup> Moreover, H-silicon tandem architectures are challenging at the lab-scale the champion tandem solar cells based on ultrahighcost III−V semiconductor heterostructures.<sup>5</sup> However, these highest-efficiency halide perovskite cells use a 3D halide perovskite absorber layer that is susceptible to degradation by environmental stressors and device operation. Stability has also held 3D perovskites back in a variety of other potential optoelectronics applications including LEDs, lasing, and photodetection. 

Lower-dimensional quasi-2D halide perovskites, having a wider bandgap than 3D perovskites, also have shown success as solar cells, LEDs, lasers, and photodetectors. With a layered architecture created by splitting the 3D perovskite lattice with hydrophobic spacer cations, 2D halide perovskites show significantly improved stability compared to their 3D counterparts. However, devices made with these absorbers trail 3D halide perovskite cells in terms of efficiency. Unfortunately, the same structural properties that imbue 2D halide perovskites with better stability are responsible for their lower solar cell performance. For a real-world solar cell, it is mandatory that both high stability and high efficiency are realized in the same device. 

However, there need not be a trade-off between stability and efficiency in halide perovskite photovoltaics. In fact, 3D halide perovskites and 2D halide perovskites are extremely compatible materials that can be incorporated together into a single device in a variety of architectures. Combining 3D and 2D halide perovskites in one solar cell can achieve the stability of the 2D without sacrificing the efficiency of the 3D. Additionally, through the passivation of defects, grain boundaries, and interfaces, 3D-2D halide perovskite devices can exhibit superior stability and efficiency than their constituent materials alone. Recent developments in materials processing leading to a better control of the 2D-3D heterostructures are now also opening novel opportunities for device optimization and innovative multilayered device architectures. While 3D-2D halide perovskites still lag behind the figures of merit required for commercialization, we see a clear path toward reaching those parameters that would not be possible in a single-phase system. Such developments initiated in the context of solar cells will foster further progress for myriad other optoelectronic applications based on halide perovskite semiconductors, in particular for light emission and photodetection. 

This review explores the structures, optoelectronic properties, and stabilities of 3D and 2D halide perovskites, investigating the structural explanations for their materials properties. We then discuss incorporation mechanisms to realize 3D-2D halide perovskite devices with both doped and capped architectures. We review the performance of 3D-2D halide perovskites with various architectures reported in literature and discuss what approaches have shown the most success. Finally, we discuss future avenues for advanced semiconducting devices using 3D2D architectures. While several excellent reviews and perspectives have been published on the properties of 3D and 2D perovskites alone, the recent focus on mixed-dimensional perovskites deserves its own exploration. To that end, the purpose of this review is to summarize the state of the field for 3D-2D halide perovskites, and to serve as a handbook for future investigation of mixed-phase halide perovskites as this area of research grows in popularity for photovoltaics and other optoelectronic device technologies. 

### **PART 1. INDIVIDUAL PROPERTIES OF 3D AND 2D HALIDE PEROVSKITES** 

### **2. STRUCTURAL PROPERTIES OF 3D AND 2D HALIDE PEROVSKITES** 

### **2.1. Crystallographic Structure of 3D Halide Perovskites** 

Halide perovskites are a class of ionic crystals with stoichiometry A<sup>+</sup> B<sup>2+</sup> X<sup>−</sup> 3<sup>, where X isa halogen, B is usually a heavy group-IV</sup> metal such as Sn or Pb, and A is either an organic or inorganic monovalent cation. The broader perovskite crystallographic structure supports other ionic materials including oxides with different charge combinations (e.g., A<sup>2+</sup> B<sup>4+</sup> O<sup>2−</sup> 3<sup>),butthese</sup> materials are less useful as semiconductors for optoelectronics and will not be discussed here. In the ideal (cubic) perovskite structure, the B<sup>2+</sup> and X<sup>−</sup> ions form a lattice of corner-sharing BX6 octahedra with B-sites in the center of each octahedron and X-sites at the corners. Eight neighboring octahedra define the cuboctahedral A-site (Figure 1a).<sup>6</sup> The semiconducting properties of halide perovskites derive from the s/p orbital overlap of the B and X ions in the 3D sublattice of octahedra, with the A- site stabilizing the structure and maintaining the crystal’s charge neutrality.<sup>7</sup> A lower-symmetry lattice of corner-sharing BX6 octahedra obtained from the reference cubic perovskite structure by lattice distortion is also defined as a perovskite by extension. 

If the A-site cation is too small to fill the cuboctahedral site, the BX6 octahedra will undergo cooperative in- and out-of-plane tilts to reduce the volume of the A-site, distorting the lattice from cubic to tetragonal or orthorhombic.<sup>8</sup> The Goldschmidt tolerance factor ( _t_ ) is a geometric factor of the three ionic radii which can be used to predict the stability and degree of octahedral distortion in a perovskite system: _t_ = ( _r_ A + _r_ X)/√2( _r_ B + _r_ X).<sup>9,10</sup> The factor can be derived from the geometry of the perovskite structure and is defined such that for _t_ = 1 hard spheres of A, B, and X would touch without intersecting to form a cubic unit cell. For _t_ = 1 the structure is perfectly cubic, with a Pb−I−Pb bond angle of 180° between corner-sharing octahedra. If 0.8 < _t_ < 1, the octahedral tilt lowers the Pb−I− Pb angles and yields a lower-symmetry lattice, either tetragonal or orthorhombic (Figure 1b). For _t_ < 0.8 the required distortion will be too severe, and the perovskite structure does not form. Likewise, for _t_ > 1 the cuboctahedral site cannot accommodate the A cation and a nonperovskite phase will be the stable phase. 

**9567** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 1. Structures and tolerance factors of 3D perovskites. (a) Cubic perovskite crystal structure. Reproduced with permission from ref 20. Copyright 2014 Springer Nature. (b) Comparison between orthorhombic (left), tetragonal (middle), and cubic (right) phases of 3D halide perovskite. Reproduced with permission from ref 21. Copyright 2016 Wiley-VCH. (c) Delta phases of FAPbI3 perovskites, created using crystallographic data from ref 22. (d) Delta phases of CsPbI3 perovskites. Reproduced with permission from ref 23. Copyright 2018 Springer Nature. (e) Tolerance factor tuning with Cs-FA alloys. Reproduced with permission from ref 10. Copyright 2015 American Chemical Society. 

However, for ion combinations at the edge of the acceptable range at room temperature (e.g., CsPbI3), the perovskite phase can form at higher temperatures and persist as a metastable phase when cooled.<sup>8,11</sup> The octahedral factor _μ_ = _r_ B/ _r_ X > 0.41 is another geometric factor which predicts the stability of the B-X octahedra in the perovskite structure.<sup>11</sup> For _μ_ = 0.41 hard spheres of X coordinating the same B-site would touch each other without overlapping, and for _μ_ < 0.41 they begin to overlap. Table 1 lists tolerance factors for possible combinations of common A-, B-, and X-site ions and comments on which have been synthesized with a perovskite structure. 

The most well-studied halide perovskite is MAPbI3 (MA = methylammonium). With _t_ ∼ 0.912, MAPbI3 is very close to an ideal perovskite, forming a tetragonal phase at room temperature.<sup>12,13</sup> The MA cation has the most suitable effective radius of any organic or inorganic monovalent cation for a phase-stable lead iodide perovskite, but chemical stability issues associated with MA have motivated the use of less suitably sized but more chemically stable cations for halide perovskites such as FAPbI3 (FA = formamidinium, _t_ ∼ 0.987) and CsPbI3 ( _t_ ∼ 0.851). At room temperature the stable form of FAPbI3 is a hexagonal nonperovskite structure (the _δ_ -phase).<sup>8</sup> The PbI6 octahedra still form but join into a 1D face-sharing network with a Pb−I−Pb bond angle below 100°, and as a result the phase is not optically active (Figure 1c). The cubic perovskite phase of FAPbI3 becomes stable for _T_ ∼ 150 °C. CsPbI3 also adopts a nonperovskite _δ_ -phase at room temperature, with the PbI6 octahedra forming a 1D edge-sharing network (Figure 1d).<sup>14</sup> Heated past 360 °C, CsPbI3 converts into the cubic _α_ -phase; upon cooling from 360 °C, it moves through two additional perovskite phases: first from the _α_ -phase to the tetragonal _β_ - phase (260 °C) and then from the _β_ -phase to the orthorhombic _γ_ -phase (175 °C).<sup>15</sup> The substitution of iodine atoms with bromine atoms leads to an increase in the tolerance factors, which would be expected to stabilize CsPbBr3 and destabilize 

Table 1. Reported ABX3 Perovskites 

|A|B|X|_t_<sup>12,24</sup>|Reported/Not<br>Reported|Ref|
|---|---|---|---|---|---|
|MA<br>|Pb<br>|F (128.5 pm)|0.987|Not reported|25|
|(217 pm)|(119 pm)|Cl (181 pm)|0.938|Reported|25<br>|
|||Br (196 pm)|0.927|Reported|13,26|
|||I (220 pm)|0.912|Reported|8,13|
||Sn<br>|F|1.003|Not reported||
||(115 pm)|Cl|0.951|Reported|27,28|
|||Br|0.939|Reported|28|
|||I|0.922|Reported|8,28|
|FA<br>|Pb|F|1.09|Not reported||
|(253 pm)||Cl|1.023|Reported|29|
|||Br|1.008|Reported|26|
|||I|0.987|Reported|8,30|
||Sn|F|1.108|Not reported||
|||Cl|1.037|Not reported|31,32|
|||Br|1.021|Reported|33|
|||I|0.998|Reported|8,34|
|Cs<br>|Pb|F|0.904|Reported|35|
|(188 pm)||Cl|0.87|Reported|36|
|||Br|0.862|Reported|26,37|
|||I|0.851|Reported|38|
||Sn|F|0.919|Not reported|39|
|||Cl|0.881|Reported|27,40|
|||Br|0.873|Reported|41|
|||I|0.861|Reported|42|



FAPbBr3. However, neither FAPbBr316 nor CsPbBr314 exhibits the structural instabilities from high-temperature cubic phases toward nonperovskite yellow phases of their iodides. The increased tolerance factor also causes MAPbBr3 to adopt an undistorted cubic phase at room temperature.<sup>13</sup> 

In order to realize a chemically stable perovskite phase at room temperature, the A-site is often an alloy of FA-Cs<sup>10</sup> or FAMA-Cs<sup>17</sup> to give an effective cation radius for a near-ideal tolerance factor (Figure 1e). While the B-site<sup>18</sup> and X-site<sup>19</sup> can also be alloyed, this changes the bandgap of the halide perovskite; the A-site, decoupled from the crystal’s electronic structure, can be alloyed without significantly altering its semiconductor properties. Triple-cation A-site mixtures including FA0.8MA0.15Cs0.05 have become the state-of-the-art for 3D halide perovskite photovoltaics. 

### **2.2. From 3D to 2D: Reduced Dimensionality while Maintaining Corner-Sharing Octahedra** 

Assigning an “effective radius” to molecular A-site cations is a simplification which neglects the cation’s shape and charge distribution. For specific classes of high-aspect-ratio A-site cations, quasi-perovskite structures can be stabilized, which show reduced dimensionality but maintain the 3D structure’s corner-sharing PbI6 octahedra and therefore remain photoactive. Linear ammonium or diammonium “spacer” cations can sit in what used to be the cuboctahedral A-site cage, breaking it in half and separating the PbI6 octahedral network into disconnected layers. 

The ⟨100⟩, ⟨110⟩, and ⟨111⟩ layered halide perovskite series along with a few more atypical halide perovskite networks are known.<sup>43</sup> The ⟨100⟩ layered halide perovskites are the most extensively studied.<sup>44−46</sup> The dimensionality of their electronic structure is considered to be equal to 2, sharing strong similarities with strongly confined classical semiconductor quantum wells and other 2D materials (vide infra). 

**9568** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

Among ⟨100⟩ layered halide perovskites, monolayered Ruddlesden−Popper (RP) 2D halide perovskites were the first to be synthesized and studied in detail.<sup>47−49</sup> They have the stoichiometry A′<sup>+</sup> 2<sup>B2+X−</sup> 4<sup>, with A′ a linear spacer monocation.</sup> RP A′ cations have an ammonium group which sits within the half-cuboctahedral site and a long, typically nonpolar group which extends perpendicular to the Pb−I plane (e.g., butylammonium, BA<sup>+</sup> ). This breaks the lattice into strongly ionic monolayers of corner-sharing PbI6 octahedra (inorganic layer) separated by two linear A′ cations (organic layer) in a region presenting a smaller dielectric constant. The A′ cations of neighboring layers face each other, holding the layers together via van der Waals interactions between their nonpolar groups. A reference RP crystallographic structure can be defined for which adjacent layers exactly present a (1/2, 1/2) unit-cell offset in the 2D plane, although actual structures may exhibit slight deviations from this ideal offset<sup>50</sup> (Figure 2a). 



Figure 2. Structures of 2D perovskites. (a−c) Three types of 2D halide perovskite, which are (a) Ruddlesden−Popper (RP), (b) Dion Jacobson (DJ), and (c) alternating cation (ACI), _n_ = 1. (d) RP structures for different perovskite thicknesses ( _n_ = 1, 2, 3), which correspond to the number of octahedra along the stacking direction in the perovskite layers (ranging from _n_ = 1 2D halide perovskite to 3D halide perovskite ( _n_ →∞)). (a−d) Reproduced with permission from ref 50. Copyright 2020 Springer Nature. (e) Schematic illustration of the lattice mismatch concept. 2D halide perovskite of _n_ larger than 2 is regarded as L1/L2 with L1 the 3D ( _n_ = ∞) bulk material, e.g., MAPbI3, and L2, a _n_ = 1 compound, e.g., (BA)2PbI4. Reproduced with permission from ref 67. Copyright 2018 American Chemical Society. (f) Structure of (BA)2(DMA)Pb2I7, where DMA is a large A-cite cation (geometric Goldschmidt tolerance factor is relaxed). Reproduced with permission from ref 68. Copyright 2020 American Chemical Society. 

Dion−Jacobson (DJ) 2D halide perovskites, which were discovered more recently,<sup>51</sup> have the stoichiometry A′<sup>2+</sup> B<sup>2+</sup> X<sup>−</sup> 4<sup>,</sup> with A′ a linear dication terminated on either end by ammonium groups (e.g., 1,4-butanediammonium, BDA<sup>2+</sup> ). The DJ structure is similar to RP except that the organic layer is composed of one A′ cation with an ammonium group sitting in the A-site of both inorganic layers it connects. As a result the DJ structure has little 

unit-cell offset between layers, and a reference DJ crystallographic structure with no offset can be defined.<sup>50</sup> DJ halide perovskites generally have stronger interlayer bonding than RP halide perovskites. They tend to show a larger (near 180°) axial (out-of-plane) Pb−I−Pb bond angle and a smaller (155°− 165°) equatorial (in-plane) Pb−I−Pb bond angle compared to RP halide perovskites, which have more consistent bond angles between 165° and 172°, although the distortion varies for both phases depending on the chemistry (Figure 2b).<sup>47,51</sup> 

A third class of 2D halide perovskite, alternating cation (ACI), has stoichiometry A′<sup>+</sup> A<sup>+</sup> B<sup>2+</sup> X<sup>−</sup> 4<sup>,whereAisa3Dhalide</sup> perovskite A cation and A′ is a larger cation.<sup>52</sup> The A′ cation in the ACI structure lacks the high aspect ratio of RP and DJ A′ cations and is usually only slightly too large to fit in the 3D cuboctahedral site (e.g., guanidinium). The structure is once again broken into planar sheets, this time separated by alternating rows of A cations and A′ cations. The ideal ACI structure has a (1/2, 0) unit-cell offset in the 2D plane between layers.<sup>50</sup> ACI halide perovskites show Pb−I−Pb bond angles which are large (near 180°) in one in-plane direction and small (near 160°) in the other, with intermediate (165°−167°) axial bond angles (Figure 2c).<sup>52</sup> 

There should be a size requirement for an organic spacer to form a 2D halide perovskite, albeit undetermined in some cases. For linear RP monoammonium cations, the longest chain reported is octadecyl ammonium (18 carbons)<sup>53</sup> and the smallest is methylhydrazinium.<sup>54</sup> For cyclic cations, the diameter of the ring has to be smaller than the BX6 octahedron (6.3 Å) to be fit into the 2D structure. Generally, a ring size of three to six carbons is required to form 2D halide perovskite, while larger rings facilitate the formation of 1D halide perovskite.<sup>55,56</sup> Each of the three types of ⟨100⟩ 2D perovskites has different size requirements as determined by the material’s structure. In the case of ACI-type 2D perovskites, the A′-site must be smaller and has less room for structural variability than in either RP or DJ phases. 

For interested readers, _The 2D Halide Perovskite Rulebook_ by Li et al. provides an excellent comprehensive review of reported 2D halide perovskites.<sup>57</sup> 

### **2.3. From 2D to Quasi-2D: Introducing** **_n_ -Value** 

2D halide perovskites with an inorganic layer a single sheet of PbI6 octahedra thick, like those discussed above, are said to have an _n_ -value of 1. The inorganic layer thickness can be increased if 3D A-site cations are incorporated to fill the new unbroken cuboctahedral sites between eight neighboring octahedra. This broadens the RP, DJ, and ACI material classes to include “quasi2D” structures of the form A′<sup>+</sup> 2<sup>A+</sup> _n_ −1<sup>B2+</sup> _n_<sup>X−</sup> 3 _n_ +1<sup>(RP),58−60</sup> A′<sup>2+</sup> A<sup>+</sup> _n_ −1<sup>B2+</sup> _n_<sup>X−</sup> 3 _n_ +1<sup>(DJ),51andA′+A+</sup> _n_<sup>B2+</sup> _n_<sup>X−</sup> 3 _n_ +1<sup>(ACI),52</sup> where _n_ corresponds structurally to the number of octahedra of the inorganic layer in the out-of-plane direction. From an electronic viewpoint, the _n_ -value is directly connected to the structure’s quantum well thickness. The 3D halide perovskite structure can be conceptualized as the limit of this quasi-2D structure out to _n_ = ∞, and _n_ -values between 1 and ∞ are expected to provide a tuning of the material properties between those of an _n_ 1 2D and a pure 3D halide perovskite (Figure 2d). 

In reality, pure quasi-2D halide perovskites with arbitrary _n_ - value out to _n_ = ∞ cannot be physically realized. Usually, above a threshold _n_ -value that varies depending on the structure and chemistry but can be as low as _n_ = 1 and is practically limited to _n_ = 6−7, the system will form a mixture of 3D and lower- _n_ 2D phases instead of a higher single _n_ -value. Table 2 lists A′-site 

**9569** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

Table 2. Highest Reported _n_ -Values for 2D Halide Perovskites That Form with _n_ > 2<sup>_a_</sup> 

|Phase|A′|A|B|X|Max_n_|Ref|
|---|---|---|---|---|---|---|
|RP|Ethylammonium (EA<sup>+</sup>)|MA|Pb|Br|3|69|
|||EA|Pb|Br|3|70<br>|
|||||Cl|3|70,71<br>|
||Propylammonium|MA|Pb|I|4|72|
||Butylammonium|MA|Pb|I|7|66|
|||||Br|3|73|
||||Sn|I|3|74|
|||||Br|3|73,75|
|||EA|Pb|I|3|76,77|
|||Cs|Pb|Br|3|78<br>|
||Pentylammonium|MA|Pb|I|6|79|
||Hexylammonium|MA|Pb|I|4|80,81<br>|
||Allylammonium|MA|Pb|I|3|82|
|||EA|Pb|Br|3|83<br>|
||Phenylmethylammonium|MA|Pb|I|3|61|
||Phenylethylammonium|MA|Pb|I|3|49<br>|
||Benzylammonium|MA|Pb|I|3|61|
||3-Phenyl-2-propenammonium|MA0.5FA0.5|Pb|I|3|84<br>|
||Isoamylammonium|MA|Pb|Cl|3|85|
||Isoamylammonium|EA|Pb|Br|3|86<br>|
||4-Bromobutylammonium|EA|Pb|Br|3|87|
||4-Iodobutylammonium|MA|Pb|I|3|88|
||2-Iodopropylammonium|MA|Pb|I|3|82|
||4-Fluorophenylethylammonium|MA|Pb|I|3|89<br>|
||2-Thiophenemethylammonium|MA|Pb|I|3|90|
||4-Aminomethyl-1-cyclohexanecarboxylate|EA|Pb|Br|3|91<br>|
|DJ|1,4-Butanediammonium|MA|Pb|I|3|92|
|||FA|Sn|I|3|93|
||1,6-Hexanediammonium|MA|Pb|I|3|92|
||1,7-Heptanediammonium|MA|Pb|I|3|92|
||1,8-Octanediammonium|MA|Pb|I|4|92|
||1,9-Nonanediammonium|MA|Pb|I|4|92|
||3-(Aminomethyl)piperidinium|MA|Pb|I|4|51|
||4-(Aminomethyl)piperidinium|MA|Pb|I|7|94|
||3-(Aminomethyl)pyridinium|MA|Pb|I|4|95|
||4-(Aminomethyl)pyridinium|MA|Pb|I|4|95|
||_m_-Phenylenediammonium|MA|Pb|I|3|96|
|ACI|Guanidinium|MA|Pb|I|3|52|
||Protonated thiourea|MA|Pb|I|3|97|



_a_ Only phases with published crystallographic data are collected. 

cations which can form 2D halide perovskites with _n_ > 2, for which crystallographic data has been reported from singlecrystal diffraction. We note that this is not a comprehensive list of known 2D halide perovskites with _n_ > 2, as there have been several other reports of novel high- _n_ 2D halide perovskites that did not include crystallographic data.<sup>61−64</sup> An effective average ⟨ _n_ ⟩ value is sometimes defined for mixed- _n_ -value systems, although this terminology can be misleading given the differences in material properties between a pure single- _n_ - value system and an effective ⟨ _n_ ⟩ value system. It has been shown experimentally that for pure systems with _n_ up to 5, the halide perovskite electronic properties are still characteristic of 2D materials, which justifies the use of the quasi-2D terminology for pure systems. For mixed systems where ⟨ _n_ ⟩ reaches much higher values, the effective electronic dimensionality can be questioned. There are two factors determining the highest _n_ ( _n_ max) of pure quasi-2D halide perovskites: thermodynamics and strain energy accumulation resulting from internal lattice mismatch.<sup>65</sup> 

From a thermodynamics perspective, generally the enthalpy of formation (Δ _H_ ) is used to determine whether a pure quasi2D material such as BA2MA _n_ −1Pb _n_ I3 _n_ +1 (BA = butylammonium) is favorable or not with respect to a mixture of classical binary precursors such as MAI, BAI, and PbI2 in solution-based synthesis (calculated using enthalpy of solvation).<sup>66</sup> The assumption that the entropy of formation (Δ _S_ ) in the system is never positive is based on the highly ordered quantum well structure of the quasi-2D halide perovskite. Therefore, as Δ _G_ = Δ _H_ − _T_ Δ _S_ , to obtain the negative Δ _G_ , Δ _H_ has to be negative. For example, for BA MA 2D halide perovskites, Δ _H_ is negative for _n_ = 1 to _n_ = 5 and becomes positive for _n_ = 6 and _n_ = 7.<sup>66</sup> These compositions were also found to be unstable with respect to the decomposition into the 3D halide perovskite MAPbI3, and the BAI and PbI2 precursors. As a result, the highest _n_ of BA MA 2D halide perovskites for a stable pure phase is _n_ = 5. However, the structural parameters for _n_ = 6 and _n_ = 7 were indeed successfully obtained from the analyses of diffraction patterns at 

**9570** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 3. Bandgap of 3D perovskites. (a) CsPbI3 partial density of states for Cs, Pb, and I atoms. (b) CsPbI3 crystal orbital Hamiltonian population analysis showing bonding (positive) and antibonding (negative) character. (c) Schematic energy level diagram for CsPbI3. (d) Influence of X-site on the energy level diagram for the CsPbX3 series. (e) Influence of B-site on the energy level diagram for the CsBI3 series. (f) Influence of A-site on the energy level diagram for the ASnCl3 series, showing nonintuitive bandgap increase with cation size. This increase is a result of lattice expansion with larger tolerance factor in MASnCl3 and FASnCl3. The VBM is more affected than the CBM because of its greater B-X hybridization. (a−f) Reproduced with permission from ref 32. Copyright 2019 Springer Nature. (g) Effect of Cs incorporation on the bandgaps of (FA1− _x_ Cs _x_ )PbI3 and (FA1− _x_ Cs _x_ )SnI3. Bandgap decreases with Cs for (FA1− _x_ Cs _x_ )SnI3 as lattice contracts and increases with Cs for (FA1− _x_ Cs _x_ )PbI3 as octahedra distort. (h) Effect of Sn incorporation on the bandgaps of (FA1− _y_ Cs _y_ )(Pb1− _x_ Sn _x_ )I3 showing nonmonotonic _x_ -dependence. Bowing effect decreases with _y_ as (FA1− _y_ Cs _y_ )SnI3 tolerance factor is reduced. (g−h) Reproduced with permission from ref 108. Copyright 2017 American Chemical Society. (i) Effect of Br incorporation on the bandgap of MAPb(I1− _x_ Br _x_ )3 showing monotonic increase with _x_ . Reproduced with permission from ref 19. Copyright 2013 American Chemical Society. 

the price of ignoring small contributions coming from minor phases.<sup>66</sup> 

A complementary approach consists in trying to understand the origin of the internal energy accumulated in a quasi-2D lattice such as BA2MA _n_ −1Pb _n_ I3 _n_ +1 from a mechanical perspective. For that purpose a quasi-2D system is envisioned as a composite formed by alternating _n_ = 1 and bulk-like 3D layers, assembled through coherent interfaces<sup>67</sup> (Figure 2e). This concept is central for the analysis of the formation of heterostructures between different materials in the field of classical semiconductors. An _n_ = 1 bulk 2D halide perovskite with an inplane lattice parameter very different from the one of a targeted 3D bulk halide perovskite will most likely not form coherent 

interfaces in quasi-2D compounds, because the internal strain energy scales roughly as the square of the lattice mismatch between the two bulk materials. As an example, BA2PbI4 and MAPbI3 have an in-plane lattice mismatch on the order of 1%, which is usually considered in the field of classical semiconductors as an upper limit for the formation of heterostructures. However, the accumulation of strain energy in BA2MA _n_ −1Pb _n_ I3 _n_ +1 is reduced by the flexibility of the BA cation.<sup>67</sup> Phenethylammonium (PEA) offers a counterexample, with (PEA)2(MA) _n_ −1Pb _n_ I3 _n_ +1 having an in-plane lattice parameter very close to that of (BA)2(MA) _n_ −1Pb _n_ I3 _n_ +1 but a maximum _n_ -value of only 3 due to a lack of flexibility compared to BA (Table 2) (BA is a linear alkane, while PEA is an aromatic 

**9571** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

Table 3. Reported Bandgaps of Common Halide Perovskites<sup>_a_</sup> 

|A|B|X|Bandgap|Ref|Bandgap|Ref|Bandgap|Ref|
|---|---|---|---|---|---|---|---|---|
|MA|Pb|Cl|3.06|115|||||
|||Br|2.25|115|||||
|||Br0.5I0.5|1.8|19|||||
|||I|1.61|115|1.55|18|||
||Pb0.5Sn0.5|I|1.17|18|||||
||Sn|Cl|3.46|116|3.61|117|3.69|118|
|||Br|2.15|118|2.25|119|||
|||I|1.3|18|1.3|112|1.15|120|
|FA|Pb|Br|2.15|30|2.13|121|||
|||Br0.5I0.5|1.62|122|||||
|||I|1.41|30|1.45|110|1.48|111|
||Pb0.5Sn0.5|I|1.28|123|||||
||Sn|I|1.41|124|1.4|120|||
|Cs|Pb|Cl|3|125|2.85|126|2.86|127|
|||Br|2.4|125|2.23|126|2.24|127|
|||I|1.67|8|1.73|109|||
||Sn|Cl|2.97|128|2.98|129|2.9|130|
|||Br|1.92|119|||||
|||I|1.3|42|1.3|8|||
|FA0.85Cs0.15|Pb|I|1.52|10|||||
|FA0.79MA0.16Cs0.05|Pb|I0.83Br0.17|1.6|17|||||
|FA0.7MA0.3|Pb0.5Sn0.5|I|1.26|131|||||
|FA0.85MA0.15|Pb|I0.85Br0.15|1.55|132|||||



_a_ Multiple values are given where reports conflict. 

molecule). The relaxation of interface strain accumulated by lattice mismatch in a quasi-2D lattice also takes advantage of a specific feature of halide perovskite semiconductors. Strain relaxation only occurs in classical semiconductors through bond stretching or compression, but the energy cost is lowered in halide perovskites by the tilting of the surface octahedra (octahedra that are bonded with the A′ cations) and the elongation of the octahedron cage. Since the A′ cations move together with the surface octahedra, the structure flexibility of organic cations will determine the extent of the relaxation. On the other hand, the stress is also a function of the size of the A- site cation, as more stress will be built up as the size of the A-site cation increases. 

The organic cations in 2D halide perovskites can relax the Goldschmidt tolerance factor, enabling larger A-site cation incorporation into the PbI6 cage. For example, guanidinium (GA<sup>+</sup> ) and dimethylammonium (DMA<sup>+</sup> ) (Figure 2f) were too large to be incorporated into the PbI6 cage in 3D lead-iodide halide perovskites but could be fit into the cage in RP 2D halide perovskites with a BA spacer cation.<sup>68</sup> 

### **3. OPTOELECTRONIC PROPERTIES OF 3D AND 2D HALIDE PEROVSKITES** 

### **3.1. Semiconductor Properties of 3D Halide Perovskites** 

**3.1.1. From Structure to Optoelectronic Properties: The Physical Basis for 3D Halide Perovskites’ Bandgap.** Many of the remarkable optoelectronic properties of ABX3 halide perovskites which are not present in other halides are derived from the electronic configuration of the B-site cations and the corner-sharing BX6 sublattice of the crystal structure.<sup>98,32,99,100</sup> The B-site of a halide perovskite is conventionally a 2+ cation with an ns<sup>2</sup> configuration. In the case of the Pb<sup>2+</sup> 

cation, the electronic configuration is [Xe] 6s<sup>2</sup> 4f<sup>14</sup> 5d,<sup>10</sup> with the 6s states fully occupied and sitting below the halogen’s filled p-orbital. As a result, the valence band maximum (VBM, highestenergy occupied electron state below the bandgap) of APbI3 is formed from the antibonding molecular orbitals of the Pb 6s − I 5p states, whereas in most common semiconductor materials the VBM would be composed of bonding molecular orbitals (Figure 3a−c).<sup>32</sup> This antibonding character of the VBM contributes significantly to halide perovskites’ defect tolerance, which will be expanded upon later.<sup>101,102</sup> The conduction band minimum (CBM, lowest-energy unoccupied electron state above the bandgap) of a halide perovskite is an antibonding molecular orbital of the B-site p-states and X-site s-states and is comprised mainly of the np atomic orbitals of the B-site. Group theory analysis reveals that the space group symmetry of the crystal prevents B-site and X-site p-state hybridization at the R-point where the VBM and CBM sit, which reduces the X-site character of the CBM.<sup>100</sup> As a result the VBM is more strongly influenced than the CBM by lattice distortions which change bond angles and distances.<sup>32</sup> 

The X-site p-orbitals contributing to the VBM are directional, with two lobes of electron density pointing in opposite directions. By a stroke of good luck, the B-X sublattice of a cubic halide perovskite crystal happens to be a 3D network of corner-sharing BX6 octahedra with X-sites at the corners and B- sites at the centers, such that each X-site’s occupied p-orbital points directly toward both B-sites the anion is coordinated with. The valence band therefore has an exceptional degree of orbital overlap and the electronic structure takes on a delocalized character.<sup>98,103</sup> Extended electronic states dominate over localized states, and the electronic dispersions display a direct bandgap with an allowed optical transition between twice degenerated conduction and valence bands with low and similar 

**9572** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 4. Defect tolerance and nonradiative recombination in 3D perovskites. (a) Schematic of point defects found in ABX3 perovskites. Defects with low formation energies tend to be shallow, whereas deep-level defects usually have high formation energies. (b) Schematic energy level diagram showing how the antibonding VBM and the CBM with majority Pb character allow most MAPbI3 defect levels to fall outside of the bandgap, in contrast to inorganic semiconductors. (a−b) Reproduced with permission from ref 151. Copyright 2018 Springer Nature. (c) Schematic permittivity spectrum of a perovskite showing the contributions of lattice dynamics and ion migration. Reproduced with permission from ref 144. Copyright 2019 American Institute of Physics. (d) Best-reported _V_ OC values for a variety of solar cell absorbers, plotted against absorber bandgap. The solid line shows the bandgap voltage, and the dashed line shows the maximum _V_ OC allowed by the Shockley−Queisser limit. Reproduced with permission from ref 143. Copyright 2019 Springer Nature. (e) Polar plots of MAPbI3 second harmonic generation rotational anisotropy experiments for parallel (P) or perpendicular (S) incident (in) and outgoing (out) light. Data fits excellently with theory for the surface _mm_ 2 point group of a centrosymmetric _I_ 4/ _mcm_ space group crystal, rather than the 4 _mm_ point group of a noncentrosymmetric _I_ 4 _cm_ crystal. Reproduced with permission from ref 149. Copyright 2018 Springer Nature. 

effective masses. In other words, it is an almost ideal situation for optoelectronic applications not even encountered in a III−V semiconductor such as GaAs.<sup>104</sup> Moreover, contrary to the initial expectations, it was shown that the binding energy of the exciton is small, leading to easy ionization at temperatures for device operations,<sup>105,106</sup> and the crystal thus demonstrates freecarrier rather than excitonic charge behavior with low effective masses. The ultimate limitations of the carrier mobilities, by comparison to classical semiconductors such as GaAs or Si, come not from unfavorable electronic band structures but from the softness of the lattice and the low-energy vibrational density of states which promotes charge carrier scattering.<sup>107</sup> 

Lower-symmetry (tetragonal and orthorhombic) halide perovskite phases relax strain by distorting the network of BX6 

octahedra. The octahedral sublattice distorts by reducing the B− X−B bond angle from the maximum value of 180° (cubic), which reduces the p-orbital overlap, reduces the covalency, and widens the bandgap.<sup>108,109</sup> For A-sites too large or too small for the octahedral sublattice to accommodate them, the structure breaks into a lower-dimensional network of edge- (e.g., CsPbI3 _δ_ -phase) or face- (e.g., FAPbI3 _δ_ -phase) sharing BX6 octahedra, for which the network of overlapping p-orbitals is lost. In these structures the delocalized character disappears, the bandgap widens, and the lattice no longer accommodates free-carrier charge transport. While A-site orbitals do not meaningfully contribute to the band structure, sitting far below the VBM, the A-site still is a crucial contributor to the optoelectronic 

**9573** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

properties of 3D halide perovskites by stabilizing the cornersharing BX6 sublattice. 

Depending on the Pb−I−Pb bond angle, APbI3 halide perovskites vary in bandgap from 1.45−1.48 eV (cubic FAPbI3) to 1.67−1.73 eV (orthorhombic CsPbI3).<sup>8,109−111</sup> A 1.45 eV bandgap is just slightly larger than the ideal bandgap for a solar cell according to the Shockley−Queisser limit, which is why most of the highest-performing 3D halide perovskite solar cells use a FAPbI3 or majority-FAPbI3 absorber. In the general ABX3 structure, increasing A-site radius can either decrease bandgap due to reduced octahedral distortions or increase bandgap due to lattice expansion (Figure 3f). Replacing Pb with Sn directly impacts the atomic orbitals comprising the VBM and CBM and lowers the bandgap, from 1.52 eV for MAPbI3 to 1.30 eV for MASnI38,112 (Figure 3e). Replacing I with Br likewise influences the atomic orbital comprising the VBM and widens the bandgap to 2.34 eV<sup>113</sup> (Figure 3d). Alloys of I/Br at the X-site can yield bandgaps intermediate between those of MAPbI3 and MABrI3 with a near-linear concentration dependence<sup>19</sup> (Figure 3i); however, Pb/Sn alloys at the B-site show a nonlinear, nonmonotonic concentration dependence (Figure 3h), with MASn0.5Pb0.5I3 having a bandgap below 1.2 eV.<sup>18</sup> This bowing behavior is common for APb _x_ Sn1− _x_ X3 halide perovskites and appears to emerge from the competing influences of expansive lattice strain (bandgap-widening) and increasing Pb−I−Pb angle (bandgap-narrowing) as tolerance factor increases,<sup>108,114</sup> which also explains why the bandgaps of (FA1− _x_ Cs _x_ )PbI3 and (FA1− _x_ Cs _x_ )SnI3 show respectively positive and negative _x_ - dependence (Figure 3g).<sup>108</sup> The bandgaps of selected halide perovskites are shown in Table 3. 

Bandgap tunability through the alloying of A-, B-, and X-sites unlocks new applications for perovskite absorbers. In the case of solar cells, lead iodide-based perovskites which incorporate Br or Sn can serve as wide-bandgap or narrow-bandgap layers in tandem solar cells, respectively, with bandgaps tuned to maximize the power conversion efficiency (PCE) of the full device. 

**3.1.2. Origin of Defect Tolerance in 3D Halide Perovskites.** Halide perovskites appear to have high tolerance to point defects. This is unusual for halides which tend to exhibit high defect concentrations. High defect tolerance in a semiconductor has three possible explanations: a low defect density (either because of high defect formation energy or lattice self-healing), defect states being shallow or resonant with band states, and defect states with low capture cross sections.<sup>133</sup> All these properties seem to coexist in halide perovskites to an extent.<sup>133−138</sup> Single crystals of halide perovskites have been reported with defect densities <10<sup>12</sup> cm<sup>−3</sup> ,<sup>139</sup> which is impressive even for inorganic semiconductors;<sup>140</sup> films of halide perovskites appear to have several orders of magnitude higher defect densities, although the reliable measurement of defects in films is difficult.<sup>139</sup> Direct measurement of defect concentration or defect behavior is difficult not only for halide perovskites but also for semiconductors in general, with experimental methods open to misinterpretation.<sup>135</sup> As such it has been difficult to disentangle the relative contributions of these three explanations for defect tolerance or to quantify the relationship between defect density and performance in halide perovskites. 

The defect tolerance of halide perovskites is at least in part derived from the antibonding character of the VBM, a result of the ns<sup>2</sup> electronic configuration of the B-site cation.<sup>98,135</sup> With a VBM above the constituent atomic orbitals of both the X- and B- site ions, any defect states which would be expected to fall near 

or between these atomic orbitals (e.g., B-site vacancies) would be near or below the VBM, whereas with a VBM comprised of bonding states and a CBM of antibonding states the same defect levels may sit in the middle of the bandgap (Figure 4b). This design principle further suggests that a CBM composed of bonding states would grant additional defect tolerance.<sup>102,141</sup> Fortunately, the large energy difference between the Pb 6p and I 5p orbitals gives MAPbI3’s antibonding CBM almost entirely Pb 6p character and keeps it from being pushed up in energy such that donor defects become trap states.<sup>98</sup> 

The ABX3 halide perovskite structure has 12 possible intrinsic point defects: A-, B-, and X-site vacancies, A, B, and X interstitials, and the six possible substitutions between these three ions. In the case of MAPbI3, defects with low formation energy include Ii, MAPb, VMA, VPb, MAi, PbMA, and VI. It appears that these defects all form states at most 50 meV into the bandgap, close to either the VBM or CBM.<sup>142</sup> Defect states with deeper levels such as IMA, IPb, PbI, and Pbi seem to have higher formation energy and low population in MAPbI3 films at room temperature<sup>134,142,143</sup> (Figure 4a). 

The halogen vacancy is of particular interest, being a common deep-level defect (F-center) in ionic halide crystals and even in some other ns<sup>2</sup> halides. The strength of the interaction between the two B cations which bond to the vacancy site determines the position of the defect level. In the case of MAPbI3, the size of the A-site, along with Coulomb repulsion, gives a large Pb−Pb distance which minimizes this interaction. The corner-sharing octahedral network in which only two B cations coordinate each X-site also reduces the hybridization of cation p-orbitals at the vacancy.<sup>98</sup> 

The recognition that ns<sup>2</sup> cations are responsible for halide perovskite defect tolerance can help guide the search for future optoelectronic materials. Pb<sup>2+</sup> , Sn<sup>2+</sup> , Ge<sup>2+</sup> , Sb<sup>3+</sup> , and Te<sup>4+</sup> all adopt the ns<sup>2</sup> configuration and may be promising candidates for semiconductors, although the ns<sup>2</sup> orbital must be close enough in energy to the anion p-orbital to push the antibonding VBM above the level of cation vacancy states.<sup>102</sup> 

Besides their shallow defect levels, halide perovskites are granted additional defect tolerance thanks to screening of electrostatic potentials by their high static dielectric constant of ∼22, as well as by dynamical lattice screening through various ionic displacement or reorientation processes occurring across a wide frequency range, as is apparent in halide perovskites’ complex dielectric permittivity spectra (Figure 4c).<sup>144</sup> Dynamic lattice effects will be discussed further below. 

Related to the dynamic processes which contribute to dielectric screening, halide perovskite crystals also exhibit dynamic self-healing through ion migration and the reforming of localized degradation products. Self-healing after humidity- or light-induced degradation will be discussed further in the context of halide perovskite stability below. In the context of defect tolerance, the possibility of dynamic defect formation and annihilation either through diffusion or through lattice reformation creates an upper limit to the possible defect concentration in the crystal bulk and limits the effect such defects can have on charges. As proposed by Rakita et al.<sup>145</sup> halide perovskites’ low activation energy for ion hopping, discussed further below, allows for the diffusion of defects to surfaces on the time scale of seconds to hours. Further, dynamic lattice restructuring in halide perovskites can create and destroy local defects on time scales short enough that charges do not experience such defects as different from the lattice itself, which also allows for the screening of extrinsic or nondynamic trap 

**9574** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 5. Carrier transport in 3D perovskites. (a) Left: Magnetic field-dependence of low-temperature MAPbI3 energy transitions, including freecarrier transitions (blue solid lines) from long-pulse fixed-field measurements (black circles) and exciton transitions (black dashed lines) from fixedenergy fast-field-sweep measurements. An exciton binding energy of 16 meV is calculated. Right: Schematic of free-carrier levels (solid lines) and excitonic levels (dashed lines), showing transitions. Reproduced with permission from ref 106. Copyright 2015 Springer Nature. (b) Calculated hole (left) and electron (right) spin density for neutral (top) and charged (bottom) CsPbI3 cluster showing charge localization through lattice distortion. Reproduced with permission from ref 165. Copyright 2016 American Chemical Society. (c) Various measurements of temperature-dependent mobility for perovskites showing a _T_<sup>−</sup><sup>_γ_</sup> dependence for 1.5 < _γ_ < 3 near room temperature. Top left: Time-of-flight measurements of MAPbI3 single crystals. Reproduced with permission from ref 166. Copyright 2018 American Chemical Society. Top right: Hall measurements of MAPbBr3 single crystals. Reproduced with permission from ref 167. Copyright 2016 Wiley-VCH. Bottom left: Optical measurements of MAPbI3 thin films. Reproduced with permission from ref 168. Copyright 2019 American Chemical Society. Inset in green shows results of dynamic distortion model for MAPbI3 predicting _γ_ ∼ 2.1. Reproduced with permission from ref 169. Frohlich large polaron models predicẗ _γ_ ∼ 0.5−1. Copyright 2018 American Chemical Society. (c) Adapted with permission from ref 156. Copyright 2021 American Chemical Society. (d) Schematic of temperature dependence of recombination as explained by dynamic disorder model. Reproduced with permission from ref 170. Copyright 2018 Elsevier. 

states by dynamic defects. Rakita et al. identify two key properties which a semiconductor should possess to exhibit such self-healing: a low formation energy with high entropic stabilization which allows for the local dynamical breaking and reforming of the lattice, and a low activation energy for ion diffusion which allows for defect migration to surfaces within seconds. As will be discussed later, this dynamic lattice limits the degree to which halide perovskites can be doped, which explains 

why halide perovskites are almost always used as intrinsic semiconductors within devices. 

Defect tolerance in halide perovskites also extends to A-, B-, and X-site alloying. Intuitively, a mixed-ion perovskite should show worse carrier mobility and higher nonradiative recombination than a pure system because of the introduction of local lattice strain. However, both mixed-cation and mixed-anion perovskites have in fact shown suppressed nonradiative recombination and enhanced charge transport compared to 

**9575** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

Table 4. Exciton Effective Mass and Binding Energy for 3D Halide Perovskites 

|Year||Compound|Binding energy (meV)|Effective mass|f  (m0)<br>Approach|Ref|
|---|---|---|---|---|---|---|
|2015|MAPbI3||16|0.104|High-field magneto optical absorption spectroscopy|106|
||FAPbI3(|tetragonal phase)|10|0.095|||
||MAPbI3−|_x_Cl_x_(tetragonal phase)|10|0.105|||
|2016|MAPbI3|(tetragonal phase)|12|0.104|Magneto optical spectroscopy|264|
||FAPbBr3|(tetragonal phase)|24|0.13|||



their pure counterparts.<sup>105,146,147</sup> The dynamic lattices of halide perovskites afford tolerance toward local strain, and such strain can actually help suppress collective lattice dynamics which hinder charge transport.<sup>105</sup> 

**3.1.3. Nonradiative Recombination in 3D Halide Perovskites.** The defect tolerance of 3D halide perovskites contributes to their low nonradiative recombination, as quantified by the open-circuit voltage ( _V_ OC) deficit of halide perovskite solar cells.<sup>20</sup> When sunlight excites charges in a solar cell, it splits the quasi-Fermi levels of electrons and holes. The difference between these quasi-Fermi levels is the achievable _V_ OC for a solar cell. Any nonradiative recombination of electrons and holes reduces the quasi-Fermi level splitting, lowering achievable _V_ OC. The _V_ OC deficit _Eg_ / _q_ − _V_ OC, the difference between the bandgap voltage and _V_ OC, correlates with the halide perovskite’s nonradiative recombination rate. State-of-the-art 3D halide perovskite devices have shown _V_ OC deficits as low as 0.4 compared to their Shockley−Queisser (SQ) minimum _V_ OC deficit of 0.27, much better than other solution-processed photovoltaics such as organic photovoltaics (OPV) or dyesensitized solar cells (DSSC) but still worse than GaAs or GaInP<sup>143</sup> (Figure 4d). 

It appears that nonradiative recombination can be suppressed in halide perovskites through the strong coupling between the soft lattice and free carriers, which is discussed further below. Dynamic lattice distortions around a carrier can minimize the effect of electric fields generated by trap states on the carrier and reduce those trap states’ capture cross sections. Screening from the material’s high static dielectric constant also has an effect.<sup>148</sup> 

A once-popular explanation for the low recombination rates in 3D halide perovskites is the existence of a bulk Rashba effect. In noncentrosymmetric crystals, electrons can feel an effective magnetic field from spin−orbit coupling (SOC) which lifts electron spin degeneracy and creates an indirect bandgap, suppressing recombination. The heavy Pb and I ions in MAPbI3 indeed show significant SOC, but whether or not MAPbI3 is centrosymmetric has been a subject of debate. More recently it has appeared that MAPbI3 is indeed centrosymmetric, and no static bulk Rashba effect exists<sup>149</sup> (Figure 4e). Moreover, depolarization fields strongly reduce the impact of bulk polarizations in halide perovskites, which do not belong to the category of hyperferroelectric materials.<sup>150</sup> There may be a dynamic Rashba effect due to inversion symmetry breaking from MA cation rotations, but recent work has suggested that this effect is not large enough to cause meaningful band splitting.<sup>149</sup> However, local polarization effects should not be ignored, since any local symmetry breaking in such highly ionic materials shall lead to the creation of a local charge or dipole. 

Although the effects of defects are suppressed in 3D halide perovskites, shallow trap states from charged defects are still a major contributor to nonradiative recombination. Defect states at grain boundaries and interfaces in particular seem to be detrimental to charge extraction. Many of the innovations made 

to push halide perovskite device efficiency higher have centered around reducing or passivating these defect states. 

**3.1.4. Carrier Transport in 3D Halide Perovskites.** The high covalency afforded by the 3D network of overlapping Pb−I orbitals in halide perovskite crystals gives a delocalized electronic structure leading to a low exciton binding energy and free-carrier-like charge transport.<sup>98,105</sup> The exciton binding energy of MAPbI3 is 16 meV in the low-temperature orthorhombic phase (Figure 5a and Table 4), comparable to that of Si (15 meV), and <10 meV in the room-temperature tetragonal phase. This energy is well below the thermal energy _k_ B _T_ at room temperature (about 25 meV).<sup>105,106,152</sup> As a result, excitons in MAPbI3 are easily dissociated into free carriers at room temperature. The electron and hole effective masses appear to be comparable, with an exciton reduced effective mass _m_ * = (1/ _m_ e + 1/ _m_ h)<sup>−1</sup> of 0.104 _m_ e.<sup>106</sup> The charge carrier mobility of 3D halide perovskites is on the order of tens of cm<sup>2</sup> / (V s), and the carrier diffusion length can range from hundreds of nm in films to hundreds of _μ_ m in single crystals.<sup>153,154</sup> 

The soft lattice of 3D halide perovskites gives experimentally a low energy density of optical vibrations that as a result have a high population at room temperature,<sup>155</sup> therefore promoting electron−lattice coupling which is much more pronounced than in inorganic semiconductors.<sup>107</sup> The high dielectric constants of 3D halide perovskites give phonons a greater effect on local electric fields, enhancing coupling further.<sup>156</sup> It is often suggested that the strong electron−phonon interactions in halide perovskites could manifest in polaronic charge transport, whereby charge carriers couple to local lattice deformations which travel together as a quasiparticle.<sup>157−160</sup> While it appears that some form of local polaronic behavior is present in these materials<sup>161</sup> (Figure 5b), many materials properties including the temperature dependence of the carrier mobility are inconsistent with a polaron model<sup>156,162</sup> (Figure 5c). Indeed state-of-the-art modeling of carrier mobilities clearly states that extended Frôhlich polaron mechanisms have a negligible effect.<sup>107</sup> A complementary picture of electron−phonon interactions is based on the dynamic disorder model, which aims at capturing the anharmonicity of 3D halide perovskites’ lattice<sup>156</sup> (Figure 5d). It is indeed nowadays very often assumed that optical phonons have a protective effect on charge carriers, with local lattice deformation leading to longer carrier lifetime. This effect is a double-edged sword, however, causing a decrease in carrier mobility. Most analyses nevertheless rely on idealized or weakly anharmonic phonon pictures that do not match the direct experimental observations of the lattice dynamics displaying overdamped and dispersionless optical branches,<sup>155</sup> as well as various low-frequency stochastic relaxational motions.<sup>163</sup> It is therefore urgently needed to propose theoretical treatments of lattice anharmonicity and electron− phonon coupling far beyond classical perturbative or selfconsistent approaches. Using such approaches, a correct picture of the lattice dynamics can be recovered with a strong impact on 

**9576** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 6. Sharp optical absorption edge in 3D perovskites. (a) Comparison of absorption spectra for various photovoltaic absorbers showing excellent MAPbI3 Urbach energy. Reproduced with permission from ref 178. Copyright 2017 American Chemical Society. (b) _V_ OC deficit plotted against Urbach energy for a variety of perovskite and inorganic semiconductors, reproduced with permission from ref 172. Copyright 2020 American Chemical Society. (a−b) Reproduced with permission from ref . Copyright 2022 American Chemical Society. (c) Temperature-dependence of Urbach energy for a variety of semiconductors showing the extremely low static Urbach energy of MAPbI3 (black). Reproduced with permission from ref 179. Copyright 2019 American Chemical Society. (d) Autocorrelation function of the disorder potential of MAPbI3 at 425 K calculated using molecular dynamics (MD). The thick curve is the average of snapshots along the force-field MD trajectory (thin curves). Reproduced with permission from ref 177. Copyright 2019 Springer Nature. 

the electronic properties including bandgap renormalization and smearing of both electronic and vibrational densities of states.<sup>164</sup> 

It has been suggested that dynamic ordering of the ns<sup>2</sup> lone pairs on B-site cations contributes to the high dielectric function and acts to protect charges in 3D halide perovskites.<sup>148</sup> The sp antibonding state comprising the halide perovskite’s VBM is stabilized through hybridization between the B cation’s s state (VBM) and the p state (CBM), facilitated by the anion p state. With some p-character, the VBM state now shows an asymmetric electron density directed toward one of the B cation’s coordination sites. This results in an inherent lattice instability that can manifest as dynamic B cation off-center displacement. The flat-bottom potential of B cation reorientation in 3D halide perovskites allows for dynamic local reorientation in the presence of free carriers, manifesting in a ferroelectric-like increase in the dielectric function in the THz regime and electron−lattice coupling which can reduce scattering. 

**3.1.5. Urbach Energy in 3D Halide Perovskites.** The Urbach energy _E_ U of a solar cell’s absorber layer is also correlated with its _V_ OC deficit (Figure 6b). 3D halide perovskites show Urbach energies comparable to those of GaAs (7.5 meV) and c- Si (12.5 meV) as shown in Figure 6a−b, which is remarkable for such soft materials.<sup>171</sup> Halide perovskite films have static Urbach energies (i.e., _E_ U at 0 K) between 3.5 and 5 meV,<sup>172,173</sup> lower than the static _E_ U of GaAs, GAN, InP, or c-Si (Figure 6c).<sup>173</sup> At room temperature, halide perovskite films show _E_ U values as low 

as 11 meV (MAPbI3)<sup>174</sup> or 13 meV (FAPbI3),<sup>175</sup> although some halide perovskites such as CsPbI3 have _E_ U values as high as 77 meV.<sup>176</sup> Notably, halide perovskite films do not have significantly higher _E_ U values than single crystals.<sup>171</sup> These small Urbach tails and steep absorption edges indicate a high degree of nanoscale crystallinity. Molecular dynamics simulations have suggested that although halide perovskites show anharmonic nuclear dynamics and disorder at room temperature, MAPbI3 and CsPbI3 exhibit short-range disorder potentials within a bond length (Figure 6d). The correlation length of the disorder potential in these materials is comparable to that of Si and GaAs, which is possible because of dynamic displacements of primarily the X anion and indirectly from the A cation.<sup>177</sup> 

**3.1.6. Solution Processability of 3D Halide Perovskites.** Because of their ionic nature, their soft lattice, and their low lattice energy, halide perovskites have the distinct advantage over inorganic semiconductors of being solution processable.<sup>180−187</sup> High-quality halide perovskite films can be prepared by dissolving precursor AX and BX2 salts in a mixture of polar aprotic solvents such as 4:1 DMF:DMSO, precipitating the halide perovskite phase with an antisolvent, and annealing (Figure 7a−d). In this case DMF acts as a solute and DMSO as a Lewis base to complex with the precursor salts in solution. In the case of MAPbI3, IR spectroscopy shows a decrease in stretching frequency for the S�O bond of DMSO upon incorporation of PbI2 and MAI + PbI2 powders, confirming the formation of PbI2· 

**9577** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 7. Solution processing of 3D perovskites. (a−d) Schematic of film deposition pathways for MAPbI3 and their resulting microstructures. The use of a Lewis base (DMSO) and an antisolvent (diethyl ether) gives compact, high-quality MAPbI3 films as in (d). (a−d) Reproduced with permission from ref 187. Copyright 2015 American Chemical Society. (e) SEM images of highly crystalline and a pinhole-free MAPb(I1− _x_ Cl _x_ )3 film grown at room temperature through the formation of a metastable intermediate 2D phase. Reproduced with permission from ref 185. Copyright 2020 Royal Society of Chemistry. (f) Schematic showing the formation of an MAI·PbI2·DMSO adduct complex as an intermediate phase for perovskite crystal growth. Reproduced with permission from ref 186. Copyright 2014 Springer Nature. 

DMSO and MAI·PbI2·DMSO adducts.<sup>187</sup> This MAI·PbI2· DMSO adduct phase corresponds to the white film seen for MAPbI3 before annealing. By exploiting the volatility of DMSO in this adduct, annealing of the film can remove the DMSO and leave a dense film of MAPbI3 (Figure 7f). Films of MAI·PbI2· DMSO adducts are precipitated during spin-coating by dripping an antisolvent that is miscible with the precursor solvent but does not dissolve the halide perovskite precursors (e.g., toluene).<sup>186</sup> For FAPbI3, DMSO is sometimes fully or partially replaced with a more suitable Lewis base such as NMP<sup>188</sup> or thiourea.<sup>189</sup> A two-step deposition method can also be employed, whereby FAI is deposited on top of a PbI2·DMSO film to form FAPbI3 through FAI−DMSO intramolecular exchange.<sup>190</sup> As with MAPbI3, each of these FAPbI3-adduct films can then be annealed to drive off the Lewis base and leave compact FAPbI3 films, with the caveat that the halide perovskite must be heated to 150 °C to form the high-temperature black phase. Thermodynamically stable halide perovskite phases such as MAPbI3 are usually processed at temperatures below 100 °C, and pinhole-free films can even be achieved at room temperature through solvent engineering<sup>185</sup> (Figure 7e). Solution-based processing also allows for the easy incorporation of additives (e.g., for defect passivation or to control film growth kinetics) or the alloying of A-, B-, or X-site ions through the mixing of their salts.<sup>18,19,191</sup> 

Scaling up of perovskite devices is another requirement for commercialization, since the conventional spin-coating film 

deposition techniques are limited to devices ≤1 cm<sup>2</sup> compared to a > 800 cm<sup>2</sup> commercial module.<sup>192</sup> Fortunately, a variety of techniques have been demonstrated for forming high-quality large-area halide perovskite films, including blade coating, slotdie coating, spray coating, and electrodeposition.<sup>193</sup> It is important to note that each of these techniques place different constraints on the solvents, antisolvents, and deposition steps possible for film formation, depending on factors including solvent evaporation rate.<sup>192</sup> Moreover, solution processing offers opportunities for low-cost, high-throughput manufacturing compared to the conventional high-temperature crystal growth and wafer processing used for inorganic solar cells.<sup>4</sup> Lowtemperature solution processing may also one day enable a rollto-roll manufacturing process on flexible substrates which promises high-throughput mass production.<sup>193,194</sup> For interested readers, the review article “Scalable fabrication and coating methods for perovskite solar cells and solar modules” by Park and Zhu provides an excellent introduction to large-area perovskite deposition technologies and considerations for their use.<sup>192</sup> 

However, it is important to note that not only the halide perovskite layer but every layer in the device stack must be processable via low-cost techniques to realize cheap devices and, in particular, must be low-temperature processable for flexible substrates.<sup>195</sup> Conventional perovskite solar cells use an intrinsic (undoped, “i”) halide perovskite layer sandwiched between an n- doped electron transport layer (ETL, “n”) and a p-doped hole 

**9578** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** **<u><mark>pubs.acs.org/CR</mark></u>** <mark>Review</mark> 



Figure 8. Ionic mobility and doping in 3D perovskites. (a) Vacancy-mediated ion migration pathways for I (along octahedral edges), Pb (diagonally across cuboctahedral faces), and MA (through cuboctahedral faces). Reproduced with permission from ref 199. Copyright 2015 Springer Nature. (b) Temperature-dependent conductivity of MAPbI3 large-grain film (top right), small-grain film (bottom left), and single crystal (bottom right). Top left: schematic of experimental setup. Ion migration is seen in all samples as the change in slope of ln( _σT_ ) vs _T_<sup>−1</sup> at high temperatures. Ion migration is suppressed in single crystals compared to small-grain films and in dark compared to light conditions. Reproduced with permission from ref 200. Copyright 2016 Springer Nature. (c) Influence of PbI2:MAI precursor ratio on the Fermi level in MAPbI3 films showing p-doping by VPb and n-doping by VMA. Reproduced with permission from ref 203. Copyright 2014 American Institute of Physics. (d) Influence of substrate on the Fermi level of MAPbI3 showing significant charge transfer doping, which implies a low intrinsic carrier density. Reproduced with permission from ref 205. Copyright 2014 Royal Society of Chemistry. 

transport layer (HTL, “p”). So-called “regular” (n-i-p) perovskite device architectures place the ETL between the substrate/ bottom contact and the perovskite and place the HTL between the perovskite and the top contact. Common ETLs for regulararchitecture devices are metal oxides such as TiO2 and SnO2, which generally have high processing temperatures. These considerations have motivated research on inverted (p-i-n) 

halide perovskite devices, with a hole-collecting substrate and electron-collecting top contact, because of the reduced temperatures required for processing the substrate HTL in an inverted device stack compared to mesoporous TiO2 for a regular stack.<sup>196</sup> High processing temperatures for transport layers also limit the possibilities for two-terminal tandem devices.<sup>197</sup> 

**9579** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 9. Ferroelectricity of 3D perovskites. (a) Dielectric function of a tetragonal MAPbI3 single crystal at 204 K (top) and integration of the dominant imaginary component over the bias field to reveal a polarization−electric field (P-E) hysteresis loop (bottom), which is strong evidence for ferroelectricity. Reproduced with permission from ref 206. Copyright 2017 National Academy of Sciences. (b) Electric current generated in response to IR illumination in a cubic MAPbBr3 single crystal for Au electrodes (top) and Pb electrodes (bottom). A current response to surface heating could be indicative of pyroelectricity, which is a prerequisite for ferroelectricity. However, the electrode-dependent current response and the decay of the response across cycles from the first measurement (black) to the last (green) suggest that the current is actually from trapped charges, and no pyroelectric effect is evident. This forbids Cubic MAPbBr3 from being ferroelectric. Reproduced with permission from ref 211. Copyright 2016 American Institute of Physics. (c) Temperature-dependence of the C44 shear modulus (black) and Bragg M point intensity (red) for FAPbBr3 showing a ferroelastic phase transition at ∼265 K. Reproduced with permission from ref 138. Copyright 2018 American Physical Society. 

**3.1.7. Ionic Mobility in 3D Halide Perovskites and** 

**Resistance to Extrinsic Electrical Doping.** The soft lattice of 3D halide perovskites allows for significant ionic mobility in the crystal. DFT simulations of MAPbI3 disagree on the precise activation energies for ion diffusion but agree that I<sup>−</sup> is the most mobile species, hopping along the edges of PbI6 octahedra. In comparison, MA<sup>+</sup> is less mobile, hopping through the face of the cuboctahedral site, and Pb<sup>2+</sup> is the least mobile, hopping diagonally across the cuboctahedral face<sup>198,199</sup> (Figure 8a). Ionic mobility is a significant contributing factor to the significant current−voltage hysteresis observed in 3D halide perovskite solar cells which will be expanded upon in section 4. Reports on the temperature-dependence of conductivity in MAPbI3 have found a clear transition in slope around room temperature which suggests a switch in the principal charge carriers from electrons (low- _T_ ) to ions (high- _T_ )<sup>200,201</sup> (Figure 8b). These measurements confirmed that at room temperature MAPbI3 is effectively a mixed ionic−electronic conductor. 

Related to halide perovskites’ ionic mobility is their resistance to be extrinsically electronically doped.<sup>202</sup> Although many impurities are expected to introduce shallow donor or acceptor states into the lattice, charge compensation by mobile ions and intrinsic defects limits the effect of introducing dopants. DFT simulations suggest that degenerate p-doping is possible in MAPbI3 by substitution of Pb<sup>2+</sup> with Na<sup>+</sup> or K<sup>+</sup> , or substitution of I<sup>−</sup> with O<sup>2−</sup> , but that extrinsic n-doping cannot achieve a higher concentration than what is possible with intrinsic doping in MAPbI3. 

As many intrinsic defects are shallow donors or acceptors, some degree of control over the Fermi level can be achieved by controlling the concentration of intrinsic defects. By tuning the I:Pb ratio in MAPbI3, the ratio between the crystal’s dominant donor defects (MAi, Pb-rich conditions) and acceptor defects (VPb, Pb-poor conditions) can be controlled to raise or lower the Fermi level<sup>203</sup> (Figure 8c). However, most studies have found an intrinsic carrier density cap of <10<sup>14</sup> for MAPbI3.<sup>202</sup> Charge transfer doping between a halide perovskite and a p-doped or n- doped substrate has been observed to dictate the Fermi level deep into the halide perovskite layer, indicating a low density of intrinsic carriers<sup>202,204,205</sup> (Figure 8d). 

**3.1.8. Bulk Ferroelectricity in 3D Halide Perovskites.** 

There are several factors which complicate the measurement of ferroelectricity in 3D halide perovskites. First, their <2 eV bandgaps are low enough that applying a strong electric field generates a significant unwanted leakage current which obscures the measurement of polarization domain reorientation.<sup>206</sup> Second, their dynamic lattices allow mobile ions to move in response to an intrinsic or applied field, adding to leakage current and introducing hysteresis that can be misinterpreted as ferroelectricity.<sup>206,207</sup> As a result, whether or not MAPbI3 is ferroelectric has been a point of debate for years within the halide perovskite community.<sup>206,208−210</sup> Several studies have reported a ferroelectric response in the tetragonal phase of MAPbI3 (stable below 57 °C) which decreased in the cubic phase (above 57 °C). Poling with a 16 kV/cm field was shown to orient polarization domains within tetragonal MAPbI3, which could persist for weeks.<sup>208</sup> Integration of the imaginary 

**9580** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 10. State-of-the-art 3D perovskite solar cells. (a) Record efficiency for perovskite and perovskite-Si tandem solar cells over time. Record Si solar cell efficiency is shown by the dashed line. Data from ref 5. This plot is courtesy of the National Renewable Energy Laboratory, Golden, CO. (b) Record efficiency for a variety of solar cell materials plotted against cumulative publications. A trend of ∼5% PCE increase for every 10× publications is shared by a variety of materials including perovskites. Reproduced with permission from ref 234. Copyright 2023 Elsevier. (c) Characteristic high-efficiency n- i-p 3D perovskite device _J_ − _V_ curve with 25.8% PCE. Inset shows the device architecture: FTO−Cl-treated SnO2−FAPbI3-MDACl2 perovskite−MeOPEAI passivation layer (MeO-PEA = 4-methoxyphenethylammonium)−Spiro-OMeTAD−Au. Reproduced with permission from ref 219. Copyright 2021 Springer Nature. (d) Characteristic high-efficiency p-i-n 3D perovskite device _J_ − _V_ curve with 25.4% PCE. Inset shows the device architecture: ITO−MeO-2PACZ−(Rb0.05Cs0.05MA0.05FA0.85)Pb(I0.95Br0.05)3 perovskite−3-(aminomethyl)pyridine passivation layer−LiF passivation layer−C60− BCP passivation layer−Ag. Reproduced with permission from ref 225. Copyright 2022 Springer Nature. 

component of the dielectric function of tetragonal MAPbI3 over applied bias reveals an unmistakable hysteresis loop, which is strong evidence for ferroelectricity (Figure 9a). However, these results contradict experimental and simulation results, which contend that MAPbI3 is centrosymmetric and therefore nonferroelectric.<sup>149</sup> Nonetheless, it appears that MAPbI3 can indeed be ferroelectric in its tetragonal phase at low temperature. 

Other perovskite phases such as MAPbBr3 have been definitively proven to not be ferroelectric.<sup>211</sup> MAPbBr3 was found to create an electric current in response to surface heating, which could be an indicator of pyroelectricity and a noncentrosymmetric structure; however, this current was electrodedependent and decreased with repeated cycling, suggesting that it was actually related to the detrapping of charges from the crystal and that the structure is in fact centrosymmetric (Figure 9b). On the other hand, nanocrystals of FAPbBr3 do show ferroelectricity and have been successfully employed in piezoelectric devices.<sup>212</sup> 

Many crystals which contain ns<sup>2</sup> cations such as Pb<sup>2+</sup> have shown second-order Jann−Teller distortion, which manifests a displacive ferroelectric effect; however, oxide perovskites that demonstrate this effect all have a tolerance factor above 1, which facilitates the required B-site distortion.<sup>148</sup> In that case, an A-site cation larger than FA would be required to expect bulk ferroelectricity, but such a cation would be unstable in the 3D halide perovskite structure. It seems that the B cation displacement potential for most 3D halide perovskites is a flat 

bottom well rather than the double-well characteristic of ferroelectric behavior. A-site molecular reorientation could in theory also lead to a long-range lattice polarization, but in the MAPbI3 ground state the MA cations are antipolar, resulting in no net dipole moment. At room temperature MA cations appear fully disordered, which would also preclude ferroelectricity.<sup>213</sup> Depolarization fields are also expected to strongly counteract the creation of a spontaneous polarization at the macroscopic scale, and 3D halide perovskites do not belong to the class of hyperferroelectric materials.<sup>150</sup> 

It has been proposed that many of the reports of ferroelectricity in halide perovskites are in fact observations of ferroelastic effects�that is, the creation of a spontaneous strain distribution rather than a spontaneous net dipole moment.<sup>144,213</sup> For example, the apparently ferroelectric domains in MAPbI3 observed via piezoresponse force microscopy (PFM) may in fact be ferroelastic domains of alternating crystal orientation. It was shown directly from a combined inelastic neutron and Brillouin scattering study that the unusual softening of the shear modulus C44 in FAPbBr3 just below RT is typically related to the proximity of a ferroelastic transition, which, in this case, remains incipient at the macroscopic level<sup>138</sup> (Figure 9c). This means nevertheless that any local lattice perturbation or stoichiometry deviation may stabilize ferroelastic strain in such a compound. If 3D halide perovskites exhibit some local polarization or spontaneous strain effects, it seems unlikely 

**9581** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

Table 5. Reported n-i-p Halide Perovskite Devices with PCE > 24.5%. 1-sun Illumination Stability and Shelf Stability Are Also Reported<sup>_a_</sup> 

|||Efficiency||1-sun ill|umination, MPP<br>atmospher|tracking, inert<br>e||Shelf stabilit|y, ambient a|ir||
|---|---|---|---|---|---|---|---|---|---|---|---|
||Reorted|Certified|||Stabilit scaled|||Stabilit scaled|Relative|||
|Year|p<br>PCE|i<br>PCE|Notes|Stability|y<br>to 1000 h (%)|Notes|Stability|y<br>to 90 days (%)|Humidity|Notes|Ref|
|2023|26.08|25.73||88% after<br>600 h|80|Encapsulated, in<br>air|||||216|
||25.64|25.06|||||||||235<br>|
||24.5|||82.2%<br>after<br>350 h|49||94.5%<br>after<br>1680 h|93|30%||236|
|2022|25.7|25.4||∼85% after<br>350 h|57||80% after<br>1000 h|57|20%||224|
||25.01|24.6||∼80% after<br>500 h|60||||||237|
||25.05|24.39||91% after<br>1000 h|91||||||238|
||24.95|24.17||81% after<br>1000 h|81|55°C|||||239|
||25.14|||93% after<br>400 h|83||90% after<br>1800 h|88|40%||240|
||24.5|||99% after<br>2000 h|100|Encapsulated, in<br>air,55°C|||||241|
|2021||25.7|||||||||242|
||25.8|25.5||∼90% after<br>500 h|80||||||243|
||25.6|25.2||85% after<br>450 h|67||90% after<br>1000 h|78|20%||218|
|||25.2||∼80% after<br>500 h|60||||||217|
||25.28|24.68|||||||||244|
|||24.59|24.35<br>stabilized|>98% after<br>1620 h|99|Encapsulated|97.3% after<br>1083 h|95|85%|Changed HTL for<br>test, 20.6% PCE|221<br>|
||24.7|||90% after<br>1000 h|90||73% after<br>740 h|21|>85%||245|
||24.6||||||99% after<br>2000 h|98|85%|No HTAB, 21%<br>PCE|246|
|2020||25.5<br>25.5|||||||||247<br>248|
||24.82|24.64|||||87% over<br>500 h|44|50%||222|
||25.17|24.37||90% after<br>400 h|75||||||223|
|2019||25.2|||||||||249|
|_a_Devic|es incorpor|ating 2D h|alide perov|skites are in|bold.|||||||



that these features meaningfully affect the charge transport properties of the crystal or device performance. 

### **3.1.9. Best-Performing 3D Halide Perovskite Devices.** 

In recent years the record efficiency of 3D halide perovskite solar cells has exceeded that of polycrystalline Si and is now approaching that of monocrystalline Si.<sup>5</sup> Figure 10a shows the record halide perovskite and halide perovskite-Si tandem efficiency over time. In general the “regular” n-i-p device architecture outperforms the “inverted” p-i-n architecture, although p-i-n devices have nearly caught up with n-i-p devices recently.<sup>214,215</sup> Tables 5 and 6 list n-i-p and p-i-n 3D halide perovskite solar cells with efficiency exceeding 24%. 

As of February 2023 the highest efficiency verified by NREL for an n-i-p halide perovskite solar cell is 25.7%.<sup>5,216</sup> Almost all reported devices with efficiency over 24% (of which there were only a handful as of January 2023) shared the same general architecture: an FTO bottom contact, a SnO2 or TiO2 ETL, a FAPbI3 or majority-FAPbI3 absorber layer, a spiro-OMeTAD HTL, and an Au top contact.<sup>217−224</sup> The innovation of each of these devices which allowed for such excellent efficiency varied in each case but usually involved a combination of passivation of 

interfaces and grain boundaries, improvement of transport layer energy alignment and carrier transport, passivation or reduction of intrinsic trap states, and improved crystallinity. Notably, many aspects of these high-performing devices are either difficult to scale (e.g., the Spiro HTL) or prohibitively expensive for commercial devices (e.g., the Au top contact). The _J_ − _V_ curve and cell architecture of a characteristic high-efficiency n-i-p device are shown in Figure 10c. 

The p-i-n architecture seems much more promising than n-i-p in terms of scalability, but p-i-n efficiency is still lagging slightly behind.<sup>215</sup> The highest-efficiency p-i-n halide perovskite solar cell reported as of February 2023 had a 25.35% efficiency (certified 24.05%),<sup>225</sup> with the cell architecture and _J_ − _V_ curve shown in Figure 10d; the highest certified efficiency stands at 24.3%.<sup>226</sup> There have been only ∼10 reported p-i-n devices with PCE > 24%, and only two above 25%.<sup>225−233</sup> These cells also shared a majority-FAPbI3 absorber layer, but there was more variance in charge transport layer choice between them. NiO _x_ and MeO-2PACZ are both popular bottom HTLs for highefficiency p-i-n cells, and the top ETL is usually C60 or PCBM. 

**9582** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

Table 6. Reported p-i-n Halide Perovskite Devices with PCE > 24%. 1-sun Illumination Stability and Shelf Stability Are Also Reported<sup>_a_</sup> 

|||Efficiency|fi|1-sun illumina|tion, MPP tracking|, inert atmosphere||Shelf stability, amb|ient air|||
|---|---|---|---|---|---|---|---|---|---|---|---|
|Year|Reported<br>PCE|Certified<br>PCE|Notes|Stability|Stability scaled<br>to 1000 h (%)|Notes|Stability|Stability scaled to<br>90 days (%)|Relative<br>Humidity|Notes|Ref|
|2023|24.6|24.2||96% after<br>1000 h|96||||||233|
||24.3|24.2||∼120% after<br>1100 h|118||||||232|
||24.48|23.2||82% after<br>1000 h|82||96% after<br>1000 h|91|30%||231|
||24.12||||||95% after<br>1200 h|91|55%||230|
|2022|25|24.3||98% after<br>1500 h|99||98% after<br>2000 h|98|45%||226|
||25.35|24.05||87% after<br>2428 h|95||||||225|
||24.3|23.5||90.5% after<br>1000 h|91|55°C|||||228|
||24.27|23.4|perovskite/<br>BHJ cell|90% after<br>1000 h|90||85% after<br>1000 h|68|55%||227|
||24.3|||95% after<br>500 h|90|Encapsulated,<br>20.5% PCE|||||229|



_a_ Devices incorporating 2D halide perovskites are in bold. 

Usually, a buffer layer is added between the halide perovskite and ETL layer. 

Interestingly, when compared in terms of cumulative number of publications instead of time, halide perovskite solar cell efficiency has increased at about the same rate as those of Si, CIGSe, and CdTe, showing about a 5% increase in PCE per factor of 10 increase in publications<sup>234</sup> (Figure 10b). This logarithmic increase suggests that improving the last few percentage points toward halide perovskites’ thermodynamic limit of efficiency may be a difficult task. Fortunately, the efficiency of halide perovskite solar cells taken alone is already sufficient to compete with established solar cell technologies. However, the new and critical challenge is to improve the scalability and stability of halide perovskite cells.<sup>4</sup> 

### **3.2. Semiconductor Properties of 2D Halide Perovskites** 

### **3.2.1. Origin of 2D Halide Perovskites’ Wider Bandgap** 

**and Optical Spectrum.** The optoelectronic properties of 2D halide perovskites, like those of 3D, arise from the cornersharing PbI6 octahedra.<sup>43,50</sup> The VBM and CBM have the same atomic orbital character as in 3D halide perovskites, as shown in Figure 11a. However, quantum confinement raises 2D halide perovskites’ bandgap substantially, as the organic spacer layers present a barrier to out-of-plane electron motion. 2D halide perovskites can be considered as superlattices of quantum wells similar to classical semiconductors,<sup>276</sup> with the important exception that their electronic structure cannot be understood on the basis of transverse effective mass models, since the halide perovskite well and the organic barrier strongly differ in nature.<sup>277</sup> Quantum confinement effects are rather revealed by DFT calculations, including the existence of n sub-bands in both the conduction and valence bands when the quantum thickness is tuned.<sup>43</sup> For RP 2D halide perovskites, the band structure shows in most cases a close to flat dispersion along the stacking axis indicating minimal coupling (Figure 11b), since the interlayer distances between halide perovskite quantum wells are large even for small alkylammonium chains such as BA in the barrier; for DJ and ACI 2D halide perovskites interlayer coupling can be enhanced by shorter interlayer distances, but the 

transverse effective masses along the stacking axes remain so far much larger than the in-plane effective masses (Table 7).<sup>50</sup> 

2D halide perovskites exhibit unique photophysics properties compared with their 3D counterparts, resulting from a reduced dimensionality, and strongly bound electron−hole pairs (excitons) at room temperature. The steady-state optical absorption and photoluminescence spectra of 2D halide perovskites exhibit strong excitonic resonances at room temperature, as a result of the strong Coulomb interactions and large exciton binding energies of 2D halide perovskites (0.1−0.5 eV) in layered QW like materials.<sup>65</sup> The absorption coefficient of 2D halide perovskites is typically a few 10<sup>5</sup> cm<sup>−1</sup> at exciton ground states, which is 1 order of magnitude higher than that of 3D halide perovskites, making 2D halide perovskites efficient absorbers in this spectral region. Such high absorption coefficient in 2D systems results from the quantum and dielectric confinement in 2D systems, leading to a large oscillator strength of excitons at ground state (Figure 11c). 

The steady-state optical absorption and PL spectra of typical RP 2D halide perovskites series (BA2MA _n_ −1Pb _n_ I3 _n_ +1) are listed in Figure 11d−e.<sup>278</sup> Both PL and optical absorption spectra show monotonous decrease in exciton energy and bandgap, with _n_ -value increase from 1 to 5. Such behavior is expected from the decrease of quantum and dielectric confinement with increasing inorganic layer thickness, resulting in lower continuum bandgap and exciton binding energy. The most remarkable evidence of the dielectric confinement effect, similarly to other 2D materials,<sup>279</sup> is the deviation of nS exciton resonances from 2D Rydberg series. It has been analyzed in detail as a function of _n_ up to _n_ = 5 in BA2MA _n_ −1Pb _n_ I3 _n_ +1 RP phases by combining magneto-optical spectroscopy and theoretical analyses.<sup>65</sup> 

Structural differences between the three types of 2D halide perovskite result in subtly different bandgaps. The ACI 2D halide perovskite GAMA _n_ Pb _n_ I3 _n_ +1 has a bandgap of 2.27 eV for _n_ = 1 and 1.73 eV for _n_ = 3.<sup>52</sup> The RP halide perovskite BA2MA _n_ −1Pb _n_ I3 _n_ +1 has a bandgap of 2.43 eV for _n_ = 1 and 2.03 eV for _n_ = 3, wider than that of ACI because of the longer interlayer distance and increased octahedral distortion.<sup>47</sup> The DJ halide perovskite (3AMP)(MA) _n_ −1Pb _n_ I3 _n_ +1 (3AMP = 3- 

**9583** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 11. Origin of 2D halide perovskites’ wider bandgap and optical spectrum. (a) Hybridizations of atomic orbitals for the electronic states at the band edges in 2D halide perovskites (Cs2PbI4), without SOC. The VBM is formed by antibonding orbitals of Pb 6s - I 5p, and the CBM by Pb - p and I - s states, the same characteristics as in 3D halide perovskites. (b) Band structure of the Cs2PbI4 calculated by DFT including SOC. (c) Energy level alignment (top) and dielectric constant profile (bottom) along the stacking direction in the 2D halide perovskites. (a−c) Reproduced with permission from ref 50. Copyright 2020 Springer Nature. (d) Absorption and (e) PL spectra for exfoliated crystals of 2D halide perovskites (BA)2(MA) _n_ −1Pb _n_ I3 _n_ +1 with _n_ = 1−5, respectively. (d−e) Reproduced with permission from ref 278. Copyright 2017 American Association for the Advancement of Science. (f) Schematics of the Rydberg series of the exciton ground state (1s) and excited exciton states (2s, 3s, etc.). Reproduced with permission from ref 65. Copyright 2018 Springer-Nature. (g) Illustration of exciton diffusion and recombination dynamics in 2D halide perovskites after photoexcitation. Reproduced with permission from ref 278. Copyright 2017 American Association for the Advancement of Science. 

(aminomethyl)piperidinium) has a bandgap of 2.23 eV for _n_ = 1 and 1.92 eV for _n_ = 3, lower than that of RP because of DJ’s lower axial octahedral distortion and the destabilizing effect of interlayer I−I interactions on the VBM.<sup>51</sup> Bandgaps for a selection of 2D halide perovskites are given in Tables 8 and 9. 

Furthermore, as a result of the layered structure, a strong anisotropic optical response is observed in terms of the dielectric function of these materials, leading to the formation of excitons with anisotropic absorption in 2D halide perovskite systems.<sup>280−284</sup> 

The emission bandwidth of 2D halide perovskites is highly variable based on the intrinsic structural disorder and the strength of the electron−phonon coupling. For example, photoluminescence of lead-based 2D halide perovskites shows narrow exciton emission bandwidths with low Stokes shift, which allow for the design of tunable-color narrowband 

emitters.<sup>278</sup> On the other hand, strong electron−phonon coupling in 2D halide perovskites results in structural deformation and charge localization leading to the formation of self-trapped excitons and broadband emissions, which has promising applications in white-light emission.<sup>285</sup> 

Another important feature related to the optical properties of 2D halide perovskites is the emissions from low-energy states located at the edges of the perovskite layers, first evidenced for _n_ > 2 in BA2MA _n_ −1Pb _n_ I3 _n_ +1 RP phases,<sup>278</sup> as demonstrated in Figure 11f. They have been attributed to intrinsic strain relaxation by localized octahedra promoting electron and hole separation<sup>67</sup> but may be enhanced by external effects such as the presence of moisture.<sup>286</sup> Their existence is fundamental for exciton dissociation and proper operation of solar cells based on 2D halide perovskites.<sup>287</sup> However, they may have detrimental effects for solar cell operation leading to a limitation of the open- 

**9584** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

Table 7. Exciton Effective Mass and Binding Energy for 2D Halide Perovskites 

|Year|Compound||Binding energy<br>(meV)|Effective mass<br>(_m_0)|Approach|Ref|
|---|---|---|---|---|---|---|
|2018|(BA)2(MA)_n_−1Pb_n_I3n+1(_n_= 1−5)|_n_= 1|470|0.221|Magneto optical absorption spectroscopy|65|
|||_n_= 2|250|0.217|||
|||_n_= 3|180|0.201|||
|||_n_= 4|160|0.196|||
|||_n_= 5|125|0.186|||
|2005|(C6H13NH3)2(MA)_n_−1Pb_n_I3n+1(_n_= 1 - 4)|_n_= 1|361||Optical absorption spectroscopy|265|
|2003||_n_= 2|260||Optical and electrical absorption spectroscopy|266|
|||_n_= 3|150||||
|||_n_= 4|100||||
|1996|(C9H19NH3)2(MA)_n_−1Pb_n_I3n+1(_n_= 1 - 4)|_n_= 1|388||Optical absorption spectra|267|
|||_n_= 2|181||||
|||_n_= 3|96||||
|||_n_= 4|60||||
|1998|(PEA)2(MA)_n_−1Pb_n_I3n+1(_n_= 1 - 4)|_n_= 1|220||Transmission spectroscopy|268|
|1991||_n_= 1|220|0.09|Optical absorption spectra|58|
|||_n_= 2|170||||
|2019||_n_= 3|125||Estimated from exciton scaling law|269|
|||_n_= 4|100||||
|1991|(C10H21NH3)2PbI4|_n_= 1|320|0.09|Optical absorption spectra|58|
|1989|(C10H21NH3)2PbI4|_n_= 1|370||Reflection, luminescence and absorption spectra|46|
|2009|(FC6H4C2H4NH3)2PbI4|_n_= 1|540|0.12|Temperature dependence PL spectroscopy|270|
|1990|(CmH2m+1NH3)PbI4(m = 4, 6, 12)|_n_= 1|300||Optical absorption spectroscopy|271|
|2000|[H3N(CH2)6NH3]PbI4|_n_= 1|153||Optical absorption spectroscopy|272|
||[H3N(CH2)6NH3]PbBr4||166||||
||[H3N(CH2)6NH3]PbCl4||205||||



Table 8. Bandgaps of Common RP 2D Halide Perovskites 

|A′|A|B|X|n|Bandgap|Ref|
|---|---|---|---|---|---|---|
|Butylammonium||Pb|I|1|2.43|47|
||MA|Pb|I|2|2.17|47|
||MA|Pb|I|3|2.03|47|
||MA|Pb|I|5|1.83|66|
||MA|Pb|I|7|1.74|66|
||MA|Pb|Br|1|2.99|290|
||MA|Pb|Br|3|2.4|73|
||MA|Pb|Cl|1|3.7|291|
|||Sn|I|1|1.83|63|
||MA|Sn|Br|2|1.64|63|
||MA|Sn|Br|3|1.5|63|
||MA|Sn|Br|5|1.37|63|
|||Sn|Br|1|2.28 (calc)|292|
||MA|Sn|Br|3|2.22|75|
||FA|Pb|I|2|2.18|68|
||GA|Pb|I|2|2.2|68|
|Hexylammonium|MA|Pb|I|2|2.16|79|
||MA|Pb|I|3|2.01|79|
|Phenylethylammonium||Pb|I|1|2.57|293|
||MA|Pb|I|3|2.1|49|



circuit voltage. In the case of LEDs based on multilayered BA2MA _n_ −1Pb _n_ I3 _n_ +1 RP phases,<sup>278</sup> this effect limits the external quantum efficiency (EQE) despite the injection of very large electrical current and excellent device stability.<sup>288</sup> Since the pioneering work by Blancon et al. in 2017, low-energy edge state emission has been observed in many other 2D halide perovskites including bromide ones.<sup>289</sup> 

For interested readers, the article “Semiconductor physics of organic−inorganic 2D halide perovskites” by Blancon et al. 

provides a more detailed review of the optoelectronic properties of 2D halide perovskites.<sup>50</sup> 

**3.2.2. Defect Tolerance in 2D Halide Perovskites.** 2D halide perovskites appear to share the defect tolerance of 3D halide perovskites afforded by the antibonding VBM of their band structure, at least to an extent.<sup>294</sup> However, quantum confinement and higher exciton binding energy in 2D halide perovskites increases exciton trapping. Below-bandgap exciton trap states can be detected using the transient absorption spectra, as shown for example in Figure 12a for BA2MA _n_ −1Pb _n_ I3 _n_ +1 ( _n_ = 1). The density of traps increases with decreasing _n_ -value, estimated from the relative magnitudes of peak bleaching from trap states (normalized to the 1s exciton bleaching signal).<sup>295</sup> 2D halide perovskites can also form selftrapped excitons from exciton−phonon interactions as a result of their lowered deformation energy compared to 3D halide perovskites (Figure 12b).<sup>285,295−297</sup> This may account for the below-gap and white-light emission seen in 2D halide perovskites that are not present in 3D, as shown in Figure 12c for (NMEDA)[PbBr4] (N-MEDA = N<sup>1</sup> -methylethane-1,2-diammonium).<sup>298</sup> Computational evidence also suggests that shallow defects in 3D halide perovskites may be deeper in 2D halide perovskites as a result of their lowered VBM and raised CBM due to quantum confinement (Figure 12d).<sup>299</sup> On the other hand, 2D halide perovskites have been shown to have higher defect formation energies than 3D halide perovskites (Figure 12e).<sup>300−302</sup> This may be a result of the higher lattice formation enthalpy of 2D halide perovskites and will be expanded upon below. 

**3.2.3. Nonradiative Recombination in 2D Halide Perovskites.** Like other lower-dimensional materials, layered 2D halide perovskites suffer from nonradiative losses of carriers, especially with high fluence of carrier injection. The emergence 

**9585** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

Table 9. Bandgaps of Common DJ and ACI 2D Halide Perovskites 

|Phase|A′|A|B|X|_n_|Bandgap|Ref|
|---|---|---|---|---|---|---|---|
|DJ|4-(Aminomethyl)piperidinium||Pb|I|1|2.38|51|
|||MA|Pb|I|2|2.17|51|
|||MA|Pb|I|3|1.99|51|
|||MA|Pb|I|4|1.89|51|
||3-(Aminomethyl)piperidinium||Pb|I|1|2.23|51|
|||MA|Pb|I|2|2.02|51|
|||MA|Pb|I|3|1.92|51|
|||MA|Pb|I|4|1.87|51|
||1,7-Heptanediammonium||Pb|I|1|2.43|92|
|||MA|Pb|I|3|2|92|
||1,9-Nonanediammonium||Pb|I|1|2.43|92|
|||MA|Pb|I|3|2.02|92|
|ACI|Guanidinium|MA|Pb|I|1|2.27|52|
||Guanidinium|MA|Pb|I|2|1.99|52|
||Guanidinium|MA|Pb|I|3|1.73|52|
||Protonated thiourea|MA|Pb|I|1|2.11|97|
||Protonated thiourea|MA|Pb|I|2|1.97|97|
||Protonated thiourea|MA|Pb|I|3|1.81|97|





Figure 12. Defect tolerance in 2D perovskites. (a) Pseudo color representations of TA spectra of BA2PbI4 with 350 nm excitation. A bleaching centered below the bandgap is attributed to the excitonic trap states. Reproduced with permission from ref 295. Copyright 2015 American Chemical Society. (b) Schematics of self-trapped excitons (STEs). Red and blue arrows indicate trapping and detrapping, respectively. Reproduced with permission from ref 285. Copyright 2017 Royal Society of Chemistry. (c) PL and absorbance spectra of (N-MEDA)PbBr4, showing white-light emission due to STEs. Reproduced with permission from ref 298. Copyright 2016 American Chemical Society. (d) Energy alignments of the CBM and VBMs of MAPbI3 and MA2Pb(SCN)2I2 as well as the defect transition levels, with respect to the vacuum levels. Reproduced with permission from ref 299. Copyright 2016 Royal Society of Chemistry. (e) Calculated defect formation energies of MAPbI3, PEA2PbI4, and BAPbI4, at the intrinsic Fermi level. Reproduced with permission from ref 301. Copyright 2022 arXiv. 

of the loss mechanism originated from the enhanced many-body interactions, such as the Auger effect and exciton−exciton annihilation (EEA). Compared with 3D systems, rapid rates of EEA and Auger recombination are generally expected in 2D halide perovskites, since the reduced dimensionality and large exciton binding energies enhance the electron−hole interactions, giving more probability of many-body effects in confined systems.<sup>303,304</sup> Specifically, the Auger recombination describes a three-body interaction, where an electron and hole nonradiatively give up their energy to another electron into the conduction band, resulting in a fast carrier recombination rate scaling with the cube of carrier population. Analogously, the 

EEA process describes a two-particle interaction, where kinetic energy is transferred from a recombined exciton to another exciton, giving a second order bimolecular carrier recombination. Both recombination losses are nonradioactive and therefore result in a roll-off of photoluminescence quantum yield (PLQY) at higher fluence and limit the efficient harvesting of carriers in a device (Figure 13a).<sup>305</sup> 

The rates of Auger and EEA recombination can be extracted from time-resolved photoluminescence or transient absorption spectroscopies, based on the kinetics equation of the carriers. However, the assignment of the kinetics of recombination can be sometimes nontrivial, since additional carrier dynamics (such as 

**9586** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 13. Nonradiative recombination in 2D halide perovskites. (a) PLQYs of 2D halide perovskite (red) and 3D halide perovskite films (blue) as a function of carrier density; the curves indicate serious Auger recombination takes place in 2D halide perovskites compared to the 3D ones, leading to rapid PLQY declining at lower threshold. Reproduced with permission from ref 305. Copyright 2021 Springer Nature. (b) Evolution of PL decays in 2D halide perovskites as a function of excitation intensity, showing exciton−exciton annihilation is the dominant recombination path in the highdensity regime. Reproduced with permission from ref 269. Copyright 2019 American Chemical Society. (c) Effective Auger rate constant ( _φ_ 2k3) in PEA-MA lead iodide thin films as a function of PEA concentration, extracted from fits to traces of optical pump terahertz probe spectroscopy. The recombination rates show an increase with PEA concentration and then a decrease for the 100% PEA film, which is attributed to the trade-off between the increase of the electric density of states and increased quantum confinement. Reproduced with permission from ref 255. Copyright 2016 American Chemical Society. 

Table 10. Charge Carrier Mobilities for 3D Halide Perovskites 

|Year|Compound|Charge carrier mobility (cm<sup>2 </sup>V<sup>−1 </sup>s<sup>−1</sup>)||Approach|Ref|
|---|---|---|---|---|---|
|1995|MASnI3|50 (Hall mobility)|Hall effect measurement||250|
|2013|MASnI3|2320 (Hall electron mobility)|||8|
||CsSnI3|536 (Hall electron mobility)||||
||FASnI3|103 (Hall electron mobility)||||
||MASn0.5Pb0.5I3|270 (Hall electron mobility)||||
||MAPbI3|66 (Hall electron mobility)||||
|2016|MAPbI3|197|Far-infrared spectroscopy, e|stimated by electron-LO phonon coupling|251|
||MAPbBr3|158||||
||MAPbCl3|58||||
|2013|MAPbI3−_x_Cl_x_(thin film)|11.6|THz spectroscopy||252|
||MAPbI3(thin film)|8||||
|2015|MAPbI3(single crystals)|164 (hole mobility)|SCLC measurements||154|



trap-assisted recombination, and bimolecular free-carrier recombination) may be convoluted.<sup>269,275,306</sup> There have been a few studies on the EEA and Auger recombination in 2D halide perovskites based on time-resolved spectroscopy. Delport et al. have studied PEA2MA _n_ −1Pb _n_ I3 _n_ +1 halide perovskites and demonstrated EEA rates on the order of 10<sup>−4</sup> cm<sup>2</sup> /s, 1 order of magnitude lower than the typical values in monolayer TMDs.<sup>269</sup> At high fluence, EEA rates start to dominate in the carrier recombination and show weak _n_ -dependence (Figure 13b). Chen et al. reports a decrease of biomolecular and thirdorder kinetics as _n_ -value increases in the 2D halide perovskite series.<sup>306</sup> Milot et al. reported the bimolecular and Auger rates for mixed PEA and MAPbI3 thin films, showing the fastest recombination rate with 67% PEA (⟨ _n_ ⟩≥ 2) content (Figure 13c).<sup>255</sup> Deng et al. utilized transient absorption microscopy to visualize both the spatial and temporal evolution of the exciton dynamics, revealing a large exciton diffusion constant and decreasing annihilation rate with increasing _n_ -value.<sup>275</sup> Till this day, there is still not a general consensus on the _n_ -value dependence on EEA and Auger rates in 2D halide perovskites, and more fundamental questions of the EEA and Auger recombination, as well as their interplay with carrier transport, 

and dependence with organic spacers, and structural distortion are still not well understood. 

To reduce the unwanted nonradiative recombination rates, several methods have been proposed to lower the nonlinear process in 2D halide perovskites, including compositional engineering to increase the recombination centers in 2D systems, structural engineering, and tailoring the dielectric confinement by reducing the e-h overlap.<sup>269,307</sup> These methods aim to manipulate the dielectric screening by the organic layers, which brings down the exciton binding energy. 

### **3.2.4. Carrier Transport of 2D Halide Perovskites.** 

Despite being good light absorbers with high absorption coefficient at exciton resonance, 2D halide perovskites suffer from reduced PCE in photovoltaic devices (∼19% so far) compared to their 3D systems.<sup>308</sup> This is partially due to the inferior charge transport properties in the multiple quantum well-like system, forming stable excitons leading to an inefficient charge separation and collection. The typical values of mobility are of the order of 10<sup>−2</sup> to 10 cm<sup>2</sup> V s<sup>−1</sup> (see Tables 10 and 11), variable on specific techniques, approximately 1 order of magnitude lower than the mobilities in 3DPKs, as well as other 2D materials such as TMDs and inorganic MQWs.<sup>50</sup> 

**9587** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

Table 11. Charge Carrier Mobilities for 2D Halide Perovskites 

|Year|Compound|Charge carrier mobility<br>(cm<sup>2 </sup>V<sup>−1 </sup>s<sup>−1</sup>)|Approach|Ref|
|---|---|---|---|---|
|1999|PEA2SnI4|0.62|Field effect transistors|253<br>|
|2016|PEA2SnI4|15 (hole mobility)|Field effect transistors|254|
|2016|Mixed MA-PEA 2D halide perovskites|1−25 (from PEA2PbI4to<br>MAPbI3)|Optical pump THz probe spectroscopy|255<br>|
|2017|(n-BA)2(MA)3Pb4I13|1.88|Optical pump THz probe spectroscopy|256|
||(iso-BA)2(MA)3Pb4I13|0.38|||
|2016|(BA)2(MA)3Pb4I13|10<sup>−2 </sup>(in solar cell)|Linearly increasing voltage (CELIV)|257|
|2017|(BA)2(MA)_n_−1Pb_n_I3_n_+1(_n_= 1−5)|10<sup>−1 </sup>−10°|Time-resolved microwave conductivity (TRMC)|258|
|2018|(BA)2(MA)_n_−1Pb_n_I3_n_+1(_n_= 1−4)|10<sup>−2 </sup>−10<sup>−1 </sup>(yield-mobility<br>product)|Time-resolved microwave conductivity (TRMC)|259|
|2019|(PEA)2PbI4|10<sup>−2 </sup>_- 10<sup>−1 </sup>(in-plane)<br>10<sup>−3 </sup>_- 10<sup>−2 </sup>(out-of-plane)|Time-resolved microwave conductivity (TRMC)|260|
||(F-PEA)2PbI4|10<sup>−2 </sup>−10<sup>−1 </sup>(in-plane)<br>5×10<sup>−3 </sup>−10<sup>−2 </sup>(out-of-plane)|||
|2018|Mixed MA-ALA 2D halide perovskites<br>(_n_= 10)|1.1|Photoluminescence Quenching Experiments, then use diffusion length and<br>Einstein relation|261|
||Mixed MA-PEA 2D halide perovskites<br>(_n_= 10)|5.7×10<sup>−1</sup>|||
||Mixed MA-BTA 2D halide perovskites<br>(_n_= 10)|8.9×10<sup>−2</sup>|||
|2001|(C6H4FC2H4NH3)2SnI4(_m_= 2−4)|0.2−0.6 (_m_= 4−2)|Field effect transistors|262|
|2017|(PEA)2PbI4|26 (hole)|Field effect transistors|263|



The low charge mobilities are mainly governed by the electron−phonon scattering mechanisms in 2D halide perovskites, as demonstrated by temperature-dependent microwave conductivity measurements in BA2MA _n_ −1Pb _n_ I3 _n_ +1 systems;<sup>258</sup> however, deviation from the electron−phonon scattering model has been observed with increasing _n_ -value approaching 3D (Figure 14a). This suggests the transport behavior in 2D halide perovskites is approaching their 3D analogues with increasing numbers of inorganic layers and that the dynamic disorder greatly affects the local crystal structure and subsequently the charge mobility.<sup>170,258</sup> Additionally, strong electron phonon coupling in 2D halide perovskites results in small polarons or immobilized self-trapped states and strong local lattice distortion and hinders the efficient band-edge transport to hopping-like transport between trapping sites,<sup>157,309</sup> while on the other hand it favors the broadband emission toward the applications of white-light LEDs.<sup>285</sup> However, the specific types of phonons involved in the electron−phonon scatterings 2D halide perovskites, and the subsequent effects on the charge mobilities, are still in debate. 

Besides the free-carrier transport in 2D halide perovskites, diffusion and dissociation of excitons are the key mechanisms determining the charge separation. Typical reported diffusion constants are 10<sup>−2</sup> to 10<sup>−1</sup> cm<sup>2</sup> s<sup>−1</sup> , listed in Table 12. An illustration summarizing typical exciton dynamics and transport is shown in Figure 14b. Photogenerated charge carriers typically go through thermalization and a subsequent cooling process, which typically occurs at the sub-picosecond to picosecond time scale. Exciton and charge dynamics dominate the energy transfer on the 1−100 ps time scale. Excitons can diffuse to the crystal surfaces over 100 ps, where dissociation to free carriers occurs. Rapid and efficient exciton dissociations have been reported in hot-cast RP films with _n_ > 2, where the exciton transport mechanisms are dominated by the diffusion to low-energy edge states leading to subsequent dissociation.<sup>273,278</sup> The transfer kinetics from excitons to the edge states is explicitly characterized using transient absorption spectroscopies with both front and back pump excitation (Figure 14c−f), which 

demonstrates the transport of excitons to the surface edge states via a diffusive process and the dissociation at surface electronic states driving the charge separation.<sup>273</sup> 

Here, we have listed the key factors and bottlenecks that greatly affect the charge carrier transport in 2D halide perovskites and methods to enhance the transport properties for device optimization. 

_3.2.4.1. Quantum-Well Structure._ The presence of quantum and dielectric confinement in QWs of 2D halide perovskites results in high exciton binding energies exceeding _k_ B _T_ , making the dissociation process of photogenerated excitations difficult. Besides, the presence of QWs reduces the carrier diffusion lengths and gives more probability of nonradiative recombination.<sup>274</sup> Overall, increasing the number of perovskite layers in each QW ( _n_ number) increases the fraction of free carriers, which favors the charge separation, however at the consequence of more trap density and less controlled phase purity.<sup>255,258,258</sup> For example, Herz et al. have studied the charge transport properties of the PEA2MAPb _n_ I3 _n_ +1 system (PEA = 2-phenylethylammonium) and demonstrated a maximum mobility with 50% PEA concentration, suggesting a balance between the reduced excitonic system (less ⟨ _n_ ⟩ value) and increasing density of trap states (higher ⟨ _n_ ⟩ value) (Figure 14g).<sup>255</sup> Gélvez-Rueda et al. demonstrated enhanced carrier mobility with increasing _n_ - value, consistent with lowering of hole effective mass from DFT calculations.<sup>258</sup> Researchers have demonstrated organic cations with high dielectric constants, which reduces the exciton binding energy and promotes the exciton dissociation and transfer of the carriers.<sup>309,310</sup> Besides the exciton transport in quantum wells, exciton dissociation to lower-energy states at the edge of perovskite layers has been investigated to be an efficient pathway for 2D halide perovskites with higher _n_ -value, where diffused excitons efficiently dissociate into free carriers leading to efficient transfer of charge carriers.<sup>273,276</sup> 

_3.2.4.2. Organic Cations._ While organic spacers have greatly limited the out-of-plane mobility of 2D halide perovskites, the carrier transport behavior can be improved by rational design of organic cations, including the ligand lengths, polarity, aromatic 

**9588** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

### **<u>Chemical Reviews</u>** 



Figure 14. Carrier transport of 2D perovskites. (a) Carrier mobility of (BA)2(MA) _n_ −1Pb _n_ I3 _n_ +1 at different temperatures. Reproduced with permission from ref 258. Copyright 2017 American Chemical Society. (b) Schematic illustration of exciton dynamics and transport for 2D halide perovskites. Reproduced with permission from ref 50. Copyright 2020 Springer Nature. (c) Schematic of TA spectroscopy with front and back pumping geometries. (d) Kinetics of the excitonic feature at the back pump geometry for various thicknesses, under excitation of 480 nm with 4 × 10<sup>11</sup> photons/ cm<sup>2.</sup> . (e) Corresponding rising kinetics of the edge state for different thicknesses. (f) Illustration of the charge distribution and transport at the back pump geometry. Excitons are created near the bottom of the glass slide and diffuse onto the surfaces where a high density of edge states is present, leading to efficient exciton dissociation at the surface. (c−f) Reproduced with permission from ref 273. Copyright 2020 American Chemical Society. (g) Charge carrier diffusion lengths as a function of PEA content for PEA-MA perovskites. Reproduced with permission from ref 255. Copyright 2016 American Chemical Society. (h) TRMC comparison of out-of-plane and in-plane transport for _n_ = 1 2D halide perovskites, showing enhanced transport with fluorination. Reproduced with permission from ref 260. Copyright 2019 American Chemical Society. (i) Schematic model showing potential wells in a stacked structure where carriers are prevented from escaping. (j) Thickness dependence of _J_ SC in a device, showing optimal thickness of 200∼300 nm. (i−j) Reproduced with permission from ref 287. Copyright 2018 Springer Nature. 

Table 12. Carrier Diffusion Length for 2D Halide Perovskites 

|Year|Compound|Exciton diffusion constant (cm<sup>2 </sup>s<sup>−1</sup>)|Approach|Ref|
|---|---|---|---|---|
|2020|(BA)2(MA)_n_−1Pb_n_I3_n_+1(_n_= 3)|0.18|Transient absorption with pumping front and back|273|
|2020|(PEA)2PbI4|0.192|Transient photoluminescence microscopy|274|
|2020|(BA)2(MA)_n_−1Pb_n_I3_n_+1(_n_= 1−5)|0.06−0.34|Transient absorption microscopy|275|



moiety, dielectric constant, and divalent spacers. Many studies have focused on exploring short-chain ligands which increased out-of-plane carrier transport.<sup>311,312</sup> For example, Ren et al. demonstrate 2-(methylthio)ethylammonium (MTEA) molecules that enable a sulfur−sulfur interaction at the organic tails, resulting in efficient charge transport.<sup>311</sup> Increasing the dipole moment of organic cations, such as fluorinated spacers, has been found to facilize the charge separation with a polarized crystal lattice, which in turn enhances the carrier transport, as displayed for one example in Figure 14h.<sup>260,313−315</sup> Additionally, studies on _n_ = 1 halide perovskite have demonstrated increase of out-ofplane conductivity by orders of magnitude, by using the 

aromatic organics (perylene and pyrene) with proper energy matching with the inorganic layers and enhanced intermolecular hydrogen bonding and supermolecular _π_ -stacking.<sup>316</sup> Additionally, 2D halide perovskites with Dion−Jacobson phase with a single layer of divalent organics have shortened the interlayer spacing and can lead to more efficient carrier transport than the RP phase.<sup>317</sup> Furthermore, it has been suggested that the distortion of the crystal lattice, including the Pb−I bond lengths and Pb−I−Pb bond angle, can greatly affect the charge transport properties in 2D halide perovskites.<sup>318</sup> Many researchers have proposed the introduction of various organic cations, which tailors the structural distortions and bond angle of Pb−I−Pb in 

**9589** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** **<u><mark>pubs.acs.org/CR</mark></u>** <mark>Review</mark> 



Figure 15. Solution processing of 2D halide perovskites. (a) Schematic showing the difference in charge transport for horizontal (left), vertical (middle), and mixed (right) orientations of a 2D halide perovskite film. Reproduced with permission from ref 328. Copyright 2021 Wiley-VCH. (b) Schematic showing how 2D halide perovskites nucleate from the air−liquid interface in contrast to 3D halide perovskites (right) and a GIWAXS pattern of an oriented 2D film demonstrating that despite this nucleation behavior, growing oriented 2D perovskite films is possible. Reproduced with permission from ref 332. Copyright 2018 Springer Nature. (c) GIWAXS patterns of room-temperature-cast (left) and hot-cast (middle) films of BA2MA3Pb4I13 showing formation of an oriented film with hot-casting, and a schematic representation of the (101) orientation with the (202) and (−11−1) planes labeled (right). Reproduced with permission from ref 257. Copyright 2016 Springer Nature. (d) GIWAXS patterns of PEA2MA4Pb5I16 perovskite films before (left) and after (middle) solvent vapor annealing treatment, and device PCE as a function of Hermans orientation factor (right). Reproduced with permission from ref 321. Copyright 2020 American Chemical Society. (e) (top) Schematic showing the phase purity and orientation of 2D halide perovskite films for the classic solution method (from precursor salts) and phase selective method (from single crystals). (bottom) GIWAXS patterns for the phase-pure crystal powder (left), phase-selective film (middle), and classically processed film (right). Reproduced with permission from ref 322. Copyright 2021 Wiley-VCH. 

different ways, resulting in overlap of the orbitals in favor of the electron transport.<sup>319,320</sup> 

_3.2.4.3. Quality Control of the Thin Film: Orientation, Thickness, and Phase Purity._ Besides the intrinsic factors of the 2D halide perovskite crystals, the thin film quality of these is the a curial factor of efficient charge collection. Researchers have explored a variety of methods to control the crystal vertical orientation, film thickness, and single-pure-phase distribution. Tsai et al. have developed a hot-casting technique to form highsingle-crystalline films with preferred vertical orientation.<sup>257</sup> Zhao et al. reported the solvent vapor deposition for deposition of a PEA2MA4Pb5I16 film resulting in enhanced carrier mobility.<sup>321</sup> Sidhik et al. have observed the presence of memory seeds in the crystal solvent and developed a new method with pure phase and high crystallinity.<sup>322</sup> Tsai et al. have demonstrated that optimizing the thin film thickness is curial in the design of 2D halide perovskite-based photovoltaics, where a significant drop in PCE has been revealed with film thickness beyond the depletion region (200−300 nm), limited by the exciton diffusion lengths.<sup>287</sup> As suggested in Figure 14i−j, thin absorbers result in inefficient photoabsorption despite high internal electrical field assisting the charge collection. Thick absorbers, on the other hand, lead to weak internal field to extract carriers from energy barriers. They have shown that the dominant photocurrent collection is related to the electric field 

assisted electron−hole pair separation and transport across potential barriers. 

**3.2.5. Urbach Energy in 2D Halide Perovskites.** Studies on single-phase 2D halide perovskites have reported typical Urbach energies ranging from 18 to 35 meV at room temperature,<sup>323−325</sup> which are comparable with the typical Urbach tails of 13−15 meV in the 3D halide perovskite MAPbI3 thin films.<sup>326,327</sup> These studies also suggest that the sharpness of the Urbach tail can be greatly impacted by careful material design, such as the homogeneity of the energy landscape, and better control of the phase purity and degree of structural disorder.<sup>324</sup> 

Besides the static contribution of Urbach energy resulting from intrinsic disorder, temperature-dependent Urbach energy tails are also reported in 2D halide perovskites, as a result of dynamic band energy disorder that is influenced by the vibrational states of the lattice.<sup>323</sup> For instance, Zhang et al. reported Urbach energies of PEAPbI4 ( _n_ = 1) film, which gives 20 meV at 80 K and 35 meV at room temperature. Analysis of the Urbach energies based on the Urbach−Martinessen formula reveals a coupling with optical phonons with average energy of 30 meV, consistent with the PL broadening as a function of temperature. 

**3.2.6. Solution Processability of 2D Halide Perovskites.** The prerequisite to fabricate a highly efficient halide perovskite solar cell is to obtain crystalline and compact thin 

**9590** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

films. The traditional solution processing of the halide perovskite film evolves from the precursor solution to the wet film and finally a solid film on annealing. The crystallization process of halide perovskites follows the classical nucleation and growth theories, which usually start from the precursor solution. It is very important to optimize this crystallization process to control the nucleation, and growth rate, hence obtaining a highquality film. As a result, an in-depth understanding of the fundamental mechanisms involved in the crystal nucleation and growth process is required for the optimization of the crystallization kinetics. 

In the 2D halide perovskites, the crystalline orientation is very important for efficient charge carrier transport toward the selective contacts. The anisotropy in the charge transport observed in the 2D halide perovskite thin films is not only related to the multiple quantum well nature but also to the inhomogeneous crystal orientation within the crystal structure.<sup>257</sup> There are generally three different types of orientations observed in the two-dimensional halide perovskites, namely, vertical, horizontal, and mixed orientation (Figure 15a).<sup>328</sup> In a parallel orientation, the inorganic layers are aligned parallel to the substrate, which is otherwise referred to as the in-plane orientation. 2D halide perovskites with _n_ < 3 are generally aligned parallel to the substrate due to its low formation energy, limiting the charge transport across the layers.<sup>328</sup> In the case of vertical orientation, the inorganic layers are aligned perpendicular to the substrate, referred to as the out-of-plane orientation, which is perfect for the charge carrier transport and extraction to the selective contacts. However, the mixed orientation corresponds to the crystallites aligned in random directions inside a thin film. The insulating nature of the organic layers leads to a preferred charge transport along the inorganic layers, while the transport along the spacer layer is hindered. It was reported that the parallel orientation of the 2D halide perovskite thin films can be converted to the mixed orientation by a sequential method, where some of the grains are vertically oriented which increases the performance of the 2D halide perovskite solar cells.<sup>329</sup> There are three important characteristics of a 2D halide perovskite thin film�the _n_ -layer thickness distribution, crystalline orientation, and crystallinity�which determine the optoelectronic properties. The huge diversity in precursor composition which includes different spacer cations, deposition technique, and use of different solvent compositions has complicated the crystallization mechanism in the 2D halide perovskite thin films. As a result, there is no generalized technique to fabricate homogeneous, oriented, and crystalline 2D halide perovskite thin films which calls for an in-depth understanding of the nucleation and the growth mechanism which is a guide for the progress of 2D halide perovskite solar cells or other devices. 

In contrast to the 3D halide perovskites, the crystallization of 2D halide perovskites starts at the air−liquid interface where 3Dlike inorganic octahedra are formed first, which results in a downward oriented growth as the solvent escapes (Figure 15b). Due to the poor solubility of lead iodide, there is an uncontrolled and rapid formation of the PbI2−solvent complexes at the air− liquid interface and within the liquid, which results in the formation of 2D halide perovskites with heterogeneous orientation. As a result, a better control of the nucleation process by controlling the growth and the number of PbI2− solvent complexes will help in controlling the orientation of the 2D halide perovskite thin films. Tremendous effort which includes solvent engineering, additive engineering, and hot- 

casting technique developed by our group has helped in attaining out-of-plane oriented 2D halide perovskite thin films from the air−liquid interface.<sup>257,330,331</sup> 

Chen et al. studied the crystallization process of 2D halide perovskite thin films, by starting from a wet solution to the solvent dried final film.<sup>332</sup> They proposed that the difference in solubility of lead iodide and different organic cations results in a heterogeneous distribution of the quantum well or _n_ -layer thicknesses within the 2D halide perovskite film. The PbI2− solvent complex forms first at the air−liquid interface. Following this, due to the difference in solubility and the steric hindrance of different organic cations, the smaller organic cation (MA or FA) goes and attaches first to the PbI2−solvent complex, forming 3D halide perovskite-like structures at the top surface which act as a template for the downward growth of the 2D halide perovskite crystals. The consumption of the small organic cation is accompanied by the coordination with the bulky organic cations resulting in the formation of larger quantum wells or _n_ -value thicknesses at the top air−liquid interface. Thenceforth, there is an increase in concentration of the larger organic spacer cation compared to the small cations promoting the formation of lower _n_ -phase 2D halide perovskites at the bottom of the film. Therefore, the final film comprises of a mixture of low _n_ -value, larger _n_ -value, and 3D-like halide perovskite crystal structures in a single thin film. Truhlar et al. proposed that the surface tension of the solution is the primary reason for the difference in the crystal growth rate on the surface of the liquid and the substrate.<sup>333</sup> Further, Li et al. proposed to slow down the crystallization process to increase the reaction time of the larger organic cations with the PbI2−solvent complexes, which has been shown to improve the quality of the 2D halide perovskite thin film with much ordered crystal orientation and reduced phase heterogeneity.<sup>334</sup> 

Hence, we can identify two important prerequisites to obtain a high-quality 2D halide perovskite thin film used for highefficiency halide perovskite solar cells: (1) homogenous distribution of the quantum well crystal structures, or _n_ -phases, and (2) ordered out-of-the-plane or vertical crystal lattice orientation. As a result, a tremendous amount of effort has been put forward to obtain these properties in a 2D halide perovskite thin film through different processing strategies. 

_3.2.6.1. Solution-Based Thin-Film Processing Strategies._ The most attractive part of the 3D halide perovskite materials is their easy solution processability to obtain high-quality thin films. However, the solution processed 2D halide perovskite thin film has issues concerning the phase heterogeneity and crystal orientation. Quintero-Bermudez et al. identified three different 2D halide perovskite thin film properties which can affect the performance of the PV devices:<sup>335</sup> (1) QW orientational disorder and the presence of horizontal wells, particularly of low- _n_ phases acting as the source of resistive losses in the device limiting the fill factor. (2) The varying distribution in the bandgap of the 2D halide perovskite films leads to photovoltage losses in the PV devices. The presence of low- _n_ phase is expected to increase the bandgap and hence the open-circuit voltage, but the open-circuit voltage is identical for most 2D halide perovskite devices. This voltage loss can be attributed to the polydispersity of the quantum well structures. Also, the presence of these low- _n_ phases creates traps for charge carriers due to the type-II band alignment of thin wells, an effect which also leads to the losses in short-circuit current density. (3) The presence of low- _n_ phases reduces the probability of generating charge carriers due to the decreased absorbance of films, the reason for 

**9591** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

which might be the reduced density of the halide perovskite in the thin films when compared to the proportion of organic spacers. This issue can be resolved by increasing the thickness of the film and reducing the length of the organic spacers. As a result, it becomes imperative to understand and improve the fabrication methods of the 2D halide perovskite thin films. Several works have shown that retarding the crystal growth, rapid nucleation, or seed-assisted growth are conducive to obtain a high-quality 2D halide perovskite thin film. The methods that are generally used for fabricating the 2D halide perovskite films are the hot-casting, vacuum, antisolvent, and post-annealing methods, etc. 

Hot-Casting Method. The room-temperature processing of 2D halide perovskite thin films results in a random orientation, whereas the hot-casting approach where the hot precursor solution is spin-cast on a hot substrate has realized the dominant vertical orientation of the 2D halide perovskite crystals (Figure 15c). In 2016, Tsai et al. fabricated a high-quality 2D BA2MA3Pb4I13 ( _n_ = 4) halide perovskite film with singlecrystal-like characteristics using the hot-casting approach, where the halide perovskite solution kept at 70 °C was immediately spin-coated on a hot substrate (150 °C) to obtain a preferential out-of-plane orientation.<sup>257</sup> They utilized the grazing-incidence wide-angle scattering (GIWAXS) measurements to explore the crystallinity and orientation of the as-grown films. Sharp Bragg spots were obtained for films fabricated using the hot-casting approach, indicating high crystallinity and better orientation, whereas the film fabricated by a normal spin-coating process showed wide concentric rings indicative of lack of a preferential orientation and inferior crystallinity. Currently, the hot-casting approach is widely used for various 2D halide perovskite materials. Looking into the mechanism, the preheated substrate accelerates the nucleation process from the intermediate sol−gel complex to the 2D halide perovskite phase, which initiates from the solution−substrate interface instead of the air−liquid interface. Some of the concerns regarding this technique stem from the experimental repeatability and include difficulty in precise control over the temperature, upscaling of the technique, and sudden variation in the temperature leading to undesirable strain and cracks arising due to the difference in the thermal expansion coefficient of the glass and the halide perovskite film. 

Postannealing Strategy. The postannealing technique was initially used in the 3D halide perovskite films to reduce the number of grain boundaries by increasing the grain size achieved by Ostwald ripening. However, this strategy has been shown to modify the phase distribution and crystalline orientation of the 2D halide perovskite thin films to attain more order in the crystal structure. Zheng et al. demonstrated a slow post-annealing (SPA) technique where the fabricated (BA)2(MA)3Pb4I13 RP halide perovskite film was annealed at a temperature of 60 °C for 2.5 days. They observed a reorganization in the phase distribution of the 2D halide perovskite films achieving a gradual increase in the QW thickness in the perpendicular direction which helps in efficient charge carrier extraction and reduced surface recombination. The devices fabricated by the SPA technique achieved a power conversion efficiency of 17.3% with enhanced shelf life stability.<sup>336</sup> 

Thenceforth, some modifications were made to the postannealing treatment where the annealing process was carried out in a solvent-vapor environment, which will basically plasticize the thin film, and lead to the reorientation of the crystallite domains (Figure 15d). Loo et al. used isopropanol as the processing solvent, where the 2D PEA2MA4Pb5I16 RP halide 

perovskite film was annealed for several hours to attain the vertical orientation without compromising the phase of the obtained film. A similar strategy was utilized in a DJ-based halide perovskite (BDA)(Cs0.1FA0.9)4Pb5I16 (BDA = 1,4-butanediammonium), which provided an efficiency of 18.2%.<sup>321</sup> In addition to the modification observed in the crystalline orientation, the solvent vapor also helps in improving the crystalline quality of the 2D halide perovskite films not only on the surface but also within the bulk depending on the penetration depth of the solvent vapor, which is directly proportional to the amount of time used for annealing. Despite all of these advantages, there are some major concerns that the extended annealing times would affect the compositional stability of the 2D halide perovskite film due to the volatility of the organic components resulting in the formation of ionic defects within the bulk and on the surface, deteriorating the solar cell performance and the stability of the device. 

Antisolvent Technique. The antisolvent approach evolved from the field of 3D halide perovskites was used for growing highly crystalline, uniform, and compact films by selectively washing away the high-boiling-point solvent to obtain uniform crystallization.<sup>189</sup> The most common solvents used for fabricating the halide perovskite films include the polar protic solvents, dimethylformamide, dimethyl sulfoxide, _N_ -methylpyrrolidone, and _γ_ -butyrolactone, all of which have high boiling points greater than 150 °C. As a result, uniform evaporation of these solvents at the lower temperature of 100 °C (used for fabricating the halide perovskite thin films) is difficult, which leads to a retarded nucleation and random crystallization forming a nonuniform and less crystalline film. To counter this, the researchers developed an antisolvent process to produce high-quality films. The antisolvents used include nonpolar solvents like diethyl ether, chlorobenzene, anisole, toluene, etc., which have a huge polarity difference compared to the polar protic solvents used for the film fabrication. Due to this difference, these antisolvents get mixed with the main solvent without interacting with the solute, hence rapidly washing away the solvent, forming a supersaturated precursor mix which acts as a driving force for the crystallization process. The antisolvent approach was mainly used in the Dion−Jacobson 2D halide perovskites, considering its close similarity with the 3D halide perovskites, which show a stronger Lewis acid−base interaction between the main solvent and the halide perovskites.<sup>51,337</sup> Xie et al. showed that the introduction of the antisolvent chlorobenzene in the precursor solution improves the morphology and the crystalline quality of thin films.<sup>338</sup> They found that this is achieved by accelerating the nucleation of 2D (BA)2(MA)3Pb4I13 halide perovskite leading to a compact, pinhole-free, and highly crystalline film. However, the major drawback is the experimental reproducibility, which requires a precise control in the location at which the antisolvent is dropped, the time of antisolvent dropping, the amount of antisolvent used, and the height from the substrate from where the antisolvent is dropped. Any slight variation from these optimized conditions has serious impacts on the final crystalline quality and the morphology of the thin film obtained. Hence, the upscaling of the antisolvent process turns out to be difficult. In addition, the amount of antisolvent used is large in quantity, which would increase the fabrication cost, and also most of these antisolvents are toxic organic compounds which happen to be harmful for the environment and difficult to handle for human beings. Despite of all these shortcomings, the antisolvent 

**9592** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 16. Ion migration in 2D perovskites. (a) Temperature-dependent conductivity of single crystals of MAPbI3 (left) and BA2MA2Pb3I10 (right) showing high-temperature transition to ionic-dominated conductivity in 3D halide perovskites but no such ionic conductivity regime in 2D halide perovskites. Reproduced with permission from ref 341. Copyright 2018 American Chemical Society. (b) Activation energy for iodine ion diffusion across a mechanically paired PEA2MA _n_ −1Pb _n_ I3 _n_ +1-PEA2MA _n_ −1Pb _n_ Br3 _n_ +1 interface for varying ⟨ _n_ ⟩-value. _E_ a is determined by the rate of change in the PEA2MA _n_ −1Pb _n_ Br3 _n_ +1 film’s absorption spectrum. The _E_ a for 3D _n_ = ∞ was taken with permission from ref 346. Copyright 2020 American Chemical Society. Reproduced with permission from ref 343. Copyright 2019 American Chemical Society. (c) Absorption spectrum over time for a film of HA2MAPb2I7 (HA = hexylammonium) mechanically paired with a film of HA2MAPb2Br7 at 100 °C (left) showing a bandgap shift with Br diffusion, and calculated activation energy for Br ion diffusion for BA vs HA A′-site cation (right) found by repeating this experiment at a variety of temperatures and fitting the rate of excitonic peak shift. Reproduced with permission from ref 345. Copyright 2020 American Chemical Society. (d) Sheet resistance of single crystals of PEA2MA _n_ −1Pb _n_ I3 _n_ +1 ( _n_ = 1−3) using the four-point probe method shown in the inset. The thickness _d_ is <10 _μ_ m for 2D samples and 200 _μ_ m for 3D samples. The high sheet resistance for 2D samples suggests a low intrinsic carrier concentration. Reproduced with permission from ref 302. Copyright 2017 American Chemical Society. 

approach still continues to be a convenient and significant method for use in the lab scale. 

Phase-Selective Strategy. A key challenge in the field of 2D halide perovskites is to develop a technique to synthesize phasepure 2D halide perovskite, which is dominantly comprised of single-QW thicknesses. The classical approaches, which we discussed previously, form halide perovskite layer thickness intermediate between the 2D halide perovskites _n_ = 1 and the 3D halide perovskites. They usually go through an intermediate sol gel complex between the precursor and the solvent which is the main reason for the heterogeneous phase distribution in 2D halide perovskite thin films. Liang et al. used a molten salt _n_ - butylammonium acetate, instead of the traditional spacer salt _n_ - butylammonium iodide, to obtain a single-QW thickness of BA2MA _n_ −1Pb _n_ I3 _n_ +1 ( _n_ = 1−5).<sup>339</sup> The _n_ -butylammonium acetate forms a gel-like intermediate phase that is uniformly distributed throughout the halide perovskite framework, allowing phase-pure quantum well films to be produced with vertically aligned grains. These quantum wells have a single-well width and are highly efficient, achieving a power conversion efficiency of 16.25% and an open voltage of 1.31 V. Furthermore, the solar cells show excellent stability, with less than 10% efficiency degradation after exposure to high humidity, high temperature, or continuous light for extended periods of time. Further, Sidhik et al. reported a phase-selective synthesis method which involves a precrystallization step of 2D halide perovskite crystalline powders followed by single-step solution 

processing, to produce 2D halide perovskite thin films principally formed from perovskite layers with a single-QW layer thickness (or _n_ -value), with high crystallinity and desired orientation suitable for fabricating optoelectronic devices (Figure 15e).<sup>322</sup> Comprehensive characterization revealed the exact nature of 2D halide perovskite film formation where the growth is dominated by the nucleation of 100−200 nm homogeneous _n-_ value seeds, which have characteristics similar to the parent crystal dissolved. The phase-selective method showed solar cells with an efficiency of 17.1% with a high opencircuit voltage of 1.22 V and an enhanced operational stability of T98 > 800 h under continuous illumination without any external heat management. 

**3.2.7. Ionic Mobility in 2D Halide Perovskites and Potential for Electrical Doping.** 2D halide perovskites show reduced ionic mobility compared to 3D halide perovskites. In the out-of-plane direction this can intuitively be explained by the A′ cation acting as an energetic barrier to ion hopping.<sup>57</sup> What’s more interesting is that in-plane ionic mobility is suppressed as well, apparently as a result of a higher vacancy formation energy for VI and VMA and therefore a lower vacancy concentration.<sup>340−342</sup> Several studies have compared the temperature dependence of conductivity in 3D and 2D halide perovskites and found that while 3D halide perovskites show a distinct transition from electronic to ionic-dominated charge transport at high temperatures, 2D halide perovskite conductivity remains electronic across the temperature region.<sup>340,341</sup> This is true 

**9593** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 17. Ferroelectricity in 2D perovskite BZA2PbCl4 (BZA = benzylammonium). (a) Structure of BZA2PbCl4 below (left) and above (right) its Curie temperature of 438 K, showing preferential rotational alignment of the BZA cations at low temperature, giving rise to a noncentrosymmetric crystal structure. (b) Polarization−electric field (P-E) hysteresis loops for BZA2PbCl4, showing a saturation polarization of ∼13 _μ_ C cm<sup>−2</sup> , among the highest values reported for a molecular ferroelectric. (c) Temperature-dependence of BZA2PbCl4 polarization as determined by pyroelectric response, showing the paraelectric−ferroelectric phase transition at 438 K. (a−c) Reproduced with permission from ref 347. Copyright 2015 Springer Nature. 

both in dark conditions and under 1-sun illumination (Figure 16a). 

As should be expected, halide mobility has been shown to increase with ⟨ _n_ ⟩-value.<sup>343</sup> Figure 16b shows the activation energy for iodine ion diffusion across a mechanically paired PEA2MA _n_ −1Pb _n_ I3 _n_ +1−PEA2MA _n_ −1Pb _n_ Br3 _n_ +1 interface for varying ⟨ _n_ ⟩-value. PEA n1 films show an _E_ a of 71.5 kJ/mol compared to 66.9 kJ/mol for ⟨ _n_ ⟩≥ 6 and 57.8 kJ/mol for ⟨ _n_ ⟩≥ 10. The spacer cation also influences ionic mobility, with bulky _π_ - conjugated cations suppressing mobility compared to linear cations and longer-chain linear cations suppressing mobility compared to shorter ones.<sup>344,345</sup> Figure 16c shows the rate of ion diffusion across a mechanically paired A′2MAPb2I7− A′2MAPb2Br7 interface for A′ = BA or HA (hexylammonium), as measured by the shift in excitonic absorption peak for the iodide film. HA, with a carbon backbone two units longer than BA, shows an _E_ a 14 kJ/mol greater.<sup>345</sup> 

Another result of 2D halide perovskites’ higher defect formation energy is their suppressed self-doping compared to 3D halide perovskites. The self-doping concentration in single crystals of PEA2MA _n_ −1Pb _n_ I3 _n_ +1 for _n_ = 1−3 was found to be more than 3 orders of magnitude lower than in MAPbI3,<sup>302</sup> as seen from sheet resistance measurements (Figure 16d). Low selfdoping concentrations could suppress the screening of extrinsic electronic dopants seen in 3D halide perovskites.<sup>202</sup> Combined with 2D halide perovskites’ suppressed ion migration, this suggests that electronically doped homojunctions or heterojunctions of 2D halide perovskites may be more feasible than with 3D halide perovskites. More research needs to be done on the performance and stability of doped 2D-2D and 2D-3D junctions, which could in theory be used to realize 2D halide perovskite transport layers in devices. 

### **3.2.8. Bulk Ferroelectricity in 2D Halide Perovskites.** 

Compared to 3D halide perovskites, ferroelectricity in 2D halide perovskites is much more common and moreover can be engineered to an extent through the choice of A′-site and A-site cations. A′-site cations that are reorientable with a dipole moment perpendicular to their rotation axis (i.e., the stacking axis) can in some cases form polarization domains of the same orientation, exhibiting an order−disorder ferroelectric−paraelectric phase transition, although this is not guaranteed. For example, BZA2PbCl4 (BZA = benzylammonium) exhibits a ferroelectric phase transition through spacer cation alignment,<sup>347</sup> but BZAPbI4 does not.<sup>348</sup> The 2D structure also permits larger A-site cations ( _t_ > 1) and a greater degree of B-site distortion, which can unlock a displacive ferroelectric effect through the preferential orientation of the B-site ns<sup>2</sup> electron pair and off-center displacement of the B-site cation within its octahedral cage.<sup>148</sup> This effect can explain the ferroelectric and antiferroelectric phases shown in 2D halide perovskites with oversized A-site cations such as BA2EA2Pb3I10 (EA = ethylammonium)<sup>77</sup> and EA4Pb3I10349 and may explain why BZAPbI4 is not ferroelectric while BZA2PbCl4 is.<sup>148</sup> 

The ideal (undistorted) reference RP and DJ structures for bulk 2D halide perovskites correspond to the D4h point group.<sup>50,100</sup> High-temperature centrosymmetric crystal phases of 2D hybrid halide perovskites further exhibit an in-plane cell doubling via antiferrodistorsive tilts of the octahedra. Additional polar lattice distortions in relation with polar space groups can be very often proposed depending on the number of Bragg reflections considered in the refinement of the crystallographic structure. But as pointed out by some authors, such assignment can be ambiguous because of the dynamic disorder present in most of the halide perovskites.<sup>52</sup> 

**9594** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 18. Photodoping and light-induced lattice dynamics in 2D halide perovskites. (a) Static (black) and transient (red) XRD patterns of RP 2D halide perovskites BAPbI4 at 1 ns and 22 _μ_ J/cm<sup>2</sup> . The positive and negative differential signals in the transient pattern indicate peak shifting toward lower _Q_ . This behavior is attributed to the increase of out-of-plane Pb−I−Pb bond angles, which gives rise to red shifting and narrowing of PL over time. (b) Demonstration of in-plane and out-of-plane Bragg peaks of interest. (a−b) Reproduced with permission from ref 369. Copyright 2022 WileyVCH. (c) Time traces of Bragg peaks (400) (530) in 2D halide perovskites (4AMP)(MA)Pb2I7 single crystals, revealing in-plane lattice dynamics with light excitation. (d) Crystal structure of (4AMP)(MA)Pb2I7 viewed at the [110] and [001] directions, showing intrinsic in-plane octahedral rotations. (e) Schematic illustration of the lattice dynamics in DJ 2D halide perovskites, showing light-induced reduction of octahedral tilt and thermally activated atomic displacement from the Debye−Waller effect. (c−e) Reproduced with permission from ref 370. Copyright 2023 Springer Nature. (f) Schematic illustration of in situ GIWAXS experiment and powder diffraction pattern of 2D halide perovskites. (g) Angular-integrated diffraction spectra before and after sun light illumination, and after sample resting in the dark. (h) Overview of the light-induced lattice contraction in 2D halide perovskites. (f−h) Reproduced with permission from ref 370. Copyright 2022 Springer Nature. 

A better way to gauge the existence of a ferroelectric phase is to rely on experimental techniques dedicated to the direct characterization of the electrical polarization and to observe a phase transition from a ferroelectric to a paraelectric phase at a well-defined Curie temperature, and a polarization hysteresis. An example is provided by the 2D halide perovskite BZA2PbCl4, which crystallizes in a _Cmca_ centrosymmetric phase at high temperature and undergoes a ferroelectric phase transition at _T_ = 438 K to a _Cmc_ 21 noncentrosymmetric structure<sup>347,350</sup> (Figure 17). It shall be pointed out that in most cases reported so far, the polar axis is perpendicular to the stacking, which leads to an incomplete Rashba effect with a partial in-plane spinor splitting.<sup>351</sup> In recent years, a number of well-documented examples have been reported, mostly involving 2D bromide halide perovskites. Interestingly, ferroelectricity can be sometimes observed for _n_ = 2 or _n_ = 3 materials,<sup>73,78,352−354</sup> while the _n_ = 1 phase remains nonpolar.<sup>285</sup> 

Another type of lattice distortion can be induced by using chiral molecules in the barrier. These distortions are not necessarily related to a loss of centrosymmetry and a polar lattice.<sup>355</sup> Transfer of chirality to the halide perovskite lattice is expected, with a modification of the electronic properties close to the bandgap and various specific optoelectronic properties, such as circular dichroism or circular polarized light emission.<sup>356−362</sup> 

**3.2.9. Photodoping of 2D Halide Perovskites/LightInduced Lattice Dynamics.** In semiconductors, photogenerated carriers release their energy to the lattice, which eventually loses their energy as heat via lattice vibrations and, therefore, perturbs the crystal lattice. For 2D halide perovskites, despite intensive studies on electron−phonon coupling and carrier dynamics, only a few studies have been focused directly on the lattice dynamics. This is partially due to the structural complexity in 2D halide perovskites. Studies based on ultrafast spectroscopy and diffraction techniques have revealed a variety of lattice dynamics, such as polaronic carrier−lattice coupling,<sup>363</sup> exciton-polarons,<sup>364,365</sup> coherent optical and acoustic phonons,<sup>363,366−368</sup> and specific movements involving octahedral twisting and tilt. 

_3.2.9.1. Polaronic Lattice Response._ Thouin et al. have observed polaronic character of excitons in _n_ = 1 PEA 2D halide perovskites, where the exciton states are coherently coupled at low temperatures ( _T_ < 100 K) and low excitation densities to low-frequency optical vibrational modes. These coherent vibrational modes involve motions of the lead iodide layers (octahedral tilt and twisting), leading to specific lattice reorganizations.<sup>363</sup> Kandada and Silva attribute their observations to the formation of “exciton polaron” quasiparticles to describe the exciton−lattice interaction dynamics via polaronic effects, in 2D halide perovskites.<sup>364</sup> 

**9595** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 



Figure 19. State-of-the-art 2D perovskite solar cells. (a) Record-efficiency “quasi-2D” perovskite device _J_ − _V_ curve with 22.3% PCE. Inset shows device architecture: FTO−TiO2−(GA)(MA)5Pb5I16 (⟨ _n_ ⟩≥ 5)−ImI passivation layer−Spiro-OMeTAD−Au. (b) Low-angle XRD of a ⟨ _n_ ⟩≥ 5 film showing mixed-phase _n_ = 3, _n_ = 1, and 3D with and without ImI additive. (c) Absorption spectra of ⟨ _n_ ⟩≥ 3, 4, 5 films showing lower- _n_ phases for ⟨ _n_ ⟩≥ 3 and large 3D absorption edges for all samples. (a−c) Reproduced with permission from ref 372. Copyright 2022 American Chemical Society. (d) Recordefficiency “phase-pure” 2D perovskite device _J_ − _V_ curve with 18.3% PCE after 12 min of light soaking. Inset shows device architecture: ITO−PEDOT− PSS−(4AMP)(MA)2Pb3I10 ( _n_ = 3)−PCBM−Al. (e) GIWAXS pattern of _n_ = 3 device film showing diffraction peaks of 4AMP _n_ = 3 including the lowangle (300) peak at _q_ ∼ 0.8, with no other observable phases. Other peaks below _q_ = 2 which can be definitively assigned to n3 are circled in white. 3D diffraction peaks overlap with n3 peaks at _q_ ∼ 1 and _q_ ∼ 2, and so those peaks cannot definitively be assigned to n3. (d−e) Reproduced with permission from ref 371. Copyright 2022 Springer Nature. 

_3.2.9.2. Coherent Coupling to Lattice Vibrations._ Similarly, Guo et al. reported oscillation of electronic bandgaps induced by coherent lattice vibrations via optical phonons by nonresonance infrared pumping, which is attributed to the antiphase octahedral rotations at ultrafast time scales.<sup>366</sup> Quan et al. studied the vibration relaxation in bromide 2D halide perovskites, which suggests dynamic lattice disorder via phonon dephasing. Such vibrational relaxation rate and their temperature dependence can be tailored by the choice of flexible alkyl or aromatic spacer cations.<sup>368</sup> 

_3.2.9.3. Relaxation of Lattice Distortion via Octahedral Tilt._ Cuthriell et al. studied the nonequilibrium lattice response of BA and PEA _n_ = 1 halide perovskites and reveal a suppressing line width narrowing in both transient X-rays and photoluminescent spectra at ∼1 ns time scales, suggesting a transient ordering of distorted octahedra (Figure 18 a,b).<sup>369</sup> Interestingly, Zhang et al. has reported lattice dynamics beyond the Mott density and revealed an ultrafast relaxation of the lattice distortion at very short time, via reduced in-lane octahedral tilting (relaxation of antiferro-distortions) in DJ-type 2D halide perovskites (Figure 18 c−e).<sup>370</sup> Such strong carrier−lattice interactions are initiated by dense electron−hole plasma beyond the Mott density. Furthermore, such a response is observed to be absent in RPtype 2D halide perovskites, where less in-plane distortion is present in the intrinsic structure. These behaviors suggest the interactions between the carrier gas and lattice are tailored by the rigidity of the spacer cations and the intrinsic distortion of the crystal structure. 

_3.2.9.4. Long-Time Dynamics: Lattice Response upon Light Soaking._ Apart from the role of octahedral tilting in the shorttime light-induced lattice dynamics, the lattice parameter 

contractions have also been reported at long time scale. Specifically, Li et al. investigated the light-soaking effect of 2D halide perovskites and observed interlayer contraction in the inplane and out-of-plane directions (Figure 18f−h), which leads to an increase in power conversion efficiency in DJ-based 2Dhalide perovskite solar cells.<sup>371</sup> The work showed that by illuminating solar light onto a 4AMP-based DJ phase 2D halide perovskite (4AMP = 4-(aminomethyl)piperidinium), we can modulate the pre-existing interlayer iodine---iodine interactions and increase carrier mobilities in the out-of-plane (across the organic spacer cation) direction by a factor of 3. We further find that this enhancement of the transport properties only occurs in 2D halide perovskite that have compact spacer cations such as 4AMP and GA molecules and where the stacking of the inorganic octahedra slabs is directly on top of each other in either one or both planar directions. Similar experimental and theoretical studies have also indicated that the DJ phase halide perovskite exhibits longer carrier lifetime and higher transport mobilities compared to the “softer” RP phase. 

**3.2.10. Best-Performing 2D Halide Perovskite Devices.** Partially because of its higher exciton binding energy and reduced carrier mobility and partially because of a diminished focus in the halide perovskite community on 2D halide perovskite devices, 2D solar cell efficiency trails behind that of 3D. Exciton binding energy is reduced, and carrier mobility is increased as a 2D halide perovskite’s _n_ -value increases, and as a result increasing the _n_ -value of 2D halide perovskites is a major goal in the halide perovskite community. As of February 2023 the highest-efficiency low-⟨ _n_ ⟩-value “quasi-2D” halide perovskite solar cell used an ACI absorber layer of GAMA5Pb5I16 (GA < _n_ ≥ 5) in an n-i-p architecture with a TiO2 ETL and a Spiro- 

**9596** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

### **<u>Chemical Reviews</u>** 



Figure 20. Stability of 3D perovskites. (a) Schematic of MAPbI3 photooxidation. Top left: O2 adsorbs at an iodide vacancy. Top right: Illumination generates e<sup>−</sup> −h<sup>+</sup> pairs. Bottom left: O2 takes a photoelectron to form O2− superoxide radical. Bottom right: O2− reacts with MAPbI3 to form PbI2, I2, MA, and H2O. Reproduced with permission from ref 379. Copyright 2017 Springer Nature. (b) Calculated formation energy difference between _α_ - phase and FAPbI3/CsPbI3 _δ_ -phases in (FA1− _x_ Cs _x_ )PbI3 as a function of _x_ (top horizontal axis) or tolerance factor (bottom horizontal axis). The crossing point for the two curves at _x_ ∼ 0.15 gives the concentration of minimum energy difference for either _δ_ -phase and is predicted to be the most stable composition. Reproduced with permission from ref 10. Copyright 2015 American Chemical Society. (c) PL spectra of MAPb(I0.5Br0.5)3 (left) and FA0.83Cs0.17Pb(Br0.4I0.6)3 (right) measured over time with constant light exposure. Both perovskites’ emission peaks redshift as iodide and bromide phase-segregate and charges are shuttled into low-bandgap iodide regions. The process is slower for the FA-Cs film because of the larger barrier to halide diffusion. Reproduced with permission from ref 406. Copyright 2021 American Chemical Society. (d) Normalized PCE for a MAPbI3 solar cell held at various biases in dark conditions. Applied voltages over 1 V lead to rapid degradation of device performance, suggesting that photodegradation at _V_ OC is partially due to the built-in field. Reproduced with permission from ref 414. Copyright 2016 American Chemical Society. (e) PL spectra of MASnI3 (top) and FASnI3 (bottom) films over 60 min in air, demonstrating the suppression of Sn<sup>4+</sup> formation in FASnI3. PL intensity falls by ∼40% in 

**9597** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

#### Figure 20. continued 

MASnI3 and by ∼10% in FASnI3 as Sn<sup>4+</sup> is created and nonradiative recombination increases. Reproduced with permission from ref 433. Copyright 2016 Wiley-VCH. (f) PL imaging before and after bleaching APbBr3 single crystals (A = MA, FA, Cs) with a two-photon microscope at 8% (top), 13% (middle), and 18% (bottom) laser power, and recovery over 12 h in dark. 0s marks the time immediately after 100 bleaching iterations. The degrading beam is focused 50 _μ_ m within the crystal bulk. All crystals recover partially at all three laser intensities, but the rate of healing decreases at higher intensities. FAPbI3 shows the fastest recovery and CsPbI3 the slowest recovery in all cases. Reproduced with permission from ref 452. Copyright 2018 Wiley-VCH. 

OMeTAD HTL and achieved an excellent PCE of 22.3%.<sup>372</sup> The _J_ − _V_ curve and device architecture for this cell are shown in Figure 19a. However, treating such devices as quasi-2D may be inaccurate, as the diffraction pattern (Figure 19b) and absorption spectrum (Figure 19c) of the GA < _n_ ≥ 5 film in fact showed a mixture of 3D MAPbI3 and 2D GA _n_ = 1−3. The label of “quasi-2D” for mixed 3D-2D systems grown using the stoichiometric ratio of precursor salts for a certain _n_ -value may not accurately capture the materials properties of such systems, which have complex microstructures and significant regions of majority-3D phase. The language used to describe phase-pure ( _n_ ) and mixed-phase (⟨ _n_ ⟩) systems is often interchangeable in the perovskite community, but their materials and device properties are vastly different, suggesting an urgent need to refine the language and make the distinction clear as phasepurity becomes more realizable in 2D films. As will be discussed below, both pure-phase and mixed-phase systems show great promise for high-performance halide perovskite devices, and both deserve significant further exploration. 

One reason for the prevalence of mixed 2D or mixed 2D-3D in reports of 2D halide perovskite films and devices is the difficulty of depositing phase-pure 2D films, as discussed above. As a result, relatively few papers exist which demonstrate phase-pure high- _n_ 2D devices. The best-performing solar cell using a majority-”phase-pure” 2D halide perovskite absorber was reported by our group in 2022 at 18.3%.<sup>371</sup> High-phase-purity (4AMP)MA2Pb3I10 (DJ _n_ = 3) was used as the absorber layer of an inverted solar cell with a PEDOT:PSS HTL, a PCBM ETL, and an Al top contact. The device efficiency was seen to improve by 2.7% after 10 min of light exposure, which was attributed to light-induced interlayer contraction reducing the height and width of the organic layer’s potential barrier. Figure 19d shows the _J_ − _V_ curve and device architecture for the phase-pure DJ cell. The GIWAXS pattern for the DJ film in Figure 19e confirms the phase-purity, with no 2D peaks besides the n3 peaks observable. As these results suggest, the potential barrier of the organic layer is a persistent hindrance to the realization of high-efficiency 2D devices. 

### **4. STABILITY OF 3D AND 2D HALIDE PEROVSKITES** 

### **4.1. Issues with 3D Halide Perovskite Stability** 

While the device performance of 3D halide perovskites is comparable to that of inorganic semiconductors, their stability is far worse. 3D halide perovskites are vulnerable to degradation via O2, water, elevated temperatures, bias, and light, as well as reactions with other layers in a device stack. The A-, B-, and X- sites in 3D halide perovskites are all low-valence, high-radius ions, giving the crystal low lattice energy and higher instability against environmental stressors.<sup>373</sup> Ammonium groups in A-site cations are especially vulnerable to attack by reactive molecules such as O2 and H2O.<sup>374</sup> Unfortunately, the stability of 3D halide perovskites does not share the same tolerance to defects as its device performance does; there is evidence that halide 

perovskite degradation is mediated by defects, which need to be almost entirely passivated to stabilize devices.<sup>142</sup> 

The degradation route of 3D halide perovskites changes depending on their chemistry; in particular, different A-sites give rise to distinct degradation pathways depending on the relative contributions of phase instability and chemical instability.<sup>375,376</sup> However, both MAPbI3, which is found in a tetragonal perovskite black phase at RT but is chemically unstable, and FAPbI3 and CsPbI3, which are more chemically stable but show structural reconstructions toward nonperovskite phases, degrade too quickly to be useful in a commercial device. Alloying the A-site can improve the chemical stability significantly and preserve a perovskite lattice, as will be discussed below. It has further merits, since the compositions of these alloys can be tuned to stabilize a cubic perovskite phase at RT. MAPbI3 is indeed usually found in a perovskite tetragonal phase at RT, with a perovskite tetragonal to cubic structural instability slightly above RT. Domain walls between tetragonal domains and crystal twinning are among the possible additional consequences in the tetragonal phase.<sup>376</sup> Moreover, CsPbI3 has an optical bandgap too high for PV in its high-temperature cubic perovskite black phase. But the bandgap is not reduced but increased in the metastable black phase at RT, due to orthorhombic lattice distortions.<sup>375</sup> 

**4.1.1. Chemical Instability of MAPbI3.** Degradation of MAPbI3 proceeds through the deprotonation of the MA cation, which can then leave the crystal as a gas.<sup>374,377,378</sup> In air under light illumination, MAPbI3 degrades via photooxidation, which begins with the adsorption and diffusion of O2 molecules through VI-sites as shown in Figure 20a.<sup>379</sup> Photooxidation is a common degradation mechanism for all solar cell materials,<sup>380</sup> but it results in much more rapid degradation in halide perovskites than in Si. Particularly in the case of halide perovskites, light illumination causes lattice distortions which increase the concentration of iodide vacancies and the ionic mobility, increasing the adsorption and diffusion rates for O2.<sup>200,381</sup> It has also been suggested that I<sup>−</sup> in the lattice can reduce its radius by oxidizing to neutral iodine in the presence of photogenerated holes, increasing [VI].<sup>381</sup> Adsorbed O2 creates a state near the CBM which can capture a photoelectron, forming the free radical O<sup>−</sup> 2<sup>.Thisreactivespeciesthentakesaproton</sup> from MA, destroying the perovskite structure in the process:<sup>374,377,380</sup> 



<!-- Start of picture text -->
O2 + e O2 + 4MAPbI3<br>4MA + 4PbI2 + 2I2 + 2H2O<br><!-- End of picture text -->

In the absence of O2, a less reactive electron acceptor such as CO2 can attack the halide perovskite via the same route.<sup>377</sup> In a dark O2-rich environment, MAPbI3 remains metastable since oxygen is unable to penetrate past the surface of the film.<sup>382</sup> Likewise, if charges are extracted quickly from the halide perovskite, e.g., during solar cell operation, photooxidation is suppressed compared to that at _V_ OC.<sup>383</sup> 

**9598** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

Heat also has a degrading effect on MAPbI3 halide perovskites. After holding MAPbI3 at 100 °C for 20 min in vacuum, Kim et al. observed the creation of an intermediate degradation phase associated with the decomposition of MAPbI3 into CH3I, NH3, and PbI2.<sup>384</sup> This phase was also seen at 80 °C after >1 h. Other studies have similarly found elevated temperatures as low as 85 °C can also cause the MA<sup>+</sup> cation to deprotonate or decompose into NH3 and CH3I.<sup>385,386</sup> 

MAPbI3 is very sensitive to humidity, as even a small concentration of H2O molecules can accelerate the photooxidation process. Superoxide radicals can react with complexed H2O to form hydroxide (OH<sup>−</sup> ), which deprotonates MA more aggressively than O2−.374 This changes the rate-limiting reaction of the degradation process and consequently accelerates the degradation kinetics significantly. As H2O is one degradation product of anhydrous photooxidation, it can build up in a film even in a dry environment and accelerate degradation after enough has accumulated.<sup>382</sup> In humid environments, H2O will also complex with MAPbI3, forming a monohydrate phase MAPbI3·H2O of edge-sharing PbI6 octahedra<sup>387</sup> or a dihydrate phase MA4PbI6·2H2O of disconnected octahedra along with PbI2.<sup>388</sup> The hydration reaction is reversible if reacted species can be prevented from leaving the crystal, but because the hydrate destroys the perovskite structure, the film microstructure does not recover upon drying.<sup>388</sup> Both MA<sup>+</sup> and I<sup>−</sup> can escape the lattice through water-mediated reactions, MA<sup>+</sup> by deprotonating and volatilizing and I<sup>−</sup> by taking the MA<sup>+</sup> proton and dissolving in H2O as HI, which leaves PbI2.<sup>389,390</sup> 

**4.1.2. Phase Instability of FAPbI3 and CsPbI3.** The FA cation has much better chemical stability than MA as a result of its lower acidity, its increased mass, and its smaller dipole moment.<sup>391,392</sup> As a result, FAPbI3 shows significantly improved thermal stability compared to MAPbI3 in inert atmosphere. Whereas films of MAPbI3 were found to decompose within 20 h at 90 °C in N2, thermal decomposition was substantially suppressed in FAPbI3 films under the same conditions.<sup>393</sup> However, FAPbI3 does still degrade at high temperatures, its diffraction pattern showing a notable increase in PbI2 after annealing for as little as 500 s at 170 °C.<sup>394</sup> The Cs cation is even more chemically stable than FA since it is not volatile and cannot be deprotonated.<sup>395</sup> 

Unfortunately, the extreme tolerance factors of FAPbI3 and CsPbI3 introduce a new degradation pathway through reconstructive phase transformations. The cubic _α_ -phase of FAPbI3 and the orthorhombic _γ_ -phase of CsPbI3 are metastable at room temperature, with the stable phases for both being their nonperovskite _δ_ -phases.<sup>8</sup> _γ_ -CsPbI3 showed a complete transformation to _δ_ -CsPbI3 after annealing at 90 °C in N2.<sup>393</sup> The presence of water can catalyze the phase transformation of both materials, with FAPbI3 degrading severely after 30 days in 15% RH and within 2 h at 90%RH.<sup>10</sup> Light can also accelerate the phase transition: the absorbance of FAPbI3 films showed a 75% decrease after 16 h of 1-sun illumination at 50%RH.<sup>396</sup> The phase transformation of these materials is in theory reversible through annealing above 150 °C (FAPbI3) or 320 °C (CsPbI3),<sup>132,397</sup> although annealing devices at temperatures that high would damage other organic layers and interfaces. 

As lattice reconstruction is a consequence of extreme tolerance factor, it can be suppressed by tuning the tolerance factor through A-site alloying. The popular mixed A cation halide perovskite FA0.85Cs0.15PbI3 maintains the intrinsic heat stability of FAPbI3 but is significantly more tolerant to humidity because the lowered effective tolerance factor makes the black 

phase more thermodynamically stable at room temperature.<sup>10</sup> Figure 20b shows the calculated formation energy difference between the FAPbI3 and CsPbI3 _δ_ -phases and the (FA1− _x_ Cs _x_ )- PbI3 _α_ -phase as a function of Cs concentration _x_ . There is a minimum energy difference at the point where the _δ_ -FA and _δ_ - Cs curves intersect (around _x_ ∼ 0.15), which explains the higher structural stability of the FA0.85Cs0.15PbI3 halide perovskite. Triple-cation recipes such as FA0.79MA0.16Cs0.05Pb(I0.83Br0.17)3 also show high stability even with the inclusion of MA.<sup>17</sup> Part of the improvement can be attributed to better crystallinity as a result of slower film growth kinetics in mixed-cation, mixedanion systems, which is seen for both films and single crystals.<sup>17,398</sup> 

However, mixed A-site halide perovskites do eventually degrade. FA0.85Cs0.15PbI3 is stable under humidity or light alone, but when both humidity and light are present, it degrades into the _δ_ -phases of FAPbI3 and CsPbI3, and into PbI2.<sup>399</sup> At longer time scales the FA deprotonates or degrades, forming additional PbI2. In an N2 atmosphere FA0.85Cs0.15PbI3 cells showed a moderate loss in efficiency after 600 h at 85 °C and a significant 47.7% PCE loss after 600 h of 1-sun illumination at the MPP (maximum power point), with the performance loss under light being caused by phase segregation and the formation of a current-blocking Cs _δ_ -phase.<sup>400</sup> Mixed FA-MA-Cs films have been shown to degrade in two stages at elevated temperatures (112−181 °C), quickly at first by deprotonation of MA and then more slowly by deprotonation of FA.<sup>401</sup> 

**4.1.3. Phase Segregation in Mixed Systems.** When a halide perovskite application requires a wider bandgap, a common practice is to alloy the X-site with a lighter halide ion, e.g., MAPb(I1− _x_ Br _x_ )3.<sup>19</sup> Because the X anion is a mobile species in a halide perovskite crystal, a halide perovskite with an alloyed X-site is susceptible to phase segregation, particularly under illumination.<sup>402−410</sup> Because a mixed iodide-bromide halide perovskite’s bandgap decreases as iodide concentration increases, localized I-rich regions in a nonuniform film have the effect of lowering the quasi-Fermi level splitting and reducing the _V_ OC, leading to a decrease in device performance.<sup>402,403</sup> Figure 20c shows the shift in PL spectra of MAPb(I0.5Br0.5)3 and FA0.83Cs0.17Pb(Br0.4I0.6)3 under constant illumination. The spectra redshift as iodide and bromide phase-segregate and charges are shuttled into low-bandgap iodide regions. Notably, this process is significantly slower in the FA-Cs film, which has a higher activation energy for halide diffusion.<sup>406</sup> 

Several mechanisms have been proposed for light-induced halide demixing. A polaron picture of halide segregation suggests that illumination generates carriers that couple to the lattice, generating local strain, which lowers the halide diffusion barrier and facilitates demixing.<sup>404</sup> Another model suggests that the lowered bandgap of an iodide-rich phase (particularly a raised VBM) provides a free energy driving force for iodide segregation.<sup>402</sup> Light-induced halide segregation in MAPb(I1− _x_ Br _x_ )3 has been shown to be intrinsic for _x_ > 0.5 and straininduced for _x_ < 0.5.<sup>405</sup> For films, this means that halide segregation occurs preferentially at grain boundaries and charged trap states as areas of localized strain. Improving film crystallinity,<sup>406</sup> reducing trap density,<sup>407−409</sup> relaxing strain,<sup>405</sup> reducing the carrier diffusion length,<sup>402</sup> and suppressing electron−phonon coupling<sup>404</sup> all appear to suppress halide segregation. Halide segregation is at least mostly reversible in an inert atmosphere or with perfect encapsulation, with films remixing in the absence of light, but the generation of additional trap states makes the process irreversible in air.<sup>409</sup> 

**9599** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

Mixed A-site cations are less prone to demixing than mixed X- site halides. In fact, an alloyed A-site has been shown to decrease the rate of halide segregation compared to films with a pure A- site.<sup>407</sup> This effect may be due to reduced charge-lattice coupling in mixed A-site systems<sup>404</sup> or to the improved crystallinity of their films.<sup>406</sup> However, phase segregation is still an issue in mixed-cation systems. Phase segregation into _δ_ -phases is the primary degradation pathway for FA-Cs halide perovskites, although the formation of the _δ_ -phase breaks the halide perovskite structure completely unlike in the case of halide demixing.<sup>399,400</sup> Nanoscale A-site heterogeneity created during film formation in the mixed-cation system FA0.83Cs0.17PbI3 has also been shown to induce larger-scale phase segregation during device operation.<sup>411</sup> 

**4.1.4. Solar Cell Device-Level Stability and the Effect of Bias.** The mobility of ions and defects (both intrinsic and extrinsic) in 3D halide perovskites causes additional stability issues when a halide perovskite layer is assembled into a full device stack.<sup>142,412−414</sup> Adding an internal electric field across the halide perovskite layer induces the movement of halide ions. As a result a concentration gradient forms with X-site vacancies near the HTL and a halide-rich layer near the ETL.<sup>413</sup> This electric field can be generated either by an external bias or by quasi-Fermi level splitting under light illumination.<sup>414</sup> Dark current measurements of MAPbI3 at a fixed voltage showed a decay and saturation of current on the time scale of seconds, which was attributed to ion migration.<sup>414</sup> As shown in Figure 20d, biasing a MAPbI3 cell in the dark before measurement at voltages >8 V was shown to cause an efficiency loss dominated by a decrease in the short-circuit current ( _J_ SC), suggesting that an iodide vacancy layer could be blocking hole extraction to the HTL. Cells biased at 1 or 1.2 V and then left in dark conditions for a week without bias completely and partially recovered, respectively, as a thermodynamic equilibrium ion concentration was re-established. It was suggested that open-circuit device degradation observed under light could be partially attributed to the 1 V of forward bias established across the halide perovskite solar cell rather than to the light itself. 

Besides bias effects, halide perovskites in a device stack can react with the other layers, especially at the degrading conditions of solar cell operation. Metal oxide charge transport layers (CTLs) such as TiO2415 and to a lesser extent SnO2416 are known to generate superoxides upon exposure to UV light, which can degrade the halide perovskite layer, and Li<sup>+</sup> has been shown to diffuse from a Spiro-OMeTAD HTL into the halide perovskite layer.<sup>417</sup> Furthermore, a top metal contact in a device can diffuse through the top CTL into the halide perovskite layer to react with the halide or reduce the B cation,<sup>418,419</sup> or mobile reactive species can diffuse through the CTL and corrode the metal.<sup>420,421</sup> These reactions can be suppressed through electrode and CTL materials selection,<sup>422,423</sup> through the passivation of interfaces,<sup>418,419,424</sup> and by reducing the ionic mobility within the halide perovskite.<sup>425</sup> 

**4.1.5. B-Site Oxidation in Sn and Pb-Sn Halide** 

**Perovskites.** The alloying or replacement of Pb with Sn at the B-site in 3D halide perovskites introduces a new aggressive degradation mechanism through the oxidation of Sn<sup>2+</sup> to Sn<sup>4+</sup> .<sup>8,426,427</sup> The 5s<sup>2</sup> valence electrons of Sn are significantly more active than the 6s<sup>2</sup> electrons of Pb, and as a result Sn will oxidize to Sn<sup>4+</sup> much more readily than Pb.<sup>428</sup> Sn oxidation occurs in the presence of O2, leading to the formation of Sn vacancies with energy level close to the VBM, which results in high p-type doping.<sup>112,429</sup> Excessive p-doping reduces carrier 

diffusion lengths and increases nonradiative recombination, which deteriorates device performance. Sn-based halide perovskite absorber layers can also react with CTLs, for example being degraded by 4- _tert_ -butylpyridine or acetonitrile during deposition of Spiro-OMeTAD.<sup>430</sup> 

Regardless of A-site, the degradation of SnI3-based halide perovskites proceeds through the oxidation of Sn to form SnO2 and SnI4.<sup>431</sup> SnI4 then evolves into I2, which aggressively oxidizes the halide perovskite further, accelerating degradation.<sup>432</sup> It has been suggested that the presence of Pb in the B- site, for example in APb0.5Sn0.5I3, can qualitatively change the degradation pathway and suppress SnI4 formation:<sup>431</sup> 



<!-- Start of picture text -->
2ASnI (A3 = FA, MA, Cs) + O2 2AI + SnO2 + SnI4<br><!-- End of picture text -->



<!-- Start of picture text -->
2ASn0.5Pb0.5I3 + O2 2AI + SnO2 + PbI2 + I2<br>As a result, incorporation of Pb can improve device stability<br>faster than would be expected from a pure stoichiometric<br>argument. 431<br><!-- End of picture text -->

Sn<sup>2+</sup> → Sn<sup>4+</sup> oxidation is reduced in FASnI3 compared to MASnI3 because of the higher VSn formation energy,<sup>433</sup> which is a result of the reduced Sn 5s−I 5p antibonding coupling in FASnI3 due to the larger FA cation increasing the Sn−I bond length.<sup>434</sup> This slower oxidation is demonstrated in Figure 20e, which compares the PL spectra of MASnI3 and FASnI3 over 60 min in air.<sup>433</sup> Incorporating some amount of the larger molecule GA at the A-site can realize significant additional stabilization.<sup>435</sup> Oxidation can be additionally suppressed by the incorporation of reducing agents such as SnX2 (X = F, Cl, Br, I, SCN),<sup>427</sup> metallic Sn,<sup>436,437</sup> or other additives.<sup>426,427</sup> The low solubility of SnX2 compounds also causes them to precipitate early during solution processing and act as nucleation sites for homogeneous growth.<sup>438</sup> From a device architecture perspective, stability can be improved by extracting holes as efficiently as possible, for example by employing an inverted architecture where charges are generated near the HTL<sup>426</sup> or by improving hole extraction and transport of the HTL.<sup>439</sup> 

**4.1.6. 3D Halide Perovskite Self-Healing.** An interesting aspect of halide perovskite degradation is that to an extent both single crystals and films of the materials are self-healing. Partial recovery of the perovskite phase in films or device performance in solar cells has been shown once halide perovskites are removed from degrading conditions, in particular from humid to dry atmosphere<sup>388,440−443</sup> and from illuminated or biased conditions to dark, unbiased conditions.<sup>444−454</sup> 

In humid conditions halide perovskites degrade in several stages, some but not all of which are reversible.<sup>388</sup> The MAPbI3 halide perovskite phase will reversibly transform to a 1D monohydrate phase MAPbI3·H2O (which maintains the perovskite stoichiometry) upon exposure to low H2O concentrations.<sup>388,440,442</sup> If the device is removed from humidity while only the monohydrate phase has been formed, it can recover. Additional H2O will result in the formation of the 0D dihydrate phase MA4PbI6·2H2O and the precipitation of excess PbI2. This reaction is also reversible in theory, but segregation of PbI2 and collapse of the microstructure makes it easier for volatile MAI to escape, which renders the process irreversible.<sup>388,442</sup> Preventing the release of degradation products can improve the self-healing capability of MAPbI3 in humid conditions.<sup>441</sup> The dihydrate phase will decompose irreversibly with additional H2O as MAI is dissolved and removed from the crystal.<sup>388</sup> 

**9600** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

Halide perovskites also self-heal when moved from light to dark conditions. The phase segregation of illuminated mixedhalide films,<sup>453,454</sup> the defect concentration gradient formed from light-induced bias across a device,<sup>450</sup> and the higher defect density in illuminated films<sup>381,444</sup> will each cause reversion to the thermodynamic equilibrium state of uniform distribution when the driving force of light is removed. Nie et al. found that illumination of MAPbI3 led to the formation of light-induced metastable trap states, which self-healed after less than 1 min in dark conditions.<sup>444</sup> Self-healing from light-induced degradation has been observed not only in devices but also in single crystals of FAPbBr3, MAPbBr3, and CsPbBr3,<sup>452</sup> with FAPbBr3 healing the fastest (Figure 20f); the authors attributed this recovery to the localization of degradation products. Some (but not all) light-induced decomposition reactions have also been shown to be reversible in devices with the requirement that degradation products stay within the device.<sup>448</sup> 

As degradation progresses, self-healing effects can diminish or even reverse. Khenkin et al. found that light−dark cycling of FA0.79MA0.16Cs0.05Pb(I0.83Br0.17)3 devices initially showed complete PCE recovery in the dark, but after 50% PCE degradation _J_ SC and FF would rapidly decrease when the light was turned off and increase when the light was turned on.<sup>446</sup> The authors attributed this behavior to multiple coexisting processes within the device: the formation of new defect states under light and disappearance under dark as in ref 444 at the early stages of degradation, and the detrapping and resultant activation of interfacial defect states under dark that were filled by photocarriers under light at longer degradation times. Lightinduced recovery through the passivation of defect states was also seen after degradation of halide perovskite devices under UV light.<sup>447</sup> 

The self-healing effect in 3D halide perovskites can be enhanced with additives. 2D halide perovskites in particular can improve 3D halide perovskites’ ability to self-heal, as will be discussed later, but a similar improvement in MAPbI3 selfhealing after humidity-induced degradation has been realized with a polyethylene glycol (PEG) scaffold.<sup>441</sup> MAPbI3 films which incorporated PEG saw a near-complete recovery in device performance after a 60 s exposure to water vapor and 45 s in dry air. The proposed mechanism of this improvement was strong bonding between MAI and PEG, which retained degradation products in the vicinity of the degraded halide perovskite grain such that the perovskite phase could reform when water was removed. These promising results suggest that halide perovskite stability can be significantly enhanced through additive or architecture engineering to localize degradation products. 

Notably, although halide perovskites are notoriously environmentally unstable compared to inorganic semiconductors, selfhealing allows them to perform remarkably well in applications where damage is inevitable regardless of intrinsic material stability; for example as radiation detectors.<sup>455,456</sup> halide perovskites have been shown to withstand proton doses several orders of magnitude higher than crystalline Si and self-heal after radiation is stopped.<sup>456</sup> Conventional semiconductors receive their intrinsic stability from their rigid lattices with high bond energy, but they are less forgiving toward the defect states which form when those bonds are broken. In contrast, halide perovskites’ combination of intrinsic defect tolerance and selfhealing is perfect for high-radiation applications. 

Since self-healing is a characteristic not shared by conventional Si or III−V semiconductors, conventional accelerated degradation tests developed for these inorganic materials are not 

designed to measure its effects on device lifetime. This has prompted a call for the adoption of new halide perovskitespecific degradation tests, in particular tests to approximate the effects of day−night cycling on devices.<sup>457,458</sup> It has been proposed that a more complete understanding of self-healing in halide perovskites under operating conditions could be used to extend device lifetimes by intermittently taking devices offline to recover.<sup>459</sup> 

**4.1.7. Current State-of-the-Art 3D Stability.** A variety of methods have been developed to improve the stability of 3D halide perovskites, many of which seek to reduce or passivate defects within a film. Additives can be introduced to passivate charged defects at grain boundaries, simultaneously suppressing oxygen adsorption and halide segregation.<sup>460</sup> Improving the crystallinity of the film, for example through precursor solution engineering, will also suppress degradation. Likewise, enhancing the hydrophobicity of the halide perovskite film with additives can also improve stability. Ammonium salts (e.g., MACl<sup>461</sup> ), Lewis acids (e.g., C60-PEG<sup>462</sup> ), Lewis bases (e.g., PMMA<sup>463</sup> ), and ionic liquids (e.g., 1-alkyl-4-amino-1,2,4-triazolium<sup>464</sup> ) have all been shown to improve 3D device stability through some combination of these three processes when introduced into the precursor solution or the antisolvent. As will be discussed extensively below, the incorporation of 2D halide perovskites as a dopant or capping layer can also significantly improve stability for partially the same reasons. 

Besides defects, interfaces within a device are also principal origins of degradation. The stability of halide perovskite solar cells can be enhanced by passivating the halide perovskite−HTL and halide perovskite−ETL heterojunctions.<sup>465</sup> Since charge accumulation at interfaces can accelerate degradation reactions, improving band alignment at these heterojunctions can also increase stability.<sup>466,467</sup> Some CTLs are themselves prone to degradation, most notoriously Spiro-OMeTAD, which is known to degrade under heat, light, oxygen, and moisture, particularly when doped.<sup>468−471</sup> The environmental stability of not only the halide perovskite but every layer in the device must also be ensured. Ion migration also needs to be suppressed, both within the perovskite layer to avoid defect accumulation at interfaces<sup>199</sup> and between layers to avoid reactions between CTLs or contacts.<sup>417,422</sup> 

Encapsulation of halide perovskite devices can significantly enhance their stability in harsh environmental conditions.<sup>472</sup> Encapsulated devices have retained >95% of their initial PCE after 1000 h at 85 °C/85%RH, 2000 h of outdoor testing, and 5 h submerged in water. Encapsulation not only prevents the ingress of O2 and H2O but also prevents the outgassing of volatile halide perovskite degradation products which allows for self-healing when the degrading condition is removed.<sup>448</sup> 

Unlike solar cell efficiency, which is a relatively unambiguous figure of merit, stability is much more difficult to quantify. The stability of any solar cell will depend on its environment, and unfortunately a standardized set of environmental and device conditions for degradation tests has not been adopted by the halide perovskite community. As a result, it is difficult to make one-to-one comparisons of device stability across publications and groups. For example, many reports will measure photostability in inert atmosphere with the justification that it effectively simulates the atmosphere seen by an encapsulated device (e.g., ref 224); other reports will directly measure the photostability of encapsulated cells in ambient air (e.g., ref 229), and still others will measure the photostability at elevated temperatures (e.g., ref 473). Likewise, different reports measure 

**9601** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

air stability in elevated (e.g., ref 221), ambient (e.g., ref 224), or reduced (e.g., ref 474) humidity conditions, or measure shelfstability in the dark in inert atmosphere (e.g., ref 237). Elevated temperature tests have also been reported in air (e.g., ref 235) or in N2 (e.g., ref 236). When devices are encapsulated, the encapsulation procedure is also not standardized across papers, and not all encapsulation is equally effective.<sup>472</sup> In order to better understand the present and future state-of-the-art for halide perovskite stability, the field must adopt a standardized and easily replicable set of degradation conditions. Recent progress has been made toward this goal, e.g., through the 2020 consensus statement for stability assessment which advocates for the use of modified International Summit on Organic Photovoltaic Stability (ISOS) testing protocols.<sup>457</sup> However, this statement has not been universally adopted and it is still unclear which testing procedures are the most relevant to predicting device lifetime under real-world operating conditions. 

Even when degradation tests are standardized, the testing apparatus may introduce different conditions from what have been reported. For example, different sources for above-bandgap light can emit subtly different spectra which can influence a device’s degradation rate, particularly for differences in the UV range.<sup>457</sup> It is therefore necessary to standardize not only the testing conditions but also the apparatus used to achieve those conditions. However, in the case of light soaking, which apparatus should become the standard is unclear, since various light sources present a trade-off between accuracy to the solar spectrum (e.g., Xenon bulbs, which can emit UV radiation) and lab-scale feasibility (e.g., LED lamps which are cheaper, last longer, and use less energy).<sup>475</sup> A possible compromise could be to measure in-operando stability under 1-sun visible (e.g., LEDgenerated) light with MPP tracking and separately measure stability under UV light alone with a standardized UV lamp. 

A common degradation condition which is fairly repeatable is continuous 1-sun illumination in inert atmosphere with MPP tracking (ISOS-L-1I).<sup>457</sup> If it is assumed that device encapsulation can achieve a perfect barrier to air and water, this measurement has practical utility. The best devices as of 2023 retain >90% and up to 100% of their initial PCE after 1000 h (∼42 days) in this condition;<sup>476,477</sup> this 1000 h mark has become somewhat of a key milestone in the field. “Shelfstability” in ambient air without light (ISOS-D-1<sup>457</sup> ) is another commonly reported metric. In this case variations in the %RH of ambient air between laboratories and over the course of a measurement could introduce discrepancies in reported stability. However, tests such as this in atmospheres containing both O2 and H2O are important considering the various halide perovskite degradation pathways, which involve these molecules. The best devices retain >90% of their initial PCE after 90 days (2160 h) in ambient conditions without encapsulation.<sup>478,479</sup> The photostability in N2 and shelf stability in air are given in Tables 5 and 6, for example high-efficiency devices over 24% PCE, where reported. To better compare between reports, the stability values given have also been projected to 1000 h (photostability) or 90 days (ambient stability) assuming a constant degradation rate. 

Along with ISOS protocols, it has become clear that light plays a key role in perovskite solar cell degradation more-so than in inorganic photovoltaics, which tend to lose performance due to the failure of module components besides the absorber layer itself.<sup>480</sup> As has been discussed above, light activates many degradation processes in halide perovskite films, and temperature accelerates these processes. We therefore suggest, as Boyd 

et al. do in their excellent review of perovskite degradation,<sup>475</sup> that light-soaking degradation tests in inert atmosphere be performed under a combination of concentrated sunlight (e.g., 5-suns) and elevated temperature (e.g., 85 °C). The adoption of this testing standard should be done simultaneous with rigorous investigation by the halide perovskite community of how degradation rate in common perovskite devices scales with light intensity and temperature. In addition, the ability of each perovskite device to self-heal in dark conditions should be quantified through cyclic testing with standardized cycle rates and rest periods, which can likewise be performed with concentrated sunlight. 

### **4.2. Improved Stability with 2D Halide Perovskites** 

Compared to 3D halide perovskites with the same A-site cation, 2D halide perovskites demonstrate improved stability against heat, light, oxygen, and water. This was the main breakthrough brought by the 2016 seminal paper of Tsai et al., besides an over 2.5-times increase in the then-reported efficiency for 2D halide perovskite solar cells.<sup>257</sup> However, 2D halide perovskites are still susceptible to degradation in operating conditions and more effort is needed to improve their stability toward what is required for commercialization. 

**4.2.1. Comparing the Stability of RP, DJ, and ACI 2D Halide Perovskites.** While few rigorous studies on the degradation pathways of various 2D halide perovskites exist and the vast majority of 2D devices have been mixed 2D-3D films, the stability of reported devices suggests that in a device architecture DJ and ACI halide perovskites are more stable than RP halide perovskites.<sup>481,482</sup> This is often explained as being due to the stronger interlayer bonding in ACI and especially in DJ halide perovskites, compared to the RP structure, for which layers are held together by the van der Waals forces between spacer molecules. The shorter interlayer distance in DJ and ACI structures may also have a stabilizing effect. Interestingly, bare films (not incorporated into devices) of RP halide perovskites have been shown to be more stable than bare films of DJ halide perovskites,<sup>481</sup> which may be due to the difference in formation energy between the two phases: RP halide perovskites have a negative formation energy larger than that of the 3D phase giving higher thermodynamic stability,<sup>483,484</sup> whereas DJ halide perovskites have a positive formation enthalpy making them metastable.<sup>79</sup> This suggests that interlayer bond strength and formation energy compete to respectively stabilize and destabilize the DJ phase relative to the RP phase and that which effect is more important depends on the environmental conditions. Moreover, the rate at which reactive species can penetrate the crystal structure, the rate of degradation in the presence of those species, and the ease with which degradation products can leave the structure will each depend not only on the intrinsic stability of the structure but also on the microstructure, the device architecture, and the particular external conditions. More work needs to be done to elucidate the differences in degradation mechanism and degradation rate for the various 2D halide perovskite structures. 

**4.2.2. Mechanistic Rationale for 2D Halide Perovskites’ Improved Stability.** The improved stability of 2D halide perovskites comes from a combination of the hydrophobic spacer cations<sup>328,481,485−487</sup> and the suppressed ion mobility<sup>340,341,343</sup> and reduced vacancy density<sup>302,301</sup> in the 2D phase. These materials properties not only result in better bulk stability but also can enable a self-passivating degradation mechanism via disproportionation at surfaces, as will be 

**9602** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** **<u><mark>pubs.acs.org/CR</mark></u>** <mark>Review</mark> 



Figure 21. Stability of 2D perovskites. (a) Top: Enthalpy of formation (Δ _H_ f) for 2D RP BA2MA _n_ −1Pb _n_ I3 _n_ +1 _n_ = 1−7 showing a steep increase after _n_ = 5. MAPbI3 Δ _H_ f is shown in dashed green line. Bottom: Δ _H_ f for _n_ = 1−5 showing stabilization of even _n_ -values. Reproduced with permission from ref 66. Copyright 2018 National Academy of Sciences. (b) Unencapsulated device PCE data over time for cells with absorber layers of DJ (PDA)MA3Pb4I13 (PDA = 1,3-propanediammonium, ⟨ _n_ ⟩≥ 4, blue), RP (PA)2MA3Pb4I13 (PA = propylammonium, ⟨ _n_ ⟩≥ 4, red), and 3D MAPbI3 (green) in four environments. Top left: ambient air, dark, 40−70%RH. Top right: ambient air, 85 °C/40−70%RH. Bottom left: 85 °C/85%RH. Bottom right: 1-sun illumination in inert atmosphere. The DJ device shows the best stability, and the 3D device shows the worst stability under all conditions. Reproduced with permission from ref 492. Copyright 2019 Elsevier. (c) Unencapsulated (top) and encapsulated (bottom) device PCE data over time for RP (BA)2MA2Pb3I10 (red) and 3D MAPbI3 (blue) in two environmental conditions. Left: 1-sun illumination in inert atmosphere. Right: ambient air, 65% RH. Top: The unencapsulated RP device has better stability than the 3D device under both conditions. Bottom: Encapsulation further improves the stability of the RP device relative to the 3D device. Reproduced with permission from ref 257. Copyright 2016 Springer Nature. (d) Water contact angle measurements for 3D MAPbI3 (top left) and the _n_ = 3 RP structures (A′)2MA2Pb3I10 with A′ = BA (top right), pentylammonium (PA, bottom left), and hexylammonium (HA, bottom right). Contact angle increases with spacer cation length. Reproduced with permission from ref 80. Copyright 2019 American Chemical Society. (e) PL intensity over time for films of RP (BA)2MA _n_ −1Pb _n_ I3 _n_ +1 ( _n_ = 1−3) and 3D MAPbI3 under continual irradiation by 450 nm light in inert atmosphere. A nonmonotonic _n_ -value dependence is observed, with RP _n_ = 3 showing better stability than both _n_ = 3 and MAPbI3. Reproduced with permission from ref 506. Copyright 2021 American Chemical Society. (f) PL intensity 

**9603** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

**<u>Chemical Reviews</u>** 

**<u><mark>pubs.acs.org/CR</mark></u>** 

<mark>Review</mark> 

#### Figure 21. continued 

over time for single crystals of (BA)2PbI4 (left), (BA)2MA2Pb3I10 (center), and MAPbI3 (right) after a pulse of low (imaging, yellow), moderate (blue), and high (red) laser irradiation. The RP films self-heal faster than 3D films after moderate photodamage. For high photodamage the _n_ = 1 crystal heals the fastest but the _n_ = 3 crystal shows permanent photodamage. Reproduced with permission from ref 504. Copyright 2022 Wiley-VCH. (g) Unencapsulated (top) and encapsulated (bottom) device PCE data over time for RP (BA)2MA3Sn4I13 (red) and 3D MASnI3 (black) in ambient air. The RP device showed better air stability than the 3D device both with and without encapsulation. Reproduced with permission from ref 507. Copyright 2017 American Chemical Society. 

discussed later.<sup>481,488−491</sup> For some 2D halide perovskites, a higher thermodynamic stability additionally suppresses degradation.<sup>483,484</sup> 

2D halide perovskites are more stable in humid environments than 3D halide perovskites.<sup>80,257,492</sup> This is at least partially due to the hydrophobicity of the A′-site cations.<sup>486</sup> The bulky spacer cation introduced into the 2D lattice can suppress the ingress of water molecules into the inorganic layer, slowing watermediated deprotonation of the A-site cation in MAPbI3328 and the water-mediated _α_ → _δ_ phase transition in FAPbI3.493 

As has been discussed above, 2D halide perovskites show a reduced density of X-site and A-site vacancies and a reduced ion mobility compared to 3D halide perovskites.<sup>302,301,340,341,343</sup> This suppresses the several degradation pathways which are facilitated by vacancies or mobile halides. Lower vacancy density reduces the rate at which O2 and H2O enter the lattice, as these molecules have a high affinity for point defects.<sup>494</sup> Light-induced halide segregation in mixed-halide 2D halide perovskites is also suppressed by the reduced [VX], although it does still occur.<sup>344,481,495−497</sup> It should be noted that halide segregation may be suppressed not only due to a reduction in defect concentration but also because of a preferred I−Br distribution and a smaller bandgap change between the iodide and bromide phases in 2D halide perovskites.<sup>495</sup> Bias-induced halide migration and _J_ − _V_ hysteresis are also both suppressed in 2D halide perovskite devices.<sup>257,322,498</sup> 

Part of the reason why 3D halide perovskites degrade so quickly, especially in the presence of water, is the low formation energy of the 3D structure. In RP 2D halide perovskites, introducing an A′ cation into the lattice also introduces a significant van der Waals force between layers which has the effect of increasing the formation energy of the crystal.<sup>484</sup> This is another possible explanation for the improved stability of RP 2D halide perovskites. However, it should be noted that MA-based DJ 2D halide perovskites have no such van der Waals interactions and in fact show a positive enthalpy of formation, suggesting that they are in fact metastable phases;<sup>79</sup> in spite of this, and while DJ films may indeed be less air-stable than RP films, DJ halide perovskite devices outperform RP devices in terms of stability.<sup>481,492</sup> This suggests that formation energy is not a sufficient explanation by itself for the improved stability of 2D phases. 

**4.2.3. Novel Degradation Pathways in 2D Halide Perovskites.** Despite their improved stability, 2D halide perovskites do still degrade under environmental stressors. However, humidity-induced degradation of RP 2D halide perovskites proceeds via disproportionation at surfaces whereby a lower- _n_ -value 2D halide perovskite is formed along with 3D halide perovskite (or its degradation products).<sup>481,488−491</sup> Forming lower- _n_ -value perovskites as a degradation product has the effect of increasing the A′ cation concentration at surfaces exposed to humidity, which slows further water ingress. As a result, RP 2D halide perovskites are to an extent selfpassivating. 

The nature of the disproportionation reaction is still controversial and may be dependent on spacer cation chemistry. For RP halide perovskites with a BA A′ cation, studies have reported the formation of a mixed-lower- _n_ film (e.g., n3 → n2 + n1).<sup>488,490</sup> Some reports on RP halide perovskites with a PEA cation suggest they behave similarly,<sup>491</sup> whereas others see the direct formation of n1 with no intermediate _n_ -value appearing.<sup>489</sup> In DJ halide perovskites a hydrate complex has been shown to form on the surface of films exposed to humid air which can be transformed back to the DJ phase with annealing.<sup>499</sup> 

The wider bandgap and the chemistry of the A′-site can cause novel reactions in 2D halide perovskites which are absent in the 3D phase. In particular, a redox reaction between Pb<sup>2+</sup> and the A′ cation can reduce Pb<sup>2+</sup> to Pb<sup>0</sup> and oxidize the A′ amine group to an imine.<sup>500,501</sup> This reaction proceeds through the formation of a Pb<sup>2+</sup> -amide complex followed by a sequence of light-assisted proton transfer reactions, and it requires the A′ cation to possess a _β_ -C−H bond (e.g., butylammonium).<sup>500</sup> An interesting consequence of this degradation process is that, since it increases with decreasing _n_ -value at the same time as 3D degradation processes are suppressed, it can lead to a nonmonotonic _n_ -value dependence of stability where an _n_ > 1 RP is more stable than either its n1 or 3D phase in certain environments.<sup>501</sup> 

The 2D structure informs the crystal surfaces along which degradation occurs. Mechanically exfoliated nanoflakes of the well-known 2D halide perovskite PEA2PbI4 were used to investigate 2D halide perovskite intrinsic photostability.<sup>502</sup> Under resonant photoexcitation, PEA2PbI4 degrades to PbI2 in a process initiated most aggressively at the crystal edges (inplane) and secondarily from the surface (out-of-plane). This is in contrast to the layer-by-layer degradation observed in platelike MAPbI3 crystals.<sup>503</sup> The surface degradation was explained by the observed lengthening of Pb−I bonds along the out-ofplane direction in PEA2PbI4, making those bonds more vulnerable to cleavage. Edge degradation was explained by outgassing of volatile organic degradation products being initiated at the edges, because of the more efficient mass transfer in the in-plane compared to out-of-plane direction. It was shown that encapsulation could efficiently suppress both degradation pathways. 

Recent work by our group has shown a light-induced lattice contraction in the out-of-plane direction for DJ and ACI halide perovskites, which was not observed for RP halide perovskites or 3D halide perovskites.<sup>371</sup> When exposed to constant light illumination, DJ and ACI halide perovskites exhibited interlayer contraction over tens of minutes, which was reversible when light was removed. While our report did not observe or comment on degradation, modulation of bond lengths and introduction of compressive strain could change the activation energies for degradation reactions and the diffusion of degradation products for DJ and ACI halide perovskites under 

**9604** 

https://doi.org/10.1021/acs.chemrev.3c00214 _Chem. Rev._ 2023, 123, 9565−9652 

