# Perovskite: Scintillators, direct detectors, and X-ray imagers

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Materials Today |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 292 |
| 作者 | A. Jana, Sangeun Cho, S. Patil, Abhishek Meena, Y. Jo, V. Sree, Youngsin Park, H. Kim et al. |
| DOI | 10.1016/j.mattod.2022.04.009 |
| 源文件 | 005_Jana_2022_Perovskite-Scintillators-direct-detectors-and-X.pdf |

---
# **Perovskite: scintillators, direct detectors, and X-ray imagers** 

Atanu Jana,<sup>a</sup> Sangeun Cho,<sup>a</sup> Supriya A. Patil,<sup>b</sup> Abhishek Meena,<sup>a</sup> Yongcheol Jo,<sup>a</sup> Vijaya Gopalan Sree,<sup>a</sup> Youngsin Park,<sup>c</sup> Hyungsang Kim,*<sup>,a</sup> Hyunsik Im*<sup>,a</sup> and Robert A. Taylor<sup>d</sup> 

a Division of Physics and Semiconductor Science, Dongguk University, Seoul 04620, Republic of Korea. Email: _hskim@dongguk.edu (H.K.), hyunsik7@dongguk.edu (H.I.)_ 

> b Department Nanotechnology & Advanced Materials Engineering, Sejong University, Seoul05006, South Korea 

> c Department of Chemistry, School of Natural Science, Ulsan National Institute of Science and Technology (UNIST), Ulsan 44919, Korea 

d Clarendon Laboratory, Department of Physics, University of Oxford, Parks Road, Oxford OX1 3PU, UK. 

## **Abstract** 

Halide perovskites (HPs) are used in various applications, including solar cells, light-emitting diodes, lasers, and photodetectors. These materials have recently received a great deal of attention as high-energy radiation detectors and scintillators due to their excellent light yield, mobilitylifetime product (µτ), and X-ray sensitivity. In addition, due to their solution-processability and low cost, perovskite materials could be used to produce thick perovskite films across wide areas, allowing for low-dose X-ray imaging. Perovskite-based scintillators and detectors could eventually replace commercialized products like thallium‐doped cesium iodide (CsI:Tl) and amorphous silicon (Si). Here, we review all of the key properties of HPs, the relevant terminology necessary for radiation detection and scintillation, the physical mechanisms underlying their operation, the fabrication process, and perovskite crystals and thin-films of varying dimensionality used for high-energy radiation detection. We also cover the critical issues and solutions that HPs as detectors, scintillators, and imagers face. 

1 

## **1. Introduction** 

A scintillator is a type of phosphor material that converts various kinds of high-energy radiation (e.g. (a) electromagnetic (EM) radiation: X-rays/gamma rays (γ-rays) and (b) particle radiation: alpha rays (α-rays), beta rays (β-rays), electron rays, proton rays, heavy particle rays, neutron rays, etc.) into ultraviolet-visible (UV-Vis) light [1,2]. Then, photomultiplier tubes (PMTs), thin-film phototransistor (TFT) arrays, amorphous Si photodiodes (PDs), complementary metal-oxide semiconductor (CMOS) detectors, Si avalanche PDs (APDs), and arrays, or charge-coupled devices (CCDs) are used to detect the emitted light without damaging the detector. The EM radiation spans a broad range in which visible light falls in a small zone (400-800 nm). Visible light can be seen with the naked eye, but invisible rays, such as α-, β-, γ-, and X-rays cannot. To detect these rays, photographic plates possess a significant disadvantage due to their poor capability to absorb the radiation. Therefore, other detection methods are currently required urgently. There are different kinds of scintillators, such as organic crystal (e.g., stilbene and anthracene) [3,4], organic liquid (e.g. 2,5-diphenyloxazole (PPO)) [5], inorganic crystal (e.g., cesium iodide, gadolinium silicate, and gadolinium oxysulfide (GOS)) [6], gases (e.g., xenon and helium) [7], and plastic scintillator (e.g., polyvinyltoluene and polystyrene) [8]. These scintillators are used selectively depending on the radiation type and application purpose. Semiconductorbased conventional X-ray direct detectors, which convert X-ray photons into electrons, have superior resolution, much higher than scintillators. Unfortunately, direct detectors that use amorphous selenium, take longer to collect an image due to their lower X-ray stopping power and insufficient charge transport ability. Scintillator imagers, however, are more sensitive than direct X-ray imagers. In this case, the X-ray image quality is poor because of the lower conversion efficiency and the scattering-induced optical crosstalk. The typical synthesis of conventional scintillators, requires high-temperature sintering, producing agglomerated powders or bulk crystals that are difficult to process for device fabrication, whereas solution-processed scintillators are highly promising. Therefore, there is an imperative for the development of both direct and indirect detectors that can be synthesized at low temperatures. 

Recently, lead HP scintillators and direct detectors in the form of single crystals (SCs), polycrystalline materials, and nanocrystals (NCs) have attracted great interest due to their tunable emission wavelength, low detection limit, high stopping power, and ease of fabrication, and the 

2 

high atomic number of lead [9–13]. All the major breakthroughs using perovskites as scintillators and direct detectors are listed in **Table 1** . 

**Table 1.** Breakthroughs in perovskite scintillator and detector research 

|Principal|Perovskite scintillator, detector and imager|Year|
|---|---|---|
|investigator_et al._|||
|Vasil’ev|CsPbCl3: X-ray scintillator|1995[14]|
|Asai|(C6H13NH3)2PbI4: proton scintillator|2002[15]|
|Asai|3D and 2D hybrid perovskites: proton scintillator|2004[16]|
|Koshimizu|(C6H5(CH2)2NH3)2PbBr4: γ-ray scintillator|2008[17]|
|Kanatzidis|CsPbBr3SCs: X-ray detector|2013[18]|
|Heiss|MAPbI3: X-ray detector|2015[19]|
|Huang|MAPbBr3SCs: X-ray detector|2016[20]|
|Kovalenko|MAPbI3, FAPbI3and I-treated MAPbBr3: γ-ray detector|2016[21]|
|Soci|MAPbI3, MAPbBr3, and (EDBE)PbCl4: X-ray scintillator|2016[22]|
|Kovalenko|Cs_x_FA1−_x_PbI3−_y_Br_y_(_x_= 0–0.1,_y_= 0–0.6) SCs: γ-ray<br>dosimetry|2017[23]|
|Huang|MAPbBr3SCs: X-ray detector|2017[24]|
|J. Matt|MAPbI3wafer: X-ray detector|2017[25]|
|Huang|CH3NH3PbBr3−xClxSCs: γ-ray detector|2017[26]|
|Park|MAPbI3+ MAPbBr3thin-film: X-ray detector and imager|2017[27]|
|Tang|Cs2AgBiBr6SCs: X-ray detector|2017[28]|
|Kanatzidis|CsPbBr3SCs: γ-ray detector|2018[29]|
|Liu|CsPbX3(X = Cl, Br, I) NCs: X-ray scintillator|2018[30]|
|Tang|Rb2CuBr3SCs: X‐Ray scintillator|2019[31]|
|Brovelli|Plastic scintillator [CsPbBr3NCs + polymer + organic dye];<br>X-rays and α-particle scintillator|2020[32]|
|Im|CsPbX3(X = Cl, Br, I) NCs + PPO: X-ray scintillator and<br>imager|2020[33]|



3 

Even though perovskites perform exceptionally well in direct and indirect detectors, many questions remain unanswered. How can we improve the light yield of perovskite materials? What is the structural-property relationship under high-energy radiation? How can we improve the X- ray image quality using perovskite-based detectors and scintillators?  In this regard, we review the scintillation and luminescence properties of different types of perovskite materials irradiated with X-rays, γ- rays, α-rays, β-rays, and neutron rays. Though there have been some previous review papers on both direct and indirect perovskite X-ray detectors for imaging [34–39], we present various breakthroughs in perovskite scintillator and detector research over time, with a detailed explanation of the related terminology, the performance of common scintillators and direct X-ray detectors, direct and indirect X-ray detectors based on different dimensional perovskites and finally, we discuss gigahertz X-ray imaging and possible strategies to enhance the performance of perovskite X-ray detectors. 

## **2. High-energy radiation sources (α-, β-, γ-, and X‐rays) and their importance in various fields** 

The EM spectrum includes a wide range of radiation, including α-, β-, γ-, and X‐rays. X-rays can be classified as “soft”, with energies typically below 10 keV, or “hard”, with energies ranging from 10 to 200 keV [40]. Today, X-rays are used in various fields such as crystallography, medical imaging, airport security, and microscopy. γ-ray photons are the most energetic photons in the EM spectrum. γ-ray photons generally exceed 100 keV. Because of their high penetration power, γ- rays can pass through many materials, including human tissue. γ-rays have substantially higher energy and penetrating ability than X-rays. Different radioisotope sources are used for generating γ-rays, such as<sup>24</sup> Na,<sup>28</sup> Al,<sup>38</sup> Cl,<sup>56</sup> Mn,<sup>72</sup> Ga,<sup>76</sup> As,<sup>88</sup> Y,<sup>124</sup> Sb,<sup>140</sup> La,<sup>144</sup> Pr [1]. α-particles, also known as α-rays or α-radiation, consist of two protons and two neutrons bound together into a particle identical to a helium-4 nucleus. These charged particles [41] are used in scientific research, medical imaging, and environmental analysis. Various radioisotope sources are used for generating α-rays, such as<sup>148</sup> Gd,<sup>232</sup> Th,<sup>238</sup> U,<sup>235</sup> U,<sup>236</sup> U,<sup>230</sup> Th,<sup>234</sup> U,<sup>231</sup> Pa,<sup>239</sup> Pu,<sup>243</sup> Am  [1]. The β-ray, which has moderate penetrating power, is a useful resource for monitoring surface radiative pollution. High-Z (atomic number) elements are suitable for X/γ-ray absorption, whereas light elements are better used as β-ray scintillators [42,43].  Various nuclides are used for generating β-rays such as 3H, 14C, 32P, 35S, 36Cl, 45Ca, 63Ni, 90Sr, 99Tc, 147Pm, 22Na, 60Co, 137Cs. 

4 

## **3. Terms related to scintillation and radiation detection** 

**3.1. Radioactivity:** Radioactivity is the amount of ionizing radiation emitted by a substance. The standard international (SI) unit of radioactivity is the becquerel (abbreviated Bq), which equals 1 disintegration per second (dps). Another unit of radioactivity is the curie, a historical unit based on the number of dps in 1gram of radium-226 (37 billion disintegrations per second). One curie = 37 billion Bq, 1 picocurie (a trillionth of a curie) equals 0.037 Bq, and 1 Bq equals 27 picocuries. Radioactivity is also measured in disintegrations per minute (dpm) where 1 dpm equals 1/60 Bq. 

**3.2. Exposure** : Exposure refers to the amount of ionization caused by radiation passing through air. The exposure units are roentgen (R) and coulomb/kilogram (C/kg). The amount of radiation required to generate a charge of 2.58 × 10<sup>−4</sup> C in 1 kg of dry air is 1R. 

**3.3. Dose** : Dose is the amount of radiation absorbed by a specific substance. The SI unit for absorbed dose is gray (Gy) or J/kg, where 1Gy is defined as the amount of radiation that results in 1 J energy absorption per kg of a specific substance. Gray is a measure of the energy deposited in tissue. Dose absorbed by dry air (Gyair) can be converted to R using 1Gyair = 114 R. One gray is equal to 100 rads. Dose rate equals the amount of dose per unit time. The correlation between these units is as follows:  1 rad = 0.01 Gy = 0.01 J/kg = 100 erg/g. 

**3.4. Dose equivalent:** Dose equivalent is expressed in terms of both the amount of radiation absorbed and the medical effects of a particular type of radiation. Units for dose equivalent are the roentgen equivalent man (rem) and sievert (Sv), and biological dose equivalents are commonly measured in 1/1000th of a rem (known as a millirem or mrem). The correlation between these units is as follows: 1 R (exposure) = 1 rad (absorbed dose) = 1 rem or 1000 mrem (dose equivalent). The more modern sievert = 100 rem. It is a large dose and is often seen in units of millisieverts (mSv) or microsieverts (µSv). 

**3.5. Kinetic energy released per unit mass (KERMA):** KERMA is the sum of the initial kinetic energies of all charged particles released by uncharged ionizing radiation in a substance, divided by its mass. The gray (Gy) or joule per kilogram is the SI unit of KERMA, and it is the same as the unit of absorbed dose. 

5 

**3.6. Unit of sensitivity:** The unit of sensitivity is expressed in microcoulombs per air KERMA of milligray per square centimetre (μC mGyair<sup>−1</sup> cm<sup>−2</sup> ). 

## **4. What are the important parameters for scintillators and detectors?** 

## **4.1 Scintillation parameters** 

## **4.1.1 Scintillation yield** 

The scintillation yield (or light yield) is the number of photons ( _N_ ph) emitted by a scintillator per unit energy, deposited by ionizing radiation or with a γ-ray of quantum energy in the medium. $! Hence, it can be calculated using the following formula: 𝑁!" = 𝑁#"𝑆𝑄= 𝑆𝑄 , 𝑁#" is the $"# number of electron-hole pairs, 𝐸#" is the average energy necessary to produce one thermalized e- h pair, _S_ is the transport/transfer efficiency of the e-h pair energy to the luminescence centre, and _Q_ is the quantum yield for the final luminescence process. The components of the scintillation yield (conversion efficiency, transport, luminescence yield, and light collection) are, to some extent, all dependent on the structural quality of the lattice [44,45]. Scintillation properties of commonly used materials are listed in **Table 2** . 

**Table 2.** Radioluminescence (RL) and light yield for commonly used scintillator materials. 

|Sl|Material|Emission peak|Light yield|Ref.|
|---|---|---|---|---|
|no||(nm)|(ph/MeV)||
|1|BGO (Bi₄Ge₃O₁₂)|480|8,500|[46]|
|2|LYSO(Ce) [Lu1.8Y0.2SiO5:Ce]|420|29000|[47]|
|3|CsI(Tl)|540-550|65,000|[46,48,49]|
|4|LiI(I)|470|11,000|[1]|
|5|NaI(Tl)|415|38,000–55,000|[1]|
|6|CdWO4|470|15,000|[50–52]|
|7|LaBr3(Ce)|380|63,000|[53]|
|8|LaBr3(5%Ce)|380|66,000|[54]|
|9|CeBr3|380–390|57,000–66,000|[54]|



6 

|10|YAP|370|17,000|[46,55]|
|---|---|---|---|---|
|11|GAGG(Ce)|520|46000|[47]|
||[Gd3Al2Ga3O12:Ce]||||
|12|CsI(Na)|420|38,500|[56]|
|13|YAG|550|16,400|[46]|
|14|CaF2(Eu)|435|24,000|[1]|
|15|SrI2(Eu)|435|85,000|[57]|



## **4.1.2 Radioluminescence spectrum** 

Radioluminescence (RL) is is the wavelength (λsc) or frequency (νsc) distribution of the scintillation light when the medium is excited by ionizing radiation. It is mainly composed of a series of emission bands, and each of them is characterized by the maximum λsc or νsc and half-width Δλsc (Δνsc) at a given temperature. 

## **4.1.3 Energy resolution** 

The energy resolution ( _R_ ) of the scintillation detector is one of the most important parameters for distinguishing between different types of radiation [58]. The energy resolution value (Δ _E_ / _E_ ) is calculated by dividing the peak width at half maximum (Δ _E_ ) of the total peak in the pulseamplitude spectrum by the peak position maximum (E). _R_ can thus be defined as a function of various contributions: _R_<sup>2</sup> =𝑅<sup>%</sup> &' + 𝑅<sup>%</sup> ()* + 𝑅<sup>%</sup> )&+, where _Rnp_ is the factor of non-proportionality. In a few scintillators, the number of emitted photons is not proportional to the absorbed energies that lead to a distribution of the light yield, which deteriorates the value of R. The parameter _R_ inh is associated with the inhomogeneity of the crystal, inducing local variations in the light efficiency. Therefore, it is essential to synthesize defect-free crystals that will exhibit better reflecting properties. The parameter _R_ lim is the ultimate or statistical resolution of the perfect detector, and it 

,-.(01) ~~,~~ where n(PM) denotes the variance of the is determined by the Poisson’s law: _R_ lim =2.35( 3$#" 

photomultiplier (PM) gain and _N_ phe represents the number of photoelectrons emitted by the PM due to scintillation absorption by its photocathode [44,59,60]. 

7 

## **4.1.4 Photon detector efficiency (PDE)** 

The photon detection efficiency (PDE) of a silicon photomultiplier (SiPM) is influenced by the wavelength of the incident light, the applied overvoltage, and the microcell fill factor. In particular, the product of the quantum efficiency (QE), the avalanche-initiation probability (Ɛ), and the microcell fill factor (F) determine the PDE in a SiPM as follows: 



<!-- Start of picture text -->
PDE (λ, V) = QE(λ, V) × Ɛ (V) × F<br><!-- End of picture text -->

Crosstalk and afterpulsing can render the direct measurement of the PDE of a SiPM more difficult. To overcome these issues, the PDE is commonly estimated using the responsivity of the sensor (R), which is defined as the ratio of the measured photocurrent to the incident optical power at a particular wavelength. The PDE can be calculated using the following equation: 



<!-- Start of picture text -->
PDE = (R.h.c)/(e × λ × G)(1 + PXT)(1 + PAP),<br><!-- End of picture text -->

where R is the responsivity, h is Planck's constant (6.626 x 10<sup>-34</sup> m²kg s<sup>−1</sup> ), c is the speed of light (2.998 ´ 10<sup>8</sup> m/s), e is the elementary charge (1.602 ´ 10<sup>-19</sup> C), λ is the wavelength of the incident light, G is the gain, PXT is the crosstalk probability, and PAP is the afterpulsing probability. 

## **4.2 Key parameters in high-energy radiation detectors** 

## **4.2.1 Ionization energy** 

The ionization energy of a scintillator is defined as the minimum energy required to create an e-h pair at the atomic level under high-energy radiation. According to the empirical model proposed by Klein [61], the ionization energy of semiconductor materials can be calculated as follows: 



<!-- Start of picture text -->
Wk  = 2.8 ´ E g +  E phonon<br><!-- End of picture text -->

where _E_ g and _E_ phonon are the bandgap and phonon energy term (0.5 – 1.0 eV) of the semiconductor material, respectively. This empirical formula, which is known as the Klein rule, posits a direct relationship between the ionization energy and the bandgap. In several cases, theoretical predictions using this formula closely match experimental values. For example, Nie _et al._ 

8 

calculated the experimental ionization energy ( _We_ ) of 4.46 eV for a 2D-layered perovskite (BA)2(MA)2Pb3I10 material using the following equation: 



<!-- Start of picture text -->
4×$×ɳ<br>We    =  %<br>&<br><!-- End of picture text -->

where _Φ_ is the photon flux (Ct s<sup>−1</sup> cm<sup>−2</sup> ), _E_ is the X-ray photon energy (eV), ɳ is the absorption efficiency of the material, _Q_ is the total charge density (C cm<sup>−2</sup> s<sup>−1</sup> ), and _q_ is the elementary charge [62]. According to the Klein rule, the predicated ionization energy of (BA)2(MA)2Pb3I10 is 5.54 eV, which is in good agreement with the experimental value. 

## **4.2.2 Detector’s sensitivity and signal-to-noise ratio (SNR)** 

The detector’s sensitivity is the most important figure of merit to evaluate the performance of an X-ray detector for various imaging applications. It is defined as the collected charge _Q_ per unit exposure to high-energy radiation per unit area [63,64]. The X-ray sensitivity ( _S_ ) of a detector can be evaluated as follows: _S_ =Δ _I_ / _DA_ ; where photocurrent Δ _I_ = _I_ light − _I_ dark, _D_ is the dose rate of incident X-ray radiation, and _A_ is the area of the detector [65]. 

The SNR measures the ratio between <mark>the level of a desired signal to the level of background noise</mark> in image processing. This factor plays a key role in determining the image quality of an X-ray detector. The _SNR_ is further divided into two types: input _SNR_ and output _SNR_ [66]. The detective quantum efficiency ( _DQE_ ) can be calculated from the following relation: 



<!-- Start of picture text -->
DQE  = [ SNR out /  SNR in] 2 .<br><!-- End of picture text -->

## **4.2.3 Linear X-ray absorption coefficient** 

The absorption coefficient (µac) is the sum of the mass fraction of all elements in the compound. 



<!-- Start of picture text -->
"!#!$!%!<br>µac=∑𝑓! !𝜇! =<br>"!#!$!<br><!-- End of picture text -->

_i_ denotes the elements of the compound, _fi_ is the mass fraction of element _i_ , _µi_ is the absorption coefficient of element _i_ , _Ni_ is the number of atoms of element _i_ in the compound, and _Ai_ is the atomic weight of element _i_ [62].  For CH3NH3PbBr3 (CNH6PbBr3), the absorption coefficient (µac) can be calculated as follows: 

9 



<!-- Start of picture text -->
7'8'-7(8(-97)8)-7*+8*+-:7,-8,-<br>µac =<br>7'-7(-97)-7*+-7,-<br><!-- End of picture text -->

## **4.2.4 Mobility-lifetime product (** **_μτ_ )** 

The mobility-lifetime product ( _μτ_ ) is a key parameter, that evaluates <mark>the quality of semiconductorbased radiation detectors.</mark> _<mark>μ</mark> τ_ is directly correlated with the mean drift length _λ_ = _μτE_ under an applied electric field _E_ . In fact, the electrons and holes generated by the incident radiation must have a large enough _λ_ to reach the electrodes before recombination. For elemental semiconductors, _μτ_ is in the order of 1 cm<sup>2</sup> V<sup>−1</sup> for electrons and holes, while for compound semiconductors, this value is typically in the order of 10<sup>−4</sup> and 10<sup>−5</sup> cm<sup>2</sup> V<sup>−1</sup> for electrons and holes, respectively. Usually, a _μτ_ product of > 10<sup>−4</sup> cm<sup>2</sup> V<sup>−1</sup> is desirable for detector materials [67–69]. 

## **4.2.5 Charge collection efficiency (CCE)** 

The charge collection efficiency **(** CCE) is an important property of a detector, and it directly influences the performance, in particular, the energy resolution. CCE is the ratio of the electrical charge _Q_ generated in the external circuit to the charge _Q_ 0 generated by the incident radiation on the detector. CCE can be determined by the Hecht equation as follows:[64,70,71] 



<!-- Start of picture text -->
<  = < @<=<br>CCE = 𝑄 >. >"<br>𝑄; =  + 𝜆 𝐿 " /1 −𝑒 3 + 𝜆 𝐿 ? 41 −𝑒 56,<br><!-- End of picture text -->

where, _L_ is the detector thickness, and _λ_ h = _μ_ h _τ_ h _E_ and _λe_ = _μeτeE_ are the mean drift length of holes and electrons, respectively. Hence, CCE strongly depends on _λ_ h and _λe_ , as well as the incoming photon interaction position _x_ (i.e., the distance between the created electrons and holes and the electrodes). Note that under X-ray (or g- ray) irradiation, <mark>the linear attenuation coefficient of the detector material has to be t</mark> aken into account in the CCE equation [71]. 

Some commonly used radiation detectors with their physical properties have been listed in **Table 3.** 

**Table 3.** Physical properties of some radiation detectors [72–74] 

|Material|Bandgap (eV)|Density|(μτ)e(cm<sup>2</sup>V<sup>−1</sup>)|(μτ)h(cm<sup>2</sup>V<sup>−1</sup>)|
|---|---|---|---|---|
|Si|1.12|2.33|>1|∼1|



10 

|Ge|0.67|5.33|>1|>1|
|---|---|---|---|---|
|a-Se|2.2|4.3|0.005 × 10<sup>−6</sup>|0.0014 × 10<sup>−6</sup>|
|TlBr|2.68|7.56|6.5 × 10<sup>−3</sup>|~10<sup>−4</sup>|
|InP|1.35|4.78|5 × 10<sup>−6</sup>|<1.5 × 10<sup>−5</sup>|
|GaAs|1.43|5.32|8 × 10<sup>−5</sup>|4 × 10<sup>−6</sup>|
|PbI2|2.32|6.2|8×10<sup>−6</sup>|9×10<sup>−7</sup>|
|BiI3|1.3|5.78|N/A|N/A|
|α-HgI2|2.15|6.4|8 × 10<sup>−4</sup>|3 × 10<sup>−5</sup>|
|CdTe|1.44|5.85|3 × 10<sup>−3</sup>|2 × 10<sup>−4</sup>|
|CdZnTe|1.57|5.78|2.3 × 10<sup>−2</sup>|2.4 × 10<sup>−5</sup>|
|CdZnSe|2.0|5.5|∼10<sup>−4</sup>|10<sup>−6</sup>|
|CdMnTe|1.73|5.8|>10<sup>−6</sup>|N/A|
|Hg3S2I2|2.25|7.04|1.6×10<sup>−6</sup>|N/A|
|Hg3Se2I2|2.12|7.38|∼1×10<sup>−5</sup>|N/A|
|Hg3Te2I2|1.93|7.58|3.3×10<sup>−6</sup>|N/A|
|Cs2Hg3S4|2.8|6.29|4.2×10<sup>−4</sup>|5.82×10<sup>−5</sup>|
|Cs2Hg6S7|1.63|6.94|1.2×10<sup>−3</sup>|1.0×10<sup>−4</sup>|
|TlGaSe2|1.93|6.4|6×10<sup>−5</sup>|9.2×10<sup>−6</sup>|



## **4.2.6 Leakage currents** 

Leakage currents are generally determined by the electronic band structure of a detector material and device configuration. Actually, the leakage current largely depends on the intrinsic carrier concentration, which is determined by the band gap of the material [75]. Small band gap semiconductor-based detectors should operate at low temperatures to decrease the carrier concentration-dependent leakage current which is an electrical noise source that degrades detection efficiency and energy resolution [76]. Furthermore, impurities and defects can decrease the resistivity of the detector and increase the leakage current noise level [77]. 

## **4.2.7 Polarization effect** 

11 

The term “polarization effect” was coined in the semiconductor detector industry to describe any long-term changes in system performance caused by applied bias. The electric field in the detector can be modified as a result of the polarization effect. As internal fields are created, this often shifts the effect of the applied external field. The CCE of the detector is reduced due to these internal fields. The polarization effect becomes more pronounced as detectors are damaged by radiation over time [70]. The polarization effect can be neutralized in detector materials via heating the detector, alternating the bias polarity, setting the bias off and waiting, illuminating the detector [78]. 

## **4.2.8 Gain factor** 

The gain factor ( _G_ ) of a photoelectric detector can be calculated as follows: 

_G_ = _I_ R / _I_ P, where _I_ R is the measured current, and _I_ P is the theoretical current, _I_ P = _φβe_ . _φ_ is the photon absorption rate (photons s<sup>−1</sup> ), and can be calculated as follows: 



<!-- Start of picture text -->
φ = εDm s  / E ph,<br><!-- End of picture text -->

where _ε_ is the fraction of absorbed photons, _D_ is the dose rate, _m_ s is the crystal mass, and _E_ ph is the X-ray energy. _β_ is the maximum number of carriers generated by a photon and is determined by 



<!-- Start of picture text -->
β  =  E ph /Δ,<br><!-- End of picture text -->

where Δ is the empirical ionization energy [61,79]. 

Therefore, the theoretical current _I_ P can be calculated using the following equation: 



<!-- Start of picture text -->
I P =  φβe  =  εDm s e /Δ.<br><!-- End of picture text -->

## **4.3 Key parameters in X-ray imaging** 

Image quality can be described as the aspect of an image that influences a clinician's confidence in visualizing the right diagnostic features. Computed radiography (CR) and digital radiography (DR) are the most prevalent digital radiographic detectors. The significant components of radiography image quality are spatial resolution, noise, contrast, dynamic range, and artifacts [80]. These components are discussed briefly in this section. 

## **4.3.1 Spatial resolution** 

12 

Spatial resolution is a measure of scintillation performance that describes the ability to separate two points and is quantified as the smallest separation of two points that can be distinguished from each other. The most common method for measuring the spatial resolution is spatial frequency, defined as the number of details that can fit into a given space. The spatial frequency from a linepair resolution test template can be used to calculate the spatial resolution. The spatial resolution is determined by counting cycles or line pairs per unit of distance (millimeters, inches, pixels, or image height). Line pairs per millimeter (lp/mm) is the most common spatial frequency unit, but for digital images, cycles/pixel (C/P) and line width/picture height (LW/PH) are more convenient [81]. 

## **4.3.2 Noise** 

Random or organized variations within a picture that do not correlate to X-ray attenuation variations of the object are referred to as radiographic noise. The noise power spectrum is the most accurate noise metric for determining the noise's spatial frequency content. Image noise is mostly caused by quantum noise, which is determined by the number of X-ray quanta employed to create the image. The great strategy to reduce quantum noise is to control exposure parameters. 

## **4.3.3 Contrast** 

The signal or brightness difference between the structure of interest and its surroundings is referred to as radiographic contrast. Different tissues attenuate X-rays differently, creating contrast. The atomic number, density, and thickness of a tissue are all proportional to radiographic contrast. X- ray attenuation, for example, is lowest in air, highest in bone, and somewhere in between in soft tissues. The contrast in digital radiography can be altered using picture post-processing techniques, in which pixel values are changed to produce the desired range of contrast based on specific clinical requirements. 

## **4.3.4 Dynamic range** 

The dynamic range refers to the range of X-ray intensity that the detector can image. To obtain high-quality digital radiographs, radiographic detectors that give good contrast over a wide dynamic range are required. Wide dynamic range detectors will display very low or very high exposure values in an image, allowing viewers to see various visual intensities. Although 

13 

photographs with a narrow latitude have more visible contrast, extreme exposure intensities appear overly white or black with no discernible contrast. 

## **4.3.5 Artifacts** 

Artifacts are caused by several factors such as uneven magnification, a non-uniform image due to detector issues, poor detector elements, aliasing, and inappropriate grid utilization, leading to poor image quality. 

## **5. How do scintillators and detectors work** 

Depending on their operating mechanism, X-ray detectors can be indirect or direct. This chapter explains and addresses the detection mechanisms for indirect and direct X-ray detectors in detail. In addition, we summarize the key elements used to assess the efficiency of both detector types from a physical perspective. 

## **5.1 Scintillation mechanisms** 

In the scintillation conversion process, three sub-processes occur ( **Figure 1** ): 

(a) **Absorption/multiplication:** In the interaction between electromagnetic radiation and matter, three fundamental mechanisms are involved: photoelectric absorption, Compton scattering, and electron−positron pair formation. Photoelectric absorption is the dominant mechanism at low energy levels (i.e., up to a few hundred keV). However, Compton scattering becomes dominant at energies higher than a few hundred keV. In this situation, the incident high-energy photons only transfer a small portion of their energy, with the rest scattered by the outer shell electron. In photoelectric absorption, an inner shell hole and a primary electron are formed, causing the atom to become ionized. The multiplication of electrons and holes is the next step, which involves various complicated processes, including secondary X-ray, nonradiative decay (Auger processes), and inelastic electron/electron scattering. The mechanisms for e<sup>+</sup> e<sup>−</sup> pair formation can occur above a threshold of 1.02 MeV. In addition to photoelectric absorption and Compton scattering, electron−positron pair formation is favorable for high-Z materials. Electrons continue to lose energy mostly through Coulomb scattering below the threshold for electron−positron pair formation. These processes include a significant number of charge carriers with kinetic energies below the ionization threshold. Electrons and holes 

14 

thermalize to the bottom of the CB and the top of the VB, respectively, at this stage. The entire process takes place on a sub-picosecond scale via carrier-carrier scattering. 

(b) **Energy carrier transport:** At the site of incident radiation absorption and final emission, the radiation-generated electrons and holes do not interact or recombine.  Until they transfer to a luminescence core, many electrons and holes first migrate within 10<sup>-12</sup> to 10<sup>-8</sup> s in the transport stage. Trap states are crucial at this point. If there are many trap states in a scintillation material, the scintillation process will be less efficient. Migrating charge carriers may be caught by defects such as ionic vacancies and grain boundaries in scintillator materials or become selftrapped in the crystal lattice, resulting in nonradiative losses and possible radiative recombination delays during the transport stage. These defects must be effectively suppressed by improving the crystal growth and/or surface morphology of the scintillation material. Large crack-free SCs will thus be extremely useful in enhancing scintillation performance. 

(c) **Relaxation/emission:** The emission process, in which scintillation photons are emitted, is the final stage. The energy stored in an excited emitting center can be released in two ways: by emitting a photon or through non-radiative processes. Radiative photon emission can occur via the recombination of electrons and holes or the interaction of energetic secondary electrons with luminescent ions. These secondary electrons are highly effective if they reach as many luminescence centers as possible. Secondary electron dispersion has a spatial size of ~100 nm. There are around 10<sup>9</sup> atoms in an incoming radiation quantum of 1 MeV within a volume of 100 nm<sup>3</sup> , and the number of secondary electrons is around 10<sup>5</sup> . Direct electron−hole recombination is common in semiconductor-based scintillators such as ZnO and lead HPs. Activator-type scintillators, such as Ce-doped materials, on the other hand, rely heavily on the excitation of luminescent ions. The number of photons _N_ ph produced according to the energy of the incoming particle determines the overall conversion efficiency: _N_ ph = _N_ e/h _SQ_ = ( _E_ incident / _E_ e/h) _SQ_ = ( _E_ incident /β _E_ g) _SQ_ , where the number of electron−hole pairs generated during the multiplication stage, the efficiency with which an energy carrier can excite a luminescent center, and the QE of the luminescent center are represented by _N_ e/h, _S_ , and _Q_ , respectively. The energy of the incident particle and that required to create a thermalized electron−hole pair, respectively, are _E_ incident and _E_ e/h. The bandgap of the material ( _E_ g) with the proportional constant β (varying between 2 and 3) is equal to _E_ e/h. It is important to note that the scintillation 

15 

mechanism described above only applies to inorganic scintillators; that for organic or noncrystalline scintillators can be more complicated. 

## **5.2 Direct X-ray detection mechanism** 

A bulk semiconductor absorbs x-ray photons, forming a charge cloud in the material. Defect states can trap excited electrons (holes), allowing the holes to traverse between electrodes many times before recombination. To store and process the collected charges into signals, a thin-film transistor (TFT) or complementary metal oxide semiconductor (CMOS) array is required. The TFT-based flat panel detector (FPD) is widely used in X-ray imaging applications, such as optical radiography and mammography. 



**FIGURE 1.** Mechanism of indirect detectors (scintillators) and direct detectors for high-energy radiation and particles. 

## **6. Growth strategies for high-quality SCs** 

HP SCs have attracted the interest of researchers due to their ease of development and potential commercial use as scintillators and radiation detectors. Many methods for growing perovskite 

16 

SCs with various compositions, sizes, and exposed facets have been reported ( **Figure 2** ). The benefits of these approaches and their general processes are presented in this chapter. 

## **6.1 Inverse temperature crystallization (ITC)** 

Bakr et al. proposed the ITC method to synthesize lead HP SCs [82]. The solubility of perovskite decreases in some solvents with increasing temperature. γ-butyrolactone (GBL), dimethyl sulfoxide (DMSO), and N, N-dimethylformamide (DMF) are suitable solvents for MAPbI3, MAPbCl3, and MAPbBr3, respectively, whereas DMSO is the best solvent for growing inorganic CsPbBr3 SCs using ITC. The growth temperature and precursor concentration heavily influence the quality and production yield of SCs. In ITC, large-sized crystals can be grown faster by introducing a crystal seed to the saturated precursor solution. This is attributed to the critical Gibbs free energy G* required for nucleation [83]. As a result, crystallization begins spontaneously from the seed. Otherwise, the crystal will spontaneously dissolve. Therefore, a crystal seed should be introduced to grow large, high-quality SCs. ITC is convenient for growing multi-component HP SCs such as MAxFA1–xPbI3 SCs [84]. 

## 6 **.2 Anti-solvent vapor-assisted crystallization (AVC)** 

The AVC approach uses the solubility of the precursor solution in various solvents to generate high-quality SCs in a repeatable and temperature-independent manner. Bakr’s group developed a method to generate crack-free MAPbBr3 SCs with a volume of more than 100 mm<sup>3</sup> [85]. When a precursor is placed in a sealed bottle containing an antisolvent, the solubility drops as the antisolvent diffuses into the precursor solution, causing crystal formation. In general, solvents such as DMF, γ-butyrolactone (GBL), and DMSO should dissolve precursors, whereas MAPbX3 SCs should be insoluble in antisolvents such as DCM, acetonitrile, and chlorobenzene (CB). With this approach, SCs produced with a PbBr2/MABr molar ratio of 1.0 may change from transparent to opaque. This is attributed to the large difference in solubility between MABr and PbBr2 in DMF. PbBr2 precipitates faster than MABr after the antisolvent has consumed the majority of the DMF solvent, which could result in non-stoichiometric MAPbBr3 or surface contaminants. Wei _et al_ . employed a molar ratio of 0.8 to overcome this problem, ensuring that there was always more MABr than PbBr2 in the solution [20]. This resulted in the formation of clear SCs (1–6 mm) that were used for the fabrication of X-ray 

17 

detectors. All-inorganic CsPbBr3 SCs were also prepared using the AVC approach [86]. The atomic usage efficiency of raw materials can be considerably improved using AVC, which is also useful for eliminating temperature-dependent phase transitions, convective current disturbances, and potential lattice disorder generated by MA<sup>+</sup> solvation during crystal formation because it does not require heat. However, AVC has the disadvantage of being difficult to scale up for industrial uses and it has lower reproducibility than other methods. 

## **6.3 Bridgman growth** 

Perovskite precursors are heated in a silica tube for Bridgman growth above the melting point of precursors and held at that temperature for a longer time to avoid heterogeneous nucleation and suppress the formation of structural defects [29]. The ingot is then cooled slowly to room temperature. Cracks and the fracturing of the ingot are likely to result from an excessively high temperature gradient and a reduction in speed and cooling rate. Therefore, these parameters should be considered to obtain better-quality SCs that can be used as scintillators and detectors. 

18 



**FIGURE 2.** Various methods for synthesizing perovskite SCs. (A) the AVC method and (B) MAPbBr3 SCs synthesized using AVC. Reproduced with permission [87]. (C) The Bridgman method and (D) CsPbBr3 SCs fabricated using the Bridgman method. Reproduced with permission [29]. (E) The ITC method and (F) MAPbX3 SCs (X =Cl or Br or I) produced using the ITC method. Reproduced with permission [88]. (G) The STL method and (H) MAPbI3 SCs grown using the STL method. Reproduced with permission. Figure 3H (right) [89]  and 3H (left) [90]. 

19 

In the Bridgman method, raising the temperature above the melting point is helpful for raw materials with low solubilities, such as all-inorganic perovskites, despite the long growth time and significant energy consumption needed. However, this process necessitates using a particular Bridgman furnace, which limits its applicability. 

## **6.4 Solution temperature lowering (STL)** 

Weber’s methodology, which makes use of the variation in the solubility of the perovskite precursor in different solvents at varying temperatures, is the basis for the STL method. In this method, the precursors are dissolved in polar solvents at high temperatures and then slowly cooled to room temperature to obtain perovskite SCs. This process has been adopted to produce SCs that have been used in scintillators and detectors. In a typical example of the synthesis of MAPbI3 SCs using STL, lead(II) acetate trihydrate and methylammonium iodide were combined in a hydriodic acid solution at 65 °C. When the temperature was reduced from 65 to 40 °C, the solution became saturated, and well-shaped MAPbI3 SCs with 10 mm × 10 mm × 8 mm were produced [89]. 

## **7. Fabrication of samples for scintillation, radiation detection, and X-ray imaging** 

X-ray beams are extremely difficult to focus, diffract, or mirror in comparison to visible light, so large-area panels are needed for X-ray imaging. Metal HP (MHP)-based detectors can be easily rendered using various low-cost techniques, such as direct growth by solution processing on Si wafers, printing, conformal attachment, and isostatic pressing [91].  Herein, we discuss various sample fabrication methods for scintillation, direct radiation detection, and imaging. 

## **7.1 Fabrication methods for scintillation and imaging** 

For indirect‐type X‐ray detectors, terbium‐doped GOS (Gd2O2S:Tb) and CsI:Tl materials are commonly being used as a scintillator. Heo _et al_ . developed a cost-effective CsPbBr3 perovskite nanocrystal (PNC) scintillator and demonstrated high‐performance detectors with high spatial resolution, sensitivity, and stability for indirect X-ray detectors. The CsPbBr3 nanocrystal (NC) 

20 

film was fabricated by spin coating on a glass substrate, and the obtained film was then directly paired with CMOS arrays and Si PDs ( **Figure 3A, B** ) [92]. The CsPbBr3 NC-based X‐ray 



**FIGURE 3** . Fabrication of CsPbBr3 NC-based X‐ray detectors. (A) Schematic diagram of an X- ray detector configuration showing carbon fiber reinforced polymer (CFRP) film/scintillator film/arrayed Si-PDs module. (B) Photograph of CsPbBr3 NCs integrated with Si-PDs-arrays for X-ray module. Reproduced with permission [92] (C) Experimental setup for real-time X-ray diagnostic imaging of biological samples. A beetle is placed between the X-ray source and a scintillation platform made of perovskite QDs. (D) and (E) Beetle's Bright-field and X-ray images, respectively, captured with a digital camera. Reproduced with permission [30]. 

detector exhibits superior spatial resolution (9.8 lp mm<sup>−1</sup> at modulation transfer function (MTF) = 0.2 and 12.5–8.9 lp mm<sup>−1</sup> for a linear line chart), a faster response time (~200 ns), and comparable stability compared to the commercialized GOS-based detectors. The solution processability of PNCs allows for the production of a thin-film scintillator device for ultrasensitive X-ray detection. 

21 

Spin-coated CsPbBr3 NCs are used for an X-ray sensing system, transforming high-energy X-ray photons into visible light that may be detected by a PMT. Chen _et al._ fabricated an X-ray scintillation detector by first covering a polydimethylsiloxane (PDMS) substrate with perovskite quantum dots (QDs) and then attaching a PMT for maximum visible photon collection ( **Figure 3C-E** ) [30]. Direct X-ray contrast imaging using high-efficiency PNCs is easily suited to highthroughput electronics inspection and tissue imaging, where standard digital cameras can be employed. 

## **7.2 Fabrication methods for radiation detection** 

X-ray beams are very difficult to concentrate, diffract, and reflect, compared to the visible light, and panels with a large area are thus needed for X-ray beam imaging. MHP detectors can be fabricated easily through different low-cost methods, for example, direct growth through solution processing on Si wafers, printing, conformal attachment, and isostatic pressing. The solutionprocessed photodetector techniques such as doctor blading, inkjet printing, spin-coating, and spray-coating have many manufacturing advantages (such as ease of processing) and efficient performance for various applications [91]. Other scalable methods for MHP detectors have also been developed to improve their efficiency. Kim _et al_ . [27] fabricated an 830 μm-thick polycrystalline MAPbI3 (MPC) photoconductor layer sandwiched between polymer/perovskite composites, demonstrating high a µτ product of 1×10<sup>−4</sup> cm<sup>2</sup> V<sup>−1</sup> and good X-ray sensitivity of 11 µC mGyair<sup>−1</sup> cm<sup>–2</sup> ( **Figure 4** ). Wei _et al_ . [24] added a layer of brominated (3-aminopropyl) triethoxysilane (APTES) molecules to connect the MHP perovskite and Si wafers through primary chemical bonds. The APTES molecule binds with the native oxide (–OH) on the Si wafer via a condensation process to form strong covalent Si–O–Si bonds, and the APTES molecule assists in the perovskite crystal with its ammonium bromide group to prepare the Si-integrated MAPbBr3 SC device using a low-temperature solution-processed molecular bonding method ( **Figure 5** ) [24]. 

22 



**FIGURE 4.** Hybrid perovskites are being used to create an X-ray detector. (A) All-solutionprocessed digital X-ray detector. (B) Spin-cast polyimide (PI)-MAPbI3 on a-Si:H TFT backplane (left panel). Inset: Single-pixel structure of TFT (scale bar 30 µm). Printed MPCs on PI-MAPbI3 (right panel). (C) Charge collection and sensitivity of MPC detector measured at 100 kVp. Inset: hole-h pair generation energy ( _W_ ±) in the pixelated (blue triangles) and diode (red triangles) detectors. (D) Hand phantom X-ray image obtained using MPC detector. Reproduced with permission [27]. 

Yang _et al_ . [93] used an isostatic-squeezing strategy to incorporate Cs2AgBiBr6 wafers with upscaling ability, fulfilling the criteria for a large-area imaging application. They used an isostaticpressing method, which does not require a solvent during the Cs2AgBiBr6 film fabrication process and produces a highly compact and pinhole-free Cs2AgBiBr6 wafer. The Cs2AgBiBr6 crystals in the form of ball-milled powder were fitted into a pie-shaped mold through a compressor, and 

23 

consequently, a pressure of 200 MPa was applied through a hydraulic press. Consequently, the device showed a remarkable sensitivity of 250 µC Gyair<sup>−1</sup> cm<sup>–2</sup> , and a spatial resolution of 4.9 lp mm<sup>−1</sup> [93]. 



**FIGURE 5.** SCs of Si-integrated MAPbBr3 and device properties. (A, B) Si-integrated MAPbBr3 SCs attached through APTES. (C) MAPbBr3-based X-ray detector configuration. (D) Dark current and photocurrent density of the Si-integrated MAPbBr3 SC device and (E) MAPbBr3 SC device with Au-anode (control device). Reproduced with permission [25]. 

Shrestha _et al_ . [25] fabricated a MAPbI3 wafer-based photodetector by applying 15 MPa for 2 min using a hydraulic press, and the device showed a remarkable conversion efficiency of 2,527 µC Gyair<sup>−1</sup> cm<sup>−2</sup> under 70 kVp X-ray exposure. Zhao _et al_ . [94] developed a new approach for flexible X-ray detectors. They developed a new fabrication method for large-area and flexible perovskite membranes with an area of 400 cm<sup>2</sup> by infiltrating saturated perovskite solution via porous polymer membranes by vacuum pumping, followed by hot lamination. The fabricated X-ray 

24 

detector reached a sensitivity of 8,696 ± 228 µC Gyair<sup>−1</sup> cm<sup>–2</sup> . Recently, Xu _et al_ . [95] developed an ultra-flexible sandwich structure thin film scintillation screen synthesized by spin-coating that showed high sensitivity and low-cost, stable  X-ray imaging. They obtained a flexible scintillation screen with a three-step process. First, they spin-coated a thin polymer layer onto quartz substrates. Then MAPbBr3 perovskite QDs solution was spin-coated on the polymer surface. Finally, a polymer surface was coated on top of the perovskite layer. Ultimately, the polymer-perovskite QD-polymer (PPP) scintillation screen was peeled off from the substrate for different measurements. 

## **7.2.1 Electronic integration and encapsulation methods** 

X‐ray imaging detectors based on currently available approaches can be classified into directand indirect-type X-ray detectors. For direct detection, the electrical contact between perovskites and front-end circuits should be considered and for indirect detection, perovskite scintillators should be coupled with photosensors [92,96]. For indirect‐type X‐ray detectors, GOS and CsI:Tl materials are commonly used as scintillators [97–99]. Heo _et al._ [92] developed a cost-effective CsPbBr3  NCs scintillator and demonstrated a high‐performance indirect-type X-ray detector with high spatial resolution, sensitivity, and stability. The CsPbBr3 NC film was fabricated by spincoating on a glass substrate and the obtained film was then directly paired CMOS arrays and SiPDs. The CsPbBr3 NC-based X‐ray detector exhibited a higher spatial resolution of 9.8 lp mm<sup>−1</sup> at modulation transfer function (MTF) = 0.2, a faster response time and comparable stability compared with the commercialized GOS:Tb, based detectors [92]. To protect perovskite scintillators from both mechanical and chemical damages and enhance their stability under ambient conditions, encapsulation is crucial for MHP X-ray detectors. Encapsulation materials should be highly transparent to high-energy X- and g-rays. Polymer and thin-film encapsulation (TFE) are suitable for traditional radiation detectors [100]. Polyethylene terephthalate (PET), polytetrafluoroethylene (PTFE), poly(methyl methacrylate) (PMMA), etc. are among the commonly used polymers for encapsulation in MHP X-ray detectors. The layer of Al2O3 or SiO2 for encapsulation can be provided by various TFE processes, like chemical vapor deposition (CVD), plasma enhanced chemical vapor deposition (PECVD), physical vapour deposition (PVD), and atomic layer deposition (ALD) [101]. Furthermore, many researchers have also used metal foils for encapsulation: for example, Rocha _et al_ . [102] encapsulated CsI:Tl scintillators by 

25 

aluminum walls. Zhang _et al_ . [103] successfully fabricated a highly efficient X-ray detector based on Cs2AgBiBr6 film encapsulated with a 100-μm-thick Be window. The resulting Cs2AgBiBr6 device showed efficient X-ray detection with a low dose rate of 145.2 nGyair s<sup>−1</sup> and a detection sensitivity of up to 1.8 × 104 µC Gyair<sup>−1</sup> cm<sup>−2</sup> . 

## **8. Different dimensional perovskites and their scintillation performance** 

This section presents a detailed discussion of the different dimensional perovskites and related materials used for radiation detection. 

## **8.1 Organic-inorganic 3D perovskites (MAPbBr3, MAPbI3, FAPbI3)** 

The 3D ABX3 perovskite structure is made up of a continuous network of corner-sharing [BX6]<sup>4-</sup> octahedra with A-site cations filling in the gaps. Since the light yield of X-ray scintillation is inversely proportional to the optical bandgap, perovskite crystals have many advantages in this application. Low-bandgap perovskites MAPbI3 (1.51 eV) and MAPbBr3 (2.18 eV) have theoretically calculated photon yields of about 270,000 and 190,000 photons MeV<sup>-1</sup> , respectively, which are higher than the current state-of-the-art cerium (Ce<sup>3+</sup> ) doped lanthanum tribromide LaBr3 (Eg = 5.90 eV) [104] and Ce<sup>3+</sup> doped lutetium iodide LuI3 (Eg = 4.15 eV) scintillators [105], which have light yields of 61,000 and 50,000 photons MeV<sup>-1</sup> . Birowosuto _et al_ . studied the X-ray scintillation properties of MAPbI3 and MAPbBr3 SCs synthesized by the slow evaporation and the ITC methods, respectively [22]. Since charge carriers are trapped and detrapped under high-energy excitation, scintillators often generate delayed luminescence or afterglow. To study the trap states, low-temperature thermoluminescence measurements were performed on these SCs. Both crystals have good consistency, with a low density of shallow traps and no deep trap states, resulting in a substantial reduction in afterglow. At room temperature, the light yields of MAPbI3 and MAPbBr3 are approximately 1,000 photons MeV<sup>-1</sup> , while at 10 K, they are 296,000 and 152,000 photons MeV<sup>-1</sup> , respectively [22]. The exciton binding energy of MAPbBr3 and MAPbI3 is in the range of 2–70 meV [106]. In 3D perovskites, loosely bound excitonic states are far more susceptible to thermal quenching than tightly bound excitons in 2D perovskites. Thus, 3D perovskite crystals need to operate at much lower temperatures than 2D crystals to achieve optimum scintillation efficiency. The development of high-performance scintillators that can operate properly at cryogenic temperatures is critical for various practical applications. The efficiency of a scintillator 

26 

generally degrades as the temperature drops. Because of their excellent stability and optical properties at low temperatures, Mykhaylyk _et al._ demonstrated that APbBr3 SCs are a promising material for radiation detection [107]. For hard radiation, MAPbI3 SCs also had a good spectral response and a low dark current [107]. The optical and electronic properties of HPs can be modulated using doping and compositional engineering. At room temperature, Xu and colleagues published a series of studies on the scintillation properties of MAPbCl3-xBrx crystals [108–110]. 

## **8.2 Organic-inorganic 2D perovskites** 

2D perovskites have the general formula L2MX4 where L is a large monocation  (e.g., butylammonium (BA), hexylammonium, phenylethylammonium (PEA)), M is a dication (e.g., Sn<sup>2+</sup> and Pb<sup>2+</sup> ) and X is a halide ion. An inorganic layer is sandwiched between two large organic spacer layers in 2D perovskites. These perovskites have much better intrinsic stability and resistance to humidity than their 3D counterparts because of their higher formation energy and the hydrophobic nature of organic cations. 2D perovskites have been proposed and researched since the 1990s [111]. However, Asai _et al_ . were the first to record the 2.0 MeV proton bombardment of 2D (C6H13NH3)2PbI4 thin-films in 2002 [15]. At room temperature, the decay times of (C6H13NH3)2PbI4 and (C3H7NH3)2PbBr4 were significantly faster than those of many standard inorganic scintillators. Both 2D crystals, however, had thicknesses of less than 0.3 mm. It is worth noting that when it comes to detecting high-energy radiation, thickness is crucial. Scintillators with substantial area and thickness are needed for use in a g-ray or fast-neutron detector. To increase the thickness of 2D crystals, Koshimizu _at el._ used aromatic ammonium achieving the thickness more than 1 mm [17]. They synthesized 5×6×1 mm<sup>3</sup> SCs of (C6H5(CH2)2NH3)2PbBr4 that exhibited a light yield of 10,000 photons MeV<sup>−1</sup> , measured at 662 keV g-ray energy. However, under pulsed X-ray excitation, its main decay time was 9.4 ns, which is comparable to that of (C6H13NH3)2PbI4. When irradiated with g-rays or X-rays, the absorbed energy of the inorganic layer is much higher than that of the organic layer, so the scintillation properties of organic–inorganic layered perovskite-type compounds are mainly based on inorganic layer exciton properties. Furthermore, the luminescence of perovskites is dominated by two structural distortions: (i) the Pb-Br-Pb bridging bond linking two adjacent [PbBr6]<sup>2-</sup> and (ii) the Br-Pb-Br bond of [PbBr6]<sup>2-</sup> . These structural distortions in perovskites make them ideal for γ-ray detection. Kawano _et al_ . recently 

27 

published an antisolvent diffusion method for synthesizing large (C6H5(CH2)2NH3)2PbBr4 crystals (17×23×4 mm<sup>3</sup> ) that had structural distortions and it showed excellent scintillation properties exhibiting a high light yield of 14,000 photons MeV<sup>-1</sup> under γ-rays and fast response of 11 ns [112]. To increase the structural distortions and light yield, Horimoto _et al._ introduced F on the benzene ring of C6H5(CH2)2NH3 at the ortho, meta, and para positions individually and synthesized [n-FC6H4(CH2)2NH3]2PbBr4 {n-FPhe = FC6H4(CH2)2} (n = 2, 3, 4) crystals [113]. Under g-ray irradiation, however, the light yield was around 3,300 (2-FPhe), 12,000 (3-FPhe), and 8,300 photons MeV<sup>−1</sup> (4-FPhe), which was still lower than that of (C6H5(CH2)2NH3)2PbBr4 crystals. Several metal ions (e.g., Sr<sup>2+</sup> , Ba<sup>2+</sup> , Mn<sup>2+</sup> , and Li<sup>+</sup> ) have been incorporated in the inorganic layers to improve the light yield. Akatsuka _et al_ . doped Sr<sup>2+</sup> in (C6H5(CH2)2NH3)2PbBr4 [(C6H5C2H4NH3)2Pb1−xSrxBr4] achieving the scintillation light yields of 19,700 and 18,500 photons MeV<sup>−1</sup> for x = 0.1 and 0.25 samples [114], respectively which are better than that of pure (C6H5(CH2)2NH3)2PbBr4 crystal [113]. A series of Mn<sup>2+</sup> -doped L2PbBr4 [L = n-BA, n-OA, and stearammonium (STA)] was synthesized to improve the light yield [43]. Dopant Mn<sup>2+</sup> has two advantages: (i) capturing energy from trap states in perovskites and (ii) removing photon loss as the Mn emission photon energy (2 eV) is lower than that of 2D perovskites (3.1 eV). Water-stable Mn-doped STA2PbBr4 exhibited the highest light yield of ∼24,000 photons MeV<sup>−1</sup> among the three Mn-doped 2D perovskites ( **Figure 6** ). Due to the high hydrophobicity of STA organic cation, Mn<sup>2+</sup> -doped STA2PbBr4 showed excellent stability in water. Generally, 3D perovskites are highly unstable in water [115] which is commonly used as a coolant or reaction moderator in nuclear reactors.  In this case, Mn<sup>2+</sup> -doped STA2PbBr4 will be highly beneficial for practical applications. 

28 



**FIGURE 6.** (A) Schematic diagram of aqueous synthesis of Mn-doped 2D perovskites. Inset: Mn<sup>2+</sup> -doped STA2PbBr4 under UV light. (B) RL spectra of ZnS(Cu) and Mn<sup>2+</sup> -doped STA2PbBr4 (2D HP). Reproduced with permission.[43] 

Alkali metal ions can also enhance the light yield of 2D perovskites. Birowosuto _et al._ doped (PEA)2PbBr4 with Li-ions. The light yields of undoped and doped crystals were 8,000 ± 800 photons MeV<sup>−1</sup> and 11,000 ± 500 photons MeV<sup>−1</sup> , respectively [116]. Later, they found that Li-doping enhanced the light yield of (PEA)2PbBr4 compared to BA2PbBr4 [117]. The Lidoped perovskite crystals showed very fast g-ray excited scintillation decay, with average decay times of 12.9 ns and 8.0 ns for PEA2PbBr4 and BA2PbBr4, respectively. The same group also reported a library of 2D HPs and studied their scintillation properties. Among them, BA2PbBr4 showed a maximum light yield of 40,000 photons/MeV and rapid decay of 5.3 ns [118]. Although monovalent alkylammonium cation-based 2D perovskites have been studied extensively as scintillators, diammonium cation-based 2D perovskites have rarely been explored. Recently, Birowosuto _et al_ . reported (EDBE)PbCl4 2D perovskite crystals (EDBE = 2,2′-(eth-ylenedioxy)bis(ethylammonium)) with a light yield of 9,000 photons MeV<sup>−1</sup> , whereas 

the light yields of 3D MAPbI3 and MAPbBr3 crystals were below 1,000 photons MeV<sup>−1</sup> [22]. 

29 

## **8.3 All-inorganic 3D perovskite (CsPbBr3, CsPbI3)** 

All-inorganic 3D perovskites have shown promising light yield under high-energy radiation ( **Table 4** ). Since Voloshinovskii _et al_ .’s [119] first observation of the very fast and intense X-ray luminescence of excitons in CsPbX3 (X = Cl, Br, I) at low temperatures in 1993, researchers have been looking into the scintillation properties of all-inorganic halide perovskite SCs. In 2008, Kobayasi _et al_ . reported the scintillation properties of CsPbCl3 SCs, which showed a low light yield of ~300 photons MeV<sup>−1</sup> under γ-ray excitation [120]. At a low temperature (7K), CsPbBr3 SCs exhibited a light yield of 50,000 photons MeV<sup>−1</sup> under 12 keV X-ray irradiation [121]. Along with SCs, CsPbX3 NCs also show promising scintillation properties. In 2017, Wang Chen _et al_ . first explored the scintillation properties of these NCs in different solvents, concentrations, and excitation intensities [122]. Qiushui Chen _et al_ . reported the fabrication of multicolor, highefficiency X-ray scintillators using a series of CsPbX3 NCs [30]. The spin-coated CsPbBr3 nanocrystal film has a low detection limit of 13 nGy s<sup>−1</sup> , which is around 420 times lower than expected for standard medical diagnostics (5.5 μGy s<sup>−1</sup> ). Under excitation by a<sup>137</sup> Cs source (661 keV), this scintillator responds quickly (44.6 ns), suitable for X-ray imaging applications. For this purpose, the authors constructed a simple X-ray imaging system consisting of a CsPbBr3 NC-based background substrate, a digital camera, an α-Si PD array, and a TFT sensor panel, and successfully took an X-ray image of a biological specimen (i.e., a beetle) with a metallic needle. 

30 



**FIGURE 7.** CsPbBr3 based liquid scintillator. (A) Schematic diagram showing CsPbBr3 NCs hybridized with PPO. (B) RL spectra of PPO and PPO-CsPbBr3 NCs. The RL intensity of PPOCsPbBr3 NCs is much higher than those of only PPO and CsPbBr3 NCs. (C) X-ray FPD. PPOCsPbBr3 NCs dispersed in octane were placed between two quartz windows. (D) Photographs of data storage device on liquid scintillator and X-ray images. (E) Images of the Leeds test objects. (F-H) Line profiles on the line-pair phantom along the yellow lines in Fig. 4E. lp/mm is indicated by numbers (0.63-5). lp/mm: line pair per millimeter. (I-K) Edge spread function (ESF) across 

31 

edge of phantom (red box in the inset image). G/P: grey value/pixel. Reproduced with permission [33]. 

At a spatial resolution of 2.0 lp mm<sup>−1</sup> , this detector has an MTF value of 0.72, better than that of CsI:Tl-based detector (MTF value of 0.36 at 2.0 lp mm<sup>−1</sup> ). One of the most important features of X-ray image detectors is a large active region, which must be larger than objects such as a patient’s body part. On the other hand, spin-coating makes it challenging to make large-area PNC films. Zhang _et al_ . described the use of a highly concentrated CsPbBr3 nanosheet by the self-assembly phenomenon for the fabrication of a crack-free thin film with a surface area of 72 cm<sup>2</sup> [123]. Under X-ray illumination, scintillators made from these nanosheets have high RL and long-term stability. Moreover, the light yield of this scintillator film is higher (21,000 photons MeV<sup>−1</sup> ) than that of the commercially available Ce:LuAG single-crystal scintillator (18,000 photons MeV<sup>−1</sup> ). The excellent scintillation output is due to an energy transfer mechanism within the self-assembled CsPbBr3 nanosheets. Cho _et al._ reported a liquid scintillator made up of CsPbX3 (A: Cl, Br, I) NCs hybridized with PPO that can be used for high-resolution X-ray imaging ( **Figure 7)** [33]. The hybrid scintillator showed superior spatial resolution with an lp mm<sup>−1</sup> of at least 3.5, significantly higher than pure HP NCs and PPO scintillators. 

**Table 4.** Scintillation properties of all-inorganic 3D perovskites 

|Materials|Light yield<br>( photons MeV<sup>−1</sup>)|Decay time (excition source)|Ref.|
|---|---|---|---|
|CsPbCl3SC|330|0.30, 5.6 ns (X-ray)|[120]|
|CsPbCl3SC|∼1,200|0.39, 7.0 ns (X-ray)|[124]|
|CsPbBr3SC|∼50,000 (7 K)|∼1 ns (X-ray)|[121]|
|CsPbBr3NCs|-|2.87 ns (285 nm)|[92]|
|CsPbBr3NCs|-|44.6 ns (<sup>137</sup>Cs, 661 keV)|[30]|



32 

|PPO + CsPbBr3NCs|~ 10 photons keV<sup>-1</sup>|60−100 ns (g-ray)|[33]|
|---|---|---|---|
|CsPbBr3nanosheets|∼21,000|1−10 ns (410 nm)|[123]|
|CsPbBr3@Cs4PbBr6<br>powders|-|3 ns (375 nm)|[125]|
|CsPbBr3@Cs4PbBr6NCs|64,000|< 10 ns (59.5 keV from<sup>241</sup>Am)|[126]|
|CsPbBr3NCs@PMMA|∼9,000|3.4 - 14.1 ns (400 nm)|[32]|



## **8.4 0D-3D all-inorganic perovskite** 

The combination of 0D-3D perovskite materials such as CsPbBr3@Cs4PbBr6 has been proven to be an effective method for improving scintillation properties. The CsBr bridges completely separate the [PbBr6]<sup>4–</sup> octahedrons in the Cs4PbBr6 crystal structure, creating 0D perovskite, whereas [PbBr6]<sup>4–</sup> octahedrons are connected in all three directions, forming 3D CsPbBr3. While 3D HP NCs are promising, with high scintillation efficiency at room temperature, they are unstable under high-energy irradiation, not only because of their inherent sensitivity to multiple environmental factors such as light, heat, and moisture but also because of well-known aggregation and phase transition issues [126]. As a result, achieving high scintillation efficiency and stable X- ray irradiation performance in HPs is still a difficult task. The “emitter-in-matrix” type material could solve these issues if it has the following properties: (i) the emitter must lead to highefficiency RL, (ii) the matrix must stop X-rays maintaining high material stability, and (iii) the host must be optically transparent to the emission from the embedded emitter in order to avoid photon loss. For improved stability and performance, Cao _et al._ synthesized a CsPbBr3@Cs4PbBr6 “emitter-in-matrix” structure where CsPbBr3 NCs were embedded inside the Cs4PbBr6 crystal matrix ( **Figure 8** ) [125]. The Cs4PbBr6 matrix increased X-ray attenuation and the stability of the 

33 



**FIGURE 8.** (A) CsPbBr3@Cs4PbBr6 and schematic diagram of band gap of both 0D and 3D perovskites. The transparent matrix and light emitter were Cs4PbBr6 and CsPbBr3, respectively. (B) RL and absorption spectra of CsPbBr3@Cs4PbBr6. (C) A low-cost blade-coating process was 

34 

used to create a large-area film of CsPbBr3@Cs4PbBr6. (D) X-ray imaging set-up. The X-ray source and the sensing component were separated by the target material. The scintillation film was covered on an electron-multiplying CCD to provide the sensing component. (E) Image of a capsule with a metal spring inside and X-ray image using CsPbBr3@Cs4PbBr6. The scale bar is 1.5 mm. Reproduced with permission [125]. 

embedded CsPbBr3 NCs. The wide-band-gap Cs4PbBr6 was also transparent to the green emission of CsPbBr3 NCs, minimizing photon loss caused by self-absorption (or photon recycling). As an X-ray projector, a large-area film of CsPbBr3@Cs4PbBr6 with a size of 360×240 mm<sup>2</sup> was fabricated, allowing a clear picture of an unseen internal structure to be viewed with high quality, demonstrating its great potential for practical use. Xu _et al._ fabricated a similar composition (CsPbBr3/Cs4PbBr6), showing that the CsPbBr3/Cs4PbBr6 material possesses excellent radiation hardness and high air stability [126]. The light yield of CsPbBr3/Cs4PbBr6 was about 64,000 photons MeV<sup>−1</sup> , which is around 168% that of NaI:Tl and 156% that of CsI:Na. 

## **8.5 Lead-free 3D double perovskites** 

While organic-inorganic hybrid lead HPs have shown promise as scintillators, their strong selfabsorption, relatively low light yield, and lead toxicity make it necessary to substitute lead and volatile organic counterpart. Hence, nontoxic perovskites with a high scintillation light yield against high-energy radiations are desired. In addition, lead HPs often exhibit ionic migrations under an electrical field, resulting in baseline drift, increased noise, and thus signal difficulty. Indirect radiation detection using metal HPs could eliminate the ionic migration issue. By forming a double perovskite structure A2B′B′′X6, in which A is Cs, B′ is a monovalent metal (Ag<sup>+</sup> , Na<sup>+</sup> , 

etc.), B′′ is a trivalent metal (Bi<sup>3+</sup> , In<sup>3+</sup> , etc.), and X is a halide, lead can be replaced with heterovalent metals. Because of their all-inorganic constituents, these materials typically have strong thermal and moisture stability, indicating that they may be used in optoelectronic devices. Using a hydrothermal process, Tang group created lead-free double perovskite crystals based on lanthanides (Cs2NaTbCl6 and Cs2NaEuCl6) [127]. The light yield of Cs2NaTbCl6 under X-ray radiation was 46,600 photons MeV<sup>−1</sup> , which is substantially higher than that of lead-based HPs. 

35 

Reducing the self-absorption effect is the most effective way to improve light yield. The selfabsorption effect can be reduced by using double perovskites with a large Stokes change between the radioluminescence (RL) and absorption spectra that gain from self-trapped excitons (STEs). Zhu _et al_ . described a series of nontoxic double-perovskite scintillators made of Cs2Ag0.6Na0.4In1yBiyCl6 in which the X-ray absorption coefficient, radiative emission efficiency, light yield, and light decay were all manipulated by changing the heavy atom Bi<sup>3+</sup> material ( **Figure 9** ) [128]. Due to its negligible self-absorption effect, the light yield of Cs2Ag0.6Na0.4In0.85Bi0.15Cl6 is up to 39,000±7000 photons MeV<sup>−1</sup> , considerably higher than that of the previously recorded CsPbBr3 NCs (21,000 photons MeV<sup>−1</sup> ). 



**FIGURE 9.** (A) Stokes shift of Cs2Ag0.6Na0.4In0.85Bi0.15Cl6 with different Bi<sup>3+</sup> concentrations. (B) Attenuation efficiency and light yield of Cs2Ag0.6Na0.4In0.85Bi0.15Cl6 versus amount of Bi<sup>3+</sup> . (C) RL intensity as a function of dose rate, revealing detection limit of Cs2Ag0.6Na0.4In0.85Bi0.15Cl6. (D) 

36 

X-ray photographs of test-pattern plate taken at various X-ray doses. (E) Finger bending in realtime X-ray images (dose rate: 47.2 μGyair s<sup>−1</sup> , voltage: 50 kV). Reproduced with permission [128]. 



**FIGURE 10.** Scintillation properties and X-ray imaging of 2D-(C8H17NH3)2SnBr4 perovskite. (A) Schematic diagram of the 2D layered crystal structure of (C8H17NH3)2SnBr4. (B) RL spectrum of a (C8H17NH3)2SnBr4-PMMA film. Inset: image under UV light. (C) Image of target materials. (D) The contour profiles of image (C), (E) Photo and X-ray images of a capsule with a metal spring inside, a circuit board, and a biological specimen (crab). Reproduced with permission [129]. 

37 

Static X-ray imaging was achieved at a low dose of ∼1 μGyair, and dynamic X-ray imaging of finger bending without ghosting was shown at a low dose rate of 47.2 μGyair s<sup>−1</sup> , thanks to this scintillator's high light output and rapid light decay. The RL strength and X-ray image quality remained nearly unchanged after 50 h thermal treatment at 85 °C accompanied by 50 h X-ray irradiation in ambient air. Using Ce ions as a sensitizer in lead-free double-perovskite (DP) crystals could improve X-ray detection and imaging sensitivity by increasing the X-ray stopping power. Ce:Cs2NaTbCl6 crystals have a light output of 52,153 photons MeV<sup>−1</sup> , 25% higher than that of undoped crystal, and a detection limit of 30 nGy s<sup>−1</sup> (roughly 1/183 of a normal medical imaging dose), and the scintillation film has a spatial resolution of up to 10 lp mm<sup>−1</sup> [130]. 

## **8.6 Lead-free 2D perovskites** 

The development of lead-free 2D perovskites as scintillators is important due to their higher stability as compared to their 3D counterparts. Recently, Gu _et al_ . developed a lead-free 2D perovskite ((C8H17NH3)2SnBr4) scintillator [129]. This perovskite showed a PL peak at 596 nm and nearly 100% PLQY with a long-lived luminescence of τ = 3.34 μs. Furthermore, they embedded (C8H17NH3)2SnBr4 in a polymer matrix to fabricate a uniform flexible scintillator film. Using this film, the team captured images with a resolution of 200 μm ( **Figure 10** ). These findings reveal the potential applications of (C8H17NH3)2SnBr4 as a next-generation scintillator with low cost, nontoxicity, and good resolution. 

## **8.7 Lead-free low dimensional (0D and 1D) metal halides** 

Low light yield under high-energy radiation and the toxicity of lead HPs severely restrict their practical application. Lead-free low-dimensional all-inorganic and organic-inorganic hybrid metal halides show efficient luminescence and high stability, making them highly attractive for highenergy radiation detectors. 0D metal halides are an important class of light emitter in which anionic metal polyhedrons are separated by organic or inorganic cations and they show highly efficient Stokes-shifted broadband emissions [131]. Kovalenko _et al_ . synthesized group 14 metal-based 0D compounds, Bmpip2MBr4 (Bmpip = 1-butyl-1-methylpiperidinium cation and M = Ge, Sn, Pb). The RL of Sn and Pb halides is comparable to the brightness of an inorganic commercial X-ray scintillator (NaI:Tl) [132]. However, Sn(II) is prone to oxidation, making this scintillator highly 

38 

unstable, and Pb is highly toxic. Therefore, the development of highly stable organic 0D metal halide hybrids as scintillators with high light yield and stability under X-ray irradiation is of great interest. Ma _et al_ . synthesized an organic Sb(III) chloride-based scintillator with a high light yield of 54,000 photons/MeV, a low detection limit of 191.4 nGyair s<sup>−1</sup> , and excellent stability of over 2 years [133]. Recently, they also reported a 0D, inch-sized Mn-based organic-inorganic X-ray scintillator, ethylenebis-triphenylphosphonium manganese (II) bromide ((C38H34P2)MnBr4) [134]. It exhibited an emission peak at 517 nm with a PL quantum efficiency (PLQE) of 95%. It showed a very high light yield of 80,000 photons MeV<sup>-1</sup> and a low detection limit of 72.8 nGy s<sup>-1</sup> . The scintillation properties of lanthanide-based 0D halides have rarely been investigated. Wu _et al._ reported all-inorganic Cs4EuX6 (X=Br, I) SCs as self-activated scintillators with excellent performance under gamma-ray irradiation. Cs4EuBr6 and Cs4EuI6 showed high light yields of 78,000 ± 4000 photons MeV<sup>−1</sup> and 53,000 ± 3000 photons MeV<sup>−1</sup> under<sup>137</sup> Cs g-ray irradiation, respectively [135]. 

Tang _et al._ reported lead-free halide SCs, namely Rb2CuBr3 [136], K2CuBr3 [137], and Rb2CuCl3 [138], as scintillators with exceptionally high light yields. Moreover, 1D Rb2CuBr3 showed a violet emission (385 nm) and a high PL QY (98.6%). It exhibited a very high light yield of ≈ 91,056 photons MeV<sup>-1</sup> and excellent spectral stability over 2 months under ambient conditions.  In the case of 1D K2CuBr3, the PL QY is 86.98% for the violet emission (391 nm), and the light yield is 23,806 photons MeV<sup>-1</sup> whereas Rb2CuCl3 demonstrated a PL peak at 397 nm and light yield of 16,600 photons MeV<sup>-1</sup> . The excellent scintillation yield, low toxicity, and good stability indicate that alkali metal-based copper halides could be promising X-ray scintillators. Wu _et al._ presented 0D Cs3Cu2I5 SCs with a high scintillation yield of 32,000 photons MeV<sup>-1</sup> and 29,000 photons MeV<sup>-1</sup> under X-rays and γ-rays, respectively. Along with SCs, Cs3Cu2I5 NCs are also gaining attention as X-ray scintillators [139]. These NCs showed efficient and reabsorption-free RL with a high light yield of 79,279 photons MeV<sup>-1</sup> under X-rays ( **Figure 11** ) [140]. 

39 



**FIGURE 11.** (A) X-ray absorption coefficients of Cs3Cu2I5, CsPbBr3, CsI:Tl, and carbon dots versus photon energy. Inset: images of colloidal Cs3Cu2I5 NCs under room light and X-ray irradiation with a 50 keV. (B) RL spectrum of a NC film and photon detection efficiency. (C) Response intensity of NCs as a function of X-ray dose rate. Reproduced with permission [140]. 

Wei _et al._ reported a lead-free heterometallic SC, Cs4MnBi2Cl12, that showed better RL than a commercial NaI(Tl) scintillator [141]. 

## **8.8 Polymer encapsulated all-inorganic 3D perovskites** 

As X-ray scintillators, CsI:Tl and GOS:Tb are now commonly used. The CsI:Tl scintillator requires an expensive and tedious vacuum process to produce a thick crystalline scintillator film, which is inherently brittle and fragile, restricting its use in versatile detection applications like oral and dental imaging. On the other hand, the low-cost and lightweight GOS scintillator is embedded in a flexible matrix. However, it scatters a large portion of the emitted light, lowering the spatial resolution, and has a slow response time, necessitating a long X-ray exposure time to obtain an X- ray image and, as a result, designing a new, cost-effective scintillator with a high spatial resolution and fast response time is highly challenging. Heo _et al_ . showed that a low-cost X-ray detector made of a carbon fiber-reinforced polymer film/scintillator film/Si-PD array has high resolution, sensitivity, and stability [92]. They photopolymerized a mixture solution of CsPbBr3 NCs, methylmethacrylate (MMA), and photo-initiator to make the CsPbBr3 NC scintillator film. 

40 

