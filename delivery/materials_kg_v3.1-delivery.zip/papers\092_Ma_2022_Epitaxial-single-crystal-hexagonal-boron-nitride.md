# Epitaxial single-crystal hexagonal boron nitride multilayers on Ni (111)

| 字段 | 内容 |
|---|---|
| 期刊 | Nature |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 234 |
| 作者 | K. Ma, Lei-Ning Zhang, Sunghwan Jin, Yan Wang, Seong In Yoon, Hyuntae Hwang, Juseung Oh, Darryl Jeong et al. |
| DOI | 10.1038/s41586-022-04745-7 |
| 源文件 | 092_Ma_2022_Epitaxial-single-crystal-hexagonal-boron-nitride.pdf |

---
- 1 **Epitaxial Single-Crystal Hexagonal Boron Nitride Multi-** 

# 2 **Layers on Ni (111)** 

- 3 _Kyung Yeol Ma_<sup>_1,2_</sup> _, Leining Zhang_<sup>_2,3_</sup> _, Sunghwan Jin_<sup>_2,4_</sup> _, Yan Wang_<sup>_5_</sup> _, Seong In Yoon_<sup>_1_</sup> _, Hyuntae_ 4 _Hwang_<sup>_2,4_</sup> _, Juseung Oh_<sup>_6_</sup> _, Da Sol Jeong_<sup>_1_</sup> _, Meihui Wang_<sup>_1,2_</sup> _, Shahana Chatterjee_<sup>_2_</sup> _, Gwangwoo_ 5 _Kim_<sup>_1_</sup> _, A-Rang Jang_<sup>_7_</sup> _, Jieun Yang_<sup>_8_</sup> _, Sunmin Ryu_<sup>_6_</sup> _, Hu Young Jeong_<sup>_9_</sup> _, Rodney S. Ruoff_<sup>_1,2,3,4,_</sup> _*,_ 

- 6 _Manish Chhowalla_<sup>_5,_</sup> _*, Feng Ding_<sup>_2,3,_</sup> _*, and Hyeon Suk Shin_<sup>_1,2,4,10,_</sup> _*_ 

- 7 1Department of Chemistry, Ulsan National Institute of Science and Technology (UNIST), 8 Ulsan 44919, Republic of Korea 

9 

10 

11 

- 12 

13 

14 

- 15 

16 

   - 2Center for Multidimensional Carbon Materials, Institute of Basic Science (IBS), Ulsan 44919, Republic of Korea 

   - 3Department of Materials Science and Engineering, Ulsan National Institute of Science and Technology (UNIST), Ulsan 44919, Republic of Korea 

   - 4Department of Energy Engineering, Ulsan National Institute of Science and Technology (UNIST), Ulsan 44919, Republic of Korea 

   - 5Department of Materials Science and Metallurgy, University of Cambridge, Cambridge CB3 0FS, UK 

- 17 6Department of Chemistry, Pohang University of Science and Technology (POSTECH), 18 Pohang 37673, Republic of Korea 

- 19 7Department of Electrical Engineering, Semyung University, Jecheon 27136, Republic of 20 Korea 

- 21 8Department of Chemistry and Research Institute of Basic Sciences, Kyung Hee University, 22 Seoul 02447, Republic of Korea 

- 23 

24 

25 

26 

- 27 

   - 9UNIST Central Research Facilities (UCRF), Ulsan National Institute of Science and Technology (UNIST), Ulsan 44919, Republic of Korea 

   - 10Low Dimensional Carbon Materials, Ulsan National Institute of Science and Technology (UNIST), Ulsan 44919, Republic of Korea 

   - *These authors contributed equally: Kyung Yeol Ma, Leining Zhang 

- 28 Corresponding authors: shin@unist.ac.kr (HSS); f.ding@unist.ac.kr (FD); mc209@cam.ac.uk 29 (MC); rsruoff@ibs.re.kr (RSR) 

1 

- 30 **Large-area single-crystal monolayers of two dimensional (2D) materials such as** 

- 31 **graphene**<sup>**1-3**</sup> **, hexagonal boron nitride (hBN)**<sup>**4-6**</sup> **and transition metal dichalcogenides**<sup>**7,8**</sup> 

32 **have been grown. hBN is considered to be the “ideal” dielectric for 2D materials-based** 33 **field effect transistors (FETs) – offering the potential for extending Moore’s law**<sup>**9,10**</sup> **.** 34 **Although hBN thicker than a monolayer is more desirable as substrate for 2D** 35 **semiconductors**<sup>**11,12**</sup> **, highly uniform and single-crystal multi-layer hBN growth has yet** 36 **to be demonstrated. Here we report the epitaxial growth of wafer-scale single-crystal** 37 **tri-layer hBN by a chemical vapour deposition method. Uniformly aligned hBN islands** 38 **are found to grow on single-crystal Ni (111) at early stage and finally to coalesce into a** 39 **single-crystal film. Cross-sectional transmission electron microscopy (TEM) results** 40 **show that a Ni23B6 interlayer is formed (during cooling) between the single-crystal hBN** 41 **film and Ni substrate by boron dissolution in Ni. There is epitaxial relationship between** 42 **hBN and Ni23B6 and between Ni23B6 and Ni. We also find that the hBN film acts as a** 43 **protective layer that remains intact during catalytic evolution of hydrogen – suggesting** 44 **continuous single-crystal hBN. This hBN transferred onto the SiO2 (300 nm)/Si wafer** 45 **acts as a dielectric layer to reduce electron doping from the SiO2 substrate in MoS2** 46 **FETs. Our results demonstrate high quality multi-layered hBN over large area, which** 47 **should open up new pathways for making it a ubiquitous substrate for 2D** 48 **semiconductors.** 

49 Insulating hBN has been said to be an ideal substrate and dielectric for FETs based on 2D 50 semiconductors because it reportedly can effectively screen charge trap sites to prevent 51 scattering<sup>10</sup> . hBN films are also reported to prevent oxidation of metals such as Fe and Cu<sup>4,13</sup> , 52 and to act as an effective tunnel barrier<sup>14</sup> . A key challenge for realizing the potential 

2 

- 53 applications of hBN and for opening new avenues for science is growth of uniform hBN 

- 54 films over large areas. Recent studies have reported the growth of wafer-scale single-crystal 

55 hBN monolayer on Au, Cu (110), or Cu (111) surfaces by chemical vapour deposition 56 (CVD)<sup>4-6</sup> . However, hBN with thicknesses greater than a monolayer is desirable for most 57 applications such as a gas-diffusion barrier<sup>15</sup> , an oxidation-protecting layer<sup>16</sup> , an 58 encapsulation layer<sup>17</sup> , a dielectric substrate for 2D semiconductors<sup>10-12</sup> , and as a capacitor for 59 resistive random access memory<sup>18</sup> . Several strategies have been reported to grow multi60 layered but polycrystalline hBN by CVD on catalytic (Fe, Ni, Cu, Pt, and Ni-Fe alloys)<sup>11-13,19-</sup> 61 25 and inert (SiO2 and Al2O3)26-28 substrates. However, growth of uniform single-crystal 62 multi- or few-layered hBN over large area has, to the best of our knowledge, not yet been 63 realized. 

64 A single-crystal Ni (111) foil was prepared from polycrystalline Ni foil by annealing in a 65 mixed hydrogen and argon atmosphere<sup>29</sup> (Extended Data Fig. 1a). Tri-layer hBN films were 66 grown on the single crystal Ni (111) substrates by flowing borazine (flow rate of 0.1 sccm) 67 for 60 min into the growth furnace held at 1220<sup>o</sup> C (Extended Data Fig. 1b-d and see 68 Methods for details). Scanning electron microscopy (SEM) images of how the hBN growth 69 evolves with time (by ―interrupting growth‖ at times less than 60 min) are shown in Fig. 1a. 70 In the initial stage of growth (it was learned that this is within the first ~30 min), 71 unidirectionally aligned tri-layer hBN islands are observed on the Ni (111) surface (Fig. 1a 72 and Extended Data Fig. 2a-b). After growth for 45 min (Fig. 1a(iii)), hBN islands grow and 73 merge into larger ones. The thickness of the thin film does not change during the coalescence 74 of such tri-layer hBN islands at 45 min  the average thickness of hBN islands at growth 75 times of 30 and 45 min is 1.03 ± 0.06 and 1.05 ± 0.03 nm, respectively (Extended Data Fig. 

3 

- 76 2c-d). The substrate was found to be fully covered by tri-layer hBN at the growth time of 60 

- 77 min (Fig. 1a(iv)). The tri-layer hBN film could be transferred from the Ni (111) foil onto SiO2 

78 (300 nm)/Si substrates by a wet-transfer method (Fig. 1b); a photograph of the hBN film 79 shows uniform contrast, suggesting uniform film thickness (Fig. 1b). Atomic force 80 microscopy (AFM) line scans show that the average thickness of the transferred film is 1.27 ± 81 0.06 nm (see the inset of Fig. 1b and Extended Data Fig. 3 for AFM images at different 82 positions). A typical Raman spectrum of tri-layer hBN film transferred onto SiO2 (300 nm)/Si 83 substrate shows the characteristic hBN peak (E2g) at 1368 cm<sup>-1</sup> with full width at half 84 maximum (FWHM) of ~14 cm<sup>-1</sup> (Fig. 1c) narrower than that (17 cm<sup>-1</sup> ) reported for multilayer 85 hBN grown on Ni-Fe alloy<sup>12</sup> but comparable to that reported for single-crystal monolayer 86 hBN<sup>6</sup> . Figure 1d shows 12 Raman intensity mapping images (mapping area of 5  m  5  m 87 at each position) for the E2g peak in the continuous tri-layer hBN film, exhibiting uniform 88 contrast. The average intensity of the peak (E2g mode at 1368 cm<sup>-1</sup> ) for a total of 2065 spectra 89 in these 12 images is 314.4 ± 23.5, suggesting highly uniform thickness over large area. 90 Ultraviolet-visible (UV-Vis) absorption spectroscopy shows the optical bandgap energy of 91 6.05 eV (Fig. 1e) in agreement with a previous report for hBN<sup>20</sup> . X-ray photoelectron 92 spectroscopy (XPS) measurements show sp<sup>2</sup> -bybridized B- and N-bonded atoms in the tri93 layer hBN and also the presence of Ni-B bonds (Fig. 1f). The B 1s spectrum was 94 deconvoluted into two distinct peaks at 190.2 eV (hBN) and 187.9 eV (B-Ni bond in nickel 95 borides<sup>30</sup> ). The B/N atomic ratio in the hBN calculated from the 190.2 eV (B 1s) and 397.9 96 eV (N 1s) peaks (Fig. 1f) was found to be 1:0.96. The N 1s spectrum shows a single peak, 97 indicating the presence of N in only B-N bonds. The B1s peak from the B-Ni bonds in Ni23B6 98 disappears after the sample was transferred to SiO2/Si substrate, and the B1s and N1s peaks 99 show the B/N atomic ratio of 1 : 0.96 (Fig. 1g). 

4 

- 100 A schematic illustration of the proposed growth process is shown in Fig. 1h: (i) dissociation 

101 of borazine precursor on the Ni surface at 1220<sup>o</sup> C provides the B and N species for the hBN 102 film. (ii) B is dissolved into the Ni as a solid solution due to the high solubility at the growth 103 conditions (note that ternary Ni-B-N phase diagram indicates ~0.3 at % solubility of B at 104 1085<sup>o</sup> C<sup>31</sup> ) In contrast, N is reported to have very low solubility in Ni (~0.004 at % at 1550 105 oC — thus it is expected to be much lower at 1220 oC32). Thus, formation of nickel nitride or 106 dissolution of N is not expected to play a role in the growth of hBN. (iii) hBN islands 107 nucleate and epitaxially grow on the Ni (111) surface and the detailed mechanism will be 108 discussed later. The tri-layer hBN evidently grows by a surface-mediated mechanism (i.e., not 109 by precipitation from the bulk during cooling process): the thickness remains constant for 110 different cooling rates of -60, -30, and -5<sup>o</sup> C/min<sup>33</sup> (the inset of Fig. 1b for -60<sup>o</sup> C/min and 111 AFM images in Extended Data Fig. 4 for -30 and -5<sup>o</sup> C/min). In precipitation-based growth 112 (versus surface mediated)<sup>11</sup> , the thickness of the film should increase when decreasing the 113 cooling rate, if the cooling rates are low enough to ―freeze out‖ precipitation<sup>11</sup> . (iv) The 114 islands coalesce into a continuous tri-layered hBN film after 60 min and the furnace is then 115 cooled to room temperature. (v) We suggest that the excess B that had dissolved in the Ni 116 (111) precipitates (during cooling) as the observed Ni23B6 layer that is found to be located 117 between the tri-layer hBN film and the Ni (111) substrate; see energy-filtered (EF) TEM 118 elemental mapping and cross-sectional images at different cooling rates (Extended Data Fig. 119 5). The thickness of the Ni23B6 layer was observed to be thicker for larger cooling rates 120 (Extended Data Fig. 5c-e), suggesting the Ni23B6 alloy forms during cooling. As the melting 121 point of Ni23B6 (988<sup>o</sup> C) is much lower than the growth temperature<sup>34</sup> , it would be expected 122 that the Ni23B6 crystal is formed during the cooling process via the precipitation of the 123 dissolved boron atoms. We note studies reporting that Ni23B6 alloy can be formed by an 

5 

- 124 undercooling process<sup>34,35</sup> . The cross-section TEM measurements show that Ni23B6 alloy was 

- 125 always found sandwiched between the hBN layer and the Ni (111). We also do not find any 126 evidence for excess B in the films (XPS results) because unbonded B that diffuses to the 

- 127 surface forms volatile BHx (Extended Data Fig. 5f) and is pumped away. Our analyses 128 indicates that Ni23B6 interlayer is always present under the hBN (Extended Data Fig. 5g-i). 

129 We have studied the impact of growth temperature on the structure and thickness of as130 deposited hBN. We did growths at temperatures ranging from 1020 to 1320<sup>o</sup> C for 30 min 131 (Extended Data Fig. 6). At 1020<sup>o</sup> C, polycrystalline hBN film with a thickness of ~3.0 nm is 132 grown. We note others reporting polycrystalline hBN films grown on polycrystal Ni<sup>20</sup> . The 133 growth of uniform and continuous single crystal tri-layer hBN occurs from 1120<sup>o</sup> C (but for 134 longer growth times than 60 min). For the 30-min growths, the hBN island sizes were 135 approximately 700 nm at 1120<sup>o</sup> C, 2  m at 1170<sup>o</sup> C and 8  m at 1220<sup>o</sup> C (Extended Data Fig. 136 6b-d). At 1270<sup>o</sup> C, hBN films exhibit substantial non-uniformity in thickness and roughness. 137 Local melting of the Ni surface was observed at 1320<sup>o</sup> C (Extended Data Fig. 6e-f). Thus, our 138 results suggest that single-crystal hBN growth on Ni (111) requires higher temperature of 139 ~1120<sup>o</sup> C than conventionally used growth temperature of approximately 1000<sup>o</sup> C using Ni 140 catalyst<sup>13,20,22</sup> . 

141 We find by cross-sectional TEM measurements that there is epitaxy between the tri-layer 142 hBN and Ni23B6, and between the Ni23B6 and Ni (111); that is, at the respective interfaces. 143 The low- and high-magnification TEM images of a 200-nm thick Ni23B6 on the Ni (111) 

- 144 surface are shown in Fig. 2a, b. Ni23B6 is reported to be face-centered cubic (FCC; space 

- 145 group 𝐹𝑚3̅𝑚) with lattice constant of 𝑎= 10.76 Å<sup>36</sup> ; this is consistent with our annular 

- 146 dark field (ADF) scanning TEM (STEM) image and crystal model (Fig. 2c-d). The selected- 

6 

147 area electron diffraction (SAED) patterns show overlapped hexagonal dots of Ni23B6 and Ni 148 (Fig. 2e), indicating the epitaxial relationship between Ni23B6 and Ni substrate with [111] 149 Ni23B6 ∥ [111] Ni and [002] Ni23B6 ∥ [002] Ni. A uniform tri-layer hBN film is shown in 150 Fig. 2f and g, consistent with the AFM height profile (Fig. 1c). 3 layers with interlayer 151 distance of 0.33 nm (yellow dashes) was found. The magnified HR-TEM image in the inset 152 of Fig. 2g indicates the stacking order of AA’A. It is noted that boron and nitrogen atoms are 153 indistinguishable but AA’ stacked hBN is the global minimum among all possible stacking 154 configurations<sup>37</sup> . The [112̅0] direction in hBN was found to be well aligned with the [110] 155 direction of Ni23B6 from FFT patterns in Fig. 2h and i. To examine whether the hBN film is 156 single crystal over a large area, we did SAED measurements of hBN film transferred onto 5- 157 nm-thick amorphous SiN membrane (on a 3-mm grid) and collected SAED patterns at the 9 158 locations shown in Fig. 2j. The 9 SAED patterns shown in Fig. 2k are identical and display 159 one set of hexagonal dots, indicating that the hBN film is single crystal over the 1 mm scale 160 that could be probed here. Polarized optical microscopy (POM) patterns of liquid crystal 4- 161 cyano-4'-pentylbiphenyl (referred to as 5CB) on hBN film do not show the presence of grain 162 boundaries and their uniform change of color with different polarization angles (Extended 163 Data Fig. 7a-c), suggesting that the hBN is single crystalline and also has uniform thickness 164 on a large scale<sup>4,33</sup> . In contrast, POM patterns of 5CB on polycrystalline hBN grown at 1020 165 oC show inhomogeneous color contrast with the polarization angles (Extended Data Fig. 7d). 166 The second-harmonic generation (SHG) mapping also supports that the single-crystal tri167 layer hBN film is continuous without any measurable grain boundaries, whereas the grain 168 boundaries are clearly visible in polycrystalline hBN film (Extended Data Fig. 8a-f). SHG 169 mapping has been used to identify the absence of grain boundaries in single-crystal hBN 170 monolayer<sup>5</sup> . Photoluminescence (PL) can also be used to assess the quality of hBN because 

7 

- 171 defects in hBN samples are sources of single photon emission in the visible and near infrared 

- 172 wavelengthregions<sup>38,39</sup> . The fact that we did not observe any PL signal for the single-crystal 

- 173 tri-layer hBN film further suggests its single crystal nature (Extended Data Fig. 8g, h). 

174 To understand the mechanism of hBN epitaxial growth, we explored hBN island growth at 175 different growth times. AFM images of hBN islands on the Ni (111) surface after exposure to 176 borazine (that we will refer to as ―growth‖) for 1 minute show edge docking of most hBN 177 islands (Fig. 3a, 1 min), which implies that most hBN islands nucleate at step edges. After 30 178 min growth, most hBN islands are no longer attached to a step edge (Fig. 3a, 30 min). 179 Previous studies reported that the nucleation of 2D materials near a step edge of the substrate 180 is energetically preferred compared to nucleation on a terrace and the interaction between the 181 edge of the 2D material and the step edge determines the alignment of the 2D materials<sup>5,6,8,40-</sup> 182 44. Figure 3b shows that the binding energy of a hBN nucleus (N7B6) at a step edge is about 2 

183 eV higher than on a terrace  the configuration C in Fig. 3b is preferred. In Fig. 3c, the van 184 der Waals (vdW) interactions of mono-, bi- and tri-layer hBN film on Ni (111) surface have 185 two local minima at 0º and 60º rotation angle. Thus, hBN islands nucleated at the step edge 186 can maintain their original alignment even after they grow across a step edge. The edge187 docking complementarity mechanism ensures that the alignment of hBN islands is not 188 changed even at a titled step edge.<sup>40</sup> Such a mechanism ensures the single crystallinity of the 189 large area hBN film on a wafer-scale Ni substrate. A scheme of the overall proposed growth 190 mechanism is shown in Fig. 3d. The distorted trapezoid shape (or the truncated triangle-like 

- 191 shape) of the hBN islands is due to the slow growth rate of hBN islands along the direction 

- 192 perpendicular to the step edges because of the extra energy penalty of hBN crossing step 

- 193 edges as reported in a previous study<sup>5</sup> . 

8 

- 194 Our standard growth condition leads to single crystal tri-layer hBN islands (or continuous 

195 films if growth is long enough to complete the film) in a broad range of borazine gas flow 196 rate. We have, however, controlled the thickness of hBN films to different than trilayer by 197 using parameters outside the parameter space favoring trilayer. We have grown large area bi198 and 5-layer single-crystal hBN films by varying the growth conditions (Extended Data Fig. 9), 199 in accord with decrease of hBN binding energy with thickness (Fig. 3e). However, 4L and 6L 200 hBN films could not be grown, which requires further investigation. In Fig. 3e, the specific 201 binding energy, _E_ b2, of thick hBN (n≥4) on Ni (111) surface is about the same, and smaller 202 than _E_ b2 of mono-, bi-, and tri-layer hBN. That is, hBN thicker than 3 layers have very similar 203 stability and thus it is hard to find the experimental windows to control the thickness of 204 thicker hBN layers (n≥4). 

205 To evaluate the uniformity of our tri-layer hBN, we performed electrochemical peel-off 206 tests. This test was done by generation of hydrogen gas through the hydrogen evolution 207 reaction (HER). The peel-off test was carried out on two samples: single-crystal tri-layer hBN 208 on Ni23B6/ Ni (111) and thick polycrystalline hBN on Ni (111) (Extended Data Fig. 6a). The 209 experimental set up is shown in Fig. 4a and described in details in Methods. The single210 crystal hBN did not show any damage per SEM imaging (Fig. 4b), indicating a good 211 protection against electrochemical degradation. We also tested polycrystalline hBN, which 212 showed partial peel-off after 50 cycles of HER and complete peel-off after 500 cycles (Fig. 213 4c). The results suggest that presence of grain boundaries allows H<sup>+</sup> in HER electrolyte to 214 penetrate into the Ni (111) surface and peel off the polycrystalline hBN film when hydrogen 215 gas is evolved. These results demonstrate that the single-crystal tri-layer hBN is continuous 216 and uniform with no significant defects such as incomplete regions of growth. 

9 

- 217 The feasibility of tri-layer hBN as a gate dielectric in FETs based on MoS2 is shown in Fig. 

- 218 4d where transfer characteristics of bottom gated devices on SiO2 and hBN are shown. It can 

- 219 be seen that the threshold voltage in the MoS2 FET with hBN shifted to positive gate voltage, 

- 220 indicating that single-crystal tri-layer hBN reduces charge trapping and prevents electron 

- 221 doping from the SiO2 substrate. In addition, higher mobility of MoS2 on hBN (90 cm<sup>2</sup> /Vs) 

- 222 was observed (SiO2 = 56 cm<sup>2</sup> /Vs) due to less scattering by coulomb impurities with tri-layer 223 hBN. 

- 224 In summary, we report uniform and large area epitaxially grown single-crystal tri-layer hBN 

- 225 films on Ni (111) foils, and we find uniform stacking that we suggest is AA’A. Hinted by the 

- 226 hBN binding energy decreasing with thickness, we found modified growth conditions and 

- 227 thereby achieved large area epitaxially grown single-crystal 2-layer, and separately single 

- 228 crystal 5-layer, hBN films. 

- 229 

10 

## 230 **References** 

- 231 1 Lee, J. H. _et al._ Wafer-scale growth of single-crystal monolayer graphene on reusable 232 hydrogen-terminated germanium. _Science_ **344** , 286–289 (2014). 

- 233 2 Wu, T. R. _et al._ Fast growth of inch-sized single-crystalline graphene from a 234 controlled single nucleus on Cu-Ni alloys. _Nat. Mater._ **15** , 43–47 (2016). 

- 235 3 Xu, X. Z. _et al._ Ultrafast epitaxial growth of metre-sized single-crystal graphene on 236 industrial Cu foil. _Sci. Bull._ **62** , 1074–1080 (2017). 

- 237 4 Lee, J. S. _et al._ Wafer-scale single-crystal hexagonal boron nitride film via self238 collimated grain formation. _Science_ **362** , 817–821 (2018). 

- 239 5 Wang, L. _et al._ Epitaxial growth of a 100-square-centimetre single-crystal hexagonal 240 boron nitride monolayer on copper. _Nature_ **570** , 91–95 (2019). 

- 241 6 Chen, T. A. _et al._ Wafer-scale single-crystal hexagonal boron nitride monolayers on 242 Cu (111). _Nature_ **579** , 219–223 (2020). 

- 243 7 Yang, P. F. _et al._ Epitaxial growth of centimeter-scale single-crystal MoS2 monolayer 244 on Au(111). _ACS Nano_ **14** , 5036–5045 (2020). 

- 245 8 Choi, S. H. _et al._ Epitaxial single-crystal growth of transition metal dichalcogenide 246 monolayers via the atomic sawtooth Au surface. _Adv. Mater._ **33** , 2006601 (2021). 

- 247 9 Li, M. Y., Su, S. K., Wong, H. S. P. & Li, L. J. How 2D semiconductors could extend 248 Moore's law. _Nature_ **567** , 169–170 (2019). 

- 249 10 Dean, C. R. _et al._ Boron nitride substrates for high-quality graphene electronics. _Nat._ 250 _Nanotechnol._ **5** , 722–726 (2010). 

- 251 11 Kim, S. M. _et al._ Synthesis of large-area multilayer hexagonal boron nitride for high 252 material performance. _Nat. Commun._ **6** , 8662 (2015). 

11 

- 253 12 Uchida, Y. _et al._ Controlled growth of large-area uniform multilayer hexagonal boron 

- 254 nitride as an effective 2D substrate. _ACS Nano_ **12** , 6236–6244 (2018). 

- 255 13 Liu, Z. _et al._ Ultrathin high-temperature oxidation-resistant coatings of hexagonal 256 boron nitride. _Nat. Commun._ **4** , 2541 (2013). 

- 257 14 Britnell, L. _et al._ Field-effect tunneling transistor based on vertical graphene 258 heterostructures. _Science_ **335** , 947–950 (2012). 

- 259 15 Ko, H. _et al._ Toward non-gas-permeable hBN film growth on smooth Fe surface. _2D_ 260 _Mater._ **8** , 034003 (2021). 

- 261 16 Ahn, S. _et al._ Prevention of transition metal dichalcogenide photodegradation by 262 encapsulation with h-BN layers. _ACS Nano_ **10** , 8973–8979 (2016). 

- 263 17 Wang, L. _et al._ One-dimensional electrical contact to a two-dimensional material. 264 _Science_ **342** , 614–617 (2013). 

- 265 18 Shi, Y. Y. _et al._ Electronic synapses made of layered two-dimensional materials. _Nat._ 266 _Electron._ **1** , 458–465 (2018). 

- 267 19 Caneva, S. _et al._ Controlling catalyst bulk reservoir effects for monolayer hexagonal 268 boron nitride CVD. _Nano Lett._ **16** , 1250–1261 (2016). 

- 269 20 Shi, Y. M. _et al._ Synthesis of few-layer hexagonal boron nitride thin film by chemical 270 vapor deposition. _Nano Lett._ **10** , 4134–4139 (2010). 

- 271 21 Chatterjee, S. _et al._ Chemical vapor deposition of boron nitride nanosheets on metallic 272 substrates via decaborane/ammonia reactions. _Chem. Mater._ **23** , 4414–4416 (2011). 

- 273 22 Ismach, A. _et al._ Toward the controlled synthesis of hexagonal boron nitride films. 274 _ACS Nano_ **6** , 6378–6385 (2012). 

- 275 23 Gao, Y. _et al._ Repeated and controlled growth of monolayer, bilayer and few-layer 276 hexagonal boron nitride on Pt foils. _ACS Nano_ **7** , 5199–5206 (2013). 

12 

- 277 24 Song, L. _et al._ Large scale growth and characterization of atomic hexagonal boron 278 nitride layers. _Nano Lett._ **10** , 3209–3215 (2010). 

- 279 25 Kim, K. K. _et al._ Synthesis and characterization of hexagonal boron nitride film as a 280 dielectric layer for graphene devices. _ACS Nano_ **6** , 8583–8590 (2012). 

- 281 26 Jang, A. R. _et al._ Wafer-scale and wrinkle-free epitaxial growth of single-orientated 

- 282 multilayer hexagonal boron nitride on sapphire. _Nano Lett._ **16** , 3360–3366 (2016). 

- 283 27 Liu, D. H. _et al._ Conformal hexagonal-boron nitride dielectric interface for tungsten 

- 284 diselenide devices with improved mobility and thermal dissipation. _Nat. Commun._ **10** , 285 1188 (2019). 

- 286 28 Shi, Z. Y. _et al._ Vapor-liquid-solid growth of large-area multilayer hexagonal boron 287 nitride on dielectric substrates. _Nat. Commun._ **11** , 849 (2020). 

- 288 29 Jin, S. _et al._ Colossal grain growth yields single-crystal metal foils by contact-free 289 annealing. _Science_ **362** , 1021–1025 (2018). 

- 290 30 Zhang, P. _et al._ Electroless plated Ni-Bx films as highly active electrocatalysts for 

- 291 hydrogen production from water over a wide pH range. _Nano Energy_ **19** , 98–107 292 (2016). 

- 293 31 Rogl, P. & Schuster, J. Boron nitride and silicon nitride systems. _Inst. Phys. Chem._ 294 _Univ. Vienna Austria_ , 79–86 (1991). 

- 295 32 Kowanda, C. & Speidel, M. O. Solubility nitrogen in liquid nickel and binary Ni-Xi 296 alloys (Xi=Cr, Mo,W, Mn, Fe,Co) under elevated pressure. _Scr. Mater._ **48** , 1073–1078 297 (2003). 

- 298 33 Park, J. H. _et al._ Large-area monolayer hexagonal boron nitride on Pt foil. _ACS Nano_ 299 **8** , 8520–8528 (2014). 

- 300 34 Battezzati, L., Antonione, C. & Baricco, M. Undercooling of Ni-B and Fe-B alloys 13 

- 301 and their metastable phase diagrams. _J. Alloys Compd._ **247** , 164–171 (1997). 

- 302 35 Liu, F., Xu, J. F., Zhang, D. & Jian, Z. Y. Solidification of Highly Undercooled 303 Hypereutectic Ni-Ni3B Alloy Melt. _Metall. Mater. Trans. A_ **45a** , 4810–4819 (2014). 

- 304 36 Villars, P. & Calvert, L. D. Pearsons's Handbook of crystallographic data for 305 intermetallic phases. (ASM International, Materials Park, Ohio, 1991). 

- 306 37 Alem, N. _et al._ Atomically thin hexagonal boron nitride probed by ultrahigh307 resolution transmission electron microscopy. _Phys. Rev. B_ **80** , 155425 (2009). 

- 308 38 Caldwell, J. D. _et al._ Photonics with hexagonal boron nitride. _Nat. Rev. Mater._ **4** , 552– 309 567 (2019). 

- 310 39 Toth, M. & Aharonovich, I. Single photon sources in atomically thin materials. _Annu._ 311 _Rev. Phys. Chem._ **70** , 123–142 (2019). 

- 312 40 Bets, K. V., Gupta, N. & Yakobsion, B. I. How the complementarity at vicinal steps 313 enables growth of 2D monocrystals. _Nano Lett._ **19** , 2027–2031 (2019). 

- 314 41 Dong, J., Zhang, L. N., Dai, X. Y. & Ding, F. The epitaxy of 2D materials growth. _Nat._ 315 _Commun._ **11** , 5862 (2020). 

- 316 42 Zhang, L. N., Peng, P. & Ding, F. Epitaxial growth of 2D materials on high-index 317 substrate surfaces. _Adv. Funct. Mater._ **31** , 2100503 (2021). 

- 318 43 Gao, J. F., Yip, J., Zhao, J. J., Yakobson, B. I. & Ding, F. Graphene nucleation on 319 transition metal surface: structure transformation and role of the metal step edge. _J._ 320 _Am. Chem. Soc._ **133** , 5009–5015 (2011). 

- 321 44 Yuan, Q. H., Yakobson, B. I. & Ding, F. Edge-catalyst wetting and orientation control 322 of graphene growth by chemical vapor deposition growth. _J. Phys. Chem. Lett._ **5** , 323 3093–3099 (2014). 

324 

14 

325 

## **Acknowledgements** 

326 This work was supported by the research fund (NRF-2019R1A4A1027934, NRF327 2020R1A2C2004865, NRF-2021M3H4A1A02049651, NRF-2021R1A3B1077184, and 

328 NRF-2022R1C1C2009666) via the National Research Foundation and IBS (IBS-R-019-D1), 329 Republic of Korea. MC, YW acknowledge support from Leverhulme Trust (RPG-2019-22 330 7), EPSRC (EP/T026200/1, EP/T001038/1), and Royal Society Wolfson Merit Award (W 331 <mark>RM\FT\180009)</mark> . European Research Council (ERC) European Union’s Horizon 2020 res 332 earch and innovation programme (grant agreement No. 101019828 - 2D LOTTO) 

333 

## **Author statements** 

334 These authors contributed equally: Kyung Yeol Ma, Leining Zhang. 

335 

## **Affiliations** 

336 **Department of Chemistry, Ulsan National Institute of Science and Technology (UNIST),** 

337 **Ulsan 44919, Republic of Korea** 

338 Kyung Yeol Ma, Seong In Yoon, Da Sol Jeong, Meihui Wang, Gwangwoo Kim, Rodney S. 339 Ruoff & Hyeon Suk Shin 

- 340 **Center for Multidimensional Carbon Materials, Institute of Basic Science (IBS), Ulsan** 

341 **44919, Republic of Korea** 

- 342 Kyung Yeol Ma, Leining Zhang, Sunghwan Jin, Hyuntae Hwang, Meihui Wang, Shahana 

343 Chatterjee, Rodney S. Ruoff, Feng Ding & Hyeon Suk Shin 

- 344 **Department of Materials Science and Engineering, Ulsan National Institute of Science** 

- 345 **and Technology (UNIST), Ulsan 44919, Republic of Korea** 

- 346 Leining Zhang, Rodney S. Ruoff & Feng Ding 

15 

- 347 **Department of Energy Engineering, Ulsan National Institute of Science and Technology** 

- 348 **(UNIST), Ulsan 44919, Republic of Korea** 

- 349 Sunghwan Jin, Hyuntae Hwang & Rodney S. Ruoff 

- 350 **Department of Materials Science and Metallurgy, University of Cambridge, Cambridge** 

- 351 **CB3 0FS, UK** 

- 352 Yan Wang & Manish Chhowalla 

- 353 **Department of Chemistry, Pohang University of Science and Technology (POSTECH),** 

- 354 **Pohang 37673, Republic of Korea** 

- 355 Juseung Oh & Sunmin Ryu 

- 356 **Department of Electrical Engineering, Semyung University, Jecheon 27136, Republic of** 

- 357 **Korea** 

- 358 A-Rang Jang 

- 359 **Department of Chemistry and Research Institute of Basic Sciences, Kyung Hee** 

- 360 **University, Seoul 02447, Republic of Korea** 

- 361 Jieun Yang 

- 362 **UNIST Central Research Facilities (UCRF), Ulsan National Institute of Science and** 

- 363 **Technology (UNIST), Ulsan 44919, Republic of Korea** 

- 364 Hu Young Jeong 

- 365 **Low Dimensional Carbon Materials, Ulsan National Institute of Science and Technology** 

- 366 **(UNIST), Ulsan 44919, Republic of Korea** 

- 367 Hyeon Suk Shin 

368 

16 

## 369 **Contributions** 

- 370 H.S.S. and K.Y.M. conceived the project. R.S.R. suggested attempting growth of hBN on Ni 

- 371 (111) and contributed many useful suggestions related to the growth and characterization of 

- 372 hBN films. K.Y.M. grew the hBN by CVD, performed the transfer of hBN, and carried out 

- 373 SEM, EBSD, Raman, AFM, UV-Vis and POM measurements. F.D. and L.Z. performed the 

- 374 theoretical calculations. S.J., M.W. and S.C. conducted the contact-free annealing of the Ni 

- 375 foil. S.I.Y. and H.H. carried out XPS measurement. H.H., D.S.J. and J.Y. performed 

- 376 electrochemical measurements. G.K. and A-.R.J. performed the H2 plasma etching. Y.W. and 

- 377 M.C. performed FET fabrication and analysis. H.Y.J. performed TEM, STEM and SAED 

- 378 pattern measurements. J.O. and S. R. performed SHG imaging experiments. H.S.S., F.D., 

- 379 M.C., and R.S.R. supervised this project. All authors contributed to writing of the manuscript. 

380 **Corresponding author** 

- 381 Correspondence to Rodney S. Ruoff , Manish Chhowalla, Feng Ding, or Hyeon Suk Shin 

- 382 

- 383 

17 

## 384 **Main figure legend** 

- 385 **Fig. 1 | Growth of single-crystal tri-layer hBN on Ni (111).** (a) SEM images showing the 386 time evolution of tri-layer hBN on a Ni (111) foil surface at 1220<sup>o</sup> C. Insets show two 

387 different high-magnification SEM images each showing hBN islands. In the first, a single 388 hBN island is parallel to the surface steps. The second shows two hBN islands that have 389 joined along one edge. (b) Photograph of 2 cm  5 cm hBN film transferred onto the SiO2 390 (300 nm)/Si substrate. Inset shows an AFM image of an edge of the hBN film transferred 391 onto the SiO2 (300 nm)/Si substrate. The average thickness at 24 positions (in the film edges) 392 is 1.27 ± 0.06 nm. (c) Raman spectrum of a tri-layer hBN film on SiO2 (300 nm)/Si, showing 393 the characteristic hBN signal at 1368 cm<sup>-1</sup> . (d) Raman mapping images of the E2g peak 394 intensity at the 12 marked positions on the tri-layer hBN film on SiO2 (300 nm)/Si. The 395 mapped area at each position is 5  m  5  m. (e) UV-Vis absorption spectrum of tri-layer 396 hBN film transferred onto a quartz substrate. The inset is optical bandgap analysis of (e). (f): 397 XPS spectra measured from an as-grown tri-layer hBN film on Ni (111) after 60 min growth. 398 The binding energies of the peaks in the B 1s region are assigned as 190.2 eV (hBN) and 399 187.9 eV (Ni-B) and that in the N 1s region at 379.9 eV (hBN). (g) XPS spectra measured 400 from a transferred tri-layer hBN film on SiO2 (300 nm)/Si substrate. (h) Schematic 401 illustration of the proposed growth pathway of tri-layer hBN film on Ni (111) and the 402 subsequent appearance of Ni23B6 at the Ni (111)/hBN interface. The final structure from top 403 to bottom is tri-layer hBN/Ni23B6/Ni (111). The tri-layer hBN/Ni23B6 and Ni23B6/Ni (111) 404 layers show epitaxial relationship, respectively. 

405 

- 406 **Fig. 2 | Crystal structure of tri-layer hBN on Ni23B6/Ni (111).** (a) Low-magnification TEM 

18 

- 407 image of hBN/Ni23B6/Ni grown for 60 min. (b) High-magnification TEM image of the 

408 Ni23B6/Ni interface and (c) ADF-STEM image of Ni23B6 at the [110] zone axis. (d) Simulated 409 crystal model of Ni23B6. (e) SAED pattern of Ni23B6 and Ni. (f) Low- and (g) High410 magnification TEM images of tri-layer hBN on Ni23B6. The inset of (g) shows a higher 411 magnification image, demonstrating the AA'A stacking order. The corresponding FFT 412 patterns of (h) hBN and (i) Ni23B6 from the yellow square regions in (g). (j) SEM image of 413 tri-layer hBN film on 5-nm-thick amorphous SiN windows. (k) The corresponding 9 SAED 414 patterns in (j). The relative orientation angle (θ; obtained by averaging the 9 SAED patterns) 415 of the six symmetrical hexagonal dots is 36.52˚ ± 0.24˚, and the near zero spread shows that 416 all the hexagonal lattices observed (from the 9 separate SAED patterns) are aligned along one 417 specific direction. 

418 

419 **Fig. 3 |** **<mark>The mechanism of tri-layer hBN growth.</mark>** <mark>(a) AFM images of tri-layer hBN on Ni</mark> 420 <mark>(111) surface for growth times of 1 min (left) and 30 min (right). The hBN islands grown for</mark> 421 <mark>1 min have one edge attached to a step edge of the surface, but the edges of the hBN islands</mark> 422 <mark>grown for 30 min do not grow close to step edges. (b) Binding of N</mark> 7 <mark>B</mark> 6 <mark>(considered as the</mark> 423 <mark>probe seed for growth of hBN</mark><sup>6</sup> <mark>) on different sites of a Ni (111) surface:</mark> **<mark>A</mark>** <mark>, the most stable</mark> 424 <mark>configuration of a 0º-rotation angle N</mark> 7 <mark>B</mark> 6 <mark>on a Ni (111) terrace;</mark> **<mark>B</mark>** <mark>, the most stable</mark> 425 <mark>configuration of a 60º-rotation angle N</mark> 7 <mark>B</mark> 6 <mark>on a Ni (111) terrace;</mark> **<mark>C</mark>** <mark>, the most stable</mark> 426 <mark>configuration of a 0º-rotation angle N</mark> 7 <mark>B</mark> 6 <mark>near a <110> step edge of the Ni (111) surface;</mark> **<mark>D</mark>** <mark>,</mark> 427 <mark>the most stable configuration of a 60º-rotation angle N</mark> 7 <mark>B</mark> 6 <mark>near a <110> step edge of the Ni</mark> 

- 428 <mark>(111) surface. The binding energies of these N</mark> 7 <mark>B</mark> 6 <mark>are shown in the panel below, namely -</mark> 

- 429 <mark>12.09 eV for A, -11.95 eV for B, -14.20 eV for C and -13.85 eV for D. (More configurations</mark> 

- 430 <mark>are shown in Extended Data Fig. 10.) (c) Illustration of two possible epitaxial alignments of</mark> 

19 

- 431 <mark>the hBN film on the Ni (111) surface: 0º-rotation angle and 60º-rotation angle and the binding</mark> 432 <mark>energies of mono-, bi- and tri-layer hBN layers on the Ni (111) surface as a function of the</mark> 

- 433 <mark>rotation angle. Note that the 0º-rotation angle hBN alignment corresponds to the global</mark> 

- 434 <mark>minimum and the 60º-rotation angle one corresponds to a deep local minimum for the mono-,</mark> 

- 435 <mark>bi- and tri-layer hBN films. (d) Illustration of hBN c</mark> omplementarity <mark>nucleation</mark><sup>40</sup> <mark>and growth</mark> 

- 436 <mark>on the Ni (111) surface, where the nucleation near a step edge is energetically preferred but</mark> 

- 437 <mark>the docked edge later passes over the step edge during further growth. The step edges of the</mark> 

- 438 <mark>substrate generally slow down the growth rate of the hBN island edge parallel to them that</mark> 439 <mark>finally leads to a distorted trapezoid shape of the grown hBN island. (e)</mark> The specific binding 440 energy of the top layer to the next layer of multi-layer hBN on the Ni (111) surface (the 441 single-layer hBN’s ―next‖ layer is the Ni (111) surface). 

442 

443 **Fig. 4 | Peel-off test of hBN/Ni23B6** **_and_ FET built with hBN as a dielectric.** (a) Schematic 444 illustration of HER on hBN/Ni23B6/Ni (111) electrode. (b) SEM image of hBN/Ni23B6 after 445 2,000 cycles of HER measured in 0.5 M H2SO4 with a scan rate of 5 mV s<sup>-1</sup> . (c) SEM images 446 of ~3.0 nm-thick polycrystal hBN/Ni (111) before and after ~500 cycles of HER. 447 Polycrystalline hBN was completely peeled off. (d) Drain current versus gate voltage curve 448 of typical MoS2 FET on SiO2 and hBN/SiO2. The extracted mobility at room temperature is 449 56 cm<sup>2</sup> /Vs for SiO2 and 90 cm<sup>2</sup> /Vs for hBN/SiO2, respectively. The threshold voltage right 

450 shifted with hBN covering the SiO2, preventing strong electron doping from the substrates. 451 The inset shows FET device structure with hBN. 

452 

453 

20 

## 454 **Methods** 

- 455 **Preparation of single-crystal Ni (111) foil** 

- 456 Large-area Ni (111) foil was prepared by the contact-free annealing method<sup>29</sup> . A suspended 

- 457 commercial polycrystalline Ni foil (100  m thick, 99.994%; Alfa Aesar) was heated to 1,350 

- 458 oC, and held at that temperature for 24 h under a mixed-gas flow (Ar, 30 sccm, H2, 30 sccm; 

- 459 sccm, standard cubic centimetres per minute) at a pressure of 760 torr. 

- 460 **Growth of single-crystal tri-layer hBN on Ni (111)** 

461 The Ni (111) foil was placed inside the high-temperature and low-pressure CVD system 462 (Extended Data Fig. 1) at the centre of a furnace. A borazine (purchased from Gelest, Inc.) 463 precursor flask was placed in a water bath at -15<sup>o</sup> C. The bath temperature before the growth 464 of hBN was ramped up to 25<sup>o</sup> C. Before growth, the Ni (111) foil was heated to the growth 465 temperature (1,220<sup>o</sup> C) under a mixed-gas flow (Ar, 10 sccm; H2, 10 sccm). The flow of 466 borazine gas at 0.1 sccm (controlled by a mass flow controller) was then introduced into the 467 CVD chamber for 60 min in order to grow hBN. After hBN growth, the borazine flow was 468 terminated and the furnace was cooled rapidly to room temperature under a mixed-gas flow 469 (Ar, 10 sccm, H2, 10 sccm). The hBN growth at various temperature were performed from 470 1020 to 1320<sup>o</sup> C (Extended Data Fig. 6). The precursor flow rates used to grow 2- and 5-layer 471 hBN film were 0.025 sccm (borazine gas) and 50.1 sccm (0.1 sccm of borazine gas and 50 472 sccm of N2), respectively. 

- 473 **Transfer of hBN films onto arbitrary substrates** 

- 474 The as-grown hBN was transferred to SiO2/Si wafer, quartz plate, and 5-nm-thick 475 amorphous SiN windows (TEMwindows.com) by the polymer-mediated wet transfer process 

- 476 for further characterizations. A poly(methyl methacrylate) (PMMA) film was spin-coated on 

21 

477 the as-grown hBN/Ni23B6/Ni as a protection layer. Then Ni23B6/Ni was etched away in the 

478 aqueous solution of iron chloride (FeCl3). After thorough washing, the hBN film was 

- 479 transferred onto a target substrate, and finally PMMA was removed by dipping in acetone. 

480 

## **Characterizations** 

481 The prepared Ni (111) foil was characterized by SEM (Verios 460, FEI) and electron 482 backscatter diffraction (Hikari from Ametek). The surface morphology of hBN was 483 characterized by optical microscopy (Axio Scope. A1, Carl Zeiss), SEM (Verios 460, FEI), 484 and AFM (Dimension Icon, Bruker). XPS (ESCALAB 250 Xi, Thermo Scientific) was 485 performed to determine chemical compositions. Raman spectrum was obtained using a micro 486 Raman spectrometer (alpha 300, WITec GmBH) with a laser excitation wavelength of 532 487 nm and about 2 mW power. The UV-vis adsorption spectrum (Cary 5000 UV-vis-NIR, 488 Agilent) was measured to estimate the optical band gap of hBN on the quartz substrate. The 489 optical band gap energy was determined by using the formula of a direct band gap 490 semiconductor: 𝛼= 𝐶(𝐸−𝐸𝑔)<sup>1/2</sup> /𝐸 (where 𝛼 is the absorption coefficient, C is a constant, 491 E is the photon energy, and 𝐸𝑔 is the optical bandgap energy). The plot of (𝛼𝐸)<sup>2</sup> 𝑣𝑠. 𝐸 492 should be a straight line. Therefore, when (𝛼𝐸)<sup>2</sup> = 0, 𝐸 should be equal to 𝐸𝑔. For atomic493 resolution TEM and STEM imaging, a spherical aberration (Cs)-corrected TEM (Titan<sup>3</sup> G2 494 60-300, FEI) was used at 80 and 200 kV, respectively. To evaluate the lattice orientations of 495 hBN film, SAED patterns in TEM (JEM-2100F, JEOL) on 5-nm-thick amorphous SiN 496 windows and POM (Eclipse LV100-POL equipped with a heating stage, Nikon) on SiO2/Si 497 wafer after LC (4-cyano-4'-pentylbiphenyl (5CB), Alfa Aesar) coating were employed. SHG 498 imaging was performed with a home-built micro-SHG spectroscopy setup configured upon a 499 commercial microscope (Nikon, Ti-U)<sup>45</sup> . Ipara and Icross denote the SHG signals parallel and 

22 

500 perpendicular to the polarization of the fundamental beam operated at 950 nm, respectively. 

- 501 SHG signals were generated by 140-fs fundamental pulses from a commercial Ti-Sapphire 

- 502 laser and detected with a Si CCD detector. The pulses were focused onto a focal spot of ~1.5 

- 503  m in diameter. Ipara and Icross were selected by a Wollaston prism placed before the detector. 

504 

## **Calculation Methods** 

505 All calculations are performed within the framework of density functional theory (DFT) with 506 D3 correction for van der Waals interactions as implemented in the Vienna ab-initio 507 simulation Package (VASP)<sup>46,47</sup> . The exchange-correlation functions are treated by the 508 generalized gradient approximation (GGA)<sup>48</sup> , and the interaction between valence electrons 509 and ion cores is carried out by the projected augmented wave (PAW) methods<sup>49</sup> . During 510 modeling, three atom-thick Ni (111) slab with the bottom layer fixed is chosen as the 511 substrate. To avoid inducing extra strain on hBN film, the lattice of the Ni substrate is 512 stretched by 0.7% to fit the lattice constant of hBN. Periodic boundary conditions are applied 513 along the hBN plane directions, and the vacuum spacing in the out of plane direction is set to 514 be larger than 15 Å. The force on each atom less than 0.01 eV/Å and an energy convergence 

- 515 of 10<sup>-4</sup> eV are used as the criterion of convergence for atomic structure relaxations. 

516 The binding energy of an hBN nucleus (N7B6) at a step edge or on a terrace of the Ni(111) 517 substrate is defined as: 



<!-- Start of picture text -->
𝐸𝑏0 = 𝐸𝑇𝑜𝑡𝑎𝑙 −𝐸N7B6 −𝐸𝑆𝑢𝑏<br><!-- End of picture text -->

518 where 𝐸𝑇𝑜𝑡𝑎𝑙 is the total energy of N7B6 cluster on the substrate.𝐸N7B6 and 𝐸𝑆𝑢𝑏 are the 

519 energies of the free-standing N7B6 cluster and substrate, respectively. 

520 The interaction between multi-layer hBN film and a Ni (111) substrate is defined as: 



<!-- Start of picture text -->
𝐸𝑏1 = (𝐸𝑇𝑜𝑡𝑎𝑙 −𝐸ℎ𝐵𝑁 −𝐸𝑆𝑢𝑏)/𝐴<br><!-- End of picture text -->

23 

521 where 𝐸ℎ𝐵𝑁 and 𝐸𝑆𝑢𝑏 are the energies of the free-standing multi-layer hBN and Ni (111) 

- 522 substrate, respectively, and 𝐸𝑇𝑜𝑡𝑎𝑙 is the total energy of multi-layer hBN on the substrate. 

- 523 The specific binding energy of the top hBN layer is defined as: 



<!-- Start of picture text -->
𝐸𝑏2 = (𝐸𝑛/𝑁𝑖 −𝐸(𝑛−1)/𝑁𝑖 −𝐸𝑡𝑜𝑝)/𝐴<br><!-- End of picture text -->

524 where 𝐸𝑛/𝑁𝑖 and 𝐸(𝑛−1)/𝑁𝑖 represent the total energies of n-layer and (n-1)-layer hBN on 525 the Ni (111) substrate, respectively. 𝐸𝑡𝑜𝑝 is the energy top-layer of hBN and 𝐴 is the area of 526 a hBN layer. 

527 

## **H2 plasma etching** 

528 To evaluate the electrocatalytic performance of Ni23B6 without hBN protecting layer, as529 grown sample was exposure to 50 W of H2 plasma using a 13.56 MHz radio frequency 530 plasma generator (Diener Femto, Diener Electronic) for 5 min. The sample was kept 10 cm 531 away from the discharge zone. The plasma treatment was performed at 25<sup>o</sup> C with a H2 gas 

532 flow (5 sccm). The operating pressure was maintained at 1 mbar during plasma exposure. It is 533 also noted that no potential was applied to the aluminum stage on which the sample was 534 placed. 

535 **Electrochemical peel-off test** 

536 Electrochemical measurements were performed in a three-electrode cell using a ZIVE SP2 537 (ZIVE LAB). The polarization curves were collected by linear sweep voltammetry with a 538 scan rate of 5 mV s<sup>-1</sup> in 0.5 M H2SO4 electrolyte. A square shaped metal foil electrode of 539 geometric area 1 x 1 cm<sup>2</sup> was used as the working electrode. The working electrode was 540 equipped in the customized holder for measurements. Ag/AgCl and graphite rod were used as 

- 541 the reference electrode and counter electrode, respectively. During the electrochemical 

24 

542 measurements, high-purity N2 gas was continually bubbled throughout the whole 

543 electrochemical measurement. Potentials versus RHE can be calculated compared with 544 Ag/AgCl electrode by adding a value of 0.215 V after calibration. The electrochemical 545 stabilities of the catalysts were evaluated by continuously cycling the catalyst for 2,000 times 546 at a scan rate of 5 mV s<sup>-1</sup> . 

547 

## **FET fabrication and measurements** 

548 The hBN was first transferred on 300-nm-thick SiO2 by PMMA-assisted wet transferring 549 and MoS2 was mechanical exfoliated on top of it via a scotch tape method. Then electron550 beam lithography was used to pattern the electrodes. 10-nm-thick In and 100-nm-thick Au 551 were deposited subsequently to achieve ohmic contacts. The device was rinsed with 552 isopropanol after immersing in acetone for lift-off. Once the fabrication process was 553 completed, all devices were annealed at 200 °C in forming gas for one hour before 554 measurements. Transistor performance were measured by applying voltage with the Keithley 555 4200 semiconductor parameter analyzer system. The mobility extraction was done as per the 556 following equations<sup>50,51</sup> . 

557 The drain current in FETs is given by: 



<!-- Start of picture text -->
𝑊<br>𝐼𝐷  = µ𝐶𝑜𝑥  (𝑉𝐺 −𝑉𝑇)𝑉𝐷, 𝑤ℎ𝑒𝑛 𝑉𝐷 ≪𝑉𝐺 −𝑉𝑇<br>𝐿<br><!-- End of picture text -->



<!-- Start of picture text -->
𝑊<br>= µ𝐶𝑜𝑥  (𝑉𝐺 −𝑉𝑇) 2 , 𝑤ℎ𝑒𝑛 𝑉𝐷 > 𝑉𝐺 −𝑉𝑇<br>2𝐿<br><!-- End of picture text -->

𝜀0𝜀𝑟 558 Where _µ_ is mobility, 𝐶𝑜𝑥 is the capacitance of the insulating layer (𝐶𝑜𝑥 = ), _W_ is the 𝑑 

559 width of the device, _L_ is the channel length of the device, _VG_ is the gate voltage, _VT_ is the 560 threshold voltage, and _VD_ is the drain voltage. Mobility values for the MoS2 FET can be 

25 

561 extracted from the transfer curves using the following equation: 



<!-- Start of picture text -->
𝑔𝑚 𝐿<br>µ =<br>𝑉𝐷𝐶𝑜𝑥𝑊<br><!-- End of picture text -->

562 The maximum transconductance, 𝑔𝑚, is extracted from the largest slope value of the transfer 

563 curve: 



<!-- Start of picture text -->
𝑔𝑚  = ∂𝐼𝐷<br>∂𝑉𝐺<br><!-- End of picture text -->

- 564 The mobility is extracted in the linear region where 𝑉𝐷 ≪𝑉𝐺 −𝑉𝑇. VD = 1 V in these 

- 565 transfer curve measurements. 𝑉𝐺 −𝑉𝑇 > 10V was considered to make sure the device 

- 566 operates in linear region for the mobility extract. _VT_ = 1.5 V for SiO2 substrate and 10 V for 

- 567 hBN/SiO2 substrate. Current at _VG_ = 13 V was chosen for mobility extraction for SiO2 

- 568 substrate and current at _VG_ = 20 V was chosen for hBN/SiO2 substrate. 

- 569 

- 570 **Methods references** 

- 571 45 Kim, W., Ahn, J. Y., Oh, J., Shim, J. H. & Ryu, S. Second-harmonic young's 572 interference in atom-thin heterocrystals. _Nano Lett._ **20** , 8825–8831 (2020). 

- 573 46 Kresse, G. & Furthmuller, J. Efficiency of ab-initio total energy calculations for 574 metals and semiconductors using a plane-wave basis set. _Comput. Mater. Sci._ **6** , 15– 575 50 (1996). 

- 576 47 Kresse, G. & Hafner, J. Ab-initio molecular-dynamics for open-shell transition-metals. 577 _Phys. Rev. B_ **48** , 13115–13118 (1993). 

- 578 48 Perdew, J. P., Burke, K. & Ernzerhof, M. Generalized gradient approximation made 579 simple. _Phys. Rev. Lett._ **77** , 3865–3868 (1996). 

26 

- 580 49 Kresse, G. & Joubert, D. From ultrasoft pseudopotentials to the projector augmented581 wave method. _Phys. Rev. B_ **59** , 1758–1775 (1999). 

- 582 50 Kappera, R. _et al._ Phase-engineered low-resistance contacts for ultrathin MoS2 583 transistors. _Nat. Mater._ **13** , 1128–1134 (2014). 

- 584 51 Liu, K. -K. _et al._ Growth of large-area and highly crystalline MoS2 thin layers on 585 insulating substrates. _Nano Lett._ **12** , 1538–1544 (2012). 

- 586 52 Gorbachev, R. V. _et al._ Hunting for monolayer boron nitride: optical and Raman 587 signatures. _Small_ **7** , 465–468 (2011). 

- 588 

- 589 **Data availability** 

- 590 The data that support the findings of this paper are available in the paper. Source data are 

- 591 available in this paper. 

- 592 **Code availability** 

- 593 All computational data are presented in the manuscript. All DFT calculations were 

- 594 performed by using the Vienna ab initio simulation package (VASP), which is commercially 

- 595 available at https://www.vasp.at/. 

- 596 **Competing interests** 

- 597 The authors declare no competing interests. 

- 598 

- 599 

27 

## 600 **Extended data figure legend** 

- 601 **Extended Data Fig. 1 | Growth method and annealing protocol for growth of single-** 

602 **crystal tri-layer hBN on Ni (111).** (a) Electron backscatter diffraction (EBSD) IPF map in 603 the normal direction of Ni (111) foil produced by the contact-free annealing method. (b) 604 Schematic diagram of high-temperature and low-pressure CVD for the growth of hBN on Ni 605 (111). (c) Temperature-time profile for hBN growth. (d) Photograph of a 2 cm x 5 cm as606 grown single-crystal tri-layer hBN film on Ni (111). 

607 

608 **Extended Data Fig. 2 | Uniformity of aligned growth of hBN flakes on Ni (111).** (a-b) 609 Large-area SEM images of as-grown unidirectionally aligned hBN flakes on Ni (111) 610 substrate after growth for 30 min. AFM images of tri-layer hBN islands for the growth times 611 of (c) 30 and (d) 45 min. The insets in (c) and (d) show height measurements taken at the 612 position of the yellow lines. The average thickness of hBN islands at the growth time of 30 613 min (total 25 flakes) and 45 min (total 17 flakes) is 1.03 ± 0.06 and 1.05 ± 0.03 nm, 614 respectively. It suggests uniform thickness of the tri-layer hBN film in large area. 

615 

616 **Extended Data Fig. 3 | Thickness uniformity of tri-layer hBN film transferred onto SiO2** 

617 **(300 nm)/Si.** Photograph of 2 cm × 5 cm hBN film transferred onto the SiO2 (300 nm)/Si 618 substrate and AFM images obtained at the 8 marked positions. Insets show representative 619 height profiles at the film edges. The mean and standard deviation of AFM thickness at 24 620 positions is 1.27 ± 0.06 nm. 

621 

28 

- 622 **Extended Data Fig. 4 | The effect of cooling rate on hBN thickness.** AFM images of hBN 

- 623 film transferred onto SiO2/Si for the cooling rates of (a) -30<sup>o</sup> C/min and (b) -5<sup>o</sup> C/min 624 (cooling from 1220<sup>o</sup> C to 620<sup>o</sup> C in both cases). 

625 

626 **Extended Data Fig. 5 | Atomic distributions, cooling rate effect, and time evolution of** 627 **hBN/Ni23B6/Ni.** Energy filtered TEM (EF-TEM) mapping of hBN/Ni23B6/Ni. (a) Cross628 sectional TEM image (upper left) and Energy filtered TEM (EF-TEM) maps of boron (red), 629 nitrogen (green), and nickel (blue). (b) An image of overlaid EF-TEM maps for all elements. 630 The effect of cooling rate for cooling from 1220 to 620<sup>o</sup> C. Cross-sectional TEM images of 631 as-formed Ni23B6 alloy for the cooling rates of (c) -60<sup>o</sup> C/min, (d) -30<sup>o</sup> C/min, and (e) -5 632 oC/min. (f) Proposed mechanism for escape of B atoms during cooling. Slow cooling causes 633 escape of more B atoms, and the thickness of Ni23B6 alloy decreases. (g-i) schematic 634 diagrams (upper panels) and cross-sectional TEM images (lower panels) at the different 635 growth times of (g) 30 min, (h) 45 min, and (i) 60 min at 1220<sup>o</sup> C. Cross-section TEM images 636 show the Ni23B6 surface near the boundary of Ni23B6/Ni and Ni surface after growth for 30 637 min. 

638 

639 **Extended Data Fig. 6 | Growth of hBN on Ni (111) at different growth temperature.** 

640 SEM images of hBN grown on Ni (111) for 30 min at (a) 1020<sup>o</sup> C, (b) 1120<sup>o</sup> C, (c) 1170<sup>o</sup> C, 641 (d) 1220<sup>o</sup> C, (e) 1270<sup>o</sup> C, and (f) 1320<sup>o</sup> C. The average thickness of hBN islands at 1170<sup>o</sup> C is 

642 1.05 ± 0.04 nm. The inset of (a) shows the SAED pattern of the hBN film grown at 1020<sup>o</sup> C. 

643 

29 

644 

645 **Extended Data Fig. 7 | Analysis of the crystal orientation of single-crystal tri-layer and** 646 **polycrystal multilayer hBN films with LC (5CB)-assisted POM.** (a) Schematic of LC 647 alignment on hBN and (b) a corresponding photograph. Area 1, 2 and 3 in (b) are pieces (1 648 cm × 1 cm) broken from a large hBN film (2 cm × 5 cm) on SiO2 (300 nm)/Si. (c) 649 Representative POM images of LC-coated hBN film as a function of the polarized light 650 angles from 0 to 180<sup>o</sup> at the Area 1 in (b). POM images of Area 2 and 3 are same as Area 1. 651 (d) POM images of LC-coated polycrystal hBN film as a function of the polarized light 652 angles from 0 to 180<sup>o</sup> . The inhomogeneous color contrast is shown as a function of the 653 polarized light angles. 

654 

655 

**Extended Data Fig. 8 | Analysis of crystalline domains with polarized second-harmonic** 

656 **generation (SHG) imaging and photoluminescence (PL) spectra.** Optical micrographs of 657 (a) 'single-crystal' tri-layer hBN and (b) polycrystalline multi-layer hBN films. Raster 658 scanning images of SHG intensity ratio, (Icross/Ipara)<sup>0.5</sup> , which is governed by the 659 crystallographic orientation: (c) single-crystal tri-layer hBN and (d) polycrystalline multi660 layer hBN films. Ipara and Icross denote the SHG signals parallel and perpendicular to the 661 polarization of the fundamental 950 nm beam, respectively. The images were obtained within 662 the blue squares of (a) and (b). Histograms in (e) and (f) show the ratio distribution of (c) and 663 (d), respectively. (e) Shows a single domain in the area of 150  m  150  m, whereas (f) 664 shows 4 grains. Note that the center-to-center distance in tri-layer hBN islands in Fig. 1 and 665 Extended Data Fig. 2 is less than 20  m. The results indicate that the tri-layer hBN sample in 666 (a) _is a single crystal thus without any grain boundaries_ , unlike the polycrystalline hBN 

30 

- 667 sample in (b). (g) PL spectra of single-crystal tri-layer and (h) polycrystalline hBN films on 

- 668 SiO2 (300 nm)/Si substrate. Spectra were measured at 10 different positions for each sample 669 and all showed essentially the same result. The excitation wavelength is 340 nm (140 fs 80 670 MHz, 1.3 mW). While the PL emission of polycrystalline hBN appears at 565 nm (~2.19 eV), 

- 671 that of single-crystal tri-layer hBN film is the same as from the SiO2 (300 nm)/Si substrate. 

672 

673 **Extended Data Fig. 9 | Growth and characterizations of 2-layer and 5-layer hBN films.** 

674 (a) Photograph of 5 mm  5 mm bi-layer hBN film on a SiO2 (300 nm)/Si substrate after 675 transfer. (b) Raman spectra at the 16 positions indicated in (a). (c) Comparison of Raman 676 spectra of bi-layer and tri-layer hBN. The absolute Raman intensity of bi-layer hBN (197.1 ± 677 17.4) is 1.6 times lower than that of tri-layer hBN (314.4 ± 23.5). This is consistent with the 

678 results reported for the ratio of Raman peak intensities for mechanically exfoliated tri-layer 679 and bi-layer hBN<sup>52</sup> . (d) AFM images show 4 edges of the bi-layer hBN film transferred onto 680 the SiO2 (300 nm)/Si substrate. Representative height profiles are shown in the insets. The 681 average AFM thickness at 12 positions is 0.91 ± 0.04 nm. (e) POM images of LC-coated bi682 layer hBN film as a function of the polarized light angle (from 0 to 180<sup>o</sup> ). (f) Photograph of 5 683 mm  5 mm 5-layer hBN film on a SiO2 (300 nm)/Si substrate after transfer. (g) Raman 684 spectra at the 16 positions indicated in (f). (h) Comparison of Raman spectra of tri-layer and 685 5-layer hBN. The absolute Raman intensity of 5-layer hBN (515.6 ± 24.1) is 1.64 times 686 higher than that of tri-layer hBN (314.4 ± 23.5). This is consistent with the result for the ratio 687 of Raman peak intensities for mechanically exfoliated 5-layer and tri-layer hBN<sup>52</sup> . (i) AFM 688 images show 4 edges of the 5-layer hBN film transferred onto the SiO2 (300 nm)/Si substrate. 689 Representative height profiles are shown in the insets. The average AFM thickness at 12 

31 

- 690 positions is 1.93 ± 0.11 nm. (j) POM images of LC-coated 5-layer hBN film as a function of 

- 691 the polarized light angle (from 0 to 180<sup>o</sup> ). 

- 692 As we demonstrated above, we could control the thickness of hBN film with different 

- 693 calculated specific binding energies by changing flows of reactant gases which affects 

- 694 chemical equilibrium and chemical potential. Our standard condition leads to commonly 

- 695 observed single crystal 3L hBN in a broad range of borazine gas flow rate, and we need to 

- 696 significantly change the amount of borazine or to add another precursor, N2, as a feedstock to 

- 697 change the chemical equilibrium to tune the hBN thickness. Finally, we found bi-layer hBN 

- 698 when borazine gas flow was reduced from 0.1 sccm to 0.025 sccm. hBN thicker than tri-layer 

- 699 was observed when large N2 gas flow (50 sccm) was added. 

- 700 

- 701 **Extended Data Fig. 10 | Configurations of an hBN nucleus (N7B6) at different sites of** 

- 702 **vicinal Ni (111) substrates.** The calculated binding energy are shown below with a unit of 

- 703 eV. 

- 704 

- 705 

- 706 

32 



<!-- Start of picture text -->
a<br>(i) 0 min (ii) 30 min (iii) 45 min (iv) 60 min<br>hBN hBN<br>5 μm 5 μm<br>30 μm 30 μm 30 μm 30 μm<br>b SiO2 hBN d<br>1.2 nm<br>350 1. (312.1±21.2) 2. (308.9±24.4)<br>1 μm<br>1 2 3 4<br>5 6 7 8<br>9 10 11 12<br>1 μm<br>0<br>3. (314.4±22.7) 4. (300.1±21.9) 5. (315.1±24.2) 6. (326.1±17.3) 7. (319.7±28.2)<br>c<br>1.1k 1368 cm -1<br>(E2g)<br>1.0k 8. (311.1±14.1) 9. (304.9±25.7) 10. (326.4±24.9) 11. (327.1±18.9) 12. (326.2±20.5)<br>FWHM: 14.3 cm -1<br>0.9k<br>0.8k<br>1200 1300 1400 1500 1600 1700<br>Wavenumber (cm-1)<br>e 0.200.15 2x106x104x10131313 Optical bandgap (OBG): 6.05 eV f 7k6k B 1s 190.2 eV(B-N) 187.9 eV(B-Ni) 12k9k N 1s 397.9 eV(N-B) g 4k B 1s 190.1 eV(B-N) 9k6k N 1s 397.9 eV(N-B)<br>0.10 3k<br>0.05 0 6.0 Photon Energy (eV) 5.8 5.6 5.4 5k 6k 3k<br>∽ 200 nm<br>0.00 4k 3k 2k<br>200 240 280 320 195 192 189 186 402 399 396 393 195 192 189 186 402 399 396 393<br>Wavelength (nm) Binding energy (eV) Binding energy (eV) Binding energy (eV) Binding energy (eV)<br>h<br>Boron<br>Nitrogen<br>(BHNH)3 Hydrogen<br>Ni23B6<br>Ni<br>Step i: Dissociation of borazine Step ii: Dissolution of B atoms Step iii: Growth of tri-layer hBN Step iv: Coalescence of tri-layer hBN Step v: Formation of Ni23B6 during cooling<br>).( tiItasnenuy .<br>2)<br>itbAnopros 22 �� (eV/cm(E ).( tiItasnenuy . ).( tiItasnenuy .<br><!-- End of picture text -->



<!-- Start of picture text -->
a b c e<br>��<br>Ni23B6<br>200 nm Ni23B6 1 nm ��<br>d<br>Ni<br>Ni<br>200 nm 2 nm<br>Ni B Z. A. = [110]<br>: . Å, : .<br>f g h<br>0002<br>�<br>hBN<br>Z. A.=[ � ]<br>Ni23B6 0.33 nm i<br>111<br>A 002<br>A’<br>10 nm A 5 Å 2 nm<br>Z. A.=[110]<br>j ⅰ ⅱ ⅲ k ⅰ ⅱ ⅲ ⅳ<br>ⅳ ⅴ ⅵ θ θ θ θ<br>ⅶ ⅷ ⅸ<br>200 μm 5 1/nm 36.05˚ 5 1/nm 36.39˚ 5 1/nm 36.41˚ 5 1/nm 36.24˚<br>ⅴ ⅵ ⅶ ⅷ ⅸ<br>θ θ θ<br>θ θ<br>5 1/nm 36.71˚ 5 1/nm 36.68˚ 5 1/nm 36.70˚ 5 1/nm 36.86˚ 5 1/nm 36.64˚<br><!-- End of picture text -->



<!-- Start of picture text -->
a c e<br>1 min 30 min -1.875 5-layer<br>6-layer<br>1 μm 1 μm -1.890<br>00º o 60º60 o 4-layer<br>1 st layer Ni              2 nd layer Ni                3 rd layer Ni -1.905 7-layer<br>1 μm 5 μm mono-layer  bi-layer  tri-layer<br>-3.0 -1.920 Eb2<br>b -1.935<br>-7.0<br>Eb1<br>A B<br>-7.5 -2.265<br>0 30 60 90 120 Eb2<br>Rotation angle ( � ) -2.280<br>d<br>C D<br>-2.295<br>0 o 60 o Nucleus<br>-12.0 A B 0.137 -2.310 Eb2<br>D -6.900<br>-14.0 0.356<br>C<br>-6.915<br>0.0<br>Rotation angle ( � )<br>� -2(eV)Enmb1<br>� -2)(eVEnmb2<br>)V<br>e<br>(<br>g<br>nid<br>ni<br>B<br><!-- End of picture text -->



<!-- Start of picture text -->
a b d 102 with hBN<br>C.E. R.E. W.E. H2 hBN/Ni23Be - 6 2000 cycles 101010-110 In/Auwithout hBNMoShBNSiO2 2/Si<br>10-2<br>e - 10-3 μ : 56 cm 2 /Vs μ : 90 cm 2 /Vs<br>Electrolyte H + 20 μm 10-4<br>10-5<br>-20 -10 0 10 20<br>Gate voltage (V)<br>)/( tAmnerrcμμu<br>iDnar<br><!-- End of picture text -->



<!-- Start of picture text -->
c<br>Peel-off test of a polycrystal hBN by proton penetration through the grain boundary<br>H2<br>H + Grain boundary<br>Ni Ni Ni<br>0 cycles 50 cycles 500 cycles<br>2 μm 2 μm 2 μm<br><!-- End of picture text -->

