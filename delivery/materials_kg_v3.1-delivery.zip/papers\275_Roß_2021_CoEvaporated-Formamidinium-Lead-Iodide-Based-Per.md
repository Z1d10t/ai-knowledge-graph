# Co‐Evaporated Formamidinium Lead Iodide Based Perovskites with 1000 h Constant Stability for Fully Textured Monolithic Perovskite/Silicon Tandem Solar Cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Advanced Energy Materials |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 182 |
| 作者 | M. Roß, Stefanie Severin, M. Stutz, P. Wagner, H. Köbler, Martin Favin–Lévêque, A. Al-Ashouri, Paul Korb et al. |
| DOI | 10.1002/aenm.202101460 |
| 源文件 | 059_Roß_2021_CoEvaporated-Formamidinium-Lead-Iodide-Based-Per.pdf |

---
**ReseaRch aRticle** 



**www.advenergymat.de** 

# **Co-Evaporated Formamidinium Lead Iodide Based Perovskites with 1000 h Constant Stability for Fully Textured Monolithic Perovskite/Silicon Tandem Solar Cells** 

_Marcel Roß,* Stefanie Severin, Marvin Björn Stutz, Philipp Wagner, Hans Köbler, Martin Favin-Lévêque, Amran Al-Ashouri, Paul Korb, Philipp Tockhorn, Antonio Abate, Bernd Stannowski, Bernd Rech, and Steve Albrecht*_ 

## **1. Introduction** 

**Formamidinium iodide (FAI) based perovskite absorbers have been shown to be ideal candidates for highly efficient and operationally stable perovskite solar cells (PSC). A major challenge for formamidinium lead iodide (FAPbI3) is to suppress the phase transition from the photoactive black phase into yellow nonperovskite** **_δ_ -phase. Several approaches to stabilize the black phase have been developed for solution-based perovskites, whereas so far, vacuum-deposited FAPbI3 has rarely been reported. This study demonstrates the preparation of FAPbI3 by co-evaporation and discusses the influence of the subjacent hole transporting layer (HTL) on its phase stability. By using FAI excess in the evaporation process in combination with phosphonic acids groups from the HTL, the black perovskite phase is stabilized at room temperature. Further addition of 32–59% methylammonium iodide (MAI) during the co-evaporation process leads to good absorption properties and high PSC efficiencies of 20.4%. In addition, excellent stability is achieved for optimized MAI to FAI ratios, maintaining 100% of the initial PSC performance after 1000 h under constant operation. This highly stable perovskite composition enables the first monolithic fully textured perovskite/silicon tandem solar cells with co-evaporated perovskite absorbers. Due to the conformally covered pyramid texture, these tandem cells show minimal reflection losses and reach an efficiency of 24.6%.** 

Providing sufficient energy from photovoltaics for humanity’s growing demand motivates research on new absorber materials and solar cells designs. Metal halide perovskites are among these new materials, as they offer preferable optoelectronic properties<sup>[1,2]</sup> and favorable manufacturing perspectives. Due to the high absorption coefficients<sup>[3]</sup> in combination with long charge carrier diffusion lengths<sup>[4,5]</sup> compared to typical film thicknesses in the order of 500 nm, light can be efficiently absorbed and charges can be collected effectively by selective contacts. In addition, a high tolerance against defects was found for perovskite films processed with various deposition techniques.<sup>[6–8]</sup> Therefore, metal halide perovskites attracted a lot of interest in the last decade. In particular, the increase in power conversion efficiency (PCE) of perovskite solar cells (PSCs) from 14% to over 25% within 7 years is outstanding.<sup>[9,10]</sup> Another great 

M. Roß, S. Severin, P. Wagner, M. Favin-Lévêque, A. Al-Ashouri, P. Korb, H. Köbler, A. Abate P. Tockhorn, S. Albrecht Young Investigator Group Active Materials and Interfaces Young Investigator Group Perovskite Tandem Solar Cells for Stable Perovskite Solar Cells Helmholtz-Zentrum Berlin Helmholtz-Zentrum Berlin Kekuléstraße 5, 12489 Berlin, Germany Kekuléstraße 5, 12489 Berlin, Germany E-mail: marcel.ross@helmholtz-berlin.de; B. Stannowski steve.albrecht@helmholtz-berlin.de Helmholtz-Zentrum Berlin für Materialien und Energie GmbH M. B. Stutz PVcomB, 12489 Berlin, Germany Humboldt-Universität zu Berlin B. Stannowski Brook-Taylor-Str. 2, 12489 Berlin, Germany Beuth University of Applied Sciences Berlin 13353 Berlin, Germany The ORCID identification number(s) for the author(s) of this article B. Rech, S. Albrecht can be found under https://doi.org/10.1002/aenm.202101460. Faculty of Electrical Engineering and Computer Science © 2021 The Authors. Advanced Energy Materials published by WileyTechnical University Berlin VCH GmbH. This is an open access article under the terms of the CreaMarchstraße 23, 10587 Berlin, Germany tive Commons Attribution License, which permits use, distribution and B. Rech reproduction in any medium, provided the original work is properly cited. Helmholtz-Zentrum Berlin für Materialien und Energie GmbH Scientific Management **DOI: 10.1002/aenm.202101460** 12489 Berlin, Germany 

**DOI: 10.1002/aenm.202101460** 

**2101460 (1 of 14)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101460 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

advantage of metal halide perovskites is, that their bandgap can be easily tuned by anion or cation exchange.<sup>[11]</sup> Therefore, metal halide perovskites are excellent absorber materials for tandem applications.<sup>[12]</sup> The combination with crystalline silicon in tandem solar cells is particularly attractive as silicon based solar cells currently dominate the photovoltaic market.<sup>[13]</sup> The potential of monolithic perovskite/silicon tandem solar cells is demonstrated by use of solution processing to be over 29% efficient,<sup>[14]</sup> which significantly exceeds the record efficiency of silicon or perovskite single-junction solar cells.<sup>[15]</sup> 

A great advantage of perovskites is the simplicity of preparation and the variety of deposition techniques.<sup>[7,8,16–18]</sup> Presently, most perovskite solar cells are prepared by solution-based methods,<sup>[19]</sup> such as spin coating,<sup>[20]</sup> slot-die coating,<sup>[21]</sup> or inkjet printing.<sup>[22]</sup> These methods require the use of large amounts of often toxic solvents. In addition, these techniques do not allow or complicate a conformal deposition on textured substrates and are unsuitable to cover thin films on rough surfaces with high aspect ratios.<sup>[23]</sup> In these aspects, vacuum-based deposition methods are superior over solution processing.<sup>[8,24]</sup> Moreover, vacuum-based deposition methods allow for good control of layer thicknesses and enable homogeneous coating on large substrates more easily.<sup>[25,26]</sup> 

For solution-based high efficient single-junction solar cells, formamidinium iodide (FAI) based perovskite absorbers with band gaps of around 1.55 eV have become the preferred choice to enable single-junction efficiencies above 25%.<sup>[10]</sup> This is due to their more suitable band gap closer to the detailed balance optimum, and the enhanced thermal stability.<sup>[10,27–31]</sup> Moreover, a variety of strategies have been developed to suppress the phase conversion from _α_ - to _δ_ -phase, which is one of the main drawbacks of FAPbI3 perovskites.<sup>[32–34]</sup> 

In contrast, methylammonium lead iodide (MAPbI3) is still the standard for most co-evaporated perovskite solar cells, thus all PCEs of over 20% published to date have been obtained with pure MAPbI3.<sup>[35–39]</sup> For pure FAPbI3 perovskites prepared by co-evaporation, PCE values over 14% have been reported.<sup>[40,41]</sup> These lower performances might originate from the phase instability. Recently, Borchert et al. demonstrated that the yellow, nonperovskite _δ_ -phase ( _δ_ -FAPbI3) is dominantly formed during the co-evaporation of FAI and PbI2.<sup>[40]</sup> By subsequent thermal annealing, the _δ_ -phase can be converted into the desired black perovskite trigonal _α_ -phase. Unfortunately, FAPbI3 perovskites suffer from a phase transformation of the black phase into the yellow nonperovskite _δ_ -phase.<sup>[42]</sup> For solution-processed perovskites it has been proven a viable approach to stabilize the black perovskite phase of FAPbI3 by the inclusion of cations with smaller ion radii such as Cs<sup>+</sup> or MA<sup>+</sup> .<sup>[27,43]</sup> This approach is also followed by Gil-Escrig and coworkers, who included MAI to prepare phase pure, cubic MA0.5FA0.5PbI3 perovskite solar cells with high efficiency by co-evaporation at room temperature.<sup>[41]</sup> Also more complex compositions such as triple cation.<sup>[24]</sup> with a band gap of 1.70 eV and PCE of 16%, or MAI-free perovskites, e.g., formamidinium cesium lead iodide bromide, with PCEs above 18%<sup>[44]</sup> can be prepared by co-evaporation. However, the efficiencies of pure MAPbI3 could not yet be surpassed for co-evaporated perovskite solar cells. Only with a recently reported layer-by-layer deposition process of PbI2, FAI, and CsI followed by an in-vacuum temperature 

treatment an efficiency of over 21% was achieved by vacuum deposition.<sup>[45]</sup> 

Vacuum-based deposition are particularly attractive for perovskite/silicon tandem solar cell processing, as this technique allows to conformally cover the microscopic pyramid textures of typical silicon wafers. Until now, all perovskite/ silicon tandem solar cells have been realized by including at least one solution-assisted fabrication step for the perovskite absorber.<sup>[46–48]</sup> Slot-die-coating and blade-coating processes enabled monolithic tandem solar cells on medium-sized (≈2 µm) pyramidal textures. However, the perovskite absorber does not retain the texture, and is therefore not conformally deposited.<sup>[46,47]</sup> In 2018, Sahli et al. reported a hybrid process in which PbI2 and PbBr2 were first evaporated and then a mixture of formamidinium bromide and iodide was spin-coated to prepare a fully textured monolithic perovskite/silicon tandem solar cell.<sup>[49]</sup> This rather complex two-step process suffers from the drawbacks of solution processing and until now led to perovskites with limited fill factors and pronounced hysteresis. The co-evaporation method, on the other hand, can easily provide conformal and uniform films on micrometer-textured glass or silicon.<sup>[25,49–51]</sup> Although several publications highlighting evaporated films on such textures, up to now no perovskite/ silicon tandem solar cell could be realized. The reasons for this are barely investigated so far. One possible explanation might be the low stability of MAPbI3<sup>[52–54]</sup> – the predominant composition investigated for co-evaporated perovskites – that could suffer from process-induced damages. Overall, aspects of perovskite process stability as well as long-term stability are of fundamental importance for both single-junction and tandem solar cells.<sup>[55–57]</sup> Therefore, this work addresses various aspects of stability related to coevaporate FAPbI3 and MAFAPbI3 perovskites. In the first part of this study, we focus on the preparation of pure FAPbI3 by co-evaporation and discuss the influence of the subjacent hole transporting layer (HTL) [2-(3,6-Dimethoxy9 _H_ -carbazol-9-yl)ethyl]phosphonic Acid (MeO-2PACz)<sup>[58]</sup> on its phase stability. We demonstrate that free phosphonic acids groups significantly affect the stability of the black FAPbI3 perovskite phase. We succeed in stabilizing the black perovskite phase at room temperature for the first time, by combining free phosphonic acids from the HTL with additional FAI excess in the evaporation process. 

Furthermore, we demonstrate that FAI can be easily replaced by MAI in the co-evaporation process, and we correlate the evaporation-rate to stoichiometry ratios in the film by nuclear magnetic resonance (NMR) spectroscopy. We find that the optimal MAI mole fraction, in terms of absorption properties and PCE, is between 32% and 59%. Using a perovskite with MAI content in this range, we achieve solar cells with excellent stability, maintaining 100% of their initial performance after 1000 h in permanent operation. 

Finally, we identify the deposition-induced damage of the semi-transparent top contact as a crucial step in the fabrication of fully textured perovskite/silicon tandem solar cells when using MAPbI3 absorbers. By replacing it with a more stable MAFAPbI3 composition, we realized the first fully textured monolithic perovskite/silicon tandem solar cell with a co-evaporated perovskite absorber that reaches a remarkable PCE of 24.5%. Further optimization of the current matching 

**2101460 (2 of 14)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101460 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



<!-- Start of picture text -->
A B<br>C D<br><!-- End of picture text -->

**Figure 1.** A) Schematic of the herein used hole selective layer MeO-2PACz as deposited without any washing treatment. B) MeO-2PACz layer after washing with ethanol to form a self-assembled monolayer. C,D) XRD patterns of FAPbI3 films before and after annealing prepared with three different molar ratios (determined based on the deposition rate) on C) unwashed MeO-2PACz and D) washed MeO-2PACz. The expected position of the most characteristic reflexes is highlighted with dotted lines: for _δ_ - FAPbI3 in yellow, for PbI2 in dark red, and for the _α_ -FAPbI3 perovskite in light blue. 

will enable fully textured perovskite/silicon tandem solar cells by co-evaporation that are on par with state-of-the-art devices employing solution-processed perovskites. 

## **2. Phase Stability of Pure FAPbI3 Perovskite** 

To obtain formamidinium-based perovskite absorbers, we simultaneously evaporate the precursor materials FAI and PbI2 from two individual thermal evaporation sources. For all processes, the evaporation rate of each material is kept constant by automatically adjusting the source temperature (for details see Supporting Information). Initially, we prepare FAPbI3 films with three different molar ratios, according to the rates determined on the quartz crystal microbalance (QCM) of each material. Starting with a FAI to PbI2 molar ratio of 0.85–1 (lead iodide excess) we obtain yellowish brown films. As expected from literature,<sup>[40]</sup> the color of these films changes during annealing at 145 °C for 10 min (Figure S1A, Supporting Information). This 

color change can be explained by a transition of the yellow _δ_ -phase to the black perovskite phase. Besides the color, the morphology of the films (see Figure S1B,C in the Supporting Information), changes as well. Before annealing the films are characterized by areas with very small (≈50 nm) and disordered grains, interspersed with round, ≈250 nm large grains. After annealing, the grain size distribution, estimated from the SEM image, is more homogeneous with diameters of around 150 – 300 nm and the areas with small, disordered structures are significantly reduced. With increasing FAI content towards stoichiometry and organic precursor excess, we notice that also the nonannealed films show a black color. **Figure 1** C displays the XRD patterns of films prepared with FAI to PbI2 ratios of 0.85/1 (lead iodide excess – FA0.85PbI2.85), 1/1 (stoichiometric –FAPbI3), and 1.15/1 (organic precursor excess – FA1.15PbI3.15) each before and after annealing. For the films with the lowest FAI content, the yellow nonperovskite phase and the expected PbI2 excess are clearly visible. After annealing of films with this rate ratio, a certain amount of the black perovskite phase can be 

**2101460 (3 of 14)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101460 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

observed along with the _δ_ -phase. For stoichiometric films, the PbI2 signal disappears and the mixture of yellow _δ_ -phase and black perovskite phase is already present before the annealing. After annealing the black perovskite phase is predominantly present. For the highest FAI content with organic precursor excess, the films consist exclusively of the black perovskite phase and no difference in phase composition can be observed between annealed and nonannealed films. With the help of a high FAI ratio, the black perovskite phase of pure FAPbI3 can be stabilized at room temperature without the addition of other cations like Cs<sup>+</sup> or MA<sup>+</sup> . To the best of our knowledge, this is the first report of a stable, pure FAPbI3 perovskite film prepared by co-evaporation at room temperature. As previous publications on vacuum processed FAPbI3 perovskites employed different contact materials, such as _N_ 4, _N_ 4, _N_ 4″, _N_ 4″-tetra([1,1′-biphenyl]4-yl)-[1,1′:4′,1″-terphenyl]-4,4″-diamine (TATM) or buckminsterfullerene (C60) and could not demonstrate the stabilization of the black phase with FAI excess,<sup>[40,41]</sup> we suspected a connection between the stabilization of the black perovskite phase and the nature of the subjacent selective contact. 

One of the major differences of the selective contact MeO-2PACz used here to other organic transport layers such as C60 or TATM is the phosphonic acid functionality. Depending on how the MeO-2PACz layer is deposited and the orientation of its molecules towards the substrate, these phosphonic acid groups can be free (Figure 1A) or bonded (Figure 1B). If the MeO- 2PACz layer is first deposited via spin coating and afterwards washed with its former solvent (ethanol), unbound molecules are removed and no free phosphonic acids groups are present with orientation towards the free surface. Then a proper self-assembled monolayer can be formed as depicted in Figure 1B. If washing after spin coating is omitted, molecules with their phosphonic acid group pointing upwards remain. The details of the two different ways to prepare the MeO-2PACz layer are described in the experimental part. The XRD patterns of perovskite films grown by co-evaporation prepared on unwashed MeO-2-PACz layers that contain free phosphonic acid groups, are presented in Figure 1C. The results of the same experiment repeated on washed MeO-2PACz, are shown in Figure 1D. Interestingly, the underlying hole selective contact film property causes fundamentally different XRD patterns of the co-evaporated perovskite film grown on top: For all films and rate ratios, a clear PbI2 signal can be seen, even for strong organic precursor excess. Even with the highest FAI rate, the film consists mainly of the yellow _δ_ -phase before annealing. By annealing at 145 °C for 10 min, the film converts into the black perovskite phase, but XRD reflexes of the yellow _δ_ -delta phase are still visible, indicating an incomplete conversion. In agreement with reports using TATM and C60,<sup>[40,41]</sup> it is therefore not possible to stabilize the black FAPbI3 phase on washed MeO-2PACz at room temperature. To be sure that the herein presented stabilization of black FAPbI3 phase is an effect of the unbound molecules with free phosphonic acid groups, we prepared further samples with different MeO-2PACz concentrations in the same evaporation run. With increasing concentration of the MeO-2PACz solution for unwashed samples, the ratio of the perovskite phase to the _δ_ -phase clearly increases. From a concentration of 0.8 × 10<sup>−3</sup> m, only the black perovskite phase is present (Figure S2, Supporting Information). 

Overall, the free phosphonic acid groups present in unwashed MeO-2PACz films in combination with the FAI excess seem to be crucial for the stabilization of the black perovskite phase. In other studies, it has already been shown that subjacent contact layers have an important influence on the growth of the perovskite during co-evaporation.<sup>[38,59]</sup> Our results underline this substrate sensitivity of the co-evaporation process for FAPbI3, as even the same hole-selective material deposited in different ways can strongly influence the resulting evaporated perovskite. One potential reason for the observed differences can be the nature of the phosphonic acid group, which is a particularly versatile ligand,<sup>[60]</sup> and can strongly interact with FAI via hydrogen bonds.<sup>[61]</sup> This interaction might enable an increased incorporation of FAI into the perovskite during the co-evaporation, which is in line with the results shown in Figure 1C,D, indicating an enhanced lead iodide formation in the films prepared on washed MeO-2PACz. That the growth process is changing between washed and unwashed MeO-2PACz is also visible in the SEM cross section image (Figure S3, Supporting Information) of annealed FA1.15PbI3.15 films. While large grains are obtained for washed MeO-2PACz, small disordered structures are visible for unwashed MeO-2PACz. In addition to the significant change in morphology, we also see a higher layer thickness for films prepared on unwashed MeO-2PACz, which further indicates that more FAI is incorporated into the unwashed MeO-2PACz samples. 

Solar cells in p-i-n architecture with washed and unwashed MeO-2PACz are fabricated using the solar cell stack shown in **Figure 2** A. Despite the influence of the HTL preparation, three different FAI to PbI2 ratios of 0.85, 1, and 1.15 are analyzed. For the organic precursor excess (highest FAI rate), solar cells were prepared with annealed and nonannealed films. Since for all other conditions the nonannealed films consisted almost entirely of the yellow _δ_ -phase, solar cells were only prepared from annealed samples. Figure 2B shows the statistics of the measured solar cell PCE in current-density/voltage ( _J_ – _V_ ) scan under simulated AM1.5G illumination for open-circuit voltage to short circuit current density (reverse) and short circuit current density to open-circuit voltage (forward) scan direction. The corresponding photovoltaic performance parameters open-circuit voltage ( _V_ oc), short circuit current density ( _J_ sc), fill factor (FF), as well as the external quantum efficiency (EQE) spectra are displayed in Figure S4 in the Supporting Information. 

For washed MeO-2PACz the best solar cells, which reach an efficiency of up to 16%, are prepared with lead iodide excess (FA0.85PbI2.85). With stoichiometric conditions, the _J_ sc of the unwashed solar cells increases (Figure S4A, Supporting Information) but the _V_ oc and thus the efficiency is reduced. The lower _V_ oc (Figure S4C, Supporting Information) is most likely a consequence of the missing PbI2 excess, which has been reported to reduce recombination losses for solution-based perovskite solar cells.<sup>[62,63]</sup> Although the black phase of FAPbI3 is stabilized with increasing FAI content on unwashed MeO-2PACz, the PCE decreases significantly for the solar cells prepared with organic precursor excess, which is due to the further reduced _V_ oc as well as the low FF (Figure S4B, Supporting Information). For FA1.15PbI3.15, the black perovskite phase is obtained on unwashed MeO-2PACz even without annealing, but these 

**2101460 (4 of 14)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101460 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 





**Figure 2.** A) Schematic p-i-n single junction solar cell layout. B) Statistical comparison of solar cell PCE extracted from _J_ – _V_ scans (reverse and forward) measured under simulated AM1.5G illumination for 3 different FAI to PbI2 ratios. Washed (open triangles) and nonwashed (filled circles) MeO-2PACz hole-selective layers as well as annealed (red boxes) and nonannealed (blue boxes) perovskite films are shown. The boxes are determined by the 25th and 75th percentiles, the squares represent the mean values and the horizontal lines the median. 

solar cells do not achieve high efficiencies. Attributed to the low _J_ sc also reflected in the corresponding EQE spectrum, the maximum PCE achieved with nonannealed samples is only 4.8%. 

For the washed samples, the PCE is increasing with increasing FAI content, which is in line with the XRD results, showing an excess of PbI2 for all films and the lowest proportion of _δ_ -phase for FA1.15PbI3.15. The increased FAI content leads in particular to a higher _J_ sc of the washed solar cells (Figure S4A, Supporting Information). Therefore, the washed samples achieve the highest PCEs of above 16% with organic precursor excess (FA1.15PbI3.15). 

Overall, Figure 2B shows that the annealing step is essential for high solar cell performance and indicates that highest PCEs are obtained with a certain excess of PbI2. The different trends in PCE observed for washed and unwashed MeO-2PACz show again the substantial influence of the underlying contact on the resulting perovskite. 

In summary, we show that it is possible to stabilize the black perovskite phase at room temperature on unwashed MeO-2PACz with organic precursor excess by using FAI to PbI2 rate ratios of 1.15 to 1. For films with organic precursor excess (FA1.15PbI3.15) no difference in XRD between annealed and nonannealed samples is observed. Unfortunately, the required amounts of FAI lead to a reduced PCE of the solar cells. Furthermore, we notice that the solar cells annealed after deposition, show in all cases higher PCEs. The highest PCE is achieved with a slight excess of PbI2 and therefore it is not attractive to stabilize the black phase with FAI excess. In the following, we will present stabilization of the black FAPbI3 phase by including methyl ammonium cations from the coevaporation of MAI into the perovskite. 

## **3. MAFAPbI3-Stabilizing Perovskite with MAI** 

Based on the more effective stabilization of the black FAPbI3 perovskite phase on unwashed MeO-2PACz, the further 

experiments will employ this HTL and nominal excess of organic precursor (sum of MAI and FAI). Starting from pure FAPbI3, an increasing amount of MAI is added and the resulting mixture is further denoted as MAFAPbI3. For this purpose, the rate of FAI is reduced and MAI, evaporated from a third source, is accordingly added. 

To ensure that these changes in rates are also reflected in the composition of the resulting perovskite films, we determined the molar ratio between FAI and MAI using<sup>1</sup> H-NMR spectroscopy. Pareja-Rivera et al. already demonstrated that this technique is useful to determine the exact composition of perovskite films.<sup>[64]</sup> The method presented in their study involves scratching and weighing the perovskite powder and requires therefore large quantities of perovskite material (minimum 15 mg). To analyze smaller sample quantities (≈2 mg), we adapted the procedure: By only determining the MAI to FAI ratio, we avoid the addition of an internal standard and the material-consuming weighing. The perovskite films were directly dissolved in deuterium oxide and the peak area of the methyl group of MAI (2.62 ppm) was compared with that of the CH group of FAI (7.84 ppm). Details on the procedure, including an example<sup>1</sup> H-NMR spectrum, can be found in the Supporting Information. **Figure 3** shows the MAI mole fraction expected from evaporation rates and the MAI mole fraction of the co-evaporated perovskite films determined by<sup>1</sup> H-NMR spectroscopy. Overall, the results from<sup>1</sup> H-NMR spectroscopy are in good agreement with the composition expected from evaporation rates. Especially in the MAI rate range from 0.45 to 1, a linear relation between rate and film inclusion is found. Interestingly, we observe a larger deviation between the expected composition and the composition determined by<sup>1</sup> H-NMR for small MAI mole fractions. This indicates that for compositions close to pure FAPbI3 the incorporation of MAI into the final film is lower as expected from the rate ratio. The<sup>1</sup> H-NMR results confirm that FAI can easily be replaced by MAI in the perovskite phase. Only in the region close to pure FAPbI3 (small MAI fraction), the incorporation of MAI seems to be 

**2101460 (5 of 14)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101460 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 



**Figure 3.** Comparison between MAI mole fraction of organic cations in co-evaporated MAFAPbI3 films expected from the used MAI to FAI evaporation rates in comparison to the mole fraction of MAI determined from the final co-evaporated perovskite layer by<sup>1</sup> H-NMR spectroscopy after dissolving the perovskite film. The blue line serves as guide to the eye and represents an ideal correlation between expected and measured mole fraction. 

more difficult, and the formation of pure phase is preferred. To verify that the deviations are not due to an error in the determination by<sup>1</sup> H-NMR spectroscopy, we successfully confirmed the method for solutions of known compositions (Figure S6, 

Supporting Information). Additionally we compared the MAI content of an annealed (10 min at 145 °C) and a nonannealed sample using<sup>1</sup> H-NMR spectroscopy (Figure S5B, Supporting Information), which shows no considerable difference in the MAI to FAI ratio before and after annealing. 

In total, the increasing MAI rate is transferred into the film composition meaning the higher the rate, the higher the MAI fraction in the film. Even films with more than 50% MAI can be realized without adjustments of the process. This is in contrast to a recent publication,<sup>[41]</sup> indicating that the MAI incorporation is self-limited during the co-evaporation of MAI, FAI and PbI2. One explanation for this might be that in the previous experiment by Gil-Escrig et al.,<sup>[41]</sup> additional MAI in different amounts was added while here the FAI is replaced by MAI by adjusting both rates simultaneously. 

After proving that changes in the evaporation rates transfer into changes in the film composition, the optical transmission of the perovskite films before and after annealing (145 °C for 10 min) is studied on glass/indium tin oxide (ITO)/MeO-2PACz with different MAI contents ( **Figure 4** ). The layer thickness of the samples is controlled by the thickness displayed on the PbI2 QCM sensor and is with values of about 650 nm comparable for all samples (see Figure S7 in the Supporting Information). For the nonannealed samples (Figure 4A) with low MAI content, the absorption edge is around 550–600 nm which corresponds to the yellow, nonperovskite _δ_ -phase of FAPbI3.<sup>[65]</sup> With increasing amount of MAI the band edge shifts to 795 nm which is in good agreement to the reported values for the black FAPbI3 phase.<sup>[40,41]</sup> As reported in literature,<sup>[41]</sup> the black 



**Figure 4.** Transmission spectra of MAFAPbI3 films prepared on glass/ITO/MeO-2PACz with different MAI to FAI ratio from 0% to 59% in the left column and from 59% to 100% in the right column A) films as deposited B) films after annealing at 145 °C for 10 min. The measurements are carried out in air without encapsulation. 

**2101460 (6 of 14)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101460 

**www.advancedsciencenews.com** 

perovskite phase can be stabilized with a certain MAI content even at room temperature. When the MAI content is increased to over 70%, a small reduction of the band gap is observed. This change of about 25 nm (≈0.05 eV) is in good agreement with the expected band gap difference between FAPbI3 and MAPbI3. Interestingly, the absorption coefficient for energies just above the band gap is higher for pure MAPbI3 films as compared to FAPbI3 with small fractions of MAI as seen by the lower transmission for pure MAPbI3 between 700 and 750 nm. 

For the annealed films (Figure 4B), the band gab of ≈1.54 eV, corresponding to the black phase of FAPbI3, is visible in the transmission spectra even in absence of MAI. Therefore, the annealed films with low MAI content appear to have a higher phase stability than the nonannealed films when measured in air. With increasing MAI content for annealed films, the band gap changes only slightly, but the transmission onset becomes sharper. The significantly reduced transmission between 550 and 775 nm indicates a higher absorption coefficient with increasing MAI content. As already seen for the nonannealed films, a change in bandgap occurs again with a MAI content of more than 70%, corresponding to the transition from FAPbI3 to MAPbI3. Overall, the influence of the annealing on the transmission is reduced with increasing MAI content. A direct comparison of the transmission measurements for three different compositions between annealed and nonannealed films is displayed in Figure S8 in the Supporting Information. 

In addition to the transmission, also the morphology of coevaporated and annealed perovskite films changes with the MAI content (Figure S7, Supporting Information). With increasing MAI content, the shape of the initially disordered small grains changes and they become larger and columnar. This change in morphology is in line with the reduced transmission between 550 and 775 nm of films prepared with more than 32% MAI content. 

The comparison of the XRD measurements for annealed samples with increasing MAI content, reveals that the intensity of the reflexes at about 14°, and 28° 2 _θ_ increases with the MAI content and reaches a maximum at 55% MAI (see Figure S9 in the Supporting Information). Furthermore the full width at half maximum (FWHM) of the most characteristic reflex at about 14°, being a marker for the size of the perovskite crystallites, is decreasing strongly from 21% to 55% MAI and remains rather constant for higher MAI ratios up to 80%. This finding is in good agreement to the observed morphology in SEM. Overall, our morphological analyses, the transmission spectra, and the XRD measurements indicate that the addition of MAI significantly improves the optoelectronic quality of the resulting perovskite film; whether this also translates into the solar cell performance is in detail analyzed in the following. 

To investigate the influence of MAI inclusion on the solar cell performance, we prepare solar cells in p-i-n configuration with the same configuration as presented in Figure 2A. Here we use again unwashed hole-selective contact material MeO-2PACz in combination with annealed (145 °C for 10 min) perovskite films with different MAI to FAI ratios. In addition, we vary the stoichiometry between the organic precursor (sum of MA + FA) to lead. **Figure 5** A displays the statistics of the measured solar cell PCE of _J_ – _V_ measurements (reverse and forward scan) under simulated AM1.5G illumination. The corresponding perfor- 

**www.advenergymat.de** 

mance parameters _V_ oc, _J_ sc, FF and the EQE spectra are shown in Figure S10 in the Supporting Information. Starting from pure FAPbI3, with 15% organic precursor excess, the addition of 16% MAI (keeping the organic precursor excess constant), reduces the average efficiency of the solar cells mainly due to a decreasing FF and _J_ sc. With MAI mole fractions of more than 32%, high solar cell efficiency of above 19% are obtained (see **Table 1** ). Between MAI contents from 32% to 59%, the high _J_ sc values of around 24 mA cm<sup>−2</sup> enable high solar cell PCEs. 

This is also confirmed by the representative EQEs of each FAI/MAI ratio shown in Figure S10D in the Supporting Information. Once the MAI content is increased above 70%, the _J_ sc decreases again. This can be explained by a shift in the bandgap that has been observed in both the transmission and the EQE measurements. As the increased bandgap does not lead to a higher _V_ oc, the PCE decreases. Optimal solar cell results are achieved when the MAI content of the perovskites is between 32% and 59%. This is visible in the statistics of the solar cells’ PCE as well as an increased absorption between 550 and 775 nm. Interestingly, the larger grain sizes for MAI ratios higher than 70% do not yield higher solar cell performance. Figure 5B shows a comparison between selected MAI to FAI fractions with either stoichiometric composition or films deposited with MAI + FAI excess. For pure formamidinium lead iodide, a stoichiometric composition or even a certain excess of PbI2 is crucial to obtain high PCEs (see Figure 2B for details), whereas comparable PCEs for stoichiometric and films with MAI + FAI excess are obtained when the MAI content is above 32% (see Table 1). The best solar cells (Figure 5C) with a PCE above 20% could be prepared with a MAI content of 47% in the MA0.47FA0.53PbI3 perovskite composition and an additional sodium fluoride (NaF) anti-reflective (AR) coating evaporated onto the glass. The AR coating enhances the _J_ SC by over 1 mA cm<sup>−2</sup> as the comparison of the solar cell performance before and after NaF coating in Table 1 shows. 

The best solar cell with 47% MAI and 100 nm antireflection coating shows only minimal hysteresis and reaches a stabilised power conversion efficiency of 20.4% during maximum power point (MPP) tracking for 10 min as displayed in the inset of Figure 5C. The band gap of 1.53 eV, determined from the inflection point of the EQE (Figure 5D), is in good agreement to literature values of pure FAPbI3,<sup>[40]</sup> despite the significant MA incorporation. The open-circuit voltage of 1.05 V corresponds to an energetic difference of 480 meV between e· _V_ oc and the band gap (1.53 eV). 

This difference is comparable to previously reported values for pure MAPbI3 on MeO-2PACz, where a _V_ oc of 1.15 V was obtained with a band gap of 1.61 eV.<sup>[38]</sup> Due to the combination of the narrow bandgap and the antireflection layer, a _J_ sc above 25 mA cm<sup>−2</sup> is obtained, which agrees very well to the integrated photocurrent from EQE spectra being 25.18 mA cm<sup>−2</sup> . The PCE achieved in this work is among the highest reported values for co-evaporated PSCs and is to the best of our knowledge the first reported PCE above 20% where a more complex perovskite composition than pure MAPbI3 is used. 

As already described in the introduction, a major problem of pure MAPbI3 absorbers is the intrinsic instability under illumination.<sup>[66]</sup> To assess how the MAI content affects the stability of the MAI/FAI mixed perovskites, we further study solar 

**2101460 (7 of 14)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101460 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 5.** A) Statistic of device performance extracted from _J_ – _V_ scan (reverse and forward scan) under simulated AM1.5G illumination of minimum 12 solar cells prepared with different MAI to FAI molar ratios and organic precursor excess of ≈15%. All perovskite films were deposited on unwashed MeO-2PACz and annealed afterwards. B) Comparison of PCE values for solar cells prepared under stoichiometric conditions (blue) and with MAI + FAI excess (red). C) _J_ – _V_ curve of the best MA0.47FA0.53PbI3 device with maximum power point tracking in the inset. D) EQE spectrum with highlighted inflection point and corresponding integration of the product with AM1.5G spectrum. 

cells with different MAI to FAI ratios over a long time in MPP tracking. For this purpose, the unencapsulated solar cells are actively temperature controlled to 25 °C under constant mpptracking at one sun illumination in nitrogen for 1000 h using a home-built setup. Additionally, a _J_ – _V_ scan is performed after every 24 h. As previously, perovskites deposited with MAI + FAI excess are used for the stability experiment. Due to the reduced efficiency of the samples with 0% and 16% MAI containing FAI + MAI excess, the solar cells prepared under stoichiometric conditions were used. For the MA0.47FA0.53PbI3 solar cells containing 47% MAI an additional NaF AR coating is included. **Figure 6** shows the averaged MPP-tracking of at least six individual solar cells per composition, a normalized graph and the 

results of the best solar cell of each composition are displayed in Figure S11 in the Supporting Information. For pure FAPbI3 cells, the T80 time (time in which the PCE reaches 80% of the initial PCE)<sup>[67]</sup> is 886 h, i.e., about 37 days. If 16% FAI is replaced by MAI, this time decreases significantly to 93 h. Contrary to expectations, stability increases again as the MAI content is increased. Already with 32% MAI, the T80 time exceeds the test duration and is well above 1000 h. All solar cells in the range of 32% to 47% MAI show excellent stability, during 1000 h of operation and at least 96.4% of the initial PCE is maintained. The solar cells with 32% MAI retain even 100% of their initial PCE after 1000 h. This range of MA to FA fraction with highest long-term stability fits well with the optimal region for lowest 

**Table 1.** Photovoltaic parameters for selected co-evaporated p-i-n perovskite solar displayed in Figure 5A–C. All solar cells have an active area of 0.16 cm<sup>2</sup> . 

|Composition||_J_scmA cm<sup>−2</sup>|_V_ocV|FF %|PCE %|MPP %|
|---|---|---|---|---|---|---|
|32% MAI|organic precursor excess|23.10|1.06|77.12|18.9||
|32% MAI|Stoichiometric|23.20|1.05|74.86|18.2||
|46% MAI|organic precursor excess|24.26|1.04|76.32|19.2||
|47% MAI|Stoichiometric|24.24|1.05|75.33|19.1||
|47%<sup>a)</sup>MAI|Stoichiometric|25.70|1.05|75.91|20.4|20.4|



a)Including a 100 nm thin antireflection coating. 

**2101460 (8 of 14)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101460 

**www.advancedsciencenews.com** 



**Figure 6.** Averaged MPP-tracking of minimum six individual solar cells for 1000 h under 1 sun illumination in nitrogen atmosphere. Next to each curve, the remaining percentage of the initial PCE after 1000 h is displayed. 

transmission and highest solar cell PCEs. For the record solar cell with 47% MAI and anti-reflection layer, an efficiency of over 20% can be retained for a period of over 1 month (720 h) under continuous illumination (Figure S11A, Supporting Information). During this period, the PCE decreased to 98.5% of the initial PCE, so the high stability of MAFAPbI3 perovskite solar cells from co-evaporation already shown by Gil-Escrig et al.<sup>[41]</sup> could be further increased by 8%. 

With a high MAI content of 59% and above, the stability of the solar cells decreases again. Nevertheless, the T80 times are higher than those of pure FAPbI3. In summary, the MAFAPbI3 perovskite mixtures exhibit excellent stability under illumination in the range of 32% to 47% MAI. Our results indicate that even compositions with a high MAI fraction up to 47% can exhibit good stability, and that the stability under illumination is not only influenced by the composition but especially by the quality of the absorber material. In the MAI range with the highest stabilities the perovskite films are characterized by large columnar orientated grains (Figure S7, Supporting Information), show the lowest transmission and achieve the highest PCEs. 

## **4. Monolithic Perovskite/Silicon Tandem Solar Cell** 

In addition to stability under illumination, resistance against species, which may lead to degradation such as water, oxygen, or solvent vapor, is essential for the application of perovskite solar cells. This is especially important for perovskite/silicon tandem solar cells, where a semitransparent top contact needs to be deposited on top of the perovskite absorber. For highly efficient tandem solar cells, a combination of tin oxide (SnO2) deposited via atomic layer deposition (ALD) using water as an oxygen source and a sputter-deposited transparent conductive oxide (TCO) has become established.<sup>[14,68,69]</sup> These depositions may potentially harm the perovskite. 

Although the co-evaporation process has repeatedly been shown to enable conformal deposition of the perovskite, there 

**www.advenergymat.de** 

are no publications reporting perovskite/silicon tandem solar cells with co-evaporated perovskite absorbers. The reasons for this may be manifold, but we identify the deposition of SnO2 by ALD during the fabrication of the semitransparent top contact as one critical process. 

**Figure 7** shows a cross-sectional scanning electron microscope (SEM) image of a MAPbI3 perovskite capped with 18 nm of C60 on a textured silicon bottom cell before and after ALD deposition of SnO2. Before SnO2 deposition (Figure 7A), the perovskite consists mainly of columnar grains with about 150 nm diameter that were reported previously.<sup>[38,50]</sup> After the SnO2 buffer layer is processed, the morphology is significantly altered (Figure 7B): instead of large, columnar oriented grains, only disordered fine-textured structures (<50 nm) can be seen. This clearly shows that the perovskite is degraded by the ALD process. The most plausible decomposition product is PbI2, which is also confirmed by the EQE of the finished tandem solar cell shown in Figure S12 in the Supporting Information. Instead of two clearly distinguishable EQEs for the two sub cells with a defined band gap around 1.60 eV for the MAPbI3 top cell, a broad EQE response of the optically filtered silicon cell is visible. The onset of photocurrent response for the top cell at the band gap edge is very small and a stronger signal is seen for wavelengths higher than 500 nm which is in line with the optical band gap of pure PbI2 ( _E_ g ≈ 2.5 eV). Thus, the co-evaporated MAPbI3 on textured silicon bottom cells seems to be strongly degraded and high amounts of PbI2 were likely formed after the top-contact processing by ALD. In comparison to Figure 7, the complete top contact, including the sputtered TCO, is necessary for the EQE measurement. Therefore, it cannot be excluded that the sample was additionally damaged by the sputter deposition process. However, as currently the highest tandem solar cell efficiencies are realized with a SnO2 buffer layer,<sup>[14]</sup> the effect of sputter damage through the SnO2 is expected to be minor. 

As PbI2 and perovskites can be easily distinguished optically, we deposited the perovskite on textured glass to perform transmission measurements. This offers a simple way to evaluate the resistance of the perovskite against the degradation species and process conditions of the SnO2 ALD process. For the co-evaporated MAPbI3 perovskite films deposited on textured glass that resembles the pyramid structure of silicon,<sup>[50]</sup> a significant change in transmission before and after the deposition of SnO2 via ALD is visible (Figure 7C). We observe a change in absorption onset corresponding to a strong conversion of perovskite to PbI2. In contrast, the transmission spectrum of MA0.5FA0.63PbI3.13 including 44% MAI on the same textured glass substrate is almost unchanged by the deposition of SnO2 via ALD (Figure 7D). Therefore, we conclude that the MA0.5FA0.63PbI3.13 perovskite grown on the textured surface is more resilient against degradation during the SnO2 ALD deposition used as buffer layer for the semi-transparent top contact. 

Due to this superior stability, MA0.5FA0.63PbI3.13 can be used to prepare fully textured perovskite/silicon tandem solar cells with co-evaporated perovskite without suffering from degradation when processing the SnO2 buffer layer with ALD. The used solar cell structure is displayed in the in **Figure 8** A. As shown in Figure 8B,C, the silicon pyramid structures are conformally coated with perovskite and in contrast to pure 

**2101460 (9 of 14)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101460 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 7.** Cross-sectional SEM images of a textured silicon bottom cell with evaporated MAPbI3 perovskite caped with 18 nm C60. A) before SnO2 deposition B) after deposition of SnO2 via ALD. Transmission spectra of co-evaporated C) MAPbI3 and D) MA0.5FA0.63PbI3.13 perovskite films on textured glass both caped with 18 nm of C60 before and after deposition of 20 nm SnO2 via ALD. 

MAPbI3, the morphology of the stable MA0.5FA0.63PbI3.13 composition remains intact after deposition of SnO2 via ALD. Overall, the pyramid structures, with maximal heights of 4 µm and average heights of 1.7 µm (Figure S13, Supporting Information), can be homogenously coated with perovskite and no significant differences in morphology between planar glass/ ITO (Figure S7B, Supporting Information) and textured silicon substrates (Figure 8C) are observed. 

Figure 8E shows the _J_ – _V_ curve of the best tandem solar cell under simulated AM1.5G illumination with an MPP track in the inset. The resulting performance parameters are displayed in **Table 2** . 

Additional statistics for five fully textured monolithic perovskite/silicon tandem solar cells prepared in different co-evaporation runs are shown in Figure S14 in the Supporting Information and a measurement at elevated temperatures is displayed in Figure S15 in the Supporting Information. The best tandem solar cell shows minimal hysteresis and reaches a stabilized power conversion efficiency of 24.58% during MPP tracking. Assuming a top cell _V_ oc of 1.05 V as found for the planar perovskite single junction and a silicon bottom cell _V_ oc of 690 mV, one would expect a combined tandem _V_ oc of 1.74 V. Comparing this to the measured tandem _V_ oc value of 1.69V, a loss of 60 mV is found, which limits the tandem performance. This could be attributed to the increased cell area and to enhanced nonradiative recombination losses, caused by the larger surface area of the microtextures. Especially the perovskite/C60 interface is 

known to induce severe nonradiative recombination losses.<sup>[70]</sup> Figure 8D shows the EQE data and the reflection measurement of the tandem solar cell. Even without additional and complex light management such as textured foils or AR coatings, the tandem cell exhibits minimal reflection losses due to the conformally covered pyramid textures. In the wavelength range from 300 to 1200 nm reflections induce a current loss of 1.62 mA cm<sup>−2</sup> which agrees well with literature values for textured tandem solar cells<sup>[49]</sup> and is significantly reduced compared to planar record tandem solar cells.<sup>[14]</sup> The tandem solar cell exhibits a cumulative current density of 39.59 mA cm<sup>−2</sup> , while 21.02 mA cm<sup>−2</sup> are generated in the perovskite top cell and 18.57 mA cm<sup>−2</sup> are gained in the silicon bottom cell. This results in a difference in photocurrent density of 2.45 mA cm<sup>−2</sup> . The mismatch helps to generate a high tandem FF as reported by Köhnen et al.,<sup>[69]</sup> however, operating the tandem cell close to current matching conditions will likely further increase the performance. This can be achieved by either reducing the perovskite layer thickness, or increasing the perovskite band gap. Overall, it is more reasonable to increase the band gap of the perovskite for higher efficiencies, as the overall tandem _V_ oc would then also be enhanced by higher top cell _V_ oc. 

Our results clearly show that it is possible to prepare high efficiency monolithic perovskite/silicon tandem solar cells using co-evaporation. For that, the stability of the perovskite composition against degradation during the processing of the subsequent transparent top contact, typically consisting of 

**2101460 (10 of 14)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101460 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 





**Figure 8.** A) schematic fully textured monolithic perovskite/silicon tandem solar cell B) tilted top view and C) cross-sectional SEM image of textured silicon bottom cells covered with MA0.5FA0.63PbI3.13, capped with 18 nm of C60 and after the 20 nm SnO2 ALD deposition D) EQE and reflection spectra (denoted as 1 − _R_ ) including the integrated current densities of the two sub cells, the sum and reflection. E) _J_ – _V_ characteristics of fully textured monolithic perovskite/silicon tandem solar cell with maximum power point tracking in the inset. 

**Table 2.** Photovoltaic parameters of the record fully textured monolithic perovskite/silicon tandem solar cell measured under AM1.5G illumination using annealed MA0.5FA0.63PbI3.13 with organic precursor excess on unwashed MeO-2PACz. The active area of the solar cell is 1.008 cm<sup>2</sup> . The measurement is performed in air without any encapsulation. 

|Measurement Mode|_J_scmA cm<sup>−2</sup>|_V_ocV|FF %|PCE %|
|---|---|---|---|---|
|_J_scto_V_oc|18.57|1.69|78.87|24.72|
|_V_octo_J_sc|18.57|1.68|77.94|24.35|
|MPP||||24.58|



**2101460 (11 of 14)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101460 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

metal oxides processed via atomic layer deposition and sputtering, is as a key aspect for further development. 

## **5. Conclusion** 

In this work, the preparation of formamidinium lead iodide (FAPbI3) based perovskites by co-evaporation was studied, whereby various aspects of film and solar cell stability were analyzed. Starting from pure FAPbI3, it was show that an excess of formamidinium iodide (FAI) in combination with free phosphonic acid groups from unwashed MeO-2PACz hole-selective layers pointing towards the surface of the co-evaporated perovskite can stabilize the black perovskite phase at room temperature. However, the best solar cell efficiency for pure FAPbI3 of over 16% was achieved with a less phase stable perovskite composition containing PbI2 excess. Therefore, the phase stability of the perovskite composition was further increased by adding methylammonium iodide (MAI) from a third evaporation source. Using nuclear magnetic resonance spectroscopy, it was demonstrated that FAI can easily be replaced by MAI during the co-evaporation process. It was illustrated that the optimal MAI content in terms of absorption properties and solar cell PCEs ranges between 32% and 59%. Using an MAI content of 47%, a photocurrent of 25.7 mA cm<sup>−2</sup> and a PCE of 20.4% was achieved, which is among the best efficiencies published for solar cells with co-evaporated perovskite absorbers. The long-term stability of MAFAPbI3 solar cells under illumination (1000 h) was tested for different perovskite compositions with a variety of MAI/FAI fractions. In the range of 32% to 47% MAI, the solar cells showed excellent stability. The solar cells with 32% MAI retain 100% of their initial PCE after 1000 h under continuous illumination. Furthermore, the absorber stability during atomic layer deposition (ALD) of tin oxide (SnO2) using water as oxygen source degrades MAPbI3 based perovskites when being integrated into monolithic fully textured perovskite/silicon tandem solar cells. In contrast, co-evaporated MA0.5FA0.63PbI3.13 showed, due to its higher stability, no change in morphology or transmission after SnO2 ALD processing on top. Based on this perovskite composition, the first monolithic fully textured perovskite/silicon tandem solar cells with co-evaporated perovskite absorber were realized. These tandem cells reached an efficiency of 24.6% and had minimal reflection losses due to the conformally covered pyramid texture. 

The herein used processes are suitable for large area processing and thus upscaling. Further optimization of current matching, including band gap tuning will lead to efficiencies that are on par with the best solution processed perovskite/silicon tandem solar cells. 

## **Supporting Information** 

Supporting Information is available from the Wiley Online Library or from the author. 

## **Acknowledgements** 

For technical assistance, the authors thank T. Lußky, H. Heinz, M. Gabernig, C. Klimm, C. Ferber, M. Muske (Institute for Silicon 

Photovoltaics) and T. Henschel, H. Rhein, J. Niels Kleesiek, A. Harter (PVcomB). The authors acknowledge funding from the Federal Ministry of Education and Research (BMBF) for funding of the Young Investigator Group Perovskite Tandem Solar Cells within the program “Materialforschung für die Energiewende” (Grant No. 03SF0540), the Helmholtz Association within the HySPRINT Innovation lab project, and the HyPerCells joint Graduate School. The authors thank the Department Optics for Solar Energy, D. Yoo, J. Sutter, and C. Becker, for providing microtextured glass substrates. 

Open access funding enabled and organized by Projekt DEAL. 

## **Conflict of Interest** 

The authors declare no conflict of interest. 

## **Data Availability Statement** 

The data that supports the findings of this study are available in the supplementary material of this article. 

## **Keywords** 

co-evaporation, constant stability, FAPbI3, fully textured, tandem solar cells 

Received: May 10, 2021 Revised: June 21, 2021 Published online: July 22, 2021 

- [1] J. Huang, Y. Yuan, Y. Shao, Y. Yan, _Nat. Rev. Mater._ **2017** , _2_ , 17042. 

- [2] C. Zuo, H. J. Bolink, H. Han, J. Huang, D. Cahen, L. Ding, _Adv. Sci._ **2016** , _3_ , 1500324. 

- [3] S. De Wolf, J. Holovsky, S.-J. Moon, P. Löper, B. Niesen, M. Ledinsky, F.-J. Haug, J.-H. Yum, C. Ballif, _J. Phys. Chem. Lett._ **2014** , _5_ , 1035. 

- [4] G. Xing, N. Mathews, S. Sun, S. S. Lim, Y. M. Lam, M. Grätzel, S. Mhaisalkar, T. C. Sum, _Science_ **2013** , _342_ , 344. 

- [5] L. M. Herz, _ACS Energy Lett._ **2017** , _2_ , 1539. 

- [6] K. X. Steirer, P. Schulz, G. Teeter, V. Stevanovic, M. Yang, K. Zhu, J. J. Berry, _ACS Energy Lett._ **2016** , _1_ , 360. 

- [7] R. Swartwout, M. T. Hoerantner, V. Bulović, _Energy Environ. Mater._ **2019** , _2_ , 119. 

- [8] Y. Vaynzof, _Adv. Energy Mater._ **2020** , _10_ , 2003073. 

- [9] NREL Best Research-Cell Efficiency Chart, https://www.nrel.gov/pv/ cell-efficiency.html (accessed: March 2021). 

- [10] J. J. Yoo, G. Seo, M. R. Chua, T. G. Park, Y. Lu, F. Rotermund, Y.-K. Kim, C. S. Moon, N. J. Jeon, J.-P. Correa-Baena, V. Bulović, S. S. Shin, M. G. Bawendi, J. Seo, _Nature_ **2021** , _590_ , 587. 

- [11] N. J. Jeon, J. H. Noh, W. S. Yang, Y. C. Kim, S. Ryu, J. Seo, S. I. Seok, _Nature_ **2015** , _517_ , 476. 

- [12] M. Jošt, L. Kegelmann, L. Korte, S. Albrecht, _Adv. Energy Mater._ **2020** , _10_ , 1904102. 

- [13] L. C. Andreani, A. Bozzola, P. Kowalczewski, M. Liscidini, L. Redorici, _Adv. Phys.: X_ **2019** , _4_ , 1548305. 

- [14] A. Al-Ashouri, E. Köhnen, B. Li, A. Magomedov, H. Hempel, P. Caprioglio, J. A. Márquez, A. B. Morales Vilches, E. Kasparavicius, J. A. Smith, N. Phung, D. Menzel, M. Grischek, L. Kegelmann, D. Skroblin, C. Gollwitzer, T. Malinauskas, M. Jošt, G. Matič, B. Rech, R. Schlatmann, M. Topič, L. Korte, A. Abate, B. Stannowski, D. Neher, M. Stolterfoht, T. Unold, V. Getautis, S. Albrecht, _Science_ **2020** , _370_ , 1300. 

**2101460 (12 of 14)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101460 

**www.advancedsciencenews.com** 

- [15] K. Yoshikawa, H. Kawasaki, W. Yoshida, T. Irie, K. Konishi, K. Nakano, T. Uto, D. Adachi, M. Kanematsu, H. Uzu, K. Yamamoto, _Nat. Energy_ **2017** , _2_ , 17032. 

- [16] M. Liu, M. B. Johnston, H. J. Snaith, _Nature_ **2013** , _501_ , 395. 

- [17] W. A. Dunlap-Shohl, Y. Zhou, N. P. Padture, D. B. Mitzi, _Chem. Rev._ **2019** , _119_ , 3193. 

- [18] T. Soto-Montero, W. Soltanpoor, M. Morales-Masis, _APL Mater._ **2020** , _8_ , 110903. 

- [19] J.-P. Correa-Baena, A. Abate, M. Saliba, W. Tress, T. Jesper Jacobsson, M. Grätzel, A. Hagfeldt, _Energy Environ. Sci._ **2017** , _10_ , 710. 

- [20] N.-G. Park, K. Zhu, _Nat. Rev. Mater._ **2020** , _5_ , 333. 

- [21] J. B. Whitaker, D. H. Kim, B. W. Larson, F. Zhang, J. J. Berry, M. F. A. M. van Hest, K. Zhu, _Sustainable Energy Fuels_ **2018** , _2_ , 2442. 

- [22] F. Mathies, H. Eggers, B. S. Richards, G. Hernandez-Sosa, U. Lemmer, U. W. Paetzold, _ACS Appl. Energy Mater._ **2018** , _1_ , 1834. 

- [23] M. Jošt, T. Bertram, D. Koushik, J. A. Marquez, M. A. Verheijen, M. D. Heinemann, E. Köhnen, A. Al-Ashouri, S. Braunger, F. Lang, B. Rech, T. Unold, M. Creatore, I. Lauermann, C. A. Kaufmann, R. Schlatmann, S. Albrecht, _ACS Energy Lett._ **2019** , _4_ , 583. 

- [24] L. Gil-Escrig, C. Momblona, M. G. La-Placa, P. P. Boix, M. Sessolo, H. J. Bolink, _Adv. Energy Mater._ **2018** , _8_ , 1703506. 

- [25] T. Abzieher, J. A. Schwenzer, S. Moghadamzadeh, F. Sutterluti, I. M. Hossain, M. Pfau, E. Lotter, M. Hetterich, B. S. Richards, U. Lemmer, M. Powalla, U. W. Paetzold, _IEEE J. Photovoltaics_ **2019** , _9_ , 1249. 

- [26] C. Momblona, O. Malinkiewicz, C. Roldan-Carmona, A. Soriano, L. Gil-Escrig, E. Bandiello, M. Scheepers, E. Edri, H. J. Bolink, _APL Mater._ **2014** , _2_ , 081504. 

- [27] M. Kim, G.-H. Kim, T. K. Lee, I. W. Choi, H. W. Choi, Y. Jo, Y. J. Yoon, J. W. Kim, J. Lee, D. Huh, H. Lee, S. K. Kwak, J. Y. Kim, D. S. Kim, _Joule_ **2019** , _3_ , 2179. 

- [28] W. Shockley, H. J. Queisser, _J. Appl. Phys._ **1961** , _32_ , 510. 

- [29] Q. Jiang, Y. Zhao, X. Zhang, X. Yang, Y. Chen, Z. Chu, Q. Ye, X. Li, Z. Yin, J. You, _Nat. Photonics_ **2019** , _13_ , 460. 

- [30] S.-H. Turren-Cruz, A. Hagfeldt, M. Saliba, _Science_ **2018** , _362_ , 449. 

- [31] G. E. Eperon, S. D. Stranks, C. Menelaou, M. B. Johnston, L. M. Herz, H. J. Snaith, _Energy Environ. Sci._ **2014** , _7_ , 982. 

- [32] Y. Fan, H. Meng, L. Wang, S. Pang, _Sol. RRL_ **2019** , _3_ , 1900215. 

- [33] M. Lyu, N.-G. Park, _Sol. RRL_ **2020** , _4_ , 2000331. 

- [34] J. W. Lee, Z. Dai, C. Lee, H. M. Lee, T. H. Han, N. De Marco, O. Lin, C. S. Choi, B. Dunn, J. Koh, D. Di Carlo, J. H. Ko, H. D. Maynard, Y. Yang, _J. Am. Chem. Soc._ **2018** , _140_ , 6317. 

- [35] C. Momblona, L. Gil-Escrig, E. Bandiello, E. M. Hutter, M. Sessolo, K. Lederer, J. Blochwitz-Nimoth, H. J. Bolink, _Energy Environ. Sci._ **2016** , _9_ , 3456. 

- [36] D. Pérez-del-Rey, P. P. Boix, M. Sessolo, A. Hadipour, H. J. Bolink, _J. Phys. Chem. Lett._ **2018** , _9_ , 1041. 

- [37] J. Li, H. Wang, X. Y. Chin, H. A. Dewi, K. Vergeer, T. W. Goh, J. W. M. Lim, J. H. Lew, K. P. Loh, C. Soci, T. C. Sum, H. J. Bolink, N. Mathews, S. Mhaisalkar, A. Bruno, _Joule_ **2020** , _4_ , 1035. 

- [38] M. Roß, L. Gil-Escrig, A. Al-Ashouri, P. Tockhorn, M. Jošt, B. Rech, S. Albrecht, _ACS Appl. Mater. Interfaces_ **2020** , _12_ , 39261. 

- [39] M. M. Tavakoli, P. Yadav, D. Prochowicz, R. Tavakoli, _Sol. RRL_ **2021** , _5_ , 2000552. 

- [40] J. Borchert, R. L. Milot, J. B. Patel, C. L. Davies, A. D. Wright, L. Martínez Maestro, H. J. Snaith, L. M. Herz, M. B. Johnston, _ACS Energy Lett._ **2017** , _2_ , 2799. 

- [41] L. Gil-Escrig, C. Dreessen, I. C. Kaya, B.-S. Kim, F. Palazon, M. Sessolo, H. J. Bolink, _ACS Energy Lett._ **2020** , _5_ , 3053. 

- [42] L. Gu, D. Zhang, M. Kam, Q. Zhang, S. Poddar, Y. Fu, X. Mo, Z. Fan, _Nanoscale_ **2018** , _10_ , 15164. 

- [43] J.-W. Lee, D.-H. Kim, H.-S. Kim, S.-W. Seo, S. M. Cho, N.-G. Park, _Adv. Energy Mater._ **2015** , _5_ , 1501310. 

- [44] Y.-H. Chiang, M. Anaya, S. D. Stranks, _ACS Energy Lett._ **2020** , _5_ , 2498. 

**www.advenergymat.de** 

- [45] J. Feng, Y. Jiao, H. Wang, X. Zhu, Y. Sun, M. Du, Y. Cao, D. Yang, S. F. Liu, _Energy Environ. Sci._ **2021** , _14_ , 3035. 

- [46] A. S. Subbiah, F. H. Isikgor, C. T. Howells, M. De Bastiani, J. Liu, E. Aydin, F. Furlan, T. G. Allen, F. Xu, S. Zhumagali, S. Hoogland, E. H. Sargent, I. McCulloch, S. De Wolf, _ACS Energy Lett._ **2020** , _5_ , 3034. 

- [47] B. Chen, Z. Yu, K. Liu, X. Zheng, Y. Liu, J. Shi, D. Spronk, P. N. Rudd, Z. Holman, J. Huang, _Joule_ **2019** , _3_ , 177. 

- [48] Y. Hou, E. Aydin, M. De Bastiani, C. Xiao, F. H. Isikgor, D. J. Xue, B. Chen, H. Chen, B. Bahrami, A. H. Chowdhury, A. Johnston, S. W. Baek, Z. Huang, M. Wei, Y. Dong, J. Troughton, R. Jalmood, A. J. Mirabelli, T. G. Allen, E. Van Kerschaver, M. I. Saidaminov, D. Baran, Q. Qiao, K. Zhu, S. De Wolf, E. H. Sargent, _Science_ **2020** , _367_ , 1135. 

- [49] F. Sahli, J. Werner, B. A. Kamino, M. Bräuninger, R. Monnard, B. Paviet-Salomon, L. Barraud, L. Ding, J. J. Diaz Leon, D. Sacchetto, G. Cattaneo, M. Despeisse, M. Boccard, S. Nicolay, Q. Jeangros, B. Niesen, C. Ballif, _Nat. Mater._ **2018** , _17_ , 820. 

- [50] L. Gil-Escrig, M. Roß, J. Sutter, A. Al-Ashouri, C. Becker, S. Albrecht, _Sol. RRL_ **2021** , _5_ , 2000553. 

- [51] L. Cojocaru, K. Wienands, T. W. Kim, S. Uchida, A. J. Bett, S. Rafizadeh, J. C. Goldschmidt, S. W. Glunz, _ACS Appl. Mater. Interfaces_ **2018** , _10_ , 26293. 

- [52] B. Conings, J. Drijkoningen, N. Gauquelin, A. Babayigit, J. D’Haen, L. D’Olieslaeger, A. Ethirajan, J. Verbeeck, J. Manca, E. Mosconi, F. D. Angelis, H.-G. Boyen, _Adv. Energy Mater._ **2015** , _5_ , 1500477. 

- [53] M. I. Asghar, J. Zhang, H. Wang, P. D. Lund, _Renewable Sustainable Energy Rev._ **2017** , _77_ , 131. 

- [54] V. Kumar, J. Barbé, W. L. Schmidt, K. Tsevas, B. Ozkan, C. M. Handley, C. L. Freeman, D. C. Sinclair, I. M. Reaney, W. C. Tsoi, A. Dunbar, C. Rodenburg, _J. Mater. Chem. A_ **2018** , _6_ , 23578. 

- [55] N. Li, X. Niu, Q. Chen, H. Zhou, _Chem. Soc. Rev._ **2020** , _49_ , 8235. 

- [56] D. Kim, H. J. Jung, I. J. Park, B. W. Larson, S. P. Dunfield, C. Xiao, J. Kim, J. Tong, P. Boonmongkolras, S. G. Ji, F. Zhang, S. R. Pae, M. Kim, S. B. Kang, V. Dravid, J. J. Berry, J. Y. Kim, K. Zhu, D. H. Kim, B. Shin, _Science_ **2020** , _368_ , 155. 

- [57] L. Meng, J. You, Y. Yang, _Nat. Commun._ **2018** , _9_ , 5265. 

- [58] A. Al-Ashouri, A. Magomedov, M. Ross, M. Jost, M. Talaikis, G. Chistiakova, T. Bertram, J. A. Marquez, E. Kohnen, E. Kasparavicius, S. Levcenco, L. Gil-Escrig, C. J. Hages, R. Schlatmann, B. Rech, T. Malinauskas, T. Unold, C. A. Kaufmann, L. Korte, G. Niaura, V. Getautis, S. Albrecht, _Energy Environ. Sci._ **2019** , _12_ , 3356. 

- [59] S. Olthof, K. Meerholz, _Sci. Rep._ **2017** , _7_ , 40267. 

- [60] G. Guerrero, J. G. Alauzun, M. Granier, D. Laurencin, P. H. Mutin, _Dalton Trans._ **2013** , _42_ , 12569. 

- [61] H. Xie, Z. Wang, Z. Chen, C. Pereyra, M. Pols, K. Gałkowski, M. Anaya, S. Fu, X. Jia, P. Tang, D. J. Kubicki, A. Agarwalla, H.-S. Kim, D. Prochowicz, X. Borrisé, M. Bonn, C. Bao, X. Sun, S. M. Zakeeruddin, L. Emsley, J. Arbiol, F. Gao, F. Fu, H. I. Wang, K.-J. Tielrooij, S. D. Stranks, S. Tao, M. Grätzel, A. Hagfeldt, M. Lira-Cantu, _Joule_ **2021** , _5_ , 1246. 

- [62] C. Roldán-Carmona, P. Gratia, I. Zimmermann, G. Grancini, P. Gao, M. Graetzel, M. K. Nazeeruddin, _Energy Environ. Sci._ **2015** , _8_ , 3550. 

- [63] D. Bi, W. Tress, M. I. Dar, P. Gao, J. Luo, C. Renevier, K. Schenk, A. Abate, F. Giordano, J.-P. C. Baena, J.-D. Decoppet, S. M. Zakeeruddin, M. K. Nazeeruddin, M. Grätzel, A. Hagfeldt, _Sci. Adv._ **2016** , _2_ , 1501170. 

- [64] C. Pareja-Rivera, A. L. Solís-Cambero, M. Sánchez-Torres, E. Lima, D. Solis-Ibarra, _ACS Energy Lett._ **2018** , _3_ , 2366. 

- [65] F. Ma, J. Li, W. Li, N. Lin, L. Wang, J. Qiao, _Chem. Sci._ **2017** , _8_ , 800. 

- [66] E. J. Juarez-Perez, L. K. Ono, M. Maeda, Y. Jiang, Z. Hawash, Y. Qi, _J. Mater. Chem. A_ **2018** , _6_ , 9604. 

- [67] M. V. Khenkin, E. A. Katz, A. Abate, G. Bardizza, J. J. Berry, C. Brabec, F. Brunetti, V. Bulović, Q. Burlingame, A. Di Carlo, R. Cheacharoen, Y.-B. Cheng, A. Colsmann, S. Cros, K. Domanski, 

**2101460 (13 of 14)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101460 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

   - M. Dusza, C. J. Fell, S. R. Forrest, Y. Galagan, D. Di Girolamo, M. Grätzel, A. Hagfeldt, E. von Hauff, H. Hoppe, J. Kettle, H. Köbler, M. S. Leite, S. Liu, Y.-L. Loo, J. M. Luther, C.-Q. Ma, M. Madsen, M. Manceau, M. Matheron, M. McGehee, R. Meitzner, M. K. Nazeeruddin, A. F. Nogueira, Ç. Odabaşı, A. Osherov, N.-G. Park, M. O. Reese, F. De Rossi, M. Saliba, U. S. Schubert, H. J. Snaith, S. D. Stranks, W. Tress, P. A. Troshin, V. Turkovic, S. Veenstra, I. Visoly-Fisher, A. Walsh, T. Watson, H. Xie, R. Yıldırım, S. M. Zakeeruddin, K. Zhu, M. Lira-Cantu, _Nat. Energy_ **2020** , _5_ , 35. 

- [68] K. A. Bush, A. F. Palmstrom, Z. J. Yu, M. Boccard, R. Cheacharoen, J. P. Mailoa, D. P. McMeekin, R. L. Z. Hoye, C. D. Bailie, T. Leijtens, 

   - I. M. Peters, M. C. Minichetti, N. Rolston, R. Prasanna, S. Sofia, D. Harwood, W. Ma, F. Moghadam, H. J. Snaith, T. Buonassisi, Z. C. Holman, S. F. Bent, M. D. McGehee, _Nat. Energy_ **2017** , _2_ , 17009. 

- [69] E. Köhnen, M. Jost, A. B. Morales-Vilches, P. Tockhorn, A. Al-Ashouri, B. Macco, L. Kegelmann, L. Korte, B. Rech, R. Schlatmann, B. Stannowski, S. Albrecht, _Sustainable Energy & Fuels_ **2019** , _3_ , 1995. 

- [70] M. Stolterfoht, C. M. Wolff, J. A. Márquez, S. Zhang, C. J. Hages, D. Rothhardt, S. Albrecht, P. L. Burn, P. Meredith, T. Unold, D. Neher, _Nat. Energy_ **2018** , _3_ , 847. 

**2101460 (14 of 14)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101460 

