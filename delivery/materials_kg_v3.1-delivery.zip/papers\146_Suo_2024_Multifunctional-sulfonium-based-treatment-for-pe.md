# Multifunctional sulfonium-based treatment for perovskite solar cells with less than 1% efficiency loss over 4,500-h operational stability tests

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Energy |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 191 |
| 作者 | Jia-Jia Suo, Bowen Yang, E. Mosconi, Dmitry Bogachuk, T. Doherty, K. Frohna, D. Kubicki, F. Fu et al. |
| DOI | 10.1038/s41560-023-01421-6 |
| 源文件 | 046_Suo_2024_Multifunctional-sulfonium-based-treatment-for-pe.pdf |

---
## **nature energy** 

**Article** 

https://doi.org/10.1038/s41560-023-01421-6 

# **Multifunctional sulfonium-based treatment for perovskite solar cells with less than 1% efficiency loss over 4,500-h operational stability tests** 

|Received: 28 December 2022<br>Accepted: 21 November 2023<br>Published online: 4 January 2024<br>Check for updates|**Jiajia Suo**<br> <sup>**1,2,19**</sup>**, Bowen Yang**<br> <sup>**1,2,19**</sup><br>**, Edoardo Mosconi**<br> <sup>**3**</sup><br>**,**<br>**Dmitry Bogachuk**<sup>**4,5,6**</sup>**, Tiarnan A. S. Doherty**<sup>**7,8**</sup>**, Kyle Frohna**<br> <sup>**7,9**</sup>**,**<br>**Dominik J. Kubicki**<br> <sup>**10,18**</sup>**, Fan Fu**<br> <sup>**11**</sup>**, YeonJu Kim**<br> <sup>**2,12**</sup>**, Oussama Er-Raji**<br> <sup>**4,5**</sup>**,**<br>**Tiankai Zhang**<sup>**13**</sup>**, Lorenzo Baldinelli**<br> <sup>**14**</sup>**, Lukas Wagner**<br> <sup>**4,15**</sup>**, Ayodhya N. Tiwari**<sup>**11**</sup>**,**<br>**Feng Gao**<br> <sup>**13**</sup>**, Andreas Hinsch**<sup>**4**</sup>**, Samuel D. Stranks**<br> <sup>**7,9**</sup>**,**<br>**Filippo De Angelis**<br> <sup>**3,14,16,17**</sup>**& Anders Hagfeldt**<br> <sup>**1,2**</sup>|
|---|---|
||The stabilization of grain boundaries and surfaces of the perovskite layer is<br>critical to extend the durability of perovskite solar cells. Here we introduced<br>a sulfonium-based molecule, dimethylphenethylsulfonium iodide (DMPESI),<br>for the post-deposition treatment of formamidinium lead iodide perovskite<br>films. The treated films show improved stability upon light soaking and<br>remains in the black_α_phase after two years ageing under ambient condition<br>without encapsulation. The DMPESI-treated perovskite solar cells show<br>less than 1% performance loss after more than 4,500 h at maximum power<br>point tracking, yielding a theoretical_T_80of over nine years under continuous<br>1-sun illumination. The solar cells also display less than 5% power conversion<br>efficiency drops under various ageing conditions, including 100 thermal<br>cycles between 25 °C and 85 °C and an 1,050-h damp heat test.|



Efficiency, stability and scalability are the most important factors on the route towards commercialization of perovskite solar cells (PSCs). Remarkable certified power conversion efficiencies (PCEs) have achieved 25.7% on single-junction PSCs and 32.5% on perovskite-silicon tandem solar cells<sup>1</sup> . Recently, scalability has also been effectively managed by modifying the charge transport layers and interfacial treatments with up-scalable deposition techniques, which enabled certified PCEs of 23.1, 22.7 and 20.5% on 1, 24 and 64 cm<sup>2</sup> cells and mini-modules, respectively<sup>2–4</sup> . Although stability has been notably improved, it still remains the most critical limitation for commercializing state-of-the-art highly efficient perovskite-based photovoltaics and further improvement is critically required<sup>5–7</sup> . 

Both performance loss and degradation of PSCs are initiated at grain boundaries and interfaces, where defects and mobile ions tend 

to accumulate under external stress, such as continuous illumination, humid environment and elevated temperature<sup>8–12</sup> . Therefore, suppressing surface defects along with inhibiting mobile ion migration is critical to achieve PSCs long-term stability. Different molecular species have been explored to suppress defect formation and ion migration either in the perovskite bulk or at the adjacent interfaces, with the ultimate goal of achieving stable PSCs. These species include ammonium-based salts, small organic molecules, polymers and other passivation agents including inorganic salts<sup>13–16</sup> . A category of aprotic sulfonium-based molecules shows great potential in stabilizing PSCs, however, it remains largely unexplored<sup>17</sup> . The innovation of utilizing such material to stabilize PSCs are driven by the unique geometries with largely strengthened chemical and humidity stability provided by the sulfonium-based cations. For example, a 1D perovskite ((CH3)3SPbI3) 

A full list of affiliations appears at the end of the paper. e-mail: bowen.yang@kemi.uu.se; edoardo@thch.unipg.it; anders.hagfeldt@uu.se 

Nature Energy | Volume 9 | February 2024 | 172–183 

**172** 

**Article** 

https://doi.org/10.1038/s41560-023-01421-6 



<!-- Start of picture text -->
a b R.H. 40 ± 20% Fresh c R.H. 85–95% Fresh<br>1 3 5 10 1 3 5 10<br>6 month<br>DMPESI<br>1 month 24 month 24 h<br>1 3 5 10 1 3 5 10<br>Fresh<br>7.5 6.5 5.5 4.5 3.5 2.5 1.5 Reference DMPESI-treated (mg ml –1 ) Reference DMPESI-treated (mg ml –1 )<br>δ  ( ppm )<br>1e17<br>d Ref e Ref f 3 Mean before g<br>Mean after 6,000<br>2<br>6,000 4,000<br>1<br>2,000<br>0 0<br>1.4 1.5 1.6 1.7 0 200 400<br>4,000 Before light soaking After light soaking Energy (eV) Time (s)<br>1e17<br>h DMPESI i DMPESI j 3 k<br>6,000<br>2<br>4,000<br>2,000<br>1<br>2,000<br>0 0<br>1.4 1.5 1.6 1.7 0 200 400<br>Energy (eV) Time (s)<br>–2 –1 –1)(mS I eVPL Intensity (a.u.)<br>Intensity (a.u.)<br>–2 –1 –1)(mS I eVPL Intensity (a.u.)<br><!-- End of picture text -->

**Fig. 1 | Stability of DMPESI molecule and treated perovskite films under moisture and light-soaking conditions. a** ,<sup>1</sup> H NMR spectra of DMPESI in anhydrous DMSO-d6 after six months of storage in ambient air. The H2O peak in DMSO-d6 is at 3.3 ppm (vertical dashed blue line): the signal is absent in the samples. The chemical structure of DMPESI is shown. **b** , Photographs of fresh and 24-month aged unencapsulated perovskite film (1.0 cm by 2.0 cm) without and with DMPESI treatment of different concentrations (from left to right: reference, 1 mg ml<sup>−1</sup> , 3 mg ml<sup>−1</sup> , 5 mg ml<sup>−1</sup> , 10 mg ml<sup>−1</sup> ) in ambient air with R.H. 40 ± 20%. **c** , Photographs of fresh and 24 h aged unencapsulated perovskite film (1.0 cm by 2.0 cm) without and with DMPESI treatment of different concentrations (from left to right: reference, 1 mg ml<sup>−1</sup> , 3 mg ml<sup>−1</sup> , 5 mg ml<sup>−1</sup> , 10 mg ml<sup>−1</sup> ) in high humid condition of R.H. 85∼95%. ( **d** , **e** , **h** , **i** ) Hyperspectral photoluminescence 

microscopy of FAPbI3 reference and DMPESI-treated films, scale bar = 15 μm. **d** , **e** , Photoluminescence (PL) map of reference FAPbI3 film before ( **d** ) and after ( **e** ) 10 minutes of light soaking in air at 1-sun illumination intensity with a 405 nm continuous wave laser. **f** , PL spectra before (solid lines) and after (dashed lines) light from the coloured points marked in panels **d** and **e** . The mean PL spectrum of the region is marked in black. _I_ PL is PL intensity. **g** , Photoluminescence intensity changes with light soaking of the marked regions in **d** and the average of the image (black). **h** , **i** , Photoluminescence intensity map of DMPESI-treated film before ( **h** ) and after ( **i** ) 10 minutes of light soaking (1-sun equivalent). **j** , PL spectra before (solid lines) and after (dashed lines) light soaking of the marked regions in **h** and **i** . **k** , PL intensity changes with light soaking of the marked regions in **h** and the average of the image (black). 

based on the trimethylsulfonium cation has been synthesized, which exhibits elevated chemical stability<sup>18</sup> . Similarly, a fully alkylated butyldimethylsulfonium iodide was introduced into perovskite, which exhibited a pronounced enhancement in device stability under humid conditions<sup>19</sup> . However, the poor solubility of these aliphatic sulfonium salts<sup>18–21</sup> in low polar solvents (such as isopropanol and chloroform) limits their application for surface treatment. 

In this work, we synthesized and introduced an unexplored dimethylphenethylsulfonium cation and its iodide salt, DMPESI (Fig. 1a, inset), endowed with an aromatic moiety, and used it as a surface passivation agent on FAPbI3-based PSCs. We pose the aromatic nature of the ligand induces a close packing on the perovskite surface compared with aliphatic chains. The results indicate that one-step perovskite surface treatment with DMPESI effectively achieves a series of benefits: it passivates surface defects, prolonging charge-carrier lifetime and suppressing non-radiative recombination, resulting in superior PSCs performance; it enhances thermodynamic stability of black FAPbI3, preventing phase transition to _δ_ phase; it induces formation of a compact and ultra-hydrophobic capping layer on top 

of the perovskite surface, which inhibits ion migration and impedes ambient-induced degradation mechanisms. Consequently, the DMPESI-treated FAPbI3 film exhibits much improved stability upon light soaking and remains in the black phase after two years ageing under ambient condition. Moreover, the resulting high-efficiency (PCE > 23%) PSCs exhibit long-term stability, showing: a negligible PCE drop (less than 1%) after more than 4,500 h maximum power point tracking, which is among the most operationally stable PSCs reported so far; they retain more than 96% of initial performance without encapsulation at 60 °C with relative humidity (R.H.) < 30% after 400 h ageing; the encapsulated devices retain over 98% of their initial performance under thermal cycling, following the International Summit on Organic Photovoltaic Stability (ISOS) stability protocol; the encapsulated devices successfully pass the damp heat test (85 °C at 85% R.H.) for over 1,000 h with less than 5% loss in PCE. Such excellent durability of our DMPESI-treated perovskite film and the PSC devices provides a strong indication that perovskite thin films have the potential to fulfil industrial protocols and compete with Si-based solar cells for further large-scale and industrial productions. 

Nature Energy | Volume 9 | February 2024 | 172–183 

**173** 

**Article** 

https://doi.org/10.1038/s41560-023-01421-6 

### **Perovskite film stability under moisture and light soaking** 

We started by evaluating the stability of the DMPESI salt by storing it in ambient air with R.H. of 40 ± 20% and tracking it using<sup>1</sup> H nuclear magnetic resonance (<sup>1</sup> H NMR) measurement. As evident from the spectra in Fig. 1a, no H2O peak is detected after six months of storage. Such low water uptake property of aprotic DMPESI is expected to improve the hydrophobicity of the perovskite film after surface treatment, and thus the device stability, especially under humid conditions. The hydrophobicity of DMPES<sup>+</sup> against a related ammonium-based phenethylammonium cation (PEA<sup>+</sup> ) is confirmed by mapping the electrostatic potential of both cations, as derived by density function theory (DFT) calculations (Supplementary Note 1), showing a high polarity region close to the ammonium group in PEA<sup>+</sup> , which is lacking in DMPES<sup>+</sup> . Similarly, solvation free energies and water interaction energies calculated for both cations clearly show a reduced tendency to bind water for DMPES<sup>+</sup> against PEA<sup>+</sup> . 

We deposit a layer of 1–10 mg ml<sup>−1</sup> of DMPESI on top of a 3D perovskite film, where formamidinium lead triiodide (FAPbI3) is selected, owing to its favourable bandgap suitable for high-performance PSCs<sup>22,23</sup> . The morphologies of the perovskite films are presented in Supplementary Fig. 2. A dense and pinhole-free polycrystalline perovskite film with micrometre-sized grains becomes more uniform upon surface treatment even with low amount (1 mg ml<sup>−1</sup> ) of DMPESI. As the concentration of DMPESI increases to 3 mg ml<sup>−1</sup> and 5 mg ml<sup>−1</sup> , a uniform and smooth surface is still observed, however, new species also appear. Notably, when the concentration of DMPESI further increases to 10 mg ml<sup>−1</sup> , some cracks are observed on the perovskite surface, which might be due to the aggregation of the excess DMPESI. 

Contact angle measurements of water droplets on the surface were carried out to evaluate the moisture stability of the perovskite film (Supplementary Fig. 3). A pronounced increase in contact angle is observed from 55.8° of the reference perovskite to around 90° of the DMPESI-treated films, regardless of concentration, suggesting a more hydrophobic surface upon treatment. Then we exposed the perovskite films to ambient air. The reference film becomes brownish after exposure for ten days. In contrast, the perovskite films treated with 3 mg ml<sup>−1</sup> and 5 mg ml<sup>−1</sup> DMPESI remain in pure black phase under the same condition even after 24 months (Fig. 1b and Supplementary Fig. 4), as evidenced by the X-ray diffraction (XRD) patterns of the aged samples in Supplementary Fig. 5. We further expose the perovskite films to a high R.H. of 85–95%. Photographs of the films are shown in Fig. 1c and Supplementary Fig. 6 and their corresponding XRD patterns are monitored in Supplementary Fig. 7. After exposure for 24 h, the reference perovskite film experiences a rapid transformation from black phase to yellow phase FAPbI3. In addition, the peak at 13.9° for _α_ (110) exhibits dramatic decrease in intensity, suggesting an inferior perovskite crystallinity with larger disordered regions between grains<sup>24</sup> . However, in sharp contrast, films treated with moderate quantities (1 mg ml<sup>−1</sup> , 3 mg ml<sup>−1</sup> and 5 mg ml<sup>−1</sup> ) of DMPESI retain in the black phase FAPbI3. Interestingly, the perovskite film treated with excessive DMPESI (10 mg ml<sup>−1</sup> ) displays aggravated phase instability. We attribute this to the poor surface coverage caused by the aggregation of the excess DMPESI, supported by the observed scanning electron microscope (SEM) image in Supplementary Fig. 2, which could induce degradation pathways for moisture from external atmosphere to penetrate into the perovskite bulk, leading to an accelerated degradation process. 

To further probe the light-soaking stability of the reference and DMPESI-treated (3 mg ml<sup>−1</sup> ) films, we performed wide-field, hyperspectral PL mapping of both samples in ambient conditions. Hyperspectral PL maps (Fig. 1d,h) display similar spatial PL distributions with comparable emissions intensities and peak positions and an additional small red-shifted PL. The DMPESI-treated sample shows enhanced low energy emission around the edges of the grains in comparison with the reference sample (Supplementary Fig. 8). The samples were then light 

soaked for 10 minutes with 1-sun illumination intensity under ambient conditions. The corresponding maps of the same areas of the reference and treated samples are shown in Fig. 1e,i, respectively. Notably, the intensity of the reference sample drops dramatically during illumination and distinct regions tens of microns in size with higher or lower PL emerge (Supplementary Video 1). As shown in Fig. 1f and Supplementary Fig. 9, the regions that lose the most intensity also display a dramatic PL blue shift of ∼75 meV and the emergence of a second peak at much higher energy close to 2 eV. This suggests that the reference FAPbI3 phase is highly unstable and over the course of ten minutes of light soaking, multiple new phases/compositions emerge, negatively affecting the optoelectronic quality of the material. The regions that retain the most PL intensity simply drop in intensity without any peak shift. The instability of the reference sample is further highlighted in Fig. 1g, which plots the integrated PL intensity at different points on the sample. By contrast, the DMPESI-treated sample displays remarkably different behaviour. The treated sample exhibits effectively no transient behaviour over the same time period, with negligible changes to the PL intensity, spatial distribution or spectra as shown in Fig. 1i–k and Supplementary Video 2. These results collectively show that the DMPESI treatment has turned an intrinsically unstable material into a much more stable one both macroscopically and microscopically. 

### **Atomistic mechanism with perovskite** 

To explore the reasons underlying stability of the DMPESI-treated perovskite film, we carried out DFT calculations of absorbed DMPESI and phenylethylammonium iodide (PEAI) layers on PbI2- and formamidinium iodide (FAI)-terminated perovskite surfaces at various surface coverage, as shown in Fig. 2a,b for the full-coverage systems<sup>25,26</sup> (detailed approach in the Supplementary Information). The interaction of a single DMPESI or PEAI unit on the PbI2-terminated surface provides us with the strength of the salt/perovskite surface, devoid of intermolecular packing interactions (Supplementary Fig. 10c–e). Supplementary Table 2 shows that the dissociative adsorption of the iodide salts, with formation of surface Pb–I bond, is strongly favoured in DMPESI vs PEAI (2.09 vs 1.74 eV) and effectively supersedes surface FAI bonding (1.61 eV). The strong interaction energy is a prerequisite to effectively prevent surface dissolution during device operation. At half coverage, DMPESI binding is still favoured over PEAI (1.93 vs 1.71 eV per molecule) though PEAI forms a slightly more compact layer (Supplementary Fig. 10f–g and Supplementary Table 2). Surprisingly, at full coverage, DMPESI preferentially forms an overlayer (about half of interacting molecules do not bind the perovskite surface) whereas PEAI forms an ordered monolayer (Supplementary Fig. 10h,i), with comparable interaction energies dominated by intermolecular interactions. The absence of directional hydrogen bond in the sulfonium-based DMPESI does not induce an ordered molecular orientation as it is found in the PEAI salt endowed with R-NH3+ groups. On a fully FAI-terminated perovskite surface, DMPESI also forms a strong protective layer with enhanced interaction energy (1.69 vs 1.28 eV) dominated by dispersion forces (Supplementary Fig. 10l,m). Thus DMPES<sup>+</sup> can effectively assist the encapsulation of mobile iodide anions via the sulfonium groups and the phenyl rings in the DMPESI framework. This encapsulation could also reduce the presence of interstitial iodine defects at the PbI2-terminated surface, which are demonstrated to be a hole-trapping centre<sup>27</sup> . Moreover, the electronic properties of the passivated slab with a DMPESI layer show a reduction of the surface traps with respect to the bare PbI2-terminated surface<sup>28</sup> , even if only half of the exposed surface Pb atoms are passivated by iodide, as shown in Supplementary Fig. 11. The interlayer in this case does not introduce notable changes on the electronic structure with respect to the bare FAI-terminated surface (Supplementary Fig. 11). Both DMPESI and PEAI are also able to effectively passivate surface FAI vacancies (Supplementary Fig. 10n,o). 

Overall, our analysis indicates the salient features of DMPESI/ perovskite interaction that make this salt different from standard 

Nature Energy | Volume 9 | February 2024 | 172–183 

**174** 

**Article** 

https://doi.org/10.1038/s41560-023-01421-6 



<!-- Start of picture text -->
a b<br>c d e<br>DMPESI Ref<br>200 nm        0.7 Å –1 200 nm<br>f g h<br>FA FA<br>DMPESI<br>FA<br>DMPESI treated 0 DMPESI treated<br>DMPESI treated<br>CP<br>×4<br>4<br>DMPESI DMPESI<br>8<br>12 8 4 0 140 100 60 20<br>8 4 0<br>1H  δ  (ppm) 1H  δ  (ppm) 13C  δ  (ppm)<br> (ppm) δ H 1<br><!-- End of picture text -->

**Fig. 2 | Microstructure of the perovskite films and interactions between DMPESI and FAPbI3. a** , **b** , DMPESI/FAPbI3 perovskite full-coverage interface DFT models at PbI2- ( **a** ) and FAI-terminated ( **b** ) surfaces. The following colour code is used for the atomic representations: purple, I; cyan, Pb; blue, N; yellow, S; green, C; white, H. **c** , Annular dark-field image reconstructed from SED data of DMPESItreated perovskite film. **d** , The ED patterns extracted from intragranular region are shown. **e** , Annular dark-field image reconstructed from SED data of reference film. Atomic-level interaction between FAPbI3 and DMPESI from solid-state NMR. 

**f** , Quantitative<sup>1</sup> H MAS NMR spectra of DMPESI (blue) and DMPESI-treated FAPbI3 prepared as spin-coated thin films (red). **g,**<sup>1</sup> H–<sup>1</sup> H spin-diffusion spectrum of DMPESI-treated FAPbI3 prepared as spin-coated thin films (50 kHz MAS, 23 T). The horizontal cross section at 3.4 ppm (dashed line) is shown in green. The spectrum of DMPESI is shown in green in panel **f** . **h** ,<sup>1</sup> H–<sup>13</sup> C cross polarization MAS spectra of DMPESI and DMPESI-treated FAPbI3 prepared as a drop-cast film. FA is formamidinium, CP is cross polarization, ×4 is 4 times intensity of the signal. 

PEAI. Basically, DMPESI is able to strongly bind the perovskite surface forming a surface hydrophobic layer. The strong surface interaction stabilizes the perovskite layer probably locking it into the black phase. At high coverage, however, the competition between surface/molecule and intermolecular interactions induces the formation of a DMPESI overlayer, which may limit charge extraction and to some extent prevent full surface passivation. 

Scanning electron diffraction (SED) measurements have been carried out to understand the impact of DMPESI on the microstructure of the perovskite film<sup>29</sup> . An annular dark-field (ADF) image reconstructed from SED data reveals variation in the diffraction contrast across the perovskite film with brighter regions appearing between distinct grains, as shown in Fig. 2c. Examining the SED pattern extracted from one of the grains reveals a perovskite grain oriented near the [001]c zone axis. The presence of superstructure reflections, forbidden from 

appearing in the cubic perovskite phase (white arrows in Supplementary Fig. 12b), indicates the presence of octahedral tilting, which has been shown to frustrate the phase transition from photoactive FA-rich perovskites to the photoinactive _δ_ phase<sup>30</sup> . Examining the SED pattern extracted from the intragranular region—Fig. 2d (in comparison with reference film in Fig. 2e)—indicates the presence of an additional crystalline phase, which can also be observed by the emission morphologies, shown in Supplementary Fig. 8. Combining with the results obtained from XRD and grazing-incidence wide angle X-ray scattering (GIWAXS), shown in Supplementary Fig. 13, we suspect the short diffraction vectors can most likely be attributed to low-dimensional perovskite structures formed between the grains of the 3D FAPbI3 bulk upon DMPESI treatment. Octahedral tilting is also observed in the reference perovskite film, as indicated in Supplementary Fig. 12d,e. This probably arises from the alloying trace amount of MA<sup>+</sup> on the A 

Nature Energy | Volume 9 | February 2024 | 172–183 

**175** 

**Article** 

https://doi.org/10.1038/s41560-023-01421-6 



<!-- Start of picture text -->
10–5<br>a Perovskite DMPESI b c<br>100 Glass Reference Reference<br>DMPESI:<br>1 mg ml –1<br>10–6 3 mg ml –1<br>5 mg ml –1<br>10 mg ml –1<br>Suppression<br>HTL of surface<br>10–1 Perovskite DMPESI recombination<br>Glass Reference Charge<br>10–7 extraction efficiency<br>Charge<br>extraction<br>efficiency<br>10–2 10–8<br>0 0.2 0.4 0.6 0.8 1.0 10–9 10–8 10–7 10–6 1.0 1.1 1.2 1.3<br>Time (µs) Time (s) ∆ E F (eV)<br>d e f<br>1.15<br>25 24<br>20 ControlDMPESI 1.10 1.38  k B T/q<br>21 1.05<br>15 J SC V OC FF PCE<br>(mA cm–2) (V) (%)<br>10 RS 25.42 1.107 0.769 21.65 MPPT 1.00 1.74  k B T/q<br>FS 25.44 1.103 0.748 20.98 18 ambient air DMPESI<br>5 RS 25.53 1.136 0.805 23.32 0.95 Control<br>FS 25.39 1.135 0.803 23.14 DMPESI<br>0 15<br>0.0 0.2 0.4 0.6 0.8 1.0 1.2 0 100 200 300 400 500 0.1 0.4 1.0<br>Voltage (V) Time (s) ln ( I I0 –1)<br>Normalized PL<br> (s)  Decay time τTPL<br>PCE (%)  (V) V OC<br>–2 )Current density (mA cm<br><!-- End of picture text -->

**Fig. 3 | Optoelectronic properties of perovskite films and photovoltaic devices performance. a** , Transient PL decays of reference and DMPESIpassivated (3 mg ml<sup>−1</sup> ) perovskite films on glass with and without HTL. The fits are obtained from the multi-exponential decay function, which were used to calculate the differential lifetimes. The saturated coloured balls correspond to PL decays of perovskite on glass (shown in grey box) with (red) and without (black) DMPESI. The non-saturated coloured circles correspond to PL decays of perovskite on glass with an HTL on top (shown in lilac box). **b** , **c** , Differential decay time of passivated perovskite films with HTL plotted as a function of time after excitation ( **b** ) and quasi-Fermi level splitting ( **c** ). As the concentration of the DMPESI increases, the suppression of the surface recombination increases 

as well (up to 3 mg ml<sup>−1</sup> ), but the charge extraction efficiency decreases. **d** , _J_ – _V_ curves of the control (black) and (3 mg ml<sup>−1</sup> ) DMPESI-treated (red) devices, reverse scan (RS) and forward scan (FS) are indicated as solid symbols and open symbols, respectively. Inserted table summarized the corresponding photovoltaic parameters. **e** , PCE of the device employing DMPESI (3 mg ml<sup>−1</sup> ) treatment device at maximum power point as a function of time at room temperature (r.t.), under ambient condition, without encapsulation. **f** , _V_ OC versus logarithm of light intensity of the solar cells with and without DMPESI treatment with corresponding linear fits, from which the slopes determined by the ideality factors (1.38 for DMPESI and 1.74 for control) were found. _kB_ is the Boltzmann constant, T is the temperature and _q_ is the elementary charge. 

site with FA<sup>+</sup> and imbues a degree of stability (that is, the reference film does not turn entirely to _δ_ phase immediately), although is not sufficient to firmly stabilize the perovskite film. The synergistic effect of the DMPESI at the grain boundaries and the structural octahedral tilting, however, successfully realizes an ultra-stable perovskite film upon treatment. 

To further assess the microscopic interaction between DMPESI and the FAPbI3 film, we conducted solid-state magic angle spinning (MAS) NMR measurements (<sup>1</sup> H NMR and<sup>13</sup> C NMR)<sup>31</sup> . High-resolution<sup>1</sup> H MAS NMR spectra of thin films of FAPbI3 passivated with DMPESI are shown in Fig. 2f–h. Whereas the aromatic signals of DMPESI (6–8.5 ppm) overlap with those of FA in Fig. 2f, the spectrum (0–5 ppm) contains signals originating from the aliphatic part of DMPESI. There is a qualitative difference in the aliphatic region between DMPESI and DMPESI-treated FAPbI3 film, indicating that in the latter case, DMPESI is in a different chemical form. Moreover, we conducted a<sup>1</sup> H–<sup>1</sup> H spin-diffusion experiment that probes proximities via magnetic dipole–dipole interactions between protons (Fig. 2g). Despite the substantial signal overlap mentioned above, it is clear that the aliphatic signal of DMPESI at 3.4 ppm has an intermolecular dipolar coupling to FA rather than 

only an intramolecular dipolar coupling to the aromatic protons of DMPESI. This is evident based on the shape of the cross-peak, which has two components whose position and intensity ratio matches exactly those of the FA signal (Fig. 2g, green trace). To further corroborate the interaction of DMPESI with FAPbI3, we next carried out<sup>13</sup> C MAS NMR measurements on drop-cast films (Fig. 2h), which shows substantial changes to the structure of DMPESI in the solid material. As shown from the cross polarization (CP) spectrum, which detects exclusively rigid local environments, the aromatic and aliphatic DMPESI peaks are shifted and broadened relative to DMPESI, revealing the interaction and/or reaction between DMPESI and FAPbI3. More detailed discussions of the solid-state NMR data are provided in Supplementary Note 3. 

Furthermore, to investigate the composition of the new species formed upon DMPESI treatment, we synthesized various stoichiometries of the possible low-dimensional perovskites and compared their XRD patterns, as indicated in Supplementary Fig. 14. Interestingly, the two broad peaks (4.3° and 5.5°) observed in the perovskite film treated with a more than optimal amount of DMPESI (10 mg ml<sup>−1</sup> ) cannot be assigned to any single low-dimensional perovskite species but appear at the same diffraction angles in a 1:5 mol/mol mixture of 

Nature Energy | Volume 9 | February 2024 | 172–183 

**176** 

**Article** 

https://doi.org/10.1038/s41560-023-01421-6 



<!-- Start of picture text -->
a b<br>1.0<br>100,000 DMPESI (aged)<br>0.8<br>Ambient<br>0.6 Fresh After 67 days 10,000<br>0.4 100,000 Control (aged)<br>Control<br>0.2<br>DMPESI 10,000<br>0<br>0 10 20 30 40 50 60 70 10 15 20 25 30<br>Time (d) 2 θ  (°)<br>c d<br>1.0<br>1.0<br>0.9<br>0.8<br>0.8 Thermal cycle Damp heat<br>Control<br>Control<br>0.6 DMPESI<br>0.7 DMPESI<br>0 20 40 60 80 100 0 200 400 600 800 1,000<br>Number of temperature cycles Time (h)<br>e f<br>0.81.0 T 80 ~78,931 h 0.951.00 70486725 6223 82654,567641 15,37 57 7 725 77603555 445973 ~100%<br>0.6 0.90 6546 50 52 74 68 78<br>0.4 Control MPPT 0.85 66 47 53 69,71 58<br>0.2 DMPESIFit of linear regime 0.80 63 49 45,51,61,64 FAPbIMixed cation–mixed halide3<br>0.75 Our work (FAPbI3)<br>0<br>0 1,000 2,000 3,000 4,000 5,000 0 1,000 2,000 3,000 4,000 5,000<br>Time (h) Time (h)<br>g h<br>105 105 A u HTL Perovskite<br>104 104 Control (fresh)<br>103 Control (fresh)DMPESI (fresh) 103 Au diffusion DMPESI (fresh)Control (aged)<br>DMPESI (aged)<br>102 Iodine diffusion Control (aged)DMPESI (aged) 102<br>101 101<br>Au HTL Perovskite<br>100 100<br>0 300 600 900 1,200 1,500 0 1,000 2,000 3,000 4,000<br>Sputter time (s) Sputter time (s)<br>Intensity<br>Normalized PCE (%) Intensity<br>ControlDMPESI<br>Normalized PCE Normalized PCE<br>PCE/PCE (%)0<br>Normalized PCE<br>Intensity (counts) Intensity (counts)<br><!-- End of picture text -->

**Fig. 4 | Durability of the PSCs. a** , Dark shelf stability of unencapsulated control and DMPESI-treated PSCs and inserted photos are the devices before and after ageing in ambient condition at r.t. with R.H. around 20–40%, five devices for each condition, the initial device PCEs are 23.02 ± 0.26% (DMPESI treated) and 21.03 ± 0.48% (control). **b** , XRD patterns of shelf-aged control and DMPESItreated PSCs. **c** , Temperature cycling (25–85 °C) test of encapsulated control and treated devices, five devices for each condition. **d** , Damp heat test (85 °C, 85% R.H.) of the encapsulated control and treated devices, five devices for each condition. The initial PCEs of temperature cycling and damp heat tested devices are 22.24 ± 0.22% (DMPESI treated) and 20.12 ± 0.42% (control). Data 

are presented as mean values ± SEM for **a** , **c** and **d** . **e** , Long-term operational stability of the unencapsulated control and treated devices under MPPT with continuous 1-sun illumination under N2 flow at room temperature. The linear fitting of DMPESI-treated device maximum power point stability, the initial device PCE is 22.68% (DMPESI treated) and 20.43% (control). **f** , Operational stability of state-of-the-art highly efficient (PCE > 22%) PSCs extracted from literature<sup>8,15,23,25,26,35,37,41,44–78</sup> (perovskite composition based on FAPbI3 marked in green dots; mixed cation–mixed halide marked in blue dots; our work marked in red star).ToF-SIMS depth profiles of the fresh and aged (control and treated) devices of **g** , I<sup>−</sup> and **h** , Au. 

DMPESI and FAPbI3. This result indicates that unlike ammonium salts, which commonly form pure low-dimensional perovskites upon surface treatment, DMEPSI is prone to reacting with FAPbI3 to form a mixture species, which can be further evidenced by the very similar surface morphology (Supplementary Fig. 15), compared with the 10 mg ml<sup>−1</sup> DMPESI-treated perovskite film as indicated in Supplementary Fig. 2. This is also in agreement with DFT calculations, which reveals the propensity of DMPESI to establish intermolecular interactions at high coverage in comparison with other ammonium salts (that is, PEAI) that tend to form two-dimensional phases at the surface of the 3D perovskite. 

### **Optoelectronic properties of perovskite films and devices** 

To investigate the optoelectronic properties of the DMPESI-treated perovskite films with and without hole-transporting layer (HTL), time-resolved PL-decay measurements have been carried out, as shown in Fig. 3a and Supplementary Fig. 16, respectively. Evidently, moderate quantities of DMPESI result in effective prolongation of charge-carrier lifetime under high-injection regime, indicating high quality of the perovskite films with notably reduced non-radiative recombination. To disentangle between different competing processes leading to 

Nature Energy | Volume 9 | February 2024 | 172–183 

**177** 

**Article** 

https://doi.org/10.1038/s41560-023-01421-6 

excess charge-carrier depopulation, we utilized a differential lifetime ( _τ_ TPL) approach pioneered by Kirchartz et al<sup>32,33</sup> . Because differential lifetime highly depends on the charge-carrier injection and PL derivative over time, it provides additional information about the charge-carrier dynamics on different timescales, such as second-order radiative and first-order trap-assisted recombination mechanisms. The synergy of differential lifetime analysis with a numerical simulation (description of both methods can be found in Supplementary Note 4) reveals that DMPESI-treated samples have >16 times less surface recombination. Because the introduction of charge-selective layers should not cause any additional non-radiative recombination and, hence, quench the PL intensity at longer timescales under open-circuit condition<sup>34</sup> . We attribute the prolongation of _τ_ TPL by DMPESI treatment shown in Fig. 3b to its effective suppression of surface states at the perovskite/HTL interface. However, thicker DMPESI layers (>3 mg ml<sup>−1</sup> ) hinder the charge extraction efficiency (visible at timescales <10<sup>−8</sup> s), due to charge accumulation at perovskite/DMPESI contact (Supplementary Fig. 18) without further reduction in interfacial recombination, as seen by the convergence of differential lifetimes of samples with various DMPESI concentrations at _τ_ TPL ≈ 3.5 _μ_ s (Fig. 3c). Therefore, the layer produced by 3 mg ml<sup>−1</sup> DMPESI solution strongly suppresses the non-radiative recombination at perovskite/HTL interface and, simultaneously, allows an efficient hole extraction by an HTL. 

PSC devices were fabricated with DMPESI treatment (under various conditions) by employing the n–i–p architecture of fluorine doped tin oxide (FTO)/cp-TiO2/mp-TiO2/3D perovskite/DMPESI/spiro-OMeTAD/ Au, in comparison with the reference cells and the PEAI treated ones. Statistical box charts of the photovoltaic parameters and the corresponding champion values are shown in Supplementary Fig. 19 and Supplementary Tables 6 and 7, respectively. Compared with the control devices, the devices post treated with trace amount (1 mg ml<sup>−1</sup> ) of DMPESI present slight improvements in open-circuit voltage ( _V_ OC) and fill factor (FF), however, a large amount (10 mg ml<sup>−1</sup> ) of DMPESI results in inferior values in all PV parameters, which we attribute to the blocked charge transfer upon aggregation and formation of a thick interlayer between perovskite and HTL, as observed in cross-section SEM in Supplementary Fig. 20. This result is also in agreement with the time-resolved PL measurement discussed above. Both _V_ OC and FF are substantially increased by introducing moderate quantities, especially 3 mg ml<sup>−1</sup> of DMPESI, leading to the best reverse PCE of 23.32% and forward PCE of 23.14%, as summarized in the table in Fig. 3d. The PCE is stabilized at 23.3% under maximum power point, as shown in Fig. 3e. Incident photon-to-current conversion efficiency was measured and shown in Supplementary Fig. 21, which demonstrates efficient light harvesting across the absorption spectrum and has an integrated value agreeing with the measured _J_ SC from the _I_ – _V_ measurement. It is worth noticing that the hysteresis of the treated devices becomes negligible in comparison with the control devices. In addition, Fig. 3f shows a linear relationship between _V_ OC and the logarithm of light intensity for both the control and treated PSCs. From this measurement, the diode ideality factor ( _n_ id) of the control cell was found to be 1.74, whereas the treated cell has a _n_ id of 1.38. Such reduction in _n_ id suggests an effective suppression of the trap-assisted recombination, which affects mainly _V_ OC and FF losses<sup>35,36</sup> . On the basis of the reconstructed pseudo- _J_ – _V_ curves, as shown in Supplementary Fig. 22, the FF losses associated with charge transport remain nearly unchanged in the presence of DMPESI, whereas the non-radiative recombination FF losses are reduced by a factor of two. We attribute the suppression of non-radiative recombination to a strong reduction in trap density, which has been confirmed by the space-charge-limited current measurements (Supplementary Fig. 23) and DFT calculations (Supplementary Fig. 11), agreeing well with the reduction in energy tail states and Urbach energy (Supplementary Fig. 24). Combining with the analysis shown earlier, we postulate that the introduction of DMPESI on the perovskite surfaces effectively 

passivates the disordered states at the interfaces and thus strongly reduces non-radiative recombination to improve device _V_ OC and FF. 

### **Durability of the PSCs** 

To investigate the stability of the PSCs, we first tracked their shelf-life stability by storing the unencapsulated devices in ambient air with R.H. of 40% ± 20% for more than two months. Figure 4a shows that the PCE of a control device without any post treatment decreased by ∼60% after ageing for 67 days, whereas the treated device with 3 mg ml<sup>−1</sup> DMPESI treatment retains 94% of its initial PCE value. Visual inspection of the devices before and after ageing shows that the control device turned light brown, indicating a phase transformation resulting in lower light absorption in the visible part of the spectrum. The DMPESI-treated device remained completely black, which was confirmed by XRD (Fig. 4b). A thermal-stability test was also performed by heating the unencapsulated PSCs at 60 °C with R.H. of less than 30%. From the results in Supplementary Fig. 25a, the treated cell retained more than 96% of its initial PCE, whereas the control cell retained less than 85% after 400 h of ageing. Moreover, we replaced the hole-transporting material (spiro-OMeTAD) with the more thermally stable material of poly(bis(4-phenyl)(2,4,6-trimethylphenyl)amine) (PTAA) for harsh thermal-stability tests. As shown in Fig. 4c, we observed a dramatic stability improvement in the DMPESI-treated devices (encapsulated) under thermal cycling (between 25 °C to 85 °C, procedure shown in Supplementary Fig. 25b), following the ISOS-T-1 stability protocol<sup>7</sup> . Furthermore, the encapsulated treated device also successfully passed the damp heat test (85 °C at 85% R.H. condition) for over 1,000 h with less than 5% loss in PCE, as shown in Fig. 4d. 

To further examine the treated FAPbI3-based PSCs under intensive light soaking and gain insights into the intrinsic degradation mechanisms, we exposed the cells to maximum power point tracking (MPPT) under continuous 1-sun illumination in an inert atmosphere with N2 flow at room temperature. As presented in Fig. 4e and the corresponding current-voltage ( _J_ – _V_ ) parameters in Supplementary Fig. 26, an initial rapid burn-in regime within the first 30 h is clearly observed in the control cell, leading to a PCE loss of 12% of its initial value, which is similar to other reports on FAPbI3 PSCs in literature<sup>7,37</sup> . This is typically attributed to the redistribution of charged defects<sup>38</sup> . Subsequently, a slower decay is present in the control cell, owing to irreversible chemical reactions through migration, which gradually cause irreversible degradation of the device, leading to a 20% loss after operational ageing for 1,500 h. In stark contrast, the treated device shows an extraordinary long-term operational stability under the same ageing condition, with negligible PCE drop (less than 1%) after half-year MPPT ageing for over 4,500 h. This result makes our device among the most stable, high-efficiency PSC reported to date, as illustrated in Fig. 4f (more details summarized in Supplementary Table 8). A similar result is also obtained by measuring other cells within the same batch and different batches, as shown in Supplementary Fig. 27. Making a linear extrapolation of these data yields a theoretical _T_ 80 of over nine years (Fig. 4e) under continuous 1-sun illumination, which would correspond to a photon flux of an outdoor PV installation in Sweden or Germany (1,000 kWh m<sup>−2</sup> per year) of over 78 years. 

On the basis of the combination of results from SED, transient PL and PL-decay analysis, we attribute the initial burn-in effect present in the reference samples to lower energy barrier for I<sup>−</sup> migration and their accumulation of iodide interstitials (Ii− and Ii+) at the surfaces. As recently demonstrated, the phase impurities, often found at the grain boundaries, seed the degradation under illumination by trapping the photoexcited charge carriers and forming I2(refs.39–41). DMPESI post treatment effectively inhibits this mechanism by passivating the surface states and sequestrating mobile I<sup>−</sup> ions at the grain boundaries, preventing an accumulation of interstitial iodide at the phase impurities and thus circumventing degradation<sup>42</sup> . Consequently, this leads to reduced rate of non-radiative recombination processes in 

Nature Energy | Volume 9 | February 2024 | 172–183 

**178** 

**Article** 

https://doi.org/10.1038/s41560-023-01421-6 

perovskite, which also remain constant even after long time duration (Fig. 1k), resulting in a stable PSC performance without the burn-in effect (Fig. 4e). 

Furthermore, undesirable migration, especially of iodide ions from the perovskite bulk and of gold from the metal contact, has been investigated as a principal factor that causes deleterious effects on the stability of metal halide perovskites<sup>43,44</sup> . Therefore, time-of-flight secondary ion mass spectroscopy (ToF-SIMS) elemental depth profiles have been carried out for both devices (control and treated) before and after the continuous operational ageing process, and the full spectra are shown in Supplementary Fig. 28. It is observed that both the as-prepared control and treated cells have similar signals occurrence for I<sup>−</sup> and Au. However, for the control cell after ageing, the signals of I<sup>−</sup> and Au are, as expected, substantially increased in the HTL layer and perovskite layer (Fig. 4g,h), respectively, which provides direct evidence for ion migration within the layers of the device. Such severe ion diffusion creates not only deep trap states but also shunts across the cell, leading to a dramatic PCE drop, especially in _V_ OC and FF, as also in accordance with the photovoltaic parameters measured throughout the MPPT ageing test. However, in sharp contrast, negligible I<sup>−</sup> and Au diffusion signals of diffusing species have been detected for the treated cells after ageing. This evidence clearly indicates that the introduction of DMPESI can effectively suppress the iodide ions and gold migration and improve the device stability. Moreover, surface treatment with DMPESI also shows positive effects on device performance and stability on other perovskite compositions, as shown in Supplementary Fig. 29. 

### **Conclusions** 

In conclusion, we have shown that a single surface treatment step with a sulfonium salt leads to stabilization of the black phase of FAPbI3. We elucidated that its mechanism of action is related to its interaction with the perovskite surface. Both the perovskite bulk through formation of an additional intragranular species at the grain boundaries and forming a robust interlayer between perovskite and HTL efficiently blocks mobile ion migration and protects the perovskite film from external atmosphere. As a result, it enables long-term stabilization of highly efficient PSCs, especially under moisture and light-soaking conditions, which also provides a strong indication that perovskite films exhibit the potential to fulfil industrial protocols and compete with Si-based solar cells for further large-scale and industrial production. Moreover, the in-depth understanding of such unexplored sulfonium-based molecules opens up more possibilities in material science and engineering, which is important and encouraging in the field, towards further stabilization of future perovskite-based optoelectronic devices. 

(m, 2H), 3.10 (dd, _J_ = 8.8, 7.0 Hz, 2H), 2.97 (s, 6H);<sup>13</sup> C NMR (101 MHz, DMSO) δ 137.98, 129.22, 129.15, 127.58, 43.43, 29.47, 24.73. 

#### **Synthesis of FAPbI3 powder** 

Formamidinium acetate (20.8 g, 0.20 mol, Sigma-Aldrich) was dissolved in ethanol (30 ml, Acros) at 0 °C, HI solution (57% in water, 40 ml, Sigma-Aldrich) was added dropwise into the solution. After 30 min, the solution was removed to room temperature and stirred for another 1 h. The solvent was removed by using a rotary evaporator at 60 °C; the solid was recrystallized by mixture solution of ethanol and diethyl ether (Sigma-Aldrich) three times. Then the formamidinium iodide was dried under vacuum for 2 h. FAI (2.75 g, 16 mmol) and PbI2 (7.37 g, 16 mmol) were dissolved in the anhydrous 2-methoxylethanol (20 ml, Sigma-Aldrich), then the solution was stirred at 140 °C for 2 h, anhydrous toluene (40 ml, Sigma-Aldrich) was added dropwise. The black FAPbI3 powder was filtered and dried under vacuum for 2 h, the black powder was stored in argon glovebox. 

#### **Substrate** 

Fluorine doped tin oxide (FTO) substrates (NSG-10) were chemically etched by zinc powder and 4 M HCl solution and sonicated in 2% Hellmanex water solution for 30 min, acetone for 15 min and ethanol for 15 min, respectively. Then, all substrates were further cleaned by UV– ozone for 15 min. Then a compact TiO2 layer was deposited on cleaned FTO substrates via spray pyrolysis deposition from a precursor solution of titanium diisopropoxide bis(acetylacetonate) (Sigma-Aldrich) in anhydrous ethanol (Acros), with oxygen as carrier gas. Substrates were heated at 450 °C and kept at this temperature for 15 min before and 30 min after the spray of the precursor solution then left to cool down to room temperature. Mesoporous TiO2 layer was spin coated at 3,000 r.p.m. for 30 s, with the acceleration rate of 1,500 r.p.m. s<sup>−1</sup> , using a 30 nm TiO2 paste (Dyesol 30 NR-D) diluted in ethanol with 1:6 volume ratio. After the spin coating, the substrates were dried at 80 °C for 10 min and then sintered at 450 °C for 30 min under dry air flow. 

#### **Perovskite layer** 

The perovskite precursor solution was prepared by dissolving FAPbI3 powder (1.8 M) and MACl (0.63 M, Dyenamo) into mixed solvent of DMF and DMSO (DMF:DMSO = 4:1 v/v, Acros). The perovskite solution was spin coated at 6,000 r.p.m. for 50 s with pouring diethyl ether (1 ml, Acros) as an anti-solvent at 15 s of spin-coat process. Then the substrates were annealed at 150 °C for 10 min in dry air. The DMPESI was dissolved in chloroform (Acros) with different concentration and the solution was spin coated at 4,000 r.p.m. for 20 s on the as-prepared perovskite films and dried on a hot plate at 100 °C for 10 min. 

### **Methods** 

#### **Synthesis of DMPESI** 

2-Mercaptophenylenthane (2.0 g, 14.5 mmol, TCI), NaOH (1.0 g, 25.0 mmol, Alfa) tetrabutylammonium iodide (200 mg, 0.5 mmol, Sigma-Aldrich) were added into the mixed solution of toluene (10 ml, Sigma-Aldrich) and H2O (10 ml). Iodomethane (2.26 g, 16.0 mmol, Acros) was added dropwise into the mixture. After stirring for 12 h at room temperature, brine (50 ml) was added into the solution and the mixture was extracted by Et2O (30 ml × 3, Acros). After the combined organic phase was dried over MgSO4, the solvent was removed under reduced pressure to give the product (1.93 g, 82% yield) without further purification. Colourless liquid;<sup>1</sup> H NMR (400 MHz, CDCl3) δ 7.25–7.19 (m, 2H), 7.17–7.11 (m, 3H), 2.87–2.78 (m, 2H), 2.68 (t, _J_ = 7.9 Hz, 2H), 2.05 (s, 3H). Methyl(phenethyl)sulfane (1.80 g, 11.8 mmol) was dissolved in EtOH (10 ml, Acros) at room temperature, iodomethane (1.76 g, 12.0 mmol, Acros) was added dropwise into the solution. After the mixture was stirred for 24 h, Et2O (30 ml, Acros) was added into the solution. The solid was filtered and washed by diethyl ether three times to afford the final product. White solid;<sup>1</sup> H NMR (400 MHz, DMSO) δ 7.36 (d, _J_ = 4.4 Hz, 4H), 7.27 (ddd, _J_ = 8.7, 5.0, 3.8 Hz, 1H), 3.72–3.59 

#### **Hole-transporting layer and Au top contact** 

The substrates were cooled down to room temperature after annealing the perovskite. The hole-transporting solution was deposited by spin coating at 4,000 r.p.m. for 20 s as hole-transporting material. Spiro-MeOTAD: 90 mg spiro-MeOTAD (Xi’an Polymer Light Technology) was dissolved in 1 ml chlorobenzene, doped by 20.6 μl bis(trifluoromethylsulfonyl)imide lithium salt solution (520 mg ml<sup>−1</sup> LiTFSI in acetonitrile, Sigma-Aldrich) and 35.5 μl 4-tert-butylpyridine (tBP, Sigma-Aldrich). PTAA: 10 mg PTAA (Xi’an Polymer Light Technology) was dissolved in 1 ml, doped by 1.6 μl bis(trifluoromethylsulfonyl) imide lithium salt solution (520 mg ml<sup>−1</sup> LiTFSI in acetonitrile, Sigma-Aldrich) and 2 μl 4-tert-butylpyridine. Finally, 80 nm of Au top electrode was deposited through thermal evaporator under high vacuum with an active area of 0.16 cm<sup>2</sup> . 

#### **PSC characterization** 

The solar cell devices were measured using a 300 W Xenon light source (Oriel). The spectral mismatch between AM 1.5 G and the solar simulator was calibrated by a Schott K113 Tempax filter (Prazosopms Gas 

Nature Energy | Volume 9 | February 2024 | 172–183 

**179** 

**Article** 

https://doi.org/10.1038/s41560-023-01421-6 

and Optik GmbH). The light intensity was calibrated with a silicon photodiode with an infrared-cut-off filter (KG2, Schott). Current– voltage characteristics were applied by an external voltage bias while measuring the corresponding current with Keithley 2400 under ambient air condition. The voltage scan rate was 50 mV s<sup>−1</sup> . The devices were covered with a black metal mask with an active area of 0.16 cm<sup>2</sup> . Incident photon-to-current efficiency was carried by a commercial apparatus (Aekeo-Ariadne, Cicci Research s.r.l.). The top-view and cross-section morphologies of the samples were characterized using a high-resolution scanning electron microscope (Zeiss Merlin) with an in-lens secondary electron detector. 

#### **XRD and GIWAXS measurement** 

The X-ray diffraction patterns were recorded with PANalytical Empyrean system with a PIXcel-1D detector, Bragg–Brentano beam optics and parallel beam optics. Light source is from copper Kα beam filtered with nickel β filter. Diffraction spectra were characterized between 2θ of 10° and 70° at a scan rate of 1° per minute with the step width of 0.02°. GIWAXS were measured on a Bruker D8 Discover Plus instrument equipped with a rotating anode and a Dectris Eiger2 500 K detector. The primary beam path was collimated by a 1.0 mm micromask (after a focussing Göbel mirror), followed by a 0.5 mm micromask, followed by a 0.3 mm double-pinhole collimator. The detector was placed at 178 mm from the sample and 2D images were acquired for 300 seconds at 2° theta (incidence angle). Two-dimensional images were integrated using EVA software. Photoelectron spectroscopy measurements were performed in a custom-built ultra-high vacuum system. The pass energy was 10 eV, and the samples were grounded during the measurement. 

#### **SED measurement** 

Scanning electron diffraction (SED) data were acquired on the JEOL ARM300CF E02 instrument at ePSIC, Diamond Light Source with a Merlin/Medipix pixelated STEM detector. Utilizing the following experimental parameters: accelerating voltage = 200 kV; nanobeam alignment ( ∼ 1 mrad convergence angle); electron probe ∼5 nm; probe current ∼3.1 pA; scan dwell time 1 ms; camera length 15 cm, we achieved an electron dose per scan of ∼10 eÅ<sup>−2</sup> at 150,000 × magnification when approximating the beam shape as a circle with a diameter of ∼5 nm. This accumulated dose is almost an order of magnitude lower than the lowest reported threshold at which the crystal structure of FAPbI3 begins to change (66 eÅ<sup>−2</sup> ). SED data were calibrated and corrected for elliptical distortions using reference data acquired on an Au cross grating. In SED, under our experimental conditions, 1 pixel on the Merlin/Medipix pixelated STEM detector is ∼0.0059 Å<sup>−1</sup> . SED diffraction data were analysed in pyXem. In the manuscript, we refer to annular dark-field (ADF) images in reference to SED data presented in Fig. 2. ADFs are reconstructed from SED data by plotting the integrated diffracted intensity as a function of probe position, excluding the directly transmitted beam. The samples were prepared on SiN windows from Norcada (part number: NT025X) with 0.65 M perovskite precursor; the spin-coating process is same with perovskite film fabrication above. SED integrates through the thickness of the film and thus does not provide any depth resolution in its measurements. 

#### **Hyperspectral photoluminescence map** 

Wide-field, hyperspectral photoluminescence microscopy was performed using a Photon etc. IMA system. The sample was excited with a 405 nm continuous wave laser shaped to have a top hat profile larger than the field of view of the camera so the area of interest was uniformly illuminated. The excitation was focused onto the sample using an Olympus 100× air objective (MPLFLN100×) to produce an illumination intensity of 67 mW cm<sup>−2</sup> , equivalent to approximately 1-sun illumination for a material with the bandgap of FAPbI3. A volume Bragg grating was used to spectrally split the light at each point on the sample. First 

a hyperspectral scan of a sample was performed, then the sample was continuously illuminated for a period of time and broadband luminescence images were intermittently captured every 1.5 seconds. Once this light-soaking period was complete, a final hyperspectral scan was once again performed. 

#### **Solid-state NMR** 

Solid-state magic angle spinning (MAS) NMR spectra of<sup>1</sup> H (1,000.4 MHz) were recorded on a Bruker Avance Neo 23.5 T spectrometer equipped with a 1.3 mm MAS probe using 100 kHz RF field amplitude. For the<sup>1</sup> H–<sup>1</sup> H spin-diffusion measurement, a recycle delay of 2 s, mixing delay of 2 s, 150 slices and 16 scans per slice were used. The 2D dataset was processed with 100 Hz of Lorentzian apodization in the directly detected dimension.<sup>1</sup> H chemical shifts were referenced to the<sup>13</sup> C chemical shift of solid adamantane (38.48 ppm for the CH2 signal) using the ratio of the gyromagnetic ratios in accordance with the International Union of Pure and Applied Chemistry (IUPAC) recommendation.<sup>13</sup> C echo and<sup>1</sup> H–<sup>13</sup> C CP MAS spectra were recorded on a Bruker Avance Neo 14.1 T (150.7 MHz) spectrometer equipped with a 4 mm CP MAS probe and referenced to solid adamantane. Seventy-four kHz<sup>1</sup> H decoupling was used. The recycle delays and numbers of scans are given in Supplementary Table 2. The rotors were spun using dry nitrogen. Two types of sample were used for NMR: (1) spin-coated passivated thin films prepared according to the same procedure as in device fabrication (<sup>1</sup> H measurements) and (2) drop-cast films (<sup>13</sup> C measurements, to obtain a larger amount of material). 

#### **Stability test** 

The operational stability of the devices was measured under a white light-emitting diode lamp with biologic MPG2 potentiostat under N2 gas flow at maximum power point tracking (MPPT). The encapsulation of PSCs devices is using EVA as the encapsulant and using glass as the cover. For the temperature cycling test, a hot plate is using to control the temperature (R.T.–85 °C). 

#### **Other measurements** 

The photoluminescence lifetime was measured via time-correlated single photon counting using a LifeSpec II (Edinburgh Instruments) fluorescence spectrometer with a picosecond pulsed diode laser (EPL510, Edinburgh Instruments) at 510 nm wavelength.<sup>1</sup> H NMR and<sup>13</sup> C NMR measurements were performed on Bruker AvanceIII-400 MHz NMR spectrometer. Atomic force microscopy (AFM) measurements were carried out using an AFM (Bruker Dimension Icon) in air with controlled humidity at around 20% R.H. 

#### **Reporting summary** 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

### **Data availability** 

All data generated or analysed during this study are included in the published article and its Supplementary Information files. Source data are provided with this paper. 

### **References** 

1. _Best Research-Cell Efficiency Chart_ (NREL, 2022); www.nrel.gov/ 

   - pv/cell-efficiency.html 

2. Su, H. et al. Stable perovskite solar cells with 23.12% efficiency and area over 1 cm<sup>2</sup> by an all-in-one strategy. _Sci. China Chem._ **65** , 1321–1329 (2022). 

3. Ding, Y. et al. Single-crystalline TiO2 nanoparticles for stable and efficient perovskite modules. _Nat. Nanotechnol._ **17** , 598–605 (2022). 

4. Kim, M. et al. Conformal quantum dot–SnO2 layers as electron transporters for efficient perovskite solar cells. _Science_ **375** , 302–306 (2022). 

Nature Energy | Volume 9 | February 2024 | 172–183 

**180** 

**Article** 

https://doi.org/10.1038/s41560-023-01421-6 

5. Walker, E. and Thoubboron, K. _Solar Panel Warranties: What to Know_ (Energysage, 2022); https://news.energysage.com/ shopping-solar-panels-pay-attention-to-solar-panels-warranty/ 

6. Peters, I. M. et al. The value of stability in photovoltaics. _Joule_ **5** , 3137–3153 (2021). 

7. Khenkin, M. V. et al. Consensus statement for stability assessment and reporting for perovskite photovoltaics based on ISOS procedures. _Nat. Energy_ **5** , 35–49 (2020). 

8. Chen, S. et al. Stabilizing perovskite-substrate interfaces for high-performance perovskite modules. _Science_ **373** , 902–907 (2021). 

9. Meggiolaro, D., Mosconi, E. & De Angelis, F. Formation of surface defects dominates ion migration in lead-halide perovskites. _ACS Energy Lett._ **4** , 779–785 (2019). 

10. Tan, S. et al. Stability-limiting heterointerfaces of perovskite photovoltaics. _Nature_ **605** , 268–273 (2022). 

11. Yang, S. et al. Stabilizing halide perovskite surfaces for solar cell operation with wide-bandgap lead oxysalts. _Science_ **365** , 473–478 (2019). 

12. Dunfield, S. P. et al. From defects to degradation: a mechanistic understanding of degradation in perovskite solar cell devices and modules. _Adv. Energy Mater._ **10** , 1904054 (2020). 

13. Yusoff, A. R. M. et al. Passivation and process engineering approaches of halide perovskite films for high efficiency and stability perovskite solar cells. _Energy Environ. Sci._ **14** , 2906–2953 (2021). 

14. Jiang, Q. et al. Surface passivation of perovskite film for efficient solar cells. _Nat. Photonics_ **13** , 460–466 (2019). 

15. Suo, J. et al. Interfacial engineering from material to solvent: a mechanistic understanding on stabilizing _α_ -formamidinium lead triiodide perovskite photovoltaics. _Nano Energy_ **94** , 106924 (2022). 

16. Bi, D. et al. Polymer-templated nucleation and crystal growth of perovskite films for solar cells with effciency greater than 21%. _Nat. Energy_ **1** , 16142 (2016). 

17. Kim, B. & Soek, S. I. Molecular aspects of organic cations affecting the humidity stability of perovskites. _Energy Environ. Sci._ **13** , 805–820 (2022). 

18. Kaltzoglou, A. et al. Trimethylsulfonium lead triiodide: an airstable hybrid halide perovskite. _Inorg. Chem._ **56** , 6302–6309 (2017). 

19. Kim, B. et al. Enhanced moisture stability by butyldimethylsulfonium cation in perovskite solar cells. _Adv. Sci._ **7** , 1901840 (2020). 

20. Cai, Y. et al. Organic sulfonium-stabilized high efficiency cesiumor methylammonium lead bromide perovskite nanocrystals. _Angew. Chem. Int. Ed._ **61** , e202209 (2022). 

21. Zuo, X. et al. Passivating buried interface via self-assembled novel sulfonium salt toward stable and efficient perovskite solar cells. _Chem. Eng. J._ **431** , 133209 (2022). 

22. Kim, M. et al. Methylammonium chloride induces intermediate phase stabilization for efficient perovskite solar cells. _Joule_ **3** , 2179–2192 (2019). 

23. Min, H. et al. Efficient, stable solar cells by using inherent bandgap of _α_ -phase formamidinium lead iodide. _Science_ **366** , 749–753 (2019). 

24. Wozny, S. et al. Controlled humidity study on the formation of higher efficiency formamidinium lead triiodide-based solar cells. _Chem. Mater._ **27** , 4814–4820 (2015). 

25. Yang, B. et al. Outstanding passivation effect by a mixed-salt interlayer with internal interactions in perovskite solar cells. _ACS Energy Lett._ **5** , 3159–3167 (2020). 

26. Suo, J. et al. Surface reconstruction engineering with synergistic effect of mixed-salt passivation treatment toward efficient and stable perovskite solar cells. _Adv. Funct. Mater._ **31** , 2102902 (2021). 

27. Ambrosio, F. et al. Charge localization and trapping at surfaces in lead-iodide perovskites: the role of polarons and defects. _J. Mater. Chem. A_ **8** , 6882–6892 (2020). 

28. Meggiolaro, D. et al. Energy level tuning at the MAPbI3 perovskite/ contact interface using chemical treatment. _ACS Energy Lett._ **4** , 2181–2184 (2019). 

29. Orri, J. F. et al. Unveiling the interaction mechanisms of electron and X-ray radiation with halide perovskite semiconductors using scanning nanoprobe diffraction. _Adv. Mater._ **34** , 2200383 (2022). 

30. Doherty, T. S. et al. Stabilized tilted-octahedra halide perovskites inhibit local formation of performance-limiting phases. _Scinece_ **374** , 1598–1605 (2021). 

31. Kubicki, D. J. et al. NMR spectroscopy probes microstructure, dynamics and doping of metal halide perovskites. _Nat. Rev. Chem._ **5** , 624–645 (2021). 

32. Krückemeier, L. et al. Understanding transient photoluminescence in halide perovskite layer stacks and solar cells. _Adv. Energy Mater._ **11** , 2003489 (2021). 

33. Krogmeier, B. et al. Quantitative analysis of the transient photoluminescence of CH3NH3PbI3/PC61BM heterojunctions by numerical simulations. _Sustain. Energy Fuels_ **2** , 1027–1034 (2018). 

34. Al-Ashouri, A. et al. Monolithic perovskite/silicon tandem solar cell with >29% efficiency by enhanced hole extraction. _Science_ **370** , 1300–1309 (2020). 

35. Yang, B. et al. Interfacial passivation engineering of perovskite solar cells with fill factor over 82% and outstanding operational stability on n–i–p architecture. _ACS Energy Lett._ **6** , 3916–3923 (2021). 

36. Tress, W. et al. Interpretation and evolution of open-circuit voltage, recombination, ideality factor and subgap defect states during reversible light-soaking and irreversible degradation of perovskite solar cells. _Energy Environ. Sci._ **11** , 151–165 (2018). 

37. Park, B. et al. Stabilization of formamidinium lead triiodide _α_ -phase with isopropylammonium chloride for perovskite solar cells. _Nat. Energy_ **6** , 419–428 (2021). 

38. Domanski, K. et al. Systematic investigation of the impact of operation conditions on the degradation behaviour of perovskite solar cells. _Nat. Energy_ **3** , 61–67 (2018). 

39. Ni, Z. et al. Evolution of defects during the degradation of metal halide perovskite solar cells under reverse bias and illumination. _Nat. Energy_ **7** , 65–73 (2022). 

40. Motti, S. G. et al. Controlling competing photochemical reactions stabilizes perovskite solar cells. _Nat. Photonics_ **15** , 532–539 (2019). 

41. Tan, S. et al. Shallow iodine defects accelerate the degradation of _α_ -phase formamidinium perovskite. _Joule_ **4** , 2426–2442 (2020). 

42. Meggiolaro, D. et al. Formation of surface defects dominates ion migration in lead-halide perovskites. _ACS Energy Lett._ **4** , 779–785 (2019). 

43. Wang, Y. et al. Stabilizing heterostructures of soft perovskite semiconductors. _Science_ **365** , 687–691 (2019). 

44. Zai, H. et al. Sandwiched electrode buffer for efficient and stable perovskite solar cells with dual back surface fields. _Joule_ **5** , 2148–2163 (2021). 

45. Hui, W. et al. Stabilizing black-phase formamidinium perovskite formation at room temperature and high humidity. _Science_ **371** , 1359–1364 (2021). 

46. Kim, G. et al. Impact of strain relaxation on performance of _α_ -formamidinium lead iodide perovskite solar cells. _Science_ **370** , 108–112 (2020). 

47. Jeong, J. et al. Pseudo-halide anion engineering for α-FAPbI3 perovskite solar cells. _Nature_ **592** , 381–385 (2021). 

48. Lu, H. et al. Vapor-assisted deposition of highly efficient, stable black-phase FAPbI3 perovskite solar cells. _Science_ **370** , eabb8985 (2020). 

Nature Energy | Volume 9 | February 2024 | 172–183 

**181** 

**Article** 

https://doi.org/10.1038/s41560-023-01421-6 

49. Yoo, J. J. et al. Efficient perovskite solar cells via improved carrier management. _Nature_ **590** , 587–593 (2021). 

50. Guo, P. et al. Interfacial embedding of laser-manufactured fluorinated gold clusters enabling stable perovskite solar cells with efficiency over 24%. _Adv. Mater._ **33** , 2101590 (2021). 

51. Min, H. et al. Perovskite solar cells with atomically coherent interlayers on SnO2 electrodes. _Nature_ **598** , 444–450 (2021). 

52. Yun, H.-S. et al. Ethanol-based green-solution processing of _α_ -formamidinium lead triiodide perovskite layers. _Nat. Energy_ **7** , 828–834 (2022). 

53. Yoo, J. J. et al. An interface stabilized perovskite solar cell with high stabilized efficiency and low voltage loss. _Energy Environ. Sci._ **12** , 2192–2199 (2019). 

54. Zhu, H. et al. Tailored amphiphilic molecular mitigators for stable perovskite solar cells with 23.5% efficiency. _Adv. Mater._ **32** , 1907757 (2020). 

55. Jang, Y.-W. et al. Intact 2D/3D halide junction perovskite solar cells via solid-phase in-plane growth. _Nat. Energy_ **6** , 63–71 (2021). 

56. Zhang, H. et al. Multimodal host–guest complexation for efficient and stable perovskite photovoltaics. _Nat. Commun._ **12** , 3383 (2021). 

57. Pei, F. et al. Thermal management enables more efficient and stable perovskite solar cells. _ACS Energy Lett._ **6** , 3029–3036 (2021). 

58. Xue, J. et al. Reconfiguring the band-edge states of photovoltaic perovskites by conjugated organic cations. _Science_ **371** , 636–640 (2021). 

59. Li, N. et al. Liquid medium annealing for fabricating durable perovskite solar cells with improved reproducibility. _Science_ **373** , 561–567 (2021). 

60. Jung, E. H. et al. Efficient, stable and scalable perovskite solar cells using poly(3-hexylthiophene). _Nature_ **567** , 511–515 (2019). 

61. Yang, Y. et al. Modulation of perovskite crystallization processes towards highly efficient and stable perovskite solar cells with MXene quantum dot-modified SnO2. _Energy Environ. Sci._ **14** , 3447–3454 (2021). 

62. Zhu, H. et al. Synergistic effect of fluorinated passivator and hole transport dopant enables stable perovskite solar cells with an efficiency near 24%. _J. Am. Chem. Soc._ **143** , 3231–3237 (2021). 

63. Su, T.-S. et al. Crown ether modulation enables over 23% efficient formamidinium-based perovskite solar cells. _J. Am. Chem. Soc._ **142** , 19980–19991 (2020). 

64. Wang, R. et al. Constructive molecular configurations for surface-defect passivation of perovskite photovoltaics. _Science_ **366** , 1509–1513 (2019). 

65. Wang, H. et al. Water stable haloplumbate modulation for efficient and stable hybrid perovskite photovoltaics. _Adv. Energy Mater._ **11** , 2101082 (2021). 

66. Wang, P. et al. Cobalt chloride hexahydrate assisted in reducing energy loss in perovskite solar cells with record open-circuit voltage of 1.20 V. _ACS Energy Lett._ **6** , 2121–2128 (2021). 

67. Wang, P. et al. Gradient energy alignment engineering for planar perovskite solar cells with efficiency over 23%. _Adv. Mater._ **32** , 1905766 (2020). 

68. Krishna, A. et al. Nanoscale interfacial engineering enables highly stable and efficient perovskite photovoltaics. _Energy Environ. Sci._ **14** , 5552–5562 (2021). 

69. Zhang, F. et al. Metastable Dion–Jacobson 2D structure enables efficient and stable perovskite solar cells. _Science_ **375** , 71–76 (2022). 

70. Peng, J. et al. Centimetre-scale perovskite solar cells with fill factors of more than 86 per cent. _Nature_ **601** , 573–578 (2022). 

71. Zhao, L. et al. Enabling full-scale grain boundary mitigation in polycrystalline perovskite solids. _Sci. Adv._ **8** , eabo3733 (2022). 

72. Wang, T. et al. Transporting holes stably under iodide invasion in efficient perovskite solar cells. _Science_ **377** , 1227 (2022). 

73. Sidhik, S. et al. Deterministic fabrication of 3D/2D perovskite bilayer stacks for durable and efficient solar cells. _Science_ **377** , 1425–1430 (2022). 

74. Liu, C. et al. Tuning structural isomers of phenylenediammonium to afford efficient and stable perovskite solar cells and modules. _Nat. Commun._ **12** , 6394 (2021). 

75. Cao, Q. et al. Star-polymer multidentate-cross-linking strategy for superior operational stability of inverted perovskite solar cells at high efficiency. _Energy Environ. Sci._ **14** , 5406–5415 (2021). 

76. Li, X. et al. Constructing heterojunctions by surface sulfidation for efficient inverted perovskite solar cells. _Science_ **375** , 434–437 (2022). 

77. Li, Z. et al. Organometallic-functionalized interfaces for highly efficient inverted perovskite solar cells. _Science_ **376** , 416–420 (2022). 

78. Jiang, Q. et al. Surface reaction for efficient and stable inverted perovskite solar cells. _Nature_ **611** , 278–283 (2022). 

### **Acknowledgements** 

We acknowledge W. Bi (École polytechnique fédérale de Lausanne, EPFL) for help of XRD measurements and P. A. Schouwink (EPFL) for GIWAXS measurements. J.S. and A. Hagfeldt acknowledge Swiss National Science Foundation for financial support with project number 200020_185041. B.Y. and A. Hagfeldt acknowledge funding from the European Union’s Horizon 2020 research and innovation programme under grant agreement number 764047 and from the Horizon Europe framework programme for research and innovation under grant agreement number 101084124–DIAMOND. E.M. wishes to thank the project Ricerca@CNR PHOTOCAT (CUP B93C21000060006). F.D.A was supported by the Italian Ministry of Environment and Energy Security in the framework of the Project GoPV (CSEAA_00011) for Research on the Electric System. E.M. and F.D.A acknowledge funding from the European Union’s Horizon Europe research and innovation programme under grant agreement number 101082176–VALHALLA. D.B. acknowledges the scholarship support of the German Federal Environmental Foundation (DBU). F.F. acknowledges the funding from the Swiss National Science Foundation (number 200021_213073). K.F. acknowledges an Engineering and Physical Sciences Research Council (EPSRC) Doctoral Prize Fellowship and a Winton Sustainability Fund Studentship. T.A.S.D. acknowledges the support of an Oppenheimer Research Fellowship, a Schmidt Science Fellowship and a Research Fellowship at Murray Edwards College. S.D.S. acknowledges the Royal Society and Tata Group (UF150033) and the EPSRC (EP/R023980/1) for funding. The work has received funding from the European Research Council under the European Union’s Horizon 2020 research and innovation programme (HYPERION–grant agreement number 756962). The UK High-Field Solid-State NMR Facility used in this research was funded by EPSRC and Biotechnology and Biological Sciences Research Council (BBSRC) (EP/T015063/1) and for the 1 GHz instrument, EP/R029946/1. Collaborative assistance from the Facility Manager Team (D. Iuga and T. Franks, University of Warwick) is acknowledged. D.J.K. acknowledges the support of the University of Warwick. This work was carried out with the support for Diamond Light Source, instrument E02 at the electron physical science research centre (ePSIC) (proposal MG30750). 

### **Author contributions** 

J.S. and B.Y. conceived the idea, prepared films and fabricated all devices and characterizations. E.M., L.B. and F.D.A. performed the DFT calculations. D.B. and L.W. performed PL-decay simulations, whereas D.B., O.E.-R. and A. Hinsch analysed the carrier-dependent decay time. D.B. also conducted the drift-diffusion simulation of 

Nature Energy | Volume 9 | February 2024 | 172–183 

**182** 

**Article** 

https://doi.org/10.1038/s41560-023-01421-6 

perovskite/HTL interface. T.A.S.D. performed SED measurements and analysed the data. K.F. and S.D.S. performed the hyperspectral PL maps measurement and analysed the data. D.J.K carried out the solid-state NMR measurements and analysed the data. F.F. performed the ToF-SIMS measurements. Y.K. performed the contact angle measurement and assisted perovskite film stability under high humidity. T.Z. and F.G. performed the AFM measurement. J.S., B.Y., E.M., D.B., L.W. and A. Hagfeldt participated in editing the manuscript. A. Hagfeldt directed the overall research. All authors read and commented on the manuscript. 

### **Funding** 

Open access funding provided by Uppsala University. 

### **Competing interests** 

S.D.S. is a co-founder of Swift Solar Inc. The remaining authors declare no competing interests. 

### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41560023-01421-6. 

**Correspondence and requests for materials** should be addressed to Bowen Yang, Edoardo Mosconi or Anders Hagfeldt. 

**Peer review information** _Nature Energy_ thanks Baomin Xu and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at www.nature.com/reprints. 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons. org/licenses/by/4.0/. 

##### © The Author(s) 2024 

1Department of Chemistry–Ångström Laboratory, Uppsala University, Uppsala, Sweden. 2Laboratory of Photomolecular Science, Institute of Chemical Sciences and Engineering, School of Basic Sciences, Ecole Polytechnique Fédérale de Lausanne, Lausanne, Switzerland.<sup>3</sup> Computational Laboratory for Hybrid/Organic Photovoltaics (CLHYO), Istituto CNR di Scienze e Tecnologie Chimiche ‘Giulio Natta’ (CNR-SCITEC), Perugia, Italy.<sup>4</sup> Fraunhofer Institute for Solar Energy Systems ISE, Freiburg, Germany.<sup>5</sup> Department of Sustainable Systems Engineering (INATECH), Albert-Ludwigs-Universität Freiburg, Freiburg, Germany.<sup>6</sup> Solarlab Aiko Europe GmbH, Freiburg, Germany.<sup>7</sup> Department of Chemical Engineering and Biotechnology, University of Cambridge, Cambridge, UK.<sup>8</sup> Department of Materials Science and Metallurgy, University of Cambridge, Cambridge, UK.<sup>9</sup> Cavendish Laboratory, Department of Physics, University of Cambridge, Cambridge, UK.<sup>10</sup> Department of Physics, University of Warwick, Coventry, UK.<sup>11</sup> Laboratory for Thin Films and Photovoltaics, Empa−Swiss Federal Laboratories for Materials Science and Technology, Duebendorf, Switzerland.<sup>12</sup> Laboratory for Molecular Engineering of Optoelectronic Nanomaterials, Institute of Chemical Sciences and Engineering, School of Basic Sciences, Ecole Polytechnique Fédérale de Lausanne, Lausanne, Switzerland.<sup>13</sup> Department of Physics, Chemistry and Biology (IFM), Linköping University, Linköping, Sweden.<sup>14</sup> Department of Chemistry, Biology and Biotechnology, University of Perugia, Perugia, Italy.<sup>15</sup> Physics of Solar Energy Conversion Group, Department of Physics, Philipps-University Marburg, Marburg, Germany.<sup>16</sup> Department of Natural Sciences and Mathematics, College of Sciences and Human Studies, Prince Mohammad Bin Fahd University, Dhahran, Saudi Arabia.<sup>17</sup> SKKU Institute of Energy Science and Technology (SIEST), Sungkyunkwan University, Suwon, Korea. 18Present address: School of Chemistry, University of Birmingham, Edgbaston, UK. 19These authors contributed equally: Jiajia Suo, Bowen Yang. e-mail: bowen.yang@kemi.uu.se; edoardo@thch.unipg.it; anders.hagfeldt@uu.se 

Nature Energy | Volume 9 | February 2024 | 172–183 

**183** 











