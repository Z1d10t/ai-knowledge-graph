# Liquid-phase sintering of lead halide perovskites and metal-organic framework glasses

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Science |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 210 |
| 作者 | Jing-Wei Hou, Peng Chen, A. Shukla, A. Krajnc, Tie-Sheng Wang, Xue-Mei Li, Rana Doasa, L. Tizei et al. |
| DOI | 10.1126/science.abf4460 |
| 源文件 | 020_Hou_2021_Liquid-phase-sintering-of-lead-halide-perovskite.pdf |

---


eprints@whiterose.ac.uk https://eprints.whiterose.ac.uk **Universities of Leeds, Sheffield and York** 

Deposited via The University of Leeds. 

White Rose Research Online URL for this paper: <mark>https://eprints.whiterose.ac.uk/id/eprint/178435/</mark> 

Version: Accepted Version 

## **Article:** 

Hou, J, Chen, P, Shukla, A et al. (2021) Liquid-phase sintering of lead halide perovskites and metal-organic framework glasses. Science, 374 (6567). pp. 621-625. ISSN: 00368075 

<mark>https://doi.org/10.1126/science.abf4460</mark> 

© 2021 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. This is the author’s version of the work. It is posted here by permission of the AAAS for personal use, not for redistribution. The definitive version was published in Science on 28th October 2021, Vol. 374, DOI:10.1126/science.abf4460 

### **Reuse** 

Items deposited in White Rose Research Online are protected by copyright, with all rights reserved unless indicated otherwise. They may be downloaded and/or printed for private study, or other acts as permitted by national copyright laws. The publisher or other rights holders may allow further reproduction and re-use of the full text version. This is indicated by the licence information on the White Rose Research Online record for the item. 

### **Takedown** 

If you consider content in White Rose Research Online to be in breach of UK law, please notify us by emailing eprints@whiterose.ac.uk including the URL of the record and the reason for the withdrawal request. 



Submitted Manuscript: Confidential Template revised February 2021 

# **Title: Liquid-phase sintering of lead halide perovskites and metal-organic framework glasses** 

5 

**Authors:** Jingwei Hou<sup>1,*</sup> , Peng Chen<sup>1,2</sup> , Atul Shukla<sup>3,4</sup> , Andraž Krajnc<sup>5</sup> , Tiesheng Wang<sup>6</sup> , Xuemei Li<sup>1</sup> , Rana Doasa<sup>7</sup> , Luiz H. G. Tizei<sup>8</sup> , Bun Chan<sup>9</sup> , Duncan N. Johnstone<sup>10</sup> , Rijia Lin<sup>1</sup> , Tobias U. Schülli<sup>11</sup> , Isaac Martens<sup>11</sup> , Dominique Appadoo<sup>12</sup> , Mark S'Ari<sup>7</sup> , Zhiliang Wang<sup>1,2</sup> , Tong Wei<sup>13</sup> , Shih-Chun Lo<sup>4,14</sup> , Mingyuan Lu<sup>15</sup> , Shichun Li<sup>16</sup> ,Ebinazar B. Namdas<sup>3,4</sup> , Gregor Mali<sup>5</sup> , Anthony K. Cheetham<sup>17,18</sup> , Sean. M. Collins<sup>19,*</sup> , Vicki Chen<sup>1</sup> , Lianzhou Wang<sup>1,2*</sup> , Thomas D. Bennett<sup>10,*</sup> 

## **Affiliations:** 

10 

1School of Chemical Engineering, The University of Queensland, St Lucia, QLD, 4072 Australia. 

2Australian Institute for Bioengineering and Nanotechnology, The University of Queensland, St Lucia, QLD, 4072 Australia. 

15 

3School of Mathematics and Physics, The University of Queensland, St Lucia, QLD, 4072 Australia. 

4Centre for Organic Photonics & Electronics, The University of Queensland, Brisbane, Queensland 4072, Australia. 

5Department of Inorganic Chemistry and Technology, National Institute of Chemistry, 1001 Ljubljana, Slovenia. 

20 

6School of Mechanical Engineering, Shanghai Jiao Tong University, Shanghai 200240, China. 

- 7School of Chemical and Process Engineering, University of Leeds, LS2 9JT, UK. 

8Université Paris-Saclay, CNRS, Laboratoire de Physique des Solides, 91405, Orsay, France. 

9Graduate School of Engineering, Nagasaki University, Nagasaki 852-8521 Japan. 

25 

10Department of Materials Science and Metallurgy, University of Cambridge, 27 Charles Babbage Road, Cambridge, CB3 0FS, UK. 

11ESRF—The European Synchrotron, 71 Avenue des Martyrs, 38000 Grenoble, France. 

- 12Australian Synchrotron, 800 Blackburn Rd, Clayton, VIC, 3168 Australia. 

- 13College of Science, Civil Aviation University of China, Tianjin 300300, China. 

30 

14School of Chemistry and Molecular Biosciences, The University of Queensland, St Lucia, QLD, 4072 Australia. 

15School of Mechanical and Mining Engineering, The University of Queensland, St Lucia, QLD, 4072 Australia. 

16Institute of Chemical Materials, China Academy of Engineering Physics, Mianyang 621900, China. 

35 

- 17Materials Research Laboratory, University of California, Santa Barbara, CA, 93106 USA. 

- 18Department of Materials Science and Engineering, National University of Singapore, Singapore, 117576 Singapore. 

1 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

15 

20 

25 

30 

35 

19School of Chemical and Process Engineering and School of Chemistry, University of Leeds, LS2 9JT, UK. 

*Correspondence to: jingwei.hou@uq.edu.au; s.m.collins@leeds.ac.uk; l.wang@uq.edu.au; tdb35@cam.ac.uk 

**Abstract:** Lead halide perovskite (LHP) semiconductors show exceptional optoelectronic properties. Important barriers for their applications, however, lie in their polymorphism, instability to polar solvents, phase segregation and susceptibility to the leaching of lead ions. We report a family of scalable composites fabricated through liquid-phase sintering of LHPs and metal-organic framework glasses. The glass acts as a matrix for LHPs, effectively stabilizing non-equilibrium perovskite phases by interfacial interactions. These interactions also passivate LHP surface defects and impart bright, narrow-band photoluminescence with a wide-gamut for creating white LEDs. The processable composites show high stability against immersion in water and organic solvents, alongside exposure to heat, light, air, and ambient humidity. These properties, together with their lead self-sequestration capability, can enable breakthrough applications for LHPs. 

**One-Sentence Summary:** Ultrastable and highly luminescent lead halide perovskite and metalorganic framework glass composites 

## **Main Text:** 

Lead halide perovskites (LHPs) exhibit tunable bandgaps, high charge carrier mobilities, and bright, narrow-band photoluminescence (PL) that could offer advantages for optoelectronic applications over conventional Si-based and binary II-VI, III-V and IV-VI semiconducting materials ( _1_ ). However, for successful technological integration, LHPs must overcome their inherent polymorphism, decomposition upon exposure to polar solvents, oxygen, heat and light, the presence of trap states, and the phase segregation and leaching of toxic heavy metal ions ( _2_ , _3_ ). Targeted high optical absorptivity and direct band gaps optimal for photovoltaics and redlight LEDs, for example, are found in the CsPbI3 pseudo-cubic ‘black’ phases (α-, β- and γ- phases), but thermodynamic factors promote their conversion to the inactive nonperovskite ‘yellow’ δ-phase under ambient conditions (Fig. 1A) ( _4_ ). LHP materials for white light LEDs will critically depend on stabilization of this red emitter, ideally combined in a single broad-band luminescent material architecture. 

40 

The formation of LHP composites may offer solutions to some of these problems ( _5_ ), but the ionic nature of LHPs is not entirely conducive to composite fabrication. Functional penalties incurred include LHP aggregation and decomposition, poor mechanical stability caused by weak interfacial interactions with the chosen matrix, and the formation of high concentrations of trap states ( _6_ ). Research into a subfamily of metal-organic frameworks (MOFs) called zeolitic imidazolate frameworks (ZIFs) has enabled access to high-temperature ZIF liquids and microporous glasses after quenching ( _7_ ). ZIF glasses have distinct physicochemical properties in terms of their porosity, reactivity, mechanical rigidity/ductility and optical response ( _8_ – _10_ ), and have been used as host matrices for crystalline MOFs ( _11_ , _12_ ). Together, these properties make ZIF glasses prime candidates for addressing the multiple challenges for LHP composite formation. 

2 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

15 

We describe a new class of composites, fabricated by liquid phase sintering of crystalline LHPs and ZIF glass matrices, and show that industrial powder processing techniques used to form high-performance composites can be applied to chemically dissimilar LHPs and ZIF glasses. ZIF-62 (Zn[(Im)1.95(bIm)0.05] (Im: imidazolate; bIm: benzimidazolate)) and CsPbI3 were first synthesized mechanochemically and showed the expected phase transitions (Fig. 1A, fig. S1 to S3) ( _13_ ). 25 wt% CsPbI3 was then mixed with ZIF-62 glass (denoted as agZIF-62, glass transition temperature _T_ g: ~304°C, fig. S3B), and the mixtures are termed (CsPbI3)(agZIF62)(25/75) ( _11_ ). The ex situ synchrotron powder x-ray diffraction (XRD) pattern of (CsPbI3)(agZIF-62)(25/75) (mixture pattern in Fig. 1B) exhibited weak Bragg peaks, ascribed to the nonperovskite δ-CsPbI3 phase. The mixture was sintered at different temperatures (up to 350°C) and then quenched with liquid nitrogen (referred to as cryogenic quenching) under flowing Ar. The resultant composites, termed (CsPbI3)0.25(agZIF-62)0.75, showed XRD features consistent with the metastable γ-CsPbI3 phase, with gradually increasing intensity with higher sintering temperatures (Fig. 1B, fig. S4). Negligible weight loss was observed during sintering (fig. S5). 

20 

The broad PL emission of agZIF-62 was reduced after mixing with CsPbI3, which we attribute to photon absorption by CsPbI3 (fig. S6) ( _14_ ). The (CsPbI3)0.25(agZIF-62)0.75 composites started to show red PL emission after sintering-quenching at 175°C, with the strongest PL obtained with 275°C (Fig. 1C). Higher sintering temperatures red-shifted the PL maxima (fig. S7), concomitant with an observed decrease in the optical band gaps (Fig. 1D, fig. S6C). They also led to a lower defect density and enhanced homogeneity for the CsPbI3 component, as indicated by the reduced PL full-widths at half-maximum (FWHM) and the longer excited-state lifetimes (fig. S8, Table S1) ( _15_ ). Compared to a slower quenching, rapid, cryogenic quenching formed materials with optimal PL lifetimes and PL quantum yields (PLQY, >50%) (fig. S9 and S10, Table S1). 

25 Temperature-resolved high-resolution in situ synchrotron powder XRD was collected for (CsPbI3)(agZIF-62)(25/75) (Fig. 2A, fig. S11). The emerging peaks from ~170°C indicate the formation of α-CsPbI3 ( _Pm-3m_ ). These peaks intensified at higher sintering temperatures. During the quenching stage, the gradual emergence of β-CsPbI3 ( _P4/mbm_ ) (from ~250°C) and γ-CsPbI3 ( _Pbnm_ ) (from ~150°C) was evidenced ( _16_ ). The deconvoluted α-CsPbI3 crystallite size increased 30 during sintering (Fig. 2B), consistent with the changes in band gap caused by quantumconfinement effects ( _5_ ). 

35 

40 

45 

The evolution of α-CsPbI3 crystallite size can be attributed to coarsening of CsPbI3 grains and the phase transition from bulkier δ-CsPbI3 crystallites, a cascade confirmed by synchrotron in situ small-angle x-ray scattering (SAXS). Coarsening of CsPbI3 grains mainly occurred in the size range smaller than the XRD deconvoluted crystallite size at <10 nm, starting from 165°C (Fig. 2C, fig. S12 to S14). Upon sintering, atoms in CsPbI3 grains became mobile from the Tamman temperature ( _T_ Tamman ~103°C) as approximated by 0.5 _T_ melt in degrees K ( _16_ , _17_ ). A similar response could also be expected for agZIF-62. Characteristic of liquid-phase sintering, CsPbI3 grain coarsening and composite densification were observed at a temperature lower than the inherent _T_ g of agZIF-62 (~304°C) (fig. S15) ( _18_ ). The emergence of an interface resulting from densification occurs analogously to surface energy-controlled transitions from δ- to α-phase in solvent-modulated or ligand-capped CsPbI3 quantum dots ( _19_ , _20_ ), with the interfacial energy dominant for smaller grains resulting in phase transitions at lower temperatures. To examine our hypothesis that intimate interfacial contact is critical for phase control, we synthesized [Zn(Im)1.75(bIm)0.25] agZIF-62 with a higher _T_ melt and higher viscosity caused by bulkier bIm 

3 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

15 

20 

25 

30 

ligands and subsequently demonstrated the expected higher residual δ-CsPbI3 content in the composite (fig. S16). 

We further probed the changes in interfacial bonding within (CsPbI3)0.25(agZIF-62)0.75 by temperature-resolved synchrotron terahertz (THz) radiation and far-infrared (FarIR) vibrational spectroscopy. The 2<sup>nd</sup> -derivative spectra revealed the fine vibrational modes of Zn tetrahedra (Fig. 2D, fig. S17 and S18) ( _9_ ). The modes assigned to Zn-N vibrations (~287 cm<sup>-1</sup> ) and Zn-I stretching (~135 cm<sup>-1</sup> ) within Zn(Im)2(bIm)I tetrahedra by density functional theory (fig. S19) began to intensify with increasing temperature from ~140°C. These changes were consistent with the endothermic response at ~140°C in the first heating ramp of differential scanning calorimetry (DSC) measurements, concomitant with changes in CsPbI3 binding observed in phonon signatures and in ex situ spectroscopy (fig. S20 to S23). 

Magic-angle-spinning nuclear magnetic resonance (MAS NMR) spectroscopy provided insights into the different species complementary to vibrational spectroscopy. The broader signals from composite<sup>13</sup> C and<sup>15</sup> N spectra indicated additional disorder of ZIF component over the powder mixture (fig. S24). The<sup>133</sup> Cs MAS NMR spectra of (CsPbI3)(agZIF-62)(25/75) exhibited narrow signals of δ-CsPbI3 [260 parts per million (ppm)] ( _21_ ) and CsI (~280 ppm). Broad, low signals extending between 0 and ~350 ppm can be ascribed to poorly crystalline, highly defective CsPbI3 (Fig. 2E, fig. S25). After sintering, the broad contributions and CsI peaks diminished, and the major signals stemmed from g-CsPbI3. These signals exhibited notable shoulders (160 to 80 ppm), with shoulder intensities highly dependent on the sintering conditions. They could be assigned to Cs nuclei on or near the surface of CsPbI3 grains where structural defects, sites of the interaction between the g-CsPbI3 and agZIF-62, or both are abundant. We also noted that the signals of the δ-CsPbI3 of the same sample exhibited no shoulder, consistent with less interfacial contact between δ-CsPbI3 and agZIF-62. 

These observations allowed us to propose a mechanism for γ-CsPbI3 stabilization within composites ( _22_ , _23_ ). The α-, β- and γ-phases of CsPbI3 have double-well phonon modes at the center of the Brillouin zone, driving the phase transition to δ-CsPbI3 in a concerted phonon manner ( _24_ ). The interfacial bonding disrupts the local Pb-I sublattice phonon modes and therefore avoids the harmonic order-disorder entropy ( _25_ , _26_ ). Together with the physical confinement effect offered by the matrices, these factors counter the strong thermodynamic driving force to form δ-CsPbI3. 

35 

40 

We evaluated this mechanism further and verified embedded nanocrystals of γ-CsPbI3 as the source of luminescence using microscopic measurements. After sintering the mixture of particles became a monolith with a smooth surface observed in scanning electron microscopy (SEM) (fig. S26 and S27). Annular dark-field scanning transmission electron microscopy (ADF-STEM) of (CsPbI3)0.25(agZIF-62)0.75 showed pronounced atomic number contrast between the two phases, further corroborated by energy-dispersive x-ray spectroscopy (STEM-EDS) elemental distribution mapping (Fig. 3A, fig. S28). The crystalline and amorphous regions were identified by scanning electron diffraction (SED) ( _27_ ) with regions exhibiting Bragg diffraction corresponding to crystalline CsPbI3 grains (Fig. 3B). Convolutional neural network (CNN) classification identified γ-CsPbI3 as the major phase within the composite fragment. Individual grains were single-crystalline, whereas the speckle in the classification map arose from inherent ambiguities due to overlap in the diffraction peaks expected from δ- and γ-CsPbI3 (Fig. 3C, fig. S29 and S30). The average size of CsPbI3 from STEM was ~30 nm (fig. S31), readily modulated by extended ball milling before sintering, which further enhanced the composite PLQY to >65% due to a more pronounced quantum confinement effect (fig. S32) ( _5_ ). 

45 

4 

Submitted Manuscript: Confidential Template revised February 2021 

10 

15 

5 

20 

25 

30 

To probe the internal structure, we performed ADF-STEM tomography on a shard (>1 µm) of (CsPbI3)0.25(agZIF-62)0.75 (Fig. 3D). The voids in cross-sections of the volume are characteristic of densification processes in liquid phase sintering ( _18_ ). Point diffraction data identified both δ- CsPbI3 and γ-CsPbI3 within the particle. A high degree of interfacial contact was correlated with γ-CsPbI3, consistent with the hypothesized phase control through interfacial stabilization (fig. S33). STEM-based cathodoluminescence (CL) detected strong, narrow luminescence from isolated grains (<40 nm), with minor interparticle emission wavelength shifts (Fig. 3E-F, fig. S34). The variation of CL intensity is complex in origin, highly sensitive to the crystal quality and exposure to unpassivated surface states and particle size effects ( _28_ ). Despite this, the CL spectra from individual grains provided incontrovertible evidence of luminescence from glassbound nanocrystals of γ-CsPbI3. 

Returning to the aim of achieving long device lifetimes, we evaluated the composites in diverse environmental and operational settings. The rigid, hydrophobic agZIF-62 provided protection for CsPbI3 (fig. S35 and S36), leading to stable PL emission for (CsPbI3)0.25(agZIF-62)0.75 after extended (~20 h) sonication in various nonpolar, polar protic, and polar aprotic organic solvents (fig. S37). The composite also exhibited stability against 10,000 hours immersion in water, storage under ambient conditions for 650 days, mild heating and continuous laser excitation (~57 mW/cm<sup>2</sup> ) for >5000 s (Fig.4A, fig. S38 to S40). The microporous composite design presents a key route to sequestration of toxic components (fig. S41 and S42), or to potential photochemical platforms where the CsPbI3 crystals are not electronically insulated (fig. S43). (CsPbI3)0.25(agZIF-62)0.75 made from mechanochemical precursors have similar performance compared with the solvothermal precursors, making the composite promising for up-scaling (fig. S44). Collectively, (CsPbI3)0.25(agZIF-62)0.75 offers significant advantages over LHP composites with other substrates (fig. S45, Table S2). 

Finally, an array of composites were formed from CsPbX3 (X=Cl, Br and mixed halide ions) and agZIF-62, showing a wide color gamut with narrow PL peaks (Fig. 4B and C, Table S3). For all the CsPbX3 composites, their absolute PL intensities were at least two orders of magnitude higher than those of the corresponding pure CsPbX3 samples, either as-synthesized or after being treated with identical sintering (fig. S46). These properties, together with the high processibility (Fig. 4D), render these monolithic materials ideal candidates for downshifting white LEDs (fig. S47). 

## **References and Notes** 

35 

1. M. V. Kovalenko, L. Protesescu, M. I. Bodnarchuk, Properties and potential optoelectronic applications of lead halide perovskite nanocrystals. _Science_ . **_358_** , 745–750 (2017). 

2. X. Li, F. Zhang, H. He, J. J. Berry, K. Zhu, T. Xu, On-device lead sequestration for perovskite solar cells. _Nature_ . **_578_** , 555–558 (2020). 

40 

3. T. A. S. Doherty, A. J. Winchester, S. Macpherson, D. N. Johnstone, V. Pareek, E. M. Tennyson, S. Kosar, F. U. Kosasih, M. Anaya, M. Abdi-Jalebi, Z. Andaji-Garmaroudi, E. L. Wong, J. Madéo, Y.-H. Chiang, J.-S. Park, Y.-K. Jung, C. E. Petoukhoff, G. Divitini, M. K. L. Man, C. Ducati, A. Walsh, P. A. Midgley, K. M. Dani, S. D. Stranks, Performance-limiting nanoscale trap clusters at grain junctions in halide perovskites. _Nature_ . **_580_** , 360–366 (2020). 

5 

Submitted Manuscript: Confidential Template revised February 2021 

4. Y. Wang, M. I. Dar, L. K. Ono, T. Zhang, M. Kan, Y. Li, L. Zhang, X. Wang, Y. Yang, X. Gao, Y. Qi, M. Grätzel, Y. Zhao, Thermodynamically stabilized β-CsPbI3–based perovskite solar cells with efficiencies >18%. _Science_ . **_365_** , 591–595 (2019). 

5. J. Shamsi, A. S. Urban, M. Imran, L. De Trizio, L. Manna, Metal halide perovskite 5 nanocrystals: synthesis, post-synthesis modifications, and their optical properties. _Chem. Rev._ **_119_** , 3296–3348 (2019). 

6. Q. A. Akkerman, G. Rainò, M. V. Kovalenko, L. Manna, Genesis, challenges and opportunities for colloidal lead halide perovskite nanocrystals. _Nat. Mater._ **_17_** , 394–405 (2018). 

7. T. D. Bennett, Y. Yue, P. Li, A. Qiao, H. Tao, N. G. Greaves, T. Richards, G. I. 10 Lampronti, S. A. T. Redfern, F. Blanc, O. K. Farha, J. T. Hupp, A. K. Cheetham, D. A. Keen, Melt-quenched glasses of metal–organic frameworks. _J. Am. Chem. Soc._ **_138_** , 3484–3492 (2016). 

8. R. S. K. Madsen, A. Qiao, J. Sen, I. Hung, K. Chen, Z. Gan, S. Sen, Y. Yue, Ultrahighfield<sup>67</sup> Zn NMR reveals short-range disorder in zeolitic imidazolate framework glasses. _Science_ . **_367_** , 1473–1476 (2020). 

15 

9. J. Hou, M. L. Ríos Gómez, A. Krajnc, A. McCaul, S. Li, A. M. Bumstead, A. F. Sapnik, Z. Deng, R. Lin, P. A. Chater, D. S. Keeble, D. A. Keen, D. Appadoo, B. Chan, V. Chen, G. Mali, T. D. Bennett, Halogenated metal–organic framework glasses and liquids. _J. Am. Chem. Soc._ **_142_** , 3880–3890 (2020). 

10. L. Frentzel-Beyme, M. Kloss, P. Kolodzeiski, R. Pallach, S. Henke, Meltable mixed20 linker zeolitic imidazolate frameworks and their microporous glasses - from melting point engineering to selective hydrocarbon sorption. _J. Am. Chem. Soc._ **_141_** , 12362–12371 (2019). 

25 

11. J. Hou, C. W. Ashling, S. M. Collins, A. Krajnc, C. Zhou, L. Longley, D. N. Johnstone, P. A. Chater, S. Li, M.-V. Coulet, P. L. Llewellyn, F.-X. Coudert, D. A. Keen, P. A. Midgley, G. Mali, V. Chen, T. D. Bennett, Metal-organic framework crystal-glass composites. _Nat. Commun._ **_10_** , 2580 (2019). 

12. C. W. Ashling, D. N. Johnstone, R. N. Widmer, J. Hou, S. M. Collins, A. F. Sapnik, A. M. Bumstead, P. A. Midgley, P. A. Chater, D. A. Keen, T. D. Bennett, Synthesis and properties of a compositional series of MIL-53(Al) metal–organic framework crystal-glass composites. _J. Am. Chem. Soc._ **_141_** , 15641–15648 (2019). 

30 

35 

40 

13. J. A. Steele, H. Jin, I. Dovgaliuk, R. F. Berger, T. Braeckevelt, H. Yuan, C. Martin, E. Solano, K. Lejaeghere, S. M. J. Rogge, C. Notebaert, W. Vandezande, K. P. F. Janssen, B. Goderis, E. Debroye, Y.-K. Wang, Y. Dong, D. Ma, M. Saidaminov, H. Tan, Z. Lu, V. Dyadkin, D. Chernyshov, V. Van Speybroeck, E. H. Sargent, J. Hofkens, M. B. J. Roeffaers, Thermal unequilibrium of strained black CsPbI3 thin films. _Science_ . **_365_** , 679–684 (2019). 

14. N. J. L. K. Davis, F. J. de la Peña, M. Tabachnyk, J. M. Richter, R. D. Lamboll, E. P. Booker, F. Wisnivesky Rocca Rivarola, J. T. Griffiths, C. Ducati, S. M. Menke, F. Deschler, N. C. Greenham, Photon reabsorption in mixed CsPbCl3:CsPbI3 perovskite nanocrystal films for light-emitting diodes. _J. Phys. Chem. C_ . **_121_** , 3790–3796 (2017). 

15. K. M. Boopathi, B. Martín-García, A. Ray, J. M. Pina, S. Marras, M. I. Saidaminov, F. Bonaccorso, F. Di Stasio, E. H. Sargent, L. Manna, A. L. Abdelhady, Permanent lattice compression of lead-halide perovskite for persistently enhanced optoelectronic properties. _ACS Energy Lett._ **_5_** , 642–649 (2020). 

6 

Submitted Manuscript: Confidential Template revised February 2021 

16. A. Marronnier, G. Roma, S. Boyer-Richard, L. Pedesseau, J.-M. Jancu, Y. Bonnassieux, C. Katan, C. C. Stoumpos, M. G. Kanatzidis, J. Even, Anharmonicity and disorder in the black phases of cesium lead iodide used for stable inorganic perovskite solar cells. _ACS Nano_ . **_12_** , 3477–3486 (2018). 

5 

17. Y. Dai, P. Lu, Z. Cao, C. T. Campbell, Y. Xia, The physical chemistry and materials science behind sinter-resistant catalysts. _Chem. Soc. Rev._ **_47_** , 4314–4331 (2018). 

18. R. M. German, P. Suri, S. J. Park, Review: liquid phase sintering. _J. Mater. Sci._ **_44_** , 1–39 (2009). 

10 

19. Y. Wang, G. Chen, D. Ouyang, X. He, C. Li, R. Ma, W. Yin, W. C. H. Choy, High phase stability in CsPbI3 enabled by Pb–I octahedra anchors for efficient inorganic perovskite photovoltaics. _Adv. Mater._ , **_32_** ,2000186 (2020). 

20. B. Zhao, S.-F. Jin, S. Huang, N. Liu, J.-Y. Ma, D.-J. Xue, Q. Han, J. Ding, Q.-Q. Ge, Y. Feng, J.-S. Hu, Thermodynamically stable orthorhombic γ-CsPbI3 thin films for highperformance photovoltaics. _J. Am. Chem. Soc._ **_140_** , 11716–11725 (2018). 

15 

20 

21. A. Karmakar, M. S. Dodd, X. Zhang, M. S. Oakley, M. Klobukowski, V. K. Michaelis, Mechanochemical synthesis of 0D and 3D cesium lead mixed halide perovskites. _Chem. Commun._ **_55_** , 5079–5082 (2019). 

22. R. Wang, J. Xue, K.-L. Wang, Z.-K. Wang, Y. Luo, D. Fenning, G. Xu, S. Nuryyeva, T. Huang, Y. Zhao, J. L. Yang, J. Zhu, M. Wang, S. Tan, I. Yavuz, K. N. Houk, Y. Yang, Constructive molecular configurations for surface-defect passivation of perovskite photovoltaics. _Science_ . **_366_** , 1509–1513 (2019). 

23. S. Bai, P. Da, C. Li, Z. Wang, Z. Yuan, F. Fu, M. Kawecki, X. Liu, N. Sakai, J. T.-W. Wang, S. Huettner, S. Buecheler, M. Fahlman, F. Gao, H. J. Snaith, Planar perovskite solar cells with long-term stability using ionic liquid additives. _Nature_ . **_571_** , 245–250 (2019). 

25 

30 

24. A. Marronnier, H. Lee, B. Geffroy, J. Even, Y. Bonnassieux, G. Roma, Structural instabilities related to highly anharmonic phonons in halide perovskites. _J. Phys. Chem. Lett._ **_8_** , 2659–2665 (2017). 

25. M. Grechko, S. A. Bretschneider, L. Vietze, H. Kim, M. Bonn, Vibrational coupling between organic and inorganic sublattices of hybrid perovskites. _Angew. Chem. Int. Ed._ **_57_** , 13657–13661 (2018). 

26. B. Wang, N. Novendra, A. Navrotsky, Energetics, structures, and phase transitions of cubic and orthorhombic cesium lead iodide (CsPbI3) polymorphs. _J. Am. Chem. Soc._ **_141_** , 14501–14504 (2019). 

35 

40 

27. O. Panova, X. C. Chen, K. C. Bustillo, C. Ophus, M. P. Bhatt, N. Balsara, A. M. Minor, Orientation mapping of semicrystalline polymers using scanning electron nanobeam diffraction. _Micron_ . **_88_** , 30–36 (2016). 

28. J. T. Griffiths, F. W. Rocca Rivarola, N. J. L. K. Davis, R. Ahumada-Lazo, J. A. Alanis, P. Parkinson, D. J. Binks, W. Y. Fu, F. De La Pena, M. B. Price, A. Howkins, I. Boyd, C. J. Humphreys, N. C. Greenham, C. Ducati, Effect of size on the luminescent efficiency of perovskite nanocrystals. _ACS Appl. Energy Mater._ **_2_** , 6998–7004 (2019). 

7 

Submitted Manuscript: Confidential Template revised February 2021 

29. M. F. Thorne, M. L. R. Gómez, A. M. Bumstead, S. Li, T. D. Bennett, Mechanochemical synthesis of mixed metal, mixed linker, glass-forming metal–organic frameworks. _Green Chem._ **_22_** , 2505–2512 (2020). 

5 

30. R. Lin, J. Hou, M. Li, Z. Wang, L. Ge, S. Li, S. Smart, Z. Zhu, T. D. Bennett, V. Chen, Interfacial engineering of a polymer–MOF composite by _in situ_ vitrification. _Chem. Commun._ **_56_** , 3609–3612 (2020). 

31. I. Bressler, B. R. Pauw, A. F. Thünemann, _McSAS_ : software for the retrieval of model parameter distributions from scattering patterns. _J. Appl. Crystallogr._ **_48_** , 962–969 (2015). 

10 

15 

20 

25 

32. D. N. Johnstone, P. Crout, Joonatan Laulainen, S. Høgås, B. Martineau, T. Bergh, S. Smeets, S. Collins, Jędrzej Morzy, H. Ånes, E. Prestat, Tiarnan Doherty, T. Ostasevicius, M. Danaie, R. Tovey, _pyxem/pyxem: pyxem 0.10.0_ (Zenodo, 2019; https://zenodo.org/record/3533653). 

33. F. de la Pena, T. Ostasevicius, V. Tonaas Fauske, P. Burdet, P. Jokubauskas, M. Nord, M. Sarahan, E. Prestat, D. N. Johnstone, J. Taillon, Jan Caron, T. Furnival, K. E. MacArthur, A. Eljarrat, S. Mazzucco, V. Migunov, T. Aarholt, M. Walls, F. Winkler, G. Donval, B. Martineau, A. Garmannslund, L.-F. Zagonel, I. Iyengar, Electron Microscopy (Big and Small) Data Analysis With the Open Source Software Package HyperSpy. _Microsc. Microanal._ **_23_** , 214–215 (2017). 

34. F. D. L. Peña, E. Prestat, V. T. Fauske, P. Burdet, P. Jokubauskas, M. Nord, T. Ostasevicius, K. E. MacArthur, M. Sarahan, D. N. Johnstone, J. Taillon, J. Lähnemann, V. Migunov, A. Eljarrat, J. Caron, T. Aarholt, S. Mazzucco, M. Walls, T. Slater, F. Winkler, Pquinn-Dls, B. Martineau, G. Donval, R. McLeod, E. R. Hoglund, I. Alxneit, D. Lundeby, T. Henninen, Luiz Fernando Zagonel, A. Garmannslund, _hyperspy/hyperspy: HyperSpy v1.5.2_ (Zenodo, 2019; https://zenodo.org/record/3396791). 

35. D. N. Johnstone, F. C. N. Firth, C. P. Grey, P. A. Midgley, M. J. Cliffe, S. M. Collins, direct imaging of correlated defect nanodomains in a metal–organic framework. _J. Am. Chem. Soc._ **_142_** , 13081– 13089 (2020). 

36. A. Chambolle, T. Pock, A first-order primal-dual algorithm for convex problems with applications to imaging. _J. Math. Imaging Vis._ **_40_** , 120–145 (2011). 

30 

37. T. Goldstein, M. Li, X. Yuan, E. Esser, B. Richard, Adaptive primal-dual hybrid gradient methods for saddle-point problems. http://arxiv.org/abs/1305.0546v1 (2013). 

38. W. van Aarle, W. J. Palenstijn, J. De Beenhouwer, T. Altantzis, S. Bals, K. J. Batenburg, J. Sijbers, The ASTRA toolbox: a platform for advanced algorithm development in electron tomography. _Ultramicroscopy_ . **_157_** , 35–47 (2015). 

35 

40 

39. F. Oviedo, Z. Ren, S. Sun, C. Settens, Z. Liu, N. T. P. Hartono, S. Ramasamy, B. L. DeCost, S. I. P. Tian, G. Romano, A. Gilad Kusne, T. Buonassisi, Fast and interpretable classification of small X-ray diffraction datasets using data augmentation and deep neural networks. _Npj Comput. Mater._ **_5_** , 60 (2019). 

40. R. J. Sutton, M. R. Filip, A. A. Haghighirad, N. Sakai, B. Wenger, F. Giustino, H. J. Snaith, Cubic or orthorhombic? Revealing the crystal structure of metastable black-phase CsPbI3 by theory and experiment. _ACS Energy Lett._ **_3_** , 1787–1794 (2018). 

8 

Submitted Manuscript: Confidential Template revised February 2021 

41. G. Brunetti, D. Robert, P. Bayle-Guillemaud, J. L. Rouvière, E. F. Rauch, J. F. Martin, J. F. Colin, F. Bertin, C. Cayron, Confirmation of the domino-cascade model by LiFePO4 /FePO4 precession electron diffraction. _Chem. Mater._ **_23_** , 4515–4524 (2011). 

5 

42. E. F. Rauch, J. Portillo, S. Nicolopoulos, D. Bultreys, S. Rouvimov, P. Moeck, Automated nanocrystal orientation and phase mapping in the transmission electron microscope on the basis of precession electron diffraction. _Z. Für Krist._ **225** , 103-109 (2010). 

43. D. N. Johnstone, P. Crout, S. Høgås, T. Bergh, M. Danaie, C. Francis, S. Smeets, D. Weber, _pyxem/pyxem-demos: pyxem-demos 0.11.0_ (Zenodo, 2020; https://zenodo.org/record/3831456). 

10 

15 

20 

25 

44. S. van der Walt, S. C. Colbert, G. Varoquaux, The NumPy array: a structure for efficient numerical computation. _Comput. Sci. Eng._ **_13_** , 22–30 (2011). 

45. M. J. Frisch and G. W. Trucks and H. B. Schlegel and G. E. Scuseria and M. A. Robb and J. R. Cheeseman and G. Scalmani and V. Barone and G. A. Petersson and H. Nakatsuji and X. Li and M. Caricato and A. V. Marenich and J. Bloino and B. G. Janesko and R. Gomperts and B. Mennucci and H. P. Hratchian and J. V. Ortiz and A. F. Izmaylov and J. L. Sonnenberg and D. Williams-Young and F. Ding and F. Lipparini and F. Egidi and J. Goings and B. Peng and A. Petrone and T. Henderson and D. Ranasinghe and V. G. Zakrzewski and J. Gao and N. Rega and G. Zheng and W. Liang and M. Hada and M. Ehara and K. Toyota and R. Fukuda and J. Hasegawa and M. Ishida and T. Nakajima and Y. Honda and O. Kitao and H. Nakai and T. Vreven and K. Throssell and Montgomery, {Jr.}, J. A. and J. E. Peralta and F. Ogliaro and M. J. Bearpark and J. J. Heyd and E. N. Brothers and K. N. Kudin and V. N. Staroverov and T. A. Keith and R. Kobayashi and J. Normand and K. Raghavachari and A. P. Rendell and J. C. Burant and S. S. Iyengar and J. Tomasi and M. Cossi and J. M. Millam and M. Klene and C. Adamo and R. Cammi and J. W. Ochterski and R. L. Martin and K. Morokuma and O. Farkas and J. B. Foresman and D. J. Fox, _Gaussian 16 Revision C.01_ (Gaussian, Inc., Wallingford CT, 2016). 

46. P. J. Stephens, F. J. Devlin, C. F. Chabalowski, M. J. Frisch, Ab Initio calculation of vibrational absorption and circular dichroism spectra using density functional force fields. _J. Phys. Chem._ **_98_** , 11623–11627 (1994). 

30 

47. T. Clark, J. Chandrasekhar, G. W. Spitznagel, P. V. R. Schleyer, Efficient diffuse function-augmented basis sets for anion calculations. III. The 3-21+G basis set for first-row elements, Li-F. _J. Comput. Chem._ **_4_** , 294–301 (1983). 

48. F. Weigend, R. Ahlrichs, Balanced basis sets of split valence, triple zeta valence and quadruple zeta valence quality for H to Rn: Design and assessment of accuracy. _Phys. Chem. Chem. Phys._ **_7_** , 3297 (2005). 

35 

40 

49. C. La-o-vorakiat, H. Xia, J. Kadro, T. Salim, D. Zhao, T. Ahmed, Y. M. Lam, J.-X. Zhu, R. A. Marcus, M.-E. Michel-Beyerle, E. E. M. Chia, Phonon mode transformation across the orthohombic–tetragonal phase transition in a lead iodide perovskite CH3NH3PbI3: A terahertz time-domain spectroscopy approach. _J. Phys. Chem. Lett._ **_7_** , 1–6 (2016). 

50. C. Chen, D. Li, Y. Wu, C. Chen, Z.-G. Zhu, W. Y. Shih, W.-H. Shih, Flexible inorganic CsPbI3 perovskite nanocrystal-PMMA composite films with enhanced stability in air and water for white light-emitting diodes. _Nanotechnology_ . **_31_** , 225602 (2020). 

51. J. Xu, Y. Wu, Z. Li, X. Liu, G. Cao, J. Yao, Resistive switching in nonperovskite-phase CsPbI3 film-based memory devices. _ACS Appl. Mater. Interfaces_ . **_12_** , 9409–9420 (2020). 

9 

Submitted Manuscript: Confidential Template revised February 2021 

52. U. Bansode, A. Rahman, S. Ogale, Low-temperature processing of optimally polymerwrapped α-CsPbI3 for self-powered flexible photo-detector application. _J. Mater. Chem. C_ . **_7_** , 6986–6996 (2019). 

5 

10 

53. T. Xuan, J. Huang, H. Liu, S. Lou, L. Cao, W. Gan, R.-S. Liu, J. Wang, Superhydrophobic cesium lead halide perovskite quantum dot-polymer composites with high stability and luminescent efficiency for wide color gamut white light-emitting diodes. _Chem. Mater._ **_31_** , 1042–1047 (2019). 

54. J.-Y. Sun, F. T. Rabouw, X.-F. Yang, X.-Y. Huang, X.-P. Jing, S. Ye, Q.-Y. Zhang, Facile two-step synthesis of all-inorganic perovskite CsPbX3 (X = Cl, Br, and I) zeolite-Y composite phosphors for potential backlight display application. _Adv. Funct. Mater._ **_27_** , 1704371 (2017). 

55. S. Ma, S. H. Kim, B. Jeong, H. Kwon, S. Yun, G. Jang, H. Yang, C. Park, D. Lee, J. Moon, Strain‐mediated phase stabilization: a new strategy for ultrastable α‐CsPbI3 perovskite by nanoconfined growth. _Small_ . **_15_** , 1900219 (2019). 

15 

20 

56. F.-Y. Jia, L.-D. Sun, H. Dong, L. Huang, L.-G. Wang, L.-D. Li, Y. Jung, L. Zhou, C.-H. Yan, Improvement in the stability of γ-CsPbI 3 nanowires enabled by lattice immobilization through the Pb–O anchor in SBA-15. _Inorg. Chem. Front._ **_7_** , 4572–4579 (2020). 

57. Z. Zhang, L. Shen, Y. Zhao, Y. Zhang, H. Yang, W. Xiang, X. Liang, G. Chen, H. Yu, Coexisting CsPbCl3:CsPbI3 perovskite nanocrystal glasses with high luminescence and stability. _Chem. Eng. J._ **_385_** , 123415 (2020). 

58. Y. Zhao, C. Xie, X. Zhang, P. Yang, CsPbX3 quantum dots embedded in zeolitic imidazolate framework-8 microparticles for bright white light-emitting devices. _ACS Appl. Nano Mater._ **_4_** , 5478–5485 (2021). 

25 

59. Z. Zhang, L. Li, L. Liu, X. Xiao, H. Huang, J. Xu, Water-stable and photoelectrochemically active CsPbBr3/polyaniline composite by a photocatalytic polymerization process. _J. Phys. Chem. C_ . **_124_** , 22228–22234 (2020). 

60. J.-F. Liao, Y.-F. Xu, X.-D. Wang, H.-Y. Chen, D.-B. Kuang, CsPbBr3 nanocrystal/MO2 (M = Si, Ti, Sn) composites: insight into charge-carrier dynamics and photoelectrochemical applications. _ACS Appl. Mater. Interfaces_ . **_10_** , 42301–42309 (2018). 

30 

35 

40 

61. Y. Li, Y. Lv, Z. Guo, L. Dong, J. Zheng, C. Chai, N. Chen, Y. Lu, C. Chen, One-step preparation of long-term stable and flexible CsPbBr3 perovskite quantum dots/ethylene vinyl acetate copolymer composite films for white light-emitting diodes. _ACS Appl. Mater. Interfaces_ . **_10_** , 15888–15894 (2018). 

## **Acknowledgments:** 

**Funding:** Australian Research Council (DE190100803, DE210100930, DP180103874, DE190101152, DP200101900,and FL190100139); Department of Industry, Innovation and Science (AISRF53765); University of Queensland (UQECR2057677); Australian Centre for Advanced Photovoltaics fellowship and Australian Renewable Energy Agency; Henry Royce Institute for a summer undergraduate internship; National Natural Science Foundation of China (51772326); RIKEN Information Systems and Cybersecurity (Project Q20266); Slovenian Research Agency (research core funding P1-0021); Ras al Khaimah Center for 

10 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

Advanced Materials; Royal Society and Leverhulme Trust for a University Research Fellowship (UF150021) and Philip Leverhulme Prize (2019); European Union’s Horizon 2020 research and innovation programme (823717–ESTEEM3); National Agency for Research future investment TEMPOS-CHROMATEM (ANR-10-EQPX-50). Part of this research was undertaken on the THz/Far-IR, SAXS and PD beamlines at the Australian Synchrotron, part of ANSTO (M15988 and M15433). The authors acknowledge the Centre for Microscopy and Microanalysis and the Australian National Fabrication Facility, the University of Queensland; the Leeds EPSRC Nanoscience and Nanotechnology Facility (LENNF); ESRF / ID31 beamline; and the Diamond Light Source for access and support in the use of the electron Physical Sciences Imaging Centre (MG21980, MG25140). We would like to acknowledge D. D'Alessandro and Y. Sun for discussion. 

## **Author contributions:** 

Conceptualization: JH, TDB 

Methodology: JH, PC, TW, SMC, ZW, TUS 

15 

Investigation: JH, AS, SCL, WT, EBN, AK, GM, RD, LHGT, DHN, MS’A, SMC, CB, XL, RL, SL, ML, IM, DA 

Funding acquisition: JH, SMC, GM, AKC, VC, LW, TDB 

Project administration: JH, SMC, LW 

Writing – original draft: JH, AKC, VC, LW, TDB 

20 

Writing – review & editing: all authors 

**Competing interests:** JH, VC and LW are inventors on a relevant patent submitted by The University of Queensland. 

25 

**Data and materials availability:** All data are available in the manuscript or the supplementary materials. Additional data are available upon request to the corresponding authors. 

## **Supplementary Materials** 

30 

Materials and Methods Supplementary Text Figs. S1 to S47 Tables S1 to S3 References ( _30–61_ ) 

11 

Submitted Manuscript: Confidential Template revised February 2021 

5 



**Fig. 1. Fabrication of (CsPbI3)0.25(agZIF-62)0.75 composites at various sintering temperatures.** (A) Phase transition of CsPbI3 in its pure phase and within the composites. (B) Ex situ room-temperature synchrotron powder XRD for (CsPbI3)(agZIF-62)(25/75) (marked as Mixture) and (CsPbI3)0.25(agZIF-62)0.75 composites fabricated with different sintering temperatures. (C) PL spectra and (D) Ultraviolet-visible (UV-Vis) absorption spectra for (CsPbI3)0.25(agZIF-62)0.75 composites fabricated at different sintering temperatures. Arrows mark two band edges attributed to δ- and γ-CsPbI3 observed for the sample prepared at 175°C. 

12 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 



**Fig. 2. Structure and bonding evolution during sintering.** (A) Temperature-resolved, highresolution in situ synchrotron powder XRD for (CsPbI3)(agZIF-62)(25/75), with the Bragg peak _hkl_ indices marked for different CsPbI3 phases. The dominating phases are color-coded as: δ (yellow), α (red), β (blue) and γ (gray). (B) Average sizes of α-CsPbI3 deconvoluted from in situ powder XRD. (C) CsPbI3 particle-size evolution during sintering fitted from in situ SAXS patterns. (D) Temperature-resolved 2<sup>nd</sup> derivative in situ THz FarIR spectra for (CsPbI3)(agZIF62)(25/75) during the first heating ramp. (E)<sup>133</sup> Cs MAS NMR spectra of (CsPbI3)(agZIF62)(25/75) and 275°C sintered (CsPbI3)0.25(agZIF-62)0.75. (* denote spinning sidebands and † denotes the weak signal of CsI). 

13 

Submitted Manuscript: Confidential Template revised February 2021 

5 



**Fig. 3. Phase distribution for the (CsPbI3)0.25(agZIF-62)0.75 composite fabricated with 300°C sintering.** (A) ADF-STEM image, (B) SED-STEM mapping and (C) CsPbI3 crystal phase classification results for (CsPbI3)0.25(agZIF-62)0.75 composite. (D) Volume rendering of a tomographic reconstruction of (CsPbI3)0.25(agZIF-62)0.75 and a single cross-sectional plane extracted from the volume. Color-coded arrows highlight the regions where selected area electron diffraction data were collected. Scale bars in (A to D) are 250 nm. (E) CL-STEM mapping of the integrated CL intensity. The scale bar is 70 nm. (F) CL spectra acquired at each STEM probe position, and the sum CL spectrum of the whole region in (E). 

14 

Submitted Manuscript: Confidential Template revised February 2021 

5 



**Fig. 4. Stability and optical performance of the composites.** (A) Change of the relative PL intensity for (CsPbI3)0.25(agZIF-62)0.75 immersed in the Milli-Q water. Sample was sintered at 300°C. (B) Normalized PL intensities of the (CsPbX3)0.25(agZIF-62)0.75 composites (X=Cl, Br, I and mixed halide ions). (C-D) Optical photos of the composites and pure CsPbX3 under 365 nm UV light. Composites for (B-D) were sintered at 275°C. Scale bar in (D) is 1 cm. 

15 

