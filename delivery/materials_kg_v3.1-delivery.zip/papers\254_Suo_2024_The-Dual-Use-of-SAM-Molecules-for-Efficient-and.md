# The Dual Use of SAM Molecules for Efficient and Stable Perovskite Solar Cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Advanced Energy Materials |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 212 |
| 作者 | Jia-Jia Suo, Bo-Wen Yang, Dmitry Bogachuk, G. Boschloo, A. Hagfeldt |
| DOI | 10.1002/aenm.202400205 |
| 源文件 | 041_Suo_2024_The-Dual-Use-of-SAM-Molecules-for-Efficient-and.pdf |

---
**REVIEW** 

**www.advenergymat.de** 





# **The Dual Use of SAM Molecules for Efficient and Stable Perovskite Solar Cells** 

_Jiajia Suo, Bowen Yang,* Dmitry Bogachuk, Gerrit Boschloo, and Anders Hagfeldt*_ 

layer,<sup>[5,6]</sup> perovskite composition,<sup>[7–9]</sup> additives in the bulk,<sup>[10,11]</sup> and interfacial modulators,<sup>[12–20]</sup> have proven effective in improving the performance of PSCs. Among them, self-assembled monolayer (SAM) molecules have recently garnered significant attention for their potential to address these challenges by optimizing charge transfer progress and enhancing interfacial properties in PSCs. 

**Perovskite solar cells (PSCs) hold significant promise as the next-generation materials in photovoltaic markets, owing to their ability to achieve impressive power conversion efficiencies, streamlined fabrication processes, cost-effective manufacturing, and numerous other advantages. The utilization of self-assembled monolayer (SAM) molecules has proven to be a significant success in enhancing device efficiency and extending device stability. This review highlights the dual use of SAM molecules in the realm of PSCs, which can not only serve as charge transport materials but also act as interfacial modulators. These research endeavors encompass a wide range of applications for various SAM molecules in both n-i-p and p-i-n structured PSCs, providing a deep insight into the underlying mechanisms. Furthermore, this review proposes current research challenges for future investigations into SAM materials. This timely and thorough review seeks to provide direction and inspiration for current research efforts dedicated to the ongoing incorporation of SAMs in the field of perovskite photovoltaics.** 

In this review, we aim to provide a timely and comprehensive overview of the pivotal role played by SAM molecules in advancing the properties of PSCs. We summarized the dual use of SAM molecules in the realm of PSCs, shedding light on their multifunctionality in improving both efficiency and stability. First, we introduced the key components of SAM molecules and explored their diverse deposition methods. Subsequently, we delved into the different roles that SAM molecules fill in PSCs. Moreover, we underlined their use as charge-selective materials and interfacial modulators in PSCs. In conclusion, we summarize key findings and highlight the need for continued investigation and a deeper understanding of SAM molecules within the field of perovskite research activities. 

## **1. Introduction** 

In the ever-evolving landscape of renewable energy technologies, perovskite solar cells (PSCs) have emerged as promising contenders for efficient and cost-effective photovoltaic devices. The remarkable progress in PSCs comes with their set of challenges, particularly in achieving both efficiency and stability concurrently.<sup>[1–4]</sup> Advancements in material development across various components of a PSC, encompassing the charge selective 

### **1.1. Definition of SAMs** 

J. Suo, B. Yang, G. Boschloo, A. Hagfeldt Department of Chemistry – Ångström Laboratory Uppsala University Uppsala SE-75120, Sweden E-mail: bowen.yang@kemi.uu.se; anders.hagfeldt@uu.se D.Bogachuk Solarlab Aiko EuropeGmbH 79110 Freiburg,Germany A.Hagfeldt SKKU Instituteof Energy ScienceandTechnology (SIEST) Sungkyunkwan University Suwon 440-746, South Korea 

The ORCID identification number(s) for the author(s) of this article can be found under https://doi.org/10.1002/aenm.202400205 

© 2024 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH. This is an open access article under the terms of the Creative Commons Attribution License, which permits use, distribution and reproduction in any medium, provided the original work is properly cited. 

### **DOI: 10.1002/aenm.202400205** 

SAMs in PSCs are characterized as consisting of one or a few layers of organic molecules that spontaneously anchor to the surface of a solid substrate. Due to the thermodynamically favorable selfassembly process, SAM molecules predominately align vertically on the substrate surface. The molecular structure of SAMs typically comprises three components: an anchoring group, a linker group, and a terminal group, as shown in **Figure 1** .<sup>[4,21]</sup> 

### _1.1.1. Anchoring Group_ 

The anchoring groups of SAM molecules play a pivotal role in reacting with the metal oxide and chemically attaching it to the substrate surface. Different anchoring groups (─COOH, ─PO(OH)2, ─OH, ─SiR2OH, etc.) have been developed to adsorb to the substrate through distinct types of interactions, which mainly react with surface ─OH groups and coordinate with metal atoms of the substrates, exhibiting diverse binding energies. These offer a range of choices for their application to various metal oxides 

**2400205 (1 of 17)** 

_Adv. Energy Mater._ **2025** , _15_ , 2400205 

© 2024 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



**Figure 1.** The general structure of SAM molecules in perovskite solar cells. 

and other substrates (such as indium tin oxide (ITO), fluorinedoped tin oxide (FTO), NiOx, TiO2, SnO2, etc.). Furthermore, the anchoring process significantly influences the molecular orientation with respect to the surface normal, as well as the substrate’s contact resistance and work function (WF). These factors are crucial for the anchoring arrangement on the substrate surface, interfacial charge transfer properties, and overall device performance. 

### _1.1.2. Linker Group_ 

The linker group within SAMs serves as the molecular backbone connecting the anchoring group and terminal group. Two prevalent types of linker units are employed: alkyl chains (nonconjugated) and aromatic groups (conjugated), each demonstrating distinct charge transport rates. Meanwhile, the composition of linker groups can exert influence over intermolecular interactions, including the self-assemble process and ultimate packing structure. Additionally, the structure of these linker groups plays a crucial role in electronic separation, barrier properties, molecular solubility, and other properties. Moreover, the variation of linker groups helps to regulate the molecular structure as well as the function of the entire SAM molecule. 

### _1.1.3. Terminal Group_ 

The terminal group within SAMs determines the material’s functionalities, surface properties, as well as interaction with the overlayer and the surrounding atmosphere. Through the utilization of organic synthetic chemistry, an array of functional groups and diverse atoms (O, N, S, I, Br, Cl) can be introduced. These entities possess the potential to establish robust interactions with materials like perovskite and other upper layers, thereby exerting an influence on their formation process and morphology. Moreover, these interactions could modify the surface WF and delicately adjust the energy levels, thereby enhancing the charge extraction and suppressing interfacial carrier recombination. Apart from the interfacial modification, the utilization of compounds, such as carbazole and triphenylamine can improve the chargeselective properties of SAM molecules, making them serve as charge transport materials in PSCs. 



**www.advenergymat.de** 

### **1.2. Deposition of SAM Molecules** 

SAMs can be processed to the substrates via various deposition techniques, mainly including exposing them to the SAMs vapor-saturated environment, deposition of SAM solution, thermal evaporation of SAMs, and incorporating SAMs into perovskite solution, as illustrated in **Figure 2** . 

### _1.2.1. Vapor Processing_ 

Volatile SAM compounds can be suitable for use with the vapor processing method. The self-assembled monolayer will be formed by exposing the substrate to an atmosphere saturated with those SAM molecules.<sup>[22]</sup> Subsequent annealing is necessary to enhance the bonding with the substrate, aiming to remove the excess unbound molecules from the layer.<sup>[23]</sup> 

### _1.2.2. Solution Processing_ 

The solution processing technique is the most commonly applied method to deposit SAMs, which consists of dip-coating, spincoating, and spray-coating. 

SAMs formed by dip-coating are normally prepared by immersing the substrate into the SAM solution where the molecule chemically adsorbs, followed by annealing and subsequent washing steps.<sup>[24–27]</sup> The adsorption can be regulated by modulating the solvent, concentration, and dipping time.<sup>[23]</sup> The solvent washing is employed to eliminate the residual SAM molecules that are weakly bonded to the substrate. However, the necessity of long immersing time and the use of toxic organic solvents are the main disadvantages of utilizing the dip-coating technique. In contrast, spin-coating is a fast and simple process to produce uniform SAMs by dispensing the SAM molecules on the substrate at a certain speed, followed by thermal treatment, whereas a solvent-washing step is not always necessary.<sup>[23,26]</sup> Other scalable solution processing techniques have also been reported such as ultrasonic spray coating and air-brush coating. Spray-coating is a sophisticated technique that typically demands precise control of parameter space to achieve high-quality layers. In contrast, Cassella et al. reported that air-brush coating offers a more straightforward and broadly accessible approach, making it particularly well-suited for depositing SAM layers.<sup>[28]</sup> They sprayed or airbrushed the SAM molecules onto the substrates, followed by drying with N2 and subsequent annealing. Afterward, the substrates were rinsed with solvent to remove the excessive molecules. 

It is worth noticing that for all the above-mentioned solution processing techniques, researchers have commonly described the removal of excess SAM molecules through rinsing, washing, or sonicating in solvents. These rinsing procedures are generally carried out after thermal annealing, as they lead to the formation of stronger covalent bonds, attaching the monolayer materials firmly to the surface.<sup>[28]</sup> 

### _1.2.3. Evaporation_ 

Farag et al. recently explored, for the first time, the utilization of physical vapor deposition (PVD) through thermal evaporation 

**2400205 (2 of 17)** 

_Adv. Energy Mater._ **2025** , _15_ , 2400205 

© 2024 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 





### **www.advenergymat.de** 



**Figure 2.** SAMs deposition methods: a) vapor processing – exposing in the SAM vapor environment, b) solution processing – depositing a wet film of dissolved SAM, c) evaporation – thermal evaporation of SAMs, and d) incorporation into perovskite solution – mixing SAMs into the perovskite precursor solution. 

of high-quality SAM hole transport layers and incorporation in PSCs. These devices exhibited comparable performance to their solution-processed counterparts.<sup>[29]</sup> Such development is crucial in commercial PV production lines, where vacuum-based deposition techniques are predominantly employed, making the integration of vacuum-based methods into large-scale perovskite production feasible. Moreover, evaporation enables the application of consistent and uniform coatings, even on textured surfaces, thereby enhancing process yield and reproducibility. This provides immense potential for the homogeneous deposition of complete PSCs with SAMs on textured surfaces to produce fullytextured perovskite/silicon tandem solar cells which are compatible with the pyramidal surface of the silicon solar cells common in the PV industry. 

### _1.2.4. Incorporation into Perovskite Solution_ 

Because of the robust interaction between anchoring groups and metal oxide substrates, SAMs can be deposited by incorporating SAM molecules into the perovskite precursor solution. This allows the formation of a compact SAM layer on the metal oxide surface during perovskite film processing. The codeposition process not only simplifies the manufacturing process but also passivates the perovskite films to further enhance device performance.<sup>[30,31]</sup> 

### **1.3. Roles of SAMs in PSCs** 

As previously mentioned, self-assembled monolayers in PSCs are defined by the presence of one or a few layers of organic molecules anchoring to the substrates. In comparison with other materials, the use of such thin layers substantially reduces the quantity of materials required, thereby lowering manufacturing costs. Additionally, the incorporation of monolayer-thickness SAMs results in minimal absorption in visible light, causing negligible optical losses compared to substrates without SAM treatment.<sup>[32]</sup> Furthermore, utilizing SAMs contributes to the improvement of solar cell performance and stability, which is mainly achieved by modifying the surface energy level, reducing interfacial defects, enhancing the quality of perovskite films, and preventing device degradation. 

### _1.3.1. Energy-Level Alignment_ 

Ensuring a suitable energy alignment between charge transport and perovskite layers is crucial for facilitating efficient charge extraction. The introduction of SAMs on the substrate surface initiates interfacial charge redistribution, resulting in a modification of the work function. The changes in WF (Δ _𝜑_ ) can be assessed using the following equation<sup>[33]</sup> : 



<!-- Start of picture text -->
Δ 𝜑 = − N + 𝜇 M−S (1)<br>[  𝜇𝜀 0 ⊥k SAMSAM 𝜀 0 k M−S ]<br><!-- End of picture text -->

where _N_ is the adsorbate grafting density, ɛ0 is the permittivity of free space and _k_ is the dielectric constant of adsorbate. Due to _μ_ M−S/ɛ _0k_ M−S being closely related to the nature of the substrate, the WF shift (Δ _𝜑_ ) is primarily dependent on the dipole moment of the SAM to the surface (μ⊥SAM). Utilizing SAM-dipoles to alter the interfacial WF directly influences the quasi-Fermi level splitting under excitation and consequently, device open-circuit voltage ( _V_ OC). Furthermore, this modification can expedite charge extraction and diminish energy losses during the charge transfer process, thereby enhancing device short-circuit current ( _J_ sc) and fill factor (FF), consequently improving the overall device performance. 

### _1.3.2. Interfacial Trap Density_ 

Diverse traps in PSCs predominantly exist at the interface and grain boundaries of perovskite films, contributing to nonradiative recombination, diminished carrier lifetime and density, and consequently, a decline in device performance.<sup>[34,35]</sup> The incorporation of SAMs at the interface serves to passivate crystal defects in both the substrate and perovskite films. For instance, various Lewis base terminal groups engage with uncoordinated Pb<sup>2+</sup> ions to mitigate defects.<sup>[36,37]</sup> Ammonium salts terminal groups interact with the [PbI6]<sup>4−</sup> structure to alleviate defects arising from A-site vacancies.<sup>[38]</sup> Additionally, hydrogen bonding has proven effective in reducing defects by stabilizing movable halide ions.<sup>[39]</sup> 

### _1.3.3. Crystallization of Perovskite Film_ 

Apart from modifying the WF, SAMs can also alter the wettability of the substrate surface, thereby influencing the growth process 

**2400205 (3 of 17)** 

_Adv. Energy Mater._ **2025** , _15_ , 2400205 

© 2024 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

and quality of the perovskite film. In general, the crystallization of the perovskite film involves two steps.<sup>[40]</sup> The initial phase encompasses perovskite nucleation, wherein perovskite seeds form on the substrate. Subsequently, throughout the drying and thermal annealing processes, interdiffusion of perovskite seeds takes place, facilitating the growth of perovskite grains through seed interactions. To enhance the grain size of the perovskite film, it is crucial to maintain a substantial distance between perovskite crystal seeds and ensure high grain boundary mobility. The introduction of SAM molecules can alleviate the dragging force between the substrate and perovskite solution, thereby promoting the formation of larger grains.<sup>[41]</sup> Simultaneously, enlarging the sizes of perovskite grains will result in a decrease in perovskite grain boundaries, effectively reducing the trap density within the perovskite film. 

### _1.3.4. Device Stability_ 

Enhancing the stability of PSCs is a pivotal challenge for their practical application. Given that defects contribute to the degradation of PSCs, the use of SAMs aids in reducing trap density at the interface and within the perovskite film, ultimately improving perovskite quality and device stability. Additionally, the anchoring groups can react with a metal oxide to diminish surface ─OH groups on the substrate, effectively suppressing perovskite decomposition. Furthermore, the introduction of SAM molecules prevents direct contact between perovskite film and substrate, such as poly(3,4-ethylenedioxythiophene) polystyrene sulfonate (PEDOT:PSS), whose acidic and hygroscopic properties may lead to the degradation of the perovskite film.<sup>[42]</sup> 

## **2. The Use of SAMs as Charge Selective Contacts in PSCs** 

### **2.1. SAM as Hole Transport Material** 

In inverted p-i-n structured perovskite solar cells, PEDOT:PSS, ploy(triaryl amine) (PTAA), and NiOx are the most commonly used hole transport materials (HTMs). However, these materials have drawbacks that hinder the further enhancement of device performance. Among them, hydrophilic PEDOT:PSS exhibits chemical instability after treatment with the perovskite precursor solution and demonstrates mismatched interfacial energy levels when compared with other HTMs.<sup>[43]</sup> On the other hand, hydrophobic PTAA introduces challenges due to its poor surface wettability upon exposure to the perovskite precursor solution.<sup>[44]</sup> Both factors contribute to the generation of electronic and compositional defects at the buried HTM/perovskite interface, amplifying nonradiative recombination and thus diminishing both device performance and stability.<sup>[45]</sup> In the case of NiOx HTMs, they exhibit low hole mobility and require additional doping or thermal treatment to enhance the film quality.<sup>[2]</sup> Additional interfacial treatment is crucial to mitigate interfacial defects arising from the interaction between nickel oxide and perovskite films.<sup>[46]</sup> Consequently, self-assembled monolayer HTMs offer a solution by enhancing surface wettability, improving perovskite film quality, and reducing interfacial defects. This demonstrates the potential to effectively tackle the challenges mentioned above.<sup>[47]</sup> 



### **www.advenergymat.de** 

### _2.1.1. Carbazole-Based SAMs and Alternatives_ 

Carbazole-based molecules, typically featuring carbazole derivative as terminal group, long carbon chain as linker group, and phosphonic acid as anchoring group, have emerged as the predominant self-assembled hole transport materials in inverted perovskite solar cells, as summarized in **Figure 3** . In their pioneering work, Magomedov et al. introduced a novel carbazole-based molecule, **V1036** ((2-{3,6-bis[bis(4methoxyphenyl)amino]−9H-carbazol-9-yl}ethyl)phosphonic acid), as a hole selective contact for the fabrication of inverted PSCs, achieving a remarkable peak PCE of 17.8% and an impressive average fill factor of 80%.<sup>[24]</sup> The SAM layer is established by immersing the ITO substrate into a **V1036** solution to facilitate binding interactions between ITO and the phosphonic anchoring groups of **V1036** . Subsequently, they simplified the structure of the **V1036** molecule to **2PACz** ([2-(9H-carbazol-9-yl)ethyl]phosphonic acid) and **MeO-2PACz** ([2-(3,6-dimethoxy-9H-carbazol-9-yl)ethyl]phosphonic acid), which exhibited reduced absorption in visible light compared to PTAA and **V1036** .<sup>[26]</sup> Additionally, these molecules can form a compact monolayer on the ITO surface through spin-coating with a low concentration. As a result, the utilization of SAMs establishes an energetically aligned interface with the perovskite absorber, reducing non-radiative losses and enhancing device performance to 21.1%. They further realized a certified efficiency of 23.26% for a monolithic copper indium gallium selenide (CIGSe)/perovskite tandem solar cell with a 1 cm<sup>2</sup> active area by integrating **MeO-2PACz** as HTM. Al-Ashouri et al. delved into the impact of various substituted functional groups (methoxy and methyl) on the carbazole structure and the aliphatic chain length (n) in carbazole-based SAM molecules, to scrutinize their influence on device performance.<sup>[48]</sup> Following a thorough comparison, it was observed that methyl substitution presented advantages in terms of both passivation and hole extraction with perovskite films. Notably, **2PACz** and **Me-4PACz** ([4-(3,6-dimethyl-9H-carbazol-9-yl)butyl]phosphonic acid) were identified to significantly enhanced hole extraction and device performance, particularly in terms of fill factor. Consequently, the incorporation of **Me-4PACz** as a holeselective layer substantially improved the FF of single-junction PSCs to an impressive 84% and realized a certified PCE exceeding 29% for monolithic perovskite/silicon tandem solar cells. 

In addition to the small molecules, the polymerization of carbazole phosphonic acids also has the potential to demonstrate remarkable hole extraction capacity and effective suppression of interfacial recombination, contributing to the stabilization of perovskite/HTM interfaces. Ren et al. introduced a polymeric hole transport material, **Poly-4PACz** (Poly(4-(9Hcarbazol-9-yl)butyl)phosphonic acid), for use in inverted perovskite solar cells.<sup>[49]</sup> This material exhibits high conductivity, making it less sensitive to variations in layer thickness and roughness on different transparent conductive oxide (TCO) substrates (ITO and FTO). Thus, it is highly suitable for the scalable coating of perovskite films. Consequently, blade-coated perovskite solar cells and modules achieved impressive PCEs of 24.4% and 20.7% at active areas of 6.84 mm<sup>2</sup> and 25.0 cm<sup>2</sup> , respectively. 

**2400205 (4 of 17)** 

_Adv. Energy Mater._ **2025** , _15_ , 2400205 

© 2024 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



### **www.advenergymat.de** 



**Figure 3.** The molecular structure of carbazole and other tricyclic aromatic compounds-based SAMs, the anchoring group is highlighted in blue, the linker group is highlighted in black, and the terminal group is highlighted in red. 

In addition, Jen’s group designed and utilized two novel SAM molecules, **CbzPh** ((4-(7Hbenzo[ _c_ ]carbazol7-yl)butyl)phosphonic acid) and **CbzNaph** ([4(7Hdibenzo[ _c,g_ ]carbazol-7-yl)butyl]phosphonic acid), as hole selective materials in inverted PSCs.<sup>[50]</sup> The increased molecular dipoles in **CbzPh** and **CbzNaph** effectively adjusted the WF of ITO, while the intensified _𝜋_ - _𝜋_ interactions promoted a more organized and compact SAM assembly. Notably, **CbzNaph** demonstrated exceptional hole extraction capabilities, leading to a remarkable enhancement in device performance to 24.1%, coupled with improved stability under diverse conditions. The same molecule has been utilized as a hole-selective layer in wide-bandgap PSCs.<sup>[51]</sup> The employment of **4PADCB** facilitates the subsequent growth of high-quality wide-bandgap perovskite over a large area, effectively suppressing interfacial non-radiative recombination and enabling efficient hole extraction. Consequently, a certified stabilized PCE of 26.4% was achieved in monolithic all-perovskite tandem solar cells with an aperture area of 1.044 cm<sup>2</sup> . Recently, the same group extended their de- 

sign efforts to incorporate a bromine-substituted SAM molecule, specifically **DCB-BPA** ((4-(5,9-dibromo-7 _H_ -dibenzo[ _c_ , _g_ ]carbazol7-yl)butyl)phosphonic acid), as hole selective materials for PSCs with a wide bandgap perovskite of 1.77 eV.<sup>[52]</sup> The integration of **DCB-BPA** established an energetically aligned interface and enhanced the quality of the wide bandgap perovskite film by reducing interfacial density, effectively mitigating losses from interfacial non-radiative recombination. As a result, an impressive certified PCE of 18.88% was attained, accompanied by an excellent _V_ oc of 1.339 V. In addition to expanding the conjugated structure of the carbazole framework, introducing other extended conjugated systems can also enhance hole extraction and mitigate non-radiative recombination by facilitating electron delocalization. To demonstrate this, Wang et al. incorporated two benzene rings into **2PACz** , resulting in **Ph-2PACz** (2-(3,6-diphenyl-9H-carbazol-9-yl)ethyl)phosphonic acid) as the hole-selective material in inverted PSCs.<sup>[53]</sup> They realized that the contorted structure in **Ph-2PACz** reduces _𝜋_ – _𝜋_ intermolecular interactions, promoting more uniform self-assembly. As a result, 

**2400205 (5 of 17)** 

_Adv. Energy Mater._ **2025** , _15_ , 2400205 

© 2024 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



**www.advenergymat.de** 



**Figure 4.** The molecular structure of the triarylamine-based SAMs, the anchoring group is highlighted in blue, the linker group is highlighted in black, and the terminal group is highlighted in red. 

the utilization of **Ph-2PACz** yielded a PCE of 21.3% in a 1.67 eV PSC and an impressive 28.9% efficiency in a perovskite/silicon tandem solar cell. Furthermore, the encapsulated **Ph-2PACz** tandem device exhibited enhanced stability against light, thermal, and moisture, compared to counterparts based on PTAA and **2PACz** . 

Similar to the carbazole structure, other tricyclic aromatic compounds, such as phenothiazine, show similar properties as self-assembled hole transport materials. Ullah et al. designed and utilized a series of tricyclic aromatic rings containing O, S, or Se, respectively, as hole selective materials.<sup>[54]</sup> Their investigation revealed that all these molecules formed an energetically well-aligned interface with the perovskite film. Notably, the Se-containing SAM, **Br-2EPSe** (2-(3,7-dibromo-10Hphenoselenazine-10-yl)ethyl)phosphonin acid), exhibited the strongest interaction with the perovskite film, effectively reducing defect density. Thus, inverted PSCs incorporating **Br-2EPSe** 

achieved an impressive PCE of 22.73% and maintained ≈96% of their initial performance after a maximum 500 h power point tracking test. 

### _2.1.2. Triarylamine-Based SAMs_ 

In general, materials based on triarylamine demonstrate excellent properties in terms of hole selective capability, such as Spiro-OMeTAD and PTAA. As listed in **Figure 4** , triarylamine compound-based SAMs have been used as high-performance HTMs in inverted PSCs. For example, Yalcin and colleagues introduced **TPA** (4,4″-bis(diphenyl amino)−1,1′:3′,1″-terphenyl5′-carboxylic acid) and **MC-43** (4′-[bis(2′,4′-dimethoxybiphenyl4-yl)amino]-biphenyl-4-carboxylic acid) as potential alternatives to the widely utilized PEDOT:PSS for hole-selective contacts in PSCs.<sup>[25]</sup> Their investigation revealed that larger 

**2400205 (6 of 17)** 

_Adv. Energy Mater._ **2025** , _15_ , 2400205 

© 2024 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advenergymat.de** 



**www.advancedsciencenews.com** 

conjugated structures exhibit improved charge transfer capabilities. Consequently, the device performance utilizing **MC-43** rose to 17.5%. Taking inspiration from commonly used dye molecules in dye-sensitized solar cells, Guo’s research team utilized donor-acceptor-type **MPA-BT-CA** (3-(7-(4-(bis(4methoxyphenyl)amino)phenyl)benzo[ _c_ ][1,2,5]thiadiazol-4-yl)−2cyanoacrylic acid) molecules for self-assembly, serving as hole transport agents.<sup>[55]</sup> The new molecule not only modulates the interfacial energy level but also effectively passivates interfacial defects. As a result, the intended device achieved an impressive 21.24% power conversion efficiency, alongside good long-term and thermal stability. Modulating the substitution functional group can fine-tune the energy level of organic molecules, thereby further enhancing device performance. Subsequent research by the team revealed that the incorporation of fluorine atoms effectively reduced the highest occupied molecular orbital (HOMO) levels within these donor-acceptor-type molecules.<sup>[56]</sup> This alteration contributed to the reduction of energy losses and an improvement in the open-circuit voltage of PSCs. Consequently, the utilization of **FMPA-BT-CA** (3-(7-(4-(bis(4-methoxyphenyl)amino)−2fluorophenyl)benzo[ _c_ ][1,2,5]thiadiazol-4-yl)−2-cyanoacrylic acid) resulted in an enhanced PCE of 22.37%. Similarly, Guo and co-workers reported two D-A selfassemble hole transport molecules, namely **PPA** ((7-(4-(diphenylamino)phenyl)benzo[ _c_ ][1,2,5]thiadiazol4-yl)phosphonic acid) and **PPAOMe** (7-(4-(bis(4methoxyphenyl)amino)phenyl)benzo[ _c_ ][1,2,5]thiadiazol-4yl)phosphonic acid), featuring phosphonic acid as anchoring groups.<sup>[57]</sup> Upon evaluating the donor groups, it was observed that **PPA** exhibited better energy alignment and excellent hole extraction capability. Therefore, the devices based on **PPA** achieved a champion PCE of 23.24% with excellent operational stability. Very recently, Wu’s group developed **MPA-CPA** ((2-(4(bis(4-methoxyphenyl)amino)phenyl)−1-cyanovinyl)phosphonic acid) as the self-assembled monolayer on top of the ITO substrate in the p-i-n PSCs.<sup>[47]</sup> The introduction of the cyanovinyl phosphonic acid (CPA) group induces the formation of a super wetting underlayer, resulting in a uniform perovskite film. Additionally, the organic molecules from the amphiphilic overlayer effectively passivate the defects in both the interfacial region and the perovskite bulk. As a result, a certified PCE of 25.4% was achieved, marking one of the highest reported PCEs for inverted PSCs. Apart from its application in single-junction PSCs, Zhu et al. employed a donor-acceptor-type compound, **MPA2FPh-BT-BA** (4-(7-(4-(bis(4-methoxyphenyl)amino)−2,5difluorophenyl)benzo[ _c_ ][1,2,5]thiadiazol-4-yl)benzoic acid), as HTM in all-perovskite tandem solar cells.<sup>[58]</sup> They discovered that this novel molecule effectively addressed interfacial defects, thereby reducing non-radiative recombination in the widebandgap cells. Furthermore, they found that the employment of the new molecule in narrow-bandgap cells could effectively regulate the perovskite crystallization process and enhance the quality of the Sn-Pb perovskite film. Consequently, the incorporation of SAMs in both layers resulted in a remarkable PCE of 27.22%, accompanied by improved operational stability. 

In addition to the widely employed carboxylic and phosphonic acid groups, boric acid, a mild acid, serves as an alternative anchoring group for SAMs-based HTMs. These compounds have 



been reported to swiftly interact with polyhydroxy compounds on the surface of an ITO substrate. Through the modification of the terminal group, Guo et al. employed **MTPA-BA** ((4-(di-ptolylamino)phenyl)boronic acid) as the hole selective layer due to its suitable energy level, achieving a champion PCE of 22.62% and an excellent FF of 85.2%.<sup>[59]</sup> Moreover, devices based on **MTPA-BA** exhibited better operational and shelf stability in comparison to those based on **2PACz** . 

### **2.2. SAM as Electron Transport Material** 

As mentioned above, SAM molecules have proven successful as HTMs in PSCs. Their potential application as electron transport materials (ETMs) has also been explored. In contrast to HTMs, the utilization of SAM as ETMs exhibits lower device performance when compared to established metal oxide substrates (such as TiO2 and SnO2) in the n-i-p structures, as summarized in **Figure 5** . Hou et al. proposed a fullerene-based **C60-SAM** as an ETM to replace TiO2.<sup>[60]</sup> The strong binding between the phosphonic acid anchoring group and the oxide surface of the substrate significantly reduced the hysteresis effect in n-i-p structured PSCs. A similar effect has been proved by Topolovsek et al. through the employment of a siloxane-functionalized C60 SAM, namely **SiI-C60** .<sup>[61]</sup> The self-assembly of the n-type ionic liquid, **BIPH-II** (1-([1,1′-biphenyl]−4-yl)−3-(2-hydroxyethyl)−1Himidazol-3-ium iodide), on the FTO substrate was observed to reduce the WF of the conductive substrate.<sup>[62]</sup> This, in turn, improved interfacial electron extraction and suppressed interfacial charge recombination, resulting in a significant enhancement in device performance from 9.0% to 17.3%. Naphthalene-imide derivatives exhibit good thermal stability and excellent electron mobility, showing their potential as SAM ETMs. Li et al. explored naphthalene-imide compound to adjust energy level, improving the PCE of devices employing **NDI-P** (3,3′-(1,3,6,8tetraoxo-1,3,6,8-tetrahydrobenzo[ _lmn_ ][3,8]phenanthroline-2,7diyl)dipropionic acid) to 16%.<sup>[63]</sup> Additionally, Fürer et al. introduced naphthalene-imide-based SAMs ( **NDI-2a, 2c, 3a** ) as a surface modification to enhance device thermal stability.<sup>[64]</sup> 

## **3. The Use of SAMs as Interfacial Modulators in PSCs** 

### **3.1. Interfacial Treatment Between Hole Transport Layer and Perovskite Layer** 

In p-i-n structured perovskite solar cells, PEDOT:PSS and NiOx are the commonly employed hole transport materials.<sup>[65,66]</sup> Due to their properties, such as chemical instability, low conductivity, and work function mismatch, various defects would be generated at the interface between the perovskite and hole transport materials, which limit both PCE and long-term stability of the device. To reduce the defects and enhance device performance, the implementation of SAMs at the buried HTM/perovskite interlayer is a frequently utilized approach. Regarding PEDOT:PSS, its acidic and hygroscopic nature can lead to the degradation of the perovskite film. Employing SAMs can prevent direct contact between PEDOT:PSS and the perovskite layer, thereby extending 

**2400205 (7 of 17)** 

_Adv. Energy Mater._ **2025** , _15_ , 2400205 

© 2024 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



### **www.advenergymat.de** 











**Figure 5.** The molecular structure of SAM electron transport materials, the anchoring group is highlighted in blue, the linker group is highlighted in black, and the terminal group is highlighted in red. 

the lifetime of PSCs. For example, Gu et al. introduced 3- aminopropanoic acid onto the PEDOT:PSS surface.<sup>[67]</sup> The employment of SAMs altered the perovskite crystallization process and enhanced the coverage of the perovskite film. As a result, this modification led to an improvement in device performance from 9.7% to 11.6%. Chen and the co-authors employed a bilayer consisting of a **2PACz** monolayer on PEDOT:PSS in high bandgap tin-based PSCs, as shown in **Figure 6** a.<sup>[42]</sup> They discovered synergistic effects in the bilayer, establishing an energetically aligned interface, reducing lattice disorder, and minimizing non-radiative recombination within the perovskite layer. Consequently, the incorporation of **2PACz** and PEDOT:PSS not only enhances the power conversion efficiency from 6.83% to 8.66%, but also significantly improves the device’s stability. 

Especially in the context of NiOx as HTMs in p-i-n cells, the utilization of SAMs for interfacial treatment can diminish inevitable surface defects and reduce the presence of hydroxyl groups. Furthermore, it establishes an energetically aligned interface, reducing energy loss during the hole transfer process and regulating perovskite crystallization to elevate film quality. Yang’s groups introduced a diethanolamine (DEA) monomolecular layer to crosslink the NiOx and perovskite films, aiming to reduce the interfacial defects and enhance both perovskite crystallinity and film quality.<sup>[68]</sup> Moreover, their finding revealed that the interfacial treatment with DEA creates an energetically aligned inter- 

face, improving hole extraction and charge transport rates, resulting in a notable enhancement of the device PCE from 11.5% to 15.9%. Na’s group reported similar functional SAMs by employing 3-(Triethoxysilyl)propylamine (TSPA) as the surface modifier for the nickel oxide layer.<sup>[69]</sup> Wang and colleagues utilized a range of benzoic acids as self-assembled monolayers to passivate defects at the interface between the NiOx and perovskite layer.<sup>[70]</sup> Their study unveiled that the use of 4-bromobenzoic acid (Br-BA) notably suppresses trap-assisted recombination, minimizes the energy offset between NiOx and perovskite, and simultaneously modifies the surface wettability of NiOx to improve the perovskite crystallization process. This resulted in achieving a champion PCE of 18.4% as well as enhanced device stability. Chen’s group developed a self-assembled layer based on p-chlorobenzenesulfonic acid (CBSA) to diminish interfacial defects, as shown in Figure 6b.<sup>[71]</sup> This was achieved by passivating surface oxygen defects in NiOx through sulfonic acid groups and filling iodine vacancy gaps in the lower perovskite layer using chlorine atoms. The incorporation of the CBSA interlayer additionally releases lattice strain in the bottom perovskite layer, effectively mitigating interfacial strain and impeding undesirable reactions at the NiOx-perovskite interface. Consequently, the photovoltaic cells treated with CBSA demonstrated an outstanding power conversion efficiency of 21.8%, accompanied by prolonged stability under varying conditions. Differing from the previously 

**2400205 (8 of 17)** 

_Adv. Energy Mater._ **2025** , _15_ , 2400205 

© 2024 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



### **www.advenergymat.de** 



**Figure 6.** a) Structure of /PEDOT:PSS/2PACz/perovskite. Reproduced with permission.<sup>[42]</sup> Copyright 2022, Elsevier. b) Schematic diagrams of lattice strain distribution in perovskite grains deposited on NiOx and NiOx/CBSA substrates. Reproduced with permission.<sup>[71]</sup> Copyright 2022, Wiley-VCH. c) Schematic of the device structure, the illustration of the bridge, the structures of the designed molecules (F-BA, Cl-BA, Br-BA, I-BA, and I-TFBA), and the corresponding electrostatic potentials. The color bar from red to blue represents the increase of the electropositivity. Reproduced with permission.<sup>[72]</sup> Copyright 2022, Wiley-VCH. 

mentioned coordinating interaction between SAMs and the perovskite layer, as depicted in Figure 6c, Han’s research team recently demonstrated that the iodine atom in both 4-iodo-benzoic acid (I-BA) and 4-iodo-2,3,5,6-tetrafluorobenzoic acid (I-TFBA) forms a robust halogen bonding interaction with I<sup>−</sup> ions within the perovskite layer.<sup>[72]</sup> This interaction effectively restrains the formation of I2 during continuous light exposure and mitigates the formation of voids at the interface. Moreover, the highly directional halogen bonding interaction plays a constructive role in facilitating the ordered growth of perovskite crystal to promote the charge transfer process. As a result, the device treated with I- TFBA yielded a champion efficiency of 22.02% and significantly enhanced the device stability, remaining 91.9% of its initial PCE after 1000 h light soaking at 55 °C. 

Apart from the above-mentioned simple molecules, conjugated organic compounds have also been utilized for interfacial treatment between NiOx and perovskite layers. This strategy aims to reduce defects and suppress interfacial recombination. Additionally, these compounds have exhibited noteworthy properties in enhancing hole selectivity between NiOx and the perovskite layer. For example, Cheng et al. employed conjugated small organic molecules terminated with two pyridine groups as a bridge for hole transfer between NiOx and perovskite layer by coordinating interactions.<sup>[73]</sup> The introduction of PTZ molecules on the upper surface of NiOx enhanced hole extraction, and passivated interfacial defects, consequently leading to improved device performance and stability. 

Furthermore, commonly used SAM HTMs, such as **2PACz** , have also been employed as SAMs at the interface of the NiOx and perovskite layers.<sup>[74]</sup> For example, Tan’s group utilized a mixture of carbazole-based compounds, **2PACz** and **MeO-2PACz** , 

deposited onto the surface of a NiOx nanocrystal film processed at low-temperatures ( **Figure 7** a).<sup>[75]</sup> This approach facilitated efficient hole extraction and reduced interfacial recombination, achieving an impressive power conversion efficiency of 24.7% on flexible all-perovskite tandem solar cells. Recently, Li et al. utilized **MeO-4PADBC** (4-(3,11-dimethoxy-7Hdibenzo[c,g]carbazol-7-yl)butyl)phosphonic acid) to anchor onto the surface of NiOx films, to help promote hole extraction, and to reduce the interfacial defects between NiOx and perovskite. This approach led to notable improvements across various compositions, achieving a certified PCE of 25.6% for 1.53 eV devices, as shown in Figure 7b.<sup>[76]</sup> Furthermore, this combination immobilized MeO-4PADBC at the interface between NiOx and the perovskite, forming a robust hole selective layer that significantly boosted the device’s thermal stability. 

### **3.2. Interfacial Treatment Between Electron Transport Layer and Perovskite Layer** 

Beyond their use as interlayers between HTL and perovskite, SAMs have also been extensively applied to modify ETL and perovskite interfaces. Mesoporous TiO2 (m-TiO2), an n-type semiconductor, has been widely utilized as an electron transport layer to fabricate highly efficient n-i-p PSCs. Its mesoporous property is beneficial due to the large contact area for interfacial charge transfer. However, the low electron mobility of the m- TiO2 layer and high interfacial defect density between TiO2 and perovskite are the main reasons hindering the further enhancement of device performance. Initially, Snaith’ group utilized a self-assembled monolayer of fullerene, C60-SAM, anchored to the 

**2400205 (9 of 17)** 

_Adv. Energy Mater._ **2025** , _15_ , 2400205 

© 2024 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



### **www.advenergymat.de** 



**Figure 7.** a) Device structure and molecular structures of bridging molecules. Reproduced with permission.<sup>[75]</sup> Copyright 2022, Springer Nature. b) Molecular structure, side view of MeO-2PACz and MeO-4PADBC, and the schematic illustration of MeO-4PADBC anchoring on NiOx nanoparticles as the HSL in PSC. Reproduced with permission.<sup>[76]</sup> Copyright 2023, AAAS. 

surface of the n-type TiO2 layer, as shown in **Figure 8** a.<sup>[77,78]</sup> This modification aimed to facilitate electron transfer, ultimately leading to improved photovoltaic performance of the solar cell device and reduced hysteresis. Subsequently, other fullerene derivatives have been explored as interfacial agents to be applied on the surface of the TiO2 layer to enhance device performance.<sup>[79]</sup> For example, as depicted in Figure 8b, Meng’s group demonstrated that PCBA effectively passivates Pb-I antisite defects, leading to improved electron transport through the ordered interaction between the fullerene cage and iodide.<sup>[80,81]</sup> When combined with 3- carboxypropyl-triphenyl phosphonium bromide (CPTPB), the resulting devices show an outstanding power conversion efficiency of 24.8%, accompanied by minimal hysteresis and enhanced stability under various conditions such as light soaking and thermal stress. As depicted in Figure 8c, Ogomi et al. enhanced the photovoltaic performance of the device by incorporating _𝛾_ -amino butyric acid HI salt (GABAH<sup>+</sup> I<sup>−</sup> ) as a self-assembled monolayer anchoring on the TiO2 surface.<sup>[38]</sup> This introduction of the SAMs layer passivated surface defect passivation, facilitated electron injection, and enlarged the perovskite crystals. In addition to HI salts, amino acid molecules have also been employed as selfassembled monolayers to anchor on TiO2 surfaces.<sup>[82]</sup> The utilization of SAMs as an interlayer effectively lowered trap density and enhanced the quality of perovskite films. Furthermore, it established an energetically aligned interface, facilitating electron transport between the perovskite and TiO2. Consequently, the introduction of SAMs’ molecular structure significantly improved 

device performance. Moreover, the modification of the molecular structure of SAMs can also a make significant difference in their properties. For example, formulating lead coordination groups, such as chloride atoms,<sup>[36]</sup> amine,<sup>[83]</sup> pyridine,<sup>[84]</sup> and thiols,<sup>[85]</sup> in SAM molecules can passivate the TiO2 surface. This approach proves advantageous in reducing trap density, promoting electron transfer as well as enhancing the quality of perovskite films. In addition, anchoring groups can be modified to include not only carboxylic acid but also phosphonic acid<sup>[86]</sup> (Figure 8d) and silane<sup>[87]</sup> (Figure 8e). Han’s research team introduced an organic silane self-assembled monolayer atop the TiO2 layer to mitigate interfacial recombination processes.<sup>[87]</sup> This modification led to a notable enhancement in the power conversion efficiency of the HTL-free device based on a carbon counter electrode, increasing it from 9.6% to 12.7%. 

Recently, due to the excellent electron mobility, remarkable UV stability, and low-temperature annealing process, SnO2 has emerged as a widely utilized electron transport layer. A popular method to further enhance the performance and stability of SnO2-based devices involves introducing SAMs to modify the ETL/perovskite interface. Trialkoxysilane SAMs are recognized for their ability to self-assemble and cross-link on SnO2 surfaces through silanization. This process significantly reduces surface ─OH groups by forming anchoring O─Si bonds, with the terminal group interacting with the perovskite bottom layer. For instance, Yang et al. utilized 3-aminopropyltriethoxysilane (APTES) to modify the SnO2/perovskite interface.<sup>[39]</sup> The introduction of 

**2400205 (10 of 17)** 

_Adv. Energy Mater._ **2025** , _15_ , 2400205 

© 2024 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



### **www.advenergymat.de** 



**Figure 8.** a) Schematic of the device structure. Reproduced with permission.<sup>[77]</sup> Copyright 2013, American Chemical Society. b) Molecular structure of CPTPB and PCBA. Reproduced with permission.<sup>[81]</sup> Copyright 2022, Wiley-VCH. c) Structure of titania anode where HOCO─R─NH3<sup>+</sup> was inserted between perovskite and porous titania. Reproduced with permission.<sup>[38]</sup> Copyright 2014, American Chemical Society. d) Phosphonic acid SAMs with the same terminal group, but different chain lengths; and phosphonic acid SAMs with equivalent chain lengths, but the varied terminal group. Reproduced with permission.<sup>[86]</sup> Copyright 2020, Elsevier. e) Structure of the fully printable mesoscopic perovskite solar cells based on a carbon CE. Reproduced with permission.<sup>[87]</sup> Copyright 2015, American Chemical Society. 

APTES improved perovskite film quality, lowered the WF, passivated interfacial trap states, and reduced the recombination process, resulting in a device power conversion efficiency exceeding 18%. The same effect can also be realized by employing the molecule 3-mercaptopropyltrimethoxysilane (MPTMS) ( **Figure 9** a).<sup>[88]</sup> Similarly, Dai et al. employed an iodineterminated self-assembled monolayer (I-SAM) to increase adhesion toughness at the SnO2 and perovskite interface, enhancing mechanical reliability, as shown in Figure 9b.<sup>[89]</sup> Consequently, the target device exhibited improved performance, reduced hysteresis, and notably enhanced operational stability, with a projected T80 extending to 4000 h. As depicted in Figure 9c, Yang’s group introduced a range of self-assembled monolayers on SnO2 to create diverse chemical interactions.<sup>[90]</sup> They found that the incorporation of 4-pyridinecarboxylic acid SAM led to remarkable improvements, achieving the highest efficiency of 18.8%, an approximate 10% enhancement compared to devices without SAMs. In addition, SAMs based on amino acids (HOOC─R─NH2) have been extensively employed to enhance the performance of those SnO2-based PSCs (Figure 9d).<sup>[91,92]</sup> The bifunctional groups of ─COOH and ─NH2 within amino acids have been demonstrated to possess the ability to concurrently cross-link the surface of SnO2 and perovskite layers. This re- 

sults in faster interfacial charge extraction and transport. Different terminal groups exhibit distinct interactions with the perovskite layer, thereby exerting different effects on device performance. Other terminal groups, such as sulfonium salt,<sup>[93]</sup> ammonium salt,<sup>[94]</sup> have also been investigated to modify the interface of SnO2 and perovskite films. These materials have demonstrated the ability to passivate interfacial defects and reduce the interfacial energy barrier, thereby enhancing device PCE and stability. Furthermore, SAMs derived from n-type functionalized fullerene compounds, such as DPC60<sup>[95]</sup> and C9,<sup>[96]</sup> known for their outstanding electron extraction properties, have also been employed to enhance the performance and stability of SnO2-based PSCs. 

Apart from TiO2 and SnO2, the extensive use of SAMs has been extended to ZnO-based PSCs. The ZnO substrate boasts high charge mobility, a low-temperature annealing process, and remarkable optoelectronic properties.<sup>[97]</sup> Nevertheless, the substrate’s instability, arising from interaction with the perovskite film, requires additional interfacial treatment, with one common method being the utilization of SAM molecules. For instance, Zuo et al. developed 3-aminopropanoic acid (C3-SAM) to modify the ZnO-coated substrate in PSCs ( **Figure 10** a).<sup>[98]</sup> The incorporation of C3-SAM not only improved the quality of the 

**2400205 (11 of 17)** 

_Adv. Energy Mater._ **2025** , _15_ , 2400205 

© 2024 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advenergymat.de** 



**www.advancedsciencenews.com** 





**Figure 9.** a) Schematic diagram of the SnO2/MPTMS/perovskite. Adapted with permission.<sup>[88]</sup> Copyright 2021, Wiley-VCH. b) Schematic illustration of the sandwich DCB specimen for toughness testing (not to scale). Insert shows magnified schematic illustration of idealized I-SAM. Reproduced with permission.<sup>[89]</sup> Copyright 2021, AAAS. c) Schematic diagram of the perovskite solar cell device structure and the SAM between the SnO2 and perovskite film. Reproduced with permission.<sup>[90]</sup> Copyright 2017, American Chemical Society. d) Diagram of SnO2 ETL where HOOC─R─NH2 was inserted between perovskite and SnO2 layer. Reproduced with permission.<sup>[91]</sup> Copyright 2020, Elsevier. 



**Figure 10.** a) Schematic diagram of perovskite solar cell device structure, SAM-induced permanent dipole formation, involvement of the SAM in the crystalline structure of perovskite crystals, and schematic energy level of each layer in perovskite solar cells. Reproduced with permission.<sup>[98]</sup> Copyright 2015, American Chemical Society. b) SAM-induced permanent dipole moment at the ZnO/perovskite interface. Reproduced with permission.<sup>[100]</sup> Copyright 2017, Wiley-VCH. c) Structure of PSCs based on SAM-ZnO. Adapted with permission.<sup>[101]</sup> Copyright 2018, Wiley-VCH. 

**2400205 (12 of 17)** 

_Adv. Energy Mater._ **2025** , _15_ , 2400205 

© 2024 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

perovskite by reducing pinholes and trap state density, but also resulted in an energetically aligned surface that promoted charge extraction. This leads to an increase in device performance from 11.96% to 15.67%. Kim’s group employed three methoxybenzoic acids as a self-assembled surface passivation layer to modify the ZnO surface.<sup>[99]</sup> They observed that the largest of these, 3,4,5-trimethoxybenzoic acid (TMBA), induced a more substantial WF shift in the ZnO substrate. This shift was attributed to its strong dipole moment and hydrogen bonding between the methoxy groups and ammonium cations. Such interaction improved charge transfer, enhanced perovskite crystallization properties, and facilitated interfacial proton transfer. Consequently, PSCs treated with TMBA exhibited an improved power conversion efficiency from 1.44% to 13.75%, accompanied by enhanced device stability. Azmi et al. employed new polar SAMs to modify ZnO in PSCs, as shown in Figure 10b.<sup>[100]</sup> They found that the incorporation of the SAM layer enhanced the hydrophobicity of the ZnO substrate, improved the quality of the perovskite film, and increased the dipole effect, thereby enhancing charge extraction. This approach resulted in a notable improvement in device PCE to 18.82%. 3-(aminopropyl)triethoxysilane (APTES), depicted in Figure 10c, has also been employed as the SAM interfacial passivation by Liu et al to improve the perovskite quality and performance as well as the stability on ZnO-based devices.<sup>[101]</sup> 

## **4. Summary and Perspective** 

### **4.1. Summary** 

In this comprehensive review, we systematically described the key components and properties of self-assembled monolayers linking them to diverse functionality in perovskite solar cells. In summary, SAM molecules consist of three key components: an anchoring group, a linker group, and a terminal group, making them readily modifiable through the introduction of various functional groups or atoms. Various deposition methods, such as vapor deposition, solution deposition, evaporation, and integration into the perovskite solution, demonstrate the potential for large-scale applications of SAM molecules. Furthermore, we have summarized the extensive use of SAMs as charge-selective contacts and interfacial modulators. These applications effectively modify surface energy levels, reduce interfacial defects, enhance the quality of perovskite films grown on top of them, and thereby improve device performance and stability. 

### **4.2. Perspective** 

SAMs undeniably herald a new era in cost-effective and highefficiency PSCs material development, owing to their adaptable structural modifications and exceptional processing properties. However, despite their advantages, SAMs encounter challenges on their path to practical applications in PSCs. Consequently, the forthcoming discussion will delve into the future perspectives of SAMs, specifically addressing challenges related to molecular design, film characterization, and the advancement of PSC performance. 



**www.advenergymat.de** 

### _4.2.1. Molecular Design_ 

As outlined in Section 1.1., the molecular structure of SAMs typically comprises three components: an anchoring group, a linker group, and a terminal group. It is crucial to consider each of these parts when designing innovative SAM molecules for their successful implementation in PSCs. 

- i. The anchoring groups in SAM molecules should normally form chemical bonds with the substrate during the selfassembled processing. In some cases, the hydrophilic anchoring groups from the excess unanchored SAM molecules may contribute to modifying the surface wettability of the substrate and interacting with the perovskite layer. This interaction enhances perovskite deposition, resulting in the formation of uniform perovskite films and minimizing buried interfacial defects. Nevertheless, the choice of anchoring group should be tailored according to the specific substrate as well as the desired binding and chemical properties. 

- ii. The linker groups serve to connect the anchoring and terminal groups. These linker groups normally consist of either alkyl chains or aromatic conjugated moieties. The strong intermolecular interaction between the aromatic spacers often leads to poor solubility and flexibility, making them less favored in SAM designs. The length and orientation of the alkyl chain play a pivotal role in adjusting the interaction strength between the terminal group and the anchoring group, providing flexibility for optimizing conformation in molecular assembly. 

- iii. The terminal group functions as the core in a SAM molecule, exerting significant influence over SAM functionalities. The introduction of various functional groups helps to establish the interaction with the upper layer, promote charge extraction, and suppress interfacial nonradiative recombination. The design of the terminal groups is typically guided by their intermolecular interactions and intended functionalities. 

Nevertheless, it remains a challenge for organic chemists to pursue additional structural adjustments in designing, selecting, and synthesizing new SAM molecules with optimized combinations to fine-tune the properties of SAMs, ensuring their optimal effectiveness in PSCs. Simultaneously, a more comprehensive understanding of the relationships among the three components in a SAM molecule and their respective roles in influencing interfaces or charge transport layers and functionalizing devices is essential to provide guidance for enhanced molecular design. 

Additionally, although SAMs have gained extensive traction as hole transport materials in inverted PSCs, the success in developing effective n-type SAMs remains limited. The ongoing development and exploration of innovative SAM-based electron transport materials are critical for unlocking their full potential in future solar cell applications. 

### _4.2.2. Characterization and Mechanism Understanding_ 

First, as SAMs exist as extremely thin layers, serving as interfacial modulators or charge transport layers, direct observation of their microstructures through commonly used techniques such 

**2400205 (13 of 17)** 

_Adv. Energy Mater._ **2025** , _15_ , 2400205 

© 2024 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



as SEM or TEM, presents significant challenges. In most studies, researchers have employed techniques such as AFM, XPS, and contact angle measurements to confirm the formation of the SAM layers. However, these approaches may not entirely unveil the true state of the monolayer. Thus, there is a critical need for more surface-sensitive characterizations of these selfassembled monolayers. Secondly, evaluating uniformity, identifying defects, or ensuring full surface coverage in monolayer molecules presents another challenge, particularly in enabling their use for the fabrication of large-area devices intended for future industrial applications. The effectiveness of a SAM interlayer may be misinterpreted if its surface coverage is not thoroughly examined. While some studies suggest that the combination of different SAMs can lead to the formation of a more compact and ordered SAM layer, a more in-depth investigation is necessary to comprehend its properties. Furthermore, the mechanism of the charge transport process is still a subject of debate: some groups argue that SAMs modify the work function of the underlying substrate, while others believe SAMs function as hole/electron transport layers to selectively transport charges. 

### _4.2.3. Stability Issue_ 

Although the employment of SAMs has proven to be a successful strategy in enhancing the performance of perovskite solar cells, future investigations should address the stability challenges associated with self-assembled monolayer molecules, particularly under light and thermal conditions. The ultrathin organic layers absorb UV light during solar cell operation, which is likely to result in the decomposition of these organic compounds. Simultaneously, elevated temperatures can induce the breakdown of bonds between the anchoring group of small SAM molecules and substrates, contributing to the degradation of PSCs. Therefore, future studies should focus on exploring and investigating advanced thermal- and photo-stable SAM molecules to achieve more stable PSCs with high efficiency. 

## **Acknowledgements** 

J.S. and A.H. acknowledge the Swiss National Science Foundation for financial support with Project No. 200020_185041. B.Y. and G.B. acknowledge funding from the Horizon Europe framework program for research and innovation under grant agreement No. 101084124–DIAMOND and the ST and UP for Energy program. 



### **www.advenergymat.de** 

- [1] S. Akin, N. Arora, S. M. Zakeeruddin, M. Grätzel, R. H. Friend, D. I. Dar, _Adv. Energy Mater._ **2020** , _10_ , 1903090. 

- [2] E. Aydin, M. De Bastiani, S. De Wolf, _Adv. Mater._ **2019** , _31_ , 1900428. 

- [3] F. H. Isikgor, S. Zhumagali, L. V. T. Merino, M. De Bastiani, I. McCulloch, S. De Wolf, _Nat. Rev. Mater._ **2023** , _8_ , 89. 

- [4] H. Cheng, Y. Li, Y. Zhong, _Mater. Chem. Front._ **2023** , _7_ , 3958. 

- [5] T. Zhang, F. Wang, H.-B. Kim, I.-W. Choi, C. Wang, E. Cho, R. Konefal, Y. Puttisong, K. Terado, L. Kobera, M. Chen, M. Yang, S. Bai, B. Yang, J. Suo, S.-C. Yang, X. Liu, F. Fu, H. Yoshida, W. M. Chen, J. Brus, V. Coropceanu, A. Hagfeldt, J.-L. Brédas, M. Fahlman, D. S. Kim, Z. Hu, F. Gao, _Science._ **2022** , _377_ , 495. 

- [6] Y. Saygili, H.-S. Kim, B. Yang, J. Suo, A. B. Munoz-Garcia, M. Pavone, A. Hagfeldt, _ACS Energy Lett._ **2020** , _5_ , 1271. 

- [7] M. Saliba, T. Matsui, J.-Y. Seo, K. Domanski, J.-P. Correa-Baene, M. K. Nazeerunddin, S. M. Zakeeruddin, W. Tress, A. Abate, A. Hagfeldt, M. Grätzel, _Energy Environ. Sci._ **2016** , _9_ , 1989. 

- [8] M. Kim, G.-H. Kim, T. K. Lee, I. W. Choi, H. W. Choi, Y. Jo, Y. J. Yoon, J. W. Kim, J. Lee, D. Huh, H. Lee, S. K. Kwak, J. Y. Kim, D. S. Kim, _Joule._ **2019** , _3_ , 2179. 

- [9] H. Min, M. Kim, S.-U. Lee, H. Kim, G. Kim, K. Choi, J. H. Lee, S. I. Seok, _Science._ **2019** , _366_ , 749. 

- [10] B. Yang, J. Suo, D. Bogachuk, W. Kaiser, C. Baretzky, O. Er-Raji, G. Loukeris, A. A. Alothman, E. Mosconi, M. Kohlstädt, U. Würfel, F. De Angelis, A. Hagfeldt, _Energy Environ. Sci._ **2024** , _17_ , 1549. 

- [11] S. Wang, B. Yang, J. Han, Z. He, T. Li, Q. Cao, J. Yang, J. Suo, X. Li, Z. Liu, S. Liu, C. Tang, A. Hagfeldt, _Energy Environ. Sci._ **2020** , _13_ , 5068. 

- [12] Q. Jiang, Y. Zhao, X. Zhang, X. Yang, Y. Chen, Z. Chu, Q. Ye, X. Li, Z. Yin, J. You, _Nat Photonics._ **2019** , _13_ , 460. 

- [13] H. Kim, S.-U. Lee, D. Y. Lee, M. J. Paik, H. Na, J. Lee, S. I. Seok, _Adv. Energy Mater._ **2019** , _9_ , 1902740. 

- [14] H. Zhu, Y. Liu, F. T. Eickemeyer, L. Pan, D. Ren, M. A. Ruiz-Preciado, B. Carlsen, B. Yang, X. Dong, Z. Wang, H. Liu, S. Wang, S. M. Zakeeruddin, A. Hagfeldt, M. I. Dar, X. Li, M. Grätzel, _Adv. Mater._ **2020** , _32_ , 1907757. 

- [15] J. Suo, B. Yang, E. Mosconi, D. Bogachuk, T. A. S. Doherty, K. Frohna, D. J. Kubicki, F. Fu, Y. Kim, O. Er-Raji, T. Zhang, L. Baldinelli, L. Wagner, A. N. Tiwari, F. Gao, A. Hinsch, S. D. Stranks, F. De Angelis, A. Hagfeldt, _Nat. Energy._ **2024** , _9_ , 172. 

- [16] J. Suo, B. Yang, J. Jeong, T. Zhang, S. Olthof, F. Gao, M. Grätzel, G. Boschloo, A. Hagfeldt, _Nano Energy._ **2022** , _94_ , 106924. 

- [17] B. Yang, J. Suo, F. D. Giacomo, S. Olthof, D. Bogachuk, Y. Kim, X. Sun, L. Wagner, F. Fu, S. M. Zakeeruddin, A. Hinsch, M. Grätzel, A. D. Carlo, A. Hagfeldt, _ACS Energy Lett._ **2021** , _6_ , 3916. 

- [18] J. Suo, B. Yang, E. Mosconi, H.-S. Choi, Y. Kim, S. M. Zakeeruddin, F. D. Angelis, M. Grätzel, H.-S. Kim, A. Hagfeldt, _Adv. Func. Mater._ **2021** , _31_ , 2102902. 

- [19] B. Yang, J. Suo, E. Mosconi, D. Ricciarelli, W. Tress, F. D. Angelis, H.-S. Kim*, A. Hagfeldt, _ACS Energy Lett._ **2020** , _5_ , 3159. 

- [20] J. Suo, B. Yang, A. Hagfeldt, _Energies._ **2021** , _14_ , 4836. 

## **Conflict of Interest** 

D.B. is an employee of Solarlab Aiko Europe GmbH. The remaining authors declare no conflict of interest. 

## **Keywords** 

charge transport materials, interfacial modulators, perovskite solar cells, SAMs molecules 

Received: January 14, 2024 Revised: March 22, 2024 Published online: April 18, 2024 

- [21] R. Qiao, L. Zuo, _J. Mater. Res._ **2018** , _22_ , 387. 

- [22] J. Dong, A. Wang, K. Y. Simon Nh, G. Mao, _Thin Solid Films._ **2006** , _515_ , 2116. 

- [23] F. Ali, C. Roldán-Carmona, M. Sohail, M. K. Nazeeruddin, _Adv. Energy Mater._ **2020** , _10_ , 2002989. 

- [24] A. Magomedov, A. Al-Ashouri, E. Kasparaviˇcius, S. Strazdaite, G. Niaura, M. Jošt, T. Malinauskas, S. Albrecht, V. Getautis, _Adv. Energy Mater._ **2018** , _8_ , 1801892. 

- [25] E. Yalcin, M. Can, C. Rodriguez-Seco, E. Aktas, R. Pudi, W. Cambarau, S. Demic, E. Palomares, _Energy Environ. Sci._ **2019** , _12_ , 230. 

- [26] A. Al-Ashouri, A. Magomedov, M. Roß, M. jošt, M. Talaikis, G. Chistiakova, T. Bertram, J. A. Márquez, E. Köhnen, E. Kasparaviˇcius, S. Levcenco, L. Gil-Escrig, C. J. Hages, R. Schlatmann, B. Rech, 

**2400205 (14 of 17)** 

_Adv. Energy Mater._ **2025** , _15_ , 2400205 

© 2024 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

   - T. Malinauskas, T. Unold, C. A. Kaufmann, L. Korte, G. Niaura, V. Getautis, S. Albrecht, _Energy Environ. Sci._ **2019** , _12_ , 3356. 

- [27] S. N. Afraj, C.-H. Kuan, J.-S. Lin, J.-S. Ni, A. Velusamy, M.-C. Chen, E. W.-G. Diau, _Adv. Funct. Mater._ **2023** , _33_ , 2213939. 

- [28] E. J. Cassella, E. L. K. Spooner, T. Thornber, M. E. O’Kane, T. E. Catley, J. E. Bishop, J. A. Smith, O. S. Game, D. G. Lidzey, _Adv. Sci._ **2022** , _9_ , 2104848. 

- [29] A. Farag, T. Feeney, I. M. Hossain, F. Schackmar, P. Fassl, K. Küster, R. Bäuerle, M. A. Ruiz-Preciado, M. Hentschel, D. B. Ritzer, A. Diercks, Y. Li, B. A. Nejand, F. Laufer, R. Singh, U. Starke, U. W. Paetzold, _Adv. Energy Mater._ **2023** , _13_ , 2203982. 

- [30] X. Zheng, Z. Li, Y. Zhang, M. Chen, T. Liu, C. Xiao, D. Gao, J. B. Patel, D. Kuciauskas, A. Magomedov, R. A. Scheidt, X. Wang, S. P. Harvey, Z. Dai, C. Zhang, D. Morales, H. Pruett, B. M. Wieliczka, A. R. Kirmani, N. P. Padture, K. R. Graham, Y. Yan, M. K. Nazeeruddin, M. D. McGehee, Z. Zhu, J. M. Luther, _Nat. Energy._ **2023** , _8_ , 462. 

- [31] Q. Tan, Z. Li, G. Luo, X. Zhang, B. Che, G. Chen, H. Gao, D. He, G. Ma, J. Wang, J. Xiu, H. Yi, T. Chen, Z. He, _Nature._ **2023** , _620_ , 545. 

- [32] E. Li, E. Bi, Y. Wu, W. Zhang, L. Li, H. Chen, L. Han, H. Tian, W. Zhu, _Adv. Funct. Mater._ **2020** , _30_ , 1909509. 

- [33] B. de Boer, A. Hadipour, M. M. Mandoc, T. van Woudenbergh, P. W. M. Blom, _Adv. Mater._ **2005** , _17_ , 621. 

- [34] S. Chen, X. Dai, S. Xu, H. Jiao, L. Zhao, J. Huang, _Science._ **2021** , _373_ , 902. 

- [35] D. Meggiolaro, E. Mosconi, F. De Angelis, _ACS Energy Lett._ **2019** , _4_ , 779. 

- [36] T. Zhu, J. Su, F. Labat, I. Ciofini, T. Pauporté, _ACS Appl. Mater. Interfaces._ **2020** , _12_ , 744. 

- [37] L. Xie, J. Chen, P. Vashishtha, X. Zhao, G. S. Shin, S. G. Mhaisalkar, N. G. Park, _ACS Energy Lett._ **2019** , _4_ , 2192. 

- [38] Y. Ogomi, A. Morita, S. Tsukamoto, T. Saitho, Q. Shen, T. Toyoda, K. Yoshino, S. S. Pandey, T. Ma, S. Hayase, _J. Phys. Chem. C._ **2014** , _118_ , 16651. 

- [39] G. Yang, C. Wang, H. Lei, X. Zheng, P. Qin, L. Xiong, X. Zhao, Y. Yan, G. Fang, _J Mater Chem._ **2017** , _5_ , 1658. 

- [40] S. Y. Kim, S. J. Cho, S. E. Byeon, X. He, H. J. Yoon, _Adv. Energy Mater._ **2020** , _10_ , 2002606. 

- [41] C. Bi, Q. Wang, Y. Shao, Y. Yuan, Z. Xiao, J. Huang, _Nat. Commun._ **2015** , _6_ , 7747. 

- [42] M. Chen, G. Kapil, L. Wang, S. Razey Sahamir, A. K. Baranwal, K. Nishimura, Y. Sanehira, Z. Zhang, M. Akmal Kamarudin, Q. Shen, S. Hayase, _Chem. Eng. J._ **2022** , _436_ , 135196. 

- [43] Y. Yao, C. Cheng, C. Zhang, H. Hu, K. Wang, S. De Wolf, _Adv. Mater._ **2022** , _34_ , 2203794. 

- [44] S. Wu, J. Zhang, Z. Li, D. Liu, M. Qin, S. H. Cheung, X. Lu, D. Lei, S. K. So, Z. Zhu, A. K.-Y. Jen, _Joule._ **2020** , _4_ , 1248. 

- [45] M. Stolterfoht, P. Caprioglio, C. M. Wolff, J. A. Márquez, J. Nordmann, S. Zhang, D. Rothhardt, U. Hörmann, Y. Amir, A. Redinger, L Kegelmann, F. Zu, S. Albrecht, N. Koch, T. Kirchartz, M. Saliba, T. Unold, D. Neher, _Energy Environ. Sci._ **2019** , _12_ , 2778. 

- [46] A. Farag, P. Fassl, H. Hu, T. Feeney, A. Quintilla, M. A. Ruiz-Preciado, W. Hempel, D. Bagrowski, P. Noack, B. Wattenberg, T. Dippell, U. W. Paetzold, _Adv Funct Mater._ **2023** , _33_ , 2210758. 

- [47] S. Zhang, F. Ye, X. Wang, R. Chen, H. Zhang, L. Zhan, X. Ji, Y. Li, X. Ji, S. Liu, M. Yu, F. Yu, Y. Zhang, R. Wu, Z. Liu, Z. Ning, D. Neher, L. Han, Y. Lin, H. Tian, W. Chen, M. Stolterfoht, L. Zhang, W. Zhu, Y. Wu, _Science._ **2023** , _380_ , 404. 

- [48] A. Al-Ashouri, E. Köhnen, B. Li, A. Magomedov, H. Hempel, P. Caprioglio, J. A. Márquez, A. B. M. Vilches, E. Kasparavicius, J. A. Smith, N. Phung, D. Menzel, M. Grischek, L. Kegelmann, D. Skroblin, C. Gollwitzer, T. Malinauskas, M. Jošt, G. Matiˇc, B. Rech, R. Schlatmann, M. Topiˇc, L. Korte, A. Abate, B. Stannowski, D. Neher, M. Stolterfoht, T. Unold, V. Getautis, S. Albrecht, _Science._ **2020** , _370_ , 1300. 



### **www.advenergymat.de** 

- [49] Z. Ren, Z. Cui, X. Shi, L. Wang, Y. Dou, F. Wang, H. Lin, H. Yan, S. Chen, _Joule._ **2023** , _7_ , 2894. 

- [50] W. Jiang, F. Li, M. Li, F. Qi, F. R. Lin, A. K.-Y. Jen, _Angew. Chem., Int. Ed._ **2022** , _61_ , 202213560. 

- [51] R. He, W. Wang, Z. Yi, F. Lang, C. Chen, J. Luo, J. Zhu, J. Thiesbrummel, S. Shah, K. Wei, Y. Lui, C. Wang, H. Lai, H. Huang, J. Zhou, B. Zou, X. Yin, S. Ren, X. Hao, L. Wu, J. Zhang, J. Zhang, M. Stolterfoht, F. Fu, W. Tang, D. Zhao, _Nature._ **2023** , _618_ , 80. 

- [52] Z. Yi, W. Wang, R. He, J. Zhu, W. Jiao, Y. Luo, Y. Xu, Y. Wang, Z. Zeng, K. Wei, J. Zhang, S.-W. Tsang, C. Chen, W. Tang, D. Zhao, _Energy Environ. Sci._ **2024** , _17_ , 202. 

- [53] G. Wang, J. Zheng, W. Duan, J. Yang, M. A. Mahmud, Q. Lian, S. Tang, C. Liao, J. Bing, J. Yi, T. L. Leung, X. Cui, H. Chen, F. Jiang, Y. Huang, A. Lambertz, M. Jankovec, M. Topiˇc, S. Bremner, Y.-Z. Zhang, C. Cheng, K. Ding, A. Ho-Baillie, _Joule._ **2023** , _7_ , 2583. 

- [54] A. Ullah, K. H. Park, Y. Lee, S. Park, A. B. Faheem, H. D. Nguyen, Y. Siddique, K.-K. Lee, Y. Jo, C.-H. Han, S. Ahn, I. Jeong, S. Cho, B. Kim, Y. S. Park, S. Hong, _Adv. Funct. Mater._ **2022** , _32_ , 2208793. 

- [55] Y. Wang, Q. Liao, J. Chen, W. Huang, X. Zhuang, Y. Tang, B. Li, X. Yao, X. Feng, X. Zhang, M. Su, Z. He, T. J. Marks, A. Facchetti, X. Guo, _J. Am. Chem. Soc._ **2020** , _142_ , 16632. 

- [56] Q. Liao, Y. Wang, M. Hao, B. Li, K. Yang, X. Ji, Z. Wang, K. Wang, W. Chi, X. Guo, W. Huang, _ACS Appl. Mater. Interfaces._ **2022** , _14_ , 43547. 

- [57] R. Guo, X. Zhang, X. Zheng, L. Li, M. Li, Y. Zhao, S. Zhang, L. Luo, S. You, W. Li, Z. Gong, R. Huang, Y. Cui, Y. Rong, H. Zeng, X. Li, _Adv. Funct. Mater._ **2023** , 2211955. 

- [58] J. Zhu, Y. Luo, R. He, C. Chen, Y. Wang, J. Luo, Z. Yi, J. Thiesbrummel, C. Wang, F. Lang, H. Lai, Y. Xu, J. Wang, Z. Zhang, W. Liang, G. Cui, S. Ren, X. Hao, H. Huang, Y. Wang, F. Yao, Q. Lin, L. Wu, J. Zhang, M. Stolterfoht, F. Fu, D. Zhao, _Nat. Energy._ **2023** , _8_ , 714. 

- [59] H. Guo, C. Liu, H. Hu, S. Zhang, X. Ji, X.-M. Cao, Z. Ning, W.-H. Zhu, H. Tian, Y. Wu, _Natl Sci Rev._ **2023** , _10_ , nwad057. 

- [60] Y. Hou, S. Scheiner, X. Tang, N. Gasparini, M. Richter, N. Li, P. Schweizer, S. Chen, H. Chen, C. O. R. Quiroz, X. Du, G. J. Matt, A. Osvet, E. Spiecker, R. H. Fink, A. Hirsch, M. Halik, C. J. Brabec, _Adv. Mater. Interfaces._ **2017** , _4_ , 1700007. 

- [61] P. Topolovsek, F. Lamberti, T. Gatti, A. Cito, J. M. Ball, E. Menna, C. Gadermaier, A. Petrozza, _J. Mater. Chem. A._ **2017** , _5_ , 11882. 

- [62] H. Cheng, Y. Li, M. Zhang, K. Zhao, Z.-S. Wang, _ChemSusChem._ **2020** , _13_ , 2779. 

- [63] L. Li, Y. Wu, E. Li, C. Shen, H. Zhang, X. Xu, G. Wu, M. Cai, W.-H. Zhu, _Chem. Commun._ **2019** , _55_ , 13239. 

- [64] S. O. Fürer, K. J. Rietwyk, F. Pulvirenti, D. P. McMeekin, M. A. Surmiak, S. R. Raga, W. Mao, X. Lin, Y. Hora, J. Wang, Y. Shi, S. Barlow, D. S. Ginger, S. R. Marder, U. Bach, _ACS Appl. Energy Mater._ **2023** , _6_ , 667. 

- [65] W. Han, G. Ren, J. Liu, Z. Li, H. Bao, C. Liu, W. Guo, _ACS Appl. Mater. Interfaces._ **2020** , _12_ , 49297. 

- [66] D. Bogachuk, C. Baretzky, J. Eckert, B. Yang, J. Suo, U. K. Dangudubiyyam, G. Loukeris, H. Mohammadzadeh, S. Kluska, M. Kohlstädt, U. Würfel, _Sol. RRL._ **2024** , _8_ , 2300750. 

- [67] Z. Gu, L. Zuo, T. T. Larsen-Olsen, T. Ye, G. Wu, F. C. Krebs, H. Chen, _J. Mater. Chem. A._ **2015** , _3_ , 24254. 

- [68] Y. Bai, H. Chen, S. Xiao, Q. Xue, T. Zhang, Z. Zhu, Q. Li, C. Hu, Y. Yang, Z. Hu, F. Huang, K. S. Wong, H.-L. Yip, S. Yang, _Adv. Funct. Mater._ **2016** , _26_ , 2950. 

- [69] D. S. Mann, P. Patil, S.-N. Kwon, S.-I. Na, _Appl. Surface Sci._ **2021** , _560_ , 149973. 

- [70] Q. Wang, C.-C. Chueh, T. Zhao, J. Cheng, M. Eslamian, W. C. H. Choy, A. K.-Y. Jen, _ChemSusChem._ **2017** , _10_ , 3794. 

- [71] J. Zhang, J. Yang, R. Dai, W. Sheng, Y. Su, Y. Zhong, X. Li, L. Tan, Y. Chen, _Adv. Energy Mater._ **2022** , _12_ , 2103674. 

- [72] C. Zhang, X. Shen, M. Chen, Y. Zhao, X. Lin, Z. Qin, Y. Wang, L. Han, _Adv. Energy Mater._ **2023** , _13_ , 2203250. 

**2400205 (15 of 17)** 

_Adv. Energy Mater._ **2025** , _15_ , 2400205 

© 2024 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



### **www.advenergymat.de** 

- [73] H. Cheng, Y. Li, G. Zhao, K. Zhao, Z.-S. Wang, _ACS Appl. Mater. Interfaces._ **2019** , _11_ , 28960. 

- [74] X. Zhu, C. F. J. Lau, K. Mo, S. Cheng, Y. Xu, R. Li, C. Wang, Q. Zheng, Y. Liu, T. Wang, Q. Lin, Z. Wang, _Nano Energy._ **2022** , _103_ , 107849. 

- [75] L. Li, Y. Wang, X. Wang, R. Lin, X. Luo, Z. Liu, K. Zhou, S. Xiong, Q. Bao, G. Chen, Y. Tian, Y. Deng, K. Xiao, J. Wu, M. I. Saidaminov, H. Lin, C.-Q. Ma, Z. Zhao, Y. Wu, L. Zhang, H. Tan, _Nat. Energy._ **2022** , _7_ , 708. 

- [76] Z. Li, X. Sun, X. Zheng, B. Li, D. Gao, S. Zhang, X. Wu, S. Li, J. Gong, J. M. Luther, Z. Li, Z. Zhu, _Science._ **2023** , _382_ , 284. 

- [77] A. Abrusci, S. D. Stranks, P. Docampo, H.-L. Yip, A. K.-Y. Jen, H. J. Snaith, _Nano Lett._ **2013** , _13_ , 3124. 

- [78] K. Wojciechowski, S. D. Stranks, A. Abate, G. Sadoughi, A. Sadhanala, N. Kopidakis, G. Rumbles, C.-Z. Li, R. H. Friend, A. K.-Y. Jen, H. J. Snaith, _ACS Nano._ **2014** , _8_ , 12701. 

- [79] Y. Dong, W. Li, X. Zhang, Q. Xu, Q. Liu, C. Li, Z. Bo, _Small._ **2016** , _12_ , 1098. 

- [80] J. Wu, J. Shi, Y. Li, H. Li, H. Wu, Y. Luo, D. Li, Q. Meng, _Adv. Energy Mater._ **2019** , _9_ , 1901352. 

- [81] Z. Chen, Y. Li, Z. Liu, J. Shi, B. Yu, S. Tan, Y. Cui, C. Tan, F. Tian, H. Wu, Y. Luo, D. Li, Q. Meng, _Adv. Energy Mater._ **2023** , _13_ , 2202799. 

- [82] B. Li, Y. Chen, Z. Liang, D. Gao, W. Huang, _RSC Adv._ **2015** , _5_ , 94290. 

- [83] Y. C. Shih, L. Y. Wang, H. C. Hsieha, K. F. Lin, _J. Mater. Chem. A._ **2015** , _3_ , 9133. 

- [84] F. Han, G. Hao, Z. Wan, J. Luo, J. Xia, C. Jia, _Electrochim. Acta._ **2019** , _296_ , 75. 

- [85] J. Cao, J. Yin, S. Yuan, Y. Zhao, J. Li, N. Zheng, _Nanoscale._ **2015** , _7_ , 9443. 

- [86] S. Y. Abate, D.-C. Huang, Y.-T. Tao, _Org. Electron._ **2020** , _78_ , 105583. 

- [87] L. Liu, A. Mei, T. Liu, P. Jiang, Y. Sheng, L. Zhang, H. Han, _J. Am. Chem. Soc._ **2015** , _137_ , 1790. 

- [88] Y. Shi, H. Zhang, X. Tong, X. Hou, F. Li, Y. Du, S. Wang, Q. Zhang, P. Liu, X. Zhao, _Sol. RRL._ **2021** , _5_ , 2100128. 

- [89] Z. Dai, S. K. Yadavalli, M. Chen, A. Abbaspourtamijani, Y. Qi, N. P. Padture, _Science._ **2021** , _372_ , 618. 

- [90] L. Zuo, Q. Chen, N. De Marco, Y.-T. Hsieh, H. Chen, P. Sun, S.-Y. Chang, H. Zhao, S. Dong, Y. Yang, _Nano Lett._ **2017** , _17_ , 269. 

- [91] J. Du, L. Feng, X. Guo, X. Huang, Z. Lin, J. Su, Z. Hu, J. Zhang, J. Chang, Y. Hao, _J. Power Sources._ **2020** , _455_ , 227974. 

- [92] X. Sun, H. Jiang, Y. Sun, Z. Guo, Z. Pang, F. Wang, J. Yang, L. Yang, _Electrochim. Acta._ **2022** , _428_ , 140930. 

- [93] X. Zuo, B. Kim, B. Liu, D. He, L. Bai, W. Wang, C. Xu, Q. Song, C. Jia, Z. Zang, D. Lee, X. Li, J. Chen, _Chem. Eng. J._ **2022** , _431_ , 133209. 

- [94] M. Hou, H. Zhang, Z. Wang, Y. Xia, Y. Chen, W. Huang, _ACS Appl. Mater. Interfaces._ **2018** , _10_ , 30607. 

- [95] C. Tian, K. Lin, J. Lu, W. Feng, P. Song, L. Xie, Z. Wei, _Small Methods._ **2020** , _4_ , 1900476. 

- [96] K. Liu, S. Chen, J. Wu, H. Zhang, M. Qin, X. Lu, Y. Tu, Q. Meng, X. Zhan, _Energy Environ. Sci._ **2018** , _11_ , 3463. 

- [97] Q. Zhang, C. S. Dandeneau, X. Zhou, G. Cao, _Adv. Mater._ **2009** , _21_ , 4087. 

- [98] L. Zuo, Z. Gu, T. Ye, W. Fu, G. Wu, H. Li, H. Chen, _J. Am. Chem. Soc._ **2015** , _137_ , 2674. 

- [99] J. Han, H. Kwon, E. Kim, D.-W. Kim, H. J. Son, D. H. Kim, _J. Mater. Chem. A._ **2020** , _8_ , 2105. 

- [100] R. Azmi, W. T. Hadmojo, S. Sinaga, C.-L. Lee, S. C. Yoon, I. H. Jung, S.-Y. Jang, _Adv. Energy Mater._ **2018** , _8_ , 1701683. 

- [101] D. Liu, Y. Wang, Z. She, H. Zheng, P. Zhang, F. Wang, J. Wu, Z. Chen, S. Li, _Sol. RRL._ **2018** , _2_ , 1800240. 



**JiajiaSuo** obtainedhisPhDfromtheShanghaiInstituteofOrganicChemistry,ChineseAcademyof Sciences,in2018,workingonpalladium-catalyzedasymmetricorganicsynthesis.Subsequently,he conductedpostdoctoralresearchatÉcolePolytechniqueFédéraledeLausanne(EPFL)andUppsala UniversityunderthesupervisionofProf.AndersHagfeldt,specializinginthefundamentalstudyof dye-sensitizedsolarcellsandperovskitesolarcells.Currently,heisaresearcheratUppsalaUniversity dedicatedtoadvancingthesustainabledevelopmentoffuturephotovoltaicmaterials. 



**BowenYang** iscurrentlyaResearcherattheDepartmentofPhysicalChemistryatUppsalaUniversity, Sweden.SheobtainedherPhDin2018fromtheDepartmentofEnvironmentalEngineering,Clean EnergyCenterattheUniversityofConnecticut,USA.ShethenworkedasaScientistwithProf.Anders Hagfeldtfrom2018to2021intheLaboratoryofPhotomolecularScienceattheÉcolepolytechnique fédéraledeLausanne(EPFL),Switzerland.Hercurrentresearchfocusesonobtaininghighlyefficient andstableperovskitesolarcellsthroughmaterialanddeviceengineering. 

**2400205 (16 of 17)** 

_Adv. Energy Mater._ **2025** , _15_ , 2400205 

© 2024 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



### **www.advenergymat.de** 







|**DmitryBogachuk**hasobtainedanMScdegreeinSustainableSystemsEngineeringatAlbert-Ludwigs<br>UniversitätFreiburg,Germanyspecializinginphotovoltaicsandfunctionalnanomaterials.In2019he<br>wasawardedascholarshipfromtheGermanFederalEnvironmentalFoundation(DBU)toconduct<br>hisPhDstudiesontheefficient,stable,printableperovskitesolarmoduleswithlowCO2footprintat<br>FraunhoferISE.In2023hereceivedaprestigiousEva-Mayr-StihlYoungTalentAwardforhisPhDthe-<br>sis,whichhecompletedwitha_summacumlaude_predicate.Currently,heisaChiefScientistatSolarlab<br>AikoEuropeGmbHsupervisingresearchactivitiesrelatedtothedevelopmentofperovskite/silicon<br>tandemphotovoltaicdevices.|
|---|
|**GerritBoschloo**isaprofessorofphysicalchemistryatUppsalaUniversity(Sweden),whereheleadsa<br>researchgroupfocusingonperovskitesolarcells,dye-sensitizedsolarcells,andfundamentalstudies<br>ofthesemiconductor/electrolyteinterface.HereceivedhisPhDin1996atDelftUniversityofTech-<br>nology(theNetherlands).Heistheauthorofmorethan280peer-reviewedpapers(h-index87)and6<br>patentsandisco-founderofthecompanyDyenamoAB.|
|**AndersHagfeldt**hasbeenVice-ChancellorofUppsalaUniversitysince2021andProfessorofPhys-<br>icalChemistry.HeobtainedhisPhDatUppsalaUniversityin1993.HewasProfessorattheÉcole<br>PolytechniqueFédéraledeLausannein2014–2020.Hisresearchhasfocusedonthefieldsofdye-<br>sensitizedsolarcells,perovskitesolarcells,andsolarfuels.Hehaspublishedmorethan630scientific<br>papersthathavereceivedover139,481citations.Heisamemberofseveralacademiesincludingthe<br>RoyalSwedishAcademyofSciencesandtheRoyalSwedishAcademyofEngineeringSciences,Swe-<br>den.HeholdsanHonoraryDoctoratefromUniversitéParisCité,France.|



**2400205 (17 of 17)** 

_Adv. Energy Mater._ **2025** , _15_ , 2400205 

© 2024 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

