# Multifunctional ytterbium oxide buffer for perovskite solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 196 |
| 作者 | Peng Chen, Yun Xiao, Jun-Tao Hu, Shun-De Li, De-Ying Luo, R. Su, Pietro Caprioglio, P. Kaienburg et al. |
| DOI | 10.1038/s41586-023-06892-x |
| 源文件 | 038_Chen_2024_Multifunctional-ytterbium-oxide-buffer-for-perov.pdf |

---
- 1 **Multifunctional ytterbium oxide buffer for perovskite solar cells** 

- 2 Authors: Peng Chen<sup>1,11</sup> , Yun Xiao<sup>2,11</sup> , Juntao Hu<sup>3,10,11</sup> , Shunde Li<sup>1,11</sup> , Deying Luo<sup>4</sup> *, Rui 

- 3 Su<sup>1</sup> , Pietro Caprioglio<sup>2</sup> , Pascal Kaienburg<sup>2</sup> , Xiaohan Jia<sup>1</sup> , Nan Chen<sup>3</sup> , Jingjing Wu<sup>5</sup> , 

- 4 Yanping Sui<sup>5</sup> , Pengyi Tang<sup>5</sup> , Haoming Yan<sup>1</sup> , Tianyu Huang<sup>1</sup> , Maotao Yu<sup>1</sup> , Qiuyang Li<sup>1</sup> , 

- 5 Lichen Zhao<sup>1</sup> , Cheng-Hung Hou<sup>6</sup> , Yun-Wen You<sup>6</sup> , Jing-Jong Shyue<sup>6</sup> , Dengke Wang<sup>3</sup> , 

- 6 Xiaojun Li<sup>7</sup> , Qing Zhao<sup>1</sup> , Qihuang Gong<sup>1,8,9</sup> *, Zheng-Hong Lu<sup>3,4</sup> *, Henry J. Snaith<sup>2</sup> *, Rui 

- 7 Zhu<sup>1,8,9</sup> * 

- 8 1State Key Laboratory for Artificial Microstructure and Mesoscopic Physics, School of 

- 9 Physics, Frontiers Science Center for Nano-optoelectronics & Collaborative Innovation 

- 10 Center of Quantum Matter, Peking University, 100871 Beijing, China 

- 11 2Clarendon Laboratory, Department of Physics, University of Oxford, Oxford OX1 3PU, 

- 12 UK 

- 13 3Department of Physics, Center for Optoelectronics Engineering Research, Yunnan 

- 14 University, 650091 Kunming, China 

- 15 4Department of Materials Science and Engineering, University of Toronto, Toronto, 

- 16 Ontario M5G 3E4, Canada 

1 

- 17 5State Key Laboratory of Information Functional Materials, 2020 X-Lab, Shanghai 

- 18 Institute of Microsystem and Information Technology, Chinese Academy of Sciences, 

- 19 Shanghai 200050, China 

- 20 6Research Center for Applied Sciences, Academia Sinica, Taipei 11529, Taiwan 

- 21 7Beijing National Laboratory for Molecular Sciences, CAS Key Laboratory of Organic 

- 22 Solids, Institute of Chemistry, Chinese Academy of Sciences, Beijing, 100190 China 

- 23 8Peking University Yangtze Delta Institute of Optoelectronics, Nantong, 226010 Jiangsu, 

- 24 China 

- 25 9Collaborative Innovation Center of Extreme Optics, Shanxi University, Taiyuan, 030006 

- 26 Shanxi, China 

- 27 10Present address: Department of Physics, Mathematics and Computer Science, Faculty of 

- 28 Basic Medical Science, Kunming Medical University, Kunming, 650500, Yunnan, China 

- 29 11These authors contributed equally to this work 

- 30 *Correspondence: deying.luo@utoronto.ca (D.L.); qhgong@pku.edu.cn (Q.G.); 

- 31 <u>zhenghong.lu@utoronto.ca (Z.-H.L.); henry.snaith@physics.ox.ac.uk</u> (H.J.S.); 

- 32 <u>iamzhurui@pku.edu.cn</u> (R.Z.) 

- 33 

2 

- 34 **Summary** 

- 35 **Perovskite solar cells (PSCs) comprise a solid perovskite absorber sandwiched** 

- 36 **between multiple layers of different charge-selective materials, ensuring uni-** 

- 37 **directional current flow and high voltage output of the devices**<sup>**1,2**</sup> **. A “buffer material”** 

- 38 **between the electron-selective layer (ESL) and the metal electrode in p-** 

- 39 **type/intrinsic/n-type (p-i-n) PSCs (also known as inverted PSCs) allows electrons to** 

- 40 **flow from the ESL to the electrode**<sup>**3-5**</sup> **. Also, it acts as a barrier inhibiting the inter-** 

- 41 **diffusion of harmful species in or degradation products out of the perovskite** 

- 42 **absorber**<sup>**6-8**</sup> **. Thus far, evaporable organic molecules**<sup>**9,10**</sup> **and atomic-layer-deposited** 

- 43 **metal oxides**<sup>**11,12**</sup> **have proven successful, but each has specific imperfections. Here, we** 

- 44 **report a chemically stable and multifunctional buffer material, ytterbium oxide** 

- 45 **(YbO** **_x_ ), for p-i-n PSCs** **_via_ scalable thermal evaporation deposition. We employed this** 

- 46 **YbO** **_x_ buffer into the p-i-n PSCs with a narrow-bandgap (NBG) perovskite absorber,** 

- 47 **yielding a certified power conversion efficiency (PCE) of over 25%. We also** 

- 48 **demonstrate the broad applicability of YbO** **_x_ in enabling highly efficient PSCs from** 

- 49 **various types of perovskite absorber layers, delivering state-of-the-art efficiencies of** 

- 50 **20.1% for the wide-bandgap (WBG) perovskite absorber and 22.1% for the mid-** 

- 51 **bandgap (MBG) perovskite absorber, respectively. Moreover, when subjected to** 

3 

- 52 **ISOS-L-3 accelerated ageing, encapsulated devices with YbO** **_x_ exhibit markedly** 

- 53 **enhanced device stability.** 

- 54 

4 

- 55 The PCE of single-junction p-i-n PSCs (also referred to as inverted PSCs) has surpassed 

- 56 25% through passivation methodologies<sup>3-5,13-15</sup> . However, the published operational 

- 57 stability of p-i-n PSCs under stringent test conditions still lags behind commercially viable 

- 58 solar panels<sup>16-18</sup> . Though multiple factors are responsible for device degradation under 

- 59 operating conditions<sup>19-21</sup> , ion migration under realistic operational conditions represents a 

- 60 significant challenge as it is almost ubiquitous within a device. Electrical bias and 

- 61 illumination-induced ion migration within a perovskite absorber layer can inevitably vary 

- 62 the chemical composition at the nano- and micro-scale<sup>19,21,22</sup> , inducing higher chemical 

- 63 heterogeneity, increased non-radiative recombination centers and subsequent initial sites 

- 64 where device degradation occurs<sup>2,23</sup> . Furthermore, these mobile ions from the perovskite 

- 65 absorber can diffuse into the charge-selective layers and may accumulate at the metal 

- 66 electrode interface. The accumulated ions have been proven to corrode the metal 

- 67 electrodes<sup>7,24</sup> , damaging the integrity of the metal electrode and degrading device stability. 

- 68 Another key concern for long-term instability is the metal diffusion into the electron- 

- 69 selective and perovskite layers, which may lead to the formation of metal halides and 

- 70 weakened device stability<sup>7,25,26</sup> . 

- 71 Attempting to introduce an effective buffer layer between the ESL and the metal electrode 

- 72 to block atom and ion movement between the perovskite and metal layers (in both 

- 73 directions, **<mark>Extended Data Fig. 1a</mark>** <mark>)</mark> is of technological interest in improving overall device 

5 

- 74 performance<sup>6-8</sup> . In this case, the buffer layer must facilitate the directional flow of electrons 

- 75 from the buffer to the metal electrode, ensuring efficient electron collection of the PSCs. 

- 76 The method for depositing the buffer layer must be compatible with underlying materials 

- 77 such as (6,6)-Phenyl C61 butyric acid methyl ester (PCBM) and C60. Moreover, an ideal 

- 78 buffer layer can effectively prevent the permeation of external harmful species like oxygen 

- 79 and moisture from the air. To date, bathocuproine (BCP), the most commonly used buffer 

- 80 material, can be processed with scalable thermal evaporation in p-i-n PSCs<sup>5,9</sup> . 

- 81 Unfortunately, BCP suffers from poor thermal stability under the protocol temperature of 

- 82 85℃ by the International Summit on Organic Photovoltaic Stability (ISOS) protocols, 

- 83 which will likely limit long-term operational stability<sup>12,22,27-29</sup> . Low work-function oxides, 

- 84 including zinc oxide (ZnO) nanoparticles, compact tin oxide (SnO2) layer, and aluminum- 

- 85 doped zinc oxide (AZO) nanoparticles, have also been applied as buffer materials in p-i-n 

- 86 PSCs to replace the BCP or to form bilayer buffers<sup>11,12</sup> . Yet, these oxides either are 

- 87 challenging for large-scale fabrication or require dedicated instruments and expensive 

- 88 fabrication precursors, which contradicts cost-effective practical applications. An 

- 89 intrinsically stable and multifunctional material, YbO _x_ , which can be deposited by the 

- 90 scalable thermal evaporation approach, is a compelling buffer material for efficient and 

- 91 stable p-i-n PSCs. 

- 92 **Properties of ytterbium oxide** 

6 

- 93 Yb with a low Gibbs free energy has a strong tendency to form YbO _x_ when exposed to 

- 94 oxygen ( **Supplementary Note 1, Extended Data Fig. 1b** ). The YbO _x_ that can be processed 

- 95 with thermal evaporation ( **Extended Data Fig. 1c** ) shows great promise of commercial 

- 96 applications ( **Supplementary Note 2, Supplementary Tables 1 and 2** ). To understand the 

- 97 oxidation of Yb, we first thermally evaporated a few nanometers of Yb films on a large- 

- 98 scale indium tin oxide (ITO) substrate (100 cm<sup>2</sup> ) in the device fabrication vacuum chamber 

- 99 with a base pressure of 10<sup>–4</sup> Pa. The sampling data from different areas of the sample shows 

- 100 identical YbO _x_ states ( **<mark>Extended Data Fig. 2</mark>** <mark>)</mark> . This rapid oxidation associated with metal 

- 101 Yb is further demonstrated by the color change of the polished Yb metal surfaces before 

- 102 and after oxidation ( **<mark>Extended Data Fig. 3</mark>** ). We then studied the detailed oxidation 

- 103 dynamics of the clean Yb<sup>0</sup> surface by tracking the oxidation process over time using in-situ 

- 104 photoelectron X-ray spectroscopy (XPS) ( **<mark>Extended Data Fig. 4, Supplementary Table</mark>** 

- 105 **3** ). These results indicate that the Yb film (with a thickness of a few nanometers) deposited 

- 106 on the large-area ITO substrate can be fully oxidized in a few minutes when upscaling in a 

- 107 device fabrication vacuum chamber with a base pressure of 10<sup>–4</sup> Pa (see details in 

- 108 **Supplementary Note 3** ). Such benefits eliminate the additionally dedicated oxidation step, 

- 109 which is usually required for other oxides processed with thermal evaporation<sup>30</sup> . 

- 110 **Fig. 1a-c** shows the high-resolution TEM (HRTEM) images and the corresponding fast 

- 111 Fourier transform (FFT) patterns of the Yb film. The HRTEM images and FFT patterns 

7 

- 112 feature the crystalline structure corresponding to a face-centered cubic system with space 

- 113 group 225 (Fm3m) visualized from [0-11] direction in the selected red rectangle region. 

- 114 By clarifying the Yb natural oxidation through XPS spectra ( **Fig. 1d, e** )<sup>31,32</sup> , the resulting 

- 115 YbO _x_ exhibits a broad and continuous halo in the typical FFT pattern, indicative of the 

- 116 amorphous atomic arrangement ( **Extended Data Fig. 5** )<sup>33</sup> . The amorphous characteristics 

- 117 of the YbO _x_ films are also confirmed through grazing-incidence wide-angle X-ray 

- 118 scattering (GIWAXS) ( **Extended Data Fig. 6** ). The energy-dispersive X-ray (EDX) 

- 119 chemical composition map for the YbO _x_ film suggests a spatially homogeneous distribution 

- 120 of both Yb and O elements in the films is spatially homogeneous ( **Supplementary Fig. 1** ). 

- 121 The reflection electron energy loss spectroscopy (REELS) spectrum shows the surface 

- 122 bandgap of the YbO _x_ is as high as 5.5 eV ( **Fig. 1f** )<sup>34</sup> , which is transparent to visible light 

- 123 wavelengths. Critical information associated with the electronic structure, including work 

- 124 function, valence band maximum (VBM), and conduction band minimum (CBM), are 

- 125 quantified by combining ultraviolet photoemission spectroscopy (UPS) analyses ( **Fig. 1g** ) 

- 126 with the REELS data. These results above suggest that the YbO _x_ film is n-type, with a 

- 127 Fermi level of 3.08 eV from the vacuum and a CBM of 1.26 eV from the vacuum ( **Fig. 1h** ). 

- 128 **Multifunctional role of interfacial YbO** **_x_** 

- 129 **Fig. 2** shows XPS data on the variation of chemical constituents in the electron-selective 

- 130 layer and its interface with the metal electrode measured from samples with (target) and 

8 

- 131 without (control) the YbO _x_ buffer layer before and after accelerated ageing in ambient air 

- 132 (relative humidity, 80%) at 80℃ for 5 h. The samples consist of 

- 133 substrate/perovskite/C60/Cu (control) and substrate/perovskite/C60/YbO _x_ /Cu (target). A 

- 134 mechanical lift-off approach was used to delaminate the Cu electrode from the rest of the 

- 135 sample stacks<sup>35</sup> . The delaminated Cu is referred to as the Cu side, and the other is the 

- 136 substrate side ( **Supplementary Fig. 2** ). **Supplementary Fig. 3** shows scanning electron 

- 137 microscope (SEM) images of the delaminated surfaces of both control and target samples. 

- 138 The buried organic C60 layer for the substrate side was removed using gas cluster ion beam 

- 139 (GCIB) sputtering in order to probe throughout the layer stack. 

- 140 **Fig. 2a, b** shows the Cu 2p XPS depth profiling of the substrate side before and after ageing. 

- 141 Note that the Cs Auger signal (highlighted in orange color) is used to probe the perovskite 

- 142 layer in this observation. The data show a noticeable decrease in the Cu 2p XPS peak 

- 143 intensity of the fresh control sample (without YbO _x_ ) after the 60 s of GCIB sputtering, and 

- 144 the Cu 2p XPS peak intensity is below the instrument limitation with increasing the 

- 145 sputtering time. In contrast, the Cu 2p XPS peaks for the aged control samples remain 

- 146 detectable after extended GCIB sputtering to such as 360 s ( **Fig. 2b** ). While at 720 s, Cu 

- 147 2p XPS peaks and significant Cs Auger signals are simultaneously detected for the aged 

- 148 control sample. This experimental observation indicates that Cu diffusion exists in the aged 

- 149 control samples. When the YbO _x_ buffer layer is inserted between the C60 and Cu, the 

9 

- 150 distribution of the Cu species into the C60 and perovskite underneath is not detected for 

- 151 both fresh and aged target samples, as shown in **Fig. 2c** . Next, we probed the chemical 

- 152 changes on the delaminated Cu surfaces of both control and target samples by tracking the 

- 153 Cu LMM Auger peaks of the delaminated Cu side after ageing. A peak exists at around 

- 154 571 eV for the aged control sample without YbO _x_ ( **Fig. 2d** ). This result indicates that Cu 

- 155 oxidation happens in the aged control samples, consistent with the color change of the Cu 

- 156 electrode (control) after accelerated ageing in ambient air (relative humidity, 80%) at 80℃ 

- 157 for 5 h ( **Supplementary Fig. 4** ). However, the Cu oxidation peak is not observed in the 

- 158 aged target samples (with YbO _x_ ) ( **Fig. 2e** )<sup>23,36</sup> . The depth-profiling data show that the 

- 159 chemical state of the YbO _x_ remains the same throughout the thickness before and after 

- 160 accelerated ageing ( **Fig. 2f** ). 

- 161 The UPS depth profiling analysis based on the real device stacks reveals that the insertion 

- 162 of YbO _x_ can reduce the work function of the contact interface compared to the control 

- 163 sample without YbO _x_ ( **Supplementary Fig. 5** ). One such variation brings a positive impact 

- 164 on electron collection at the Cu electrode interface. To reveal the charge-carrier transport 

- 165 properties of the YbO _x_ buffer, two devices with 20 alternative layers of YbO _x_ (2 nm) and 

- 166 YbO _x_ (5 nm)/Cu (1 nm) [for example, ITO/[YbO _x_ (2 nm)]20/Cu (100 nm) and ITO/[YbO _x_ 

- 167 (5 nm)/Cu (1 nm)]20/Cu (100 nm)] were prepared. We confirm that the YbO _x_ used in the 

- 168 charge-carrier transport measurements shows no metallic states and instead exhibits a 

10 

- 169 considerable density of in-gap states near the Fermi level ( **Extended Data Fig. 7a, b** ). By 

- 170 measuring the temperature dependence of current density _−_ voltage ( _J−V_ ) characteristics of 

- 171 the devices with ITO/[YbO _x_ (2 nm)]20/Cu (100 nm) and ITO/[YbO _x_ (5 nm)/Cu (1 nm)]20/Cu 

- 172 (100 nm) ( **Extended Data Fig. 7c, d** and **Extended Data Fig. 8** ), we find that the charge- 

- 173 carrier transport inside the YbO _x_ follows a phonon-assisted electron hopping from one 

- 174 localized state to another rather than through the drift of Bloch wave described in the typical 

- 175 energy-band theory ( **Supplementary Note 4)** . This physical process was originally 

- 176 proposed by Mott<sup>37</sup> , who gave the temperature-conductivity dependence law below: 

- 177 

1 𝜎= 𝜎0 𝑒𝑥𝑝( −𝐵/𝑇4)                                                  (1) 

- 178 where _σ_ 0 is a pre-factor, and _B_ depends on the radial extension of the wave functions and 

- 179 density of states. Herein, we illustrate phonon-assisted electron hopping _via_ unoccupied 

- 180 localized states of the YbO _x_ buffer layer when electrons flow from C60 to Cu ( **Fig. 3a** ). 

- 181 **Photovoltaic performance enhancement** 

- 182 To assess the impact of the YbO _x_ buffer layer on device performance, we fabricated full 

- 183 devices using perovskites with three different typical bandgaps. The cross-sectional and 

- 184 top-view SEM images for these perovskites are shown in **Supplementary Fig. 6** . 

- 185 **Supplementary Fig. 7** displays the optoelectronic properties of the associated perovskites 

- 186 with various bandgaps. Firstly, we evaluated the photovoltaic performances of the p-i-n 

- 187 PSCs based on an NBG perovskite absorber [Rb0.05Cs0.05MA0.05FA0.85Pb(I0.95Br0.05)3]. The 

11 

- 188 perovskite absorber was post-treated with 3-(Aminomethyl)pyridine to suppress non- 

- 189 radiative recombination at the interface<sup>3</sup> . **Fig. 3b** displays device configurations of the p-i- 

- 190 n PSCs with YbO _x_ and illustrates the amorphous nature of the YbO _x_ buffer. The optimal 

- 191 thickness for the YbO _x_ layer in this work is around 1.5 nm ( **Supplementary Fig. 8** ). 

- 192 From _J−V_ scanned results, the champion PSC with YbO _x_ exhibits a remarkable PCE of 

- 193 25.2% [an open-circuit voltage ( _V_ OC) of 1.16 V, a fill factor (FF) of 0.83, and a short-circuit 

- 194 current density ( _J_ SC) of 26.1 mA cm<sup>−2</sup> ] ( **Fig. 3c** and **Extended Data Table 1** ). The steady- 

- 195 state power output (SPO) of our YbO _x_ -based p-i-n PSCs is ∼24.7% under standard 

- 196 simulated 1-sun illumination, AM 1.5G irradiance ( **Fig. 3c** ), and the YbO _x_ -based devices 

- 197 show negligible hysteresis in nature ( **Supplementary Fig. 9** ). Note that a MgF2 

- 198 antireflection coating was used to minimize the light reflection therefore to maximize the 

- 199 photocurrent of the p-i-n PSCs ( **Supplementary Table 4** ). To further validate our finding, 

- 200 we sent one of our non-encapsulated YbO _x_ -based NBG PSCs to an accredited institution 

- 201 of the Photovoltaic and Wind Power Systems Quality Test Center (Chinese Academy of 

- 202 Science, China) for external certification. We obtained a certified PCE of 25.09% 

- 203 ( **Supplementary Fig. 10** ), which is among the highest PCEs of p-i-n PSCs and represents 

- 204 the best PCE of p-i-n PSCs with an inorganic buffer layer ( **Supplementary Tables 5 and** 

- 205 **6** ). Our experiments further validate the universality of the YbO _x_ buffer layer in the p-i-n 

- 206 PSCs with MBG and WBG perovskite absorbers. The MBG PSCs with YbO _x_ deliver 

12 

- 207 decent performance with a champion PCE of 22.1% ( **Fig. 3d** ). In particular, the YbO _x_ - 

- 208 based WBG devices yield an impressive PCE of up to 20.1% [a _V_ OC of 1.30 V, an FF of 

- 209 0.82 and a _J_ SC of 18.6 mA cm<sup>−2</sup> ] **(Fig. 3e** ). To our knowledge, this respectful PCE is among 

- 210 the highest PCEs for p-i-n PSCs with WBGs of 1.75−1.80 eV ( **Supplementary Table 7** ). 

- 211 Moreover, we find that p-i-n PSCs with YbO _x_ show high reproducibility and minor batch- 

- 212 to-batch variations in device performance regardless of the perovskite bandgap ( **Fig. 3f** , 

- 213 **Supplementary Figs. 11, 12** ). 

- 214 It is clear that all these p-i-n PSCs have achieved prominent _V_ OC in **Fig. 3g** , which are close 

- 215 to or even surpass 90% of the radiative limit versus the bandgap energy<sup>38</sup> . Furthermore, 

- 216 external quantum efficiencies of the electroluminescence (EQEELs) for the YbO _x_ -based p- 

- 217 i-n PSCs with NBG and WBG perovskite absorbers ( **Supplementary Fig. 13** ) present 5.12% 

- 218 (NBG) and 0.97% (WBG), respectively. Under such conditions, derived from the EQEEL, 

- 219 we calculated the QFLS values of the PSCs containing the different absorbers to be 1.159 

- 220 eV (NBG) and 1.289 eV (WBG), respectively, consistent with the obtained _V_ OC from the 

- 221 _J−V_ scans ( **Supplementary Note 5** ). Moreover, the integrated _J_ SC values of the champion 

- 222 NBG-, MBG-, and WBG-based PSCs, where their bandgaps are calculated to be 1.54 eV, 

- 223 1.59 eV, and 1.77 eV ( **Supplementary Fig. 14** ), are 25.7 mA cm<sup>−2</sup> , 22.1 mA cm<sup>−2</sup> , and 

- 224 18.3 mA cm<sup>−2</sup> , respectively ( **Fig. 3h** ). 

- 225 **Thermal and operational stability** 

13 

- 226 We tested the thermal stability of the PSCs with BCP or YbO _x_ (encapsulated using glass 

- 227 covers sealed by epoxy resin). The encapsulated PSCs are stored at 85°C in the dark in a 

- 228 nitrogen-filled glovebox. **Fig. 4a** compares results of the thermal stability for the NBG- 

- 229 based PSCs with BCP or YbO _x_ buffer layers. Compared to the PSCs with BCP, the YbO _x_ - 

- 230 based device exhibits a slight increase in the PCEs initially (<100 h) and retains 98% of its 

- 231 initial PCE after 500 h. By contrast, the BCP-based device shows a sharp PCE drop upon 

- 232 exerting thermal stress, and only 82% of its initial PCE can be retained after 500 h. 

- 233 Similarly, in the WBG-based PSCs, the YbO _x_ -based device exhibits enhanced thermal 

- 234 stability ( **Fig. 4b** ). However, the WBG-PSCs with either BCP or YbO _x_ buffer layers 

- 235 degrade at faster rates compared to NBG-based PSCs. Such a difference correlates with the 

- 236 inherently poor stability of the WBG perovskite with a high bromide ratio<sup>39,40</sup> . Nonetheless, 

- 237 the WBG-based PSCs with YbO _x_ can still retain 80% of its initial PCE after 500 h, whereas 

- 238 the BCP-based device drops quickly to 75% of its initial PCE in the initial 24 h and 

- 239 approximately 57% of device performance after 500 h. 

- 240 We also examined the long-term operational stability tracking at the maximum power 

- 241 output under 1-sun illumination with and without thermal stress. The tested PSCs were also 

- 242 encapsulated and continuously illuminated by a white light-emitting diode (LED) array 

- 243 with an intensity equivalent to 100 mW cm<sup>−2</sup> of AM 1.5G irradiance without active cooling. 

- 244 The most stable NBG-based device with YbO _x_ maintained its initial performance for 800 

14 

- 245 h, and retained 97% of the initial PCE (23.5%) after 1000 h ( **Fig. 4c** ). In comparison, the 

- 246 NBG-based device with BCP dropped quickly to 96% of the initial PCE after 213 h 

- 247 ( **Supplementary Fig. 15** ). Notably, when subjected to multiple external stress (complied 

- 248 with ISOS-L-3 protocols), compared to the BCP-based device, the encapsulated YbO _x_ - 

- 249 based device still exhibits improved long-term operational stability tracking at maximum 

- 250 power output point at 85°C in ambient air (relative humidity, 50%) ( **Fig. 4d** and 

- 251 **Supplementary Figs. 16, 17** ). Specifically, the encapsulated devices with YbO _x_ retain ~85% 

- 252 of its initial PCE (23.6%) after 500 h, which is comparable to p-i-n PSCs with SnO2 

- 253 ( **Supplementary Table 8** ). By contrast, the BCP-based device only retains 60% of the 

- 254 initial PCE after 213 h under ISOS-L-3 test qualifications. These results indicate that the 

- 255 PSCs with the YbO _x_ buffer show more substantial resistance to external stress than the 

- 256 regular BCP-containing ones, consistent with our observation above. Note that although 

- 257 enhanced device stability of p-i-n PSCs employing BCP buffer layers in conjunction with 

- 258 Cr/Au electrodes has been reported in the past<sup>41</sup> , such a multilayer buffer makes the device 

- 259 much more complex, and Au is not a scalable metal owing to its high cost ( **Supplementary** 

- 260 **Table 2** ). 

- 261 To gain more insights into the device stability improvements, we then conducted time-of- 

- 262 flight secondary ions mass spectrometry (TOF-SIMS) measurements on full PSC devices 

- 263 with BCP or YbO _x_ before and after ageing. Combining the TOF-SIMS with the depth- 

15 

- 264 profile XPS results ( **Fig. 2** , **Extended Data Fig. 9** , and **Supplementary Fig. 18** ), we 

- 265 demonstrate that replacing BCP with YbO _x_ can suppress undesirable bi-directional harmful 

- 266 species movements (such as I<sup>–</sup> , Cs<sup>+</sup> , Rb<sup>+</sup> , and Cu), and we find that the YbO _x_ is chemically 

- 267 unreactive with the perovskites ( **Fig. 4e-g** , see details in **Supplementary Note 6)** . Hence, 

- 268 we conclude that multifunctional YbO _x_ is advantageous for use as the buffer material from 

- 269 various evaluation angles ( **Supplementary Fig. 19** ). 

- 270 **References** 

- 271 1 Jena, A. K., Kulkarni, A. & Miyasaka, T. Halide perovskite photovoltaics: 272 Background, status, and future prospects. _Chem. Rev._ **119,** 3036-3103 (2019). 

- 273 2 Luo, D., Su, R., Zhang, W., Gong, Q. & Zhu, R. Minimizing non-radiative 274 recombination losses in perovskite solar cells. _Nat. Rev. Mater._ **5,** 44-60 (2019). 

- 275 3 Jiang, Q. _et al._ Surface reaction for efficient and stable inverted perovskite solar 

- 276 cells. _Nature_ **611,** 278-283 (2022). 

- 277 4 Tan, Q. _et al._ Inverted perovskite solar cells using dimethylacridine-based dopants. 

- 278 _Nature_ **620,** 545-551 (2023). 

- 279 5 Peng, W. _et al._ Reducing nonradiative recombination in perovskite solar cells with 

- 280 a porous insulator contact. _Science_ **379,** 683-690 (2023). 

- 281 6 Wu, S. _et al._ 2D metal-organic framework for stable perovskite solar cells with 282 minimized lead leakage. _Nat. Nanotechnol._ **15,** 934-940 (2020). 

16 

|283|7|Wu, S._et al._A chemically inert bismuth interlayer enhances long-term stability of|
|---|---|---|
|284||inverted perovskite solar cells._Nat. Commun._ **10,**1-10 (2019).|
|285|8|Zhang, S._et al._Barrier designs in perovskite solar cells for long-term stability._Adv._|
|286||_Energy Mater._ **10,**2001610 (2020).|
|287|9|Luo, D._et al._Enhanced photovoltage for inverted planar heterojunction perovskite|
|288||solar cells._Science_ **360,**1442-1446 (2018).|
|289|10|Fei, C._et al._Lead-chelating hole-transport layers for efficient and stable perovskite|
|290||minimodules._Science_ **380,**823-829 (2023).|
|291|11|Li, C._et al._Rational design of lewis base molecules for stable and efficient inverted|
|292||perovskite solar cells._Science_ **379,**690-694 (2023).|
|293|12|Azmi, R._et al._Damp heat–stable perovskite solar cells with tailored-dimensionality|
|294||2D/3D heterojunctions._Science_ **376,**73-77 (2022).|
|295|13|Zhang, S._et al._Minimizing buried interfacial defects for efficient inverted|
|296||perovskite solar cells._Science_ **380,**404-409 (2023).|
|297|14|Park, S. M._et al._Low-loss contacts on textured substrates for inverted perovskite|
|298||solar cells._Nature_**,**DOI:10.1038/s41586-41023-06745-41587 (2023).|
|299|15|Liang, Z._et al._Out-of-plane cations homogenise perovskite composition for solar|
|300||cells._Nature_**,**DOI:10.1038/s41586-41023-06784-41580 (2023).|
|301|16|Li, B. & Zhang, W. Improving the stability of inverted perovskite solar cells|
|302||towards commercialization._Commun. Mater._ **3,**65 (2022).|



17 

|303|17|Duan, L._et al._Stability challenges for the commercialization of perovskite–silicon|
|---|---|---|
|304||tandem solar cells._Nat. Rev. Mater._ **8,**261-281 (2023).|
|305|18|Zhu, H._et al._Long-term operating stability in perovskite photovoltaics._Nat. Rev._|
|306||_Mater._ **8,**569-586 (2023).|
|307|19|Macpherson, S._et al._Local nanoscale phase impurities are degradation sites in|
|308||halide perovskites._Nature_ **607,**294-300 (2022).|
|309|20|Guo, R._et al._Degradation mechanisms of perovskite solar cells under vacuum and|
|310||one atmosphere of nitrogen._Nat. Energy_ **6,**977-986 (2021).|
|311|21|Nazir, G._et al._Stabilization of perovskite solar cells: Recent developments and|
|312||future perspectives._Adv. Mater._ **34,**2204380 (2022).|
|313|22|Bai, S._et al._Planar perovskite solar cells with long-term stability using ionic liquid|
|314||additives._Nature_ **571,**245-250 (2019).|
|315|23|Hu, J. T._et al._Tracking the evolution of materials and interfaces in perovskite solar|
|316||cells under an electric field._Commun. Mater._ **3,**39 (2022).|
|317|24|Li, J., Dong, Q., Li, N. & Wang, L. Direct evidence of ion diffusion for the silver-|
|318||electrode-induced thermal degradation of inverted perovskite solar cells._Adv._|
|319||_Energy Mater._ **7,**1602922 (2017).|
|320|25|Domanski, K._et al._Not all that glitters is gold: Metal-migration-induced|
|321||degradation in perovskite solar cells._ACS Nano_ **10,**6306-6314 (2016).|



18 

|322|26|Li, X._et al._Constructing heterojunctions by surface sulfidation for efficient|
|---|---|---|
|323||inverted perovskite solar cells._Science_ **375,**434-437 (2022).|
|324|27|Li, X._et al._High-efficiency and durable inverted perovskite solar cells with|
|325||thermally-induced phase-change electron extraction layer._Adv. Energy Mater._ **11,**|
|326||2102844 (2021).|
|327|28|Kafafi, Z. H._et al._Low-power-consumption and long-lifetime OLED with a high|
|328||Tgn-type organic transport material._Proc. SPIE_ **5519,**263 (2004).|
|329|29|Khenkin, M. V._et al._Consensus statement for stability assessment and reporting|
|330||for perovskite photovoltaics based on isos procedures._Nat. Energy_ **5,**35-49 (2020).|
|331|30|Greiner, M. T._et al._Universal energy-level alignment of molecules on metal oxides.|
|332||_Nat. Mater._ **11,**76-81 (2011).|
|333|31|Ohno, Y. XPS studies of the intermediate valence state of Yb in (YbS)1.25CrS2._J._|
|334||_Electron Spectrosc. Relat. Phenom._ **165,**1-4 (2008).|
|335|32|Lang, W., Padalia, B., Watson, L. & Fabian, D. Reinvestigation of the core levels|
|336||of pure and oxidised ytterbium and lutetium._J. Electron Spectrosc. Relat. Phenom._|
|337||**7,**357-358 (1976).|
|338|33|He, Y._et al._Amorphizing noble metal chalcogenide catalysts at the single-layer|
|339||limit towards hydrogen production._Nat. Catalysis_ **5,**212-221 (2022).|



19 

- 340 34 Hu, J. T. _et al._ Damage-free depth profiling of electronic structures in multilayered 341 organic semiconductors by photoelectron spectroscopy and cluster ion beam. _Phys._ 342 _Status Solidi B_ **258,** 2100130 (2021). 343 35 Chen, P. _et al._ Refining perovskite heterojunctions for effective light-emitting solar 344 cells. _Adv. Mater._ **35,** 2208178 (2022). 345 36 Greiner, M. T., Chai, L., Helander, M. G., Tang, W.-M. & Lu, Z.-H. Metal/metal346 oxide interfaces: How metal contacts affect the work function and band structure 347 of MoO3. _Adv. Funct. Mater._ **23,** 215-226 (2013). 348 37 Mott, N. Electrons in glass. _Nature_ **257,** 15-18 (1975). 349 38 Oliver, R. D. J. _et al._ Understanding and suppressing non-radiative losses in 350 methylammonium-free wide-bandgap perovskite solar cells. _Energy Environ. Sci._ 351 **15,** 714-726 (2022). 

- 352 39 Tong, J. _et al._ Wide-bandgap metal halide perovskites for tandem solar cells. _ACS_ 353 _Energy Lett._ **6,** 232-248 (2020). 

- 354 40 Ganose, A. M., Scanlon, D. O., Walsh, A. & Hoye, R. L. Z. The defect challenge 355 of wide-bandgap semiconductors for photovoltaics and beyond. _Nat. Commun._ **13,** 356 1-4 (2022). 

- 357 41 Tremblay, M.-H. _et al._ Benzocyclobutene polymer as an additive for a 358 benzocyclobutene-fullerene: Application in stable p-i-n perovskite solar cells. _J._ 359 _Mater. Chem. A_ **9,** 9347-9353 (2021). 

20 

# 360 **Figure legends** 

- 361 **Fig. 1** | **Characterization of YbO** **_x_ films** . **a** , A general high-resolution transmission 

- 362 electron microscopy (HRTEM) image of the pure ytterbium film. The magnified HRTEM 

- 363 image ( **b** ) and the corresponding fast Fourier transform (FFT) patterns ( **c** ) of the red 

- 364 squared area selected in ( **a** ). X-ray photoemission spectroscopy (XPS) spectra of the Yb 4d 

- 365 corresponding to the Yb<sup>3+</sup> state ( **d** ) and O 1s ( **e** ). **f** , The reflection electron energy loss 

- 366 spectroscopy (REELS) spectrum of the YbO _x_ film. The inset shows how the band gap is 

- 367 determined. **g** , Ultraviolet photoelectron spectroscopy (UPS) spectra of the YbO _x_ film. Left, 

- 368 secondary electron cut-off (SECO) spectrum. Right, valence band (VB) spectrum. **h** , 

- 369 Energy levels of the YbO _x_ film. Key parameters shown are _E_ CBM (conduction band 

- 370 minimum), _E_ VBM (valence band maximum), _E_ F (Fermi level), and _E_ VAC (vacuum level). 

- 371 **Fig. 2** . | **Photoemission spectroscopy of the lift-off full devices.** Cu 2p XPS depth 

- 372 profiling using gas cluster ion beam (GCIB) sputtering (The sputtering rate for organic 

- 373 films is about 0.05 nm s<sup>–1</sup> using _N,N'_ -bis-(1-naphthyl)- _N,N'_ -diphenyl-1,1’ -biphenyl-4,4’ - 

- 374 diamine (NPB) as the reference) detected at the substrate side of ( **a** ) the fresh control 

- 375 (without YbO _x_ ) sample and ( **b** ) the aged control sample (after thermal annealing at 80°C 

- 376 in ambient air for 5 h). Control: substrate/perovskite/C60/Cu. **c** , Cu 2p XPS depth profiling 

- 377 detected at the substrate side of the fresh (up) and the aged (bottom) target samples (with 

- 378 YbO _x_ , after thermal annealing at 80°C in ambient air for 5 h). Target: 

21 

- 379 substrate/perovskite/C60/YbO _x_ /Cu. Cu LMM Auger spectra were detected at the Cu side of 

- 380 ( **d** ) the aged control sample and ( **e** ) the aged target sample (after thermal annealing at 80°C 

- 381 in ambient air for 5 h). The red line at the top shows the spectra difference, and this line is 

- 382 obtained by using the as-delaminated spectrum (0 s, blue lines at the middle) minus Cu<sup>0</sup> 

- 383 reference spectrum (black lines at the bottom)], which can be used to analyze chemical 

- 384 states. **f** , Yb 4d XPS depth profiling measured at the Cu side of the fresh target sample with 

- 385 YbO _x_ , before and after the accelerated ageing. 

- 386 **Fig. 3** . **| Photovoltaic performance. a** , Schematic illustration of the charge-carrier 

- 387 transport across the ESL/YbO _x_ /Cu interface. The carrier transport in the YbO _x_ buffer layer 

- 388 is by phonon-assisted electron hopping from one localized state to another. **b** , Schematic 

- 389 illustration of the device configuration of a typical p-i-n PSCs with the YbO _x_ buffer layer. 

- 390 The magnified area illustrates the amorphous nature of the YbO _x_ buffer layer used in our 

- 391 p-i-n PSCs. **c-e** , The current density−voltage ( _J_ − _V_ ) characteristics of the p-i-n PSCs with 

- 392 various bandgaps and these devices' steady-state power output (SPO) at the maximum 

- 393 power point under simulated AM 1.5 G illumination (inset). NBG, narrow bandgap. MBG, 

- 394 mid-bandgap. WBG, wide bandgap. **f** , Power-conversion-efficiencies (PCEs) distributions 

- 395 for p-i-n PSCs with NBG, MBG, and WBG bandgaps. The number of devices is 15 for 

- 396 each. **g** , Comparison of the _V_ OC of state-of-the-art p-i-n PSCs with varied bandgaps. Note 

- 397 that the data from the literature is based on the p-i-n PSCs with the BCP buffer layer. The 

22 

- 398 dashed line represents 90% of the radiative limit concerning the bandgap energy. **h** , The 

- 399 external quantum efficiency (EQE) spectra of the champion p-i-n PSCs with NBG, MBG, 

- 400 and WBG perovskites. 

- 401 **Fig. 4. | Stability of YbO** **_x_ -based p-i-n PSCs.** Variations of the PCEs of the encapsulated 

- 402 ( **a** ) NBG- and ( **b** ) WBG-containing PSCs with the BCP or YbO _x_ buffer layer aged in a 

- 403 nitrogen-filled glove box under 85°C in the dark. **c** , The maximum power point tracking 

- 404 (MPPT) curve of an encapsulated NBG-containing PSC with YbO _x_ under continuous 

- 405 illumination by using a white light-emitting diode (LED) array with an intensity of 100 

- 406 mW cm<sup>−2</sup> in a nitrogen atmosphere at about 40°C. **d** , The MPPT curve of an encapsulated 

- 407 NBG-containing PSC with YbO _x_ held at 85°C under 1-sun illumination and 50% relative 

- 408 humidity in ambient air (ISOS-L-3 conditions). The light source is a white light LED solar 

- 409 simulator with a simulated AM 1.5G spectrum. The temperature was controlled and 

- 410 monitored by polyimide heating film with a digital-displayed temperature controller. **e-g** , 

- 411 Evolutions of Pb 4f, I 3d, and Yb 4d XPS peaks of the perovskite/YbO _x_ bilayers as a 

- 412 function of the storage period in a nitrogen-filled glovebox. The perovskite film without 

- 413 the YbO _x_ is marked as “control”, and the perovskite/YbO _x_ bilayer is marked as “target.” 

- 414 **Methods** 

- 415 **Materials.** Lead diiodide (PbI2, 99%), lead dibromide (PbBr2, 99%), [2-(3,6-dimethoxy- 

- 416 9H-carbazol-9-yl)ethyl]phosphonic Acid (MeO-2PACz) and [2-(9H-Carbazol-9- 

23 

- 417 yl)ethyl]phosphonic Acid (2PACz) were purchased from Tokyo Chemical Industry Co., 

- 418 Ltd (TCI, Japan). Formamidinium iodide (FAI), methylammonium iodide (MAI), and 

- 419 methylammonium bromide (MABr) were purchased from Greatcell Solar. Rubidium 

- 420 iodide (RbI, >99.99%) was purchased from Alfa Aesar. Cesium iodide (CsI, >99.99%) and 

- 421 1-butyl-1-methylpiperidinium tetrafluoroborate ([BMP]<sup>+</sup> [BF4]<sup>−</sup> , 99%) were purchased 

- 422 from Sigma Aldrich (USA). [6,6]-phenyl-C61-butyric acid methyl ester (PCBM) was 

- 423 purchased from Nano-C Tech. (USA). Poly [bis (4-phenyl) (2, 4, 6-trimethylphenyl) amine] 

- 424 (PTAA, MW~13,000) and phenylethylammonium iodide (PEAI) were purchased from 

- 425 Xi’an Polymer Light Technology Corp (China). Nickle oxide (NiO _x_ ) nanoparticles, C60, 

- 426 and bathocuproine (BCP) were purchased from Advanced Election Technology Co., Ltd 

- 427 (China). Ytterbium (99.9%) was purchased from Kurt Lesker (Shanghai) Trading 

- 428 Company Inc. Magnesium fluoride (MgF2, 99.99%) was purchased from Alfa Aesar. Ultra- 

- 429 dry dimethylformamide (DMF), ultra-dry dimethyl sulfoxide (DMSO), ultra-dry 

- 430 isopropanol (IPA), ultra-dry ethanol, ultra-dry anisole, and ultra-dry chlorobenzene (CB) 

- 431 were purchased from commercial sources (Acros). Toluene was purchased from 

- 432 Sinopharm Chemical Reagent Co., Ltd (China). Copper (Cu) was purchased from a 

- 433 commercial source with high purity. All reagents were used as received without further 

- 434 purification. 

24 

- 435 **Perovskite precursor solution** . The perovskite composition in the narrow-bandgap (NBG) 

- 436 perovskite is Rb0.05Cs0.05MA0.05FA0.85Pb(I0.95Br0.05)3. The perovskite precursor solution 

- 437 was prepared by mixing CsI (19.5 mg), RbI (15.9 mg), MABr (8.4 mg), FAI (219.5 mg), 

- 438 PbI2 (656.9 mg), and PbBr2 (27.5 mg) in 1 mL mixed solvent of DMF:DMSO (4/1, v/v) 

- 439 and the resulting precursor solution was stirred at 50℃ for 2 h before use<sup>3</sup> . For the mid- 

- 440 bandgap (MBG) perovskite, the perovskite composition is 

- 441 (Cs0.05FA0.85MA0.10)0.95Pb(I0.85Br0.15)3. The perovskite precursor solution was prepared by 

- 442 mixing PbI2 (1.28 M), FAI (1.21 M), MABr (0.16 M), PbBr2 (0.22 M), and CsI (0.07 M) 

- 443 in a mixed solvent of DMF/DMSO (4/1, v/v), and the resulting precursor solution was 

- 444 stirred at 70℃ for 2 h before use. For the wide-bandgap (WBG) perovskite, the perovskite 

- 445 composition is FA0.83Cs0.17Pb(I0.6Br0.4)3. The perovskite precursor solution was prepared 

- 446 by mixing PbI2 (0.56 M), FAI (1.16 M), PbBr2 (0.84 M), and CsI (0.24 M) in a mixed 

- 447 solvent of DMF/DMSO (4/1, v/v), and the resulting precursor solution was stirred at 50℃ 

- 448 for 5 h before use. 

- 449 **Device fabrication.** Before device fabrication, the pre-patterned ITO or FTO substrates 

- 450 were ultrasonically cleaned using an aqueous detergent solution, deionized water, acetone, 

- 451 and IPA for 20 min. Subsequently, the as-cleaned ITO and FTO substrates were treated 

- 452 with UV-ozone for 10 min. 

25 

- 453 For the WBG perovskite, 15 mg mL<sup>−1</sup> NiO _x_ nanoparticle in a mixed solvent of IPA: 

- 454 deionized water (1:3) solution was spin-coated onto ITO substrates at 3,000 r.p.m. for 30 s 

- 455 (with a ramping rate of 1,000 r.p.m. s<sup>−1</sup> ), and the as-formed films were heated at 150°C for 

- 456 30 min in ambient air. The subsequent overlayers were deposited after the substrates cooled 

- 457 down to room temperature. The following operations were all carried out in an N2-filled 

- 458 glovebox (with H2O and O2 concentrations of < 0.1 ppm). Before depositing the perovskite 

- 459 layer, the NiO _x_ film was modified by the self-assembling monolayer of 2PACz and MeO- 

- 460 2PACz. The solutions of 2PACz and MeO-2PACz with the same concentration (0.5 mg 

- 461 mL<sup>−1</sup> in ethanol) were mixed with the volume ratio of 1:1, and then the mixed solution of 

- 462 2PACz and MeO-2PACz was spin-coated onto the NiO _x_ film at 3,000 r.p.m. (with a 

- 463 ramping rate of 1,000 r.p.m. s<sup>−1</sup> ) for 30 s followed by annealing at 100°C for 5 min. When 

- 464 the films cooled down to room temperature, the perovskite precursor solution was 

- 465 deposited onto the substrates by a consecutive two-step program at 1,000 rpm for 10 s with 

- 466 a ramping rate of 1,000 r.p.m. s<sup>−1</sup> and 5,000 r.p.m. for 35 s with a ramping rate of 1000 

- 467 r.p.m. s<sup>−1</sup> . During the second step, 300-μL of anisole doped with the ionic liquid 

- 468 ([BMP]<sup>+</sup> [BF4]<sup>−</sup> , 0.01 mg mL<sup>−1</sup> ) was poured on the center of the spinning substrates at 5 s 

- 469 before the end of the whole program. Then the samples were immediately transferred to 

- 470 the hotplate, annealing at 100°C for 30 min. For the post-treatment of the WBG perovskite 

- 471 films, 200-μL of PEAI (5 mg mL<sup>−1</sup> in IPA) and 100-μL of MAI (5 mg mL<sup>−1</sup> in IPA) were 

- 472 mixed in 705-μL of a mixed solvent of DMF/IPA (5/700, v/v) to obtain 1,005-μL of post- 

26 

- 473 treatment solution. Then 50-μL of post-treatment solution was dynamically spin-coated on 

- 474 top of the perovskite film, followed by annealing at 100°C for 5 min. 

- 475 For the MBG perovskite, 2 mg mL<sup>−1</sup> PTAA (in toluene) solution was spin-coated onto ITO 

- 476 substrates at 5,000 r.p.m. for 30 s (with a ramping rate of 2,500 r.p.m. s<sup>−1</sup> ), and as-formed 

- 477 films were heated at 120°C for 10 min. The subsequent overlayers were deposited after the 

- 478 substrates cooled down to room temperature. Then, the PEAI solution (10 mg mL<sup>−1</sup> in IPA) 

- 479 was spin-coated onto the PTAA-coated substrates at 5,000 r.p.m. for 30 s (with a ramping 

- 480 rate of 2,500 r.p.m. s<sup>−1</sup> ), and then the samples were heated at 100°C for 5 min. Subsequently, 

- 481 the perovskite films were spin-coated onto the substrates by a two-step program at 2,000 

- 482 r.p.m. for 10 s (with a ramping rate of 200 r.p.m. s<sup>−1</sup> ) and 6,000 r.p.m. for 30 s (with a 

- 483 ramping rate of 1,000 r.p.m. s<sup>−1</sup> ), respectively. During the second step, 100-μL of CB was 

- 484 poured on the center of the spinning substrates at 16 s before the end of the whole program. 

- 485 Then the samples were immediately transferred to the hotplate, annealing at 105°C for 30 

- 486 min. 

- 487 For the NBG perovskite, the MeO-2PACz (0.5 mg mL<sup>−1</sup> , in ethanol) solution was spin- 

- 488 coated onto the pre-cleaned FTO substrates at 3,000 r.p.m. for 30 s and annealed at 100°C 

- 489 for 10 min in an N2-filled glove box. The perovskite films were prepared according to the 

- 490 previous work reported elsewhere<sup>3</sup> . 

27 

- 491 The samples were then transferred to a vacuum chamber to make the charge-selective layer 

- 492 without air exposure. C60 (35 nm) was thermally evaporated in a vacuum chamber with a 

- 493 base pressure of < 4×10<sup>−4</sup> Pa. For the NBG perovskites, the PCBM solution (20 mg mL<sup>−1</sup> 

- 494 in CB) was spin-coated on top of the perovskite layer at the speed of 1,000 r.p.m. for 30 s 

- 495 (with a ramping rate of 200 r.p.m. s<sup>−1</sup> ). 

- 496 For the buffer layer fabrication, the samples were transferred to a separate vacuum chamber 

- 497 with a base pressure of < 4×10<sup>−4</sup> Pa. The ytterbium oxide (YbO _x_ ) buffer layer with a 

- 498 thickness of 1.5 nm was obtained by the thermally evaporated metal ytterbium (Yb) in the 

- 499 vacuum chamber. The thermal evaporation rate for the metal ytterbium is 1 Å/s. Note that 

- 500 Yb will be naturally oxidized into the YbO _x_ in a few minutes without intentional additional 

- 501 oxidation processes. For the control devices with the BCP interlayer, BCP (1 mg mL<sup>−1</sup> in 

- 502 ethanol) was spin-coated at 5,000 r.p.m. with a ramping rate of 2,500 r.p.m. s<sup>−1</sup> for 30 s. 

- 503 Finally, a 100-nm thick Cu electrode was thermally evaporated on the samples in the 

- 504 vacuum chamber (< 4×10<sup>−4</sup> Pa) through a metal shadow mask with an aperture area of 10.3 

- 505 mm<sup>2</sup> . The aperture mask area for the photovoltaic performance tests is 7.2 mm<sup>2</sup> . Besides, 

- 506 for the WBG and MBG devices, MgF2 (100 nm) was deposited on the glass side of the ITO 

- 507 substrate as the anti-reflection coating, while for the NBG devices, MgF2 (125 nm) was 

- 508 deposited on the glass side of the FTO substrate. 

28 

- 509 **Stability assessment.** For the stabilized power output (SPO) test, the encapsulated devices 

- 510 were measured at the maximum power point (MPP) under full-spectrum white LED 

- 511 illumination (continuous 1-sun illumination) in ambient air or in the N2 atmosphere. 

- 512 Thermal stability assessments for encapsulated devices were conducted by storing the 

- 513 encapsulated PSCs on a hot plate at 85℃ in an N2 atmosphere. Photovoltaic performances 

- 514 were regularly measured when cooled down to room temperature. For the NBG-containing 

- 515 PSCs, the PCBM electron transport layer was replaced by C60 (35 nm, prepared by thermal 

- 516 evaporation) in the thermal stability and long-term MPP tracking assessments. The 

- 517 encapsulation for the device was done by capping the device with a glass slide, using UV 

- 518 adhesive as the sealant. The encapsulation process was finished in an N2-filled glovebox 

- 519 (with H2O and O2 concentrations of < 0.1 ppm). For the stability test under the ISOS-L-3 

- 520 protocol, the temperature was controlled and monitored by the polyimide heating film with 

- 521 a digital display in temperature control. The ageing devices adhered to the polyimide 

- 522 heating film. 

- 523 **PV characterization.** The PSCs' current density–voltage ( _J–V_ ) characteristics were 

- 524 performed using a Keithley 2400 Source Meter under AM 1.5G illumination with a Xenon- 

- 525 lamp solar simulator (XES-40S1, SAN-EI). Before the measurement, the light intensity of 

- 526 100 mW cm<sup>−2</sup> was calibrated using a standard monocrystalline silicon solar cell with a KG- 

- 527 5 filter. The external quantum efficiency (EQE) was measured by a QE-R3011 

29 

- 528 measurement system (Enli Technology, Inc.). Electroluminescence (EL) quantum 

- 529 efficiency (EQEEL) was carried out at room temperature (297 K) in an N2-filled glovebox. 

- 530 A Keithley 2400 Source Meter and an integration sphere (CME-LP38) coupled with a 

- 531 spectrometer (Flame, Ocean Optics) were used for the measurements. The device was 

- 532 placed on top of the integration sphere, and only forward light emission can be collected. 

- 533 The devices were swept from zero bias to forward bias. 

- 534 **Film characterization.** The field-emission scanning electron microscope (FE-SEM) was 

- 535 used to investigate the top-view and cross-sectional morphology with an accelerating 

- 536 voltage of 10 kV (Hitachi U8010). Spin-coating perovskite films on the ITO-coated glass 

- 537 substrates prepared samples for Ultraviolet-visible (UV-vis) absorption spectra 

- 538 characterizations. Then their UV-vis absorption spectra (350-850 nm) were recorded by a 

- 539 spectrophotometer (UH4150, Hitachi, Japan) with the background noise subtracted before 

- 540 testing. During the measuring process, the perovskite films were exposed to air for less 

- 541 than 5 min. The time-resolved photoluminescence (TRPL) spectroscopy measurements 

- 542 were performed by an Edinburgh Instruments FLS1000 photoluminescence spectrometer 

- 543 (Edinburg, UK), and a pulsed laser measured all TRPL-related tests with the excitation 

- 544 wavelength of 450 nm after 120-second illumination. Temperature-dependent current 

- 545 density−voltage ( _J_ − _V_ ) characteristics of ITO/[YbO _x_ (5 nm)/Cu (1 nm)]20/Cu and 

- 546 ITO/[YbO _x_ (2 nm)]20/Cu were measured by using HP4140B picoammeter dominated by 

30 

- 547 computer within a cryostat. Both devices processed by evaporating 20 alternative layers. 

- 548 For [YbO _x_ (5 nm)/Cu (1 nm)]20, we mean we have deposited 20 alternating layers of 5 nm 

- 549 YbO _x_ followed by 1 nm Cu. The starting low temperature is 80 K cooled with liquid 

- 550 nitrogen, and data was acquired by every 30 K increase controlled by MercuryiTC low 

- 551 temperature environment controller. Grazing incidence wide-angle X-ray scattering 

- 552 (GIWAXS) measurements for amorphous Yb films deposited on various substrates were 

- 553 conducted at the BL17B1 beamline of Shanghai Synchrotron Radiation Facility (SSRF). 

- 554 The X-ray wavelength was 1.240 Å with a grazing incident angle of 1.0 degree, and the 

- 555 scattering intensity was detected by a PILATUS 2M detector. 

- 556 Thermo Scientific ESCALAB Xi<sup>+</sup> system was used to acquire the X-ray photoelectron 

- 557 spectroscopy (XPS), ultraviolet photoelectron spectroscopy (UPS), and the reflection 

- 558 electron energy loss spectroscopy (REELS) spectra. All samples were transferred into the 

- 559 analysis chamber via a vacuum transfer module avoiding exposure to the air. Unless 

- 560 otherwise stated, the gas cluster ion beam (GCIB) sputtering technology carried out the 

- 561 depth profiles with the parameters of 2000-cluster sizes at 4 keV ion energy. Ar<sup>+</sup> ion 

- 562 sputtering was used as a supplement to etch the hard materials, such as metal electrodes. 

- 563 High-resolution transmission electron microscopy (HRTEM) and annular dark-field 

- 564 scanning transmission electron microscopy (ADF-STEM) images have been obtained by 

- 565 using a JEM-2100F field emission gun microscope with a 0.19 nm point‐to‐point resolution 

31 

- 566 at 200 kV equipped with Energy disperse X-ray (EDX) detectors. Images have been 

- 567 analysed using Gatan Digital Micrograph software. To reduce the electron dose during the 

- 568 HRTEM characterization, we limited the total electron beam exposure time to within 5 s. 

- 569 All the time-of-flight secondary-ion mass spectrometry (TOF-SIMS) profiles were 

- 570 acquired by a PHI TRIFT V nanoTOF (ULVAC-PHI, Japan) system using slice-and-view 

- 571 analysis scheme. A 20 kV C60<sup>+</sup> beam with a pulse frequency of 8200 Hz and a pulse length 

- 572 of 15 ns was used as the primary-ion beam. All the secondary-ion signals were acquired 

- 573 from a 50 μm × 50 μm area. A 1 kV Ar<sup>+</sup> beam was used as the sputter source to remove the 

- 574 surface material during TOF-SIMS profiling, and the sputtering crater size was 1000 μm × 

- 575 1000 μm. All the secondary-ion data presented in the profiles were normalized by total ion 

- 576 intensities. 

- 577 **Data and materials availability** 

- 578 All data are available in the main text or the supplementary materials, and are also available 

- 579 from the corresponding author on reasonable request 

- 580 **Acknowledgments** 

- 581 This work was financially supported by the Natural Science Foundation of China 

- 582 (52325310, 52203208), the Beijing Natural Science Foundation (JQ21005), the National 

- 583 Key R&D Program of China (2021YFB3800100, 2021YFB3800101), the Science and 

- 584 Technology Project of Southwest Joint Graduate School of Yunnan Province (Research on 

32 

- 585 the key problems of perovskite solar cells for applications), the open research fund of 

- 586 Songshan Lake Materials Laboratory (2022SLABFK07), CAS Pioneer Hundred Talents 

- 587 Program B (E2XBRD1001), the China Postdoctoral Science Foundation (2023TQ0009), 

- 588 and the R&D Fruit Fund (20210001). This work was also sponsored by Beijing Nova 

- 589 Program (Contract Nos. 20220484148 and 20230484480). H.J.S. acknowledges funding 

- 590 from the Engineering and Physical Science Council (EPSRC) grant number EP/S004947/1. 

- 591 Y.X. acknowledges Moritz Riede from Oxford University for his supervision in general. 

- 592 Y.X. acknowledges China Oxford Scholarship Fund. The authors also thank beamlines 

- 593 BL19U1, BL17B1, and BL14B1 at the SSRF for providing the beamtime and User 

- 594 Experiment Assist System of SSRF for their help. 

- 595 **Author contributions** 

- 596 D.L., Z.-H.L., P.C., Y.X., and R.Z. conceived the idea and designed the experiments. P.C., 

- 597 Y.X., S.L. X.J., and T.H. fabricated PSCs and characterized photovoltaic performances. 

- 598 P.C. and M.Y. performed electroluminescence tests. Y.X., P.K., and Pietro. C. contributed 

- 599 to the analysis of electroluminescence results. X.L. conducted EQE measurements. J.H., 

- 600 J.W., Y.S., and P.T. conducted the TEM and EDX tests. J.H. and N.C. performed REELS, 

- 601 UPS, and XPS measurements. J.H., N.C., D.W., D.L., R.S., and Z.-H.L. contributed to 

- 602 analyzing REELS, UPS, and XPS results. N.C. and Z-H.L. contributed to the analysis of 

- 603 charge transport mechanisms. J.H., P.C., Y.X., and Q.L. conducted the SEM 

33 

- 604 measurements. S.L. and L.Z. helped perform the GIWAXS measurements. P.C. and Y.X. 

- 605 measured UV-Vis light absorption. C.-H.H., Y-W.Y., and J.-J.S. performed TOF-SIMS 

- 606 measurements. P.C., Y.X, and Q.Z. performed the TRPL test and did data analysis. H.Y., 

- 607 Y.X., and P.C. conducted the stability test. D.L., Q.G., Z.-H.L., H.J.S., and R.Z. directed 

- 608 and supervised the project. P.C. and Y.X. wrote the first draft of the paper. D.L., Q.G., Z.- 

- 609 H.L., H.J.S., and R.Z. revised the paper. All authors analyzed their data, reviewed and 

- 610 commented on the paper. 

- 611 **Conflict of interest** 

- 612 Henry J. Snaith is the founder and Chief Scientific Officer of Oxford Photovoltaics, a 

- 613 company commercializing perovskite photovoltaics. 

- 614 **Extended data figure legends** 

- 615 **Extended Data Fig. 1** | **Overview of buffer layers. a** , Schematic illustration of the 

- 616 functions of an ideal buffer layer between the electron-selective layer (ESL) and the metal 

- 617 electrode, showing suppression of the harmful species movement and the non-radiative 

- 618 recombination. **b** , Standard molar Gibbs free energy (Δ _f_ G) of formation at 298.15 K in kJ 

- 619 mol<sup>–1</sup> of representative metal oxides including ZnO, SnO2, ZnSnO4, TiO2, Cr2O3, and 

- 620 Yb2O3. **c** , Schematic illustration of the thermal evaporation deposition process of the metal 

- 621 Yb. 

34 

- 622 **Extended Data Fig. 2** | **XPS characterizations. a** , Photograph of 1.5 nm YbO _x_ film 

- 623 deposited on a large-scale ITO substrate (100 cm<sup>2</sup> ) by a scalable thermal evaporation 

- 624 approach. The areas at the corner of the sample highlighted by the dotted box were used to 

- 625 conduct the XPS measurements. **b** , Yb 4d XPS spectra corresponding to the highlighted 

- 626 areas in ( **a** ). The XPS data show that YbO _x_ on an 100-cm<sup>2</sup> substrate can be formed when 

- 627 upscaling in the device fabrication chamber with a base pressure of 10<sup>−4</sup> Pa. 

- 628 **Extended Data Fig. 3** | **XPS measurements and photographs of Yb bulk and YbO** **_x_** 

- 629 **surface. a,** Yb 4d XPS spectrum of the Yb bulk with 2400 s Ar ion etching. Photographs 

- 630 of the pristine Yb bulk with a naturally oxidized YbO _x_ surface ( **b** ) and the polished Yb bulk 

- 631 ( **c** ) in ambient air. The color change indicates that the refreshed metal Yb surface would 

- 632 quickly react with oxygen upon oxygen exposure, forming YbO _x_ on the surface. 

- 633 **Extended Data Fig. 4** | **The oxidization process of Yb. a** , Yb 4d XPS spectrum of an as- 

- 634 prepared ITO/YbO _x_ (1.5 nm) film. The sample was immediately transferred from the 

- 635 physical vapor deposition system to the XPS chamber by the vacuum transfer module 

- 636 without exposure to the air. **b** , Yb 4d XPS spectra of a clean Yb<sup>0</sup> surface spontaneously 

- 637 oxidized in the UHV XPS chamber. L represents Langmuir. **c** , The YbO _x_ thickness and 

- 638 Yb<sup>3+</sup> /Yb<sup>0</sup> ratios as a function of the exposure dose. **d-i** , Yb 4d XPS spectra with increased 

- 639 exposure dose. 

35 

- 640 **Extended Data Fig. 5** | **Transmission electron microscopy (TEM) measurements. a, b,** 

- 641 TEM images of YbO _x_ directly deposited on the carbon-supported copper (50 and 20 nm). 

- 642 **c** , The typical fast Fourier transform (FFT) spectrum (30 × 30 nm<sup>2</sup> area) indicates the 

- 643 amorphous crystal structure of YbO _x_ . 

- 644 **Extended Data Fig. 6** | **2D grazing incidence wide-angle X-ray scattering (GIWAXS)** 

- 645 **measurements.** The 2D GIWAXS patterns at an incidence angle of 1.0° for YbO _x_ films 

- 646 prepared on different substrates including silicon ( **a** ), glass ( **b** ), and ITO-coated glass ( **c** ), 

- 647 respectively. The thickness of the deposited YbO _x_ film for this measurement is 10 nm. **d** , 

- 648 The 2D GIWAXS pattern of the pristine ITO-coated glass. 

- 649 **Extended Data Fig. 7** | **Gap states in the YbO** **_x_ film and charge-carrier transport** 

- 650 **measurements. a** , Yb 4d XPS spectra of the YbO _x_ film with a thickness of 40 nm. **b** , 

- 651 Valence band spectra of YbO _x_ . There exists a considerable density of gap states below the 

- 652 Fermi level. **c** , Current density−voltage characteristics of the ITO/[YbO _x_ (2 nm)]20/Cu over 

- 653 temperature ranged from 120 K to 300 K. Note that the 40 nm YbO _x_ deposition is 

- 654 completed by evaporating 20 alternative layers. **d** , The plot of conductivity against 

- 655 temperature. The conductivity is calculated at 26 mA cm<sup>−2</sup> , where the injected current is 

- 656 equal to the short-circuit current of a narrow-bandgap PSC under 1-sun illumination. Note 

- 657 that the pre-factor σ0 = (2.22 ± 0.47) × 10<sup>−3</sup> S m<sup>−1</sup> , and the characteristic parameter _B_ = 

- 658 10.33 ± 0.81. 

36 

- 659 **Extended Data Fig. 8** | **Charge-carrier transport measurements. a** , Current 

- 660 density−voltage characteristics of the device with a configuration of ITO/[YbO _x_ (5 nm)/Cu 

- 661 (1 nm)]20/Cu over temperature ranged from 110 K to 290 K. **b,** The plot of conductivity 

- 662 against temperature. 

- 663 **Extended Data Fig. 9** | **Time-of-flight secondary ion mass spectrometry (TOF-SIMS)** 

- 664 **measurements.** TOF-SIMS depth profiles of the BCP- or YbO _x_ -based PSCs with and 

- 665 without ageing. **a, c,** are the control (with the BCP buffer layer) and target device (with the 

- 666 YbO _x_ buffer layer), respectively. **b, d,** are TOF-SIMS profiles of both control and target 

- 667 devices after ageing at 85°C for 200 h in the N2 atmosphere, respectively. The highlighted 

- 668 secondary ion distribution: 1: Cs<sup>+</sup> ; 2: Rb<sup>+</sup> ; 3: Cu<sup>+</sup> , 4: I<sup>+</sup> ; 5: Br<sup>+</sup> . 

- 669 **Extendend Data Table 1 | Photovoltaic parameters.** Summary of photovoltaic 

- 670 parameters for the champion p-i-n PSCs with NBG (1.54 eV), MBG (1.59 eV), and WBG 

- 671 perovskites (1.77 eV). The devices were measured from reverse scans (RS) under simulated 

- 672 AM 1.5G solar irradiation at 100 mW cm<sup>−2</sup> . For p-i-n PSCs with WBG perovskites, RS is 

- 673 from 1.35 V to –0.02 V. For p-i-n PSCs with NBG and MBG perovskites, RS is from 1.22 

- 674 V to –0.02 V). 

- 675 aThe average device parameters and standard deviations are based on 15 devices. 

37 



<!-- Start of picture text -->
Yb 4d O 1s<br>4<br>E Vac<br>2<br>E CBM<br>210 203 196 189 182 175 539 535 531 527 0 E F=0<br>10 nm<br>Binding Energy (eV) Binding Energy (eV)<br>REELS SECO VB - 2<br>(1 1 1)<br>(0 2 2)<br>(2 0 0)<br>E VBM<br>- 4<br>(1 -1 -1)<br>E g=5.5 eV<br>- 8 -6 -4 -2 0 2<br>-3.68 eV<br>2 nm<br>[0 -1 1] Yb 3.08 eV<br>- 6<br>-8 -6 -4 -2 0 2 4 18 16 4 2 0<br>Energy Loss (eV) Binding Energy (eV)<br>).<br>u<br>.<br>a<br>( ytis<br>n<br>e<br>t<br>n<br>I Intensity (a.u.) 3.08 eV<br>)<br>V 1.82 eV<br>e<br>( y<br>g<br>r<br>e<br>n<br>E<br>).<br>3.68 eV<br>u<br>.<br>a<br>( ytis<br>n<br>e<br>t<br>In Intensity (a.u.)<br><!-- End of picture text -->

**a** 



<!-- Start of picture text -->
b<br><!-- End of picture text -->



<!-- Start of picture text -->
c<br><!-- End of picture text -->



<!-- Start of picture text -->
Fresh Control/substrate side A g ed Control/substrate side Fresh Tar g et/substrate side<br>Cu 2p Cu 2p Cu 2p<br>Cs Auger<br>Cs Auger 72 0 s<br>720 s 720 s 450 s<br>60 s<br>0 s<br>450 s 360 s<br>960 950 940 930<br>Aged Target/substrate side<br>60 s 60 s Cu 2p<br>720 s<br>Cu 2p3/2 450 s<br>0 s 60 s<br>0 s<br>0 s<br>960 950 940 930 960 950 940 930 960 950 940 930<br>Binding Energy (eV)<br>Binding Energy (eV) Binding Energy (eV)<br>d e f<br>Aged Control/Cu side Aged Target/Cu side Fresh Target/Cu side<br>Cu LMM Cu LMM Yb 4d<br>600 s<br>residual residual<br>120 s<br>0 s<br>360 s 360 s<br>120 s 120 s 208 198 188 178<br> 0 s  0 s A g ed Tar g et/Cu side<br>Yb 4d<br>Cu 1+ Cu 0 Cu 1+ Cu 0 600 s<br>120 s<br>0 s<br>580 575 570 565 560 580 575 570 565 560 208 198 188 178<br>Binding Energy (eV) Binding Energy (eV) Binding Energy (eV)<br>Intensity (a.u.) Intensity (a.u.) Intensity (a.u.)<br>Intensity (a.u.) Intensity (a.u.) Intensity (a.u.)<br><!-- End of picture text -->



<!-- Start of picture text -->
a b<br>Thermally activated hopping<br>TCO<br>Unoccupied<br>localized Amorphous metal oxide HSL<br>states<br>Perovskite<br>Fermi level<br>Occupied<br>localized ESL<br>states<br>YbOX<br>Cu<br>Yb O<br>ESL YbO X Cu<br>c d e<br>2 5 2 0<br>2 5<br>2 0 1 6<br>2 0 2 0 2 0<br>2 0<br>1 5 1 2<br>1 5 1 0 1 0 1 0<br>N BG 1 0 M BG 8 W BG<br>1 0 0 0 0<br>0 100 200 300 0 100 200 300 0 100 200 300<br>Time (s) 5 Time (s) 4 Time (s)<br>5<br>N BG 1.54 eV M BG 1.61 eV W BG 1.77 eV<br>0 0 0<br>0.0 0.3 0.6 0.9 1.2 0.0 0.3 0.6 0.9 1.2 0.0 0.3 0.6 0.9 1.2<br>Voltage (V) Voltage (V) Voltage (V)<br>f g h<br>1. 5 3 0<br>90% Rad. Limit 10 0<br>W BG<br>2 5<br>MBG w/ YbO  x (This work) 2 5<br>1. 4<br>2 4 NBG w/ BCP  (Reported ) 8 0 W BG<br>2 0<br>2 3<br>1. 3 M BG<br>6 0<br>2 2 N BG 1 5<br>2 1 1. 2 4 0<br>1 0<br>2 0<br>1. 1 2 0<br>5<br>1 9<br>State-of-the-art p-i-n PSCs<br>1 8 1. 0 0 0<br>1.5 1.6 1.7 1.8 300 400 500 600 700 800<br>Bandgap (eV) Wavelength (nm)<br>-2) -2)  -2)<br>m m m<br>c  c  c<br>A  ) A ) A  )<br>(m %(  (m %(  (m %(<br>O O O<br> ytis P  ytis P  ytis P<br>n S n S n S<br>e e e<br>D D D<br> t  t  t<br>n n n<br>e e e<br>rr rr rr<br>u u u<br>C C C<br>)%  )( V )%<br>(  (<br>E E<br>C V OC Q<br>P<br>E<br>-2)(mA cmIntegrated  J sc<br><!-- End of picture text -->

