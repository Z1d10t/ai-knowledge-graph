# Origins and influences of metallic lead in perovskite solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Joule |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 465 |
| 作者 | Ji-Wei Liang, Xu-Zhi Hu, Chen Wang, Chao Liang, Cong Chen, Meng Xiao, Jiashuai Li, Chen Tao et al. |
| DOI | 10.1016/j.joule.2022.03.005 |
| 源文件 | 012_Liang_2022_Origins-and-influences-of-metallic-lead-in-perov.pdf |

---
**ll** 

### Article 

# Origins and influences of metallic lead in perovskite solar cells 



Jiwei Liang, Xuzhi Hu, Chen Wang, ..., Rui Yu, Weijun Ke, Guojia Fang 

yurui@whu.edu.cn (R.Y.) weijun.ke@whu.edu.cn (W.K.) gjfang@whu.edu.cn (G.F.) 

Highlights 

PbI2 is very unstable under both light and X-ray irradiation 

Pb<sup>0</sup> is a photodegradation byproduct of PbI2 instead of perovskites 

Instability of PbI2 under X-ray irradiation disturbs XPS measurements 

Pb<sup>0</sup> deteriorates the efficiency and stability of perovskite solar cells 

A systematic study on the origins and influences of Pb<sup>0</sup> for PSCs was carried out, where we reveal the relationship among Pb<sup>0</sup> , PbI2, and perovskites. Our results demonstrate that both light and X-ray irradiation can lead to the decomposition of PbI2. By contrast, perovskite themselves are much more stable than lead halides. Furthermore, we propose an effective strategy to restrain the detrimental Pb<sup>0</sup> by eliminating excess PbI2 in perovskites and introducing excess A-site cations. 

Liang et al., Joule 6, 816–833 April 20, 2022 ª 2022 Elsevier Inc. https://doi.org/10.1016/j.joule.2022.03.005 



**ll** 

##### Article 

## Origins and influences of metallic lead in perovskite solar cells 

Jiwei Liang,<sup>1,2</sup> Xuzhi Hu,<sup>1</sup> Chen Wang,<sup>1</sup> Chao Liang,<sup>3</sup> Cong Chen,<sup>1</sup> Meng Xiao,<sup>1</sup> Jiashuai Li,<sup>1</sup> Chen Tao,<sup>1,2</sup> Guichuan Xing,<sup>3</sup> Rui Yu,<sup>1,</sup> * Weijun Ke,<sup>1,2,</sup> * and Guojia Fang<sup>1,2,4,</sup> * 

###### SUMMARY 

Metallic lead (Pb<sup>0</sup> ) impurities in metal-halide perovskites have attracted tremendous research concerns owing to their detrimental effects on perovskite solar cells (PSCs). However, the origins and influences of the Pb<sup>0</sup> behind this issue have yet to be well understood. Herein, we show that Pb<sup>0</sup> is hardly formed in the growth of halide perovskites but is easily postformed in the perovskite films with excess PbI2. It is found that Pb<sup>0</sup> impurities are decomposition byproducts of residual PbI2 in perovskites under light or X-ray irradiation. Therefore, PSCs obtained using photodegraded PbI2 films show large efficiency and stability losses. By contrast, the perovskite devices without detectable Pb<sup>0</sup> impurities have a much better efficiency and stability. This work reveals the origins and influences of Pb<sup>0</sup> in halide perovskites and provides a strategy for avoiding the formation of detrimental Pb<sup>0</sup> byproducts, which would drive further enhancements in device performance of halide perovskite solar cells, detectors, etc. 

###### INTRODUCTION 

Lead-halide perovskites have been a focus of new-generation photovoltaic technologies owing to their superior optical absorption coefficients, long carrier diffusion lengths, high defect tolerance, etc.<sup>1–5</sup> The certified power conversion efficiency (PCE) of perovskite solar cells (PSCs) has jumped to 25.7%,<sup>6</sup> which is comparable with those of commercialized monosilicon solar cells.<sup>7</sup> To achieve high PCEs, mixed cations (e.g., methylammonium [MA<sup>+</sup> ], formamidinium [FA<sup>+</sup> ], and alkali ions) and anions (I<sup>�</sup> , Br<sup>�</sup> , and Cl<sup>�</sup> ) have been widely employed in many previous works.<sup>8–12</sup> Some other common methods, such as additive engineering<sup>13,14</sup> and surface passivation,<sup>15,16</sup> have also successfully increased the PCE of PSCs, thanks to the decreased nonradiative recombination and trap densities. However, one of the most critical challenges is that halide perovskites are still suffering from poor stability,<sup>17–20</sup> which seriously hinder the upcoming commercialization of PSCs. 

The stability limits of PSCs can be attributed into two main categories: extrinsic and intrinsic factors. Extrinsic environmental factors can be well blocked by external encapsulation.<sup>21</sup> While intrinsic factors, such as light-induced decomposition,<sup>22</sup> ion migration,<sup>23</sup> and thermal degradation,<sup>24</sup> have to be resolved by improving the quality of perovskites themselves. Metallic lead (Pb<sup>0</sup> )<sup>25</sup> is considered one of the most detrimental intrinsic factors for PSCs’ deterioration, resulting in the reduction of both efficiency and stability.<sup>26–29</sup> For example, Wang et al. suggested that Pb<sup>0</sup> stemming from the perovskite precursor solutions is very harmful, but can be reduced by Eu<sup>3+</sup> , which enables the oxidation of Pb<sup>0</sup> to Pb<sup>2+</sup> for realizing stable PSCs.<sup>30</sup> Other 

###### Context & scale 

Lead halide perovskite solar cells (PSCs) have drawn worldwide attention due to their high absorption coefficients, long charge carrier diffusion lengths, and high defect tolerance. The certified power conversion efficiency (PCE) of PSCs has jumped to 25.7% in the last decade. However, there is a lack of consensus on the origins of metallic lead (Pb<sup>0</sup> ) as to whether it comes from the initial precursor solutions or the resultant perovskite films. Here, we uncover the relationship among Pb<sup>0</sup> , lead iodide (PbI2), and halide perovskites under light or X-ray irradiation. It is shown that Pb<sup>0</sup> impurities are decomposition byproducts of residual PbI2 in perovskites under light or X-ray irradiation. Moreover, the presence of Pb<sup>0</sup> impurities significantly hampers perovskite crystallization, reduces trap activity energy, and loads deeplevel defect states, which not only increases nonradiative recombination but also accelerates perovskite degradation. By contrast, perovskites themselves are much more stable under light and X-ray irradiation. 



816 Joule 6, 816–833, April 20, 2022 ª 2022 Elsevier Inc. 

**ll** 

##### Article 

reports considered that Pb<sup>0</sup> resulting from thermal annealing of perovskite films or interface degradation between perovskites and electron-transport layers should be avoided for high-performance PSCs.<sup>31–33</sup> Nevertheless, there is a lack of consensus on the origins of Pb<sup>0</sup> , that is. whether it comes from the initial precursor solutions or the resultant perovskite films. In addition, although Pb<sup>0</sup> had been commonly regarded as an intrinsic defect in perovskites, the characteristics and influences of Pb<sup>0</sup> in perovskites, the understanding of and their devices have lagged far behind.<sup>34–37</sup> It is therefore essential to thoroughly identify the origins and influences of Pb<sup>0</sup> in perovskites to further improve solar-cell efficiency and stability. 

In this work, we carried out a series of experiments to understand the origins and influences of Pb<sup>0</sup> in perovskite solar cells. We found that Pb<sup>0</sup> impurities are decomposition byproducts of residual lead iodide (PbI2) in perovskites under light or X-ray irradiation. By contrast, perovskites themselves without excess lead halides hardly induce Pb<sup>0</sup> impurities and have a much better tolerance for light and X-ray irradiation. The results show that the presence of Pb<sup>0</sup> in perovskite films hampers the perovskite crystallization, leads to additional deep-defect levels, and loads reduction of trap activity energy, which not only increases nonradiative recombination but also accelerates perovskite degradation. Therefore, the resultant PSCs obtained from the light-aged PbI2 films with Pb<sup>0</sup> impurities have much reduced efficiencies and stability. The results give an effective strategy to restrain the formation of Pb<sup>0</sup> in halide perovskites and further improve the performance of PSCs. 

###### RESULTS AND DISCUSSION 

Given that excess PbI2 has been widely applied in highly efficient PSCs<sup>27,31,38–41</sup> and is supposed to be related to Pb<sup>0</sup> , we firstly investigated perovskite films with excess PbI2. We employed a basic perovskite member of MAPbI3 to study its essential properties. A stoichiometric one-step antisolvent-processed MAPbI3 film, a MAPbI3 film with 5 mol % excess PbI2, and a MAPbI3 film with 5 mol % excess PbI2 and methylammonium iodide (MAI, 6 mg/mL) posttreatment were loaded for comparison. Top-view scanning electron microscopy (SEM) images of all samples are shown in Figures 1A–1C, where we can observe that the stoichiometric MAPbI3 (here defined as the control one) exhibited a small crystal size (Figure 1A). And the crystal size increases with the introduction of excess PbI2, corresponding to previous reports.<sup>38,40,42</sup> Meanwhile, the excess PbI2 is abundant at the surface of perovskites, which can be observed by the off-white spots (marked with red cycles) in Figure 1B. Besides, when we use 6 mg/mL of MAI/isopropanol (IPA) to modify the surface of perovskites, the abundant PbI2 gradually disappeared as evidenced in Figure 1C. X-ray diffraction (XRD) measurements further confirmed the appearance and disappearance of PbI2 in Figure 1D and the zoomed-in XRD patterns are exhibited in Figure S1. What is interesting is that the Pb<sup>0</sup> peaks in the X-ray photoelectron spectroscopy (XPS) characterization (Figure 1E) are inextricably linked to the PbI2. For example, obvious PbI2 diffractions were detected in the MAPbI3 film with 5% excess PbI2 and also showed strong Pb<sup>0</sup> peaks in XPS spectra. However, the control and 6 mg/mL MAI-treated MAPbI3 samples did not show any PbI2 peaks under XRD measurements, which also did not contain Pb<sup>0</sup> in XPS characterization. It seems that the presence of PbI2 in the perovskites led to the emergence of Pb<sup>0</sup> instead of the perovskites themselves. Given that the perovskite film was washed by IPA solvent during the MAI solution-coating process, this might lead to Pb<sup>0</sup> vanishing. To exclude this concern, we also performed XRD and XPS measurements of the 5% excess PbI2-incorporated MAPbI3 perovskite film with IPA washing (Figure S2), showing as the unwashed one (Figures 1D and 1E). Therefore, we can conclude that the 

1Key Laboratory of Artificial Micro- and Nano-structures of Ministry of Education of China, School of Physics and Technology, Wuhan University, Wuhan 430072, People’s Republic of China 

2Shenzhen Institute, Wuhan University, Shenzhen 518055, People’s Republic of China 3Joint Key Laboratory of the Ministry of Education, Institute of Applied Physics and Materials Engineering, University of Macau, Macau 999078, People’s Republic of China 4Lead contact *Correspondence: yurui@whu.edu.cn (R.Y.), weijun.ke@whu.edu.cn (W.K.), gjfang@whu.edu.cn (G.F.) https://doi.org/10.1016/j.joule.2022.03.005 

Joule 6, 816–833, April 20, 2022 817 

**ll** 

##### Article 



Figure 1. X-ray irradiation analysis of MAPbI3 perovskites (A) Top-view SEM image of a stoichiometric MAPbI3 perovskite film (control). 

(B) Top-view SEM image of a MAPbI3 perovskite film with 5 mol % excess PbI2. 

(C) Top-view SEM image of a MAPbI3 perovskite film with 5 mol % excess PbI2 and 6 mg/mL MAI posttreatment. 

(D) XRD patterns of the corresponding perovskite films. 

(E) Pb 4f high-resolution XPS spectra of the corresponding perovskite films. 

(F) Pb 4f high-resolution XPS spectra of PbI2 films with X-ray radiation for 0–20 min. 

(G) J-V curves of a stoichiometric MAPbI3 PSC before and after X-ray irradiation. 

(H) J-V curves of a stoichiometric MAPbI3 PSC with 5 mol % excess PbI2 before and after X-ray irradiation. 

(I) J-V curves of a stoichiometric MAPbI3 PSC with 5 mol % excess PbI2 and 6 mg/mL MAI treatment before and after X-ray irradiation. 

Pb<sup>0</sup> impurities actually resulted from the decomposition of PbI2 during the XPS testing but did not exist in the initial perovskite films. In other words, the Pb<sup>0</sup> impurities in perovskite films were not introduced by precursor solutions but were induced by the postmeasurement process. It is well known that PbI2 is a light-sensitive material.<sup>43</sup> Any photon excitations with energies higher than around 2.51 eV would be able to decompose PbI2 into Pb<sup>0</sup> (Equation 1), such as the X-ray source used in the XPS instrument. 



<!-- Start of picture text -->
PbI2 ������2:51 eV � !Pb 0 + I2[ (Equation 1)<br><!-- End of picture text -->

To prove this conjecture, we also performed XPS characteristics of the PbI2 films exposed the X-ray radiation for different times during the measurements. Figure 1F shows that the peak intensity of Pb<sup>0</sup> gradually increases with prolonging the 

818 Joule 6, 816–833, April 20, 2022 

**ll** 

##### Article 

radiation time. Even though without extra X-ray radiation, initial X-ray radiation during the XPS measurements is strong enough to decompose PbI2 into Pb<sup>0</sup> . Besides, this decomposition phenomenon existed in not only PbI2 but also in other lead halides (e.g., Lead bromide [PbBr2] and lead chloride [PbCl2]), which exhibited similar instability under X-ray radiation in the process of XPS measurements (Figure S3). The dissociation energies of PbI2, PbBr2, and PbCl2 are estimated to be around 2.51, 3.06, and 3.19 eV, respectively (Equations 1, 3, and 4).<sup>43</sup> All lead halides are X-ray sensitive and PbI2 should be the most unstable one under X-ray or light irradiation. Therefore, Pb<sup>0</sup> impurities should be more carefully considered during XPS or any other high-photon-energy measurements, especially for the lead-halide-rich perovskite samples. 

Different from the film with excess PbI2, the stoichiometric MAPbI3 sample only shows the peaks of Pb<sup>2+</sup> at 137.9 and 142.8 eV, indicating that MAPbI3 perovskite itself possesses good stability under long-term X-ray radiation, as compared with the one with excess PbI2 (Figure S4). This is because the dissociation energy of MAPbI3 perovskite reaches up to around 6.17 eV, as described in Equation 2.<sup>44</sup> 



<!-- Start of picture text -->
MAPbI3 ������6:17 eV � !PbI2 + MAI (Equation 2)<br><!-- End of picture text -->

Therefore, halide perovskites should have much better stability than lead halides (6.17 eV for MAPbI3 versus 2.51 eV for PbI2). Note that MAPbI3 would have lowered dissociation energies under particular conditions of vacuum, heating, and moisture because of the unstable MAI.<sup>18,45,46</sup> Perovskite films with excess lead halides under long-term X-ray or light irradiation would favor the formation of Pb<sup>0</sup> , which actually originated from the decomposition of lead halides but not of perovskites. We further checked the X-ray stability of PSCs using the MAPbI3 films processed with different conditions, i.e., control, 5% excess PbI2, and 5% excess PbI2 plus MAI posttreatment. Figures 1G–1I show that the MAPbI3 PSC with 5% excess PbI2 exhibited poor X-ray stability, which only maintained 90% of its initial efficiency after 5 h of X-ray irradiation. For comparison, MAPbI3 PSCs without excess PbI2 exhibited stronger resistance to X-ray radiation. 

In addition to coating extra MAI, we can also use other different bulky organic cations, i.e., guanidinium iodide (GAI), dimethylammonium iodide (DMAI), and phenethylammonium iodide (PEAI),<sup>15,16,47</sup> to react with the residual PbI2 in MAPbI3 and introduce low-dimensional perovskites with post-annealing. Top-view SEM images of the excess PbI2-incorporated MAPbI3 films with different-cation posttreatments are given in Figure S5, showing an obvious change on the surface of MAPbI3 perovskite films. All these cations (GAI, DMAI, and PEAI) can react with the residual PbI2 to form mixed-dimensional perovskites, as confirmed by the XRD patterns shown in Figure S6. More importantly, the Pb<sup>0</sup> signal disappeared as the PbI2 was consumed in these samples (Figure S7). Therefore, low-dimensional perovskites can not only serve as a passivator for reducing surface/interface defects<sup>16</sup> but also act as an inhibitor for the formation of Pb<sup>0</sup> in perovskites. These results strongly suggest that the reduction of excess PbI2 should be one of the keys to further eliminating detrimental Pb<sup>0</sup> impurities in perovskite films. 

To further study the effects of Pb<sup>0</sup> in PbI2 and perovskites, we then introduced Pb<sup>0</sup> impurities into PbI2 films on purpose. The PbI2 films deposited on glass substrates were directly exposed to a white LED source (70 mW/cm<sup>2</sup> ) in a nitrogen-filled glovebox. Figure 2A presents an optical photograph of the PbI2 films with light irradiation for different times, which gradually turned from yellow to black after light irradiation 

Joule 6, 816–833, April 20, 2022 819 

**ll** 



<!-- Start of picture text -->
Article<br><!-- End of picture text -->



Figure 2. The generation of Pb<sup>0</sup> in PbI2 films (A) Photograph of PbI2 films with light irradiation for 0–8 h. 

(B) Top-view SEM image of a fresh PbI2 film. 

(C) Top-view SEM image of a PbI2 film with light irradiation for 8 h. 

(D) XRD patterns of PbI2 films with light irradiation for 0–8 h. 

(E) TEM image of a fresh PbI2 film. 

(F) TEM image of a PbI2 film after light irradiation for 8 h. 

(G) PL spectra of PbI2 films with light irradiation for 0–8 h. 

(H) TRPL spectra of PbI2 films with light irradiation for 0–8 h. 

(I) Time-resolved transient absorption spectra of PbI2 films with light irradiation for 0–8 h. 

for 8 h. Ultraviolet-visible (UV-vis) spectra also confirmed the absorption enhancement of the films after light irradiation, as shown in Figure S8. SEM images of the PbI2 films reveal that pinholes and black spots appeared with the extension of the light-irradiation time (Figures 2B, 2C, and S9). We supposed that the dark spots are mainly cubic Pb<sup>0</sup> because PbI2 can easily decompose into Pb<sup>0</sup> under light irradiation, resulting in pinholes in the PbI2 films after iodine (I2) sublimation. The light decomposition process of PbI2 can be described in Equation 1 as mentioned above. 

We further certified this process by measuring the XRD patterns of these films (Figure 2D). From zoomed-in XRD results in Figure S10, all the films with light irradiation had an extra diffraction peak at 31.3<sup>�</sup> , which can be assigned to a (111) plane of Pb<sup>0</sup> . 

820 Joule 6, 816–833, April 20, 2022 

**ll** 

##### Article 

The intensity of the diffraction peak at 31.3<sup>�</sup> gradually increased after light-irradiation time increased, indicating increased amounts of Pb<sup>0</sup> in the final films. To further prove the generation of Pb<sup>0</sup> , high-resolution transmission electron microscopy (HRTEM) images of a pristine PbI2 film and a PbI2 film with 8 h of light irradiation were carried out, as shown in Figures 2E and 2F. For the pristine PbI2 film, an interplanar spacing of 1.75 A<sup>˚</sup> is well matched with a (004) reflection of hexagonal lattice (PDF #07-0235), while for the light-aged PbI2 film, it can be observed an extra lattice spacing of 1.43 A<sup>˚</sup> , corresponding to the diffraction of a (222) plane for cubic Pb<sup>0</sup> (PDF #04-0686). Furthermore, energy dispersive spectrometry (EDS) mapping was also carried out (Figure S11) to analyze element distribution, showing that the amounts of I are reduced after light exposure and confirming that Pb<sup>0</sup> is a degradation byproduct of PbI2 with light aging. These results strongly demonstrate that the appearance of Pb<sup>0</sup> in the light-aged PbI2 films can only originate from PbI2. 

To study the effects of Pb<sup>0</sup> in charge carrier generation and recombination, photoluminescence (PL) and time-resolved photoluminescence (TRPL) measurements were also performed in the different PbI2 films (Figures 2G and 2H). In comparison with the fresh PbI2 film, the PL intensity and lifetime of the light-aged PbI2 films were significantly decreased, stemming from the increased nonradiative recombination. This is consistent with the notion that the Pb<sup>0</sup> serving as a recombination center can increase nonradiative recombination and therefore decrease the PL intensity. Also, transient absorption (TA) spectra of the samples were measured, as presented in Figures S12 and 2I. A negative DA signal at 499 nm corresponds to photobleaching of PbI2 (Figure S12). The fitted data of the decay is given in Table S1, where the carrier charge lifetime t2 (t3) reduces from 13.07 (336.60 ps) to 0.41 (11.69 ps) for the film after 8 h of light aging. This result indicates that the presence of Pb<sup>0</sup> in PbI2 significantly aggravates carrier recombination.<sup>48</sup> 

Encouraged by the above results, we then investigated the influences of Pb<sup>0</sup> on the efficiency and stability of PSCs. The light-aged PbI2 films loaded with Pb<sup>0</sup> impurities on purpose were employed to assemble perovskite films and devices. The perovskite films were fabricated by a two-step deposition method, as illustrated in Figure 3A. The devices used SnO2 as electron transfer layers and 2,20,7,70-tetrakis [N,N-di(4-methoxyphenyl) amino]-9,90-spiro-bifluorene (spiro-OMeTAD) as holetransfer layers. In the first step, we employed PbI2 films with light irradiation for different times (e.g., 2, 4, 6, and 8 h) and fresh PbI2 as control sample as precursor layers. The longer light-irradiation times led to more amounts of Pb<sup>0</sup> in the final films. Top-view SEM images of the fabricated perovskite films obtained using fresh PbI2 and 8 h-light-aged PbI2 are compared in Figures 3B and 3C, where we can observe that some spongy grains appear and gradually increase as the amount of Pb<sup>0</sup> increases (Figures S13A–S13C). The red dashed lines depict the shape of these spongy materials in the SEM images. Compared with the fresh PbI2-fabricated perovskite film, these materials have an irregular and poriferous morphology, as evidenced by the zoomed-in SEM images shown in Figure S14. To identify the spongy materials, we deposited a thin formamidinium iodide (FAI) layer on the surface of an ITO and a perovskite film, as shown in Figures S14C and S14D. We found that the morphology of both films has an extremely similar spongy shape with the perovskite film obtained using light-aged PbI2. This demonstrates that Pb<sup>0</sup> hampered perovskite crystallization and resulted in excess FAI remaining on the surface of perovskites. XRD characteristics further certified the formation of perovskite films was hindered by the light-aged PbI2 films (Figure 3D). The peak intensities of both perovskite and PbI2 films (at 12.6<sup>�</sup> ) present a declining trend, indicating the reduced crystalline quality of the perovskite and the PbI2 films. Furthermore, confocal PL 

Joule 6, 816–833, April 20, 2022 821 

**ll** 



<!-- Start of picture text -->
Article<br><!-- End of picture text -->



Figure 3. Characterization of PSCs using light-aged PbI2 as the precursors 

(A) Schematic of the fabrication process of sequential deposition using light-aged PbI2 films as the precursors. 

(B) Top-view SEM image of a perovskite film obtained using fresh PbI2. 

(C) Top-view SEM image of a perovskite film obtained using PbI2 film with light irradiation for 8 h. 

(D) XRD patterns of the perovskite films obtained using PbI2 precursor films with light irradiation for 0–8 h. 

(E) Confocal PL microscopy image of a perovskite film obtained using fresh PbI2. 

(F) Confocal PL microscopy image of a perovskite film obtained using PbI2 film with light irradiation for 8 h. 

(G) J-V curves of PSCs using different PbI2 precursor films. 

(H) The corresponding box plots of PCEs. 

(I) Maximum power point tracking of PSCs obtained using different PbI2 precursor films. 

mapping was carried out to analyze the carrier-dynamic properties of perovskite films. Compared with the fresh PbI2-fabricated perovskite film, the perovskite film obtained from 8 h-light-aged PbI2 exhibited much weaker and dispersive PL distribution arising from the poor crystalline quality, residual FAI, and Pb<sup>0</sup> impurities (Figures 3E, 3F, and S13D–S13F). 

In the following, we checked the device performance of PSCs obtained from the fresh and light-aged PbI2 films. Current density-voltage (J-V) characteristics of the corresponding devices are compared in Figures 3G, 3H, and S15 and Table 1. Obviously, the fresh PbI2-based device presented the optimal performance, giving a JSC of 24.5 mA/cm<sup>2</sup> , a VOC of 1.13 V, an FF of 82%, and a PCE of 22.7%. Compared with 

822 Joule 6, 816–833, April 20, 2022 

**ll** 

##### Article 

Table 1. Photovoltaic parameters of the best-performing PSCs using fresh and light-aged PbI2 precursor films 

|Sample|VOC(V)|JSC(mA/Cm<sup>2</sup>)|FF (%)|PCE (%)|IntegratedJsc from<br>EQE (mA/cm<sup>2</sup>)|
|---|---|---|---|---|---|
|Fresh|1.13|24.5|82.0|22.7|23.9|
|2 h|1.01|22.9|69.2|16.0|22.2|
|4 h|0.99|21.6|62.2|13.3|21.1|
|6 h|0.99|20.3|57.3|11.5|20.3|
|8 h|0.97|19.1|52.9|9.8|18.9|



the fresh PbI2-based device, the performance of the devices obtained using lightaged PbI2 exhibited a drastic decline. For example, the solar cell assembled by a PbI2 precursor layer with 8 h of light aging had a JSC of 19.1 mA/cm<sup>2</sup> , a VOC of 0.97 V, an FF of 53%, and a PCE of 9.8% (Table 1). External quantum efficiency (EQE) spectra and integrated current densities of the corresponding devices are exhibited in Figure S16, which are consistent with the trend in J-V results shown in Figure 3G. The photovoltaic parameter distribution of 10 cells for each condition is summarized in Figures 3H and S15B–S15D and Table S2, confirming the good reproducibility of the devices. Furthermore, Figure 3I compares normalized steady-state PCEs of PSCs obtained using different PbI2 films, where we can observe that the device efficiencies drop significantly for the devices using light-aged PbI2 films. However, all these perovskite films had similar absorption spectra (Figure S17, calculated as Eg = 1.54 eV), indicating that the performance decline stems from the severe internal recombination induced by Pb<sup>0</sup> . Therefore, the Pb<sup>0</sup> impurities in the light-aged PbI2 films can not only bring down device performance but also accelerate the degradation of PSCs. 

To explore the origins of performance degradation, we performed PL and TRPL analysis to estimate the carrier recombination in perovskite films. As shown in Figures 4A and 4B, all the samples exhibited a PL peak at about 805 nm, indicating that the main components remained FA1�xMAxPbI3 perovskites even though using light-aged PbI2 as the precursor layer. Whereas the gradually decreased PL peak of the lightaged PbI2-based samples manifests that the Pb<sup>0</sup> serving as traps to capture carriers would lead to severely photogenerated charge carrier recombination. TRPL results show that the sample obtained from a PbI2 film with 8 h of light aging had the shortest carrier lifetime, which agrees with the PL measurements. To study the built-in potential (Vbi) of the devices, Mott-Schottky analyses of PSCs were conducted under a frequency of 1 kHz with bias voltages ranging from 0 to 1.2 V, as shown in Figure 4C.<sup>49,50</sup> It is shown that the Vbi reduced from 0.85 V for the reference to 0.73 V for the sample obtained using a PbI2 film with 8 h of light aging and the corresponding depletion width (W) decreased from 208 to 82 nm. With a decreased Vbi, the carrier extraction was hindered by a reduced bias, hence leading to serious charge recombination and a reduced VOC. 

We then performed temperature-dependent admittance spectroscopy (AS) under low pressure (�10 Pa) to identify the location and density of the trap states in the perovskite films. The detailed relationships and analyses can be found in the experimental procedures section. The different capacitance spectra of PSCs are exhibited in Figure S18, and the corresponding derivative capacitance spectra reflecting the carrier freeze-out are shown in Figure S19. By determining the u = u0 through applied AC signals with increasing temperature, we fitted the Arrhenius plots of the transition frequencies at each temperature. As presented in Figure 4D, the fitting trap activation energy (Ea) reduced from 0.25 to 0.02 eV with Pb<sup>0</sup> introduction, 

Joule 6, 816–833, April 20, 2022 823 

**ll** 

Article 



Figure 4. Optical and electrical properties of perovskite films (A) PL spectra of the perovskite films using PbI2 precursor films with light irradiation for 0–8 h. (B) TRPL spectra of the perovskite films using PbI2 precursor films with light irradiation for 0–8 h. (C) Mott-Schottky plots of the perovskite films using PbI2 precursor films with light irradiation for 0–8 h. (D) Arrhenius plots of the perovskite films using PbI2 precursor films with light irradiation for 0–8 h. (E) Trap-state densities of the corresponding PSCs at room temperature. (F) Pb 4f high-resolution XPS spectra of the perovskite films using PbI2 precursor films with light irradiation for 0–8 h. 

implying easy trap migration under light irradiation. Besides, the trap migration inevitably led to ion movements which have been considered to be one of the main reasons for PSC instability.<sup>51,52</sup> For a p-type perovskite semiconductor, the thermal emission depth of trap (Ed) has an energetic formula of Ed = ET � EV, which is the difference of trap state location and the valence band maximum.<sup>53</sup> In Figure 4E, the differentiated capacitance spectra combined with Vbi can yield the trap density distribution and the trap depth. As exhibited in the trap-energy distribution under room temperature of each device, trap density increased from 5.0 3 10<sup>16</sup> for the reference device to 1.0 3 10<sup>17</sup> cm<sup>�3</sup> for the 8 h-light-aged PbI2-based one. Moreover, the distribution of trap-state energy level shifted from 0.25 to 0.4 eV above the valance band maximum after loading Pb<sup>0</sup> . The results predicted that the presence of Pb<sup>0</sup> can significantly influence the trap distribution, mainly in increasing the trap-state density and deepening the trap-state energy. The XPS spectra of 

824 Joule 6, 816–833, April 20, 2022 

**ll** 

##### Article 



Figure 5. Performance analysis of PSCs (A) Top-view SEM image of a stoichiometric Cs0.06(FA0.92MA0.08)0.94Pb(I0.92Br0.08)3 perovskite film. 

(B) Top-view SEM image of a Cs0.06(FA0.92MA0.08)0.94Pb(I0.92Br0.08)3 perovskite film with 5 mol % excess PbI2. 

(C) Top-view SEM image of a Cs0.06(FA0.92MA0.08)0.94Pb(I0.92Br0.08)3 perovskite film with 5 mol % excess PbI2 and BABr posttreatment. (D) XRD patterns of the corresponding perovskite films. 

(E) J-V curves of the corresponding PSCs. 

(F) PCEs of the corresponding PSCs. 

(G) MPP tracking curves of the corresponding PSCs. 

the corresponding perovskite films show that the signal of Pb<sup>0</sup> gradually increases, attributed to the decomposition of PbI2 with light aging (Figure 4F). 

To further verify the effects of Pb<sup>0</sup> and excess PbI2 in general perovskites, we also fabricated mixed-cation and mixed-halide perovskites, which have been widely reported for highly efficient PSCs.<sup>3,5</sup> Figures 5A–5C show top-view SEM images of Cs0.06(FA0.92MA0.08)0.94Pb(I0.92Br0.08)3 (CsFAMA) perovskite films obtained using a stoichiometric precursor, a precursor with excess PbI2, and a precursor with excess PbI2 plus n-butylammonium bromide (BABr) posttreatment, which we labeled as stoichiometric, 5% PbI2, and 5% PbI2 + BABr. All these films were prepared by a one-step antisolvent method. The films had similar surface morphonology but, compared with the stoichiometric perovskite film (Figure 5A), there were some bright crystals in the sample with excess PbI2 (Figure 5B). These bright crystals should be PbI2, which is consistent with the XRD patterns of the films (Figure 5D) and the previous reports.<sup>54</sup> We also deposited a thin film of BABr on the surface 

Joule 6, 816–833, April 20, 2022 825 

**ll** 

Article 

Table 2. Photovoltaic parameters of the best-performing CsFAMA PSCs using various perovskite light-absorbers 

|Sample|VOC(V)|JSC(mA/cm<sup>2</sup>)|FF (%)|PCE (%)|IntegratedJSCfrom<br>EQE (mA/cm<sup>2</sup>)|
|---|---|---|---|---|---|
|Stoichiometric|1.09|24.3|76.0|20.1|23.6|
|5% PbI2|1.09|24.3|80.2|21.2|23.6|
|5% PbI2 +BABr|1.15|24.4|80.1|22.5|23.7|



of CsFAMA perovskites with post-annealing, which could form a 2D/3D perovskite heterostructure and enhance the device performance.<sup>16,55–57</sup> Figure 5C shows that the surface morphology of a CsFAMA perovskite film with 5% excess PbI2 and BABr posttreatment is slightly different, as compared with the other two samples. Atomic-force microscopy (AFM) also proved the morphology change, as shown in Figure S20. Combining SEM with XRD results in Figures 5B–5D, it seems that the PbI2 crystals disappeared after BABr posttreatment. The as-synthesized triple-cation mixed-halide perovskite films exhibited typical XRD patterns, corresponding to the lattice of CsFAMA perovskite (Figure 5D). An additional characteristic peak of PbI2 at 12.6<sup>�</sup> was only detected in the 5% excess PbI2-incorporated sample. After BABr treatment, the diffraction patterns of PbI2 completely disappeared and other peaks below 15<sup>�</sup> can be assigned to two-dimensional Ruddlesden-Popper perovskites as reported in the literature.<sup>56,57</sup> 

We then used these films for the fabrication of solar cells and investigated their effects on device performance. The devices employed a planar n-i-p structure using SnO2 as an electron-transport layer and spiro-OMeTAD as a hole-transfer layer. The detail of the fabrication process is described in the experimental procedures section. J-V characteristics and photovoltaic parameters of the corresponding PSCs are shown in Figures 5E, 5F, and S21 and Tables 2 and S3. The presence of excess PbI2 in PSCs improved FF from 76.0% to 80.2% and PCE from 20.1% to 21.2% (Figure 5E). The loading of mixed 2D/3D perovskites by BABr posttreatment further improved VOC from 1.09 to 1.15 V and resulted in a significantly enhanced PCE of 22.5%. Meanwhile, the introduction of excess PbI2 and BABr posttreatment in perovskite films did not change the bandgap of stoichiometric CsFAMA perovskite (Eg = 1.57 eV calculated from the absorption in Figure S22A) and therefore exhibited no loss in JSC. These results agree with the EQE results shown in Figure S22B. The integrated JSC of stoichiometric, excess PbI2, and excess PbI2 + BABr-based devices are 23.6, 23.6, and 23.7 mA/cm<sup>2</sup> , respectively. To understand enhancement in VOC, FF, and PCE of solar cells, we also measured PL and TRPL spectra of the corresponding films. It is worth noting that PL intensity is associated with nonradiative recombination, which gradually decreased after the perovskite films introduced excess PbI2 and were further treated with BABr (Figure S22C). TRPL results show that the carrier lifetime of the perovskite films (Figure S22D) increased after loading excess PbI2 and BABr treatment, which is beneficial for the FF and VOC in devices. 

The long-term stability of the corresponding devices employing stoichiometric, excess PbI2, and excess PbI2 + BABr-based perovskite absorbers were surveyed, wherein maximum power point (MPP) tracking was recorded by measuring PSCs stored in a nitrogen-filled glovebox. Interestingly, the stability results show a different trend, as compared with the efficiency results. Figure 5G indicate that the stoichiometric and excess PbI2 + BABr-based cells maintained 95% and 97% of their initial PCEs after 250 h, respectively. By contrast, the device with excess PbI2 exhibited an obvious decline and only maintained 82% of its initial PCE under the same conditions. In this case, although the excess PbI2 in PSCs had a positive 

826 Joule 6, 816–833, April 20, 2022 

**ll** 

##### Article 

influence on PCEs, it had a negative influence on light stability, which can be attributed to the light decomposition of excess PbI2 in perovskites. The results suggest that further strategies for enhancement of the stability of PSCs should control the amount of PbI2 and provide self-compensating A-site cations. 

###### Conclusions 

In summary, we carried out a series of experiments to investigate the origins and effects of Pb<sup>0</sup> in PSCs. Studies on single PbI2 films showed that light or X-ray irradiation would result in the decomposition of PbI2, leading to the formation of detrimental Pb<sup>0</sup> byproducts. The Pb<sup>0</sup> impurities can serve as recombination centers that increase nonradiative recombination and suppress charge carrier transfer in PbI2 and perovskites. We used light-aged PbI2 films with Pb<sup>0</sup> impurities as the precursor layers for the fabrication of PSCs. The PCE dramatically reduced from 22.7% for the reference cell to 9.8% for the 8 h-light-aged PbI2-based cells, because the Pb<sup>0</sup> in the light-aged PbI2-assembled perovskite films not only deepen the trap-state level from 0.25 to 0.4 eV but also increase the trap density from 5.0 3 10<sup>16</sup> to 1.0 3 10<sup>17</sup> cm<sup>�3</sup> . Besides, the presence of Pb<sup>0</sup> also hampered the perovskite crystallization and decreased the trap activation energy from 0.25 to 0.02 eV, resulting in a serious device performance deterioration. The results also showed that halide perovskite films are much more stable than their metal-halide precursors of under light or X-ray irradiation. This work would suggest that further enhancements on PSC performance need to avoid the formation of excess PbI2 and light-decomposed Pb<sup>0</sup> , which should be one of the keys for realizing PSCs’ commercialization in the future. 

###### EXPERIMENTAL PROCEDURES 

###### Resource availability 

Lead contact 

Further information and requests for resources should be directed to and will be full filled by the lead contact, Guojia Fang (gjfang@whu.edu.cn). 

###### Materials availability 

This study did not generate new unique materials. 

###### Data and code availability 

This study did not generate any datasets or codes. The data and results supporting the current study are available from the lead contact upon reasonable request. 

###### Materials and solvents 

PbI2 (99.9985%) was purchased from Tokyo Chemical Industry (TCI, Japan). PbBr2 (99.99%), PbCl2 (99.99%), cesium iodide (CsI 99.99%), MAI (99.9%), and methylammonium bromine (MABr 99.9%) were purchased from Sigma Aldrich. FAI, poly[bis(4phenyl) (2,4,6-trimethylphenyl) amine] (PTAA), GAI, DMAI, PEAI, and BABr were purchased from Xi’an Polymer Light Technology (China). Spiro-OMeTAD was purchased from Advanced Election Technology. Besides, N,N-dimethylformamide (DMF, 99.8%), dimethyl sulfoxide (DMSO, 99.7%), IPA (99.7%), and chlorobenzene (CB, 99.8%) were purchased from Sigma Aldrich. Ethyl ether (99.5%) was purchased from Sinopharm Chemical Reagent (China). 

###### Precursor and film preparation 

Before film deposition, the etched ITO glass substrates (% 15 U/sq) were washed by sonication with detergent, deionized water, acetone, and ethanol for 15 min successively. After drying with dry nitrogen, 15 min of ultraviolet-O3 treatment was carried out before being transferred to electron transfer layer deposition. Alfa SnO2 

Joule 6, 816–833, April 20, 2022 827 

**ll** 

Article 

nanoparticle solution (2.5%, diluted by ultrapure water, %18.2 MU, cm) was spincoated on the substrates at 5,000 rpm for 20 s, following annealed at 180<sup>�</sup> C for 20 min in the atmosphere. Subsequently, an additional 15 min of ultraviolet-O3 was treated to enhance the film wettability. The perovskite layers were prepared by antisolvent or sequentially deposition and the whole fabrication process was carried out in an N2-filled glovebox at controlled room temperature (�23<sup>�</sup> C) and H2O and oxygen level (%0.1 ppm, %0.1 ppm). After that, a solution of spiro-OMeTAD dissolved in CB (72.3 mg/mL) with the addition of 17.5 mL Li-TFSI/acetonitrile (520 mg/mL), and 28.8 mL 4-tertbutylpyridine was deposited at 3,000 rpm for 30 s by spin coating without further annealing. Finally, 60 nm of Au was deposited by thermal evaporation under 2.0 3 10<sup>�4</sup> Pa vacuum pressure. 

###### The perovskite films fabricated by an antisolvent process MAPbI3 

A 1.5 M stoichiometric perovskite precursor solution was obtained by dissolving MAI (1.5M) and PbI2 (1.5 M) in a mixed solvent of DMF:DMSO = 10:1 (v:v). 2 mol % or 5 mol % PbI2 was added into a stoichiometric MAPbI3 perovskite solution to form MAPbI3 films with excess PbI2. The MAPbI3 films were deposited on the pre-fabricated SnO2/ITO substrates by a one-step spin-coating process: keeping 4,000 rpm for 30 s and dropping 400 mL of antisolvent (e.g., diethyl ether) at the 23<sup>rd</sup> s to form wet perovskite precursor films after spin coating. After that, the as-prepared perovskite films were annealed on a hot plate at 100<sup>�</sup> C for 10 min in an N2filled glovebox. To remove excess PbI2 in perovskites, MAI/IPA solutions (e.g., 3 or 6 mg/mL) were spin-coated on the surface of perovskites at 3,000 rpm for 30 s and then annealed at 100<sup>�</sup> C for 3 min. And for other low-dimensional perovskitemodified samples, organic cation solutions (i.e., GAI, DMAI, and PEAI, 20 mM dissolved in IPA) were spin-coated on the fabricated perovskite films at 3,000 rpm for 30 s and then annealed at 100<sup>�</sup> C for 5 min. 

Cs0.06(FA0.92MA0.08)0.94Pb(I0.92Br0.08)3 

A 1.4 M stoichiometric perovskite precursor solution was obtained by dissolving PbI2, PbBr2, MABr, FAI, and CsI with 1 mol % KI additive in a mixed solvent of DMF and DMSO (4:1/v:v). Extra 5 mol % PbI2 was added into the stoichiometric mixed-cation perovskite solution for the excess PbI2. For BABr solution, BABr was dissolved into IPA solvent with a concentration of 2 mg/mL. The perovskite films (with or without excess PbI2) were deposited on the pre-fabricated SnO2/ITO substrates by a two-step spin-coating process: first at 1,000 rpm for 5 s with a ramp of 5,000 rpm/s, and then at 5,000 rpm for 45 s with a ramp of 10,000 rpm/s. At the 15<sup>th</sup> s of the spin coating, 120 mL of antisolvent (e.g., CB) was dripped to form a wet perovskite precursor film. Then, the as-prepared perovskite films were annealed on a hot plate at 65<sup>�</sup> C for 2 min and 120<sup>�</sup> C for 10 min in an N2-filled glovebox. For BABr treatment, 50 mL of BABr/IPA solution was spin-coated on the perovskite surface at 3,000 rpm for 30 s after the film cooling to room temperature and followed by thermal annealing at 100<sup>�</sup> C for 5 min. 

###### The perovskite films fabricated by a sequential deposition process FA1�xMAxPbI3 

A 1.3 M PbI2 solution dissolved in a mixed solvent of DMF:DMSO = 9:1 (v:v) was used for spin coating at 1,500 rpm for 30 s, and then annealed at 70<sup>�</sup> C for 1 min in an N2filled glovebox. For light-aged samples, the as-fabricated PbI2 films were put on the platform under simulated one-sun AM 1.5G illumination for different h (e.g., 2, 4,.8 h). After the light-aging process, a mixed solution of FAI:MAI:MACl (90:6.5:9 mg in IPA) was spin-coated on the surface of PbI2 at 1,500 rpm for 30 s, and then annealed 

828 Joule 6, 816–833, April 20, 2022 

**ll** 

##### Article 

at 150<sup>�</sup> C for 15 min in the atmosphere with controlled humidity (�30%). For FAI posttreated perovskite film, a 50 mL solution of FAI (60 mg/mL) was spin-coated on the surface of perovskite at 3,000 rpm for 30 s and annealed at 100<sup>�</sup> C for 5 min. Then, the perovskite samples were transferred to an N2-filled glovebox for further processing. 

###### Characterization and analysis Film characterization 

The morphology of the films was observed by SEM (Zeiss SIGMA) with an accelerating voltage of 15 kV. The crystal lattice and element distribution were investigated using high-resolution TEM (JEM-F200) and EDS mapping (JEM-F200) with an accelerating voltage of 200 kV. AFM images of perovskites were carried out by using the Bruker dimension icon under peak force mode. Absorption spectra of films were carried out using a spectrophotometer (UV-vis, mini UV-1208 model, Shimadzu). PL spectra of perovskite films were measured using a DeltaFlex fluorescence spectrometer (HORIBA) with a center wavelength of 481 nm semiconductor laser and TRPL was carried out with time-correlated single-photon counting (TCSPC) module. PL (excitation at 400 nm) and TRPL of PbI2 films were measured with an Edinburgh Instrument (FLSP980). The crystallographic films were measured by grazing incidence X-ray diffraction (GIXRD) instrument (D8 Discover, Bruker) with 40 kV, 40 mA radiation (Cu Ka, l = 0.15406 nm, incident slit = 0.1 mm, receiving slit = 20mm, incident angle [center] = 3<sup>�</sup> , scan speed = 5<sup>�</sup> /min). 

Confocal microscopy imaging was acquired using a wide-filed, hyperspectral imaging microscope system (TCS SP8, Leica). A wavelength of 552 nm solid-state laser was employed as a PL excitation source, and a charge-coupled-device (CCD) array detector having a detection range from 700 to 800 nm was used for PL detection. The signal collection area for each film was 100 (10 3 10) mm<sup>2</sup> . 

X-ray aging measurements were carried out by a miniature X-ray tube system, which includes a Mini-X2 X-ray tube module and controller (AMPTEK). The Mini-X2 generates X-ray radiation with tungsten (W) as the anode material. We used a tube voltage of 35 kV and a tube current of 20 mA to irradiate the perovskite films (with or without excess PbI2) for 5 h. The distance was about 30 mm between the samples and the X-ray source, where the X-ray dose rate was 3.65 mGy/s during our testing. 

Femtosecond optical spectroscopy was obtained from the Ultrafast System HELIOSTM TA spectrometer. The laser source was a Coherent Legend regenerative amplifier (150 fs, 1 kHz, 800 nm) seeded by a Coherent Vitesse oscillator (100 fs, 80 MHz). The broadband probe pulses (420–800 nm) were generated by focusing a small portion of the fundamental 800 nm laser pulses into a 2 mm sapphire plate. 400 nm wavelength laser pulses were obtained through a BBO doubling crystal from an 800 nm femtosecond laser. The dynamics can be described by: 

y = A1e<sup>ð�t=t1Þ</sup> + A2e<sup>ð�t=t2Þ</sup> + A3e<sup>ð�t=t3Þ</sup> 

where t1 represents hot carrier process, t2 represents carrier charge transfer process, and t3 represents free electron-hole recombination process. 

XPS measurements were performed by an ESCALAB 250Xi (Thermo Scientific, USA) with a monochromatic magnesium-Ka X-ray gun (400 W, l = 1.254 keV) in an ultrahigh vacuum chamber (�10<sup>�6</sup> Pa). And the XPS spectra were analyzed using Thermo Scientific Avantage software. All test samples were prepared in an N2-filled 

Joule 6, 816–833, April 20, 2022 829 

**ll** 

Article 

glovebox with controlled humidity and oxygen level (%0.1 ppm). The shift of binding energy was referenced to the C 1s peak at 284.8 eV of the surface adventitious carton. 

###### Device characterization 

EQE measurements were performed with a QE/IPCE system (Enli Technology). J-V curves of the PSCs were measured under air mass 1.5 global (AM 1.5 G) conditions (Enli Technology) in a nitrogen atmosphere. All of the devices were measured by masking the active area (0.1188 cm<sup>2</sup> ) with a metal mask (the certified area is 0.0578 cm<sup>2</sup> ). J-V measurements were performed with a scan rate of 20 mV,s<sup>�1</sup> ranging from 1.2 to �0.1 V and then reversed again from �0.1 to 1.2 V with a dwell time of 25 ms. 

###### Stability measurements 

All of the unencapsulated perovskite devices were aged in a multichannel thin-film photovoltaic attenuation test system (PVLT-6001X-16B, Suzhou D&R Instruments). Given that the Li-TFSI doped spiro-OMeTAD would influence the stability of devices, we employed a PTAA HTL prepared using a 20 mg/mL PTAA solution in our stability measurements. The devices were performed MPP under illumination (white LED source, 70 mW,cm<sup>�2</sup> , wavelength range from 400 to 850 nm) with one test cycle every 15 s at an average temperature of about 30<sup>�</sup> C (glovebox temperature is kept about 25<sup>�</sup> C) in an N2-filled glovebox. The loaded resistance values ranged from 5 U to 10 kU, the loaded voltage values ranged from �2 to 2 V, and one source meter matched with each device, respectively. J-V measurements were carried out with a scan rate of 15 mV,s<sup>�1</sup> ranging from 1,200 to �50 mV and scan cycle set as every 60 min. 

###### Admittance characterization 

Mott-Schottky curves with capacitance-voltage measurements were performed by a CHI760E electrochemical workstation (Shanghai Chenhua Instruments) at 1 kHz with bias voltages ranging from 1.4 to 0 V and an AC voltage of 20 mV was used to test the corresponding capacitance at shifty bias voltage. AS measurements were performed with a CHI760E electrochemical workstation (Shanghai Chenhua Instruments) at different temperatures ranging from 250 to 320 K in the dark at a relatively low vacuum (�10 Pa) with a small AC disturbed voltage of 20 mV. The frequency scope from 1 to 100 kHz and a DC bias voltage of 0 V was kept during the measurements. The relationship can be derived by the following equation. 



<!-- Start of picture text -->
bT 2<br>Eε = kBTLn<br>u<br>!<br>Vbi udC<br>NTðEuÞ = �<br>qWkBT , du<br><!-- End of picture text -->

where u0 is the characteristic transition angular frequency, b is the temperature parameter, and Ea is the activation energy of the trap. The built-in potential (Vbi) and the depletion width (W) in the perovskite layers can be estimated by the following depletion approximation equation (Mott-Schottky): 



<!-- Start of picture text -->
A 2 2ðVbi � VÞ<br>C 2 = qεε0NB<br><!-- End of picture text -->

where A, C, N, and V are the active area, capacitance, doping profile, and applied bias voltage, respectively. The linear region of the Mott-Schottky plots describes the property of the depletion layer, where the intersection with the bias voltage 

830 Joule 6, 816–833, April 20, 2022 

**ll** 

##### Article 

gives Vbi and the slope determines the doping density N in perovskites. The depletion width can be obtained according to the following equation: 



<!-- Start of picture text -->
f f i f f i f f i f f i f f i f f i f f i ffi<br>2εε0Vbi<br>W =<br>s qNB<br><!-- End of picture text -->

The dissociation energies of PbBr2 and PbCl2 can be estimated by the following equations: 



<!-- Start of picture text -->
PbBr2 ������3:06 eV � !Pb 0 + 2Br [ (Equation 3)<br>PbCl2 ������3:19 eV � !Pb 0 + 2Cl [ (Equation 4)<br><!-- End of picture text -->

###### SUPPLEMENTAL INFORMATION 

Supplemental information can be found online at https://doi.org/10.1016/j.joule. 2022.03.005. 

###### ACKNOWLEDGMENTS 

This work was supported by the National Natural Science Foundation of China (grant numbers 62074117, 61904126, 12134010, and 12174290), the Shenzhen Fundamental Research Program (grant number JCYJ20190808152609307), the Fundamental Research Funds for the Central Universities (grant number 2042021kf0228), and the Natural Science Foundation of Hubei Province, China (grant numbers 2019AAA020 and 2021CFB039). 

###### AUTHOR CONTRIBUTIONS 

J.L. and W.K. formulated experimental planning experiments and conducted experiments and data analysis. X.H., C.W., C.C., M.X., J.L., C.T., and R.Y. assisted the experimental process. C.L. and G.X. tested and analyzed transient absorption spectra. This work was supported by funding acquisition from C.T., W.K., and G.F. The original draft was written by J.L. and G.F. The manuscript was reviewed and edited by G.F. 

###### DECLARATION OF INTERESTS 

The authors declare no competing interests. 

Received: October 18, 2021 Revised: January 19, 2022 Accepted: March 17, 2022 Published: April 12, 2022 

###### REFERENCES 

1. Kojima, A., Teshima, K., Shirai, Y., and Miyasaka, T. (2009). Organometal halide perovskites as visible-light sensitizers for photovoltaic cells. J. Am. Chem. Soc. 131, 6050–6051. 

2. Yang, W.S., Noh, J.H., Jeon, N.J., Kim, Y.C., Ryu, S., Seo, J., and Seok, S.I. (2015). SOLAR CELLS. High-performance photovoltaic perovskite layers fabricated through intramolecular exchange. Science 348, 1234–1237. 

3. Yang, X., Luo, D., Xiang, Y., Zhao, L., Anaya, M., Shen, Y., Wu, J., Yang, W., Chiang, Y.H., Tu, Y., et al. (2021). Buried interfaces in halide 

- perovskite photovoltaics. Adv. Mater. 33, 6. NREL. Research cell efficiency records, NREL. e2006435. https://www.nrel.gov/pv/cell-efficiency.html. 

4. Wang, Y., Wu, T., Barbaud, J., Kong, W., Cui, 7. Richter, A., Mu¨ ller, R., Benick, J., Feldmann, F., D., Chen, H., Yang, X., and Han, L. (2019). Steinhauser, B., Reichel, C., Fell, A., Bivour, M., Stabilizing heterostructures of soft Hermle, M., and Glunz, S.W. (2021). Design perovskite semiconductors. Science 365,, rules for high-efficiency both-sides-contacted 687–691.. silicon solar cells with balanced charge carrier transport and recombination losses. Nat. 

5. Li, N., Niu, X., Li, L., Wang, H., Huang, Z., Energy 6, 429–438. Zhang, Y., Chen, Y., Zhang, X., Zhu, C., Zai, H., et al. (2021). Liquid medium annealing for 8. Cai, B., Xing, Y., Yang, Z., Zhang, W.H., and fabricating durable perovskite solar cells with Qiu, J. (2013). High performance hybrid solar improved reproducibility. Science 373, cells sensitized by organolead halide 561–567. perovskites. Energy Environ. Sci. 6, 1480–1485. 6, 1480–1485., 1480–1485.. 

4. Wang, Y., Wu, T., Barbaud, J., Kong, W., Cui, D., Chen, H., Yang, X., and Han, L. (2019). Stabilizing heterostructures of soft perovskite semiconductors. Science 365,, 687–691.. 

8. Cai, B., Xing, Y., Yang, Z., Zhang, W.H., and Qiu, J. (2013). High performance hybrid solar cells sensitized by organolead halide perovskites. Energy Environ. Sci. 6, 1480–1485. 6, 1480–1485., 1480–1485.. 

Joule 6, 816–833, April 20, 2022 831 

#### **ll** 

##### Article 

9. Chen, W., Zhou, Y., Wang, L., Wu, Y., Tu, B., Yu, B., Liu, F., Tam, H.-W., Wang, G., Djuri�si�c, A.B., et al. (2018). Molecule-doped nickel oxide: verified charge transfer and planar inverted mixed cation perovskite solar cell. Adv. Mater. 30, e1800515. 

10. Fu, P., Hu, S., Tang, J., and Xiao, Z. (2021). Material exploration via designing spatial arrangement of octahedral units: a case study of lead halide perovskites. Front. Optoelectron. 14, 252–259. 

11. Liang, C., Gu, H., Xia, J., Mei, S., Pang, P., Zhang, N., Guo, J., Guo, R., Shen, Y., Yang, S., et al. (2021). Recent progress in perovskitebased reversible photon-electricity conversion devices. Adv. Funct. Mater. 32, 2108926. 

12. Song, Z., Watthage, S.C., Phillips, A.B., Tompkins, B.L., Ellingson, R.J., and Heben, M.J. (2015). Impact of processing temperature and composition on the formation of methylammonium lead iodide perovskites. Chem. Mater. 27, 4612–4619. 

13. Jeong, J., Kim, M., Seo, J., Lu, H., Ahlawat, P., Mishra, A., Yang, Y., Hope, M.A., Eickemeyer, F.T., Kim, M., et al. (2021). Pseudo-halide anion engineering for a-FAPbI3 perovskite solar cells. Nature 592, 381–385. 

14. Zhang, W., Pathak, S., Sakai, N., Stergiopoulos, T., Nayak, P.K., Noel, N.K., Haghighirad, A.A., Burlakov, V.M., deQuilettes, D.W., Sadhanala, A., et al. (2015). Enhanced optoelectronic quality of perovskite thin films with hypophosphorous acid for planar heterojunction solar cells. Nat. Commun. 6, 10030. 

15. Chavan, R.D., Prochowicz, D., Tavakoli, M.M., Yadav, P., and Hong, C.K. (2020). Surface treatment of perovskite layer with guanidinium iodide leads to enhanced moisture stability and improved efficiency of perovskite solar cells. Adv. Mater. Interfaces 7, 2000105. 

16. Jiang, Q., Zhao, Y., Zhang, X., Yang, X., Chen, Y., Chu, Z., Ye, Q., Li, X., Yin, Z., and You, J. (2019). Surface passivation of perovskite film for efficient solar cells. Nat. Photon. 13, 460–466. 

17. Ono, L.K., Liu, S.F., and Qi, Y. (2020). Reducing detrimental defects for high-performance metal halide perovskite solar cells. Angew. Chem. Int. Ed. Engl. 59, 6676–6698. 

18. Juarez-Perez, E.J., Ono, L.K., Maeda, M., Jiang, Y., Hawash, Z., and Qi, Y. (2018). Photodecomposition and thermal decomposition in methylammonium halide lead perovskites and inferred design principles to increase photovoltaic device stability. J. Mater. Chem. A 6, 9604–9612. 

19. Meng, L., You, J., and Yang, Y. (2018). Addressing the stability issue of perovskite solar cells for commercial applications. Nat. Commun. 9, 5265. 

20. Song, Z., McElvany, C.L., Phillips, A.B., Celik, I., Krantz, P.W., Watthage, S.C., Liyanage, G.K., Apul, D., and Heben, M.J. (2017). A technoeconomic analysis of perovskite solar module manufacturing with low-cost materials and techniques. Energy Environ. Sci. 10, 1297– 1305. 

21. Weerasinghe, H.C., Dkhissi, Y., Scully, A.D., Caruso, R.A., and Cheng, Y.-B. (2015). Encapsulation for improving the lifetime of 

flexible perovskite solar cells. Nano Energy 18, 118–125. 

22. Li, Y., Xu, X., Wang, C., Ecker, B., Yang, J., Huang, J., and Gao, Y. (2017). Light-induced degradation of CH3NH3PbI3 hybrid perovskite thin film. J. Phys. Chem. C 121, 3904–3910. 

23. Yuan, Y., and Huang, J. (2016). Ion migration in organometal trihalide perovskite and its impact on photovoltaic efficiency and stability. Acc. Chem. Res. 49, 286–293. 

24. Bi, E., Chen, H., Xie, F., Wu, Y., Chen, W., Su, Y., Islam, A., Gra¨tzel, M., Yang, X., and Han, L. (2017). Diffusion engineering of ions and charge carriers for stable efficient perovskite solar cells. Nat. Commun. 8, 15330. 

25. Dawood, R.I., Forty, A.J., Tubbs, M.R., and Frank, F.C. (1965). The photodecomposition of lead iodide. Proc. R. Soc. A: Math. Phys. Eng. Sci. 284, 272–288. 

26. Wang, R., Xue, J., Wang, K.-L., Wang, Z.-K., Luo, Y., Fenning, D., Xu, G., Nuryyeva, S., Huang, T., Zhao, Y., et al. (2019). Constructive molecular configurations for surface-defect passivation of perovskite photovoltaics. Science 366, 1509–1513. 

27. Wang, H., Wang, Z., Yang, Z., Xu, Y., Ding, Y., Tan, L., Yi, C., Zhang, Z., Meng, K., Chen, G., et al. (2020). Ligand-modulated excess PbI2 nanosheets for highly efficient and stable perovskite solar cells. Adv. Mater. 32, 2000865. 

28. Roose, B., Dey, K., Chiang, Y.-H., Friend, R.H., and Stranks, S.D. (2020). Critical assessment of the use of excess lead iodide in lead halide perovskite solar cells. J. Phys. Chem. Lett. 11, 6505–6512. 

29. Tang, X., Brandl, M., May, B., Levchuk, I., Hou, Y., Richter, M., Chen, H., Chen, S., Kahmann, S., Osvet, A., et al. (2016). Photoinduced degradation of methylammonium lead triiodide perovskite semiconductors. J. Mater. Chem. A 4, 15896–15903. 

30. Wang, L., Zhou, H., Hu, J., Huang, B., Sun, M., Dong, B., Zheng, G., Huang, Y., Chen, Y., Li, L., et al. (2019). A Eu<sup>3+</sup> -Eu<sup>2+</sup> ion redox shuttle imparts operational durability to Pb-I perovskite solar cells. Science 363, 265–270. 

31. Tumen-Ulzii, G., Qin, C., Klotz, D., Leyden, M.R., Wang, P., Auffray, M., Fujihara, T., Matsushima, T., Lee, J.-W., Lee, S.-J., et al. (2020). Detrimental effect of unreacted PbI2 on the long-term stability of perovskite solar cells. Adv. Mater. 32, e1905035. 

32. Jacobsson, T.J., Correa-Baena, J.-P., Halvani Anaraki, E., Philippe, B., Stranks, S.D., Bouduban, M.E.F., Tress, W., Schenk, K., Teuscher, J., Moser, J.-E., et al. (2016). Unreacted PbI2 as a double-edged sword for enhancing the performance of perovskite solar cells. J. Am. Chem. Soc. 138, 10331–10343. 

33. Cappel, U.B., Svanstro¨ m, S., Lanzilotto, V., Johansson, F.O.L., Aitola, K., Philippe, B., Giangrisostomi, E., Ovsyannikov, R., Leitner, T., Fo¨ hlisch, A., et al. (2017). Partially reversible photoinduced chemical changes in a mixedion perovskite material for solar cells. ACS Appl. Mater. Interfaces 9, 34970–34978. 

34. Chun-Ren Ke, J., Walton, A.S., Lewis, D.J., Tedstone, A., O’Brien, P., Thomas, A.G., and Flavell, W.R. (2017). In situ investigation of 

degradation at organometal halide perovskite surfaces by X-ray photoelectron spectroscopy at realistic water vapour pressure. Chem. Commun. (Camb) 53, 5231–5234. 

35. Lin, W.-C., Lo, W.-C., Li, J.-X., Wang, Y.-K., Tang, J.-F., and Fong, Z.-Y. (2021). In situ XPS investigation of the X-ray-triggered decomposition of perovskites in ultrahigh vacuum condition. npj Mater. Degrad. 5, 13. 

36. McGettrick, J.D., Hooper, K., Pockett, A., Baker, J., Troughton, J., Carnie, M., and Watson, T. (2019). Sources of Pb(0) artefacts during XPS analysis of lead halide perovskites. Mater. Lett. 251, 98–101. 

37. Yin, W.-J., Shi, T., and Yan, Y. (2014). Unusual defect physics in CH3NH3PbI3 perovskite solar cell absorber. Appl. Phys. Lett. 104, 063903. 

38. Kim, Y.C., Jeon, N.J., Noh, J.H., Yang, W.S., Seo, J., Yun, J.S., Ho-Baillie, A., Huang, S., Green, M.A., Seidel, J., et al. (2016). Beneficial effects of PbI2 incorporated in organo-lead halide perovskite solar cells. Adv. Energy Mater. 6, 1502104. 

39. Shi, B., Yao, X., Hou, F., Guo, S., Li, Y., Wei, C., Ding, Y., Li, Y., Zhao, Y., and Zhang, X. (2018). Unraveling the passivation process of PbI2 to enhance the efficiency of planar perovskite solar cells. J. Phys. Chem. C 122, 21269–21276. 

40. Liu, F., Dong, Q., Wong, M.K., Djuri�si�c, A.B., Ng, A., Ren, Z., Shen, Q., Surya, C., Chan, W.K., Wang, J., et al. (2016). Is excess PbI2 beneficial for perovskite solar cell performance? Adv. Energy Mater. 6, 1502206. 

41. Donakowski, A., Miller, D.W., Anderson, N.C., Ruth, A., Sanehira, E.M., Berry, J.J., Irwin, M.D., Rockett, A., and Steirer, K.X. (2021). Improving photostability of cesium-doped formamidinium lead triiodide perovskite. ACS Energy Lett. 6, 574–580. 

42. Ke, W., Xiao, C., Wang, C., Saparov, B., Duan, H.-S., Zhao, D., Xiao, Z., Schulz, P., Harvey, S.P., Liao, W., et al. (2016). Employing lead thiocyanate additive to reduce the hysteresis and boost the fill factor of planar perovskite solar cells. Adv. Mater. 28, 5214–5221. 

43. Benavides-Garcia, M., and Balasubramanian, K. (1994). Bond energies, ionization potentials, and the singlet-triplet energy separations of SnCl2, SnBr2, SnI2, PbCl2, PbBr2, PbI2, and their positive ions. J. Chem. Phys. 100, 2821–2830. 

44. Emara, J., Schnier, T., Pourdavoud, N., Riedl, T., Meerholz, K., and Olthof, S. (2016). Impact of film stoichiometry on the ionization energy and electronic structure of CH3NH3PbI3 perovskites. Adv. Mater. 28, 553–559. 

45. Nickel, N.H., Lang, F., Brus, V.V., Shargaieva, O., and Rappich, J. (2017). Unraveling the lightinduced degradation mechanisms of CH3NH3PbI3 perovskite films. Adv. Electron. Mater. 3, 1700158. 

46. Song, Z., Wang, C., Phillips, A.B., Grice, C.R., Zhao, D., Yu, Y., Chen, C., Li, C., Yin, X., Ellingson, R.J., et al. (2018). Probing the origins of photodegradation in organic-inorganic metal halide perovskites with time-resolved mass spectrometry. Sustainable Energy Fuels 2, 2460–2467. 

47. Ke, W., Spanopoulos, I., Stoumpos, C.C., and Kanatzidis, M.G. (2018). Myths and reality of 

832 Joule 6, 816–833, April 20, 2022 

#### **ll** 

##### Article 

HPbI3 in halide perovskite solar cells. Nat. Commun. 9, 4785. 

48. Zhang, J., Qin, J., Wang, M., Bai, Y., Zou, H., Keum, J.K., Tao, R., Xu, H., Yu, H., Haacke, S., et al. (2019). Uniform permutation of quasi-2d perovskites by vacuum poling for efficient, high-fill-factor solar cells. Joule 3, 3061–3071. 

49. Ye, S., Rao, H., Zhao, Z., Zhang, L., Bao, H., Sun, W., Li, Y., Gu, F., Wang, J., Liu, Z., et al. (2017). A breakthrough efficiency of 19.9% obtained in inverted perovskite solar cells by using an efficient trap state passivator Cu(thiourea)I. J. Am. Chem. Soc. 139, 7504–7512. 

50. Li, N., Tao, S., Chen, Y., Niu, X., Onwudinanti, C.K., Hu, C., Qiu, Z., Xu, Z., Zheng, G., Wang, L., et al. (2019). Cation and anion immobilization through chemical bonding enhancement with fluorides for stable halide perovskite solar cells. Nat. Energy 4, 408–415. 

51. Slotcavage, D.J., Karunadasa, H.I., and McGehee, M.D. (2016). Light-induced phase segregation in halide-perovskite absorbers. ACS Energy Lett. 1, 1199–1205. 

52. Yang, J., Tang, W., Yuan, R., Chen, Y., Wang, J., Wu, Y., Yin, W.-J., Yuan, N., Ding, J., and Zhang, W.-H. (2020). Defect mitigation using d-penicillamine for efficient methylammoniumfree perovskite solar cells with high operational stability. Chem. Sci. 12, 2050–2059. 

53. Duan, H.-S., Zhou, H., Chen, Q., Sun, P., Luo, S., Song, T.-B., Bob, B., and Yang, Y. (2015). The identification and characterization of defect states in hybrid organic-inorganic perovskite photovoltaics. Phys. Chem. Chem. Phys. 17, 112–116. 

54. Luo, D., Yang, W., Wang, Z., Sadhanala, A., Hu, Q., Su, R., Shivanna, R., Trindade, G.F., Watts, J.F., Xu, Z., et al. (2018). Enhanced photovoltage for inverted planar 

heterojunction perovskite solar cells. Science 360, 1442–1446. 

55. Zhou, Y., Wang, F., Cao, Y., Wang, J.-P., Fang, H.-H., Loi, M.A., Zhao, N., and Wong, C.-P. (2017). Benzylamine-treated wide-bandgap perovskite with high thermal-photostability and photovoltaic performance. Adv. Energy Mater. 7, 1442–1446. 

56. Yang, G., Ren, Z., Liu, K., Qin, M., Deng, W., Zhang, H., Wang, H., Liang, J., Ye, F., Liang, Q., et al. (2021). Stable and low-photovoltage-loss perovskite solar cells by multifunctional passivation. Nat. Photon. 15, 681–689. 

57. Duong, T., Pham, H., Yin, Y., Peng, J., Mahmud, M.A., Wu, Y., Shen, H., Zheng, J., Tran-Phu, T., Lu, T., et al. (2021). Efficient and stable wide bandgap perovskite solar cells through surface passivation with long alkyl chain organic cations. J. Mater. Chem. A 9, 18454–18465. 

Joule 6, 816–833, April 20, 2022 833 

