# Engineering Semiconductor Quantum Dots for Selectivity Switch on High-Performance Heterogeneous Coupling Photosynthesis.

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | ACS Nano |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 185 |
| 作者 | Ming-Yu Qi, M. Conte, Zi-Rong Tang, Yi-Jun Xu |
| DOI | 10.1021/acsnano.2c08652 |
| 源文件 | 058_Qi_2022_Engineering-Semiconductor-Quantum-Dots-for-Selec.pdf |

---


eprints@whiterose.ac.uk https://eprints.whiterose.ac.uk **Universities of Leeds, Sheffield and York** 

Deposited via The University of Sheffield. 

White Rose Research Online URL for this paper: <mark>https://eprints.whiterose.ac.uk/id/eprint/192434/</mark> 

Version: Accepted Version 

## **Article:** 

Qi, M.-Y., Conte, M., Tang, Z.-R. et al. (2022) Engineering semiconductor quantum dots for selectivity switch on high-performance heterogeneous coupling photosynthesis. ACS Nano, 16 (10). pp. 17444-17453. ISSN: 1936-0851 

<mark>https://doi.org/10.1021/acsnano.2c08652</mark> 

This document is the Accepted Manuscript version of a Published Work that appeared in final form in ACS Nano, copyright © American Chemical Society after peer review and technical editing by the publisher. To access the final edited and published work see https://doi.org/10.1021/acsnano.2c08652 

#### **Reuse** 

Items deposited in White Rose Research Online are protected by copyright, with all rights reserved unless indicated otherwise. They may be downloaded and/or printed for private study, or other acts as permitted by national copyright laws. The publisher or other rights holders may allow further reproduction and re-use of the full text version. This is indicated by the licence information on the White Rose Research Online record for the item. 

#### **Takedown** 

If you consider content in White Rose Research Online to be in breach of UK law, please notify us by emailing eprints@whiterose.ac.uk including the URL of the record and the reason for the withdrawal request. 



ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

# **Engineering Semiconductor Quantum Dots for Selectivity Switch on High-Performance Heterogeneous Coupling Photosynthesis** 

_Ming-Yu Qi,_<sup>_1_</sup> _Marco Conte,_<sup>_2_</sup> _Zi-Rong Tang,_<sup>_1_</sup> _and Yi-Jun Xu_<sup>_*,1_</sup> 

- 1 College of Chemistry, State Key Laboratory of Photocatalysis on Energy and Environment, Fuzhou University, Fuzhou, 350116, China. 

- 2 Department of Chemistry, University of Sheffield, Sheffield, S3 7HF, UK. 

1 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

## **Abstract** 

Semiconductor-based photoredox catalysis brings an innovative strategy for sustainable organic transformation, _e.g.,_ C−C/C−X bond formation, _via_ radical coupling under mild conditions. However, since semiconductors interact with photogenerated radicals unselectively, the precise control of selectivity for such organic synthesis by steering radical conversion is extremely challenging. Here, by the judicious design of structurally well-defined and atomically dispersed cocatalyst over semiconductor quantum dots, we demonstrate the precise selectivity switch on high-performance selective heterogeneous coupling photosynthesis of C–C bond or C–N bond along with hydrogen production over the Ni-oxo cluster and single Pd atom-decorated CdS quantum dots crafted onto the SiO2 support. Mechanistic studies unveil that the Ph(•CH)NH2 and PhCH2NH 2<sup>•+</sup> act as dominant radical intermediates for such divergent organic synthesis of C–C coupled vicinal diamines and C–N coupled imines, as respectively enabled by Ni-oxo clusters assisted radical-radical coupling and single Pd atom assisted radical addition-elimination. This work overcomes the pervasive difficulties of selectivity regulation in semiconductor-based photochemical synthesis, highlighting a vista of utilizing atomically dispersed cocatalysts as 

active sites to maneuver unselective radical conversion by engineering quantum dots toward selective heterogeneous photosynthesis. 

KEYWORDS: artificial photosynthesis, covalent-assembly, semiconductor quantum dots, atomically dispersed cocatalysts, C−X bond formation 

2 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

### **TOC GRAPHICS** 



3 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

Organic transformations involving C−C/C−X bond (X = N, O, S) formation are of paramount significance in the synthesis of pharmaceuticals and fine chemicals.<sup>1-3</sup> Over the past decade, photoredox catalysis has been recognized as a powerful technique for such organic synthesis, most prominently with the generation of highly reactive intermediates, _i.e.,_ carbonand heteroatom-centered radicals as an enabling platform.<sup>4-7</sup> Traditionally, these radicals are accessed _via_ well-known single electron transfer (SET) between organic substrates and the triplet excited state of _d_<sup>_6_</sup> transition-metal complexes (especially [Ru] and [Ir]) generated through visible-light-induced metal to ligand charge transfer (MLCT).<sup>4-5, 8</sup> Due to the intrinsic advantages of defined coordination geometry, active center and ligands, these transition-metal complexes as homogeneous photocatalysts can be modified rationally to a given selective organic synthesis such as C–X bond formation.<sup>5, 9</sup> However, most of the molecular transition-metal complexes for triplet-initiated reactions are not stable,<sup>10</sup> and these homogeneous catalytic systems are often plagued by the effective product/catalyst separation and catalyst recycling.<sup>9-11</sup> 

Semiconductor-based heterogeneous photocatalysis has emerged as an alternative to initiate radical coupling reactions for C−C/C−X bond synthesis owing to its high efficiency and convenience in the generation of various high-reactive radical species _via_ charge transfer between organic molecules and semiconductors under mild conditions.<sup>12</sup> However, since semiconductors interact with photogenerated radicals unselectively,<sup>13</sup> the precise control of selectivity by steering radical conversion is extremely challenging for C−C/C−X bond synthesis on the surface of semiconductors. As a bridge between homo- and heterogeneous catalysis, atomically dispersed catalysts render the merits of homogeneous catalysts, including the welldefined active sites and the tunable interactions with ligands, and inherit the high durability and excellent recoverability as heterogeneous catalysts.<sup>14-15</sup> In particular, the uniform active sites, featuring unsaturated coordination sites and characteristic electronic structures, are expected to unlock exclusively high activity and selectivity.<sup>14-17</sup> In this regard, the rational design of semiconductor-based photocatalysts with the body of heterogeneous catalysts and the soul of homogeneous catalysts by incorporating atomically dispersed metal guest with the host semiconductor, would be a powerful but yet-to-be-realised strategy toward real-life and scalable solar-driven photoredox organic synthesis. 

4 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

Herein, taking amines, the most versatile building blocks for the synthesis of N-containing compounds, as proof-of-concept model molecules,<sup>18-20</sup> we report the judicious design of structurally well-defined Ni or Pd-decorated CdS quantum dots (QDs) crafted onto spherical SiO2 (M-CdS/SiO2, M=Ni or Pd) as the robust, heterogeneous catalyst for the high-performance photochemical coupling of amines into tunable C–C coupled vicinal diamines or C–N coupled imines concomitantly with hydrogen (H2) production at ambient conditions. High-reactive C- centered radicals (Ph(•CH)NH2) are generated _via_ the electron transfer followed by proton transfer between benzylamine molecules and photoexcited CdS QDs. Atomically dispersed Ni or 

Pd species act as active sites to steer Ph(•CH)NH2 radical conversion pathway for precisely controlling the photochemical selectivity switch between C–C and C–N bond formation reaction along with enhanced activity, _i.e.,_ direct C–C coupling of Ph(•CH)NH2 for vicinal diamines synthesis by Ni-oxo clusters-assisted catalysis and C–N coupling of aldimine intermediate (Ph(CH)NH, generated from the dehydrogenation of Ph(•CH)NH2) for imines synthesis by single Pd atoms-assisted catalysis. The use of SiO2 support and robust covalent-assembly strategy significantly improves the anti-photocorrosion and recycling capability of M-CdS QDs _._ The successful gram-scale synthesis and sun-light irradiation experiment further showcase the significant potential of the present artificial photosynthesis system for real scale-up applications. 

## **Results and Discussion** 

## **Preparation and characterization of the M-CdS/SiO 2** 

To overcome the drawbacks of weak interfacial interaction, poor anti-leaching capability and low-loading net content of photoactive particles in previous electrostatic self-assembly approach,<sup>21-23</sup> we herein turn to adopt a robust covalent-assembly approach ( **Figure 1a** and **S1** ) to achieve efficient interfacial binding and improve the loading amount of photoactive CdS QDs onto SiO2 support before crafting atomically dispersed metal cocatalysts. This covalent-based interfacial engineering approach is inspired from the application of 1-(3(dimethylamino)propyl)-3-ethylcarbodiimide hydrochloride (EDC)/N-hydroxysuccinimide (NHS) cross-linking reaction for the formation of amide bonds in the assemble/modification of proteins.<sup>24-27</sup> In our designed synthesis methodology, the SiO2 supports are firstly modified by branched poly-ethylenimine (BPEI) for grafting with −NH2 groups;<sup>21, 23</sup> whereas CdS QDs are prepared using 3-mercaptopropionic acid (MPA) as capping molecule,<sup>23</sup> which serves as a stabilizer to disperse QDs and provides −COOH groups for grafting with SiO2. After activation 

5 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

of the −COOH groups in CdS QDs by EDC/NHS, amidation reaction can occur smoothly to form a covalent amide bond, thereby robustly linking MPA-CdS QDs and BPEI-SiO2 support. Upon grafting MPA-CdS QDs onto BPEI-SiO2 support, a binding energy located at 287.1 eV, corresponding to the newly formed amide bond (–CON–), is observed in the C 1s X-ray photoelectron spectroscopy (XPS) spectrum of CdS-SiO2 ( **Figure S2** ).<sup>28-29</sup> This is also detected by the N 1s and O 1s XPS spectra, in which the featured peaks appeared at 397.2 eV of N 1s region and 530.1 eV of O 1s region are both attributed to –CON– bond.<sup>29-30</sup> The formation of an amide bond was further confirmed by Fourier-transform infrared spectroscopy ( **Figure S3** ). It is evident that utilizing such EDC/NHS covalent-assembly approach is able to realize the effective chemical grafting of CdS QDs onto SiO2 supports. Consequently, as compared to electrostatic self-assembly approach, this robust covalent-assembly approach not only achieves a high QDs loading of approximately 15 wt% onto SiO2 spheres (see **Figure S4-6** for crystal structures, morphologies, and optical absorption properties), but also endows CdS/SiO2 with ultra-low element leakage after the photochemical reaction as will be discussed below. 

Upon achieving the robust binding and high loading of CdS QDs onto SiO2 supports by such covalent-assembly approach, we further decorated the well-fabricated CdS/SiO2 with atomically  dispersed  metal  (single-atom  or  cluster)  cocatalysts  through  a  facile _in-situ_ photodeposition strategy ( **Figure 1a** ). In our approach, CdS/SiO2 contains residual dangling – COOH groups, which can serve as a rigid ligand to adsorb and anchor Pd<sup>2+</sup> (or Ni<sup>2+</sup> ) cations. Photodeposition of Pd (or Ni) species was carried out using PdCI2 (NiCl2∙6H2O for Ni) as a precursor in aqueous solution, which was irradiated with a xenon lamp for 0.5 h. No formation of Pd or Ni-derived nanoparticles is observed in high-resolution transmission electron microscopy (TEM) images ( **Figure S7** and **S8** ) of the obtained M-CdS/SiO2 (M=Ni or Pd). Elemental mapping results of the individual M-CdS/SiO2 sphere ( **Figure S7e** and **S8e** ) reveal that the Pd or Ni element is evenly distributed in the surface of CdS/SiO2, and the aberration-corrected highangle annular dark-field scanning TEM (HAADF-STEM) images certify that the Pd or Ni species is atomically dispersed on CdS/SiO2 ( **Figure S9** ). 

6 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 





**Figure 1.** (a) Synthesis procedure for the M-CdS/SiO2 composite (M=Ni or Pd). (b) Normalized Pd K-edge XANES spectra of Pd-CdS/SiO2 in reference to Pd foil and PdO. (c) FT-EXAFS spectra of Pd-CdS/SiO2 in reference to Pd foil and PdO. (d) The corresponding EXAFS fitting curves for Pd-CdS/SiO2. (e) Normalized Ni K-edge XANES spectra of Ni-CdS/SiO2 in reference to Ni foil and NiO. (f) FT-EXAFS spectra of Ni-CdS/SiO 2 in reference to Ni foil and NiO. (g) The corresponding EXAFS fitting curves for Ni-CdS/SiO . Insets in 2 **Figure 1d** and **g** are the structures of Pd-CdS/SiO2 and Ni-CdS/SiO2 optimized by first principle DFT calculations. Atoms in cyan, green, red, brown, yellow, grey and white represent Pd, Ni, O, Cd, S, C and H respectively. 

To further investigate the local coordination environment of atomically dispersed Pd or Ni species, X-ray absorption spectroscopy (XAS) measurements were carried out. **Figure 1b** shows 

7 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

the Pd K-edge X-ray absorption near-edge structure (XANES) spectrum of Pd-CdS/SiO2, along with Pd foil and PdO as references. Evidently, the threshold energy (E0) of the Pd K-edge for PdCdS/SiO2 is between that of PdO and Pd foil, and the XANES white line peak of Pd-CdS/SiO2 is very close to that of PdO, demonstrating that the electronic state of Pd in Pd-CdS/SiO2 approximates to +2.<sup>31</sup> Processed through a Fourier transform (FT), the Pd extended X-ray absorption fine structure (EXAFS) spectra ( **Figure 1c** ) are obtained to determine the local structures of the Pd species. In reference to standard Pd foil and PdO, Pd-CdS/SiO does not 2 present the peak in region 2 to 3 Å from the Pd-Pd contribution, suggesting the sole presence of isolated and dispersed Pd single atoms in Pd-CdS/SiO2.<sup>32-33</sup> The only one notable Pd-O coordination peak in region 1 to 2 Å can be observed in EXAFS spectrum of Pd-CdS/SiO2, which indicates that the single Pd atoms are coordinated with O atoms. Quantitative coordination structural results for the isolated Pd atoms are extracted from EXAFS curve fitting ( **Figure 1d** and **Table S1** ). The coordination number (CN) of the O atoms for individual Pd atoms is calculated to be 4.1, corroborating the coordinately unsaturated single Pd atoms as compared with Pd foil (CN = 12) and PdO (CN = 8).<sup>34</sup> In addition, the Ni K-edge XANES spectrum of NiCdS/SiO2, featuring the pre-edge and white-line peak similar to the reference spectrum of NiO ( **Figure 1e** ), confirms that Ni atoms carry positive charges +2, consistent with the XPS data ( **Figure S10** and **S11** ).<sup>35</sup> Concerning the FT-EXAFS spectrum of Ni-CdS/SiO (2 **Figure 1f** ), besides a strong peak centered at about 2.0 Å from Ni–O contribution, another lower shell peak in the region 2.5 to 3.5 Å is detected, indicating the presence of Ni–O–Ni/Ni–Ni contribution derived from ultrasmall Ni-oxo clusters,<sup>36</sup> which was further confirmed by the Wavelet transform plot and EXAFS data fitting results ( **Figure S12** and **Table S2** ). With the further aid of first principle density functional theory (DFT) optimization calculations, the most stable structures of Pd-CdS/SiO2 and Ni-CdS/SiO2 were verified, as sketched in the insets model of **Figure 1d** and **g** . 

8 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 



**Figure 2** (a) Schematic representation of the chemical reactions involved in the suggested process for conversion of BA into BBAD or DPEA as well as H2. (b) Results from dehydrocoupling of BA to DPEA and H2 over CdS/SiO2 composite with different weight contents of CdS QDs after 6 h of xenon-lamp irradiation. (c) Photocatalytic oxidative coupling of BA to DPEA/BBAD and H2 over different samples. (d) Time profiles of oxidative coupling of BA over Pd-CdS/SiO2 and Ni-CdS/SiO2 composite. Recycling performance of (e) Pd-CdS/SiO2 composite and (f) Ni-CdS/SiO2 composite toward photocatalytic selective BA oxidation with H2 production. 

## **Dehydrocoupling of amines to produce imines or vicinal diamines** 

N-containing compounds represent a privileged class of bulk commodities and fine chemicals, which are extensively used in pharmaceuticals, fragrances, dyes, fungicides, and agricultural chemicals.<sup>37</sup> Nearly 90% of the top 200 drugs are N-containing derived compounds, and their global market is more than $50 billion per year.<sup>18</sup> Amines, as well as their derivatives, are among the most versatile building blocks for the synthesis of above application-oriented N- containing chemicals.<sup>38</sup> In the next, we investigated the application of M-CdS/SiO2 (M=Ni or Pd) for the dehydrocoupling of amines into C–C coupled product of diamines or C–N coupled product of imines in one tunable photoredox catalytic system. Taking benzylamine (BA) as a 

9 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

model substrate, the dehydrocoupling of BA into N-benzylbenzaldimine (BBAD) or 1,2diphenylethylenediamine (DPEA) integrated with H2 production ( **Figure 2a** ) was carried out in an acetonitrile solution containing 0.2 mmol of BA and 10 mg of the obtained samples, which was irradiated with a xenon lamp at ambient conditions. A linear relationship between the CdS loading amount and the amount of evolved H2/DPEA is found, and the optimal DPEA formation amount of 53 μmol can be achieved over 15%-CdS/SiO2 with a selectivity of above 98% ( **Figure 2b** ). Upon decorating with Ni, the Ni-CdS/SiO exhibits enhanced H evolution rate by 2.8 times 2 2 as compared with CdS/SiO ; meanwhile, the DPEA formation rate improves from 5.9 to 17.0 2 mmol g CdS −1 h−1 ( **Figure 2c** and **S13a** ). Specifically, the decoration of Pd onto CdS/SiO2 not only boosts the evolution of H2, but also tunes the selectivity of BA oxidation from DPEA to BBAD. As a result, over Pd-CdS/SiO2, a BBAD formation rate of 22.1 mmol g −1 h−1 can be obtained CdS with a high selectivity of above 99% ( **Figure 2c** and **S13b** ). The molar ratios of oxidation product (DPEA/BBAD) and reduction product (H2) during the reaction, are calculated to be approximately 1.0, suggesting a stoichiometric dehydrocoupling reaction. With irradiation for 6 h, the yield of BBAD over Pd-CdS/SiO2 reaches 99% ( **Figure 2d** and **S14-16** ). As for DPEA, a yield of 90% is achieved over Ni-CdS/SiO2 with the selectivity of above 99% after 7 h. Furthermore, the optimized apparent quantum yield (AQY) of 15.7% for H2 is achieved at λ = 365 nm ( **Figure S17** ), which is a competitive photocatalytic system for selective organic transformation or H evolution. 2 

Such covalent-assembly approach of loading CdS QDs onto the SiO2 support is leading to the recovery and re-dispersion of ultrasmall CdS QDs from the reaction solution for long-term repeated uses. After four repeated trials, the catalytic performance for H2 and BBAD/DPEA production over M-CdS/SiO2 (M=Pd or Ni) remains stable ( **Figure 2e** and **f** ), whereas that of unsupported CdS QDs has diminished by approximately 33% for H2, 31% for DPEA ( **Figure S18** ). A very small amount of trimer (2,4,5-triphenyl-1 _H_ -imidazole, yield < 2%, **Figure S19** ) after three consecutive cycles is obtained over above catalysts, which presumably results from the photocyclization between residual BBAD and newly generated C-centered radical.<sup>39</sup> **Figure S20** and **21** illustrate the well maintenance of crystal structure and element composition in recycled M-CdS/SiO , reflecting a high durability of the covalent assembled M-CdS/SiO . As 2 2 displayed in **Table S3** , the results of inductively coupled plasma (ICP) spectroscopy analysis evidences that there are slightly detectable Cd<sup>2+</sup> (1.12 μg, corresponding to 0.19% of leaching 

10 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

ratio) and S<sup>2−</sup> (2.18 μg, corresponding to 0.24% of leaching ratio) leakage over CdS/SiO2 in the reaction solution, which are much lower than those of bare CdS QDs (4.35 μg for Cd<sup>2+</sup> , 7.08 μg for S<sup>2−</sup> ). These results signify that this covalent-assembly strategy not only facilitates the recovery of CdS QDs for reuse, but also inhibits the photocorrosion of CdS QDs, thus endowing M-CdS/SiO2 with excellent durability. 





**Figure 3.** (a) Substrate scope of amines. (b) Gram-scale synthesis. (c) Sun-light irradiation reaction.<sup>[a]</sup> Reaction conditions: 0.2 mmol BA, 10 mL CH3CN, 10 mg Pd-CdS/SiO2, Ar atmosphere, 300 W xenon lamp, 6 h, room temperature.<sup>[b]</sup> Yield (%).<sup>[c]</sup> Selectivity (%).<sup>[d]</sup> H2 

11 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

production rate (mmol g CdS −1 h−1). [e]Reaction time is 4 h. [f]Reaction time is 5 h. [g]Reaction conditions: 0.2 mmol BA, 10 mL CH3CN, 10 mg Ni-CdS/SiO2. Ar atmosphere, 300 W xenon lamp, 7 h, room temperature. 

## **Substrate scope and synthetic applications** 

Following these initial promising results, we began to evaluate the generality of our cooperative photoredox-catalysed system for the dehydrogenative coupling of amines into C–N coupled imines or C–C coupled vicinal diamines integrated with H2 production. As displayed in **Figure 3a** , a wide range of aromatic amines bearing different para-substituent groups react smoothly to afford corresponding amines or vicinal diamines with moderate to excellent yields as well as outstanding selectivity (> 96%). (2b-2g and 3b-3g). Among them, a strong electronwithdrawing group, namely trifluoromethyl (–CF ), is also tolerated, albeit with relatively low 3 yields (49% for 2g, 59% for 3g). This system is also quite compatible with ortho- and metasubstituted aromatic amines to deliver the corresponding products in 52%–97% yields (2h-2i and 3h-3i). Dehydrogenative coupling of 3,4(or 2,4)-di-substituted aromatic amines furnishes the corresponding imines and vicinal diamines with yields of 81% (2j, 76% for 2k) and 50% (3j, 41% for 3k), respectively. In the case of α-methylbenzylamine, the desired products 2l and 3l are obtained in moderate yields of 75% and 40%, respectively. It is noteworthy that this current system is also applicable to heteroatom-containing amines (1m-1o), which usually have detrimental effects ( _i.e.,_ catalyst poisoning caused by the strong coordination of amines to the metal center) on the activity and stability of metal-complex catalysts,<sup>40</sup> although a slight drop in yields is observed (2m-2o and 3m-3o) compared with benzylic amines. 

Compared with previous reports on the synthesis of imines and vicinal diamines ( **Table S4** and **S5** ), the present system not only bypasses the use of additional chemical reagents, but also releases stoichiometric H2 as green fuel. In addition, this catalytic system is the first report of solar-driven dehydrocoupling of amines to vicinal diamines. More importantly, the catalytic performance over M-CdS/SiO2 is superior to that of the previously reported catalyst systems. As a proof-of-concept, this catalytic system was evaluated to synthesize BBAD and DPEA on a gram scale. Consequently, a BBAD yield of 92% (1.35 g) and a DPEA yield of 68% (1.08 g) within 36 h are obtained over Pd-CdS/SiO2 and Ni-CdS/SiO2, respectively ( **Figure 3b** ). Even more, the desired product BBAD and DPEA can be obtained with the yields of 78% and 53%, 

12 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

respectively, upon direct irradiation by natural sunlight ( **Figure 3c** ). These results demonstrate the feasibility and potential of this SiO2-supported M-CdS QDs protocol in practical synthesis. 





**Figure 4.** (a) Control experiments and quenching experiments with different additives catalysed by Ni-CdS/SiO2 and Pd-CdS/SiO2 composite. Scavenger concentrations: 20 mM CCI4, Lactic acid or DMPO. Reaction time: 6 h. (b) Redox potentials of oxidative dehydrogenation of BA and H2 evolution against the positions of VBM and CBM of CdS QDs. Hammett plots for the selective oxidation of para-substituted benzylamines coupled with H2 production over (c) PdCdS/SiO2 and (d) Ni-CdS/SiO2 composite. (e) _In-situ_ EPR spectra of CdS/SiO2, Ni-CdS/SiO2 and Pd-CdS/SiO2 composite in Ar saturated CH3CN solution in the presence of DMPO. 

## **Mechanism insight for dehydrocoupling of amines** 

To probe the reaction mechanism for the dehydrocoupling of amines integrated with H2 production in the present catalytic system, we first performed a series of control and quenching experiments, as displayed in **Figure 4a** . Control experiments imply that, in the absence of light or catalysts, the reaction cannot proceed at all ( **Figure 4a (ii)** ). The addition of CCl4 as electron scavenger completely ceased the H evolution, and moreover, the formation of BBAD/DPEA 2 was retarded once introducing lactic acid ( **Figure 4a (iii)** and **(iv)** ), suggesting the joint participation of electrons and holes for H2 and BBAD/DPEA production. Based on the Tauc plot 

13 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

( **Figure S22** ), the bandgap (Eg) of CdS QDs is evaluated to be 2.43 eV. The conduction band minimum (CBM) of CdS is estimated at −0.65 V vs normal hydrogen electrode (NHE) according to the Mott–Schottky analysis, and the valance band maximum (VBM) of CdS is thus calculated with the value of 1.78 V vs NHE. Moreover, the redox potential of BA is measured to be about 1.09 V vs NHE according to the cyclic voltammograms ( **Figure S23** ). Thermodynamic constraints require that, for these two half-reactions to proceed simultaneously, the CBM of CdS QDs needs to be more negative than H<sup>+</sup> /H2 energy level (−0.41 V vs NHE), whereas the VBM must have a more positive potential than BA/BA<sup>•+</sup> energy level (1.09 V vs NHE).<sup>12</sup> As sketched in **Figure 4b** , upon light irradiation, the charge carriers, _i.e.,_ electron-hole pairs, are generated from the photoexcition of CdS QDs; and the loading of Ni or Pd cocatalyst significantly expedites photoinduced charge carrier separation, as evidenced by **Figure S24** , which results in a significantly enhanced activity. The photoexcited holes with sufficient thermodynamic driving force can facilely oxidize BA into its cationic form for subsequent coupling reaction; meanwhile, the abstracted protons are reduced by photoexcited electrons to produce H2. 

To further decipher the catalytic mechanism for the selectivity regarding divergent synthesis of BBAD and DPEA over M-CdS/SiO2, the radical-quenching experiment has been conducted. The addition of 5,5-dimethyl-1-pyrrolineN-oxide (DMPO) as a radical scavenger significantly suppresses the formation of DPEA over Ni-CdS/SiO2, but only slightly retards the BBAD production over Pd-CdS/SiO2 ( **Figure 4a (v)** ), which preliminarily reveals that the generation of two kinds of homo-coupling products follows different intermediates-mediated pathways. In addition, the reaction for cumylamine dehydrogenation completely stops ( **Figure 4a (vi)** ), suggesting that the cleavage of α-C−H bond is crucial to the reaction. To identify the ratelimiting step of BBAD/DPEA formation, we examined the α-C−H bond activation in BA by graphing the Hammett plot. A reasonable linearity between the log(kX/kH) values and the Brown−Okamoto constants (σ<sup>+</sup> ) is obtained over Pd-CdS/SiO2 ( **Figure 4c** ), suggesting that the dehydrocoupling of BA proceeds _via_ the intermediacy of a cationic species (PhCH2NH 2<sup>•+</sup> ), and α-C−H bond cleavage is the rate-limiting step in the formation of BBAD.<sup>41-43</sup> However, for the synthesis of DPEA over Ni-CdS/SiO2, para-substituted benzylamines show irregular and marginal influence on the reaction rates ( **Figure 4d** ), confirming a neutral C-centered radical ( _i.e.,_ Ph(•CH)NH2) involved in the reaction.<sup>41, 44</sup> Furthermore, _in-situ_ electron paramagnetic resonance (EPR) spectroscopy was performed to monitor the effect of Pd or Ni cocatalyst in the 

14 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

dehydrocoupling of amines ( **Figure 4e** and **S25** ). Upon light irradiation, Ph(•CH)NH2 is gradually evolved over all catalysts and eventually trapped by DMPO, as evidenced by the characteristic signal peaks belonging to the DMPO-PhCHNH2 adduct ( **Figure S25** and **S26** ).<sup>43</sup> Upon Pd or Ni decoration, an obvious increase in the evolution rate of Ph(•CH)NH2 radical is observed, indicating that both Pd and Ni species significantly promote the deprotonation of amines. It is worth noting that Pd-CdS/SiO2 exhibits the optimal catalytic performance for the dehydrocoupling of BA ( **Figure 2c** ); however, the evolution rate of Ph(•CH)NH2 radical over Pd-CdS/SiO  is obviously lower than that of Ni-CdS/SiO , which further indicates that the 2 2 cleavage of α-C−H bond is a rate-limiting step in Pd-assisted catalytic system. 





15 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

**Figure 5.** Calculated potential energy diagrams for dehydrocoupling of BA to BBAD or DPEA catalysed by the M-CdS/SiO2 composite. Inset in **Figure 5** is the cleavage energy comparison of α-C–H bond under different conditions. 

Upon gathering the above information, we can conclude that the cleavage of α-C−H bond is a rate-limiting step in Pd-assisted catalytic system for BBAD formation process over PdCdS/SiO2, whereas homo-coupling of Ph(•CH)NH2 is the key step in the Ni-assisted catalytic system for DPEA formation process over Ni-CdS/SiO2. To further gain insights into the selectivity regulation and the overall reaction pathways for the dehydrocoupling of BA over PdCdS/SiO2 and Ni-CdS/SiO2, density functional theory (DFT) calculations were performed. According to EXAFS analysis, a single Pd atom and two-atom Ni cluster coordinated with MPA on the surface of cubic CdS QDs were constructed to represent the active sites on Pd-CdS/SiO2 and Ni-CdS/SiO2, respectively ( **Figure S28** and **S29** ). As depicted in **Figure 5** , both BA adsorption steps over Pd-CdS/SiO2 and Ni-CdS/SiO2 composite are exothermic with the values of −0.325 and −0.810 eV, respectively. The first deprotonation step of BA* over Pd-CdS/SiO2 is endergonic by a high energy barrier of 0.724 eV (that for the case without catalyst is 1.320 eV, inset in **Figure 5** ), suggesting that the activation of C–H bond in BA is a rate-limiting step for BA dehydrocoupling occurs on Pd-CdS/SiO2 consistent with the conclusion drawn from the experimental data; nevertheless, such deprotonation process is spontaneous on the surface of NiCdS/SiO  with the C–H bond dissociation energy of −0.44 eV. For the Pd-assisted BBAD 2 formation mechanism, the formed Ph(•CH)NH2 radical can be further protonated to produce a highly active aldimine intermediate ( _i.e.,_ (phenyl)methanimine) by overcoming a moderate energy barrier of 0.413 eV. Subsequently, the aldimine intermediate is prone to undergo an addition-elimination mechanism,<sup>45</sup> _i.e.,_ the addition of another BA molecule to form N-benzyl-1phenylmethanediamine, thereby ensuring elimination of ammonia ( **Figure S27** ) for BBAD production. Considering the weak (phenyl)methanimine desorption energy of 0.275 eV on the Pd-CdS/SiO2 surface, a thermodynamically more feasible reaction pathway is that, the aldimine intermediate is preferentially desorbed from the surface of Pd-CdS/SiO2 to the solution, undertaking a thermodynamically downhill addition-elimination pathway with an exergonic condensation energy of −1.961 eV, followed by a very low elimination energy of 0.139 eV to produce BBAD ( **Figure S30** ). In contrast, as for the Ni-assisted DPEA formation mechanism, it is noteworthy that the second deprotonation process of Ph(•CH)NH2 radical is significantly 

16 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

harder thermodynamically due to the high N–H bond cleavage energy of 2.014 eV. In such a scenario, a homo-coupling pathway for DPEA production is thermodynamically favorable with an exergonic energy of −2.042 eV, which is considered to be the critical step to tune the product selectivity. Hence, the theoretical studies of BA dehydrocoupling reveal that the divergent synthesis of BBAD and DPEA over M-CdS/SiO2 originates from the reasonable C–H/N–H bond cleavage energy on the Pd-CdS/SiO2 surface and a large exergonic C–C coupling energy enabled by Ni-CdS/SiO2. Taking the above experimental and theoretical results together, the overall catalytic reaction mechanism has been proposed accordingly in **Figure 6** . 



**Figure 6.** Proposed mechanism for dehydrocoupling of BA to BBAD or DPEA catalysed by the M-CdS/SiO2 composite. 

## **Conclusions** 

In summary, we report the strategy of designing the structurally well-defined cocatalyst over the semiconductor surface to steer unselective photogenerated radicals for the tunable selective photoredox dehydrocoupling of amines into C–C coupled vicinal diamines or C–N coupled imines concomitantly with H2 byproduct over the atomically dispersed Ni or Pddecorated CdS/SiO composite. Our methodology is compatible with a variety of readily 2 available amines, affording the high-performance production of vicinal diamines and imines with outstanding selectivity, stability and recyclability. Mechanistic studies confirm the Ph(•CH)NH2 

17 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

and PhCH2NH 2<sup>•+</sup> as dominant radical intermediates for the divergent synthesis of C–C coupled vicinal diamines and C–N coupled imines, respectively, as enabled by specific cocatalyst of Nioxo cluster and single Pd atom. This work overcomes the well-known pervasive shortcomings of selectivity regulation in semiconductor-based heterogeneous photochemical synthesis, and is expected to pave the way of decorating atomically dispersed cocatalysts as the active sites onto semiconductor to maneuver radical conversion for divergent synthesis of fine chemicals. 

## **Methods** 

**Synthesis of EDC/NHS covalent assembled CdS/SiO2.** In a typical process, 0.1 g of BPEISiO2 was mixed with 0.1 g of NHS and 1 mL of EDC in 100 mL of phosphate buffer saline (pH = 7.0), which was kept at an ambient temperature with stirring for 15 min. A certain concentration of CdS QDs was then added into the above solution, stirred for another 6 h. Afterwards, the as-synthesized samples were isolated by centrifugation, followed by drying at 60 °C in an oven. The obtained products are labeled as x%CdS/SiO2, in which x% (x = 2.5, 5, 10 and 15) stands for the mass ratio of CdS QDs. 

**Synthesis of M-CdS/SiO2.** M-CdS/SiO2 was prepared based on a facile photodeposition strategy. Typically, 50 mg of CdS/SiO2 was dissolved in a 50 mL of mixed solution of DI water (40 mL) and ethanol (10 mL) that contained a certain amount of PdCI2. Subsequently, the suspension was irradiated with UV-vis light (λ > 300 nm) under nitrogen (N2) atmosphere for 0.5 h. The obtained products were collected _via_ centrifugation and washed by DI water. Followed by blow-drying with N2, the Pd-CdS/SiO2 composites with different Pd weight loading (0.15%, 0.3%, 0.75% and 1.5%) were obtained. The photodeposition of Ni cocatalyst for the synthesis of 

Ni-CdS/SiO composites with different Ni weight loading (0.3%, 0.75%, 1.5% and 2%) takes the 2 same method, except for the difference of precursor (NiCl2∙6H2O for Ni). 

**Photoactivity testing.** Photocatalytic H2 evolution paired with imine or vicinal diamine synthesis was carried out in a double-walled quartz reactor, which was maintained at 25 °C by a flow of circulating water. Typically, 10 mg sample was added into 10 mL CH3CN containing 0.2 

mmol amines. The reaction solution was purged with Ar gas for 20 min. Then, a 300 W xenon lamp (PLS-SXE 300D, Beijing Perfectlight Co., Ltd.) was used as light source, and the light power density is measured to be approximately 120 mW cm<sup>−2</sup> . The generated H2 was quantified by a gas chromatograph (Shimadzu GC-8A 2014C). The liquid products were analyzed by the gas chromatography-mass spectrometry (Shimadzu GC-MS QP 2020, Q-Exactive, see **Figure S16** and **S31-44** for the corresponding Mass spectra). 

ASSOCIATED CONTENT 

## **Supporting Information** . 

The Supporting Information is available free of charge at http://pubs.acs.org. 

18 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

Additional experimental details, characterization (crystal structures, morphologies, and optical absorption properties) and photoactivity results of the obtained sample. Energy band structure of CdS QDs, photoelectrochemical measurements of various samples, additional DFT results. Mass spectra of the obtain liquid-products. 

AUTHOR INFORMATION 

## **Corresponding Author** 

**Yi-Jun Xu** — College of Chemistry, State Key Laboratory of Photocatalysis on Energy and Environment, Fuzhou University, Fuzhou, 350116, China; orcid.org/0000-0002-2195-1695; Email: yjxu@fzu.edu.cn; Homepage: http://xugroup.fzu.edu.cn. 

## **Author Contributions** 

Y.-J.X. proposed the research direction and supervised the project. M.-Y.Q. designed and preformed the experiments. Y.-J.X. and M.-Y.Q. wrote and revised the manuscript. Z.-R.T. and M.C. provided helpful suggestions. All authors participated in discussion and reviewed the paper before submission. 

## **Notes** 

The authors declare no competing financial interest. 

## ACKNOWLEDGMENT 

This work was supported by the Natural Science Foundation of China (22172030, 22072023, 21872029, U1463204 and 21173045), the Program for National Science and Technology Innovation Leading Talents (00387072), the Program for Leading Talents of Fujian Universities, the 1st Program of Fujian Province for Top Creative Young Talents, and the Natural Science Foundation of Fujian Province (2017J07002 and 2019J01631). 

## REFERENCES 

(1) Moran, J.; Preetz, A.; Mesch, R. A.; Krische, M. J. Iridium-catalysed direct C-C coupling of methanol and allenes. _Nat. Chem._ **2011,** _3_ , 287-290. 

(2) Wang, H.; Gao, X.; Lv, Z.; Abdelilah, T.; Lei, A. Recent advances in oxidative R<sup>1</sup> -H/R<sup>2</sup> -H cross-coupling with hydrogen evolution via photo-/electrochemistry. _Chem. Rev._ **2019,** _119_ , 6769-6787. 

19 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

(3) Hazari, N.; Melvin, P. R.; Beromi, M. M. Well-defined nickel and palladium precatalysts for cross-coupling. _Nat. Rev. Chem._ **2017,** _1_ , 0025. 

(4) Hu, A.; Guo, J.-J.; Pan, H.; Tang, H.; Gao, Z.; Zuo, Z. δ‑Selective Functionalization of Alkanols Enabled by Visible-Light-Induced Ligand-to-Metal Charge Transfer. _J. Am. Chem. Soc._ **2018,** _140_ , 1612-1616. 

(5) Marzo, L.; Pagire, S. K.; Reiser, O.; Koenig, B. Visible-light photocatalysis: does It make a difference in organic synthesis? _Angew. Chem. Int. Ed._ **2018,** _57_ , 10034-10072. 

(6) Musacchio, A. J.; Nguyen, L. Q.; Beard, G. H.; Knowles, R. R. Catalytic Olefin Hydroamination with Aminium Radical Cations: A Photoredox Method for Direct C-N Bond Formation. _J. Am. Chem. Soc._ **2014,** _136_ , 12217-12220. 

(7) Trowbridge, A.; Reich, D.; Gaunt, M. J. Multicomponent synthesis of tertiary alkylamines by photocatalytic olefin-hydroaminoalkylation. _Nature_ **2018,** _561_ , 522-527. 

(8) Schultz, D. M.; Yoon, T. P. Solar synthesis: prospects in visible light photocatalysis. _Science_ **2014,** _343_ , 1239176. 

(9) Cui, X.; Li, W.; Ryabchuk, P.; Junge, K.; Beller, M. Bridging homogeneous and heterogeneous catalysis by heterogeneous single-metal-site catalysts. _Nat. Catal_ **2018,** _1_ , 385397. 

(10) Jiang, Y.; Lopez-Arteaga, R.; Weiss, E. A. Quantum Dots Photocatalyze Intermolecular 2+2 Cycloadditions of Aromatic Alkenes Adsorbed to their Surfaces via van der Waals Interactions. _J. Am. Chem. Soc._ **2022,** _144_ , 3782-3786. 

(11) Caputo, J. A.; Frenette, L. C.; Zhao, N.; Sowers, K. L.; Krauss, T. D.; Weix, D. J. General and efficient C-C bond forming photoredox catalysis with semiconductor quantum dots. _J. Am. Chem. Soc._ **2017,** _139_ , 4250-4253. 

(12) Qi, M.-Y.; Conte, M.; Anpo, M.; Tang, Z.-R.; Xu, Y.-J. Cooperative coupling of oxidative organic synthesis and hydrogen production over semiconductor-based photocatalysts. _Chem. Rev._ **2021,** _121_ , 13051-13085. 

(13) Kou, J.; Lu, C.; Wang, J.; Chen, Y.; Xu, Z.; Varma, R. S. Selectivity Enhancement in Heterogeneous Photocatalytic Transformations. _Chem. Rev._ **2017,** _117_ , 1445-1514. 

(14) Gao, C.; Low, J.; Long, R.; Kong, T.; Zhu, J.; Xiong, Y. Heterogeneous Single-Atom Photocatalysts: Fundamentals and Applications. _Chem. Rev._ **2020,** _120_ , 12175-12216. 

20 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

(15) Ji, S.; Chen, Y.; Zhao, S.; Chen, W.; Shi, L.; Wang, Y.; Dong, J.; Li, Z.; Li, F.; Chen, C.; Peng, Q.; Li, J.; Wang, D.; Li, Y. Atomically Dispersed Ruthenium Species Inside MetalOrganic Frameworks: Combining the High Activity of Atomic Sites and the Molecular Sieving Effect of MOFs. _Angew. Chem. Int. Ed._ **2019,** _58_ , 4271-4275. 

(16) Liu, Z.; Huang, F.; Peng, M.; Chen, Y.; Cai, X.; Wang, L.; Hu, Z.; Wen, X.; Wang, N.; Xiao, D.; Jiang, H.; Sun, H.; Liu, H.; Ma, D. Tuning the selectivity of catalytic nitriles hydrogenation by structure regulation in atomically dispersed Pd catalysts. _Nat. Commun,_ **2021,** _12_ , 6194. 

(17) Wang, L.; Zhang, W.; Wang, S.; Gao, Z.; Luo, Z.; Wang, X.; Zeng, R.; Li, A.; Li, H.; Wang, M.; Zheng, X.; Zhu, J.; Zhang, W.; Ma, C.; Si, R.; Zeng, J. Atomic-level insights in optimizing reaction paths for hydroformylation reaction over Rh/CoO single-atom catalyst. _Nat. Commun,_ **2016,** _7_ , 14036. 

(18) Jagadeesh, R. V.; Murugesan, K.; Alshammari, A. S.; Neumann, H.; Pohl, M.-M.; Radnik, J.; Beller, M. MOF-derived cobalt nanoparticles catalyze a general synthesis of amines. _Science_ **2017,** _358_ , 326-332. 

(19) Froidevaux, V.; Negrell, C.; Caillol, S.; Pascault, J.-P.; Boutevin, B. Biobased Amines: From Synthesis to Polymers; Present and Future. _Chem. Rev._ **2016,** _116_ , 14181-14224. 

(20) Murugesan, K.; Senthamarai, T.; Chandrashekhar, V. G.; Natte, K.; Kamer, P. C. J.; Beller, M.; Jagadeesh, R. V. Catalytic reductive aminations using molecular hydrogen for synthesis of different kinds of amines. _Chem. Soc. Rev._ **2020,** _49_ , 6273-6328. 

(21) Zhang, N.; Han, C.; Xu, Y.-J.; Foley, J. J.; Zhang, D.; Codrington, J.; Gray, S. K.; Sun, Y. Near-field dielectric scattering promotes optical absorption by platinum nanoparticles. _Nat. Photonics_ **2016,** _10_ , 473-482. 

(22) Han, C.; Li, S.-H.; Tang, Z.-R.; Xu, Y.-J. Tunable plasmonic core-shell heterostructure design for broadband light driven catalysis. _Chem. Sci._ **2018,** _9_ , 8914-8922. 

(23) Qi, M.-Y.; Li, Y.-H.; Anpo, M.; Tang, Z.-R.; Xu, Y.-J. Efficient photoredox-mediated C-C coupling organic synthesis and hydrogen production over engineered semiconductor quantum dots. _ACS Catal._ **2020,** _10_ , 14327-14335. 

(24) Fereiro, J. A.; Porat, G.; Bendikov, T.; Pecht, I.; Sheves, M.; Cahen, D. Protein electronics: chemical modulation of contacts control energy level alignment in gold-azurin-gold junctions. _J. Am. Chem. Soc._ **2018,** _140_ , 13317-13326. 

21 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

(25) Gannett, P. M.; Kabulski, J.; Perez, F. A.; Liu, Z. Y.; Lederman, D.; Locuson, C. W.; Ayscue, R. R.; Thomsen, N. M.; Tracy, T. S. Preparation, characterization, and substrate metabolism of gold-immobilized cytochrome P4502C9. _J. Am. Chem. Soc._ **2006,** _128_ , 83748375. 

(26) D'Ambrosio, E. A.; Bersch, K. L.; Lauro, M. L.; Grimes, C. L. Differential peptidoglycan recognition assay using varied surface presentations. _J. Am. Chem. Soc._ **2020,** _142_ , 10926-10930. (27) Cui, X. F.; Wang, J.; Liu, B.; Ling, S.; Long, R.; Xiong, Y. J. Turning Au nanoclusters catalytically active for visible-light-driven CO reduction through bridging ligands. 2 _J. Am. Chem. Soc._ **2018,** _140_ , 16514-16520. 

(28) Cecchet, F.; Pilling, M.; Hevesi, L.; Schergna, S.; Wong, J. K. Y.; Clarkson, G. J.; Leigh, D. A.; Rudolf, P. Grafting of benzylic amide macrocycles onto acid-terminated self-assembled monolayers studied by XPS, RAIRS, and contact angle measurements. _J. Phys. Chem. B_ **2003,** _107_ , 10863-10872. 

(29) Pippig, F.; Sarghini, S.; Hollaender, A.; Paulussen, S.; Terryn, H. TFAA chemical derivatization and XPS. Analysis of OH and NHx polymers. _Surf. Interface Anal._ **2009,** _41_ , 421429. 

(30) Whelan, C. M.; Cecchet, F.; Baxter, R.; Zerbetto, F.; Clarkson, G. J.; Leigh, D. A.; Rudolf, P. Adsorption of a benzylic amide macrocycle on a solid substrate: XPS and HREELS characterization of thin films grown on Au(111). _J. Phys. Chem. B_ **2002,** _106_ , 8739-8746. 

(31) Wei, S. J.; Li, A.; Liu, J. C.; Li, Z.; Chen, W. X.; Gong, Y.; Zhang, Q. H.; Cheong, W. C.; Wang, Y.; Zheng, L. R.; Xiao, H.; Chen, C.; Wang, D. S.; Peng, Q.; Gu, L.; Han, X. D.; Li, J.; Li, Y. D. Direct observation of noble metal nanoparticles transforming to thermally stable single atoms. _Nat. Nanotechnol._ **2018,** _13_ , 856-861. 

(32) Liu, P.; Zhao, Y.; Qin, R.; Mo, S.; Chen, G.; Gu, L.; Chevrier, D. M.; Zhang, P.; Guo, Q.; Zang, D.; Wu, B.; Fu, G.; Zheng, N. Photochemical route for synthesizing atomically dispersed palladium catalysts. _Science_ **2016,** _352_ , 797-801. 

(33) Chen, Z.; Vorobyeva, E.; Mitchell, S.; Fako, E.; Ortuno, M. A.; Lopez, N.; Collins, S. M.; Midgley, P. A.; Richard, S.; Vile, G.; Perez-Ramirez, J. A heterogeneous single-atom palladium catalyst surpassing homogeneous systems for Suzuki coupling. _Nat. Nanotechnol._ **2018,** _13_ , 702707 

22 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

(34) Gao, C.; Chen, S.; Wang, Y.; Wang, J.; Zheng, X.; Zhu, J.; Song, L.; Zhang, W.; Xiong, Y. Heterogeneous single-atom catalyst for visible-light-driven high-turnover CO2 reduction: the role of electron transfer. _Adv. Mater._ **2018,** _30_ , 1704624. 

(35) Xia, C.; Qiu, Y.; Xia, Y.; Zhu, P.; King, G.; Zhang, X.; Wu, Z.; Kim, J. Y.; Cullen, D. A.; Zheng, D.; Li, P.; Shakouri, M.; Heredia, E.; Cui, P.; Alshareef, H. N.; Hu, Y.; Wang, H. General synthesis of single-atom catalysts with high metal loading using graphene quantum dots. _Nat. Chem._ **2021,** _13_ , 887-894. 

(36) Si, X.; Chen, J.; Lu, F.; Liu, X.; Ren, Y.; Lu, R.; Jiang, H.; Liu, H.; Miao, S.; Zhu, Y.; Luo, X.; Xu, J. Immobilized Ni clusters in mesoporous aluminum silica nanospheres for catalytic hydrogenolysis of lignin. _ACS Sustainable Chem. Eng_ **2019,** _7_ , 19034-19041. 

(37) Rigoli, J. W.; Weatherly, C. D.; Alderson, J. M.; Vo, B. T.; Schomaker, J. M. Tunable, chemoselective amination via silver catalysis. _J. Am. Chem. Soc._ **2013,** _135_ , 17238-17241. 

(38) Mukherjee, A.; Nerush, A.; Leitus, G.; Shimon, L. J. W.; Ben David, Y.; Jalapa, N. A. E.; Milstein, D. Manganese-catalyzed environmentally benign dehydrogenative coupling of alcohols and amines to form aldimines and H2: a catalytic and mechanistic study. _J. Am. Chem. Soc._ **2016,** _138_ , 4298-4301. 

(39) Wang, M.; Li, L.; Lu, J.; Luo, N.; Zhang, X.; Wang, F. Photocatalytic coupling of amines to imidazoles using a Mo-ZnIn2S4 catalyst. _Green Chem._ **2017,** _19_ , 5172-5177. 

(40) Lang, X.; Ma, W.; Zhao, Y.; Chen, C.; Ji, H.; Zhao, J. Visible-light-induced selective photocatalytic aerobic oxidation of amines into imines on TiO2. _Chem.-Eur. J._ **2012,** _18_ , 26242631. 

(41) Zhang, N.; Li, X.; Ye, H.; Chen, S.; Ju, H.; Liu, D.; Lin, Y.; Ye, W.; Wang, C.; Xu, Q.; Zhu, J.; Song, L.; Jiang, J.; Xiong, Y. Oxide defect engineering enables to couple solar energy into oxygen activation. _J. Am. Chem. Soc._ **2016,** _138_ , 8928-8935. 

(42) Su, F.; Mathew, S. C.; Moehlmann, L.; Antonietti, M.; Wang, X.; Blechert, S. Aerobic oxidative coupling of amines by carbon nitride photocatalysis with visible light. _Angew. Chem. Int. Ed._ **2011,** _50_ , 657-660. 

(43) Huang, Y.; Liu, C.; Li, M.; Li, H.; Li, Y.; Su, R.; Zhang, B. Photoimmobilized Ni clusters boost photodehydrogenative coupling of amines to imines via enhanced hydrogen evolution kinetics. _ACS Catal._ **2020,** _10_ , 3904-3910. 

23 

ACS Nano 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 

(44) Lang, X.; Ji, H.; Chen, C.; Ma, W.; Zhao, J. Selective formation of imines by aerobic photocatalytic oxidation of amines on TiO2. _Angew. Chem. Int. Ed._ **2011,** _50_ , 3934-3937. 

(45) Xiao, Y.; Tian, G.; Li, W.; Xie, Y.; Jiang, B.; Tian, C.; Zhao, D.; Fu, H. Molecule selfassembly synthesis of porous few-layer carbon nitride for highly efficient photoredox catalysis. _J. Am. Chem. Soc._ **2019,** _141_ , 2508-2515. 

24 

