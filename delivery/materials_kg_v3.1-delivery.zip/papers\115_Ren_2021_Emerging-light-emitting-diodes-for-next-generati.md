# Emerging light-emitting diodes for next-generation data communications

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Electronics |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 213 |
| 作者 | A. Ren, Hao Wang, Wei Zhang, Jiang Wu, Zhi-Ming M. Wang, R. Penty, I. White |
| DOI | 10.1038/s41928-021-00624-7 |
| 源文件 | 015_Ren_2021_Emerging-light-emitting-diodes-for-next-generati.pdf |

---
**Please do not remove this page** 



## **Emerging light-emitting diodes for next-generation data communications** 

REN, AOBO ; Wang, Hao; ZHANG, WEI; Wu, Jiang; Wang, Zhiming; Penty, Richard V.; White, Ian H. https://openresearch.surrey.ac.uk/esploro/outputs/journalArticle/Emerging-light-emitting-diodes-for-next-generation-data/99608323702346/filesAndL inks?index=0 

REN, A., Wang, H., ZHANG, W., Wu, J., Wang, Z., Penty, R. V., & White, I. H. (2021). Emerging light-emitting diodes for next-generation data communications. Nature Electronics, 4, 559–572. https://doi.org/10.1038/s41928-021-00624-7 Document Version: Author's Accepted Manuscript 

Published Version: https://doi.org/10.1038/s41928-021-00624-7 

Surrey Open Research repository homepage: https://openresearch.surrey.ac.uk/esploro/ openresearch@surrey.ac.uk Free to read © Springer Nature Limited 2021 Downloaded On 2026/11/23 05:17:27 +0000 

REVIEW ARTICLE 



**https://doi.org/10.1038/s41928-021-00624-7** 



# **Emerging light-emitting diodes for next-generation data communications** 

**Aobo Ren� �**<sup>**1,2,6**</sup> **, Hao Wang� �**<sup>**3,6**</sup> **, Wei Zhang� �**<sup>**2**✉</sup> **, Jiang Wu� �**<sup>**1,4**✉</sup> **, Zhiming Wang**<sup>**1**</sup> **, Richard V. Penty**<sup>**3**</sup> **and Ian H. White**<sup>**3,5**</sup> 

**The continuing development of consumer electronics, mobile communications and advanced computing technologies has led to a rapid growth in data traffic, creating challenges for the communications industry. Light-emitting diode (LED)-based communication links are of potential use in both free space and optical interconnect applications, and LEDs based on emerging semiconductor materials, which can offer tunable optoelectronics properties and solution-processable manufacturing, are of particular interest in the development of next-generation data communications. Here we review the development of emerging LED materials—organic semiconductors, colloidal quantum dots and metal halide perovskites—for use in optical communications. We examine efforts to improve the modulation performance and device efficiency of these LEDs, and consider potential applications in on-chip interconnects and light fidelity (Li-Fi). We also explore the challenges that exist in developing practical high-speed LED-based data communication systems.** 

emiconductor lasers have typically been used to tackle speed and capacity bottlenecks in data communications<sup>1</sup> . However, Sdue to the relatively high manufacturing costs and the relatively complex driver circuits of lasers<sup>2</sup> , as well as eye safety issues, alternative solutions have been sought for future applications in human-centric systems, short-distance communications and indoor wireless data services. Light-emitting diodes (LEDs) are a cost-effective and low-power alternative<sup>2–4</sup> . LED-based links are, in particular, expected to be extensively used in Internet of Things (IoT) and 6G technologies, and in moderate/high-speed photonic interconnects, visible light communications (VLC), underwater communications and accurate indoor positioning applications<sup>2–5</sup> . 

The potential use of LEDs in next-generation data communications is driven by the rapid development of energy-efficient LEDs that can function as illumination and signalling devices. The concepts and fundamental principles of LED links are illustrated in Box 1. Micro-LEDs (µLEDs) based on crystalline inorganic III–V semiconductors have been widely examined for communications<sup>2</sup> . Because of advances in epitaxy, lithography and flip-chip techniques<sup>6</sup> , III–V µLEDs have delivered a modulation bandwidth from several hundred megahertz to over one gigahertz<sup>2,7</sup> . A non-polar m-plane InGaN/GaN µLED with a high modulation bandwidth of 1.5 GHz was demonstrated in 2018<sup>7</sup> , and a 1.3 GHz electrical-to-optical bandwidth quantum dot (QD) µLED was recently reported with a data rate of 4 Gbps (ref.<sup>8</sup> ). Nevertheless, conventional approaches are challenged by the high requirements for low size, weight, power and cost of next-generation data communication systems<sup>5,9,10</sup> . 

Organic semiconductors, colloidal quantum dots (CQDs) and metal halide perovskites offer tailorable optoelectronic properties, mechanical flexibility and low-cost processing<sup>10</sup> . These characteristics make them attractive candidates for use in low-cost and low-power LED links in next-generation integrated and scalable data communication modules. Thus, while conventional inorganic thin-film technologies are likely to continue to play a dominant 

role in optical communications<sup>9,11</sup> , we believe that LEDs based on these emerging materials can provide a complementary role. In this Review, we examine the development of emerging semiconductor materials for LEDs and colour converters. We first consider the fundamentals of LED-based optical communication systems, and then explore efforts to boost the frequency response and enhance the external quantum efficiency (EQE) of LEDs based on emerging materials. Finally, we consider the challenges that exist in developing these LEDs for practical communication systems. 

##### **Emerging materials for fast LEDs** 

In general, organic semiconductors, CQDs or halide perovskites (Fig. 1a–c) serve as an emissive layer that is sandwiched between an electron transport layer (ETL) and a hole transport layer (HTL) to form a complete LED. As shown in Fig. 1d, electrons and holes are injected into the emissive layer under a forward bias through the ETL and HTL, respectively, accompanied by radiative recombination and photon emission. On the basis of the energy band of various light-emitting materials (Fig. 1e), one should rationally choose electrodes and charge transport layers (CTLs) with suitable energy level alignments to construct an efficient LED. 

The electroluminescent materials used in organic LEDs (OLEDs) can be classified into two types: small molecules and polymers. The electroluminescence performances of these two types of organic material are comparable, while small-molecule and polymer OLEDs rely on different fabrication methods (vacuum evaporation and wet chemistry, respectively). The first practical application of vapour-deposited OLEDs was reported in 1987<sup>12</sup> . Subsequently, a breakthrough in OLEDs was the demonstration of electroluminescence from conjugated polymers in 1990<sup>13</sup> . Since then, after nearly three decades of intense research and development, OLEDs have entered the stage of commercialization for top-end displays<sup>14</sup> . 

Inspired by the findings in semiconductor nanocrystals and electroluminescent polymers, the first CQD-based LED (hereafter 

> 1Institute of Fundamental and Frontier Sciences, University of Electronic Science and Technology of China, Chengdu, China. 2Advanced Technology Institute, University of Surrey, Guildford, UK.<sup>3</sup> Centre for Photonic Systems, Department of Engineering, University of Cambridge, Cambridge, UK.<sup>4</sup> State Key Laboratory of Electronic Thin Films and Integrated Devices, University of Electronic Science and Technology of China, Chengdu, China.<sup>5</sup> Vice-Chancellor’s Office, University of Bath, Bath, UK.<sup>6</sup> These authors contributed equally: Aobo Ren, Hao Wang.<sup>✉</sup> e-mail: wz0003@surrey.ac.uk; jiangwu@uestc.edu.cn 

**NATURE ELECTRONICS** | VOL 4 | AUGUST 2021 | 559–572 | www.nature.com/natureelectronics 

**559** 

<mark>REVIEW ARTICLE</mark> 

**NATURE ELECTRONICS** 

###### **Box 1 | Fundamentals of LED links** 

A typical LED-based communication system is enabled by modulating light from an LED with a fast on–off switching capability, using it as a data source. In the communication process, a transmitter consisting of a driven circuit receives information from the signal generator to control an LED. Te electrically modulated data are then transformed into a modulated optical signal by the LED transmitter. Tis modulated light propagates over a waveguide link or free-space channel. Guided-wave LED links enable high-speed yet low-cost optical interconnection over plastic optical fibres or polymer waveguides for short-range communication in board-level interconnects, the IoT and indoor networks, 

while free-space LED links find application in optical wireless communications, such as light fidelity (Li-Fi) and underwater communications. Afer its propagation through the channel, the light signal is subsequently converted back into an electrical signal and analysed by a receiver. Te receiver normally consists of an optics system, an opto-electrical converter including a photodetector, amplifiers and a signal processing circuit. In general, intensity modulation is the most practical and cost-effective approach to modulate LEDs, while optical coherent modulation and demodulation incur high costs, making them impractical for most targeted LED-based communication applications. 



<!-- Start of picture text -->
Waveguide<br>Driver Signal processing<br>Signal High-speed LED Free space Photodetector Signal<br><!-- End of picture text -->

referred to as a QLED) was presented in 1994<sup>15</sup> , which attracted tremendous attention afterwards. Advances in QLEDs have been achieved for high-colour-quality lighting and display technologies<sup>16,17</sup> . CQDs are semiconductor nanoparticles with sizes of a few nanometres and are normally covered with a shell layer and surface ligands. Due to the three-dimensional (3D) quantum confinement effect, the electronic states are discrete instead of continuous; thus, the bandgap of CQDs related to the Bohr exciton radius can be easily tuned by varying their composition and size. The typical electroluminescence of CQDs exhibits a narrow emission band with a typical full-width at half-maximum (FWHM) of ~30 nm, which is determined by precise monodispersity control of CQDs. The colour purity and spectral tunability of CQDs from the visible (for example, CdSe-based CQDs) to the near-infrared (for example, PbS-based CQDs) regions broadly extend the emission spectra of OLEDs<sup>18</sup> . 

Metal halide perovskites have a general ABX3 crystal structure, where the A site is an organic or inorganic cation (for example, methylammonium (MA<sup>+</sup> ), formamidinium (FA<sup>+</sup> ) and Cs<sup>+</sup> ), the B site is a divalent metal cation (for example, Pb<sup>2+</sup> , Sn<sup>2+</sup> and Ge<sup>2+</sup> ) and the X site is a halogen anion (for example, Cl<sup>−</sup> , Br<sup>−</sup> and I<sup>−</sup> ). Notably, metal halide perovskites possess a number of striking properties, such as high absorption coefficients (5.7 × 10<sup>4</sup> cm<sup>−1</sup> for MAPbI3), long carrier diffusion lengths (exceeding 1 μm), high charge carrier mobilities (on the order of 10 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ) and high defect tolerance<sup>19</sup> . Since perovskite materials were introduced into solar cells in 2009<sup>20</sup> , research on perovskite photovoltaics has increased, pushing the power conversion efficiencies from 3.8% to greater than 25% in only one decade<sup>21</sup> . This impressive progress also paves the way for the development of perovskite LEDs (PeLEDs). Within half a decade after the first demonstration of a room-temperature PeLED in 2014, efficient PeLEDs with an EQE of over 20% were simultaneously reported by four groups<sup>22–25</sup> . The rapid growth in PeLEDs has made them on par with the best-performing OLEDs and QLEDs. Compared with organic (FWHM >40 nm) and CQD (FWHM ~30 nm) emitters, perovskite light emitters with high efficiency 

and colour purity (FWHM <20 nm) have been developed as strong competitors to these counterparts<sup>26</sup> . 

Tremendous research progress in emerging light-emitting technology based on the aforementioned materials has been witnessed in recent years. These materials can attract such broad scientific and industrial interest for several reasons. Specifically, their widely tunable optoelectronic properties, including their bandgap, electronic energy level and carrier drift velocity, can be customized through synthetical and compositional engineering. This not only allows a tunable photoemission of the chosen material from the visible to near-infrared regions but also benefits the optimization of the band structure and carrier transport. Another distinct advantage is that these materials can be solution-processed and deposited via readily available manufacturing techniques under ambient conditions, such as spin-coating, spray-coating, blade-coating and inkjet printing<sup>10</sup> (Fig. 1f–i). These methods offer great merits for manufacturing complementary metal–oxide semiconductor-compatible photonic components without relying on comprehensive epitaxial growth and are even practical for low-cost, high-throughput and industrial-scale fabrication. Overall, these emerging materials are revolutionizing the light-emitting technologies, and much room for improvement of the device performance remains. In the meantime, their further application as LED links for optical communications is promising and gradually attracting intensive research interest. 

##### **Boosting the frequency response** 

LEDs with these emerging materials for communication purposes need to be optimized in terms of the modulation bandwidth. The response speed of LEDs is limited by the time delay from the receiving of an electrical signal to the generation of photons induced by carrier recombination (Box 2). Following the development and success of OLEDs for display applications, part of the research focus has switched to the field of adopting OLEDs as transmitters for optical communications in the past decade<sup>27–34</sup> . During the development of OLEDs, various fluorescent and phosphorescent emitters have been found to provide highly efficient devices. Nonetheless, many 

**<mark>NATURE ELECTRONICS</mark>** <mark>| VOL 4 | AUGUST 2021 | 559–572 | www.nature.com/natureelectronics</mark> 

**<mark>560</mark>** 

<mark>REVIEW ARTICLE</mark> 

**NATURE ELECTRONICS** 



<!-- Start of picture text -->
a b c<br>TBPe BDAVBi Shell<br>N<br>N Core<br>A (CH3NH3+, NH2CHNH2+, Cs+)<br>N O N N S N n Ligand B (Pb 2+ , Sn 2+ , Ge 2+ )<br>X (Cl – , Br – , I – )<br>DMAC-BP F8BT<br>d e<br>Metallic cathode 1.84<br>ETL 2.60<br>3.10 3.30 3.20<br>Emitting layerHTL – – 4.40 4.38 4.30 3.90 3.98 4.17 4.12<br>+<br>+<br>5.45 5.30 5.80 5.90 5.24 5.50 5.20 5.40 5.34<br>Transparent anode 6.60 6.94 6.53<br>Substrate<br>f g h i<br>Spin-coating Spray-coating Blade-coating<br>Inkjet printing<br>Energy (eV) TBPe BDAVBi DMAC-BP F8BT SAg2 InP PbS MAPbI3 FASnl3<br>CdSe FAPbCl3 CsPbBr3<br><!-- End of picture text -->

**Fig. 1 | LEDs based on emerging materials. a** , Chemical structures of 2,5,8,11-tetra- _tert_ -butylperylene (TBPe), 4,4′-bis[4-(diphenylamino)styryl]biphenyl (BDAVBi), bis[4-(9,9-dimethyl-9,10-dihydroacridine)phenyl]methanone (DMAC-BP) and poly(9,9-dioctylfluorene-alt-benzothiadiazole) (F8BT). **b** , Schematic of a typical core–shell CQD. **c** , Three-dimensional crystal structure of a perovskite with the general formula ABX3. **d** , General configuration and operation of an LED. When a voltage is applied between the cathode and the anode of an LED, electrons and holes are injected into the emitting layer through an ETL and a HTL, respectively, and then, the carriers recombine, resulting in emission of photons. **e** , Energy band structure of typical organics (left group), CQDs (middle group) and perovskites (right group) that have been used in LEDs. The highest occupied molecular orbital (HOMO) or valance band maximum (VBM) of each material is shown at the bottom of the coloured bars. The lowest unoccupied molecular orbital (LUMO) or conduction band minimum (CBM) of each material is shown at the top of the coloured bars. **f** – **i** , Solution-processed materials, including organic semiconductors, CQDs and metal halide perovskites, can be fabricated via readily available manufacturing techniques (spin-coating ( **f** ), spray-coating ( **g** ), inkjet printing ( **h** ) and blade-coating ( **i** )) under ambient conditions. Panel **d** adapted with permission from ref.<sup>35</sup> , Springer Nature Ltd. 

of them are not suitable for fast-response devices due to their long exciton decay lifetimes (several hundred nanoseconds to microseconds)<sup>35–37</sup> . In response, organic emitters with shorter luminescence lifetimes (several to tens of nanoseconds) have been selected over many other more efficient emitters for fast OLEDs<sup>22,30,34,38</sup> . As in inorganic devices, the luminescence lifetimes of organic emitters can be reduced via doping; for example, the lifetimes of non-doped tris(8-hydroxyquinolinato)aluminium (Alq3) and rubrene-doped Alq3 are 16 ns and 10 ns, respectively<sup>39</sup> . Some efforts have been dedicated to doping emitters at a certain level to improve the device performance while obtaining short luminescence lifetimes<sup>29,34,38</sup> . Through the adoption of such emitters with short luminescence lifetimes, the potential communication ability of these OLEDs has been improved. However, only a few papers have reported bandwidths exceeding 10 MHz. 

Currently, the active areas of most reported fast LED devices are approximately a few square millimetres, which are much larger than the areas of III–V µLEDs (normally less than 100 × 100 µm<sup>2</sup> ). Therefore, the corresponding large resistor–capacitor (RC) time constants become the main obstacle to a fast response. Due to the low mobility in organic semiconductors, the total thickness of an OLED is several tens to hundreds of nanometres, forming a high capacitance and thus limiting the bandwidth. The impact of a large RC time constant can be effectively reduced by shrinking the active area to decrease the parasitic capacitance while maintaining a high injection level to mitigate the resistance effect<sup>38,40</sup> . For example, an OLED based on a well-studied blend of polymers was investigated for communications and demonstrated a −3 dB bandwidth of 

26 MHz (ref.<sup>30</sup> ). Such a high bandwidth is mainly attributed to its reduced active area (0.018 mm<sup>2</sup> ) and the use of a conjugated polymer blend with relatively high charge carrier mobility. Apart from the consequential large RC effect, the charge transit time might also affect these OLED devices due to the same issue of low charge mobility. The modulation bandwidth can be improved by introducing inorganic CTLs, the mobilities of which are several orders of magnitude higher than those of organic semiconductors (for example, by utilizing ZnS as an ETL)<sup>29</sup> . In addition, the energy band mismatch at the interfaces between the CTLs and other functional layers needs to be minimized; otherwise, the capacitance effect might be intensified because more charge carriers accumulate at the interfaces<sup>41</sup> . 

A breakthrough in developing high-speed OLEDs with bandwidths in the range of hundreds of megahertz was achieved in 2020<sup>38</sup> . This study provided a comprehensive and systematic investigation on boosting the bandwidth of OLEDs from the material to the device engineering level (Fig. 2a). In these OLEDs, a small active area was employed (0.092 mm<sup>2</sup> ) to obtain a low device capacitance. The contacts were carefully designed to minimize the series resistance. The additional electron blocking layer (EBL) and hole blocking layer (HBL) enabled the device to operate at high current densities. The oxidized silicon substrate with high thermal conductivity was chosen over the traditional indium-tin-oxide-coated glass to realize better heat management, thus reducing the effect of a temperature rise<sup>38</sup> . In this scenario, the device resistance and charge transit time could be effectively reduced under high electric fields. As the RC time constant is enormously decreased 

**NATURE ELECTRONICS** | VOL 4 | AUGUST 2021 | 559–572 | www.nature.com/natureelectronics 

**561** 

<mark>REVIEW ARTICLE</mark> 

**NATURE ELECTRONICS** 

###### **Box 2 | Theoretical bandwidth limitations of LEDs for data communications** 

In an LED communication link, afer receiving an electrical signal, the generation of the corresponding optical signal results from charge injection, transport and recombination. A typical equivalent circuit of an LED can be simplified as a single diode resistor (Rd) and capacitor (C) network with a series resistor (Rs). Te diode resistance varies nonlinearly with the applied electrical field, while the series resistance is the equivalent resistance of the overall resistance associated with the contacts, wiring and drive circuit, which is expected to be a constant value. Te diode capacitance originates from the dielectric behaviour of the device and charge accumulation at the interfaces between different functional layers. As a result, there is a time delay corresponding to the RC effect, charge transit and recombination processes before a new equilibrium is established in the device. 

Te relationship between dynamic injected current _I_ ( _t_ ) and applied voltage _V_ ( _t_ ) can be derived from this simplified equivalent electrical model as follows<sup>40</sup> 



<!-- Start of picture text -->
��(�) + + � = � + � (�) ���<br>�� � ��� �� � � �(�) �� � ����(�) ��� �<br><!-- End of picture text -->

Te RC time constant _τ_ RC can be derived from equation (1) 



<!-- Start of picture text -->
�<br>� �� = � ���<br>�� + � � �<br><!-- End of picture text -->

Based on previous research on high-speed III–V LEDs, the frequency response of an LED is given by<sup>137</sup> 



<!-- Start of picture text -->
�<br>�−��� = ���<br>�� �<br><!-- End of picture text -->



<!-- Start of picture text -->
e – h ν HTL C<br>Cathode – Rs I ( t ) +<br>Trapping<br>Rd<br>V ( t  )<br>ETL Anode<br>h +<br>Emitting<br>layer<br><!-- End of picture text -->

where _τ_ can be the value of either carrier lifetime _τ_ c or _τ_ RC, depending on which one is the dominant factor limiting the modulation performance. Here the −3 dB modulation bandwidth _f_ −3dB of an LED is defined as the modulation frequency at which electrical power available from a detector is reduced by half. The corresponding −3 dB optical bandwidth is the frequency at which optical power is half of the unmodulated value and is given by ~~√~~ �(�� _�_ )<sup>−�</sup> . However, fast LEDs based on emerging materials, especially with organic functional layers, have much lower carrier mobilities (for example, ~10<sup>−6</sup> –10<sup>−2</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ) than those of III–V semiconductors (for example, ~10<sup>2</sup> –10<sup>3</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ). Therefore, other than those fast µLEDs with fairly small RC time constants (neglected in the most of cases)<sup>7,8,138</sup> , such an effect becomes significant in LEDs focused on in this Review. In addition, the charge transit time _τ_ tr, which is the time over which the injected carriers drift from the terminals to the recombination region, may not be neglected in the optimization of high-speed LEDs with these materials<sup>38</sup> . 

through these approaches, the impact of the luminescence lifetime on the device bandwidth would gradually dominate. A type of fast-emission material (3 wt% 4,4′-bis[4-(diphenylamino)styryl] biphenyl (BDAVBi) doped into 2-methyl-9,10-bis(naphthalen-2-yl) anthracene (MADN)) with a 1.1 ns lifetime was thereby selected for the emitting layer. By simultaneously optimizing all the aspects, an exceptionally fast OLED with a −6 dB bandwidth of 245 MHz (Fig. 2b) and free-space data rates beyond 1 Gbps over a distance of 2 m was demonstrated. 

Interest in the possible use of CQD and perovskite-based LEDs for communications has only recently emerged. These LEDs were initially used for high-speed transmission in the photoluminescence mode, where these materials are optically excited to provide balanced white emissions<sup>42–44</sup> . In the past two years, several studies have investigated the modulation performance of electroluminescent CdSe/ZnS QLEDs<sup>45–47</sup> , and a 3 m free-space VLC link with a data rate of 4 Mbps using such a QLED was recently reported<sup>46</sup> . Similar to the previous studies on OLEDs, the bandwidth of these QLEDs could be improved via the reduction of the device area and optimization of the CTLs<sup>46,47</sup> . The large surface-to-volume ratio of CQDs can normally promote the formation of trap states or vacancies<sup>18</sup> , this might also lead to an increase in the device capacitance. Measures including surface passivation to minimize the charge accumulation in traps<sup>48</sup> and surface ligand modification<sup>49</sup> to enhance the carrier injection might also boost the modulation performance of QLEDs. 

For electroluminescent PeLEDs, a two-dimensional (2D) Ruddlesden–Popper perovskite nanoplate-based LED was first 

made for communications in 2019<sup>50</sup> . Its −3 dB bandwidth is 0.02 MHz, which is relatively small compared with the bandwidths of other reported devices. Such small bandwidth should be attributed to the large RC time constant caused by its large active area (approximately 9 mm<sup>2</sup> ) and defects in the nanoplates. In addition to the issue of defects in perovskites, device stability is another major challenge for realizing real-world communications using PeLEDs as high-level injections are required to deliver high bandwidths. Most recently, a bidirectional data transmission link via two dual-functional perovskite diodes was developed<sup>51</sup> . High electroluminescence performance (peak EQE of 21.2%) and device stability were achieved via employing rational passivation of trap states on the perovskite crystal surface<sup>52</sup> (Fig. 2c,d). By applying different bias directions, the device could work in both emission and detection modes, and bidirectional data transmission between two identical diodes was realized (Fig. 2e). Combined with size reduction, the parasitic capacitance was greatly decreased, correspondingly yielding a small RC time constant under relatively high injections. As indicated in Fig. 2f, the maximum −3 dB bandwidth reached 21.5 MHz when the device size was decreased to 0.1 mm<sup>2</sup> . Figure 2g shows the development of three types of emerging high-speed LEDs with various emission wavelengths and approximate device areas as a function of the operating current densities. In general, the smaller the device active area, the larger the modulation bandwidth, which matches the expectations of a reduced RC effect. The investigation of these LEDs towards high-speed applications was begun rather late, and the bandwidths for most of the reported studiess are still within the several to 20 MHz range. 

**NATURE ELECTRONICS** | VOL 4 | AUGUST 2021 | 559–572 | www.nature.com/natureelectronics 

**562** 



<!-- Start of picture text -->
REVIEW ARTICLE<br>a b<br>Ag (30 nm) 0<br>Capping layer<br>Cathode<br>ETL+,- Active area<br>HBL –6<br>TBPe:MADN or 30-nm-thick<br>BDAVBi:MADN silver Anode<br>EBL Al –10<br>HTL.,- 0.5 mm G3-FEM-OLED at 19 V<br>Al (200 nm)%$&&'()* Organic G3-OLED at 19 V<br>layers BDAVBi film<br>SiOSi!"#$!" 2 TBPe film<br>10 –1 10 0 10 1 10 2 10 3<br>Frequency (MHz)<br>c e f<br>ODEA LED mode 6<br>3<br>H2N O O O NH2<br>0<br>–3<br>d<br>–6 Area (mm 2 )  f −3dB (MHz)<br>–9 7.25 1.8<br>3.70 2.7<br>–12 1.88 3.8<br>0.76 5.8<br>–15<br>0.27 13.7<br>–18 0.10 21.5<br>Detector mode<br>10 –3 10 –2 10 –1 10 0 10 1<br>Frequency (MHz)<br>g<br>100<br>Ref.  30 Ref.  38<br>Ref.  29<br>10<br>Ref.  45 10<br>Ref.  28 Ref.  38 Ref.  46<br>Ref.  51<br>Ref.  27<br>1<br>~1 mm 2<br>R (600–750 nm) 1<br>G (500–560 nm)<br>0.1 B (410–480 nm) Ref.  34 Ref.  33<br>NIR ( 750 nm)<br>OLED Ref.  31<br>QLED<br>PeLED Ref.  50 Ref.  32<br>0.1<br>0.01<br>100 200 500 1,000<br>10 1 10 2 10 3 10 4 10 5<br>Current density (mA cm –2 )<br>(dB)<br>Normalized frequency response<br>(dB)<br>Normalized frequency response<br>3 dB bandwith (MHz)−<br><!-- End of picture text -->

**NATURE ELECTRONICS** 

**Fig. 2 | Frequency response characteristics of and research progress in emerging LEDs. a** , Schematic of the layer stack and contact pads used in BDAVBi:MADN-based ‘fast-emission-molecule’ (FEM)-OLEDs. **b** , Frequency response characteristics of FEM-OLEDs and emitting layers. **c** , Molecular structure of 2,2′-[oxybis(ethylenoxy)]diethylamine (ODEA) used to passivate organic cations of perovskites. G3 is the third-generation OLEDs fabricated in ref.<sup>38</sup> . **d** , Molecular adsorption on the defect-containing surface. The red, blue, cyan and white spheres represent O, N, C and H atoms, respectively. The hydrogen and coordination bonds are denoted by the green lines and blue square, respectively. **e** , Schematic of dual-functional perovskite diodes for optical communication systems. **f** , Frequency response characteristics of PeLEDs with various device areas. _f_ −3dB, −3�dB modulation bandwidth. **g** , The −3�dB bandwidth versus current density of reported studies covering OLEDs<sup>27–34,38</sup> , QLEDs<sup>45,46</sup> and PeLEDs<sup>50,51</sup> . R, red; G, green; B, blue; NIR, near-infrared. Note that the symbol size is proportional to the device active area. Scale symbol, 1�mm<sup>2</sup> . Panels adapted with permission from: **a** , **b** , ref.<sup>38</sup> under a Creative Commons licence CC BY 4.0; **c** , **d** , ref.<sup>52</sup> , Springer Nature Ltd; **e** , **f** , ref.<sup>51</sup> , Springer Nature Ltd. 

##### **Enhancing the EQE towards practical applications** 

A high EQE of an LED is always the long-term aim that researchers have been pursuing. For the high-throughput scenarios (for example, wireless optical links and underwater communications), efficient LEDs with higher output powers enable a more stable and longer transmission distance. As for the low-power system cases 

(for example, IoT and integrated sources for on-chip photonics), the on-chip LEDs with energy and power constraints require high EQEs for lower power consumption, thus enabling a lower energy-per-bit metric (Box 3). 

However, the EQE at a high current density still suffers from severe roll-off, which could be attributed to unbalanced charge 

**NATURE ELECTRONICS** | VOL 4 | AUGUST 2021 | 559–572 | www.nature.com/natureelectronics 

**563** 

<mark>REVIEW ARTICLE</mark> 

**NATURE ELECTRONICS** 

###### **Box 3 | Necessity of efficient devices in LED-based communication links** 

A larger modulation bandwidth can be expected if one reduces the transport-related time constants of an LED and improves the radiative recombination rate of the emitting layer (directly reflected as a shorter luminescence lifetime). An LED for communications normally requires a small active area, thus allowing relatively low parasitic capacitance and current overshoot during the charge and discharge processes. However, a reduction in the active area is accompanied by an absolute electroluminescence intensity drop even at higher injection current densities. An optical data link would fail if the received radiant power is decreased to the minimum detectable power of photodetectors during the transmission. In a single free-space LED link, the received radiant power _Φ_ R (W) is defined as 



<!-- Start of picture text -->
θ 2<br>θ 1 d Ω<br>r d A PD<br>d A LED<br>L<br>d A LED d A  PD<br><!-- End of picture text -->



<!-- Start of picture text -->
Φ� = ������� ��� � ��Ω = ������� ��� � � ������ ��� � �<br>���<br>= ��� × � ��<br><!-- End of picture text -->

where the radiance _L_ R (W m<sup>−2</sup> sr<sup>−1</sup> ) denotes the power emitted, reflected, transmitted or received by a surface per unit projected area, per unit solid angle d _Ω_ ; _θ_ is the angle with respect to the normal direction; d _A_ LEDcos _θ_ 1 and d _A_ PDcos _θ_ 2 are the orthogonally projected areas of the LED and photodetector in a plane normal to the given beam direction, respectively; _r_ is the distance between LED and photodetector; noise-equivalent power NEP (W Hz<sup>−1/2</sup> ) measures the threshold above which a signal can be detected, which defined as the signal power that gives a signal-to-noise ratio of 1 for a given output bandwidth Δ _f_ . 

Terefore, it is necessary to improve the EQE as much as possible for reliable data transmission at a certain distance as the EQE is also found by 



<!-- Start of picture text -->
Φ���¯ �<br>��� = ���<br>����������<br><!-- End of picture text -->

where �¯ _�_ is the average photon energy and _q_ is the elementary charge; Φ���¯ _�_ presents the photon flux (photons per second). A reasonable trade-off is required to maintain a detectable power while decreasing the device active area _A_ LED for a given injected current density _J_ inj. 

For a guided-wave link, the loss of the system roughly comprises of coupling losses, propagation loss and excess loss. Te propagation loss is induced by absorption and scattering effects in the waveguide material, and it thus increases as the length of the waveguide _L_ increases. Te excess loss is caused by the geometry of the device such as bending loss of a bent waveguide. Hence, similarly, a high EQE is also essential in a guided-wave system to ensure a desirable data rate at a fixed device area and transmission distance. 

injection, non-radiative recombination and Joule heating<sup>22,53,54</sup> . In addition, such an effect can strongly narrow the modulated linear dynamic range of the device, reducing its practical use. The EQE can be defined as 



<!-- Start of picture text -->
��� =  � ��� × � ×  � ���� ×  � ��� = ��� ×  � ��� ���<br><!-- End of picture text -->

where _η_ inj is the injection efficiency (fraction of injected carriers that form excitons), _χ_ is the fraction of spin-allowed excitons, _η_ PLQY is the photoluminescence quantum yield (PLQY), _η_ out is the outcoupling efficiency and IQE is the internal quantum efficiency. Note that IQE is directly related to the proportion of radiative recombination in the total charge recombination process. This formula provides three important messages: the numbers of effective electrons and holes injected into the emissive layers should be equal; the non-radiative recombination should be minimized; and the released photons should be effectively extracted. Here, we review the recent strategies for pushing the limits of the above processes. 

**OLEDs.** For injected carriers with uncorrelated spins, each exciton has four possible spin states: one singlet state with a total spin of 0 and three ‘triplet’ states with a total spin of 1. As a consequence of quantum spin statistics, conventional fluorescent OLEDs suffer from a limited IQE of 25% as only the singlets can decay radiatively without spin–orbit coupling<sup>55</sup> (Fig. 3a). Phosphorescent OLEDs can emit from both singlet and triplet excitons, allowing their IQEs to reach almost 100% (refs.<sup>55–57</sup> ). This is commonly achieved by using 

rare noble metal atoms (for example, platinum or iridium) with a large spin–orbit interaction to facilitate intersystem crossing (ISC) and triplet emission<sup>56</sup> . Since the first efficient organic phosphorescent emission was found in 1998<sup>56</sup> , numerous types of phosphorescent emitters have been developed over the past two decades, and several studies have demonstrated maximum EQEs exceeding 30% (refs.<sup>58,59</sup> ). Despite the relatively high efficiency attained from phosphorescent emitters, these materials fail to deliver low-cost devices due to the use of expensive heavy metal complexes<sup>35</sup> . We believe that adopting phosphorescent OLEDs in data communication links might face the same challenge. 

To overcome the efficiency limitation in fluorescent OLEDs, fluorescent materials should effectively enhance the emission by harvesting both singlet and triplet excitons. For example, triplet–triplet annihilation (TTA) fluorescent molecules allow two triplet excitons to fuse into one singlet exciton. This process is also known as triplet fusion, and the maximum IQE of TTA-based OLEDs can theoretically reach 62.5% (ref.<sup>60</sup> ). Major efforts have been made to achieve highly efficient blue OLEDs because TTA-based OLEDs can work at subbandgap voltages through the triplet fusion process, which is beneficial for wide-bandgap blue emitters<sup>37</sup> . Thermally activated delayed fluorescence (TADF) molecules were first proposed in 2009<sup>61</sup> , and they are classified as another type of organic fluorescent material that can utilize both singlet and triplet excitons for emission. In TADF molecules, the singlet–triplet energy splitting (∆ _E_ st), the energy gap between the lowest singlet (S1) and triplet (T1), is small (<0.2 eV), and therefore, the triplet excitons can possibly 

**NATURE ELECTRONICS** | VOL 4 | AUGUST 2021 | 559–572 | www.nature.com/natureelectronics 

**564** 

**NATURE ELECTRONICS** 

### <mark>REVIEW ARTICLE</mark> 



<!-- Start of picture text -->
a b c<br>+ – + – + –<br>25% Singlet 75% Triplet 25% Singlet 75% Triplet<br>K ISC K ISC D n<br>D3<br>S1 S1 K RISC D2<br>Δ E st Δ E st T1 D1<br>T1<br>PF PF DF Ph PF<br>Ph Doublet ( S  = 1/2)<br>S0 S0 D0<br>d e f<br>Energy<br>In Zn P Se S<br>Shell<br>Core<br>PbS QD emitte r<br>Radius 50 nm D on or PbS/ZnO QD matrix<br>g h i<br>CsPbBr3<br>ITO 200 nm Pb<br>I TFB<br>C<br>Single-layered structure –2 N Perovskite<br>Small  n Large  n Organic layer<br>MABr –3 – – ZnO-PEIE A B<br>ITO<br>Bilayered structure CsPbBrITO 3 –4 h ν – –– Glass substrate C<br>–5 +<br>Perovskite MQWs<br>CsPbBr3/MABr + +<br>ITO –6 + +<br>Quasi-core/shell structure<br>(mixture 1.0)<br>MoO x /Au<br>Graded shell<br>TFB<br>ITO<br>Energy (eV) MoO/Au x<br>ZnO-PEIE<br>C MABr CsPbBr3 PEDOT:PSS ITO<br><!-- End of picture text -->

**Fig. 3 | Recent advances in enhancing the EQE for three types of LED. a** – **c** , Emission mechanisms of conventional fluorescence, TADF and radical materials. The formed singlet and triplet excitons are at a ratio of 1:3 after electron–hole recombination. **a** , The singlet excitons radiatively deactivate to S0 via prompt fluorescence (PF) decay. **b** , Both PF and delayed fluorescence (DF) decay occur in TADF materials. Owing to the small singlet–triplet energy splitting (∆ _E_ st), the accumulated triplet excitons at T1 can transfer to S1 through an RISC process after thermal activation. Ph, phosphorescence; _K_ ISC, rate constant of ISC; _K_ RISC, rate constant of RISC. **c** , Illustration of the doublet emission process under excitation. The electron spin vector represents doublets. **d** , Schematic of the structure and electronic energy level within a core/graded-shell QD. **e** , Ternary blend PbS/ZnO CQD thin film incorporating a binary host matrix that not only electronically passivates QDs but also facilitates efficient and balanced carrier injection into the emitting QD layers. **f** , Electron diffraction spectroscopy mapping of In, Zn, P (top left) and Se, S (top right) for InP/ZnSe/ZnS QDs with uniform InP cores and highly symmetric ZnSe/ ZnS shells (scale bars, 10�nm). The schematic shows the surface ligands of InP/ZnSe/ZnS QDs are exchanged by shorter ones. A thick shell with short ligands suppresses interdot energy transfer and Auger recombination and improves charge injection. **g** , Left: compositional distribution management of the quasi-core/shell CsPbBr3/MABr structure for passivating non-radiative defects and balancing charge injection. ITO, indium tin oxide. Right: cross-sectional transmission electron microscopy of quasi-core/shell CsPbBr3/MABr structure. The white arrows indicate the grain boundaries. **h** , Energy level diagram of the perovskite MQW structure assembled by different layered perovskites. Such an MQW structure enables more efficient radiative recombination. _n_ , the number of monolayer sheets within a layer; PEDOT:PSS, poly(3,4-ethylenedioxythiophene) polystyrene sulfonate; TFB, poly(9,9-dioctyl-fluorene-co- _N_ - (4-butylphenyl)diphenylamine); PEIE, polyethylenimine ethoxylated. **i** , PeLED with submicrometre-scale structures that enable efficient light outcoupling from the device and maintain the emission spectrum at various viewing angles. The red arrows illustrate that the light trapped in the device can be extracted by the submicrometre structures along different paths (A, B and C). Panels adapted with permission from: **e** , ref.<sup>80</sup> , Springer Nature Ltd; **f** , ref.<sup>17</sup> , Springer Nature Ltd; **g** , ref.<sup>22</sup> , Springer Nature Ltd; **h** , ref.<sup>53</sup> under a Creative Commons licence CC BY 4.0; **i** , ref.<sup>24</sup> , Springer Nature Ltd. 

upconvert to singlet states through an efficient endothermic reverse ISC (RISC) process<sup>35</sup> (Fig. 3b). Theoretically, TADF material-based OLEDs can reach 100% IQE<sup>62,63</sup> . Similarly, benefiting from the RISC process, hybridized local and charge-transfer organic molecules and carbene metal amides were successively proposed to enable a theoretical unity IQE<sup>64–66</sup> . 

Although a high device efficiency can be achieved by using these materials, they might not be very applicable for high-speed applications because of the existence of delayed fluorescence behaviour (for example, TTA and TADF)<sup>35,37,65</sup> as the lifetime of triplet excitons is much longer than that of singlet excitons, which might affect the fast switching ability (for instance, delayed electroluminescence 

**NATURE ELECTRONICS** | VOL 4 | AUGUST 2021 | 559–572 | www.nature.com/natureelectronics 

**565** 

<mark>REVIEW ARTICLE</mark> 

**NATURE ELECTRONICS** 

was observed after turn-off in some TTA-based devices<sup>37,67</sup> ). Alternatively, the issues of triplet excitons could be bypassed through organic radicals<sup>68</sup> . Specifically, open-shell molecules have a singly occupied molecular orbital in the ground state, yielding an overall spin-1/2 doublet (Fig. 3c). The doublet-spin nature circumvents the formation of triplet excitons that limit the efficiency of non-radical-based OLEDs<sup>68,69</sup> . Recently, a highly efficient deep-red/ near-infrared OLED based on doublet emission with a maximum EQE of 27% and a radiative decay rate of 2.9 × 10<sup>7</sup> s<sup>−1</sup> was demonstrated<sup>68</sup> . This work is believed to overcome the efficiency limitation of OLEDs. In addition, the nanosecond-level luminescence lifetime (17.2 ns) indicates the potential of delivering fast response devices with high efficiency. 

**QLEDs.** Although CQDs have no emission limitation of excitons compared with organic semiconductors, the high density of surface defects and dangling bonds of CQDs cause a low PLQY. To address this issue, substantial research has been devoted to suppressing the non-radiative recombination of CQD emitting layers, which can fall into two broad categories: surface-shell and ligand engineering<sup>70,71</sup> . The former category uses a core/shell design in which the CQD core is coated with a wide-bandgap inorganic semiconductor shell layer (such as ZnS, CdS and ZnSe), while the early core-only structure is generally adopted in CdSe-based high-performance QLEDs<sup>18</sup> . Through further optimization of core/shell structures with favourable shell thicknesses<sup>72</sup> , alloying shells<sup>73</sup> or graded intermediate shells<sup>74</sup> , the CQDs not only alleviate the lattice strain at the interface but also reduce the overlap of electron and hole wavefunctions by exciton confinement in the CQD core, thus effectively lowering the Auger recombination<sup>75</sup> (Fig. 3d). The latter category also plays a crucial role in the nucleation and growth of CQDs<sup>76</sup> . The ligand length can be carefully controlled via ligand exchange, avoiding the aggregation of CQDs in solvents. Concurrently, the balance of charge carrier transport is maintained<sup>77</sup> . 

So far, the combination of these two CQD surface engineering procedures has promoted the PLQY of CQDs to close to unity and the maximum EQE to above 20% (refs.<sup>16,78</sup> ). Nevertheless, for the close-packed CQD thin films, the decreased interdot spacing can lead to Förster resonant energy transfer (FRET) of the excitonic energy of adjacent CQDs<sup>79</sup> . This non-radiative FRET process spontaneously accompanies multiple energy transfer and self-quenching processes, thus largely reducing the PLQY of the CQD emitting layer. Even though one can increase the shell thickness or ligand length to suppress the interdot FRET, the large core/shell lattice mismatch and the intrinsic insulation of long-chain ligands can directly affect the electrical properties of the CQD films. This may cause relatively low device conductivity, profoundly limiting the response speed in optical communications. Alternatively, embedding CQDs into a host matrix has been considered a feasible approach to passivate surface traps and avoid inhomogeneous CQD aggregation (Fig. 3e). Most recently, several different inorganic<sup>80</sup> and perovskite<sup>48,81,82</sup> matrixes were reported to serve as carrier-injection media of CQDs. By incorporating near-infrared CQDs into the host matrix, such structures provide balanced carrier supplies and excitonic energy transfer to the emitting CQDs. Although the maximum EQEs of these QLEDs have not hit a record comparable to many other devices, the use of high carrier mobility matrix materials (for example, binary ZnO/PbS<sup>80</sup> , layered perovskites<sup>81</sup> and hybrid perovskites<sup>82</sup> ) is expected to provide a faster carrier transport capability, which is essential for high-speed LEDs. In addition to the intensively studied CdSe-based QLEDs, a landmark result for InP/ ZnSe/ZnS QLEDs was reported recently. The uniform InP core and highly symmetric core/shell shape are enabled by in situ core surface etching during the high-temperature growth of the shell, resulting in a PLQY near unity and a theoretical maximum EQE of 21.4% (ref.<sup>17</sup> ; Fig. 3f). The research has yet to demonstrate high-speed 

cadmium-free QLEDs, but interest in heavy-metal-free CQD materials and devices is increasing. 

**PeLEDs.** By virtue of the success in perovskite solar cells, considerable progress has also been made in PeLEDs, such as overcoming insufficient film coverage, controlling crystallization and suppressing non-radiative recombination<sup>22,52,83–85</sup> (Fig. 3g). However, the low exciton binding energy in perovskites is conducive to charge separation in solar cell and photodetector applications. Unfortunately, the unexpected non-radiative recombinations, trap-mediated and Auger recombination, limit the emission performance of PeLEDs under moderate carrier densities<sup>86</sup> . As such, a variety of approaches via spatial confinement engineering have been carried out to increase the binding energy and the exciton oscillator strength for high PLQY<sup>87</sup> . 

Compared with their bulk counterparts, low-dimensional perovskites (for example, nanocrystals (NCs), QDs, nanorods, nanoplates and so on), have shown distinct advantages in enhancing the bimolecular radiative recombination and avoiding the formation of morphological defects. Soon after the first embodiments of hybrid perovskite QDs<sup>88</sup> and all-inorganic perovskite NCs<sup>89</sup> , a series of studies started to focus on defect passivation<sup>90</sup> , surface ligand engineering<sup>23</sup> and NC nucleation control<sup>91</sup> . These attempts pioneered perovskite QDs/NCs with PLQYs surpassing 70%. The corresponding EQEs of QD/NC-based LEDs rose quickly from less than 1% to over 20%. Another approach utilized 2D or quasi-2D layered perovskites (for example, Ruddlesden–Popper perovskites) as emissive layers that can offer a much larger exciton binding energy (320 meV) at room temperature<sup>92</sup> . The small organic or inorganic cations of 3D perovskites can be substituted by organic cations with a large ionic radius that exhibit mismatch with the corner-sharing lead halide octahedral structure. The 3D perovskites can therefore be separated into quasi-2D perovskites (monolayer or multilayer), and the dominant number of layers directly depends on the proportion of long-chain organic cations. 

In 2016, two groups independently developed mixed quasi-2D perovskites by introducing phenylethylammonium iodide (PEAI)<sup>93</sup> and 1-naphthylmethylamine iodide (NMAI)<sup>94</sup> to create a multiple quantum well (MQW) structure, realizing efficient cascade energy transfer<sup>53</sup> (Fig. 3h). Subsequently, a number of interesting studies were performed, including structure design (for example, quasi-2D/3D perovskite–polymer heterostructures<sup>25</sup> and quasi-2D Dion–Jacobson structures<sup>95</sup> ), phase control<sup>96</sup> and composition tailoring<sup>19</sup> . Inspired by the concept of strongly confined perovskites, blue PeLEDs have achieved an improvement in the peak EQE from ~1% to 12.3% (refs.<sup>97,98</sup> ), though a gap remains compared with the state-of-the-art green and red PeLEDs. 

On the basis of the unique advantages of both high carrier mobility and relatively balanced bipolar charge transport in perovskites<sup>87</sup> , further improvement of the device performance, particularly in the response speed, is promising. In particular, even for polycrystalline films with a large amount of grain boundaries, their carrier mobilities (~1–10 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ) can still be several orders of magnitude higher than those of many typical organic semiconductor films (for example, _N_ , _N_ ′-di(1-naphthyl)- _N_ , _N_ ′-diphenyl-(1,1′-biphenyl)-4,4′-diamine (α-NPD) ~10<sup>−4</sup> –10<sup>−3</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , Alq3 ~10<sup>−6</sup> –10<sup>−4</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> )<sup>99</sup> . Nevertheless, the excess long-chain cations in low-dimensional perovskites may also prohibit charge transport due to their inherent insulating property. With this in mind, one should be very careful to suppress the exciton quenching by doping long-chain cations<sup>100</sup> without compromising the electrical conductivity. 

**Light outcoupling.** Prominent improvements in the PLQY in these three types of material have been made, while the externally measured device efficiencies are still far below their internal luminescence efficiencies. Previous demonstrations have attributed 

**NATURE ELECTRONICS** | VOL 4 | AUGUST 2021 | 559–572 | www.nature.com/natureelectronics 

**566** 

<mark>REVIEW ARTICLE</mark> 

**NATURE ELECTRONICS** 



<!-- Start of picture text -->
a b c<br>Fluorophores<br>ETL<br>HTL<br>Electrode<br>Blue LED Side-by-side RGB  Tandem RGB<br>e<br>d<br>Δ A / A 1.0 Absorption<br>0.10 Cs2Ag0.60Na0.40InCl6<br>10 3<br>Cs2AgInCl6<br>0.08 0.8<br>Photoluminescence<br>0.06 Cs2Ag0.60Na0.40InCl6<br>10 2 0.6 Cs2AgInCl6 (×1,000)<br>0.04 Cs2NaInCl6 (×1,500)<br>0.02 0.4<br>10 1<br>0<br>0.2<br>–0.02<br>10 0<br>0<br>400 500 600 700 800 400 500 600 700 800<br>Wavelength (nm) Wavelength (nm)<br>Time (ps)<br>Intensity (a.u.)<br><!-- End of picture text -->

**Fig. 4 | White-light wireless transmission. a** , Schematic of a colour-converter-based white-light LED. **b** , **c** , Schematic of electrically driven side-by-side ( **b** ) and tandem ( **c** ) RGB white-light LEDs. **d** , Transient absorption spectra of Cs2Ag0.60Na0.40InCl6 under 325�nm wavelength laser excitation. Δ _A/A_ is the optical density. A wide photoinduced absorption of Cs2Ag0.60Na0.40InCl6 that covers the visible light spectrum can be observed. **e** , Absorption and photoluminescence spectra of the double perovskites Cs2AgInCl6 and Cs2Ag0.60Na0.40InCl6. Cs2Ag0.60Na0.40InCl6 shows an enhanced broadband emission (400–800�nm). White emission of 500-nm-thick Cs2Ag0.60Na0.40InCl6 films under 254�nm ultraviolet illumination can be clearly observed in the inset. Panels adapted with permission from: **d** , **e** , ref.<sup>126</sup> , Springer Nature Ltd. 

this discrepancy to light trapping in planar-type LEDs<sup>101</sup> . Due to the relatively high refractive indices of perovskites, this effect is more severe in PeLEDs than in OLEDs and QLEDs<sup>102</sup> . The generated light in the emissive layer would induce several different optical modes including an out-coupled mode, a surface plasmon polariton mode, a substrate mode and parasitic absorption. Among these optical modes, only the out-coupled mode contributes to the out-of-plane light emisison<sup>103</sup> . Recently, a patterned submicrometre-scale structure was utilized in PeLEDs to reduce the optical losses in lateral waveguide substrate modes<sup>24</sup> (Fig. 3i). Consequently, the outcoupling efficiency was improved from 21.8% to 30% compared with a reference device with a conventional flat emissive layer. Other strategies to improve out-of-plane coupling demonstrated in OLEDs can also be applied to QLEDs and PeLEDs, such as the use of low-index grids<sup>104</sup> , textured substrates<sup>105</sup> and microcavity structures<sup>106</sup> . In contrast, for low-power optical interconnects, on-chip devices generally require a high in-plane coupling efficiency over a high out-of-plane coupling efficiency. A few attempts of integrating light sources and in-plane photodetectors/polymer waveguides have been realized in either a stacked configuration of an OLED on top of a planar single-mode waveguide based on evanescent coupling scheme<sup>107</sup> or a chip-based dual-beam sensor platform using integrated OLED and organic photodetectors<sup>108</sup> . However, it is still challenging to efficiently couple light from a Lambertian and incoherent thin-film light source into waveguides at the current stage. Continuous work on efficient photon outcoupling is highly desirable to promote both free-space and guided-wave communications. 

##### **Light fidelity (Li-Fi)** 

Among the future demands of monochromatic LED-based optical links, indoor wireless VLC and on-chip interconnects are seen as the 

most possible solutions. Recently, there has been increasing interest in using solution-processed materials for light fidelity (Li-Fi), while the study of on-chip interconnects based on them relatively lags behind. Li-Fi is commonly regarded as an upcoming candidate to complement the less-sufficient and overcrowded radio-frequency communications<sup>2</sup> . The data are transmitted by modulating the light source; in parallel, the function of solid-state lighting can also be fulfilled due to the much higher frequency than the human eye can detect. The application of individual red, green and blue (RGB) pixel packaged LEDs with reliable performance for data communications currently seems immature due to, for instance, the difficulties in colour balancing, signal processing and fabrication. Most present white-light system designs propose wide-bandwidth blue µLED chips combined with a layer of fluorescent material on top as a colour converter to realize white-light transmission<sup>109</sup> (Fig. 4a). 

**Colour converters.** As a typical example, a blue GaN/InGaN µLED is coated with a longer emission wavelength phosphor that downconverts part of the blue light into yellow (or green and red) light, resulting in white emission<sup>110</sup> . Although µLED sources with large bandwidths (several hundred megahertz) have already been realized, the use of phosphors (for example, Y3Al5O12:Ce<sup>3+</sup> ) with a relatively long luminescence lifetime of ~200 ns greatly slows the response, with a limited modulation bandwidth of only a few megahertz<sup>111</sup> . The modulation bandwidth of colour converters is inversely proportional to their luminescence lifetimes<sup>42</sup> . In some cases, owing to the bandwidth limitation of light sources, the measured bandwidth of the converter is smaller than the estimated value<sup>112</sup> . To speed up the transmission, either filtering out the slow phosphor emission<sup>113</sup> or using optimized detection and signal equalization<sup>114</sup> could be useful. However, replacing the slow phosphor by colour converters 

**NATURE ELECTRONICS** | VOL 4 | AUGUST 2021 | 559–572 | www.nature.com/natureelectronics 

**567** 

<mark>REVIEW ARTICLE</mark> 

**NATURE ELECTRONICS** 



<!-- Start of picture text -->
Emerging high-speed LEDs<br>2 Flexible biosensors 3 Data centre<br>1 Self-guiding vehicles<br>4 Underwater<br>communications<br>6 Li-Fi and short-distance on-board communications 5 Low-cost on-chip IoT sensors<br>1010101<br><!-- End of picture text -->

**Fig. 5 | Future scenarios for LED communications.** LED links can be applied in widespread communication solutions: (1) integrated components for short-range communications with rigorous latency requirements (for example, self-guiding vehicles); (2) flexible biosensors (for example, real-time health monitoring and disposable lab-on-a-chip for point-of-care diagnostics); (3) data centre; (4) underwater communications; (5) low-cost on-chip IoT sensors for accurate tracking and positioning; (6) indoor data services (for example, Li-Fi and short-distance on-board communications). 

with a faster response time (luminescence lifetime of less than 10 ns, ideally less than 1 ns (ref.<sup>115</sup> )) is expected to be the fundamental approach for overcoming such a bottleneck. 

Since 2012, colour converters made from organic fluorophores, CQDs and perovskites have been proposed for white-light VLC applications. For example, a conjugated polymer poly(1,4-phenylenevinylene (PPV)-based colour converter with a fast response of over 200 MHz and a recorded 1.68 Gbps data rate was demonstrated<sup>116</sup> . Further explorations of organic fluorophores as colour converters, including blended organic molecules and conjugated polymers with extremely short luminescence lifetimes (less than 1 ns), were subsequently reported<sup>117,118</sup> . Other organic categories, such as aggregation-induced emission luminogens (AIEgens) based on diphenyl isoquinolinium derivatives and dye encapsulated metal–organic frameworks (dye@MOFs), were also studied as colour converters for VLC applications<sup>112,119</sup> . Possibly due to the shorter lifetime, the reported AIEgens show much larger −6 dB electrical modulation bandwidths (up to 279 MHz) than MOFs (3.6 MHz). 

A few studies emerged soon afterwards, using CQDs (CdSe/ ZnS) or perovskite QDs (CsPbBr _x_ I3− _x_ ) as colour converters with luminescence lifetimes of several to tens of nanoseconds<sup>42,44,120</sup> . These materials exhibit a large colour gamut and a high PLQY, while the modulation bandwidths are still smaller than those of organic fluorophores. Further research has resulted in the pioneering work of a laser diode-powered perovskite NC (CsPbBr3)-based colour converter achieving a −3 dB bandwidth of 491 MHz, manifesting its great potential in high-speed VLC applications<sup>43</sup> . For carbon dots, the reported luminescence lifetimes are several nanoseconds with efficient emissions in the solid state after particular 

post-treatments<sup>121,122</sup> . Such heavy-metal-free colour-converter materials are also expected to be promising candidates with a modulation bandwidth comparable to that of organic fluorophores. 

**White LEDs.** In addition to downconverter-based white-light sources, electrically driven RGB white-light LEDs with unique merits of high colour saturation and low energy consumption are considered an alternative choice for VLC applications. The stable white emission of these LEDs can be obtained by either side-by-side RGB pixels or stacked diodes (tandem structure) (Fig. 4b,c). Such types of device, including OLEDs and QLEDs, have been extensively investigated for displays<sup>123,124</sup> . However, the study of VLC applications has rarely been reported, which might be due to the intrinsically unmatched frequency response between each diode. This situation could soon change due to the demonstration of full-colour RGB-mixed QLEDs, where three different colours of QDs are integrated into a single emitter<sup>125</sup> . However, the unavoidable charge transfer between QDs with various bandgaps would cause a voltage-dependent colour evolution. More recently, the white-light-emitting double perovskite Cs2Ag0.6Na0.4InCl6 was introduced<sup>126</sup> . Through breaking of the parity-forbidden transition and reduction of the electronic dimensionality, this double perovskite exhibits a broad emission spectrum (400–800 nm) and a high PLQY (Fig. 4d,e). Although further device application of these materials will be challenging, it is implied that fast VLC could also be realized by single-emitter-based white LEDs. 

##### **Outlook** 

LEDs are potential candidates for transmitters in next-generation optical data communications. Photonic devices for IoT and 6G 

**NATURE ELECTRONICS** | VOL 4 | AUGUST 2021 | 559–572 | www.nature.com/natureelectronics 

**568** 

<mark>REVIEW ARTICLE</mark> 

#### **NATURE ELECTRONICS** 

communication systems must though be high-speed, low-cost and easy to integrate<sup>3,5,9</sup> (Fig. 5). Organic semiconductors, CQDs and perovskites are promising materials that could be used to complement and/or compete with conventional inorganic counterparts in particular optoelectronic applications. However, the development of LEDs for optical communication purposes based on these solution-processable materials has only begun, and their performance is still far from what is required. 

The modulation performance and device efficiency are the two key elements for fast LEDs, but only a handful of studies have addressed both parameters. With respect to the materials, charge carriers in emitting materials are expected to recombine radiatively with a short decay time. For organic semiconductors, although several types of material can potentially deliver very high IQEs, emitting materials must be carefully selected because of their long luminescence lifetimes causing delayed emission. For CQDs and perovskites, major efforts have been devoted to the optimization of material synthesis, defect passivation and compositional engineering for higher energy conversion efficiencies. Some of these procedures might bring about a relatively long luminescence lifetime, but this is detrimental to obtaining a rapid response. 

A possible way to achieve a short lifetime is to raise the carrier recombination rate. Rational doping of emitting materials could, for instance, be an effective solution to increase the possibility of recombination thus reducing the carrier lifetime<sup>127,128</sup> . However, introducing excess dopant may sacrifice the radiative luminescence efficiency and increase the heat generated inside the devices. This twofold effect would affect both modulation performance and device efficiency. In view of Fermi’s golden rules, the decay rate _Γ_ , given by Γ = (���¯�)<sup>�</sup> |⟨�| � |�⟩|<sup>�</sup> _�_ (�� − ��), where ħ is the reduced Planck constant, |⟨�| � |�⟩|<sup>�</sup> is the matrix element of the transition from the initial state |�⟩ at energy _E_ i in the valence band to the final state ⟨�| at energy _E_ f in the conduction band, is governed mainly by the transition dipole moment and local density of states<sup>129</sup> . To this end, effort has been devoted to manipulating the transition dipole moment (such as via wave function engineering by synthesizing low-dimensional materials<sup>130</sup> ) or controlling the local density of optical states (such as via photonic environment engineering by using hyperbolic metamaterials<sup>129</sup> ). Nevertheless, the study of these materials and devices still lags far behind that of the µLEDs, and further explorations are required. Moreover, the most efficient QLEDs and PeLEDs contain toxic heavy metals (such as cadmium and lead). Thus, toxic-metal-free devices must be developed to deliver a sustainable communications technology<sup>17,131</sup> . 

In terms of device engineering, a large RC time constant is, so far, the major limiting factor to achieving high-speed operation. Typically, the most straightforward method to weaken the impact of the device RC time constant is to reduce the device active area, while maintaining a high injected current. Appropriate contact optimization is also crucial to minimize the device series resistance. In particular, the relatively high density of surface traps in QLEDs and PeLEDs could aggravate the charge accumulation effect, which might bring extra capacitance to the devices. Therefore, interface engineering, including defect passivation, requires additional attention. 

The luminescence lifetime will gradually dominate the modulation performance of an LED when its RC time constant is lower than the threshold. In addition, the charge transit time may be a factor under high-speed operation, particularly for those devices using organic functional layers with intrinsically low mobilities. This could be effectively reduced by employing large electric fields and high-mobility CTLs. However, in the modification of functional layers, charge imbalance issues<sup>87</sup> , including energy level mismatch, incompatible carrier mobilities between the ETL and HTL, and current leakage, should be avoided to prevent extra charge accumula- 

tion. Therefore, more rational selection and optimization of CTLs need to be further investigated for high-speed LEDs. 

Due to the nonlinear current–voltage characteristics of LEDs, high-level injection is required for a large bandwidth. To further improve the modulation performance, good heat management is necessary to allow devices to work at higher current densities with long-term stability, which is especially difficult in PeLEDs. So far, most of the reported bandwidth optimization strategies are based on experience from inorganic fast μLEDs. Clarifying the mechanisms for achieving a high-frequency response for each type of emerging LED is equally important. 

In terms of systems-level development, and owing to the solution-processable advantage of these emerging LEDs, the key goal is to develop mature scalable fabrication techniques (such as advanced printing techniques<sup>132,133</sup> ). This will enable easy integration with other photonic components<sup>133,134</sup> —including polymer waveguides, optical microlenses and photodetectors—providing low-cost, low-coupling loss, industrial-scale and highly integrated communication systems. Finally, considerable effort has been devoted to expanding the data transmission rates in communication systems through advanced equalization algorithms<sup>2,135,136</sup> . We believe that the way ahead lies in combining these with emerging LED links to achieve practical high-speed data transmissions for next-generation communications. 

Received: 8 May 2020; Accepted: 25 June 2021; Published online: 23 August 2021 

##### **References** 

1. Lindemann, M. et al. Ultrafast spin-lasers. _Nature_ **568** , 212–215 (2019). 2. Karunatilaka, D., Zafar, F., Kalavally, V. & Parthiban, R. LED based indoor visible light communications: state of the art. _IEEE Commun. Surv. Tutorials_ **17** , 1649–1678 (2015). 

3. Rappaport, T. S. et al. Wireless communications and applications above 100 GHz: opportunities and challenges for 6G and beyond. _IEEE Access_ **7** , 78729–78757 (2019). 

4. Jovicic, A., Li, J. & Richardson, T. Visible light communication: opportunities, challenges and the path to market. _IEEE Commun. Mag._ **51** , 26–32 (2013). 

5. Dang, S., Amin, O., Shihada, B. & Alouini, M.-S. What should 6G be? _Nat. Electron._ **3** , 20–29 (2020). 

6. Ren, A., Yuan, L., Xu, H., Wu, J. & Wang, Z. Recent progress of III–V quantum dot infrared photodetectors on silicon. _J. Mater. Chem. C_ **7** , 14441–14453 (2019). 

7. Rashidi, A., Monavarian, M., Aragon, A., Rishinaramangalam, A. & Feezell, D. Nonpolar plane InGaN/GaN micro-scale light-emitting diode with 1.5 GHz modulation bandwidth. _IEEE Electron Device Lett._ **39** , 520–523 (2018). 

8. Wang, L. et al. 13 GHz E-O bandwidth GaN-based micro-LED for multi-gigabit visible light communication. _Photon. Res._ **9** , 792 (2021). 

9. Clark, J. & Lanzani, G. Organic photonics for communications. _Nat. Photon._ **4** , 438–446 (2010). 

10. García De Arquer, F. P., Armin, A., Meredith, P. & Sargent, E. H. Solution-processed semiconductors for next-generation photodetectors. _Nat. Rev. Mater._ **2** , 1–16 (2017). 

11. Asghari, M. & Krishnamoorthy, A. V. Energy-efficient communication. _Nat. Photon._ **5** , 268–270 (2011). 

12. Tang, C. W. & Vanslyke, S. A. Organic electroluminescent diodes. _Appl. Phys. Lett._ **51** , 913–915 (1987). 

13. Burroughes, J. H. et al. Light-emitting diodes based on conjugated polymers. _Nature_ **347** , 539–541 (1990). 

14. Jou, J. H., Kumar, S., Agrawal, A., Li, T. H. & Sahoo, S. Approaches for fabricating high efficiency organic light emitting diodes. _J. Mater. Chem. C_ **3** , 2974–3002 (2015). 

15. Colvin, V. L., Schlamp, M. C. & Alivisatos, A. P. Light-emitting diodes made from cadmium selenide nanocrystals and a semiconducting polymer. _Nature_ **370** , 354–357 (1994). 

16. Dai, X. et al. Solution-processed, high-performance light-emitting diodes based on quantum dots. _Nature_ **515** , 96–99 (2014). 

17. Won, Y. H. et al. Highly efficient and stable InP/ZnSe/ZnS quantum dot light-emitting diodes. _Nature_ **575** , 634–638 (2019). 

18. Shirasaki, Y., Supran, G. J., Bawendi, M. G. & Bulović, V. Emergence of colloidal quantum-dot light-emitting technologies. _Nat. Photon._ **7** , 13–23 (2013). 

**NATURE ELECTRONICS** | VOL 4 | AUGUST 2021 | 559–572 | www.nature.com/natureelectronics 

**569** 

### <mark>REVIEW ARTICLE</mark> 

19. Quan, L. N. et al. Tailoring the energy landscape in quasi-2D halide perovskites enables efficient green-light emission. _Nano Lett._ **17** , 3701–3709 (2017). 

20. Kojima, A., Teshima, K., Shirai, Y. & Miyasaka, T. Organometal halide perovskites as visible-light sensitizers for photovoltaic cells. _J. Am. Chem. Soc._ **131** , 6050–6051 (2009). 

21. Best research-cell efficiency chart. _National Renewable Energy Laboratory_ https://www.nrel.gov/pv/cell-efficiency.html (2021). 

22. Lin, K. et al. Perovskite light-emitting diodes with external quantum efficiency exceeding 20 per cent. _Nature_ **562** , 245–248 (2018). 

23. Chiba, T. et al. Anion-exchange red perovskite quantum dots with ammonium iodine salts for highly efficient light-emitting devices. _Nat. Photon._ **12** , 681–687 (2018). 

24. Cao, Y. et al. Perovskite light-emitting diodes based on spontaneously formed submicrometre-scale structures. _Nature_ **562** , 249–253 (2018). 

25. Zhao, B. et al. High-efficiency perovskite–polymer bulk heterostructure light-emitting diodes. _Nat. Photon._ **12** , 783–789 (2018). 

26. Kim, Y. H., Cho, H. & Lee, T. W. Metal halide perovskite light emitters. _Proc. Natl. Acad. Sci. USA_ **113** , 11694–11702 (2016). 

27. Barlow, I. A., Kreouzis, T. & Lidzey, D. G. A polymer light-emitting diode as an optical communication light source. _Org. Electron._ **8** , 621–624 (2007). 

28. Fukuda, T., Okada, T., Wei, B., Ichikawa, M. & Taniguchi, Y. Influence of carrier-injection efficiency on modulation rate of organic light source. _Opt. Lett._ **32** , 1905 (2007). 

29. Fukuda, T., Wei, B., Suto, E., Ichikawa, M. & Taniguchi, Y. Fast-response organic-inorganic hybrid light-emitting diode. _Phys. Status Solidi Rapid Res. Lett._ **2** , 290–292 (2008). 

30. Barlow, I. A., Kreouzis, T. & Lidzey, D. G. High-speed electroluminescence modulation of a conjugated-polymer light emitting diode. _Appl. Phys. Lett._ **94** , 11–14 (2009). 

31. Haigh, P. A. et al. Visible light communications: real time 10 Mb/s link with a low bandwidth polymer light-emitting diode. _Opt. Express_ **22** , 2830 (2014). 

32. Haigh, P. A. et al. Wavelength-multiplexed polymer LEDs: towards 55 Mb/s organic visible light communications. _IEEE J. Sel. Areas Commun._ **33** , 1819–1828 (2015). 

33. Chen, H., Xu, Z., Gao, Q. & Li, S. A 51.6 Mb/s experimental VLC system using a monochromic organic LED. _IEEE Photon. J._ **10** , 1–12 (2018). 

34. Minotto, A. et al. Visible light communication with efficient far-red/ near-infrared polymer light-emitting diodes. _Light Sci. Appl._ **9** , 70 (2020). 

35. Liu, Y., Li, C., Ren, Z., Yan, S. & Bryce, M. R. All-organic thermally activated delayed fluorescence materials for organic light-emitting diodes. _Nat. Rev. Mater._ **3** , 18020 (2018). 

36. Xu, Z., Tang, B. Z., Wang, Y. & Ma, D. Recent advances in high performance blue organic light-emitting diodes based on fluorescence emitters. _J. Mater. Chem. C_ **8** , 2614–2642 (2020). 

37. Salehi, A. et al. Realization of high-efficiency fluorescent organic light-emitting diodes with low driving voltage. _Nat. Commun._ **10** , 2305 (2019). 

38. Yoshida, K. et al. 245 MHz bandwidth organic light-emitting diodes used in a gigabit optical wireless data link. _Nat. Commun._ **11** , 1171 (2020). 

39. Fukuda, T., Okada, T., Wei, B., Ichikawa, M. & Taniguchi, Y. Transient property of optically pumped organic film of different fluorescence lifetimes. _Appl. Phys. Lett._ **90** , 1–4 (2007). 

40. Chime, A. C. et al. Electrical modelling and design of ultra-fast micro-OLED with coplanar wave-guided electrodes in ON–OFF regime. _Org. Electron._ **56** , 284–290 (2018). 

41. Ruhstaller, B. et al. Transient and steady-state behavior of space charges in multilayer organic light-emitting diodes. _J. Appl. Phys._ **89** , 4575–4586 (2001). 

42. Xiao, X. et al. Improving the modulation bandwidth of LED by CdSe/ZnS quantum dots for visible light communication. _Opt. Express_ **24** , 21577 (2016). 

43. Dursun, I. et al. Perovskite nanocrystals as a color converter for visible light communication. _ACS Photon._ **3** , 1150–1156 (2016). 

44. Kang, C. H. et al. High-speed colour-converting photodetector with all-inorganic CsPbBr3 perovskite nanocrystals for ultraviolet light communication. _Light Sci. Appl._ **8** , 2047–7538 (2019). 

45. Xiao, H. et al. Effects of injection current on the modulation bandwidths of quantum-dot light-emitting diodes. _IEEE Trans. Electron Devices_ **66** , 4805–4810 (2019). 

46. Xiao, H. et al. 4 Mb/s under a 3 m transmission distance using a quantum dot light-emitting diode and NRZ-OOK modulation. _Opt. Lett._ **45** , 1297 (2020). 

47. Xiao, H., Wang, R., Wang, K., Chen, W. & Chiang, K. S. Trade-offs between illumination and modulation performances of quantum-dot LED. _IEEE Photon. Technol. Lett._ **32** , 726–729 (2020). 

48. Gong, X. et al. Highly efficient quantum dot near-infrared light-emitting diodes. _Nat. Photon._ **10** , 253–257 (2016). 

#### **NATURE ELECTRONICS** 

49. Pu, C. et al. Electrochemically-stable ligands bridge the photoluminescence-electroluminescence gap of quantum dots. _Nat. Commun._ **11** , 937 (2020). 

50. Deng, W. et al. 2D Ruddlesden–Popper perovskite nanoplate based deep‐blue light‐emitting diodes for light communication. _Adv. Funct. Mater._ **29** , 1903861 (2019). 

51. Bao, C. et al. Bidirectional optical signal transmission between two identical devices using perovskite diodes. _Nat. Electron._ **3** , 156–164 (2020). 

52. Xu, W. et al. Rational molecular passivation for high-performance perovskite light-emitting diodes. _Nat. Photon._ **13** , 418–424 (2019). 

53. Zou, W. et al. Minimising efficiency roll-off in high-brightness perovskite light-emitting diodes. _Nat. Commun._ **9** , 608 (2018). 

54. Zhao, L. et al. Termal management enables bright and stable perovskite light-emitting diodes. _Adv. Mater._ **32** , 2000752 (2020). 

55. Friend, R. H. et al. Electroluminescence in conjugated polymers. _Nature_ **397** , 121–128 (1999). 

56. Baldo, M. A. et al. Highly efficient phosphorescent emission from organic electroluminescent devices. _Nature_ **395** , 151–154 (1998). 

57. O’Brien, D. F., Baldo, M. A., Tompson, M. E. & Forrest, S. R. Improved energy transfer in electrophosphorescent devices. _Appl. Phys. Lett._ **74** , 442–444 (1999). 

58. Shin, H. et al. Sky-blue phosphorescent OLEDs with 34.1% external quantum efficiency using a low refractive index electron transporting layer. _Adv. Mater._ **28** , 4920–4925 (2016). 

59. Lu, G. Z. et al. Rapid room temperature synthesis of red iridium(III) complexes containing a four-membered Ir–S–C–S chelating ring for highly efficient OLEDs with EQE over 30%. _Chem. Sci._ **10** , 3535–3542 (2019). 

60. Sinha, S., Rothe, C., Güntner, R., Scherf, U. & Monkman, A. P. Electrophosphorescence and delayed electroluminescence from pristine polyfluorene thin-film devices at low temperature. _Phys. Rev. Lett._ **90** , 127402 (2003). 

61. Endo, A. et al. Termally activated delayed fluorescence from Sn<sup>4+</sup> – porphyrin complexes and their application to organic light-emitting diodes—a novel mechanism for electroluminescence. _Adv. Mater._ **21** , 4802–4806 (2009). 

62. Uoyama, H., Goushi, K., Shizu, K., Nomura, H. & Adachi, C. Highly efficient organic light-emitting diodes from delayed fluorescence. _Nature_ **492** , 234–238 (2012). 

63. Goushi, K., Yoshida, K., Sato, K. & Adachi, C. Organic light-emitting diodes employing efficient reverse intersystem crossing for triplet-to-singlet state conversion. _Nat. Photon._ **6** , 253–258 (2012). 

64. Li, W. et al. A twisting donor-acceptor molecule with an intercrossed excited state for highly efficient, deep-blue electroluminescence. _Adv. Funct. Mater._ **22** , 2797–2803 (2012). 

65. Di, D. et al. High-performance light-emitting diodes based on carbene-metal-amides. _Science_ **356** , 159–163 (2017). 

66. Hall, C. R., Romanov, A. S., Bochmann, M. & Meech, S. R. Ultrafast structure and dynamics in the thermally activated delayed fluorescence of a carbene-metal-amide. _J. Phys. Chem. Lett._ **9** , 5873–5876 (2018). 

67. Xiang, C., Peng, C., Chen, Y. & So, F. Origin of sub-bandgap electroluminescence in organic light-emitting diodes. _Small_ **11** , 5439–5443 (2015). 

68. Ai, X. et al. Efficient radical-based light-emitting diodes with doublet emission. _Nature_ **563** , 536–540 (2018). 

69. Abdurahman, A. et al. Understanding the luminescent nature of organic radicals for efficient doublet emitters and pure-red light-emitting diodes. _Nat. Mater._ **19** , 1224–1229 (2020). 

70. Shang, Y. & Ning, Z. Colloidal quantum-dots surface and device structure engineering for high-performance light-emitting diodes. _Natl Sci. Rev._ **4** , 170–183 (2017). 

71. Chen, F., Guan, Z. & Tang, A. Nanostructure and device architecture engineering for high-performance quantum-dot light-emitting diodes. _J. Mater. Chem. C_ **6** , 10958–10981 (2018). 

72. Pal, B. N. et al. ‘Giant’ CdSe/CdS core/shell nanocrystal quantum dots as efficient electroluminescent materials: Strong influence of shell thickness on light-emitting diode performance. _Nano Lett._ **12** , 331–336 (2012). 

73. Bae, W. K. et al. Controlled alloying of the core-shell interface in CdSe/CdS quantum dots for suppression of auger recombination. _ACS Nano_ **7** , 3411–3419 (2013). 

74. Yang, Y. et al. High-efficiency light-emitting devices based on quantum dots with tailored nanostructures. _Nat. Photon._ **9** , 259–265 (2015). 

75. Peng, X., Schlamp, M. C., Kadavanich, A. V. & Alivisatos, A. P. Epitaxial growth of highly luminescent CdSe/CdS core/shell nanocrystals with photostability and electronic accessibility. _J. Am. Chem. Soc._ **119** , 7019–7029 (1997). 

76. Murray, C. B., Norris, D. J. & Bawendi, M. G. Synthesis and characterization of nearly monodisperse CdE (E = S, Se, Te) semiconductor nanocrystallites. _J. Am. Chem. Soc._ **115** , 8706–8715 (1993). 

**NATURE ELECTRONICS** | VOL 4 | AUGUST 2021 | 559–572 | www.nature.com/natureelectronics 

**570** 

#### **NATURE ELECTRONICS** 

77. Shrestha, A., Batmunkh, M., Tricoli, A., Qiao, S. Z. & Dai, S. Near-infrared active lead chalcogenide quantum dots: preparation, post-synthesis ligand exchange, and applications in solar cells. _Angew. Chem. Int. Ed._ **58** , 5202–5224 (2019). 

78. Shen, H. et al. Visible quantum dot light-emitting diodes with simultaneous high brightness and efficiency. _Nat. Photon._ **13** , 192–197 (2019). 

79. Kagan, C. R., Murray, C. B., Nirmal, M. & Bawendi, M. G. Electronic energy transfer in CdSe quantum dot solids. _Phys. Rev. Lett._ **76** , 1517–1520 (1996). 

80. Pradhan, S. et al. High-efficiency colloidal quantum dot infrared light-emitting diodes via engineering at the supra-nanocrystalline level. _Nat. Nanotechnol._ **14** , 72–79 (2019). 

81. Gao, L. et al. Efficient near-infrared light-emitting diodes based on quantum dots in layered perovskite. _Nat. Photon._ **14** , 227–233 (2020). 

82. Vasilopoulou, M. et al. Efficient colloidal quantum dot light-emitting diodes operating in the second near-infrared biological window. _Nat. Photon._ **14** , 50–56 (2020). 

83. Yuan, Z. et al. Unveiling the synergistic effect of precursor stoichiometry and interfacial reactions for perovskite light-emitting diodes. _Nat. Commun._ **10** , 2818 (2019). 

84. Miao, Y. et al. Stable and bright formamidinium-based perovskite light-emitting diodes with high energy conversion efficiency. _Nat. Commun._ **10** , 1–7 (2019). 

85. Cho, H. et al. Overcoming the electroluminescence efficiency limitations of perovskite light-emitting diodes. _Science_ **350** , 1222–1225 (2015). 

86. Zheng, K. et al. Exciton binding energy and the nature of emissive states in organometal halide perovskites. _J. Phys. Chem. Lett._ **6** , 2969–2975 (2015). 

87. Stranks, S. D., Hoye, R. L. Z., Di, D., Friend, R. H. & Deschler, F. Te physics of light emission in halide perovskite devices. _Adv. Mater._ **31** , 1803336 (2019). 

88. Schmidt, L. C. et al. Nontemplate synthesis of CH3NH3PbBr3 perovskite nanoparticles. _J. Am. Chem. Soc._ **136** , 850–853 (2014). 

89. Protesescu, L. et al. Nanocrystals of cesium lead halide perovskites (CsPbX3, X = Cl, Br, and I): novel optoelectronic materials showing bright emission with wide color gamut. _Nano Lett._ **15** , 3692–3696 (2015). 

90. Zhang, F. et al. Brightly luminescent and color-tunable colloidal CH3NH3PbX3 (X = Br, I, Cl) quantum dots: potential alternatives for display technology. _ACS Nano_ **9** , 4533–4542 (2015). 

91. Wang, H. et al. Perovskite-molecule composite thin films for efficient and stable light-emitting diodes. _Nat. Commun._ **11** , 891 (2020). 

92. Hong, X., Ishihara, T. & Nurmikko, A. V. Dielectric confinement effect on excitons in PbI4-based layered semiconductors. _Phys. Rev. B_ **45** , 6961–6964 (1992). 

93. Yuan, M. et al. Perovskite energy funnels for efficient light-emitting diodes. _Nat. Nanotechnol._ **11** , 872–877 (2016). 

94. Wang, N. et al. Perovskite light-emitting diodes based on solution-processed self-organized multiple quantum wells. _Nat. Photon._ **10** , 699–704 (2016). 

95. Shang, Y. et al. Highly stable hybrid perovskite light-emitting diodes based on Dion–Jacobson structure. _Sci. Adv._ **5** , eaaw8072 (2019). 

96. Yang, X. et al. Efficient green light-emitting diodes based on quasi-two-dimensional composition and phase engineered perovskite with surface passivation. _Nat. Commun._ **9** , 570 (2018). 

97. Wang, Q., Ren, J., Peng, X. F., Ji, X. X. & Yang, X. H. Efficient sky-blue perovskite light-emitting devices based on ethylammonium bromide induced layered perovskites. _ACS Appl. Mater. Interfaces_ **9** , 29901–29906 (2017). 

98. Dong, Y. et al. Bipolar-shell resurfacing for blue LEDs based on strongly confined perovskite quantum dots. _Nat. Nanotechnol._ **15** , 668–674 (2020). 

99. Matsushima, T. et al. High performance from extraordinarily thick organic light-emitting diodes. _Nature_ **572** , 502–506 (2019). 

100. Wang, Z. et al. Manipulating the trade-off between quantum yield and electrical conductivity for high-brightness quasi-2D perovskite light-emitting diodes. _Adv. Funct. Mater._ **28** , 1804187 (2018). 

101. Adachi, C., Baldo, M. A., Tompson, M. E. & Forrest, S. R. Nearly 100% internal phosphorescence efficiency in an organic light emitting device. _J. Appl. Phys._ **90** , 5048–5051 (2001). 

102. Richter, J. M. et al. Enhancing photoluminescence yields in lead halide perovskites by photon recycling and light out-coupling. _Nat. Commun._ **7** , 1341 (2016). 

103. Chen, Z. et al. Utilization of trapped optical modes for white perovskite light-emitting diodes with efficiency over 12%. _Joule_ **5** , 456–466 (2021). 

104. Sun, Y. & Forrest, S. R. Enhanced light out-coupling of organic light-emitting devices using embedded low-index grids. _Nat. Photon._ **2** , 483–487 (2008). 

105. Koo, W. H. et al. Light extraction from organic light-emitting diodes enhanced by spontaneously formed buckles. _Nat. Photon._ **4** , 222–226 (2010). 

106. Dodabalapur, A., Rothberg, L. J., Miller, T. M. & Kwock, E. W. Microcavity effects in organic semiconductors. _Appl. Phys. Lett._ **64** , 2486–2488 (1994). 

### <mark>REVIEW ARTICLE</mark> 

107. Ramuz, M., Bürgi, L., Stanley, R. & Winnewisser, C. Coupling light from an organic light emitting diode (OLED) into a single-mode waveguide: toward monolithically integrated optical sensors. _J. Appl. Phys._ **105** , 184508 (2009). 

108. Ratcliff, E. L. et al. A planar, chip-based, dual-beam refractometer using an integrated organic light-emitting diode (OLED) light source and organic photovoltaic (OPV) detectors. _Anal. Chem._ **82** , 2734–2742 (2010). 

109. Haigh, P. A., Ghassemlooy, Z., Rajbhandari, S. & Papakonstantinou, I. Visible light communications using organic light emitting diodes. _IEEE Commun. Mag._ **51** , 148–154 (2013). 

110. Rajbhandari, S. et al. A review of gallium nitride LEDs for multi-gigabit-per-second visible light data communications. _Semicond. Sci. Technol._ **32** , 023001 (2017). 

111. Schubert, E. F., Gessmann, T. & Kim, J. K. Organic Light Emitting Devices: Synthesis, Properties and Applications (eds Müllen, K. & Scherf, U.) 1–33 (Wiley, 2005); https://doi.org/10.1002/3527607986.ch1 

112. Wang, Z. et al. Warm-white-light-emitting diode based on a dye-loaded metal–organic framework for fast white-light communication. _ACS Appl. Mater. Interfaces_ **9** , 35253–35259 (2017). 

113. Khalid, A. M., Cossu, G., Corsini, R., Choudhury, P. & Ciaramella, E. 1-Gb/s transmission over a phosphorescent white LED by using rate-adaptive discrete multitone modulation. _IEEE Photon. J._ **4** , 1465–1473 (2012). 

114. Huang, X., Wang, Z., Shi, J., Wang, Y. & Chi, N. 16 Gbit/s phosphorescent white LED based VLC transmission using a cascaded pre-equalization circuit and a differential outputs PIN receiver. _Opt. Express_ **23** , 22034 (2015). 

115. Manousiadis, P. P., Yoshida, K., Turnbull, G. A. & Samuel, I. D. W. Organic semiconductors for visible light communications. _Philos. Trans. R. Soc. A_ **378** , 20190186 (2020). 

116. Chun, H. et al. Visible light communication using a blue GaN μ LED and fluorescent polymer color converter. _IEEE Photon. Technol. Lett._ **26** , 2035–2038 (2014). 

117. Sajjad, M. T. et al. Novel fast color-converter for visible light communication using a blend of conjugated polymers. _ACS Photon._ **2** , 194–199 (2015). 

118. Vithanage, D. A. et al. BODIPY star-shaped molecules as solid state colour converters for visible light communications. _Appl. Phys. Lett._ **109** , 013302 (2016). 

119. Zhang, Y. et al. Aggregation-induced emission luminogens as color converters for visible-light communication. _ACS Appl. Mater. Interfaces_ **10** , 34418–34426 (2018). 

120. Mei, S. et al. High-bandwidth white-light system combining a micro-LED with perovskite quantum dots for visible light communication. _ACS Appl. Mater. Interfaces_ **10** , 5641–5648 (2018). 

121. Zhou, Z. et al. Hydrogen peroxide-treated carbon dot phosphor with a bathochromic-shifed, aggregation-enhanced emission for light-emitting devices and visible light communication. _Adv. Sci._ **5** , 1800369 (2018). 

122. Liu, E. et al. Highly emissive carbon dots in solid state and their applications in light-emitting devices and visible light communication. _ACS Sustain. Chem. Eng._ **7** , 9301–9308 (2019). 

123. Geffroy, B., le Roy, P. & Prat, C. Organic light-emitting diode (OLED) technology: materials, devices and display technologies. _Polym. Int._ **55** , 572–582 (2006). 

124. Zhang, H., Chen, S. & Sun, X. W. Efficient red/green/blue tandem quantum-dot light-emitting diodes with external quantum efficiency exceeding 21%. _ACS Nano_ **12** , 697–704 (2018). 

125. Lee, K. H. et al. Highly efficient, color-reproducible full-color electroluminescent devices based on red/green/blue quantum dot-mixed multilayer. _ACS Nano_ **9** , 10941–10949 (2015). 

126. Luo, J. et al. Efficient and stable emission of warm-white light from lead-free halide double perovskites. _Nature_ **563** , 541–545 (2018). 

127. Zou, S. et al. Stabilizing cesium lead halide perovskite lattice through Mn(II) substitution for air-stable light-emitting diodes. _J. Am. Chem. Soc._ **139** , 11443–11450 (2017). 

128. Euvrard, J., Yan, Y. & Mitzi, D. B. Electrical doping in halide perovskites. _Nat. Rev. Mater._ **6** , 531–549 (2021). 

129. Poddubny, A., Iorsh, I., Belov, P. & Kivshar, Y. Hyperbolic metamaterials. _Nat. Photon._ **7** , 958–967 (2013). 

130. Hou, X. et al. Engineering Auger recombination in colloidal quantum dots via dielectric screening. _Nat. Commun._ **10** , 1750 (2019). 

131. Wu, Z., Liu, P., Zhang, W., Wang, K. & Sun, X. W. Development of InP quantum dot-based light-emitting diodes. _ACS Energy Lett._ **5** , 1095–1106 (2020). 

132. Jiang, C. et al. Printed subthreshold organic transistors operating at high gain and ultralow power. _Science_ **363** , 719–723 (2019). 

133. Zhang, C. et al. Organic printed photonics: from microring lasers to integrated circuits. _Sci. Adv._ **1** , e1500257 (2015). 

134. Lee, M. et al. Broadband modulation of light by using an electro-optic polymer. _Science_ **298** , 1401–1403 (2002). 

**NATURE ELECTRONICS** | VOL 4 | AUGUST 2021 | 559–572 | www.nature.com/natureelectronics 

**571** 

**NATURE ELECTRONICS** 

### <mark>REVIEW ARTICLE</mark> 

135. Zhu, M. et al. Optical single side-band Nyquist PAM-4 transmission using dual-drive MZM modulation and direct detection. _Opt. Express_ **26** , 6629 (2018). 

136. Fan, Q., Zhou, G., Gui, T., Lu, C. & Lau, A. P. T. Advancing theoretical understanding and practical performance of signal processing for nonlinear optical communications through machine learning. _Nat. Commun._ **11** , 3694 (2020). 

137. Zhang, Y., Wang, L., Wang, K., Wong, K. S. & Wu, K. Recent advances in the hardware of visible light communication. _IEEE Access_ **7** , 91093–91104 (2019). 

138. Agrawal, G. P. _Fiber‐Optic Communication Systems_ (Wiley, 2010); https:// doi.org/10.1002/9780470918524 

##### **Acknowledgements** 

We thank X. Li for valuable discussions and arguments. H.W. thanks D. Dong for the screen bar that helped when drafting this article. This work was supported by EPSRC (2015; EP/M015165/1), the National Natural Science Foundation of China (61974014), the National Key Research and Development Program of China (2019YFB2203400), the ‘111 Project’ (B20030), the Fundamental Research Funds for the Central Universities (ZYGX2019Z018), the Innovation Group Project of Sichuan Province (20CXTD0090) and the UESTC Shared Research Facilities of Electromagnetic Wave and Matter Interaction (Y0301901290100201). W.Z. thanks 

the financial support from EPSRC New Investigator Award (2018; EP/R043272/1) and H2020-EU grant (2018; CORNET 760949). 

##### **Author contributions** 

All authors conceived this work and contributed to the discussion of content. A.R. and H.W. researched the data and wrote the first draft. W.Z., J.W. and I.H.W. revised the manuscript before submission. 

##### **Competing interests** 

The authors declare no competing interests. 

##### **Additional information** 

**Correspondence** should be addressed to W.Z. or J.W. 

**Peer review information** _Nature Electronics_ thanks Jiang Tang, Lina Quan and the other, 

anonymous, reviewer(s) for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at www.nature.com/reprints. 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in 

published maps and institutional affiliations. 

© Springer Nature Limited 2021 

**NATURE ELECTRONICS** | VOL 4 | AUGUST 2021 | 559–572 | www.nature.com/natureelectronics 

**572** 

