# Progress on AlGaN-based solar-blind ultraviolet photodetectors and focal plane arrays

| 字段 | 内容 |
|---|---|
| 期刊 | Light: Science & Applications |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 432 |
| 作者 | Qing Cai, Hai-Fan You, Hui Guo, Jin Wang, Bin Liu, Zi-Li Xie, Dun-Jun Chen, Hai Lu et al. |
| DOI | 10.1038/s41377-021-00527-4 |
| 源文件 | 023_Cai_2021_Progress-on-AlGaN-based-solar-blind-ultraviolet.pdf |

---
Official journal of the CIOMP 2047-7538 www.nature.com/lsa 

Cai et al. Light: Science & Applications (2021) 10:94 https://doi.org/10.1038/s41377-021-00527-4 

O <u>p e n</u> A c c e s s 

## R E V I E W A R T I C L E 

# Progress on AlGaN-based solar-blind ultraviolet photodetectors and focal plane arrays 

Qing Cai 1, Haifan You1, Hui Guo1, Jin Wang1, Bin Liu1, Zili Xie1, Dunjun Chen1, Hai Lu1, Youdou Zheng1 and Rong Zhang<sup>1,2,3</sup> 

### Abstract 

Solar-blind ultraviolet (UV) photodetectors (PDs) have attracted tremendous attention in the environmental, industrial, military, and biological fields. As a representative III-nitride material, AlGaN alloys have broad development prospects in the field of solar-blind detection due to their superior properties, such as tunable wide bandgaps for intrinsic UV detection. In recent decades, a variety of AlGaN-based PDs have been developed to achieve high-precision solar-blind UV detection. As integrated optoelectronic technology advances, AlGaN-based focal plane arrays (FPAs) are manufactured and exhibit outstanding solar-blind imaging capability. Considering the rapid development of AlGaN detection techniques, this paper comprehensively reviews the progress on AlGaN-based solar-blind UV PDs and FPAs. First, the basic physical properties of AlGaN are presented. The epitaxy and p-type doping problems of AlGaN alloys are then discussed. Diverse PDs, including photoconductors and Schottky, metal–semiconductor–metal (MSM), p-i-n, and avalanche photodiodes (APDs), are demonstrated, and the physical mechanisms are analyzed to improve device performance. Additionally, this paper summarizes imaging technologies used with AlGaN FPAs in recent years. Benefiting from the development of AlGaN materials and optoelectronic devices, solar-blind UV detection technology is greeted with significant revolutions. 

### Introduction 

Ultraviolet (UV) radiation, which covers the electromagnetic spectrum from 400 to 10 nm, can be divided into four subdivisions: UVA (320–400 nm), UVB (280–320 nm), UVC (200–280 nm), and VUV (vacuum UV, 10–200 nm). The sun is the primary source of UV light, and UVC light it typically absorbed by the ozonosphere when it passes through the atmosphere. Thus, no UVC photons exist naturally within the Earth’s atmosphere. Therefore, the UVC solar spectrum is also called the solar-blind UV waveband<sup>1–3</sup> . This feature ensures that the detection of solar-blind UV photon signals within the Earth’s atmosphere is not affected by background 

Correspondence: Rong Zhang (rzhangxmu@xmu.edu.cn) 

> 1Key Laboratory of Advanced Photonic and Electronic Materials, School of Electronic Science and Engineering, Nanjing University, Nanjing 210093, China 

> 2Collaborative Innovation Center for Optoelectronic Semiconductors and Efficient Devices, Department of Physics, Xiamen University, Xiamen 361005, China 

radiation from sunlight, which gives the solar-blind UV detecting potential applications in early missile threat warning and tracking, environmental monitoring, engine monitoring, flame detection and monitoring, non-line-ofsight communications, etc.<sup>4–12</sup> . 

Group-III nitride semiconductors exhibit superior properties, such as a wide energy bandgap, large thermal conductivity, high carrier mobility, small dielectric constant, strong anti-radiation ability, and good chemical stability<sup>13–17</sup> . Due to these superior properties, III-nitride semiconductors can be applied in extreme environments<sup>18</sup> , solid-state lighting and displays<sup>19</sup> , shortwavelength lasers<sup>20–22</sup> , and optical detection<sup>23–26</sup> . IIInitride semiconductors primarily include GaN, AlN, and InN along with their ternary and quaternary alloys AlGaN, InGaN, and AlGaInN<sup>27–32</sup> . Among these materials, the AlGaN ternary alloy semiconductor can tune its bandgap in the range of 3.4–6.2 eV by changing the Al component, covering the UVA, UVB, and UVC 

Full list of author information is available at the end of the article 

> © The Author(s) 2021, corrected publication 2021 

> OpenAccess ThisarticleislicensedunderaCreativeCommonsAttribution4.0InternationalLicense,whichpermitsuse,sharing,adaptation,distributionandreproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/licenses/by/4.0/. 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 2 of 31 

wavelength bands of 200–365 nm. Additionally, AlGaN exhibits a high specific detectivity approximately 10<sup>12</sup> cm Hz<sup>1/2</sup> W<sup>−133</sup> . Based on these outstanding optoelectronic characteristics, AlGaN ternary alloys exhibit marked advantages in promoting the evolution of UV photodetectors (PDs), particularly in fabricating intrinsic solarblind UV detectors<sup>34,35</sup> . 

In 1998, O Ambacher concluded various results of Group-III nitride semiconductor devices<sup>36</sup> . Due to the rapid development of blue light-emitting diodes (LEDs), III-nitride based blue-emitting lasers, high power transistors, and PDs have also gradually attracted more attention. In 2001, E Munoz et al. reviewed the basic structure of a III-nitride UV photodetector<sup>37</sup> and focused on the essential physical mechanisms of devices with different structures and preliminarily emphasized that UV imaging will drastically change various aspects of civilian and military fields. In 2005, Khan et al. provided a review of advances in III-nitride LEDs and laser diodes (LDs)<sup>38</sup> . The development of AlGaN LEDs also promotes progress in the epitaxial techniques of subsequent AlGaN-based photodetect (PD) materials. In 2011, Razeghi summarized the developments of III-nitride materials in critical spectral regimes from UV to terahertz wavelengths<sup>39</sup> . Among these materials, AlGaN alloys play a significant role in the LEDs, avalanche photodiodes (APDs), single photon detectors, and focal plane arrays (FPAs). In 2015, Alaie et al. described the advantages of different UV PDs such as AlGaN, ZnO, MgZnO, SiC, diamond, and other material compound PDs<sup>40</sup> , and also analyzed the state of UV detection from the aspect of material. In 2018, Li. et al. reviewed AlGaN-based materials and UV devices in detail<sup>41</sup> . Various devices and application scenarios of AlGaN are reviewed in their work. Despite considerable effort, more robust content in AlGaN solar-blind UV detection are required for better understanding the development of this field and finding out the problems needed to be solved in the future. 

In terms of FPAs, Dupuis et al. concluded their work on GaN-based UV APDs and FPA imaging applications<sup>42</sup> . However, their fabricated devices were primarily composed of GaN and low-Al-content AlGaN, and their detection and imaging wavelengths were primarily located in the UVA band. High-Al-content AlGaN material fabrication has always been a serious problem. In addition, although different research groups have reported corresponding UV FPAs in conjunction with their UV detectors, recent summaries of AlGaN solar-blind detection and FPAs are inadequate. 

In recent years, AlGaN-based materials and their UV PDs have been rapidly developed<sup>43–46</sup> . The fabrication techniques of common Schottky and p-i-n structure AlGaN UVA PDs are relatively mature<sup>47–52</sup> . However, AlGaN-based solar-blind UV PDs and FPAs remain to be 

improved due to uniformity problems in materials and devices<sup>53–62</sup> . To perform solar-blind UV detection, the bandgap of AlxGa1-xN must exceed 4.42 eV (Al composition: ~0.4). Due to the low surface mobility of Al adatoms and large lattice mismatch between AlN and GaN<sup>63–71</sup> , the epitaxy of high-Al-content AlGaN alloys with high crystal quality is one of the primary problems in the development of AlGaN-based solar-blind detectors<sup>72–74</sup> . Another problem is the low p-type doping efficiency of AlGaN<sup>75–81</sup> , and it is difficult to obtain high-holeconcentration and high-conductivity p-AlGaN materials. This phenomenon can be attributed to the high activation energy of the Mg acceptor in the AlGaN alloy<sup>82</sup> . In addition to material issues, device design and key FPA techniques are also the primary factors that must be considered in the development of AlGaN-based solarblind detection technology. 

This review summarizes recent advances in the processing and properties of AlGaN-based solar-blind UV PDs and FPAs. In the following sections, epitaxial growth and doping techniques of AlGaN are presented. Then, the third section primarily focuses on the development of AlGaN solar-blind UV PDs, including the progress of various detectors, performance improvement methods, and internal physical mechanisms. Moreover, the advances in AlGaN-based solar-blind FPAs and imaging techniques are reviewed to better understand solar-blind technology for versatile applications (Fig. 1). 



<!-- Start of picture text -->
1020 1023<br>Mg δ-doping w/o In 1022 P-ALxGa1-xN 80 nm<br>10101918 Mg 101010212019 i-ALn-ALi-AL0.40.40.4GaGaGa0.60.60.6N 140 nmN 180 nmN 60 nm<br>In 1018 n-AL0.5Ga0.5N 300 nm<br>1017 0 50 100 150Depth (nm)200 250 300 350 4001017 AL0.5AINGa0.5N<br>p -AlGaN<br>i -AlGaN<br>Overgrown AlN layer n -AlGaN<br>Sapphire substrate 3  μ m ALGAN n -GaN GaN-on-sapphire substateTi mask<br>Sapphire<br>n-AlGaNp-AlGaNi-AlGaN<br>Indium Indium Indium<br>bump bump bump<br>Si ROIC<br>Application<br>ocal plane array<br>g<br>F<br>opin<br>P<br>D<br>h<br>oto<br>deDevice<br>Material te<br>ct<br>o<br>h r<br>t<br>–3)Mg concentration (cm –3)In concentration (cm<br>ow<br>Gr<br><!-- End of picture text -->

Fig. 1 Diagram of this review. Including the material section (AlGaN growth and doping), device section (AlGaN solar-blind photodetector), and application section (AlGaN focal plane array) 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 3 of 31 

### Epitaxial growth and doping of AlGaN 

The high crystalline quality of AlGaN is the basis of high-performance AlGaN-based devices. The growth methods of III–V compound semiconductors can be primarily divided into two categories—the monoblock single crystal growth method, and the epitaxial growth method, which groups materials with the same crystalline orientation on the substrate. In monoblock method, the Bridgman method involves placing the material in a vertically crucible with a tip and then solidifying it directionally from the tip of the crucible through a sharply gradient temperature. Directional solidification of the material can be achieved by a moving furnace or a moving crucible. The horizontal Bridgman method was also developed for GaAs growth. 

With regard to III–V compound semiconductors with volatile components, the V components tend to overflow from the melt due to dissociation pressure at their melting point. To prevent this phenomenon and allow the semiconductor compound material to be grown as a single crystal in a conventional czochralski (CZ) furnace, the surface of the compound semiconductor solution can be covered with a transparent layer with high chemical stability, a low melting point, and a high boiling point (e.g., B2O3). Concurrently, the single crystal furnace is filled with inert gas. The compound semiconductor can then be grown as a single crystal by the liquid encapsulation czochralski (LEC) process, as silicon and germanium are grown by the CZ method. 

However, these methods typically cannot avoid contamination by impurities from quartz crucibles and heating systems. Due to the high melting point of GaN/ AlGaN material (>1700 °C), it is also difficult to prepare AlGaN bulk single crystal materials using these methods. Even with high-temperature (HT) and high-pressure technologies, only powdered and needle-like AlGaN crystals can be prepared. The growth of thin film AlGaN materials still depends on the development of epitaxial technology. 

There are three types of epitaxy methods: liquid phase epitaxy (LPE), molecular beam epitaxy (MBE), and vapor phase epitaxy (VPE). The LPE method is easy to operate, and a single crystal grows at low temperature and fast speed. However, the LPE method can only fabricate a thin epitaxy layer with limited thickness. It is also difficult to purposefully change the gradient of impurity concentrations and the type of conductivity during the growth process intensively. Hydride vapor phase epitaxy (HVPE) can grow III-nitrides rapidly. However, it is difficult to accurately control the film thickness with this method, and the reaction gas is corrosive to the equipment, which effects the purity of GaN(AlGaN) materials. MBE can precisely control the thickness of the growth film. Additionally, the growth temperature is lower than that of the 

VPE and LPE methods. Doping and composition of material can be modulated in this way. However, the low growth rate, complex equipment, and high cost impede the application of the MBE method in large-scale industrial production. Metal-organic vapor phase epitaxy (MOVPE) achieves a moderate growth rate and can accurately control the film thickness, which is particularly suitable for large-scale industrial production. MOVPE is also the most widely used method to growth of GaN (AlGaN) materials and high-performance devices. 

However, the epitaxy of AlGaN material poses several serious problems. AlGaN material is typically grown on an AlN/sapphire substrate<sup>83–87</sup> . Due to the large lattice mismatch of 13.2% between AlN and sapphire, the AlN template presents many dislocations, which affect the epitaxial AlGaN crystal quality<sup>88–91</sup> . Meanwhile, AlGaN epitaxy requires temperatures in excess of 1300 °C. The large thermal expansion mismatch in the AlGaN/AlN/ sapphire structure results in heat-induced stress, which is released by dislocations<sup>89,91–93</sup> . Additionally, because the surface adhesion coefficient of Al atoms is much higher than that of Ga atoms, dense islands tend to form during nucleation growth. To minimize the free energy of the system, two adjacent islands are combined, thus leading to tensile stress<sup>94</sup> . Because tensile stress is inversely proportional to the island size, the AlGaN film tends to crack due to excessive tensile stress, deteriorating the quality of the film. Also, the Al source provider trimethyl aluminum (TMA) is relatively active and reacts with ammonia gas above the substrate to form large numbers of microparticles before reaching the growth surface. The microparticles generated by the pre-reaction fall on the surface of material and produce many defects. 

The realization of effective doping is also a basic requirement of semiconductor device fabrication<sup>76,95–99</sup> . For (Al)GaN, p-type doping of nitride is an important factor that restricts the development of GaN-based devices. Although breakthroughs have been made in p-GaN<sup>100–102</sup> , there are difficulties in p-type doping of high-Al-content AlGaN because the activation energy of the Mg acceptor increases with increasing Al content. Therefore, it is important to study the doping characteristics of nitride semiconductor materials to improve the performance of AlGaN-based devices. 

#### Epitaxy of high-Al-content AlGaN 

To improve the crystalline quality of high-Al-content AlGaN epitaxial thin films, researchers have tried various methods to control stress to reduce the dislocations during the material growth process. Mudu et al.<sup>103</sup> incorporated a low temperature (840 °C) AlN nucleation layer onto the c-plane sapphire substrate. Subsequently, an AlN buffer layer grown at high temperature (1150 °C) is employed to convert the island-like three-dimensional 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 4 of 31 

growth mode at low temperatures into a two-dimensional growth mode. Several dislocations are then bent to form a closed loop and disappear. Concurrently, the AlN buffer layer can adjust the stress and alleviate the subsequent stress accumulation of the AlGaN epitaxial film, which is conducive to obtaining better high-quality, crack free, and high-Al-content AlGaN material. Adivarahan et al.<sup>97</sup> proposed that a small amount of In elements can be added as a lubricant on the growth surface to enhance the migration of Al atoms, thus alleviating the defects resulting from strong adhesion coefficient of Al adatoms. Codoping of In elements can also significantly increase the effective doping concentration of n-AlGaN. Using this method, they obtained a smooth, low-roughness surface morphology, and significantly reduced the screw dislocation and edge dislocation density of the AlGaN material. 

Interlayer modulation can effectively grow AlGaN materials. Jiang et al.<sup>104</sup> inserted a 25-nm-thick HT GaN layer between the AlN template and the AlGaN layer to block dislocations from penetrating through the AlGaN layer. They found that the HT-GaN layer can effectively block the vertical edge dislocations (Fig. 2c, d), while the screw dislocation density remains unchanged (Fig. 2a, b). This method can reduce the total dislocation density of the AlGaN material by an order of magnitude. 



<!-- Start of picture text -->
a 200 nm b 200 nm<br>GaN<br>g=0002<br>c 200 nm d 200 nm<br>GaN<br>100 nm<br>g=0-110<br><!-- End of picture text -->

Fig. 2 Cross-sectional TEM images for the AlGaN layers grown on AlN/sapphire templates. Samples without (a, c) and with (b, d) a 25 nm HT-GaN interlayer. a, b are measured with diffraction vector g = (0002) to image screw-component threading dislocations. c, d with g = (0–110) to image edge-component threading dislocations. The inset of Fig. 2d is an enlarged image of the dislocation, corresponding to the dashed circle. Reprinted with permission from Jiang et al.<sup>104</sup> . Copyright 2005 American Institute of Physics 

The control of stress and strain during epitaxial growth is also one of the primary factors that must be considered. Bethoux et al.<sup>105</sup> prepared a thick fully plastic strain relaxed AlGaN cracking layer on the GaN template, and then buried cracks via lateral epitaxial growth to achieve a high-quality AlGaN film with a smooth surface and no cracks. Figure 3a shows the strain-relaxation process. The cracks of the AlGaN film introduce misfit dislocations (MDs) at the AlGaN/GaN interface. A significant opening of cracks is formed due to the contraction of AlGaN stripes. The tensile stress leads to crack propagation into the inserted GaN layer. Crack edges in the GaN layer allow the nucleation of MDs and AlGaN lateral growth over cracks can bury MDs. Finally, a smooth and crack free film with high crystalline quality is obtained. This method is also suitable for AlN epitaxy. Figure 3b, c confirm the burying of cracks by regrowth. Voids can be distinctly observed in the inserted GaN layer, as shown in Fig. 3c. Figure 3d illustrates the cracked MOCVD-grown Al0.2Ga0.8N film on GaN. The enlarged SEM image also verifies crack overgrowth, as shown in Fig. 3e. An AFM image of the smooth Al0.2Ga0.8N film exhibits a marked step-flow morphology. The density of threading dislocations is estimated to be 5 × 10<sup>8</sup> cm<sup>−2</sup> . The root-meansquare (RMS) roughness of the film is below 1 nm in a 15 × 15 μm<sup>2</sup> scan. 

Zhang et al.<sup>106,107</sup> inserted an AlGaN/AlN superlattice (SL) layer to adjust the stress of the AlGaN film during the epitaxial growth of AlGaN. This growth technique can be used to grow thick crack-free AlGaN films. Sun et al.<sup>108</sup> also used pulsed atomic layer epitaxy (PALE) to grow shortperiod SL structures. The PALE method can enhance the migration of Al adatoms and reduce parasitic pre-actions. The TEM micrographs in Fig. 4 show screw-type threading dislocations for two 1-μm-thick n<sup>+</sup> -Al0.55Ga0.45N layers. Samples are grown on AlN buffer with and without the SL structure. Figure 4a shows that there are few threading dislocations at the interfaces between AlN, SL, and top n-AlGaN. Instead, dislocation loops in Fig. 4a at the interface between AlGaN and SL are formed to eliminate threading dislocations after inserting the SL structure. Conversely, Fig. 4b shows large amounts of dislocations in the n<sup>+</sup> -Al0.55Ga0.45N layer without SL. The overall screwtype threading dislocations are estimated to be below 3 × 10<sup>8</sup> cm<sup>−2</sup> . Compared to direct epitaxy (dislocation density: ~5 × 10<sup>9</sup> cm<sup>−2</sup> ), the number of dislocations is reduced by more than an order of magnitude. 

Epitaxial lateral overgrowth (ELO) is also an important method for growing high-Al-content AlGaN and AlN materials<sup>109–113</sup> . The commonly used method is to grow AlGaN on the pattern template<sup>114–116</sup> . Typically, as the epitaxial AlGaN film thickness increases, the dislocation density decreases. Kueller et al.<sup>117</sup> proposed epitaxial overgrowth of AlGaN on a structured AlN/sapphire 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 5 of 31 



<!-- Start of picture text -->
a b f<br>AlN<br>1 2 GaN 1  μ m<br>AlGaN hE<br>GaN c<br>δC AlGaN<br>3 4<br>GaN<br>3  μ m<br>d e<br>5<br>1  μ m<br>20  μ m 0.5  μ m<br>Fig. 3 Control of stress and strain during AlGaN/AlN epitaxial growth. a Schematic diagram of relaxation process: (1) coherent growth below<br>the critical thickness; (2) AlGaN cracks and MDs are introduced at AlGaN/GaN interface; (3) Relaxation resulted from dislocations enlarges the crack<br>aperture; (4) cracks propagate to the GaN layer, MDs relaxing in GaN; (5) lateral growth buries cracks. Cross-sectional XTEM images of b MBE-grown<br>AlN and c MOCVD-grown Al0.2Ga0.8N films on GaN. d SEM images of a 500-nm-thick cracked MOCVD-grown Al0.2Ga0.8N film on GaN. e Enlarged SEM<br>image of crack overgrowth. f AFM image of a crack free Al0.2Ga0.8N film. Reprinted with permission from Bethoux et al. 105 . Copyright 2003 American<br>Institute of Physics<br>a b<br>AlGaN g=0002<br>g=0002<br>Dislocation loop<br>SL<br>AlN<br>500 nm 200 nm<br>Sapphire<br>Fig. 4 AlGaN/AlN superlattice employed on the AlGaN growth. Cross-section TEM images [vector: g = (0002)] showing screw-component TDs in<br>n-Al0.55Ga0.45N with (a) and without (b) superlattice insertion. Reprinted with permission from Sun et al. 108 . Copyright 2005 American Institute of<br>Physics<br><!-- End of picture text -->

template, as shown in Fig. 5a. They also found that stripes parallel to the [1–100] direction are a more promising pattern for AlGaN coalescence in their growth conditions. Cicek et al.<sup>118</sup> reported an AlGaN-based UV detector grown on a patterned Si(111) template (Fig. 5b) and used PALE technique to facilitate the epitaxial lateral growth of AlN, as shown in Fig. 5c. Due to the slow epitaxial lateral growth rate and high aspect ratio trench, air voids form at the trench location after the AlN has grown 8.5 μm vertically. The air voids mitigate crackings and reduce the generation of dislocations in the AlN template. Figure 5d shows an AFM image of a coalesced AlN surface in a 5 × 10 μm scan. Step-flow morphology is shown with an RMS roughness of 0.12 nm in the trench regions. However, the ridge regions exhibit different characteristics. Based on this phenomenon, Mogilatenko et al.<sup>116</sup> studied the dislocation evolution and distribution in thick AlN layers with the ELO method. As shown in Fig. 5g, the threading dislocation inclination contributes to the compensation of 

compressive strain in the growth process of Al0.8Ga0.2N on the ELO-AlN template. Therefore, the wing (trench) regions exhibit lower defect densities than the ridge regions (Fig. 5f). 

A nanopatterned template can also be used for AlGaN/ AlN ELO. In addition to improving crystal quality, the small nanopatterned substrate (NPS) ELO technique requires a thinner coalescence epilayer thickness, which helps reduce the epitaxial manufacturing cost. Donghyun et al.<sup>119</sup> used nanosphere lithography combined with the ELO method to improve the crystal quality of the AlN epilayer and achieved a small coalescence thickness of below 2 μm. Figure 6a illustrates the silica nanosphere lithography technique. The air voids incorporated by the NPS can effectively relieve the stress of AlN, as shown in Fig. 6b–d. Additionally, the miscut of the sapphire substrate introduces typical zigzag macrosteps<sup>120</sup> , as shown in the AFM image of Fig. 6f. Conroy et al. used selfassembled silica spheres on the surface of AlN to produce 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 6 of 31 



<!-- Start of picture text -->
a b d RMS: 1.2 Å<br>820 nm AlGaN 6  μ m<br>3  μ m<br>AlN<br>e<br>6  μ m<br>Si(111)<br>c<br>LEO AlN [0002]AlN<br>[0001] 820 nm AlGaN<br>[10-10]AlN<br>[11-20] 3  μ m 6  μ m Si(111) 3  μ m Si(111)<br>f 4  μ m g Al 0.8 Ga 0.2 N<br>Inclined dislocation line<br>in the coalescence<br>grain boundary<br>68°<br>1  μ m<br>[1-100] ELO-AlN(m)<br>Wing Wing Middle Wing Middle Wing<br>of ridge of ridge<br>Ridge Trench Ridge<br>Ridge Trench Ridge<br><!-- End of picture text -->

Fig. 5 Epitaxial lateral overgrowth for AlGaN fabrication. a Cross-sectional secondary electron image of AlGaN grown on an AlN ELO template. Reprinted with permission from Kueller et al.<sup>117</sup> . Copyright 2010 Elsevier B.V. b, c SEM images of the stripe-patterned AlN/Si(111) template. d AFM image of the ELO-AlN layer grown on the patterned Si template and corresponding cross-sectional SEM image of the patterned structure (e). Atomic steps are observed over the trenches. Reprinted with permission from Cicek et al.<sup>118</sup> . Copyright 2013 American Institute of Physics. f Plan-view SEM image of n-Al0.8Ga0.2N grown on ELO-AlN. g Cross-sectional annular dark-field STEM image presents that the defect distribution in the ELO-AlN-AlGaN structure. Reprinted with permission from Mogilatenko et al.<sup>116</sup> . Copyright 2014 Elsevier B.V 

the pattern template. Figure 6g, h shows the ELO process and the edge-type dislocation of overgrowth AlN decreases by approximately two orders of magnitude<sup>121</sup> . Le. et al.<sup>122</sup> demonstrated semipolar AlGaN fabricated by controlled nanowire coalescence and obtained AlGaN quasi 3D film structures with nearly free dislocations (Fig. 6i). Also, based on coalesced film structures, they fabricated UV LEDs and obtained excellent electrical and optical performance. These results unequivocally confirmed the potential applications of the ELO technique in AlGaN-based devices. 

Additionally, plenty of other approaches have been used to grow high-crystal-quality AlGaN and AlN, such as modulated V/III ratio growth under HT conditions, migration-enhanced epitaxy, modified epitaxy, and ammonia pulse-flow multilayer epitaxy. Table 1 summarizes the recent progress of AlGaN and AlN epitaxial growth. 

AlGaN grown on the LT/HT AlN template is a common epitaxial method due to its simple process. However, the two-step method based on the LT/HT AlN template, which includes the LT/MT/HT three-step method, is macroscopically restricted to the level of crack-free thin films in the early research stage. To improve the crystal quality of high-Al-content AlGaN, other epitaxial methods are suggested to be applied simultaneously. Interlayer modulation and SL structure make a significant sense of blocking threading dislocations by releasing stress and strain. Pulse atomic layer epitaxy and pulse flow multilayer growth also 

contribute to the migration of Al atoms and facilitate the microscopic reduction of threading dislocations. However, concurrently, these methods also proposed higher requirements for epitaxial equipment, which must accurately control the preset gas flux and the thickness of the insert epitaxial layer. The ELO method causes dislocations to bend and annihilate during the epitaxial process. Although this approach is effective, it relies on patterned templates, which inevitably increases the number of epitaxial steps and associated costs. Consequently, various methods can be combined to obtain high-quality AlGaN materials that match different requirements. Currently, the threading dislocation density in AlGaN materials is typically 10<sup>8</sup> –10<sup>10</sup> cm<sup>−2</sup> . The potential and application prospects of AlGaN also must be explored in more detail. 

In addition to improving crystal quality in the preparation of AlGaN materials, doping is another factor that must be considered. The doping level in PDs with p-n or p-i-n structures also plays a decisive role in device performance. In AlGaN materials, n-type doping has become relatively mature. However, efficient p-type doping still faces severe challenges. 

#### High-efficiency p-type doping of AlGaN 

In III-nitride semiconductors, Mg, Zn, and Be elements are typically used for p-type doping<sup>123–125</sup> , and the corresponding activation energies (AE) of the three elements in GaN are 60, 160, and 370 meV<sup>126,127</sup> . All of their AE 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 7 of 31 



<!-- Start of picture text -->
Nanosphere lithography<br>a d<br>AlN (1.3 μm) AlN nanorods<br>Overgrown AlN layer<br>Sapphire substrate Sapphire substrate Sapphire substrate<br>b c<br>3  μ m<br>Sapphire substrate<br>nm<br>e f 10<br>[1–100] 5 0<br>1  μ m 1  μ m [11–20] 5  μ m 2.50 0 2.5 2.5 5 7.5 10 –10<br>µm<br>g h i<br>p -AlGaN<br>i -AlGaN<br>n -AlGaN<br>AlN overgrowth n -GaN<br>AlN overgrowth<br>Ti mask<br>1  μ m GaN-on-sapphire substate<br>AlN nanorods AlGaN:Mg<br>i-AlGaN<br>AlN growth AlN nanorods AlGaN:Si<br>Al(CH3)3 and<br>Sapphire NH3, 1100°C Sapphire<br>Sapphire 1  μ m GaN template 200 nm 20 nm<br>µm<br>AlGaN DH<br>GaN:Si<br><!-- End of picture text -->

Fig. 6 Nanopatterned template for AlGaN/AlN epitaxial lateral overgrowth. a Schematic diagram of silica nanosphere lithography. b, c SEM images of the nano-patterned substrate (NPS). d Cross-section and e plane-view SEM images of the ELO-AlN layer on the NPS. f AFM image shows the macro-steps on the AlN surface. Reprinted with permission from Donghyun et al.<sup>119</sup> . Copyright 2017 American Institute of Physics. g SEM crosssectional image of ELO-AlN nanorod pattern with air gaps. h SEM image of ELO-AlN on sapphire. Reprinted with permission from Conroy et al.<sup>121</sup> . Copyright 2015 The Royal Society of Chemistry. i Coalesced AlGaN nanowire double heterostructure LED, the following two images are crosssectional STM-HAADF image and high-magnification image, respectively. Reprinted with permission from Binh et al.<sup>122</sup> . Copyright 2016 WILEY-VCH Verlag GmbH & Co. KGaA, Weinheim 

increase with the aluminum component in AlGaN alloy. Despite the fact that the AE of Be is lower than that of other elements, it is toxic metal and is more likely to introduce interstitial atoms to compensate acceptors. Therefore, studies commonly use Mg as an impurity acceptor for p-doping of GaN-based materials<sup>128,129</sup> . However, several factors lead to the problems of p-type doping in high-Al-content AlxGa1-xN alloys: (i) the low solubility of acceptor dopants in (Al)GaN<sup>130</sup> ; (ii) the strong self-compensation effect resulting from the donorlike native defects<sup>131</sup> ; and (iii) the high activation energy of the Mg acceptor, which increases from 160 to 500 meV as the Al composition rises (x: 0–1) in AlxGa1-xN<sup>128</sup> . The bottleneck problem of p-type doping has long plagued the developing progress of AlGaN devices. 

To solve the difficulties of p-type doping of AlGaN alloys, researchers have developed a variety of methods to restrain the self-compensation process, increasing the solubility of Mg and reduce the AE of Mg in AlGaN<sup>77,132,133</sup> . These methods include delta (δ) doping, modulation doping, SL doping, codoping, polarizationinduced doping, and multidimensional doping<sup>79,96,134–138</sup> . 

The delta doping method maintains a steady flux of the group-V source (NH3) and alternate Al, Ga, and Mg source supplies so that the Mg source is supplied in an NH3 environment<sup>139–142</sup> . Due to the interruption of the group-III source supply, Mg is likely to combine with Al or Ga vacancies, thereby increasing the doping of Mg substitutional atoms in AlGaN, reducing the self-compensation effect, and improving the incorporation efficiency of Mg atoms. 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 8 of 31 

Table 1 Summary of AlGaN and AlN epitaxial progress 

|Epitaxial material|Thickness (μm)|Methods|XRD FWHM<br>(arc sec)|Dislocation<br>density (cm<sup>−2</sup>)|Comment|Reference|
|---|---|---|---|---|---|---|
|Al0.2Ga0.8N|2|GaN buffer<br>Low temperature (LT)-AlN<br>interlayer with GaN buffer<br>LT-AlN and superlattices<br>(SLs) interlayers with<br>GaN buffer|(0002): 570<br>(20–24): 876<br>(0002): 744<br>(20–24): 1092<br>(0002): 726<br>(20–24): 1014|_<br>6 × 10<sup>9 </sup>(etch pits)<br>4 × 10<sup>9 </sup>(etch pits)|Crack network<br>Several cracks<br>Crack free|Chen et al.<sup>107</sup>|
|||SLs interlayer with<br>GaN buffer|(0002): 384<br>(20–24): 708|2 × 10<sup>9 </sup>(etch pits)|Crack free||
||1.2|Directly on sapphire|(0002): 876<br>(20–24): 1398|7 × 10<sup>9 </sup>(etch pits)|Crack free||
|Al0.2Ga0.8N|3|LT AlN and HT Al0.2Ga0.8N<br>with SLs|(0002): 360<br>(20–24): 690<br>for SLs|_|Crack free|Zhang et al.<sup>106</sup>|
|Al0.55Ga0.45N|1|PALE and SLs|_|Screw: 7 × 10<sup>7</sup><br>Edge: 3 × 10<sup>9</sup>|Dramatically reduce<br>screw-type TD density|Sun et al.<sup>108</sup>|
|Al0.2Ga0.8N|0.2|Plastic relaxation and<br>lateral growth|(0002): <340|5 × 10<sup>8</sup>|Crack free|Bethoux et al.<sup>105</sup>|
|Al0.4Ga0.6N|0.5|Indium-silicon codoping<br>approach|_|_|Crack free, indium<br>counteract with defect<br>incorporation|Adivarahan<br>et al.<sup>97</sup>|
|AlN|>10|ELO|(0002): 300<br>(20–24): 400|<10<sup>7 </sup>(plan-view<br>of TEM)|Crack free|Imura et al.<sup>272</sup>|
|Al0.23Ga0.77N|1.5|GaN interlayer|_|2 × 10<sup>8</sup>|Crack free|Jiang et al.<sup>104</sup>|
|AlN|6|Nanoscaled ELO|_|3.5 × 10<sup>8</sup>|Crack free|Conroy et al.<sup>121</sup>|
|AlN|8.5|ELO on Si(111) substrate|(0002): 960<br>(10–12): 810|_|RMS: 0.12 nm|Cicek et al.<sup>118</sup>|
|Al0.8Ga0.2N on AlN|Al0.8Ga0.2N: 3<br>AlN: 12|ELO-AlN|_|Wing region:<br><10<sup>7</sup><br>Ridge region:<br>6–9 × 10<sup>8</sup>|Achieve effective defect<br>reduction|Mogilatenko<br>et al.<sup>116</sup>|
|Al0.33Ga0.67N on AlN|Al0.33Ga0.67N: 0.82<br>AlN: 5|ELO|(0002): 100<br>(10–12): 500<br>for AlN|_|Crack free|Kueller et al.<sup>117</sup>|
|Al0.8Ga0.2N on AlN|Al0.8Ga0.2N: 1<br>AlN: 5|ELO-AlN|(002): 140<br>(302): 335<br>for AlN|5 × 10<sup>8</sup><br>(plan-view of CL)|0.25° miscut toward<br>a-plane sapphire provide<br>a smooth surface|Zeimer et al.<sup>273</sup>|
|AlN|5.2|Nanoscaled ELO|(0002): 186<br>(10–12): 432|_|Crack free|Donghyun<br>et al.<sup>119</sup>|
|Al0.1Ga0.9N|3|Nano-patterned sapphire<br>substrate (NPSS) ELO|_|1–2 × 10<sup>9</sup>|Annihilation of TDs is<br>related to stacking faults|Tasi et al.<sup>274</sup>|



Cai et al. Light: Science & Applications (2021) 10:94 

Page 9 of 31 



<!-- Start of picture text -->
Temperature (K)<br>a 10 20 10 23 b 10 20 10 23 c 310 300 290 280 270 260 250 240<br>Mg δ-doping w/o In 10 22 Mg δ-doping with In 10 22 10 19<br>10 19 10 21 10 19 10 21<br>Mg Mg<br>10 20 10 20 10 18<br>10 18 10 19 10 18 In 10 19<br>In 10 18 10 18 10 17 Mg Mg δδ-doping with In-doping w/o In<br>10 17 10 17 10 17 10 17<br>0 50 100 150 200 250 300 350 400 0 50 100 150 200 250 300 350 400 0.0032 0.0034 0.0036 0.0038 0.0040 0.0042<br>Depth (nm) Depth (nm) 1/ T  (K –1 )<br>d 10 18 96 ×1032 18 e 0.10<br>1010 1614 32806448 24168 AIN peak 0.05<br>30 40 50 60 70 80 90 100<br>10 12 Depth (nm) EF<br>10 10 δ-doping with In 0.00<br>10 8<br>–0.05<br>10 6 δ-doping w/o In<br>10 4 –0.10 δ-doping w/o In<br>10 2 Uniform-doping δ-doping with In<br>10 0<br>33 34 35 36 37 –0.1579 80 81 82 83 84<br>(0002) 2θ-ω (degree) Depth (nm)<br>E A =38 meV,  C =62%<br>E A =46 meV,  C =79%<br>–3Mg concentration (cm) –3In concentration (cm) –3Mg concentration (cm) –3In concentration (cm) –3Hole concentration (cm)<br>Al comp. (%) –3Mg conc. (cm)<br>Energy (eV)<br>XRD intensity (arb. unit)<br><!-- End of picture text -->

Fig. 7 Mg-δ-doped AlGaN layers with and without In surfactant. a, b Mg and In concentration depth profiles. c Temperature-dependent hole concentrations. The solid lines are fitting curves. d HRXRD (0002) 2θ-ω scan curves. The inset presents the Al-content and Mg concentration depth profiles in the In-surfactant-assisted sample. e Calculated self-consistent valence band diagrams at the quantum-well and graded-barrier interface, as a result of Mg-δ-doping. Reprinted with permission from Jiang et al.<sup>76</sup> . Copyright 2015 AIP Publishing LLC 

The SL doping method uses energy band engineering to reduce the AE of Mg acceptor impurities<sup>143–149</sup> . In the IIInitride heterostructure, the polarization effect caused by lattice mismatch will generate a polarized electric field, which will cause the energy band near the interface to bend, thereby reducing the acceptor impurities near the interface. It is beneficial to increase the activation efficiency of Mg acceptors and improve the conductivity of p-type materials. 

Based on the delta doping technique, Jiang et al.<sup>76</sup> proposed an indium-surfactant-assisted method to achieve a high concentration of holes in Al0.4Ga0.6N. Figure 7a, b shows the depth profiles of Mg and In concentrations in Mg-δ-doped AlGaN layers. With In surfactant assistance, the average Mg concentration was improved from 1.1 × 10<sup>19</sup> to 1.3 × 10<sup>19</sup> cm<sup>−3</sup> . Indium desorption produces more vacancies, which promotes Mg occupation and contributes to the incorporation of Mg in the δ-doping process. 

Figure 7c shows the dependent relation between hole concentration (HC) and temperature. The HC is expressed as the formula 



<!-- Start of picture text -->
1 � C Nv EA<br>H ¼ ð1Þ<br>C g exp � � kT �<br><!-- End of picture text -->

where H is the HC, C = ND/NA is the compensation ratio, Nv = 2(2πmp*kT)3/2h−3 is the effective valence band state 

density, g is the acceptor degeneracy factor, and EA is the acceptor activation energy. After fitting the curves in Fig. 7c, the compensation ratio C was found to be obtained of 62% for the In-surfactant sample and 79% for the other sample without the In surfactant. The reduction in the compensation ratio can be attributed to the suppression of nitrogen vacancies (VNs) through the introduction of indium. The activation energy EA also decreased from 46 to 38 meV with indium surfactant. 

As the HDXRD and SIMS (inset) measurements in Fig. 7d show, satellite peaks present the different Al compositions in the epitaxial samples, indicating the selfformed quantum-well (QW) and graded-barrier (GB) heterostructure. Figure 7e presents the calculated valence band diagram of the QW and GB interface. Holes will accumulate at the interface near the Fermi level, thus forming a two-dimensional hole gas (2DHG). In the indium-surfactant-assisted sample, larger interfacial band bending promotes the formation and accumulation of 2DHG holes. Consequently, with enhancement produced by Mg, the suppression of the compensation centers, and the 2DHG incrementation, a high concentration of holes (4.75 × 10<sup>18</sup> cm<sup>−3</sup> ) was achieved along with a low sheet resistivity of 2.46 × 10<sup>4</sup> Ω/sq for the Al0.4Ga0.6N epilayer. 

Additionally, Simon et al.<sup>150</sup> proposed an AlGaN heterostructure with graded Al composition and achieved polarization-induced p-type doping of AlGaN for the first time. They grew AlGaN with a graded Al composition on 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 10 of 31 



<!-- Start of picture text -->
Electron blocking<br>Electron blocking GaN QWs<br>GaN QWs<br>Ec Ec<br>Efn Efn<br>Graded<br>p-AlGaN R<br>a 0-30% b<br>Ev Ev<br>No Hole<br>Hole blocking<br>N-face blocking<br>Electron injection Electron injection<br>Ec Ec<br>Opposing field Efn Assisting field Efn<br>Ec Ec<br>Efn Efn<br>GaN QWs GaN QWs<br>c d<br>Ga-face N-face<br>Efp<br>Efp<br>Ev<br>Ev<br>EBL: 15% p-AlGaN<br>p-15% AlGaN p-15% AlGaN<br><!-- End of picture text -->

Fig. 8 Energy band diagrams of GaN/Al0.15Ga0.85N MQW. a LED of N-polar QW with traditional electron blocking layer and b with graded p-AlGaN (polarization-induced p-doping). c LED of Ga-face QW: polarization fields oppose electron injection. d LED of N-face QW: polarization fields assist carrier injection. Reprinted with permission from Verma et al.<sup>151</sup> . Copyright 2011 American Institute of Physics 

AlN. Because the net charge on the AlN/AlGaN interface induced by polarization is negative, mobile holes can be introduced in the graded AlGaN layer, which is similar to p-type doping. A p-type doped AlGaN alloy with a HC exceeding 2 × 10<sup>18</sup> cm<sup>−3</sup> and resistivity of 0.6 Ω cm was achieved. They also employed polarization-induced p- type doping in an N-polar III-nitride QW UV LED<sup>151</sup> . As shown in Fig. 8b, when acting as an electron blocking layer, the polarization-induced p-doped layer removes the energy barriers for holes more effectively than a traditional layer (Fig. 8a). Also, the N-polar structure also facilitates carrier transport in the QWs, as shown in Fig. 8c, d. Thus, polarization-induced p-type doping potentially facilitates higher performance of in AlGaNbased devices. 

Other methods have also been reported for improving p-doping efficiency. Kang et al.<sup>137</sup> proposed a new multidimensional Mg SL doping method to improve the vertical conductivity of AlGaN materials. They calculated the density of states along the [0001] direction of the nondoped and Mg-doped structures via first-principles analysis and found that three-dimensional SL Mg doping reduced the hole barrier and increased the HC in the barrier region, which resulted from the strong Pz hybridization between Mg and N. According to the theoretical 

results, they prepared an Al0.63Ga0.37N/Al0.51Ga0.49N SL structure and obtained high-efficiency p-type doping, with an HC of 3.5 × 10<sup>18</sup> cm<sup>−3</sup> and a low resistivity of 0.7 Ω cm. Alternative Mg and Si codoping methods have been also proposed for p-channel device fabrication. Recent results of AlGaN p-type doping are summarized in Table 2. 

In our opinion, doping methods can be divided into two types: structure-induced and impurity-intervention. Polarization-induced doping and SL doping use energyband engineering to modulate holes, thus leading to effective p-type doping. These typical structure-induced doping methods mitigate the demand on activating acceptor impurities. However, these methods can only be applied with specific structures. Impurity-intervention doping is easier to control in epitaxial processes, such as In-surfactant-assisted Mg-δ-doping, V/III ratio modulation doping, and alternative codoping. The ultimate goal of these methods is to reduce the activation energy of the acceptor (EA) and improve doping efficiency. Existing doping methods can increase the HC of AlGaN to 10<sup>18</sup> . Additionally, we must consider the influence of impurity incorporation on the quality of AlGaN alloys. In terms of the subsequent PDs, impurity scattering is also a significant factor that impacts the device performance. 

Thus, with the development of epitaxy and doping technology, the crystalline quality and doping level of AlGaN materials are continuously improved, which is conducive to improving the performance of fabricated devices. In addition to the material itself, a variety of PD structures also exhibit great differences in performance, which will be discussed in the next section. 

### AlGaN-based solar-blind UV PDs 

To date, the research goal of UV PDs has been to obtain devices with low dark current, high responsivity, and large bandwidth. Due to their large and tunable bandgap, good thermal conductivity, high carrier mobility, and superior physical and chemical stability of AlxGa1-xN materials, solar-blind UV detection technologies based on AlxGa1-xN materials have become a domestic hotspot of extensive research<sup>51,152–155</sup> . Herein, we focus on the structures and properties of the various types of AlGaN solar-blind PDs. 

#### Photoconductors 

Photoconductors have attracted considerable attention for a long time due to their simple fabrication process, high responsivity, low cost merits, and the fact that they can be used in flame and fire monitoring applications<sup>156–158</sup> . The work of photoconductive devices is based on changes in electrical conductivity caused by light excitation. However, due to defects, the photoconductive effect in GaN and AlGaN is typically associated with a slow response speed, low-energy photon response, and severe temperature dependence. Defects in the material trap 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 11 of 31 

|Reference|Jiang et al.76||Simon et al.150|Kang et al.136||Peter et al.96|Li et al.275||Nakarmi et al.134|Kinoshita et al.78|Jeon et al.124||Waldron et al.276||Kishimoto|et al.277|Aoyagi et al.278||Kawanishi<br>et al.279|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|T<br>Comment|Enhance Mg incorporation, reduce|compensation ratio and EA|Robust to thermal freezeout effects|Enhance vertical hole conductivity in|Al-rich structure|Confined hole gas due to valence band<br>|bending<br>Impurity free||High vertical conductance, terminate|dislocation propagation<br>Suppress self-compensation, reduce EA|Narrow optimal window for Mg doping,|excessive Mg incorporation causes defects|Reduction of neutral impurity scattering|improvesmobility|<br>AlC as hole injection layer||Promote development of p-channel|di|evces<br>Potential of carbon acceptors in AlGaN|
|Hole Mobility<br>(cm2V−1s−1) at R|1.34||15|2.6||_|_||5|_|2.7||9.2||30||1||0.4|
|Resistivity<br>(Ωcm) at RT|Sheet Resistivity:|2.46 × 104 (Ω/sq)|1|0.7||0.2|_||0.6|47|10||0.2||Sheet Resistivity:|2 × 104 (Ω/sq)|0.99||20|
|Hole Concentration<br>(cm−3) at RT|4.75 × 1018||1.5 × 1018|3.5 × 1018||2.5 × 1018|~1018||2 × 1018|2 × 1017|2.2 × 1017||3.4 × 1018||Sheet carrier density:|1013 (cm−2)|6.3 × 1018||3.2 × 1018|
||Mg-δ-||doping|-doping|||doping|||doping|||||AlGaN|||||
|Technique|In-surfactant-assisted|doping|Polarization-induced|Multidimensional Mg||Superlattice doping|Polarization-induced||Mg-δ-doping|V/III ratio modulation|Mg-doping||Modulation-doping||Al/C3H8 treatment of|template|Alternative codoping||C-doping|
|ial|0.6N||d AlGaN|a0.37N/|a0.49N SLs|0.8N/GaN SLs|d AlxGa1-xN|0.3)|a0.93N|0.3N|0.5N||0.8N/GaN SLs||Al0.8Ga0.2N||0.6N||0.9N|
|Mater|Al0.4Ga||Grade|Al0.63G|Al0.51G|Al0.2Ga|Grade|(x: 0 ~|Al0.07G|Al0.7Ga|Al0.5Ga||Al0.2Ga||AlC on||Al0.4Ga||Al0.1Ga|



Cai et al. Light: Science & Applications (2021) 10:94 

Page 12 of 31 



<!-- Start of picture text -->
a Front illumination b 10 0 10 –3 c<br>1<br>Ti/Al Ti/Al 10 –1 2 1<br>AI0.51Ga0.49N Eg~4.6 eV 10 –4 3<br>(Detector) 250 nm<br>AIN insulator layer Eg~6.2 eV 10 –2 2.1<br>200 nm<br>Energy [eV] 0.1<br>Eg~4.8 eV 10 –3<br>Al0.67Ga0.33N (filter) 200 nm 10 –3<br>10 –5<br>AIN nucleation layer Eg~6.2 eV<br>40 nm 10 –4 10 –8<br>c-Al2O3 0.01 –30 0 30<br>10 –5 Vopt Bias [V]<br>1.5 2.5 3.5 4.5 5.5 1 10 100<br>Back illumination<br>Energy [eV] Voltage [V]<br>d e f<br>light on<br>light on (hν=4.8 eV)<br>10 2<br>1<br>light off 2<br>light off<br>10 1<br>10 0<br>light on (hν=3.8 eV)<br>0.1<br>10 –1<br>light off<br>light off 1<br>10 –2<br>0 1000 2000 0 1000 2000 2 3 4 5<br>Time [sec] Time [sec] Photon energy [eV]<br>Responsivity [A/W] Responsivity [A/W] l [mA]<br>Photocurrent [a.u.]<br> [sec]Time response, τ<br>Normalized photocurrent [a.u.]<br><!-- End of picture text -->

Fig. 9 Structure and performance of an AlGaN solar-blind photoconductor. a Schematic structure of AlGaN photodetector. b Spectral responsivity of the AlGaN detector at back-illumination under 5 V bias. The insert illustrates the photocurrent resonance peak, measured at 5 V (curve 1), 12 V (curve 2), and 15 V (curve 3), respectively. c Spectral responsivity versus applied voltage (hν ~ 4.8 eV). The inset presents the dark current. Vopt is the trap-free point (6 V). d Time response (hν ~ 4.8 eV) at 5 V (dark circles) and 15 V (green triangles). e Time response at 5 V (trap-free regime) with 4.8 eV photon (squares) and 3.8 eV photon (triangles). f Time constant versus photon energy at 5 V. Reprinted with permission from Cherkashinin et al.<sup>55</sup> . Copyright 2006 WILEY-VCH Verlag GmbH & Co. KGaA, Weinheim 

carriers. Long-term hole trapping causes the minimum hole recombination time to be much higher than the electron transit time, and the charge collection rate is higher than the charge generation rate, which is also the primary reason for the formation of photoconductive gain. The switching speed of the PDs relies on the minority lifetime of the carriers: the longer the minority carrier lifetime is, the higher the gain but also, the lower the switching speed<sup>159–163</sup> . Therefore, a trade-off between gain and speed must be considered. Additionally, the existence of defect energy levels can also cause a lowenergy photon response. The defect-related carrier capture and release mechanism is also fed back to the frequency characteristics of the device. For example, the outof-band response is higher at low frequencies. 

The first GaN-based PD implemented by Khan et al.<sup>164</sup> is a photoconductive detector. Only two metals must be deposited onto the GaN film for ohmic contact. However, the shortcomings of this PD also include a slow response 

speed and large leakage currents. In addition, solar-blind detection requires using AlGaN materials. 

In 2004, Lebedev et al.<sup>157</sup> fabricated a photoconductive solar-blind Al0.51Ga0.49N detector with an Al0.67Ga0.33N integrated filter and obtained a high solar-blind responsivity with a narrow wavelength range, verifying the functionality of the filter. They also confirmed that defect states will lead to subband and near-bandgap absorption in AlGaN optoelectronic detectors. In 2006, they also studied the responsivity and time response of AlGaN solar-blind photoconductors. Figure 9a shows the schematic structure of the AlGaN detector. As shown in Fig. 9b, the PD achieves a spectral detection range from 220 to 300 nm. Additionally, the photocurrent peaks in the inset of Fig. 9b can be attributed to the transition between the localized deep acceptor state and shallow donor state<sup>152</sup> . Notably, there are two response shoulders in Fig. 9c, indicating the effects of traps on the photoconductivity. The onset drop of the photoresponse at 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 13 of 31 

Vopt (6 V) can be attributed to excess trapped carrier density. At higher voltage, the free carrier density is sufficiently large to neglect the trapping effect. Also, the effect of trapping on the photoconductivity increases the decay time. Figure 9d shows the time response characteristics of the PD at low (5 V) and high (15 V) voltages. With a 15-V bias, the device exhibits a significant defectrelated persistence photoconductivity (PCC) effect. Conversely, when the bias is lower than 7 V, no marked PCC effects are observed. The characteristic time constant (τ) can be extracted from the following expression: 



<!-- Start of picture text -->
t<br>IðtÞ ¼ I0 þ B0 exp � ð2Þ<br>� ��τ β�<br><!-- End of picture text -->

where I0 is the preliminary dark current, B0 is the exponential term, and β is the decay exponent. For the 5-V and 15-V curves, τ is 0.03 and 0.7 s, respectively. However, PCC effects also occur in the trap-free regime (bias <7 V) when the photon energy is 3.8 eV, as shown in Fig. 9e. The time constant τ increases with decreasing photon energy (see Fig. 9f) and becomes independent at the lower bias value (<6 V). They concluded that there is an optimal parameter (6 V) to achieve a compromise between the response time and spectral responsivity. The trapping of space charges accounts for the increase of decay time. 

#### Schottky barrier photodiodes 

The structure and fabrication process of AlGaN-based Schottky detectors are relatively simple and consist of a Schottky contact metal and an ohmic contact metal. The photoelectric response speed is fast, and the response time is on the order of ns. But the response speed is restricted by the RC time constant. Among the various available detectors, the Schottky detector has the widest flat-band response window in a short wavelength region, which is suitable for manufacturing detectors and arrays. Its responsivity is near 0.1 A/W at zero bias<sup>165,166</sup> and the response ratio of UV to visible light is typically in the range of 10<sup>3</sup> to 10<sup>4</sup> . 

In 1998, Osinsky et al.<sup>167</sup> reported the first AlGaN Schottky solar-blind UV photodiode, which exhibits a response of 70 mA/W at 272 nm at 0 V, with an external quantum efficiency (EQE) of 32%. The fabricated AlGaN Schottky detector exhibits superior solar-blind characteristics, and the UV/visible rejection ratio reaches 10<sup>4</sup> . 

Miyake et al. proposed front-illuminated solar-blind AlGaN Schottky PDs on a large scale<sup>168</sup> . The fabricated devices operated at wavelengths of 100–265 nm. The UV/ visible rejection ratio is ~10<sup>4</sup> . The manufactured AlGaNbased solar-blind detectors could be employed for the VUV detection. Additionally, Biyikli et al. produced a lownoise and high-detectivity Schottky photodiode for solar- 

blind UV detection<sup>169</sup> . AlGaN/GaN heterostructures were used to achieve better ohmic contact. The cutoff wavelength was located at 274 nm, corresponding to the Al content of AlGaN absorption layer. The proposed devices exhibited a low dark current density of 1.8 nA/cm<sup>2</sup> in the bias range of 0–25 V. The PD exhibited a maximum EQE of 42% at 267 nm. Moreover, the device exhibited a high detectivity, which exceeded 2.6 × 10<sup>12</sup> cm Hz<sup>1/2</sup> W<sup>−1</sup> , and a low noise power density below 3 × 10<sup>−29</sup> A<sup>2</sup> /Hz at 10 kHz. 

Sang et al.<sup>166</sup> proposed an AlGaN-based solar-blind PD (Fig. 10a, b) with back illumination and used Ni/Pt Schottky contacts to reduce the leakage current. Figure 10b shows that the device exhibits a significant peak at 289 nm. One of the major merits of Schottky detectors is their fast response speed. Biyikli also proposed an indiumtin-oxide (ITO) Schottky PD with a high response speed (3-dB bandwidth: 1.10 GHz). Also, high bandwidthefficiency AlGaN Schottky photodiodes were demonstrated by Tut et al.<sup>169</sup> . As shown in Fig. 10c, the fabricated device produced an extremely low dark current at the level of 3 fA when the applied voltage was lower than 12 V. The solar-blind cutoff edge was ~266 nm, as shown in Fig. 10d. At an applied voltage of 20 V, they obtained a peak responsivity of 147 mA/W at 256 nm with rejection ratio in excess of four orders of magnitude. Also, the device with a diameter of 30 μm achieved a 53-ps pulsewidth and a 4.1-GHz BW, which are extracted from Fig. 10e, f. The fabricated AlGaN Schottky photodiode obtained a BW-efficient product of 2.9 GHz, demonstrating the device’s superior response speed performance. 

#### Schottky metal–semiconductor–metal PDs 

A metal–semiconductor–metal (MSM) PD is composed of two back-to-back Schottky diodes and has the advantages of a simple structure and manufacturing process, a low dark current, a fast response, and an easy planar integration. The RC time constant can be reduced by controlling the electrode spacing of the interdigital structure, which is suitable for high-speed photoelectric conversion applications<sup>170–174</sup> . 

In 1997, Carrano et al.<sup>175</sup> reported that a Schottky GaN UV detector with an MSM structure had a dark current of 57 pA at 10 V and achieved a 0.4 A/W responsivity under a bias of 6 V. In 1999, Monroy et al.<sup>176</sup> reported n-type and p-type MSM structure GaN UV detectors with response times of 10 and 200 ns, respectively. In 2004, Li et al.<sup>177</sup> reported an MSM-structured GaN UV PD with a response time of 4.9 ps. Several research groups have reported on AlGaN solar-blind UV detectors with frontor back- illuminated MSM structures<sup>178–181</sup> . 

Xie et al. fabricated an AlGaN MSM solar-blind UV detector with an ultralow dark current based on HT-AlN epitaxy<sup>182</sup> . At room temperature and at 150 °C, its dark 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 14 of 31 



<!-- Start of picture text -->
a c e<br>Ni/Pt-schottky contact 80<br>Ti/Al/Ti/Pt Ti/Al/Ti/Pt 25 V<br>ohmic contact ohmic contact 10 –11 5<br>i -AI0.47Ga0.53N 60 10 –12 4 5 V10 V<br>n -AI0.52Ga0.48N 40 10 –13 15 V20 V<br>10 –14 3 25 V<br>AIN(5nm)/AlGan(5nm)SLsAIN(320nm) 20 10 –15 –40 –35 –30 –25 –20 –15 –10 –5 0 5 2<br>Voltage (V) 5V<br>Sapphire 0 1<br>(a)<br>0<br>–35 –30 –25 –20 –15 –10 –5 0 5 100 200 300 400 500<br>Voltage (V) Time (ps)<br>b d 0.16 f<br>0.03<br>10 0<br>5 V<br>0.12 10 V<br>0.02 15 V<br>26 mA/W @289nm UV/V  = 1000 0.08 20 V25 V 5 V10 V20 V<br>0.01 Bias= 0V 25 V<br>0.04 (b)<br>10 –1<br>0.00 (a)<br>250 300 350 400 450 500 0.00 260 280 300 320 10 2 10 3 10 4<br>Wavelength (nm)<br>Wavelength (nm) Frequency (MHz)<br>Fig. 10 Structure and performance of AlGaN Schottky barrier photodiodes. a Schematic structure of Schottky AlGaN photodetector.<br>b Responsivity of the fabricated device at 0 V. Reprinted with permission from Sang et al. 166 . Copyright 2008 Chinese Physical Society and IOP<br>Publishing Ltd. c Dark current of the fabricated AlGaN photodetector. d Responsivity of the devices at different applied voltages. e Pulse response of<br>the devices at different applied voltages. f Corresponding fast Fourier transform curves. Reprinted with permission from Tut et al. 169 . Copyright 2004<br>Elsevier Ltd<br>a 10 –8 b 10 0 Q.E=100% c 10 0 Q.E=100%<br>10 –9 Ni/AuUlD AlGaN (0.3 5  μ m μ m)Ni/Au 10 –1 Q.E=25%Q.E=5% 10 –1 Q.E=25%<br>10 –10 AlN (0.5  μ m) 10 –2 10 –2 Q.E=5%<br>Dark current (RT) Sapphire substrate 2 V 2 V<br>10 –11 10 –3 4 V 4 V<br>10 –12 Dark current (150 °C)Photocurrent (RT) 10 –4 6 V8 V 1010 –3–4 6 V8 V<br>10 –13 Photocurrent (150 °C) 10 –5 10 V 10 V<br>10 –5<br>10 –14 10 –6<br>10 –15 10 –7 10 –6<br>RT 150 °C<br>10 –16 10 –8 10 –7<br>0 5 10 15 20 250 300 350 400 450 250 300 350 400 450<br>Voltage (V) Wavelength (nm) Wavelength (nm)<br>Fig. 11 Structure and performance of a Schottky metal-semiconductor-metal photodetector. a I-V curves of the MSM detectors measured in<br>dark and under 254 nm UV illumination at RT and 150 °C conditions, respectively. Spectral response of the devices measured at b RT and c 150 °C.<br>Reprinted with permission from Xie et al. 182 . Copyright 2012 IEEE<br>Current (pA) Current (A) Voltage (mV)<br>Responsivity (A/W) Responsivity (A/W)<br>Normalized response<br>Current (A)<br>Responsivity (A/W) Responsivity (A/W)<br><!-- End of picture text -->

current remains in the fA order of magnitude, as shown in Fig. 11a. The device has a room temperature EQE of 64% (at 275 nm) at applied voltage of 10 V, and the solar-blind UV/near UV rejection ratio reaches 10<sup>4</sup> (Fig. 11b). The EQE of the device remains above 50% even at 150 °C, and the UV/visible rejection ratio exceeds 8000, as shown in Fig. 11c. These results also confirmed that the AlGaN solar-blind detectors can withstand higher operating temperatures. 

Using the MSM structure, researchers have proposed various methods to increase device performance<sup>183–185</sup> . Nanoplasmonic enhancement can be employed on the solar-blind photodetector<sup>186</sup> . Li et al.<sup>187</sup> demonstrated that Al nanoparticles enhanced the responsivity of an AlGaN MSM solar-blind detector, as shown in Fig. 12a, c. By investigating the electric field distribution of Al nanoparticles (seen in Fig. 12b), they found that the localized surface plasmon resonance effects contributed 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 15 of 31 



<!-- Start of picture text -->
a c e<br>10 –7<br>Ni Al 0.300.25 @5V 20 nm AI40 nm AI60 nm AI 10 –8 Conventional MSMMSM with LT-AIN cap layerMSM with LT-AIN and recessed electrodes<br>W/O AI<br>10 –9<br>AlGaN 0.20<br>Sapphire 0.15 10 –10<br>b 0.10 10 –11<br>0.05 10 –12<br>Max<br>0.00 10 –13<br>240 260 280 300 320 340 0 1 2 3 4 5<br>Wavelength (nm) Bias voltage (V)<br>E g =10 nm Ni/Au (3 nm/6 nm)<br>d f<br>Conventional MSM<br>10 0 MSM with LT-AIN cap layer<br>MSM with LT-AIN and ICP recessed electrodes<br>200 nm AlGaN epilayer 10 –1<br>E g =20 nm<br>LT-AlN (20 nm) 1 µm GaN epilayer 10 –2<br>GaN buffer layer 10 –3<br>at 300 W Xe arc lamp<br>Sapphire substrate 10 –4 and a calibrated monochromator<br>Min<br>E g =40 nm 300 350 400<br>Wavelength (nm)<br>Current (A)<br>Responsivity (A/W)<br>Responsivity (A/W)<br><!-- End of picture text -->

Fig. 12 Performance improvement methods on AlGaN MSM photodetectors. a Schematic structure of AlGaN MSM photodetector with Al nanoparticles. b Electric field distribution of Al nanoparticles with changing gaps. c Responsivity of devices with and without Al nanoparticles. Reprinted with permission from Li et al.<sup>187</sup> . Copyright 2014 Optical Society of America. d Schematic structure of AlGaN with low-temperature AlN cap layer and recessed electrodes. e Dark current curves of the three samples. f Spectral response of the three samples. Reprinted with permission from Chen et al.<sup>188</sup> . Copyright 2010 The Japan Society of Applied Physics 

to the enhancement in responsivity of the MSM detectors. Chen et al.<sup>188</sup> also fabricated an MSM AlGaN PD with a low-temperature (LT) AlN layer and recessed electrode structure, as shown in Fig. 12d. The improved structure shows a lower dark current than the conventional structure in Fig. 12e. Highly resistive LT-AlN provides a higher potential barrier. Figure 12f shows that the LT-AlN and a recessed electrode structure yield a higher responsivity, which can be ascribed to the enhanced electric field intensity between electrodes and higher photoconductive gain. Additionally, polarization engineering can also be used to enhance the performance of AlGaN solar-blind detectors by introducing high electron mobility conduction channel<sup>189,190</sup> . 

#### p-n, p-i-n photodiodes 

Most p-n or p-i-n junction detectors exhibit have many advantages, including a low working bias, a high input impedance, a high working frequency, and an integration capability that is useful for manufacturing technologies and semiconductor planar processes<sup>191–194</sup> . Unlike the p-n junction, the width of the space charge region in the p-i-n structure does not depend on the p-n junction electric field, but is primarily determined by the thickness of the i-type layer. Therefore, the design of the thickness 

in an unintentionally-doped (i-type) layer is important. A thick i-type layer can ensure sufficient light absorption to improve the quantum efficiency of the detector, which facilitates reducing the junction capacitance and the RC time constant. However, this layer will concurrently increase the transit time of photogenerated carriers and reduce the response speed of the detector. Hence, it is necessary to compromise the design according to demands of real applications. 

In 1999, Parish et al.<sup>195</sup> prepared a p-i-n structure AlGaN solar-blind UV detector on a laterally epitaxial GaN template. Its peak response was 0.05 A/W at 285 nm, and the dark current density was 10 nA/cm<sup>2</sup> , and the response time was extremely low (4.5 ns). Biyikli et al.<sup>196</sup> employed a recessed etching process on the p<sup>+</sup> -GaN cap layer in a p-i-n structure AlGaN solar-blind UV detector. The dark current of the fabricated device was as low as 3 fA under a 6-V bias, and the detectivity reached 4.9 × 10<sup>14</sup> cm Hz<sup>1/2</sup> W<sup>−1</sup> . Collins et al.<sup>197</sup> used high-Al-content n-Al0.6Ga0.4N as the optical window layer in the p-i-n structure AlGaN detector to enhance the light transmission to the AlGaN solar-blind absorption region, and obtained a detectivity up to 2.0 × 10<sup>14</sup> cm Hz<sup>1/2</sup> W<sup>−1</sup> . Researchers at Northwestern University adopted a high-Al-content p-Al0.7Ga0.3N as the optical 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 16 of 31 



<!-- Start of picture text -->
a b c<br>p- GaN (100 nm) : 2.1×10 18  cm –3<br>p- Al0.38Ga0.62N (50 nm) : 2.4×10 16  cm –3 10 –4 Area = 729 Rseries = 700  μΩ m 2 100 Bias : –5 VBias : –4 V<br>i- Al0.4Ga0.6N (200 nm) 10 –6 η ideality = 2.4 10 Bias : –3 VBias : –2 V<br>n- Al0.45Ga0.55N (35 nm) : –7.21×10 17  cm –3 Bias : –1 V<br>10 –8 Bias : 0 V<br>n + - Al0.5Ga0.5N (600 nm) : –4.41×10 18  cm –3 1<br>10 –10<br>0.1<br>AIN (600 nm) 10 –12<br>LT–AIN buffer 10 –14<br>–10 –5 0 5 10 250 300 350 400 450<br>Sapphire (0.01)<br>Voltage (V) Wavelength (nm)<br>d Ni/Au e f<br>10 –8 10 0<br>P-GaN~50 nm SiO2 Photocurrent 60 0 V<br>Graded N-AlGaN(Al:0.60-0.45)~20 nmGraded P-AlGaN(Al:0.45-0)~20 nmI-AlP-Al0.450.45GaGa0.550.55N~150 nmN~80 nm Ti/Al/Ni/Au 1010 –10–9 Dark current 150 °CRT150 °C 101010 –1–2–3 504030201010 –1 V–2 V–3 V–4 V–5 V<br>10 –11 250 260 270 280 290 300<br>N-Al0.60Ga0.40N~600 nm 10 –4 Wavelength (nm)<br>0 V<br>–1 V<br>Al0.60GaAIN ~400 nm0.40N/AIN~400 nm 10 –12 RT 10 –5 –2 V–3 V–4 V<br>Sapphire substrate 10 –13 10 –6 –5 V<br>Backside illuminated 0 1 2 3 4 5 250 300 350 400 450<br>Voltage (V) Wavelength (nm)<br>80 °C 120 °C<br>Current (A)<br>Responsivity (mA/W)<br>Quantum efficiency (%)<br>Current (A)<br>Responsivity (A/W)<br><!-- End of picture text -->

Fig. 13 Structures and performance of AlGaN p-i-n photodiodes. a Schematic cross-sectional structure of p-i-n AlGaN photodetector. b I-V curves of ten devices on the same wafer. Turn-on voltage is 5.6 V. The label shows series resistance and ideality factor. c Responsivity at different reverse biases. 176 mA/W under zero bias and 192 mA/W at 5 V. Reprinted with permission from Cicek et al.<sup>199</sup> . Copyright 2013 AIP Publishing LLC. d Schematic cross-sectional structure of the photodetector. e I-V curves at different temperatures. f Responsivity at various biases. The inset illustrates quantum efficiency in the wavelength range from 250 to 300 nm. Reprinted with permission from Wang et al.<sup>200</sup> . Copyright 2012 Chinese Physical Society and IOP Publishing Ltd 

window layer in AlGaN p-i-n detector and obtained a response peak (at 262 nm) of 0.20 A/W at zero bias. The UV/visible rejection ratio reached 10<sup>6198</sup> . In 2013, Cicek et al.<sup>199</sup> used a Si-In codoped Al0.5Ga0.5N window layer and a high-quality AlN template to prepare a backilluminated p-i-n structure AlGaN solar-blind UV detector, as shown in Fig. 13a–c. An EQE of 80% at 275 nm was obtained at zero bias, and an EQE of 89% was achieved at a 5-V applied voltage. The UV/visible light rejection ratio exceeded six orders of magnitude. Multisample measurements verified the uniformity of the device performance. 

When manufacturing AlGaN solar-blind UV detectors, HT-AlN buffer layers and AlN/AlGaN SL structures are often used to suppress the accumulation of tensile strain in the epitaxial process of the AlGaN layer and reduce the dislocation density of the AlGaN layer. The research team of Nanjing University used this method to prepare a p-i-n structure AlGaN solar-blind UV detector<sup>200</sup> , as shown in Fig. 13d–f. The leakage current was as low as 1.8 pA, and the peak quantum efficiency reached 64%. The temperature dependent I-V curve shows that the dark current increases marginally with increasing temperature, which can be attributed to defect-related parasitic leakage<sup>201</sup> . 

However, the dark current remains on the order of 10 pA. The thermal-noise-limited detectivity reaches 3.3 × 10<sup>13</sup> cm Hz<sup>1/2</sup> W<sup>−1</sup> . 

#### Avalanche photodiodes 

APDs can obtain gain via the impact ionization process of carriers under breakdown conditions so that they can detect weak UV signals<sup>156,202–206</sup> . The APD exhibits two modes: linear and Geiger. When avalanche breakdown occurs and the device achieves a large multiplication gain, the device works in Geiger mode, which plays a significant role in the field of single-photon detection<sup>207–211</sup> . The multiplication factor can be extracted from the following formula 



<!-- Start of picture text -->
1<br>M ¼ ð3Þ<br>1 � R L0 α ð x Þdx<br><!-- End of picture text -->

where L is the movement length and α is the multiplication coefficient of carriers. The impact ionization coefficient is related to the material itself (Al content in AlxGa1-xN) and to external factors such as electric field intensity, temperature, etc. Experimentally, the relationship between the multiplication gain and current–voltage 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 17 of 31 

can be expressed as 



<!-- Start of picture text -->
G ¼ IM light � IM dark ð4Þ<br>I0 light � I0 dark<br><!-- End of picture text -->

where IM and I0 are the multiplied and unmultiplied currents, respectively<sup>203,212,213</sup> . 

The APD that has been reported so far includes the various structures discussed above, including Schottky, p- n, and p-i-n structures. In particular, a separate absorption and multiplication (SAM) structure has also been proposed to enhance device performance. In the absorption region of the SAM structure, the photogenerated carriers are separated by the bias voltage. The single type of carrier is accelerated into the multiplication region through the electric field, thereby causing massive impact ionization and triggering avalanche events. This singlecarrier triggering avalanche mechanism can reduce the excess noise of the device<sup>214,215</sup> . Considering the materials used in APDs, high-Al-content AlGaN APDs are typically prepared on AlN/sapphire templates, and the material quality and performance of the fabricated devices are better than those used on GaN templates. 

Currently, UV GaN APDs<sup>216,217</sup> have made great progress and achieved single photon detection with multiplication gain exceeding 10<sup>5</sup> . However, AlGaN-based solar-blind APDs are rarely reported<sup>218–221</sup> and the development of the AlGaN APD marginally lags behind that of GaN. The primary reasons for the slow development of AlGaN APDs include difficulties in achieving high-quality material epitaxy, the problem of obtaining high-efficiency p-type doping, and the change in impact ionization coefficient with Al composition in AlxGa1-xN alloys<sup>222,223</sup> . 

A solar-blind AlGaN APD with a maximum gain of 700 was reported by McClintock et al.<sup>218</sup> . Under a low bias voltage, the device exhibits soft breakdown, and Geiger operating mode does not occur. Tut et al. proposed a Schottky solar-blind APD that achieved an avalanche gain of 1560 after repeatability measurements. They obtained a high thermally limited detectivity of 1.4 × 10<sup>14</sup> cm Hz<sup>1/2</sup> W<sup>−1</sup> 219. To produce high-quality AlGaN materials for avalanche device fabrication, Sun et al. inserted an Al0.4Ga0.6N/AlN SL structure with six periods into the interface between the p-i-n active layer and HT-AlN buffer layer. The employment of an SL structure effectively relieved the strain and reduced the dislocation density<sup>220</sup> . Through the SL modulating epitaxial method, the manufactured AlGaN APD achieved a high gain of 2500 at 62 V applied voltage. The temperature-dependent dark current characteristics verified that APD has a positive temperature coefficient, and breakdown is caused by 

avalanches, rather than tunneling and photoconductive gain related to defects. 

Because the gain of AlGaN APD with a conventional p-i-n structure is limited at the magnitude of 10<sup>3</sup> , Shao et al. propose the back-illuminated SAM structure, as shown in Fig. 14a. By employing the SAM structure, nearly pure holes can be injected from absorption region into the multiplication region<sup>224</sup> . The higher hole ionization coefficients contribute to the larger multiplication gain. The SAM APD exhibits a significant avalanche breakdown characteristic at the applied voltage of 75.5 V (Fig. 14b). Furthermore, they developed a photoelectrochemical treatment process to repair etching-induced damage, and the surface defects were effectively passivated. The SEM images show that the photoelectrochemical treatment can remove or smooth whiskers and pyramids on the sidewall of the fabricated APDs induced by ICP dry-etching, as shown in Fig. 14c, d. The optimized flatter sidewall can reduce the risk of local breakdown or premature microplasma breakdown, which can result from a high local electric field formed at the cusp of whiskers and pyramids. The current–voltage characteristics of the fabricated AlGaN SAM APD showed that the photoelectrochemical treatment can effectively reduce the leakage current and improve the yield and gain of APD devices, as shown in Fig. 14e. Combining this optimized method, the device obtained a high gain of 1.2 × 10<sup>4</sup> at 84-V bias, as shown in Fig. 14b. The response peak located at 280 nm can be observed in Fig. 14f. According to the current–temperature characteristics of the device, as shown in Fig. 14g, a positive temperature coefficient indicates that the source of the gain is avalanche multiplication. 

To further improve device performance, Dong et al. exploited polarization engineering in an AlGaN SAM APD<sup>225</sup> , as shown in Fig. 15a. By adjusting the Al composition of the p-AlGaN layer, the polarization field and doping effect can be introduced into the APDs. The spontaneous and piezoelectric polarization in GaN-based semiconductors can introduce an internal electric field up to several MV/cm, which is of the same order of magnitude as the avalanche breakdown electric field in the multiplication region of AlGaN APDs. Therefore, by adjusting the Al content of AlGaN, a polarization electric field with the same direction as the reverse bias can be introduced into the multiplication region of the APDs (Fig. 15c). Figure 15b shows that the polarization-induced electric field can significantly reduce the avalanche breakdown voltage. The maximum multiplication gain is also pronouncedly enhanced by the polarization enhancement. Bulmer et al. calculated that the reasonable design of AlGaN APDs with polarization engineering could reduce operating avalanche voltage by nearly 40%<sup>226</sup> . Experimentally, Shao et al. manufactured a 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 18 of 31 



<!-- Start of picture text -->
a Ni/Au c d f<br>10 0<br>40 nm p-GaN 0.10<br>15 nm grading p-AlGaN 10 –1 Q.E. = 50% 0.08<br>80 nm p-Al0.4Ga0.6N Q.E. = 30% 0.06<br>180 nm i-Al0.4Ga0.6N 10 –2 Q.E. = 10% 0.04<br>0.02<br>180 nm i-Al60 nm n-Al0.40.4GaGa0.60.6NN Ni/AuTi/Al/ 1010 –3–4 0 V–2 V–5 V–9 V 276Wavelength (nm)279 282 285<br>500 nm n-Al0.5Ga0.5N 8.0 kV X45,000 100 nm WD 9.4 mm 8.0 kV X45,000 100 nm WD 15.8 mm –12 V–15 V<br>10 –5<br>600 nm i-Al0.5Ga0.5N 250 260 270 280 290 300 310 320 330 340 350<br>Wavelength (nm)<br>AlN/Sapphire<br>b e 10 –3 As-etched g<br>10 –5 10 –4 After KOH treatment 10 –6<br>10 –6 10 4 10 –5 After photo-electrochemical treatment 10 –7 298 K323 K<br>10 –7 10 –6 348 K<br>10 –8 10 3 10 –7 10 –8<br>10 –9 Light 10 2 1010 –8–9 10 –9<br>10 –10<br>10 –10<br>10 –11 Dark 10 –10<br>10 1 10 –11<br>10 –12 10 –12 10 –11<br>10 –13 10 0 10 –13<br>10 –12<br>0 10 20 30 40 50 60 70 80 5 10 15 20 25 30 35 40 45 50 55 60 65 70 40 45 50 55 60 65 70 75 80 85<br>Reverse bias (V) Reverse bias (V) Reverse bias (V)<br>Responsivity (A/W)<br>Responsivity (A/W)<br>Gain<br>Current (A) Current (A) Current (A)<br><!-- End of picture text -->

Fig. 14 Structure and performance of an AlGaN SAM APD. a Schematic cross-sectional diagram of the SAM AlGaN APD. b I-V curve in dark and under illumination. Sidewall SEM images of APD with KOH (c) and photo-electrochemical (d) treatment, respectively. e Dark currents for samples with different treatments. f Spectral response at various applied voltages. g Dark currents at various temperatures. Reprinted with permission from Shao et al.<sup>224</sup> . Copyright 2014 IEEE 

polarization-enhanced AlGaN SAM APD by reducing the Al component of the p-AlGaN layer, as shown in Fig. 15e. Figure 15d presents a conventional APD referenced counterpart<sup>227</sup> . The polarization-enhanced APD presents a markedly lower avalanche breakdown voltage and significant higher avalanche gain of 2.1 × 10<sup>4</sup> compared to the counterpart, as shown in Fig. 15f. The dark current also decreases significantly by one order of magnitude at the onset of breakdown. 

Additionally, Shao et al. proposed and fabricated an AlGaN heterostructure APD with high/low-Al-content AlGaN layers as the multiplication region rather than a conventional homogeneous AlGaN layer based on the SAM structure, as shown in Fig. 15g<sup>228</sup> . The carrier multiplication process is primarily initiated by impact ionization of holes, and the design of the Al0.2Ga0.8N/ Al0.45Ga0.55N heterostructure in the multiplication region can induce a band offset to facilitate hole ionization. The holes can obtain additional energy from a valence band offset, and suppress the electron ionization benefitting from the barrier generated at the conduction band. Thus, the designed heterostructure is expected to reduce the excess noise of APDs, which can be attributed to the electron-initiated multiplication process. Also, the lowAl-content Al0.2Ga0.8N layer can increase the average hole impact ionization coefficient across the entire 

multiplication region and achieve a higher avalanche gain. Consequently, they obtained a maximum gain of 5.5 × 10<sup>4</sup> and a solar-blind response peak at 275 nm (Fig. 15h, i). 

In addition to basic device structures, fabrication techniques can also be employed to improve device performance<sup>210</sup> . For example, bevel mesa and field plate terminal technologies can effectively homogenize the electric field distribution and are conducive to reducing the dark current and prevent the early breakdown of the device. The recessed electrode structure is also able to facilitate electric field enhancement. 

Polarization field control and energy-band engineering have become increasingly important means for the design of AlGaN heterostructure PDs. Strong polarization is a unique characteristic of nitride semiconductor systems. The polarization field has a strong modulation effect on the energy band structure of the heterojunction, which will significantly affect device performance. Polarizationinduced energy band engineering is important in device structure design. How to use the polarization field to enhance device performance or avoid the negative effects of the polarization field is critical to describe and must be considered in the structural design of nitride semiconductor devices. To review the progress of AlGaNbased solar-blind PDs comprehensively, we summarized the characteristics of the reported devices in Table 3. 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 19 of 31 



<!-- Start of picture text -->
a b c<br>10 –3 4.0 P i n i n<br>P-AlxGa1-xN 80 nm 10 –5 3.5 b GaN<br>i-Al0.4Ga0.6N 140 nm 10 –7 3.0 AlAl0.150.25GaGa0.850.75NN<br>n-Al0.4Ga0.6N 60 nm 2.5 Reference<br>i-Al0.4Ga0.6N 180 nm 10 –9 2.0<br>10 –11 p-GaN 1.5<br>n-Al0.5Ga0.5N 300 nm p-Al0.15Ga0.85N 1.0<br>10 –13 p-Al0.25Ga0.75N<br>Al0.5Ga0.5N Reference 0.5<br>10 –15 0.0<br>AlN 0 20 40 60 80 100 0.0 0.1 0.2 0.3 0.4 0.5 0.6<br>Voltage (V) Depth (um)<br>d e f<br>Ni/Au<br>40 nm p-GaN Ni/Au 10 –5 Dark Conventioal 10 5<br>15 nm grading p-AlGaN 40 nm p-GaN 10 –6 Light Polarization enhanced<br>80 nm p-Al0.4Ga0.6N 80 nm p-Al0.2Ga0.8N 10 –7 10 4<br>180 nm i-Al0.4Ga0.6N 180 nm i-Al0.4Ga0.6N 10 –8 10 3<br>10 –9<br>60 nm n-Al0.4Ga0.6N 60 nm n-Al0.4Ga0.6N<br>180 nm i-Al0.4Ga0.6N Ni/AuTi/AI/ 180 nm i-Al0.4Ga0.6N Ni/AuTi/AI/ 1010 –10–11 10 2<br>500 nm n-Al0.5Ga0.5N 500 nm n-Al0.5Ga0.5N 10 –12 10 1<br>10 –13<br>600 nm i-Al0.5Ga0.5N 600 nm i-Al0.5Ga0.5N 10 –14 Polarization enhanced 10 0<br>10 –15 Conventioal<br>AIN/Sapphire AIN/Sapphire 10 –1<br>0 10 20 30 40 50 60 70 80 90<br>Voltage (V)<br>g h i<br>Ni/Au 10 –4 10 9<br>60 nm p-GaN 10 –5 10 8 100 1 V<br>120 nm p-Al0.2Ga0.8N 10 –5 10 –6 10 7 5 V<br>50 nm i-Al0.2Ga0.8N 10 –6 10 –7 10 6 80 20 V<br>10 –7 10 –8 10 5<br>150 nm i-Al0.45Ga0.55N 10 –8 98 100Reverse bias (V)102 104 106 108 110 10 4 60<br>60 nm n-Al0.45Ga0.55N 10 –9 10 3<br>Ti/AI/ 10 2 40<br>180 nm i-Al0.45Ga0.55N Ni/Au 10 –10 10 1<br>800 nm Al0.5Ga0.5N 10 –11 Dark 10 0 20<br>AlGaN template/Sapphire 500 nm i-Al0.55Ga0.45N 1010 –12–13 0 20 40 60 80 100 Light 1201010 –1–2 0260 265 270 275 280 285 290 295 300<br>Wavelength (nm)<br>Reverse bias (V)<br>Current (A)<br>Electric field (MV/cm)<br>Gain<br>Current (A)<br>Current (A)<br>Gain<br>Current (A)<br>External quantum efficiency (%)<br><!-- End of picture text -->

Fig. 15 Polarization engineering for improving device performance. Schematic structures of various back-illuminated SAM APDs: a simulated polarization-enhanced, d, e conventional counterpart and experimental polarization-enhanced, g ionization-enhanced. b, f, h The I-V and gain curves of the proposed APDs, respectively, transverse corresponding. c Electric field distribution of sample a. i EQE of sample g. Reprinted with permission from Dong et al.<sup>225</sup> and Shao et al.<sup>227,228</sup> . Copyright 2013 IEEE, 2014 IEEE and 2017 IEEE 

With the development of fabrication techniques, the structures of AlGaN devices have become more diversified and achieve different performances in various application scenarios. Although photoconductive devices have a simple fabrication process, the signal recognition rate is low due to the high dark current. Using the Schottky structure, the dark current can be reduced by several orders of magnitude. The solar-blind UV/visible rejection ratio can reach 10<sup>4</sup> , and the back-to-back Schottky MSM structure can promote the extraction of photogenerated carriers. In addition to realizing AlGaN solar-blind UV detection, this structure also has the advantage of a simple preparation technique (typically one-step lithography). The planar structure of the AlGaN PD can also be combined with the nanoplasmonic enhancement method to 

improve responsivity. However, the uneven distribution of the electric field results in the effective detection area of the planar structure being restricted to the device surface. Traps such as surface states will lead to unexpected persistent photoconductance effects, thus reducing the response speed of the device. A vertical p-i-n structure is proposed to achieve a detectivity of 10<sup>14</sup> cm Hz<sup>1/2</sup> W<sup>−1</sup> . Thus, an avalanche PD is developed that can detect weak light signals with its large multiplication gain. The existing gain of AlGaN PDs can reach 10<sup>5</sup> , which encourages the research of single photon detection in solar-blind UV light. 

However, due to epitaxial problems in high-Alcontent AlGaN materials, the threading dislocations of AlGaN typically exceed 10<sup>8</sup> cm<sup>−2</sup> . There remains a 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 20 of 31 

Table 3 Summary of the reported parameters of various AlGaN-based solar-blind photodetectors 

|Material|Structure|Dark current (A)|Responsivity (A/W)|Rejection ratio|Detectivity<br>(cm Hz<sup>1/2 </sup>W<sup>−1</sup>)|Gain|Reference|
|---|---|---|---|---|---|---|---|
|Al0.51Ga0.49N|photoconductor|10<sup>−7</sup>@30 V|0.3@258 nm|~10<sup>3</sup>|_|_|55|
|Al0.26Ga0.74N|Schottky|10<sup>−9</sup>|0.07@272 nm|~10<sup>4</sup>|_|_|167|
|Al0.5Ga0.5N|Schottky|10<sup>−7</sup>@-10 V|0.033@206 nm|~10<sup>4</sup>|_|_|168|
|AlGaN/GaN|Schottky|1.5 × 10<sup>−13</sup>@0 V|0.09@267 nm|~10<sup>4</sup>|2.6 × 10<sup>12</sup>|_|169|
|Al0.38Ga0.62N/GaN|Schottky|3 × 10<sup>−15</sup>@-12 V|0.147@256 nm|>10<sup>4</sup>|1.8 × 10<sup>13</sup>|_|165|
|Al0.4Ga0.6N|MSM|10<sup>−15</sup>@20 V|0.143@275 nm|~10<sup>4</sup>|_|_|182|
|Al0.6Ga0.4N/|MSM|10<sup>−11</sup>@5 V|10<sup>6</sup>@220 nm|~10<sup>6</sup>|_|_|280|
|Al0.5Ga0.5N||||||||
|Al0.6Ga0.4N|MSM|<2 × 10<sup>−9</sup>@10 V|0.51@230 nm|~10<sup>2</sup>|_|_|281|
|Al0.4Ga0.6N|MSM|10<sup>−12</sup>@30 V|0.14@275 nm|~10<sup>4</sup>|_|_|282|
|Al0.5Ga0.5N|MSM|3.32 × 10<sup>−6</sup>@20 V|0.2@251 nm|>10<sup>3</sup>|_|_|283|
|Al0.33Ga0.67N/GaN|p-i-n|10<sup>−8 </sup>A/cm<sup>2</sup>@-5 V|0.05@286 nm|~10<sup>4</sup>|_|_|195|
|Al0.45Ga0.55N|p-i-n|<3 × 10<sup>−15</sup>@-6 V|0.11@261 nm|~10<sup>4</sup>|4.9 × 10<sup>14</sup>|_|196|
|Al0.48Ga0.52N/|p-i-n|8.2 × 10<sup>−11</sup>|0.09@269 nm|~10<sup>3</sup>|2.0 × 10<sup>14</sup>|_|197|
|Al0.57Ga0.43N||A/cm<sup>2</sup>@-5 V||||||
|Al0.36Ga0.64N/|p-i-n|2.3 × 10<sup>−4 </sup>A/cm<sup>2</sup>@-|0.136@282 nm|~10<sup>3</sup>|_|_|198|
|Al0.45Ga0.55N||5 V||||||
|Al0.45Ga0.55N|p-i-n|1.8 × 10<sup>−12</sup>@-5 V|0.114@270 nm|~10<sup>4</sup>|3.3 × 10<sup>13</sup>|_|200|
|Al0.38Ga0.62N|p-i-n avalanche|1.6 × 10<sup>−8</sup><br>A/cm<sup>2</sup>@0 V|_|_|_|700|218|
|Al0.4Ga0.6N|p-i-n avalanche|<8 × 10<sup>−15</sup>@-20 V|0.13@272 nm|~10<sup>4</sup>|1.4 × 10<sup>14</sup>|1560|219|
|Al0.4Ga0.6N|p-i-n avalanche|3.3 × 10<sup>−12</sup>@-10 V|0.08@270 nm|_|_|2500|220|
|Al0.38Ga0.62N|SAM avalanche|1.0 × 10<sup>−8 </sup>A/cm<sup>2</sup>@-<br>20 V|0.132@281 nm|~10<sup>3</sup>|_|3000|221|
|Al0.4Ga0.6N|SAM avalanche|10<sup>−13</sup>@-15 V|0.15@280 nm|~10<sup>4</sup>|_|1.2 × 10|<sup>4</sup><br>224|
|Al0.4Ga0.6N|SAM avalanche|5 × 10<sup>−10</sup>@-60 V|_|_|_|2.1 × 10|<sup>4</sup><br>227|
|Al0.2Ga0.8N/|SAM avalanche|~10<sup>−11</sup>@-20 V|EQE 95.8%@275 nm|_|_|5.5 × 10|<sup>4</sup><br>228|
|Al0.45Ga0.55N||||||||
|Al0.65Ga0.35N|p-i-n avalanche|~10<sup>−13</sup>@-75 V|0.06@255 nm|>1.2 × 10<sup>4</sup>|_|10<sup>5</sup>|284|



long pathway to realize solar-blind UV single photon avalanche diodes (SPADs). There is also a lack of experimental extraction of impact ionization coefficients in AlGaN. Furthermore, the physical mechanisms of different dislocations on the leakage currents and the influences of impurity scattering as well as the capture of carriers by defects on device performance remain to be studied. Despite these gaps in the literature, the substantial progress has been made in the development of individual devices, which provides support for FPAs and opens a new era in AlGaN solarblind UV imaging. 

### Focal plane arrays 

FPA imaging is an important application of UV detection and has promoted significant revolutions in imaging technology. FPA must be combined with a readout integrated circuit (ROIC) to complete signal detection<sup>229,230</sup> . The silicon-based integrated circuit is typically used as a bridge for detection. Thus, the development of the FPA matches the development of integrated circuits (i.e., Moore’s law). FPA imaging has made considerable progress in long wavelength bands such as infrared, farinfrared (terahertz), and sub-mm wavelengths<sup>231–240</sup> . With the development of GaN-based materials, in recent 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 21 of 31 

decades, the application of FPAs in the field of UV and deep UV imaging has become more extensive<sup>241–243</sup> . 

#### FPA architectures 

Typically, FPAs are divided into monolithic-integration and hybrid-integration architectures. Additionally, in terms of application types, FPAs can be classified as PDs or thermal detectors<sup>244–248</sup> . We focus on solar-blind UV FPAs in this review. 

In monolithic-integration architectures, both optical detection and signal readout (multiplexing) are completed in the same detection material. This approach can reduce the number of process steps, reduce preparation costs, and increase yields. CCD and CMOS sensors are two commonly used types of image sensors, both of which use photodiodes for photoelectric conversion of light into digital data. The primary difference in how they operate is the way they transmit digital data. The charge data of each pixel in each row of a CCD sensor is transferred to the next pixel in sequence, output from the bottom of the pixel, and then amplified and output by the amplifier at the edge of the sensor. In a CMOS sensor, each pixel is adjacent to an amplifier and an A/D conversion circuit, which outputs data in the same manner as a memory circuit. The reason for this difference is as follows: (i) CCDs’ mechanism ensures that the data will not be distorted during transmission. Thus, the data of each pixel can be gathered at the edge of the sensor and then amplified; (ii) CMOS data exhibits more noise when transmitted over longer distances and thus must be amplified first, followed by integrating the data from each pixel. CCD sensors are superior to CMOS sensors in terms of sensitivity, resolution, and noise control, while CMOS sensors are low cost, require little power, and can be highly integrated. However, with the advancement of CCD and CMOS sensor technologies, the differences between the two are gradually shrinking. For example, CCD sensors are starting to use less power for applications in the mobile communications market (e.g., Sanyo), and CMOS sensors are starting to achieve higher resolutions and sensitivities for use in upscale imaging products. 

In terms of the hybrid-packaged structure, the detector and multiplexer are optimized independently. UV solidstate imagers are primarily manufactured with a hybrid structure. The merits of the hybrid structure include nearly 100% fill factors and a large area for processing signals on the multiplexer chip. PDs are interconnected with ROIC to describe signal reading. In 1977, hybrid packaging technology was developed and used for production in the following decades. The most commonly used hybridization approach is flip-chip interconnected by bump bonds (indium), as shown in Fig. 16. The detector array is integrated with the silicon readout circuit through 



<!-- Start of picture text -->
Sapphire<br>n-AlGaN<br>i-AlGaN<br>p-AlGaN<br>Indium Indium Indium<br>bump bump bump<br>Si ROIC<br><!-- End of picture text -->

Fig. 16 Hybrid-packaged AlGaN focal plane arrays. Indium bump for FPA interconnect AlGaN solar-blind UV photodetector with silicon ROIC 

the indium bump. Heating causes the indium bump to melt, and the soldering process is implemented by reflow<sup>249–251</sup> . 

In addition to the indium bump technique, other approaches are also performed out to complete the fabrication process, such as loophole interconnection and 3D integration<sup>252</sup> . Device illumination is also a factor that should be considered for FPA integration. The backilluminated device is more conducive to the bonding of the array and ROIC. The opaque multiplexer will not reduce the effective light area of the device in the backilluminated AlGaN-based structure, as shown in Fig. 16. In the case of ROIC, preamplifier techniques promote the development of high-performance FPAs. Due to a large dark current caused by background noise and the nonuniformity of the material, ROIC will face the problems of a small dynamic range and large spatial noise. Therefore, background and dark current suppression (BDS) circuits are required to reduce spatial noise and provide fast frame rates<sup>253</sup> . Various circuits are employed for FPAs, such as direct injection (DI) circuit<sup>254–258</sup> , capacitive transimpedance amplification input circuit (CTIA)<sup>259–262</sup> , and source follower per detector (SFD)<sup>263–265</sup> . DI yields poor performance at low flux, while CTIA yields high gains and is more complex. The SFD is the most common circuit in the infrared radiation astronomy field. In recent decades, the development of UV detectors and integrated circuits has jointly promoted the advancement of FPA imaging technology. 

#### Development of AlGaN-based solar-blind UV FPAs 

In the back-illuminated AlxGa1-xN-based solar-blind UV FPA, the imaging element is commonly composed of a detector array and a silicon-based CMOS ROIC (Fig. 16). The AlxGa1-xN solar-blind UV array detects UV signals and converts the UV light emitted or reflected by the target into electrical signals. The silicon CMOS ROIC stores the electrical signals collected by the UV detector array in the integrating capacitor, and reads out the 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 22 of 31 



<!-- Start of picture text -->
a b<br>Common<br>contact Unit cell Unit cell<br>p-GaN Contact layer<br>p-AlGaN p-layer<br>uid n-AlGaN absorber<br>n-AlGaN Window and common contact<br>Sapphire substrate<br>UV radiation<br><!-- End of picture text -->



Fig. 17 256 × 256 AlGaN UV FPA structure and imaging. a Schematic cross-sectional diagram of AlGaN-based FPA structure. b UV reflection image of a US dollar coin with the fabricated FPA. Reprinted with permission from Lamarre et al.<sup>266</sup> . Copyright WILEY-VCH Verlag Berlin GmbH 

electrical signals distributed in space in a certain time sequence relationship to automatically complete twodimensional (2D) imaging. When the AlxGa1-xN-based UV FPA works in the solar-blind region of the solar spectrum under the atmosphere, there is no need or less use of UV filters, which can increase the UV light transmittance and improve the detectivity, due to its intrinsic solar-blind characteristic. 

In 2001, Lamarre et al. reported back-illuminated 256 × 256 AlGaN UV FPAs with 30 × 30 μm<sup>2</sup> unit pixels<sup>266</sup> . Figure 17a shows the schematic structure of the FPA. An Mg-doped p-type GaN cap layer is used for better ohmic contact. Figure 17b shows the UV reflection image of a coin by this FPA. 

The Razeghi research group at Northwestern University in the United States also reported a 320 × 256 AlxGa1-xN-based UV detector array in 2005<sup>267</sup> . The prepared FPA is composed of 320 × 256 arrays of 25 μm × 25 μm pixels with a period of 30 μm, as shown in Fig. 18e. There is a common n-type contact ring on the periphery of the array. Before combining FPA and ROIC, the electrical characteristics of individual pixels in the array were studied. The turn-on voltage of the pixel is 4.7 V, the series resistance is 4.3 kΩ, and the ideal factor of the device is 3.6. Figure 18a shows the schematic cross-sectional structure of the p-i-n AlGaN PD. The device exhibits a significant response peak at 255 nm under zero bias (Fig. 18b). 

Due to the absorption of solar-blind light by ozone spheres, 280-nm light radiation is rare in nature. The imaging of the camera requires artificial scenes to cooperate. A simple scene can use shortwave UV light and a shadow mask props, these props form a certain shape and are then imaged by the camera. Figure 18d shows the image of the prop letter CQD. UV cameras can also image arcs and coronas, which can be used for the diagnosis of high-voltage equipment, and can also be used for military missile warnings, accurate positioning imaging of ships 

and port berthing in fog, and many other solar-blind imaging fields. Figure18c is a solar-blind image of a small flyback transformer with high-frequency arcs. The imaging geometry is illustrated in Fig. 18f. By improving the FPA processing methods (background difference), the pixel yield can be improved, thereby eliminating the existence of poor scan points. 

For FPAs, important indicators for judging performance include pixel uniformity and anti-noise ability. Additionally, the parasitic illumination of multiplexers and cooled readout circuits also restrict the development of FPA imaging technology. Reine et al. reported a backilluminated 256 × 256 hybrid AlGaN-based FPAs for solar-blind UV detection<sup>268</sup> . The detection wavelength covers the range from 260 to 280 nm. The response nonuniformities of the FPA are as low as 2.5%. They obtained the best pixel with a low noise equivalent irradiance of 90 photos/pixel at 1 Hz. Reverchon et al.<sup>269</sup> demonstrated an FPA of 320 × 256 Al0.45Ga0.55N Schottky photodiode pixels. The multiplex process with ROIC was implemented using a black matrix at room temperature. Using a basic black glass to reduce noise, a UV/visible rejection ratio of four orders of magnitude was achieved. 

Hai Lu et al. of Nanjing University also fabricated AlGaN p-i-n FPAs with 320 × 256 pixels. As shown in Fig. 19a, b, FPAs are prepared on a 2-inch sapphire substrate with a pixel size of 25 × 25 μm<sup>2</sup> . The I-V characteristics show superior pixel performance and consistency, as shown in Fig. 19c. The arrays are integrated with silicon driver circuits by indium bumps (Fig. 19d, e). This AlGaN FPA camera can describe solarblind UV imaging, and a hand-shaped picture is exhibited in Fig. 19f. 

In terms of substrate material, the AlGaN detector that is prepared on sapphire can be used to fabricate FPA, and AlGaN devices on Si can also be manufactured for FPA imaging. Malinowski et al. reported the fabrication of an 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 23 of 31 



<!-- Start of picture text -->
a Ti/Pt/Au Thin Ni/Au c d<br>p-GaN:Mg (50 nm)<br>p-Al0.36Ga0.64N (50 nm)<br>i-Al0.36Ga0.64N (200 nm)<br>n-Al0.45Ga0.55N (100 nm) Ti/Al/Ti/Pt/Au<br>Al0.5Ga0.5N:Si-ln<br>(600 nm)<br>AlN (~1 μm)<br>AlN buffer<br>Sapphire (00.1)<br>Back-illumination<br>b e f<br>10 –1 Un-biased Patterned image<br>(Black toner)<br>Peak responsivity UV Optic<br>10 –2 95.7 ma/W f=32 mm<br>10 –3 @ 255 nm<br>10 –4<br>10 –5<br>UV<br>10 –6 source<br>Polished aluminum plate<br>200 225 250 275 300 325 350 375 400 425 450<br>Wavelength<br>Responsivity (A/W)<br><!-- End of picture text -->

Fig. 18 320 × 256 AlGaN UV FPAs and imaging technology. a Schematic structure of the AlGaN photodetector. b Spectral response at 0 V. c Electrical arc discharge image from FPA camera. d Paper-cutout image from FPA camera. e SEM image of FPA with indium bump. f Schematic diagram of Imaging geometry. Reprinted with permission from McClintock et al.<sup>267</sup> . Copyright 2005 SPIE 



<!-- Start of picture text -->
a b c<br>10 -4<br>10 -5 I1I2<br>320× 256 320× 256 320× 256 10 -6 I3I4<br>10 -7 I5I6<br>I7<br>320× 256 320× 256 320× 256 10 -8 I8<br>I9<br>10 -9 I10<br>I11<br>320× 256 320× 256 320× 256 10 -10 I12<br>I13<br>10 -11 I14<br>320× 256 320× 256 320× 256 10 -12 I15I16<br>I17<br>2-inch sapphire wafer 10 -13 I18<br>-10 -5 0 5 10<br>Applied Bias (V)<br>d e f<br>Current (A)<br><!-- End of picture text -->







Fig. 19 AlGaN p-i-n solar-blind UV FPAs and imaging by Nanjing University. a 320 × 256 AlGaN FPAs on 2-inch sapphire wafer. b Optical images of AlGaN focal plane arrays. c I-V characteristics of individual photodetector. d Silicon driver IC. e Optical images of array with Indium bumps. f Solarblind ultraviolet images taken from the AlGaN FPA camera 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 24 of 31 



<!-- Start of picture text -->
a b<br>30  μ m 1  μ m<br>c d<br>Un-patterned<br>Patterned<br><!-- End of picture text -->

Fig. 20 Reduced area epitaxy for the growth of AlGaN photodetector pixels. a SEM image of patterned AlN, mesa size: 26 μm × 26 μm, periodicity: 30 μm. b Cross-sectional SEM image of sidewall. Implemented AlGaN UV photodetector grown on patterned (c) and unpatterned (d) AlN template. Reprinted with permission from Cicek et al.<sup>271</sup> . Copyright 2013 American Institute of Physics 

AlGaN-based FPA of 256 × 256 pixels integrated with a CMOS readout chip<sup>270</sup> . A thin silicon layer was left to block light with wavelengths higher than 20 nm. The proposed FPA was sensitive down to 1-nm wavelength, thus achieving extreme UV light imaging. Cicek et al.<sup>118</sup> proposed a scheme of laterally epitaxial AlGaN/AlN on silicon and fabricated an AlGaN hybrid FPA with an indium bump. Unlike sapphire epitaxy, it is necessary to remove the Si substrate with acid after attachment to prevent Si from absorbing solar-blind UV light. The p-i-n unit PD pixel yielded a low dark current density of 1.6 × 10<sup>−8</sup> A/cm<sup>2</sup> at 10 V, which confirmed the feasibility of AlGaN growth on silicon. 

Because the FPA is composed of individual pixel units, the reduced area epitaxy (RAE) method can be used for the growth of the PD structure. As shown in Fig. 20a, patterned AlN fabricated after dry etching was used to grow AlGaN structure. An etching depth of 300 nm is shown in the cross-sectional image in Fig. 20b. The biaxial strain can be released by the patterned squares to improve the crystal quality. A comparison of the RAE and nonRAE epitaxial materials shows that the patterned epitaxial pixels are nearly crack-free, while the counterpart exhibits many cracks, as shown in Fig. 20c, d. Cicek et al. obtained 97% crack-free pixels through the RAE method<sup>271</sup> . 

Due to the improvement of AlGaN material preparation technology and device performance, AlGaN has become a superior alternative material for the development of small-size, lightweight, and low-power solar-blind FPAs. To express the development process of AlGaN-based FPAs more clearly, we reviewed and summarized the 

results of reported AlGaN-based FPAs in recent years, as shown in Table 4. 

It can be concluded that most AlGaN detectors in FPAs exhibit a p-i-n structure. The vertical structure can be used to fabricate the back-illuminated PD, which is beneficial to the flip-on-chip process. Currently, solar-blind UV imaging of 320 × 256 pixels can typically be achieved. However, FPAs composed of avalanche optoelectronic devices are rarely reported, which can be attributed to the stricter requirements of higher device uniformity and yield in AlGaN APDs. Large-area UV imaging arrays are also not as sharp as visible and infrared light. With the sustained improvement of the epitaxial technique and device performance, the technology of AlGaN solar-blind UV imaging will likely develop quickly. All permissions and copyrights of reprint figures in this review are provided in the supplementary material. 

### Summary and prospects 

Although considerable progress has been made with AlGaN-based solar-blind UV PDs over the past two decades, the performances of these devices have yet to meet expectations, particularly with single photon detection. The biggest bottleneck in the development of AlGaN-based solar-blind UV PDs is the high-quality film epitaxy of high-Al-content AlGaN alloys. Many ingenious and thoughtful epitaxy methods or techniques mentioned above such as high-low AlN buffers, SL dislocation filter, or stress control layer, PALE method, ELO techniques, have substantively improved the crystal quality of AlGaN alloys. Additionally, bulk AlN single-crystal substrates can mitigate serious lattice mismatches, and thermal mismatches can occur when using sapphire substrates to fabricate AlGaN films, but large-area AlN bulk single crystal is not commercially available. Using an AlN or AlGaN nanopatterned template based on a sapphire substrate is a promising way to fabricate high-quality AlGaN films combined with the ELO technique. 

However, the threading dislocation density in AlGaN materials is typically above 1 × 10<sup>8</sup> cm<sup>−2</sup> at present, which is six orders of magnitude higher than that of SiC, a relatively mature material in developing UV SPAD. Therefore, it is very difficult to prepare materials that meet the requirements of SPAD only by relying on the existing growth methods and equipment. To obtain further high-quality AlGaN materials, certain challenges must be overcome, such as improving the growth chamber and optimizing the growth conditions from the perspective of growth kinetics. The fabrication of p-AlGaN suffers from low Mg acceptor doping efficiency in addition to serious crystal quality problem. Although many methods as aforementioned have been developed to suppress the self-compensation process, increase the solubility of Mg atom, and reduce the activation energy of Mg acceptor in AlGaN, how to guarantee achieving a high HC 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 25 of 31 

Table 4 Summary of reported AlGaN-based focal plane arrays 

|Material (Active region)|Pixel structure|Pixel points|Operating wavelength (nm)|Year|Reference|
|---|---|---|---|---|---|
|AlGaN|p-i-n|256 × 256|265–285|2001|Lamarre et al.<sup>266</sup>|
|Al0.32Ga0.68N|p-i-n|320 × 256|280|2005|McClintock et al.<sup>267</sup>|
|Al0.36Ga0.64N|p-i-n|320 × 256|278|2005|McClintock et al.<sup>285</sup>|
|Al0.45Ga0.55N|p-i-n|256 × 256|260–280|2006|Reine et al.<sup>268</sup>|
|Al0.08Ga0.92N|p-i-n|8 × 8|330–350|2006|Kim et al.<sup>286,287</sup>|
|Al0.45Ga0.55N|Schottky|320 × 256|280|2007|Reverchon et al.<sup>269</sup>|
|Al0.59Ga0.41N|p-i-n|128 × 128|233–258|2008|Yuan et al.<sup>62</sup>|
|Al0.43Ga0.57N|Schottky|320 × 256|260–290|2009|Duboz et al.<sup>288</sup>|
|Al0.4Ga0.6N with Si-layer|Schottky|256 × 256|1–33|2011|Malinowski et al.<sup>270</sup>|
|Al0.45Ga0.55N|p-i-n|320 × 256|290|2013|Cicek et al.<sup>118</sup>|
|Al0.4Ga0.6N|p-i-n|320 × 256|275|2013|Cicek et al.<sup>271</sup>|
|Al0.4Ga0.6N|p-i-n|320 × 256|278|2015|McClintock et al.<sup>288</sup>|
|AlGaN|p-i-n|320 × 256|200–400|2018|Lakovleva et al.<sup>289</sup>|
|Al0.43Ga0.57N|p-i-n|640 × 512|280|2020|Rehm et al.<sup>290</sup>|



and a high crystal quality of p-AlGaN simultaneously requires further research and better methods. 

Certainly, structural design and fabrication processes are also important factors in developing low-noise and high-gain AlGaN-based solar-blind UV PDs, particularly in this heterostructure system with a strong polarization effect and large lattice mismatch. Polarization field control and energy-band cutting technologies will become increasingly important means for the design of AlGaN heterostructure PDs. Bevel mesa and field plate terminal technologies can effectively uniform the electric field distribution and are helpful to reduce the dark current and prevent early breakdown of a device. 

Moreover, further research on device physics is necessary to achieve state-of-the-art AlGaN-based solar-blind UV PDs. Under the critical breakdown electric field, the contribution of different types of dislocations to the tunneling leakage current remains unclear, particularly in a high-dislocation-density material system. The effect of dislocations on impact ionization has also rarely been studied. Understanding these physics mechanisms will help us to take more effective methods to solve material fabrication and process questions. The experimental values of the carrier impact ionization coefficient in AlGaN materials have not yet been extracted, which affects the accurate design and simulation of the device structure. 

Regarding application field, AlGaN FPAs play an irreplaceable role in solar-blind UV imaging. Despite marked progress in AlGaN FPAs, the uniformity and scale of arrays must be further improved. In particular, avalanche 

FPAs for detecting weak signals is still confronted with huge challenges. With the development of epitaxial and PD technology, the fabrication of large-scale AlGaN solarblind UV FPAs is anticipated in the near future. 

##### Acknowledgements 

The authors acknowledge the National Key R&D Program of China (2016YFB0400903), the NSFC (61634002), and the NSAF (U1830109). 

##### Author details 

> 1Key Laboratory of Advanced Photonic and Electronic Materials, School of Electronic Science and Engineering, Nanjing University, Nanjing 210093, China. 

> 2Collaborative Innovation Center for Optoelectronic Semiconductors and Efficient Devices, Department of Physics, Xiamen University, Xiamen 361005, China.<sup>3</sup> Institute of Future Display Technology, Tan Kah Kee Innovation Laboratory, Xiamen 361102, China 

##### Conflict of interest 

The authors declare no competing interests. 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41377-021-00527-4. 

Received: 14 December 2020 Revised: 30 March 2021 Accepted: 31 March 2021 



##### References 

1. Shibata, T. et al. Evaluation of the solar-blind effect in ultraviolet ozone lidar with raman lasers. Appl. Opt. 26, 2604–2608 (1987). 

2. McClintock, R. et al. AlxGa1-xN materials and device technology for solar blind ultraviolet photodetector applications. In Proc. of SPIE 4288, Photodetectors: Materials and Devices VI. 219–229 (SPIE, San Jose, 2001). 

3. Safin, R. G. et al. Solar-blind filter for the ultraviolet region. J. Opt. Technol. 74, 208–210 (2007). 

4. Kuryatkov, V. et al. Solar-blind ultraviolet photodetectors based on superlattices of Aln/Alga(in)N. Appl. Phys. Lett. 82, 1323–1325 (2003). 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 26 of 31 

5. Reilly, D. M., Moriarty, D. T. & Maynard, J. A. Unique properties of solar blind ultraviolet communication systems for unattended ground-sensor networks. In Proc. of SPIE 5611, Unmanned/Unattended Sensors and Sensor Networks. 244–254 (SPIE, London, 2004). 

6. Li, H. G. et al. Spectral response tuning and realization of quasi-solar-blind detection in organic ultraviolet photodetectors. Org. Electron. 12, 70–77 (2011). 

7. Srour, H. et al. Solar blind metal-semiconductor-metal ultraviolet photodetectors using quasi-alloy of BGaN/GaN superlattices. Appl. Phys. Lett. 99, 221101 (2011). 

8. McClintock, R., Haddadi, A. & Razeghi, M. Free-space optical communication using mid-infrared or solar-blind ultraviolet sources and detectors. In Proc. of SPIE 8268, Quantum Sensing and Nanophotonic Devices IX. 826810 (SPIE, San Francisco, 2012). 

9. Wang, T. J. et al. Solar-blind ultraviolet band-pass filter based on metal— dielectric multilayer structures. Chin. Phys. B 23, 074201 (2014). 

10. Zhou, Y. et al. Study on parameters extraction method of discharge based on solar-blind ultraviolet imaging detection. In Proc. of the International Conference on Information Technology and Industrial Automation. 11–16 (Destech Publications, USA, 2015). 

11. Lyu, C. G. et al. Solar-blind ultraviolet upwelling radiance diurnal variation led by observation geometry factors on geostationary attitude sensor limb viewing. Terr. Atmos. Ocean. Sci. 27, 943–953 (2016). 

12. Qian, L. X. et al. β-Ga2O3 solar-blind deep-ultraviolet photodetector based on annealed sapphire substrate. Vacuum 140, 106–110 (2017). 

13. Mazzeo, G. et al. Deep ultraviolet detection dynamics of AlGaN based devices. Appl. Phys. Lett. 89, 223513 (2006). 

14. Hofstetter, D. et al. Monolithically integrated AlGaN/GaN/AlN-based solarblind ultraviolet and near-infrared detectors. Electron. Lett. 44, 986–988 (2008). 

15. Oshima, T. et al. Vertical solar-blind deep-ultraviolet schottky photodetectors based on β-Ga2O3 substrates. Appl. Phys. Express 1, 011202 (2008). 

16. Wang, G. S. et al. Performance comparison of front- and back-illuminated AlGaN-based metal-semiconductor-metal solar-blind ultraviolet photodetectors. Journal of Vacuum. Sci. Technol. B: Microelectron. Nanometer Struct. Process. Meas. Phenom. 31, 011202 (2013). 

17. Han, W. Y. et al. High performance back-illuminated MIS structure AlGaN solar-blind ultraviolet photodiodes. J. Mater. Sci.: Mater. Electron. 29, 9077–9082 (2018). 

18. Nela, L. et al. Ultra-compact, high-frequency power integrated circuits based on Gan-on-Si schottky barrier diodes. IEEE Transactions on Power. Electronics 36, 1269–1273 (2021). 

19. Sheu, J. K. et al. White-light emission from near UV InGaN-GaN LED chip precoated with blue/green/red phosphors. IEEE Photonics Technol. Lett. 15, 18–20 (2003). 

20. Karbownik, P. & Sarzala, R. P. Structure optimisation of short-wavelength ridge-waveguide InGaN/GaN diode lasers. Opto-Electron. Rev. 16, 27–33 (2008). 

21. Witzigmann, B. et al. Simulation and design of optical gain in In(Al)GaN/GaN short wavelength lasers. In Proc. of SPIE 6184, Semiconductor Lasers and Laser Dynamics II. 61840E (SPIE, Strasbourg, 2006). 

22. Uchida, S. et al. Short wavelength lasers based on GaAs and GaN substrate for DVD and Blu-ray technology. In Proc. of 2006 International Electron Devices Meeting. 1–4 (IEEE, San Francisco, 2006). 

23. Wu, S. et al. Femtosecond optical generation and detection of coherent acoustic phonons in GaN single crystals. Phys. Rev. B 76, 085210 (2007). 

24. Chow, K. H. et al. Intrinsic defects in GaN. I. Ga sublattice defects observed by optical detection of electron paramagnetic resonance. Phys. Rev. B 69, 045207 (2004). 

25. Vlasenko, L. S. et al. Defects observed by optical detection of electron paramagnetic resonance in electron-irradiated p-type GaN. Phys. Rev. B 65, 205202 (2002). 

26. Bozdog, C. et al. Optical detection of electron paramagnetic resonance in electron-irradiated GaN. Phys. Rev. B 59, 12479–12486 (1999). 

27. Wraback, M. et al. Time-resolved reflectivity studies of coherent longitudinal acoustic phonon pulses in bulk III-nitride semiconductors. Phys. Status Solidi (A) 202, 790–794 (2005). 

28. Kane, M. H. et al. Multifunctional III-nitride dilute magnetic semiconductor epilayers and nanostructures as a future platform for spintronic devices. In Proc. of SPIE 5732, Quantum Sensing and Nanophotonic Devices II. 389–400 (APIE, San Jose, 2005). 

29. Makino, H. et al. Making ferromagnetic semiconductors out of III-V nitride semiconductors. In Proc. of SPIE 5774, Fifth International Conference on Thin Film Physics and Applications. 11–16 (SPIE, Shanghai, 2004). 

30. Palacios, T. et al. Submicron technology for III-nitride semiconductors. J. Vac. Sci. Technol. B 20, 2071–2074 (2002). 

31. Komirenko, S. M. et al. Runaway effects in nanoscale group-III nitride semiconductor structures. Phys. Rev. B 64, 113207 (2001). 

32. Mohammad, S. N. Trap-assisted recombination in semiconductors: application to group III gallium nitride material and junctions. Philos. Mag. B 81, 591–612 (2001). 

33. Albrecht, B. et al. AlGaN ultraviolet a and ultraviolet C photodetectors with very high specific detectivity D. Jpn. J. Appl. Phys. 52, 08JB28 (2013). 

34. van Schalkwyk, L. et al. Implementation of an AlGaN-based solar-blind UV four-quadrant detector. Phys. B: Condens. Matter 439, 93–96 (2014). 

35. Litton, C. W. et al. Design requirements for high-sensitivity uv solar blind imaging detectors based on AlGaN/GaN photodetector arrays: a review. In Proc. of SPIE 4454, Materials for Infrared Detectors. 218–232 (SPIE, San Diego, 2001). 

36. Ambacher, O. Growth and applications of group III nitrides. J. Phys. D 31, 2653–2710 (1998). 

37. Muñoz, E. et al. III nitrides and UV detection. J. Phys. Condens. Matter 13, 7115–7137 (2001). 

38. Khan, M. A. et al. III-nitride UV devices. Jpn. J. Appl. Phys. 44, 7191–7206 (2005). 39. Razeghi, M. III-nitride optoelectronic devices: from ultraviolet toward terahertz. IEEE Photonics J. 3, 263–267 (2011). 

40. Alaie, Z., Nejad, S. M. & Yousefi, M. H. Recent advances in ultraviolet photodetectors. Mater. Sci. Semiconductor Process. 29, 16–55 (2015). 

41. Li, D. B. et al. AlGaN photonics: recent advances in materials and ultraviolet devices. Adv. Opt. Photonics 10, 43–110 (2018). 

42. Sood, A. K. et al. Development of high-performance detector technology for UV and IR applications. In Proc. of SPIE 11151, Sensors, Systems, and NextGeneration Satellites XXIII. 1115113 (SPIE, Strasbourg, 2019). 

43. Malinowski, P. E. et al. AlGaN photodetectors for applications in the extreme ultraviolet (EUV) wavelength range. In Proc. of SPIE 7003, Optical Sensors 2008. 70030N (SPIE, Strasbourg, 2008). 

44. Zhou, J. et al. Resonant tunneling effect in metal-semiconductor-metal ultraviolet detectors grown with AlGaN/GaN multi-quantum-well interlayer. Appl. Phys. Lett. 89, 053514 (2006). 

45. Duboz, J. Y. et al. Submicron metal-semiconductor-metal ultraviolet detectors based on AlGaN grown on silicon: results and simulation. J. Appl. Phys. 92, 5602–5604 (2002). 

46. Shur, M. S. & Khan, M. A. GaN and AlGaN ultraviolet detectors. Semiconductors Semimet. 57, 407–439 (1999). 

47. Sai, P. et al. AlGaN/GaN field effect transistors based on lateral schottky barrier gates as millimeter wave detectors. In Proc. of the 2018 43rd International Conference on Infrared, Millimeter, and Terahertz Waves. (IEEE, Nagoya, 2018). 

48. Malinowski, P. E. et al. EUV detectors based on AlGaN-on-si schottky photodiodes. In Proc. of SPIE 8073, Optical Sensors 2011; and Photonic Crystal Fibers V. 807302 (SPIE, Prague, 2011). 

49. Hellings, G. et al. AlGaN schottky diodes for detector applications in the UV wavelength range. In Proc. of the 14th IEEE Mediterranean Electrotechnical Conference. (IEEE, Ajaccio, 2008). 

50. Park, M. J. et al. Nonpolar GaN-based nanopillar green Light-Emitting Diode (Led) fabricated by using self-aligned In3Sn nanodots. Appl. Surf. Sci. 536, 147865 (2021). 

51. Kalra, A. et al. Polarization-graded AlGaN solar-blind P-I-N detector with 92% zero-bias external quantum efficiency. IEEE Photonics Technol. Lett. 31, 1237–1240 (2019). 

52. Long, J. P. et al. UV detectors and focal plane array imagers based on AlGaN P-I-N photodiodes. Opto-Electron. Rev. 10, 251–260 (2002). 

53. Ainbund, M. R. et al. Solar-blind UV photocathodes based on AlGaN heterostructures with a 300- to 330-Nm spectral sensitivity threshold. Tech. Phys. Lett. 38, 439–442 (2012). 

54. Laskar, M. R. et al. Polarization sensitive solar-blind detector based on a-plane AlGaN. In Proc. of the IEEE Photonic Society 24th Annual Meeting. 37–38 (IEEE, Arlington, 2011). 

55. Cherkashinin, G. et al. The performance of AlGaN solar blind UV photodetectors: responsivity and decay time. Phys. Status Solidi (B) 243, 1713–1717 (2006). 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 27 of 31 

56. Duboz, J. Y. et al. Solar blind detectors based on AlGaN grown on sapphire. Phys. Status Solidi (C) 2, 964–971 (2005). 

57. Biyikli, N. et al. High-speed solar-blind AlGaN schottky photodiodes. MRS Online Proc. Libr. 764, 58 (2002). 

58. Guo, S. P. et al. Growth of high Al concentration AlGaN for solar blind photodetector applications. MRS Online Proc. Libr. 693, 138–143 (2001). 

59. Brown, J. D. et al. Solar-blind AlGaN heterostructure photodiodes. Mater. Res. Soc. Internet J. Nitride Semiconductor Res. 5, e9 (2000). 

60. Reverchon, J. L. et al. Performances of AlGaN-based focal plane arrays from 10 nm to 200 nm. In Proc. of SPIE 7691, Space Missions and Technologies. 769109 (SPIE, Orlando, 2010). 

61. Reine, M. B. et al. Solar-blind AlGaN 256×256 p-i-n detectors and focal plane arrays. In Proc. of SPIE 6119, Semiconductor Photodetectors III. 611901 (SPIE, San Jose, 2006). 

62. Yuan, Y. G. et al. Development of solar-blind AlGaN 128 × 128 ultraviolet focal plane arrays. Sci. China Ser. E: Technol. Sci. 51, 820–826 (2008). 

63. Miyoshi, M. et al. High-electron-mobility AlGaN/AlN/GaN heterostructures grown on 100-mm-diam epitaxial AlN/sapphire templates by metalorganic vapor phase epitaxy. Appl. Phys. Lett. 85, 1710–1712 (2004). 

64. Simpkins, B. S. & Yu, E. T. Influence of aln buffer on electronic properties and dislocation microstructure of AlGaN/GaN grown by molecular beam epitaxy on sic. J. Vac. Sci. Technol. B 21, 1818–1821 (2003). 

65. Furis, M. et al. Time resolved photoluminescence of Si-doped high Al mole fraction AlGaN epilayers grown by plasma-enhanced molecular beam epitaxy. MRS Online Proc. Libr. 798, 559–564 (2003). 

66. Kato, T. et al. Selective growth of GaN/AlGaN microstructures by metalorganic vapor phase epitaxy. Jpn. J. Appl. Phys. 40, 1896–1898 (2001). 

67. Nikishin, S. A. et al. Growth of AlGaN on Si(111) by gas source molecular beam epitaxy. Appl. Phys. Lett. 76, 3028–3030 (2000). 

68. Webb, J. B. et al. Growth of high mobility AlGaN/GaN heterostructures by ammonia-molecular beam epitaxy. Phys. Status Solidi (A) 176, 243–246 (1999). 

69. Dimitrov, R. et al. Comparison of N-face and Ga-face AlGaN/GaN-based high electron mobility transistors grown by plasma-induced molecular beam epitaxy. Jpn. J. Appl. Phys. 38, 4962–4968 (1999). 

70. Domen, K. et al. Corrections to “lasing mechanism of InGaN-GaN-AlGaN MQW laser diode grown on SiC by low-pressure metal~organic vapor phase epitaxy”. IEEE J. Sel. Top. Quantum Electron. 4, 803 (1998). 

71. Domen, K. et al. Lasing mechanism of InGaN-GaN-AlGaN MQW laser diode grown on Sic by Low-Pressure metal-organic vapor phase epitaxy. IEEE J. Sel. Top. Quantum Electron. 4, 490–497 (1998). 

72. Ponce, F. A. et al. Crystalline structure of AlGaN epitaxy on sapphire using AlN buffer layers. Appl. Phys. Lett. 65, 2302–2304 (1994). 

73. Wu, Z. H. et al. Strain relaxation mechanisms in AlGaN epitaxy on AlN templates. Appl. Phys. Express 3, 111003 (2010). 

74. Huang, C. Y. et al. Overcoming the excessive compressive strain in AlGaN epitaxy by introducing high Si-doping in Aln templates. Jpn. J. Appl. Phys. 59, 070904 (2020). 

75. Mohanbabu, A. & Mohankumar, N. Recessed Mg-doped P-type In0.2Ga0.8n cap gate AlGaN/GaN/AlGaN DH-HEMT for high breakdown and power electronics applications. In Proc. of 2016 International Conference on Inventive Computation Technologies. (IEEE, Coimbatore, 2016). 

76. Chen, Y. D. et al. High hole concentration in p-type AlGaN by indiumsurfactant-assisted Mg-delta doping. Appl. Phys. Lett. 106, 162102 (2015). 

77. Gunning, B. P. et al. Comprehensive study of the electronic and optical behavior of highly degenerate p-type Mg-doped GaN and AlGaN. J. Appl. Phys. 117, 045710 (2015). 

78. Kinoshita, T. et al. High p-type conduction in high-Al content Mg-doped AlGaN. Appl. Phys. Lett. 102, 012105 (2013). 

79. Nagata, K. et al. High-output-power AlGaN/GaN ultraviolet-light-emitting diodes by activation of Mg-doped p-type AlGaN in oxygen ambient. Phys. Status Solidi (A) 207, 1393–1396 (2010). 

80. Waldron, E., Graff, J. & Schubert, E. Influence of doping profiles on p-type AlGaN/GaN superlattices. Phys. Status Solidi (A) 188, 889–893 (2001). 

81. Hsu, L. & Walukiewicz, W. Theoretical transport studies of p-type GaN/AlGaN modulation-doped heterostructures. Appl. Phys. Lett. 74, 2405–2407 (1999). 

82. Xu, Q. J. et al. Mg acceptor activation mechanism and hole transport characteristics in highly Mg-doped AlGaN alloys. Chin. Phys. B 29, 058103 (2020). 

83. Kozawa, T. et al. UV photoemission study of AlGaN grown by metalorganic vapor phase epitaxy. Jpn. J. Appl. Phys. 39, L772–L774 (2000). 

84. Li, L. K. et al. High electron mobility AlGaN/GaN heterostructures grown on sapphire substrates by molecular-beam epitaxy. Appl. Phys. Lett. 76, 742–744 (2000). 

85. Smorchkova, I. P. et al. Polarization-induced charge and electron mobility in AlGaN/GaN heterostructures grown by plasma-assisted molecular-beam epitaxy. J. Appl. Phys. 86, 4520–4526 (1999). 

86. Polyakov, A. Y. et al. Scanning electron microscope studies of AlGaN films grown by organometallic vapor phase epitaxy. Solid-State Electron. 42, 637–646 (1998). 

87. Johnson, M. A. L. et al. Growth of GaN, InGaN, and AlGaN films and quantum well structures by molecular beam epitaxy. J. Cryst. Growth 175–176, 72–78 (1997). 

88. Xu, S. R. et al. Improvements in a-plane GaN crystal quality by AlN/AlGaN superlattices layers. J. Cryst. Growth 311, 3622–3625 (2009). 

89. Tsukihara, M. et al. Effect of middle temperature intermediate layer on crystal quality of AlGaN grown on sapphire substrates by metalorganic chemical vapor deposition. J. Cryst. Growth 300, 190–193 (2007). 

90. Shiojima, K. et al. Effect of epitaxial layer crystal quality on DC and RF characteristics of AlGaN/GaN Short-gate high-electron-mobility transistors on sapphire substrates. Jpn. J. Appl. Phys. 44, 8435–8440 (2005). 

91. Takano, T. et al. Improvement of crystal quality of AlGaN multi quantum well structure by combination of flow-rate modulation epitaxy and AlN/GaN multi-buffer layer and resultant lasing at deep ultra-violet region. Jpn. J. Appl. Phys. 43, L1258–L1260 (2004). 

92. Isono, K. I. et al. Improvement of crystal quality of n-AlGaN by alternatesource-feeding metal organic vapor phase epitaxy. Jpn. J. Appl. Phys. 46, 5711–5714 (2007). 

93. Li, Z. et al. Semi-polar (11-22) AlGaN on overgrown GaN on micro-rod templates: simultaneous Management of crystal quality improvement and cracking issue. Appl. Phys. Lett. 110, 082103 (2017). 

94. Gao, H. J. & Nix, W. D. Surface roughening of heteroepitaxial thin films. Ann. Rev.Mater. Sci. 29, 173–209 (1999). 

95. Zolper, J. C. Ion implantation in group III-nitride semiconductors: a tool for doping and defect studies. J. Cryst. Growth 178, 157–167 (1997). 

96. Kozodoy, P. et al. Enhanced Mg doping efficiency in Al0.2Ga0.8n/GaN superlattices. Appl. Phys. Lett. 74, 3681–3683 (1999). 

97. Adivarahan, V. et al. Indium-silicon co-doping of high-aluminum-content AlGaN for solar blind photodetectors. Appl. Phys. Lett. 79, 1903–1905 (2001). 

98. Du, Y. et al. Influence of Mg doping on the electronic structure and optical properties of GaN. Optoelectron. Adv. Mater. Rapid Commun. 5, 1050–1055 (2011). 

99. Zhang, Z. H. et al. AlGaN solar-blind p-i-n-i-n APDs employing a charge layer with modulated doping and bandgap. In Proc. of Asia Communications and Photonics Conference 2019. (Optical Society of America, Chengdu, 2019). 

100. Akasaki, I. et al. Photoluminescence of Mg-doped p-type GaN and electroluminescence of GaN p-n junction LED. J. Lumin. 48–49, 666–670 (1991). 

101. Amano, H. et al. P-type conduction in Mg-doped GaN treated with lowenergy electron beam irradiation (LEEBI). Jpn. J. Appl. Phys. 28, L2112–L2114 (1989). 

102. Amano, H. et al. Growth and luminescence properties of Mg-doped GaN prepared by MOVPE. J. Electrochem. Soc. 137, 1639–1641 (1990). 

103. Gökkavas, M. et al. AlGaN-based high-performance metal-semiconductormetal photodetectors. Photonics Nanostruct. 5, 53–62 (2007). 

104. Jiang, H. et al. Reduction of threading dislocations in AlGaN layers grown on AlN/sapphire templates using high-temperature GaN interlayer. Appl. Phys. Lett. 87, 241911 (2005). 

105. Bethoux, J. M. et al. Growth of high quality crack-free AlGaN films on GaN templates using plastic relaxation through buried cracks. J. Appl. Phys. 94, 6499–6507 (2003). 

106. Zhang, J. P. et al. Crack-free thick AlGaN grown on sapphire using AlN/AlGaN superlattices for strain management. Appl. Phys. Lett. 80, 3542–3544 (2002). 

107. Chen, C. Q. et al. AlGaN layers grown on GaN using strain-relief interlayers. Appl. Phys. Lett. 81, 4961–4963 (2002). 

108. Sun, W. H. et al. Fine structure of AlN/AlGaN superlattice grown by pulsed atomic-layer epitaxy for dislocation filtering. Appl. Phys. Lett. 87, 211915 (2005). 

109. Bell, A. et al. Spatial variation of luminescence from AlGaN grown by facet controlled epitaxial lateral overgrowth. Appl. Phys. Lett. 85, 3417–3419 (2004). 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 28 of 31 

110. Ishibashi, A. et al. Spatially resolved cathodoluminescence study on AlGaN layer fabricated by air-bridged lateral epitaxial growth. Phys. Status Solidi (B) 241, 2730–2734 (2004). 

111. Koida, T. et al. Improved quantum efficiency in nonpolar (1120) AlGaN/GaN quantum wells grown on GaN prepared by lateral epitaxial overgrowth. Appl. Phys. Lett. 84, 3768–3770 (2004). 

112. Kawaguchi, Y. et al. Low-dislocation density AlGaN layer by air-bridged lateral epitaxial growth. Phys. Status Solidi (C) 0, 2107–2110 (2003). 

113. Liu, R. et al. Thick crack-free AlGaN films deposited by facet-controlled epitaxial lateral overgrowth. Phys. Status Solidi (C) 0, 2136–2140 (2003). 

114. Chen, G. T. et al. Epitaxial lateral overgrowth of GaN on AlGaN/(111)Si micropillar array fabricated by polystyrene microsphere lithography. In Proc. of SPIE 6894, Gallium Nitride Materials and Devices III. 689408 (SPIE, San Jose, 2008). 

115. Mino, T. et al. Characteristics of epitaxial lateral overgrowth AlN templates on (111) Si substrates for AlGaN deep-UV leds fabricated on different direction stripe patterns. Phys. Status Solidi (C) 9, 802–805 (2012). 

116. Mogilatenko, A. et al. Defect analysis in AlGaN layers on AlN templates obtained by epitaxial lateral overgrowth. J. Cryst. Growth 402, 222–229 (2014). 

117. Kueller, V. et al. Growth of AlGaN and AlN on patterned AlN/sapphire templates. J. Cryst. Growth 315, 200–203 (2011). 

118. Cicek, E. et al. AlxGa1-xN-based solar-blind ultraviolet photodetector based on lateral epitaxial overgrowth of AlN on Si substrate. Appl. Phys. Lett. 103, 181113 (2013). 

119. Lee, D. et al. Improved performance of AlGaN-based deep ultraviolet lightemitting diodes with nano-patterned AlN/sapphire substrates. Appl. Phys. Lett. 110, 191103 (2017). 

120. Kueller, V. et al. Controlled coalescence of MOVPE grown AlN during lateral overgrowth. J. Cryst. Growth 368, 83–86 (2013). 

121. Conroy, M. et al. Epitaxial lateral overgrowth of aln on self-assembled patterned nanorods. J. Mater. Chem. C. 3, 431–437 (2015). 

122. Le, B. H. et al. Controlled coalescence of AlGaN nanowire arrays: an architecture for nearly dislocation-free planar ultraviolet photonic device applications. Adv. Mater. 28, 8446–8454 (2016). 

123. Mitrofanov, O., Manfra, M. & Weimann, N. Impact of Si doping on radio frequency dispersion in unpassivated GaN/AlGaN/GaN high-electronmobility transistors grown by plasma-assisted molecular-beam epitaxy. Appl. Phys. Lett. 82, 4361–4363 (2003). 

124. Jeon, S. R. et al. Investigation of Mg doping in high-al content p-type AlxGa1X<sup>N(0.3 < X < 0.5).Appl.Phys.Lett. 86,082107(2005).</sup> 

125. Sarkar, B. et al. N- and P- type doping in al-rich AlGaN and AlN. ECS Trans. 86, 25–30 (2018). 

126. Jung, W. H. et al. Activation energy, capture cross section, and emission frequency of the trap level in unintentionally doped N-type GaN epilayers grown on sapphire substrates in a nitrogen-rich atmosphere. Jpn. J. Appl. Phys. 39, L1084 (2000). 

127. Kim, D. J. et al. Thermal activation energies of Mg in GaN: Mg measured by the hall effect and admittance spectroscopy. J. Appl. Phys. 88, 2564–2569 (2000). 

128. Katsuragawa, M. et al. Thermal ionization energy of Si and Mg in AlGaN. J. Cryst. Growth 189-190, 528–531 (1998). 

129. Tokunaga, H. et al. Effects of growth pressure on AlGaN and Mg-doped GaN grown using multiwafer metal organic vapor phase epitaxy system. J. Cryst. Growth 272, 348–352 (2004). 

130. Namkoong, G., Doolittle, W. A. & Brown, A. S. Incorporation of Mg in GaN grown by plasma-assisted molecular beam epitaxy. Appl. Phys. Lett. 77, 4386–4388 (2000). 

131. van de Walle, C. G. & Neugebauer, J. First-principles calculations for defects and impurities: applications to III-nitrides. J. Appl. Phys. 95, 3851–3879 (2004). 

132. Zhong, H. X. et al. Reducing Mg acceptor activation-energy in Al0.83ga0.17n disorder alloy substituted by nanoscale (Aln)5/(Gan)1 superlattice using MgGa δ-doping: Mg local-structure effect. Sci. Rep. 4, 6710 (2014). 

133. Zhang, Z. H. et al. Nearly efficiency-droop-free AlGaN-based ultraviolet lightemitting diodes with a specifically designed superlattice p-type electron blocking layer for high Mg doping efficiency. Nanoscale Res. Lett. 13, 122 (2018). 

134. Nakarmi, M. L. et al. Enhanced p-type conduction in GaN and AlGaN by Mgδ-doping. Appl. Phys. Lett. 82, 3041–3043 (2003). 

135. Ji, Y. J., Du, Y. J. & Wang, M. S. Electronic structure and optical properties of Al and Mg Co-doped GaN. Chin. Phys. B 22, 117103 (2013). 

136. Zheng, T. C. et al. Improved p-type conductivity in Al-Rich AlGaN using multidimensional Mg-doped superlattices. Sci. Rep. 6, 21897 (2016). 

137. Aid, S. R. et al. Carrier activation in Mg implanted GaN by short wavelength Nd: YAG laser thermal annealing. Phys. Status Solidi (A) 214, 1700225 (2017). 

138. Zhou, H. et al. Enhancement-mode AlGaN/GaN fin-moshemts on Si substrate with atomic layer epitaxy MgCaO. IEEE Electron Device Lett. 38, 1294–1297 (2017). 

139. Wu, Z. L. et al. Improvement of properties in nonpolar a-plane p-AlGaN films by Mg-delta doping method. In Proc. of 2017 Conference on Lasers and Electro-Optics Pacific Rim. (IEEE, Singapore, 2017). 

140. Chen, Y. D. et al. Enhanced Mg doping efficiency in P-type GaN by indiumsurfactant-assisted delta doping method. Appl. Phys. Express 6, 041001 (2013). 

141. Wang, H. B. et al. Enhanced performance of P-GaN by Mg δ doping. J. Cryst. Growth 304, 7–10 (2007). 

142. Raffo, L. et al. Effects of Mg doping on the superconducting properties of YBa2Cu3O7-δ and La1.85sr0.15CuO4 systems. Superconductor Sci. Technol. 8, 409–414 (1995). 

143. Wang, X. et al. Experimental evidences for reducing Mg activation energy in high Al-content AlGaN alloy by MgGa δ doping in (AlN)m/(Gan)n superlattice. Sci. Rep. 7, 44223 (2017). 

144. Jiang, X. H. et al. Improvement of p-type conductivity in Al-Rich AlGaN substituted by MgGa δ-doping (Aln)m/(Gan)n (m ≥ n) superlattice. J. Alloy. Compd. 686, 484–488 (2016). 

145. Wierer, J. J. Jr. et al. Layer disordering and doping compensation of an intersubband AlGaN/AlN superlattice by silicon implantation. Appl. Phys. Lett. 105, 131107 (2014). 

146. Kuo, Y. K. et al. Advantages of InGaN solar cells with p-doped and high-alcontent superlattice AlGaN barriers. IEEE Photonics Technol. Lett. 25, 85–87 (2013). 

147. Zhang, W. et al. Interaction between Si doping and the polarization-induced internal electric field in the AlGaN/GaN superlattice. Appl. Phys. Lett. 99, 162105 (2011). 

148. Lopatiuk-Tirpak, O. et al. Electron irradiation-induced increase of minority carrier diffusion length, mobility, and lifetime in Mg-doped AlN/AlGaN short period superlattice. Appl. Phys. Lett. 91, 182103 (2007). 

149. Bai, J. et al. Influence of pyramidal defects on photoluminescence of Mgdoped AlGaN/GaN superlattice structures. Jpn. J. Appl. Phys. 41, 5909–5911 (2002). 

150. Simon, J. et al. Polarization-induced hole doping in wide-band-gap uniaxial semiconductor heterostructures. Science 327, 60–64 (2010). 

151. Verma, J. et al. N-polar III-nitride quantum well light-emitting diodes with polarization-induced doping. Appl. Phys. Lett. 99, 171104 (2011). 

152. Lebedev, V. et al. Defect related absorption and emission in AlGaN solar-blind UV photodetectors. Phys. Status Solidi (C) 2, 1360–1365 (2005). 

153. Wang, X. D. et al. Electro-optical characteristics for AlGaN solar-blind p-i-n photodiode: experiment and simulation. In Proc. of the 2012 12th International Conference on Numerical Simulation of Optoelectronic Devices. (IEEE, Shanghai, 2012). 

154. Dong, K. X. et al. Back-illuminated GaN/AlGaN solar-blind avalanche photodiodes. IEEE Photonics Technol. Lett. 27, 272–275 (2015). 

155. Dong, K. X. et al. AlGaN solar-blind avalanche photodiodes with p-type hexagonal boron nitride. IEEE Photonics Technol. Lett. 30, 2131–2134 (2018). 

156. Lebedev, V. et al. Space charge limited electron transport in AlGaN photoconductors. J. Appl. Phys. 101, 033705 (2007). 

157. Lebedev, V. et al. Gap state absorption in AlGaN photoconductors and solarblind photodetectors. Phys. Status Solidi (C) 1, 233–237 (2004). 

158. Walker, D. et al. AlGaN ultraviolet photoconductors grown on sapphire. Appl. Phys. Lett. 68, 2100–2101 (1996). 

159. Hirsch, E. A. et al. High-gain persistent nonlinear conductivity in highvoltage gallium nitride photoconductive switches. In Proc. of 2018 IEEE International Power Modulator and High Voltage Conference. 45–50 (IEEE, Jackson, 2018). 

160. Anagnostakis, E. A. On a generic equation modelling the persistent photoconductive response of semiconductor devices. Phys. Status Solidi (B) 177, 533–536 (1993). 

161. Anagnostakis, E. A. Negative differential mobility features in the persistent photoconductive response of semiconductor devices. Phys. Status Solidi (A) 136, 247–250 (1993). 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 29 of 31 

162. Anagnostakis, E. A. Determination of persistent photoconductivity within semiconductor epitaxial layers by photoconductive gain. Phys. Rev. B 46, 7593–7595 (1992). 

163. Blazey, K. W. & Schneider, J. Thermal detection of electron spin resonance in the persistent photoconductive state of semi-insulating GaAs crystals grown from pyrolytic BN crucibles. Appl. Phys. Lett. 48, 855–857 (1986). 

164. Khan, M. A. et al. High-responsivity photoconductive ultraviolet sensors based on insulating single-crystal GaN epilayers. Appl. Phys. Lett. 60, 2917–2919 (1992). 

165. Tut, T. et al. High bandwidth-efficiency solar-blind AlGaN schottky photodiodes with low dark current. Solid-State Electron. 49, 117–122 (2005). 

166. Sang, L. W. et al. AlGaN-based solar-blind schottky photodetectors fabricated on AlN/sapphire template. Chin. Phys. Lett. 25, 258–261 (2008). 

167. Osinsky, A. et al. Schottky barrier photodetectors based on AlGaN. Appl. Phys. Lett. 72, 742–744 (1998). 

168. Miyake, H. et al. High performance schottky UV detectors (265-100 nm) using n-Al0.5Ga0.5N on AlN epitaxial layer. Phys. Status Solidi (A) 200, 151–154 (2003). 

169. Biyikli, N. et al. Solar-blind AlGaN-based schottky photodiodes with low noise and high detectivity. Appl. Phys. Lett. 81, 3272–3274 (2002). 

170. Chuah, L. S., Hassan, Z. & Hassan, H. A. Performance improvement of large area GaN Msm photodiode with thin AlGaN surface layer. Microelectron. Int. 27, 140–142 (2010). 

171. Lee, K. H. et al. Nitride-based msm photodetectors with a hemt structure and a low-temperature AlGaN intermediate layer. J. Electrochem. Soc. 155, H959–H963 (2008). 

172. Marso, M. et al. Comparison of AlGaN/GaN MSM varactor diodes based on HFET and MOSHFET layer structures. In Proc. of 2006 International Conference on Advanced Semiconductor Devices and Microsystems. 229–232 (IEEE, Smolenice, 2006). 

173. Marso, M. et al. MSM varactor diodes based on AlGaN/GaN/SiC HEMT layer structures. In Proc. of the 5th International Conference on Advanced Semiconductor Devices and Microsystems. 151–154 (IEEE, Slomenice, 2004). 

174. Kishino, K. et al. Resonant-cavity-enhanced UV metal-semiconductor-metal (MSM) photodetectors based on AlGaN system. Phys. Status Solidi (A) 188, 321–324 (2001). 

175. Carrano, J. C. et al. Very low dark current metal-semiconductor-metal ultraviolet photodetectors fabricated on single-crystal GaN epitaxial layers. Appl. Phys. Lett. 70, 1992–1994 (1997). 

176. Monroy, E. et al. AlGaN metal-semiconductor-metal photodiodes. Appl. Phys. Lett. 74, 3401–3403 (1999). 

177. Li, J. L. et al. Picosecond response of gallium-nitride metal-semiconductormetal photodetectors. Appl. Phys. Lett. 84, 2091–2093 (2004). 

178. Yang, B. et al. High-performance back-illuminated solar-blind AlGaN metalsemiconductor-metal photodetectors. Electron. Lett. 36, 1866–1867 (2000). 

179. Brendel, M. et al. Top- and bottom-illumination of solar-blind AlGaN metalsemiconductor-metal photodetectors. Phys. Status Solidi (A) 212, 1021–1028 (2015). 

180. Averine, S. V. et al. Solar-blind MSM-photodetectors based on AlxGa1-xN/GaN heterostructures grown by MOCVD. Solid-State Electron. 52, 618–624 (2008). 

181. Brendel, M. et al. Solar-blind AlGaN MSM photodetectors with 24% external quantum efficiency at 0 V. Electron. Lett. 51, 1598–1600 (2015). 

182. Xie, F. et al. Ultra-low dark current alGaN-based solar-blind metalsemiconductor-metal photodetectors for high-temperature applications. IEEE Sens. J. 12, 2086–2090 (2012). 

183. Qiao, G. et al. Nanoplasmonically enhanced high-performance metastable phase α-Ga2O3 solar-blind photodetectors. ACS Applied. Mater. Interfaces 11, 40283–40289 (2019). 

184. Li, D. B. et al. Direct observation of localized surface plasmon field enhancement by kelvin probe force microscopy. Light: Sci. Appl. 6, e17038 (2017). 

185. Li, D. B. et al. Realization of a high-performance GaN UV detector by nanoplasmonic enhancement. Adv. Mater. 24, 845–849 (2012). 

186. Stockman, M. I. Nanoplasmonics: the physics behind the applications. Phys. Today 64, 39–44 (2011). 

187. Bao, G. H. et al. Enhanced spectral response of an AlGaN-based solar-blind ultraviolet photodetector with Al nanoparticles. Opt. Express 22, 24286–24293 (2014). 

188. Chen, C. H. et al. AlGaN metal-semiconductor-metal photodetectors with low-temperature AlN cap layer and recessed electrodes. Jpn. J. Appl. Phys. 49, 04DG05 (2010). 

189. Jiang, K. et al. Polarization-enhanced AlGaN solar-blind ultraviolet detectors. Photonics Res. 8, 1243–1252 (2020). 

190. Satterthwaite, P. F. et al. High responsivity, low dark current ultraviolet photodetectors based on two-dimensional electron gas interdigitated transducers. ACS Photonics 5, 4277–4282 (2018). 

191. Xie, Z. L. et al. AlGaN-based 330 nm resonant-cavity-enhanced p-i-n junction ultraviolet photodetectors using AlN/AlGaN distributed bragg reflectors. Phys. Status Solidi (C) 7, 1821–1824 (2010). 

192. Liu, C. H. et al. Highly ESD-reliable, nitride-based heterostructure p-i-n photodetectors with a p-AlGaN blocking layer. J. Electrochem. Soc. 155, H232–H234 (2008). 

193. Pernot, C. et al. Solar-blind UV photodetectors based on GaN/AlGaN p-i-n photodiodes. Jpn. J. Appl. Phys. 39, L387–L389 (2000). 

194. Xu, G. et al. High speed, low noise ultraviolet photodetectors based on GaN p-i-n and AlGaN(p)-GaN(i)-GaN(n) structures. Mater. Sci. Forum 264–268, 1441–1444 (1998). 

195. Parish, G. et al. High-performance (Al, Ga)N-Based solar-blind ultraviolet p-i-n detectors on laterally epitaxially overgrown GaN. Appl. Phys. Lett. 75, 247–249 (1999). 

196. Biyikli, N. et al. Solar-blind alGaN-based p-i-n photodiodes with low dark current and high detectivity. IEEE Photonics Technol. Lett. 16, 1718–1720 (2004). 

197. Collins, C. J. et al. Improved solar-blind detectivity using an AlXGA1-xN heterojunction p-i-n photodiode. Appl. Phys. Lett. 80, 3754–3756 (2002). 

198. McClintock, R. et al. High quantum efficiency AlGaN solar-blind p-i-n photodiodes. Appl. Phys. Lett. 84, 1248–1250 (2004). 

199. Cicek, E. et al. AlxGa1-xN-based back-illuminated solar-blind photodetectors with external quantum efficiency of 89%. Appl. Phys. Lett. 103, 191108 (2013). 

200. Wang, S. G. et al. High quantum efficiency back-illuminated AlGaN-based solar-blind ultraviolet p-i-n photodetectors. Chin. Phys. Lett. 29, 097302 (2012). 

201. Kuksenkov, D. V. et al. Low-frequency noise and performance of GaN p-n junction photodetectors. J. Appl. Phys. 83, 2142–2146 (1998). 

202. Gao, L. L. Investigation of back-illuminated AlGaN avalanche photodiodes with p-type graded AlxGa1-XN layer. Opt. Quantum Electron. 47, 1933–1940 (2015). 

203. Tut, T. et al. Experimental evaluation of impact ionization coefficients in AlxGa1-xN based avalanche photodiodes. Appl. Phys. Lett. 89, 183524 (2006). 

204. Huang, Z. Q. et al. AlGaN solar-blind avalanche photodiodes with enhanced multiplication gain using back-illuminated structure. Appl. Phys. Express 6, 054101 (2013). 

205. Zhang, S. K. et al. Effects of polarization fields on avalanche breakdown of AlGaN quantum-well photodiode. In Proc. of SPIE 8262, Gallium Nitride Materials and Devices VII. 826227 (SPIE, San Francisco, 2012). 

206. Cao, Z. X. et al. Dark current simulation of GaN/AlGaN p-i-n avalanche photodiode. In Proc. of the 2009 9th International Conference on Numerical Simulation of Optoelectronic Devices. (IEEE, USA, 2009). 

207. Wu, H. L. et al. All AlGaN epitaxial structure solar-blind avalanche photodiodes with high efficiency and high gain. Appl. Phys. Express 9, 052103 (2016). 

208. Cai, Q. et al. An improved design for solar-blind AlGaN avalanche photodiodes. IEEE Photonics J. 9, 6803507 (2017). 

209. Yao, C. J. et al. AlGaN solar-blind avalanche photodiodes with alInN/AlGaN distributed bragg reflectors. Appl. Phys. A 123, 439 (2017). 

210. Cai, Q. et al. AlGaN ultraviolet avalanche photodiodes based on a triple-mesa structure. Appl. Phys. Lett. 113, 123503 (2018). 

211. Sood, A. K. et al. GaN/AlGaN avalanche photodiode detectors for high performance ultraviolet sensing applications. In Proc. of SPIE 11129, Infrared Sensors, Devices, and Applications IX. 111290 F (SPIE, San Diego, 2019). 

212. Zhang, S. K. et al. Avalanche breakdown and breakdown luminescence of AlGaN multiquantum wells. Appl. Phys. Lett. 87, 262113 (2005). 

213. Cai, Q. et al. Performance modulation for back-illuminated AlGaN ultraviolet avalanche photodiodes based on multiplication scaling. IEEE Photonics J. 11, 6801507 (2019). 

214. McClintock, R. et al. Hole-initiated multiplication in back-illuminated GaN avalanche photodiodes. Appl. Phys. Lett. 90, 141112 (2007). 

215. Cai, Q. et al. Direct observation of reach-through behavior in back-illuminated AlGaN avalanche photodiode with separate absorption and multiplication structure. J. Phys. D 53, 425101 (2020). 

216. Carrano, J. C. et al. GaN avalanche photodiodes. Appl. Phys. Lett. 76, 924–926 (2000). 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 30 of 31 

217. Vashaei, Z. et al. GaN avalanche photodiodes grown on m-plane freestanding GaN substrate. Appl. Phys. Lett. 96, 201908 (2010). 

218. McClintock, R. et al. Avalanche multiplication in AlGaN based solar-blind photodetectors. Appl. Phys. Lett. 87, 241123 (2005). 

219. Tut, T. et al. AlxGa1-xN-based avalanche photodiodes with high reproducible avalanche gain. Appl. Phys. Lett. 90, 163506 (2007). 

220. Sun, L. et al. AlGaN solar-blind avalanche photodiodes with high multiplication gain. Appl. Phys. Lett. 97, 191103 (2010). 

221. Huang, Y. et al. Back-illuminated separate absorption and multiplication AlGaN solar-blind avalanche photodiodes. Appl. Phys. Lett. 101, 253516 (2012). 

222. Kim, J. et al. Comparison of AlGaN p-i-n ultraviolet avalanche photodiodes grown on free-standing GaN and sapphire substrates. Appl. Phys. Express 8, 122202 (2015). 

223. Joshi, V. et al. Dependence of avalanche breakdown on surface & buffer traps in AlGaN/GaN HEMTs. In Proc. of 2017 International Conference on Simulation of Semiconductor Processes and Devices. 109–112 (IEEE, Kamakura, 2017). 

224. Shao, Z. G. et al. High-gain AlGaN solar-blind avalanche photodiodes. IEEE Electron Device Lett. 35, 372–374 (2014). 

225. Dong, K. X. et al. Exploitation of polarization in back-illuminated AlGaN avalanche photodiodes. IEEE Photonics Technol. Lett. 25, 1510–1513 (2013). 

226. Bulmer, J. et al. Visible-blind APD heterostructure design with superior field confinement and low operating voltage. IEEE Photonics Technol. Lett. 28, 39–42 (2016). 

227. Shao, Z. et al. Significant performance improvement in AlGaN solar-blind avalanche photodiodes by exploiting the built-in polarization electric field. IEEE J. Sel. Top. Quant. Electron. 20, 3803306 (2014). 

228. Shao, Z. G. et al. Ionization-enhanced AlGaN heterostructure avalanche photodiodes. IEEE Electron Device Lett. 38, 485–488 (2017). 

229. Qu, H. M. et al. New Non-uniformity correction approach for infrared focal plane arrays imaging. J. Opt. Soc. Korea 17, 213–218 (2013). 

230. Li, Y. Y., Jin, W. Q. & Liu, Z. H. Interior radiation noise reduction method based on multiframe processing in infrared focal plane arrays imaging system. IEEE Photonics J. 10, 6803512 (2018). 

231. Huang, C. H. et al. Multispectral imaging of mineral samples by infrared quantum dot focal plane array sensors. Measurement 159, 107775 (2020). 

232. Martin, T. et al. 320 × 240 Pixel ingaas/inp focal plane array for short-wave infrared and visible light imaging. In Proc. of SPIE 5726, Semiconductor Photodetectors II. 85–91 (SPIE, San Jose, 2005). 

233. Datcu, S. et al. Focal plane array infrared camera transfer function calculation and image restoration. Optical Eng. 43, 648–657 (2004). 

234. Narlis, E. O. Comparative performance analysis of the mwir and lwir focal plane array starring imaging infrared systems. Int. J. Infrared Millim. Waves 23, 393–408 (2002). 

235. Haka, A. S., Levin, I. W. & Lewis, E. N. Uncooled barium strontium titanium focal plane array detection for mid-infrared fourier transform spectroscopic imaging. Appl. Spectrosc. 54, 753–755 (2000). 

236. Marcott, C. et al. Infrared microspectroscopic imaging of biomineralized tissues using a mercury-cadmium-telluride focal-plane array detector. Phosphorus Sulfur Silicon Relat. Elem. 144, 417–420 (1999). 

237. Lewis, E. N. et al. Si:As focal-plane array detection for fourier transform spectroscopic imaging in the infrared fingerprint region. Appl. Spectrosc. 51, 563–567 (1997). 

238. Lewis, E. N., Levin, I. W. & Crocombe, R. A. Applications of infrared imaging with a focal plane array detector and a step-scan FT-IR spectrometer. In Proc. of the 10th International Conference. 589–590 (Springer, Budapest, 1997). 

239. Beck, W. A. et al. in Quantum Well Intersubband Transition Physics and Devices (eds Liu, H. C., Levine, B. F. & Andersson, J. Y.) (Springer, 1994). 

240. McCauley, H. M. & Auborn, J. E. Image enhancement of infrared uncooled focal plane array imagery. In Proc. of SPIE 1479, Surveillance Technologies. (SPIE, Orlando, 1991). 

241. Li, X. J. et al. Analysis and design of low noise column stage in cmos roic for UV GaN focal plane array. In Proc. of SPIE 9521, Selected Papers from Conferences of the Photoelectronic Technology Committee of the Chinese Society of Astronautics 2014, Part I. (SPIE, China, 2015). 

242. Jia, H. X. et al. Effects of visible light on a readout integrated circuit for GaNbased UV focal plane array. Semiconductor Sci. Technol. 21, 112–115 (2006). 

243. Kang, Y. et al. 64 × 1 UV focal plane array of GaN p-i-n photodiodes. In Proc. of SPIE 5633, Advanced Materials and Devices for Sensing and Imaging II. 78–85 (SPIE, Beijing, 2005). 

244. Rimmer, A. N. An uncooled thermal-array-based detector as an advanced security sensor. In Proc. of SPIE 5403, Sensors, and Command, Control, Communications, and Intelligence (C3I) Technologies for Homeland Security and Homeland Defense III. 842-850 (SPIE, Orlando, 2004). 

245. Todd, M. A. et al. High-performance ferroelectric and magnetoresistive materials for next-generation thermal detector arrays. In Proc. of SPIE 4795, Materials for Infrared Detectors II. 88–99 (SPIE, Seattle, 2002). 

246. Berg, E. P. et al. Fast focal plane array detector and readout for pulsed optothermal radiometry. Anal. Sci. 17, s465–s468 (2001). 

247. Alessandrello, A. et al. The first step toward CUORE: cuoricino, a thermal detector array to search for rare events. Nucl. Phys. B-Proc. Suppl. 87, 78–80 (2000). 

248. Khrebtov, I. A. & Malyarov, V. G. Uncooled thermal ir detector arrays. J. Opt. Technol. 64, 511–522 (1997). 

249. Chu, K. M. et al. Improvement of adhesion and microwave transmission characteristics of indium bump by silver coating for low temperature flipchip applications. MRS Online Proc. Libr. 833, 78–83 (2004). 

250. Chu, K. M. et al. Characteristics of indium bump for flip-chip bonding used in polymeric-waveguide-integrated optical interconnection systems. Jpn. J. Appl. Phys. 43, 5922–5927 (2004). 

251. Gandhi, A. & Pathak, H. T. Lift-off technique for the growth of indium bumps for FPA. In Proc. of SPIE 3316, International Workshop on the Physics of Semiconductor Devices IX. 782–785 (SPIE, Delhi, 1998). 

252. Hoffman, A., Loose, M. & Suntharalingam, V. Cmos detector technology. Exp. Astron. 19, 111–134 (2005). 

253. Zhang, W. K., Chen, H. L. & Ding, R. J. Readout integrated circuit with multimode background suppression for long wavelength infrared focal plane arrays. Opt. Quant. Electron. 53, 4 (2021). 

254. Griffin, W. P., Raghunathan, A. & Roy, K. CLIP: circuit level IC protection through direct injection of process variations. IEEE Trans. Very Large Scale Integr. VLSI Syst. 20, 791–803 (2012). 

255. Gumenjuk-Sichevska, J. V. et al. Infrared photodetectors based on the system “Hg1-XcDxTe photodiode - direct-injection readout circuit”. Opto-Electron. Rev. 19, 198–205 (2011). 

256. Azuma, N., Usami, Y. & Nagata, M. Evaluation of environmental noise susceptibility of Rf circuits using direct power injection. In Proc. of 2009 IEEE International Symposium on Radio-Frequency Integration Technology. 80–83 (IEEE, Singapore, 2009). 

257. Alaeldine, A. et al. A direct power injection model for immunity prediction in integrated circuits. IEEE Trans. Electromagn. Compatibility 50, 52–62 (2008). 

258. Chin, Y. L. et al. New design structure of a direct-injection input circuit with adaptive gain control techniques. In Proc. of SPIE 3436, Infrared Technology and Applications XXIV. 129–137 (SPIE, San Diego,1998). 

259. Nagata, H. et al. Development of a cryogenic GaAs AC-coupled ctia readout for far-infrared and submillimeter detectors. In Proc. of SPIE 7020, Millimeter and Submillimeter Detectors and Instrumentation for Astronomy IV. (SPIE, Marseille, 2008). 

260. Farhoomand, J. et al. A 32 × 32 CTIA readout design for deep cryogenic applications. In Proc. of SPIE 6297, Infrared Spaceborne Remote Sensing XIV. 629711 (SPIE, San Diego, 2006). 

261. Huang, J. et al. CMOS readout circuit with CTIA for quantum well infrared photodetector in very long wavelength infrared application. In Proc. of the 2006 Joint 31st International Conference on Infrared Millimeter Waves and 14th International Conference on Teraherz Electronics. 147 (IEEE, Shanghai, 2006). 

262. Garcia, J. et al. A quad 1 × 16 cmos roic with fully differential CTIA-CDS for orthogonally modulated 2-D active imaging systems. In Proc. of 2005 IEEE LEOS Annual Meeting Conference Proceedings. 462–463 (IEEE, Sydney, 2005). 

263. Pullia, A. & Zocca, F. A self-adjusting constant-current source follower for CMOS preamplifiers of semiconductor detector signals. In Proc. of 2006 IEEE Nuclear Science Symposium Conference Record. 354–356 (IEEE, San Diego, 2006). 

264. Castoldi, A., Galimberti, A. & Guazzoni, C. Impact of non ideal signal transfer of on-chip source-follower JFET on silicon drift detector noise performance. In Proc. of 2006 IEEE Nuclear Science Symposium Conference Record. 1263–1267 (IEEE, San Diego, 2006). 

265. Pancheri, L. et al. Silicon pin detector with integrated JFET-based source follower. Electron. Lett. 40, 1301–1302 (2004). 

266. Lamarre, P. et al. AlGaN UV focal plane arrays. Phys. Status Solidi (A) 188, 289–292 (2001). 

Cai et al. Light: Science & Applications (2021) 10:94 

Page 31 of 31 

267. McClintock, R. et al. Back-illuminated solar-blind photodetectors for imaging applications. In Proc. of SPIE 5732, Quantum Sensing and Nanophotonic Devices II. 175–184 (SPIE, San Jose, 2005). 

268. Reine, M. B. et al. Solar-blind AlGaN 256 × 256 p-i-n detectors and focal plane arrays. In Proc. of SPIE 6119, Semiconductor Photodetectors III. (SPIE, San Jose, 2006). 

269. Reverchon, J. L. et al. AlGaN-based focal plane arrays for selective UV imaging at 310 nm and 280 nm and route toward deep UV imaging. In Proc. of SPIE 6744, Sensors, Systems, and Next-Generation Satellites Xi. (SPIE, Florence, 2007). 

270. Malinowski, P. E. et al. AlGaN-on-Si-based 10-μm pixel-to-pixel pitch hybrid imagers for the EUV range. IEEE Electron Device Lett. 32, 1561–1563 (2011). 

271. Cicek, E. et al. Crack-free AlGaN for solar-blind focal plane arrays through reduced area epitaxy. Appl. Phys. Lett. 102, 051102 (2013). 

272. Imura, M. et al. Microstructure of epitaxial lateral overgrown AlN on trenchpatterned AlN template by high-temperature metal-organic vapor phase epitaxy. Appl. Phys. Lett. 89, 221901 (2006). 

273. Zeimer, U. et al. High quality AlGaN grown on ELO AlN/sapphire templates. J. Cryst. Growth 377, 32–36 (2013). 

274. Tasi, C. T. et al. Reduction of defects in AlGaN grown on nanoscale-patterned sapphire substrates by hydride vapor phase epitaxy. Materials 10, 605 (2017). 

275. Li, S. B. et al. Polarization induced Pn-junction without dopant in graded AlGaN coherently strained on GaN. Appl. Phys. Lett. 101, 122103 (2012). 

276. Waldron, E. L., Graff, J. W. & Schubert, E. F. Improved mobilities and resistivities in modulation-doped p-type AlGaN/GaN superlattices. Appl. Phys. Lett. 79, 2737–2739 (2001). 

277. Kishimoto, K., Funato, M. & Kawakami, Y. Deposition of carbon-containing hole injection layers on p-type Al0.8ga0.2N grown by metalorganic vapor phase epitaxy. Appl. Phys. Lett. 117, 062101 (2020). 

278. Aoyagi, Y. et al. High hole carrier concentration realized by alternative codoping technique in metal organic chemical vapor deposition. Appl. Phys. Lett. 99, 112110 (2011). 

279. Kawanishi, H. & Tomizawa, T. Carbon-doped p-type (0001) plane AlGaN (Al = 6-55%) with high hole density. Phys. Status Solidi (B) 249, 459–463 (2012). 

280. Yoshikawa, A. et al. High-performance solar-blind Al0.6Ga0.4N/Al0.5Ga0.5N MSM type photodetector. Appl. Phys. Lett. 111, 191103 (2017). 

281. Gu, Y. et al. Analysis of high-temperature carrier transport mechanisms for high Al-content Al0.6Ga0.4N MSM photodetectors. IEEE Trans. Electron Devices 67, 160–165 (2020). 

282. Knigge, A. et al. AlGaN metal-semiconductor-metal photodetectors on planar and epitaxial laterally overgrown AlN/sapphire templates for the ultraviolet C spectral region. Jpn. J. Appl. Phys. 52, 08JF03 (2013). 

283. Rathkanthiwar, S. et al. Gain mechanism and carrier transport in high responsivity AlGaN-based solar blind metal semiconductor metal photodetectors. J. Appl. Phys. 121, 164502 (2017). 

284. Reddy, P. et al. High gain, large area, and solar blind avalanche photodiodes based on Al-rich AlGaN grown on AlN substrates. Appl. Phys. Lett. 116, 081101 (2020). 

285. McClintock, R. et al. Back-illuminated solar-blind photodetectors for imaging applications. In Proc. of SPIE 5732, Quantum Sensing and Nanophotonic Devices II. 175–184 (SPIE, San Jose, 2005). 

286. Kim, K. C. et al. Visible-blind ultraviolet imagers consisting of 8 × 8 AlGaN p-i-n photodiode arrays. J. Vac. Sci. Technol. A 24, 641–644 (2006). 

287. Duboz, J. Y. et al. UV imaging based on AlGaN arrays. Phys. Status Solidi (C) 6, S611–S614 (2009). 

288. McClintock, R. & Razeghi, M. Solar-blind photodetectors and focal plane arrays based on AlGaN. In Proc. of SPIE 9555, Optical Sensing, Imaging, and Photon Counting: Nanostructured Devices and Applications. (SPIE, San Diego, 2015). 

289. Iakovleva, N. I. et al. Analysis of current-voltage characteristics in UV AlGaN heterostructure FPAs. J. Commun. Technol. Electron. 64, 1046–1054 (2019). 

290. Rehm, R. et al. Toward AlGaN focal plane arrays for solar-blind ultraviolet detection. Phys. Status Solidi (A) 217, 1900769 (2020). 

