# Near-infrared phosphorescent carbon dots for sonodynamic precision tumor therapy

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Communications |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 359 |
| 作者 | Bi-Jiang Geng, Jin-Yan Hu, Yuan Li, Shi-Ni Feng, Deng-Yu Pan, Ling-Yan Feng, Long-Xiang Shen |
| DOI | 10.1038/s41467-022-33474-8 |
| 源文件 | 042_Geng_2022_Near-infrared-phosphorescent-carbon-dots-for-son.pdf |

---
Article 



https://doi.org/10.1038/s41467-022-33474-8 

# Near-infrared phosphorescent carbon dots for sonodynamic precision tumor therapy 

|Received: 13 December 2021<br>Accepted: 16 September 2022|Bijiang Geng<br>1, Jinyan Hu1, Yuan Li2, Shini Feng2, Dengyu Pan<br>1<br>,<br>Lingyan Feng<br>3<br>& Longxiang Shen<br>4|
|---|---|
|Check for updates|Theranostic sonosensitizers with combined sonodynamic and near infrared<br>(NIR) imaging modes are required for imaging guided sonodynamic therapy<br>(SDT). It is challenging, however, to realize a single material that is simulta-<br>neously endowed with both NIR emitting and sonodynamic activities. Herein,<br>we report the design of a class of NIR-emitting sonosensitizers from a NIR<br>phosphorescent carbon dot (CD) material with a narrow bandgap (1.62 eV) and<br>long-lived excited triplet states (11.4μs), two of which can enhance SDT as<br>thermodynamically and dynamically favorable factors under low-intensity<br>ultrasound irradiation, respectively. The NIR-phosphorescent CDs are identi-<br>fied as bipolar quantum dots containing both p- and n-type surface functio-<br>nalization regions that can drive spatial separation of e<sup>−</sup>–h<sup>+ </sup>pairs and fast<br>transfer to reaction sites. Importantly, the cancer-specific targeting and high-<br>level intratumor enrichment of the theranostic CDs are achieved by cancer cell<br>membrane encapsulation for precision SDT with complete eradication of solid<br>tumors by single injection and single irradiation. These results will open up a<br>promising approach to engineer phosphorescent materials with long-lived<br>triplet excited states for sonodynamic precision tumor therapy.|



Sonodynamic therapy (SDT), which utilizes low-intensity ultrasound (US) and crucial sonosensitizers to generate highly cytotoxic reactive oxygen species (ROS) for inducing tumor cell apoptosis, has recently been highlighted as a promising non-invasive therapeutic modality, because of remarkable therapeutic advantages in extending tissuepenetration deepness and reducing side effects<sup>1–5</sup> . A variety of sonosensitizers have been developed from organic compounds and metalbased inorganic nanoparticles (NPs) for enhanced SDT<sup>4,6–11</sup> . Albeit encouraging progress in the emerging SDT filed, low-yield ROS generation from sonosensitizers presents a major limitation in clinical transformation. It is thus of critical importance to manipulate thermodynamic and dynamical factors that promote the high-yield ROS generation of semiconductor sonosensitizers<sup>12–15</sup> . A narrow bandgap of a sonosensitizer is a beneficial thermodynamic factor because minimal energy is required to drive the generation of electron−hole (e<sup>−</sup> –h<sup>+</sup> ) 

pairs in low-intensity US settings<sup>6,16–20</sup> . The extended excited-state lifetime of a sonosensitizer is a favorable dynamical factor because long-lived charge carriers can participate in catalytic reactions with high probability before e<sup>−</sup> –h<sup>+</sup> pair recombination. Based on these considerations, it is a rationale for fabrication of a high-efficacy sonosensitizer that should be endowed with a narrow bandgap and an extended carrier lifetime for effective excitation, separation, and catalytic reactions of charge carriers. Nevertheless, canonical semiconductor sonosensitizers are based on titanium dioxide with a wide bandgap (>3 eV) and a short carrier lifetime (50 ns)<sup>21–23</sup> . 

With the advent of precision medicine, increasing interest focuses on the development of theranostic nanomedicines for precision cancer therapy<sup>24–26</sup> . Towards this objective, theranostic sonosensitizers with combined sonodynamic and imaging modes are required for imaging guided SDT to determine the optimal SDT window<sup>27,28</sup> . 

> 1School of Environmental and Chemical Engineering, Shanghai University, Shanghai 200444, China. 2School of Life Sciences, Shanghai University, Shanghai 200444, China.<sup>3</sup> Materials Genome Institute, Shanghai University, Shanghai 200444, China.<sup>4</sup> Department of Orthopedic Surgery, Shanghai Jiao Tong University affiliated Sixth People’s Hospital, Shanghai 200233, China. e-mail: dypan617@shu.edu.cn; lingyanfeng@t.shu.edu.cn; 7250012700@shsmu.edu.cn 

Nature Communications |  (2022) 13:5735 

1 

Article 

https://doi.org/10.1038/s41467-022-33474-8 

Generally, near-infrared (NIR) fluorescent dyes are employed to label sonosensitizers<sup>8,29,30</sup> . However, dye labeling is limited by insufficient photostability, systemic toxicity, and increased fabrication costs. Moreover, typical NIR-fluorescent dyes such as Cy5.5 and indocyanine green (ICG) exhibit no or poor SDT performance owing to rapid e<sup>−</sup> –h<sup>+</sup> recombination<sup>1,4</sup> . Alternatively, NIR-fluorescent semiconductor quantum dots could be stable fluorescence probes, but their time-resolved PL spectra also exhibit high e<sup>−</sup> –h<sup>+</sup> pair recombination rates with a typical carrier lifetime in the range of a few ns<sup>31,32</sup> , leading to deactivation of intrinsic sonocatalytic activity. Currently, phosphorescent materials with afterglow emission at room temperature from longlived excited triplet states have received increasing interest for applications in optoelectronic devices, data security, and time-resolved bioimaging with minimal background interference<sup>33–35</sup> . Notably, electrons in excited triplet states are highly reactive with O2 molecules, a typical triplet-state quencher, to generate highly cytotoxic<sup>1</sup> O236,37. As a consequence, phosphorescent materials, in particular, NIRphosphorescent materials, could be specially designed as enhanced sonosensitizers owing to their ultralong carrier lifetimes and narrow bandgaps. To date, typical NIR-phosphorescent materials have been prepared from transition-metal (Re, Ru, Os, Ir, Pt, Pd, and Au) complexes<sup>38–41</sup> , which present limimiations to clinical applications owing to high metal toxicity as well as high costs. In such a scenario, the synthesis of NIR-phosphorescent materials from metal-free materials with excellent biocompatibility and low costs would be a groundbreaking tactic for the exploration of their phosphorescence imaging and SDT performance. 

Herein, we report the ‘phosphorescent sonosensitizer’ concept as a class of theranostic platforms for NIR imaging guided sonodynamic therapy using multifunctional carbon dots (CDs) with an ingenious p–n junction and a greatly narrow bandgap for enhanced charge separation dynamics and NIR excitation/emission as the paragon (Fig. 1). These distinct electronic structures endowed CDs with carrier 

excitation at low energy, charge separation at high efficiency, and great potential for many modern technologies, including LEDs, solar cells, photocatalytic agents, bioimaging, SDT, and PDT. We have developed a one-step synthetic strategy (microwave synthesis) for controlled synthesis of CDs with the conductivity types of CDs (p–, n–, and p–n junction) facilely engineered by sulfonic acceptors and/or N donators. Compared with previously reported preparation of p–n junction CDs involving complex post-treatments and long-time consumption<sup>42,43</sup> , our one-step and high-efficiency method is suitable for low-cost production. Interestingly, we found that the p–n junction CDs (p–n-CDs) possessed bright long-lived (11.4 μs) phosphorescence rather than widely reported short-lived (ns) fluorescence from CDs or graphene quantum dots<sup>42,43</sup> . Although they were dispersed in aqueous solutions or physiological media, they exhibited afterglow emission at room temperature without the need for stabilizing agents such as polyvinyl alcohol (PVA) or other matrices<sup>44–48</sup> . Moreover, they can emit NIR phosphorescence at 760 nm with phosphorescent efficiency as high as 17.6% as a result of the synergistic effects of electronwithdrawing and electron-donating modifications on the electronic structure. We also found thatthe p–n junction CDs exhibited enhanced 1O2 generation efficiency under US irradiation through three enhancement mechanisms: (1) highly effective inhibition of the e<sup>−</sup> –h<sup>+</sup> pair recombination through the p–n junction, (2) long-lived tripletstate mediated<sup>1</sup> O2 generation, (3) GSH depletion using overexpressed GSH as a hole sacrificial agent. Finally, we constructed a CD-based theranostic platform (p–n-CD@CCM) for NIR imaging guided sonodynamic therapy using cancer cell membrane (CCM) as the targeting agent and delivery system to overcome the in vivo limitations by freestanding CDs, such as rapid renal clearance owing to the ultrafine size<sup>49</sup> . Given the NIR imaging capability, excellent biocompatibility, enhanced US-mediated<sup>1</sup> O2 generation efficiency of p–n-CDs as well as the CCM targeting capability, we showed complete eradication of solid tumors by single injection and single irradiation. Our results will open 



Fig. 1 | Design and mechanism of p–n-CD@CCM for sonodynamic precision cancer therapy. Schematic illustration of cancer cell membrane encapsulated NIR- 

phosphorescent CDs with long-lived triplet excited states (T1) for tumor-specific NIR imaging and precision sonodynamic therapy. 

Nature Communications |  (2022) 13:5735 

2 

Article 

https://doi.org/10.1038/s41467-022-33474-8 



<!-- Start of picture text -->
(a) (b) p-CD n-CD p-n-CD<br>High<br>natural<br>light<br>200  o C 15 min BPEI 200  o C 15 min BPEI 200  o C 15 min<br>700 nm<br>excitation<br>p-CD n-CD p-n-CD Low<br>(c) (f) (i)<br>p-n-CD 2.7 ± 0.6 nm p-n-CD p-n-CD p-n-CD N 1 s p-n-CD S 2 p<br>C 1s pyrrolic N -SO3/2p3/2<br>0.21 nm (25.6 at.%)O 1s<br>-SO3/2p1/2<br>(9.8 at.%)<br>1 Diameter  2 3 ( nm ) 4 (8.1 at.%)S 2p N 1s graphitic N<br>50 nm 2 nm 200 400 600 396 399 402 405 160 165 170 175<br>Binding energy (eV) Binding energy (eV) Binding energy (eV)<br>(d) (g) (j)<br>p-CD 2.2 ± 0.4 nm p-CD p-CD p-CD C 1 s p-CD S 2 p<br>0.21 nm C 1s (42.0 at.%)O 1s C-C -SO3/2p3/2<br>-SO3/2p1/2<br>1 Diameter (nm) 2 3 (10.4 at.%)S 2p C-O<br>50 nm 2 nm 200Binding energy (eV)400 600 280 Binding energy (eV)285 290 295 160 Binding energy (eV)165 170 175<br>(e) (h) (k)<br>n-CD 2.3 ± 0.6 nm n-CD n-CD n-CD C 1 s n-CD N 1 s<br>pyrrolic N<br>C 1s C-C<br>0.21 nm (13.4 at.%)<br>O 1s<br>(14.0 at.%)<br>N 1s<br>1 Diameter (nm) 2 3 4 C-NC-O graphitic N<br>50 nm 2 nm 200 400 600 280 285 290 295 394 396 398 400 402 404 406<br>Binding energy (eV) Binding energy (eV) Binding energy (eV)<br>).(ytisItanenu. ).(ytisItanenu. ).(ytisItanenu.<br>).(au. ).(au. ).(au.<br>ytisItnen ytisItnen ytisItnen<br>).(au. ).(au. ).(au.<br>ytisItnen ytisItnen ytisItnen<br><!-- End of picture text -->

Fig. 2 | Synthesis and characterization of p-CDs, n-CDs, and p–n-CDs. a Microwave synthesis routes of p-CDs, n-CDs, or p–n-CDs using ICG, TNP + BPEI, or ICG + BPEI as the precursor, respectively. b Photographs and NIR fluorescence images of p-CDs, n-CDs, and p–n-CDs under natural light and 700 nm excitation, respectively. c–e TEM images and corresponding lateral size distribution of p–n- 

CDs (c), p-CDs (d), and n-CDs (e). f–h HRTEM images of p–n-CDs (f), p-CDs (g), and n-CDs (h). i–k XPS survey, high-resolution C 1s, N 1s, S 2p spectra of p–n-CDs (i), p-CDs (j), and n-CDs (k). A representative image of three biological replicates from each group is shown in (c–h). Source data are provided as a Source Data file. 

up a promising approach to engineer phosphorescent materials with NIR emission and long-lived triplet excited states for wide-range applications apart from sonodynamic precision tumor therapy. 

## Results 

Synthesis of CDs with different acceptor/donator modifications 

We developed a one-step microwave strategy for controlled synthesis of NIR-phosphorescent p–n-CDs finely decorated with sulfonic (SO3ˉ) acceptors and pyrrolic/graphitic N donators from the precursors of ICG and branched polyethylenimine (BPEI) (Fig. 2a). For comparison, p-type CDs (p-CDs) decorated with SO3− acceptors and n-type CDs (nCDs) decorated with pyrrolic/graphitic N donators were synthesized by microwave treatment of ICG only and 1,3,6-trinitropyrene+BPEI, respectively. The resulting p–n-CDs in concentrated aqueous solutions showed black color while concentrated solutions of p-CDs and n-CDs showed green and brown colors, respectively (Fig. 2b). The statistic size distribution from Transmission electron microscope (TEM) images (Fig. 2c–e) showed three kinds of ultrafine CDs have similar average sizes (2.7 ± 0.6 nm for p–n-CDs, 2.2 ± 0.4 nm for p-CDs, 2.3 ± 0.6 nm for n-CDs). Meanwhile, the high crystallinity of these CDs 

was observed in their high-resolution TEM (HRTEM) images (Fig. 2f–h), revealing a 0.21 nm crystal spacing corresponded to the (100) plane of graphite<sup>50,51</sup> . A broad distinct peak at approximately 22° can be detected in the X-raydiffraction(XRD) patterns (SupplementaryFig. 1), indicating a wider (002) layer spacing of these CDs<sup>52</sup> . The graphitic structure of the three kinds of CDs was confirmed by the Raman spectra (Supplementary Fig. 2), revealing that the D/G intensity ratio of 0.995, 0.930, and 0.974 for p–n-CDs, p-CDs, and n-CDs, respectively. Their surface modifications were analyzed by X-ray spectroscopy (XPS). The full-range XPS spectrum of p–n-CDs showed a high atomic content of N (9.8 at.%), S (8.1 at.%), and O (25.6 at.%) with S/O ratio approximating to that of SO3− groups (Fig. 2i). The high-resolution C 1s XPS spectrum showed peaks at 284.3, 286.0, 291.8 eV, attributable to the C–C, C–N, and C–S bonds, respectively (Supplementary Fig. 3). The high-resolution N 1s spectrum consists of a strong single peak at 399.0 eV and a weak peak at 400.9 eV, which were ascribed to pyrrolic and graphitic N, respectively. The high-resolution S 2p spectrum exhibited twocharacteristic SO3ˉ bands at168.6 and 169.9 eV.From the XPS analysis, p–n-CDs is characterized by modification with SO3ˉ acceptors (8.1 at.%), pyrrolic N (7.3 at.%), and graphitic N (2.5 at.%) 

Nature Communications |  (2022) 13:5735 

3 

Article 

https://doi.org/10.1038/s41467-022-33474-8 



<!-- Start of picture text -->
(a) p-n-CD p-CD n-CD (c)<br>p-CD n-CD p-n-CD<br>-2. 0<br>-1.50 eV<br>-1.36 eV<br>E Fn-1.0= -0.69 V-0.5 0.0 E Fp0.5= 0.75 V1.0 -1.0 -0.5 E Fp= 0.62 V0.0 0.5 -1.0 E Fn-0.5= -1.17 V0.0 0.5 1.0 -1.0 E Fn=- 1 .17 eV  -0.77 eV<br>(b) p-n-CDPotential (V vs. Ag/AgCl)Tauc plot Eg =1.62 eV p-CDPotential (V vs. Ag/AgCl)Tauc plot Eg =2.25 eV n-CDPotential (V vs. Ag/AgCl)Tauc plot Eg =2.26 eV 0 2.25 eV 2.26 eV 1.62 eV E Fn=-0.69 eV n-type<br>2.25 eV 2.26 eV E Fp= 0 .62 eV E p-typeFp=0.75 eV<br>1.5 1.62 eV h 2.0 (eV) 2.5 1.5 2.0 h 2.5 (eV)3.0 3.5 1.5 2.0 h  (eV)2.5 3.0 1. 0 0.75 eV 0.90 eV 0.85 eV<br>300 400 500 600 700 800 900 300 400 500 600 700 800 900 300 400 500 600 700 800 900<br>Wavelength (nm) Wavelength (nm) Wavelength (nm)<br>(d) (e) CD-1 (f) CD-2 (i) CD-1 CD-2 CD-3<br>CD-1 8 7.51 eV<br>7<br>6<br>200 300 400 500 600 700 200 300 400 500 600 700 E g=4.07 eV<br>CD-2 (g) Wavelength (nm) (h) Wavelength (nm) 5 4.14 eV 4.59 eV<br>CD-3 Red-shift  p-CD p-n-CD-1 4<br> p-n-CD-2 E g=1.92 eV<br>3 3.44 eV<br>E g=3.09 eV<br>2.67 eV<br>2<br>CD-3 1<br>1.05 eV<br>200 300 400 500 600 700 200 400 600 800 1000 1200<br>Wavelength (nm) Wavelength (nm) 0<br>2-241/C (F) cm 2-241/C (F) cm 2-241/C (F) cm<br>).au. 1/2h)( ).au. 1/2h)( ).au. 1/2h)(<br>( ytisItnen ( ytisItnen ( ytisItnen Potential (V vs. Ag/AgCl<br>).au. Os ).au. Os<br>(  oitbAnpros gallicrts reottnh ( oitbAnpros gallicrts reottnh<br>).( oitbAanprosu. gOsallicrts reottnh ).( ytisItnenau. Energy (eV)<br><!-- End of picture text -->

Fig. 3 | Tuning electronic structures of CDs with different modifications. a Conductivity type identification of CDs by measuring varied capacitance (C) with the applied potential in the Mott-Schottky relationship. The symbols EFp and EFn represent the Fermi levels of the p- and n-type semiconductors. b Absorption spectra and corresponding Tauc plots of p–n-CDs, p-CDs, and n-CDs. c Schematic illustration of the energy-band diagrams of the p-CDs, n- 

CDs, and p–n-CDs. d Molecular Models of CDs with different surface modifications (SO3-modified CD-1, SO3-pyrrolic N-modified CD-2, and SO3-pyrrolic N-graphitic N-modified CD-3). e–i Calculated UV–vis absorption spectra (e–g), fluorescence emission spectra (h), HOMO, LUMO, and bandgap (i) of CD-1, CD2, and CD-3 using TD-DFT methods. Source data are provided as a Source Data file. 

donators. For p-CDs, the XPS analysis showed their surface modification by rich SO3ˉ acceptors (10.4 at.%) (Fig. 2j and Supplementary Fig. 4). For n-CDs, their surface modification was dominated by pyrrolic and graphitic N donators (Fig. 2k and Supplementary Fig. 5). The surface modification of the three types of CDs was further demonstrated by Fourier transform infrared (FT-IR) spectra (Supplementary Fig. 6). The stretching vibration bands of –SO3, C–N, C = C, and C–S can be found in the FT-IR spectrum of p–n-CDs, suggesting the presence of SO3ˉ and N-containing heterocycles. Because of negative charge from SO3ˉ and positive charge from pyrrolic N, p-CDs, n-CDs and p–n-CDs showed Zeta potential of −25.3 ± 3.2 mV, +15.6 ± 2.1 mV, and −10.9 ± 1.6 mV, respectively (Supplementary Fig. 7). Supplementary Fig. 8 revealed that p–n-CDs were kept stable in physiological conditions (PBS and fetal bovine serum) because of high water solubility, indicating the excellent stability of p–n-CDs. 

### Modification-tuned electronic structures of CDs 

We then explored the modification-dependent electronic properties of the CDs with similar sizes. Electrochemical impedance spectroscopic analyses were conducted to identify their conductivity type, as shown in Fig. 3a. Like previously reported p–n-type graphene oxide quantum dots<sup>42</sup> , the p–n-CD electrode showed a MottSchottky relationship characterized by two straight lines with negative and positive slopes located in different potential ranges, confirming the co-existence of both p- and n-type conductivities. The Mott-Schottky relationship of the p-CD electrode showed a negative slope, corresponding to single p-type conductivity, while the Mott-Schottky relationship of the n-CD electrode exhibited a 

positive slope, indicating the n-type conductivity. These results showed that the conductivity types of CDs can be successfully regulated by controlling surface modification with electronwithdrawing and electron-donating moieties. 

The bandgap of these CDs was then determined by measuring UVvis absorption spectra in aqueous solutions (Fig. 3b), from which the (αE)<sup>2</sup> versus (E) plots were derived, where E is photon energy and α is the normalized adsorption coefficient. The p–n-CDs showed broad UV to NIR absorption with prominent absorption bands between 500 and 700 nm, suggesting a narrow bandgap. Based on the (αE)<sup>2</sup> −E plot, the bandgap of p–n-CDs was determined to be 1.62 eV. In contrast, the absorption spectra of p-CDs and n-CDs were confined in the UV-vis region with an absorption shoulder around 450 nm, and their bandgap was determined as 2.25 and 2.26 eV, respectively. According to electrochemical cyclic voltammetry (CV) measurements on CD electrodes (Supplementary Fig. 9), the conduction band minimum (CBM) of p- CDs, n-CDs and p–n-CDs, was determined to be located at −1.50, −1.36, and −0.77 eV (vs Ag/AgCl), respectively. Accordingly, the valence-band maximum (VBM) of p-CDs, n-CDs, and p–n-CDs was determined to be at 0.75, 0.90, and 0.85 eV (vs Ag/AgCl), respectively, based on VBM = CBM + bandgap. As demonstrated in energy-band diagrams of these CDs (Fig. 3c), the energy-band characteristics of CDs, including CBM, VBM, and the CBM-VBM gap are also dependent on their surface modification. Compared with p-CDs and n-CDs, p–n-CDs have a remarkable reduction in the CBM–VBM gap and much lower CBM position, which can be ascribed to the synergistic effects from simultaneous SO3 and pyrrolic N/graphitic N modification on the shift of the electronic bands. 

Nature Communications |  (2022) 13:5735 

4 

Article 

https://doi.org/10.1038/s41467-022-33474-8 

To understand the synergistic effects of electron-withdrawing and electron-donating modification on CD electronic structures, we established three kinds of sp<sup>2</sup> hybrid carbon molecules as simple CD models (Fig. 3d) and evaluated their electronic and optical properties using time-dependent density functional theory (TD-DFT). It should be noted that the relative comparison among the models could identify trends and suggest interpretations for the observed results. Figure 3e–i exhibited the absorption spectra, fluorescence emission spectra, and HOMO-LUMO energy gaps of the molecular CDs. The CD-1 molecule modified with SO3 only revealed a wide bandgap of 4.07 eV and an absorption spectrum confined in the UV range (Fig. 3e). However, the absorption and fluorescence peaks of CD-2 molecules were obviously red-shifted to the visible region after modification with pyrrolic N (Fig. 3f, h). The obtained CD-2 molecule exhibited a lower bandgap of 3.09 eV compared with CD-1 molecule (4.07 eV) (Fig. 3g). Furthermore, the simultaneous modification with SO3, pyrrolic N, and graphitic N in CD-3 results in the smallest HOMO-LUMO gap (1.92 eV) and the most extended absorption and fluorescence emission. Overall, the consistent experimental and calculation results clarified that the strong electron-withdrawing and electron-donating modification could finely tune the energy bands of CDs. 

### NIR phosphorescence, sonodynamic and GSH depletion properties of p–n-CD 

We investigated the PL properties of CD solutions, whose electronic structures have been modulated by SO3 and/or pyrrolic N/graphitic N. The wide-bandgap p-CDs and n-CDs emitted short-wavelength fluorescence at 430 nm and 470 nm, respectively, under UV excitation (Fig. 4a, b). In contrast, narrow bandgap p–n-CDs emitted NIR emission with PL maximum at 760 nm and maximum excitation at 700 nm (Fig. 4c). The p–n-CDs have absolute PL quantum yield of 17.6% and NIR emission brightness comparable to that of the clinically used ICG. Moreover, the p–n-CDs showed improved stability against photobleaching. The p–n-CDs exhibited no fluorescence attenuation after storage in aqueous solution at room temperature for 7 days, while ICG showed marked fluorescence quenching after 1D storage (Fig. 4d and Supplementary Fig. 10). The strong and stable PL emission of the water-soluble p–n-CDs in the NIR-I biowindow suggests that they can serve as a superior NIR probe for bioimaging. 

Since the carrier lifetime of a semiconductor is a key dynamic parameter for a variety of applications, time-resolved PL spectra of CDs was measured. The time-resolved PL spectra of the p-CDs and n-CDs exhibited fast PL decay with an average lifetime of 3.74 ns and 4.82 ns, respectively (Fig. 4e, f), revealing the CDs’ common fluorescence nature with short lifetime. Interestingly, the time-resolved PL spectrum of the p–n-CDs excited at 700 nm and detected at 760nm emission can be fitted by bi-exponential decay function with an average carrier lifetime of 11.4 μs (Fig. 4g), three orders of magnitude longer than that of the p-CDs and n-CDs. The extended carrier lifetime is an indicator of long-lived triplet excited states, from which electron transition to the ground state occurs by phosphorescence at room temperature. To further confirm the phosphorescence nature of p–n-CDs, PVA was used as a matrix to stabilize triplet excited states. The p–n-CD@PVA films exhibited phosphorescent emission at 778 nm and carrier lifetime as long as 185 ms (Fig. 4h, i). Generally, the co-existence of transient and long-lived components was commonly observed in phosphorescent materials, such as phosphorescent CDs<sup>44,53–55</sup> . To our surprise, there were no transient components (ns-scale lifetime) from the time-resolved PL spectra of the p–n-CD solution and the p–n-CD@PVA film apart from the longlived components (1.6 and 19.2 μs for the p–n-CD solution; 15.7, 87.6, 637.2 ms for the p–n-CD film). These results suggest that the e<sup>−</sup> –h<sup>+</sup> pair recombination from singlet excited states to the ground state could be inhibited by the p–n junction between different functional regions within single CDs. 

Inspired by the narrow bandgap, long carrier lifetime, and p–n junction configuration of NIR-phosphorescent p–n-CDs, we investigated their sonodynamic properties under low-intensity US irradiation (50 kHz, 3.0 W/cm<sup>2</sup> ) using 1,3-diphenylisobenzofuran (DPBF) as the<sup>1</sup> O2 probe. With increasing irradiation time from 0 to 5 min, the characteristic absorption peaks of DPBF rapidly disappeared (Fig. 4j), indicating that US-excited p–n-CDs as a sonosensitizer reacted with O2 to produce<sup>1</sup> O2 as highly cytotoxic ROS for SDT. In contrast, p-CDs and n-CDs with short carrier lifetime and wide bandgap showed no sonodynamic effect (Supplementary Fig. 11). For comparison with ICG with a narrow bandgap but with a short carrier lifetime (0.46 ns) (Supplementary Fig. 12), p–n-CDs showed notably enhanced US triggered<sup>1</sup> O2 generation. The<sup>1</sup> O2 generation efficiency was thus determined to be 0.220 min<sup>−1</sup> for p–n-CDs, 2.2 and 3.2 times that of ICG and TiO2, respectively (Fig. 4k). No significant decrease of DPBF absorption peaks can be observed in the DPBF + US, p–n-CDs + US (no DPBF), and ICG + US (no DPBF) groups (Supplementary Fig. 13), suggesting the USactivated<sup>1</sup> O2 generation behavior of p–n-CDs. To present direct evidence for the enhanced ROS generation capability for the p–n-CD sonosensitizer, electron spin resonance (ESR) spectra were measured using 2,2,6,6-tetramethylpiperidine (TEMP) as the trapping agent of 1O2. Compared with ICG and TiO2 sonosensitizers, p–n-CDs exhibited the strongest ESR signals characteristic of<sup>1</sup> O2 (Fig. 4l). For non-SDTactive p-CDs and n-CDs, no<sup>1</sup> O2 ESR signals were observed. These results suggest that the narrow bandgap and long carrier lifetime are two key factors for activating and enhancing SDT. Apart from the enhanced sonodynamic performance of p–n-CDs, the long-lived triplet excited states could endow p–n-CD with excellent photodynamic properties. As depicted in Supplementary Fig. 14, the characteristic absorption peak of the 1O2 probe DPBF at 412 nm decreased significantly under 660 nm laser irradiation in the presence of p–n-CDs, confirming the high photodynamic activity of p–n-CDs owing to the presence of long-lived triplet excited states. Because of the catalytic activity of long-lived triplet excited states, we proposed a triplet-state mediated<sup>1</sup> O2 generation mechanism (Fig. 4p), distinct from that of extensively reported inorganic sonosensitizers<sup>16,56–58</sup> . The long-lived triplet excited states of p–n-CDs could be available through US or NIR light excitation and then intersystem crossing (ISC) for phosphorescence emission and generation of<sup>1</sup> O2 because O2 molecules are a typical triplet-state quencher<sup>36,37</sup> . Given the tumor-specific microenvironment (TME) characterized by overexpressed GSH, we further explored the GSH depletion ability of the p–n-CD sonosensitizer using 5,5-dithiobis(2-nitrobenzoic acid) (DTNB) probe. Figure 4m revealed that the characteristic absorption peak of GSH significantly decreased with the extended US time, indicating that GSH could be acted as a hole-scavenger in the SDT process. The sonodynamic effect of p–nCDs in the presence of GSH was then measured to confirm the enhanced<sup>1</sup> O2 generation. It was found that the<sup>1</sup> O2 generation capability was further enhanced by GSH, which functions as a hole sacrificial agent to further inhibit e<sup>−</sup> –h<sup>+</sup> pair recombination (Fig. 4n, o). 

### In vitro precision SDT of p–n-CD@CCM 

It is known that typical inorganic nanomedicines with suitable sizes (20–200 nm) could circumvent rapid renal filtration and enable passive accumulation in tumor tissue by the enhanced permeability and retention (EPR) effect<sup>59–62</sup> , but these nanomedicines would be limited in clinical translation because of long-term safety concerns. Instead, recent studies have revealed that ultrasmall CDs could be used as highly biocompatible nanomedicines because they undergo rapid renal filtration without inducing significant long-term toxicity<sup>49</sup> . A critical issue to be addressed is how to improve tumor targeting or accumulation levels and elongate blood circulation half-life for CDbased nanomedicines. 

Recently, cancer cell membranes (CCM) derived from homologous tumors have been developed as efficient tumor-specific 

Nature Communications |  (2022) 13:5735 

5 

Article 

https://doi.org/10.1038/s41467-022-33474-8 



<!-- Start of picture text -->
(a) (b) (c) (d)<br>PLE PL p-CD PLE PL n-CD p-n-CD PLE PL<br>300 400 500 600 700 800 300 400 500 600 700 800 300 400 500 600 700 800<br>Wavelength (nm) Wavelength (nm) Wavelength (nm)<br>(e) (f) (g) (h)<br>p-CD Ex=350 nm n-CD Ex=365 nm p-n-CD Ex=680 nm p-n-CD film<br>Phos Em<br>=3.74 ns =4.82 ns =11.4  s Phos Ex 778 nm<br>0 20 40 60 80 100 0 20 40 60 80 100 0 20 40 60 80 100 500 600 700 800 900<br>Time (ns) Time (ns) Time (ns) Wavelength (nm)<br>(i) (j) (k) (l)<br>p-n-CD film Ex=700 nm 2 p-n-CD + US 0 min p-n-CDICG p-n-CD<br>phosphorescence decay  1 min 1 TiO2 ICG<br>t  = 185 ms 2 min3 min y=0.220x-0.036y=0.103x+0.021 TiO2<br>1<br>4 min y=0.072x-0.022 p-CD<br>5 min n-CD<br>US<br>0<br>0<br>0 2 4 6 8 400 600 800 0 1 2 3 4 5 3300 3400<br>Time (s) Wavelength (nm) Time (min) Magnetic field (G)<br>(m)1 p-n-CD + US + GSH (n) p-n-CD+US+GSH (o) 2 p-n-CD+GSH (p)Sn<br> 0 min 4 p-n-CD<br> 2 min 0 min ISC<br> 4 min 6 min 1 min2 min 1 y=0.220x-0.036y=0.363x-0.025 S1 T1 1O2<br> 8 min 2 3 min US<br>10 min 4 min5 min or FL Phos O2<br>0 NI R<br>0 0<br>300 400 500 600 400 600 800 0 1 2 3 4 5 S 0<br>Wavelength (nm) Wavelength (nm) Time (min)<br>). ). ).<br>au. au. au.<br>( ytis ( ytis ( ytis<br>n n n<br>Iten Iten Iten<br>).<br>st st st au.<br>n n n<br>u u u<br>o o o ( ytis<br>C C C n<br>Iten<br>).<br>Cstnou ( bbaecnarosu. -Ln(A/A)0 ).( ytisItanenu.<br>A<br>). ).<br>au. au.<br>(  (<br>e e<br>c c<br>n n<br>a a<br>bor bro -Ln(A/A)0<br>s s<br>b b<br>A A<br><!-- End of picture text -->

Fig. 4 | NIR phosphorescence, sonodynamic and GSH depletion properties of p–n-CDs. a–c PL and excitation (PLE) spectra of p-CDs (a), n-CDs (b), and p–n-CDs (c). d NIR emitting stability contrast between p–n-CDs and ICG in aqueous solutions stored for 0, 1, 3, and 7 days. The excitation and emission wavelengths were 700 and 790 nm, respectively. e–g Time-resolved PL spectra and the corresponding fitting curves of p-CDs (e), n-CDs (f), and p–n-CDs (g). h Phosphorescence excitation and emission spectra of p–n-CD@PVA films. i Time-resolved phosphorescence spectrum and the corresponding fitting curve of p–n-CD@PVA. j Time-dependent 1O2 generation of p–n-CDs under US irradiation (50 kHz, 3.0 W/cm2) for 5 min detected with the DPBF probe. k Rate constant of US triggered<sup>1</sup> O2 generation in the 

presence of p–n-CDs, ICG, and TiO2 under the same US irradiation. l ESR spectra of US triggered<sup>1</sup> O2 generation in the absence and presence of p–n-CDs, p-CDs, n-CDs, ICG, or TiO2 using TEMP as the trapping agent of<sup>1</sup> O2. m GSH depletion by holes produced from US-excited p–n-CDs. n Enhanced US triggered<sup>1</sup> O2 generation by p–n-CDs in the presence of GSH (1 mM) as the hole quencher. o Rate constant of<sup>1</sup> O2 generation in the presence of p–n-CD under US irradiation with or without the addition of GSH (1 mM). p Schematic illustration of phosphorescence emission and 1O2 generation mechanisms of p–n-CDs from long-lived excited triplet states via ISC. The concentrations of indicated samples (p–n-CD, p-CD, n-CD, ICG, and TiO2) were all 200 µg/mL. Source data are provided as a Source Data file. 

delivery vehicles because cancer-specific proteins are retained on the surface enabling homotypic recognition to the same cancer cell lines<sup>63–65</sup> . Encouraged by the promise of CCMs in cancer-specific drug delivery, we prepared two kinds of p–n-CD loaded CCM vehicles, p–nCD@143B and p–n-CD@Hela, derived from human osteosarcoma 143B cells and Human cervical cancer Hela cells, respectively, by a successive extrusion approach. 

TEM images of representative p–n-CD@CCM vehicles revealed the superficial coverage of the CCM layer and the presence of loaded p–n-CDs in the interior cavity, indicating that ultrafine p–n-CDs were successfully encapsulated into CCM vehicles (Fig. 5a, b and Supplementary Fig. 15). The amount of encapsulated p–n-CDs in p–nCD@CCM was determined by UV-vis-NIR absorption spectroscopy. After removing unloaded p–n-CDs through centrifugation, the loading rate of p–n-CD in p–n-CD@CCM can be determined to be 20%. Western blotting analysis (Fig. 5c) showed source membrane markers were 

well retained in the CCM vehicles, including two plasma membranespecific markers (cadherins and Na+ /K+ -ATPase) and a widely reported tumor-associated transmembrane protein (glycoprotein 100 or gp100). In contrast, intracellular protein markers of Histone H3 and COXIV were eliminated from CCMs, demonstrating the selective retention of membrane fragments after the treatment. The average hydrodynamic diameter of unloaded CCM and p–n-CD@CCM vehicles was 68.1 ± 1.9 nm and 78.8 ± 1.3 nm, respectively (Fig. 5d). No visible precipitate was observed in PBS and FBS solutions after storing for 7 days (Supplementary Fig. 17a), demonstrating the excellent stability of p–n-CD@CCM in the physiological environment for medical applications. The high stability of p–n-CD@CCM in aqueous solution was further evaluated by measurement of change in hydrodynamic diameter and Zeta potential during storage. There was no substantial change in hydrodynamic diameter and Zeta potential after storing for 7 days (Supplementary Fig. 17b, c). 

Nature Communications |  (2022) 13:5735 

6 

Article 

https://doi.org/10.1038/s41467-022-33474-8 



<!-- Start of picture text -->
(a) p-n-CD@CCM (b) p-n-CD@CCM (c)pan CadherinCell lysate CCM 120 kDa (d) 30 p-n-CDCCM<br>p-n-CD Na+/K+-ATPase 113 kDa p-n-CD@CCM<br>20<br>10.1 nm 68.1 nm<br>gp100 70 kDa 78.8 nm<br>10<br>Histone H3 15 kDa<br>COXIV 15 kDa<br>0<br>100 nm CCM 20 nm GAPDH 37 kDa 1 10 100 1000<br>Size (nm)<br>(e) p-n-CD@143B (f) p-n-CD@HeLa (g) p-n-CD 24 h (h) p-n-CD@CCM 24 h<br>143B 143B 100 48 h 100 48 h<br>50 50<br>0 0<br>20 μm 20 μm 0 12 25 50 100 200 0 12 25 50 100 200<br>(i) Concentration (μg/mL) (j) Concentration (μg/mL)<br>p-n-CD@CCM+US 24 h Control<br>HeLa 633 nm HeLa 633 nm 48 h US<br>100 100 p-n-CD@CCM<br>ICG<br>p-n-CD+US<br>p-n-CD@CCM+US<br>50 50<br>0 0<br>20 μm 20 μm 0 12 25 50 100 200 Groups<br>Concentration (μg/mL)<br>(k) Control  p-n-CD@CCM p-n-CD+US  p-n-CD@CCM+US (l) Control  p-n-CD@CCM p-n-CD+US  p-n-CD@CCM+US<br>Calcein-AM DCFH-DA<br>PI DAPI<br>Merged Merged<br>200 μm 20 μm<br>)%<br>( r<br>e<br>b<br>m<br>u<br>N<br>Relative cell viability (%) Relative cell viability (%)<br>Relative cell viability (%) Relative cell viability (%)<br><!-- End of picture text -->

Fig. 5 | In vitro precision SDT of p–n-CD@CCM. a, b TEM images of p–nCD@CCM. c Western blotting analysis of cell lysate and CCM by membrane-specific (pan-cadherin, Na+/K+-ATPase, and gp100) and intracellular protein markers (Histone H3 and COXIV). d Hydrodynamic diameter of free p–n-CDs, CCM, and p–nCD@CCM. e, f Cancer-specific confocal images of 143B and Hela cells incubated with p–n-CD@Hela or p–n-CD@143B, respectively. g, h Relative cell viability of 143B cells incubated with free p–n-CDs (g) or p–n-CD@CCM (h) at varied concentrations 

without US irradiation (n = 5 biologically independent samples). i Relative cell viability of 143B cells incubated with p–n-CD@CCM under US irradiation (50 kHz, 3.0 W/cm<sup>2</sup> ) (n = 5 biologically independent samples). j–l Relative cell viability (j) (n = 5 biologically independent samples), live/dead cell staining (k), and ROS staining (l) of 143B cells after indicated treatments. Data are presented as mean values ± SD. A representative image of three biological replicates from each group is shown in (a–c), (e), (f), (k), (l). Source data are provided as a Source Data file. 

We then investigated the sonodynamic properties of p–nCD@CCM, revealing that the characteristic absorption peaks of DPBF at 412 nm rapidly disappeared with increasing the US irradiation time (Supplementary Fig. 18a). The 1O2 generation efficiency of p–n-CD@CCM was thus calculated to be 0.212 min<sup>−1</sup> (Supplementary Fig. 18b), which was similar to that of pristine p–nCD (0.220 min<sup>−1</sup> ), indicating that encapsulation into CCM will not affect the excellent sonodynamic performance of p–n-CDs. To confirm the homotypic recognition capability and assess in vitro targeting efficacy of p–n-CD@CCM vehicles, p–n-CD@143B was incubated with 143B cells using Hela cells as a negative control, and 

cell images excited at 633 nm were taken by a confocal laser scanning microscopy (CLSM). The sharp contrast between bright green fluorescence of 143B cells and dark green fluorescence of Hela cells revealed that p–n-CD@143B can specifically recognize 143B cells with high uptake levels owing to the retained 143B cell membrane markers (Fig. 5e). Similarly, p–n-CD@Hela can specifically differentiate Hela cells from 143B cells, as shown in Fig. 5f. These results clearly demonstrated it is feasible to design p–nCD@CCM as the cancer-specific NIR probe for precise bioimaging via CCM-based homotypic recognition. The in vitro imaging also showed that p–n-CDs as a sonosensitizer can be facilely delivered 

Nature Communications |  (2022) 13:5735 

7 

Article 

https://doi.org/10.1038/s41467-022-33474-8 

by CCM vehicles and internalized into the cytoplasm of target cells for SDT. 

Prior to in vitro SDT evaluation, the biosafety of p–n-CD@CCM at a cellular level was assessed. The cytotoxicity of p–n-CDs and p–nCD@CCM was tested by the MTT assay at varied concentration of 0–200 μg/mL. It was found that no obvious cytotoxicity was induced by p–n-CDs or p–n-CD@CCM even at 200 μg/mL, suggesting a good biosafety for SDT application (Fig. 5g, h). To reveal the in vitro SDT performance of p–n-CD@143B against target 143B cells, we performed the MTT assay under US irradiation (50 kHz, 3.0 W/cm<sup>2</sup> ) for 5 min. Substantial concentration-dependent cell toxicity was induced by p–nCD@CCM even at lower concentrations under US irradiation (Fig. 5i). To demonstrate the enhanced SDT performance of p–n-CD@CCM, relative cell viability of 143B cells against the control for 48 h incubation was compared for different treatment groups, including US, p–nCD@CCM, ICG + US, p–n-CD + US, and p–n-CD@CCM + US under the same concentration (200 μg/mL) and US irradiation conditions. Both p–n-CD + US and p–n-CD@CCM + US groups exhibited the highest SDT effect with little discrepancy at the cellular levels (Fig. 5j). It should be pointed out that ICG has the same functions for NIR imaging and SDT as p–n-CDs, but it only exhibited a lower SDT effect, because of its much shorter carrier life than that of p–n-CDs. 

We further investigated the SDT effect of p–n-CD@CCM using the calcein-AM and PI co-staining assay. Remarkable cell death corresponding to PI-positive cells was observed by fluorescence microscope after p–n-CD mediated SDT or p–n-CD@CCM mediated SDT (Fig. 5k and Supplementary Fig. 19, 21a), confirming the excellent SDT efficacy of p–n-CDs or p–n-CD@CCM. Moreover, we performed the apoptosis assay through the flow cytometry using Annexin V-FITC and PI staining. As presented in Supplementary Fig. 22, significant apoptosis of 143B cells was detected in the p–n-CD + US and p–n-CD@CCM + US groups. To investigate the antitumor mechanism of p–n-CDs in cellular level, we evaluated the intracellular ROS levels using DCFH-DA staining assay. The 143B cells in the control group, US irradiation alone group, and p–n-CD@CCM alone group exhibited no obvious ROS fluorescence signal (Fig. 5l and Supplementary Figs. 20, 21b). In contrast, the strongest green fluorescence located in the cytoplasm was observed in p–n-CD + US and p–n-CD@CCM + US groups, confirming the ROSmediated cell death induced by p–n-CD-based SDT. 

### In vivo precision SDT of p–n-CD@CCM 

To achieve precision SDT of tumors, we first assessed the tumorspecific in vivo NIR imaging capability of p–n-CD@143B. 143B and Hela tumors were simultaneously transplanted at two sides of the same mice for in vivo NIR imaging with intravenously injected free p–n-CDs and p–n-CD@143B as the probe excited at 700 nm. For free p–n-CDs, there was no substantial accumulation at 143B or Hela tumor sites because of rapid renal filtration of p–n-CDs (Fig. 6b and Supplementary Fig. 23a). Interestingly, p–n-CD@143B specifically accumulated in 143B tumors because of the homotypic recognition nature of CCM143B (Fig. 6c and Supplementary Fig. 23b). The highest NIR fluorescence signal in the tumor tissue was detectable at 12-24 h postinjection. Significant retention of p–n-CD@143B was mainly found in the liver and the 143B tumor at the 12 h and 24 h post-injection, with little retention in the Hela tumor (Fig. 6d and Supplementary Fig. 24a). Similarly, p–n-CD@Hela can specifically accumulated in Hela tumors, as depicted in Supplementary Figs. 24, 25, 26b. These results clearly verified the excellent in vivo imaging capability of p–n-CD@CCM at the NIR-I biowindow, tumor-specific recognition potential, and high intratumoral levels. 

We next evaluated in vivo SDT effects of p–n-CD@CCM for precision tumor therapy. Six groups of 143B tumor-bearing mice were randomly divided as followed: Group 1: Control, Group 2: US, Group 3: p–n-CD@CCM, Group 4: ICG + US, Group 5: p–n-CD + US, Group 6: p–n-CD@CCM + US. According to the in vivo NIR imaging result, single 

US irradiation (50 kHz, 3.0 W/cm<sup>2</sup> , 5 min) was performed at 24 h after single i.v. injection of p–n-CD@CCM (2.0 mg/kg) (Fig. 6a). The timedependent change of treated 143B tumors in volume and weight exhibited consistent SDT effects (Fig. 6e, f). That is, no tumor growth inhibition effects were observed in the US, ICG + US, and p–nCD@CCM groups; a limited tumor inhibition was induced by p–nCD + US; a complete tumor eradication was realized by p–nCD@CCM + US during 16 days (Supplementary Fig. 27). Importantly, the mice percent survival was greatly improved by p–n-CD@CCM + US, with no death observed in the 60-day treatment/observation duration (Fig. 6g). The excellent SDT therapeutic effects of p–nCD@CCM were also demonstrated by the ROS staining of tumor tissues. The p–n-CD@CCM + US group possessed the highest ROS levels in tumor tissues (Fig. 6i). Haematoxylin and eosin (H&E) staining was then carried out to analyze the SDT efficacy of p–n-CD@CCM, which exhibited the most severe damage of tumors (Fig. 6j). To investigate whether tumor cells in tissue were apoptosis on day 4 or 5, the tumor sections in each groups were collected on the fourth day posttreatment and subjected to terminal deoxynucleotidyl transferase dUTP nick-end labeling (TUNEL) staining. Supplementary Fig. 28 revealed that the tumor in p–n-CD@CCM + US group showed severe apoptosis and necrosis. Together, these in vivo SDT effects further revealed that it is of importance to design a high-efficacy sonosensitizer with tumor-specific targeting capability, as confirmed by the model p–n-CD@CCM sonosensitizer. 

Considering that US wave possessed high tissue-penetration depth, the in vivo deep-tissue SDT was then performed to evaluate the potential therapeutic effect of p–n-CD@CCM. We established two 143B tumors on the left and right sides of mice and the US treatments were performed from left to right (Supplementary Fig. 29a). The left and right tumors rapidly grew in the control group (Supplementary Fig. 29b). Significantly, the tumor growth on both sides was completely inhibited for mice treatment with p–n-CD@CCM plus US irradiation from left to right. These results clearly demonstrated that the US treatments could penetrate through the body of mice and the highefficiency p–n-CD@CCM sonosensitizers could be applicable for deeptissue SDT. 

The pharmacokinetic examination of p–n-CD and p–n-CD@CCM sonosensitizers after systemic injection were then investigated. The plasma concentration-time profiles of p–n-CD and p–n-CD@CCM samples showed a typical double-compartment pharmacokinetic behavior (Supplementary Fig. 30). For free p–n-CDs without CCM coating, the elimination half-life (t1/2) was only 0.8 ± 0.1 h, revealing rapid renal clearance owing to the ultrafine size (2.2 ± 0.4 nm), like previous reports on CDs. In contrast, after CCM coating, the half-life was elongated to 11.6 ± 0.9 h, 14.5 times of that of free p–n-CDs, indicating that the typical renal clearing process of CDs was inhibited by CCM coating. The longer circulation time allowed p–n-CD@CCM to enrich in tumors at high levels. The in vivo biodistribution and excretion pathway of p–n-CD@CCM were explored for examination of its in vivo metabolic process. Supplementary Fig. 31a revealed that p–nCD@CCM primarily accumulated in liver at 24 h post-injection due to the capture of the reticuloendothelial system. Importantly, no obvious p–n-CD signals were observed in these organs after 14 days, suggesting the nearly complete clearance of p–n-CD@CCM. To study the excretion pathway, the p–n-CD concentrations in the urine and feces were also measured. Much higher levels of p–n-CD were observed in the feces, demonstrating that p–n-CD@CCM was eliminated from the mice majorly by liver excretion (Supplementary Fig. 31b). 

Finally, we investigated the potential long-term toxicity of p–nCD@CCM through the histopathological measurement, biochemical blood analysis, and blood routine examination. During the treatment period, negligible fluctuation of the mice weight can be observed in each group (Fig. 6h). For histopathological measurement, no obvious damages in major organs were detected after different treatments 

Nature Communications |  (2022) 13:5735 

8 

Article 

https://doi.org/10.1038/s41467-022-33474-8 



<!-- Start of picture text -->
(a)<br>(b) 0 h 1 h 2 h 4 h 8 h 24 h High (c) Control 4 hp-n-CD@143B12 h 24 h 48 h<br>Heart High<br>HeLa 143B Liver<br>Low Spleen<br>(d) Lung<br>0 h 4 h 12 h 24 h 48 h 72 h High<br>Kidney<br>Left tumor<br>HeLa 143B (Hela)<br>Right tumor<br>Low (143B) Low<br>(e) (f) 8 (g) (h)25<br>p-n-CD@CCM+US Control 100<br>2000 p-n-CD+USICG+US 6 USp-n-CD@CCM 80 20<br>p-n-CD@CCM ICG+US<br>US p-n-CD+US 60 Control 15 p-n-CD@CCM+US<br>1000 Control 4 p-n-CD@CCM+US P  = 2.1E-8 40 USp-n-CD@CCM 10 p-n-CD+USICG+US<br>2 20 ICG+USp-n-CD+US 5 p-n-CD@CCMUS<br>p-n-CD@CCM+US Control<br>0 0 0 0<br>0 2 4 6 8 10 12 14 16 18 0 10 20 30 40 50 60 70 80 0 2 4 6 8 10 12 14 16<br>Groups<br>Time (days) Time (days) Time (days)<br>(i) Control  US  p-n-CD@CCM ICG+US  p-n-CD+US  p-n-CD@CCM+US<br>DHE<br>DAPI<br>Merged<br>200 μm<br>(j)<br>H&E<br>200 μm<br>p-n-CD<br>B<br>3<br>4<br>1<br>@<br>D<br>C<br>p-n-<br>3)<br>(mme )(htg<br>ulomromv 000 P  .12= Tumor weight (g) Percent survival giedBowy<br>u<br>T<br><!-- End of picture text -->

Fig. 6 | In vivo precision SDT of p–n-CD@CCM. a SDT protocol of p–n-CD@143B (2.0 g/kg) under single US irradiation on 143B tumor-bearing mice. b In vivo NIR imaging of mice with free p–n-CDs. c Tumor-specific in vivo NIR imaging of mice with p–n-CD@143B. d Ex vivo NIR imaging of major tissues and tumors with p–nCD@143B. e 143B tumor growth curves of mice after indicated treatments (n = 5 biologically independent samples). f 143B tumor weight after indicated treatments (n = 5 biologically independent samples). g Survival curves of mice after indicated 

treatments. h Body weight of mice after indicated treatments. i ROS staining images of tumors after indicated treatments with DHE as the ROS probe. j H&E staining images of tumors after indicated treatments. Data are presented as mean values ± SD. Statistical significance was calculated with two-tailed Student’s t test (e) and (f). A representative image of three biological replicates from each group is shown in (i), (j). Source data are provided as a Source Data file. 

(Supplementary Fig. 32), indicating the insignificant adverse effects of p–n-CD@CCM. Furthermore, all the blood biochemical and blood routine indexes in each groups were located in the normal range (Supplementary Fig. 33), suggesting the good biocompatibility of p–n-CD@CCM. 

## Discussion 

Recently, CDs have been engineered as promising fluorescent materials owing to their numerous merits such as high optical stability, excellent solubility, low toxicity, and easy preparation. Generally, single-component CDs do not exhibit observable phosphorescence 

Nature Communications |  (2022) 13:5735 

9 

Article 

https://doi.org/10.1038/s41467-022-33474-8 

due to their unstable triplet states. To extend their phosphorescent applications in data encryption and anti-counterfeiting, great effort has been made in the construction of CD-based hybrid phosphorescent systems, in which various organic or inorganic matrices, including KAl(SO4)2·xH2O<sup>45</sup> , SiO233, zeolites<sup>46</sup> , layered double hydroxides<sup>47</sup> , poly(vinyl alcohol)<sup>44</sup> , polyurethane<sup>66</sup> , and cyanuric acid<sup>48</sup> , were employed to suppress the intermolecular vibration for triplet stabilization. However, CD-based hybrid phosphorescent systems are limited by the solid-state-only applications as well as timeconsuming and high-cost fabrication involving the use of additional matrices in the solid composites. To date, matrix-free phosphorescent CDs have not been fabricated for phosphorescent applications in aqueous solutions or physiological media because several issues are difficult to address by self-stabilization of triplet states. First, a challenge is to substantially reduce the energy gap (ΔEST) of CDs between the lowest singlet (S1) to the lowest triplet (T1) for enhancing their favorable intersystem crossing. Second, highly efficient fluorescent emission in CD solutions shows overwhelming advantages over phosphorescent emission, leading to low population probability in the triplet states despite effective ISC. Unfortunately, the electron–hole recombination from S1 to the ground state could not be inhibited to quench the fluorescence emission for enhanced RTP. Third, the excited triplet states at a low-level population are strongly quenched by dissolved molecular oxygen (triplet-state<sup>3</sup> O2) to form singlet-state<sup>1</sup> O2, further impeding the aqueous applications of RTP materials. Herein, we reported that matrix-free p–n-CDs in solution states can be rationally constructed as a solution-applicable RTP material by p–n junction engineering. The formation of the p–n junction within single p–n-CDs can effectively inhibit the e<sup>−</sup> –h<sup>+</sup> pair recombination from excited singlet states to the ground state and thus enhance the RTP emission as evidenced by the time-resolved PL spectra of the p–n-CD solution and the p–n-CD@PVA film, where no transient fluorescent components were observed apart from the long-lived components. In addition, rapid charge transfers from the n-type dopant (pyrrolic N) to the p-type dopant (SO3ˉ) in the bipolar configuration could stabilize the triplet states with a long lifetime of 11.4 μs in aqueous solutions. In contrast, for p-CDs with SO3ˉ functionalization only or n-CDs with pyrrolic/graphitic N functionalization only, effective charge transfer could not be established, leading to fluorescent emission with a nsscale lifetime in aqueous solutions. Furthermore, TD-DFT calculations showed that the simultaneous modification with SO3, pyrrolic N, and graphitic N in the CD-3 model can reduce ΔEST to a smaller value (0.55 eV), which is favorable for effective ISC to populate triplet excitons and consequently emitting phosphorescence. In contrast, for SO3modified CD-1 has ΔEST as high as 1.08 eV, suggesting ineffective ISC at room temperature. These results clearly revealed that phosphorescent p–n-CDs exhibited a distinct triplet stabilization mechanism by creating the p–n junction rather than the hydrogen-bonded network in CDbased hybrid phosphorescent systems. Compared with the complex preparation processes of CD-based hybrid phosphorescent systems, the construction of highly phosphorescent p–n junction CDs is simple, one-step, and rapid by one-pot microwave irradiation. 

It is noted that current afterglow CDs in the hybrid systems are mainly limited to visible RTP emissions from blue, green to yellow. Recently, high-efficiency red RTP emissions at 620 nm have been also achieved by embedding CDs in Mn-containing open-frame-work matrices<sup>54</sup> , but RTP emissions extended to the NIR region remain unexplored to date for NIR applications such as NIR imaging and emitters. Generally, the NIR emissions of quantum dots require a narrow bandgap; it is challenging for CDs to simultaneously reduce the bandgap and stabilize triplet states. Here, we found that phosphorescent p–n-CDs have a narrow bandgap of 1.62 eV and thus emit NIR phosphorescence at 760 nm as a result of the synergistic effects of electron-withdrawing and electron-donating modifications on the p–nCD electronic structure. The rational p–n junction modification in NIR- 

phosphorescent p–n-CDs creates the narrow bandgap and stabilize triplet states. Importantly, the p–n-CDs exhibit a phosphorescent efficiency as high as 17.6% in aqueous solutions and high NIR emission brightness comparable to that of the clinically used ICG. These RTP properties render p–n-CDs as a superior long-lived NIR imaging platform for biomedical applications with minimal background interference. 

Long-lived triplet states of organic photosensitizers are tremendously important forphotodynamictherapy (PDT) owing to a high yield of singlet oxygen generation upon photo-excitation. Based on similar mechanisms to organic photosensitizers, organic sonosensitizers with long-lived triplet states are also favorable for SDT under US irradiation. Interestingly, phosphorescent p–n-CDs have long-lived triplet states in aqueous solutions, enabling effective singlet oxygen generation for SDT like organic photosensitizers. Unlike organic sonosensitizers with low photostability, p–n-CDs have excellent photostability owing to the graphitic structure. Moreover, p–n-CDs possess a narrow bandgap for enhanced sonoexcitation. 

In conclusion, we have developed a one-step microwave strategy for controlled synthesis of NIR-phosphorescent p–n-CDs finely decorated with sulfonic acceptors and pyrrolic/graphitic N donators. The p–n-CDs are endowed with a narrow bandgap of 1.62 eV and a long carrier lifetime of 11.4 μs, two of which can enhance SDT as thermodynamically and dynamically favorable factors under low-intensity ultrasound irradiation, respectively. Additionally, p–n-CDs can emit NIR emission with PL maximum at 760 nm and maximum excitation at 700 nm with absolute PL quantum yield of 17.6% and improved stability against photo-bleaching. They exhibit enhanced<sup>1</sup> O2 generation efficiency owing to (1) inhibition of the e<sup>−</sup> –h<sup>+</sup> pair recombination owing to the p–n junction, (2) long-lived triplet-state mediated<sup>1</sup> O2 generation, (3) GSH depletion using overexpressed GSH as a hole sacrificial agent. We have also prepared two kinds of p–n-CD loaded CCM vehicles with homotypic recognition capability as the cancer-specific NIR probe and sonosensitizer for precision bioimaging and SDT with excellent tumor eradication capability. Our results will open up a promising approach to engineer phosphorescent materials with NIR emission and long-lived triplet excited states for wide range applications apart from sonodynamic precision tumor therapy. 

## Methods 

### Materials 

ICG and BPEI (Mn ~ 1800 Da) were purchased from J&K Scientific Co., Ltd. (Beijing, China). Pyrene was obtained from TCI (Japan). Nitric acid (HNO3) and PVA were purchased from Sinopharm Chemical Reagents Co., Ltd. (Shanghai, China). DPBF, 3-(4,5-dimethyl-thiazole-2-yl)−2,5phenyltetrazolium bromide (MTT), dihydroethidium (DHE), and TEMP were purchased from Sigma-Aldrich. 

### Preparation of p–n-CDs, p-CDs, and n-CDs 

For the preparation of p–n-CDs, ICG (5 mg) and BPEI (50 mg) were dissolved in ethanol (10 mL) and then transferred to a reaction tube. The microwave reaction was performed at 200 °C for 15 min to obtain p–n-CDs, which were then dialyzed for 48 h to remove remaining ICG and BPEI. Similarly, p-CDs were synthesized by the microwave reaction at 200 °C for 15 min using single ICG as the precursor. For n-CDs, 1,3,6trinitropyrene (TNP) was initially synthesized through the nitration reaction of pyrene at 80 °C for 48 h. The obtained TNP was filtered through a 220 µm microporous membrane for several times to remove the unreacted pyrene and HNO3. Then, n-CDs were prepared through the microwave reaction at 200 °C for 15 min using TNP and BPEI as the precursors. 

### Preparation of p–n-CD@PVA composite films 

0.2 g of PVA was first added to 2 mL of DI water. To obtain uniform p–nCD@PVA solution, p–n-CD aqueous solution (5 mg/mL, 100 μL) was 

Nature Communications |  (2022) 13:5735 

10 

Article 

https://doi.org/10.1038/s41467-022-33474-8 

added to PVA solution (100 mg/mL) through a slow shake. The composite was coated onto the glass substrates and dried at 60 °C for 1 h to obtain the p–n-CD@PVA composite films. 

### Preparation of CCM fragments 

143B and Hela cells were purchased from Cell Bank of Type Culture Collection of Chinese Academy of Sciences (Shanghai, China). 143B and Hela cells were harvested and then resuspended in cold PBS. The collected cells were suspended in a hypotonic lysing buffer containing PMSF (Beyotime, China) and membrane protein extraction reagent. The resuspended 143B or Hela cells were incubated in ice bath for 15 min and then broken repeatedly using a freeze-thaw method. After centrifugation at 800 × g for 10 min, the supernatant was further centrifuged at 15, 000 × g for 30 min to obtain the cell membrane fragments. The membrane products of CCM-143B and CCM-Hela were lyophilized and stored at −80 °C. The lyophilized membranes are rehydrated in ultrapure water or PBS buffer. For CCM protein characterization, the following antibodies were used for western blot analysis: Anti-pan cadherin antibody (Abcam, ab22744, 1:1000); AntiNa+/K+-ATPase antibody (Abcam, ab76020, 1:1000), Anti-gp100 antibody (Abcam, ab137078, 1:1000), Anti-Histone H3.3 Rabbit pAb (Servicebio, GB11026, 1:500), Anti-COX IV Rabbit pAb (Servicebio, GB11250, 1:500), Anti-GAPDH Mouse mAb (Servicebio, GB12002, 1:1000), HRP conjugated Goat Anti-Rabbit IgG (Servicebio, GB23303, 1:3000), HRP conjugated Goat Anti-Mouse IgG (Servicebio, GB23301, 1:3000). 

### Preparation of p–n-CD@CCM 

A successive extrusion approach was utilized to prepare the p–nCD@CCM. Briefly, 1 mL aqueous solution of p–n-CDs with varied concentration (0.1, 0.2, 0.3, 0.4, or 0.5 mg/mL) was mixed with CCM143B or CCM-Hela dispersions (1 mL, 1.0 mg/mL). The p–n-CDs and CCM were transferred into a syringe and successively extruded through 500 nm, 200 nm, and 100 nm water-phase filters, followed by centrifugation to remove unloaded p–n-CDs from the dispersions. The amount of encapsulated p–n-CDs in p–n-CD@CCM was determined by UV-vis-NIR absorption spectroscopy. Finally, a p–n-CD@CCM dispersion with encapsulated p–n-CDs at a high concentration (200 µg/mL) and a high loading (~20%) was obtained at the mass ratio of p–n-CD to CCM (3:10 w/w) for further structural characterization and SDT measurements. 

### Characterization 

TEM images of p-CDs, n-CDs, p–n-CDs, and p–n-CD@CCM were acquired by a JEM-2100F microscope. XPS, FT-IR, XRD, and Raman spectra of p-CDs, n-CDs, and p–n-CDs were performed using Kratos Axis Ultra DLD, Nicolet AVATAR 370, Rigaku 18 KW D/max-2550, and Renishaw in plus laser Raman spectrometer, respectively. The hydrodynamic diameter and Zeta potential measurements were carried out using a Malvern Zetasizer Nano ZS90. The UV-vis-NIR absorption and fluorescence spectra of p-CDs, n-CDs, and p–n-CDs were measured by Agilent Cary 5000 and Hitachi 7000 spectrophotometer. The phosphorescence spectra and lifetimes were measured by an Edinburgh FLS1000 spectrometer. ESR spectra were recorded on a Bruker EMX plus ESR spectrometer. 

obtained by broadening the oscillator strength at corresponding excited energy using Gauss broadening functions. According to Kasha’s rule, their fluorescence spectra are related to the radiation transition of the first singlet excited state (S1). In order to simulate the emission spectra of CD molecules, the molecular geometries at the S1 excited state were then optimized at the PBE0/TZVP level with the TDDFT method. All the calculations were performed using the Gaussian 16 program. 

### Sonodynamic performance of p–n-CDs 

The mixture solution of 20 µg DPBF and p–n-CD (200 μg/mL, 1 mL) were exposed to US irradiation (50 kHz, 3.0 W/cm<sup>2</sup> ) for 5 min and the absorbance of DPBF at 418 nm was recorded to calculate the quantum yield of<sup>1</sup> O2 generation. Similarly, the<sup>1</sup> O2 generation efficiency of p- CDs, n-CDs, ICG, and commercial TiO2 nanopaticles were measured under the same conditions. For ESR measurements, the mixture solution of 20 μL TEMP and p–n-CD (200 μg/mL, 1 mL) were exposed to US irradiation for 2 min and the signal of<sup>1</sup> O2 was detected by ESR spectrometer using TEMP as the trapping agent. Similarly, the ESR spectra of US alone, p-CDs, n-CDs, ICG, and commercial TiO2 nanopaticles were detected under the same conditions. 

### Electrochemical measurements 

The CV curves of p–n-CDs, p-CDs, and n-CDs were measured based on a three-electrode system using electrochemical workstation (CHI 660D, China). The reference electrode, counter electrode, and electrolyte were Ag/AgCl, platinum wire, and TBAPF6, respectively. According to the CV curves, the conduction band (CB) energy level of p–n-CDs, p-CDs, and n-CDs at pH 7.4 was measured to be −0.77, −1.50, and −1.36 eV vs Ag/AgCl, respectively. The conductivity type of p–nCDs, p-CDs, and n-CDs was analyzed through impedance spectroscopy equipped with Thales software. The conduction- and valence-band edges of p–n-CDs, p-CDs, and n-CDs were determined by a linear potential scan (5 mV/s). 

### MTT assay 

143B cells were first seeded in the 96-wellplates and incubated for 24 h. After incubated with p–n-CD@CCM for another 24 or 48 h, a standard MTT assay was performed to detect the cell viability. For in vitro sonodynamic therapy, after incubated with p–n-CD@CCM for 4 h, 143B cells were exposed to US irradiation (50 kHz, 3.0 W/cm<sup>2</sup> ) for 5 min. Then, 143B cells were incubated for 24 or 48 h and a standard MTT assay was performed to detect the cell viability. 

### Live/dead cell staining 

Calcein AM and PI were used as the probes to stain the live and dead cells after treating with PBS, US, p–n-CD@CCM, ICG + US, p–n-CD + US, or p–n-CD@CCM + US. US treatments were carried out for 5 min under the condition of 50 kHz and 3.0 W/cm<sup>2</sup> . The fluorescence microscope (Olympus, Japan) was utilized to obtain the fluorescence images under the excitation wavelength of 488 nm for calcein AM and 561 nm for PI. The semi-quantitative analysis of live/dead cell staining images was determined by the Image J software (ver. 1.7) via triplicate parallel samples. 

### In vitro ROS detection 

### Computational details 

We first established three sp<sup>2</sup> hybrid carbon clusters with different functional groups as CD-like molecule models including SO3-modified CD-1, SO3-pyrrolic N-modified CD-2, and SO3-pyrrolic N-graphitic N- modified CD-3. The geometry of CD molecules at the ground state was optimized with dispersion corrected density functional theory (DFTD3)<sup>67,68</sup> . To investigate the photophysical properties of CD molecules, their excited electronic structures were calculated at the PBE0-D3/ TZVP level with the TD-DFT method. Their UV absorption spectra were 

For in vitro ROS detection, DCFH-DA was used to detect intracellular ROS level in the 143B cells after treating with PBS, US, p–nCD@CCM, ICG + US, p–n-CD + US, or p–n-CD@CCM + US. US treatments were carried out for 5 min under the condition of 50 kHz and 3.0 W/cm<sup>2</sup> . The confocal images were collected using Olympus FV3000 microscope and the data were analyzed with FV31S-SW (ver. 2.1.1.98). The semi-quantitative analysis of ROS staining images was determined by the Image J software (ver. 1.7) via triplicate parallel samples. 

Nature Communications |  (2022) 13:5735 

11 

Article 

https://doi.org/10.1038/s41467-022-33474-8 

### Apoptosis assay 

For cell apoptosis analysis, the 143B cells were first seeded in 6-well plates and then incubated overnight. After different treatments including control, US alone, p–n-CD@CCM, ICG + US, p–n-CD + US, and p–n-CD@CCM + US, the 143B cells were incubated for another 24 h. US treatments were carried out for 5 min under the condition of 50 kHz and 3.0 W/cm<sup>2</sup> . Then, 143B cells were collected by centrifugation (300 × g, 5 min) and detected by flow cytometer (Beckman, CytoFLEX LX) using an Annexin V-FITC/PI assay kit (Dojindo, Japan) according to the manufacturer’s protocol. For the detailed operation, 143B cells were first stained with Annexin V-FITC (5 μL) for 15 min in Annexin-binding buffer. PI (5 μL) was then added to 143B cells and incubated for another 15 min. Beckman Coulter cytExpert 2.3.0.84 software was used for data collection and analysis. 

### Cell imaging 

For in vitro cell imaging, 143B and Hela cells were first seeded in 96well plates. The p–n-CD@143B and p–n-CD@Hela solutions were introduced into the 143B or Hela cells with a final concentration of ~10 μg mL<sup>−1</sup> , respectively. After 30 min of incubation, the 143B and Hela cells were washed with PBS for three times to remove excessive p–nCD@143B or p–n-CD@Hela. Afterward, the cells were fixed with 4% paraformaldehyde solution and stained by 4′,6-diamidino-2-phenylindole (DAPI), followed by observation under a confocal microscope (Olympus, Japan). Confocal imaging data were analyzed with FV31S-SW (ver. 2.1.1.98). 

### Tumor model 

3–5-week-old female Balb/c nude mice were purchased from SLAC Laboratory Animal (Shanghai, China). All mice were housed in an animal facility under constant environmental conditions (room temperature, 22 ± 1 °C, relative humidity, 40–70% and a 12 h light-dark cycle). All animal experiments were carried out under the permission by Institutional Animal Care and Use Committee of Shanghai University (SYXK 2019-0020). To establish a tumor model on the nude mice, 5 × 10<sup>6</sup> of 143B cells were subcutaneously injected into their back side. 

2.0 mg/kg. 10 μL of blood was collected in heparinized tubes from the tail vein at different time points including 5 min, 10 min, 30 min, 1 h, 2 h, 4 h, 8 h, 12 h, and 24 h, dispersed into 990 μL PBS, and centrifuged at 1500 × g for 10 min to harvest plasma samples. The p–n-CD concentration in the supernatants was examined by chromatometry at 680 nm. The plasma concentration-time profiles of p–n-CD and p–nCD@CCM samples showed a typical double-compartment pharmacokinetic behavior. 

### In vivo metabolism study 

After intravenous injection of p–n-CD@CCM (2.0 mg/kg), 3–5-weekold female Balb/c mice (n = 5) were sacrificed at 1, 7, and 14 days, respectively. The major organs were collected and solubilized by aqua regia for detection of p–n-CD concentrations by chromatometry at 680 nm. To study the excretion pathway, after intravenous injection of p–n-CD@CCM (2.0 mg/kg), Balb/c mice (n = 5) were kept in metabolic cages to collect their feces and urine. The feces and urine were solubilized by aqua regia and the 680 nm absorbance was measured to determine the concentration of p–n-CD. 

### Statistical analysis 

To ensure the accuracy of the experiments, at least three replicates were performed. All data are presented as mean values ± SD. All statistical analyses were performed by Origin 2018 and Graphpad Prism 8.0. Statistical significance between two groups was calculated with two-tailed Student’s t test. 

### Reporting summary 

Further information on research design is available in the Nature Research Reporting Summary linked to this article. 

## Data availability 

The authors declare that all relevant data supporting the findings of this study are available within the paper, the Supplementary Information, and Source data. Source data are provided with this paper. 

## References 

### In vivo NIR fluorescence imaging 

The p–n-CD@CCM (2.0 mg kg<sup>−1</sup> ) was intravenously injected to 143B tumor-bearing mice. After intravenous injection of different time, an IVIS Lumina III in vivo Imaging System (PerkinElmer, USA) was utilized to obtain the NIR fluorescence images under the excitation and collection wavelength of 700 and 790 nm, respectively. The NIR fluorescence imaging has been repeated for three times and the data were analyzed with Living Image 4.5.2 Software (PerkinElmer, USA). 

### In vivo SDT 

Six groups of 143B tumor-bearing mice were randomly divided as followed: control, US, p–n-CD@CCM, ICG + US, p–n-CD + US, and p–nCD@CCM + US. After intravenous injection of 24 h, US irradiation was conducted in groups 2, 4, 5, and 6 for 5 min under the condition of 50 kHz and 3.0 W/cm<sup>2</sup> . We measured the tumor sizes and body weight of mice every two days and every day, respectively. For in vivo deeptissue SDT, we initially established two 143B tumors on either side of mice and the US irradiation was conducted from left to right. On the 2-day post-treatment, tumors in each groups were harvested for histological analysis including H&E and ROS staining. Tumors in each groups were also collected for ROS detection using DHE as the probe. On the 16-day post-treatment, major organs and blood in each groups were harvested to assess the in vivo long-term toxicity through histological analysis, blood biochemistry, and blood routine analysis. 

### In vivo pharmacokinetic 

3–5-week-old female Balb/c mice (n = 5) were intravenously injected with p–n-CDs and p–n-CD@CCM, respectively, at a p–n-CD dose of 

1. He, Y., Liu, H. S., Yin, J. & Yoon, J. Sonodynamic and chemodynamic therapy based on organic/organometallic sensitizers. Coord. Chem. Rev. 429, 213610 (2021). 

2. Hu, H. et al. Emerging nanomedicine-enabled/enhanced nanodynamic therapies beyond traditional photodynamics. Adv. Mater. 33, e2005062 (2021). 

3. Son, S. et al. Multifunctional sonosensitizers in sonodynamic cancer therapy. Chem. Soc. Rev. 49, 3244–3261 (2020). 

4. Xing, X. et al. Advances and perspectives in organic sonosensitizers for sonodynamic therapy. Coord. Chem. Rev. 445, 214087 (2021). 

5. Wang, S. et al. Beyond photo: Xdynamic therapies in fighting cancer. Adv. Mater. 33, e2007488 (2021). 

6. Yang, Y., Wang, X., Qian, H. & Cheng, L. Titanium-based sonosensitizers for sonodynamic cancer therapy. Appl. Mater. Today 25, 101215 (2021). 

7. Xu, T., Zhao, S., Lin, C., Zheng, X. & Lan, M. Recent advances in nanomaterials for sonodynamic therapy. Nano Res. 13, 2898–2908 (2020). 

8. Cheng, Y., Wen, C., Sun, Y. Q., Yu, H. & Yin, X. B. Mixed‐metal MOF‐ derived hollow porous nanocomposite for trimodality imaging guided reactive oxygen species‐augmented synergistic therapy. Adv. Funct. Mater. 31, 2104378 (2021). 

9. Dong, Y. et al. 2D piezoelectric Bi2MoO6 nanoribbons for GSHenhanced sonodynamic therapy. Adv. Funct. Mater. 33, 2106838 (2021). 

10. Pan, X. et al. Metal-organic-framework-derived carbon nanostructure augmented sonodynamic cancer therapy. Adv. Mater. 30, 1800180 (2018). 

Nature Communications |  (2022) 13:5735 

12 

Article 

https://doi.org/10.1038/s41467-022-33474-8 

11. Feng, L. et al. An ultrasmall SnFe2O4 nanozyme with endogenous oxygen generation and glutathione depletion for synergistic cancer therapy. Adv. Funct. Mater. 31, 2006216 (2020). 

12. Wang, X. et al. Ultrafine titanium monoxide (TiO1+x) nanorods for enhanced sonodynamic therapy. J. Am. Chem. Soc. 142, 6527–6537 (2020). 

13. Gong, F. et al. Preparation of TiH1.924 nanodots by liquid-phase exfoliation for enhanced sonodynamic cancer therapy. Nat. Commun. 11, 3712 (2020). 

14. Liu, Y. et al. Boosting antitumor sonodynamic therapy efficacy of black phosphorus via covalent functionalization. Adv. Sci. 8, e2102422 (2021). 

15. Song, M. et al. Sonoactivated chemodynamic therapy: a robust ROS generation nanotheranostic eradicates multidrug‐resistant bacterial infection. Adv. Funct. Mater. 30, 2003587 (2020). 

16. Liang, S. et al. A robust narrow bandgap vanadium tetrasulfide sonosensitizer optimized by charge separation engineering for enhanced sonodynamic cancer therapy. Adv. Mater. 33, 2101467 (2021). 

17. Geng, B. et al. Multifunctional carbon dot/MXene heterojunctions for alleviation of tumor hypoxia and enhanced sonodynamic therapy. Carbon 179, 493–504 (2021). 

18. Bai, S. et al. Ultrasmall iron-doped titanium oxide nanodots for enhanced sonodynamic and chemodynamic cancer therapy. Acs Nano 14, 15119–15130 (2020). 

19. Fu, S. et al. Catalytically active CoFe2O4 nanoflowers for augmented sonodynamic and chemodynamic combination therapy with elicitation of robust immune response. Acs Nano 15, 11953–11969 (2021). 

20. Han, X. et al. Oxygen-deficient black titania for synergistic/ enhanced sonodynamic and photoinduced cancer therapy at near infrared-II biowindow. Acs Nano 12, 4545–4555 (2018). 

21. You, D. G. et al. ROS-generating TiO2 nanoparticles for non-invasive sonodynamic therapy of cancer. Sci. Rep. 6, 23200 (2016). 

22. Shi, J. et al. Reactive oxygen species-manipulated drug release from a smart envelope-type mesoporous titanium nanovehicle for tumor sonodynamic-chemotherapy. ACS Appl. Mater. Interfaces 7, 28554–28565 (2015). 

23. Wang, X. et al. Site-specific sonocatalytic tumor suppression by chemically engineered single-crystalline mesoporous titanium dioxide sonosensitizers. J. Mater. Chem. B 5, 4579–4586 (2017). 

24. Mi, P., Cabral, H. & Kataoka, K. Ligand-installed nanocarriers toward precision therapy. Adv. Mater. 32, e1902604 (2020). 

25. Tran, P. H. L. et al. Exosomes and nanoengineering: a match made for precision therapeutics. Adv. Mater. 32, e1904040 (2020). 

26. Sunderland, K. S., Yang, M. & Mao, C. Phage-enabled nanomedicine: from probes to therapeutics in precision medicine. Angew. Chem. Int. Ed. 56, 1964–1992 (2017). 

27. Ho, Y.-J. et al. Superhydrophobic drug-loaded mesoporous silica nanoparticles capped with β-cyclodextrin for ultrasound imageguided combined antivascular and chemo-sonodynamic therapy. Biomaterials 232, 119723 (2020). 

28. Wang, D. et al. Precise magnetic resonance imaging-guided sonodynamic therapy for drug-resistant bacterial deep infection. Biomaterials 264, 120386 (2021). 

29. Zheng, X. et al. Biodegradable natural product-based nanoparticles for near-infrared fluorescence imaging-guided sonodynamic therapy. ACS Appl. Mater. Interfaces 11, 18178–18185 (2019). 

30. Geng, B. et al. W-doped TiO2 nanorods for multimode tumor eradication in osteosarcoma models under single ultrasound irradiation. ACS Appl. Mater. Interfaces 13, 45325–45334 (2021). 

31. Biju, V., Itoh, T. & Ishikawa, M. Delivering quantum dots to cells: bioconjugated quantum dots for targeted and nonspecific extracellular and intracellular imaging. Chem. Soc. Rev. 39, 3031–3056 (2010). 

32. Ma, Y., Zhang, Y. & Yu, W. W. Near infrared emitting quantum dots: synthesis, luminescence properties and applications. J. Mater. Chem. C. 7, 13662–13679 (2019). 

33. Sun, Y. et al. Ultralong lifetime and efficient room temperature phosphorescent carbon dots through multi-confinement structure design. Nat. Commun. 11, 5591 (2020). 

34. Liang, Y.-C. et al. Ultralong and efficient phosphorescence from silica confined carbon nanodots in aqueous solution. Nano Today 34, 100900 (2020). 

35. Zhao, W., He, Z. & Tang, B. Z. Room-temperature phosphorescence from organic aggregates. Nat. Rev. Mater. 5, 869–885 (2020). 

36. You, Y. & Nam, W. Photofunctional triplet excited states of cyclometalated Ir(III) complexes: beyond electroluminescence. Chem. Soc. Rev. 41, 7061–7084 (2012). 

37. Zhao, J., Xu, K., Yang, W., Wang, Z. & Zhong, F. The triplet excited state of Bodipy: formation, modulation and application. Chem. Soc. Rev. 44, 8904–8939 (2015). 

38. Xiang, H., Cheng, J., Ma, X., Zhou, X. & Chruma, J. J. Near-infrared phosphorescence: materials and applications. Chem. Soc. Rev. 42, 6128–6185 (2013). 

39. Wang, J. et al. Rhodium(I) complex-based polymeric nanomicelles in water exhibiting coexistent near-infrared phosphorescence imaging and anticancer activity in vivo. J. Am. Chem. Soc. 142, 2709–2714 (2020). 

40. Wu, Y. et al. Dual mode NIR long persistent phosphorescence and NIR-to-NIR Stokes luminescence in La3Ga5GeO14: Cr<sup>3+</sup> , Nd<sup>3+</sup> phosphor. J. Alloy. Compd. 649, 62–66 (2015). 

41. Jin, C. et al. Rational design of NIR-emitting iridium(III) complexes for multimodal phosphorescence imaging of mitochondria under two-photon excitation. Chem. Commun. 53, 10374–10377 (2017). 

42. Yeh, T.-F., Teng, C.-Y., Chen, S.-J. & Teng, H. Nitrogen-doped graphene oxide quantum dots as photocatalysts for overall watersplitting under visible light illumination. Adv. Mater. 26, 3297–3303 (2014). 

43. Yan, Y. et al. Systematic bandgap engineering of graphene quantum dots and applications for photocatalytic water splitting and CO2 reduction. Acs Nano 12, 3523–3532 (2018). 

44. Jiang, K. et al. Triple-mode emission of carbon dots: applications for advanced anti-counterfeiting. Angew. Chem. Int. Ed. 55, 7231–7235 (2016). 

45. Dong, X. et al. Efficient long lifetime room temperature phosphorescence of carbon dots in a potash alum matrix. J. Mater. Chem. C. 3, 2798–2801 (2015). 

46. Liu, J. et al. Carbon dots in zeolites: A new class of thermally activated delayed fluorescence materials with ultralong lifetimes. Sci. Adv. 3, e1603171 (2017). 

47. Bai, L. Q., Xue, N., Wang, X. R., Shi, W. Y. & Lu, C. Activating efficient room temperature phosphorescence of carbon dots by synergism of orderly non-noble metals and dual structural confinements. Nanoscale 9, 6658–6664 (2017). 

48. Tan, J., Ye, Y., Ren, X., Zhao, W. & Yue, D. High pH-induced efficient room-temperature phosphorescence from carbon dots in hydrogen-bonded matrices. J. Mater. Chem. C. 6, 7890–7895 (2018). 

49. Choi, H. S. et al. Renal clearance of quantum dots. Nat. Biotechnol. 25, 1165–1170 (2007). 

50. Geng, B. et al. NIR-responsive carbon dots for efficient photothermal cancer therapy at low power densities. Carbon 134, 153–162 (2018). 

51. Geng, B. et al. Enriched graphitic N dopants of carbon dots as F cores mediate photothermal conversion in the NIR-II window with high efficiency. Carbon 162, 220–233 (2020). 

52. Geng, B., Hu, J., Li, P., Pan, D. & Shen, L. DNA binding graphene quantum dots inhibit dual topoisomerases for cancer chemotherapy. Carbon 187, 365–374 (2022). 

Nature Communications |  (2022) 13:5735 

13 

Article 

https://doi.org/10.1038/s41467-022-33474-8 

53. Jiang, K. et al. Carbon dots with dual-emissive, robust, and aggregation-induced room-temperature phosphorescence characteristics. Angew. Chem. Int. Ed. 59, 1263–1269 (2020). 

54. Wang, B. et al. Carbon dots in a matrix: energy-transfer-enhanced room-temperature red phosphorescence. Angew. Chem. Int. Ed. 58, 18443–18448 (2019). 

55. Zhang, J. et al. Phosphorescent carbon dots for highly efficient oxygen photosensitization and as photo-oxidative nanozymes. ACS Appl. Mater. Interfaces 10, 40808–40814 (2018). 

56. Liang, S. et al. Conferring Ti-based MOFs with defects for enhanced sonodynamic cancer therapy. Adv. Mater. 33, e2100333 (2021). 

57. Zhong, X. et al. GSH-depleted PtCu3 nanocages for chemodynamic-enhanced sonodynamic cancer therapy. Adv. Funct. Mater. 30, 1907954 (2020). 

58. Dong, Z. et al. Synthesis of CaCO3-based nanomedicine for enhanced sonodynamic therapy via amplification of tumor oxidative stress. Chem 6, 1391–1407 (2020). 

59. Liu, J. et al. Passive tumor targeting of renal-clearable luminescent gold nanoparticles: long tumor retention and fast normal tissue clearance. J. Am. Chem. Soc. 135, 4978–4981 (2013). 

60. Park, J.-H. et al. Biodegradable luminescent porous silicon nanoparticles for in vivo applications. Nat. Mater. 8, 331–336 (2009). 

61. Song, G. et al. Degradable molybdenum oxide nanosheets with rapid clearance and efficient tumor homing capabilities as a therapeutic nanoplatform. Angew. Chem. Int. Ed. 55, 2122–2126 (2016). 

62. Yang, K., Feng, L., Shi, X. & Liu, Z. Nano-graphene in biomedicine: theranostic applications. Chem. Soc. Rev. 42, 530–547 (2013). 

63. Fang, R. H. et al. Cancer cell membrane-coated nanoparticles for anticancer vaccination and drug delivery. Nano Lett. 14, 2181–2188 (2014). 

64. Zhu, J.-Y. et al. Preferential cancer cell self-recognition and tumor self-targeting by coating nanoparticles with homotypic cancer cell membranes. Nano Lett. 16, 5895–5901 (2016). 

65. Lv, Y. et al. Cancer cell membrane-biomimetic nanoprobes with two-photon excitation and near-infrared emission for intravital tumor fluorescence imaging. Acs Nano 12, 1350–1358 (2018). 

66. Tan, J. et al. Large-scale synthesis of N-doped carbon quantum dots and their phosphorescence properties in a polyurethane matrix. Nanoscale 8, 4742–4747 (2016). 

67. Grimme, S. Semiempirical hybrid density functional with perturbative second-order correlation. J. Chem. Phys. 124, 034108 (2006). 

68. Weigend, F. & Ahlrichs, R. Balanced basis sets of split valence, triple zeta valence and quadruple zeta valence quality for H to Rn: design and assessment of accuracy. Phys. Chem. Chem. Phys. 7, 3297–3305 (2005). 

## Acknowledgements 

This work was supported by the National Natural Science Foundation of China (No. 22278262 to D.P., 22108168 to B.G., 12175142 to L.S., 22177067 to L.F.), Shanghai Rising-Star Program (A type) (No. 20QA1403400 to 

L.F.), China Postdoctoral Science Foundation (No. 2020M681267 to B.G.), the Science and Technology Commission of Shanghai Municipality (No. 22ZR1424000 to D.P.), and the cultivation project (No. ynms202103 to L.S.) from Shanghai Jiao Tong University affiliated Sixth People’s Hospital. 

## Author contributions 

D.P. designed and directed the study, analyzed the data and wrote the manuscript. B.G. designed and performed experiments, and collected and analyzed data. L.F., L.S. provided important suggestions, supervised parts of the project, and improved the manuscript. S.F. provided advice and technical help with cell experiments and mouse cancer models. J.H., Y.L. performed cell and animal experiments. All authors discussed the results and reviewed the manuscript. 

## Competing interests 

The authors declare no competing interests. 

## Additional information 

Supplementary information The online version contains supplementary material available at 

https://doi.org/10.1038/s41467-022-33474-8. 

Correspondence and requests for materials should be addressed to Dengyu Pan, Lingyan Feng or Longxiang Shen. 

Peer review information Nature Communications thanks Siwei Yang and the other anonymous reviewer(s) for their contribution to the peer review of this work. Peer reviewer reports are available. 

Reprints and permission information is available at 

http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2022 

Nature Communications |  (2022) 13:5735 

14 

