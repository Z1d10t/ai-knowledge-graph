# Hydrogenated Cs2AgBiBr6 for significantly improved efficiency of lead-free inorganic double perovskite solar cell

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 369 |
| 作者 | Ze-Yu Zhang, Qingde Sun, Yue Lu, Feng Lu, Xulin Mu, Suhuai Wei, Man-Ling Sui |
| DOI | 10.1038/s41467-022-31016-w |
| 源文件 | 001_Zhang_2022_Hydrogenated-Cs2AgBiBr6-for-significantly-improv.pdf |

---


## ARTICLE 



> https://doi.org/10.1038/s41467-022-31016-w **OPEN** 

# Hydrogenated Cs2AgBiBr6 for significantly improved efficiency of lead-free inorganic double perovskite solar cell 

Zeyu Zhang<sup>1</sup> , Qingde Sun<sup>2</sup> , Yue Lu 1✉, Feng Lu3, Xulin Mu1, Su-Huai Wei 2✉ & Manling Sui 1✉ 

Development of lead-free inorganic perovskite material, such as Cs2AgBiBr6, is of great importance to solve the toxicity and stability issues of traditional lead halide perovskite solar cells. However, due to a wide bandgap of Cs2AgBiBr6 film, its light absorption ability is largely limited and the photoelectronic conversion efficiency is normally lower than 4.23%. In this text, by using a hydrogenation method, the bandgap of Cs2AgBiBr6 films could be tunable from 2.18 eV to 1.64 eV. At the same time, the highest photoelectric conversion efficiency of hydrogenated Cs2AgBiBr6 perovskite solar cell has been improved up to 6.37% with good environmental stability. Further investigations confirmed that the interstitial doping of atomic hydrogen in Cs2AgBiBr6 lattice could not only adjust its valence and conduction band energy levels, but also optimize the carrier mobility and carrier lifetime. All these works provide an insightful strategy to fabricate high performance lead-free inorganic perovskite solar cells. 

> 1 Beijing Key Laboratory of Microstructure and Properties of Solids, Faculty of Materials and Manufacturing, Beijing University of Technology, 100124 Beijing, China.<sup>2</sup> Beijing Computational Science Research Center, 100193 Beijing, China.<sup>3</sup> Department of Electronic Science and Engineering, and Tianjin Key Laboratory of Photo-Electronic Thin Film Device and Technology, Nankai University, 300071 Tianjin, China.<sup>✉</sup> email: luyue@bjut.edu.cn; suhuaiwei@csrc.ac.cn; mlsui@bjut.edu.cn 

1 

NATURE COMMUNICATIONS | (2022) 13:3397 | https://doi.org/10.1038/s41467-022-31016-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-31016-w 

s one of the significant developments of third-generation solar cells, organic-inorganic halide perovskites (OIHP) Ahave attracted tremendous attentions since their highest photoelectronic conversion efficiency (PCE) is now approaching 25.7%<sup>1</sup> , comparable to the silicon-based solar cells. Traditionally, the OIHP materials have a stoichiometric ratio of ABX3, in which the A, B and X sites are consisted of organic cation (Methylamine cation (MA<sup>+</sup> ) or Formamidine cation (FA<sup>+</sup> )), metal cation Pb<sup>2+</sup> and halide anions (Cl<sup>−</sup> , Br<sup>−</sup> and I<sup>−</sup> ), respectively<sup>2–5</sup> . Despite the excellent photovoltage performance of OIHP solar cells, there still exist two critical issues that hinder their widely applications in industry<sup>6–8</sup> . The first aspect is the intrinsic instability of the OIHP caused by the volatility of organic components, and the other is the disreputable toxicity of lead element. To solve these problems, extensive efforts have been done to explore the Pb-free inorganic perovskite materials as the core adsorbent layer in solar cell<sup>9–13</sup> . For example, it has been reported that the substitution of MA<sup>+</sup> with Cs<sup>+</sup> cations in A site could increase the decomposition energy of perovskite from −0.111 eV (MAPbI3) to −0.069 eV (CsPbI3)<sup>14</sup> , thereby enhancing the stability. Considering on the toxicity of Pb element in B site of perovskite, tin cation (Sn<sup>2+</sup> ) or silver cation (Ag<sup>+</sup> ) combined with bismuth cation (Bi<sup>3+</sup> ) are alternative substitutions to relieve the toxicity of the optical absorption layer. Nevertheless, the susceptible Sn<sup>2+</sup> is easily oxidized to Sn<sup>4+</sup> in air, which rapidly decreases the photovoltage performance of CsSnI3-based solar cells<sup>15,16</sup> . While, the double substitutions of Pb<sup>2+</sup> utilizing B-site cations such as Ag<sup>+</sup> and Bi<sup>3+</sup> in perovskite could effectively improve the stability due to its enhanced Coulomb interaction energy, which leads to a high positive decomposition energy in Cs2AgBiBr6 (0.38 eV)<sup>17</sup> . Thus, Cs2AgBiBr6-based perovskite solar cell (PSC) is one of the most promising candidates in inorganic lead-free perovskite photovoltaic devices. 

However, until now, although abundant attempts have been done to optimize the optoelectronic properties of Cs2AgBiBr6 PSC, the PCE of Cs2AgBiBr6 PSCs increased gradually and the champion PCE of Cs2AgBiBr6 PSC was just 4.23%<sup>18–23</sup> , which is much lower than that of organic-inorganic hybrid lead-based PSCs. Therefore, the improvement of PCE in Cs2AgBiBr6 PSC is urgently needed. There are three main factors restricting the improvement of the efficiency, including the large bandgap (Eg), low carrier mobility and carrier lifetime. The Cs2AgBiBr6 has an indirect measured bandgap of 1.83 eV–2.19 eV<sup>24,25</sup> , which limits the light absorption of low energy photons in the perovskite layer. Meanwhile, the carrier mobility of Cs2AgBiBr6 is only about 1.00 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> –11.81 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , which is quite smaller than the one in MAPbI3 (about 35 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> )<sup>26–28</sup> . In addition, the carrier lifetime of thin-film Cs2AgBiBr6 is only about 13.7 ns due to a large number of defect states at the grain boundaries of the films<sup>29,30</sup> . 

In order to improve the PCE of Cs2AgBiBr6 PSC, extensive efforts have been tried to improve the carrier transport properties. For example, Wang et al. successfully developed a vapordeposition method to fabricate the Cs2AgBiBr6 perovskite film with dense grains, whose defect density (2.13 × 10<sup>16</sup> cm<sup>−3</sup> )<sup>18</sup> was lower than that of the solution method (9.1 × 10<sup>16</sup> cm<sup>−3</sup> )<sup>31</sup> . Gao et al. spin-coated an excellent Cs2AgBiBr6 film with the grain size of 410 nm via a proper anti-solvent technology, the defect density of perovskite film has been decreased significantly and the PCE of Cs2AgBiBr6 PSCs has been improved up to 2.2%<sup>19</sup> . On the other side, reducing the bandgap Eg of perovskite has been achieved in several reports. For example, Mete et al. found that doping of Co into PbTiO3 perovskite could effectively increase the light absorption property<sup>32</sup> . By doping Tl<sup>+</sup> , Tl<sup>3+</sup> , Sb<sup>3+</sup> or Sn<sup>2+</sup> elements into the lattice of Cs2AgBiBr6, the bandgap has been found to decrease effectively<sup>33–35</sup> . In addition, Li et al. successfully 

decreased the Eg value of single crystal Cs2AgBiBr6 from 2.19 eV to 1.7 eV by applied a high pressure of 15 GPa, however, the crystal structure as well as the Eg value recovered rapidly as the pressure is removed<sup>36</sup> . Recently, by adjusting the degree of Ag-Bi disorder, Ji et al. achieved the decrease of bandgap from 1.98 eV to 1.72 eV in single crystal Cs2AgBiBr6, which was grown at high evaporation temperature of 150 °C<sup>37</sup> . This result is consistent with the predication of Yang et al. based on density functional theory (DFT) calculations that the bandgap of Cs2AgBiBr6 could be effectively decreased from 1.93 eV to 0.44 eV after disordering at the (Ag, Bi) sublattice<sup>38</sup> . However, due to unsuitable pressure and temperature preparation conditions, such effective crystalengineering approaches for the reduction of bandgap could not been implemented in the spin-coated Cs2AgBiBr6 thin films for the fabrication of PSC devices. Therefore, the critical issue is the feasibility of the strategy of reducing bandgap in the perovskite thin films and its realizability in PSCs. 

In this text, by using a hydrogenation method, atomic hydrogen could be successfully doped into the interstitial sites of Cs2AgBiBr6 crystal lattice, which modified the bandgap of highquality double perovskite Cs2AgBiBr6 films from 2.18 eV to 1.64 eV. Based on this, the highest PCE of hydrogenated Cs2AgBiBr6-based PSC has been improved for more than 150% up to 6.37%, which is the record-high efficiency so far. Moreover, the hydrogenated Cs2AgBiBr6 PSCs exhibit remarkable stability in nitrogen environments under light illumination at both room temperature and as high as 85 °C. 

### Results 

Fabrication and characterization of hydrogenated Cs2AgBiBr6 films. As shown in Fig. 1a, high quality Cs2AgBiBr6 films were firstly fabricated by using a traditional one-step spin-coating solution method (details see Method), which have a face-centered cubic structure phase (Fm3m) (the black spectrum in Fig. 1b) and present a yellow color (the optical image of the pristine sample insets in Fig. 1b). Then the perovskite films were hydrogenated for different times (600 s and 1200 s) by using plasma treatment in a hydrogen (H2) and argon (Ar) mixed gas environment (Fig. 1a, see Method). When the hydrogenation time is up to 1200 s, the Cs2AgBiBr6 perovskite films remain to be the cubic phase (Fm3m) without any phase transition (Fig. 1b), but the color of the films change from yellow into black (insert pictures in Fig. 1b) and the surface morphology of perovskite film becomes smoother (Fig. 1c). 

To quantitatively analyze the color change of the hydrogenated Cs2AgBiBr6 films, optical absorption of these perovskite films was investigated by Ultraviolet-visible absorption spectra (UV-vis) as shown in Fig. 1d. When increasing the hydrogenation time from 0 s to 1200 s, the light absorption for photons with wavelength above 496 nm exhibits an obvious increase, which indicates an effective improvement of visible light absorption of the hydrogenated Cs2AgBiBr6 perovskite films. Meanwhile, the bandgap of hydrogenated Cs2AgBiBr6 films is also consistent with the measured one determined by the tauc plots equation [Eq. 1], 



<!-- Start of picture text -->
ðαhνÞ 1=n ¼ Aðhν � EgÞ ð1Þ<br><!-- End of picture text -->

where α is absorption coefficient, h is Plank’s constant, ν is the incident frequency, A is a constant of proportionality<sup>39</sup> and the exponent n is 2 for indirect bandgap semiconductor<sup>40</sup> . As shown in Supplementary Fig. 1, the pristine Cs2AgBiBr6 film is an indirect semiconductor with a bandgap value of 2.18 eV, which is consistent with previous reports<sup>24,25</sup> . However, after hydrogenating the Cs2AgBiBr6 films for 600 s and 1200 s, the treated Cs2AgBiBr6 films are still indirect semiconductors, and their bandgap values have been decreased from 2.18 eV to 1.91 eV and 

2 

NATURE COMMUNICATIONS | (2022) 13:3397 | https://doi.org/10.1038/s41467-022-31016-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-31016-w 



Fig. 1 Fabrication of the hydrogenated Cs2AgBiBr6 perovskite films and the photoelectrical property characterization. a The preparation method of Cs2AgBiBr6 perovskite films during the hydrogenation treatment in hydrogen gas plasma. b X-ray Diffraction (XRD) patterns of the Cs2AgBiBr6 perovskite films with different hydrogenation time (inserts show the optical pictures of the corresponding Cs2AgBiBr6 films). c Scanning electron microscopy (SEM) images of the pristine Cs2AgBiBr6 film and the 1200 s hydrogenated Cs2AgBiBr6 film. d Ultraviolet-visible absorption spectra (UV-vis) of the Cs2AgBiBr6 perovskite films with different hydrogenation time. e Photoluminescence (PL) spectra of the Cs2AgBiBr6 perovskite films with different hydrogenation time. f Carrier mobility and carrier concentration of the Cs2AgBiBr6 perovskite films with different hydrogenation time. g Time-resolved photoluminescence (TRPL) and the measurement of carrier lifetime (inset) of Cs2AgBiBr6 perovskite films with different hydrogenation time. 

3 

NATURE COMMUNICATIONS | (2022) 13:3397 | https://doi.org/10.1038/s41467-022-31016-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-31016-w 

further to 1.64 eV, respectively (Fig. 1d). In addition, as the increasing of hydrogenation time, a broad photoluminescence (PL) peak at around 760 nm raises continuously (Fig. 1e), which indicates a reduction of bandgap of Cs2AgBiBr6 film during hydrogenation treatment. 

It should be pointed out that some groups ascribed the enhancement of sub-bandgap adsorption to the defect state generation between the valence band (VB) and conduction band (CB), but always taking along with a reduction of PL intensity and lifetime<sup>41–43</sup> . In order to further understand the effect of plasma treatment on the photoelectrical properties of Cs2AgBiBr6 film, its carrier mobility, carrier concentration and carrier lifetime are tested as shown in Fig. 1f and g. The carrier mobility in the pristine Cs2AgBiBr6 film was about 1.71 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> and obtained from the Hall-effect measurement data (Supplementary Fig. 2). After hydrogenating the Cs2AgBiBr6 film for 600 s, the carrier mobility (3.17 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ) increases by 85%. As elongating the hydrogenation time to 1200 s, the carrier mobility (9.28 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ) increases up to 542%, as compared with the one in the pristine Cs2AgBiBr6 film (Fig. 1f). Meanwhile, the carrier concentration of Cs2AgBiBr6 film has been improved from 1.42 × 10<sup>12</sup> cm<sup>−3</sup> to 2.51 × 10<sup>12</sup> cm<sup>−3</sup> and further to 5.96 × 10<sup>12</sup> cm<sup>−3</sup> after 600 s and 1200 s hydrogenation treatment (Fig. 1f), which is mostly ascribing to the enhancement of light absorption range above 496 nm. Finally, an obvious increase of the carrier lifetime from 18.85 ns to 30.67 ns and further to 41.86 ns in hydrogenated Cs2AgBiBr6 film has been detected (inset in Fig. 1g, Supplementary Fig. 3 and Supplementary Table. 1) after hydrogenation treatment of the Cs2AgBiBr6 films for 600 s and 1200 s, which is quite different from the decreasing of PL lifetime that is induced by the defect state generation for sub-bandgap adsorption<sup>41,42</sup> . Therefore, considering on the results in UV-vis spectra, PL spectrum and PL lifetime, the bandgap of Cs2AgBiBr6 film was indeed reduced after hydrogenation, but not induced by the increasing of defect sate density in perovskite film<sup>41–43</sup> . 

In order to explore the influence of hydrogen atom (H<sup>*</sup> ) on Cs2AgBiBr6, the distribution of H<sup>*</sup> in Cs2AgBiBr6 film needs to be studied. After hydrogenating the perovskite films from 0 to 3000 s, the color evolution rate of the front (surface exposed in the hydrogen plasma environment) and back (see from the glass side of the film) sides of the Cs2AgBiBr6 films is quite different (Fig. 2a). In order to quantify the variation tendency for the front and back sides of the hydrogenated Cs2AgBiBr6 films, the blackness of the optical images on both sides was counted up as a change of hydrogenation time (black and red curves in Fig. 2a). It is clearly identified that the blackness keeps increasing gradually with the hydrogenation time increase, and the blackness of front side is always higher than the one of back side, especially when hydrogenating the Cs2AgBiBr6 film for 600–1800 s. After 1800 s hydrogenation treatment, the blackness difference of front and back sides becomes smaller. All these results indicate that the H<sup>*</sup> concentration in the hydrogenated Cs2AgBiBr6 film has a gradient distribution depending on the positing and hydrogenating time. 

During the hydrogenation treatment of Cs2AgBiBr6 film (Method), H<sup>*</sup> needs to diffuse firstly from the front side into the inner of perovskite film, so it obviously obeys the onedimensional constant surface concentration diffusion model<sup>44</sup> 



<!-- Start of picture text -->
C x<br>¼ erfc f f i  f f i  f ð2Þ<br>Cs �2 p Dt�<br><!-- End of picture text -->

where x is the diffusion thickness, D is diffusion coefficient of H<sup>*</sup> in Cs2AgBiBr6 film, t is the diffusion time (equivalent to hydrogenation time), Cs is diffusion source concentration (x = 0) and C is concentration at the depth x in film [Eq. 2]. However, due to the uncertainty of the diffusion coefficient of H<sup>*</sup> in Cs2AgBiBr6, it is hard to predict quantitatively the H<sup>*</sup> 

distribution concentration in perovskite film. The diffusion coefficient of H<sup>*</sup> in most materials ranges from 4.9 × 10<sup>−15</sup> cm<sup>2</sup> /s to 1.07 × 10<sup>−5</sup> cm<sup>2</sup> /s (Supplementary Table. 2)<sup>45–52</sup> . So here, to estimate the diffusion coefficient (detail see “Method” section), we first simulated the depthdependent CCs<sup>values at different hydrogenation time (600 s, 1200 s,</sup> 1800 s, 2400 s and 3000 s) based on the selected diffusion coefficients from 1 × 10<sup>−15</sup> cm<sup>2</sup> /s to 1 × 10<sup>−5</sup> cm<sup>2</sup> /s, as shown in Supplementary Fig. 4a–e, respectively. At a maximum film thickness of 140 nm (Supplementary Fig. 4f), the simulated CCs values are shown in Supplementary Fig. 4 and summarized in Supplementary Table. 3. Considering the simulated CCs<sup>value at the</sup> real film thickness should be comparable to the image blackness (details see Method and Fig. 2a) ratio at the front and back sides of hydrogenated Cs2AgBiBr6 film (Supplementary Fig. 4g and Supplementary Table. 3), the real diffusion coefficient D of H<sup>*</sup> in Cs2AgBiBr6 is then estimated to range from about 1 × 10<sup>−14</sup> cm<sup>2</sup> /s to 1 × 10<sup>−13</sup> cm<sup>2</sup> /s. Figure 2b shows a schematic diagram of H<sup>*</sup> diffusion in the hydrogenated Cs2AgBiBr6 film of 1200 s. 

After the diffusion of H<sup>*</sup> into the Cs2AgBiBr6 lattice, the perovskite films exhibit extraordinary stability in N2 environment undergoing long-term high temperature (85 °C) or 1 sun light illuminating treatments (Fig. 2c and d). After 80 day ageing process, these hydrogenated Cs2AgBiBr6 films keep optically black, indicating their superior stability in N2 environment with light and heat treatments. The excellent photoelectric properties of hydrogenated perovskite films mentioned above (Fig. 1) suggest that the hydrogenated Cs2AgBiBr6 should have great application potential in the lead-free PSC. In order to fabricate the PSC practically, energy level of hydrogenated Cs2AgBiBr6 needs to be firstly determined as shown in Fig. 2e. Here, the ultraviolet photoelectron spectroscopy (UPS) characterizations confirm that the work function ϕ of 0 s, 600 s and 1200 s hydrogenated Cs2AgBiBr6 films were −5.27 eV, −4.39 eV and −3.89 eV, and the energy gap ΔE between the energy level of maximum VB (EVBM) and Fermi level were 0.93 eV, 1.26 eV and 1.44 eV (Supplementary Fig. 5), respectively. Combining with the bandgap values in Fig. 1d, EVBM and minimum CB (ECBM) of hydrogenated Cs2AgBiBr6 films could be obtained as shown in Fig. 2e (details see Supplementary Fig. 5). 

Hydrogenated Cs2AgBiBr6 perovskite solar cells. To make sure the compatibility of energy level in PSC, the energy level positions of SnO2 and Spiro-OMeTAD were also determined through UVvis and UPS spectra as shown in Supplementary Fig. 6, from which we could find that they matched well with the energy level of hydrogenated Cs2AgBiBr6 films (Fig. 2f). So here, we selected SnO2, Spiro-OMeTAD, indium tin oxide (ITO) and gold (Au) as the electron transport layer (ETL), hole transport layer (HTL) and electrodes (Fig. 2f), respectively. And the PSC device was successfully prepared as shown in Supplementary Fig. 7, in which the layer structures could be identified clearly. The pristine Cs2AgBiBr6-based PSC exhibits a low PCE of only about 0.55%, and the short-circuit current density (Jsc) is 1.03 mA/cm<sup>2</sup> (see black lines and dots in Fig. 3a and d). After hydrogenating the Cs2AgBiBr6 films for 600 s and 1200 s, although the open-circuit voltage (Voc) has a little increase from 0.88 V to 0.92 V, the short-circuit current density (Jsc) increases significantly from 1.03 mA/cm<sup>2</sup> to 7.65 mA/cm<sup>2</sup> and further to 11.40 mA/cm<sup>2</sup> (Fig. 3a). For the 1200 s hydrogenated Cs2AgBiBr6 PSCs, the champion PCE values are 5.64% and 6.37% for forward and backward scans, respectively (Fig. 3b). And this is the record high efficiency in the Cs2AgBiBr6-based PSC devices so far. The corresponding photocurrent and PCE at maximum power output of 0.64 V bias are 

4 NATURE COMMUNICATIONS | (2022) 13:3397 | https://doi.org/10.1038/s41467-022-31016-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-31016-w 



Fig. 2 The distribution of atomic hydrogen, environmental stability and energy level in the hydrogenated Cs2AgBiBr6 film. a The optical images of the Cs2AgBiBr6 films with different hydrogenation time (top) and the blackness evolution of their corresponding images at the front and back sides (bottom). b The schematic diagram of the simulated distribution of atomic hydrogen in hydrogenated Cs2AgBiBr6 film according to a diffusion coefficient of 5 × 10<sup>−14</sup> cm<sup>2</sup> /s (top), and the diffusion curve of H<sup>*</sup> based on different diffusion coefficient at the depth direction of film (bottom). c Evolution of the bandgap values of hydrogenated Cs2AgBiBr6 films as storing in N2, 1 sun light illumination and 85 °C heating environments. d The photo-images (Front side) for stability of the hydrogenated Cs2AgBiBr6 films at N2, light illumination and 85 °C heating environments, respectively. e The energy level of ECBM, EVBM and EF (femi level) in Cs2AgBiBr6 films with different hydrogenation time (0 s, 600 s and 1200 s). f Energy-level diagram of the functional layers in hydrogenated Cs2AgBiBr6 perovskite solar cell. 

shown in Fig. 3c (the photocurrent of pristine and 600 s hydrogenated PSCs were shown in Supplementary Fig. 8). It could clearly observe that hydrogenated Cs2AgBiBr6 PSC devices exhibit a rapid response after light soaking, resulting in stable PCE (about 6.25% for 1200 s hydrogenated sample) and current density (9.78 mA/cm<sup>2</sup> ) during the continuous light illumination. Meanwhile, the average PCE of hydrogenated Cs2AgBiBr6 is effectively improved from 0.42% (0 s) to 2.95% (600 s) and then to 5.56% (1200 s) (Fig. 3d). The statistical analysis of Voc, Jsc and fill factor (FF) were summarized in Supplementary Fig. 9. 

To further confirm the decrease of bandgap value and enhancement of Jsc, external quantum efficiency (EQE) spectra of Cs2AgBiBr6 PSCs with different hydrogenation time (0 s, 600 s and 1200 s) are shown in Fig. 3e. The photoresponse range expands gradually from 539 nm for pristine to 720 nm for 1200 s hydrogenated Cs2AgBiBr6 PSCs, and matches well with the tendency of bandgap in Fig. 1d and e. Meanwhile, as enlarging the hydrogenation time, the integrated current density values of hydrogenated Cs2AgBiBr6 PSCs raise from 1.02 mA/cm<sup>2</sup> to 7.57 mA/cm<sup>2</sup> and further to 11.29 mA/cm<sup>2</sup> (Fig. 3e). The 

5 

NATURE COMMUNICATIONS | (2022) 13:3397 | https://doi.org/10.1038/s41467-022-31016-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-31016-w 



Fig. 3 Photoelectrical performance and environmental stability of hydrogenated Cs2AgBiBr6 perovskite solar cell. a Current density-voltage (J-V) curve of the champion Cs2AgBiBr6 PSCs with different hydrogenation time (0 s, 600 s and 1200 s). Inset shows the schematic of the layered perovskite solar cell. b J-V curves under reverse and forward bias of 1200 s hydrogenated Cs2AgBiBr6 PSC. c Steady-state photocurrents of 1200 s hydrogenated Cs2AgBiBr6 PSCs at bias voltages of 0.64 V near the maximum power output. d The average photoelectric conversion efficiency (PCE) distribution of Cs2AgBiBr6 PSCs with different hydrogenation time (0 s, 600 s and 1200 s). The outliers, middle line, upper/lower box limits and upper/lower whiskers in the box plot indicate the single points, median, 25th/75th quartiles, and maximum/minimum, respectively. e EQE spectrum of and integrated current density of the Cs2AgBiBr6 PSCs with different hydrogenation time (0 s, 600 s and 1200 s). f Long-term stability of 1200 s hydrogenated Cs2AgBiBr6 PSCs under light illumination, 85 °C, 85 °C plus light illumination and double 85 condition of 85% humidity at 85 °C, respectively. 

integrated current density values with different hydrogenation time are well consistent with the corresponding Jsc values determined by the J-V curves in Fig. 3a. 

After hydrogenation treatment, the photoelectric properties of hydrogenated Cs2AgBiBr6 PSCs have been effectively improved. In order to understand the environmental stability of hydrogenated Cs2AgBiBr6 PSCs, the devices were treated in nitrogen at 20 °C with light illumination, and at 85 °C without or with light illumination for 1440 h, respectively (Fig. 3f). After these 

environmental treatments, they maintained nearly 95%, 91% and 84% of initial PCE, respectively. However, when storing in air with 85% relative humility at 85 °C for 1440 h, the PCE of hydrogenated Cs2AgBiBr6 PSC devices reduced near 42% as compared with the initial one (Fig. 3f). All these results indicate that the hydrogenated Cs2AgBiBr6 PSCs have excellent thermostability and light illumination stability in nitrogen environment or when encapsulated to isolate moisture, that could promote the practical application of hydrogenated Cs2AgBiBr6 PSC devices. 

6 

NATURE COMMUNICATIONS | (2022) 13:3397 | https://doi.org/10.1038/s41467-022-31016-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-31016-w 



Fig. 4 Analyses on the evolution of Cs2AgBiBr6 films during hydrogenation treatment. a XRD spectra indicating the generation of CsBr (110) peak (marked by the red arrow) with different hydrogenation time. b XRD spectra of the Cs2AgBiBr6 (044) peak under different hydrogenation time. c Evolution tendency for the XRD area proportion of CsBr (110) peak as compared with the ones of Cs2AgBiBr6, inset shows the peak shift of Cs2AgBiBr6 (044) to the low XRD angle during the hydrogenation treatment. d–g Quasi in situ observation for the structural evolution of hydrogenated Cs2AgBiBr6 film, red and orange markers indicate the Cs2AgBiBr6 and CsBr phases, respectively. The detailed evolution process of the areas marked with baby blue rectangles in Fig. 4d–f were listed in Fig. 4g. h–k HAADF images of pristine and hydrogenated Cs2AgBiBr6 films, and the corresponding Fast Fourier transform (FFT) images for the areas marked by red and blue boxes. 

### Discussion 

In order to comprehensively understand the evolution of Cs2AgBiBr6 crystal structure during the hydrogenation treatment, the X-ray Diffraction (XRD) spectra of Cs2AgBiBr6 perovskite films with different hydrogenation time were measured as shown in Supplementary Fig. 10 and Fig. 4a. When the hydrogenation treatment time is <1200 s, the XRD peak of Cs2AgBiBr6-(044) was slightly offset with the increase of hydrogenation time (Fig. 4b). And a low angle shift of Cs2AgBiBr6-(044) XRD peak from initial 

45.506°–45.480° indicates a lattice expansion of about Δa = 0.006 Å at the hydrogenation time of 1200 s (Fig. 4c). However, when increasing the hydrogenation treatment time larger than 1400 s, a new XRD peak at 29.375° appears and enhances gradually, which could be labeled as CsBr (110) in Fig. 4a and confirmed by transmission electron microscopy (TEM) in Fig. 4f and g. In addition, BiBr (<sup>�</sup> 312) peak may coexist and overlap with CsBr (110) peak as discussed in the caption of Supplementary Fig. 10. To further confirm this phenomenon, 

7 

NATURE COMMUNICATIONS | (2022) 13:3397 | https://doi.org/10.1038/s41467-022-31016-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-31016-w 

quasi in situ TEM observation for the hydrogenated Cs2AgBiBr6 was shown in Fig. 4d–g (beam damage was considered as shown in Supplementary Fig. 11, detail see Methods). Initially, the main diffraction spots in the selected area electron diffraction (SAED) pattern of Cs2AgBiBr6 film were determined as along [0<sup>�</sup> 21] zone axis (Fig. 4d). As increasing the hydrogenation time from 0 s to 1200 s, the SAED patterns can still be identified as Cs2AgBiBr6 (Fig. 4e), but the diffraction spots gradually dim and expand (marking by the rad arrows in Fig. 4g), which indicates the lattice expansion as the ones in Fig. 4c. When enlarging the hydrogenation time up to 1400 s, CsBr (110) spot began to emerge near the Cs2AgBiBr6 (<sup>�</sup> 400) diffraction spot (marking by the orange arrows in Fig. 4g). Meanwhile, the morphology of the Cs2AgBiBr6 film changed obviously (Supplementary Fig. 12). And when the hydrogenation time reached 2400 s, most of the perovskite film decomposed (Fig. 4f), the XRD pattern of polycrystal CsBr and ion chromatography signal of HBr were much more clear (Supplementary Fig. 10 and Supplementary Fig. 13, Methods). It should be pointed out that, the champion PCE of hydrogenated Cs2AgBiBr6 PSC presents at the 1200 s hydrogenated samples (Fig. 3a and b). At this moment, Cs2AgBiBr6 film only processes a lattice distortion due to the atomic hydrogen insertion (Fig. 4h–k) and no impurity phase peak could be detected. So, it is reasonable to conclude that the introducing of hydrogen atom into Cs2AgBiBr6 lattice (not the decomposition intermediates) would regulate down the bandgap of perovskite film and increase the light harvest for high PCE of PSCs. In addition, to quantify the evolution tendency of H<sup>*</sup> concentration associating with the lattice expansion of Cs2AgBiBr6 film, crystal lattice parameter calculated by first-principle calculations were summarized in Supplementary Table. 4, from which we could deduce that the average doping concentration of H<sup>*</sup> should be lower than 0.3125 at.% (1/320 of atoms) in 1200 s hydrogenated Cs2AgBiBr6. 

For the effect of H<sup>*</sup> on chemical state of Cs2AgBiBr6 film, X-ray photoelectron spectroscopy (XPS) was used as shown in Fig. 5a–c and Supplementary Fig. 14. For the pristine Cs2AgBiBr6 film, only one Cs 3d3/2 XPS peak at 739.2 eV was present. However, after hydrogenating the Cs2AgBiBr6 films for 600 s and 1200 s, the Cs 3d3/2 peak divided into two peaks: one shifts to a low binding energy of 738.7 eV (600 s) and then to 738.6 eV (1200 s), the other one shifts to a high binding energy from 739.2 eV (0 s) to 740.6 eV (600 s) and then to 741.1 eV (1200 s) (Fig. 5a). For Ag 3d3/2 peak, the increase of hydrogenation time would induce an increase of binding energy from 374.0 eV to 374.1 eV and further to 374.2 eV (Fig. 5b). However, the major peak of Bi 4f5/2 in Cs2AgBiBr6 films keeps at around 164.7 eV (Fig. 5c), but a small peak appears at around 162.2 eV and 162.0 eV after 600 s and 1200 s hydrogenation treatment. In addition, the binding energy position of Br 3d in Cs2AgBiBr6 films almost unchanged after 600 s and 1200 s hydrogenation treatment (Supplementary Fig. 14). 

Although the hydrogenation process affects the chemical environment of Cs, Ag and Bi atoms in Cs2AgBiBr6 lattice, the occupation position of H<sup>*</sup> in the crystal lattice of Cs2AgBiBr6 is still unknown. To settle this problem, DFT calculation with HSE + SOC band structures of host Cs2AgBiBr6 is used to simulate the possible H<sup>*</sup> positions in Cs2AgBiBr6 lattice as shown in Fig. 5d and Supplementary Fig. 15. There exists three different structure units in Cs2AgBiBr6 lattice for H<sup>*</sup> incorporation, including: Ag-Br-Cs hexahedron (named as H1), Bi-Br-Cs hexahedron (H2), and Cs-Br-Cs octahedron (H3) sites as shown in Fig. 5d and Supplementary Fig. 16. Here the H<sup>*</sup> may be a substitutional atom at the Br site in Hn(Br) (where n = 1, 2, or 3) (Supplementary Fig. 16a–c) or as an interstitial hydrogen in Hn(in) polyhedrons (insets in Fig. 5d). However, for the hydrogen substitution on Br site, the bandgap for all H1/2/3(Br) 

configurations almost unchanged as compared with the host Cs2AgBiBr6 (Supplementary Fig. 15 and Supplementary Fig. 16). The inconsistency between theoretical simulation results and experimental results (Fig. 1d) indicates that the substitution of H<sup>*</sup> at the Br sites is not the main contribution for the optimization of bandgap in hydrogenated Cs2AgBiBr6. 

For the interstitial doping of hydrogen (as the form of H<sup>*</sup> or H2) in Cs2AgBiBr6 structure, there are various different positions, as shown in the H1(in), H2(in) and H3(in) structures for the form of H<sup>*</sup> in Fig. 5d, Supplementary Fig. 17 and the H2-1(in), H2-2(in) and H2-3(in) structures for the form of H2 in Supplementary Fig. 18. However, for hydrogen molecule doping into the Cs2AgBiBr6 lattice in Supplementary Fig. 18, they are apparently not consistent with the experimental results (Fig. 1d). Therefore, we need only considering on the three different structures of H1(in), H2(in) and H3(in). For the formation energies of H1(in), H2(in) and H3(in) structures, though H3(in) has the highest value, the difference between them are small, indicating the formation of H1(in), H2(in) and H3(in) in hydrogenated Cs2AgBiBr6 are both possible (Fig. 5d). For the host Cs2AgBiBr6, its bandgap (by using the HSE + SOC model, Supplementary Fig. 15) has been determined to be indirect with a value of 1.98 eV, which is close to the experimental one of 2.18 eV in Fig. 1). However, for the three different types of Hn(in) structures (Fig. 5d), interbands are formed between the upper VB and lower CB, leading to the decreasing of effective bandgaps compared with the host Cs2AgBiBr6 (Supplementary Fig. 17), which is consistent with the experimental result (Fig. 2e). In addition, we also noticed that hydrogenation treatment of the Cs2AgBiBr6 film induced almost no defect state increasing between its valence and conductive bands (Supplementary Fig. 19). And the physical model for the energy level positions of Hn(in) structures are derived as shown in Fig. 5e. On one hand, H-1s orbital couples with cation and forms the bonding state (Supplementary Fig. 17), which is higher than VBM (Fig. 5e); on the other hand, H-1s orbital couples with anion and forms antibonding state (Supplementary Fig. 17), which is higher than CBM (Fig. 5e). This physical model is well matched with the experimental energy-level diagram in hydrogenated Cs2AgBiBr6 (Fig. 2e, f). 

In addition, the variations of charges on Ag, Cs and Bi atom sites in different Hn(in) structures are investigated by bader analysis and compared with the one in host structure, as shown in Fig. 5f. The decreased bader charge of Ag atom in H1(in) means Ag losing some electrons to the surrounding atoms and leading to the increasing of Ag 3d binding energy. This is in agreement with the variation tendency of Ag 3d peak position shift in XPS results (increasing of binding energy in Fig. 5b and g), which indicates the existence of H1(in) in hydrogenated Cs2AgBiBr6. However, the increasing bader charge of Bi atom in H2(in) suggests an electron gain of Bi atom from the surrounding atoms (Fig. 5f), resulting in the decreasing binding energy of Bi 4 f. This is consistent with the decrease of Bi 4 f binding energy in XPS results (Fig. 5c and g) and reveals the formation of H2(in) in hydrogenated Cs2AgBiBr6. What’s more, the existence of H1(in) and H2(in) structures would induce the decrease of bader charges (Fig. 5f) and increase of binding energy of Cs atoms, which is well matched with the peak position increasement of Cs 3d in XPS results (Fig. 5a and g). On the other hand, the presence of H3(in) induces an increase of bader charge of Cs atoms, which corresponds to a decreasing binding energy of Cs 3d (Fig. 5a and g). So, by analyzing the changes of bader charges and comparing them with XPS results (Fig. 5), we confirm that the interstitial doping of H<sup>*</sup> in H1(in), H2(in) and H3(in) structures do exist in the hydrogenated Cs2AgBiBr6. 

In this paper, we have developed a hydrogenation method to modify the material properties of Cs2AgBiBr6 film. After 

8 

NATURE COMMUNICATIONS | (2022) 13:3397 | https://doi.org/10.1038/s41467-022-31016-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-31016-w 



Fig. 5 Analyses on the chemical environment of Cs2AgBiBr6 during hydrogenation treatment. a–c X-ray photoelectron spectroscopy (XPS) spectra of Cs 3d, Ag 3d and Bi 4 f in Cs2AgBiBr6 films with different hydrogenation time (0 s, 600 s and 1200 s). d The formation energies of H1(in), H2(in) and H3(in). Here, Hn(in), where n = 1, 2, or 3, presents the H atom in the interstitial position of the Hn polyhedrons surrounded by Cs-Br-Ag (H1), Cs-Br-Bi (H2), and Cs-Br-Cs (H3), respectively. Cs, Ag, Bi, Br and H atoms are represented by cyan, light gray, purple, brown and red dots, respectively. e Schematic band coupling models of Hn(in) showing energy level positions when the H 1 s orbital is coupled to anion (forming donor) and cation (forming acceptor) levels (HA (coupled from interstitial Hn(in) and anion) and HC (coupled from interstitial Hn(in) and cation)). f Bader charge variations of Ag, Bi, and Cs atoms in the host and next to the interstitial H<sup>*</sup> in the Hn(in) polyhedrons. g The variation tendency of binding energy of Cs 3d3/2, Ag 3d3/2 and Bi 4f5/2 peaks as the increase of hydrogenation time. 

hydrogenating treatment of the Cs2AgBiBr6 film from 0 s to 1200 s, the light absorption at the wavelength above 496 nm increases apparently, which corresponds to a decrease of bandgap from 2.18 eV to 1.64 eV. At the same time, the carrier concentration of the hydrogenated Cs2AgBiBr6 films increases from 1.42 × 10<sup>12</sup> cm<sup>−3</sup> to 5.96 × 10<sup>12</sup> cm<sup>−3</sup> , and the carrier mobility and lifetime have also been largely improved from 1.71 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> and 18.85 ns, to 9.28 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> and 41.86 ns, respectively. Based on this, the hydrogenated Cs2AgBiBr6 perovskite films are fabricated into solar cells, and the highest PCE of 6.37% is achieved, which is a record high efficiency of Cs2AgBiBr6-based PSC. Firstprinciple calculations confirm that hydrogen atoms are doped into the interstitial sites of Cs2AgBiBr6 lattice, and the band couplings between hydrogen atoms and anion/cation alter the valence/CB levels, which agrees well with the experimental results. All these findings provide an effective lattice engineering strategy for preparing high-efficient and bandgap tunable lead-free inorganic PSCs, which are not only environment-friendly for optoelectronic device applications, but also remarkable stable in appropriate working or storage environments. And this discovery may offer a good opportunity for exploring the next generation PSC and other optoelectronic devices. 

### Methods 

Materials. The experimental materials such as tin oxide (SnO2, 15%), cesium bromide (CsBr, 99.9%), silver bromide (AgBr, 99.5%) and bismuth bromide (BiBr3, 99%) were purchased from Alfa Aesar. Dimethylsulfoxide (DMSO, anhydrous 99.9% Sigma-Aldrich), isopropanol (IPA 99.5%, Aladdin), acetonitrile (99.8%, Sigma-Aldrich), 4-tertbutylpyridine (96%, Sigma-Aldrich), bis (trifluoromethane) sulfonimide lithium salt (99%, Xi’an Polymer Light Technology Corp), chlorobenzene (99%, Aladdin) and spiro-OMeTAD (99.5%, Xi’an Polymer Light Technology Corp) were used without further purification. 

Preparation of perovskite precursor solutions. In this work, we adopt a solution spin-coating method<sup>4</sup> to prepare high quality Cs2AgBiBr6 films. As we all known, the solubility of Cs2AgBiBr6 in dimethylsulfoxide (DMSO) solution is about 0.6 mol/L, here we choose DMSO as the precursor solvent<sup>20</sup> . The Cs2AgBiBr6 perovskite precursor solution (0.6 mol/L) was prepared by dissolving 212.81 mg CsBr, 187.77 mg AgBr and 448.68 mg BiBr3 into 1 mL of anhydrous solvent of DMSO. In order to ensure sufficient solubility and prepare high quality Cs2AgBiBr6 perovskite film, the perovskite precursor solution was stirred at 70<sup>o</sup> C in glove box for 12 h until the solutes were completely dissolved into the DMSO solvent and filtered through 0.45 μm poly tetra fluoro ethylene (PTFE) filtering membrane. 

Determination of the diffusion coefficient of atomic hydrogen in Cs2AgBiBr6 film. As shown in Eq. 2, the evolution of CCs<sup>values could be deduced as a change of</sup> hydrogenation time and atomic hydrogen diffusion coefficient (Supplementary Fig. 4). However, due to the thickness of Cs2AgBiBr6 film is about 140 nm (Supplementary Fig. 4f), so the determination of CCs<sup>values at the top surface and bottom</sup> of a 140 nm thick Cs2AgBiBr6 film is critical important as shown in Supplementary Table 3. However, in practice, it is very difficult to quantify the atomic hydrogen concentration at the top surface and bottom of the hydrogenated Cs2AgBiBr6 film, which inversely limits the analysis on the accurate diffusion coefficient of atomic hydrogen in Cs2AgBiBr6 film. To settle this problem, we firstly extract the CCs00<sup>values</sup> from the experimental optical images in Fig. 2a and compare them with the simulated values CCs<sup>inSupplementaryTable3.Asshownabove,theoptical</sup> absorption properties of hydrogenated Cs2AgBiBr6 film increases as the increasing of hydrogenation time (actually the hydrogen concentration increase), and film became much darker (Fig. 2a). From this point of view, it is assumed that the blackness values of the front and back side optical images (in Fig. 2a) are directly proportional to the average hydrogen concentration near the top and bottom surface of hydrogenated Cs2AgBiBr6 film, respectively (as shown by Csˊ and Cˊ in Supplementary Fig. 4g). However, the hydrogen concentration is gradient distributed from the top surface to the bottom of film (Fig. 2b), this means that the experimental CCs00<sup>valuesmustbelargerthanthesimulated</sup> CCs<sup>values</sup><sup>~~(~~</sup> CCs00<sup>~~>~~</sup> CCs<sup>~~)~~</sup> (Supplementary Fig. 4g). According to the experimental CCs00<sup>valueof0.205atthehydrogenationtimeof</sup> 600 s (Supplementary Table 3), the simulated CCs<sup>value should be less than 0.205 and</sup> we can find that only a diffusion coefficient smaller than 1 × 10<sup>−13</sup> cm<sup>2</sup> /s 

9 

NATURE COMMUNICATIONS | (2022) 13:3397 | https://doi.org/10.1038/s41467-022-31016-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-31016-w 

~~(~~ CCs<sup>¼ 0:203) is appropriate. Meanwhile, such a diffusion efficient of 1 × 10−13 cm2/s</sup> is applicable to the CCs00<sup>and</sup> CCs<sup>~~v~~aluesatthehydrogenationtimeof1200 s</sup> ~~(~~ CCs00<sup>¼ 0:405 ></sup> CCs<sup>¼ 0:366),1800 s</sup><sup>~~(~~</sup> CCs00<sup>¼ 0:834 ></sup> CCs<sup>¼ 0:460),2400 s</sup> ~~(~~ CCs00<sup>¼ 0:963 ></sup> CCs<sup>¼ 0:522)and3000 s</sup><sup>~~(~~</sup> CCs00<sup>�1:000 ></sup> CCs<sup>¼ 0:571).Itshouldbe</sup> pointed out that, as the hydrogenation time increasing up to 3000 s, the front and back sides color of the hydrogenated Cs2AgBiBr6 film are both black, which takes a CCs00<sup>�1:000: It indicates that a large number of hydrogen atoms must have reached to</sup> the bottom of the Cs2AgBiBr6 film after 3000 s hydrogenation treatment. However, from the data in Supplementary Table 3, if the diffusion efficient is <1 × 10<sup>−14</sup> cm<sup>2</sup> /s, then the CCs<sup>value equals to 0.074 even after a 3000 s of hydrogen diffusion. From all</sup> the analyses above, we can conclude that the diffusion coefficient D of atomic hydrogen in Cs2AgBiBr6 film must be located in the range between 1 × 10<sup>−14</sup> cm<sup>2</sup> /s and 1 × 10<sup>−13</sup> cm<sup>2</sup> /s. 

Device fabrication. Inorganic lead-free double PSCs with typical planar structure ITO/SnO2/perovskite/spiro-OMeTAD/Au were fabricated as follows: The ITO glass substrates were washed by ultrasonic cleaning in acetone, ethanol, detergent and deionized water for 30 min, respectively. After drying, the ITO glass substrates were treated by an oxygen plasma for 10 min to improve the hydrophilicity of the substrate surface. The original solution of SnO2 was mixed with deionized water in the volume ratio of 1:5. SnO2 solution of 50 μL was dynamically spin-coated on the clean ITO glass substrates at 3000 rpm for 30 s. Then the SnO2 ETL film was annealed at 150 °C for 30 min in air. In order to improve the surface coverage and film quality, a lot of efforts were made in our research such as: increasing the spincoating temperature<sup>53</sup> to 40 °C and using isopropanol (IPA) solution as antisolovent during the spin-coating process as shown in Fig. 1a. Cs2AgBiBr6 perovskite films were deposited in the glove box full of N2 using traditional solventquenching method with IPA as the antisolvent. 50 μL Cs2AgBiBr6 precursor solution was dynamically spin-coated at 40 °C on the cleaned ITO glass substrates at 5000 rpm for 50 s, and 300 μL antisolvent (IPA solvent) was spin-coated at 10 s, which was just before the atomization point. Then the film was annealed at 290 °C for 5 min. Then, the perovskite films were plasma treated for different times. 

Spiro-OMeTAD was used as the HTL. To prepare the Spiro-OMeTAD solution, 45 μL Li-TFSI solution (170 mg/mL acetonitrile), 10 μL 4-TBP and 90 mg SpiroOMeTAD were mixed into 1 mL chlorobenzene solvent and then stirred in a dark environment in N2 glove box until fully dissolved. After that, 50 μL SpiroOMeTAD solution was dynamically spin-coated on the surface of the perovskite film at 3000 rpm for 30 s in N2 glove box. After the spin-coating, it was placed in oxygen atmosphere and kept away from light for 24 h to make Spiro-OMeTAD layer fully oxidized. Au electrode was coated on the Spiro-OMeTAD HTL by thermal evaporation. The interface between the electrode film and the HTL was well combined. The electrode film was uniform with the thickness of about 60 nm. 

Plasma treatment on the perovskite film. In order to doping the hydrogen atoms into Cs2AgBiBr6 film, the film was hydrogenated through a plasma treatment (Soft Plasma Cleaner SPC 150) with the source power of 30 W in Ar and H2 mix (80 vt.% H2) gas. For the plasma equipment, with a molecular pump keeps the stable gas pressure in the working condition, the plasma power is of lower than 40 Watts and equipped with radio frequency (RF) ion source of 13.56 MHz. Indicating that the sample could be considered as a uniformly exposure of steady plasma environment<sup>54</sup> . 

Normally, one of the most important feature of “cold” plasma is that the electron temperature is lower than 10 eV<sup>55</sup> . According to the average electron temperature values listed in Supplementary Table. 5, the plasma treatment in our experiment belongs to low temperature plasma. To intuitively observe the local temperature during the working condition in plasma chamber, the irreversible surface temperature indicating strips (ISTIS, Thermax, temperature error of ±1 °C) were used to determine the temperature as shown in Supplementary Fig. 20a–c, from which the working temperature was finally determined to be lower than 37 °C. In addition to the environment temperature of the thermal steady state of the plasma chamber, the temperature of the chemical events at the atomic scale should also be taken into account. To describe the chemical interaction between plasma gas and Cs2AgBiBr6 film, the maximum energy transfer ET from highly energetic hydrogen radicals to the surface atom of Cs2AgBiBr6 should be considered [Eq. 3], 



<!-- Start of picture text -->
2MEðE þ 2mc 2 Þ<br>ET ¼ ð3Þ<br>ðm þ MÞ 2 c 2 þ 2ME<br><!-- End of picture text -->

here, E is kinetic energy of the incoming plasma excited hydrogen radical; m, M is the mass of hydrogen atom and the chemical elements in Cs2AgBiBr6; c is the velocity of light (3.00 × 10<sup>8</sup> m/s). If the kinetic energy E is much smaller than mc<sup>2</sup> (mc<sup>2</sup> ¼ 9.40 × 10<sup>8</sup> eV for the hydrogen atom) [Eq. 4], the equation could be simplified as<sup>56</sup> 



<!-- Start of picture text -->
4Mm<br>ET ¼ E ð4Þ<br>ðm þ MÞ 2<br><!-- End of picture text -->

In this work, the maximum kinetic energy of radicals in hydrogen plasma is 9.3 eV (Supplementary Table 5), which is much smaller than mc<sup>2</sup> . So, the energy 

transfer from the hydrogen radicals to the surface atoms in Cs2AgBiBr6 could be deduced from Eq. 4. Based on this, the maximum energy transfer EF to the surface atoms of Cs, Ag, Bi and Br could be determined as 0.28 eV, 0.34 eV, 0.18 eV and 0.46 eV, respectively, which are obviously lower than the bond dissociation energies of Cs-Br (4.03 eV), Bi-Br (2.49 eV) and Ag-Br (2.91 eV) in Cs2AgBiBr6 (Supplementary Table 6)<sup>57</sup> . Therefore, the calculation results indicate that the low temperature hydrogen plasma treatment is hard to break the chemical bonds in Cs2AgBiBr6. 

However, the Cs2AgBiBr6 lattice is stable only when the hydrogenation treatment is <1200 s. The decomposition of hydrogenated Cs2AgBiBr6 phase occurs after 1400 s hydrogenation treatment (Fig. 4), which is attributed to the intrinsic structural instability of hydrogenated Cs2AgBiBr6. As increasing the concentration of atomic hydrogen into Cs2AgBiBr6 lattice, the formation energy of perovskite does process a raising (Fig. 5d). 

Determination of perovskite film decomposition products by ion chromatography. Bromine-anion calibration standard solutions were prepared by diluting the HBr stock solution with deionized water to the desired concentration. The eluent was prepared by adding 20 mL 0.24 mol/L Na2CO3 water solution and 10 mL 0.3 mol/L NaHCO3 water solution into 1000 mL ultrapure water. All solutions were filtered using a 0.45 μm filter before use. A commercial Metrohm 883 Basic IC plus instrument equipped with anion-separation column (Metrosep A Supp 5) was used for obtaining the ion chromatogram. 

Characterization of solar cells and films. We measured J-V curves of PSC devices in air with Keithley 2400 Source under AM 1.5 (100 mW cm<sup>−2</sup> , xenon lamp, Newport) irradiance level. All the I-V measurements were carried out in ambient air environment. The area of each device is 0.2 cm<sup>2</sup> . During measuring, a 0.04 cm<sup>2</sup> non-reflective mask was used to define the accurate active cell area with the testing range of reverse scanning voltage from 1.2 V to −0.2 V (step 0.02 V). The drivelevel capacitance profiling measurement was performed at ac frequency of 10 kHz (total carrier density) by subtracting frequency and 500 kKz (free carrier density) by using Semiconductor Device Analyzer (Keysight B1500A). Steady-state and transient-state PL spectra were obtained by using FLS-1000 fluorescence spectroscopy (Edinburgh Instruments) at 430 and 470 nm excitation wavelength, respectively. The external quantum efficiencies and integrated current of PSCs were measured by using Zolix SCS10-X150-DSSC. The optical absorption spectrum was measured in air by an ultraviolet-visible near-infrared spectrophotometer (UV-Vis) (Hitachi, UH-4150). The XRD spectra of the perovskite films were obtained with Bruker D8 Advance X-ray diffractometer using Cu Kα radiation (λ = 1.5418 Å). Scanning electron microscope (Helios Nanolab 600i) operated at 5 kV was used to characterize the microstructure of films and cross-section of PSC. The carrier lifetime was obtained by using B411 (FLS-1000). The XPS and UPS spectrums were measured through XPS system (ESCALAB 250Xi). The electrical properties were measured with four-point probe method by using Hall-effect measurement system (Eastchanging ET 9000). 

The preparation and characterization of transmission electron microscopy (TEM) samples. The TEM sample of Cs2AgBiBr6 perovskite devices were prepared through Focused Ion Beam (FIB) system (Helios Nanolab 600i) operating at 2–30 kV. In order to make sure the cleanliness of the device surface, the sample was first cleaned by N2 gas gun before putting into the FIB system. Firstly, we selected one flat area and deposited 1.2 μm thick Pt layer (200 nm e-beam deposition with 5 kV, 2.7 nA followed by 1 μm ion beam deposition with 30 kV, 30 pA) onto the surface of device, which could protect the sample from the harm of Ga ion beam damage. Then, the specimen was crosscut and thinned to about 200 nm from 1.5 μm by using 30 kV Ga ion beam. Lastly, in order to remove the surface damage layer, a final polishing was performed first using 5 kV, 15 pA and further using 2 kV, 23 pA Ga ion beam. TEM sample of Cs2AgBiBr6 films was prepared by transfer of as-grown Cs2AgBiBr6 films onto a TEM grid. Samples were investigated by using probe spherical aberration corrected transmission electron microscope (FEI Titan G2) with 300 kV accelerating voltage and gain the images using scanning transmission electron microscopy-high angle annular dark field (STEM-HAADF) detectors. The microscopic chemical compositions of the samples were analyzed by using high efficient “Super X” Energy Disperse Spectroscopy (EDS) detector. The energy resolution of the super-EDX is 137 eV. The EDS data were collected and processed by using Esprit 1.9 software. In order to explore the effect of electron beam on lead-free inorganic double perovskite Cs2AgBiBr6, in situ analysis on structure evolution under continuous electron beam was performed through SAED as shown in Supplementary Fig. 11. Based on the results in Supplementary Fig. 11, to avoid the beam damage on the TEM characterization of Cs2AgBiBr6 samples, the total electron dose should be controlled less than 300 e<sup>−</sup> /Å<sup>2</sup> . The electron dose rate was controlled to be 1 e<sup>−</sup> /Å<sup>2</sup> s for TEM model and the acquisition time for each TEM image is 1 s (Fig. 4d–g, Supplementary Fig. 11 and Supplementary Fig. 12). While, for the HAADF images in Fig. 4h and i, the electron dose rate is about 2 × 10<sup>6</sup> e<sup>−</sup> /Å<sup>2</sup> s, and the acquisition time of each pixel is about 2 μs. 

DFT calculation. First-principles calculations were performed using DFT as implemented in the VASP code<sup>58,59</sup> . The electron and core interactions were 

10 

NATURE COMMUNICATIONS | (2022) 13:3397 | https://doi.org/10.1038/s41467-022-31016-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-31016-w 

included using the frozen-core projected augmented wave approach<sup>60</sup> . The generalized gradient approximation of Perdew–Burke–Ernzerhof (PBE)<sup>61</sup> was used for the exchange correlation functional. The kinetic energy cutoff for plane-wave basis functions is set to 400 eV. K-point meshes with grid spacings of 2π × 0.025 Å<sup>−1</sup> or smaller were used for Brillouin zone integration. The structures of Cs2AgBiBr6 with the Fm3m space group were relaxed until the total energies converged to 10<sup>−4</sup> eV. All the atoms are fully relaxed for the substitutional hydrogen (H1/2/3(Br)) and interstitial hydrogens (H1/2/3(in)) in Cs2AgBiBr6 lattice. The formation energies and Bader charges of H1/2/3(in) are conducted using PBE functional. The formation energy are defined as: ΔEf = E(Hi)-E(host)-0.5·E(H2), where E(Hi), E(host) and E(H2) are the total energies of Hi, pure Cs2AgBiBr6 and hydrogen molecule, respectively. Whereas, a hybrid Heyd–Scuseria–Ernzerhot (HSE)<sup>62</sup> with a standard 25% Hartree Fock exchange was used for evaluating the bandgaps. Due to the heavy element Bi in Cs2AgBiBr6, spin-orbit coupling (SOC) effect was also taken into consideration in the calculations. 

Ageing process of perovskite films. Cs2AgBiBr6 perovskite films could change from yellow to black after hydrogenation process, indicating the large increase in light absorption. Then we ageing the hydrogenated Cs2AgBiBr6 films at different condition including: 20 °C/N2/dark, 20 °C/N2/1-sun-light-illumination and 85 °C/ N2/dark environments. Then we take optical images of the hydrogenated Cs2AgBiBr6 films at different ageing time and gain the bandgap values of the films through UV-Vis. 

Reporting summary. Further information on research design is available in the Nature Research Reporting Summary linked to this article. 

### Data availability 

The source data generated in this study are provided in the Source Data file. Source data are provided with this paper. 

Received: 12 June 2021; Accepted: 26 May 2022; 



17. Savory, C. N., Walsh, A. & Scanlon, D. O. Can Pb-free halide double perovskites support high-efficiency solar cells? ACS Energy Lett. 1, 949–955 (2016). 

18. Wang, M. et al. High-Quality sequential-vapor-deposited Cs2AgBiBr6 thin films for lead-free perovskite solar cells. Sol. Rrl. 2, 1800217 (2018). 

19. Gao, W. et al. High-quality Cs2AgBiBr6 double perovskite film for lead-free inverted planar heterojunction solar cells with 2.2% efficiency. Chem. Phys. Chem. 19, 1696–1700 (2018). 

20. Greul, E., Petrus, M. L., Binek, A., Docampo, P. & Bein, T. Highly stable, phase pure Cs2AgBiBr6 double perovskite thin films for optoelectronic applications. J. Mater. Chem. A. 5, 19972–19981 (2017). 

21. Sirtl, M. T. et al. 2D/3D Hybrid Cs2AgBiBr6 double perovskite solar cells: Improved energy level alignment for higher contact-selectively and large open circuit voltage. Adv. Energy Mater. 12, 2103215 (2022). 

22. Wang, B. N. et al. Chlorophyll derivative-sensitized TiO2 electron transport layer for record efficiency of Cs2AgBiBr6 double perovskite solar cells. J. Am. Chem. Soc. 143, 2207–2211 (2021). 

23. Wang, B. N. et al. Organic dye/Cs2AgBiBr6 double perovskite heterojunction solar cells. J. Am. Chem. Soc. 143, 14877–14883 (2021). 

24. Slavney, A. H., Hu, T., Lindenberg, A. M. & Karunadasa, H. I. A bismuthhalide double perovskite with long carrier recombination lifetime for photovoltaic applications. J. Am. Chem. Soc. 138, 2138–2141 (2016). 

25. McClure, E. T., Ball, M. R., Windl, W. & Woodward, P. M. Cs2AgBiX6 (X = Br, Cl): new visible light absorbing, lead-free halide perovskite semiconductors. Chem. Mater. 28, 1348–1354 (2016). 

26. Pan, W. C. et al. Cs2AgBiBr6 single-crystal X-ray detectors with a low detection limit. Nat. Photon. 11, 726–732 (2017). 

27. Bartesaghi, D. et al. Charge carrier dynamics in Cs2AgBiBr6 double perovskite. J. Phys. Chem. C. 122, 4809–4816 (2018). 

28. Milot, R. L., Eperon, G. E., Snaith, H. J., Johnston, M. B. & Herz, L. M. Temperature dependent charge‐carrier dynamics in CH3NH3PbI3 perovskite thin films. Adv. Funct. Mater. 25, 6218–6227 (2015). 

29. Ning, W. H. et al. Long electron-hole diffusion length in high-quality lead-free double perovskite films. Adv. Mater. 30, 1706246 (2018). 

30. Fan, P. et al. Single-source vapor-deposited Cs2AgBiBr6 thin films for lead-free perovskite solar cells. Nanomaterials 9, 1760 (2019). 

31. Kung, P. K. et al. Lead free double perovskites for perovskite solar cells. Sol. Rrl. 4, 1900306 (2019). 

### References 

1. National Renewable Energy Laboratory. Best Research-Cell Efficiency chart, https://www.nrel.gov/pv/assets/pdfs/best-research-cell-efficiencies-rev220126. pdf (2022). 

2. Jeon, N. J. et al. Compositional engineering of perovskite materials for highperformance solar cells. Nature 517, 476–480 (2015). 

3. Bi, D. et al. Efficient luminescent solar cells based on tailored mixed-cation perovskites. Sci. Adv. 2, e1501170 (2016). 

4. Yang, W. S. et al. Iodide management in formamidinium-lead-halide-based perovskite layers for efficient solar cells. Science 356, 1376–1379 (2017). 

5. Correa-Baena, J. P. et al. Promises and challenges of perovskite solar cells. Science 358, 739–744 (2017). 

6. Babayigit, A., Ethirajan, A., Muller, M. & Conings, B. Toxicity of organometal halide perovskite solar cells. Nat. Mater. 15, 247–251 (2016). 

7. Leijtens, T. et al. Stability of metal halide perovskite solar cells. Adv. Energy Mater. 5, 1500963 (2015). 

8. Berhe, T. A. et al. Organometal halide perovskite solar cells: degradation and stability. Energy Environ. Sci. 9, 323–356 (2016). 

9. Shi, Z. et al. Lead-Free organic-inorganic hybrid perovskites for photovoltaic applications: recent advances and perspectives. Adv. Mater. 29, 1605005 (2017). 

10. Hayase, S. Research following Pb perovskite solar cells. Electrochemistry 85, 222–225 (2017). 

11. Zhang, C., Gao, L., Hayase, S. & Ma, T. Current advancements in material research and techniques focusing on lead-free perovskite solar cells. Chem. Lett. 46, 1276–1284 (2017). 

12. Zuo, C. et al. Advances in perovskite solar cells. Adv. Sci. 3, 1500324 (2016). 

13. Ran, C. et al. Bilateral interface engineering toward efficient 2D–3D bulk heterojunction tin halide lead-free perovskite solar cells. ACS Energy Lett. 3, 713–721 (2018). 

14. Zhang, Y. Y. et al. Intrinsic instability of the hybrid halide perovskite semiconductor CH3NH3PbI3. Chin. Phys. Lett. 35, 036104 (2018). 

15. Chung, I. et al. CsSnI3: Semiconductor or metal? High electrical conductivity and strong near-infrared photoluminescence from a single material. High hole mobility and phase-transitions. J. Am. Chem. Soc. 134, 8579–8587 (2012). 

16. Chen, J. et al. Tin(IV)-tolerant vapor phase growth and photophysical properties of aligned cesium tin halide perovskite (CsSnX3, X=Br, I) nanowires. ACS Energy Lett. 4, 1045–1052 (2019). 

32. Mete, E. et al. Double perovskite structure induced by Co addition to PbTiO3: Insights from DFT and experimental solid-state NMR spectroscopy. J. Phys. Chem. C. 123, 27132–27139 (2019). 

33. Slavney, A. H. et al. Defect-induced band-edge reconstruction of a bismuthhalide double perovskite for visible-light absorption. J. Am. Chem. Soc. 139, 5015–5018 (2017). 

34. Li, Z. W. et al. Bandgap lowering in mixed alloys of Cs2Ag(SbxBi1−x)Br6 double perovskite thin films. J. Mater. Chem. A. 8, 21780–21788 (2020). 

35. Lindquist, K. P. et al. Tuning the bandgap of Cs2AgBiBr6 through dilute tin alloying. Chem. Sci. 10, 10620–10628 (2019). 

36. Li, Q. et al. High-pressure band-gap engineering in lead-free Cs2AgBiBr6 double perovskite. Angew. Chem. Int. Ed. 56, 15969–15973 (2017). 

37. Ji, F. X. et al. Lead-free halide double perovskite Cs2AgBiBr6 with decreased band gap. Angew. Chem. Int. Ed. 132, 15303–15306 (2020). 

38. Yang, J. X., Zhang, P. & Wei, S. H. Band structure engineering of Cs2AgBiBr6 perovskite through order-disordered transition: a first-principle study. J. Phys. Chem. Lett. 9, 31–35 (2018). 

39. Davis, E. A. & Mott, N. F. Conduction in non-crystalline systems V. Conductivity, optical absorption and photoconductivity in amorphous semiconductors. Philos. Mag. 22, 0903–0922 (1970). 

40. Viezbicke, B. D., Patel, S., Davis, B. E. & Birnie, D. P. III Evaluation of the tauc method for optical absorption edge determination: ZnO thin films as a model system. Phys. Status Solidi B. 252, 1700–1710 (2015). 

41. Ji, F. X. et al. Near‐infrared light‐responsive Cu‐doped Cs2AgBiBr6. Adv. Funct. Mater. 30, 2005521 (2020). 

42. Nayak, P. K. et al. Impact of Bi<sup>3+</sup> heterovalent doping in organic-inorganic metal halide perovskite crystals. J. Am. Chem. Soc. 140, 574–577 (2018). 

43. Liu, G. H. et al. Extending absorption of Cs2AgBiBr6 to near-infrared region (≈1350 nm) with intermediate band. Adv. Funct. Mater. 32, 2109891 (2021). 

44. Mehrer, H. Diffusion in Solids: fundamentals, methods, materials, diffusioncontrolled processes. 42 (Springer-Verlag Berlin Heidelberg, 2007). 

45. Olden, V., Alvaro, A. & Akselsen, O. M. Hydrogen diffusion and hydrogen influenced critical stress intensity in an API X70 pipeline steel welded jointexperiments and FE simulations. Int. J. Hydrog. Energy 37, 11474–11486 (2012). 

46. Martins, T. R. D. B., Azambuja, V. M., Santos, D. S. D. & Tavares, S. S. M. Influence of nanoxides on diffusivity and solubility of hydrogen in Pd-based alloys. Mater. Res. 20, 111–116 (2017). 

11 

NATURE COMMUNICATIONS | (2022) 13:3397 | https://doi.org/10.1038/s41467-022-31016-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-31016-w 

47. Lee, J., Park, C., Park, H. & Kang, N. Effective hydrogen diffusion coefficient for CoCrFeMnNi high-entropy alloy and microstructural behaviors after hydrogen permeation. Int. J. Hydrog. Energy 45, 10227–10232 (2020). 

48. Kürten, D., Khader, I. & Kailer, A. Determining the effective hydrogen diffusion coefficient in 100Cr6. Mater. Corros. 71, 918–923 (2020). 

49. Zheng, G., Popov, B. N. & White, R. E. Electrochemical determination of the diffusion coefficient of hydrogen through an LaNi4.25Al0.75 electrode in alkaline aqueous solution. J. Electrochem. Soc. 142, 2695 (1995). 

50. Sheikholeslam, S. A. et al. Hydrogen diffusion characterization of amorphous yttrium stabilized zirconia dielectrics. 2016 IEEE 16th Int. Conf. Nanotechnol. IEEE. 164–166 (2016). 

51. Yu, G. C. A comparison between proton and hydrogen chemical diffusion coefficients of titanium oxide films. Phys. Stat. Sol. (a). 198, 302–311 (2003). 

52. Weidinger, A. et al. Hydrogen diffusion in chalcopyrite solar cell materials. MRS. O. P. L. 513, 177–181 (1998). 

53. Nie, W. Y. et al. High-efficiency solution-processed perovskite solar cells with millimeter-scale grains. Science 347, 522–525 (2015). 

54. Jin, Q. Y. et al. RF and microwave ion sources study at institute of modern physics. Plasma 4, 332–344 (2021). 

55. Taccogna, F. & Dilecce, G. Non-equilibrium in low-temperature plasmas. Eur. Phys. J. D. 70, 1–37 (2016). 

56. Spencer, M. G. & Alam, T. High power direct energy conversion by nuclear batteries. Appl. Phys. Rev. 6, 031305 (2019). 

57. Luo, Y. R. Comprehensive handbook of chemical bond energies.1399 (CRC Press, 2007). 

58. Kresse, G. & Furthmüller, J. Efficient iterative schemes for Ab initio total energy calculations using a plane-wave basis set. Phys. Rev. B. 54, 11169–11186 (1996). 

59. Kresse, G. & Furthmüller, J. Efficiency of ab-initio total energy calculations for metals and semiconductors using a plane-wave basis set. Comput. Mater. Sci. 6, 15–50 (1996). 

60. Kresse, G. & Joubert, D. From ultrasoft pseudopotentials to the projector augmented-wave method. Phys. Rev. B. 59, 1758–1775 (1999). 

61. Perdew, J. P., Burke, K. & Ernzerhof, M. Generalized gradient approximation made simple. Phys. Rev. Lett. 77, 3865–3868 (1996). 

62. Heyd, J. & Scuseria, G. E. Hybrid functionals based on a screened coulomb potential. J. Chem. Phys. 118, 8207–8215 (2003). 

### Acknowledgements 

This work was supported by the Beijing Innovation Team Building Program, China (IDHT20190503), the National Natural Science Foundation of China (11704015, 51621003, 12074016), the General Program of Science and Technology Development Project of Beijing Municipal Education Commission (KM202110005003), Beijing Natural Science Foundation (Z210016) and the National Key Research and Development Program of China (2016YFB0700700). 

### Author contributions 

Y.L. and M.L.S. conceived and designed the experiments. Z.Y.Z. prepared the samples, performed the measurement of X-ray diffraction, scanning electron microscopy, ultraviolet-visible absorption, hall effect, time-resolved photoluminescence, ultraviolet photoelectron spectroscopy, X-ray photoelectron spectroscopy, transmission electron microscope, current density-voltage curve and calculation the diffusion coefficient. Q.D.S., S.H.W., and F.L. did the theoretical calculations. X.L.M. prepared the perovskite film. Z.Y.Z., Y.L., M.L.S., and S.H.W. analyzed the data and co-wrote the paper. All authors discussed the results and revised the paper. 

### Competing interests 

The authors declare no competing interests. 

### Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-022-31016-w. 

Correspondence and requests for materials should be addressed to Yue Lu, Su-Huai Wei or Manling Sui. 

Peer review information Nature Communications thanks Deniz Uner and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. Peer reviewer reports are available. 

Reprints and permission information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2022 

12 

NATURE COMMUNICATIONS | (2022) 13:3397 | https://doi.org/10.1038/s41467-022-31016-w | www.nature.com/naturecommunications 

