# Understanding Performance Limiting Interfacial Recombination in pin Perovskite Solar Cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Advanced Energy Materials |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 265 |
| 作者 | Jonathan H. Warby, Feng-Shuo Zu, Stefan Zeiske, Emilio Gutiérrez-Partida, Lennart Frohloff, Simon Kahmann, K. Frohna, E. Mosconi et al. |
| DOI | 10.1002/aenm.202103567 |
| 源文件 | 029_Warby_2022_Understanding-Performance-Limiting-Interfacial-R.pdf |

---
**ReseaRch aRticle** 



**www.advenergymat.de** 

# **Understanding Performance Limiting Interfacial Recombination in** **_pin_ Perovskite Solar Cells** 

_Jonathan Warby,* Fengshuo Zu, Stefan Zeiske, Emilio Gutierrez-Partida, Lennart Frohloff, Simon Kahmann, Kyle Frohna, Edoardo Mosconi, Eros Radicchi, Felix Lang, Sahil Shah, Francisco Peña-Camargo, Hannes Hempel, Thomas Unold, Norbert Koch, Ardalan Armin, Filippo De Angelis, Samuel D. Stranks, Dieter Neher, and Martin Stolterfoht*_ 

## **1. Introduction** 

**Perovskite semiconductors are an attractive option to overcome the limitations of established silicon based photovoltaic (PV) technologies due to their exceptional opto-electronic properties and their successful integration into multijunction cells. However, the performance of single- and multijunction cells is largely limited by significant nonradiative recombination at the perovskite/organic electron transport layer junctions. In this work, the cause of interfacial recombination at the perovskite/C60 interface is revealed via a combination of photoluminescence, photoelectron spectroscopy, and firstprinciple numerical simulations. It is found that the most significant contribution to the total C60-induced recombination loss occurs within the first monolayer of C60, rather than in the bulk of C60 or at the perovskite surface. The experiments show that the C60 molecules act as deep trap states when in direct contact with the perovskite. It is further demonstrated that by reducing the surface coverage of C60, the radiative efficiency of the bare perovskite layer can be retained. The findings of this work pave the way toward overcoming one of the most critical remaining performance losses in perovskite solar cells.** 

Since their discovery in 2009 perovskite solar cells have spurred enormous interest due to highly impressive power conversion efficiencies (in excess of 25%)<sup>[1]</sup> with the use of far less stringent manufacturing techniques and more impure materials than other technologies. In order to achieve such high performance, the community has adopted the key principle that to reach the full potential of perovskite solar cells, one must minimize nonradiative recombination in the device.<sup>[2,3]</sup> This will in turn decrease dark currents and increase open circuit voltage ( _V_ OC). In general, perovskite solar cells can be classified into two architecture types, _nip_ and _pin,_ where the difference is defined by the order of deposition of the electron 

J. Warby, E. Gutierrez-Partida, F. Lang, S. Shah, F. Peña-Camargo, D. Neher, M. Stolterfoht Institute of Physics and Astronomy University of Potsdam Karl-Liebknecht-Str. 24–25, D-14476 Potsdam-Golm, Germany 

E-mail: warby@uni-potsdam.de; stolterf@uni-potsdam.de 

F. Zu, L. Frohloff, N. Koch Humboldt-Universitat zu Berlin Institut für Physik & IRIS Adlershof Brook-Taylor Straße 6, D-12489 Berlin, Germany 

S. Zeiske, A. Armin Department of Physics Swansea University 

Singleton Campus, Swansea SA2 8PP, UK S. Kahmann, K. Frohna, S. D. Stranks Department of Physics Cavendish Laboratory University of Cambridge Cambridge CB3 0HE, UK 

The ORCID identification number(s) for the author(s) of this article can be found under https://doi.org/10.1002/aenm.202103567. 

E. Mosconi, E. Radicchi, F. De Angelis Computational Laboratory for Hybrid/Organic Photovoltaics (CLHYO) Istituto CNR di Scienze e Tecnologie Chimiche “Giulio Natta” (CNR-SCITEC) Via Elce di Sotto 8 Perugia 06123, Italy 

H. Hempel, T. Unold Department of Structure and Dynamics of Energy Materials Helmholtz-Zentrum-Berlin D-14109 Berlin, Germany 

F. De Angelis Department of Chemistry, Biology and Biotechnology University of Perugia Via Elce di Sotto 8, Perugia 06123, Italy 

F. De Angelis Department of Natural Sciences & Mathematics College of Sciences & Human Studies Prince Mohammad Bin Fahd University P.O. Box 1664, Al Khobar 31952, Kingdom of Saudi Arabia S. D. Stranks Department of Chemical Engineering & Biotechnology University of Cambridge Cambridge CB3 0AS, UK 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH. This is an open access article under the terms of the Creative Commons Attribution License, which permits use, distribution and reproduction in any medium, provided the original work is properly cited. 

### **DOI: 10.1002/aenm.202103567** 

**2103567 (1 of 10)** 

_Adv. Energy Mater._ **2022** , _12_ , 2103567 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

and hole selective contacts relative to the transparent conductive oxide (TCO) substrate. The highest performing cells are currently made in the _nip_ architecture;<sup>[1]</sup> however, _pin_ -type perovskite solar cells are also of significant interest due to their high operational stability<sup>[4]</sup> and their successful integration into multijunction tandem solar cells with other established and emerging photovoltaic technologies.<sup>[5,6]</sup> The success of _pin_ type cells in this regard can be largely attributed to the simple processability of the charge transport layers, which can be fabricated at low temperatures (≈100 °C) or by thermal evaporation without the need for chemical dopants which could negatively affect the device stability.<sup>[7]</sup> As such, _pin_ -type perovskite cells are currently the preferred platform for high efficiency tandems.<sup>[5]</sup> However, it is well known that even the highest performing _pin_ cells are limited by substantial nonradiative recombination induced by the electron transport layer.<sup>[8]</sup> The highest efficiency silicon/perovskite and perovskite/perovskite tandem solar cells to date all use fullerene electron transport layers, which are likely the limiting factor to their performance.<sup>[5,9,10]</sup> 

As we show in **Figure 1** a, a C60-induced nonradiative loss is limiting the performance of most of the metal halide perovskite 

systems we have studied, including hybrid organic/inorganic metal halides with mixed cation and halide compositions over a large range of bandgaps, inorganic perovskites, and even 2D/3D perovskites. Figure 1a summarizes reported photoluminescent quantum yield (PLQY) values (where the generation current, _J_ G = 1 sun) obtained on bare perovskite and perovskite/C60 films and complete cell stacks, for mono, double, and triple cation perovskites with different bandgaps, inorganic and 2D/3D layered perovskites. In all systems, the recombination loss induced by the C60 layer greatly outweighs the recombination in the neat layer by 1–3 orders of magnitude, and dominates the PLQY losses of the complete devices in all cases. Moreover, the PLQY of the perovskite/C60 stack layers ends up at low values (<1 × 10<sup>−3</sup> ), quite irrespective of the perovskite composition, although the PLQY of C60 stacks was found to decrease with higher Br or MAPbBr3 content.<sup>[11]</sup> Contrastingly, cells in the _nip_ configuration can have an external radiative efficiency of nearly 10%, where the injected current is equal to the short circuit current density ( _J_ injected = _J_ SC).<sup>[12]</sup> Particularly important for tandem cells applications is the low PLQY in presence of C60 in case of the triple cation perovskites with a bandgap between 



**Figure 1.** a) C60-induced recombination losses in various perovskite systems. (Data taken from refs. [8,11,13–18].) C60 appears to lower the PL yield (PLQY) to ≈1 × 10<sup>−4</sup> –1 × 10<sup>−3</sup> of the neat layer, relatively independent of the composition. We note that these different perovskites are denoted as methyl ammonium lead iodide (MAPbI3), double cation is denoted as FA0.8MA0.2PbI3, triple cation perovskite (Cs0.05FA _x_ MA _y_ Pb(I _x_ Br _y_ )3) is abbreviated as “TC,” where the _x_ : _y_ ratio reflects the molar ratio of FAPbI3 versus MAPbBr3, 2D/3D perovskites are denoted by the spacer cation butylammonium (BA) and the number of layers of octahedra between spacer cations, e.g., _n_ = 4 is BA4. b) PLQY of an 83:17 TC perovskite on different transport layers, showing that fullerenes limit the performance of _pin_ cells and spiro-OMeTAD limits _nip_ cells; overall the _pin_ cells are more limited by interface recombination. Dashed line indicates the PLQY of the neat perovskite on glass. c) Possible recombination pathways at the C60 interface (C60-induced surface trap states, across-interface recombination, and recombination within the C60 layer directly at the interface or in the bulk). 

**2103567 (2 of 10)** 

_Adv. Energy Mater._ **2022** , _12_ , 2103567 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

1.63 eV to 1.88 eV. Figure 1b further highlights that with the use of self-assembled monolayers and also poly[bis(4-phenyl) (2,4,6-trimethylphenyl)amine (PTAA): poly(9,9-bis(3’-( _N_ , _N_ - dimethyl)- _N_ -ethylammoinium-propyl-2,7-fluorene)-alt-2,7-(9,9dioctylfluorene))dibromide (PFN) one can achieve no additional losses compared to the nonradiative bulk recombination in case of a triple cation perovskite, and that the use of metal oxides in _nip_ type cells with a triple cation perovskite layer also cause less losses compared to C60. However, despite the huge importance of the C60-induced recombination losses in determining the radiative efficiency of _pin_ -type solar cells, the origins of nonradiative recombination at this interface and the interfacial recombination pathways have not been widely explored yet and remain elusive today. In principle, as shown in Figure 1c, there could be four pathways for nonradiative recombination when the C60 is in contact with the perovskite: 

- I) Interface recombination within the perovskite layer, where both the electrons and holes recombine in the perovskite via new surface traps which are created due to changes in surface stoichiometry or reactions with the C60 ( _mechanism 1)_ ; 

- II) Across-interface recombination, where the electron is extracted to the C60 and it recombines with a hole in the perovskite via trap states ( _mechanism 2_ ); 

- III) Interface recombination within the C60, where the electron and hole are extracted to the C60 and recombine at the interface via trap states in the C60 ( _mechanism 3)_ ; 

- IV) Recombination within the bulk of C60, where electrons and holes are extracted to the C60 and recombine via trap states in the C60 ( _mechanism 4_ ). This is distinct from _mechanism 3_ as the holes can travel throughout the C60 also introducing the possibility of recombination at the electrode. 

Each of these mechanisms will have different implications for optimization pathways to circumvent the loss. Thus, to further advance single- and multijunction cells, we need to understand if, or to what extent each mechanism contributes. 

In this work, we disentangle the involvement of each of these mechanisms to the increased nonradiative recombination in perovskite/C60 systems. We first performed ultrasensitive photovoltaic external quantum efficiency (EQE) measurements of conventional and lateral devices which revealed a large increase in trap state density when interfaced with C60. We then measured the PLQY in perovskite/C60 films as a function of the C60 thickness or C60 coverage (from sub-nm to 30 nm). These experiments revealed a remarkable direct correlation between the loss of PLQY and the C60 thickness in a regime where the C60 only partially covers the perovskite surface, ruling out bulk C60 recombination ( _mechanism 4_ ). By examining the highest molecular orbital (HOMO) features of the sequentially deposited C60 layers using ultraviolet photoelectron spectroscopy (UPS), we demonstrate that the PLQY drops to its lowest value, once the perovskite surface is completely covered with the C60. Following this, we are able to develop a quantitative model based on PLQY being inversely proportional to C60 surface coverage which fits our experimental data very well. We then performed confocal microscopy and hyperspectral PL imaging, which confirmed that the decrease in PL intensity was homogenous in the _XY_ plane. After this, in order to understand the 

**www.advenergymat.de** 

possibility of C60-induced mid-gap states on the perovskite surface, we modeled the perovskite-C60 interaction for different terminated surfaces, showing no formation of mid-gap states in the perovskite, considering two different surface terminations. This, in combination with the EQE and additional PL measurements on perovskite/C60 stacks allowed us rule out increased nonradiative recombination in the perovskite ( _mechanism 1_ ). We then compared the PL emission of C60 films, with perovskite/C60 stacks. These measurements revealed the presence of excitonic states in the C60 which could be well aligned with the valence band of the perovskites, facilitating hole transfer ( _mechanism 3_ ). However, we did not observe any C60 photoluminescence or electroluminescence in the photovoltaic devices which ruled out this theory. This indicates that the remaining acrossinterface recombination ( _mechanism 2_ ) is the operational loss mechanism. With further UPS measurements and modeling of the perovskite/C60 interaction, we propose either C60 density of states (DOS) broadening creating low lying states or a charge transfer state is the source of additional traps at this interface. Finally, strategies are proposed to reduce the nonradiative loss at this interface. 

## **2. Evidence of Traps** 

We begin by looking for subgap features in devices with C60, and performed ultrasensitive EQE measurements on a perovskite solar cell in a _pin_ device architecture [(indium tin oxide, ITO (150nm)/PTAA:PFN (8nm)/perovskite (400– 500nm)/C60 (30nm)/bathocuproine, BCP (8nm)/ Cu (100nm)]. We employ a triple cation (TC) absorber which is widely used in literature, (Cs0.05(FA0.83MA0.17)0.95Pb(I0.83Br0.17)3, with a bandgap of 1.63 eV and a PCE of 20%). The average performance parameters of the cells are displayed in Figure S1 and Table 1 (Supporting Information). **Figure 2** a shows the EQE of the solar cells (diode structure), which reveals the presence of sub gap states density (at very low EQEs of 10<sup>−7</sup> –10<sup>−6</sup> ). As discussed in Note S1 (Supporting Information), this cannot be explained by bulk recombination based on a transfer matrix model.<sup>[19]</sup> Importantly, upon inserting a LiF layer in between the perovskite and the C60, the sub gap feature is reduced, while the _V_ OC of the cell increases by 40 meV.<sup>[8]</sup> Interestingly, the increased trap state density is also visible from the increased trap-assisted EQE signal in ultrasensitive EQE measurements in a photoresistor structure (Figure 2b). We note that the EQE in the sub gap range appears at higher EQE values than in Figure 2a, which is due to the increased recombination in the wide photoresistor channel and consequently lower EQE signal above the gap. These measurements confirm a large increase of trap state density when the perovskite is in direct contact with the C60 layer. 

## **3. Location of Nonradiative Recombination** 

With strong evidence of traps when C60 is in contact with the perovskite, we attempt to better determine the precise spatial location of the recombination. We evaporate C60 with varying thickness onto the TC perovskite and measure the PLQY 

**2103567 (3 of 10)** 

_Adv. Energy Mater._ **2022** , _12_ , 2103567 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 2.** a) Sensitive external quantum efficiency (EQE) measurements of triple cation perovskite solar cells plotted as a function of photon energy and compared for the case with (blue) and without (red) a LiF layer, highlighting the presence of deep traps at low EQEs (10<sup>−7</sup> ). The relative trap density appears to be reduced if the LiF layer is inserted between perovskite and C60, which improves the device performance from ≈20% to 21% through a better _V_ OC (40 mV) and better FF (≈2%).<sup>[8]</sup> The inset shows a simplified solar cell device stack. b) Sensitive EQE of triple cation perovskite devices fabricated in photoresistor architecture plotted as a function of photon energy, and compared for the case with (blue) and without (red) a C60 layer. The inset shows a simplified device stack, where the triple cation layer is sandwiched between glass and top electrodes (gold). 

(inset **Figure 3** a). Intriguingly we observe that the majority of the PLQY loss with respect to the neat occurs in samples with _only 1 nm_ of C60 and we see no further loss beyond samples with 4 nm. We repeat this experiment on a double cation (DC) perovskite (FA0.8MA0.2PbI3 with a bandgap of 1.54 eV and cells with a PCE of around 21%, performance parameters, Figure S1, Supporting Information) which we recently reported to have a PLQY in neat films of up to 0.2 and a Shockley-Read-Hall 

(SRH) lifetime over 10 µs.<sup>[14]</sup> This will afford us a larger dynamic range to investigate PLQY losses (Figure 3a). In this case, we find the same result where almost all loss occurred in the first nm, and, the loss is very large (5 × 10<sup>−3</sup> after 1 nm). Therefore, to better resolve the range where the PLQY drops rapidly, we investigate the sub-nm regime of C60 thickness on the DC and TC perovskites, with high resolution using multiple samples and measurements for each thickness (Figure 3b). 



**Figure 3.** a,b) PLQY versus C60 thickness for a double cation perovskite (FA0.8MA0.2PbI3), and triple cation perovskite (inset), showing that the PL emission is quenched within the first few nm of C60 indicating the importance of recombination directly across the interface. c) FCC crystal structure of C60 with lattice parameter of 14 Å. d) Ultraviolet photoelectron spectra of partially covered perovskite surfaces with C60. 

**2103567 (4 of 10)** 

_Adv. Energy Mater._ **2022** , _12_ , 2103567 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

We observe that there is an initial plateau of the PLQY with very low thicknesses of C60 (<0.01 nm), followed by a decrease inversely proportional to the C60 thickness until ≈3 nm and then remaining constant until an operational C60 thickness of ≈30 nm. If we consider the unit cell of crystalline C60, it adopts a face centered cubic (FCC) structure with a lattice parameter a = 1.41 nm (Figure 3c). Assuming a perfectly smooth surface, we should expect full surface coverage at ≈1 nm (the interplanar spacing of the hexagonally close packed planes is 1 nm). Hence, a nominal sub-nm C60 thickness (as determined by the rate and duration of thermal evaporation), should be considered as a partial coverage of the perovskite layer. This saturation of the quenching with increased thickness beyond 3 nm is very interesting and indicative of a surface mediated process. However, all of the recombination did not happen in precisely the first nm as would have been predicted above. 

As we deposit C60 via thermal evaporation and the perovskite surface is multicrystalline, it is likely that film growth occurs through the formation terraces and islands of C60 on the perovskite surface rather than epitaxiallly.<sup>[20]</sup> In addition to this the perovskite film has a root mean square roughness of 21.5 nm.<sup>[17]</sup> As such, we hypothesize that full surface coverage of C60 on the perovskite will not be complete at 1 nm and that the PLQY is related to the surface coverage, saturating when it is complete. In order to investigate this, sequentially deposited C60 layers on the DC perovskite were studied by UPS. Given the very surface sensitive nature of UPS, the photoemission spectra are expected to consist of perovskite valence bands and C60 highest occupied molecular orbital (HOMO) features until the surface is fully covered by C60 molecules. It is clearly shown in Figure 3d that the C60 HOMO features start to dominate and saturate at the thickness of 2.3 nm, indicating a complete coverage of C60 molecules on the perovskite surface already at 2.3 nm. The same experiment was also performed on the TC perovskite, which showed the same result with the C60 feature dominating from 2.3 nm onward (Figure S2, Supporting Information). 

We now seek to accurately describe our PLQY versus C60 thickness data by developing a numerical model based on known recombination kinetics in metal halide perovskites. To this end, we consider that the PLQY is the ratio of the radiative recombination rate ( _k_ 2 _n_<sup>2</sup> ) to the total recombination rate ( _k_ 1 _n_ + _k_ 2 _n_<sup>2</sup> ), which is the sum of all nonradiative recombination rates ( _k_ 1 _n_ ) and the radiative rate, neglecting Auger recombination which occurs at ≈1000 suns in perovskites<sup>[21,22]</sup> 



<!-- Start of picture text -->
k n 2 2<br>PLQY = k n 1 + k n 2 2 (1)<br><!-- End of picture text -->

The first-order nonradiative recombination rate constant depends in turn on the number of trap states _N_ traps 



<!-- Start of picture text -->
k 1 = N traps v th σ (2)<br><!-- End of picture text -->

where _v_ th _σ_ is the product of the capture cross-section and the thermal velocity; we do not attempt to measure _v_ th _σ_ , but simply note that the nonradiative recombination rate is proportional to the trap density ( _N_ traps cm<sup>−3</sup> ). We will call these intrinsic traps ( _N_ traps(intrinsic)), which (together with _v_ th _σ_ ) determine the 

**www.advenergymat.de** 

PLQY of our control films (1 × 10<sup>−2</sup> and 2 × 10<sup>−1</sup> for TC and DC, respectively). In our model, as we deposit C60 on the surface, we are increasing the total number of traps (Ntraps(total)) by introducing extrinsic traps _N_ traps(external). When the number of C60 molecules is low, then _k_ 1(intrinsic) >> _k_ 1(extrinsic) and there is little effect on the PLQY; this is characterized by the plateau region of the PLQY in Figure 3b. There is then a transition until _k_ 1(extrinsic) >> _k_ 1(intrinsic) upon which there is an inversely proportional relationship between C60 surface coverage and the PLQY. Finally, the PLQY will saturate when full surface coverage is achieved as no more surface traps can be created. Using this simple model and a thickness for complete surface coverage of 2.3 nm (from UPS) we can closely fit the experimentally obtained PLQY data (red lines Figure 3b). Therefore, with the combination of the PLQY, UPS and a close fit of the model we conclude that all of nonradiative recombination happens exactly at the surface allowing us to exclude _mechanism 4_ (predominant recombination in the bulk of C60). The fact that the PLQY decays inversely with the number of C60 molecules (PLQY _α N_ C60<sup>−1</sup> ), indicates that _N_ traps ∝ _N_ C60. Additionally, this type of recombination analysis is only valid for deep traps indicating that C60 is making deep rather than shallow traps at the surface. The correlation of surface coverage and PLQY opens up possibilities to improve device performance by reducing contact area of the C60 with the perovskite through the use of a patterned interlayer; this “point contacts” strategy is well known for silicon<sup>[23]</sup> and has been demonstrated on the substrate side for _nip_ perovskite solar cells.<sup>[24]</sup> 

## **4. Origin of Interfacial Traps** 

A possible origin of traps can be found in Figure S3 (Supporting Information) where we observe the lowest-unoccupied molecular orbital (LUMO) is positioned ≈100 meV below the conduction band minimum (CBM) of the perovskite at the interface and upon increasing the thickness of C60, the LUMO bends upward (by ≈0.3 eV). This low lying LUMO of the C60 at the interface could potentially introduce trap states which cause the increased nonradiative recombination. Such an effect has been previously observed in organic semiconductors in contact with inorganic materials,<sup>[25]</sup> and attributed to broadening of the organic DOS at the interface because of spatial variation (inhomogeneity) in the electrostatic potential of the inorganic material.<sup>[26]</sup> Note, a broad DOS _throughout_ the C60 could also be related to packing faults or impurities causing energetic disorder. To test the packing fault hypothesis we try solvent and thermal annealing the C60 electron transport layer (ETL) in case of a TC absorber layer to increase crystallinity and order as reported for PCBM by Shao et al.<sup>[27]</sup> (Figure S4, Supporting Information) which showed, however, no improvement. We then fabricate TC/C60 stacks with different purities of C60 which showed that the PLQY was the same for all samples, ruling out recombination via impurity defects (Figure S5, Supporting Information). Therefore, the observed pinning of the C60 LUMO below the conduction band is more likely due to the C60 DOS broadening through inhomogenous electrostatics of the perovskite surface. 

As we have pinned down the location of the recombination to the interface, we now inspect samples of our DC and TC 

**2103567 (5 of 10)** 

_Adv. Energy Mater._ **2022** , _12_ , 2103567 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 4.** a–f) Confocal PL intensity maps of double cation (DC) and triple cation (TC) perovskite with different thicknesses of C60 on top revealing no change in the heterogeneity of PL intensity across the film with respect to coverage converse to possible clustering of C60 molecules, or darkening of individual grains. 

perovskite with subsurface coverage of C60 with confocal microscopy ( **Figure 4** ) and hyperspectral imaging (Figure S6, Supporting Information) to see if there was any heterogeneity in PL intensity in the _xy_ -plane for subsurface coverage samples. Through this technique, we can potentially resolve the length scale of the clustering/islands of C60 by the evolution of darker or brighter regions in the PL maps (confocal PL can have a high spatial resolution ≈100 nm). However, these measurements revealed that the multicrystalline surface of the DC and TC films displays the same degree of heterogeneity of the PL signal (within our resolution limit) irrespective of surface coverage. While these results do not demonstrate any heterogeneity (or clustering of C60), they reveal individual grains (especially for the DC perovskite) and would warrant further research in the future if point contact methods are found to improve the PLQY at this interface. 

Now that we have identified the location of the recombination to the interface, we seek to determine whether the traps originate from the perovskite or the C60. First, we discuss the possibility that C60 induces deep traps on the perovskite surface (i.e., _mechanism 1_ ). In general, the closed shell nature of C60 should make it relatively unreactive to redox reactions on the surface and it is an apolar molecule so there should be no electrostatic repulsion of ions causing a change of surface stoichiometry. Nevertheless, we investigate whether the reduction in PLQY was surface independent. To do this we fabricate samples of TC perovskite where the perovskite is either deposited on top of a glass/C60 substrate, or, C60 is deposited on a glass/perovskite substrate (Figure S7, Supporting Information). We measure the PLQY of these samples with incidence of the 

excitation light from both sides in order to account for the generation of carriers either next to or away from the C60. We find that the PLQY is almost identical between these two samples when the illumination pathway is matched, e.g., through the perovskite. We note that the bottom and top surfaces of the perovskite film are different in chemical nature; for example, the surface of 83:17 TC perovskite can be effectively passivated with tri-octyl phosphine oxide which results in a PLQY in excess of 0.2, indicating that the trap concentration of the bottom interface is much lower.<sup>[13,28]</sup> This, therefore, supports the hypothesis that the C60-induced loss does not significantly depend on the surface chemistry. 

To further investigate possible trap states induced by the C60-perovskite interactions, we perform first principle calculations. The interaction of C60 with the MAPbI3 perovskite surface has been previously modeled by Quarti et al.<sup>[29]</sup> Here we consider two surface terminations representing a more stable/ less reactive MAI-terminated surface (Figure S8b, Supporting Information) and a less stable/more reactive PbI2-terminated perovskite surface (Figure S8a, Supporting Information). These interfaces were geometry optimized by Perdew-Burke-Ernzerhof (PBE),<sup>[30]</sup> including D3 dispersion corrections.<sup>[31]</sup> The alignment of energy levels was determined by accurate hybrid HeydScuseria-Ernzerhof (HSE) calculations<sup>[32]</sup> including spin-orbit coupling (hereafter HSE-SOC). All calculations were carried out by the Quantum Espresso program package.<sup>[33]</sup> The HSE-SOC calculated electronic DOS is reported in Figure S8 (Supporting Information) for both surface terminations. Firstly, both simulations do not show the formation of mid-gap states in the 

**2103567 (6 of 10)** 

_Adv. Energy Mater._ **2022** , _12_ , 2103567 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 

perovskite further ruling out _mechanism 1_ . For both systems, a C60/perovskite shortest C-Pb distance of ≈3Å is calculated, with an interaction energy of ≈0.5 eV dominated by the dispersion term. Moreover, the simulations of the noninteracting and interacting DOS show appreciable interfacial electronic coupling (200 meV) and in the case of the PbI2 terminated surface, a stabilization of the C60 LUMO by 200 meV. Therefore, a lower energy charge transfer state could exist at this interface and a DOS broadening of the C60 LUMO from electrostatic variations of the perovskite surface potential is also possible; both could be a source of traps at the perovskite/C60 interface. 

## **5. Discerning between Across-Interface Recombination and Hole Transfer** 

Now that we have ruled out recombination in the perovskite ( _mechanism 1_ ) and recombination in the bulk of the C60 ( _mechanism 4_ ), we investigate the relative contribution of the hole recombining from perovskite across the interface _(mechanism 2),_ or from within the C60 layer _(mechanism 3)_ ( **Figure 5** a). We begin by measuring the UV–vis of a 30 nm thin film C60 (as we use in our devices) to better understand the energetic distribution of states in the C60 layer (Figure S9, Supporting Information). We observe vibronic peaks whose origin and energy are summarized in the inset of the figure. Of particular interest 

is a small shoulder at ≈1.9 eV (526 nm) which is the spin forbidden HOMO to LUMO (hu → t1u). As shown from the UPS results in Figure S3 (Supporting Information), the C60 LUMO has a favorable energetic alignment with the CBM of the 1.54–1.63 eV perovskites, and a large energy offset of ≈200–300 meV is present for holes. Therefore, hole transfer to the C60 HOMO levels is highly unlikely (given _k_ B _T_ is ≈25 meV) to occur. Next, we measure the PL of the same C60 film to understand the nature of its radiative transitions (Figure 5b). We observe a broad emission which is the convolution of 3 peaks centered at 1.63, 1.52 (Δ _E_ = 90 meV) and 1.41 eV (Δ _E_ = 180 meV) in accordance with literature.<sup>[34]</sup> The 1.63 eV peak is attributed to the (t1u → hu) transition which luminesces weakly due to relaxation of the spin forbidden selection rule when a localized exciton state forms. The binding energy of this exciton of ≈270 meV lowers the energy of the luminescent transition considerably. The two lower states are vibronic replicas of the 1.63 eV peak associated with the primary “breathing mode” in the Raman spectrum at 1469 cm<sup>−1</sup> (182 meV—same energy as the peak spacing).<sup>[35]</sup> What is most intriguing about the PL spectrum is that the lower energy transitions open the possibility of hole transfer to such states (if the electron and hole are equally stabilized by the exciton) which we illustrate in Figure S10 (Supporting Information). 

Following this understanding, we look for a signature of C60 PL in our perovskite/ C60 stacks. At open circuit conditions, we calculate that the recombination current at the TC 



**Figure 5.** a) Possible mechanisms which contribute to nonradiative losses in C60. b) Photoluminescence characterization of a C60 film, which is fitted to show the three peaks contributing to the shape, black line is the cumulative fit of all 3 peaks. c) Comparison of the PL of an 83:17 TC cell at one sun with the PL of C60 adjusted such that the recombination current in the C60 is ≈ 20 mA cm<sup>−2</sup> . d) Final proposed mechanism and causes of C60 induced nonradiative losses showing increased nonradiative recombination either via a charge transfer state or low lying C60 states at the interface due to D.O.S broadening. 

**2103567 (7 of 10)** 

_Adv. Energy Mater._ **2022** , _12_ , 2103567 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

perovskite/C60 interface is ≈20 mA cm<sup>−2</sup> .<sup>[17]</sup> We then measured the C60 PL where the generated carrier flux was equivalent to 20 mA cm<sup>−2</sup> in the perovskite (full details in Note S2, Supporting Information) and compared this with the PL of a _pin_ - type TC solar cell (at 1 sun) (Figure 5c). However, we do not observe a significant contribution of any of the C60 peaks in the PL of the TC solar cell. Notably, if all the recombination is happening through this pathway, we could expect the 1.41 eV peak to be visible. Further, we measure the electroluminescence (EL) of the same device at varying current densities from 83 µA cm<sup>−2</sup> to 18.3 mA cm<sup>−2</sup> and do not observe any evidence of C60 electroluminescence (Figure S10, Supporting Information) which with the lack of C60 PL allows us to rule out _mechanism 3_ . 

## **6. Further Discussion** 

For _mechanism 2_ to operate there needs to be a source of trap states to partake in nonradiative recombination. To this end, we have shown significant evidence of trap states in perovskite/ C60 half stacks and complete devices through sensitive EQE measurements (Figure 2a,b). These states could be due to DOS broadening causing low lying LUMO states at the surface which we measured with UPS (Figure S3, Supporting Information) or a charge transfer state at the interface (Figure S8, Supporting Information). These two possible sources of traps are summarized schematically in Figure 5d. Viable optimization pathways to reduce the loss while keeping C60 as the ETL should be; i) significantly reduce the concentration of holes at the perovskite C60 interface, ii) the insertion of a hole blocking layer to prevent hole transfer or physically decouple the electronic perovskite/ C60 interaction, and, iii) reduce the contact area between perovskite and C60 using a “point contacts” strategy, possibly through a lithographic process to pattern the surface. With regard to the point contacts strategy a gentle lithographic process which patterns the surface with an insulator and does not damage the perovskite will need to be developed. The insulator should be patterned to reduce surface contact of the C60 to less than 10% for significant improvement (ideal case is ≈ 3%) with distances between contact points being less than the diffusion length of the perovskite (calculated to be ≈5 µm in case of the TC and 40 µm in case of DC, using a perovskite mobility of 1 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> as reported<sup>[36]</sup> ). We have included detailed schematics and further description of how ideal point contacts would look in Figure S12 (Supporting Information). As a proof of concept, we attempted to spontaneously form point contacts through a discontinuous film of poly(methyl methacrylate) (PMMA) (Figure S13, Supporting Information) by simply modifying the concentration. The results showed a ≈30 mV improvement in _V_ OC but was quickly limited by the insulating nature of PMMA causing the _V_ OC to drop again (further discussion in Figure S14, Supporting Information).<sup>[37]</sup> This validates the strategy but shows the need for a lithographic or wet chemical step to better pattern the insulator for it to reach its true potential (for the TC this would be roughly a 100 mV improvement over the control). Patterning on this length scale is typically achieved using photolithographic techniques, which one could envision causing some damage to the perovskite through deep-UV light exposure and subsequent etching steps. However, there exists a 

**www.advenergymat.de** 

great number of so called “soft” lithographic techniques which could be suitable methods to make a patterned film of insulator on this length scale. For example, one could use polymer blend lithography,<sup>[38]</sup> self-assembly of block copolymers,<sup>[39]</sup> nanosphere lithography<sup>[40]</sup> or nanoimprint lithography.<sup>[41]</sup> These methods would allow processing and etching with orthogonal solvents like chlorobenzene and isopropanol which do not significantly damage the perovskite layer with short exposure. As can be seen there are many different possibilities and avenues of exploration to develop such a process. It is not without challenges and efforts are ongoing in our lab to achieve this, it is however beyond the scope of this work. 

Overall, it is clear that C60 is not without its problems when being used as an ETL in _pin_ perovskite solar cells —which begs the question; “Why are C60 and other fullerenes (e. g. PCBM) so frequently used?” To that end we believe that it is because fullerenes have; i) a high electron affinity and mobility, ii) an appropriate alignment of their LUMO to many popular perovskites and, iii) a spherical shape which facilitates good vertical electron transport regardless of the processing conditions. This is opposed to most other small molecule organic ETLs which are planar thus requiring more care during fabrication to ensure proper alignment of _π_ -orbitals with respect to the direction of charge transport. These benefits have outweighed the nonradiative recombination loss until now, but the rapid progress of the field has left fullerene transport layers as a significant roadblock to further performance improvements. Strategies which very strongly reduce the minority carrier concentration at the perovskite/SpiroOMeTAD interface have been shown to work very well in _nip_ cells (e.g. 2D perovskite interlayers<sup>[42]</sup> ) and LiF is known to improve _pin_ cells by this mechanism via a surface dipole repelling the holes.<sup>[10]</sup> However, in the case of higher bandgap perovskites (>1.7eV), hole transfer to the C60 may also occur, requiring ETLs with a deeper HOMO. 

## **7. Conclusions** 

In summary, we have qualitatively explained the interfacial recombination at the perovskite/C60 heterojunction. Sensitive EQE measurements revealed a large number of subgap states induced by C60 in perovskite devices. The PLQY of perovskite/ C60 stacks illuminated through the glass/perovskite and C60 side and ab initio simulations were inconsistent with C60 inducing trap states on the perovskite thus implicating nonradiative recombination happens via states in C60. Coverage dependent PLQY and UPS measurements revealed that the most critical loss process in most high performing _pin_ -type cells is a surface mediated process, which happens at the first monolayer of C60. We are able to model our thickness dependent PLQY data well by making the additional trap density directly proportional to the number of C60 molecules at the perovskite surface, which saturates when surface coverage is complete. Having pinned down the location of the recombination process, we examined whether holes from the perovskite go directly to trap states at the interface or to the HOMO of C60. However, we didn’t find any evidence of hole transfer to either the HOMO or an excitonic state of C60 through PL and EL measurements of a TC 

**2103567 (8 of 10)** 

_Adv. Energy Mater._ **2022** , _12_ , 2103567 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

perovskite device allowing us to rule out this mechanism. We conclude that recombination across the interface via C60 trap states is the operational mechanism and that the traps originate either from charge transfer states or DOS broadening at the interface pinning the LUMO below the conduction band of the perovskite. The investigation laid out here and proof of concept devices demonstrates that reducing the hole concentration at the perovskite C60 interface and “point contact” strategies will allow one to improve the device _V_ OC, paving the way for further strategies to eliminate this loss pathway. 

## **Supporting Information** 

Supporting Information is available from the Wiley Online Library or from the author. 

## **Acknowledgements** 

The authors acknowledge funding from the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation) within the SPP 2196 (SURPRISE 423749265 and HIPSTER 424709669) as well as through the SFB 951 (HIOS, project number 182087777). The authors further acknowledge financial support by the Federal Ministry for Economic Affairs and Energy within the framework of the 7th Energy Research Programme (P3T-HOPE, 03EE1017C) and HyPerCells (a joint graduate school of the Potsdam University and the HZB). F.L. acknowledges financial support from the Alexander von Humboldt Foundation via the Feodor Lynen program. S.K. is grateful for a postdoctoral fellowship (91793256) from the German Academic Foreign Service (DAAD). A.A. acknowledges support from the Welsh Government’s Sêr Cymru II Rising Star and Capacity Builder Accelerator Programs through the European Regional Development Fund, Welsh European Funding Office, and Swansea University Strategic Initiative in Sustainable Advanced Materials. S.D.S. acknowledges the Royal Society and Tata Group (UF150033). The work has received funding from the European Research Council under the European Union’s Horizon 2020 research and innovation programme (HYPERION - grant agreement no. 756962). The authors acknowledge the Engineering and Physical Sciences Research Council (EPSRC, EP/R023980/1) for funding. K.F. acknowledges a George and Lilian Schiff Studentship, Winton Studentship, an EPSRC studentship, Cambridge Trust Scholarship, and Robert Gardiner Scholarship. 

Open access funding enabled and organized by Projekt DEAL. 

## **Conflict of Interest** 

S.D.S is a co-founder of Swift Solar. 

## **Data Availability Statement** 

The data that support the findings of this study are available from the corresponding author upon reasonable request. 

## **Keywords** 

C60, defects, interface recombination, loss mechanisms, perovskites, solar cells 

Received: November 13, 2021 Revised: January 11, 2022 Published online: February 9, 2022 

**www.advenergymat.de** 

- [1] J. J. Yoo, G. Seo, M. R. Chua, T. G. Park, Y. Lu, F. Rotermund, Y.-K. Kim, C. S. Moon, N. J. Jeon, J.-P. Correa-Baena, V. Bulović, S. S. Shin, M. G. Bawendi, J. Seo, _Nature_ **2021** , _590_ , 587. 

- [2] U. Rau, _Phys. Rev. B: Condens. Matter Mater. Phys._ **2007** , _76_ , 085303. 

- [3] P. Wurfel, _J. Phys. C: Solid State Phys._ **1982** , _15_ , 3967. 

- [4] Y.-H. Lin, N. Sakai, P. Da, J. Wu, H. C. Sansom, A. J. Ramadan, S. Mahesh, J. Liu, R. D. J. Oliver, J. Lim, L. Aspitarte, K. Sharma, P. K. Madhu, A. B. Morales-Vilches, P. K. Nayak, S. Bai, F. Gao, C. R. M. Grovenor, M. B. Johnston, J. G. Labram, J. R. Durrant, J. M. Ball, B. Wenger, B. Stannowski, H. J. Snaith, _Science_ **2020** , _369_ , 96. 

- [5] A. Al-Ashouri, E. Köhnen, B. Li, A. Magomedov, H. Hempel, P. Caprioglio, J. A. Márquez, A. B. M. Vilches, E. Kasparavicius, J. A. Smith, N. Phung, D. Menzel, M. Grischek, L. Kegelmann, D. Skroblin, C. Gollwitzer, T. Malinauskas, M. Jošt, G. Matič, B. Rech, R. Schlatmann, M. Topič, L. Korte, A. Abate, B. Stannowski, D. Neher, M. Stolterfoht, T. Unold, V. Getautis, S. Albrecht, _Science_ **2020** , _370_ , 1300. 

- [6] A. Al-Ashouri, A. Magomedov, M. Roß, M. Jošt, M. Talaikis, G. Chistiakova, T. Bertram, J. A. Márquez, E. Köhnen, E. Kasparavičius, S. Levcenco, L. Gil-Escrig, C. J. Hages, R. Schlatmann, B. Rech, T. Malinauskas, T. Unold, C. A. Kaufmann, L. Korte, G. Niaura, V. Getautis, S. Albrecht, _Energy Environ. Sci._ **2019** , _12_ , 3356. 

- [7] C. Momblona, L. Gil-Escrig, E. Bandiello, E. M. Hutter, M. Sessolo, K. Lederer, J. Blochwitz-Nimoth, H. J. Bolink, _Energy Environ. Sci._ **2016** , _9_ , 3456. 

- [8] M. Stolterfoht, C. M. Wolff, J. A. Márquez, S. Zhang, C. J. Hages, D. Rothhardt, S. Albrecht, P. L. Burn, P. Meredith, T. Unold, D. Neher, _Nat. Energy_ **2018** , _3_ , 847. 

- [9] F. Li, X. Deng, F. Qi, Z. Li, D. Liu, D. Shen, M. Qin, S. Wu, F. Lin, S.-H. Jang, J. Zhang, X. Lu, D. Lei, C.-S. Lee, Z. Zhu, A. K.-Y. Jen, _J. Am. Chem. Soc._ **2020** , _142_ , 20134. 

- [10] F. Lang, E. Köhnen, J. Warby, K.e Xu, M. Grischek, P. Wagner, D. Neher, L. Korte, S. Albrecht, M. Stolterfoht, _ACS Energy Lett._ **2021** , _12_ , 3982. 

- [11] F. Peña-Camargo, P. Caprioglio, F. Zu, E. Gutierrez-Partida, C. M. Wolff, K. Brinkmann, S. Albrecht, T. Riedl, N. Koch, D. Neher, M. Stolterfoht, _ACS Energy Lett._ **2020** , _5_ , 2728. 

- [12] Q. Jiang, Y. Zhao, X. Zhang, X. Yang, Y. Chen, Z. Chu, Q. Ye, X. Li, Z. Yin, J. You, _Nat. Photonics_ **2019** , _13_ , 460. 

- [13] M. Stolterfoht, M. Grischek, P. Caprioglio, C. M. Wolff, E. GutierrezPartida, F. Peña-Camargo, D. Rothhardt, S. Zhang, M. Raoufi, J. Wolansky, M. Abdi-Jalebi, S. D. Stranks, S. Albrecht, T. Kirchartz, D. Neher, _Adv. Mater._ **2020** , _32_ , 2000080. 

- [14] E. Gutierrez-Partida, H. Hempel, S. Caicedo-Dávila, M. Raoufi, F. Peña-Camargo, M. Grischek, R. Gunder, J. Diekmann, P. Caprioglio, K. O. Brinkmann, H. Köbler, S. Albrecht, T. Riedl, A. Abate, D. Abou-Ras, T. Unold, D. Neher, M. Stolterfoht, _ACS Energy Lett._ **2021** , _6_ , 1045. 

- [15] P. Caprioglio, C. M. Wolff, O. J. Sandberg, A. Armin, B. Rech, S. Albrecht, D. Neher, M. Stolterfoht, _Adv. Energy Mater._ **2020** , _10_ , 2000502. 

- [16] M. Stolterfoht, V. M. Le Corre, M. Feuerstein, P. Caprioglio, L. J. A. Koster, D. Neher, _ACS Energy Lett._ **2019** , _4_ , 2887. 

- [17] M. Stolterfoht, P. Caprioglio, C. M. Wolff, J. A. Márquez, J. Nordmann, S. Zhang, D. Rothhardt, U. Hörmann, Y. Amir, A. Redinger, L. Kegelmann, F. Zu, S. Albrecht, N. Koch, T. Kirchartz, M. Saliba, T. Unold, D. Neher, _Energy Environ. Sci._ **2019** , _12_ , 2778. 

- [18] S. Zhang, S. M. Hosseini, R. Gunder, A. Petsiuk, P. Caprioglio, C. M. Wolff, S. Shoaee, P. Meredith, S. Schorr, T. Unold, P. L. Burn, D. Neher, M. Stolterfoht, _Adv. Mater._ **2019** , _31_ , 1901090. 

- [19] C. Kaiser, S. Zeiske, P. Meredith, A. Armin, _Adv. Opt. Mater._ **2020** , _8_ , 1901542. 

- [20] A. Koma, _Prog. Cryst. Growth Charact. Mater._ **1995** , _30_ , 129. 

**2103567 (9 of 10)** 

_Adv. Energy Mater._ **2022** , _12_ , 2103567 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

- [21] J. M. Richter, M. Abdi-Jalebi, A. Sadhanala, M. Tabachnyk, J. P. H. Rivett, L. M. Pazos-Outón, K. C. Gödel, M. Price, F. Deschler, R. H. Friend, _Nat. Commun._ **2016** , _7_ , 13941. 

- [22] F. Staub, H. Hempel, J.-C. Hebig, J. Mock, U. W. Paetzold, U. Rau, T. Unold, T. Kirchartz, _Phys. Rev. Appl._ **2016** , _6_ , 044017. 

- [23] B. Vermang, V. Fjällström, J. Pettersson, P. Salomé, M. Edoff, _Sol. Energy Mater. Sol. Cells_ **2013** , _117_ , 505. 

- [24] J. Peng, D. Walter, Y. Ren, M. Tebyetekerwa, Y. Wu, T. Duong, Q. Lin, J. Li, T. Lu, M.d A. Mahmud, O. L. C. Lem, S. Zhao, W. Liu, Y. Liu, H. Shen, L.i Li, F. Kremer, H. T. Nguyen, D.-Y. Choi, K. J. Weber, K. R. Catchpole, T. P. White, _Science_ **2021** , _371_ , 390. 

- [25] N. B. Kotadiya, et al., _Nat. Mater._ **2018** , _17_ , 329. 

- [26] M. A. Baldo, S. R. Forrest, _Phys. Rev. B_ **2001** , _64_ , 085201. 

- [27] Y. Shao, Y. Yuan, J. Huang, _Nat. Energy_ **2016** , _1_ , 15001. 

- [28] D. W. Dequilettes, S. Koch, S. Burke, R. K. Paranji, A. J. Shropshire, M. E. Ziffer, D. S. Ginger, _ACS Energy Lett._ **2016** , _1_ , 438. 

- [29] C. Quarti, F. De Angelis, D. Beljonne, _Chem. Mater._ **2017** , _29_ , 958. 

- [30] J. P. Perdew, M. Ernzerhof, K. Burke, _J. Chem. Phys._ **1998** , _105_ , 9982. [31] S. Grimme, J. Antony, S. Ehrlich, H. Krieg, _J. Chem. Phys._ **2010** , _132_ , 154104. 

- [32] J. Heyd, G. E. Scuseria, M. Ernzerhof, _J. Chem. Phys._ **2003** , _118_ , 8207. 

- [33] P. Giannozzi, O. Baseggio, P. Bonfà, D. Brunato, R. Car, I. Carnimeo, C. Cavazzoni, S. De Gironcoli, P. Delugas, F. Ferrari Ruffino, A. Ferretti, N. Marzari, I. Timrov, A. Urru, S. Baroni, _J. Chem. Phys._ **2020** , _152_ , 154105. 

- [34] F. Negri, G. Orlandi, F. Zerbetto, _J. Chem. Phys._ **1992** , _97_ , 6496. 

- [35] V. Capozzi, G. Casamassima, G. F. Lorusso, A. Minafra, R. Piccolo, T. Trovato, A. Valentini, _Solid State Commun._ **1996** , _98_ , 853. 

- [36] J. Lim, M. T. Hörantner, N. Sakai, J. M. Ball, S. Mahesh, N. K. Noel, Y.-H. Lin, J. B. Patel, D. P. Mcmeekin, M. B. Johnston, B. Wenger, H. J. Snaith, _Energy Environ. Sci._ **2019** , _12_ , 169. 

- [37] S. Kavadiya, A. Onno, C. C. Boyd, X. Wang, A. Cetta, M. D. Mcgehee, Z. C. Holman, _Sol. RRL_ **2021** , _5_ , 2100107. 

- [38] C. Huang, M. Moosmann, J. Jin, T. Heiler, S. Walheim, T. Schimmel, _Beilstein J. Nanotechnol._ **2012** , _3_ , 620. 

- [39] J. N. L. Albert, T. H. Epps, _Mater. Today_ **2010** , _13_ , 24. 

- [40] C. L. Haynes, R. P. Van Duyne, _J. Phys. Chem. B_ **2001** , _105_ , 5599. 

- [41] S. Y. Chou, _J. Vac. Sci. Technol., B: Microelectron. Nanometer Struct.– Process., Meas., Phenom._ **1998** , _14_ , 4129. 

- [42] A. A. Sutanto, P. Caprioglio, N. Drigo, Y. J. Hofstetter, I. Garcia-Benito, V. I. E. Queloz, D. Neher, M. K. Nazeeruddin, M. Stolterfoht, Y. Vaynzof, G. Grancini, _Chem_ **2021** , _7_ , 1903. 

**2103567 (10 of 10)** 

_Adv. Energy Mater._ **2022** , _12_ , 2103567 

© 2022 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

