# Rational selection of the polymeric structure for interface engineering of perovskite solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Joule |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 173 |
| 作者 | Min-Huan Wang, Ye-Pin Zhao, Xiao-Qing Jiang, Yanfeng Yin, I. Yavuz, Peng-Yu Zhu, Anni Zhang, G. Han et al. |
| DOI | 10.1016/j.joule.2022.04.002 |
| 源文件 | 062_Wang_2022_Rational-selection-of-the-polymeric-structure-fo.pdf |

---
**ll** 

### Article 

# Rational selection of the polymeric structure for interface engineering of perovskite solar cells 



Minhuan Wang, Yepin Zhao, Xiaoqing Jiang, ..., Shengye Jin, Jin-Wook Lee, Yang Yang 

jmbian@dlut.edu.cn (J.B.) sjin@dicp.ac.cn (S.J.) jw.lee@skku.edu (J.-W.L.) yangy@ucla.edu (Y.Y.) 

Highlights Minimized steric hindrance enables the effective defect passivation 

Design rules for selecting a polymer based on the molecular level are provided 

PVA passivates the interfacial defect and suppresses defect migration effectively 

Champion perovskite solar cell treated by PVA shows a high PCE of 23.20% 

High power conversion efficiency (PCE) and operational stability are needed for the widespread application of perovskite solar cells (PSCs). Here, the design rules for selecting a polymer based on the molecular-level consideration are provided. The prototypical PSCs treated with the optimal polymeric passivation exhibited superior performance (PCE = 23.20%) and operational stability (79.6% of the initial PCE retained after 1,600 h of continuous illuminance, whereas the reference devices are largely degraded). 

Wang et al., Joule 6, 1032–1048 May 18, 2022 ª 2022 Elsevier Inc. https://doi.org/10.1016/j.joule.2022.04.002 



**ll** 

##### Article 

## Rational selection of the polymeric structure for interface engineering of perovskite solar cells 

Minhuan Wang,<sup>1,2,9</sup> Yepin Zhao,<sup>2,9</sup> Xiaoqing Jiang,<sup>3,9</sup> Yanfeng Yin,<sup>1,7,9</sup> Ilhan Yavuz,<sup>4</sup> Pengchen Zhu,<sup>2</sup> Anni Zhang,<sup>2</sup> Gill Sang Han,<sup>5</sup> Hyun Suk Jung,<sup>5,8</sup> Yifan Zhou,<sup>2</sup> Wenxin Yang,<sup>2</sup> Jiming Bian,<sup>1,</sup> * Shengye Jin,<sup>7,</sup> * Jin-Wook Lee,<sup>6,8,</sup> * and Yang Yang<sup>2,10,</sup> * 

###### SUMMARY 

Tedious trial-and-error procedures are commonly practiced for surface modification of the perovskite solar cell (PSC) active layers. A guideline to rationally choose the passivating functional groups of the polymeric structure that is eminently effective in passivating the charged defects and elongating the device lifetime is hence in urgent demand. Herein, three prototypical polymers, poly(vinyl acetate) (PVA), polyethylene glycol (PEG), and poly(9-vinylcarbazole) (PVK), are selected to investigate the structural effect of the polymeric modification agents on the PSCs. We found that PVA possesses the Lewis base functional group with the minimized steric hindrance and the strongest electron-donating ability, enabling the most effective defect passivation on the perovskite film surface and the most enhanced carrier diffusion capacity. It demonstrates a power conversion efficiency (PCE) of 23.20% and noticeably enhanced operational stability. Our work provides important insights toward the selection of polymeric modification agents for high-performance and long-term stable PSCs. 

###### INTRODUCTION 

Organic-inorganic metal halide perovskite solar cell (PSC) has shown great potential as the next-generation low-cost solar energy harvester, owing to its superior light absorption coefficient (�10<sup>5</sup> cm<sup>�1</sup> ), long and balanced charge-carrier diffusion lengths (>1 mm in polycrystalline films), high defect tolerance, and ease of fabrication by simple solution processes.<sup>1–10</sup> In the past decade, there was a rapid surge in the power conversion efficiency (PCE) of the all-solid-state PSCs. Currently, the record PCE has improved to over 25% for n-i-p-structured devices,<sup>11–14</sup> which is attributed to the tremendous research efforts on crystal growth and compositional modulation of the perovskite light-harvesting layer as well as device configuration design and interface engineering.<sup>10,12</sup> 

###### Context & scale 

Good device performance with reasonable long-term stability is highly demanded for the successful commercialization of the perovskite solar cells (PSCs). Defect passivation through polymeric agents is a powerful strategy for highly efficient and stable PSCs. They are beneficial for longevity of the passivation under operational condition owing to their bulky and longrange-ordered molecular structures. However, the molecular design rules of the polymer agents lack sufficient discussion. Here, we incorporated strategically designed polymeric passivating agents to investigate their interactions with perovskite crystals and correlated them with the device performances and longevity of the passivation effects. 

Metal halide perovskite films for high-efficiency devices are mostly grown via lowtemperature solution-based processes.<sup>15–17</sup> The resulting films are inevitably polycrystalline in nature with a high density of defects, including point and extended imperfections, which are mainly located at the top surface and grain boundaries of the films.<sup>18–21</sup> The presence of these defects can aggravate charge-carrier recombination in PSCs, which negatively affects the device performance.<sup>22</sup> In addition, due to low activation energies for the migration of the ionic defects in the perovskite films 



1032 Joule 6, 1032–1048, May 18, 2022 ª 2022 Elsevier Inc. 

**ll** 

##### Article 

(�0.6 eV for halide vacancies, can be further reduced under illumination), those charged ionic defects can migrate toward charge-transporting layers under an electric field, which degrades the long-term operational stability of the devices.<sup>23,24</sup> Thus, minimizing the detrimental effect of defects and suppressing ion migration through effective surface modification have been proven to be the most powerful strategies for high-performance and stable PSCs.<sup>10,25,26</sup> 

Compared with other passivating agents,<sup>10,25,27</sup> polymers have unique advantages when used as surface passivating agents.<sup>17,28–30</sup> The polymeric passivation materials are found to be beneficial for durable defect passivation under operational conditions owing to their bulky and long-range-ordered molecular structure.<sup>28–31</sup> Nevertheless, the molecular structure of the polymeric passivation agents and their interaction with perovskite crystals are not fully elucidated. Consequently, choosing a suitable polymeric surface passivation agent commonly involves tedious trial-anderror procedures. Hence, a guideline to rationally choose the passivating functional groups of the polymeric structure that is eminently effective in passivating the charged defects and elongating the device lifetime is highly desired. 

Hence, three prototypical low-cost polymers, namely, poly(vinyl acetate) (PVA), polyethylene glycol (PEG), and poly(9-vinylcarbazole) (PVK), were adopted to investigate the effects of the molecular structure of polymeric passivating agents on the effectiveness of surface defect passivation. Based on computational and experimental analyses, the defect passivation capability of the polymeric passivating agents was closely correlated with the molecular structure of the polymers and their interactions with the perovskite crystal surface. Among these polymers, PVA, with sterically accessible Lewis base ester groups, was proven to be the most effective passivating agent to nullify the charged defect states and impede their migration, while improving the interfacial contact between the perovskite and hole transporting layer (HTL) simultaneously. The PVA-modified PSCs achieved a remarkably improved PCE of 23.20%, along with significantly enhanced operational stability and negligible current-voltage hysteresis. 

###### RESULTS AND DISCUSSION 

The molecular structures of the selected polymers for surface modification are shown in Figures S1A–S1C. These polymers were dissolved in the chlorobenzene and spin-coated onto the annealed perovskite layer. The PSCs with the structure of indium-doped tin oxide (ITO)/SnO2/perovskite/polymer/spiro-MeOTAD/Au were fabricated. The concentration of the polymer solutions was optimized based on the photovoltaic performance of the PSCs. The measured photovoltaic parameters are plotted in Figure S2, and the average values for each parameter are summarized in Table S1. No matter what kind of polymer used, the average PCE reaches maximum values with 0.05 mg/mL polymer solution, possibly due to similar insulating nature. Notably, the average short-circuit current density (JSC) of the devices was enhanced by 5.8% from 24.130 G 0.556 to 25.286 G 0.329 mA/cm<sup>2</sup> as the concentration of PVA increased from 0 to 0.05 mg/mL. However, further increase in the PVA concentration reduced the average JSC to 24.930 G 0.982 (0.15 mg/mL). Similarly, enhancement in both open-circuit voltage (VOC) and fill factor (FF) reached their maximum when the PVA concentration was raised to 0.05 mg/mL: from 1.117 G 0.009 to 1.150 G 0.006 V for VOC (3.0% enhancement) and from 0.746 G 0.010 to 0.795 G 0.010 for FF (6.5% enhancement). As a result, the average PCE of the 0.05 mg/mL PVA-solution-treated devices was enhanced by 12.9% from 20.12 G 0.36 to 22.71 G 0.41%. For the devices with PEG and PVK polymers, similar changes 

1Key Laboratory of Materials Modification by Laser, Ion and Electron Beams (Dalian University of Technology), Ministry of Education, School of Physics, Dalian 116024, China 

2Department of Materials Science and Engineering and California NanoSystems Institute, University of California, Los Angeles, Los Angeles, CA 90095, USA 

3State Key Laboratory Base of Eco-Chemical Engineering, College of Chemical Engineering, Qingdao University of Science and Technology, Qingdao 266042, China 

4Department of Physics, Marmara University, Ziverbey, Istanbul 34722, Turkey 5School of Advanced Materials Science and Engineering, Sungkyunkwan University (SKKU), Suwon 16419, Republic of Korea 

6SKKU Advanced Institute of Nanotechnology (SAINT) and Department of Nanoengineering, Sungkyunkwan University, Suwon 16419, Republic of Korea 

7State Key Laboratory of Molecular Reaction Dynamics, Dalian Institute of Chemical Physics, Chinese Academy of Sciences, 457 Zhong Shan Rd., Dalian 116023, China 

8SKKU Institute of Energy Science & Technology (SIEST), Sungkyunkwan University, Suwon, 16419, Republic of Korea 

9These authors contributed equally 10Lead contact *Correspondence: jmbian@dlut.edu.cn (J.B.), sjin@dicp.ac.cn (S.J.), jw.lee@skku.edu (J.-W.L.), yangy@ucla.edu (Y.Y.) https://doi.org/10.1016/j.joule.2022.04.002 

Joule 6, 1032–1048, May 18, 2022 1033 

**ll** 

Article 



Figure 1. Interaction simulation and confirmation (A) Partial charge distribution of three kinds of monomers determined by density functional theory (DFT) calculation. (B–J) Theoretical models of the monomers interacting with surface iodide vacancy (VI) defect of perovskite crystals and the corresponding interaction energies (Eint): monomers of (B) poly(vinyl acetate) (PVA), (E) polyethylene glycol (PEG), and (H) poly(9-vinylcarbazole) (PVK). Fourier transform infrared spectroscopy (FTIR) spectra of (C and D) pure PVA and PVA-PbI2 films, (F and G) pure PEG and PEG-PbI2 films, and (I and J) PVK and PVK-PbI2 films. 

in photovoltaic parameters were observed, but the magnitude of changes was relatively smaller than those obtained from PVA-based devices. The overall increase in the PCE was thus less pronounced: from 20.12 G 0.36 to 21.54 G 0.53 and 20.85 G 0.81 for PEG- and PVK-based devices, respectively. The differences in the photovoltaic performances of the devices should be attributed to the varying passivation effects between the surface defects of perovskite thin films and the polymers. 

As demonstrated in our previous works,<sup>6,32</sup> the calculated interaction energies for the model monomer molecules can be used for speculating general trend in interaction energies of the polymers. Thus, the partial charge distribution and resultant interaction energies of the selected polymers are first investigated by density functional theory (DFT) calculation using their respective monomers (Figure 1A). Relatively stronger negative partial charge is localized on ester double-bond groups (C=O) on the side chain of the PVA monomer, whereas relatively weaker negative partial charge is found on ether bond (C–O) on the main chain of the PEG monomer. In the PVK monomer, the negative partial charge is delocalized on the carbazole functional group. The molecular interactions between the polymers and the charged 

1034 Joule 6, 1032–1048, May 18, 2022 

**ll** 

##### Article 

surface defects on perovskite crystals are further investigated by the DFT calculation. It has been reported that the iodide vacancy (VI) defects will most readily form on the perovskite surface due to its lowest formation energy.<sup>33,34</sup> We confirmed that our pristine film also has a I/Pb ratio lower than 3, which is indicative of iodide-deficient film surface (i.e., iodide vacancies, Figure S3). Therefore, we investigated the interaction between the VI and the selected monomers based on the structural models shown in Figures 1B, 1E, and 1H (top view of the models is available in Figure S4). The PVA monomer molecule interacted strongly with the VI defect, resulting in an interaction energy (Eint, defined as Eint = Emolecule�perovskite � Eperovskite � Emolecule)<sup>35</sup> of �0.590 eV, whereas the lower interaction energies of �0.536 and �0.406 eV were obtained for PEG and PVK monomers. It indicates that the more electron-rich functional groups of the polymeric passivating agents would preferentially interact with the positively charged VI defect. Considering the structural configuration of the monomers interacting with the perovskite lattices, the difference in the interaction energies of these three monomers with the VI defects should be attributed to the varying strength of the partial charge on the interacting functional groups of the monomers, as well as the degree of steric hindrance of the functional groups. The ester double-bond groups (C=O) on the side chain of PVA monomer possess a greater negative partial charge and are more accessible to the undercoordinated Pb<sup>2+</sup> (VI), whereas the ether bond (C–O) on the PEG monomer has a smaller partial charge and is hindered by surrounding CH2. In PVK monomer, the partial negative charge is delocalized around the bulky carbazole group. Hence, its interaction with the perovskite crystal defects is limited, as indicated by the lowest interaction energy. 

To confirm the interaction between the correlated Lewis base functional groups of the polymers and the Lewis acid lead ions, we applied Fourier transform infrared spectroscopy (FTIR) to investigate the C=O stretch in PVA, C–O stretch in PEG, and carbazole vibration in PVK (Figure 1). The stretching vibration of C=O bond in PVA molecule appeared at 1,722 cm<sup>�1</sup> , and it shifted to 1,698 cm<sup>�1</sup> (D = 24 cm<sup>�1</sup> ) upon interaction with PbI2. The shift of the C=O stretching vibration frequency in PVA molecule resulted from the delocalization of electrons in oxygen to form Lewis acid-base adduct with the PbI2. On the other hand, the positions of the FTIR peaks of C–O groups in PEG molecule and carbazole groups in PVK were less influenced by the addition of PbI2. The peaks corresponding to C–O and carbazole functional groups were shifted from 1,155 to 1,150 cm<sup>�1</sup> (D = 5 cm<sup>�1</sup> ) and from 1,598 to 1,596 cm<sup>�1</sup> (D = 2 cm<sup>�1</sup> ), respectively. The much more pronounced peak shift for PVA than those for other polymers supports the stronger interaction energy between the PVA and undercoordinated Pb<sup>2+</sup> (VI) owing to the sterically accessible Lewis base C=O functional group with more negative partial charges, confirming the predications by computer simulations. 

The strength of the interaction was further confirmed by X-ray photoelectron spectroscopy (XPS) analysis. Figure 2A and Figure S5 show the XPS spectra of the Pb 4f orbitals measured from the perovskite films without and with surface post-treatment by PVA, PEG, and PVK (all at the concentration of 0.05 mg/mL). The typical two peaks due to the spin-orbit splitting were detected from the high-resolution Pb 4f core-level spectra. With the polymeric overlayers, the peaks shifted to a lower binding energy, probably due to the lowered oxidation state or increased electron cloud density of Pb as a result of electron donation from the polymers.<sup>36</sup> Among the polymers, the largest shift of peak was observed for the film with PVA as a modification layer, indicating that the ester double bond (C=O) in PVA rendered the strongest interaction with the undercoordinated Pb<sup>2+</sup> ions on the perovskite surface, which is consistent with above DFT calculations and FTIR measurements. 

Joule 6, 1032–1048, May 18, 2022 1035 

**ll** 

Article 



Figure 2. Characterizations of film surface changes with different treatments (A and B) (A) XPS spectra of Pb 4f peaks of the perovskite films without and with polymer modification layer and (B) corresponding X-ray diffraction (XRD) patterns. (C–J) Scanning electron microscopy (SEM) images and conductive atomic force microscopic (c-AFM) images of the perovskite films (C and G) without and with surface treatment using (D and H) PVA, (E and I) PEG, and (F and J) PVK. The perovskite films were prepared on SnO2-coated ITO glass. The c-AFM measurement was carried out with a bias voltage of 100 mV under room light. 

The X-ray diffraction (XRD) patterns of the perovskite films without and with the three polymers treatment are shown in Figure 2B. The intensities and full-width-half-maximums (FWHMs) of the (001) and (002) orientation peaks of the polymer-treated perovskite film were comparable with those of the peaks of the control perovskite film, indicating that the post-heat-treatment introduction of the polymer layer had a negligible effect on the crystallinity of the underlying perovskite film. The topview scanning electron microscopic (SEM) images of the perovskite films without and with polymer treatments are shown in Figures 2C–2F. Compared with the control film (without any polymer treatment), the grain size of polymer-modified perovskite films almost remained unchanged. The larger (5 3 4 mm<sup>2</sup> ) SEM images and the corresponding statistical distribution of grains are shown in Figure S6. The average grain size of both control and polymer-treated films was �370 nm. The contact angle measurement of the pure PVA, PEG, and PVK, perovskite and perovskite films 

1036 Joule 6, 1032–1048, May 18, 2022 

**ll** 

##### Article 

post-treated by PVA, PEG, and PVK was conducted as shown in Figure S7. The left water contact angles were 72.8<sup>�</sup> , 28.9<sup>�</sup> , and 95.0<sup>�</sup> (the right water contact angles were 71.9<sup>�</sup> , 27.8<sup>�</sup> , and 94.9<sup>�</sup> ) for the pure PVA, PEG, and PVK films, respectively (shown in Figures S7A–S7C). The contact angles of pristine perovskite film were 55.1<sup>�</sup> and 55.4<sup>�</sup> for left and right, respectively. The contact angle trend of perovskite film post-treated by PVA was 57.9<sup>�</sup> and 57.6<sup>�</sup> for left and right, respectively (shown in Figure S7E). The contact angle pure PVA > PVA/perovskite > pristine perovskite (the same trend was seen in the other two polymer materials) indicates that the discontinuous polymeric layer is formed on the surface of the perovskite film. The surface roughness of the perovskite films with and without polymers was further studied by atomic force microscopy (AFM) as shown in Figure S8. The root mean square (RMS) roughness values were measured to be 36.8, 30.9, 34.1, and 34.5 nm for control, PVA-treated, PEG-treated, and PVK-treated perovskite films, respectively. The decreased roughness of the polymer-modified perovskite films can be ascribed to the formation of thin polymeric overlayer. The conductive AFM (c-AFM) was performed, and the results are shown in Figures 2G–2J to observe the spatially resolved electrical properties of these perovskite films. The average current was 175, 1,520, 879, and 323 pA for control, PVA-treated, PEG-treated, and PVK-treated perovskite films, respectively. Clearly, the current was higher but inhomogeneous in the films with the polymer post-treatment, whereas relatively uniform and lower current was observed in the control film, which indicates that the local charge collection efficiency of photo-generated carriers was facilitated for the polymer post-treatment samples. Meanwhile, the Kelvin probe force microscopy (KPFM) measurement was performed as shown in Figure S9 to investigate the surface energy changed by the polymers. Compared with the control film, the contact potential difference (CPD) at the grain boundary region increases significantly for the films modified by polymers (�100 mV). This indicates that the polymeric passivator mainly exists at the low-lying grain boundary region and passivates the defects at the grain boundaries. The CPD at grain interior region remains unchanged or slightly changed, indicating that surface-energy-level alignment in this region is not affected by the polymer coating. 

To investigate the impact of the deposited polymers on carrier dynamics, we first examined the steady-state absorption and photoluminescence (PL) spectra of the perovskite films with and without polymer deposition (Figure 3A). The absorption spectra were almost identical for all perovskite films, indicating no significant contribution of the polymer layer to the absorption in the visible wavelength region. On the other side, the steady-state PL intensity was significantly enhanced for the films with the polymer treatment, by 10.4 (PVA), 4.2 (PEG), and 2.8 (PVK) times higher than that of the control film. This result was consistent with the trap-state passivation effect of polymers. We then investigated the carrier dynamic over a large timescale from fs to ms through both the ultrafast transient absorption (TA) spectroscopy (Figure S10) and the time-resolved PL (TRPL) technique. Figure 3B shows the recovery kinetics of transient bleaching signal probed at 795 nm in TA spectra of perovskite films without and with the three polymeric modification layers (pump wavelength was 370 nm). The TA bleaching signal at 795 nm originates from the band-edge state filling by photo-excited charge carriers.<sup>37,38</sup> Its recovery kinetic can then reflect the carrier depopulation process. For all the examined samples, their TA kinetic did not exhibit any ultrafast decay process within the <1 ns window, indicating that the deposition of PVA, PEG, and PVK did not introduce any fast decay pathways to the carriers in perovskites. However, compared with the control sample, the TA decays became slower in the ns time window for the films with the polymer post-treatment. This trend can be further confirmed by the TRPL decays collected in the ns-to-ms time windows (as seen in Figure 3C). To quantitatively determine the 

Joule 6, 1032–1048, May 18, 2022 1037 

**ll** 

Article 



Figure 3. Carrier lifetime differences of the films with different treatments (A–K) (A) Absorption and steady-state photoluminescence (PL) spectra, (B) transient absorption (TA) decay curves, (C) time-resolved PL decay, and twodimensional PL intensity and PL lifetime images of the perovskite films without (D and H) and with polymer modification layers of PVA (E and I), PEG (F and J), and PVK (G and K). The empty circles indicate the measured data, and solid lines indicate the fitted curves in (C). 

photo-excited carrier lifetimes, the TRPL decays in Figure 3C were fitted by a biexponential decay function and the resulting parameters are summarized in Table S2. The averaged PL lifetimes (t) were calculated to be 139.3, 877.2, 556.5, and 382.4 ns for the control film and PVA-, PEG-, and PVK-treated films, respectively. The trend was also confirmed by fitting results using stretched exponential function (a model can reflect the time domain response of a system as it physically represents a distribution of microscopic lifetimes)<sup>39</sup> and shown in Figure S11; Table S3. The carrier lifetimes in polymertreated perovskite films became much longer than that in the control sample. This result is also consistent with the trap passivation mechanism by polymer depositions, which eliminates the nonradiative carrier loss (recombination) and thus leads to longer carrier lifetimes and enhanced PL intensity. Most importantly, among the three examined polymers, PVA was found to introduce the most prominent trap passivation effect in perovskites. This result is coherent with the predictions from DFT calculations. 

To examine the PL homogeneity of perovskite films before and after the polymer deposition, the PL intensity and lifetime images with a sub-micrometer spatial resolution were taken using a laser-scanned and time-resolved imaging microscopy. 

1038 Joule 6, 1032–1048, May 18, 2022 

**ll** 

##### Article 



Figure 4. PL-scanned imaging microscopy and fitted data (A–D) PL intensity images of perovskite films at different delay times after excitation before (A) and after PVA (B), PEG (C), and PVK (D) treatment. The spread of PL spot with the increase of delay time reflects the carrier transport away from the excitation site samples, respectively. (E) s<sup>2</sup> x<sup>ðtÞ asafunctionofdelaytime,withalinearfittoyieldthediffusioncoefficient.</sup> (F) The fitted diffusion coefficient and calculated carrier diffusion length of the perovskite films without and with polymer treatment. 

Figures 3D–3G show the PL intensity images of perovskite films with and without polymer depositions, and their corresponding PL lifetime images are shown in Figures 3H–3K. Although the spatial resolution of the imaging microscopy was unable to resolve the perovskite grain structures (<500 nm) in the film, prominent improvements in both PL intensity and homogeneity (in micrometer scale) were observed in the films with polymer depositions. The results in PL lifetime images (Figures 3H–3K) further confirmed the polymer-induced improvement of PL property by displaying longer local PL lifetimes and more homogeneous lifetime distribution. Therefore, among the three examined polymers, PVA passivating layer again leads to the greatest improvement in the PL intensity, lifetime, and distribution homogeneity. 

Aside from the PL quantum yield and lifetimes, carrier diffusivity (or diffusion length) is also a key factor that determines the performance of PSC. We investigated how the polymer treatment can affect the carrier transport in perovskite films by using PLscanned imaging microscopy.<sup>40</sup> In this measurement, the excitation laser beam was focused at a fixed position on the film and a series of PL intensity images were obtained by plotting the scanned PL collection pathway across the film as a function of delay time. The delay time from excitation to emitting photons was recorded by the time-correlated single-photon counting model.<sup>40</sup> Figures 4A–4D are the PL intensity images at various delay times obtained from the control and PVA-, PEG-, and PVK-treated films. All films showed a spread of PL spot with the increase in delay times. As the PL intensity was proportional to carrier population, the 

Joule 6, 1032–1048, May 18, 2022 1039 

**ll** 

Article 

spread of PL indicates that the carriers were transported away from the initial excitation site.<sup>41,42</sup> To quantitatively determine the diffusion coefficient, the crosssectional profiles of the PL spots at different delay times were fitted by s<sup>2</sup> x<sup>ðtÞ=</sup> s<sup>2</sup> 0; x<sup>+ 4Dt(seeFigureS12forthefitting),40–42whereGaussianvariance(s</sup> x<sup>2ðtÞ)re-</sup> flected the size of PL spot. The diffusion coefficient (D) was then calculated from a linear fit of the measured Gaussian variance as a function of time (Figure 4E) (see the detail about the calculation in the Note S1) and was found to be 0.0164 G 0.0022, 0.0414 G 0.0061, 0.0378 G 0.0020, and 0.0267 G 0.0020 cm<sup>2</sup> /s for the control film, PVA-, PEG-, and PVK-treated perovskite films, respectively. The theoretical f **f** i f **f** i f **f** carrier diffusion length (LD) was then calculated by LD = pDt. The D and LD values from different films are compared in Figure 4F, where a dramatic increase in D and LD is found for films with polymer treatment. This result indicates that the polymers can not only passivate the defects but also improve carrier diffusion, most likely by passivating deep traps and increasing the probability of inter-grain carrier transport. Again, the PVA polymer is the champion one with a maximum LD of 1.70 mm. 

All abovementioned results evidently demonstrate the excellent passivating effect of polymer treatment, particularly for PVA, in improving many photophysical properties of perovskite materials. The comparison between three different polymers also provides an important insight into the design of an effective polymer with specific molecular structure that regulates and optimizes the perovskite photophysical properties. 

Finally, we examined the effect of polymer treatment in practical PSCs. The complete device structure of ITO/SnO2/perovskite/polymer/spiro-MeOTAD/Au is illustrated in Figure S13, and the cross-sectional SEM images of the devices are presented in Figure S14. Here, the interface between the perovskite active layer and HTL is the focus of our investigation and is thus marked with a red dotted box. In the control device, some concave- and convex-shaped regions, as well as obvious contact gap, were observed at the interface. Compared with the control device, the interface contacts between perovskite and HTL improved significantly for the polymer-treated devices, especially with the post-treatment by PVA. This observation indicates that the polymer post-treatment can improve the interface contact, which may contribute to facilitating the carrier extraction from the perovskite layer. The current density-voltage (J-V) curves and corresponding photovoltaic performance parameters of the champion PSCs with and without the polymer treatment process are compared in Figure 5A and Table 1. The control device had a JSC of 23.28 mA/cm<sup>2</sup> , Voc of 1.120 V, FF of 78.5%, and a resulted PCE of 20.47% in the reverse scan. In comparison, the perovskite film treated by 0.05 mg/mL PVA solution had all the photovoltaic parameters increased, achieving a JSC of 25.24 mA/cm<sup>2</sup> , Voc of 1.149 V, FF of 80.0%, and a resulted PCE of 23.20% in the reverse scan. The champion PCEs of the devices with PEG- and PVK-modified layers were 22.35% and 21.97%, respectively, which were both higher than that of the control devices. Therefore, we confirmed that all three polymers were effective in improving the performances of the devices, and the best improvement was achieved by PVA. Figure 5B displays the external quantum efficiency (EQE) spectra of the corresponding devices. The integrated JSC values were calculated to be 23.20, 24.59, 23.64, and 23.52 mA/cm<sup>2</sup> for control, PVA-, PEG-, and PVK-treated devices, respectively. These values were reasonably consistent with the average JSC values obtained from the J-V measurements, with less than 5% discrepancy. The time-dependent photocurrent output at a fixed bias voltage was measured and is shown in Figure 5C, with the stabilized PCEs of 20.08%, 22.92%, 21.69%, and 21.26% for the control, PVA, PEG, and PVK treatment, respectively, which were also consistent with the PCEs obtained from the J-V measurements. 

1040 Joule 6, 1032–1048, May 18, 2022 

**ll** 

##### Article 



Figure 5. Device characterizations 

(A) Current density-voltage (J-V) curves of the PSCs without and with polymer post-treatment by PVA, PEG, and PVK. Solid and dotted lines are data obtained by reverse and forward scans, respectively. 

(B) The external quantum efficiency (EQE) spectra and corresponding integrated short-circuit current density (JSC) of the PSCs. 

(C) Time-dependent power output measurements to monitor the stabilized power conversion efficiencies (PCEs) at constant bias voltage. (D–G) (D) Transient photocurrent (TPC) decay, (E) The Nyquist plots, (F) Mott-Schottky plots, (G) calculated trap density of the corresponding PSCs without and with polymer post-treatment by PVA, PEG, and PVK. (H and I) (H) Space-charge-limited-current (SCLC) measurements and (I) defect density calculated from SCLC measurements without and with polymer post-treatment. VTFL is the trap-filling voltage. The empty circles indicate the measured data, and the solid lines indicate the fitted curves in (D) and (F). 

The transient photocurrent (TPC) and transient photovoltage (TPV) decay process were applied to study the charge-carrier behavior in the PSCs as shown in Figures 5D and S15. The TPC and TPV data were fitted by single exponential decay model to get the time constants for charge collection (tC) and charge recombination (tR) (Figure S16). The tC values for the control, PVA, PEG, and PVK were 4.75, 1.82, 2.07, and 2.34 ms, respectively, indicating a facilitated charge collection process in the PVA-treated device. The introduction of PVA might improve the interfacial contact between the perovskite and HTL to promote the extraction of photo-excited carriers. The tRs were 0.14, 0.30, 0.20, and 0.16 ms for the control, PVA-, PEG-, and PVK-treated devices, respectively, which are in accord with the trend observed in the PL intensity and lifetime measurements (Figures 3B and 3C). The largest tR for the sample treated by PVA indicates that the recombination of electron and hole pairs can be most effectively mitigated by the PVA post-treatment. Based on the above 

Joule 6, 1032–1048, May 18, 2022 1041 

**ll** 

Article 

Table 1. Photovoltaic parameters 

|||Voc [V]|Jsc [mA cm<sup>�2</sup>]|FF [%]|PCE [%]|
|---|---|---|---|---|---|
|Ref|forward|1.118|23.31|69.1|18.01|
||reverse|1.120|23.28|78.5|20.47|
|PVA|forward|1.146|25.25|78.7|22.77|
||reverse|1.149|25.24|80.0|23.20|
|PEG|forward|1.112|24.92|75.5|20.92|
||reverse|1.126|24.94|79.6|22.35|
|PVK|forward|1.104|25.19|75.0|20.86|
||reverse|1.106|25.27|78.6|21.97|



The parameters of the PSCs tested under standard solar simulator (100 mW$cm<sup>�2</sup> illumination, AM 1.5G). Open-circuit voltage (VOC), short-circuit current density (JSC), fill factor (FF), and power conversion efficiency (PCE). 

analysis, it can be deduced that the density of defect states at the interface was greatly reduced via PVA post-treatment to facilitate the extraction of photo-excited hole carriers to the HTL layer. Thus, we attributed the improved photocurrent to (1) improved charge-carrier diffusion lengths in the perovskite layer due to reduced defect states, (2) the improved interfacial contact to promote the charge transfer from the perovskite layer to spiro-MeOTAD layer. The both factors should contribute to charge collection efficiency of the PSCs and thus photocurrent of the device.<sup>43,44</sup> Electrochemical impedance spectroscopy (EIS) is a powerful method to analyze the characteristics of heterointerfaces of perovskite devices. Here, the Nyquist plots by the EIS measurement are shown in Figure 5E. Using a modified Randles equivalent circuit, the radii of the semicircles can be assigned to a combination of the charge transport resistance (Rct) and recombination resistance (Rrec).<sup>28,45,46</sup> In comparison with that of the control device, the Rct (the semicircle with relatively smaller radius) decreased significantly, but the Rrec (the semicircle with relatively larger radius) increased in the case of the PVA treatment. The observed trend exhibited by Rct and Rrec correlates well with the TPV and photocurrent decay measurements. Thus, it can be speculated that an appropriately thin PVA-modified layer could effectively prevent interfacial charge recombination while improving the interfacial contact, and in turn facilitate the extraction of photo-generated carrier from perovskite layer. The Mott-Schottky plots of devices were further investigated, as shown in Figure 5F. The built-in potentials of the devices were 1.033, 1.093, 1.072, and 1.065 V for devices without and with polymer post-treatment by control and PVA, PEG, and PVK, respectively, which correlated with the VOC measured from the devices. The trap density (Nt) of each device was estimated by using admittance spectroscopy measurement (Figures S17 and 5G),<sup>47</sup> (the detail about the calculation is seen in Note S2). The Nt was lower for the polymer posttreatment devices (PVA < PEG < PVK < control), and the trend corresponded well with the TA, steady-state PL intensity, average PL lifetime, the tR, and interfacial contact, indicating that the polymer post-treatment by PVA, PEG, and PVK reduced the surface and/or interfacial defect density and enhanced the device performance. Furthermore, the space-charge-limited-current (SCLC) technique was utilized to cross-check the defect density in the perovskite films treated by different passivating agents, as shown in Figures 5H and 5I. The device with a structure of ITO/perovskite/polymer/Au was fabricated and is shown in the inset of Figure 5I. The Nt can be calculated from the equation: 



<!-- Start of picture text -->
eNtd 2<br>VTFL = (Equation 1)<br>2εε0<br><!-- End of picture text -->

where e istheelementarycharge, d isthe perovskitefilm thickness, ε istherelativedielectric constant, ε0 is the vacuum permittivity, and VTFL is the trap-filling voltage. The 

1042 Joule 6, 1032–1048, May 18, 2022 

**ll** 

##### Article 



Figure 6. Stability tests (A–C) The change of PCEs of the PSCs without and with polymer post-treatment by PVA, PEG, and PVK (A) under continuous illumination (90 G10 mW cm<sup>�2</sup> ), (B) thermal stress (85<sup>�</sup> C, under dark and nitrogen atmosphere), and (C) dark conditions without encapsulation. 

perovskite film treated by PVA had the lowest defect density of 4.61 3 10<sup>15</sup> cm<sup>�3</sup> , which was significantly lower than that of the control sample (1.01 3 10<sup>16</sup> cm<sup>�3</sup> ) and lower than those of PEG-treated films (5.19 3 10<sup>15</sup> cm<sup>�3</sup> ) and PVK-treated films (5.44 3 10<sup>15</sup> cm<sup>�3</sup> ). Additionally, dark J-V curves of the devices are presented in Figure S18, (the detail about the calculation is presented in Note S3). The series resistance (Rs), shunt resistance (Rsh), saturation current (J0), and ideality factor (n) calculated from dark J-V curves are summarized in Table S4.<sup>48</sup> Compared with the control device, the reduced Rs and increased Rsh obtained in PVA-treated devices are consistent with the TPV and TPC measurements. The lower J0 and n values also indicate the reduced interfacial recombination and improved interfacial contact between the perovskite and HTL. 

To investigate the effects of different polymeric passivating agents on the operational stability of the solar cell devices, we exposed the encapsulated devices to continuous illumination under open-circuit conditions (Figure 6A). The ion migration is expected to be the most severe under open-circuit conditions (versus maximum power point [MPP] tracking) due to relatively high charge-carrier concentration in the device. After 1,600 h of exposure, the control device almost completely degraded, whereas the encapsulated device incorporated with PVA maintained 79.6% of its initial PCE. The devices incorporated with PEG and PVK retained 55.5% and 42.8% of the initial PCEs, respectively. To further evaluate the thermal stability of the devices, we kept the unencapsulated devices in a nitrogen-filled glove box at 85<sup>�</sup> C (Figure 6B). The poly(triaryl amine) (PTAA) was used as the hole-transporting layer instead of spiro-MeOTAD owing to its poor thermal stability. After 1,600 h, we observed that the device incorporated with PVA maintained the highest PCE (retaining 72.8% of its initial PCE) relative to the other devices. The control, PEG-, and PVK-incorporated devices retained 0%, 58.2%, and 48.3% of their initial PCEs, respectively. Finally, the change of PCE for unencapsulated devices 

Joule 6, 1032–1048, May 18, 2022 1043 

**ll** 

Article 

under dark conditions was investigated as shown in Figure 6C. All devices with polymeric surface modification maintained higher PCE than that of control device for 1,600 h. After 1,600 h, the control device and the devices with PVA, PEG, and PVK modifications maintained 33.3%, 98.7%, 84.3%, and 73.9% of their initial efficiency, respectively. The observed trend in device stability indicates that the passivating agents, having Lewis base functional group with strong partial charge and little steric hindrance when interacting with the lattice defects, can be beneficial for defect passivation and defect migration suppression during the elongated stress tests under harsh operational conditions. The strongly coordinated charged defects by the passivation agents probably remained impervious to the potential gradient due to their compensated charge and the larger effective mass. 

###### Conclusions 

In summary, we studied the influence of partial charge and structural configuration for the polymeric passivating agents by utilizing prototypical polymers, including PVA, PEG, and PVK. Among them, the sterically accessible ester functional groups in the PVA with the strongest partial charge ensured its strongest interaction with the charged defects on the perovskite surface, leading to its superior passivating capability and longevity of the devices. Meanwhile, the PVA interlayer further improved the interfacial contact between the perovskite and HTL to promote photo-generated charge-carrier extraction. As a result, PVA-modified PSC demonstrated a remarkably improved PCE of 23.20% compared with 20.47% of the control device, together with an evident enhancement of its operational and thermal stabilities. Our work reveals the importance of the functional group configuration in the polymeric passivation agents and thus provides a guideline to rationally select suitable passivating polymers for high-performance and long-term durable PSCs. 

###### EXPERIMENTAL PROCEDURES 

###### Resource availability 

Lead contact 

Further information and requests for resources should be directed to the lead contact, Prof. Yang Yang (yangy@ucla.edu). 

###### Materials availability 

This study did not generate any new unique materials. 

###### Data and code availability 

All data needed to support the findings of this study are available from the lead contact upon reasonable request. 

###### Device fabrication 

Indium-doped tin oxide (ITO)-coated glass was pre-patterned and cleaned with successive sonication in detergent, deionized water, acetone (99.9%, Sigma-Aldrich), and 2-propanol (IPA, 99.7%, Sigma-Aldrich) for 30 min, respectively. The substrates were dried under nitrogen flow and treated by UV-ozone to enhance the wettability and remove organic contaminants. A thin layer (ca. 30 nm) of tin oxide (SnO2) nanoparticles (15 wt % in water, Alfa-Aesar) was spin-coated (3,000 rpm for 30 s) from a filtered aqueous solution (2 mg mL<sup>�1</sup> ) onto the ITO glass and annealed at 150<sup>�</sup> C for 30 min. The SnO2/ITO/glass substrates were transferred into a nitrogen glove box for perovskite film deposition after another treatment by UV-ozone. The PbI2 (99.99%, Alfa-Aesar) solution was prepared by dissolving 1.5-M PbI2 into 1-mL dimethylformamide (DMF, 99.8%, Sigma-Aldrich)/dimethyl sulfoxide (DMSO, 99.7%, Sigma-Aldrich) mixed solvent (v/v 9/1). The organic solution was prepared by 

1044 Joule 6, 1032–1048, May 18, 2022 

**ll** 

##### Article 

dissolving 90-mg HC(NH2)2I (FAI, 99%, GreatCell Solar), 6-mg CH3NH3Br (MABr, 99%, GreatCell Solar), and 9-mg CH3NH3Cl (MACl, 99%, Xi’an Polymer Light Technology) into 1-mL IPA. The solutions were stirred for over 1 h before use. The PbI2 solution was spin-coated on the substrate at 1,500 rpm for 30 s and annealed at 70<sup>�</sup> C for 30 s. The FAI/MABr/MACl solution was spin-coated on the PbI2 at 2,000 rpm for 30 s and annealed at 95<sup>�</sup> C for 30 s; then, the film was annealed outside the glove box at 150<sup>�</sup> C for 10 min with 40% humidity. Then, chlorobenzene (CB, 99.8%, Sigma-Aldrich) or polymer solutions was drop-casted at 2,000 rpm on the perovskite film. The film was dried at 80<sup>�</sup> C for 30 s. The polymer materials (including poly(vinyl acetate) [PVA, 99.5%, Alfa-Aesar]), polyethylene glycol (PEG, 99.5%, Sigma-Aldrich), and poly(9-vinylcarbazole) (PVK, 99.5%, Alfa-Aesar) were dissolved in CB with different weight concentration. The Spiro-OMeTAD solution (72.3-mg Spiro-OMeTAD [99.8%, Xi’an polymer light technology]) in 1-mL CB with 28-mL 4-tert-butyl pyridine (t-BP, 98%, Sigma-Aldrich) and 17.5-mL lithium bis(trifluoromethanesulfonyl)imide (Li-TFSI, 99.95%, Sigma-Aldrich) (520 mg/mL in acetonitrile (99.8%, Sigma-Aldrich]) was spun onto the perovskite film at 3,000 rpm for 30 s by dropping 25 mL of the solution as a hole conductor. The devices were completed by evaporating 100-nm gold or silver in a vacuum chamber (base pressure, 5 3 10<sup>�5</sup> Pa) at 0.5 A<sup>˚</sup> /s on the top of spiro-MeOTAD layer. The device contact area was 0.12 cm<sup>2</sup> . 

###### Materials characterization 

FTIR spectroscopy was characterized by an FT/IR-6100 (Jasco) under purging with nitrogen gas. Silicon substrates were used for FTIR measurements. The UV-Vis absorption spectra were measured by a U4100 spectrophotometer (Hitachi). XRD was performed in regular q-2q scanning mode using X-ray diffractometer (PANalytical, CuKa1: l = 0.154056 nm) with a scan rate of 4<sup>�</sup> min<sup>�1</sup> . The SEM (Nova Nano 230) and AFM (Bruker dimension fast scan) with peak-force tapping mode using silicon tips (OTESPA, Bruker) were used to characterize the morphology of the perovskite films. The PL signal was recorded using a Horiba Jobin Yvon system, whereas the time-resolved PL decay profiles were measured using a Picoharp 300 with timecorrelated single-photon-counting capabilities. The films were excited using a 640-nm monochromatic pulse laser with a 100-kHz frequency provided by a picosecond laser diode head (PLD 800B, PicoQuant). The XPS was performed on a Thermo Scientific ESCA LAB250Xi system. An Al Ka 1,486.8-eV X-ray radiation source was used for XPS. The perovskite film was coated on the ITO substrate directly and grounded by silver to avoid the charging when measuring. TA was based on a regenerative amplified Ti:Sapphire laser system from coherent (800 nm, 35 fs, 6 mJ/pulse, and 1 kHz repetition rate), nonlinear frequency-mixing techniques and the Helios spectrometer (Ultrafast Systems LLC). All the samples were excited using 370-nm laser source. 

###### Device characterization 

The current density-voltage (J-V) curves of the PSCs were measured by Keithley 2401 source meter with the scanning rate of 0.1 V/s (�0.1 to 1.2 V and �1.2 to �0.1 V), which operated under simulated AM 1.5G illumination (100 mW cm<sup>�2</sup> , Oriel Sol3A, Newport) in ambient atmosphere. The light intensity was calibrated by a standard Si photodiode (NREL-certified, KG-5 filter). The PSCs, without any pre-conditioning-like applied bias voltage or light soaking, were covered with a metal mask (0.1 cm<sup>2</sup> ) to control the active area precisely when measuring. The external quantum efficiency (EQE) was tested by a specially designed system named Enli tech under AC mode (frequency = 133 Hz) without bias light. The steady-state PCE was calculated from stabilized photocurrent density at a constant bias voltage of 0.94, 0.98, 

Joule 6, 1032–1048, May 18, 2022 1045 

**ll** 

Article 

0.96, and 0.94 V for the control, PVA-treated, PEG-treated, and PVK-treated PSCs, respectively. EIS measurements were conducted with an electrochemical workstation (Zennium Zahner, Germany) with a 20-mV amplitude of AC perturbation ranging from 100 mHz to 2 MHz. An array of diodes (Molex 180081-4320) simulating 0.5 sun generated a white light bias, which was used to measure TPC and TPV. A nitrogen laser (LSI VSL-337ND-S) pumped a pulsed red dye laser (Rhodamine 6G, 590 nm) to be the perturbation source with a repetition frequency of 10 Hz and a pulse width of 4 ns. A digital oscilloscope (Tektronix DPO 4104B) was used to record the currents under short-circuit and voltages under open-circuit conditions at a 50 U and over a 1 MU resistor, respectively. 

###### Stability test 

The stability of PSCs was conducted under continuous illumination. The devices (simply encapsulated by epoxy resin and a piece of glass, open-circuit condition) were placed under continuous light, which generated by halogen lamps with an intensity of 90 G 5 mW cm<sup>�2</sup> at ambient conditions (RH: �50%, temperature: 40<sup>�</sup> C). The stabilized PCE was periodically measured under 1-sun illumination at the MPP. The PSCs were placed on a hot plate (85<sup>�</sup> C), which was placed inside a nitrogen glove box to obtain the thermal stability performance. The dark stability was tested in the dark, and the PSCs were removed from the devices for measurement at ambient conditions. The devices were stored in a dry box (room temperature, RH < 30%). 

###### Computational method 

The formation energy for defects, the interaction energy, and the charge distribution were calculated with DFT for the most stable molecular configurations. The DFT in a plane-wave/pseudopotential approach was used, as implemented in the Vienna ab initio simulation package (VASP). Revised Perdew-Burke-Ernzerhof generalized gradient approximation (PBEsol) was described for the exchange-correlation functional. We include dispersion corrections to the final total energies using Grimme’s DFT-D3 scheme. Planewave-type basis sets with a kinetic energy cutoff of 300 eV were used. For geometry optimizations, both ionic positions and cell dimensions were allowed to relax using a conjugate-gradient algorithm until the residual forces become less than 0.02 eV/A<sup>˚</sup> . The surfaces were modeled by a 2 3 2 periodic slab consisting of 9 atomic layers, separated by a �15 A<sup>˚</sup> of vacuum, in the surface normal direction. 4 3 4 3 1 k-mesh for geometry optimizations and a following 8 3 8 3 1 k-mesh single-point energy calculations were used for Brillouin zone (BZ) sampling, centered at the G-point. 

###### SUPPLEMENTAL INFORMATION 

Supplemental information can be found online at https://doi.org/10.1016/j.joule. 2022.04.002. 

###### ACKNOWLEDGMENTS 

M.H. acknowledges financial support from the National Natural Science Foundation of China (NSFC) (12104081) and the help from Dr. Cai (Cai Rui) with c-AFM measurements. J.M. acknowledges financial support from the NSFC (51872036 and 51773025) and the special funds of central government guide local for scientific and technological development (2021JH6/10500152). S.J. thanks the financial support from NSFC (21725305). G.S.H. and J.-W.L. acknowledge financial support from the National Research Foundation of Korea (NRF) grant funded by the Korea Government (MSIT) (2022R1C1C1011975, 2021R1I1A1A01050938) and Korea Institute 

1046 Joule 6, 1032–1048, May 18, 2022 

**ll** 

##### Article 

of Energy Technology Evaluation and Planning (KETEP) grant funded by the Korea Government (MOTIE) (20214000000640 and 20213030010400). This work is also supported by ‘‘Leaders in Industry-university Cooperation+’’ Project, supported by the Ministry of Education and NRF. Computing resources used in this work were provided by the National Center for High Performance Computing of Turkey (UHeM). 

###### AUTHOR CONTRIBUTIONS 

M.H.W. and Y.P.Z. contributed to the paper idea, devices and films preparation, analysis, and paper writing under the supervision of Y.Y. and J.-W.L. X.Q.J. contributed to the suggestions on paper revision and the FITR data. Y.F.Y. contributed to the test and characterization of carrier dynamics. I.Y. contributed to the simulated calculation. P.C.Z., A.N.Z., G.S.H., H.S.J., Y.F.Z., and W.X.Y. contributed to the preparation device and some measuring device. S.Y.J. contributed to the analysis of carrier dynamics. J.M.B. and J.-W.L. contributed to the data analysis. 

###### DECLARATION OF INTERESTS 

The authors declare no competing interests. 

Received: October 7, 2021 Revised: December 17, 2021 Accepted: April 4, 2022 Published: April 29, 2022 

###### REFERENCES 

1. Kim, H.S., Lee, C.R., Im, J.H., Lee, K.B., Moehl, T.C. (2013). Long-range balanced electronT., Marchioro, A., Moon, S.J., Humphry-Baker, and hole-transport lengths in organicR., Yum, J.H., Moser, J.E., et al. (2012). Lead inorganic CH3NH3PbI3. Science 342, 344–347. iodide perovskite sensitized all-solid-state submicron thin film mesoscopic solar cell with 8. Dong, Q.F., Fang, Y.J., Shao, Y.C., Mulligan, P., efficiency exceeding 9%. Sci. Rep. 2, 591. Qiu, J., Cao, L., and Huang, J.S. (2015). 

   8. Dong, Q.F., Fang, Y.J., Shao, Y.C., Mulligan, P., Qiu, J., Cao, L., and Huang, J.S. (2015). Electron-hole diffusion lengths > 175 mm in solution-grown CH3NH3PbI3 single crystals. Science 347, 967–970. 

2. Burschka, J., Pellet, N., Moon, S.J., HumphryBaker, R., Gao, P., Nazeeruddin, M.K., and Gra¨tzel, M. (2013). Sequential deposition as a route to high-performance perovskitesensitized solar cells. Nature 499, 316–319. 

   9. Jung, E.H., Jeon, N.J., Park, E.Y., Moon, C.S., Shin, T.J., Yang, T.Y., Noh, J.H., and Seo, J. (2019). Efficient, stable and scalable perovskite solar cells using poly(3-hexylthiophene). Nature 567, 511–515. 

3. Lee, M.M., Teuscher, J., Miyasaka, T., Murakami, T.N., and Snaith, H.J. (2012). Efficient hybrid solar cells based on mesosuperstructured organometal halide perovskites. Science 338, 643–647. 

   10. Jiang, Q., Zhao, Y., Zhang, X., Yang, X., Chen, Y., Chu, Z., Ye, Q., Li, X., Yin, Z., and You, J. (2019). Surface passivation of perovskite film for efficient solar cells. Nat. Photonics 13, 460–466. 

   11. NREL (2021). Best research-cell efficiencies. https://www.nrel.gov/pv/cell-efficiency.html. 

4. Yang, W.S., Noh, J.H., Jeon, N.J., Kim, Y.C., Ryu, S., Seo, J., and Seok, S.I. (2015). SOLAR CELLS. High-performance photovoltaic perovskite layers fabricated through intramolecular exchange. Science 348, 1234–1237. 

   12. Kim, J.Y., Lee, J.W., Jung, H.S., Shin, H., and Park, N.G. (2020). High-efficiency perovskite solar cells. Chem. Rev. 120, 7867–7918. 

5. Ahn, N., Son, D.Y., Jang, I.H., Kang, S.M., Choi, M., and Park, N.G. (2015). Highly reproducible perovskite solar cells with average efficiency of 18.3% and best efficiency of 19.7% fabricated via Lewis base adduct of lead (II). J. Am. Chem. Soc. 137, 8696–8699. 

   13. Kim, G., Min, H., Lee, K.S., Lee, D.Y., Yoon, S.M., and Seok, S.I. (2020). Impact of strain relaxation on performance of alphaformamidinium lead iodide perovskite solar cells. Science 370, 108–112. 

6. Zhao, Y., Zhu, P., Wang, M., Huang, S., Zhao, Z., Tan, S., Han, T.H., Lee, J.W., Huang, T., Wang, R., et al. (2020). A polymerization-assisted grain growth strategy for efficient and stable perovskite solar cells. Adv. Mater. 32, e1907769. [Pubmed: 32147861]. 

   14. Yoo, J.J., Seo, G., Chua, M.R., Park, T.G., Lu, Y., Rotermund, F., Kim, Y.K., Moon, C.S., Jeon, N.J., Correa-Baena, J.P., et al. (2021). Efficient perovskite solar cells via improved carrier management. Nature 590, 587–593. 

7. Xing, G.C., Mathews, N., Sun, S.Y., Lim, S.S., Lam, Y.M., Gra¨tzel, M., Mhaisalkar, S., and Sum, 

15. Deng, Y., Peng, E., Shao, Y., Xiao, Z., Dong, Q., and Huang, J. (2015). Scalable fabrication of 

efficient organolead trihalide perovskite solar cells with doctor-bladed active layers. Energy Environ. Sci. 8, 1544–1550. 

16. Ko, H.-S., Lee, J.-W., and Park, N.-G. (2015). % Efficiency perovskite solar cells prepared under high relative humidity: importance of PbI2 morphology in two-step deposition of CH3NH3PbI3. J. Mater. Chem. A 3, 8808–8815. 

17. De Bastiani, M., Dell’Erba, G., Gandini, M., D’Innocenzo, V., Neutzner, S., Kandada, A.R.S., Grancini, G., Binda, M., Prato, M., Ball, J.M., et al. (2016). Ion migration and the role of preconditioning cycles in the stabilization of the J-V characteristics of inverted hybrid perovskite solar cells. Adv. Energy Mater. 6. [Pubmed: 1501453]. 

18. Ni, Z., Bao, C., Liu, Y., Jiang, Q., Wu, W.Q., Chen, S., Dai, X., Chen, B., Hartweg, B., Yu, Z., et al. (2020). Resolving spatial and energetic distributions of trap states in metal halide perovskite solar cells. Science 367, 1352–1358. 

19. Zhu, H., Liu, Y., Eickemeyer, F.T., Pan, L., Ren, D., Ruiz-Preciado, M.A., Carlsen, B., Yang, B., Dong, X., Wang, Z., et al. (2020). Tailored amphiphilic molecular mitigators for stable perovskite solar cells with 23.5% efficiency. Adv. Mater. 32, e1907757. [Pubmed: 32068922]. 

20. Wang, S., Chen, H., Zhang, J., Xu, G., Chen, W., Xue, R., Zhang, M., Li, Y., and Li, Y. (2019). Targeted therapy for interfacial engineering toward stable and efficient perovskite solar cells. Adv. Mater. 31, e1903691. [Pubmed: 31456294]. 

Joule 6, 1032–1048, May 18, 2022 1047 

#### **ll** 

##### Article 

21. Liang, L., Luo, H., Hu, J., Li, H., and Gao, P. (2020). Efficient perovskite solar cells by reducing interface-mediated recombination: a bulky amine approach. Adv. Energy Mater. 10, 2000197. [Pubmed: 2000197]. 

22. Yang, Y., Yang, M., Moore, D.T., Yan, Y., Miller, E.M., Zhu, K., and Beard, M.C. (2017). Top and bottom surfaces limit carrier lifetime in lead iodide perovskite films. Nat. Energy 2, 16207. 

23. Eames, C., Frost, J.M., Barnes, P.R., O’Regan, B.C., Walsh, A., and Islam, M.S. (2015). Ionic transport in hybrid lead iodide perovskite solar cells. Nat. Commun. 6, 7497. 

24. Domanski, K., Roose, B., Matsui, T., Saliba, M., Turren-Cruz, S., Correa-Baena, J., Carmona, C.R., Richardson, G., Foster, J.M., De Angelis, F.D., et al. (2017). Migration of cations induces reversible performance losses over day/night cycling in perovskite solar cells. Energy Environ. Sci. 10, 604–613. 

25. Wang, R., Xue, J., Wang, K.L., Wang, Z.K., Luo, Y., Fenning, D., Xu, G., Nuryyeva, S., Huang, T., Zhao, Y., et al. (2019). Constructive molecular configurations for surface-defect passivation of perovskite photovoltaics. Science 366, 1509– 1513. 

26. Han, T.H., Tan, S., Xue, J., Meng, L., Lee, J.W., and Yang, Y. (2019). Interface and defect engineering for metal halide perovskite optoelectronic devices. Adv. Mater. 31, e1803515. [Pubmed: 30761623]. 

27. Kim, H., Lee, S.U., Lee, D.Y., Paik, M.J., Na, H., Lee, J., and Seok, S.I. (2019). Optimal interfacial engineering with different length of alkylammonium halide for efficient and stable perovskite solar cells. Adv. Energy Mater. 9, 1902740. [Pubmed: 1902740]. 

28. Wang, M., Tan, S., Zhao, Y., Zhu, P., Yin, Y., Feng, Y., Huang, T., Xue, J., Wang, R., Han, G.S., et al. (2021). Stable and efficient methylammonium-, cesium-, and bromide-free perovskite solar cells by in-situ interlayer formation. Adv. Funct. Mater. 31, 2007520. [Pubmed: 2007520]. 

29. Tan, F., Tan, H., Saidaminov, M.I., Wei, M., Liu, M., Mei, A., Li, P., Zhang, B., Tan, C.S., Gong, X., et al. (2019). In situ back-contact passivation improves photovoltage and fill factor in perovskite solar cells. Adv. Mater. 31, e1807435. [Pubmed: 30740780]. 

30. Li, F., Yuan, J., Ling, X., Zhang, Y., Yang, Y., Cheung, S.H., Ho, C.H.Y., Gao, X., and Ma, W. (2018). A universal strategy to utilize polymeric 

   - semiconductors for perovskite solar cells with enhanced efficiency and longevity. Adv. Funct. Mater. 28, 1706377. [Pubmed: 1706377]. 

31. Ferdowsi, P., Ochoa-Martinez, E., Alonso, S.S., Steiner, U., and Saliba, M. (2020). Ultrathin polymeric films for interfacial passivation in wide band-gap perovskite solar cells. Sci. Rep. 10, 22260. 

32. Han, T.H., Lee, J.W., Choi, C., Tan, S., Lee, C., Zhao, Y., Dai, Z., De Marco, N.D., Lee, S.J., Bae, S.H., et al. (2019). Perovskite-polymer composite cross-linker approach for highlystable and efficient perovskite solar cells. Nat. Commun. 10, 520. 

33. Walsh, A., Scanlon, D.O., Chen, S., Gong, X., and Wei, S.H. (2015). Self-regulation mechanism for charged point defects in hybrid halide perovskites. Angew. Chem. 127, 1811– 1814. 

34. Tan, S., Yavuz, I., Weber, M.H., Huang, T., Chen, C., Wang, R., Wang, H., Ko, J.H., Nuryyeva, S., Xue, J., et al. (2020). Shallow iodine defects accelerate the degradation of alpha-phase formamidinium perovskite. Joule 4, 2426–2442. 

35. Zhao, Y., Zhu, P., Huang, S., Tan, S., Wang, M., Wang, R., Xue, J., Han, T.H., Lee, S.J., Zhang, A., et al. (2020). Molecular interaction regulates the performance and longevity of defect passivation for metal halide perovskite solar cells. J. Am. Chem. Soc. 142, 20071–20079. 

36. Kang, D.-H., Kim, S.-Y., Lee, J.-W., and Park, N.-G. (2021). Efficient surface passivation of perovskite films by a post-treatment method with a minimal dose. J. Mater. Chem. A 9, 3441–3450. 

37. Wu, K., Liang, G., Shang, Q., Ren, Y., Kong, D., and Lian, T. (2015). Ultrafast interfacial electron and hole transfer from CsPbBr3 perovskite quantum dots. J. Am. Chem. Soc. 137, 12792– 12795. 

38. Yin, Z., Leng, J., Wang, S., Liang, G., Tian, W., Wu, K., and Jin, S. (2021). Auger-assisted electron transfer between adjacent quantum wells in two-dimensional layered perovskites. J. Am. Chem. Soc. 143, 4725–4731. 

39. Dane, W., Susanne, K., Sven, B., Rajan, K.P., Alfred, J.S., Mark, E.Z., and David, S.G. (2016). Photoluminescence lifetimes exceeding 8 ms and quantum yields exceeding 30% in hybrid perovskite thin films by ligand passivation. ACS Energy Lett. 1, 438–444. 

40. Yin, Y., Tian, W., Leng, J., Bian, J., and Jin, S. (2020). Carrier transport limited by trap state in Cs2AgBiBr6 double perovskites. J. Phys. Chem. Lett. 11, 6956–6963. 

41. Guo, Z., Manser, J.S., Wan, Y., Kamat, P.V., and Huang, L. (2015). Spatial and temporal imaging of long-range charge transport in perovskite thin films by ultrafast microscopy. Nat. Commun. 6, 7471. 

42. Sun, Q., Yin, Z., Wang, S., Zhao, C., Leng, J., Tian, W., and Jin, S. (2020). Long-range exciton transport in perovskite-metal organic framework solid composites. J. Phys. Chem. Lett. 11, 9045–9050. 

43. Chen, W., Castro, J., Ahn, S., Li, X., and Vazquez-Mena, O. (2019). Improved charge extraction beyond diffusion length by layer-bylayer multistacking intercalation of graphene layers inside quantum dots films. Adv. Mater. 31, e1807894. [Pubmed: 30761634]. 

44. Wu, F., Shen, W., Cui, Q., Bi, D., Yue, W., Qu, Q., and Wang, M. (2010). Dynamic characterization of hybrid solar cells based on polymer and aligned ZnO nanorods by intensity modulated photocurrent spectroscopy. J. Phys. Chem. C 114, 20225– 20235. 

45. Jung, K.-H., Seo, J.-Y., Lee, S., Shin, H., and Park, N.-G. (2017). Solution-processed SnO2 thin film for a hysteresis-free planar perovskite solar cell with a power conversion efficiency of 19.2%. J. Mater. Chem. A 5, 24790–24803. 

46. Jiang, X., Wang, D., Yu, Z., Ma, W., Li, H.B., Yang, X., Liu, F., Hagfeldt, A., and Sun, L. (2019). Molecular engineering of copper phthalocyanines: a strategy in developing dopant-free hole-transporting materials for efficient and ambient-stable perovskite solar cells. Adv. Energy Mater. 9, 1803287. [Pubmed: 1803287]. 

47. Lee, J.-W., Bae, S.-H., Hsieh, Y.-T., De Marco, N.D., Wang, M., Sun, P., and Yang, Y. (2017). A bifunctional Lewis base additive for microscopic homogeneity in perovskite solar cells. Chem 3, 290–302. 

48. Lee, J.W., Dai, Z., Lee, C., Lee, H.M., Han, T.H., De Marco, N.D., Lin, O., Choi, C.S., Dunn, B., Koh, J., et al. (2018). Tuning molecular interactions for highly reproducible and efficient formamidinium perovskite solar cells via adduct approach. J. Am. Chem. Soc. 140, 6317–6324. 

1048 Joule 6, 1032–1048, May 18, 2022 

