# Qubits made by advanced semiconductor manufacturing

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Electronics |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 392 |
| 作者 | A. Zwerver, T. Krähenmann, T. Watson, L. Lampert, H. George, R. Pillarisetty, S. Bojarski, P. Amin et al. |
| DOI | 10.1038/s41928-022-00727-9 |
| 源文件 | 030_Zwerver_2021_Qubits-made-by-advanced-semiconductor-manufactur.pdf |

---
**Qubits made by advanced semiconductor manufacturing** 

A.M.J. Zwerver<sup>1</sup> , T. Kr¨ahenmann<sup>1</sup> , T.F. Watson<sup>2</sup> , L. Lampert<sup>2</sup> , H.C. George<sup>2</sup> , R. Pillarisetty<sup>2</sup> , S.A. Bojarski<sup>2</sup> , P. Amin<sup>2</sup> , S.V. Amitonov<sup>1</sup> , J.M. Boter<sup>1</sup> , R. Caudillo<sup>2</sup> , D. Corras-Serrano<sup>2</sup> , J.P. Dehollain<sup>1</sup> , G. Droulers<sup>1</sup> , E.M. Henry<sup>2</sup> , R. Kotlyar<sup>2</sup> , M. Lodari<sup>1</sup> , F. Luthi<sup>2</sup> , D.J. Michalak<sup>2</sup> , B.K. Mueller<sup>2</sup> , S. Neyens<sup>2</sup> , J. Roberts<sup>2</sup> , N. Samkharadze<sup>1</sup> , G. Zheng<sup>1</sup> , O.K. Zietz<sup>2</sup> , G. Scappucci<sup>1</sup> , M. Veldhorst<sup>1</sup> , L.M.K. Vandersypen<sup>1</sup><sup>_,∗_</sup> , J.S. Clarke<sup>2</sup><sup>_,∗_</sup> (Dated: February 1, 2021) 

> 1 _QuTech and Kavli Institute of Nanoscience, Delft University of Technology, 2600 GA Delft, The Netherlands_ 

> 2 _Intel Components Research, Intel Corporation, 2501 NW 229th Avenue, Hillsboro, OR, USA_ 

> _∗_ Corresponding authors: l.m.k.vandersypen@tudelft.nl; james.s.clarke@intel.com 

Full-scale quantum computers require the integration of millions of quantum bits [1, 2]. The promise of leveraging industrial semiconductor manufacturing to meet this requirement has fueled the pursuit of quantum computing in silicon quantum dots. However, to date, their fabrication has relied on electron-beam lithography [3–14] and, with few exceptions [4, 7, 14], on academic style lift-off processes. Although these fabrication techniques offer process flexibility, they suffer from low yield and poor uniformity. An important question is whether the processing conditions developed in the manufacturing fab environment to enable high yield, throughput, and uniformity of transistors are suitable for quantum dot arrays and do not compromise the delicate qubit properties. Here, we demonstrate quantum dots hosted at a<sup>28</sup> Si/<sup>28</sup> SiO2 interface, fabricated in a 300 mm semiconductor manufacturing facility using all-optical lithography and fully industrial processing [15]. As a result, we achieve nanoscale gate patterns with remarkable homogeneity. The quantum dots are wellbehaved in the multi-electron regime, with excellent tunnel barrier control, a crucial feature for faulttolerant two-qubit gates. Single-spin qubit operation using magnetic resonance reveals relaxation times of over 1 s at 1 Tesla and coherence times of over 3 ms, matching the quality of silicon spin qubits reported to date [3–13]. The feasibility of high-quality qubits made with fully-industrial techniques strongly enhances the prospects of a large-scale quantum computer. 

The idea of exploiting quantum mechanics to build computers with computational powers beyond the abilities of any classical device has gathered momentum since the 1980’s [16]. However, in order for full-fledged quantum computers to become a reality, they need to be fault-tolerant, i.e. errors from unavoidable decoherence must be reversed faster than they occur [1]. The most promising architectures require a scalable qubit system of individually-addressable qubits with a gate fidelity over 99% and tunable nearest-neighbour couplings [17, 18]. 

Spin qubits in gate-defined quantum dots (QDs) offer great potential for quantum computation due to their small size and relatively long coherence times [19–21]. Single-qubit gate fidelities over 99.9% [9, 22] as well as two-qubit gates [8, 11, 23–25], algorithms [10], conditional teleportation [26], three-qubit entanglement [27] and four-qubit universal control [28] have already been demonstrated. Moreover, silicon spin qubits have been operated at relatively high temperatures of 1-4 K [6, 29], where the higher cooling power enables scaling strategies with integration of control electronics [30–34]. 

A major advantage of silicon spin qubits is that they could leverage decades of technology development in the semiconductor industry. Today, industry is able to make uniform transistors with gate lengths of several tens of nanometers and spaced apart by 34 nm (fins) to 54 nm (gates), feature sizes that are well below the 193 nm wavelength of the light used in the lithography process [35]. This engineering feat and the high yield that 

allows integrated circuits containing billions of transistors to function, are enabled by adhering to strict design rules and by advanced semiconductor manufacturing techniques such as multiple patterning for pitch doubling, subtractive processing, chemically-selective plasma etches, and chemical mechanical polishing (CMP) [36]. While these processing conditions are more intrusive than the metal lift-off processing conditions typically used on academic devices, they will be key to achieving the extremely high yield necessary for the fabrication of thousands or millions of qubits in a functional array. 

A quantum dot device bears a strong similarity to a transistor, taken to the limit where the gate above the channel controls the flow of electrons one at a time [37]. In linear qubit arrays, the transistor gate is replaced by multiple gates, used to shape the potential landscape of the channel into multiple potential minima (quantum dots), to control the occupation of each dot down to the last electron, and to precisely tune the wavefunction overlap (tunnel coupling) of electrons in neighbouring dots [38]. In addition, qubit devices commonly rely on integrated nearby charge sensors to enable single-shot spin readout and high-fidelity initialisation [21, 39]. A first key question is then whether the reliable but strict design rules of industrial patterning can produce suitable qubit device layouts. A separate consideration is that qubit coherence is easily affected by microscopic charge fluctuations from interface, surface and bulk defects. Therefore, a second key question is whether the coherence proper- 

2 

ties of the qubits survive the processing conditions needed to achieve high yield and uniformity. Although the first qubits in quantum dots fabricated on wafer-scale in industrial foundries have been presented [4, 40], they rely on electron-beam lithography and avoid CMP for the active device area. CMP requires a uniform metal density across the wafer, which introduces its own complexities for quantum dot devices, due to the large amount of floating metal and added capacitance. 

In this letter, we demonstrate optically-patterned quantum dots and qubits, made in a state-of-the-art 300 mm wafer process line, similar to those used for commercial advanced integrated circuits. 

A dedicated mask set based on 193 nm immersion lithography is created for patterning quantum dot arrays of various lengths, as well as a number of test structures, such as transistors of various sizes and Hall bars. These test structures allow us to directly extract important metrics at both room temperature and low temperature such as mobility, threshold voltage, subthreshold slope and interface trap density. Analysed together, these metrics give us understanding of the gate oxide and contact quality along with the electrostatics to help troubleshoot process targeting [15]. 

As in current complementary metal-oxidesemiconductor (CMOS) transistors, the active region of these quantum dot devices consists of a fin etched out of the silicon substrate [35]. Nested top-gates with a pitch of 50 nm, separated from the fin by a composite SiO2/high-k dielectric, are used to form and manipulate quantum dots. Figure 1a shows a high-angle annular dark-field scanning transmission electron microscopy (HAADF-STEM) image of the active device area. A cross-section transmission electron microscopy (TEM) image along a fin with quantum dot gates is shown in Fig. 1b. N-type ion implants on both ends of the fin, well separated from the active region, serve as Ohmic contacts to the fins. We pattern two such linear quantum dot arrays, separated by 100 nm (see Fig. 1c for a TEM image across both fins). In our experiments, we use a quantum dot in one array as a charge sensor for the quantum dots and qubits in the other array. A 3D device schematic is shown in Fig. 1d. 

The process flow starts from a conventional transistor flow but is adapted to fabricate two sets of gates in successive steps using a combination of 300 mm optical lithography, thin film deposition, plasma etch, and chemical mechanical polish processes. The main steps are illustrated in Fig. 1e. First, the fins are defined in a Si substrate. The area between the fins is filled in with a shallow trench isolation dielectric material and polished. The first gate layer (with even numbers) is defined using an industry standard replacement metal gate process [41– 43] and the second gate layer (with odd numbers) is then formed adjacent to the first gate layer. Finally, a contact layer is patterned to enable routing to bond pads, as well as ohmic and gate contacts. In the devices intended for coherent experiments (discussed in Fig. 4), a 

metal wire that shunts a coplanar stripline (connected to an on-chip coplanar waveguide) is placed parallel to the fins in the contact layer (Extended Data Fig. 2). The samples used only for quantum dot formation are fabricated on natural silicon substrates, whereas the samples used for qubit readout and manipulation are fabricated on an isotopically enriched<sup>28</sup> Si epilayer with a residual 29Si concentration of 800 ppm [44]. This reduces the hyperfine interaction of the qubits with nuclear spins in the host material and thus increases the qubit coherence [20]. 

A single 300 mm wafer contains more than 10 _,_ 000 quantum dot arrays of various lengths, with up to 55 gates per fin. The impact of the industrial fabrication is immediately clear when we compare the TEM image of a 7-gate device in Fig. 1b to a TEM image of an academic Si-MOS device (see Extended Data Fig. 1); the gate uniformity is remarkable and there are no traces of residual metallic pieces. This uniformity is reflected in e.g. the threshold voltage of individual gates within quantum dot arrays, as well as across quantum dot arrays throughout the wafer, measured at room temperature (see Extended Data Fig. 3). 

All quantum dot and qubit measurements are carried out in a dilution refrigerator, operated at base temperature. The measurements have been performed on a plethora of different devices from different process flow generations, measured in three different dilution refrigerators in different laboratories. Samples of the same generation taken from anywhere across the wafer show very reproducible quantum dot behaviour. 

We form quantum dots by tuning the gates individually to define a suitable potential landscape (dots can be controllably formed below any of the inner 5 gates). Figure 2a shows a typical result, where we measure the current through a QD while sweeping three gate voltages, one of which mostly controls the electrochemical potential (labeled G3 in Fig. 1b) of the quantum dot and the others (G2 and G4) mostly control the tunnel barriers. Starting at a G3 gate voltage of 3.9 V, we count more than 80 lines, known as Coulomb peaks, separating regions with a stable number of electrons on the QD. This number is changed by exactly one when passing a Coulomb peak. While the Coulomb peaks are parallel and evenly spaced at a high G3 voltage ( _>_ 3 V), they become irregular and also further separated towards the few-electron regime (around 1.5 V on G3). Such irregular behaviour is characteristic of Si-MOS devices, due to their close proximity to the dielectric interface [3– 7, 14, 23, 24]. 

Analysing these first-generation dots through so-called Coulomb diamonds [39], gives an average charging energy of 8 _._ 4 _±_ 0 _._ 2 meV (all error bars are 1 _σ_ from the mean) per dot in the multi-electron regime (see Extended Data Fig. 4). This indicates the dot diameter to be on the order of 45 nm, which is about the width of a single gate. Next, we measure charge noise in the multi-electron regime, by measuring the current fluctuations at a fixed gate voltage, on the flank of a Coulomb peak. The power 

3 

spectral density shows a 1/ _f_ slope that is characteristic of charge noise in solid-state devices [45]. The charge noise amplitude is in the range of 1 _−_ 10 _µ_ eV/ _~~√~~_ Hz at 1 Hz, with some variation between Coulomb peaks (Fig. 2b). These are common charge noise values in Si-MOS QD samples [5]. 

Figure 2c shows the transport through a double QD as a function of the gate voltages that (mostly) control the electrochemical potential of each dot, G3 and G5. Characteristic points of conductance are measured, socalled triple points. At these points, the electrochemical potentials of the reservoirs are aligned with the electrochemical potentials of the left and the right dot, such that electrons can tunnel sequentially through the two dots [38]. Increasing the voltage applied to the intermediate gate G4 is expected to lower the tunnel barrier between the dots, eventually reaching the point where one large dot is formed. This behaviour is seen in Figs. 2c-f, as the gradual transition from triple points to single, parallel and evenly spaced Coulomb peaks. This shows the tunability of the interdot tunnel coupling in this double dot, which is advantageous for two-qubit control in such a system [6, 11, 27, 34]. 

In a next step, we use a QD in one fin as a charge sensor for the charge occupation of the QDs in the other fin. This allows us to unambiguously map the charge states of the qubit dots down to the last electron [39]. A characteristic charge stability diagram showing the last electron transition is shown in Fig. 3a. The current through the sensor is measured as a function of the voltage on two gates controlling the qubit dot. In the few-electron regime, we can usually distinguish lines with several different slopes, indicating the formation of additional, spurious dots next to the intended dot. However, we consistently are able to find a clean region in the charge stability diagram with an isolated addition line corresponding to the last electron. Several iterations of geometry and material changes improved the charge sensing by orders of magnitude, resulting in a sensing step of about 500 pA for a source-drain voltage of 500 _µ_ V. This allows singleshot readout of the spin of a single electron by means of spin-dependent tunneling and real-time charge detection (Fig. 3c) [46]. 

In order to define a qubit via the electron spin states, we apply a magnetic field in the [100]-direction, parallel to the fins, separating the spin-up and spin-down levels in energy. We apply a three-stage pulse to gate G6 to measure the spin relaxation time, _T_ 1 [46]. We find _T_ 1 exceeding 1 s at a magnetic field of 1 Tesla (Fig. 3b). This long _T_ 1 is comparable to those reported previously for silicon quantum dots [5, 6] and indicates that the more complicated processing conditions of the 300 mmscale fabrication do not degrade the spin relaxation time. Upon measuring _T_ 1 as a function of magnetic field, we find a striking, non-monotonic dependence, which is well described in the literature and the result of the valley structure in the conduction band of silicon. Following [5, 47], we fit the magnetic field dependence of the spin 

relaxation rate (1 _/T_ 1) with a model including the effect of Johnson noise and phonons inducing spin transitions mediated by spin-orbit coupling, and taking into account the lowest four valley states (Fig. 3d). The peak in the relaxation rate around 2 _._ 25 T corresponds to the situation where the Zeeman energy equals the valley splitting energy, from which we extract a valley splitting of 260 _±_ 2 _µ_ eV, well above the thermal energy and qubit splitting in this system. 

To coherently control the spin states, we apply an ac current to the stripline in order to generate an oscillating magnetic field at the QD [48]. Electron spin resonance occurs when the driving frequency matches the spin Larmor frequency of _f_ = 17 _._ 1 GHz, which is set by the static magnetic field at the dot. By pulsing the spin-down level below the Fermi reservoir, we load the QD with a spindown electron. We then pulse deep in the Coulomb blockade regime to manipulate the spin with microwave bursts. Finally, we pulse to the readout point and perform spindependent tunneling readout. The spin-up probability as a function of microwave burst duration shows clear Rabi oscillations, (Fig. 4a). We have studied Rabi oscillations in three devices; the main figures show data for qubit 1 (Q1) and the Extended figures (11, 12 and 13) show data for qubit 2 (Q2), formed on the same device, and qubit 3. As expected, the Rabi frequency is linear in the driving amplitude, reaching up to about 900 kHz for Q2. 

The spin dephasing time _T_ 2<sup>_∗_ismeasuredthrougha</sup> Ramsey interference measurement (see Extended Data Fig. 8). Fitting this Ramsey pattern with a Gaussiandamped oscillation, yields a decay time of _T_ 2<sup>_∗_= 24</sup><sup>_±_6</sup><sup>_µs_</sup> when averaging data over 100 s (the error bar here refers to the statistical variation between 41 post-selected repetitions of 100 s segments). As we repeat such Ramsey measurements, we observe slow jumps in the qubit frequency. Averaging the free induction decay over 2 hours and 40 minutes still gives a _T_ 2<sup>_∗_of11</sup><sup>_±_2</sup><sup>_µs_,seeMethods</sup> section for more details. 

To analyse the single-qubit gate fidelity, we employ randomised benchmarking [49] (Extended Fig. 10). A number, _m_ , of random Clifford gates is applied to the qubit, followed by a gate that ideally returns the spin to either the spin-up or spin-down state. In reality, the probability to reach the target state decays with _m_ due to imperfections. The standard analysis gives a single-qubit gate fidelity of 99 _._ 0% for Q1 and 99 _._ 1% for Q2. With the Rabi decay being dominated by low-frequency noise, the present combination of _T_ 2<sup>_∗_andRabifrequencyshould</sup> allow an even higher fidelity [6, 23, 29]. We suspect the single-qubit gate fidelity to be limited by improper calibration. Nonetheless, the fidelity is already around the fault-tolerant threshold for the surface code [18]. 

Finally, we study the limits of spin coherence by performing dynamical decoupling by means of Carr-PurcellMeiboom-Gill (CPMG) sequences (see Fig. 4b for the coherence decay using 50 pulses). These sequences eliminate the effect from quasi-static noise sources. Figure 4c shows the normalised amplitude of the CPMG decay as 

4 

a function of evolution time for different numbers of _π_ - pulses, _n_ . By fitting these curves we extract _T_ 2<sup>CPMG</sup> ( _n_ ). We use a Gaussian decay envelope which yields distinctly better agreement than an exponential decay. The _T_ 2<sup>CPMG</sup> times are plotted as a function of _n_ in Fig. 4d. We obtain a _T_ 2<sup>CPMG</sup> of over 3 _._ 5 ms for _n_ = 50 CPMG pulses, more than 100 times larger than _T_ 2<sup>_∗_,withroomforfur-</sup> ther increases through additional decoupling pulses. The CPMG data for Q1 is consistent with charge noise as the limiting mechanism (see Methods). For Q2, an additional noise mechanism is likely present. Again, all the decay timescales are comparable to the results reported earlier for<sup>28</sup> Si-MOS devices [3–7, 23]. 

In summary, despite the industrial processing conditions used to fabricate the qubit samples, key performance indicators such as charge noise, the charge sensing signal, _T_ 1, _T_ 2<sup>_∗_and</sup><sup>_T_CPMG</sup> 2 , are already state-of-the-art. The formation of easily tunable double dots bodes well for the implementation of two-qubit gates in this system. Several further improvements are possible. First, the ESR stripline can be redesigned to lower resistance and dissipation by increasing the trace width up to the short and using lower resistivity materials. Furthermore, bringing the quantum dots on the inside of the stripline [48] will increase the ratio of magnetic field and (unwanted) electric fields and heating. Finally, spurious dots in the few electron regime and two-level systems can be removed by reducing the presence of material charge defects [50, 51]. While growth conditions for high-quality Si/dielectric interfaces have been identified, performancelimiting defects can be formed through downstream processing. Further work is ongoing to optimise the process flow and recipes (temperature budget, plasma conditions, chemical exposure, and annealing conditions) to reduce defects at the end of line. 

These fabrication methods can be adapted to allow for 2D quantum dot arrays as well. Moreover, these processing steps are by default integratable with any other CMOS technology, which opens up the potential to integrate classical circuits next to the qubit chip. Eventually, industrial processing has the potential to achieve the very high quantum dot uniformity that would enable crossbar addressing schemes [32]. The compatibility of silicon spin qubits with fully-industrial processing demonstrated here, highlights their potential for scaling and for realising a fault-tolerant full-stack quantum computer. 

5 



<!-- Start of picture text -->
a c d<br>Silicon Fins<br>Spin Qubits e<br>Charge Sensors<br>Gate Routing<br>Dummification<br>b<br>ACL G1 G2 G3 G4 G5 G6 G7 ACR<br><!-- End of picture text -->

FIG. 1. **Industrially fabricated quantum dot devices. a,** HAADF-STEM image of a typical device. The active region consists of two parallel fins; one hosts the qubits and the other hosts the sensing dot. The fan-out of the gates is clearly visible, as are many additional metallic structures (called dummification) needed to maintain a roughly constant density of metal on the surface, which ensures homogeneous polishing on a wafer scale. **b,** TEM image along a Si fin, showing 7 finger gates to define the quantum dot array and two accumulation gates to induce reservoirs connecting to the n-type implants that serve as Ohmic contacts (outside the image). **c,** False-coloured TEM image perpendicular to the Si fins, showing the fins and the gates on top. **d,** Schematic of the active region of the device. **e,** Schematic of the process steps used to fabricate the devices as explained in the main text. 

6 



<!-- Start of picture text -->
a b<br>c d e f<br><!-- End of picture text -->

FIG. 2. **Tunable single and double quantum dots a,** Charge stability diagram for a single QD measured via electron transport. **b,** Coulomb blockade peaks in the multielectron regime (orange line) and the power spectral density at 1 Hz of the quantum dot potential fluctuations measured at the flank of each peak (purple dots). **c-f,** Charge stability diagrams of a double quantum dot formed under gates G3 and G5. The gate voltage on G4 is gradually increased (G4 is 1245, 1308, 1353 and 1398 mV from **c** to **f** ), showing good control over the interdot tunnel coupling. 

7 



<!-- Start of picture text -->
a b<br>e r w<br>c d<br><!-- End of picture text -->



FIG. 3. **Charge sensing and single-shot spin readout. a,** Charge stability diagram of the last-electron regime of a QD, measured with a sensing dot in the other fin. The points w, r and e refer to the wait, readout and empty stages of the gate voltage pulse. **b,** Spin-up probability as a function of load time at a magnetic field of 1 T. The exponential fit yields a _T_ 1 of 1 _._ 6 _±_ 0 _._ 6 s. **c,** Real-time current through the sensing dot indicating a spin-up (purple line) and spin-down (orange line) electron, recorded with a measurement bandwidth of 3 kHz set by an external low-pass filter. **d,** Relaxation rate (1 _/T_ 1) as a function of the applied magnetic field (purple dots). The relaxation rate is fitted by a model (orange line) that includes the effect of Johnson noise and phonons coupling to the spin via spin-orbit interaction. From this fit, we extract a valley splitting of _Ev_ = 260 _±_ 2 _µ_ eV. 

8 



<!-- Start of picture text -->
a b<br>c d<br><!-- End of picture text -->

FIG. 4. **An industrial silicon spin qubit a,** Rabi oscillations of the measured spin-up probability as a function of microwave burst duration. **b,** CPMG experiment, the measured spin-up probability as a function of the free evolution time separating 50 _π_ pulses, with artificial detuning. The data is fitted with _A_ (cos( _ωt_ + _φ_ )+ _B_ ) exp( _−_ ( _t/T_ 2<sup>CPMG</sup> )<sup>2</sup> )+ _C_ . The fitted CPMG coherence time _T_ 2<sup>CPMG</sup> is 3.7 _±_ 0 _._ 2 ms. **c,** Demodulated and normalised CPMG amplitude as a function of the total evolution time for different numbers _n_ of _π_ -pulses. **d,** Measured coherence time _T_ 2<sup>CPMG</sup> for different numbers of CPMG _π_ pulses. The orange line represents a fit through the data (excluding _n_ = 1) following _T_ 2<sup>CPMG</sup> _∝ n_<sup>(</sup><sup>_γ/_(</sup><sup>_γ_+1))</sup> . We extract _γ_ = 1 _._ 1 _±_ 0 _._ 2. 

9 

- [1] Campbell, E. T., Terhal, B. M. & Vuillot, C. Roads towards fault-tolerant universal quantum computation. _Nature_ **549** , 172–179 (2017). 

- [2] Wecker, D., Bauer, B., Clark, B. K., Hastings, M. B. & Troyer, M. Gate-count estimates for performing quantum chemistry on small quantum computers. _Phys. Rev. A_ **90** , 022305 (2014). 

- [3] Veldhorst, M. _et al._ An addressable quantum dot qubit with fault-tolerant control-fidelity. _Nat. Nanotechnol._ **9** , 981–985 (2014). 

- [4] Maurand, R. _et al._ A CMOS silicon spin qubit. _Nat. Commun._ **7** , 13575 (2016). 

- [5] Petit, L. _et al._ Spin lifetime and charge noise in hot silicon quantum dot qubits. _Phys. Rev. Lett._ **121** , 076801 (2018). 

- [6] Yang, C. H. _et al._ Operation of a silicon quantum processor unit cell above one kelvin. _Nature_ **580** , 350–354 (2020). 

- [7] Harvey-Collard, P. _et al._ Spin-orbit interactions for singlet-triplet qubits in silicon. _Phys. Rev. Lett._ **122** , 217702 (2019). 

- [8] Xue, X. _et al._ Benchmarking gate fidelities in a Si/SiGe two-qubit device. _Phys. Rev. X_ **9** , 021011 (2019). 

- [9] Yoneda, J. _et al._ A quantum-dot spin qubit with coherence limited by charge noise and fidelity higher than 99.9%. _Nat. Nanotechnol._ **13** , 102–106 (2018). 

- [10] Watson, T. F. _et al._ A programmable two-qubit quantum processor in silicon. _Nature_ **555** , 633–637 (2018). 

- [11] Zajac, D. M. _et al._ Resonantly driven CNOT gate for electron spins. _Science_ **359** , 439–442 (2018). 

- [12] Andrews, R. W. Quantifying error and leakage in an encoded Si/SiGe triple-dot qubit. _Nat. Nanotechnol._ **14** , 5 (2019). 

- [13] Wu, X. _et al._ Two-axis control of a singlet-triplet qubit with an integrated micromagnet. _Proc. Natl. Acad. Sci. USA_ **111** , 11938–11942 (2014). 

- [14] Li, R. _et al._ A flexible 300 mm integrated Si MOS platform for electron- and hole-spin qubits exploration. _In International Electron Devices Meeting_ 38.3.1–38.3.4 (IEEE, 2020). 

- [15] Pillarisetty, R. _et al._ Qubit device integration using advanced semiconductor manufacturing process technology. _In International Electron Devices Meeting_ 133–136 (IEEE, 2018). 

- [16] Feynman, R. P. Simulating physics with computers. _Int. J. Theor. Phys._ **21** , 467–488 (1982). 

- [17] Bravyi, S. B. & Kitaev, A. Y. Quantum codes on a lattice with boundary. _Preprint at arXiv:quant-ph/9811052_ (1998). 

- [18] Fowler, A. G., Mariantoni, M., Martinis, J. M. & Cleland, A. N. Surface codes: towards practical large-scale quantum computation. _Phys. Rev. A_ **86** , 032324 (2012). 

- [19] Loss, D. & DiVincenzo, D. P. Quantum computation with quantum dots. _Phys. Rev. A_ **57** , 120–126 (1998). 

- [20] Zwanenburg, F. A. _et al._ Silicon quantum electronics. _Rev. Mod. Phys._ **85** , 961–1019 (2013). 

- [21] Vandersypen, L. M. K. & Eriksson, M. A. Quantum computing with semiconductor spins. _Physics Today_ **72** , 38–45 (2019). 

- [22] Yang, C. H. _et al._ Silicon qubit fidelities approaching incoherent noise limits via pulse engineering. _Nat. Electron._ **2** , 151–158 (2019). 

- [23] Veldhorst, M. _et al._ A two-qubit logic gate in silicon. _Nature_ **526** , 410–414 (2015). 

- [24] Huang, W. _et al._ Fidelity benchmarks for two-qubit gates in silicon. _Nature_ **569** , 532–536 (2019). 

- [25] Hendrickx, N., Franke, D., Sammak, A., Scappucci, G. & Veldhorst, M. Fast two-qubit logic with holes in germanium. _Nature_ **577** , 487–491 (2020). 

- [26] Qiao, H. _et al._ Conditional teleportation of quantum-dot spin states. _Nat. Commun._ **11** , 3022 (2020). 

- [27] Takeda, K., Noiri, A., Nakajima, T., Yoneda, J. & Kobayashi, T. Quantum tomography of an entangled three-spin state in silicon. _Preprint at arXiv:2010.10316_ 21. 

- [28] Hendrickx, N. W. _et al._ A four-qubit germanium quantum processor. _Preprint at arXiv:2009.04268_ (2020). 

- [29] Petit, L. _et al._ Universal quantum logic in hot silicon qubits. _Nature_ **580** , 355–359 (2020). 

- [30] Vandersypen, L. M. K. _et al._ Interfacing spin qubits in quantum dots and donors—hot, dense, and coherent. _npj Quant. Inf._ **3** , 34 (2017). 

- [31] Veldhorst, M., Eenink, H. G. J., Yang, C. H. & Dzurak, A. S. Silicon CMOS architecture for a spin-based quantum computer. _Nat. Commun._ **8** , 1766 (2017). 

- [32] Li, R. _et al._ A crossbar network for silicon quantum dot qubits. _Sci. Adv._ **4** (2018). 

- [33] Pauka, S. J. _et al._ A cryogenic interface for controlling many qubits. _Preprint at arXiv:1912.01299_ (2019). 

- [34] Xue, X. _et al._ CMOS-based cryogenic control of silicon quantum circuits. _Preprint at arXiv:2009.14185_ (2020). 

- [35] Auth, C. _et al._ A 10nm high performance and low-power CMOS technology featuring 3<sup>_rd_</sup> generation FinFET transistors, self-aligned quad patterning, contact over active gate and cobalt local interconnects. _In International Electron Devices Meeting_ 29.1.1–29.1.4 (IEEE, 2017). 

- [36] Van Zant, P. _Microchip Fabrication: A Practical Guide to Semiconductor Processing, 6th Edition_ (McGraw-Hill, New York, 2014). 

- [37] Averin, D. V. & Likharev, K. K. Coulomb blockade of single-electron tunnelling, and coherent oscillations in small tunnel junctions. _J. Low Temp. Phys._ **62** , 345–373 (1986). 

- [38] van der Wiel, W. G. _et al._ Electron transport through double quantum dots. _Rev. Mod. Phys._ **75** , 1–22 (2002). 

- [39] Hanson, R., Kouwenhoven, L. P., Petta, J. R., Tarucha, S. & Vandersypen, L. M. K. Spins in few-electron quantum dots. _Rev. Mod. Phys._ **79** , 1217–1265 (2007). 

- [40] Chanrion, E. _et al._ Charge detection in an array of CMOS quantum dots. _Phys. Rev. Applied_ **14** , 024066 (2020). 

- [41] Natarajan, S. _et al._ A 32nm logic technology featuring 2<sup>_nd_</sup> -generation high-k + metal-gate transistors, enhanced channel strain and 0.171 _µ_ m<sup>2</sup> sram cell size in a 291mb array. _In International Electron Devices Meeting_ 1–3 (IEEE, 2008). 

- [42] Auth, C. _et al._ A 22nm high performance and low-power CMOS technology featuring fully-depleted tri-gate transistors, self-aligned contacts and high density MIM capacitors. _In Symposium on VLSI Technology (VLSIT)_ 131–132 (VLSIT, 2012). 

- [43] Mistry, K. _et al._ A 45nm logic technology with highk+metal gate transistors, strained silicon, 9 Cu interconnect layers, 193nm dry patterning, and 100% Pb-free 

10 

packaging. _In International Electron Devices Meeting_ 247–250 (IEEE, 2007). 

- [44] Sabbagh, D. _et al._ Quantum transport properties of industrial<sup>28</sup> Si/<sup>28</sup> SiO2. _Phys. Rev. Applied_ **12** , 014013 (2019). 

- [45] Paladino, E., Galperin, Y., Falci, G. & Altshuler, B. 1/f noise: implications for solid-state quantum information. _Rev. Mod. Phys._ **86** , 361–418 (2014). 

- [46] Elzerman, J. M. _et al._ Single-shot read-out of an individual electron spin in a quantum dot. _Nature_ **430** , 431–435 (2004). 

- [47] Yang, C. H. _et al._ Spin-valley lifetimes in a silicon quantum dot with tunable valley splitting. _Nat. Commun._ **4** , 2069 (2013). 

- [48] Koppens, F. H. L. _et al._ Driven coherent oscillations of a single electron spin in a quantum dot. _Nature_ **442** , 766–771 (2006). 

- [49] Knill, E. _et al._ Randomized benchmarking of quantum gates. _Phys. Rev. A_ **77** , 012307 (2008). 

- [50] Nicollian, E. & Brews, J. _MOS (Metal Oxide Semiconductor) Physics and Technology_ (John Wiley & sons, New York, 1982). 

- [51] Schulz, M. Interface states at the SiO2-Si interface. _Surface Science_ **132** , 422–455 (1983). 

- [52] Bylander, J. _et al._ Noise spectroscopy through dynamical decoupling with a superconducting flux qubit. _Nat. Phys._ **7** , 565–570 (2011). 

- [53] Cywinski, L., Lutchyn, R. M., Nave, C. P. & Das Sarma, S. How to enhance dephasing time in superconducting qubits. _Phys. Rev. B_ **77** , 11 (2008). 

11 

**METHODS** 

# **Setup and instrumentation** 

The measurements were performed on two different setups on different continents, setup 1 (S1, Delft) and setup 2 (S2, Hillsboro). The samples were cooled down in a dilution refrigerator, operated at the base temperature of around 10 mK (S1: Oxford Triton dry dilution refrigerator, S2: Bluefors XLD dry dilution refrigerator). DC voltages were applied via Delft in-house built, battery-powered voltage sources (S1 and S2). The printed circuit board onto which the sample was mounted contained bias tees with a cut-off frequency of 3 Hz to allow for the application of gate voltage pulses (S1 and S2). The pulses were generated by an arbitrary waveform generator (AWG, S1: Tektronix AWG5014, S2: Zurich Instruments HDAWG). The baseband current through the sensing dot was converted to a voltage by means of a home-built amplifier, filtered through a room-temperature low-pass filter (S1: 3 kHz, S2: 1.5 kHz) and sampled by a digitiser (S1: M4i spectrum, S2: Zurich Instruments MFLI). Microwave bursts for driving ESR were generated by a vector source with an internal IQ mixer (S1 and S2: Keysight PSG8267D), with the I and Q channels controlled by two output channels of the AWG. 

# **Charge noise measurements** 

Each charge noise data point in Fig. 2c is obtained by recording a 140 second time trace (at 28 Hz sampling rate) of the current through the QD with the plunger gate voltage fixed at the steepest point of the Coulomb peak flank. To convert the current signal to energy, we proceed as follows. First, we convert the current to gate voltage by multiplying the data by the slope of the Coulomb peak at the operating point. Then, we multiply with the lever arm to convert from plunger gate voltage to energy. To obtain the power spectral density (PSD), we divide the data in 10 equally long segments, take the single-sided fast Fourier transform (FFT) of the segments and average these. Fitting the PSD to _A/f_<sup>_α_</sup> we extract the energy fluctuations at 1 Hz ( _~~√~~ A_ ) for each Coulomb peak. We extract a mean value of _α_ = 1 _._ 1 _±_ 0 _._ 3. 

# **Spin readout** 

In order to read out the spin eigenstate we use energyselective tunneling to the electron reservoir [46]. The spin levels are aligned with respect to the Fermi reservoir, such that a spin-up electron can tunnel out of the QD, while for a spin-down electron it is energetically forbidden to leave the QD. Thus, depending on the spin state, the charge occupation in the QD will change. To monitor the charge state, we apply a fixed voltage bias across the sensing dot and measure the baseband current signal through the sensing dot, filtered with a low-pass filter and sampled via the digitiser. In post-analysis we threshold the sensing dot signal and accordingly assign a spin-up or spin-down to every single shot experiment. 

After readout, we empty the QD to repeat the sequence. As is commonly seen in spin-dependent tunneling, the readout errors are not symmetric, which is reflected in the range of the oscillations in Figs. 4a,b. 

# **Qubit operations** 

When addressing the qubit, we phenomenologically observe that the qubit resonance frequency shifts depending on the burst duration. The precise origin of this resonance shift is so-far unclear, but appears to be caused by heating. Similar observations have been made in recent spin qubit experiments [9, 10, 34] that used electric-dipole spin resonance via micromagnets as the driving mechanism. To ensure a reproducible qubit frequency in the experiments, we apply an off-resonant microwave burst prior to the intended manipulation phase to saturate this frequency shift. We further investigate this frequency shift in Extended Data Figs. 6 and 7. 

# **Ramsey oscillation** 

We observe that the qubit resonance frequency in the devices exhibits jumps of several 100 s of kHz on a timescale of 5-10 minutes. To extract meaningful results, we monitor this frequency shift throughout the experiments and accordingly discard certain data traces, such that we only take into account data acquired with the qubit in a narrow frequency window. To illustrate the frequency shift, we show the FFT of 100 repetitions of a Ramsey interference measurement of qubit 1 (measurement time _∼_ 2 hours 40 min) in Extended Data Fig. 8a, which tracks the qubit frequency over time. In order to estimate the _T_ 2<sup>_∗_ofqubit1,wefit</sup> each of the 100 repetitions of the Ramsey measurement (measurement time per repetition _∼_ 100 s) and extract a _T_ 2<sup>_∗_value.Evidently,someofthedataqualityisrather</sup> poor due to the previously described frequency jumps in which case the extracted _T_ 2<sup>_∗_valueismeaningless.We</sup> calculate the mean square error of each fit and disregard all the measurements with a high error. The average _T_ 2<sup>_∗_</sup> of the 41 remaining traces is 24 _±_ 6 _µ_ s (Extended Data Fig. 8b). Averaging the data traces of all 41 traces and then fitting a decay curve yields a dephasing time of 16 _±_ 2 _µ_ s (Extended Data Fig. 8c); averaging the data of all 100 traces still gives a dephasing time of 11 _±_ 2 _µ_ s (Extended Data Fig. 8d). 

# **CPMG coherence measurements and power spectral density** 

To ensure robust fitting, the CPMG sequences are applied with artificial detuning. We fit the resulting curves with a Gaussian damped cosine function: _A_ (cos( _ωt_ + _φ_ ) + _B_ ) exp[ _−_ ( _t/T_ 2<sup>CPMG</sup> )<sup>2</sup> ] + _C_ . If, instead of using a Gaussian decay, we leave the exponent of the decay open as a fitting parameter, we obtain values for the exponent between 2.3 and 2.6, but the use of the additional parameter results in less robust fits. The offset _B_ is included to compensate for the loss of 

12 

readout visibility for long microwave burst duration. We attribute this to heating generated while driving the spin rotations. The measurement is divided into segments, each consisting of 200 single shots. Each segment includes a simple calibration part, based on which we post-select repetitions for which the spin-up probability after applying a _π_ -pulse is above 25 percent. In this way, we can exclude repetitions where the qubit resonance frequency has shifted drastically. The remaining repetitions are averaged to obtain the characteristic decay curves for each choice of _n_ , one of which is shown in Fig. 4b. From fitting the decay curves, we extract the _T_ 2<sup>CPMG</sup> times as a function of _n_ , shown in Fig. 4d. To extract the CPMG amplitude as a function of evolution time from the data, we demodulate the measured values with the parameters extracted from the fit, according to _A_ CPMG = ( _x − C_ ) _/_ ( _A_ (cos( _ωt_ + _φ_ )+ _B_ )), with _x_ the measured data. Due to experimental noise, points where the denominator is small, do not yield meaningful results. Hence, we exclude data points for which the absolute value of the expected denominator is smaller than 0.4. The extracted CPMG amplitudes are plotted in Fig. 4c. In a commonly used simplified framework [52, 53], we can relate the data of Fig. 4d to a noise power spectral density of the form _S_ ( _ω_ ) _∝_ 1 _/ω_<sup>_γ_</sup> . Specifically, fitting the data to _T_ 2<sup>_CP MG_</sup> ( _n_ ) _∝ n_<sup>_γ/_(</sup><sup>_γ_+1)</sup> gives _γ_ = 1 _._ 1 _±_ 0 _._ 2. Alternatively, we can estimate _γ_ by fitting the noise power spectral density extracted from the individual data points in the CPMG decays [53] in Extended Data Fig. 9(a). This analysis gives _γ_ = 1 _._ 2 _±_ 0 _._ 1. Either way, the extracted power spectral density is close to the 1 _/f_ dependence that is characteristic of charge noise. Charge noise can affect spin coherence since the spin resonance frequency is sensitive to the gate voltage, as also reported before for Si-MOS based spin qubits [3]. We next estimate how large charge noise would need to be in order to dominate spin decoherence. To do so, we extrapolate the extracted spectral density in the range between 10<sup>3</sup> and 10<sup>4</sup> Hz to an amplitude at 1 Hz, which after conversion to units of charge noise gives 29 _±_ 27 _µ_ eV/ _~~√~~_ Hz. With the caveat that this extrapolation is not very precise, we note that this value is only slightly larger than the charge noise amplitude in the multi-electron regime of 2 _−_ 10 _µ_ eV/ _~~√~~_ Hz. Considering that charge noise values are typically higher in the few-electron regime, this suggests that coherence of Q1 may be limited by charge noise [53]. For Q2, which is another qubit in the same sample, the same procedure gives an extrapolated noise at 1 Hz that is an order of magnitude larger. Possibly a two-level fluctuator is active in the vicinity of this qubit in the regime where the qubit data was taken. 

## **ACKNOWLEDGEMENTS** 

We thank Luca Petit and Sander de Snoo for software support and Raymond Schouten, Raymond Vermeulen, Marijn Tiggelman, Jason Mensingh, Olaf Benningshof and Matt Sarsby for technical support. Moreover, we thank all people from the QuTech spin qubit group and from the Intel Components research group for discussions. We acknowledge financial support from Intel Corporation and the QuantERA ERA-NET Cofund in Quantum Technologies implemented within the European Union’s Horizon 2020 Program. 

## **AUTHOR CONTRIBUTIONS** 

A.M.J.Z., T.K., T.F.W., L.L. and F.L. performed the quantum dot and qubit measurements. J.B., D.C.S., J.P.D., G.D., R.K., D.J.M., R.P., N.S., G.S., M.V., L.M.K.V. and J.C. designed the devices. S.A.B., H.C.G., E.M.H. and B.K.M. fabricated the devices. P.A., J.M.B., R.C., T.K., L.L., F.L., D.M., S.N., R.P., T.F.W., O.K.Z., G.Z. and A.M.J.Z. characterised the test structures and devices. M.L. characterised the Si-MOS stacks. S.V.A. contributed to the preparation of the experiments. A.M.J.Z., T.K., T.F.W., L.L. and F.L. analysed the data. J.R., L.M.K.V. and J.S.C. conceived and supervised the project. A.M.J.Z., T.K. and L.M.K.V. wrote the manuscript with input from all authors. 

## **ADDITIONAL INFORMATION** 

_Data availability_ Datasets and analysis scripts supporting the conclusions of this paper are available at https://doi.org/10.5281/zenodo.4478855. 

_Competing interests_ The authors declare no competing interests. 

13 



EXTENDED DATA FIG. 1. **Comparison of an academic SiMOS device and a TEM-image of an industrial device. a,** High-angle annular dark-field scanning transmission electron microscopy image (HAADF-STEM) of a SiMOS device from [1], fabricated at Delft University of Technology, using electron beam lithography and lift-off techniques. Below the fine gates, the screening gates of the device are visible. **b,** TEM image of a device nominally identical to devices measured here. Compared to the academic device, the gate profiles and dimensions are much more uniform and well-defined (as stated in the main text, there are two sets of nested gates, so we should compare gates within the same set), and there are no traces of spurious pieces of metal. 

14 



EXTENDED DATA FIG. 2. **Sample with ESR line.** A scanning electron microscope image of a sample with an ESR line, nominally identical to the samples measured in this letter. The ESR line is false-coloured in red. The active area of the sample is indicated by the cartoon of a spin. Metal dummification is clearly visible in the image, the quantum dot gates are not visible as they are covered by dielectric. 

15 



<!-- Start of picture text -->
a b<br>c d<br><!-- End of picture text -->

EXTENDED DATA FIG. 3. **Cross-wafer variation of threshold voltages.** Each 300 mm wafer consists of 82 die and each die contains quantum dot arrays with various design skews and array sizes (up to 55 gates), as well as transistor and calibration test structures. To analyse cross-wafer sample uniformity, automated probing at room temperature is used to measure one seven-gate device per die (nominally identical to the devices discussed in the main text). For each device, the threshold voltage for the seven gates on the qubit fin are analysed. **a,** Median threshold voltage of the three gates of the first gate layer (evennumbered). For the bulk of the samples, the median threshold voltage is between 0 _._ 6 V and 0 _._ 8 V. **b,** Median threshold voltage for the four gates of the second gate layer (odd-numbered gates). **c,** Spread (highest minus lowest value) in threshold voltage of the three gates in the first gate layer per sample. For the majority of the wafer, the spread in threshold voltage is between 50 and 200 mV. **d,** Spread in threshold voltage for the second gate layer per sample. In general, the spread in threshold voltage for the majority of the second gate layer is between 100 and 250 mV. The combination of figures **a** , **b** , **c** and **d** . shows that the spread of threshold voltage per sample is low and the median is rather uniform, indicating a good cross-wafer uniformity and thus a precise process control. The cross-wafer variation of the second gate layer is slightly augmented relative to the first layer. This arises from small process-induced cross-wafer variability of the final effective oxide thickness of the second gate layer, which gives rise to an electrostatic change and results in a small shift in threshold voltage. 

16 



EXTENDED DATA FIG. 4. **Coulomb diamonds** Typical Coulomb blockade diamonds measured in the multi-electron regime, from which the quantum dot charging energy and the gate lever arms are determined. Coulomb diamonds are measured by scanning a gate voltage versus the bias voltage applied between the source and the drain contact. When the electrochemical potential of the quantum dot falls outside the bias window, the current through the quantum dot is blocked, i.e. the sample is in Coulomb blockade. Once the electrochemical potential of the quantum dot is aligned within the bias window, Coulomb blockade is lifted. The bias window increases along the vertical axis, hence Coulomb blockade is lifted over a wider gate voltage range. The regions of blockaded current have the characteristic diamond shape. Here we extract a charging energy of 8 _._ 4 _±_ 0 _._ 2 meV and a lever arm of 0 _._ 36 meV/mV. 

17 



<!-- Start of picture text -->
1400 dIdVSensG2  [a.u.] 0.004<br>0.003<br>1300<br>1<br>0.002<br>0.001<br>1200<br>0.000<br>1100<br>0.001<br>0.002<br>1000<br>2<br>0.003<br>900 0.004<br>800 900 1000 1100 1200 1300 1400<br>G2 [mV]<br>G3 [mV]<br><!-- End of picture text -->

EXTENDED DATA FIG. 5. **Charge stability diagram for the few-electron regime.** Charge stability diagram for the few-electron regime of the samples in which qubit 1 and qubit 2 are measured. Smaller charge sensing maps are stitched together to obtain one large map. As pointed out in the main text, the Coulomb peaks become more irregular towards the single-electron regime, indicating dots forming under adjacent gates. The approximate gate voltages at which qubit 1 and qubit 2 are measured are indicated. 

18 



<!-- Start of picture text -->
Off resonant (-10MHz, 20 µs)<br>time On resonant (I/Q = 0.05 V, 3 µs)<br>a b<br>I/Q<br><!-- End of picture text -->

EXTENDED DATA FIG. 6. **Frequency shift due to off-resonant microwave pulse amplitude.** Microwave spectroscopy of **a,** qubit 1 and **b,** qubit 2 as a function of the I/Q amplitude of an off-resonant microwave pre-burst (orange in schematic) that is applied immediately before the microwave spectroscopy burst (purple in schematic). Both qubit 1 and qubit 2 show similar behavior with the qubit frequency shifting to a lower frequency when the I/Q amplitude of the off-resonant microwave pre-burst is above 0 _._ 05 V. The microwave output power at an I/Q amplitude of 0.2 V is 6 dBm and the LO frequency is 13 _._ 072 GHz for qubit 1 and 13 _._ 053 GHz for qubit 2 (different tuning than in the main text). The off-resonant burst is 10 MHz away from the LO frequency with a duration of 20 _µ_ s. The spectroscopic microwave burst has an I/Q amplitude of 0 _._ 05 V with a duration of 3 _µ_ s. 



<!-- Start of picture text -->
Off resonant<br>On resonant<br>time time<br>a b<br>I/Q I/Q<br><!-- End of picture text -->



EXTENDED DATA FIG. 7. **Time dependent frequency shift of qubit 1.** In these measurements we perform microwave spectroscopy of the qubit at low power to find the qubit resonance frequency. Before the microwave spectroscopy burst (purple in schematic), we apply an off-resonant burst. **a,** The resonance frequency of the qubit as a function of the duration of the off-resonant burst applied before spectroscopy (purple dots). An exponential fit gives a time constant of 1 _._ 7 _µ_ s. **b,** The resonant frequency of the qubit as a function of the time between the off-resonant and spectroscopy pulse. An exponential fit gives a time constant of 37 _µ_ s. The time dependence of the resonance frequency of the qubit while turning on and off the microwave signal indicates that the frequency shift is related to heating. The off-resonant burst is applied 5 MHz away from the LO and has an I/Q amplitude of 0 _._ 2 V. The spectroscopy burst has an I/Q amplitude of 0 _._ 05 V and a duration of 3 _._ 5 _µ_ s. The LO frequency is 17 _._ 1428 GHz and the microwave output power is 13 dBm at I/Q amplitude of 0.2 V. 

19 



<!-- Start of picture text -->
a b<br>c d<br><!-- End of picture text -->

EXTENDED DATA FIG. 8. **Ramsey analysis over time. a,** Fast Fourier transform (FFT) of a Ramsey experiment. The data consists of 100 traces, each trace is an average of 200 repetitions. The entire measurement takes three hours in total. The FFT of the Ramsey fringes shows frequency jumps over the timescale of the measurement. Each trace is fitted individually with a decaying Gaussian curve and the fit is analysed by calculating the mean square error. We keep the 41 traces with mean square error below a given threshold. **b,** Extracted _T_ 2<sup>_∗_fortheselectedtraces(purpledots).Theaverageofthe</sup><sup>_T_2</sup><sup>_∗_timesof</sup> the selected traces is 24 _±_ 6 _µ_ s (orange line). **c,** Ramsey decay curve. The data points are the averaged data of the 41 selected traces. The fit gives a _T_ 2<sup>_∗_timeof16</sup><sup>_±_2</sup><sup>_µ_s.</sup><sup>**d,**Ramseydecaycurve.Thedatapointsaretheaverageofall100tracesofthe</sup> two hour and 40 minute measurement. The fit gives a _T_ 2<sup>_∗_timeof11</sup><sup>_±_2</sup><sup>_µ_s.</sup> 

20 



<!-- Start of picture text -->
a b<br><!-- End of picture text -->

EXTENDED DATA FIG. 9. **Noise analysis for qubit 1. a,** Dynamical decoupling pulses for which the time between two subsequent _π_ -pulses is fixed, can act as a filter function for Gaussian noise [2, 3]. The filter function peaks at a frequency of _f_ 0 = 2 _twaitn_<sup>,with</sup><sup>_n_thenumberof</sup><sup>_π_-pulsesand</sup><sup>_twait_theevolutiontime.Whenthefilterissufficientlynarrowaround</sup> the frequency _f_ 0, the noise within the bandwidth can be regarded as constant. We can use this to relate the amplitude of the CPMG decay, _ACP MG_ , for each wait time and number of _π_ pulses, to the dominant noise spectrum for the qubit: _S_ ( _f_ 0) = _−_ ln( _ACP MG_ ) _/_ 2 _π_<sup>2</sup> _twait_ [4, 5]. Here, we plot the noise spectrum, _S_ ( _f_ ) as a function of frequency for the data shown in Fig. 4c of the main text. We only take data points into account for which 0 _._ 15 _< ACP MG <_ 0 _._ 85. We assume that the noise spectrum dominating spin decoherence is described by a power law and use the fit function _Bf_<sup>_−γ_</sup> . We obtain _γ_ = 1 _._ 2 _±_ 0 _._ 1 and a noise value at 1 Hz of _B_ = 820 _±_ 750 Hz/ _~~√~~_ Hz. This agrees well with the fitting of the individual CPMG curves and the _T_ 2 _,CP MG_ scaling in Fig. 4 of the main text. Using the susceptibility of the qubit resonance frequency to a voltage change of a nearby gate and the energy lever arm of that gate we can compare the noise value B to charge noise. With this conversion we obtain _B_ = 29 _±_ 27 _µ_ eV/ _~~√~~_ Hz. **b,** Following [2], we now use the filter function as described in **a** to estimate the noise decay and the noise level at 1 Hz that gives the given _T_ 2 _,CP MG_ for the number of _π_ -pulses and fit this to our data. We obtain _γ_ = 1 _._ 06 _±_ 0 _._ 13 and _B_ = 30 _±_ 18 _µ_ eV/ _~~√~~_ Hz. This is comparable to the results obtained in **a** . 

21 



<!-- Start of picture text -->
a b c<br>d e f<br><!-- End of picture text -->

EXTENDED DATA FIG. 10. **AllXY and Randomised benchmarking. a, d,** To check the calibration of the single-qubit gates we perform an AllXY sequence [6] on **a,** qubit 1 and **d,** qubit 2. Each data point corresponds to the outcome after sequentially applying two gates from the set I, X, X<sup>2</sup> , Y, Y<sup>2</sup> , where X and Y indicate 90<sup>_◦_</sup> rotations. The data points should ideally follow a staircase pattern (solid line) and deviations from this indicate calibration errors. **b, c, e, f,** To determine the single-qubit gate fidelity, we perform randomised benchmarking [7, 8]. In randomised benchmarking, we randomly select _p_ gates from a set of 24 gates that form the Clifford group and apply them to the qubit. At the end of the sequence we apply an inverting gate from the Clifford group that ideally takes the qubit state back to either _|_ 0 _⟩_ or _|_ 1 _⟩_ . In this experiment, the Clifford gates are decomposed to the set of primitive gates I, _±_ X, _±_ X<sup>2</sup> , _±_ Y, _±_ Y<sup>2</sup> . On average a Clifford gate contains 1.875 primitive gates. **b, e,** Normalised spin-up probability as a function of the number of Clifford operations applied for **b,** qubit 1 and **e,** qubit 2. The orange and purple data points correspond to sequences producing a net Clifford of X<sup>2</sup> or I, respectively, ideally taking the spin to either spin up or spin down. Each data point corresponds to 40 randomisations of the Clifford sequence and the normalisation is done by additional calibration experiments where we apply either just I or X<sup>2</sup> to the qubit. **c, f,** The difference between the purple and orange data points in **b, e,** is fitted with and exponential of the form _V Pc_<sup>_p_.Fromthiswe</sup> derive an average Clifford-gate fidelity of _FC_ = 1 _−_ (1 _− Pc_ ) _/_ 2 of 98 _._ 1 _±_ 2 _._ 7% and 98 _._ 2 _±_ 1 _._ 4% for qubit 1 and qubit 2 respectively. This translates to a primitive gate fidelity of 99 _._ 0 _±_ 1 _._ 4% and 99 _._ 1 _±_ 0 _._ 7% for Q1 and Q2. 

22 



<!-- Start of picture text -->
a b c<br>d e<br><!-- End of picture text -->

EXTENDED DATA FIG. 11. **Rabi oscillations for qubit 2. a-d,** Rabi oscillation of qubit 2 measured for different output powers of the microwave source. **e,** The extracted Rabi frequency is plotted versus the square root of the applied power, showing the expected linear dependence. 



<!-- Start of picture text -->
a b c<br><!-- End of picture text -->

EXTENDED DATA FIG. 12. **Coherence of qubit 2. a,** CPMG-curve for qubit 2 for _n_ = 20. Fitting this curve, as described in the methods, gives _T_ 2 _,CP MG_ = 1 _._ 2 _±_ 0 _._ 2 ms. **b,** Analogously to the case of qubit 1 (see main text), we demodulate and normalise the CPMG amplitude as a function of evolution time for different numbers of _π_ pulses, giving the CPMG amplitude. **c,** The measured CPMG decay time as a function of the number of _π_ -pulses. The orange line represents a fit through the data (excluding _n_ = 1) following _T_ 2<sup>CPMG</sup> _∝ n_<sup>(</sup><sup>_γ/_(</sup><sup>_γ_+1))</sup> . We extract _γ_ = 1 _._ 51 _±_ 0 _._ 15. Performing a similar analysis as has been done for qubit 1 (see Extended Data Fig. 9) gives unreliable results. 

23 



<!-- Start of picture text -->
a b<br><!-- End of picture text -->

EXTENDED DATA FIG. 13. **Rabi oscillations for qubit 3** . **a,** Rabi oscillation for a third qubit measured on a different device than qubits 1 and 2. The qubit was measured at an external magnetic field of _B_ = 0 _._ 675 T, giving a Larmor frequency of 18 _._ 757 GHz. From fitting the curve, we extract a Rabi frequency of 1.4 MHz. **b,** Spin-up probability versus burst duration and microwave frequency in a slightly different tuning regime. The expected Chevron pattern is visible. We observed a second (spurious) quantum dot in the vicinity of qubit 3 and expect that hybridisation with this extra quantum dot is limiting the _T_ 2<sup>_∗_</sup> and also the _T_ 2 _,Rabi_ of qubit 3. 

- [1] Eenink, H. G. J. _et al._ Tunable coupling and isolation of single electrons in silicon metal-oxide-semiconductor quantum dots. _Nano Lett._ **19** , 8653–8657 (2019). 

- [2] Bylander, J. _et al._ Noise spectroscopy through dynamical decoupling with a superconducting flux qubit. _Nat. Phys._ **7** , 565–570 (2011). 

- [3] Cywinski, L., Lutchyn, R. M., Nave, C. P. & Das Sarma, S. How to enhance dephasing time in superconducting qubits. _Phys. Rev. B_ **77** , 11 (2008). 

- [4] Kawakami, E. _et al._ Gate fidelity and coherence of an electron spin in an Si/SiGe quantum dot with micromagnet. _Proc. Natl. Acad. Sci. USA_ **113** , 11738–11743 (2016). 

- [5] Yoneda, J. _et al._ A quantum-dot spin qubit with coherence limited by charge noise and fidelity higher than 99.9%. _Nat. Nanotechnol._ **13** , 102–106 (2018). 

- [6] Reed, M. _Entanglement and Quantum Error Correction with Superconducting Qubits_ (2013). 

- [7] Knill, E. _et al._ Randomized benchmarking of quantum gates. _Phys. Rev. A_ **77** , 012307 (2008). 

- [8] Magesan, E., Gambetta, J. M. & Emerson, J. Characterizing quantum gates via randomized benchmarking. _Phys. Rev. A_ **85** , 042311 (2012). 

