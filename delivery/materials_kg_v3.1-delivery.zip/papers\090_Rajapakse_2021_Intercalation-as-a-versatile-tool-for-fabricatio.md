# Intercalation as a versatile tool for fabrication, property tuning, and phase transitions in 2D materials

| 字段 | 内容 |
|---|---|
| 期刊 | npj 2D Materials and Applications |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 241 |
| 作者 | Manthila Rajapakse, B. Karki, Usman O. Abu, Sahar Pishgar, Md Rajib Khan Musa, S. Riyadh, M. Yu, G. Sumanasekera et al. |
| DOI | 10.1038/s41699-021-00211-6 |
| 源文件 | 090_Rajapakse_2021_Intercalation-as-a-versatile-tool-for-fabricatio.pdf |

---
www.nature.com/npj2dmaterials 

## REVIEW ARTICLE **OPEN** 



# Intercalation as a versatile tool for fabrication, property tuning, and phase transitions in 2D materials 

Manthila Rajapakse<sup>1</sup> , Bhupendra Karki 1, Usman O. Abu 2, Sahar Pishgar 1, Md Rajib Khan Musa1, S. M. Shah Riyadh 1, Ming Yu1, Gamini Sumanasekera<sup>1,2✉</sup> and Jacek B. Jasinski 2 ✉ 

Recent advances in two-dimensional (2D) materials have led to the renewed interest in intercalation as a powerful fabrication and processing tool. Intercalation is an effective method of modifying the interlayer interactions, doping 2D materials, modifying their electronic structure or even converting them into starkly different new structures or phases. Herein, we discuss different methods of intercalation and provide a comprehensive review of various roles and applications of intercalation in next‐generation energy storage, optoelectronics, thermoelectrics, catalysis, etc. The recent progress in intercalation effects on crystal structure and structural <mark>p</mark> hase transitions <mark>,</mark> includin <mark>g</mark> the emer <mark>g</mark> ence of <mark>q</mark> uantum <mark>p</mark> hases are also reviewed. n <mark>pj</mark> 2D Materials and A <mark>pp</mark> lications (2021) 5:30 ; htt <mark>p</mark> s://doi.or <mark>g</mark> /10.1038/s41699-021-00211-6 

### INTRODUCTION 

Along with the emergence of nanotechnology, the study of lowdimensional materials has gained much attention due to some unusual material properties<sup>1</sup> . The discovery of graphene and other two-dimensional (2D) materials, including phosphorene<sup>2</sup> , silicene<sup>3,4</sup> , germanene<sup>4</sup> , MXenes<sup>5</sup> , and transition metal dichalcogenides (TMD)<sup>6</sup> , has led to the recent rapid growth in this field. Due to extraordinary properties arising from their reduced dimensionality, 2D materials can be used in a wide array of applications, including energy storage (batteries and capacitors)<sup>7–9</sup> , energy conversion<sup>10</sup> , superconductors<sup>11</sup> , photonics<sup>12</sup> , catalysts<sup>13,14</sup> , etc. These accelerated advances in the field of 2D materials has also led to a renewed interest in intercalation as a powerful tool for the fabrication and processing of layered structures. In general, intercalation in layered materials is a process of inserting foreign ions or molecules in-between weakly-bonded layers. Layered materials are suitable host materials for various intercalants, including ions and molecules. The research area of intercalation in layered materials has grown rapidly since the development of a large class of graphite intercalation compounds (GICs)<sup>15</sup> . 

Synthesis of single- and few-layered 2D materials is an essential first step for investigating the layer-dependent property changes and providing pathways for large scale applications. Although the primary scope of this paper is intercalation, other competitive 2D fabrication methods like hydrothermal self-assembly, chemical vapor deposition (CVD), and mechanical exfoliation (scotch-tape method) are commonly used for 2D material fabrication. Hydrothermal method is mostly suitable for precursors with excellent solubility and stability at high pressure and high temperature<sup>1</sup> . Intercalation-assisted exfoliation is an alternative for precursors that are sensitive to elevated temperatures and pressures. Also, non-liquid-based intercalation methods work for precursors that have relatively poor solubilities. Another commonly employed 2D material synthesis method is the CVD, which has enabled the synthesis of large-area and uniformly thick 2D layers on metallic and insulating surfaces. However, CVD is very sensitive to lattice structure dissimilarities between 2D materials and substrate<sup>16</sup> . A lattice mismatch between the substrate and deposited thin film 

could lead to the film’s distortions and formation of its superstructures. Likewise, transferring CVD grown 2D materials from the substrate is challenging. Nonetheless, intercalation-assisted exfoliation can be used to fabricate free-standing 2D materials. While mechanical exfoliation using a scotch-tape is one of the oldest methods of fabricating 2D materials, this method is commonly used for laboratory-scale production because of limitations in ensuring uniformity of thickness on a large scale. Conversely, intercalation-assisted exfoliation followed by controlled sonication and centrifugation can be used to fabricate larger amounts of 2D materials with more uniformity in thickness. On the other hand, a significant limitation of intercalation-assisted liquid exfoliation is its suitability for 2D materials that have weak interlayer interaction, so that the insertion of foreign species further weakens/breaks the interlayer bonds. However, the choice of the fabrication method depends on the nature of 2D materials and the intended applications. 

Different intercalation strategies have been developed, including chemical intercalation from gas<sup>17,18</sup> or liquid phase<sup>17,19</sup> , electrochemical intercalation using solid<sup>20,21</sup> or liquid<sup>22–24</sup> electrolytes, etc. The content of this review article has been organized in the following manner (Fig. 1 illustrates the outline of the paper). In the section “Intercalation methods”, different intercalation methods, their fundamentals, and utilization of these methods will be discussed with notable examples. Intercalation has been widely used for exfoliation and large-scale production of 2D materials. Studies on the use of intercalation for the fabrication of 2D materials will be reviewed and described in the section “Intercalation for fabrication of 2d materials”. Intercalation has also been used for various technologies as a tool for controlling properties of layered materials, moving them across phase diagrams, or triggering structural transformations. Unlike in previously published reviews on intercalation, which often categorize the intercalation-related works according to materials properties and resulting applications, we recognize that intercalation may lead to several different effects and play different roles, depending on the host-intercalant system and conditions. Therefore, we describe these diverse roles with the underlying mechanisms and review 

> 1Department of Physics and Astronomy, University of Louisville, Louisville, KY 40292, USA. 2Conn Center for Renewable Energy Research, University of Louisville, 40292, USA.<sup>✉</sup> email: gamini.sumanasekera@louisville.edu; jacek.jasinski@louisville.edu 

KY 

Published in partnership with FCT NOVA with the support of E-MRS 

M. Rajapakse et al. 

2 



Fig. 1 Intercalation of 2D materials. Schematic diagram summarizing different intercalation techniques and applications of intercalation in 2D materials. 

the existing literature from this point of view. Firstly, the use of intercalation for energy storage, based on easy insertion and deinsertion of electrical charges, is recognized and reviewed in the section “Intercalation for electrochemical energy storage”. Then, in the section “Property tuning through intercalation-induced doping”, the charge carrier doping of the host layers due to the donor or acceptor intercalation is discussed. The effects on electronic structure and various properties, such as electrical, catalytic, optical, magnetic, as well as on the formation of strongly correlated phases, such as superconductivity or charge density waves (CDWs), are reviewed. In the section “Intercalation effects on interlayer interactions”, the effects of intercalation on the interlayer interactions and interlayer separation, which affects mechanical and optical properties, phonon dispersions, in addition to thermal and electronic transport, are considered and discussed. By weakening of interlayer van der Waals (vdW) interactions, intercalation can also lead to the relative plane slips and changing layer stacking, such as in the case of TMDs, where intercalation can cause the 2H to 1T (1T’) phase transition. This type of structural phase transition, along with intercalationinduced structural phase transition, caused by the in-plane bond reconstruction, such as in the case of the theoretically predicted phase transition between black and blue phosphorene, will be discussed and reviewed in the section “Intercalation-induced structural phase transitions”. A brief overview of opportunities and challenges in the intercalation of 2D materials is given at the end. 

### INTERCALATION METHODS 

### Electrochemical intercalation 

In this method, the intercalation process is driven by the application of external current or a voltage to the system, which can be performed using a typical electrochemical cell setup in which the roles of anode and cathode electrodes are played by intercalants and host materials, respectively, as shown in Fig. 2a. An electrochemical cell requires electrolytes medium (solid or liquid) to promote the movement of charges between host and guest species. Although many liquid electrolytes are commonly used in electrochemistry, in this paper, we classify such examples 

under electrochemical intercalation (not liquid phase intercalation) due to two reasons; (1) Electricity through an external circuit is a characteristic outcome of electrochemical intercalation. (2) Electrolyte is not necessarily the main source of intercalant (anode is). (Section “Liquid phase intercalation” covers liquid-phase intercalation methods in which the liquids are used as the main source of intercalant.). 

Intercalant source (or guest species) could either be a donor or acceptor type compound. In both cases, a charge transfer (driven and by an external electric field) between hosts and intercalants take place. Upon intercalation, donor type materials give away electrons and creep into the interlayer spacings of the layered host material. Such intercalation’s electrochemical reaction can be represented as xH + D<sup>+</sup> + e<sup>−</sup> → HxD where, H and D are host material and donor species, respectively. Alkaline and alkaline earth metals like Li, Na, and Mg are well-known donor-type intercalants that are widely used with layered materials in many studies and applications<sup>25–28</sup> . On the other hand, an acceptor type species like H2SO4 takes away electrons from host material via a reaction; xH + A<sup>−</sup> → HxD + e<sup>−</sup> , where A is the acceptor species<sup>29</sup> . Electrochemical intercalation is unique because of the easy reversibility of the intercalation process<sup>17</sup> . Typically, deintercalation can be done by simply reversing the polarity of the current; there are instances in which intercalation could lead to parasitic side-reactions, involving the electrolyte<sup>30</sup> or the hostguest bonding sometimes beyond a certain degree of intercalation<sup>31,32</sup> . For instance, in-situ transmission electron microscopy (TEM) studies reveal that electrochemical intercalation of Li into BP could lead to the formation of amorphous LixPy alloys beyond a certain degree of lithiation<sup>33</sup> . A similar study on Na also shows this dual mechanism in which intercalation is followed by the formation of Na3P alloy<sup>34</sup> . The extent of such parasitic sidereactions may depend on specific conditions of the intercalation process, including its geometry. Zhang et al.<sup>35</sup> have shown that the voltage-controlled selective intercalation of Li<sup>+</sup> and Na<sup>+</sup> ions through the top surface of MoS2 is more robust and stable compared to the intercalation through the edges. The study has revealed that the sealed-edge MoS2 allows the intercalation of small alkali metal ions (Li<sup>+</sup> and Na<sup>+</sup> ) and rejects large ions such as K<sup>+</sup> . 

However, the stages of intercalation can be controlled externally by means of applied electric field or potential. Furthermore, the amount of charge transferred during intercalation/deintercalation can be easily estimated if the parameters like current and time are known; thus, the stoichiometry of the final intercalated compound can also be predicted. Electrochemical intercalation is controlled mainly by either chronopotentiometry or chronoamperometry<sup>36</sup> . Chronopotentiometry is a galvanostatic method in which the current is held at a constant level for a given time. In chronoamperometry, a potential step is applied, and the resulting current vs. time profile is observed. Ever since the introduction of the lithium-ion battery, which is arguably the best application in electrochemical intercalation, this method received a lot of attention. As a result, many studies are carried out implementing electrochemical intercalation with an array of layered host materials and intercalants. 

Although electrochemical intercalation in liquid electrolyte is widely used in most commercially available energy storage systems, this technology has some serious drawbacks, including high reactivity of the electrolyte in ambient conditions, dendrite growth from anode to cathode, and limited temperature range of operation. Some of these drawbacks can be minimized by using solid electrolytes in lieu of liquid electrolytes. Examples of promising solid-state electrolytes are, Perovskite type (Li3xLa(2/3)−xTiO3,)<sup>37</sup> , NASICON-type conductors LiM2(PO4)3 (M = Zr, Ti, Hf, Ge or Sn)<sup>38</sup> , Garnet-type conductors Li5La3M2O12 (M = Nb, Ta)<sup>39</sup> . 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 30 

M. Rajapakse et al. 

3 



Fig. 2 Intercalation methods. a Electrochemical intercalation, b two-zone vapor phase intercalation, c liquid/solution phase intercalation. 

### Vapor phase intercalation 

This is one of the earliest and most common intercalation mechanisms. Vapor phase techniques are based on the utilization of heat to control the intercalation process. In other words, controlling the temperature of intercalants and hosts controls the vapor-transport and hence the transport of intercalants into the host layers. In general, intercalants and host materials are heated inside an enclosed vessel, which is suitable to create high vapor pressure inside the system (see Fig. 2b). Depending on the temperature control method, vapor phase intercalation can be divided into two main categories, isothermal or two-zone transport<sup>17,18</sup> . In the isothermal method, both hosts and intercalants are held at the same temperature, whereas a temperature difference is maintained in the two-zone method. In both methods, temperature (or temperature difference) regulates vapor pressure of the intercalant and controls thermodynamics of intercalation<sup>18,40</sup> . The vapor phase intercalation method is popular as it is compatible with a variety of intercalant/host pairs. For instance, previous works report vapor phase intercalation of host 2D materials like graphene, TMDs, and phosphorene with many alkali metals (Na, K, and Cs)<sup>41</sup> , transition metals (Cu, Cd, Hg)<sup>42</sup> , post transition metals (Sn, Pb)<sup>42</sup> and pnictogens like Bi<sup>42</sup> . The vapor phase intercalation of halogen intercalants like bromine<sup>43</sup> and iodine<sup>44,45</sup> have also been reported. On the downside, compared to electrochemical intercalation, vapor phase technique lacks the ability to determine the composition (stoichiometry) of the intercalated samples in situ as it is challenging to calculate the number of atoms/molecules transferred to the host material. Although several ex situ quantification techniques have been implemented to determine the chemical compositions of the final intercalated product. Salvo et al.<sup>42</sup> report a gravimetric analysis in which the final and initial masses of the host material are being compared. Insertion of intercalants is responsible for the increase in mass, and thus, the number of guest atoms intercalated can be calculated. Alternatively, energy dispersive X-ray spectroscopy with elemental mapping can also be used to determine the chemical composition<sup>41</sup> . 

### Liquid phase intercalation 

This section covers few approaches that differ slightly from each other, in which the host 2D material is being immersed into a 

liquid that contains intercalant atoms, ions, or molecules so that the intercalants can creep into the vdW gaps of the immersed host material via the liquid medium being the common practice (see Fig. 2c). This method does not generate electric currents as a result of intercalation; thus, liquid phase intercalation should not be confused with some electrochemical intercalation methods which involve a liquid electrolyte. The liquid source for intercalants could either be a solution containing intercalants<sup>17,46,47</sup> or the molten state of the intercalants itself<sup>19,48</sup> . The intercalation process in the liquid phase is governed by the kinetic and thermodynamic nature of the liquid-intercalant source and host. The effects of solvent type, temperature, intercalant concentration, and the size of the host lattice on the intercalation rate are studied and reported elsewhere<sup>49,50</sup> . It has been reported that liquid phase intercalation can be used to insert an array of inorganic and organic molecules like hydrazine, dimethyl sulfoxide (DMSO), sulfuric acid, urea, acetone, ethyl alcohol, tetrahydrofuran N,N-dimethyl formamide, chloroform, toluene and isopropylamine (i-PrA) into layered materials<sup>47,51–53</sup> . In the case of hydrazine and dimethylformamide (DMF) intercalated MXene<sup>47</sup> , it has been found that deintercalation is also possible by drying the intercalated product above the boiling points of hydrazine and DMF, which makes the process reversible. Koski et al. has reported intercalation of zerovalent Cu into Bi2Se3 using a Cu<sup>+</sup> salt in a solvent complex, resulting in a high Cu yield up to 60% in the intercalated compound<sup>54</sup> . Typically, solution phase intercalations are governed by a chemical reaction, oxidation, reduction, or both. For instance, the monovalent Cu<sup>+</sup> salt being used as the intercalant source converts into zerovalent Cu and Cu<sup>2+</sup> in solution phase intercalation with Bi2Se3. Only zerovalent Cu gets intercalated while Cu<sup>2+</sup> is bound in a solvent complex<sup>54</sup> . This is an example of an oxidation–reduction (redox) reaction, which governs the intercalation process. A similar approach has been used by Wang et al. to intercalate Sn into 2D metal chalcogenides<sup>55</sup> . These methods have been further extended to intercalate various TMDs (e.g., Sb2Te3, In2Se3, GaSe)<sup>56</sup> and non-TMDs such as MoO357 as well as incorporating dual metal elements into them<sup>58</sup> . 

Liquid ammonia and some organic solvents like methylammonium and tetrahydrofuran are known to dissolve alkali and alkaliearth metals<sup>46</sup> . As a result, especially liquid ammonia has been widely used to intercalate alkali and alkali-earth metals into 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 30 

M. Rajapakse et al. 

4 

Table 1. Summary of different fabrication methods for various layered vdW materials and their properties. 

|Fabrication methods|2D Materials|Comments||
|---|---|---|---|
|CVD|Graphene<sup>83</sup>, TMDs<sup>84</sup>|LPCVD & APCVD|Mostly in Cu substrate.|
|||MoS2, WS2, MoSe2, WSe2|Monolayer|
|Exfoliation|Graphene<sup>85–88</sup>|Adhesive tape, wedge-based, graphite<br>oxide reduction, shear-mixing,<br>sonication, molten salts, electrochemical<br>synthesis||
||TMDs<sup>87</sup>|Shear-mixing|2–12 layers, length 40–200 nm, concentrations up<br>to 0.5 mg mL<sup>−1</sup>, nanosheets|
|||Wet and dry ball milling|Scalable production, simple procedure, high<br>concentration, control of size and thickness is<br>difficult|
||hBN<sup>87</sup>|Shear-mixing|average thickness 4–12 nm, tens to hundreds of<br>nanometer lateral size|
|||Wet and dry ball milling|few-layer BN|
||2D-Xenes<sup>87</sup>|Shear-mixing|Lateral size several microns, few layers.|
|Hydrothermal self-<br>assembly|GO nanosheets<sup>89</sup>|Bottom up|tunable thickness ranging from ∼1 nm to<br>∼1500 nm (monolayer)|
|Intercalation-assisted<br>exfoliation-|Graphene oxide<sup>68–70</sup>|Oxidation of graphite by KMnO4,<br>KNO3,…|High yield, thickness ~ 1 nm, scalable but<br>explosion risk, Low electrical conductivity of GO|
|oxidation based|Graphene<sup>71–73</sup>, h-BN<sup>74</sup>|Gas phase intercalation|Yield: dependent on intercalation agents,<br>thickness: few layers, sufficient for layer materials<br>with strong in-plane bonding|
|Intercalation-assisted<br>exfoliation-<br>reduction based|Metal chalcogenides<sup>74–78</sup><br>Graphene<sup>79</sup>, h-BN<sup>69,80</sup>|Gas phase intercalation|High yield, thickness: mono-few layers, high<br>conductivity of metal chalcogenides, time<br>consuming, relatively small lateral size|
|||Liquid phase intercalation|High yield, thickness: mono-few layers, tunable<br>semiconductor, and metallic phase percentage,<br>suitable for large-scale production, sensitive to<br>moisture and oxygen|
|||Electrochemical intercalation|High yield, thickness: monolayers, safe, high cost|



graphene<sup>46</sup> , MoS259, and black phosphorous (BP)60. In the latter two cases, Zhang et al. have also been able to observe superconductivity in the host materials. Liquid ammonia (NH3) can self-ionize into NH4+ and NH2− (2NH3 → NH4+ + NH2−). Upon introduction, alkali or alkaliearth metals (M) also gets ionized inside the medium, donating the electron to the medium temporarily (M → M<sup>+</sup> + e<sup>−</sup> ). The metal ion moves freely in the medium and eventually creeps into the layers of the host material. After the intercalation, the ejected electron is donated back from ammonia and attaches to the intercalated compound resulting in zerovalent intercalation of metals<sup>46</sup> . The color of the metal-ammonia solution changes from dark blue to yellowishbrown when the metal concentration is changing from low to high, which can be used as an indicator for the progress of intercalation. 

The ion exchange method is another type of liquid phase intercalation in which an existing ion in the host gets replaced by a guest ion. This mechanism is widely applied in layered double hydroxides (LDH)<sup>61</sup> . An LDH has an interlayer charge-compensating anion such as CO<sup>3−</sup> , NO<sup>3−</sup> or Cl<sup>−</sup> . This charge compensating anion can be replaced by another thermodynamically competitive anion provided by an intercalant source in a liquid medium. There are reported works on intercalating many organic anions<sup>61,62</sup> , and halides<sup>63</sup> into the interlayer spacing of LDHs using this method. 

In addition to the usage of aqueous or non-aqueous solutions, metal intercalation can also be done in the liquid phase by immersing host materials in molten metals or metal salts<sup>64</sup> . Furthermore, usage of molten Li-Ca alloys to intercalate Ca in graphene intercalated compounds have also been reported<sup>19,48</sup> . High temperatures are required as metals need to be always kept in the molten state. An inert environment is also necessary as alkali metals are highly reactive in the normal atmosphere. 

Overall, liquid phase intercalation methods can be a better option over electrochemical intercalation whenever the host/guest species are less conductive. However, similarly to vapor phase methods, liquid phase intercalation also lacks control over the composition of the final product. In situ quantitative measurements can also be a challenge, as it is hard to monitor the overall process. 

### INTERCALATION FOR FABRICATION OF 2D MATERIALS 

Historically, intercalation has been applied to layered materials as a means of exfoliating individual 2D layers from their bulk counterparts in large quantities. Exfoliation of 2D materials was initially developed for graphite, which involves the manual rubbing and peeling of bulk graphite<sup>65</sup> . The underlying principle for the intercalation-based exfoliation is in increasing the interlayer spacing between individual 2D layers by inserting foreign species. This weakens the interlayer adhesion and reduces the energy barrier to exfoliation, thus eventually increases the accessible surface areas in 2D materials<sup>66</sup> . Layered crystals are particularly suitable for intercalation processes as they can strongly adsorb guest species into their vdW gaps between each layer, forming the basis of intercalation-based exfoliations of a variety of 2D materials, including 2D TMDs<sup>67</sup> . Different intercalationassisted methods have been utilized to fabricate 2D materials such as oxidation-based intercalation and exfoliation<sup>68–74</sup> , reductionbased intercalation and exfoliation<sup>69,75–80</sup> , and ion-exchanged intercalation and exfoliation<sup>81,82</sup> . A list of such fabrication methods compared with other methods<sup>83–89</sup> of fabrication of 2D materials are presented in Table 1. In oxidation-based intercalation, a strong oxidative agent is used to oxidize and intercalate the layered host material to expand the interlayer spacing; thus, the material can be 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 30 

M. Rajapakse et al. 

5 

exfoliated to thin flakes more easily by shear force or gas production reaction. So far, this process has been mostly used for the preparation of graphene oxide (GO) by oxidizing graphite applying common oxidizing agents like potassium permanganate and concentrated sulfuric acid<sup>66,68</sup> . A major drawback of this method is that it introduces a significant number of chemical groups and structural defects. Hence, the physical properties of graphene exfoliated via the oxidation–reduction intercalations are quite different from those of its pristine form<sup>90,91</sup> . For example, the electrical conductivity of the graphene obtained via intercalation is generally lower than that of the mechanically exfoliated graphene due to the enhanced electron scattering from the structural defects. In addition, the large size of oxidizing molecules, small interlayer spaces, and weak in-plane covalent bonds in host materials, which may lead to decomposition, are some of the limiting factors of this process<sup>69</sup> . Reduction-based intercalation of alkali metals has been widely used to fabricate 2D materials including TMDs (MoS2, WS2, NbSe2, WSe2, VSe2, Sb2Se3, Bi2Te3, …), graphite, and h-BN<sup>75,76,92</sup> . In this method, small size alkali atoms or ions such as lithium (Li) are intercalated into the small spacings between the layers of the host material. Adding water to alkali metal-intercalated materials produces hydrogen bubbles expanding the interlayer distances and exfoliates them into 2D layers. Different methods of intercalation of alkali metals have been used. For instance, Eda et al. have reported liquid-phase intercalation in n-butyllithium (n-BuLi) solution to fabricate 2D layers of MoS275. As discussed, alkali metals can also be electrochemically intercalated to layer materials, as developed by Zeng et al., based on the working principles of lithium-ion batteries (LIBs). They have reported intercalation of Li to various bulk layered materials such as MoS2, WS2, TiS2, TaS2, ZrS2, and graphite<sup>76</sup> . The electrochemical intercalation of Li into BP has also been reported in a recent study<sup>22</sup> . The formation of elongated BP segments has been observed and the process has been suggested as a key step for the production of BP nanoribbons. 

While electrochemical intercalation is the base process for the operation of LIBs and some other electrochemical energy storage devices, intercalation-based methods have also been used in synthesizing materials for various applications, including gassensing. For instance, Lee et al.<sup>93</sup> fabricated 2D V2CTx via selective etching and intercalation with ultrahigh selectivity towards nonpolar gases. The obtained MXene was intercalated with tetra-n butyl ammonium hydroxide (TBAOH) and dealuminated upon shaking in deionized (DI) water for 2 h. TBAOH was employed as a medium of delamination as previous attempts to separate the MXene layers proved abortive. The resulting V2CTx nanoflakes were then used to fabricate devices that demonstrated impressive gas-sensing abilities: detecting hydrogen and methane at 2 and 25 ppm, respectively. 

### INTERCALATION FOR ELECTROCHEMICAL ENERGY STORAGE 

The principles of intercalation have been exploited for electrochemical energy storage, like in the case of commercial Li-ion batteries, where the interlayer gaps of graphite, which is often used as anode material, serve as the host for reversible insertion and de-insertion of Li-ions during charging-discharging cycles. In many layered materials, intercalation is a reversible process of inserting and storing ionic species inside the interlayer gaps while the integrity of the host material is preserved. This is particularly true for the systems where the gaps are relatively large as compared to the size of the intercalant species. This process can be used directly for energy storage applications. Indeed, reversible intercalation of lithium and other alkali metals in layer materials has been widely used in electrochemical energy storage systems, such as electrochemical batteries and pseudocapacitors. 

### Batteries 

Intercalation/de-intercalation is the fundamental underlying process of Li-ion batteries. For example, in commercial Li-ion batteries, graphite (C6) is often used as anode materials, and its interlayer gaps serve as the host for reversible insertion and deinsertion of Li-ions during charging-discharging cycles. The reversible intercalation of Li occurs according to xLi<sup>+</sup> + xe<sup>–</sup> + C6 ↔ LixC6 reaction with 0 ≤ x ≤ 1<sup>94</sup> . During this process, Li<sup>+</sup> are supplied to and from the anode through the electrolyte, while electrons are provided via the external electrical circuit. As the charge carriers could be reversibly inserted into the interlayer spacing of a layered material (electrode), intercalation allows avoiding several severe problems associated with standard electrochemical reactions, including volumetric expansion and strain generated during the charging/discharging cycles<sup>94</sup> . Throughout the evolution of Li-ion batteries, several battery configurations have been implemented by making either or both electrodes with layered materials<sup>95</sup> . For instance, the battery can be a “half intercalation cell” in which only the cathode is made with a layered host for Li<sup>+</sup> , whereas the anode is just Li metal (Fig. 3a (top)). The modern Li-ion battery has a configuration where both anode and cathode are made with layered materials and store Li-ions at different potentials; thus, a potential difference can be created (Fig. 3a (middle)). As further developments, Read et al. have reported a “dual-ion intercalation” configuration<sup>96</sup> (Fig. 3a (bottom)). In this configuration, not only Li cations but also some anions are simultaneously involved in intercalation/ deintercalation between two layered electrodes. 

In addition to graphite, also other layered materials have been explored for their electrochemical intercalation applications. In particular, electrochemical intercalation of alkali metals into vdW gaps of TMDs have been probed for decades to test their suitability in energy storage applications. Good conductivity of the electrode is an index for a good battery, which TMD materials have proven to possess<sup>6,97</sup> . The most used intercalants for 2D TMDs are alkali metals, such as Li, K, Na, Cs, etc. and some transition metals like Fe, Cr, Mn, and V<sup>98</sup> . For example, Whittingham et al. has reported<sup>99,100</sup> the fundamental properties of LixTiS2 compounds and showed that TiS2 can be used as a cathode for high-energy-density reversible Li-ion batteries due to its lightweight<sup>97</sup> , higher metallic conductivity<sup>101,102</sup> and rapid selfdiffusion of Li<sup>103</sup> . Whittingham’s work in 1976 used a simple electrochemical cell with TiS2 cathode, Li anode, and an electrolyte made with LiPF6 dissolved in propylene carbonate<sup>97</sup> . The initial current densities of 10 mA/cm<sup>2</sup> of active material surface were found to be the highest surface current density reported for any battery system with an organic electrolyte. The cells showed good cyclability and have retained the reversibility after 1100 cycles despite the resistance losses associated with electrolyte. Recent application of TiSe2 in rechargeable batteries has gained much attention because of its large interlayer spacing and higher electrical conductivity. TiSe2 was used as a cathode material, and its electrochemical behavior was studied through magnesium (Mg), sodium (Na), and Potassium (K) ion intercalation. TiS2 has also been used as the cathode for Na-ion batteries<sup>104</sup> . Na<sup>+</sup> intercalation on TiSe2 nanosheets shows the reversible capacity of 147 mAhg<sup>−1</sup> at the current density of 0.1 Ag<sup>−1</sup> and at higher current density (10.0 Ag<sup>−1</sup> ) it exhibits a good rate capability with a capacity of 103 mAhg<sup>−1 105</sup> . Electronic structure of Mg<sup>2+</sup> intercalated TiSe2 was studied by Gu. et al. through the rechargeable performance of Mg-ion batteries<sup>106</sup> . First principle calculation confirmed the close energy levels of 3d-orbital of Ti and 4p-orbital of Se, d–p orbital hybridization around the fermi level. Mg<sup>2+</sup> were reversibly intercalated/deintercalated from the vdW gap between the TiSe2 layers. The charge delocalization in metal-ligand was due to the strong d–p orbital hybridization, which enhances the reversible performance of Mg<sup>2+</sup> intercalation/deintercalation. 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 30 

M. Rajapakse et al. 

6 



Fig. 3 Intercalation for energy storage applications. a Typical battery configurations for Li-ion batteries<sup>95</sup> . (top) half-cell where only the cathode serves as intercalation host. (middle) Both electrodes serving as hosts (typical Li-ion battery configuration) (bottom) “dual-ion intercalation” in which both anions and cations serve as intercalants and both electrodes serve as hosts (Read et al.)<sup>96</sup> . b Pseudocapacitance of VOPO4 with Li<sup>+</sup> and Na<sup>+</sup> intercalation<sup>130</sup> . Panel a adapted with permission from ref.<sup>95</sup> Chem. Rev. 118, 11433–11456 (2018) Copyright (2018). American Chemical Society; Panel b adapted with permission from ref.<sup>130</sup> Nano. Lett. 16, 742–747 (2016). Copyright (2016). American Chemical Society. 

Electrochemical K<sup>+</sup> /Li<sup>+</sup> intercalation study in TiSe2 were reported by Li et al. via in situ X-ray diffraction (XRD), ex situ TEM, and ex situ X-ray photoelectron spectroscopy (XPS) characterizations<sup>107</sup> . In comparison to Li<sup>+</sup> intercalation, it was observed that K<sup>+</sup> show lower (1–2 orders) diffusion coefficient and more sluggish intercalation reaction kinetics based on the galvanostatic intermittent titration technique (GITT) analysis. During K<sup>+</sup> intercalation/deintercalation TiSe2 undergoes irreversible structural changes while the intercalation reaction was fully reversible for Li<sup>+</sup> intercalation/deintercalation. 

Another promising layered material for its electrochemical intercalation applications is BP. Specifically, its high theoretical capacity (2596 mAhg<sup>−1</sup> )<sup>108</sup> and low diffusion barrier of 0.08 eV for Li<sup>+</sup> ,<sup>109</sup> make BP a promising candidate for energy storage research. Compared to graphene, phosphorene allows large ion intercalation and deintercalation easily due to large interlayer distance of 0.53 nm<sup>110–112</sup> . For this reason, BP was employed in anodes of Li-ion battery and exhibited an improved charge capacity of 1279 mAhg<sup>−1</sup> with a first cycle efficiency of 57%<sup>113</sup> . Na-ion battery promised to be cost-effective<sup>114–119</sup> alternative of Li-ion battery. Theoretical calculation showed fast Na diffusion in zigzag direction and charging and discharging analogous to LIB. First Na-ion battery was fabricated by Cui and co-worker<sup>34</sup> using phosphorene/graphene sandwich structure. This structure reduced the diffusion path and accommodated volume expansion by providing a buffer space for expansion. This battery achieved reversible capacity of 2040 mAhg<sup>−1</sup> and retained 85% capacity after 100 cycles.<sup>120,121</sup> 

Finally, one more class of layered materials that should be emphasized are 2D oxides, as their intercalation capabilities have enabled a wide range of applications in electrochemical energy storage. Molybdenum oxides have been extensively investigated as electrode materials in Li-ion batteries with high capacities taking advantage of the properties derived from their layers accepting foreign atoms. Investigations have been carried out for both anode and cathode materials<sup>122</sup> . The unique structural properties of molybdenum oxides, involving linked MoO6 octahedra and the gap between layers in the α-MoO3 phase, offer an outstanding arrangement to intercalate a high capacity of 

small ions like Li<sup>+</sup> ions when used as a cathode material. The ability to intercalate Li<sup>+</sup> ions to produce highly conducting lithium intercalated molybdenum bronzes during the charge/discharge process is the key working principle of this application<sup>110,123</sup> . Highly reversible redox reactions by molybdenum oxides loading up to 1.5 Li per Mo atom is reported, which gives rise to a high energy density with a theoretical value of 745 Whkg<sup>−1</sup> ,<sup>123</sup> . 

### Electrochemical capacitors 

The formation of double layers between the conductive electrodes and a liquid electrolyte is the basis in every electrochemical capacitor to store electrical energy. Two layers of charges with opposing polarity form, one at the surface of the electrode and one in the electrolyte are formed at the double-layer. The doublelayer acts like a conventional electrostatic capacitor, but with the thickness of a single molecule giving an extremely large value to the capacitance. Pseudocapacitance, on the other hand, is accompanied by a Faradic charge-transfer of an electron between electrolyte and electrode. The resulting device, pseudocapacitor, stores electricity by either a fast sequence of Faradic redox reactions, electrosorption, or intercalation process on the electrode-electrolyte interface<sup>124</sup> . In contrast to batteries, materials in pseudocapacitors do not undergo phase transition upon intercalation<sup>124</sup> . 

TMDs and TMD-graphene hetero-nanosheets have become a promising class of materials in the fabrication of pseudocapacitors in the recent past. A fewer number of layers in the electrodes leads to faster and more reversible charge transfer under intercalation compared to higher layered samples as demonstrated by Mahmood et al. for graphene-WS2 hybrid<sup>125</sup> . Fast and reversible intercalation of 2D TMDs is possible if the intercalation/ de-intercalation is kinetically fast enough to keep pace with the charging/discharging rate, which ultimately leads to extrinsic pseudocapacitance, which is ideal for high-rate charge-storage applications<sup>126</sup> . WS2 and MoS2 are two of the most used TMD 2D materials for pseudocapacitor applications. They have favorable electrochemical properties mainly due to high electrical conductivity, hydrophobicity, and the ability of the layers to 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 30 

M. Rajapakse et al. 

7 

dynamically expand in order to host various intercalant species. An in situ study reports that WS2-graphene heterostructure pseudocapacitors with LiPF6/ethylene carbonate/diethyl carbonate electrolytes have shown an intercalation pseudocapacitance value of 838 mAhg<sup>−1</sup> at 0.1 Ag<sup>−1</sup> for Li storage with a promising cyclability of 0.08% capacity fade per cycle for 100 cycles<sup>127</sup> . Another study reveals that pseudocapacitors made of 1T phase MoS2 nanosheets have also shown a competitive capacitance ranging from 400 to 700 Fcm<sup>−3</sup> at 5 mVs<sup>−1</sup> . These pseudocapacitors were capable of hosting ions such as H<sup>+</sup> , Li<sup>+</sup> , Na<sup>+</sup> , and K<sup>+</sup> with promising coulombic efficiencies in excess of 95% and stability over 5000 cycles<sup>128</sup> . 

In addition to TMDs, layered oxides such as VOPO4 and α-MoO3 have long been identified as a potential layered host material for pseudocapacitors in bulk form. However, for example, in the case of VOPO4, this material suffers from poor cyclability and moderate capacity<sup>129</sup> . But exfoliated 2D nanosheets of VOPO4 have shown better intercalation/deintercalation properties resulting in improved cyclability and capacity retention over the bulk material. Zhu et al.<sup>130</sup> have reported high-rate intercalation pseudocapacitance in VOPO4. VOPO4 nanosheets used as the cathode material have shown a specific capacity of 154 mAhg<sup>−1</sup> and 136 mAhg<sup>−1</sup> for lithium and sodium ions, respectively. In addition to high charging/discharging rates, it has also shown good cyclability for both lithium and sodium with capacity retentions of 90% and 73%, respectively after 500 cycles (Fig. 3b). 

Li<sup>+</sup> intercalation of molybdite (α-MoO3)<sup>131</sup> , which is an electroactive 2D layered material comprising of alternately stacked layers held together by weak van der Waals forces along [010], shows an enhanced pseudocapacitance. Though the interlayer gaps on MoO3 can be used for Li<sup>+</sup> intercalation, there has been less interest in energy storage applications due to its poor cycling behavior and modes reaction kinetics<sup>132</sup> . Brezesinski et al.<sup>131</sup> reported capacitive charge-storage properties of both crystalline and amorphous mesoporous MoO3. Although both samples displayed redox pseudocapacitance, the layered crystalline structure of α -MoO3 enabled more efficient lithium ions insertion into the quasi 2D vdW gaps. This report suggested that an extra capacitance contribution arises due to the intercalation pseudocapacitance, which appears to have similar kinetics as redox pseudocapacitance. 

Intercalation can also be used in the fabrication of supercapacitors, between MXenes and the intercalants. MXenes, which are generally prepared from MAX phases comprised of layered ternary carbides with the formula is Mn+1 XnTz (n is an integer between 1 and 4)<sup>133–136</sup> where M is an early transition metal, X is carbon and/or nitrogen, and T embodies various terminations such as fluorine, hydroxyl, and/or oxygen atoms<sup>120,121</sup> . Shen et al.<sup>137</sup> reported improved electrical conductivity and electrochemical performance when carbon—intercalated Ti3C2Tx MXene (Ti3C2Tx/C) was used as the active electrode material of supercapacitors. The carbon atoms introduced into the layers expanded the interlayer spacing; thus, enhancing gravimetric capacitance and assisting the permeation of electrolyte ions into adjacent layers. They achieved a gravimetric capacitance of 364.3 Fg<sup>−1</sup> and an impressive electrochemical stability of 99% over 10,000 cycles. The intercalation was achieved by the annealing of long chain fatty amines into galleries of the MXene. 

### PROPERTY TUNING THROUGH INTERCALATION-INDUCED DOPING 

Among several methods introduced to modify the properties of 2D materials, such as dimensional sizing<sup>138</sup> , external field tuning<sup>139</sup> , stacking order modification<sup>140</sup> , and strain engineering<sup>141,142</sup> ; intercalation<sup>143,144</sup> has become one of the most widely used, due to its effective and controlled electrical charge doping capabilities. During the intercalation process, when the donor 

(acceptor)-type intercalants are inserted between the layers of the host 2D material, they donate (withdraw) electrons to (from) the adjacent host layers, causing their Fermi level to shift and properties to change. Examples of donor- and acceptor-type intercalants in graphite are alkali metals<sup>145</sup> and protonic acids<sup>146</sup> , respectively. Overall, this process allows for wide tuning of the carrier concentration and significant control of various properties of the host material, including the electrical, thermal, magnetic, catalytic, vibrational, mechanical<sup>6,144,147</sup> , etc., leading to various applications, including electronic and optically active structures, catalysts, sensors, and more. In some instances, intercalation can also lead to phase transitions, such as a metal-insulator transition, and to the emergence of magnetism, superconductivity, and other strongly-correlated phases, such as CDW. 

### Reversible doping of layered materials through gatecontrolled ions injection 

Recently, the electrochemical intercalation for the controlled doping and material property tuning has been realized in filed effect transistor structures. For example, a bilayer graphene has been integrated into a miniaturized electrochemical cell architecture, and the intercalation process has been controlled through an electric gate<sup>148</sup> . Similarly, Yang et al. has demonstrated gatetunable ionic intercalation in α-MoO3 using ionic liquid-controlled transistor structures.<sup>149</sup> Gate-tunable ion injection doping has also been demonstrated in α-MoO3 devices with solid electrolyte<sup>150</sup> and graphene-device structures with liquid gate<sup>151</sup> . In yet another study, the electrolyte gating has been used to control the carrier density of 2M‐WS2 and reversible switching between the superconducting, metallic, and insulating state<sup>152</sup> . Similarly, Yu et al. has used the gate-controlled Li-ion intercalation to modulate the material properties of layered crystals of 1T-TaS2153. By measuring the temperature dependence of resistance of samples with different thickness, they have shown that gate-controlled intercalation modulates the phase transitions in 1T-TaS2 from a Mottinsulator to a metal state (Fig. 4a–c).<sup>153</sup> Switching of the electrical transport mechanism by ionic gating has also been demonstrated in 2D crystals of 2H-TaSe2 by Wu et al.<sup>154,155</sup> (see Fig. 4d–f). 

By and large, reversible and dramatic changes in electronic properties via gate-controlled ion injection provides intriguing opportunities for the development of novel nanodevices with highly tunable properties under an electric field. 

### Band engineering for optoelectronics and photovoltaics 

Due to their unique band structures and impressive optical properties, such as strong light-matter interactions, large exciton band energy, significant photoconversion, and light emission, etc., semiconducting 2D materials are promising for optoelectronic applications<sup>156</sup> . Intercalation can be used to modify the trions, conductivity and polarizations of these materials to expand their scope of use in optoelectronics. Hantanasirisakul et al.<sup>157</sup> synthesized Ti3CNTx via two etching routes using a mixture of LiF and HCl with HF, respectively and observed that intercalants, such as water and tetraalkylammonium hydroxides reduce the electronic conductivity of MXene due to augmented inter-flake resistance, leading to a surge in resistivity with declining temperature as detected in ensemble transport measurements. This was due to the hopping of electrons between flakes of Ti3CNTx instead of movement within the flakes, signaling a by-pass of the bandgaps of the as-prepared material, which would have supported the intrinsic movement of electrons within flakes. However, deintercalation via ion-exchange or vacuum annealing caused the bulk conductivity within Ti3CNTx to change to metallic. Upon investigating the optoelectronic properties of the synthesized MXene, they have noticed that Ti3CNTx has lower electronic conductivity and a blue shift of the main absorption feature within the UV –visible spectrum, likened to Ti3C2Tx. The possibility of 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 30 

M. Rajapakse et al. 

8 



Fig. 4 Gate-controlled intercalation effects on 1T-TaS2/2H-TaSe2. a Schematic measurement setup of 1T-TaS2 iFET. b Schematic of Li intercalation into layered 1T-TaS2. c Resistance R (normalized to its initial value R0) of 1T-TaS2 thin flakes during an up-sweep of Vg at T = 325 K. Sample A (black curve) is fully exposed to solid electrolyte, corner of sample B (red curve) is exposed while the region between electrodes was covered by a layer of PMMA and sample C (blue curve) is fully protected by PMMA<sup>153</sup> . Superconductivity and CDW in 2H-TaSe2. d sample configuration and optical image of a real device. e Hall coefficient RH as a function of magnetic field for the 10-nm-thick sample at various gate voltages for VG = 0 and 0.8 V at 2 K showing that Rxy is negative and nonlinear and for VG = 1.1 and 1.5 V showing that RH is positive and magnetic field independent. f Transition temperature of CDW and superconductivity with respect to gate voltage<sup>155</sup> . Panel a–c reprinted with permission from Springer Nature Publications Nature Nanotechnology<sup>153</sup> , Copyright (2015), advance online publication 26 January 2015 (https://doi.org/10.1038/nnano.2014.323, Nat. Nanotechnol.); panel d–f reused with permission from American Physical Society/Wu et al.<sup>155</sup> (https://doi.org/10.1103/PhysRevMaterials.3.104003). 

creating MXene-based materials with tunable electronic properties holds promise as the conductivity of Ti3C2Tx has also shown to depend on the presence of intercalants. 

In another study, the optical properties of α-MoO3 nanoribbons were tuned by a combined intercalation and de-intercalation process<sup>57</sup> . Zerovalent metals, such as Sn and Co were intercalated into α-MoO3 while the reverse process was accomplished by oxidative de-intercalation using iodine or hydrogen peroxide, and temperature-induced phase transitions. The intercalation process results in tuning the color of the precursor from transparent white to deep blue indigo, while the chemically or thermally driven reverse process yields the original transparent white color. Intercalated metals occupy positions on the layers that are disordered compared to the precursor. Conversely, the deintercalation process aids in re-ordering of these sites in a phase transition. This back-and-forth optical tuning of α-MoO3 shows promising prospects in chemochromic applications and colorchanging temperature sensors (see Fig. 5a). In addition to distorting the host structure that modifies the existing state, intercalants add discrete interband states between valance and conduction bands, which reduces the effective band gap of the material. Computational studies on n-type doping (equivalent to the type of doping provided by zerovalent metal intercalation) by Huang et al.<sup>158</sup> lends credence to this assertion. Intercalation of H<sup>+</sup> ions into MoO3 nanosheets enables researchers to tune and control the band structure of this wide-bandgap material. Intercalation of H<sup>+</sup> ions to the system results in the formation of unstable H2O groups, which may be released as molecular H2O introducing oxygen vacancies to the system. Consequently, HxMoO3 structure transfers to MoO3-x, which has a defect state within the bandgap and can be used as a photoactive material in optoelectronic devices and photocatalysis<sup>122,159,160</sup> . 

Moreover, a 70% increase in optical transparency in a wide spectral range, between the visible to near-infrared light, was observed when Cu atoms were intercalated into Bi2Se3 upon optical transmission measurements; the transparency of thinner nanoplates was even better, at 90%<sup>161</sup> . This is a consequence of chemical tuning of considerably diminished material absorption after intercalation and the outcome of nanophotonic zero-wave anti-reflection peculiar to nanoplates of very small thickness. The band gap of the material was widened because of the presence of Cu atoms in the vdW gaps, leading to the improved optical property over a wide range of wavelength. The concurrence of these mechanisms can be further exploited in diverse optoelectronic applications of 2D nanostructured materials (Fig. 5b). 

Intercalation and injection of large amounts of free carriers into MoS2 causes some changes in band structure, reducing the absorption of the material. According to research performed by Xiong et al., after Li intercalation of MoS2 a modest decline in transmission at wavelengths greater than 700 nm and a huge enhancement in transmission at wavelengths between 400 and 700 nm was detected<sup>162,163</sup> . In addition, the bands of intercalated MoS2 overlapped and underwent a semiconductor (2H) to metallic (1T) transition, as discussed in detail in the section “Stacking order modifications and applications in catalysis”. Similar reducing of the absorption has been reported for Li-intercalated graphite, suggesting that intercalation could be a promising method to be utilized in transparent electrodes and touch screen applications<sup>164</sup> . 

A sodium-ethylenediamine intercalated graphene compound (GIC) was found to be an excellent microwave absorber compared to pristine graphene. 10% wt. GIC in a GIC/paraffin mixture can absorb –75.6 dB at 9.25 GHz, where 20% wt. pure graphene in graphene/paraffin mixture absorption only –37.6 dB. Graphite band structure in Fig. 5c shows an unoccupied π* band. Intercalation of Na and ethylenediamine partially fills the π* bands and increases 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 30 

M. Rajapakse et al. 

9 



Fig. 5 Intercalation effects on band engineering. a Zerovalent metal intercalation-induced chemochromism in MoO3. Schematic illustration of zerovalent metal intercalation into MoO3 (top). MoO3 undergoes A color change of MoO3 dispersed in deionized water when intercalated with Co(0) or Sn(0) metal (bottom-left). UV-visible absorbance of MoO3 (black line), Co-MoO3(red line), and Sn-MoO3 (blue line) (bottom-right). The band gap is shown as an inset<sup>57</sup> . b The Burstein–Moss (BM) effect in Cu-intercalated Bi2Se3. Schematic illustration of Cu intercalation into Bi2Se3 (top). Optical transmission image of an 8-nm thick Bi2Se3 nanoplate before (bottom-left) and after (bottom-right) Cu intercalation. Schematic showing the BM shift induced by the increased free electron density (bottom-center)<sup>161</sup> . c, d Sodium-ethylenediamine GIC Na (ethylenediamine)C15: “GIC” possess higher electrical conductivity and unfrom 1.0–5.0 mm with loadings of 10.0 wt%<sup>165</sup> . Panel a adapted with permission ref.<sup>57</sup> from ACS Nano 9, 3226–3233 (2015). Copyright (2015). American Chemical Society; panel b reprinted with permission from Springer Nature Publications Nature Communications<sup>161</sup> Copyright (2014), advance online publication 27 October 2014 (https://doi.org/ 10.1038/ncomms6670, Nat. Commun.). Panels c–f adapted with permission ref.<sup>165</sup> from ACS Appl. Mater. Interfaces. 12, 16841–16848 (2020). Copyright (2020). American Chemical Society. 

electrical conductivity and induces polarization; thus, increasing microwave absorption ability of graphene (Fig. 5d–f)<sup>165</sup> . 

### Magnetism 

Magnetic properties of host materials can be tuned through the intercalation mechanism. Introducing foreign atoms at varying concentrations into the layers of host materials to tune spin–orbit effects<sup>166–168</sup> , orbital-moments<sup>166,169,170</sup> , lattice parameters<sup>6,171,172</sup> , etc. of host materials can alter their magnetic properties or induce magnetic phase transitions. 

Dai et al.<sup>173</sup> crystallized MnNb3S6 by intercalation of Mn ions into the octahedral holes between the trigonal prismatic layers of NbS2 (Fig. 6a). The introduced Mn ions caused magnetization to increase abruptly as temperature increased, indicating a magnetic phase transition. Furthermore, the magnetization was more robust in the direction perpendicular to the c-plane of the crystal compared to the parallel direction. This was the result of the effective modulation of the magnetic state by an external field where the chiral magnetic soliton (CSL) state emerged, as shown in Fig. 6b. CSLs are intermittent superlattice structure which consists of helical spin textures. They are topological, ensuring their robustness against material defects. The intercalated ions not only couple the a–b plane but also the c-axis. 

Chromium exhibited a similar effect upon intercalation to form Cr1/3NbS2 (see Fig. 6c) monoaxial chiral magnet. Han et al.<sup>174</sup> reported that Cr1/3NbS2 showed strong magnetic anisotropy when the external field was applied and perpendicularly to the c-axis (H > Hs). The CSL phase was observed to be magnetically metastable as observed from the loop on the boundary of the phase transition from the incommensurate CSL to the commensurate forced ferromagnetic phase (FFM). Furthermore, two critical points were 

displayed in the phase diagram constructed. The first was a tricritical one located at the meeting point of the CSL, FFM, and PM, states while the other was a zero-field type located at the meeting of CSL, HM, and PM states. These states are shown in Fig. 6d. 

Zhang et al.<sup>175</sup> intercalated Fe ions into the galleries of TaS2 to form a mono-crystalline quasi vdW ferromagnet (Fe0.26TaS2) as shown in Fig. 6e–f. The critical behavior of the resulting material was thus measured around transition temperature (100.7 K) from ferromagnetic to paramagnetic phase. The critical exponents obtained were consistent and intrinsic to the material, while a further analysis within the framework of renormalization group theory showed that the spin coupling inside Fe0.26TaS2 crystal was of the three-dimensional (3D) Heisenberg type with long-range magnetic interaction. In addition, it exhibited strong anisotropy, long-range magnetic interaction, and the ability to be cleaved into nanosheets; these features were pointers to the possible application of this material in spintronics. 

Another study by Deng et al.<sup>105</sup> showed the intercalation dependent gate tunable 2D itinerant ferromagnetism in atomically thin Fe3-xGeTe2 (FGT) crystals (see Fig. 6g). It was observed that intercalating lithium in exfoliated flakes of the ferromagnet Fe3-xGeTe2 induces a nonzero magnetization at T ∼ 300 K. Like the charging process in a Li-ion battery, a positive gate voltage Vg, intercalates lithium ions into the Fe3-xGeTe2 thin flake as shown in Fig. 6h. The high doping level, which originates due to the charge transfer of lithium ions into the host crystals, effects a significant change in the room temperature ferromagnetism in the FGT thin flake. Once the gate voltage is swept back, the gate induced highTc state reverts to its initial low-Tc state (see Fig. 6i–j). Thus, in ionic gating, intercalation mechanism induces the reversibility of the magnetic response. Such reversibility indicates that the gateintercalated ions do not chemically react (that is, form chemical 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 30 

M. Rajapakse et al. 

10 



Fig. 6 Intercalation effects on the magnetism. a Crystal structure of MnNb3S6. b H -T phase diagram in the vicinity of the phase transition for MnNb3S6 with H ⊥ c (HM corresponds to possible helimagnetism; CSL denotes possible chiral magnetic soliton phase; PM is paramagnetic state; and FMM represents forced ferromagnetic state)<sup>173</sup> . c The crystal structure of Cr1/3NbS2. d The H-T phase diagram in the vicinity of the phase transition obtained by the scaling of M-T-H for Cr1/3NbS2 with H ⊥ c (HM corresponds to the helimagnetism; CSL is the chiral magnetic soliton phase; PM is the paramagnetic state; and FMM represents the forced ferromagnetic state)<sup>174</sup> . e Schematic diagram of Fe1/4TaS2 crystal structure. Ta, S, and Fe atoms are denoted by green, orange, and purple balls, respectively. f Experimental two-dimensional backscatteredyield mapping patterns of the Fe in the crystal obtained from RBS/C spectra. θ and φ are the scanning angles when performing the twodimensional mapping, and the color scale is the integral backscattering signals (counts)<sup>175</sup> . Ferromagnetism in an atomically thin Fe3-xGeTe2 flake modulated by an ionic gate. Conductance as a function of gate voltage Vg measured in a trilayer Fe3-xGeTe2 device at g 10 K and 240 K, h 330 K. i Phase diagram of the trilayer FGT sample as the gate voltage and temperature are varied. j Coercive field as a function of the gate voltage at T = 10 K<sup>105</sup> . Panels a, b republished with permission of IOP Publishing from Critical phenomenon and phase diagram of Mnintercalated layered MnNb3S6. Dai et al., vol. 31. Copyright (2019); permission conveyed through Copyright Clearance Center, Inc.; panels c, d reused with permission from American Physical Society/Han et al.<sup>174</sup> (https://doi.org/10.1103/PhysRevB.96.094439); panels e, f reused with permission from American Physical Society/Zhang et al.<sup>175</sup> (https://doi.org/10.1103/PhysRevB.96.054406); panels g–j reprinted with permission from Springer Nature Publications Nature<sup>105</sup> , Copyright (2018), advance online publication 07 August 2018 (https://doi.org/10.1038/s41586018-0626-9, Nature). 

bonds) with the crystal, which is consistent with results from gatecontrolled intercalation of other layered crystal<sup>30,176,177</sup> . Gate controlled intercalation of lithium ions makes FGT crystals suitable for electrically controlled magnetoelectronic devices. 

However, intercalation-induced magnetic properties can sometimes be coincidental like in the case of the recent study by Weber et al., where sodium has been intercalated into Fe2.78GeTe2 in the presence of benzophenone to yield NaFe2.78GeTe2178. Naintercalation has been selected rather than focusing on Liintercalation due to the ease of Na detection. The study has shown that Na promptly intercalates into the vdW gaps, as uncovered by synchrotron X-beam diffraction. Simultaneously, the Fe2.78GeTe2 layer becomes intensely charge-doped and strained by means of chemical pressure, yet found to hold its structure and ferromagnetic transition temperature of ∼140 K. At the same time, over a wide intercalation range, the formation of a ferromagnetic amorphous iron germanide (Fe2-xGe) impurity phase has been observed, which caused a room temperature magnetism. Overall, it has been concluded that intercalation could be utilized as a powerful method for electron-doping Fe3-xGeTe2 and its derivatives. 

### Strongly-correlated systems—superconductivity, CDWs, and other quantum phases 

Most common physical systems, including metals and semiconductors, can be described very well with non-interacting electrons because the Coulomb interaction energy of electrons is much smaller than their kinetic energy. However, for certain class of systems, the interactions between the electrons (or quasi-particles) are not weak and play a major role in determining the properties of such systems. Such systems known as strongly correlated systems include, (i) conventional superconductors (ii) high-temperature superconductors (iii) quantum Hall systems (iv) charge density waves, etc. 

Upon insertion of donor intercalants, such as metals into graphite, and formation of donor-type GIC, the material acquires a more metallic character as the Fermi level goes up and the density of states at the Fermi level increases. This may lead to strongly correlated phenomena such as superconductivity, as reported for several GICs, including CaC6179–181, YbC6181, and BaC6182. Similar effects and appearance of a superconductor state upon doping-induced intercalation have also been observed in other layered 2D materials. For example, 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 30 

M. Rajapakse et al. 

11 



Fig. 7 Intercalation effects on superconductivity and CDW. a Temperature dependence of magnetic susceptibility χ for Li, K, Rb, Cs, and Ca intercalation for BP. Shown are ZFC (solid symbols) and FC (open symbols) measurements for an in-plane magnetic field of 10 Oe. The inset shows how Tc was determined for individual samples: it is defined as the sharp change in dχ/dT. b Magnetization M as a function of the magnetic field for intercalated compounds<sup>60</sup> . c Crystal structure of Cu intercalated Bi2Se3 that makes superconducting CuxBi2Se3 (left), and random substitution of Cu by replacing Bi atoms making Bi2-xCuxSe3 which is not superconductive (right).<sup>187</sup> d magnetic transport measurements of Cu0.12Bi2Se3, which shows a superconducting transition at 3.8 K. Upper inset: superconductivity occurs only in a narrow window of x in CuxBi2Se3. Superconductivity is not found for x < 0.1 and x > 0.3, or in Bi2-xCuxSe3. Lower inset: temperature dependence of the superconducting upper critical field of Cu0.12Bi2Se3 for the magnetic field applied parallel to the c axis and parallel to the ab plane.<sup>188</sup> . e Resistivity profile of single crystal Cu0.12Bi2Se3 with applied current in ab-plane. The lower inset shows that the superconducting transition occurs at̴ 3.8 K. The upper inset shows the magnetoresistance plot at T = 1.8 K. The second inset shows the zoomed in version of the resistivity plot and the third inset shows the comparison of the Seebeck coefficients of CuxBi2Se3 and Bi2-xCuxSe3.<sup>188</sup> f Superconductivity in K intercalated 2H-MoS2. g Superconducting phases of K intercalated 2H-MoS2 at various K concentration<sup>59</sup> . Electronic phase diagram of Cu intercalated TaS2 and TiSe2. Temperature (T) vs concentration (x) electronic phase diagram of Cu intercalated h TaS2190 and i TiSe2 with inset showing the crystal structure<sup>191</sup> . Panels a, b reprinted with permission from Springer Nature Publications Nature Communications<sup>60</sup> , Copyright (2017), advance online publication 23 February 2017 (https://doi.org/10.1038/ncomms15036, Nature Commun). Panel c reused with permission from John Wiley and Sons/Wang et al.<sup>187</sup> . Panels d, e reused with permission from American Physical Society/Hor et al.<sup>188</sup> (https://doi.org/ 10.1103/PhysRevLett.104.057001); panels f, g adapted with permission from<sup>59</sup> Nano Lett. 16, 629–636. Copyright (2016). American Chemical Society; panel h reused with permission from American Physical Society/Wagner et al.<sup>190</sup> (https://doi.org/10.1103/PhysRevB.78.104520); panel i reprinted with permission from Springer Nature Publications Nat. Physics<sup>191</sup> , Copyright (2006), advance online publication 28 June 2006 (https://doi.org/10.1038/nphys360, Nat. Phys). 

intercalation of different metals has been reported to induce superconductivity in samples of BP<sup>60,183</sup> . BP exhibits superconductivity at a pressure above 10 GPa, i.e., above its phase transition<sup>60,183</sup> . However, no superconductivity has been reported for its normal orthorhombic phase. On the other 

hand, alkali- (Li, K, Rb, and Cs) and alkali-earth-(Ca) intercalated phosphorous exhibit superconductivity at 3.8 ± 0.1 K, independent of intercalant (Fig. 7a, b). This superconductivity originates from heavy doping of phosphorene layer, and intercalant works as charge reservoirs<sup>60</sup> . 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 30 

M. Rajapakse et al. 

12 

The doping-induced superconductive phase has also been demonstrated recently in Re6Se8Cl2, a superatomic vdW 2D layered compound of the Chevrel phase class of materials<sup>184</sup> . In this case, a dramatic increase in carrier concentration that resulted in the superconductive phase was achieved via a process equivalent to de-intercalation, where the current annealing was applied for electron doping through dissociation and loss of interplanar Cl atoms. 

Early Cu doping studies have shown that Cu-intercalated Bi2Se3 compounds may have a dual nature<sup>185,186</sup> , which makes Cu an ambipolar dopant. Specifically, doped Cu can either be randomly substituted for Bi within the host structure to make Bi2-xCuxSe3 (Fig. 7c (right)) or it can be intercalated between quintuple-layergaps to make CuxBi2Se3 (Fig. 7c (left)). Two outcomes have drastically different electrical properties, and only the intercalated form (CuxBi2Se3) is found to exhibit the superconducting behavior in the range 0.12 < x < 0.15 at 3.8 K (Fig. 7d, e)<sup>187,188</sup> . Generation of mobile electrons in the conduction band upon Cu intercalation changes the symmetry around the host network cations, thus facilitated the production of Cooper pairs, which are responsible for the superconducting behavior. 

Superconductivity as a quantum phase of a strongly correlated system is often accompanied or compete with other quantum phases. In particular, the interplay between superconductivity and CDW states, i.e., collective macroscopic modulations of electron charge density, originated from electron-electron or electronphonon interactions, have been reported for many strongly correlated systems, including heavy-doped 2D materials<sup>189–191</sup> . By tuning carrier concentration, but also other system parameters, such as temperature, strain, pressure, electric field, etc., CDWs can often be created and controlled. 2D TMDs, such as MoS2, TiSe2, TaS2, and TaSe2 provide the platform to study competitive relationship between superconductivity and CDWs. Intercalationinduced transition to a superconductive phase in MoS2 through potassium (K) intercalation has been observed by Zhang et al.<sup>59,192</sup> . K intercalation was achieved through liquid-ammonia method<sup>193,194</sup> , and the phase transition from superconducting 2H to metallic 1T was observed on increasing the content of the K in the samples. Superconductivity in MoS2 samples was essentially achieved by inserting K atoms in between S-Mo-S layers. However, superconductivity disappeared while exposing the sample to air because of de-intercalation of K atoms. The tunable nature of superconducting transition, the existence of CDW, and strong spin–orbit coupling make the superconducting layered TMDs a class of fascinating materials. For example, it was observed that superconducting transition temperature (Tc) of pristine TaS2 increases from 0.8 K to the maximum 3.7 K, showing a dome-like behavior with electrochemical intercalation of cetyltrimethylammonium (CTA<sup>+</sup> ) into 2H-TaS2195. Figure 7f shows the susceptibility χ = M/H of MoS2 sample at different temperatures with increasing K concentration determined through energy-dispersive X-ray microanalysis<sup>59</sup> . Evolution of 2H-K0.4MoS2 phase from 2H-MoS2 was first observed at Tc ≈ 6.9 K for the average K concentration, c < 12 atom%. On increasing the K concentration, 2H-K0.4MoS2 phase undergoes a phase transition to 1T phase at Tc ≈ 2.8 K and finally to 1T’ phase at 4.6 K at higher K concentration up to c ≈ 25 atom% (see Fig. 7g). For c > 25 atom%, excess potassium causes a decomposition reaction, and the volume fraction of both the 2H and 1T′ phase starts to decrease, but Tc is not affected. This study demonstrates that K intercalation is responsible for both the structural and superconducting phase transition. Quantum phases have also been reported in other intercalated 2D materials, including quantum CDW phases in Na- or Rb-intercalated TaS2,<sup>196,197</sup> or chiral magnetic soliton (CSL) lattices in Cr- or Mnintercalated layered NbS2173,198. 

The electronic phase diagram of Cu intercalation in TaS2190 and TiSe2191 and is shown in Fig. 7h and Fig. 7i, respectively. The transition temperature of CDW is suppressed, and the new 

superconducting state emerges with the concentration of Cu intercalation. Superconducting transition temperature first increases and then decreases with the highest Cu intercalation in both compounds. However, both CDW and superconducting phases co-exist up to the medium Cu doping level. In order to clarify the relationship between superconductivity and CDW, Kogar et al. performed the X-ray diffraction studies to study the evolution of CDW in Cu-intercalated TiSe2199. It was found that incommensurate CDW and superconductivity coexist at a medium Cu intercalation, and CDW peaks were observed up to the higher concentration, x = 0.09. Furthermore, low-temperature scanning tunneling microscopy studies on CDW order of TiSe2 shows the presence of long-range coherent commensurate CDW in TiSe2 while Cu0.08TiSe2 shows the incommensurate CDW phase with localized commensurate CDW separated by domain walls<sup>200</sup> . These domain walls provide an extra population of fermions near the Fermi level, which might play a role in the emergence of superconductivity in this system. In a recent study, Wu et al. observed the suppression of CDWs and enhancement of superconductivity in 2D 2H-TaSe2 by Li-ion intercalation, tuned by ion gating mechanism<sup>155</sup> (see Fig. 4d–f). Moreover, the CDW phase transition mechanism has been further corroborated by Na intercalation into 1T- TaS2. Na intercalation into 1T-TaS2 was reported for controlled parameters such as Na flux and sample temperature. Different exposure of Na gives the formation of different charge-density-wave-related superstructures. Increasing the sample temperature induces a Ta 4f spectrum, which suggests a CDW after intercalation with similar charge distribution for the low-temperature phase. The Ta 4f levels splitting for the annealed intercalated sample are reported to have the same magnitude as for the clean sample in the commensurate phase at 150 K. Interestingly, for Na deposited at 300 K, the splitting of the Ta 4 f levels increases with increasing Na exposure, which suggests a strong interrelation of the Na/Ta ratio and a changed electronic structure. Comparison between 300 K and 150 K Na<sup>+</sup> incorporated into the vdW gap shows a higher value at 300 K. Pettenkofer et al. measurements show that the amount of Na is dependent on the CDW phase and electronic structure present in the intercalation process. The deposition at 150 K shows only a 10% Na/Ta ratio. However, in the Ta 5d-derived band, the Na-induced shifts of the Fermi-level position, which causes the emergence of a CDW phase in NaxTaS2.<sup>196</sup> . 

Intercalation is known to reduce the interlayer coupling of bulk MoTe2 and WTe2, resulting in a band-structural topology transition from a layered type-II Weyl semimetal to a weak topological insulator<sup>201</sup> (topological insulators are discussed separately in the section “Topological insulators”). Thus, intercalation method is an innovative strategy to control the dimensionality of TMDs with novel electronic states giving rise to superconductivity and complex bandstructure topology. The mechanism of enhanced superconductivity in intercalated TMDs can be attributed to the enhanced density of states near the Fermi level due to the breaking of the balance between the compensated electron and hole pockets. Additional phonon modes arising from the intercalants and enhanced screening of Coulomb interactions between electrons in TMD layers may also play an important role in enhancing Tc. 

### INTERCALATION EFFECTS ON INTERLAYER INTERACTIONS 

In addition to electrical doping, intercalation can also modify interlayer vdW interactions. This, in turn, can change the interlayer separation and have profound effects on various material properties. It can strongly affect the vibrational modes and electromagnetic absorption spectrum of the material. It can also enhance or decrease the interlayer transport of both electrical charges and heat. Finally, it can also effectively suppress the interlayer interactions and consequently produce the material composed of individual isolated layers, where the surface 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 30 

M. Rajapakse et al. 

13 

properties, such as in the case of topological insulators, become dominant. Here, we have a detailed discussion of the effects of interlayer interactions on thermoelectricity, electromagnetic wave absorption, and topological insulators. 

### Thermoelectricity 

Recently, intercalation into various layered materials, including graphite<sup>202,203</sup> , TiS253,204, MoS2205–207, and BP208, has been shown as an effective approach to modify thermal properties, including a significant reduction of the thermal conductance in these materials. Insertion of guest species into the vdW gaps can cause structural changes in layered materials. These intercalationinduced structural changes can be used to tune phonon propagation, thus changing the thermal properties of the material. For example, Sood et al. have demonstrated switchable thermal transistors (Fig. 8a), based on reversible electrochemical lithium intercalation in MoS2 thin films and have used first-principles calculations to show that the thermal conductance changes in such devices are due to phonon scattering by lithium rattler modes, c-axis strain, and stacking disorder<sup>207</sup> . In general, tunable thermal conductivity in intercalated layered materials is believed to be a result of the intercalation-controlled phonon scattering induced by structural and compositional disorders<sup>53,203,206–208</sup> . 

Thermoelectric figure of merit (ZT), or in other words, the ability to generate thermoelectric power for a given material is determined by ZT = σS<sup>2</sup> T/ρ where S, σ, ρ, and T are Seebeck coefficient, electrical conductivity, thermal conductivity, and absolute temperature, respectively<sup>144,209</sup> . One approach to enhance ZT is to reduce thermal conductivity while maintaining or increasing electrical conductivity. This can be easily achieved by intercalating ions, molecules, and atoms, etc., into the vdW gaps of host 2D materials<sup>210</sup> . Wan et al. has reported that intercalation of SnS layer into TiS2 resulting in an improved ZT in directions both parallel and normal to the host layers<sup>210</sup> . As a result of weakened interlayer bonding due to intercalation, sound velocity along the transverse direction was softened. It suppresses phonon transport as a result while simultaneously maintaining the electron mobility in the direction parallel to the layers. In addition, along the perpendicular direction to the layers, lattice thermal conductivity of the intercalated compound (SnS)1.2(TiS2)2 found to be smaller than the predicted minimum. This is because of the phonon localization due to translational disorder of SnS layers (intercalant) parallel to the host layers. 

Structural flexibility in thermoelectric materials is an important factor, especially when it comes to flexible electronics applications. However, many layered thermoelectric materials such as TiS2 suffer from high flexural modulus, which makes these materials less flexible. Intercalation of organic cations could reduce the flexural moduli of layered thermoelectric materials while also donating charge carriers to the lattice. For example, flexible hybrid superlattice was fabricated using organic cations ((hexylammonium)x(H2O)y(DMSO)z) as an intercalant. These organic cations provide the n-type carriers for current and energy transport. The ZT value for this organic-cation-intercalated-TiS2 compound found to be dramatically improved (0.28 in comparison to typical values less than 0.08) at 373 K<sup>53</sup> (Fig. 8b). 

### Electromagnetic wave absorption 

2D materials have shown promise for use in the absorption of electromagnetic waves (EMW) due to their large surface areas and surplus interfaces<sup>211</sup> . Intercalation can be used to expand the interlayer spacings of bulk precursors or to domicile guest atoms between interfaces to create EMW absorbers<sup>211,212</sup> . Ti3C2Tx MXenes intercalated with DMF yielded a large interlayer spacing between nanosheets relative to those treated with ethanol or DMSO. The DMF treated MXene thus, exhibited an approximate reflection loss value of −41.1 dB at 13.4 GHz, indicating their 

efficacy as highly effective dielectric materials for EMW absorption<sup>212</sup> . Feng et al.<sup>211</sup> synthesized a layered hybrid where TiO2 and NiO nanoparticles were dispersed between layers of Ni intercalated Ti3C2 (etched from Ti3AlC2) MXene by facile hydrothermal oxidation. This novel magnetic composite showed an impressive absorbing bandwidth of 11.1 GHz and 9 GHz at respective thicknesses of 3 and 2 mm. This behavior is derived from the amorphous nature of the as-synthesized sheets and multiple reflections. 

### Topological insulators 

Topological insulators (TI) are materials that are insulating in the interior but having exotic metallic (conductive) states on their surfaces. Group V–VI chalcogenide semiconductors such as Bi2Se3, Bi2Te3, and Sb2Te3 have gained a reputation recently as they consist of insulating bulk gaps and conductive Dirac surfaces. One of the main hurdles in the study of TI materials is the overwhelming bulk contributions that overshadow the topological surface phenomena<sup>213</sup> . Therefore, intercalation can be used as a tool to produce TIs with a higher surface-to-volume ratio where topological surface conductance is more pronounced. Intercalation of Cu into Bi2Se3 layers has been done experimentally, and it has been found that other than the aforementioned superconductivity (CuxBi2Se3), intercalation could also open the gaps in Bi2Se3 by breaking or weakening interlayer bonds in topological surface states. The structure of Bi2Se3 consists of five strongly bonded atomic layers of Se-Bi-Se-Bi-Se sandwiched together to form a quintuple layer. These quintuple layers are weakly bonded by vdW forces, and hence intercalation of guest species into these quintuple-layer-gaps is easily achievable<sup>187,188</sup> . In another study, Zhang et al. has reported transition of Weyl semimetals MoTe2 and WTe2 to topological insulator state upon organic cation intercalation<sup>201</sup> . Insertion of organic cations weakens the interlayer bonding, making the topological surface states more prominent. 

### INTERCALATION-INDUCED STRUCTURAL PHASE TRANSITIONS 

Intercalation can also lead to profound structural changes and structural phase transitions in 2D layered materials. Firstly, by weakening the interlayer interactions, it can facilitate the easy slippage between the layers allowing the change of the layer stacking. This can even lead to structural phase transitions and drastic changes of 2D material properties, such as in the case of 2H to 1T/1T’ transition in TMDs, where the material changes from semiconductor to a metallic state. Secondly, intercalation can also lead to charge transfer-mediated bond weakening, and reconstruction, followed by structural phase transition and formation of new phases, such as in the case of black-to-blue phosphorous transition. 

### Stacking order modifications and applications in catalysis 

During the intercalation, structure of the host material undergoes changes that can be explained through such processes as sliding of slabs, change of symmetry around the host network, and cation and anion shift. Coordination around the guest species is directly connected to slab gliding<sup>214</sup> . In this process, the structure of slabs does not change, and such gliding motions take place just to provide the most-steady environment for the intercalating element. For example, under Na intercalation, the atomistic structural evolution in BP shows a two-stage sodiation mechanism, in which the stacking order of BP changes (Fig. 9a). Increasing the concentration of intercalating Na atoms results in an increase of distortion in the middle layer. Also, amorphous stripes are found to be formed in BP during this sodiation process<sup>215</sup> . 

Perhaps one of the most studied processes of intercalationinduced structural transformation is the 2H—1T/1T’ phase transition in TMDs. An example is the intercalation of MoS2 with 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 30 

M. Rajapakse et al. 

14 



Fig. 8 Intercalation effects on MoS2 and TiS2. a Thermal conductance of MoS2 tuned by electrochemical Li-intercalation. Schematic illustration of cross-sectional view and optical micrograph of the 10 nm thick MoS2 device used for operando scanning thermal conductance measurements (top-left and center). Thermal conductance vs. voltage measured for this structure (top-right). Thermal conductance maps taken at different stages of lithiation and delithiation over one electrochemical cycle. (bottom). Calculations of the normalized cross-plane thermal conductance of a 10 nm thick MoS2 film plotted vs. % c-axis strain (%) relative to the pristine (unlithiated) 2H-MoS2 (right)<sup>207</sup> . b Synthesis and thermal properties of TiS2-based inorganic/organic TiS2[(HA)x(H2O)y(DMSO)z] superlattices. Schematic illustration of the synthesis process (top-left). In-plane thermal conductivity measured as a function of temperature for TiS2 single crystal and TiS2[(HA)0.08(H2O)0.22(DMSO)0.03] hybrid superlattice (top-right). Structural model of TiS2 single crystal and TiS2[(HA)0.08(H2O)0.22(DMSO)0.03] hybrid superlattice (bottom-left). Spectral energy density for bulk TiS2 single crystal and the TiS2 monolayer in the TiS2[(HA)0.08(H2O)0.22(DMSO)0.03] hybrid superlattice calculated using molecular dynamics simulations (bottom-right)<sup>53</sup> . Panel a reprinted with permission from Springer Nature Publications Nature Communicaton<sup>207</sup> , Copyright (2018), advance online publication 21 September 2018 (https://doi.org/ 10.1038/s41467-018-06760-7, Nat. Commun.). Panel b reused with permission from Springer Nature Publications Nature Materials<sup>53</sup> , Copyright (2015), advance online publication 19 February 2015 (https://doi.org/10.1038/nmat4251, Nat. Mater.). 

Li, which induces the phase transition from 2H-MoS2 to 1T-MoS2. During this process, the symmetry around the Mo atom changes, and the translation of atomic layers causes formation of octahedral slabs of 1T-MoS2 like in TiS2216. Leng et al. has shown that chemically-intercalated 1T- MoS2 undergoes further distortion to form 1T’ phase in order to lower the system energy, which can 

be seen by XRD as the shift of the (002) peak of 2H-MoS2 from 14.4° to 14.2 which corresponds to the (001) of Li-intercalated 1T’MoS2217. Similarly, in their recent study, Zhu et al. have reported the reversible phase transition between the 2H (semiconducting) and 1 T’ (metallic) phases of MoS2 by controlling the migration of Li<sup>+</sup> ions with an electric field<sup>218</sup> . As observed by Raman 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 30 

M. Rajapakse et al. 

15 



Fig. 9 Stacking order modifications induced by intercalation. a Stacking reordering of BP layer by Na intercalation<sup>215</sup> . b In situ TEM image of lithiation process of MoS2 nanosheet. (i, ii) Real time TEM images of the lithiation process showing propagation of the reaction front; (iii) edge area showing distortion of the layer structure; (iv–vi) in situ EDPs showing the evolution of the structure. EDP of pristine MoS2 (iv) shows 6-fold symmetry, followed with 2 × 2 superstructure reflections in (v) and diffraction spots of Li2S in (vi)<sup>220</sup> . c Schematic representation of phase transition from 1T-MoS2 to 2H-MoS2 using Ionic Liquid (ILs) interaction and deintercalation.<sup>225</sup> d Polarization curves of 2H-MoS2 and IL intercalated 1T-MoS2225. Panel a adapted with permission from ref. 215 Chemistry of Materials, 29, 1350–1356 (2017). Copyright (2017) American Chemical Society; panel b reprinted with permission from Springer Nature Publications Science China Chemistry<sup>220</sup> , Copyright (2018), advance online publication 29 August 2017 (https://doi.org/10.1007/s11426-017-9128-0, Sci. China Chem.); panels c, d reused with permission from John Wiley and Sons/Reddy Inta et al.<sup>225</sup> . 

spectroscopy, upon Li-intercalation, the natural pristine MoS2 which exists predominately in the 2H phase, develops peaks at 200, 225, and 355 cm<sup>−1</sup> which are characteristic of 1T’-MoS2. 

Considering the importance of understanding the mechanism of intercalation and phase transition of TMDs, researchers strive to develop in situ measurement systems. In this regard, Ji et al. have proposed a solid, doable methodology to investigate the intercalation of H-MoS2 monolayers in situ via scanning transmission electron microscopy (STEM). They have utilized energetic electron beam irradiation to release Li from Li2CO3 precursor to implement the lithiation of 2H-MoS2. In this research, the nucleation of T’ phase domains have been reported randomly and reversible, where T’ domains went back to the H phase by prolonged e-beam illumination<sup>219</sup> . In a similar experimental approach, Huang et al.<sup>220</sup> explained Li and Na intercalation-induced 2H to 1T phase transition mechanism using an in situ TEM study. TEM imaging showed that as the reaction proceeded, a reaction front propagated through the MoS2. As in Fig. 9b, an edge area shows the distortion of the layer structure. Comparison of TEM images taken before and after intercalation confirmed the phase transition. Pristine MoS2 showed a 6-fold symmetry, while lithiated sample showed a superstructure with 2-fold symmetry. With increasing Li concentration, more superstructures have appeared. 

To investigate the phase transition of MoS2 from 2H to 1T phase and simultaneous transformation of the electronic state from semiconducting to a metallic state upon alkali metal insertion, 

Enyashin et al. calculated the band structure of 1T-MoS2; the valence band and conduction band overlapped at K-point, showing fully metallic behavior of a material without a band gap which led to a significant drop in the absorption of 1T-LixMoS2 and increased electrical conductance<sup>221</sup> . 

Catalytic properties of TMDs can also be significantly enhanced by intercalation-assisted phase transitions, which can effectively shift the chemical potentials of 2D TMDs within a wide range, which is suitable for optimizing catalytic properties. For example, Li<sup>+</sup> -intercalated 2D MoS2 has exhibited an enhanced hydrogen evolution reaction (HER) efficiency<sup>222</sup> . In these cases, intercalated Li atoms transfer excess charge carriers to MoS2, which increases its charge carrier density, and thus its conductivity. Also, the structural phase transition into more stable octahedral coordination occurs to lower the electronic energy of the whole system. Consequently, the chemical potential of Li-intercalated MoS2 shifts, and HER performance is improved. In addition to the changes in electronic structures, intercalations often alter the structural phases of 2D TMDs to be more suitable for catalysts. For example, electrochemical intercalation of Li<sup>+</sup> has been shown to transform the 2H (semiconducting) phase of 2D MoS2 and WS2 into the 1T (metallic) phase, and such 1T-rich 2D TMDs have exhibited enhanced HER performance. For instance, Lukowski et al. has reported the synthesis of a flowerlike MoS2 nanostructure with a high density of exposed edges directly on graphite substrate via chemical vapor deposition method, followed by 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 30 

M. Rajapakse et al. 

16 



Fig. 10 Structural phase transition from black to blue phosphorene using Li intercalation. a Top and side view of layered black phosphorene, initial b and final c structure of Li intercalated black phosphorene, d final structure of black phosphorene after removing Li. 

soaking of as-grown 2H-MoS2 layers in n-BuLi solution at room temperature or 60 °C for 6–48 h to convert nanostructures into metallic 1T-MoS2 polymorph. HER activity of produced 1T-MoS2 nanosheets exfoliated after lithium intercalation at 60 °C for 48 h improved significantly, with 200 mA/cm<sup>2</sup> current density at −400 mV vs. RHE<sup>223</sup> . A similar concept has been demonstrated by Wang et al., where the HER activity of as-grown 2H-MoS2 catalyst was largely improved by Li electrochemical tuning with layer exfoliation and 1T phase formation. The enhanced catalyst obtained 200 mA/cm<sup>2</sup> cathodic current at only 200 mV over potential<sup>224</sup> . In addition, Inta et al. showed that increasing the interlayer spaces in MoS2 by intercalation of ionic liquid (IL) molecules into the MoS2 sheets, results in the formation of 1TMoS2 phase (Fig. 9c). As shown in Fig. 9d, HER electrocatalytic activity of IL-intercalated 1T-MoS2 has improved in comparison with 2H-MoS2 due to the existence of conducting basal planes, formed as a result of IL intercalation, which allowed to deliver current density of 50 mA/cm<sup>2</sup> at an over potential of 210 mV. Preparing 1T-MoS2 directly on carbon cloth (CC) provides better charge transport and low contact resistance resulting in better electrochemical performance<sup>225</sup> . 

### Charge transfer-mediated bond reconstruction 

Unlike MoS2, which shows a reversible phase transition, the complex transitional metal selenide, Cr4TiSe8, is an example of materials that undergo irreversible structural phase transition of the host after chemical and electrochemical intercalation. As a result of this intercalation, the structure of the host matrix changes from monoclinic to trigonal. Trigonal LixCrTi0.25Se2 has a structure like intercalated layered TMDs. This phase transition from monoclinic to trigonal has been investigated by Behrens et al.<sup>226</sup> , using energy-dispersive (ED) XRD. According to their report, intercalation of Cr4TiSe8 takes place in several steps; monoclinic Li0.1Cr4TiSe8 is formed at the first step, further Li concentration facilitates a phase transition and domains of trigonal LixCrTi0.25Se2 nucleate and grow. 

A recent theoretical study by Musa et al.<sup>227</sup> has shown that Liintercalation can lead to a structural phase transition from black to blue phosphorene in a two-step (lithiation and delithiation) process. In lithiation part, Li atom intercalated in black phosphorene act as a 

“catalyst” in the ‘reactive region’ of the lone pair of P atoms and breaks the P–P bonds in the arm-chair direction. This bondbreaking form a narrow nanoribbon like local structure. In the delithiation part, these nanoribbons join and form a blue phosphorene structure with interlayer separation of ~4.6 Å (Fig. 10). 

### CHALLENGES AND OPPORTUNITIES 

Intercalation is arguably one of the best tools in the quest for new material phases and properties. Even though the study of intercalation in 2D materials has opened new avenues of opportunities that can be used in numerous applications in future electronic devices, there exist a handful of hurdles in using these techniques in practical applications and mass production. Both opportunities and challenges are briefly overviewed in the following. 

As mentioned earlier, compared to other 2D fabrication methods, intercalation has been proven to be a promising approach in many aspects. It is a cost-effective and straightforward method compared to CVD. Also, material yield is larger and more uniform than conventional scotch-tape methods. Moreover, intercalation assisted exfoliation accommodate a large array of precursor materials, where precursor selection for other methods is somewhat limited by factors like, solubility, pressure, and temperature sensitivity. 

The ability to modify material properties via intercalation equips researchers with additional tools in their search of materials with enhanced properties and development of novel disruptive technologies. The ever-increasing demand for mobile electronics and portable energy storage needed to power it, continues to motive enormous scientific interests in electrochemical intercalation processes and intercalation-compatible materials. This includes studies toward electrochemical energy storage technologies beyond Li-ion batteries. For example, Na<sup>+</sup> and Mg<sup>2+</sup> ions have recently garnered attention as promising high-capacity and lowcost alternatives to Li-ion technology<sup>228</sup> . Therefore, intercalation, as the principle of portable energy storage devices will remain a highly active research and development area in the foreseeable future. Intercalation also presents excellent prospects in the tuning of atomically thin vdW materials, which are useful in fabricating electronic and memory devices<sup>229</sup> . The electron-electron and electron-phonon interactions of these vdW materials can be significantly tuned to exploit the impressive physics exhibited by 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 30 

M. Rajapakse et al. 

17 

them<sup>229</sup> . Intercalation-induced reversible phase transitions from semiconductor to metallic phases (as in MoS2 and other TMDs) is a good example illustrating that the same 2D material could switch between two states upon intercalation and de-intercalation. If intercalation/de-intercalation can be done electrochemically inside a device made of such 2D materials, the possible applications would be inconceivable. There have been intensive intercalationdependent studies in layered bulk materials, investigations on controlling the band structure, Fermi level, and various properties, such as electronic, optical, and magnetic, via intercalation mechanisms. Intercalation has been also widely explored as a tool to induce and control superconductivity and other strongly-correlated phases in 2D layered materials. For example, by introducing disorder in the crystal lattice, intercalation can lead to enhanced electron-phonon interactions and Cooper pairing. The emergence of quantum phases like CDWs and superconductivity is are worth studying in order to reveal in-depth insights and enable potential applications of these phenomena. It is also known that such effects are enhanced in low-dimensional systems<sup>230</sup> . Thus, intercalation serves that purpose as well by weakening/eliminating interlayer forces and lowering the dimensionality of bulk materials. Furthermore, fields like spintronics and quantum computing will benefit from the development of topological insulators. There are several 2D materials that are insulating in bulk but have exotic metallic states on their surfaces<sup>231</sup> . These topological surface states are better revealed by means of intercalation-assisted exfoliation. Further studies of intercalation reaction stage, intercalant species, host materials, and real-time in situ studies are needed in order to better understand the critical phenomena such as superconductivity and CDW phases. 

Although so many studies have been done on the intercalation of 2D materials, there are some challenges left that require more fundamental research in this rapidly growing field. Furthermore, intercalation chemistry is not clear enough in selecting the host and guest pair to achieve purposeful structural modification; thus, an in situ mechanism needs much more exploration to investigate the real-time structural changes during the intercalation process. This can be partly achieved by conducting comparative experiments using different intercalation schemes<sup>205</sup> . In addition, there is the need for an in-depth understanding of interactions between the intercalants and hosts atoms as they differ in diffusion dynamics<sup>205</sup> . There is also the complexity of the thickness of host materials. Host materials with minimal thickness are better intercalated as in the case of few layer BP where regimented doping can impressively modify its properties<sup>232</sup> . Design and development of such investigation methods could help to study and understand the mechanism of intercalation and properties of intercalated materials at a more fundamental level. 

There are instances where experimental intercalation results do not meet theoretically predicted outcomes. For example, firstprinciple calculations predict that Li intercalation could cause bond-breaking and rearrangement in BP in such a way that leads to a phase transition towards blue phosphorous. But in situ and ex situ electrochemical Li intercalations could not show this transition at experimental level<sup>22</sup> due to reasons, such as different than modeled distributions of Li ions or the parasitic side-reaction of lithium phosphide formation, which limited the attainable level of Li intercalation. Still, it is worth understanding such limitations and finding alternative ways to overcome these challenges, as this can lead to the emergence of novel properties and the development of novel structures. In the particular case of Liintercalated BP, this can result in a new method of synthesizing blue phosphorous, allowing for experimental studies of intriguing properties of this material<sup>233</sup> , like its wide band gap<sup>234</sup> , thermal characteristics<sup>235</sup> , high mobility<sup>236</sup> , and stable structure<sup>234</sup> . 

Development of high-efficient, cost-effective, and scalable intercalation methods is one of the important remaining challenges that still need to be addressed. In addition, so many 

intercalated 2D materials are unstable in air. Thus, stability is an overwhelming issue, especially when reactive intercalants, like alkali and alkali-earth metals, are used. Elemental quantification of the intercalated host material in such experiments is quite challenging, too. For example, in the case of the electrochemical Li intercalation into BP, concentrations of intercalated Li ions have been estimated based on quantities of starting materials used along with the current applied in the ex situ and in situ experiments<sup>22</sup> . The inhomogeneity of the intercalation across the flakes has proved to be challenging to factor in. However, conventional characterization schemes like Raman spectroscopy, electron microscopy, XRD, XPS, nuclear magnetic resonance (NMR), and a dazzling array of other methods can be used to verify the resulting structure or surface chemistry<sup>232</sup> . In addition, a rational design for in-depth structural, optical, thermal, electrical, and magnetic characterizations of the intercalation process of these layered materials is essential for exploring the relationship between intercalation mechanism and property changes. 

### DATA AVAILABILITY 

Data sharing was not applicable to this paper, as no original datasets were generated or analyzed for this review. 

Received: 22 October 2020; Accepted: 16 February 2021; 



### REFERENCES 

1. Gupta, A., Sakthivel, T. & Seal, S. Recent development in 2D materials beyond graphene. Prog. Mater. Sci. 73, 44–126 (2015). 

2. Qiu, M. et al. Omnipotent phosphorene: a next-generation, two-dimensional nanoplatform for multidisciplinary biomedical applications. Chem. Soc. Rev. 47, 5588–5601 (2018). 

3. Teshome, T. & Datta, A. Effect of doping in controlling the structure, reactivity, and electronic properties of pristine and Ca(II)-intercalated layered silicene. J. Phys. Chem. C. 121, 15169–15180 (2017). 

4. Jamdagni, P., Kumar, A., Sharma, M., Thakur, A. & Ahluwalia, P. K. Electronic properties and STM images of vacancy clusters and chains in functionalized silicene and germanene. Phys. E 85, 65–73 (2017). 

5. Zhu, X. L. et al. Alkaline intercalation of Ti3C2 MXene for simultaneous electrochemical detection of Cd(II), Pb(II), Cu(II) and Hg(II). Electrochim. Acta 248, 46–57 (2017). 

6. Jung, Y., Zhou, Y. & Cha, J. J. Intercalation in two-dimensional transition metal chalcogenides. Inorg. Chem. Front 3, 452–463 (2016). 

7. Chen, D., Tang, L. H. & Li, J. H. Graphene-based materials in electrochemistry. Chem. Soc. Rev. 39, 3157–3180 (2010). 

8. Xu, C. H. et al. Graphene-based electrodes for electrochemical energy storage. Energ. Environ. Sci. 6, 1388–1414 (2013). 

9. Raccichini, R., Varzi, A., Passerini, S. & Scrosati, B. The role of graphene for electrochemical energy storage. Nat. Mater. 14, 271–279 (2015). 

10. Bae, S. et al. Roll-to-roll production of 30-inch graphene films for transparent electrodes. Nat. Nanotechnol. 5, 574–578 (2010). 

11. Ge, J. F. et al. Superconductivity above 100 K in single-layer FeSe films on doped SrTiO3. Nat. Mater. 14, 285–289 (2015). 

12. Grigorenko, A. N., Polini, M. & Novoselov, K. S. Graphene plasmonics. Nat. Photonics 6, 749–758 (2012). 

13. Deng, D. H. et al. Catalysis with two-dimensional materials and their heterostructures. Nat. Nanotechnol. 11, 218–230 (2016). 

14. Chen, J. Z. et al. One-pot synthesis of CdS nanocrystals hybridized with singlelayer transition-metal dichalcogenide nanosheets for efficient photocatalytic hydrogen evolution. Angew. Chem. Int. Ed. 54, 1210–1214 (2015). 

15. Xu, J. T. et al. Recent progress in graphite intercalation compounds for rechargeable metal (Li, Na, K, Al)-ion batteries. Adv. Sci. 4, 1700146 (2017). 

16. Müller, F., Stöwe, K. & Sachdev, H. Symmetry versus commensurability: epitaxial growth of hexagonal boron nitride on Pt (111) from B-trichloroborazine (ClBNH) 3. Chem. Mater. 17, 3464–3467 (2005). 

17. Stark, M. S., Kuntz, K. L., Martens, S. J. & Warren, S. C. Intercalation of layered materials from bulk to 2D. Adv. Mater. 31, 1808213 (2019). 

18. Dresselhaus, M. S. & Dresselhaus, G. Intercalation compounds of graphite. Adv. Phys. 51, 1–186 (2002). 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 30 

M. Rajapakse et al. 

18 

19. Pruvost, S., Berger, P., Herold, C. & Lagrange, P. Nuclear microanalysis: an efficient tool to study intercalation compounds containing lithium. Carbon 42, 2049–2056 (2004). 

20. Bissessur, R. & Scully, S. F. Intercalation of solid polymer electrolytes into graphite oxide. Solid State Ion. 178, 877–882 (2007). 

21. Zhou, D. et al. SiO2 hollow nanosphere-based composite solid electrolyte for lithium metal batteries to suppress lithium dendrite growth and enhance cycle life. Adv. Energy Mater. 6, 1502214 (2016). 

22. Rajapakse, M. et al. Electrochemical Li intercalation in black phosphorous: in-situ and ex-situ studies. J. Phys. Chem. C. 124, 10710–10718 (2020). 

23. Xu, K. Nonaqueous liquid electrolytes for lithium-based rechargeable batteries. Chem. Rev. 104, 4303–4417 (2004). 

24. Zheng, H. H., Jiang, K., Abe, T. & Ogumi, Z. Electrochemical intercalation of lithium into a natural graphite anode in quaternary ammonium-based ionic liquid electrolytes. Carbon 44, 203–210 (2006). 

25. Li, X. L. & Li, Y. D. MoS2 nanostructures: synthesis and electrochemical Mg<sup>2+</sup> intercalation. J. Phys. Chem. B 108, 13893–13900 (2004). 

26. Sun, L. Q. et al. Electrochemical activity of black phosphorus as an anode material for lithium-ion batteries. J. Phys. Chem. C. 116, 14772–14779 (2012). 

27. Morales, J., Santos, J. & Tirado, J. L. Electrochemical studies of lithium and sodium intercalation in MoSe2. Solid State Ion-. 83, 57–64 (1996). 

28. Shokhen, V. & Zitoun, D. Electrochemical intercalation of sodium in vertically aligned molybdenum disulfide for hydrogen evolution reaction. Flatchem 14, 100086 (2019). 

29. Shioyama, H. & Fujii, R. Electrochemical reactions of stage-1 sulfuric-acid graphite-intercalation compound. Carbon 25, 771–774 (1987). 

30. Zhao, S. Y. F. et al. Controlled electrochemical intercalation of graphene/h-BN van der Waals heterostructures. Nano Lett. 18, 460–466 (2018). 

31. Södergren, S. et al. Lithium intercalation in nanoporous anatase TiO2 studied with XPS. J. Phys. Chem. B 101, 3087–3090 (1997). 

32. Kim, S., Cui, J., Dravid, V. P. & He, K. Orientation‐dependent intercalation channels for lithium and sodium in black phosphorus. Adv. Mater. 31, 1904623 (2019). 

33. Xia, W. et al. Visualizing the electrochemical lithiation/delithiation behaviors of black phosphorus by in situ transmission electron microscopy. J. Phys. Chem. C. 120, 5861–5868 (2016). 

34. Sun, J. et al. A phosphorene–graphene hybrid material as a high-capacity anode for sodium-ion batteries. Nat. Nanotechnol. 10, 980–985 (2015). 

35. Zhang, J. et al. Reversible and selective ion intercalation through the top surface of few-layer MoS2. Nat. Commun. 9, 1–9 (2018). 

36. Schöllhorn, R. in Progress in Intercalation Research 1–81 (Springer, 1994). 

37. Bohnke, O., Bohnke, C. & Fourquet, J. Mechanism of ionic conduction and electrochemical intercalation of lithium into the perovskite lanthanum lithium titanate. Solid State Ion-. 91, 21–31 (1996). 

38. Giarola, M. et al. Structure and vibrational dynamics of NASICON-type LiTi2(PO4)3. J. Phys. Chem. C. 121, 3697–3706 (2017). 

39. Thangadurai, V., Kaack, H. & Weppner, W. J. Novel fast lithium ion conduction in garnet‐type Li5La3M2O12 (M = Nb, Ta). J. Am. Ceram. Soc. 86, 437–440 (2003). 

40. Ebert, L. B. Intercalation compounds of graphite. Annu Rev. Mater. Sci. 6, 181–211 (1976). 

41. Abellan, G. et al. Exploring the formation of black phosphorus intercalation compounds with alkali metals. Angew. Chem. Int Ed. 56, 15267–15273 (2017). 

42. Disalvo, F. J., Hull, G. W., Schwartz, L. H., Voorhoev, J. M. & Waszczak, J. V. Metal intercalation compounds of TaS2—preparation and properties. J. Chem. Phys. 59, 1922–1929 (1973). 

43. Endo, M., Yamanashi, H., Doll, G. L. & Dresselhaus, M. S. Preparation and electrical-properties of bromine intercalated vapor-grown carbon-fibers. J. Appl Phys. 64, 2995–3004 (1988). 

44. Kumari, L., Prasad, V. & Subramanyam, S. V. Effect of iodine incorporation on the electrical properties of amorphous conducting carbon films. Carbon 41, 1841–1846 (2003). 

45. Fujiwara, A. et al. Two effects of Iodine Intercalation on Tc in Bi2Sr2Ca1X<sup>Y</sup> X<sup>Cu</sup> 2<sup>O</sup> 8<sup>—two-dimensionalityandcharge-transfer.Phys.C.208,29–37(1993).</sup> 

46. Markus, B. G. et al. Improved alkali intercalation of carbonaceous materials in ammonia solution. Phys. Status Solidi B 256, 1900324 (2019). 

47. Mashtalir, O. et al. Intercalation and delamination of layered carbides and carbonitrides. Nat. Commun. 4, 1–7 (2013). 

48. Emery, N. et al. Superconductivity of bulk CaC6. Phys. Rev. Lett. 95, 087003 (2005). 

49. Zhang, Q., Mei, L., Cao, X., Tang, Y. & Zeng, Z. Intercalation and exfoliation chemistry of transition metal dichalcogenides. J. Mater. Chem. A 8, 15417–15444 (2020). 

50. Evans, J. S., Price, S. J., Wong, H.-V. & O’Hare, D. Kinetic study of the intercalation of cobaltocene by layered metal dichalcogenides with time-resolved in situ X- ray powder diffraction. J. Am. Chem. Soc. 120, 10837–10846 (1998). 

51. Mashtalir, O., Lukatskaya, M. R., Zhao, M. Q., Barsoum, M. W. & Gogotsi, Y. Amineassisted delamination of Nb2C MXene for Li-ion energy storage devices. Adv. Mater. 27, 3501–3506 (2015). 

52. Sekhar, N. C. & Varghese, L. A. Mechanical, thermal, and rheological studies of phenolic resin modified with intercalated graphite prepared via liquid phase intercalation. Polym. Test. 79, 106010 (2019). 

53. Wan, C. L. et al. Flexible n-type thermoelectric materials by organic intercalation of layered transition metal dichalcogenide TiS2. Nat. Mater. 14, 622–627 (2015). 

54. Koski, K. J. et al. High-density chemical intercalation of zero-valent copper into Bi2Se3 nanoribbons. J. Am. Chem. Soc. 134, 7584–7587 (2012). 

55. Pan, Y. et al. Schottky barriers in bilayer phosphorene transistors. ACS Appl. Mater. Interfaces 9, 12694–12705 (2017). 

56. Motter, J. P., Koski, K. J. & Cui, Y. General strategy for zero-valent intercalation into two-dimensional layered nanomaterials. Chem. Mater. 26, 2313–2317 (2014). 

57. Wang, M. J. & Koski, K. J. Reversible Chemochromic MoO3 nanoribbons through zerovalent metal intercalation. Acs Nano 9, 3226–3233 (2015). 

58. Chen, K. P., Chung, F. R., Wang, M. J. & Koski, K. J. Dual element intercalation into 2D layered Bi2Se3 nanoribbons. J. Am. Chem. Soc. 137, 5431–5437 (2015). 

59. Zhang, R. Y. et al. Superconductivity in potassium-doped metallic polymorphs of MoS2. Nano Lett. 16, 629–636 (2016). 

60. Zhang, R., Waters, J., Geim, A. K. & Grigorieva, I. V. Intercalant-independent transition temperature in superconducting black phosphorus. Nat. Commun. 8, 1–7 (2017). 

61. Millange, F., Walton, R. I., Lei, L. X. & O’Hare, D. Efficient separation of terephthalate and phthalate anions by selective ion-exchange intercalation in the layered double hydroxide Ca2Al(OH)6.NO3.2H2O. Chem. Mater. 12, 1990–1994 (2000). 

62. Fogg, A. M., Dunn, J. S., Shyu, S. G., Cary, D. R. & O’Hare, D. Selective ionexchange intercalation of isomeric dicarboxylate anions into the layered double hydroxide [LiAl2(OH)(6)]Cl center dot H2O. Chem. Mater. 10, 351–355 (1998). 

63. Costantino, U., Vivani, R., Bastianini, M., Costantino, F. & Nocchetti, M. Ion exchange and intercalation properties of layered double hydroxides towards halide anions. Dalton Trans. 43, 11587–11596 (2014). 

64. Friend, R. H. & Yoffe, A. D. Electronic-properties of intercalation complexes of the transition-metal dichalcogenides. Adv. Phys. 36, 1–94 (1987). 

65. Novoselov, K. S. et al. Electric field effect in atomically thin carbon films. Science 306, 666–669 (2004). 

66. Nicolosi, V., Chhowalla, M., Kanatzidis, M. G., Strano, M. S. & Coleman, J. N. Liquid exfoliation of layered materials. Science 340, 1226419 (2013). 

67. Chhowalla, M. et al. The chemistry of two-dimensional layered transition metal dichalcogenide nanosheets. Nat. Chem. 5, 263–275 (2013). 

68. Peng, L. et al. An iron-based green approach to 1-h production of single-layer graphene oxide. Nat. commun. 6, 1–9 (2015). 

69. Cai, X., Luo, Y., Liu, B. & Cheng, H.-M. Preparation of 2D material dispersions and their applications. Chem. Soc. Rev. 47, 6224–6266 (2018). 

70. Hummers, W. S. Jr & Offeman, R. E. Preparation of graphitic oxide. J. Am. Chem. Soc. 80, 1339–1339 (1958). 

71. Stankovich, S. et al. Synthesis of graphene-based nanosheets via chemical reduction of exfoliated graphite oxide. Carbon 45, 1558–1565 (2007). 

72. Okino, F. & Bartlett, N. Hexafluoroarsenates of graphite from its interaction with AsF5′AsF5+ F2′ and O2AsF6′ and the structure of C14AsF6. Dalton Trans. 2081–2090 (1993). 

73. Shih, C.-J. et al. Understanding surfactant/graphene interactions using a graphene field effect transistor: relating molecular structure to hysteresis and carrier mobility. Langmuir 28, 8579–8586 (2012). 

74. Tao, P. et al. Recent advances in exfoliation techniques of layered and nonlayered materials for energy conversion and storage. J. Mater. Chem. A 7, 23512–23536 (2019). 

75. Eda, G. et al. Photoluminescence from chemically exfoliated MoS2. Nano Lett. 11, 5111–5116 (2011). 

76. Zeng, Z. et al. Single‐layer semiconducting nanosheets: high‐yield preparation and device fabrication. Angew. Chem. Int. Ed. 123, 11289–11293 (2011). 

77. Zheng, J. et al. High yield exfoliation of two-dimensional chalcogenides using sodium naphthalenide. Nat. commun. 5, 1–7 (2014). 

78. Yin, Y. et al. Contributions of phase, sulfur vacancies, and edges to the hydrogen evolution reaction catalytic activity of porous molybdenum disulfide nanosheets. J. Am. Chem. Soc. 138, 7965–7972 (2016). 

79. Koike, Y., Suematsu, H., Higuchi, K. & Tanuma, S.-i Superconductivity in graphitepotassium intercalation compound C8K. Solid State Commun. 27, 623–627 (1978). 

80. Sumiyoshi, A., Hyodo, H., Sato, Y., Terauchi, M. & Kimura, K. Good reproductive preparation method of Li-intercalated hexagonal boron nitride and transmission electron microscopy–electron energy loss spectroscopy analysis. Solid State Sci. 47, 68–72 (2015). 

81. Ma, R. Z. & Sasaki, T. Nanosheets of oxides and hydroxides: ultimate 2D chargebearing functional crystallites. Adv. Mater. 22, 5082–5104 (2010). 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 30 

M. Rajapakse et al. 

19 

82. Wang, Q. & O’Hare, D. Recent advances in the synthesis and application of layered double hydroxide (LDH) nanosheets. Chem. Rev. 112, 4124–4155 (2012). 

83. Muñoz, R. & Gómez‐Aleixandre, C. Review of CVD synthesis of graphene. Chem. Vap. Depos. 19, 297–322 (2013). 

84. Zhang, Y. et al. Recent progress in CVD growth of 2D transition metal dichalcogenides and related heterostructures. Adv. Mater. 31, 1901694 (2019). 

85. Abbott’s, I. E. Graphene: exploring carbon flatland. Phys. Today 60, 35 (2007). 

86. Jayasena, B. & Subbiah, S. A novel mechanical cleavage method for synthesizing few-layer graphenes. Nanoscale Res. Lett. 6, 95 (2011). 

87. Le, T.-H., Oh, Y., Kim, H. & Yoon, H. Exfoliation of 2D materials for energy and environmental applications. Chem. Eur. J. 26, 6360 (2020). 

88. Kamali, A. R. & Fray, D. J. Molten salt corrosion of graphite as a possible way to make carbon nanostructures. Carbon 56, 121–131 (2013). 

89. Tang, L. et al. Bottom-up synthesis of large-scale graphene oxide nanosheets. J. Mater. Chem. 22, 5676–5683 (2012). 

90. Dikin, D. A. et al. Preparation and characterization of graphene oxide paper. Nature 448, 457–460 (2007). 

91. Dreyer, D. R., Park, S., Bielawski, C. W. & Ruoff, R. S. The chemistry of graphene oxide. Chem. Soc. Rev. 39, 228–240 (2010). 

92. Tan, C. et al. Recent advances in ultrathin two-dimensional nanomaterials. Chem. Rev. 117, 6225–6331 (2017). 

93. Lee, E., VahidMohammadi, A., Yoon, Y. S., Beidaghi, M. & Kim, D.-J. Twodimensional vanadium carbide MXene for gas sensors with ultrahigh sensitivity toward nonpolar gases. ACS Sens 4, 1603–1611 (2019). 

94. Li, D. J., Danilov, D. L., Gao, L., Yang, Y. & Notten, P. H. L. Degradation mechanisms of the graphite electrode in C6/LiFePO4 batteries unraveled by a non-destructive approach. J. Electrochem Soc. 163, A3016–A3021 (2016). 

95. Winter, M., Barnett, B. & Xu, K. Before Li ion batteries. Chem. Rev. 118, 11433–11456 (2018). 

96. Read, J. A., Cresce, A. V., Ervin, M. H. & Xu, K. Dual-graphite chemistry enabled by a high voltage electrolyte. Energ. Environ. Sci. 7, 617–620 (2014). 

97. Whittingham, M. S. Electrical energy-storage and intercalation chemistry. Science 192, 1126–1127 (1976). 

98. Wilson, J. A. & Yoffe, A. D. The transition metal dichalcogenides discussion and interpretation of the observed optical, electrical and structural properties. Adv. Phys. 18, 193–335 (1969). 

99. Whittingham, M. S. Hydrated intercalation complexes of layered disulfides. Mater. Res Bull. 9, 1681–1690 (1974). 

100. Whittingham, M. S. Ionic motion in electronic conductors. J. Electrochem Soc. 121, C101–C101 (1974). 

101. Thompson, A. H. Electron-electron scattering in TiS2. Phys. Rev. Lett. 35, 1786–1789 (1975). 

102. Thompson, A. H., Gamble, F. R. & Symon, C. R. Verification of existence of TiS2. Mater. Res Bull. 10, 915–919 (1975). 

103. Whittingham, M. S. Chemistry of intercalation compounds—metal guests in chalcogenide hosts. Prog. Solid State Ch 12, 41–99 (1978). 

104. Johnson, W. B. & Worrell, W. L. Lithium and sodium intercalated dichalcogenides —properties and electrode applications. Synth. Met 4, 225–248 (1982). 

105. Deng, Y. et al. Gate-tunable room-temperature ferromagnetism in twodimensional Fe3GeTe2. Nature 563, 94–99 (2018). 

106. Gu, Y., Katsura, Y., Yoshino, T., Takagi, H. & Taniguchi, K. Rechargeable magnesium-ion battery based on a TiSe2-cathode with d-p orbital hybridized electronic structure. Sci. Rep. 5, 1–9 (2015). 

107. Li, P. et al. Electrochemical potassium/lithium-ion intercalation into TiSe2: kinetics and mechanism. Energy Storage Mater. 16, 512–518 (2019). 

108. Qian, J., Wu, X., Cao, Y., Ai, X. & Yang, H. High capacity and rate capability of amorphous phosphorus for sodium ion batteries. Angew. Chem. Int. Ed. 52, 4633–4636 (2013). 

109. Dai, J. & Zeng, X. C. Bilayer phosphorene: effect of stacking order on bandgap and its potential applications in thin-film solar cells. J. Phys. Chem. Lett. 5, 1289–1293 (2014). 

110. Wang, X. et al. Highly anisotropic and robust excitons in monolayer black phosphorus. Nat. Nanotechnol. 10, 517–521 (2015). 

111. Ge, S., Zhang, L., Wang, P. & Fang, Y. Intense, stable and excitation wavelengthindependent photoluminescence emission in the blue-violet region from phosphorene quantum dots. Sci. Rep. 6, 27307 (2016). 

112. Gao, L.-F. et al. Small molecule-assisted fabrication of black phosphorus quantum dots with a broadband nonlinear optical response. Nanoscale 8, 15132–15136 (2016). 

113. Park, C. M. & Sohn, H. J. Black phosphorus and its composite for lithium rechargeable batteries. Adv. Mater. 19, 2465–2468 (2007). 

114. Li, W. et al. Confined amorphous red phosphorus in MOF‐derived N‐doped microporous carbon as a superior anode for sodium‐ion battery. Adv. Mater. 29, 1605820 (2017). 

115. Hou, H. et al. Efficient storing energy harvested by triboelectric nanogenerators using a safe and durable all‐solid‐state sodium‐ion battery. Adv. Sci. 4, 1700072 (2017). 

116. Luo, J. et al. Graphene-roll-wrapped Prussian blue nanospheres as a highperformance binder-free cathode for sodium-ion batteries. ACS Appl. Mater. Interfaces 9, 25317–25322 (2017). 

117. Xu, Y. et al. Layer‐by‐layer Na3V2(PO4)3 embedded in reduced graphene oxide as superior rate and ultralong‐life sodium‐ion battery cathode. Adv. Energy Mater. 6, 1600389 (2016). 

118. Sheng, M., Zhang, F., Ji, B., Tong, X. & Tang, Y. A novel tin‐graphite dual‐ion battery based on sodium‐ion electrolyte with high energy density. Adv. Energy Mater. 7, 1601963 (2017). 

119. Balogun, M.-S., Luo, Y., Qiu, W., Liu, P. & Tong, Y. A review of carbon materials and their composites with alloy metals for sodium ion battery anodes. Carbon 98, 162–178 (2016). 

120. Chaudhari, N. K. et al. MXene: an emerging two-dimensional material for future energy conversion and storage applications. J. Mater. Chem. A 5, 24564–24579 (2017). 

121. Verger, L., Natu, V., Carey, M. & Barsoum, M. W. MXenes: an introduction of their synthesis, select properties, and applications. Trends Chem. 1, 656–669 (2019). 

122. de Castro, I. A. et al. Molybdenum oxides—from fundamentals to functionality. Adv. Mater. 29, 1701619 (2017). 

123. Julien, C., Mauger, A., Vijh, A. & Zaghib, K. in Lithium Batteries 29–68 (Springer, 2016). 

124. Lukatskaya, M. R., Dunn, B. & Gogotsi, Y. Multidimensional materials and device architectures for future hybrid energy storage. Nat. Commun. 7, 1–13 (2016). 

125. Mahmood, Q. et al. Unveiling surface redox charge storage of interacting twodimensional heteronanosheets in hierarchical architectures. Nano Lett. 15, 2269–2277 (2015). 

126. Augustyn, V. et al. High-rate electrochemical energy storage through Li<sup>+</sup> intercalation pseudocapacitance. Nat. Mater. 12, 518–522 (2013). 

127. Chen, D. Y. et al. In situ nitrogenated graphene-few-layer WS2 composites for fast and reversible Li<sup>+</sup> storage. Nanoscale 5, 7890–7896 (2013). 

128. Acerce, M., Voiry, D. & Chhowalla, M. Metallic 1T phase MoS2 nanosheets as supercapacitor electrode materials. Nat. Nanotechnol. 10, 313–318 (2015). 

129. Peng, L. et al. Effective interlayer engineering of two-dimensional VOPO4 nanosheets via controlled organic intercalation for improving alkali ion storage. Nano Lett. 17, 6273–6279 (2017). 

130. Zhu, Y., Peng, L. L., Chen, D. H. & Yu, G. H. Intercalation pseudocapacitance in ultrathin VOPO4 nanosheets: toward high-rate alkali-ion-based electrochemical energy storage. Nano Lett. 16, 742–747 (2016). 

131. Brezesinski, T., Wang, J., Tolbert, S. H. & Dunn, B. Ordered mesoporous alphaMoO3 with iso-oriented nanocrystalline walls for thin-film pseudocapacitors. Nat. Mater. 9, 146–151 (2010). 

132. Li, W., Cheng, F., Tao, Z. & Chen, J. Vapor-transportation preparation and reversible lithium intercalation/deintercalation of α-MoO3 microrods. J. Phys. Chem. B 110, 119–124 (2006). 

133. Li, K. et al. 3D MXene architectures for efficient energy storage and conversion. Adv. Funct. Mater. 30, 2000842 (2020). 

134. Li, K. et al. All-pseudocapacitive asymmetric MXene-carbon-conducting polymer supercapacitors. Nano Energy 75, 104971 (2020). 

135. Li, K. et al. An ultrafast conducting polymer@MXene positive electrode with high volumetric capacitance for advanced asymmetric supercapacitors. Small 16, 1906851 (2020). 

136. Deysher, G. et al. Synthesis of Mo4VAlC4 MAX phase and two-dimensional Mo4VC4 MXene with five atomic layers of transition metals. Acs Nano 14, 204–217 (2020). 

137. Shen, L. et al. Carbon-intercalated Ti3C2Tx MXene for high-performance electrochemical energy storage. J. Mater. Chem. A 6, 23513–23520 (2018). 

138. Li, X. L., Wang, X. R., Zhang, L., Lee, S. W. & Dai, H. J. Chemically derived, ultrasmooth graphene nanoribbon semiconductors. Science 319, 1229–1232 (2008). 

139. Wang, F. et al. Gate-variable optical transitions in graphene. Science 320, 206–209 (2008). 

140. Bao, W. et al. Stacking-dependent band gap and quantum transport in trilayer graphene. Nat. Phys. 7, 948–952 (2011). 

141. Feng, J., Qian, X. F., Huang, C. W. & Li, J. Strain-engineered artificial atom as a broad-spectrum solar energy funnel. Nat. Photonics 6, 865–871 (2012). 

142. Akhtar, M. et al. Bilayer phosphorene under high pressure: in situ Raman spectroscopy. Phys. Chem. Chem. Phys. 21, 7298–7304 (2019). 

143. Zeng, Z. Y. et al. An effective method for the fabrication of few-layer-thick inorganic nanosheets. Angew. Chem. Int Ed. 51, 9052–9056 (2012). 

144. Wan, J. Y. et al. Tuning two-dimensional nanomaterials by intercalation: materials, properties and applications. Chem. Soc. Rev. 45, 6742–6765 (2016). 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 30 

M. Rajapakse et al. 

20 

145. Hérold, C., Hérold, A. & Lagrange, P. New synthesis routes for donor-type graphite intercalation compounds. J. Phys. Chem. Solids 57, 655–662 (1996). 

146. Sorokina, N., Nikol’skaya, I., Ionov, S. & Avdeev, V. Acceptor-type graphite intercalation compounds and new carbon materials based on them. Russ. Chem. Bull. 54, 1749–1767 (2005). 

147. Dresselhaus, M. S. Intercalation in Layered Materials, Vol. 148. (Springer, 2013). 

148. Kühne, M. Lithium Intercalation in Bilayer Graphene Devices (Springer, 2018). 

149. Yang, C. S. et al. A synaptic transistor based on quasi-2D molybdenum oxide. Adv. Mater. 29, 1700906 (2017). 

150. Yang, C.-S. et al. All-solid-state synaptic transistor with ultralow conductance for neuromorphic computing. Adv. Funct. Mater. 28, 1804170 (2018). 

151. Sharbati, M. T. et al. Low-power, electrochemically tunable graphene synapses for neuromorphic computing. Adv. Mater. 30, 1802353 (2018). 

152. Che, X. et al. Gate-tunable electrical transport in thin 2M-WS2 flakes. Adv. Electron. Mater. 5, 1900462 (2019). 

153. Yu, Y. et al. Gate-tunable phase transitions in thin flakes of 1T-TaS2. Nat. Nanotechnol. 10, 270–276 (2015). 

154. Wu, Y. et al. Lithium ion intercalation in thin crystals of hexagonal TaSe2 gated by a polymer electrolyte. Appl. Phys. Lett. 112, 023502 (2018). 

155. Wu, Y. et al. Ion intercalation engineering of electronic properties of twodimensional crystals of 2H−TaSe2. Phys. Rev. Mater. 3, 104003 (2019). 

156. Kang, S. et al. 2D semiconducting materials for electronic and optoelectronic applications: potential and challenge. 2d Mater. 7, 022003 (2020). 

157. Hantanasirisakul, K. et al. Effects of synthesis and processing on optoelectronic properties of titanium carbonitride MXene. Chem. Mater. 31, 2941–2951 (2019). 

158. Huang, P.-R., He, Y., Cao, C. & Lu, Z.-H. Impact of lattice distortion and electron doping on α-MoO3 electronic structure. Sci. Rep. 4, 7131 (2014). 

159. Alsaif, M. M. Y. A. et al. High-performance field effect transistors using electronic inks of 2D molybdenum oxide nanoflakes. Adv. Funct. Mater. 26, 91–100 (2016). 

160. Ou, J. Z., Campbell, J. L., Yao, D., Wlodarski, W. & Kalantar-Zadeh, K. In situ Raman spectroscopy of H2 gas interaction with layered MoO3. J. Phys. Chem. C. 115, 10757–10763 (2011). 

161. Yao, J. et al. Optical transmission enhacement through chemically tuned twodimensional bismuth chalcogenide nanoplates. Nat. Commun. 5, 5670 (2014). 

162. Xiong, F. et al. Li Intercalation in MoS2: in situ observation of its dynamics and tuning optical and electrical properties. Nano Lett. 15, 6777–6784 (2015). 

163. Wan, J. et al. In situ investigations of Li-MoS2 with planar batteries. Adv. Energy Mater. https://doi.org/10.1002/aenm.201401742 (2015). 

164. Bao, W. et al. Approaching the limits of transparency and conductivity in graphitic materials through lithium intercalation. Nat. Commun. 5, 4224 (2014). 

165. Quan, L. et al. The electromagnetic absorption of a Na-ethylenediamine graphite intercalation compound. ACS Appl. Mater. Interfaces 12, 16841–16848 (2020). 

166. Kumar, P., Skomski, R. & Pushpa, R. Magnetically ordered transition-metalintercalated WSe2. ACS Omega 2, 7985–7990 (2017). 

167. Le, D. et al. Spin–orbit coupling in the band structure of monolayer WSe2. J. Phys. Condens. Matter 27, 182201 (2015). 

168. Yuan, H. et al. Zeeman-type spin splitting controlled by an electric field. Nat. Phys. 9, 563–569 (2013). 

169. Skomski, R., Kashyap, A. & Enders, A. Is the magnetic anisotropy proportional to the orbital moment? J. Appl Phys. 109, 07E143 (2011). 

170. Bruno, P. Tight-binding approach to the orbital magnetic moment and magnetocrystalline anisotropy of transition-metal monolayers. Phys. Rev. B 39, 865 (1989). 

171. Dresselhaus, M. S. Intercalation in layered materials. MRS Bull. 12, 24–28 (1987). 172. Gamble, F. R. et al. Intercalation complexes of lewis bases and layered sulfides: a large class of new superconductors. Science 174, 493 (1971). 

173. Dai, Y. et al. Critical phenomenon and phase diagram of Mn-intercalated layered MnNb3S6. J. Phys. Condens. Matter 31, 195803 (2019). 

174. Han, H. et al. Tricritical point and phase diagram based on critical scaling in the monoaxial chiral helimagnet Cr1/3NbS2. Phys. Rev. B 96, 094439 (2017). 

175. Zhang, C. et al. Critical behavior of intercalated quasi-van der Waals ferromagnet Fe0.26 TaS2. Phys. Rev. Mater. 3, 114403 (2019). 

176. Lei, B. et al. Tuning phase transitions in FeSe thin flakes by field-effect transistor with solid ion conductor as the gate dielectric. Phys. Rev. B 95, 020503 (2017). 

177. Lei, B. et al. Gate-tuned superconductor-insulator transition in (Li, Fe) OHFeSe. Phys. Rev. B 93, 060501 (2016). 

178. Weber, D., Trout, A. H., McComb, D. W. & Goldberger, J. E. DecompositionInduced Room-Temperature Magnetism of the Na-Intercalated Layered Ferromagnet Fe3–xGeTe2. Nano Lett. 19, 5031–5035 (2019). 

179. Kanetani, K. et al. Ca intercalated bilayer graphene as a thinnest limit of superconducting C6Ca. P Natl Acad. Sci. USA 109, 19610–19613 (2012). 

180. Yang, S. L. et al. Superconducting graphene sheets in CaC6 enabled by phononmediated interband interactions. Nat. Commun. 5, 1–5 (2014). 

181. Mazin, I. I. Intercalant-driven superconductivity in YbC6 and CaC6. Phys. Rev. Lett. 95, 227001 (2005). 

182. Heguri, S. et al. Superconductivity in the graphite intercalation compound BaC6. Phys. Rev. Lett. 114, 247201 (2015). 

183. Kawamura, H., Shirotani, I. & Tachikawa, K. Anomalous superconductivity and pressure induced phase transitions in black phosphorus. Solid State commun. 54, 775–778 (1985). 

184. Telford, E. J. et al. Doping-induced superconductivity in the van der Waals superatomic crystal Re6Se8Cl2. Nano Lett. 20, 1718–1724 (2020). 

185. Vasko, A., Tichy, L., Horak, J. & Weissenstein, J. Amphoteric nature of copper impurities in Bi2Se3 crystals. Appl Phys. 5, 217–221 (1974). 

186. Deridder, R., Vandyck, D., Vantendeloo, G., Vanlanduyt, J. & Amelinckx, S. Microstructural study of copper-intercalated niobium disulfide and Tantalum disulfide CuxNbS2 and CuxTaS2 III. Study of diffuse-scattering—transition-state. Phys. Status Solidi A 39, 383–399 (1977). 

187. He, L., Kou, X. F. & Wang, K. L. Review of 3D topological insulator thin-film growth by molecular beam epitaxy and potential applications. Phys. Status Solidi-R. 7, 50–63 (2013). 

188. Hor, Y. S. et al. Superconductivity in CuxBi2Se3 and its Implications for pairing in the undoped topological insulator. Phys. Rev. Lett. 104, 057001 (2010). 

189. Chen, C.-W., Choe, J. & Morosan, E. Charge density waves in strongly correlated electron systems. Rep. Prog. Phys. 79, 084505 (2016). 

190. Wagner, K. E. et al. Tuning the charge density wave and superconductivity in CuxTaS2. Phys. Rev. B 78, 104520 (2008). 

191. Morosan, E. et al. Superconductivity in CuxTiSe2. Nat. Phys. 2, 544–550 (2006). 

192. Zhang, R. Intercalation Induced Superconductivity in MoS2, Black Phosphorus and Bi2Se3. (2017). 

193. Friend, R. H. & Yoffe, A. D. Electronic properties of intercalation complexes of the transition metal dichalcogenides. Adv. Phys. 36, 1–94 (1987). 

194. Somoano, R. B. & Rembaum, A. Superconductivity in intercalated molybdenum disulfide. Phys. Rev. Lett. 27, 402 (1971). 

195. Wang, N. Z. et al. Tunable superconductivity by electrochemical intercalation in TaS2. New J. Phys. 20, 023014 (2018). 

196. Pettenkofer, C. & Jaegermann, W. Charge-density-wave transformation-induced by na intercalation into 1T-TaS2. Phys. Rev. B 50, 8816–8823 (1994). 

197. Rossnagel, K. Suppression and emergence of charge-density waves at the surfaces of layered 1T-TiSe2 and 1T-TaS2 by in situ Rb deposition. New J. Phys. 12, 125018 (2010). 

198. Togawa, Y. et al. Chiral magnetic soliton lattice on a chiral helimagnet. Phys. Rev. Lett. 108, 107202 (2012). 

199. Kogar, A. et al. Observation of a charge density wave incommensuration near the superconducting dome in CuxTiSe2. Phys. Rev. Lett. 118, 027002 (2017). 

200. Yan, S. et al. Influence of domain walls in the incommensurate charge density wave state of Cu intercalated 1 T−TiSe2. Phys. Rev. Lett. 118, 106405 (2017). 

201. Zhang, H. et al. Enhancement of superconductivity in organic-inorganic hybrid topological materials. Sci. Bull. 65, 188–193 (2020). 

202. Matsumoto, R., Okabe, Y. & Akuzawa, N. Thermoelectric properties and performance of n-type and p-type graphite intercalation compounds. J. Electron Mater. 44, 399–406 (2015). 

203. Qian, X., Gu, X. K., Dresselhaus, M. S. & Yane, R. G. Anisotropic tuning of graphite thermal conductivity by lithium intercalation. J. Phys. Chem. Lett. 7, 4744–4750 (2016). 

204. Guilmeau, E., Breard, Y. & Maignan, A. Transport and thermoelectric properties in copper intercalated TiS2 chalcogenide. Appl. Phys. Lett. 99, 052107 (2011). 

205. Ng, H. K. et al. Effects Of structural phase transition on thermoelectric performance in lithium-intercalated molybdenum disulfide (LixMoS2). ACS Appl. Mater. Interfaces 11, 12184–12189 (2019). 

206. Zhu, G. H. et al. Tuning thermal conductivity in molybdenum disulfide by electrochemical intercalation. Nat. Commun. 7, 1–9 (2016). 

207. Sood, A. et al. An electrochemical thermal transistor. Nat. Commun. 9, 1–9 (2018). 

208. Kang, J. S., Ke, M. & Hu, Y. J. Ionic intercalation in two-dimensional van der Waals materials: in situ characterization and electrochemical control of the anisotropic thermal conductivity of black phosphorus. Nano Lett. 17, 1431–1438 (2017). 

209. Karki, B., Rajapakse, M., Sumanasekera, G. U. & Jasinski, J. B. Structural and thermoelectric properties of black arsenic–phosphorus. ACS Appl. Energy Mater. 3, 8543–8551 (2020). 

210. Wan, C. L. et al. Intercalation: building a natural superlattice for better thermoelectric performance in layered chalcogenides. J. Electron Mater. 40, 1271–1280 (2011). 

211. Feng, W. et al. Mxenes derived laminated and magnetic composites with excellent microwave absorbing performance. Sci. Rep. 9, 3957 (2019). 

212. Xu, G. et al. Solvent-regulated preparation of well-intercalated Ti3C2Tx MXene nanosheets and application for highly effective electromagnetic wave absorption. Nanotechnology 29, 355201 (2018). 

213. Guo, Y. F., Liu, Z. F. & Peng, H. L. A roadmap for controlled production of topological insulator nanostructures and thin films. Small 11, 3290–3305 (2015). 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 30 

M. Rajapakse et al. 

21 

214. Sandré, E. Phase transitions induced in layered host structures during alkali metal intercalation processes. J. Solid State Chem. 88, 269 (1990). 

215. Cheng, Y. et al. Sodium-induced reordering of atomic stacks in black phosphorus. Chem. Mater. 29, 1350–1356 (2017). 

216. Py, M. A. & Haering, R. R. Structural destabilization induced by lithium intercalation in MoS2 and related compounds. Can. J. Phys. 61, 76–84 (1983). 

217. Leng, K. et al. Phase restructuring in transition metal dichalcogenides for highly stable energy storage. Acs Nano 10, 9208–9215 (2016). 

218. Zhu, X., Li, D., Liang, X. & Lu, W. D. Ionic modulation and ionic coupling effects in MoS2 devices for neuromorphic computing. Nat. Mater. 18, 141–148 (2019). 

219. Ji, X. et al. phase transition in monolayer molybdenum disulfide via electron beam assisted solid state lithiation/delithiation. Appl. Phys. Lett. 116, 033103 (2020). 

220. Huang, Q. M., Wang, L. F., Xu, Z., Wang, W. L. & Bai, X. D. In-situ TEM investigation of MoS2 upon alkali metal intercalation. Sci. China Chem. 61, 222–227 (2018). 

221. Enyashin, A. N. & Seifert, G. Density-functional study of LixMoS2 intercalates (0 ≤ x ≤1). Comput Theor. Chem. 999, 13–20 (2012). 

222. Huan, Y. H., Shi, J. P., Zhao, G. C., Yan, X. Q. & Zhang, Y. F. 2D metallic transitional metal dichalcogenides for electrochemical hydrogen evolution. Energy Technol.Ger. 7, 1801025 (2019). 

223. Lukowski, M. A. et al. Enhanced hydrogen evolution catalysis from chemically exfoliated metallic MoS2 nanosheets. J. Am. Chem. Soc. 135, 10274–10277 (2013). 

224. Wang, H. et al. Electrochemical tuning of MoS2 nanoparticles on threedimensional substrate for efficient hydrogen evolution. Acs Nano 8, 4940–4947 (2014). 

225. Reddy Inta, H. et al. Ionic liquid‐intercalated metallic MoS2 as a superior electrode for energy storage applications. ChemNanoMat 6, 685–695 (2020). 

226. Behrens, M., Kiebach, R., Ophey, J., Riemenschneider, O. & Bensch, W. The reaction mechanism of a complex intercalation system: In situ X-ray diffraction studies of the chemical and electrochemical lithium intercalation in Cr4TiSe8. Chem.-Eur. J. 12, 6348–6355 (2006). 

227. Musa, M. R. K. et al. Li interaction-induced phase transition from black to blue phosphorene. Phys. Rev. Mater. 5, 024007 (2021). 

228. Massé, R. C., Liu, C., Li, Y., Mai, L. & Cao, G. Energy storage through intercalation reactions: electrodes for rechargeable batteries. Natl Sci. Rev. 4, 26–53 (2017). 

229. Li, Y., Yan, H., Xu, B., Zhen, L. & Xu, C. Y. Electrochemical intercalation in atomically thin van der Waals materials for structural phase transition and device applications. Adv. Mater. 33, 2000581 (2020). 

### ACKNOWLEDGEMENTS 

This work was supported by the U.S. Department of Energy, Office of Science, Basic Energy Sciences, under Award # DE-SC0019348. 

### AUTHOR CONTRIBUTIONS 

J.B.J. and G.S. conceived the outline of the review, and together with M.R., directed the overall project, including organizing all contributions and editing the manuscript. All authors contributed to the literature search and writing the Abstract and the sections “Introduction” and “Challenges and opportunities”. In addition, M.R., B.K., and U.O.A. contributed to the sections from “Intercalation methods” to “Intercalationinduced structural phase transitions”, S.P. contributed to the sections “Intercalation for fabrication of 2D materials” and “Intercalation-induced structural phase transitions”, M.R.K.M. contributed to the sections “Property tuning through intercalation-induced doping” and “Intercalation-induced structural phase transitions”, S.M.S.R. contributed to the sections “Intercalation for fabrication of 2D materials” and “Intercalation-induced structural phase transitions”, M.Y. contributed to the section “Intercalation-induced structural phase transitions”, G.S. contributed to the sections “Property tuning through intercalation-induced doping” and “Intercalation effects on interlayer interactions”, and J.B.J. contributed to the sections “Property tuning through intercalation-induced doping” and “Intercalation effects on interlayer interactions”. M.R., B.K., U.O.A., M.Y., J.B.J., and G.S. edited the paper at all stages. All authors have given approval to the final version of the manuscript. 

### COMPETING INTERESTS 

The authors declare no competing interests. 

### ADDITIONAL INFORMATION 

Correspondence and requests for materials should be addressed to G.S. or J.B.J. 

Reprints and permission information is available at http://www.nature.com/ reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

230. Hossain, M. et al. Recent advances in two-dimensional materials with charge density waves: synthesis, characterization and applications. Crystals 7, 298 (2017). 

231. Moore, J. E. The birth of topological insulators. Nature 464, 194–198 (2010). 

232. Hu, H. et al. Recent advances in doping engineering of black phosphorus. J. Mater. Chem. A 8, 5421–5441 (2020). 

233. Ren, K. et al. Strain-enhanced properties of van der Waals heterostructure based on blue phosphorus and g-GaN as a visible-light-driven photocatalyst for water splitting. Rsc Adv. 9, 4816–4823 (2019). 

234. Zhu, Z. & Tomanek, D. Semiconducting layered blue phosphorus: a computational study. Phys. Rev. Lett. 112, 176802 (2014). 

235. Sun, H. Y., Liu, G., Li, Q. F. & Wan, X. G. First-principles study of thermal expansion and thermomechanics of single-layer black and blue phosphorus. Phys. Lett. A 380, 2098–2104 (2016). 

236. Liu, L. Z., Wu, X. L., Liu, X. X. & Chu, P. K. Strain-induced band structure and mobility modulation in graphitic blue phosphorus. Appl Surf. Sci. 356, 626–630 (2015). 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons. org/licenses/by/4.0/. 

© The Author(s) 2021 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2021) 30 

