# Inorganic wide-bandgap perovskite subcells with dipole bridge for all-perovskite tandems

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Energy |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 297 |
| 作者 | Tiantian Li, Jian Xu, Ren-Xing Lin, S. Teale, Hong-Jiang Li, Z. Liu, Chenyang Duan, Qian Zhao et al. |
| DOI | 10.1038/s41560-023-01250-7 |
| 源文件 | 064_Li_2023_Inorganic-wide-bandgap-perovskite-subcells-with.pdf |

---
TSpace Research Repository 

tspace.library.utoronto.ca 

# **Inorganic wide-bandgap perovskite subcells with dipole bridge for all-perovskite tandems** 

Tiantian Li, Jian Xu, Renxing Lin, Sam Teale, Hongjiang Li, Zhou Liu, Chenyang Duan, Qian Zhao, Ke Xiao,  Pu Wu, Bin Chen, Sheng Jiang, Shaobing Xiong, Haowen Luo, Sushu Wan, Ludong Li, Qinye Bao, Yuxi Tian,  Xueping Gao, Jin Xie, Edward H. Sargent, and Hairen Tan 

**Version** Post-Print\Accepted Manuscript 

**Citation** Li, T., Xu, J., Lin, R., Teale, S., Li, H., Liu, Z., Duan, C., Zhao, Q., Xiao, K., **(published** Wu, P., Chen, B., Jiang, S., Xiong, S., Luo, H., Wan, S., Li, L., Bao, Q., Tian, **version)** Y., Gao, X., ... Tan, H. (2023). Inorganic wide-bandgap perovskite subcells with dipole bridge for all-perovskite tandems. Nature Energy, 8(6), 610-620. 

DOI https://doi.org/10.1038/s41560-023-01250-7 **Publisher** This version of the article has been accepted for publication, after peer review and **Terms of** is subject to Springer Nature’s AM terms of use but is not the Version of Record **Use** and does not reflect post-acceptance improvements, or any corrections. The Version of Record is available online at: https://doi.org/10.1038/ s41560-023-01250-7 

#### **How to cite TSpace items** 

**Always cite the published version** , so the author(s) will receive recognition through services that track citation counts, e.g. Scopus. If you need to cite the page number of the **author manuscript from TSpace** because you cannot access the published version, then cite the TSpace version **in addition to** the published version using the permanent URI (handle) found on the record page. 

#### **This article was made openly accessible by U of T Faculty. Please** **<u>tell us how this access benefits you. Your story matters.</u>** 



## **Inorganic wide-bandgap perovskite subcells with dipole bridge for all-perovskite tandems** 

Tiantian Li,<sup>1,3†</sup> Jian Xu,<sup>2†</sup> Renxing Lin,<sup>1</sup> Sam Teale,<sup>2</sup> Hongjiang Li,<sup>1</sup> Zhou Liu,<sup>1</sup> Chenyang Duan,<sup>1</sup> Qian Zhao,<sup>3</sup> Ke Xiao,<sup>1</sup> Pu Wu,<sup>1</sup> Bin Chen,<sup>2</sup> Sheng Jiang,<sup>4</sup> Shaobing Xiong,<sup>4</sup> Haowen Luo,<sup>1</sup> Sushu Wan,<sup>5</sup> Ludong Li,<sup>1</sup> Qinye Bao,<sup>4</sup> Yuxi Tian,<sup>5</sup> Xueping Gao,<sup>3</sup> Jin Xie,<sup>5</sup> Edward H. Sargent,<sup>2</sup> * and Hairen Tan<sup>1</sup> * 

_1National Laboratory of Solid State Microstructures, College of Engineering and Applied Sciences, Frontiers Science Center for Critical Earth Material Cycling, Nanjing University, Nanjing 210023, China_ 

_2Department of Electrical and Computer Engineering, University of Toronto, 10 King’s College Road, Toronto, Ontario, M5S 3G4, Canada_ 

_3School of Materials Science and Engineering, Nankai University, Tianjin 300350, China_ 

_4School of Physics and Electronic Science, East China Normal University, Shanghai 200241, China_ 

_5School of Chemistry and Chemical Engineering, Nanjing University, Nanjing 210023, China_ 

† These authors contributed equally to this work. 

*Corresponding authors. E-mails: <u>hairentan@nju.edu.cn; ted.sargent@utoronto.ca</u> 

**The operating stability has become a priority issue for all-perovskite tandem solar cells. Inorganic CsPbI3-xBrx perovskites, which have good photostability against halide segregation, are promising alternatives for all-perovskite tandem solar cells. However, the interface between organic transport layers and inorganic perovskite suffers from a large energetic mismatch and inhibits charge extraction compared to hybrid analogues, resulting in low open-circuit voltages and fill factors. Here we show that inserting at this interface a passivating dipole layer having high molecular polarity – a molecule that interacts strongly with both inorganic perovskite and C60 – reduces the energetic mismatch and accelerates the charge extraction. This strategy resulted in a power conversion efficiency (PCE) of 18.5% in wide-bandgap (WBG) devices. We report all-perovskite tandems using an inorganic WBG subcell, achieving a PCE of 25.6% (steady-state 25.2%). Encapsulated** 

1 

#### **tandems retain 96% of their initial performance after 1000 h of simulated 1-sun operation at the maximum power point.** 

### **Introduction** 

All-perovskite tandem solar cells consisting of wide-bandgap (WBG) perovskite (~1.8 eV) and narrow-bandgap (NBG) perovskite (~1.2 eV) absorber layers extend the usable range of the solar spectrum and reduce thermalization losses in single-junction solar cells<sup>1–4</sup> . The highest reported power conversion efficiency (PCE) of all-perovskite tandem solar cells (26.4%)<sup>5</sup> has exceeded the best-performing single-junction perovskite solar cells (PSCs) (25.7%)<sup>6</sup> ; however, long-term stability remains as a major bottleneck for commercial application, which require a product lifetime of 20~25 years<sup>7</sup> . 

A mixed iodine-bromine WBG perovskite is required in tandems to achieve a high open-circuit voltage ( _VOC_ ); yet photoinstability of WBG organic-inorganic hybrid perovskites limits longterm stability<sup>8</sup> . Efficient tandem devices made using a hybrid WBG layer have so far only maintained >90% of initial PCE for 600 h of operation at their maximum power point (MPP)<sup>5</sup> . Inorganic CsPbI3-xBrx perovskites, exhibit increased photostability<sup>9–11</sup> and excellent thermal stability, so are good candidates for WBG absorbers<sup>12–14</sup> . Despite this promise, the performance of all-inorganic PSCs, especially in the inverted _p-i-n_ device structure, lags far behind organic−inorganic PSCs, a limitation dominated by low _VOC_ and fill factors (FF)<sup>15–19</sup> , as listed in **Supplementary Table 1** . 

We reasoned that fast crystallization with uncontrolled intermediate phases results in poor film quality for all-inorganic perovskites<sup>20–22</sup> . The high density of interfacial defects leads to poor contact between the CsPbI3-xBrx perovskite and electron-transport layers (ETL), which demands more effective passivation strategies. Another key challenge is that wide-bandgap CsPbI3-xBrx perovskite has an inferior energetic alignment with ETL<sup>23,24</sup> , especially for C60 that is commonly used in the inverted architecture<sup>16,25</sup> . Inorganic perovskites typically have higher conduction band minimums (CBM) than the equivalent hybrid perovskite at the same bandgap<sup>26–28</sup> . The large conduction band offset (ΔEc ~ 0.7 eV) at this interface not only severely hinders charge extraction and leads to large _VOC_ losses<sup>29–31</sup> but also triggers the hysteresis in the current density- 

2 

voltage ( _J-V_ ) curves response<sup>32</sup> . Molecules with a _π_ -conjugated backbone have the potential to passivate trap states and facilitate charge transfer<sup>33–36</sup> . Organic passivators with an asymmetric structure can induce an intramolecular dipole moment across an interface owing to the unequal electronegativity. 

In this work, we find that introducing a dipole layer with high molecular polarity at the perovskite/C60 interface reconfigures interfacial states to improve band alignment and increase the binding between inorganic perovskite and organic contacts. This strategy enables a PCE of 18.5% with a _VOC_ of 1.23 V and average FF > 0.83, as well as an operational stability for over 2000 h without PCE degradation under one-sun illumination in WBG PSCs. Using this allinorganic WBG subcell, we report all-perovskite tandem solar cells with a PCE of 25.6%. Encapsulated tandem devices exhibit promising operating stability, maintaining 96% of their initial performance after over 1000 h operation at MPP. 

#### **Molecular structure design strategy** 

Here we pursued a _π_ -conjugated molecular structure to insert into perovskite/C60 interface ( **Fig 1a** ). Starting with the commonly used passivant phenethylammonium (PEA) cations, we seek to regulate the electric dipole moment by introducing either F atom (4-Fluorophenethylammonium (F-PEA)) or CF3 group (4-(Trifluoromethyl) phenethylammonium (CF3-PEA)) at the para position of the amino group ( **Fig 1b** and **Supplementary Fig. 1** ). For this type of ammonium ligand, their -NH3<sup>+</sup> side tends to interact with the perovskite surface<sup>37,38</sup> , while the other side interacts with the C60 contact layer. The maximum electrostatic potential ( _φ_ max) at the -NH3<sup>+</sup> side of each ligand is such that: _φ_ max,PEA< _φ_ max,F-PEA< _φ_ max,CF3-PEA; while the minimum electrostatic potential ( _φ_ min) at the other side is: _φ_ min,PEA> _φ_ min,F-PEA> _φ_ min,CF3-PEA. We posited that the higher _φ_ max could increase the binding strength between the inorganic perovskite and passivator; and that the lower _φ_ min could increase the binding strength between ETL and passivated perovskite layers. The large difference between _φ_ max and _φ_ min within a ligand usually suggests high molecular polarity. We found that the dipole moments for the neutral molecules increase as the number of electron-withdrawing F groups increases ( **Supplementary Table 2** ). 

We carried out density functional theory (DFT) calculations to understand how the molecular structure of each passivator affects defect passivation and charge transport at the perovskite/ETL 

3 

interface. Among the three passivation molecules, CF3-PEA binds to the perovskite most strongly by occupying the cesium vacancy site ( **Fig. 1c** ), in accordance with its highest _φ_ max when compared with PEA and F-PEA. A stronger binding with the perovskite surface suggests a more effective surface passivation since defective sites are more likely to be passivated. We revealed that in-gap states induced by deep-level defects, i.e. I-Pb antisites, are eliminated after passivation with PEA or CF3-PEA ( **Supplementary Fig. 2** ). The DFT simulation results herein indicate that better surface passivation enabled by CF3-PEA is mainly ascribed to stronger binding with defect sites on the perovskite surface. 

To study how the passivating molecules affect interfacial charge transport, we explored the interaction between the C60 layer and the perovskite surface, as well as charge extraction at perovskite/C60 interface. As shown in **Fig. 1d** , capping passivators induce significant charge redistribution. Charge accumulation within C60 molecules is repressed when passivated by PEA molecules and is further promoted in cases by F-PEA and CF3-PEA passivated perovskite. The adsorption energy (Eads) of C60 on the control (bare), PEA, F-PEA, and CF3-PEA passivated (110) perovskite surface are -0.47, -0.53, -0.57, and -0.71 eV, respectively. This indicates that the interaction between C60 and CF3-PEA passivated perovskite is strongest among the three passivators, which reduces device charge transfer resistance and accelerates interfacial charge transfer<sup>39</sup> . 

We used the HSE+SOC method (hybrid functionals including spin orbital coupling) to calculate the projected density of states (PDOS) of C60/perovskite heterojunction **(Fig. 1e)** . It can be found that these passivators (PEA, F-PEA and CF3-PEA) do not introduce sub-bandgap states. The CBM of the entire heterojunction originates from C60 components. For the control and PEA passivated systems, the first CB of the perovskite component is far from the first CB of the C60 component. However, for CF3-PEA passivated system, the two first CBs become much closer in energy, and thus the CBMs of C60 and perovskite align with each other. This indicates that electron extraction from the CF3-PEA passivated perovskite layer to the C60 layer is more efficient than that in the control, PEA, and F-PEA passivated cases<sup>40</sup> . 

We further studied the work function (WF) changes and CBM shifts upon three passivator treatments ( **Supplementary Table 3** and **Supplementary Table 4** ). We found that F-PEA and 

4 

CF3-PEA exhibit an increased WF and CBM downshift compared with the bare surface, while PEA exhibits a decreased WF and CBM upshift compared with the bare surface. The WF shift originates from two contributions<sup>41,42</sup> , the intrinsic dipole of the ligands ( _µ_ intrinsic) and the dipole created by the interaction between the ligands and the perovskite surface ( _µ_ interaction). _µ_ intrinsic and _µ_ interaction lies in the opposite direction along the z-axis of the surface slabs and thus have an opposite effect on the WF. Since PEA has a lower molecular polarity, its _µ_ intrinsic contribution was less than that of F-PEA and CF3-PEA, and therefore insufficient to negate the WF decrease contributed by the _µ_ interaction term, resulting in an overall WF decrease. We thus offer that in cationic-type passivated cases, a higher molecular polarity helps to induce a WF increase and improve electron extraction. 

#### **PV performance of CsPbI3-xBrx PSCs employing dipole layers** 

DFT calculations indicated that CF3-PEA has the potential to provide more effective surface passivation and improved interfacial electron extraction than conventional PEA. To test this idea, we fabricated all-inorganic CsPbI3-xBrx PSCs in the inverted _p-i-n_ architecture to evaluate the effects of the three passivators on photovoltaic (PV) performance, and the preparation process is shown in **Supplementary Fig. 3** . The optimized concentration in isopropyl alcohol of PEA, F- PEA and CF3-PEA were all 1.0 mol% relative to Cs<sup>+</sup> ( **Supplementary Fig. 4** ). **Figure 2a** and **Table 1** compare the PV parameters of the control and passivated solar cells. Prototypical passivator PEA improved _VOC_ slightly but reduced the short-circuit current density ( _JSC_ ) and FF, resulting in only a slight improvement in PCE. Encouragingly, F-PEA and CF3-PEA substantially improved the _VOC_ and FF of devices without deteriorating _JSC_ . 

Champion devices used CF3-PEA exhibited _VOC_ up to 1.23 V, a gain of 220 mV compared to control devices. Accompanied with a noticeable FF improvement (80.7% to 82.8%), and high _JSC_ (18.1 mA cm<sup>-2</sup> ), the champion CF3-PEA device achieved a high PCE of 18.5%, the highest value for inverted all-inorganic perovskite with a bandgap around 1.8 eV. The steady-state PCE of the CF3-PEA device is 18.3% ( **Supplementary Fig. 5** ), well matched with the PCE determined from _J-V_ scans. The _JSC_ calculated from EQE agrees well with the value from _J-V_ measurement ( **Fig. 2b** ). **Supplementary Fig. 6** shows the PCE histogram of 120 CF3-PEA passivated devices with an average PCE of 17.3% and a narrow distribution with standard 

5 

deviation of 0.49%. The hysteresis index (defined as (PCEreverse – PCEforward)/PCEreverse × 100%) of control, PEA, F-PEA, and CF3-PEA devices are 13.9%, 11.1%, 4.0% and 3.0%, respectively ( **Fig. 2c** ). The CF3-PEA device had the lowest hysteresis (PCEs of 18.5% vs. 18.0% between reverse and forward scans), which is good compared to that of high-performance all-inorganic PSCs reported previously<sup>43,44</sup> . This we attribute to defect passivation by CF3-PEA and improved band alignment at the perovskite/C60 interface<sup>45,46</sup> , a trend also seen in DFT. 

We investigated the operational stability of all-inorganic CsPbI3-xBrx PSCs using a multi-color LED solar simulator with intensity equivalent to 100 mW cm<sup>-2</sup> by continuously tracking the MPP in ambient conditions. The encapsulated CF3-PEA device maintained its initial PCE during 2000 h of MPP operation ( **Fig. 2d** ). We studied the role, in achieving higher photostability, of the allinorganic CsPbI3-xBrx films vs. the effect of the dipole layer. Both the control and CF3-PEA treated devices did not show any light-induced phase segregation after 20 minutes of 10-sun equivalent illumination. In contrast, organic-inorganic hybrid perovskite films with a similar bandgap exhibited serious phase separation under identical illumination conditions ( **Fig. 2d inset** and **Supplementary Fig. 7** ). The inorganic PSCs also had higher thermal stability than do the organic-inorganic hybrid devices under 85℃ thermal stress ( **Supplementary Fig. 8** and **Supplementary Fig. 9** ). 

#### **Characterization of CsPbI3-xBrx perovskite films** 

Next we sought to characterize the morphology and crystalline structure of CsPbI3-xBrx perovskite films to reveal the interaction between perovskites and passivators. Scanning electron microscopy (SEM) images show dense, pinhole-free control films; the morphologies of films are unchanged after passivation ( **Fig. 3a** ). Passivation treatments did not affect the overall crystallinity and no new phase were formed, as evidenced by X-ray diffraction (XRD) patterns ( **Fig. 3b** ). If the concentration of passivators is increased, we found peaks at low angles (2 theta <10<sup>°</sup> ) appear which correspond to diffraction signals of the original molecules ( **Supplementary Fig. 10** ). Once we used IPA to wash the high-concentration capping layers, all of these impurity XRD peaks disappeared. These results indicate that the passivators do not form 2D perovskite capping layers<sup>47</sup> , something we assign to the strong resistance of Cs<sup>+</sup> to ion exchange, which is consistent with previously reported results<sup>48,49</sup> . The thin passivation layers also did not alter UV- 

6 

vis absorption, and the band edges remain nearly unchanged (~1.77 eV) ( **Supplementary Fig. 11** ). The PV bandgap estimated from the EQE spectra is about 1.78 eV<sup>50</sup> ( **Supplementary Fig. 12** ), which is comparable with the optical bandgap value of 1.77 eV ( **Supplementary Fig. 11** ). 

The elemental composition and electronic structure for the pristine and passivated CsPbI3-xBrx films are determined by X-ray photoelectron spectroscopy (XPS) measurement. The XPS spectra of N 1s and F 1s shown in **Fig. 3c** and **3d** indicate the existence of the passivator molecules on the surface of passivated films. The Pb 4f XPS spectrum of the control film contains two main peaks at 138.06 and 142.92 eV, corresponding to the Pb 4f 7/2 and 5/2 orbitals, respectively. The Pb 4f peaks in the PEA passivated film shift toward higher binding energy by 0.08 eV, whereas the F-PEA and CF3-PEA passivated films shift to lower binding energies by 0.07 eV and 0.14 eV ( **Fig. 3e** ), respectively. The XPS core level spectra of Cs 3d, I 3d and Br 3d in perovskite are shown in **Supplementary Fig. 13** `.` The shift direction of binding energy for elements (Pb/Cs/I/Br) show the same trend, though the shift values are slightly different ( **Supplementary Table 5** ). In perovskite films with each passivator, the binding energy shift of Cs is the largest among characterized elements, indicating that the passivators have a stronger interaction with Cs<sup>31,33</sup> . 

We further performed ultraviolet photoelectron spectroscopy (UPS) to investigate the surface energetics of perovskite films and C60 layers ( **Supplementary Fig. 14** and **Supplementary Fig. 15** ). From UPS we can see that PEA treatment decreases the WF of CsPbI3-xBrx film surfaces from 4.86 to 4.83 eV with respect to the vacuum level, while F-PEA and CF3-PEA passivated films exhibit deeper WFs of 5.08 eV and 5.34 eV, respectively ( **Fig. 3f** ). The ΔEc between the CBM of CsPbI3-xBrx and pure C60 (4.35 eV) for control, PEA, F-PEA, and CF3-PEA treated films are 0.74, 0.89, 0.44 and 0.16 eV, respectively. We also provide the estimated energetics of C60 coated on different passivation perovskite films ( **Supplementary Fig. 16** ). The energy level alignment was presented as referenced to the vacuum level and Fermi level (EF), respectively ( **Supplementary Fig. 17** ). We found that the PEA enlarges the ΔEc between the perovskite and C60, while the F-PEA and CF3-PEA dipole layers reduce the ΔEc offset, which is consistent with the results obtained from separately measured C60 on top of glass/ITO `.` Our DFT calculations also support above experimental results of the WF changes and CBM shift upon three passivator treatments. 

7 

Drift-diffusion modeling shows that the ~ 210 mV _VOC_ increase in CF3-PEA treated devices can be linked to a reduced energy level mismatch between perovskite and ETL (ΔEc) and trap passivation at the perovskite surface. When we vary the surface trap density, ΔEc presents the dominant effect. The model indicates that ΔEc effects _VOC_ in two ways: increased recombination at the perovskite/C60 interface which reduces quasi fermi level splitting (QFLS), and losses purely related to band alignment where the _VOC_ is lower than the bulk QFLS ( **Supplementary Fig. 18** ). 

We measured the ideality factor of devices using each treatment ( **Supplementary Fig. 19** ), values of the control, PEA, F-PEA, and CF3-PEA devices were 1.32, 1.25, 1.22, and 1.17, respectively. Reduced ideality factor of devices indicates suppressed non-radiative recombination. We measured the electroluminescence spectra of control and passivated PSC devices, operating as light-emitting-diodes ( **Supplementary Fig. 20)** . The CF3-PEA-passivated devices achieved significantly higher electroluminescence intensity at various applied bias. Combined with the lowest ideality factors for the CF3-PEA passivated device, we confirm that CF3-PEA exhibits the most efficient suppression of trap-assisted recombination in devices among these three passivators. 

We performed steady-state photoluminescence (PL) and time-resolved photoluminescence (TRPL) to probe the radiative recombination and carrier transfer behavior in CsPbI3-xBrx films. The passivated CsPbI3-xBrx films exhibit suppressed defect-induced non-radiative recombination, as evidenced by the increased PL intensities ( **Fig** `.` **4a** ). As shown in **Fig. 4b** , the CF3-PEA film coated with C60 shows PL enhancement, indicating the C60 does not induce as much recombination as it does for the control. This is due to passivation of surface defects and the band mismatch between the C60 and the perovskite surface. The PEA device is not worse than the control (bigger mismatch) because the QFLS of films does not decrease beyond a mismatch of ~0.3 eV. And then the PEA film has a lower defect density. **Figure 4c** presents TRPL of perovskite/C60 junctions, from which we calculated the differential lifetime ( **Fig. 4d** ) to distinguish charge extraction vs. trap-assisted recombination. The first interval at shorter times is dominated by the transfer of electrons from the bulk into the C60 and the second interval at longer delay times is dominated by interfacial recombination<sup>51–53</sup> . The sharp drop in emission 

8 

for CF3-PEA/C60 indicates efficient electron transfer at the interface and the high plateau suggests a reduced trap density. We obtained the same trend under an increased excitation fluence of 58.3 nJ cm<sup>-2</sup> ( **Supplementary Fig. 21** and **Supplementary Table 8** ). Drift-diffusion modeling shows that the maximum achievable _JSC_ based on absorption is 18.4 mA cm<sup>-2</sup> , assuming that all absorbed photons contribute to the current ( **Supplementary Fig. 18d** ). CF3PEA treated devices show an average _JSC_ increase of 0.5 mA cm<sup>-2</sup> compared with control devices ( **Supplementary Note 1** ). 

#### **Performance and stability of all-perovskite tandems** 

We then fabricated monolithic all-perovskite tandem solar cells using CF3-PEA passivated CsPbI3-xBrx perovskite for the WBG subcells ( **Fig. 5a** and **5b** ). The champion tandem device exhibited a PCE of 25.6% under reverse scan, with a _VOC_ of 2.00 V, _JSC_ of 16.1 mA cm<sup>-2</sup> and FF of 79.6% ( **Fig. 5c** and **Table 2** ). The integrated _JSC_ values of the WBG and NBG subcells from EQE spectra are 16.2 and 16.4 mA cm<sup>-2</sup> , respectively, in good agreement with the _JSC_ values determined from _J-V_ measurements ( **Fig. 5d** ). The champion tandem device exhibited a stabilized PCE of 25.2% measured over 120 s ( **Fig. 5e** ). **Figure 5f** shows the PCE histogram of 50 tandem solar cells processed among several batches, indicating an average PCE of 24.3% and a good reproducibility. The photovoltaic performance of tandem solar cells with all-inorganic WBG subcells is comparable to that of tandem devices with inorganic-organic hybrid WBG perovskites reported in our previous studies<sup>54,55</sup> . 

We found that the performance of CsPbI3-xBrx PSCs slightly reduced in _VOC_ and FF after replacing the C60/BCP based ETL with C60/ALD-SnO2, required in all-perovskite tandem solar cells ( **Supplementary Fig. 22** ). The performance reduction of devices with ALD-SnO2 layer could be explained by the following factors: (1) the ~100 minutes long heating at 75℃ during ALD processing possibly altered the metastable-state of the all-inorganic perovskites<sup>56</sup> ; (2) the vacuum environment during ALD may accelerate the phase transition of all-inorganic perovskites<sup>57</sup> ; (3) the moisture injected during water pulses could be harmful to all-inorganic perovskites, of which the phase is very sensitive to moisture<sup>48,58</sup> . 

Device stability is crucial for the commercialization of all-perovskite tandems. We investigated long-term operational stability under simulated 1-sun illumination. We tracked the power output 

9 

of encapsulated devices at their MPP in ambient air under a multi-color LED solar simulator with intensity equivalent to 100 mW cm<sup>-2</sup> . The tandem devices exhibit promising operational stability and maintained 96% of initial PCE after MPP operation over 1000 h ( **Fig** `.` **5g** ), which is superior to the tandem devices with mixed-cation and mixed-halide hybrid WBG perovskites in previous reports<sup>59,60</sup> . 

The inorganic wide-bandgap perovskites enable a significant advance in operating stability; yet work remains to be done to increase the PCEs of all-perovskite tandem devices. To achieve PCEs beyond 30%, it will be required to improve the _VOC_ of the WBG front subcell from 1.23 V reported herein to greater than 1.4 V, something that may be obtained by further suppressing bulk and surface recombination. Regulating the rapid nucleation and crystallization process of all-inorganic perovskite films with additive and composition engineering is expected to reduce the bulk trap density. Higher _VOC_ is further expected by reducing the hole-transport layer/perovskite interfacial recombination losses. Another focus will be on further improve the phase stability of WBG inorganic perovskites, something enabled by composition engineering, in order to avoid performance degradation in front subcells during the sequent deposition steps of the tunnel recombination junction and NBG bottom subcells. We project that, by combining such efforts, it will become possible to achieve PCEs of all-perovskite tandem solar cells that reach towards those of hybrid subcells. 

#### **Conclusions** 

This work demonstrates efficient and stable all-perovskite tandem solar cells with an allinorganic WBG subcell that provides improved photostability over hybrid perovskites. We demonstrate a strongly bonding electric dipole interlayer using high-polarity CF3-PEA molecules to passivate surface defects, regulate interfacial energy level alignment, resulting in suppressed non-radiative charge recombination and improved interfacial electron extraction. Using the CF3-PEA passivator, inverted all-inorganic CsPbI3-xBrx PSCs show a PCE of 18.5% with excellent operating stability over 2000 h. We further achieve an efficiency of 25.6% (steadystate 25.2%) in all-perovskite tandem solar cell using a CsPbI3-xBrx WBG subcell. The encapsulated tandem devices retain 96% of their initial performance after 1000 h of simulated 1- sun illumination. This 1000-h lifetime surpasses – by fully a factor of 4x – the longest operating 

10 

lifetime reported in all-perovskite tandem cells<sup>5</sup> . The strategy contributes a facile route towards efficient and stable all-perovskite tandem solar cells. 

#### **Methods** 

#### **First-Principles Calculations** 

First-principles calculations based on density functional theory (DFT) were carried out using the Vienna _Ab initio_ Simulation Package (VASP)<sup>61</sup> . For the exchange-correlation functional, the Perdew-Burke-Ernzerhof functional (PBE)<sup>62</sup> and the screened Heyd−Scuseria−Ernzerhof (HSE) hybrid functional<sup>63,64</sup> were adopted. In addition, DFT-D3 method was used for the van der Waals (vdW) correction<sup>65</sup> . The spin-orbital coupling (SOC) effect was included. The mixing parameter (α) of the Hartree-Fock term in HSE+SOC calculations was set to 0.45, which had been proven to reproduce the experimental bandgap. The plane-wave cutoff energy was 400 eV. The energy and force convergence criteria were set to 10<sup>−5</sup> eV and 0.03 eV·Å<sup>−1</sup> , respectively. The Brillouin zone was sampled with Γ-centered _k_ -mesh densities of 2π × 0.03 Å<sup>-1</sup> in the calculations of the energetic and electronic properties. We used a vacuum of 20 Å to separate neighboring surfaces in the z-direction. The binding energies of different ammonium cations (PEA, F-PEA and CF3PEA) with the perovskite surface were calculated as _E_ mol/pvsk – _E_ pvsk – _E_ mol, where _E_ mol/pvsk, _E_ pvsk and _E_ mol are the total energies of the adsorption system, the perovskite system and CF3-PEAI/FPEAI/PEAI (I represents iodide), respectively. A higher binding energy value indicates a stronger binding strength with the perovskite surface. The adsorption energies (Eads) of C60 with different ammonium cations (PEA, F-PEA and CF3-PEA) passivated and bare perovskite surface were calculated as _E_ (C60@perovskite)− _E_ (C60)− _E_ (perovskite). The electrostatic potentials ( _φ_ ) of the passivators were calculated in the Gaussian 09 package at the B3LYP/def2TZVP level with DFT-D3. The maximum _φ_ ( _φmax_ ) and minimum _φ_ ( _φmin_ ) in these passivators were obtained with the help of Multiwfn code<sup>66</sup> . 

#### **Drift-diffusion modeling for device performance simulation** 

We used SCAPS-1D (a Solar Cell Capacitance Simulator) to build the device model<sup>67</sup> . Detailed simulation methods are illustrated in **Supplementary Fig. 18** and **Supplementary Table 6-7** . 

11 

#### **Materials** 

All materials were used as received without further purification. PbI2 (99.99%), PbCl2 (99.99%), PbBr2 (99.99%), 2PACz (>98.0%) and MeO-2PACz (>98.0%) were purchased from TCI Chemicals. SnI2 (99.999%) was purchased from Alfa Aesar. SnF2 (99.9%), formamidine sulfinic acid (FSA, ≥98%), CsI (99.999%), DMF, (99.8% anhydrous), DMSO (99.9% anhydrous), isopropyl alcohol (IPA, 99.8% anhydrous) and ethyl acetate (99.8% anhydrous) were purchased from Sigma-Aldrich. The organic halide salts (FAI, MAI, DMAI, PEAI, F-PEAI) were purchased from GreatCell Solar Materials (Australia). CF3-PEAI (99.9%) and BCP (>99% sublimed) were purchased from Xi’an Polymer Light Technology Corp. PEDOT:PSS aqueous solution (Al 4083) was purchased from Heraeus Clevios (Germany). The C60 was purchased from Nano-C. NiO nanocrystals were synthesized according to previous reports<sup>68</sup> . 

#### **Perovskite precursor solution** 

Wide-bandgap CsPbI3-xBrx perovskite: DMAI: CsI: PbBr2: PbI2: PbCl2 (molar ratio = 0.9:1:0.45:0.55:0.1) were dissolved in mixed DMF and DMSO solvents (volume ratio = 1:1.4) at a concentration of 0.95 M and were stirred at 60°C in N2 glove box for 2 h before film fabrication. The precursor solution was filtered through a 0.22 μm polytetrafluoroethylene (PTFE) membrane before making the perovskite films. 

Narrow-bandgap FA0.7MA0.3Pb0.5Sn0.5I3 perovskite: the precursor solution (2.0 M) was prepared in mixed solvents of DMF and DMSO with a volume ratio of 2:1. The molar ratios for FAI/MAI and PbI2/SnI2 were 0.7:0.3 and 0.5:0.5, respectively. The molar ratio of (FAI + MAI)/(PbI2 +SnI2) was 1:1. SnF2 (10 mol% relative to SnI2) was added in the precursor solution. The precursor solution was stirred at room temperature for 2 h. Tin powders (5 mg ml<sup>-1</sup> ) and FSA (0.3 mol%) were added in the precursor to reduce Sn<sup>4+</sup> in the precursor solution. The precursor solution with the remaining tin powders was filtered through a 0.22 μm polytetrafluoroethylene (PTFE) membrane before making the perovskite films. 

#### **All-inorganic perovskite solar cell fabrication** 

The pre-patterned ITO glass was sequentially washed with water, acetone, and IPA sequentially, and then treated with UV-ozone for 15 min before use. The NiO layer was spin-coated onto the 

12 

ITO substrate with a NiO nanocrystal suspension (20 mg ml<sup>-1</sup> in water) at 3000 rpm for 30 s and subsequently annealed at 100°C for 10 min in air. Self-assembled molecules (SAM) were used to optimize the NiO film<sup>69</sup> . The solutions of 2PACz and MeO-2PACz with the same concentration (0.2 mmol L<sup>-1</sup> in IPA) were mixed with 1:3 ratio and then were spin-coated on the NiO film at 4000 rpm. for 20 s, followed by annealing at 100°C for 5 min. After cooling, the substrates were immediately transferred to the glovebox. The perovskite precursor was spin coated on NiO/SAM at 2600 rpm for 150 s, and was kept in the N2 glovebox for 1 h before heating. The samples were then taken out from the glovebox and annealed at 170°C for 20 mins in ambient air with a humidity below 40%. For surface passivation, the passivation solution in IPA (1mol%) was drop-casted on perovskite film at 5000 rpm for 20s, followed by drying at 90°C for 3 min. Then the cooled films were washed by IPA at 5000 rpm for 20s. After the cooling to room temperature, the substrates were transferred to the evaporation system. Finally, C60 (20 nm), BCP (7 nm) and Cu (100 nm) were sequentially deposited on top of the perovskite by thermal evaporation. 

#### **Monolithic all-perovskite tandem solar cell fabrication** 

The CsPbI3-xBrx films were prepared as mentioned above. The substrates were transferred to the evaporation system after the fabrication of all-inorganic perovskite films, and 20-nm-thick C60 film was deposited on top by thermal evaporation at a rate of 0.2 Å/s. The substrates were then transferred to the atomic layer deposition (ALD) system (Veeco Savannah S200) to deposit 20 nm SnO2 at 75°C using precursors of tetrakis(dimethylamino) tin(IV) (99.9999%, Nanjing Ai Mou Yuan Scientific Equipment Co., Ltd) and deionized water. After ALD deposition, the substrates were transferred back to the thermal evaporation system to deposit an ultra-thin layer of Au clusters layer (~1 nm) on ALD-SnO2. PEDOT:PSS layers were spin-cast on top of front cells and annealed in air at 120°C for 20 min. After the substrates had cooled, we immediately transferred the substrates to a nitrogen-filled glovebox for the deposition of narrow-bandgap perovskite films. The perovskite films were deposited with two-step spin-coating procedures: (1) 1000 rpm for 10 s with a ramp-up of 200 rpm s<sup>-1</sup> and (2) 4000 rpm for 40 s with a ramp-up of 1000 rpm s<sup>-1</sup> . Ethyl acetate (200 µl) was dropped on the spinning substrate during the second spin-coating step at 20 s before the end of the procedure. Finally, 20 nm C60, 7 nm BCP and 150 

13 

nm Cu films were sequentially deposited by thermal evaporation (Beijing Technol Science). Details on the deposition of ALD-SnO2 layers can be found in our previous work<sup>55</sup> . 

#### **Characterization of solar cells** 

For single-junction solar cells, the _J-V_ characteristics were measured using a Keithley 2400 sourcemeter under the illumination of the solar simulator (EnliTech, Class AAA) at the light intensity of 100 mW cm<sup>−2</sup> as checked with NREL calibrated reference solar cells (KG-5 and KG0 reference cells were used for the measurements of wide-bandgap and narrow-bandgap solar cells, respectively). Unless otherwise stated, the _J-V_ curves were all measured under the same conditions<sup>70</sup> : in a nitrogen-filled glovebox with a scanning rate of 200 mV s<sup>-1</sup> (voltage steps of 20 mV and a delay time of 100 ms). The active area was determined by the aperture shade mask (0.049 cm<sup>2</sup> ) placed in front of the solar cells. EQE measurements were performed in ambient air using a QE system (EnliTech) with monochromatic light focused on device pixel and a chopper frequency of 20 Hz. For tandem solar cells, the _J-V_ characteristics were carried out under the illumination of a two-lamp high spectral match solar simulator (SAN-EI ELECTRIC, XHS50S1). The spectrum from the simulator were finely tuned to ensure that spectral mismatch is within 100±3% for each 50-nm interval between wavelength range 400-1000 nm. The solar simulator was set at the light intensity of 100 mW cm<sup>−2</sup> as checked with a calibrated crystalline silicon reference solar cell with a quartz window (KG-0). (see the detailed discussion in **Supplementary Note 2** ). EQE measurements were performed in ambient air, and the bias illumination from highly-bright LEDs with emission peaks of 850 and 460 nm were used for the measurements of the front and back subcells, respectively. No bias voltage was applied during the EQE measurements of tandems. 

#### **Operational stability tests of solar cells** 

The operating stability tests were carried out under simulated AM 1.5G illumination (Class AAA, multi-color LED solar simulator, Guangzhou Crysco Equipment Co. Ltd) with an intensity of 100 mW cm<sup>−2</sup> using a home-build LabVIEW-based MPP tracking system and a Perturb and observe method in ambient conditions (humidity of 30-50%). The solar cells were encapsulated with a cover glass and UV epoxy (Three Bond, Japan) which was cured under an UV-LED lamp (peak emission at 365 nm) for 3 min. No UV-filter was applied during operation. The MPP 

14 

ageing was performed at room temperature and the device temperature was increased to around 35−40℃ during operation due to the self-heating under illumination. There was no active cooling during the measurement stage. The illumination intensity was regularly calibrated to check the degradation of the LED lamp. 

#### **Other characterizations** 

XRD patterns were acquired using a Bruker D8 AVANTAGE Diffractometer with Cu Kα (λ = 1.54 Å) radiation. XPS analysis was carried out using the Thermo Scientific Al K-Alpha XPS system with energy steps of 0.1 eV. SEM images were obtained using a TESCAN microscope with an accelerating voltage of 2 kV. Optical absorption measurements were carried out in a Lambda 950 UV/Vis spectrophotometer. 

PL measurements were conducted on a home-built wide-field microscope based on Olymplus IX73. A 532 nm CW diode laser was used as the excitation light for the sample measurements with the laser power density on the film surface of 100 mW cm<sup>-2</sup> . The fluorescence of the samples was collected by a dry objective lens (Olympus LUCPlanFI 40×, NA = 0.6) and detected by an EMCCD camera (iXon Ultra 888, Andor) after passing through 550 nm (ET550LP, Chroma), long-pass filters. TRPL was measured using a Horiba Fluorolog-3 Time-Correlated Single Photon Counting System; the samples were excited using a pulsed laser with a wavelength of 485 nm (2 MHz, 5.83 and 58.3 nj cm<sup>-2</sup> ) from the glass side. The PL decay curves were fitted with biexponential components to obtain a fast and a slow decay lifetime. 

Ultraviolet photoelectron spectroscopy (UPS) were performed in an ultrahigh vacuum (UHV) surface analysis system equipped with a fast entry load-lock, a transfer chamber and an analysis chamber (base pressure ~10<sup>-10</sup> mbar). UPS employed the He I 21.22 eV as the excitation source with an energy resolution of 50 meV. The work function was derived from the secondary electron cutoff and the ionization potential from the frontier edge of the occupied density states to the vacuum level.  The LED devices characterizations were carried out with a Keithley 2400 sourcemeter and a 100 mm integrating sphere coupled with a spectrometer (Ocean Optics, Spectrum TEQ-EQY). 

#### **Author contributions** 

15 

H.T. conceived the idea and directed the overall project. T.L. and C.D. fabricated all the inorganic perovskite devices and conducted the characterization. J.Xu. carried out the DFT simulation. S.T. performed SCAPS simulations. K.X. helped on ALD processing. R.L. and P.W. helped on the fabrication of NBG subcells. S.J., S.X. and Q.B. performed the UPS measurements. HJ.L., Z.L., B.C., HW.L., S.W., Y.T., L.L., X.G., and J.Xie. helped on the material characterization. H.T. and E.H.S. supervised the work. H.T., T.L. and J.Xu. wrote the draft manuscript, and S.T., HJ.L., Q.Z., B.C., L.L., X.G. and E.H.S. improved the manuscript. All authors read and commented on the manuscript. 

#### **Acknowledgments** 

This work was financially supported by the National Key R&D Program of China (2022YFB4200304), National Natural Science Foundation of China (U21A2076 and 61974063), Natural Science Foundation of Jiangsu Province (BE2022021, BE2022026, BK20202008, BK20190315), the Technology Innovation Fund of Nanjing University, Fundamental Research Funds for the Central Universities (0213/14380206; 0205/14380252), Frontiers Science Center for Critical Earth Material Cycling Fund (DLTD2109), and Program for Innovative Talents and Entrepreneur in Jiangsu. The work at University of Toronto was supported by the U.S. Department of the Navy, Office of Naval Research (N00014-20-1-2572). J. Xu acknowledges SciNet, which is funded by the Canada Foundation for Innovation under the auspices of Compute Canada, for providing the computing resources for DFT simulations. 

#### **Competing interests** 

Hairen Tan is the founder, Chief Scientific Officer, and Chairman of Renshine Solar Co., Ltd., a company that is commercializing perovskite PVs. The other authors declare no competing financial or non-financial interests. 

#### **Data availability** 

The datasets generated and analysed during the current study are included in the published article and its Supplementary Information and source data files. Source data are provided with this paper. 

16 

#### **Tables** 

**Table 1. PV parameters of the control and passivated PSCs** 

|**Device**|**Scans**|**_VOC_**<br>**(V)**|**_JSC_**<br>**(mA cm**<sup>**-2**</sup>**)**|**FF**<br>**(%)**|**PCE**<br>**(%)**|**SPO**<br>**(%)**|**HI**<br>**(%)**|
|---|---|---|---|---|---|---|---|
||Rev.|1.01|17.6|80.7|14.4|||
|Control|For.|0.99|17.5|71.4|12.4|13.4|13.9|
||Average|0.99±0.02|17.6±0.24|79.7±0.64|13.8±0.29|||
||Rev.|1.05|17.6|79.6|14.7|||
|PEA|For.|1.03|17.6|72.3|13.1|13.9|11.1|
||Average|1.04±0.01|17.5±0.22|79.3±0.62|14.4±0.23|||
||Rev.|1.13|18.0|81.7|16.5|||
|F-PEA|For.|1.12|17.8|79.7|15.9|16.1|4.0|
||Average|1.12±0.02|17.6±0.22|81.4±0.41|16.1±0.25|||
||Rev.|1.23|18.1|82.8|18.5|||
|CF3-PEA|For.|1.23|18.0|81.4|18.0|18.3|3.0|
||Average|1.20±0.02|18.0±0.14|83.2±0.62|17.9±0.32|||



Average rows: the values represent the average and standard deviation of 26 devices under reverse scan. 

**Table 2. Champion PV parameters of the WBG subcell with C60/ALD-SnO2 structure, the NBG subcell and the all-perovskite tandem device** 

|**Device**|**_VOC_**<br>**(V)**|**_JSC_**<br>**(mA cm**<sup>**-2**</sup>**)**|**FF**<br>**(%)**|**PCE**<br>**(%)**|
|---|---|---|---|---|
|WBG subcell<br>(with ALD-SnO2)|1.19|17.5|80.6|16.6|
|NBG subcell|0.84|32.4|79.7|21.7|
|Tandem|2.00|16.1|79.6|25.6|



#### **Figure Legends/Captions (for main text figures)** 

**Fig.1| DFT calculations of surface passivation and interfacial charge transport** `.` **a** , Schematic structure of inverted CsPbI3-xBrx PSCs. **b** , Electrostatic potentials ( _φ_ ), ( _φ_ max: red color, _φ_ min: blue color) of each passivator (PEA, F-PEA and CF3-PEA). **c** `,` Binding energy between passivators and VCs defects for a A-I terminated (001) perovskite surface. **d** `,` Charge density difference (blue, depletion; yellow, accumulation) of anchoring C60 ETL onto the control and ammonium cations (PEA, F-PEA and CF3-PEA) passivated (110) perovskite surfaces. The same isosurface level was used. Calculated Eads were also shown. The passivation molecules were shown in the dashed black box. The atoms in the structures were differentiated by different colors: 

17 

Cs was represented by grass green, Pb by grey and I by purple. **e** , HSE+SOC calculated projected density of states (PDOS) of the perovskite/C60 heterojunction for each passivation strategy. The gray and orange dash lines indicate the first CB levels of perovskite and C60 at the interface, respectively. pvsk: perovskite, e – : electron, h+: hole. The grey and orange arrows indicate the PDOS area of the perovskite layers and C60 layers, respectively. The blue arrow denoted the direction of electron transport at the perovskite/C60 interface. 'fast/slow' labels indicate the fast/slow electron extraction property. 

**Fig. 2| Photovoltaic performance of CsPbI3-xBrx perovskite solar cells with dipole layers. a** , PV parameters of control and passivated solar cells (26 devices for each type). The box plot denotes median (centre line), 75th (top edge of the box), 25th (bottom edge of the box) percentiles. The solid dots represent each device datum. **b** `,` EQE curves of the four champion devices. **c** , _J-V_ curves of the four champion devices for each condition. _J-V_ hysteresis performance was represented by the shaded area. **d** , MPP tracking of an encapsulated CF3-PEA device for over 2000 h in air under simulated 1-sun solar illumination (equivalent to AM1.5G, 100 mW cm<sup>-2</sup> , multicolor LED simulator) The device had an initial PCE of 16.8%. The operating temperature of the device was around 35℃, and the relative humidity was ~30 – 40%. (inset: PL spectra of CF3-PEA film under 10-sun illumination for 0, 5, 10, 15, and 20 min). 

**Fig. 3| Characterization of CsPbI3-xBrx perovskite films** . **a** , SEM images of perovskite films. **b** , X-ray diffraction (XRD) patterns of perovskite films. **c-e** , XPS spectra of N 1s ( **c** ), F 1s ( **d** ) and Pb 4f ( **e** ) core-level. The vertical dashed line indicated the binding energy position of Pb 4f in the control film. **f** , Energy level alignment diagram of CsPbI3-xBrx and ETL. EF: Fermi level, EVAC: vacuum level. 

**Fig. 4| Photoluminescence properties of perovskite films with different dipole layers. a** , **b** , steady-state PL spectra of perovskite films (a) and perovskite films coated with C60 (b). The insets show the sample structures and the laser illumination directions. **c** , TRPL spectra of perovskite/C60 junctions. **d** , Computed differential lifetimes obtained by taking the derivative from fits to the transients in (c). The excitation fluence of TRPL spectra was 5.83 nJ cm<sup>–2</sup> . 

**Fig. 5| Performance of monolithic all-perovskite tandem solar cells. a** - **b** , Schematic structure ( **a** ) and Cross-sectional SEM image ( **b** ) of an all-perovskite tandem solar cell. **c** , The _J-V_ measurements from a CsPbI3-xBrx single-junction device with C60/ALD-SnO2 structure, a FA0.7MA0.3Pb0.5Sn0.5I3 narrow bandgap device, and a monolithic all-perovskite tandem cell. **d** , EQE curves of the best-performing tandem cell. **e** , Stabilized power output of the champion tandem cell. **f** , Histogram of PCEs over 50 all-perovskite tandem solar cells, showing an average PCE of 24.4 ± 0.7%. **g** , Continuous MPP tracking of an encapsulated tandem cell over 1000 hours under simulated 1-sun illumination (equivalent to AM1.5G, 100 mW cm<sup>-2</sup> , multi-color 

18 

LED simulator) in ambient air. The device had an initial PCE of 24.1%. The operating temperature of the device was around 35℃, and the relative humidity was ~30 – 40%. 

#### **References** 

1. Chen, H. _et al._ Regulating surface potential maximizes voltage in all-perovskite tandems. _Nature_ **613** , 676–681 (2022). 

2. Wang, C. _et al._ A universal close-space annealing strategy towards high-quality perovskite absorbers enabling efficient all-perovskite tandem solar cells. _Nat. Energy_ **7** , 744–753 (2022). 

3. Tong, J. _et al._ Carrier control in Sn–Pb perovskites via 2D cation engineering for all-perovskite tandem solar cells with improved efficiency and stability. _Nat. Energy_ **7** , 642–651 (2022). 

4. Jiang, Q. _et al_ . Compositional texture engineering for highly stable wide-bandgap perovskite solar cells. _Science_ **378** , 1295–1300 (2022). 

5. Lin, R. _et al._ All-perovskite tandem solar cells with improved grain surface passivation. _Nature_ **603** , 73–78 (2022). 

6. NREL Best-Research Cell Efficiencies. https://www.nrel.gov/pv/cell-efficiency.html. [Accessed on January 23, 2023] 

7. Wang, D., Wright, M., Elumalai, N. K. & Uddin, A. Stability of perovskite solar cells. _Sol. Energy Mater Sol. Cells_ **147** , 255–275 (2016). 

8. Wen, J. _et al._ Steric engineering enables efficient and photostable wide-bandgap perovskites for all-perovskite tandem solar cells. _Adv. Mater._ **34** , 2110356 (2022). 

9. Zhou, W. _et al._ Light-independent ionic transport in inorganic perovskite and ultrastable Cs-based perovskite solar cells. _J. Phys. Chem. Lett_ **8** , 4122–4128 (2017). 

10. Bischak, C. G. _et al._ Origin of reversible photoinduced phase separation in hybrid perovskites. _Nano Lett._ **17** , 1028– 1033 (2017). 

11. Afsari, M., Boochani, A. & Shirdel, F. Electronic and optical properties of two propounded compound in photovoltaic applications, CsPbI3 and CH3NH3PbI3: By DFT. _optik_ **199** , 163360 (2019). 

12. Balakrishna, R. G., Kobosko, S. M. & Kamat, P. V. Mixed halide perovskite solar cells. Consequence of iodide treatment on phase segregation recovery. _ACS Energy Lett._ **3** , 2267–2272 (2018). 

13. Bush, K. A. _et al._ Compositional engineering for efficient wide band gap perovskites with improved stability to photoinduced phase segregation. _ACS Energy Lett._ **3** , 428–435 (2018). 

14. Di Girolamo, D. _et al._ Ion migration-induced amorphization and phase segregation as a degradation mechanism in planar perovskite solar cells. _Adv. Energy Mater._ **10** , 2000310 (2020). 

15. Ho-Baillie, A., Zhang, M., Lau, C. F. J., Ma, F. J. & Huang, S. Untapped potentials of inorganic metal halide perovskite solar cells. _Joule_ **3** , 938–955 (2019). 

16. Wang, J. _et al._ Highly efficient all-inorganic perovskite solar cells with suppressed non-radiative recombination by a Lewis base. _Nat. Commun._ **11** , 177 (2020). 

17. Fu, S. _et al._ Tailoring in situ healing and stabilizing post-treatment agent for high-performance inverted CsPbI3 perovskite solar cells with efficiency of 16.67%. _ACS Energy Lett._ **5** , 3314–3321 (2020). 

18. Zeng, Q. _et al._ Polymer-passivated inorganic cesium lead mixed-halide perovskites for stable and efficient solar cells with high open-circuit voltage over 1.3 V. _Adv. Mater._ **30** , 1705393 (2018). 

19. Zeng, Z. _et al._ In situ grain boundary functionalization for stable and efficient inorganic CsPbI2Br perovskite solar cells. _Adv. Energy Mater._ **8** , 1801050 (2018). 

19 

20. Li, T. _et al._ Cesium acetate-assisted crystallization for high-performance inverted CsPbI3 perovskite solar cells. _Nanotechnology_ **33** , 375205 (2022). 

21. Wang, K. _et al._ Rapid nucleation and slow crystal growth of CsPbI3 films aided by solvent molecular sieve for perovskite photovoltaics. _Adv.Energy Mater._ **12** , 2201274 (2022). 

22. Zhang, J. _et al._ Molten-salt-assisted CsPbI3 perovskite crystallization for nearly 20%-efficiency solar cells. _Adv. Mater._ **33** , 2103770 (2021). 

23. Jiang, Q. _et al._ Enhanced electron extraction using SnO2 for high-efficiency planar-structure HC(NH2)2PbI3-based perovskite solar cells. _Nat. Energy_ **2** , 16177 (2017). 

24. Ye, Q. _et al._ Cesium lead inorganic solar cell with efficiency beyond 18% via reduced charge recombination. _Adv. Mater._ **31** , 1905143 (2019). 

25. Liu, C. _et al._ Tailoring C60 for efficient inorganic CsPbI2Br perovskite solar cells and modules. _Adv. Mater._ **32** , 1907361 (2020). 

26. Chang, X. _et al._ Printable CsPbI3 perovskite solar cells with PCE of 19% via an additive strategy. _Adv. Mater._ **32** , 2001243 (2020). 

27. Cho, A. N. & Park, N. G. Impact of interfacial layers in perovskite solar cells. _ChemSusChem_ **10** , 3687–3704 (2017). 

28. Wang, Y. _et al._ Thermodynamically stabilized β-CsPbI3–based perovskite solar cells with efficiencies >18%. _Science_ **365** , 591–595 (2019). 

29. Xu, W. _et al._ Minimizing voltage loss in efficient all-inorganic CsPbI2Br perovskite solar cells through energy level alignment. _ACS Energy Lett._ **4** , 2491–2499 (2019). 

30. Wang, H., Yuan, J., Xi, J., Du, J. & Tian, J. Multiple-function surface engineering of SnO2 nanoparticles to achieve efficient perovskite solar cells. _J. Phys. Chem. Lett._ **12** , 9142–9148 (2021). 

31. Liu, J. _et al._ Efficient and stable perovskite-silicon tandem solar cells through contact displacement by MgFx. _Science_ **377** , 302–306 (2022). 

32. Luo, D., Li, X., Dumont, A., Yu, H. & Lu, Z. H. Recent progress on perovskite surfaces and interfaces in optoelectronic devices. _Adv. Mater._ **33** , 2006004 (2021). 

33. Duan, J. _et al._ Effect of side-group-regulated dipolar passivating molecules on CsPbBr3 perovskite solar cells. _ACS Energy Lett._ **6** , 2336–2342 (2021). 

34. Tan, S. _et al._ Effect of high dipole moment cation on layered 2D organic–inorganic halide perovskite solar cells. _Adv. Energy Mater._ **9** , 1803024 (2019). 

35. Xue, J. _et al._ Reconfiguring the band-edge states of photovoltaic perovskites by conjugated organic cations. _Science_ **371** , 636–640 (2021). 

36. Lin, Y. _et al._ π-conjugated lewis base: efficient trap-passivation and charge-extraction for hybrid perovskite solar cells. _Adv. Mater._ **29** , 1604545 (2017). 

37. Chen, B., Rudd, P. N., Yang, S., Yuan, Y. & Huang, J. Imperfections and their passivation in halide perovskite solar cells. _Chem. Soc. Rev._ **48** , 3842–3867 (2019). 

38. Gao, F., Zhao, Y., Zhang, X. & You, J. Recent progresses on defect passivation toward efficient perovskite solar cells. _Adv. Energy Mater._ **10** , 1902650 (2020). 

39. Li, B. _et al._ Anchoring fullerene onto perovskite film via grafting pyridine toward enhanced electron transport in highefficiency solar cells. _ACS Appl. Mater. Interfaces_ **10** , 32471–32482 (2018). 

40. Liu, X. Y. _et al._ Spin-orbit coupling accelerates the photoinduced interfacial electron transfer in a fullerene-based perovskite heterojunction. _J. Phys. Chem. Lett._ **12** , 1131–1137 (2021). 

20 

41. Canil, L. _et al._ Tuning halide perovskite energy levels. _Energy Environ. Sci._ **14** , 1429–1438 (2021). 

42. Leung, C., Kao, L., Su, S., Feng, J. & Chan, T. Relationship between surface dipole, work function and charge transfer: Some exceptions to an established rule. _Phys. Rev. B_ **68** , 195408 (2003). 

43. Cui, Y. _et al._ A versatile molten-salt induction strategy to achieve efficient CsPbI3 perovskite solar cells with a high open-circuit voltage >1.2 V. _Adv. Mater._ **34** , 2205028 (2022). 

44. Zhang, H. _et al._ Fluorine-containing passivation layer via surface chelation for inorganic perovskite solar cells. _Angew. Chem. Int. Ed._ e202216634 (2022). 

45. Wang, C. _et al._ Understanding and eliminating hysteresis for highly efficient planar perovskite solar cells. _Adv. Energy Mater._ **7** , 1700414 (2017). 

46. Beal, R. E. _et al._ Cesium lead halide perovskites with improved stability for tandem solar cells. _J. Phys. Chem. Lett._ **7** , 746–751 (2016). 

47. Cai, Y. _et al._ Graded 2D/3D (CF3-PEA)2FA0.85MA0.15Pb2I7/FA0.85MA0.15PbI3 heterojunction for stable perovskite solar cell with an efficiency over 23.0%. _J. Energy Chem._ **65** , 480–489 (2022). 

48. Liu, T. _et al._ Modifying surface termination of CsPbI3 grain boundaries by 2D perovskite layer for efficient and stable photovoltaics. _Adv. Funct. Mater._ **31** , 2009515 (2021). 

49. Wang, Y. _et al._ Efficient α-CsPbI3 photovoltaics with surface terminated organic cations. _Joule_ **2** , 2065–2075 (2018). 

50. Almora, O. _et al._ Quantifying the absorption onset in the quantum efficiency of emerging photovoltaic devices. _Adv. Energy Mater._ **11** , 2100022 (2021). 

51. Krogmeier, B., Staub, F., Grabowski, D., Rau, U. & Kirchartz, T. Quantitative analysis of the transient photoluminescence of CH3NH3PbI3/PC61BM heterojunctions by numerical simulations. _Sustain. Energy Fuels_ **2** , 1027– 1034 (2018). 

52. Kirchartz, T., Márquez, J. A., Stolterfoht, M. & Unold, T. Photoluminescence-based characterization of halide perovskites for photovoltaics. _Adv. Energy Mater._ **10** , 1904134 (2020). 

53. Al-Ashouri, A. _et al._ Monolithic perovskite/silicon tandem solar cell with >29% efficiency by enhanced hole extraction. _Science_ **370** , 1300–1309 (2020). 

54. Lin, R. _et al._ Monolithic all-perovskite tandem solar cells with 24.8% efficiency exploiting comproportionation to suppress Sn(Ⅱ) oxidation in precursor ink. _Nat. Energy_ **4** , 864–873 (2019). 

55. Xiao, K. _et al._ All-perovskite tandem solar cells with 24.2% certified efficiency and area over 1 cm<sup>2</sup> using surfaceanchoring zwitterionic antioxidant. _Nat. Energy_ **5** , 870–880 (2020). 

56. Wang, X., Wang, Y., Chen, Y., Liu, X. & Zhao, Y. Efficient and stable CsPbI3 inorganic perovskite photovoltaics enabled by crystal secondary growth. _Adv. Mater._ **33** , 2103688 (2021). 

57. Guo, R. _et al._ Degradation mechanisms of perovskite solar cells under vacuum and one atmosphere of nitrogen. _Nat. Energy_ **6** , 977–986 (2021). 

58. Wang, Y., Zhang, T., Kan, M. & Zhao, Y. Bifunctional stabilization of all-inorganic α-CsPbI3 perovskite for 17% efficiency photovoltaics. _J. Am. Chem. Soc._ **140** , 12345–12348 (2018). 

59. Gil-Escrig, L. _et al._ Efficient wide-bandgap mixed-cation and mixed-halide perovskite solar cells by vacuum deposition. _ACS Energy Lett._ **6** , 827–836 (2021). 

60. Chen, C. _et al._ Interfacial engineering of a thiophene-based 2D/3D perovskite heterojunction for efficient and stable inverted wide-bandgap perovskite solar cells. _Nano Energy_ **90** , 106608 (2021). 

61. Kresse, G. J. F. Efficient iterative schemes for ab initio total-energy calculations using a plane-wave basis set. _J. Phys. Chem. A_ **54** , 11169–11186 (1996). 

21 

62. Perdew, J. P., Burke, K. & Ernzerhof, M. Generalized gradient approximation made simple. _Phys. Rev. Lett._ **77** , 3865– 3868 (1996). 

63. Paier, J. _et al._ Screened hybrid density functionals applied to solids. _J. Chem. Phys._ **124** , 154709 (2006). 

64. Heyd, J., Scuseria, G. E. & Ernzerhof, M. Hybrid functionals based on a screened Coulomb potential. _J. Chem. Phys._ **118** , 8207–8215 (2003). 

65. Lee, K., Murray, É. D., Kong, L., Lundqvist, B. I. & Langreth, D. C. Higher-accuracy van der Waals density functional. _Phys. Rev. B Condens._ **82** , 081101 (2010). 

66. Lu, T. & Chen, F. Multiwfn: A multifunctional wavefunction analyzer. _J Comput Chem_ **33** , 580–592 (2012). 

67. Burgelman, M., Nollet, P. & Degrave, S. Modelling polycrystalline semiconductor solar cells. _Thin Solid Films_ **361** , 527–532 (2000). 

68. Han, Q. _et al._ Low-temperature processed inorganic hole transport layer for efficient and stable mixed Pb-Sn lowbandgap perovskite solar cells. _Sci. Bull._ **64** , 1399–1401 (2019). 

69. Li, L. _et al._ Flexible all-perovskite tandem solar cells approaching 25% efficiency with molecule-bridged hole-selective contact. _Nat. Energy_ **7** , 708–717(2022). 

70. Belisle, R. A. _et al._ Interpretation of inverted photocurrent transients in organic lead halide perovskite solar cells: Proof of the field screening by mobile ions and determination of the space charge layer widths. _Energy Environ. Sci._ **10** , 192– 204 (2017). 

22 

