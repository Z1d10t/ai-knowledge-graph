# Lead immobilization for environmentally sustainable perovskite solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Nature |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 185 |
| 作者 | Hui Zhang, Jin-wook Lee, Giuseppe Nasti, R. Handy, A. Abate, M. Grätzel, Nam-Gyu Park |
| DOI | 10.1038/s41586-023-05938-4 |
| 源文件 | 073_Zhang_2023_Lead-immobilization-for-environmentally-sustaina.pdf |

---
Perspective 

# **Lead immobilization for environmentally sustainable perovskite solar cells** 

|https://doi.org/10.1038/s41586-023-05938-4<br>Received: 11 April 2022|**Hui Zhang**<sup>**1,2**</sup>**, Jin-Wook Lee**<sup>**3,4**</sup>**, Giuseppe Nasti**<sup>**5**</sup>**, Richard Handy**<sup>**6**</sup>**, Antonio Abate**<sup>**5** ✉</sup>**,**<br>**Michael Grätzel**<sup>**4,7** ✉</sup>**& Nam-Gyu Park**<sup>**2,4** ✉</sup>|
|---|---|
|Accepted: 10 March 2023||
|Published online: 24 May 2023<br>Check for updates|Lead halide perovskites are promising semiconducting materials for solar energy<br>harvesting. However, the presence of heavy-metal lead ions is problematic when<br>considering potential harmful leakage into the environment from broken cells and<br>also from a public acceptance point of view. Moreover, strict legislation on the use<br>of lead around the world has driven innovation in the development of strategies<br>for recycling end-of-life products by means of environmentally friendly and<br>cost-effective routes. Lead immobilization is a strategy to transform water-soluble<br>lead ions into insoluble, nonbioavailable and nontransportable forms over large pH<br>and temperature ranges and to suppress lead leakage if the devices are damaged.<br>An ideal methodology should ensure sufficient lead-chelating capability without<br>substantially influencing the device performance, production cost and recycling.<br>Here we analyse chemical approaches to immobilize Pb<sup>2+</sup>from perovskite solar cells,<br>such as grain isolation, lead complexation, structure integration and adsorption of<br>leaked lead, based on their feasibility to suppress lead leakage to a minimal level. We<br>highlight the need for a standard lead-leakage test and related mathematical model<br>to be established for the reliable evaluation of the potential environmental risk of<br>perovskite optoelectronics.|



Lead halide perovskites have attracted intense research attention since their first application as light harvesters in solid-state photovoltaics<sup>1</sup> . Certified record power conversion efficiencies (PCEs) of the state-of-the-art perovskite single-junction and perovskite/Si tandem solar cells have reached 25.8% and 33.2% (ref. 2), respectively. Excellent operational stability over 9,000 h under international electrotechnical commission standards<sup>3</sup> and perovskite modules (64 cm<sup>2</sup> ) with efficiency greater than 20% (ref. 4) have been achieved. These achievements have enhanced the technology readiness of perovskite solar cells (PSCs) for commercialization. 

However, the use of lead is a threat to the environment and human health owing its toxicity<sup>5–8</sup> . Although lead occurs naturally in the Earth’s crust, anthropogenic activity such as mining in the past few centuries and the use of lead in gasoline, paint and electronics has increased the risk of exposure to humans and wildlife<sup>9,10</sup> . The use of lead has been systematically regulated, with specific limitations designed for each application. This is mainly to minimize the risk of exposure to lead in each type of application but also to consider the chemical form of the lead-containing compound in relation to bioavailability, which—in turn—influences both toxicity and bioaccumulation, that is, the ability of the compound to enter living organisms<sup>5,11,12</sup> . The existing legislation around lead does not specifically mention perovskite-based electronics and, thus, some urgent consideration is needed on the risk assessment of these materials to assist safe and responsible 

innovation with lead halide perovskites<sup>5,6</sup> . Recent efforts have strived to substitute the lead element by using divalent metals, such as tin<sup>13–15</sup> , or combining monovalent and trivalent metals to construct double-metal perovskites<sup>16–18</sup> , but the performance of lead-free PSCs is much lower than their lead-based counterparts, indicating the essential role of lead in perovskites to realize high efficiency and long-term stability<sup>19–22</sup> . 

In this Perspective, we discuss the physicochemical role of lead on the optoelectronic properties of perovskite materials<sup>23</sup> (Box 1) and accompanying lead toxicity issues with relevant legislation<sup>24,25</sup> . The lead leaching and exposure pathways from PSCs during their lifespan will be discussed<sup>25–29</sup> , at which point the end-of-life device can be possibly recycled for reuse by specialists with minimized exposure risk<sup>30</sup> . However, occasional lead leakage from operating devices is out of control and, hence, potentially more harmful. The resultant environmental impacts need to be quantified by considering the concentration and bioavailability of the exposed lead compounds<sup>26,31–33</sup> . We discuss here chemical approaches to fundamentally resolve the issue, categorized into: (1) regulating the solubility and diffusivity of lead ions in the device<sup>34–51</sup> and (2) chemical adsorption of the leaking lead ions through lead-adsorbing materials<sup>52–57</sup> . Beyond these approaches, we propose possible routes for fundamental mitigation of lead toxicity through chemical immobilization. 

> 1Key Laboratory of Flexible Electronics (KLOFE) & Institute of Advanced Materials (IAM), Nanjing Tech University, Nanjing, China. 2School of Chemical Engineering and Center for Antibonding Regulated Crystals, Sungkyunkwan University, Suwon, Republic of Korea.<sup>3</sup> Department of Nano Engineering and Department of Nano Science and Technology, SKKU Advanced Institute of Nanotechnology (SAINT), Sungkyunkwan University, Suwon, Republic of Korea.<sup>4</sup> SKKU Institute of Energy Science and Technology (SIEST), Sungkyunkwan University, Suwon, Republic of Korea.<sup>5</sup> Department of Chemical, Materials and Production Engineering, University of Naples Federico II, Naples, Italy.<sup>6</sup> University of Plymouth, Plymouth, UK.<sup>7</sup> Laboratory of Photonics and Interfaces, École Polytechnique Fédérale de Lausanne, Lausanne, Switzerland.<sup>✉</sup> e-mail: antonio.abate@unina.it; michael.graetzel@epfl.ch; npark@skku.edu 

Nature | Vol 617 | 25 May 2023 | **687** 

Perspective 

#### **Box 1** 

## The physicochemical roles of lead in perovskite devices 

The prototypical ABX3 metal halide perovskites consist of threedimensional (3D) corner-sharing BX46− octahedra with A+ cations occupying cubo-octahedral sites. The A is a monovalent organic or alkali metal cation (for example, MA<sup>+</sup> , FA<sup>+</sup> or Cs<sup>+</sup> ), B is a divalent metal cation (for example, Pb<sup>2+</sup> or Sn<sup>2+</sup> ) and X is a halide anion (for example, I<sup>−</sup> , Br<sup>−</sup> or Cl<sup>−</sup> ). Although any ions satisfying the geometrical constraints can be considered to build the perovskite structure, not all the compositions qualify for the light absorber of high-performance photovoltaics. 

A fundamental question around the toxicity issue of the perovskite is if it is possible to realize the excellent optoelectronic properties of the perovskite without lead. Although some progress has been made, the power conversion efficiency and stability of the lead-free perovskite solar cells are still far lower than those of lead halide perovskite photovoltaics. Considering the characteristic orbital mixing configuration that contributes to the excellent optoelectronic properties of the lead halide perovskites, there have been attempts to replace the lead with other metals of similar orbital configurations. Owing to the identical valence shell electron configuration, the group IV elements have been adopted. Among them, the most widely studied material is tin (Sn)-based perovskites<sup>16</sup> . Sn<sup>2+</sup> has a similar ionic radius (118 pm) to Pb<sup>2+</sup> (119 pm), alongside lone-pair 5 _s_ and empty 5 _p_ orbitals, whose effective nuclear charges ( _Z_ eff) are 10.63 and 9.10, respectively<sup>134,135</sup> . 

However, Sn<sup>2+</sup> has a tendency to be oxidized to Sn<sup>4+</sup> (standard reduction potential, _E_ 0 = 0.15 V for Sn<sup>2+</sup> /Sn<sup>4+</sup> versus _E_ 0 = 1.67 for Pb<sup>2+</sup> /Pb<sup>4+</sup> )<sup>136</sup> , probably because of a lack of lanthanide contraction resulting in a relatively smaller _Z_ eff for 5 _s_ lone-pair electrons than that for 6 _s_ ones in Pb<sup>2+</sup> (ref. 14). Consequently, the unintended generation of Sn<sup>4+</sup> in perovskite films results in high defect densities and, thus, poor optoelectronic properties<sup>13</sup> . Meanwhile, the acute toxicity of SnI2 was suggested to be rather higher than that of PbI2 (ref. 137). Germanium (Ge) is another group IV element with identical valence-electron configuration<sup>138</sup> . However, its smaller ionic radius (73 pm) and even higher tendency to be oxidized ( _E_ 0 = 0.0 V for Ge<sup>2+</sup> /Ge<sup>4+</sup> ) cause poor optoelectronic properties and stability<sup>139–141</sup> . In an effort to search for stable lead-free perovskites, other compositions based on _ns_<sup>2</sup> -containing Bi<sup>3+</sup> and Sb<sup>3+</sup> have also been explored. However, these compositions form lower-dimensional crystal structures with relatively wider bandgaps and poor charge-transporting capabilities<sup>16–18</sup> . Double perovskites consisting of Ag<sup>+</sup> /Bi<sup>3+</sup> or Ag<sup>+/</sup> Sb<sup>3+</sup> or other combinations of M<sup>+</sup> and M<sup>3+</sup> ions form a structurally 3D corner-sharing octahedra network, but their lower electronic dimensionality hampers efficient carrier transport<sup>17</sup> . Thus, at present, lead is the most promising element with respect to optoelectronic properties and thermodynamic and environmental stability of the perovskite crystals (Box 1 Table). 

###### **Box 1 Table: Typical properties of lead and other alternative ions and halide perovskites (related) compounds containing those ions** 

||**Pb**<sup>**2+**</sup>|**Sn**<sup>**2+**</sup>|**Ge**<sup>**2+**</sup>|**Bi**<sup>**3+**</sup><br>**Sb**<sup>**3+**</sup>|**M**<sup>**+**</sup>**/M**<sup>**3+**</sup>|
|---|---|---|---|---|---|
|**Effective ionic radius (pm)**|119|118|73|103<br>76|–|
|**Oxidation state stability**|O|X||O|O|
|**3D perovskite formability**|O|O||X|O(double perovskite)|
|**Defect-tolerant orbital**<br>**configuration**|O|O||O|O|
|**Suitable bandgap**|O(direct, ~1.5–3.0 eV)|O(direct, ~1.|2–3.5 eV)|X(indirect, ~2.0–3.0 eV)|X(indirect, ~2.0–3.0 eV)|
|**High isotropic carrier-transport**<br>**capabilities (MX6** **connectivity)**|O|O||X(1D)|X(electronically 0D)|
|O, achievable; X, unachievable. Data fro|m refs. 15,17,18,136,138,141.|||||



##### **Lead in PSCs** 

###### **Lead toxicity and relevant legislation** 

The toxicity of lead to humans became apparent in the mid-twentieth century<sup>9</sup> and the concerns of lead exposure to humans include the incidental ingestion of Pb from soil<sup>10</sup> or contaminated foods such as vegetables<sup>58</sup> , although water is a main cause of oral exposure<sup>59</sup> . Pb is adsorbed by means of the small intestine into the blood and bioaccumulates in internal organs, including the liver, kidneys and the central nervous system. Pb is also deposited in the skeleton and can be remobilized during pregnancy, causing exposure to the foetus<sup>60</sup> . Public health concerns from chronic Pb exposure include neurotoxicity, impaired cognitive development and growth in children, effects on renal function, immunity and the risk of cancer<sup>61</sup> . Clinical monitoring through measuring total Pb concentrations in blood or urine is possible<sup>8,62</sup> . However, the best way to protect the population is to prevent the exposure by setting limits on total Pb concentrations in soil, water, food, medicines and other consumer products. 

The legislation with respect to human health includes some internationally agreed standards. For example, the World Health Organization 

(WHO) recommends a limit on total Pb in drinking water of 10 µg l<sup>−1</sup> (ref. 63). In the USA, the 90th percentile for action on Pb concentrations in drinkable water is currently 15 µg l<sup>−1</sup> and has been continuously revised every 3–7 years, with a desire for zero Pb in drinking water in the future<sup>64</sup> . With respect to protecting the agricultural food chain to humans, the upper limit of lead content in agricultural soil is set to 250 mg kg<sup>−1</sup> in China<sup>65</sup> . The maximum tolerable lead content in canned beverages and foods is 150 and 250 mg kg<sup>−1</sup> , respectively, set by the Food and Agriculture Organization (FAO) of the United Nations<sup>66</sup> . In the USA, the Centers for Disease Control and Prevention (CDC) indicates a reference value for blood lead concentration of 3.5 µg dl<sup>−1</sup> (ref. 67). There are also regulations for the disposal of solid wastes. For example, in the USA, the safe-to-use level of lead leakage (leaching from solid waste) is set to 5 µg l<sup>−1</sup> (ref. 56). There are also restrictions on the use of sludge containing metals, including Pb, in the EU<sup>68</sup> . EU legislation limits the content of lead in ‘homogeneous materials’ to 0.1% by weight. With that said, photovoltaic panels, “intended to be used in a system that is designed, assembled and installed by professionals for permanent use at a defined location”, are already exempt from this limitation<sup>69</sup> . However, this exemption does not apply to devices 

**688** | Nature | Vol 617 | 25 May 2023 



<!-- Start of picture text -->
Fabrication<br>FAO limit: 0.025 mg kg –1 - 10 –2<br>body weight Global<br>spreading<br>- 10 –3<br>Adult LWI limit<br>(2010) mg<br>Operating - 10 –4<br>Human LWI<br>3,000–5,000<br>years ago Local  - 10 –5<br>μg spreading<br>- 10 –6<br>LWI evaluation Low dispersion High dispersion - 10 –7<br>10 –11 10 –10 10 –9 10 –8 10 –7 10 –6 10 –5 10 –4<br>Underground Fraction of world PSC lead leaking to the food chain<br>Old LWI adult limit (withdrawn in 2010)<br>LWI 3,000–5,000 years ago<br>Fraction of exposed world population<br><!-- End of picture text -->

**Fig. 1 | Lead-leakage pathways from PSCs and estimation of their potential environment impact.** Schematic illustration of lead-leakage pathways to the underground water during device fabrication and outdoor operation and estimation of their impact to the level of human LWI, which was calculated by 

considering the world population and total PSC lead required for electricity generation in 2050 compared with the adult LWI limit in 2010 and human LWI 3,000–5,000 years ago. Right panel adapted with permission from ref. 84, Elsevier. 

embedded in consumer electronics or portable systems, and so lead immobilization could represent a way towards compliance for consumer devices incorporating PSCs, but specific legislation regulating this issue will be needed in the future<sup>70</sup> . 

###### **Environmental impacts of PSCs** 

**Life-cycle assessment of PSCs.** Life-cycle assessment has been used to evaluate the environmental impacts of PSCs by considering all stages of their life cycle from the extraction, purification and preparation of lead-related raw materials to the manufacturing, installation and maintenance of PSCs and the handling of the products at the end of their lifespan<sup>32,71,72</sup> . An evaluation of PSC life cycle has concluded that PSCs can be considered more sustainable than other technologies, such as commercially available Si solar cells. For the amount of lead used in a PSC, only an approximately 1-µm-thick perovskite layer is used owing to their extremely high absorption coefficient, and lead concentrations are often very low in complete PSC devices (around 0.015 mg l<sup>−1</sup> dm<sup>−3</sup> ), which is similar to the amount of lead in solder conventionally used to assemble crystalline silicon solar panels. Around 17,000 metric tons of Pb is embodied in the production of the perovskite layer for a yearly 2,400-GW electricity generation, representing only 1.1% of the 1.6 million metric tons of lead consumed in the US domestic market each year<sup>32</sup> . We must also consider that, in Europe, already 56% of lead comes from secondary sources that do not require mining and concentration of the material; these are the most energy-intensive processes of the production from primary sources and so the use of secondary sources can reduce potential overall environmental impacts<sup>73</sup> . Despite these positive aspects, Pb leakage from PSCs still represents a substantial concern because, after installation, the panels will spend most of their lifetime subjected to uncontrolled atmospheric conditions, and possible damage to the panel will lead to dissolution and spreading of the lead owing to rainwater<sup>12,74</sup> . 

**Bioavailability of perovskites.** Life-cycle analysis and leaching studies might identify the potential exposure concentrations, but the effects on human health or the environment depend on how much of the total Pb is bioavailable to the organism and also whether the bioavailable fraction presents a concern for toxicity. Even though potential lead leakage from PSCs might be relatively low, there is an ethical concern 

around lifetime exposure to trace amounts of Pb from the products because the internal organs will eventually accumulate sufficient Pb to cause adverse biological effects. However, the organ concentrations at the threshold of adverse effect are not yet well defined. Instead, epidemiology approaches are used to associate lifetime Pb exposure with specific diseases (for example, Parkinson’s disease)<sup>75</sup> or to relate organ concentrations with specific effects (for example, kidney Pb concentrations and renal function)<sup>76</sup> . The toxic effect of lead halide perovskites is strongly dependent on the cellular properties and metabolic activity of cell types. For instance, human dopaminergic neuroblastoma cells and murine primary hippocampal neurons are very sensitive to the toxicity of MAPbI3 (ref. 77), whereas human lung epithelial cells are less sensitive<sup>77,78</sup> . Furthermore, lead toxicity is also related to the type of lead source, and the toxicity of different lead sources has been shown to follow the order Pb<sup>2+</sup> > perovskites > PbI2 = PbO (ref. 79). Moreover, the pH of the environment and the size of the perovskite nanoparticles also influence perovskite toxicity. Acidic conditions will accelerate the dissolution of Pb from the particles and, at low pH values, the Pb is present as the bioavailable Pb<sup>2+</sup> species, which readily binds to biological membranes. There may also be particle-size effects, and smaller perovskite nanoparticles with a high specific surface area are more toxic than larger ones<sup>80,81</sup> . 

The bioavailability of Pb in soils depends on Pb speciation in the water, the chemical composition of the soil (for example, ionic strength, pH, natural organic matter) and the type of soil (clay soil, loamy soil etc.). Inevitably, Pb uptake by plants and other soil organisms will be influenced by these factors and the source of the Pb. Perovskite has been shown to be more bioavailable, such that the lead uptake coefficient greatly increased in the order native soil < PbI2 < perovskites. The reason for this was attributed to organic cations from the perovskites, which can alter the pH values of the soil and affect the lead uptake ability of the plants<sup>31</sup> . Thus, for environmental or human health risk assessments, the form of the Pb, its chemical transformations and the surrounding chemical matrix should be considered. 

Lead weekly intake (LWI) by humans was taken as health-based guidelines for lead exposure and the upper limit was set at 0.025 mg kg<sup>−1</sup> body weight by the FAO of the United Nations<sup>82</sup> . By assuming that all the lead contained in a broken PSC panel would leak and reach the environment in a finite amount of time<sup>83</sup> , the level of LWI under different percentage dispersion and environmental spreading scenarios is estimated. 

Nature | Vol 617 | 25 May 2023 | **689** 

Perspective 



<!-- Start of picture text -->
Lead-immobilization methodologies<br>Grain isolation Complexation Integration Adsorption<br>Interconnectivity<br>R<br>R<br>R<br>R I nterpenetration/bridg e<br>H2O Leakage<br>I − I − I −<br>Capture<br>Pb 2+<br>Blocking water ingress Precipitating from Preventing structure Capturing leaked<br>and ion outflow environmental water defragmentation lead ions from water<br><!-- End of picture text -->

**Fig. 2 | Lead-immobilization methodologies in PSCs.** Grain isolation with hydrophobic polymers, oxides or insoluble lead salts to block water ingress. Complexation of additive and lead compounds with low _K_ sp allowing to precipitate from environmental water. Structural integration with enhanced 

interconnectivity to prevent structure fragmentation and layer delamination. Adsorption of lead ions using embedded lead adsorbents on the exterior of the device. 

The scheme shown in Fig. 1 was calculated to estimate the possible level of LWI taking into account different possible scenarios. From it, we can deduce that a low fraction of the total lead needed for PSCs reaching the food chain can represent a risk for humans, as—in many scenarios—the LWI would be higher than the levels estimated for the humans of 3,000–5,000 years ago and the adult LWI limit withdrawn in 2010 (ref. 84). 

##### **Lead immobilization in PSCs** 

Owing to the soft and ionic character of perovskite, the first premise of lead leakage from PSCs is ascribed to water-induced decomposition of perovskite crystals into soluble lead salts<sup>85,86</sup> , which can outflow from the device and are then infiltrated into underground water or soil along with rainwater, leading to damage to the ecosystem and human health. To prevent such pollution, the pathways of water ingress and lead leakage need to be blocked by means of some chemical lead-immobilizing approaches, which transform lead components into insoluble, nontransportable or nonbioavailable forms, as illustrated in Fig. 2, so that the exposed lead from PSCs is at a safe-to-use level. 

###### **Grain encapsulation** 

By wrapping the perovskite grains within hydrophobic organics (such as polystyrene)<sup>87,88</sup> , water-resistant oxides (such as TiO2 (ref. 89), SiO2 (refs. 44,45,90), Al2O3 (ref. 91)) or insoluble lead salts (such as PbS (ref. 92), PbSO4 (ref. 46), Pb(OH)2 (ref. 47)), the pathways for water ingress and ions outflow can be effectively blocked. The use of isolation strategy is dependent on the water permeability of the capping layers, which usually use materials with strong hydrophobicity, high compactness and full coverage on perovskite grains. For instance, the condensation of small molecules along with perovskite crystallization<sup>44,45</sup> or depositing hydrophobic molecules<sup>43</sup> or functional salts (such as sulfonics<sup>37,93</sup> , sulfates<sup>46</sup> , sulfides<sup>92,94,95</sup> ) on top of the perovskite layer in post-treatments enabled an in situ encapsulation of grain boundaries and surface. Well-grain-encapsulated lead-containing perovskites manifested robust water stability, which even demonstrated promising application as scintillators for in vivo bioimaging without notable cytotoxicity on target animals<sup>90,96,97</sup> , indicating reduced bioavailability. Furthermore, inserting water-resistant layers into the PSCs for inner<sup>98–101</sup> or external encapsulation<sup>102–106</sup> can also prevent water permeation, but these approaches are ineffective in case of device breakage. Even though 

some self-healing characteristics were endowed by mixing curable materials with the encapsulants<sup>102</sup> , the protection effectiveness might be problematic because the curing process of the damaged encapsulants usually requires external stimulus (for example, ultraviolet radiation, heating), which are not always available in case of emergency. 

###### **Chemical complexation** 

To mitigate water contamination, the solubility of lead compounds from degraded perovskites needs to be decreased by forming low-solubility products ( _K_ sp) of lead-additive complexes through rational additive engineering. Typically, the additives should consist of both electron-donating Lewis base functional groups (such as carbonyl<sup>34,36,37</sup> , thiol<sup>107</sup> , sulfonic<sup>53</sup> , sulfide<sup>108</sup> , porphyrin ring<sup>35</sup> , crown ethers)<sup>38</sup> coordinating with Lewis acidic Pb<sup>2+</sup> ions through an acid– base interaction and hydrophobic backbone or side chains being endowed with water-repelling moieties (such as long alkyl chains, fluorine groups, carbon nanotubes<sup>34</sup> ), allowing them to precipitate from water after complexation. Thus, the as-formed complexes become hydrophobic after the chelation of the functional groups with Pb<sup>2+</sup> . For example, the addition of polyacrylic-acid-grafted carbon nanotubes (CNT-PAA) into the perovskite precursor can effectively suppress the lead leakage of the corresponding PSCs<sup>34</sup> . Briefly, the CNT-PAA exhibited a high Pb<sup>2+</sup> -capturing capability owing to the presence of a large amount of carboxyl groups on the wall of CNTs. After the occupation of hydrophilic groups by Pb<sup>2+</sup> , the self-aggregation of water-insoluble CNTs allowed them to form precipitation in water. As a result, the leaked lead from the CNT-PAA-doped device was well below the hazardous waste limit on water immersion<sup>34</sup> . 

###### **Structure integration** 

Water (moisture)-induced perovskite decomposition usually initiates from water adsorption at the crystal surface, followed by deep penetration into the interior of the bulk and substantially accelerated perovskite fragmentation and ions release<sup>40</sup> . Integration of perovskite structure within the device by improving the binding strength of the constituent elements, intergrain connectivity and interfacial cohesion is able to increase the energy barrier for water penetration, structural fragmentation and layer delamination, thus boosting the structural stability against water dissolution and lead leaking<sup>49,109</sup> . For instance, interfacial/intergrain bridge by means of strong coordination or dipole–dipole interaction can enhance the interconnectivity of the 

**690** | Nature | Vol 617 | 25 May 2023 

**Table 1 | Quantitative analysis of lead-immobilization strategies** 

||**Grain isolation**|**Lead complexation**|**Structure integration**|**Chemical adsorption**|
|---|---|---|---|---|
|**Mechanism**|Prevent water contact with<br>perovskite|Decrease solubility of degraded<br>Pb compounds|Prevent perovskite<br>defragmentation|Capture leaked Pb<sup>2+</sup>from water|
|**Materials**|Hydrophobic oxides,<br>polymers or lead salts|Additives with lead-chelating<br>groups|Porous scaffold, crosslinkable<br>monomers, for example|Lead adsorbents|
|**Location**|Grain boundaries and<br>surface|Perovskite bulk|Bulk, surface and interface of<br>perovskite|Exterior of the device|
|**Lead-adsorbing capacity**|Limited because of its<br>effect on charge transport|Limited because of its effect on<br>perovskite crystallization|Independent of the loading<br>amount|Relatively high|
|**Lead selectivity**|High (pre-isolated Pb<sup>2+</sup>)|High (pre-complexed Pb<sup>2+</sup>)|High (pre-integrated Pb<sup>2+</sup>)|Can be disturbed by environmental<br>factors|
|**Responsivity**|Before leakage|Before leakage|Before leakage|After leakage|
|**Lead recycling**|Challenging because of<br>the isolated Pb|Challenging because of low<br>solubility of Pb complex|Negligible influence|No influence|
|**SQE (full device)**|83% (ref. 43)|58.3% (ref. 35), ~73% (ref. 38),<br>62.5% (ref. 37), 58.4% (ref. 36),<br>70% (ref. 34)|71.9% (ref. 40), 94% (ref. 41),<br>82.9% (ref. 42)|98% (ref. 52)|
|**SQE (broken device)**|–|–|–|>99.9% (refs. 53,55–57)|
|**PCE increase**|+8.5% (ref. 43), +10%<br>(ref. 44), +3.3% (ref. 45)|+9.5% (ref. 35), +17% (ref. 38),<br>+1.9% (ref. 37), +15% (ref. 36),<br>+14% (ref. 34)|+10% (ref. 41), +6.5% (ref. 40),<br>+9.4% (ref. 42)|−1.1% (ref. 52), +1.5% (ref. 54), +0.4%<br>(ref. 56), +1.9% (ref. 55)|
|**Lifetime increase**|>100% (refs. 43–45)|>100% (refs. 34–39)|+67% (ref. 41), +87.5% (ref. 40),<br>>100% (ref. 42)|Negligible influence<sup>56,90</sup>|
|**Scalability**|–|17.36% (19.32 cm<sup>2</sup>)<sup>37</sup>|15.7% (19.16 cm<sup>2</sup>)<sup>41</sup>, 16.75%<br>(24 cm<sup>2</sup>)<sup>42</sup>|16.3% (60.8 cm<sup>2</sup>)<sup>53</sup>, 14.98%<br>(25 cm<sup>2</sup>)<sup>56</sup>, 18.5% (31.5 cm<sup>2</sup>)<sup>55</sup>|



device, resulting in extremely stable perovskites in highly salty, acidic (pH = 1) and basic (pH = 13) aqueous conditions<sup>110</sup> . Sole enhancement of chemical interaction at the perovskite top surface has proved effective to resisting crystal collapse and retarding lead release<sup>40</sup> , but it might be ineffective in case of device damage. Alternatively, the whole structure including the surface, bulk and interface of the perovskite layer needs to be integrated. 

The integration of perovskite grains can be achieved by implementing polymerizable monomers into the perovskite layer to construct perovskite/polymer matrix<sup>41,42</sup> . For example, acrylamide monomers were used as additives in the preparation of perovskite films<sup>41</sup> , which were polymerized in situ to form polyamides along with the perovskite transformation. The –C=O groups from the polyamides can interact with undercoordinated Pb<sup>2+</sup> at grain boundaries and surface of the perovskite to form a robust chelation structure in the as-deposited thin films<sup>41</sup> . Also, the polyamides are prone to form hydrogels when exposed to water, which can further prevent the dissolution and diffusion of Pb<sup>2+</sup> from the device into water<sup>41</sup> . Moreover, the agglomeration effect of the monomers during polymerization can induce compressive strain within the perovskite layer, which can increase the activation energy for ions migration<sup>111</sup> and barrier for water permeation<sup>112</sup> , leading to improved crystal stability in high-humidity conditions. Furthermore, the infiltration of perovskite into rigid and mesoporous structure is also expected to prevent structural collapse. 

###### **Adsorption of leaked lead** 

As well as in situ immobilization, lead-adsorbing materials can be integrated into PSCs to capture leaking ions in case of device damage. Similarly, an effective lead adsorbent should contain lead-binding groups (for example, phosphonates<sup>54,113</sup> , thiols<sup>107,114</sup> , sulfonates<sup>56</sup> , tetraethylene glycol)<sup>115</sup> to form water-insoluble lead products with extremely low _K_ sp values<sup>116–119</sup> . 

All functional layers located at the interior or exterior of the devices, for example, charge-transport layers<sup>107,113,115,120</sup> , electrodes<sup>52</sup> or encapsulants<sup>54–56,114,121</sup> , may be considered as hosts for lead adsorbents. Because 

the lead sequestration efficiency (SQE) is directly correlated with the density of adsorbing sites, the loaded materials should be abundant to ensure sufficient lead-adsorbing capacity. Thereby, the implementation of Pb adsorbents into interior layers of the device might be insufficient because of the limited scavenging capacity by layers. The conductivity of the electrode would decay if too much insulating materials was infiltrated<sup>52</sup> . Also, charge-transport layers are at most a few hundred/tens of nanometres thick, which offer a low capacity to capture all Pb<sup>2+</sup> contained in the perovskite film. Therefore, embedding lead-adsorbing materials into the exterior encapsulation is a better option, for which the device performance is not restricted by the loading amount<sup>56</sup> . Given the random lead diffusion pathways, both front and back sides of the device can be simultaneously protected. A good example was given by Li et al.<sup>54</sup> , in which a highly transparent Pb adsorbent was deposited on top of the front glass without filtering the incident light, and a blend of polymer encapsulants and Pb<sup>2+</sup> -binding materials was inserted between the back electrode and the encapsulating cover. Owing to the remarkable lead-adsorbing capability on both sides, such chemical approaches can substantially reduce lead leakage by 96% (ref. 54). Moreover, lead-adsorbing materials with different activity in various temperature and pH conditions should be combined. For instance, the use of lead adsorbents consisting of phosphonic and methylenephosphonic acid groups within one device can retain high SQE over a large temperature range owing to the varied temperature-dependent deprotonation effect<sup>54</sup> . 

As summarized in Table 1, the four aforementioned lead-immobilization strategies are systematically compared from the aspects of work mechanism, protection effectiveness and their influence on device performance. Notably, interior lead-immobilization strategies (that is, isolation, complexation, integration) demonstrate high selectivity and fast responsibility because the Pb<sup>2+</sup> ions are pre-protected before leakage but relatively low SQEs (about 60–80%). It is known that the lead-immobilizing capacity is correlated to the density of functional sites in the embedded additives, especially for the method of complexation. However, most of these additives are insulating and, in some 

Nature | Vol 617 | 25 May 2023 | **691** 

Perspective 

**Table 2 | Recommended testing conditions of lead leakage for PSCs** 

||**Conditions**|**Specifications**|
|---|---|---|
|**Water**|pH = 4.2; 0.1 ppm Ca<sup>2+</sup>; dripping speed:<br>5 ml h<sup>−1</sup>per 1-cm<sup>2</sup>device; soaking with<br>120 ml water per 1-cm<sup>2</sup>device; room<br>temperature or mediated temperature|The pH values and competing Ca<sup>2+</sup>ions are used to mimic acidic rain. The water volume and flow rate are used<br>to simulate one day of soaking and dripping under heavy rainfall (50 mm h<sup>−1</sup>).|
|**Samples**|Aged perovskite films|To mimic the case of full exposure of the perovskite layer to water.|
|**Metrics**|LR,_c_LLand SQE|(<br>)<br>_c_<br>LR<br>100%;<br>; SQE<br>1<br>100%<br>leaked lead fromperovskite<br>lead contained in perovskite<br>LL<br>leaked lead fromperovskite<br>volume of exposed water<br>leaked Pb fromimmobilizedperovskite<br>leaked Pb frompristine perovskite<br>=<br>×<br>=<br>=<br>−<br>×|



cases, light absorbing, which can undermine charge transport and photon harvesting, and the interaction between the additives and the Pb precursors can affect perovskite crystallization. Therefore, a trade-off between PCE and SQE might occur when the additive concentration exceeds the tolerance of perovskite materials<sup>122</sup> . Nevertheless, a rational dose of Pb-immobilizing additives in the perovskite layer can advantageously lead to PCE increase and lifetime increase (Table 1), which are defined by the PCE and lifetime ratio of the best optimized device to the pristine device, respectively. Furthermore, owing to the inert character of grain encapsulation and insolubility of the as-formed lead complexes, these approaches for grain isolation and chemical complexation would challenge the lead-recycling process, which relies on the ease of extraction of the lead from the device. Also, formation of a homogeneous capping layer at the perovskite grain boundaries might be problematic, especially in large-scale manufacturing, because of the difficulties in controlling the layer thickness, restricting the upscaling of PSCs. In these aspects, the structure integration seems to be more promising, in which the lead-immobilizing capacity is related to the structural stability rather than the chelating sites of the additives, leading to relatively higher SQEs of about 80%. 

By contrast, the implementation of lead adsorbents at the exterior of the device is more effective in the suppression of lead leakage with SQE approaching 100% because a large amount of materials can be loaded without influence on the device performance. However, it still suffers from several drawbacks that may reduce their effectiveness. First, the lead adsorbents are specifically designed to capture the Pb ions after their release from the perovskite lattice and the sorption speed should be extremely fast, otherwise the capturing efficiency might be limited if the water flux is fast or the Pb<sup>2+</sup> concentration is high at the initial stage of device damage. Second, the variation of environmental pH and temperature and the presence of other metal ions (for example, Ca<sup>2+</sup> , Mg<sup>2+</sup> ) within the water may defunctionalize the Pb adsorbents. Third, the lead adsorbents, as well as showing excellent Pb-adsorbing capacity, should also support scratching resistance, ultraviolet stability and high selectivity of lead ions. 

Notably, the lead leaking from PSCs and their adsorption is strongly dependent on the testing conditions, such as temperature, pH values and volume of the exposed water, and how the devices are broken. However, the reported SQE values in Table 2 were measured in completely different conditions. To quantitatively evaluate the lead leakage from PSCs and compare the use of different lead-immobilization techniques from worldwide laboratories, a standard lead-leakage test supported by computational modelling needs to be established. Also, some metrics, for example, total leaked lead concentration ( _c_ LL), leakage ratio (LR) and SQE, are recommended to be measured in a standard way, and two occasions (that is, water soaking and water dripping) of perovskite exposure in case of harsh weather conditions (acidic and heavy rain) are mimicked as listed in Table 2 and illustrated in Fig. 3a. Moreover, the aged perovskite films instead of completed devices, together with or without delaminated encapsulants, should be used in the lead-leakage measurement to simulate the case of full exposure of the perovskite layer to water. Furthermore, biological tests can also be performed to evaluate the influence of the leaked lead on the growth of plants or animals. 

##### **Conclusions and future prospects** 

Research on lead-based PSCs has advanced rapidly on both the efficiency and stability fronts. It is time now to examine how to pursue the next phase of implementing this promising technology on the large industrial scale with sustainability in mind, avoiding any possible leakage of lead in the environment from the preparation of the precursors to the long-term working life of the solar panel. The questions are, which options should researchers focus on to fulfil the goal of developing a safe technology that does not harm the environment or human health and which practices need to be abandoned. 

###### **Towards lead immobilization in PSCs** 

As already surveyed in this Perspective, techniques for lead scavenging in PSCs include in situ grain encapsulation, reducing lead solubility, strengthening internal connectivity and capturing leaked lead. Considering the available means to avoid lead contamination and situations that may lead to device damage, a future blueprint for lead immobilization can be outlined. 

To improve SQE without sacrificing device performance, the optical constants (for example, refractive index, absorption coefficients) and electrical properties (for example, conductivity, energy levels) of the additives used in the interior of the PSCs for lead immobilization need to be further optimized to eliminate their influence on photocharge generation and extraction. Moreover, the interaction between the additives and lead precursors should be tuned by adjusting the coordination strength, additive concentration or processing methods to improve perovskite crystallinity. Different lead-immobilizing approaches can be combined in one device. For instance, combining interior strategies (that is, structural integration) to prevent most of the lead escape from the device and chemical capturing of leaking lead with lead adsorbents in encapsulants, as illustrated in Fig. 3b. 

Further investigation of the temporal dynamics of lead escape from PSCs and lead capturing from water in different environmental conditions (for example, pH, temperature) can also provide guidelines for the optimization of lead-immobilization strategies towards practical application<sup>123</sup> . To guarantee sufficient lead-immobilizing capacity and resistance to re-dissolution, researchers should choose additives abundant in anchoring sites, such as by grafting the lead-chelating functional groups on a backbone with high specific surface area (such as CNTs<sup>34</sup> , graphene<sup>56</sup> , metal–organic framework<sup>57</sup> ), and persistent binding energy with Pb<sup>2+</sup> in a broad range of environmental conditions. Moreover, some environmentally friendly and degradable agents such as magnetic nanoparticles and chitosan composites, which exhibit promising activity to remove lead from wastewater in wide ranges of pH and temperature<sup>124–126</sup> , might be explored as lead adsorbents in PSCs to improve their availability at various weather conditions without further pollution. Even though the bioavailability of immobilized lead is substantially reduced, these compounds might be re-dissolved and cause potential hazards during long-term exposure. In this respect, lessons from hydrogel of polyamides<sup>41</sup> or self-bundling of CNTs<sup>34</sup> to precipitate the lead products from water, and integration of the perovskite layer 

**692** | Nature | Vol 617 | 25 May 2023 



<!-- Start of picture text -->
a<br>Pb<br>Time<br>WWater soakingater soaking<br>Testing instrument Lead detection<br>30˚<br>Safe to use<br>Time<br>Water dripping Biological testing Data analysis<br>b<br>Glass/FTO<br>CTL<br>Perovskite Pb immobilization structure<br>CTL with enhanced integrity<br>Electrode<br>Pb adsorbent<br>Encapsulant Materials with high<br>Pb-adsorbing capacity<br>SQE (%)<br> (ppm) c LL LR<br><!-- End of picture text -->

**Fig. 3 | Proposed lead-leakage measurements and device structure for lead immobilization. a** , Schematic illustration of the detection of leaking lead in the cases of water soaking of the perovskite layer and water dripping from the perovskite layer with precisely defined metrics, for example, LR, _c_ LL and SQE, 

and the evaluation of the potential impact of the leaked lead on the growth of plants and animals. **b** , Proposed device structure for lead immobilization, including interior and exterior strategies. CTL, charge-transport layer; FTO, fluorine-doped tin oxide. 

within the device to prevent its delamination and fragmentation in environmental water, are desirable. 

###### **Considering the full life cycle of PSCs** 

Lead leakage should be avoided when considering the full life cycle of PSCs. Starting with the preparation of lead halide perovskite films for photovoltaic applications, the overwhelming majority of researchers have adapted spin coating as their method of choice; this should be replaced by other solution-processing methods such as slot die coating, screen printing or doctor blading, as these waste only a very small percentage of the perovskite precursors compared with spin coating. Also, lead-immobilization strategies can be introduced into the precursor solutions to reduce the bioavailability of lead-containing waste. PSCs should be specifically optimized to prevent lead leakage according to their application. For example, flexible electronics are directly accessible to humans because of their potential applications in daily life and the plastic substrates are prone to damage because they are sensitive to light, heat, scratching and bending. Therefore, self-curing ability by mixing healable materials<sup>102</sup> and strain modulation to facilitate stress relaxation<sup>127</sup> should be endowed in flexible PSCs to improve their mechanical resistance. 

Strategies should also be developed to dispose end-of-life perovskite devices. Ideally, all components of the multilayered PSCs should be recycled for reuse to save their energy-payback time, especially the lead compounds because of their toxicity. Techniques of lead recycling from PSCs were generally based on electrochemical deposition<sup>128</sup> , selective solvent extraction<sup>129–131</sup> , desorption from precipitated lead compounds<sup>6,132</sup> and so on<sup>30,133</sup> . Even though very high recycling yield can be achieved<sup>6,128–132</sup> , these lead-recycling methods involve a large amount of organic solvents and complex energy-consuming processes, which increase the recycling cost and challenge their large-scale application. Furthermore, we should note that lead immobilization with highly complexed Pb<sup>2+</sup> would be a challenge for lead recycling, so the 

potential for lead recycling should be considered as one of the criteria for the selection of lead-immobilization strategies. 

Finally, practical deployment of optoelectronic devices based on lead halide perovskites should be accompanied by in-depth occupational and local population risk assessments and the prevention of lead leakage during their operation and at end of life is not only legally required but also an ethical obligation. Specific legislation on lead use can drive innovation on the development of strategies in lead immobilization and device recycling. Meanwhile, emergency remediation must be planned to mitigate unintentional airborne emission of lead soil pollution in case of fire accidents. Moreover, the PSCs should pass a standard test to evaluate the potential risk of lead leakage before putting them on the market. 

1. Kim, H. S. et al. Lead iodide perovskite sensitized all-solid-state submicron thin film mesoscopic solar cell with efficiency exceeding 9%. _Sci. Rep._ **2** , 591 (2012). 

2. National Renewable Energy Laboratory (NREL). Best research-cell efficiency chart. _NREL_ https://www.nrel.gov/pv/cell-efficiency.html (2023). 

3. Mei, A. et al. Stabilizing perovskite solar cells to IEC61215:2016 standards with over 

   - 9,000-h operational tracking. _Joule_ **4** , 2646–2660 (2020). 

4. Kim, M. et al. Conformal quantum dot–SnO2 layers as electron transporters for efficient 

   - perovskite solar cells. _Science_ **375** , 302–306 (2022). 

5. Babayigit, A., Ethirajan, A., Muller, M. & Conings, B. Toxicity of organometal halide 

   - perovskite solar cells. _Nat. Mater._ **15** , 247–251 (2016). 

6. Park, S. Y. et al. Sustainable lead management in halide perovskite solar cells. _Nat. Sustain._ **3** , 1044–1051 (2020). 

7. Park, N. G., Grätzel, M., Miyasaka, T., Zhu, K. & Emery, K. Towards stable and commercially available perovskite solar cells. _Nat. Energy_ **1** , 16152 (2016). 

8. Bellinger, D. C. Very low lead exposures and children’s neurodevelopment. _Curr. Opin. Pediatr._ **20** , 172–177 (2008). 

9. Acharya, S. Lead between the lines. _Nat. Chem._ **5** , 894–894 (2013). 

10. Van de Wiele, T. R. et al. Comparison of five in vitro digestion models to in vivo experimental results: lead bioaccessibility in the human gastrointestinal tract. _J. Environ. Sci. Health A_ **42** , 1203–1211 (2007). 

11. Pourrut, B., Shahid, M., Dumat, C., Winterton, P. & Pinelli, E. Lead uptake, toxicity, and 

   - detoxification in plants. _Rev. Environ. Contam. Toxicol._ **213** , 113–136 (2011). 

12. Fabini, D. Quantifying the potential for lead pollution from halide perovskite photovoltaics. _J. Phys. Chem. Lett._ **6** , 3546–3548 (2015). 

Nature | Vol 617 | 25 May 2023 | **693** 

### Perspective 

13. Heo, Y. J. et al. Enhancing performance and stability of tin halide perovskite light emitting diodes via coordination engineering of Lewis acid–base adducts. _Adv. Funct. Mater._ **31** , 2106974 (2021). 

14. Awais, M., Kirsch, R. L., Yeddu, V. & Saidaminov, M. I. Tin halide perovskites going forward: Frost diagrams offer hints. _ACS Mater. Lett._ **3** , 299–307 (2021). 

15. Tao, S. et al. Absolute energy level positions in tin- and lead-based halide perovskites. _Nat. Commun._ **10** , 2560 (2019). 

16. Ke, W. & Kanatzidis, M. G. Prospects for low-toxicity lead-free perovskite solar cells. _Nat. Commun._ **10** , 965 (2019). 

17. Xiao, Z., Meng, W., Wang, J., Mitzi, D. B. & Yan, Y. Searching for promising new perovskitebased photovoltaic absorbers: the importance of electronic dimensionality. _Mater. Horiz._ **4** , 206–216 (2017). 

18. Lyu, M. Q. et al. Organic–inorganic bismuth (III)-based material: a lead-free, air-stable and solution-processable light-absorber beyond organolead perovskites. _Nano Res._ **9** , 692–702 (2016). 

19. Xiao, Z., Song, Z. & Yan, Y. From lead halide perovskites to lead-free metal halide perovskites and perovskite derivatives. _Adv. Mater._ **31** , 1803792 (2019). 

20. Yin, W.-J., Shi, T. & Yan, Y. Superior photovoltaic properties of lead halide perovskites: insights from first-principles theory. _J. Phys. Chem. C_ **119** , 5253–5264 (2015). 

21. Lee, J.-W., Tan, S., Seok, S. I., Yang, Y. & Park, N.-G. Rethinking the A cation in halide perovskites. _Science_ **375** , eabj1186 (2022). 

22. Miyata, K. et al. Large polarons in lead halide perovskites. _Sci. Adv._ **3** , e1701217 (2017). 23. Huang, J., Yuan, Y., Shao, Y. & Yan, Y. Understanding the physical properties of hybrid perovskites for photovoltaic applications. _Nat. Rev. Mater._ **2** , 17042 (2017). 

24. Vidal, R. et al. Assessing health and environmental impacts of solvents for producing perovskite solar cells. _Nat. Sustain._ **4** , 277–285 (2021). 

25. Ren, M., Qian, X., Chen, Y., Wang, T. & Zhao, Y. Potential lead toxicity and leakage issues on lead halide perovskite photovoltaics. _J. Hazard. Mater._ **426** , 127848 (2022). 

26. Tian, X., Stranks, S. D. & You, F. Life cycle assessment of recycling strategies for perovskite photovoltaic modules. _Nat. Sustain._ **4** , 821–829 (2021). 

27. Alberola-Borras, J. A. et al. Perovskite photovoltaic modules: life cycle assessment of pre-industrial production process. _iScience_ **9** , 542–551 (2018). 

28. Jin, X. et al. Mitigating potential lead leakage risk of perovskite solar cells by device architecture engineering from exterior to interior. _ACS Energy Lett._ **7** , 3618–3636 (2022). 

29. Wu, P., Wang, S., Li, X. & Zhang, F. Beyond efficiency fever: preventing lead leakage for perovskite solar cells. _Matter_ **5** , 1137–1161 (2022). 

30. Zhang, H. & Park, N.-G. Towards sustainability with self-healing and recyclable perovskite solar cells. _eScience_ **2** , 567–572 (2022). 

31. Li, J. et al. Biological impact of lead from halide perovskites reveals the risk of introducing a safe threshold. _Nat. Commun._ **11** , 310 (2020). **This work investigated the bioavailability of leaked lead from PSCs and its impact on the growth of plants.** 

32. Billen, P. et al. Comparative evaluation of lead emissions and toxicity potential in the life cycle of lead halide perovskite photovoltaics. _Energy_ **166** , 1089–1096 (2019). 

33. Hailegnaw, B., Kirmayer, S., Edri, E., Hodes, G. & Cahen, D. Rain on methylammonium lead iodide based perovskites: possible environmental effects of perovskite solar cells. _J. Phys. Chem. Lett._ **6** , 1543–1547 (2015). 

34. Wang, J. et al. Polyacrylic acid grafted carbon nanotubes for immobilization of lead(II) in perovskite solar cell. _ACS Energy Lett._ **7** , 1577–1585 (2022). **This study reported an efficient lead-immobilization method by taking advantage of high-specific-surface-area and self-aggregation properties of CNTs.** 

35. Liang, Y. et al. Lead leakage preventable fullerene-porphyrin dyad for efficient and stable perovskite solar cells. _Adv. Funct. Mater._ **32** , 2110139 (2021). 

36. Cao, Q. et al. Environmental-friendly polymer for efficient and stable inverted perovskite solar cells with mitigating lead leakage. _Adv. Funct. Mater._ **32** , 2201036 (2022). 

37. Hu, Y. et al. A holistic sunscreen interface strategy to effectively improve the performance of perovskite solar cells and prevent lead leakage. _Chem. Eng. J._ **433** , 134566 (2022). 

38. Zhang, H. et al. Multimodal host–guest complexation for efficient and stable perovskite photovoltaics. _Nat. Commun._ **12** , 3383 (2021). 

39. Meng, X. et al. A biomimetic self-shield interface for flexible perovskite solar cells with negligible lead leakage. _Adv. Funct. Mater._ **31** , 2106460 (2021). 

40. Wei, X. et al. Avoiding structural collapse to reduce lead leakage in perovskite photovoltaics. _Angew. Chem. Int. Ed._ **61** , e202204314 (2022). **In this work, the lead leaking from PSCs was effectively suppressed by constructing a robust 2D perovskite structure on top of a 3D perovskite surface.** 

41. Niu, B. et al. Mitigating the lead leakage of high-performance perovskite solar cells via in situ polymerized networks. _ACS Energy Lett._ **6** , 3443–3449 (2021). **This study constructed a perovskite/polymer matrix within the perovskite films by means of in situ polymerization of acrylamide, which can form hydrogels when exposed to water and hence prevent lead leakage.** 

42. Zhu, X. et al. Photoinduced cross linkable polymerization of flexible perovskite solar cells and modules by incorporating benzyl acrylate. _Adv. Funct. Mater._ **32** , 2202408 (2022). 

43. Zhang, H. et al. Design of superhydrophobic surfaces for stable perovskite solar cells with reducing lead leakage. _Adv. Energy Mater._ **11** , 2102281 (2021). **This work reported a strategy to suppress lead leakage from PSCs by depositing superhydrophobic molecules on top of a perovskite layer.** 

44. Bai, Y. et al. Oligomeric silica-wrapped perovskites enable synchronous defect passivation and grain stabilization for efficient and stable perovskite photovoltaics. _ACS Energy Lett._ **4** , 1231–1240 (2019). 

45. Liu, T. et al. Stable formamidinium-based perovskite solar cells via in situ grain encapsulation. _Adv. Energy Mater._ **8** , 1800232 (2018). 

46. Yang, S. et al. Stabilizing halide perovskite surfaces for solar cell operation with wide-bandgap lead oxysalts. _Science_ **365** , 473–478 (2019). 

47. Jana, A. & Kim, K. S. Water-stable, fluorescent organic inorganic hybrid and fully inorganic perovskites. _ACS Energy Lett._ **3** , 2120–2126 (2018). 

48. Zhang, Y. et al. Water-repellent perovskites induced by a blend of organic halide salts for efficient and stable solar cells. _ACS Appl. Mater. Interfaces_ **13** , 33172–33181 (2021). 

49. Li, N. et al. Cation and anion immobilization through chemical bonding enhancement with fluorides for stable halide perovskite solar cells. _Nat. Energy_ **4** , 408–415 (2019). 

50. Li, X. et al. Constructing heterojunctions by surface sulfidation for efficient inverted perovskite solar cells. _Science_ **375** , 434–437 (2022). 

51. Li, X. et al. In-situ cross-linking strategy for efficient and operationally stable methylammoniun lead iodide solar cells. _Nat. Commun._ **9** , 3806 (2018). 

52. Chen, S. et al. Trapping lead in perovskite solar modules with abundant and low-cost cation-exchange resins. _Nat. Energy_ **5** , 1003–1011 (2020). **This study reported a method to trap lead in PSCs by integrating mesoporous cationexchange resins with excellent selectivity of lead ions into carbon electrodes.** 

53. Chen, S. et al. Preventing lead leakage with built-in resin layers for sustainable perovskite solar cells. _Nat. Sustain._ **4** , 636–643 (2021). **This work implemented a lead-adsorbing scaffold in PSCs, which is more effective in suppressing lead leakage than the device with the coating at the exterior of a glass surface.** 

54. Li, X. et al. On-device lead sequestration for perovskite solar cells. _Nature_ **578** , 555–558 (2020). **In this study, lead-absorbing materials with suitable transparency and lead-chelating activity at various temperatures were applied at both the front and back sides of the device stack to prevent lead leakage in a wide range of temperature conditions.** 

55. Xiao, X. et al. Lead-adsorbing ionogel-based encapsulation for impact-resistant, stable, and lead-safe perovskite modules. _Sci. Adv._ **7** , eabi8249 (2021). 

56. Li, Z. et al. Sulfonated graphene aerogels enable safe-to-use flexible perovskite solar modules. _Adv. Energy Mater._ **12** , 2103236 (2021). 

57. Huckaba, A. J. et al. Lead sequestration from perovskite solar cells using a metal–organic framework polymer composite. _Energy Technol._ **8** , 2000239 (2020). 

58. Douay, F. et al. Assessment of potential health risk for inhabitants living near a former lead smelter. Part 1: metal concentrations in soils, agricultural crops, and homegrown vegetables. _Environ. Monit. Assess._ **185** , 3665–3680 (2013). 

59. Edwards, M. Fetal death and reduced birth rates associated with exposure to leadcontaminated drinking water. _Environ. Sci. Technol._ **48** , 739–746 (2014). 

60. Chandran, L. & Cataldo, R. Lead poisoning: basics and new developments. _Pediatr. Rev._ **31** , 399–406 (2010). 

61. Canfield, R. L. et al. Intellectual impairment in children with blood lead concentrations below 10 microg per deciliter. _New Engl. J. Med._ **348** , 1517–1526 (2003). 

62. Barbosa, F., Tanus-Santos, J. E., Gerlach, R. F. & Parsons, P. J. A critical review of biomarkers used for monitoring human exposure to lead: advantages, limitations, and future needs. _Environ. Health Perspect._ **113** , 1669–1674 (2005). 

63. World Health Organization (WHO). Guidelines for drinking-water quality, 4th edition, incorporating the 1st addendum. _WHO_ https://www.who.int/publications/i/item/ 9789241549950 (2017). 

64. United States Environmental Protection Agency (EPA). National primary drinking water regulations: proposed lead and copper rule revisions. _EPA_ https://www.epa.gov/ dwreginfo/lead-and-copper-rule (2019). 

65. Technology Standards Department of State Bureau of Environmental Protection of China. Environmental quality standard for soils GB 15618-1995. _ChineseStandard.net_ https:// www.chinesestandard.net/PDF.aspx/GB15618-1995 (1995). 

66. World Health Organization & Food and Agriculture Organization of the United Nations. Evaluation of certain food additives: fifty-ninth report of the Joint FAO/WHO Expert Committee on Food Additives. _WHO_ https://apps.who.int/iris/handle/10665/42601 (2002). 

67. Centers for Disease Control and Prevention (CDC). Recommended actions based on blood lead level. _CDC_ https://www.cdc.gov/nceh/lead/advisory/acclpp/actions-blls.htm (2022). 

68. Hudcova, H., Vymazal, J. & Rozkosny, M. Present restrictions of sewage sludge application in agriculture within the European Union. _Soil Water Res._ **14** , 104–120 (2019). 

69. European Commission. Restriction of hazardous substances in electrical and electronic equipment (RoHS). _European Commission_ https://environment.ec.europa.eu/topics/ waste-and-recycling/rohs-directive_en (2017). 

70. legislation.gov.uk. Directive 2011/65/EU of the European Parliament and of the Council of 8 June 2011 on the restriction of the use of certain hazardous substances in electrical and electronic equipment (recast) (Text with EEA relevance). _legislation.gov.uk_ https://www. legislation.gov.uk/eudr/2011/65 (2011). 

71. Celik, I. et al. Life Cycle Assessment (LCA) of perovskite PV cells projected from lab to fab. _Sol. Energy Mater. Sol. Cells_ **156** , 157–169 (2016). 

72. Vidal, R., Alberola‐Borràs, J. A., Sánchez‐Pantoja, N. & Mora‐Seró, I. Comparison of perovskite solar cells with other photovoltaics technologies from the point of view of life cycle assessment. _Adv. Energy Sustain. Res._ **2** , 2000088 (2021). 

73. Davidson, A. J., Binks, S. P. & Gediga, J. Lead industry life cycle studies: environmental impact and life cycle assessment of lead battery and architectural sheet production. _Int. J. Life Cycle Assess._ **21** , 1624–1636 (2016). 

74. Su, P. et al. Pb-based perovskite solar cells and the underlying pollution behind clean energy: dynamic leaching of toxic substances from discarded perovskite solar cells. _J. Phys. Chem. Lett._ **11** , 2812–2817 (2020). 

75. Coon, S. et al. Whole-body lifetime occupational lead exposure and risk of Parkinson’s disease. _Environ. Health Perspect._ **114** , 1872–1876 (2006). 

76. Satarug, S., Gobe, G. C., Vesey, D. A. & Phelps, K. R. Cadmium and lead exposure, nephrotoxicity, and mortality. _Toxics_ **8** , 86 (2020). 

77. Wang, G. et al. An across-species comparison of the sensitivity of different organisms to Pb-based perovskites used in solar cells. _Sci. Total Environ._ **708** , 135134 (2020). 

78. Benmessaoud, I. R. et al. Health hazards of methylammonium lead iodide based perovskites: cytotoxicity studies. _Toxicol. Res._ **5** , 407–419 (2016). 

79. Bae, S. Y. et al. Hazard potential of perovskite solar cell technology for potential implementation of “safe-by-design” approach. _Sci. Rep._ **9** , 4242 (2019). 

80. Zhai, Y., Hunting, E. R., Wouterse, M., Peijnenburg, W. J. G. M. & Vijver, M. G. Importance of exposure dynamics of metal-based nano-ZnO, -Cu and -Pb governing the metabolic potential of soil bacterial communities. _Ecotoxicol. Environ. Saf._ **145** , 349–358 (2017). 

**694** | Nature | Vol 617 | 25 May 2023 

81. Zhai, Y., Wang, Z., Wang, G., Peijnenburg, W. J. G. M. & Vijver, M. G. The fate and toxicity of 117. Yang, Z. et al. Multifunctional phosphorus-containing Lewis acid and base passivation Pb-based perovskite nanoparticles on soil bacterial community: impacts of pH, humic enabling efficient and moisture-stable perovskite solar cells. _Adv. Funct. Mater._ **30** , acid, and divalent cations. _Chemosphere_ **249** , 126564 (2020). 1910710 (2020). 

82. World Health Organization (WHO). Evaluation of certain food additives and contaminants: 118. Mokhtar, M. Z. et al. Bioinspired scaffolds that sequester lead ions in physically damaged seventy-third [73rd] report of the Joint FAO/WHO Expert Committee on Food Additives. high efficiency perovskite solar cells. _Chem. Commun._ **57** , 994–997 (2021). _WHO_ https://apps.who.int/iris/handle/10665/44515 (2011). 119. Horvath, E. et al. Fighting health hazards in lead halide perovskite optoelectronic 

83. Yan, D. et al. Lead leaching of perovskite solar cells in aqueous environments: a quantitative devices with transparent phosphate salts. _ACS Appl. Mater. Interfaces_ **13** , 33995–34002 investigation. _Sol. RRL_ **6** , 2200332 (2022). (2021). 

84. Ponti, C. et al. Environmental lead exposure from halide perovskites in solar cells. _Trends_ 120. He, Z. et al. Simultaneous chemical crosslinking of SnO2 and perovskite for high‐ _Ecol. Evol._ **37** , 281–283 (2022). performance planar perovskite solar cells with minimized lead leakage. _Sol. RRL_ **6** , 

85. Juarez-Perez, E. J. & Haro, M. Perovskite solar cells take a step forward. _Science_ **368** , 1309 2200567 (2022). (2020). 121. Li, Z. et al. An effective and economical encapsulation method for trapping lead leakage 

86. Shi, L. et al. Gas chromatography–mass spectrometry analyses of encapsulated stable in rigid and flexible perovskite photovoltaics. _Nano Energy_ **93** , 106853 (2022). perovskite solar cells. _Science_ **368** , eaba2412 (2020). 122. Luo, H. et al. Sustainable Pb management in perovskite solar cells toward eco‐friendly 

87. Raja, S. N. et al. Encapsulation of perovskite nanocrystals into macroscale polymer development. _Adv. Energy Mater._ **12** , 2201242 (2022). matrices: enhanced stability and polarization. _ACS Appl. Mater. Interfaces_ **8** , 35523–35533 123. Dou, J., Bai, Y. & Chen, Q. Challenges of lead leakage in perovskite solar cells. _Mater._ (2016). _Chem. Front._ **6** , 2779–2789 (2022). 

88. Wu, J. et al. A simple way to simultaneously release the interface stress and realize the 124. Shahabuddi, S. et al. Kinetic and equilibrium adsorption of lead from water using inner encapsulation for highly efficient and stable perovskite solar cells. _Adv. Funct._ magnetic metformin-substituted SBA-15. _Environ. Sci. Water Res. Technol._ **4** , 549–558 _Mater._ **29** , 1905336 (2019). (2018). 

89. Li, Z. et al. Photoelectrochemically active and environmentally stable CsPbBr3/TiO2 core/ 125. Singh, R. & Bhateria, R. Experimental and modeling process optimization of lead adsorption shell nanocrystals. _Adv. Funct. Mater._ **28** , 1704288 (2018). on magnetite nanoparticles via isothermal, kinetics, and thermodynamic studies. _ACS_ 

90. Ryu, I. et al. In vivo plain X-ray imaging of cancer using perovskite quantum dot _Omega_ **5** , 10826–10837 (2020). scintillators. _Adv. Funct. Mater._ **31** , 2102334 (2021). 126. Reddy, D. H. K. & Lee, S. M. Application of magnetic chitosan composites for the removal 

91. Zhou, W. et al. Charge transfer boosting moisture resistance of seminude perovskite of toxic metal and dyes from aqueous solutions. _Adv. Colloid Interface Sci._ **201** , 68–93 nanocrystals via hierarchical alumina modulation. _J. Phys. Chem. Lett._ **11** , 3159–3165 (2013). (2020). 127. Zhang, H. & Park, N.-G. Strain control to stabilize perovskite solar cells. _Angew. Chem. Int._ 

92. Zhang, Y. et al. Enhancing efficiency and stability of perovskite solar cells via in situ _Ed._ **61** , e202212268 (2022). incorporation of lead sulfide layer. _Sustain. Energy Fuels_ **5** , 3700–3704 (2021). 128. Poll, C. G. et al. Electrochemical recycling of lead from hybrid organic–inorganic 

93. Guo, Y., Sato, W., Shoyama, K. & Nakamura, E. Sulfamic acid-catalyzed lead perovskite perovskites using deep eutectic solvents. _Green Chem._ **18** , 2946–2955 (2016). formation for solar cell fabrication on glass or plastic substrates. _J. Am. Chem. Soc._ **138** , 129. Wang, K. et al. “One-key-reset” recycling of whole perovskite solar cell. _Matter_ **4** , 5410–5416 (2016). 2522–2541 (2021). 

94. Hosokawa, H. et al. Solution-processed intermediate-band solar cells with lead sulfide 130. Feng, X. et al. Close-loop recycling of perovskite solar cells through dissolutionquantum dots and lead halide perovskites. _Nat. Commun._ **10** , 43 (2019). recrystallization of perovskite by butylamine. _Cell Rep. Phys. Sci._ **2** , 100341 (2021). 

95. Xie, L., Zhang, T. & Zhao, Y. Stabilizing the MAPbI3 perovksite via the in-situ formed lead 131. Kim, B. J. et al. Selective dissolution of halide perovskites as a step towards recycling sulfide layer for efficient and robust solar cells. _J. Energy Chem._ **47** , 62–65 (2020). solar cells. _Nat. Commun._ **7** , 11735 (2016). 

96. Lian, H. et al. Metal halide perovskite quantum dots for amphiprotic bio-imaging. _Coordin._ 132. Chen, B. et al. Recycling lead and transparent conductors from perovskite solar modules. _Chem. Rev._ **452** , 214313 (2022). _Nat. Commun._ **12** , 5859 (2021). 

97. Chen, Q. et al. All-inorganic perovskite nanocrystal scintillators. _Nature_ **561** , 88–93 133. Liu, F. et al. Recycling and recovery of perovskite solar cells. _Mater. Today_ **43** , 185–197 (2018). (2021). 

98. You, J. et al. Improved air stability of perovskite solar cells via solution-processed metal 134. Clementi, E., Raimondi, D. L. & Reinhardt, W. P. Atomic screening constants from SCF oxide transport layers. _Nat. Nanotechnol._ **11** , 75–81 (2016). functions. II. Atoms with 37 to 86 electrons. _J. Chem. Phys._ **47** , 1300–1307 (1967). 

99. Cao, Q. et al. Efficient and stable inverted perovskite solar cells with very high fill factors 135. Kim, J. Y., Lee, J. W., Jung, H. S., Shin, H. & Park, N. G. High-efficiency perovskite solar via incorporation of star-shaped polymer. _Sci. Adv._ **7** , eabg0633 (2021). cells. _Chem. Rev._ **120** , 7867–7918 (2020). 

100. Lv, Y. et al. Low-temperature atomic layer deposition of metal oxide layers for perovskite 136. Lee, J. W. & Park, N. G. Chemical approaches for stabilizing perovskite solar cells. _Adv._ solar cells with high efficiency and stability under harsh environmental conditions. _ACS Energy Mater._ **10** , 1903249 (2020). _Appl. Mater. Interfaces_ **10** , 23928–23937 (2018). 137. Tchounwou, P. B., Yedjou, C. G., Patlolla, A. K. & Sutton, D. J. in _Molecular, Clinical and_ 

101. Kim, Y. R. et al. Inner encapsulating approach for moisture-stable perovskite solar cells. _Environmental Toxicology. Experientia Supplementum_ Vol. 101, 133–164 (Springer, 2012). _Sol. RRL_ **5** , 2100351 (2021). 138. Stoumpos, C. C. et al. Hybrid germanium iodide perovskite semiconductors: active lone 

102. Jiang, Y. et al. Reduction of lead leakage from damaged lead halide perovskite solar pairs, structural distortions, direct and indirect energy gaps, and strong nonlinear optical modules using self-healing polymer-based encapsulation. _Nat. Energy_ **4** , 585–593 (2019). properties. _J. Am. Chem. Soc._ **137** , 6804–6819 (2015). **In this study, a self-healable polymer encapsulant was used to prevent lead leakage in** 139. Enghag, P. _Encyclopedia of the Elements: Technical Data - History - Processing - Applications_ **case of mechanical damage.** (Wiley, 2008). 

103. Fu, Z. et al. Encapsulation of printable mesoscopic perovskite solar cells enables high 140. Krishnamoorthy, T. et al. Lead-free germanium iodide perovskite materials for photovoltaic temperature and long-term outdoor stability. _Adv. Funct. Mater._ **29** , 1809129 (2019). applications. _J. Mater. Chem. A_ **3** , 23829–23832 (2015). 

104. Lv, Y., Zhang, H., Liu, R., Sun, Y. & Huang, W. Composite encapsulation enabled superior 141. Shannon, R. D. Revised effective ionic radii and systematic studies of interatomic comprehensive stability of perovskite solar cells. _ACS Appl. Mater. Interfaces_ **12** , distances in halides and chalcogenides. _Acta Crystallogr. A_ **32** , 751–767 (1976). 27277–27285 (2020). 

105. Cheacharoen, R. et al. Design and understanding of encapsulated perovskite solar cells to withstand temperature cycling. _Energy Environ. Sci._ **11** , 144–150 (2018). **Acknowledgements** This research was supported by the National Research Foundation of 

106. Hirata, M. K., Freitas, J. N., Santos, T. E. A., Mammana, V. P. & Nogueira, A. F. Assembly Korea (NRF) grants funded by the Ministry of Science and ICT (MSIT) of Korea under contract considerations for dye-sensitized solar modules with polymer gel electrolyte. _Ind. Eng._ NRF-2021R1A3B1076723 (Research Leader Program), the National Key & Program of China _Chem. Res._ **55** , 10278–10285 (2016). (grant no. 2020YFA07099003) and the Young Scientist Exchange Program between the 

107. Wu, S. et al. 2D metal–organic framework for stable perovskite solar cells with minimized Republic of Korea and the People’s Republic of China. lead leakage. _Nat. Nanotechnol._ **15** , 934–940 (2020). **Herein, the lead leaking from PSCs was properly suppressed by using a lead-chelating Author contributions** N.-G.P. and H.Z. conceived the idea for the study. H.Z. wrote the first draft. **metal–organic framework as the charge-transport layer within the device.** J.-W.L., R.H., A.A. and M.G. contributed to the writing. N.-G.P. edited the manuscript. All authors 

108. Bi, H. et al. Top‐contacts‐interface engineering for high‐performance perovskite solar cell commented on the manuscript. H.Z., J.-W.L., A.A. and N.-G.P. contributed to the preparation of with reducing lead leakage. _Sol. RRL_ **6** , 2200352 (2022). the figures. 

109. Xu, Y. et al. In situ polymer network in perovskite solar cells enabled superior moisture and thermal resistance. _J. Phys. Chem. Lett._ **13** , 3754–3762 (2022). **Competing interests** The authors declare no competing interests. 

110. Liu, Y. et al. Tough, stable and self-healing luminescent perovskite-polymer matrix applicable to all harsh aquatic environments. _Nat. Commun._ **13** , 1338 (2022). **Additional information** 

111. Zhao, J. et al. Strained hybrid perovskite thin films and their impact on the intrinsic stability **Correspondence and requests for materials** should be addressed to Antonio Abate, of perovskite solar cells. _Sci. Adv._ **3** , eaao5616 (2017). Michael Grätzel or Nam-Gyu Park. 

112. Lu, Y.-B. et al. Light enhanced moisture degradation of perovskite solar cell material **Peer review information** _Nature_ thanks Chang-Zhi Li, Rosario Vidal and the other, anonymous, CH3NH3PbI3. _J. Mater. Chem. A_ **7** , 27469–27474 (2019). reviewer(s) for their contribution to the peer review of this work. 

113. Zhang, J. et al. Multifunctional molecule engineered SnO2 for perovskite solar cells with **Reprints and permissions information** is available at http://www.nature.com/reprints. high efficiency and reduced lead leakage. _Sol. RRL_ **5** , 2100464 (2021). **Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in 

114. Mendez L, R. D., Breen, B. N. & Cahen, D. Lead sequestration from halide perovskite solar published maps and institutional affiliations. cells with a low-cost thiol-containing encapsulant. _ACS Appl. Mater. Interfaces_ **14** , 29766–29772 (2022). Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this 

115. Lee, J., Kim, G. W., Kim, M., Park, S. A. & Park, T. Nonaromatic green-solvent-processable, article under a publishing agreement with the author(s) or other rightsholder(s); author dopant-free, and lead-capturable hole transport polymers in perovskite solar cells with self-archiving of the accepted manuscript version of this article is solely governed by the high efficiency. _Adv. Energy Mater._ **10** , 1902662 (2020). terms of such publishing agreement and applicable law. 

116. Edwards, M. & McNeill, L. S. Effect of phosphate inhibitors on lead release from pipes. _J. Am. Water Works Assoc._ **94** , 79–90 (2002). © Springer Nature Limited 2023 

© Springer Nature Limited 2023 

Nature | Vol 617 | 25 May 2023 | **695** 

