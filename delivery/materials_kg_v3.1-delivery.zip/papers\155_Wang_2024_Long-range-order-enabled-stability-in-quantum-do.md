# Long-range order enabled stability in quantum dot light-emitting diodes

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 187 |
| 作者 | Ya‐Kun Wang, Hao-Yue Wan, S. Teale, Luke Grater, Feng Zhao, Zhong-Da Zhang, Hong‐Wei Duan, Muhammad Imran et al. |
| DOI | 10.1038/s41586-024-07363-7 |
| 源文件 | 055_Wang_2024_Long-range-order-enabled-stability-in-quantum-do.pdf |

---
- 1 **Long-range order enabled stability in perovskite quantum dot LEDs** 

- 2 

- 3 Ya-Kun Wang<sup>1,2,4</sup> , Haoyue Wan<sup>2,4</sup> , Sam Teale<sup>2,3</sup> , Luke Grater<sup>2</sup> , Feng Zhao<sup>1</sup> , Zhongda Zhang<sup>1</sup> , 

- 4 Hong-Wei Duan<sup>1</sup> , Muhammad Imran<sup>2</sup> , Sui-Dong Wang<sup>1</sup> , Sjoerd Hoogland<sup>2</sup> , Liang-Sheng 5 Liao<sup>1*</sup> 

- 6 

- 7 1 Institute of Functional Nano & Soft Materials (FUNSOM), Jiangsu Key Laboratory for 

- 8 Carbon-Based Functional Materials & Devices, Soochow University, Suzhou, Jiangsu 

- 9 215123, PR China. 

- 10 2 Department of Electrical and Computer Engineering, University of Toronto, 10 King’s 

- 11 College Road, Toronto, Ontario, M5S 3G4, Canada. 

- 12 3 Clarendon Laboratory, University of Oxford, Oxford, United Kingdom. 

- 13 4 These authors contributed equally to this work. 

- 14 * Email: lsliao@suda.edu.cn. 

- 15 

1 

# 1 **Abstract** 

- 2 **Light-emitting diodes (LEDs) based on perovskite quantum dots have produced** 

- 3 **external quantum efficiencies (EQEs) of over 25% with narrowband emission**<sup>**1,2**</sup> **, but** 

- 4 **these LEDs suffer from limited operating lifetimes. We posit that poor long-range** 

- 5 **ordering in perovskite quantum dot (QD) films – variations in dot size, surface ligand** 

- 6 **density and dot-to-dot stacking – inhibits carrier injection, resulting in inferior** 

- 7 **operating stability due to the large bias required to produce emission in these LEDs.** 

- 8 **Here we report a chemical treatment to improve the long-range order of perovskite QD** 

- 9 **films: the diffraction intensity from the repeating QD units increases 3-fold compared to** 

- 10 **controls. We achieve this using a synergistic dual ligand approach: an iodide-rich agent** 11 **(aniline hydroiodide) for anion exchange and a chemically-reactive agent** 

- 12 **(bromotrimethylsilane) that produces a strong acid which** **_in situ_ dissolves smaller QDs** 

- 13 **to regulate size and more effectively remove less conductive ligands to enable compact,** 14 **uniform and defect-free films. These films exhibit high conductivity (4 × 10**<sup>**-4**</sup> **S m**<sup>**-1**</sup> **),** 15 **which is 2.5-fold higher than that of the control, and represents the highest conductivity** 

- 16 **recorded among perovskite QDs. The high conductivity ensures efficient charge** 17 **transportation, enabling red perovskite QD-LEDs that generate a luminance of 1000 cd** 

- 18 **m**<sup>**-2**</sup> **at a record-low voltage of 2.8 V. The EQE at this luminance is over 20%.** 19 **Furthermore, the stability of the operating device is 100x better than prior red** 20 **perovskite LEDs at EQEs of >20%.** 

- 21 

2 

- 1 Indium phosphide quantum dot-based LEDs and organic LEDs (OLEDs) have achieved 2 impressive performance along many axes, but suffer from broad emission spectra with full- 

- 3 width at half maximum (FWHM, >35 nm)<sup>3-7</sup> . Metal-halide perovskite colloidal quantum dots, 

- 4 which show narrow FWHM (<30 nm)<sup>8-11</sup> , have produced EQEs as high as 25.8% in red 

- 5 wavelengths with FWHM of ~30 nm<sup>2</sup> . However, this champion EQE is achieved at 

- 6 luminance <10 cd m<sup>-2</sup> , whereas real-world applications (cell phones or computer screens) 7 usually require luminance up to 1000 cd m<sup>-2</sup> . Moreover, the operating half-life for perovskite 

- 8 LEDs at an initial luminance of 1000 cd m<sup>-2</sup> has so far been limited to <5 min<sup>12</sup> , hindering 9 commercial prospects for displays. 

10 

11 The stability of an LED is defined by TX, the time taken for the luminance of the LED to drop 12 from the initial luminance (L0) to X% of L0 at a continuous external bias ( _Vex_ ). In this regard, 13 thickness and external bias are decisive to LED stability because they determine the electric 14 field experienced by the emitting material. Increasing the thickness of the emission layer to 15 1.5 µm to reduce the _Vex_ /nm has been shown to increase the stability of green perovskite 16 LEDs<sup>13</sup> . However, this method is limited to specific systems and is not applicable to red 17 perovskite quantum dots because it requires complex temperature/substrate control to 18 produce a perfect single-crystal emission layer. 

19 

20 For perovskite LED materials (quantum dots or quasi-two-dimensional thin films), there 21 exists a tradeoff between low _Vex_ to prolong the operational stability, and the demand of high 22 _Vex_ to increase current densities and meet practical luminance levels.<sup>1,14</sup> Though many studies 23 focus on low luminance levels for stability, and generally measure stability down to T50, for 24 real-world applications, the time taken to sustain a 10% luminance loss (T90) at an operational 25 luminance of ~1000 cd m<sup>-2</sup> is more important as phone/computer screens require up to ~1000 26 cd m<sup>-2</sup> and a 10% luminance loss would be considered defective. Thus, we focused on 27 developing perovskite LEDs with high luminance at a low _Vex_ to demonstrate increased T90 28 stability at 1000 cd m<sup>-2</sup> . 

29 

3 

1 



- 2 **Fig. 1 | Long-range order control strategy** . During surface ligand treatment, the ligands 

- 3 with stronger binding affinity occupy halide vacancies and bind to uncoordinated Pb. In the 

- 4 control case, the ligands have limited passivation ability because of weak Lewis acid/base 

- 5 binding, and the dot-to-dot difference is significant because of the existence of leftover long 

- 6 oleate ligands. In the case of our synergistic dual ligand strategy, the iodide-rich ligand 

- 7 enables anion exchange and passivation, and TMSBr produces strong acid to enable dot-to- 

- 8 dot coherence by dissolving the smallest dots and connecting the size-uniform dots. 

- 9 

10 

- 11 Due to their rapid nucleation and growth rate, perovskite quantum dots tend to form with a 12 distribution of sizes, and with variable ligand coverage.<sup>15</sup> This leads to a disordered 13 arrangement in films which exhibit low conductivity and large barriers to carrier injection 14 ( **Fig 1** ). It is still possible for such films to produce high EQEs under low injection densities, 

- 15 but the large electric fields necessary to produce practical luminances induce destructive ion 

4 

- 1 migration<sup>16</sup> ; and injecting large currents into an emission layer with high resistance generates 

- 2 extra heat, further accelerating degradation<sup>17</sup> . 

- 3 

- 4 One previous strategy to improve long-range order packing is to exchange perovskite QDs 

- 5 with the assistance of a highly polar solvent (DMF), which has proven effective in our 

- 6 previous work in blue and red LEDs<sup>18,19</sup> , but the introduction of this highly polar solvent 

- 7 compromises perovskite quantum dot structural stability and harms operating stability. In a 

- 8 recent work on monolayer blue perovskite LEDs<sup>20</sup> , we demonstrated that reactive halide 9 trimethylsilane (TMS-X) enables ordered films by _in-situ_ producing HX acid for both 

- 10 passivation and long-range order. 

11 

12 Here we report a synergistic dual ligand approach to achieve stable red perovskite LEDs. We 13 use an iodide-rich agent (AnHI) for anion exchange and passivation of the all-inorganic 14 CsPbBr3 quantum dots; and a chemically-reactive agent (TMSBr) to regulate size and surface 15 ligands for long-range order. The liquid nature of TMSBr ensures miscibility with surface16 friendly non-polar solvents, and reacts with protic agents (nucleophilic reaction) to produce a 17 strong acid (HBr) in solution which acts to dissolve QDs with poor ligand coverage. 18 Additionally, TMSBr is a short (three carbon atoms) ligand and thus produces highly 19 conductive QD films needed for efficient LEDs ( **Fig. 1** ). 

20 

21 We started by measuring photoluminescence (PL) spectra to characterize the dot-to-dot 22 coupling and packing behaviour from spectral linewidth ( **Fig. 2** and **Extended Data Fig. 1** ). 23 Treated films show a ~ 7 nm redshift compared to the original and control films, suggesting 24 stronger dot-to-dot interactions<sup>21</sup> ( **Fig. 2a and Supplementary Note 1** for comprehensive 25 sample information). The treated films show FWHM of 28 nm, ~10 nm narrower than that of 26 the original and control films. The narrower emission linewidth suggests an improved size 27 distribution after TMSBr treatment, resulting from the removal of small-size dots. We 28 employed _in-situ_ time-dependent PL measurements to record the TMSBr treatment process. 29 We observed a quick PL spectrum narrowing after TMSBr addition (after 125 s), providing 

5 

- 1 further evidence that TMSBr dissolves smaller dots to improve size uniformity<sup>22</sup> **(Extended** 

- 2 **Data Fig. 2** ). We calculated the size difference from TEM images before and after TMSBr 

- 3 addition, and found the strong acid dissolves non-cubic shaped QDs and smaller sized QDs 

- 4 with size-deviation larger than 30% (<6 nm) ( **Extended data Fig. 3** ). 

- 5 

- 6 We investigated the trap density of films by using excitation-dependent PL quantum yield 7 (PLQY) measurements ( **Fig. 2b** and **Extended Data Fig. 1** ). Below 0.5 mWcm<sup>-2</sup> , original, 8 control and treated QDs all show a PLQY increase when the excitation intensity increases 9 below 0.5 mWcm<sup>-2</sup> . This is consistent with the physical phenomenon that the density of trap 

- 10 states is fixed and as the radiative recombination rate is related to the square of the carrier 11 density there is an increase in radiative recombination with excitation power<sup>23</sup> . The treated 12 films have a maximum PLQY of ~86% at an excitation power of ~0.5 mWcm<sup>-2</sup> , while the 13 PLQY of the original and control exhibit lower PLQY of 52% and 74%, respectively ( **Fig. 2b** 14 and **Extended Fig. 1** ). The treated QD films exhibit over 3.0-fold higher PLQY at a high 15 excitation intensity of ~80 mWcm<sup>-2</sup> . Increased PLQY at high excitation intensity suggests the 16 treated films are less prone to the nonradiative Auger-Meitner recombination<sup>13</sup> , resulting from 17 the removal of small-size dots and improved delocalization of excitons in the long-range 18 ordering films<sup>21</sup> . 

19 

20 We used density functional theory (DFT) to calculate the binding affinity of AnHI/TMSBr 21 and halide migration before and after dual-ligand treatment. The results showed that the 22 binding affinity of TMSBr/AnHI is ~10-fold higher than that of oleate ligands, and the 23 activation energy for halide migration of treated CsPbBrxI3-x is ~0.5 eV higher than the 24 control ( **Extended Data Fig. 4** ). 

25 

6 

1 



- 2 **Fig. 2 | Long-range order behaviour with different ligand treatments** . **a,** photoluminance 

- 3 spectra of control and treated films. **b,** excitation-dependent PLQY of control and treated 

- 4 films **c,** field-effect transistors of control and treated films. **d** , GISAXS pattern of control 

- 5 films, **e** , dot-to-dot ordering and distance of control films calculated from azimuthal 

- 6 integration of the GISAXS diffraction patterns (exchanged once and twice). **f,** GIWAXS 

- 7 pattern from a control film. **g** , GISAXS pattern of treated films. **h** , dot-to-dot ordering and 

- 8 distance of treated films calculated from azimuthal integration of the GISAXS diffraction 

- 9 patterns (exchanged once and twice). **i,** GIWAXS pattern from a treated film. 

10 

- 11 We determined film conductivity by building field-effect transistors with an ITO/perovskite/ 

- 12 Al architecture ( **Fig. 2c** and **Extended Data Fig. 1** ). The channel length ( _L_ ) and channel 

- 13 width ( _W_ ) of the FETs were fixed at 50 m and 1000 m using pre-patterned masks. Both 

7 

- 1 films show linear current-voltage ( _I‒V_ ) characteristics in the scanning voltage range from -2 2 V to 2 V. We extract the conductivity ( _σ_ ¿ of each film by plotting the current as a function of 3 scanning voltage: 

- _L_ 

- 4 _σ_ =<sup>_I_</sup> _V_<sup>_×_</sup> _T ×W_ 

- 5 where _L_ is the channel length, _T_ is the thickness of the films, _W_ is the channel width, and _I/V_ 6 is the slope of the current-voltage curve. We calculated _σ_ as 4.5 × 10<sup>-4</sup> S m<sup>-1</sup> for the 7 AnHI/TMSBr treated film, 3.6-fold and over 10-fold higher than the control and original 8 films, respectively. 

9 

10 We used grazing incidence wide-angle X-ray scattering (GIWAXS) and grazing incidence 11 small-angle X-ray scattering (GISAXS) to investigate the effect of our dual ligand treatment 12 on film ordering ( **Figs. 2d-i** ). We prepared control films using AnHI only and treated films 13 exchanged with AnHI/TMSBr; both films used ~11 nm QDs exchanged twice to improve 14 long-range order and were measured to be 30 nm thick. GISAXS patterns from twice 15 exchanged control and treated films ( **Fig. 2d** and **2g** ) show an obvious increase in diffraction 16 intensity for the treated films and thus improved long-range order in the treated QDs<sup>24,25</sup> . 17 Azimuthal integration of GISAXS patterns shows a sharper first-order peak (~0.05 Å) for 18 both films after the second exchange. The AnHi/TMSBr treated films have 3-fold more 19 intense diffraction overall, however. From GISAXS we measure the average dot-to-dot 20 distance for the control film to be 12.5 nm ( **Fig. 2e** ), whereas the treated films show a first21 order scattering closer to 0.06 Å, indicating a shorter dot-to-dot distance of ~11.3 nm<sup>26</sup> ( **Fig.** 22 **2h** ). The shorter dot-to-dot distance (~1.2 nm) and 3-fold higher peak-to-valley intensity of 23 azimuthal integration indicate the treated films are more closely packed with better long24 range order. 

25 

26 Typically, it is difficult to resolve short-range order in thin films containing small QDs as 27 coherence between multiple unit cells is required. Despite both films having a similar 28 thickness (~30 nm), GIWAXS patterns obtained from each film differ greatly. Control films 29 display a small amount of diffraction from the perovskite crystal structure (instead showing 

8 

- 1 significant diffraction from the indium tin oxide substrate beneath) ( **Fig. 2d** and **2f** ). 2 AnHI/TMSBr treated films show the same (1 0 1) QD orientation ( **Extended Data Fig. 4** ), 3 but exhibit much stronger scattering, 6 times greater than controls, suggesting that QDs 

- 4 within the film are arranged in a continuous, highly ordered pattern ( **Fig. 2i** ). The control and 

- 5 treated films have a similar thickness (with thickness difference < 2 nm as determined by 6 Atomic-Profiler measurement) and composition, with Br/I ratio difference <5% (as 7 determined by X-ray photoelectron spectroscopy measurement, XPS), providing a fair basis 8 for comparing diffraction intensity between control and treated films. Large-area TEM 9 images further support better dot-to-dot coherence ( **Extended Data Fig. 3** ) 

10 

- 11 We next studied the molecular mechanism of surface ligand density control. We used nuclear 12 magnetic resonance (NMR) to examine the effect of TMSBr on resurfacing the quantum dots 13 ( **Fig. 3** ). We dispersed original QDs, control QDs with AnHI ligands, and treated QDs with 14 AnHI/TMSBr in deuterated toluene (Tol). The chemical shift signal intensity between 5-7 15 ppm, assigned to the alkene hydrogen of oleate ligands and octadecene, reduced ~60-fold 16 when the QDs were exchanged using control ligands ( **Fig. 3a** ). These signals disappear 17 almost entirely for the treated QDs, with a 160-fold reduced intensity **(Fig. 3a** ). Fourier18 transform infrared (FTIR) spectroscopy shows greatly reduced signals from alkene hydrogen 19 of the oleate ligands and octadecene, which supports the 1H NMR results ( **Extended Data** 20 **Fig. 3** ). For the treated QDs, there are only signals of -CH 3 in the final solution, which is 21 believed to come from the methyl group of TMSBr ( **Fig. 3b** ). The combination of high PLQY 

- 22 and complete removal of original long oleate ligands suggest the effective passivation and 23 successful resurfacing of TMSBr, leading to films with exceptional long-range order. 

24 

9 

1 



- 2 **Fig. 3 | NMR spectra for surface ligand investigation. a,**<sup>1</sup> H NMR spectra for original, 

- 3 control and treated perovskite quantum dots. **b,** scheme illustrating the surface ligand 

- 4 variation using different ligand treatments. 

- 5 

- 6 As our aim was to improve film stability, we assessed the thermal stability of control and 

- 7 AnHI/TMSBr treated films. Whilst heating films at 100 °C, we recorded the PL intensities as 

- 8 a function of time, we found that control films suffer from thermal quenching: the emission 

- 9 peak of the original and control is less symmetrical, and the intensity decreases quickly to 

- 10 <50% within 15 min with the appearance of a slight shoulder in the shorter wavelengths 

- 11 ( **Extended Data Fig. 1** ). By contrast, the treated QD film samples retain a PLQY above 85% 

- 12 and there is no observable PL peak shift or linewidth broadening even after 50 min under the 

- 13 same conditions ( **Extended Data Fig. 1** ). Confocal PL mapping of original and control films 

10 

- 1 shows bright spots in the film after heating at 100 °C in ambient conditions. Likely this is due 

- 2 to dot aggregation and fusion under heating because of ligand loss and unstable surfaces 

- 3 ( **Extended Data Fig. 5** ). By contrast, the treated films appeared uniform with no observable 

- 4 spots across the film. Scanning electron microscopy (SEM) and atomic force microscopy 

- 5 (AFM) of treated films show a smoother morphology than the original and control ( **Extended** 

- 6 **Data Fig. 5** ). Using density functional theory we find that AnHI/TMSBr provides tight 

- 7 binding to QDs ( **Extended Data Fig. 4** ), suggesting more comprehensive passivation of each 8 QD, and thus ion migration is suppressed. 

- 9 

- 10 Encouraged by the improved conductivity and promising optical properties, we sought next 11 to translate this into optimized LEDs ( **Fig. 4** ). We used a configuration consisting of indium 12 tin oxide (ITO as anode)/ nickel oxide: 4- trifluoromethyl benzoic acid ( <mark>4-CF</mark> 3 <mark>-BA,</mark> hole13 injection layer)/ poly[N,N’-bis(4-butylphenyl)-N,N’-bis(phenyl)-benzidine](Poly-TPD as 14 hole-transport layer)/ perovskite QDs (active layer)/ 3′,3′″,3′″″-(1,3,5-triazine-2,4,615 triyl)tris(([1,1′-biphenyl]-3-carbonitrile)) (CNT2T as electron-transport layer)/ lithium 16 fluoride (LiF)/ aluminum (Al as cathode) ( **Fig. 4a** ). <mark>We used NiO</mark> x <mark>:self-assembled molecule</mark> 17 <mark>(SAM, 4-CF</mark> 3 <mark>-BA) as the hole injection layer (HIL) in view of its good material stability and</mark> 18 <mark>hole-injecting capabilities</mark> 27. We use Poly-TPD on top of NiOx:SAM (HIL) to decrease the 19 charge injection barrier between the HIL and active layer. The thickness of each layer was 20 determined by the cross-sectional TEM ( **Extended Data Fig. 5** ). 

- 21 

- 22 

11 

1 



- 2 **Fig. 4 | LED performance and operating stability. a,** device structure and the materials 

- 3 used in each layer. **b,** electroluminescence spectra of the LEDs in the voltage range of 2.2 V 

- 4 to 4.0 V (corresponds to a current density range of 1 – 90 mA cm<sup>-2</sup> ). **c-e,** current density- 

- 5 voltage , luminance-voltage (d), EQE versus luminance curve (e) of the LEDs. **f,** luminance 

- 6 and EQE histogram of 18 devices. **g,** emission peak wavelength and FWHM obtained from 

- 7 the EL spectra over time. **h,** operating stability of control and treated LEDs. **i,** reported peak 

- 8 EQEs and calculated T90 of red perovskite LEDs. 

9 

- 10 The resulting LEDs exhibit stable electroluminescence with no observable peak shift or 11 change in FWHM in the current density range of 1 to 90 mA cm<sup>-2</sup> ( **Fig. 4b** ). The treated LEDs 

- 12 exhibit a record-low voltage of 2.8 V at a luminance of 1000 cd m<sup>-2</sup> (1.0 V lower than the 

- 13 previous record perovskite LED<sup>28</sup> ) and require only 3.7 V to produce a luminance of ~ 5000 

- 14 cd m<sup>-2</sup> . Furthermore, our champion LED exhibited its highest EQE (22%) at ~180 cd m<sup>-2</sup> and 

- 15 a maximum luminance of ~7000 cd m<sup>-2</sup> . These LEDs also exhibit reduced efficiency roll-off: 

12 

- 1 the EQE remains ~ 20% at 1000 cd m<sup>-2</sup> ( **Figs. 4c-e** ).  Although the efficiency roll-off is one of 

- 2 the best among red perovskite LEDs, efficiency roll-off remains an issue in perovskite LEDs. 

- 3 We fabricated 18 batches of devices to ensure the EQE and luminance are reliable and 

- 4 repeatable. The resulting LEDs show a stable EL peak with negligible FWHM change after 5 200 min of continuous operation ( **Fig. 4g** ). In contrast, the LEDs using control QDs exhibit 

- 6 inferior EQEs and luminance (EQE of ~12% and a lower maximum luminance of 3000 cd m<sup>-</sup> 7 2); the original QD based LEDs show EQE of 5% with a maximum luminance ~1000 cd m -2 

8 ( **Extended Data Fig. 6** ). This strategy is also applicable to pure-red LEDs emitting in the 9 range of 630 – 640 nm: we achieved a maximum EQE of over 21% and maximum luminance 10 of over 8000 cd m<sup>-2</sup> with emission at 636 nm ( **Extended Data Fig. 7** ). We optimized the 11 cathode/ETL/perovskite interfaces by comparing two ETLs (TPBI and CNT2T), and found 12 the CNT2T based devices had a 0.5 V lower turn-on voltage (2.0 V _vs_ 2.5 V) and 20-fold 13 increased maximum luminance (4500 cd m<sup>-2</sup> _vs_ 200 cd m<sup>-2</sup> ) compared to the TPBI-based 14 devices ( **Extended Data Fig. 8** ). 

15 

16 We then measured LED operating stability by applying a current density of 5 mA cm<sup>-2</sup> , which 17 provided an initial luminance (L0) of 1015 cd m<sup>-2</sup> and monitored the luminance over time. 18 The T-ninety lifetime (T90) – the time by which L0 decreased to 90% of its original luminance 19 – was 500 min ( **Fig. 4h)** . This is 16 times longer than the control (T90 of 30 min) ( **Fig. 4h** ), 20 and is a 100-fold longer lifetime than the best previous report (EQE >20%) at comparable 21 initial luminance ( **Fig. 4i** and **Extended Data Fig. 9** , See **Supplementary Note 2** for the 22 comprehensive lifetime comparison)<sup>1,2,28-37</sup> . To compare our data to other perovskite LED 23 reports, typically tested at ~ 100 cd m<sup>-2</sup> , we measured the stability of our LEDs at different 24 initial luminances. From this we calculated a luminance induced acceleration factor<sup>38-39</sup> , and 25 calculated a T90 at 100 cd m<sup>-2</sup> of 800 h for our LEDs ( **Extended Data Fig. 10** and **Fig. 4i** ). We 26 conducted time-of-flight secondary ion mass spectrometry (ToF-SIMS) depth profiling of 27 control and treated LED devices before and after electrical stress (continuous electrical aging 28 at 1000 cd m<sup>-2</sup> for 30 min) to monitor the ion migration. The control LEDs show broadened 29 Br/I distribution indicating ion migration toward to adjacent hole/electron transporting layer, 

13 

- 1 while the treated LEDs show consistent Br/I distribution without noticeable differences 

- 2 ( **Extended Data Fig. 11** ). Both the improved long-range order and device engineering – 

- 3 PEDOT:PSS replaced by a NiOx/SAM HIL as NiOx/SAM layers have better carrier 

- 4 injection/transportation properties and stability<sup>40</sup> –contributes to the record-high stability. 

- 5 

- 6 **Conclusion** 

- 7 In summary, long-range order QD films were synthesized using a dual-ligand approach that 

- 8 alters the size distribution and arrangement of quantum dots in perovskite QD films. This 

- 9 allowed us to fabricate compact, uniform active layer films with high PLQY and well-tuned 

- 10 electrical transport properties. Red perovskite LEDs made using this perovskite QDs 

- 11 achieved a record-low voltage of 2.8 V for a luminance of 1000 cd m<sup>-2</sup> and high operating 

- 12 stability: T90 of 500 min at 1015 cd m<sup>-2</sup> . This work paves the way for enhanced T90 stability at 

- 13 the practical luminance of real-world applications (cell phones), and should stimulate more 

- 14 efforts focusing on practical luminance and durability, and in turn, drive the perovskite LED 

- 15 industry closer to widespread real-world implementation. 

- 16 

- 17 

### 18 

# **Online content** 

- 19 Any methods, additional references, Nature Research reporting summaries, source data, 20 statements of data availability and associated accession codes are available. 

21 

# 22 **References** 

- 23 1 Wang, K. _et al._ Suppressing phase disproportionation in quasi-2D perovskite light24 emitting diodes. _Nat. Commun._ **14** (2023). 

- 25 2 Jiang, J. _et al._ Red Perovskite Light‐Emitting Diodes with Efficiency Exceeding 25% 26 Realized by Co‐Spacer Cations. _Adv. Mater._ **34** , 2204460 (2022). 

- 27 3 Won, Y. H. _et al._ Highly efficient and stable InP/ZnSe/ZnS quantum dot light-emitting 28 diodes. _Nature_ **575** , 634-638 (2019). 

14 

- 1 4 Wang, Y. K. _et al._ Bifunctional Electron-Transporting Agent for Red Colloidal 2 Quantum Dot Light-Emitting Diodes. _J. Am. Chem. Soc._ **145** , 6428-6433 (2023). 

- 3 5 Jang, E. & Jang, H. Review: Quantum Dot Light-Emitting Diodes. _Chem Rev_ , (2023). 

- 4 6 Han, T. H. _et al._ A roadmap for the commercialization of perovskite light emitters. 5 _Nat. Rev. Mater._ **7** , 757-777 (2022). 

- 6 7 Lu, M. _et al._ Metal Halide Perovskite Light‐Emitting Devices: Promising Technology 7 for Next‐Generation Displays. _Adv. Funct. Mater._ **29** , 1902008 (2019). 

- 8 8 Song, J. et al. Quantum Dot Light-Emitting Diodes Based on Inorganic Perovskite 9 Cesium Lead Halides (CsPbX3). _Adv. Mater._ 27, 7162-7167 (2015). 

- 10 9 Prakasam, V. _et al._ Large area perovskite light-emitting diodes by gas-assisted 11 crystallization. _J. Mater. Chem. C_ **7** , 3795-3801 (2019). 

- 12 10 Ahn, S. _et al._ Fine Control of Perovskite Crystallization and Reducing Luminescence 13 Quenching Using Self‐Doped Polyaniline Hole Injection Layer for Efficient 14 Perovskite Light‐Emitting Diodes. _Adv. Funct. Mater._ **29** , 1807535 (2019). 

- 15 11 Li, X. _et al._ CsPbX3 Quantum Dots for Lighting and Displays: Room-Temperature 16 Synthesis, Photoluminescence Superiorities, Underlying Origins and White Light17 Emitting Diodes. _Adv. Funct. Mater._ **26** , 2435-2445 (2016). 

- 18 12 Kim, Y.-H. _et al._ Comprehensive defect suppression in perovskite nanocrystals for 19 high-efficiency light-emitting diodes. _Nat. Photon._ **15** , 148-155 (2021). 

- 20 13 Chen, W. _et al._ Highly bright and stable single-crystal perovskite light-emitting 21 diodes. _Nat.Photon._ **17** , 401-407 (2023). 

- 22 14 Zhao, L., Lee, K. M., Roh, K., Khan, S. U. Z. & Rand, B. P. Improved Outcoupling 23 Efficiency and Stability of Perovskite Light‐Emitting Diodes using Thin Emitting 24 Layers. _Adv. Mater._ **31** , 1805836 (2019). 

- 25 15 Mu, Y., He, Z., Wang, K., Pi, X. & Zhou, S. Recent progress and future prospects on 26 halide perovskite nanocrystals for optoelectronics and beyond. _iScience_ **25** , 105371 27 (2022). 

- 28 16 Vashishtha, P. & Halpert, J. E. Field-Driven Ion Migration and Color Instability in 29 Red-Emitting Mixed Halide Perovskite Nanocrystal Light-Emitting Diodes. _Chem._ 30 _Mater._ **29** , 5965-5973 (2017). 

15 

- 1 17 Zhao, L. _et al._ Thermal Management Enables Bright and Stable Perovskite Light‐ 2 Emitting Diodes. _Adv. Mater._ **32** , 2000752 (2020). 

- 3 18 Dong, Y. _et al._ Bipolar-shell resurfacing for blue LEDs based on strongly confined 4 perovskite quantum dots. _Nat. Nanotechnol._ **15** , 668-674 (2020). 

- 5 19 Wang, Y. K. _et al._ All-Inorganic Quantum-Dot LEDs Based on a Phase-Stabilized 6 alpha-CsPbI3 Perovskite. _Angew. Chem. Int. Ed._ **60** , 16164-16170 (2021). 

- 7 20 Wang, Y.-K. _et al._ Self-assembled monolayer–based blue perovskite LEDs. _Sci. Adv._ 8 **9** , eadh2140 (2023). 

- 9 21 Zhou, C. _et al._ Quantum Dot Self-Assembly Enables Low-Threshold Lasing. _Adv. Sci._ 

- 10 **8** (2021). 

- 11 22 Peng, C. _et al._ A Demulsification–Crystallization Model for High-Quality Perovskite 12 Nanocrystals. _Ad. Mate._ **35** , 2206969 (2023). 

- 13 23 Jiang, Y. _et al._ Synthesis-on-substrate of quantum dot solids. _Nature_ **612** , 679-684 14 (2022). 

- 15 24 Choi, M. J. _et al._ Cascade surface modification of colloidal quantum dot inks enables 16 efficient bulk homojunction photovoltaics. _Nat. Commun._ **11** , 103 (2020). 

- 17 25 Bian, K. _et al._ Shape-Anisotropy Driven Symmetry Transformations in Nanocrystal 18 Superlattice Polymorphs. _ACS Nano_ **5** , 2815-2823 (2011). 

- 19 26 Tan, W. L. & McNeill, C. R. X-ray diffraction of photovoltaic perovskites: Principles 20 and applications. _App. Phy. Rev._ **9** , 021310 (2022). 

- 21 27 Lee, S. _et al._ Dipole Engineering through the Orientation of Interface Molecules for 22 Efficient InP Quantum Dot Light-Emitting Diodes. _J. Am. Chem. Soc._ **144** , 2092323 20930 (2022). 

- 24 28 Wang, Y. K. _et al._ All‐Inorganic Quantum‐Dot LEDs Based on a Phase‐Stabilized α‐ 25 CsPbI<sub>3</sub> Perovskite. _Angew. Chem. Int. Ed._ **60** , 16164-16170 (2021). 

- 26 29 Zhang, J. _et al._ A Multifunctional “Halide‐Equivalent” Anion Enabling Efficient 27 CsPb(Br/I)3 Nanocrystals Pure‐Red Light‐Emitting Diodes with External Quantum 28 Efficiency Exceeding 23%. _Adv. Mater._ **35** , 2209002 (2023). 

- 29 30 Liu, Z. _et al._ Deep‐Red Perovskite Light‐Emitting Diodes with External Quantum 30 Efficiency Exceeding 21% Enabled by Ligand‐Modulated Dimensionality Control. 

16 

- 1 _Adv. Opt. Mater._ **10** , 2201123 (2022). 

- 2 31 Xie, M. _et al._ High-Efficiency Pure-Red Perovskite Quantum-Dot Light-Emitting 3 Diodes. _Nano Lett._ **22** , 8266-8273 (2022). 

- 4 32 Wang, Y. K. _et al._ In Situ Inorganic Ligand Replenishment Enables Bandgap Stability 5 in Mixed‐Halide Perovskite Quantum Dot Solids. _Adv. Mater._ **34** , 2200854 (2022). 

- 6 33 Chiba, T. _et al._ Anion-exchange red perovskite quantum dots with ammonium iodine 7 salts for highly efficient light-emitting devices. _Nat. Photon._ **12** , 681-687 (2018). 

- 8 34 Zhang, J. _et al._ Ligand‐Induced Cation–π Interactions Enable High‐Efficiency, Bright, 9 and Spectrally Stable Rec. 2020 Pure‐Red Perovskite Light‐Emitting Diodes. _Adv._ 

- 10 _Mater._ **35** (2023). 

- 11 35 Xie, M. _et al._ Suppressing Ion Migration of Mixed‐Halide Perovskite Quantum Dots 12 for High Efficiency Pure‐Red Light‐Emitting Diodes. _Adv. Funct. Mater._ **33** (2023). 

- 13 36 Hassan, Y. _et al._ Ligand-engineered bandgap stability in mixed-halide perovskite 14 LEDs. _Nature_ **591** , 72-77 (2021). 

- 15 37 Ke, Y. _et al._ Efficient and Bright Deep‐Red Light‐Emitting Diodes based on a Lateral 16 0D/3D Perovskite Heterostructure. _Adv. Mater._ , 2207301 (2023). 

- 17 38.      Guo, B. _et al._ Ultrastable near-infrared perovskite light-emitting diodes. _Nat. Photon._ 18 **16** , 637-643 (2022) 

- 19 39.     Liu, Y. et al. Bright and Stable Light-Emitting Diodes Based on Perovskite Quantum 20 Dots in Perovskite Matrix. _J. Am. Chem. Soc._ 143, 15606-15615 (2021). 

- 21 40.     Lee, S. _et al._ Dipole Engineering through the Orientation of Interface Molecules for 22 Efficient InP Quantum Dot Light-Emitting Diodes. _J. Am. Chem. Soc._ **144** , 2092323 20930 (2022). 

- 24 

- 25 

- 26 

- 27 

- 28 

# **Acknowledgements** 

- 29 We acknowledge financial support from the National Natural Science Foundation of China 

17 

- 1 (NSFC) (62205230, 62175171, and 51821002), China Postdoctoral Science Foundation 

- 2 (2021TQ0230, 2021M690114), Suzhou Key Laboratory of Functional Nano & Soft 

- 3 Materials, Collaborative Innovation Center of Suzhou Nano Science & Technology, the 111 

- 4 Project, Joint International Research Laboratory of Carbon-Based Functional Materials and 

- 5 Devices. This project is also funded by the Collaborative Innovation Center of Suzhou Nano 

- 6 Science and Technology (CIC-Nano). The authors acknowledge the Sargent group at the 

- 7 University of Toronto for access to experimental facilities. This publication is based, in part, 

- 8 on work supported by the Natural Sciences and Engineering Research Council of Canada 9 (NSERC). 

10 

### 11 

# **Author contributions** 

12 L.L. supervised the project. L.L. and Y.W. conceived the idea and wrote the manuscript. Y.W. 13 and H.W. prepared the perovskite quantum dots, fabricated LEDs and performed the 14 characterization of LEDs. S.T and L.G. performed GIWAXS and GISAXS measurements. 15 Z.Z. performed the conductivity measurements. M.I measured TEM. S.H. contributed to data 16 analyses and provided instructive suggestions. All authors discussed the results and assisted 17 in the preparation of the manuscript. 

18 

# 19 **Competing interests** 

- 20 The authors declare no conflict of interest. 

21 

### 22 

# **Additional information** 

- 23 **Extended data** is available for this paper. 

- 24 **Reprints and permissions information** is available at http://www.nature.com/reprints. 

- 25 **Correspondence and requests for materials** should be addressed to L.L. 

- 26 **Publisher’s note:** Springer Nature remains neutral with regard to jurisdictional claims in 

- 27 published maps and institutional affiliations. 

28 

18 

1 

# 2 **METHODS** 

- 3 **Materials.** Cesium carbonate (Cs2CO3, Puratronic, 99.994%, metals basis, Alfa Aesar), Lead 4 (II) bromide (PbBr2, 99%, Sigma-Aldrich), Oleylamine (OAm, technical grade 70%, Sigma5 Aldrich), Oleic acid (OA, technical grade 90%, Sigma-Aldrich), 1-Octadecene (ODE, 6 technical grade 90%, Sigma-Aldrich), Methyl acetate (ReagentPlus, 99%, Sigma-Aldrich), 7 Nafion perfluorinated resin solution (tetrafluoroethylene-perfluoro-3,6-dioxa-4-methyl-78 octenesulfonic acid copolymer, 5 wt.% in a mixture of lower aliphatic alcohols and water, 9 containing 45% water) 4-CF3-BA (98%) and lithium fluoride (LiF, >99.99%) were purchased 

- 10 from Sigma-Aldrich. NiOx nanoparticles ((P-21, 0.15 wt %) were purchased from Avantama. 11 All the chemicals were used directly as received. 

12 

13 **Quantum dot synthesis and purification.** CsPbBr3 QDs were synthesized and purified 14 based on a previously reported method with some modifications. In brief, 310 mg Cs 2CO3, 15 1.2 ml oleic acid (OAc), and 5.0 ml 1-octadecene (ODE) were dried in a 3-necked round 16 bottom flask at room temperature for 15 min. In another flask, 600 mg PbBr2 was mixed with 17 5 ml of OAm/OAc mixture and 40 ml of ODE followed by vacuum drying at 120<sup>o</sup> C for 20 18 min. Under N2 atmosphere, the lead halide precursors were kept at reaction temperature (86 19 oC) until all solids were dissolved. Then, 4.0 ml Cs precursor solution was swiftly injected 20 into the flask containing the lead halide precursor. After a chosen reaction time (2 min), the 21 solution was cooled using an ice water bath. The solution was centrifuged at 7800 rpm to 22 remove unreacted precursors. The precipitation was discarded and the supernatant was 23 collected. For the purification process, the supernatant was precipitated by adding 50 ml 24 methyl acetate. Then the mixture was centrifuged to collect the precipitant and dissolved in 25 octane. 

26 

27 **In-situ ligand exchange with synergistic dual ligand strategy.** For the ligand exchange 28 process, 5.0 ml of CsPbBr3 quantum dots were diluted with 4.0 ml toluene in a flask. Then, 29 100 mg of aniline hydroiodide was added to the perovskite quantum dot solution. After ~25 

19 

- 1 min stirring, the mixture was divided into four tubes and 2.5-fold ethyl acetate was added to 

- 2 each tube. After full vortexing, the tubes were centrifuged at 7800 rpm for ~5 min and the 

- 3 precipitate was dissolved in 2.0 ml toluene. Then, 40 μL of TMSBr was added to the solution 

- 4 during vortex for 30 seconds, followed by ~6 ml of ethyl acetate was added to the mixture. 

- 5 After centrifuging, the supernatant was discarded while the precipitate was re-suspended into 

- 6 ~1 ml octane. During the ligand exchange process, it is crucial to carefully control the 7 reaction time within 30 seconds. The antisolvent should be added immediately after the 8 reaction time to halt the reaction and stabilize the spectrum. 9 

10 **PL characterization.** A Horiba Fluorolog system was used for PL characterization. Steady11 state PL was measured with a monochromatized Xe lamp as the excitation source. A Time12 Correlated Single Photon Counting (TCSPC) detector and a pulsed UV laser diode ( _λ_ = 374 13 nm) were used to acquire transient PL. An instrument response function of Δ _t_ =0.13 ns 14 provides a limit to the overall time resolution. Time-resolved emission spectra were recorded 15 by measuring individual transient PL traces at increasing emission wavelengths. PL stability 16 was measured in ambient conditions with a relative humidity of approximately 20%, using 17 the laser diode (Delta Diode 375, peak wavelength 374 nm, 100 MHz) with a peak power of 18 300 mW and average power of 1.8 mW. The spot size was ~0.01 cm<sup>2</sup> , so the calculated 19 excitation density was 180 mW cm<sup>-2</sup> . Absolute PLQY values were obtained by coupling a 20 Quanta-Phi integrating sphere to the Fluorolog system through optical fiber bundles. All the 21 PLQY measurements followed published methods. Both excitation and emission spectra were 22 measured for three cases: the sample directly illuminated by the excitation beam path in the 23 integrating sphere, the sample offset within the integrating sphere from the beam path, and 24 the empty sphere itself. For PLQY measurements, the Fluorolog was set to an excitation 25 wavelength of 380 nm and a 2 nm bandpass for both the excitation and emission slits. By 26 using these settings, the resulting spectra had high signal-to-noise ratios and provided an 27 excitation intensity in a range of 1~30 mW cm<sup>-2</sup> . The detector was calibrated for spectral 28 variance with a Newport white light source. The excitation intensity was varied for intensity- 

- 29 dependent PL spectra by changing the slit width on the Fluorolog monochromator. Excitation 

20 

- 1 intensity was obtained by recording the power <mark>with an Ophir LaserStar Dual Channel Power</mark> 2 <mark>and energy meter and by calculating the beam area through the known dispersion relations for</mark> 3 <mark>the monochromator.</mark> 

- 4 

- 5 **<mark>NMR and XPS measurements:</mark>** 1 <mark>H NMR spectra were measured by utilizing the</mark> 6 <mark>JNMECZ400S/L1 with a frequency of 400 MHz</mark> **.** XPS measurements were performed using a 7 PHI5500 multitechnique system with a base pressure of ~10<sup>−9</sup> torr. The X-ray radiation is Al 8 Kα emission (1,486.7 eV; take-off angle, 75°). 

9 

10 **AFM measurements.** AFM measurement was performed with an Asylum Research Cypher 11 AFM operated in AC mode in air. Imaging was done using ASYELEC-02 silicon probes with 12 titanium-iridium coatings from Asylum Research. The probes had a typical spring constant of 13 42 N m<sup>-1</sup> . Before measuring the thickness, a scratch is made on the film by using a knife. 14 Since the scraped parts will accumulate on the scratch side, a peak will be formed on the 15 cross-section. By performing AFM analysis on the areas on both sides of the scratch, we can 16 obtain the height by comparing the difference between the flat part and the low par 17 ( **Extended Data Fig. 5** ). 

18 

19 **SEM and TEM measurements.** Samples for top-view TEM imaging were prepared above 20 onto a copper TEM grid attached to a glass substrate by using the same spin-coating and 21 annealing method used in LEDs. Samples for top-view TEM imaging were prepared above 22 onto a copper TEM grid attached to a glass substrate by using the same spin-coating and 23 annealing method used in LEDs. Cross-sectional samples for TEM were prepared using a 24 cryo-focused ion beam (FIB, Hitachi NB5000). The accelerating voltage of the ion beam was 25 40 kV, with a gradual decrease in the accelerating voltage to 2 kV as the sample thickness 26 decreased. Cryo-TEM was performed using a Hitachi HF-3300 S/TEM, operated at 300 kV. 

27 

- 28 **Density Functional Theory Calculations** . We used the Vienna Ab initio Simulation Package 29 (VASP)<sup>2</sup> to perform the DFT calculations. The projector augmented wave (PAW) method was 

21 

- 1 used to treat the effective interaction of the core electrons and nucleus with the valence 

- 2 electrons, while exchange and correlation were described using the Perdew-Burke-Ernzerhof 

- 3 (PBE) functional. We used the cutoff energy of 400 eV with the energy and force 

- 4 convergence tolerance of 10<sup>−5</sup> eV and 0.02 eV·Å<sup>−1</sup> , respectively. 

- 5 

- 6 **GIWAXS and GISAXS measurement. GIWAXS and GISAXS** were conducted at the Hard 

- 7 X-ray MicroAnalysis (HXMA) beamline of the Canadian Light Source (CLS). An energy of 8 17.998 keV (λ= 0.6888 Å) was selected using a Si(111) monochromator. Patterns were 9 collected on a SX165 CCD camera (Rayonix) placed at a distance of 175 mm from the 

- 10 sample. A lead beamstop blocked the direct beam. Images were calibrated using LaB6 and 11 processed with the Nika Igor plug-in and the GIXSGUI MATLAB plug-in. 

12 

13 **LED Fabrication.** <mark>LEDs were fabricated on</mark> patterned ITO-coated glass substrates purchased 14 from Thin Film Devices Incorporated. The thickness of the glass substrate is 0.70 ± 0.002 15 mm. The thickness of the ITO layer is 320 ± 25 Å, the resistivity is 100 ± 25 ohms sq<sup>-1</sup> , and 16 the transmittance is > 80% at 475~800 nm. We cleaned the substrates with detergent, 17 deionized water, acetone, and isopropanol in an ultrasonic washer, then treated them with 18 oxygen plasma for 5 min. Then, 50 μL of diluted NiOx nanoparticle dispersions (Avantama, 19 P-21, 0.15 wt %) was filtered through a 0.22 μm polytetrafluoroethylene (PTFE) membrane 20 before use and spun-cast at 3000 rpm for 30 s and annealed at 100 °C for 10 min. Annealed 21 NiOx films were UV-ozone treated for 3 min. NiO x substrates were soaked with SAM 22 solutions (2.5 mg/mL in anhydrous ethanol) for 30 s, and spin-cast at 5000 rpm for 20 s, and 23 then annealed at 100 °C for 5 min (NiOx/SAM thickness of 20 nm). Unbound SAM 24 molecules were washed off with pure anhydrous ethanol spin coating at 5000 rpm for 20 s 25 and annealed at 100 °C for 5 min. All HIL-coated substrates were transferred in the N2-filled 26 glovebox, and then 150 μL of poly-TPD (American Dye Sources Inc., ADS254BE) in 27 chlorobenzene (6 mg/mL) solution was filtered through a 0.22 μm PTFE membrane before 28 use and spun-cast at 2000 rpm for 30 s (Poly-TPD thickness of 30 nm). The films were 29 annealed at 150 °C for 15 min. Perovskite QDs were then spin-coated onto the poly-TPD at 

22 

- 1 2000 rpm for 30 s (perovskite QD thickness of 35 nm). Finally, the substrates were 

- 2 transferred into a high vacuum thermal evaporator, where CNT2T (~50 nm), LiF (~1 nm), 

- 3 and Al (~120 nm) were deposited thereon layer by layer through a shadow mask at a pressure 4 below 10<sup>-8</sup> torr. 

- 5 

- 6 **LED Evaluation.** The devices were encapsulated before the current density and luminance 7 measurements, using an ultraviolet curable resin (exposure under ultraviolet light for 20 s) 8 and covered on the edges between the device and a transparent glass chip. All the devices 9 were tested in ambient conditions. <mark>All devices were tested under ambient conditions. The</mark> 

- 10 <mark>luminance versus voltages and the current density versus voltage characteristics were</mark> 11 <mark>collected using an HP4140B picoammeter. The absolute EL power spectra were collected</mark> 12 <mark>using an integrating sphere and an Ocean Optics USB4000 spectrometer by mounting the</mark> 13 <mark>devices on the wall of the integrating sphere. The EQEs were then calculated through the</mark> 14 <mark>measured absolute EL power spectra and the current density. The devices were mounted on</mark> 15 <mark>the open aperture of the integrating sphere to allow the light emitted from the glass surface to</mark> 16 <mark>be collected, while the emission from the substrate edges was not collected. We have</mark> 17 <mark>reproduced the measurements multiple times and also for several repetitions of the same</mark> 18 <mark>experiment. The lifetime of encapsulated devices was measured in ambient conditions. LEDs</mark> 19 <mark>were driven using a Keithley 2400 source meter at a constant current, and the luminance</mark> 20 <mark>intensity was measured with a QE</mark> _<mark>Pro</mark>_ <mark>calibrated spectrometer (Ocean Optics). The current</mark> 21 <mark>used to drive the LED for stability tests was first determined using an EQE measurement</mark> 22 <mark>system.</mark> The radiance of our spectrometer (QEpro, Ocean Optics) used in our system was 23 calibrated by a radiometric calibrated light source (HL-3P-INT-CAL, Ocean Optics), and to 24 validate our test system, we cross-checked the whole system using a commercial planar 25 OLED (purchased from Lumtec. Corp., T70 > 10,000 h) with a reference system that is 26 separately calibrated in a different lab, the EQE values measured at two different systems 27 gave similar results (average variations < 2%). 

28 

29 

# **Data availability** 

23 

- 1 The data that support the findings of this study are available from the corresponding author 

- 2 upon reasonable request. 

- 3 

- 4 

- 5 

24 

1 



- 2 **Extended Data Fig. 1. a-c,** photoluminance spectra (a), excitation-dependent PLQY (b) and 

- 3 field-effect transistors (c) of original film. **d,** the emission peak dependence on aging time 

- 4 (Inset: initial PL spectra of the original, control and treated perovskite films, and after 50 min. 

- 5 

- 6 

- 7 

8 



25 

- 1 **Extended Data Fig. 2. a,** scheme illustrating the system for the _in-situ_ PL measurement. It 

- 2 consists of 405 nm LED as a light source, optical fibers, a QE-Pro spectrometer (Ocean 

- 3 Optics) and a laptop. **b,** _In-situ_ time-dependent PL spectra of a QD solution during ligand 

- 4 exchange. The red arrow indicates the time the TMSBr was added. **c,** extracted peak positions 

- 5 and FWHM from b. 

- 6 

26 

1 

2 



- 3 **Extended Data Fig. 3.** a **,** XPS analysis showing the control and treated films have a similar 

- 4 composition with Br/I ratio difference < 5%. **b,** FTIR results of original, control and treated 

- 5 films. **c-d,** TEM images of control (c) and treated (d) QDs supporting the claim of long-range 

- 6 order films for the treated CsPbBrxI3-x. 

- 7 

- 8 

27 

1 

9 



2 



- 3 **Extended Data Fig. 4. a,** binding structure of OAc/OAm, AnHI and TMSBr on the surface 

- 4 of the nanocrystals. **b,** electrostatic potential distribution in the AnHI and TMSBr molecules. 

- 5 **c,** calculated binding affinity energy of AnHI and TMSBr, using OAc/OAm ligands as the 

- 6 control. **d, t** he assigned Brag spots to CsPbBr3 with an extended lattice constant due to Iodine 

- 7 incorporation using GIXSGUI. 

8 

10 

11 

28 

1 

2 



- 3 **Extended Data Fig. 5.  a-c,** PL mapping (a), SEM images (b) and AFM images (c) of 4 original, control and treated CsPbBrxI3-x films of original, control and treated CsPbBrxI3-x 5 films. **d,** cross-sectional TEM images show the thickness of each layer (the elemental 6 distribution of Al, Pb and O as reference). **e-f** , AFM images with the thickness measurement 7 details of the control films. **g-h** , AFM images with the thickness measurement details of the 

- 8 treated films 

- 9 

29 

1 



30 

- 1 **Extended Data Fig. 6.** current density-voltage, luminance-voltage, EQE versus luminance 

- 2 curves of original (a) and control (b) LEDs. 

- 3 

31 

1 

2 **Extended Data Fig. 7. a-d,** current density-voltage (a), luminance-voltage (b), EL spectra (c) 



- 3 and EQE versus luminance curve (d) of the pure-red LEDs with EL peak in the range of 630 4 – 640 nm. **e-f** , quantitative statics and standard deviation for batch-to-batch (e) and 

- 5 performance variation within one batch (f). 

6 

32 

1 

2 **Extended Data Fig. 8. Device interface engineering** . **a,** device structure using PEDOT:PSS 

9 

10 11 



- 3 as the HIL and TPBI as the ETL, and the current density-voltage, luminance-voltage, EQE 

- 4 versus luminance curves of the LEDs. **b,** device structure using NiOx/SAM as the HIL and 5 TPBI as the ETL, and the current density-voltage, luminance-voltage, EQE versus luminance 

- 6 curves of the LEDs. **c,** device structure using PEDOT:PSS as the HIL and CNT2T as the 7 ETL, and the current density-voltage, luminance-voltage, EQE versus luminance curves of 8 the LEDs. 

33 

1 

2 



- 3 **Extended Data Fig. 9. a,** device structure and operational stability using PEDOT:PSS. **b,** 

- 4 device structure and operational stability using NiOx/SAM. **c,** original T90 stability obtained 

- 5 from the measured data (the values near the colored square are initial luminance (cd m<sup>-2</sup> )). 

- 6 

- 7 

8 

34 

1 



- 2 **Extended Data Fig. 10. a** , measured stability at luminance of 1100 cd m<sup>-2</sup> , 2200 cd m<sup>-2</sup> , 3150 

- 3 cd m<sup>-2</sup> and 4200 cd m<sup>-2</sup> ; **b** , extrapolated stability derived from (a).; **c-f** , Input voltage change 

- 4 during the operational lifetime measurements. 

35 

1 

2 





- 3 **Extended Data Fig. 11.** TOF-SIMS depth profiles of the control (a-b) and treated (d-e) 

- 4 CsPbBrxI3-x LEDs before (a,d) and after electrical stress  (continuous electrical aging at 1000 

- 5 cd m<sup>-2</sup> for 30 min) (b,e). **c,f,** scheme illustrating the Br/I migration to the adjacent layers in 

- 6 control and the suppressed Br/I ion migration in the treated LEDs. **e,f** EL spectra of original 

- 7 and control LEDs held at a current density of 10 mA cm<sup>-2</sup> for 30 minutes, **g,** EL spectra of 

- 8 treated LEDs held at different current densities. 

- 9 

36 

- 1 **Supplementary Note 1** 

- 2 The original sample is CsPbBrxI3-x QDs with only anion exchange (oleylamine iodide); the 3 control sample is CsPbBrxI3-x QDs with both anion exchange (oleylamine iodide) and surface 4 treatment (AnHI), and the treated samples are the CsPbBrxI3-x QDs with dual-ligand surface 5 treatment (AnHI/TMSBr). 

- 6 

## **Supplementary Note 2** 

7 To ensure a fair T90 comparison with the articles reporting T50 lifetime, we reviewed 8 publications that reported an EQE of >20%, and manually extracted their T90 values from the 9 stability graph (since most of them report the T50 value, there is also a T90 value that can be 10 extracted). Although we focus on the T90 stability at 1000 cd m<sup>-2</sup> and aim to push the practical 11 application of perovskite LEDs, there are, until now, no articles (EQE > 20%) reporting 12 operating lifetime at 1000 cd m<sup>-2</sup> . To provide a fair T90 stability comparison, we converted all 13 stability lifetimes in literature to 100 cd m<sup>-2</sup> using the well-recognized equation of 14 _L_ 0 _n ×T_ 90= _constant_<sup>(n of 1.95 according to</sup><sup>**Extended Data Fig. 10**)1-2, and obtained the</sup> 

- 15 

## **Figure 4i** . 

16 Among the comparison of RGB perovskite LEDs<sup>2-3</sup> , we conclude that 1) stability remains a 17 significant challenge for the further application of perovskite LEDs; 2) Comparing 18 operational stability at a decent and reasonable EQE level is more meaningful (Blue: EQE of 19 > 10%; Green: EQE >20%; Red: EQE >20%), which agrees with practical application 20 requirements and the consensus within perovskite LED community; 3) Our work represents 21 the best stability among red perovskite LEDs with an EQE >20%. 

- 22 

## **Supplementary Note 3** 

23 We observed an EL spectra shift under low current density (~10 mA cm<sup>-2</sup> ) for the original and 24 control LEDs, while the treated one started to display evidence of phase segregation only 25 when the current density reached 90 mA cm<sup>-2</sup> ( **Extended Data Fig.11** ). 

26 

27 

## Reference: 

- 28 1. Guo, B. _et al._ Ultrastable near-infrared perovskite light-emitting diodes. _Nat. Photon._ **16** , 29 637-643 (2022) 

- 30 2. Liu, Y. et al. Bright and Stable Light-Emitting Diodes Based on Perovskite Quantum 31 Dots in Perovskitetrix. _J. Am. Chem. Soc._ 143, 15606-15615 (2021). 

- 32 3. Jiang, Y. et al. Synthesis-on-substrate of quantum dot solids. _Nature_ 612, 679-684 (2022). 

- 33 4. Ma, D. et al. Distribution control enables efficient reduced-dimensional perovskite 34 LEDs. _Nature_ 599, 594-598 (2021). 

37 

