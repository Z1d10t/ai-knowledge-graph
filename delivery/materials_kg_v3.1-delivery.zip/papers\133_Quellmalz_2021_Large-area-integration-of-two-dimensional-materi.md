# Large-area integration of two-dimensional materials and their heterostructures by wafer bonding

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 199 |
| 作者 | A. Quellmalz, Xiao-Jing Wang, S. Sawallich, B. Uzlu, M. Otto, S. Wagner, Zhenxing Wang, M. Prechtl et al. |
| DOI | 10.1038/s41467-021-21136-0 |
| 源文件 | 033_Quellmalz_2021_Large-area-integration-of-two-dimensional-materi.pdf |

---


## ARTICLE 



> https://doi.org/10.1038/s41467-021-21136-0 **OPEN** 

# Large-area integration of two-dimensional materials and their heterostructures by wafer bonding 

Arne Quellmalz 1✉, Xiaojing Wang1, Simon Sawallich 2,3, Burkay Uzlu3,4, Martin Otto 4, Stefan Wagner 4, Zhenxing Wang 4, Maximilian Prechtl 5, Oliver Hartwig 5, Siwei Luo5, Georg S. Duesberg 5, Max C. Lemme 3,4, Kristinn B. Gylfason1, Niclas Roxhed 1, Göran Stemme1 & Frank Niklaus 1✉ 

Integrating two-dimensional (2D) materials into semiconductor manufacturing lines is essential to exploit their material properties in a wide range of application areas. However, current approaches are not compatible with high-volume manufacturing on wafer level. Here, we report a generic methodology for large-area integration of 2D materials by adhesive wafer bonding. Our approach avoids manual handling and uses equipment, processes, and materials that are readily available in large-scale semiconductor manufacturing lines. We demonstrate the transfer of CVD graphene from copper foils (100-mm diameter) and molybdenum disulfide (MoS2) from SiO2/Si chips (centimeter-sized) to silicon wafers (100-mm diameter). Furthermore, we stack graphene with CVD hexagonal boron nitride and MoS2 layers to heterostructures, and fabricate encapsulated field-effect graphene devices, with high carrier mobilities of up to 4520 cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> . Thus, our approach is suited for backend of the line integration of 2D materials on top of integrated circuits, with potential to accelerate progress in electronics, photonics, and sensing. 

> 1 Division of Micro and Nanosystems, School of Electrical Engineering and Computer Science, KTH Royal Institute of Technology, Stockholm, Sweden. 

> 2 Protemics GmbH, Aachen, Germany. 3 Chair of Electronic Devices, Faculty of Electrical Engineering and Information Technology, RWTH Aachen University, Aachen, Germany.<sup>4</sup> AMO GmbH, Advanced Microelectronic Center Aachen (AMICA), Aachen, Germany.<sup>5</sup> Institute of Physics, EIT 2, Faculty of Electrical Engineering and Information Technology, Universität der Bundeswehr München, Neubiberg, Germany.<sup>✉</sup> email: arne.quellmalz@eecs.kth.se; frank.niklaus@eecs.kth.se 

1 

NATURE COMMUNICATIONS | (2021) 12:917 | https://doi.org/10.1038/s41467-021-21136-0 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21136-0 

he astonishing properties of two-dimensional (2D) materials have aroused tremendous interest in the semiTconductor industry. These new types of atomically thin materials promise to continue the trend of shrinking transistors and better sensors. For graphene, an atomically thin layer of carbon atoms, the ultrahigh charge carrier mobility, and its strong light absorption enabled the demonstration of high-frequency analog electronics<sup>1,2</sup> , flexible electronics<sup>3</sup> , high-sensitivity Hall sensors<sup>4,5</sup> , and high-speed photodetectors for telecommunication and imaging technologies<sup>6–8</sup> . Transition metal dichalcogenides are often semiconducting and promise advancements for highand low-power transistors<sup>9</sup> , infrared photodetectors<sup>10</sup> , and emerging device concepts such as memristors<sup>11–13</sup> and singlephoton emitters for optical quantum communication<sup>14–16</sup> . The scaling limit of transistors is set by short-channel effects that arise from intrinsic semiconductor properties. These effects degrade the off-state leakage current and are the limiting factor for silicon transistors with sub-10 nm gate length. On this scale, molybdenum disulfide (MoS2) transistors are expected to achieve more than two orders of magnitude lower leakage current than silicon transistors<sup>17</sup> . Furthermore, the carrier mobility in MoS2 transistors degrades less with decreasing channel thickness than in silicon transistors<sup>18,19</sup> . Hence, 2D semiconductors may be the ultimate channel material for ultra-scaled MOSFETs<sup>20</sup> . Vertical stacking of 2D materials forms van der Waals heterostructures, a novel class of materials with new material properties that result from synergetic effects between the stacked layers at their interfaces<sup>21–26</sup> . Integrating 2D materials into conventional semiconductor fabrication lines is critically important to exploit their material properties in commercial devices while benefitting from established silicon-based infrastructure with low-cost and highvolume device manufacturing on large<sup>20</sup> substrates<sup>20,27</sup> . Yet, there are several bottlenecks that have prevented this last decisive step so far. The synthesis of 2D materials by chemical vapor deposition (CVD) is scalable to large areas, and the best contemporary processes provide close to intrinsic material quality<sup>28–31</sup> . However, the high process temperatures required to obtain high material quality rules out direct growth on preprocessed silicon electronics substrates, and hence mandates a material transfer from dedicated growth substrates to the device substrate. Commonly used wet transfer approaches rely on an intermediate polymeric carrier, typically poly(methyl methacrylate) (PMMA)<sup>32–34</sup> or polycarbonate<sup>35,36</sup> , which mechanically supports the 2D material during its removal from the growth substrate and the transfer to the target substrate by scooping from the surface of a liquid. This process may be implemented at various stages of the device fabrication and allows the placement of the 2D material directly on a target substrate of choice, including complementary metal oxide semiconductor electronic wafers. For graphene, wet transfers degrade the material properties by causing defects, wrinkles, and strain in the transferred layer<sup>37</sup> . In addition, residuals of the polymeric carrier layer remain on the surface of the 2D material and degrade its electronic transport properties<sup>38,39</sup> . Attempts to minimize these adverse effects of wet transfer include bubble delamination<sup>40</sup> , advanced cleaning procedures<sup>41</sup> , and replacing poly(methyl methacrylate) with paraffin as carrier polymer<sup>42</sup> . Nevertheless, they do not eliminate the noted issues entirely. Dry transfer approaches using rollers, laminators, and hot presses enable the reuse of metallic growth substrates and avoid submersion of the target substrate in liquids, which is beneficial, for example, for the integration of 2D materials with suspended devices<sup>33,43–50</sup> . However, dry-transferred layers often suffer from microcracks, wrinkles, reduction in charge carrier mobility, and contamination by residuals from the sacrificial carrier layers. On the micrometer scale, cleaning techniques can mechanically manipulate the 

location of encapsulated contaminants and restore intrinsic material properties<sup>51</sup> . Delamination of single-crystal CVD graphene from copper foil by strong van der Waals forces with a stamp of exfoliated hexagonal boron nitride (hBN) yields almost intrinsic graphene properties, but is limited in size to areas of a few hundred micrometers<sup>30</sup> . Most importantly, neither of the reported transfer methods is compatible with industry routines for large-scale manufacturing while still preserving the high quality of the 2D material as on the growth substrate, which is required for many applications<sup>52</sup> . Here, we present a versatile approach for the transfer and stacking of 2D materials to heterostructures by adhesive bonding with bisbenzocyclobutene (BCB) and commercial wafer bonding equipment. BCB is a hydroxyl-free dielectric material that was developed for the semiconductor industry and is being used as an interlayer dielectric, for heterogeneous system integration, and as an organic gate dielectric layer since it has low fixed-charge and trap densities<sup>53–57</sup> . Our approach avoids manual handling of the 2D material and does not require sacrificial carrier layers that may contaminate the surface of the 2D material. The proposed method only utilizes equipment, processes and materials that are readily available in large-scale semiconductor production lines, which are crucial advantages for the integration into the semiconductor ecosystem<sup>58,59</sup> . We demonstrated the transfer of monolayer graphene from copper foils to 100-mm-diameter silicon wafers, the transfer and stacking of multilayer hBN, and monolayer graphene to form graphene/hBN heterostructures, and the stacking of two graphene layers to form double-layer graphene. We also fabricated field-effect graphene devices to demonstrate the utility of our methodology for wafer-level device manufacturing with conventional semiconductor processes. Furthermore, we demonstrated the transfer of multilayer MoS2, as a representative for transition metal dichalcogenides, from a centimeter-sized silicon chip to a 100-mm-diameter silicon wafer. All transferred layers and heterostructures were of high quality, that is, they featured uniform coverage and little strain in the transferred 2D materials. These findings indicate that our proposed integration approach preserves similar mechanical properties of the 2D materials as present on the growth substrate while minimizing degradation of the transferred layers through the introduction of wrinkles or excessive strain. 

### Results 

Method for transfer of 2D materials and heterostructures. Our method for transferring 2D materials from their growth substrate to a target wafer comprises four consecutive steps (Fig. 1): first, the target wafer is spin-coated with an adhesive layer of thermosetting BCB. A softbake removes solvents and solidifies the adhesive layer (Fig. 1a (1)). Next, the 2D material on its growth substrate is placed on top of the target wafer such that the 2D material is facing the adhesive layer (Fig. 1a (2)). The stack is then loaded in a commercial wafer bonder (Fig. 1a (3)). Inside the tool, heating temporarily decreases the viscosity of the adhesive layer while the bond chuck applies a uniform force to the wafer stack. Thus, the adhesive layer molds against the 2D material and forms a stable bond to the target wafer while replicating the surface topography of the growth substrate without exerting excessive pressure on the 2D material. This characteristic is beneficial, since it minimizes potential damage, wrinkles, or strain in the transferred 2D material. After wafer bonding, the growth substrate is removed (Fig. 1a (4)) by either etching, delamination, or permeation of liquids into the interface between the 2D material and the growth substrate, which leaves the 2D material transferred on the target wafer (Fig. 1a (I)). Since BCB is a thermosetting polymer, heating partially cross-links the polymer chains in the adhesive layer, which form a network with high 

2 

NATURE COMMUNICATIONS | (2021) 12:917 | https://doi.org/10.1038/s41467-021-21136-0 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21136-0 



<!-- Start of picture text -->
a Wafer-level transfer of 2D materials<br>Choice of 2D material on  2D material (I)<br>growth substrate Heat<br>on growth 2D material<br>substrate<br>Bisbenzocyclo- Force on target wafer<br>butene (BCB)<br>Target<br>wafer<br>Bonder<br>(1) Spin-coating of  (2) Placement of  (3) Wafer  chuck (4) Removal of<br>adhesive on target wafer 2D material  bonding growth substrate<br>b Formation of 2D material heterostructures<br>Choice of 2D material on  2D material (II)<br>growth substrate Heat 2D material<br>on growth<br>2D material on substrate heterostructure<br>target wafer Force on target wafer<br>Bonder<br>(1) Reuse target wafer to (2) Placement of (3) Wafer  chuck (4) Removal of<br> form heterostructures 2D material  bonding  growth substrate<br><!-- End of picture text -->

Fig. 1 Schematics illustration of the methodology for wafer-level transfer of two-dimensional (2D) materials and formation of 2D material heterostructures. a Wafer-level transfer of materials. (1) Spin coating and soft baking of thermosetting bisbenzocyclobutene (BCB) as an adhesive layer on the target wafer. (2) Placement of the 2D material on its growth substrate on top of the target wafer, with the 2D material facing the target wafer. (3) Adhesive wafer bonding by applying heat and force to the wafer stack using a commercial semiconductor wafer bonding tool, thereby forming a stable bond between the 2D material on its growth substrate and the target wafer. (4) Removal of the growth substrate. (I) Transferred 2D material on the target wafer. b Formation of 2D material heterostructures. (1) Reusing the target wafer from step (I) without additional treatment. (2) Placement of a second 2D material on its growth substrate on top of the target wafer, with the 2D material facing the previously transferred 2D material. (3) Wafer bonding as in a) step (3). (4) Removing the growth substrate of the second 2D material. (II) Transferred 2D material heterostructure on the target wafer. 

chemical stability. If the degree of cross-linking is kept low, by appropriate choice of bonding temperature and time, the BCB adhesive layer allows repeated molding. Hence, reusing the same target wafer for another transfer assembles heterostructures by vertical stacking of 2D materials—without coating any additional adhesive, simply by reusing the existing adhesive layer below the previously transferred 2D material (Fig. 1b (1–4) and (II)). Thus, van der Waals heterostructures form by repeating the three steps of material placement (Fig. 1b (2)), wafer bonding (Fig. 1b (3)), and removal of the growth substrate (Fig. 1b (4)). We note that in this process neither the interface between the first and second 2D material nor the surface of the second 2D material is exposed to any polymer carrier or adhesive that may potentially degrade the 2D material properties by contamination. Partially cross-linked BCB is chemically stable and sustains conventional wafer processing. This feature enables not only structuring of the 2D material to devices after the transfer (using the wafers (I) and (II) in Fig. 1a, b, respectively), but also the integration of metal contacts on top of the BCB layer before transfer (Supplementary Fig. 1). These contacts could be used to interface integrated circuits (ICs) that may be embedded on the target wafer. Moreover, membranes of 2D materials can be suspended over cavities, which were etched into the adhesive layer before transfer (Supplementary Fig. 2). In both cases, the 2D material in the contact and membrane area is not in contact with the adhesive at any time (see Supplementary Notes 1 and 2 for demonstration). 

Wafer-level transfer of graphene/hBN heterostructures. To demonstrate the viability of our methodology for wafer-level transfer of 2D materials and formation of large-area van der Waals heterostructures, we integrated graphene/hBN heterostructures (see “Methods” for details of the process and materials). We characterized the transferred layers using van der Pauw (vdP) devices, noncontact terahertz (THz) near-field spectroscopy, and Raman spectroscopy (Fig. 2). In short, consecutive transfers of multilayer hBN from copper foil and monolayer graphene from copper foil, both synthesized by CVD, formed a graphene/hBN heterostructure on a 100-mm-diameter silicon wafer. First, we attached the hBN on copper foil (2.5 cm × 2.5 cm) to the adhesive on the spin-coated target wafer by wafer bonding. After etching away the copper in FeCl3 solution and rinsing in deionized water, we placed the monolayer graphene on a copper foil (100 mm diameter) on top of the target wafer and performed a second bonding process in a vacuum atmosphere. Finally, etching in FeCl3 uncovered the transferred layers. Due to the difference in the size of the growth substrates, the graphene/hBN heterostructure in the center of the wafer is surrounded by a monolayer of graphene on BCB. Note that in the heterostructure, neither the graphene nor the top surface of the hBN was in contact with polymers or adhesives at any time. Moreover, the second transfer was performed in a vacuum and at elevated temperature, which reduces the amount of water and gas molecules that may get trapped between the layers. Residuals of copper 

3 

NATURE COMMUNICATIONS | (2021) 12:917 | https://doi.org/10.1038/s41467-021-21136-0 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21136-0 



<!-- Start of picture text -->
a Graphene/hBN  van-der-Pauw devices b Sheet resistance Carrier density Mobility<br>heterostructure covered<br>630 ± 90 Ω/sq. (3.7 ± 0.7) ⋅10 12   cm -2 2800 ± 100 cm 2  V -1  s -1<br>Graphene 1 mm 50 600 ± 90 Ω/sq. (4.9 ± 0.2) ⋅10 12   cm -2 2000 ± 200 cm 2  V -1  s -1<br>covered<br>40<br>Graphene (N = 18)<br>30 Graphene/hBN (N = 9)<br>20<br>BCB<br>Si 10<br>BCB 400 600 800 1 2 3 4 5 6 7 1000 2000 3000 4000<br>1 cm Si R sh (Ω/sq.) n (cm -2 ) ×10 12 μ (cm 2  V -1  s -1 )<br>c R sh (Ω/sq.) 60 d 2700 Γ 2D (cm -1 )<br>Graphene<br>800 2695 50<br>Graphene/hBN<br>700 Graphene/hBN  50 2690 45<br>heterostructure 2685<br>600 40 40<br>2680<br>500 35<br>30 2675 Intrinsic<br>400 30<br>2670 point<br>300 20 25<br>2665<br>200 Sites of Raman  2660 20<br>spectroscopy 10<br>100 2655 Γ 2D, gr = 28.8 cm -1  ± 3.6 cm -1 15<br>Reference area Γ 2D, gr/hBN = 27.3 cm -1  ± 3.8 cm -1<br>0 2650 10<br>300 500 700 1575 1580 1585 1590 1595 1600 1605<br>1 cm<br>R sh (Ω/sq.) G peak position  ω G (cm -1 )<br>p doping<br>Compressive<br>strain<br>Tensile<br>strain<br>Frequency (%)<br>Graphene/hBN<br>Graphene<br>Graphene  Graphene/hBN<br>Frequency (%)<br>-12D peak position )(cm ω 2D<br><!-- End of picture text -->

Fig. 2 Characterization of transferred CVD graphene and graphene/hexagonal boron nitride (hBN) heterostructures. a Photograph of a 100-mmdiameter silicon wafer with van der Pauw (vdP) devices. The graphene sheet covers the entire wafer and lies on top of multilayer CVD hBN in the marked region. b Extracted sheet resistance (Rsh), carrier density (n), and charge carrier mobility (μ) from Hall measurements of vdP devices at room temperature (number of devices: 18 graphene (blue); 9 graphene/hBN (red)). c Spatially resolved map of Rsh extracted from noncontact terahertz near-field spectroscopy, indicating a uniform coverage of graphene on the entire high resistive silicon wafer (average within the marked region: 450 ± 50 Ω sq<sup>�1</sup> ). d Correlation map of the Raman G and 2D peak position (ωG and ω2D, respectively) of the transferred graphene (triangles) and the graphene/hBN heterostructure (circles). The colormap represents the extracted full-width at half-maximum of the 2D peak (Γ2D) of the transferred graphene (Γ2D,gr) and the graphene/hBN heterostructure (Γ2D,gr/hBN). The open circle indicates the peak positions of intrinsic graphene<sup>74</sup> . The total number of spectra for graphene on bisbenzocyclobutene (BCB) and graphene on hBN is 430 and 124, respectively. Note, a, b are from the same sample, whereas c, d are performed on a second sample. 

and the copper etchant are still potential contaminants at the interlayer interface, which potentially can affect the properties of the heterostructure<sup>60</sup> . Next, we integrated Ti/Au electrodes and patterned the 2D material heterostructure to vdP devices, which allow electrical material characterization on the target wafer (Fig. 2a). Four-point probe measurements of a total of 27 vdP devices yielded the graphene sheet resistance (Rsh), carrier density (n), and mobility of majority charge carrier (μ) of the transferred graphene layer, both for graphene resting on BCB and for graphene resting on hBN (Fig. 2b) (see “Methods”). In both cases, all measured devices were functioning and we found a similar Rsh (630 ± 90 and 600 ± 90 Ω sq<sup>−1</sup> , respectively), whereas the n and μ showed differences for graphene resting on BCB and on hBN, respectively. The carrier density in the graphene on BCB was lower than for graphene on hBN (ð3:7 ± 0:7Þ ´ 10<sup>12</sup> and ð4:9 ± 0:2Þ ´ 10<sup>12</sup> cm<sup>�2</sup> ), while the mobility was higher for graphene on BCB than for the graphene on hBN (2800 ± 100 and 2000 ± 200 cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> ). For the transferred graphene monolayer resting on BCB, the extracted mobilities are in the higher range of previously reported values for polycrystalline CVD graphene transferred on large areas from polycrystalline copper substrates by various methods, including wet transfer with polymeric carrier 

layers<sup>42,61</sup> , face-to-face transfer by bubble formation<sup>62</sup> and lamination<sup>50</sup> . The mobility in our graphene/hBN heterostructure is similar to values reported by Pandey et al.<sup>63</sup> and Shautsova et al.<sup>64</sup> , who encapsulated graphene in CVD hBN using wet and dry transfers. In accordance with these works, our results indicate that current large-area CVD hBN substrates typically do not increase the mobility in polycrystalline graphene, thus contrasting several studies on single crystals of graphene and hBN<sup>29,30,65,66</sup> . We emphasize that for a meaningful comparison, the initial graphene quality before the transfer is of crucial importance. Our measurements suggest slightly lower mobility in the graphene/ hBN heterostructure than for graphene on BCB. Since we performed the measurements on the same wafer containing graphene from the same growth substrate, which was exposed to the same fabrication processes, we conclude that the substrate below the graphene (hBN and BCB, respectively) is mainly responsible for the discrepancy in material characteristics. For our materials, the microscopic surface roughness of hBN on Cu foil is ~50% higher than for graphene on Cu foil (root mean square (RMS): 264 and 176 nm, respectively, see Supplementary Fig. 3). This difference might cause local strain variations in the covering graphene layer, which reduces charge carrier mobility<sup>67</sup> . In 

4 

NATURE COMMUNICATIONS | (2021) 12:917 | https://doi.org/10.1038/s41467-021-21136-0 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21136-0 

addition, large topography of the transferred materials may potentially cause problems for very high-resolution lithography. Using growth substrates with lower surface topography may mitigate this issue<sup>68–70</sup> . 

We used terahertz time-domain spectroscopy (THz-TDS) to further characterize the electrical properties and homogeneity of the wafer-level transferred graphene and large-area graphene/ hBN heterostructure. The THz-TDS measurements are recorded in transmission mode using a photoconductive near-field detector<sup>71,72</sup> (see “Methods”), which records the amplitude and phase information of a THz signal traveling through the sample. Scanning across the sample surface yields spatially resolved images of the graphene sheet resistance on wafer scale. For our measurements, we set the spatial resolution to 500 µm by adjusting the distance of the near-field detector to the sample and the pitch between acquisition sites. The spatial resolution is significantly larger than the intrinsic length scale that is probed by the THz-TDS. This transport length is estimated by the distance lD, which a charge carrier transverses during one cycle of the alternating THz field<sup>73</sup> . For our sample and setup, we estimate lD � 60 � 100 nm (see Supplementary information for calculation). The map of the graphene sheet resistance on a 100-mmdiameter wafer after transfer and formation of the graphene/hBN heterostructure indicates a uniform coverage and successful transfer on the entire wafer (Fig. 2c). The sheet resistance in the marked region averages to 450 ± 50 Ω sq<sup>�1</sup> , and is similar for both underlying materials (450 ± 20 and 440 ± 20 Ω sq<sup>�1</sup> for BCB and hBN, respectively), which is in line with the measurements of the vdP devices shown in Fig. 2b. These values are similar to the values reported for polycrystalline graphene that was transferred from polycrystalline copper substrates using various methods<sup>42,50,63</sup> . Rahimi et al.<sup>61</sup> reported a higher mean value of 2600 Ω sq<sup>�1</sup> , which originated from lower residual doping. Note that the THz near-field measurement in Fig. 2c was performed on a different sample with high-resistivity Si than the vdP measurements in Fig. 2a, b to avoid absorption of the THz signal by the substrate. At the lateral transition between the graphene/ hBN heterostructure and the monolayer graphene (i.e., the outer edges of the heterostructure), the graphene sheet resistance is increased and less uniform. This variation was most likely caused by surface inhomogeneities in the BCB layer that resulted from a partly detached edge region of the hBN on copper foil in the first transfer. This effect is known to occur in wafer bonding of compliant substrates where the contact area of the wafer chuck is smaller than the substrate. Precise adjustment of the contact area between the wafer bonder and the donor substrate to the size of the copper foil should improve the lateral interface between regions with different layer stacks. 

We performed Raman measurements to extract detailed information about the local graphene quality, including the relationship between doping and nanometer-scale strain variations, by analyzing the positions of the Raman G (ωG) and 2D (ω2D) peaks and the full-width at half-maximum of the 2D peak (Γ2D)<sup>74–76</sup> . In particular, stress variations are of interest since they limit the charge carrier mobility in high-quality graphene, a crucial parameter for high-performance graphene devices<sup>67</sup> . In Fig. 2d, we plot the correlation map of ωG and ω2D for the acquired Raman spectra of the transferred graphene placed on BCB (triangles) and on hBN (filled circles), respectively. The location of the acquisition sites on the wafer is marked in Fig. 2c. The single open circle represents the G and 2D peak positions of intrinsic graphene, which is neither doped nor strained (ωG ¼ 1582 cm<sup>�1</sup> , ω2D ¼ 2670 cm<sup>�1</sup> )<sup>74</sup> . Hole doping of graphene shifts ωG and ω2D with a relative slope of 0.7 (dashed line), while strain results in a relative shift with a slope of 2.2 (solid line)<sup>75</sup> . For both substrate 

materials on our sample, the peak locations indicate slightly tensile strain and predominant hole doping. For graphene on BCB, the charge carrier doping is more pronounced than for graphene on hBN, while the peak locations are less scattered and more confined within a smaller area. Our observation of hole doping and reduced doping level of the graphene when placed on hBN compared to placement on polymeric substrate materials agrees with literature<sup>77</sup> . However, multilayer hBN grown by CVD does not have the same strong effect as exfoliated hBN, which restores almost intrinsic conditions<sup>77</sup> . The color scale of the data points in Fig. 2d represents Γ2D and averages to 28:8 ± 3:6 cm<sup>�1</sup> for graphene on BCB and 27:3 ± 3:8 cm<sup>�1</sup> for graphene on hBN. Both values indicate the decent quality of the graphene with little strain variations within the spot of the Raman excitation laser. 

Stacking of graphene layers by repeated transfer. The recent discovery of specific twist angles between two graphene layers that give rise to astonishing properties such as unconventional superconductivity, correlated insulation, and magnetism<sup>24–26</sup> has spurred great interest in new methods for well-controlled fabrication of double-layer graphene. Furthermore, the stacking of two or multiple layers of 2D materials is of interest for controlling the stiffness of nanoelectromechanical devices<sup>78,79</sup> . 

We performed two consecutive transfers of monolayer (1-layer) graphene from their copper growth substrates to a 100-mmdiameter silicon wafer to demonstrate that our transfer methodology is suitable for high-yield formation of double-layer (2-layer) graphene on large areas (we avoid the term bilayer graphene to distinguish these films from Bernal stacked materials, see “Methods” for process details). First, we transferred CVD graphene from a quarter of a 100-mm copper foil to the center of the target wafer with BCB. For the second transfer, we used a full 100-mm copper foil with CVD graphene. To provide a reference for THz spectroscopy, we removed the graphene on parts of the growth substrate before transfer (left side of the wafer in Fig. 3a). The spatially resolved map of the sheet resistance (Rsh) in Fig. 3c reveals a uniform coverage of graphene on the wafer without major defects. Decreased Rsh in the center clearly distinguishes 1- and 2-layer graphene on the target wafer and confirms the presence of doublelayer graphene. We attribute the difference in the 1-layer graphene Rsh between these experiments and the dataset presented in Fig. 2 to a dissimilarity in graphene quality before transfer. The graphene sheet in Fig. 3a that forms the 1-layer region on the target wafer was from a different batch than the graphene sheet used in Fig. 2. To characterize the 1- and 2-layer graphene on the silicon wafer, we extracted the position of the G and 2D peaks from Raman measurements and plotted the correlation map of ωG and ω2D (Fig. 3b). In both regions, the peak positions were clustered with little spread. The measurements indicate hole doping in the graphene, which is consistent with our measurements on graphene/hBN heterostructures in Fig. 2d. We found that the 1-layer graphene (triangles) experienced tensile strain, while the 2-layer graphene (circles) was strained compressively. However, the peak location for 2-layer graphene might also be influenced by weak interactions between the stacked layers. The full-width at halfmaximum of the 2D peak (Γ2D) (coloration of data points) is similar in both regions and averages to Γ2D; 1�layer ¼ 33:5 ± 4:6 cm<sup>�1</sup> and Γ2D; 2�layer ¼ 32:3 ± 4:9 cm<sup>�1</sup> , suggesting minor variations in strain and comparably few defects, hinting at potentially high charge carrier mobility. 

Field-effect graphene devices. We fabricated and evaluated topgated field-effect devices on 100-mm-diameter silicon wafers using four photolithography layers and conventional processing 

5 

NATURE COMMUNICATIONS | (2021) 12:917 | https://doi.org/10.1038/s41467-021-21136-0 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21136-0 



<!-- Start of picture text -->
a No graphene b 2700 Γ 2D (cm -1 )<br>1-layer graphene<br>BCB 2695 50<br>Si 2-layer graphene<br>2690 45<br>1-layer graphene 2685 40<br>2-layer graphene BCB 2680<br>Si 35<br>2675 Intrinsic<br>2-layer graphene 30<br>(randomly stacked) 2670 point<br>25<br>2665<br>BCB 20<br>2660<br>1 cm Si Γ 2D, 1-layer = 33.5 cm -1  ± 5.6 cm -1<br>2655 Γ 2D, 2-layer = 32.3 cm -1  ± 4.9 cm -1 15<br>Sites of Raman spectroscopy<br>2650 10<br>1575 1580 1585 1590 1595 1600 1605<br>G peak position  ω G (cm -1 )<br>c R sh (Ω/sq.) 1-layer graphene  2-layer region 20 d 2.4 μ max = 2630 cm 2  V -1  s -1 3000 1 2 3<br>1500 780 ± 60 Ω/sq.<br>16 2.0<br>Gate 4<br>2000<br>1.6<br>1000 12 30<br>1-layer region<br>2600 ± 1300 cm 2  V -1  s -1<br>1170 ± 120 Ω/sq.<br>1.2 N = 16<br>8 20<br>1000<br>500 0.8<br>4 10<br>1 cm 0.4<br>0<br>400 800 1200 1600 -4 0 4 1000 3000 5000<br>Sheet resistance   R sh (Ω/sq.) Gate voltage (V) Max mobility (cm 2  V -1  s -1 )<br>Fig. 3 Characterization of double-layer (2-layer) graphene formed by two consecutive transfers of monolayer (1-layer) CVD graphene and wafer-level<br>integration of top-gated field-effecteld-effect graphene devices. a Photograph of a high resistive silicon wafer with 100-mm diameter after graphene transfer.<br>Dashed lines indicate regions of single-layer, double-layer, and no graphene (only bisbenzocyclobutene (BCB)). b Correlation map of Raman G and 2D peak b Correlation map of Raman G and 2D peak Correlation map of Raman G and 2D peak<br>positions (ωG and ω2D, respectively), extracted from measurements in regions of 1-layer graphene (triangles) and 2-layer graphene (circles). The colormapωG and ω2D, respectively), extracted from measurements in regions of 1-layer graphene (triangles) and 2-layer graphene (circles). The colormapG and ω2D, respectively), extracted from measurements in regions of 1-layer graphene (triangles) and 2-layer graphene (circles). The colormap and ω2D, respectively), extracted from measurements in regions of 1-layer graphene (triangles) and 2-layer graphene (circles). The colormap ω2D, respectively), extracted from measurements in regions of 1-layer graphene (triangles) and 2-layer graphene (circles). The colormap2D, respectively), extracted from measurements in regions of 1-layer graphene (triangles) and 2-layer graphene (circles). The colormap, respectively), extracted from measurements in regions of 1-layer graphene (triangles) and 2-layer graphene (circles). The colormap<br>represents the full-width at half-maximum of the 2D peak (Γ2D)Γ2D)2D)) of single-layer graphene (Γ2D,1-layer)Γ2D,1-layer)2D,1-layer)) and double-layer graphene (Γ2D,2-layer).Γ2D,2-layer).2D,2-layer).). c Spatially<br>resolved map of the graphene sheet resistance (Rsh) from noncontact terahertz near-field spectroscopy (left), clearly showing decreased Rsh in the 2-layerRsh) from noncontact terahertz near-field spectroscopy (left), clearly showing decreased Rsh in the 2-layersh) from noncontact terahertz near-field spectroscopy (left), clearly showing decreased Rsh in the 2-layer) from noncontact terahertz near-field spectroscopy (left), clearly showing decreased Rsh in the 2-layerfield spectroscopy (left), clearly showing decreased Rsh in the 2-layereld spectroscopy (left), clearly showing decreased Rsh in the 2-layer Rsh in the 2-layersh in the 2-layer in the 2-layer<br>graphene region. The histogram (right) represents the data inside the dashed rectangle (blue: 1-layer region; red: 2-layer region). d Top-gate voltage<br>dependency of the graphene sheet resistance and the field-effect mobility in an integrated graphene device at room temperature (left) and histogram of the field-effect mobility in an integrated graphene device at room temperature (left) and histogram of theeld-effect mobility in an integrated graphene device at room temperature (left) and histogram of the<br>maximum filed-effectled-effect mobility (μmax)μmax)max)) of 16 devices at room temperature (bottom right). Optical microscope picture of a fabricated field-effecteld-effect graphene<br>(top right). The dashed line marks the graphene area. Electrodes 1 to 4 are used for electrical characterization by a 4-point probe van der Pauw<br>method, while the gate voltage tuned the doping of the graphene. Scale bar: 100 µm. µm.m.<br>technology (Fig. 3d,d, details see “Methods”).Methods”).”).). The extracted sheet such as quartz. The mobilities of the field-effect graphene devices<br>resistance and charge carrier mobility as a function of the gate on BCB were comparable to the mobilities of the vdP devices<br>voltage of a typical device (Fig. 3d,d, left) show the expected char- shown in Fig. 2b, which were solely fabricated by noncontact<br>acteristic behavior of gated graphene devices 80 (see “Methods” for “Methods” forMethods” for” for for processes to avoid potential material damage during device fab-<br>measurement details), where the mobility is zero at the Dirac point rication. This similarity suggests that the quality of the transferred<br>to a zero of the transconductance. At this point, the charge graphene is preserved during device manufacturing with multiple<br>carriers convert from electrons to holes or vice versa. In our processing steps such as high-temperature Al2O3 deposition,<br>measurements, the mobility is not exactly zero because of the multiple lithographic layers, metal depositions, and etching pro-<br>limited number of data points. The maximum field-effect mobility field-effect mobilityeld-effect mobility cesses. Consequently, these results suggest that our transfer<br>of holes from 16 devices averages to 2600 ± 1300 cm 2 V �11 s �11 with methodology is compatible with large-scale manufacturing of<br>values up to 4520 cm 2 V �11 s �11 . The mobilities are in the same graphene devices using conventional semiconductor process<br>as for identical reference devices with the same type of technologies.<br>graphene that were fabricated on top of both BCB and quartz<br>substrates (2800 ± 900 and 1700 ± 700 cm 2 V �11 s �11 , respectively) Transfer of MoS2 and MoS2/graphene heterostructures. Our<br>using conventional wet transfer (see Supplementary information). proposed transfer methodology is generic and applicable to a<br>These results indicate that (1) the graphene transfer by adhesive broad spectrum of 2D materials available on various types of<br>bonding using BCB yields similar finalnal graphene quality as growth substrates. We demonstrated this versatility by transfer-<br>conventional wet transfer and that (2) BCB as substrate material ring a multilayer of CVD MoS2 from a SiO2/Si growth substrate<br>yields similar graphene properties as common dielectric substrates to a 100-mm-diameter silicon wafer (see “Methods” for<br>p doping<br>No graphene<br>(reference) 1-layer graphene<br>2-layer graphene<br>Compressive<br>strain<br>Tensile<br>strain<br>-12D peak position )(cm ω 2D<br>Frequency (%) (k/sq.)Ω R sh  -1 -12(cm V)s μ<br>Frequency (%)<br><!-- End of picture text -->

Fig. 3 Characterization of double-layer (2-layer) graphene formed by two consecutive transfers of monolayer (1-layer) CVD graphene and wafer-level integration of top-gated field-effecteld-effect graphene devices. a Photograph of a high resistive silicon wafer with 100-mm diameter after graphene transfer. Dashed lines indicate regions of single-layer, double-layer, and no graphene (only bisbenzocyclobutene (BCB)). b Correlation map of Raman G and 2D peak b Correlation map of Raman G and 2D peak Correlation map of Raman G and 2D peak positions (ωG and ω2D, respectively), extracted from measurements in regions of 1-layer graphene (triangles) and 2-layer graphene (circles). The colormapωG and ω2D, respectively), extracted from measurements in regions of 1-layer graphene (triangles) and 2-layer graphene (circles). The colormapG and ω2D, respectively), extracted from measurements in regions of 1-layer graphene (triangles) and 2-layer graphene (circles). The colormap and ω2D, respectively), extracted from measurements in regions of 1-layer graphene (triangles) and 2-layer graphene (circles). The colormap ω2D, respectively), extracted from measurements in regions of 1-layer graphene (triangles) and 2-layer graphene (circles). The colormap2D, respectively), extracted from measurements in regions of 1-layer graphene (triangles) and 2-layer graphene (circles). The colormap, respectively), extracted from measurements in regions of 1-layer graphene (triangles) and 2-layer graphene (circles). The colormap represents the full-width at half-maximum of the 2D peak (Γ2D)Γ2D)2D)) of single-layer graphene (Γ2D,1-layer)Γ2D,1-layer)2D,1-layer)) and double-layer graphene (Γ2D,2-layer).Γ2D,2-layer).2D,2-layer).). c Spatially resolved map of the graphene sheet resistance (Rsh) from noncontact terahertz near-field spectroscopy (left), clearly showing decreased Rsh in the 2-layerRsh) from noncontact terahertz near-field spectroscopy (left), clearly showing decreased Rsh in the 2-layersh) from noncontact terahertz near-field spectroscopy (left), clearly showing decreased Rsh in the 2-layer) from noncontact terahertz near-field spectroscopy (left), clearly showing decreased Rsh in the 2-layerfield spectroscopy (left), clearly showing decreased Rsh in the 2-layereld spectroscopy (left), clearly showing decreased Rsh in the 2-layer Rsh in the 2-layersh in the 2-layer in the 2-layer graphene region. The histogram (right) represents the data inside the dashed rectangle (blue: 1-layer region; red: 2-layer region). d Top-gate voltage dependency of the graphene sheet resistance and the field-effect mobility in an integrated graphene device at room temperature (left) and histogram of the field-effect mobility in an integrated graphene device at room temperature (left) and histogram of theeld-effect mobility in an integrated graphene device at room temperature (left) and histogram of the maximum filed-effectled-effect mobility (μmax)μmax)max)) of 16 devices at room temperature (bottom right). Optical microscope picture of a fabricated field-effecteld-effect graphene device (top right). The dashed line marks the graphene area. Electrodes 1 to 4 are used for electrical characterization by a 4-point probe van der Pauw method, while the gate voltage tuned the doping of the graphene. Scale bar: 100 µm. µm.m. 

technology (Fig. 3d,d, details see “Methods”).Methods”).”).). The extracted sheet resistance and charge carrier mobility as a function of the gate voltage of a typical device (Fig. 3d,d, left) show the expected characteristic behavior of gated graphene devices<sup>80</sup> (see “Methods” for “Methods” forMethods” for” for for measurement details), where the mobility is zero at the Dirac point due to a zero of the transconductance. At this point, the charge carriers convert from electrons to holes or vice versa. In our measurements, the mobility is not exactly zero because of the limited number of data points. The maximum field-effect mobility field-effect mobilityeld-effect mobility of holes from 16 devices averages to 2600 ± 1300 cm<sup>2</sup> V<sup>�11</sup> s<sup>�11</sup> with values up to 4520 cm<sup>2</sup> V<sup>�11</sup> s<sup>�11</sup> . The mobilities are in the same range as for identical reference devices with the same type of graphene that were fabricated on top of both BCB and quartz substrates (2800 ± 900 and 1700 ± 700 cm<sup>2</sup> V<sup>�11</sup> s<sup>�11</sup> , respectively) using conventional wet transfer (see Supplementary information). These results indicate that (1) the graphene transfer by adhesive wafer bonding using BCB yields similar finalnal graphene quality as conventional wet transfer and that (2) BCB as substrate material yields similar graphene properties as common dielectric substrates 

6 

NATURE COMMUNICATIONS | (2021) 12:917 | https://doi.org/10.1038/s41467-021-21136-0 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21136-0 



<!-- Start of picture text -->
a 2 mm b<br>E 1 2g A1g Transferred A On growth<br>384.6 cm -1 409.0 cm -1 1.834 eV substrate<br>B<br>1.968 eV<br>On growth<br>Transferred substrate<br>BCB SiO2<br>Si Si<br>Raman modes<br>of BCB<br>1.95 1.96 1.97 1.98<br>Energy (eV)<br>360 380 400 420 440 1.70 1.75 1.80 1.85 1.90 1.95 2.00 2.05<br>Raman shift (cm -1 ) Energy (eV)<br>c R sh (kΩ/sq.) 9 d 30 2681.9 ± 1.8 cm -1 25 385.16 ± 0.35 cmE 1 2g -1 408.06 ± 0.28 cmA1g -1<br>3 20<br>15<br>7<br>10<br>5<br>2<br>5 2674 2682 2690 384 385 386 407 408 409<br>2D peak position  ω 2D (cm -1 ) Peak position (cm -1 )<br>30.3 ± 3.9 cm -1 Raman modes<br>3 A of BCB<br>1 15<br>2 mm<br>1 5 B<br>0<br>0 1 2 3 20 25 30 35 40 1.7 1.8 1.9 2.0<br>Sheet resistance   R sh (kΩ/sq.) Γ 2D, MoS2/gr (cm -1 ) Energy (eV)<br>BCB BCB<br>Si Si<br>Graphene<br>MoS2/graphene<br>Intensity (arb. units)<br>Normalized PL intensity (arb. units)<br>Frequency Frequency<br>/grapheneMoS21030 ± 520 Ω/sq. Graphene 1910 ± 280 Ω/sq.<br>Frequency (%)<br>Frequency PL intensity (arb. units)<br><!-- End of picture text -->

Fig. 4 Transfer and characterization of molybdenum disulfide (MoS2) and MoS2/graphene heterostructures. a Averaged Raman spectra of multilayer MoS2 on the SiO2/Si growth substrate before transfer (blue) and after transfer to the target wafer (red). The Raman spectra are averages of area scans with 8 × 10 measurements in 1 mm<sup>2</sup> areas (black rectangle in the photograph of transferred MoS2) and were normalized to the intensity of the E<sup>1</sup> 2g mode. The shaded regions represent the standard deviation of the intensity. The vertical dashed lines indicate the peak positions of the E<sup>1</sup> 2g and A1g modes of the as-grown film before transfer. b Averages of 25 photoluminescence (PL) intensity spectra of pristine (blue) and transferred (red) multilayer MoS2 with A and B excitonic transitions (shaded areas: standard deviation). The inset magnifies the region from 1.945 to 1.98 eV and shows the Raman modes of bisbenzocyclobutene (BCB), which are superimposed with the optical response of the MoS2 layer. c Spatially resolved map (left) and histogram (right) of the graphene sheet resistance (Rsh) from terahertz near-field spectroscopy (resolution: 300 μm). The MoS2/graphene heterostructure in the center (rectangular region) is surrounded by graphene, both resting on BCB. d Raman and PL spectroscopy of the MoS2/graphene heterostructure, measured in a 1 × 1 mm<sup>2</sup> region on the same sample as in panel (c) (white rectangle). The Raman peak positions indicate the presence of both MoS2 (E<sup>1</sup> 2g and A1g peaks) and graphene (2D peak position (ω2D) and the respective full-width at half-maximum (Γ2D;MoS2=gr). The averaged PL spectrum (bottom right) shows the A and B excitonic transitions of MoS2 and the superimposed Raman modes of BCB (shaded area: standard deviation). 

parameters of film growth and transfer). First, we bonded the centimeter-sized MoS2/SiO2/Si substrate to a BCB-coated 100mm-diameter target wafer. Next, we submerged the bonded stack in a potassium hydroxide (KOH) solution, which permeated into the MoS2/SiO2 interface and detached the MoS2 from its growth substrate. This process took tens of seconds, after which the MoS2 remained transferred on top of the BCB layer of the target wafer. The surface roughness of the transferred MoS2 (RMS: 1.9 nm; measurement area: 25 µm × 25 µm) remained low compared to the original surface roughness of the MoS2 on the growth substrate (RMS: 0.8 nm; measurement area: 5 µm × 5 µm). Typical Raman spectra prior transfer (Fig. 4a) exhibited the characteristic E<sup>1</sup> 2g and A1g modes of pristine MoS2 at 384.6 and 409.1 cm<sup>−1</sup> , respectively, which are in good agreement with reported values for MoS2<sup>9,81–83</sup> . After transfer, we found the peaks at 384.7 cm<sup>−1</sup> (E<sup>1</sup> 2g) and 407.2 cm<sup>−1</sup> (A1g), that is, without detectable shifts in the position of the E<sup>1</sup> 2g mode within the accuracy of our Raman setup. Since the E<sup>1</sup> 2g mode is highly sensitive to uniaxial strain<sup>84</sup> , we conclude that the strain in the transferred MoS2 film was the same as present on the growth substrate and was not significantly affected by our transfer methodology. In contrast, the A1g mode is sensitive to changes in the substrate material, which could cause 

the observed shift of 1.8 cm<sup>−185,86</sup> . To further investigate the quality of the transferred MoS2 film, we compare the average of 25 normalized photoluminescence (PL) intensity spectra of pristine and transferred MoS2 (Fig. 4b). Before transfer, we found two prominent peaks at 1.821 and 1.968 eV, which correspond to A and B excitonic transitions, respectively<sup>87</sup> . After transfer, we observed a drastic increase in the A/B intensity ratio since the B- excitation vanishes. A high A/B intensity ratio indicates a high quality of the MoS2 film<sup>88</sup> . The A exciton transition energy is blue-shifted by 13 meV to 1.834 eV (see Supplementary Fig. 11 for statistics), which we attribute to the change of the substrate material from SiO2 (before transfer) to BCB (after transfer)<sup>86</sup> . The additional features of the PL intensity between 1.96 and 1.97 eV are Raman modes of the underlying BCB, and hence do not belong to the excitonic transitions in the MoS2 (see Supplementary information for the Raman spectrum of BCB). We formed MoS2/graphene heterostructures by stacking a centimeter-sized layer of MoS2 onto a sheet of graphene in two consecutive transfers (see “Methods”). The map of the graphene sheet resistance extracted from THz spectroscopy indicated the presence of graphene in both the MoS2/graphene heterostructure and its surroundings (1030 ± 520 and 1910 ± 280 Ω sq<sup>�1</sup> , respectively). 

7 

NATURE COMMUNICATIONS | (2021) 12:917 | https://doi.org/10.1038/s41467-021-21136-0 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21136-0 

In the region of the MoS2/graphene heterostructure, Rsh is significantly reduced. Since the high sheet resistance of a sole MoS2 layer is not directly detectable in this measurement, we speculate that interactions between graphene and MoS2 caused this variation. Raman and PL spectroscopy of the MoS2/graphene heterostructure confirmed the presence and integrity of both materials (Fig. 4d and Supplementary information). The position of the 2D peak of graphene (ω2D) averaged to 2681:9 ± 1:8 cm<sup>�1</sup> with a full-width at half-maximum (Γ2D;MoS2=gr) of 30:3 ± 3:9 cm<sup>�1</sup> . This value is in good agreement with the results in Fig. 3, which hints at the integrity of the graphene even after stacking. The Raman E<sup>1</sup> 2g mode of MoS2 exhibited a minor shift from 384:26 ± 0:17 to 385:16 ± 0:35 cm<sup>�1</sup> , while the position of the A1g mode remained unchanged (408:06 ± 0:28 cm<sup>�1</sup> ) (see Supplementary information on material characterization prior to transfer). The averaged PL spectrum featured the distinct peaks of A and B excitonic transitions in MoS2 with high A/B ratio and superimposed Raman modes of BCB. We further demonstrated the versatility of the methodology by reversing the order of stacked materials, which formed graphene/MoS2 heterostructures by successfully transferring graphene onto previously transferred MoS2 layers (see Supplementary information). Taken together, the Raman and PL measurements confirm that the layer quality of MoS2 is preserved during the transfer and the stacking to heterostructures. Hence, our methodology is potentially suitable for large-area transfer of MoS2 films and their heterostructures. 

### Discussion 

We have demonstrated a generic methodology for transfer and large-area integration of 2D materials and their heterostructures on wafer level, which is compatible with conventional semiconductor fabrication lines. Our approach avoids manual handling of released layers and relies only on tools, processes, and materials that are already established in the semiconductor industry. To illustrate its applicability, we manufactured graphene devices on a 100-mm-diameter silicon, performed a statistical analysis of the material characteristics, and demonstrated that our transfer method is, in principle, compatible with the conventional process technology. THz near-field inspection confirmed the uniform coverage of graphene in large areas while the evaluation of vdP devices yielded a high charge carrier mobility of up to 2800 ± 100 cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> , which is among the highest reported values for similar substrate sizes and graphene quality. As representatives for transition metal dichalcogenides, we demonstrated the transfer of MoS2. Raman and PL spectroscopy indicated little strain in both transferred graphene and MoS2. We fabricated top-gated field-effect graphene devices (μ ¼ 2600 ± 1300 cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> ), which required multiple lithography steps in combination with conventional deposition and etching processes after the transfer. This result demonstrates that the proposed transfer process is compatible with large-scale device manufacturing without causing significant deterioration in the quality of the 2D material. 

The transfer method replicates the surface topography of the growth substrate of the 2D material in an adhesive layer on the target wafer by molding at low viscosity of the adhesive. After removal of the growth substrate, the 2D material remains on the target wafer in the same shape as it was synthesized on the growth substrate. This feature minimizes defects or additional strain in the 2D material by avoiding deformation. In addition, it reduces wrinkles, which may result from excess material due to different surface topography of the growth substrate and the target wafer. We hypothesize that this feature contributes to preserving similar mechanical properties of the transferred 2D materials. The ability 

of the adhesive layer to mold repeatedly allows the stacking of 2D materials to heterostructures. In this case, merely the bottommost 2D material is in contact with the adhesive layer. This ensures that the other 2D materials and the interfaces between layers are not contaminated by polymer residuals. To demonstrate this capability, we fabricated graphene/hBN heterostructures, doublelayer graphene, and MoS2/graphene heterostructures on large areas by consecutive transfers. In the resulting stacks, Raman, PL, and THz spectroscopy confirmed the uniform coverage and high quality of the graphene and MoS2 layers. 

We anticipate that our transfer methodology is applicable to 2D materials in general, independent of the size and the type of growth substrate. Consequently, the barrier is comparatively low for the industry to consider this methodology for the integration of 2D materials on top of conventional IC and microsystem device substrates in the back end of the line. Hence, we expect that our methodology has the potential to accelerate advancements in fundamental 2D material science, as well as in a wide range of application areas, spanning over electronics, sensing, and photonics. 

### Methods 

Transfer of graphene. First, a 2.5 µm-thick adhesive layer of BCB (Cyclotene 3022-46, Dow Inc.) was spin-coated at 5000 r.p.m. on the 100-mm target wafer. A softbake on a hot plate at 100 °C for 4 min removed solvents and solidified the adhesive layer. Next, the target wafer was brought in proximity to a 100-mm sheet of monolayer CVD graphene on copper foil (Graphenea Inc.) with the graphene facing the BCB layer. This stack was bonded in a commercial wafer bonder (SB8, SÜSS MicroTec SE) at 190 °C for 20 min using a bond force of 3 kN (bond pressure: 0.95 bar) in a nitrogen atmosphere. Etching the copper foil in FeCl3 solution and rinsing in deionized water for 30 min uncovered the graphene, transferred to the target wafer. 

Formation of graphene/hBN heterostructures. A 100-mm wafer was spincoated with a 2.5-µm-thick layer of BCB (Cyclotene 3022-46, Dow Inc.; spinning speed: 5000 r.p.m., softbake: 100 °C for 4 min). A 2.5 cm × 2.5 cm sheet of multilayer hBN (thickness: 2–5 nm) synthesized by CVD on copper foil (2D Semiconductors Inc.) was placed on top of the target wafer (hBN facing the BCB layer) and bonded at 190 °C for 20 min at a bond force of 250 N (bond pressure: 4 bar) in a nitrogen atmosphere. Etching of the copper foil in FeCl3 and subsequent rinsing in deionized water for 30 min uncovered the hBN, transferred to the target wafer. To form a graphene/hBN heterostructure, a 100-mm sheet of CVD graphene on copper foil was placed on top of the target wafer and bonded at 190 °C for 20 min (bond force: 3 kN, bond pressure: 0.95 bar, vacuum atmosphere). Etching of the copper foil in FeCl3 and rinsing in deionized water for 30 min uncovered the graphene, which formed a graphene/hBN heterostructure with the previously transferred hBN. 

Formation of 2-layer graphene. A 2.5-µm-thick adhesive layer of BCB (Cyclotene 3022-46, Dow Inc.) was spin-coated at 5000 r.p.m. on the 100-mm target wafer. Softbake on a hot plate at 100 °C for 4 min removed solvents and solidified the adhesive layer. The target wafer was brought in proximity to a quarter of a 100 mm sheet of monolayer CVD graphene on copper foil (Graphenea Inc.) with the graphene facing the BCB layer. This stack was bonded in a commercial wafer bonder (Suss-SB8) at 190 °C for 20 min using a bond force of 600 N (bond pressure: 3.1 bar) in a nitrogen atmosphere. Etching of the copper foil in FeCl3 solution and rinsing in deionized water for 30 min uncovered the graphene, transferred to the target wafer. To form 2-layer graphene, a 100-mm sheet of CVD graphene on copper foil was placed on top of the target wafer and bonded at 190 °C for 20 min (bond force: 3 kN, bond pressure: 0.95 bar, vacuum atmosphere). Etching of the copper foil in FeCl3 and rinsing in deionized water for 30 min uncovered the graphene, which formed 2-layer graphene with the previously transferred layer. Note, the bond force was adapted to account for the difference in size of the growth substrates. To form reference areas for THz spectroscopy, the 100-mm copper foil was cut into two pieces and graphene was partially removed from one piece by etching in O2 plasma prior transfer. During transfer, both parts were placed side by side, covering the entire target wafer. 

Fabrication and evaluation of vdP devices. A graphene/hBN heterostructure was formed on an oxidized 100-mm silicon wafer (100 nm SiO2) (see above). Thermal evaporation of 20 nm Ti and 200 nm Au through a shadow mask formed electrodes (300 µm × 300 µm) on top of the transferred graphene layer. Ablation by a pulsed femtosecond laser electrically insulated individual vdP devices with an edge length of ~3 mm. These noncontact processes prevent potential material degradation by 

8 

NATURE COMMUNICATIONS | (2021) 12:917 | https://doi.org/10.1038/s41467-021-21136-0 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21136-0 

lithographic layers in contact with the graphene. For device characterization, the wafer was resting on an electromagnet (Wuxue Wen Fang Electric Co. Ltd, model WF-P25/20), which was placed inside a probe station (Cascade Microtech Inc.). Four-point probe measurements of the voltage across the device edge (device current: 100 µA), and the Hall voltage (device current: 1 mA at 1.28 ± 0.17 V; magnetic flux: 28.8 mT) yielded the sheet resistance, carrier density, and mobility of the transferred graphene. Electrical measurements were performed under ambient conditions at room temperature, using a parameter analyzer (Keithley SCS4200). 

Fabrication and evaluation of top-gated field-effect devices. Graphene-based top-gated field-effect devices were fabricated on a 100-mm silicon wafer. First, large-area graphene (10 cm × 10 cm) was transferred by adhesive wafer bonding (see above). Contacts to graphene were fabricated by sputter deposition of 25 nm Ni and e-beam evaporation of 135 nm Al, followed by a lift-off process in acetone (60 °C, 30 min) (1st photolithography layer). The graphene sheet was then patterned by etching in oxygen plasma (2nd photolithography layer)). As a top-gate dielectric, 40 nm Al2O3 was deposited by atomic layer deposition and top-gate electrodes were fabricated by e-beam evaporation of 10/150 nm Ti/Al (3rd photolithography layer). To access the graphene metal contacts under Al2O3, reactive ion etching with SF6 and O2 was used to open vias through the Al2O3 (4th photolithography layer). All resist layers were removed by immersion in acetone (60 °C, 30 min). In this process sequence, the first and second lithographic layers were in direct contact with the graphene, which may have degraded the graphene quality. However, encapsulation of the graphene before fabricating the contacts eliminates this potential source of degradation<sup>89</sup> . Electrical measurements were performed under ambient conditions at room temperature. The sheet resistance (Rsh) was measured by 4-probe vdP method with top gating. A current (I12) was forced between electrodes 1 and 2 (Fig. 3d), while the voltage drop between electrodes 3 and 4 (V34) was measured. The sheet resistance (Rsh) was calculated by<sup>90</sup> 



<!-- Start of picture text -->
V34 π<br>Rsh ¼ I12 ln 2 ð1Þ<br>and the mobility (μ) was then derived by<br>1 dGsh<br>μ ¼ ð2Þ<br>CG dVG<br>where<br>1<br>Gsh ¼ ð3Þ<br>Rsh<br><!-- End of picture text -->

and VG and CG are the gate voltage and the capacitance of the dielectric per unit area (k = 7 for Al2O3), respectively. 

Raman spectroscopy of graphene. Raman measurements were conducted using a confocal Raman microscope (alpha 300R, WITec GmbH), equipped with a 532-nm laser, which was coupled to the microscope using a single-mode optical fiber. A power meter in the optical path determined the laser power (0.6 mW), which ensured a high reproducibility of the experiments. The laser power was chosen to stay in the noninvasive regime<sup>91</sup> . The microscope was connected to a 600 mm ultrahigh-throughput spectrometer (UHTS 600) using a photonic fiber. An 1800 g mm<sup>−1</sup> grating was used for the dispersion and an EMCCD camera for the detection of the scattered light. To compensate the topography of the substrate, a ×50 objective with a NA of 0.5 was chosen for the measurements. Note that we have used a high-resolution 1800 g mm<sup>−1</sup> grating in combination with the 600 mm spectrometer to obtain more intense signals with a pixel resolution of 0.1 cm<sup>−1</sup> @ 2800 relative cm<sup>−1</sup> . For each measurement site, the spectra were acquired in areas of 25 µm × 25 µm with 25 single spectra per line and 25 lines per site (integration time: 3 s). Peak positions were extracted by a Lorentzian fit. To ensure the validity of the extracted values, only data with a peak intensity exceeding a threshold of ten counts and sufficient separation to the noise level were considered. 

purity) was loaded into a quartz boat and placed in the center of the quartz tube of the furnace. The furnace was purged by forming gas (Ar 95%/H2 5%). For the growth, the furnace temperature was ramped up to 950 °C within 30 min, which was then maintained for 60 min. After the growth, the quartz tube was cooled down within 4 h. The growth yielded quasi-continuous films of MoS2 multilayers, with micrometer-sized domains. 

Transfer of MoS2. First, a 2.5-µm-thick adhesive layer of BCB (Cyclotene 3022-46, Dow Inc.) was spin-coated at 5000 r.p.m. on the 100-mm target wafer. A softbake on a hot plate at 100 °C for 4 min removed solvents and solidified the adhesive layer. Next, a multilayer of MoS2, grown on SiO2/Si chips (10 mm × 7 mm), was placed on top of the BCB layer (MoS2 facing the target wafer) and surrounded by silicon dummy chips of the same height to ensure a uniform force distribution during the bonding process. This stack was bonded at 190 °C for 20 min using a bond force of 400 N (bond pressure: 2 bar) in a nitrogen atmosphere, which attached the MoS2 layer on its growth substrate to the target wafer. Etching in O2/ SF6 plasma cleaned the edges of the growth substrate from potential BCB residuals. Submersion of the bonded stack in KOH solution detached the growth substrate from the MoS2 layer by permeation of KOH into the MoS2/substrate interface within tens of seconds. The MoS2 layer remained transferred on the target wafer. 

Formation of MoS2/graphene heterostructures. First, the silicon target wafer (diameter: 100 mm; resistivity: >10<sup>4</sup> Ω·cm) was spin-coated with a 2.5 µm-thick BCB layer (Cyclotene 3022-46, Dow Inc., spinning speed: 5000 r.p.m.; softbake: 100 °C for 4 min). A quarter of a 100-mm sheet of monolayer CVD graphene on copper foil (Graphenea Inc.) was bonded to the target wafer with the graphene facing the BCB layer (bond temperature: 190 °C; bond time: 30 min; bond force: 600 N with a resulting bond pressure of 3.1 bar, nitrogen atmosphere). Etching of the copper foil and rinsing in deionized water for 30 min uncovered the transferred graphene on top of the BCB on the target wafer. Next, a multilayer of MoS2 on a SiO2/Si chip (10 mm × 10 mm) was placed on top of the transferred graphene (MoS2 facing the graphene) and surrounded by silicon dummy chips to ensure a uniform force distribution over the wafer during the following bonding process. Bonding at 190 °C for 30 min attached the MoS2/SiO2/Si chip to the target wafer (bond force: 750 N with a resulting bond pressure of 3 bar, vacuum atmosphere). Etching in O2/SF6 plasma cleaned the edges of the chip while a resist mask protected the remaining surface of the target wafer. Submersion of the bonded stack in acetone stripped the resist mask and detached the growth substrate, leaving the MoS2 film transferred on top of the graphene, forming a MoS2/graphene heterostructure. 

Raman and PL measurements of MoS2 films. Raman and PL measurements were carried out in a confocal Raman system (alpha 300, WITec GmbH) in ambient conditions. For all measurements, an excitation laser with a wavelength of 532 nm and a 100× objective was used. For Raman measurements, the excitation power was 1 mW (1800 g mm<sup>−1</sup> grating), which achieves a spectral resolution of about 1.2 cm<sup>−1</sup> . For PL measurements, the excitation power was 0.2 mW (600 g mm<sup>−1</sup> grating). 

### Data availability 

The data that support the findings of this study are available from the corresponding author upon reasonable request. 

### Code availability 

The code that supports the findings of this study is available from the corresponding author upon request. 

Received: 14 January 2020; Accepted: 14 January 2021; 



THz near-field spectroscopy. We used THz-TDS in transmission mode to measure the sheet resistance of the transferred graphene on the target wafer. The samples were prepared on high-resistivity wafers with a resistivity of >10<sup>4</sup> Ω·cm, to avoid inadvertent absorption of the THz signal by the target wafer. For the measurements, we used a THz pump/probe setup equipped with a femtosecond fiber laser (generating pulses of 100 fs duration and 780 nm center wavelength) to pump a terahertz emitter and to gate a photoconductive near-field micro-probe detector (TeraSpike TD-800-X-HR-WT). By measuring the THz transmission through the sample, we extracted the local sheet resistance of the graphene<sup>71,72</sup> . Lateral scanning of the sample with the tip of the near-field detector held at close distance yielded a spatially resolved map of the graphene sheet resistance with a pixel size of a few hundred micrometer. See Supplementary information for a description of the setup and the estimation of the pixel size. 

Synthesis of MoS2 monolayers. The MoS2 films were grown in a CVD furnace with a 40 mm-diameter quartz tube as the reactor, similar to that described by Luo et al.<sup>92</sup> . In short, the SiO2/Si growth substrates were located 12–15 cm downstream from the center of the heated tube (500 mm). MoS2 powder (Alfa Aeasar, 99% 

### References 

1. Kang, J. et al. On-chip intercalated-graphene inductors for next-generation radio frequency electronics. Nat. Electron. 1, 46–51 (2018). 

2. Auton, G. et al. Graphene ballistic nano-rectifier with very high responsivity. Nat. Commun. 7, 1–6 (2016). 

3. Kim, K. S. et al. Large-scale pattern growth of graphene films for stretchable transparent electrodes. Nature 457, 706–710 (2009). 

4. Huang, L. et al. Graphene/Si CMOS hybrid Hall integrated circuits. Sci. Rep. 4, 5548 (2014). 

5. Dauber, J. et al. Ultra-sensitive Hall sensors based on graphene encapsulated in hexagonal boron nitride. Appl. Phys. Lett. 106, 193501 (2015). 

6. Schall, D. et al. 50 GBit/s photodetectors based on wafer-scale graphene for integrated silicon photonic communication systems. ACS Photonics 1, 781–784 (2014). 

9 

NATURE COMMUNICATIONS | (2021) 12:917 | https://doi.org/10.1038/s41467-021-21136-0 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21136-0 

7. Ma, P. et al. Plasmonically enhanced graphene photodetector featuring 100 Gbit/s data reception, high responsivity, and compact size. ACS Photonics 6, 154–161 (2019). 

8. Goossens, S. et al. Broadband image sensor array based on graphene–CMOS integration. Nat. Photonics 11, 366–371 (2017). 

9. Gatensby, R., Hallam, T., Lee, K., McEvoy, N. & Duesberg, G. S. Investigations of vapour-phase deposited transition metal dichalcogenide films for future electronic applications. Solid State Electron. 125, 39–51 (2016). 

10. Yim, C. et al. Wide spectral photoresponse of layered platinum diselenidebased photodiodes. Nano Lett. 18, 1794–1800 (2018). 

11. Sangwan, V. K. et al. Gate-tunable memristive phenomena mediated by grain boundaries in single-layer MoS2. Nat. Nanotechnol. 10, 403–406 (2015). 

12. Zhang, F. et al. Electric-field induced structural transition in vertical MoTe2and Mo1–xWxTe2-based resistive memories. Nat. Mater. 18, 55–61 (2019). 

13. Belete, M. et al. Nonvolatile Resistive Switching in Nanocrystalline Molybdenum Disulfide with Ion-Based Plasticity. Advanced Electronic Materials 6, 1900892 (2020). 

14. He, Y.-M. et al. Single quantum emitters in monolayer semiconductors. Nat. Nanotechnol. 10, 497–502 (2015). 

15. Mak, K. F. & Shan, J. Photonics and optoelectronics of 2D semiconductor transition metal dichalcogenides. Nat. Photonics 10, 216–226 (2016). 

16. Wu, W. et al. Locally defined quantum emission from epitaxial few-layer tungsten diselenide. Appl. Phys. Lett. 114, 213102 (2019). 

17. Desai, S. B. et al. MoS2 transistors with 1-nanometer gate lengths. Science 354, 99–102 (2016). 

18. Cao, W., Kang, J., Sarkar, D., Liu, W. & Banerjee, K. 2D semiconductor FETs—projections and design for sub-10 nm VLSI. IEEE Trans. Electron Dev. 62, 3459–3469 (2015). 

19. Schmidt, M. et al. Mobility extraction in SOI MOSFETs with sub 1nm body thickness. Solid State Electron. 53, 1246–1251 (2009). 

20. Akinwande, D. et al. Graphene and two-dimensional materials for silicon technology. Nature 573, 507–518 (2019). 

21. Song, J. C. W., Shytov, A. V. & Levitov, L. S. Electron interactions and gap opening in graphene superlattices. Phys. Rev. Lett. 111, 266801 (2013). 

22. Dean, C. R. et al. Hofstadter’s butterfly and the fractal quantum Hall effect in moiré superlattices. Nature 497, 598–602 (2013). 

23. Ponomarenko, L. A. et al. Cloning of Dirac fermions in graphene superlattices. Nature 497, 594–597 (2013). 

24. Cao, Y. et al. Correlated insulator behaviour at half-filling in magic-angle graphene superlattices. Nature https://doi.org/10.1038/nature26154 (2018). 

25. Cao, Y. et al. Unconventional superconductivity in magic-angle graphene superlattices. Nature https://doi.org/10.1038/nature26160 (2018). 

26. Sharpe, A. L. et al. Emergent ferromagnetism near three-quarters filling in twisted bilayer graphene. Science 365, 605–608 (2019). 

27. Neumaier, D., Pindl, S. & Lemme, M. C. Integrating graphene into semiconductor fabrication lines. Nat. Mater. 18, 525–529 (2019). 

28. Li, X. et al. Large-area synthesis of high-quality and uniform graphene films on copper foils. Science 324, 1312–1314 (2009). 

29. Petrone, N. et al. Chemical vapor deposition-derived graphene with electrical performance of exfoliated graphene. Nano Lett. 12, 2751–2756 (2012). 

30. Banszerus, L. et al. Ultrahigh-mobility graphene devices from chemical vapor deposition on reusable copper. Sci. Adv. 1, e1500222 (2015). 

31. O’Brien, M. et al. Transition metal dichalcogenide growth via close proximity precursor supply. Sci. Rep. 4, 7374 (2014). 

32. Li, X. et al. Transfer of large-area graphene films for high-performance transparent conductive electrodes. Nano Lett. 9, 4359–4363 (2009). 

33. Suk, J. W. et al. Transfer of CVD-grown monolayer graphene onto arbitrary substrates. ACS Nano 5, 6916–6924 (2011). 

34. De Fazio, D. et al. High-mobility, wet-transferred graphene grown by chemical vapor deposition. ACS Nano 13, 8926–8935 (2019). 

35. Lin, Y. C. et al. Clean transfer of graphene for isolation and suspension. ACS Nano 5, 2362–2368 (2011). 

36. Wood, J. D. et al. Annealing free, clean graphene transfer using alternative polymer scaffolds. Nanotechnology 26, 055302 (2015). 

37. Hallam, T., Berner, N. C., Yim, C. & Duesberg, G. S. Strain, bubbles, dirt, and folds: a study of graphene polymer-assisted transfer. Adv. Mater. Interfaces 1, 1400115 (2014). 

38. Gammelgaard, L. et al. Graphene transport properties upon exposure to PMMA processing and heat treatments. 2D Mater. 1, 035005 (2014). 

39. Choi, W., Shehzad, M. A., Park, S. & Seo, Y. Influence of removing PMMA residues on surface of CVD graphene using a contact-mode atomic force microscope. RSC Adv. 7, 6943–6949 (2017). 

40. Gao, L. et al. Repeated growth and bubbling transfer of graphene with millimetre-size single-crystal grains using platinum. Nat. Commun. 3, 697–699 (2012). 

41. Liang, X. et al. Toward clean and crackless transfer of graphene. ACS Nano 5, 9144–9153 (2011). 

42. Leong, W. S. et al. Paraffin-enabled graphene transfer. Nat. Commun. 10, 1–8 (2019). 

43. Yoon, T. et al. Direct measurement of adhesion energy of monolayer graphene as-grown on copper and its application to renewable transfer process. Nano Lett. 12, 1448–1452 (2012). 

44. Lock, E. H. et al. High-quality uniform dry transfer of graphene to polymers. Nano Lett. 12, 102–107 (2012). 

45. Martins, L. G. P. et al. Direct transfer of graphene onto flexible substrates. Proc. Natl Acad. Sci. USA 110, 17762–17767 (2013). 

46. Fechine, G. J. M. et al. Direct dry transfer of chemical vapor deposition graphene to polymeric substrates. Carbon 83, 224–231 (2015). 

47. Xin, H., Zhao, Q., Chen, D. & Li, W. Roll-to-roll mechanical peeling for dry transfer of chemical vapor deposition graphene. J. Micro Nano-Manuf. 6, 031004 (2018). 

48. Takahashi, K., Ishida, H. & Sawada, K. Vacuum-sealed microcavity formed from suspended graphene by using a low-pressure dry-transfer technique. Appl. Phys. Lett. 112, 041901 (2018). 

49. Marchena, M. et al. Dry transfer of graphene to dielectrics and flexible substrates using polyimide as a transparent and stable intermediate layer. 2D Mater. 5, 35022 (2018). 

50. Shivayogimath, A. et al. Do-it-yourself transfer of large-area graphene using an office laminator and water. Chem. Mater. 31, 2328–2336 (2019). 

51. Purdie, D. G. et al. Cleaning interfaces in layered materials heterostructures. Nat. Commun. 9, 5387 (2018). 

52. Romagnoli, M. et al. Graphene-based integrated photonics for next-generation datacom and telecom. Nat. Rev. Mater. 3, 392 (2018). 

53. Burdeaux, D., Townsend, P., Carr, J. & Garrou, P. Benzocyclobutene (BCB) dielectrics for the fabrication of high density, thin film multichip modules. J Engl. Med. 19, 1357–1366 (1990). 

54. Mills, M. E., Townsend, P., Castillo, D., Martin, S. & Achen, A. Benzocyclobutene (DVS-BCB) polymer as an interlayer dielectric (ILD) material. Microelectron. Eng. 33, 327–334 (1997). 

55. Niklaus, F., Enoksson, P., Kälvesten, E. & Stemme, G. Low-temperature full wafer adhesive bonding. J. Micromech. Microeng. 11, 100 (2001). 

56. Chua, L.-L. et al. General observation of n-type field-effect behaviour in organic semiconductors. Nature 434, 194–199 (2005). 

57. Chua, L.-L., Ho, P. K. H., Sirringhaus, H. & Friend, R. H. High-stability ultrathin spin-on benzocyclobutene gate dielectric for polymer field-effect transistors. Appl. Phys. Lett. 84, 3400–3402 (2004). 

58. Quellmalz, A. et al. Wafer-scale transfer of graphene by adhesive wafer bonding. In 2019 IEEE 32nd International Conference on Micro Electro Mechanical Systems (MEMS), 257–259 (IEEE, 2019). 

59. Quellmalz, A. et al. Large-scale integration of 2D material heterostructures by adhesive bonding. In 2020 IEEE 33rd International Conference on Micro Electro Mechanical Systems (MEMS) 943–945 (IEEE, 2020). 

60. Lupina, G. et al. Residual metallic contamination of transferred chemical vapor deposited graphene. ACS Nano 9, 4776–4785 (2015). 

61. Rahimi, S. et al. Toward 300 mm wafer-scalable high-performance polycrystalline chemical vapor deposited graphene transistors. ACS Nano 8, 10471–10479 (2014). 

62. Gao, L. et al. Face-to-face transfer of wafer-scale graphene films. Nature 505, 190–194 (2014). 

63. Pandey, H. et al. All CVD boron nitride encapsulated graphene FETs with CMOS compatible metal edge contacts. IEEE Trans. Electron Dev. 65, 4129–4134 (2018). 

64. Shautsova, V., Gilbertson, A. M., Black, N. C. G., Maier, S. A. & Cohen, L. F. Hexagonal boron nitride assisted transfer and encapsulation of large area CVD graphene. Sci. Rep. 6, 30210 (2016). 

65. Banszerus, L. et al. Ballistic transport exceeding 28 μm in CVD grown graphene. Nano Lett. 16, 1387–1391 (2016). 

66. Calado, V. E. et al. Ballistic transport in graphene grown by chemical vapor deposition. Appl. Phys. Lett. 104, 023103 (2014). 

67. Couto, N. J. G. et al. Random strain fluctuations as dominant disorder source for high-quality on-substrate graphene devices. Phys. Rev. X 4, 041019 (2014). 

68. Sutter, P. W., Flege, J.-I. & Sutter, E. A. Epitaxial graphene on ruthenium. Nat. Mater. 7, 406–411 (2008). 

69. Yoshii, S. et al. Suppression of inhomogeneous segregation in graphene growth on epitaxial metal films. Nano Lett. 11, 2628–2633 (2011). 

70. Chen, T.-A. et al. Wafer-scale single-crystal hexagonal boron nitride monolayers on Cu (111). Nature 579, 219–223 (2020). 

71. Wächter, M., Nagel, M. & Kurz, H. Tapered photoconductive terahertz field probe tip with subwavelength spatial resolution. Appl. Phys. Lett. 95, 041112 (2009). 

72. Nagel, M., Matheisen, C. & Kurz, H. in Handbook of Terahertz Technology for Imaging, Sensing and Communications (ed. Saeedkia, D.) 374–402 (Woodhead Publishing, 2013). 

73. Bøggild, P. et al. Mapping the electrical properties of large-area graphene. 2D Mater. 4, 042003 (2017). 

10 

NATURE COMMUNICATIONS | (2021) 12:917 | https://doi.org/10.1038/s41467-021-21136-0 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21136-0 

74. Bendiab, N. et al. Unravelling external perturbation effects on the optical phonon response of graphene. J. Raman Spectrosc. 49, 130–145 (2018). 

75. Lee, J. E., Ahn, G., Shim, J., Lee, Y. S. & Ryu, S. Optical separation of mechanical strain from charge doping in graphene. Nat. Commun. 3, 1024 (2012). 

76. Neumann, C. et al. Raman spectroscopy as probe of nanometre-scale strain variations in graphene. Nat. Commun. 6, 8429 (2015). 

77. Banszerus, L. et al. Identifying suitable substrates for high-quality graphenebased heterostructures. 2D Mater. 4, 025030 (2017). 

78. Fan, X. et al. Graphene ribbons with suspended masses as transducers in ultrasmall nanoelectromechanical accelerometers. Nat. Electron 2, 394–404 (2019). 

79. Fan, X. et al. Suspended graphene membranes with attached silicon proof masses as piezoresistive nanoelectromechanical systems accelerometers. Nano Lett. 19, 6788–6799 (2019). 

80. Uzlu, B. et al. Gate-tunable graphene-based Hall sensors on flexible substrates with increased sensitivity. Sci. Rep. 9, 18059 (2019). 

81. Lee, K., Gatensby, R., McEvoy, N., Hallam, T. & Duesberg, G. S. Highperformance sensors based on molybdenum disulfide thin films. Adv. Mater. 25, 6699–6702 (2013). 

82. Li, H. et al. From bulk to monolayer MoS2: evolution of Raman scattering. Adv. Funct. Mater. 22, 1385–1390 (2012). 

83. Lee, C. et al. Anomalous lattice vibrations of single- and few-layer MoS2. ACS Nano 4, 2695–2700 (2010). 

84. Wang, Y., Cong, C., Qiu, C. & Yu, T. Raman spectroscopy study of lattice vibration and crystallographic orientation of monolayer MoS2 under uniaxial strain. Small 9, 2857–2861 (2013). 

85. Rahaman, M. et al. Highly localized strain in a MoS2/Au heterostructure revealed by tip-enhanced Raman spectroscopy. Nano Lett. 17, 6027–6033 (2017). 

86. Buscema, M., Steele, G. A., van der Zant, H. S. J. & Castellanos-Gomez, A. The effect of the substrate on the Raman and photoluminescence emission of single-layer MoS2. Nano Res. 7, 561–571 (2014). 

87. Splendiani, A. et al. Emerging photoluminescence in monolayer MoS2. Nano Lett. 10, 1271–1275 (2010). 

88. McCreary, K. M., Hanbicki, A. T., Sivaram, S. V. & Jonker, B. T. A- and B-exciton photoluminescence intensity ratio as a measure of sample quality for transition metal dichalcogenide monolayers. APL Mater. 6, 111106 (2018). 

89. Wang, L. et al. One-dimensional electrical contact to a two-dimensional material. Science 342, 614–617 (2013). 

90. Enderling, S. et al. Suspended Greek cross test structures for measuring the sheet resistance of non-standard cleanroom materials. In Proceedings of the 2005 International Conference on Microelectronic Test Structures, 2005. ICMTS 2005, 1–4 (IEEE, 2005). 

91. Wagner, S. et al. Noninvasive scanning Raman spectroscopy and tomography for graphene membrane characterization. Nano Lett. 17, 1504–1511 (2017). 

92. Luo, S. et al. Photoresponse properties of large-area MoS2 atomic layer synthesized by vapor phase deposition. J. Appl. Phys. 116, 164304 (2014). 

### Acknowledgements 

This project has received funding from the European Union’s Horizon 2020 research and innovation program under grant agreement no. 825272 (ULISSES—www.ulisses-project. eu), the European Research Council through the Starting Grant M&M’s (No. 277879), Graphene Flagship (785219, 881603), VINNOVA (2017-05108), VR (2015-05112), the Swedish Foundation for Strategic Research (SSF) (GMT14-0071), the German Ministry for Education and Research (BMBF, GIMMIK 03XP0210), the German Ministry for Economic Affairs and Energy (BMWi) and the European Social Fund in Germany (AachenCarbon, FKZ: 03EFLNW199), and the China Scholarship Council (CSC) through a scholarship grant. We thank Daniel Neumaier of AMO GmbH, Aachen for 

fruitful discussions. Graphene Flagship 2D Experimental Pilot Line (Acronym: 2D-EPL), Grant no. 952792. 

### Author contributions 

A.Q., X.W., K.B.G., N.R., G.S. and F.N. conceptualized the methodology. A.Q. performed significant part of the wafer bonding experiments, part of the white-light interferometric measurements, the entire fabrication and evaluation of the vdP devices, SEM inspection, X.W. performed part the wafer bonding experiments and white-light interferometric measurements. S.W. performed and A.Q. evaluated the Raman measurements of graphene/hBN heterostructures, 1-layer graphene and 2-layer graphene. S.S. performed and evaluated the THz spectroscopy and A.Q. analyzed the data statistically. B.U. and Z.W. designed, fabricated, and characterized top-gated field-effect devices from transferred graphene by A.Q. (bonding) and M.O. (wet transfer). S.L. synthesized the MoS2, M.P. and O.H. performed all related Raman and PL measurements. M.P., O.H. and G.S.D. analyzed the spectroscopic measurements of MoS2. M.L., K.B.G., N.R., G.S. and F.N. supervised the project. All authors contributed to drafting and revising the manuscript. 

### Funding 

Open Access funding provided by KTH Royal Institute of Technology. 

### Competing interests 

A.Q., X.W., K.B.G., N.R., G.S., and F.N. are co-inventors on a patent application describing a method for 2D material transfer (PCT/EP2020/051831). The other authors have no competing interests. 

### Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-021-21136-0. 

Correspondence and requests for materials should be addressed to A.Q. or F.N. 

Peer review information Nature Communications thanks David Mackenzie and the other, anonymous reviewer(s) for their contribution to the peer review of this work. Peer review reports are available. 

Reprints and permission information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2021 

11 

NATURE COMMUNICATIONS | (2021) 12:917 | https://doi.org/10.1038/s41467-021-21136-0 | www.nature.com/naturecommunications 

