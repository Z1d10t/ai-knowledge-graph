# Enhanced bulk photovoltaic effect in two-dimensional ferroelectric CuInP2S6

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Communications |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 292 |
| 作者 | Yue Li, Jun Fu, Xiao-Yu Mao, Chen Chen, Heng Liu, Mingda Gong, H. Zeng |
| DOI | 10.1038/s41467-021-26200-3 |
| 源文件 | 067_Li_2021_Enhanced-bulk-photovoltaic-effect-in-two-dimensi.pdf |

---


# ARTICLE 



> https://doi.org/10.1038/s41467-021-26200-3 **OPEN** 

Enhanced bulk photovoltaic effect in two-dimensional ferroelectric CuInP2S6 Yue Li<sup>1,2,5</sup> , Jun Fu<sup>1,2,5</sup> , Xiaoyu Mao<sup>1,2,5</sup> , Chen Chen<sup>1,2</sup> , Heng Liu<sup>1,2</sup> , Ming Gong<sup>3,4✉</sup> & Hualing Zeng 1,2✉ 

The photocurrent generation in photovoltaics relies essentially on the interface of p-n junction or Schottky barrier with the photoelectric efficiency constrained by the ShockleyQueisser limit. The recent progress has shown a promising route to surpass this limit via the bulk photovoltaic effect for crystals without inversion symmetry. Here we report the bulk photovoltaic effect in two-dimensional ferroelectric CuInP2S6 with enhanced photocurrent density by two orders of magnitude higher than conventional bulk ferroelectric perovskite oxides. The bulk photovoltaic effect is inherently associated to the room-temperature polar ordering in two-dimensional CuInP2S6. We also demonstrate a crossover from twodimensional to three-dimensional bulk photovoltaic effect with the observation of a dramatic decrease in photocurrent density when the thickness of the two-dimensional material exceeds the free path length at around 40 nm. This work spotlights the potential application of ultrathin two-dimensional ferroelectric materials for the third-generation photovoltaic cells. 

> 1 International Center for Quantum Design of Functional Materials (ICQD), Hefei National Laboratory for Physical Science at the Microscale, and Synergetic Innovation Center of Quantum Information and Quantum Physics, University of Science and Technology of China, 230026 Hefei, Anhui, People’s Republic of China.<sup>2</sup> Key Laboratory of Strongly-Coupled Quantum Matter Physics, Chinese Academy of Sciences, Department of Physics, University of Science and Technology of China, 230026 Hefei, Anhui, People’s Republic of China.<sup>3</sup> CAS Key Laboratory of Quantum Information, University of Science and Technology of China, 230026 Hefei, People’s Republic of China.<sup>4</sup> Synergetic Innovation Center of Quantum Information and Quantum Physics, University of Science and Technology of China, 230026 Hefei, Anhui, People’s Republic of China.<sup>5</sup> These authors contributed equally: Yue Li, Jun Fu, Xiaoyu Mao. ✉email: gongm@ustc.edu.cn; hlzeng@ustc.edu.cn 

1 

NATURE COMMUNICATIONS | (2021) 12:5896 | https://doi.org/10.1038/s41467-021-26200-3 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-26200-3 

he bulk photovoltaic effect (BPVE), a kind of nonlinear optical process that converts light into electricity in solids, Thas a potential advantage in a solar cell with an efficiencyficiencyciency 

has a potential advantage in a solar cell with an efficiencyficiencyciency that exceeds the fundamental Schockley–Queisser (S–Q) limit<sup>1–7</sup> . This effect is only valid in crystals with broken inversion symmetry, which can lead to significant electronic polarization<sup>8–10</sup> that plays a similar role as the p–n junction and Schottky barrier in photovoltaics. Thus, a strong zero-bias photocurrent (or shift current) can be observed in noncentrosymmetric materials when irradiated with light above the energy bandgap<sup>11,12</sup> . The BPVE is particularly pronounced in polar materials<sup>13–15</sup> . The recent advances of the BPVE in ferroelectric perovskite oxides exceeding the S–Q limit have spurred further exploration for electronic systems with optimal device efficiency performance<sup>16</sup> . Along this line, the low-dimensional materials such as CuInP2S6, α-In2Se3, and MoTe2 with layered van der Waals (vdW) structure without inversion symmetry have been suggested for high-efficiency photocurrent collection via BPVE<sup>17–23</sup> . However, while the intriguing physics in the two-dimensional (2D) limit, such as magnetism<sup>24–26</sup> , hyperferroelectricity<sup>27–30</sup> , and exotic topological phases<sup>31–33</sup> have been widely explored, the direct experimental study on BPVE in 2D materials remains unimplemented. 

Here we demonstrate the enhanced BPVE in ultrathin ferroelectric CuInP2S6 (CIPS). The shift current is directly measured in the family of 2D materials. The enhanced BPVE is associated to the room-temperature ferroelectricity of CuInP2S6 as evidenced by the electric polarization, temperature, and thickness dependent behavior. Below the critical temperature, Tc ~315 K<sup>17,34</sup> for the transition from ferroelectric phase to paraelectric phase, large open-circuit photovoltage (Voc), and short-circuit photocurrent (Isc) are observed along the direction of electric polarization when irradiated with light. The Voc and Isc can be controlled and even reversed by an external electric field. Based on this approach, the maximum Voc is obtained to be about 1.0 V and the enhanced photocurrent density is two orders of magnitude higher than that reported from the ferroelectric perovskite oxides<sup>35–39</sup> . Notably, above Tc, negligible photovoltage and photocurrent are observed in all devices in the paraelectric phase with restored high symmetry<sup>40</sup> . We find that the shift current density from 2D CIPS falls between that from onedimensional (1D) and three-dimensional (3D) BPVE-based photovoltaics. We also demonstrate a crossover from 2D to 3D photovoltaics when the thickness of the CIPS exceeds the free path length (l0) of photocarriers, beyond which the photocurrent reduces to the dark condition level even with inversion asymmetry. These results highlight the potential of developing nextgeneration solar cells with ultrathin 2D materials. 

## Results 

BPVE in 2D ferroelectric CIPS. In previous investigations of the BPVE on bulk materials, a capacitor-like structure is utilized (see Fig. 1a), where the dielectric layer or polar material is sandwiched by the top and bottom metal electrodes<sup>35,36,39</sup> . When it is irradiated with light, a non-zero Isc could be observed even without external bias. This zero-bias photocurrent is regarded as the characteristic feature of BPVE. The BPVE has been mostly demonstrated in perovskite oxides in the name of photoferroics<sup>3</sup> . For example, a giant photovoltage above the bandgap was observed in domain engineered BiFeO3<sup>3,5</sup> , and the power conversion efficiency η possibly above the S–Q limit was reported<sup>16</sup> . In these experiments, the sample thickness is much larger than the free path length of hot photocarriers, which is about 10–100 nm in a rough estimation<sup>36,41</sup> . In a 1D nanotube with a large free path length, the photocurrent can be furtherly enhanced. Therefore, ultrathin vdW ferroelectrics with 

controllable thickness are ideal candidates for enhanced photocurrent generation via BPVE (see Fig. 1a). 

In this work, 2D CIPS was utilized as the photoferroic layer for the BPVE study. The CIPS is an ionic ferroelectric, where the Cu, In, and paired P–P atoms fill in the sulfur cages. The off-center shift of the Cu cations leads to stable out-of-plane ferroelectricity<sup>17,42</sup> . The electrically switchable polarization in CIPS has been demonstrated at room temperature down to the thickness of 4 nm<sup>17</sup> . Figure 1b presents the optical image of the 2D photovoltaic device with a sandwiched structure (for device #1). All the ultrathin vdW materials used in the devices were prepared by mechanical exfoliation method<sup>43</sup> and assembled via the dry-transfer technique<sup>44</sup> (see the detailed fabrication process in the “Methods” section). The ultrathin CIPS with thickness down to 8 nm was confirmed by the atomic force microscopy (AFM) and the Raman spectroscopy (see Fig. S1) and their ferroelectricity was confirmed by the piezoresponse force microscopy (PFM) measurement at ambient condition (see Fig. S2). In the device, bilayer and few-layer graphene were used as crossed bottom and top electrodes, respectively. Benefited from the high optical transmission of graphene in the visible range<sup>45,46</sup> , our device is allowed to carry out the direct measurements on photo-generated carriers with the synchronous electric control of the polarization. 

The CIPS is a semiconductor with a gap width Eg at ~2.9 eV<sup>47,48</sup> , thus to realize the BPVE, the laser with a wavelength of 405 nm is chosen as the excitation source. We scan the laser spot (with a diameter of 2 μm, see the “Methods” section) over the device at its initial state. From the Isc mapping, we find that the photo-generated current exists only in the overlapping area of the top and bottom graphene electrodes as evidenced by the spatial correspondence (see Fig. 1b, c). In contrast, outside the overlapping sandwich area, the photocurrent is negligible at around 2 pA, which is to the level of the background current as limited by the DC source-monitor (see the “Methods” section). To check the spatial dependence of Isc in detail, we extracted one line profile from the Isc mapping (see Fig. S3). When the laser spot is moved away from the sandwich edge with step resolution at 160 nm, the Isc vanishes quickly to the noise level. This spatial confinement feature is a direct manifestation of finite free path length of the hot photocarriers. This feature excludes the origin of Isc from the Schottky barrier at the single or double graphene/ CIPS interfaces. Moreover, the sign and magnitude of the photocurrent are non-uniformly distributed, showing independence on sample topography (see Figs. 1c and S3). Since the device is not electrically polarized in advance, the spatially randomized photocurrent is the result of the spontaneous electric polarization in CIPS (see Fig. S2). 

Next, we studied the photocurrent generation in CIPS by homogeneous light illumination on the whole device. In the open-circuit condition, we characterize the relation between photocurrent and voltage using<sup>16</sup> 



<!-- Start of picture text -->
J scd<br>V oc ¼ ; ð1Þ<br>σpv þ σd<br><!-- End of picture text -->

where d is the sample thickness, J sc is the photocurrent density from the total photocurrent Isc divided by the laser spot area, and σpv; σd (with σpv � σd) is the conductivity of the photovoltaic current and the dark current, respectively. In theory σpv ¼ eI0αφð_ωÞ<sup>�1</sup> μτ, where I0 is the light intensity, α is the absorption coefficient, ℏω is the excitation photon energy, φ is the quantum yield and μ; τ are the mobility and lifetime of the hot carriers. The photocurrent density is related to the BPVE via the 

2 

NATURE COMMUNICATIONS | (2021) 12:5896 | https://doi.org/10.1038/s41467-021-26200-3 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-26200-3 



<!-- Start of picture text -->
a<br>Cu<br>In<br>P<br>~100 nm ~1 nm S<br>C<br>I Light<br>Dark<br>V<br>J (mA/cm 2 )<br>b c 16 2.7<br>Top graphene<br>8 nm<br>CuInP2S6<br>12<br>Bottom graphene 1.7<br>8<br>0.7<br>4<br>-0.1<br>0 4 8 12 16<br>X (ûm)<br>Y (m)û<br><!-- End of picture text -->

Fig. 1 Bulk photovoltaic effect in 2D ferroelectric CIPS. a (Left panel) The schematic structure of 3D BPVE device with film thickness at the order of around 100 nm. Inset shows the characteristic I–V curve of the bulk photovoltaic effect in 3D ferroelectrics. The black and red lines represent the I–V curves at the dark conditions and bright conditions, respectively. (Right panel) The schematic structure of 2D BPVE device. The thickness of 2D ferroelectrics can be as thin as 1 nm. b, c The optical image and corresponding short-circuit photocurrent density mapping of the 2D BPVE device. The region of top graphene, ultrathin CIPS, and bottom graphene are marked with orange, blue, and red dashed lines, respectively. The scale bar in b is 3 μm. 

third-rank piezoelectric tensor as 



<!-- Start of picture text -->
J sc ¼ αgI0 / I0; ð2Þ<br><!-- End of picture text -->

This relation can be understood from two different aspects by defining the equivalent resistance R ¼ d=ðσpv þ σdÞ and built-in photovoltaic electric field Epv ¼ J sc=ðσpv þ σdÞ. Intuitively, a device with high efficiency is required to have large equivalence resistance R and a large photovaltavic field Epv, which are essential for photocurrent generation instead of electron–hole recombination. Thus, the larger the photovoltaic field is, the stronger the photovoltaic voltage will be. 

Switchable photovoltaic effect in 2D BPVE device. Figure 2a shows the characteristic output I–V curve from one typical device (device #2). Due to the atomically thin thickness of 2D ferroelectrics, the bias in the DC measurement is set to be within ±0.1 V (much smaller than Voc), which is equivalent to a field strength of Em � 10<sup>5</sup> V/cm, to avoid the degradation of electric polarization in ultrathin CIPS (see Supplementary Note 1). With light illumination, a large and positive Isc was observed. Using the laser spot area ~20 μm<sup>2</sup> , we estimate the short-circuit current density Jsc to be around 10 mA/cm<sup>2</sup> . In contrast, when the laser is switched off (dark condition), the current density at 0.1 V is about 1 μA/cm<sup>2</sup> ≪ Jsc. With a linear fit on the output characteristic I–V curve, the Voc is estimated to be −0.8 V, which is close to the coercive field of CIPS (see Fig. S2). Compared with previously reported bulk ferroelectric photovoltaic cells<sup>35–37</sup> , this result yields much larger Isc and Voc at the same excitation density (10.2 W/cm<sup>2</sup> ). These data yield photoconductivity at the order of 8.7 × 10<sup>−7</sup> S/m, which is comparable with the results reported in literatures<sup>35–37</sup> . A full characterization of the ferroelectrics for BPVE is summarized in Table 1, highlighting the potential advantages of CIPS for BPVE based photovoltaics by comparing them with the other materials in the literature. 

In ferroelectrics, the electric polarization is nonvolatile and electrically switchable. Therefore, the BPVE of CIPS should be in principle controllable via an external electric field. To verify the relation between the enhanced photocurrent and the ferroelectricity, we study the photocurrent as a function of poling voltage. Figure 2b presents the photovoltaic behavior of the device (for device #3) with the pulsed poling voltage varying from +1.8 to −1.8 V and then backward to +1.8 V. When polarizing the device with +1.8 V, a positive photocurrent is observed within ±0.1 V reading bias. With −1.8 V poling voltage, the current is modulated to negative. By scanning the polarizing voltage, the sign of the photocurrent can be controlled from negative to positive gradually. The asymmetry of the photocurrent between backward and forward scanning arises from the ferroelectric hysteresis of CIPS. Specifically, the switchable photocurrent is summarized in Fig. 2c, where the BPVE can be enhanced or suppressed subject to the electric polarization state of CIPS. To show the hysteresis behavior more clearly, we extract the Jsc at each poling voltage. As shown in Fig. 2d, the Jsc follows an obvious hysteresis loop when the poling voltage scans forward and backward. Similarly, the Voc as the function of the poling voltage is shown in Fig. S5. 

Temperature and power dependence of the BPVE in CIPS. To further investigate the origin of BPVE in CIPS, we study the BPVE as a function of temperature (T). CIPS is a room temperature ferroelectric with critical temperature Tc at ~315 K<sup>17,34</sup> . Upon heating the device to be above Tc, the ferroelectric CIPS will transform to the paraelectric phase with restored inversion symmetry, in which the BPVE is forbidden strictly. Figure 3a shows the open-circuit voltage as a function of temperature, in which the Voc decreases with the increase of temperature and vanishes completely when T > 315 K. The disappearance of the photovoltage above Tc indicates that the observed enhanced BPVE is associated with the ferroelectricity of 2D CIPS. We also 

3 

NATURE COMMUNICATIONS | (2021) 12:5896 | https://doi.org/10.1038/s41467-021-26200-3 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-26200-3 



<!-- Start of picture text -->
a b J (mA/cm 2 )<br>0.1<br> Dark  15<br> Pin 2 ûW<br> Fitted I-V1<br>0.0 0<br>10  Pin 1 ûW<br> Fitted I-V2<br> Pin 0.5 ûW<br> Fitted I-V3 -0.1 -15<br> Pin 0.25 ûW 1.2 0.0 -1.2 -1.2 0.0 1.2<br> Fitted I-V4 Poling Voltage (V)<br>5<br> Pin 0.125 ûW<br> Fitted I-V5 c 12 + Poled d 12<br>6<br>0V Poled<br>0 0 0<br>-6 - Poled<br>-12 -12<br>-1.5 -1.0 -0.5 0.0 -0.1 0.0 0.1 -1.2 0.0 1.2<br>Voltage (V) Voltage (V) Poling Voltage (V)<br> (V)Vr<br>2J (mA/cm)<br>2J (mA/cm) 2(mA/cm)Jsc<br><!-- End of picture text -->

Fig. 2 Switchable photovoltaic effect in 2D BPVE device. a The characteristic output I–V curves of device #2 at dark (black dots) and bright (color dots) conditions. The excitation light source is the laser line with 405 nm wavelength. The dotted color lines represent the linear fit on the output I–V curves measured at bright conditions with different laser power. b The photovoltaic behavior under different poling voltages. The poling voltage is swept from +1.8 to −1.8 V and then backward to +1.8 V. The reading bias is set to be within ±0.1 V. The color represents the magnitude of the generated photocurrent density. c Extracted output I–V curves at specific poling voltages from b with the red, blue, and dark blue dots representing the positively, zero voltage, and negatively poled states respectively. d The plot of Isc as a function of the poling voltage. The arrows indicate the measurement sequence. 

Table 1 The results of short-circuit current density Jsc, open-circuit voltage Voc, photoconductivity σ, fill factor (FF), and power conversion efficiency η for samples with thickness d and excitation intensity Pin. 

||Jsc (A/cm<sup>2</sup>)|Voc (V)|d (nm)|Pin (W/cm<sup>2</sup>)|σ (S/m)|FF (%)|Gap (eV)|S–Q<br>limit (%)|η (%)|
|---|---|---|---|---|---|---|---|---|---|
|BTO tip<br>enhanced<sup>16</sup>|1.9 × 10<sup>−2</sup>|1.2|100|0.1|1.6 × 10<sup>−5</sup>|21|3.2|2.8|4.8|
|BTO 20 nm<sup>36</sup>|2.2 × 10<sup>−6</sup>|0.6|20|0.3|7.3 × 10<sup>−10</sup>|25|3.2|2.8|1.1 × 10<sup>−4</sup>|
|BTO 50 nm<sup>36</sup>|3.8 × 10<sup>−6</sup>|0.65|50|0.3|2.9 × 10<sup>−9</sup>|25|3.2|2.8|2.1 × 10<sup>−4</sup>|
|BFO<sup>35</sup>|3.8 × 10<sup>−7</sup>|0.27|170|7.5 × 10<sup>−4</sup>|2.4 × 10<sup>−9</sup>|25|2.7|8.8|3.4 × 10<sup>−3</sup>|
|KBNNO<sup>37</sup>|4 × 10<sup>−8</sup>|3.5|2 × 10<sup>4</sup>|4 × 10<sup>−3</sup>|2.3 × 10<sup>−9</sup>|31.5|1.39|32.9|1.1 × 10<sup>−3</sup>|
|PLZTN<sup>38</sup>|3.7 × 10<sup>−8</sup>|23|3 × 10<sup>5</sup>|0.1|4.8 × 10<sup>−9</sup>|46|2.5|12.5|3.9 × 10<sup>−4</sup>|
|BBLT<sup>39</sup>|6.5 × 10<sup>−9</sup>|16|5 × 10<sup>5</sup>|0.1|2.03 × 10<sup>−9</sup>|29|3.2|2.8|3.0 × 10<sup>−5</sup>|
|CIPS|9.6 × 10<sup>−3</sup>|0.8|7.3|10.2|8.71 × 10<sup>−7</sup>|25|2.85|7.1|0.63 (/α~ 3%)|
|CIPS|8 × 10<sup>−4</sup>|1.65|7.3|0.3|3.3 × 10<sup>−8</sup>|25|2.85|7.1|3.67(/α~ 3%)|
|CIPS|2.6 × 10<sup>−5</sup>|0.5|230|25.5|1.17 × 10<sup>−7</sup>|25|2.85|7.1|5.1 × 10<sup>−5</sup><br>(/α~ 25%)|



Data in the first seven rows are from previous literature; the last three rows are data from our samples. The photoconductivity per power density can be obtained using σ/Pin, in which the CIPS almost have the smallest conductivity per excitation density. For the power conversion efficiency, the best value for thin CIPS films in this study is closing to the S–Q limit when considering the absorption at 405 nm (see Supplementary Note 2). 

investigate the photocurrent dependence on light illumination power Pin. Figure 3b displays the Jsc and the corresponding σpv from Eqs. (1) and (2) as a function of the laser power (for device #2) changing from 1 to 20 W/cm<sup>2</sup> . The monotonical increase of generated Jsc with Pin is consistent with the prediction of Eq. (2) and the results in previous studies of BPVE<sup>21,35,36</sup> . By the extracted open-circuit voltage, we also extract σpv, which is proportional to the excitation power as expected from Eqs. (1) and (2). By comparing the photoconductivity of CIPS with that from previous literatures<sup>31–35</sup> , we find comparable results in our devices. Importantly, noting that in all the experiments, our samples have the smallest thickness with a similar amplitude of Voc and σpv, thus the CIPS has the smallest photoconductivity per excitation power if using the data in Table 1. 

Energy band alignments in the 2D CIPS device. The observed enhanced photocurrent via BPVE in CIPS can be understood 

through the switchable energy band alignments in the graphene/ CIPS/graphene heterostructure. In the ferroelectric phase, the offcenter shift of the Cu ions induces a built-in electric field (Ebi) perpendicular to the 2D plane. Therefore, with an out-of-plane electric polarization, the vacuum levels at the two sides of the CIPS are different as illustrated in Fig. 4a, b, which leads to different alignments of the energy bands of graphene at the top and bottom interfaces. The different energy band alignments result in an asymmetric energy potential barrier with barrier height at ΔΦ along the out-of-plane direction. For ferroelectric CIPS, the ΔΦ could be as large as ~1 eV<sup>49</sup> . When the device is illuminated with light, the photo-generated electron and hole pairs are separated by the Ebi and are drifted under ΔΦ to generate significant Isc. Furthermore, the sign of the asymmetric energy potential barrier between the top and bottom surfaces can be controlled by the direction of electric polarization, leading to the direction switchable photocurrent (Fig. 2c). When the CIPS is with the paraelectric phase, the charged Cu ions are equally 

4 

NATURE COMMUNICATIONS | (2021) 12:5896 | https://doi.org/10.1038/s41467-021-26200-3 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-26200-3 



<!-- Start of picture text -->
a b<br>0.8 15 1.8x10 -6<br>0.6<br>10 1.2x10 -6<br>0.4 TC<br>5 6.0x10 -7<br>0.2<br>0.0 0 0.0<br>300 305 310 315 320 0 10 20<br>Temperature (K) Power Density (W/cm 2 )<br> (V)VOC (s/m)§<br>2 (mA/cm)Jsc<br><!-- End of picture text -->

Fig. 3 Temperature and power dependence of the BPVE in CIPS. a The open-circuit voltage as a function of the temperature. The Voc vanishes when the temperature increases to the phase transition temperature at about 315 K. Insets display the crystal structures of CIPS in ferroelectric and paraelectric phases. b The short-circuit current density (left axis) and the photoconductivity (right axis) as a function of the illumination laser power density. Linear dependence of the Jsc and σpv on excitation power is in accord with Eq. (2). 



<!-- Start of picture text -->
a Vacuum level b Vacuum level c Vacuum level<br>ΔΦ ~1 eV ΔΦ ~1 eV<br>Φ ~ 3.7 eV Φ ~ 3.7 eV<br>- -<br>Eg<br>Eg Ef Eg Ef Ef<br>+ +<br>+ - - +<br>+ - - +<br>+ - - +<br>+ I sc - - I sc +<br>+ - - +<br>+ - - +<br>+ - - +<br>Ebi Ebi<br><!-- End of picture text -->

Fig. 4 Energy band alignments in the 2D CIPS device. a, b The band diagram for the graphene/CIPS/graphene heterostructure at the upward and downward electric polarization state of ferroelectric CIPS. The top and bottom graphene electrodes are represented with slabs of atoms in gray on the left and right sides of CIPS. In the heterostructure, the polarization charges are marked with “+” and “−” symbols, and the built-in electric field are indicated by the dashed lined arrows. The cartoon on the top depicts the corresponding energy shift of the conduction band and valence band. c The band diagram of the device with the CIPS at the paraelectric phase. 

distributed at the two surfaces in the unit cell, resulting in a zero Ebi and ΔΦ as shown in Fig. 4c. There is no observable photocurrent from BPVE. 

The dimensionality effect of the BPVE. Finally, to show the advantages of 2D BPVE, we summarize the photocurrent density generated via BPVE from different material systems in Fig. 5a. By considering the linear dependence of the photocurrent on light power density from Eq. (2), we take three colored shadings to represent the performance for 1D, 2D, and 3D BPVE photovoltaics, respectively. We find that the BPVE induced photocurrent density in 2D CIPS falls in the gap between 1D (WS2 nanotube in ref.<sup>21</sup> ) and conventional 3D ferroelectric photovoltaics. For 3D materials, most of the ferroelectrics are oxide insulators with perovskite structure, in which the large gap width 

fundamentally limits the photocurrent density unless via subtle domain engineering (refs.<sup>3,5,6</sup> ) or under the aid of scanning probe technique (ref.<sup>16</sup> ). In 1D WS2 nanotube, the ultrahigh photocurrent density is benefited from the nanoscale diameter size of the tube in nature and the enhanced shift current<sup>50</sup> . The BPVE-induced photocurrent density is three orders of magnitude larger than that observed in 3D bulk photovoltaics. However, as confined by the tube structure, the direction of the photocurrent could not be switched by the external electric field. For 2D ferroelectric CIPS, the bulk photovoltaic performance of all the devices (with thickness ranging from 8 to 60 nm) fill in this three orders of magnitude gap in Jsc. We have also studied 2D CIPS with various thicknesses (see Fig. 5b), showing that when the thickness is <dc � 2l0, where l0 � 40 nm, significantly enhanced BPVE can be found. In contrast, when the film thickness is larger than the above free path length, the photocurrent decreases to the 

5 

NATURE COMMUNICATIONS | (2021) 12:5896 | https://doi.org/10.1038/s41467-021-26200-3 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-26200-3 



<!-- Start of picture text -->
a 10 4<br> WS2 Nanotube in Ref.21<br>10 3  CIPS-8 nm CIPS-10 nm<br> CIPS-15 nm<br>10 2  CIPS-20 nm<br> CIPS-60 nm<br>10 1  CIPS-62 nm  CIPS-67 nm<br> BiFeO3-170 nm in Ref.35<br>10 0  BaTiO3-50 nm in Ref.36<br> BaTiO3-20 nm in Ref.36<br>10 -1  KBNNO in Ref.37 PLZTN in Ref.38<br> BBLT in Ref.39<br>10 -2  CIPS-80 nm<br> CIPS-90 nm<br>10 -3  CIPS-95 nm CIPS-120 nm<br>10 -4<br>10 -5<br>10 -6<br>10 -6 10 -5 10 -4 10 -3 10 -2 10 -1 10 0 10 1 10 2 10 3 10 4<br>Power (W/cm 2 )<br>b<br>10 0<br>10 -1<br>dc  ~80 nm<br>10 -2<br>10 -3<br>0 50 100 150 200 250<br>CIPS Thickness (nm)<br>2 (mA/cm)Jsc<br>/P (mA/W)Isc<br><!-- End of picture text -->

Fig. 5 The dimensionality factor of the BPVE. a An overview of the photovoltaic performance in 1D, 2D, and 3D BVPE materials. The paralleled polygons filled in yellow, red, and blue represent the short-circuit photocurrent density from 1D, 2D, and 3D bulk photovoltaics respectively. With the same illumination power density, the photocurrent density from 2D ferroelectric CIPS falls in the gap between 1D and 3D bulk photovoltaics. b The thickness dependent BPVE in ferroelectric CIPS. For each device with different film thicknesses, the observed short-circuit photocurrent is normalized by the incident light power. The Isc decreases to the 3D noise level as the CIPS is thicker than 80 nm, indicating the free path length of the hot photocarriers to be about 40 nm, using the estimation of dc � 2l0. A similar conclusion can be achieved by the open circuit voltage, as shown in the Supplementary material of Fig. S10. 

noise level quickly. This is a clear demonstration of the crossover from 2D to 3D BPVE materials, which has not yet been observed in experiments. A similar conclusion can be achieved by examining the Voc (see Fig. S10). Our results suggest that the dimensionality of the photovoltaic materials plays an essential role in photo-electric conversion. The observed dimensionality effect in BPVE photovoltaics can be intuitively interpreted from two aspects. Firstly, it is well-known that the separation between the two collecting electrodes in a photovoltaic device should be smaller than the free path length for efficient photoelectric conversion (see the Cartoon in Fig. S13). With a capacitor-like device structure, the atomic thickness of 2D CIPS naturally fulfills this prerequisite. Secondly, it has been pointed out that when the dimensionality is reduced the BPVE is more efficient with enhanced shift current<sup>51</sup> , which may originate from the Berry connection of the Bloch functions<sup>52</sup> . 

## Discussion 

In summary, we report the enhanced BPVE effect in 2D ferroelectric CIPS. In the ferroelectric phase without inversion symmetry, the photocurrent is enhanced by two orders of magnitude as compared with that in bulk ferroelectric materials. In contrast, in the paraelectric phase with inversion symmetry, the BPVE is absent even in the 2D limit. The performance of our 2D photovoltaics falls in between the 1D and 3D bulk photovoltaics, implying that the device dimensionality is one of the key ingredients for developing high-efficiency BPVE-based photovoltaics. 

From the thickness-dependent photocurrent generation, we estimate the free path length in CIPS to be about 40 nm. Our findings highlight the potential of ultrathin 2D ferroelectrics for developing third-generation solar cells with high efficiency beyond the fundamental S–Q limit. 

## Methods 

Sample preparation and topography measurement. Bulk single crystal graphite and CIPS used in the study were purchased from 2D Semiconductors Inc. The ultrathin vdW materials were prepared by the mechanical exfoliation on Si substrate with 300 nm SiO2 coated on the top. The vdW heterostructures were made by the alldry transfer technique<sup>42</sup> . The topography and thickness of samples were characterized by atomic force microscopy (AFM) (AIST-Smart SPM) at tapping mode. 

Raman spectroscopy characterization. Raman spectra were carried out with the Horiba micro-Raman system (LabRAM HR Evolution) to verify the phase structure and thickness of CIPS and graphene. The wavelength of the excitation laser is 532 nm and the on-sample power is set to be 150 μW. As shown in Fig. S1, the characteristic Raman mode of single crystal CIPS at 275, 325, 384 cm<sup>−1</sup> were observed, which confirm the ferroelectric phase and are consistent with the previous reports<sup>16</sup> . The graphene thickness is confirmed by the optical contrast under an optical microscope and the Raman spectra. For a few layers of graphene, the intensity ratio of G mode and 2D mode can be used to identify film thickness. The ratio of IG/I2D for the bottom graphene electrode in device #1 is 2/3, which confirms that it is bilayer graphene. 

PFM characterization. PFM measurements were performed with the AIST-Smart SPM system under ambient conditions. The PFM tip used is Pt/Ir coated conducting Si tip. The conductive substrates used in this study were prepared through sputtering 20 nm-thick gold film onto the Silicon substrate. Ultrathin CIPS was mechanically cleaved directly on the conductive substrate. In the PFM measurements, the piezoelectric amplitude and phase show obvious butterfly-like loop and hysteresis loop as shown in Fig. S2, respectively. 

Device fabrication and transport measurement. The metal electrodes on the top and bottom graphene were made by the standard UV lithography technique and the following electron beam evaporation of 5 nm Ti and 60 nm Au. The samples were soaked in acetone for 12 h during the lift-off process. The transport measurement was taken in the vacuum chamber under the pressure blow 0.1 Torr at room temperature and above room temperature. Keysight source meter (B2912A with 10 fA resolution) was used to apply pulsed voltage and measure the I–V characteristics. The excitation laser wavelength for the photovoltaic measurement is 405 nm. The laser was focused on the sample with a homemade scanning confocal microscopy system. 

## Data availability 

The data that support the findings of this study are available from the corresponding author on reasonable request. 

Received: 18 February 2021; Accepted: 21 September 2021; 



## References 

1. Kraut, W. & von Baltz, R. Anomalous bulk photovoltaic effect in ferroelectrics: a quadratic response theory. Phys. Rev. B 19, 1548–1554 (1979). 

2. von Baltz, R. & Kraut, W. Theory of the bulk photovoltaic effect in pure crystals. Phys. Rev. B 23, 5590–5596 (1981). 

3. Bhatnagar, A., Roy Chaudhuri, A., Heon Kim, Y., Hesse, D. & Alexe, M. Role of domain walls in the abnormal photovoltaic effect in BiFeO3. Nat. Commun. 4, 2835 (2013). 

4. Sipe, J. E. & Shkrebtii, A. I. Second-order optical response in semiconductors. Phys. Rev. B 61, 5337–5352 (2000). 

5. Yang, S. Y. et al. Above-bandgap voltages from ferroelectric photovoltaic devices. Nat. Nanotechnol. 5, 143–147 (2010). 

6. Seidel, J. et al. Efficient photovoltaic current generation at ferroelectric domain walls. Phys. Rev. Lett. 107, 126805 (2011). 

7. Rühle, S. Tabulated values of the Shockley–Queisser limit for single junction solar cells. Sol. Energy 130, 139–147 (2016). 

8. Xiao, D., Chang, M.-C. & Niu, Q. Berry phase effects on electronic properties. Rev. Mod. Phys. 82, 1959–2007 (2010). 

9. Zhang, Y. et al. Switchable magnetic bulk photovoltaic effect in the twodimensional magnet CrI3. Nat. Commun. 10, 3783 (2019). 

6 

NATURE COMMUNICATIONS | (2021) 12:5896 | https://doi.org/10.1038/s41467-021-26200-3 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-26200-3 

10. Nakamura, M. et al. Shift current photovoltaic effect in a ferroelectric chargetransfer complex. Nat. Commun. 8, 281 (2017). 

11. Young, S. M. & Rappe, A. M. First Principles Calculation of the Shift Current Photovoltaic Effect in Ferroelectrics. Phys. Rev. Lett. 109, 116601 (2012). 

12. Cook, A. M., Fregoso, B. M., de Juan, F., Coh, S. & Moore, J. E. Design principles for shift current photovoltaics. Nat. Commun. 8, 14176 (2017). 

13. Fridkin, V. M. Bulk photovoltaic effect in noncentrosymmetric crystals. Crystallogr. Rep. 46, 654–658 (2001). 

14. Glass, A. M., von der Linde, D. & Negran, T. J. High-voltage bulk photovoltaic effect and the photorefractive process in LiNbO3. Appl. Phys. Lett. 25, 233–235 (1974). 

15. Glass, A. & Auston, D. Optical rectification by impurities in polar crystals. IEEE J. Quantum Electron. 8, 540–541 (1972). 

16. Spanier, J. E. et al. Power conversion efficiency exceeding the Shockley–Queisser limit in a ferroelectric insulator. Nat. Photonics 10, 611–616 (2016). 

17. Liu, F. et al. Room-temperature ferroelectricity in CuInP2S6 ultrathin flakes. Nat. Commun. 7, 12357 (2016). 

18. Wan, S. et al. Room-temperature ferroelectricity and a switchable diode effect in two-dimensional α-In2Se3 thin layers. Nanoscale 10, 14885–14892 (2018). 

19. Yuan, S. et al. Room-temperature ferroelectricity in MoTe2 down to the atomic monolayer limit. Nat. Commun. 10, 1775 (2019). 

20. Zhou, Y. et al. Out-of-plane piezoelectricity and ferroelectricity in layered α- In2Se3 nanoflakes. Nano Lett. 17, 5508–5513 (2017). 

21. Zhang, Y. J. et al. Enhanced intrinsic photovoltaic effect in tungsten disulfide nanotubes. Nature 570, 349–353 (2019). 

22. Guan, Z. et al. Recent progress in two-dimensional ferroelectric materials. Adv. Electron. Mater. 6, 1900818 (2020). 

23. Qi, L., Ruan, S. & Zeng, Y.-J. Review on recent developments in 2D ferroelectrics: theories and applications. Adv. Mater. 33, 2005098 (2021). 

24. Deng, Y. et al. Gate-tunable room-temperature ferromagnetism in twodimensional Fe3GeTe2. Nature 563, 94–99 (2018). 

25. Gong, C. et al. Discovery of intrinsic ferromagnetism in two-dimensional van der Waals crystals. Nature 546, 265–269 (2017). 

26. Huang, B. et al. Layer-dependent ferromagnetism in a van der Waals crystal down to the monolayer limit. Nature 546, 270–273 (2017). 

27. Garrity, K. F., Rabe, K. M. & Vanderbilt, D. Hyperferroelectrics: proper ferroelectrics with persistent polarization. Phys. Rev. Lett. 112, 127601 (2014). 

28. Xiao, J. et al. Intrinsic two-dimensional ferroelectricity with dipole locking. Phys. Rev. Lett. 120, 227601 (2018). 

29. Ding, W. et al. Prediction of intrinsic two-dimensional ferroelectrics in In2Se3 and other III2–VI3 van der Waals materials. Nat. Commun. 8, 14956 (2017). 

30. Birol, T. Stable and switchable polarization in 2D. Nature 560, 174 (2018). 31. Kou, L. et al. Robust 2D topological insulators in van der Waals heterostructures. ACS Nano 8, 10448–10454 (2014). 

32. Kou, L. et al. Graphene-based topological insulator with an intrinsic bulk band gap above room temperature. Nano Lett. 13, 6251–6255 (2013). 

33. Hu, J., Alicea, J., Wu, R. & Franz, M. Giant topological insulator gap in graphene with 5d adatoms. Phys. Rev. Lett. 109, 266801 (2012). 

34. Simon, A., Ravez, J., Maisonneuve, V., Payen, C. & Cajipe, V. B. Paraelectricferroelectric transition in the lamellar thiophosphate CuInP2S6. Chem. Mater. 6, 1575–1580 (1994). 

35. Ji, W., Yao, K. & Liang, Y. C. Bulk photovoltaic effect at visible wavelength in epitaxial ferroelectric BiFeO3 thin films. Adv. Mater. 22, 1763–1766 (2010). 

36. Zenkevich, A. et al. Giant bulk photovoltaic effect in thin ferroelectric BaTiO3 films. Phys. Rev. B 90, 161409 (2014). 

37. Grinberg, I. et al. Perovskite oxides for visible-light-absorbing ferroelectric and photovoltaic materials. Nature 503, 509–512 (2013). 

38. Huangfu, G. et al. Visible or near-infrared light self-powered photodetectors based on transparent ferroelectric ceramics. ACS Appl. Mater. Interfaces 12, 33950–33959 (2020). 

39. Pal, S. et al. Giant photovoltaic response in band engineered ferroelectric perovskite. Sci. Rep. 8, 8005 (2018). 

40. Ji, C. et al. Ferroelectricity-driven self-powered ultraviolet photodetection with strong polarization sensitivity in a two-dimensional halide hybrid Perovskite. Angew. Chem. Int. Ed. 59, 18933–18937 (2020). 

41. Butler, K. T., Frost, J. M. & Walsh, A. Ferroelectric materials for solar energy conversion: photoferroics revisited. Energy Environ. Sci. 8, 838–848 (2015). 

44. Castellanos-Gomez, A. et al. Deterministic transfer of two-dimensional materials by all-dry viscoelastic stamping. 2D Mater. 1, 011002 (2014). 

45. Bonaccorso, F., Sun, Z., Hasan, T. & Ferrari, A. C. Graphene photonics and optoelectronics. Nat. Photonics 4, 611–622 (2010). 

46. Liu, M. et al. A graphene-based broadband optical modulator. Nature 474, 64–67 (2011). 

47. Studenyak, I. P. et al. Disordering effect on optical absorption processes in CuInP2S6 layered ferrielectrics. Phys. Status Solidi B 236, 678–686 (2003). 

48. Dziaugys, A., Banys, J., Macutkevic, J., Sobiestianskas, R. & Vysochanskii, Y. Dipolar glass phase in ferrielectrics: CuInP2S6 and Ag0.1Cu0.9InP2S6 crystals. Phys. Status Solidi A 207, 1960–1967 (2010). 

49. Wu, J. et al. High tunnelling electroresistance in a ferroelectric van der Waals heterojunction via giant barrier height modulation. Nat. Electron. 3, 1–7 (2020). 

50. Tan, L. Z. et al. Shift current bulk photovoltaic effect in polar materials— hybrid and oxide perovskites and beyond. NPJ Comput. Mater. 2, 16026 (2016). 

51. Cook, A. M., Fregoso, B., de Juan, F., Coh, S. & Moore, J. E. Design principles for shift current photovoltaics. Nat. Commun. 8, 14176 (2017). 

52. Young, S. M., Zheng, F. & Rappe, A. M. First-principles calculation of the bulk photovoltaic effect in bismuth ferrite. Phys. Rev. Lett. 109, 236601 (2012). 

## Acknowledgements 

This work was supported by the National Key Research and Development Program of China (Grant Nos. 2017YFA0205004, 2018YFA0306600, 2017YFA0304504 and 2017YFA0304103), the National Natural Science Foundation of China (Grant Nos. 11674295 and 11774328), the Fundamental Research Funds for the Central Universities (Grant Nos. WK3510000013 and WK2030020032), and the Anhui Initiative in Quantum Information Technologies (Grant No. AHY170000). This work was partially carried out at the USTC Center for Micro and Nanoscale Research and Fabrication. 

## Author contributions 

H.Z. conceived the idea and supervised the research. Y.L., J.F., and X.M. prepared the samples, fabricated the devices, and carried out the photocurrent measurements, H.L. and C.C. carried out the PFM measurements. Y.L., J.F., X.M., M.G., and H.Z. analyzed the data and wrote the paper. All authors commented on the manuscript. 

## Competing interests 

The authors declare no competing interests. 

## Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-021-26200-3. 

Correspondence and requests for materials should be addressed to Ming Gong or Hualing Zeng. 

Peer review information Nature Communications thanks the anonymous reviewer(s) for their contribution to the peer review of this work. Peer reviewer reports are available. 

Reprints and permission information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

42. Belianinov, A. et al. CuInP2S6 room temperature layered ferroelectric. Nano Lett. 15, 3808–3814 (2015). 

43. Novoselov, K. S. et al. Electric field effect in atomically thin carbon films. Science 306, 666 (2004). 

© The Author(s) 2021 

7 

NATURE COMMUNICATIONS | (2021) 12:5896 | https://doi.org/10.1038/s41467-021-26200-3 | www.nature.com/naturecommunications 

