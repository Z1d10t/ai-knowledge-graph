# Efficient and stable inverted perovskite solar cells with very high fill factors via incorporation of star-shaped polymer

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Science Advances |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 239 |
| 作者 | Qipeng Cao, Yongjiang Li, Hong Zhang, Jiabao Yang, Jian Han, Ting Xu, Shuangjie Wang, Zi-Shuai Wang et al. |
| DOI | 10.1126/sciadv.abg0633 |
| 源文件 | 034_Cao_2021_Efficient-and-stable-inverted-perovskite-solar-c.pdf |

---
SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

#### **AP P L IED P HYSICS** 

# **Efficient and stable inverted perovskite solar cells with very high fill factors via incorporation of star-shaped polymer** 

**Qi Cao**<sup>**1†**</sup> **, Yongjiang Li**<sup>**2†**</sup> **, Hong Zhang**<sup>**3†**</sup> **, Jiabao Yang**<sup>**1**</sup> **, Jian Han**<sup>**1**</sup> **, Ting Xu**<sup>**4**</sup> **, Shuangjie Wang**<sup>**1**</sup> **, Zishuai Wang**<sup>**5**</sup> **, Bingyu Gao**<sup>**1**</sup> **, Junsong Zhao**<sup>**1**</sup> **, Xiaoqiang Li**<sup>**1**</sup> **, Xiaoyan Ma**<sup>**2**</sup> **, Shaik Mohammed Zakeeruddin**<sup>**3**</sup> **, Wei E. I. Sha**<sup>**4**</sup> **, Xuanhua Li**<sup>**1**</sup> ***, Michael Grätzel**<sup>**3**</sup> ***** 

Copyright © 2021 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works. Distributed under a Creative Commons Attribution NonCommercial License 4.0 (CC BY-NC). 

**Stabilizing high-efficiency perovskite solar cells (PSCs) at operating conditions remains an unresolved issue hampering its large-scale commercial deployment. Here, we report a star-shaped polymer to improve charge transport and inhibit ion migration at the perovskite interface. The incorporation of multiple chemical anchor sites in the star-shaped polymer branches strongly controls the crystallization of perovskite film with lower trap density and higher carrier mobility and thus inhibits the nonradiative recombination and reduces the charge-transport loss. Consequently, the modified inverted PSCs show an optimal power conversion efficiency of 22.1% and a very high fill factor (FF) of 0.862, corresponding to 95.4% of the Shockley-Queisser limited FF (0.904) of PSCs with a 1.59-eV bandgap. The modified devices exhibit excellent long-term operational and thermal stability at the maximum power point for 1000 hours at 45°C under continuous one-sun illumination without any significant loss of efficiency.** 

#### **INTRODUCTION** 

Hybrid organic-inorganic halide perovskites are attractive photoelectric materials exhibiting the advantages of low cost ( _1_ ) and ease in manufacturing ( _2_ ) while exhibiting strong panchromatic sunlight absorption ( _3_ ), long carrier diffusion lengths ( _4_ ), and adjustable direct bandgaps ( _5_ ). The power conversion efficiencies (PCEs) of perovskite solar cells (PSCs) achieved within only a few years have reached 25.5% ( _6_ – _9_ ) using the regular (n-i-p) structure. Unfortunately, the PCE of inverted (p-i-n) PSCs lags significantly behind that of regular structured devices. Although the open-circuit voltage ( _V_ oc), short-circuit current ( _J_ sc), and fill factor (FF) are highly correlated and synergistically affect the PCE, most researchers have principally dedicated their efforts to optimizing _V_ oc and _J_ sc rather than attempting to comprehend and optimize the FF value ( _10_ ). In most cases, the FF values of PSCs usually exhibit low values between 0.7 and 0.8, and even those devices with certified 22.7% ( _11_ ) and 23.3% ( _12_ ), PCEs show an FF value lower than 0.8. Recently, a higher FF value of 0.848 has been achieved, which likely played a determining role in reaching a 25.2% PCE ( _7_ ). 

For FF optimization, low series resistances ( _R_ s) and large shunt resistances ( _R_ sh) are usually required ( _13_ ). The _R_ s in a PSC can be determined by ohmic elements, for example, the conductive base, electron and hole transport layer (ETL and HTL, respectively), and metal back contact ( _14_ ). Increasing the conductivity and mobility of the ETL and HTL will help to improve the FF in PSCs. To improve the _R_ sh value, the leakage current caused by carrier recombination 

> 1State Key Laboratory of Solidification Processing, Center for Nano Energy Materials, School of Materials Science and Engineering, Northwestern Polytechnical University, Xi'an 710072, China.<sup>2</sup> The Key Laboratory of Space Applied Physics and Chemistry, School of Chemistry and Chemical Engineering, Northwestern Polytechnical University, Xi'an 710072, China.<sup>3</sup> Laboratory of Photonics and Interfaces, Ecole Polytechnique Fédérale de Lausanne, CH-1015 Lausanne, Switzerland.<sup>4</sup> Key Laboratory of Micro-Nano Electronic Devices and Smart Systems of Zhejiang Province, Zhejiang University, Zhejiang 310027, China.<sup>5</sup> Department of Electrical and Electronic Engineering, The University of Hong Kong, Pokfulam Road, Hong Kong. 

> *Corresponding author. Email: michael.graetzel@epfl.ch (M.G.); lixh32@nwpu. edu.cn (X.L.) †These authors contribute equally to this work. 

in the bulk and at interfaces should be minimized ( _15_ ). Among various types of recombination, defect-induced recombination plays a major role in the reduction of the FF and _V_ oc ( _16_ ). Until present, many passivation methods have been proposed to reduce the defect density, significantly boosting _R_ sh and reducing defect-induced recombination ( _17_ – _19_ ). Additives based on the Lewis acid-base theory ( _20_ , _21_ ) including solvents ( _22_ ), ionic liquids ( _23_ , _24_ ), small molecules ( _25_ – _27_ ), and polymers ( _28_ , _29_ ) are used to modify perovskite films with various functional groups. When used as additives, the high volatility and high diffusion coefficient of small molecules may make it difficult to maintain the long-term stability of PSCs under extreme conditions ( _30_ – _33_ ). For these reasons, several attempts have instead been made to use polymers as additives ( _28_ , _29_ , _34_ ). These polymers, however, generally have a one-dimensional (1D) linear structure and can only show a single passivation effect when they modify the surface of perovskite films. Few researchers directly passivate perovskite films through 3D polymers that have multiple branches and multiple functional groups on each branch. 

Here, we have designed a 3D star-shaped polyhedral oligomeric silsesquioxane-poly(trifluoroethyl methacrylate)- _b_ -poly(methyl methacrylate) (PPP) polymer as a novel modulator to regulate perovskite film crystallization (Fig. 1A). The polyhedral oligomeric silsesquioxane serving as a core in the star-shaped PPP material is surrounded by eight branches, including poly(trifluoroethyl methacrylate) and poly(methyl methacrylate) molecular chains. The core is a type of organic-inorganic intramolecular hybrid material with a highly symmetrical rigid Si─O─Si cubic cage skeleton, which can offer the PPP material 3D structure stability ( _35_ ). Poly(trifluoroethyl methacrylate) is a type of special fluoropolymer that exhibits outstanding hydrophobic and anti-adhesion properties ( _36_ ). On the PPP polymer branches, there are multiple chemical anchor sites including carbonyl (C═O) and ─CF3, which act as 3D skeleton templates to passivate defects at the grain boundaries (GBs) and interfacial surfaces, inhibit nonradiative recombination and charge-transport loss, and improve stabilities under moisture, thermal, and illumination stress. As a result, the PPP-modified inverted devices obtain an optimal 22.1% efficiency and an astoundingly high FF value of 0.862. 

**1 of 11** 

Cao _et al_ ., _Sci. Adv._ 2021; **7** : eabg0633     7 July 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 1. Interactions between the PPP polymer and perovskite.** ( **A** ) Structural formula of the PPP polymer. ( **B** ) Schematic diagram of the interaction between the PPP polymer (partial 3D structure) and perovskite, including chelation between C═O and Pb and hydrogen bonding between ─CF3 and FA<sup>+</sup> and MA<sup>+</sup> . ( **C** ) FTIR spectra of the PPP polymer, PbI2, and PPP-PbI2. ( **D** ) Fingerprint region of C═O. ( **E** and **F** ) XPS spectra of Pb 4 _f_ and N 1 _s_ in control and PPP-modified perovskite films. a.u., arbitrary units. ( **G** )<sup>1</sup> H-NMR spectra of FAI and FAI-PPP mixture. ( **H** )<sup>1</sup> H-NMR spectra of MABr and MABr-PPP mixture. 

The nonencapsulated modified device exhibits a significantly enhanced environmental stability with retaining of more than 93% of the initial efficiency after 6000 hours of exposure to ambient environment atmosphere [40% relative humidity (RH), 25°C]. The encapsulated modified device exhibits excellent operational stability with almost no change in efficiency after 1000 hours of maximum power point tracking under one-sun illumination at 45°C, as well as very good thermal stability with 91% of the initial efficiency retained under continuous one-sun illumination at 75°C for 1000 hours. 

#### **RESULTS** 

### **Structural and morphology characterizations** 

The Fourier transform infrared (FTIR) spectrum (fig. S1),<sup>1</sup> H nuclear magnetic resonance (<sup>1</sup> H-NMR) spectrum (fig. S2), and gel permeation chromatography (GPC) (fig. S3) results confirmed the structure of the as-prepared PPP polymer. The PPP polymers used as a novel additive have been introduced into the perovskite film via a chlorobenzene antisolvent. The interaction between the PPP polymer and CsMAFA (MA, methylamine cation; FA, formamidinium cation)– based perovskite is shown in Fig. 1B, which has been investigated by combining FTIR, x-ray photoelectron spectroscopy (XPS), and 

1H-NMR. First, the C═O bond of the PPP polymer chelation with noncoordinating Pb<sup>2+</sup> is observed. As shown in Fig. 1 (C and D), the stretching vibration of the C═O bond of the PPP polymer appears at 1741 cm<sup>−1</sup> and shifts to 1731 cm<sup>−1</sup> when it interacts with PbI2. The shift in the C═O stretching vibration frequency of the PPP polymer to a lower wave number arises from the electron delocalization from C═O when an intermediate PPP-PbI2 adduct is formed, which demonstrates a strong interaction between PbI2 and C═O in the PPP polymer. From the XPS spectra of the PPP-modified perovskite film (fig. S4), we detect C, O, F, and Si on the top surface, and the XPS spectra of Cs 3 _d_ , Br 3 _d_ , I 3 _d_ , and Pb 4 _f_ shift after the incorporation of the PPP polymer. This phenomenon indicates that there is an interaction between the PPP polymer and perovskite. From the Pb 4 _f_ XPS spectra (Fig. 1E), there are two main peaks at 138.4 and 143.3 eV, corresponding to Pb 4 _f_ 7/2 and Pb 4 _f_ 5/2, respectively. In addition, the two small peaks at 136.7 and 141.6 eV are ascribed to the existence of metallic Pb in the control film. The metallic Pb peaks disappear for the PPP-modified perovskite film, showing that the PPP polymer can prevent the formation of metallic Pb. 

In addition, the strong hydrogen bonding between the ─CF3 group of the PPP polymer and FA<sup>+</sup> and MA<sup>+</sup> in the perovskite film has been investigated. After the CsMAFA perovskite was modified 

**2 of 11** 

Cao _et al_ ., _Sci. Adv._ 2021; **7** : eabg0633     7 July 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

by the PPP polymer, the XPS spectra of the N 1s orbital peak obtained for the CsMAFA perovskite film show a significant deviation (Fig. 1F). Furthermore, the N─H stretching vibration in the FTIR spectra of FAI and MABr perovskites shifts to lower wave number, which indicates the interaction between the N─H of the perovskite and ─CF3 functional group in the PPP polymer (fig. S5) ( _37_ ). The 1H-NMR spectra are further used to demonstrate the existence of hydrogen bonds. The electronegativity of the fluorine atom is stronger than that of oxygen in the PPP polymer, so it is easy to associate with H atoms to form F···H hydrogen bonds. Once the perovskite film is modified with the PPP polymer, N─H···F hydrogen bonds are readily formed with N─H in FA<sup>+</sup> and MA<sup>+</sup> ( _38_ ). We compare the 1H-NMR spectra of FAI and FAI-PPP–based dimethyl sulfoxide-d6 (CD3SOCD3) and chloroform-d3 (CDCl3) mixed solvent (Fig. 1G). After adding the PPP polymer, the chemical shift () values of the H atoms in the NH2 and ═NH2+ show a clear shift. Furthermore, we also compare the<sup>1</sup> H-NMR spectra of MABr and MABr-PPP solutions. Figure 1H shows that the  value of H in NH3+ moves to the lower field direction by approximately 0.06 parts per million (ppm; from 7.63 to 7.69 ppm) after the introduction of the PPP polymer. These findings signify that the F atoms in the PPP polymer have formed a hydrogen bond with the H atoms in the NH2 and ═NH2+ of the FAI perovskite and NH3+ of the MABr perovskite. 

We now explore the effects of the PPP polymer on the morphology and quality of perovskite films. The top-view scanning electron microscopy (SEM) and cross-sectional SEM images of the control and PPP-modified films are presented in Fig. 2 (A to D). Compared to the control, the PPP-modified perovskite shows a densely packed film with a larger grain size. Figure S6 shows the corresponding grain size distribution. The average grain size of the control film is approximately 260 nm, while that of the PPP-modified perovskite film is approximately 350 nm. Moreover, the cross-sectional SEM image of the control shows an irregular vertical arrangement and obvious GBs, while the PPP-modified perovskite crystals are well arranged along the vertical direction and GBs are not readily observed. These results demonstrate that the PPP polymer promotes perovskite crystallization to obtain a high-quality film. Transmission electron microscopy (TEM) is used to further study the PPP-modified perovskite film. As shown in Fig. 2 (E and F), the perovskite material is coated with a very thin amorphous phase of PPP molecules, but a good crystal structure is attested by the exposed region. The interplanar spacing of the perovskite material is confirmed to be 0.63 nm, which corresponds to the (100) plane of the CsMAFA crystal tetragonal phase (Fig. 2F). The 3D structure of the PPP polymer can bridge grains and constitute 3D skeleton templates to immobilize perovskite grains. The x-ray diffraction (XRD) patterns illustrate that the PPP molecules 



**Fig. 2. Morphology and structural properties of perovskite films.** ( **A** and **B** ) Top-view SEM images of the control and PPP-modified perovskite films. ( **C** and **D** ) Crosssectional SEM images of the control and PPP-modified perovskite films. ( **E** ) High-resolution TEM image of PPP-modified perovskite crystals. ( **F** ) Enlarged TEM image of the red box in (E). ( **G** ) XRD patterns of the control and PPP-modified perovskite films. 

**3 of 11** 

Cao _et al_ ., _Sci. Adv._ 2021; **7** : eabg0633     7 July 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

are not incorporated into the perovskite crystal lattice. The full width at half maximum of the (100) peak of the PPP-modified perovskite film is smaller than that of the control (fig. S7). Compared to the control, the PPP-modified film shows stronger intensities of the CsMAFA crystal but a weaker intensity of the PbI2 peaks in the XRD pattern, suggesting a larger grain size and higher crystallinity (Fig. 2G). In the PPP-modified perovskite films, enhanced absorption is also observed, which is attributed to increased crystallinity (fig. S8). Because the 3D PPP polymer branches have multiple chemical anchor sites including C═O and ─CF3, the strong interaction of the C═O bond of the PPP polymer with PbI2 and the hydrogen bonding interaction between the PPP polymer and FA<sup>+</sup> and MA<sup>+</sup> reduce the content of unreacted PbI2, regulating the morphology and thereby improving the quality of the perovskite film. We also combined scanning TEM imaging, energy-dispersive x-ray mapping (fig. S9), and time-of-flight secondary ion mass spectroscopy (ToF-SIMS) depth profile (fig. S10) to prove that PPP polymers are distributed in the bulk of the perovskite film. 

### **Photovoltaic performances** 

We characterized the photovoltaic performance of the control and the PPP-modified devices using the inverted device structure ITO/NiO _x_ (20 nm)/pristine perovskite or PPP-modified perovskite (750 nm)/ PCBM+C60 (45 nm)/BCP (10 nm)/Cr (5 nm)/Au (100 nm) (where ITO represents indium tin oxide, PCBM represents [6,6]-phenylC61-butyric acid methyl ester, and BCP represents 2,9-dimethyl-4,7diphenyl-1,10-phenanthroline; Fig. 3A). Statistical distributions, optimum current density-voltage ( _J-V_ ) curves, and photovoltaic parameters of PSCs as a function of PPP concentration are presented in figs. S11 and S12 and table S1. The highest PCE of the control device is 18.62% (18.08%), with a _V_ oc value of 1.082 (1.078) V, a _J_ sc value of 22.32 (22.20) mA cm<sup>−2</sup> , and a FF value of 0.770 (0.755), as obtained from the reverse (forward) scan. The optimal concentration of the PPP polymer is 0.1 mg ml<sup>−1</sup> . The PCE of the PPP-modified device increased to 22.11% (21.91%), with a _V_ oc value of 1.131 (1.131) V, a _J_ sc value of 23.24 (23.14) mA cm<sup>−2</sup> , and a FF value of 0.841 (0.837), obtained from the reverse (forward) scan (Fig. 3B and Table 1) with 



**Fig. 3. Photovoltaic performance.** ( **A** ) Device architecture of the PPP-modified PSCs. ( **B** ) Champion _J-V_ curves obtained in forward and reverse scans of the control and PPP-modified devices. ( **C** ) Stabilized photocurrent and SPO at 0.91 and 0.97 V for the control and PPP-modified devices, respectively. ( **D** ) EQE spectra and integrated current of the control and PPP-modified devices. ( **E** ) PCE histogram of 20 PSCs of the control and PPP-modified devices. ( **F** ) Collection of FFs versus PCEs, reported for inverted PSCs. 

**4 of 11** 

Cao _et al_ ., _Sci. Adv._ 2021; **7** : eabg0633     7 July 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

**Table 1. Champion photovoltaic parameters of the inverted PSCs measured in different scan directions under standard AM 1.5 illumination (100 mW cm**<sup>**−2**</sup> **).** 

|**Device**|**Scanning direction**|**_V_oc (V)**|**_J_sc (mA cm**<sup>**−2**</sup>**)**|**FF**|**PCE (%)**|**Hysteresis factor***|
|---|---|---|---|---|---|---|
|Control|Forward|1.078|22.20|0.755|18.08|2.90|
||Reverse|1.082|22.32|0.770|18.62||
|PPP-modified|Forward|1.131|23.14|0.837|21.91|0.90|
||Reverse|1.131|23.24|0.841|22.11||



───────────── * Hysteresis factor =<sup>PCE reverse −  PCE forward</sup> PCE reverse 

a scan rate of 0.05 V s<sup>−1</sup> . We calculate the hysteresis factors for the control and PPP-modified devices to be 2.9 and 0.9%, respectively, which show that the PPP-modified device exhibits a very small hysteresis. We also measured the device PCE at other scan rates including 0.25 and 0.01 V s<sup>−1</sup> (fig. S13 and table S2). The PPP-modified device still exhibits negligible hysteresis. Moreover, the PPP-modified device shows higher and more rapidly rising photocurrents than the control device. The steady-state power output (SPO) stabilizes at approximately 22.03% (Fig. 3C). The _J_ sc values derived from integrating the external quantum efficiency (EQE) spectra over the standard global AM 1.5 solar emission are 21.66 and 22.78 mA cm<sup>−2</sup> for the control and PPP-modified device, respectively, which agree with the _J_ sc values measured from the _J-V_ curve (Fig. 3D). The histogram of the PCE with 20 PPP-modified PSCs shows excellent reproducibility, which confirms that incorporating PPP improves the performance of PSCs (Fig. 3E). One of the devices based on PPP-modified PSCs with negligible hysteresis achieves a notably high FF value of 0.862 (see fig. S14), which approaches the Shockley-Queisser (S-Q) limit of 0.904 V for a PSC with 1.59 eV bandgap ( _39_ ). Both the 22.1% PCE and 0.86 FF are among the highest values recorded for inverted PSCs (Fig. 3F and table S3) ( _8_ , _24_ , _40_ – _50_ ). We also introduce the PPP polymer into other perovskite components such as MAPbI3, MA0.5FA0.5PbI3. The PPP-modified devices also show improved PCE and high FF (fig. S15), indicating that the incorporation of star-shaped polymer into perovskite is an effective and universal strategy. 

### **Origin of the improved performance and device physics** 

We tested the steady-state photoluminescence (SSPL) and time- resolved photoluminescence (TRPL) to analyze the carrier recombination dynamics as presented in Fig. 4 (A and B) and listed the corresponding data in Table 2. The SSPL intensity of the PPP-modified perovskite film exhibits an obvious enhancement compared to that of the control. Concurrently, the PL peak position of the PPP-modified film displays a blue shift from 780 (control device) to 775 nm. These results provide strong evidence that the PPP molecules can effectively mitigate the trap density and act to passivate GBs and surface defects, due to their strong interaction with perovskite as supported by the XPS and FTIR results. We further investigated the origin of the improved photovoltaic performance by performing TRPL measurements to study the carrier transport and recombination at the perov skite layer (Fig. 4B). To evaluate the TRPL data, we applied a kinetic model described in our previous study ( _51_ ). For both films, we observe two features: a rapid decay within the first 50 ns followed by an almost monoexponentially slower decay. The 

fast decay at early times has been attributed to initial carrier trapping, whereas hole transfer, the following slower decay, is caused by nonradiative recombination ( _51_ ). Considering bulk recombination, we derive for the target device a first-order rate constant for nonradiative carrier recombination of _k_ 1 = 5.3 × 10<sup>5</sup> s<sup>−1</sup> corresponding to a lifetime of  = 941.7 ns, while the respective values for the control film are _k_ 1 = 1.61 × 10<sup>6</sup> s<sup>−1</sup> and  = 310.8 ns. This indicates that the PPP modification of the perovskite film suppresses nonradiative carrier recombination, thus improving the photovoltaic metrics. Note, however, that surface recombination of charge carriers also yields a first-order rate law ( _51_ ), rendering it difficult to distinguish between surface and bulk recombination by this kinetic analysis. 

To quantitatively investigate the PPP polymer passivation effects in perovskites, we characterize the trap density and carrier mobility by measuring the space charge–limited current. The PPP-modified devices show lower electron and hole trap densities than the control devices, which most likely results from the passivation effect of the surface or interface defects by the PPP polymer (Table 2 and fig. S16). The calculated electron mobility of the PPP-modified device is increased to 14.76 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> compared with that of the control device (1.69 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ). The hole mobility also increases from 4.16 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> for the control device to 15.94 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> for the PPP-modified device. Moreover, Mott-Schottky analyses were undertaken to evaluate the built-in potential ( _V_ bi) (Fig. 4C). The value of _V_ bi of the PPP-modified PSC determined is 1.10 V, which is larger than that of the control device (0.85 V). Thus, the PPP-modified device shows higher carrier mobility, more balanced carrier transportation, and a higher _V_ bi value, demonstrating the substantial benefits from modifying perovskite by PPP. 

We further determined the effect of PPP on the ideality factor of our PSCs. The carrier recombination mechanism can be investigated by studying the current and voltage dependencies under different light intensities for the control and PPP-modified devices (fig. S17). The slope of the _k_ B _T_ / _q_ unit determines whether _V_ oc loss is predominated by trapinduced nonradiative recombination (where _k_ B is the Boltzmann constant, _T_ is the thermodynamic temperature, and _q_ is the electron charge). The slope of _V_ oc versus light intensity reduces from 1.31 _k_ B _T_ / _q_ (control) to 1.08 _k_ B _T_ / _q_ (PPP-modified), suggesting a reduction of trap-induced recombination under open-circuit conditions. Because of the power law _J_ sc ∝ _I_<sup></sup> (where  is an exponential factor and _I_ is the light intensity), the dependence of _J_ sc on light intensity can be identified. The calculated  values are 0.957 and 0.998 for the control and PPP-modified PSCs, respectively, illustrating a slight decrease in bimolecular recombination under short-circuit conditions. 

**5 of 11** 

Cao _et al_ ., _Sci. Adv._ 2021; **7** : eabg0633     7 July 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 4. Effects of PPP modification on the electrical effects of perovskite films.** ( **A** ) SSPL and ( **B** ) TRPL spectra of the control and PPP-modified perovskite films. ( **C** ) 1/C<sup>2</sup> versus applied voltage plots (Mott-Schottky) in the control and PPP-modified PSCs. ( **D** ) _V_ oc plotted against the logarithm of _J_ sc in the device. ( **E** ) Dark _J-V_ curves of the control and PPP-modified PSCs. ( **F** ) The device FF S-Q limit consists of charge-transport loss (blue area) and nonradiative loss (pink area). The deep yellow and olive green circles represent the measured FF and the maximum FF without charge-transport loss, respectively. 



<!-- Start of picture text -->
n ID is quantized from the slope of  is quantized from the slope of  of current leakage induced by surface defects (the  R s and  R sh values<br>) plot based on Eq. 1 are obtained from the  V oc/ J sc ratio and the dark  J-V  curve). Further-<br>more, nonradiative carrier recombination and charge-transport<br>─ ─ losses are the two main reasons reducing the FF value below the S-Q<br>V oc =   n ID k B T (1)<br>q ln ( J J sc 0 ) limit ( 52 ). Neglecting charge-transport losses, we derive the maxi-<br>mum FF value (FFmax) from Eq. 2 ( 53 )<br><!-- End of picture text -->

Furthermore, the ideality factor _n_ ID is quantized from the slope of  is quantized from the slope of the _V_ oc versus lg ( _J_ sc) plot based on Eq. 1 

where _J_ 0 is the saturation current density at reverse bias. The calculated _n_ ID value of the control device is 1.37. The calculated _n_ ID value of the PPP-modified device decreased significantly to 1.08 (Fig. 4D). This value is very low, indicating that the trap-induced recombination is significantly suppressed. 



<!-- Start of picture text -->
 FF max =  ___________ v  oc − ln (  v  oc + 0.72 ) with   v oc =  _ qV  oc  (2)<br>v  oc + 1 n  ID   k B T<br><!-- End of picture text -->



<!-- Start of picture text -->
─<br> FF s =  FF max (1 − 1.1   r s ) +   r s2 (3)<br>5.4<br><!-- End of picture text -->

We also study the energy band structure of the PPP-modified PSC (figs. S18 and S19). The calculated _E_ F values of the control and PPP-modified devices are 4.61 and 4.49 eV, respectively. A significant upshift in the _E_ F level of the PPP-modified film in devices attests to its enhanced properties as an n-type film ( _8_ ). The more the properties of a perovskite film approach n-type, the more substantially the electron traps are filled, which can result in a further reduction in the reorganization events caused by the traps. As a result, the PPP-modified perovskite layer has a better band alignment with the ETL and HTL, which is beneficial toward _V_ oc improvement, _R_ s decrease, and charge transfer. 



<!-- Start of picture text -->
_ _<br> FF =  FF s( 1 −   v  oc  v +  oc 0.72 FF r  sh  s ) (4)<br><!-- End of picture text -->

where _r_ s and _r_ sh are the normalized resistances, given by _r_ s = _J_ sc _R_ s/ _V_ oc and _r_ sh = _J_ sc _R_ sh/ _V_ oc, respectively. As shown in Fig. 4F, FFmax values are 0.859 and 0.886 for the control and PPP-modified devices, respectively. The nonradiative loss for the PPP-modified device is suppressed because the PPP polymer passivates defects in the perovskite film. If both the nonradiative loss and charge-transport loss are considered, the empirical Eqs. 3 and 4 should be adopted ( _15_ ), and we calculate that the FF values of the control and PPP-modified devices are 0.730 and 0.858, respectively. The calculated FF value agrees with the measured FF value, the difference being less than 6%. Compared to the control device, the charge-transport loss in the PPP-modified device is also clearly reduced owing to the increased carrier mobility, as shown above. These results confirmed that the 3D PPP polymer not only inhibits nonradiative recombination but also improves charge transport in the device. 

To explain the improvement in FF, we measure the dark current curve because the FF is a parameter that is strongly influenced by resistance losses (Fig. 4E). The reverse saturation current and turnon voltage of the PPP-modified device are reduced compared with that of the control device. The _R_ s value for the PPP-modified device decreases from 6.31 (control device) to 1.30 ohm·cm<sup>2</sup> , which we attribute to the improved quality of the perovskite film and better band alignment of the device. On the other hand, the _R_ sh values for the PPP-modified and control device are 15,220 and 3003 ohm·cm<sup>2</sup> , respectively. The increase in _R_ sh value is mainly due to the inhibition 

**6 of 11** 

Cao _et al_ ., _Sci. Adv._ 2021; **7** : eabg0633     7 July 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

**Table 2. Comparison of electrical parameters.** The trap density and charge carrier mobilities obtained for electron-only and hole-only devices with control and PPP-modified PSCs and series resistance ( _R_ s), shunt resistance ( _R_ sh), ideality factor ( _n_ ID), and nonradiative carrier recombination lifetime () for the control and PPP-modified PSCs. 

|**Device**|**Trap dens**<br>**Electron**|**ity (cm**<sup>**−3**</sup>**)**<br>**Hole**|**Mobility (c**<br>**Electron**|**m**<sup>**2**</sup>**V**<sup>**−1**</sup>**s**<sup>**−1**</sup>**)**<br>**Hole**|**h/e**|**_R_s**<br>**(ohm·cm**<sup>**2**</sup>**)**|**_R_sh**<br>**(ohm·cm**<sup>**2**</sup>**)**|**_n_ID**|** (ns)**|
|---|---|---|---|---|---|---|---|---|---|
|Control|1.32 × 10<sup>16</sup>|4.85 × 10<sup>15</sup>|1.69|4.16|2.46|6.31|3,003|1.37|310.8|
|PPP-modified|3.87 × 10<sup>15</sup>|3.70 × 10<sup>15</sup>|14.76|15.94|1.08|1.30|15,220|1.08|941.7|



### **Enhanced device stability** 

First, we study the environmental stability of the device. The control perovskite film shows an enhanced degradation compared with the PPP-modified perovskite film after aging for 240 hours at 85°C and 40% ambient RH (figs. S20 and S21). The presence of GBs is the main source of perovskite film decomposition in humid environment since moisture penetrates the perovskite crystal through the GBs, accelerating its destruction ( _31_ ). The enhanced environmental stability can be attributed to the increased hydrophobicity of the perovskite film surface after the introduction of the PPP polymer (fig. S22). We also study the long-term stability of PSCs without encapsulation. When the device is stored in a 40% RH air environment for 6000 hours, the normalized PCE of the modified device is stable at exhibiting approximately 93% of its original value while the control device declines to ~73% of its original PCE (Fig. 5A). The relatively stable PCE of the PPP-modified perovskite film indicates that it has fewer internal defects than the control device’s film, mainly due to the protection of the perovskite crystals by the naturally hydrophobic PPP polymer that form a core-shell structure (Fig. 2E), providing a strong resistance to humidity. 

The PPP passivation treatment also improves the photo-, thermal, and operational stability of the PSCs. The long-term operational stability of the encapsulated CsMAFA-based PSCs with and without PPP incorporation was investigated with maximum power point tracking under one-sun illumination (45°C, in air, 100 mW/cm<sup>2</sup> ) as depicted in Fig. 5B. The SPO of the control device only retains ~36% after 500 hours of operation, while the SPO of the PPP-modified device is almost unchanged after continuous operation for 1000 hours. In addition, the PCE evaluation of encapsulated devices aged under one-sun illumination at 75°C has been recorded and is exhibited in Fig. 5C. The control device with Cr interlayer maintains approximately 71% of the initial PCE for 1000 hours, whereas the control device without Cr interlayer retains only approximately 30% for 500 hours. Thus, the result demonstrates that the Cr interlayer has a positive effect on the long-term stability. Cr effectively shields gold electrode contact from detrimental reactions with oxidizing and halide-forming iodide species ( _54_ ). When there is a Cr interlayer, the rate of reduction in stability witnessed under such harsh conditions is much slower for the PPP-modified device in comparison to the control device. Specific points of data are shown in fig. S23 for the most stable and highest PCE device. The PPP-modified device impressively maintains 91% of its initial efficiency of ~22% after 1000 hours, whereas the control device retains only 71% of its initial efficiency of ~18%. Our PPP-modified PSC compares favorably with other reported results (table S4). When there is no Cr interlayer, the PPP-modified device still maintains 85% of its initial efficiency after 1000 hours. 

To unveil the mechanism of the enhanced stability, we monitor the depth profiles of several key species in the control and PPP-modified 



**Fig. 5. Stability.** ( **A** ) Air stability for the nonencapsulated control and PPP-modified devices (the average PCE is obtained from 10 devices of each type of device, and the error bars represent the SD of the devices). ( **B** ) Maximum power point (MPP) tracking of encapsulated PSCs with and without PPP-modified in air under one-sun illumination at 45°C. ( **C** ) Thermal stability of encapsulated control and PPP-modified devices. The devices were illuminated under full-spectrum sunlight (no UV filter) at 75°C in air under open-circuit conditions, and their output photovoltaic power was determined by recording _J-V_ curves at regular time intervals. The plotted data points present averages for the 10 cells. ToF-SIMS depth profiles of ( **D** ) control and ( **E** ) PPP-modified electrodeless PSC devices before (solid line) and after (short dashed line) thermal aging at 75°C and full-spectrum sunlight for 300 hours in the N2 atmosphere. 

**7 of 11** 

Cao _et al_ ., _Sci. Adv._ 2021; **7** : eabg0633     7 July 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

devices before and after thermal aging at 75°C and full-spectrum sunlight for 300 hours under a N2 atmosphere by ToF-SIMS (Fig. 5, D and E) ( _55_ , _56_ ). C60− is selected for following the evolution of the PCBM+C60 ETL, CN<sup>−</sup> as representing the MA<sup>+</sup> and FA<sup>+</sup> ; CN2H4I<sup>−</sup> as representing the FAI, I<sup>−</sup> , PbI2−, and Br− for the CsMAFA perovskite; 18O− and F− for the PPP polymer; NiO2− for the NiO _x_ ; and InO2− for the ITO. Figure 5D shows that the diffusion of CN<sup>−</sup> , CN2H4I<sup>−</sup> , I<sup>−</sup> , PbI2−, and Br<sup>−</sup> found in the perovskite to the NiO _x_ HTL is obvious after aging of the control electrodeless PSC device, resulting in the rapid decomposition of the perovskite. In contrast, the outward diffusion of I<sup>−</sup> and Br<sup>−</sup> ion and all ionic groups from the perovskite is largely reduced for the PPP-modified electrodeless PSC device (Fig. 5E). The strong hydrogen bonding of F···H─N between the ─CF3 radical of the PPP polymer and FA<sup>+</sup> and MA<sup>+</sup> can restrain FA<sup>+</sup> and MA<sup>+</sup> , and the C═O of the PPP polymer has strong chelation with Pb to immobilize Pb ion or ionic groups; thus, the PPP-modified device exhibits a better shielding effect compared with the control device. In addition, the thermogravimetric analysis (TGA) also manifests that the PPP-modified perovskite has a better thermal stability than the control perovskite (fig. S24). Thus, the PPP polymer inhibits ion migration in the perovskite film and thus improves the long-term illumination and thermal stability of PSCs. 

#### **DISCUSSION** 

In summary, a 3D star-shaped multifunctional PPP polymer has been designed to modify the perovskite film used in an inverted PSC device. The PPP molecule acts as a 3D skeleton template to control crystallization and to passivate defects at GBs and the surface, as well as to reduce nonradiative recombination, charge-transport losses, and ion migration. Consequently, the PPP-modified inverted PSC obtains an optimal 22.1% efficiency and a very high FF value of 0.862. We also used a modified detailed balance model ( _57_ ) to confirm that the loss of FF (0.862) in the PPP-modified device with reference to its S-Q limit (0.904) is predominantly caused by the defect- induced recombination rather than by _R_ s and _R_ sh (as detailed in fig. S25 and table S5). If nonradiative carrier recombination was controlled by the Shockley-ReadHall bulk mechanism, the dominating factor _V_ oc that drops from its S-Q limiting value of 1.32 V to the observed values of 1.10 V would correspond to an FF value of 0.820, which is below the measured value of 0.862. Consequently, surface recombination is likely to be the dominant recombination mechanism in the PPP-modified device. Thus, it appears feasible to further boost the FF close to its S-Q limit of 0.904 by passivating defects in interfaces. Regarding the stability, the modified device exhibits a significant enhancement in ambient air, retaining more than 93% of its initial efficiency after 6000 hours of exposure to air with 40% RH. The encapsulated device with PPP modification likewise exhibits a remarkable improvement of the operational and thermal stability, operating at maximum power point for 1000 hours under continuous one-sun illumination at 45°C, without efficiency loss. Thus, introducing the star-shaped and plurifunctional molecule in the perovskite films greatly improves its performance in particular in inverted PSC configuration, opening a new direction for advancements in the practical deployment of these solar cells. 

#### **MATERIALS AND METHODS** 

### **Materials** 

Nickel nitrate hexahydrate [Ni(NO3)2·6H2O, 99.999%], chlorobenzene (CB; 99.8%), anhydrous dimethyl sulfoxide (DMSO; 99.8%), and 

_N_ , _N_ -dimethylformamide (DMF; 99.8%) were purchased from SigmaAldrich. All photovoltaic materials were purchased from Xi’an Polymer Light Technology Corp. and did not require further purification. 3-Chloropropyltrimethoxysilane, pentamethyldiethylenetriamine (PMDETA), trifluoroethyl methacrylate (TFEMA), methyl methacrylate (MMA), and copper (I) chloride (CuCl) were purchased from Aladdin. 

### **Materials synthesis** 

The synthesis process of the PPP polymer [weight-average molecular weight (Mw ≈ 1.47 × 10<sup>5</sup> )] was divided into two steps. (i) For the synthesis of octa(-chloropropyl) silsesquioxane [POSS-(Cl)8], concentrated hydrochloric acid (8 ml), 3-chloropropyltrimethoxysilane (10 ml), and methanol (200 ml) were mixed in a 500-ml roundbottomed flask and then quickly stirred for 5 days in a 40°C oil bath to complete hydrolysis. The obtained product was washed multiple times with methanol and dried under vacuum to yield a white powder. (ii) For the synthesis of PPP polymer, the synthesis procedures were carried out using POSS-(Cl)8 as radical initiator in a one-pot, two-step atom transfer radical polymerization process. In this process, the flask was continuously flowed with dry N2 to remove O2. Then, POSS-(Cl)8 (0.20 g), toluene (20 ml), TFEMA (20 ml), PMDETA (0.12 ml), and CuCl (0.02 g) were mixed in the flask. The flask was put into an oil bath equipped with magnetic stirring bar at 110°C. After the reaction proceeded for 24 hours, the same volume of the MMA monomer was added into the flask, and the reaction was continued for 24 hours. After 48 hours, the flask was cooled in ice water to terminate the polymerization reaction. The mixture was then poured into tetrahydrofuran for dilution, filtered through an alumina column to remove the catalyst, and then poured into a tenfold methanolwater mixed solvent. After being filtered and dried under a reduced pressure at 50°C for 12 hours, the final product PPP polymer was obtained. The synthesis process of this molecule is not complicated and can be prepared on a large scale. Nickel oxide nanoparticles were synthesized according to a previous method ( _58_ ). The CsMAFA triple-cation perovskite precursor solution was prepared by mixing lead iodide (PbI2; 1.30 M), cesium iodide (CsI; 0.07 M), lead bromide (PbBr2; 0.21 M), methylammonium bromide (MABr; 0.21 M), and formamidine iodide (FAI; 1.19 M) in a mixed anhydrous solvent of DMF/DMSO (4/1, v/v) and was stirred overnight ( _59_ ). **Inverted solar cell fabrication (p-i-n)** 

ITO glasses were washed twice with ethanol in an ultrasonic bath for 15 min. NiO _x_ (20 mg ml<sup>−1</sup> in H2O) was spin-coated on dry and ultraviolet (UV)–treated ITO at 2000 rpm for 40 s and then heated at 100°C for 10 min. The thickness of the NiO _x_ film was approximately 20 nm. The coated ITO was then moved to a glove box. The perovskite solution was spin-coated on the NiO _x_ HTL according to a procedure where the spin-coating speed and duration were increased from 1000 rpm for 10 s to 6000 rpm for 30 s. A total of 110 l of the PPP polymer with various concentrations (0, 0.04, 0.1, 0.6, and 1.0 mg ml<sup>−1</sup> ) of the CB antisolvent was deposited for 15 s before the end of the procedure, and then the perovskite solution was annealed at 100°C for 20 min to obtain the bright perovskite film with a thickness of 750 nm. After that, 20 mg of PCBM (99% purity) and 5 mg of fullerene (C60, 99.5% purity) were dissolved in 1 ml of CB and spin-coated on the perovskite film at 3000 rpm for 30 s, and then the ETL films were annealed on a 60°C heating stage for 10 min. The thickness of the 

**8 of 11** 

Cao _et al_ ., _Sci. Adv._ 2021; **7** : eabg0633     7 July 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

ETL is approximately 45 nm. After cooling to room temperature, the BCP solution (0.5 mg ml<sup>−1</sup> in isopropanol) was spin-coated at 5800 rpm for 30 s. Last, the fabrication of the devices was accomplished by thermally evaporating chromium (Cr; 5 nm) and gold (Au; 100 nm) electrodes under a vacuum of 2 × 10<sup>−6</sup> mbar (0.1 cm<sup>2</sup> effective area). 

### **Solar cell characterization** 

The contact angles were obtained by a DSA100 instrument (KRUSS, Germany). The SEM images of the perovskite films and cross-sectional devices were obtained using a FEI Helios G4 CX system. The TEM images were obtained with a FEI Talos F200X microscope operated with a 200-kV electron gun. The XRD patterns of the perovskite films were gained by Cu K radiation from a PANAlyticalX’pert PRO diffractometer equipped with a diffracted beam monochromator. The XPS measurements were performed on a Kratos Axis Supra spectrometer. The ultraviolet photoelectron spectroscopy (UPS) of the perovskite films was obtained by a Shimadzu Kratos photoelectron spectrometer with a nonmonochromatic He I photon source ( _h_  = 21.22 eV). The _J-V_ curves of the PSCs were obtained under AM 1.5 G (100 mW cm<sup>−2</sup> ) solar illumination with a Newport solar simulator, and the scan rate corresponding to the curve was 0.05 V s<sup>−1</sup> . The EQE was obtained with a Newport system (1600 W) using monochromatic incident light in director current mode ( _60_ ). The SSPL and TRPL spectra were obtained by an Edinburgh Instruments FLS980 fluorescence spectrometer. The absorption of the thin films was obtained using a PerkinElmer Lambda 35 UV-vis spectrophotometer. Mott-Schottky analyses were carried out on an electrochemical workstation (Chenhua 760) in a voltage range of 0 to 1.5 V under dark conditions. The FTIR spectra were measured on a Jasco FTIR-6100 spectrometer in a wavelength range of 4000 to 650 cm<sup>−1</sup> . The<sup>1</sup> H-NMR measurements were performed by a Bruker AVANCE-300 instrument. TGA was performed by a METTLER TGA/DSC 3<sup>+</sup> analyzer. GPC was performed with a Waters 1515 system, and the selected solvent was tetrahydrofuran. The ToF- SIMS was measured by a ToF-SIMS 5-100 instrument (ION-TOF GmbH, Germany). The depth profiling was obtained through a 10-keV Ar-cluster sputtering beam raster of 300 m by 300 m area. 

### **Stability test** 

The moisture stability measurements of the pristine and PPP-modified perovskite films were performed at 40% RH and 85°C. The moisture stability measurements of the nonencapsulated solar cells were implemented in 40% RH and 25°C under dark condition. The PCEs of the devices were periodically obtained under AM 1.5 G simulated sunlight illumination in ambient air. The complete PSCs could be encapsulated in a N2 glove box with a cover glass and UV adhesive (LT-U001, Lumtec). The operational stability of the encapsulated cells was measured at 45°C under a white light-emitting diode lamp with a 16-channel, thin-film photovoltaic maximum power point tracking test system (YH-VMPP-16). The photo- and thermal stability of the encapsulated devices were measured by using the Newport solar simulator under open-circuit conditions. The UV filter was not used during the aging process. For _J-V_ characterization, the devices were taken out of the aging chamber and then cooled and tested at different time intervals. 

### **SUPPLEMENTARY MATERIALS** 

Supplementary material for this article is available at http://advances.sciencemag.org/cgi/ content/full/7/28/eabg0633/DC1 

### **REFERENCES AND NOTES** 

1. X. Li, F. Zhang, H. He, J. J. Berry, K. Zhu, T. Xu, On-device lead sequestration for perovskite solar cells. _Nature_ **578** , 555–558 (2020). 

2. M. Yang, Z. Li, M. O. Reese, O. G. Reid, D. H. Kim, S. Siol, T. R. Klein, Y. Yan, J. J. Berry, M. F. A. M. van Hest, K. Zhu, Perovskite ink with wide processing window for scalable high-efficiency solar cells. _Nat. Energy_ **2** , 17038 (2017). 

3. J. Burschka, N. Pellet, S. J. Moon, R. Humphry-Baker, P. Gao, M. K. Nazeeruddin, M. Grätzel, Sequential deposition as a route to high-performance perovskite-sensitized solar cells. _Nature_ **499** , 316–319 (2013). 

4. Q. Dong, Y. Fang, Y. Shao, P. Mulligan, J. Qiu, L. Cao, J. Huang, Electron-hole diffusion lengths & >175 m in solution-grown CH3NH3PbI3 single crystals. _Science_ **347** , 967–970 (2015). 

5. T. Niu, J. Lu, R. Munir, J. Li, D. Barrit, X. Zhang, H. Hu, Z. Yang, A. Amassian, K. Zhao, S. F. Liu, Stable high-performance perovskite solar cells via grain boundary passivation. _Adv. Mater._ **30** , 1706576 (2018). 

6. Best Research Cell Efficiency Records, _Nation Renewable Energy Laboratory (NREL)_ (2021); www.nrel.gov/pv/cell-efficiency.html. 

7. J. J. Yoo, G. Seo, M. R. Chua, T. G. Park, Y. Lu, F. Rotermund, Y.-K. Kim, C. S. Moon, N. J. Jeon, J.-P. Correa-Baena, V. Bulović, S. S. Shin, M. G. Bawendi, J. Seo, Efficient perovskite solar cells via improved carrier management. _Nature_ **590** , 587–593 (2021). 

8. X. Zheng, Y. Hou, C. Bao, J. Yin, F. Yuan, Z. Huang, K. Song, J. Liu, J. Troughton, N. Gasparini, C. Zhou, Y. Lin, D.-J. Xue, B. Chen, A. K. Johnston, N. Wei, M. N. Hedhili, M. Wei, A. Y. Alsalloum, P. Maity, B. Turedi, C. Yang, D. Baran, T. D. Anthopoulos, Y. Han, Z.-H. Lu, O. F. Mohammed, F. Gao, E. H. Sargent, O. M. Bakr, Managing grains and interfaces via ligand anchoring enables 22.3%-efficiency inverted perovskite solar cells. _Nat. Energy_ **5** , 131–140 (2020). 

9. H. Min, M. Kim, S.-U. Lee, H. Kim, G. Kim, K. Choi, J. H. Lee, S. I. Seok, Efficient, stable solar cells by using inherent bandgap of -phase formamidinium lead iodide. _Science_ **366** , 749–753 (2019). 

10. P. Schulz, D. Cahen, A. Kahn, Halide perovskites: Is it all about the interfaces? _Chem. Rev._ **119** , 3349–3417 (2019). 

11. E. H. Jung, N. J. Jeon, E. Y. Park, C. S. Moon, T. J. Shin, T.-Y. Yang, J. H. Noh, J. Seo, Efficient, stable and scalable perovskite solar cells using poly(3-hexylthiophene). _Nature_ **567** , 511–515 (2019). 

12. Q. Jiang, Y. Zhao, X. Zhang, X. Yang, Y. Chen, Z. Chu, Q. Ye, X. Li, Z. Yin, J. You, Surface passivation of perovskite film for efficient solar cells. _Nat. Photonics_ **13** , 460–466 (2019). 

13. B. Qi, J. Wang, Fill factor in organic solar cells. _Phys. Chem. Chem. Phys._ **15** , 8972–8982 (2013). 

14. N. Mundhaas, Z. J. Yu, K. A. Bush, H.-P. Wang, J. Häusele, S. Kavadiya, M. D. McGehee, Z. C. Holman, Series resistance measurements of perovskite solar cells using _Jsc_ – _Voc_ measurements. _Sol. RRL_ **3** , 1800378 (2019). 

15. H. D. Kim, H. Ohkita, Potential improvement in fill factor of lead-halide perovskite solar cells. _Sol. RRL_ **1** , 1700027 (2017). 

16. D. Luo, R. Su, W. Zhang, Q. Gong, R. Zhu, Minimizing non-radiative recombination losses in perovskite solar cells. _Nat. Rev. Mater._ **5** , 44–60 (2020). 

17. H. Zhang, M. K. Nazeeruddin, W. C. H. Choy, Perovskite photovoltaics: The significant role of ligands in film formation, passivation, and stability. _Adv. Mater._ **31** , 1805702 (2019). 

18. Y. Bai, X. Meng, S. Yang, Interface engineering for highly efficient and stable planar p-i-n perovskite solar cells. _Adv. Energy Mater._ **8** , 1701883 (2018). 

19. F. Gao, Y. Zhao, X. Zhang, J. You, Recent progresses on defect passivation toward efficient perovskite solar cells. _Adv. Energy Mater._ **10** , 1902650 (2020). 

20. S. Liu, Y. Guan, Y. Sheng, Y. Hu, Y. Rong, A. Mei, H. Han, A review on additives for halide perovskite solar cells. _Adv. Energy Mater._ **10** , 1902492 (2020). 

21. F. Zhang, K. Zhu, Additive engineering for efficient and stable perovskite solar cells. _Adv. Energy Mater._ **10** , 1902579 (2020). 

22. J. W. Lee, Z. Dai, C. Lee, H. M. Lee, T. H. Han, N. De Marco, O. Lin, C. S. Choi, B. Dunn, J. Koh, D. Di Carlo, J. H. Ko, H. D. Maynard, Y. Yang, Tuning molecular interactions for highly reproducible and efficient formamidinium perovskite solar cells via adduct approach. _J. Am. Chem. Soc._ **140** , 6317–6324 (2018). 

23. Y.-H. Lin, N. Sakai, P. Da, J. Wu, H. C. Sansom, A. J. Ramadan, S. Mahesh, J. Liu, R. D. J. Oliver, J. Lim, L. Aspitarte, K. Sharma, P. K. Madhu, A. B. Morales-Vilches, P. K. Nayak, S. Bai, F. Gao, C. R. M. Grovenor, M. B. Johnston, J. G. Labram, J. R. Durrant, J. M. Ball, B. Wenger, B. Stannowski, H. J. Snaith, A piperidinium salt stabilizes efficient metal-halide perovskite solar cells. _Science_ **369** , 96–102 (2020). 

24. S. Bai, P. Da, C. Li, Z. Wang, Z. Yuan, F. Fu, M. Kawecki, X. Liu, N. Sakai, J. T.-W. Wang, S. Huettner, S. Buecheler, M. Fahlman, F. Gao, H. J. Snaith, Planar perovskite solar cells with long-term stability using ionic liquid additives. _Nature_ **571** , 245–250 (2019). 

25. N. K. Noel, A. Abate, S. D. Stranks, E. S. Parrott, V. M. Burlakov, A. Goriely, H. J. Snaith, Enhanced photoluminescence and solar cell performance via lewis base passivation of organic–inorganic lead halide perovskites. _ACS Nano_ **8** , 9815–9821 (2014). 

**9 of 11** 

Cao _et al_ ., _Sci. Adv._ 2021; **7** : eabg0633     7 July 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

26. R. Wang, J. Xue, L. Meng, J.-W. Lee, Z. Zhao, P. Sun, L. Cai, T. Huang, Z. Wang, Z.-K. Wang, Y. Duan, J. L. Yang, S. Tan, Y. Yuan, Y. Huang, Y. Yang, Caffeine improves the performance and thermal stability of perovskite solar cells. _Joule_ **3** , 1464–1477 (2019). 

27. C.-H. Chiang, C.-G. Wu, Bulk heterojunction perovskite-PCBM solar cells with high fill factor. _Nat. Photonics_ **10** , 196–200 (2016). 

28. D. Bi, C. Yi, J. Luo, J.-D. Décoppet, F. Zhang, S. M. Zakeeruddin, X. Li, A. Hagfeldt, M. Grätzel, Polymer-templated nucleation and crystal growth of perovskite films for solar cells with efficiency greater than 21%. _Nat. Energy_ **1** , 16142 (2016). 

29. T. H. Han, J. W. Lee, C. Choi, S. Tan, C. Lee, Y. Zhao, Z. Dai, N. De Marco, S. J. Lee, S. H. Bae, Y. Yuan, H. M. Lee, Y. Huang, Y. Yang, Perovskite-polymer composite cross-linker approach for highly-stable and efficient perovskite solar cells. _Nat. Commun._ **10** , 520 (2019). 

30. T. Elmelund, B. Seger, M. Kuno, P. V. Kamat, How interplay between photo and thermal activation dictates halide ion segregation in mixed halide perovskites. _ACS Energy Lett._ **5** , 56–63 (2020). 

31. J. S. Yun, J. Kim, T. Young, R. J. Patterson, D. Kim, J. Seidel, S. Lim, M. A. Green, S. Huang, A. Ho-Baillie, Humidity-induced degradation via grain boundaries of HC(NH2)2PbI3 planar perovskite solar cells. _Adv. Funct. Mater._ **28** , 1705363 (2018). 

32. Y. Jiang, S.-C. Yang, Q. Jeangros, S. Pisoni, T. Moser, S. Buecheler, A. N. Tiwari, F. Fu, Mitigation of vacuum and illumination-induced degradation in perovskite solar cells by structure engineering. _Joule_ **4** , 1087–1103 (2020). 

33. N. Li, Y. Luo, Z. Chen, X. Niu, X. Zhang, J. Lu, R. Kumar, J. Jiang, H. Liu, X. Guo, B. Lai, G. Brocks, Q. Chen, S. Tao, D. P. Fenning, H. Zhou, Microscopic degradation in formamidinium-cesium lead iodide perovskite solar cells under operational stressors. _Joule_ **4** , 1743–1758 (2020). 

34. Y. Zhao, J. Wei, H. Li, Y. Yan, W. Zhou, D. Yu, Q. Zhao, A polymer scaffold for self-healing perovskite solar cells. _Nat. Commun._ **7** , 10228 (2016). 

35. W. Zhang, G. Camino, R. Yang, Polymer/polyhedral oligomeric silsesquioxane (POSS) nanocomposites: An overview of fire retardance. _Prog. Polym. Sci._ **67** , 77–125 (2017). 

36. S. Valero, T. Soria, N. Marinova, J. L. Delgado, Efficient and stable perovskite solar cells based on perfluorinated polymers. _Polym. Chem._ **10** , 5726–5736 (2019). 

37. L. Meng, C. Sun, R. Wang, W. Huang, Z. Zhao, P. Sun, T. Huang, J. Xue, J. W. Lee, C. Zhu, Y. Huang, Y. Li, Y. Yang, Tailored phase conversion under conjugated polymer enables thermally stable perovskite solar cells with efficiency exceeding 21%. _J. Am. Chem. Soc._ **140** , 17255–17262 (2018). 

38. C.-C. Zhang, Z.-K. Wang, S. Yuan, R. Wang, M. Li, M. F. Jimoh, L.-S. Liao, Y. Yang, Polarized ferroelectric polymers for high-performance perovskite solar cells. _Adv. Mater._ **31** , 1902222 (2019). 

39. S. Rühle, Tabulated values of the Shockley-Queisser limit for single junction solar cells. _Sol. Energy_ **130** , 139–147 (2016). 

40. K. Wang, C. Liu, P. Du, J. Zheng, X. Gong, Bulk heterojunction perovskite hybrid solar cells with large fill factor. _Energ. Environ. Sci._ **8** , 1245–1255 (2015). 

41. C.-G. Wu, C.-H. Chiang, Z.-L. Tseng, M. K. Nazeeruddin, A. Hagfeldt, M. Grätzel, High efficiency stable inverted perovskite solar cells without current hysteresis. _Energ. Environ. Sci._ **8** , 2725–2733 (2015). 

42. C. H. Chiang, C. G. Wu, A method for the preparation of highly oriented MAPbI3 crystallites for high-efficiency perovskite solar cells to achieve an 86% fill factor. _ACS Nano_ **12** , 10355–10364 (2018). 

43. Y. Bai, Y. Lin, L. Ren, X. Shi, E. Strounina, Y. Deng, Q. Wang, Y. Fang, X. Zheng, Y. Lin, Z.-G. Chen, Y. Du, L. Wang, J. Huang, Oligomeric silica-wrapped perovskites enable synchronous defect passivation and grain stabilization for efficient and stable perovskite photovoltaics. _ACS Energy Lett._ **4** , 1231–1240 (2019). 

44. H. Chen, Q. Wei, M. I. Saidaminov, F. Wang, A. Johnston, Y. Hou, Z. Peng, K. Xu, W. Zhou, Z. Liu, L. Qiao, X. Wang, S. Xu, J. Li, R. Long, Y. Ke, E. H. Sargent, Z. Ning, Efficient and stable inverted perovskite solar cells incorporating secondary amines. _Adv. Mater._ **31** , 1903559 (2019). 

45. S. Yang, S. Chen, E. Mosconi, Y. Fang, X. Xiao, C. Wang, Y. Zhou, Z. Yu, J. Zhao, Y. Gao, F. D. Angelis, J. Huang, Stabilizing halide perovskite surfaces for solar cell operation with wide-bandgap lead oxysalts. _Science_ **365** , 473–478 (2019). 

46. P. Ru, E. Bi, Y. Zhang, Y. Wang, W. Kong, Y. Sha, W. Tang, P. Zhang, Y. Wu, W. Chen, X. Yang, H. Chen, L. Han, High electron affinity enables fast hole extraction for efficient flexible inverted perovskite solar cells. _Adv. Energy Mater._ **10** , 1903487 (2020). 

47. K. Wang, C. Wu, Y. Hou, D. Yang, T. Ye, J. Yoon, M. Sanghadasa, S. Priya, Isothermally crystallized perovskites at room-temperature. _Energ. Environ. Sci._ **13** , 3412–3422 (2020). 

48. S. Wu, J. Zhang, Z. Li, D. Liu, M. Qin, S. H. Cheung, X. Lu, D. Lei, S. K. So, Z. Zhu, A. K. Y. Jen, Modulation of defects and interfaces through alkylammonium interlayer for efficient inverted perovskite solar cells. _Joule_ **4** , 1248–1262 (2020). 

49. W. Chen, Y. Wang, G. Pang, C. W. Koh, A. B. Djurišić, Y. Wu, B. Tu, F.-z. Liu, R. Chen, H. Y. Woo, X. Guo, Z. He, Conjugated polymer-assisted grain boundary passivation for efficient inverted planar perovskite solar cells. _Adv. Funct. Mater._ **29** , 1808855 (2019). 

50. X. Liu, Y. Cheng, C. Liu, T. Zhang, N. Zhang, S. Zhang, J. Chen, Q. Xu, 20.7% highly reproducible inverted planar perovskite solar cells with enhanced fill factor and eliminated hysteresis. _Energ. Environ. Sci._ **12** , 1622–1633 (2019). 

51. T. S. Su, F. T. Eickemeyer, M. A. Hope, F. Jahanbakhshi, M. Mladenovic, J. Li, Z. Zhou, A. Mishra, J. H. Yum, D. Ren, A. Krishna, O. Ouellette, T. C. Wei, H. Zhou, H. H. Huang, M. D. Mensi, K. Sivula, S. M. Zakeeruddin, J. V. Milic, A. Hagfeldt, U. Rothlisberger, L. Emsley, H. Zhang, M. Gratzel, Crown ether modulation enables over 23% efficient formamidinium-based perovskite solar cells. _J. Am. Chem. Soc._ **142** , 19980–19991 (2020). 

52. M. A. Green, Accuracy of analytical expressions for solar cell fill factors. _Sol. Cells_ **7** , 337–340 (1982). 

53. J. Wang, J. Zhang, Y. Zhou, H. Liu, Q. Xue, X. Li, C.-C. Chueh, H.-L. Yip, Z. Zhu, A. K. Y. Jen, Highly efficient all-inorganic perovskite solar cells with suppressed non-radiative recombination by a lewis base. _Nat.Commun._ **11** , 177 (2020). 

54. M. Kaltenbrunner, G. Adam, E. D. Glowacki, M. Drack, R. Schwodiauer, L. Leonat, D. H. Apaydin, H. Groiss, M. C. Scharber, M. S. White, N. S. Sariciftci, S. Bauer, Flexible high power-per-weight perovskite solar cells with chromium oxide-metal contacts for improved stability in air. _Nat. Mater._ **14** , 1032–1039 (2015). 

55. S. P. Harvey, J. Messinger, K. Zhu, J. M. Luther, J. J. Berry, Investigating the effects of chemical gradients on performance and reliability within perovskite solar cells with TOF-SIMS. _Adv. Energy Mater._ **10** , 1903674 (2020). 

56. J. Cao, S. X. Tao, P. A. Bobbert, C. P. Wong, N. Zhao, Interstitial occupancy by extrinsic alkali cations in perovskites and its impact on ion migration. _Adv. Mater._ **30** , 1707350 (2018). 

57. W. E. I. Sha, H. Zhang, Z. S. Wang, H. L. Zhu, X. Ren, F. Lin, A. K. Y. Jen, W. C. H. Choy, Quantifying efficiency loss of perovskite solar cells by a modified detailed balance model. _Adv. Energy Mater._ **8** , 1701586 (2018). 

58. H. Zhang, J. Cheng, F. Lin, H. He, J. Mao, K. S. Wong, A. K. Jen, W. C. Choy, Pinhole-free and surface-nanostructured NiO _x_ film by room-temperature solution process for high-performance flexible perovskite solar cells with good stability and reproducibility. _ACS Nano_ **10** , 1503–1511 (2016). 

59. Q. Cao, Z. Li, J. Han, S. J. Wang, J. Zhu, H. Tang, X. Li, X. Li, Electron transport bilayer with cascade energy alignment for efficient perovskite solar cells. _Sol. RRL_ **3** , 1900333 (2019). 

60. S. Wang, Z. Li, Y. Zhang, X. Liu, J. Han, X. Li, Z. Liu, S. Liu, W. C. H. Choy, Water-soluble triazolium ionic-liquid-induced surface self-assembly to enhance the stability and efficiency of perovskite solar cells. _Adv. Funct. Mater._ **29** , 1900417 (2019). 

61. H. Tan, A. Jain, O. Voznyy, X. Lan, F. P. G. d. Arquer, J. Z. Fan, R. Quintero-Bermudez, M. Yuan, B. Zhang, Y. Zhao, F. Fan, P. Li, L. N. Quan, Y. Zhao, Z.-H. Lu, Z. Yang, S. Hoogland, E. H. Sargent, Efficient and stable solution-processed planar perovskite solar cells via contact passivation. _Science_ **355** , 722–726 (2017). 

62. Y. Hou, X. Y. Du, S. Scheiner, D. P. McMeekin, Z. Wang, N. Li, M. S. Killian, H. W. Chen, M. Richter, I. Levchuk, N. Schrenker, E. Spiecker, T. Stubhan, N. A. Luechinger, A. Hirsch, P. Schmuki, H.-P. Steinrück, R. H. Fink, M. Halik, H. J. Snaith, C. J. Brabec, A generic interface to reduce the efficiency-stability-cost gap of perovskite solar cells. _Science_ **358** , 1192–1197 (2017). 

63. J. A. Christians, P. Schulz, J. S. Tinkham, T. H. Schloemer, S. P. Harvey, B. J. Tremolet de Villers, A. Sellinger, J. J. Berry, J. M. Luther, Tailored interfaces of unencapsulated perovskite solar cells for & >1,000 hour operational stability. _Nat. Energy_ **3** , 68–74 (2018). 

64. S.-H. Turren-Cruz, A. Hagfeldt, M. Saliba, Methylammonium-free, high-performance, and stable perovskite solar cells on a planar architecture. _Science_ **362** , 449–453 (2018). 

65. W. Chen, Y. Wu, Y. Yue, J. Liu, W. Zhang, X. Yang, H. Chen, E. Bi, I. Ashraful, M. Grätzel, L. Han, Efficient and stable large-area perovskite solar cells with inorganic charge extraction layers. _Science_ **350** , 944–948 (2015). 

66. Y. Wang, W. Chen, L. Wang, B. Tu, T. Chen, B. Liu, K. Yang, C. W. Koh, X. Zhang, H. Sun, G. Chen, X. Feng, H. Y. Woo, A. B. Djurišić, Z. He, X. Guo, Dopant-free small-molecule hole-transporting material for inverted perovskite solar cells with efficiency exceeding 21%. _Adv. Mater._ **31** , 1902781 (2019). 

**Acknowledgments:** We thank C. K. Graetzel for valuable help with correcting the manuscript, F. Eickemeyer for fruitful discussion, A. Krishna for TRPL fitting, and the members from the Analytical & Testing Center of Northwestern Polytechnical University for the help of SEM, TEM, XPS, and UPS characterization. **Funding:** This research is supported by the Key Research and Development Program from Shaanxi Province (2020GXLH-Z-025), the Shaanxi International Cooperation Project (2020KWZ-018), the Research Fund of the State Key Laboratory of Solidification Processing (NPU), China (Grant No. 2021-QZ-02), and the Fundamental Research Funds for the Central Universities (3102019ghxm003, 3102019JC005, and 3102019ghjd001). H.Z., S.M.Z., and M.G. are grateful for financial support from the European Union’s Horizon 2020 research and innovation programme under grant agreement 881603 (GRAPHENE FLAGSHIP Core 3). **Author contributions:** Xuanhua Li and Q.C. proposed the experimental 

**10 of 11** 

Cao _et al_ ., _Sci. Adv._ 2021; **7** : eabg0633     7 July 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

ideas, designed the experiments, and wrote the manuscript. J.Y., J.H., S.W., B.G., J.Z., and Xiaoqiang Li conducted the device/sample fabrication, optimization, and characterizations. Y.L. and X.M. synthesized the PPP polymer. T.X., Z.W., and W.E.I.S. performed the modified detailed balance model to study the FF loss. Q.C., M.G., S.M.Z., and H.Z. analyzed the data and revised the manuscript. **Competing interests:** The authors declare that they have no competing interests. **Data and materials availability:** All data needed to evaluate the conclusions in the paper are present in the paper and/or the Supplementary Materials. Additional data related to this paper may be requested from the authors 

Submitted 11 December 2020 Accepted 26 May 2021 Published 7 July 2021 10.1126/sciadv.abg0633 

**Citation:** Q. Cao, Y. Li, H. Zhang, J. Yang, J. Han, T. Xu, S. Wang, Z. Wang, B. Gao, J. Zhao, X. Li, X. Ma, S. M. Zakeeruddin, W. E. I. Sha, X. Li, M. Grätzel, Efficient and stable inverted perovskite solar cells with very high fill factors via incorporation of star-shaped polymer. _Sci. Adv._ **7** , eabg0633 (2021). 

**11 of 11** 

Cao _et al_ ., _Sci. Adv._ 2021; **7** : eabg0633     7 July 2021 



## **Efficient and stable inverted perovskite solar cells with very high fill factors via incorporation of star-shaped polymer** 

Qi Cao, Yongjiang Li, Hong Zhang, Jiabao Yang, Jian Han, Ting Xu, Shuangjie Wang, Zishuai Wang, Bingyu Gao, Junsong Zhao, Xiaoqiang Li, Xiaoyan Ma, Shaik Mohammed Zakeeruddin, Wei E. I. Sha, Xuanhua Li, and Michael Grätzel 

_Sci. Adv._ **7** (28), eabg0633.  DOI: 10.1126/sciadv.abg0633 

**View the article online** https://www.science.org/doi/10.1126/sciadv.abg0633 **Permissions** 

https://www.science.org/help/reprints-and-permissions 

Use of this article is subject to the Terms of service 

_Science Advances_ (ISSN 2375-2548) is published by the American Association for the Advancement of Science. 1200 New York Avenue NW, Washington, DC 20005. The title _Science Advances_ is a registered trademark of AAAS. 

Copyright © 2021 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works. Distributed under a Creative Commons Attribution NonCommercial License 4.0 (CC BY-NC). 

