# Bimolecularly passivated interface enables efficient and stable inverted perovskite solar cells

| 字段 | 内容 |
|---|---|
| 期刊 | Science |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 639 |
| 作者 | Cheng Liu, Yi Yang, Hao Chen, Jian Xu, Ao Liu, Abdulaziz S. R. Bati, Hui-Hui Zhu, Luke Grater et al. |
| DOI | 10.1126/science.adk1633 |
| 源文件 | 010_Liu_2023_Bimolecularly-passivated-interface-enables-effic.pdf |

---
TSpace Research Repository 

tspace.library.utoronto.ca 

# **Bimolecularly-passivated interface enables efficient and stable inverted perovskite solar cells** 

Cheng Liu, Yi Yang, Hao Chen, Jian Xu, Ao Liu, Abdulaziz S. R. Bati, Huihui Zhu, Luke Grater, Shreyash Sudhakar Hadke, Chuying Huang, Vinod K. Sangwan, Tong Cai, Donghoon Shin, Lin X. Chen, Mark C. Hersam, Chad A. Mirkin, Bin Chen, Mercouri G. Kanatzidis, Edward H. Sargent 

**Version** Postprint/Accepted Manuscript 

**Citation** Liu, C., Yang, Y., Chen, H., Xu, J., Liu, A., Bati, A. S., ... & Sargent, **(published version)** E. H. (2023). Bimolecularly passivated interface enables efficient and stable inverted perovskite solar cells. Science, 382(6672), 810-815. 

**DOI** <u>https://doi.org/10.1126/science.adk1633</u> 

**Copyright / License** This document is the Accepted Manuscript version of a Published Work that appeared in final form in Science. The published work is available at https://doi.org/10.1126/science.adk1633 

### **How to cite TSpace items** 

**Always cite the published version** , so the author(s) will receive recognition through services that track citation counts, e.g. Scopus. If you need to cite the page number of the **author manuscript from TSpace** because you cannot access the published version, then cite the TSpace version **in addition to** the published version using the permanent URI (handle) found on the record page. 

**This article was made openly accessible by U of T Faculty. Please** **<u>tell us how this access benefits you. Your story matters.</u>** 



Submitted Manuscript: Confidential 

10 

20 

## **Bimolecularly-passivated interface enables efficient and stable inverted perovskite solar cells** 

5 

Cheng Liu<sup>1</sup> †, Yi Yang<sup>1</sup> †, Hao Chen<sup>1,2</sup> †, Jian Xu<sup>2</sup> †, Ao Liu<sup>1</sup> †, Abdulaziz S. R. Bati<sup>1</sup> , Huihui Zhu<sup>1</sup> , Luke Grater<sup>2</sup> , Shreyash Sudhakar Hadke<sup>4</sup> , Chuying Huang<sup>1</sup> , Vinod K. Sangwan<sup>4</sup> , Tong Cai<sup>1,5</sup> , Donghoon Shin<sup>4,5</sup> , Lin X. Chen<sup>1</sup> , Mark C. Hersam<sup>1,3,4</sup> , Chad A. Mirkin<sup>1,4,5</sup> , Bin Chen<sup>1</sup> *, Mercouri G. Kanatzidis<sup>1</sup> *, Edward H. Sargent<sup>1,2,3</sup> * 

### **Affiliations:** 

1Department of Chemistry, Northwestern University, 2145 Sheridan Rd, Evanston, Illinois 60208, United States 

2Department of Electrical and Computer Engineering, University of Toronto, 35 St George Street, Toronto, Ontario, M5S 1A4, Canada 

3Department of Electrical and Computer Engineering, Northwestern University, 2145 Sheridan Rd, Evanston, Illinois 60208, United States 

15 

4 Department of Materials Science and Engineering, Northwestern University, 2220 Campus Dr, Evanston, Illinois 60208, United States 

5International Institute for Nanotechnology, Northwestern University, Evanston, Illinois 60208, United States 

†These authors contributed equally to this work. 

*Corresponding author. Email: bin.chen@northwestern.edu (B.C.), m- kanatzidis@northwestern.edu (M.G.K.), ted.sargent@northwestern.edu (E.H.S.) 

25 

30 

35 

**Abstract:** Compared to the n-i-p structure, inverted (p-i-n) perovskite solar cells (PSCs) promise increased operating stability, but these photovoltaic cells often exhibit lower power conversion efficiencies (PCEs) that result from nonradiative recombination losses, particularly at the perovskite/C60 interface. We passivated surface defects and enabled reflection of minority carriers from the interface into the bulk using two types of functional molecules. We used sulfur-modified methylthio molecules to passivate surface defects and suppress recombination through strong coordination and hydrogen bonding, along with diammonium molecules to repel minority carriers and reduce contact-induced interface recombination achieved through field-effect passivation. The approach leads to a fivefold increase in carrier lifetime and a threefold reduction in photoluminescence quantum yield loss. This approach enabled a certified quasi-steady-state PCE of 25.1% for inverted PSCs with stable operation at 65 Celsius for > 2,000 hours in ambient air. We also fabricated monolithic all-perovskite tandem solar cells with 28.1% PCE. 

**One-Sentence Summary:** Using a passivant combined with a minority carrier blocker increases the QSS-certified efficiency of inverted perovskite solar cells to 25.1%. 

1 

Submitted Manuscript: Confidential 

5 

10 

15 

20 

25 

30 

35 

**Main Text:** Certified power conversion efficiencies (PCEs) > 25% have been widely reported for perovskite solar cells (PSCs) in the regular (n-i-p) structure ( _1-3_ ). Although inverted (p-i-n) PSCs have potential advantage because of their stability, low-temperature processing, and compatibility with integration into tandem solar cells ( _4-8_ ), their reported PCEs rarely surpass 24% under the stringent quasi-steady-state (QSS) protocol ( _9-11_ ). This efficiency gap is primarily attributed to higher recombination rates at the interface between the perovskite and the charge transport materials ( _12_ ). The detrimental impact of buried perovskite/hole transport layer (HTL) interface losses has been addressed through the development of self-assembled monolayers (SAMs) ( _1315_ ). However, the top interface between the perovskite and the electron transport layer (ETL) typically made from C60 and its derivatives suffers from interfacial recombination that results from minority carriers in the vicinity of the interface as well as the effect of incompletely-passivated trap states ( _16_ ). 

Surface passivation can suppress interface charge recombination and has been accomplished by using organohalides ( _4, 17-19_ ), Lewis bases ( _20, 21_ ), and dipolar compounds ( _22, 23_ ). We noted that reliance on a single species of molecule may fail to address simultaneously both surface and interface recombination processes (Fig. 1A) ( _24, 25_ ). Specifically, the existence of nearinterface minority carriers (holes in the perovskite layer) leads to direct interface recombination with majority carriers (electrons in the ETL), a process that can occur even at nondefect sites ( _26_ ). In addition, defects at the perovskite surface induce surface recombination through trapping of carriers. The most common defect, the halide vacancy, has a low formation energy ( _27, 28_ ). 

### **Exploring class 1 and 2 molecule combinations** 

We sought to address complex interface carrier recombination issues using a combination of different molecules, each with distinct functionalities. The first class of molecules we incorporated repelled hole carriers to reduce interface recombination through field-effect passivation (Fig. 1B). The second class of molecule interacted with defect sites to form chemical bonds to reduce surface recombination through chemical passivation. 

Diammonium ligands, in which one -NH3<sup>+</sup> group anchors to the perovskite surface and the other extends away from it, can induce a surface dipole and n-type doping ( _29, 30_ ) and provide effective field-effect passivation for both narrow bandgap (NBG) (~1.2 eV) and wide bandgap (WBG) (~1.8 eV) PSCs ( _26_ ). We explored the passivation effect of different diammonium ligands on normal bandgap (~1.5 eV) PSC devices. The device architecture consisted of fluorine-doped tin oxide (FTO)/NiOx/[4-(3,6-dimethyl-9H-carbazol-9-yl)butyl]phosphonic acid (Me4PACz)/perovskite/passivation layer/C60/Bathocuproine (BCP)/Ag (fig. S1). <mark>Optical constants of materials are in fig. S2.</mark> The current-voltage characteristics showed that ethane-1,2-diammonium (EDAI2) and propane-1,3-diammonium iodide (PDAI2), with high binding energy with the perovskite surface (fig. S3), enabled a device performance improvement compared with the control devices (without passivation), from PCEs of ~22.8% to ~23.9% with active areas of 0.05 cm<sup>2</sup> (Fig. 1, C and D). Thus, diammonium ligands work well in normal bandgap PSCs, and the PCE improvement could be explained by field-effect passivation that repels minority carriers ( _26_ ). 

40 

We then sought a second molecule to add a chemical passivation function. We first examined _n_ -butylammonium iodide (BAI), which is widely used as chemical passivating agent ( _31, 32_ ), in combination with PDAI2. Its addition increased PCE to ~24.3% compared with PDAI2-only. Extending the chain length to amylamine hydroiodide (AAI) further improved the average efficiency to ~24.5%, thus providing a baseline roughly at parity with efficient previously-reported inverted PSCs ( _12, 17_ ). 

45 

2 

Submitted Manuscript: Confidential 

5 

10 

15 

20 

25 

30 

35 

We then further tuned the electrical dipole moment by incorporating sulfur as a donor atom in the alkyl chain by synthesizing methylthio-based ammonium ligands, namely 2- (methylthio)ethylamine hydroiodide (2MTEAI) and 3-(methylthio)propylamine hydroiodide (3MTPAI). The use of both diammonium and methylthio molecules led to improved PCE across several combinations, namely EDAI2/2MTEAI, PDAI2/2MTEAI, EDAI2/3MTPAI, and PDAI2/3MTPAI, in comparison to both the control device and single-molecule passivated devices. The highest average PCE (>25.5%) was achieved with PDAI2/3MTPAI (Fig. 1D). We thus focused on the PDAI2/3MTPAI combination for further investigation. 

### **PDAI2/3MTPAI characteristics** 

We used density function theory (DFT) to compare 3MTPA<sup>+</sup> versus AA<sup>+</sup> by modeling ligand orientations of 3MTPA and AA on the perovskite surface per fig. S4. The binding energy difference (∆ _E_ clean) between the parallel ( _E_ clean-parallel) and vertical configurations ( _E_ clean-vertical) was used as a measure of ligand orientation. A larger ∆ _E_ clean value of -0.22 eV for 3MTPA indicated a stronger preference for the parallel orientation compared to -0.13 eV for AA (Fig. 2A). This difference corresponded to greater occupation on the vacancy defect position. Electrostatic potentials in the ligands (Fig. 2B) showed that 3MTPA, when compared to AA, had a lower minimum electrostatic potential ( _φ_ min) because of its electron-rich center surrounding the S atom that facilitated binding with the positively charged iodide vacancy. The higher maximum electrostatic potential ( _φ_ max) at the -NH3<sup>+</sup> side also added increased binding strength between the ligand and the surface cation vacancy site of perovskite. 

The passivation effect of the ligands was further evaluated by considering the presence of iodide vacancies, which are the predominant defects on the perovskite surface (fig. S5) ( _33_ ). We assessed the binding energy difference (∆ _E_ relative) between that of the defective surface ( _E_ VI-parallel) and the clean surface ( _E_ clean-parallel). ∆ _E_ relative of AA with the perovskite remains nearly unchanged, regardless of the presence or absence of iodide vacancy. In contrast, ∆ _E_ relative = -0.38 eV was obtained for 3MTPA, indicating a favorable interaction with the defective sites. 3MTPA induced a notable charge redistribution that accumulated charges at iodide vacancy, assigned to S-Pb coordination bonding (Fig. 2C). 

Charge transfer between 3MTPA and formamidinium (FA) was also observed (Fig. 2D), accompanied by a shorter distance of 2.72 Å between the sulfur atom in 3MTPA and the hydrogen atom in FA that indicated the formation of a hydrogen bond. In contrast, the distance between the carbon atom at the corresponding site in AA and the hydrogen atom in FA was 3.33 Å. Thus, the formation energy of the FA vacancy increased from -0.79 eV to -0.71 eV (fig. S6).<sup>1</sup> H nuclear magnetic resonance (<sup>1</sup> H NMR) spectra showed that the amino proton peak of FAI at _δ_ = 8.82 parts per million (ppm) exhibited increased broadening and shifted to a lower field after mixing with 3MTPAI compared to AAI (Fig. 2E). These changes again indicated stronger hydrogen bonding interactions between 3MTPA and FA than that with AA ( _34_ ). Computation work suggested that the methylthio group provided stronger binding – viewed in some studies as a proxy for stronger passivation – compared with ligands that relied on ammonium functional groups alone. 

40 

We assessed diammonium-methylthio dual passivation (DMDP) using x-ray photoelectron spectroscopy (XPS). The Pb 4 _f_ peaks of the passivated perovskite film shifted toward lower binding energy of 0.23 eV compared to the control film (Fig. 2F), which we attributed to an increased electron density at Pb<sup>2+</sup> ( _35_ ). Time-of-flight secondary ion mass spectrometry (ToFSIMS) we employed to analyze the surface ligand distribution <mark>. Comparing signal ratios of PDA:3MTPA and PDA:AA under identical conditions on perovskite films with PDAI</mark> 2 <mark>/3MTPAI</mark> 

45 

3 

Submitted Manuscript: Confidential 

5 

10 

15 

20 

25 

30 

35 

40 

<mark>and PDAI</mark> 2 <mark>/AAI bimolecular passivation, we found that the signal ratio of 1:2.7 for PDA:3MTPA was lower than the ratio of 1:1.1 for AA:PDA (Fig. 2G). This suggests that 3MTPA has a stronger binding affinity to the perovskite surface and better passivation effect of defects, consistent with its higher binding energy (fig. S7).</mark> 

Fig. 2H illustrates the centimeter-scale photoluminescence (PL) intensity distribution of a perovskite film with Gaussian-distributed passivators on the surface (fig. S8) ( _36_ ). The region surrounding the PDAI2/3MTPAI center exhibited higher PL emission than the corresponding region for PDAI2/AAI; and the contour region with the lowest PL intensity was skewed toward the PDAI2/AAI center. 

Scanning electron microscopy (SEM) images revealed dense polygonal grains with sizes of ~500 nm for the control perovskite film; the morphologies were unchanged after DMDP passivation (fig. S9). Grazing-incidence wide-angle x-ray scattering (GIWAXS) did not reveal any peaks at low scattering vectors q in the DMDP-based film, which indicated that no lowdimensional perovskite formed (Fig. 3A). We ascribed the peak at ~0.84 Å<sup>-1</sup> in the control sample to the presence of _δ_ -FAPbI3 formed in the ambient humid air during the measurement. The suppression of _δ_ -FAPbI3 in the DMDP-based film indicates improved ambient stability. The unchanged surface dimensionality was further corroborated by transient absorption spectra where the passivated film displayed a single bleach spectral feature from the three-dimensional perovskite (fig. S10). 

To examine the chemical passivation effect of DMDP strategy on film optoelectronic properties, we conducted time-resolved photoluminescence (TRPL) measurements (Fig. 3B and table S1). Control perovskite films showed a sharp decrease in emission characteristic of high levels of nonradiative carrier recombination on the bare perovskite surface. Treatment with PDAI2 showed little improvement in lifetime that reflected its limited suppression of defect-induced surface recombination. In contrast, the perovskite film treated with 3MTPAI displayed a sustained plateau in the decay curve reflecting increased carrier lifetime. <mark>This might be due to a combined effect of reduced non-radiative traps and enhanced photon recycling (</mark> _<mark>37</mark>_ <mark>). The re-emission of photons from the WBG subcell might serve to augment photon absorption of the adjacent NBG subcell when it is integrated in the tandem configuration.</mark> 

We used ultraviolet photoelectron spectroscopy (UPS) to characterize band edge energies (Fig. 3C and fig. S11). PDAI2 treatment reduced the energy level difference between the conduction band minimum ( _E_ CBM) and the Fermi level ( _E_ F) of the perovskite surface to 0.10 eV, compared to 0.20 eV and 0.17 eV for the control and 3MTPAI treatments, respectively. The stronger n-type doping effect of PDAI2 was attributed to the additional -NH3<sup>+</sup> group extending away from the perovskite matrix that induced a surface dipole that repelled the minority carrier at the interface ( _26, 38_ ). This treatment enabled field-effect passivation and reduced interface recombination <mark>(fig. S12)</mark> . We expect this passivation effect to be retained upon the incorporation of 3MTPAI because n-type doping was also observed compared with use of single 3MTPAI. 

### **Photovoltaic performance** 

PDAI2 did not enhance the PL quantum yield (PLQY) (Fig. 3D) of the perovskite film before C60 deposition and there was little PLQY loss after coating with C60, which were consistent with its field-effective-passivation role. Increased PDAI2 concentration led to a decrease in both PLQY and PCE, which we attributed to increased surface recombination. For 3MTPAI, in the absence of C60, PLQY increased as 3MTPAI processing solution concentration increased from 3 mM to 15 mM. Upon contact with C60, noticeable PLQY and PCE losses were seen, and these losses became 

45 

4 

Submitted Manuscript: Confidential 

5 

10 

15 

20 

more pronounced at higher concentrations, indicating increased interface recombination. The DMDP strategy improved PLQY of the perovskite/C60 samples and increased the PCE to > 26% even at 12 mM concentration of 3MTPAI. In sum, 3MTPAI and PDAI2 could increase passivation and decrease carrier recombination without interfering with one another (Fig. 3E). 

The photovoltaic parameters of devices with different treatments at the optimized concentration are summarized in fig. S13. The DMDP-based devices showed an improved PCE from 22.8 ± 0.4 to 25.5 ± 0.3% compared to the control device, accompanied by enhancements in open-circuit voltage ( _V_ OC) from 1.12 ± 0.01 to 1.16 ± 0.01 V and fill factor (FF) from 78.5 ± 1.3 to 83.8 ± 1.3%. The diode characteristics of the devices in the absence of light showed that the devices in which we used the DMDP strategy presented an average dark saturation current ( _J_ 0) reduction by two orders of magnitude compared to the control devices, demonstrating effective inhibition of carrier recombination (fig. S14) ( _39_ ). Fig. 4A shows the current density-voltage ( _J_ - _V_ ) curves for the champion DMDP device, which exhibited a PCE of 26.4%, with a short-circuit current ( _J_ SC) of 26.2 mA cm<sup>-2</sup> , _V_ OC of 1.17 V, and FF of 85.8%. 

We focused on QSS measurement in certification: here the highest performance based on maximum power point tracking (MPPT) was a PCE of 25.5% for 100 s (fig. S15). A National Renewable Energy Lab (NREL) certification that used the asymptotic maximum power scan protocol (Fig. 4B and fig. S16) reported a QSS PCE of 25.1% for an illuminated area of 0.05 cm<sup>2</sup> along with a fast-scan PCE of 25.9%, compared to other reported certified QSS PCEs that did not exceed 25% (Fig. 4C and table S2) ( _9, 10, 40, 41_ ). We also fabricated 1.5 cm<sup>2</sup> devices using the DMDP treatment that delivered a PCE of 24.0% (fig. S17), consistent with increased film homogeneity and reduced localized non-radiative recombination (fig. S18). 

### **Longevity studies** 

25 

30 

In our studies of the thermal stability of encapsulated devices, we found that after 1,600 hours of thermal aging at 85˚C in nitrogen (ISOS-D-2), the DMDP-based devices retained 95% of initial PCE, surpassing the retention of 84% for the control device (Fig. 4 <mark>D and fig. S19</mark> ). We investigated the operating stability under MPPT under 1 sun of an encapsulated device operating in ambient air. After 2,000 hours of continuous operation under 1 sun illumination at 65˚C (ISOS-L-3 protocol, where ISOS is the International Summit on Organic PV stability), the DMDP-based device maintained 96% of original PCE, whereas the control device was reduced to 70% of initial PCE (Fig. 4E <mark>and fig. S20)</mark> . A comparison with other PSCs tested using the ISOS-L-3 protocol is provided in table S3. 

### **Discussion** 

35 

40 

To investigate the applicability of the DMDP strategy on other perovskite compositions, we fabricated PSCs with both WBG and NBG perovskite materials. Notably, the average PCE was improved by 14% and 13% when the DMDP strategy is used for NBG and WBG PSCs (Fig. 4F), respectively. We applied the DMDP strategy to monolithic all-perovskite tandem solar cells with the structure of FTO/NiOx/Me-4PACz/WBG perovskite/C60/SnOx/Au/poly(3,4ethylenedioxythiophene) polystyrene sulfonate (PEDOT:PSS)/NBG perovskite/C60/SnOx/Ag (Fig. 4G). The _J_ - _V_ characteristics of the champion tandem device (Fig. 4H) with an illuminated area of 0.05 cm<sup>2</sup> exhibited a PCE of 28.1% with a _V_ OC of 2.14 V, _J_ SC of 15.6 mA cm<sup>-2</sup> , and FF of 84.0%, and a stabilized PCE of 27.1% under MPPT. <mark>A well-matched current response is seen in the external quantum efficiency (EQE) spectra (fig. S21).</mark> 

5 

Submitted Manuscript: Confidential 

5 

<mark>Realizing both chemical and field-effect passivation by the combined use of methylthio and diammonium molecules has mitigated complex carrier recombination issues at the perovskite/ETL interface.</mark> We consider the multi-molecule passivation approach, along with diverse functionalities, as a promising direction for exploring next-generation passivation strategies to achieve improved performance and stability in perovskite optoelectronics. 

### **References and Notes** 

1. M. Kim _et al._ , Conformal quantum dot-SnO2 layers as electron transporters for efficient perovskite solar cells. _Science_ **375** , 302-306 (2022). 

10 

2. Y. Zhao _et al._ , Inactive (PbI2)2RbCl stabilizes perovskite films for efficient solar cells. _Science_ **377** , 531-534 (2022). 

3. Y. Ding _et al._ , Single-crystalline TiO2 nanoparticles for stable and efficient perovskite modules. _Nat. Nanotechnol._ **17** , 598-605 (2022). 

15 

4. T. Li _et al._ , Inorganic wide-bandgap perovskite subcells with dipole bridge for all-perovskite tandems. _Nat. Energy_ **8** , 610-620 (2023). 

5. X. Zheng _et al._ , Co-deposition of hole-selective contact and absorber for improving the processability of perovskite solar cells. _Nat. Energy_ **8** , 462-472 (2023). 

6. R. Lin _et al._ , All-perovskite tandem solar cells with 3D/3D bilayer perovskite heterojunction. _Nature_ , (2023). 

20 

7. J. Tong _et al._ , Carrier control in Sn-Pb perovskites via 2D cation engineering for allperovskite tandem solar cells with improved efficiency and stability. _Nat. Energy_ **7** , 642-651 (2022). 

8. J. Xu _et al._ , Triple-halide wide-band gap perovskites with suppressed phase segregation for efficient tandems. _Science_ **367** , 1097-1104 (2020). 

25 

9. W. Peng _et al._ , Reducing nonradiative recombination in perovskite solar cells with a porous insulator contact. _Science_ **379** , 683-690 (2023). 

10. Q. Jiang _et al._ , Surface reaction for efficient and stable inverted perovskite solar cells. _Nature_ **611** , 278-283 (2022). 

30 

11. Q. Cao _et al._ , Efficient and stable inverted perovskite solar cells with very high fill factors via incorporation of star-shaped polymer. _Sci. Adv._ **7** , eabg0633. 

12. S. Liu, V. P. Biju, Y. Qi, W. Chen, Z. Liu, Recent progress in the development of highefficiency inverted perovskite solar cells. _NPG Asia Mater._ **15** , 27 (2023). 

35 

13. F. Ali, C. Roldán-Carmona, M. Sohail, M. K. Nazeeruddin, Applications of Self-Assembled Monolayers for Perovskite Solar Cells Interface Engineering to Address Efficiency and Stability. _Adv. Energy Mater._ **10** , 2002989 (2020). 

14. K. Almasabi _et al._ , Hole-Transporting Self-Assembled Monolayer Enables Efficient SingleCrystal Perovskite Solar Cells with Enhanced Stability. _ACS Energy Lett._ **8** , 950-956 (2023). 

15. Q. Tan _et al._ , Inverted perovskite solar cells using dimethylacridine-based dopants. _Nature_ , (2023). 

6 

Submitted Manuscript: Confidential 

16. F. Ye _et al._ , Overcoming C60-induced interfacial recombination in inverted perovskite solar cells by electron-transporting carborane. _Nat. Commun._ **13** , 7454 (2022). 

17. H. Chen _et al._ , Quantum-size-tuned heterostructures enable efficient and stable inverted perovskite solar cells. _Nat. Photonics_ **16** , 352-358 (2022). 

5 

18. R. Lin _et al._ , All-perovskite tandem solar cells with improved grain surface passivation. _Nature_ **603** , 73-78 (2022). 

<mark>19. D. H. Kim et al., Bimolecular Additives Improve Wide-Band-Gap Perovskites for Efficient Tandem Solar Cells with CIGS.</mark> _<mark>Joule</mark>_ **<mark>3</mark>** <mark>, 1734-1745 (2019).</mark> 

10 

20. Z. Li _et al._ , Organometallic-functionalized interfaces for highly efficient inverted perovskite solar cells. _Science_ **376** , 416-420 (2022). 

21. X. Li _et al._ , Constructing heterojunctions by surface sulfidation for efficient inverted perovskite solar cells. _Science_ **375** , 434-437 (2022). 

22. P. Caprioglio _et al._ , Bi-functional interfaces by poly(ionic liquid) treatment in efficient pin and nip perovskite solar cells. _Energy Environ. Sci._ **14** , 4508-4522 (2021). 

15 

23. Z. Zhu _et al._ , Correlating the perovskite/polymer multi-mode reactions with deep-level traps in perovskite solar cells. _Joule_ **6** , 2849-2868 (2022). 

24. W. Yang _et al._ Visualizing field-effects and chemical passivation in efficient 2D/3D heterojunction perovskite solar cells and modules. SSRN: http://dx.doi.org/10.2139/ssrn.4318826 

20 

25. Z. Zhang _et al._ , Rationalization of passivation strategies toward high-performance perovskite solar cells. _Chem. Soc. Rev._ **52** , 163-195 (2023). 

26. H. Chen _et al._ , Regulating surface potential maximizes voltage in all-perovskite tandems. _Nature_ **613** , 676-681 (2023). 

25 

27. D. Meggiolaro, F. De Angelis, First-principles modeling of defects in lead halide perovskites: best practices and open issues. _ACS Energy Lett._ **3** , 2206-2222 (2018). 

28. A. Walsh, S. D. Stranks, Taking control of ion transport in halide perovskite solar cells. _ACS Energy Lett._ **3** , 1983-1990 (2018). 

29. S. Hu _et al._ , Optimized carrier extraction at interfaces for 23.6% efficient tin-lead perovskite solar cells. _Energy Environ. Sci._ **15** , 2096-2107 (2022). 

30 

30. C. Quarti, F. De Angelis, D. Beljonne, Influence of surface termination on the energy level alignment at the CH3NH3PbI3 perovskite/C60 interface. _Chem. Mater._ **29** , 958-968 (2017). 

31. S. Sidhik _et al._ , Deterministic fabrication of 3D/2D perovskite bilayer stacks for durable and efficient solar cells. _Science_ **377** , 1425-1430 (2022). 

35 

32. A. R. b. Mohd Yusoff _et al._ , Passivation and process engineering approaches of halide perovskite films for high efficiency and stability perovskite solar cells. _Energy Environ. Sci._ **14** , 2906-2953 (2021). 

33. J. Jeong _et al._ , Pseudo-halide anion engineering for α-FAPbI3 perovskite solar cells. _Nature_ **592** , 381-385 (2021). 

34. L. Zhu _et al._ , Unveiling the additive-assisted oriented growth of perovskite crystallite for high performance light-emitting diodes. _Nat. Commun._ **12** , 5081 (2021). 

40 

7 

Submitted Manuscript: Confidential 

35. Z. Wang _et al._ , Xanthate-induced sulfur doped all-inorganic perovskite with superior phase stability and enhanced performance. _Nano Energy_ **59** , 258-267 (2019). 

36. E. J. Kluender _et al._ , Catalyst discovery through megalibraries of nanomaterials. _Proc. Natl. Acad. Sci._ **116** , 40-45 (2019). 

5 

<mark>37. D. W. deQuilettes</mark> _<mark>et al.</mark>_ <mark>, Charge-Carrier Recombination in Halide Perovskites.</mark> _<mark>Chem. Rev.</mark>_ **<mark>119</mark>** <mark>, 11007-11019 (2019).</mark> 

38. A. Liu _et al._ , Antimony fluoride (SbF3): A potent hole suppressor for tin(II)-halide perovskite devices. _InfoMat_ **5** , e12386 (2023). 

39. A. Cuevas, The recombination parameter _J_ 0. _Energy Procedia_ **55** , 53-62 (2014). 

10 

40. X. Wu _et al._ , Backbone engineering enables highly efficient polymer hole-transporting materials for inverted perovskite solar cells. _Adv. Mater._ **35** , 2208431 (2023). 

41. F. Li _et al._ , Hydrogen-bond-bridged intermediate for perovskite solar cells with enhanced efficiency and stability. _Nat. Photonics_ **17** , 478-484 (2023). 

15 

42. G. Kresse, J. Furthmüller, Efficient iterative schemes for ab initio total-energy calculations using a plane-wave basis set. _Phys. Rev. B_ **54** , 11169-11186 (1996). 

43. J. P. Perdew, K. Burke, M. Ernzerhof, Generalized gradient approximation made simple. _Phys. Rev. Lett._ **77** , 3865-3868 (1996). 

44. K. Lee, É. D. Murray, L. Kong, B. I. Lundqvist, D. C. Langreth, Higher-accuracy van der Waals density functional. _Phys. Rev. B_ **82** , 081101 (2010). 

20 

45. T. Lu, F. Chen, Multiwfn: A multifunctional wavefunction analyzer. _J. Comput. Chem._ **33** , 580-592 (2012). 

46. S. M. Park et al., Engineering ligand reactivity enables high-temperature operation of stable perovskite solar cells. _Science_ **381** , 209-215 (2023). 

25 

47. S. Chen, X. Xiao, H. Gu, J. Huang, Iodine reduction for reproducible and high-performance perovskite solar cells and modules. _Sci. Adv._ **7** , eabe8130. 

48. X. Zheng et al., Managing grains and interfaces via ligand anchoring enables 22.3%efficiency inverted perovskite solar cells. _Nat. Energy_ **5** , 131-140 (2020). 

49. Y.-H. Lin et al., A piperidinium salt stabilizes efficient metal-halide perovskite solar cells. _Science_ **369** , 96-102 (2020). 

30 

35 

50. S. Yang et al., Stabilizing halide perovskite surfaces for solar cell operation with widebandgap lead oxysalts. _Science_ **365** , 473-478 (2019). 

**Acknowledgments:** Part of the research described in this paper was performed at the Canadian Light Source, a national research facility of the University of Saskatchewan, which is supported by the Canada Foundation for Innovation (CFI), the Natural Sciences and Engineering Research Council (NSERC), the National Research Council (NRC), the Canadian Institutes of Health Research (CIHR), the Government of Saskatchewan, and the University of Saskatchewan. ASRB acknowledges support from King Abdullah University of Science and Technology (KAUST) through the Ibn Rushd Postdoctoral Fellowship Award. 

40 

8 

Submitted Manuscript: Confidential 

### **Funding:** 

This work was supported under award number OSR-CRG2020-4350.2. 

EHS acknowledges support from the Office of Naval Research (ONR) N00014-20-12572. 

5 

MGK was supported by ONR grant N00014-20-1-2725. 

<mark>CAM was supported by the Army Research Office under grants W911NF-23-1-0141 and W911NF-23-1-0285, and by the Sherman Fairchild Foundation, Inc.</mark> 

10 

This work made use of the SPID, EPIC, and Keck-II facilities of Northwestern University’s NUANCE Center, which has received support from the SHyNE Resource (NSF ECCS-2025633), 

The International Institute of Nanotechnology, Northwestern University and Northwestern’s MRSEC program (NSF DMR-1720139). 

15 

Charge transport characterization was supported by the National Science Foundation (NSF) Materials Research Science and Engineering Center (MRSEC) at Northwestern University under award number DMR-1720319. 

### **Author contributions:** 

20 

25 

Conceptualization: CL, YY DFT calculation: JX Device fabrication: CL, YY, HC Writing – original draft: CL, YY Writing – review & editing: AL, HZ XPS and UPS characterization: AB GIWAXS characterization: LG Electrical characterization: SSH, VKS, MCH TA measurement: CH, LXC Ink spray coating: TC, DS Supervision on ink spray coating: CAM Supervision: BC, MGK, EHS 

**Competing interests:** Authors declare that they have no competing interests. 

30 **Data and materials availability:** All data are available in the main text or the supplementary materials. 

### **Supplementary Materials** 

35 

Materials and Methods Figs. S1 to S21 Tables S1 to S3 

9 

Submitted Manuscript: Confidential 

5 



**Fig. 1. Passivation at the perovskite/ETL interface.** ( **A** , **B** ) Schematic of the perovskite surface without passivation (A) and with both chemical and field-effect passivation (B). ( **C** ) Chemical structures of the diammonium and ammonium ligands investigated in this study. ( **D** ) PCEs of control vs. passivated PSCs using different passivation ligands. 

10 

Submitted Manuscript: Confidential 

5 

10 

15 



**Fig. 2. The process of passivation through the methylthio group on perovskite surfaces.** ( **A** ) Binding energies of ammonium ligands with clean and defective perovskite surface with the typical iodide vacancy. ( **B** ) Electrostatic potential ( _φ_ ) of 3MTPA and AA ligands ( _φ_ max: blue colour; _φ_ min: red color). ( **C** ) Calculated charge density difference (blue, depletion; yellow, accumulation) of anchoring ammonium ligands onto the perovskite surface with I vacancies. The red open circles indicate the positions of I vacancies. The atoms in the structures are differentiated by different colors: S is represented by grass green, C by brown, Pb by gray, and I by purple. ( **D** ) Calculated charge density difference showing the hydrogen bond formation between 3MTPA and FA. ( **E** ) The proton NMR spectra of FAI, FAI with AAI, and FAI with 3MTPAI. ( **F** ) High-resolution Pb 4f XPS peaks of the perovskite films. ( **G** ) <mark>SIMS mapping of signal ratios of 3MTPA: PDA and AA: PDA for perovskite samples with PDAI</mark> 2 <mark>/3MTPAI (1:2 molar ratio) and PDAI</mark> 2 <mark>/AAI (1:2 molar ratio) bimolecular passivation.</mark> ( **H** ) PL intensity distribution of the 1 cm by 1 cm perovskite film post-synthetic treated by spray coating with ink 1 of PDAI2/3MTPAI and ink 2 of PDAI2/AAI solution centered around the diagonal corners. 

11 

Submitted Manuscript: Confidential 

5 



**Fig. 3. DMDP strategy working principle.** ( **A** ) GIWAXS patterns of the control and DMDPbased perovskite films. ( **B** ) TRPL of the perovskite films treated with different ligands. ( **C** ) The energy level difference between the conduction band maximum and Fermi level for the perovskite films treated with different ligands. ( **D** ) Ligand-concentration-dependent PLQY of the perovskite films, PLQY loss of the perovskite films after C60 deposition, and PCEs of devices. For DMDP, the concentration of 3MTPAI was varied, while the PDAI2 concentration was optimized and maintained at 6 mM. ( **E** ) Schematic diagram showing the inhibition of interface recombination by PDAI2 and the suppression of defect-induced recombination by 3MTPAI. 

12 

Submitted Manuscript: Confidential 

5 



**Fig. 4. Device performance and stability.** ( **A** ) _J_ - _V_ characteristics of the best-performing DMDP-based device. ( **B** ) QSS _J_ - _V_ curve of one representative DMDP-based device certified at NREL. ( **C** ) Certified QSS and fast-scan PCE statistics of inverted PSCs. ( **D** ) Thermal stability of encapsulated PSCs annealed at 85˚C in nitrogen. ( **E** ) Operational stability of encapsulated PSCs under constant one sun illumination at 65˚C in air with 50% RH. ( **F** ) PCEs of the WBG and NBG PSCs showing the universality of the DMDP strategy. ( **G** ) Architecture of the tandem device. ( **H** ) _J_ - _V_ characteristics of the best-performing tandem device based on the DMDP strategy. The inset shows the stabilized PCE under MPPT. 

13 

