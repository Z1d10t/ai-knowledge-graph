# Review on Chemical Stability of Lead Halide Perovskite Solar Cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nano-Micro Letters |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 205 |
| 作者 | Jing Zhuang, Ji-Zheng Wang, Feng Yan |
| DOI | 10.1007/s40820-023-01046-0 |
| 源文件 | 026_Zhuang_2023_Review-on-Chemical-Stability-of-Lead-Halide-Pero.pdf |

---
e-ISSN 2150-5551 CN 31-2103/TB 

## **<mark>REVIEW</mark>** 

https://doi.org/10.1007/s40820-023-01046-0 



# **Review on Chemical Stability of Lead Halide Perovskite Solar Cells** 

###### **Cite as** 

Nano-Micro Lett. (2023) 15:84 Jing Zhuang<sup>1</sup> , Jizheng Wang<sup>2,3</sup> , Feng Yan<sup>1,4*</sup> 

Received: 19 January 2023 Accepted: 23 February 2023 Published online: 31 March 2023 © The Author(s) 2023 

#### **HIGHLIGHTS** 

- A comprehensive review is presented on the chemical reactions of perovskite films underdifferent environmental conditions and with charge transfer materials and metalelectrodes in perovskite solar cells. 

- The influence of chemical reactions on device stability is elucidated. 

- Effective strategies for suppressing the degradation reactions are specified. 

**ABSTRACT** Lead halide perovskite solar cells (PSCs) have become a promising next-generation photovoltaic technology due to their skyrocketed power conversion efficiency. However, the device stability issues may restrict their commercial applications, which are dominated by various chemical reactions of perovskite layers. Hence, a comprehensive illustration on the stability of perovskite films in PSCs is urgently needed. In this review article, chemical reactions of perovskite films under different environmental conditions (e.g., moisture, oxygen, light) and with charge transfer materials and metal electrodes are systematically elucidated. Effective strategies for suppressing the degradation reactions of perovskites, such as buffer layer introduction and additives engineering, are specified. Finally, conclusions and outlooks for this field are proposed. The comprehensive review will provide a guideline on the material engineering and device design for PSCs. 



**KEYWORDS** Perovskite solar cells; Chemical reactions; Defects; Degradation; Device stability 

> * Feng Yan, apafyan@polyu.edu.hk 

> 1 Department of Applied Physics, The Hong Kong Polytechnic University, Hung Hom, Kowloon, Hong Kong SAR, People’s Republic of China 

> 2 Beijing National Laboratory for Molecular Sciences, CAS Key Laboratory of Organic Solids, Institute of Chemistry, Chinese Academy of Sciences, Beijing 100190, People’s Republic of China 

> 3 University of Chinese Academy of Sciences, Beijing 100049, People’s Republic of China 

> 4 Research Institute of Intelligent Wearable Systems, The Hong Kong Polytechnic University, Hung Hom, Kowloon, Hong Kong SAR 999077, People’s Republic of China 

1 3 

**84** Page 2 of 34 

Nano-Micro Lett. (2023) 15:84 

### **1 Introduction** 

As one of the sustainable clean energy sources, photovoltaic technology has been developed vigorously in recent decades. Among them, lead halide perovskite solar cells (PSCs) stand out due to their rapidly increasing power conversion efficiency (PCE), and are currently considered as the most encouraging and promising candidate for the next generation photovoltaic technology [1–7]. In a PSC, the active lightharvesting materials are generally metal halide perovskites with a structural formula of  ABX3 (A: monovalent cation, CH3NH3+, HC(NH2)2+,  Cs+; B: divalent metal cation, Pb<sup>2+</sup> ,  Sn<sup>2+</sup> ; X: halide anion,  I<sup>−</sup> ,  Br<sup>−</sup> ,  Cl<sup>−</sup> ) [8–11], which are responsible for converting the incident sunlight into free carriers in the devices, therefore playing a crucial role in the conversion of energy. The extraction of free carriers depends 

on the electron/hole transport layers (ETL/HTL) that sandwich the perovskite layer and transport charge carriers to corresponding electrodes. Therefore, typical configurations of PSCs involve conductive glass/ETL/perovskite/HTL/ electrode (n-i-p) or conductive glass/ HTL/perovskite/ ETL/ electrode (p-i-n), as shown in Fig. 1 [12–16]. 

PSCs show advantages over commercially available solar cells in terms of low cost and little energy consumption in device fabrication. As the dominating share of the photovoltaic industry, monocrystalline silicon solar cells suffer from high fabrication cost, high-temperature preparation, bulky active layer and long payback time. In contrast, PSCs can be fabricated by solution methods at low temperature with very low fabrication cost and little material consumption [17–23]. GaAs solar cells, which have realized the highest PCE of single-junction solar 



**Fig. 1 a** Basic structures of PSCs: (i) mesoporous structure with cathode/compact layer  (TiO2)/mesoporous layer  (TiO2 or  Al2O3)/perovskite/ HTL/anode, (ii) conventional structure with cathode/ETL/perovskite/HTL/anode, and (iii) inverted structure with anode/HTL/ perovskite/ETL/ cathode. **b** Schematic representation of the interfaces in a planar-structured PSC. ➀ , ➁ , ➂ , and ➃ represent ETL/perovskite interface, perovsktite/HTL interface, cathode/ETL interface, and HTL/anode interface, respectively. Reproduced with permission from Ref. [12]. Copyright 2018, Wiley-VCH 

© The authors 

https://doi.org/10.1007/s40820-023-01046-0 

Page 3 of 34 **84** 

Nano-Micro Lett. (2023) 15:84 

cells, are only used in small-area markets such as space stations [24], while large-area PSCs (over 60  cm<sup>2</sup> ) with PCE over 20.5% have been achieved [25, 26], promising their large-area applications. Other thin film solar cells, such as copper indium diselenide (GIGS), cadmium telluride (CdTe), and quantum dot solar cells, are subject to the slow growth of efficiency [27]. Notably, the certified PCE of PSCs has exceeded 25.7% after one decade study, owing to the excellent photophysical properties of perovskites [5]. Considering the theoretical Shockley–Queisser limit of ~ 31% [28–31], there is still a relatively large space for PCE improvement for PSCs. Despite these advantages, device stability of PSCs is a critical issue to their commercial applications [32–37]. It has been recognized that device stability is closely related to a series of chemical reactions between perovskite and ETL/HTL [5, 38–40], electrodes or the environment issues (e.g., moisture, oxygen, light) [41–46]. 

The chemical reactions of lead halide perovskite have significant impacts on interfacial defects [47, 48], charge transport/extraction [49], and thus photovoltaic performance and device stability of PSCs [50–55]. Because of the relatively active chemical properties, perovskites may react with oxygen [56–59], water [60–63], Lewis acids and bases [64, 65] and some metals [66–70], at perovskite/charge transport layer interfaces or grain boundaries (GBs). In general, these reactions fall into two categories: 1) the reactions with species in ambient environment, including water, oxygen, and light; 2) the reactions with other materials in the device, including HTL/ETL, metal electrodes, and alternative modifiers. In order to suppress the degradation reactions of perovskites, it’s necessary to reduce the reactivity of perovskites through doping additives or compositional modifications [65, 71–77]. Despite significant efforts in additive engineering, the stability of PSCs still can’t meet the requirements for commercialization [78–81]. Physical isolation, another effective strategy for improving device stability, also attracts enormous attention simultaneously [82–89]. Some specific materials can serve as buffer layers to reduce the detrimental interfacial reactions. For example, the modified ZnO isolation layer with good electrical conductivity between the Ag electrode and ETL can effectively suppress the reaction between perovskite and Ag [90]. The hydrophobic diketopyrrolopyrrole-based polymers are deposited on perovskites surfaces to prevent the perovskites from being 

invaded by water [91]. In conclusion, understanding the chemical reactions at the interfaces can help researchers find feasible approaches to prevent the degradation of lead halide perovskites and improve the stability of PSCs. 

In this review, we describe a variety of interfacial chemical reactions under different conditions, and the reactions mechanisms are also summarized. We retrospectively examined the established understanding of how the interfacial reactions affect the defects/traps formation, non-radiative recombination, ion migrations, and eventually device stability. A relatively clear relationship between device stability and interfacial chemical reactions is revealed in this part. According to different chemical reactions mechanism, we also review some available strategies for improving the chemical stability of perovskites. Finally, potential suggestions on reducing or avoiding the detrimental interfacial reactions in device fabrication and commercialization are proposed. 

### **2  Interfacial Chemical Reactions** 

##### **2.1  Environmental Factors** 

Although encapsulated lead halide PSCs can insulate air, the challenge of achieving an ideal encapsulation effect makes it necessary to explore how environmental factors affect the chemical stability of PSCs. Both pure  MAPbI3 and FAPbI3 are very sensitive to air due to their intrinsic instability, which can be demonstrated by their color changes from black to yellow in a few minutes, especially in high-humidity environments. Studies have shown that water and oxygen in the air can react with perovskites through different pathways. In addition, ambient light can induce the decomposition of perovskites, which will be discussed in this part. 

##### **_2.1.1  Water‑Induced Reactions_** 

Many studies have revealed that the reactions of lead halide perovskites with  H2O can accelerate the degradation process and deteriorate the chemical stability of PSCs [60, 61, 92]. In order to express the reaction mechanism more concisely, all chemical reactions of perovskite in this review are based on the archetypal  MAPbI3 unless otherwise stated. Walsh et al _._ proposed the simple acid–base reversible reactions 

1 3 

**84** Page 4 of 34 

Nano-Micro Lett. (2023) 15:84 

between  MAPbI3 and  H2O as follows [48], and a plausible decomposition pathway for  MAPbI3 is shown in Fig. 2a. 



<!-- Start of picture text -->
[( CH 3 NH 3) PbI 3] n +  H 2 O<br>(2.1-1)<br>⇋ [ ( CH 3 NH 3)( n −1)( PbI 3) n ][ H 3 O +] +  CH 3 NH 2 ↑<br><!-- End of picture text -->



<!-- Start of picture text -->
[( CH 3 NH 3)( n −1)( PbI 3) n ][ H 3 O +]<br>(2.1-2)<br>⇌ HI ↑ + PbI 2 + [( CH 3 NH 3) PbI 3]( n −1) +  H 2 O<br><!-- End of picture text -->

By combining Eqs. 2.1-1 and 2.1-2, the whole degradation process of  MAPbI3 in the presence of  H2O can be generalized as follows: 



<!-- Start of picture text -->
H 2 O<br>( CH 3 NH 3) PbI 3 � ������ �→ HI ↑ + PbI 2 +  CH 3 NH 2 ↑ (2.1-3)<br><!-- End of picture text -->

CH3NH2 and HI both exist in gas phases at room temperature, and thus the continuous release of gas products promotes the reaction to proceed in the forward direction. 

In consequence,  MAPbI3 will completely degrade into  PbI2 once the open system contains water [93]. 

Wang et al _._ further proposed that the degradation product HI can continue to decompose into  H2 and  I2 under the stimulation of ultraviolet (UV) light [94]. The photoreaction process of HI under UV irradiation is illustrated below: 



<!-- Start of picture text -->
UV<br>2 HI � ����� → H 2 ↑ + I 2 (2.1-4)<br><!-- End of picture text -->

The whole degradation reaction of  MAPbI3 when  H2O and UV light coexist is generalized in Eq. 2.1-5 with the combination of Eqs. 2.1-3 and 2.1-4. Therefore, the final solid products of  MAPbI3 decomposition are  PbI2 and  I2. 



<!-- Start of picture text -->
� �������������� H 2 O + UV �→ 1<br>( CH 3 NH 3) PbI 3<br>2 H 2 ↑ + PbI 2 +  CH 3 NH 2 ↑ + 2 1 I 2<br>(2.1-5)<br>Considering that lead halide perovskites are prone to<br>absorb  H2O molecule in the air to form a hydrated complex<br><!-- End of picture text -->



**Fig. 2 a** Possible decomposition pathway of hybrid halide perovskites in the presence of water. A water molecule, 1, is required to initiate the process with the decomposition being driven by the phase changes of both hydrogen iodide, (2, soluble in water) and the methylammonia (3, volatile and soluble in water). This pathway results in the formation of a yellow solid, which corresponds to the experimentally observed  PbI2, 4. Reproduced with permission from Ref. [48]. Copyright 2014, American Chemical Society. **b** Photographs of  CH3NH3PbI3 films deposited on FTO and stored under ambient conditions for several days. **c** Evolutions of photoelectron spectra of I 3 _d_ 5/2, Pb 4 _f_ , C 1 _s_ and O 1 _s_ . **b** , **c** Reproduced with permission from Ref. [97]. Copyright 2016, American Chemical Society. (Color figure online) 

© The authors 

https://doi.org/10.1007/s40820-023-01046-0 

Page 5 of 34 **84** 

Nano-Micro Lett. (2023) 15:84 

[50, 51, 63], the hydration processes of  MAPbI3 are displayed in Eqs. 2.1-6 and 2.1-7, respectively. Notably, the decoloring process of black perovskites induced by the generation of monohydrated phase  CH3NH3PbI3·H2O is reversible [95], and that can be reconverted into  MAPbI3 again through dehydration process [63]. However, the degradation reactions become irreversible once the dihydrate (CH3NH3)4PbI6·2H2O forms (Eq. 2.1-7). Here, in the hydration  process, the  [PbI6]<sup>4−</sup> in the 3D network of  MAPbI3 decays to a 0D framework of isolated octahedral. Ptasinska et al _._ pointed out that a transient phase  PbI2+ _xx−_ (0 ≤ x < 1) forms during the evolution of a hydrated complex under ambient conditions [96]. The resulting  PbI2+ _xx−_ is reactive when exposed to air and decomposes into lead-containing compounds inducing amorphous PbO, Pb(OH)2, and  PbCO3 (Eqs. 2.1-9, 2.1-10, 2.1-11), which is evidenced by X-ray photoelectron spectra (XPS) characterizations in Fig. 2c. 

( _CH_ 3 _NH_ 3) _PbI_ 3 + _H_ 2 _O_ ⇌ ( _CH_ 3 _NH_ 3) _PbI_ 3 ⋅ _H_ 2 _O_ (2.1-6) 



<!-- Start of picture text -->
4 ( CH 3 NH 3) PbI 3 + 8 H 2 O  → ( CH 3 NH 3)4 PbI 6<br>(2.1-7)<br>⋅ 2 H 2 O  + 3 Pb ( OH )2 + 6 HI ↑<br><!-- End of picture text -->



<!-- Start of picture text -->
( CH 3 NH 3)4 PbI 6 ⋅ 2 H 2 O  → ( CH 3 NH 3 ) x PbI 2+ x<br>(2.1-8)<br>+ (4 − x ) CH 3 NH 2 ↑ +(4 − x ) HI ↑ +2 H 2 O<br><!-- End of picture text -->



<!-- Start of picture text -->
2 ( CH 3 NH 3) x PbI 2+ x  + 2 CO 2 +  O 2 → 2 PbCO 3<br>(2.1-9)<br>+ 2 I 2 + 2 xCH 3 NH 2 ↑ +2 xHI ↑<br>( CH 3 NH 3) x PbI 2+ x  +  H 2 O  + 1 2 O 2 → Pb ( OH )2<br>(2.1-10)<br>+  I 2 +  xCH 3 NH 2 ↑ + xHI ↑<br><!-- End of picture text -->



<!-- Start of picture text -->
Pb ( OH )2 → PbO  +  H 2 O (2.1-11)<br><!-- End of picture text -->

It’s reported that trapped charges can facilitate the degradation reactions of  MAPbI3 in humid conditions. Ahn et al _._ deposited different polarity ions on the perovskite surfaces in humidified nitrogen and discovered that  MAPbI3 is irreversibly decomposed to yellow  PbI2 only when moisture and charges coexist (Fig. 3a–d) [97]. Figure 3e–l demonstrate 



**Fig. 3 a–d** Schematic illustration of perovskite degradation processes (left), **e–h** top-view (middle) and **i–l** cross-sectional (right) SEM images of perovskite layers ( **a** , **e** , **i** ) before, ( **b** , **f** , **j** ) after 6 h, ( **c** , **g** , **k** ) 12 h and ( **d** , **h** , **l** ) 18 h by ion deposition in humidified nitrogen. The color change from dark brown to yellow in **a-d** represents the gradual degradation process. Black lines and their widths in **a–d** represent grain boundaries and degradation extent, respectively. Scale bars, 200 nm. **m** Topography and **n** surface potential profile of  MA0.6FA0.4PbI2.9Br0.1 film obtained from KPFM measurements after deposition of  N2-positive ions. Reproduced with permission from Ref. [98]. Copyright 2016, Springer Nature. (Color figure online) 

1 3 

**84** Page 6 of 34 

Nano-Micro Lett. (2023) 15:84 

that the degradation of perovskite starts from the GBs and the striking resemblance in kelvin probe force microscopy (KPFM) measurements (Fig. 3m and n) indicates that charges are preferentially trapped along GBs, which demonstrates that trapped charges can give rise to irreversible degradation. The degradation mechanism can be summarized: first, the perovskite material undergoes a hydration reaction in humid environment. Next, the organic cations, like  MA<sup>+</sup> , will be deprotonated with the help of the local electric field induced by the charges trapped at the defect sites. The deprotonation process in the presence of water is shown below: 



<!-- Start of picture text -->
TC<br>CH 3 NH 3 + +  H 2 O � ���� �→ CH 3 NH 2 ↑ + H 3 O + (2.1-12)<br><!-- End of picture text -->

Here TC represents trapped charges. The release of gas phase  CH3NH2 will shift the following hydration equilibrium reaction to the right side, causing the perovskite to start irreversible decomposition: 



<!-- Start of picture text -->
TC<br>( CH 3 NH 3) PbI 3 +  H 2 O � ���� �→ PbI 2 +  CH 3 NH 2 ↑ + H 3 O + +  I −<br>(2.1-13)<br><!-- End of picture text -->

In addition, oxygen can also accelerate the aging of perovskite in humid conditions, which is attributed to the scavenging action of  O2 on the  H3O<sup>+</sup> proton formed in the aforementioned deprotonation process (Eq. 2.1-12). The overall degradation reaction of  MAPbI3 with the participation of  O2 is shown as follows: 



<!-- Start of picture text -->
( CH 3 NH 3) PbI 3 + 14 O 2 ← ←←←←←←←←←←←←←← H 2 O + TC → PbI 2 +  CH 3 NH 2 ↑ + 1 2 H 2 O  + 1 2 I 2<br>(2.1-14)<br><!-- End of picture text -->

In summary, lead halide perovskite can easily decompose into  PbI2,  CH3NH2, HI, and other products in humid conditions with/without other factors (e.g. UV light, trapped charges, oxygen). The degradation reaction of  MAPbI3 is usually irreversible due to the formed gas products (e.g. CH3NH2, HI) will release into the air. Therefore, protecting perovskites from water is crucial to improve the stability of PSCs. 

##### **_2.1.2  Oxygen‑Induced Reactions_** 

Oxygen can induce the degradation of lead halide perovskites under certain conditions [98]. A study found that  O2 molecules are only physically attached to the perovskites surfaces without chemical reactions. Once the adsorbed O2 captures an excess electron to form superoxide  (O2·−), the degradation reactions of perovskites will proceed [99]. 

Haque et al _._ reported that  O2 could permeate into the grain surface and interior of  MAPbI3, which could also be reduced to highly reactive  O2·− with the help of photo-excited electrons [57, 100]. It’s observed that the  Al2O3/MAPbI3 system can produce more  O2·− than  TiO2/MAPbI3 system. In Fig. 4a, the  TiO2 film can accept an electron from the photoexcited  MAPbI3 because of the favorable energy offset at the heterojunction. Therefore, the fewer electrons transferring to oxygen leads to a lower yield of  O2·− for the  TiO2/MAPbI3 system. Simultaneously, ab initio simulations demonstrate the  O2·− prefer energetically to occupy the iodide vacancies sites [101]. The photo-induced  O2·− formation is the key factor for the degradation reactions of  MAPbI3: 



<!-- Start of picture text -->
light<br>( CH 3 NH 3) PbI 3 � ������ �→ ( CH 3 NH 3) PbI 3∗ (2.1-15)<br><!-- End of picture text -->



<!-- Start of picture text -->
O 2 � ������������������������ ( CH 3 NH 3) PbI →3 ∗ O ⋅ 2 − (2.1-16)<br><!-- End of picture text -->



<!-- Start of picture text -->
4( CH 3 NH 3) PbI 3 ∗ +  O ( 2 ⋅ −) → 4 PbI 2 + 2 I 2 (2.1-17)<br>+ 2 H 2 O  + 4 CH 3 NH 2 ↑<br><!-- End of picture text -->

CH3NH3PbI3* carries both photo-induced electrons and holes (Eq. 2.1-15), and  O2 captures an electron from CH3NH3PbI3* to form  O2·− (Eq. 2.1-16). The study found that  MAPbI3 films with large grains degrade more slowly, which is attributed to large crystallites containing the fewer surface reaction sites. Based on the studies above, Sultana et al _._ discovered that the degradation product  PbI2 (Eq. 2.117) could further react with  O2 to produce lead oxyiodide under UV irradiation [38], which can be expressed as follows: 



<!-- Start of picture text -->
UV<br>PbI 2 � ����� → e − cb ( PbI 2) +  h + vb ( PbI 2) (2.1-18)<br><!-- End of picture text -->



<!-- Start of picture text -->
e − cb ( PbI 2) +  O 2 → O 2∙− +  PbI 2 (2.1-19)<br><!-- End of picture text -->



<!-- Start of picture text -->
( x  +  y ) PbI 2 + 2 y O 2 ∙− → ( PbI 2) x ( PbO ) y  +  yI 2 (2.1-20)<br><!-- End of picture text -->

The electron is excited from the valence band of  PbI2 to its conduction band under UV irradiation (Eq. 2.1-18), which then transfers to  O2 molecular to generate  O2·− (Eq. 2.1-19). Finally, the highly reactive  O2.− further reacts with  PbI2 generating lead oxyiodide. 

It’s reported that  O2.− will capture an acid proton of the CH3NH3+ to generate hydroperoxyl radical  (HO2·) once approaching the ammonium group (Eq. 2.1-21) [102, 103]. 

© The authors 

https://doi.org/10.1007/s40820-023-01046-0 

Page 7 of 34 **84** 

Nano-Micro Lett. (2023) 15:84 



**Fig. 4 a** Schematic model showing the electron transfer of the photoexcited electrons in the  MAPbI3 layers to oxygen resulting in the formation of superoxide. Reproduced with permission from Ref. [101]. Copyright 2015, Wiley-VCH. **b** Photovoltaic performance characteristics of p-i-n PSC treated by  H2O2 via the gas-phase deposition method with urea hydrogen peroxide for 40 s, compared to a control device, measured under AM1.5 100 mW/cm<sup>2</sup> simulated sunlight. Reproduced with permission from Ref. [103]. Copyright 2019, Elsevier. **c** Schematic representation of the photo-oxidative degradation process of the  MAPbI3 (001) surface. Reproduced with permission from Ref. [108]. Copyright 2019, Royal Society of Chemistry 

Subsequently, two different reaction mechanisms are proposed to express next degradation process of perovskite. The first one is that two  HO2· interact to produce hydrogen peroxide  (H2O2) under lights (Eq. 2.1-22). Ultimately,  H2O2 reacts with  Pb<sup>0</sup> on the perovskite surface generating PbO or Pb(OH)2 (Eqs. 2.1-23, 2.1-24). It is worth noting that the formed PbO has an unexpected passivation effect, preventing the accumulation of anion vacancies and formation of Pb-Pb dimers, which can increase the open-circuit voltage ( _V_ oc) for inverted PSCs as exhibited in Fig. 4b. The second one demonstrates that  HO2· radicals can dissociate into  H2 and  O2, and the remaining  O2 can serve as a reactant again for the continuous degradation process (Eq. 2.1-25). 



<!-- Start of picture text -->
2 HO 2⋅ ↔ 2 O 2 ↑ + H 2 ↑ (2.1-25)<br><!-- End of picture text -->

Hillhouse et al _._ reported that  H2O can accelerate the photooxidation reaction of  MAPbI3 and proposed one plausible degradation pathway [104].  H2O rapidly undergoes the deprotonation reaction to form  HO2· and  HO<sup>−</sup> in the presence of  O2·− (Eq. 2.1-26). As mentioned above, the newly formed  HO2· will interact to release  H2 and  O2 (Eq. 2.1-25). Unfortunately,  HO<sup>−</sup> triggers the decomposition of  MAPbI3 into  PbI2 (Eq. 2.1-27), which subsequently reacts with  H2O to generate PbIOH and HI (Eq. 2.1-28) in the following steps: 



<!-- Start of picture text -->
O (∙−) 2 +  H 2 O  ↔ HO − +  HO 2⋅ (2.1-26)<br><!-- End of picture text -->



<!-- Start of picture text -->
CH 3 NH 3 + +  O 2 ∙− ↔ CH 3 NH 2 ↑ + HO 2⋅ (2.1-21)<br><!-- End of picture text -->



<!-- Start of picture text -->
2 HO 2⋅ ↔ O 2 ↑ + H 2 O 2 (2.1-22)<br><!-- End of picture text -->



<!-- Start of picture text -->
Pb 0 +  H 2 O 2 → Pb ( OH )2 (2.1-23)<br><!-- End of picture text -->



<!-- Start of picture text -->
Pb 0 +  H 2 O 2 → PbO  +  H 2 O (2.1-24)<br><!-- End of picture text -->



<!-- Start of picture text -->
( CH 3 NH 3) PbI 3 +  HO − → PbI 2 +  H 2 O  +  CH 3 NH 2 ↑ + I −<br>(2.1-27)<br><!-- End of picture text -->



<!-- Start of picture text -->
PbI 2 +  H 2 O  → PbIOH  +  HI ↑ (2.1-28)<br><!-- End of picture text -->

It’s worth noting that  O2·− more rapidly reacts with  H2O (Eq. 2.1-26) than  CH3NH3+ (Eq. 2.1-21) due to a lower activation energy for the whole reaction pathway, which 

1 3 

**84** Page 8 of 34 

Nano-Micro Lett. (2023) 15:84 

demonstrates that  H2O can accelerate photooxidative degradation of  MAPbI3. 

Except for the degradation products mentioned above like PbI2 and lead oxyiodide, Snaith et al _._ detected metal lead (Pb<sup>0</sup> ) on the perovskite surface [105] and proposed a plausible formation mechanism of  Pb<sup>0</sup> [102]. An iodide ion  (I<sup>−</sup> ) abstracts a photogenerated hole  (h<sup>+</sup> ) to produce an iodine atom  (I<sup>·</sup> ) (Eq. 2.1-29), which is accompanied by rapid site exchange of iodide from a regular to interstitial lattice site. Two iodine atoms combine with each other to generate  I2, simultaneously leaving two iodine vacancies  (VI·) (Eq. 2.130). Subsequently,  VI· captures an electron to generate Farbe center  (VI·e’) (Eq. 2.1-31), which then reduces the  Pb<sup>2+</sup> in the adjacent site to  Pb<sup>+</sup> (Eq. 2.1-32). Finally,  Pb<sup>+</sup> undergoes a disproportionation reaction to produce  Pb<sup>0</sup> (Eq. 2.1-33). 



<!-- Start of picture text -->
I − +  h + → I ∙ (2.1-29)<br><!-- End of picture text -->



<!-- Start of picture text -->
2 I ∙ → I 2 + 2 VI ∙ (2.1-30)<br><!-- End of picture text -->



<!-- Start of picture text -->
VI ∙ +  e � → VI ∙ e � (2.1-31)<br><!-- End of picture text -->



<!-- Start of picture text -->
Pb 2+ +  V I ∙ e � → VI ∙ Pb + (2.1-32)<br><!-- End of picture text -->



<!-- Start of picture text -->
2 Pb + → Pb 2+ +  Pb 0 (2.1-33)<br><!-- End of picture text -->

Based on the above research, a photo-oxidative degradation mechanism of  MAPbI3 is proposed for rapid surface oxidation and slow inner hydration [101, 106]. Wang et al _._ reported the three-step degradation process of  MAPbI3 as displayed in Fig. 4c [107]. Step I:  O2 on the  MAPbI3 surface capture a photogenerated electron from the conduction band of  MAPbI3 to form  O2− (Eq. 2.1-16). Step II:  O2− rapidly oxidizes the  PbI2-terminated surface to produce PbO, resulting in a breakage of the Pb–I frameworks and the exposure of the MAI-terminated surface. Subsequently, the underlying MAI-terminated surface is further oxidized to generate  H2O and PbO or the unstable Pb(OH)2. Step III: The oxidation products PbO and Pb(OH)2 can act as protective layers to inhibit the further oxidation of the internal  MAPbI3. The newly produced  H2O molecules from the surface oxidation and decomposition of Pb(OH)2 can slowly hydrate with the internal  MAPbI3, finally leading to the structural collapse of  MAPbI3. 

In conclusion, the oxygen-induced reactions of perovskites need the participation of light or water. Firstly,  O2 

captures photogenerated electrons generating  O2−, which subsequently introduces a series of decomposition pathways under different conditions. Finally, the generating degradation products mainly include  CH3NH2,  I2,  PbI2, and PbO (or Pb(OH)2). 

##### **_2.1.3  Light‑Induced Reactions_** 

Unlike oxygen, light can induce the perovskites degradation without any presence of other environmental factors (e.g., water, oxygen). Study demonstrated that UV light can induce severe degradation of lead halide perovskites [108, 109]. As shown in Fig. 5a, Gao et al _._ detected  Pb<sup>0</sup> on the  MAPbI3 surface after about 120 min of UV irradiation with a wavelength of 408 nm [110]. The proposed degradation reactions of  MAPbI3 under UV irradiation can be generalized in Eqs. 2.1-34, 2.1-35. Figure 5b shows that the ratio of  Pb<sup>0</sup> remains nearly constant after 480 min of UV irradiation, which indicates that the decomposition of MAPbI3 has already saturated. 



<!-- Start of picture text -->
UV<br>( CH 3 NH 3) PbI 3 � ����� → PbI 2 +  HI ↑ + CH 3 NH 2 ↑ (2.1-34)<br><!-- End of picture text -->



<!-- Start of picture text -->
UV<br>PbI 2 � ����� → Pb 0 +  I 2 (2.1-35)<br><!-- End of picture text -->

Yan et al _._ proposed a possible photodegradation mechanism of  MAPbI3 concerning hot carriers [111]. As shown in Fig. 5c, the first step is that  MAPbI3 is excited by light ( _hv_ > 3 eV) to generate long-lived hot carriers (Eq. 2.1-36). Then a hot electron reacts with the  CH3NH3+ via columbic coupling to generate a free proton and release  CH3NH2 near surface or GB regions (Eq. 2.1-37). Finally, the free protons interact with undercoordinated  I<sup>−</sup> on the surface, generating volatile HI and iodine vacancies (Eq. 2.1-38). The release of HI can induce the destruction of Pb-I framework from the corner-shared to the face-shared Pb-I octahedral, causing the degradation of  MAPbI3 into  PbI2. 



<!-- Start of picture text -->
hv ( >  3eV) → e − ( hot ) +  h + ( hot ) (2.1-36)<br><!-- End of picture text -->



<!-- Start of picture text -->
CH 3 NH 3 + +  e −( hot ) → CH 3 NH 2 +  H + +  e − (2.1-37)<br><!-- End of picture text -->



<!-- Start of picture text -->
I − +  H + → HI ↑ + VI (2.1-38)<br><!-- End of picture text -->

It’s reported that halide defects have an influence on the photostability of  MAPbI3 [112]. Petrozza et al _._ found 

© The authors 

https://doi.org/10.1007/s40820-023-01046-0 

Page 9 of 34 **84** 

Nano-Micro Lett. (2023) 15:84 



**Fig. 5   a** Pb 4f7/2 decomposition and **b** metallic Pb fraction during laser irradiation. **a** , **b** Reproduced with permission from Ref. [111]. Copyright 2017, American Chemical Society. **c** Schematic representation of photodegradation mechanism. 1) Hot carrier generation, 2) deprotonation and release of MA gas, and 3) formation of HI gas and  VI. Reproduced with permission from Ref. [112]. Copyright 2018, Royal Society of Chemistry. **d, e** , Photoluminescence enhancement and quenching mechanisms. Ion dynamics in  MAPbI3 thin film promoting PLIE in **d** , when the probability of  I0 species encounters is small and Frenkel pair annihilation is boosted by electron trapping, and PLID in **e** , when the probability of  I0 species encounters is high, boosting  I2 molecule formation. **d** , **e** Reproduced with permission from Ref. [113]. Copyright 2019, Springer Nature 

that long-living carrier traps associated with halide defects could trigger photoconversion, which drives both photoluminescence intensity enhancement (PLIE) and photoluminescence intensity decrease (PLID). In Fig. 5d and e, PLIE and PLID processes are proposed to explain the observations. The timescales involved in PLID and PLIE are consistent with the reported ionic activities, such as ion/defect annihilation and migration rates [113, 114]. Generally, vacancies (e.g., _V_ Pb) and interstitial halogen (e.g.,  Ii) defects dominate in the perovskites. _V_ Pb is only moderately active as a trap, while  Ii can remarkably trap both electrons and holes via (+ /0) and (0/ −) transitions. When the probability of encountering  I<sup>0</sup> species is very low, the light-induced PLIE is associated with annihilation of the  Ii−VI+ Frenkel pair: 

The PLID mechanism is proposed to be a bimolecular reaction boosted by increasing the encountering probability of  I<sup>0</sup> species, occurring near the film surface filled with long-lived traps: 



<!-- Start of picture text -->
light<br>2 Ii 0 → I 2 (2.1-40)<br><!-- End of picture text -->

The two processes may coexist and compete in the perovskite material. If traps densities are adequately low, photoinduced PLIE will be a dominant effect. However, photoinduced PLID will play a key role when high-density traps appear near the film surface that may act as a reservoir for photogenerated species, eventually causing perovskites degradation. Therefore, passivating under-coordinated surface sites can prohibit defect formation and hence enhance the photostability of perovskites. 



<!-- Start of picture text -->
light<br>I + � ������ �→ I 0 � ������ �→ I 0<br>i ∕ I i −.... V I + +  e − light i ∕ I i −.... V I + i<br>(2.1-39)<br>+  pristine material<br><!-- End of picture text -->

1 3 

**84** Page 10 of 34 

Nano-Micro Lett. (2023) 15:84 

##### **2.2  Charge Transport Layers** 

In addition to the aforementioned degradation reactions induced by environmental factors, the chemical stability of lead halide PSCs can be affected by charge transport layers, including ETL and HTL. Generally, the interfacial chemical reactions are not desirable, which could lead to destroyed structure and reduced charge transport/extraction. However, for certain charge transport layers such as Cl-containing SnO2, interfacial reactions have been demonstrated to be beneficial for charge transport and chemical stability of PSCs. Considering the diversity of charge transport materials, a variety of interfacial reactions and their effects on device stability have been reported in literature. Therefore, 

the chemical reactions in PSCs induced by charge transport layers are elucidated in this session. 

##### **_2.2.1  ETL‑Induced Reactions_** 

TiO2 has been widely used as an electron transport material in the early study of PSCs [36, 115–121]. Belmonte et al _._ reported that  TiO2 interacts with  MAPbI3 mainly through binding  I<sup>−</sup> in  MAPbI3 to undercoordinated  Ti<sup>4+</sup> in  TiO2 [49, 122]. Notably, this Ti-I-Pb bond is not strong due to the little hybridization between  Pb _s–p_ state and  Ti _d_ orbital, hence the adsorption/desorption of  I<sup>−</sup> at the interface may occur easily. The interactions between  TiO2 and perovskite are reversible under both positive and negative biases, as shown in Fig. 6a–c. At a positive bias, weakly bonded  I<sup>−</sup> migrate 



**Fig. 6** Diagram representing iodide migration and chemical species present at the interfaces. **a** At positive-bias iodine ions are forced to migrate toward the hole selective contact where the reaction with spiro-OMeTAD<sup>+</sup> occurs. The iodide defective layer is formed at the  TiO2/ MAPbI3 interface. **b** At zero-bias the neutral case appears. **c** At negative-bias spiro-OMeTAD only partially returns to its oxidized, conductive state. Iodide ions accumulate at the  TiO2/perovskite interface. **a-c** Reproduced with permission from Ref. [49]. Copyright 2016, Wiley-VCH. **d** Scheme showing the reversible chemistry reactions process occurring at the solid-state  TiO2/CH3NH3PbI3 interface. Reproduced with permission from Ref. [124]. Copyright 2017, American Chemical Society. **e** Degradation scheme of  CH3NH3PbI3 perovskite solar cells during light exposure test:  TiO2/CH3NH3PbI3. Reproduced with permission from Ref. [125]. Copyright 2014, American Chemical Society 

© The authors 

https://doi.org/10.1007/s40820-023-01046-0 

Page 11 of 34 **84** 

Nano-Micro Lett. (2023) 15:84 

towards the hole transport layer contact and hence I vacancies remain at  MAPbI3/TiO2 interface, and the positive charges are compensated by electrons injection and accumulations at  TiO2. In contrast, excess  I<sup>−</sup> may accumulate at MAPbI3/TiO2 interface under a negative bias. The Ti-I-Pb bonds easily accommodate excessive defect or ion charges in a highly reversible manner to generate capacitive currents. However, it’s worth noting that this reversible interaction has a negligible effect on the photovoltaic performance and chemical stability of PSCs. 

Studies on film’s current response to  I2 vapor have revealed that reversible chemical reactions occur at TiO2/ I2 and MAPbI3/I2 interfaces [123]. Rand et al _._ discovered the pathways for  I2 passivation of  MAPbI3 surface defects from the photoconductivity data of  MAPbI3 films. According to the current response of  TiO2 film to  I2 vapor pressures, they proposed a plausible reaction mechanism between  TiO2 and  I2. As shown in Eqs. 2.2-1, 2.2-2, and 2.2-3,  TiO2 and MAPbI3 surfaces undergo strong reversible reactions with I2 gas, respectively. Combining these three reactions, the chemical interaction between  TiO2 and  MAPbI3 can be generalized in Eq. 2.2-4. 



<!-- Start of picture text -->
e − MAPbI 3 +  trap 0 MAPbI 3 ⇌ trap − (2.2-1)<br><!-- End of picture text -->



<!-- Start of picture text -->
trap − + 1 2 I 2 ⇌ I adsorbed − ( MAPbI 3) (2.2-2)<br><!-- End of picture text -->



<!-- Start of picture text -->
e − TiO 2 + 1 2 I 2 ⇌ I adsorbed − ( TiO 2) (2.2-3)<br><!-- End of picture text -->



<!-- Start of picture text -->
e − TiO 2 +  I adsorbed − ( MAPbI 3) ⇌ I adsorbed − ( TiO 2)  +  e MAPbI − 3 +  trap 0 MAPbI 3<br>(2.2-4)<br><!-- End of picture text -->

I<sup>−</sup> in  MAPbI3 is adsorbed on the  TiO2 surface and deplete an electron on  TiO2, leaving a free electron as well as a trap on the  MAPbI3 surface (Fig. 6d). The energy level of the trap would determine whether the electron is captured or freely transmitted. Therefore,  MAPbI3 may be chemically reduced by  TiO2 due to the differences in work function. In addition, the newly formed traps on the  MAPbI3 surface will make a difference to carrier density and recombination rate, which could deteriorate the device stability. 

TiO2 was also reported to catalyze  MAPbI3 decomposition in the presence of light [124]. In Fig. 6e,  TiO2 extracts an electron from  I<sup>−</sup> under light irradiation generating  I2 (Eq. 2.2-5), which deconstructs perovskites crystal and reduces their chemical stability. As mentioned in _2.2.1_ part, 

CH3NH3+ can be deprotonated to generate  CH3NH2 and  H+ in humid conditions. The presence of  I2 and  H<sup>+</sup> will accelerate the reaction (Eq. 2.2-6) to proceed forward, further destroying the perovskite structure. 



<!-- Start of picture text -->
2 I − � ���������������� TiO 2+ light �→ I 2 + 2 e − TiO 2 (2.2-5)<br><!-- End of picture text -->



<!-- Start of picture text -->
I − +  I 2 + 3 H + + 2 e − TiO 2 ⇌ 3 HI ↑ (2.2-6)<br><!-- End of picture text -->

TiO2 acts as a catalyzer rather than a reagent in the reactions with perovskites, which accelerates the degradation process of perovskites to some extent. Therefore, reducing the catalytic performance of  TiO2 is an effective way to improve the photovoltaic performance and chemical stability of  TiO2-based PSCs. 

It’s reported that ZnO ETL can also interact chemically with perovskites [125–129]. Anta et al _._ proposed that an acid–base reaction could occur at the ZnO/perovskite interface [130], triggering the decomposition of perovskite into PbI2 in humid conditions. In addition, this interaction could cause redissolution of the ZnO substrate, whose morphology changes from spherical nanoparticles to aciculate particles (Fig. 7a). 

Additionally, the deprotonation reaction between ZnO and perovskite can cause the thermal degradation of perovskite. Kelly et al _._ found that the basic hydroxyl groups and residual acetate ligands exist on the ZnO surface through the Fourier transform infrared spectroscopy (FTIR) spectra analysis (Fig. 7b), which can be eliminated or reduced by high-temperature calcination of ZnO films (Fig. 7c) [131]. Otherwise, the hydroxide or residual acetate ligands will react with  CH3NH3+ destroying the crystal structure of perovskite, which is evidenced in Fig. 7d and e [132]. And this decomposition process of  MAPbI3 can be expressed as follows: 



<!-- Start of picture text -->
OH − + CH 3 NH + 3 → CH 3 NH 3 OH (2.2-7)<br><!-- End of picture text -->



<!-- Start of picture text -->
heat<br>CH 3 NH 3 OH � ������ → CH 3 NH 2 ↑ + H 2 O (2.2-8)<br><!-- End of picture text -->

As shown in Eqs. 2.2-7 and 2.2-8, the whole degradation reactions are the deprotonation process of  CH3NH3+, and CH3NH3OH easily decomposes into  CH3NH2 gas and  H2O under heat. The decomposition of  CH3NH3OH can promote the reaction (Eq. 2.2-7) to proceed forward continuously, which accelerates  MAPbI3 degradation. It’s reported that MAPbI3 decomposes easily to form HI in humid conditions [94], which subsequently reacts with ZnO resulting in 

1 3 

**84** Page 12 of 34 

Nano-Micro Lett. (2023) 15:84 



**Fig. 7   a** SEM of _h_ ZnO and  Al2O3 substrates before (left) and after (right) deposition of perovskite layer. Reproduced with permission from Ref. [131]. Copyright 2016, Royal Society of Chemistry. **b** FTIR spectra of ZnO films on glass annealed at various temperatures. **c** Photographs of  CH3NH3PbI3 films deposited on thermally pretreated ZnO layers and heated to 100 °C for the indicated time: top row (left to right): pretreated at 25, 100, 200 °C. Bottom row (left to right): pretreated at 300 °C, 400 °C, and  SiO2/CH3NH3PbI3. **b** , **c** Reproduced with permission from Ref. [132]. Copyright 2015, American Chemical Society. **d** High-resolution of O 1 _s_ XPS core level spectra of ZnO with annealing at 200 °C for 1 h in air. **e** XRD patterns and photographs of perovskite film on annealed ZnO without thermal annealing and annealing at 100 °C for 30 min. **d** , **e** Reproduced with permission from Ref. [133]. Copyright 2015, American Chemical Society. (Color figure online) 

reduced electron mobility of ZnO and deteriorative chemical stability of PSCs. This neutralization reaction can be presented in the following reaction [127]: 

2 _HI_ + _ZnO_ → _ZnI_ 2 + _H_ 2 _O_ (49) 

SnO2 is widely used in PSCs owing to its good electron transport ability and chemical stability. However, the interactions between the Cl-containing  SnO2 and perovskite still exist. Recently, Seok et al _._ reported that a  FASnClx interlayer at a  SnO2/perovskite interface could be formed by an interfacial reaction between Cl-bonded  SnO2 and Cl-containing FAPbI3 perovskite (Fig. 8a and b) [5], which is related to the easy formation of Sn-based perovskites in the presence of  Cl<sup>−</sup> ,  FA<sup>+</sup> and  Sn<sup>2+</sup> [133, 134]. The coherent interlayer reduces the interfacial charge recombination and enhances charge transport/extraction, achieving stable PSCs with a high PCE of 25.8% (Fig. 8c and d). However, Sn-Cl bonds 

did not form when the Cl-containing  FAPbI3 solution was applied on a pure  SnO2 surface. In comparison, Cl-bonded SnO2 can interact with  Cl<sup>−</sup> -free  FAPbI3 precursor to form Sn-I bonds by  Cl<sup>−</sup> –I<sup>−</sup> exchange. In addition, Pang et al _._ also discovered the spontaneous ion-exchange reaction between Cl<sup>−</sup> and  I<sup>−</sup> at the  SnOx-Cl/MAPbI3 interface (Fig. 8e and f), which could effectively passivate the physical contact defects. The diffusion of  Cl<sup>−</sup> in the  MAPbI3 films promoted the grain longitudinal growth and decreased the GB density [135]. It is worth noting that the reactions between  SnOx–Cl and perovskite effectively passivate the interface defects, thereby improving the photovoltaic performance and chemical stability of the PSCs. 

Fullerene derivatives, like phenyl-C61-butyric acid methyl ester (PCBM) and [6, 6]-Phenyl-C71-butyric acid methyl ester  (PC71BM), are another type of popularly used electron transport materials particularly in inverted PSCs. It’s 

© The authors 

https://doi.org/10.1007/s40820-023-01046-0 

Page 13 of 34 **84** 

Nano-Micro Lett. (2023) 15:84 



**Fig. 8 a** ToF-SIMS depth profiles for the perovskite and Cl-bonded  SnO2 on FTO. **b** Simulation of the formation of the  FASnClx interlayer between perovskite and  SnO2. **c** _J_ - _V_ curves of the best-performing device, measured in reverse (red solid line) and forward (blue dashed line) modes. **d** Maximum power point tracking measured for the PSC fabricated using Cl-bonded  SnO2 and Cl-containing  FAPbI3. **a-d** Reproduced with permission from Ref. [5]. Copyright 2021, Springer Nature. **e** UV-vis spectra of  SnOx-Cl, MAI,  SnOx-Cl+MAI, and  SnI4, respectively. **f** XRD pattern of  SnOx-Cl + MAI and reference  MA2SnI6 powder samples, providing the feasibility of the ion-exchange reaction. **e** , **f** Reproduced with permission from Ref. [136]. Copyright 2019, Wiley-VCH. (Color figure online) 

reported that PCBM undergoes an electron transfer reaction with halogens in perovskites to produce PCBM-nX radicals [74, 136]. Additionally, halogens favorably interact with  C70 face rather than O face of  PC71BM through covalent bonds [137]. Such strong interactions can suppress Pb-I antisite defects and ions migration at perovskite/PCBM interfaces, which can lead to improved stability and reduced hysteresis of PSCs [138]. However,  C60, another commonly used ETL in the inverted PSCs, barely undergoes interfacial chemical reactions with perovskites because of its chemical inertness. 

##### **_2.2.2  HTL‑Induced Reactions_** 

In general, the widely used HTLs in inverted PSCs (i.e., p-i-n structure) are mainly poly(3,4-ethylenedioxythiophene) polystyrene sulfonate (PEDOT:PSS) [139, 140], poly[bis(4-phenyl)(2,4,6-trimethylphenyl)amine (PTAA) [141–143] and  NiOx [144, 145]. As an inorganic HTL, NiOx is regarded as a promising HTL candidate with the advantages of good optical transparency, excellent stability 

and low cost [146, 147]. The interaction between  NiOx and perovskite has been studied by many groups. McGehee et al _._ proposed a surface-assisted electron transferproton transfer (ET-PT) reaction mechanism at the  NiOx/ perovskite interface [148]. They deposited various perovskite precursors (MAI, MABr, MACl, CsI, and  PbI2 in acetonitrile solvent, respectively) onto  NiOx surface and observed that only MAI could bleach  NiOx film, which demonstrates that  Ni<sup>≥3+</sup> sites can oxidize  I<sup>−</sup> only in the presence of a proton donor but neither  Br<sup>−</sup> or  Cl<sup>−</sup> because of their much higher oxidation potentials. In conclusion, Ni<sup>≥3+</sup> defect sites can act not only as Lewis acid to oxidize I<sup>−</sup> but also as Brønsted base to deprotonate  CH3NH3+. The perovskite solution was deposited on the various HTLs (PTAA, poly-TPD, and  NiOx) to detect the differences in the perovskite films through XRD analysis. It’s observed that  PbI2 accumulates at the  NiOx/perovskite interface or scatters throughout PTAA-based perovskite. However, only the interfacial  PbI2 can block the extraction of holes resulting in the _Voc_ loss of PSCs. The whole reaction can be shown in Fig. 9a. 

1 3 

**84** Page 14 of 34 

Nano-Micro Lett. (2023) 15:84 



**Fig. 9 a** Schematic of the formation process of  PbI2-xBrx at the interface. **b** Dark and light _J_ - _V_ curves of  Cs0.25FA0.75Pb(Br0.2I0.8)3 perovskite solar cells with 0–3 mol% excess A-site. **a** , **b** Reproduced with permission from Ref.[150]. Copyright 2020, Elsevier. **c** Diagram of the passivation mechanism. **d** Fabrication procedure for perovskite solar cells by R2R process. **e** _J_ - _V_ curves of flexible devices (1.01  cm<sup>2</sup> ) with and without HI treatment. Inset presents the photograph of flexible perovskite solar cells. **f** Normalized PCE of encapsulated PSCs based on  NiOx and  NiOx (HI) hole-transport layers under ambient condition (25–55% relative humidity and 25–35 ℃ ) for 30 days. **c-f** Reproduced with permission from Ref. [146]. Copyright 2021, Royal Society of Chemistry 



<!-- Start of picture text -->
( CH 3 NH 3) PbI 3 +  Ni ≥3+ Ox ↔ Ni ≥2+ OxH  +  PbI 2 +  CH 3 NH 2 ↑ + 1<br>2 I 2<br>(2.2-10)<br><!-- End of picture text -->

According to reaction Eq. 2.2-10, the resulting A-site deficient in this region increases interface recombination and reduces chemical stability of PSCs. The study found that 1–5 mol% excess A-site cations were incorporated into the perovskite precursor solution to prevent the reaction above. Therefore, the formation of  PbI2 layer at the  NiOx/ perovskite interface is inhabited, and the _V_ oc was improved by > 200 mV as shown in Fig. 9b. 

Wang et al. reported that trivalent nickel compound (NiOOH) on  NiOx HTL surfaces can be reduced to nickel iodide  (NiI2) by soaking the  NiOx HTLs in hydroiodic acid (HI) during roll-to-roll printing of flexible PSCs [144], as shown in Fig. 9c and d, which can enhance  NiOx/perovskite interface contact and ameliorate the work function of NiOx film. The reaction process is shown below: 



<!-- Start of picture text -->
NiOOH  + 3 HI → NiI 2 + 2 H 2 O  + 1<br>2 I 2<br><!-- End of picture text -->



<!-- Start of picture text -->
(2.2-11)<br><!-- End of picture text -->



<!-- Start of picture text -->
Ni 2 O 3 + 6 HI → 2 NiI 2 + 3 H 2 O  +  I 2 (2.2-12)<br><!-- End of picture text -->

Subsequently,  I<sup>−</sup> in  NiI2 can coordinate with Pb in perovskite to form a Pb-I bond, inducing an orderly growth of perovskite lattice and enhancing the crystallinity of the perovskite film. Consequently, flexible PSCs with improved PCE as well as remarkable chemical stability were achieved (Fig. 9e and f). 

In addition to  NiOx, the commonly used HTLs are PEDOT:PSS and PTAA in inverted PSCs. We note that PEDOT:PSS and PTAA are rarely reported to react with perovskites. However, PEDOT:PSS has been shown to corrode ITO due to its acidic composition, which can react with  In2O3 [13, 139, 149, 150]. As a consequence, the dissociated indium ions can diffuse into the perovskite layer and then deteriorate device performance and stability [151, 152]. 

The normal PSCs (i.e. n-i-p structure) using 2,2’,7,7’-Tetrakis[N,N-di(4-methoxyphenyl)amino]-9,9’spirobifluorene (spiro-OMeTAD) as HTL have achieved efficiency records, however, the instability of spiroOMeTAD itself and its additives limits their commercial applications [153]. Therefore, the interfacial reactions between perovskite and spiro-OMeTAD under various conditions have been investigated to improve the device 

© The authors 

https://doi.org/10.1007/s40820-023-01046-0 

Page 15 of 34 **84** 

Nano-Micro Lett. (2023) 15:84 

stability. Sultana et al _._ detected the signal of [spiroOMeTAD(PbI2)nPbI]<sup>+</sup> adducts in the mass spectra and found that the interaction between spiro-OMeTAD and perovskite was beneficial for PSCs operations [38]. In addition, Belmonte et al _._ reported that  I<sup>−</sup> is driven towards the spiro-OMeTAD HTL and react with the oxidized spiro-OMeTAD<sup>+</sup> under a positive bias (Eq. 2.2-13) [49]. This irreversible reaction turns the spiro-OMeTAD<sup>+</sup> into neutral molecule, which prevents the oxidation of spiroOMeTAD [154] and consequently decreases the conductivity of HTL. Hence, this process has a negative effect on the photovoltaic performance and chemical stability of PSCs. 

_spiro_ − _OMeTAD_<sup>+</sup> + _I_<sup>−</sup> → _spiro_ − _OMeTAD_ − _I_ (2.2-13) 

Besides, several common additives such as Lithium bis(trifluoromethanesulfonyl)-imide (Li-TFSI) and 4-tertbutylpyridine (TBP) in spiro-OMeTAD can influence the stability of perovskite active layers. Many studies have shown that the hygroscopic nature of Li-TFSI can accelerate the degradation of perovskite in humid conditions [155, 156]. As shown in Fig. 10a and b, TBP can react with  PbI2 to form new complexes  [PbI2 ∙ _x_ TBP], which disintegrates the perovskite structure and deteriorates the device performance [157, 158]. The reaction can be expressed as follows: 



<!-- Start of picture text -->
PbI 2 +  xTBP  → PbI 2 ⋅ xTBP (2.2-14)<br><!-- End of picture text -->

Chen et al. explored the decomposition of PSCs under operating conditions in the presence of light and  H2O [159]. The crystal evolution processes are displayed in Fig. 10c. As 



**Fig. 10 a** The UV-vis absorption of TBP liquid (dark line) and  PbI2 solution in TBP (red line). **b** Pb 4f7/2 XPS spectra consuming of  PbI2. **a** , **b** Reproduced with permission from Ref. [159]. Copyright 2014, Royal Society of Chemistry. **c** Crystal structural evolution from  CH3NH3PbI3, CH3NH3PbI3·H2O and  PbI2 to PbIOH. **d** FE-SEM images of top views and the cross-section views of relevant phases  CH3NH3PbI3,  PbI2, and PbIOH formed in lead halide perovskite solar cell at different stages. **c** , **d** Reproduced with permission from Ref. [161]. Copyright 2017, American Chemical Society 

1 3 

**84** Page 16 of 34 

Nano-Micro Lett. (2023) 15:84 

mentioned in Sect. 2.1.1,  MAPbI3 can react with  H2O generating intermediate  CH3NH3PbI3·H2O in low-humidity conditions [63, 95, 96], which has little effect on the device performance. However,  CH3NH3PbI3·H2O can further decompose into  PbI2 once exposed to high humidity, destroying the perovskite structure and reducing the chemical stability of PSCs. H2O would further react with axial I of  [PbI6]<sup>4−</sup> to form [PbI4O2]<sup>6−</sup> under light irradiation or in the presence of spiroMeOTAD. Given that the ionic radius of  I<sup>−</sup> (2.06 Å) is significantly bigger than that of  O<sup>2−</sup> (1.26 Å) [136],  [PbI4O2]<sup>6−</sup> is prone to deform. These deformed  [PbI4O2]<sup>6−</sup> octahedrons further connect with each other to become PbIOH with the coordination structure of  [PbI5O3]<sup>9−</sup> . Figure 10d presents the scanning electron microscopy (SEM) images of PSCs at different degradation stages. It’s worth noting that in addition to H2O and light, spiro-MeOTAD is another key factor to stimulate the decomposition of  MAPbI3 into PbIOH, indicating that spiro-OMeTAD has a crucial influence on the chemical stability of PSCs. 

Because of the intrinsic thermal instability of organic HTLs in normal PSCs, a lot of research efforts are devoted to inorganic HTLs [160–162], such as CuSCN, which is a promising candidate due to its low cost and durability [163–165]. It’s reported that the CuSCN can catalyze the thermal degradation process of perovskite films even in the absence of moisture and oxygen [82, 166–168], although the thermal stability of CuSCN itself is excellent.  CH3NH3I and CuSCN can react to form  CH3NH3SCN and CuI as follows: 



<!-- Start of picture text -->
heat<br>( CH 3 NH 3) PbI 3 +  CuSCN � ������ →<br>(2.2-15)<br>CuI  +  PbI 2 +  CH 3 NH 3 SCN<br><!-- End of picture text -->

##### **2.3  Metal Electrodes** 

Lead halide perovskites not only react with the adjacent layers like charges transport layers, but also experience chemical interactions with the top metal electrodes through ions migrations. The common metal electrodes, such as aluminum (Al), silver (Ag) and gold (Au), can be corroded when in contact with hybrid perovskites or air. These metal ions can diffuse through charge transport layers into perovskites and meanwhile the halide species like  I<sup>−</sup> can migrate to the metal electrode, which result in reactions between metal and halide ions. It has been reported that almost all reactions between metal electrode and perovskites cause severe performance 

and stability deterioration of PSCs. Therefore, exploring the reactions of the metal electrodes is helpful to have a better understanding of the chemical stability issues of PSCs. 

##### **_2.3.1  Ag Electrode‑Induced Reactions_** 

Ag is prone to suffer from corrosion or contamination in contact with lead halide perovskite films. Studies found that  I<sup>−</sup> in perovskites can react with spiro-OMeTAD<sup>+</sup> at the interface, resulting in a large amount of  I<sup>−</sup> accumulating in the spiro-OMeTAD layer [49, 169]. Strikingly,  I<sup>−</sup> passes through the Spiro-OMeTAD layer and migrates to the Ag contact, meanwhile, Ag ions also diffuse into the perovskite layer from the top electrode, generating AgI in the PSCs [93, 170, 171]. 

Kato et al _._ reported that moisture can promote the production of AgI and a five-steps mechanism is proposed to understand the observations (Fig. 11a) [171], including (1) diffusion of  H2O into perovskite through the pinholes in spiro-MeOTAD layer; (2)  H2O-induced decomposition of  MAPbI3 and production of volatile species containing I<sup>−</sup> (e.g., HI); (3) Migration of these volatile species to the bottom or top Ag layer; (4) Surface diffusion of the volatile species containing  I<sup>−</sup> ; (5) AgI formation. The chemical reaction of AgI formation can be expressed as follows: 



<!-- Start of picture text -->
2 HI  + 2 Ag  → 2 AgI  +  H 2 ↑ (2.3-1)<br><!-- End of picture text -->

In addition, thermal treatment can also accelerate the formation of AgI in inverted PSCs. In Fig. 11b–d, time-offlight secondary ions mass spectroscopy (ToF–SIMS) tests revealed that thermal treatment triggered a significant accumulation of  I<sup>−</sup> ,  I2−, and  CN− ions at the PCBM/Ag interface, indicating two crucial facts: the decomposition of  MAPbI3 and the diffusion of both  I<sup>−</sup> and  MA<sup>+</sup> ions [172]. The formation of AgI accelerates the release of  MA<sup>+</sup> and  I<sup>−</sup> ions from the GBs of the perovskite layer and reconstructs the grain domains, leading to more defects both in the perovskite films and at the interface. Consequently, the PSCs suffer from degraded performance due to the formation of AgI. 

Ma et al _._ reported electrochemical corrosion of Ag grid electrodes by PEDOT:PSS in flexible PSCs, which is a major reason for the low performance and poor chemical stability of the devices [41]. This redox reaction involves the reduction of the highly conductive PEDOT:PSS layer and the oxidation of the Ag electrode, which is proposed 

© The authors 

https://doi.org/10.1007/s40820-023-01046-0 

Page 17 of 34 **84** 

Nano-Micro Lett. (2023) 15:84 



**Fig. 11   a** Schematic illustration of a proposed mechanism of AgI formation. Reproduced with permission from Ref. [174]. Copyright 2015, Wiley-VCH. ToF-SIMS elemental depth profiles **b** before and **c** after a thermal treatment at 85 °C for 24 h. **d** The depth profiles of  Ag<sup>-</sup> ,  I<sup>-</sup> and CN<sup>-</sup> after different temperature of thermal treatment. **b-d** Reproduced with permission from Ref. [175]. Copyright 2017, Wiley-VCH. **e** The possible reaction mechanism of the PH1000-involved electrochemical corrosion of Ag electrode. Reproduced with permission from Ref. [41]. Copyright 2018, Wiley-VCH 

to be three steps including (Fig. 11e): (1) Ag electrode easily loses an electron to form  Ag<sup>+</sup> with the aid of acidic PEDOT:PSS layer; (2) PEDOT:PSS layer receives an electron and is reduced; (3)  Ag<sup>+</sup> enters into the perovskite precursor solution and reacts with  I<sup>−</sup> to generate AgI. 

Therefore, regardless of the structure of PSCs, the corrosion of Ag electrode is usually ascribed to the chemical reactions between Ag and the components of perovskites, which is achieved through  Ag<sup>+</sup> migration or halide ions diffusion [173–175]. Eventually the formed AgI impedes the charge transport and reduces the photovoltaic performance and chemical stability of PSCs. 

##### **_2.3.2  Au Electrode‑Induced Reactions_** 

Au, an inert metal and a common electrode material [5, 176], has been found to react with lead hybrid perovskite in previous studies [177–181]. Researches show that Au diffuses from the electrode across the HTL into the perovskite layer under certain conditions such as light soaking [182] or heat aging [183], resulting in an irreversible loss in photovoltaic performance and chemical stability of PSCs. Tarasov et al _._ proposed the corrosion mechanism of Au electrode based on its reaction with iodine-based perovskites [184]. Generally, the intensive UV irradiation of perovskite would induce the 

1 3 

**84** Page 18 of 34 

Nano-Micro Lett. (2023) 15:84 

release of volatile  I2 and MAI, forming highly reactive polyiodide melts with a general formula of MAI-nI2. This MAInI2 could react strongly with Au at room temperature and form  [AuI2]<sup>−</sup> and  [AuI4]<sup>−</sup> complexes. Consequently, a new (MA)2Au2I6 phase is observed on the Au interface, which is detrimental to the performance of PSCs. 



<!-- Start of picture text -->
light<br>2 MAI  − nI 2 + 2 Au � ������ �→ ( MA )2 Au 2 I 6 (2.3-2)<br><!-- End of picture text -->

In addition,  MAPbI3/Au interface can catalyze the perovskite degradation reaction. A type of reduction/oxidation reaction termed underpotential deposition (UPD) involving lead, iodine, and hydrogen can occur at the  MAPbI3/Au interface [185]. UPD is a surface adsorption reaction that changes the oxidation state of ions, and occurs spontaneously at a lower voltage than the bulk reaction potential. XPS measurements demonstrate that  Pb<sup>0</sup> UPD<sup>and  I0</sup> UPD<sup>form at  MAPbI</sup> 3<sup>/Au sur-</sup> face, and the whole degradation pathway of  MAPbI3/Au can be described with the following steps (Fig. 12a): (1)  I<sup>−</sup> loses an electron to form  I<sup>0</sup> UPD<sup>that absorbs on the Au surface (Eq. 2.3-</sup> 3), which induces the decomposition of  MAPbI3 into  PbI2 and  CH3NH3+. (2)  CH3NH3+ captures a free electron to form methylamine gas and  H<sup>0</sup> UPD<sup>simultaneously (Eq. 2.3-4). (3)</sup> The adsorbed  I<sup>0</sup> UPD<sup>reacts with  H0</sup> UPD<sup>to generate HI,  I</sup> 2<sup>, or</sup> H2 gases (Eq. 2.3-5, 2.3-6, 2.2-7). (4) The byproduct  CH3NH2 reacts with  PbI2 via PbI  (CH3NH2) interphase to form more 

HI, imines, and  Pb<sup>0</sup> UPD<sup>(Eq. 2.3-8). Eventually, the degradation</sup> reaction of  MAPbI3 will stop when the surface of the Au catalyst is completely covered with  Pb<sup>0</sup> UPD<sup>. Hence, the detrimental</sup> interfacial chemical reactions provide a source for defects and reduce the chemical stability of PSCs. 



<!-- Start of picture text -->
I − � ���� Au → IUPD 0 +  e − (2.3-3)<br><!-- End of picture text -->



<!-- Start of picture text -->
CH 3 NH 3 + +  e − � ���� Au → CH 3 NH 2 ↑ + HUPD 0 (2.3-4)<br><!-- End of picture text -->



<!-- Start of picture text -->
IUPD 0 +  H UPD 0 → HI ↑ (2.3-5)<br><!-- End of picture text -->



<!-- Start of picture text -->
2 I 0 UPD → I 2 (2.3-6)<br><!-- End of picture text -->



<!-- Start of picture text -->
2 H 0 UPD → H 2 ↑ (2.3-7)<br><!-- End of picture text -->



<!-- Start of picture text -->
Au<br>CH 3 NH 2 +  PbI 2 → CH 2 =  NH ↑ + Pb 0 UPD + 2 HI ↑ (2.3-8)<br><!-- End of picture text -->

Notably, Au not only reacts with perovskite through ions migrations but also can be corroded by interaction with the inorganic holes transport material CuSCN. It has been reported that the reactive thiocyanate anions are prone to react with Au electrode under an electrical bias, forming an undesired potential barrier for charge carriers [153, 165, 



**Fig. 12 a** Proposed noble metal catalyzed degradation at  MAPbI3/Au heterojunctions where the byproducts methylamine and  PbI2 (in red) lead to the eventual formation of  Pb<sup>0</sup> . Reproduced with permission from Ref. [188]. Copyright 2019, American Institute of Physics. **b** Proposed chemical corrosion of Al electrode of p-i-n type PSCs by the diffusion of  CH3NH3I. Reproduced with permission from Ref. [192]. Copyright 2020, Wiley-VCH. In situ XRD analysis of the degradation of the LED stack with moist air in the dark: **c** In situ XRD spectra versus time. **d** Integrated XRD peak intensities of key materials versus time. **e** In situ SEM analysis on the LED stack in an environmental chamber at various time points from 0 to 180 min; the last one, SEM image near the boundary of the Al area after 180 min exposure showing that only the area covered with Al undergoes  H2O-mediated decomposition. **c-e** Reproduced with permission from Ref. [193]. Copyright 2016, American Chemical Society 

© The authors 

https://doi.org/10.1007/s40820-023-01046-0 

Page 19 of 34 **84** 

Nano-Micro Lett. (2023) 15:84 

186, 187], which may seriously affect the device performance and chemical stability. 

##### **_2.3.3  Al Electrode‑Induced Reactions_** 

Although Al is commonly employed as the top electrode in inverted PSCs, Al is chemically unstable due to its easy oxidation by air and reactions with lead halide perovskites [171, 188]. For example, Ma et al _._ found that both  CH3NH3+ and  I− can migrate towards the Al electrode through a  PC61BM layer, resulting in the chemical corrosion of the Al electrode and the degradation of the perovskite film [189]. In particular,  CH3NH3I is highly acidic and can react with Al as shown below: 



<!-- Start of picture text -->
6 CH 3 NH 3 I  + 2 Al  → 6 CH 3 NH 2 ↑ +2 AlI 3 + 3 H 2 ↑ (2.3-9)<br><!-- End of picture text -->

For the overall degradation of PSC, the chemical corrosion of Al electrode can be described in Eq. 2.3-10. The reaction process involves the following steps (Fig. 12b) including: (1) formation of  CH3NH3I from perovskite decomposition, (2) diffusion of  CH3NH3I through the thin PC61BM region, (3) reaction between  CH3NH3I and Al, yielding  AlI3,  CH3NH2 and  H2, (4) formation of bubble and volcano-like surface defects owing to the release of  H2 gas, (5) further decomposition of perovskite due to the  Al<sup>3+</sup> diffusion into perovskite layer. 



<!-- Start of picture text -->
6( CH 3 NH 3) PbI 3 + 2 Al  → 2 AlI 3 + 6 PbI 2 + 6 CH 3 NH 2 ↑ +3 H 2 ↑<br>(2.3-10)<br><!-- End of picture text -->

To further investigate the Al-perovskite reactions, Zhao et al _._ employed in situ X-ray diffraction (XRD) analyses (Fig. 12c and d) and SEM measurements (Fig. 12e) to study the redox reactions between the Al electrode and perovskite [190]. The chemical degradation process can be divided into three stages. Stage 1: Al reacts with a perovskite in the presence of moisture, resulting in the reduction of  Pb<sup>2+</sup> to  Pb<sup>0</sup> and the crystal nucleation of  MA4PbI6·2H2O, which can be expressed as follows: 



<!-- Start of picture text -->
2 Al  + 4 ( CH 3 NH 3) PbI 3 + 2 H 2 O  → ( CH 3 NH 3)4 PbI 6 ⋅ 2 H 2 O<br>+ 3 Pb 0 + 2 Al 3+ + 6 I −<br>(2.3-11)<br><!-- End of picture text -->

Stage 2: with the continuous redox reaction between Al and  Pb<sup>2+</sup> , the further loss of  Pb<sup>2+</sup> in  MA4PbI6·2H2O will lead to the formation of MAI as shown below: 



<!-- Start of picture text -->
2 Al  + 3 ( CH 3 NH 3)4 PbI 6 ⋅ 2 H 2 O  → 12 CH 3 NH 3 I<br>(2.3-12)<br>+ 3 Pb 0 + 2 Al 3+ + 6 I − + 2 H 2 O<br><!-- End of picture text -->

Stage 3: Once metal Al is completely oxidized to  Al<sup>3+</sup> , further exposure to moisture could cause  Pb<sup>0</sup> to reoxidize and hydrate forming PbO·xH2O. In addition, volatile MAI gradually disappears due to prolonged exposure to air. Here, moisture not only promotes ions diffusion but also keeps the reactions between Al and  MAPbI3 forward. 

### **3  Strategies for Improving the Chemical Stability** 

Interfacial chemical reaction is a key factor affecting the chemical stability of lead halide PSCs. According to the above discussion, not all the interfacial reactions in PSCs are detrimental to device performance and chemical stability, such as the reactions at  SnOx-Cl/perovskite interface. Therefore, in order to improve the chemical stability of PSCs, it’s necessary to inhibit unfavorable interfacial reactions. Two effective strategies have been proposed to reduce adverse interfacial reactions in the past few years. One is to insert a buffer layer at the contact interface to block ions migration or the invasion of water and oxygen. At present, many materials, such as PMMA [167],  Al2O3 [82], and  Cr2O3 [181], are introduced to optimize contact interfaces as a buffer layer. Another approach is to employ additives, such as 2-amylpyridine [158] and ionic liquids [191], in perovskites to reduce the chemical activity of the reactants. 

##### **3.1  Buffer Layers** 

Various buffer layers have been developed to modify the perovskite surface to prohibit the chemical reactions with various materials, including air,  NiOx, spiro-OMeTAD, CuSCN, TiO2, ZnO, metal electrode and so on, based on different reaction mechanisms. The effective approaches for these interface modifications are detailed as follows. 

_Air/perovskite interface_ : The buffer layer, especially polymer materials, can isolate moisture or oxygen and inhibit the degradation of lead halide perovskite films. For example, hygroscopic polymer poly(ethylene oxide) (PEO) can chemically interact with undercoordinated Pb ions on a perovskite surface, passivating defect sites and reducing charge recombination loss [192]. In Fig. 13a and b, PEO prevents surface hydration reaction of perovskite by absorbing  H2O before perovskites do, leading to greatly improved chemical stability of PSCs. A number of hydrophobic polymers, such 

1 3 

**84** Page 20 of 34 

Nano-Micro Lett. (2023) 15:84 

as polystyrene [193], PTzDPPBTz [91] and carbon-based materials [194], are also used to protect perovskites from H2O. In Fig. 13c, Trichloro(3,3,3-trifl uoropropyl)silane was introduced between a perovskite layer and  C60 ETL, which reacts with a tiny amount of  H2O existing in the perovskite film to form silanols [193]. Then these silanols can automatically cross-link through forming Si–O–Si (siloxane) bonds to make the insulating layer protect the underlying perovskite film from water erosion. 

It has been reported that low-dimensional materials covering perovskite surfaces can effectively insulate  O2 and improve the perovskite film quality [58]. For example, Kanatzidis et al. inserted a 1D thiazole ammonium lead iodide  (TAPbI3) interfacial layer between the perovskite and 

HTL, which serves to passivate the three-dimensional (3D) perovskite film and prevent oxygen invasion [195], leading to an improvement of device efficiency as well as enhancement of chemical stability. 

_NiOx/perovskite interface:_ The interfacial redox reaction between  Ni<sup>3+</sup> in  NiOx and MAI salt will generate PbI2-rich holes extraction barriers, which can lower _V_ oc and accelerate perovskite degradation by deprotonating precursor amine and oxidizing iodide to interstitial iodine [148]. A modifier layer, trimethylolpropane tris(2-methyl1-aziridinepropionate) (SaC-100), was used to modify the NiOx/MAPbI3 contact interface [83]. Results reveal that N and O atoms in SaC-100 can passivate the uncoordinated  Ni<sup>3+</sup> and  Pb<sup>2+</sup> defects in  NiOx and  MAPbI3 through 



**Fig. 13 a** Schematic illustration of polymer PEO thin film assembled on the perovskite structure. **b** Operational stability test for evolution of PCE of  FA0.87Cs0.13Pb(I0.87Br0.13)3 devices without and with PEO, continuously measured under xenon-lamp simulated fullspectrum AM 1.5, 100 mW  cm<sup>-2</sup> equivalent irradiance in air (humidity ~50 RH%) without any ultraviolet filter, held at maximum power point during ageing, and tested at 0.03-s time intervals. **a** , **b** Reproduced with permission from Ref. [195]. Copyright 2018, Royal Society of Chemistry. **c** Schematic diagram showing the cross-link process of fluoro-silane layer on the perovskite film. Reproduced with permission from Ref. [196]. Copyright 2016, Wiley-VCH. **d** The corresponding redox potential of  I<sup>-</sup> /I3-and the homo levels of P3HT, PDCBT, and spiro-MeOTAD. **e** The unencapsulated device photostability tests under continuous one sun illumination in a home-built chamber filled with  N2. **d, e** Reproduced with permission from Ref. [199]. Copyright 2017, AAAS 

© The authors 

https://doi.org/10.1007/s40820-023-01046-0 

Page 21 of 34 **84** 

Nano-Micro Lett. (2023) 15:84 

producing Lewis adducts, respectively. In addition, the reaction between  NiOx and  MAPbI3 is suppressed in the presence of SaC-100, which is helpful for improving the conductivity of  NiOx and inhibiting the degradation of MAPbI3 films. 

_Spiro-OMeTAD/perovskite interface_ : Buffer layer materials can not only resist the invasion of air, but also block the undesired contacts between adjacent layers. For example, Wang et al _._ reported an effective buffer layer montmorillonite (MMT), which was inserted between perovskite and spiro-OMeTAD to prevent TBP from reacting with  PbI2, because MMT can interact with TBP and build its intercalated structure by hydrogen bond. Consequently, the efficiency and chemical stability of PSCs are largely improved simultaneously [157].  I2 deriving from perovskite tends to react with HTLs, such as Spiro-OMeTAD, whose HOMO level is close to the oxidation potential of  I<sup>−</sup> /I3− (~ − 5.0 eV). In Fig. 13d, depositing a polythiophene derivative with a lower HOMO level approaching − 5.3 eV on the perovskite surface can effectively suppress  I<sup>−</sup> /I3− reaction, resulting in PSCs with enhanced efficiency and stability (Fig. 13e) [196]. 

_CuSCN/perovskite interface:_ In order to promote the chemical stability of PSCs with CuSCN HTLs, it’s necessary to insert a buffer layer between perovskite and CuSCN. Snaith et al _._ not only introduced mesoporous  Al2O3 at the perovskite/CuSCN interface to reduce the contact area of CuSCN with perovskite, but also encapsulated the complete cell with PMMA to prevent degradation products from release [82]. It has been found that if an electrical bias is 

applied on the PSC, an electrical potential-induced reaction between Au and  SCN<sup>−</sup> would occur, leading to poor operational stability of PSCs. Therefore, a thin reduced graphene oxide (rGO) interlayer was introduced between CuSCN and Au electrode to migrate the degradation reaction [165]. In addition,  Cu2O [197] and Cs:NiOx [198] interfacial layers were also used to reduce these detrimental interfacial chemical reaction for PSCs. 

_TiO2/perovskite interface_ : Ito et al _._ performed light irradiation tests of PSCs with/without a  Sb2S3 inserted layer between  TiO2 and  MAPbI3 [124]. For the device without Sb2S3, the black  MAPbI3 layers completely decompose to yellow  PbI2 by losing HI and  CH3NH2. On the other hand, the device with  Sb2S3 can deactivate the reaction of  I<sup>−</sup> /I2 at the surface of  TiO2, so the  MAPbI3 layer is stable and durable against light exposure as shown in Fig. 14a. 

_ZnO/perovskite interface_ : A thin layer of MgO and protonated ethanolamine were in sequence deposited on the ZnO surface to resolve the poor chemical stability of ZnO-based device [199]. Moreover, 1,2-ethanedithiol [200], poly(ethylenimine) [132] and graphene oxide quantum dots [126] can also play the same role. 

_Metal/perovskite interface_ : The chemical instability of PSCs induced by metal electrode corrosion can be suppressed by interfacial modifications.  I<sup>−</sup> in the perovskite can migrate to an Al electrode through PCBM layer to react with Al, forming aluminum iodide at the Al/perovskite interface. A bathocuproine (BCP) buffer layer has been reported to insert the interface between the Al 



**Fig. 14 a** Variation of photoenergy conversion efficiencies of solar cells during light exposure (AM1.5, 100 mW  cm<sup>-2</sup> ) without encapsulation in air for 12 h. Reproduced with permission from Ref. [125]. Copyright 2014, American Chemical Society. Composition depth profiles of the perovskite devices by SIMS: **b** with only PCBM as ETL; **c** with PCBM/ZnO bilayer as ETL. **b, c** Reproduced with permission from Ref. [204]. Copyright 2015, Elsevier. **d** Schematic energy level diagrams of cells with PCBM/Ag and PCBM/AgAl. Reproduced with permission from Ref. [206]. Copyright 2016, Elsevier. (Color figure online) 

1 3 

**84** Page 22 of 34 

Nano-Micro Lett. (2023) 15:84 

electrode and  PC61BM [189]. Test results support that this buffer layer can block the  CH3NH3I migration and hence prevent the Al electrode from chemical corrosion by  CH3NH3I, improving the chemical stability of the PSCs. Qiu et al _._ introduced a ZnO layer between PCBM and an Al electrode to prevent perovskite from reacting with Al, ToF–SIMS characterizations demonstrated that ZnO layer can effectively inhibit the diffusion of  I<sup>−</sup> ions (Fig. 14b and c) [201]. 

Cr/Cr2O3 interlayer provides a buffer to shield top Ag electrodes from chemical corrosion caused by HI liberated from the  MAPbI3 degradation [181, 202]. Compared with pure Ag, an AgAl alloy electrode shows much higher stability in aging tests, which is related to  AlOx formed at the PCBM/AgAl interface during thermal evaporation and aging [203]. In Fig. 14d, this  AlOx interlayer can suppress the migration of Ag atoms to the active layer, strengthen the metal contact with PCBM and prevent moisture encroachment. In addition, nanostructured carbon layers, including N-doped graphene, PCBM and carbon quantum dots, were inserted between a perovskite layer and an Ag electrode to block  I<sup>−</sup> and Ag diffusion [204]. The degradation reaction of perovskite by ions migration was ultimately inhibited, and thus the chemical stability of PSCs was greatly enhanced. Moreover, a graphene barrier between CuSCN and Au can inhibit  I<sup>−</sup> migration and perfectly block Au diffusion, as shown in Fig. 15a–c [205], successfully restraining undesired chemical reactions between  I<sup>−</sup> and the Au electrode. Many groups introduced stable buffer layers through interfacial reactions to reduce ions migration [206]. For example, hexamethyldisilathiane is deposited on a perovskite surface to react with  Pb<sup>2+</sup> and form stable PbS buffer layer, which can effectively suppress  I<sup>−</sup> diffusion and prevent corrosion of metal electrodes [207]. 

##### **3.2  Additives Engineering** 

_Water-induced reactions_ : Various additives have been demonstrated to change the physical or/and chemical properties of metal halide perovskites and thus improve the moisture-/ oxygen-/light- stability of the materials [208]. For example, a fluorinated additive named 1,1,1-trifluoro-ethylammonium iodide (FEAI) was introduced into  MAPbI3 to reduce the moisture-induced degradation reactions, because the 

hydrophobic  CF3-terminal group on the perovskite surface resist the invasion of moisture [209]. Zhao et al _._ employed hygroscopic polyethylene glycol (PEG) scaffold to fabricate moisture-stable perovskite films because the omnipresent PEG molecules can absorb  H2O efficiently. The resulting compact moisture barrier around perovskite crystal grains can prevent water from penetrating into the films [210]. The additive ethyl 2-cyanoacrylate (E2CA) can spontaneously polymerize into a compact polymer once exposed to moisture as shown in Fig. 15d and e, blocking the penetration channels of moisture due to its hydrophobic nature [211]. Moreover, poly(4-vinylpyridine) (PVP) [212], poly(ethylene oxide) (PEO) [192], and trimethylolpropane triacrylate (TMTA) [213] can also be used as additives to reduce the reactions between perovskite and  H2O. 

_Oxygen-induced reactions_ : Snaith et al _._ introduced the ionic liquid 1-butyl-3-methylimidazolium tetrafluoroborate (BMIMBF4) into perovskite precursor and found that [BMIM]<sup>+</sup> cations were bound to the surface sites, hence suppressing the surface degradation reactions induced by oxygen or moisture adsorption (Fig. 15f) [214]. The thiourea has been demonstrated to form Pb–S bonds on the outermost layer of perovskite, which efficiently suppressed the absorption of oxygen and prevented the formation of superoxide [215]. 

_Light-induced reactions_ : The solid ionic additive 1-butyl1-methylpiperidinium tetrafluoroborate  ([BMP]<sup>+</sup> [BF4]<sup>−</sup> ) was adopted to enhance the photostability of PSCs under fullspectrum sunlight [191]. It’s reported that the generation of  I2 under illumination is one of the main factors causing the photo-degradation of perovskites [216]. The interstitial I<sup>−</sup> ions capture the holes to become neutral interstitial iodine atoms, and these neutral atoms need to diffuse and combine to produce  I2 [112].  [BMP]<sup>+</sup> [BF4]<sup>−</sup> therefore suppressed the photochemical reactions of perovskite by reducing the surface defects, such as interstitial pairs and iodide vacancies, and retarding diffusion of neutral iodine interstitials. 

_CTL-induced reactions_ : The additives can also inhibit undesirable reactions occurring at charges transport layer/ perovskite interfaces. Han et al _._ used a new additive 2-amylpyridine (2-Py) to replace TBP in Spiro-OMeTAD and found that the corrosion of perovskite was suppressed [158]. The existence of the amyl chain at the ortho-position of pyridine in 2-Py is vital to restrain the perovskite degradation reaction, which is attributed to the following aspects: 1) the amyl chain near the nitrogen atom can reduce the 

© The authors 

https://doi.org/10.1007/s40820-023-01046-0 

Page 23 of 34 **84** 

Nano-Micro Lett. (2023) 15:84 



**Fig. 15** The iodide ion  (I<sup>-</sup> ) and Au diffusion in CuSCN/Au and CuSCN/GRP (3)/Au PSCs. **a** Schematic of the diffusion process during the light illumination under an applied electrical bias and dark state without the bias. Cross-sectional STEM images of CuSCN/Au **b** and CuSCN/GRP (3)/Au PCSs **c** after 3 cycles of continuous light illumination (12 h) and dark state (12 h). The scale bar is 200 nm. The EDX scan (I and Au) along the vertical lines (a´, b´, and c´) are also provided. **a-c** Reproduced with permission from Ref. [208]. Copyright 2020, Elsevier. **d** Chemical structure and moisture induced polymerization of E2CA with marked functional groups: C=C (red), C ≡ N (olive) and C=O (cyan). **e** Schematic illustrations of spontaneous grain polymerization in  MAPbI3-E2CA films. E2CA chemically anchors to GBs with C=O and C ≡ N groups and spontaneously polymerizes to a polymer at GBs when exposed in moisture air. **d** , **e** Reproduced with permission from Ref. [214]. Copyright 2019, Elsevier. **f** XRD patterns of pristine and aged samples of control film and film containing  BMIMBF4 (0.3 mol%) on NiO/FTOcoated glass substrates. The stars represent the decomposition product of  PbI2 in the films. The insets show images of the aged samples (around 2.8 cm × 2.8 cm) after 72 h of light-soaking at 60-65 °C. Reproduced with permission from Ref. [217]. Copyright 2019, Springer Nature. (Color figure online) 

coordination ability of pyridine; 2) the steric hindrance from the o-substitution of pyridine prevents it from penetrating the perovskite. In addition, 2-Py can increase the dissolution and dispersion of Li-TFSI compared with TBP, which has a positive effect on the conductivity of the Spiro-OMeTAD HTL. Other additives, like  TiO2 nanoparticles (NPs)-modified CNT (CNT:TiO2) [217], graphene oxide (GO) [218], 

and 1,6-diazidohexane (N3) [219] can also be introduced into spiro-OMeTAD to minimize the TBP-PbI2 complex formation and hence improve the chemical stability of the perovskite/HTL interface. 

_Metal electrode-induced reactions_ : It has been reported that the ions migration can initiate the degradation of devices [113, 220], which can be efficiently inhibited by 

1 3 

**84** Page 24 of 34 

Nano-Micro Lett. (2023) 15:84 

some additives with special functional groups. For example, caffeine with two conjugated carboxyl groups interacts strongly with  Pb<sup>2+</sup> ions to slow down the perovskite crystal growth and thus produce high-quality films [221]. In Fig. 16, the Energy-dispersive X-ray spectra (EDX) mapping shows that Ag can diffuse into the whole perovskite region and I<sup>−</sup> ions also migrate through the PTAA layer in the control device, while there is no obvious indication of such similar ions migrations in the caffeine-incorporated device. The caffeine significantly suppresses ions migration, and hence the chemical stability of PSCs is effectively enhanced. Chen et al. employed the methimazole (MMI) to form the MMIPbI2 complex in situ at the GBs, and these surface patches can also effectively suppress Ag diffusion and simultaneously retard  I<sup>−</sup> migration [222]. 

The multifunctional additive of dipentaerythritol pentaacrylate (DPPA) can impede  I<sup>−</sup> movements due to synergistic effects of its functional groups [223]. The  CH2=CH groups in DPPA crosslink at GBs and block the channels of ions migrations. And the -OH groups in DPPA can bond with  I<sup>−</sup> in the perovskite through hydrogen bond interaction, chemically immobilizing these migrated  I<sup>−</sup> . In addition, the polystyrene (PS) [224] and PCBM [74] can also obstruct ions migrations across GBs and dissociated ions can only move around their original sites. Therefore, the problem of chemical stability induced by ions migration can be well solved. 

### **4  Conclusions and Outlook** 

Although lead halide PSCs have already achieved a high certified PCE up to 25.7% through a low-cost and simple fabrication process, the long-term stability still lags far behind the commercial application standard. Therefore, the top priority is to explore the degradation mechanism of lead halide PSCs in more depth, which is helpful for achieving high-efficiency and stable devices. As one of the most important factors influencing the photovoltaic performance and chemical stability of PSCs, interfacial chemical reactions due to environment conditions, interface contacts and metal electrode are systematically elucidated in this paper. Their reaction mechanisms as well as influence on interface defects, nonradiative recombination and degradation process are summarized. Up to now, there is no unified theory that generalizes all interface reactions. For example, lead halide perovskites degrade easily to form  PbI2 and other lead-containing compounds once exposed to humid environment.  O2 capture photo-induced electrons to generate superoxide  O2·− with the aid of light, which can induce quick degradation of lead halide perovskite films. In addition, some chemical reactions at charge transport layers/perovskite interface can produce undesirable interfacial defects and reduce charge transport capacity of ETL or HTL, eventually deteriorate the chemical stability and photovoltaic performance of PSCs. It’s noteworthy that Cl-containing  SnO2 ETL can react friendly with lead halide perovskites to passivate the interface defects and improve the device efficiency. The interfacial reactions are 



**Fig. 16   a-f** Energy-dispersive X-ray spectra (EDX) mapping of the aged pure PVSK device **a** Ag, **b** I, and **c** Pb, and the aged caffeine-containing PVSK device **d** Ag, **e** I, and **f** Pb. **g** , **h** EDX line scans of **g** aged pure PVSK device and **h** aged caffeine-containing PVSK device. Reproduced with permission from Ref. [224]. Copyright 2019, Elsevier. (Color figure online) 

© The authors 

https://doi.org/10.1007/s40820-023-01046-0 

Page 25 of 34 **84** 

Nano-Micro Lett. (2023) 15:84 

induced by ions migrations, for example,  I<sup>−</sup> can diffuse into a metal electrode and simultaneously metal ions can also migrate through the perovskite, which corrode the metal electrode and decrease the operational lifetime of PSCs. 

At present, various buffer layers or additives have been employed to suppress the detrimental interfacial reactions and optimize the device performance as well as long-term stability. Therefore, it’s necessary to investigate the chemical properties of additives or buffer layer materials in depth, because their different functional groups may play completely different roles in the photovoltaic performance. The fluorine-containing additives can improve the hydrophobic properties of lead halide perovskite films, and effectively reduce the humidity-induced degradation of PSCs. The detrimental  I2 in the lead halide perovskite easily induces the shallow charge traps and accelerates the light-decomposition of perovskite. The hydrazine functional group can reduce these  I2 in perovskite precursor solutions to  I<sup>−</sup> , which significantly improve the light stability of perovskites. In addition, more attentions should be paid to benign chemical reaction in PSCs and thus we can make use of these reactions to further improve the efficiency and stability of PSCs. For example, the organic long chain amine (e.g. phenylethylamine, butylamine) can react with  PbI2 to form stable 2D perovskite on the bulk perovskite surface, contributing to the decreased non-radiative recombination and enhanced water resistance of 3D perovskite films. Investigating novel and stable charge transport layer and electrode materials is also of significance for the chemical stability of PSCs. Future molecular design of charge transport materials should consider the energy level alignment, high carrier mobility and stability. The cheap and chemically stable carbon electrode might be an alternative to reduce the cost and deterioration for lead halide PSCs. It’s expected that rational management of interfacial chemical reactions in the whole PSCs will lead to substantial performance enhancement, paying the way for the commercialization of PSCs in the future. 

**Acknowledgements** This work is financially supported by the Research Grants Council (RGC) of Hong Kong, China (Project No. 15306822), Innovation and Technology Commission of Hong Kong, China (Innovation and Technology Fund-Guangdong-Hong Kong Technology Cooperation Funding Scheme (ITF-TCFS), Project No. GHP/042/19SZ). This work is financially supported by the Research Institute of Intelligent Wearable Systems of the Hong Kong Polytechnic University, Hong Kong, China (Project Code: CD46). The work was supported by the funding for Projects of Strategic Importance of the Hong Kong Polytechnic University 

(Project Code: 1-ZE2X). The work is also supported by Shenzhen Science and Technology Innovation Commission, (Project No.: SGDX20210823103401011). 

**Funding** Open access funding provided by Shanghai Jiao Tong University. 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http:// creat iveco mmons. org/ licen ses/ by/4. 0/. 

### **References** 

1. A. Kojima, K. Teshima, Y. Shirai, T. Miyasaka, Organometal halide perovskites as visible-light sensitizers for photovoltaic cells. J. Am. Chem. Soc. **131** , 6050 (2009). https:// doi. org/ 10. 1021/ ja809 598r 

2. J.-H. Im, C.-R. Lee, J.-W. Lee, S.-W. Park, N.-G. Park, 6.5% efficient perovskite quantum-dot-sensitized solar cell. Nanoscale **3** , 4088 (2011). https:// doi. org/ 10. 1039/ C1NR1 0867K 

3. M.M. Lee, J. Teuscher, T. Miyasaka, T.N. Murakami, H.J. Snaith, Efficient hybrid solar cells based on meso-superstructured organometal halide perovskites. Science **338** , 643 (2012). https:// doi. org/ 10. 1126/ scien ce. 12286 04 

4. J.H. Heo, S.H. Im, J.H. Noh, T.N. Mandal, C.S. Lim et al., Efficient inorganic-organic hybrid heterojunction solar cells containing perovskite compound and polymeric hole conductors. Nat. Photonics **7** , 487 (2013). https:// doi. org/ 10. 1038/ Nphot on. 2013. 80 

5. H. Min, D.Y. Lee, J. Kim, G. Kim, K.S. Lee et al., Perovskite solar cells with atomically coherent interlayers on SnO2 electrodes. Nature **598** , 444 (2021). https:// doi. org/ 10. 1038/ s41586- 021- 03964-8 

6. H.-S. Kim, C.-R. Lee, J.-H. Im, K.-B. Lee, T. Moehl et al., Lead iodide perovskite sensitized all-solid-state submicron thin film mesoscopic solar cell with efficiency exceeding 9%. Sci. Rep. **2** , 591 (2012). https:// doi. org/ 10. 1038/ srep0 0591 

7. C. Jiang, J. Zhou, H. Li, L. Tan, M. Li et al., Double layer composite electrode strategy for efficient perovskite solar cells with excellent reverse-bias stability. Nano-Micro Lett. **15** , 12 (2022). https:// doi. org/ 10. 1007/ s40820- 022- 00985-4 

1 3 

**84** Page 26 of 34 

Nano-Micro Lett. (2023) 15:84 

8. W. Travis, E.N.K. Glover, H. Bronstein, D.O. Scanlon, R.G. Palgrave, On the application of the tolerance factor to inorganic and hybrid halide perovskites: a revised system. Chem. Sci. **7** , 4548 (2016). https:// doi. org/ 10. 1039/ C5SC0 4845A 

9. L. Qiu, S. He, L.K. Ono, Y. Qi, Progress of surface science studies on  ABX3-based metal halide perovskite solar cells. Adv. Energy Mater. **10** , 1902726 (2020). https:// doi. org/ 10. 1002/ aenm. 20190 2726 

10. M. Anaya, G. Lozano, M.E. Calvo, H. Míguez,  ABX3 perovskites for tandem solar cells. Joule **1** , 769 (2017). https:// doi. org/ 10. 1016/j. joule. 2017. 09. 017 

11. C. Yi, J. Luo, S. Meloni, A. Boziki, N. Ashari-Astani et al., Entropic stabilization of mixed A-cation  ABX3 metal halide perovskites for high performance perovskite solar cells. Energy Environ. Sci. **9** , 656 (2016). https:// doi. org/ 10. 1039/ C5EE0 3255E 

12. S. Wang, T. Sakurai, W. Wen, Y. Qi, Energy level alignment at interfaces in metal halide perovskite solar cells. Adv. Mater. Interfaces **5** , 1800260 (2018). https:// doi. org/ 10. 1002/ admi. 20180 0260 

13. L. Meng, J. You, T.-F. Guo, Y. Yang, Recent advances in the inverted planar structure of perovskite solar cells. Acc. Chem. Res. **49** , 155 (2016). https:// doi. org/ 10. 1021/ acs. accou nts. 5b004 04 

14. Z. Liu, A. Zhu, F. Cai, L. Tao, Y. Zhou et al., Nickel oxide nanoparticles for efficient hole transport in p-i-n and n-i-p perovskite solar cells. J. Mater. Chem. A **5** , 6597 (2017). https:// doi. org/ 10. 1039/ C7TA0 1593C 

15. C. Momblona, L. Gil-Escrig, E. Bandiello, E.M. Hutter, M. Sessolo et al., Efficient vacuum deposited p-i-n and n-i-p perovskite solar cells employing doped charge transport layers. Energy Environ. Sci. **9** , 3456 (2016). https:// doi. org/ 10. 1039/ C6EE0 2100J 

16. Z. Zhang, J. Liang, J. Wang, Y. Zheng, X. Wu et al., Resolving mixed intermediate phases in methylammonium-free Sn–Pb alloyed perovskites for high-performance solar cells. Nano-Micro Lett. **14** , 165 (2022). https:// doi. org/ 10. 1007/ s40820- 022- 00918-1 

17. A. Polman, M. Knight, E.C. Garnett, B. Ehrler, W.C. Sinke, Photovoltaic materials: present efficiencies and future challenges. Science **352** , aad4424 (2016). https:// doi. org/ 10. 1126/ scien ce. aad44 24 

18. F. Huang, M. Li, P. Siffalovic, G. Cao, J. Tian, From scalable solution fabrication of perovskite films towards commercialization of solar cells. Energy Environ. Sci. **12** , 518 (2019). https:// doi. org/ 10. 1039/ C8EE0 3025A 

19. F. Yang, L. Dong, D. Jang, B. Saparov, K.C. Tam et al., Low temperature processed fully printed efficient planar structure carbon electrode perovskite solar cells and modules. Adv. Energy Mater. **11** , 2101219 (2021). https:// doi. org/ 10. 1002/ aenm. 20210 1219 

20. A. Mei, X. Li, L. Liu, Z. Ku, T. Liu et al., A hole-conductor– free, fully printable mesoscopic perovskite solar cell with high stability. Science **345** , 295 (2014). https:// doi. org/ 10. 1126/ scien ce. 12547 63 

21. H. Zhou, Q. Chen, G. Li, S. Luo, T.-B. Song et al., Interface engineering of highly efficient perovskite solar cells. Science **345** , 542 (2014). https:// doi. org/ 10. 1126/ scien ce. 12540 50 

22. J.-P. Correa-Baena, M. Saliba, T. Buonassisi, M. Grätzel, A. Abate et al., Promises and challenges of perovskite solar cells. Science **358** , 739 (2017). https:// doi. org/ 10. 1126/ scien ce. aam63 23 

23. X. Lin, Y. Wang, H. Su, Z. Qin, Z. Zhang et al., An insitu formed tunneling layer enriches the options of anode for efficient and stable regular perovskite solar cells. Nano-Micro Lett. **15** , 10 (2022). https:// doi. org/ 10. 1007/ s40820- 022- 00975-6 

24. I. Massiot, A. Cattoni, S. Collin, Progress and prospects for ultrathin solar cells. Nat. Energy **5** , 959 (2020). https:// doi. org/ 10. 1038/ s41560- 020- 00714-4 

25. M.A. Green, E.D. Dunlop, J. Hohl-Ebinger, M. Yoshita, N. Kopidakis et al., Solar cell efficiency tables (version 59). Prog. Photovolt. **30** , 3–12 (2022). https:// doi. org/ 10. 1002/ pip. 3506 

26. Japan Electrical Safety & Environment Technology Laboratories, Chinese Perovskite Tech Firm Wuxi Utmost Light Claims 20.5% ‘World Record’ Efficiency For Perovskite Solar Mini Module, Certified By Japan’s JET; Plans To Build Large Area Perovskite Solar Module Production Lines, http:// taiya ngnews. info/ techn ology/ 20-5- worldrecord- effic iency- for- perov skite- solar- module/, 2021. 

27. L. Fu, H. Li, L. Wang, R. Yin, B. Li et al., Defect passivation strategies in perovskites for an enhanced photovoltaic performance. Energy Environ. Sci. **13** , 4017 (2020). https:// doi. org/ 10. 1039/ D0EE0 1767A 

28. W.E.I. Sha, X. Ren, L. Chen, W.C.H. Choy, The efficiency limit of  CH3NH3PbI3 perovskite solar cells. Appl. Phys. Lett. **106** , 221104 (2015). https:// doi. org/ 10. 1063/1. 49221 50 

29. S. Draguta, J.A. Christians, Y.V. Morozov, A. Mucunzi, J.S. Manser et al., A quantitative and spatially resolved analysis of the performance-bottleneck in high efficiency, planar hybrid perovskite solar cells. Energy Environ. Sci. **11** , 960 (2018). https:// doi. org/ 10. 1039/ C7EE0 3654J 

30. X. Ren, Z. Wang, W.E.I. Sha, W.C.H. Choy, Exploring the way to approach the efficiency limit of perovskite solar cells by drift-diffusion model. ACS Photonics **4** , 934 (2017). https:// doi. org/ 10. 1021/ acsph otoni cs. 6b010 43 

31. W.E.I. Sha, H. Zhang, Z.S. Wang, H.L. Zhu, X. Ren et al., Quantifying efficiency loss of perovskite solar cells by a modified detailed balance model. Adv. Energy Mater. **8** , 1701586 (2018). https:// doi. org/ 10. 1002/ aenm. 20170 1586 

32. X. Zhao, N.-G. Park, Stability issues on perovskite solar cells. Photonics **2** , 1139 (2015). https:// doi. org/ 10. 3390/ photo nics2 041139 

33. A. Aftab, M.I. Ahmad, A review of stability and progress in tin halide perovskite solar cell. Sol. Energy **216** , 26 (2021). https:// doi. org/ 10. 1016/j. solen er. 2020. 12. 065 

34. R. Wang, M. Mujahid, Y. Duan, Z.K. Wang, J. Xue et al., A review of perovskites solar cell stability. Adv. Funct. Mater. **29** , 1808843 (2019). https:// doi. org/ 10. 1002/ adfm. 20180 8843 

© The authors 

https://doi.org/10.1007/s40820-023-01046-0 

Page 27 of 34 **84** 

Nano-Micro Lett. (2023) 15:84 

35. J. Feng, X. Zhu, Z. Yang, X. Zhang, J. Niu et al., Record efficiency stable flexible perovskite solar cell using effective additive assistant strategy. Adv. Mater. **30** , 1801418 (2018). https:// doi. org/ 10. 1002/ adma. 20180 1418 

36. M.M. Tavakoli, P. Yadav, R. Tavakoli, J. Kong, Surface engineering of  TiO2 ETL for highly efficient and hysteresis-less planar perovskite solar cell (21.4%) with enhanced opencircuit voltage and stability. Adv. Energy Mater. **8** , 1800794 (2018). https:// doi. org/ 10. 1002/ aenm. 20180 0794 

37. L. Meng, J. You, Y. Yang, Addressing the stability issue of perovskite solar cells for commercial applications. Nat. Commun. **9** , 1 (2018). https:// doi. org/ 10. 1038/ s41467- 018- 07255-1 

38. N. Sultana, N.J. Demarais, D. Shevchenko, P.J. Derrick, Laser desorption/ionization mass spectrometry of perovskite solar cells: identification of interface interactions and degradation reactions. Sol. RRL **2** , 1800022 (2018). https:// doi. org/ 10. 1002/ solr. 20180 0022 

39. J. Wei, Q. Wang, J. Huo, F. Gao, Z. Gan et al., Mechanisms and suppression of photoinduced degradation in perovskite solar cells. Adv. Energy Mater. **11** , 2002326 (2021). https:// doi. org/ 10. 1002/ aenm. 20200 2326 

40. N. Li, X. Niu, Q. Chen, H. Zhou, Towards commercialization: the operational stability of perovskite solar cells. Chem. Soc. Rev. **49** , 8235 (2020). https:// doi. org/ 10. 1039/ D0CS0 0573H 

41. J. Wang, X. Chen, F. Jiang, Q. Luo, L. Zhang et al., Electrochemical corrosion of Ag electrode in the silver grid electrode-based flexible perovskite solar cells and the suppression method. Sol. RRL **2** , 1800118 (2018). https:// doi. org/ 10. 1002/ solr. 20180 0118 

42. X. Wang, K. Rakstys, K. Jack, H. Jin, J. Lai et al., Engineering fluorinated-cation containing inverted perovskite solar cells with an efficiency of >21% and improved stability towards humidity. Nat. Commun. **12** , 52 (2021). https:// doi. org/ 10. 1038/ s41467- 020- 20272-3 

43. Z. Liu, L. Qiu, L.K. Ono, S. He, Z. Hu et al., A holistic approach to interface stabilization for efficient perovskite solar modules with over 2,000-hour operational stability. Nat. Energy **5** , 596 (2020). https:// doi. org/ 10. 1038/ s41560- 020- 0653-2 

44. S. Yang, S. Chen, E. Mosconi, Y. Fang, X. Xiao et al., Stabilizing halide perovskite surfaces for solar cell operation with wide-bandgap lead oxysalts. Science **365** , 473 (2019). https:// doi. org/ 10. 1126/ scien ce. aax32 94 

45. P. Hang, J. Xie, C. Kan, B. Li, Y. Zhang et al., Stabilizing fullerene for burn-in-free and stable perovskite solar cells under ultraviolet preconditioning and light soaking. Adv. Mater. **33** , 2006910 (2021). https:// doi. org/ 10. 1002/ adma. 20200 6910 

46. Y. Rong, Y. Hu, A. Mei, H. Tan, M.I. Saidaminov et al., Challenges for commercializing perovskite solar cells. Science **361** , 8235 (2018). https:// doi. org/ 10. 1126/ scien ce. aat82 35 

47. X. Ma, L. Yang, X. Shang, M. Li, D. Gao et al., Grain boundary defect passivation by in situ formed wide-bandgap lead sulfate for efficient and stable perovskite solar cells. Chem. 

Eng. J. **426** , 130685 (2021). https:// doi. org/ 10. 1016/j. cej. 2021. 130685 

48. J.M. Frost, K.T. Butler, F. Brivio, C.H. Hendon, M. van Schilfgaarde et al., Atomistic origins of high-performance in hybrid halide perovskite solar cells. Nano Lett. **14** , 2584 (2014). https:// doi. org/ 10. 1021/ nl500 390f 

49. J. Carrillo, A. Guerrero, S. Rahimnejad, O. Almora, I. Zarazua et al., Ionic reactivity at contacts and aging of methylammonium lead triiodide perovskite solar cells. Adv. Energy Mater. **6** , 1502246 (2016). https:// doi. org/ 10. 1002/ aenm. 20150 2246 

50. J.A. Christians, P.A. MirandaHerrera, P.V. Kamat, Transformation of the excited state and photovoltaic efficiency of CH3NH3PbI3 perovskite upon controlled exposure to humidified air. J. Am. Chem. Soc. **137** , 1530 (2015). https:// doi. org/ 10. 1021/ ja511 132a 

51. A.M.A. Leguy, Y. Hu, M. Campoy-Quiles, M.I. Alonso, O.J. Weber et al., Reversible hydration of  CH3NH3PbI3 in films, single crystals, and solar cells. Chem. Mater. **27** , 3397 (2015). https:// doi. org/ 10. 1021/ acs. chemm ater. 5b006 60 

52. G. Ren, W. Han, Q. Zhang, Z. Li, Y. Deng et al., Overcoming perovskite corrosion and de-doping through chemical binding of halogen bonds toward efficient and stable perovskite solar cells. Nano-Micro Lett. **14** , 175 (2022). https:// doi. org/ 10. 1007/ s40820- 022- 00916-3 

53. G. Tong, L.K. Ono, Y. Liu, H. Zhang, T. Bu et al., Up-scalable fabrication of  SnO2 with multifunctional interface for high performance perovskite solar modules. Nano-Micro Lett. **13** , 155 (2021). https:// doi. org/ 10. 1007/ s40820- 021- 00675-7 

54. T. Wu, Z. Qin, Y. Wang, Y. Wu, W. Chen et al., The main progress of perovskite solar cells in 2020–2021. NanoMicro Lett. **13** , 152 (2021). https:// doi. org/ 10. 1007/ s40820- 021- 00672-w 

55. Z. Li, Y. Gao, Z. Zhang, Q. Xiong, L. Deng et al., cPCNregulated  SnO2 composites enables perovskite solar cell with efficiency beyond 23%. Nano-Micro Lett. **13** , 101 (2021). https:// doi. org/ 10. 1007/ s40820- 021- 00636-0 

56. D. Bryant, N. Aristidou, S. Pont, I. Sanchez-Molina, T. Chotchuangchutchaval et al., Light and oxygen induced degradation limits the operational stability of methylammonium lead triiodide perovskite solar cells. Energy Environ. Sci. **9** , 1850 (2016). https:// doi. org/ 10. 1039/ c6ee9 0023b 

57. D. Bryant, N. Aristidou, S. Pont, I. Sanchez-Molina, T. Chotchunangatchaval et al., Light and oxygen induced degradation limits the operational stability of methylammonium lead triiodide perovskite solar cells. Energy Environ. Sci. **9** , 1655 (2016). https:// doi. org/ 10. 1039/ C6EE0 0409A 

58. W. Chi, S.K. Banerjee, Achieving resistance against moisture and oxygen for perovskite solar cells with high efficiency and stability. Chem. Mater. **33** , 4269–4303 (2021). https:// doi. org/ 10. 1021/ acs. chemm ater. 1c007 73 

59. G. Niu, X. Guo, L. Wang, Review of recent progress in chemical stability of perovskite solar cells. J. Mater. Chem. A **3** , 8970 (2015). https:// doi. org/ 10. 1039/ C4TA0 4994B 

1 3 

**84** Page 28 of 34 

Nano-Micro Lett. (2023) 15:84 

60. F. Li, M. Liu, Recent efficient strategies for improving the moisture stability of perovskite solar cells. J. Mater. Chem. A **5** , 15447 (2017). https:// doi. org/ 10. 1039/ C7TA0 1325F 

61. J. Jiang, Q. Wang, Z. Jin, X. Zhang, J. Lei et al., Polymer doping for high-efficiency perovskite solar cells with improved moisture stability. Adv. Energy Mater. **8** , 1701757 (2018). https:// doi. org/ 10. 1002/ aenm. 20170 1757 

62. I. Hwang, I. Jeong, J. Lee, M.J. Ko, K. Yong, Enhancing stability of perovskite solar cells to moisture by the facile hydrophobic passivation. ACS Appl. Mater. Interfaces **7** , 17330 (2015). https:// doi. org/ 10. 1021/ acsami. 5b044 90 

63. J. Yang, B.D. Siempelkamp, D. Liu, T.L. Kelly, Investigation of  CH3NH3PbI3 degradation rates and mechanisms in controlled humidity environments using in situ techniques. ACS Nano **9** , 1955 (2015). https:// doi. org/ 10. 1021/ nn506 864k 

64. J. Zhu, D.H. Kim, J.D. Kim, D.G. Lee, W.B. Kim et al., Allin-one Lewis base for enhanced precursor and device stability in highly efficient perovskite solar cells. ACS Energy Lett. **6** , 3425 (2021). https:// doi. org/ 10. 1021/ acsen ergyl ett. 1c014 65 

65. L. Yu, T. Guo, H. Yuan, Z. Zhang, Z. Deng et al., Effective lewis base additive with S-donor for efficient and stable CsPbI2Br based perovskite solar cells. Chem. Eng. J. **420** , 129931 (2021). https:// doi. org/ 10. 1016/j. cej. 2021. 129931 

66. W. Xiang, S. Liu, W. Tress, A review on the stability of inorganic metal halide perovskites: challenges and opportunities for stable solar cells. Energy Environ. Sci. **14** , 2090 (2021). https:// doi. org/ 10. 1039/ D1EE0 0157D 

67. S. Xiong, M. Yuan, J. Yang, J. Song, X. Guo et al., Engineering of the back contact between PCBM and metal electrode for planar perovskite solar cells with enhanced efficiency and stability. Adv. Opt. Mater. **7** , 1900542 (2019). https:// doi. org/ 10. 1002/ adom. 20190 0542 

68. B. Rivkin, P. Fassl, Q. Sun, A.D. Taylor, Z. Chen et al., Effect of ion migration-induced electrode degradation on the operational stability of perovskite solar cells. ACS Omega **3** , 10042 (2018). https:// doi. org/ 10. 1021/ acsom ega. 8b016 26 

69. Z. Yang, B.H. Babu, S. Wu, T. Liu, S. Fang et al., Review on practical interface engineering of perovskite solar cells: from efficiency to stability. Sol. RRL **4** , 1900257 (2020). https:// doi. org/ 10. 1002/ solr. 20190 0257 

70. Y. Xu, Z. Lin, W. Wei, Y. Hao, S. Liu et al., Recent progress of electrode materials for flexible perovskite solar cells. Nano-Micro Lett. **14** , 117 (2022). https:// doi. org/ 10. 1007/ s40820- 022- 00859-9 

71. K.M.M. Salim, S. Masi, A.F. Gualdrón-Reyes, R.S. Sánchez, E.M. Barea et al., Boosting long-term stability of pure formamidinium perovskite solar cells by ambient air additive assisted fabrication. ACS Energy Lett. **6** , 3511 (2021). https:// doi. org/ 10. 1021/ acsen ergyl ett. 1c013 11 

72. H. Zheng, X. Xu, S. Xu, G. Liu, S. Chen et al., The multiple effects of polyaniline additive to improve the efficiency and stability of perovskite solar cells. J. Mater. Chem. C **7** , 4441 (2019). https:// doi. org/ 10. 1039/ C8TC0 5975F 

73. L. Xie, J. Chen, P. Vashishtha, X. Zhao, G.S. Shin et al., Importance of functional groups in cross-linking 

   - methoxysilane additives for high-efficiency and stable perovskite solar cells. ACS Energy Lett. **4** , 2192 (2019). https:// doi. org/ 10. 1021/ acsen ergyl ett. 9b013 56 

74. C. Park, H. Ko, D.H. Sin, K.C. Song, K. Cho, Organometal halide perovskite solar cells with improved thermal stability via grain boundary passivation using a molecular additive. Adv. Funct. Mater. **27** , 1703546 (2017). https:// doi. org/ 10. 1002/ adfm. 20170 3546 

75. Y. Chen, X. Yang, P. Liu, W. Wang, R. Ran et al., Improving moisture/thermal stability and efficiency of CH3NH3PbI3-based perovskite solar cells via gentle butyl acrylate additive strategy. Sol. RRL **5** , 2000621 (2021). https:// doi. org/ 10. 1002/ solr. 20200 0621 

76. J. Xu, J. Cui, S. Yang, Y. Han, X. Guo et al., Unraveling passivation mechanism of imidazolium-based ionic liquids on inorganic perovskite to achieve near-record-efficiency CsPbI2Br solar cells. Nano-Micro Lett. **14** , 7 (2021). https:// doi. org/ 10. 1007/ s40820- 021- 00763-8 

77. W. Zhao, J. Xu, K. He, Y. Cai, Y. Han et al., A special additive enables all cations and anions passivation for stable perovskite solar cells with efficiency over 23%. Nano-Micro Lett. **13** , 169 (2021). https:// doi. org/ 10. 1007/ s40820- 021- 00688-2 

78. S. Tang, Y. Deng, X. Zheng, Y. Bai, Y. Fang et al., Composition engineering in doctor-blading of perovskite solar cells. Adv. Energy Mater. **7** , 1700302 (2017). https:// doi. org/ 10. 1002/ aenm. 20170 0302 

79. Y. Jiang, X. He, T. Liu, N. Zhao, M. Qin et al., Intralayer a-site compositional engineering of ruddlesden–popper perovskites for thermostable and efficient solar cells. ACS Energy Lett. **4** , 1216 (2019). https:// doi. org/ 10. 1021/ acsen ergyl ett. 9b004 03 

80. T. Ozturk, E. Akman, A.E. Shalan, S. Akin, Composition engineering of operationally stable  CsPbI2Br perovskite solar cells with a record efficiency over 17%. Nano Energy **87** , 106157 (2021). https:// doi. org/ 10. 1016/j. nanoen. 2021. 106157 

81. X. Jin, L. Yang, X.-F. Wang, Efficient two-dimensional perovskite solar cells realized by incorporation of  Ti3C2Tx MXene as nano-dopants. Nanomicro. Lett. **13** , 68 (2021). https:// doi. org/ 10. 1007/ s40820- 021- 00602-w 

82. J. Liu, S.K. Pathak, N. Sakai, R. Sheng, S. Bai et al., Identification and mitigation of a critical interfacial instability in perovskite solar cells employing copper thiocyanate holetransporter. Adv. Mater. Interfaces **3** , 1600571 (2016). https:// doi. org/ 10. 1002/ admi. 20160 0571 

83. J. Zhang, J. Long, Z. Huang, J. Yang, X. Li et al., Obstructing interfacial reaction between  NiOx and perovskite to enable efficient and stable inverted perovskite solar cells. Chem. Eng. J. **426** , 131357 (2021). https:// doi. org/ 10. 1016/j. cej. 2021. 131357 

84. S. Guarnera, A. Abate, W. Zhang, J.M. Foster, G. Richardson et al., Improving the long-term stability of perovskite solar cells with a porous  Al2O3 buffer layer. J. Phys. Chem. Lett. **6** , 432 (2015). https:// doi. org/ 10. 1021/ jz502 703p 

85. A. Capasso, F. Matteocci, L. Najafi, M. Prato, J. Buha et al., Few-layer  MoS2 flakes as active buffer layer for stable 

© The authors 

https://doi.org/10.1007/s40820-023-01046-0 

Page 29 of 34 **84** 

Nano-Micro Lett. (2023) 15:84 

   - perovskite solar cells. Adv. Energy Mater. **6** , 1600920 (2016). https:// doi. org/ 10. 1002/ aenm. 20160 0920 

86. X. Zheng, H. Lei, G. Yang, W. Ke, Z. Chen et al., Enhancing efficiency and stability of perovskite solar cells via a high mobility p-type PbS buffer layer. Nano Energy **38** , 1 (2017). https:// doi. org/ 10. 1016/j. nanoen. 2017. 05. 040 

87. K. Chatzimanolis, K. Rogdakis, D. Tsikritzis, N. Tzoganakis, M. Tountas et al., Inverted perovskite solar cells with enhanced lifetime and thermal stability enabled by a metallic tantalum disulfide buffer layer. Nanoscale Adv. **3** , 3124 (2021). https:// doi. org/ 10. 1039/ D1NA0 0172H 

88. H. Zhong, W. Li, Y. Huang, D. Cao, C. Zhang et al., Allinorganic perovskite solar cells with tetrabutylammonium acetate as the buffer layer between the  SnO2 electron transport film and  CsPbI3. ACS Appl. Mater. Interfaces **14** , 5183 (2022). https:// doi. org/ 10. 1021/ acsami. 1c183 75 

89. W. Dong, W. Qiao, S. Xiong, J. Yang, X. Wang et al., Surface passivation and energetic modification suppress nonradiative recombination in perovskite solar cells. Nano-Micro Lett. **14** , 108 (2022). https:// doi. org/ 10. 1007/ s40820- 022- 00854-0 

90. L. Zhu, C. Chen, Y. Weng, F. Li, Q. Lou, Enhancing the performance of inverted perovskite solar cells by inserting a ZnO:TIPD film between PCBM layer and Ag electrode. Sol. Energy Mater. Sol. Cells **198** , 11 (2019). https:// doi. org/ 10. 1016/j. solmat. 2019. 04. 007 

91. C.-Y. Chang, C.-C. Wang, Enhanced stability and performance of air-processed perovskite solar cells via defect passivation with a thiazole-bridged diketopyrrolopyrrole-based π-conjugated polymer. J. Mater. Chem. A **8** , 8593 (2020). https:// doi. org/ 10. 1039/ D0TA0 0978D 

92. J. Chen, L. Zuo, Y. Zhang, X. Lian, W. Fu et al., High-performance thickness insensitive perovskite solar cells with enhanced moisture stability. Adv. Energy Mater. **8** , 1800438 (2018). https:// doi. org/ 10. 1002/ aenm. 20180 0438 

93. Y. Han, S. Meyer, Y. Dkhissi, K. Weber, J.M. Pringle et al., Degradation observations of encapsulated planar CH3NH3PbI3 perovskite solar cells at high temperatures and humidity. J. Mater. Chem. A **3** , 8139 (2015). https:// doi. org/ 10. 1039/ C5TA0 0358J 

94. G. Niu, W. Li, F. Meng, L. Wang, H. Dong et al., Study on the stability of CH3NH3PbI3 films and the effect of postmodification by aluminum oxide in all-solid-state hybrid solar cells. J. Mater. Chem. A **2** , 705 (2014). https:// doi. org/ 10. 1039/ C3TA1 3606J 

95. Q. Wang, B. Chen, Y. Liu, Y. Deng, Y. Bai et al., Scaling behavior of moisture-induced grain degradation in polycrystalline hybrid perovskite thin films. Energy Environ. Sci. **10** , 516 (2017). https:// doi. org/ 10. 1039/ C6EE0 2941H 

96. W. Huang, J.S. Manser, P.V. Kamat, S. Ptasinska, Evolution of chemical composition, morphology, and photovoltaic efficiency of  CH3NH3PbI3 perovskite under ambient conditions. Chem. Mater. **28** , 303 (2016). https:// doi. org/ 10. 1021/ acs. chemm ater. 5b041 22 

97. N. Ahn, K. Kwak, M.S. Jang, H. Yoon, B.Y. Lee et al., Trapped charge-driven degradation of perovskite solar cells. 

   - Nat. Commun. **7** , 13422 (2016). https:// doi. org/ 10. 1038/ ncomm s13422 

98. A.J. Pearson, G.E. Eperon, P.E. Hopkinson, S.N. Habisreutinger, J.T.-W. Wang et al., Oxygen degradation in mesoporous  Al2O3/CH3NH3PbI3-xClx perovskite solar cells: kinetics and mechanisms. Adv. Energy Mater. **6** , 1600014 (2016). https:// doi. org/ 10. 1002/ aenm. 20160 0014 

99. L. Zhang, P.H.L. Sit, Ab initio study of the role of oxygen and excess electrons in the degradation of  CH3NH3PbI3. J. Mater. Chem. A **5** , 9042 (2017). https:// doi. org/ 10. 1039/ C7TA0 1091E 

100. N. Aristidou, I. Sanchez-Molina, T. Chotchuangchutchaval, M. Brown, L. Martinez et al., The role of oxygen in the degradation of methylammonium lead trihalide perovskite photoactive layers. Angew. Chem. Int. Ed. **54** , 8208 (2015). https:// doi. org/ 10. 1002/ anie. 20150 3153 

101. N. Aristidou, C. Eames, I. Sanchez-Molina, X. Bu, J. Kosco et al., Fast oxygen diffusion and iodide defects mediate oxygen-induced degradation of perovskite solar cells. Nat. Commun. **8** , 15218 (2017). https:// doi. org/ 10. 1038/ ncomm s15218 

102. J.S.W. Godding, A.J. Ramadan, Y.-H. Lin, K. Schutt, H.J. Snaith et al., Oxidative passivation of metal halide perovskites. Joule **3** , 2716 (2019). https:// doi. org/ 10. 1016/j. joule. 2019. 08. 006 

103. F. Lang, O. Shargaieva, V.V. Brus, H.C. Neitzert, J. Rappich et al., Influence of radiation on the properties and the stability of hybrid perovskites. Adv. Mater. **30** , 1702905 (2018). https:// doi. org/ 10. 1002/ adma. 20170 2905 

104. T.D. Siegler, W.A. Dunlap-Shohl, Y. Meng, Y. Yang, W.F. Kau et al., Water-accelerated photooxidation of  CH3NH3PbI3 perovskite. J. Am. Chem. Soc. **144** , 5552 (2022). https:// doi. org/ 10. 1021/ jacs. 2c003 91 

105. A.J. Ramadan, L.A. Rochford, S. Fearn, H.J. Snaith, Processing solvent-dependent electronic and structural properties of cesium lead triiodide thin films. J. Phys. Chem. Lett. **8** , 4172 (2017). https:// doi. org/ 10. 1021/ acs. jpcle tt. 7b016 77 

106. Q. Sun, P. Fassl, D. Becker-Koch, A. Bausch, B. Rivkin et al., Role of microstructure in oxygen induced photodegradation of methylammonium lead triiodide perovskite films. Adv. Energy Mater. **7** , 1700977 (2017). https:// doi. org/ 10. 1002/ aenm. 20170 0977 

107. Y. Ouyang, Y. Li, P. Zhu, Q. Li, Y. Gao et al., Photo-oxidative degradation of methylammonium lead iodide perovskite: mechanism and protection. J. Mater. Chem. A **7** , 2275 (2019). https:// doi. org/ 10. 1039/ C8TA1 2193A 

108. W. Li, W. Zhang, S. Van Reenen, R.J. Sutton, J. Fan et al., Enhanced UV-light stability of planar heterojunction perovskite solar cells with caesium bromide interface modification. Energy Environ. Sci. **9** , 490 (2016). https:// doi. org/ 10. 1039/ C5EE0 3522H 

109. T. Leijtens, G.E. Eperon, S. Pathak, A. Abate, M.M. Lee et al., Overcoming ultraviolet light instability of sensitized TiO2 with meso-superstructured organometal tri-halide perovskite solar cells. Nat. Commun. **4** , 2885 (2013). https:// doi. org/ 10. 1038/ ncomm s3885 

1 3 

**84** Page 30 of 34 

Nano-Micro Lett. (2023) 15:84 

110. Y. Li, X. Xu, C. Wang, B. Ecker, J. Yang et al., Light-induced degradation of  CH3NH3PbI3 hybrid perovskite thin film. J. Phys. Chem. C **121** , 3904 (2017). https:// doi. org/ 10. 1021/ acs. jpcc. 6b118 53 

111. Z. Song, C. Wang, A.B. Phillips, C.R. Grice, D. Zhao et al., Probing the origins of photodegradation in organic–inorganic metal halide perovskites with time-resolved mass spectrometry. Sustain. Energy Fuels **2** , 2460 (2018). https:// doi. org/ 10. 1039/ C8SE0 0358K 

112. S.G. Motti, D. Meggiolaro, A.J. Barker, E. Mosconi, C.A.R. Perini et al., Controlling competing photochemical reactions stabilizes perovskite solar cells. Nat. Photonics **13** , 532–539 (2019). https:// doi. org/ 10. 1038/ s41566- 019- 0435-1 

113. J.M. Azpiroz, E. Mosconi, J. Bisquert, F. De Angelis, Defect migration in methylammonium lead iodide and its role in perovskite solar cell operation. Energy Environ. Sci. **8** , 2118 (2015). https:// doi. org/ 10. 1039/ C5EE0 1265A 

114. R. Gottesman, E. Haltzi, L. Gouda, S. Tirosh, Y. Bouhadana et al., Extremely slow photoconductivity response of CH3NH3PbI3 perovskites suggesting structural changes under working conditions. J. Phys. Chem. Lett. **5** , 2662 (2014). https:// doi. org/ 10. 1021/ jz501 373f 

115. Y. You, W. Tian, L. Min, F. Cao, K. Deng et al.,  TiO2/WO3 bilayer as electron transport layer for efficient planar perovskite solar cell with efficiency exceeding 20%. Adv. Mater. Interfaces **7** , 1901406 (2020). https:// doi. org/ 10. 1002/ admi. 20190 1406 

116. M.M. Byranvand, T. Kim, S. Song, G. Kang, S.U. Ryu et al., p-type CuI islands on  TiO2 electron transport layer for a highly efficient planar-perovskite solar cell with negligible hysteresis. Adv. Energy Mater. **8** , 1702235 (2018). https:// doi. org/ 10. 1002/ aenm. 20170 2235 

117. M. Kim, I.-W. Choi, S.J. Choi, J.W. Song, S.-I. Mo et al., Enhanced electrical properties of Li-salts doped mesoporous TiO2 in perovskite solar cells. Joule **5** , 659 (2021). https:// doi. org/ 10. 1016/j. joule. 2021. 02. 007 

118. B. Wang, J. Yang, L. Lu, W. Xiao, H. Wu et al., Interface engineering of air-stable n-doping fullerene-modified  TiO2 electron transport layer for highly efficient and stable perovskite solar cells. Adv. Mater. Interfaces **7** , 1901964 (2020). https:// doi. org/ 10. 1002/ admi. 20190 1964 

119. S. Haque, M.J. Mendes, O. Sanchez-Sobrado, H. Águas, E. Fortunato et al., Photonic-structured  TiO2 for high-efficiency, flexible and stable perovskite solar cells. Nano Energy **59** , 91 (2019). https:// doi. org/ 10. 1016/j. nanoen. 2019. 02. 023 

120. T. Leijtens, G.E. Eperon, S. Pathak, A. Abate, M.M. Lee et al., Overcoming ultraviolet light instability of sensitized TiO2 with meso-superstructured organometal tri-halide perovskite solar cells. Nat. Commun. **4** , 1 (2013). https:// doi. org/ 10. 1038/ ncomm s3885 

121. M. Shahiduzzaman, M.I. Hossain, S. Visal, T. Kaneko, W. Qarony et al., Spray pyrolyzed  TiO2 embedded multi-layer front contact design for high-efficiency perovskite solar cells. Nano-Micro. Lett. **13** , 36 (2021). https:// doi. org/ 10. 1007/ s40820- 020- 00559-2 

122. V. Roiati, E. Mosconi, A. Listorti, S. Colella, G. Gigli et al., Stark effect in perovskite/TiO2 solar cells: evidence of local interfacial order. Nano Lett. **14** , 2168 (2014). https:// doi. org/ 10. 1021/ nl500 544c 

123. R.A. Kerner, B.P. Rand, Linking chemistry at the  TiO2/ CH3NH3PbI3 interface to current–voltage hysteresis. J. Phys. Chem. Lett. **8** , 2298 (2017). https:// doi. org/ 10. 1021/ acs. jpcle tt. 7b007 12 

124. S. Ito, S. Tanaka, K. Manabe, H. Nishino, Effects of surface blocking layer of  Sb2S3 on nanocrystalline  TiO2 for CH3NH3PbI3 perovskite solar cells. J. Phys. Chem. C **118** , 16995 (2014). https:// doi. org/ 10. 1021/ jp500 449z 

125. J. Zhang, T. Pauporté, Effects of oxide contact layer on the preparation and properties of  CH3NH3PbI3 for perovskite solar cell application. J. Phys. Chem. C **119** , 14919 (2015). https:// doi. org/ 10. 1021/ acs. jpcc. 5b029 84 

126. M.M. Tavakoli, R. Tavakoli, Z. Nourbakhsh, A. Waleed, U.S. Virk et al., High efficiency and stable perovskite solar cell using ZnO/rGO QDs as an electron transfer layer. Adv. Mater. Interfaces **3** , 1500790 (2016). https:// doi. org/ 10. 1002/ admi. 20150 0790 

127. H. Si, Q. Liao, Z. Zhang, Y. Li, X. Yang et al., An innovative design of perovskite solar cells with  Al2O3 inserting at ZnO/perovskite interface for improving the performance and stability. Nano Energy **22** , 223 (2016). https:// doi. org/ 10. 1016/j. nanoen. 2016. 02. 025 

128. R. Azmi, S. Hwang, W. Yin, T.-W. Kim, T.K. Ahn et al., High efficiency low-temperature processed perovskite solar cells integrated with alkali metal doped ZnO electron transport layers. ACS Energy Lett. **3** , 1241 (2018). https:// doi. org/ 10. 1021/ acsen ergyl ett. 8b004 93 

129. Z. Wang, X. Zhu, J. Feng, C. Wang, C. Zhang et al., Antisolvent-and annealing-free deposition for highly stable efficient perovskite solar cells via modified ZnO. Adv. Sci. **8** , 2002860 (2021). https:// doi. org/ 10. 1002/ advs. 20200 2860 

130. J. Idígoras, A. Todinova, J.R. Sánchez-Valencia, A. Barranco, A. Borrás et al., The interaction between hybrid organic–inorganic halide perovskite and selective contacts in perovskite solar cells: an infrared spectroscopy study. Phys. Chem. Chem. Phys. **18** , 13583 (2016). https:// doi. org/ 10. 1039/ C6CP0 1265E 

131. J. Yang, B.D. Siempelkamp, E. Mosconi, F. De Angelis, T.L. Kelly, Origin of the thermal instability in  CH3NH3PbI3 thin films deposited on ZnO. Chem. Mater. **27** , 4229 (2015). https:// doi. org/ 10. 1021/ acs. chemm ater. 5b015 98 

132. Y. Cheng, Q.-D. Yang, J. Xiao, Q. Xue, H.-W. Li et al., Decomposition of organometal halide perovskite films on zinc oxide nanoparticles. ACS Appl. Mater. Interfaces **7** , 36 (2015). https:// doi. org/ 10. 1021/ acsami. 5b046 95 

133. F. Hao, C.C. Stoumpos, D.H. Cao, R.P.H. Chang, M.G. Kanatzidis, Lead-free solid-state organic–inorganic halide perovskite solar cells. Nat. Photonics **8** , 489 (2014). https:// doi. org/ 10. 1038/ nphot on. 2014. 82 

134. F. Giustino, H.J. Snaith, Toward lead-free perovskite solar cells. ACS Energy Lett. **1** , 1233 (2016). https:// doi. org/ 10. 1021/ acsen ergyl ett. 6b004 99 

© The authors 

https://doi.org/10.1007/s40820-023-01046-0 

Page 31 of 34 **84** 

Nano-Micro Lett. (2023) 15:84 

135. Z. Li, L. Wang, R. Liu, Y. Fan, H. Meng et al., Spontaneous interface ion exchange: passivating surface defects of perovskite solar cells with enhanced photovoltage. Adv. Energy Mater. **9** , 1902142 (2019). https:// doi. org/ 10. 1002/ aenm. 20190 2142 

136. J. You, L. Meng, T.-B. Song, T.-F. Guo, Y. Yang et al., Improved air stability of perovskite solar cells via solutionprocessed metal oxide transport layers. Nat. Nanotechnol. **11** , 75 (2016). https:// doi. org/ 10. 1038/ nnano. 2015. 230 

137. H. Lee, C. Lee, Analysis of ion-diffusion-induced interface degradation in inverted perovskite solar cells via restoration of the Ag electrode. Adv. Energy Mater. **8** , 1702197 (2018). https:// doi. org/ 10. 1002/ aenm. 20170 2197 

138. J. Xu, A. Buin, A.H. Ip, W. Li, O. Voznyy et al., Perovskite–fullerene hybrid materials suppress hysteresis in planar diodes. Nat. Commun. **6** , 7081 (2015). https:// doi. org/ 10. 1038/ ncomm s8081 

139. Q. Wang, C.-C. Chueh, M. Eslamian, A.K.-Y. Jen, Modulation of PEDOT: PSS pH for efficient inverted perovskite solar cells with reduced potential loss and enhanced stability. ACS Appl. Mater. Interfaces **8** , 32068 (2016). https:// doi. org/ 10. 1021/ acsami. 6b117 57 

140. W. Sun, Y. Li, Y. Xiao, Z. Zhao, S. Ye et al., An ammonia modified PEDOT: PSS for interfacial engineering in inverted planar perovskite solar cells. Org. Electron. **46** , 22 (2017). https:// doi. org/ 10. 1016/j. orgel. 2017. 03. 019 

141. Y. Jiang, S.-C. Yang, Q. Jeangros, S. Pisoni, T. Moser et al., Mitigation of vacuum and illumination-induced degradation in perovskite solar cells by structure engineering. Joule **4** , 1087 (2020). https:// doi. org/ 10. 1016/j. joule. 2020. 03. 017 

142. Y. Li, B. Wang, T. Liu, Q. Zeng, D. Cao et al., Interfacial engineering of PTAA/perovskites for improved crystallinity and hole extraction in inverted perovskite solar cells. ACS Appl. Mater. Interfaces **14** , 3284 (2022). https:// doi. org/ 10. 1021/ acsami. 1c210 00 

143. T. Liu, K. Chen, Q. Hu, R. Zhu, Q. Gong, Inverted perovskite solar cells: progresses and perspectives. Adv. Energy Mater. **6** , 1600457 (2016). https:// doi. org/ 10. 1002/ aenm. 20160 0457 

144. H. Wang, Z. Huang, S. Xiao, X. Meng, Z. Xing et al., An in situ bifacial passivation strategy for flexible perovskite solar module with mechanical robustness by roll-to-roll fabrication. J. Mater. Chem. A **9** , 5759 (2021). https:// doi. org/ 10. 1039/ D0TA1 2067G 

145. M. Du, S. Zhao, L. Duan, Y. Cao, H. Wang et al., Surface redox engineering of vacuum-deposited NiOx for top-performance perovskite solar cells and modules. Joule **6** , 1931 (2022). https:// doi. org/ 10. 1016/j. joule. 2022. 06. 026 

146. W. Chen, F.Z. Liu, X.Y. Feng, A.B. Djurišić, W.K. Chan et al., Cesium doped NiOx as an efficient hole extraction layer for inverted planar perovskite solar cells. Adv. Energy Mater. **7** , 1700722 (2017). https:// doi. org/ 10. 1002/ aenm. 20170 0722 

147. J.R. Manders, S.W. Tsang, M.J. Hartel, T.H. Lai, S. Chen et al., Solution-processed nickel oxide hole transport layers in high efficiency polymer photovoltaic cells. Adv. Funct. Mater. **23** , 2993 (2013). https:// doi. org/ 10. 1002/ adfm. 20120 2269 

148. C.C. Boyd, R.C. Shallcross, T. Moot, R. Kerner, L. Bertoluzzi et al., Overcoming redox reactions at perovskite-nickel oxide interfaces to boost voltages in perovskite solar cells. Joule **4** , 1759 (2020). https:// doi. org/ 10. 1016/j. joule. 2020. 06. 004 

149. F. Hou, Z. Su, F. Jin, X. Yan, L. Wang et al., Efficient and stable planar heterojunction perovskite solar cells with an MoO3/PEDOT: PSS hole transporting layer. Nanoscale **7** , 9427 (2015). https:// doi. org/ 10. 1039/ C5NR0 1864A 

150. J.W. Jo, M.S. Seo, M. Park, J.Y. Kim, J.S. Park et al., Improving performance and stability of flexible planarheterojunction perovskite solar cells using polymeric holetransport material. Adv. Funct. Mater. **26** , 4464 (2016). https:// doi. org/ 10. 1002/ adfm. 20160 0746 

151. Y. Meng, Z. Hu, N. Ai, Z. Jiang, J. Wang et al., Improving the stability of bulk heterojunction solar cells by incorporating pH-neutral PEDOT: PSS as the hole transport layer. ACS Appl. Mater. Interfaces **6** , 5122 (2014). https:// doi. org/ 10. 1021/ am500 336s 

152. C. Redondo-Obispo, T.S. Ripolles, S. Cortijo-Campos, A.L. Alvarez, E. Climent-Pascual et al., Enhanced stability and efficiency in inverted perovskite solar cells through graphene doping of PEDOT: PSS hole transport layer. Mater. Design. **191** , 108587 (2020). https:// doi. org/ 10. 1016/j. matdes. 2020. 108587 

153. C. Liu, L. Zhang, Y. Li, X. Zhou, S. She et al., Highly stable and efficient perovskite solar cells with 22.0% efficiency based on inorganic–organic dopant-free double hole transporting layers. Adv. Funct. Mater. **30** , 1908462 (2020). https:// doi. org/ 10. 1002/ adfm. 20190 8462 

154. S. Kim, S. Bae, S.-W. Lee, K. Cho, K.D. Lee et al., Relationship between ion migration and interfacial degradation of  CH3NH3PbI3 perovskite solar cells under thermal conditions. Sci. Rep. **7** , 1 (2017). https:// doi. org/ 10. 1038/ s41598- 017- 00866-6 

155. T. Wu, R. Zhuang, R. Zhao, R. Zhao, L. Zhu et al., Understanding the effects of fluorine substitution in lithium salt on photovoltaic properties and stability of perovskite solar cells. ACS Energy Lett. **6** , 2218–2228 (2021). https:// doi. org/ 10. 1021/ acsen ergyl ett. 1c006 85 

156. Y. Liu, Y. Hu, X. Zhang, P. Zeng, F. Li et al., Inhibited aggregation of lithium salt in spiro-OMeTAD toward highly efficient perovskite solar cells. Nano Energy **70** , 104483 (2020). https:// doi. org/ 10. 1016/j. nanoen. 2020. 104483 

157. W. Li, H. Dong, L. Wang, N. Li, X. Guo et al., Montmorillonite as bifunctional buffer layer material for hybrid perovskite solar cells with protection from corrosion and retarding recombination. J. Mater. Chem. A **2** , 13587 (2014). https:// doi. org/ 10. 1039/ C4TA0 1550A 

158. Y. Yue, N. Salim, Y. Wu, X. Yang, A. Islam et al., Enhanced stability of perovskite solar cells through corrosion-free pyridine derivatives in hole-transporting materials. Adv. Mater. **28** , 10738 (2016). https:// doi. org/ 10. 1002/ adma. 20160 2822 

159. B.-A. Chen, J.-T. Lin, N.-T. Suen, C.-W. Tsao, T.-C. Chu et al., In situ identification of photo- and moisture-dependent 

1 3 

**84** Page 32 of 34 

Nano-Micro Lett. (2023) 15:84 

phase evolution of perovskite solar cells. ACS Energy Lett. **2** , 342 (2017). https:// doi. org/ 10. 1021/ acsen ergyl ett. 6b006 98 

160. Q. Wu, C. Xue, Y. Li, P. Zhou, W. Liu et al., Kesterite Cu2ZnSnS4 as a low-cost inorganic hole-transporting material for high-efficiency perovskite solar cells. ACS Appl. Mater. Interfaces **7** , 28466 (2015). https:// doi. org/ 10. 1021/ acsami. 5b095 72 

161. Y. Yang, H. Chen, X. Zheng, X. Meng, T. Zhang et al., Ultrasound-spray deposition of multi-walled carbon nanotubes on NiO nanoparticles-embedded perovskite layers for high-performance carbon-based perovskite solar cells. Nano Energy **42** , 322 (2017). https:// doi. org/ 10. 1016/j. nanoen. 2017. 11. 003 

162. C. Liu, X. Zhou, S. Chen, X. Zhao, S. Dai et al., Hydrophobic Cu2O quantum dots enabled by surfactant modification as top hole-transport materials for efficient perovskite solar cells. Adv. Sci. **6** , 1801169 (2019). https:// doi. org/ 10. 1002/ advs. 20180 1169 

163. I.S. Yang, S. Lee, J. Choi, M.T. Jung, J. Kim et al., Enhancement of open circuit voltage for CuSCN-based perovskite solar cells by controlling the perovskite/CuSCN interface with functional molecules. J. Mater. Chem. A **7** , 6028 (2019). https:// doi. org/ 10. 1039/ C8TA1 2217B 

164. B. Lee, A.J. Yun, J. Kim, B. Gil, B. Shin et al., Aminosilanemodified  CuGaO2 nanoparticles incorporated with CuSCN as a hole-transport layer for efficient and stable perovskite solar cells. Adv. Mater. Interfaces **6** , 1901372 (2019). https:// doi. org/ 10. 1002/ admi. 20190 1372 

165. N. Arora, M.I. Dar, A. Hinderhofer, N. Pellet, F. Schreiber et al., Perovskite solar cells with CuSCN hole extraction layers yield stabilized efficiencies greater than 20%. Science **358** , 768 (2017). https:// doi. org/ 10. 1126/ scien ce. aam56 55 

166. G.A. Sepalage, S. Meyer, A.R. Pascoe, A.D. Scully, U. Bach et al., A facile deposition method for CuSCN: exploring the influence of CuSCN on JV hysteresis in planar perovskite solar cells. Nano Energy **32** , 310 (2017). https:// doi. org/ 10. 1016/j. nanoen. 2016. 12. 043 

167. P. Xu, J. Liu, J. Huang, F. Yu, C.-H. Li et al., Interfacial engineering of CuSCN-based perovskite solar cells via PMMA interlayer toward enhanced efficiency and stability. New J. Chem. **45** , 13168 (2021). https:// doi. org/ 10. 1039/ D1NJ0 2454J 

168. L. Kavan, Z.V. Živcová, P. Hubík, N. Arora, M.I. Dar et al., Electrochemical characterization of CuSCN hole-extracting thin films for perovskite photovoltaics. ACS Appl. Energy Mater. **2** , 4264 (2019). https:// doi. org/ 10. 1021/ acsaem. 9b004 96 

169. H.-S. Kim, I.-H. Jang, N. Ahn, M. Choi, A. Guerrero et al., Control of I-V hysteresis in  CH3NH3PbI3 perovskite solar cell. J. Phys. Chem. Lett. **6** , 4633 (2015). https:// doi. org/ 10. 1021/ acs. jpcle tt. 5b022 73 

170. T. Zhang, X. Meng, Y. Bai, S. Xiao, C. Hu et al., Profiling the organic cation-dependent degradation of organolead halide perovskite solar cells. J. Mater. Chem. A **5** , 1103 (2017). https:// doi. org/ 10. 1039/ C6TA0 9687E 

171. Y. Kato, L.K. Ono, M.V. Lee, S. Wang, S.R. Raga et al., Silver iodide formation in methyl ammonium lead iodide 

   - perovskite solar cells with silver top electrodes. Adv. Mater. Interfaces **2** , 1500195 (2015). https:// doi. org/ 10. 1002/ admi. 20150 0195 

172. J. Li, Q. Dong, N. Li, L. Wang, Direct evidence of ion diffusion for the silver-electrode-induced thermal degradation of inverted perovskite solar cells. Adv. Energy Mater. **7** , 1602922 (2017). https:// doi. org/ 10. 1002/ aenm. 20160 2922 

173. E. Lee, J. Ahn, H.C. Kwon, S. Ma, K. Kim et al., All-solutionprocessed silver nanowire window electrode-based flexible perovskite solar cells enabled with amorphous metal oxide protection. Adv. Energy Mater. **8** , 1702182 (2018). https:// doi. org/ 10. 1002/ aenm. 20170 2182 

174. Y. Cheng, X. Liu, Z. Guan, M. Li, Z. Zeng et al., Revealing the degradation and self-healing mechanisms in perovskite solar cells by sub-bandgap external quantum efficiency spectroscopy. Adv. Mater. **33** , 2006170 (2021). https:// doi. org/ 10. 1002/ adma. 20200 6170 

175. C.C. Boyd, R. Cheacharoen, K.A. Bush, R. Prasanna, T. Leijtens et al., Barrier design to prevent metal-induced degradation and improve thermal stability in perovskite solar cells. ACS Energy Lett. **3** , 1772 (2018). https:// doi. org/ 10. 1021/ acsen ergyl ett. 8b009 26 

176. J. Jeong, M. Kim, J. Seo, H. Lu, P. Ahlawat et al., Pseudohalide anion engineering for α-FAPbI3 perovskite solar cells. Nature **592** , 381–385 (2021). https:// doi. org/ 10. 1038/ s41586- 021- 03406-5 

177. A. Guerrero, J. You, C. Aranda, Y.S. Kang, G. Garcia-Belmonte et al., Interfacial degradation of planar lead halide perovskite solar cells. ACS Nano **10** , 218 (2016). https:// doi. org/ 10. 1021/ acsna no. 5b036 87 

178. P. Qin, T. Wu, Z. Wang, L. Xiao, L. Ma et al., Grain boundary and interface passivation with Core-Shell Au@CdS nanospheres for high-efficiency perovskite solar cells. Adv. Funct. Mater. **30** , 1908408 (2020). https:// doi. org/ 10. 1002/ adfm. 20190 8408 

179. A. Davis, T. Tran, D. Young, Solution chemistry of iodide leaching of gold. Hydrometallurgy **32** , 143 (1993). https:// doi. org/ 10. 1016/ 0304- 386X(93) 90020-E 

180. L. Liang, Y. Cai, X. Li, M.K. Nazeeruddin, P. Gao, All that glitters is not gold: recent progress of alternative counter electrodes for perovskite solar cells. Nano Energy **52** , 211 (2018). https:// doi. org/ 10. 1016/j. nanoen. 2018. 07. 049 

181. M. Kaltenbrunner, G. Adam, E.D. Głowacki, M. Drack, R. Schwödiauer et al., Flexible high power-per-weight perovskite solar cells with chromium oxide–metal contacts for improved stability in air. Nat. Mater. **14** , 1032 (2015). https:// doi. org/ 10. 1038/ nmat4 388 

182. S. Cacovich, L. Ciná, F. Matteocci, G. Divitini, P.A. Midgley et al., Gold and iodine diffusion in large area perovskite solar cells under illumination. Nanoscale **9** , 4700 (2017). https:// doi. org/ 10. 1039/ C7NR0 0784A 

183. K. Domanski, J.-P. Correa-Baena, N. Mine, M.K. Nazeeruddin, A. Abate et al., Not all that glitters is gold: metalmigration-induced degradation in perovskite solar cells. ACS Nano **10** , 6306 (2016). https:// doi. org/ 10. 1021/ acsna no. 6b026 13 

© The authors 

https://doi.org/10.1007/s40820-023-01046-0 

Page 33 of 34 **84** 

Nano-Micro Lett. (2023) 15:84 

184. N.N. Shlenskaya, N.A. Belich, M. Grätzel, E.A. Goodilin, A.B. Tarasov, Light-induced reactivity of gold and hybrid perovskite as a new possible degradation mechanism in perovskite solar cells. J. Mater. Chem. A **6** , 1780 (2018). https:// doi. org/ 10. 1039/ C7TA1 0217H 

185. R.A. Kerner, P. Schulz, J.A. Christians, S.P. Dunfield, B. Dou et al., Reactions at noble metal contacts with methylammonium lead triiodide perovskites: role of underpotential deposition and electrochemistry. APL Mater. **7** , 041103 (2019). https:// doi. org/ 10. 1063/1. 50838 12 

186. Y. Xu, Y. Tian, M. Hou, Y. Wu, Y. Ding et al., Performance promotion through dual-interface engineering of CuSCN layers in planar perovskite solar cells. J. Phys. Chem. C **124** , 27977 (2020). https:// doi. org/ 10. 1021/ acs. jpcc. 0c097 94 

187. Y. Yang, M.T. Hoang, D. Yao, N.D. Pham, V.T. Tiong et al., Spiro-OMeTAD or CuSCN as a preferable hole transport material for carbon-based planar perovskite solar cells. J. Mater. Chem. A **8** , 12723 (2020). https:// doi. org/ 10. 1039/ D0TA0 3951A 

188. M. Jørgensen, K. Norrman, F.C. Krebs, Stability/degradation of polymer solar cells. Sol. Energy Mater. Sol. Cells **92** , 686 (2008). https:// doi. org/ 10. 1016/j. solmat. 2008. 01. 005 

189. S. Guo, X. Sun, C. Ding, R. Huang, M. Tan et al., Non-uniform chemical corrosion of metal electrode of p–i–n type of perovskite solar cells caused by the diffusion of  CH3NH3I. Energy Technol. **8** , 2000250 (2020). https:// doi. org/ 10. 1002/ ente. 20200 0250 

190. L. Zhao, R.A. Kerner, Z. Xiao, Y.L. Lin, K.M. Lee et al., Redox chemistry dominates the degradation and decomposition of metal halide perovskite optoelectronic devices. ACS Energy Lett. **1** , 595 (2016). https:// doi. org/ 10. 1021/ acsen ergyl ett. 6b003 20 

191. Y.-H. Lin, N. Sakai, P. Da, J. Wu, C. Sansom Harry et al., A piperidinium salt stabilizes efficient metal-halide perovskite solar cells. Science **369** , 96 (2020). https:// doi. org/ 10. 1126/ scien ce. aba16 28 

192. M. Kim, S.G. Motti, R. Sorrentino, A. Petrozza, Enhanced solar cell stability by hygroscopic polymer passivation of metal halide perovskite thin film. Energy Environ. Sci. **11** , 2609 (2018). https:// doi. org/ 10. 1039/ C8EE0 1101J 

193. Q. Wang, Q. Dong, T. Li, A. Gruverman, J. Huang, Thin insulating tunneling contacts for efficient and water-resistant perovskite solar cells. Adv. Mater. **28** , 6734 (2016). https:// doi. org/ 10. 1002/ adma. 20160 0969 

194. Z. Wu, T. Song, B. Sun, Carbon-based materials used for perovskite solar cells. ChemNanoMat **3** , 75 (2017). https:// doi. org/ 10. 1002/ cnma. 20160 0312 

195. L. Gao, I. Spanopoulos, W. Ke, S. Huang, I. Hadar et al., Improved environmental stability and solar cell efficiency of (MA, FA)  PbI3 perovskite using a wide-band-gap 1D thiazolium lead iodide capping layer strategy. ACS Energy Lett. **4** , 1763 (2019). https:// doi. org/ 10. 1021/ acsen ergyl ett. 9b009 30 

196. Y. Hou, X. Du, S. Scheiner, D.P. McMeekin, Z. Wang et al., A generic interface to reduce the efficiency-stability-cost gap of perovskite solar cells. Science **358** , 1192 (2017). https:// doi. org/ 10. 1126/ scien ce. aao55 61 

197. J. Kim, Y. Lee, B. Gil, A.J. Yun, J. Kim et al., A  Cu2O– CuSCN nanocomposite as a hole-transport material of perovskite solar cells for enhanced carrier transport and suppressed interfacial degradation. ACS Appl. Energy Mater. **3** , 7572 (2020). https:// doi. org/ 10. 1021/ acsaem. 0c010 01 

198. S.S. Mali, J.V. Patil, H. Kim, R. Luque, C.K. Hong, Highly efficient thermally stable perovskite solar cells via Cs:NiOx/ CuSCN double-inorganic hole extraction layer interface engineering. Mater. Today **26** , 8 (2019). https:// doi. org/ 10. 1016/j. mattod. 2019. 01. 017 

199. J. Cao, B. Wu, R. Chen, Y. Wu, Y. Hui et al., Efficient, hysteresis-free, and stable perovskite solar cells with ZnO as electron-transport layer: effect of surface passivation. Adv. Mater. **30** , 1705596 (2018). https:// doi. org/ 10. 1002/ adma. 20170 5596 

200. R. Azmi, C.-L. Lee, I.H. Jung, S.-Y. Jang, Simultaneous improvement in efficiency and stability of low-temperatureprocessed perovskite solar cells by interfacial control. Adv. Energy Mater. **8** , 1702934 (2018). https:// doi. org/ 10. 1002/ aenm. 20170 2934 

201. W. Qiu, M. Buffière, G. Brammertz, U.W. Paetzold, L. Froyen et al., High efficiency perovskite solar cells using a PCBM/ZnO double electron transport layer and a short air-aging step. Org. Electron. **26** , 30 (2015). https:// doi. org/ 10. 1016/j. orgel. 2015. 06. 046 

202. S. Zheng, W. Li, T. Su, F. Xie, J. Chen et al., Metal oxide crox as a promising bilayer electron transport material for enhancing the performance stability of planar perovskite solar cells. Sol. RRL **2** , 1700245 (2018). https:// doi. org/ 10. 1002/ solr. 20170 0245 

203. Z. Jiang, X. Chen, X. Lin, X. Jia, J. Wang et al., Amazing stable open-circuit voltage in perovskite solar cells using AgAl alloy electrode. Sol. Energy Mater. Sol. Cells **146** , 35 (2016). https:// doi. org/ 10. 1016/j. solmat. 2015. 11. 026 

204. E. Bi, H. Chen, F. Xie, Y. Wu, W. Chen et al., Diffusion engineering of ions and charge carriers for stable efficient perovskite solar cells. Nat. Commun. **8** , 15330 (2017). https:// doi. org/ 10. 1038/ ncomm s15330 

205. J. Lee, S. Singh, S. Kim, S. Baik, Graphene interfacial diffusion barrier between CuSCN and Au layers for stable perovskite solar cells. Carbon **157** , 731 (2020). https:// doi. org/ 10. 1016/j. carbon. 2019. 10. 101 

206. Q. Jiang, J. Tong, Y. Xian, R.A. Kerner, S.P. Dunfield et al., Surface reaction for efficient and stable inverted perovskite solar cells. Nature **611** , 278 (2022). https:// doi. org/ 10. 1038/ s41586- 022- 05268-x 

207. X. Li, W. Zhang, X. Guo, C. Lu, J. Wei et al., Constructing heterojunctions by surface sulfidation for efficient inverted perovskite solar cells. Science **375** , 434 (2022). https:// doi. org/ 10. 1126/ scien ce. abl56 76 

208. F. Zhang, K. Zhu, Additive engineering for efficient and stable perovskite solar cells. Adv. Energy Mater. **10** , 1902579 (2020). https:// doi. org/ 10. 1002/ aenm. 20190 2579 

209. D. Bi, P. Gao, R. Scopelliti, E. Oveisi, J. Luo et al., High-performance perovskite solar cells with enhanced environmental stability based on amphiphile-modified 

1 3 

**84** Page 34 of 34 

Nano-Micro Lett. (2023) 15:84 

   - CH3NH3PbI3. Adv. Mater. **28** , 2910 (2016). https:// doi. org/ 10. 1002/ adma. 20150 5255 

210. Y. Zhao, J. Wei, H. Li, Y. Yan, W. Zhou et al., A polymer scaffold for self-healing perovskite solar cells. Nat. Commun. **7** , 1 (2016). https:// doi. org/ 10. 1038/ ncomm s10228 

211. X. Li, W. Zhang, W. Zhang, H.-Q. Wang, J. Fang, Spontaneous grain polymerization for efficient and stable perovskite solar cells. Nano Energy **58** , 825 (2019). https:// doi. org/ 10. 1016/j. nanoen. 2019. 02. 009 

212. L. Zuo, H. Guo, D.W. deQuilettes, S. Jariwala, N. deMarco et al., Polymer-modified halide perovskite films for efficient and stable planar heterojunction solar cells. Sci. Adv. **3** , e1700106 (2017) 

213. X. Li, W. Zhang, Y.-C. Wang, W. Zhang, H.-Q. Wang et al., In-situ cross-linking strategy for efficient and operationally stable methylammoniun lead iodide solar cells. Nat. Commun. **9** , 1 (2018). https:// doi. org/ 10. 1038/ s41467- 018- 06204-2 

214. S. Bai, P. Da, C. Li, Z. Wang, Z. Yuan et al., Planar perovskite solar cells with long-term stability using ionic liquid additives. Nature **571** , 245 (2019). https:// doi. org/ 10. 1038/ s41586- 019- 1357-2 

215. L. Gao, S. Huang, L. Chen, X. Li, B. Ding et al., Excellent stability of perovskite solar cells by passivation engineering. Sol. RRL **2** , 1800088 (2018). https:// doi. org/ 10. 1002/ solr. 20180 0088 

216. G.Y. Kim, A. Senocrate, T.-Y. Yang, G. Gregori, M. Grätzel et al., Large tunable photoeffect on ion conduction in halide perovskites and implications for photodecomposition. Nat. Mater. **17** , 445 (2018). https:// doi. org/ 10. 1038/ s41563- 018- 0038-0 

217. Q. Lou, H. Li, Q. Huang, Z. Shen, F. Li et al., Multifunctional CNT:  TiO2 additives in spiro-OMeTAD layer for highly 

   - efficient and stable perovskite solar cells. EcoMat **3** , e12099 (2021). https:// doi. org/ 10. 1002/ eom2. 12099 

218. Q. Luo, Y. Zhang, C. Liu, J. Li, N. Wang et al., Iodidereduced graphene oxide with dopant-free spiro-OMeTAD for ambient stable and high-efficiency perovskite solar cells. J. Mater. Chem. A **3** , 15996 (2015). https:// doi. org/ 10. 1039/ C5TA0 2710A 

219. Y. Han, G. Zhang, H. Xie, T. Kong, Y. Li et al., Azide additive acting as a powerful locker for  Li<sup>+</sup> and TBP in spiroOMeTAD toward highly efficient and stable perovskite solar cells. Nano Energy (2022). https:// doi. org/ 10. 1016/j. nanoen. 2022. 107072 

220. Y. Shao, Y. Fang, T. Li, Q. Wang, Q. Dong et al., Grain boundary dominated ion migration in polycrystalline organic–inorganic halide perovskite films. Energy Environ. Sci. **9** , 1752 (2016). https:// doi. org/ 10. 1039/ C6EE0 0413J 

221. R. Wang, J. Xue, L. Meng, J.-W. Lee, Z. Zhao et al., Caffeine improves the performance and thermal stability of perovskite solar cells. Joule **3** , 1464 (2019). https:// doi. org/ 10. 1016/j. joule. 2019. 04. 005 

222. L. Liu, S. Huang, Y. Lu, P. Liu, Y. Zhao et al., Grain-boundary “patches” by in situ conversion to enhance perovskite solar cells stability. Adv. Mater. **30** , 1800544 (2018). https:// doi. org/ 10. 1002/ adma. 20180 0544 

223. X. Li, S. Ke, X. Feng, X. Zhao, W. Zhang et al., Enhancing the stability of perovskite solar cells through cross-linkable and hydrogen bonding multifunctional additives. J. Mater. Chem. A **9** , 12684 (2021). https:// doi. org/ 10. 1039/ D1TA0 1572A 

224. Y. Ma, Y. Cheng, X. Xu, M. Li, C. Zhang et al., Suppressing ion migration across perovskite grain boundaries by polymer additives. Adv. Funct. Mater. **31** , 2006802 (2021). https:// doi. org/ 10. 1002/ adfm. 20200 6802 

© The authors 

https://doi.org/10.1007/s40820-023-01046-0 

