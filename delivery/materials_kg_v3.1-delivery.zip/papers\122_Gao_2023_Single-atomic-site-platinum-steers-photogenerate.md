# Single-atomic-site platinum steers photogenerated charge carrier lifetime of hematite nanoflakes for photoelectrochemical water splitting

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 209 |
| 作者 | Rui-Ting Gao, Jiang-Lou Zhang, T. Nakajima, Jin-Lu He, Xian-Hu Liu, Xue-Yuan Zhang, Lei Wang, Li-Min Wu |
| DOI | 10.1038/s41467-023-38343-6 |
| 源文件 | 022_Gao_2023_Single-atomic-site-platinum-steers-photogenerate.pdf |

---
Article 



https://doi.org/10.1038/s41467-023-38343-6 

# Single-atomic-site platinum steers photogenerated charge carrier lifetime of hematite nanoflakes for photoelectrochemical water splitting 

|Received: 11 August 2022<br>Accepted: 26 April 2023|Rui-Ting Gao<br>1, Jiangwei Zhang<br>1, Tomohiko Nakajima<br>2, Jinlu He<br>3<br>,<br>Xianhu Liu<br>4, Xueyuan Zhang5, Lei Wang1<br>& Limin Wu<sup>1,6</sup>|
|---|---|
|Check for updates|Although much effort has been devoted to improving photoelectrochemical<br>water splitting of hematite (α-Fe2O3) due to its high theoretical solar-to-|
||hydrogen conversion efficiency of 15.5%, the low applied bias photon-to-<br>current efficiency remains a huge challenge for practical applications. Herein,<br>we introduce single platinum atom sites coordination with oxygen atom<br>(Pt-O/Pt-O-Fe) sites into single crystallineα-Fe2O3nanoflakes photoanodes<br>(SAs Pt:Fe2O3-Ov). The single-atom Pt doping ofα-Fe2O3can induce few<br>electron trapping sites, enhance carrier separation capability, and boost<br>charge transfer lifetime in the bulk structure as well as improve charge carrier<br>injection efficiency at the semiconductor/electrolyte interface. Further intro-<br>duction of surface oxygen vacancies can suppress charge carrier recombina-<br>tion and promote surface reaction kinetics, especially at low potential.<br>Accordingly, the optimum SAs Pt:Fe2O3-Ov photoanode exhibits the photo-<br>electrochemical performance of 3.65 and 5.30 mA cm<sup>−2 </sup>at 1.23 and 1.5 VRHE,<br>respectively, with an applied bias photon-to-current efficiency of 0.68% for the<br>hematite-based photoanodes. This study opens an avenue for designing highly<br>efficient atomic-level engineering on single crystalline semiconductors for<br>feasible photoelectrochemical applications.|



Photoelectrochemical (PEC) water splitting has attracted great promises in recent years for sustainable hydrogen production<sup>1–5</sup> , in which the fabrication of the suitable semiconductor photoanodes with sufficient light absorption and efficient charge carrier transport is becoming increasingly important for achieving high solar-to-hydrogen (STH) conversion efficiency<sup>6–10</sup> . Many metal oxide semiconductors such as TiO211–13, α-Fe2O314–16, BiVO417–19, and WO320–22, have been 

considered as promising candidates owing to their availability, facile preparation, and oxidative stability. Especially, hematite (α-Fe2O3), a n-type semiconductor with a small band gap of ~2.1 eV, can absorb a large portion of the solar spectrum and allow a theoretical STH efficiency of 15.5% under standard sunlight illumination<sup>23–26</sup> . However, its short hole diffusion length, poor charge carrier conductivity, and sluggish oxygen evolution reaction kinetics limit the photocurrent of 

> 1College of Chemistry and Chemical Engineering, College of Energy Material and Chemistry, Inner Mongolia University, Hohhot 010021, China. 2Advanced Manufacturing Research Institute, National Institute of Advanced Industrial Science and Technology, Tsukuba Central 5, 1-1-1 Higashi, Tsukuba, Ibaraki 3058565, Japan.<sup>3</sup> College of Chemistry and Chemical Engineering, Inner Mongolia University, Hohhot 010021, China.<sup>4</sup> Key Laboratory of Materials Processing and Mold, Ministry of Education, Zhengzhou University, Zhengzhou 450002, China.<sup>5</sup> State Key Laboratory of Chemo/Biosensing and Chemometrics, College of Chemistry and Chemical Engineering, Hunan University, Changsha 410082, China.<sup>6</sup> Department of Materials Science and State Key Laboratory of Molecular Engineering of Polymers, Fudan University, Shanghai 200433, China. e-mail: hejinlu@imu.edu.cn; wanglei@imu.edu.cn; wlm@imu.edu.cn 

Nature Communications |  (2023) 14:2640 

1 

Article 

https://doi.org/10.1038/s41467-023-38343-6 

α-Fe2O3 far below its theoretical value of 12.4 mA cm<sup>−227,28</sup> . Especially, the low electron mobility (~10<sup>−2</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ) as one of the main intrinsic drawbacks significantly impedes its PEC performance<sup>29–31</sup> . 

To enhance the electron mobility of photoelectrode, doping elements (e.g., Ti<sup>32–34</sup> , Sn<sup>35–37</sup> , Zr<sup>38</sup> , La<sup>39</sup> , Ta<sup>27,40</sup> , B<sup>41</sup> , and P<sup>31</sup> ) have been adapted to substantially ameliorate the photo-efficiency of α-Fe2O3. For example, nonmetallic P doping has a superior activity owing to the strong covalent interaction between P and O, which boosted fast electron carriers and avoided the formation of deep electron trapping sites in α-Fe2O331. Although these doping elements can improve more or less the electrical conductivity and charge transfer of α-Fe2O3, all the dopants in the photoelectrodes reported so far are clusters or bigger than clusters. As a result, not only the improvement of PEC is limited, but also the band bending caused by these clusters decreases the width of space-charge layer which limits the number of the carriers inside of the layer. In addition, these traditional dopants have not much influence on onset potential (generally located at 0.8–1.0 VRHE). The onset potential further influences the applied bias photon-tocurrent efficiency (ABPE) of α-Fe2O3 due to the surface and bulk trap states<sup>3,42</sup> , the high onset potential causing to the low ABPE. Therefore, additional strategies are desirable to improve the charge transfer efficiency and ABPE value. 

Recently, engineering single atom catalysts have been widely used to enhance the oxygen evolution reaction performances. Unsaturated coordination environments of single atoms often function as active sites, influencing the catalytic performances<sup>43,44</sup> . However, most single atoms are incorporated into amorphous catalyst layers, and no reports are related to single atom doping semiconductors. For example, atomically dispersed Ni-N4 sites coordinated with oxygen atom have promoted photogenerated charge separation and thus improved PEC performance of BiVO445. The single atom catalysts grown on an amorphous support act as the charge transfer layer, and the construction of single-atomic Ni-N4-O moiety is located at the interface of photoelectrode/oxygen evolution cocatalyst (OEC). In fact, more serious recombination usually happens in the bulk materials. To this end, it is highly desirable to design single metal atoms doped into photoelectrode to efficiently transfer carrier from the bulks to the photoelectrode/electrolyte interfaces, and improve the OER and PEC performances. 

Herein, we develop a versatile strategy to engineer single platinum atom sites coordinated with an oxygen atom (Pt-O) incorporated into single crystalline hematite photoanodes by using 2,2-bipyridine as the ligand to chelate Pt cations, followed by the inert atmosphere 

treatment to remove the ligand. The construction of single atomic Pt-O coordination in Fe2O3 nanoflakes (SAs Pt:Fe2O3) owns few deep electron trapping sites in hematite. Accordingly, the SAs Pt:Fe2O3 with the surface oxygen vacancies can achieve the photocurrent density of 3.65 mA cm<sup>−2</sup> at 1.23 VRHE with a ABPE of 0.68%, which is more than double most of the previously reported values of the doped Fe2O3based photoanodes (Supplementary Table 1), and even superior to the cocatalysts decorated Fe2O3-based photoanodes.X-rayabsorption fine structure analysis, time-resolved spectroscopic investigation, and time domain density functional theory and nonadiabatic molecular dynamics calculations have demonstrated that the improved PEC activity can be ascribed to the construction of the single-atomic Pt-O and Pt-O-Fe in Fe2O3, which facilitates the hole transfer from Fe2O3 bulk to interface, extends the charge carrier lifetime, and accelerates the reaction kinetics for PEC water splitting. 

## Results 

### Electronic structure of Fe2O3 and Pt doped Fe2O3 

Using the density functional theory (DFT) method, we firstly calculated the projected density of states (PDOS) and electron localization function (ELF) to determine if the loading of Pt nanoparticles (NPs) and single atoms (SAs) can influence the electronic structure and electron mobility of Fe2O3 geometries, and the samples are labeled as NPs Pt/ Fe2O3 and SAs Pt:Fe2O3 (Supplementary Fig. 1a–c). The computed direct band gap of Fe2O3 is approximately 2.0 eV (Fig. 1a), agreeing with the value reported in the literature (2.1 eV)<sup>14,15</sup> . For the NPs Pt/Fe2O3, partial Pt atoms are bonded to surface oxygens, whilst others exhibit metallic properties, forming the Pt-Pt bonds. The Pt NPs introduce almost continuous states between the band gap of Fe2O3 (Fig. 1b), promoting the photogenerated electrons transferring from Fe2O3 to Pt NPs. However, the state created by Pt NPs can act as the charge recombination center. Further downsizing the Pt nanoparticles to single atomic level, Pt atoms form Pt-O covalent bonds with O atoms, which create several charge trapping states within the bandgap compared to that of NPs Pt/Fe2O3 (Fig. 1c). These trapping states primarily composed of SAs Pt atoms, can trap the photogenerated charge carriers and accelerate the electronhole separation (discussion in the following). Moreover, ELF shows that doping Pt reduces the electron localization in regard to that of the pristine Fe2O3 (Fig. 1d–f), benefiting to improve electron transport rate. Comparatively, the strong Pt-O and metal-metal interaction exist in NPs Pt/Fe2O3 (Fig. 1e), while the latter vanishes in SAs Pt:Fe2O3 (Fig. 1f). These results confirm that single atomic Pt doping can facilitate the electron 



Fig. 1 | Electronic structures of Fe2O3, NPs Pt/Fe2O3, and SAs Pt:Fe2O3. a–c Projected density of states (PDOS) states of a Fe2O3, b NPs Pt/Fe2O3, and c SAs Pt:Fe2O3, d–f electron density distribution plots of d Fe2O3, e NPs Pt/Fe2O3, and f SAs Pt:Fe2O3. 

Nature Communications |  (2023) 14:2640 

2 

Article 

https://doi.org/10.1038/s41467-023-38343-6 



Fig. 2 | Characterization of SAs Pt:Fe2O3. a Schematic illustration for the synthesis of SAs Pt:Fe2O3. Color codes: grey (Pt), green (Cl), blue (N), and purple (C); b SEM images; c–e high resolution HAADF STEM images. A large numbers of Pt atoms were atomically dispersed on the Fe2O3 as observed in c. Inset of e shows the FFT 

pattern; f, g the lines represent the line profiles from HAADF intensity analysis labeled in e; h elemental mapping. Scale bars in b–e, and h are 200 nm, 5 nm, 500 pm, 500 pm, and 20 nm, respectively. 

separation and transfer in contrast to traditional doping engineering in term of improving performance. 

### Synthesis and characterization of SAs Pt:Fe2O3 

Motivated by the theoretical calculations, SAs Pt:Fe2O3 photoanode was synthesized as illustrated in Fig. 2a. To begin with, onedimensional single-crystalline Fe2O3 nanoflakes were formed by a thermal treatment at 400 °C for 3 h in air (Supplementary Fig. 2), and subsequently were immersed in the solution of 2,2-bipyridine as the ligand to chelate Pt cations. The ligand was removed under Ar atmosphere at 330 °C to obtain isolated single-atomic Pt doped Fe2O3 (Supplementary Fig. 3). The NPs Pt/Fe2O3 was prepared as the thermal temperature was 400 °C (Supplementary Fig. 4). X-ray diffraction (XRD) pattern of SAs Pt:Fe2O3 displays the Fe2O3 (JCPDS No. 33-0664), Fe3O4 (JCPDS No. 19-0629), and Fe peaks (Supplementary Fig. 4d). The formation of Fe3O4 originated from the thermal annealing treatment owing to the oxygen diffusion from the surface to the bulk material. Fe3O4 is not photoactive for photoelectrochemical performance, while it can be assured that it is more conducive than the Fe2O3, and acts as a conductive layer to transfer charge carrier from the Fe2O3 to the back side<sup>46</sup> . Scanning electron microscopy (SEM) images exhibit one dimensional nanoflakes structure with a length of 1.5–2.5 μm on SAs Pt:Fe2O3 (Fig. 2b and Supplementary Fig. 5). The aberration-corrected high-angle annular dark-field scanning transmission electron microscopy (AC-HAADF-STEM) images reveal a high degree of single atom dispersion for SAs Pt:Fe2O3 (Fig. 2c–e and Supplementary Fig. 6), where the Pt atoms are uniformly dispersed at the Fe atom positions (Fig. 2f, g). One can see that the edge of nanoflakes presents the defected structure decorated with the isolated Pt atoms (Fig. 2d and 

Supplementary Fig. 7). Element mapping shows the homogeneous distribution of Fe, O, and Pt species across the whole nanoflakes (Fig. 2h), indicative of the presence of single atom (Supplementary Fig. 8). Induced coupled plasma-mass spectrometry analysis shows ~4 at.% of Pt content on SAs Pt:Fe2O3. On the contrary, significant aggregation of Pt species with a size of 5–10 nm can be observed on NPs Pt/Fe2O3 (Supplementary Figs. 9–11). The controllable experiment using the same manner without 2,2-bipyridine results in the formation of Pt nanoparticles (Supplementary Fig. 12). It should be noted that the use of 2,2-bipyridine and low annealing treatment are the critical factors to realize the single atom sites and maintain the dispersion of Pt species. This is a feasible approach of tailoring Pt single atoms doping into single crystalline photoelectrodes. 

X-ray photoelectron spectra (XPS) and X-ray absorption fine structure (XAS) spectroscopy were used to probe the local coordination chemistry of the Pt species. The binding energies of Pt 4f7/2 (72.80) and Pt 4f5/2 peaks (76.10 eV) on SAs Pt:Fe2O3 are higher than those of metallic Pt<sup>0</sup> and lower than those of Pt<sup>4+</sup> (Fig. 3a), indicating the presence of SAs Pt in hematite. The only Pt 4f peaks representing the metallic Pt appear in NPs:Fe2O3 (Supplementary Fig. 13). To further provide the evidence of single atom, Fig. 3b exhibits two peaks at 1.94 Å and 2.84 Å in the Pt L-edge X-ray absorption fine structure (EXAFS) spectrum of SAs Pt:Fe2O3. The first shell originates from the coordination of Pt atom to oxygen (Pt-O), and the second shell fits for the Pt-O-Fe with a comparison between Pt-O-Fe and Pt-Pt coordination models, consistent with the analysis of the dispersed Pt atoms from HADDF-STEM images (Fig. 2c). The contribution of Pt-O and Pt-O-Fe comes from the interaction between single Pt site and oxygen/ iron atoms on Fe2O3. The normalized X-ray absorption near-edge 

Nature Communications |  (2023) 14:2640 

3 

Article 

https://doi.org/10.1038/s41467-023-38343-6 



Fig. 3 | Coordination environment analysis of SAs Pt:Fe2O3. a Pt 4f XPS spectra; b Fourier-transformed R-space of the experimental Pt K-edge EXAFS signals; c normalized XANES spectra; d–f 3D contour WT-EXAFS maps with 2D projection of 

d Pt foil, e PtO, and f SAs Pt:Fe2O3. g free energies of OER reaction steps occurring on Pt-O or Pt-O-Fe active sites in SAs Pt:Fe2O3. 

structure (XANES) spectra exhibit the intensity of SAs Pt:Fe2O3 located at Pt foil and PtO2 (Fig. 3c), manifesting that the valence of Pt is lower than +4. The R space fitting and EXAFS fitting results suggest that the calculated structure is Pt-O and Pt-O-Fe (Supplementary Fig. 14 and Supplementary Table 2). SAs Pt:Fe2O3 exhibits Pt-O bonding with coordination number (CN) approaching 4.5 at 1.94 Å, and Pt-O-Fe bonding with CN approaching 1.0 at 2.84 Å in second coordination shell, clearly demonstrating the formation of single atom on hematite. Owing to the powerful resolution in both k and R spaces, the Pt L edge wavelet transform extended EXAFS (WT-EXAFS) was employed to investigate the atomic configuration of SAs Pt:Fe2O3 with the references of Pt foil and PtO (Fig. 3d–f). For the Pt L edge wavelet transform of χ(k) spectra of SAs Pt:Fe2O3, one highest merged scattering path signalof Pt-O bond located at [χ(k), χ(R)] of [6.0, 2.02] is observed, and a low scattering path signal of Pt-O-Fe bond located at [χ(k), χ(R)] of [6.0, 3.0] can be seen (Fig. 3f). The characteristic scattering path signal of Pt-Pt bond in the Pt foil is located at [7.4, 2.80] (Fig. 3d), and it is not detected on SAs Pt:Fe2O3. The characteristic scattering path signal of Pt-O bonds in the PtO is located at [6.0, 2.0] (Fig. 3e). The WT-EXAFS analysis determines the radial distance and k space resolution, confirming the coexistence of Pt-O and Pt-O-Fe without Pt-Pt in SAs Pt:Fe2O3. The above analyses demonstrate that the dispersed 

Pt atoms are in the form of Pt-O and Pt-O-Fe bonds in the hematite nanoflakes. 

To investigate the real reaction path of four-electron oxygen evolution reaction (OER) in SAs Pt:Fe2O3, we calculated the thermodynamic free energy diagrams for OER. The side view structures of *OH, *O, and *OOH absorbed on SAs Pt:Fe2O3 surface are shown in the inset of Fig. 3g. The calculated data in Fig. 3g demonstrate that there are two OER paths (first OER path: Pt-OH → PtOFe → PtOOH → O2; second OER path: Pt-OH → PtO → PtOOH → O2) in SAs Pt:Fe2O3 surface. Typically, the higher energy barrier of rate-determining steps, the larger overpotentials (η) for OER. As seen in Fig. 3g, we can conclude that the energy barrier of *O intermediate formation in the first OER path (2.07 eV) is lower than that of *OOH intermediate formation in the second OER path (2.48 eV). Thus, the η of first OER path (0.84 V) is lower than that of second OER path (1.25 V). The distinct 0.41 V drop in η shows that the first OER path is the real reaction path in SAs Pt:Fe2O3, indicating that Pt-O-Fe is the crucial active site which can promote the surface OER kinetics and improve the solar water splitting activity. 

### Photoelectrochemical performance 

The PEC performances were investigated in a three-electrode cell (Supplementary Fig. 15). Figure 4a shows the photocurrent-potential 

Nature Communications |  (2023) 14:2640 

4 

Article 

https://doi.org/10.1038/s41467-023-38343-6 



Fig. 4 | PEC performances and band edge energetics of Fe2O3, NPs Pt/Fe2O3, and SAs Pt:Fe2O3. a J-V curves; b extracted Von; c charge separation efficiencies; d charge transfer efficiencies; e OCP-derived carrier transfer lifetimes; f PEIS at 1.23 VRHE. Inset shows the circuit; g Mott-Schottky plots; h UPS spectra. The black 

dashed lines indicate the area shown in zoomed-in image in the inset of h; i band diagrams determined from UV-vis absorption and UPS measurements. All electrochemical measurements were performed in 1 M KOH under AM 1.5G illumination (100 mW cm<sup>−2</sup> ). 

(J-V) curves of the photoanodes in 1 M KOH under AM 1.5G (100 mW cm<sup>−2</sup> ) simulated sunlight. The pristine Fe2O3 displays a photocurrent density of 0.45 mA cm<sup>−2</sup> at 1.23 VRHE with an onset potential (Von) of 0.652 VRHE. With the introduction of Pt dopant into hematite, both NPs and SAs enhance the photocurrent densities of hematite, accompanied by the negative shift of Von, indicating the fast charge transfer by Pt incorporation. Dark current densities for both samples are also remarkably improved with a cathodic shift of approximately 58 mV at 0.5 mA cm<sup>−2</sup> (Supplementary Fig. 16). The optimum SAs Pt:Fe2O3 shows a photocurrent density of 2.71 mA cm<sup>−2</sup> at 1.23 VRHE (Supplementary Fig. 17), higher than that of NPs Pt/Fe2O3 (1.29 mA cm<sup>−2</sup> ). Moreover, the Von of SAs Pt:Fe2O3 (0.627 VRHE) is found to be negatively shifted by 25 and 16 mV relative to those of the pristine Fe2O3 and NPs Pt/Fe2O3 (Fig. 4b), suggesting the enhanced surface water oxidation kinetics, especially the surface edge with the substitution of single atomic Pt (Fig. 2d). The improved photocurrent and the reduced Von increase ABPE with a maximum value of 0.51% (Supplementary Fig. 18), which surpasses the previously reported the highest value of 0.31%<sup>27</sup> . Besides, the current spike on SAs Pt:Fe2O3 (i/i0 = 0.91) is reduced from the chopped J-V plots (Supplementary Fig. 19), indicating promoting sluggish water oxidation by single atomic Pt. 

To understand the charge character by the influence of SAs Pt, charge separation efficiency (ƞsep) and charge transfer efficiency (ƞtran) were calculated, and derived from the J-V curves measured in a hole 

scavenger-containing electrolyte (Supplementary Fig. 20). The ƞsep points to the hole extraction from the excited Fe2O3 to the surface. From Fig. 4c, Pt doping dramatically improves the ƞsep in the entire voltage region. SAs Pt:Fe2O3 presents higher ƞsep values in relative to the traditional particles doping, reaching to 80.1% at 1.23 VRHE, while NPs Pt/ Fe2O3 arrives to 44.1% of the same potential. Single atom edging at the surface also plays a vital role for the hole trapping to the surface for water oxidation. Besides, SAs Pt:Fe2O3 exhibits a ƞtran value of 25.8% at 1.23 VRHE (Fig. 4d), higher than that of NPs Pt/Fe2O3 (23.0%), indicating that the fraction of holes reaches to the semiconductor/electrolyte interface without significant recombination in the bulk material. All these results confirm that adjusting the coordination environment via atom-level regulation for PEC water splitting evidently promotes to the charge separation/transfer and realizes efficient energy conversion. 

Open circuit potential (OCP) transient decay profile provides an additional information on the photogenerated charge carrier behavior. The OCP in dark is positive and then shifts to the negative direction under illumination (Supplementary Fig. 21a), which is caused by built-in electric field generated by the photo-generated carriers<sup>27</sup> . SAs Pt:Fe2O3 presents a strikingly accelerated OCP decay as terminating the illumination in relative to NPs Pt/Fe2O3, representing a large photovoltage generation (ΔOCP = OCPdark - OCPlight). Charge transfer and recombination are principally two competing processes that determine the water oxidation rate on the photoanode surface. To 

Nature Communications |  (2023) 14:2640 

5 

Article 

https://doi.org/10.1038/s41467-023-38343-6 

further clarify the charge recombination rate at the semiconductor/ electrolyte junction, the carrier transfer lifetime was calculated from the derived-OCP values, as depicted in Fig. 4e (see details for supporting information). NPs Pt/Fe2O3 displays a carrier lifetime of 11.69 ms when illumination was removed, one time lower than the pristine Fe2O3 (20.32 ms). SAs Pt substitution continues to reduce upon 7.22 ms on Fe2O3, indicating effective charge separation and fast transfer kinetics. In addition, the incident photon-to-current conversion efficiency (IPCE) on SAs Pt:Fe2O3 is remarkably improved over the entire range of 340-600 nm (Supplementary Fig. 21b). 

Figure 4f shows the photoelectrochemical impedance spectroscopy (PEIS) for the corresponding photoanodes, and the equivalent circuit was employed to fit the Nyquist plots of PEIS (inset of Fig. 4f). SAs Pt:Fe2O3 exhibits a considerably lower resistance (546.50 Ω) than NPs Pt/Fe2O3 (809.80 Ω) and Fe2O3 (2719.40 Ω), as summarized in Supplementary Table 3. And, SAs Pt:Fe2O3 remains a relatively stable photocurrent for 10 h durability (Supplementary Fig. 22a). The gases produced from the working and counter electrodes present the evolved O2 and H2 with a ratio of 2:1 with the Faraday efficiencies of gas productions closed to 100% (Supplementary Fig. 22b). In fact, anion and cations species modulation allow to induce extra electrons near Fe<sup>3+</sup> sites to form Fe<sup>2+</sup> sites, which can enhance the electrical conductivity of Fe2O3. However, high amount metal doping would principally induce the recombination centers by creating inter-bandgap energy states since the Fe<sup>2+</sup> sites are near to the surface region, causing trapping states and high overpotential for water oxidation. The coordination of single atomic-level Pt substitution for Fe<sup>3+</sup> can avoid the high concentration of doping to a certain degree, which increases the polaron hopping probability, and feasibly enhances the photogenerated charge carrier rate for PEC reaction, consistent with the DFT calculation. On the other hand, atom-level substitution near to the surface would inhibit the interfacial charge recombination, which is reflected by the low Von. 

The flat band potentials (Efb) of SAs Pt:Fe2O3 and NPs Pt/Fe2O3 were conducted by Mott-Schottky measurement. Efb is cathodically shifted since Pt was induced (Fig. 4g), coincided with the shift of Von from the J-V plot (Fig. 4b). SAs Pt:Fe2O3 has shown a lower Efb (0.35 VRHE) than NPs Pt/Fe2O3 (0.37 VRHE), manifesting the change in the band energetics. Besides, the similar slopes of Mott–Schottky plots represent the resembled carrier concentration, implying the close donor densities in the supporting materials loading with Pt nanoparticles and single-atom. Ultraviolet photoelectron spectroscopy (UPS) and ultraviolet-visible (UV-Vis) absorption were implemented to illustrate the band edge positions of the photoanodes. Tauc plots of photoanodes declare the band gaps of the pristine Fe2O3, NPs Pt/ Fe2O3, and SAs Pt:Fe2O3 are 2.07, 2.03, and 2.01 eV (Supplementary Fig. 23), respectively, coherent with the decreased slopes of MottSchottky (Fig. 4g). The work functions of the samples were determined by subtracting the cutoff energies (Ecutoff) from the UPS curves (Fig. 4h). The positions of the valence band maxima in regard to the Fermi levels were derived from the onset of valence band photoemission on the low binding energy edges of UPS spectra (inset of Fig. 4h). Based on these results, the determined band positions for the corresponding samples are summarized in Fig. 4i and Supplementary Table 4, according to the literatures reported<sup>3,47</sup> . One can see that tailoring Pt-O sites can influence the band structure, promote the charge separation, and accelerate the photogenerated holes transferring to the semiconductor/electrolyte surface for water oxidation, therefore enhancing PEC performance. 

### IMPS and TAS analysis for carrier kinetics 

Furthermore, we performed intensity modulated photocurrent spectroscopy (IMPS) and transient absorption spectroscopy (TAS) to understand the charge carrier kinetics in various Fe2O3 photoanodes. The semicircle coincides with the competition between interfacial carrier transfer and electron-hole recombination (Supplementary Fig. 24). 

The frequency of the maximum imaginary is associated with the sum of charge transfer (ktrans) and recombination (krec) rate constants (ktrans+krec)<sup>48–50</sup> . The ratio of ktrans/(ktrans+krec) is taken by comparing the instantaneous photocurrent and steady-state photocurrent. SAs Pt:Fe2O3 exhibits the highest ktrans values over the measured potential range (Fig. 5a), indicating that single atoms speed up the charge carrier mobility and quickly transfer from the bulk material to the surface or to the back contact. By contrast, the krec of SAs Pt:Fe2O3 is lower than that of NPs Pt/Fe2O3, and almost overlapped with that of the pristine Fe2O3 in the potential of 0.8–1.1 VRHE (Fig. 5b), indicating high charge transfer rate of SAs Pt:Fe2O3. Further considering surface substitution by SAs Pt, Fermi level pinning effect caused by surface states can be eliminated. With the Pt nanoparticles decorated on the surface, the aggregated particles are inefficient to change the inherent surface trap states possibly owing to the deep-level defects, while atomic Pt substitution does not induce more defects in hematite (Supplementary Fig. 25). Further on, the high charge transfer efficiency of ktrans/(ktrans+krec) can be obtained on SAs Pt:Fe2O3, especially in the potential range of 0.8-1.1 VRHE (Fig. 5c), suggesting that the charge recombination is greatly reduced via single atomic bulk and surface doping. In other words, Pt-O coordination favors the photoresponse at low potentials. 

TAS can be used to characterize the dynamics of photoinduced charge carrier. The distinct absorption spectra of photoelectrons and holes in photoanode make it possible to monitor the concentration variation of the species, especially the fates of photoholes and photoelectrons on the timescale of picosecond to microseconds. TAS of hematite principally presents two bands, where a bleach band at a probe wavelength of ~600 nm is ascribed to trapping photoelectrons, and an absorption band of ~700 nm corresponds to photoholes<sup>51,52</sup> . Under OCP condition (Supplementary Fig. 26), the photogenerated charge carrier dynamics can be associated to the bulk electron-hole recombination since the decay dynamics are faster than the timescale of water oxidation on the surface. From the decay dynamics photoinduced absorption (Fig. 5d–f), the carrier dynamics for the samples was calculated by fitting the kinetics traces at 600 nm and 700 nm (Supplementary Table 5). The charge carrier decay average lifetime of τav at 600 nm extends from 304.49 ps (Fe2O3) to 437.28 ps for NPs Pt/Fe2O3 and 486.76 ps for SAs Pt:Fe2O3. The increased charge carrier decay lifetime of the absorption signal indicates that single atom doping can effectively promote charge separation, extend charge carrier decay lifetime, and reduce the charge recombination on the picosecond time scale. SAs Pt:Fe2O3 shows the long lifetimes at 600 and 700 nm relative to NPs Pt/Fe2O3 and Fe2O3, indicative of the long-lived photoholes for water oxidation. The pristine Fe2O3 exhibits a fast decay among all samples due to the serious electron-hole recombination. These provide strong evidence that the charge recombination kinetics can be greatly suppressed by SAs Pt doping, which favors to the water photooxidation of hematite under the present experimental conditions. We next carried out the nonadiabatic (NA) molecular dynamics with decoherence-induced surface hopping (DISH) approach to analysis the charge carrier dynamics of hematite, and the simulated data are shown in Fig. 5g–i. Fitting the curves to an exponent, PðtÞ = expð� τt<sup>~~Þ~~,</sup> we obtained the charge trapping, detrapping, transfer, and recombination time scales (Supplementary Table 6). In general, electron-hole recombination results in short carrier lifetime and reduces OER performance. In the pristine Fe2O3 system, the photogeneration charge carriers occur the detrimental recombination process (Fig. 5g). Doping the Fe2O3 with Pt NPs (Fig. 5h), free carrier recombination process is inhibited compared to the Fe2O3 system, and the electron transfer between Fe2O3 and NPs Pt becomes the main process. The fast charge transfer promotes efficient charge separation and prolongs the carrier lifetime. Changing the NPs Pt to SAs Pt (Fig. 5i), the occurrence of free carrier recombination is further reduced compared to NPs Pt/Fe2O3 

Nature Communications |  (2023) 14:2640 

6 

Article 

https://doi.org/10.1038/s41467-023-38343-6 



Fig. 5 | IMPS and TAS for Fe2O3, NPs Pt/Fe2O3, and SAs Pt:Fe2O3. a Charge transfer rate constant (ktrans); b charge recombination rate constant (krec); c charge transfer efficiencies extracted from IMPS analysis; d, e transient absorption decays observed at d 600 nm and e 700 nm. The fits for the decays were calculated with 

three exponential decay model, shown as the solid lines, and the circles represent experimental data; f time-resolved transient absorption spectra of SAs Pt:Fe2O3 when excited with 380 nm; g–i electron trapping, electron detrapping, hole trapping, and charge recombination of g Fe2O3, h NPs Pt/Fe2O3, and i SAs Pt:Fe2O3. 

system, and the charge carriers mainly take place in trapping and detrapping processes. The charge trapping and detrapping are in dynamic equilibrium, which extends the carrier lifetime and improves the OER performance of Fe2O3 comparable to NPs Pt doping, demonstrating the above experimental results. 

### Further PEC performance enhancement via surface oxygen vacancies 

Benefited from the role of single atom substitution, we further used plasma etching treatment to produce surface oxygen vacancies (OV) and accelerate the charge transfer on SAs Pt:Fe2O3 (remarked as SAs Pt:Fe2O3-OV). No evident morphology change can be discerned for the treated sample (Supplementary Fig. 27). Single atoms are still retained from HAADF-STEM observation (Fig. 6a). Surface vacancies can be viewed as marked by the circle (Fig. 6b), accompanied by the irregular surface boundary originated from plasma treatment (Supplementary Fig. 28). Moreover, SAs Pt:Fe2O3-Ov maintains two peaks at 1.96 Å and 2.86 Å in the Pt L-edge EXAFS spectrum (Fig. 6c), representing the coordination of Pt-O and Pt-O-Fe (Supplementary Fig. 29). The slight decrease in peak intensity on SAs Pt:Fe2O3-OV can be observed compared with SAs Pt:Fe2O3 (Supplementary Fig. 30), reflecting a decrease in the 

coordination number of Pt to O ascribed to the presence of oxygen vacancies. The SAs Pt:Fe2O3-OV displays Pt-O bonding with CN approaching to 4 at 1.96 Å in the first coordination shell (lower than SAs Pt:Fe2O3 with CN of 4.5), while Pt-O-Fe bonding with CN approaching 1 at 2.86 Å in the second coordination shell (Supplementary Table 7). The fitting results of χ(R) and χ(k) space spectra with reasonable R-factor quantitatively support the local atomic structure and coordination numbers information. O 1s XPS spectrum shows that the lattice oxygen is shifted to higher binding energy by 180 mV for SAs Pt:Fe2O3-OV, while Pt 4f XPS spectrum is negatively shifted after plasma treatment (Supplementary Fig. 31). This means that SAs Pt in Fe2O3-OV are electron-richer compared with SAs Pt:Fe2O3, and more charge can be transferred from Fe2O3 to Pt. Additionally, Pt content on the top surface has decreased from 9.96 (without plasma treatment) to 6.97 at.% (Supplementary Table 8). This can be originated from the generated surface OV, which anchors the Pt single atom to stabilize it. 

The PEC performance of SAs Pt:Fe2O3-OV is further improved after optimization (Supplementary Fig. S32), in which the photocurrents reach to 3.65 and 5.30 mA cm<sup>-2</sup> at 1.23 and 1.5 VRHE with a maximum ABPE value of 0.68% (Fig. 6d, e). This is more than double the previously reported highest value of the doped Fe2O3-based photoanodes 

Nature Communications |  (2023) 14:2640 

7 

Article 

https://doi.org/10.1038/s41467-023-38343-6 



Fig. 6 | Performance improvement of SAs Pt:Fe2O3-Ov. a, b High resolution HAADF STEM images; c k3-weighted Fourier-transform spectra from EXAFS; d J-V curves in 1 M KOH under AM 1.5G illumination; e ABPE value; f time-resolved transient absorption spectra when excited with 380 nm; g charge separation and 

charge transfer efficiencies; h charge transfer rate constants (ktrans)and charge recombination rate constants (krec); i transient absorption decays observed at 600 and 700 nm. The fits for the decays were calculated with three exponential decay model, shown as the solid lines, whereas the circles represent experimental data. 

(Supplementary Table 1), and even superior to the cocatalysts decorated Fe2O3-based photoanodes (Supplementary Table 9). Meanwhile, Von shifts to the negative direction with ΔVon = 5 mV, in line with the negative shift of the flat band potential on SAs Pt:Fe2O3-OV deduced from the Mott–Schottky plot (Supplementary Fig. 33). This is currently known as one of the best performances in terms of photocurrent and Von for elemental doping hematite semiconductors. Moreover, the electrochemical specific surface area of SAs Pt:Fe2O3-OV is evidently increased, almost 4 times higher than that of the SAs Pt:Fe2O3 (Supplementary Fig. 34). There is no notable enhancement on the charge separation between SAs Pt:Fe2O3-OV and SAs Pt:Fe2O3, but the charge transfer efficiency of SAs Pt:Fe2O3-OV highly increases (Fig. 6g and Supplementary Fig. 35), supporting the charge transfer influenced by the oxygen vacancies. The charge carrier derived from OCP displays that SAs Pt:Fe2O3-OV has faster photoresponse (Supplementary Fig. S36), along with higher ktrans value, lower krec values (Fig. 6h and Supplementary Fig. 37), and long charge carrier lifetime (Fig. 6f, i) comparable with non-treated SAs Pt:Fe2O3 (Supplementary Fig. 38). The surface recombination is generally happened which affects the oxygen evolution reaction and PEC activity of the photoelectrode. Here the surface oxygen vacancies induced can serve as surface states below the conduction band minimum that boost the charge carrier transfer. The defects raise the flat band potential away from the redox potential of O2/H2O and increase the upward bending of the hematite band edge. 

This can facilitate the charge transfer from the Fe2O3 surface to the electrolyte. In other words, surface oxygen vacancies are conductive to a reduced interfacial charge-transfer barrier and surface trapping states. PDOS of SAs Pt:Fe2O3-OV demonstrates that oxygen vacancies can eliminate the trap states between the band gap of Fe2O3 (Supplementary Fig. 39a, b), reducing the charge recombination. Also, ELF (Supplementary Fig. 39c) shows that oxygen vacancies noticeably reduce electron localization and electron transport resistance, which act as active sites for chemisorption of the intermediates, and improve the surface water ability. All these results demonstrate that the synergistic effect of single atom coordination and surface oxygen vacancies are responsible for the improved charge transfer and the suppressed photogenerated charge recombination, boosting water oxidation ability. 

Based on the calculation and experimental results above, a mechanism is proposed to clarify the improved charge carrier kinetics for SAs Pt decorated on the defected Fe2O3. The influence of charge transfer and recombination is schematically illustrated in Supplementary Fig. 40. When Fe2O3 is exposed to light to generate photogenerated carriers, most of the photo-generated carriers would be recombined instantaneously before arriving to the surface for water oxidation reaction owing to the short hole diffusion length. Few separated photogenerated electrons and holes in the conduction band and the valence band are transferred to the corresponding surface to 

Nature Communications |  (2023) 14:2640 

8 

Article 

https://doi.org/10.1038/s41467-023-38343-6 

participate in oxygen and hydrogen evolution reactions, causing the poor performance. When Pt species were incorporated to Fe2O3, the mobility of excited carrier can be accelerated, thereby improving the carrier transfer efficiency. In contrast to the traditional element doping, single atoms coordination is in favor of improving the charge separation efficiency and prolonging the charge carrier lifetime by the shift of the photogenerated holes towards the photoanode/electrolyte interface and of the electrons to the back side. On the other hand, single atom-level substitution can efficiently suppress the deeplevel defects in hematite relative to the nanoparticle/cluster-level doping, in which the latter with aggregated defects has a distribution along the photoanode. Further surface oxygen vacancies were produced in the material, thereby surface oxygen vacancies and reduced Fe<sup>2+</sup> species within the nanoflakes following the doping reaction mechanism. In addition, one-dimensional single-crystalline nanoflakes structure with enough light harvesting could facilitate the charge collection efficiency. 

## Discussion 

In summary, single platinum atom doped into Fe2O3 photoanode has been successfully synthesized by using 2,2-bipyridine as the ligand to chelate Pt cations, followed by the inert atmosphere treatment. Compared with NPs Pt loading, SAs Pt:Fe2O3 can obviously suppress the deep-level defects and shift the band edge positions of Fe2O3. The introduction of surface oxygen vacancies further enhances the PEC activity of the SAs Pt:Fe2O3. The resulting photoanode achieves the photocurrent densities of 3.65 and 5.30 mA cm<sup>−2</sup> at 1.23 and 1.5 VRHE with a high ABPE of 0.68% for the hematite-based photoanodes. The synergism of single atomic-level doping and surface oxygen vacancies improve charge carrier separation capability and injection efficiency at the semiconductor/electrolyte interface, prolong the charge carrier lifetime, and promote the reaction kinetics. These results clarify the importance of the designing single atom doping engineering in the photoelectrode to boost the efficient charge transfer and extending charge lifetime, and provide a design idea to construct highly efficient photoelectrodes for improving the solar conversion efficiency of other semiconductors. 

## Methods 

### Material preparation 

Iron foils (Alfa Aesar, 0.25 mm thick, 99.99%) with a size of 1 cm<sup>2</sup> were degreased by ultrasonic treatment in acetone and ethanol for 10 min, and then dried in a nitrogen stream. To prepare the α-Fe2O3 nanoflakes grown on iron substrate, iron foils were thermally annealed in a furnace (HF-Kejing Furnace, KSL-1100X) at 400 °C in air at a heating rate of 10 °C min<sup>−1</sup> and kept at the required temperature for 3~4 h. The entire sample surface became nanoflakes during the thermal annealing for the following treatment. Hexachloroplatinic acid hexahydrate (5 mmol) dissolved in ethanol was mixed with 2,2-bipyridine in a molar ratio of 1:1, 1:3, and 1:6 for 10 min The α-Fe2O3 nanoflakes were immersed into the above solution for different times (5 min, 15 min, 25 min, and 35 min), following by drying overnight in a vacuum oven at 60 °C. Next, the samples were annealing in Ar at 330 °C and 400 °C for 100 min for the synthesis of SAs Pt:Fe2O3 and NPs Pt/Fe2O3, respectively. For the SAs Pt:Fe2O3-OV, SAs Pt:Fe2O3 was treated in a plasma etching condition (HFKejing, PEC-500 W) in Ar at 20 W for various times (5 min, 15 min, 25 min, and 35 min). 

### Photoelectrochemical characterization 

Photoelectrochemical measurements were measured in a standard three-electrode system with a CHI 760D electrochemical analyzer. The light source was used the simulated AM 1.5 G (100 mW cm<sup>−2</sup> ) sunlight. The solar simulator used for PEC measurement was equipped with a total-reflection mirror and AM 1.5G fitter, and the spectrum was measured as shown in Supplementary Fig. 41. 1 M Potassium hydroxide (KOH, pH = 14) was used as an electrolyte. The prepared sample, Pt foil, 

and Ag/AgCl were used as the working electrode, counter electrode, and reference electrode, respectively. Photocurrent vs voltage (I-V) curves were recorded by scanning the potential from −0.5 to 0.65 VAg/ AgCl<sup>with a rate of 10 mV s−1. The measured potential was converted into</sup> a potential with respect to a reversible hydrogen electrode (RHE). There is no iR correction performed in the experiment. Electrochemical impedance spectroscopy (EIS) was performed at 1.23 VRHE and a small AC amplitude of 10 mV in the frequency range of 10<sup>−2</sup> –10<sup>5</sup> Hz under AM 1.5 G illumination. 

Applied bias photon-to-current efficiency (ABPE) can be calcuJ × <u>ð1:23�V bÞ</u> lated using the following equation of ABPE(%) = ptotal , in which J is the photocurrent density (mA cm<sup>−2</sup> ) obtained from AM 1.5G illumination, Vb refers to the applied bias potential versus RHE, and Ptotal is the total light intensity of AM 1.5 G. The incident photoelectron conversion efficiency (IPCE) was measured in 1 M KOH at a potential of 1.23 VRHE in a Xe lamp. IPCE was calculated using the formula of IPCE(%) = λJ ×× p 1240Light<sup>× 100%,where Jpresentsthephotocurrentdensity(mAcm−2),</sup> λ and Plight are the incident light wavelength (nm) and the power density obtained at a specific wavelength (mW cm<sup>−2</sup> ), respectively. Charge separation efficiency (ηsep, the yield of photo-generated holes reaching the semiconductor/electrolyte interface) and surface charge transfer efficiency (ηtrans, the yield of holes participating in the water oxidation reaction after reaching the electrode/electrolyte interface) JH2 O can be calculated using the following formula of ηsep = JH2O2<sup>and ηtrans =</sup> <u>J12H2:O52</u><sup>~~,~~in which JH2O and JH2O2 are the photocurrent densities obtained in 1</sup> M KOH without and with H2O2, 12.5 mA cm<sup>−2</sup> is the theoretical photocurrent of Fe2O3 under AM 1.5 G illumination. For comparison of charge recombination rate at the photoanode/electrolyte junction, the carrier lifetime was quantified by τn (τn ~~=~~ KeB<sup>ð</sup> <u>dOCPdt</u><sup>Þ�1).</sup> 

### Material characterization 

The crystalline structure and composition were performed by X-ray diffraction analysis (XRD, Rigaku RINT-2000, Cu Kα radiation at 40 kV and 40 mA) and X-ray photoelectron spectroscopy (XPS, ESCALAB 250xi, Thermo Fisher Scientific). The elemental contents were tested by inductively coupled plasma optical emission spectroscopy (ICPOES-720ES, Agilent, USA). The morphology was observed using field emission scanning electron microscopy (FE-SEM, Supra 55, Zeiss, Germany) and transmission electron microscopy (TEM, JEM-2100F, JEOL, Japan) systems. The cross-sectional SEM image was taken by argon-ion milling machine (GATAN, ILION693) with a voltage of 5 kV, following with SEM observation. The aberration-corrected high-angle annular dark-field scanning transmission electron microscopy was performed using JEM-ARM200F. UV-visible diffuse reflectance spectra were implemented on a UV-2600 (Shimadzu) spectrometer using BaSO4 as the reference. Photoluminescence (PL) spectra were performed on a HORIBA Fluoromax-4 (HORIBA JY, HORIBA Fluoromax-4, USA) under laser excitation at 350 nm. The electron paramagnetic resonance (EPR) measurements were recorded using a JES-FA200 spectrometer at low temperature (−150 °C). 

### Charge carrier kinetics measurements 

Intensity modulated photocurrent spectroscopy (IMPS) was performed with a potentiostat (PGSTAT302N, Metrohm), an impedance analyser (FRA32M, Metrohm), and a light-emitting diode (LED) driver kit (Metrohm) that drove illumination of 420 nm power UV LED in 1 M KOH at different voltages (0.8 VRHE, 0.9 VRHE, 1.0 VRHE, 1.1 VRHE, 1.2 VRHE, 1.3 VRHE, 1.4 VRHE, and 1.5 VRHE). The LED intensity was 5.5 mW cm<sup>−2</sup> , and it was modulated by 10% in the range of 10 kHz–0.1 Hz. Transient absorption spectroscopy (TAS) measurements were performed on a Helios (Ultrafast systems) spectrometers using a regeneratively amplified femtosecond Ti:sapphire laser system (Spitfire Pro-F1KXP, Spectra-Physics; frequency, 1 kHz; max pulse energy, ~8 mJ; pulse 

Nature Communications |  (2023) 14:2640 

9 

Article 

https://doi.org/10.1038/s41467-023-38343-6 

width, 120 fs) at room temperature. For the TAS sample preparation of the pristine hematite, ten pieces of Fe2O3 nanoflakes with the same experimental condition were scratched from the iron foils into a 5 ml sample storage using a plastic dropper. Then, 3 ml deionized water was added into the storage, and was ultrasonic treated for 30 min to maintain high dispersion of the sample. For comparison, we conducted the TAS measurement of the deionized water to eliminate its disturbance during the measurement. The TAS sample preparations of NPs Pt/Fe2O3 and SAs Pt:Fe2O3 were used the same treatment of the pristine Fe2O3. The data were analyzed through commercial software (Surface Xplorer, Ultrafast Systems). An individual three-exponential decay model was used to calculate the fits of the decay. The amplitude weighted average lifetime (τav) can be fitted using the following equation of τav ~~=~~ SUMSUM½Ai½Ai × τ� i�<sup>~~,~~where Ai is the amplitude of the component</sup> with lifetime (τi), and τi is the amplitude weighted lifetime. 

### Simulation methodology 

Geometry optimization, electronic structure, adiabatic molecular dynamic (MD), and nonadiabatic (NA) coupling calculations were performed using Vienna ab initio simulation package (VASP) software<sup>53</sup> . The electron exchange-correlation and electron-ion core interactions were treated with the generalized gradient approximation of Perdew–Burke–Ernzerhof (PBE)<sup>54</sup> and projector-augmented-wave (PAW)<sup>55</sup> approaches, respectively. Typically, the Fe 3d strong correlated electrons cannot be well-described by the standard DFT method. Therefore, to correct the strongly correlated electronic nature of Fe 3d-electrons, we applied the on-site Coulomb correction (U = 5 eV for Fe 3d orbitals) to accurately describe the band gap of Fe2O3 (~2.0 eV), which agrees well with the data (2.1 eV) calculated using the same functional method<sup>56</sup> . The plane wave cutoff energy was set to 500 eV. The weak van der Waals interactions were described with the Grimme DFT-D3 methdsh<sup>57</sup> . The geometry optimizations were carried out at Γ- point because a large supercell was used. The electronic structure calculations were performed on 2 × 2 × 1 grid for k-point sampling. After the geometry optimization, all systems were heated to 300 K by repeated velocity scaling. Then, 4 ps microcanonical ensemble adiabatic MD trajectories were obtained. The nonadiabatic molecular dynamic (NAMD) simulations were calculated with the decoherenceinduced surface hopping (DISH) method<sup>58</sup> implemented within the time-dependent Kohn–Sham density functional framework<sup>59–61</sup> , which were performed using the PYthon eXtension for Ab Initio Dynamics (PYXAID) code<sup>62,63</sup> . 

The four-electron OER occurs based on Equations (1)–(4), where the * represents the surfaces: 



<!-- Start of picture text -->
* + H2O ! *OH + e � + H + ð1Þ<br>*OH ! *O + e � + H + ð2Þ<br>H2O + *O ! *OOH + e � + H + ð3Þ<br><!-- End of picture text -->



<!-- Start of picture text -->
*OOH ! * + O2 + e � + H + ð4Þ<br><!-- End of picture text -->

The Gibbs free energy G was calculated with the followed equation of G = E + EZPE � TS � eU. E, EZPE , S, U, and T correspond single point energy, zero-point energy, entropy, potential versus standard hydrogen electrode, and temperature (298.15 K), respectively. The overpotential (η) toward OER was computed using the equation (U = 0 V) of η = maxfΔG1,ΔGe2,ΔG3,ΔG4g � 1:23: The ΔG1,ΔG2,ΔG3, and ΔG4 represent the Gibbs free energy difference for elementary reactions. 

## Data availability 

The data that support the findings of this study are available from the corresponding authors upon reasonable request. Source data are provided with this paper. 

## References 

1. Liu, Y. et al. Identifying reactive sites and surface traps in chalcopyrite photocathodes. Angew. Chem. Int. Ed. 60, 23651–23655 (2021). 

2. Kim, T. W. & Choi, K.-S. Nanoporous BiVO4 photoanodes with duallayer oxygen evolution catalysts for solar water splitting. Science 343, 990–994 (2014). 

3. Xiao, Y. et al. Band structure engineering and defect control of Ta3N5 for efficient photoelectrochemical water oxidation. Nat. Catal. 3, 932–940 (2020). 

4. Mascaretti, L. et al. Plasmon-enhanced photoelectrochemical water splitting for efficient renewable energy storage. Adv. Mater. 31, 1805513 (2019). 

5. Gao, R.-T. et al. Towards long-term photostability of nickel hydroxide/BiVO4 photoanodes for oxygen evolution catalysts via in situ catalyst tuning. Angew. Chem. Int. Ed. 59, 6213–6218 (2020). 

6. Hernandez-Pagan, E. A. et al. Resistance and polarization losses in aqueous buffer–membrane electrolytes for water-splitting photoelectrochemical cells. Energy Environ. Sci. 5, 7582–7589 (2012). 

7. Pan, L. et al. Cu2O photocathodes with band-tail states assisted hole transport for standalone solar water splitting. Nat. Commun. 11, 318 (2020). 

8. Gao, R.-T. & Wang, L. Stable cocatalyst-free BiVO4 photoanodes with passivated surface states for photocorrosion inhibition. Angew. Chem. Int. Ed. 59, 23094–23099 (2020). 

9. Andrei, V. et al. Floating perovskite-BiVO4 devices for scalable solar fuel production. Nature 609, 518–522 (2022). 

10. Kuang, Y. et al. Ultrastable low-bias water splitting photoanodes via photocorrosion inhibition and in situ catalyst regeneration. Nat. Energy 2, 16191 (2016). 

11. Roy, P. et al. Oxide Nanotubes on Ti-Ru alloys: strongly enhanced and stable photoelectrochemical activity for water splitting. J. Am. Chem. Soc. 133, 5629–5631 (2011). 

12. Young, K. J. et al. Light-driven water oxidation for solar fuels. Coord. Chem. Rev. 256, 2503–2520 (2012). 

13. Mi, Y. et al. Constructing a AZO/TiO2 core/shell nanocone array with uniformly dispersed Au NPs for enhancing photoelectrochemical water splitting. Adv. Energy Mater. 6, 1501496 (2016). 

14. Tilley, S. D., Cornuz, M., Sivula, K. & Gratzel, M. Light-induced water splitting with hematite: improved nanostructure and iridiumoxide catalysis. Angew. Chem. Int. Ed. 49, 6405–6408 (2010). 

15. Sivula, K. et al. Photoelectrochemical water splitting with mesoporous hematite prepared by a solution-based colloidal approach. J. Am. Chem. Soc. 132, 7436–7444 (2010). 

16. Mayer, M. T., Lin, Y., Yuan, G. & Wang, D. Forming heterojunctions at the nanoscale for improved photoelectrochemical water splitting by semiconductor materials: case studies on hematite. Acc. Chem. Res. 46, 1558–1566 (2013). 

17. Jang, J.-W. et al. Enhancing charge carrier lifetime in metal oxide photoelectrodes through mild hydrogen treatment. Adv. Energy Mater. 7, 1701536 (2017). 

18. Ye, S. et al. Unassisted photoelectrochemical cell with multimediator modulation for solar water splitting exceeding 4% solarto-hydrogen efficiency. J. Am. Chem. Soc. 143, 12499–12508 (2021). 

19. Cui, J. et al. 2D bismuthene as a functional interlayer between BiVO4 and NiFeOOH for enhanced oxygen-evolution photoanodes. Adv. Funct. Mater. 32, 2207136 (2022). 

20. Solarska, R. et al. Enhanced water splitting at thin film tungsten trioxide photoanodes bearing plasmonic gold-polyoxometalate particles. Angew. Chem. Int. Ed. 53, 14196–14200 (2014). 

Nature Communications |  (2023) 14:2640 

10 

Article 

https://doi.org/10.1038/s41467-023-38343-6 

21. Altomare, M. et al. Molten o-H3PO4: a new electrolyte for the anodic synthesis of self-organized oxide structures − WO3 nanochannel layers and others. J. Am. Chem. Soc. 137, 5646–5649 (2015). 

22. Bloor, L. G. et al. Solar-driven water oxidation and decoupled hydrogen production mediated by an electron-coupled-proton buffer. J. Am. Chem. Soc. 138, 6707–6710 (2016). 

23. Stefik, M. et al. Transparent, conducting Nb:SnO2 for host-guest photoelectrochemistry. Nano Lett. 12, 5431–5435 (2012). 

24. Qiu, W., Xiao, S., Tong, Y. & Yang, S. Toward efficient charge collection and light absorption: a perspective of light trapping for advanced photoelectrodes. J. Phys. Chem. C. 123, 18753–18770 (2019). 

25. Wang, L., Zhu, J. & Liu, X. Oxygen-vacancy-dominated cocatalyst/ hematite interface for boosting solar water splitting. ACS Appl. Mater. Interface 11, 22271–22277 (2019). 

26. Yoon, K.-Y. et al. NiFeOx decorated Ge-hematite/perovskite for an efficient water splitting system. Nat. Commun. 12, 4309 (2021). 

27. Zhang, H. et al. Gradient tantalum-doped hematite homojunction photoanode improves both photocurrents and turn-on voltage for solar water splitting. Nat. Commun. 11, 4622 (2020). 

28. Wang, L., Nguyen, N. T., Huang, X., Schmuki, P. & Bi, Y. Hematite photoanodes: synergetic enhancement of light harvesting and charge management by sandwiched with Fe2TiO5/Fe2O3/Pt structures. Adv. Funct. Mater. 27, 1703527 (2017). 

29. Liao, P., Toroker, M. C. & Carter, E. A. Electron transport in pure and doped hematite. Nano Lett. 11, 1775–1781 (2011). 

30. Sivula, K., Le Formal, F. & Gratzel, M. Solar water splitting: progress using hematite (α-Fe2O3) photoelectrodes. ChemSusChem 4, 432–449 (2011). 

31. Zhang, Y. et al. Nonmetal P-doped hematite photoanode with enhanced electron mobility and high water oxidation activity. Energy Environ. Sci. 6, 1965–1970 (2013). 

32. Li, C., Luo, Z., Wang, T. & Gong, J. Surface, bulk, and interface: rational design of hematite architecture toward efficient photoelectrochemical water splitting. Adv. Mater. 30, 1707502 (2018). 

33. Mirbagheri, N. et al. Visible light driven photoelectrochemical water oxidation by Zn- and Ti-doped hematite nanostructures. ACS Catal. 4, 2006–2015 (2014). 

34. Toussaint, C. et al. Combining mesoporosity and Ti-doping in hematite films for water splitting. J. Phys. Chem. C. 119, 1642–1650 (2015). 

35. Ling, Y., Wang, G., Wheeler, D. A., Zhang, J. Z. & Li, Y. Sn-doped hematite nanostructures for photoelectrochemical water splitting. Nano Lett. 22, 2119–2125 (2011). 

36. Hufnagel, A. G. et al. Why tin-doping enhances the efficiency of hematite photoanodes for water splitting-the full picture. Adv. Funct. Mater. 28, 1804472 (2018). 

37. Liu, Y., Formal, F. L., Boudoire, F. & Guijarro, N. Hematite photoanodes for solar water splitting: a detailed spectroelectrochemical analysis on the pH-dependent performance. ACS Appl. Energy Mater. 2, 6825–2833 (2019). 

38. Shen, S. et al. Physical and photoelectrochemical properties of Zrdoped hematite nanorod arrays. Nanoscale 5, 9867–9874 (2013). 

39. Li, N. et al. Effect of La-doping on optical bandgap and photoelectrochemical performance of hematite nanostructures. J. Mater. Chem. A 2, 19290–19297 (2014). 

40. Ruoko, T.-P. et al. Charge carrier dynamics in tantalum oxide overlayered and tantalum doped hematite photoanodes. J. Mater. Chem. A 7, 3206–3215 (2019). 

41. Ahn, H.-J., Yoon, K.-Y., Kwak, M.-J., Park, J. & Jang, J.-H. Boron Doping of metal-doped hematite for reduced surface recombination in water splitting. ACS Catal. 8, 11932–11939 (2018). 

42. He, Y. et al. What limits the performance of Ta3N5 for solar water splitting? Chem 1, 640–655 (2016). 

43. Gao, R. et al. Pt/Fe2O3 with Pt-Fe pair sites as a catalyst for oxygen reduction with ultralow Pt loading. Nat. Energy 6, 414–623 (2021). 

44. Poerwoprajitno, A. R. et al. A single-Pt-atom-on-Ru-nanoparticle electrocatalyst for CO-resilient methanol oxidation. Nat. Catal. 5, 231–237 (2022). 

45. Zhang, X. et al. Engineering single-atomic Ni-N4-O sites on semiconductor photoanodes for high-performance photoelectrochemical water splitting. J. Am. Chem. Soc. 143, 20657–20669 (2021). 

46. Wang, L., Nguyen, N. T., Zhang, Y., Bi, Y. & Schmuki, P. Enhanced solar water splitting by swift charge separation in Au/FeOOH sandwiched single-crystalline Fe2O3 nanoflake photoelectrodes. ChemSusChem 10, 2720–2727 (2017). 

47. Hou, Y. et al. A generic interface to reduce the efficiency-stabilitycost gap of perovskite solar cells. Science 358, 1192–1197 (2017). 

48. Kruger, J., Plass, R., Gratzel, M., Cameron, P. J. & Peter, L. M. Charge transport and back reaction in solid-state dye-sensitized solar cells: a study using intensity-modulated photovoltage and photocurrent spectroscopy. J. Phys. Chem. B 107, 7536–7539 (2003). 

49. Ravishankar, S. et al. Intensity-modulated photocurrent spectroscopy and its application to perovskite solar cells. J. Phys. Chem. C. 123, 24995–25014 (2019). 

50. Boudoire, F. et al. Spray synthesis of CuFeO2 photocathodes and inoperando assessment of charge carrier recombination. J. Phys. Chem. C. 125, 10883–10890 (2021). 

51. Barroso, M. et al. Dynamics of photogenerated holes in surface modified a-Fe2O3 photoanodes for solar water splitting. Proc. Natl Acad. Sci. 109, 15640–15645 (2012). 

52. Barroso, M., Pendlebury, S. R., Cowan, A. J. & Durrant, J. R. Charge carrier trapping, recombination and transfer in hematite (a-Fe2O3) water splitting photoanodes. Chem. Sci. 4, 2724–2734 (2013). 

53. Kresse, G. & Furthmüller, J. Efficient iterative schemes for Ab initio total-energy calculations using a plane-wave basis set. Phys. Rev. B 54, 11169–11186 (1996). 

54. Perdew, J. P., Burke, K. & Ernzerhof, M. Generalized gradient approximation made simple. Phys. Rev. B 77, 3865–3868 (1996). 

55. Blochl, P. E. Projector augmented-wave method. Phys. Rev. B 50, 17953–17979 (1994). 

56. Dzade, N. Y., Roldan, A. & Leeuw, N. H. D. A density functional theory study of the adsorption of benzene on hematite (α-Fe2O3) surfaces. Minerals 4, 89–115 (2014). 

57. Grimme, S., Antony, J., Ehrlich, S. & Krieg, H. A consistent and accurate Ab initio parametrization of density functional dispersion correction (DFT-D) for the 94 elements H-Pu. J. Chem. Phys. 132, 154104 (2010). 

58. Jaeger, H. M., Fischer, S. & Prezhdo, O. V. Decoherence-induced surface hopping. J. Chem. Phys. 137, 22A545 (2012). 

59. Craig, C. F., Duncan, W. R. & Prezhdo, O. V. Trajectory surface hopping in the time-dependent kohn-sham approach for electronnuclear dynamics. Phys. Rev. B 95, 163001 (2005). 

60. Kohn, W. & Sham, L. J. Self-consistent equations including exchange and correlation effects. Phys. Rev. 140, A1133–A1138 (1965). 

61. Fischer, S. A., Habenicht, B. F., Madrid, A. B., Duncan, W. R. & Prezhdo, O. V. Regarding the validity of the time-dependent kohnsham approach for electron-nuclear dynamics via trajectory surface hopping. J. Chem. Phys. 134, 024102 (2011). 

62. Akimov, A. V. & Prezhdo, O. V. The Pyxaid program for non-adiabatic molecular dynamics in condensed matter systems. J. Chem. Theory Comput. 9, 4959 (2013). 

63. Akimov, A. V. & Prezhdo, O. V. Advanced capabilities of the PYXAID program: integration schemes, decoherence effects, multiexcitonic states, and field-matter interaction. J. Chem. Theory Comput. 10, 789–804 (2014). 

Nature Communications |  (2023) 14:2640 

11 

Article 

https://doi.org/10.1038/s41467-023-38343-6 

## Acknowledgements 

The work was financially supported by the National Key Research and Development Program of China (2022YFA1205200), the National Natural Science Foundations of China (51721002, 21965024, 22269016), and the Inner Mongolia funding (2020JQ01). 

Peer review information Nature Communications thanks Wenping Si, Tero-Petri Ruoko and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. 

Reprints and permissions information is available at http://www.nature.com/reprints 

## Author contributions 

L.W. and L.M.W. proposed and supervised the project; R.-T.G. designed and performed the materials synthesis and PEC measurements. J.Z. analyzed the EXAFS results. T.N. performed the IMPS tests. X.L. and X.Z. assisted the data analysis. J.H. performed the DFT calculation. L.W. and R.-T.G. wrote the manuscript. L.W. and L.M.W. revised the manuscript. All authors contributed to discussion and manuscript review. 

## Competing interests 

The authors declare no competing interests. 

## Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-023-38343-6. 

Correspondence and requests for materials should be addressed to Jinlu He, Lei Wang or Limin Wu. 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

#### © The Author(s) 2023 

Nature Communications |  (2023) 14:2640 

12 

