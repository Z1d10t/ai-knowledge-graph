# Ubiquitous Superconducting Diode Effect in Superconductor Thin Films.

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Physical Review Letters |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 215 |
| 作者 | Yasen Hou, F. Nichele, H. Chi, A. Lodesani, Yingying Wu, M. Ritter, D. Haxell, M. Davydova et al. |
| DOI | 10.1103/PhysRevLett.131.027001 |
| 源文件 | 013_Hou_2022_Ubiquitous-Superconducting-Diode-Effect-in-Super.pdf |

---
# **Ubiquitous Superconducting Diode Effect in Superconductor Thin Films** 

Yasen Hou<sup>1*</sup> , Fabrizio Nichele<sup>2</sup> , Hang Chi<sup>1,3</sup> , Alessandro Lodesani<sup>1</sup> , Yingying Wu<sup>1</sup> , Markus F. Ritter<sup>2</sup> , Daniel Z. Haxell<sup>2</sup> , Margarita Davydova<sup>4</sup> , Stefan Ilić<sup>5</sup> , Ourania Glezakou-Elbert<sup>6</sup> , Amith Varambally<sup>7</sup> , F. 

Sebastian Bergeret<sup>5,8</sup> , Akashdeep Kamra<sup>9*</sup> , Liang Fu<sup>4</sup> , Patrick A. Lee<sup>4*</sup> , Jagadeesh S. Moodera<sup>1,4*</sup> 

- _1Francis Bitter Magnet Laboratory and Plasma Science and Fusion Center, Massachusetts Institute of Technology, Cambridge, MA 02139, USA_ 

         - _2IBM Research Europe - Zurich, Säumerstrasse 4, 8803 Rüschlikon, Switzerland_ 

         - _3U.S. Army CCDC Army Research Laboratory, Adelphi, Maryland 20783, USA_ 

- _4Department of Physics, Massachusetts Institute of Technology, Cambridge, MA 02139, USA_ 

      - _5Centro de Física de Materiales (CFM-MPC), Centro Mixto CSIC-UPV/EHU, Pº Manuel de Lardizabal 5, Donostia-San Sebastián 20018, Spain_ 

               - _6Hanford High School, Richland, Washington 99354, USA_ 

            - _7Vestavia Hills High School, Vestavia Hills, Alabama 35216, USA_ 

         - _8Donostia International Physics Center (DIPC), Donostia-San Sebastián 20018, Spain_ 

   - _9Condensed Matter Physics Center (IFIMAC) and Departamento de Física Teórica de la Materia Condensada, Universidad Autónoma de Madrid, E-28049 Madrid, Spain_ 

* Corresponding authors. Email: yshou@mit.edu (Yasen Hou); akashdeep.kamra@uam.es (Akashdeep Kamra); palee@mit.edu (Patrick A. Lee); moodera@mit.edu (Jagadeesh S. Moodera) 

### **ABSTRACT** 

The macroscopic coherence in superconductors supports dissipationless supercurrents which could play a central role in emerging quantum technologies. Accomplishing unequal supercurrents in the forward and backward directions would enable unprecedented functionalities. This nonreciprocity of critical supercurrents is called superconducting (SC) diode effect. We demonstrate strong SC diode effect in conventional SC thin films, such as niobium and vanadium, employing external magnetic fields as small as 1 Oe. Interfacing the SC layer with a ferromagnetic semiconductor EuS, we further accomplish non-volatile SC diode effect reaching a giant efficiency of 65%. By careful control experiments and theoretical modeling, we demonstrate that the critical supercurrent nonreciprocity in SC thin films could be easily 

Page **1** of **27** 

accomplished with asymmetrical vortex edge/surface barriers and the universal Meissner screening current governing the critical currents. Our engineering of the SC diode effect in simple systems opens door for novel technologies. Meanwhile, we reveal the ubiquity of Meissner screening effect induced SC diode effect in superconducting films, which should be eliminated with great care in the search of exotic superconducting states harboring finite-momentum Cooper pairing. 

### **Introduction** 

Similar to a conventional semiconductor diode, a superconductor with non-reciprocal current flow, a SC diode, may form the building block for, e.g., dissipationless SC digital logic. The recent observation of such a SC diode effect in a complex thin film superconductor heterostructure subjected to an external magnetic field has stimulated vigorous activity towards understanding and replicating it [1]. Supercurrent rectification has also been demonstrated in multiple Josephson junction systems including AlInGaAs/InAs-Al [2], NbSe2/Nb3Br8/NbSe2 [3] and Nb-NiTe2-Nb [4], where largest nonreciprocities are observed at large in-plane magnetic fields [2,4]. Furthermore, an intrinsic SC diode effect has been observed in few-layer NbSe2 [5] and twisted trilayer graphene/WTe2 heterostructures [6] in an out-of-plane magnetic field. To quantify the diode effect, it is common to introduce an asymmetry parameter, called the diode 

𝐼𝑐<sup>+</sup> −𝐼𝑐<sup>−</sup> efficiency, 𝜂= where _I_ c<sup>+</sup> and _I_ c<sup>-</sup> are the critical currents in the two opposite directions. The value of 𝐼𝑐<sup>+</sup> +𝐼𝑐<sup>−</sup> 

 denotes the magnitude of the diode effect, while the sign defines the polarity. Up to now, reported values of 𝜂 range from a few percent to 30% [1-6]. 

Several theoretical mechanisms have been proposed to explain the SC diode effects in superconductors [7-11] and in Josephson junctions [12,13], with special emphasis on the potential role of the finitemomentum Cooper pairing [7-13]. While this mechanism focuses on the intrinsic depairing current [7-13], it is known that nearly all the superconductor films fail to be governed by the critical pair breaking mechanism, which merely offers the theoretical maximum for a specially designed sample [14-16]. A broad range of other mechanisms come to govern different samples [17,18]. Magnetic flux, or Abrikosov vortices, 

Page **2** of **27** 

are normally pinned to defect centers or surfaces of a superconductor [19]. The current flow, however, produces a Lorentz force on the vortices. A critical current is often measured when the pinning centers or the surface barrier cannot hold vortices anymore and dissipation starts in the superconductor [18,20-22]. This principle has been exploited to engineer superconducting vortices-based rectifiers [23-27]. Furthermore, Vodolazov and Peeters predicted existence and engineering of SC diode effect employing controlled edge disorder [23]. This escaped experimental realization thus far and the present work accomplishes it. 

Here, using V and Nb superconductors, three types of the SC diode effect are demonstrated, two of which are rooted in the universal Meissner screening instead of the rare finite-momentum Cooper pairing. We show a robust control of the nonreciprocity with record high efficiency in conventional superconductors without requiring additional spin-orbit coupling (SOC), exchange fields. 

### **Results** 

The V, Nb and EuS films in our experiments were deposited on clean, heated sapphire substrates in a single deposition process in a molecular-beam epitaxy chamber (base pressure < 4 × 10<sup>-10</sup> Torr) [28]. The thicknesses ( _dm, d)_ of EuS and V (or Nb) were respectively 5 and 8 nm _._ The film was patterned by e-beam lithography and Ar ion milling into a Hall bar geometry, with width _W_ ~8  m and length _L_ ~48  m [Fig. 1(a)]. Patterned V device had _T_ c 3.5 K ~ 4.3 K and a residual resistance ratio around 3 (Supplemental Material [29]). Four-probe geometry current vs voltage scans were measured to observe the critical current ( _Ic)_ nonreciprocity. The _I-V_ scans taken at 1.8 K for a V film subjected to out-of-plane magnetic field are shown in Fig. 1(b). Increasing and decreasing current sweeps showed distinctly different _Ic_ values: _Ic_ ± marking the SC to normal state transition, whereas a much smaller retrapping current _Ir_ ± was recorded while transitioning back from the normal to the SC state [Fig. 1(b)]. The low _Ir_ ± is often attributed to selfheating when the film is in the normal state [3,4]. In this study, we focus on _Ic_ ± where the nonreciprocity was controllable by applying an out-of-plane magnetic field. With 2.8 Oe field applied along the + _z_ 

Page **3** of **27** 

direction, _Ic_ for positive direction ( _Ic_<sup>+</sup> ) was significantly larger than when the current flow was in the negative direction ( _Ic_<sup>-</sup> ). By reversing the magnetic field _Ic_<sup>+</sup> and _Ic_<sup>-</sup> magnitudes interchanged. The magnetic field dependence of _Ic_<sup>+</sup> and _Ic_<sup>-</sup> is plotted in Fig. 1(c), _Ic_ showing large field dependence, an “inverted V” shape, with peaks occurring at ±2.5 Oe. A noticeable current rectification occurred even for fields <1 Oe, 

its polarity controllable by the field direction. The diode efficiency versus magnetic field, Fig. 1(c) exhibiting a maximum efficiency of ~19% at ±2.8 Oe. Such supercurrent rectification (type A) was observed in all the superconducting devices we measured. _I-V_ scans of another V device and a Nb device are presented in Supplemental Material [29], showing similar _Ic_ nonreciprocity for an out-of-plane magnetic field. 

For the current flow in a SC without breaking the mirror symmetry with respect to the _x_ - _z_ plane, the + _x_ and - _x_ directions are equivalent. Thus, we attribute the observed diode effect to a combination of Meissner current generated to screen the applied magnetic field and symmetry breaking of the device edges during fabrication. In practice, the two edges of a SC stripe could never be identical, thereby admitting slightly different critical current densities _j_ c and _j_ c +  _j_ c, which are smaller than the Ginzburg-Landau depairing limit _j_ GL, as indicated in Fig. 1(d). When current density in the device is above _j_ c, the Lorentz force on vortices nucleated at the edge overcomes the Bean-Livingston barrier thereby enabling vortex flow though the sample which destroys superconductivity [20,23,30-32]. The Meissner effect induces two dissipationless counter-flowing screening current densities ± _j_ ( _Bz_ ) at the two edges, when an out-of-plane field is applied. This screening current adds or subtracts to the applied current at opposite edges, and modifies the measured values of _j_ c<sup>+</sup> and _j_ c<sup>-</sup> . At small fields, the screening current density is simply the Meissner response _j_ ( _Bz_ ) = 𝑎𝐵𝑧,  linear with the applied magnetic field, where _a_ is a constant. For the case shown in Fig. 1(d), on the 𝐵𝑧 > 0 side, 



<!-- Start of picture text -->
𝛿𝑗𝑐<br>𝑗𝑐 + = 𝑗𝑐 + 𝑎𝐵𝑧 ,     𝑗𝑐 − = 𝑗𝑐 −𝑎𝐵𝑧 , 𝑤ℎ𝑒𝑛 𝑎𝐵𝑧 <       (1)<br>2<br>𝛿𝑗𝑐<br>𝑗𝑐 + = 𝑗𝑐 + 𝛿𝑗𝑐 −𝑎𝐵𝑧 ,    𝑗𝑐 − = 𝑗𝑐 −𝑎𝐵𝑧 , 𝑤ℎ𝑒𝑛 𝑎𝐵𝑧 ≥           (2)<br>2<br><!-- End of picture text -->

Page **4** of **27** 

Similar results are obtained for reversed field. Assuming a uniform current flow in the superconducting stipe, we have   𝐼𝑐± = 𝑆𝑗𝑐±, where _S_ is the device cross-section. 



<!-- Start of picture text -->
𝛿𝑗𝑐<br>𝐼𝑐 + = 𝑆(𝑗𝑐 + 𝑎𝐵𝑧) ,    𝐼𝑐 − = 𝑆(𝑗𝑐 −𝑎𝐵𝑧) ,   𝑤ℎ𝑒𝑛 𝑎𝐵𝑧 <   (3)<br>2<br><!-- End of picture text -->



<!-- Start of picture text -->
𝛿𝑗𝑐<br>𝐼𝑐 + = 𝑆(𝑗𝑐 + 𝛿𝑗𝑐 −𝑎𝐵𝑧),    𝐼𝑐 − = 𝑆(𝑗𝑐 −𝑎𝐵𝑧),    𝑤ℎ𝑒𝑛 𝑎𝐵𝑧 ≥       (4)<br>2<br><!-- End of picture text -->

The experimental data could be fitted with 𝑆𝑗𝑐 = 3.14 𝑚𝐴, 𝑆𝛿𝑗𝑐 = 1.35 𝑚𝐴 and 𝑆𝑎= 0.275 𝑚𝐴. 𝑂𝑒<sup>−1</sup> as shown by the dashed curves in Fig. 1(c). As the field increases,  a sublinear dependence of _I_ c on _B_ is observed, which is understood as follows [21]. Due to weak but finite bulk pinning, _Ic_ is determined by the bulk pinning (instead of the surfaces) when the surface barriers have been made smaller than the bulk pinning by the applied magnetic field. When this happens at a field estimated below, _Ic_ deviates from its linear dependence, the latter resulting from the edges/surfaces playing the main role. This is also the reason for the superconducting diode effect to be decreasing with increasing applied field [Fig. 1(c)]. The _Ic_ is then determined by the bulk pinning (and not the surfaces) and the inversion symmetry breaking due to surfaces starts to be irrelevant. 

It is convenient to define 𝐵𝑠 = 𝑗𝑐/𝑎 as the field scale where _Ic_ vanishes, assuming a linear extrapolation. Our fitting parameters yield 𝐵𝑠 = 11.4 Oe. Such a drastic suppression of _Ic_ by out-of-plane magnetic field in the thin film geometry could be understood by the ineffective Meissner screening [33]. The physical interpretation is that, in a thin film, the screening current is confined to the plane and is ineffective in screening the external magnetic field. As a result, the field penetrates on the scale of the Pearl length [34] 𝜆𝑃 = 2𝜆<sup>2</sup> /𝑑≫𝜆. Maksimova [33] considered the vortex mechanism of _Ic_ and for  < _W_ <  P found that _B_ s = 𝜙0/(√3𝜋 𝜉𝑊), where 𝜉 is the coherence length. For _W_ >  P , _W_ is replaced by 2  P in this formula (Supplemental Material [29]). For V we estimate that  = 130 nm and  P =4.25  m, which is somewhat smaller than _W_ = 8 μ m. Using 𝜉 =11 nm (Supplemental Material [29]), we obtain _B_ s ~ 40 Oe which is larger than the observed value, but is of comparable scale. This variation of _Ic_ at a field scale much smaller than the critical field and consistent with the vortex surface barrier annihilation field [20,21,33] confirms the direct role of vortices in determining _Ic_ and SC diode effect. 

Page **5** of **27** 

As the peak diode efficiency is determined by the edge asymmetry, we fabricated devices with and without a lithographically defined edge asymmetry (serrated edge with a lateral size of 3  m, much larger than the coherence length) [35]. Critical current vs magnetic field for both devices are shown in Supplemental Material [29]. The device without defined asymmetry shows a peak value for diode efficiency of 21%, while the one with a serrated edge attains a much larger diode efficiency, reaching ~50%.  Critical current peaks of the device with defined asymmetry occur at ±5.1 Oe, larger than 1.5 Oe for the device without it, which shows (and agrees with) a lower critical current for the serrated edges [35]. As temperature increases, both critical currents and diode efficiency drop as detailed in the Supplemental Material [29]. The main reason behind such a strong effect of the etching inhomogeneities is that the critical current in the devices is being determined by (i) vortex surface barrier, which is highly sensitive to the superconductor quality at the edges, and (ii) the current density at the edges. As per the contribution of (i) above, a deterioration in the superconducting properties close to an edge due to the etching-related disorder may lead to a significant lowering of the vortex surface barrier. As per the contribution (ii) listed above, the current density at the edge may be locally enhanced due to disorder for the a given total current through the superconductor [35]. These results further support the Meissner screening and asymmetric vortex surface barriers to be the underlying mechanism and a practical approach to enhance the diode efficiency [23]. 

Due to the highly sensitive dependence of _Ic_ on the out-of-plane field, a false “in-plane” magnetic field induced diode effect could easily be measured, with an offset between the magnetic field direction and the film plane by as small as 0.01˚ (Supplemental Material [29]). Hence, while investigating the SC diode effect under an in-plane magnetic field, any out-of-plane component of the field needs to be carefully removed to interpret the data. To study the effects of the real in-plane magnetic field on the critical currents, we developed a technique that enabled us to remove the out-of-plane field up to an accuracy of < 0.1 Oe (Supplemental Material [29]). A diode effect (type B) is then observed when the in-plane magnetic field is both parallel and perpendicular to the current flow (Supplemental Material [29]). The physical origin for this type of diode effect remains unclear and encourages further exploration – theoretical and experimental. 

Page **6** of **27** 

Experimentally, a drastic suppression of _Ic_ by an out-of-plane field has been reported in other superconductor films such as NbN [36], TaN [36], MgB2 [37], (Li,Fe)OHFeSe [38] and Nb/SrRuO3 bilayers [39]. However, no asymmetrical _Ic_ were reported except for an earlier work on grainy Sn films which was largely unnoticed by the community [40]. 

We investigated furthermore the _Ic_ rectification of the third kind (type C) in a hybrid structure where the SC film has a ferromagnetic layer EuS over it. 5nm thick EuS film shows a Curie temperature comparable to the bulk value and the hysteresis loop of EuS at 1.8K shows nice rectangular shape (Supplemental Material [29]). Fig. 2(a) shows the _I-V_ scans of a Pt/V/EuS trilayer when the EuS layer was magnetized along the _y_ direction (in-plane and perpendicular to the current flow). 0.2 nm of Pt is deposited to provide spin-orbit coupling and Rashba splitting at the V surface [41,42]. With a small external field to magnetize the EuS layer, a dramatic difference was observed between _Ic_ along the positive and negative directions of current flow. At _B_ y = -30 Oe, _Ic_<sup>+</sup> was more than 4 times larger than _Ic_<sup>-</sup> , producing a giant _Ic_ ratio of 480% and a diode efficiency of 65%, the highest value of diode rectification seen in superconductors yet. The _Ic_ asymmetry was reversed when the EuS magnetization direction was flipped. The temperature, magnetic field and angle dependencies of the SC diode effect were systematically studied on a second Pt/V/EuS device. A clear supercurrent rectification is also demonstrated in Supplemental Material [29]. As the temperature increased, _I_ c<sup>+</sup> and _I_ c<sup>-</sup> reduced whereas  remained nearly unchanged from 60 mK up to 1.3 K [Fig. 2(b)]. Further increase of the temperature led to a decrease of _Ic_<sup>+</sup> , _Ic_<sup>-</sup> and  , although clear diode phenomenon was seen even up to 3.6 K, close to _T_ c. At 1 K, the effect was found to quickly reach a maximum value as the field was increased to 18 Oe [Fig. 2(c)], and beyond that _I_ c<sup>+</sup> , _I_ c<sup>-</sup> , and  decreased slightly as the field increased. Hysteresis in _Ic_ and  diode efficiency was observed which resembled the magnetic hysteresis of the EuS film. This hysteresis in _I_ c enables control of the diode polarity via the remnant EuS magnetization direction, for field-free scenario. Diode efficiency at zero external field, though a little smaller than the maximum value when EuS is fully magnetized, was still 21% for the Pt/V/EuS 

Page **7** of **27** 

device. Fig. 2(d) shows  on a polar plot: the largest asymmetry was for the magnetic field perpendicular to the current flow direction, while it was negligible when the field was parallel to the current flow. 

It is tempting to interpret the giant supercurrent rectification in Pt/V/EuS as support for the finitemomentum pairing mechanism with Pt providing the required Rashba SOC [41,42] and exchange coupling with EuS giving a large spin-splitting in the V layer [43]. However, upon further investigations, we discovered that a similarly large nonreciprocity could be observed in a V/EuS bilayer device, without Pt providing the Rashba SOC [Fig. 3(a)]. Temperature [Fig. 3(b)], magnetic field and angle (Supplemental Material [29]) dependencies of the SC diode effect were systematically measured on a second V/EuS device, all showing close resemblance to that of Pt/V/EuS. Moreover, Figs. 3(c)-3(d) show similar EuSmagnetization-controlled diode effect in Nb/EuS bilayers, and persisting up to 6.5 K, as the _T_ c for Nb was higher than V [Fig. 4(a)]. 

To further examine the role of the exchange field, Nb/EuS and Nb/Al2O3/EuS films were grown in one deposition cycle, and a mask was used to cover one of them during the 3 nm-thick Al2O3 film spacer layer deposition. _I-V_ scans at 1.8 K showed that both samples had very similar _Ic_ when EuS was magnetized [Figs. 4(b)-4(c)], _Ic_ nonreciprocity in Nb/Al2O3/EuS trilayer, comparable to Nb/EuS bilayer. This shows that a direct contact between the SC and FM layer was not required for the type C diode effect. Based on these observations, we conclude that neither Rashba SOC nor interfacial exchange with the FM are essential in the observed Ic nonreciprocity. 

The diode effect in SC/FM bilayers has been reported in other systems [31,44-48]. The phenomenon could be understood by a screening current mechanism [31] shown schematically in Fig. 4(d). The in-plane magnetization along the y axis of the FM layer produces oppositely oriented fringing fields in the _y_ - _z_ plane at the two edges. A calculation shows that, for distances _r_ > _d_ m, the fringing field can be viewed as emerging radially from point sources with opposite signs at the opposite edges and decaying as 1/ _r_ [49]. This produces a _z_ component of the magnetic field, 



<!-- Start of picture text -->
B z = 2 md m z /( z 2  +  y 2 )             (5)<br><!-- End of picture text -->

Page **8** of **27** 

where _z_ and _y_ are measured from the sample edges and _m_ is the magnetization density. For EuS,  the Eu moment is  𝜇𝑠 = 7𝜇𝐵 and estimate 4  _m_ ~ 1.5 T [50,51]. Similar to the type A, this perpendicular magnetic field produces a Meissner screening current flowing in the + _x_ direction, with two important differences. Since the fringing field reverses direction on the two edges, the screening current on both edges flows in the same direction [Fig. 4(d)], and a diode effect occurs without requiring edge asymmetry as in type A and the sign is independent of the material combination. This current adds to the external current in the + _x_ direction, but partly cancels it in - _x_ direction, resulting in a smaller _I_ c<sup>+</sup> and larger _I_ c<sup>-</sup> . By reversing EuS magnetization, screening current around the edges flows along - _x_ direction, which reverses the current asymmetry. A second difference is that, unlike a uniform applied magnetic field, the fringing fields are strongly localized near the edges. Per our estimation (Supplemental Material [29]), the magnitude of the screening current is comparable to the departing current, leading to a gigantic diode effect. 

In summary, we demonstrated ubiquitous superconducting diode effect in thin film superconductors without the need for spin-orbit or direct exchange coupling, and thus without having to invoke an exotic superconducting state harboring finite-momentum pairing. Our work shows that vortex surface barriers, and not pair breaking, determine the critical currents in two-dimensional or thin film superconductors. Hence, studying a potential finite-momentum paired superconducting order in a film using critical current nonreciprocity can only be accomplished via a careful device design that eliminates the role of vortices in determining the critical current, and as a result achieves the pair breaking mechanism. Consequently, recent reports treating the SC diode effect as a proof of finite-momentum pairing need to be reconsidered. From prospective technology development, we demonstrated a giant diode efficiency of 21% (65%) using no (small 30 Oe) external magnetic field for a nonvolatile diode effect, setting the stage for envisioning computation architectures based on superconducting rectification and providing a fresh impetus to the ongoing development of superconductors-based quantum technologies. 

## **References** 

Page **9** of **27** 

[1] F. Ando, Y. Miyasaka, T. Li, J. Ishizuka, T. Arakawa, Y. Shiota, T. Moriyama, Y. Yanase, and T. Ono, Nature **584** , 373 (2020). 

- [2] C. Baumgartner _et al._ , Nat. Nanotechnol. **17** , 39 (2022). 

- [3] H. Wu _et al._ , Nature **604** , 653 (2022). 

- [4] B. Pal _et al._ , Nat. Phys. **18** , 1228 (2022). 

- [5] L. Bauriedl _et al._ , Nat. Commun. **13** , 4266 (2022). 

- [6] J.-X. Lin _et al._ , Nat. Phys. **18** , 1221 (2022). 

- [7] A. Daido, Y. Ikeda, and Y. Yanase, Phys. Rev. Lett. **128** , 037001 (2022). 

- [8] S. Ilić and F. S. Bergeret, Phys. Rev. Lett. **128** , 177001 (2022). 

- [9] N. F. Q. Yuan and L. Fu, Proc. Natl. Acad. Sci. **119** , e2119548119 (2022). 

- [10] J. J. He, Y. Tanaka, and N. Nagaosa, New J. Phys. **24** , 053014 (2022). 

- [11] H. D. Scammell, J. I. A. Li, and M. S. Scheurer, 2D Mater. **9** , 025027 (2022). 

- [12] M. Davydova, S. Prembabu, and L. Fu, Sci. Adv. **8** , eabo0309 (2022). [13] Yukio Tanaka, Bo Lu, and N. Nagaosa, Preprint at <u>https://doi.org/10.48550/arXiv.2205.13177  (2022).</u> 

- [14] K. Xu, P. Cao, and J. R. Heath, Nano Lett. **10** , 4206 (2010). 

- [15] C. P. Poole, Academic Press: San Diego. 

- [16] C. C. Tsuei, J. Mannhart, and D. Dimos, AIP Conf. Proc. **182** , 194 (1989). 

- [17] K. K. Likharev, Rev. Mod. Phys. **51** , 101 (1979). 

- [18] V. V. Shmidt, Sov. Phys. Uspekhi **13** , 408 (1970). 

- [19] C. P. Bean and J. D. Livingston, Phys. Rev. Lett. **12** , 14 (1964). 

- [20] V. V. Shmidt, JETP **30** , 1137 (1970). 

- [21] M. K. Hope, M. Amundsen, D. Suri, J. S. Moodera, and A. Kamra, Phys. Rev. B **104** , 184512 (2021). 

- [22] A. Buzdin and M. Daumens, Physica C: Superconductivity **294** , 257 (1998). 

- [23] D. Y. Vodolazov and F. M. Peeters, Phys. Rev. B **72** , 172508 (2005). 

- [24] C. S. Lee, B. Jankó, I. Derényi, and A. L. Barabási, Nature **400** , 337 (1999). 

- [25] J. E. Villegas, S. Savel'ev, F. Nori, E. M. Gonzalez, J. V. Anguita, R. García, and J. L. Vicent, Science **302** , 1188 (2003). 

- [26] J. E. Villegas, E. M. Gonzalez, M. P. Gonzalez, J. V. Anguita, and J. L. Vicent, Phys. Rev. B **71** , 024519 (2005). 

- [27] D. Cerbu, V. N. Gladilin, J. Cuppens, J. Fritzsche, J. Tempere, J. T. Devreese, V. V. Moshchalkov, A. V. Silhanek, and J. Van de Vondel, New J. Phys. **15** , 063022 (2013). 

- [28] P. Wei, F. Katmis, C.-Z. Chang, and J. S. Moodera, Nano Letters **16** , 2714 (2016). 

- [29] See Supplemental Material at .. for additional details on experiments and theory. 

- [30] M. Benkraouda and J. R. Clem, Phys. Rev. B **58** , 15103 (1998). 

- [31] D. Y. Vodolazov, B. A. Gribkov, S. A. Gusev, A. Y. Klimov, Y. N. Nozdrin, V. V. Rogov, and S. N. Vdovichev, Phys. Rev. B **72** , 064509 (2005). 

- [32] M. Kupriyanov and K. Likharev, Sov. Phys. Solid State **16** (1975). 

- [33] G. M. Maksimova, Phys. Solid State **40** , 1607 (1998). 

- [34] J. Pearl, Appl. Phys. Lett. **5** , 65 (1964). 

- [35] J. R. Clem and K. K. Berggren, Physical Review B **84** , 174510 (2011). 

- [36] K. Ilin, D. Henrich, Y. Luck, Y. Liang, M. Siegel, and D. Y. Vodolazov, Phys. Rev. B **89** , 184511 (2014). 

Page **10** of **27** 

- [37] C. B. Eom _et al._ , Nature **411** , 558 (2001). 

- [38] J. Hänisch, Y. Huang, D. Li, J. Yuan, K. Jin, X. Dong, E. Talantsev, B. Holzapfel, and Z. Zhao, Supercond. Sci. Technol. **33** , 114009 (2020). 

- [39] M. Feigenson, L. Klein, M. Karpovski, J. W. Reiner, and M. R. Beasley, J. Appl. Phys. **97** , 10J120 (2005). 

- [40] A. G. Sivakov, O. G. Turutanov, A. E. Kolinko, and A. S. Pokhila, Low Temp. Phys. **44** , 226 (2018). 

- [41] R. Meservey and P. M. Tedrow, Physics Reports **238** , 173 (1994). 

- [42] 

   - P. Fulde, Advances in Physics **22** , 667 (1973). 

- [43] P. Wei, F. Katmis, B. A. Assaf, H. Steinberg, P. Jarillo-Herrero, D. Heiman, and J. S. Moodera, Physical Review Letters **110** , 186807 (2013). 

- [44] M. V. Milošević, G. R. Berdiyorov, and F. M. Peeters, Phys. Rev. Lett. **95** , 147004 (2005). 

- [45] N. Touitou, P. Bernstein, J. F. Hamet, C. Simon, L. Méchin, J. P. Contour, and E. Jacquet, Appl. Phys. Lett. **85** , 1742 (2004). 

- [46] A. Papon, K. Senapati, and Z. H. Barber, Appl. Phys. Lett. **93** , 172507 (2008). 

- [47] G. Carapella, P. Sabatino, and G. Costabile, Phys. Rev. B **81** , 054503 (2010). 

- [48] G. Carapella, V. Granata, F. Russo, and G. Costabile, Appl. Phys. Lett. **94** , 242504 (2009). 

- [49] Y. Liu _et al._ , Nano Lett. **20** , 456 (2020). 

- [50] A. Svane _et al._ , Phys. Stat. Sol. (B) **241** , 3185 (2004). 

- [51] A. Mauger and C. Godart, Physics Reports **141** , 51 (1986). 

### **Acknowledgements** 

**Funding:** This work was supported by Air Force Office of Sponsored Research (FA9550-23-10004 DEF), Office of Naval Research (N00014-20-1-2306), National Science Foundation (NSFDMR 1700137 and 2218550); Army Research Office (W911NF-20-2-0061, DURIP W911NF-201-0074). F.N. MFR, DZH acknowledge support from the European Research Council (grant number 804273). H.C. is sponsored by the Army Research Laboratory under Cooperative Agreement Number W911NF-19-2-0015. S.I. and F.S.B. are supported by European Union’s Horizon 2020 Research and Innovation Framework Programme under Grant No. 800923 (SUPERTED), and the Spanish Ministerio de Ciencia e Innovacion (MICINN) through Project PID2020-114252GBI00 (SPIRIT). F.S.B. acknowledges financial support by the A. v. Humboldt Foundation. A.K. acknowledges the support by the Spanish Ministry for Science and Innovation – AEI Grant CEX2018-000805-M (through the “Maria de Maeztu” Programme for Units of Excellence in R&D). P.A.L. acknowledges the support by DOE office of Basic Sciences Grant No. DE-FG0203ER46076. 

**Author contributions:** Y.H., J.S.M., L.F., F.S.B., and P.A.L. conceived and designed the study. Y.H. grew the samples and fabricated the devices. Y.H. and F.N. performed the measurements. H.C., A.L., Y.W., M.F.R., and D.Z.H. assisted with the measurements. O.G.E. and A.V. fabricated devices with defined edges and performed measurements on the devices. Y.H., A.K., P.A.L., and J.S.M. performed theory modeling. M.D., S.I., F.S.B. and F.L. provided discussion and theoretical support. Y.H., A.K., P.A.L., and J.S.M. wrote the paper with contributions from all authors. 

**Competing interests** : The authors declare no competing interests. 

Page **11** of **27** 

**Data and materials availability:** The data that support the findings of this study are available from the corresponding authors upon request. 

Page **12** of **27** 



FIG. 1: Demonstration of out-of-plane field induced diode effect in a SC film at 1.8 K. (a) Top: schematic drawing of the vanadium thin film strip. Bottom: optical microscope image of the Hall bar strip of V film. Scale bar denotes 8  m. (b) _I-V_ scans of the device at 2.8 Oe out-of-plane field along ± _z_ direction as indicated by the red and blue lines. Black arrows indicate the scan direction. (c) Critical currents and diode efficiency as a function of the magnetic field.  Black dashed lines show the calculated critical current values based on our model.  (d) Schematic depiction of Meissner screening currents and the asymmetry between the critical current densities at the two edges. 

Page **13** of **27** 



FIG. 2: SC diode effect in Pt/V/EuS trilayers. (a) _I-V_ scans of a Pt/V/EuS device showing giant critical current rectification effect at 1.8 K. Inset shows a schematic of the Pt/V/EuS stack. (b) Temperature dependence of the critical current at _By_ = 200 Oe. (c) Magnetic field dependence of the critical current at 1 K. Solid (dashed) lines were obtained when scanning the magnetic field up (down). (d) Angle (  ) dependence of  at _T_ = 1 K and _B_ = 200 Oe. Data in a and b to d are from two different Pt/V/EuS devices. 

Page **14** of **27** 



FIG. 3: SC diode effect in SC/FM bilayers. (a) _I-V_ scans of a V/EuS device showing a similarly large SC diode effect as in Pt/V/EuS. Inset shows a schematic of the V/EuS stack. (b) Temperature dependence of the critical currents for a second V/EuS at _By_ = 30 Oe. (c) _I-V_ scans of a Nb/EuS device exhibiting nonreciprocity. Inset shows a schematic of the Nb/EuS stack. (d) Temperature dependence of the critical currents at _By_ = 30 Oe for the same Nb/EuS device. 

Page **15** of **27** 



FIG. 4: Screening current mechanism for the SC diode effect in SC/FM bilayers. (a) _R-T_ curves for the SC/FM films with and without a 3 nm Al2O3 spacer layer. (b) _I-V_ scans of the Nb/EuS device measured at 1.8 K showing type C SC diode effects. Inset shows a schematic of the Nb/EuS stack. (c) _I-V_ scans of the Nb/Al2O3/EuS device at 1.8 K showing similar diode effects as in b. Inset shows a schematic of the Nb/Al2O3/EuS stack. (d) Schematic depiction of the screening currents induced by the out-of-plane edge magnetic fields due to the EuS layer. _Is_ denotes the induced screening current. 

Page **16** of **27** 

Supplemental material for “Ubiquitous Superconducting Diode Effect in Superconductor Thin Films” 

Yasen Hou<sup>1*</sup> , Fabrizio Nichele<sup>2</sup> , Hang Chi<sup>1,3</sup> , Alessandro Lodesani<sup>1</sup> , Yingying Wu<sup>1</sup> , Markus F. Ritter<sup>2</sup> , Daniel Z. Haxell<sup>2</sup> , Margarita Davydova<sup>4</sup> , Stefan Ilić<sup>5</sup> , Ourania Glezakou-Elbert<sup>6</sup> , Amith Varambally<sup>7</sup> , F. Sebastian Bergeret<sup>5,8</sup> , Akashdeep Kamra<sup>9*</sup> , Liang Fu<sup>4</sup> , Patrick A. Lee<sup>4*</sup> , Jagadeesh S. Moodera<sup>1,4*</sup> 

* Corresponding authors. Email: yshou@mit.edu (Yasen Hou); akashdeep.kamra@uam.es (Akashdeep Kamra); palee@mit.edu (Patrick A. Lee); moodera@mit.edu (Jagadeesh S. Moodera) 

### **Materials and Methods** 

The growth of V, Nb, EuS, Pt and Al2O3 thin films were carried out in a custom-built molecular beam epitaxy system with a base vacuum of < 4×10<sup>-10</sup> Torr. Polished sapphire Al2O3(0001) were used as substrates, whose surface high quality was assured by _ex situ_ chemical cleaning and thermal annealing and _in situ_ outgassing at 800 °C for 30 min. Subsequently the substrate was cooled down to the growth temperature for growing epitaxial metallic layers. Typical growth temperature was 230°C for V, EuS, Pt and Al2O3, and was 500°C for Nb. High-purity V, Nb, Pt and EuS sources were evaporated from an electron-beam source (e-gun) with a growth rate of approximately 0.5 Å/s. The films were patterned to a Hall-bar geometry following standard electron beam lithography and Ar ion milling. 

Transport and magnetic measurements were performed in a Quantum Design Physical Property Measurement System (PPMS), equipped with a 9 T superconducting magnet. Current–voltage curves were measured through a current preamplifier (DL Instruments, model 1211), a voltage amplifier (Stanford Research Systems, model SR560) and a National Instruments data acquisition system. Ultra-low temperature measurements were realized in a dilution refrigerator equipped with a three-axis vector magnet and with a mixing chamber base temperature below 10 mK. The sample was connected via phosphor-bronze lines, which included a series of pi-filters and RC filters from QDevil, installed both at the mixing chamber level and at the sample holder. Overall, the resistance of each measurement line was about 2.6 kΩ. To minimize Joule heating, the source contact of the device (leftmost contact in Fig. 1a) was connected to 11 parallel lines, while the drain (rightmost contact in Fig. 1a) was bonded to a cold ground with negligible series resistance. In addition to this, two lateral arms of the device (two leftmost lateral contacts in Fig. 1a) were also connected in parallel to the source contact. In this way, the source-drain resistance of the entire measurement setup was 991 Ω when the device was in the superconducting state and transitioned to 1156 Ω in the resistive state. 

Page **17** of **27** 



FIG. S1: _R-T_ curve for a typical V device showing _T_ c ~ 4.1K and a residual resistance ratio ~3. 



FIG. S2: Type A SC diode effect in another V film and in a Nb film at 1.8 K. (a) _I-V_ scans of a second V device at 2.5 Oe out-of-plane field along ± _z_ direction as indicated by the red and blue lines. Black arrows indicate the scan direction. (b) Critical currents and diode efficiency as a function of the magnetic field. (c and d) Similar effects in a Nb device. 

Page **18** of **27** 



FIG. S3: Out-of-plane critical field ( _H_ c2) vs temperature for a typical V device. The coherence length is 2 . estimated to be ~11 nm by the Ginzburg–Landau equation [52] 𝜀𝐺𝐿(0𝐾) = √𝜙0/2𝜋𝐻𝑐2(0𝐾) 

Page **19** of **27** 

**Note 1: False “in-plane” magnetic field induced diode effect.** 



FIG. S4: _I-V_ scans of the device showing a false “in-plane” diode effect, which is actually caused by the out-of-plane component of the magnetic field. Note the diode polarity is reversed when the magnetic field deviates from nominally in-plane direction by as little as 0.01˚. 

In our study, the device was mounted on a rotating sample holder in a DynaCool Physical Property Measurement System (PPMS) set up, with a minimum step rotation of 0.01˚. The thin film was mounted so that the in-plane magnetic field was along the _y_ axis (  = 0˚).  The red curve in Fig. S4 shows the _I-V_ scans of the device with a 2 T “in-plane” applied magnetic field showing different _Ic_<sup>+</sup> and _Ic_<sup>-</sup> values suggesting a SC diode effect. However, when the device was rotated to  = -0.01˚, the asymmetry of _Ic_<sup>+</sup> and _Ic_<sup>-</sup> was reversed. With such a small rotation, the change of the in-plane component of the magnetic field was ~ 3×10<sup>-4</sup> Oe, which is too small to have any effect on the device behavior. Thus, we attribute the apparent inplane diode effect in Fig. S4 to the residual out-of-plane component of the magnetic field. Limited by the resolution of the rotator, the magnetic field was only nominally along the _y_ axis and the offset angle could easily be somewhere between -0.01˚ to 0.01˚. The corresponding out-of-plane component of the magnetic field _B_ z was up to 3.5 Oe when a 2 T field was applied to observe an apparent in-plane SC diode effect. Then the nonreciprocity polarity reversal seen is due to a sign change in the _B_ z component. In our study, the angle between the magnetic field and the film plane was carefully calibrated so that residual offset angle was only limited by the equipment resolution. Without careful calibration, we found that the offset angle 

Page **20** of **27** 

could easily be anywhere from -1˚ to 1˚, when manually placing the device along a certain plane. In this case, the false in-plane field-induced diode effect occurs even when the applied field is as small as 100 Oe. 



FIG. S5: Type A SC diode effect in V devices without and with defined edge asymmetry at 1.8 K. (a) _I-V_ scans of a V device without defined edge asymmetry at 1.5 _Oe_ out-of-plane field along ± _z_ direction as indicated by the red and blue lines. Black arrows show the scan direction. (b) Critical currents and diode efficiency as a function of the magnetic field. (c-d) Similar effects in the V device with one serrated edge and one ‘straight’ edge. Insets show the device image (dark areas on the devices are PMMA residuals). 

Page **21** of **27** 



FIG. S6: Critical currents and diode efficiency of the device with defined edge asymmetry shown in Fig. S5(c) at different temperatures. 

### **Note 2: Suppression of critical current by out-of-plane magnetic field.** 

In this section we give a physical explanation of why a very small perpendicular field can suppress the critical current by giving a simple derivation of the field _Bs_ defined in the text. 

The key observation is that in a thin film, the supercurrent is confined to a plane and is ineffective in screening an external field applied perpendicular to the plane. This problem was treated by Pearl (ref. 34) 2𝜆<sup>2</sup> who showed that the field penetrate on the scale of the Pearl length 𝜆𝑃 = which greatly exceeds the 𝑑 usual London penetration depth  .  First, we consider the case when the sample width 𝑊≪𝜆𝑃. This was the case treated by Maksimova (ref. 33). In this case the applied field penetrates completely. In the London 𝐵𝑊 gauge the vector potential 𝐴𝑥 = 𝐵𝑦 and equals 2 at the sample edge. We use the London equation 𝑗𝑠 = 𝑐 𝐴𝑥 𝑐 𝐵𝑊 = ~~.~~ Setting 𝑗𝑠 to equal the Ginzburg-Landau critical current 𝑗𝐺𝐿 given by equation (8) in the text, 4𝜋 𝜆<sup>2</sup> 8𝜋 𝜆<sup>2</sup> 2 2 we find the critical field to be 3 𝜙0/(√3𝜋 𝜉𝑊), which apart from the factor 3, is the same as 𝐵𝑠 = 𝜙0/(√3𝜋 𝜉𝑊) quoted in the main text and in ref. 33. In the opposite case 𝑊≫𝜆𝑃, the field is confined to a distance equal to the Pearl length near the edge. Using equation (6) the vector potential 𝐴𝑥 in the London gauge is found to be 𝐵𝜆𝑃 at the sample edge 𝐵𝑊 𝑊 instead of for the previous case. We can repeat the argument above but replace by 𝜆𝑃. Therefore, in 2 2 𝑊 the expression for 𝐵𝑠 we simply replace by 𝜆𝑃 in this limit. 2 

### **Note 3: Precise removal of the out-of-plane magnetic field** 

Page **22** of **27** 

To completely remove the out-of-plane component of the magnetic field, we measured the device in a dilution fridge fitted with a vector magnetic field configuration, where magnetic fields along two orthogonal directions _B_ 1 and _B_ 2 could be tuned individually. The device was mounted in a scheme shown in Fig. S7, where _B_ 1 was along the device _y_ axis ( _B_ 1 = _B_ 1y), with some inevitable residual angle  that created a small perpendicular component _B_ 1z. This residual out-of-plane component was subsequently removed by adjusting _B_ 2 along the _z_ axis. Note that the offset angle  in Fig. S7 is exaggerated for better illustration and the real angle is less than 1˚. 



FIG. S7: Schematic depict of the device in a vector magnetic field. _B1_ and _B2_ are two individually adjustable magnetic fields orthogonal to each other. The device is placed so that _B_ 1 is nominally in the film plane and perpendicular to the current flow direction.  denotes the residual angle deviating from the film plane. This creates the residual out-of-plane component _B_ 1z = _B_ 1sin ., which is then eliminated by adjusting the second magnetic field _B_ 2 along the _z_ axis. 

At each applied in-plane field, _B_ 2 = _B_ 2z was scanned and critical currents of the device were measured. Fig. S8(a) shows _Ic_ ± as a function of _B_ 2 at different _B_ 1 values. We found that while _I_ c± vs _B_ 2 always follows the inversed “V” shape, the peak position “ _B_ 2p” was shifted away from 0 when an in-plane field _B_ 1 was applied. Further analysis shows that _B_ 2p follows _B_ 1 linearly [Fig. S8(b)]. This is reasonable because when an “in-plane” field _B_ 1 is applied, the out-of-plane component _B_ 1z suppresses the critical currents of the device. As _B_ 2 is scanned along the _z_ axis, the largest critical currents are located at where _B_ 2 balances out _B_ 1z ( _B_ 2 = _-B_ 1z = - _B_ 1 _sin_  ). 

The residual angle  for this device was then determined to be 0.291˚ by a linear fitting. With this information, we defined a corrected out-of-plane field _B_ zc = _B_ 2 + _B_ 1× _sin_ 0.291˚, which represents the actual out-of-plane magnetic field. Figs. S8(c)-8(e) present the critical current as a function of _B_ zc with the inplane fields _B_ 1 being 0 T, 2 T and 4 T, respectively. At _B_ 1 = 0 T, a typical type A SC diode effect was observed, with the diode efficiency being 0 at _B_ zc = 0 Oe [Fig. S8(C)]. However, when the applied in-plane field was 2 T and 4 T, a clear difference between _I_ c<sup>+</sup> and _I_ c<sup>-</sup> was observed even at _B_ zc = 0 Oe. Because the 

Page **23** of **27** 

out-of-plane field is precisely 0, we attribute the observed supercurrent rectification at _B_ zc = 0 Oe to the effect of the actual in-plane magnetic field. 



FIG. S8: Elimination of the out-of-plane magnetic field. (a) Critical currents vs _B_ 2 at different values of _B_ 1 for the scheme shown in Fig. S7. (b) Peak position of the critical current _B_ 2p as a function of the applied inplane field _B_ 1. (c-e) Critical currents vs corrected _B_ zc = _B_ 2 + _B_ 1× _sin_  showing actual in-plane field induced diode effect (type B). All data were measured at _T_ = 500 mK. 



Page **24** of **27** 

FIG. S9: In-plane field induced SC diode effect in SC V film. (a) _Ic_ ± and |  | as a function of the in-plane field perpendicular to current flow _._ (b) _Ic_ ± and |  | as a function of the in-plane field parallel to current flow. Both sets of data were taken at 500 mK. 



Fig. S10: Magnetic properties of a typical V(8nm)/EuS(5nm) film. (a) Measured _M_ as a function of temperature with 50 Oe in-plane applied field showing a Curie temperature of 17K. (b) Hysteresis loop at 1.8K showing a nicely rectangle loop. Linear background from the sapphire substrate and superconducting peaks are removed. 



FIG. S11: Demonstration of a clear supercurrent rectification at _By_ = 200 Oe and _T_ = 1 K. The device current (blue) and the voltage drop (red) as a function of time is shown. The device behaved as a superconductor supporting dissipationless current along the - _x_ direction, while dissipative current flows through a normal metal in the other direction. 

Page **25** of **27** 



FIG. S12: Magnetic field and angle dependence of the diode effect for the second V/EuS device. (a) Magnetic field dependence of the critical currents at 1K. Solid (dashed) lines were obtained when scanning the magnetic field up (down). (b) Angle (  ) dependence of _Ic_ ± at _T_ = 1 K and _By_ = 50 Oe. (c) The corresponding diode efficiency as a function of angle  . 

### **Note 4: Estimation of the screening current in FM/SC bilayers.** 

The magnitude of the screening current is estimated using the London equation. The _x_ component of the 

𝜕𝐴𝑥 vector potential is obtained by integrating **_B_** =∇× 𝑨, i.e., 𝐵𝑧 = ~~.~~ In the London gauge we find: 𝜕𝑦 



<!-- Start of picture text -->
𝑦<br>𝐴𝑥(𝑦) = ∫𝐵0 𝑧(𝑧, 𝑦 ′ ) 𝑑𝑦 ′ (S1)<br><!-- End of picture text -->

where we have shifted the _y_ coordinate so that the sample lies between _y_ = - _W_ /2 and _W_ /2. Using Eq. (5) in the manuscript in the shifted coordinate, we find that right at the sample edge, the _Ax_ field is independent of _z_ and is given by 𝐴𝑥 = 𝜋𝑚𝑑𝑚. From the edge it extends into the sample by a distance ~ _d_ in the _y_ 

𝑐 𝐴𝑥 direction. Using the London equation 𝑗𝑥 = ~~,~~ we find that, at the sample edge, the current is given by: 4𝜋 𝜆<sup>2</sup> 



<!-- Start of picture text -->
𝑐 𝜋𝑚𝑑𝑚<br>𝑗0 =    (S2)<br>4𝜋 𝜆 2<br><!-- End of picture text -->

On the other hand, the critical current density of the SC film is estimated by the GL theory as: 



<!-- Start of picture text -->
𝑐 𝜙0<br>𝑗𝐺𝐿 =    (S3)<br>4𝜋 3√3𝜋𝜉𝜆 2<br><!-- End of picture text -->

The ratio between the screening current density and the critical current density is then: 

Page **26** of **27** 



<!-- Start of picture text -->
𝑗0 3√3𝜋 2 𝑚𝑑𝑚𝜉(𝑇)<br>=   (S4)<br>𝑗𝐺𝐿 𝜙0<br><!-- End of picture text -->

By using 4π𝑚= 1.5𝑇, 𝑑𝑚 = 5𝑛𝑚, 𝜉= 11𝑛𝑚, 𝜙0 = 2 × 10<sup>3</sup> 𝑇(𝑛𝑚)<sup>2</sup> , we estimate: 



<!-- Start of picture text -->
𝑗0<br>= 0.156  (S5)<br>𝑗𝐺𝐿<br><!-- End of picture text -->

This rough estimate shows that the screening current due to the fringing field is comparable to the critical current and can lead to the diode effect.  The ratio is proportional to the thickness of the FM film and can be increased using thicker films, keeping in mind that the estimate is valid only for _d_ m < _d_ .  In understanding our observed effect, we experimentally find that vortex surface barriers and Meissner response of the applied magnetic field will determine the critical current in wide films. This barrier, and consequently the critical current, scales inversely with the device width. Hence, for narrow devices with widths comparable to or smaller than the coherence length, the surface barrier becomes large and the role of Meissner currents should become negligible. Under those conditions, the depairing mechanism may determine the critical current and finite-momentum Cooper pairing can be probed. The thickness of the devices should be kept small, ideally comparable to or smaller than the coherence length. 

[52] N. R. Werthamer, E. Helfand, and P. C. Hohenberg, Physical Review **147** , 295 (1966). 

Page **27** of **27** 

