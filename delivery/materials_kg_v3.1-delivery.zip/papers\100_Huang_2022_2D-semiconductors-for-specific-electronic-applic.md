# 2D semiconductors for specific electronic applications: from device to system

| 字段 | 内容 |
|---|---|
| 期刊 | npj 2D Materials and Applications |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 222 |
| 作者 | Xiao-He Huang, Chunsen Liu, Peng Zhou |
| DOI | 10.1038/s41699-022-00327-3 |
| 源文件 | 100_Huang_2022_2D-semiconductors-for-specific-electronic-applic.pdf |

---
www.nature.com/npj2dmaterials 

# PERSPECTIVE **OPEN** 2D semiconductors for specific electronic applications: from device to system 

Xiaohe Huang<sup>1,2,3</sup> , Chunsen Liu<sup>2✉</sup> and Peng Zhou 1,2,3 ✉ 

The shrinking of transistors has hit a wall of material degradation and the specialized electronic applications for complex scenarios have raised challenges in heterostructures integration. Intriguingly, two-dimensional (2D) materials have excellent performance even at monolayer. The rich band structures and the lattice-mismatch-free heterostructures can further develop specific mechanisms to meet the demands of various electronic systems. Here we review the progress of 2D semiconductors to develop specific electronic applications from devices to systems. Focusing on the ultra-thin high-performance nanosheets for transistor channels, we consider channel optimization, contact characteristics, dielectric integration. Then we examined 2D semiconductors for specific electronic functions including computing, memory and sense. Finally, we discuss the specific applications of functionalized arrays aiming at problems that are difficult to solve with bulk materials, like the fusion of memory and com <mark>p</mark> utation and the all-in-one s <mark>y</mark> stem. n <mark>pj</mark> 2D Materials and A <mark>pp</mark> lications (2022) 6:51 ; htt <mark>p</mark> s://doi.or <mark>g</mark> /10.1038/s41699-022-00327-3 

## INTRODUCTION 

The data-intensive applications like artificial intelligence that shapes our lives are highly dependent on computing capabilities<sup>1</sup> , pushing the need for hybrid data processing and application-specific functions at the system level<sup>2,3</sup> . Nevertheless, there are facing two major challenges from device to system. From the bottom up, channel materials of transistors will be harder to make practical improvements in the future if it continues to shrink in the way as previously adopted<sup>4</sup> since the short-channel effects cannot be better addressed<sup>5</sup> . From the top, systems in complex scenarios such as IoT, edge computing require diverse interactions in specific environments<sup>6</sup> , placing increasing demands on the integrated systems for specialized processing applications<sup>7</sup> . But functionally integrated systems place stringent requirements on the heterogeneous integration of the underlying materials<sup>8</sup> . 

2D semiconductors, as a family of emerging semiconductor materials<sup>9</sup> , exhibit unprecedented new properties<sup>10</sup> that promise to overcome the barriers of miniaturization and specific applications<sup>11</sup> . First, 2D semiconductors with intact structures at nanoscale are beneficial to create high-performance low-power electronic devices<sup>12</sup> . 2D semiconductors have remained ignorant until the first monolayer MoS2 transistors were prepared<sup>13</sup> , revealing ultra-high on/off ratios, superior mobility, and ultralow off-state currents. Secondly, the abundant band engineering and the atomically smooth and flexible interface provide an additional degree of freedom for the fusion of different electrical functions, easy to create more efficient and specific applications by heterogeneous integration<sup>14</sup> . On this basis, 2D semiconductors can implement device structures and functions previously unattainable with other materials and many innovative electronic devices have been invented, such as ultrafast non-volatile flash<sup>15,16</sup> , reconfigurable logic<sup>17,18</sup> , and logic-in-memory<sup>19</sup> . Overall, the extensive physical characteristics of 2D semiconductors can be mined for specific electrical functions and hold great promise for all-in-one systems (Fig. 1). 2D materials cover a large 

multidisciplinary range which have been extensively reviewed<sup>10,11,20–23</sup> . Here we focus on 2D semiconductors as the role of the channel in transistor architectures for constructing specific electronic applications. 

In this article, the progress, opportunities, and challenges of 2D semiconductors to develop specific electronic applications from devices to systems are reviewed. we first consider the progress of 2D semiconductors as ultra-thin nanosheet channels for a higherperformance transistor, covering channel optimization, contact characterization, and dielectric integration. Next, we introduced the electronic functions enabled by the novel physical properties of 2D semiconductors, mainly including three parts: computing, memory, and sense. The progress and challenges from functional devices to specific fusion applications in systems are also discussed, focusing on 2D semiconductors in specific electronic systems to overcome problems that are difficult to solve with conventional materials. 

## Ultrathin nanosheets for high-performance transistors 

Transistors drove the explosive development of electronic applications in the form of integrated circuits. In today’s big data era, the increase in computing power is forcing the performance of the underlying transistors to continue to improve. At advanced transistor nodes, the channel thickness also needs to be thin enough to maintain effective gate control at shorter channels. However, for bulk materials, as the thickness goes into the nanometre size, as shown in Fig. 2a, the interfacial state due to the suspended bonds brings about a dramatic decrease in mobility<sup>24</sup> . 2D semiconductors hold great promise for transistors as an alternative technology because they do not suffer from the channel shrinking challenges that limit Si transistors<sup>25</sup> . As shown in Fig. 2b, 2D materials without dangling bonds can achieve atomically smooth interfaces that not only maintain excellent electrical properties but also allow for readily heterogeneous integration. To build specific electronic systems, 

> 1ASIC & System State Key Lab., School of Microelectronics, Fudan University, Shanghai, China. 2Frontier Institute of Chip and System & Qizhi Institute, Shanghai Key Lab for Future Computing Hardware and System, Fudan University, Shanghai, China.<sup>3</sup> Hubei Yangtze Memory Laboratories, Wuhan 430205, China.<sup>✉</sup> email: chunsen_liu@fudan.edu.cn; pengzhou@fudan.edu.cn 



Published in partnership with FCT NOVA with the support of E-MRS 

X. Huang et al. 

2 





Fig. 1 A schematic diagram of the potential road of specific electrical applications for 2D semiconductors. The bottom panel shows a route for 2D semiconductors to serve as ultrathin high-performance nanosheets in the future transistor architecture. The top panel shows the novel properties of 2D materials and opportunities for specific applications from functions to integrated systems. 



Fig. 2 Structural characteristics and publication trends for 2D semiconductors. a Schematic illustrations of the lattice-mismatched siliconoxide interfaces. b Schematic illustrations of the lattice-mismatch-free vdW interfaces between 2D materials. c Number of 2D semiconductors publications from 2011 to 2020. (Keywords used for searching “transistor” and the corresponding abbreviation for 2D semiconductors like “MoS2”. Source: Web of Science, accessed in December 2021). 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2022) 51 

X. Huang et al. 

3 



the underlying transistor performance based on 2D semiconductors is fundamental. 

2D semiconductors serving as high-performance channels. The birth of the first monolayer MoS2 transistor with an ultra-high onoff ratio inspired a wave of transistor research in 2D semiconductors<sup>13</sup> . Along with this, a series of 2D semiconductors emerged, mainly including TMDs (transition metal dichalcogenides)<sup>22</sup> , Phosphorene<sup>26,27</sup> and Group III chalcogenides and so on<sup>10</sup> . Among the hundreds of possible 2D semiconductor materials<sup>28</sup> , there are ten most used for transistor research, with carrier types classified as n-type, p-type, and ambipolar, as shown in Fig. 2c. Because of the stable performance of the properties and functions, MoS2-related transistor researches occupy more than half of the total. Black phosphorus, one of the few P-type 2D materials, has also attracted much attention for its excellent hole mobility properties<sup>26</sup> . Ambipolar materials with unique carrier dynamic properties<sup>29</sup> , such as WSe2 and WS2<sup>30</sup> , have also been reported in an increasing number of studies. In transistor applications, as with standard silicon processes, a specification of device metrics is required for the assessments of these 2D semiconductor channels. 

Although 2D semiconductors can easily attain one atomic layer of thinner than 1 nm, it is the performance at the ultra-scaled channel length that determines their application opportunities in high-performance transistors. To verify the immunity to shortchannel effects, MoS2 FETs with channel lengths ranging from microns to tens of nanometers were prepared to study the trend in electrical behaviour<sup>31,32</sup> , indicating that MoS2 has immunity to the short channel. The MoS2 transistor with carbon nanotubes as the gate electrode has a gate of only 1 nm<sup>33</sup> , as seen in Fig. 3a, which still exhibits excellent switching performance with an on/ off ratio greater than 10<sup>6</sup> . In a standard planar gate device structure, Xie et al. achieved physical channel lengths as low as 8 and 3.8 nm using graphene as the electrode<sup>34</sup> . It should be noted that the technology nodes’ names in the industry now do not match their actual transistor size, for example in the silicon-based 10 nm technology node half-gate pitch is 27 nm<sup>35</sup> . 2D semiconductors have great potential for applications in ultrashort channel devices that break through the actual physical size of 5 nm, illustrating that 2D semiconductors can break the limits of short channels of bulk materials while maintaining excellent electrical properties. More than just improved gate control, 2D semiconductors can achieve drive currents that are also comparable to silicon. As shown in Fig. 3b, the current can reach 1135 μA μm<sup>−1</sup> at Lg = 35 nm<sup>36</sup> . Other aspects such as contact and dielectric environments related to on-state currents will be discussed later. 

Transistor architectures play a role in the performance since structural variations can modify the electric field applied to the channel. Thanks to their layered nature, 2D semiconductors are also adapted to various transistor architectures<sup>37–39</sup> , from planar to three-dimensional (3D), as shown in Fig. 3c–e. The 3D structure allows for better gate control and higher current for a given footprint of the transistor<sup>38</sup> . Gate-all-around devices are considered to be promising devices because of their excellent electrostatic control properties and area efficiency<sup>40</sup> , as shown in Fig. 3e, g. As a natural nanosheet, 2D semiconductors can exploit the property of atomically smooth on both surfaces, which makes them a more suitable candidate channel for Gate-All-Around (GAA) as well as vertical-stacking architectures<sup>39</sup> . The combination of multi-channel and ultrathin 2D materials paves the way toward high-performance and lowpower electronic devices<sup>41</sup> . 

Current performance is the core metric for 2D semiconductors as a channel, where the effective mass and the bandgap are the fundamental factors, which are determined by the material itself. The effective mass is an intrinsic parameter to evaluate the 

highest current achievable by the channel, which is directly related to the band structure, as an expression of the second derivative of the band dispersion<sup>42</sup> . The maximum ballistic current that can flow through the channel is proportional to the carrier ballistic velocity. A low effective mass means that a high carrier velocity can be achieved more easily, so a material with a lower effective mass can provide a higher current limit<sup>43</sup> . On the other hand, the effective mass cannot be too low, because it is easy to induce the carrier tunnelling current between the source and drain while also unable to provide sufficient carrier density of states, which will weaken the performance of the transistor current<sup>44</sup> . Different 2D semiconductors are available to choose the appropriate effective mass to meet the current performance requirements<sup>12,42</sup> . MoS2 with a large effective mass of electrons, about 0.5 m0, can effectively suppress direct tunnelling between source and drain electrodes in ultra-short channel devices, thus effectively suppressing leakage currents. WS2 has a relatively small effective mass for electrons and holes, and its intrinsic electrical properties are comparable for n- and p-FETs in a single layer<sup>45</sup> , making it a promising candidate for transistor channel. The bandgap directly affects the ratio of the on-state current to the off-state leakage current. Usually, the band structures evolve with the decreasing thickness as the bandgaps become larger. The layer-dependent band transition mainly stems from interlayer coupling and confinement effects<sup>22</sup> . 2H TMDs are the main part of 2D semiconductors, which are direct bandgaps at the monolayer. But with the increase of layers, the bandgap of TMDs gradually decreases and changes from direct bandgap to indirect bandgap varying from 1.1 to 2.1 eV. The uniform atomic thickness and the appreciable direct bandgap are the reason why ultrathin 2D semiconductors can be effectively regulated by the gate voltage and achieve excellent switching performance with an outstanding ratio. BP will maintain a direct bandgap varying from 0.3 to 2 eV. Therefore, BP with a suitable bandgap can provide options as compensation for the relatively large bandgap of TMDs<sup>46</sup> . A broad range of 2D semiconductors with specific characteristics are offered for options according to the appropriate needs of current performance. 

Carrier mobility, another essential parameter, represents how easily carriers move in materials under the action of the electric field. It reflects the sensitivity of the source-drain current to gate voltage. Mobility is firstly affected by the intrinsic electrical properties of the material. Generally, the theoretical phononlimit mobility is the highest mobility that can be reached by the material. Although this predicts the potential of 2D semiconductors itself<sup>47</sup> , the actual situation of the device is more complex and cannot be generalized<sup>48</sup> . Various scattering factors, such as lattice defects, ionized impurities, grain boundaries, and other structural defects, are the major constraints that are often difficult to separate their respective contributions<sup>49</sup> . The influence of extrinsic effects caused by impurities and dielectric environments hinders the study of the inherent physics of 2D semiconductors and limits the design of devices. The theoretically predicted high mobility could not be obtained in the experiments. vdW heterojunction encapsulated by hBN and contacted by graphene can be measured for intrinsic mobility without the influence of external scattering, whereas this is not practical for actual transistor applications<sup>50</sup> . Mobility as an indirectly derived parameter is susceptible to some underlying deviations due to the test method and may not reflect the real state of the device<sup>12</sup> . In transistors with ultra-short channels, the carrier transport will be close to the ballistic transport and the effective drive current is more determined by the contact and dielectric environment. 

Contact improvement of 2D semiconductors. High-quality sourcedrain contact with the semiconductor is critical to the performance and operations of transistors, especially for ultrathin 2D 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2022) 51 

X. Huang et al. 

4 





Fig. 3 Channel characteristics of 2D semiconductors. a Schematic illustrations of the 1 nm-gate-length CNT-MoS2 transistor. The left panel shows the transfer characteristics curve of the 1 nm-gate-length device. The left and right panels are reproduced from ref.<sup>33</sup> and ref.<sup>36</sup> , respectively. b Schematic illustrations of the short-channel-length monolayer MoS2 transistor. The right panel shows the output characteristics curves of the 35 nm-channel-length device. c–e Gate structure of 2D semiconductor and electric field distribution including planer gate, 3D gate, and Gate all around. f, g Cross-sectional transmission electron microscope images refer to planer gate, 3D Gate all around. f, g are reproduced from refs.<sup>37,39</sup> . 

semiconductors<sup>51</sup> . As 2D semiconductor channels reach the nanoscale, the contact resistance between the source-drain electrode and the semiconductor interface rises and dominates, becoming one of the major factors limiting transistor performance<sup>52</sup> . The metal-semiconductor contact on silicon-based transistors has been optimized and enhanced over decades to efficiently enable ultralow resistance. In contrast, the transport properties of 2D semiconductors and the contact studies are still far from that of silicon-based despite many working studies reported<sup>53</sup> . This is mainly because it is particularly challenging to 

form undamaged contacts between metals and atomically thin 2D semiconductors<sup>54</sup> . 

The root of the formation of contact resistance is that a Schottky barrier<sup>55</sup> will be formed between the contact electrode and the semiconductor, attributed to the energy difference between the metal work function and the semiconductor electron affinity energy, as well as the Fermi level pinning<sup>56</sup> caused by an undesirable contact interface. Theoretically, a Schottky barrier would be the energy level difference between metal electrode and semiconductor in band alignment<sup>57,58</sup> , as 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2022) 51 

X. Huang et al. 

5 





Fig. 4 Contact characteristics of 2D semiconductors. a The band alignment of common metals (Sc, Ti, Cr, Au, and Pt) with examples of monolayer 2D semiconductors (MoS2, BP, and WSe2). b Comparison of ideal and practical band structures of metal-2D semiconductor (Au-WSe2) contacts. c Fermi level pinning effect for monolayer MoS2 and MoTe2. c are reproduced from ref.<sup>59</sup> . d Illustration of transferred metal technique to forming ideal metal-semiconductor junctions. The upper and lower panel show the Cross-sectional schematics and TEM images between evaporated metal and transferred metal, respectively. d are reproduced from ref.<sup>64</sup> . e Illustration of ultraclean vdW contact by evaporating indium as a capping layer. The lower panel shows atomic-resolution images of In/Au on monolayer MoS2. e are reproduced from ref.<sup>65</sup> . f Illustration of ultralow contact resistance on 2D semiconductors via semimetal. The left and right panels show the density of state (DOS) and the band diagram of semimetal and semiconductor contact respectively. The middle panel shows the Schematic of a transistor with a monolayer MoS2 channel and semimetal contacts. c are reproduced from ref.<sup>36</sup> . 

shown in Fig. 4a, b. To minimize the barriers caused in this way, different metals are chosen as contacts for improvement depending on the match to the band of the channels. However experimentally the contact enhancement brought by this is very limited. Because the contact interface suffers from undesirable factors that cause the Fermi energy level of the junction to be typically fixed at a position within the bandgap, with little change in respect to the different metals used<sup>59</sup> (Fig. 4b, c). For bulk materials, the solution to this problem is to heavily doping the region so that the tunnelling current is dominant ignoring the effect of the Schottky barrier<sup>60</sup> . This approach, however, is not suitable for 2D semiconductors because of the technical challenge of doping in atomically thin thicknesses, where doping 

disrupts the lattice structure<sup>61</sup> . Another route is the insertion of an interface layer or the realization of vdW contact. Although the introduction of a layer of the dielectric at the interface can reduce pinning, it inevitably introduces excess tunnelling barriers<sup>62,63</sup> . The construction of a vdW contact by metal transfer achieves near-ideal Schottky barrier regulation, but may not be suitable for scale integration<sup>64</sup> . The presence of a vdW gap can also lead to contact resistance (Fig. 4d). By thermal evaporation of soft metals, the ideal contact interface can be readily formed (Fig. 4e) and the contact resistance is obviously reduced from the previous method<sup>65</sup> , but the presence of the Schottky barrier from the material itself still makes the contact resistance not low enough compared to silicon. 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2022) 51 

X. Huang et al. 

6 





Fig. 5 Dielectric characteristics of 2D semiconductors. a Illustration of direct growth of a conventional high-κ dielectric on 2D semiconductors. The upper and lower panel show the ALD and PEALD processes respectively. b Schematic of hBN as a dielectric by vdW transfer. c Illustration of covering a seed layer to deposit high-κ dielectric. d Growth of high-κ Bi2SeO5 dielectric by in situ native oxidation from Bi2O2Se. e Leakage characteristics in comparison with Si and 2D semiconductors from different dielectric technologies. e are reproduced from ref.<sup>73</sup> . f Comparison of band diagram and dielectric constants between MoS2 and different dielectrics. 

The research team fuelled by TSMC has proposed a semimetal contact method to achieve the lowest contact resistance and thus the largest reported on-state current for 2D semiconductors<sup>36</sup> . As shown in Fig. 4f, they propose to suppress the metalinduced gap state by using the semimetal to set a density of states close to 0 at the Fermi level for reducing the gap state brought by the semiconductor conduction band so that the gap state is saturated. This enables an almost zero Schottky barrier height achieved through the semimetal bismuth (Bi). However, some semimetals such as Stannum (Sn) and Bi may suffer from serious thermal stability and process compatibility problems due to their melting points below 300 °C. Further, antimony (Sb) semimetal, resistant to higher temperatures, has been investigated as a novel contact metal, which can still achieve ohmic contacts with a Schottky barrier highly close to zero, paving the way for high-performance ultrathin transistors<sup>66,67</sup> . In addition to the channels, the contact electrodes need to be small enough for the miniaturization of transistors. Both top contact and edge contact exist for 2D semiconductors<sup>68</sup> , and it was previously reported that the electrical transport performance of top contact 

transistors may degrade with the decrease of electrode length. The ideal contact for a small-sized 2D semiconductor would be an edge contact<sup>69</sup> . Because the conventional top contact is susceptible to defects that significantly reduce the electrical transportability, inducing a large electrode size, while the edge contact is less affected by this. Theoretically, the carrier transport length of an edge contact can be less than 1 nm, allowing the electrode to be small while maintaining performance, which is both promising and challenging to fabricate. 

Dielectric for 2D transistors. Dielectric integration is also an important study to improve the electrical properties of 2D semiconductors for high-performance transistors. The advancement of dielectric could lower the threshold voltage which is beneficial to reducing the device power consumption and also eliminating the device hysteresis contributing to improving the stability of the device. The application of high-κ dielectric materials such as hafnium oxide has been proven in silicon, with experimental equipment and methodological techniques readily available. As shown in Fig. 5a, the earliest use of ALD to deposit 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2022) 51 

X. Huang et al. 

7 



high-κ oxide gate dielectrics in 2D semiconductors was available for thicker gate dielectric layers of the prototype devices<sup>13</sup> . The 2D semiconductor surface without hanging bonds does not possess nucleation sites, and growing oxide films directly by ALD will form uneven structures that cannot completely cover the surface<sup>70</sup> . Due to surface non-uniformity, the local defect states at the interface trap charges to cause hysteresis so the thin gate dielectric is prone to leakage, which is intolerable for highperformance transistors. To fit the atomically smooth inert surface, the dielectric layer may preferably have the same vdW interface. The hBN is used as a gate dielectric insulating layer, not only to maintain atomic-level interface flatness, but also to insulate the 2D semiconductor from the external environment as an encapsulation material, which can greatly improve the intrinsic characteristics such as mobility and stability. As shown in Fig. 5b, hBN is effective and convenient for verifying the device principle when the dielectric layer does not need to be too thin<sup>50</sup> . However, the size of high-quality hBN obtained are small, usually by mechanical exfoliation, not suitable for large-scale preparation. Furthermore, the dielectric constant of hBN is only about 5, similar to that of silicon dioxide but not a high-κ dielectric. When gate control capability at smaller EOT is required, the physical thickness of hBN would be too thin resulting in significant leakage current, catastrophic for the application<sup>71</sup> . Buffer layer or seed layer technique was developed for the integration of highquality ultra-thin high κ dielectrics on 2D semiconductors (Fig. 5c). Usually, a very thin metal layer (which can be naturally oxidized) or oxide layer is first deposited on the 2D semiconductor by thermal evaporation before the ALD gate dielectric<sup>72</sup> . This buffer layer provides the suspended bonds as the nucleation sites required for the deposition of ultrathin high-κ dielectrics. Despite the improvement over the previous ones, the evaporated metal film also suffers from roughness, disorderly variations, and damage by energetic metal ions. To solve these problems, the organic PTCDA as a better seed layer has been proposed<sup>73</sup> . Highquality gate dielectrics with 1 nm EOT are prepared from PTCDA seed layers, and their electrical characteristics meet the requirements of practical applications in the industry<sup>74</sup> . 

Just like silicon evolved due to the benefits of natural silicon oxide, a unique in situ oxidized high-κ dielectric layer may be promising. As shown in Fig. 5d, a special 2D semiconductor Bi2O2Se can generate its own high-κ oxide in situ by precise layerby-layer oxidation<sup>75</sup> . The oxidized formed Bi2SeO5 has a high dielectric constant of 21 and still maintains good leakage properties at 0.9 nm EOT. The disadvantage of such in situ oxides is that they are only effective for specific oxidable 2D semiconductors, instead limiting the choice of 2D semiconductors. Figure 5e summarizes the performance of different dielectrics as a top-gate dielectric on 2D materials including a comparison with silicon processes<sup>73,75–77</sup> . Some data points indicate that the high-κ dielectric integrated on 2D materials are already comparable to industrial requirements. The demand for low-power consumption can be met even at an EOT of 1 nm. Figure 5f shows a contrast of the band alignment and dielectric constants of dielectrics associated with 2D semiconductors. For a good gate dielectric in 2D semiconductors contains five elements: high dielectric constant, low leakage, fewer defects, high breakdown characteristics, and low scattering. It seems to be harsh to fully meet these needs, and the choice has to be balanced against multiple requirements. 

## 2D semiconductors for specific electronic functions 

The rich band structure of 2D semiconductors allows for more options in device design, while the ultrathin nature also brings the benefits of easier manipulation. The vdW heterojunction can be easily constructed without considering problems such as the mismatch of heterogeneous lattices in bulk semiconductors<sup>14</sup> . 

Combinatorial designs at the band and architecture levels can derive novel properties to fuel new functional and new principle transistor discoveries, providing a broad system for fundamental device research. To highlight the employment of 2D semiconductor channels in transistors, here we focus on functional devices with potential specific electronic applications, the most common of which are computing, memory, and sense. 

Computing functions. Low-power logic devices have always been pursued in computing systems. The reduction in transistor size has led to an exponential increase in the number of transistors on the chip, and therefore the power consumption of individual devices aggregated on the chip is an alarming problem. The classical transistor principle is based on the model of thermoelectric emission, even with ideal electrostatic regulation, its switching performance has a thermodynamic limit of Subthreshold Swing (SS) > 60 mV/dec. A breakthrough in the physical mechanism of current devices is essential to achieving lower-power devices. 2D semiconductors, which are not subject to lattice mismatch, provide favourable support for constructing new mechanisms of low-power logic switches. Tunnelling transistors (TFETs) control the current flow by band-to-band tunnelling which is mainly a heterojunction structure type (Fig. 6a). A major advantage of TFETs is that the off-state current is rarely dependent on temperature, but rather on tunnelling efficiency. However, this also predetermines that the drive current will not be large<sup>78</sup> . The negative capacitance transistor implements voltage amplification to control the current by introducing a ferroelectric dielectric at the gate (Fig. 6b). 2D semiconductor intrinsically possesses the ultimate thickness which can bring larger bulk capacitance helping to reduce SS to lower levels than conventional materials. Different researchers have fabricated lowvoltage driven MoS2 devices with negative capacitance realizing hysteresis-free, low power, and high current transistors<sup>79,80</sup> . Nevertheless, ferroelectric materials tend to develop polarization under electric fields that cause hysteresis and affect the stability of the operating condition<sup>81</sup> . Dirac source transistors employ Dirac materials as cold electron sources to lower the limits of thermally emitted electrons<sup>82</sup> (Fig. 6c). The unique linear bandedge dispersion relationship of graphene results in a superexponential carrier concentration variation with energy, enabling SS below 40 mV/dec with almost no hysteresis in conjunction with MoS2. The GAA structure can also be added to the MoS2 to further reduce power consumption and increase drive current<sup>83</sup> . These transistors targeting low-power computing rely on the excellent interfacial properties of 2D semiconductors to accomplish the construction of new mechanisms. 

With tailor-made according to its nature, 2D semiconductors realize a completely new transistor structure. As shown in Fig. 6d, MoS2 is used as the channel, and the top gate and back gate are used as two input signals that can jointly tune the channel conduction state for logic computation<sup>84</sup> . In contrast to the restricted passivation surfaces of bulk semiconductors, both the top and bottom surfaces of 2D semiconductors can be effectively tuned. Moreover, its logic function can be switched between AND and OR as the thickness and light vary. Such a two-surface channel (TSC) transistor serves as a more compact logic cell, where one device can perform the logic functions that would traditionally require two devices, significantly improving area utilization. As shown in Fig. 6f, it’s like folding two transistors together, but only taking up the footprint of one transistor. On this basis, the diverse polarities of 2D semiconductors are introduced to implement more different logics<sup>85</sup> (Fig. 6g). For example, the bipolarity of WSe2 has two working carriers at the same time and is suitable for constructing XNOR logic. As nonlinear arithmetic logic, XNOR logic requires more transistor resources in traditional architectures, while only a single device is enough to implement it using bipolar TSC transistors. Figure 6h 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2022) 51 

X. Huang et al. 

8 





Fig. 6 2D semiconductors for computing. a Cross-sectional transistor schematic of a tunnelling FET. b Cross-sectional transistor schematic of a negative-capacitance FET. c Cross-sectional transistor schematic of a Dirac-source FET. d Illustration of logic gate based on the single MoS2 transistor. The left penal shows the schematic structure and the right penal shows the cross-sectional TEM image. e Comparison of traditional logic gates and 2D logic gates. d, e are reproduced from ref.<sup>84</sup> . f Transfer curves and logic behaviour of the logic gates based on WSe2 (ambipolar-type), BP (p-type), and MoS2 (n-type). g Schematic of a 2T2R circuit composed of a WSe2 logic transistor, a MoS2 logic transistor, and two resistors. f, g are reproduced from ref.<sup>85</sup> . 

shows a logic circuit based on TSC transistors, which can implement a half adder and parity checker with an overhead of 2T2R. The TSC logic transistors have superior small size and hightemperature stability. 

The unique carrier dynamics of 2D semiconductors provide a controllable degree of freedom to manipulate polarities through electrostatic tuning. The carrier injection of the contact is regulated by an additional electrode<sup>86</sup> , which allows the device to be programmed between n-type and p-type. This avoids the need for doping and effectively increases circuit reusability and reduces design complexity. However, this polarity switching is maintained by a constant gate voltage bias. With solid-state ion doping, it is also possible to build non-volatile programmable devices<sup>87</sup> . When the gate voltage is removed, the device remains in the n- or p-type state. The WSe2 homogeneous junction device based on horizontal double gates exhibits eight current switching states, and various input voltages enable logic 

function switching of the cell<sup>17</sup> . The cascaded devices can be created for reconfigurable complex logic function circuits that facilitate the application of secure encryption. vdW heterojunctions of 2D semiconductors exhibit anti-bipolarity<sup>88</sup> , negative differential resistance<sup>89</sup> , or resonant tunnelling<sup>90</sup> depending on the band combinations, thus permitting the construction of novel multivalued logic calculations<sup>91</sup> . For example, the band alignment of heterojunctions composed of MoS2 and BP can shift from type-I to type-II and type-III under effective gate control<sup>92</sup> . From this, a tunable trinary logic gate with a new logical mid-state is developed. Homogeneous junctions with misaligned bands formed by solution-doped MoS2 also show ternary states under gate voltage modulation, leading to ternary inverters, NMIN and NMAX gates<sup>93</sup> . This area-selective chemical doping simplifies the construction of multivalued logic gates. The higher information density of multivalued logic gates is attractive for computing systems to reduce circuit complexity, 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2022) 51 

X. Huang et al. 

9 



and the abundant tunable properties could provide new ideas for circuit design. 

Memory functions. 2D semiconductors without dangling bonds are compatible with memory applications, allowing for the tailoring of specific memory transistors. The electrical characteristics of floating-gate memory largely depend on the band design, for which the sharp layered interface is naturally suited. With its direct bandgap and ultrathin thickness, monolayer MoS2 as a channel material is extremely sensitive to charge changes in the floating gate<sup>94</sup> , with a ratio of programmed to erased states of up to 10<sup>4</sup> . Memory transistors based on full 2D material stacks enable the two-terminal operation by tunnelling from the drain to charge and discharge of the floating gate<sup>95</sup> . This two-terminal device can be realized with an on/off ratio of 10<sup>9</sup> and a retention time of over 10<sup>4</sup> s. Without the need for a typical gate to govern the injection of the floating gate, this structure also simplifies the construction by removing the blocking layer. Charge-trap memory is a more stable and optimized structure, whose major difference is that the charge is trapped in a material with a high defect energy density 

instead of a floating gate where the electrons can move. For 2D semiconductors, only one layer of channel material is necessary, which is highly compatible with conventional processes<sup>96</sup> , as shown in Fig. 7a–c. Discrete charge storing of oxide layer defects allows for more precise modulation. Utilizing 2D graphite acetylene with sufficient hybridization states as a separate capture layer to form vdW heterojunctions with 2D semiconductors, up to nine storage states can be obtained, exhibiting novel multilevel and multifunctional memory<sup>97</sup> . 

By controlling the field-effect characteristics of the 2D semiconductors through the residual polarization of ferroelectricity (Fig. 7d), a ferroelectric transistor memory can be implemented<sup>98</sup> . The large surface-to-volume ratio enables 2D semiconductors highly sensitive to interfacial environments, which greatly enhances the response to external factors such as ferroelectric polarization<sup>99</sup> . The 2D ferroelectric transistors employ organic polymers P(VDF-TrFE)<sup>100–102</sup> or inorganic high-κ oxides<sup>103</sup> as their ferroelectric gate dielectric. The most compelling features of these ferroelectric non-volatile memories are their simple device structure, faster access speeds, high endurance and low 



Fig. 7 2D semiconductors for memory. a Tunnelling mechanism of programing and erasing in a flash memory device. b Schematic structure of a charge-trap memory based on MoS2. c Memory window of the transfer curves in the MoS2 memory device. b, c are reproduced from ref.<sup>96</sup> . d Illustration of polarization–voltage hysteretic characteristic in 2D ferroelectric field-effect transistors. e Schematic structure of an AlScN/MoS2 FE-FET. f Memory window of the transfer curves in the AlScN/MoS2 FE-FET. e, f are reproduced from ref.<sup>108</sup> . g Band alignment and the electric field of 2D ultrafast non-volatile flash in the FN tunnelling process. h The cross-sectional high-resolution TEM image of the 2D ultrafast non-volatile flash device. i Response waveforms of the ultrafast memory operation in programming and erasing. g–i are reproduced from ref.<sup>15</sup> . 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2022) 51 

X. Huang et al. 

10 



writing energy<sup>104</sup> . The HfZrOx-based ferroelectric memory requires a high-quality interface to enhance its performance since the oxygen vacancies present at the interface may strongly affect the electrical properties and even severely degrade the reliability of the device<sup>105</sup> . The current ferroelectric transistors using inorganic high-κ oxides are limited to back-gate structures because it is difficult to maintain inorganic ferroelectric material properties at the smooth interfaces of 2D semiconductors. Topgate structures can be prepared with ferroelectric polymers, however, the operating voltage is too high<sup>106,107</sup> . As in Fig. 7e, f, the ferroelectric material AlScN dielectric compatible with the post-CMOS process can also produce high-performance ferroelectric memory in combination with 2D semiconductors<sup>108</sup> . The 2D channel is critical not only for acquiring high on/off ratios but also for long-time retention due to the minimal depolarization field<sup>109</sup> . For the problem of depolarization field and gate leakage current in ferroelectric gate dielectrics, ferroelectric channel transistors implemented with the 2D ferroelectric semiconductor InSe can employ the popular high-quality dielectric layer without the need for a crystalline ferroelectric insulating layer<sup>110</sup> . The naturally existing mobile charges in 2D ferroelectric semiconductors can form a built-in electric field, which effectively shields the depolarization field inside the ferroelectric semiconductor, improves the fatigue resistance of conventional FeFETs, eliminates charge capture and leakage current effects, and ultimately achieves optimized ferroelectric memory performance<sup>111</sup> . 

In addition to bringing certain performance improvements to traditional memory technologies, 2D semiconductors allow for innovative breakthroughs to the original framework limitations. A high-speed quasi-nonvolatile memory device was created by embedding a PN junction in the floating gate, exploring the combination of high-speed writing and long-time retention<sup>112</sup> . The core principle is to accelerate the process of charge injection by using the forward potential barrier of the PN junction for highspeed data writing, and to prevent charge escape by using the reverse potential barrier for effectively extending the data retention time. Based on the semi-floating gate, the improved lateral PN junction for the floating gate achieves symmetric ultrafast write erase operation<sup>113</sup> , and the modulating effect of the local ferroelectric field further enhances the quasi-non-volatile retention time<sup>114,115</sup> . vdW heterogeneous integration has shown amazing potential for pushing the limits of memory, with both research teams successfully constructing ultrafast, non-volatile floating-gate memory devices. Exploiting the atomically sharp interface and enhanced interfacial coupling properties of 2D vdW heterojunctions<sup>16</sup> , Wu et al demonstrated 20 ns read/write times (compared to hundreds of microseconds in commercial flash devices), high erase/write ratios (~10<sup>10</sup> ), and long storage times (over 10 years). Liu et al found that during the operation of storing and erasing, the barrier height determines the degree of charge tunnelling through, the gate coupling ratio defines the charge density generated by the gate control voltage, and clean interface ensures that no additional contamination or defects are introduced (Fig. 7g, h)<sup>15</sup> . A generic device model based on this ultrafast charge memory principle was developed to break through the traditional empirical constraints with 2D materials (Fig. 7i). Highperformance memory based on vdW heterogeneous structures provides a bright technical path for the development of unified general-purpose memory. 

Sensing functions. 2D semiconductors have a surface-to-volume ratio unmatched by other structural materials and have a natural advantage in responding to surrounding physical or chemical signals. Light, atmosphere, temperature, and humidity are prone to cause rapid changes in electron transport at 2D surfaces. And these changes are fast response, high sensitivity, easy to achieve sensor miniaturization, which can play a significant role in improving sensor sensitivity and reducing sample usage, 

especially for in vivo, in situ and real-time detection in biological sciences<sup>116</sup> . Its suitable bandgap provides better biocompatibility and lower detection limits for biological targets, which is advantageous in the detection of complex biological samples at low concentrations<sup>117</sup> . The MoS2 nano-biosensor has already achieved the detection of various biomolecules such as DNA<sup>118</sup> , RNA<sup>119</sup> , and proteins<sup>120</sup> . Compared to resistive or capacitive sensors<sup>121,122</sup> , biosensors based on field-effect transistor structures are typically used as 2D semiconductor channels for transduction, where the detection mechanism lies in the electrical signal in the biomolecule altering the carrier distribution in the channel. So high mobilities are important for biodetection<sup>123</sup> . To improve the detection sensitivity of the target, different structures or surface modification functionalizations of the channel have been used<sup>124,125</sup> . The principle is similar to the detection of some molecules or ions as chemical sensors<sup>126</sup> . One of the problems of detection in solution is that long-time immersion can easily damage the channel material or structure of the transistor, thus the controllability of the device is poor and non-reusable<sup>127</sup> . 2D semiconductors can also provide sensitive detection of pressure<sup>128</sup> , yet pressure puts high demands on the stability of the device as well. For use on electronic chips, gas and light detection is non-invasive for 2D semiconductors and is generally more widely used. 

The sensing of gases by 2D semiconductors generally stems from the electron transfer mechanism between the gas molecules and the channel. A suitable bandgap allows for the transfer properties to enhance the sensing capability<sup>129</sup> . Different gases touching or disassociating from the channel will cause the channel resistance to change accordingly. The direction and magnitude of the variation in channel resistance are used to analyze the composition and concentration of the gas to be measured. It is valuable for the detection of flammable and toxic gases<sup>130</sup> . First-principles calculations show that MoS2 experiences high rate charge transfer and high adsorption energy with NO, NO2, and SO2, for which MoS2 produces a strong response<sup>131</sup> . As for MoSe2, the adsorption of SO2 and NO leads to P-type doping, while the adsorption of NO2 induces the semiconductor-to-metal transition, so the MoSe2 sensor is more sensitive to NO2<sup>132</sup> . Diverse 2D semiconductors provide more suitable options for sensing different gases<sup>133–136</sup> . Structural optimization and light assist can effectively enhance 2D gas sensor responsiveness<sup>137</sup> . As shown in Fig. 8a, the suspended structure increases the effective sensing area, and the introduction of light also promotes the electronic interaction of the channel with the adsorbed molecules. The minimum detection concentration of SnS2 after optimization was increased from the ppm level to 20 ppb (Fig. 8b) with a high selection ratio (Fig. 8c). High sensitivity and selectivity ratios, fast response recovery time, and the ability to operate at room temperature are advantages of 2D semiconductors as gas-sensitive materials. 

The unique optoelectronic properties exhibited by 2D semiconductors are widely used in photodetectors<sup>138</sup> . Their operating principles can be primarily classified into photoconductive effect type (Fig. 8d–f)<sup>139</sup> and photovoltaic effect type (Fig. 8g–i)<sup>140</sup> . When light with photon energy greater than the bandgap is irradiated on the 2D semiconductors, the material absorbs the photon energy and excites to produce electrons and holes, resulting in the conductivity change of 2D semiconductors<sup>141</sup> . With the merits of high responsiveness, high photocurrent gain, and high quantum efficiency<sup>142</sup> , 2D semiconductor photodetectors based on the photoconductivity effect are widely studied. However, it has the problems of high dark current and low detectivity. By taking advantage of gate modulation, we can improve the sensitivity, suppress the dark current and improve the photocurrent on/off ratio<sup>139</sup> . The introduction of ferroelectric material into the gate dielectric layer (Fig. 8d) enables highly 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2022) 51 

X. Huang et al. 

11 





Fig. 8 2D semiconductors for sense. a Schematic of a suspended SnS2-based gas sensor. b Responses of the suspended SnS2-based sensor under different vapour conditions. c The selectivity of the suspended SnS2-based sensor in different gases and solvent vapours. a–c are reproduced from ref.<sup>137</sup> . d Schematic of a MoS2-based photoconductive mode detector with the ferroelectric HZO thin film in the gate dielectric stack. e Mechanism of ultrasensitive optical detection in the negative-capacitance MoS2 phototransistor. f Transfer curves of the NC MoS2 phototransistor under different light. d–f are reproduced from ref.<sup>139</sup> . g Schematic of vdW unipolar barrier phototransistors. h Band alignment of the vdW unipolar barrier phototransistors. i Output curves of the vdW unipolar barrier phototransistors under different light. g–i are reproduced from ref.<sup>140</sup> . 

sensitive photodetection by using the local electrostatic field of the ferroelectric material to suppress the dark current (Fig. 8e, f). The photovoltaic photodetector with the formation of a junction can also improve the performance and suppress dark currents. The electrons and holes generated by light irradiation migrate in response to the junction’s built-in electric field, yielding a photogenerated voltage, which is the photovoltaic effect<sup>143</sup> . 2D semiconductor photodetectors based on the photovoltaic effect usually have excellent high-frequency response characteristics that can be applied to optical communication, optical modulation, and ultrafast light detection<sup>144,145</sup> . To construct unique band alignments for improved photodetection performance, vdW heterojunctions solve the technical bottleneck of lattice mismatch in conventional epitaxial thin-film materials. As shown in Fig. 8g, h, a properly matched band can construct a unipolar potential barrier that effectively suppresses the dark current without weakening the optical response, enhancing the detector signal-to-noise ratio<sup>140</sup> . While bandgaps for TMDs correspond to wavelengths in the visible band, black phosphorus with narrow band gaps is available for mid-IR and long-wave IR photodetection. The extensive band structure of 2D semiconductors is sufficient to enable 2D photodetectors to achieve wideband photoresponse. 

## Functional array functions 

Thanks to the extensive and in-depth research base on the physical properties of 2D semiconductors, the exploration of electronic application systems with specific functionalities are already underway and has expanded from single-device optimization research to a multi-device array with specific functions. Despite being at the initial research stage, the uncertain and challenging path of 2D semiconductors toward array applications is where the opportunity for disruptive technologies lies. According to the applications, we divide the arrays into two types, computing arrays, and functional fusion arrays. 

Computing array. The scale of the array based on 2D semiconductors is developed mutually with access to the prepared materials. In the earlier studies, the mechanical exfoliation method without hardware equipment requirements is suited for some small-scale cascades of circuit function verification. The team from MIT was the first to consider the cascade to complete the integrated function demonstration, and they implemented a NAND gate, SRAM, and ring oscillator with exfoliated bilayer MoS2<sup>146</sup> . To solve the problem of input-output voltage mismatch between transistor devices, they implemented E-mode and D-mode inverter connections using the metal gate to modulate 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2022) 51 

X. Huang et al. 



## 12 



Fig. 9 Computing function arrays of 2D semiconductors. a Schematic of the back-gate architecture of MoS2 transistor adjusted by the channel width/length ratio for integrated circuits. b Schematic of MoS2-based inverters using n-type enhancement-mode. c Block diagram of the MoS2-based 1-bit microprocessor architecture. d Block-level representation of the OPA circuit made from MoS2 transistors. e Optical images of the MoS2-based analogue circuits chip. a–e are reproduced from ref.<sup>156,157</sup> . f Illustration of the single logic transistor with switchable functions. The top penal shows the cross-sectional TEM image and the bottom penal shows the schematic structure. g Schematic of the pixel processing array circuit based on the single logic transistor. h Optical images of the image processing pixel array with switchable functions. f–h are reproduced from ref.<sup>158</sup> . 

the threshold. The ring oscillator composed operates from 0.52 MHz at Vdd = 1.15 V to 1.6 MHz at Vdd = 2 V, confirming the ability of the 2D semiconductor to work in applications. Limited to the size of the exfoliated material, such integrated circuits were only available with 2–12 transistor devices, which were at a more primitive stage. Subsequently, the complexity and functionality of the circuits have increased markedly thanks to technological advances in transfer and large-area CVD growth<sup>147</sup> . Introducing assisted compact models and electronic design automation, device, and circuit co-optimization within the first gate process allows for the preparation of more complete functions, including various combinations (inverters, NAND, NOR, AND, OR, XOR, XNOR) and sequential logic circuits (latches, edge-triggered registers) and switched-capacitor DC-DC converters<sup>148</sup> . Solution-processable 2D semiconductor nanosheets also enable high-quality channel material deposition with 95% yield for diverse logic gate functions. Yet, the size of transistors prepared by liquid-phase epitaxy is relatively large, reaching tens of microns or more<sup>149</sup> . With MoS2 grown on 2-inch substrates by single-crystal epitaxy<sup>150</sup> , the device channel length can reach 500 nm, the device yield reaches 94.3%, with a 16% on-state current variation. The single-crystal growth and wafer-level 

uniformity of MoS2 provide a scalable technology route for 2D semiconductors. There are also stability studies dedicated to smaller devices<sup>151,152</sup> , but not yet migrated from discrete devices to functional circuits. Process optimization is possible by eliminating the transfer process through in situ growth<sup>66,153,154</sup> , and there is still room for performance and scalability improvements. Machine learning algorithms can also be used to assist in manufacturing optimization<sup>155</sup> . The existing computational patterns are divided into digital and analogue, both of which are inseparable from the stability of the device materials and the matching design issues. Effective advances in synthetic growth and process flow can make 2D semiconductors feasible without considering higher requirements for complementary logic and application specifications for demo chip systems. The research team at the Technical University of Vienna has been working on this (Fig. 9a–e). In the absence of a p-type for MoS2, the matching between transistors is achieved by the adjustment of the width-to-length ratio to implement the cascade (Fig. 9a). It can be combined into a microprocessor containing a comprehensive architecture<sup>156</sup> (Fig. 9b). It integrates 115 2D transistors in an area of 0.6 mm<sup>2</sup> , with a 1 bit data register and program counter capacity. 1-bit data 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2022) 51 

X. Huang et al. 

13 



memory designs could be easily extended, and progress in steps could allow for continued practical considerations. Analogue circuit systems are less generally known but are essential in practical application requirements, and the compatibility between analogue and digital is desired. Analogue devices are required to provide highly stable and reproducible parameters, which places more demands on analogue circuits based on 2D semiconductors. This is because 2D transistors are very sensitive to changes of different factors involved in circuit fabrication such as oxide quality and interface states. Exceptional transistor performance with low hysteresis and high repeatability is achieved by carefully controlling the low variability<sup>157</sup> , enabling the combination of transistors into a 4-stage amplifier (Fig. 9d, e) with a total gain of 36 dB, consistent with the modelling. This operational amplifier has a unit gain frequency of 0.3 Mhz suitable for practical feedback circuits such as inverting amplifiers, integrators, logarithmic amplifiers and impedance amplifiers. Although digital and analogue circuits for 2D semiconductors are still far from industry standards, as a proof of concept, the validity of the working capability is much more worthy of attention to give a guiding analysis for industrial production at scale. 

In addition to the traditional mimicry of silicon-based computing systems, 2D semiconductors are capable of expanding new computing array applications based on their own characteristics. Taking advantage of the two surface channels and the efficiently adjustable band (Fig. 9f), the ambipolar WSe2 transistor achieves different logic functions such as AND and XNOR by applying different voltages to the drain without additional control circuits<sup>158</sup> (Fig. 9g). This highly efficient logic computing unit achieves the same functionality as a conventional silicon-based logic gate, consuming only 16% of the transistor count of the latter (Fig. 9h). Computing arrays with electrically switchable logic reduce circuit redundancy and increase transistor utilization significantly. This work can be considered as a highly integrated and customized ALU that still has many difficulties to overcome. So far, most electronic devices have been implemented on rigid substrates, while 2D semiconductors have excellent mechanical flexibility thus providing a natural advantage in flexible and transparent electronics<sup>159</sup> . 4-inch highquality, highly oriented monolayer MoS2 obtained by epitaxial growth and optimization of the device processing process were used to successfully realize large-area flexible transistor arrays as well as logic devices with sizes of 3 μm<sup>160</sup> . Device densities up to 1518 devices cm<sup>−2</sup> and yields of 97% were attained. In addition, the individual devices exhibit excellent electrical performance and flexibility, with a switching ratio of 10<sup>10</sup> , average mobility of 55 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , and an average current density of 35 μA μm<sup>−1</sup> . MoS2 can be used as a driving transistor to realize 32*32 microLED display arrays by adopting a nearly damage-free large-size 2D semiconductor TFT manufacturing process<sup>161</sup> , demonstrating the great potential of 2D semiconductor materials for display driver industry applications. 

Functional fusion array. The novel and sensitive physical properties of 2D semiconductors allow the task of processing to be performed within memory or sensing functions. The memory of 2D semiconductors is often combined with computational processing, since the stored state can finely regulate the conductance of the 2D semiconductor, and then act with the input signal to obtain the processed output. This is similar to applications in neuromorphic computing, where there has been a large amount of research linking device behaviour to the mapping of neuro-synaptic behaviour, but for 2D semiconductors is mostly limited to functional demonstrations of single devices<sup>162–164</sup> . Considering the variation between multiple devices and achieving integration at the array level is critical to implementing large-scale systems that highlight the advantages of 2D. As shown in Fig. 10a, the logic functions and circuits can be 

implemented directly on the memory device with large-scale CVD MoS2 as the channel of the floating-gate memory<sup>19</sup> . With the ability to precisely control the conductance state of a 2D semiconductor, the threshold voltage of the memory cell can be tuned by adding or removing charge carriers in the floating gate. Non-volatile programming of the threshold voltage provides more freedom to reconfigure the function for both digital and analogue circuit applications (Fig. 10b). This direct integration of memory and logic can increase processing speed. 2D semiconductors are potential candidates for artificial synapses with low power consumption, flexible heterogeneous integration, and excellent tunable performance. The implementation of 2D semiconductor synaptic arrays on commercial sr-SiNx exhibits uniform performance, sufficiently high analogue on–off ratios, and linear conductivity updates<sup>165</sup> . Compatible with conventional semiconductors, sr-SiNx as a functional dielectric provides a simple way to construct 2D synaptic arrays. Thanks to the 2D ferroelectric devices with large on–off ratios, high speed, and low power consumption, and non-volatile characteristics, their polarization-regulated weight updates are intensively studied for neuromorphic computing<sup>20,114,166,167</sup> . Considering the computational tasks performed on these memories, a peripheral circuit is required for analogue signal processing. 2D semiconductor WSe2 manipulates polarity through non-volatile ferroelectric memory<sup>168</sup> (Fig. 10c), allowing functional integration of operational amplifiers for analogue signal processing (Fig. 10d). The efficient processing of analogue signals by homogeneous devices (Fig. 10e) ensures instant processing at the output of the stored signals, improving module integration and resistance matching. 2D semiconductors offer such an approach to break the bottleneck of compatibility issues of physical separation of peripheral circuits and memory computing modules between heterogeneous devices, and to realize the integration of analogue signal processing and memory operations on the same platform for the unified neuromorphic computing architecture. 

Large-area, 2D semiconductors for easy 3D integration create effective sensor arrays that provide tighter functional integration into the system. The 8*8 active pixel image sensor array can be prepared by two-step large-area growth of bilayer MoS2 without transfer<sup>169</sup> . To verify monolithic 3D integration, MoS2 phototransistor arrays with ultra-high responsivity (>10<sup>3</sup> A/W) and tunable optical gain (10<sup>2</sup> –10<sup>5</sup> ) were realized on CMOS circuits by fine-pitch vertical interconnects at BEOL<sup>170</sup> . In addition to bringing functions closer together over spatial distances, 2D semiconductors allow for radical functional fusion, improving system processing efficiency. As shown in Fig. 11a, in conventional hardware systems for signal conversion and processing, such tedious discrete processes affect the speed of signal processing, and the huge unprocessed information transmission increases energy consumption. Based on the artificial neural network processing principle (shown in Fig. 11b), a 2D semiconductor enables the construction of a sensor array that simultaneously implements optical signal acquisition and processing<sup>171</sup> . To map the neural network algorithm, WSe2, as a photosensitive material with bipolar conducting behaviour and excellent optoelectronic properties, is the key to the fusion of sensing and processing (Fig. 11c). Although the ANN employed is a single-layer network with an array of only 3*3 pixels, the system is capable of processing images at a throughput of 20 million bins per second, enabling real-time image acquisition operations at the ns level. The computing part of the ANN algorithm is integrated into the hardware itself, without data migration, reducing energy consumption and latency, which gives a novel way for the implementation of ultra-fast machine vision imaging. From biological behaviour, a curved image sensor that mimics human visual imaging enables neuromorphic data processing functions, complete with effective image capture and pre-processing<sup>172</sup> . The focus is on the integrated 2D semiconductor-based heterojunction that makes the photon-triggered electrical response similar to 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2022) 51 

X. Huang et al. 

14 





Fig. 10 Computing in memory arrays of 2D semiconductors. a Schematic of the logic-in-memory chip based on 2D floating-gate memory transistors. The bottom penal shows the schematic diagram of the memory circuits. b Programmable functions implemented by the inverter cell based on the floating-gate memory. a, b are reproduced from ref.<sup>19</sup> . c Illustration of the homogeneous transistor-memory architecture and working mechanism based on FE polarization doping. d Schematic diagram of the OPA circuits (left) and test configuration (right) based on FE polarization doping. e Waveforms of the addition operation (left), the integral calculation for the square input (middle) and the triangle input (right). c–e are reproduced from ref.<sup>168</sup> . 

synaptic signals in neural networks and leads to a weighted electrical output. 

Once the sensing and processing functions are performed simultaneously, the data usually needs to be stored, and there is a certain amount of energy consumption and time delay in the intervening data transmission. If the state of the sensor can be remembered, a highly efficient integrated system of sensingprocessing-memory could be realized to further improve the processing capability of the sensor. Inspired by the retina, the floating grid optoelectronic memory is proposed as an all-in-one retinal hardware with sensing, computing, and memory as one<sup>173</sup> (Fig. 11d). The phenomenon of WSe2 non-volatile positive/ negative photoconductance exhibit good linearity (Fig. 11e). The complete functions of human vision are available on a single device: photoreceptor (rod and cone cells), signal conversion 

(bipolar cells), weight storage update (non-elongated cells), and output (ganglia). The application of this device validates the separation detection of moving objects and high accuracy recognition function of the tricolour trolley (Fig. 11f). But there are still some critical technical processes to overcome from the low-density proof-of-concept in the laboratory to the complex integrated functional systems that address practical applications. As the nodes of the intelligent system increase, redundant data is transmitted between sensing, processing, and memory causing waste of resources<sup>6</sup> . One-stop processing at the edge terminals thus reducing unnecessary data movement and production is a natural solution to consider. 2D semiconductors have excellent characteristics of electrical, heterogeneous integration, adjustable external field, and other properties suitable for integration of sense, memory, and computing, which is conducive to breaking 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2022) 51 

X. Huang et al. 

15 





Fig. 11 Arrays integrated with sense. a Illustration of the chain flow for sensing detection by the traditional hardware. b Schematic diagram of the single-layer artificial neural network as the classifier implemented by 2D sensors. c Macroscopic images of the ANN sensor-based array. c are reproduced from ref.<sup>171</sup> . d Schematic diagram of the all-in-one retinomorphic hardware device based on 2D materials. e Cumulative positive and negative photoconductivity characteristics of the retinomorphic devices. f Principle of Motion detection and recognition precessed by retina-inspired 2D retinomorphic hardware. d–f are reproduced from ref.<sup>173</sup> . 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2022) 51 

X. Huang et al. 

16 



through the functional limitations of traditional semiconductor materials to promote electronic data systems faster, more energyefficient and more intelligent. 

## Summary and perspectives 

In the framework of transistor-based electronic applications, we have summarized two potential development paths from device and system for 2D semiconductors. From the underlying device perspective, unlike conventional bulk materials, 2D semiconductors are structurally and functionally intact at the atomic level and have inherent adaptation advantages for future transistor architectures. Therefore, as high-performance ultra-thin nanosheets, 2D semiconductors need to meet the practical needs for fabrication, with optimization mainly in terms of channel modulation, contact enhancement, and dielectric integration. Among them, short-channel performance, ultra-low contact from semimetal can reach comparable to the requirements of industry, whereas doping for polarity and ultra-thin dielectric integration has made considerable progress but are not enough for application. From the perspective of functional systems, 2D semiconductors exhibit novel physical properties favourable to the construction of diverse functional applications, with unique application merits in processing, memory, and sense. Appended to the seamless vdW heterogeneous integration, fusion functions such as neuromorphic computing, logic-in-memory, and in-sense computing have moved from device concepts to small-scale array presentation. To make leaps in computational performance requires a new paradigm of integrated performance<sup>8</sup> , where the integrative collaboration of discrete functions can bring the benefits of massive energy and execution time. Hardware systems with sensing, storing, and processing all in one on 2D semiconductors are expected to disrupt the future architecture of electronic applications. 

The two trends in 2D semiconductors are complementary and closely related. The path to high-performance transistors driven by industry demands highly on device technology, as this is close to readily available commercial applications and is the more nearterm engineering goal. The robustness of 2D semiconductors as the underlying devices promoted by industry, will also greatly facilitate the development of their systems. The top-level design of the integrated system framework can motivate the application orientation of 2D semiconductors to support the application scenarios suitable for the base devices, and the hardware system for fusion functions is the academic research goal in the long term. What needs to be seen is that there are still immediate critical communal challenges that need to be addressed. Large-area material growth with compatible transfer integration techniques is the first hurdle limiting the application of 2D semiconductors at scale. Intel’s latest claim is that four 2D semiconductor materials can be prepared at 300 mm level to date<sup>153</sup> , but are limited to in situ growth of one type of film. Compatible transfer integration becomes a key factor for widespread application, as the heterogeneous stacking brings out the best in 2D. It is equally necessary to find a practical passivated interface material to ensure the stability of 2D semiconductors. The 2D over-sensitive surface is prone to bring unwanted unstable performance which is an essential challenge for device preparation at present, so a modification process that can stabilize the 2D material properties under various conditions will greatly accelerate the iterative mass production. Stability is the basic premise before facing other subsequent problems to be solved one by one. In an era where the demand for electronic applications continues to surge, 2D semiconductors seem to be thorny rose in the face of shrinking difficulties and computing architecture bottlenecks, an answer both real and vaguely distant. Despite the difficulties, it is clear that the future calls for 3D integration, and the disruptive 

integration options from 2D semiconductors offer the advantage of adding a degree of freedom to 3D integration. 

## DATA AVAILABILITY 

The data that support the findings of this study are available from the corresponding author upon reasonable request. 

Received: 24 March 2022; Accepted: 13 July 2022; 



## REFERENCES 

1. LeCun, Y., Bengio, Y. & Hinton, G. Deep learning. Nature 521, 436–444 (2015). 

2. Zhang, W. et al. Neuro-inspired computing chips. Nat. Electron. 3, 371–382 (2020). 

3. Yoo, H. J. 1.2 Intelligence on silicon: From deep-neural-network accelerators to brain mimicking AI-SoCs. In Proc. 2019 IEEE International Solid-State Circuits Conference - (ISSCC), 20–26 (IEEE, 2019). 

4. Jacob, A. P. et al. Scaling challenges for advanced CMOS devices. Int. J. High. Speed Electron. Syst. 26, 1740001 (2017). 

5. Luisier, M., Lundstrom, M., Antoniadis, D. A. & Bokor, J. Ultimate device scaling: Intrinsic performance comparisons of carbon-based, InGaAs, and Si field-effect transistors for 5 nm gate length. In Proc. 2011 International Electron Devices Meeting, 11.12.11–11.12.14 (IEEE, 2011). 

6. Zhou, F. & Chai, Y. Near-sensor and in-sensor computing. Nat. Electron. 3, 664–671 (2020). 

7. Shulaker, M. M. et al. Three-dimensional integration of nanotechnologies for computing and data storage on a single chip. Nature 547, 74–78 (2017). 

8. Radway, R. M. et al. The future of hardware technologies for computing: N3XT 3D MOSAIC, illusion scaleup, co-design. In Proc. 2021 IEEE International Electron Devices Meeting (IEDM), 25.24.21–25.24.24 (IEEE, 2021). 

9. Chaves, A. et al. Bandgap engineering of two-dimensional semiconductor materials. npj 2D Mater. Appl. 4, 29 (Springer Nature, 2020). 

10. Novoselov, K. S., Mishchenko, A., Carvalho, A. & Castro Neto, A. H. 2D materials and van der Waals heterostructures. Science 353, aac9439 (2016). 

11. Akinwande, D. et al. Graphene and two-dimensional materials for silicon technology. Nature 573, 507–518 (2019). 

12. Liu, Y. et al. Promises and prospects of two-dimensional transistors. Nature 591, 43–53 (2021). 

13. Radisavljevic, B., Radenovic, A., Brivio, J., Giacometti, V. & Kis, A. Single-layer MoS2 transistors. Nat. Nanotechnol. 6, 147–150 (2011). 

14. Liu, Y., Huang, Y. & Duan, X. Van der Waals integration before and beyond twodimensional materials. Nature 567, 323–333 (2019). 

15. Liu, L. et al. Ultrafast non-volatile flash memory based on van der Waals heterostructures. Nat. Nanotechnol. 16, 874–881 (2021). 

16. Wu, L. et al. Atomically sharp interface enabled ultrahigh-speed non-volatile memory devices. Nat. Nanotechnol. 16, 882–887 (2021). 

17. Pan, C. et al. Reconfigurable logic and neuromorphic circuits based on electrically tunable two-dimensional homojunctions. Nat. Electron. 3, 383–390 (2020). 

18. Wu, P., Reis, D., Hu, X. S. & Appenzeller, J. Two-dimensional transistors with reconfigurable polarities for secure circuits. Nat. Electron. 4, 45–53 (2020). 

19. Migliato Marega, G. et al. Logic-in-memory based on an atomically thin semiconductor. Nature 587, 72–77 (2020). 

20. Liu, C. et al. Two-dimensional materials for next-generation computing technologies. Nat. Nanotechnol. 15, 545–557 (2020). 

21. Hu, Z. et al. Two-dimensional transition metal dichalcogenides: Interface and defect engineering. Chem. Soc. Rev. 47, 3100–3128 (2018). 

22. Manzeli, S., Ovchinnikov, D., Pasquier, D., Yazyev, O. V. & Kis, A. 2D transition metal dichalcogenides. Nat. Rev. Mater. 2, 17033 (2017). 

23. Rehman, M. M. et al. Decade of 2D-materials-based RRAM devices: A review. Sci. Technol. Adv. Mater. 21, 147–186 (2020). 

24. Poljak, M., Jovanovic, V., Grgec, D. & Suligoj, T. Assessment of electron mobility in ultrathin-body InGaAs-on-insulator MOSFETs using physics-based modeling. IEEE Trans. Electron Devices 59, 1636–1643 (2012). 

25. Chhowalla, M., Jena, D. & Zhang, H. Two-dimensional semiconductors for transistors. Nat. Rev. Mater. 1, 16052 (2016). 

26. Li, L. et al. Black phosphorus field-effect transistors. Nat. Nanotechnol. 9, 372–377 (2014). 

27. Liu, H. et al. Phosphorene: An unexplored 2D semiconductor with a high hole mobility. ACS Nano 8, 4033–4041 (2014). 

28. Mounet, N. et al. Two-dimensional materials from high-throughput computational exfoliation of experimentally known compounds. Nat. Nanotechnol. 13, 246–252 (2018). 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2022) 51 

X. Huang et al. 

17 



29. Hu, W. et al. Ambipolar 2D semiconductors and emerging device applications. Small Methods 5, e2000837 (2021). 

30. Zhao, W. et al. Evolution of electronic structure in atomically thin sheets of WS2 and WSe2. ACS Nano 7, 791–797 (2013). 

31. Liu, H., Neal, A. T. & Ye, P. D. Channel length scaling of MoS2 MOSFETs. ACS Nano 6, 8563–8569 (2012). 

32. Zhang, F. & Appenzeller, J. Tunability of short-channel effects in MoS2 fieldeffect devices. Nano Lett. 15, 301–306 (2015). 

33. Desai Sujay, B. et al. MoS2 transistors with 1-nanometer gate lengths. Science 354, 99–102 (2016). 

34. Xie, L. et al. Graphene-contacted ultrashort channel monolayer MoS2 transistors. Adv. Mater. 29, 1702522 (2017). 

35. Auth, C. et al. A 10 nm high performance and low-power CMOS technology featuring 3rd generation FinFET transistors, Self-Aligned Quad Patterning, contact over active gate and cobalt local interconnects. In Proc. 2017 IEEE International Electron Devices Meeting (IEDM), 29.21.21–29.21.24 (IEEE, 2017). 

36. Shen, P. C. et al. Ultralow contact resistance between semimetal and monolayer semiconductors. Nature 593, 211–217 (2021). 

37. Arutchelvan, G. et al. Impact of device scaling on the electrical properties of MoS2 field-effect transistors. Sci. Rep. 11, 6610 (2021). 

38. Chen, M. C. et al. TMD FinFET with 4 nm thin body and back gate control for future low power technology. In Proc. 2015 IEEE International Electron Devices Meeting (IEDM), 32.32.31–32.32.34 (IEEE, 2015). 

39. Huang, X. et al. Ultrathin multibridge channel transistor enabled by van der Waals assembly. Adv. Mater. 33, e2102201 (2021). 

40. Bae, G. et al. 3 nm GAA Technology featuring multi-bridge-channel FET for low power and high performance applications. In Proc. 2018 IEEE International Electron Devices Meeting (IEDM), 28.27.21–28.27.24 (IEEE, 2018). 

41. Xiong, X. et al. Demonstration of vertically-stacked CVD monolayer channels: MoS2 nanosheets GAA-FET with Ion > 700 µA/µm and MoS2/WSe2 CFET. In Proc. 2021 IEEE International Electron Devices Meeting (IEDM), 7.5.1–7.5.4 (IEEE, 2021). 

42. Su, S.-K. et al. Layered semiconducting 2D materials for future transistor applications. Small Struct. 2, 2000103 (2021). 

43. Lundstrom, M. Fundamentals of Nanotransistors Vol. 6 (World Scientific, 2013). 

44. Hiblot, G., Rafhay, Q., Boeuf, F. & Ghibaudo, G. Analytical relationship between subthreshold swing of thermionic and tunnelling currents. Electron. Lett. 50, 1745–1747 (2014). 

45. Jin, Z., Li, X., Mullen, J. T. & Kim, K. W. Intrinsic transport properties of electrons and holes in monolayer transition-metal dichalcogenides. Phys. Rev. B 90, 045422 (2014). 

46. Ling, X., Wang, H., Huang, S., Xia, F. & Dresselhaus, M. S. The renaissance of black phosphorus. Proc. Natl Acad. Sci. USA 112, 4523–4530 (2015). 

47. Kaasbjerg, K., Thygesen, K. S. & Jacobsen, K. W. Phonon-limited mobility inn-type single-layer MoS2 from first principles. Phys. Rev. B 85, 115317 (2012). 

48. Ma, N. & Jena, D. Charge scattering and mobility in atomically thin semiconductors. Phys. Rev. X 4, 011043 (2014). 

49. Schmidt, H. et al. Transport properties of monolayer MoS2 grown by chemical vapor deposition. Nano Lett. 14, 1909–1913 (2014). 

50. Cui, X. et al. Multi-terminal transport measurements of MoS2 using a van der Waals heterostructure device platform. Nat. Nanotechnol. 10, 534–540 (2015). 

51. Razavieh, A., Zeitzoff, P. & Nowak, E. J. Challenges and limitations of CMOS scaling for FinFET and beyond architectures. IEEE Trans. Nanotechnol. 18, 999–1004 (2019). 

52. Allain, A., Kang, J., Banerjee, K. & Kis, A. Electrical contacts to two-dimensional semiconductors. Nat. Mater. 14, 1195–1205 (2015). 

53. Schulman, D. S., Arnold, A. J. & Das, S. Contact engineering for 2D materials and devices. Chem. Soc. Rev. 47, 3037–3058 (2018). 

54. Wang, Y. & Chhowalla, M. Making clean electrical contacts on 2D transition metal dichalcogenides. Nat. Rev. Phys. 4, 101–112 (2021). 

55. Tung, R. T. The physics and chemistry of the Schottky barrier height. Appl. Phys. Rev. 1, 011304 (2014). 

56. Sotthewes, K. et al. Universal Fermi-level pinning in transition-metal dichalcogenides. J. Phys. Chem. C 123, 5411–5420 (2019). 

57. Gong, C. et al. Band alignment of two-dimensional transition metal dichalcogenides: Application in tunnel field effect transistors. Appl. Phys. Lett. 103, 053513 (2013). 

58. Feng, Q., Yan, F., Luo, W. & Wang, K. Charge trap memory based on few-layer black phosphorus. Nanoscale 8, 2686–2692 (2016). 

59. Kim, C. et al. Fermi level pinning at electrical metal contacts of monolayer molybdenum dichalcogenides. ACS Nano 11, 1588–1596 (2017). 

60. Morkoç, H. et al. Large‐band‐gap SiC, III–V nitride, and II–VI ZnSe‐based semiconductor device technologies. J. Appl. Phys. 76, 1363–1398 (1994). 

61. Rai, A. et al. Progress in contact, doping and mobility engineering of MoS2: An atomically thin 2D semiconductor. Crystals 8, 316 (2018). 

62. Jaiswal, H. N. et al. Diode-like selective enhancement of carrier transport through metal-semiconductor interface decorated by monolayer boron nitride. Adv. Mater. 32, e2002716 (2020). 

63. Wang, J. et al. High mobility MoS2 transistor with low Schottky barrier contact by using atomic thick h-BN as a tunneling layer. Adv. Mater. 28, 8302–8308 (2016). 

64. Liu, Y. et al. Approaching the Schottky–Mott limit in van der Waals metalsemiconductor junctions. Nature 557, 696–700 (2018). 

65. Wang, Y. et al. Van der Waals contacts between three-dimensional metals and two-dimensional semiconductors. Nature 568, 70–74 (2019). 

66. Brien, K. P. O. et al. Advancing 2D monolayer CMOS through contact, channel and interface engineering. In Proc. 2021 IEEE International Electron Devices Meeting (IEDM), 7.1.1–7.1.4 (IEEE, 2021). 

67. Chou, A. S. et al. Antimony semimetal contact with enhanced thermal stability for high performance 2D electronics. In Proc. 2021 IEEE International Electron Devices Meeting (IEDM), 7.2.1–7.2.4 (IEEE, 2021). 

68. Szabó, Á., Jain, A., Parzefall, M., Novotny, L. & Luisier, M. Electron transport through Metal/MoS2 interfaces: Edge- or area-dependent process? Nano Lett. 19, 3641–3647 (2019). 

69. Cheng, Z. et al. Immunity to contact scaling in MoS2 transistors using in situ edge contacts. Nano Lett. 19, 5077–5085 (2019). 

70. McDonnell, S. et al. HfO2 on MoS2 by atomic layer deposition: Adsorption mechanisms and thickness scalability. ACS Nano 7, 10354–10361 (2013). 

71. Knobloch, T. et al. The performance limits of hexagonal boron nitride as an insulator for scaled CMOS devices based on two-dimensional materials. Nat. Electron. 4, 98–108 (2021). 

72. Zou, X. et al. Interface engineering for high-performance top-gated MoS2 fieldeffect transistors. Adv. Mater. 26, 6255–6261 (2014). 

73. Li, W. et al. Uniform and ultrathin high-κ gate dielectrics for two-dimensional electronic devices. Nat. Electron. 2, 563–571 (2019). 

74. Yu, Z. et al. Reliability of ultrathin high-κ dielectrics on chemical-vapor deposited 2D semiconductors. In Proc. 2020 IEEE International Electron Devices Meeting (IEDM), 3.2.1–3.3.4 (IEEE, 2020). 

75. Li, T. et al. A native oxide high-κ gate dielectric for two-dimensional electronics. Nat. Electron. 3, 473–478 (2020). 

76. Zou, X. et al. Damage-free mica/MoS2 interface for high-performance multilayer MoS2 field-effect transistors. Nanotechnology 30, 345204 (2019). 

77. Vexler, M. I. et al. Electrical characterization and modeling of the Au/CaF2/ nSi(111) structures with high-quality tunnel-thin fluoride layer. J. Appl. Phys. 105, 083716 (2009). 

78. Sarkar, D. et al. A subthermionic tunnel field-effect transistor with an atomically thin channel. Nature 526, 91–95 (2015). 

79. Si, M. et al. Steep-slope hysteresis-free negative capacitance MoS2 transistors. Nat. Nanotechnol. 13, 24–28 (2018). 

80. Yu, Z. et al. Negative capacitance 2D MoS2 transistors with sub-60 mV/dec subthreshold swing over 6 orders, 250 μA/μm current density, and nearlyhysteresis-free. In Proc. 2017 IEEE International Electron Devices Meeting (IEDM), 23.26.21–23.26.24 (IEEE, 2017). 

81. Khan, A. I., Yeung, C. W., Chenming, H. & Salahuddin, S. Ferroelectric negative capacitance MOSFET: Capacitance tuning & antiferroelectric operation. In Proc. 2011 International Electron Devices Meeting, 11.13.11–11.13.14 (IEEE, 2011). 

82. Qiu, C. et al. Dirac-source field-effect transistors as energy-efficient, highperformance electronic switches. Science 361, 387–392 (2018). 

83. Tang, Z. et al. A steep-slope MoS2/graphene Dirac-source field-effect transistor with a large drive current. Nano Lett. 21, 1758–1764 (2021). 

84. Liu, C. et al. Small footprint transistor architecture for photoswitching logic and in situ memory. Nat. Nanotechnol. 14, 662–667 (2019). 

85. Chen, H. et al. Logic gates based on neuristors made from two-dimensional materials. Nat. Electron. 4, 399–404 (2021). 

86. Resta, G. V. et al. Doping-free complementary logic gates enabled by twodimensional polarity-controllable transistors. ACS Nano 12, 7039–7047 (2018). 

87. Lee, S.-J. et al. Programmable devices based on reversible solid-state doping of two-dimensional semiconductors with superionic silver iodide. Nat. Electron. 3, 630–637 (2020). 

88. Shim, J. et al. Light-triggered ternary device and inverter based on heterojunction of van der Waals materials. ACS Nano 11, 6319–6327 (2017). 

89. Shim, J. et al. Phosphorene/rhenium disulfide heterojunction-based negative differential resistance device for multi-valued logic. Nat. Commun. 7, 13413 (2016). 

90. Choi, W. et al. Dynamic oscillation via negative differential resistance in type III junction organic/two‐dimensional and oxide/two‐dimensional transition metal dichalcogenide diodes. Adv. Funct. Mater. 31, 2009436 (2020). 

91. Park, S. et al. Quaternary NAND logic and complementary ternary inverter with p‐MoTe2/n‐MoS2 heterostack channel transistors. Adv. Funct. Mater. 32, 2108737 (2021). 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2022) 51 

X. Huang et al. 

18 



92. Huang, M. et al. Multifunctional high-performance van der Waals heterostructures. Nat. Nanotechnol. 12, 1148–1154 (2017). 

93. Kim, J. et al. Area-selective chemical doping on solution-processed MoS2 thin-film for multi-valued logic gates. Nano Lett. 22, 570–577 (2022). 

94. Bertolazzi, S., Krasnozhon, D. & Kis, A. Nonvolatile memory cells based on MoS2/ graphene heterostructures. ACS Nano 7, 3246–3252 (2013). 

95. Vu, Q. A. et al. Two-terminal floating-gate memory with van der Waals heterostructures for ultrahigh on/off ratio. Nat. Commun. 7, 12725 (2016). 

96. Zhang, E. et al. Tunable charge-trap memory based on few-layer MoS2. ACS Nano 9, 612–619 (2015). 

97. Wen, J. et al. Direct charge trapping multilevel memory with graphdiyne/MoS2 van der Waals heterostructure. Adv. Sci. 8, e2101417 (2021). 

98. Luo, Z. D., Yang, M. M., Liu, Y. & Alexe, M. Emerging opportunities for 2D semiconductor/ferroelectric transistor-structure devices. Adv. Mater. 33, e2005620 (2021). 

99. Gao, J. et al. Multifunctional MoTe2 Fe‐FET enabled by ferroelectric polarization‐ assisted charge trapping. Adv. Funct. Mater. 32, 2110415 (2022). 

100. Wang, X. et al. Ferroelectric FET for nonvolatile memory application with twodimensional MoSe2 channels. 2D Mater. 4, 025036 (2017). 

101. Hong, S. et al. Complementary type ferroelectric memory transistor circuits with P‐ and N‐channel MoTe2. Adv. Electron. Mater. 6, 2000479 (2020). 

102. Lee, Y. T. et al. Nonvolatile ferroelectric memory circuit using black phosphorus nanosheet-based field-effect transistors with P(VDF-TrFE) polymer. ACS Nano 9, 10394–10401 (2015). 

103. Yap, W. C., Jiang, H., Liu, J., Xia, Q. & Zhu, W. Ferroelectric transistors with monolayer molybdenum disulfide and ultra-thin aluminum-doped hafnium oxide. Appl. Phys. Lett. 111, 013103 (2017). 

104. Mikolajick, T., Schroeder, U. & Slesazeck, S. The past, the present, and the future of ferroelectric memories. IEEE Trans. Electron Devices 67, 1434–1443 (2020). 

105. Chen, L. et al. A van der Waals synaptic transistor based on ferroelectric Hf0.5Zr0.5O2 and 2D tungsten disulfide. Adv. Electron. Mater. 6, 2000057 (2020). 

106. Kobayashi, T., Hori, N., Nakajima, T. & Kawae, T. Electrical characteristics of MoS2 field-effect transistor with ferroelectric vinylidene fluoride-trifluoroethylene copolymer gate structure. Appl. Phys. Lett. 108, 132903 (2016). 

107. Cho, Y. et al. Nanowatt use 8 V switching nonvolatile memory transistors with 2D MoTe2 channel and ferroelectric P(VDF-TrFE). Nano Energy 81, 105686 (2021). 

108. Liu, X. et al. Post-CMOS compatible aluminum scandium nitride/2D channel ferroelectric field-effect-transistor memory. Nano Lett. 21, 3753–3761 (2021). 

109. Ma, T. P. & Jin-Ping, H. Why is nonvolatile ferroelectric memory field-effect transistor still elusive? IEEE Electron Device Lett. 23, 386–388 (2002). 

110. Si, M. et al. A ferroelectric semiconductor field-effect transistor. Nat. Electron. 2, 580–586 (2019). 

111. Wang, S. et al. Two-dimensional ferroelectric channel transistors integrating ultra-fast memory and neural computing. Nat. Commun. 12, 53 (2021). 

112. Liu, C. et al. A semi-floating gate memory based on van der Waals heterostructures for quasi-non-volatile applications. Nat. Nanotechnol. 13, 404–410 (2018). 

113. Li, J. et al. Symmetric ultrafast writing and erasing speeds in quasi-nonvolatile memory via van der Waals heterostructures. Adv. Mater. 31, e1808035 (2019). 

114. Wu, G. et al. Programmable transition metal dichalcogenide homojunctions controlled by nonvolatile ferroelectric domains. Nat. Electron. 3, 43–50 (2020). 

115. Ding, Y. et al. A semi‐floating memory with 535% enhancement of refresh time by local field modulation. Adv. Funct. Mater. 30, 1908089 (2020). 

116. Lee, C. W., Suh, J. M. & Jang, H. W. Chemical sensors based on two-dimensional (2D) materials for selective detection of ions and molecules in liquid. Front. Chem. 7, 708 (2019). 

117. Mao, S. et al. Two-dimensional nanomaterial-based field-effect transistors for chemical and biological sensing. Chem. Soc. Rev. 46, 6872–6904 (2017). 

118. Park, H.-Y. et al. n- and p-Type doping phenomenon by artificial DNA and M-DNA on two-dimensional transition metal dichalcogenides. ACS Nano 8, 11603–11613 (2014). 

119. Majd, S. M., Salimi, A. & Ghasemi, F. An ultrasensitive detection of miRNA-155 in breast cancer via direct hybridization assay using two-dimensional molybdenum disulfide field-effect transistor biosensor. Biosens. Bioelectron. 105, 6–13 (2018). 

120. Park, H. et al. Label-free and recalibrated multilayer MoS2 biosensor for point-ofcare diagnostics. ACS Appl. Mater. Interfaces 9, 43490–43497 (2017). 

121. Dalila, R. N., Md Arshad, M. K., Gopinath, S. C. B., Norhaimi, W. M. W. & Fathil, M. F. M. Current and future envision on developing biosensors aided by 2D molybdenum disulfide (MoS2) productions. Biosens. Bioelectron. 132, 248–264 (2019). 

122. Oh, S. H. et al. Nanophotonic biosensors harnessing van der Waals materials. Nat. Commun. 12, 3824 (2021). 

123. Meng, Z., Stolz, R. M., Mendecki, L. & Mirica, K. A. Electrically-transduced chemical sensors based on two-dimensional nanomaterials. Chem. Rev. 119, 478–598 (2019). 

124. Lin, M. et al. Programmable engineering of a biosensing interface with tetrahedral DNA nanostructures for ultrasensitive DNA detection. Angew. Chem. -Int. Ed. 54, 2151–2155 (2015). 

125. Zhang, Y. et al. DNA-based functionalization of two-dimensional MoS2 FET biosensor for ultrasensitive detection of PSA. Appl. Surf. Sci. 548, 149169 (2021). 

126. Parlak, O., Incel, A., Uzun, L., Turner, A. P. F. & Tiwari, A. Structuring Au nanoparticles on two-dimensional MoS2 nanosheets for electrochemical glucose biosensors. Biosens. Bioelectron. 89, 545–550 (2017). 

127. Zhang, Y. et al. Bio-separated and gate-free 2D MoS2 biosensor array for ultrasensitive detection of BRCA1. Nanomaterials 11, 545 (2021). 

128. Huang, Y.-C. et al. Sensitive pressure sensors based on conductive microstructured air-gap gates and two-dimensional semiconductor transistors. Nat. Electron. 3, 59–69 (2020). 

129. Yang, S., Jiang, C. & Wei, S.-H. Gas sensing in 2D materials. Appl. Phys. Rev. 4, 021304 (2017). 

130. Qin, Z. et al. Effect of layer number on recovery rate of WS2 nanosheets for ammonia detection at room temperature. Appl. Surf. Sci. 414, 244–250 (2017). 

131. Zhao, S., Xue, J. & Kang, W. Gas adsorption on MoS2 monolayer from firstprinciples calculations. Chem. Phys. Lett. 595–596, 35–42 (2014). 

132. Sharma, M., Jamdagni, P., Kumar, A. & Ahluwalia, P. K. Interactions of gas molecules with monolayer MoSe2: A first principle study. AIP Conf. Proc. 1731, 140045 (2016). 

133. Bui, V. Q., Pham, T. T., Le, D. A., Thi, C. M. & Le, H. M. A first-principles investigation of various gas (CO, H2O, NO, and O2) absorptions on a WS2 monolayer: Stability and electronic properties. J. Phys. Condens. Matter 27, 305005 (2015). 

134. Hong, Y. et al. Gas-sensing characteristics of exfoliated WSe2 field-effect transistors. J. Nanosci. Nanotechnol. 17, 3151–3154 (2017). 

135. Yang, A. et al. Humidity sensing using vertically oriented arrays of ReS2 nanosheets deposited on an interdigitated gold electrode. 2D Mater. 3, 045012 (2016). 

136. Xiong, Y. et al. Ultra-sensitive NH3 sensor based on flower-shaped SnS2 nanostructures with sub-ppm detection ability. J. Hazard. Mater. 341, 159–167 (2018). 

137. Chen, H. et al. Suspended SnS2 layers by light assistance for ultrasensitive ammonia detection at room temperature. Adv. Funct. Mater. 28, 1801035 (2018). 

138. Long, M., Wang, P., Fang, H. & Hu, W. Progress, challenges, and opportunities for 2D material based photodetectors. Adv. Funct. Mater. 29, 1803807 (2018). 

139. Tu, L. et al. Ultrasensitive negative capacitance phototransistors. Nat. Commun. 11, 101 (2020). 

140. Chen, Y. et al. Unipolar barrier photodetectors based on van der Waals heterostructures. Nat. Electron. 4, 357–363 (2021). 

141. Lopez-Sanchez, O., Lembke, D., Kayci, M., Radenovic, A. & Kis, A. Ultrasensitive photodetectors based on monolayer MoS2. Nat. Nanotechnol. 8, 497–501 (2013). 

142. Shim, J. et al. High-performance 2D rhenium disulfide (ReS2) transistors and photodetectors by oxygen plasma treatment. Adv. Mater. 28, 6985–6992 (2016). 

143. Long, M. et al. Broadband photovoltaic detectors based on an atomically thin heterostructure. Nano Lett. 16, 2254–2259 (2016). 

144. Gao, A. et al. Observation of ballistic avalanche phenomena in nanoscale vertical InSe/BP heterostructures. Nat. Nanotechnol. 14, 217–222 (2019). 

145. Zhang, K. et al. Interlayer transition and infrared photodetection in atomically thin type-II MoTe2/MoS2 van der Waals heterostructures. ACS Nano 10, 3852–3858 (2016). 

146. Wang, H. et al. Integrated circuits based on bilayer MoS(2) transistors. Nano Lett. 12, 4674–4680 (2012). 

147. Kang, K. et al. High-mobility three-atom-thick semiconducting films with waferscale homogeneity. Nature 520, 656–660 (2015). 

148. Yu, L. et al. Design, modeling, and fabrication of chemical vapor deposition grown MoS2 circuits with E-mode FETs for large-area electronics. Nano Lett. 16, 6349–6356 (2016). 

149. Lin, Z. et al. Solution-processable 2D semiconductors for high-performance large-area electronics. Nature 562, 254–258 (2018). 

150. Li, T. et al. Epitaxial growth of wafer-scale molybdenum disulfide semiconductor single crystals on sapphire. Nat. Nanotechnol. 16, 1201–1207 (2021). 

151. Smets, Q. et al. Ultra-scaled MOCVD MoS2 MOSFETs with 42 nm contact pitch and 250 µA/µm drain current. In Proc. 2019 IEEE International Electron Devices Meeting (IEDM), 23.22.21–23.22.24 (IEEE, 2019). 

152. Cheng, C. C. et al. First demonstration of 40-nm channel length top-gate WS2 pFET using channel area-selective CVD growth directly on SiOx/Si substrate. In Proc. 2019 Symposium on VLSI Technology T244–T245 (IEEE, 2019). 

153. Dorow, C. J. et al. Advancing monolayer 2D NMOS and PMOS transistor integration from growth to van der Waals interface engineering for ultimate CMOS scaling. In Proc. 2021 Symposium on VLSI Technology, 1–2 (IEEE, 2021). 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2022) 51 

X. Huang et al. 

19 



154. Li, J. et al. General synthesis of two-dimensional van der Waals heterostructure arrays. Nature 579, 368–374 (2020). 

155. Chen, X. et al. Wafer-scale functional circuits based on two dimensional semiconductors with fabrication optimized by machine learning. Nat. Commun. 12, 5953 (2021). 

156. Wachter, S., Polyushkin, D. K., Bethge, O. & Mueller, T. A microprocessor based on a two-dimensional semiconductor. Nat. Commun. 8, 14948 (2017). 

## ACKNOWLEDGEMENTS 

This work was supported by the National Key Research and Development Program of China(2021YFA1200500) and National Natural Science Foundation of China (61925402, 62090032, and 62004040), Science and Technology Commission of Shanghai Municipality(19JC1416600), Shanghai Pilot Program for Basic Research - FuDan University 21TQ1400100 (21TQ011), and the young scientist project of MOE innovation platform. 

157. Polyushkin, D. K. et al. Analogue two-dimensional semiconductor electronics. Nat. Electron. 3, 486–491 (2020). 

158. Zeng, S. et al. An application-specific image processing array based on WSe2 transistors with electrically switchable logic functions. Nat. Commun. 13, 56 (2022). 

159. Daus, A. et al. High-performance flexible nanoscale transistors based on transition metal dichalcogenides. Nat. Electron. 4, 495–501 (2021). 

160. Li, N. et al. Large-scale flexible and transparent electronics based on monolayer molybdenum disulfide field-effect transistors. Nat. Electron. 3, 711–717 (2020). 

161. Meng, W. et al. Three-dimensional monolithic micro-LED display driven by atomically thin transistor matrix. Nat. Nanotechnol. 16, 1231–1236 (2021). 

162. Wang, Y. et al. Band‐tailored van der Waals heterostructure for multilevel memory and artificial synapse. InfoMat 3, 917–928 (2021). 

163. Zhou, Y. A reconfigurable two-WSe2-transistor synaptic cell for reinforcement learning. Adv. Mater. 34, e2107754 (2022). 

164. Tang, J. et al. A reliable all‐2D materials artificial synapse for high energy‐efficient neuromorphic computing. Adv. Funct. Mater. 31, 2011083 (2021). 

165. Xiang, D., Liu, T., Zhang, X., Zhou, P. & Chen, W. Dielectric rngineered twodimensional neuromorphic transistors. Nano Lett. 21, 3557–3565 (2021). 

166. Ielmini, D. & Wong, H. S. P. In-memory computing with resistive switching devices. Nat. Electron. 1, 333–343 (2018). 

## AUTHOR CONTRIBUTIONS 

C.L. and P.Z. directed and supervised the project; X.H. drafted the manuscript with input from C.L. and P.Z.; all authors contributed to the discussion and revision of the manuscript at all stages. 

## COMPETING INTERESTS 

The authors declare no competing interests. 

## ADDITIONAL INFORMATION 

Correspondence and requests for materials should be addressed to Chunsen Liu or Peng Zhou. 

Reprints and permission information is available at http://www.nature.com/ reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

167. Wang, X. et al. Van der Waals engineering of ferroelectric heterostructures for long-retention memory. Nat. Commun. 12, 1109 (2021). 

168. Tong, L. et al. 2D materials-based homogeneous transistor-memory architecture for neuromorphic hardware. Science 373, 1353–1358 (2021). 

169. Hong, S. et al. Highly sensitive active pixel image sensor array driven by largearea bilayer MoS2 transistor circuitry. Nat. Commun. 12, 3559 (2021). 

170. Yang, C. C. et al. Ultrahigh responsivity and tunable photogain BEOL compatible MoS2 phototransistor array for monolithic 3D image sensor with blocklevel sensing circuits. In Proc. 2020 IEEE Symposium on VLSI Technology, 1–2 (IEEE, 2020). 

171. Mennel, L. et al. Ultrafast machine vision with 2D material neural network image sensors. Nature 579, 62–66 (2020). 

172. Choi, C. et al. Curved neuromorphic image sensor array using a MoS2-organic heterostructure inspired by the human visual recognition system. Nat. Commun. 11, 5934 (2020). 

173. Zhang, Z. et al. All-in-one two-dimensional retinomorphic hardware device for motion detection and recognition. Nat. Nanotechnol. 17, 27–32 (2022). 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http:// creativecommons.org/licenses/by/4.0/. 

© The Author(s) 2022 

Published in partnership with FCT NOVA with the support of E-MRS 

npj 2D Materials and Applications (2022) 51 

