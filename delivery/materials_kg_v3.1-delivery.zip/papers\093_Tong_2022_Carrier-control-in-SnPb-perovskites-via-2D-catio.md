# Carrier control in Sn–Pb perovskites via 2D cation engineering for all-perovskite tandem solar cells with improved efficiency and stability

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Energy |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 234 |
| 作者 | Jinhui Tong, Qi Jiang, A. Ferguson, A. Palmstrom, Xiao-Ming Wang, Ji Hao, Sean P. Dunfield, Amy E. Louks et al. |
| DOI | 10.1038/s41560-022-01046-1 |
| 源文件 | 093_Tong_2022_Carrier-control-in-SnPb-perovskites-via-2D-catio.pdf |

---
# **Carrier control in Sn–Pb perovskites via 2D cation engineering for allperovskite tandem solar cells with improved efficiency and stability** 

Jinhui Tong,<sup>1†*</sup> Qi Jiang,<sup>1†</sup> Andrew J. Ferguson,<sup>1</sup> Axel F. Palmstrom,<sup>2</sup> Xiaoming Wang,<sup>7</sup> Ji Hao,<sup>1</sup> Sean P. Dunfield,<sup>2,3,4</sup> Amy E. Louks,<sup>2</sup> Steven P. Harvey,<sup>2</sup> Chongwen Li,<sup>7</sup> Haipeng Lu,<sup>1</sup> Ryan M. France,<sup>1</sup> Samuel A. Johnson,<sup>3</sup> Fei Zhang,<sup>1</sup> Mengjin Yang,<sup>2</sup> John F. Geisz,<sup>1</sup> Michael D. McGehee,<sup>1,3,4,5</sup> Matthew C. Beard,<sup>1,4</sup> Yanfa Yan<sup>7</sup> , Darius Kuciauskas,<sup>1</sup> Joseph J. Berry,<sup>2,4,6</sup> Kai Zhu<sup>1*</sup> 

- 1 Chemistry and Nanoscience Center, National Renewable Energy Laboratory, Golden, CO 80401, USA 

- 2 Materials Science Center, National Renewable Energy Laboratory, Golden, CO 80401, USA 

- 3 Materials Science and Engineering Program, University of Colorado, Boulder, CO 80309, USA. 

- 4 Renewable and Sustainable Energy Institute, University of Colorado, Boulder, CO 80309, USA. 

- 5 Department of Chemical and Biological Engineering, University of Colorado, Boulder, CO 80309, USA. 

- 6 Department of Physics, University of Colorado, Boulder, CO 80309, USA. 

- 7 Department of Physics and Astronomy and Wright Center for Photovoltaics Innovation and Commercialization, University of Toledo, Toledo, OH 43606, USA. 

- Corresponding authors. Jinhui.Tong@nrel.gov (J.T.) and Kai.Zhu@nrel.gov (K.Z.) 

- These two authors contributed equally to this work. 

1 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

## **Abstract** 

All-perovskite tandem solar cells are promising for achieving photovoltaics with power conversion efficiencies above the detailed balance limit of single-junction cells, while retaining the low-cost, light weight and other advantages associated with metal halide perovskite photovoltaics. However, the efficiency and stability of all-perovskite tandem cells are limited by the Sn-Pb-based narrowbandgap perovskite cells. Here we show that the formation of quasi-2D structure (PEA)2GAPb2I7 from additives based on mixed bulky organic cations phenethylammonium (PEA<sup>+</sup> ) and guanidinium (GA<sup>+</sup> ) provides critical defect control to significantly improve the structural and optoelectronic properties of the narrow-bandgap (1.25-eV) Sn-Pb perovskite thin films. This new 2D additive engineering results in Sn-Pb based absorbers with unprecedented low dark carrier density (~1.3  10<sup>14</sup> cm<sup>-3</sup> ), long bulk carrier lifetime (~9.2  s), and low surface recombination velocity (~1.4 cm/s), leading to 22.1%-efficient single-junction Sn-Pb perovskite cells and 25.5%efficient all-perovskite 2-terminal tandems with high photovoltage and long operational stability. 

2 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

An effective way to improve solar cell efficiency is to employ tandem structures, which can improve the utilization of the solar spectrum to reduce thermalization and transmission losses<sup>1-4</sup> . Metal halide perovskites have been widely applied in tandem solar cells due to their high absorption coefficient, small Urbach energy and continuous tunable band gap<sup>5-9</sup> . The idea of allperovskite tandem photovoltaics is particularly appealing, as these thin-film tandems offer high efficiency and low weight combined with low cost and scalable fabrication processes<sup>10</sup> . At present, the main challenge in all-perovskite tandem solar cells is the effective use of Sn-Pb-based narrowbandgap perovskite solar cells (PSCs). There are two main challenges in fabricating efficient and stable Sn-Pb PSCs. First, Sn<sup>2+</sup> can be oxidized to Sn<sup>4+</sup> during and after Sn-containing perovskite processing<sup>11, 12</sup> , which dopes Sn-Pb perovskites p-type, eventually leading to a high background (dark) carrier density that renders them poor photovoltaic (PV) materials<sup>13, 14</sup> . Second, the nonuniform nucleation and fast crystallization of Sn-containing perovskites make it more challenging to fabricate high-quality, dense, and compact Sn-Pb perovskite films<sup>15</sup> . The defective grain boundaries/surfaces can exacerbate the Sn<sup>2+</sup> -Sn<sup>4+</sup> issue<sup>16</sup> . These challenges often result in large voltage loss and poor stability of Sn-Pb based PSCs. 

To address these issues, many research efforts have been devoted to optimizing the processing condition, tuning the composition, and using additives, including those that facilitate 2D perovskite structures, to improve the quality of Sn-Pb perovskite thin films<sup>17-21</sup> . Most of these recent efforts have resulted in markedly reduced dark carrier/defect densities (ranging from about 10<sup>15</sup> cm<sup>−3</sup> to 10<sup>16</sup> cm<sup>−317-20, 22, 23</sup> ) along with increased carrier lifetimes (ranging from a few hundred nanosecond to over one microsecond<sup>17, 20, 21, 23, 24</sup> ), leading to multiple demonstrations of >20% Sn-Pb PSCs<sup>17-24</sup> . Despite these recent rapid advances, the stability and efficiency of SnPb PSCs are still inferior to their pure Pb counterpart, limiting the performance of all-perovskite tandem cells. 

In this study, we report a new 2D additive approach to improve the narrow-bandgap (1.25 eV) Sn-Pb perovskite based on (FASnI3)0.6(MAPbI3)0.4 (or FA0.6MA0.4Sn0.6Pb0.4I3, where FA is formamidinium and MA is methylammonium)<sup>17, 25</sup> . A combination of phenethylammonium iodide (PEAI) and guanidinium thiocyanate (GASCN) additives is found to significantly improve the quality of the Sn-Pb perovskite thin films, resulting in low background carrier density (~10<sup>14</sup> cm<sup>−3</sup> ) and long bulk carrier lifetime (~9  s). The formation of quasi-2D (PEA)2GAPb2I7 from the mixedcation additives was found critical to the improved optoelectronic properties. With this new 

3 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

additive approach, we demonstrate ~22.1%-efficient narrow-bandgap Sn-Pb PSCs with an opencircuit voltage (Voc) > 0.91 V. We combine the efficient single-junction narrow-bandgap cell with a 1.75-eV bandgap perovskite to make 2-terminal tandem solar cells with a PCE of ~25.5% and Voc > 2.1 V. Moreover, we show that the Sn-Pb narrow-bandgap and all-perovskite tandem devices are stable, retaining about 82% and 80% of their respective maximum PCEs after 1830 h and 1500 h, respectively, under continuous operation in N2 (ISOS-L-1 conditions<sup>26</sup> ). 



**Fig. 1. Charge carrier dynamics. a** , Time-resolved photoluminescence (TRPL) measurement on ~800-nm-thick narrow-bandgap perovskite film prepared with the PEAI-GASCN additives under different excitation intensities (injection levels). **b** , TRPL measurements of perovskite films with thickness varying from 200 to 800 nm. **c** , Thickness dependence of the TRPL lifetime with analysis to extract the bulk carrier lifetime and the surface recombination velocity. **d** , Temperature dependence of recombination rate (or lifetime<sup>−1</sup> ) from TRPL measurement. _T_ is the temperature, _E_ a is the activation energy associated with shallow traps, and _k_ is Boltzmann’s constant. The laser excitation wavelength was 640 nm. 

## **Optoelectronic properties of Sn-Pb perovskites** 

We conducted a set of time-resolved photoluminescence (TRPL) measurements to examine the charge recombination kinetics in (FASnI3)0.6(MAPbI3)0.4 perovskite thin films on glass substrates 

4 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

prepared using a combination of 2% PEAI and 7% GASCN relative to the amount of MA<sup>+</sup> in precursor. Using these additives did not affect the bandgap (~1.25 eV; Supplementary Fig. 1) or crystal structure (Supplementary Fig. 2). We have previously shown that using 7% GASCN additive can significantly enhance the carrier lifetime from less than 200 ns to above 1  s<sup>17</sup> . Here, we found that by using mixed PEAI-GASCN additives the carrier lifetime is further increased by almost another order of magnitude. Figure 1a shows the TRPL decay at various excitation intensities (injection levels). The effective average carrier lifetime is increased from about 2.5 to 7  s when the injection density is decreased from 7.2  10<sup>15</sup> to ~3–6  10<sup>14</sup> cm<sup>−3</sup> pulse<sup>−1</sup> . Next, we examined the thickness dependence of TRPL decay kinetics to separate the contributions from the bulk and surface effects on charge carrier recombination. Figure 1b shows the TRPL decay for perovskite films with varying thickness from 200 nm to 800 nm with injection fixed at about 6  10<sup>14</sup> cm<sup>−3</sup> pulse<sup>−1</sup> . The TRPL decay becomes faster with reduced film thickness, suggesting that surface recombination has a non-negligible impact on carrier recombination. In general, the measured TRPL lifetime (𝜏TRPL) can be related to the bulk recombination lifetime (𝜏b) and surface recombination velocity (𝑆) by the following equation based on a simple double-heterostructure model<sup>27</sup> , 



<!-- Start of picture text -->
1 1 2𝑆<br>=  + (1)<br>𝜏TRPL 𝜏b 𝑑<br><!-- End of picture text -->

where 𝑑 is the film thickness. Analyzing the thickness dependent TRPL results (Figure 1c) using Eq. 1 yielded remarkable 𝜏b of ~9.2  s and low 𝑆 of ~1.4 cm/s. The low value of _S_ corresponds to a ‘lifetime’ for surface recombination of about 30  s for an 800-nm-thick absorber layer, suggesting that for the Sn-Pb perovskite in this study charge recombination is primarily determined by recombination processes in the bulk. It should be noted that this is resulting from our additive approach that renders a good perovskite surface with a low surface recombination velocity. 

The bulk lifetime 𝜏b is affected by defect-mediated recombination and radiative recombination. The lifetime for radiative recombination is given by  rad = ( _BN_ A)<sup>−1</sup> , where the radiative recombination coefficient _B_ is about (0.6–2)  10<sup>−10</sup> cm<sup>3</sup> /s<sup>27</sup> and _N_ A is the dark carrier (hole) density. With _N_ A = 1.3  10<sup>14</sup> cm<sup>-3</sup> for the perovskite film prepared with PEAI-GASCN additives (given in Figure 2a),  rad is estimated in the range of 38–128  s; thus, the TRPL decay 

5 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

(Figure 1a,b) is dominated by defect-mediated recombination. The same conclusion is obtained from the temperature ( _T_ ) dependence of TRPL decay kinetics (Figure 1d). Note that trapping/detrapping from shallow traps could affect recombination kinetics. Analysis using a trap level/activation energy _E_ a of 130 meV suggests that trapping/detrapping from shallow traps is not the main reason for the long carrier lifetime (Figure 1d). The same conclusion is obtained when the trap level is varied from about 100–170 meV, which is likely attributable to iodine vacancy and/or interstitial tin in Sn-Pb perovskites<sup>28</sup> . 



**Fig. 2. Optoelectronic and morphological comparison. a–b** , Comparison of the dark carrier density from Hall effect measurements (a) and its correlation with the TRPL lifetime (b) for perovskite thin films prepared without additive (pristine) and with additives as indicated. **c** , Typical J–V characteristics of PSCs prepared with and without additives as indicated. **d–f** , SEM images of perovskite films prepared without additive (d), with GASCN (e), and with both PEAI and GASCN (f). 

To understand the reason for the long carrier lifetime, we carried out the Hall effect measurement to examine the dark carrier (hole) density. In general, due to the facile oxidation of Sn<sup>2+</sup> to Sn<sup>4+</sup> and rapid crystallization of Sn-based perovskite films, Sn-containing perovskites often exhibit >10<sup>17</sup> cm<sup>−3</sup> dark carrier density<sup>13, 18, 29, 30</sup> _._ In this study, we showed that when a combination of PEAI-GASCN additives is used, the dark carrier density is remarkably reduced by more than 

6 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

two orders of magnitude, reaching ~1.3  10<sup>14</sup> cm<sup>-3</sup> (Figure 2a and Supplementary Figure 3). Such a low dark carrier density is unprecedented for Sn-Pb perovskite and is similar to corresponding values for Pb-only perovskites<sup>27</sup> . These results suggest that with additives in this study Sn-Pb perovskites can have recombination lifetimes and dark carrier densities comparable to Pb-only perovskites. 

It is evident that the carrier lifetime increases with decreasing dark carrier density (Figure 2b). Because the dark carrier density can be tuned by orders of magnitude, the relative importance of radiative and defect-mediated recombination changes in this study. For example, the measured radiative lifetime for _N_ A = 1.2  10<sup>17</sup> cm<sup>-3</sup> is ~100 ns. Therefore, the combination of PEAI and GASCN additives offer the possibility to engineer the dark carrier density and lifetime, giving an effective route to PV performance optimization. 

The low dark carrier density and long carrier lifetime are expected to significantly reduce the Voc deficit in Sn-Pb-based PSCs. Figure 2c compares the typical current density–voltage (J–V) curves of narrow-bandgap PSCs based on perovskite films prepared with and without additives. The Voc of these devices show a clear increase from 0.747 V (pristine) to 0.820 V (GASCN) to 0.883 V (PEAI+GASCN) from the reverse scan. The detailed PV parameters for both reverse and forward scans for these devices are shown in Supplementary Table 1. The significant improvement of Voc when using both PEAI and GASCN is consistent with reduced recombination associated with the low dark carrier density. The detailed balance limit for a single-junction solar cell with a 1.25-eV-bandgap absorber is _V_ oc = 0.981 V<sup>31</sup> . Analysis of the solar cell external quantum efficiency (EQE; Supplementary Fig. 12) provides an upper estimate for the radiative limit for open-circuit voltage, 𝑉ocrad = 0.973 V 32. This analysis already suggests that losses associated with band tails might be as low as 8 mV, highlighting the high optoelectronic quality of the Sn-Pb absorber. Comparison with the measured _V_ oc indicate that all non-radiative recombination processes account for voltage losses of about 90 mV (and as low as 57 mV for the champion cell shown in Figure 4a), comparable with the voltage losses observed for higher bandgap Pb-only devices<sup>32, 33</sup> . 

The improved optoelectronic properties associated with the use of PEAI-GASCN additives are also consistent with the film morphologies (Figure 2d–f, and Supplementary Fig. 4) where the film prepared with PEAI-GASCN additives showed the smoothest film surface with relatively large grain sizes and less clear grain boundaries. We also conducted steady PL measurements 

7 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

(Supplementary Fig. 5). The (FASnI3)0.6(MAPbI3)0.4 perovskite film using PEAI+GASCN additives showed the strongest PL intensity, which is consistent with the better film quality with the PEAI+GASCN additive. In addition, X-ray photoelectron spectroscopy (XPS) measurement (Supplementary Fig. 6 and Supplementary Tables 2,3) showed that the use of PEAI-GASCN additives resulted in an organic-halide and Pb rich surface region with respect to Sn, as well as significantly reduced Sn<sup>4+</sup> -to-Sn<sup>2+</sup> ratios, in comparison to other samples. A recent study showed that the bulk of Sn-based perovskites is less prone to oxidation than the surface region where the Sn termination on the surface (undercoordinated surface Sn atoms) can promote Sn<sup>2+</sup> oxidation to Sn<sup>4+ 34</sup> . We expect that a more defective surface region can further facilitate Sn<sup>2+</sup> oxidation deeper into the bulk. Thus, the surface region of Sn-Pb perovskite is important. The organic-halide rich region is preferred for suppressing oxidation Sn<sup>2+</sup> to Sn<sup>4+ 34</sup> , and it can also help passivating undercoordinated B-sites and reducing the concentration of halide vacancies. The XPS results show the most significant beneficial impacts are realized by using the combination of PEAI and GASCN, which is consistent with the low surface recombination velocity (~1.4 cm/s) and the most significant reduction of dark carrier density in the corresponding Sn-Pb perovskites. 



**Fig. 3. XRD characterization. a** , Comparison of XRD patterns of 2D perovskite thin films with varying degrees of GA:PEA mixing ratios. **b** , Comparison of the XRD patterns of 2D perovskite with the GA:PEA ratio of about 7:2 and (PEA)2GAPb2I7 perovskite along with that of (GA)2PbI4 and (PEA)2PbI4. **c** , Comparison of XRD patterns of 3D Sn-Pb perovskite precursor with adding different amounts of PEAI and GAI additives. The vertical shadow lines are guide to the eye. X- ray source: Cu K  radiation. 

8 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. 

The published version of the article is available from the relevant publisher. 

To understand the role of using the mixed-cation GA<sup>+</sup> -PEA<sup>+</sup> additives for Sn-Pb perovskite synthesis, we conducted a series of structural analysis. It is known that both GA<sup>+</sup> and PEA<sup>+</sup> can template the growth of 2D structures<sup>35-38</sup> . We hypothesize that the use of mixed PEAI and GASCN in the precursors also lead to the formation of 2D structures. To test this hypothesis and understand how PEA<sup>+</sup> and GA<sup>+</sup> compete in forming 2D structures, we first examined the XRD patterns using different GA<sup>+</sup> -PEA<sup>+</sup> mixing ratios. To simplify the comparison, we only used GAI as the source for GA<sup>+</sup> as it is known that SCN<sup>−</sup> easily escapes from the perovskite films during preparation<sup>39, 40</sup> . Figure 3a shows the diffraction pattern’s evolution with the GA<sup>+</sup> :PEA<sup>+</sup> mixing ratio spanning from 0:1 (PEA2PbI4) to 1:0 (GA2PbI4) with a systematic change observed in the low diffraction angle region. The main diffraction peaks (about 5.4  and 10.8  ) from PEA2PbI4 decreased whereas the main peak (about 13.8  ) from GA2PbI4 increased with increase of the GA<sup>+</sup> :PEA<sup>+</sup> ratio. When the GA<sup>+</sup> :PEA<sup>+</sup> ratio increased to above 0.4:0.6, three new diffraction peaks (about 4.3  , 8.5  , and 12.8  ) emerged and increased with higher GA<sup>+</sup> up to about 0.8:0.2; more detailed structural evolution with increasing GA<sup>+</sup> :PEA<sup>+</sup> ratios is given in Supplementary Figs. 7,8. The low-angle diffraction peaks suggest that the competition of GA<sup>+</sup> and PEA<sup>+</sup> in the precursor likely resulted in the formation of new 2D/quasi-2D structures. Figure 3b compares the XRD pattern based on a mixing ratio of 0.78:0.22 (corresponding to GA<sup>+</sup> :PEA<sup>+</sup> =7:2 as used in the optimal Sn-Pb perovskite precursor, Supplementary Fig. 9) to that of PEA2GAPb2I7 n=2 2D film; the XRD patterns of GA2PbI4 and PEA2PbI4 are also shown for comparison. Note that the formation of PEA2GAPb2I7 with PEA<sup>+</sup> and GA<sup>+</sup> is consistent with a recent study where a similar XRD pattern was observed for n=2 2D structures involving two different bulky organic cations<sup>41</sup> . The XRD results show that the material based on precursor of (GA0.78PEA0.22)2PbI4 consist of primarily n=2 PEA2GAPb2I7 along with some n=1 PEA2PbI4 and GA2PbI4. It should be noted that 2D structures with n=3 or higher number are not likely to form (Supplementary Figs. 10,11). When a significant amount of mixed PEA<sup>+</sup> -GA<sup>+</sup> (>10% mole ratio with respect to A-site cations) was added to the 3D (FASnI3)0.6(MAPbI3)0.4 precursor, the diffraction peaks associated with PEA2GAPb2I7 were observed (Figure 3c). For a lower concentration (<7%) the amount of 2D structures is likely too low to be detected in these experiments. Note that replacing Pb with Sn or Pb-Sn mixture in PEA2GAPb2I7 did not strongly affect the structure (Supplementary Fig. 12). The three characteristics low diffraction peaks (about 4.3°, 8.5°, and 12.8°) showed very little difference, due to the small difference of atomic scattering factors of Pb<sup>2+</sup> and Sn<sup>2+</sup> ions. Thus, it is possible 

9 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

n=2 2D structures with various Sn-Pb combinations may exist in the perovskite film. Since these 2D structures only contribute to a small fraction of the total material composition of the final perovskite film, they are not expected to significantly affect the composition of the bulk materials. This is consistent with the optical absorption results shown in Supplementary Fig. 1, where no obvious impact on the bandgap was observed. Note that TOF-SIMS results show that PEA<sup>+</sup> and GA<sup>+</sup> additives are distributed across the (FASnI3)0.6(MAPbI3)0.4 perovskite film (Supplementary Fig. 13). 

Pure 2D structures (normally referred to as n=1) are frequently used to improve 3D perovskites by passivating their surfaces and/or grain boundaries<sup>42</sup> . The formation of such 2D structure could improve the Sn-Pb perovskite electronic properties by (i) passivating grain boundaries and surfaces through its much wider band gap; (ii) blocking diffusion of Sn out of grains and further suppressing the formation of excessive Sn vacancies; and (iii) reducing oxygen diffusion into grains through surface and grain boundaries to suppress further oxidation of Sn<sup>2+</sup> . In comparison to the n=1 pure 2D structure, n=2 quasi-2D structures offer some unique advantages without losing the barrier protection capability associated with bulky organic cations. By using the time-resolved microwave conductivity (TRMC) technique, we found that the free carrier lifetime is much longer in n=2 PEA2GAPb2I7 (about 309 ns) than n=1 PEA2PbI4 (~21 ns) and GA2PbI4 (~101 ns) (Supplementary Fig. 14 and Supplementary Table 4). This observation is consistent with a recent study where the n=1 structure was found to exhibit a faster recombination rate than the n=2 structure owing to the much larger exciton binding energy<sup>43</sup> . We also found that PEA2GAPb2I7 exhibited enhanced out-of-plane charge transport when compared to PEA2PbI4, whereas the outof-plane transport in GA2PbI4 is too low to measure (Supplementary Fig. 15). The longer carrier lifetime and faster out-of-plane charge transport in n=2 PEA2GAPb2I7 in comparison to n=1 PEA2PbI4 and GA2PbI4 are significant for minimizing charge recombination and enhancing charge extraction at the 3D/2D interface, which could in turn improve the optoelectronic properties of SnPb perovskite thin films. 

10 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 



**Fig. 4. Single-junction Sn-Pb narrow-bandgap perovskite solar cells. a** , J–V curve of the champion narrow-bandgap PSC along with the stable power output (SPO) efficiency near the maximum power point (inset). **b** , Statistics of PV parameters of Sn-Pb narrow-bandgap PSCs (20 devices). **c** , Long-term stability of unencapsulated Sn-Pb narrow-bandgap PSC under continuous light illumination at about 30–35  C in N2. The perovskite thin films in these devices were prepared by using PEAI-GASCN additives. 

## **Single-junction narrow-bandgap Sn-Pb PSCs** 

These high-quality Sn-Pb perovskite films allowed us to fabricate highly efficient and stable Sn-Pb based PSCs. Figure 4a shows the J–V curves of the champion Sn-Pb PSC with negligible hysteresis between the reverse and forward voltage scans. The reverse scan yielded a PCE of 22.2%, with a Jsc of 30.62 mA/cm<sup>2</sup> , Voc of 0.916 V, and FF of 0.790. When measured in a forward scan, it showed a PCE of 22.1%, with a Jsc of 30.73 mA/cm<sup>2</sup> , Voc of 0.912 V and FF of 0.787. The corresponding stable power output (SPO) PCE was 22.1% (Figure 4a, inset). The EQE spectrum of the Sn-Pb PSC is shown in Supplementary Fig. 16, which yielded an integrated Jsc that agrees with the J–V measurement. Figure 4b shows the statistics of the PV parameters of the Sn-Pb narrow-bandgap PSCs. The _V_ oc of these cells span from about 0.85 V to near 0.92 V, which is significantly higher than literature results of Sn-Pb PSCs with a similar bandgap<sup>18, 20, 23, 24</sup> . The 

11 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

narrow-bandgap PSC also demonstrated a good device stability, retaining over 82% of its maximum efficiency under continuous simulated solar illumination in N2 for 1830 h. This good long-term stability along with the high Voc values from Sn-Pb narrow-bandgap PSCs reaffirm the benefit of reducing the dark carrier density and improving carrier lifetime in Sn-Pb perovskites. Note that we also tested device characteristics using <mark>PEACl and GACl/GAI or their combination</mark> (Supplementary Fig. 17) <mark>. Although these additives showed improvements to various degrees, the device using PEAI+GASCN additives exhibited the best device performance.</mark> 



**Fig. 5. Monolithic all-perovskite tandem solar cells. a** , Schematic of the two-terminal monolithic tandem device. **b** , Typical cross-sectional SEM image of a tandem device. **c** , J–V curve of the champion all-perovskite tandem solar cell along with the stable power output (SPO) efficiency near the maximum power point (inset). **d** , EQE spectra of the front (wide-bandgap) and back (narrow-bandgap) subcells with the integrated Jsc values indicated. **e** , Long-term stability of the tandem device under continuous light illumination (~0.8 suns) at about 30–35  C in N2. The 

12 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

perovskite thin films in the narrow-bandgap subcells were prepared by using PEAI-GASCN additives. 

**Table 1. PV parameters of narrow-bandgap and wide-bandgap perovskite single-junction and monolithic all-perovskite 2-terminal tandem solar cells.** 

|**Device**||**Jsc**<br>**(mA/cm**<sup>**2**</sup>**)**|**Voc**<br>**(V)**|**FF**|**PCE**<br>**(%)**|**SPO**<br>**(%)**|
|---|---|---|---|---|---|---|
|1.25-eV PSC|Reverse|30.62|0.916|0.790|22.2|22.1|
||Forward|30.73|0.912|0.787|22.1||
|1.75-eV PSC|Reverse|17.50|1.225|0.797|17.1|16.6|
||Forward|17.70|1.222|0.761|16.5||
|2T tandem|Reverse|15.03|2.121|0.801|25.5|25.5|
||Forward|15.05|2.114|0.797|25.4||



## **All-perovskite tandem solar cells** 

We further fabricated monolithic all-perovskite tandem solar cells by integrating the 1.25-eV SnPb narrow-bandgap back cell with a FA0.7Cs0.3PbI2.1Br0.9-based 1.75-eV wide-bandgap front cell. Figure 5a shows the schematic tandem device stack: glass/ITO/Meo-2PACz/1.75-eV perovskite/LiF/C60/33-nm SnOx/1-nm Au/PEDOT:PSS/1.25-eV perovskite/C60/BCP/Ag. A typical cross-section SEM image of the tandem device is shown in Figure 5b. The perovskite film thickness is about 400 nm for the 1.75-eV and 1  m for the 1.25-eV perovskite absorbers. The relatively thin film thickness of the wide-bandgap subcell was selected to achieve proper current matching with the narrow-bandgap subcell. The 1-nm Au deposited on SnOx facilitates electronhole recombination to connect the two subcells<sup>18, 19, 44</sup> . The J–V curves of the 1.75-eV widebandgap PSC are shown in Supplementary Fig. 18, and the corresponding J-V parameters are shown in Table 1. Figure 5c shows the J–V curves of the champion all-perovskite tandem device with both the reverse and forward voltage scans. The PCE under reverse scan was 25.5%, with a Voc of 2.121 V, a Jsc of 15.03 mA/cm<sup>2</sup> , and an FF of 0.801. When measured from the forward scan, the 2T tandem showed a PCE of 25.4%, with a Voc of 2.114 V, a Jsc of 15.05 mA/cm<sup>2</sup> and an FF of 0.797. The hysteresis between the reverse and forward scans is negligible. The PCE from the J–V curve is consistent with the stable power output PCE 25.5% (inset of Figure 5c). The statistics 

13 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

of the tandem PV parameters are given in Supplementary Fig. 19. The high Voc of the tandem PSCs is attributed to the high Voc of the Sn-Pb subcell. One such device was certified with a stabilized PCE of 24.30  0.43% and Voc of >2.11 V using an 11-point Asymptotic Pmax Scan protocol (Supplementary Figs. 20,21). This certified Voc value further confirms the record high photovoltage in our tandem and Sn-Pb narrow-bandgap solar cells. Figure 5d shows the EQEs from the wide-bandgap and narrow-bandgap subcells, yielding the integrated Jsc values of 14.98 mA/cm<sup>2</sup> and 14.88 mA/cm<sup>2</sup> , respectively. These values also agree well with the Jsc determined from the J–V measurements. 

Finally, we evaluated the long-term stability of the unencapsulated 2-T tandem cell under ISOS-L-1 N2 conditions<sup>26</sup> at 30–35  C, under continuous light illumination from a sulfur plasma lamp at ~0.8 suns. Figure 5e shows that the 2T tandem cell retained 80% of its maximum efficiency after 1500 h. We also conducted additional stability test with encapsulated tandem cells in air. Supplementary Fig. 22 shows the long-term operational stability of the encapsulated 2-T tandem cell in ambient air retaining >90% of the initial efficiency after 500 h. 

## **Conclusions** 

We report on the rational and synergistic impact of using a combination of PEAI-GASCN additives, which led to the formation of quasi-two-dimensional structure (PEA)2GAPb2I7 and substantially improved the optoelectronic quality of narrow-bandgap (1.25 eV) Sn-Pb perovskite thin films. The much-enhanced optoelectronic quality can be collectively attributed to several factors associated with the use of PEAI-GASCN additives, including improved film morphology, more effective defect passivation, and faster charge extraction at the 3D/2D interface. The resulting Sn-Pb perovskite with PEAI-GASCN additives showed unprecedented low dark carrier density (~1.3  10<sup>14</sup> cm<sup>-3</sup> ), long bulk carrier lifetime (~9.2  s), and low surface recombination velocity (~1.4 cm/s). We obtained 22.1%-efficient single-junction Sn-Pb perovskite cells and 25.5%efficient all-perovskite 2-terminal tandems with high photovoltages (certified tandem cell voltage 2.1142 V) and long operational stability. Our results on the device efficiency and stability for both the Sn-Pb narrow-bandgap PSC and all-perovskite tandem, by addressing the critical voltage losses, suggest that the use of mixed cations to incorporate n=2 2D structure in the 3D Sn-Pb perovskite precursor can accelerate the development of Sn-Pb-based perovskites for solar cell and other related optoelectronic applications. 

14 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

## **Methods** 

**Materials.** All solvents and chemical materials are directly used without purification unless otherwise stated. Lead iodide (PbI2, 99.999% trace metals basis), tin iodide (SnI2, 99.99% trace metals basis), guanidium thiocyanate (GASCN), tin (II) fluoride (SnF2), and cesium iodide (CsI) were purchased from Sigma-Aldrich. Phenethylammonium iodide (PEAI), formamidinium iodide (FAI), and methylammonium iodide (MAI) were purchased from Greatcell Solar. PbBr2, MeO2PACz, and bathocuproine (BCP) were purchased from TCI. Heraeus CLEVIOS<sup>TM</sup> P VP AI 4083 were purchased from Heraeus Clevios. C60 were purchased from Luminescence Technology. Dimethylformamide (DMF), dimethyl sulfoxide (DMSO), toluene, isopropanol, and ethanol were purchased from Sigma-Aldrich. 

**Perovskite precursor solution.** To make the narrow-bandgap (FASnI3)0.6(MAPbI3)0.4 (or FA0.6MA0.4Sn0.6Pb0.4I3) precursor, FAI (0.6 mmol), SnI2 (0.6 mmol), SnF2 (0.06 mmol), MAI (0.4 mmol), PbI2 (0.4 mmol) were mixed in 500  l DMF/DMSO (V/V 4:1) and stirring for 2 hours before use. For the (FASnI3)0.6(MAPbI3)0.4 with GASCN and PEAI passivated samples, the GASCN and PEAI powders were directly added into the (FASnI3)0.6(MAPbI3)0.4 precursor with different mole ratio with respect to MAI. To make the wide-bandgap of Cs0.3FA0.7PbI2.1Br0.9 precursor, PbCl2 (0.02 mmol), FAI (0.7 mmol), CsI (0.3 mmol), PbBr2 (0.45 mmol), and PbI2 (0.55 mmol) were mixed in 750  l DMF and 250  l DMSO mixed solution and stirred for 2 hours before use. The perovskite precursors were prepared in glovebox under N2, and they were filtered with PTFE 0.2 μm filters before use. 

**Wide-bandgap single-junction perovskite solar cells fabrication.** The pre-patterned ITO substrates were sequentially cleaned by ultra-sonic in acetone and isopropanol for 20 min, respectively. After UV-Ozone treatment of the ITO substrates for 15 min, 1 mM of MeO-2PACz ethanol solution was dropped onto the ITO substrates and spin-coated at 3000 rpm for 30 s, followed by 100  C 10-min annealing in a N2 glovebox. After cooling down the substrates, the wide-bandgap perovskite precursor was dropped onto it and spin-coated at 6000 rpm for 60 s. During the spinning process, the antisolvent of toluene was dropped at 15 s. The resulting perovskite film was then annealed at 100  C for 10 min. Then 1-nm LiF/30-nm C60 were thermal 

15 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

evaporated on the perovskite, followed by 33-nm SnOx deposited by ALD. Finally, 100-nm Ag was evaporated. 

**Narrow-bandgap single-junction perovskite solar cells fabrication.** The pre-patterned ITO substrates were sequentially cleaned by ultra-sonic in acetone and isopropanol for 20 minutes, respectively. PEDOT: PSS was spin-coated onto the ITO substrate at 5000 rpm and annealed at 120  C for 20 min in air. After that, the ITO-PEDOT:PSS substrates were transferred into a N2 glovebox. The (FASnI3)0.6(MAPbI3)0.4-based precursors without and with additives were spincoated onto the ITO/PEDOT:PSS substrates at 5000 rpm for 30 s and 350  l toluene was dripped onto the spinning substrate at 10 s after the starting of the spin coating. The resulting perovskite films were then thermal annealed at 100 ℃ for 10 min. Finally, 30-nm C60/6-nm BCP/100-nm Ag were sequentially thermal-evaporated on the perovskite layer. 

**Monolithic two-terminal all-perovskite tandem solar cell fabrication.** The two-terminal tandem solar cells were built by fabricating the narrow-bandgap subcell (about 1  m) on top of the wide-bandgap subcell (about 400 nm). The fabrication process of each subcell was identical to the single-junction solar cells. 30-nm C60/33-nm SnOx/1-nm Au was used as the interconnecting layer between the wide- and narrow-bandgap subcells. The 30-nm C60 and 1-nm Au were deposited by thermal evaporation in the glovebox. The 33-nm SnOx layer (thickness characterized by spectroscopic ellipsometry on a reference silicon wafer) was deposited by atomic layer deposition (ALD) at 90  C from 250 cycles of tetrakis(dimethylamino)tin(IV) (Strem chemicals, CAS: 106677-9) and water. The deposition was performed in a Beneq TFS200 reactor with chamber. The tetrakis(dimethylamino)tin(IV) (TDMASn) precursor was maintained at 55  C and water unheated and nitrogen process flows at 250 and 300 sccm, respectively. The TDMASn was dosed according to a charge-pulse-purge procedure consisting of a 0.35 s nitrogen charge, 1 s pulse, and 0.2 s pulse with nitrogen flow through the bubbler. The tin oxide growth consisted of a cyclical process of: TDMASn charge-pulse-purge dose procedure, purge (6 s), water dose (0.2 s), and purge (6 s) for a growth rate of 1.4 Å/cycle, as previously reported<sup>45</sup> . 

**Solar cell characterizations.** The photocurrent density–voltage ( _J–V_ ) were measured in a N2 glovebox using an AM 1.5G solar simulator (Oriel Sol3A Class AAA). The intensity of the solar 

16 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

simulator was calibrated to 100 mW/cm<sup>2</sup> using a reference Silicon solar cell (Oriel, VLSI standards, certified by NREL PV Performance Calibration group) as detailed in a previous study<sup>46</sup> . The _J–V_ curves of both single-junction and tandem solar cells were taken with reverse and forward voltage scans with the scan speed of 0.1 V/s (voltage steps of 10 mV and a delay time of 100 ms). Prior to _J-V_ characterization, all devices were first pre-conditioned by continuous illumination under 1 Sun (AM 1.5G, 100 mW/cm<sup>2</sup> ) for 10 seconds. The device area was 0.112 cm<sup>2</sup> and masked with a metal aperture to define an active area of 0.09 cm<sup>2</sup> . The stable power output (SPO) efficiency of the solar cells was measured by monitoring the output efficiency with the biased voltage set at the maximum power point. The external quantum efficiency (EQE) spectra of single-junction cells were taken by using the Newport Oriel IQE200. The reference cell used for the calibration of EQE was calibrated by the certification group in NREL. For EQE measurement of the tandem solar cells, two highly bright LEDs with emission wavelength at 470 nm and 850 nm were used as the bias light to measure the back narrow-bandgap and front wide-bandgap subcells, respectively. The chopper frequency was 314 Hz. For long-term stability measurement, the solar cells were loaded into a home-built stability measuring system as described previously<sup>47</sup> . During the measurement, samples were kept in a nitrogen environment and maintained at about 30–35  C. 

**Time-resolved photoluminescence characterization.** Excitation was provided by the 640-nm output from an optical parametric amplifier pumped by a Yb:KGW laser with the repetition rate reduced to 55 kHz and a pulse width of ca. 0.3 ps (Orpheus/Pharos, Light Conversion). A multimode optical fiber was used to guide the excitation beam to the sample. The light was focused on the sample with an aspheric lens to provide an excitation spot with a diameter of approximately 180 μm. The same lens/fiber combination was used to collect the PL signal, which was routed to the detector using a dichroic beam splitter through a 70 nm bandpass filter centered at 1000 nm. The TRPL decays were recorded via time-correlated single-photon counting (PicoHarp 300 TCSPC Module, PicoQuant) using a silicon single-photon avalanche diode (Micro Photon Devices). Temperature dependent TRPL measurements were performed by mounting the sample inside an optical closed loop helium cryostat. For TRPL measurement, the samples were placed in an air-free container with quartz optical windows. 

17 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

**Time-resolved microwave conductivity characterization.** Thin-film perovskite samples deposited directly onto pre-cleaned and UV-ozone-treated quartz substrates were photoexcited through the quartz side of the substrate with 450 nm (5-ns pulse width) from an optical parametric oscillator (Continuum Panther) pumped by the 355-nm harmonic of a Q-switched Nd:YAG laser (Continuum Powerlite). Flash-photolysis time-resolved microwave conductivity experiments were conducted with the sample oriented in parallel, and perpendicular to the microwave electric field, for the in-plane measurements and for the out of plane measurement, respectively, as described previously<sup>48</sup> . The transient change in photoconductance, Δ _G_ ( _t_ ), was measured via changes in the microwave power, Δ _P_ ( _t_ ), due to absorption of microwaves (~9 GHz) by the photogenerated holes ΔP and electrons: = −KΔG. The end-of-pulse (peak) photoconductance, Δ _G_ peak, is related to the P product of the yield of free-carrier generation, _φ_ , and the sum of the GHz-frequency electron and hole mobilities. The sensitivity factor (K) is 24,000 for the in-plane measurements, and 929 for the out-of-plane measurements. Detailed configurations and calculations can be seen in a previous study<sup>48</sup> . TRMC measurements of 2D samples were conducted in air. 

**X-ray diffraction (XRD) and electron microscope characterizations.** The crystal structures of prepared perovskite films were characterized using an X-ray diffractometer (D-Max 2200, Rigaku) with a Cu K  radiation source. 2D-XRD was measured using a D8-Discover (Bruker) with general area detector diffraction system (GADDS) four-circle detector and a Cu K  radiation source. The morphologies and microstructures of the prepared perovskite films and the cross-sectional structures and thickness of the solar cells were investigated using a field-emission scanning electron microscopy (FESEM, Nova 630 NanoSEM, FEI). The optical absorption spectra of perovskite films were measured using an ultraviolet-visible (UV-vis) spectrophotometer (Cary6000i, Agilent). 

**Hall effect measurement.** Transport measurements of the perovskite thin films were measured using a Lakeshore 8425 Hall probe equipped with a 2T superconducting magnet at room temperature. The perovskite thin film was prepared on the glass substrate, and then the fourterminal Ti/Au (10 nm / 80 nm) square contacts were deposited on the perovskite thin film to define a Van der Pauw sample with an area of 50 μm × 50 μm by using the standard 

18 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

semiconducting fabrication techniques in the cleanroom. The samples were placed in the vacuum chamber during Hall measurement. 

**X-ray photoemission spectroscopy (XPS) characterization.** XPS measurements were performed on a Physical Electronics 5600 photoelectron spectrometer, which has been discussed in detail previously<sup>49</sup> . Briefly, radiation was produced by a monochromatic 350 W Al Kα excitation centered at 1486.7 eV. XPS core-level spectra were collected using a step size of 0.1 eV and pass energy of 11.75 eV. The electron binding energy scale was calibrated using the Fermi edge of a copper substrate, cleaned with Argon ion bombardment. Peak areas were fit using a Gaussian-Lorentzian peak fitting algorithm with a Shirley background. Spectra taken with the Al source are typically assigned an uncertainty of 0.05 eV. Compositional analyses and deconvolutions are typically assigned an uncertainty of 5%. The samples were placed in the vacuum chamber during XPS measurement. 

**DFT calculation.** DFT calculations were performed using the VASP code<sup>50, 51</sup> with projector augmented-wave<sup>52</sup> potentials. A kinetic energy cutoff of 500 eV was used to expand the wave functions. The Brillouin zone was sampled with Γ-centered 3×3×1 k-mesh. The atomic coordinates were relaxed with PBE functional<sup>53</sup> with a force tolerance of 0.01 eV Å<sup>−1</sup> . Grimme’s D3 correction<sup>54</sup> was adopted to deal with the weak van der Waals interactions. 

**Stead-state PL measurement.** The steady state PL measurement was conducted on perovskite thin films deposited on soda–lime glasses. Samples were excited from the perovskite film side using a 532 nm continuous-wave laser. PL signals were then detected via a Symphony-II CCD (Horiba) detector. 

**Time-of-flight secondary-ion mass spectrometry (TOF-SIMS).** An ION-TOF TOF-SIMS V Time of Flight SIMS (TOF-SIMS) spectrometer was used for depth profiling of the perovskite utilizing methods covered in detail in previous reports<sup>55</sup> . Analysis was completed utilizing a 3-lens 30 kV BiMn primary ion gun. High mass resolution depth profiles were completed with a 30KeV 

19 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

Bi3<sup>+</sup> primary ion beam, (0.8 pA pulsed beam current), a 50×50µm area was analyzed with a 128:128 primary beam raster. Sputter depth profiling was accomplished with 1kV Cesium ion beam (6 nA sputter current) with a raster of 150×150 microns. 

**Reporting summary.** Further information on research design is available in the Nature Research Reporting Summary linked to this article. 

## **Data Availability** 

All data generated or analysed during this study are included in this published article and its Supplementary Information and Source Data files. 

## **References** 

1. Hörantner, M.T. et al. The potential of multijunction perovskite solar cells. _ACS Energy Lett._ **2** , 2506-2513 (2017). 

2. Al-Ashouri, A. et al. Monolithic perovskite/silicon tandem solar cell with >29% efficiency by enhanced hole extraction. _Science_ **370** , 1300-1309 (2020). 

3. Leijtens, T., Bush, K.A., Prasanna, R. & McGehee, M.D. Opportunities and challenges for tandem solar cells using metal halide perovskite semiconductors. _Nat. Energy_ **3** , 828838 (2018). 

4. Tong, J. et al. Wide-Bandgap Metal Halide Perovskites for Tandem Solar Cells. _ACS Energy Lett._ **6** , 232-248 (2021). 

5. De Wolf, S. et al. Organometallic Halide Perovskites: Sharp Optical Absorption Edge and Its Relation to Photovoltaic Performance. _J. Phys. Chem. Lett._ **5** , 1035-1039 (2014). 

6. Eperon, G.E. et al. Formamidinium lead trihalide: a broadly tunable perovskite for efficient planar heterojunction solar cells. _Energy Environ. Sci._ **7** , 982-988 (2014). 

7. Green, M.A., Ho-Baillie, A. & Snaith, H.J. The emergence of perovskite solar cells. _Nat. Photonics_ **8** , 506-514 (2014). 

8. Noh, J.H., Im, S.H., Heo, J.H., Mandal, T.N. & Seok, S.I. Chemical Management for Colorful, Efficient, and Stable Inorganic–Organic Hybrid Nanostructured Solar Cells. _Nano Lett._ **13** , 1764-1769 (2013). 

9. Hao, F., Stoumpos, C.C., Chang, R.P.H. & Kanatzidis, M.G. Anomalous Band Gap Behavior in Mixed Sn and Pb Perovskites Enables Broadening of Absorption Spectrum in Solar Cells. _J. Am. Chem. Soc._ **136** , 8094-8099 (2014). 

10. Li, Z. et al. Scalable fabrication of perovskite solar cells. _Nat. Rev. Mater._ **3** , 18017 (2018). 

11. Saidaminov, M.I. et al. Conventional Solvent Oxidizes Sn(II) in Perovskite Inks. _ACS Energy Lett._ **5** , 1153-1155 (2020). 

12. Kumar, M.H. et al. Lead-Free Halide Perovskite Solar Cells with High Photocurrents Realized Through Vacancy Modulation. _Adv. Mater._ **26** , 7122-7127 (2014). 

20 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

13. Lee, S.J. et al. Reducing Carrier Density in Formamidinium Tin Perovskites and Its Beneficial Effects on Stability and Efficiency of Perovskite Solar Cells. _ACS Energy Lett._ **3** , 46-53 (2018). 

14. Leijtens, T., Prasanna, R., Gold-Parker, A., Toney, M.F. & McGehee, M.D. Mechanism of Tin Oxidation and Stabilization by Lead Substitution in Tin Halide Perovskites. _ACS Energy Lett._ **2** , 2159-2165 (2017). 

15. Yokoyama, T. et al. Overcoming Short-Circuit in Lead-Free CH3NH3SnI3 Perovskite Solar Cells via Kinetically Controlled Gas–Solid Reaction Film Fabrication Process. _J. Phys. Chem. Lett._ **7** , 776-782 (2016). 

16. Zong, Y., Zhou, Z., Chen, M., Padture, N.P. & Zhou, Y. Lewis-Adduct Mediated GrainBoundary Functionalization for Efficient Ideal-Bandgap Perovskite Solar Cells with Superior Stability. _Adv. Energy Mater._ **8** , 1800997 (2018). 

17. Tong, J. et al. Carrier lifetimes of >1 μs in Sn-Pb perovskites enable efficient allperovskite tandem solar cells. _Science_ **364** , 475-479 (2019). 

18. Lin, R. et al. Monolithic all-perovskite tandem solar cells with 24.8% efficiency exploiting comproportionation to suppress Sn(ii) oxidation in precursor ink. _Nat. Energy_ **4** , 864-873 (2019). 

19. Xiao, K. et al. All-perovskite tandem solar cells with 24.2% certified efficiency and area over 1 cm2 using surface-anchoring zwitterionic antioxidant. _Nat. Energy_ **5** , 870-880 (2020). 

20. Yang, Z. et al. Enhancing electron diffusion length in narrow-bandgap perovskites for efficient monolithic perovskite tandem solar cells. _Nat. Commun._ **10** , 4498 (2019). 

21. Ke, W. et al. Narrow-Bandgap Mixed Lead/Tin-Based 2D Dion–Jacobson Perovskites Boost the Performance of Solar Cells. _J. Am. Chem. Soc._ **142** , 15049-15057 (2020). 

22. Kapil, G. et al. Strain Relaxation and Light Management in Tin–Lead Perovskite Solar Cells to Achieve High Efficiencies. _ACS Energy Lett._ **4** , 1991-1998 (2019). 

23. Yu, Z. et al. Simplified interconnection structure based on C60/SnO2-x for all-perovskite tandem solar cells. _Nat. Energy_ **5** , 657-665 (2020). 

24. Li, C. et al. Low-bandgap mixed tin–lead iodide perovskites with reduced methylammonium for simultaneous enhancement of solar cell efficiency and stability. _Nat. Energy_ **5** , 768-776 (2020). 

25. Zhao, D. et al. Efficient two-terminal all-perovskite tandem solar cells enabled by highquality low-bandgap absorber layers. _Nat. Energy_ **3** , 1093-1100 (2018). 

26. Khenkin, M.V. et al. Consensus statement for stability assessment and reporting for perovskite photovoltaics based on ISOS procedures. _Nat. Energy_ **5** , 35-49 (2020). 

27. Kirchartz, T., Márquez, J.A., Stolterfoht, M. & Unold, T. Photoluminescence-Based Characterization of Halide Perovskites for Photovoltaics. _Adv. Energy Mater._ **10** , 1904134 (2020). 

28. Meggiolaro, D., Ricciarelli, D., Alasmari, A.A., Alasmary, F.A.S. & De Angelis, F. Tin versus Lead Redox Chemistry Modulates Charge Trapping and Self-Doping in Tin/Lead Iodide Perovskites. _J. Phys. Chem. Lett._ **11** , 3546-3556 (2020). 

29. Liao, W. et al. Lead-Free Inverted Planar Formamidinium Tin Triiodide Perovskite Solar Cells Achieving Power Conversion Efficiencies up to 6.22%. _Adv. Mater._ **28** , 9333-9340 (2016). 

30. Sabba, D. et al. Impact of Anionic Br– Substitution on Open Circuit Voltage in Lead Free Perovskite (CsSnI3-xBrx) Solar Cells. _J. Phys. Chem. C_ **119** , 1763-1767 (2015). 

21 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

31. Rühle, S. Tabulated values of the Shockley–Queisser limit for single junction solar cells. _Sol Energy_ **130** , 139-147 (2016). 

32. Krückemeier, L., Rau, U., Stolterfoht, M. & Kirchartz, T. How to Report Record OpenCircuit Voltages in Lead-Halide Perovskite Solar Cells. _Adv. Energy Mater._ **10** , 1902573 (2020). 

33. Liu, Z. et al. Open-Circuit Voltages Exceeding 1.26 V in Planar Methylammonium Lead Iodide Perovskite Solar Cells. _ACS Energy Lett._ **4** , 110-117 (2019). 

34. Ricciarelli, D., Meggiolaro, D., Ambrosio, F. & De Angelis, F. Instability of Tin Iodide Perovskites: Bulk p-Doping versus Surface Tin Oxidation. _ACS Energy Lett._ **5** , 27872795 (2020). 

35. Daub, M., Haber, C. & Hillebrecht, H. Synthesis, Crystal Structures, Optical Properties, and Phase Transitions of the Layered Guanidinium-Based Hybrid Perovskites [C(NH2)3]2MI4; M = Sn, Pb. _Eur. J. Inorg. Chem._ **2017** , 1120-1126 (2017). 

36. Jodlowski, A.D., Yépez, A., Luque, R., Camacho, L. & de Miguel, G. Benign-by-Design Solventless Mechanochemical Synthesis of Three-, Two-, and One-Dimensional Hybrid Perovskites. _Angew. Chem. Int. Ed._ **55** , 14972-14977 (2016). 

37. Soe, C.M.M. et al. New Type of 2D Perovskites with Alternating Cations in the Interlayer Space, (C(NH2)3)(CH3NH3)nPbnI3n+1: Structure, Properties, and Photovoltaic Performance. _J. Am. Chem. Soc._ **139** , 16297-16309 (2017). 

38. Liang, C. et al. Ruddlesden–Popper Perovskite for Stable Solar Cells. _Energy Environ. Sci._ **1** , 221-231 (2018). 

39. Ke, W. et al. Employing Lead Thiocyanate Additive to Reduce the Hysteresis and Boost the Fill Factor of Planar Perovskite Solar Cells. _Adv. Mater._ **28** , 5214-5221 (2016). 

40. Zhang, R. et al. A potassium thiocyanate additive for hysteresis elimination in highly efficient perovskite solar cells. _Inorg. Chem. Front._ **6** , 434-442 (2019). 

41. Fu, Y. et al. Incorporating Large A Cations into Lead Iodide Perovskite Cages: Relaxed Goldschmidt Tolerance Factor and Impact on Exciton–Phonon Interaction. _ACS Cent. Sci._ **5** , 1377-1386 (2019). 

42. Zhang, F. et al. Advances in two-dimensional organic–inorganic hybrid perovskites. _Energy Environ. Sci._ **13** , 1154-1186 (2020). 

43. Chen, X. et al. Impact of Layer Thickness on the Charge Carrier and Spin Coherence Lifetime in Two-Dimensional Layered Perovskite Single Crystals. _ACS Energy Lett._ **3** , 2273-2279 (2018). 

44. Wang, J. et al. 16.8% Monolithic all-perovskite triple-junction solar cells via a universal two-step solution process. _Nat. Commun._ **11** , 5254 (2020). 

45. Xu, J. et al. Triple-halide wide–band gap perovskites with suppressed phase segregation for efficient tandems. _Science_ **367** , 1097-1104 (2020). 

46. Palmstrom, A.F. et al. Enabling Flexible All-Perovskite Tandem Solar Cells. _Joule_ **3** , 2193-2204 (2019). 

47. Kim, D. et al. Efficient, stable silicon tandem cells enabled by anion-engineered widebandgap perovskites. _Science_ **368** , 155-160 (2020). 

48. Zhang, F. et al. Enhanced Charge Transport in 2D Perovskites via Fluorination of Organic Cation. _J. Am. Chem. Soc._ **141** , 5972-5979 (2019). 

49. Perkins, C.L. & Hasoon, F.S. Surfactant-assisted growth of CdS thin films for photovoltaic applications. _J. Vac. Sci. Technol. A_ **24** , 497-504 (2006). 

22 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

50. Kresse, G. & Furthmüller, J. Efficient iterative schemes for ab initio total-energy calculations using a plane-wave basis set. _Phys. Rev. B_ **54** , 11169-11186 (1996). 

51. Kresse, G. & Furthmüller, J. Efficiency of ab-initio total energy calculations for metals and semiconductors using a plane-wave basis set. _Comput. Mater. Sci._ **6** , 15-50 (1996). 

52. Blöchl, P.E. Projector augmented-wave method. _Phys. Rev. B_ **50** , 17953-17979 (1994). 53. Perdew, J.P., Burke, K. & Ernzerhof, M. Generalized Gradient Approximation Made Simple. _Phys. Rev. Lett_ **77** , 3865-3868 (1996). 

54. Grimme, S., Antony, J., Ehrlich, S. & Krieg, H. A consistent and accurate ab initio parametrization of density functional dispersion correction (DFT-D) for the 94 elements H-Pu. _J. Chem. Phys_ **132** , 154104 (2010). 

55. Harvey, S.P., Messinger, J., Zhu, K., Luther, J.M. & Berry, J.J. Investigating the Effects of Chemical Gradients on Performance and Reliability within Perovskite Solar Cells with TOF-SIMS. _Adv. Energy Mater._ **10** , 1903674 (2020). 

## **Acknowledgements** 

The work at the National Renewable Energy Laboratory was supported by the U.S. Department of Energy under Contract No. DE-AC36-08GO28308 with Alliance for Sustainable Energy, Limited Liability Company (LLC), the Manager and Operator of the National Renewable Energy Laboratory. We acknowledge the support on perovskite synthesis, device fabrication, and characterization from the De-Risking Halide Perovskite Solar Cells program of the National Center for Photovoltaics (J.T., Q.J., A.F.P., F.Z., S.P.D., A.E.L., R.M.F., M.Y., J.F.G., J.J.B., and K.Z.), and the support on TRPL characterization and analysis from Award Number 34361 (A.J.F. and D.K.), funded by the U.S. Department of Energy, Office of Energy Efficiency and Renewable Energy, Solar Energy Technologies Office. We also acknowledge the support on TRMC and Hall effect measurement and analysis from the Center for Hybrid Organic Inorganic Semiconductors for Energy (CHOISE), an Energy Frontier Research Center funded by the Office of Basic Energy Sciences, Office of Science within the U.S. Department of Energy (J.H., H.L., and M.C.B.). Contributions from S.A.J. and M.D.M. <mark>was supported by the U.S. Department of Energy’s Office of Energy Efficiency and Renewable Energy (EERE) under Solar Energy Technologies Office (SETO) Agreement Number DE-EE0008551.</mark> The views expressed in the article do not necessarily represent the views of the DOE or the U.S. Government. 

## **Author Contributions** 

K.Z. and J.T. conceived the idea and designed the experiment. J.T. developed the tandem solar cell structure and fabrication process. J.T. and Q.J. fabricated and characterized the perovskite devices. J.T. conducted the XRD measurement. A.J.F. and D.K. performed the TRPL 

23 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

characterization and analysis. A.F.P. conducted ALD with the support from S.A.J. under the guidance of M.D.M. F.Z. characterized the surface and cross-section morphology of the perovskite films and devices. J.H. conducted the Hall effect measurement and analysis. M.Y. participated in the tandem solar cell efficiency measurement. S.P.D. conducted the XPS measurement and analysis with the guidance from J.J.B. A.E.L. and J.J.B. conducted the long-term device stability measurement and analysis. H.L. conducted TRMC characterization and analysis under the guidance of M.C.B. R.M.F. and J.F.G. supported the tandem EQE and J-V measurements. X.W. and C. L. conducted DFT calculation and PL measurement, respectively, under the guidance of Y.Y. S.P.H. conducted the TOF-SIMS study and analysis. J.T. and K.Z. wrote the first draft of the manuscript. All authors discussed the results and contributed to the revisions of the manuscript. K.Z. supervised the project. 

## **Competing Interests** 

The authors declare no competing interests. 

24 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

