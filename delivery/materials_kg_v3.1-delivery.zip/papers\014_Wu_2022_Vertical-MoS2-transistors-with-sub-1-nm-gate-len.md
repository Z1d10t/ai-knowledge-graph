# Vertical MoS2 transistors with sub-1-nm gate lengths

| 字段 | 内容 |
|---|---|
| 期刊 | Nature |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 530 |
| 作者 | Fan Wu, H. Tian, Yang Shen, Zhanju Hou, Jie Ren, Guang-Yang Gou, Ya-Bin Sun, Yi Yang et al. |
| DOI | 10.1038/s41586-021-04323-3 |
| 源文件 | 014_Wu_2022_Vertical-MoS2-transistors-with-sub-1-nm-gate-len.pdf |

---




<!-- Start of picture text -->
Ultimate 0.34 nm Gate -l ength Side -W all Transistors<br>with Atomic Level Channel<br><!-- End of picture text -->

Tian ~~-L~~ ing Ren  (  RenTL@tsinghua.edu.cn ) Tsinghua University https://orcid.org/0000-0002-7330-0544 

Tsinghua University 

Tsinghua University 

Tsinghua University 

Tsinghua University 

Tsinghua University 

Institute of Microelectronics & Tsinghua National Laboratory for Information Science and Technology (TNList), Tsinghua University 

Keywords: Short Gate Length Transistors, Graphene Edge Gate, Chemical Vapor Deposition Graphene, Gate Control Ability 

Posted Date: December 4th, 2020 

DOI: https://doi.org/10.21203/rs.3.rs-119491/v1 

License:   This work is licensed under a Creative Commons Attribution 4.0 International License. Read Full License 

Version of Record: A version of this preprint was published at Nature on March 9th, 2022. See the published version at https://doi.org/10.1038/s41586-021-04323-3. 

Page 1/14 

Despite 55 years of efforts into short gate length transistors following the Moore’s law, the gate length below 1 nm has not been realized. Here, we demonstrated a side-wall monolayer MoS2 transistors with ultimate 0.34 nm gate length using the edge of graphene as gate electrode. Moreover, large area of chemical vapor deposition graphene and MoS2 are used for 2-inch wafer production. These ultrashort devices show excellent ON/OFF current ratio of 2 × 10<sup>5</sup> . Simulation results indicate that the MoS2 sidewall effective channel length approaches 0.34 nm in the ON state. This graphene edge gate combined with MoS2 vertical channel structure provides an e�cient gate control ability and enables the physical gate length scaling down to atomic level, which shows great potential to build next generation electronics. 

Since the �rst integrated circuit built in 1960s, silicon (Si) transistors have shrunk following the guide of Moore’s law so that more devices can be built on one chip<sup>1</sup> . Until now, Si transistors are approaching the scaling limit when the gate length (Lg) scales down to sub-5 nm<sup>2</sup> . Theoretical analysis indicates that short channel effects (SCEs), including direct source-to-drain tunneling currents (ISD-LEAK) and draininduced barrier lowering (DIBL) effect, can in�uence and even terminate the scaling down process<sup>3</sup> . It is theoretical predicted that the minimum Lg for Si-based transistors is ~2.67 nm<sup>4</sup> . So, there is of great signi�cance to explore new materials with further Lg scaling down potential. 

In recent years, two-dimensional materials, dispersing wide range of electrical conductivity from semimetal, semiconductor to insulator, have attracted great attention for next generation electronic devices<sup>5-7</sup> . Graphene, as a semi-metal material, shows high intrinsic electrical conductivity up to 10<sup>8</sup> S/m, which is very suitable as electrode<sup>8-10</sup> . MoS2, as a representative for 2D transition metal dichalcogenides (TMDCs), has a larger bandgap (~1.8 eV for monolayer) than Si (~1.12 eV)<sup>6</sup> . Besides, its native n-doped behavior, larger electron effective mass ( ~0.50 versus  ~0.19 for Si [100])<sup>11</sup> , and lower dielectric constant (~3.3 versus ~11.7 for bulk Si)<sup>12,13</sup> , leading to superior resistance to SCEs. In 2017, Xie et. al demonstrated a 3.8 nm channel length MoS2 transistor<sup>14</sup> . Therefore, MoS2 is expected to be an ideal candidate to replace Si as channel material in the future transistors<sup>15,16</sup> . 

Nowadays, for 2D material-based transistors, there are three typical device structures, as shown in Fig. 1a-c. Global back gate 2D material-based transistors are most widely studied due to the simple fabrication process<sup>17</sup> . But the relatively large effective oxide thickness (EOT) restrains the performance improvement. Another is the top gate 2D material-based transistors (6). EOT can be greatly scaling down to sub-1 nm through atomic layer depositing (ALD) high-k dielectric material. Therefore, subthreshold swing (SS) can be greatly reduced. However, whether for global gate or local gate, the Lg is typically determined by the resolution of lithography. Even using electron beam lithography (EBL), the Lg can be 

Page 2/14 

hardly scaled down below 5 nm<sup>18</sup> . In 2016, Desai et. al promoted a prototype of junction-less 2D MoS2 transistor using metallic single-wall carbon nanotube (SWCNT) as gate electrode, which demonstrates the Lg down to 1 nm<sup>19</sup> . Among the three typical transistor structures, it is hard to further scaling down Lg below 1 nm. To date, it is of great signi�cance to explore the 2D TMDC transistors with the gate-length approaching the ultimate scaling limits. 

In this work, we demonstrate a new concept of side-wall 2D transistors gated by the edge of graphene, which only have 0.34 nm Lg controlling the atomic MoS2 channel (Fig. 1d). Large area CVD graphene and MoS2 are used for wafer-scale production. The additional metal layer screens the electrical �eld from the upper surface of graphene, so that the electrical �eld comes from the edge of graphene, which can in�uence the vertical MoS2 channel. The intrinsic CVD graphene has the high electrical conductivity, which can minimize the voltage drop along the gate layer. The 0.34 nm side-wall gated transistors show good switching characteristic with 2×10<sup>5</sup> ON/OFF current ratio. Sentaurus technology computer-aided design (TCAD) simulation results show that 2D planar characteristic of graphene gate provides e�cient gate control ability, which can effectively deplete the MoS2 side-wall channel close to the graphene plane. Our work promoted a production method for scaling down Lg beyond the resolution of lithography. And most importantly, it provides a great insight into the ultimate scaling, which can be regarded as the smallest node to date based on our best knowledge (Fig. 1e). 



<!-- Start of picture text -->
Results<br>Fabrication and Characterization<br><!-- End of picture text -->

To fabricate the 0.34 nm gate-length side-wall transistor, monolayer chemical vapor deposition (CVD) graphene with 3 cm×3 cm size was �rst wet-transferred to a highly p-doped Si/ 300 nm SiO2 substrate followed by patterning graphene as gate electrode. After that, EBL was performed and a 25 nm aluminum (Al) layer was deposited by electron-beam evaporation. Graphene transistors were �rst measured to verify their electrical conductivity (Fig. S1). The samples were naturally oxidized in the air for more than 3 days to form ~5 nm dense oxidization layer (AlOx). The high quality dense AlOx was also con�rmed by the breakdown measurement (Fig. S2). Al layer serves as not only screening layer, but also self-aligned layer for further SiO2 inductively coupled plasma (ICP) etching. Extra 20 nm SiO2 was etched to form side-wall structure and 13 nm high-k HfO2 as gate dielectric was grown via ALD. Then, monolayer CVD MoS2 �lm with 2 cm×2 cm size was wet-transferred and patterned on the substrate. Ti/Pd (2 nm/ 35 nm) as source and drain contacts were made on MoS2 to complete the device. The �nal device has four electrical terminals named source (S), drain (D), 0.34 nm graphene edge gate (G), and the highly p-doped Si substrate back gate (B). By applying the edge of graphene gate a negative voltage to locally deplete the vertical MoS2 channel, the device can be turned off. The device structure and the main fabrication �ow of the 0.34 nm gate-length side-wall transistor are shown in Fig. 2a&b. 

Page 3/14 

The devices after the fabrication were characterized, the SEM image with false-colored and TEM image from a representative sample are shown in Fig. 2c and Fig. 2d. For SEM image, purple region contains monolayer graphene/AlOx/Al/AlOx/HfO2 stack. The yellow and blue regions represent the MoS2 channel and Ti/Pd metal contacts. TEM image shows the pro�le of the device core region, the layered structure of atomic vertical side-wall MoS2 channel gated by the edge of graphene can be recognized clearly. The topography MoS2 �lm/HfO2 (~13.8 nm) stack was smooth. To reduce the ungated channel resistance, source electrode was made very close to the edge of graphene (<50 nm, 14 nm in this device). The spatial distribution of aluminum, hafnium, carbon, molybdenum, sulfur and oxygen was observed in the energy dispersive spectrometer (EDS) mapping of the core region (Fig. 2e & Fig. S3), thus con�rming the location of the monolayer graphene, HfO2, Al, AlOx and monolayer MoS2 in this device. In the fabrication �ow, the CVD graphene and MoS2 were applied as gate and channel materials, which realizes wafer-scale production (Fig. 2f). 

A back gate MoS2 transistor was �rst measured (Fig. S4). It indicates that by applying positive back gate voltage (VBS=50 V), the lower extension MoS2 region on 275 nm SiO2/ 13 nm HfO2 can be tuned to relatively high electron carrier density (n<sup>+</sup> -type). Therefore, the IDS-VGS transfer characteristic at VDS=-50 mV, -1 V, -2 V and -3 V of this side-wall transistor in Fig. 3a is carried out at VBS=50 V, which demonstrate the feasibility of the graphene edge as the gate of side-wall transistor to turn off the channel. The SS is ~210 mV/dec and ON/OFF current ratio can reach up to 2×10<sup>5</sup> . Due to the present of SCEs, the value of DIBL is ~1 V/V. Leakage current from monolayer graphene side-wall gate (IG) and highly p-doped Si substrate (IB) are both close to the noise level (10<sup>-13</sup> A). 

The IDS-VDS output curves under different VGS bias at VBS=50 V is shown in Fig. 3b with a linear-like characteristic. By varying VBS from 0 V to 50 V, which can affect the extension of MoS2 region, the ON state current increases from 10<sup>-9</sup> A to 10<sup>-7</sup> A and in IDS-VGS transfer characteristic at VDS=-1.0 V (Fig. 3c). Non-ideal ON state current ~10<sup>-7</sup> A also proves the ultra-thin gate length due to the present of ungated region in the MoS2 channel. Besides, the transfer curves slightly left shift under larger VBS because the VGS has to be more negative to deplete the vertical MoS2 channel owing to the ultra-thin 0.34 nm gate length. Three IDS-VGS transfer curves at VDS=-1.0 V and VBS=50 V from different devices are shown in Fig. 3d, the SS and ON/OFF current ratios of the three devices in the same batch are shown in Fig. 3e. These results demonstrate good uniformity of this 0.34 nm Lg side-wall transistors. 

To understand the electrical behaviors and device physics, Sentaurus TCAD was performed based on this experimental side-wall transistor (Fig. 4a). All the parameters in simulation are close to the actual devices. The lower plane of the extension MoS2 region is 13 nm below the graphene gate plane in 

Page 4/14 

simulation. The comparison of experimental and simulated IDS-VGS curves are shown in Fig. 4b, which have similar trends. The curves negative shifts as VDS becomes more negative, which calls DIBL in small size transistors. The SS in simulation is slightly lower than that in experiment and the ON state current is slighter higher, which is due to the idealized materials and interfaces in the simulation. The electron density and band diagram of ON (VGS-VTH=1.5 V) and OFF (VGS-VTH=-0.5 V) state can demonstrate the ultra-thin 0.34 nm gate control ability. To have a better visibility, the circumstances of MoS2 channel along the side-wall are shown in Fig. 4c-d and Fig. S6. In the OFF state (Fig. 4c), there is a region of low electron density. The location that graphene edge gate counterparts does not possess the lowest electron density because of the electric �eld contributing from the 2D planar surface (Fig. S5). Meanwhile, the reduced electron density (Fig. 4c) and EF (Fig. S6a) shifts downward also veri�es the e�cient gate control. The extension region is still at high electron density due to the controlling of global back gate. The effective channel length (Leff) is de�ned as the channel region with electron density n<nthreshold (nthreshold=1.3×10<sup>5</sup> cm<sup>-2</sup> ) (19), therefore the ~13 nm side-wall MoS2 channel close to the graphene plane can be regarded as effective channel. In the ON state (Fig. 4d & Fig. S6b), the whole MoS2 channel is at relative high electron density. Therefore, the Leff can be regarded as Lg, which is approaching physical limitation. 

As the Lg reaching the physical limitation, the semiconductor thickness is also required to be scaling down to atomic level, in order to minimize the SCEs<sup>20</sup> . Therefore, MoS2 layer dependent IDS-VGS characteristic of the 0.34 nm gate-length side-wall transistor has also been simulated (Fig. 4e). With the thickness of MoS2 channel increases from 0.65 nm (1 layer) to 20.8 nm (32 layers), although the ON state current improves for thicker MoS2, the channel can not be completely depleted at the same VGS-VTH, both the ON/OFF current ratio and SS become undesirable. Besides, atomic layer MoS2 channel is suitable for scalable production, which is promising for next generation electronics. 

Realization of small size transistors is a critical demand. The iterative progresses of gate length as a function of time line is shown in Fig. 4f<sup>14,21-33</sup> . From 2D planar device to 3D FinFET and further GAAFET, the structure of Si transistors gradually changes with better gate control ability. In the meantime, low dimensional materials come into sight, SWCNT gated MoS2 transistor reached the smallest physical node 1 nm in 2016 and the gate length has been leveling off for 4 years. Our work promotes the side-wall structure and realizes atomic thickness material gating atomic channel. The side-wall structure utilized the naturally thickness direction, and 0.34 nm in this work is the ultimate gate length to date. Wafer-level 2D CVD monolayer materials can also be realized for future logic and circuit integration. This work shed the light of the Moore’s law going down to 0.34 nm node. 

2D materials provides us opportunities to scale down the electron device to atomic level. TMDCs show good resistance to SCEs and graphene has high electrical conductivity and ultra-thin thickness. In this work, MoS2 and the edge of graphene act as channel and gate respectively, which realized ultimate 0.34 nm gate length side-wall transistors. The side-wall structure effectively utilizes the nature ultrathin 

Page 5/14 

thickness of graphene and shows the wafer-scale production. The ON/OFF current ratio and SS value could reach 2×10<sup>5</sup> and 210 mV/dec. Further scaling down EOT, improving the MoS2 �lm quality and developing ideal contacts to MoS2 are essential for device performance enhancement. Nevertheless, this work promotes a new insight to scale down the transistors approaching physical limitation and shed light on next generation electronics. 

- (1) CVD growth of graphene and MoS2: 

i. Monolayer graphene growth on Cu: 

The 3 cm×3 cm CVD monolayer graphene on Cu was bought from Hefei Vigon Material Technology Co., LTD. The monolayer graphene coverage is higher than 99%. 

ii. Monolayer MoS2 growth on Si/SiO2: 

MoO3 powder (Alfa Aesar 99.95%) contained in a ceramic crucible and adequate sulfur powder (Alfa Aesar, 99.999%) was placed in Zone 2 and at the upstream of furnace in Zone 1, respectively. Cleaned Si/SiO2 substrate was placed on the crucible. After purge 300 sccm Ar gas 20 min as carrier gas, the growth temperature for the sulfur and MoO3 precursors was 180 ℃ and 650 ℃, respectively. Continuous monolayer MoS2 �lm was synthesized at room pressure with 10 min sul�dation time. 

(2) Wet transfer of graphene and MoS2: 

i. Graphene wet transfer: PMMA was �rst spin coated on Cu/graphene. Dilute hydrochloric acid (HCl) solution with 20% mass fraction was used to etch supported Cu layer. After Cu was completely etched, graphene/PMMA was transferred to the target sample. Further 85 ℃, 60 min annealing can enhance the adhesion between graphene and substrate. PMMA was removed by acetone for more than 30 min soaking. 

ii. MoS2 wet transfer: PMMA was �rst spin coated on Si/SiO2/MoS2. Potassium hydroxide (KOH) solution with 3% mass fraction was used to lift off MoS2/PMMA from the Si/SiO2 Then, MoS2/PMMA was transferred to the target sample. Further 85 ℃, 60 min annealing can enhance the adhesion between MoS2 and substrate. PMMA was removed by acetone for more than 30 min soaking. 

(3) SEM (scanning electron microscopy) imaging was performed by Quanta FEG 450 �eld emission scanning electron microscope (FESEM). A 10 kV accelerating voltage was used for imaging the MoS2 channel and contacted metal. 

Page 6/14 

(4) TEM (transmission electron microscopy) and EDS (energy dispersive spectroscopy) imaging was performed by Themis Z (Thermo Scienti�c) with a Super-X (Thermo Scienti�c) EDS system. The system operated at 200 kV accelerating voltage. TEM was carried out with a 23.8 mrad convergence angle electron beam and the collection angle was set to 90-370 mrad. The sample was �rst deposited carbon by electron-beam and Pt by ion-beam to protect the surface from the damage of the ion-beam. 

(5) Electrical measurements were performed under vacuum (~10<sup>-5</sup> mbar) in Lakeshore vacuum probe station with Agilent Technologies B1500A Semiconductor Device Analyzer. 



<!-- Start of picture text -->
Declarations<br>Acknowledgments:<br><!-- End of picture text -->

Funding: This work was supported in part by National Natural Science Foundation of China under Grant 62022047, 61874065 and Grant 51861145202, in part by the National Key R&D Program under Grant 2016YFA0200400, in part by Young Elite Scientists Sponsorship Program by CAST under Grant 2018QNRC001, and in part by Fok Ying-Tong Education Foundation under Grant 171051, in part by the Research Fund from Beijing Innovation Center for Future Chip and the Independent Research Program of Tsinghua University under Grant 20193080047. 

Authors contributions: H. T. proposed the idea and the project, H. T. and F. W. designed the experiment, Y. S. performed the simulation, F. W., Y. S., and H. T. contributed equally to this work., F. W., G. G. and R. J. performed the device fabrication and characterization. Y. Y. provided suggestions to the manuscript, H. T. and T.-L. R. supervised the project. All the authors discussed the results and commented on the manuscript. 

Competing interests: The authors declare no competing interests. 

Data and materials availability: All data needed to evaluate the conclusions in the manuscript are present in the manuscript or the supplementary materials. Additional datas are available upon request to the corresponding authors. 

1          Moore, G. E. Cramming More Components Onto Integrated Circuits. Proceedings of the IEEE 86, 8285 (1998). 

2          Chau, R., Doyle, B., Datta, S., Kavalieros, J. & Zhang, K. Integrated nanoelectronics for the future. Nat. Mater. 6, 810-812 (2007). 

Page 7/14 

3          Lundstrom, M. Moore's Law Forever? Science 299, 210 (2003). 

- 4          Cavin, R. K., Lugli, P. & Zhirnov, V. V. Science and Engineering Beyond Moore's Law. Proceedings of the IEEE 100, 1720-1749 (2012). 

5          Novoselov, K. S. et al. Electric Field Effect in Atomically Thin Carbon Films. Science 306, 666 (2004). 

6          Radisavljevic, B., Radenovic, A., Brivio, J., Giacometti, V. & Kis, A. Single-layer MoS2 transistors. Nat. Nanotechnol. 6, 147-150 (2011). 

7          Watanabe, K., Taniguchi, T. & Kanda, H. Direct-bandgap properties and evidence for ultraviolet lasing of hexagonal boron nitride single crystal. Nat. Mater. 3, 404-409 (2004). 

8          Marsden, A. J. et al. Electrical percolation in graphene–polymer composites. 2D Materials 5, 032003 (2018). 

9          Lee, S., Sohn, J., Jiang, Z., Chen, H.-Y. & Philip Wong, H. S. Metal oxide-resistive memory using graphene-edge electrodes. Nat. Commun. 6, 8407 (2015). 

10        Sohn, J., Lee, S., Jiang, Z., Chen, H. & Wong, H. P. Atomically thin graphene plane electrode for 3D RRAM. In: 2014 IEEE International Electron Devices Meeting. 5.3.1-5.3.4 (IEEE, 2014). 

11        Wickramaratne, D., Zahid, F. & Lake, R. K. Electronic and thermoelectric properties of few-layer transition metal dichalcogenides. The Journal of Chemical Physics 140, 124710 (2014). 

12        Yoon, Y., Ganapathi, K. & Salahuddin, S. How Good Can Monolayer MoS2 Transistors Be? Nano Lett. 11, 3768-3773 (2011). 

13        Dunlap, W. C. & Watters, R. L. Direct Measurement of the Dielectric Constants of Silicon and Germanium. Physical Review 92, 1396-1397 (1953). 

14        Xie, L. et al. Graphene-Contacted Ultrashort Channel Monolayer MoS2 Transistors. Adv. Mater. 29, 1702522 (2017). 

15        Akinwande, D. et al. Graphene and two-dimensional materials for silicon technology. Nature 573, 507-518 (2019). 

16        Liu, C. et al. Two-dimensional materials for next-generation computing technologies. Nat. Nanotechnol. 15, 545-557 (2020). 

17        Yu, Z. et al. Realization of Room-Temperature Phonon-Limited Carrier Transport in Monolayer MoS2 by Dielectric and Carrier Screening. Adv. Mater. 28, 547-552 (2016). 

Page 8/14 

18        Tseng, A. A., Kuan, C., Chen, C. D. & Ma, K. J. Electron beam lithography in nanoscale fabrication: recent development. IEEE Transactions on Electronics Packaging Manufacturing 26, 141-149 (2003). 

19        Desai, S. B. et al. MoS2 transistors with 1-nanometer gate lengths. Science 354, 99 (2016). 

20        Suzuki, K., Tanaka, T., Tosaka, Y., Horie, H. & Arimoto, Y. Scaling theory for double-gate SOI MOSFET's. IEEE Trans. Electron Devices 40, 2326-2329 (1993). 

21        Xuejue, H. et al. Sub 50-nm FinFET: PMOS. In: International Electron Devices Meeting 1999. Technical Digest. 67-70 (IEEE, 1999). 

22       Yang-Kyu, C. et al. Sub-20 nm CMOS FinFET technologies. In: International Electron Devices Meeting. Technical Digest (Cat. No.01CH37224). 19.11.11-19.11.14 (IEEE, 2001). 

23        Bin, Y. et al. FinFET scaling to 10 nm gate length. In: Digest. International Electron Devices Meeting. 251-254 (IEEE, 2002). 

24        Fu-Liang, Y. et al. 5nm-gate nanowire FinFET. In: Digest of Technical Papers. 2004 Symposium on VLSI Technology,. 196-197 (IEEE, 2004). 

25        Lee, H. et al. Sub-5nm All-Around Gate FinFET for Ultimate Scaling. In: 2006 Symposium on VLSI Technology, 2006. Digest of Technical Papers. 58-59 (IEEE, 2006). 

26        Yeo, K. H. et al. Gate-All-Around (GAA) Twin Silicon Nanowire MOSFET (TSNWFET) with 15 nm Length Gate and 4 nm Radius Nanowires. In: 2006 International Electron Devices Meeting. 1-4 (IEEE, 2006). 

27        Mertens, H. et al. Vertically stacked gate-all-around Si nanowire transistors: Key Process Optimizations and Ring Oscillator Demonstration. In: 2017 IEEE International Electron Devices Meeting (IEDM). 37.34.31-37.34.34 (IEEE, 2017). 

28        Franklin, A. D. et al. Sub-10 nm Carbon Nanotube Transistor. Nano Lett. 12, 758-762 (2012). 

29        Cao, Q., Tersoff, J., Farmer, D. B., Zhu, Y. & Han, S.-J. Carbon nanotube transistors scaled to a 40nanometer footprint. Science 356, 1369 (2017). 

30        Qiu, C. et al. Scaling carbon nanotube complementary transistors to 5-nm gate lengths. Science 355, 271 (2017). 

31        English, C. D., Smithe, K. K. H., Xu, R. L. & Pop, E. Approaching ballistic transport in monolayer MoS2 transistors with self-aligned 10 nm top gates. In: 2016 IEEE International Electron Devices Meeting (IEDM). 5.6.1-5.6.4 (IEEE, 2016). 

Page 9/14 

32        Jiang, J. et al. Ultrashort Vertical-Channel van der Waals Semiconductor Transistors. Advanced Science 7, 1902964 (2020). 

33        Zou, X., Liu, L., Xu, J., Wang, H. & Tang, W.-M. Few-Layered MoS2 Field-Effect Transistors with a Vertical Channel of Sub-10 nm. ACS Appl. Mater. Interfaces 12, 32943-32950 (2020). 



Comparison of the 0.34 nm Lg side-wall transistor with other typical structure transistors. (a) Back (global) gate structure. (b) Top gate structure. (c) 1 nm SWCNT buried gate structure19. (d) Our side-wall transistor with the edge of graphene as gate electrode. (e) The physical limitation of gate length under different gate and channel conditions. 

Page 10/14 



0.34 nm gate-length side-wall monolayer MoS2 transistor device structure and characterization. (a) Schematic of side-wall gate structure with a monolayer MoS2 channel and 0.34 nm monolayer graphene edge gate. (b) Process �ow for the device fabrication. (c) False-colored SEM image of the device showing the HfO2 gate dielectric (green), Al screening layer (purple), monolayer MoS2 channel (yellow), and the Ti/Pd source and drain electrodes (blue). (d) Cross-sectional TEM image of a representative sample showing the monolayer graphene edge gate, HfO2 gate dielectric, Al screening layer and monolayer MoS2 channel. (e) EDS mapping showing the spatial distribution of aluminum, hafnium, carbon, molybdenum, sulfur and oxygen in the device region, con�rming the location of the Al screening layer, HfO2 dielectric, monolayer graphene, and MoS2 �lm. (f) Optical image of a 2-inch wafer 0.34 nm Lg side-wall transistor array. 

Page 11/14 



Electrical characterization. (a) IDS-VGS characteristics at VBS = 50 V and VDS = -50 mV, -1 V, -2 V, -3 V. The leakage current from back gate and graphene edge gate are also shown. (b) IDS-VDS characteristics at VBS= 50 V and VGS varies from -2 V to 4 V at small VDS value. (c) IDS-VGS characteristics at VDS = -1 V and varying VBS illustrating the effect of back-gate bias on the extension region resistance, on-state current, and device characteristics. (d) IDS-VGS characteristics of three devices at VBS= 50 V and VDS=-1 V. (e) The variation of devices in one batch. The data are extracted from IDS-VGS curve at VDS=-1 V. 

Page 12/14 



TCAD simulation results and benchmark. (a) Simulated structure. (b) The comparison between experimental and simulated IDS-VGS curve. The VTH values are extracted at VDS=-1 V. The electron density of MoS2 channel along side-wall at the OFF state (c) and ON state (d). The graphene edge gate can effectively turn off the device due to the 2D planar characteristic. The effective channel length (Leff) is ~13 nm in OFF state and 0.34 nm (≈Lg) in ON state. (e) The MoS2 layer dependent IDS-VGS curve in 

Page 13/14 

this simulated side-wall transistor. Monolayer MoS2 channel has the lower SS value comparing to that of thicker MoS2 and suitable ON/OFF current ratio. (f) A time scale evolution of Lg. This work is marked by the red star, which promotes the Lg scales down to atomic limit. 

This is a list of supplementary �les associated with this preprint. Click to download. 

SupplementaryMaterials20201201.docx 

Page 14/14 

