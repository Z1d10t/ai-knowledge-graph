# Hybrid Plasmonic Nanomaterials for Hydrogen Generation and Carbon Dioxide Reduction

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | ACS Energy Letters |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 204 |
| 作者 | S. Ezendam, Matias Herran, Lin Nan, Christoph Gruber, Yicui Kang, Franz Gröbmeyer, R. Lin, J. Gargiulo et al. |
| DOI | 10.1021/acsenergylett.1c02241 |
| 源文件 | 048_Ezendam_2022_Hybrid-Plasmonic-Nanomaterials-for-Hydrogen-Gene.pdf |

---


http://pubs.acs.org/journal/aelccp 

### Hybrid Plasmonic Nanomaterials for Hydrogen Generation and Carbon Dioxide Reduction 

Simone Ezendam, Matias Herran, Lin Nan, Christoph Gruber, Yicui Kang, Franz Gröbmeyer, Rui Lin, Julian Gargiulo, Ana Sousa-Castillo, and Emiliano Cortés* 

Cite This: ACS Energy Lett. 2022, 7, 778−815 Metrics & More 

#### ACCESS 

Read Online 

Article Recommendations 

ABSTRACT: The successful development of artificial photosynthesis requires finding new materials able to efficiently harvest sunlight and catalyze hydrogen generation and carbon dioxide reduction reactions. Plasmonic nanoparticles are promising candidates for these tasks, due to their ability to confine solar energy into molecular regions. Here, we review recent developments in hybrid plasmonic photocatalysis, including the combination of plasmonic nanomaterials with catalytic metals, semiconductors, perovskites, 2D materials, metal−organic frameworks, and electrochemical cells. We perform a quantitative comparison of the demonstrated activity and selectivity of these materials for solar fuel generation in the liquid phase. In this way, we critically assess the state-of-the-art of hybrid plasmonic photocatalysts for solar fuel production, allowing its benchmarking against other existing heterogeneous catalysts. Our analysis allows 



the identification of the best performing plasmonic systems, useful to design a new generation of plasmonic catalysts. 

# O 

ver the past two centuries, the rapid and continuing increase in energy consumption has led to a global O energy and climate crisis. In the past few decades, almost 75% of human-caused carbon dioxide (CO2) emissions were a result of burning fossil fuels.<sup>1</sup> Yet, to this date their share makes up more than 80% of the energy mix.<sup>2</sup> It is evident that a transformation toward renewable energy sources is urgently needed. For millions of years, nature has used the sun as its primary energy source by photosynthesis during which sunlight is used to split water and produce energy-rich chemical compounds from CO2. Taking inspiration from this, artificial photosynthesis has become one of the most important research fields in the past decade. It consists mainly of two types of processes: one is water-splitting into hydrogen (H2) and oxygen (O2) or the H2 production from H2containing compounds, and the other is the reduction of CO2 into fuels and chemicals, such as carbon monoxide, hydrocarbons, and oxygenates. These products are generally referred to as solar fuels. 

In artificial photosynthesis, the first step is to harvest and concentrate the solar energy in molecular-sized regions. Plasmonic nanoparticles (PNPs) are promising materials to perform these tasks, due to their exceptional absorption and their ability to control light and heat at the nanoscale.<sup>3−6</sup> Therefore, the inclusion of a plasmonic material into a 

multicomponent nanostructure can greatly enhance its photocatalytic performance compared to the individual components. In recent years, an increasing number of these so-called hybrid plasmonic nanostructures have been investigated for chemical reactions, giving rise to the field of plasmon-assisted catalysis.<sup>7−12</sup> 

Despite being a young field, there are already several reviews,<sup>13−15</sup> perspectives,<sup>16−18</sup> and even a book<sup>19</sup> covering different topics of the area. Some focus on the theoretical aspects and the working mechanisms of plasmonic photocatalysis.<sup>20−22</sup> Others discuss reactions driven by a particular plasmon-induced phenomenon such as hot-carrier generation,<sup>23</sup> photothermal effects<sup>24</sup> or both.<sup>25</sup> Furthermore, Devasia et al. focus on the possibility of controlling reaction pathways with plasmonic systems.<sup>26</sup> Finally, some reviews focus on particular reactions, such as the applications of plasmonic catalysts to organic transformations<sup>27</sup> or the CO2 reduction 



Received: October 14, 2021 Accepted: January 7, 2022 Published: January 24, 2022 

© 2022 The Authors. Published by American Chemical Society 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

778 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

reaction (CO2RR).<sup>28</sup> Among the reviews on plasmon-assisted catalysis there are few on hybrid systems, so far mostly limited to bimetallic or plasmonic metal−semiconductor systems.<sup>29−33</sup> 

##### In artificial photosynthesis, the first step is to harvest and concentrate the solar energy in molecular-sized regions. 

After around 10 years of exponential growth of the field, it is necessary to benchmark plasmonic materials for catalysis, not only among them but also against other existing heterogeneous catalysts for solar fuel production. This could give a real dimension of the improvements and achievements so far while showing the potential of this new type of heterogeneous (photo)catalysis in the quest of sustainable catalysis and clean energy production. Here, we will center on the considerable advances in the development of hybrid nanomaterials toward the production of solar fuels via plasmon excitation in the liquid phase. Many systems with great potential have been investigated for plasmonic catalysis in the gas phase.<sup>9,11,25,34−40</sup> However, in this Review, we are limiting the examples to reactions under mild reaction conditions (i.e., heterogeneous catalysis in the liquid phase). In addition, we will narrow the scope of this Review to the reactions that are relevant for solar fuel production, namely H2 generation and CO2 reduction, but we will be as broad as possible regarding the evaluation of different types of novel hybrid systems, i.e., not only limited to metals and semiconductors but also including plasmonic hybrids with perovskites, 2D materials, and metal−organic frameworks for both pure photocatalysis and photoelectrocatalysis. With the increasing complexity and diversity of hybrid plasmonic nanostructures comes the necessity of a quantitative comparison among them. Here, we propose a series of standard metrics that should be reported for future plasmonic catalysts. Identifying the best performers is essential 

to design future plasmonic platforms for solar fuel production. That is the scope of this Review. 

We first briefly elaborate on the motivation to employ plasmonic materials for photo(electro)catalysis and enumerate the enhanced properties that can be obtained in hybrid nanostructures. Second, we describe the reactions to produce solar fuels that are the focus of interest of this Review. These are the reactions toward CO2 reduction and H2 generation. Third, we present the performance metrics that will be used to compare different materials/systems. In the main section, recent developments in each of the hybrid systems are reviewed. Last, in the Discussion section, the systems are summarized and compared for each reaction in a concluding meta-analysis. 

## ■<sup>PROPERTIESOFHYBRIDPLASMONIC</sup> NANOMATERIALS 

PNPs interact strongly with light through the excitation of localized surface plasmon resonances (LSPRs), which correspond to the coherent oscillations of their free electrons coupled to the electromagnetic field.<sup>3</sup> Plasmonic materials are typically metals with negative real permittivity (i.e., with high concentration of free electrons) such as silver, gold, copper, etc. The plasmon resonances are highly tunable, and their frequency can cover the ultraviolet (UV), visible, and nearinfrared (NIR) regions of the electromagnetic spectrum (i.e., the totality of solar emission).<sup>5</sup> When resonantly illuminated, the absorption cross sections of PNPs reach tens of times their geometrical size, making them efficient harvesters of light. In addition, PNPs can act as solar light antennas. They can concentrate light in small volumes of typically a few nm<sup>3</sup> near their surface, where the intensity can reach values as high as 10<sup>5</sup> the solar one.<sup>4</sup> That volume is on the order of molecular sizes, transforming the PNPs into nanoreactors within molecular scales. 



Figure 1. Hybrid plasmonic photocatalysts. (Top) Overview of the hybrid plasmonic systems that are the topic of this Review. From left to right: metal, semiconductor, perovskite, 2D, MOF, and electrochemistry. (Bottom) Desirable properties of an ideal photocatalyst. The plasmonic component can harvest light and transfer the energy through charge carriers, heat, and electromagnetic fields. Non-plasmonic materials can add or enhance catalytic properties. The hybrid system can show enhanced stability, selectivity, or activity through various mechanisms, e.g., effective charge transfer, surface chemistry, or enhanced absorption. 

779 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

There is a variety of plasmon-driven processes that can affect the activity and selectivity of target molecules.<sup>20,41</sup> Plasmon resonances are of mixed optoelectronic nature, and as such, the energy from incoming light is partly stored in the kinetic energy of charge carriers and in the electromagnetic field. These resonances can decay radiatively or transfer their energy to a charge carrier. This highly energetic charge carrier then relaxes, during which secondary and lower energy charge carriers are excited, and ultimately heat is released to the surrounding of the PNPs. This means that a resonantly illuminated PNP can supply a broad range of energy quanta, from highly energetic charge carriers with the energy of the incoming photons (∼2−3 eV) to thermal phonons (∼0.025 eV). A nearby molecule or material can use these energy quanta to perform a chemical transformation in thermal or non-thermal ways. The versatility of plasmon-driven processes offers the opportunity to obtain alternative reaction pathways toward a desired but kinetically or thermodynamically unfavorable product. For example, they can operate in a particular intermediate step of a reaction, altering the pathway toward a different product.<sup>42,43</sup> 

However, the catalytic activity of typical plasmonic metals (Au, Ag, Cu, etc.) for solar fuel production is comparatively low.<sup>44,45</sup> In recent years, plasmonic components have been interfaced with other nanomaterials, searching for superior hybrid plasmonic nanocatalysts. These hybrid plasmonic catalysts are summarized in the top half of Figure 1. The promising properties of PNPs are combined with additional enhanced photocatalytic properties from the second material that are in many cases not present in the single-component counterparts. The bottom half of Figure 1 schematizes some of the properties that are desirable (and potentially obtainable) in a hybrid plasmonic catalyst. While the plasmonic component harvests light and supplies energy through charge carriers, heat, or electromagnetic fields, a second (non-plasmonic) component can, for example, improve the interaction with target molecules, enhance the stability of the system or enlarge the lifetime of excited carriers. In the following, we present the particular opportunities that each material/interface opens for plasmonic catalysis. 

Plasmonic Metal−Metal. The catalytic activity of plasmonic metals can be improved by combining plasmonic metals with common catalytically active metals such as palladium, platinum, rhodium, etc. The inclusion of such metals can help lower the activation energy of a reaction step or enhance the adsorption/desorption dynamics of reactants/ products on the surface of the nanocatalyst. In addition, combining the two metals modifies the electronic energy bands close to their interface, potentially facilitating charge flow, reducing the chemical potential of the charge carriers, and enhancing their extraction.<sup>46</sup> In bimetallic systems, the decay of plasmon resonances gets altered, favoring non-radiative (excitation of carriers, heat generation) versus radiative channels (scattering).<sup>47−49</sup> Interestingly, the spatial distribution of absorption can be shifted toward the catalytic metal generating carriers exactly where they are more reactive.<sup>38,50,51</sup> 

Plasmonic Metal−Semiconductor. The lifetime of photoexcited charge carriers in plasmonic metals is typically less than 1 ps.<sup>52,53</sup> This time is usually too short for the carriers to act on an adsorbate, a detrimental fact for the overall reactivity of the system. Longer charge carrier lifetimes can be attained by interfacing the metal with a semiconductor. The decay of the plasmon can generate charge carriers in the 

semiconductor through three main mechanisms. First, photoexcited electrons in the metal with sufficient energy can be transferred across the Schottky barrier<sup>54</sup> to the conduction band of the semiconductor, in a process called indirect electron transfer.<sup>24,55</sup> Second, a plasmon can decay by directly exciting an electron into the conduction band of the semiconductor and a hole in the metal, in a process called plasmon-induced charge-transfer transition<sup>55</sup> or direct electron transfer.<sup>13,56</sup> The third mechanism is a plasmon-induced resonant energy transfer,<sup>57,58</sup> where an electron−hole pair is excited in the semiconductor. The presence of a Schottky barrier at a metal/ semiconductor interface<sup>54</sup> traps electrons and prevents or delays them from coming back to the metal.<sup>55</sup> The lifetime, just like the indirect electron injection across the barrier, depends on the potential difference and a trade-off has to be made between the harvesting and recombination of carriers.<sup>59,60</sup> Furthermore, structural defects and/or vacancies in the semiconductor can also act as electron traps, enhancing their lifetime, and are usually the most reactive sites.<sup>61</sup> These processes allow electrons to become available in the semiconductor to drive reduction reactions while holes remain in the metal for oxidation reactions.<sup>13</sup> Inversely, there have also been demonstrations of semiconductors harvesting the holes.<sup>40,62</sup> Without the photoexcited electrons in the plasmonic metal, wide bandgap semiconductors like titanium dioxide (TiO2) are photocatalytically active only in the UV. The energy transfer mechanisms from the plasmonic material to the semiconductor extend their operational wavelength range, accommodating a larger fraction of the solar spectrum and potentially increasing the solar-to-fuel conversion efficiency.<sup>63,64</sup> 

Plasmonic Metal−Perovskite. Perovskites are a versatile subclass of semiconductors with attractive optoelectronic and catalytic properties. They are characterized by their ABX3 crystal structure, where A and B represent cations and X an anion (see Figure 4a, below). As semiconductors, the physical and chemical properties of perovskites leading to a catalytic enhancement are generally as described above. This is especially true for ABO3-type perovskite oxides, which are cost efficient and can accommodate a wide range of substituting and doping elements to modulate their electronic and catalytic properties but are generally photocatalytically active only under UV irradiation owing to their wide bandgap. Their combination with plasmonic materials allows the absorption of visible light, making irradiation of wavelengths with photon energies below the bandgap of the perovskite accessible.<sup>65−68</sup> Both charge or energy transfer from the plasmonic material to the perovskite can occur.<sup>69,70</sup> The perovskite oxides are in many ways very similar to semiconductors included in the general semiconductor section; However, the perovskite category is included in this Review due to a second type of perovskite, namely ABX3-type perovskite halides (X = F, Cl, Br, I). They have a tunable absorption across the entire visible spectrum<sup>71</sup> as well as long carrier lifetimes.<sup>72</sup> In addition to the benefits discussed above, by combining perovskite halides and plasmonic materials, the characteristic absorption spectra of both components can be matched such that the strong near-field enhancement of the PNP can significantly enhance the absorption of light by the halide perovskite, potentially boosting their catalytic performance. 

Plasmonic Metal−2D. A 2D material is the co-catalyst with the largest possible available surface. Of particular interest 

780 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

are materials with outstanding electrical conductivity and mobility, such as carbon-based 2D and transitional metal-based 2D materials. The photogenerated electrons in the PNPs can transfer to the 2D material, where they benefit from a larger lifetime fostering substrate reactivity.<sup>73</sup> Furthermore, electrons can accumulate in the 2D material or promote the formation of charged excitons (with more than one electron coupled to a hole).<sup>74,75</sup> This accumulation facilitates reactions that require multiple electrons. Finally, the presence of defects, dopants, or oxygenated functional groups in the 2D material can act as catalytic sites for specific reactions.<sup>76</sup> 

Plasmonic Metal−MOFs. Metal−organic frameworks (MOFs) are ordered periodic structures formed by nodes of metal ions linked by organic ligands.<sup>77−79</sup> Plasmonic materials can gain interesting properties relevant to catalysis when combined with this versatile class of porous materials.<sup>80−84</sup> First, MOFs can act as substrates, providing support and increasing stability.<sup>85</sup> Second, they are highly versatile in composition and pore size, allowing structural tailoring according to the application. For example, their organic linker can be adjusted to catalyze a specific reaction or co-reaction.<sup>86</sup> This property makes them promising systems to achieve high selectivity of product formation. Third, they can be structurally designed so that their catalytic centers lie in the near-field enhancement region of the plasmonic component, enhancing their absorption.<sup>85</sup> Fourth, their high porosity can allow an extraordinarily large surface area for a reaction to occur<sup>87</sup> or the preconcentration of reactants next to the PNPs.<sup>88</sup> Finally, MOFs can also act as a charge carrier mediator to enhance the electron−hole pair separation efficiency.<sup>89</sup> 

Plasmon-Assisted Electrochemistry. Electrocatalysis, like photocatalysis, has been studied extensively in recent years.<sup>90</sup> While promising, electrochemical reactions often require high overpotentials. Plasmonic materials can enhance the performance of electrocatalytic systems by utilizing the solar energy. This can result in lower electrical energy consumption and higher product formation, which manifest as a reduced overpotential or increased current density.<sup>91−93</sup> The introduction of a plasmonic material can also modify the chemical landscape, which can affect selectivity by triggering or enhancing otherwise thermodynamically and/or kinetically hindered reactions.<sup>94</sup> 

## ■<sup>PLASMON-ASSISTEDREACTIONSTOWARD</sup> SOLAR FUEL GENERATION 

In this Review, we discuss hybrid photocatalysts with at least one plasmonic component that is resonantly illuminated. This excludes, for example, systems where the presence of a plasmonic metal can have a positive impact on the catalytic activity of the system but is either not illuminated or illuminated in a region with negligible absorption.<sup>95,96</sup> It should be noted that we consider both photocatalytic processes (typically thermodynamically favorable, ΔG < 0, with G the Gibbs free energy) and photosynthetic processes (thermodynamically unfavorable, ΔG > 0) as plasmon-assisted reactions. For simplicity, they will from here on be referred to as photocatalytic. Among the large list of recently demonstrated plasmon-assisted reactions, we focus on a few particularly relevant reactions toward the generation of solar fuels: H2 generation reactions and CO2RRs, as described below and summarized in Table 1. 

Hydrogen Generation. Because hydrogen can be burned with no greenhouse emissions, it is a promising candidate to 

###### Table 1. Reactions toward Solar Fuel Production 

|reaction|fuel|
|---|---|
|H2 Production||
|NH3BH3 + 3H2O →NH4B(OH) + 3H2<br>(ammonia borane hydrolytic dehydrogenation)|hydrogen|
|NaBH4 + 4H2O →NaB(OH)<sup>4 </sup>+ 4H2<br>(sodium borohydride hydrolytic dehydrogenation)|hydrogen|
|HCOOH →CO2 + H2 (formic acid dehydrogenation)|hydrogen|
|2H2O + 4e<sup>−</sup>→2O2 + H2 (water-splitting)|hydrogen|
|CO2 Reduction||
|CO2 + 2H<sup>+ </sup>+ 2e<sup>−</sup>→CO + H2O|carbon<br>monoxide|
|CO2 + 2H<sup>+ </sup>+ 2e<sup>−</sup>→HCOOH|formic acid|
|CO2 + 4H<sup>+ </sup>+ 4e<sup>−</sup>→HCHO + H2O|formaldehyde|
|CO2 + 6H<sup>+ </sup>+ 6e<sup>−</sup>→CH3OH + H2O|methanol|
|CO2 + 8H<sup>+ </sup>+ 8e<sup>−</sup>→CH4 + 2H2O|methane|
|2CO2 + 12H<sup>+ </sup>+ 12e<sup>−</sup>→C2H5OH + 3H2O|ethanol|



replace fossil fuels. Hydrogen has a high gravimetric energy density of 33.3 kW h kg<sup>−1</sup> , which is almost 3 times higher than that of gasoline (12.4 kW h kg<sup>−1</sup> ).<sup>97,98</sup> It is stable and can be liquefied, stored, or transported through pipelines. However, the majority of hydrogen is still produced from fossil fuels, resulting in excessive carbon emissions.<sup>99</sup> For hydrogen to become a sustainable fuel, it has to be produced from renewable energy sources. 

Among the recently demonstrated plasmon-assisted reactions, we focus on a few particularly relevant reactions toward the generation of solar fuels: H2 generation reactions and CO2 reduction reactions. 

Photocatalytic hydrogen sources can be categorized as follows: (1) Water. Solar hydrogen production via watersplitting is especially attractive, as both water and sunlight are abundant. Materials for photocatalytic water-splitting are either investigated toward their performance of full water-splitting, where H2 and O2 evolution should occur in a stoichiometric 2:1 ratio, or by using a sacrificial hole acceptor, for only the hydrogen evolution reaction (HER). This simplifies research and prevents charge recombination. However, this sacrificial agent should also be cheap and abundant, as otherwise this could become a new bottleneck for the reaction to be scaled up. (2) Other hydrogen-containing compounds. While hydrogen has a high energy content per mass, its energy content per volume is poor. This makes storing enough hydrogen, e.g., onboard of means of transport, difficult. A possible solution is the chemical storage in compounds with a higher storage density. This has resulted in compounds with a high hydrogen content like formic acid (HCOOH),<sup>100</sup> ammonia borane (NH3BH3),<sup>101</sup> or sodium borohydride (NaBH4)<sup>102</sup> gaining attention, especially for mobile and portable applications. 

Carbon Dioxide Reduction. Carbon dioxide (CO2) is one of the main greenhouse gases contributing to climate change.<sup>103</sup> CO2 conversion can have the two-fold benefit of decreasing its atmospheric concentration while also producing fuels. Compared to hydrogen production, the reactions for CO2 conversion are much more complex, as a variety of 

781 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

reaction pathways coexist. Possible products include carbon monoxide (CO), formic acid (HCOOH), methane (CH4), methanol (CH3OH), ethane (C2H6), propane (C3H8), and ethanol (CH3CH2OH), among others. These products require a different number of charge transfers, as shown in Table 1, and contain different numbers of carbon. Products with two or more carbon atoms, so-called C2+ products, are desirable but difficult to produce. Several steps can be involved, leading to the possibility of branching reaction pathways and various products being produced simultaneously. Therefore, a suitable large-scale photocatalyst for CO2 reduction should not only present a high efficiency but also a high selectivity to one product. In this Review, we will quantitatively evaluate the prospect of using hybrid plasmonics toward these goals. 

## ■<sup>PERFORMANCEMETRICS</sup> 

The main challenge when comparing different hybrid nanocatalysts is to find quantitative and relevant performance metrics. Different aspects of a catalyst performance may be evaluated, such as its activity, selectivity, stability, or temperature of operation. However, it is not straightforward to determine metrics depending only on the nanocatalyst’s intrinsic properties because its performance may be strongly altered by reaction conditions such as the illumination characteristics or reactant concentration. The typically reported performance metrics used in the field are discussed below. Table 2 summarizes the metrics that will be extracted from the original publications and written in tables for comparison. 

Table 2. Performance Metrics for Hybrid Plasmonic Catalysts That Are Used in This Review 

||photocatalysts|photoelectrocatalysts|
|---|---|---|
|activity|formation rate<br>[μmol g<sup>−1 </sup>h<sup>−1</sup>]<br>apparent quantum<br>efficiency (AQE) [%]|overpotential [mV] @ current<br>density of 10 mA cm<sup>−2</sup><br>onset potential [mV]<br>Tafel slope [mV dec<sup>−1</sup>]|
|selectivity|selectivity [%]|Faradaic efficiency (FE) [%]|
|stability|stability [h]<br>duration [h]|stability [h]<br>duration [h]|
|temperature|reactor temp [°C]|reactor temp [°C]|
|light<br>enhancement,<br>plasmonic<br>enhancement|activity enhancement<br>factor (LE,PE)|shift in operation point [ΔmV<br>or ΔmV dec<sup>−1</sup>]|



##### The main challenge when comparing different hybrid nanocatalysts is to find quantitative and relevant performance metrics. 

Activity is quantified by the formation rate of a product (amount of generated product per time per mass of hybrid catalyst, eq 1). It must be noted that this metric assumes a linear relation of product formation with respect to time and catalyst concentration, which is often not the case.<sup>104</sup> 



<!-- Start of picture text -->
n product [μmol]<br>R =<br>masshybrid catalyst [g] × time [h] (1)<br><!-- End of picture text -->

In this Review, we will use the formation rate (eq 1) as the main metric for activity, as it is most commonly reported. If it is not possible to extract the formation rate, the turnover frequency (TOF) or turnover number (TON = TOF × time) is reported in the tables. Across the literature, the TOF is used with conflicting definitions. In hybrid nanomaterials where the reaction occurs in only one of the components, the number of catalytic sites might be used instead of the total mass of the catalyst. This value is rarely reported as it is difficult to determine because the information on the number of active catalytic sites is not always available or might fluctuate in time. Instead, TOF is more commonly referred to as the mole of product molecules per mole of catalyst per time (eq 2). 



<!-- Start of picture text -->
n product [mol]<br>TOF =<br>n hybrid catalyst [mol] × time [min] (2)<br><!-- End of picture text -->

The key role of illumination in plasmon-assisted catalysis is not reflected in the activity metrics discussed so far. Therefore, the quantum efficiency (QE) should be used as a complementary metric (eq 3).<sup>105</sup> It is defined as the number of reacted electrons per absorbed photon and determined for a specific wavelength. Whenever a quantum efficiency is reported, it is usually the apparent quantum efficiency (AQE), defined as the number of reacted electrons per incident photon (eq 4). This is the case because the number of absorbed photons is often difficult to determine. The AQE is a lower bound for the QE and will be used in this Review whenever it is reported. 



<!-- Start of picture text -->
N reacted electrons<br>QE = × 100%<br>N<br>absorbed photons (3)<br><!-- End of picture text -->



<!-- Start of picture text -->
N reacted electrons<br>AQE = × 100%<br>N<br>incident photons (4)<br><!-- End of picture text -->

In photoelectrocatalysis, the metrics reported are different from the ones for photocatalysis. A metric for the activity is the overpotential (mV) at a given current density (mA cm<sup>−2</sup> ) (or vice versa). The onset potential (mV), the potential at which the reaction starts to occur, describes the reaction energy barrier. Finally, the Tafel slope (mV dec<sup>−1</sup> ), obtained by plotting the overpotential as a function of the logarithm of the current density, is used to estimate the reaction kinetics of the system. 

Selectivity is a major concern for CO2 conversion. For photocatalytic systems, it is generally reported as the ratio between the formation rate of the major product and all products in percent (eq 5). 



<!-- Start of picture text -->
n major product<br>selectivity = × 100%<br>n all products (5)<br><!-- End of picture text -->

For electrocatalytic systems, the Faradaic efficiency (FE) is more commonly reported. It describes the proportion of reacted electrons facilitating the formation of a certain product. The stability of the catalyst is referred to as the longest investigated time under operando conditions in which its activity did not significantly decrease. Whenever the stability was not examined, the experiment duration is reported in the table instead. 

782 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 



Figure 2. Plasmonic metal−metal hybrids. (a) Illustration of bimetallic hybrids with different configurations. (b) Reaction-catalyst pairs. Au1Rh1 performed better toward NH3BH3 dehydrogenation, whereas Au1Ru1 performed better toward NaBH4 dehydrogenation. (c) STEMHAADF (i) and EDS (ii) images of Ag nanocubes (red) coated with an ultrathin Pd layer (green), employed on NH3BH3 dehydrogenation. Arrhenius plot in both dark and light. (d) TEM image of both Pd-covered (iii) and Pd-dotted (iv) Ag@Au nanohexagons and their performances toward FA dehydrogenation. (e) Extinction spectrum of ∼12 nm AuNPs used as catalyst in CO2RR. Top: cumulative number of product molecules generated per AuNP (TON) as a function of time under visible illumination (λ > 400 nm). Bottom: performance toward CO2RR under blue (λ = 488 nm) and green (λ = 532 nm) illumination as a function of power. (f) Top: STEM-HAADF (v) and TEM (vi) of Au colloidosomes utilized for CO2 reduction. Bottom: CH4 generation out of CO2 reduction for Au colloidosomes at different growth steps of AuNPs, varying its size and interparticle distance. (b) Adapted with permission from ref. 108. Copyright 2020 American Chemical Society. (c) Adapted with permission from ref. 109. Copyright 2020 American Chemical Society. (d) Adapted with permission from ref. 110 Copyright 2020 Elsevier. (e) Adapted with permission from ref. 111. Copyright 2018 American Chemical Society. (f) Adapted with permission from ref. 112. Copyright 2019 Royal Society of Chemistry. 

Temperature is an important parameter that modulates the rate of reactions through the Arrhenius law. Illuminated plasmonic systems offer the opportunity of driving reactions at mild conditions, without the need for high external temperatures. Here, whenever possible, the operating temperature of the reactor will be used as a metric. It must be noted that this value might strongly differ from the surface temperature of the nanocatalysts.<sup>106</sup> 

The light enhancement (LE) aims to quantify the contribution of light to a given reaction. When doing this, one should also compensate for the temperature increase upon illumination;<sup>107</sup> however, this is not frequently done. Here, it will therefore simply be estimated as the ratio between the activity (i.e., formation rate or TOF) of a nanocatalyst in the presence and in the absence of light. 

Similarly, the plasmonic enhancement (PE) is the activity ratio of the illuminated system in the presence and absence of the plasmonic component. In photoelectrocatalysis, the enhance- 

ments are evaluated as a shift in the overpotential at a current density of 10 mA cm<sup>−2</sup> of the reactions. 

In the following, we will review the latest demonstrations of hybrid plasmonic nanomaterials for solar fuel production. 

## ■<sup>PLASMONICMETAL−METAL</sup> 

In recent years, several configurations of hybrid plasmonic bimetallic nanoparticles ranging from alloys, core−shell, partially coated structures to self-assembled catalysts, have been employed to boost the H2 production and CO2 reduction through plasmon excitation (illustration in Figure 2a). A summary of these publications can be found in Table 3 and Table 4, including the performance metrics defined in the introduction, as well as their respective experimental conditions. In the following, we will describe selected examples on these topics. 

Plasmonic Metal−Metal Hybrids for H2 Generation. Toward more efficient photocatalytic H2 generation, plasmonic materials can benefit from the addition of late transition 

783 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

Table 3. Plasmonic Metal−Metal Hybrid Systems for H2 Generation 

|photocatalyst|light source|reaction|temp<br>(°C)|formation rate<br>(μmol g<sup>−1 </sup>h<sup>−1</sup>)|stability<br>(h)|AQE (%)|PE|LE|ref|
|---|---|---|---|---|---|---|---|---|---|
|||PNP−M|etal for H|2||||||
|Au1Rh1|7 W visible LED strips|NH3BH3<br>dehydrogenation|25|240 TOF (min<sup>−1</sup>)|>0.09<sup>a</sup>|−|2.4|2.8|108|
|Au1Pt1|7 W visible LED strips|NH3BH3<br>dehydrogenation|25|200 TOF (min<sup>−1</sup>)|>0.09<sup>a</sup>|−|1.8|2.7|108|
|Au1Ru1|7 W visible LED strips|NaBH4<br>dehydrogenation|25|178 TOF (min<sup>−1</sup>)|>0.42|−|2.2|3.8|108|
|Ag@Pd nanocubes|Xe lamp<br>(100 mW cm<sup>−2</sup>)|NH3BH3<br>dehydrogenation|40|102 × 10<sup>6 c</sup>|>10|−|−|1.2|109|
|Zn1.3Cu98.7|solar simulator<br>(788 mW cm<sup>−2</sup>)|H2O reduction<br>(MeOH)|−|328 × 10<sup>3</sup>|>4|7 (@<br>570 nm)|39|1.2|113|
|Pd-tipped Au nanorods<sup>e</sup>|300 W Xe lamp<br>(λ > 400 nm)|FA dehydrogenation|45|133 × 10<sup>3</sup>|−|−|2.5|−|114|
|Pd-dotted Ag@Au<br>hexagonal NPs|300 W Xe lamp<br>(λ > 420 nm)|FA dehydrogenation|50|113 × 10<sup>3 c</sup>|>8|−|−|4.5|110|
|Pd-tipped Au nanorods|300 W Xe lamp<br>(λ > 460 nm)|FA dehydrogenation|40|30 × 10<sup>3</sup>|−|−|−|3|115|
|Pd-covered Ag@Au<br>hexagonal NPs|300 W Xe lamp<br>(λ > 420 nm)|FA dehydrogenation|50|15 × 10<sup>3 c</sup>|>8|−|−|1.15|110|
|Au@Pd nanodog-bones|300 W Xe lamp|FA dehydrogenation|15|1050|>4<sup>a</sup>|−|b|d|116|
|Pt-edged Au nanoprisms|300 W Xe lamp<br>(λ > 420 nm)|H2O reduction<br>(MeOH)|−|0.167 μmol h<sup>−1</sup>|>6<sup>a</sup>|−|5|−|117|
|Pt-tipped Au nanoprisms|300 W Xe lamp<br>(λ > 420 nm)|H2O reduction<br>(MeOH)|−|0.031 μmol h<sup>−1</sup>|>6<sup>a</sup>|−|6.5|−|117|



aExperiment duration. bNegligible product detected without plasmonic material. cNormalized only by catalytic metal. dNegligible product detected without light.<sup>e</sup> Supported by magnetic field. 

metals. Engineering the materials to exploit both lightharvesting and catalytic properties is one of the utmost challenges for these so-called plasmonic bimetallic systems. Next, we outline recent relevant reports in which different configurations were investigated for H2 production. 

An important study on alloys, carried out by Kang et al., showed that the efficiency of the Au-based alloyed catalyst was dependent on both the chemical composition of the hybrid and the hydrogen source.<sup>108</sup> Specifically, in their article Au was alloyed with different metals (Rh, Ru, Pt, Pd, Co, and Ni), and the resulting catalysts were tested toward the hydrolytic dehydrogenation of both ammonia borane (NH3BH3) and sodium borohydride (NaBH4). The best performers for both reactions are illustrated in Figure 2b. For the photocatalytic hydrolysis of NH3BH3, Au1Rh1, 1:1 atomic ratio alloys, showed the highest H2 production (TOF = 240 min<sup>−1</sup> ), followed by its Pt-analogue (Au1Pt1, TOF = 200 min<sup>−1</sup> ). For both systems, the influence of light was evidenced by the almost 3-fold increase compared to dark conditions. When compared to their respective monometallic counterparts, Rh and Pt, the hybrids showed a plasmonic H2 production enhancement of 2.4 and 1.8, respectively, indicating the benefits of such systems. However, for NaBH4 dehydrogenation, Au1Ru1 performed better than Au1Rh1, Au1Pt1, and the other alloys, achieving a production of TOF = 178 min<sup>−1</sup> . In addition to its superior H2 production, the Au1Ru1 hybrid was the catalyst that maximized the use of the incoming light. In comparison to the experiments in dark, the activity increased by a factor of 3.8 under illumination. Again, compared to the monometallic RuNPs, the inclusion of the plasmonic Au led to an improvement of 2.2-fold. This improved H2 production was a result of hot carrier injection from Au into the catalytically active Ru atoms, weakening the B−H bonds in the borohydride. 

Unlike alloys, in core−shell structures, the adsorbates can only interact with the outermost metal, which typically is the catalytic metal. This introduces an important difference between the systems. Instead of isolated active centers, the entire surface of the core−shell structure becomes active for catalytic processes. Xu et al. fabricated a hybrid plasmonic photocatalyst by coating an Ag nanocube with a thin layer of Pd (Ag@Pd NC).<sup>109</sup> Panels i and ii of Figure 2c illustrate the well-defined spatial arrangement of the metals, showing that Pd was placed only at the surface, encapsulating the Ag optical antenna. The Ag@Pd NCs were tested toward the hydrolytic dehydrogenation of NH3BH3, and changes in the activation barrier under visible light illumination were studied. The Ag@ Pd NCs showed a H2 production rate of 102 × 10<sup>6</sup> μmol g<sup>−1</sup> h<sup>−1</sup> at 40 °C, which is one of the highest rates in Table 3. This production under illumination was 1.2 times larger compared to dark conditions. In spite of this outstanding production, the most interesting finding is that the activation energy (Ea) was lowered from 50 kJ mol<sup>−1</sup> to 31.8 kJ mol<sup>−1</sup> under simulated sunlight illumination, as shown at the bottom of Figure 2b. The authors attributed the lowered Ea barrier to the fact that excited electrons on Ag accumulated within the thin Pd shell. Those excited carriers would then populate the lowest unoccupied molecular orbital (LUMO) of the Pd−NH3BH3 complex at the interface, thus facilitating the H2 production. 

By coating a plasmonic antenna with a catalytic material, the optical properties of the overall system are damped. Instead, partially coating the plasmonic components allows us to preserve the plasmon and still exploit the interface between both. Tong et al.<sup>110</sup> compared the performance of hybrid systems in which the catalytic metal was either homogeneously or heterogeneously grown on a plasmonic antenna. Both Pdcovered and Pd-dotted Ag@Au hexagonal nanoparticles were fabricated and tested toward the generation of H2 out of formic acid (HCOOH) (Figure 2d). The Pd-covered Ag@Au showed 

784 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

Table 4. Plasmonic Metal−Metal and Plasmonic Metal−Semiconductor Hybrid Systems for CO2 Reduction 

|photocatalyst|light source|major<br>product|temp<br>(°C)|formation rate<br>(μmol g<sup>−1 </sup>h<sup>−1</sup>)|minor products|selectivity<br>(%)|stability<br>(h)|AQE<br>(%)|PE|LE|ref|
|---|---|---|---|---|---|---|---|---|---|---|---|
|||||PNP−Metal for<br>|CO2|||||||
|Au<br>colloidosomes|lamp (1100 > λ > 400<br>nm, 1 W cm<sup>−2</sup>)|CH4|25<br>(RT)|1.50 (μmol g<sup>−1</sup>)|−|100|−|−|−|−<br>|112|
|Au-(EMIM-<br>BF4)|laser (@532 nm,<br>10 W cm<sup>−2</sup>)|CH4|48|0.76<sup>c</sup>|C2H2, C2H4, C2H6,<br>C3H6, C3H8|50|>8|−|−|b<br>|118|
|Au-(EMIM-<br>BF4)|laser (@532 nm,<br>10 W cm<sup>−2</sup>)|CH4|48|0.43|C2H2, C2H4 C3H6,<br>C3H8|50|>40|−|−|b<br>|119|
|Au|Xe lamp (λ > 400 nm,<br>300 mW cm<sup>−2</sup>)|CH4|25|0.068|C2H6|−|>28|−|−|b|111|
|Ag|theoretical simulations|MeOH|−|DFT calculation|−|−|−|−|−|−|120|
|Ag|laser (@514.5 nm,<br>0.295 mW μm<sup>−2</sup>)|CO|−|mechanism study<br>by SERS|−|−|−|−|−|−|121|
|Ag|laser (@514.5 nm,<br>10 mW)|C4H9OH|−|mechanism study<br>by SERS|−|−|−|−|−|−|122|
||||P|NP−Semiconducto|r for CO2|||||||
|Au/CdSe-Cu2O|300 W Xe lamp<br>(λ > 420 nm)|CO|−|80.3|CH4|−|>60|0.4|1.9|b|123|
|Au-TiO2(O)|300 W Xe lamp<br>(420 > λ > 320 nm)|CO|25<br>(RT)|25.6|CH4|−|>16|−|5.5|−|124|
|Ag1Au1/TiO2|30 W white LED<br>(λ > 420 nm)|CO|−|0.15|H2|−|>15<sup>a</sup>|−|1.6|−|125|
|Au6Pd1/(101)<br>TiO2|300 W Xe lamp|CH4|−|12.96|CO, C2H4 C2H6|85|−|−|5.2|−|126|
|Ag@TiO2|solar simulator<br>(AM1.5G, 300 W)|CH4|25|4.93<sup>c</sup>|−|−|>9|0.006|3|−|127|
|BiV O4-Au-<br>Cu2O|300 W Xe lamp<br>(λ > 420 nm)|CH4|−|3.15|CO|−|>20|0.44|5.3|−|128|
|Au/TiO2|50 W LED lamp<br>(λ = 530 nm)|CH4|3|∼3.00<sup>c</sup>|C2H6|90|>3<sup>a</sup>|−|2.4|−|129|
|aExperiment du|ration. bNegligible pro|duct detecte|d withou|t light. cCalculate|d or extracted from|graph.||||||



a H2 production of 15 × 10<sup>3</sup> μmol g<sup>−1</sup> h<sup>−1</sup> when illuminated with visible light at 50 °C with a light enhancement factor of 1.15. However, when the Pd was shaped into dots instead of a continuous shell, the performance was further improved up to 113 × 10<sup>3</sup> μmol g<sup>−1</sup> h<sup>−1</sup> . The control of the morphology of the active metal not only enabled a boost in H2 generation, but also resulted in a larger light enhancement. Indeed, the improvement of 4.5-fold in its activity under visible light illumination is the largest light enhancement factor among the examples reported in Table 3. The anisotropic distribution resulted in a lower damping of the LSPR in comparison to the full Pd shell and therefore in higher spatially inhomogeneous electric field at the surface of the Pd dots. According to the authors, the enhanced adsorption of HCOOH on Pd due to the local fields and an increased hot carrier injection rate from the plasmonic to the catalytic metal were crucial to improve the H2 production. 

Until now, most of the reports utilized Au or Ag as plasmonic metals. However, there is a substantial need to move toward earth abundant metals for sustainable plasmon-driven catalysis. While copper-based systems are the most promising choice due to its inherent resonance within the visible region, the chemical stability of these systems still remains challenging. Luo et al. recently employed Cu−Zn alloys to perform methanol reforming under simulated sunlight illumination.<sup>113</sup> It was found that the chemical composition of the alloyed nanoparticles influenced the H2 production. The largest production (328 × 10<sup>3</sup> μmol g<sup>−1</sup> h<sup>−1</sup> ) was observed for the Zn1.3Cu98.7 sample. Both the large productionsecond best in Table 3and its promising energy conversion ability reinforce the shift toward earth abundant plasmonic metals. 

All these examples shed light on the design of bimetallic hybrid nanocatalysts. The optimization of catalysts is specific to their application, as an excellent catalyst for H2 generation from one H2 source might not be suitable for H2 generation from other H2-containing compounds. It has been demonstrated that tailoring the chemical composition and the spatial arrangement of the materials can be beneficial to enhance the interaction between the adsorbate and the catalyst, leading to better catalytic performances. From the reviewed articles included in Table 3, partially coated hybrid bimetallic catalysts seem to be the most promising configurations for sunlightdriven photocatalysis. Compared to fully coated catalysts, these structures only slightly damp the LSPR while still exploiting the interface between the metals for efficient hot carrier transfer. 

Plasmonic Metal−Metal Hybrids for CO2 Reduction. In recent years, the ability of PNP to generate energetic carriers when resonantly illuminated has been exploited in multielectron processes such as CO2 reduction. However, to our knowledge, to date there appears to be no evidence of plasmonic hybrid bimetallic photocatalysts employed for this reaction. Thus, in this section we will briefly discuss and summarize some relevant monometallic examples in this field (see Table 4). 

Yu et al. reported one of the first examples.<sup>111</sup> Here, a colloidal suspension of 12 nm AuNPs coated with polyvinylpyrrolidone (AuNP-PVP), was employed to reduce CO2. This was possible due to the stability provided by the surfactant when illuminated in long-hour experiments. One of the most striking features of this report was the tunability of the reaction pathway as it was dependent on both the energy of 

785 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp Review</mark> 



Figure 3. Plasmonic metal−semiconductor hybrids. (a) Schematic representation of charge transfer at the Schottky barrier of a metal− semiconductor interface. (b) Top: TEM images of both AuNR-TiO2 and Au@Ag NR-TiO2 supported on SiO2 (scale bars 100 nm). Bottom: photocatalytic performance of the hybrid systems toward FA dehydrogenation and calculated hot electrons generation rates for the Au and Au@Ag NRs under sunlight illumination. (c) Top: TEM (i), corresponding EDS (ii), and optical characterization of Ag@SiO2/Au@CdS hybrid. Bottom: performances of a set M-SC hybrids for optimized HER. (d) Top: HAADF (iii) and EDS images (iv, scale bars 20 nm) of Au/CdSe-Cu2O used in CO2RR. Bottom: performance of the hybrid in CO2RR as a function of H2O percentage in the reaction mixture. (e) Left: TEM (v), HR-TEM (vi), HAADF (vii), and corresponding EDS (viii) images of (101) TiO2-supported Au1Pd1 alloy NPs. Top-right: CO2RR for Au, Pd, and alloyed AuPd (stoichiometry ratio Au:Pd 6:1). Bottom-right: selectivity toward the hydrocarbons varying the chemical composition of Au−Pd alloy NPs. (a,b) Adapted with permission from ref. 131. Copyright 2020 American Chemical Society. (c) Adapted with permission from ref. 132. Copyright 2021 American Chemical Society. (d) Adapted with permission from ref. 123. Copyright 2020 Wiley-VCH. (e) Adapted with permission from ref. 126.Copyright 2019 Royal Society of Chemistry. 

the photons and the photon flux. As can be seen in Figure 2e, when illuminated with visible light (λ > 400 nm, 300 mW cm<sup>−2</sup> ), the AuNPs promoted the formation of both CH4 and ethane (C2H6). To understand the mechanism, the researchers further studied the role of the plasmon and interband transitions in the reaction pathway by varying both the wavelength and power. When using green photons matching the LSPR (λ = 532 nm), the AuNPs only produced CH4 irrespective of the power. However, when the incident photons were more energetic (λ = 488 nm), AuNPs not only were able to produce CH4, but also promoted C−C coupling at high powers (>300 mW cm<sup>−1</sup> ), resulting in C2H6 production. The possibility to conduct a 14 e<sup>−</sup> (C2H6) instead a 8 e<sup>−</sup> (CH4) reduction was attributed to longer lifetimes of energetic charge carriers when exciting the interband transitions compared to the hot carriers created by means of LSPR. Hybrid plasmonic systems can potentially decrease charge recombination and 

therefore could allow the production of C2+ products by plasmon excitation of bimetallic systems in the future. Dhiman et al. investigated the influence of hotspots on the methanation of CO2 using dendritic plasmonic colloidosomes (DPC) (see Figure 2f).<sup>112</sup> Clustering the NPs allowed the utilization of not only the visible, but also the NIR region of the solar spectrum. Interestingly, they found that the performance of the system was dependent on the Au load and the strength of the hotspots created within the interparticle gaps. Specifically, only the sample with ∼8 nm AuNPs (DPC-C4, four growing steps) enabled the reduction of CO2 to generate CH4, as shown in Figure 2f. The CH4 production of 1.50 μmol g<sup>−1</sup> h<sup>−1</sup> is one of the highest in Table 4, although it is worth mentioning that the experiments were conducted at 85 °C. Conversely, colloidosomes with either smaller or larger nanoparticles were not able to reduce the CO2 neither to CO nor CH4. The performance of the 8 nm AuNPs colloidosomes was attributed to the 

786 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

Table 5. Plasmonic Metal−Semiconductor Hybrid Systems for H2 Generation 

|photocatalyst|light source|reaction|temp<br>(°C)|formation rate<br>(μmol g<sup>−1 </sup>h<sup>−1</sup>)|stability<br>(h)|AQE (%)|PE|LE|ref|
|---|---|---|---|---|---|---|---|---|---|
|||PNP−Semicon|ductor fo|r H2||||||
|Pt/TiO2-HA|300 W Xe lamp<br>(λ > 400 nm)|H2O reduction<br>(EtOH)|−|356 × 10<sup>3</sup>|>56|0.23<br>(@550 nm)|−|−|130|
|Ag@SiO2/ Au@CdS<br>with pinholes|0.35 W LED strips<br>(λ ≥400 nm)|H2O reduction<br>(Na2SO3/Na2S)|15|191 × 10<sup>3</sup>|−|−|7346|−|132|
|Au@SiO2/ Au@CdS<br>with pinholes|LED strips (λ ≥400 nm)|H2O reduction<br>(Na2SO3/Na2S)|15|143 × 10<sup>3</sup>|−|−|5500|−|132|
|Ag@SiO2@CdS@Au|LED strips (λ ≥400 nm,<br>0.198 mW cm<sup>−2</sup>)|H2O reduction<br>(Na2SO3/Na2S)|12|130 × 10<sup>3</sup>|−|0.35<br>(@475 nm)|3.3|−|133|
|Au@CdS with pinholes|LED strips (λ ≥400 nm)|H2O reduction<br>(Na2SO3/Na2S)|15|75000|−|−|2885|−|132|
|Au@Ag nanorods/TiO2|300 W Xe lamp<br>(λ ≥350 nm)|FA dehydrogenation|35|60000|>1<sup>a</sup>|−|b|−|131|
|AuNR/TiO2|300 W Xe lamp<br>(λ ≥350 nm)|FA dehydrogenation|35|40000|>1<sup>a</sup>|−|b|−|131|
|Ag@SiO2@CdS|white lamp (198 W cm<sup>−2</sup>)|H2O reduction<br>(Na2SO3/Na2S)|12|38000|−|−|75||133|
|Au@CdS, pinhole-free|LED (λ ≥350 nm)|H2O reduction<br>(Na2SO3/Na2S)|15|30000|−|−|21.4|−|132|
|Au@CdS|300 W Xe lamp<br>(λ ≥420 nm)|H2O reduction<br>(Na2SO3/Na2S)|20|24000|>20|48<sup>d</sup>|240|−|135|
|AuNP chain-<br>Zn0.67CdS0.33|Xe lamp (λ ≥420 nm,<br>300 W cm<sup>−2</sup>)|H2O reduction<br>(Na2SO3/Na2S)|15|16420|>40|54.6<br>(@420 nm)|3.3|−|136|
|TiO2-Au nanofibers|300 W Xe lamp<br>(λ ≥420 nm)|H2O reduction<br>(MeOH)|−|12440|>3<sup>a</sup>|5.11<br>(@400 nm)|10|−|137|
|AuNPs/TiO2 nanorod|300 W Xe lamp|H2O reduction<br>(EtOH)|25|7100|>30|−|57|−|134|
|AuNPs@TiO2-Pt|300 W Xe lamp<br>(λ ≥420 nm)|H2O reduction<br>(MeOH)|−|3100|>4<sup>a</sup>||−|−|138|
|AgNPs/TiO2 nanorods|150 W Xe lamp|H2O reduction<br>(MeOH)|−|740|>45|−|6.2|−|139|
|Pt-decorated Au-TiO2<br>nanodumbbell|300 m W Xe lamp (<br>λ ≥420 nm)|H2O reduction<br>(MeOH)|−|350|>10|−||−|140|
|Au@CdS/ZnO|LED lamp (λ = 640 nm,<br>3.4 mW cm<sup>−2</sup>)|H2O reduction<br>(MeOH)|25|79|>200|0.24<br>(@640 nm)|−|c|142|
|Au nanostars@c-TiO2|Xe lamp (λ ≥420 nm,<br>100 mW cm<sup>−2</sup>)|H2O reduction<br>(MeOH)|−|77|>17|2.3<br>(@650 nm)|−|−|143|
|SiO2/AuNPs@TiO2|300 W Xe lamp<br>(λ ≥420 nm)|H2O reduction<br>(MeOH)|−|52|>5<sup>a</sup>|−|−|−|144|
|3D array Au-TiO2-Pt|Xe lamp (λ ≥420 nm,<br>650 mW cm<sup>−2</sup>)|H2O reduction<br>(MeOH)|15|43|>9|0.43<br>(@540 nm)|b|−|145|
|Au nanorods/TiO2<br>dumbbell|300 W Xe lamp|H2O reduction<br>(MeOH)|30|12|−|−|b|−|146|
|Au nanostars@TiO2|150 W Xe lamp<br>(630 > λ > 420 nm)|H2O reduction<br>(MeOH)|40|7.9|>0.33<sup>a</sup>|−||−|141|
|Fe3O4-Au-CdS|Xe lamp (λ ≥420 nm)|H2O reduction<br>Na2SO3/Na2S)|65|106 μmol h<sup>−1</sup>|>12|−|−|−|147|
|SCN<sup>−</sup>-functionalized<br>AgNPs/TiO2|300 W Xe lamp<br>(λ ≥320 nm)|H2O reduction<br>(MeOH)|−|45 μmol h<sup>−1</sup>|>15|−|27.5|−|148|
|Fe3O4-CdS-Au|Xe lamp (λ ≥420 nm)|H2O reduction<br>(Na2SO3/Na2S)|−|13 μmol h<sup>−1</sup>|>30|−|1.33|−|149|



aExperiment duration. bNegligible product detected without plasmonic material. cNeglibible product detected without light. dQY of hot electron injection from transient absorption spectra. 

synergistic effects of the optimized electromagnetic and thermal hotspot coupled to the hot carriers transfer for Au surfaces to adsorbed CO2. 

It has been demonstrated that multielectron processes can be driven by PNPs, although there is still plenty of room to explore toward the fabrication of plasmonic bimetallic photocatalysts for CO2 reduction. Proper engineering of the hybrid should focus on ways to increase the pumping of hot carriers toward the active material. Also, the strong adsorption of CO on metallic surfaces must be taken into account for proper materials selection. This phenomenon should not be underestimated as it leads to the inactivation of the active sites. 

An emerging way to engineer the materials for C−C coupling is to create nanometer gaps between the plasmonic and catalytic metal surfaces. In this type of catalyst, the reduction of CO2 at the surface of the PNP can create intermediateenriched environments nearby the catalytic metal surface. This is usually referred to as in-tandem reactors. 

## ■<sup>PLASMONICMETAL−SEMICONDUCTOR</sup> 

The charge transfer from a plasmonically excited metal nanoparticle to a semiconductor, schemed in Figure 3a, has been beneficial for increasing the photocatalytic production of solar fuels. The pursuit of an optimized hybrid photocatalyst 

787 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

has led to the combination of PNPs with several semiconductors such as TiO2, CdS, and Cu2O, among others. Recent examples of these types of hybrid materials are summarized in Table 4 and Table 5, as well as the performance metrics defined in the introduction. In the following, selected examples for both H2 generation and CO2 reduction will be discussed. 

Plasmonic Metal−Semiconductor Hybrids for H2 Generation. As shown in Table 5, more than 60% of the hybrids for plasmon assisted photocatalytic H2 production utilized TiO2 as the semiconductor component, owing to its unique photochemical and photoelectrochemical properties. Herein, the best photocatalyst for hydrogen production was realized by Qin et al.<sup>130</sup> They designed and employed an efficient photocatalyst for plasmon-enhanced visible light based on Pt nanoparticles (PtNPs) supported on TiO2 photocatalysts (Pt/TiO2). While anatase-structured TiO2 is only active in the UV, the inclusion of 100 nm plasmonic PtNPs allowed to extend the photoactivity of the hybrid to the visible. The improved H2 formation rate of 356 × 10<sup>3</sup> μmol g<sup>−1</sup> h<sup>−1</sup> , the highest among all the reviewed metal−semiconductor examples, was a result of transferring hot electrons from Pt to the conduction band of TiO2. To understand the underlying mechanism, the PtNPs were replaced by AuNPs (50 nm). Unexpectedly, this system did not produce as much H2 as its Pt analogue. While the excitation of the plasmon in both metals enabled the injection of energetic electrons into the conduction band of TiO2, their different Schottky barrier strongly affected the photocatalyic performance. In short, the higher Schottky barrier of the Pt-TiO2 heterojunction of ϕ<sup>Pt</sup> = 1.7 eV (compared to ϕ<sup>Au</sup> = 0.9−1.0 eV with Au) inhibited the recombination of the injected electrons in TiO2 with the holes in the metal. This led to an extended lifetime and larger extraction toward H2 production. Remarkably, in addition to its high production, it is also one of the most stable hybrids of this section (56 h). 

Negrin-Montecelo et al. published an important study on the critical influence of morphology and composition of the plasmonic component in PNP−TiO2 nanostructures.<sup>131</sup> Herein, the authors interfaced both Au nanorods (NR) and core− shell Au@Ag NR with TiO2 and tested them toward the dehydrogenation of HCOOH (Figure 3b). In their experiments, it was found that by coating a AuNR with a Ag shell, the H2 production was increased from roughly 36.5 × 10<sup>3</sup> μmol g<sup>−1</sup> h<sup>−1</sup> to 64.9 × 10<sup>3</sup> μmol g<sup>−1</sup> h<sup>−1</sup> . As expected, TiO2 on silica beads was not able to trigger the reactions when illuminated with photons below the energy of the bandgap. This reinforces the role of the plasmonic component as the photosensitizer material. Theoretical calculations revealed that the Au@AgNRs were able to create both more and higher energy electrons than the bare AuNRs, facilitating the injection of hot electrons into the conduction band of the semiconductor. 

Recently, CdS has emerged as a promising semiconductor to be exploited in the generation of H2, as seen in the first five examples listed in Table 5. Yang et al. synthesized hybrid dual plasmonic antenna consisting of partially CdS-coated Au satellites assembled on SiO2-coated Ag nanoparticles (Ag@ SiO2/Au@CdS with pinholes).<sup>132</sup> Panels i and ii of Figure 3c show the spatial arrangement of the metals. When tested for the HER, this structure yielded one of the highest performances for this type of PNP−SC hybrids (191 × 10<sup>3</sup> μmol g<sup>−1</sup> h<sup>−1</sup> , Figure 3c). It was possible to improve the formation rate 

by 7346 times, as evidenced by the plasmonic enhancement factor. The combination of these three materials resulted in an optical response extending from the blue to the red of the visible region. The inherent absorption of the CdS was enhanced due to the overlap with the Ag resonance, and hot carriers were pumped into the conduction band of the semiconductor by the Au satellite, leading to a notable improvement in the performance. Finally, when the Ag antenna was replaced by a Au optical antenna in the hybrid, the performance was slightly inferior (143 × 10<sup>3</sup> μmol g<sup>−1</sup> h<sup>−1</sup> ). The authors attributed this result to the poor overlap between the Au LSPR and the CdS absorption band in the blue region, as shown in the extinction spectra in Figure 3c. 

In conclusion, tremendous advances have been made in the combination of PNP with semiconductors toward the generation of H2. Due to its high photoactivity, low cost as well as excellent chemical stability, TiO2 is the most used semiconductor material in hybrid plasmonic semiconductor systems so far. Nevertheless, novel hybrids with promising performances are arising. Challenges to be addressed in the near future are the susceptibility of CdS to corrosion under light illumination<sup>150</sup> and the high recombination rate of carriers of ZnO,<sup>151</sup> limiting the chemical stability and catalytic activity, respectively. 

Plasmonic Metal−Semiconductor Hybrids for CO2 Reduction. The creation of an heterojunction between metals and semiconductor is a promising strategy to suppress the HER thereby enhancing the photocatalytic CO2RR. Both the activity and selectivity can be tuned to favor a desired product of the reaction. Recent reports on the application of these hybrids are summarized in Table 4. 

One of the most remarkable examples in terms of selectivity and production of carbon-based products was recently reported by Wang et al.<sup>123</sup> The authors synthesized Au/ CdSe-Cu2O dumbbell nanorods (see Figure 3d, panels iii, iv, v) which were utilized for CO2RR under visible illumination (λ > 420 nm) at different H2O %wt in the reactant solution. Throughout the tests, H2 was never detected, and CO as well as more electron-demanding products such as CH4 were produced instead. As shown in Figure 3d, the production reached maximum values of 80.1 and 42.9 μmol g<sup>−1</sup> h<sup>−1</sup> for CO and CH4, respectively. The water provided the H atoms for the 8e<sup>−</sup> /8H<sup>+</sup> reduction of CO2 to CH4. By combining Au with these semiconductors, a plasmonic enhancement of 1.92 was achieved. The results obtained for this hybrid (Au/CdSeCu2O dumbbell nanorods) were explained by the charge transport in the materials. In short, all three components can be excited simultaneously under visible illumination, and as a result, the photogenerated electrons accumulate in Cu2O due to the recombination of its respective holes with electrons injected from Au and CdSe. 

Chen et al.<sup>126</sup> reported a systematic study where the reactivity and selectivity of TiO2 with (101) facets were found to increase with the photoreduction of Au−Pd nanoalloys of different ratio compositions. By anchoring the Au−Pd cocatalyst on TiO2 (101), the Au−Pd alloys with the stoichiometric ratio of 6:1 provided a maximum selectivity toward hydrocarbons of 85% in the CO2RR under visible light illumination (see Figure 3e). In addition to the detection of CH4, which was the main product (12.9 μmol g<sup>−1</sup> h<sup>−1</sup> ), ethane (C2H6) and ethylene (C2H4) were detected, evidencing the capability to perform C−C coupling. While the production of CH4 was still observed when only Pd was reduced on top of 

788 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 



Figure 4. Plasmonic metal−perovskite hybrids. (a) Schematic representation of a plasmonic−perovskite hybrid system. (b) Exemplary architectures of hybrid structures: (i) TEM image of CsPbBr3 nanocubes with Au nanoparticles, (ii) TEM image of La2Ti2O7 (LTO) nanosteps with Au nanorods, (iii) TEM image of LaFeO3 nanostructure with Au nanoparticles, and (iv) SEM image of SrTiO3 nanotube arrays with Ag nanoparticles. (c) By employing Au Nanorods with different resonances, the absorption of the hybrid Au−LTO structure (shown in (ii)) can be tuned and extended across the entire solar spectrum. (d) Photocatalytic H2 production of the components Au and LTO and the Au−LTO hybrid structure. (e) Photocatalytic CO2 reduction of CsPbBr3 nanocubes and the hybrid structure with Au (shown in (i)), excited with energies below the band gap of the perovskite. (b-i,e) adapted with permission from ref. 155. Copyright 2020 Elsevier. (b-ii,c,d) adapted with permission from ref. 156. Copyright 2018 American Chemical Society. (b-iii) adapted with permission from ref. 70. Copyright 2019 Elsevier. (b-iv) Adapted with permission from ref. 96. Copyright 2011 Elsevier. 

TiO2 (101), the inclusion of Au led to a notable 5.2-fold increase. 

The application of hybrids toward the reduction of CO2 is still under development, and so far only a few combinations of metals and semiconductors have been explored. The majority of the examples listed in Table 4 employed both Au and TiO2 NPs, and only one out of seven used Ag as the plasmonic component. It is also worth mentioning that in only one report the photocatalyst was tested under simulated solar illumination conditions. It is necessary to aim for sustainable ways to carry out these processes. In this regard, cheap semiconductors such as TiO2 and plasmonic metals (e.g., Al or Cu) could emerge as candidates. Cu-based systems are promising especially for C2+ products and because of the abundancy of Cu. However, to our knowledge, they have not been explored yet. At last, the design of novel heterostructures should be carefully addressed to maximize the hot carriers injection in the active centers, as well as the lifetime of hot carriers created by means of plasmon excitations. This will lead to higher efficiencies and will bring the hybrids one step closer to industrial applications. 

## ■<sup>PLASMONICMETAL−PEROVSKITE</sup> 

The synergistic effects of the combination of the lightharvesting properties of PNPs with the optoelectric and catalytic properties of perovskite materials have resulted in the investigation of various geometrical and material arrangements (see Figure 4b). In Table 6, the hybrids that have been tested toward H2 generation and CO2 reduction are summarized using the metrics specified in the introduction. In the 

following, examples with noteworthy properties in terms of formation rate, material composition, or operational wavelength range will be discussed. To our knowledge, most systems studied to date for solar fuels production are based on perovskite oxides. Halide perovskites are another promising set of materials due to the fact that their tunable absorption across the visible can be enhanced by the local field enhancement of PNPs. This has been shown to be useful in photovoltaic applications.<sup>152−154</sup> However, the current bottleneck for photocatalytic applications is their instability. Under external stimuli such as moisture, halide perovskites are easily decomposed, which is detrimental for many catalytic applications like water-splitting. This may be one of the reasons why there is no demonstration of hydrogen production on halide perovskites yet, and that the first demonstration of CO2 reduction in such a system was published in 2020.<sup>155</sup> 

Plasmonic Metal−Perovskite Hybrids for H2 Production. Plasmon−perovskite hybrids investigated toward H2 production recently are shown in Table 6. Out of the eight different pervoskite oxide materials shown in Table 6, seven<sup>70,156−163</sup> are wide band gap semiconductors which require UV light for optical excitation. Extending the light absorption into the visible region with plasmonic hybrids is a promising strategy to increase the solar-to-fuel conversion efficiency (illustrated in Figure 4c). To probe whether hybridizing such a wide bang gap perovskite with a plasmonic material allows for photocatalytic H2O reduction using only visible light, Wang et al. synthesized SrTiO3 nanocubes both with and without AgNPs.<sup>157</sup> When illuminated with a 300 W 

789 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

Table 6. Plasmonic Metal−Perovskite Hybrid Systems for H2 Generation and CO2 Reduction 

|photocatalyst|light source|reaction|temp<br>(°C)|formation rate<br>(μmol g<sup>−1 </sup>h<sup>−1</sup>)|stability<br>(h)|AQE (%)|PE|LE|ref|
|---|---|---|---|---|---|---|---|---|---|
|||PNP−Pero|vskite fo|r H2||||||
|Ag/AgTaO3-SrTiO3|500 W Hg lamp<br>(λ > 250 nm)|H2O reduction<br>(Na2SO3)|−|2150<sup>c</sup>|>9|2.02%|−|−<br>|161|
|Al/BaTiO3|solar simulator<br>(AM1.5G,<br>100 mW cm<sup>−2</sup>)|H2O reduction<br>(MeOH)|−|∼1635<sup>c</sup><br>(∼3285<sup>e</sup>)|>30|−|6.8<sup>c</sup>|d|160|
|Au/<br>Pr0.5(Ba0.5Sr0.5)0.5Co0.8Fe0.2O3|300 W Xe lamp<br>(300 mW cm<sup>−2</sup>)|H2O reduction<br>(CH2O)|−|1618|>8|−|∼540|−|165|
|Au/La2TiO7/BP|Xe lamp (λ > 420 nm)|H2O reduction<br>(MeOH)|−|740|>12|−|b|−|162|
|Au/SrTiO3/TiO2|300 W Xe lamp<br>(λ > 320 nm)|H2O reduction<br>(MeOH)|−|467.3|>8<sup>a</sup>|−|75|−|163|
|Au/La2TiO7|Xe lamp<br>(350 mW cm<sup>−2</sup>,<br>λ > 420 nm)|H2O reduction<br>(MeOH)|25<br>(RT)|340|>24|1.4%<br>(@900 nm)|−|−|156|
|Ag/SrTiO3|300 W Xe lamp<br>(λ > 420 nm)|H2O reduction<br>(MeOH)|6|264.5|>16|−|b|d|157|
|Au/LaFeO3|solar simulator<br>(AM1.5G,<br>300 mW cm<sup>−2</sup>)|H2O reduction<br>(Na2S/Na2SO3)|5|202|>6<sup>a</sup>|−|∼2|−|70|
|Ag/KTaO3|solar simulator (300<br>W)|H2O reduction<br>(MeOH)|<5|185.6<sup>c</sup>|>7<sup>a</sup>|−|1.9<sup>c</sup>|−|158|
|Ag/AgTaO3|300 W Xe lamp<br>(λ > 420 nm)|H2O reduction<br>(C2H2O4)|20|100|>40|−|5|−|166|
|Ag/AgTaO3-SrTiO3|500 W Hg lamp<br>(λ > 400 nm)|H2O reduction<br>(Na2SO3)|−|58|>9|0.11%−|−|−|161|
|Au/LaCoO3|500 W Xe lamp<br>(300 mW cm<sup>−2</sup>)|H2O reduction<br>(CH2O)|5|42|>1.5<sup>a,c</sup>|−|2.6<sup>c</sup>|−|159|
|Ag/KTaO3|300 W Xe lamp<br>(visible)|H2O reduction<br>(MeOH)|<5|25.94|>7<sup>a</sup>|−|b|−|158|
|Ag/NaTaO3|300 W Xe lamp|H2O reduction<br>(MeOH)|<5|3.54|>7<sup>a</sup>|−|2.1<sup>c</sup>|−|158|
|Au/SrTiO3:Nb|Xe lamp|H2O reduction<br>(chemical bias)|−|7 nmol h<sup>−1</sup>|>48|4.4 × 10<sup>−4</sup>%<br>(@600 nm)|pH bias<br>reduced|−|164|
|photocatalyst<br>light sourc|e<br>major<br>product|temp<br>(°C)<br>formatio<br>(μmol g<sup>−</sup>|n rate<br><sup>1 </sup>h<sup>−1</sup>)|minor<br>products|selectivity<br>(%)|stability<br>(h)<br>AQE<br>(%)|PE|LE|ref|
|||PNP−Pero|vskite for|CO2||||||
|Au/CsPbBr3<br>300 W Xe lamp<br>(λ > 420 nm)|CO|−<br>∼10.44<sup>c</sup>||CH4||−<br>−|∼2.1<sup>c</sup>|−|167|
|Ag/SrTiO3<br>300 W Xe lamp<br>(λ > 420 nm)|CO|5<br>80.24 μm|ol g<sup>−1</sup>|H2, CH4|−|>16<br>−|−|−|157|
|Au/CsPbBr3<br>100 W Xe lamp<br>(λ > 420 nm)|CO|−<br>∼10 μmo|l g<sup>−1c</sup>|CH4|∼76%<sup>c</sup>|−<br>−|∼2.1<sup>c</sup>|−|155|
|Au/CsPbBr3<br>100 W Xe lamp<br>(λ > 580 nm)|CO|−<br>∼1 μmol|g<sup>−1c</sup>|CH4|∼85%<sup>c</sup>|−<br>−|b|−|155|



aExperiment duration. bNegligible product detected without plasmonic material. cValues extracted from the graph or calculated. dNegligible product detected without light.<sup>e</sup> Piezo-photocatalysis (additional mechanical stimuli). 

Xe lamp filtered to wavelengths longer than 420 nm, the SrTiO3 nanocubes alone predictably did not produce any hydrogen. The Ag/SrTiO3 nanocomposite, however, was able to catalyze H2 production and reached a formation rate of 264.5 μmol g<sup>−1</sup> h<sup>−1</sup> . Only one other perovskite hybrid system was reported to reach a comparable high formation rate at wavelengths longer than 420 nm (see Table 6). This hybrid photocatalyst investigated by Cai et al. not only allowed the utilization of visible light but extended the usable range into the infrared (IR).<sup>156</sup> This was achieved by a hybrid system consisting of Au nanorods (AuNRs) on lanthanum titanium oxide (La2Ti2O7, LTO) nanosteps, depicted in panel ii of Figure 4b. Figure 4c shows how the absorption peak shifts when AuNRs of different plasmon resonances are incorporated in the system. It illustrates how the geometry of the PNP can be used to tune the absorption of a plasmon-perovskite hybrid 

system across the solar spectrum. The system reached its maximum apparent quantum efficiency (AQE) of 1.4% at 920 nm, the wavelength coinciding with the longitudinal plasmon resonance of the employed AuNRs. While neither the AuNRs nor LTO individually produced a significant amount of H2 when illuminated with visible light, the combined system did, as can be seen in Figure 4d. The synergistic effect arose because the low energy photons could not photoexcite the system without the AuNRs due to the large bandgap of LTO and, on the other hand, the hot electrons generated in the AuNRs under resonant illumination could only be extracted effectively through the interface with LTO. 

Most plasmonic systems are restricted to noble metals, making large-scale industrial applications expensive. This has resulted in a search for cheaper plasmonic alternatives. As far as we know, the only example of a plasmon−perovskite hybrid for 

790 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 



Figure 5. Plasmonic metal−2D hybrids. (a) Schematic representation of a 2D material loaded with plasmonic metal nanostructures of various shapes, sizes, and compositions. (b−g) illustrate the effect on catalytic activity of shape, loading amount, size, hybrid vs single material, and plasmonic material, respectively. (b) FDTD simulations on electromagnetic fields of AuNS−MoS2, AuNR−MoS2, and AuN− TMoS2 hybrid structures. Scale bars are 20 nm. Effects of (c) Au shape (d) and Au loading ratio (in wt%) on photocatalytic H2 evolution. (e) Effect of AuNP size on the CO production rate. (f) H2 evolution rate for both single plasmonic (Cu) and 2D (WS2) photocatalyst and the hybrid structure. (g) Product selectivity of CO2 reduction using a Ag−2D and Au−2D hybrid catalyst. (b, c) Adapted from ref. 181. Copyright 2017 Royal Society of Chemistry. (d) Adapted from ref. 182. Copyright 2018 Royal Society of Chemistry. (e) Adapted from ref. 185. Copyright 2019 Elsevier. (f) Adapted from ref. 186. Copyright 2018 Wiley. (g) Adapted from ref. 74. Copyright 2020 Elsevier. 

H2 production utilizing non-precious materials was published by Guo et al.<sup>160</sup> By combining barium titanate (BaTiO3) with aluminum, a plasmonic H2-production enhancement factor of 6.8 was achieved, showing the potential of non-noble metals. Additionally, the use of BaTiO3 allows for the combination of plasmonics with piezoelectronics, where mechanical stimuli significantly enhance the photogenerated carrier separation and transfer, further increasing the H2-production rate by a factor of ∼2. 

The Al/BaTiO3 hybrid as well as eight<sup>70,159,164,165</sup> out of the 15 systems shown in Table 6 were illuminated using UV− visible−IR light, optically exciting both components. One effect that should not be neglected when discussing plasmonic hybrid systems is the effect the metal has on the system, even when the plasmon is not excited. When a semiconductor is excited above the band gap, the metal can act as a charge trap, increasing carrier lifetimes. Xu et al.<sup>158</sup> probed this by testing the H2 production on KTaO3 and NaTaO3 decorated with AgNPs for both visible−NIR and UV−visible−NIR excitation. In both cases, the addition of AgNPs increased the formation rates. However, the H2 formation rates of the composites under UV−visible−NIR light were higher than under purely visible−NIR light. The enhancement in H2 production by the addition of AgNPs is therefore described as a combination of AgNPs acting as co-catalysts by increasing the charge separation of electron−hole pairs generated in the perovskite by excitation with UV light, as well as absorption in the visible and subsequent hot electron transfer from the AgNPs. The goal is to eventually use the full solar spectrum spanning from the UV to the IR for the photocatalytic production of H2, and hence all synergistic effects can and should be exploited. However, at the current stage, still far from industrial 

applications, systematic wavelength-dependent studies reporting not only on production rates but also the quantum efficiencies, like the work of Cai et al.<sup>156</sup> and Zhong et al.,<sup>164</sup> are needed to understand the underlying mechanisms and design catalysts accordingly. 

The studies conducted to date and presented above as well as in Table 6 show that plasmon−perovskite hybrids can improve H2 production rates compared to the pristine perovskites by enhancing the absorption across the solar spectrum and improving charge carrier dynamics. While they are limited to perovskite oxides and H2 generation from water, these findings show the potential of exploring also other H2 generating reactions and eventually perovskite types like perovskite halides. 

Plasmonic Metal−Perovskite Hybrids for CO2 Reduction. The combination of a plasmonic material with a perovskite for photocatalysis has shown to be beneficial not only for H2 production but can also enhance other photocatalytic processes like dye or isopropanol degradation,<sup>168−171</sup> or the removal of algae.<sup>172</sup> However, as far as we know, there are only three publications on photocatalytic CO2 reduction using plasmon-perovskite hybrids. They are shown in Table 6. The first, by Wan et al. was briefly discussed above, as the same catalyst was also investigated toward H2 production.<sup>157</sup> As expected, no CO2 reduction occurred under visible−NIR light for the SrTiO3 nanocubes. For the Ag/SrTiO3 hybrid, three products were detected: CO, H2, and CH4. As commonly reported for plasmonic photocatalysis with perovskite oxides, the enhanced photocatalytic reduction activity is attributed to improved visible light absorption and efficient charge separation. The competing HER increases with increasing Ag loading, which is explained by an increase in the recombination 

791 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

###### Table 7. Plasmonic Metal−2D for H2 Generation (1/2) 

|photocatalyst|light source|reaction|temp<br>(°C)|formation rate<br>(μmol g<sup>−1 </sup>h<sup>−1</sup>)|stability<br>(h)|AQE (%)|PE|LE|ref|
|---|---|---|---|---|---|---|---|---|---|
|||PNP|−2D for|H2||||||
|AgPd/g-C3N4|Xe lamp (λ ≥420 nm,<br>35 mW cm<sup>−2</sup>)|FA dehydrogenation<br>(HCOONa)|30−<br>40|2.32 × 10<sup>6 c</sup>|>20 min<sup>a</sup>|27.8<br>(@400 nm)|−|−|187|
|Pd/MoxW1−xO3−y|Xe lamp (λ > 420 nm,<br>63.5 mW cm<sup>−2</sup>)|NH3BH3<br>dehydrogenation|20|∼8 × 10<sup>5 c</sup>|>50 min|−|∼5|2.3|188|
|Cu/WS2|solar simulator (AM1.5G,<br>300 W, 100 mW cm<sup>−2</sup>)|H2O reduction|26|64000|>30|15.6<sup>c</sup><br>(@500 nm)|40|−|186|
|AuPd/rGO/TiO2|solar simulator (AM1.5G,<br>100 mW cm<sup>−2</sup>)|H2O reduction<br>(MeOH)|−|21500|−|−|14.3<sup>c</sup>|d|193|
|Au/CdSQDs/CeO2|150 W Xe lamp (λ> 400 nm)|H2O reduction<br>(Na2SO3/Na2S)|−|12475<sup>c</sup>|>6|−|1.7|d|194|
|BP/Au nanorods/<br>CdS nanowires|Xe lamp (λ ≥420 nm,<br>300 mW cm<sup>−2</sup>)|H2O reduction<br>(Na2SO3/Na2S)|25|8600|>9|2.3 (@900<br>nm)<sup>a</sup>||−|189|
|Bi−Bi2MoO6/CdS-<br>DETA|300 W Xe lamp (λ> 420 nm)|H2O reduction<br>(Na2SO3/Na2S)|−|7370|>16|−|1.5<sup>c</sup>|−|195|
|Au/Pt/TiO2|300 W Xe lamp|H2O reduction<br>(lactic acid)|−|6370<sup>c</sup>|−|−|∼3.2<sup>c</sup>|−|196|
|Au/Pt/Fe2O3/g-<br>C3N4|150 W Xe lamp|H2O reduction<br>(TEOA)|−|4730|>12|−|1.54<sup>c</sup>|−|197|
|AuNPs/TiO2<br>nanosheets|350 W Xe lamp|H2O reduction<br>(glycerol)|−|4700|>1<sup>d</sup>|−|−|−|198|
|Au/rGO/Pt|visible light (λ > 420 nm)|H2O reduction<br>(MeOH)|−|4333<sup>c</sup>|−|0.05<sup>c</sup><br>(@1000 nm)|−|−|180|
|Au@Pt/ZIS|300 W Xe lamp (λ≥420 nm)|H2O reduction<br>(Na2SO3/Na2S)|25|4200|>20|6.23|10|−|190|
|Au/CuSe/Pt|300 W Xe lamp (λ> 420 nm)|H2O reduction<br>(Na2SO3/Na2S)|−|4200<sup>c</sup>|>24|0.55<br>(@600 nm)|9.7|−|191|
|Cu/CG|300 W Xe lamp|H2O reduction<br>(lactic acid)|−|3940|>0.1|−|−|−|199|
|AgPd/g-C3N4|300 W Xe lamp (λ≥400 nm,<br>35 mW cm<sup>−2</sup>)|H2O reduction<br>(TEOA)|−|3430|>28|8.43<br>(@420 nm)|b|−|200|
|Au/g-C3N4|300 W Xe lamp (λ> 400 nm)|H2O reduction<br>(TEOA)|−|3308|−|−|348|−|201|
|GO-supported<br>CdSe/CdS@Au|300 W Xe lamp|H2O reduction<br>(Na2SO3/Na2S)|−|3113|>1|−|−|−|192|
|Au/WO3|300 W Xe lamp (λ> 420 nm)|H2O reduction<br>(Na2SO3)|6|2450|>24|−|−|−|202|
|AuPd/g-C3N4|300 W Xe lamp (λ≥400 nm,<br>35 mW cm<sup>−2</sup>)|H2O reduction<br>(TEOA, K2HPO4)|4|2140<sup>c</sup>|>16|−|−|−|203|
|Au@Pt/g-C3N4|300 W Xe lamp (λ> 400 nm)|H2O reduction<br>(TEOA)|−|1876|>6|−|3.6|−|204|
|Au50Pt50/C3N4|300 W Xe lamp|H2O reduction<br>(TEOA)|25|1600|>10|−||3|205|
|Au/g-C3N4|solar simulator (150 W)|H2O reduction<br>(TEA)|−|1300<sup>c</sup>|>3<sup>a</sup>|−|−|−|206|
|Pd<sup>−</sup>Ag/g-C3N4|direct sunlight<br>(1100 ≥λ ≥300 nm,<br>840 mW)|H2O reduction<br>(TEA)|−|1250|>16|8.7|1.5|−|207|



aExperiment duration. bNeglible product detected without plasmonic material. cValues extracted from graph or calculated. dNeglible product detected without light. 

of charge carriers. The selectivity toward CO formation could be optimized by choosing an intermediate amount of Ag. 

Liao et al. published the first halide perovskite-based plasmonic photocatalyst in 2020. In their study, the experiments were not carried out in an aqueous solution but in a mixture of acetonitrile and isopropanol. CsPbBr3 nanocubes were decorated with AuNPs (see panel i in Figure 4b) and tested toward their CO2 reduction performance with both visible−NIR light (λ > 420 nm) and light below the bandgap of CsPbBr3 (λ > 580 nm).<sup>155</sup> The results are in agreement with the findings of Xu et al.<sup>158</sup> (discussed above for H2 production), where the increase in activity due to the presence of the AuNPs could be attributed to both charge transfer from the perovskite to Au and charge transfer from Au to the perovskite, dependent on which entity was optically excited. 

For full visible−NIR light illumination, the introduction of AuNPs yields a 3.2-fold enhancement. The results for below bandgap excitation with wavelengths longer than 580 nm can be seen in Figure 4e. As expected, no CO2 reduction can be detected for the perovskite alone. The Au/CsPbBr3 extends the usable wavelength range further into the visible, as indicated by the CO2 conversion rate. Since then, these findings have been supported by Tang et al., who used a macroporous CsPbBr3 framework combined with AuNPs<sup>167</sup> instead of Au/CsPbBr3 nanocubes. With the first application of plasmonic perovskite hybrids toward the reduction of CO2 published in 2019, the current systems lack in efficiency but are proof that there is a lot of room to explore. Thus far, the main product is CO. Whether a higher selectivity toward C2+ products can be achieved remains to be answered. 

792 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

###### Table 8. Metal−2D for H2 Production (2/2) 

|photocatalyst|light source|reaction|temp<br>(°C)|formation rate<br>(μmol g<sup>−1 </sup>h<sup>−1</sup>)|stability<br>(h)|AQE (%)|PE|LE|ref|
|---|---|---|---|---|---|---|---|---|---|
|||P|NP−2D for|H2||||||
|Ag/TiO2/<br>g-C3N4|300 W Xe lamp (λ > 420 nm)|H2O reduction<br>(TEOA)|−|1120|>30|−|3.3|−|208|
|AgNPs/<br>g-C3N4/SnS2|500 W Xe lamp (λ > 420 nm)|H2O reduction<br>(Na2SO3/Na2S)|−|1105|−|−|1.8|−|209|
|Au/C3N4-<br>MoS2|300 W Xe lamp (λ > 400 nm)|H2O reduction<br>(TEOA)|6|1050<sup>c</sup>|>30|−|∼10<sup>c</sup>|−|210|
|PtAu/g-C3N4|300 W Xe lamp|H2O reduction<br>(Na2SO3/Na2S)|43−45|1009|>20|−|10.7|−|211|
|Pd/C3N4|300 W Xe lamp (λ > 400 nm)|H2O reduction<br>(TEOA)|5|758|>20|3.8<br>(@420 nm)|5|−|212|
|Ag NC/CNT/<br>g-C3N4|300 W Xe lamp (λ > 400 nm)|H2O reduction<br>(TEOA)|−|693|>20|−|91|−|213|
|Au/g-C3N4|300 W Xe lamp (λ > 400 nm)|H2O reduction<br>(TEOA)|−|565|>20|−|∼3.7<sup>c</sup>|−|214|
|Au/g-C3N4|300 W Xe lamp (λ > 420 nm)|H2O reduction<br>(TEOA)|20|540|>9<sup>a</sup>|0.1<br>(@520 nm)|54<sup>c</sup>|−|182|
|Au/P-doped<br>g-C3N4|300 W Xe lamp|H2O reduction<br>(MeOH)|−|460<sup>c</sup>|>30|∼3.6<br>(@420 nm)|∼12<br>|−|216|
|Au/ZnO|solar simulator (AM1.5 filter,<br>300 W)|H2O reduction<br>(Na2S/Na2SO3)|−|350.2|>12|−|b|−|217|
|Ag/2D white-<br>C3N4|300 W Xe lamp (λ > 400 nm)|H2O reduction (hole<br>scavenger)|−|342|>20|−|2.24|−|218|
|Au/g-C3N4|300 W Xe lamp (λ ≥400 nm)|H2O reduction<br>(MeOH)|−|223|>5<sup>a</sup>|−|130|−|219|
|Au/g-C3N4|300 W Xe lamp (λ > 400 nm)|H2O reduction<br>(TEOA)|25|146.2|>3|−|5.3|−|220|
|Ag@MoS2/<br>g-C3N4|300 W Xe lamp (λ > 420 nm,<br>173 mW cm<sup>−2</sup>)|H2O reduction<br>(TEOA)|6|104<sup>c</sup>|>20|−|2.08|−|221|
|Au/Ni2P/<br>g-C3N4|300 W Xe lamp (λ > 400 nm)|H2O reduction<br>(TEOA)|−|78.65|>22|0.04<br>(@420 nm)|1.67|−|222|
|Au/g-C3N4/<br>In2O3|150 W Xe lamp (λ > 420 nm)|H2O reduction<br>(MeOH)|−|56.5|>28|2.5<br>(@420 nm)|1.93<sup>c</sup>|−|223|
|Au nanorods/<br>MoS2|100 W Xe lamp (λ > 460 nm)|H2O reduction<br>(lactic acid)|25 (RT)|18.67<sup>c</sup>|>9|0.2<br>(@780 nm)|b|−|181|
|Bi/WN|300 W Xe lamp (λ > 700 nm)|H2O reduction (TEA)|4|7.5|>20|0.16 (NIR)|2.47|−|224|
|Au1Pd2/GO|500 mW cm<sup>−2</sup>|FA dehydrogenation|25|15.9 TOF (min<sup>−1</sup>)|−|−|−|1.09|225|



aExperiment duration. bNegligible product detected without plasmonic material. cValues extracted from graph or calculated. 

###### Table 9. Plasmonic Metal−2D for CO2 Reduction 

|photocatalyst|light source|major<br>product|temp<br>(°C)|formation rate<br>(μmol g<sup>−1 </sup>h<sup>−1</sup>)|minor<br>products|selectivity<br>(%)|stability<br>(h)|QE (%)|PE|LE|ref|
|---|---|---|---|---|---|---|---|---|---|---|---|
|||||PNP−2D for|CO2|||||||
|Au/ZIS/g-C3N4|300 W Xe lamp|CO|10|242.3|CH4, H2|94.1|>5<sup>a</sup>|−|−|d|230|
|Ag nanocube/rGO|300 W Xe lamp|CO|45|133.1|−|∼100|>6<sup>a</sup>|−|3.1<sup>c</sup>|−|184|
|Ag nanosphere/rGO|300 W Xe lamp|CO|45|120.1|−|∼100|>6<sup>a</sup>|−|2.8<sup>c</sup>|−|184|
|Ag/MoS2|300 W Xe lamp<br>(150 mW cm<sup>−2</sup>)|CO|15|74.7<sup>c</sup>|H2|98|>6<sup>a</sup>|−|−|−|74|
|Au/g-C3N4|Xe lamp|CO|−|28.3|CH4|85|−|−|7.6|−|231|
|Au/g-C3N4|Hg lamp (8 W)|CO|−|9.7<sup>c</sup>|CH4|−|>8<sup>a</sup>|−|6|−|185|
|Au/g-C3N4|300 W Xe lamp<br>(λ > 420 nm)|CO|−|6.59|CH4|80.9|>2<sup>a</sup>|−|−|−|232|
|AgPd/g-C3N4|solar simulator<br>(AM1.5G,<br>100 mW cm<sup>−2</sup>)|CO|−|5.42|−|−|>20|−|c|−|227|
|Au/P-doped g-C3N4|300 W Xe lamp|CH4|−|120<sup>c</sup>|H2|−|>30|2.83<sup>e</sup><br>(@420 nm)|6<br>|−|216|
|AgPd/N-doped TiO2|300 W Xe lamp|CH4|25|79.0|−|∼100|>50|−|b|−|233|
|Au/TiO2|300 W Xe lamp|CH4|−|70.34|CO|80|>100 s<sup>a</sup>|−|∼70<sup>c</sup>|−|234|
|Au/MoS2|300 W Xe lamp<br>(150 mW cm<sup>−2</sup>)|CH4|15|19.38<sup>c</sup>|H2, CO|80.2|>6<sup>a</sup>|−|−|−|74|



aExperiment duration. bNegligible product detected without plasmonic material. cValues extracted from graph or calculated. dNegligible product detected without light.<sup>e</sup> Definition not reported. 

793 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

The recent publications on hybrid plasmon perovskite structures reviewed here show that the combination of plasmonics and perovskites is a promising strategy for the photocatalytic production of solar fuels. The systems explored so far are mostly limited to perovskite oxides. Their abundance makes them attractive materials for large-scale photocatalysis. To enhance their solar catalytic performance while keeping costs low, the combination with abundant plasmonic materials like aluminum will be an interesting and potentially fruitful route to explore. Apart from the opportunities for perovskite oxides, halide perovskites for plasmon-assisted photocatalytic applications are another promising field. Their tunable absorption across the visible can be enhanced by the local field enhancement of PNPs, which has been shown in photovoltaic applications.<sup>173</sup> The current bottleneck for photocatalytic applications is their instability. Many efforts are currently made to improve their stability<sup>174</sup> and decrease their environmental toxicity,<sup>175</sup> which will allow further exploration of their combination with plasmonic materials for the production of solar fuels. 

## ■<sup>PLASMONICMETAL−2D</sup> 

This section covers metal−2D hybrid-based solar H2 production and CO2 reduction (see Figure 5a). Conventionally, 2D materials refer to single-crystalline materials that consist of single or several layers of atoms. Strictly speaking, the electron movement within the material should be only confined along the perpendicular direction of the 2D plane.<sup>176</sup> These atomically thin crystalline 2D materials are commonly obtained by mechanical or chemical exfoliation, and due to this nature, their reproducibility is highly limited. Some argue that nanosheets and -plates can also be referred to as 2D materials as long as a certain degree of quantum confinement along the thickness direction is maintained.<sup>177</sup> These types of materials are studied intensively in recent years due to their mass producibility.<sup>178,179</sup> Therefore, in the following, nanosheets and nanoflakes will also be categorized as 2D materials. Tables 7, 8, and 9 summarize some of the recent advances on metal− 2D hybrid systems. This section aims to cast insight into tuning and controlling the properties of plasmonic metal−2D hybrids for photocatalytic applications. As can be seen from the tables, overall, by combining plasmonic metal nanostructures and 2D materials, the photocatalytic performances of the hybrid systems have improved compared to their 2D singlecomponent counterparts. 

Plasmonic Metal−2D Hybrids for Hydrogen Production. By tuning the shape and size of the metal nanoparticles, the solar light absorption profiles of the hybrid system can be modified to ensure the optimum synergy in between metal and 2D materials.<sup>180−184</sup> To study the effect of the metal nanoparticle shape, Zhang et al. compared the photocatalytic H2 generation performances of 2D Molybdenum disulfide (MoS2) decorated with Au nanospheres (AuNSs), nanorods (AuNRs), and triangles (AuNTs).<sup>181</sup> To eliminate the band gap excitation of MoS2, visible light was used, and negligible amounts of H2 were detected using either pristine Au nanostructures or MoS2. However, as shown in Figure 5c, all three hybrid structures were able to catalyze H2 generation. Among the three types of Au nanostructures, AuNR-MoS2 exhibited the best performance. The H2 generation rate of AuNR/MoS2 was 1.6 and 3.7 times higher than those of AuNT/MoS2 and AuNS/MoS2. This superior hydrogen generation of AuNR-MoS2 suggests that efficient plasmon- 

induced hot-electron transfer at the metal−2D interface is promoted by the stronger electric field from AuNRs (see Figure 5b). The authors also found that the slower recombination of electrons and holes in AuNRs contributed to charge separation in both AuNR and MoS2 across the Schottky barrier. 

The mass ratio between the metal particles and the 2D materials is another determining factor of the photocatalytic reaction kinetics.<sup>182,212,218,220</sup> Guo et al. examined the role of the metal particle loading amount. They loaded 18 nm AuNPs with varying mass percentages ranging from 0.5 to 4.0% onto graphitic carbon nitride (g-C3N4) nanosheets and investigated them toward photocatalytic H2 generation. As can be seen from Figure 5d, the H2 evolution rate increased until the loading amount reached an optimum and then decreased with continuing increase of the mass ratio of AuNPs. The number of the particles per area increases as the loading amount increases. After a certain loading amount, the close vicinity of the metal particles promotes electron−hole recombinations.<sup>226</sup> This finding also implies that the optimum loading mass increases with increased size of the metal nanoparticles. This is because for larger particles to achieve the same number density, the required total mass of the loaded particles will also increase. The effect of metal nanoparticle size is described in more detail in the CO2 reduction section. 

Co-loading or alloying metal−metal nanoparticles can further influence the photocatalytic activity of the hybrid system.<sup>187,200,203,207,227</sup> Cheng et al. demonstrated that the H2 generation could be benefited from co-loading Au clusters and AuNPs onto g-C3N4.<sup>228</sup> Au cluster here refers to an “ultrasmall nanoparticle” that consists of tens to hundreds of gold atoms and has quantized energy levels. The authors argued that this configuration allows Au clusters to act as electron acceptors to reduce the charge recombination within AuNPs; hence, increasing the hot-electron lifetime within the particles. The H2 generation rate of the AuNP cluster-NP/g-C3N4 increased by a factor of 6 compared to AuNP/g-C3N4 and by 20 times compared to Au cluster/g-C3N4. This was attributed to a combined effect of a lowered Schottky barrier between Au and g-C3N4 via strong sp<sup>2</sup> hybridization and the prolonged hotcarrier lifetime. This enhancement mechanism also applies to bimetallic system such as AuPd loaded g-C3N4.<sup>229</sup> For instance, Han et al. demonstrated that by alloying Au and Pd, the H2 production rate of the alloy−g-C3N4 hybrid nanocomposite was increased by 3.5 and 1.1 times as compared to Au−g-C3N4 and Pd−g-C3N4, respectively. Their investigations on the nanocomposites indicated that the lifetime of the photogenerated hot carriers in the AuPd alloy was longer than those in Au and Pd and therefore inhibited the recombination of the hot carriers and facilitated greater photocatalytic H2 generation. 

Due to the high cost of noble metals, researchers also started to explore non-noble plasmonic metals.<sup>186,212</sup> In Tables 7 and 8, less than 5 out of more than 30 hybrid systems studied toward H2 production are non-noble-metal-based. Xu et al. demonstrated that Cu as a non-noble metal is also capable of enhancing photocatalytic water-splitting when combined with 2D tungsten disulfide (WS2).<sup>186</sup> Their Cu-WS2 heterostructure improved the H2 generation rate by 40- and 2.2-fold as compared to the WS2 and Cu single-component system under simulated 1 sun irradiation (Figure 5f). This study not only showed the potential of non-noble metals as a proof of principle, it also reached one of the highest H2 production 

794 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 



Figure 6. Plasmonic metal−MOF hybrids. (a) Types of plasmonic metal−MOF hybrids. (b) Structure of Pt@MOF/Au and scheme of the charge transfer that enhances the catalytic activity toward water-splitting; H2 formation rates of different modifications of the catalyst. (c) Left: Structure of Ag@Re-MOF and scheme of the spatial confinement of the catalytic Re-MOF to the surface of the plasmonic silver; right: cumulative TON of the catalytic Re complex incorporated into the hybrid compared to the TON of the molecular Re catalyst. (b) Adapted with permission from ref. 89. Copyright 2017 Elsevier. (c) Adapted with permission from ref. 85. Copyright 2017 American Chemical Society. 

rates (64 000 μmol g<sup>−1</sup> h<sup>−1</sup> ) and exhibited one of the highest plasmonic activity enhancements (40) in Table 9. 

To conclude, upon combining metal nanostructures and 2D materials, the hybrid systems exhibited improved HER performances. Plasmonic materials, due to their superior light absorption and unique optical properties, can enhance the light-harvesting of 2D materials and extend their usable wavelength range. Through proper engineering of plasmonic metal−2D hybrid systems, the recombination rate of the photogenerated carriers can also be reduced significantly, which results in improved H2 production. 

Plasmonic Metal−2D Hybrids for CO2 Reduction. In the H2 generation section, it was briefly mentioned that the size of the metal nanoparticles can also influence the photocatalytic activity of plasmonic metal−2D hybrid systems. To examine this, Li et al. grew AuNPs of various sizes on g- C3N4 nanosheets for CO2 reduction.<sup>183</sup> They showed that AuNPs with 4−6 nm diameter exhibited the best CO2 reduction performance under visible light irradiation (Figure 5e). The Fermi level of the smaller particles is lower. This means the Schottky barrier between AuNP and g-C3N4 is smaller and the photogenerated electrons are more readily transferred from g-C3N4 to AuNPs. 

As concluded in multiple of the aforementioned studies, the band structure at the Schottky junction is crucial to the photocatalytic activity of the system. A material-dependent study by Sun et al. comparing the CO2 photoreduction performance of Au−MoS2 and Ag−MoS2 further demonstrated the role of the band structures at the heterojunctions.<sup>74</sup> This study showed that the band structure at the metal−2D interface can impact the formation rates of specific reduction products and their selectivity (Figure 5g). At the Au−MoS2 interface the band structure prevented the electron transfer from MoS2 to Au, whereas the hot-electrons from Au could 

inject to MoS2. This resulted in electron accumulation on MoS2 upon light irradiation. On the other hand, at the Ag− MoS2 junction, the electron transfer from MoS2 to Ag was favored resulting in less electrons being accumulated at MoS2. Subsequently, in the Ag-based system, mainly CO was generated, whereas in the Au-based system CH4 was the major product. This result shows that the selectivity in CO2 reduction processes can be carefully controlled by tuning the composition of plasmonic metal−2D nanocomposites. 

Optimization of the Schottky junction at metal−2D interfaces can prolong the hot carrier lifetime and improve the charge transfer to promote the photocatalytic performance of the hybrid systems. Moreover, particularly for CO2 photoreduction, the band structure at the interface plays a significant role in selectivity. This provides us with immense opportunities in photocatalytic system development. 

Even though the plasmonic metal−2D hybrid systems have exhibited excellent potential for synergetic photocatalytic performance, the large-scale reproducibility of conventional 2D materials still remains as a bottleneck. Both “top-down” exfoliation and the “bottom-up” synthesis are not easily scalable yet. Although tremendous efforts have been devoted to the mass production of 2D materials, there remain substantial challenges before they can make a real impact in industrial applications.<sup>235</sup> Chemically synthesized nanosheets and nanoplates have been gaining popularity as alternative 2D materials due to their producibility and photocatalytic performance. Therefore, chemically synthesized 2D materials with good crystallinity and dispersity and their plasmonic hybrid systems deserve further exploration for photocatalytic applications. 

795 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

Table 10. Plasmonic Metal−MOF Hybrid Systems for H2 Generation and CO2 Reduction 

|photocatalyst|light source|r|eaction|temp<br>(°C)|formation rat<br>(μmol g<sup>−1 </sup>h<sup>−</sup>|e<br><sup>1</sup>)<br>stability<br>(h)|AQE|(%)|PE|LE|ref|
|---|---|---|---|---|---|---|---|---|---|---|---|
||||PN|P−MOF for H2||||||||
|MIL-101/Au@CdS|300 W Xe lamp (λ > 420 n|m)<br>H2O re<br>(Na2S|duction<br>/Na2SO3)|−|25000<br>|>8|8.<br>(@42|8<br>0 nm)|1.3<sup>b</sup><br>|c|237|
|UiO-66(Zr85Ti15)/<br>Au@Pd|500 W Xe lamp (λ > 420 <br>320 mW cm<sup>−2</sup>)|nm,<br>FA deh|ydrogenatio|n<br>25<br>(RT)|3315<sup>b</sup>|>6|−||12.6<sup>b</sup>|1.5|86|
|Pt@MIL-125/Au|300 W Xe lamp<br>(800 > λ > 380 nm)|H2O re<br>(TEO|duction<br>A)|25<br>(RT)|1743|>6|−||a|−|89|
|MIL-101@anatase/<br>Au|400 W tungsten lamp<br>(λ > 400 nm)|H2O re<br>(MeO|duction<br>H)|17|903|>6|−||a|−|238|
|UCNPs/<br>Pt@<br>UiO-66-NH2/Au|solar simulator (AM1.5G,<br>300 W)|H2O re<br>(TEO|duction<br>A)|25<br>(RT)|280|>16|−||∼3|−|239|
|photocatalyst|light source|major<br>product|temp<br>(°C)|formation rate<br>(μmol g<sup>−1 </sup>h<sup>−1</sup>)|minor<br>products|selectivity<br>(%)|stability<br>(h)|AQE<br>(%)|PE|LE|ref|
||||PNP|−MOF for CO2||||||||
|PPF-3/Au|300 W Xe lamp<br>(λ > 400 nm)|formic acid|25<br>(RT)|42.7|−|100|>24|−|5|−|240|
|MIL-101(Cr)/Ag|300 W Xe lamp<br>(780 > λ > 400 nm,<br>200 mW cm<sup>−2</sup>)|CO|50|808.2|CH4, H2|∼61<sup>a</sup>|>18|−|27<sup>a</sup>|−|241|
|Au@Pd@MOF-74|500 W Xe lamp|CO|−|2.46<sup>b</sup>|−|100|>5|−|1.7<sup>a</sup>|c|242|
|Ag@Re3-MOF|300 W Xe lamp<br>(700 > λ > 400 nm)|CO|−|0.94 TON/h<sup>b</sup>|−|∼100|>48|−|7|−|85|
|Au@Pd@<br>MOF-74/Pt|500 W Xe lamp|CH4|−|2.47<sup>b</sup>|CO|∼84|>5|−|1.4<sup>a</sup>|c|242|
|ZIF-67/Au|solar simulator<br>(150 mW cm<sup>−2</sup>)|MeOH|−|2380<sup>b</sup>|EtOH|∼97<sup>b</sup>|>12|6.4 (@<br>420<br>nm)|a|−|87|



aNegligible product detected without plasmonic material. bValues extracted from graph or calculated. cNegligible product detected without light. 

## ~~■~~<sup>PLASMONICMETAL−MOF</sup> 

Combining plasmonic light-harvesting of PNPs with the property tool set that MOFs offer allows for a vast amount of synergistic possibilities. In these hybrids, MOFs and PNPs can be structurally combined in several ways. Two of the most prominent examples are MOFs grown around PNPs and MOFs that are decorated with PNPs (see Figure 6a).<sup>81,82,236</sup> In the following, a unified nomenclature is used to increase readability. Particles assembled on other compounds are positioned after a “/”-sign while incorporated components are written before an “@”-sign. From left to right, the components are arranged from core to shell. Furthermore, only the common names and important features of the respective MOFs are mentioned in the text as another measure to increase readability. For example, MIL-125, a framework built up from 1,4-benzenedicarboxylate (organic linker) and TiO2 (metal node), will be described as a semiconductor-like MOF. 

Plasmonic Metal−MOF Hybrids for H2 Production. Recently explored hybrids that exploit the combination of PNPs and MOFs to boost the performance of photocatalytic H2 production are summarized in Table 10. One of the highest H2 production rates was reported for Pt@MIL-125/Au. The hybrid catalyzed the water-splitting reaction with a H2 formation rate of 1743 μmol g<sup>−1</sup> h<sup>−1</sup> .<sup>89</sup> In the optimized hybrid, PtNPs were incorporated into a porous semiconductorlike MOF (MIL-125), and the structure was subsequently decorated with rod-shaped AuNPs (see Figure 6b). The porosity of the MOF allows the reactants and products to access and leave the catalytic sites, respectively. Under visible light radiation, hot electrons generated at the AuNPs were steered through the lowest unoccupied molecular orbital (LUMO) of the MOF toward the PtNPs. Due to the difference 

in work functions of the MOF (semiconductor-like) and the Pt (metal), electrons left the MOF in favor of the Pt surface and were trapped there (Schottky junction; see Figure 6b). This electron transport pathway resulted in an accelerated unidirectional charge transfer and an amplified e<sup>−</sup> −h<sup>+</sup> separation. The extent of e<sup>−</sup> −h<sup>+</sup> separation was greatly influenced by the spatial separation of AuNPs and PtNPs. Figure 6b shows the impact of incorporating the PtNPs into the MOF compared to assembling both the PtNPs and the AuNPs on the MOF surface (MIL-125/Pt/Au), where the formation rate is about 10 times lower. Figure 6b also illustrates the role of the plasmonic component in harvesting the light as no catalytic activity was reported without the AuNPs (0 μmol g<sup>−1</sup> h<sup>−1</sup> for Pt@MIL-125). 

Like the previous hybrid, UiO-66(Zr85Ti15)/Au@Pd was designed to enrich the surface of the catalytic compound (here Pd) with electrons.<sup>86</sup> Here, a MOF (UiO-66(Zr85Ti15)) with photoactive linkers and doped metal nodes was decorated with plasmonic core−shell Au@Pd nanoparticles resulting in the second highest formation rate reported (see Table 10). This combination resulted in several processes upon visible light radiation that boosted the hydrogen formation from formic acid. First, doping the metal nodes (Zr) of the MOF with Ti promoted the charge transfer of the electrons created in the MOF linkers and enhanced the visible light absorption of the MOF. Second, amine groups within MOFs enhance the catalytic activity as they assist in the dissociation of O−H as an important step for the transformation of formic acid to H2. And last, hot electrons created by the LSPR in the Au and photoexcited electrons created at the photoactive MOF-linkers are transferred to the catalytic Pd surface. The plasmonic component is essential for the catalytic performance, as the 

796 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

hybrid has a 12.6 times higher production rate with Au compared to without. The resulting formation rate of 3315 μmol g<sup>−1</sup> h<sup>−1</sup> is the second highest reported in Table 10. More importantly, the hybrid shows how the building blocks of MOFs can be smartly designed to, for example, promote certain steps in the synthesis, facilitate charge transfer, or enhance absorption properties in combination with PNPs. 

While the concepts used in the previously discussed hybrids are promising, by far the highest formation rate with 25 000 μmol g<sup>−1</sup> h<sup>−1</sup> was reported for MIL-101/Au@CdS catalyzing the water-splitting reaction.<sup>237</sup> Here, Au@CdS core−shell particles were assembled on a MOF structure (MIL-101). The hybrid exploited the already highly reactive catalyst CdS (7400 μmol g<sup>−1</sup> h<sup>−1</sup> ; semiconductor) for achieving high formation rates. By assembling CdS on the MOF-surface, the formation rate was enhanced 2.7-fold. The MOF acts as a support, resulting in well-dispersed CdS particles and therefore possibly more active catalytic sites. By absorbing visible light, the MOF generated excited electrons that enriched the surface of CdS, therefore facilitating the reaction. Introducing AuNPs in the form of core−shell Au@CdS particles enhanced the reactivity by another 30%. The authors propose that the AuNPs accelerated the charge transfer and additionally extended the response spectrum of CdS by the LSPR. 

When comparing the values in Table 10, two approaches for H2 production utilizing PNP−MOF hybrids stand out. In absolute numbers, introducing an additional material that is already highly catalytically active (e.g., the semiconductor CdS)<sup>237</sup> that can be further enhanced by PNPs and MOFs can result in very high formation rates. In relative numbers (enhancement), targeting single, crucial steps in reactions by introducing functional groups to the MOF seems especially promising.<sup>86</sup> In all systems reported for H2 production, the hybrid consisted of three components, with the PNPs assembled on the MOF-surface (see Table 10). Different, so far unexplored geometries and structural assemblies could result in new features that improve the catalytic performance. 

Plasmonic Metal−MOF Hybrids for CO2 Production. One of the most recognized works and one of the first PNP− MOF hybrids used as photocatalyst for CO2 conversion was Ag@Re3-MOF (see Figure 6c).<sup>85</sup> Here, a molecular CO2-toCO conversion photocatalyst (Re<sup>I</sup> (CO)<sup>3</sup> (BPYDC)Cl) was covalently incorporated into a MOF (UiO-67) which was grown around cubic AgNPs. This combination yielded two main advantages. On the one hand, the incorporation of the molecular compound into the rigid MOF structure prevented its dimerization and increased the stability of the photocatalyst 48-fold to 48 h. On the other hand, coating the AgNPs with the MOF spatially confined the catalytic Re centers close to the metal surface. Under visible light illumination, the AgNPs created an intensified near-field that could be absorbed by the incorporated Re photocatalyst. As a result, the CO2-to-CO conversion was enhanced 7-fold due to the incorporation of the PNP. 

Another interesting system worth mentioning, although not in the liquid phase, was studied by Halas et al.<sup>88</sup> For this, they combined aluminum nanocubes (AlNCs) with a MOF known for a high CO2 gas uptake. The hybrid system was used to catalyze the reverse water gas shift reaction (CO2 + H2 → CO + H2O) in the gaseous phase. The hybrid exhibited a ∼4.5-fold increased CO2 uptake compared to the pristine AlNCs. The CO2 preconcentration near the surface of the plasmonic 

material resulted in a ∼3-fold increase of CO production compared to the pristine AlNCs. 

By far the highest product formation rate for CO2 conversion in Table 10 was reported for a hybrid containing a zeolitic imidazolate framework (ZIF), a subclass of MOFs. This subclass of MOFs has promising features for CO2 reduction and is currently explored for CO2 conversion using various approaches and materials.<sup>243−245</sup> Two of the main limiting factors of current ZIF materials are sufficient solar light absorption and e<sup>−</sup> −h<sup>+</sup> separation.<sup>246</sup> Combining ZIFs with PNPs may be a perfect synergistic fit, as PNPs can bring both of these features to the system. In the reported hybrid, ZIF-67 decorated with AuNPs generated methanol (MeOH) with a rate of 2380 μmol g<sup>−1</sup> h<sup>−1</sup> and a selectivity of 97%, while also being stable for at least 12 h.<sup>87</sup> It was proposed that hot electrons generated in the AuNP upon illumination could overcome the Schottky barrier formed at the PNP−MOF interface. As a result of the electrons being irreversibly injected into the LUMO of the MOF, the lifetime of the carriers was extended resulting in an electron-enriched MOF surface where the reaction subsequently occurs. Both components of the hybrid were crucial for the catalytic performance. While the MOF provided the catalytic sites, no product was detected without the plasmonic material. 

In the majority of the reported hybrids, the PNP loading amount (wt%) was optimized. However, the size of the MOF crystals was not. Guo et al. showed for MIL-101(Cr)/Ag that controlling the MOF size can have a high impact on the catalytic performance of a PNP−MOF hybrid.<sup>241</sup> When reducing the MOF crystal size in the hybrid from 800 to 80 nm, the CO2-to-CO conversion rate was increased ∼20-fold. The authors attributed this to the increased fraction of highly catalytic edge and corner sites of the MOF. This shows that all components should be carefully tuned to optimize the catalytic performance. 

The examples for both H2 production as well as CO2 reduction show that PNP−MOF hybrids have various potential pathways to increase activity and selectivity. Interestingly, the highest formation rates for both H2 production as well as CO2 reduction were achieved by NPdecorated hybrids. For the further development of PNP− MOFs, hybrids could be designed that facilitate single, crucial steps in reactions by introducing functional groups to the MOF.<sup>86</sup> This could open energetic bottlenecks of reactions and show new paths for catalysis. Furthermore, both the spatial arrangement of the hybrid components<sup>89</sup> and the size of the MOF crystals<sup>241</sup> could be implemented as common screening parameters. Generally, data concerning the long-term stability of MOF-PNP hybrids is currently not available, and only two hybrids have been reported with a stability of at least 24 h (see Table 10). This shows that long-term stability is an issue to be addressed for potential industrial applications. 

## ■<sup>PLASMON-ASSISTEDELECTROCATALYSIS</sup> 

Despite the great progress in photocatalysis, the solar-to-fuel conversion efficiency is still low. Compared to plasmonic photocatalysis, electrocatalysis shows a much higher hydrogen generation and CO2 reduction activity. However, the high overpotential and low current density are the current bottlenecks hindering energy efficient industrial applications. Consequently, combining plasmonics with electrocatalysis is a promising strategy to improve the energy conversion efficiency. 

797 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

Table 11. Plasmonic Electrocatalysts for HER H2 Generation (1/2) 

||||operation - irradiated <br>overotential@10mAcm<sup>−2</sup>|(dark)<br>Tafelsloe||
|---|---|---|---|---|---|
|catalyst|light source|electrolyte|p    <br>(mV vs RHE)|p<br>(mV dec<sup>−1</sup>)|ref|
||PN|P−Metal for H2||||
|Pt/Fe@ Au nanorods|laser (@808 nm)|0.5 M H2SO4|18 (43)|29.3 (30.6)|215|
|PtNiCu|300 W Xe lamp (780 > λ > 420 nm)|0.5 M H2SO4|39 (51)|24.1 (27.3)|249|
|Au nanorods@ PdAg nanosheets|300 W Xe lamp|0.5 M H2SO4|50 (80)|40.5 (59.7)|250|
|AgPt-tipped Au nanostars|300 W Xe lamp (1100 >λ> 420 nm)|0.5 M H2SO4|58 (75)|35 (37)|247|
|AgPt-edged Au nanostars|300 W Xe lamp (1100 >λ> 420 nm)|0.5 M H2SO4|85 (87)|48 (49)|247|
|Pd-tipped Au nanorods|300 W Xe lamp (1100 >λ> 420 nm)|0.5 M H2SO4|87 (167)|105 (129)|251|
|AgPt-covered Au nanostars|300 W Xe lamp (1100 >λ> 420 nm)|0.5 M H2SO4|91 (119)|53 (60)|247|
|Ag/Ag2S/NiS2|LED (780 > λ > 380 nm)|1 M KOH|95 (151)|45 (74)|252|
|Cu2−x@Au2S@Au nanoplates|laser (@532 nm, 1051 mW cm<sup>−2</sup>)|0.5 M H2SO4|96 (152)|−(118)|253|
|PtPd-decorated Au@Ag<br>nanocrystal|300 W Xe lamp (1100 >λ> 420 nm)|0.5 M H2SO4|150 (199)|101 (116)|254|
|AuNPs@rGO@Pd|300 W Xe lamp (λ > 420 nm)|0.1 M KOH|291 (342)|86 (162)|255|
|Ag/Au HPNS@ porous Fe2P|300 W Xe lamp (20 mW cm<sup>−2</sup>)|0.5 M H2SO4|350 (402<sup>a</sup>)|97 (−)|256|
||PNP|−Semiconductor||||
|Au film@Ti/TiO2|laser (@980 nm, 2 W cm<sup>−2</sup>)|0.5 M H2SO4|45 (183)|35 (119)|257|
|Au@NiCo LDH|solar simulator (AM 1.5G,<br>100 mW cm<sup>−2</sup>)|1 M KOH|119 (160)|57.5 (62.1)|258|
|AuNPs@ Bi2Se3 nanoflowers|iodine tungsten lamp<br>P|0.5 M H2SO4<br>NP−2D for H2|375 (380)|78 (82)|296|
|AuNPs/MoS2/graphene/Ni foam|solar simulator|0.5 M H2SO4|28 (41)|26 (36)|259|
|1T-phase Au/Pd-MoS2<br>nanosheets|Xe lamp (300 mW cm<sup>−2</sup>)|0.5 M H2SO4|64<sup>a </sup>(119<sup>a</sup>)|49 (63)|260|
|Au@ N-doped carbon|532 nm laser, 1 W|0.5 M H2SO4|99 (196)|77 (87)|261|
|Cu1.75S-Au@ MoS2 monolayer|laser (@650 nm, 1 W cm<sup>−2</sup>)|0.5 M H2SO4|114.5 (224.3)|39 (47)|262|
|Ti3C2Tx MXene|laser (@808 nm, 7.17 W cm<sup>−2</sup>)|0.5 M H2SO4|128 (578)|91 (160)|93|
|MoS2 monolayer@nanoporous<br>Au|Xe lamp (1 W cm<sup>−2</sup>)|0.5 M H2SO4|149 (167)|38 (49)|297|
|Au nanorods@MoS2 nanosheets|laser (@808 nm, 1.5 mW)|0.5 M H2SO4|160 (220)|71 (86)|263|
|MoS2@Au|500 W lamp (1100 > λ > 400 nm)|0.5 M H2SO4|193<sup>a </sup>(316<sup>a</sup>)|74 (93)|264|
|Au nanorods@MoS2 nanosheets|laser (@721 nm, 1 W cm<sup>−2</sup>)|0.5 M H2SO4|220 (260)|63 (82)|265|
|Au@Ag nanorattles@MoS2<br>monolayer|laser (@690 nm, 5 mW)|0.5 M H2SO4|335<sup>a </sup>(448<sup>a</sup>)|155 (175)|266|
|Ag/TiO2/RGO|visible light (1.22 × 10<sup>5 </sup>lx)|0.1 M KOH|820 (920)|−(165)|267|
|||PNP−MOF||||
|Au nanorods@CoFe-MOF NS|laser (@808 nm, 1500 mW cm<sup>−2</sup>)|0.5 M H2SO4|292<sup>a </sup>(435<sup>a</sup>)|94 (115)|298|
|Au nanorods@Co-MOF NS|laser (@808 nm, 200 mW cm<sup>−2</sup>)|0.5 M H2SO4|540 (690)|133 (175)|268|
|aValues extracted from graph o|r calculated.|||||



Plasmon-Assisted Electrochemistry for H2 Production. All different types of hybrid systems that were discussed above for photocatalytic H2 generation may also be useful for plasmon-enhanced electrocatalytic applications. Therefore, the broad spectrum of materials investigated is summarized in Table 11. It shows plasmonic metal and semiconductor, 2D and MOF hybrid systems. In this table, the observables Overpotential and Tafel slope are given both under illumination and in dark (the values for dark conditions are given in brackets). The comparison of values in dark and under illumination allows for an evaluation of the enhancement that plasmonics provides to the hybrid system. This evaluation can only be qualitative as the changing observables may not exclusively be attributed to the plasmonic enhancement.<sup>248</sup> Both in the table and in the discussion below, all overpotentials are reported at a current density of 10 mA cm<sup>−2</sup> . 

A study conducted by Wei et al. shows the effect different configurations of the same metal−metal hybrids can have on 

the performance.<sup>247</sup> They probed the plasmon-enhanced electrocatalytic activity of Au nanostars modified with AgPt alloys in three different arrangements: AgPt-covered, -tipped, and -edged Au nanostars (see Figure 7c). The Au nanostars offer a wide range of tunability. By tuning the size of both the nanostar core and the nanostar branches, different resonant wavelengths can be achieved. Additionally, the position of the AgPt NPs allows further tuning, as, for example, the electromagnetic field has its highest enhancement in so-called “hot spots” at the nanostar tips.<sup>269</sup> All three systems showed reduced overpotentials and Tafel slopes under visible−NIR irradiation. However, when comparing the configurations, the AgPt-tipped Au nanostars showed a superior performance with an overpotential of 58 mVRHE. This was 17 mV lower than for the AgPt-edged and 33 mV lower than for the AgPt-covered Au nanostars (see Figure 7d). Together with the reduced Tafel slope of the AgPt-tipped Au nanostars (35 mV/dec) this implied a more efficient charge transfer and faster reaction 

798 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 



Figure 7. Plasmon-assisted electrocatalysis. (a) Schematic illustration of the experimental setup and mechanism for plasmon-assisted electrocatalysis. (b) By plasmon excitation, the selectivity toward desired products of the CO2RR can be increased. (c) Schematic illustration of AgPt-covered, -tipped, and -edged Au nanostars. (d) Corresponding behavior in Tafel slope and Overpotential in dark and under illumination for configurations in (c) and control samples. (a) Adapted with permission from ref. 92. Copyright 2020 American Chemical Society. (b) Adapted with permission from ref. 94. Copyright 2019 American Chemical Society. (c,d) Adapted with permission from ref. 247. Copyright 2019 Elsevier. 

kinetics of this modified nanostar type. The superior activity was reported to be a result of the best synergy between the Au nanostars acting as light absorbers, thereby generating heat and exciting electrons, and the AgPt alloys as electron acceptors that provided the reactive sites. 

Another interesting example highlights the synergistic effect that can arise between PNPs and conventional semiconductor electrocatalysts for solar-light-enhanced water-splitting. Du et al. investigated a catalyst consisting of AuNPs and NiCo layered double hydroxides (Au@NiCo LDH) toward both reactions involved in water-splitting, the HER and the oxygen evolution reaction (OER).<sup>258</sup> To reach a current density of 10 mA cm<sup>−2</sup> , the Au@NiCo LDH required an overpotential of 119 mV for the HER and 203 mV for the OER under illumination. The comparison with the overpotentials needed in dark (160 mV for HER and 234 mV for OER) suggested that the plasmonic excitation of Au led to a higher charge transport efficiency. This shows the potential of incorporating plasmonic materials into conventional electrochemical systems to significantly reduce the electrical energy consumption. 

Seven out of 11 metal−2D hybrids in Table 11 contain MoS2. While multiple configurations of this 2D material with different plasmonic metals have been explored,<sup>260,262,263,265,297</sup> to our knowledge, one of the first metal−MoS2 hybrids for plasmon-enhanced electrocatalytic H2 generation was reported by Shi et al. in 2015.<sup>263</sup> It consisted of Au nanorods (AuNRs) and MoS2 nanosheets. When illuminated with a 808 nm laser, matching the plasmon resonance of the AuNRs, the onset potential decreased by 60 mV compared to the dark condition. Under the same laser illumination, the activation energy of H2 evolution on the AuNR-MoS2 was calculated to be 75.65 kJ 

mol<sup>−1</sup> , much lower than that of MoS2 alone (94.82 kJ mol<sup>−1</sup> ). Moreover, the plasmon excitation resulted in the Tafel slope of AuNR-MoS2 decreasing by 15 mV/dec. This indicates a higher hydrogen coverage on the surface of the catalysts and shows that plasmon excitation can enhance the electrochemical hydrogen evolution not only thermodynamically but also kinetically. 

To our knowledge, so far only two PNP−MOF hybrid systems<sup>268,298</sup> have been investigated toward plasmon-assisted electrochemical H2 generation. Currently, PNP−MOF systems seem to be significantly weaker in performance than the majority of the metal, semiconductor, and 2D hybrids, with the lowest overpotential reported thus far being 292 mV. In comparison, the best PNP−metal,<sup>215</sup> PNP−semiconductor,<sup>257</sup> and PNP−2D<sup>250</sup> hybrids operated at overpotentials as low as 18, 45, and 28 mV. To conclude, plasmon excitation can improve the electrocatalytic hydrogen evolution activity both thermodynamically and kinetically. With Au being the plasmonic component in 20 out of the 23 listed configurations, it is still the most utilized plasmonic material in all plasmonic electrocatalysts for H2 generation reported in Table 11. One emerging non-noble plasmonic material is titanium nitride (TiN) which has shown superior performance for photoelectrochemical water-splitting.<sup>60</sup> The remarkable hot carrier collection of TiN@TiO2 was attributed to its broadband absorption as well as the forming of an ohmic junction for efficient electron collection.<sup>60</sup> 

Plasmon-Assisted Electrochemistry for CO2 Reduction. Similar to electrochemical H2 production, the electrochemical reduction of carbon dioxide typically suffers from low reaction rates that necessitate high overpotentials. Additionally, 

799 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

|ref|94|270|||||92|271|271|272|273|62|91||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|LE|459% for FE|79% for FE, 200% for CD|41% for FE, 13% for CD|36% for FE, 13% for CD|15% for FE, 50% for CD|13% for FE, 0% for CD<br>31% for FE|−, 49% for CD|−, 9% for CD|−, 31% for CD|−|CO:H2 4:1 (dark),<br>5:1 (illumination)|217% for FE, 260% for CD<br>267% for FE, 100% for CD|−, 244% for CD||
|mination<br>FE|95%|68%a|24%a|4.5%a|3.1%a|1.7%a<br>0.17%a|52%|−|−|96%|CO:H2 5:1|19%a<br>22%a|54%||
|oint under illu<br>ty (CD)|cm−2<br> −1.1 VRHE|artial CDa|artial CDa|partial CDa|partial CDa|partial CDa<br> partial CDa<br>|total CDa<br>|total CDa|total CDa|total CDa||total CDa<br>partial CDa|total CDa||
|operation p<br>current densi|0.62 mA <br>photo CD @|0.6 mA cm−2 p|0.9 mA cm−2 p|0.17 mA cm−2|0.03 mA cm−2|0.07 mA cm−2 <br>0.007 mA cm−2 <br>|3.75 mA cm−2 <br>|1.85 mA cm−2|1.05 mA cm−2|3.2 mA cm−2|−|0.18 mA cm−2 <br>0.24 mA cm−2|0.55 mA cm−2|ark.|
|potential|tal for CO2<br>−0.6 VRHE|−0.7 VRHEa|−1.0 VRHEa|−1.0 VRHEa|−0.8 VRHEa|−1.0 VRHEa<br>−1.0 VRHEa|−0.8 VRHE|−1.1 VRHE|−1.1 VRHE|nductor for CO2<br>−0.59 VRHE|−1.8 VRHE|−0.7 VRHE<br>−0.7 VRHE|−0.4 VAg/AgCl|dark)/value in d|
|product|PNP−Me<br>CO|CO|ethylene|CH4|formate|EtOH<br>allyl alcohol|MeOH|CO, CH4|MeOH,<br>EtOH|PNP−Semico<br>CO|CO|CO<br>formate|acetate|mination - value in|
|electrolyte|1 M KHCO3|0.1 M KHCO3|||||0.5 M KHCO3|0.1 M NaClO4<br>(CO2-saturated)|0.1 M NaClO4<br>(CO2-saturated)|0.2 M KHCO3|50 mM K2CO3<br>(CO2-saturated)|50 mM K2CO3<br>(CO2-saturated)|0.1 M Na2SO4 (CO2-<br>saturated)|ated as (value with illu|
|light source|LED (@365 nm, 170 mW cm−2)|LED (@365 nm, 170 mW cm−2)|||||LED (@520 nm, 120 mW cm−2)<br>|Xe lamp (850 mW cm−2)|Xe lamp (850 mW cm−2)|solar simulator (100 mW cm−2)|visible light (λ > 495 nm,<br>600 mW cm−2)|LED (λ = 565 ± 52 nm,<br>160 mW cm−2)|LED (100 mW cm−2)|om graph or calculated; LE is calcul|
|catalyst|n film/Ti|||||||opyramids<br> nm)|opyramids<br>nm)|/n+p Si|GaN|NiO|2O/CuO|s extracted fr|
||Ag thi|Ag/Cu|||||AuNPs|Ag nan<br>(180|Ag nan<br>(75|RA-Au|Au/p−|Cu/p−|Ag/Cu|aValue|



800 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 



Figure 8. Histograms of (a) the main plasmonic component and (b) the illumination source used in the publications reviewed. 

the low selectivity, especially toward multicarbon products, impedes the electrochemical production of carbon-based fuels. Recent efforts to overcome these limitations by plasmonassisted electrochemical (CO2) reduction are summarized in Table 12. Figure 7a shows the schematic setup and mechanism for plasmon-assisted electrocatalytic CO2 reduction. A study conducted by Kim et al. showed that plasmonic excitation can be used to increase the reaction rate of CO2 reduction.<sup>271</sup> In this study, the electrodes consisted of Ag nanopyramids patterned on a Ag surface. The dark current density was −0.8 mA cm<sup>−2</sup> under −1.1 VRHE. Under illumination the current density increased by 31%, up to −1.0 mA cm<sup>−2</sup> . The observed photocurrent was attributed to a resonant transfer of photogenerated plasmonic hot electrons to the lowest unoccupied molecular orbital (LUMO) acceptor energy levels of adsorbed CO2 molecules or reductive intermediates. This shows the potential of plasmon-assisted electrochemistry to overcome kinetic barriers. 

The ability of plasmonic electrocatalytic systems to modify chemical reaction landscapes was also studied by Creel et al. on plasmonically active Ag thin film electrodes.<sup>94</sup> They found that under illumination, the FE for CO increased to up to 95%, while in pure electrocatalysis it was only 17%. At the same time, the production of H2 was suppressed (from FE of 75% in dark to 10% under illumination), as shown in the left panel of Figure 7b.<sup>94</sup> Moreover, methanol production was observed only under illumination (right panel of Figure 7b). The FE reached up to 2% (at −1.1 VRHE), which is reportedly an unprecedented value for silver cathodes. This shows that plasmonics provides a promising approach to promote complex electrochemical CO2RRs over other competing reactions. 

Apart from the metallic electrodes discussed above, the application of metal−semiconductor hybrid materials in plasmon-assisted electrochemistry can potentially further enhance CO2 reduction. This was probed by Landaeta et al. with a plasmonic−metal semiconductor system, consisting of Ag and Cu2O/CuO (Ag/CuxO).<sup>91</sup> The illuminated hybrid system allowed the production of acetate with a FE of 54% at a potential of −0.4 VAg/AgCl. The formation of acetate at such a low potential had not been reported before. Moreover, The current density reached 0.55 mA cm<sup>−2</sup> upon illumination, which was 3.4 times as high as the value in dark. The enhanced performance of the hybrid originated from synergistic effects between the metal and the semiconductoras no photo- 

electrocatalytic activity was observed on either just the Ag nor the CuxO alone at such low potentials. The synergistic effect between Ag and CuxO was attributed to reduced charge recombination processes thereby decreasing the needed overpotential. Additionally, Ag stabilized the Cu2O/CuO within the applied potential range, further improving the catalytic performance. 

Cu is widely studied for electrochemical CO2 reduction because of its ability to catalyze the electrochemical conversion of CO2 to valuable fuels and chemicals beyond CO.<sup>274</sup> To improve selectivity, Corson et al. coated Cu nanostructures with silver to create a plasmonically active cathode.<sup>270</sup> Illumination allowed the selective enhancement of 5 of the 14 typically observed copper CO2 reduction products while simultaneously suppressing hydrogen evolution.<sup>270</sup> Their Faradaic efficiencies can be found in Table 12. Under illumination, the CO production was enhanced at low overpotentials, whereas at high overpotentials the production of ethylene, methane, formate, and allyl alcohol was increased. 

In conclusion, introducing plasmonics into electrocatalytic systems is a promising method to improve the activity of both HER and CO2RR and increase the selectivity of CO2RR. These properties allow the utilization of light to decrease the energy consumption in producing renewable and clean fuels. However, most plasmonic metals investigated in plasmonassisted electrocatalytic systems are noble metals, which are costly and therefore hinder industrial applications. Additionally, in CO2RR the Faradaic efficiencies of hydrocarbons and multicarbon products are still low, which need to be improved in the future. 

## ■<sup>DISCUSSION</sup> 

In this section, we will summarize and compare the performance of the hybrid plasmonic photocatalysts reviewed so far. We will organize the comparison according to the following aspects. First, we make a general review on the most frequently utilized plasmonic components and light sources in plasmonic catalysis. Second, we quantitatively compare photocatalysts according to their activity and selectivity, breaking down the different reactions of interest for hydrogen production and CO2 reduction. Third, we compare the performance of the different plasmonic electrocatalysts for HER and for CO2 reduction. 

In the vast majority of the systems explored until now, the plasmonic component was either Au or Ag. Figure 8a shows a 

801 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

histogram of the main plasmonic component among the hybrid systems in this Review: 68% use Au, 24% use Ag, and only 8% use a different material. Reasons for this preference may include the high photostability of Au and the availability of versatile protocols to shape Au into different nanomorphologies with tailored resonances along the visible spectrum. Earth abundant plasmonic materials have been less explored. 

##### Basing hybrid plasmonic catalysts on expensive, rare metals is a bottleneck in the development of sustainable large-scale photocatalytic methods. 

Basing hybrid plasmonic catalysts on expensive, rare metals is a bottleneck in the development of sustainable large-scale photocatalytic methods. New abundant plasmonic materials like Al,<sup>160,275,276</sup> Cu,<sup>35,62,113,186,199</sup> Mg,<sup>277</sup> metal oxides,<sup>278−280</sup> metal nitrides<sup>281</sup> or even 2D materials,<sup>93</sup> are emerging candidates in plasmonic catalysis. However, they have been relatively unexplored until now. Moreover, hybrid combinations of these materials are a very interesting and emerging field to explore further. Research in these directions and with these materials could merge plasmonic catalysis with sustainable and large-scale solar-to-chemical energy conversion routes, disclosing the real potential for the industrial application of these concepts. 

Another key parameter in (electro)photocatalysis is the light source. Figure 8b shows the histogram of illumination sources 

among the publications reviewed here. The most used is the xenon lamp, because its emission spectrum resembles the solar one in the wavelength range 290−700 nm. They account for 68% of the examples, followed by monochromatic laser light with 9%. Lasers are chosen to match the plasmonic absorption peak of the used photocatalyst and are a useful tool to study the wavelength dependence of their properties. In addition, they can provide higher irradiances. The third most frequent illumination source is light-emitting diodes (LEDs), 8%. 365 nm LEDs are particularly popular for electrochemical CO2 reduction, as they can induce the generation of allyl alcohol on Ag/Cu hybrids. Only 7% use AM 1.5 G sources, which are the standard for solar simulators. 

Quantitative comparison among different photocatalysts is challenging due to the existent discrepancies in reported metrics and the high number of relevant experimental parameters involved, usually not reported.<sup>104,105</sup> We believe that the field can benefit from standardization of reported activity metrics and measurement conditions. The adopted metric should incorporate information on the amount of catalyst and the intensity of the employed light. For this reason, we propose the implementation of the following activity metric: 



<!-- Start of picture text -->
n product<br>ϕ =<br>m × t × I<br>catalyst (6)<br><!-- End of picture text -->

where nproduct is the amount of generated product, t is the time interval, mcatalyst is this mass of illuminated catalyst, and I is the 



Figure 9. Hybrid plasmonic nanomaterials for the generation of solar fuels. Formation rates for (a) H2 generation and (b) CO2 reduction for the different hybrid photocatalysts reviewed here. The dashed line illustrates the order of magnitude achieved with prominent examples of non-plasmonic catalysts. (c) Formation rate vs selectivity and (d) histogram of the number of publications vs the minor products reported. 

802 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

incident light irradiance. This quantity will only be meaningful if measured far from saturation, i.e., with a linear dependence on time and catalyst concentration, in a large excess of reactants. Plasmonic systems have resonances, and therefore their activities are expected to be wavelength dependent. For this reason, the spectral composition of the illumination source must always be reported. Standardization of the employed light sources would allow a proper comparison among systems. The reasonable choice for the field of artificial photosynthesis would be AM 1.5 global light sources. Additionally, to investigate the role of the spectral composition of light on the efficiency, measuring single-wavelength yields using monochromatic irradiation may be useful. 

It is important to compare plasmonic catalysts operating at similar bulk temperatures of the photoreactor. However, less than half (47%) of the publications reviewed here have reported a controlled reactor temperature. In addition, variations in the geometry of the photoreactors could also lead to discrepancies in the reported performances, even with the same employed catalyst.<sup>282</sup> To overcome this issue, the field could benefit from the establishment of a standard photocatalyst, to be used as an internal reference at each laboratory, in a similar fashion as it was proposed for semiconducting photocatalytic materials.<sup>283</sup> 

In many of the examples reviewed here, the information on reaction conditions is incomplete. In addition, even when reported, conditions vary among the different examples. Nevertheless, we believe that insightful conclusions can be obtained from the comparison of formation rates. Although the comparison between two photocatalysts is not exact under different conditions, we will focus here on evaluations of orders of magnitude in the produced formation rates. While doing so, we aim at identifying the best performers and the ones with the highest potential among the multiple hybrid plasmonic catalysts demonstrated in the past years. 

Figure 9 shows the formation rates extracted from all tables in this Review for photocatalytic H2 generation (Figure 9a) and CO2 reduction (Figure 9b). Exploration of plasmonic systems for H2 has been the most extensive, accounting for 71% of the publications reviewed here. Among the systems used for H2 production, the most popular were plasmonic metal−2D catalysts (38%), followed by metal−electrochemistry (25%), metal−semiconductor (18%), metal−perovskite (7%), metal−metal (7%), and metal−MOF (5%). For CO2 reduction, the most popular were also plasmonic metal−2D catalysts (25%), followed by metal−electrochemistry (20%), metal−semiconductor (18%), metal−metal (17%), metal− MOF (13%), and metal−perovskite (7%). The range of formation rates reported and the most efficient systems depend on the reaction under study. We will now break down the analysis into the different reactions of interest. 

Hybrid Plasmonic Nanomaterials for Photocatalytic Hydrogen Production. The performance of different plasmonic catalysts will be evaluated for the following three hydrogen production reactions: ammonia borane dehydrogenation, formic acid dehydrogenation, and water-splitting. 

The hydrolytic dehydrogenation of ammonia borane was found to be the hydrogen generation reaction with the highest formation rate. An outstandingly high formation rate of 10<sup>8</sup> μmol g<sup>−1</sup> h<sup>−1</sup> at 40 °C was observed employing core−shell Ag@Pd nanostructures.<sup>109</sup> To put this number into context, one of the highest reported performances of heterogeneous catalytic systems for hydrolysis of ammonia borane at room 

temperature is 69.8 mol/min using porous Pt25Pd75NPs<sup>284</sup> This translates to 3 × 10<sup>7</sup> μmol g<sup>−1</sup> h<sup>−1</sup> if a molar ratio of 25% Pt and 75% Pd is assumed. Therefore, the core−shell Ag@Pd nanostructures offer a comparable performance with just a 1.3 nm layer of Pd and a relatively mild illumination source of 50 mW cm<sup>−2</sup> (on the order of half the average solar irradiance). 

The hydrogen generation from formic acid dehydrogenation was possible with formation rates of the order between 10<sup>2</sup> and 10<sup>6</sup> μmol g<sup>−1</sup> h<sup>−1</sup> , as shown in Figure 9a. The metal−metal AgPd catalyst loaded on 2D graphitic carbon nitride nanosheets achieved the highest formation rate (2 × 10<sup>6</sup> μmol g<sup>−1</sup> h<sup>−1</sup> ).<sup>187</sup> Furthermore, AuNPs interfaced with a metal (Pd) or semiconductor (CdS) were also capable of photocatalyzing formic acid dehydrogenation with formation rates in the order of 10<sup>5</sup> μmol g<sup>−1</sup> h<sup>−1</sup> .<sup>114,132</sup> However, metal− semiconductor systems were able to reach these formation rates at room temperatures, while the highest activities in metal−metal systems required temperatures between 40 and 50 °C. In addition, semiconductors are typically cheaper and more abundant than catalytic metals, indicating that metal− semiconductors systems could be preferable for this reaction over metal−metal systems. Overall, the best activities for photocatalytic hydrogen generation from formic acid with plasmonic systems are comparable to the activity of heterogeneous catalysis at room temperature and without light, where formation rates on the order of 10<sup>6</sup> μmol g<sup>−1</sup> h<sup>−1</sup> were also achieved, e.g., using 2.2 nm Ag42Pd58 NPs.<sup>285</sup> 

Reviewing H2 generation from water-splitting reactions, we observed formation rates of the order between 10<sup>0</sup> and 10<sup>5</sup> μmol g<sup>−1</sup> h<sup>−1</sup> . The highest activity was 3.5 × 10<sup>5</sup> μmol g<sup>−1</sup> h<sup>−1</sup> , achieved using plasmonic PtNPs incorporated in nanostructured TiO2,<sup>130</sup> closely followed by a dual metal− semiconductor system including both Au@CdS and Ag@ SiO2 and achieving 2 × 10<sup>5</sup> μmol g<sup>−1</sup> h<sup>−1</sup> at a temperature of 15 °C.<sup>132</sup> In addition, using metal−metal ZnCu plasmonic alloys, formation rates on the order of 10<sup>5</sup> μmol g<sup>−1</sup> h<sup>−1</sup> were also achieved, illustrating an interesting demonstration that does not utilize Au or Ag.<sup>113</sup> . Another example that does not use Au or Ag as the plasmonic component are CuNPs interfaced with WS2 nanosheets that produced 10<sup>4</sup> μmol g<sup>−1</sup> h<sup>−1</sup> of hydrogen under 1 solar irradiation.<sup>186</sup> Finally, it has been shown that it is possible to drive water-splitting reactions using perovskites. However, up to date, most examples still show limited efficiencies in the order of 10<sup>3</sup> μmol g<sup>−1</sup> h<sup>−1</sup> . Remarkably, the highest plasmonic activities for water-splitting are 1 order of magnitude larger than the best activities achieved by other non-plasmonic graphitic carbon nitride-based photocatalysts.<sup>286,287</sup> This demonstrates that plasmonic nanomaterials have a substantial potential for water-splitting reactions. 

Hybrid Plasmonic Nanomaterials for Photocatalytic CO2 Reduction. As shown in Figure 9b, the formation rates for CO2 reduction are in general lower than for hydrogen production, in the range of 10<sup>−1</sup> −10<sup>3</sup> μmol g<sup>−1</sup> h<sup>−1</sup> . Moreover, we can observe that the main product of many catalysts for CO2 reduction is CO (56%), followed by CH4 (32%). Figure 9c shows formation rate of each reactions main product versus its selectivity. The plot has less points than Figure 9b because selectivity is less commonly reported. Interestingly, in the cases where it is reported, it is higher than 50%. It must be noted that there is a lack of examples where products with more than one carbon (such as C2H6, C2H4, and C3H6) are produced with high selectivity. However, these chemicals have been obtained as minor products in numerous publications. Figure 

803 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

9d shows the reported minor products for CO2 reduction, showing that C−C coupling reactions are indeed possible to achieve with plasmonic catalysts. This is a very interesting but poorly explored route so far. 

##### The main product of many catalysts for CO2 reduction is CO, followed by CH4. 

To date, the highest reported performance for producing CO was obtained using AgNPs deposited onto a MOF. Specifically, MIL−101(Cr)/Ag showed a CO production of 8 × 10<sup>2</sup> μmol g<sup>−1</sup> h<sup>−1</sup> at 50 °C, with a selectivity of 61.3%.<sup>241</sup> The hybrids with the next best production rates are plasmonic−2D Ag/rGO achieving 10<sup>2</sup> μmol g<sup>−1</sup> h<sup>−1</sup> at 45 °C, with a high selectivity close to 100%.<sup>184</sup> Furthermore, plasmonic-semiconductor systems formed by Au/CdSe-Cu2O obtained a CO formation rate of 80.2 μmol g<sup>−1</sup> h<sup>−1</sup> .<sup>123</sup> It should be noted that to date, there have been no reports of bimetallic PNPs for this reaction. The highest activity obtained with plasmonic hybrids is comparable to what can be achieved by a non-plasmonic g-C3N4 nanosheet with B−H bonding decorated MOF (∼10<sup>3</sup> μmol g<sup>−1</sup> h<sup>−1</sup> ).<sup>288</sup> 

The second main product obtained from the reduction of CO2 was CH4. This reaction requires multiple electron transfers, and therefore CH4 is more difficult to produce than CO. The best catalysts for producing CH4 were metal− 2D materials. All examples exhibited formation rates on the order of 10<sup>2</sup> . A system consisting of AgNPs combined with N- doped TiO2 nanosheets achieved a formation rate of 79 μmol g<sup>−1</sup> h<sup>−1</sup> with almost 100% selectivity. Another plasmonic-2D material Au/MoS2, also showed CH4 production rate on the same order of magnitude, achieving 20 μmol g<sup>−1</sup> h<sup>−1</sup> with a selectivity of 98%. From the metal-semiconductor category there was one example achieving that order of magnitude with 13 μmol g<sup>−1</sup> h<sup>−1</sup> . It must be noted that CH4 production from CO2 was also demonstrated with metal and metal−MOF systems but with lower activities. The formation rates for CH4 production with plasmonic systems are still lower than the ones recently achieved by non-plasmonic photocatalytic systems such as g-C3N4 nanosheet with B−H bonding decorated MOF (1.5 × 10<sup>4</sup> μmol g<sup>−1</sup> h<sup>−1</sup> ) or titanium carbide compounds (786 μmol g<sup>−1</sup> h<sup>−1</sup> ).<sup>288,289</sup> 

Finally, there are two examples worth mentioning where methanol and formic acid were obtained as main products with close to 100% selectivity using plasmonic-MOF systems. First, AuNPs incorporated in a zeolitic imidazolate framework (ZIF67) produced 2 × 10<sup>3</sup> μmol g<sup>−1</sup> h<sup>−1</sup> of methanol under irradiation from a solar simulator.<sup>87</sup> Second, hybrids of porphyrin frameworks loaded with AuNPs produced 40 μmol g<sup>−1</sup> h<sup>−1</sup> of formic acid at room temperature.<sup>240</sup> These two examples show the great potential of plasmonic−MOF systems for selective reduction of CO2 into solar fuels. 

Hybrid Plasmonic Nanomaterials for Photoelectrocatalytic H2O Splitting and CO2 Reduction. Illuminated plasmonic nanomaterials can successfully decrease the overpotentials required for electrocatalytic hydrogen evolution. Figure 10a summarizes the required overpotentials of all the plasmonic system reviewed here, at a current density of 10 mA cm<sup>−2</sup> . Notably, there are several examples of metal−metal hybrids requiring overpotentials lower than 100 mV. The best performer plasmonic system was metal−metal Pt/Fe@Au nanorods that were able to reduce the overpotential to 18 mV under irradiation.<sup>215</sup> In addition, this system showed a Tafel slope of 29.3 mV/dec, which is close to the theoretical minimum of the Tafel slope in hydrogen evolution from aqueous solution.<sup>290</sup> Plasmonic metals in combination with semiconductors and 2D materials were also capable of delivering low overpotentials. Upon illumination, the overpotential was 45 mV for nanoperforated Au films on a Ti/TiO2 film, due to the facilitated electron transfer at the Au and TiO2 Schottky barrier.<sup>257</sup> By employing Au nanorods on a graphene/MoS2 substrate it was possible to lower the required overpotential to 28 mV.<sup>259</sup> On the other hand, MOFs systems presented larger overpotentials above 292 mV. Although MOFs with large specific surface area could provide more catalytic sites for plasmonic electrocatalysts, their usually high resistivity retards the hydrogen evolution activity. 

One way to evaluate the role of light in photoelectrocatalysis is to measure the Tafel slope decrease under illumination. Figure 10b shows the Tafel slope reduction of every system in this Review. Decreases are most significant in metal−2D hybrids, highlighting the beneficial contribution of plasmonics to promote photoexcited charge separation in these materials. 

Overall, it can be concluded that metal−metal and metal− 2D hybrid nanostructures have shown the greatest photo- 



Figure 10. (a) Overpotential for plasmon-assisted electrocatalytic HER for all hybrid systems reviewed here. (b) Tafel slope decrease upon illumination of hybrid plasmonic electrocatalysts. 

804 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

electrocatalytic performances and are the most promising materials for catalyzing the HER. 

Plasmonic systems are also beneficial to enhance CO2 electroreduction. However, up to date, we were able to find only eight published examples. Among these, some remarkable performances can be highlighted. For example, by using a metal−metal Ag/Cu hybrid plasmonic system, it was possible to enhance the CO partial current density by 200% when illuminated.<sup>270</sup> In another example, using a Cu/p-NiO metal− semiconductor hybrid, the partial current density values of CO and HCOOH increased by 260% and 100% under illumination.<sup>62</sup> 

Regarding the selectivity of CO2 reduction, most reviewed plasmonic electrocatalysts displayed an improved FE toward specific products. For example, the FE of carbon monoxide and formate on Cu/p-NiO with illumination increased by 217% and 267%, respectively.<sup>62</sup> Another interesting example of improved FE was the achieved 95% CO FE of Ag/Ti film under 365 nm LED illumination at −0.6 VRHE.<sup>94</sup> This performance is better than that of one of the top pure electrocatalysts: nanoporous Ag achieved 92% CO FE at −0.6 V.<sup>291</sup> These results indicate that metal−semiconductor hybrids are promising systems to improve CO2 electroreduction activity and selectivity by plasmon excitation. 

Remarkably, the hydrogen formation rates achieved by plasmonic catalysts are comparable to state-of-the-art technologies, with the advantage of generally employing milder reaction conditions or less expensive materials. 

In spite of the advances made in the design of hybrid plasmonic nanomaterials for photoelectrocatalytic CO2 reduction and hydrogen evolution, the role of the plasmon is still unclear. In pure electrocatalytic CO2 reduction, the interface between metal and oxide semiconductor is usually considered as the active catalytic center as it facilitates the stabilization of reaction intermediates.<sup>292</sup> Plasmon excitation is expected to be beneficial for CO2 reduction at the interface, because the photothermal effect and electromagnetic field enhancement could facilitate the CO2 activation by lowering the reaction energy barrier.<sup>293</sup> However, the exact role of plasmon excitation on the stabilization of CO2 intermediates is still elusive. More detailed investigation should be focused on unraveling the origin of the plasmonic enhancement. For example, electrochemically in situ Raman<sup>190</sup> and Fourier transform infrared spectroscopy (FTIR)<sup>270</sup> can be employed to unveil the plasmon-enhanced photoelectrocatalytic reaction mechanisms. These methods employed with and without light irradiation could provide some insight into how the plasmon excitation changes the reaction pathway of electrocatalytic processes on plasmonic electrodes. Additionally, a significant enhancement of photocurrent is crucial for the improvement of plasmon-assisted photoelectrocatalytic performance. However, the short lifetime of hot carriers in plasmonic nanomaterials results in a low incident photon-to-electron conversion efficiency (IPCE), which limits the activity enhancement in plasmon-assisted photoelectrocatalytic hydrogen evolution and CO2 reduction. To this end, the interface between components in hybrid plasmonic nanostructures that can enhance the hot 

electron−hole separation efficiency is a key factor to achieve a high plasmonic enhancement.<sup>13,115,117</sup> Therefore, it is pivotal to optimize the interface between plasmonic metals and hybrid components to prolong the lifetime of hot electrons generated from the plasmon dephasing. Consequently, more efforts should be made to explore the materials with high electron mobility or long electron diffusion length as the candidate to couple with plasmonic metals. 

Outlook. We have critically reviewed and benchmarked a large set of recently reported hybrid plasmonic materials for solar fuel production. Remarkably, the hydrogen formation rates achieved by plasmonic catalysts are comparable to state of the art technologies, with the advantage of generally employing milder reaction conditions or less expensive materials, such as metal−semiconductor or metal−2D hybrids. However, most of these examples were performed with irradiances larger than expected for sunlight-driven catalysis. To reach or surpass these formation values with irradiances comparable to sunlight, further development of sunlight concentrators or focusing devices is still needed as well as novel reactor designs that can maximize light penetration and absorption. Scalability of these technologies seems possible but is scarcely explored so far. On the other hand, carbon dioxide reduction with plasmonic catalysts has not yet shown such appealing results as hydrogen generation. In general, the selectivity and efficiency for this reaction when employing hybrid plasmonic materials are still far from those of the excellent electrocatalysts reported in the literature. In this sense, the combination of plasmonic materials with metal organic frameworks appears as a promising route to explore, with few but remarkable results so far. Additionally, the combination of more than two types of materials into higher order plasmonic hybrid systems may not only allow the exploitation of the properties of the respective two-component hybrid systems but also introduce new synergies.<sup>85,180</sup> Finally, even though we have only focused on solar fuels, plasmonic hybrids might present interesting opportunities for the production of highly valuable chemicals that in most cases require the use of expensive precious metal (electro)catalysts.<sup>294</sup> In this context, earth-abundant plasmonic materials have been rarely explored for catalysis; Al, TiN, some metal oxides, among others are materials that deserve further attention. Interestingly, plasmonic materials as support of single catalytic atoms could also become a promising route for the future development of the field.<sup>295</sup> From the analysis of the systems reported here, the combination of plasmonic materials with also earth-abundant hybrid materials, such as nitrides (TiN, g-C3N4) and MOFs, may lead to new routes toward efficient and selective sustainable catalysis. 

## ■<sup>AUTHORINFORMATION</sup> 

###### Corresponding Author 

- Emiliano Cortés − Faculty of Physics, Ludwig-MaximiliansUniversität, 80539 Munchen,̈ Germany; orcid.org/00000001-8248-4165; Email: emiliano.cortes@lmu.de 

###### Authors 

- Simone Ezendam − Faculty of Physics, Ludwig-MaximiliansUniversität, 80539 Munchen,̈ Germany 

- Matias Herran − Faculty of Physics, Ludwig-MaximiliansUniversität, 80539 Munchen,̈ Germany 

- Lin Nan − Faculty of Physics, Ludwig-MaximiliansUniversität, 80539 Munchen,̈ Germany 

805 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

- Christoph Gruber − Faculty of Physics, Ludwig-MaximiliansUniversität, 80539 Munchen,̈ Germany; orcid.org/00000002-6272-0543 

- Yicui Kang − Faculty of Physics, Ludwig-MaximiliansUniversität, 80539 Munchen,̈ Germany 

- Franz Gröbmeyer − Faculty of Physics, Ludwig-MaximiliansUniversität, 80539 Munchen,̈ Germany 

- Rui Lin − Faculty of Physics, Ludwig-Maximilians-Universität, 80539 Munchen,̈ Germany 

- Julian Gargiulo − Faculty of Physics, Ludwig-MaximiliansUniversität, 80539 Munchen,̈ Germany; orcid.org/00000002-4524-3423 

- Ana Sousa-Castillo − Faculty of Physics, Ludwig-MaximiliansUniversität, 80539 Munchen,̈ Germany 

Complete contact information is available at: https://pubs.acs.org/10.1021/acsenergylett.1c02241 

###### Notes 

The authors declare no competing financial interest. Author group website: https://www.hybridplasmonics.org/. 

###### Biographies 

Simone Ezendam obtained her masters degree in physics from Ludwig-Maximilians-Universitaẗ München (LMU) in 2018 and is currently a Ph.D. candidate under the supervision of Prof. Cortés. Her current research interest lies in the operando mapping of reaction sites on nanocatalysts using super resolution techniques. 

Matias Herran graduated from University of La Plata, Argentina, and now is a Ph.D. student at LMU. His research focuses on the design of novel plasmonic hybrid nanoreactors for photocatalysis applications. 

Lin Nan received her M.Sc. degrees in mechanical engineering and materials engineering and science from Korea Advanced Institute of Science and Technology. Currently, she is a doctoral candidate at the physics department at LMU. Her research interests are hot-electron dynamics in various materials and developing novel top-down fabrication methods. 

Christoph Gruber received his bachelors degree in Chemistry from the Friedrich-Alexander University Erlangen-Nuremberg in 2017. After his masters program at the LMU, he joined Prof. Corts group as Ph.D. student in 2019. His research is focused on novel applications of interferometric scattering for energy conversion materials. 

Yicui Kang received her masters degree in physics from LMU in 2021. Now she is a Ph.D. student at LMU, under the supervision of Prof. Emiliano Cortés. Her current research interests are electrocatalytic CO2RR and plasmonic electrocatalysis. 

Franz Gröbmeyer is currently a master student at LMU. His main research direction is interferometric scattering microscopy with a focus on imaging nanoscale electrochemical processes allowing to investigate nanomaterials for energy conversion. 

Rui Lin is an Alexander Von Humboldt postdoctoral research fellow at LMU, Germany. He obtained his Ph.D. in Chemistry department of Tsinghua University, China in 2019. His research interests include nanofabrication, artificial photosynthesis, and plasmonics. His current works focus on exploring photonic nanomaterials for solar energy conversion. 

Julian Gargiulo received his Ph.D. degree in Physics at the Universidad de Buenos Aires. He was a Marie Skodowska Curie research fellow at Imperial College London and a CONICET Assistant Investigator in Argentina. He is currently a P.R.I.M.E research fellow at the Center for Bionanoscience Research (CIBION) in Argentina and at LMU in Germany. 

Ana Sousa-Castillo obtained her Ph.D. in Chemistry from the University of Vigo, Spain, in 2017. Subsequently, she joined Prof. Cortés group with a postdoctoral fellowship from Xunta de Galicia, Spain. Her research interests focus on colloidal synthesis and characterization of plasmonic metal nanohybrids for photocatalysis. 

Emiliano Cortés is Professor in Energy Conversion at the Faculty of Physics, LMU (Germany) and visiting researcher at the Physics Department, Imperial College London (UK). He is coeditor of the first book on Plasmonic Catalysis, member of the excellence cluster e- conversion, the Centre for NanoScience (CeNS), the Bavarian program Solar Technologies go Hybrid (SolTech), and the Young Academy of Europe (YAE). 

## ■<sup>ACKNOWLEDGMENTS</sup> 

We acknowledge funding and support from the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation) under Germany’s Excellence Strategy, EXC 2089/1390776260, the Bavarian program Solar Energies Go Hybrid (SolTech), the Center for NanoScience (CeNS), and the European Commission through the ERC Starting Grant CATALIGHT (802989). A.S.C. acknowledges Xunta de Galicia, Spain, for her postdoctoral fellowship. R.L. acknowledges the support from the Humboldt Foundation. J.G. acknowledges the PRIME programme of the German Academic Exchange Service (DAAD) with funds from the German Federal Ministry of Education and Research (BMBF). We thank Vera Hiendl for support in graphics design. 

## ■<sup>REFERENCES</sup> 

(1) Intergovernmental Panel on Climate Change Drivers, Trends and Mitigation. AR5 Climate Change 2014: Mitigation of Climate Change; Cambridge University Press: , Cambridge, UK and New York, 2015; Chap. 5, pp 351−412. 

(2) IEA. World Energy Balances: Overview. https://www.iea.org/ reports/world-energy-balances-overview/world. 

- (3) Maier, S. A. Plasmonics: Fundamentals and Applications; Springer, 

- 2007. 

(4) Giannini, V.; Fernandez-Dominguez, A. I.; Heck, S. C.; Maier, S. A. Plasmonic nanoantennas: Fundamentals and their use in controlling the radiative properties of nanoemitters. Chem. Rev. 2011, 111, 3888−3912. 

(5) Coronado, E. A.; Encina, E. R.; Stefani, F. D. Optical properties of metallic nanoparticles: Manipulating light, heat and forces at the nanoscale. Nanoscale 2011, 3, 4042−4059. 

(6) Mubeen, S.; Lee, J.; Singh, N.; Krämer, S.; Stucky, G. D.; Moskovits, M. An autonomous photosynthetic device in which all charge carriers derive from surface plasmons. Nat. Nanotechnol. 2013, 8, 247−251. 

(7) Linic, S.; Christopher, P.; Ingram, D. B. Plasmonic-metal nanostructures for efficient conversion of solar to chemical energy. Nat. Mater. 2011, 10, 911−921. 

(8) Christopher, P.; Xin, H.; Linic, S. Visible-light-enhanced catalytic oxidation reactions on plasmonic silver nanostructures. Nat. Chem. 2011, 3, 467−472. 

- (9) Christopher, P.; Xin, H.; Marimuthu, A.; Linic, S. Singular 

- characteristics and unique chemical bond activation mechanisms of photocatalytic reactions on plasmonic nanostructures. Nat. Mater. 2012, 11, 1044−1050. 

(10) Linic, S.; Aslam, U.; Boerigter, C.; Morabito, M. Photochemical transformations on plasmonic metal nanoparticles. Nat. Mater. 2015, 14, 567−576. 

(11) Mukherjee, S.; Libisch, F.; Large, N.; Neumann, O.; Brown, L. V.; Cheng, J.; Lassiter, J. B.; Carter, E. A.; Nordlander, P.; Halas, N. J. Hot electrons do the impossible: Plasmon-induced dissociation of H2 on Au. Nano Lett. 2013, 13, 240−247. 

806 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

(12) Kamarudheen, R.; Aalbers, G. J. W.; Hamans, R. F.; Kamp, L. P. J.; Baldi, A. Distinguishing Among All Possible Activation Mechanisms of a Plasmon-Driven Chemical Reaction. ACS Energy Letters 2020, 5, 2605−2613. 

- (13) Zhang, Y.; He, S.; Guo, W.; Hu, Y.; Huang, J.; Mulcahy, J. R.; 

- Wei, W. D. Surface-Plasmon-Driven Hot Electron Photochemistry. Chem. Rev. 2018, 118, 2927−2954. 

- (14) Li, S.; Miao, P.; Zhang, Y.; Wu, J.; Zhang, B.; Du, Y.; Han, X.; 

- Sun, J.; Xu, P. Recent Advances in Plasmonic Nanostructures for Enhanced Photocatalysis and Electrocatalysis. Adv. Mater. 2021, 33, 2000086. 

- (15) Huang, H. J.; Wu, J. C.-S.; Chiang, H.-P.; Chou Chau, Y.-F.; 

- Lin, Y.-S.; Wang, Y. H.; Chen, P.-J. Review of experimental setups for plasmonic photocatalytic reactions. Catalysts 2020, 10, 46. 

- (16) Zhan, C.; Moskovits, M.; Tian, Z. Q. Recent Progress and 

- Prospects in Plasmon-Mediated Chemical Reaction. Matter 2020, 3, 42−56. 

(17) Jain, P. K. Taking the Heat off of Plasmonic Chemistry. J. Phys. Chem. C 2019, 123, 24347−24351. 

- (18) Graziano, G. All-plasmonic water splitting. Nature Nano- 

- technology 2021, 16, 1053. 

(19) Cortés, E.; Camargo, P. H. C. Plasmonic catalysis from fundamentals to applications; John Wiley & Sons, 2021. 

(20) Martirez, J. M. P.; Bao, J. L.; Carter, E. A. First-Principles Insights into Plasmon-Induced Catalysis. Annu. Rev. Phys. Chem. 2021, 72, 99−119. 

(21) Li, X.; Everitt, H. O.; Liu, J. Synergy between thermal and nonthermal effects in plasmonic photocatalysis. Nano Research 2020, 13, 1268. 

(22) Sivan, Y.; Baraban, J. H.; Dubi, Y. Experimental practices required to isolate thermal effects in plasmonic photo-catalysis: lessons from recent experiments. OSA Continuum 2020, 3, 483. 

(23) Sun, Y.; Tang, Z. Photocatalytic hot-carrier chemistry. MRS Bull. 2020, 45, 20−25. 

(24) Luo, S.; Ren, X.; Lin, H.; Song, H.; Ye, J. Plasmonic photothermal catalysis for solar-to-fuel conversion: current status and prospects. Chemical Science 2021, 12, 5701−5719. 

(25) Mascaretti, L.; Naldoni, A. Hot electron and thermal effects in plasmonic photocatalysis. J. Appl. Phys. 2020, 128, 041101. 

(26) Devasia, D.; Das, A.; Mohan, V.; Jain, P. K. Control of Chemical Reaction Pathways by Light−Matter Coupling. Annu. Rev. Phys. Chem. 2021, 72, 423−443. 

(27) Gellé, A.; Jin, T.; De La Garza, L.; Price, G. D.; Besteiro, L. V.; Moores, A. Applications of Plasmon-Enhanced Nanocatalysis to Organic Transformations. Chem. Rev. 2020, 120, 986−1041. 

(28) Verma, R.; Belgamwar, R.; Polshettiwar, V. Plasmonic Photocatalysis for CO2 Conversion to Chemicals and Fuels. ACS Materials Letters 2021, 3, 574−598. 

(29) Linic, S.; Chavez, S.; Elias, R. Flow and extraction of energy and charge carriers in hybrid plasmonic nanostructures. Nat. Mater. 2021, 20, 916−924. 

(30) Ramakrishnan, S. B.; Mohammadparast, F.; Dadgar, A. P.; Mou, T.; Le, T.; Wang, B.; Jain, P. K.; Andiappan, M. Photoinduced Electron and Energy Transfer Pathways and Photocatalytic Mechanisms in Hybrid Plasmonic Photocatalysis. Advanced Optical Materials 2021, 9, 2101128. 

(31) Wu, N. Plasmonic metal-semiconductor photocatalysts and photoelectrochemical cells: A review. Nanoscale 2018, 10, 2679− 2696. 

(32) Kavitha, R.; Kumar, S. G. A review on plasmonic Au-ZnO heterojunction photocatalysts: Preparation, modifications and related charge carrier dynamics. Materials Science in Semiconductor Processing 2019, 93, 59−91. 

(33) Abouelela, M. M.; Kawamura, G.; Matsuda, A. A review on plasmonic nanoparticle-semiconductor photocatalysts for water splitting. Journal of Cleaner Production 2021, 294, 126200. 

(34) Bardey, S.; Bonduelle-Skrzypczak, A.; Fécant, A.; Cui, Z.; Colbeau-Justin, C.; Caps, V.; Keller, V. Plasmonic photocatalysis applied to solar fuels. Faraday Discussions 2019, 214, 417−439. 

(35) Marimuthu, A.; Zhang, J.; Linic, S. Tuning selectivity in propylene epoxidation by plasmon mediated photo-switching of Cu oxidation state. Science 2013, 339, 1590−1593. 

(36) Mukherjee, S.; Zhou, L.; Goodman, A. M.; Large, N.; AyalaOrozco, C.; Zhang, Y.; Nordlander, P.; Halas, N. J. Hot-electroninduced dissociation of H2 on gold nanoparticles supported on SiO2. J. Am. Chem. Soc. 2014, 136, 64−67. 

(37) Swearer, D. F.; Zhao, H.; Zhou, L.; Zhang, C.; Robatjazi, H.; Martirez, J. M. P.; Krauter, C. M.; Yazdi, S.; McClain, M. J.; Ringe, E.; Carter, E. A.; Nordlander, P.; Halas, N. J. Heterometallic antennareactor complexes for photocatalysis. Proc. Natl. Acad. Sci. U.S.A. 2016, 113, 8916−8920. 

(38) Aslam, U.; Chavez, S.; Linic, S. Controlling energy flow in multimetallic nanostructures for plasmonic catalysis. Nat. Nanotechnol. 2017, 12, 1000−1005. 

(39) Li, J.; Xu, X.; Huang, B.; Lou, Z.; Li, B. Light-Induced in Situ Formation of a Nonmetallic Plasmonic MoS2/MoO3−X Heterostructure with Efficient Charge Transfer for CO2 Reduction and SERS Detection. ACS Appl. Mater. Interfaces 2021, 13, 10047−10053. 

(40) Li, R.; Cheng, W. H.; Richter, M. H.; Duchene, J. S.; Tian, W.; Li, C.; Atwater, H. A. Unassisted Highly Selective Gas-Phase CO2 Reduction with a Plasmonic Au/p-GaN Photocatalyst Using H2O as an Electron Donor. ACS Energy Letters 2021, 6, 1849−1856. 

(41) Gargiulo, J.; Berté, R.; Li, Y.; Maier, S. A.; Cortés, E. From Optical to Chemical Hot Spots in Plasmonics. Acc. Chem. Res. 2019, 52, 2525−2535. 

(42) Cortés, E. Activating plasmonic chemistry: Plasmonic photocatalysts can reduce activation barriers and unlock reaction pathways. Science 2018, 362, 28−29. 

(43) Zhou, L.; Swearer, D. F.; Zhang, C.; Robatjazi, H.; Zhao, H.; Henderson, L.; Dong, L.; Christopher, P.; Carter, E. A.; Nordlander, P.; Halas, N. J. Quantifying hot carrier and thermal contributions in plasmonic photocatalysis. Science 2018, 362, 69−72. 

(44) Hammer, B.; Norskov, J. K. Why gold is the noblest of all the metals. Nature 1995, 376, 238−240. 

(45) Esterhuizen, J. A.; Goldsmith, B. R.; Linic, S. Theory-Guided Machine Learning Finds Geometric Structure-Property Relationships for Chemisorption on Subsurface Alloys. Chem. 2020, 6, 3100−3117. 

(46) Peljo, P.; Manzanares, J. A.; Girault, H. H. Contact Potentials, Fermi Level Equilibration, and Surface Charging. Langmuir 2016, 32, 5765−5775. 

(47) Lee, S.; Hwang, H.; Lee, W.; Schebarchov, D.; Wy, Y.; Grand, J.; Auguie, B.; Wi, D. H.; Cortes, E.; Han, S. W. Core-Shell Bimetallic Nanoparticle Trimers for Efficient Light-to-Chemical Energy Conversion. ACS Energy Letters 2020, 5, 3881−3890. 

(48) Li, K.; Hogan, N. J.; Kale, M. J.; Halas, N. J.; Nordlander, P.; Christopher, P. Balancing Near-Field Enhancement, Absorption, and Scattering for Effective Antenna-Reactor Plasmonic Photocatalysis. Nano Lett. 2017, 17, 3710−3717. 

(49) Quiroz, J.; et al. Controlling Reaction Selectivity over Hybrid Plasmonic Nanocatalysts. Nano Lett. 2018, 18, 7289−7297. 

(50) Chavez, S.; Aslam, U.; Linic, S. Design Principles for Directing Energy and Energetic Charge Flow in Multicomponent Plasmonic Nanostructures. ACS Energy Letters 2018, 3, 1590−1596. 

(51) Engelbrekt, C.; Crampton, K. T.; Fishman, D. A.; Law, M.; Apkarian, V. A. Efficient Plasmon-Mediated Energy Funneling to the Surface of Au@Pt Core-Shell Nanocrystals. ACS Nano 2020, 14, 5061−5074. 

(52) Brongersma, M. L.; Halas, N. J.; Nordlander, P. Plasmoninduced hot carrier science and technology. Nat. Nanotechnol. 2015, 10, 25−34. 

(53) Inouye, H.; Tanaka, K.; Tanahashi, I.; Hirao, K. Ultrafast dynamics of nonequilibrium electrons in a gold nanoparticle system. Physical Review B - Condensed Matter and Materials Physics 1998, 57, 11334−11340. 

(54) Li, H. J. W.; et al. Metallic MoO2-Modified Graphitic Carbon Nitride Boosting Photocatalytic CO2 Reduction via Schottky Junction. Solar RRL 2020, 4, 1900416. 

807 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

(55) Wu, K.; Chen, J.; McBride, J. R.; Lian, T. Efficient hot-electron transfer by a plasmon-induced interfacial charge-transfer transition. Science 2015, 349, 632−635. 

(56) Kumar, P. V.; Rossi, T. P.; Marti-Dafcik, D.; Reichmuth, D.; Kuisma, M.; Erhart, P.; Puska, M. J.; Norris, D. J. Plasmon-Induced Direct Hot-Carrier Transfer at Metal-Acceptor Interfaces. ACS Nano 2019, 13, 3188−3195. 

(57) Li, J.; Cushing, S. K.; Meng, F.; Senty, T. R.; Bristow, A. D.; Wu, N. Plasmon-induced resonance energy transfer for solar energy conversion. Nat. Photonics 2015, 9, 601−607. 

(58) Cushing, S. K.; Li, J.; Meng, F.; Senty, T. R.; Suri, S.; Zhi, M.; Li, M.; Bristow, A. D.; Wu, N. Photocatalytic activity enhanced by plasmonic resonant energy transfer from metal to semiconductor. J. Am. Chem. Soc. 2012, 134, 15033−15041. 

(59) Zheng, B. Y.; Zhao, H.; Manjavacas, A.; McClain, M.; Nordlander, P.; Halas, N. J. Distinguishing between plasmon-induced and photoexcited carriers in a device geometry. Nat. Commun. 2015, 6, 7797. 

(60) Naldoni, A.; Guler, U.; Wang, Z.; Marelli, M.; Malara, F.; Meng, X.; Besteiro, L. V.; Govorov, A. O.; Kildishev, A. V.; Boltasseva, A.; Shalaev, V. M. Broadband Hot-Electron Collection for Solar Water Splitting with Plasmonic Titanium Nitride. Advanced Optical Materials 2017, 5, 1601031. 

(61) Priebe, J. B.; Radnik, J.; Lennox, A. J. J.; Pohl, M.-M.; Karnahl, M.; Hollmann, D.; Grabow, K.; Bentrup, U.; Junge, H.; Beller, M.; Bruckner, A. Solar Hydrogen Production by Plasmonic Au-TiO2 Catalysts: Impact of Synthesis Protocol and TiO2 Phase on Charge Transfer Efficiency and H2 Evolution Rates. ACS Catal. 2015, 5, 2137−2148. 

(62) Duchene, J. S.; Tagliabue, G.; Welch, A. J.; Li, X.; Cheng, W. H.; Atwater, H. A. Optical Excitation of a Nanoparticle Cu/p-NiO Photocathode Improves Reaction Selectivity for CO2 Reduction in Aqueous Electrolytes. Nano Lett. 2020, 20, 2348−2358. 

(63) Atwater, H. A.; Polman, A. Plasmonics for improved photovoltaic devices. Nat. Mater. 2010, 9, 205−213. 

(64) Aslam, U.; Rao, V. G.; Chavez, S.; Linic, S. Catalytic conversion of solar to chemical energy on plasmonic metal nanostructures. Nature Catalysis 2018, 1, 656−665. 

(65) Bayles, A.; Carretero-Palacios, S.; Calió, L.; Lozano, G.; Calvo, M. E.; Míguez, H. Localized surface plasmon effects on the photophysics of perovskite thin films embedding metal nanoparticles. Journal of Materials Chemistry C 2020, 8, 916−921. 

(66) Kolwas, K.; Derkachova, A. Modification of Solar Energy Harvesting in Photovoltaic Materials by Plasmonic Nanospheres: New Absorption Bands in Perovskite Composite Film. J. Phys. Chem. C 2017, 121, 4524−4539. 

(67) Carretero-Palacios, S.; Calvo, M. E.; Míguez, H. Absorption Enhancement in Organic-Inorganic Halide Perovskite Films with Embedded Plasmonic Gold Nanoparticles. J. Phys. Chem. C 2015, 119, 18635−18640. 

(68) Gong, M.; Alamri, M.; Ewing, D.; Sadeghi, S. M.; Wu, J. Z. Localized Surface Plasmon Resonance Enhanced Light Absorption in AuCu/CsPbCl3 Core/Shell Nanocrystals. Adv. Mater. 2020, 32, 2002163. 

(69) Xu, D.; Liu, D.; Xie, T.; Cao, Y.; Wang, J. G.; Ning, Z. J.; Long, Y. T.; Tian, H. Plasmon resonance scattering at perovskite CH3NH3PbI3 coated single gold nanoparticles: Evidence for electron transfer. Chem. Commun. 2016, 52, 9933−9936. 

(70) Huang, Y.; Liu, J.; Cao, D.; Liu, Z.; Ren, K.; Liu, K.; Tang, A.; Wang, Z. Z.; Li, L.; Qu, S.; Wang, Z. Z. Separation of hot electrons and holes in Au/LaFeO3 to boost the photocatalytic activities both for water reduction and oxidation. Int. J. Hydrogen Energy 2019, 44, 13242−13252. 

(71) Adjokatse, S.; Fang, H. H.; Loi, M. A. Broadly tunable metal halide perovskites for solid-state light-emission applications. Mater. Today 2017, 20, 413−424. 

(72) Qiao, L.; Fang, W. H.; Long, R.; Prezhdo, O. V. Photoinduced Dynamics of Charge Carriers in Metal Halide Perovskites from an Atomistic Perspective. J. Phys. Chem. Lett. 2020, 11, 7066−7082. 

(73) Kang, Y.; Najmaei, S.; Liu, Z.; Bao, Y.; Wang, Y.; Zhu, X.; Halas, N. J.; Nordlander, P.; Ajayan, P. M.; Lou, J.; Fang, Z. Plasmonic Hot Electron Induced Structural Phase Transition in a MoS2 Monolayer. Adv. Mater. 2014, 26, 6467−6471. 

(74) Sun, S.; An, Q.; Watanabe, M.; Cheng, J.; Ho Kim, H.; Akbay, T.; Takagaki, A.; Ishihara, T. Highly correlation of CO2 reduction selectivity and surface electron Accumulation: A case study of AuMoS2 and Ag-MoS2 catalyst. Applied Catalysis B: Environmental 2020, 271, 118931. 

(75) Lui, C. H.; Frenzel, A. J.; Pilon, D. V.; Lee, Y.-H.; Ling, X.; Akselrod, G. M.; Kong, J.; Gedik, N. Trion-Induced Negative Photoconductivity in Monolayer MoS2. Phys. Rev. Lett. 2014, 113, 166801. 

(76) Pan, R.; Liu, J.; Zhang, J. Defect Engineering in 2D Photocatalytic Materials for CO2 Reduction. ChemNanoMat 2021, 7, 737−747. 

(77) Foo, M. L.; Matsuda, R.; Kitagawa, S. Functional Hybrid Porous Coordination Polymers. Chem. Mater. 2014, 26, 310−322. 

(78) Férey, G. Hybrid porous solids: past, present, future. Chem. Soc. Rev. 2008, 37, 191−214. 

(79) Furukawa, H.; Cordova, K. E.; O’Keeffe, M.; Yaghi, O. M. The Chemistry and Applications of Metal-Organic Frameworks. Science 2013, 341, 1230444. 

(80) Koh, C. S. L.; Sim, H. Y. F.; Leong, S. X.; Boong, S. K.; Chong, C.; Ling, X. Y. Plasmonic Nanoparticle-Metal-Organic Framework (NP-MOF) Nanohybrid Platforms for Emerging Plasmonic Applications. ACS Materials Letters 2021, 3, 557−573. 

(81) Wang, M.; Tang, Y.; Jin, Y. Modulating Catalytic Performance of Metal-Organic Framework Composites by Localized Surface Plasmon Resonance. ACS Catal. 2019, 9, 11502−11514. 

(82) Li, G.; Zhao, S.; Zhang, Y.; Tang, Z. Metal−organic frameworks encapsulating active nanoparticles as emerging composites for catalysis: Recent progress and perspectives. Adv. Mater. 2018, 30, 1800702. 

(83) Mu, F.; Dai, B.; Zhao, W.; Zhou, S.; Huang, H.; Yang, G.; Xia, D.; Kong, Y.; Leung, D. Y. C. Construction of a novel Ag/Ag3PO4/ MIL-68(In)-NH2 plasmonic heterojunction photocatalyst for highefficiency photocatalysis. Journal of Materials Science & Technology 2022, 101, 37−48. 

(84) Chen, L.-W.; et al. Metal−Organic Framework Membranes Encapsulating Gold Nanoparticles for Direct Plasmonic Photocatalytic Nitrogen Fixation. J. Am. Chem. Soc. 2021, 143, 5727−5736. (85) Choi, K. M.; Kim, D.; Rungtaweevoranit, B.; Trickett, C. A.; Barmanbek, J. T. D.; Alshammari, A. S.; Yang, P.; Yaghi, O. M. Plasmon-enhanced photocatalytic CO2 conversion within metalorganic frameworks under visible light. J. Am. Chem. Soc. 2017, 139, 356−362. 

(86) Wen, M.; Mori, K.; Kuwahara, Y.; Yamashita, H. Plasmonic Au@Pd nanoparticles supported on a basic metal-organic framework: Synergic boosting of H2 production from formic acid. ACS Energy Letters 2017, 2, 1−7. 

(87) Becerra, J.; Nguyen, D.-T.; Gopalakrishnan, V.-N.; Do, T.-O. Plasmonic Au Nanoparticles Incorporated in the Zeolitic Imidazolate Framework (ZIF-67) for the Efficient Sunlight-Driven Photoreduction of CO2. ACS Applied Energy Materials 2020, 3, 7659−7665. (88) Robatjazi, H.; Weinberg, D.; Swearer, D. F.; Jacobson, C.; Zhang, M.; Tian, S.; Zhou, L.; Nordlander, P.; Halas, N. J. Metalorganic frameworks tailor the properties of aluminum nanocrystals. Science Advances 2019, 5, No. eaav5340. 

(89) Xiao, J. D.; Han, L.; Luo, J.; Yu, S. H.; Jiang, H. L. Integration of Plasmonic Effects and Schottky Junctions into Metal−Organic Framework Composites: Steering Charge Flow for Enhanced VisibleLight Photocatalysis. Angewandte Chemie - International Edition 2018, 57, 1103−1107. 

(90) Electrocatalysis for the generation and consumption of fuels. Nature Reviews Chemistry 2018, 2, 0125. 

(91) Landaeta, E.; Masitas, R. A.; Clarke, T. B.; Rafacz, S.; Nelson, D. A.; Isaacs, M.; Schultz, Z. D. Copper-Oxide-Coated Silver Nanodendrites for Photoelectrocatalytic CO2 Reduction to Acetate 

808 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

at Low Overpotential. ACS Applied Nano Materials 2020, 3, 3478− 3486. 

(92) Lu, W.; Ju, F.; Yao, K.; Wei, X. Photoelectrocatalytic reduction of CO2 for efficient methanol production: Au nanoparticles as electrocatalysts and light supports. Ind. Eng. Chem. Res. 2020, 59, 4348−4357. 

(93) Wu, X.; Wang, J.; Wang, Z.; Sun, F.; Liu, Y.; Wu, K.; Meng, X.; Qiu, J. Boosting the Electrocatalysis of MXenes by Plasmon-Induced Thermalization and Hot-Electron Injection. Angewandte Chemie - International Edition 2021, 60, 9416−9420. 

(94) Creel, E. B.; Corson, E. R.; Eichhorn, J.; Kostecki, R.; Urban, J. J.; McCloskey, B. D. Directing Selectivity of Electrochemical Carbon Dioxide Reduction Using Plasmonics. ACS Energy Letters 2019, 4, 1098−1105. 

(95) Piggott, E. K.; Hope, T. O.; Crabbe, B. W.; Jalbert, P. M.; Orlova, G.; Hallett-Tapley, G. L. Exploiting the photocatalytic activity of gold nanoparticle-functionalized niobium oxide perovskites in nitroarene reductions. Catalysis Science and Technology 2017, 7, 5758−5765. 

(96) Liu, J.; Sun, Y.; Li, Z.; Li, S.; Zhao, J. Photocatalytic hydrogen production from water/methanol solutions over highly ordered AgSrTiO3 nanotube arrays. Int. J. Hydrogen Energy 2011, 36, 5811−5816. 

(97) Eppinger, J.; Huang, K. W. Formic Acid as a Hydrogen Energy Carrier. ACS Energy Letters 2017, 2, 188−195. 

(98) Armaroli, N.; Balzani, V. The Hydrogen Issue. ChemSusChem 2011, 4, 21−36. 

(99) Kruger, P. Appropriate technologies for large-scale production of electricity and hydrogen fuel. Int. J. Hydrogen Energy 2008, 33, 5881−5886. 

(100) Enthaler, S.; Von Langermann, J.; Schmidt, T. Carbon dioxide and formic acid - The couple for environmental-friendly hydrogen storage? Energy Environ. Sci. 2010, 3, 1207−1217. 

(101) Stephens, F. H.; Pons, V.; Tom Baker, R. Ammonia−borane: The hydrogen source par excellence? J. Chem. Soc., Dalton Trans. 2007, 0, 2613−2626. 

(102) Santos, D. M.; Sequeira, C. A. Sodium borohydride as a fuel for the future. Renewable and Sustainable Energy Reviews 2011, 15, 3980−4001. 

(103) Jacobson, T. A.; Kler, J. S.; Hernke, M. T.; Braun, R. K.; Meyer, K. C.; Funk, W. E. Direct human health risks of increased atmospheric carbon dioxide. Nature Sustainability 2019, 2, 691−701. 

(104) Habisreutinger, S. N.; Schmidt-Mende, L.; Stolarczyk, J. K. Photocatalytic reduction of CO2 on TiO2 and other semiconductors. Angewandte Chemie - International Edition 2013, 52, 7372−7408. 

(105) Braslavsky, S. E.; Braun, A. M.; Cassano, A. E.; Emeline, A. V.; Litter, M. I.; Palmisano, L.; Parmon, V. N.; Serpone, N. Glossary of terms used in photocatalysis and radiation catalysis (IUPAC recommendations 2011). Pure Appl. Chem. 2011, 83, 931−1014. 

(106) Baffou, G.; Quidant, R.; García De Abajo, F. J. Nanoscale control of optical heating in complex plasmonic systems. ACS Nano 2010, 4, 709−716. 

(107) Pensa, E.; Gargiulo, J.; Lauri, A.; Schlücker, S.; Cortés, E.; Maier, S. A. Spectral Screening of the Energy of Hot Holes over a Particle Plasmon Resonance. Nano Lett. 2019, 19, 1867−1874. 

(108) Kang, N.; Wang, Q.; Djeda, R.; Wang, W.; Fu, F.; Moro, M. M.; Ramirez, M. D. L. A.; Moya, S.; Coy, E.; Salmon, L.; Pozzo, J. L.; Astruc, D. Visible-Light Acceleration of H2 Evolution from Aqueous Solutions of Inorganic Hydrides Catalyzed by Gold-Transition-Metal Nanoalloys. ACS Appl. Mater. Interfaces 2020, 12, 53816−53826. 

(109) Xu, P.; Lu, W.; Zhang, J.; Zhang, L. Efficient Hydrolysis of Ammonia Borane for Hydrogen Evolution Catalyzed by Plasmonic Ag@Pd Core-Shell Nanocubes. ACS Sustainable Chem. Eng. 2020, 8, 12366−12377. 

(110) Tong, F.; Lou, Z.; Liang, X.; Ma, F.; Chen, W.; Wang, Z.; Liu, Y.; Wang, P.; Cheng, H.; Dai, Y.; Zheng, Z.; Huang, B. Plasmoninduced dehydrogenation of formic acid on Pd-dotted Ag@Au hexagonal nanoplates and single-particle study. Applied Catalysis B: Environmental 2020, 277, 119226. 

(111) Yu, S.; Wilson, A. J.; Heo, J.; Jain, P. K. Plasmonic Control of Multi-Electron Transfer and C-C Coupling in Visible-Light-Driven CO2 Reduction on Au Nanoparticles. Nano Lett. 2018, 18, 2189− 2194. 

(112) Dhiman, M.; Maity, A.; Das, A.; Belgamwar, R.; Chalke, B.; Lee, Y.; Sim, K.; Nam, J. M.; Polshettiwar, V. Plasmonic Colloidosomes of Black Gold for Solar Energy Harvesting and Hotspots Directed Catalysis for CO2 to Fuel Conversion. Chemical Science 2019, 10, 6594−6603. 

(113) Luo, S.; Lin, H.; Wang, Q.; Ren, X.; Hernández-Pinilla, D.; Nagao, T.; Xie, Y.; Yang, G.; Li, S.; Song, H.; Oshikiri, M.; Ye, J. Triggering Water and Methanol Activation for Solar-Driven H2 Production: Interplay of Dual Active Sites over Plasmonic ZnCu Alloy. J. Am. Chem. Soc. 2021, 143, 12145−12153. 

(114) Gao, W.; Liu, Q.; Zhao, X.; Cui, C.; Zhang, S.; Zhou, W.; Wang, X.; Wang, S.; Liu, H.; Sang, Y. Electromagnetic induction effect induced high-efficiency hot charge generation and transfer in Pdtipped Au nanorods to boost plasmon-enhanced formic acid dehydrogenation. Nano Energy 2021, 80, 105543. 

(115) Zheng, Z.; Tachikawa, T.; Majima, T. Plasmon-enhanced formic acid dehydrogenation using anisotropic Pd-Au nanorods studied at the single-particle level. J. Am. Chem. Soc. 2015, 137, 948− 957. 

(116) Yin, Y.; Yang, Y.; Zhang, L.; Li, Y.; Li, Z.; Lei, W.; Ma, Y.; Huang, Z. Facile synthesis of Au/Pd nano-dogbones and their plasmon-enhanced visible-to-NIR light photocatalytic performance. RSC Adv. 2017, 7, 36923−36928. 

(117) Lou, Z.; Fujitsuka, M.; Majima, T. Pt-Au Triangular Nanoprisms with Strong Dipole Plasmon Resonance for Hydrogen Generation Studied by Single-Particle Spectroscopy. ACS Nano 2016, 10, 6299−6305. 

(118) Yu, S.; Jain, P. K. Selective Branching of Plasmonic Photosynthesis into Hydrocarbon Production and Hydrogen Generation. ACS Energy Letters 2019, 4, 2295−2300. 

(119) Yu, S.; Jain, P. K. Plasmonic photosynthesis of C1−C3 hydrocarbons from carbon dioxide assisted by an ionic liquid. Nat. Commun. 2019, 10, 2022. 

(120) Zhang, X.-G. G.; Liu, Y.; Zhan, C.; Jin, X.; Chi, Q.; Wu, D.-Y. Y.; Zhao, Y.; Tian, Z.-Q. Q. Reaction Selectivity for Plasmon-Driven Carbon Dioxide Reduction on Silver Clusters: A Theoretical Prediction. J. Phys. Chem. C 2019, 123, 11101−11108. 

(121) Kumari, G.; Zhang, X.; Devasia, D.; Heo, J.; Jain, P. K. Watching visible light-driven CO2 reduction on a plasmonic nanoparticle catalyst. ACS Nano 2018, 12, 8330−8340. 

(122) Devasia, D.; Wilson, A. J.; Heo, J.; Mohan, V.; Jain, P. K. A Rich Catalog of C−C Bonded Species Formed in CO2 Reduction on a Plasmonic Photocatalyst. Nat. Commun. 2021, 12, 2612. 

(123) Wang, H.; Rong, H.; Wang, D.; Li, X.; Zhang, E.; Wan, X.; Bai, B.; Xu, M.; Liu, J.; Liu, J.; Chen, W.; Zhang, J. Highly Selective Photoreduction of CO2 with Suppressing H2 Evolution by Plasmonic Au/CdSe−Cu2 O Hierarchical Nanostructures under Visible Light. Small 2020, 16, 2000426. 

(124) Wang, A.; Wu, S.; Dong, J.; Wang, R.; Wang, J.; Zhang, J.; Zhong, S.; Bai, S. Interfacial Facet Engineering on the Schottky Barrier between Plasmonic Au and TiO2 in Boosting the Photocatalytic CO2 Reduction under Ultraviolet and Visible Light Irradiation. Chemical Engineering Journal 2021, 404, 127145. 

(125) Renones, P.; Collado, L.; Iglesias-Juez, A.; Oropeza, F. E.; Fresno, F.; de la Pena O’Shea, V. A. Silver-Gold Bimetal-Loaded TiO2 Photocatalysts for CO2 Reduction. Ind. Eng. Chem. Res. 2020, 59, 9440−9450. 

(126) Chen, Q.; Chen, X.; Fang, M.; Chen, J.; Li, Y.; Xie, Z.; Kuang, Q.; Zheng, L. Photo-induced Au-Pd alloying at TiO2 101 facets enables robust CO2 photocatalytic reduction into hydrocarbon fuels. Journal of Materials Chemistry A 2019, 7, 1334−1340. 

(127) Hong, D.; Lyu, L. M.; Koga, K.; Shimoyama, Y.; Kon, Y. Plasmonic Ag@TiO2 Core-Shell Nanoparticles for Enhanced CO2 Photoconversion to CH4. ACS Sustainable Chem. Eng. 2019, 7, 18955−18964. 

809 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

(128) Zhou, C.; Wang, S.; Zhao, Z.; Shi, Z.; Yan, S.; Zou, Z. A FacetDependent Schottky-Junction Electron Shuttle in a BiVO4010−Au− Cu2O Z-Scheme Photocatalyst for Efficient Charge Separation. Adv. Funct. Mater. 2018, 28, 1801214. 

(129) Wang, K.; Lu, J.; Lu, Y.; Lau, C. H.; Zheng, Y.; Fan, X. Unravelling the C−C Coupling in CO2 Photocatalytic Reduction with H2O on Au/TiO2-x: Combination of Plasmonic Excitation and Oxygen Vacancy. Applied Catalysis B: Environmental 2021, 292, 120147. 

(130) Qin, L.; Wang, G.; Tan, Y. Plasmonic Pt nanoparticles TiO2 hierarchical nano-architecture as a visible light photocatalyst for water splitting. Sci. Rep. 2018, 8, 16198. 

(131) Negrín-Montecelo, Y.; Comesaña-Hermo, M.; Khorashad, L. K.; Sousa-Castillo, A.; Wang, Z.; Pérez-Lorenzo, M.; Liedl, T.; Govorov, A. O.; Correa-Duarte, M. A. Photophysical Effects behind the Efficiency of Hot Electron Injection in Plasmon-Assisted Catalysis: The Joint Role of Morphology and Composition. ACS Energy Letters 2020, 5, 395−402. 

(132) Yang, J. L.; He, Y. L.; Ren, H.; Zhong, H. L.; Lin, J. S.; Yang, W. M.; Li, M. D.; Yang, Z. L.; Zhang, H.; Tian, Z. Q.; Li, J. F. Boosting photocatalytic hydrogen evolution reaction using dual plasmonic antennas. ACS Catal. 2021, 11, 5047−5053. 

(133) Ren, H.; Yang, J. L.; Yang, W. M.; Zhong, H. L.; Lin, J. S.; Radjenovic, P. M.; Sun, L.; Zhang, H.; Xu, J.; Tian, Z. Q.; Li, J. F. Core-Shell-Satellite Plasmonic Photocatalyst for Broad-Spectrum Photocatalytic Water Splitting. ACS Materials Letters 2021, 3, 69−76. (134) Zhang, X.; Luo, L.; Yun, R.; Pu, M.; Zhang, B.; Xiang, X. Increasing the Activity and Selectivity of TiO2-Supported Au Catalysts for Renewable Hydrogen Generation from Ethanol Photoreforming by Engineering Ti<sup>3+</sup> Defects. ACS Sustainable Chem. Eng. 2019, 7, 13856−13864. 

(135) Liu, J.; et al. Metal@semiconductor core-shell nanocrystals with atomically organized interfaces for efficient hot electronmediated photocatalysis. Nano Energy 2018, 48, 44−52. 

(136) Yu, G.; Qian, J.; Zhang, P.; Zhang, B.; Zhang, W.; Yan, W.; Liu, G. Collective excitation of plasmon-coupled Au-nanochain boosts photocatalytic hydrogen evolution of semiconductor. Nat. Commun. 2019, 10, 4912. 

(137) Yang, X.; Wu, X.; Li, J.; Liu, Y. TiO2-Au composite nanofibers for photocatalytic hydrogen evolution. RSC Adv. 2019, 9, 29097− 29104. 

(138) Zhao, M.; Xu, H.; Ouyang, S.; Tong, H.; Chen, H.; Li, Y.; Song, L.; Ye, J. Fabricating a Au@TiO2 Plasmonic System to Elucidate Alkali-Induced Enhancement of Photocatalytic H2 Evolution: Surface Potential Shift or Methanol Oxidation Acceleration? ACS Catal. 2018, 8, 4266−4277. 

(139) Varapragasam, S. J.; Mia, S.; Wieting, C.; Balasanthiran, C.; Hossan, M. Y.; Baride, A.; Rioux, R. M.; Hoefelmeyer, J. D. Ag-TiO2 Hybrid Nanocrystal Photocatalyst: Hydrogen Evolution under UV Irradiation but Not under Visible-Light Irradiation. ACS Applied Energy Materials 2019, 2, 8274−8282. 

(140) Zhu, M.; Wang, Y. Y.; Deng, Y. H.; Peng, X.; Wang, X.; Yuan, H.; Yang, Z. J.; Wang, Y. Y.; Wang, H. Strategic modulation of energy transfer in Au-TiO2-Pt nanodumbbells: Plasmon-enhanced hydrogen evolution reaction. Nanoscale 2020, 12, 7035−7044. 

(141) Atta, S.; Pennington, A. M.; Celik, F. E.; Fabris, L. TiO2 on Gold Nanostars Enhances Photocatalytic Water Reduction in the Near-Infrared Regime. Chem. 2018, 4, 2140−2153. 

(142) Naya, S. I.; Kume, T.; Akashi, R.; Fujishima, M.; Tada, H. Red-Light-Driven Water Splitting by Au(Core)-CdS(Shell) Half-Cut Nanoegg with Heteroepitaxial Junction. J. Am. Chem. Soc. 2018, 140, 1251−1254. 

(143) Liu, B.; Jiang, Y.; Wang, Y.; Shang, S.; Ni, Y.; Zhang, N.; Cao, M.; Hu, C. Influence of dimensionality and crystallization on visiblelight hydrogen production of Au@TiO2 core-shell photocatalysts based on localized surface plasmon resonance. Catalysis Science and Technology 2018, 8, 1094−1103. 

(144) Gesesse, G. D.; Wang, C.; Chang, B. K.; Tai, S. H.; Beaunier, P.; Wojcieszak, R.; Remita, H.; Colbeau-Justin, C.; Ghazzal, M. N. A 

soft-chemistry assisted strong metal-support interaction on a designed plasmonic core-shell photocatalyst for enhanced photocatalytic hydrogen production. Nanoscale 2020, 12, 7011−7023. 

(145) Shi, X.; Lou, Z.; Zhang, P.; Fujitsuka, M.; Majima, T. 3D-array of Au-TiO2 yolk-shell as plasmonic photocatalyst boosting multiscattering with enhanced hydrogen evolution. ACS Appl. Mater. Interfaces 2016, 8, 31738−31745. 

(146) Wu, B.; Liu, D.; Mubeen, S.; Chuong, T. T.; Moskovits, M.; Stucky, G. D. Anisotropic Growth of TiO2 onto Gold Nanorods for Plasmon-Enhanced Hydrogen Production from Water Reduction. J. Am. Chem. Soc. 2016, 138, 1114−1117. 

(147) Javaid, S.; Li, X.; Wang, F.; Chen, W.; Pang, Y.; Wang, S.; Jia, G.; Jones, F. Synthesis of magnetically separable Fe3O4-Au-CdS kinked heterotrimers incorporating plasmonic and semiconducting functionalities. Journal of Materials Chemistry C 2019, 7, 14517− 14524. 

(148) Choi, Y.; Kim, H. I.; Moon, G. H.; Jo, S.; Choi, W. Boosting up the Low Catalytic Activity of Silver for H2 Production on Ag/TiO2 Photocatalyst: Thiocyanate as a Selective Modifier. ACS Catal. 2016, 6, 821−828. 

(149) Pang, F.; Zhang, R.; Lan, D.; Ge, J. Synthesis of MagnetiteSemiconductor-Metal Trimer Nanoparticles through Functional Modular Assembly: A Magnetically Separable Photocatalyst with Photothermic Enhancement for Water Reduction. ACS Appl. Mater. Interfaces 2018, 10, 4929−4936. 

(150) Ning, X.; Lu, G. Photocorrosion inhibition of CdS-based catalysts for photocatalytic overall water splitting. Nanoscale 2020, 12, 1213−1223. 

(151) Mirzaeifard, Z.; Shariatinia, Z.; Jourshabani, M.; Rezaei Darvishi, S. M. ZnO Photocatalyst Revisited: Effective Photocatalytic Degradation of Emerging Contaminants Using S-Doped ZnO Nanoparticles under Visible Light Radiation. Ind. Eng. Chem. Res. 2020, 59, 15894−15911. 

(152) Siavash Moakhar, R.; Gholipour, S.; Masudy-Panah, S.; Seza, A.; Mehdikhani, A.; Riahi-Noori, N.; Tafazoli, S.; Timasi, N.; Lim, Y.F.; Saliba, M. Recent Advances in Plasmonic Perovskite Solar Cells. Advanced Science 2020, 7, 1902448. 

(153) Arinze, E. S.; Qiu, B.; Nyirjesy, G.; Thon, S. M. Plasmonic Nanoparticle Enhancement of Solution-Processed Solar Cells: Practical Limits and Opportunities. ACS Photonics 2016, 3, 158−173. (154) Fan, W.; Leung, M. Recent development of plasmonic resonance-based photocatalysis and photovoltaics for solar utilization. Molecules 2016, 21, 180. 

(155) Liao, J. F.; Cai, Y. T.; Li, J. Y.; Jiang, Y.; Wang, X. D.; Chen, H. Y.; Kuang, D. B. Plasmonic CsPbBr3−Au nanocomposite for excitation wavelength dependent photocatalytic CO2 reduction. Journal of Energy Chemistry 2021, 53, 309−315. 

(156) Cai, X.; Zhu, M.; Elbanna, O. A.; Fujitsuka, M.; Kim, S.; Mao, L.; Zhang, J.; Majima, T. Au Nanorod Photosensitized La2Ti2O7 Nanosteps: Successive Surface Heterojunctions Boosting Visible to Near-Infrared Photocatalytic H2 Evolution. ACS Catal. 2018, 8, 122− 131. 

(157) Wan, S.; Chen, M.; Ou, M.; Zhong, Q. Plasmonic Ag nanoparticles decorated SrTiO3 nanocubes for enhanced photocatalytic CO2 reduction and H2 evolution under visible light irradiation. Journal of CO2 Utilization 2019, 33, 357−364. 

(158) Xu, D.; Yang, S.; Jin, Y.; Chen, M.; Fan, W.; Luo, B.; Shi, W. Ag-Decorated ATaO3 (A = K, Na) Nanocube Plasmonic Photocatalysts with Enhanced Photocatalytic Water-Splitting Properties. Langmuir 2015, 31, 9694−9699. 

(159) Zhang, B.-T.; Liu, J.; Yue, S.; Teng, Y.; Wang, Z.; Li, X.; Qu, S.; Wang, Z. Hot electron injection: An efficacious approach to charge LaCoO3 for improving the water splitting efficiency. Applied Catalysis B: Environmental 2017, 219, 432−438. 

(160) Guo, L.; Zhong, C.; Cao, J.; Hao, Y.; Lei, M.; Bi, K.; Sun, Q.; Wang, Z. L. Enhanced photocatalytic H2 evolution by plasmonic and piezotronic effects based on periodic Al/BaTiO3 heterostructures. Nano Energy 2019, 62, 513−520. 

810 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

(161) Yu, J.; Zhang, L.; Qian, J.; Zhu, Z.; Ni, S.; Liu, G.; Xu, X. In situ exsolution of silver nanoparticles on AgTaO3-SrTiO3 solid solutions as efficient plasmonic photocatalysts for water splitting. Applied Catalysis B: Environmental 2019, 256, 117818. 

(162) Zhu, M.; Cai, X.; Fujitsuka, M.; Zhang, J.; Majima, T. Au/ La2Ti2O7 Nanostructures Sensitized with Black Phosphorus for Plasmon-Enhanced Photocatalytic Hydrogen Production in Visible and Near-Infrared Light. Angewandte Chemie - International Edition 2017, 56, 2064−2068. 

(163) Han, S.; Yu, L.; Zhang, H.; Chu, Z.; Chen, X.; Xi, H.; Long, J. Gold Plasmon-Enhanced Solar Hydrogen Production over SrTiO3/ TiO2 Heterostructures. ChemCatChem. 2019, 11, 6203−6207. 

(164) Zhong, Y.; Ueno, K.; Mori, Y.; Shi, X.; Oshikiri, T.; Murakoshi, K.; Inoue, H.; Misawa, H. Plasmon-Assisted Water Splitting Using Two Sides of the Same SrTiO3 Single-Crystal Substrate: Conversion of Visible Light to Chemical Energy. Angew. Chem., Int. Ed. 2014, 53, 10350−10354. 

(165) Li, Z.; Zhang, Q.; Li, J. G.; Sun, H.; Yuen, M. F.; Jiang, S.; Tian, Y.; Hong, G.; Wang, C.; Liu, M. Promoting photocatalytic h y d r o g e n e v o l u t i o n o v e r t h e p e r o v s k i t e o x i d e Pr0.5(Ba0.5Sr0.5)0.5Co0.8Fe0.2O3by plasmon-induced hot electron injection. Nanoscale 2020, 12, 18710−18720. 

(166) Xu, X.; Liu, G.; Azad, A. K. Visible light photocatalysis by in situ growth of plasmonic Ag nanoparticles upon AgTaO3. Int. J. Hydrogen Energy 2015, 40, 3672−3678. 

(167) Tang, R.; Sun, H.; Zhang, Z.; Liu, L.; Meng, F.; Zhang, X.; Yang, W.; Li, Z.; Zhao, Z.; Zheng, R.; Huang, J. Incorporating plasmonic Au-nanoparticles into three-dimensionally ordered macroporous perovskite frameworks for efficient photocatalytic CO2 reduction. Chemical Engineering Journal 2022, 429, 132137. 

(168) Wang, F.; Wang, T.; Lang, J.; Su, Y.; Wang, X. Improved photocatalytic activity and durability of AgTaO3/AgBr heterojunction: The relevance of phase and electronic structure. J. Mol. Catal. A: Chem. 2017, 426, 52−59. 

(169) Yan, Y.; Yang, H.; Yi, Z.; Li, R.; Wang, X. Enhanced photocatalytic performance and mechanism of Au@CaTiO3 composites with au nanoparticles assembled on CaTiO3 nanocuboids. Micromachines 2019, 10, 254. 

(170) Wang, H.; Yuan, X.; Wu, Y.; Zeng, G.; Tu, W.; Sheng, C.; Deng, Y.; Chen, F.; Chew, J. W. Plasmonic Bi nanoparticles and BiOCl sheets as cocatalyst deposited on perovskite-type ZnSn(OH)6 microparticle with facet-oriented polyhedron for improved visiblelight-driven photocatalysis. Applied Catalysis B: Environmental 2017, 209, 543−553. 

(171) Lu, D.; Ouyang, S.; Xu, H.; Li, D.; Zhang, X.; Li, Y.; Ye, J. Designing Au Surface-Modified Nanoporous-Single-Crystalline SrTiO3 to Optimize Diffusion of Surface Plasmon Resonance-Induce Photoelectron toward Enhanced Visible-Light Photoactivity. ACS Appl. Mater. Interfaces 2016, 8, 9506−9513. 

(172) Fan, G.; Chen, Z.; Yan, Z.; Du, B.; Pang, H.; Tang, D.; Luo, J.; Lin, J. Efficient integration of plasmonic Ag/AgCl with perovskitetype LaFeO3: Enhanced visible-light photocatalytic activity for removal of harmful algae. Journal of Hazardous Materials 2021, 409, 125018. 

(173) Li, Y. F.; Kou, Z. L.; Feng, J.; Sun, H. B. Plasmon-enhanced organic and perovskite solar cells with metal nanoparticles. Nanophotonics 2020, 9, 3111−3133. 

(174) Hintermayr, V. A.; Lampe, C.; Löw, M.; Roemer, J.; Vanderlinden, W.; Gramlich, M.; Böhm, A. X.; Sattler, C.; Nickel, B.; Lohmüller, T.; Urban, A. S. Polymer Nanoreactors Shield Perovskite Nanocrystals from Degradation. Nano Lett. 2019, 19, 4928−4933. 

(175) Luo, J.; Zhang, W.; Yang, H.; Fan, Q.; Xiong, F.; Liu, S.; Li, D.; Liu, B. Halide perovskite composites for photocatalysis: A mini review. EcoMat 2021, 3, No. e12079. 

(176) Li, Z.; Huang, W.; Liu, J.; Lv, K.; Li, Q. Embedding CdS@Au into ultrathin Ti3−XC2TY to build dual Schottky Barriers for photocatalytic H2 production. ACS Catal. 2021, 11, 8510−8520. 

(177) Voiry, D.; Shin, H. S.; Loh, K. P.; Chhowalla, M. Lowdimensional catalysts for hydrogen evolution and CO2 reduction. Nature Reviews Chemistry 2018, No. 2, 0105. 

(178) Fu, J.; Wang, S.; Wang, Z.; Liu, K.; Li, H.; Liu, H.; Hu, J.; Xu, X.; Li, H.; Liu, M. Graphitic carbon nitride based single-atom photocatalysts. Frontiers of Physics 2020, 15, 33201. 

(179) Jiang, K.; Zhu, L.; Wang, Z.; Liu, K.; Li, H.; Hu, J.; Pan, H.; Fu, J.; Zhang, N.; Qiu, X.; Liu, M. Plasma-treatment induced H2O dissociation for the enhancement of photocatalytic CO2 reduction to CH4 over graphitic carbon nitride. Appl. Surf. Sci. 2020, 508, 145173. (180) Lou, Z.; Fujitsuka, M.; Majima, T. Two-Dimensional AuNanoprism/Reduced Graphene Oxide/Pt-Nanoframe as Plasmonic Photocatalysts with Multiplasmon Modes Boosting Hot Electron Transfer for Hydrogen Generation. J. Phys. Chem. Lett. 2017, 8, 844− 849. 

(181) Zhang, P.; Fujitsuka, M.; Majima, T. Hot electron-driven hydrogen evolution using anisotropic gold nanostructure assembled monolayer MoS2. Nanoscale 2017, 9, 1520−1526. 

(182) Guo, Y.; Jia, H.; Yang, J.; Yin, H.; Yang, Z.; Wang, J.; Yang, B. Understanding the roles of plasmonic Au nanocrystal size, shape, aspect ratio and loading amount in Au/g-C3N4 hybrid nanostructures for photocatalytic hydrogen generation. Phys. Chem. Chem. Phys. 2018, 20, 22296−22307. 

(183) Li, J.; Ye, Y.; Ye, L.; Su, F.; Ma, Z.; Huang, J.; Xie, H.; Doronkin, D. E.; Zimina, A.; Grunwaldt, J. D.; Zhou, Y. Sunlight induced photo-thermal synergistic catalytic CO2 conversion: Via localized surface plasmon resonance of MoO3−X. Journal of Materials Chemistry A 2019, 7, 2821−2830. 

(184) Zhou, R.; Yin, Y.; Long, D.; Cui, J.; Yan, H.; Liu, W.; Pan, J. H. PVP-assisted laser ablation growth of Ag nanocubes anchored on reduced graphene oxide (rGO) for efficient photocatalytic CO2 reduction. Progress in Natural Science: Materials International 2019, 29, 660−666. 

(185) Li, X.; Liu, C.; Wu, D.; Li, J. Z.; Huo, P.; Wang, H. Improved charge transfer by size-dependent plasmonic Au on C3N4 for efficient photocatalytic oxidation of RhB and CO2 reduction. Chinese Journal of Catalysis 2019, 40, 928−939. 

(186) Xu, X.; Luo, F.; Tang, W.; Hu, J.; Zeng, H.; Zhou, Y. Enriching Hot Electrons via NIR-Photon-Excited Plasmon in WS2@ Cu Hybrids for Full-Spectrum Solar Hydrogen Evolution. Adv. Funct. Mater. 2018, 28, 1804055. 

(187) Wan, C.; Zhou, L.; Sun, L.; Xu, L.; Cheng, D.-g.; Chen, F.; Zhan, X.; Yang, Y. Boosting visible-light-driven hydrogen evolution from formic acid over AgPd/2D g-C3N4 nanosheets Mott-Schottky photocatalyst. Chemical Engineering Journal 2020, 396, 125229. 

(188) Yin, H.; Kuwahara, Y.; Mori, K.; Yamashita, H. Plasmonic metal/MoXW1−XO3−Y for visible-light-enhanced H2 production from ammonia borane. Journal of Materials Chemistry A 2018, 6, 10932− 10938. 

(189) Cai, X.; Mao, L.; Yang, S.; Han, K.; Zhang, J. Ultrafast Charge Separation for Full Solar Spectrum-Activated Photocatalytic H2 Generation in a Black Phosphorus-Au-CdS Heterostructure. ACS Energy Letters 2018, 3, 932−939. 

(190) An, H.; Lv, Z.; Zhang, K.; Deng, C.; Wang, H.; Xu, Z.; Wang, M.; Yin, Z. Plasmonic coupling enhancement of core-shell Au@Pt assemblies on ZnIn2S4 nanosheets towards photocatalytic H2 production. Appl. Surf. Sci. 2021, 536, 147934. 

(191) Ma, L.; Yang, D. J.; Song, X. P.; Li, H. X.; Ding, S. J.; Xiong, L.; Qin, P. L.; Chen, X. B. Pt Decorated (Au Nanosphere)/(CuSe Ultrathin Nanoplate) Tangential Hybrids for Efficient Photocatalytic Hydrogen Generation via Dual-Plasmon-Induced Strong VIS−NIR Light Absorption and Interfacial Electric Field Coupling. Solar RRL 2020, 4, 1900376. 

(192) Zhang, J.; Wang, P.; Sun, J.; Jin, Y. High-Efficiency PlasmonEnhanced and Graphene-Supported Semiconductor/Metal CoreSatellite Hetero-Nanocrystal Photocatalysts for Visible-Light Dye Photodegradation and H2 Production from Water. ACS Appl. Mater. Interfaces 2014, 6, 19905−19913. 

811 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

(193) Tudu, B.; Nalajala, N.; Reddy, K. P.; Saikia, P.; Gopinath, C. S. Electronic Integration and Thin Film Aspects of Au-Pd/rGO/TiO2 for Improved Solar Hydrogen Generation. ACS Appl. Mater. Interfaces 2019, 11, 32869−32878. 

(194) Sultana, S.; Mansingh, S.; Scurrell, M.; Parida, K. M. Controlled Synthesis of CeO2NS-Au-CdSQDs Ternary Nanoheterostructure: A Promising Visible Light Responsive Photocatalyst for H2 Evolution. Inorg. Chem. 2017, 56, 12297−12307. 

(195) Lv, J.; Zhang, J.; Liu, J.; Li, Z.; Dai, K.; Liang, C. Bi SPRPromoted Z-Scheme Bi2MoO6/CdS-Diethylenetriamine Composite with Effectively Enhanced Visible Light Photocatalytic Hydrogen Evolution Activity and Stability. ACS Sustainable Chem. Eng. 2018, 6, 696−706. 

(196) Zhang, Q.; Zhang, Y.; Xiao, K.; Meng, Z.; Tong, W.; Huang, H.; An, Q. Plasmonic gold particle generation in layer-by-layer 2D titania films as an effective immobilization strategy of composite photocatalytsts for hydrogen generation. Chemical Engineering Journal 2019, 358, 389−397. 

(197) Hassanzadeh-Tabrizi, S. A.; Nguyen, C. C.; Do, T. O. Synthesis of Fe2O3/Pt/Au nanocomposite immobilized on g-C3N4 for localized plasmon photocatalytic hydrogen evolution. Appl. Surf. Sci. 2019, 489, 741−754. 

(198) Cheng, L.; Zhang, D.; Liao, Y.; Li, F.; Zhang, H.; Xiang, Q. Constructing functionalized plasmonic gold/titanium dioxide nanosheets with small gold nanoparticles for efficient photocatalytic hydrogen evolution. J. Colloid Interface Sci. 2019, 555, 94−103. 

(199) Huang, T.; Xu, Z.; Zeng, G.; Zhang, P.; Song, T.; Wang, Y.; Wang, T.; Huang, S.; Wang, T.; Zeng, H. Selective deposition of plasmonic copper on few layers graphene with specific defects for efficiently synchronous photocatalytic hydrogen production. Carbon 2019, 143, 257−267. 

(200) Xiao, N.; Li, Y.; Li, S.; Li, X.; Gao, Y.; Ge, L.; Lu, G. In-situ synthesis of PdAg/g-C3N4 composite photocatalyst for highly efficient photocatalytic H2 generation under visible light irradiation. Int. J. Hydrogen Energy 2019, 44, 19929−19941. 

(201) Zhang, Q.; Yang, S.; Yin, S. N.; Xue, H. Over two-orders of magnitude enhancement of the photocatalytic hydrogen evolution activity of carbon nitride: Via mediator-free decoration with goldorganic microspheres. Chem. Commun. 2017, 53, 11814−11817. 

(202) Zhao, W.-Q.; Zou, J.-W.; Qu, S.-Z.; Qin, P.-L.; Chen, X.-B.; Ding, S.-J.; Ma, L.; Wang, Q.-Q. Plasmon-Mediated 2D/2D Phase Junction for Improved Photocatalytic Hydrogen Generation Activity. ACS Appl. Mater. Interfaces 2021, 13, 44440−44450. 

(203) Han, C.; Gao, Y.; Liu, S.; Ge, L.; Xiao, N.; Dai, D.; Xu, B.; Chen, C. Facile synthesis of AuPd/g-C3N4 nanocomposite: An effective strategy to enhance photocatalytic hydrogen evolution activity. Int. J. Hydrogen Energy 2017, 42, 22765−22775. 

(204) Tang, Y.; Huang, J.; Jiang, M.; Yu, J.; Wang, Q.; Zhao, J.; Li, J.; Yu, X.; Zhao, J. Photo-induced synthesis of nanostructured Pt-on-Au/ g-C3N4 composites for visible light photocatalytic hydrogen production. J. Mater. Sci. 2020, 55, 15574−15587. 

(205) Xu, Z.; Kibria, M. G.; AlOtaibi, B.; Duchesne, P. N.; Besteiro, L. V.; Gao, Y.; Zhang, Q.; Mi, Z.; Zhang, P.; Govorov, A. O.; Mai, L.; Chaker, M.; Ma, D. Towards enhancing photocatalytic hydrogen generation: Which is more important, alloy synergistic effect or plasmonic effect? Applied Catalysis B: Environmental 2018, 221, 77− 85. 

(206) Nguyen, C. C.; Sakar, M.; Vu, M. H.; Do, T. O. Nitrogen Vacancies-Assisted Enhanced Plasmonic Photoactivities of Au/gC3N4 Crumpled Nanolayers: A Novel Pathway toward Efficient Solar Light-Driven Photocatalysts. Ind. Eng. Chem. Res. 2019, 58, 3698− 3706. 

(207) Majeed, I.; Manzoor, U.; Kanodarwala, F. K.; Nadeem, M. A.; Nadeem, M. A.; Hussain, E.; Ali, H.; Badshah, A.; Stride, J. A. Pd-Ag decorated g-C3N4 as an efficient photocatalyst for hydrogen production from water under direct solar light irradiation. Catalysis Science and Technology 2018, 8, 1183−1193. 

(208) Yang, Y.; Lu, C.; Ren, J.; Li, X.; Ma, Y.; Huang, W.; Zhao, X. Enhanced photocatalytic hydrogen evolution over TiO2/g-C3N4 2D 

heterojunction coupled with plasmon Ag nanoparticles. Ceram. Int. 2020, 46, 5725−5732. 

(209) Zhao, W.; Li, Y.; Zhao, P.; Zhang, L.; Dai, B.; Xu, J.; Huang, H.; He, Y.; Leung, D. Y. Novel Z-scheme Ag-C3N4/SnS2 plasmonic heterojunction photocatalyst for degradation of tetracycline and H2 production. Chemical Engineering Journal 2021, 405, 126555. 

(210) Liu, W.; Liang, B.; Ma, Y.; Liu, Y.; Zhu, A.; Tan, P.; Xiong, X.; Pan, J. Well-organized migration of electrons for enhanced hydrogen evolution: Integration of 2D MoS2 nanosheets with plasmonic photocatalyst by a facile ultrasonic chemical method. J. Colloid Interface Sci. 2017, 508, 559−566. 

(211) Bhunia, K.; Chandra, M.; Khilari, S.; Pradhan, D. Bimetallic PtAu Alloy Nanoparticles-Integrated g-C3N4 Hybrid as an Efficient Photocatalyst for Water-to-Hydrogen Conversion. ACS Appl. Mater. Interfaces 2019, 11, 478−488. 

(212) Mo, Z.; Xu, H.; She, X.; Song, Y.; Yan, P.; Yi, J.; Zhu, X.; Lei, Y.; Yuan, S.; Li, H. Constructing Pd/2D-C3N4 composites for efficient photocatalytic H2 evolution through nonplasmon-induced bound electrons. Appl. Surf. Sci. 2019, 467−468, 151−157. 

(213) She, X.; Wu, J.; Xu, H.; Mo, Z.; Lian, J.; Song, Y.; Liu, L.; Du, D.; Li, H. Enhancing charge density and steering charge unidirectional flow in 2D non-metallic semiconductor-CNTs-metal coupled photocatalyst for solar energy conversion. Applied Catalysis B: Environmental 2017, 202, 112−117. 

(214) Mo, Z.; Xu, H.; Chen, Z.; She, X.; Song, Y.; Yan, P.; Xu, Y.; Lei, Y.; Yuan, S.; Li, H. Gold/monolayer graphitic carbon nitride plasmonic photocatalyst for ultrafast electron transfer in solar-tohydrogen energy conversion. Cuihua Xuebao/Chinese Journal of Catalysis 2018, 39, 760−770. 

(215) Guo, X.; Li, X.; Kou, S.; Yang, X.; Hu, X.; Ling, D.; Yang, J. Plasmon-enhanced electrocatalytic hydrogen/oxygen evolution by Pt/ Fe-Au nanorods. Journal of Materials Chemistry A 2018, 6, 7364− 7369. 

(216) Humayun, M.; Fu, Q.; Zheng, Z.; Li, H.; Luo, W. Improved visible-light catalytic activities of novel Au/P-doped g-C3N4 photocatalyst for solar fuel production and mechanism. Applied Catalysis A: General 2018, 568, 139−147. 

(217) Hu, J.; You, N.; Yu, Z.; Zhou, G.; Xu, X. Two-dimensional ZnO ultrathin nanosheets decorated with Au nanoparticles for effective photocatalysis. J. Appl. Phys. 2016, 120, No. 074301. 

(218) Yi, J.; She, X.; Song, Y.; Xu, H.; Zhang, P.; Mo, Z.; Liu, L.; Du, D.; Li, H. A silver on 2D white-C3N4 support photocatalyst for mechanistic insights: synergetic utilization of plasmonic effect for solar hydrogen evolution. RSC Adv. 2016, 6, 112420−112428. 

(219) Xie, L.; Ai, Z.; Zhang, M.; Sun, R.; Zhao, W. Enhanced hydrogen evolution in the presence of plasmonic Au-photo-sensitized g-C3N4 with an extended absorption spectrum from 460 to 640 nm. PLoS One 2016, 11, e0161397. 

(220) Dang, H.; Tan, G.; Yang, W.; Su, F.; Fan, H.; Dong, X.; Ye, L. Enhanced visible-light photocatalytic H2 production of graphitic carbon nitride nanosheets by dye-sensitization combined with surface plasmon resonance. Journal of the Taiwan Institute of Chemical Engineers 2017, 78, 185−194. 

(221) Lu, D.; Wang, H.; Zhao, X.; Kondamareddy, K. K.; Ding, J.; Li, C.; Fang, P. Highly efficient visible-light-induced photoactivity of Z-scheme g-C3N4/Ag/MoS2 ternary photocatalysts for organic pollutant degradation and production of hydrogen. ACS Sustainable Chem. Eng. 2017, 5, 1436−1445. 

(222) He, Y. Q.; Zhang, F.; Ma, B.; Xu, N.; Binnah Junior, L.; Yao, B.; Yang, Q.; Liu, D.; Ma, Z. Remarkably enhanced visible-light photocatalytic hydrogen evolution and antibiotic degradation over g- C3N4 nanosheets decorated by using nickel phosphide and gold nanoparticles as cocatalysts. Appl. Surf. Sci. 2020, 517, 146187. 

(223) Chava, R. K.; Do, J. Y.; Kang, M. Strategy for improving the visible photocatalytic H2 evolution activity of 2D graphitic carbon nitride nanosheets through the modification with metal and metal oxide nanocomponents. Applied Catalysis B: Environmental 2019, 248, 538−551. 

812 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

(224) Hao, J.; He, H.; Gong, S.; Fan, J.; Xu, Q.; Min, Y. L. WN Coupled with Bi Nanoparticles to Enhance the Localized Surface Plasmon Resonance Effect for Photocatalytic Hydrogen Evolution. ACS Appl. Mater. Interfaces 2021, 13, 19884−19893. 

(225) Liu, P.; Gu, X.; Zhang, H.; Cheng, J.; Song, J.; Su, H. Visiblelight-driven catalytic activity enhancement of Pd in AuPd nanoparticles for hydrogen evolution from formic acid at room temperature. Applied Catalysis B: Environmental 2017, 204, 497−504. 

(226) Ding, D.; Liu, K.; He, S.; Gao, C.; Yin, Y. Ligand-exchange assisted formation of Au/TiO2 Schottky contact for visible-light photocatalysis. Nano Lett. 2014, 14, 6731−6736. 

(227) Wang, Z.; Lee, H.; Chen, J.; Wu, M.; Leung, D. Y.; Grimes, C. A.; Lu, Z.; Xu, Z.; Feng, S. P. Synergistic effects of Pd−Ag bimetals and g-C3N4 photocatalysts for selective and efficient conversion of gaseous CO2. J. Power Sources 2020, 466, 228306. 

(228) Cheng, W.; Su, H.; Tang, F.; Che, W.; Huang, Y.; Zheng, X.; Yao, T.; Liu, J.; Hu, F.; Jiang, Y.; Liu, Q.; Wei, S. Synergetic enhancement of plasmonic hot-electron injection in Au clusternanoparticle/C3N4 for photocatalytic hydrogen evolution. Journal of Materials Chemistry A 2017, 5, 19649−19655. 

(229) Han, C.; Wu, L.; Ge, L.; Li, Y.; Zhao, Z. AuPd bimetallic nanoparticles decorated graphitic carbon nitride for highly efficient reduction of water to H2 under visible light irradiation. Carbon 2015, 92, 31−40. 

(230) Zhang, G.; Zhu, X.; Chen, D.; Li, N.; Xu, Q.; Li, H.; He, J.; Xu, H.; Lu, J. Hierarchical: Z-scheme g-C3N4/Au/ZnIn2S4 photocatalyst for highly enhanced visible-light photocatalytic nitric oxide removal and carbon dioxide conversion. Environmental Science: Nano 2020, 7, 676−687. 

(231) Li, F.; Zhou, H.; Fan, J.; Xiang, Q. Amine-functionalized graphitic carbon nitride decorated with small-sized Au nanoparticles for photocatalytic CO2 reduction. J. Colloid Interface Sci. 2020, 570, 11−19. 

(232) Li, H.; Gao, Y.; Xiong, Z.; Liao, C.; Shih, K. Enhanced selective photocatalytic reduction of CO2 to CH4 over plasmonic Au modified g-C3N4 photocatalyst under UV−vis light irradiation. Appl. Surf. Sci. 2018, 439, 552−559. 

(233) Tan, D.; Zhang, J.; Shi, J.; Li, S.; Zhang, B.; Tan, X.; Zhang, F.; Liu, L.; Shao, D.; Han, B. Photocatalytic CO2 Transformation to CH4 by Ag/Pd Bimetals Supported on N-Doped TiO2 Nanosheet. ACS Appl. Mater. Interfaces 2018, 10, 24516−24522. 

(234) Wang, R.; Shen, J.; Sun, K.; Tang, H.; Liu, Q. Enhancement in photocatalytic activity of CO2 reduction to CH4 by 0D/2D Au/TiO2 plasmon heterojunction. Appl. Surf. Sci. 2019, 493, 1142−1149. 

(235) Yang, L.; Chen, W.; Yu, Q.; Liu, B. Mass production of twodimensional materials beyond graphene and their applications. Nano Research 2021, 14, 1583−1597. 

(236) Li, Y. F. Hydrogen Bronzes of WO3 and MoO3 as Active (Photo-) Catalyst Supports for CO2 Reduction. Ph.D. thesis, University of Toronto, 2020. 

(237) Wang, Y.; Zhang, Y.; Jiang, Z.; Jiang, G.; Zhao, Z.; Wu, Q.; Liu, Y.; Xu, Q.; Duan, A.; Xu, C. Controlled fabrication and enhanced visible-light photocatalytic hydrogen production of Au@CdS/MIL101 heterostructure. Applied Catalysis B: Environmental 2016, 185, 307−314. 

(238) Tilgner, D.; Kempe, R. A Plasmonic Colloidal Photocatalyst Composed of a Metal−Organic Framework Core and a Gold/Anatase Shell for Visible-Light-Driven Wastewater Purification from Antibiotics and Hydrogen Evolution. Chem. - Eur. J. 2017, 23, 3184−3190. 

(239) Li, D.; Yu, S.-H. H.; Jiang, H.-L. L. From UV to Near-Infrared Light-Responsive Metal−Organic Framework Composites: Plasmon and Upconversion Enhanced Photocatalysis. Adv. Mater. 2018, 30, 1707377. 

(240) Chen, L.; Wang, Y.; Yu, F.; Shen, X.; Duan, C. A simple strategy for engineering heterostructures of Au nanoparticle-loaded metal-organic framework nanosheets to achieve plasmon-enhanced photocatalytic CO2 conversion under visible light. Journal of Materials Chemistry A 2019, 7, 11355−11361. 

(241) Guo, F.; Yang, S.; Liu, Y.; Wang, P.; Huang, J.; Sun, W.-Y. Size Engineering of Metal−Organic Framework MIL-101(Cr)−Ag Hybrids for Photocatalytic CO2 Reduction. ACS Catal. 2019, 9, 8464− 8470. 

(242) Han, Y.; Xu, H.; Su, Y.; Xu, Z.-l.; Wang, K.; Wang, W. Noble metal (Pt, Au@Pd) nanoparticles supported on metal organic framework (MOF-74) nanoshuttles as high-selectivity CO2 conversion catalysts. J. Catal. 2019, 370, 70−78. 

(243) Chen, M.; Han, L.; Zhou, J.; Sun, C.; Hu, C.; Wang, X.; Su, Z. Photoreduction of carbon dioxide under visible light by ultra-small Ag nanoparticles doped into Co-ZIF-9. Nanotechnology 2018, 29, 284003. (244) Meng, Y.; Zhang, L.; Jiu, H.; Zhang, Q.; Zhang, H.; Ren, W.; Sun, Y.; Li, D. Construction of g-C3N4/ZIF-67 photocatalyst with enhanced photocatalytic CO2 reduction activity. Materials Science in Semiconductor Processing 2019, 95, 35−41. 

(245) Li, R.; Zhang, W.; Zhou, K. Metal−Organic-Framework-Based Catalysts for Photoreduction of CO2. Adv. Mater. 2018, 30, 1705512. (246) Kong, Z.-C.; Liao, J.-F.; Dong, Y.-J.; Xu, Y.-F.; Chen, H.-Y.; Kuang, D.-B.; Su, C.-Y. Core@Shell CsPbBr3@Zeolitic Imidazolate Framework Nanocomposite for Efficient Photocatalytic CO2 Reduction. ACS Energy Letters 2018, 3, 2656−2662. 

(247) Wei, Y.; Zhang, X.; Liu, Z.; Chen, H. S.; Yang, P. Site-selective modification of AgPt on multibranched Au nanostars for plasmonenhanced hydrogen evolution and methanol oxidation reaction in visible to near-infrared region. J. Power Sources 2019, 425, 17−26. 

(248) Moon, C. W.; Choi, M.-J.; Hyun, J.; Jang, H. W. Enhancing Photoelectrochemical Water Splitting with Plasmonic Au Nanoparticles. Nanoscale Advances 2021, 3, 5981−6006. 

(249) Wei, Y.; Zhang, X.; Liu, Y.; Jia, C.; Yang, P. Ternary PtNiCu self-assembled nanocubes for plasmon-enhanced electrocatalytic hydrogen evolution and methanol oxidation reaction in visible light. Electrochim. Acta 2020, 349, 136366. 

(250) Ge, Z.; Wang, C.; Qi, L. Controllable synthesis of hierarchical Au/PdAg heterostructures consisting of nanosheets on nanorods with plasmon-enhanced electrocatalytic properties. Inorganic Chemistry Frontiers 2020, 7, 4077−4085. 

(251) Wei, Y.; Zhao, Z.; Yang, P. Pd-Tipped Au Nanorods for Plasmon-Enhanced Electrocatalytic Hydrogen Evolution with Photoelectric and Photothermal Effects. ChemElectroChem. 2018, 5, 778− 784. 

(252) Wu, H.; Alshareef, H. N.; Zhu, T. Photo-assisted electrochemical hydrogen evolution by plasmonic Ag nanoparticle/nanorod heterogeneity. InfoMat 2019, 1, 417−425. 

(253) Zhao, Y.; Wang, H.; Zhao, W.; Zhao, X.; Xu, J. J.; Chen, H. Y. Dark-Field Imaging of Cation Exchange Synthesis of Cu2−XS@Au2S@ Au Nanoplates toward the Plasmonic Enhanced Hydrogen Evolution Reaction. ACS Appl. Mater. Interfaces 2021, 13, 6515−6521. 

(254) Liu, Y.; Song, T.; Gao, G.; Yang, P. PtPd-decorated Multibranched Au@Ag nanocrystal heterostructures for enhanced hydrogen evolution reaction performance in visible to near infrared light. ChemNanoMat 2021, 7, 1314−1321. 

(255) Lee, J.-E.; Marques Mota, F.; Choi, C. H.; Lu, Y.-R.; Boppella, R.; Dong, C.-L.; Liu, R.-S.; Kim, D. H. Plasmon-Enhanced Electrocatalytic Properties of Rationally Designed Hybrid Nanostructures at a Catalytic Interface. Advanced Materials Interfaces 2019, 6, 1801144. 

(256) Zhao, Z.; Wu, H.; Li, C. Engineering iron phosphide-onplasmonic Ag/Au-nanoshells as an efficient cathode catalyst in water splitting for hydrogen production. Energy 2021, 218, 119520. 

(257) Pang, L.; Barras, A.; Mishyn, V.; Sandu, G.; Melinte, S.; Subramanian, P.; Boukherroub, R.; Szunerits, S. Enhanced electrocatalytic hydrogen evolution on a plasmonic electrode: The importance of the Ti/TiO2 adhesion layer. Journal of Materials Chemistry A 2020, 8, 13980−13986. 

(258) Du, L.; Shi, G.; Zhao, Y.; Chen, X.; Sun, H.; Liu, F.; Cheng, F.; Xie, W. Plasmon-promoted electrocatalytic water splitting on metal-semiconductor nanocomposites: The interfacial charge transfer and the real catalytic sites. Chemical Science 2019, 10, 9605−9612. 

813 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

(259) Xiu, X. W.; Zhang, W. C.; Hou, S. T.; Li, Z.; Lei, F. C.; Xu, S. C.; Li, C. H.; Man, B. Y.; Yu, J.; Zhang, C. Role of graphene in improving catalytic behaviors of AuNPs/MoS2/Gr/Ni-F structure in hydrogen evolution reaction. Chinese Physics B 2021, 30, No. 088801. 

(260) Shang, B.; Cui, X.; Jiao, L.; Qi, K.; Wang, Y.; Fan, J.; Yue, Y.; Wang, H.; Bao, Q.; Fan, X.; Wei, S.; Song, W.; Cheng, Z.; Guo, S.; Zheng, W. Lattice -Mismatch-Induced Ultrastable 1T-Phase MoS2Pd/Au for Plasmon-Enhanced Hydrogen Evolution. Nano Lett. 2019, 19, 2758−2764. 

(261) Zhang, H. X.; Li, Y.; Li, M. Y.; Zhang, H.; Zhang, J. Boosting electrocatalytic hydrogen evolution by plasmon-driven hot-electron excitation. Nanoscale 2018, 10, 2236−2241. 

(262) Cui, J.; Jiang, R.; Lu, W.; Xu, S.; Wang, L. Plasmon-Enhanced Photoelectrical Hydrogen Evolution on Monolayer MoS2 Decorated Cu1.75S-Au Nanocrystals. Small 2017, 13, 1602235. 

(263) Shi, Y.; Wang, J.; Wang, C.; Zhai, T. T.; Bao, W. J.; Xu, J. J.; Xia, X. H.; Chen, H. Y. Hot Electron of Au Nanorods Activates the Electrocatalysis of Hydrogen Evolution on MoS2 Nanosheets. J. Am. Chem. Soc. 2015, 137, 7365−7370. 

(264) Sriram, P.; Su, D.-S.; Periasamy, A. P.; Manikandan, A.; Wang, S.-W.; Chang, H.-T.; Chueh, Y.-L.; Yen, T.-J. Hybridizing Strong Quadrupole Gap Plasmons Using Optimized Nanoantennas with Bilayer MoS2 for Excellent Photo-Electrochemical Hydrogen Evolution. Adv. Energy Mater. 2018, 8, 1801184. 

(265) Jiang, W.; Wu, X.; Chang, J.; Ma, Y.; Song, L.; Chen, Z.; Liang, C.; Liu, X.; Zhang, Y. Integrated hetero-nanoelectrodes for plasmon-enhanced electrocatalysis of hydrogen evolution. Nano Research 2021, 14, 1195−1201. 

(266) Kang, Y.; Gong, Y.; Hu, Z.; Li, Z.; Qiu, Z.; Zhu, X.; Ajayan, P. M.; Fang, Z. Plasmonic hot electron enhanced MoS2 photocatalysis in hydrogen evolution. Nanoscale 2015, 7, 4482−4488. 

(267) Saquib, M.; Kaushik, R.; Halder, A. Photoelectrochemical Activity of Ag Coated 2D-TiO2/RGO Heterojunction for Hydrogen Evolution Reaction and Environmental Remediation. ChemistrySelect 2020, 5, 6376−6388. 

(268) Zhang, W.; Wang, S.; Yang, S. A.; Xia, X. H.; Zhou, Y. G. Plasmon of Au nanorods activates metal-organic frameworks for both the hydrogen evolution reaction and oxygen evolution reaction. Nanoscale 2020, 12, 17290−17297. 

(269) Zhu, J.; Sun, Z.; Li, J. J.; Zhao, J. W. Local temperature pattern in plasmonic gold nanoshell: Tuning the heat generation. European Physical Journal B 2010, 78, 311−314. 

(270) Corson, E. R.; Subramani, A.; Cooper, J. K.; Kostecki, R.; Urban, J. J.; McCloskey, B. D. Reduction of carbon dioxide at a plasmonically active copper−silver cathode. Chem. Commun. 2020, 56, 9970−9973. 

(271) Kim, Y.; Creel, E. B.; Corson, E. R.; McCloskey, B. D.; Urban, J. J.; Kostecki, R. Surface-Plasmon-Assisted Photoelectrochemical Reduction of CO2 and NO3 - on Nanostructured Silver Electrodes. Adv. Energy Mater. 2018, 8, 1800363. 

(272) Song, J. T.; Ryoo, H.; Cho, M.; Kim, J.; Kim, J.-G.; Chung, S.Y.; Oh, J. Nanoporous Au Thin Films on Si Photoelectrodes for Selective and Efficient Photoelectrochemical CO2 Reduction. Adv. Energy Mater. 2017, 7, 1601103. 

(273) Duchene, J. S.; Tagliabue, G.; Welch, A. J.; Cheng, W. H.; Atwater, H. A. Hot Hole Collection and Photoelectrochemical CO2 Reduction with Plasmonic Au/p-GaN Photocathodes. Nano Lett. 2018, 18, 2545−2550. 

(274) Nitopi, S.; Bertheussen, E.; Scott, S. B.; Liu, X.; Engstfeld, A. K.; Horch, S.; Seger, B.; Stephens, I. E.; Chan, K.; Hahn, C.; Nørskov, J. K.; Jaramillo, T. F.; Chorkendorff, I. Progress and Perspectives of Electrochemical CO2 Reduction on Copper in Aqueous Electrolyte. Chem. Rev. 2019, 119, 7610−7672. 

(275) Zhang, C.; Zhao, H.; Zhou, L.; Schlather, A. E.; Dong, L.; McClain, M. J.; Swearer, D. F.; Nordlander, P.; Halas, N. J. Al-Pd Nanodisk Heterodimers as Antenna-Reactor Photocatalysts. Nano Lett. 2016, 16, 6677−6682. 

(276) Swearer, D. F.; Robatjazi, H.; Martirez, J. M. P.; Zhang, M.; Zhou, L.; Carter, E. A.; Nordlander, P.; Halas, N. J. Plasmonic 

Photocatalysis of Nitrous Oxide into N2 and O2 Using AluminumIridium Antenna-Reactor Nanoparticles. ACS Nano 2019, 13, 8076− 8086. 

(277) Sterl, F.; Strohfeldt, N.; Walter, R.; Griessen, R.; Tittl, A.; Giessen, H. Magnesium as novel material for active plasmonics in the visible wavelength range. Nano Lett. 2015, 15, 7949−7955. 

(278) Kriegel, I.; Scotognella, F.; Manna, L. Plasmonic doped semiconductor nanocrystals: Properties, fabrication, applications and perspectives. Physics Reports 2017, 674, 1−52. 

(279) Agrawal, A.; Cho, S. H.; Zandi, O.; Ghosh, S.; Johns, R. W.; Milliron, D. J. Localized Surface Plasmon Resonance in Semiconductor Nanocrystals. Chemical Reviews 2018, 118, 3121−3207. 

(280) Pradhan, N.; Das Adhikari, S.; Nag, A.; Sarma, D. D. Luminescence, Plasmonic, and Magnetic Properties of Doped Semiconductor Nanocrystals. Angew. Chem., Int. Ed. 2017, 56, 7038−7054. 

(281) Naik, G. V.; Shalaev, V. M.; Boltasseva, A. Alternative Plasmonic Materials: Beyond Gold and Silver. Adv. Mater. 2013, 25, 3264−3294. 

(282) Kisch, H.; Bahnemann, D. Best Practice in Photocatalysis: Comparing Rates or Apparent Quantum Yields? J. Phys. Chem. Lett. 2015, 6, 1907−1910. 

(283) ISO 22197−1:2016. Fine ceramics (advanced ceramics, advanced technical ceramics)  Test method for air-purification performance of semiconducting photocatalytic materials  Part 1: Removal of nitric oxide, 2016. https://www.iso.org/standard/65416. html. 

(284) Yao, K.; Zhao, C.; Wang, N.; Li, T.; Lu, W.; Wang, J. An aqueous synthesis of porous PtPd nanoparticles with reversed bimetallic structures for highly efficient hydrogen generation from ammonia borane hydrolysis. Nanoscale 2020, 12, 638−647. 

(285) Zhang, S.; Metin, Ö.; Su, D.; Sun, S. Monodisperse AgPd alloy nanoparticles and their superior catalysis for the dehydrogenation of formic acid. Angewandte Chemie - International Edition 2013, 52, 3681−3684. 

(286) Mo, Z.; Xu, H.; Chen, Z.; She, X.; Song, Y.; Lian, J.; Zhu, X.; Yan, P.; Lei, Y.; Yuan, S.; Li, H. Construction of MnO2/Monolayer g- C3N4 with Mn vacancies for Z-scheme overall water splitting. Applied Catalysis B: Environmental 2019, 241, 452−460. 

(287) Wang, S.; Zhang, J.; Li, B.; Sun, H.; Wang, S. Engineered Graphitic Carbon Nitride-Based Photocatalysts for Visible-LightDriven Water Splitting: A Review. Energy Fuels 2021, 35, 6504−6526. (288) Xu, G.; Zhang, H.; Wei, J.; Zhang, H. X.; Wu, X.; Li, Y.; Li, C.; Zhang, J.; Ye, J. Integrating the g-C3N4 Nanosheet with B-H Bonding Decorated Metal-Organic Framework for CO2 Activation and Photoreduction. ACS Nano 2018, 12, 5333−5340. 

(289) Tahir, M.; Tahir, B. Constructing a Stable 2D/2D Heterojunction of Oxygen-Cluster-Modified Ti3AlC2 MAX Cocatalyst with Proton-Rich C3N4 for Highly Efficient Photocatalytic CO2 Methanation. Ind. Eng. Chem. Res. 2020, 59, 9841−9857. 

(290) Murthy, A. P.; Theerthagiri, J.; Madhavan, J. Insights on Tafel Constant in the Analysis of Hydrogen Evolution Reaction. J. Phys. Chem. C 2018, 122, 23943−23949. 

(291) Lu, Q.; Rosen, J.; Zhou, Y.; Hutchings, G. S.; Kimmel, Y. C.; Chen, J. G.; Jiao, F. A selective and efficient electrocatalyst for carbon dioxide reduction. Nat. Commun. 2014, 5, 3242. 

(292) Gao, D.; Zhang, Y.; Zhou, Z.; Cai, F.; Zhao, X.; Huang, W.; Li, Y.; Zhu, J.; Liu, P.; Yang, F.; Wang, G.; Bao, X. Enhancing CO2 Electroreduction with the Metal-Oxide Interface. J. Am. Chem. Soc. 2017, 139, 5652−5655. 

(293) Zhao, J.; Xue, S.; Ji, R.; Li, B.; Li, J. Localized surface plasmon resonance for enhanced electrocatalysis. Chem. Soc. Rev. 2021, 50, 12070−12097. 

(294) Cortés, E.; Besteiro, L. V.; Alabastri, A.; Baldi, A.; Tagliabue, G.; Demetriadou, A.; Narang, P. Challenges in Plasmonic Catalysis. ACS Nano 2020, 14, 16202−16219. 

(295) Zhou, L.; Martirez, J. M. P.; Finzel, J.; Zhang, C.; Swearer, D. F.; Tian, S.; Robatjazi, H.; Lou, M.; Dong, L.; Henderson, L.; Christopher, P.; Carter, E. A.; Nordlander, P.; Halas, N. J. Light- 

814 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Review</mark> 

driven methane dry reforming with single atomic site antenna-reactor plasmonic photocatalysts. Nature Energy 2020, 5, 61−70. 

(296) Li, D.; Lao, J.; Jiang, C.; Luo, C.; Qi, R.; Lin, H.; Huang, R.; Waterhouse, G. I. N.; Peng, H. Plasmonic Au nanoparticle-decorated Bi2Se3 nanoflowers with outstanding electrocatalytic performance forhydrogen evolution. Int. J. Hydrogen Energy 2019, 44 (59), 30876− 30884. 

(297) Zhang, Y.; Du, J.; Luo, R.; Wang, Z.; Wang, Z.; Han, J.; Liu, P.; Fujita, T.; Xue, Q.; Chen, M. 3D bicontinuous nanoporous plasmonic heterostructure for enhanced hydrogen evolution reaction under visible light. Nano Energy 2019, 58, 552−559. 

(298) Wang, S.-S.; Jiao, L.; Qian, Y.; Hu, W.-C.; Xu, G.-Y.; Wang, C.; Jiang, H.-L. Boosting Electrocatalytic Hydrogen Evolution over Metal−Organic Frameworks by Plasmon-Induced Hot-Electron Injection. Angew. Chem., Int. Ed. 2019, 58, 10713. 

815 

https://doi.org/10.1021/acsenergylett.1c02241 ACS Energy Lett. 2022, 7, 778−815 

