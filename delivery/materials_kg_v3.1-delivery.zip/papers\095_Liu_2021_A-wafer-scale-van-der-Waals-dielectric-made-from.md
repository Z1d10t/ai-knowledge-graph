# A wafer-scale van der Waals dielectric made from an inorganic molecular crystal film

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Electronics |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 229 |
| 作者 | Kai-Lang Liu, Bao Jin, Wei Han, Xiang Chen, Peng-Lai Gong, Li Huang, Ying-He Zhao, Liang Li et al. |
| DOI | 10.1038/s41928-021-00683-w |
| 源文件 | 095_Liu_2021_A-wafer-scale-van-der-Waals-dielectric-made-from.pdf |

---




<!-- Start of picture text -->
Wafer -s cale van der Waals Dielectrics of Inorganic<br>Molecular Crystals<br>Kailang Liu<br><!-- End of picture text -->

Huazhong University of Science and Technology 

Huazhong University of Science and Technology 

Huazhong University of Science and Technology 

Nanjing University of Science and Technology 

Southern University of Science and Technology 

Southern University of Science and Technology https://orcid.org/0000-0003-0741-4903 

Huazhong University of Science and Technology 

Anhui University 

Huazhong University of Science and Technology 

Zhengzhou University 

Huazhong University of Science and Technology 

Huazhong University of Science and Technology 

Huazhong University of Science and Technology https://orcid.org/0000-0003-3673-2257 Tianyou Zhai  (  zhaity@hust.edu.cn ) 

Huazhong University of Science and Technology https://orcid.org/0000-0003-0985-4806 

Keywords: van der Waals dielectrics, Sb2O3, scalable fabrication 

Page 1/16 

Posted Date: January 6th, 2021 

DOI: https://doi.org/10.21203/rs.3.rs-115496/v1 

License:   This work is licensed under a Creative Commons Attribution 4.0 International License. Read Full License 

Version of Record: A version of this preprint was published at Nature Electronics on December 21st, 2021. See the published version at https://doi.org/10.1038/s41928-021-00683-w. 

Page 2/16 

Van der Waals (vdW) dielectrics such as hBN are widely used to preserve the intrinsic properties of twodimensional (2D) semiconductors and support the fabrication of high-performance 2D devices. This is fundamentally attributed to their dangling-bond-free surface, carrying far lower density of charged scattering sources and trap states with respect to the conventional dielectrics (SiO2 etc.). However, their wafer-scale fabrication and compatible integration with 2D semiconductors remain cumbersome, giving rise to the di�culties in scalable fabrication of high-performance 2D devices. Here we report a high-κ vdW dielectric (εr=11.5) composed of inorganic molecular crystal (IMC) Sb2O3, allowing for large-scale fabrication and facile integration via standard thermal evaporation process thanks to its particular crystal structure. Similarly, our vdW dielectric also supports remarkably improved 2D devices with respect to the typical conventional dielectric SiO2. The monolayer MoS2 �eld effect transistors (FET) supported by our vdW dielectric exhibits high on/off ratio (10<sup>8</sup> ), greatly enhanced electron mobility (from 20 to 80 cm<sup>2</sup> /Vs) and reduced transfer-curve hysteresis over an order of magnitude. Our results may open a new avenue towards compatible fabrication of vdW dielectrics using IMCs and lead to the scalable fabrication of high-performance 2D devices. 

Two-dimensional (2D) semiconductors have attracted enormous research interests for their great potentials as channel materials in the next-generation �eld-effect transistors (FETs) with high mobility and great gate controllability at atomic thinness<sup>[1–5]</sup> . However, due to such a thinness, their electrical performance can be severely deteriorated by surrounding disorders, generally arising from chemical adsorbates and its neighboring dielectrics. Such disorders may bring charged scattering sources and trap states, resulting in the device performance inferior to their intrinsic properties<sup>[6, 7]</sup> . Since the discovery of high-quality graphene supported on hBN<sup>[6]</sup> , using vdW dielectrics has become a universal approach to preserve the intrinsic properties of 2D materials<sup>[8–11]</sup> and support the fabrication of high-performance devices<sup>[7, 12, 13]</sup> . The advantages of vdW dielectrics over conventional oxides (SiO2 etc.) substantially stem from their atomically �at surface, free of dangling bonds and with low-density disorders<sup>[6, 14–17]</sup> . In particular, the 2D FETs using vdW dielectrics exhibit excellent characteristics, including enhanced mobility and better switching stability<sup>[12, 13, 18]</sup> . However, such vdW dielectrics are prepared via either the mechanical exfoliation<sup>[12, 13]</sup> or vapor deposition growth on specially-designed substrate at high temperature<sup>[16–19]</sup> , incompatible to the standard semiconductor manufacturing processes. Till now, scalable growth of such vdW dielectric materials as well as its integration with 2D semiconductors remain challenging. 

Here we report a vdW dielectric �lm of inorganic molecular crystal (IMC) Sb2O3, which can be readily fabricated via standard thermal evaporation deposition (STED) process thanks to its particular crystal structure. The molecular structure is well preserved during the evaporation owing to the high molecular stability, which is con�rmed by our theoretical calculations. The deposited �lm, free of dangling bonds, 

Page 3/16 

can serve as vdW dielectrics. Its synthesis approach allows for scalable fabrication and facile integration with 2D semiconducting materials for devices fabrication at scale. To demonstrate that our vdW dielectric �lm similarly possess comparative advantages over the conventional dielectrics, we investigate the device performance of 2D MoS2 FET supported on Sb2O3 and standard SiO2 substrate respectively. We con�rm that our MoS2/Sb2O3 FETs signi�cantly outperform the MoS2/SiO2 devices, including a higher on-state current, greatly enhanced electron mobility and reduced hysteresis. Speci�cally, our monolayer MoS2/Sb2O3 FET exhibits a high on/off ratio of 10<sup>8</sup> and an enhanced electron mobility of 82 cm<sup>2</sup> /Vs at room temperature, in contrast to 20 cm<sup>2</sup> /Vs for the same device supported on SiO2. In addition, all the MoS2/SiO2 FETs demonstrate a considerable hysteresis in double-sweep transfer characteristic curves due to the trap states within the SiO2 substrate, which turn out to be negligibly small for the MoS2/Sb2O3 FETs, with a reduction of more than an order of magnitude. Based on the quantitative analysis of hysteresis, we also estimate a far lower density of trap states (nearly two orders of magnitudes) on Sb2O3 substrate in comparison to standard SiO2. The scalable fabrication of vdW dielectrics via compatible integration processes is a prerequisite for the scale-up of high-performance 2D devices. Our approach of fabricating vdW dielectrics using IMCs may open up unprecedented opportunities to promote such promising 2D devices to technological applications. 

Our vdW dielectric �lm is fabricated via STED (Fig. 1a) at room temperature. We use IMC Sb2O3 powder as the evaporation source. It consists of ultra-small Sb4O6 molecules in the form of bicyclic cages (Sb-O bond length 1.98 Å)<sup>[20–22]</sup> . All the molecules are bonded together via vdW interaction (Fig. 1b). Due to such a weak intermolecular interaction, Sb2O3 molecules are prone to sublime at elevated temperature in high vacuum before its melting, without the breakage of the Sb-O bonds. Its evaporation temperature is measured to be around (490℃) via thermogravimetric analysis at ambient pressure (Figure S1), much lower than its melting point (656℃), which implies the sublimation process of molecules at elevated temperature (The evaporation temperature in our vacuum chamber is supposed to be much lower according to Clausius-Clapeyron relation). The molecular vapor evaporated from Sb2O3 powder, free of dangling bonds all around, deposit on the substrate to form a vdW substrate (Fig. 1a). Our STED process permits the fabrication of homogeneous wafer-scale �lm (Fig. 1c and Figure S2) and the �lm thickness can be precisely controlled (Fig. 1d and Figure S2). Atomic force microscopy (AFM) is used to characterize the morphology of our �lm. It reveals its great homogeneity and �atness of our deposited �lm in micro-metric scale, without discernible voids or bumps (Fig. 1e and f). The homogeneity of morphology and elemental distribution are also con�rmed by scanning electron microscope (SEM) and elemental maps of energy-dispersive X-ray spectroscopy (EDS) (Figure S3). 

To con�rm the molecular structure of our deposited �lm, Raman spectroscopy is employed to probe the vibrational modes of the molecules. We �nd that all the Raman peaks of Sb2O3 �lm can be assigned to the intra-molecule Raman mode (see Table S1) and match well with those of Sb2O3 powder used as the 

Page 4/16 

deposition source, implying that Sb2O3 evaporates in the form of molecular vapor with the molecular structure preserved. The stability of Sb2O3 molecules can be con�rmed from the perspective of theoretical calculations via investigating the vacancy formation energy within the molecule. The formation energies of typical O, Sb, and double O vacancy are all found to be over 5 eV (Table S2), indicative of a robust molecule without the formation of vacancies and dangling bonds. Moreover, we investigate our eventual Sb2O3 �lm with X-ray diffraction (XRD), high-resolution transmission microscopy (HRTEM) as well selected-area electron diffraction pattern (SAED), which further reveal the polycrystalline structure of our Sb2O3 �lm(Figure S4). It is worth noting that the benign grain boundaries in our Sb2O3 �lm generally are free of dangling bonds<sup>[23]</sup> , which in principle would not introduce effective defects into the dielectric. 

We now investigate the dielectric properties of our Sb2O3 �lm. To determine its band gap, a 40 nm Sb2O3 �lm is deposited on glass substrate for absorption spectroscopy measurement (see Methods). The band gap of Sb2O3 �lm is determined to be 3.95 eV from its absorption spectrum (Fig. 2a), in good agreement with its density of states (DOS) distribution (Fig. 2b). Such a wide band gap renders our Sb2O3 �lm an insulator, as ascertained by the conductive test of a two-terminal device (Fig. 2c). Its resistivity of over 10<sup>9</sup> Ω∙cm at 300 K can be extracted from its I-V curve (Fig. 2c). To test its breakdown electric �eld, Sb2O3 �lm is sandwiched between two electrodes (Figure S6). As demonstrated in Fig. 2d, the breakdown voltage of our Sb2O3 �lm can be estimated to be 180 MV/m, comparable to that of SiO2. 

In order to determine the dielectric constant of Sb2O3, we fabricate a series of parallel-plate capacitors, using Sb2O3 of 300 nm as the dielectric sandwiched between degenerately doped Si substrate and metal pads. The capacitance with respect to area S are measured at increasing frequency are respectively measured (Fig. 2e inset). We then extract the static capacitance at low frequency (10 kHz) and estimate the capacitance per unit area to be C = 0.34 nF/mm<sup>2</sup> . The relative dielectric constant of our Sb2O3 �lm then can be calculated to be εr = 11.5 via the formula C = εrε0/d where ε0 is dielectric constant of vacuum and d is the thickness of Sb2O3 �lm. The measured dielectric constant of our Sb2O3 matches well with the reported value<sup>[24]</sup> . In addition, such a high dielectric constant is comparable to typical high-κ dielectric Al2O3. As the low dielectric constant of hBN (~ 5<sup>[12]</sup> ) is one of its limitations in the FET application, our Sb2O3 vdW dielectric, in contrast, possesses the highest dielectric constant in all the reported vdW dielectrics (Figure S7). 

In analogy to typical vdW dielectric h-BN, our Sb2O3 �lm of molecular crystal is free of dangling bonds, naturally holding low-density charge scattering centers and charge trap states. Our vdW �lm can potentially support high-performance 2D electronic devices of higher mobility and smaller hysteresis as well. To demonstrate its advantages in this regard, we fabricate 2D FETs respectively on our Sb2O3 vdW substrate and standard SiO2 substrate, then systematically investigate their temperature-dependent device characteristics. 

Page 5/16 

The well-studied 2D semiconductor MoS2 is chosen as the representative channel materials and all the FET devices are fabricated using the same processes (see Methods). For a clear comparison, our Sb2O3 substrate is composed of 40-nm �lm deposited on the standard SiO2/Si substrate to fully screen the charged center and trap states on SiO2 substrate (Fig. 3a). 2D MoS2 �akes are prepared via mechanical exfoliation and transferred onto the substrates. Their thickness are con�rmed via optical measurement (Figure S8) and AFM (Figure S9a and b) before the device fabrication. Degenerately doped Si serves as FET back gate in our measurement (Fig. 3a). To minimize the effect of contact resistance in our devices, we use In/Au metal to form low-resistance contact with MoS2<sup>[25]</sup> . Moreover, we also degas all the devices in high vacuum (10<sup>− 6</sup> torr) for 3 hours to reduce air adsorption on our device surface before the tests are carried out<sup>[26]</sup> . The FET based on monolayer MoS2 supported on Sb2O3 substrate is demonstrated in Fig. 3b. 

For monolayer MoS2, the band offsets at valance band maximum (VBM) and conduction band minimum (CBM) can be estimated from its band alignment to Sb2O3 (the vacuum level at 0 eV while the well-known VBM and CBM of MoS2 are extracted from reference<sup>[27]</sup> ) (Fig. 3c). These band offsets over 1 eV effectively con�ne the charges within the MoS2 channel during the device measurement. The Ohmic contact of electrodes to 2D MoS2 and great gate control of our FET can be veri�ed from the linear output curves (Ids-Vds) both at 40 K (Fig. 3d) and 300 K (Figure S9c). From the typical double-sweep transfer characteristics curves (Ids-Vgs) of monolayer MoS2/Sb2O3 FET measured at 40 K( Fig. 3e), we observe a negligibly small hysteresis window (sweep rate in all our measurements ~ 1 V/S) and estimate the electron mobility µFE at the linear range to be over 80 cm<sup>2</sup> /Vs (see Methods). In contrast, monolayer MoS2 FET on SiO2 exhibits a considerable hysteresis and much lower mobility (~ 20 cm<sup>2</sup> /Vs) despite the same device fabrication processes and measurement conditions (Figure S13). For a clear comparison of dielectric effect (Sb2O3 and SiO2) on FET mobility, we plot together their electron mobility at various gate voltage (Vgs) (Fig. 3f). The maximum electron mobility appears at around Vgs = 50V, corresponding to the charge carrier density n = 4.0 × 10<sup>12</sup> /cm<sup>2</sup> (see Methods), in agreement with the reported MoS2 FETs<sup>[25]</sup> . The FET mobility monotonically decreases at higher temperature for our devices (Fig. 3g), presumably due to rising phonon scattering. In comparison to the reported measurements at room temperature, our monolayer MoS2/Sb2O3 FET exhibits a mobility µFE of over 70 cm<sup>2</sup> /Vs, even higher than the reported value of MoS2 supported on hBN<sup>[12, 16]</sup> (Fig. 3g). 

Similar contrast experiments are also carried out using few-layer MoS2 as channel materials. The thickness-dependent mobility of supported different substrates are measured at various temperature (Fig. 3g). The comparative advantages of our vdW substrate for thicker MoS2 can also be clearly identi�ed though the mobility improvement becomes less apparent, by a factor of 2 (from 40 cm<sup>2</sup> /Vs on SiO2 to 90 cm<sup>2</sup> /Vs on Sb2O3 for trilayer MoS2 at 40 K ). This is generally attributed to the rise of screening effect for thicker MoS2 to the charged disorders on the underlying dielectric. Interestingly, the MoS2 thickness more sensitively affect the mobility for the SiO2 supported devices (mobility changes by 

Page 6/16 

a factor of 2 for monolayer and trilayer MoS2) while MoS2 of various thickness on Sb2O3 demonstrate similar mobility (see Fig. 3g). This also implies the low-density of disorders on our Sb2O3 substrate, without apparent scattering to the carrier transport of all the MoS2 channel. 

We now focus on the hysteresis of our MoS2 FET to investigate the charge trapping states of our vdW Sb2O3 and SiO2 substrates. The hysteresis of transfer characteristic curves features the instability of a FET at work, usually caused by the trapping states located in channel semiconductors, dielectric and at their interface<sup>[28]</sup> . Using vdW dielectric has been proved effective to minimize the hysteresis of 2D semiconductor FETs<sup>[12, 29]</sup> . In Fig. 3e, we already demonstrated the ultra-small hysteresis in the doublesweep transfer curves. Such a small hysteresis demonstrate a clear contrast to that obtained from a typical SiO2-supported monolayer MoS2 FET (Fig. 4a). The variation of the onset voltage ΔVon, which is usually used to quantify the FET hysteresis, reduces over an order of magnitude from 5.1 V for MoS2/SiO2 to 0.24 V for MoS2/Sb2O3 FET at 40 K. We also investigated the temperature-dependent transfer characteristics of our FET (Fig. 4b and d). We �rstly note that the onset voltage (Von) position apparently shifts toward lower voltage with the increasing temperature, presumably resulted from the Fermi level downward shift due to rising thermal excitation in MoS2, in agreement with the reported works [30, 31]. As to the amount of hysteresis ΔVon, the temperature variation from 40 K to 300 K leads to a slight increase of hysteresis for MoS2/Sb2O3 FET. Such a small dependence implies to a low density of effective trap states within our Sb2O3 dielectric as the hysteresis is generally induced by the charge carriers trapped into the trap states during the FET on/off switching (Fig. 4). In contrast, the hysteresis of monolayer MoS2/SiO2 FET sensitively depends on the temperature (Figure S13). The double-sweep transfer curves exhibit a large hysteresis window at 300 K and its ΔVon reaches 12 V. This observation accordingly points to a high density of trap states on SiO2 substrate, which can even be thermally activated at higher temperature<sup>[31]</sup> . 

To con�rm the source of trap states, we also investigate the thickness-dependent hysteresis of MoS2 FETs. For all the MoS2/Sb2O3 FETs at various temperature, the transfer characteristic curves exhibit small hysteresis window and ΔVon negligibly depends on MoS2 thickness (Fig. 4d). Such an observation implies that the trap states are not caused by the bulk defects in MoS2 considering that the density of such trap states are in principle thickness-dependent. For MoS2/SiO2 FETs, as one can anticipate, the hysteresis demonstrates no obvious dependence on MoS2 thickness but increases considerably with temperature due to the thermal activation of trap states at higher temperature. As our Sb2O3 substrates are exposed in air for long time (a few days), air adsorption onto our Sb2O3 �lm may introduce some the trap states and leads to the hysteresis<sup>[25]</sup> . Our experimental results, however, ruled out this possibility. It turns out that the typical gas can hardly adsorb onto Sb2O3 molecules, as revealed by our theoretical calculations owing to its inert surface (see Table S3). 

Page 7/16 

In order to quantitate the trap states density on Sb2O3 and SiO2 substrates, we investigate the variation of threshold voltage ΔVth in double-sweep transfer characteristic curves, which correlates to the charge of trap states density ΔQ according to ΔVth = ΔQ × C<sup>[28]</sup> , where C and ΔQ respectively stand for the gate capacitance and trapped charges. The values of ΔVth for all our MoS2/Sb2O3 devices can hardly be precisely extracted by linearly extrapolating the transfer curves due to the almost negligible hysteresis window (see Fig. 3e, Figure S9 d). We estimate ΔVth for monolayer MoS2/Sb2O3 device to be lower than 0.1 V without observable dependence on temperature, thus corresponding to a trap states density of 6.9 × 10<sup>9</sup> /cm<sup>2</sup> . In contrast, the trap states density on SiO2 demonstrates a trap charge states of 4V at 40 K. It furthermore increases to 9V at 300 K under thermal activation, corresponding to a trap states density 4.3 × 10<sup>11</sup> /cm<sup>2</sup> , which matches well with the reported value extracted from MoTe2 FET<sup>[28]</sup> . We thus con�rm a remarkable reduction of trap states by nearly two orders of magnitude for our Sb2O3 substrate with respect to SiO2. 

Our approach substantially relies on the particular structure of Sb2O3 and its excellent insulating properties. Our results may merely open up the opportunities for the scalable fabrication of vdW dielectrics via compatible processes. Evidently, such an approach of compatible fabrication is not limited to the Sb2O3, but applicable to other IMCs. In this regard, it would be of great interest to explore other IMCs (for instance with large bandgap and higher dielectric constants). As to our Sb2O3 �lm, the fabrication process can still be optimized via the modulation of substrate temperature and deposition rate in more advanced deposition systems. For instance, the deposition at low temperature may lead to formation of amorphous Sb2O3 �lm, which may furthermore modulate the �lm morphology (such as �lm roughness) as well as dielectric properties. 

As a representative example, the monolayer MoS2/Sb2O3 FETs demonstrated a mobility enhancement of 4 times using a FET measurement. However, the contact issue at the InAu-MoS2 interface may still exists for two-terminal devices, possibly leading to some underestimation of the vdW dielectric effect on the FET mobility enhancement. Its full potentials may be realized via the measurement of Hall devices. In principle, such a vdW dielectric may improve the device performance based on other 2D materials<sup>[2]</sup> and can be potentially used in other device architectures<sup>[32–34]</sup> . 

In summary, we demonstrated a novel approach to fabricate vdW dielectrics via thermal evaporation deposition using IMCs. Such an approach allows for precise deposition control, scalable fabrication and facile integration to other 2D materials. In addition, taking MoS2 FET as an initial demonstration, we unambiguously con�rm that our vdW dielectric is capable of supporting higher-quality 2D electronic devices with respect to SiO2, with a signi�cant electron mobility enhancement and a great hysteresis reduction. Our vdW dielectric not only overcomes the drawbacks of other vdW dielectrics (hBN etc.) in terms of process compatibility to standard semiconductor manufacturing, but also keeps their 

Page 8/16 

comparative advantages in the fabrication of high-performance electronic devices over conventional dielectrics. Our results potentially lead to the scalable fabrication of 2D devices with their intrinsic properties preserved using vdW dielectrics. 

Thermal evaporation deposition. The thermal evaporation deposition of Sb2O3 is carried out via standard deposition system (Nexdep, Angstrom Engineering) in high vacuum (10<sup>-6</sup> torr). The deposition rate is well controlled by an in-situ crystal quartz monitor. We use a low deposition rate of 0.06 Å/S for all the fabrication of Sb2O3 film to keep the flatness of Sb2O3 film. 

AFM. The morphology characterization and thickness calibration of Sb2O3 film as well as the thickness measurement of MoS2 are carried out with AFM (Bruker Dimension FastScan). 

Absorption spectroscopy. Absorption spectrum of Sb2O3 film deposited on glass substrate is obtained via Shimadzu SolidSpec-3700i UV-VIS-NIR spectrophotometer. 

Optical spectroscopy. Raman spectra and photoluminescence are obtained in a confocal Raman system (WITek Alpha300) with an excitation laser of 532 nm at 2 mW. 

Computation methods. The first-principles calculations were performed in the Vienna ab initio simulation package (VASP). The computation details for density of states for Sb2O3, vacancy formation energy within Sb2O3 molecule and gas adsorption are respectively described in supplementary information. 

MoS2 FET fabrication and test. 2D MoS2 are prepared via mechanical exfoliation using scotch and PDMS. The SiO2 substrates are firstly well cleaned with Ar plasma (Diener Pico). The fabricated Sb2O3 substrates are normally exposed in air before the exfoliation of MoS2. After the confirmation of MoS2 via optical measurement. PMMA is spin-coated onto the substrates with MoS2. Afterwards, the electrodes are defined via standard electron beam lithography (EBL), followed by the deposition of 10 nm In and 90 nm Au evaporated via electron beam. After the metal lift-off in acetone, the devices are transferred into a chamber equipped with semiconductor analyzer Keithly 4200. We pump the chamber and keep it in high vacuum (10<sup>-6</sup> torr) for 3 hours to eliminate the gas adsorption on device surfaces before the device test. Afterwards, devices tests are carried out at increasing temperature from 40 K to 300 K. 

FET mobility extraction. The FET mobility is extracted from transfer curve via the formula 



where L and W are respectively the width and length of channel material, C is the gate capacitance, Vds and Ids are respectively the biased voltage and current between source and drain, and Vgs is gate voltage. The 

Page 9/16 

capacitance of SiO2 substrate is estimated to be 1.15×10<sup>-8</sup> F/cm<sup>2</sup> for the dielectric constant (3.5) and thickness (300 nm). The capacitance of our Sb2O3 substrate deposited on SiO2/Si is estimated to be 1.15×10<sup>-8</sup> F/cm<sup>2</sup> for the dielectric constant (11.5) and thickness (40 nm). 

Carrier density estimation. The charge carrier density of channel materials is estimated via n=C (Vgs-Vth)/ e where Vgs is the gate voltage and Vth is the threshold voltage (determined from the FET transfer characteristic curves) and e is electron charge. 

1. Radisavljevic, B., Radenovic, A., Brivio, J., Giacometti, V. & Kis, A. Single-layer MoS2 transistors. Nat. Nanotech. 6, 147–150 (2011). 

2. Li, L. et al. Black phosphorus �eld-effect transistors. Nat. Nanotech. 9, 372–377 (2014). 

3. Kang, K. et al. High-mobility three-atom-thick semiconducting �lms with wafer-scale homogeneity. Nature 520, 656–660 (2015). 

4. Liu, Y., Duan, X., Huang, Y. & Duan, X. Two-dimensional transistors beyond graphene and TMDCs. Chem. Soc. Rev. 47, 6388–6409 (2018). 

5. Aljarb, A. et al. Ledge-directed epitaxy of continuously self-aligned single-crystalline nanoribbons of transition metal dichalcogenides. Nat. Mater. (2020), DOI: 10.1038/s41563-020-0795-4. 

- �. Dean, C. R. et al. Boron nitride substrates for high-quality graphene electronics. Nat. Nanotech. 5, 722–726 (2010). 

7. Rhodes, D., Chae, S. H., Ribeiro-Palau, R. & Hone, J. Disorder in van der Waals heterostructures of 2D materials. Nat. Mater. 18, 541–549 (2019). 

- �. Wang, L. et al. One-dimensional electrical contact to a two-dimensional material. Science 342, 614– 617 (2013). 

9. Cui, X. et al. Multi-terminal transport measurements of MoS2 using a van der Waals heterostructure device platform. Nature Nanotech. 10, 534–540 (2015). 

10. Cadiz, F. et al. Excitonic linewidth approaching the homogeneous limit in MoS2-based van der Waals heterostructures. Phys. Rev. X 7, 021026 (2017). 

11. Cao, Y. et al. Unconventional superconductivity in magic-angle graphene superlattices. Nature 556, 43–50 (2018). 

12. Lee, G. et al. Flexible and transparent MoS2 �eld-effect transistors on hexagonal boron nitridegraphene heterostructures. ACS Nano 7, 7931–7936 (2013). 

13. Lee, G.-H. et al. Highly stable, dual-gated MoS2 transistors encapsulated by hexagonal boron nitride with gate-controllable contact, resistance, and threshold Voltage. ACS Nano 9, 7019–7026 (2015). 

14. Xue, J. et al. Scanning tunnelling microscopy and spectroscopy of ultra-�at graphene on hexagonal boron nitride. Nat. Mater. 10, 282–285 (2011). 

Page 10/16 

15. Decker, R. et al. Local electronic properties of graphene on a BN substrate via scanning tunneling microscopy. Nano Lett. 11, 2291–2295 (2011). 

- 1�. Kim, S. M. et al. Synthesis of large-area multilayer hexagonal boron nitride for high material performance. Nat. Commun. 6, 8662 (2015). 

17. Chen, T. A. et al. Wafer-scale single-crystal hexagonal boron nitride monolayers on cu (111). Nature 579, 219–223 (2020). 

- 1�. Illarionov, Y. et al. Ultrathin calcium �uoride insulators for two-dimensional �eld-effect transistors. Nat. Electron. 2, 230–235 (2019). 

19. Wang, L. et al. Epitaxial growth of a 100-square-centimetre single-crystal hexagonal boron nitride monolayer on copper. Nature 570, 91–95 (2019). 

20. Svensson, C. Re�nement of the crystal structure of cubic antimony trioxide Sb2O3. Acta Crystallogr. B. 31, 2016–2018 (1975). 

21. Pereira, A. L. J. et al. Structural and vibrational study of cubic Sb2O3 under high pressure. Phys. Rev. B 85, 174108 (2012). 

22. Han, W. et al. Two-dimensional inorganic molecular crystals. Nat. Commun. 10, 4728 (2019). 

23. Zhou, Y. et al. Thin-�lm Sb2Se3 photovoltaics with oriented one-dimensional ribbons and benign grain boundaries. Nat. Photonics 9, 409–415 (2015). 

24. Young, K. F. and Frederikse, H. P. R. Compilation of the static dielectric constant of inorganic solids. J. Phys. Chem. Refer. Data 2, 313–410 (1973). 

25. Wang, Y. et al. Van der Waals contacts between three-dimensional metals and two-dimensional semiconductors. Nature 568, 70–74 (2019). 

- 2�. Late, D. J. et al. Hysteresis in single-layer MoS2 �eld effect transistors. ACS Nano 6, 5635–5641 (2012). 

27. Liu, Y., Stradins, P. & Wei, S.-H. Van der Waals metal–semiconductor junction: weak Fermi level pinning enables effective tuning of Schottky barrier. Sci. Adv. 2, e1600069 (2016). 

- 2�. Amit, I. et al. Role of charge traps in the performance of atomically thin transistors. Adv. Mater. 29, 1605598 (2017). 

29. Lee, C.-H. et al. Atomically thin p–n junctions with van der Waals heterointerfaces. Nature Nanotech. 9, 676–681 (2014). 

30. Zhu, W. et al. Electronic transport and device prospects of monolayer molybdenum disulphide grown by chemical vapour deposition. Nat. Commun. 5, 3087 (2014). 

31. Park, Y. et al. Thermally activated trap charges responsible for hysteresis in multilayer MoS2 �eldeffect transistors. Appl. Phys. Lett. 108, 083102 (2016). 

32. Britnell, L. et al. Field-effect tunneling transistor based on vertical graphene heterostructures. Science 335, 947–950 (2012). 

Page 11/16 

33. Ju, L. et al. Photoinduced doping in heterostructures of graphene and boron nitride. Nat. Nanotech. 9, 348–352 (2014). 

34. Vu, Q. A. et al. Two-terminal �oating-gate memory with van der Waals heterostructures for ultrahigh on/off ratio. Nat. Commun. 7, 12725 (2016). 

# Acknowledgements 

This work was supported by the National Nature Science Foundation of China (21825103, 51727809, 11904154), the Hubei Provincial Nature Science Foundation of China (2019CFA002), the Fundamental Research Funds for the Central Universities (2019kfyXMBZ018). We also acknowledge the Analytical and Testing Center of Huazhong University of Science and Technology for the TEM characterizations and analysis. Computational time is partially supported by the Center for Computational Science and Engineering of Southern University of Science and Technology. 

# Author contributions 

K.L and T.Z conceived the ideas. K.L and B.J. designed and carried out most the experiments under T.Z.’s supervision. K.L, B.J and X.H deposited the �lm. K.L and J. D performed the absorption spectrum measurement. P.G, and L. H carried out the works of �rst-principle calculations. X. C, L.L, S.Y and F. Z helped to analyze the data. K.L, W.H, L.L and T.Z worked on the images with the assistance from all the others. K.L wrote the paper with the inputs of all the co-authors. 

Competing �nancial interests 

The authors declare no competing �nancial interests. 

Page 12/16 



Fabrication of wafer-scale Sb2O3 �lm via standard thermal evaporation deposition. a, Schematic �gures for the fabrication of vdW �lm composed of Sb2O3 molecules via STED. b, Molecular crystal structure of Sb2O3 showing (111) plane and the structure of the ultra-small molecule. c, Sb2O3 �lm of 40 nm homogeneously deposited on a 4-inch wafer. d, Well-controlled thickness of our Sb2O3 �lm versus deposition time at a given deposition rate. e and f, AFM image of Sb2O3 �lm and a corresponding line pro�le. g, Raman spectra of Sb2O3 �lm of 40 nm deposited on substrate (green) and Sb2O3 source powder (grey) for thermal evaporation deposition in a. 

Page 13/16 



Dielectric properties of Sb2O3 �lm. a, The absorption spectrum of Sb2O3 �lm deposited on glass. , The density of state of bulk Sb2O3 via �rst-principle calculations, with the CBM being set at 0 eV. c, Conductivity measurement of Sb2O3 �lm deposited on SiO2/Si substrate. Inset: the optical image of the device for the measurement. d, The breakdown measurement of Sb2O3 �lm. Inset: the schematic �gure of the measurement device. e, The capacitances of parallel plate with Sb2O3 �lm as the dielectric material at relatively low frequency (10 kHZ), from which the dielectric constant of Sb2O3 �lm can be determined. Inset: the capacitance measured at various frequency (top-left corner) and the schematic �gures of the devices for frequency-capacitance measurement (bottom-right corner). 

Page 14/16 



MoS2 FET supported by vdW Sb2O3 substrate. a, Schematic �gure of monolayer MoS2 FET supported on Sb2O3 substrate. b, Optical image of the FET device. c, The band alignment of Sb2O3 and monolayer MoS2[27], with the band offsets over 1 eV. d, The output curves (Ids-Vds) of monolayer MoS2/Sb2O3 FET measured at 40 K. e, the double-sweep transfer characteristic curves of monolayer MoS2 FET. f, The FET mobility of monolayer MoS2, respectively on Sb2O3 and standard SiO2 substrate at various gate voltage Vgs. g, The temperature-dependent FET mobility of few-layer MoS2 supported on Sb2O3 and SiO2 substrate. As references, we also plot together some reported values of MoS2 FET supported on the widely used vdW dielectric hBN as reference [12, 13]. 

Page 15/16 



Hysteresis of MoS2 FETs supported on Sb2O3 and SiO2 substrate. a, Double-sweep transfer characteristic curves of monolayer MoS2/Sb2O3 and MoS2/SiO2 FETs respectively. b, Temperaturedependent hysteresis of monolayer MoS2/Sb2O3 FET. c, Schematic �gure depicting the charge trapping from channel material into dielectric trap states during the FET switching, giving rise to the hysteresis window in double-sweep transfer characteristics curves. d, Temperature-dependent hysteresis (ΔVon) of MoS2 FET with various layer number supported on SiO2 and Sb2O3 substrates. 

This is a list of supplementary �les associated with this preprint. Click to download. 

Supplementaryinfo.docx 

Page 16/16 

