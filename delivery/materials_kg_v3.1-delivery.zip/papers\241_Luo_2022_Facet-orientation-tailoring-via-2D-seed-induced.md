# Facet orientation tailoring via 2D-seed- induced growth enables highly efficient and stable perovskite solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Joule |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 247 |
| 作者 | Chao Luo, Guanhaojie Zheng, F. Gao, Xianjin Wang, Yao Zhao, Xing-Yu Gao, Qing Zhao |
| DOI | 10.1016/j.joule.2021.12.006 |
| 源文件 | 031_Luo_2022_Facet-orientation-tailoring-via-2D-seed-induced.pdf |

---
**ll** 

### Article 

# Facet orientation tailoring via 2D-seedinduced growth enables highly efficient and stable perovskite solar cells 



Chao Luo, Guanhaojie Zheng, Feng Gao, Xianjin Wang, Yao Zhao, Xingyu Gao, Qing Zhao zhaoqing@pku.edu.cn 

Highlights 

2D seed induction is proposed to enhance the efficiency of mixeddimensional PSCs 

Deliberately promoting favorable but completely eliminating undesired facets is achieved 

High efficiency (23.95%) and FF (0.847) are achieved for mixeddimensional PSCs 

Seed-induced crystallization is compatible and universal 

The favorable tailoring of facet orientation is realized by introducing highly oriented 2D perovskite (BDA)PbI4 to as a seed to regulate the crystallization kinetics of 3D perovskite. This strategy delivers a superior PCE of 23.95% and remarkable FF of 0.847, representing the highest values of mixed-dimensional PSCs. Moreover, the efficient PSC retains 91% of its initial PCE after 500 h tracking at the maximum power point under simulated AM1.5 illumination at 60<sup>�</sup> C. 

Luo et al., Joule 6, 240–257 January 19, 2022 ª 2021 Published by Elsevier Inc. https://doi.org/10.1016/j.joule.2021.12.006 



**ll** 

##### Article 

## Facet orientation tailoring via 2D-seedinduced growth enables highly efficient and stable perovskite solar cells 

Chao Luo,<sup>1</sup> Guanhaojie Zheng,<sup>2,3,4</sup> Feng Gao,<sup>1</sup> Xianjin Wang,<sup>1</sup> Yao Zhao,<sup>1</sup> Xingyu Gao,<sup>2,3,4</sup> and Qing Zhao<sup>1,5,6,7,</sup> * 

###### SUMMARY 

Adding 2D perovskite to 3D perovskite has been developed to effectively enhance the intrinsic stability, but it will inevitably compromise the power conversion efficiency (PCE). Here, in a novel way, we introduced highly oriented 2D (BDA)PbI4 perovskites as seeds to optimize the growth kinetics of 3D perovskite and make its crystallization directly stride over the nucleation stage. Therefore, the seeds preferentially act as templates to epitaxially grow 3D perovskite with the desired facet orientation and stacking mode. Moreover, the 2D seeds are transformed into the grain boundary after completing the orientation-induced growth. As a result, the high-quality mixed-dimensional perovskite film delivers a superior PCE of 23.95%, accompanied by a remarkable FF of 0.847. The unencapsulated Perovskite solar cell (PSC) retains 93% of its original efficiency after 1,056 h of storage and retains 91% of its initial efficiency after 500 h of operation at the maximum power point under simulated AM1.5 illumination at 60<sup>�</sup> C. 

###### INTRODUCTION 

Along with the swift development of perovskite solar cells (PSCs) in the past decade, tremendous efforts have been dedicated to passivating the generated defects by various additives or interface modification.<sup>1–3</sup> Although these attempts have made the efficiency and stability of PSCs jump to a much higher level,<sup>4,5</sup> developing a general strategy to fundamentally manipulate the crystal growth of perovskite, thus reducing the generation of defects, remains a challenge. 

Recently, the photovoltaic performance of PSCs has been found to strongly correlate with their facet orientations, which has been less explored previously. For example, the charge carrier lifetime, open-circuit voltage (VOC) deficit and device hysteresis of PSCs have been found to be related to the defect structure and density in (111) crystal facets of perovskite, and PSC performance can be enhanced by reducing the defects of (111) crystal facets.<sup>6</sup> Tao et al. showed that the perovskite (111) facet tends to have the highest defects density, as opposed to the perovskite (100) facet that has the least defects.<sup>7</sup> Similarly, the (100) facet has been reported to have higher photoluminescence (PL) intensity and an order of magnitude lower defect density than the (112) facet.<sup>8</sup> The dependence of defect density and intrinsic stability on crystal facet has been further investigated through experiments and theoretical calculations.<sup>9–13</sup> Consequently, the facet-dependent defect states in the polycrystalline perovskite lead to a strong dependence of PSC performance on the crystal facet orientations.<sup>14</sup> As a consequence, tailoring the facet orientation of perovskite, that is, deliberately 

###### Context & scale 

Perovskite solar cells (PSCs) show great competitiveness compared with traditional silicon or other thin-film solar cells. Mixeddimensional perovskite can combine the advantage of the high stability of two-dimensional (2D) perovskite and the superior efficiency of three-dimensional (3D) perovskite. However, the efficiency of mixed-dimensional PSCs is still lower than that of pure 3D PSCs. To solve this problem, we introduced 2D perovskite as a seed for the regulation of 3D perovskite crystallization kinetics and thus the facet orientation tailoring. The seeds act as templates to epitaxially grow high-quality 3D perovskite film with designed facet orientation and greatly reduced defect density. Moreover, the 2D phases are gathered at the grain boundary of 3D perovskite, which is extremely beneficial for inhibiting ion migration, passivating the defects, and improving the stability against water and oxygen. This study provides an improved method to combine the advantages of 2D and 3D perovskites. 



240 Joule 6, 240–257, January 19, 2022 ª 2021 Published by Elsevier Inc. 

**ll** 

##### Article 

promoting the favorable facet orientations of perovskite, and inhibiting or even completely eliminating those undesired facet orientations is vital to more directly and fundamentally improve the optoelectronic properties of perovskite and its related devices. 

However, manipulating facet orientation is quite difficult due to the ionic nature and fast crystallinity of solution-processed perovskite. Recently, facet orientation control has been achieved to a certain extent through monovalent cation cascade doping<sup>13</sup> and formamidinium doping in methylammonium-dominated perovskite.<sup>12</sup> Later, the surface-anchoring alkylamine ligands were introduced to raise (001) and (002) facet orientations,<sup>9</sup> with little effect on other unfavorable facets orientation. Enhanced (001) and (002) facet orientations have been realized by solid-phase epitaxial growth and doping organic cations,<sup>15–18</sup> yet obtained moderate efficiency of PSCs. Therefore, managing the crystallization of perovskite for favorably manipulating the facet orientation and stack to drastically improve both the efficiency and stability of PSCs is still lacking. 

In this work, the highly oriented 2D Dion-Jacobson (DJ) phase perovskites (BDA)PbI4 (BDA is 1,4-butanediamine) are introduced to act as seeds for the heteroepitaxial growth of 3D perovskite, by using a two-step method for the first time. The 2D seeds are found to manage the growth kinetics and thus to favorably tailor the facet orientation of 3D perovskite. The desired (001) and (002) orientations are greatly promoted, while the unfavorable (111) orientation is completely inhibited in the final perovskite film. The synchrotron-radiation-based grazing-incidence wide-angle X-ray scattering (GIWAXS) results reveal that the seed-induced growth also optimizes the stacking mode of crystal facet, making it more conducive to the vertical transport of carriers. Moreover, the 2D phase is transformed into grain boundaries (GBs) in the resulted films, forming a type-I band alignment with 3D perovskite to passivate GB defects. As a result, the seed-induced growth boosted the power conversion efficiency (PCE) of PSCs from 21.03% to 23.95%, representing the highest efficiency of mixed-dimensional PSCs. More importantly, a high fill factor (FF) of 0.847 was achieved, corresponding to about 94% of the Shockley-Queisser limited FF. The unencapsulated PSCs exhibited markedly enhanced ambient and operational stability, retaining 93% of the initial PCE after 1,056 h of storage in ambient condition and 91% of their original PCE after 500 h of continuous AM1.5 illumination under maximum power point (MPP) tracking at 60<sup>�</sup> C. Furthermore, a flexible PSC with PCE of more than 20% is realized, and the photovoltaic performance of PSCs could also be greatly promoted when other DJ phase (3AMP)PbI4 perovskites acting as seeds, demonstrating the versatility and generality of our work. 

###### RESULTS AND DISCUSSION 

###### Favorable tailoring of facet orientation 

First, we performed density functional theory (DFT) calculations to reveal the dependence of trap density on different surface crystal facets, providing a rough theoretical guidance for the subsequent selection of favorable facet orientations. The theoretical calculation results (Note S1; Figure S1) indicated favorable facet orientations such as (001) and unfavorable facet orientations such as (111). This encouraged us to regulate the facet orientation of perovskite during film fabrication. Next, we introduced the highly oriented 2D DJ phase (BDA)PbI4 perovskites (Figure S2) into a PbI2 solution for two-step deposition to serve as seed crystals (see STAR Methods section), which expectedly acted as templates for the heteroepitaxial growth of 3D perovskite (FA0.75MA0.25PbI3). The particle size in a pure PbI2 solution is less than 

1State Key Laboratory for Mesoscopic Physics and Frontiers Science Center for Nano-Optoelectronics, School of Physics, Peking University, Beijing 100871, China 

2Shanghai Synchrotron Radiation Facility (SSRF), Zhangjiang Laboratory, Shanghai Advanced Research Institute, Chinese Academy of Sciences, Shanghai 201204, China 

3University of Chinese Academy of Sciences, Beijing 100049, China 

4Shanghai Institute of Applied Physics, Chinese Academy of Sciences, Shanghai 201800, China 5Peking University Yangtze Delta Institute of Optoelectronics, Nantong 226010, Jiangsu, China 

6Collaborative Innovation Center of Quantum Matter, Beijing 100084, China 

7Lead contact 

*Correspondence: zhaoqing@pku.edu.cn https://doi.org/10.1016/j.joule.2021.12.006 

Joule 6, 240–257, January 19, 2022 241 

**ll** 

Article 



Figure 1. Favorable tailoring of facet orientation 

(A) Dynamic light scattering spectra of the PbI 2 solution, seed solution, and PbI2 solution with 1.9 mol % seed 

(B and C) X-ray diffraction (XRD) patterns and different peaks intensity ratio of perovskite films with varied seed concentrations. (D–H) Pole figure measurements along the (002) facet orientation with different seed concentrations. (D) Control. (E) 0.3 mol %. (F) 0.6 mol %. (G) 1.0 mol %. (H) 1.9 mol %. 

(I) XRD rocking curves of perovskite films with different seed concentrations. The rocking curve can only characterize the orientation of crystal facet but cannot reflect the crystal grain size. 

(J) Integrated GIWAXS intensity plots azimuthally along the ring at qxy=10 nm<sup>�1</sup> . 

(K) Possible (001) facet stacking mode in TDS film. 

(L) Possible (001) facet stacking mode in control film. 

10 nm, based on dynamic light scattering characterization (Figure 1A). After introducing 1.9 mol % 2D seed crystal colloidal solution (the sample with seed concentration of 1.9 mol % is labeled as TDS [tailoring facet orientation via DJ phase seed] in all the following descriptions) into the PbI2 solution, the characteristic particle size of several hundred nm could be observed, confirming that the seeds still maintain the colloidal properties in the PbI2 solution.<sup>19</sup> In addition, the seeds are also well maintained in PbI2 films (Figures S2 and S3). Before the introduction of seeds, PbI2 shows typical needle-like morphology in scanning electron microscopy (SEM) images (Figures S4A and S4B), consistent with recent reports.<sup>20</sup> After introducing 1.9 mol % seeds, it could be found that some bright substances are evenly distributed in the PbI2 thin film (Figures S4C and S4D). In order to identify whether they were seeds, we increased the concentration of seeds to 10 mol % and found that the density of the evenly distributed bright substances increased significantly 

242 Joule 6, 240–257, January 19, 2022 

**ll** 

##### Article 

(Figures S4E and S4F). Moreover, they do have the sheet-like structure (enlarged view in Figure S4F) and are similar to the morphology of pure seeds (Figure S4G). Therefore, we can reasonably conclude that these bright substances are the introduced seeds.<sup>21</sup> It can be observed intuitively that seeds are evenly distributed in the PbI2 thin film. 

Subsequently, the organic salt solution containing formamidinium iodide (FAI), methylammonium iodide (MAI), and methylammonium chloride (MACl) in IPA was spin-coated on the PbI2 film with 2D seeds; it should be noted that the seeds will not be damaged or dissolved by the IPA solution (Figure S3). The final 3D perovskite films were obtained after annealing at 150<sup>�</sup> C for 15 min. The grain size was found to be around 1.3 mm in the TDS sample due to the introduction of seed (Figure S5),<sup>22–27</sup> substantially larger than that of the control sample, which is desirable for better photoelectric properties.<sup>23,24</sup> Moreover, due to the hydrophobicity of the introduced seed crystal,<sup>28–32</sup> the water contact angle increases with the increase of seed concentration (Figure S6), in favor of the device stability on resisting humidity. In addition, compared with the control film, I 3d and Pb 4f peaks of the TDS film in X-ray photoelectron spectroscopy (XPS) characterization exhibit obvious shifts (Figure S7), signifying the changed chemical bonding of the I and Pb atoms after introducing the seed crystals.<sup>33</sup> 

To assess the effect of seed crystals on facet orientation, the perovskite films prepared on glass/indium tin oxide (ITO)/SnO2 with different seed concentrations were first characterized by X-ray diffraction (XRD) (Figure 1B). First, it can be found that the control perovskite film shows strong PbI2 signal (12.6<sup>�</sup> ) and multiple perovskite diffraction peaks, consistent with previous reports.<sup>34</sup> The most impressive characteristic of the XRD pattern of the seed-included film is the dramatically promoted (001) and (002) facet orientations as the seed concentration gradually increases. In sharp contrast, PbI2 signal and the undesired (111) facet orientation are suppressed and eventually disappeared. When the seed concentration increases to 1.9 mol %, the XRD pattern is dominated by diffraction peaks from favorable perovskite (001) and (002) planes, indicating a superior crystal quality. XRD results directly demonstrate the capability of 2D seed in regulating the facet orientation of 3D perovskite. More intuitively (as shown in Figure 1C), with the increase of seed concentrations, the intensity ratios of PbI2 to the perovskite (001) facet orientation and (111) to (001) facet orientation gradually decrease to zero. The intensity ratio of the (002) to (001) facet orientation remains almost unchanged, indicating that favorable (001) and (002) facet orientations have been strongly promoted, while PbI2 and perovskite (111) planes are obviously suppressed. 

To further investigate the orientation of the seed-induced perovskite films, the rocking curve measurement was performed on the (001) facet in perovskite films with different seed concentrations (Figure 1I). The rocking curve is a reliable technology to characterize the average orientation of a particular crystallographic phase.<sup>16</sup> The deviation between the crystallographic grains and their average orientation could be directly reflected by the full width at half-maximum (FWHM) of the corresponding rocking curve (u scan). For example, the FHWM is undefined for the absolutely random grain orientation in polycrystalline film within instrument resolution limit. For a single crystal with perfect orientation, the FHWM of rocking curve will be zero.<sup>16</sup> Here, the FWHM of rocking curve decreased prominently with the increased seed concentration (the inset in Figure 1I), which indicates a greatly enhanced (001) facet orientation. This once again confirmed the critical role of 2D seed in tailoring the facet orientation. To further investigate the facet orientation induced by seed, 

Joule 6, 240–257, January 19, 2022 243 

**ll** 

Article 

the pole figure measurements along the (002) facet orientation were implemented (Figures 1F–1H), in which the more concentrated diffraction signal at the center of the circle indicates a stronger preferred orientation.<sup>15</sup> The introduction of seed dramatically promotes the orientation of (002) facet, and an extremely concentrated diffraction signal is clearly visible in the sample with 1.9 mol % seed concentration (Figure 1H). 

The facet stacking mode is essential for carrier transport in perovskite films (Note S2), and the relatively low efficiency of mixed-dimensional perovskite can be ascribed to the suppressed vertical transport of carriers by insulating spacer cations.<sup>16</sup> The synchrotron radiation GIWAXS measurement could precisely detect the facet stacking mode,<sup>13</sup> and it was conducted on the control and TDS films (Figure S8). We integrated the GIWAXS pattern azimuthally over the ring at qxy = 10 nm<sup>�1</sup> (Figure 1J), which is assigned to (001) facet,<sup>12</sup> and the q is the scattering vector in reciprocal space.<sup>32</sup> For the control film, the diffraction ring shows two peaks at 35<sup>�</sup> and 145<sup>�</sup> , and the possible crystal stacking pattern is shown in Figure 1L.<sup>12</sup> Also, the peak intensity located at the 90<sup>�</sup> azimuth angle soars sharply in the TDS film, accompanied with the decreased intensities of the other two peaks (35<sup>�</sup> and 145<sup>�</sup> ) accordingly. This indicates that more (001) facets tend to stack parallel to the substrate (Figure 1K),<sup>13</sup> in favor of the vertical transport of carriers and the corresponding photovoltaic performance of PSCs (Note S2; Figure S9).<sup>12</sup> 

###### Understanding the mechanism of seed-induced growth 

First, the XRD characterization was performed on the perovskite precursor films (Figure S10). Interestingly, the undesired (111) facet orientation has disappeared in the TDS precursor film, and it can be reasonably inferred that the 2D seed begins to regulate the crystallization of the 3D perovskite in the nucleation stage,<sup>16</sup> consistent with previous reports.<sup>19,27</sup> The DJ phase perovskite was chosen as the seed because the diamine compounds with two amino groups at both ends can bond with<sup>4�</sup> octahedron at two sides,<sup>35,36</sup> which is more likely to provide nucleation sites for the highly oriented growth of 3D perovskite (Note S3; Figure S11). 

Crystal crystallization requires two processes: nucleation and growth. The kinetics of the seed-induced crystal growth can be explained by Gibbs free energy, which includes a surface term (Gs) and volume term (Gv).<sup>37</sup> Only when the crystal nucleus is larger than the critical radius r* can it grow spontaneously, otherwise, it will disintegrate spontaneously (Figure 2A).<sup>19</sup> In the control sample, the crystallization of perovskite will not occur until the critical Gibbs free energy barrier (G*) is completely overcome, as shown in region I of Figure 2B. Meanwhile, in the TDS film, the large seed crystals (more than 300 nm) already existed before the start of crystallization, which could directly serve as growth centers. Therefore, the nucleation stage is not required, and the film formation process can directly enter the growth stage (region II in Figure 2C). As a consequence, the seed-induced crystallization can commence immediately and preferentially, after covering with organic salts, at a much faster rate (Figure 2D).<sup>38</sup> The exposed divalent organic cations in the 2D seed crystal form bonds with the added 3D perovskite component, inducing the preferentially oriented growth (Figure 2D; Note S3). Moreover, according to the LaMer curve,<sup>39</sup> seed-induced crystallization will rapidly consume solute and significantly reduce solution concentration, which will in turn inhibit the random nucleation of the remaining 3D perovskite region without seeds, further making the seed-induced crystallization dominate, with the epitaxial growth around the seeds quickly covering the entire film. Note here that the subsequent 3D perovskite formation is epitaxially grown on the 2D seed template, and (BDA)PbI4 seed itself intrinsically has a highly 

244 Joule 6, 240–257, January 19, 2022 

**ll** 

##### Article 



Figure 2. Understanding the mechanism of seed-induced growth (A) Function relationship between total Gibbs free energy ( Gtot) and particle radius (r), in which Gtot includes surface term (Gs) and volume term (Gv), the gv and gs are the volume free energy per unit volume and surface free energy per unit area, respectively. (B) The Gtot as a function of r without seed. In this case, the crystallization of perovskite can only be triggered after overcoming the G* and obtaining a nucleus exceeding the r*. 

(C) The Gtot as a function of r with seed. In this case, seed crystals with a size larger than r* have been pre-formed in PbI2 film. Thus, the growth of perovskite can commence immediately and preferentially from the seed crystals. 

(D) Schematic diagram of 2D-seed-induced growth. 

(E) Schematic diagram of film growth without 2D seed. 

(F) The images of the PbI 2 film (with 2D seed) under CLSM at different reaction times after depositing organic salts 

(G) The images of the PbI 2 film (without 2D seed) under CLSM at different reaction times after depositing organic salts. 

Joule 6, 240–257, January 19, 2022 245 

**ll** 

Article 

oriented (00L) peak (Figure S13). Therefore, a highly oriented growth has been realized, and the resulting 3D perovskite film demonstrates dominant and very clean (001) and (002) peaks (Figure S13). Subsequently, multiple highly oriented crystal nuclei gradually grow up and merge with one another. Therefore, 2D (BDA)PbI4 perovskites can act as seeds to tailor the orientation of formed 3D perovskite films. However, the control film encountered random nucleation and had no preferential orientation (Figure 2E). As a result, the 3D perovskite film with highly (001) and (002) facet orientations and larger size (Note S4; Figure S14) were achieved due to the epitaxial growth of the pure (00L)-dominated 2D seeds. 

To further verify this inference, instead of pre-constructing the 2D phase in PbI2 as seeds, we dissolved the BDAI2, together with the organic salt, in IPA and then spincoated them onto pure PbI2 films (Figure S15), which is the traditional method to prepare 2D/3D perovskite.<sup>16,28,33</sup> However, we found that such a small amount of the 2D phase actually cannot regulate the crystal nucleation and tailor the facet orientation (Figure S15). This also highlights the importance and unique advantages of pre-constructing 2D seeds in the preparation of 2D/3D mixed-dimensional perovskite. 

To further study the effect of seed crystals on perovskite crystallization, a confocal laser scanning microscope (CLSM) was utilized to record the in situ transformation process from PbI2 to perovskite in real time. The pictures of the TDS and control films under CLSM at different reaction times are shown in Figures 2F and 2G, respectively (note that CLSM can only obtain grayscale images, and the colors of the pictures are pseudo color and do not represent the real PL color). Before the deposition of organic salts (t = 0 s), both the TDS (Figure 2F) and control (Figure 2G) films showed a green color (representing PbI2). After covering with organic salts, the PbI2 was expected to react with organic salts as time extends; thus, the green color gradually changed to orange-red and eventually disappeared completely. As shown in Figure 2F, the TDS sample shows remarkably faster crystallization. It takes about 7 s for the control sample to make PbI2 react with the organic salt completely (Figure 2G) because the G* must be overcome for successful nucleation. Meanwhile, 2D seeds enable the crystallization of perovskite to directly stride over the stage of nucleation in the TDS film; thus, it takes only about 4.5 s to make PbI2 react with the organic salt completely (Figure 2F). 

###### GB modification and optical characterization 

In order to further explore the distribution of 2D phase after completing the induced growth, transmission electron microscopy (TEM) was performed on the TDS film.<sup>40</sup> Two crystal grains can be clearly observed in Figure 3A and Figure 3B is an enlarged view of the white box in Figure 3A. The region 1 (grain interior) in Figure 3B was further magnified and analyzed by selected area electron diffraction (SAED), as shown in Figure 3C. The inter-planar spacing of 3.2 A<sup>˚</sup> is well matched with the (002) facet orientation of 3D perovskite (Table S1).<sup>18</sup> The region 2 (GB) in Figure 3B was also magnified and analyzed by SAED (Figure 3D), and the inter-planar spacing of 6.0 A<sup>˚</sup> originates from the (006) facet orientation of 2D phase (Table S1). Moreover, the diffraction pattern of the GB (inset in Figure 3D) is completely different from that of the grain interior (inset in Figure 3C). Therefore, significantly different from the usual 2D/3D mixed-dimensional perovskite, where the 2D phase is randomly distributed or inserted into the 3D perovskite lattice,<sup>33,41,42</sup> the 2D phase in our work is located at the GB, which was further proved by energy-dispersive spectroscopy (EDS) elemental line scan analysis (Figure S16). 

In order to further clarify the distribution of the 2D phase, the scanning Kelvin probe microscopy (SKPM) was conducted to investigate the surface potential of perovskite 

246 Joule 6, 240–257, January 19, 2022 

**ll** 

##### Article 



Figure 3. GB modification originated from 2D seed (A and B) TEM images of TDS sample, in which (B) is an enlarged view of the white box in (A). 

(C) The high-resolution TEM (HRTEM) image of the region 1 (grain interior) in (B). Inset: corresponding SAED pattern. 

(D) HRTEM image of the region 2 (grain interior) in (B). Inset: corresponding SAED pattern. 

(E) SKPM characterization of control film. 

(F) SKPM characterization of TDS film. 

(G) The diagram of band bending downward at GB in control film. 

- (H) The diagram of band bending upward at GB in TDS film. 

- (I) The TRPL of perovskite films with different seed concentrations. 

- (J) The CLSM PL mapping of control perovskite film. 

(K) The CLSM PL mapping of TDS perovskite film. Scale bar, 5 mm. 

films. The potential of the GB is higher than that of the grain interior in the control film (Figure 3E). Also, although the surface roughness is almost unaffected in the TDS film (Figure S17), the GB exhibits a lower potential than that inside the grains (Figure 3F), which is completely opposite to the situation of the control film. This phenomenon once again confirms that the 2D phase is distributed at the GB of 3D perovskite, and the possible mechanism is presented in Figure S18. The energy band will bend down at the GB in the control film (Figure 3G), attracting the 

Joule 6, 240–257, January 19, 2022 247 

**ll** 

Article 

electrons, but repelling holes.<sup>43,44</sup> Interestingly, this can be reversed by an upward bending of the energy band at the GB in the TDS film (Figure 3H), in favor of the interface extraction of holes and the FF improvement of PSCs.<sup>45</sup> In addition, this is also conducive to reducing the interface non-radiative recombination of carriers. Moreover, the type-I band alignment will be formed at GB between the 3D perovskite and the 2D phase, which can effectively passivate the GB<sup>46</sup> (Figure S19), where present the highest defect density.<sup>18</sup> As the entrance of water and oxygen and the essential area suffering from ion migration, the GB determines the quality of perovskite polycrystalline thin films. Therefore, the 2D phase with high stability located at the GB will help to get rid of the above shortcomings. Consequently, the 2D phase in the GB significantly augments the photovoltaic performance and stability of PSCs in many aspects. 

In general, a trade-off between efficiency and stability in mixed-dimensional PSCs has been reported, that is, the larger the proportion of the 2D phase in 3D perovskite, the better the stability of PSCs, but the efficiency will be weakened accordingly due to the low conductivity of the 2D phase.<sup>41</sup> Here, the 2D phase was introduced into 3D perovskite in a novel way for the first time, not only enabling a lesser amount of the 2D phase than that in usual mixed-dimensional PSCs<sup>42,47,48</sup> but also distributing the 2D phase at the GBs. Therefore, the weakening photoelectric properties caused by the 2D phase could be avoided effectively. Instead, due to the favorable distribution of the 2D phase and highly oriented high-quality 3D perovskite film with much larger grains, the photoelectric properties of the TDS films could be improved evidently. The PL spectrum reveals a marked increase in the luminescence intensity of perovskite films with the increase of seed concentrations with the same optical band gap (Figures S20 and S21). Moreover, the TDS film has a much longer carrier lifetime of 348 ns (Table S2) in the time-resolved photoluminescence (TRPL) characterization (Figure 3I), which is more than thirteen times longer than that of the control film with a carrier lifetime of 26 ns, implying much fewer deep-level defects in the TDS sample.<sup>49,50</sup> Further, the optical properties of perovskite films were visually investigated with the assistance of a home-built CLSM, which can clearly observe the luminescence of single perovskite crystal grains of control (Figure 3J) and TDS (Figure 3K) films. Evidently, the TDS film has larger crystal grains and significantly stronger single crystal grain luminescence, unambiguously indicating that the seed-induced growth enables much higher crystal quality and fewer defects in perovskite film. 

###### Photovoltaic performance of PSCs 

Seed-induced growth enhances the quality of perovskite films fundamentally, which encouraged us to further investigate its beneficial effects on photovoltaic devices. To quantify the electronic trap density (Nt) and electron mobility (m), the spacecharge-limited current (SCLC) technique was performed by constructing the electron-only devices (Figure S22). The calculated Nt is 4.6 3 1,015 cm<sup>�3</sup> for the control device, whereas the Nt of the TDS device (1.6 3 1,015 cm<sup>�3</sup> ) is only about one-third of that of the control device. The electron mobility of the TDS device is also dramatically improved by about seven times from 5.9 3 10<sup>�2</sup> to 3.9 3 10<sup>�1</sup> cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> due to the larger grains, longer carrier lifetime, and less trapping. 

PSCs were fabricated with the configuration of glass/ITO/SnO2/perovskite/spiroOMeTAD/Au (Figures 4A and S23A). To investigate the defect distribution in real PSCs, the well-established thermal admittance spectroscopy was carried out and the trap density of states (tDOS) as a function of energy-level depth was plotted in Figure 4B. The TDS device owns markedly lower defect density at almost entire energy-level depths. Moreover, electrochemical impedance spectroscopy reveals that 

248 Joule 6, 240–257, January 19, 2022 

**ll** 

##### Article 



Figure 4. Photovoltaic performance of PSCs (A) Schematic diagram of PSCs and 2D phases located at GBs. (B) The trap density of states as a function of trap depth. 

(C) The Nyquist plots of TDS and control PSCs. 

(D) Dark J-V curves of control and TDS PSCs 

(E) TPV carrier recombination lifetime of control and TDS. 

(F) J-V curves of control and TDS PSCs. 

Joule 6, 240–257, January 19, 2022 249 

**ll** 

Article 

###### Figure 4. Continued 

(G) EQE spectra and integrated photocurrent. 

(H) The statistical distributions of PCE. 

(I) Stabilized power output at the MPP voltage for 1,600 s. 

(J) Picture of flexible TDS PSC. 

(K) J-V curves of the flexible TDS PSC. 

the fitted recombination resistance is 691 U for control PSCs, while the recombination resistance was evidently enhanced to 894 U by seed-induced growth (Figure 4C), signifying an effectively suppressed carrier recombination. The dark current density-voltage (J-V) measurement also indicates that the TDS PSC owns an order of the magnitude lower dark current than the control PSC (Figure 4D). Furthermore, as an important factor to reflect the dominating recombination mechanism in PSCs, the ideality factor (m) of the control PSC is 1.84, indicating a rather serious ShockleyRead-Hall (SRH) recombination.<sup>51</sup> Also, the ideality factor is substantially reduced to 1.26 in the TDS PSC (Figure 4D), indicative of the direct bimolecular-dominated recombination. To gain more insight into the transient recombination dynamics, the charge recombination lifetime (trec) and charge transport lifetime (ttr) were extracted from the transient photovoltage (TPV) and transient photocurrent (TPC) measurements. Compared with the control PSC, the TDS PSC exhibits a faster photocurrent decay from 1,598 to 943 ns (Figure S24) but a slower photovoltage decay from 456 to 710 ns (Figure 4E), demonstrating the better carrier transport and suppressed carrier recombination in the TDS PSC. Therefore, seed-induced growth enabled a high-quality perovskite film, which was unambiguously confirmed by the above results from the device level. 

We further studied the effect of seed-induced growth on photovoltaic performance of the corresponding PSCs. The control PSC possesses a PCE of 21.03%, with a short circuit current density (JSC) of 24.20 mA/cm<sup>2</sup> , open-circuit voltage (VOC) of 1.06 V, and FF of 0.82. A satisfactory overall performance improvement of PSCs was realized in the TDS PSC with a Jsc of 24.80 mA/cm<sup>2</sup> , VOC of 1.14 V, FF of 0.847, and a much higher champion PCE of 23.95% (Table S3). Generally, the introduction of 2D perovskites will inevitably weaken the photoelectric properties of the 3D perovskites, especially the FF due to the low-conductive large cations. Fortunately, the 2D phase was distributed at the GB in our work, which avoided the sacrifice of photoelectric properties and instead vigorously improved the FF. Therefore, the highest FF of mixed-dimensional PSCs is achieved based on the 2D-seed-induced growth (Table S3). The seeds, with different n values (n = 1, 2, 3, and 4) were also used to prepare PSCs, and we found that the seed size had almost no obvious effect on the photovoltaic performance of PSCs (Figure S25). The external quantum efficiency (EQE) spectra (Figure 4G) indicated that the TDS PSC has better spectral response, and the integrated current densities are 24.3 and 24.0 mA/cm<sup>2</sup> for TDS and control PSCs, respectively. Moreover, the statistical distribution of the photovoltaic performance parameters shows that the TDS device has a significantly higher VOC, Jsc, FF, and PCE (Figures 4H and S26), definitely confirming the overwhelming superiority of the seed-induced growth. In addition, hysteresis is almost completely eliminated in the TDS PSC under forward and reverse scans (Figure S27) due to the suppressed ion migration (evidenced below). More importantly, there was no efficiency loss, but a slight increase was found for the unencapsulated TDS PSC after tracking the stabilized power output at MPP in air for 1,600 s (Figure 4I), reflecting the excellent device quality. 

The PSCs with different seed concentrations were also fabricated, and the photovoltaic performance parameters are shown in Figures S28 and S29 and Table S4. It was found that after the desired facet orientation tailoring has been achieved by 1.9 mol 

250 Joule 6, 240–257, January 19, 2022 

**ll** 

##### Article 



Figure 5. Stability characterization of PSCs 

(A) Storage stability of PSCs. 

(B) CLSM image of the control lateral structure device before applying electric field. 

(C) CLSM image of the control lateral structure device after applying electric field. (D) CLSM image of the TDS lateral structure device before applying electric field. (E) CLSM image of the TDS lateral structure device after applying electric field. (F) PSCs at MPP tracking under simulated AM1.5 illumination, 100 mW/cm<sup>2</sup> in nitrogen atmosphere at �60<sup>�</sup> C. 

% 2D phase, continuing to increase the amount of 2D phase reversely weakened the photovoltaic performance of PSCs due to the low conductivity of organic long-chain cations. We also only introduced BDAI2 into PbI2 to confirm that (BDA)PbI4 mainly affects the crystallization of perovskite and the subsequent improvement of photovoltaic performance rather than BDAI2 (Figure S30; Table S5).<sup>52</sup> To further investigate the generality of our method, another DJ phase perovskite (3AMP)PbI4 was also used as a seed to induce the growth of 3D perovskite. As shown in Figures S31–S33 and Table S4, the new 2D seed also achieved a favorable facet orientation tailoring and harvesting a high PCE of 23.32%. Moreover, our innovation is electron transport layer (ETL) compatible, and the champion PCE of 23.5% was also achieved (Voc = 1.13 V, Jsc = 24.85 mA/cm<sup>2</sup> , FF = 83.7%) based on TiO2 ETAl. (Figure S34), which firmly confirmed that our approach is a general strategy to obtain high-efficiency PSCs. Seed-induced growth can provide more uniform and better-quality perovskite films, which is desirable for flexible PSCs. The flexible PSC was further manufactured, and an excellent PCE of 20.07% was achieved (Figures 4J, 4K, and S23B), highlighting the versatility of our work.<sup>53,54</sup> 

###### Stability characterization of PSCs 

The higher crystal quality and the presence of 2D phase at the GB are expected to substantially enhance the stability of PSCs. The unencapsulated TDS PSC retained 

Joule 6, 240–257, January 19, 2022 251 

**ll** 

Article 

93% of its initial PCE after storage in ambient condition for 1,056 h under about 45% relative humidity (Figure 5A), while the PCE of the control PSC dropped drastically to 75% of its initial value during the same time period. Moreover, we tracked the evolution of their trap densities of states over time (Figure S35), and the overall defect density of the control PSC gradually increased as the storage time increased. However, in the TDS PSC, only shallow-level defects were increased, and the deep-level defects remained almost unchanged. We further utilized CLSM to in situ characterize the ion migration based on the lateral structure devices (Figures 5B–5E). A voltage of 15 V was applied on both sides of the channel with a width of 30 mm for 90 s, generating an electric field intensity of 0.5 V/mm, which is enough to initiate ion migration.<sup>55</sup> Ion migration requires medium defects; thus, significant PL quenching can be observed in the control device, due to the accumulation of defects under an electric field (Figure 5C).<sup>56</sup> In stark contrast, the defects in the TDS film were violently reduced, so the TDS device remained almost unchanged after the electric field was applied (Figure 5E), confirming that ion migration is greatly suppressed in TDS sample. More importantly, the operational stability of unencapsulated PSCs under MPP tracking with a continuous 1-sun irradiation (AM1.5G) in nitrogen atmosphere was investigated. It should be emphasized that in order to simulate the real operating environment, our operation stability characterization was carried out at about 60<sup>�</sup> C, which is more challenging than room temperature operations. The PCE of the control PSC dropped to 90% of its initial efficiency by tracking for only 48 h. Remarkably, the TDS PSC demonstrated a very prominent operational stability at 60<sup>�</sup> C by retaining 91% of its original PCE after MPP tracking for 500 h (Figure 5F). In summary, the above significantly improved stability can be attributed to (1) the significantly inhibited ion migration, (2) the intrinsically highly hydrophobic 2D phase with long-chain organics, thus fundamentally improving the resistance of perovskite to water, and (3) the higher film quality with larger grains, sharply reduced defect density, and denser films. 

###### CONCLUSION 

In summary, the favorable tailoring of facet orientation has been realized by introducing the highly oriented 2D perovskite (BDA)PbI4 as a seed to regulate the crystallization of 3D perovskite. The 2D seed optimizes the crystallization kinetics of 3D perovskite and makes its nucleation process directly stride over the G*, resulting in template-assisted growth. GIWAXS results analysis reveals that the seedinduced growth also manipulates the stack of perovskite crystal facet for better carrier transport. More importantly, the 2D phase in our work gathered at the GB of 3D perovskite after fulfilling the task of inducing oriented growth, and thus passivating the GB, inhibiting ion migration, and improving the stability against water and oxygen. The high-quality perovskite films enabled an overall remarkable improvement in photovoltaic parameters, and a PCE of 23.95% was achieved with a very high FF of 0.847, corresponding to about 94% of the Shockley-Queisser limited FF. Moreover, the efficient PSC retains 91% of its initial PCE after 500 h tracking at the MPP under simulated AM1.5 illumination at a high temperature (60<sup>�</sup> C). In addition, the flexible PSC with a PCE of more than 20% was obtained, indicating the versatility of 2D-seed-induced growth. Other DJ phase (3AMP)PbI4 seed has also proved to be useful in achieving facet orientation tailoring and photovoltaic efficiency improvement, demonstrating the universality and high repeatability of our method. This work demonstrated the unique role of seed-induced growth on preparing high-quality perovskite film, especially in facet orientation tailoring and facet stack optimization, GB modification, and stability enhancement. 

252 Joule 6, 240–257, January 19, 2022 

**ll** 

##### Article 

Furthermore, the better stability in traditional mixed-dimensional perovskite is due to the introduction of a large number of 2D phase, but at the cost of reducing efficiency. Our strategy makes 2D phase as the growth template of high-quality 3D perovskite, thus the proportion of 2D phase in 3D perovskite can be greatly reduced while maintaining significant stability and photoelectric properties enhancement. This novel way provides important guidance for solving the low efficiency of mixed-dimensional PSCs. 

###### EXPERIMENTAL PROCEDURES 

###### Resource availability 

Lead contact 

Further information and requests for resources should be directed to and will be fulfilled by the lead contact, Qing Zhao (zhaoqing@pku.edu.cn). 

Data and code availability 

This study did not generate any datasets. 

###### MATERIALS AVAILABILITY 

This study did not generate new unique reagents. 

###### MATERIALS 

PbI2 (super-dry beads, 99.999%), N,N-dimethylformamide (DMF, 99.8%), dimethyl sulfoxide (DMSO, 99.9%), acetonitrile (ACN, 99.9%), and IPA (99.7%) were purchased from Sigma-Aldrich. SnO2 colloid precursor was purchased from Alfa Aesar (Tin (IV) oxide, 15% in H2O colloidal dispersion), and lithium bis (trifluoromethanesulfonyl) imide and (Li-TFSI, 98%) also were bought from Alfa Aesar. 4-tert-butylpyridine (4-TBP, 96%) was obtained from Macklin. FAI, MACl, MAI, 2,2<sup>0</sup> ,7,7<sup>0</sup> -tetrakis (N, N-p-dimethoxy-phenylamino)-9,9<sup>0</sup> -spirobifluorene (spiro-OMeTAD, 99.8%), BDA, and 3-(aminomethyl) piperidinium (3amp) were purchased from Xi’an Polymer Light Technology Corporation. All the chemicals were used as received without further purification. 

###### Device fabrication 

The high-transparent glasses/ITO (z15 U sq<sup>�1</sup> ) with antireflective film were scrubbed vigorously with a dust-free cloth and cleaners, and then, they were cleaned by ultrasonic cleaner for 45 min using deionized water, acetone, and IPA, sequentially. The antireflection film is mainly composed of magnesium fluoride (MgF2), which was purchased from Shenzhen Shengyu Technology. The thickness of high-transparent ITO is about 140 nm, and its transmittance is about 95%. Before use, the ITO-coated glass was dried using a nitrogen gun and treated with 90 W plasma for 60 s to improve its wettability. Then, the SnO2 solution (2.67%, diluted with water) was spin-coated on the ITO at 3,000 rpm for 30 s and annealed in ambient air at 150<sup>�</sup> C for 30 min. 1.5 M PbI2 in DMF: DMSO = 9:1 was stirred for 1 h and filtered with a 0.22 mm polytetrafluoroethylene (PTFE) filter. As for the seed, 0.15 mmol PbI2 (69 mg) and 0.15 mmol BDAI2 (51.6 mg) were dissolved in 900-mL DMF and 100-mL DMSO solution; the mixed solution was then stirred at room temperature for 60 min and filtered with a 0.22 mm PTFE filter. Subsequently, the seed solution was added to the PbI2 solution with different molar ratios. After the films were cooled down to room temperature, 60-mL PbI2 solution containing 2D seeds was spin-coated on SnO2 at 1,500 rpm for 30 s and then annealed at 70<sup>�</sup> C for 1 min. Subsequently, 100 mL filtered organic salt solution containing FAI: MAI: MACl (90:6.4:9 mg in 1 ml IPA) was spin-coated on the room-temperature 

Joule 6, 240–257, January 19, 2022 253 

**ll** 

Article 

PbI2 films at 2,000 rpm for 30 s. It should be noted that once the organic salt solution is dripped onto the PbI2 films, the spin coater needs to be rotated immediately. Then, the films should be transferred from the glove box to the hot plate in the atmosphere (30%–40% humidity) as soon as possible (within about 35 s) for annealing at 150<sup>�</sup> C for 15 min. The mild moisture has a positive effect on the quality of perovskite film. It should be noted that both the PbI2 and organic salt solutions need to be fresh. Then, the mixed piro-OMeTAD solution, which was prepared by mixing 72.3-mg spiro-OMeTAD in 1-mL chlorobenzene, 28.8-mL 4-tertbutylpyridine solution, and 17.5-mL LiTFSI solution (520 mg mL<sup>�1</sup> in acetonitrile), respectively, was spin-casted on the surface of the perovskite films at 4,000 rpm for 30 s. After that, the films needed to be oxidized for 12 h in a drying cabinet with a relative humidity of 1%. Lastly, gold electrode was thermally evaporated with the thickness of about 100 nm at a low vacuum of 8 3 10<sup>�5</sup> Pa. The evaporation speed was 0.01 nm/s at the first 15 nm and 0.03 nm/s for the rest of the procedure. Then, the PSCs should be oxidized for 36 h in a drying cabinet with a relative humidity of 1% before characterization. 

###### Device characterization 

The J-V curves were performed in atmosphere using an Agilent B2900 Series precision source/measure unit with a scanning rate of 50 mV s<sup>�1</sup> (voltage step of 10 mV and delay time of 200 ms) from 1.20 to �0.01 V (reverse) or from �0.01 to 1.20 V (forward). The cells were illuminated by a Xeon lamp solar simulator (Solar IV-150A, Zolix) under AM 1.5G irradiation (100 mW cm<sup>�2</sup> ), which was calibrated by a Newport calibrated KG5-filtered Si reference cell. EQE and absorption spectrum measurement were performed on a solar cell QE/IPCE measurement system (Solar Cell Scan100, Zolix), which was calibrated by a certified silicon solar cell. The scan interval was 1 nm, and there was no bias light used during the measurement. The storage stability was characterized by placing the devices in a dark atmosphere and measuring the I-V curves. The operational stability test was measured under AM 1.5G white-LED solar simulator (VeraSol-2, AAA class, Newport) without the UV part and performed by setting the bias voltage to the initial MPP and tracing the current density. The TPV and TPC measurements were carried on a homemade system. To calculate the photocurrent density, we define the area using an aperture (0.0314 cm<sup>2</sup> ) placed on the glass side of the device to avoid overestimation of the photocurrent density. The cells were unencapsulated during all the tests. The impedance spectrum was measured by a potentiostat electrochemical workstation (AUT50690, PGSTAT204, the Netherlands) at different biases. The frequency ranges from 1 MHz to 0.01 Hz with 100 data points. The characteristic relaxation time was obtained by using RrecCrec. The Warburg impedance (Ws) was added to the equivalent circuit due to ion migration in perovskite, which is manifested as a semi-infinite circle at the low-frequency part (below 10 Hz).<sup>55</sup> The defect density was estimated from the frequency-dependent capacitance using the following equation<sup>19</sup> : 



<!-- Start of picture text -->
Ntðf Þ = � �Vbi � Vapp��qWkT 3 ðdC = df Þ 3 f<br><!-- End of picture text -->

where Vbi, W, and Vapp represents the build-in voltage, the width of the space charge region, and applied voltage, respectively. The frequency was converted from frequency to energy level of defects (Ea = Et � Ec/Ev), using thermal admittance spectroscopy. Then, we determined the defect distribution under different bias voltages as a function of energy level:<sup>57</sup> 



<!-- Start of picture text -->
NtðEaÞ = � �Vbi � Vapp��qWkT 3 ðdC = df Þ 3 f<br><!-- End of picture text -->

254 Joule 6, 240–257, January 19, 2022 

**ll** 

##### Article 

###### MATERIAL CHARACTERIZATION 

The crystal structure and phase composition were determined by the XPert Pro (Holland) X-ray diffract meter with Cu Ka1 radiation (l = 0.154 nm). The surface electronic states were investigated by the ultraviolet photoelectron spectroscopy (UPS, Axis Ultra, Kratos Analytical Ltd), and the non-monochromated He Ia (hn = 21.22 eV) was the photon source. The UV absorption spectrum were obtained by UV-2500 (Shimadzu corporation). In the TEM characterization, the perovskite films were scratched off from the substrate and then dispersed in hexane; they were treated with ultrasound for 10 min before dropping on a copper grid. The PL and TRPL were investigated at room temperature using a FLS980 (Edinburgh Instruments) spectrometer with a 450 W xenon lamp. The stability characterization of ion migration under light and electric field were performed on a homemade Olympus FV3000 CLSM system. The GIWAXS measurements were performed at BL14B1 beamline, Shanghai Synchrotron Radiation Facility (SSRF). The wavelength of the X-ray was 1.24 A<sup>˚</sup> (10 KeV), and an incidence angle of 0.5<sup>�</sup> was adopted together with an exposure time of 30 s. The diffraction patterns were collected using a 2D Mar225 detector. 

###### Computational methods 

The DFT calculations were performed in the Vienna Ab-initio Simulation Package code with the projector augmented wave (PAW). The slabs were separated by both top and bottom vacuum layers (�15 A<sup>˚</sup> ) to prevent spurious inter-slab interactions. We used the generalized gradient approximation Perdew-Burke-Ernzerhof (PBE) exchange-correlation functional. In the calculation of lattice optimization, the plane-wave basis set cutoffs of the wave functions were 500 eV for both bulk crystals and the slabs at the generalized gradient approximation (GGA)/PBE level. In the calculation, the k-point density was sampled by the Monkhorst and Pack method, the energy convergence limit was 10<sup>�5</sup> eV, the convergence standard of the atomic force was 0.01 eV/A<sup>˚</sup> , and the dispersion correction was considered in the calculation process. 

###### SUPPLEMENTAL INFORMATION 

Supplemental information can be found online at https://doi.org/10.1016/j.joule. 2021.12.006. 

###### ACKNOWLEDGMENTS 

This work is supported by the National Key Research and Development Program of China (no. 2019YFA0707003 and 2019YFE0114100), the National Natural Science Foundation of China (NSFC 51872007), and Beijing Municipal Natural Science Foundation (no. 7202094). We gratefully thank Prof. Qingbo Meng and Dr. Yiming Li from the Institute of Physics, Chinese Academy of Sciences (CAS), for TPV and TPC measurements. We gratefully acknowledge Ceshigo (http://www.ceshigo.com) for providing testing services. We also thank BL14B1 in Shanghai Synchrotron Radiation Facility for providing the beam time. 

###### AUTHOR CONTRIBUTIONS 

Q.Z. and C.L. conceived the idea and designed the experiments. C.L. and Y.Z. contributed to the fabrication of PSCs. G.Z. and X.G. provided the GIWAXS characterization and analysis. X.W. performed the physical characterizations of the devices and film microstructure analysis. F.G. synthesized the relevant chemicals. All authors were involved in the characterization of films and discussion of data analysis. Q.Z. and C.L. co-wrote the paper. 

Joule 6, 240–257, January 19, 2022 255 

#### **ll** 

Article 

###### DECLARATION OF INTERESTS 

The authors declare no competing interests. 

Received: August 22, 2021 Revised: October 4, 2021 Accepted: December 10, 2021 Published: January 6, 2022 

###### REFERENCES 

1. Yi, X.H., Zhang, Z.M., Chang, A.L., Mao, Y.C., halide perovskite solar absorber. ACS Energy Luan, Y.G., Lin, T., Wei, Y.Z., Zhang, Y.Y., Wang, Lett 3, 2663–2668. F.Y., Cao, S.K., et al. (2019). Incorporating CsF into the PbI2 film for stable mixed cation-halide 11. Kim, D.H., Park, J., Li, Z., Yang, M.J., Park, J.S., perovskite solar cells. Adv. Energy Mater. 9, Park, I.J., Kim, J.Y., Berry, J.J., Rumbles, G., and 1901726. Zhu, K. (2017). 300% enhancement of carrier mobility in uniaxial-oriented perovskite films 

2. Zhang, H.K., Qin, M.C., Chen, Z.L., Yu, W., Ren, formed by topotactic-oriented attachment. Z.W., Liu, K., Huang, J.M., Zhang, Y.K., Liang, Adv. Mater. 29, 28417505. 

2. Zhang, H.K., Qin, M.C., Chen, Z.L., Yu, W., Ren, Z.W., Liu, K., Huang, J.M., Zhang, Y.K., Liang, Q., Chandran, H.T., et al. (2021). Bottom-up quasi-epitaxial growth of hybrid perovskite from solution process-achieving highefficiency solar cells via template-Guided crystallization. Adv. Mater. 33, e2100009. 

   12. Xu, Z.Q., Liu, Z.H., Li, N.X., Tang, G., Zheng, G.H.J., Zhu, C., Chen, Y.H., Wang, L.G., Huang, Y., Li, L., et al. (2019). A thermodynamically favored crystal orientation in mixed formamidinium/methylammonium perovskite for efficient solar cells. Adv. Mater. 31, e1900390. 

3. Yang, W.S., Noh, J.H., Jeon, N.J., Kim, Y.C., Ryu, S., Seo, J., and Seok, S.I. (2015). SOLAR CELLS. High-performance photovoltaic perovskite layers fabricated through intramolecular exchange. Science 348, 1234– 1237. 

   13. Zheng, G.H.J., Zhu, C., Ma, J.Y., Zhang, X.N., Tang, G., Li, R.G., Chen, Y.H., Li, L., Hu, J.S., Hong, J.W., et al. (2018). Manipulation of facet orientation in hybrid perovskite polycrystalline films by cation cascade. Nat. Commun. 9, 2793. 

4. Bi, E.B., Tang, W.T., Chen, H., Wang, Y.B., Barbaud, J., Wu, T.H., Kong, W.Y., Tu, P., Zhu, H., Zeng, X., et al. (2019). Efficient perovskite solar cell modules with high stability enabled by iodide diffusion barriers. Joule 3, 2748– 2760. 

   14. Leblebici, S.Y., Leppert, L., Li, Y., Reyes-Lillo, S.E., Wickenburg, S., Wong, E., Lee, J., Melli, M., Ziegler, D., Angell, D.K., et al. (2016). Facetdependent photovoltaic efficiency variations in single grains of hybrid halide perovskite. Nat. Energy 1, 16093. 

5. Wu, T.H., Qin, Z.Z., Wang, Y.B., Wu, Y.Z., Chen, W., Zhang, S.F., Cai, M.L., Dai, S.Y., Zhang, J., Liu, J., et al. (2021). The main progress of perovskite solar cells in 2020–2021. Nanomicro. Lett. 13, 152. 

   15. Lee, J.-W., Tan, S., Han, T.-H., Wang, R., Zhang, L.Z., Park, C., Yoon, M., Choi, C., Xu, M.J., Liao, M.E., et al. (2020). Solid-phase hetero epitaxial growth of alpha-phase formamidinium perovskite. Nat. Commun. 11, 5514. 

6. Li, W., Rothmann, M.U., Zhu, Y., Chen, W.J., Yang, C.Q., Yuan, Y.B., Choo, Y.Y., Wen, X.M., Cheng, Y.-B., Bach, U., and Etheridge, J. (2021). The critical role of composition-dependent intragrain planar defects in the performance of MA1-xFAxPbI3 perovskite solar cells. Nat. Energy 6, 624–632. 

   16. Wang, Z.P., Lin, Q.Q., Chmiel, F.P., Sakai, N., Herz, L.M., and Snaith, H.J. (2017). Efficient ambient-air-stable solar cells with 2D-3D heterostructured butylammonium-caesiumformamidinium lead halide perovskites. Nat. Energy 2, 17135. 

   17. Liu, Z., Meng, K., Wang, X., Qiao, Z., Xu, Q.F., Li, S.D., Cheng, L., Li, Z.M., and Chen, G. (2020). In situ observation of vapor-assisted 2D-3D heterostructure formation for stable and efficient perovskite solar cells. Nano Lett 20, 1296–1304. 

7. Zhang, L.L., Liu, Y., Ye, X., Han, Q.X., Ge, C., Cui, S.Y., Guo, Q., Zheng, X.X., Zhai, Z.J., and Tao, X.T. (2018). Exploring anisotropy on oriented wafers of MAPbBr3 crystals grown by controlled antisolvent diffusion. Cryst. Growth Des. 18, 6652–6660. 

   18. Lee, J.-W., Dai, Z.H., Han, T.-H., Choi, C., Chang, S.-Y., Lee, S.-J., De Marco, N., Zhao, H.X., Sun, P.Y., Huang, Y., and Yang, Y. (2018). 2D perovskite stabilized phase-pure formamidinium perovskite solar cells. Nat. Commun. 9, 3021. 

8. Kim, D., Yun, J.-H., Lyu, M.Q., Kim, J., Lim, S., Yun, J.S., Wang, L.Z., and Seidel, J. (2019). Probing facet-dependent surface defects in MAPbI3 perovskite single crystals. J. Phys. Chem. C 123, 14144–14151. 

9. Zheng, X.P., Hou, Y., Bao, C.X., Yin, J., Yuan, F.L., Huang, Z.R., Song, K.P., Liu, J.K., Troughton, J., Gasparini, N., et al. (2020). Managing grains and interfaces via ligand anchoring enables 22.3%-efficiency inverted perovskite solar cells. Nat. Energy 5, 131–140. 

   19. Zhao, Y.C., Tan, H.R., Yuan, H.F., Yang, Z.Y., Fan, J.Z., Kim, J., Voznyy, O., Gong, X.W., Quan, L.N., Tan, C.S., et al. (2018). Perovskite seeding growth of formamidinium-leadiodide-based perovskites for efficient and stable solar cells. Nat. Commun. 9, 1607. 

10. McKenna, K.P. (2018). Electronic properties of {111} twin boundaries in a mixed-ion lead 

20. Hui, W., Chao, L.F., Lu, H., Xia, F., Wei, Q., Su, Z.H., Niu, T.T., Tao, L., Du, B., Li, D.L., et al. 

(2021). Stabilizing black-phase formamidinium perovskite formation at room temperature and high humidity. Science 371, 1359–1364. 

21. Kim, Y.Y., Park, E.Y., Yang, T.Y., Noh, J.H., Shin, T.J., Jeon, N.J., and Seo, J. (2018). Fast twostep deposition of perovskite via mediator extraction treatment for large-area, highperformance perovskite solar cells. J. Mater. Chem. A 6, 12447–12454. 

22. Alharbi, E.A., Baumeler, T.P., Krishna, A., Alyamani, A.Y., Eickemeyer, F.T., Ouellette, O., Pan, L.F., Alghamdi, F.S., Wang, Z.W., Alotaibi, M.H., et al. (2021). Formation of highperformance multi-cation halide perovskites photovoltaics by d-CsPbI3/d-RbPbI3 seedassisted heterogeneous nucleation. Adv. Energy Mater. 11, 2003785. 

23. Li, S.-S., Chang, C.-H., Wang, Y.-C., Lin, C.-W., Wang, D.-Y., Lin, J.-C., Chen, C.-C., Sheu, H.-S., Chia, H.-C., Wu, W.-R., et al. (2016). Intermixing-seeded growth for highperformance planar heterojunction perovskite solar cells assisted by precursor-capped nanoparticles. Energy Environ. Sci. 9, 1282– 1289. 

24. Lin, C.-Y., Li, S.-S., Chang, J.-W., Chia, H.-C., Hsiao, Y.-Y., Su, C.-J., Lian, B.-J., Wen, C.-Y., Huang, S.-K., Wu, W.-R., et al. (2019). Unveiling the nanoparticle-seeded catalytic nucleation kinetics of perovskite solar cells by timeresolved GIXS. Adv. Funct. Mater. 29, 1902582. 

25. Hangoma, P.M., Shin, I., Yang, H.-S., Kim, D., Jung, Y.K., Lee, B.R., Kim, J.H., Kim, K.H., and Park, S.H. (2020). 2D perovskite seeding layer for efficient air-processable and stable planar perovskite solar cells. Adv. Funct. Mater. 30, 2003081. 

26. Zhu, W.D., Chai, W.M., Chen, D.D., Ma, J.X., Chen, D.Z., Xi, H., Zhang, J.C., Zhang, C.F., and Hao, Y. (2021). High-efficiency (>14%) and airstable carbon-based, all-inorganic CsPbI2Br perovskite solar cells through a top-seeded growth strategy. ACS Energy Lett 6, 1500– 1510. 

27. Sidhik, S., Li, W.B., Samani, M.H.K., Zhang, H., Wang, Y.F., Hoffman, J., Fehr, A.K., Wong, M.S., Katan, C., Even, J., et al. (2021). Memory seeds enable high structural phase purity in 2D perovskite films for high-efficiency devices. Adv. Mater. 33, e2007176. 

28. Zhou, T., Lai, H.T., Liu, T.T., Lu, D., Wan, X.J., Zhang, X.D., Liu, Y.S., and Chen, Y.S. (2019). Highly efficient and stable solar cells based on crystalline oriented 2D/3D hybrid perovskite. Adv. Mater. 31, e1901242. 

29. Wang, H., Chan, C.C.S., Chu, M., Xie, J.S., Zhao, S.H., Guo, X.L., Miao, Q., Wong, K.S., 

256 Joule 6, 240–257, January 19, 2022 

**ll** 

##### Article 

   - Yan, K.Y., and Xu, J.B. (2020). Interlayer cross39. Zeng, L.X., Chen, S., Forberich, K., Brabec, C.J., hybrid perovskite solar cells. Chem 7, 1903– linked 2D perovskite solar cell with uniform Mai, Y.H., and Guo, F. (2020). Controlling the 1916. phase distribution and increased exciton crystallization dynamics of photovoltaic coupling. Solar RRL 4, 1900578. perovskite layers on larger-area coatings. 49. Luo, C., Yan, C., Li, W., Chun, F.J., Xie, M.L., Energy Environ. Sci. 13, 4666–4690. Zhu, Z.H., Gao, Y., Guo, B.L., and Yang, W.Q. 

   - Zheng, Y.T., Niu, T.T., Qiu, J., Chao, L.F., Li, (2020). Ultrafast thermodynamic control for B.X., Yang, Y.G., Li, Q., Lin, C.Q., Gao, X.Y., 40. Luo, C., Li, W., Xiong, D., Fu, J., and Yang, W.Q. stable and efficient mixed halide perovskite Zhang, C.F., et al. (2019). Oriented and uniform (2019). Surface pre-optimization of a mixed nanocrystals. Adv. Funct. Mater. 30, 2000026. 

30. Zheng, Y.T., Niu, T.T., Qiu, J., Chao, L.F., Li, B.X., Yang, Y.G., Li, Q., Lin, C.Q., Gao, X.Y., Zhang, C.F., et al. (2019). Oriented and uniform distribution of Dion-Jacobson phase perovskites controlled by quantum well barrier thickness. Solar RRL 3, 1900090. 

   40. Luo, C., Li, W., Xiong, D., Fu, J., and Yang, W.Q. (2019). Surface pre-optimization of a mixed halide perovskite toward high photoluminescence quantum yield in the blue spectrum range. Nanoscale 11, 15206–15215. 11, 15206–15215., 15206–15215.. 

   - photoluminescence quantum yield in the blue 50. Luo, C., Li, W., Fu, J., and Yang, W.Q. (2019). spectrum range. Nanoscale 11, 15206–15215. 11, 15206–15215., 15206–15215.. Constructing gradient energy levels to promote exciton energy transfer for 

   - 41. Krishna, A., Gottis, S., Nazeeruddin, M.K., and photoluminescence controllability of allSauvage, F. (2019). Mixed dimensional 2D/3D inorganic perovskites and application in singlehybrid perovskite absorbers: the future of component WLEDs. Chem. Mater. 31, 5616– perovskite solar cells? Adv. Funct. Mater. 29, 5624. 1806482. 

31. Niu, T.T., Ren, H., Wu, B., Xia, Y.D., Xie, X.J., Yang, Y.G., Gao, X.Y., Chen, Y.H., and Huang, W. (2019). Reduced-dimensional perovskite enabled by organic diamine for efficient photovoltaics. J. Phys. Chem. Lett. 10, 2349– 2356. 

      51. He, T.W., Li, S.S., Jiang, Y.Z., Qin, C.C., Cui, M.H., Qiao, L., Xu, H.Y., Yang, J.E., Long, R., Wang, H.H., and Yuan, M.J. (2020). Reduceddimensional perovskite photovoltaics with homogeneous energy landscape. Nat. Commun. 11, 1672. 

   42. Yao, Q., Xue, Q.F., Li, Z.C., Zhang, K.C., Zhang, T., Li, N., Yang, S.H., Brabec, C.J., Yip, H.-L., and Cao, Y. (2020). Graded 2D/3D perovskite heterostructure for efficient and operationally stable MA-free perovskite solar cells. Adv. Mater. 32, e2000571. 

32. Li, F.Z., Zhang, J., Jo, S., Qin, M.C., Li, Z., Liu, T.T., Lu, X.H., Zhu, Z.L., and Jen, A.K.-Y. (2020). Vertical orientated Dion-Jacobson Quasi-2D perovskite film with improved photovoltaic performance and stability. Small Methods 4, 1900831. 

      52. Kim, D., Jung, H.J., Park, I.J., Larson, B.W., Dunfield, S.P., Xiao, C.X., Kim, J., Tong, J.H., Boonmongkolras, P., Ji, S.G., et al. (2020). Efficient, stable silicon tandem cells enabled by anion-engineered wide-bandgap perovskites. Science 368, 155–160. 

   43. Chen, Q., Zhou, H.P., Song, T.-B., Luo, S., Hong, Z.R., Duan, H.-S., Dou, L.T., Liu, Y.S., and Yang, Y. (2014). Controllable self-induced passivation of hybrid lead iodide perovskites toward high performance solar cells. Nano Lett 14, 4158–4163. 

33. Liu, T.T., Guo, J.H., Lu, D., Xu, Z.Y., Fu, Q., Zheng, N., Xie, Z.Q., Wan, X.J., Zhang, X.D., Liu, Y.S., and Chen, Y.S. (2021). Spacer engineering using aromatic formamidinium in 2D/3D hybrid perovskites for highly efficient solar cells. ACS Nano 15, 7811–7820. 

      53. Yang, L.K., Xiong, Q., Li, Y.B., Gao, P., Xu, B., Lin, H., Li, X., and Miyasaka, T. (2021). Artemisinin-passivated mixed-cation perovskite films for durable flexible perovskite solar cells with over 21% efficiency. J. Mater. Chem. A 9, 1574–1582. 

   44. Li, J.B., Chawla, V., and Clemens, B.M. (2012). Investigating the role of grain boundaries in CZTS and CZTSSe thin film solar cells with scanning probe microscopy. Adv. Mater. 24, 720–723. 

34. Jiang, Q., Zhao, Y., Zhang, X.W., Yang, X.L., Chen, Y., Chu, Z.M., Ye, Q.F., Li, X.X., Yin, Z.G., and You, J.B. (2019). Author correction: surface passivation of perovskite film for efficient solar cells. Nat. Photonics 13, 500. 

45. Li, N.X., Tao, S.X., Chen, Y.H., Niu, X.X., Onwudinanti, C.K., Hu, C., Qiu, Z.W., Xu, Z.Q., Zheng, G.H.J., Wang, L.G., et al. (2019). Cation and anion immobilization through chemical bonding enhancement with fluorides for stable halide perovskite solar cells. Nat. Energy 4, 408–415. 

   54. Chung, J., Shin, S.S., Hwang, K., Kim, G., Kim, K.W., Lee, D.S., Kim, W., Ma, B.S., Kim, Y.-K., Kim, T.S., and Seo, J. (2020). Record-efficiency flexible perovskite solar cell and module enabled by a porous-planar structure as an electron transport layer. Energy Environ. Sci. 13, 4854–4861. 

35. Ahmad, S., Fu, P., Yu, S.W., Yang, Q., Liu, X., Wang, X.C., Wang, X.L., Guo, X., and Li, C. (2019). Dion-Jacobson phase 2D layered perovskites for solar cells with ultrahigh stability. Joule 3, 794–806. 

36. Ke, W.J., Chen, C., Spanopoulos, I., Mao, L.L., Hadar, I., Li, X.T., Hoffman, J.M., Song, Z.N., Yan, Y.F., and Kanatzidis, M.G. (2020). Narrowbandgap mixed lead/tin-based 2D DionJacobson perovskites boost the performance of solar cells. J. Am. Chem. Soc. 142, 15049– 15057. 

46. Luo, C., Zhao, Y., Wang, X., Gao, F., and Zhao, Q. (2021). Self-induced Type-I band alignment at surface grain boundaries for highly efficient and stable perovskite solar cells. Adv. Mater. 33, e2103231. 

      55. Zhou, W.K., Chen, S.L., Zhao, Y.C., Li, Q., Zhao, Y., Fu, R., Yu, D.P., Gao, P., and Zhao, Q. (2019). Constructing CsPbBr3 cluster passivated-triple cation perovskite for highly efficient and operationally stable solar cells. Adv. Funct. Mater. 29, 1809180. 

   47. Liu, Y.H., Akin, S., Pan, L.F., Uchida, R., Arora, N., Mili�c, J.V., Hinderhofer, A., Schreiber, F., Uhl, A.R., Zakeeruddin, S.M., et al. (2019). Ultrahydrophobic 3D/2D fluoroarene bilayerbased water-resistant perovskite solar cells with efficiencies exceeding 22. Sci. Adv. 5, eaaw2543. 

37. Ummadisingu, A., Steier, L., Seo, J.-Y., Matsui, T., Abate, A., Tress, W., and Gra¨tzel, M. (2017). The effect of illumination on the formation of metal halide perovskite films. Nature 545, 208–212. 

   56. Bai, S., Da, P.M., Li, C., Wang, Z.P., Yuan, Z.C., Fu, F., Kawecki, M., Liu, X.J., Sakai, N., Wang, J.T.-W., et al. (2019). Planar perovskite solar cells with long-term stability using ionic liquid additives. Nature 571, 245–250. 

   57. Duan, H.-S., Zhou, H.P., Chen, Q., Sun, P.Y., Luo, S., Song, T.-B., Bob, B., and Yang, Y. (2015). The identification and characterization of defect states in hybrid organic-inorganic perovskite photovoltaics. Phys. Chem. Chem. Phys. 17, 112–116. 

38. Yang, W.S., Park, B.-W., Jung, E.H., Jeon, N.J., Kim, Y.C., Lee, D.U., Shin, S.S., Seo, J., Kim, E.K., Noh, J.H., and Seok, S.I. (2017). Iodide management in formamidinium-lead-halidebased perovskite layers for efficient solar cells. Science 356, 1376–1379. 

48. Sutanto, A.A., Caprioglio, P., Drigo, N., Hofstetter, Y.J., Garcia-Benito, I., Queloz, V.I.E., Neher, D., Nazeeruddin, M.K., Stolterfoht, M., Vaynzof, Y., and Grancini, G. (2021). 2D/3D perovskite engineering eliminates interfacial recombination losses in 

Joule 6, 240–257, January 19, 2022 257 

