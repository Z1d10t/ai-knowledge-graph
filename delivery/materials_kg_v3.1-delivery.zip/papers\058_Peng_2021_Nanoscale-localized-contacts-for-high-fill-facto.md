# Nanoscale localized contacts for high fill factors in polymer-passivated perovskite solar cells

| 字段 | 内容 |
|---|---|
| 期刊 | Science |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 308 |
| 作者 | Jun Peng, D. Walter, Yuhao Ren, M. Tebyetekerwa, Yiliang Wu, The Duong, Qiaoling Lin, Jun-Tao Li et al. |
| DOI | 10.1126/science.abb8687 |
| 源文件 | 058_Peng_2021_Nanoscale-localized-contacts-for-high-fill-facto.pdf |

---
Submitted Manuscript: Confidential 



# **Nanoscale localized contacts for high fill factors in polymer-passivated perovskite solar cells** 

5 

Jun Peng<sup>1</sup> *, Daniel Walter<sup>1</sup> *, Yuhao Ren<sup>2</sup> , Mike Tebyetekerwa<sup>1</sup> , Yiliang Wu<sup>1</sup> , The Duong<sup>1</sup> , Qiaoling Lin<sup>2</sup> , Juntao Li<sup>2†</sup> , Teng Lu<sup>3</sup> , Md Arafat Mahmud<sup>1</sup> , Olivier Lee Cheong Lem<sup>4</sup> , Shenyou Zhao<sup>1</sup> , Wenzhu Liu<sup>5</sup> , Yun Liu<sup>3</sup> , Heping Shen<sup>1</sup> , Li Li<sup>4</sup> , Felipe Kremer<sup>6</sup> , Hieu T. Nguyen<sup>1</sup> , DukYong Choi<sup>7</sup> , Klaus J. Weber<sup>1</sup> , Kylie R. Catchpole<sup>1†</sup> , Thomas P. White<sup>1†</sup> 

1Research School of Electrical, Energy and Materials Engineering, The Australian National University, ACT 2600, Australia. 

10 

2State Key Laboratory of Optoelectronics Materials and Technologies, School of Physics, Sun Yat-sen University, Guangzhou 510275, China. 

3Reseach School of Chemistry, The Australian National University, ACT 2600, Australia. 

4Australian National Fabrication Facility, Research School of Physics, The Australian National University, ACT 2600, Australia. 

15 

5Research Center for New Energy Technology, Shanghai Institute of Microsystem and Information Technology, Chinese Academy of Sciences, Jiading, Shanghai 201800, China. 

6Centre for Advanced Microscopy, The Australian National University, ACT, 2600, Australia. 

7Australian National Fabrication Facility, The Australian National University, ACT 2600, Australia. 

20 

*These authors contributed equally to this work. 

†Correspondence to: lijt3@mail.sysu.edu.cn (J.L.); kylie.catchpole@anu.edu.au (K.R.C.); thomas.white@anu.edu.au (T.P.W.) 

25 

## **ABSTRACT** 

Polymer passivation layers can improve the open-circuit voltage of perovskite solar cells when inserted at the perovskite – charge transport layer interfaces. Unfortunately, many such layers are poor conductors, leading to a trade-off between passivation quality (voltage) and series resistance (fill-factor). Here we introduce a nanopatterned electron transport layer that 1 

Submitted Manuscript: Confidential 



5 

overcomes this trade-off by modifying the spatial distribution of the passivation layer to form nanoscale localized charge transport pathways through an otherwise passivated interface, thereby providing both effective passivation and excellent charge extraction. By combining the nanopatterned electron transport layer with a dopant-free hole transport layer, we achieved a certified power conversion efficiency of 21.6% for a 1 square centime cell with a fill factor of 0.839, and demonstrate an encapsulated cell that retains ~91.7% of its initial efficiency after 1000 hours of damp-heat exposure. 

10 

15 

The rise in perovskite solar cell (PSC) performance has been marked by dramatic increases in open circuit voltage ( _Voc_ ), short-circuit current ( _Jsc_ ), and fill-factor (FF), as illustrated Fig. 1 for reported values since 2014 ( _1-9_ ). The steady increase in _Voc_ from ~1 to ~1.2 V (for simplicity we ignore bandgap differences between the record cells) reflects efforts to reduce nonradiative recombination, especially at the perovskite-charge transport layer interfaces ( _10-25_ ). For example, insertion of ultrathin passivation layers at one or both interfaces can lead to voltage gains of > 100 mV in some cases ( _11, 22_ ).  Reported passivation materials, include insulating ( _10-14_ ) and semiconducting organic materials ( _15-17_ ), inorganic dielectrics ( _18, 19_ ), and lowdimensional perovskites ( _20-25_ ). Insulating organic materials and low-dimensional perovskites have provided some of the largest efficiency gains. 

20 

25 

30 

Two other important trends can be seen in Fig. 1. First, the _Jsc_ of record cells has not increased substantially since 2015; a consequence of the near-unity internal quantum efficiency and low optical losses of state-of-the-art cells. Second, record FF values plateaued between 2015 and 2018, before a steep increase in 2019, despite the almost linear improvement in _Voc_ during the same period. Given that FF quantifies voltage and current losses at the maximum power point relative to the maximum values of both _V_ oc and _Jsc_ , the theoretical FF limit is a function of _Voc_ and depends both on the active layer bandgap and the rate of nonradiative recombination that degrades _Voc_ . In practice, however, many cells perform well below this limit because of parasitic resistive losses (shunt and series). Thus, achieving a very high FF requires low recombination losses (high _Voc_ ), smooth, uniform and dense active layers (high shunt resistance), and very efficient charge extraction and transport (low series resistance). The lack of correlation between _Voc_ and FF in Fig. 1 suggests that the FF of record cells is not limited by recombination but 

2 

Submitted Manuscript: Confidential 



rather by resistive losses. Indeed, the theoretical maximum FF for a solar cell with _Voc_ = 1.1 V is ~0.89, well above the highest values achieved so far. 

5 

10 

15 

Maximising both _Voc_ and FF is a challenge faced by all high efficiency solar cells due to the difficulties of reducing interface recombination without hindering charge extraction. This challenge is most apparent in the case of insulating and dielectric passivation layers that provide outstanding passivation of defects (for example SiO2 passivation layers in Si cells ( _26_ ), or poly(methyl methacrylate) (PMMA) passivation of perovskite cells ( _10_ )), but must be extremely thin to avoid detrimental FF losses from series resistance. As an extreme example, silicon solar cells with tunnel oxide passivated contacts can suffer a 70% drop in FF for a 5Å variation in oxide thickness ( _27_ ). There are many examples for PSCs showing trade-offs between passivation quality ( _Voc_ ) and FF, not only for ultrathin layers of insulating polymers such as polystyrene and PMMA ( _10-12_ ), but also for poorly-conducting low-dimensional perovskite passivation layers ( _20-25_ ). Overcoming this trade-off with new materials or device architectures could improve PSC performance. 

20 

A further challenge facing perovskite technology is maintaining high efficiency, and specifically FF, on larger cell areas ( _5, 6, 28, 29_ ). The record efficiencies quoted above are for very small cells (~0.1 cm<sup>2</sup> ) – at least three orders of magnitude smaller than commercial Si cells. Increasing cell area increases the possibility of shunts created by film imperfections, whereas series resistance losses scale quadratically with current. Both contributions can rapidly degrade FF as cell areas increase, with record 1-cm<sup>2</sup> cells typically exhibiting FF values between 5% and 10% lower than their smaller counterparts ( _5_ ). 

25 

30 

In this work, we present a PSC architecture where we replaced the commonly used mesoporous TiO2 (mp-TiO2) electron transport layer (ETL) by a sparse array of nanoscale TiO2 cylinders (nanorods). The resulting nanopatterned ETL/perovskite interface could be effectively passivated with an ultrathin polymer passivation layer to achieve high _Voc_ that maintained outstanding charge collection and interfacial transport properties, which resulted in low series resistance and a high FF.  This approach was demonstrated on a large-area (1 cm<sup>2</sup> ) cell with a certified efficiency of 21.6% and FF = 0.839. A champion small-area (~0.165 cm<sup>2</sup> ) cell achieved a PCE of 

3 

Submitted Manuscript: Confidential 

10 

15 

20 

25 



5 

~23.17% with _Voc_ = 1.240 V and FF = 0.845. We investigated and explained the performance of the nanostructured interface using three-dimensional (3D) numerical simulations that replicated accurately the FF enhancement and the observed experimental trends with nanopattern geometry. The simulations strongly suggested that the TiO2 nanorods are incompletely coated with the PMMA:PCBM (phenyl-C61-butyric acid methyl ester) passivation material, leaving exposed regions of local low-resistance contact directly analogous to local contact structures in high efficiency silicon solar cells ( _30, 31_ ). Detailed comparisons between simulation and experiment placed plausible bounds on the nanorod area fraction that was left exposed and the density of recombination-active defects at this exposed ETL-perovskite interface. In addition to the nanopatterned ETL, we also introduce here an ionic dopant-free, blended hole transport layer (HTL) that offers similar cell performance to doped alternatives such as Spiro-OMeTAD (2,2’,7,7’-tetrakis-( _N,N_ -di-4-methoxyphenylamino)-9,9’-spiro-bifluorene) and PTAA (poly(triaryl amine)), but with much improved thermal stability. Encapsulated cells incorporating the new ETL and HTL combination retained > 90% of their initial efficiency after 1000 hours of exposure to damp-heat conditions of 85<sup>o</sup> C and 85% relative humidity. 

30 

Spiro-OMeTAD and PTAA are the most widely used HTL materials for high efficiency n-i-p architecture PSCs. These layers are typically doped with bis(trifluoromethane)sulfonamide lithium salt (Li-TFSI) to improve the conductivity, but the hygroscopic Li-TFSI can accelerate moisture-induced perovskite degradation, and diffusion of Li ions throughout the cell further reduces performance and stability ( _6, 32, 33_ ). These detrimental effects are exacerbated by high temperatures, contributing to the poor thermal stability of many perovskite cells.  Alternative HTL layers that offer similar efficiency performance without impacting stability include poly(3hexylthiophene) (P3HT), a semiconducting polymer used extensively in organic optoelectronics but only recently reported as an effective HTL for perovskite solar cells ( _6, 34, 35_ ). Controlling the morphology and crystallinity of the P3HT film is essential for achieving a high charge carrier mobility without dopants. The hole mobility can range from ~10<sup>-5</sup> cm<sup>2</sup> V<sup>-1</sup> s<sup>-1</sup> in an amorphous film up to ~0.1 cm<sup>2</sup> V<sup>-1</sup> s<sup>-1</sup> for a crystalline film with optimized π-π stacking of the polymer side chains ( _6, 35_ ). We show that blending P3HT with another thermally stable HTL material, copper phthalocyanine (CuPc), followed by a post-deposition solvent-annealing step, produced highly crystalline films with excellent hole transport characteristics. 

4 

Submitted Manuscript: Confidential 

25 



5 

10 

Details of the HTL optimization process and film characterization are provided in the supplementary materials (see fig. S1 to S6). To summarize the key results, x-ray diffraction (XRD) analysis revealed that applying a solvent annealing treatment with chlorobenzene to pure P3HT films improved crystallinity and conductivity compared to untreated films, and both properties were further improved by blending P3HT with CuPc (fig. S1). When incorporated into a baseline mp-TiO2 PSC process as a substitute for Spiro-OMeTAD (fig. S4 shows the device structure), the best results were obtained for a 10:1 (v/v) ratio blend of P3HT (12 mg/mL):CuPc (5 mg/mL) (fig. S5). The average FF for cells with the optimized P3HT:CuPc blend was 0.790 ± 0.016, compared to 0.728 ± 0.016 for as-deposited P3HT films, and the average PCE for the optimized cells was 20.83 ± 0.55% (fig. S6). This performance compared favorably to conventional mp-TiO2 based cells using Spiro-OMeTAD or PTAA as the HTL as reported previously ( _10, 12, 24, 25_ ). 

15 

20 

For electron extraction, the most widely used ETL configuration for n-i-p PSCs consists of a thin (~50 nm) compact TiO2 layer (c-TiO2), covered by a mp-TiO2 layer of typical thickness >100 nm. Dense random arrays of TiO2 nanowires grown by solution methods have also been explored as an alternative to mp-TiO2, but with negligible performance benefit ( _36-38_ ). The main role of the mp-TiO2 (or random nanowire array) layer is to provide a scaffold for the perovskite film to form a dense, pinhole-free film. These layers may also contribute to charge carrier collection, but the large contact area between the mp-TiO2 (or random nanowire array) and the perovskite can also result in substantial interface recombination. Hence, some form of passivation is required to achieve high voltages. A thin passivating interlayer of PMMA:PCBM can effectively increase the _Voc_ of mp-TiO2 based cells ( _10, 12, 39, 40_ ), but this layer must be ultrathin to limit resistive losses. 

30 

The average performance of mp-TiO2-based cells with the structure Glass/ITO/c-TiO2/mpTiO2/PMMA:PCBM/Cs0.05FA0.88MA0.07PbI2.56Br0.44/PMMA/P3HT:CuPc/Gold, where the ratio of PMMA:PCBM mixed precursor solution is 1:3 (w/w), is shown in Fig. 2, and replotted in fig. S6 for the optimized P3HT:CuPc blend discussed above (referred to as mp-TiO2 in the remainder of this work). Here ITO refers to indium-doped tin oxide, and MA and FA are methylammonium 

5 

Submitted Manuscript: Confidential 

10 



5 

and formamidinium, respectively. The band gap of the perovskite we used throughout was ~1.6 eV (figure S7). We also fabricated planar n-i-p cells with just the c-TiO2 ETL layer, omitting the mp-TiO2 layer altogether. Cell data are shown in Fig. 2 for planar cells fabricated with a solution-processed c-TiO2 layer (‘S-Planar’) and an atomic-layer deposition (ALD) c-TiO2 layer (‘A-Planar’), with all other layers identical to the mp-TiO2 cell.  Note that the average _Voc_ of the planar cells is slightly higher than that of the mp-TiO2 cells (Fig. 2C), and likely the result of smaller interface area over which recombination can occur. The reduced FF in the planar c-TiO2 case (Fig. 2E), however, is likely the result of a more uniform passivation layer compared to the meso-TiO2 ETL. The higher FF of the mp-TiO2 may result from partial or non-uniform coverage of the passivating layer on the textured ETL surface that has thinner regions with more efficient charge conduction through an otherwise poorly conducting film. 

15 

20 

25 

Comparison between the planar c-TiO2 and the mp-TiO2 ETL interfaces suggested that there exists a tradeoff between _Voc_ and FF, mediated by the continuity of coverage of the passivation layer. Based on this finding, we developed a nanopatterned ETL consisting of an array of TiO2 nanorods on a planar c-TiO2 layer. This optimized texture enables the high _Voc_ of the planar architecture while providing efficient charge extraction and hence high FF. The ETL fabrication process is illustrated in fig. S8. Starting with a Glass/ITO/c-TiO2 substrate, we first deposited a PMMA resist layer by spin coating, followed by a 15 min annealing step. The nanorod array was defined in the resist using electron-beam lithography (EBL) and the pattern was developed in a solution of methyl isobutyl ketone (MIBK) and isopropyl alcohol (IPA). The entire sample was then coated with an ALD-deposited conformal TiO2 layer that filled the holes in the PMMA resist and covered the resist between the holes. Finally, the TiO2 capping layer was etched with inductively coupled plasma-reactive ion etching (ICP-RIE) until the resist surface was exposed, and the remaining resist was removed by oxygen plasma. After etching, the TiO2 nanorod substrates were annealed at 500<sup>o</sup> C for 30 min under dry air before further processing, converting the as-deposited amorphous TiO2 into a nanocrystalline anatase material. 

30 

Although the diameter, pitch (spacing), and height of the nanorods could all influence the cell performance, we set the diameter to 50 nm and height to 200 nm and focused on investigating the impact of pitch. This approach was motivated by device simulations (described below) that 

6 

Submitted Manuscript: Confidential 



5 

predicted the largest changes in device performance through modification of local contact spacing. Figures S9 and S10 show the nanopatterned TiO2 ETL with pitches of 300, 600, and 1000 nm (labelled as ‘300 nm’, ‘600 nm’ and ‘1000 nm’, respectively). The nanopatterned perovskite cell structure was ITO/c-TiO2/TiO2 nanorods/PMMA:PCBM/Cs0.05FA0.88MA0.07PbI2.56Br0.44/PMMA/P3HT:CuPc/Gold (Figs. 2A and 2B). 

10 

15 

To evaluate the performance enhancement provided by the nanopatterned ETL, we compare in Fig. 2 the nanopatterned cells with different pitches to three control cell architectures, namely, mp-TiO2, A-Planar, and S-Planar. The two different planar cell types were included to compare the solution and ALD-deposited materials because the nanorods were ALD-deposited and both compact layers for the mp-TiO2 and nanopatterned cells were solution-deposited; the deposition method had negligible impact on the cell performance. All of the cells include double-side passivation with ultrathin films of PMMA and PMMA:PCBM blends at the perovskite/HTL and perovskite/ETL interfaces respectively ( _10, 11_ ). 

20 

All six cell architectures demonstrated excellent surface passivation quality (Fig. 2C), with an average _Voc_ > 1.2 V and maximum _Voc_ ~1.24 V. The nanopatterned cells achieved equivalent _Voc_ s to the planar cells for 300, 600 and 1000 nm nanorod pitches, with average _Voc_ of 1.217 ± 0.015 V, 1.218 ± 0.017 V and 1.218 ± 0.018 V, respectively, showing that the nanorods did not affect the passivation quality compared to planar cells. Also, _Jsc_ was similar for all six cell architectures (Fig. 2D) with average values ranging from 21.73 ± 0.19 mA/cm<sup>2</sup> (A-Planar) to 21.85 ± 0.17 mA/cm<sup>2</sup> (300 nm). 

25 

30 

A comparison of representative current-voltage ( _J-V_ ) curves for planar and nanopatterned cells shows that the FF increase with nanorods was dominated by reduced series resistance (Fig. 3A). The planar cells had the lowest average FFs of 0.741 ± 0.017 (S-Planar) and 0.739 ± 0.013 (APlanar), whereas the mp-TiO2 cells had a FF=0.790 ± 0.017 (Fig. 2E).  In contrast, the optimum nanopatterned cells with 300 nm pitch had an average FF = 0.824 ± 0.012, which decreased to 0.803 ± 0.015 for 600 nm pitch and 0.789 ± 0.013 for 1000 nm pitch. The 300 nm pitch nanopatterned cells has an average PCE of 21.91 ± 0.57 %, compared to 19.64 ± 0.55% (19.54 ± 

7 

Submitted Manuscript: Confidential 



0.56%) for the S-Planar (A-Planar) cells and 20.83 ± 0.55% for the mp-TiO2 cells (Fig. 2F). The best-performing nanopatterned cell has a PCE of 23.17% with _Voc_ = 1.240 V and FF = 0.845; (figure S11). 

5 

10 

15 

20 

There are several possible explanations for the combination of outstanding passivation ( _Voc_ ) and charge extraction/transport (FF) provided by the nanopatterned ETL, including: (i) Improvements in the optoelectronic quality of the perovskite film when it is deposited on the nanopatterned substrate; (ii) modification of the passivation layer coverage and/or thickness at the ETL/perovskite interface resulting in an improved balance of passivation and charge transport across the interface; and (iii) improved charge collection and interface transport caused by the geometry of the nanorods. For possibility (i), the nanorods could scaffold the growth of the perovskite film, but we found no evidence of morphology changes from scanning electron microscope (SEM) images of perovskite films deposited on planar, nanopatterned and mp-TiO2 ETLs (fig. S12), nor appreciable differences in crystal structure, orientation or crystallinity from XRD measurements of films on the different substrates (fig. S13). Photoluminescence (steadystate and time-resolved) measurements of films deposited on the different ETL structures were consistent with the experimental cell _Voc_ values: the planar and nanopatterned cells showed almost identical steady-state intensity and PL decay curves, whereas the mp-TiO2 sample had a slightly lower PL intensity and faster decay, indicating increased recombination losses (fig. S14). Thus, the nanopatterned ETL had minimal impact on the physical and optoelectronic properties of the perovskite film. 

25 

30 

To test explanations (ii) and (iii) above, we developed a full 3D numerical drift-diffusion model of the n-i-p perovskite solar cell including the periodic nanostructured TiO2 nanorods (figs. S15). The resistive PMMA:PCBM layer at the perovskite-TiO2 interface was introduced in the model as a 3 nm-thick insulating interlayer. The valence and conduction band energy levels of this interlayer are aligned to those of the perovskite and ETL, respectively, to avoid introducing energy barriers to charge transport. Bulk conductivity of the layer was reduced to match the FF of the S-Planar control samples. Nonradiative recombination at this interface and in the perovskite bulk was modelled with generalized Shockley-Read Hall statistics ( _41_ ), parameterized by self-consistent time-resolved fitting to TRPL data measured for a bare perovskite film on 

8 

Submitted Manuscript: Confidential 

15 



glass, and a perovskite film deposited on a planar Glass/ITO/TiO2/PMMA:PCBM substrate (fig. S16). 

5 

10 

From these fits, we extracted a bulk perovskite defect density of 2 × 10<sup>14</sup> cm<sup>-3</sup> for an effective electron lifetime of ~ 600 ns. This value corresponds well with recent results from Ni _et al._ ( _42_ ) who extracted bulk defect concentrations of ~10<sup>14</sup> -10<sup>15</sup> cm<sup>-3</sup> in a range of multicrystalline perovskite films from independent capacitance-based techniques. We fit a charge-carrier mobility of 0.5 cm<sup>2</sup> /V·s for a corresponding diffusion length of ~ 900 nm at 1 Sun-equivalent injection levels (fig. S17). The fitted surface areal defect density at the PMMA:PCBMpassivated interface was 5 × 10<sup>8</sup> cm<sup>-2</sup> , for an equivalent surface-recombination velocity of only 3 cm/s, indicative of the high quality passivation achieved with this method. These parameters were integrated into the full three-dimensional cell simulations, predicting _V_ oc and FF consistent with experiment (fig. S18). Details of the TRPL and cell models, and associated simulation parameters are provided in the Supplementary Materials. 

20 

With this model, we initially tested possibility (iii), which presumed that the TiO2 nanorods increased the effective surface area of the ETL and reduced resistance. Our simulations showed that if the TiO2 nanorod was conformally coated by the passivation interlayer, the increased surface area could not account for the enhancement in FF (fig. S19), and actually led to a marginal decrease in _Voc_ (-8 mV) and FF (-0.08%) for the 300 nm vs the S-Planar cell due to the increase in surface area at which non-radiative recombination can occur. FF did not increase since collection efficiency in the perovskite bulk was near-unity as the predicted charge carrier diffusion lengths (900 nm) are more than double the absorber thickness of 400 nm. 

25 

30 

For possibility (ii), we presumed that the nanostructure influenced conformity of the PMMA:PCBM layer across the TiO2-perovskite interface, which was deposited from solution by spin-coating. Some faces of the nanostructured rods likely had thinner or noncontinuous layers of PMMA:PCBM or both, for example, at the radially outward or top faces of the rod. We represented this schematically in the inset figure of Fig 3B. The uniformity of PMMA:PCBM at the TiO2 nanorods could not be observed given the PMMA:PCBM film was <3 nm thick and offered insufficient contrast to observe with electron microscopy. Instead, we simulated 

9 

Submitted Manuscript: Confidential 

25 



5 

imperfect PMMA:PCBM coverage by assuming a coverage fraction (CF) of 30 % of the TiO2 nanorod sidewalls, and presumed that the bare TiO2:perovskite interface had a defect density one order of magnitude higher than the passivated surface at 5 × 10<sup>9</sup> cm<sup>-2</sup> . Discussion of these assumptions is presented in supplementary information. Under these conditions, we found close agreement between simulation and experiment for both the magnitude of the FF change between the S-Planar and 300 nm cases (Fig. 3B) and the change in FF with the nanorod pitch as indicated by the star markers in Fig. 2E. The corresponding _Voc_ is only marginally affected, and overall device efficiency was consistent with experiment (Fig. 2, C and F). 

10 

15 

20 

Our device simulations suggest that the formation of repeatable nanoscale regions of unpassivated nanorod TiO2/perovskite interface facilitate localized low-resistance charge transport with limited impact on effective interface recombination and _V_ OC. This localized contact structure approach is analogous to local-contact structures used in high efficiency laboratory and industrial silicon solar cells, in which local openings in electrically passivating and insulating dielectric layers are laser micromachined or chemically etched ( _30, 31, 43_ ). In both cases, a global optimum trades off interface recombination ( _Voc_ ), and charge extraction (FF) (Fig. 3, C and D). When nonradiative recombination was increased at the unpassivated nanorod surfaces, expanding pitch reduced the effective interface recombination and increased _V_ OC. However, FF is maximized at an intermediate pitch. For small pitches, the increased recombination that reduced _Voc_ also reduced FF, while larger pitches reduced FF through increased transport resistance in the perovskite bulk. The convolution of FF and _Voc_ across pitches showed that a narrow pitch range optimised performance, which in our parameterization fell near the 300 nm pitch we used (Fig. 3E). Our experimental exploration of the cell structure focused on rod separation because in our device simulations (fig. S20), modification of rod height and diameter led to much smaller increases or in some cases, decreases of _Voc_ and FF. 

30 

The results presented above were all obtained on cells of area 0.165 cm<sup>2</sup> , but we also fabricated optimized 300 nm pitch nanopatterned cells with an effective area of 1.2 cm<sup>2</sup> and _J-V_ data measured with ~1.02 cm<sup>2</sup> aperture mask. Our champion perovskite cell exhibited a PCE of 21.96% (21.86%) with _Voc_ ~ 1.205 V (1.204 V), _Jsc_ ~ 21.80 mA/cm<sup>2</sup> (21.86 mA/cm<sup>2</sup> ) and FF ~ 0.836 (0.836) from reverse (forward) scans measured in-house (Fig, 4A). External quantum 

10 

Submitted Manuscript: Confidential 

10 



efficiency (EQE) spectra confirmed the measured photocurrent with a relative discrepancy of ~3% between the integrated _Jsc_ from the EQE and the _Jsc_ measured from the _J-V_ curve (Fig. 4B). Another cell submitted to an independent testing center achieved a certified efficiency of ~21.698% ± 0.555% with a FF of 83.87% ± 1.16% (fig. S21). 

5 

The histogram distribution figure (inset, Fig. 4A) presents the reproducibility of the large-area perovskite cells (details of the _J-V_ parameters are provided in table S1). The ~30 mV decrease in _Voc_ when we used the aperture to measure the cell compared to the _J-V_ performance measured without an aperture (fig. S22) we ascribed to carrier recombination within the cell’s dark region shaded by the mask ( _44_ ). Taking this deficit into account, we conclude that there was negligible loss in _Voc_ or FF between cells of area 0.165 cm<sup>2</sup> and 1 cm<sup>2</sup> , despite a more than six times increase in photocurrent. 

15 

20 

25 

To test the light and thermal stability of the cells we conducted two extended degradation tests: a steady-state power output (SPO) measurement (unencapsulated cells held at maximum power point voltage ( _Vmpp_ ) under continuous illumination in a N2 atmosphere) and a damp heat test (encapsulated cells exposed to 85<sup>o</sup> C/85% RH in the dark). For the SPO test, Fig. 4C shows that the cell with the P3HT:CuPC HTL retained ~95.3% of its initial efficiency (PCEinitial ~ 21.45% ) after 260 hours, whereas the control cell with a Spiro-OMeTAD HTL dropped to ~76.1% of its initial efficiency (PCEinitial ~ 19.50%) after 250 hours. In the damp-heat test results (Fig. 4D), the P3HT:CuPc-based cell retained ~91.7% of its initial efficiency after 1009 hours of damp-heat exposure, whereas the cell with the Spiro-OMeTAD HTL exhibited substantial degradation after only 240 hours, which we attributed to the severe deterioration at the interface between perovskite and Spiro-OMeTAD caused by lithium ion diffusion ( _6, 32, 33_ ). The cells used for the damp-heat tests included an additional barrier layer consisting of MoOx (~10 nm) and IZO (~40 nm) placed between the HTL and the gold electrode to prevent gold diffusion into the cell at elevated temperatures ( _45_ ). 

Although we only present here stability data for one control and one nanopatterned cell, the same tests were repeated on multiple cell types incorporating the P3HT:CuPC HTL, all of which exhibited a similar improvement in stability relative to spiro-OMeTAD based cells. The 

11 

Submitted Manuscript: Confidential 



hydrophobic and thermally-stable nature of the ionic dopant-free P3HT:CuPc HTLs could increase the stability of perovskite cells compared to ionic-doped organic HTL materials without any penalty in performance. Time-dependent power output and _J-V_ curves showing the cell performance evolution during the two degradation tests are provided in figs. S23 to S26. 

5 

10 

Although the nanopatterned ETL reported here was fabricated with EBL, the structure is compatible with commercial scale fabrication using nanoimprint techniques ( _46_ ). Some form of self-assembled ETL nanostructure might also provide a sufficiently irregular surface to form local contacts through a passivation layer. More generally, our work demonstrates the important interaction between ETL morphology, interface passivation and charge transport at the ETL/perovskite interface. 

## **REFERENCES AND NOTES** 

15 

- 1..NREL efficiency chart (2020); <u>www.nrel.gov/pv/assets/pdfs/best-research-cellefficiencies.20200311.pdf</u> 

2. J. Burschka, N. Pellet, S.-J. Moon, R. Humphry-Baker, P. Gao, M. K. Nazeeruddin, M. Grätzel, Sequential deposition as a route to high-performance perovskite-sensitized solar cells. _Nature_ **499** , 316-319 (2013). doi:10.1038/nature12340 

20 

3. N. J. Jeon, J. H. Noh, W. S. Yang, Y. C. Kim, S. Ryu, J. Seo, S. I. Seok, Compositional engineering of perovskite materials for high-performance solar cells. _Nature_ **517** , 476480 (2015). doi:10.1038/nature14133 

4. W. S. Yang, J. H. Noh, N. J. Jeon, Y. C. Kim, S. Ryu, J. Seo, S. I. Seok, High-performance photovoltaic perovskite layers fabricated through intramolecular exchange. _Science_ **348** , 1234-1237 (2015). doi:10.1126/science.aaa9272 

25 

30 

5. W. S. Yang, B.-W. Park, E. H. Jung, N. J. Jeon, Y. C. Kim, D. U. Lee, S. S. Shin, J. Seo, E. K. Kim, J. H. Noh, S. I. Seok, Iodide management in formamidinium-lead-halide–based perovskite layers for efficient solar cells. _Science_ **356** , 1376-1379 (2017). <u>doi:10.1126/science.aan2301</u> 

6. E. H. Jung, N. J. Jeon, E. Y. Park, C. S. Moon, T. J. Shin, T.-Y. Yang, J. H. Noh, J. Seo, Efficient, stable and scalable perovskite solar cells using poly (3-hexylthiophene). _Nature_ **567** , 511-515 (2019). doi:10.1038/s41586-019-1036-3 

7. M. A. Green, Y. Hishikawa, E. D. Dunlop, D. H. Levi, J. Hohl-Ebinger, M. Yoshita, A. W. Y. Ho-Baillie, Solar cell efficiency tables (Version 53). _Prog. Photovol. Res. Appl._ **27** , 3-12 (2019). <u>doi:10.1002/pip.3102</u> 

12 

Submitted Manuscript: Confidential 



   8. M. A. Green, E. D. Dunlop, D. H. Levi, J. Hohl‐Ebinger, M. Yoshita, A. W. Ho-Baillie, Solar cell efficiency tables (Version 54). _Res. Appl._ **27** , 565-575 (2019). doi:10.1002/pip.3171 

- 5 

- 10 

- 15 

   9. M. A. Green, E. D. Dunlop, J. Hohl-Ebinger, M. Yoshita, N. Kopidakis, A. W. Ho-Baillie, Solar cell efficiency tables (Version 55). _Prog. Photovol. Res. Appl._ **28** , (2019). <u>doi:10.1002/pip.3228</u> 

   10. J. Peng, Y. Wu, W. Ye, D. A. Jacobs, H. Shen, X. Fu, Y. Wan, T. Duong, N. Wu, C. Barugkin, H. T. Nguyen, D. Zhong, J. Li, T. Lu, Y. Liu, M. N. Lockrey, K. J. Weber, K. R. Catchpole, T. P. White, Interface passivation using ultrathin polymer–fullerene films for high-efficiency perovskite solar cells with negligible hysteresis. _Energy Environ. Sci._ **10** , 1792-1800 (2017). doi:10.1039/C7EE01096F 

   11. J. Peng, J. I. Khan, W. Liu, E. Ugur, T. Duong, Y. Wu, H. Shen, K. Wang, H. Dang, E. Aydin, X. Yang, Y. Wan, K. J. Weber, K. R. Catchpole, F. Laquai, S. De Wolf, T. P. White, A universal double-side passivation for high open-circuit voltage in perovskite solar cells: role of carbonyl groups in poly(methyl methacrylate). _Adv. Energy Mater._ **8** , 1801208 (2018). doi:10.1002/aenm.201801208 

   12. S.-H. Turren-Cruz, A. Hagfeldt, M. Saliba, Methylammonium-free, high-performance, and stable perovskite solar cells on a planar architecture. _Science_ **362** , 449-453 (2018). <u>doi:10.1126/science.aat3583</u> 

13. Q. Wang, Q. Dong, T. Li, A. Gruverman, J. Huang, Thin insulating tunneling contacts for 

20 efficient and water‐resistant perovskite solar cells. _Adv. Mater._ **28** , 6734-6739 (2016). <u>doi: 10.1002/adma.201600969</u> 

- 25 

   14. L. Zuo, H. Guo, D. W. deQuilettes, S. Jariwala, N. De Marco, S. Dong, R. DeBlock, D. S. Ginger, B. Dunn, M. Wang, Y. Yang, Polymer-modified halide perovskite films for efficient and stable planar heterojunction solar cells. _Sci. Adv._ **3** , e1700106 (2017). <u>doi:10.1126/sciadv.1700106</u> 

   15. C. Tao, S. Neutzner, L. Colella, S. Marras, A. R. S. Kandada, M. Gandini, M. De Bastiani, G. Pace, L. Manna, M. Caironi, C. Bertarelli, A. Petrozza, 17.6% stabilized efficiency in low-temperature processed planar perovskite solar cells. _Energy Environ. Sci._ **8** , 23652370 (2015). doi:10.1039/C5EE01720C 

- 30 16. F. Zhang, W. Shi, J. Luo, N. Pellet, C. Yi, X. Li, X. Zhao, T. J. S. Dennis, X. Li, S. Wang, Y. Xiao, S. M. Zakeeruddin, D. Bi, M. Grätzel, Isomer-pure bis-PCBM-assisted crystal engineering of perovskite solar cells showing excellent efficiency and stability. _Adv. Mater._ **29** , 1606806 (2017). doi:10.1002/adma.201606806 

17. J. Xu, A. Buin, A. H. Ip, W. Li, O. Voznyy, R. Comin, M. Yuan, S. Jeon, Z. Ning, J. J. 

35 McDowell, P. Kanjanaboos, J.-P. Sun, X. Lan, L. N. Quan, D. H. Kim, I. G. Hill, P. Maksymovych, E. H. Sargent, Perovskite–fullerene hybrid materials suppress hysteresis in planar diodes. _Nat. Commun._ **6** , 7081 (2015). doi:10.1038/ncomms8081 

   18. D. Koushik, W. J. Verhees, Y. Kuang, S. Veenstra, D. Zhang, M. A. Verheijen, M. Creatore, R. E. Schropp, High-efficiency humidity-stable planar perovskite solar cells based on 

13 

Submitted Manuscript: Confidential 

10 

15 



atomic layer architecture. _Energy Environ. Sci._ **10** , 91-100 (2017). <u>doi: 10.1039/C6EE02687G</u> 

5 

19. J.-P. Correa-Baena, W. Tress, K. Domanski, E. H. Anaraki, S.-H. Turren-Cruz, B. Roose, P. P. Boix, M. Grätzel, M. Saliba, A. Abate, Identifying and suppressing interfacial recombination to achieve high open-circuit voltage in perovskite solar cells. _Energy Environ. Sci._ **10** , 1207-1212 (2017). doi:10.1039/C7EE00421D 

20. S. Gharibzadeh, B. Abdollahi Nejand, M. Jakoby, T. Abzieher, D. Hauschild, S. Moghadamzadeh, J. A. Schwenzer, P. Brenner, R. Schmager, A. A. Haghighirad, L. Weinhardt, U. Lemmer, B. S. Richards, I. A. Howard, U. W. Paetzold, Record opencircuit voltage wide-bandgap perovskite solar cells utilizing 2D/3D perovskite heterostructure. _Adv. Energy Mater._ **9** , 1803699 (2019). doi: 10.1002/aenm.201803699 

21. M. A. Mahmud, T. Duong, Y. Yin, H. T. Pham, D. Walter, J. Peng, Y. Wu, L. Li, H. Shen, N. Wu, N. Mozaffari, G. Andersson, K. R. Catchpole, K. J. Weber, T. P. White, Doublesided surface passivation of 3D perovskite film for high-efficiency mixed-dimensional perovskite solar cells. _Adv. Funct. Mater._ **30** , 1907962 (2020). <u>doi:10.1002/adfm.201907962</u> 

20 

25 

30 

22. D. Luo, W. Yang, Z. Wang, A. Sadhanala, Q. Hu, R. Su, R. Shivanna, G. F. Trindade, J. F. Watts, Z. Xu, T. Liu, K. Chen, F. Ye, P. Wu, L. Zhao, J. Wu, Y. Tu, Y. Zhang, X. Yang, W. Zhang, R. H. Friend, Q. Gong, H. J. Snaith, R. Zhu, Enhanced photovoltage for inverted planar heterojunction perovskite solar cells. _Science_ **360** , 1442-1446 (2018). <u>doi:10.1126/science.aap9282</u> 

23. X. Zheng, Y. Hou, C. Bao, J. Yin, F. Yuan, Z. Huang, K. Song, J. Liu, J. Troughton, N. Gasparini, C. Zhou, Y. Lin, D.-J. Xue, B. Chen, A. K. Johnston, N. Wei, M. N. Hedhili, M. Wei, A. Y. Alsalloum, P. Maity, B. Turedi, C. Yang, D. Baran, T. D. Anthopoulos, Y. Han, Z.-H. Lu, O. F. Mohammed, F. Gao, E. H. Sargent, O. M. Bakr, Managing grains and interfaces via ligand anchoring enables 22.3%-efficiency inverted perovskite solar cells. _Nat. Energy_ **5** , 131-140 (2020). doi:10.1038/s41560-019-0538-4 

24. Q. Jiang, Y. Zhao, X. Zhang, X. Yang, Y. Chen, Z. Chu, Q. Ye, X. Li, Z. Yin, J. You, Surface passivation of perovskite film for efficient solar cells. _Nat. Photonics_ **13** , 460466 (2019). doi:10.1038/s41566-019-0398-2 

25. J. J. Yoo, S. Wieghold, M. C. Sponseller, M. R. Chua, S. N. Bertram, N. T. P. Hartono, J. S. Tresback, E. C. Hansen, J.-P. Correa-Baena, V. Bulović, T. Buonassisi, S. S. Shin, M. G. Bawendi, An interface stabilized perovskite solar cell with high stabilized efficiency and low voltage loss. _Energy Environ. Sci._ **12** , 2192-2199 (2019). doi: 10.1039/C9EE00751B 

35 

26. M. J. Kerr, A. Cuevas, Very low bulk and surface recombination in oxidized silicon wafers. _Semicond. Sci. Technol._ **17** , 35 (2001). doi:10.1088/0268-1242/17/1/306 

27. J. Shewchun, R. Singh, M. Green,  Theory of metal-insulator-semiconductor solar cells. _J. Appl. Phys._ **48** , 765-770 (1977). <u>doi:10.1063/1.323667</u> 

14 

Submitted Manuscript: Confidential 



28. Y. Wu, F. Xie, H. Chen, X. Yang, H. Su, M. Cai, Z. Zhou, T. Noda, L. Han, Thermally stable MAPbI3 perovskite solar cells with efficiency of 19.19% and area over 1 cm2 achieved by additive engineering. _Adv. Mater._ **29** , 1701073 (2017). <u>doi: 10.1002/adma.201701073</u> 

5 

10 

29. T. Matsui, T. Yamamoto, T. Nishihara, R. Morisawa, T. Yokoyama, T. Sekiguchi, T. Negami, Compositional engineering for thermally stable, highly efficient perovskite solar cells exceeding 20% power conversion efficiency with 85 C/85% 1000 h stability. _Adv. Mater._ **31** , 1806823 (2019). doi:10.1002/adma.201806823 

30. E. Franklin, K. Fong, K. McIntosh, A. Fell, A. Blakers, T. Kho, D. Walter, D. Wang, N. Zin, M. Stocks, E.-C. Wang, N. Grant, Y. Wan, Y. Yang, X. Zhang, Z. Feng, P. J. Verlinden, Design, fabrication and characterisation of a 24.4% efficient interdigitated back contact solar cell. _Prog. Photovolt: Res. Appl_ . **24** , 411–427 (2014). doi:10.1002/pip.2556 

31. M. A. Green, The path to 25% silicon solar cell efficiency: history of silicon cell evolution. _Prog. Photovolt: Res. Appl._ **17** , 183–189 (2009). doi: 10.1002/pip.892 

15 

20 

25 

32. H. Min, M. Kim, S.-U. Lee, H. Kim, G. Kim, K. Choi, J. H. Lee, S. I. Seok, Efficient, stable solar cells by using inherent bandgap of α-phase formamidinium lead iodide. _Science_ **366** , 749-753 (2019). doi:10.1126/science.aay7044 

33. Y. Hou, X. Du, S. Scheiner, D. P. McMeekin, Z. Wang, N. Li, M. S. Killian, H. Chen, M. Richter, I. Levchuk, N. Schrenker, E. Spiecker, T. Stubhan, N. A. Luechinger, A. Hirsch, P. Schmuki, H.-P. Steinrück, R. H. Fink, M. Halik, H. J. Snaith, C. J. Brabec, A generic interface to reduce the efficiency-stability-cost gap of perovskite solar cells. _Science_ **358** , 1192-1197 (2017). doi:10.1126/science.aao5561 

34. Q.-Q. Chu, B. Ding, J. Peng, H. Shen, X. Li, Y. Liu, C.-X. Li, C.-J. Li, G.-J. Yang, T. P. White, K. R. Catchpole, Highly stable carbon-based perovskite solar cell with a record efficiency of over 18% via hole transport engineering. _J. Mater. Sci. Technol._ **35** , 987 (2019). <u>doi:10.1016/j.jmst.2018.12.025</u> 

35. Q. Hu, E. Rezaee, Q. Dong, H. Shan, Q. Chen, L. Wang, B. Liu, J. H. Pan, Z. X. Xu, P3HT/Phthalocyanine nanocomposites as efficient hole‐transporting materials for perovskite solar cells. _Solar RRL_ **3** , 1800264 (2019). doi:10.1002/solr.201800264 

30 

35 

36. L. Yang, X. Wang, X. Mai, T. Wang, C. Wang, X. Li, V. Murugadoss, Q. Shao, S. Angaiah, Z. Guo, Constructing efficient mixed-ion perovskite solar cells based on TiO2 nanorod array. _J. Colloid Interface Sci._ **534** , 459-468 (2019). <u>doi:10.1016/j.jcis.2018.09.045</u> 

37. A. Fakharuddin, F. D. Giacomo, A. L. Palma, F. Matteocci, I. Ahmed, S. Razza, A. D’Epifanio, S. Licoccia, J. Ismail, A. D. Carlo, T. M. Brown, R. Jose, Vertical TiO2 nanorods as a medium for stable and high-efficiency perovskite solar modules. _ACS Nano_ **9** ,  8420–8429 (2015). doi:10.1021/acsnano.5b03265 

38. X. Li, S.-M. Dai, P. Zhu, L. -L. Deng, S. -Y. Xie, Q. Cui, H. Chen, N. Wang, H. Lin, Efficient perovskite solar cells depending on TiO2 nanorod arrays. _ACS Appl. Mater. Interfaces_ **8** , 21358–21365 (2016). doi:10.1021/acsami.6b05971 

40 

39. A. J. Bett, P. S. C. Schulze, K. M. Winkler, Ö. S. Kabakli, I. Ketterer, L. E. Mundt, S. K. Reichmuth, G. Siefer, L. Cojocaru, L. Tutsch, M. Bivour, M. Hermle, S. W. Glunz, J. C. 

   - 15 

Submitted Manuscript: Confidential 



Goldschmidt, Two-terminal perovskite silicon tandem solar cells with a high-bandgap perovskite absorber enabling voltages over 1.8 V. _Prog. Photovol. Res. Appl._ **28** , 99-110 (2020). <u>doi:10.1002/pip.3208</u> 

5 

   40. C. Wu, H. Li, Y. Yan, B. Chi, K. M. Felice, R. B. Moore, B. A. Magill, R. R. H. H. Mudiyanselage, G. A. Khodaparast, M. Sanghadasa, S. Priya, Highly-stable organo-lead halide perovskites synthesized through green self-assembly process. _Solar RRL_ **2** , 1800052 (2018). doi:10.1002/solr.201800052 

   41.  W. Shockley, W. T. Read, Jr, Statistics of the recombinations of holes and electrons. _Phys. Rev._ **87** _,_ 835 –842 (1952). doi:10.1103/PhysRev.87.835 

- 10 42. Z. Ni, C. Bao, Y. Liu, Q. Jiang, W.-Q. Wu, S. Chen, X. Dai, B. Chen, B. Hartweg, Z. Yu, Z. Holman, J. Huang, Resolving spatial and energetic distributions of trap states in metal halide perovskite solar cells. _Science_ **367** , 1352–1358 (2020). <u>doi:10.1126/science.aba0893</u> 

15 

   43. S. Zhang, X. Pan, H. Jiao, W. Deng, J. Xu, Y. Chen, P. P. Altermatt, Z. Feng, P. J. Verlinden, 335-W world-record p-type monocrystalline module with 20.6% efficient PERC solar cells. _IEEE J. Photovolt_ . **6** , 145-152 (2016). doi: 10.1109/JPHOTOV.2015.2498039 

   44. D. Kiermasch, L. Gil-Escrig, H. J. Bolink, K. Tvingstedt, Effects of Masking on OpenCircuit Voltage and Fill Factor in Solar Cells. _Joule_ **3** , 16-26 (2019). <u>doi:10.1016/j.joule.2018.10.016</u> 

- 20 45. T. Duong, Y. Wu, H. Shen, J. Peng, S. Zhao, N. Wu, M. Lockery, T. P. White, K. J. Weber, K. R. Catchpole, Light and elevated temperature induced degradation (LeTID) in perovskite solar cells and development of stable semi-transparent cells. _Sol. Energy MKater. Sol. Cells_ **188** , 27-36 (2018). doi:10.1016/j.solmat.2018.08.017 

25 

46. L. J. Guo, Nanoimprint lithography: methods and material requirements. _Adv. Mater._ **19** , 495-513 (2007). doi:10.1002/adma.200600882 

47. J. Peng, T. Duong, X. Zhou, H. Shen, Y. Wu, H. K. Mulmudi, Y. Wan, D. Zhong, J. Li, T. Tsuzuki, K. J. Weber, K. R. Catchpole, T. P. White, Efficient indium-doped TiOx electron transport layers for high-performance perovskite solar cells and perovskitesilicon tandems. _Adv. Energy Mater._ **7** , 1601768 (2017). doi:10.1002/aenm.201601768 

30 

35 

48. L. Shi, T. L. Young, J. Kim, Y. Sheng, L. Wang, Y. Chen, Z. Feng, M. J. Keevers, X. Hao, P. J. Verlinden, M. A. Green, A. W. Y. Ho-Baillie, Accelerated lifetime testing of organic– inorganic perovskite solar cells encapsulated by polyisobutylene. _ACS Appl. Mater. Interfaces_ **9** , 25073-25081 (2017). <u>doi:10.1021/acsami.7b07625</u> 

49. D. Walter, A. Fell, Y. Wu, T. Duong, C. Barugkin, N. Wu, T. White, K. Weber, Transient photovoltage in perovskite solar cells: interaction of trap-mediated recombination and migration of multiple ionic species. _J. Phys. Chem. C_ **122** , 11270-11281 (2018). <u>doi:10.1021/acs.jpcc.8b02529</u> 

50. D. A. Jacobs,  H. Shen, F. Pfeffer, J. Peng,  T. P. White, F. J. Beck, K. R. Catchpole, The two faces of capacitance: New interpretations for electrical impedance measurements of 

16 

Submitted Manuscript: Confidential 



perovskite solar cells and their relation to hysteresis. _J. Appl. Phys._ **124** , 225702 (2018). <u>doi:10.1063/1.5063259.</u> 

5 

51. J. Lim, M. T. Horantner, N. Sakai, J. M. Ball, S. Mahesh, N. K. Noel, Y.-H. Lin, J. B. Patel, D. P. McMeekin, M. B. Johnston, B. Wenger, H. J. Snaith, Elucidating the long-range charge carrier mobility in metal halide perovskite thin films. _Energy Environ. Sci_ . **12** , 169-176 (2019). doi:10.1039/C8EE03395A 

52. C. Wehrenfennig, G. E. Eperon, M. B. Johnston, H. J. Snaith, L. M. Herz, High charge carrier mobilities and lifetimes in organolead trihalide perovskites. _Adv. Mater_ . **26** , 15841589 (2014). doi:10.1002/adma.201305172 

10 

15 

20 

53. I. L. Braly, D. W. deQuilettes, L. M. Pazos-Outón, S. Burke, M. E. Ziffer, D. S. Ginger, H. W. Hillhouse, Hybrid perovskite films approaching the radiative limit with over 90% photoluminescence quantum efficiency. _Nat. Photonics_ **12** , 355-361 (2018). <u>doi:10.1038/s41566-018-0154-z</u> 

54. D. W. deQuilettes, S. Koch, S. Burke, R. K. Paranji, A. J. Shropshire, M. E. Ziffer, D. S. Ginger, Photoluminescence lifetimes exceeding 8 μs and quantum yields exceeding 30% in hybrid perovskite thin films by ligand passivation. _ACS Energy Lett_ . **1** , 438-444 (2016). <u>doi:10.1021/acsenergylett.6b00236</u> 

55. J. Wang, W. Fu, S. Jariwala, I. Sinha, A. K.-Y. Jen, David S. Ginger, Reducing surface recombination velocities at the electrical contacts will improve perovskite photovoltaics. _ACS Energy Lett_ . **4** , 222-227 (2019). doi:10.1021/acsenergylett.8b02058 

56. M. D. Stamate, On the dielectric properties of dc magnetron TiO2 thin films. _Appl. Surf. Sci._ **218** , 318-323 (2003). doi:10.1016/S0169-4332(03)00624-X 

25 

30 

57. I. Anusca, S. Balčiūnas, P. Gemeiner, Š. Svirskas, M. Sanlialp, G. Lackner, C. Fettkenhauer, J. Belovickis, V. Samulionis, M. Ivanov, B. Dkhil, J. Banys, V. V. Shvartsman, D. C. Lupascu, Dielectric response: answer to many questions in the methylammonium lead halide solar cell absorbers. _Adv. Energy Mater._ **7** , 1700600 (2017). <u>doi:10.1002/aenm.201700600</u> 

58. T. W. Crothers, R. L. Milot, J. B. Patel, E. S. Parrott, J. Schlipf, P. Müller-Buschbaum, M. B. Johnston, L. M. Herz, Photon reabsorption masks intrinsic bimolecular charge-carrier recombination in CH3NH3PbI3 perovskite. _Nano Lett._ **17** , 5782-5789 (2017). <u>doi:10.1021/acs.nanolett.7b02834</u> 

59. W. Ma, C. Yang, X. Gong, K. Lee, A. J. Heeger, Thermally stable, efficient polymer solar cells with nanoscale control of the interpenetrating network morphology. _Adv. Funct. Mater._ **15** , 1617-1622 (2005). doi:10.1002/adfm.200500211 

35 

60. S. Ge, Y. Zhang, B. Huang, S. Huang, W. Tie, Y. Lei, Q. He, G. Tu, Q. Qin, S. Niu, M. Li, D. Li, Z. Zheng, Synthesis of highly crystalline copper phthalocyanine needles by solvothermal method. _Mater. Lett._ **163** , 61-64 (2016). doi:10.1016/j.matlet.2015.10.020 

40 

17 

Submitted Manuscript: Confidential 



## **ACKNOWLEDGEMENTS** 

5 

10 

15 

20 

**Funding:** This work was supported by the Australian Government through the Australian Renewable Energy Agency (ARENA) and the Australian Research Council. Responsibility for the views, information or advice expressed herein is not accepted by the Australian Government. J. P. acknowledges the financial support of a Postdoc Fellowship from the Australian Centre for Advanced Photovoltaics (ACAP). T. P. W. is the recipient of an Australian Research Council Future Fellowship (project number FT180100302) funded by the Australian Government. Y. R., Q. L. and J. L. acknowledge funding from National Natural Science Foundation of China (Grant No. 11761131001, 11974436, 11674402) and Guangdong Basic and Applied Basic Research Foundation (2020B1515020019). **Author contributions:** J. P. conceived the idea, designed the overall experiments, and led the project. J. P., Y. W., T. D., M. A. M. and H. S. prepared and characterized the perovskite cell devices. D. W., T. W. and K. J. W. conducted the 3D numerical simulation. Y. R. and Q. L. performed the PMMA hole pattern fabrication. J. L. supervised the PMMA hole pattern fabrication and optimisation. J. P. and D. –Y. C. performed ALD TiO2 deposition and ICP-RIE etching. Y. W. and M. A. M, performed the GIXRD and XRD measurements and analysis. M. T. and H. T. N. performed the PL and TRPL measurements and analysis. T. D., O. L. C. L. and S. Z. conducted the SEM measurements and analysis. T. L. and Y. L. performed the AFM measurements and analysis. W. L. performed the EQE measurements. L. L. and F. K. performed the FIB-SEM measurements and analysis. J. P., D. W. and T. P. W. wrote and revised the manuscript. T. P. W. and K. R. C supervised the project. All authors contributed to the discussion of the results and revision of the manuscript. **Competing interests:** None declared. **Data and materials availability:** All (other) data needed to evaluate the conclusions in the paper are present in the paper or the Supplementary Materials. 

25 

## **SUPPLEMENTARY MATERIALS** 

30 

Materials and Methods Supplementary Text Figs. S1 to S27 Table S1 References ( _47 – 60_ ) 3D Simulation Model File. 

18 

Submitted Manuscript: Confidential 





**Fig. 1. Certified performance of record perovskite solar cells.** ( **A** ) Record cell efficiency. ( **B** ) Record cell _Voc_ . ( **C** ) Record cell _Jsc_ . ( **D** ) Record cell FF. Note that the effective area of all record cells plotted here was <0.2 cm<sup>2</sup> . 

19 

Submitted Manuscript: Confidential 

5 

10 

15 





**Fig. 2. Nanostructured TiO2 ETL and statistical distribution of the photovoltaic parameters for nanopattern and control perovskite cells.** ( **A** ) Schematic of nanopattern perovskite cell studied in this work. ( **B** ) Cross-sectional SEM image of the nanopattern cell structure (note that the perovskite layer was fabricated using ~1 mol/mL diluted precursor solution instead of the standard ~1.3 mol/mL (for cells); the Pt protection layer was only used to prepare the focused ion beam SEM cross-sectional image). ( **C** ) Distribution of _Voc_ . ( **D** ) Distribution of _Jsc_ . ( **E** ) Distribution of FF. ( **F** ) Distribution of PCE. Note that the control cells are S-Planar, mp-TiO2 and A-Planar; the nanopattern cells are 300 nm, 600 nm and 1000 nm. S- Planar represents planar cells based on solution-processed compact TiO2 ETLs. mp-TiO2 represents mesoporous cells based on solution-processed compact TiO2/mesoporous TiO2 ETLs. A-Planar represents planar cells based on ALD-deposited compact TiO2 ETLs. 300 nm, 600 nm and 1000 nm represents the nanopattern cells based on nanostructured TiO2 nanorods with a spacing of 300nm, 600 nm and 1000 nm, respectively. The orange star icons indicate the values calculated from the 3D numerical simulations. 

20 

Submitted Manuscript: Confidential 

5 

10 





**Fig. 3. Simulation results.** ( **A** ) Experimental _J-V_ curves of the ‘S-Planar’ (reference cell) and the ‘300 nm’ pitch, representing mid-performance cells from each batch. ( **B** ) Simulated _J_ - _V_ curves for the planar and nanostructured cell in which we presume only 30% of the nanorod is coated with the insulating passivation layer (illustrated in inset figure). The periodic separation of the nanorods, or pitch, governs _Voc_ ( **C** ), FF ( **D** ), and hence overall efficiency **(E)** . The unpassivated and passivated ETL surfaces are characterized by defect concentrations, _Nt,bare_ and _Nt,pass_ , respectively. Panels C to E plot the dependence of cell performance on the ratio of unpassivated to passivated defect density, _k_ , for CF = 30% illustrating that the optimum pitch depends on the strength of un-passivated interface recombination. The electron diffusion length, _Ld_ , is marked by vertical dashed lines. 

21 

Submitted Manuscript: Confidential 

10 





**Fig. 4. Device performance and long-term stability tests for 1 cm**<sup>**2**</sup> **perovskite cells.** ( **A** ) _J-V_ performance. ( **B** ) EQE measurement. ( **C** ) The steady-state power output (SPO) of non5 encapsulated cells based on P3HT:CuPc and Spiro-OMeTAD HTL measured by _Vmpp_ tracking under continuous 1 sun illumination intensity. ( **D** ) The SPO of encapsulated cells based on P3HT:CuPc and Spiro-OMeTAD HTL. Note that the cell structure for the damp-heat tests included a MoOx/ITO barrier between the HTL and the gold electrode: ITO/c-TiO2/TiO2 nanorods/PMMA:PCBM/Cs0.05FA0.88MA0.07PbI2.56Br0.44/PMMA/P3HT:CuPc (or Spiro10 OMeTAD)/MoOx (~10 nm)/IZO (~40 nm)/Gold. 

22 

